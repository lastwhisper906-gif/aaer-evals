# DELL 8-K — 0001571996-21-000037 filed 2021-08-26

## item codes, every 8-K on or before 2021-09-03

- 2021-08-26 0001571996-21-000037 — 2.02, 9.01
- 2021-07-01 0001571996-21-000034 — 3.02
- 2021-06-24 0001571996-21-000031 — 5.07
- 2021-06-24 0001193125-21-197644 — 7.01, 9.01
- 2021-06-16 0001571996-21-000029 — 5.02
- 2021-05-27 0001571996-21-000019 — 2.02, 9.01
- 2021-05-03 0001571996-21-000010 — 8.01, 9.01
- 2021-04-14 0001193125-21-116271 — 1.01, 7.01, 9.01
- 2021-02-25 0001571996-21-000003 — 2.02, 9.01
- 2021-02-18 0001193125-21-047844 — 1.01, 2.03, 9.01
- 2020-11-24 0001571996-20-000048 — 2.02, 9.01
- 2020-08-27 0001571996-20-000041 — 2.02, 9.01
- 2020-07-02 0001571996-20-000037 — 5.07
- 2020-05-28 0001571996-20-000028 — 2.02, 9.01
- 2020-04-09 0001193125-20-102602 — 1.01, 2.03, 9.01
- 2020-04-08 0001571996-20-000021 — 5.02
- 2020-04-03 0001571996-20-000019 — 8.01, 9.01
- 2020-03-26 0001571996-20-000015 — 7.01
- 2020-02-27 0001571996-20-000009 — 2.02, 8.01, 9.01
- 2020-02-18 0001571996-20-000005 — 8.01, 9.01
- 2020-01-09 0001571996-20-000002 — 3.02
- 2020-01-06 0001193125-20-002200 — 3.02
- 2019-12-13 0001193125-19-313947 — 3.02
- 2019-12-10 0001571996-19-000052 — 5.02
- 2019-12-02 0001571996-19-000044 — 5.02, 7.01, 9.01
- 2019-11-26 0001571996-19-000042 — 2.02, 9.01
- 2019-09-23 0001193125-19-252192 — 1.01, 2.03, 9.01
- 2019-08-29 0001571996-19-000036 — 2.02, 9.01
- 2019-08-22 0001193125-19-226939 — 7.01, 8.01, 9.01
- 2019-07-11 0001571996-19-000032 — 5.02, 5.07, 9.01
- 2019-07-03 0001571996-19-000030 — 3.02
- 2019-06-27 0001571996-19-000028 — 3.02
- 2019-05-30 0001571996-19-000021 — 2.02, 9.01
- 2019-04-02 0001571996-19-000010 — 5.02
- 2019-03-21 0001193125-19-082281 — 1.01, 1.02, 2.03, 9.01
- 2019-03-19 0001571996-19-000005 — 5.02, 9.01
- 2019-03-14 0001193125-19-074935 — 1.01, 2.03, 9.01
- 2019-03-07 0001193125-19-066045 — 8.01, 9.01
- 2019-02-28 0001571996-19-000002 — 2.02, 9.01
- 2018-12-28 0001193125-18-360943 — 1.01, 1.02, 3.01, 3.03, 5.02, 5.03, 7.01, 8.01, 9.01
- 2018-12-21 0001193125-18-356324 — 1.01, 2.03, 9.01
- 2018-12-14 0001193125-18-349469 — 8.01
- 2018-12-11 0001193125-18-346958 — 5.07, 8.01, 9.01
- 2018-11-29 0001571996-18-000041 — 2.02, 9.01
- 2018-11-28 0001571996-18-000037 — 7.01, 8.01, 9.01
- 2018-11-26 0001193125-18-333967 — 8.01, 9.01
- 2018-11-15 0001193125-18-328110 — 1.01, 9.01 — amendment of 0001193125-18-327222
- 2018-11-15 0001193125-18-327222 — 1.01, 7.01, 9.01
- 2018-10-03 0001193125-18-291390 — 8.01
- 2018-09-06 0001571996-18-000029 — 2.02, 9.01
- 2018-08-06 0001571996-18-000027 — 8.01, 9.01
- 2018-07-02 0001193125-18-210339 — 1.01, 7.01, 9.01
- 2018-06-28 0001571996-18-000024 — 5.07
- 2018-06-04 0001571996-18-000019 — 2.02, 9.01
- 2018-05-17 0001571996-18-000016 — 7.01
- 2018-04-26 0001571996-18-000009 — 7.01, 9.01
- 2018-03-08 0001193125-18-074168 — 2.02, 9.01
- 2018-02-02 0001193125-18-029947 — 7.01, 9.01
- 2017-12-07 0001571996-17-000042 — 2.02, 9.01
- 2017-10-24 0001571996-17-000037 — 1.01, 2.03, 9.01
- 2017-09-15 0001571996-17-000027 — 5.02
- 2017-09-07 0001571996-17-000017 — 2.02, 9.01
- 2017-08-24 0001571996-17-000014 — 8.01
- 2017-06-29 0001571996-17-000011 — 3.03, 5.07, 8.01, 9.01
- 2017-06-08 0001193125-17-197638 — 2.02, 9.01
- 2017-03-30 0001193125-17-102794 — 8.01
- 2017-03-30 0001193125-17-102777 — 2.02, 9.01
- 2017-03-09 0001193125-17-076981 — 1.01, 2.03, 9.01
- 2017-01-17 0001193125-17-011125 — 8.01
- 2016-12-15 0001193125-16-793722 — 8.01
- 2016-12-08 0001193125-16-787976 — 2.02, 9.01
- 2016-11-10 0001193125-16-765964 — 1.02, 8.01
- 2016-11-04 0001193125-16-760249 — 8.01
- 2016-09-13 0001193125-16-708600 — 3.02
- 2016-09-09 0001193125-16-706567 — 1.01, 1.02, 2.01, 2.03, 3.02, 3.03, 5.02, 9.01
- 2016-09-07 0001193125-16-703370 — 3.03, 5.07, 7.01, 8.01, 9.01
- 2016-09-06 0001193125-16-702057 — 2.02, 9.01
- 2016-08-31 0001193125-16-697268 — 8.01, 9.01
- 2016-08-26 0001193125-16-692921 — 8.01, 9.01
- 2016-07-11 0001193125-16-645610 — 8.01
- 2016-07-05 0001193125-16-641679 — 8.01
- 2016-06-22 0001193125-16-629055 — 1.01, 2.03, 8.01, 9.01
- 2016-06-21 0001193125-16-627071 — 8.01, 9.01
- 2016-06-10 0001193125-16-618483 — 2.02, 9.01
- 2016-06-09 0001193125-16-617893 — 8.01, 9.01

## late-filing notifications on or before 2021-09-03

- none on or before 2021-09-03

## item 2.02 — earnings release, exhibit 99.1

[0001571996-21-000037:8k_2_02:1]
EX-99.1
2
exhibit991earnings8kq2fy22.htm
EX-99.1

[0001571996-21-000037:8k_2_02:2]
Document

[0001571996-21-000037:8k_2_02:3]
Exhibit 99.1

[0001571996-21-000037:8k_2_02:4]
Durable Competitive Advantages Power Dell Technologies’

[0001571996-21-000037:8k_2_02:5]
Record Second Quarter Results in “Do-Anything-from-Anywhere” Economy

[0001571996-21-000037:8k_2_02:6]
ROUND ROCK, Texas — August 26, 2021

[0001571996-21-000037:8k_2_02:7]
News summary

[0001571996-21-000037:8k_2_02:8]
•Best second quarter in Dell Technologies’ history, driven by strong execution and demand across the IT ecosystem

[0001571996-21-000037:8k_2_02:9]
•Record second quarter revenue of $26.1 billion, up 15%

[0001571996-21-000037:8k_2_02:10]
•Record second quarter operating income of $1.4 billion, up 21%, and record second quarter non-GAAP operating income of $2.8 billion, up 7%

[0001571996-21-000037:8k_2_02:11]
Full story

[0001571996-21-000037:8k_2_02:12]
Dell Technologies (NYSE: DELL) announces record financial results for its fiscal 2022 second quarter. Revenue was up 15% to $26.1 billion. The company generated operating income of $1.4 billion, a 21% increase over the same period in the prior year, and a second quarter record non-GAAP operating income of $2.8 billion, up 7%. Net income was $0.9 billion, non-GAAP net income was $1.9 billion and adjusted EBITDA was $3.3 billion. Net cash from operating activities was $1.7 billion. Diluted earnings per share was $1.05, down 23% and non-GAAP diluted earnings per share was $2.24, up 17%.

[0001571996-21-000037:8k_2_02:13]
“We’re well known for our unique ability to adjust and lean into growth opportunities, as evidenced by our results with record second quarter revenue of $26.1 billion,” said Jeff Clarke, vice chairman and co-chief operating officer, Dell Technologies. “We’re innovating and helping customers grow with a focus on multi-cloud solutions and modern infrastructure delivered traditionally and as-a-Service.”

[0001571996-21-000037:8k_2_02:14]
1

[0001571996-21-000037:8k_2_02:15]
Second Quarter Fiscal 2022 Financial Results

[0001571996-21-000037:8k_2_02:16]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | July 30, 2021 |  | July 31, 2020 |  | Change |  | July 30, 2021 |  | July 31, 2020 |  | Change |
|  | (in millions, except per share amounts and percentages; unaudited) |
| Total net revenue | $ | 26,122 |  |  | $ | 22,733 |  |  | 15% |  | $ | 50,609 |  |  | $ | 44,630 |  |  | 13% |
| Operating income | $ | 1,372 |  |  | $ | 1,136 |  |  | 21% |  | $ | 2,747 |  |  | $ | 1,838 |  |  | 49% |
| Net income | $ | 880 |  |  | $ | 1,099 |  |  | (20)% |  | $ | 1,818 |  |  | $ | 1,281 |  |  | 42% |
| Earnings per share - diluted | $ | 1.05 |  |  | $ | 1.37 |  |  | (23)% |  | $ | 2.18 |  |  | $ | 1.56 |  |  | 40% |
| Non-GAAP net revenue | $ | 26,133 |  |  | $ | 22,775 |  |  | 15% |  | $ | 50,632 |  |  | $ | 44,720 |  |  | 13% |
| Non-GAAP operating income | $ | 2,811 |  |  | $ | 2,618 |  |  | 7% |  | $ | 5,525 |  |  | $ | 4,779 |  |  | 16% |
| Non-GAAP net income | $ | 1,911 |  |  | $ | 1,621 |  |  | 18% |  | $ | 3,730 |  |  | $ | 2,764 |  |  | 35% |
| Adjusted EBITDA | $ | 3,331 |  |  | $ | 3,100 |  |  | 7% |  | $ | 6,566 |  |  | $ | 5,707 |  |  | 15% |
| Non-GAAP earnings per share - diluted | $ | 2.24 |  |  | $ | 1.92 |  |  | 17% |  | $ | 4.38 |  |  | $ | 3.26 |  |  | 34% |

[0001571996-21-000037:8k_2_02:17]
Information about Dell Technologies’ use of non-GAAP financial information is provided under “Non-GAAP Financial Measures” below.  All comparisons in this press release are year-over-year unless otherwise noted.

[0001571996-21-000037:8k_2_02:18]
Dell Technologies ended the quarter with remaining performance obligations of $46 billion, up 24% and cash and investments of $13.6 billion. The company has paid down $5.5 billion in debt year-to-date and expects to pay down at least $16.0 billion for its fiscal year 2022.

[0001571996-21-000037:8k_2_02:19]
“We had strong results again this quarter, with all business units growing,” said Tom Sweet, chief financial officer, Dell Technologies. “We are creating long-term value by taking share, pursuing high-value growth opportunities and profitably growing and modernizing our core business. For example, in the storage space, VxRail orders were up 34% and PowerStore continues to ramp up nicely.”

[0001571996-21-000037:8k_2_02:20]
Operating segments summary

[0001571996-21-000037:8k_2_02:21]
Client Solutions Group revenue for the second quarter was up 27% to a record $14.3 billion. Operating income was a second quarter record $995 million, up 39%, and 7% of Client Solutions Group revenue, as the company innovates across the ecosystem to deliver an enhanced experience for customers looking to work and play effectively from anywhere. Commercial client revenue was $10.6 billion, up 32%, and consumer revenue was a second quarter record of $3.7 billion, up 17%.

[0001571996-21-000037:8k_2_02:22]
2

[0001571996-21-000037:8k_2_02:23]
Key highlights:

[0001571996-21-000037:8k_2_02:24]
•Strong growth in Latitude and Precision systems.

[0001571996-21-000037:8k_2_02:25]
•Introduced the new Dell UltraSharp Webcam - a beautifully designed external 4K webcam ideal for a superb video conferencing experience.

[0001571996-21-000037:8k_2_02:26]
•Launched the high-performance Alienware X-Series - a new mobile gaming family with Dell’s thinnest available 15” and 17” gaming laptops, featuring exclusive Cryo-Tech innovations.

[0001571996-21-000037:8k_2_02:27]
Infrastructure Solutions Group revenue for the second quarter was $8.4 billion, up 3% as customers accelerate their IT investments with focus on multi-cloud solutions. Servers and networking revenue was $4.5 billion, up 6%, and storage revenue was $4.0 billion, down 1%.  Operating income was $970 million for the second quarter, or approximately 11.5% of Infrastructure Solutions Group revenue.

[0001571996-21-000037:8k_2_02:28]
Key highlights:

[0001571996-21-000037:8k_2_02:29]
•Launched the APEX portfolio of services that allow customers to scale IT as needed to launch new applications, kickstart new projects and address the changing needs of their organizations – all managed by Dell and accessed through a single console.

[0001571996-21-000037:8k_2_02:30]
•Introduced Dell EMC VxRail hyperconverged infrastructure (HCI) systems with enhanced software and performance, based on recently launched Dell EMC PowerEdge servers.

[0001571996-21-000037:8k_2_02:31]
•Began shipping six of our latest generation Dell EMC PowerEdge servers, including the ruggedized systems built for challenging environments at the edge.

[0001571996-21-000037:8k_2_02:32]
•Announced an open, cloud-native Telecom ecosystem to put communications service providers (CSPs) on the fast track for innovation and revenue growth.

[0001571996-21-000037:8k_2_02:33]
VMware revenue was $3.1 billion for the second quarter, up 8% driven by broad-based strength across a diverse product portfolio. Operating income for the quarter was $849 million, or 27.0% of VMware revenue.

[0001571996-21-000037:8k_2_02:34]
Conference call information

[0001571996-21-000037:8k_2_02:35]
As previously announced, the Company will hold a conference call to discuss its second quarter performance today, August 26, 2021 at 4:30 p.m. CDT. The conference call will be broadcast live over the internet and can be accessed at https://investors.delltechnologies.com/events-and-presentations/upcoming-events.

[0001571996-21-000037:8k_2_02:36]
For those unable to listen to the live broadcast, an archived version will be available at the same location for one year.

[0001571996-21-000037:8k_2_02:37]
Additional financial and operating information may be downloaded from

[0001571996-21-000037:8k_2_02:38]
https://investors.delltechnologies.com/financial-information/quarterly-results

[0001571996-21-000037:8k_2_02:39]
Dell Technologies will hold a Securities Analyst Meeting on September 23, 2021 at 9:00 a.m. CDT. Speakers will include chairman and chief executive officer, Michael Dell, along with other key members of the executive leadership team with significant time allotted for Q&A. Registration information can be accessed online here.

[0001571996-21-000037:8k_2_02:40]
About Dell Technologies

[0001571996-21-000037:8k_2_02:41]
Dell Technologies (NYSE:DELL) helps organizations and individuals build their digital future and transform how they work, live and play. The company provides customers with the industry’s broadest and most innovative technology and services portfolio for the data era.

[0001571996-21-000037:8k_2_02:42]
3

[0001571996-21-000037:8k_2_02:43]
Contacts

[0001571996-21-000037:8k_2_02:44]
Investors: Investor_Relations@Dell.com

[0001571996-21-000037:8k_2_02:45]
Media: Media.Relations@Dell.com

[0001571996-21-000037:8k_2_02:46]
# # #

[0001571996-21-000037:8k_2_02:47]
Copyright © 2021 Dell Inc. or its subsidiaries. All Rights Reserved. Dell Technologies, Dell, EMC and Dell EMC are trademarks of Dell Inc. or its subsidiaries. Other trademarks may be trademarks of their respective owners.

[0001571996-21-000037:8k_2_02:48]
Non-GAAP Financial Measures:

[0001571996-21-000037:8k_2_02:49]
This press release presents information about Dell Technologies’ non-GAAP net revenue, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, non-GAAP net income attributable to non-controlling interests, non-GAAP net income attributable to Dell Technologies Inc. - basic, non-GAAP net income attributable to Dell Technologies Inc. - diluted, non-GAAP earnings per share attributable to Dell Technologies Inc. - basic, non-GAAP earnings per share attributable to Dell Technologies Inc. - diluted, EBITDA, and adjusted EBITDA, which are non-GAAP financial measures provided as a supplement to the results provided in accordance with generally accepted accounting principles in the United States of America (“GAAP”). A reconciliation of each non-GAAP financial measure to the most directly comparable GAAP financial measure is provided in the attached tables for each of the fiscal periods indicated.

[0001571996-21-000037:8k_2_02:50]
Special Note on Forward-Looking Statements:

[0001571996-21-000037:8k_2_02:51]
Dell Technologies’ results or events in future periods could differ materially from those expressed or implied by these forward-looking statements because of risks, uncertainties, and other factors that include, but are not limited to, the following: risks and uncertainties relating to our agreement to spin off VMware, Inc., including risks that could affect our ability to complete the transaction on the terms announced or at all and the potential effects on our business of the announcement and consummation of the transaction; the effects of the COVID-19 pandemic; competitive pressures; Dell Technologies’ reliance on third-party suppliers for products and components, including reliance on single-source or limited-source suppliers; Dell Technologies’ ability to achieve favorable pricing from its vendors; adverse global economic conditions and instability in financial markets; Dell Technologies’ execution of its growth, business and acquisition strategies; the success of Dell Technologies’ cost efficiency measures; Dell Technologies’ ability to manage solutions and products and services transitions in an effective manner; Dell Technologies’ ability to deliver high-quality products, software, and services; cyber attacks or other data security incidents; Dell Technologies’ foreign operations and ability to generate substantial non-U.S. net revenue; Dell Technologies’ product, services, customer, and geographic sales mix, and seasonal sales trends; the performance of Dell Technologies’ sales channel partners; access to the capital markets by Dell Technologies or its customers; material impairment of the value of goodwill or intangible assets; weak economic conditions and the effect of additional regulation on Dell Technologies’ financial services activities; counterparty default risks; the loss by Dell Technologies of any contracts for ISG services and solutions and its ability to perform such contracts at their estimated costs; loss by Dell Technologies of government contracts; Dell Technologies’ ability to develop and protect its proprietary intellectual property or obtain licenses to intellectual property developed by others on commercially reasonable and competitive terms; disruptions in Dell Technologies’ infrastructure; Dell Technologies’ ability to hedge effectively its exposure to fluctuations in foreign currency exchange rates and interest rates; expiration of tax holidays or favorable tax rate structures, or unfavorable outcomes in tax audits and other tax compliance matters; impairment of portfolio investments; unfavorable results of legal proceedings; compliance requirements of changing environmental and safety laws or other laws; the effect of armed hostilities, terrorism, natural disasters, and public health issues; Dell Technologies’ dependence on the services of Michael Dell and key employees; Dell Technologies’ level of indebtedness; and the impact of the financial performance of VMware, Inc.

[0001571996-21-000037:8k_2_02:52]
This list of risks, uncertainties, and other factors is not complete. Dell Technologies discusses some of these matters more fully, as well as certain risk factors that could affect Dell Technologies’ business, financial condition, results of operations, and prospects, in its reports filed with the SEC, including Dell Technologies’ annual report on Form 10-K for the fiscal year ended January 29, 2021, quarterly reports on Form 10-Q, and current reports on Form 8-K. These filings are available for review through the SEC’s website at www.sec.gov. Any or all forward-looking statements Dell Technologies makes may turn out to be wrong and can be affected by inaccurate assumptions Dell Technologies might make or by known or unknown risks, uncertainties and other factors, including those identified in this press release. Accordingly, you should not place undue reliance on the forward-looking statements made in this press release, which speak only as of its date. Dell Technologies does not undertake to update, and expressly disclaims any duty to update, its forward-looking statements, whether as a result of circumstances or events that arise after the date they are made, new information, or otherwise.

[0001571996-21-000037:8k_2_02:53]
4

[0001571996-21-000037:8k_2_02:54]
DELL TECHNOLOGIES INC.

[0001571996-21-000037:8k_2_02:55]
Condensed Consolidated Statements of Income and Related Financial Highlights

[0001571996-21-000037:8k_2_02:56]
(in millions, except percentages; unaudited)

[0001571996-21-000037:8k_2_02:57]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | July 30, 2021 |  | July 31, 2020 |  | Change |  | July 30, 2021 |  | July 31, 2020 |  | Change |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Products | $ | 19,394 |  | $ | 16,737 |  | 16% |  | $ | 37,428 |  |  | $ | 32,775 |  |  | 14% |
| Services | 6,728 |  | 5,996 |  | 12% |  | 13,181 |  |  | 11,855 |  |  | 11% |
| Total net revenue | 26,122 |  | 22,733 |  | 15% |  | 50,609 |  |  | 44,630 |  |  | 13% |
| Cost of net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Products | 15,371 |  | 13,330 |  | 15% |  | 29,585 |  |  | 26,134 |  |  | 13% |
| Services | 2,766 |  | 2,247 |  | 23% |  | 5,381 |  |  | 4,487 |  |  | 20% |
| Total cost of net revenue | 18,137 |  | 15,577 |  | 16% |  | 34,966 |  |  | 30,621 |  |  | 14% |
| Gross margin | 7,985 |  | 7,156 |  | 12% |  | 15,643 |  |  | 14,009 |  |  | 12% |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative | 5,145 |  | 4,761 |  | 8% |  | 10,105 |  |  | 9,647 |  |  | 5% |
| Research and development | 1,468 |  | 1,259 |  | 17% |  | 2,791 |  |  | 2,524 |  |  | 11% |
| Total operating expenses | 6,613 |  | 6,020 |  | 10% |  | 12,896 |  |  | 12,171 |  |  | 6% |
| Operating income | 1,372 |  | 1,136 |  | 21% |  | 2,747 |  |  | 1,838 |  |  | 49% |
| Interest and other, net | (359) |  | (636) |  | 44% |  | (747) |  |  | (1,202) |  |  | 38% |
| Income before income taxes | 1,013 |  | 500 |  | 103% |  | 2,000 |  |  | 636 |  |  | 214% |
| Income tax expense (benefit) | 133 |  | (599) |  | 122% |  | 182 |  |  | (645) |  |  | 128% |
| Net income | 880 |  | 1,099 |  | (20)% |  | 1,818 |  |  | 1,281 |  |  | 42% |
| Less: Net income attributable to non-controlling interests | 49 |  | 51 |  | (4)% |  | 100 |  |  | 90 |  |  | 11% |
| Net income attributable to Dell Technologies Inc. | $ | 831 |  | $ | 1,048 |  | (21)% |  | $ | 1,718 |  |  | $ | 1,191 |  |  | 44% |
| Percentage of Total Net Revenue: |  |  |  |  |  |  |  |  |  |  |
| Gross margin | 31 | % |  | 31 | % |  |  |  | 31 | % |  | 31 | % |  |  |
| Selling, general, and administrative | 20 | % |  | 21 | % |  |  |  | 20 | % |  | 22 | % |  |  |
| Research and development | 6 | % |  | 6 | % |  |  |  | 6 | % |  | 6 | % |  |  |
| Operating expenses | 25 | % |  | 26 | % |  |  |  | 25 | % |  | 27 | % |  |  |
| Operating income | 5 | % |  | 5 | % |  |  |  | 5 | % |  | 4 | % |  |  |
| Income before income taxes | 4 | % |  | 2 | % |  |  |  | 4 | % |  | 1 | % |  |  |
| Net income | 3 | % |  | 5 | % |  |  |  | 4 | % |  | 3 | % |  |  |
| Income tax rate | 13.1 | % |  | -119.8 | % |  |  |  | 9.1 | % |  | -101.4 | % |  |  |

[0001571996-21-000037:8k_2_02:58]
Amounts are based on underlying data and may not visually foot due to rounding.

[0001571996-21-000037:8k_2_02:59]
5

[0001571996-21-000037:8k_2_02:60]
DELL TECHNOLOGIES INC.

[0001571996-21-000037:8k_2_02:61]
Consolidated Statements of Financial Position

[0001571996-21-000037:8k_2_02:62]
(in millions; unaudited)

[0001571996-21-000037:8k_2_02:63]
|  | July 30, 2021 |  | January 29, 2021 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 11,719 |  |  | $ | 14,201 |  |
| Accounts receivable, net | 12,914 |  |  | 12,788 |  |
| Short-term financing receivables, net | 4,955 |  |  | 5,155 |  |
| Inventories, net | 4,223 |  |  | 3,402 |  |
| Other current assets | 9,556 |  |  | 8,021 |  |
| Current assets held for sale | 188 |  |  | — |  |
| Total current assets | 43,555 |  |  | 43,567 |  |
| Property, plant, and equipment, net | 6,661 |  |  | 6,431 |  |
| Long-term investments | 1,875 |  |  | 1,624 |  |
| Long-term financing receivables, net | 5,330 |  |  | 5,339 |  |
| Goodwill | 40,741 |  |  | 40,829 |  |
| Intangible assets, net | 13,014 |  |  | 14,429 |  |
| Other non-current assets | 11,502 |  |  | 11,196 |  |
| Total assets | $ | 122,678 |  |  | $ | 123,415 |  |
| LIABILITIES, REDEEMABLE SHARES, AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Short-term debt | $ | 6,427 |  |  | $ | 6,362 |  |
| Accounts payable | 23,029 |  |  | 21,696 |  |
| Accrued and other | 8,808 |  |  | 9,549 |  |
| Short-term deferred revenue | 17,003 |  |  | 16,525 |  |
| Current liabilities held for sale | 216 |  |  | — |  |
| Total current liabilities | 55,483 |  |  | 54,132 |  |
| Long-term debt | 37,167 |  |  | 41,622 |  |
| Long-term deferred revenue | 14,840 |  |  | 14,276 |  |
| Other non-current liabilities | 5,245 |  |  | 5,360 |  |
| Total liabilities | 112,735 |  |  | 115,390 |  |
| Redeemable shares | — |  |  | 472 |  |
| Stockholders’ equity: |  |  |  |
| Total Dell Technologies Inc. stockholders’ equity | 4,825 |  |  | 2,479 |  |
| Non-controlling interests | 5,118 |  |  | 5,074 |  |
| Total stockholders’ equity | 9,943 |  |  | 7,553 |  |
| Total liabilities, redeemable shares, and stockholders’ equity | $ | 122,678 |  |  | $ | 123,415 |  |

[0001571996-21-000037:8k_2_02:64]
6

[0001571996-21-000037:8k_2_02:65]
DELL TECHNOLOGIES INC.

[0001571996-21-000037:8k_2_02:66]
Condensed Consolidated Statements of Cash Flows

[0001571996-21-000037:8k_2_02:67]
(in millions; unaudited)

[0001571996-21-000037:8k_2_02:68]
|  | Three Months Ended |  | Six Months Ended |
|  | July 30, 2021 |  | July 31, 2020 |  | July 30, 2021 |  | July 31, 2020 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |
| Net income | $ | 880 |  |  | $ | 1,099 |  |  | $ | 1,818 |  |  | $ | 1,281 |  |
| Adjustments to reconcile net income to net cash provided by (used in) operating activities | 845 |  |  | 2,233 |  |  | 2,145 |  |  | 1,255 |  |
| Change in cash from operating activities | 1,725 |  |  | 3,332 |  |  | 3,963 |  |  | 2,536 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |
| Purchases of investments | (124) |  |  | (118) |  |  | (270) |  |  | (174) |  |
| Maturities and sales of investments | 79 |  |  | 32 |  |  | 335 |  |  | 71 |  |
| Capital expenditures and capitalized software development costs | (632) |  |  | (545) |  |  | (1,257) |  |  | (1,104) |  |
| Acquisition of businesses and assets, net | (6) |  |  | (296) |  |  | (16) |  |  | (334) |  |
| Divestitures of businesses and assets, net | — |  |  | — |  |  | — |  |  | 120 |  |
| Other | 14 |  |  | 3 |  |  | 20 |  |  | 12 |  |
| Change in cash from investing activities | (669) |  |  | (924) |  |  | (1,188) |  |  | (1,409) |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |
| Proceeds from the issuance of common stock | 26 |  |  | 105 |  |  | 186 |  |  | 221 |  |
| Repurchases of parent common stock (a) | (8) |  |  | — |  |  | (17) |  |  | (240) |  |
| Repurchases of subsidiary common stock (a) | (544) |  |  | (291) |  |  | (978) |  |  | (591) |  |
| Proceeds from debt | 1,209 |  |  | 1,712 |  |  | 3,935 |  |  | 11,847 |  |
| Repayments of debt | (4,353) |  |  | (4,815) |  |  | (8,423) |  |  | (10,220) |  |
| Other | (3) |  |  | (148) |  |  | (14) |  |  | (190) |  |
| Change in cash from financing activities | (3,673) |  |  | (3,437) |  |  | (5,311) |  |  | 827 |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash | (16) |  |  | 84 |  |  | (21) |  |  | (52) |  |
| Change in cash, cash equivalents, and restricted cash | (2,633) |  |  | (945) |  |  | (2,557) |  |  | 1,902 |  |
| Cash, cash equivalents, and restricted cash at beginning of the period | 15,260 |  |  | 12,998 |  |  | 15,184 |  |  | 10,151 |  |
| Cash, cash equivalents, and restricted cash at end of the period | $ | 12,627 |  |  | $ | 12,053 |  |  | $ | 12,627 |  |  | $ | 12,053 |  |

[0001571996-21-000037:8k_2_02:69]
_________________

[0001571996-21-000037:8k_2_02:70]
(a) Common stock repurchases are inclusive of employee tax withholding on stock-based compensation.

[0001571996-21-000037:8k_2_02:71]
7

[0001571996-21-000037:8k_2_02:72]
DELL TECHNOLOGIES INC.

[0001571996-21-000037:8k_2_02:73]
Segment Information

[0001571996-21-000037:8k_2_02:74]
(in millions, except percentages; unaudited; continued on next page)

[0001571996-21-000037:8k_2_02:75]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | July 30, 2021 |  | July 31, 2020 |  | Change |  | July 30, 2021 |  | July 31, 2020 |  | Change |
| Infrastructure Solutions Group (ISG): |
| Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Servers and networking | $ | 4,462 |  |  | $ | 4,196 |  |  | 6% |  | $ | 8,571 |  |  | $ | 7,954 |  |  | 8% |
| Storage | 3,970 |  |  | 4,011 |  |  | (1)% |  | 7,772 |  |  | 7,822 |  |  | (1)% |
| Total ISG net revenue | $ | 8,432 |  |  | $ | 8,207 |  |  | 3% |  | $ | 16,343 |  |  | $ | 15,776 |  |  | 4% |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| ISG operating income | $ | 970 |  |  | $ | 973 |  |  | —% |  | $ | 1,758 |  |  | $ | 1,705 |  |  | 3% |
| % of ISG net revenue | 12 | % |  | 12 | % |  |  |  | 11 | % |  | 11 | % |  |  |
| % of total reportable segment operating income | 34 | % |  | 38 | % |  |  |  | 32 | % |  | 36 | % |  |  |
| Client Solutions Group (CSG): |
| Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 10,573 |  |  | $ | 8,039 |  |  | 32% |  | $ | 20,376 |  |  | $ | 16,673 |  |  | 22% |
| Consumer | 3,690 |  |  | 3,164 |  |  | 17% |  | 7,192 |  |  | 5,634 |  |  | 28% |
| Total CSG net revenue | $ | 14,263 |  |  | $ | 11,203 |  |  | 27% |  | $ | 27,568 |  |  | $ | 22,307 |  |  | 24% |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| CSG operating income | $ | 995 |  |  | $ | 715 |  |  | 39% |  | $ | 2,085 |  |  | $ | 1,307 |  |  | 60% |
| % of CSG net revenue | 7 | % |  | 6 | % |  |  |  | 8 | % |  | 6 | % |  |  |
| % of total reportable segment operating income | 35 | % |  | 28 | % |  |  |  | 38 | % |  | 28 | % |  |  |
| VMware: |
| Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Total VMware net revenue | $ | 3,148 |  |  | $ | 2,908 |  |  | 8% |  | $ | 6,139 |  |  | $ | 5,663 |  |  | 8% |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| VMware operating income | $ | 849 |  |  | $ | 894 |  |  | (5)% |  | $ | 1,690 |  |  | $ | 1,667 |  |  | 1% |
| % of VMware net revenue | 27 | % |  | 31 | % |  |  |  | 28 | % |  | 29 | % |  |  |
| % of total reportable segment operating income | 30 | % |  | 35 | % |  |  |  | 31 | % |  | 36 | % |  |  |

[0001571996-21-000037:8k_2_02:76]
Amounts are based on underlying data and may not visually foot due to rounding.

[0001571996-21-000037:8k_2_02:77]
8

[0001571996-21-000037:8k_2_02:78]
DELL TECHNOLOGIES INC.

[0001571996-21-000037:8k_2_02:79]
Segment Information

[0001571996-21-000037:8k_2_02:80]
(in millions, except percentages; unaudited; continued)

[0001571996-21-000037:8k_2_02:81]
|  | Three Months Ended |  | Six Months Ended |
|  | July 30, 2021 |  | July 31, 2020 |  | July 30, 2021 |  | July 31, 2020 |
| Reconciliation to consolidated net revenue: |  |  |  |  |  |  |
| Reportable segment net revenue | $ | 25,843 |  |  | $ | 22,318 |  |  | $ | 50,050 |  |  | $ | 43,746 |  |
| Other businesses (a) | 288 |  |  | 457 |  |  | 578 |  |  | 974 |  |
| Unallocated transactions (b) | 2 |  |  | — |  |  | 4 |  |  | — |  |
| Impact of purchase accounting (c) | (11) |  |  | (42) |  |  | (23) |  |  | (90) |  |
| Total consolidated net revenue | $ | 26,122 |  |  | $ | 22,733 |  |  | $ | 50,609 |  |  | $ | 44,630 |  |
| Reconciliation to consolidated operating income: |  |  |  |  |
| Reportable segment operating income | $ | 2,814 |  |  | $ | 2,582 |  |  | $ | 5,533 |  |  | $ | 4,679 |  |
| Other businesses (a) | (3) |  |  | 37 |  |  | (8) |  |  | 102 |  |
| Unallocated transactions (b) | — |  |  | (1) |  |  | — |  |  | (2) |  |
| Impact of purchase accounting (c) | (20) |  |  | (53) |  |  | (45) |  |  | (116) |  |
| Amortization of intangibles | (711) |  |  | (847) |  |  | (1,420) |  |  | (1,702) |  |
| Transaction-related expenses (d) | (60) |  |  | (83) |  |  | (111) |  |  | (159) |  |
| Stock-based compensation expense (e) | (499) |  |  | (413) |  |  | (934) |  |  | (783) |  |
| Other corporate expenses (f) | (149) |  |  | (86) |  |  | (268) |  |  | (181) |  |
| Total consolidated operating income | $ | 1,372 |  |  | $ | 1,136 |  |  | $ | 2,747 |  |  | $ | 1,838 |  |

[0001571996-21-000037:8k_2_02:82]
_________________

[0001571996-21-000037:8k_2_02:83]
(a)Secureworks, Virtustream, and Boomi constitute “Other businesses” and do not meet the requirements for a reportable segment, either individually or collectively. The results of Other businesses are not material to the Company’s overall results. On September 1, 2020, the Company completed the sale of RSA Security. Prior to divestiture, RSA Security’s results were included within Other businesses.

[0001571996-21-000037:8k_2_02:84]
(b)Unallocated transactions includes other corporate items that are not allocated to Dell Technologies’ reportable segments.

[0001571996-21-000037:8k_2_02:85]
(c)Impact of purchase accounting includes non-cash purchase accounting adjustments that are primarily related to the EMC merger transaction.

[0001571996-21-000037:8k_2_02:86]
(d)Transaction-related expenses includes acquisition, integration, and divestiture related costs.

[0001571996-21-000037:8k_2_02:87]
(e)Stock-based compensation expense consists of equity awards granted based on the estimated fair value of those awards at grant date.

[0001571996-21-000037:8k_2_02:88]
(f)Other corporate expenses includes impairment charges, severance, facilities action, and other costs.

[0001571996-21-000037:8k_2_02:89]
9

[0001571996-21-000037:8k_2_02:90]
SUPPLEMENTAL SELECTED NON-GAAP FINANCIAL MEASURES

[0001571996-21-000037:8k_2_02:91]
These tables present information about the Company’s non-GAAP net revenue, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, non-GAAP net income attributable to non-controlling interests, non-GAAP net income attributable to Dell Technologies Inc. - basic, non-GAAP net income attributable to Dell Technologies Inc. - diluted, non-GAAP earnings per share attributable to Dell Technologies Inc. - basic, non-GAAP earnings per share attributable to Dell Technologies Inc. - diluted, EBITDA, and adjusted EBITDA, which are non-GAAP financial measures provided as a supplement to the results provided in accordance with generally accepted accounting principles in the United States of America (“GAAP”). A detailed discussion of Dell Technologies’ reasons for including these non-GAAP financial measures, the limitations associated with these measures, the items excluded from these measures, and our reason for excluding those items are presented in “Management’s Discussion and Analysis of Financial Condition and Results of Operations — Non-GAAP Financial Measures” in our periodic reports filed with the SEC. Dell Technologies encourages investors to review the non-GAAP discussion in these reports in conjunction with the presentation of non-GAAP financial measures.

[0001571996-21-000037:8k_2_02:92]
10

[0001571996-21-000037:8k_2_02:93]
DELL TECHNOLOGIES INC.

[0001571996-21-000037:8k_2_02:94]
Selected Non-GAAP Financial Measures

[0001571996-21-000037:8k_2_02:95]
(in millions, except per share amounts and percentages; unaudited)

[0001571996-21-000037:8k_2_02:96]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | July 30, 2021 |  | July 31, 2020 |  | Change |  | July 30, 2021 |  | July 31, 2020 |  | Change |
| Non-GAAP net revenue | $ | 26,133 |  | $ | 22,775 |  | 15% |  | $ | 50,632 |  |  | $ | 44,720 |  |  | 13% |
| Non-GAAP gross margin | $ | 8,342 |  | $ | 7,626 |  | 9% |  | $ | 16,360 |  |  | $ | 14,951 |  |  | 9% |
| % of non-GAAP net revenue | 32 | % |  | 33 | % |  |  |  | 32 | % |  | 33 | % |  |  |
| Non-GAAP operating expenses | $ | 5,531 |  | $ | 5,008 |  | 10% |  | $ | 10,835 |  |  | $ | 10,172 |  |  | 7% |
| % of non-GAAP net revenue | 21 | % |  | 22 | % |  |  |  | 21 | % |  | 23 | % |  |  |
| Non-GAAP operating income | $ | 2,811 |  | $ | 2,618 |  | 7% |  | $ | 5,525 |  |  | $ | 4,779 |  |  | 16% |
| % of non-GAAP net revenue | 11 | % |  | 11 | % |  |  |  | 11 | % |  | 11 | % |  |  |
| Non-GAAP net income | $ | 1,911 |  | $ | 1,621 |  | 18% |  | $ | 3,730 |  |  | $ | 2,764 |  |  | 35% |
| % of non-GAAP net revenue | 7 | % |  | 7 | % |  |  |  | 7 | % |  | 6 | % |  |  |
| Adjusted EBITDA | $ | 3,331 |  | $ | 3,100 |  | 7% |  | $ | 6,566 |  |  | $ | 5,707 |  |  | 15% |
| % of non-GAAP net revenue | 13 | % |  | 14 | % |  |  |  | 13 | % |  | 13 | % |  |  |
| Non-GAAP earnings per share - diluted | $ | 2.24 |  | $ | 1.92 |  | 17% |  | $ | 4.38 |  |  | $ | 3.26 |  |  | 34% |

[0001571996-21-000037:8k_2_02:97]
Amounts are based on underlying data and may not visually foot due to rounding.

[0001571996-21-000037:8k_2_02:98]
11

[0001571996-21-000037:8k_2_02:99]
DELL TECHNOLOGIES INC.

[0001571996-21-000037:8k_2_02:100]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-21-000037:8k_2_02:101]
(in millions, except percentages; unaudited; continued on next page)

[0001571996-21-000037:8k_2_02:102]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | July 30, 2021 |  | July 31, 2020 |  | Change |  | July 30, 2021 |  | July 31, 2020 |  | Change |
| Net revenue | $ | 26,122 |  |  | $ | 22,733 |  |  | 15% |  | $ | 50,609 |  |  | $ | 44,630 |  |  | 13% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 11 |  |  | 42 |  |  |  |  | 23 |  |  | 90 |  |  |  |
| Non-GAAP net revenue | $ | 26,133 |  |  | $ | 22,775 |  |  | 15% |  | $ | 50,632 |  |  | $ | 44,720 |  |  | 13% |
| Gross margin | $ | 7,985 |  |  | $ | 7,156 |  |  | 12% |  | $ | 15,643 |  |  | $ | 14,009 |  |  | 12% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 275 |  |  | 375 |  |  |  |  | 551 |  |  | 747 |  |  |  |
| Impact of purchase accounting | 12 |  |  | 43 |  |  |  |  | 25 |  |  | 94 |  |  |  |
| Transaction-related expenses | — |  |  | — |  |  |  |  | — |  |  | — |  |  |  |
| Stock-based compensation expense | 63 |  |  | 50 |  |  |  |  | 121 |  |  | 90 |  |  |  |
| Other corporate expenses | 7 |  |  | 2 |  |  |  |  | 20 |  |  | 11 |  |  |  |
| Non-GAAP gross margin | $ | 8,342 |  |  | $ | 7,626 |  |  | 9% |  | $ | 16,360 |  |  | $ | 14,951 |  |  | 9% |
| Operating expenses | $ | 6,613 |  |  | $ | 6,020 |  |  | 10% |  | $ | 12,896 |  |  | $ | 12,171 |  |  | 6% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | (436) |  |  | (472) |  |  |  |  | (869) |  |  | (955) |  |  |  |
| Impact of purchase accounting | (8) |  |  | (10) |  |  |  |  | (20) |  |  | (22) |  |  |  |
| Transaction-related expenses | (60) |  |  | (83) |  |  |  |  | (111) |  |  | (159) |  |  |  |
| Stock-based compensation expense | (436) |  |  | (363) |  |  |  |  | (813) |  |  | (693) |  |  |  |
| Other corporate expenses | (142) |  |  | (84) |  |  |  |  | (248) |  |  | (170) |  |  |  |
| Non-GAAP operating expenses | $ | 5,531 |  |  | $ | 5,008 |  |  | 10% |  | $ | 10,835 |  |  | $ | 10,172 |  |  | 7% |
| Operating income | $ | 1,372 |  |  | $ | 1,136 |  |  | 21% |  | $ | 2,747 |  |  | $ | 1,838 |  |  | 49% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 711 |  |  | 847 |  |  |  |  | 1,420 |  |  | 1,702 |  |  |  |
| Impact of purchase accounting | 20 |  |  | 53 |  |  |  |  | 45 |  |  | 116 |  |  |  |
| Transaction-related expenses | 60 |  |  | 83 |  |  |  |  | 111 |  |  | 159 |  |  |  |
| Stock-based compensation expense | 499 |  |  | 413 |  |  |  |  | 934 |  |  | 783 |  |  |  |
| Other corporate expenses | 149 |  |  | 86 |  |  |  |  | 268 |  |  | 181 |  |  |  |
| Non-GAAP operating income | $ | 2,811 |  |  | $ | 2,618 |  |  | 7% |  | $ | 5,525 |  |  | $ | 4,779 |  |  | 16% |

[0001571996-21-000037:8k_2_02:103]
12

[0001571996-21-000037:8k_2_02:104]
DELL TECHNOLOGIES INC.

[0001571996-21-000037:8k_2_02:105]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-21-000037:8k_2_02:106]
(in millions, except percentages; unaudited; continued)

[0001571996-21-000037:8k_2_02:107]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | July 30, 2021 |  | July 31, 2020 |  | Change |  | July 30, 2021 |  | July 31, 2020 |  | Change |
| Net income | $ | 880 |  |  | $ | 1,099 |  |  | (20)% |  | $ | 1,818 |  |  | $ | 1,281 |  |  | 42% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 711 |  |  | 847 |  |  |  |  | 1,420 |  |  | 1,702 |  |  |  |
| Impact of purchase accounting | 20 |  |  | 53 |  |  |  |  | 45 |  |  | 116 |  |  |  |
| Transaction-related expenses | 48 |  |  | 83 |  |  |  |  | 99 |  |  | 39 |  |  |  |
| Stock-based compensation expense | 499 |  |  | 413 |  |  |  |  | 934 |  |  | 783 |  |  |  |
| Other corporate expenses | 149 |  |  | 86 |  |  |  |  | 268 |  |  | 181 |  |  |  |
| Fair value adjustments on equity investments | (168) |  |  | (8) |  |  |  |  | (325) |  |  | (102) |  |  |  |
| Aggregate adjustment for income taxes | (228) |  |  | (952) |  |  |  |  | (529) |  |  | (1,236) |  |  |  |
| Non-GAAP net income | $ | 1,911 |  |  | $ | 1,621 |  |  | 18% |  | $ | 3,730 |  |  | $ | 2,764 |  |  | 35% |
| Net income | $ | 880 |  |  | $ | 1,099 |  |  | (20)% |  | $ | 1,818 |  |  | $ | 1,281 |  |  | 42% |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Interest and other, net | 359 |  |  | 636 |  |  |  |  | 747 |  |  | 1,202 |  |  |  |
| Income tax expense (benefit) | 133 |  |  | (599) |  |  |  |  | 182 |  |  | (645) |  |  |  |
| Depreciation and amortization | 1,240 |  |  | 1,340 |  |  |  |  | 2,479 |  |  | 2,656 |  |  |  |
| EBITDA | $ | 2,612 |  |  | $ | 2,476 |  |  | 5% |  | $ | 5,226 |  |  | $ | 4,494 |  |  | 16% |
| EBITDA | $ | 2,612 |  |  | $ | 2,476 |  |  | 5% |  | $ | 5,226 |  |  | $ | 4,494 |  |  | 16% |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense | 499 |  |  | 413 |  |  |  |  | 934 |  |  | 783 |  |  |  |
| Impact of purchase accounting | 11 |  |  | 42 |  |  |  |  | 27 |  |  | 90 |  |  |  |
| Transaction-related expenses | 60 |  |  | 83 |  |  |  |  | 111 |  |  | 159 |  |  |  |
| Other corporate expenses | 149 |  |  | 86 |  |  |  |  | 268 |  |  | 181 |  |  |  |
| Adjusted EBITDA | $ | 3,331 |  |  | $ | 3,100 |  |  | 7% |  | $ | 6,566 |  |  | $ | 5,707 |  |  | 15% |

[0001571996-21-000037:8k_2_02:108]
13

[0001571996-21-000037:8k_2_02:109]
DELL TECHNOLOGIES INC.

[0001571996-21-000037:8k_2_02:110]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-21-000037:8k_2_02:111]
For the Three Months Ended July 30, 2021

[0001571996-21-000037:8k_2_02:112]
(in millions, except per share amounts; unaudited)

[0001571996-21-000037:8k_2_02:113]
|  | GAAP |  | Amortization of intangibles |  | Impact of purchase accounting |  | Transaction-related expenses |  | Stock-based compensation expense |  | Other corporate expenses |  | Fair value adjustments on equity investments |  | Aggregate adjustment for income taxes |  | Non-GAAP |
| Net income | $ | 880 |  |  | 711 |  |  | 20 |  |  | 48 |  |  | 499 |  |  | 149 |  |  | (168) |  |  | (228) |  |  | $ | 1,911 |  |
| Less: Net income attributable to non-controlling interests (a) | 49 |  |  | 55 |  |  | 1 |  |  | 5 |  |  | 58 |  |  | (1) |  |  | — |  |  | (22) |  |  | 145 |  |
| Net income attributable to Dell Technologies Inc. - basic | 831 |  |  | 656 |  |  | 19 |  |  | 43 |  |  | 441 |  |  | 150 |  |  | (168) |  |  | (206) |  |  | 1,766 |  |
| Incremental dilution from VMware, Inc. attributable to Dell Technologies Inc. (b) | (3) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (5) |  |
| Net income attributable to Dell Technologies Inc. - diluted | $ | 828 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 1,761 |  |
| Earnings per share - basic | $ | 1.09 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 2.31 |  |
| Earnings per share - diluted | $ | 1.05 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 2.24 |  |
| Weighted-average shares outstanding - basic | 763 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 763 |  |
| Weighted-average shares outstanding - diluted | 786 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 786 |  |

[0001571996-21-000037:8k_2_02:114]
_________________

[0001571996-21-000037:8k_2_02:115]
(a)     Net income attributable to non-controlling interests is calculated by multiplying the minority interest percentage of VMware, Inc. and SecureWorks Corp. by their respective non-GAAP net income adjustments for the period presented.

[0001571996-21-000037:8k_2_02:116]
(b)     Incremental dilution from VMware, Inc. attributable to Dell Technologies Inc. represents the impact of VMware, Inc.’s dilutive securities on the diluted earnings per share of Dell Technologies Inc. and is calculated by multiplying the difference between VMware, Inc.’s basic and diluted earnings per share by the number of shares of VMware, Inc. common stock held by Dell Technologies Inc.

[0001571996-21-000037:8k_2_02:117]
14

[0001571996-21-000037:8k_2_02:118]
DELL TECHNOLOGIES INC.

[0001571996-21-000037:8k_2_02:119]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-21-000037:8k_2_02:120]
For the Six Months Ended July 30, 2021

[0001571996-21-000037:8k_2_02:121]
(in millions, except per share amounts; unaudited)

[0001571996-21-000037:8k_2_02:122]
|  | GAAP |  | Amortization of intangibles |  | Impact of purchase accounting |  | Transaction-related expenses |  | Stock-based compensation expense |  | Other corporate expenses |  | Fair value adjustments on equity investments |  | Aggregate adjustment for income taxes |  | Non-GAAP |
| Net income | 1,818 |  |  | 1,420 |  |  | 45 |  |  | 99 |  |  | 934 |  |  | 268 |  |  | (325) |  |  | (529) |  |  | 3,730 |  |
| Less: Net income attributable to non-controlling interests (a) | 100 |  |  | 108 |  |  | 2 |  |  | 9 |  |  | 110 |  |  | — |  |  | 7 |  |  | (45) |  |  | 291 |  |
| Net income attributable to Dell Technologies Inc. - basic | $ | 1,718 |  |  | $ | 1,312 |  |  | $ | 43 |  |  | $ | 90 |  |  | $ | 824 |  |  | $ | 268 |  |  | $ | (332) |  |  | $ | (484) |  |  | $ | 3,439 |  |
| Incremental dilution from VMware, Inc. attributable to Dell Technologies Inc. (b) | $ | (5) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | (9) |  |
| Net income attributable to Dell Technologies Inc. - diluted | $ | 1,713 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 3,430 |  |
| Earnings per share - basic | $ | 2.26 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 4.53 |  |
| Earnings per share - diluted | $ | 2.18 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 4.38 |  |
| Weighted-average shares outstanding - basic | 760 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 760 |  |
| Weighted-average shares outstanding - diluted | 784 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 784 |  |

[0001571996-21-000037:8k_2_02:123]
_________________

[0001571996-21-000037:8k_2_02:124]
(a)     Net income attributable to non-controlling interests is calculated by multiplying the minority interest percentage of VMware, Inc. and SecureWorks Corp. by their respective non-GAAP net income adjustments for the period presented.

[0001571996-21-000037:8k_2_02:125]
(b)     Incremental dilution from VMware, Inc. attributable to Dell Technologies Inc. represents the impact of VMware, Inc.’s dilutive securities on the diluted earnings per share of Dell Technologies Inc. and is calculated by multiplying the difference between VMware, Inc.’s basic and diluted earnings per share by the number of shares of VMware, Inc. common stock held by Dell Technologies Inc.

[0001571996-21-000037:8k_2_02:126]
15

[0001571996-21-000037:8k_2_02:127]
DELL TECHNOLOGIES INC.

[0001571996-21-000037:8k_2_02:128]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-21-000037:8k_2_02:129]
For the Three Months Ended July 31, 2020

[0001571996-21-000037:8k_2_02:130]
(in millions, except per share amounts; unaudited)

[0001571996-21-000037:8k_2_02:131]
|  | GAAP |  | Amortization of intangibles |  | Impact of purchase accounting |  | Transaction-related expenses |  | Stock-based compensation expense |  | Other corporate expenses |  | Fair value adjustments on equity investments |  | Aggregate adjustment for income taxes |  | Non-GAAP |
| Net income | $ | 1,099 |  |  | 847 |  |  | 53 |  |  | 83 |  |  | 413 |  |  | 86 |  |  | (8) |  |  | (952) |  |  | $ | 1,621 |  |
| Less: Net income attributable to non-controlling interests (a) | 51 |  |  | 64 |  |  | 4 |  |  | 8 |  |  | 57 |  |  | — |  |  | — |  |  | (29) |  |  | 155 |  |
| Net income attributable to Dell Technologies Inc. - basic | 1,048 |  |  | 783 |  |  | 49 |  |  | 75 |  |  | 356 |  |  | 86 |  |  | (8) |  |  | (923) |  |  | 1,466 |  |
| Incremental dilution from VMware, Inc. attributable to Dell Technologies Inc. (b) | (3) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (5) |  |
| Net income attributable to Dell Technologies Inc. - diluted | $ | 1,045 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 1,461 |  |
| Earnings per share - basic | $ | 1.41 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 1.98 |  |
| Earnings per share - diluted | $ | 1.37 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 1.92 |  |
| Weighted-average shares outstanding - basic | 741 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 741 |  |
| Weighted-average shares outstanding - diluted | 761 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 761 |  |

[0001571996-21-000037:8k_2_02:132]
_________________

[0001571996-21-000037:8k_2_02:133]
(a)     Net income attributable to non-controlling interests is calculated by multiplying the minority interest percentage of VMware, Inc. and SecureWorks Corp. by their respective non-GAAP net income adjustments for the period presented.

[0001571996-21-000037:8k_2_02:134]
(b)     Incremental dilution from VMware, Inc. attributable to Dell Technologies Inc. represents the impact of VMware, Inc.’s dilutive securities on the diluted earnings per share of Dell Technologies Inc. and is calculated by multiplying the difference between VMware, Inc.’s basic and diluted earnings per share by the number of shares of VMware, Inc. common stock held by Dell Technologies Inc.

[0001571996-21-000037:8k_2_02:135]
DELL TECHNOLOGIES INC.

[0001571996-21-000037:8k_2_02:136]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-21-000037:8k_2_02:137]
For the Six Months Ended July 31, 2020

[0001571996-21-000037:8k_2_02:138]
(in millions, except per share amounts; unaudited)

[0001571996-21-000037:8k_2_02:139]
|  | GAAP |  | Amortization of intangibles |  | Impact of purchase accounting |  | Transaction-related expenses |  | Stock-based compensation expense |  | Other corporate expenses |  | Fair value adjustments on equity investments |  | Aggregate adjustment for income taxes |  | Non-GAAP |
| Net income | 1,281 |  |  | 1,702 |  |  | 116 |  |  | 39 |  |  | 783 |  |  | 181 |  |  | (102) |  |  | (1,236) |  |  | 2,764 |  |
| Less: Net income attributable to non-controlling interests (a) | 90 |  |  | 124 |  |  | 7 |  |  | 15 |  |  | 111 |  |  | — |  |  | (1) |  |  | (64) |  |  | 282 |  |
| Net income attributable to Dell Technologies Inc. - basic | $ | 1,191 |  |  | $ | 1,578 |  |  | $ | 109 |  |  | $ | 24 |  |  | $ | 672 |  |  | $ | 181 |  |  | $ | (101) |  |  | $ | (1,172) |  |  | $ | 2,482 |  |
| Incremental dilution from VMware, Inc. attributable to Dell Technologies Inc. (b) | $ | (5) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | (9) |  |
| Net income attributable to Dell Technologies Inc. - diluted | $ | 1,186 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 2,473 |  |
| Earnings per share - basic | $ | 1.61 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 3.35 |  |
| Earnings per share - diluted | $ | 1.56 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 3.26 |  |
| Weighted-average shares outstanding - basic | 740 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 740 |  |
| Weighted-average shares outstanding - diluted | 758 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 758 |  |

[0001571996-21-000037:8k_2_02:140]
_________________

[0001571996-21-000037:8k_2_02:141]
(a)     Net income attributable to non-controlling interests is calculated by multiplying the minority interest percentage of VMware, Inc. and SecureWorks Corp. by their respective non-GAAP net income adjustments for the period presented.

[0001571996-21-000037:8k_2_02:142]
(b)     Incremental dilution from VMware, Inc. attributable to Dell Technologies Inc. represents the impact of VMware, Inc.’s dilutive securities on the diluted earnings per share of Dell Technologies Inc. and is calculated by multiplying the difference between VMware, Inc.’s basic and diluted earnings per share by the number of shares of VMware, Inc. common stock held by Dell Technologies Inc.
