# DELL notes — 0001571996-21-000040


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001571996-21-000040:notes:1]
Basis of Presentation — The accompanying unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes filed with the U.S. Securities and Exchange Commission (“SEC”) in the Company’s Annual Report on Form 10-K for the fiscal year ended January 29, 2021.  These Condensed Consolidated Financial Statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“GAAP”).  In the opinion of management, the accompanying Condensed Consolidated Financial Statements reflect all adjustments of a normal recurring nature considered necessary to fairly state the financial position of Dell Technologies Inc. as of July 30, 2021 and January 29, 2021, the results of its operations and corresponding comprehensive income (loss) for the three and six months ended July 30, 2021 and July 31, 2020, its cash flows for the six months ended July 30, 2021 and July 31, 2020, and its statements of stockholders’ equity for the three and six months ended July 30, 2021 and July 31, 2020.


## us-gaap:ConsolidationPolicyTextBlock

[0001571996-21-000040:notes:2]
[same as prior period, unchanged from 0001571996-21-000026:notes:2]


## us-gaap:ScheduleOfDisposalGroupsIncludingDiscontinuedOperationsIncomeStatementBalanceSheetAndAdditionalDisclosuresTextBlock

[0001571996-21-000040:notes:3]
The following table presents the major classes of assets and liabilities as of July 30, 2021 related to Boomi which were classified as held for sale as of the date indicated:

[0001571996-21-000040:notes:4]
|  | July 30, 2021 |
|  | (in millions) |
| ASSETS |
| Current assets: |  |
| Accounts receivable, net | $ | 72 |  |
| Other current assets | 32 |  |
| Total current assets | 104 |  |
| Goodwill | 39 |  |
| Other non-current assets | 40 |  |
| Total assets | $ | 183 |  |
| LIABILITIES |
| Current liabilities: |  |
| Short-term deferred revenue | $ | 155 |  |
| Other current liabilities | 45 |  |
| Total current liabilities | 200 |  |
| Other non-current liabilities | 16 |  |
| Total liabilities | $ | 216 |  |


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001571996-21-000040:notes:5]
Recently Issued Accounting Pronouncements

[0001571996-21-000040:notes:6]
Reference Rate Reform — In March 2020, the Financial Accounting Standards Board (“FASB”) issued guidance which provides temporary optional expedients and exceptions to GAAP guidance on contract modifications and certain hedging relationships to ease the financial reporting burdens related to the expected market transition from the London Interbank Offered Rate to alternative reference rates.  The Company may elect to apply the amendments prospectively through December 31, 2022.  Adoption of the new guidance is not expected to have a material impact on the Company’s financial results.

[0001571996-21-000040:notes:7]
Recently Adopted Accounting Pronouncements

[0001571996-21-000040:notes:8]
Accounting for Convertible Instruments and Contracts in an Entity’s Own Equity — In August 2020, the FASB issued guidance to simplify the accounting for convertible debt instruments and convertible preferred stock, and the derivatives scope exception for contracts in an entity's own equity.  In addition, the guidance on calculating diluted earnings per share has been simplified and made more internally consistent.  The Company early adopted this standard as of January 30, 2021.  There was no impact on the Condensed Consolidated Financial Statements or to diluted earnings per share as of the adoption date.

[0001571996-21-000040:notes:9]
Simplifying Accounting for Income Taxes — In December 2019, the FASB issued guidance to simplify the accounting for income taxes by removing certain exceptions to the general principles in Topic 740, Income Taxes, and by clarifying and amending existing guidance in order to improve consistent application of GAAP for other areas of Topic 740.  The Company adopted the standard during the three months ended April 30, 2021.  The impact of the adoption of this standard was immaterial to the Condensed Consolidated Financial Statements.


## us-gaap:FairValueDisclosuresTextBlock

[0001571996-21-000040:notes:10]
[same as prior period, unchanged from 0001571996-21-000026:notes:8]

[0001571996-21-000040:notes:11]
The following table presents the Company’s hierarchy for its assets and liabilities measured and recorded at fair value on a recurring basis as of the dates indicated:

[0001571996-21-000040:notes:12]
|  | July 30, 2021 |  | January 29, 2021 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | Quoted Prices in Active Markets for Identical Assets |  | Significant Other Observable Inputs |  | Significant Unobservable Inputs |  |  |  | Quoted Prices in Active Markets for Identical Assets |  | Significant Other Observable Inputs |  | Significant Unobservable Inputs |  |  |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 6,442 |  |  | $ | — |  |  | $ | — |  |  | $ | 6,442 |  |  | $ | 8,846 |  |  | $ | — |  |  | $ | — |  |  | $ | 8,846 |  |
| Equity and other securities | 299 |  |  | — |  |  | — |  |  | 299 |  |  | 449 |  |  | — |  |  | — |  |  | 449 |  |
| Derivative instruments | — |  |  | 75 |  |  | — |  |  | 75 |  |  | — |  |  | 104 |  |  | — |  |  | 104 |  |
| Total assets | $ | 6,741 |  |  | $ | 75 |  |  | $ | — |  |  | $ | 6,816 |  |  | $ | 9,295 |  |  | $ | 104 |  |  | $ | — |  |  | $ | 9,399 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative instruments | $ | — |  |  | $ | 131 |  |  | $ | — |  |  | $ | 131 |  |  | $ | — |  |  | $ | 133 |  |  | $ | — |  |  | $ | 133 |  |
| Total liabilities | $ | — |  |  | $ | 131 |  |  | $ | — |  |  | $ | 131 |  |  | $ | — |  |  | $ | 133 |  |  | $ | — |  |  | $ | 133 |  |

[0001571996-21-000040:notes:13]
[same as prior period, unchanged from 0001571996-21-000026:notes:11]

[0001571996-21-000040:notes:14]
Money Market Funds — The Company’s investments in money market funds that are classified as cash equivalents hold underlying investments with a weighted average maturity of 90 days or less and are recognized at fair value.  The valuations of these securities are based on quoted prices in active markets for identical assets, when available, or pricing models whereby all significant inputs are observable or can be derived from or corroborated by observable market data.  The Company reviews security pricing and assesses liquidity on a quarterly basis.  As of July 30, 2021, the Company’s U.S. portfolio had no material exposure to money market funds with a fluctuating net asset value.

[0001571996-21-000040:notes:15]
[same as prior period, unchanged from 0001571996-21-000026:notes:13]

[0001571996-21-000040:notes:16]
[same as prior period, unchanged from 0001571996-21-000026:notes:14]

[0001571996-21-000040:notes:17]
Deferred Compensation Plans — The Company offers deferred compensation plans for eligible employees, which allow participants to defer payment for a portion of their compensation.  Assets were the same as liabilities associated with the plans at approximately $355 million and $308 million as of July 30, 2021 and January 29, 2021, respectively, and are included in other assets and other liabilities on the Condensed Consolidated Statements of Financial Position.  The net impact to the Condensed Consolidated Statements of Income is not material since changes in the fair value of the assets substantially offset changes in the fair value of the liabilities.  As such, assets and liabilities associated with these plans have not been included in the recurring fair value table above.

[0001571996-21-000040:notes:18]
[same as prior period, unchanged from 0001571996-21-000026:notes:16]

[0001571996-21-000040:notes:19]
As of July 30, 2021 and January 29, 2021, the Company held private strategic investments of $1.2 billion and $1.0 billion, respectively.  As these investments represent early-stage companies without readily determinable fair values, they are not included in the recurring fair value table above.

[0001571996-21-000040:notes:20]
[same as prior period, unchanged from 0001571996-21-000026:notes:18]

[0001571996-21-000040:notes:21]
[same as prior period, unchanged from 0001571996-21-000026:notes:19]

[0001571996-21-000040:notes:22]
|  | July 30, 2021 |  | January 29, 2021 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Secured Credit Facilities | $ | 6.2 |  |  | $ | 6.3 |  |  | $ | 6.2 |  |  | $ | 6.3 |  |
| First Lien Notes | $ | 18.3 |  |  | $ | 23.1 |  |  | $ | 18.3 |  |  | $ | 22.8 |  |
| Unsecured Notes and Debentures | $ | 0.8 |  |  | $ | 1.2 |  |  | $ | 1.2 |  |  | $ | 1.6 |  |
| Senior Notes | $ | 1.6 |  |  | $ | 1.7 |  |  | $ | 2.7 |  |  | $ | 2.8 |  |
| EMC Notes | $ | 1.0 |  |  | $ | 1.0 |  |  | $ | 1.0 |  |  | $ | 1.0 |  |
| VMware Notes | $ | 4.7 |  |  | $ | 5.3 |  |  | $ | 4.7 |  |  | $ | 5.3 |  |
| Margin Loan Facility | $ | 1.0 |  |  | $ | 1.0 |  |  | $ | 4.0 |  |  | $ | 3.9 |  |

[0001571996-21-000040:notes:23]
The fair values of the outstanding debt shown in the table above, as well as the debt of Dell Financial Services and its affiliates (“DFS”) described in Note 3 of the Notes to the Condensed Consolidated Financial Statements, were determined based on observable market prices in a less active market or based on valuation methodologies using observable inputs and were categorized as Level 2 in the fair value hierarchy.  The carrying value of DFS debt approximates fair value.  Outstanding debt is recorded at carrying value and, as such, is not included in the recurring fair value table above.

[0001571996-21-000040:notes:24]
[same as prior period, unchanged from 0001571996-21-000026:notes:22]

[0001571996-21-000040:notes:25]
[same as prior period, unchanged from 0001571996-21-000026:notes:23]

[0001571996-21-000040:notes:26]
|  | July 30, 2021 |  | January 29, 2021 |
|  | Cost |  | Unrealized Gain |  | Unrealized (Loss) |  | Carrying Value |  | Cost |  | Unrealized Gain |  | Unrealized (Loss) |  | Carrying Value |
|  | (in millions) |
| Equity and other securities | $ | 1,312 |  |  | $ | 380 |  |  | $ | (150) |  |  | $ | 1,542 |  |  | $ | 907 |  |  | $ | 677 |  |  | $ | (145) |  |  | $ | 1,439 |  |
| Fixed income debt securities | 332 |  |  | 2 |  |  | (1) |  |  | 333 |  |  | 176 |  |  | 9 |  |  | — |  |  | 185 |  |
| Total securities |  |  |  |  |  |  | $ | 1,875 |  |  |  |  |  |  |  |  | $ | 1,624 |  |

[0001571996-21-000040:notes:27]
Equity and other securities — The Company has strategic investments in publicly-traded and privately-held companies.  For the six months ended July 30, 2021, the equity and other securities without readily determinable fair values of $1.2 billion increased by $340 million, primarily due to upward adjustments for observable price changes, partially offset by $26 million of downward adjustments that were primarily attributable to observable price changes.  The remainder of equity and other securities consists of publicly-traded investments that are measured at fair value on a recurring basis.

[0001571996-21-000040:notes:28]
[same as prior period, unchanged from 0001571996-21-000026:notes:26]


## dell:CreditLossFinancialInstrumentLeasesDebtVariableInterestEntitiesAndCustomerReceivablesSalesTextBlock

[0001571996-21-000040:notes:29]
NOTE 3 — FINANCIAL SERVICES

[0001571996-21-000040:notes:30]
The Company offers or arranges various financing options, services, and alternative payment structures for its customers in North America, Europe, Australia, and New Zealand through Dell Financial Services and its affiliates (“DFS”).  The Company also arranges financing for some of its customers in various countries where DFS does not currently operate as a captive enterprise.  The Company further strengthens customer relationships through flexible consumption models, which enable the Company to offer its customers the option to pay over time and, in certain cases, based on utilization, to provide them with financial flexibility to meet their changing technological requirements.  The key activities of DFS include originating, collecting, and servicing customer financing arrangements primarily related to the purchase or use of Dell Technologies products and services.  In some cases, DFS also offers financing on the purchase of third-party technology products that complement the Dell Technologies portfolio of products and services.  New financing originations were $1.9 billion and $2.6 billion for the three months ended July 30, 2021 and July 31, 2020, respectively, and $3.8 billion and $4.4 billion for the six months ended July 30, 2021 and July 31, 2020, respectively.

[0001571996-21-000040:notes:31]
The Company’s loan and lease arrangements with customers are aggregated into the following categories:

[0001571996-21-000040:notes:32]
Revolving loans — Revolving loans offered under private label credit financing programs provide qualified customers with a revolving credit line for the purchase of products and services offered by Dell Technologies.  These private label credit financing programs are referred to as Dell Preferred Account (“DPA”) and Dell Business Credit (“DBC”).  The DPA product is primarily offered to individual consumer customers, and the DBC product is primarily offered to small and medium-sized commercial customers.  Revolving loans in the United States bear interest at a variable annual percentage rate that is tied to the prime rate.  Based on historical payment patterns, revolving loan transactions are typically repaid within twelve months on average.  Due to the short-term nature of the revolving loan portfolio, the carrying value of the portfolio approximates fair value.

[0001571996-21-000040:notes:33]
Fixed-term leases and loans — The Company enters into financing arrangements with customers who seek lease financing for equipment.  DFS leases are classified as sales-type leases, direct financing leases, or operating leases.  Direct financing leases are immaterial.  Leases that commenced prior to the effective date of the current lease accounting standard continue to be accounted for under previous lease accounting guidance.  Leases with business customers have fixed terms of generally two to four years.

[0001571996-21-000040:notes:34]
The Company also offers fixed-term loans to qualified small businesses, large commercial accounts, governmental organizations, educational entities, and certain individual consumer customers.  These loans are repaid in equal payments including interest and have defined terms of generally three to five years.  The fair value of the fixed-term loan portfolio is determined using market observable inputs.  The carrying value of these loans approximates fair value.

[0001571996-21-000040:notes:35]
Financing Receivables

[0001571996-21-000040:notes:36]
The following table presents the components of the Company’s financing receivables segregated by portfolio segment as of the dates indicated:

[0001571996-21-000040:notes:37]
|  | July 30, 2021 |  | January 29, 2021 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Financing receivables, net: |  |  |  |  |  |  |  |  |  |  |  |
| Customer receivables, gross (a) | $ | 726 |  |  | $ | 9,527 |  |  | $ | 10,253 |  |  | $ | 796 |  |  | $ | 9,595 |  |  | $ | 10,391 |  |
| Allowances for losses | (126) |  |  | (161) |  |  | (287) |  |  | (148) |  |  | (173) |  |  | (321) |  |
| Customer receivables, net | 600 |  |  | 9,366 |  |  | 9,966 |  |  | 648 |  |  | 9,422 |  |  | 10,070 |  |
| Residual interest | — |  |  | 319 |  |  | 319 |  |  | — |  |  | 424 |  |  | 424 |  |
| Financing receivables, net | $ | 600 |  |  | $ | 9,685 |  |  | $ | 10,285 |  |  | $ | 648 |  |  | $ | 9,846 |  |  | $ | 10,494 |  |
| Short-term | $ | 600 |  |  | $ | 4,355 |  |  | $ | 4,955 |  |  | $ | 648 |  |  | $ | 4,507 |  |  | $ | 5,155 |  |
| Long-term | $ | — |  |  | $ | 5,330 |  |  | $ | 5,330 |  |  | $ | — |  |  | $ | 5,339 |  |  | $ | 5,339 |  |

[0001571996-21-000040:notes:38]
____________________

[0001571996-21-000040:notes:39]
(a)    Customer receivables, gross includes amounts due from customers under revolving loans, fixed-term loans, fixed-term sales-type or direct financing leases, and accrued interest.

[0001571996-21-000040:notes:40]
The following tables present the changes in allowance for financing receivable losses for the periods indicated:

[0001571996-21-000040:notes:41]
|  | Three Months Ended |
|  | July 30, 2021 |  | July 31, 2020 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |  |  |  |  |  |  |  |  |  |  |  |
| Balances at beginning of period | $ | 139 |  |  | $ | 177 |  |  | $ | 316 |  |  | $ | 144 |  |  | $ | 177 |  |  | $ | 321 |  |
| Charge-offs, net of recoveries | (10) |  |  | (3) |  |  | (13) |  |  | (18) |  |  | (7) |  |  | (25) |  |
| Provision charged to income statement | (3) |  |  | (13) |  |  | (16) |  |  | 17 |  |  | 10 |  |  | 27 |  |
| Balances at end of period | $ | 126 |  |  | $ | 161 |  |  | $ | 287 |  |  | $ | 143 |  |  | $ | 180 |  |  | $ | 323 |  |

[0001571996-21-000040:notes:42]
|  | Six Months Ended |
|  | July 30, 2021 |  | July 31, 2020 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |  |  |  |  |  |  |  |  |  |  |  |
| Balances at beginning of period | $ | 148 |  |  | $ | 173 |  |  | $ | 321 |  |  | $ | 70 |  |  | $ | 79 |  |  | $ | 149 |  |
| Adjustment for adoption of accounting standard | — |  |  | — |  |  | — |  |  | 40 |  |  | 71 |  |  | 111 |  |
| Charge-offs, net of recoveries | (23) |  |  | (5) |  |  | (28) |  |  | (38) |  |  | (16) |  |  | (54) |  |
| Provision charged to income statement | 1 |  |  | (7) |  |  | (6) |  |  | 71 |  |  | 46 |  |  | 117 |  |
| Balances at end of period | $ | 126 |  |  | $ | 161 |  |  | $ | 287 |  |  | $ | 143 |  |  | $ | 180 |  |  | $ | 323 |  |

[0001571996-21-000040:notes:43]
Aging

[0001571996-21-000040:notes:44]
The following table presents the aging of the Company’s customer financing receivables, gross, including accrued interest, segregated by class, as of the dates indicated:

[0001571996-21-000040:notes:45]
|  | July 30, 2021 |  | January 29, 2021 |
|  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |
|  | (in millions) |
| Revolving — DPA | $ | 515 |  |  | $ | 32 |  |  | $ | 8 |  |  | $ | 555 |  |  | $ | 578 |  |  | $ | 30 |  |  | $ | 13 |  |  | $ | 621 |  |
| Revolving — DBC | 155 |  |  | 13 |  |  | 3 |  |  | 171 |  |  | 157 |  |  | 14 |  |  | 4 |  |  | 175 |  |
| Fixed-term — Consumer and Commercial | 9,264 |  |  | 238 |  |  | 25 |  |  | 9,527 |  |  | 9,192 |  |  | 316 |  |  | 87 |  |  | 9,595 |  |
| Total customer receivables, gross | $ | 9,934 |  |  | $ | 283 |  |  | $ | 36 |  |  | $ | 10,253 |  |  | $ | 9,927 |  |  | $ | 360 |  |  | $ | 104 |  |  | $ | 10,391 |  |

[0001571996-21-000040:notes:46]
Aging is likely to fluctuate as a result of the variability in volume of large transactions entered into over the period, and the administrative processes that accompany those larger transactions.  Aging is also impacted by the timing of the Dell Technologies fiscal period end date, relative to calendar month-end customer payment due dates.  As a result of these factors, fluctuations in aging from period to period do not necessarily indicate a material change in the collectibility of the portfolio.

[0001571996-21-000040:notes:47]
Fixed-term consumer and commercial customer receivables are placed on non-accrual status if principal or interest is past due and considered delinquent, or if there is concern about collectibility of a specific customer receivable.  These receivables identified as doubtful for collectibility may be classified as current for aging purposes.  Aged revolving portfolio customer receivables identified as delinquent are charged off.  Receivables are moved back to accrual status when the collection of  interest is probable, or the collection of the net investment is no longer doubtful.

[0001571996-21-000040:notes:48]
Credit Quality

[0001571996-21-000040:notes:49]
The following tables present customer receivables, gross, including accrued interest, by credit quality indicator segregated by class and year of origination, as of the dates indicated:

[0001571996-21-000040:notes:50]
|  | July 30, 2021 |
|  | Fixed-term — Consumer and Commercial |  |  |  |  |  |  |
|  | Fiscal Year of Origination |  |  |  |  |  |  |
|  | 2022 |  | 2021 |  | 2020 |  | 2019 |  | 2018 |  | Years Prior |  | Revolving — DPA |  | Revolving — DBC |  | Total |
|  | (in millions) |
| Higher | $ | 1,806 |  |  | $ | 2,362 |  |  | $ | 1,330 |  |  | $ | 373 |  |  | $ | 73 |  |  | $ | 8 |  |  | $ | 149 |  |  | $ | 45 |  |  | $ | 6,146 |  |
| Mid | 520 |  |  | 925 |  |  | 487 |  |  | 162 |  |  | 32 |  |  | 1 |  |  | 172 |  |  | 52 |  |  | 2,351 |  |
| Lower | 376 |  |  | 634 |  |  | 327 |  |  | 92 |  |  | 17 |  |  | 2 |  |  | 234 |  |  | 74 |  |  | 1,756 |  |
| Total | $ | 2,702 |  |  | $ | 3,921 |  |  | $ | 2,144 |  |  | $ | 627 |  |  | $ | 122 |  |  | $ | 11 |  |  | $ | 555 |  |  | $ | 171 |  |  | $ | 10,253 |  |

[0001571996-21-000040:notes:51]
|  | January 29, 2021 |
|  | Fixed-term — Consumer and Commercial |  |  |  |  |  |  |
|  | Fiscal Year of Origination |  |  |  |  |  |  |
|  | 2021 |  | 2020 |  | 2019 |  | 2018 |  | 2017 |  | Years Prior |  | Revolving — DPA |  | Revolving — DBC |  | Total |
|  | (in millions) |
| Higher | $ | 3,125 |  |  | $ | 1,802 |  |  | $ | 661 |  |  | $ | 166 |  |  | $ | 26 |  |  | $ | — |  |  | $ | 172 |  |  | $ | 47 |  |  | $ | 5,999 |  |
| Mid | 1,121 |  |  | 671 |  |  | 287 |  |  | 73 |  |  | 9 |  |  | — |  |  | 188 |  |  | 52 |  |  | 2,401 |  |
| Lower | 865 |  |  | 499 |  |  | 243 |  |  | 38 |  |  | 9 |  |  | — |  |  | 261 |  |  | 76 |  |  | 1,991 |  |
| Total | $ | 5,111 |  |  | $ | 2,972 |  |  | $ | 1,191 |  |  | $ | 277 |  |  | $ | 44 |  |  | $ | — |  |  | $ | 621 |  |  | $ | 175 |  |  | $ | 10,391 |  |

[0001571996-21-000040:notes:52]
The categories shown in the tables above segregate customer receivables based on the relative degrees of credit risk.  The credit quality indicators for DPA revolving accounts are measured primarily as of each quarter-end date, while all other indicators are generally updated on a periodic basis.

[0001571996-21-000040:notes:53]
For DPA revolving receivables shown in the table above, the Company makes credit decisions based on proprietary scorecards, which include the customer’s credit history, payment history, credit usage, and other credit agency-related elements.  The higher quality category includes prime accounts generally of a higher credit quality that are comparable to U.S. customer FICO scores of 720 or above.  The mid-category represents the mid-tier accounts that are comparable to U.S. customer FICO scores from 660 to 719.  The lower category is generally sub-prime and represents lower credit quality accounts that are comparable to U.S. customer FICO scores below 660.  For the DBC revolving receivables and fixed-term commercial receivables shown in the table above, an internal grading system is utilized that assigns a credit level score based on a number of considerations, including liquidity, operating performance, and industry outlook.  The grading criteria and classifications for the fixed-term products differ from those for the revolving products as loss experience varies between these product and customer groups.  The credit quality categories cannot be compared between the different classes as loss experience varies substantially between the classes.

[0001571996-21-000040:notes:54]
Leases

[0001571996-21-000040:notes:55]
Interest income on sales-type lease receivables was $63 million and $66 million for the three months ended July 30, 2021 and July 31, 2020, respectively, and $127 million and $131 million for the six months ended July 30, 2021, and July 31, 2020, respectively.

[0001571996-21-000040:notes:56]
The following table presents the net revenue, cost of net revenue, and gross margin recognized at the commencement date of sales-type leases for the periods indicated:

[0001571996-21-000040:notes:57]
|  | Three Months Ended |  | Six Months Ended |
|  | July 30, 2021 |  | July 31, 2020 |  | July 30, 2021 |  | July 31, 2020 |
|  | (in millions) |
| Net revenue — products | $ | 194 |  |  | $ | 249 |  |  | $ | 424 |  |  | $ | 464 |  |
| Cost of net revenue — products | 142 |  |  | 174 |  |  | 305 |  |  | 333 |  |
| Gross margin — products | $ | 52 |  |  | $ | 75 |  |  | $ | 119 |  |  | $ | 131 |  |

[0001571996-21-000040:notes:58]
The following table presents the future maturity of the Company’s fixed-term customer leases and associated financing payments, and reconciles the undiscounted cash flows to the customer receivables, gross recognized on the Condensed Consolidated Statements of Financial Position as of the date indicated:

[0001571996-21-000040:notes:59]
|  | July 30, 2021 |
|  | (in millions) |
| Fiscal 2022 (remaining six months) | $ | 1,479 |  |
| Fiscal 2023 | 2,052 |  |
| Fiscal 2024 | 1,303 |  |
| Fiscal 2025 | 592 |  |
| Fiscal 2026 and beyond | 252 |  |
| Total undiscounted cash flows | 5,678 |  |
| Fixed-term loans | 4,493 |  |
| Revolving loans | 726 |  |
| Less: unearned income | (644) |  |
| Total customer receivables, gross | $ | 10,253 |  |

[0001571996-21-000040:notes:60]
Operating Leases

[0001571996-21-000040:notes:61]
The following table presents the components of the Company’s operating lease portfolio included in property, plant, and equipment, net as of the dates indicated:

[0001571996-21-000040:notes:62]
|  | July 30, 2021 |  | January 29, 2021 |
|  | (in millions) |
| Equipment under operating lease, gross | $ | 2,094 |  |  | $ | 1,746 |  |
| Less: accumulated depreciation | (657) |  |  | (432) |  |
| Equipment under operating lease, net | $ | 1,437 |  |  | $ | 1,314 |  |

[0001571996-21-000040:notes:63]
Operating lease income relating to lease payments was $167 million and $103 million for the three months ended July 30, 2021 and July 31, 2020, respectively, and $323 million and $190 million for the six months ended July 30, 2021, and July 31, 2020, respectively.  Depreciation expense was $127 million and $74 million for the three months ended July 30, 2021 and July 31, 2020, respectively, and $243 million and $136 million for the six months ended July 30, 2021, and July 31, 2020, respectively.

[0001571996-21-000040:notes:64]
The following table presents the future payments to be received by the Company as lessor in operating lease contracts as of the date indicated:

[0001571996-21-000040:notes:65]
|  | July 30, 2021 |
|  | (in millions) |
| Fiscal 2022 (remaining six months) | $ | 371 |  |
| Fiscal 2023 | 600 |  |
| Fiscal 2024 | 338 |  |
| Fiscal 2025 | 109 |  |
| Fiscal 2026 and beyond | 17 |  |
| Total | $ | 1,435 |  |

[0001571996-21-000040:notes:66]
DFS Debt

[0001571996-21-000040:notes:67]
The Company maintains programs that facilitate the funding of leases, loans, and other alternative payment structures in the capital markets.  The majority of DFS debt is non-recourse to Dell Technologies and represents borrowings under securitization programs and structured financing programs, for which the Company’s risk of loss is limited to transferred loan and lease payments and associated equipment.  The following table presents DFS debt as of the dates indicated.  The table excludes the allocated portion of the Company’s other borrowings, which represents the additional amount considered to fund the DFS business.

[0001571996-21-000040:notes:68]
|  | July 30, 2021 |  | January 29, 2021 |
|  | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing and securitization facilities | $ | 3,182 |  |  | $ | 3,311 |  |
| Fixed-term securitization offerings | 2,929 |  |  | 2,961 |  |
| Other | 176 |  |  | 140 |  |
| Total DFS U.S. debt | 6,287 |  |  | 6,412 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 768 |  |  | 786 |  |
| Other borrowings | 1,063 |  |  | 1,006 |  |
| Note payable | 250 |  |  | 250 |  |
| Dell Bank Senior Unsecured Eurobonds | 1,189 |  |  | 1,212 |  |
| Total DFS international debt | 3,270 |  |  | 3,254 |  |
| Total DFS debt | $ | 9,557 |  |  | $ | 9,666 |  |
| Total short-term DFS debt | $ | 5,281 |  |  | $ | 4,888 |  |
| Total long-term DFS debt | $ | 4,276 |  |  | $ | 4,778 |  |

[0001571996-21-000040:notes:69]
DFS U.S. Debt

[0001571996-21-000040:notes:70]
Asset-Based Financing and Securitization Facilities — The Company maintains separate asset-based financing facilities and a securitization facility in the United States, which are revolving facilities for fixed-term leases and loans and for revolving loans, respectively.  This debt is collateralized solely by the U.S. loan and lease payments and associated equipment in the facilities.  The debt has a variable interest rate and the duration of the debt is based on the terms of the underlying loan and lease payment streams.  As of July 30, 2021, the total debt capacity related to the U.S. asset-based financing and securitization facilities was $4.5 billion.  The Company enters into interest swap agreements to effectively convert a portion of this debt from a floating rate to a fixed rate.  See Note 6 of the Notes to the Condensed Consolidated Financial Statements for additional information about interest rate swaps.

[0001571996-21-000040:notes:71]
The Company’s U.S. securitization facility for revolving loans is effective through June 25, 2022.  The Company’s two U.S. asset-based financing facilities for fixed-term leases and loans are effective through July 10, 2023 and July 26, 2022, respectively.

[0001571996-21-000040:notes:72]
The asset-based financing and securitization facilities contain standard structural features related to the performance of the funded receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the facility, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of July 30, 2021, these criteria were met.

[0001571996-21-000040:notes:73]
Fixed-Term Securitization Offerings — The Company periodically issues asset-backed debt securities under fixed-term securitization programs to private investors.  The asset-backed debt securities are collateralized solely by the U.S. fixed-term leases and loans in the offerings, which are held by Special Purpose Entities (“SPEs”), as discussed below.  The interest rate on these securities is fixed and ranges from 0.21% to 5.92% per annum, and the duration of these securities is based on the terms of the underlying loan and lease payment streams.

[0001571996-21-000040:notes:74]
DFS International Debt

[0001571996-21-000040:notes:75]
Securitization Facility — The Company maintains a securitization facility in Europe for fixed-term leases and loans.  This facility is effective through December 21, 2022 and had a total debt capacity of $951 million as of July 30, 2021.

[0001571996-21-000040:notes:76]
The securitization facility contains standard structural features related to the performance of the securitized receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the program, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of July 30, 2021, these criteria were met.

[0001571996-21-000040:notes:77]
Other Borrowings — In connection with the Company’s international financing operations, the Company enters into revolving structured financing debt programs related to its fixed-term lease and loan products sold in Canada, Europe, Australia, and New Zealand.  The Canadian facility, which is collateralized solely by Canadian loan and lease payments and associated equipment, had a total debt capacity of $362 million as of July 30, 2021, and is effective through January 16, 2025.  The European facility, which is collateralized solely by European loan and lease payments and associated equipment, had a total debt capacity of $713 million as of July 30, 2021, and is effective through December 14, 2023.  The Australia and New Zealand facility, which is collateralized solely by Australia and New Zealand loan and lease payments and associated equipment, had a total debt capacity of $333 million as of July 30, 2021, and is effective through April 20, 2023.

[0001571996-21-000040:notes:78]
Note Payable — On August 7, 2020, the Company entered into two new unsecured credit agreements to fund receivables in Mexico.  As of July 30, 2021, the aggregate principal amount of the notes payable was $250 million.  The notes bear interest at an annual rate of 3.37% and will mature on June 1, 2022.

[0001571996-21-000040:notes:79]
Dell Bank Senior Unsecured Eurobonds — On October 17, 2019, Dell Bank International D.A.C., a wholly-owned subsidiary of Dell Technologies Inc., issued 500 million Euro of 0.625% senior unsecured three year eurobonds due October 2022.  On June 24, 2020, Dell Bank International D.A.C. issued an additional 500 million Euro of 1.625% senior unsecured four year eurobonds due June 2024.  The issuances of the senior unsecured eurobonds support the expansion of the financing operations in Europe.

[0001571996-21-000040:notes:80]
Variable Interest Entities

[0001571996-21-000040:notes:81]
In connection with the asset-based financing facilities, securitization facilities, and fixed-term securitization offerings discussed above, the Company transfers certain U.S. and European loan and lease payments and associated equipment to SPEs that meet the definition of a Variable Interest Entity (“VIE”) and are consolidated, along with the associated debt detailed above, into the Condensed Consolidated Financial Statements, as the Company is the primary beneficiary of those VIEs.  The SPEs are bankruptcy-remote legal entities with separate assets and liabilities.  The purpose of the SPEs is to facilitate the funding of customer loan and lease payments and associated equipment in the capital markets.

[0001571996-21-000040:notes:82]
Some of the SPEs have entered into financing arrangements with multi-seller conduits that, in turn, issue asset-backed debt securities in the capital markets. DFS debt outstanding held by the consolidated VIEs is collateralized by the loan and lease payments and associated equipment. The Company’s risk of loss related to securitized receivables is limited to the amount by which the Company’s right to receive collections for assets securitized exceeds the amount required to pay interest, principal, and fees and expenses related to the asset-backed securities. The Company provides credit enhancement to the securitization in the form of over-collateralization.

[0001571996-21-000040:notes:83]
The following table presents financing receivables and equipment under operating leases, net held by the consolidated VIEs as of the dates indicated:

[0001571996-21-000040:notes:84]
|  | July 30, 2021 |  | January 29, 2021 |
|  | (in millions) |
| Assets held by consolidated VIEs |  |  |  |
| Other current assets | $ | 770 |  |  | $ | 838 |  |
| Financing receivables, net of allowance |  |  |  |
| Short-term | $ | 3,457 |  |  | $ | 3,534 |  |
| Long-term | $ | 3,229 |  |  | $ | 3,314 |  |
| Property, plant, and equipment, net | $ | 838 |  |  | $ | 792 |  |
| Liabilities held by consolidated VIEs |  |  |  |
| Debt, net of unamortized debt issuance costs |  |  |  |
| Short-term | $ | 4,472 |  |  | $ | 4,208 |  |
| Long-term | $ | 2,398 |  |  | $ | 2,841 |  |

[0001571996-21-000040:notes:85]
Loan and lease payments and associated equipment transferred via securitization through SPEs were $1.3 billion and $1.2 billion for the three months ended July 30, 2021 and July 31, 2020, respectively, and $2.7 billion and $3.0 billion for the six months ended July 30, 2021 and July 31, 2020, respectively.

[0001571996-21-000040:notes:86]
Customer Receivables Sales
To manage certain concentrations of customer credit exposure, the Company may sell selected fixed-term customer receivables to unrelated third parties on a periodic basis, without recourse.  The amount of customer receivables sold for this purpose was $101 million and $228 million for the six months ended July 30, 2021 and July 31, 2020, respectively.  The Company’s continuing involvement in such customer receivables is primarily limited to servicing arrangements.  The transactions are accounted for as sales and, accordingly, the customer receivables are derecognized from the Condensed Consolidated Statements of Financial Position at the time of sale.


## us-gaap:ScheduleOfDebtTableTextBlock

[0001571996-21-000040:notes:87]
The following table presents DFS debt as of the dates indicated.  The table excludes the allocated portion of the Company’s other borrowings, which represents the additional amount considered to fund the DFS business.

[0001571996-21-000040:notes:88]
The following table presents the Company’s outstanding debt as of the dates indicated:

[0001571996-21-000040:notes:89]
|  | July 30, 2021 |  | January 29, 2021 |
|  | (in millions) |
| Secured Debt |  |  |  |
| Senior Secured Credit Facilities: |  |  |  |
| 2.00% Term Loan B-2 Facility due September 2025 | $ | 3,127 |  |  | $ | 3,143 |  |
| 1.86% Term Loan A-6 Facility due March 2024 | 3,134 |  |  | 3,134 |  |
| First Lien Notes: |  |  |  |
| 5.45% due June 2023 | 3,750 |  |  | 3,750 |  |
| 4.00% due July 2024 | 1,000 |  |  | 1,000 |  |
| 5.85% due July 2025 | 1,000 |  |  | 1,000 |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 4.90% due October 2026 | 1,750 |  |  | 1,750 |  |
| 6.10% due July 2027 | 500 |  |  | 500 |  |
| 5.30% due October 2029 | 1,750 |  |  | 1,750 |  |
| 6.20% due July 2030 | 750 |  |  | 750 |  |
| 8.10% due July 2036 | 1,500 |  |  | 1,500 |  |
| 8.35% due July 2046 | 2,000 |  |  | 2,000 |  |
| Unsecured Debt |  |  |  |
| Unsecured Notes and Debentures: |  |  |  |
| 4.625% due April 2021 | — |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| Senior Notes: |  |  |  |
| 5.875% due June 2021 | — |  |  | 1,075 |  |
| 7.125% due June 2024 | 1,625 |  |  | 1,625 |  |
| EMC Notes: |  |  |  |
| 3.375% due June 2023 | 1,000 |  |  | 1,000 |  |
| Debt of Public Subsidiary |  |  |  |
| VMware Notes: |  |  |  |
| 2.95% due August 2022 | 1,500 |  |  | 1,500 |  |
| 4.50% due May 2025 | 750 |  |  | 750 |  |
| 4.65% due May 2027 | 500 |  |  | 500 |  |
| 3.90% due August 2027 | 1,250 |  |  | 1,250 |  |
| 4.70% due May 2030 | 750 |  |  | 750 |  |
| DFS Debt (Note 3) | 9,557 |  |  | 9,666 |  |
| Other |  |  |  |
| 2.44% Margin Loan Facility due April 2022 | 1,000 |  |  | 4,000 |  |
| Other | 392 |  |  | 235 |  |
| Total debt, principal amount | $ | 44,037 |  |  | $ | 48,480 |  |

[0001571996-21-000040:notes:90]
|  | July 30, 2021 |  | January 29, 2021 |
|  | (in millions) |
| Total debt, principal amount | $ | 44,037 |  |  | $ | 48,480 |  |
| Unamortized discount, net of unamortized premium | (174) |  |  | (194) |  |
| Debt issuance costs | (269) |  |  | (302) |  |
| Total debt, carrying value | $ | 43,594 |  |  | $ | 47,984 |  |
| Total short-term debt, carrying value | $ | 6,427 |  |  | $ | 6,362 |  |
| Total long-term debt, carrying value | $ | 37,167 |  |  | $ | 41,622 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0001571996-21-000040:notes:91]
[same as prior period, unchanged from 0001571996-21-000026:notes:91]

[0001571996-21-000040:notes:92]
The Company enters into leasing transactions in which the Company is the lessee.  These lease contracts are typically classified as operating leases.  The Company’s lease contracts are generally for office buildings used to conduct its business, and the determination of whether such contracts contain leases generally does not require significant estimates or judgments.  The Company also leases certain global logistics warehouses, employee vehicles, and equipment.  As of July 30, 2021, the remaining terms of the Company’s leases range from less than one month to approximately 25 years.

[0001571996-21-000040:notes:93]
[same as prior period, unchanged from 0001571996-21-000026:notes:93]

[0001571996-21-000040:notes:94]
Financial information associated with the Company’s leases in which the Company is the lessee is contained in this Note.  As of both July 30, 2021 and January 29, 2021, there were no material finance leases for which the Company was a lessee.

[0001571996-21-000040:notes:95]
[same as prior period, unchanged from 0001571996-21-000026:notes:95]

[0001571996-21-000040:notes:96]
|  | Three Months Ended |  | Six Months Ended |
|  | July 30, 2021 |  | July 31, 2020 |  | July 30, 2021 |  | July 31, 2020 |
|  | (in millions) |
| Operating lease costs | $ | 133 |  |  | $ | 124 |  |  | $ | 275 |  |  | $ | 255 |  |
| Variable costs | 29 |  |  | 32 |  |  | 62 |  |  | 76 |  |
| Total lease costs | $ | 162 |  |  | $ | 156 |  |  | $ | 337 |  |  | $ | 331 |  |

[0001571996-21-000040:notes:97]
During both the six months ended July 30, 2021 and July 31, 2020, sublease income, finance lease costs, and short-term lease costs were immaterial.

[0001571996-21-000040:notes:98]
[same as prior period, unchanged from 0001571996-21-000026:notes:98]

[0001571996-21-000040:notes:99]
|  | Classification | July 30, 2021 |  | January 29, 2021 |  |  |
|  |  | (in millions, except for term and discount rate) |
| Operating lease right of use assets | Other non-current assets | $ | 2,044 |  | $ | 2,117 |  |  |
| Current operating lease liabilities | Accrued and other current liabilities | $ | 443 |  | $ | 436 |  |  |
| Non-current operating lease liabilities | Other non-current liabilities | 1,746 |  | 1,787 |  |  |
| Total operating lease liabilities |  | $ | 2,189 |  | $ | 2,223 |  |  |
| Weighted-average remaining lease term (in years) |  | 8.70 |  | 8.85 |  |  |
| Weighted-average discount rate |  | 3.34 | % |  | 3.47 | % |  |  |

[0001571996-21-000040:notes:100]
[same as prior period, unchanged from 0001571996-21-000026:notes:100]

[0001571996-21-000040:notes:101]
|  | Six Months Ended |
|  | July 30, 2021 |  | July 31, 2020 |
|  | (in millions) |
| Cash paid for amounts included in the measurement of lease liabilities — operating cash outflows from operating leases | $ | 257 |  |  | $ | 255 |  |
| ROU assets obtained in exchange for new operating lease liabilities | $ | 203 |  |  | $ | 255 |  |

[0001571996-21-000040:notes:102]
[same as prior period, unchanged from 0001571996-21-000026:notes:102]

[0001571996-21-000040:notes:103]
|  | July 30, 2021 |  |  |
|  | (in millions) |
| Fiscal 2022 (remaining six months) | $ | 235 |  |  |  |
| Fiscal 2023 | 470 |  |  |  |
| Fiscal 2024 | 362 |  |  |  |
| Fiscal 2025 | 274 |  |  |  |
| Fiscal 2026 | 227 |  |  |  |
| Thereafter | 1,022 |  |  |  |
| Total lease payments | 2,590 |  |  |  |
| Less: Imputed interest | (401) |  |  |  |
| Total | $ | 2,189 |  |  |  |
| Current operating lease liabilities | $ | 443 |  |  |  |
| Non-current operating lease liabilities | $ | 1,746 |  |  |  |

[0001571996-21-000040:notes:104]
[same as prior period, unchanged from 0001571996-21-000026:notes:104]

[0001571996-21-000040:notes:105]
As of July 30, 2021, the Company has additional operating leases that have not yet commenced of $71 million.  These operating leases will commence during Fiscal 2022 with lease terms of one year to 10 years.


## us-gaap:DebtDisclosureTextBlock

[0001571996-21-000040:notes:106]
NOTE 5 — DEBT

[0001571996-21-000040:notes:107]
During the six months ended July 30, 2021, the net decrease in the Company’s debt balance was primarily due to:

[0001571996-21-000040:notes:108]
•repayment of $3.0 billion principal amount of the Margin Loan Facility due April 2022;

[0001571996-21-000040:notes:109]
•repayment of $1,075 million principal amount of the 5.875% Senior Notes due June 2021; and

[0001571996-21-000040:notes:110]
•repayment of $400 million principal amount of the 4.625% Unsecured Notes due April 2021.

[0001571996-21-000040:notes:111]
Secured Debt

[0001571996-21-000040:notes:112]
Senior Secured Credit Facilities — The Company has entered into a credit agreement that provides for senior secured credit facilities (the “Senior Secured Credit Facilities”) comprising (a) term loan facilities and (b) a senior secured Revolving Credit Facility, which provides for a borrowing capacity of up to $4.5 billion for general corporate purposes, including capacity for up to $0.5 billion of letters of credit and for borrowings of up to $0.4 billion under swing-line loans.  The Revolving Credit Facility expires December 20, 2023.

[0001571996-21-000040:notes:113]
As of July 30, 2021, available borrowings under the Revolving Credit Facility totaled $4.5 billion.  The Senior Secured Credit Facilities provide that the borrowers have the right at any time, subject to customary conditions, to request incremental term loans or incremental revolving commitments.

[0001571996-21-000040:notes:114]
On February 18, 2021, the Company entered into an eighth refinancing amendment to the credit agreement for the Senior Secured Credit Facilities to refinance the existing term B loans (the “Original Term B Loans”) with a new term loan B facility consisting of an aggregate principal amount of $3,143 million refinancing term B-2 loans (the “Refinancing Term B-2 Loans”) maturing on September 19, 2025.  Proceeds from the Refinancing Term B-2 Loans, together with other funds available to the borrowers, were used to repay in full the Original Term B Loans and all accrued and unpaid fees in respect thereof.

[0001571996-21-000040:notes:115]
Except for a change in the interest rate, the Refinancing Term B-2 Loans have substantially the same terms as the Original Term B Loans under the sixth refinancing amendment to the Senior Secured Credit Agreement.  Amortization payments on the Refinancing Term B-2 Loans are equal to 0.25% of the aggregate principal amount of Refinancing Term B-2 Loans outstanding on the effective date of the eighth refinancing amendment, payable at the end of each fiscal quarter, commencing with the fiscal quarter ended April 30, 2021.

[0001571996-21-000040:notes:116]
Borrowings under the Senior Secured Credit Facilities bear interest at a rate per annum equal to an applicable margin, plus, at the borrowers’ option, either (a) a base rate, or (b) the London Interbank Offered Rate (“LIBOR”).  The Term Loan A-6 Facility bears interest at LIBOR plus an applicable margin ranging from 1.25% to 2.00% or a base rate plus an applicable margin ranging from 0.25% to 1.00%.  The Refinancing Term B-2 Loans bear interest at LIBOR plus an applicable margin of 1.75% or a base rate plus an applicable margin of 0.75%.  Interest is payable, in the case of loans bearing interest based on LIBOR, at the end of each interest period (but at least every three months), in arrears and, in the case of loans bearing interest based on the base rate, quarterly in arrears.

[0001571996-21-000040:notes:117]
The Term Loan A-6 Facility amortizes in equal quarterly installments in aggregate annual amounts equal to 5% of the original principal amount in each of the first four years after the facility closing date of March 13, 2019, and 80% of the original principal amount in the fifth year after March 13, 2019.  The Revolving Credit Facility has no amortization.

[0001571996-21-000040:notes:118]
The borrowers may voluntarily repay outstanding loans under the term loan facilities and the Revolving Credit Facility at any time without premium or penalty, other than customary “breakage” costs.

[0001571996-21-000040:notes:119]
All obligations of the borrowers under the Senior Secured Credit Facilities and certain swap agreements, cash management arrangements, and certain letters of credit provided by any lender or agent party to the Senior Secured Credit Facilities or any of its affiliates and certain other persons are secured by (a) a first-priority security interest in certain tangible and intangible assets of the borrowers and the guarantors and (b) a first-priority pledge of 100% of the capital stock of the borrowers, Dell Inc., a wholly-owned subsidiary of the Company (“Dell”), and each wholly-owned material restricted subsidiary of the borrowers and the guarantors, in each case subject to certain thresholds, exceptions, and permitted liens.

[0001571996-21-000040:notes:120]
First Lien Notes — Dell International L.L.C. and EMC Corporation (collectively, the “Issuers”), both of which are wholly-owned subsidiaries of Dell Technologies Inc., completed offerings of multiple series of senior secured notes (collectively, the “First Lien Notes”) pursuant to Rule 144A and Regulation S. Various series of the First Lien Notes were issued on June 1, 2016, March 20, 2019, and April 9, 2020 in aggregate principal amounts of $20.0 billion, $4.5 billion, and $2.25 billion, respectively.  Interest on the First Lien Notes is payable semiannually.  The First Lien Notes are secured on an equal and ratable basis with the Senior Secured Credit Facilities by substantially all of the tangible and intangible assets of the issuers and guarantors that secure obligations under the Senior Secured Credit Facilities, including pledges of all capital stock of the issuers, Dell, and certain wholly-owned material subsidiaries of the issuers and the guarantors, subject to certain exceptions.

[0001571996-21-000040:notes:121]
In June 2021, Dell International L.L.C and EMC Corporation completed the previously announced offers to exchange any and all outstanding First Lien Notes for registered first lien notes having terms substantially identical to the terms of the First Lien Notes.  The Issuers issued an aggregate $18.4 billion principal amount of registered first lien notes in exchange for the same principal amount of First Lien Notes.  As of July 30, 2021, the aggregate principal amount of unregistered First Lien Notes remaining outstanding following the settlement of the exchange offers was approximately $0.1 billion.  Following the exchange

[0001571996-21-000040:notes:122]
offer, such registered first lien notes, together with the remaining unregistered First Lien Notes, are collectively referred to as “First Lien Notes” in these Notes to the Condensed Consolidated Financial Statements.

[0001571996-21-000040:notes:123]
Unsecured Debt

[0001571996-21-000040:notes:124]
Unsecured Notes and Debentures — The Company has outstanding unsecured notes and debentures (collectively, the “Unsecured Notes and Debentures”) that were issued by Dell prior to the acquisition of Dell by Dell Technologies Inc. in the going-private transaction that closed in October 2013.  Interest on outstanding borrowings is payable semiannually.

[0001571996-21-000040:notes:125]
Senior Notes — The senior unsecured notes (collectively, the “Senior Notes”) were issued on June 22, 2016 in an aggregate principal amount of $3.25 billion.  Interest on outstanding borrowings is payable semiannually.

[0001571996-21-000040:notes:126]
EMC Notes — On September 7, 2016, as result of the merger with EMC, Dell acquired multiple outstanding Notes (collectively, the “EMC Notes”), of which $1.0 billion aggregate principal amount of its 3.375% Note remains.  Interest on the outstanding borrowing is payable semiannually.

[0001571996-21-000040:notes:127]
VMware Notes — VMware, Inc. completed public offerings of unsecured senior notes in the aggregate amounts of $4.0 billion and $2.0 billion on August 21, 2017 and April 7, 2020, respectively (the “VMware Notes”).  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.  Interest on outstanding borrowings is payable semiannually.  Subsequent to July 30, 2021, VMware, Inc. issued five series of unsecured senior notes (the “2021 VMware Notes”) in the aggregate principal amount of $6.0 billion pursuant to a public offering.  See Note 18 of the Notes to the Condensed Consolidated Financial Statements for more information about issuance of the 2021 VMware Notes.

[0001571996-21-000040:notes:128]
VMware Revolving Credit Facility — On September 12, 2017, VMware, Inc. entered into an unsecured credit agreement, establishing a revolving credit facility (the “VMware Revolving Credit Facility”) with a syndicate of lenders that provides the company with a borrowing capacity of up to $1.0 billion for VMware, Inc. general corporate purposes.  Commitments under the VMware Revolving Credit Facility are available for a period of five years, expiring September 12, 2022 and may be extended, subject to the satisfaction of certain conditions, by up to two one year periods.  The credit agreement contains certain representations, warranties, and covenants.  Commitment fees, interest rates, and other terms of borrowing under the VMware Revolving Credit Facility may vary based on VMware, Inc.’s external credit ratings.  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.  As of July 30, 2021, there were no outstanding borrowings under the VMware Revolving Credit Facility.

[0001571996-21-000040:notes:129]
See Note 3 and Note 6 of the Notes to the Condensed Consolidated Financial Statements, respectively, for discussion of DFS debt and the interest rate swap agreements that hedge a portion of that debt.

[0001571996-21-000040:notes:130]
Other

[0001571996-21-000040:notes:131]
Margin Loan Facility — On April 12, 2017, the Company entered into the Margin Loan Facility in an aggregate principal amount of $2.0 billion.  In connection with the Class V transaction described in Note 1 of the Notes to the Condensed Consolidated Financial Statements, on December 20, 2018, the Company amended the Margin Loan Facility to increase the aggregate principal amount to $3.35 billion.  In connection with obtaining the Term Loan A-6 Facility during the fiscal year ended January 31, 2020, the Company increased the aggregate principal amount of the Margin Loan Facility to $4.0 billion. VMware Holdco LLC, a wholly-owned subsidiary of EMC, is the borrower under the Margin Loan Facility, which is secured by approximately 76 million shares of Class B common stock of VMware, Inc. and approximately 24 million shares of Class A common stock of VMware, Inc.

[0001571996-21-000040:notes:132]
Loans under the Margin Loan Facility bear interest at a rate per annum payable, at the borrower’s option, either at (a) a base rate plus 1.25% per annum or (b) a LIBOR-based rate plus 2.25% per annum.  Interest under the Margin Loan Facility is payable quarterly.  The Margin Loan Facility will mature in April 2022.  The borrower may voluntarily repay outstanding loans under the Margin Loan Facility at any time without premium or penalty, other than customary “breakage” costs, subject to certain minimum threshold amounts for prepayment.  During the three months ended July 30, 2021, the Company repaid $3.0 billion principal amount of the Margin Loan Facility.  Subsequent to July 30, 2021, the Company repaid the remaining $1.0 billion principal amount of the Margin Loan Facility.  See Note 18 of the Notes to the Condensed Consolidated Financial Statements for more information about the Margin Loan Facility principal repayment, subsequent to July 30, 2021.

[0001571996-21-000040:notes:133]
Aggregate Future Maturities

[0001571996-21-000040:notes:134]
The following table presents the aggregate future maturities of the Company’s debt as of July 30, 2021 for the periods indicated:

[0001571996-21-000040:notes:135]
|  | Maturities by Fiscal Year |
|  | 2022(remaining six months) |  | 2023 |  | 2024 |  | 2025 |  | 2026 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Secured Credit Facilities and First Lien Notes | $ | 16 |  |  | $ | 213 |  |  | $ | 6,007 |  |  | $ | 1,758 |  |  | $ | 4,017 |  |  | $ | 12,750 |  |  | $ | 24,761 |  |
| Unsecured Notes and Debentures | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 952 |  |  | 952 |  |
| Senior Notes and EMC Notes | — |  |  | — |  |  | 1,000 |  |  | 1,625 |  |  | — |  |  | — |  |  | 2,625 |  |
| VMware Notes | — |  |  | 1,500 |  |  | — |  |  | — |  |  | 750 |  |  | 2,500 |  |  | 4,750 |  |
| DFS Debt | 2,752 |  |  | 4,463 |  |  | 1,454 |  |  | 851 |  |  | 37 |  |  | — |  |  | 9,557 |  |
| Margin Loan Facility | — |  |  | 1,000 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 1,000 |  |
| Other | 27 |  |  | 33 |  |  | 190 |  |  | 94 |  |  | 24 |  |  | 24 |  |  | 392 |  |
| Total maturities, principal amount | 2,795 |  |  | 7,209 |  |  | 8,651 |  |  | 4,328 |  |  | 4,828 |  |  | 16,226 |  |  | 44,037 |  |
| Associated carrying value adjustments | (3) |  |  | (5) |  |  | (27) |  |  | (65) |  |  | (45) |  |  | (298) |  |  | (443) |  |
| Total maturities, carrying value amount | $ | 2,792 |  |  | $ | 7,204 |  |  | $ | 8,624 |  |  | $ | 4,263 |  |  | $ | 4,783 |  |  | $ | 15,928 |  |  | $ | 43,594 |  |

[0001571996-21-000040:notes:136]
Covenants and Unrestricted Net Assets — The credit agreement for the Senior Secured Credit Facilities contains customary negative covenants that generally limit the ability of Denali Intermediate Inc., a wholly-owned subsidiary of Dell Technologies (“Denali Intermediate”), Dell, and Dell’s and Denali Intermediate’s other restricted subsidiaries to incur debt, create liens, make fundamental changes, enter into asset sales, make certain investments, pay dividends or distribute or redeem certain equity interests, prepay or redeem certain debt, and enter into certain transactions with affiliates.  The indenture governing the Senior Notes contains customary negative covenants that generally limit the ability of Denali Intermediate, Dell, and Dell’s and Denali Intermediate’s other restricted subsidiaries to incur additional debt or issue certain preferred shares, pay dividends on or make other distributions in respect of capital stock or make other restricted payments, make certain investments, sell or transfer certain assets, create liens on certain assets to secure debt, consolidate, merge, sell, or otherwise dispose of all or substantially all assets, enter into certain transactions with affiliates, and designate subsidiaries as unrestricted subsidiaries.  The negative covenants under such credit agreements and indenture are subject to certain exceptions, qualifications, and “baskets.”  The indentures governing the First Lien Notes, the Unsecured Notes and Debentures, and the EMC Notes variously impose limitations, subject to specified exceptions, on creating certain liens, entering into sale and lease-back transactions, and entering into certain asset sales.  The foregoing credit agreements and indentures contain customary events of default, including failure to make required payments, failure to comply with covenants, and the occurrence of certain events of bankruptcy and insolvency.

[0001571996-21-000040:notes:137]
As of July 30, 2021, the Company had certain consolidated subsidiaries that were designated as unrestricted subsidiaries for all purposes of the applicable credit agreements and the indentures governing the First Lien Notes and the Senior Notes.  Substantially all of the net assets of the Company’s consolidated subsidiaries were restricted, with the exception of the Company’s unrestricted subsidiaries, primarily VMware, Inc., Secureworks, and their respective subsidiaries, as of July 30, 2021.

[0001571996-21-000040:notes:138]
The Senior Secured Credit Facilities and the Revolving Credit Facility are subject to a first lien leverage ratio covenant that is tested at the end of each fiscal quarter of Dell with respect to Dell’s preceding four fiscal quarters.  The Company was in compliance with all financial covenants as of July 30, 2021.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001571996-21-000040:notes:139]
[same as prior period, unchanged from 0001571996-21-000026:notes:138]

[0001571996-21-000040:notes:140]
[same as prior period, unchanged from 0001571996-21-000026:notes:139]

[0001571996-21-000040:notes:141]
[same as prior period, unchanged from 0001571996-21-000026:notes:140]

[0001571996-21-000040:notes:142]
[same as prior period, unchanged from 0001571996-21-000026:notes:141]

[0001571996-21-000040:notes:143]
[same as prior period, unchanged from 0001571996-21-000026:notes:142]

[0001571996-21-000040:notes:144]
During the three and six months ended July 30, 2021 and July 31, 2020, the Company did not discontinue any cash flow hedges related to foreign exchange contracts that had a material impact on the Company’s results of operations due to the probability that the forecasted cash flows would not occur.

[0001571996-21-000040:notes:145]
[same as prior period, unchanged from 0001571996-21-000026:notes:144]

[0001571996-21-000040:notes:146]
[same as prior period, unchanged from 0001571996-21-000026:notes:145]

[0001571996-21-000040:notes:147]
[same as prior period, unchanged from 0001571996-21-000026:notes:146]

[0001571996-21-000040:notes:148]
[same as prior period, unchanged from 0001571996-21-000026:notes:147]

[0001571996-21-000040:notes:149]
[same as prior period, unchanged from 0001571996-21-000026:notes:148]

[0001571996-21-000040:notes:150]
[same as prior period, unchanged from 0001571996-21-000026:notes:149]

[0001571996-21-000040:notes:151]
[same as prior period, unchanged from 0001571996-21-000026:notes:150]

[0001571996-21-000040:notes:152]
[same as prior period, unchanged from 0001571996-21-000026:notes:151]

[0001571996-21-000040:notes:153]
|  | July 30, 2021 |  | January 29, 2021 |
|  | (in millions) |
| Foreign exchange contracts: |  |  |  |
| Designated as cash flow hedging instruments | $ | 7,933 |  |  | $ | 6,840 |  |
| Non-designated as hedging instruments | 9,818 |  |  | 9,890 |  |
| Total | $ | 17,751 |  |  | $ | 16,730 |  |
| Interest rate contracts: |  |  |  |
| Non-designated as hedging instruments | $ | 6,115 |  |  | $ | 5,859 |  |

[0001571996-21-000040:notes:154]
[same as prior period, unchanged from 0001571996-21-000026:notes:153]

[0001571996-21-000040:notes:155]
| Derivatives in Cash Flow Hedging Relationships |  | Gain (Loss) Recognized in Accumulated OCI, Net of Tax, on Derivatives |  | Location of Gain (Loss) Reclassified from Accumulated OCI into Income |  | Gain (Loss) Reclassified from Accumulated OCI into Income |  |  |  |  |
|  |  | (in millions) |  |  |  | (in millions) |  |  |  |  |
| For the three months ended July 30, 2021 |  |  |  |  |
|  |  |  |  | Total net revenue |  | $ | (6) |  |  |  |  |  |
| Foreign exchange contracts |  | $ | 65 |  |  | Total cost of net revenue |  | (7) |  |  |  |  |  |
| Interest rate contracts |  | — |  |  | Interest and other, net |  | — |  |  |  |  |  |
| Total |  | $ | 65 |  |  |  |  | $ | (13) |  |  |  |  |  |
| For the three months ended July 31, 2020 |  |  |  |  |
|  |  |  |  | Total net revenue |  | $ | 9 |  |  |  |  |  |
| Foreign exchange contracts |  | $ | (257) |  |  | Total cost of net revenue |  | (1) |  |  |  |  |  |
| Interest rate contracts |  | — |  |  | Interest and other, net |  | — |  |  |  |  |  |
| Total |  | $ | (257) |  |  |  |  | $ | 8 |  |  |  |  |  |
| For the six months ended July 30, 2021 |  |  |  |  |
|  |  |  |  | Total net revenue |  | $ | (35) |  |  |  |  |  |
| Foreign exchange contracts |  | $ | 64 |  |  | Total cost of net revenue |  | (5) |  |  |  |  |  |
| Interest rate contracts |  | — |  |  | Interest and other, net |  | — |  |  |  |  |  |
| Total |  | $ | 64 |  |  |  |  | $ | (40) |  |  |  |  |  |
| For the six months ended July 31, 2020 |  |  |  |  |
|  |  |  |  | Total net revenue |  | $ | 105 |  |  |  |  |  |
| Foreign exchange contracts |  | $ | (90) |  |  | Total cost of net revenue |  | 3 |  |  |  |  |  |
| Interest rate contracts |  | — |  |  | Interest and other, net |  | — |  |  |  |  |  |
| Total |  | $ | (90) |  |  |  |  | $ | 108 |  |  |  |  |  |

[0001571996-21-000040:notes:156]
[same as prior period, unchanged from 0001571996-21-000026:notes:155]

[0001571996-21-000040:notes:157]
|  |  | Three Months Ended |  |  | Six Months Ended |  |  |
|  |  | July 30, 2021 |  | July 31, 2020 |  |  | July 30, 2021 |  | July 31, 2020 |  | Location of Gain (Loss) Recognized |
|  |  | (in millions) |  |  |
| Gain (Loss) Recognized: |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | (133) |  |  | $ | 162 |  |  |  | $ | (157) |  |  | $ | 214 |  |  | Interest and other, net |
| Interest rate contracts |  | (4) |  |  | (5) |  |  |  | (3) |  |  | (44) |  |  | Interest and other, net |
| Total |  | $ | (137) |  |  | $ | 157 |  |  |  | $ | (160) |  |  | $ | 170 |  |  |  |

[0001571996-21-000040:notes:158]
[same as prior period, unchanged from 0001571996-21-000026:notes:157]

[0001571996-21-000040:notes:159]
[same as prior period, unchanged from 0001571996-21-000026:notes:158]

[0001571996-21-000040:notes:160]
|  | July 30, 2021 |
|  | Other CurrentAssets |  | Other Non-Current Assets |  | Other CurrentLiabilities |  | Other Non-CurrentLiabilities |  | TotalFair Value |
|  | (in millions) |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts in an asset position | $ | 76 |  |  | $ | — |  |  | $ | 49 |  |  | $ | — |  |  | $ | 125 |  |
| Foreign exchange contracts in a liability position | (12) |  |  | — |  |  | (8) |  |  | — |  |  | (20) |  |
| Net asset (liability) | 64 |  |  | — |  |  | 41 |  |  | — |  |  | 105 |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts in an asset position | 81 |  |  | 1 |  |  | 75 |  |  | — |  |  | 157 |  |
| Foreign exchange contracts in a liability position | (77) |  |  | — |  |  | (207) |  |  | (8) |  |  | (292) |  |
| Interest rate contracts in an asset position | — |  |  | 6 |  |  | — |  |  | — |  |  | 6 |  |
| Interest rate contracts in a liability position | — |  |  | — |  |  | — |  |  | (32) |  |  | (32) |  |
| Net asset (liability) | 4 |  |  | 7 |  |  | (132) |  |  | (40) |  |  | (161) |  |
| Total derivatives at fair value | $ | 68 |  |  | $ | 7 |  |  | $ | (91) |  |  | $ | (40) |  |  | $ | (56) |  |
|  | January 29, 2021 |
|  | Other CurrentAssets |  | Other Non-Current Assets |  | Other CurrentLiabilities |  | Other Non-CurrentLiabilities |  | TotalFair Value |
|  | (in millions) |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts in an asset position | $ | 28 |  |  | $ | — |  |  | $ | 18 |  |  | $ | — |  |  | $ | 46 |  |
| Foreign exchange contracts in a liability position | (10) |  |  | — |  |  | (15) |  |  | — |  |  | (25) |  |
| Net asset (liability) | 18 |  |  | — |  |  | 3 |  |  | — |  |  | 21 |  |
| Derivatives not designated as hedging instruments: |
| Foreign exchange contracts in an asset position | 184 |  |  | — |  |  | 58 |  |  | — |  |  | 242 |  |
| Foreign exchange contracts in a liability position | (108) |  |  | — |  |  | (159) |  |  | (4) |  |  | (271) |  |
| Interest rate contracts in an asset position | — |  |  | 10 |  |  | — |  |  | — |  |  | 10 |  |
| Interest rate contracts in a liability position | — |  |  | — |  |  | — |  |  | (31) |  |  | (31) |  |
| Net asset (liability) | 76 |  |  | 10 |  |  | (101) |  |  | (35) |  |  | (50) |  |
| Total derivatives at fair value | $ | 94 |  |  | $ | 10 |  |  | $ | (98) |  |  | $ | (35) |  |  | $ | (29) |  |

[0001571996-21-000040:notes:161]
[same as prior period, unchanged from 0001571996-21-000026:notes:160]

[0001571996-21-000040:notes:162]
|  | July 30, 2021 |
|  | Gross Amounts of Recognized Assets/ (Liabilities) |  | Gross Amounts Offset in the Statement of Financial Position |  | Net Amounts of Assets/ (Liabilities) Presented in the Statement of Financial Position |  | Gross Amounts not Offset in the Statement of Financial Position |  | Net Amount of Assets/ (Liabilities) Recognized in the Statement of Financial Position |
|  | Financial Instruments |  | Cash Collateral Received or Pledged |  |
|  | (in millions) |
| Derivative instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Financial assets | $ | 288 |  |  | $ | (213) |  |  | $ | 75 |  |  | $ | — |  |  | $ | — |  |  | $ | 75 |  |
| Financial liabilities | (344) |  |  | 213 |  |  | (131) |  |  | — |  |  | 19 |  |  | (112) |  |
| Total derivative instruments | $ | (56) |  |  | $ | — |  |  | $ | (56) |  |  | $ | — |  |  | $ | 19 |  |  | $ | (37) |  |
|  | January 29, 2021 |
|  | Gross Amounts of Recognized Assets/ (Liabilities) |  | Gross Amounts Offset in the Statement of Financial Position |  | Net Amounts of Assets/ (Liabilities) Presented in the Statement of Financial Position |  | Gross Amounts not Offset in the Statement of Financial Position |  | Net Amount of Assets/ (Liabilities) Recognized in the Statement of Financial Position |
|  | Financial Instruments |  | Cash Collateral Received or Pledged |  |
|  | (in millions) |
| Derivative instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Financial assets | $ | 298 |  |  | $ | (194) |  |  | $ | 104 |  |  | $ | — |  |  | $ | — |  |  | $ | 104 |  |
| Financial liabilities | (327) |  |  | 194 |  |  | (133) |  |  | — |  |  | 2 |  |  | (131) |  |
| Total derivative instruments | $ | (29) |  |  | $ | — |  |  | $ | (29) |  |  | $ | — |  |  | $ | 2 |  |  | $ | (27) |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001571996-21-000040:notes:163]
[same as prior period, unchanged from 0001571996-21-000026:notes:162]

[0001571996-21-000040:notes:164]
[same as prior period, unchanged from 0001571996-21-000026:notes:163]

[0001571996-21-000040:notes:165]
The Infrastructure Solutions Group, Client Solutions Group, and VMware reporting units are consistent with the reportable segments identified in Note 16 of the Notes to the Condensed Consolidated Financial Statements.  Other businesses consists of Secureworks, Virtustream, and Boomi, which each represent separate reporting units.

[0001571996-21-000040:notes:166]
[same as prior period, unchanged from 0001571996-21-000026:notes:165]

[0001571996-21-000040:notes:167]
|  | Infrastructure Solutions Group |  | Client Solutions Group |  | VMware |  | Other Businesses |  | Total |
|  | (in millions) |
| Balance as of January 29, 2021 | $ | 15,324 |  |  | $ | 4,237 |  |  | $ | 20,802 |  |  | $ | 466 |  |  | $ | 40,829 |  |
| Goodwill acquired | — |  |  | — |  |  | (1) |  |  | — |  |  | (1) |  |
| Impact of foreign currency translation | (48) |  |  | — |  |  | — |  |  | — |  |  | (48) |  |
| Reclassification to assets held for sale (a) | — |  |  | — |  |  | — |  |  | (39) |  |  | (39) |  |
| Balance as of July 30, 2021 | $ | 15,276 |  |  | $ | 4,237 |  |  | $ | 20,801 |  |  | $ | 427 |  |  | $ | 40,741 |  |

[0001571996-21-000040:notes:168]
(a)    During the three months ended July 30, 2021, Boomi’s goodwill was reclassified to current assets held for sale on the Condensed Consolidated Statements of Financial Position due to the Company’s entry into a definitive agreement to sell Boomi.  See Note 1 of the Notes to the Condensed Consolidated Financial Statements for additional information about the pending sale of Boomi.

[0001571996-21-000040:notes:169]
Goodwill and indefinite-lived intangible assets are tested for impairment annually during the third fiscal quarter and whenever events or circumstances may indicate that an impairment has occurred.  No impairment test has been performed since the Company’s annual impairment review in the third quarter of Fiscal 2021.

[0001571996-21-000040:notes:170]
[same as prior period, unchanged from 0001571996-21-000026:notes:169]

[0001571996-21-000040:notes:171]
[same as prior period, unchanged from 0001571996-21-000026:notes:170]

[0001571996-21-000040:notes:172]
Based on the results of the annual goodwill impairment test performed during the fiscal year ended January 29, 2021, the fair values of each of the goodwill reporting units exceeded their carrying values.

[0001571996-21-000040:notes:173]
[same as prior period, unchanged from 0001571996-21-000026:notes:171]

[0001571996-21-000040:notes:174]
[same as prior period, unchanged from 0001571996-21-000026:notes:173]

[0001571996-21-000040:notes:175]
[same as prior period, unchanged from 0001571996-21-000026:notes:174]

[0001571996-21-000040:notes:176]
|  | July 30, 2021 |  | January 29, 2021 |
|  | Gross |  | AccumulatedAmortization |  | Net |  | Gross |  | AccumulatedAmortization |  | Net |
|  | (in millions) |
| Customer relationships | $ | 22,386 |  |  | $ | (16,270) |  |  | $ | 6,116 |  |  | $ | 22,394 |  |  | $ | (15,448) |  |  | $ | 6,946 |  |
| Developed technology | 15,479 |  |  | (12,668) |  |  | 2,811 |  |  | 15,488 |  |  | (12,136) |  |  | 3,352 |  |
| Trade names | 1,287 |  |  | (955) |  |  | 332 |  |  | 1,285 |  |  | (909) |  |  | 376 |  |
| Definite-lived intangible assets | 39,152 |  |  | (29,893) |  |  | 9,259 |  |  | 39,167 |  |  | (28,493) |  |  | 10,674 |  |
| Indefinite-lived trade names | 3,755 |  |  | — |  |  | 3,755 |  |  | 3,755 |  |  | — |  |  | 3,755 |  |
| Total intangible assets | $ | 42,907 |  |  | $ | (29,893) |  |  | $ | 13,014 |  |  | $ | 42,922 |  |  | $ | (28,493) |  |  | $ | 14,429 |  |

[0001571996-21-000040:notes:177]
Amortization expense related to definite-lived intangible assets was approximately $0.7 billion and $0.8 billion for the three months ended July 30, 2021 and July 31, 2020, respectively, and $1.4 billion and $1.7 billion for the six months ended July 30, 2021 and July 31, 2020, respectively.  There were no material impairment charges related to intangible assets during the three and six months ended July 30, 2021 or July 31, 2020.

[0001571996-21-000040:notes:178]
[same as prior period, unchanged from 0001571996-21-000026:notes:177]

[0001571996-21-000040:notes:179]
[same as prior period, unchanged from 0001571996-21-000026:notes:178]

[0001571996-21-000040:notes:180]
|  | July 30, 2021 |
|  | (in millions) |
| Fiscal 2022 (remaining six months) | $ | 1,284 |  |
| Fiscal 2023 | 1,826 |  |
| Fiscal 2024 | 1,458 |  |
| Fiscal 2025 | 1,107 |  |
| Fiscal 2026 | 858 |  |
| Thereafter | 2,726 |  |
| Total | $ | 9,259 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001571996-21-000040:notes:181]
[same as prior period, unchanged from 0001571996-21-000026:notes:180]

[0001571996-21-000040:notes:182]
[same as prior period, unchanged from 0001571996-21-000026:notes:181]

[0001571996-21-000040:notes:183]
[same as prior period, unchanged from 0001571996-21-000026:notes:182]

[0001571996-21-000040:notes:184]
|  | Three Months Ended |  | Six Months Ended |
|  | July 30, 2021 |  | July 31, 2020 |  | July 30, 2021 |  | July 31, 2020 |
|  | (in millions) |
| Deferred revenue: |  |  |  |  |  |  |  |
| Deferred revenue at beginning of period | $ | 31,376 |  |  | $ | 27,617 |  |  | $ | 30,801 |  |  | $ | 27,800 |  |
| Revenue deferrals | 6,674 |  |  | 6,550 |  |  | 13,154 |  |  | 12,095 |  |
| Revenue recognized | (6,052) |  |  | (5,376) |  |  | (11,957) |  |  | (10,843) |  |
| Other (a) | (155) |  |  | — |  |  | (155) |  |  | (261) |  |
| Deferred revenue at end of period | $ | 31,843 |  |  | $ | 28,791 |  |  | $ | 31,843 |  |  | $ | 28,791 |  |
| Short-term deferred revenue | $ | 17,003 |  |  | $ | 15,341 |  |  | $ | 17,003 |  |  | $ | 15,341 |  |
| Long-term deferred revenue | $ | 14,840 |  |  | $ | 13,450 |  |  | $ | 14,840 |  |  | $ | 13,450 |  |

[0001571996-21-000040:notes:185]
(a) For the three and six months ended July 30, 2021, Other represents the reclassification of Boomi deferred revenue to liabilities held for sale.  For the six months ended July 31, 2020, Other represents the reclassification of RSA Security deferred revenue to liabilities held for sale.  See Note 1 of the Notes to the Condensed Consolidated Financial Statements for more information about the divestitures of Boomi and of RSA Security.

[0001571996-21-000040:notes:186]
Remaining Performance Obligations — Remaining performance obligations represent the aggregate amount of the transaction price allocated to performance obligations not delivered, or partially undelivered, as of the end of the reporting period.  Remaining performance obligations include deferred revenue plus unbilled amounts not yet recorded in deferred revenue.  The value of the transaction price allocated to remaining performance obligations as of July 30, 2021 was approximately $46 billion.  The Company expects to recognize approximately 61% of remaining performance obligations as revenue in the next twelve months, and the remainder thereafter.

[0001571996-21-000040:notes:187]
The aggregate amount of the transaction price allocated to remaining performance obligations does not include amounts owed under cancellable contracts where there is no substantive termination penalty.  The Company applied the practical expedient to exclude the value of remaining performance obligations for contracts for which revenue is recognized in the amount to which the Company has the right to invoice for services performed.

[0001571996-21-000040:notes:188]
[same as prior period, unchanged from 0001571996-21-000026:notes:187]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001571996-21-000040:notes:189]
NOTE 9 — COMMITMENTS AND CONTINGENCIES

[0001571996-21-000040:notes:190]
Purchase Obligations

[0001571996-21-000040:notes:191]
The Company has contractual obligations to purchase goods or services, which specify significant terms, including fixed or minimum quantities to be purchased; fixed, minimum, or variable price provisions; and the approximate timing of the transaction.  As of July 30, 2021, purchase obligations were $5.2 billion, $0.6 billion, and $0.9 billion for the remaining six month of Fiscal 2022, Fiscal 2023, and Fiscal 2024 and thereafter, respectively.

[0001571996-21-000040:notes:192]
Legal Matters

[0001571996-21-000040:notes:193]
The Company is involved in various claims, suits, assessments, investigations, and legal proceedings that arise from time to time in the ordinary course of its business, including those identified below, consisting of matters involving consumer, antitrust, tax, intellectual property, and other issues on a global basis.

[0001571996-21-000040:notes:194]
The Company accrues a liability when it believes that it is both probable that a liability has been incurred and that it can reasonably estimate the amount of the loss.  The Company reviews these accruals at least quarterly and adjusts them to reflect ongoing negotiations, settlements, rulings, advice of legal counsel, and other relevant information.  As additional information is obtained and the Company’s views on the probable outcomes of claims, suits, assessments, investigations, or legal proceedings change, the Company would record related impacts to accrued liabilities in the period in which a determination is made.  For some matters, the incurrence of a liability is not probable or the amount cannot be reasonably estimated and therefore accruals have not been made.

[0001571996-21-000040:notes:195]
The following is a discussion of the Company’s significant legal matters and other proceedings:

[0001571996-21-000040:notes:196]
Class Actions Related to the Class V Transaction — Four purported stockholders brought putative class action complaints arising out of the Class V transaction described in Note 1 of the Notes to the Condensed Consolidated Financial Statements.  The actions were captioned Hallandale Beach Police and Fire Retirement Plan v. Michael Dell et al. (Civil Action No. 2018-0816-JTL), Howard Karp v. Michael Dell et al. (Civil Action No. 2019-0032-JTL), Miramar Police Officers’ Retirement Plan v. Michael Dell et al. (Civil Action No. 2019-0049-JTL), and Steamfitters Local 449 Pension Plan v. Michael Dell et al. (Civil Action No. 2019-0115-JTL).  The four actions were consolidated in the Delaware Chancery Court into In Re Dell Class V Litigation (Consol. C.A. No. 2018-0816-JTL), which names as defendants the Company’s board of directors, Goldman Sachs & Co. LLC,  and certain stockholders of the Company, including Michael S. Dell.  The plaintiffs generally allege that the defendants breached their fiduciary duties to the former holders of Class V Common Stock in connection with the Class V transaction by allegedly causing the Company to enter into a transaction that favored the interests of the controlling stockholders at the expense of such former stockholders.  The plaintiffs seek, among other remedies, a judicial declaration that the defendants breached their fiduciary duties and an award of damages, fees, and costs.  The plaintiffs filed an amended complaint in August 2019 making substantially similar allegations to those described above.  The defendants filed a motion to dismiss the action in September 2019.  The court denied the motion in June 2020 and the case is currently in the discovery phase.  Trial is currently scheduled to begin on December 5, 2022.

[0001571996-21-000040:notes:197]
Patent Litigation — On April 25, 2019, Cirba Inc. and Cirba IP, Inc. (collectively, “Cirba”) filed a lawsuit against VMware, Inc. in the United States District Court for the District of Delaware (the “Delaware Court”), alleging two patent infringement claims and three trademark infringement-related claims (the “First Action”).  Following a hearing on August 6, 2019, the Delaware Court denied Cirba’s preliminary injunction motion.  On August 20, 2019, VMware, Inc. filed counterclaims against Cirba, asserting among other claims that Cirba is infringing four VMware, Inc. patents.  The Delaware Court severed those claims from the January 2020 trial on Cirba’s claims.  On January 24, 2020, a jury returned a verdict that VMware, Inc. had willfully infringed Cirba’s two patents and awarded approximately $237 million in damages.  As to Cirba’s trademark-related claims, the jury found that VMware, Inc. was not liable.  A total of $237 million was accrued for the First Action as of January 31, 2020, which reflected the estimated losses that were considered both probable and reasonably estimable at that time.  The amount accrued for this matter was included in Accrued and other in the Consolidated Statements of Financial Position as of January 31, 2020, and the charge was classified in Selling, general and administrative in the Consolidated Statements of Income (Loss) for the fiscal year ended January 31, 2020.  On March 9, 2020, the parties filed post-trial motions in the First Action.  On December 21, 2020, the Delaware Court granted VMware, Inc.’s request for a new trial based, in part, on Cirba’s Inc.’s lack of standing, set aside the verdict and damages award, and denied Cirba’s post-trial motions (the “Post-Trial Order”).

[0001571996-21-000040:notes:198]
On October 22, 2019, VMware, Inc. filed a separate lawsuit against Cirba in the United States District Court for the Eastern District of Virginia alleging infringement of four additional VMware, Inc. patents (The “Second Action”).  The Virginia court transferred the Second Action to the Delaware Court on February 25, 2020.  On March 23, 2020, Cirba filed a counterclaim asserting one additional patent against VMware, Inc.  The Delaware Court consolidated the First and Second Actions and ordered a consolidated trial on all of the parties’ patent infringement claims and counterclaims.  On May 3, 2021, the Court denied Cirba’s motion to certify the Post-Trial Order to enable an interlocutory appeal to the United States Court of Appeals for the Federal Circuit.  Also, on May 3, 2021, the Court granted Cirba’s motion for leave to assert an additional patent against VMware, Inc.  Separately, VMware has filed challenges with the United States Patent and Trademark Office against each of the four patents that are subject of Cirba’s allegation.  To date, of the four challenges, two ex parte reexams have been granted and one Inter Partes Review has been instituted.  As of January 29, 2021, VMware, Inc. reassessed its estimated loss accrual for the First Action based on the Post-Trial Order and determined that a loss was no longer probable and reasonably estimable with respect to the consolidated First and Second Actions.  Accordingly, the estimated loss accrual recognized during the fiscal year ended January 31, 2020 totaling $237 million was adjusted to $0 with the credit included in Selling, general, and administrative in the Consolidated Statements of Income (Loss) for the fiscal year ended January 29, 2021.  VMware, Inc. has reported that it is unable at this time to assess whether, or to what extent, it may be found liable and, if found liable, the amount any damages that may be awarded.  VMware, Inc. intends to vigorously defend itself in this matter.

[0001571996-21-000040:notes:199]
Class Actions Related to VMware, Inc.’s Acquisition of Pivotal — Two purported stockholders brought putative class action complaints arising out of VMware, Inc.’s acquisition of Pivotal Software, Inc. on December 30, 2019 as described in Note 1 of the Notes to the Condensed Consolidated Financial Statements.  The two actions were consolidated in the Delaware Chancery Court into In re: Pivotal Software, Inc. Stockholders Litigation (Civil Action No. 2020-0440-KSJM).  The complaint names as defendants the Company, VMware, Inc., Michael S. Dell, and certain officers of Pivotal.  The plaintiffs generally allege that the defendants breached their fiduciary duties to the former holders of Pivotal Class A common stock in connection with VMware, Inc.’s acquisition of Pivotal by allegedly causing Pivotal to enter into a transaction that favored the interests of Pivotal’s controlling stockholders at the expense of such former stockholders.  The plaintiffs seek, among other remedies, a judicial declaration that the defendants breached their fiduciary duties and an award of damages, fees, and costs.  Trial is currently scheduled to begin on July 6, 2022.

[0001571996-21-000040:notes:200]
Other Litigation — Dell does not currently expect that any other proceedings or matters will have a material adverse effect on its business, financial condition, results of operations, or cash flows.

[0001571996-21-000040:notes:201]
In accordance with the relevant accounting guidance, the Company provides disclosures of matters where it is at least reasonably possible that the Company could experience a material loss exceeding the amounts already accrued for these or other proceedings or matters.  In addition, the Company also discloses matters based on its consideration of other matters and qualitative factors, including the experience of other companies in the industry, and investor, customer, and employee relations considerations.  As of July 30, 2021, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for these or other proceedings or matters has been incurred.  However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company’s business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters.  Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company’s business, financial condition, results of operations, or cash flows will depend on a number of factors, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.

[0001571996-21-000040:notes:202]
Indemnifications

[0001571996-21-000040:notes:203]
In the ordinary course of business, the Company enters into contractual arrangements under which it may agree to indemnify other parties for losses incurred from certain events as defined in the relevant contract, such as litigation, regulatory penalties, or claims relating to past performance.  Such indemnification obligations may not be subject to maximum loss clauses.  Historically, payments related to these indemnifications have not been material to the Company.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001571996-21-000040:notes:204]
[same as prior period, unchanged from 0001571996-21-000026:notes:201]

[0001571996-21-000040:notes:205]
For the three months ended July 30, 2021 and July 31, 2020, the Company’s effective income tax rate was 13.1% and -119.8%, respectively, on pre-tax income of $1.0 billion and $0.5 billion, respectively.  For the six months ended July 30, 2021 and July 31, 2020, the Company’s effective income tax rate was 9.1% and -101.4%, respectively, on pre-tax income of $2.0 billion and $0.6 billion, respectively.  The changes in the Company’s effective income tax rate are primarily driven by lower discrete tax benefits on higher pre-tax income and a change in the Company’s jurisdictional mix of income.  For the six months ended July 30, 2021, the Company’s effective income tax rate includes discrete tax benefits of $131 million related to stock-based compensation.  In comparison, for the six months ended July 31, 2020, the Company’s effective income tax rate includes discrete tax benefits of $746 million related to an audit settlement that was recorded in the second quarter within that period.  The effective income tax rate for future quarters of Fiscal 2022 may be impacted by the actual mix of jurisdictions in which income is generated, as well as the impact of any discrete tax items.

[0001571996-21-000040:notes:206]
The differences between the estimated effective income tax rates and the U.S. federal statutory rate of 21% principally result from the Company’s geographical distribution of income, differences between the book and tax treatment of certain items, and the discrete tax items discussed above.  In certain jurisdictions, the Company’s tax rate is significantly less than the applicable statutory rate as a result of tax holidays.  The majority of the Company’s foreign income that is subject to these tax holidays and lower tax rates is attributable to Singapore and China.  A significant portion of these income tax benefits relate to a tax holiday that will be effective until January 31, 2029.  The Company’s other tax holidays will expire in whole or in part during fiscal years 2022 through 2030.  Many of these tax holidays and reduced tax rates may be extended when certain conditions are met or may be terminated early if certain conditions are not met.  As of July 30, 2021, the Company was not aware of any matters of non-compliance related to these tax holidays.

[0001571996-21-000040:notes:207]
The Internal Revenue Service is currently examining fiscal years 2015 through 2019.  The Company is also currently under income tax audits in various state and foreign jurisdictions.  The Company is undergoing negotiations, and in some cases contested proceedings, relating to tax matters with the taxing authorities in these jurisdictions.  The Company believes that it has valid positions supporting its tax returns and that it has provided adequate reserves related to all matters contained in tax periods open to examination.  Although the Company believes it has made adequate provisions for the uncertainties surrounding these audits, should the Company experience unfavorable outcomes, such outcomes could have a material impact on its results of operations, financial position, and cash flows.  With respect to major U.S., state and foreign taxing jurisdictions, the Company is generally not subject to tax examinations for years prior to the fiscal year ended January 29, 2010.

[0001571996-21-000040:notes:208]
Judgment is required in evaluating the Company’s uncertain tax positions and determining the Company’s provision for income taxes.  The unrecognized tax benefits were $1.4 billion as of both July 30, 2021 and January 29, 2021, and are included in Other non-current liabilities in the Condensed Consolidated Statements of Financial Position.  The Company does not anticipate a significant change to the total amount of unrecognized tax benefits within the next twelve months.

[0001571996-21-000040:notes:209]
The Company takes certain non-income tax positions in the jurisdictions in which it operates and has received certain non-income tax assessments from various jurisdictions.  The Company believes that a material loss in these matters is not probable and that it is not reasonably possible that a material loss exceeding amounts already accrued has been incurred.  The Company believes its positions in these non-income tax litigation matters are supportable and that it ultimately will prevail in the matters.  In the normal course of business, the Company’s positions and conclusions related to its non-income taxes could be challenged and assessments may be made.  To the extent new information is obtained and the Company’s views on its positions, probable outcomes of assessments, or litigation change, changes in estimates to the Company’s accrued liabilities would be recorded in the period in which such a determination is made.  In the resolution process for income tax and non-income tax audits, the Company is required in certain situations to provide collateral guarantees or indemnification to regulators and tax authorities until the matter is resolved.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001571996-21-000040:notes:210]
[same as prior period, unchanged from 0001571996-21-000026:notes:207]

[0001571996-21-000040:notes:211]
[same as prior period, unchanged from 0001571996-21-000026:notes:208]

[0001571996-21-000040:notes:212]
[same as prior period, unchanged from 0001571996-21-000026:notes:209]

[0001571996-21-000040:notes:213]
|  | Foreign Currency Translation Adjustments |  |  |  | Cash Flow Hedges |  | Pension and Other Postretirement Plans |  | Accumulated Other Comprehensive Income (Loss) |
|  | (in millions) |
| Balances as of January 29, 2021 | $ | (150) |  |  |  |  | $ | (86) |  |  | $ | (78) |  |  | $ | (314) |  |
| Other comprehensive income (loss) before reclassifications | (140) |  |  |  |  | 64 |  |  | 1 |  |  | (75) |  |
| Amounts reclassified from accumulated other comprehensive income (loss) | — |  |  |  |  | 40 |  |  | 2 |  |  | 42 |  |
| Total change for the period | (140) |  |  |  |  | 104 |  |  | 3 |  |  | (33) |  |
| Less: Change in comprehensive income (loss) attributable to non-controlling interests | — |  |  |  |  | — |  |  | — |  |  | — |  |
| Balances as of July 30, 2021 | $ | (290) |  |  |  |  | $ | 18 |  |  | $ | (75) |  |  | $ | (347) |  |

[0001571996-21-000040:notes:214]
[same as prior period, unchanged from 0001571996-21-000026:notes:211]

[0001571996-21-000040:notes:215]
[same as prior period, unchanged from 0001571996-21-000026:notes:212]

[0001571996-21-000040:notes:216]
|  |  |  | Three Months Ended |
|  |  |  | July 30, 2021 |  |  |  | July 31, 2020 |
|  |  |  | Cash Flow Hedges |  | Pensions |  | Total |  |  |  | Cash Flow Hedges |  | Pensions |  | Total |
|  |  |  | (in millions) |
| Total reclassifications, net of tax: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue |  |  | $ | (6) |  |  | $ | — |  |  | $ | (6) |  |  |  |  | $ | 9 |  |  | $ | — |  |  | $ | 9 |  |
| Cost of net revenue |  |  | (7) |  |  | — |  |  | (7) |  |  |  |  | (1) |  |  | — |  |  | (1) |  |
| Operating expenses |  |  | — |  |  | (2) |  |  | (2) |  |  |  |  | — |  |  | (2) |  |  | (2) |  |
| Total reclassifications, net of tax |  |  | $ | (13) |  |  | $ | (2) |  |  | $ | (15) |  |  |  |  | $ | 8 |  |  | $ | (2) |  |  | $ | 6 |  |
|  |  |  | Six Months Ended |
|  |  |  | July 30, 2021 |  |  |  | July 31, 2020 |
|  |  |  | Cash Flow Hedges |  | Pensions |  | Total |  |  |  | Cash Flow Hedges |  | Pensions |  | Total |
|  |  |  | (in millions) |
| Total reclassifications, net of tax: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue |  |  | $ | (35) |  |  | $ | — |  |  | $ | (35) |  |  |  |  | $ | 105 |  |  | $ | — |  |  | $ | 105 |  |
| Cost of net revenue |  |  | (5) |  |  | — |  |  | (5) |  |  |  |  | 3 |  |  | — |  |  | 3 |  |
| Operating expenses |  |  | — |  |  | (2) |  |  | (2) |  |  |  |  | — |  |  | (4) |  |  | (4) |  |
| Total reclassifications, net of tax |  |  | $ | (40) |  |  | $ | (2) |  |  | $ | (42) |  |  |  |  | $ | 108 |  |  | $ | (4) |  |  | $ | 104 |  |


## us-gaap:MinorityInterestDisclosureTextBlock

[0001571996-21-000040:notes:217]
[same as prior period, unchanged from 0001571996-21-000026:notes:214]

[0001571996-21-000040:notes:218]
VMware, Inc. — The non-controlling interests’ share of equity in VMware, Inc. is reflected as a component of the non-controlling interests in the Condensed Consolidated Statements of Financial Position and was $5 billion as of both July 30, 2021 and January 29, 2021.  As of both July 30, 2021 and January 29, 2021, the Company held approximately 80.6% of the outstanding equity interest in VMware, Inc.

[0001571996-21-000040:notes:219]
Secureworks — The non-controlling interests’ share of equity in Secureworks is reflected as a component of the non-controlling interests in the Condensed Consolidated Statements of Financial Position and was $105 million and $96 million as of July 30, 2021 and January 29, 2021, respectively.  As of July 30, 2021 and January 29, 2021, the Company held approximately 84.1% and 85.7%, respectively, of the outstanding equity interest in Secureworks, excluding restricted stock awards (“RSAs”) and 83.2% and 84.9%, respectively, including RSAs.

[0001571996-21-000040:notes:220]
[same as prior period, unchanged from 0001571996-21-000026:notes:217]

[0001571996-21-000040:notes:221]
|  | Six Months Ended |
|  | July 30, 2021 |  |  |
|  | (in millions) |
| Net income attributable to Dell Technologies Inc. | $ | 1,718 |  |  |  |
| Transfers (to)/from the non-controlling interests: |  |  |  |
| Increase in Dell Technologies Inc. additional paid-in-capital for equity issuances and other equity activity | 497 |  |  |  |
| Decrease in Dell Technologies Inc. additional paid-in-capital for equity issuances and other equity activity | (701) |  |  |  |
| Net transfers to non-controlling interests | (204) |  |  |  |
| Change from net income attributable to Dell Technologies Inc. and transfers to the non-controlling interests | $ | 1,514 |  |  |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001571996-21-000040:notes:222]
[same as prior period, unchanged from 0001571996-21-000026:notes:219]

[0001571996-21-000040:notes:223]
[same as prior period, unchanged from 0001571996-21-000026:notes:220]

[0001571996-21-000040:notes:224]
|  | Authorized |  | Issued |  | Outstanding |
|  | (in millions) |
| Common stock as of July 30, 2021 |
| Class A | 600 |  |  | 379 |  |  | 379 |  |
| Class B | 200 |  |  | 95 |  |  | 95 |  |
| Class C | 7,900 |  |  | 299 |  |  | 291 |  |
| Class D | 100 |  |  | — |  |  | — |  |
| Class V | 343 |  |  | — |  |  | — |  |
|  | 9,143 |  |  | 773 |  |  | 765 |  |
| Common stock as of January 29, 2021 |
| Class A | 600 |  |  | 385 |  |  | 385 |  |
| Class B | 200 |  |  | 102 |  |  | 102 |  |
| Class C | 7,900 |  |  | 274 |  |  | 266 |  |
| Class D | 100 |  |  | — |  |  | — |  |
| Class V | 343 |  |  | — |  |  | — |  |
|  | 9,143 |  |  | 761 |  |  | 753 |  |

[0001571996-21-000040:notes:225]
[same as prior period, unchanged from 0001571996-21-000026:notes:222]

[0001571996-21-000040:notes:226]
[same as prior period, unchanged from 0001571996-21-000026:notes:223]

[0001571996-21-000040:notes:227]
The Company is authorized to issue one million shares of preferred stock, par value $0.01 per share.  As of July 30, 2021 and January 29, 2021, no shares of preferred stock were issued or outstanding.

[0001571996-21-000040:notes:228]
[same as prior period, unchanged from 0001571996-21-000026:notes:225]

[0001571996-21-000040:notes:229]
[same as prior period, unchanged from 0001571996-21-000026:notes:226]

[0001571996-21-000040:notes:230]
[same as prior period, unchanged from 0001571996-21-000026:notes:227]

[0001571996-21-000040:notes:231]
Conversion Rights — Under the Company’s certificate of incorporation, at any time and from time to time, any holder of Class A Common Stock or Class B Common Stock has the right to convert all or any of the shares of Class A Common Stock or Class B Common Stock, as applicable, held by such holder into shares of Class C Common Stock on a one-to-one basis.  During the six months ended July 30, 2021, the Company issued 5,549,209 shares of Class C Common Stock to stockholders upon the conversion of the same number of shares of Class A Common Stock into Class C Common Stock in accordance with the Company’s certificate of incorporation. During the six months ended July 30, 2021, the Company issued 6,334,990 shares of Class C Common Stock to stockholders upon their conversion of the same number of shares of Class B Common Stock into Class C Common Stock in accordance with the Company’s certificate of incorporation.

[0001571996-21-000040:notes:232]
[same as prior period, unchanged from 0001571996-21-000026:notes:229]

[0001571996-21-000040:notes:233]
[same as prior period, unchanged from 0001571996-21-000026:notes:230]

[0001571996-21-000040:notes:234]
On February 24, 2020, the Company’s board of directors approved a stock repurchase program under which the Company is authorized to repurchase up to $1.0 billion of shares of the Class C Common Stock over a 24-month period expiring on February 28, 2022, of which approximately $760 million remained available as of July 30, 2021.   During the six months ended July 31, 2020, the Company repurchased approximately 6 million shares of Class C Common Stock for approximately $240 million and subsequently suspended activity under its stock repurchase program.

[0001571996-21-000040:notes:235]
[same as prior period, unchanged from 0001571996-21-000026:notes:232]

[0001571996-21-000040:notes:236]
[same as prior period, unchanged from 0001571996-21-000026:notes:233]

[0001571996-21-000040:notes:237]
On May 29, 2019, VMware, Inc.’s board of directors authorized the repurchase of up to $1.5 billion of VMware, Inc.’s Class A common stock through January 29, 2021.  On July 15, 2020, VMware, Inc.’s board of directors extended authorization of VMware, Inc.’s existing repurchase program and authorized the repurchase of up to an additional $1.0 billion of VMware, Inc.’s Class A common stock through January 28, 2022.  As of July 30, 2021, the cumulative authorized amount remaining for stock repurchases was $326 million.

[0001571996-21-000040:notes:238]
During the six months ended July 30, 2021, VMware, Inc. repurchased 4.7 million shares of its Class A common stock in the open market for approximately $729 million.  During the six months ended July 31, 2020, VMware, Inc. repurchased approximately 2.5 million shares of its Class A common stock in the open market for approximately $311 million.

[0001571996-21-000040:notes:239]
[same as prior period, unchanged from 0001571996-21-000026:notes:236]

[0001571996-21-000040:notes:240]
The above VMware, Inc. Class A common stock repurchases for the six months ended July 30, 2021 and July 31, 2020 exclude shares repurchased to settle employee tax withholding related to the vesting of VMware, Inc. stock awards of $243 million and $275 million, respectively.


## us-gaap:EarningsPerShareTextBlock

[0001571996-21-000040:notes:241]
[same as prior period, unchanged from 0001571996-21-000026:notes:238]

[0001571996-21-000040:notes:242]
Basic earnings per share is based on the weighted-average effect of all common shares issued and outstanding and is calculated by dividing net income by the weighted-average shares outstanding during the period.  Diluted earnings per share is calculated by dividing net income by the weighted-average number of common shares used in the basic earnings per share calculation, adjusted for incremental dilution from non-controlling interests, plus the number of common shares that would be issued assuming exercise or conversion of all potentially dilutive instruments.  The Company excludes equity instruments from the calculation of diluted earnings per share if the effect of including such instruments is antidilutive.

[0001571996-21-000040:notes:243]
[same as prior period, unchanged from 0001571996-21-000026:notes:241]

[0001571996-21-000040:notes:244]
The following table presents the basic and diluted earnings per share for Dell Technologies Common Stock for the periods indicated:

[0001571996-21-000040:notes:245]
|  | Three Months Ended |  | Six Months Ended |
|  | July 30, 2021 |  | July 31, 2020 |  | July 30, 2021 |  | July 31, 2020 |
| Earnings per share attributable to Dell Technologies Inc. |  |  |  |  |
| Dell Technologies Common Stock — Basic | $ | 1.09 |  |  | $ | 1.41 |  |  | $ | 2.26 |  |  | $ | 1.61 |  |
| Dell Technologies Common Stock — Diluted | $ | 1.05 |  |  | $ | 1.37 |  |  | $ | 2.18 |  |  | $ | 1.56 |  |

[0001571996-21-000040:notes:246]
[same as prior period, unchanged from 0001571996-21-000026:notes:244]

[0001571996-21-000040:notes:247]
|  | Three Months Ended |  | Six Months Ended |
|  | July 30, 2021 |  | July 31, 2020 |  | July 30, 2021 |  | July 31, 2020 |
|  | (in millions) |
| Numerator: Dell Technologies Common Stock |  |  |  |  |  |  |  |
| Net income attributable to Dell Technologies — basic | $ | 831 |  |  | $ | 1,048 |  |  | $ | 1,718 |  |  | $ | 1,191 |  |
| Incremental dilution from VMware, Inc. attributable to Dell Technologies (a) | (3) |  |  | (3) |  |  | (5) |  |  | (5) |  |
| Net income attributable to Dell Technologies — diluted | $ | 828 |  |  | $ | 1,045 |  |  | $ | 1,713 |  |  | $ | 1,186 |  |
| Denominator: Dell Technologies Common Stock weighted-average shares outstanding |  |  |  |  |
| Weighted-average shares outstanding — basic | 763 |  |  | 741 |  |  | 760 |  |  | 740 |  |
| Dilutive effect of options, restricted stock units, restricted stock, and other | 23 |  |  | 20 |  |  | 24 |  |  | 18 |  |
| Weighted-average shares outstanding — diluted | 786 |  |  | 761 |  |  | 784 |  |  | 758 |  |
| Weighted-average shares outstanding — antidilutive | — |  |  | 6 |  |  | — |  |  | 6 |  |

[0001571996-21-000040:notes:248]
(a)The incremental dilution from VMware, Inc. attributable to Dell Technologies represents the impact of VMware, Inc.’s dilutive securities on diluted earnings per share of Dell Technologies Common Stock, and is calculated by multiplying the difference between VMware, Inc.’s basic and diluted earnings per share by the number of shares of VMware, Inc. common stock held by the Company.  For both periods presented, there was no incremental dilution from Secureworks due to its net loss position.


## dell:TemporaryEquityTextBlock

[0001571996-21-000040:notes:249]
[same as prior period, unchanged from 0001571996-21-000026:notes:247]

[0001571996-21-000040:notes:250]
Through June 27, 2021, awards under the Company’s stock incentive plans included certain rights that allowed the holder to exercise a put feature for the underlying Class A or Class C Common Stock after a six month holding period following the issuance of such common stock.  The put feature required the Company to purchase the stock at its fair market value.  Accordingly, these awards and such common stock were subject to reclassification from equity to temporary equity.  The put feature expired on June 27, 2021, and as a result there were no issued and outstanding awards that were reclassified as temporary equity as of July 30, 2021.

[0001571996-21-000040:notes:251]
As of the fiscal year ended January 29, 2021, the Company determined the award amounts to be classified as temporary equity as follows:

[0001571996-21-000040:notes:252]
•For stock options to purchase Class C Common Stock subject to service requirements, the intrinsic value of the option was multiplied by the portion of the option for which services had been rendered.  Upon exercise of the option, the amount in temporary equity represented the fair value of the Class C Common Stock.

[0001571996-21-000040:notes:253]
[same as prior period, unchanged from 0001571996-21-000026:notes:250]

[0001571996-21-000040:notes:254]
•For share-based arrangements that were subject to the occurrence of a contingent event, those amounts were reclassified to temporary equity based on a probability assessment performed by the Company on a periodic basis.  Contingent events included the achievement of performance-based metrics.

[0001571996-21-000040:notes:255]
The following table presents the amount of redeemable shares classified as temporary equity and summarizes the award type as of the fiscal year ended January 29, 2021:

[0001571996-21-000040:notes:256]
|  |  |  | January 29, 2021 |
|  |  | (in millions) |
| Redeemable shares classified as temporary equity |  |  | $ | 472 |  |
| Issued and outstanding unrestricted common shares |  |  | 2 |  |
| Outstanding stock options |  |  | 6 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001571996-21-000040:notes:257]
[same as prior period, unchanged from 0001571996-21-000026:notes:256]

[0001571996-21-000040:notes:258]
[same as prior period, unchanged from 0001571996-21-000026:notes:257]

[0001571996-21-000040:notes:259]
ISG enables the digital transformation of the Company’s customers through its trusted multi-cloud and big data solutions, which are built upon a modern data center infrastructure.  The ISG comprehensive portfolio of advanced storage solutions includes traditional as well as next-generation storage solutions (such as all-flash arrays, scale-out file, object platforms, and software-defined solutions), while the Company’s server portfolio includes high-performance rack, blade, tower, and hyperscale servers.  The ISG networking portfolio helps business customers transform and modernize their infrastructure, mobilize and enrich end-user experiences, and accelerate business applications and processes.  ISG also offers attached software, peripherals, and services, including support and deployment, configuration, and extended warranty services.

[0001571996-21-000040:notes:260]
[same as prior period, unchanged from 0001571996-21-000026:notes:259]

[0001571996-21-000040:notes:261]
VMware works with customers in the areas of hybrid and multi-cloud, virtual cloud networking, digital workspaces, modern applications, and intrinsic security, helping customers manage their IT resources across private clouds and complex multi-cloud, multi-device environments.  VMware enables its customers to digitally transform their operations as they ready their applications, infrastructure, and employees for constantly evolving business needs.

[0001571996-21-000040:notes:262]
The reportable segments disclosed herein are based on information reviewed by the Company’s management to evaluate the business segment results.  The Company’s measure of segment revenue and segment operating income for management reporting purposes excludes the impact of Other businesses, unallocated corporate transactions, the impact of purchase accounting, amortization of intangible assets, transaction-related expenses, stock-based compensation expense, and other corporate expenses, as applicable.  The Company does not allocate assets to its reportable segments for internal reporting purposes.

[0001571996-21-000040:notes:263]
[same as prior period, unchanged from 0001571996-21-000026:notes:262]

[0001571996-21-000040:notes:264]
|  | Three Months Ended |  | Six Months Ended |
|  | July 30, 2021 |  | July 31, 2020 |  | July 30, 2021 |  | July 31, 2020 |
|  | (in millions) |
| Consolidated net revenue: |  |  |  |  |  |  |  |
| Infrastructure Solutions Group | $ | 8,432 |  |  | $ | 8,207 |  |  | $ | 16,343 |  |  | $ | 15,776 |  |
| Client Solutions Group | 14,263 |  |  | 11,203 |  |  | 27,568 |  |  | 22,307 |  |
| VMware | 3,148 |  |  | 2,908 |  |  | 6,139 |  |  | 5,663 |  |
| Reportable segment net revenue | 25,843 |  |  | 22,318 |  |  | 50,050 |  |  | 43,746 |  |
| Other businesses (a) | 288 |  |  | 457 |  |  | 578 |  |  | 974 |  |
| Unallocated transactions (b) | 2 |  |  | — |  |  | 4 |  |  | — |  |
| Impact of purchase accounting (c) | (11) |  |  | (42) |  |  | (23) |  |  | (90) |  |
| Total consolidated net revenue | $ | 26,122 |  |  | $ | 22,733 |  |  | $ | 50,609 |  |  | $ | 44,630 |  |
| Consolidated operating income: |  |  |  |  |  |  |  |
| Infrastructure Solutions Group | $ | 970 |  |  | $ | 973 |  |  | $ | 1,758 |  |  | $ | 1,705 |  |
| Client Solutions Group | 995 |  |  | 715 |  |  | 2,085 |  |  | 1,307 |  |
| VMware | 849 |  |  | 894 |  |  | 1,690 |  |  | 1,667 |  |
| Reportable segment operating income | 2,814 |  |  | 2,582 |  |  | 5,533 |  |  | 4,679 |  |
| Other businesses (a) | (3) |  |  | 37 |  |  | (8) |  |  | 102 |  |
| Unallocated transactions (b) | — |  |  | (1) |  |  | — |  |  | (2) |  |
| Impact of purchase accounting (c) | (20) |  |  | (53) |  |  | (45) |  |  | (116) |  |
| Amortization of intangibles | (711) |  |  | (847) |  |  | (1,420) |  |  | (1,702) |  |
| Transaction-related expenses (d) | (60) |  |  | (83) |  |  | (111) |  |  | (159) |  |
| Stock-based compensation expense (e) | (499) |  |  | (413) |  |  | (934) |  |  | (783) |  |
| Other corporate expenses (f) | (149) |  |  | (86) |  |  | (268) |  |  | (181) |  |
| Total consolidated operating income | $ | 1,372 |  |  | $ | 1,136 |  |  | $ | 2,747 |  |  | $ | 1,838 |  |

[0001571996-21-000040:notes:265]
[same as prior period, unchanged from 0001571996-21-000026:notes:264]

[0001571996-21-000040:notes:266]
[same as prior period, unchanged from 0001571996-21-000026:notes:265]

[0001571996-21-000040:notes:267]
[same as prior period, unchanged from 0001571996-21-000026:notes:266]

[0001571996-21-000040:notes:268]
[same as prior period, unchanged from 0001571996-21-000026:notes:267]

[0001571996-21-000040:notes:269]
[same as prior period, unchanged from 0001571996-21-000026:notes:268]

[0001571996-21-000040:notes:270]
(f)Other corporate expenses includes impairment charges, incentive charges related to equity investments, severance, facilities action, and other costs.

[0001571996-21-000040:notes:271]
[same as prior period, unchanged from 0001571996-21-000026:notes:270]

[0001571996-21-000040:notes:272]
|  | Three Months Ended |  | Six Months Ended |
|  | July 30, 2021 |  | July 31, 2020 |  | July 30, 2021 |  | July 31, 2020 |
|  | (in millions) |
| Net revenue: |  |  |  |  |  |  |  |
| Infrastructure Solutions Group: |  |  |  |  |  |  |  |
| Servers and networking | $ | 4,462 |  |  | $ | 4,196 |  |  | $ | 8,571 |  |  | $ | 7,954 |  |
| Storage | 3,970 |  |  | 4,011 |  |  | 7,772 |  |  | 7,822 |  |
| Total ISG net revenue | 8,432 |  |  | 8,207 |  |  | 16,343 |  |  | 15,776 |  |
| Client Solutions Group: |  |  |  |  |  |  |  |
| Commercial | 10,573 |  |  | 8,039 |  |  | 20,376 |  |  | 16,673 |  |
| Consumer | 3,690 |  |  | 3,164 |  |  | 7,192 |  |  | 5,634 |  |
| Total CSG net revenue | 14,263 |  |  | 11,203 |  |  | 27,568 |  |  | 22,307 |  |
| VMware: |  |  |  |  |  |  |  |
| Total VMware net revenue | 3,148 |  |  | 2,908 |  |  | 6,139 |  |  | 5,663 |  |
| Total segment net revenue | $ | 25,843 |  |  | $ | 22,318 |  |  | $ | 50,050 |  |  | $ | 43,746 |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001571996-21-000040:notes:273]
[same as prior period, unchanged from 0001571996-21-000026:notes:272]

[0001571996-21-000040:notes:274]
[same as prior period, unchanged from 0001571996-21-000026:notes:273]

[0001571996-21-000040:notes:275]
|  | July 30, 2021 |  | January 29, 2021 |
|  | (in millions) |
| Cash, cash equivalents, and restricted cash: |  |  |  |
| Cash and cash equivalents | $ | 11,719 |  |  | $ | 14,201 |  |
| Restricted cash - other current assets (a) | 827 |  |  | 891 |  |
| Restricted cash - other non-current assets (a) | 81 |  |  | 92 |  |
| Total cash, cash equivalents, and restricted cash | $ | 12,627 |  |  | $ | 15,184 |  |
| Inventories, net: |  |  |  |
| Production materials | $ | 2,332 |  |  | $ | 1,717 |  |
| Work-in-process | 775 |  |  | 677 |  |
| Finished goods | 1,116 |  |  | 1,008 |  |
| Total inventories, net | $ | 4,223 |  |  | $ | 3,402 |  |
| Property, plant, and equipment, net: |  |  |  |
| Computer equipment | 7,134 |  |  | 6,506 |  |
| Land and buildings | 4,720 |  |  | 4,745 |  |
| Machinery and other equipment | 4,076 |  |  | 3,933 |  |
| Total property, plant, and equipment | 15,930 |  |  | 15,184 |  |
| Accumulated depreciation and amortization | (9,269) |  |  | (8,753) |  |
| Total property, plant, and equipment, net | 6,661 |  |  | 6,431 |  |
| Other non-current assets: |  |  |  |
| Deferred and other tax assets | $ | 6,397 |  |  | $ | 6,230 |  |
| Operating lease right of use assets | 2,044 |  |  | 2,117 |  |
| Deferred commissions | 1,145 |  |  | 1,094 |  |
| Other | 1,916 |  |  | 1,755 |  |
| Total other non-current assets | $ | 11,502 |  |  | $ | 11,196 |  |

[0001571996-21-000040:notes:276]
[same as prior period, unchanged from 0001571996-21-000026:notes:275]

[0001571996-21-000040:notes:277]
[same as prior period, unchanged from 0001571996-21-000026:notes:276]

[0001571996-21-000040:notes:278]
[same as prior period, unchanged from 0001571996-21-000026:notes:277]

[0001571996-21-000040:notes:279]
|  | Three Months Ended |  | Six Months Ended |
|  | July 30, 2021 |  | July 31, 2020 |  | July 30, 2021 |  | July 31, 2020 |
|  | (in millions) |
| Trade Receivables — Allowance for expected credit losses: |  |  |  |  |  |  |
| Balance at beginning of period | $ | 104 |  |  | $ | 144 |  |  | $ | 104 |  |  | $ | 94 |  |
| Adjustment for adoption of accounting standard (a) | — |  |  | — |  |  | — |  |  | 27 |  |
| Allowance charged to provision | 3 |  |  | 11 |  |  | 13 |  |  | 47 |  |
| Bad debt write-offs | (9) |  |  | (9) |  |  | (19) |  |  | (22) |  |
| Balance at end of period | $ | 98 |  |  | $ | 146 |  |  | $ | 98 |  |  | $ | 146 |  |

[0001571996-21-000040:notes:280]
[same as prior period, unchanged from 0001571996-21-000026:notes:279]

[0001571996-21-000040:notes:281]
[same as prior period, unchanged from 0001571996-21-000026:notes:280]

[0001571996-21-000040:notes:282]
[same as prior period, unchanged from 0001571996-21-000026:notes:281]

[0001571996-21-000040:notes:283]
|  | Three Months Ended |  | Six Months Ended |
|  | July 30, 2021 |  | July 31, 2020 |  | July 30, 2021 |  | July 31, 2020 |
|  | (in millions) |
| Warranty liability: |  |  |  |  |  |  |  |
| Warranty liability at beginning of period | $ | 458 |  |  | $ | 476 |  |  | $ | 473 |  |  | $ | 496 |  |
| Costs accrued for new warranty contracts and changes in estimates for pre-existing warranties (a) (b) | 241 |  |  | 206 |  |  | 443 |  |  | 354 |  |
| Service obligations honored | (228) |  |  | (203) |  |  | (445) |  |  | (371) |  |
| Warranty liability at end of period | $ | 471 |  |  | $ | 479 |  |  | $ | 471 |  |  | $ | 479 |  |
| Current portion | $ | 353 |  |  | $ | 339 |  |  | $ | 353 |  |  | $ | 339 |  |
| Non-current portion | $ | 118 |  |  | $ | 140 |  |  | $ | 118 |  |  | $ | 140 |  |

[0001571996-21-000040:notes:284]
[same as prior period, unchanged from 0001571996-21-000026:notes:283]

[0001571996-21-000040:notes:285]
[same as prior period, unchanged from 0001571996-21-000026:notes:284]

[0001571996-21-000040:notes:286]
[same as prior period, unchanged from 0001571996-21-000026:notes:285]

[0001571996-21-000040:notes:287]
[same as prior period, unchanged from 0001571996-21-000026:notes:286]

[0001571996-21-000040:notes:288]
|  | Three Months Ended |  | Six Months Ended |
|  | July 30, 2021 |  | July 31, 2020 |  | July 30, 2021 |  | July 31, 2020 |
|  | (in millions) |
| Severance liability: |  |  |  |  |  |  |  |
| Severance liability at beginning of period | $ | 94 |  |  | $ | 126 |  |  | $ | 138 |  |  | $ | 196 |  |
| Severance charges to provision | 80 |  |  | 93 |  |  | 110 |  |  | 191 |  |
| Cash paid and other (a) | (48) |  |  | (51) |  |  | (122) |  |  | (219) |  |
| Severance liability at end of period | $ | 126 |  |  | $ | 168 |  |  | $ | 126 |  |  | $ | 168 |  |

[0001571996-21-000040:notes:289]
[same as prior period, unchanged from 0001571996-21-000026:notes:288]

[0001571996-21-000040:notes:290]
[same as prior period, unchanged from 0001571996-21-000026:notes:289]

[0001571996-21-000040:notes:291]
|  | Three Months Ended |  | Six Months Ended |
|  | July 30, 2021 |  | July 31, 2020 |  | July 30, 2021 |  | July 31, 2020 |
|  | (in millions) |
| Severance charges: |  |  |  |  |  |  |  |
| Cost of net revenue | $ | 9 |  |  | $ | 2 |  |  | $ | 22 |  |  | $ | 12 |  |
| Selling, general, and administrative | 69 |  |  | 88 |  |  | 83 |  |  | 169 |  |
| Research and development | 2 |  |  | 3 |  |  | 5 |  |  | 10 |  |
| Total severance charges | $ | 80 |  |  | $ | 93 |  |  | $ | 110 |  |  | $ | 191 |  |

[0001571996-21-000040:notes:292]
[same as prior period, unchanged from 0001571996-21-000026:notes:291]

[0001571996-21-000040:notes:293]
[same as prior period, unchanged from 0001571996-21-000026:notes:292]

[0001571996-21-000040:notes:294]
|  | Three Months Ended |  | Six Months Ended |
|  | July 30, 2021 |  | July 31, 2020 |  | July 30, 2021 |  | July 31, 2020 |
|  | (in millions) |
| Interest and other, net: |  |  |  |  |  |  |  |
| Investment income, primarily interest | $ | 10 |  |  | $ | 12 |  |  | $ | 21 |  |  | $ | 36 |  |
| Gain on investments, net | 168 |  |  | 8 |  |  | 325 |  |  | 102 |  |
| Interest expense | (483) |  |  | (617) |  |  | (993) |  |  | (1,289) |  |
| Foreign exchange | (64) |  |  | — |  |  | (113) |  |  | (99) |  |
| Other | 10 |  |  | (39) |  |  | 13 |  |  | 48 |  |
| Total interest and other, net | $ | (359) |  |  | $ | (636) |  |  | $ | (747) |  |  | $ | (1,202) |  |


## us-gaap:SubsequentEventsTextBlock

[0001571996-21-000040:notes:295]
SUBSEQUENT EVENTS 
VMware, Inc. Unsecured Senior Notes - Public Debt Offering

[0001571996-21-000040:notes:296]
On August 2, 2021, VMware, Inc. issued five series of unsecured senior notes pursuant to a public offering in the aggregate principal amount of $6.0 billion, consisting of outstanding principal due on the following dates:

[0001571996-21-000040:notes:297]
•$1.0 billion 0.60% Senior Note due August 15, 2023

[0001571996-21-000040:notes:298]
•$1.25 billion 1.00% Senior Note due August 15, 2024

[0001571996-21-000040:notes:299]
•$1.5 billion 1.40% Senior Note due August 15, 2026

[0001571996-21-000040:notes:300]
•$750 million 1.80% Senior Note due August 15, 2028

[0001571996-21-000040:notes:301]
•$1.5 billion 2.20% Senior Note due August 15, 2031

[0001571996-21-000040:notes:302]
The 2021 VMware Notes are payable semi annually on February 15 and August 15 of each year, commencing on February 15, 2022.

[0001571996-21-000040:notes:303]
The net proceeds from the 2021 VMware Notes are expected to be used by VMware, Inc. to fund a portion of the cash dividend payable in connection with the VMware Spin-off pursuant to the terms of the Separation and Distribution Agreement entered into on April 14, 2021 and, to the extent any proceeds remain, for general VMware, Inc. corporate purposes.  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.  See Note 1 of the Notes to the Condensed Consolidated Financial Statements included in this report for additional information related to the VMware Spin-off.

[0001571996-21-000040:notes:304]
VMware, Inc. Revolving Credit Facility and Term Loan Facilities

[0001571996-21-000040:notes:305]
On September 2, 2021, VMware, Inc. entered into an unsecured credit agreement establishing a revolving credit facility with a syndicate of lenders that provides VMware, Inc. with a borrowing capacity of up to $1.5 billion for general corporate purposes (the “2021 VMware Revolving Credit Facility”).  The 2021 VMware Revolving Credit Facility will replace VMware, Inc.’s existing $1.0 billion revolving credit facility that is currently undrawn.

[0001571996-21-000040:notes:306]
In addition, VMware, Inc. received commitments from financial institutions for a 3-year senior unsecured term loan facility and a 5-year senior unsecured term loan facility that would provide VMware, Inc. with a borrowing capacity of up to $4.0 billion, which, if funded, may be used to finance a portion of the Special Dividend and for VMware, Inc. general corporate purposes. VMware, Inc. may borrow against the term loan once up to its borrowing capacity of $4.0 billion until the earlier of (x) April 28, 2022 and (y) the date on which the Separation Agreement is terminated.  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.

[0001571996-21-000040:notes:307]
Margin Loan Facility

[0001571996-21-000040:notes:308]
Subsequent to July 30, 2021, the Company repaid the remaining $1.0 billion principal amount of the Margin Loan Facility due April 2022.  Upon repayment, the VMware, Inc. common stock pledged to secure the Margin Loan Facility was released as collateral in accordance with the associated Margin Loan Facility agreement.

[0001571996-21-000040:notes:309]
Other than the matters identified above, there were no known events occurring after July 30, 2021 and up until the date of issuance of this report that would materially affect the information presented herein.
