# DELL MD&A — 0001571996-21-000040


## mdna

[0001571996-21-000040:mdna:1]
[same as prior period, unchanged from 0001571996-21-000026:mdna:1]

[0001571996-21-000040:mdna:2]
Unless otherwise indicated, all results presented are prepared in a manner that complies, in all material respects, with generally accepted accounting principles in the United States of America (“GAAP”).  Additionally, unless otherwise indicated, all changes identified for the current-period results represent comparisons to results for the prior corresponding fiscal period.

[0001571996-21-000040:mdna:3]
[same as prior period, unchanged from 0001571996-21-000026:mdna:3]

[0001571996-21-000040:mdna:4]
[same as prior period, unchanged from 0001571996-21-000026:mdna:4]

[0001571996-21-000040:mdna:5]
[same as prior period, unchanged from 0001571996-21-000026:mdna:5]

[0001571996-21-000040:mdna:6]
Dell Technologies helps organizations and individuals build their digital future and transform how they work, live, and play.  We provide customers with the industry’s broadest and most innovative technology and services portfolio for the data era, spanning traditional infrastructure, emerging multi-cloud technologies, and essential technology needed in the “do anything from anywhere” economy.  We continue to seamlessly deliver differentiated and holistic IT solutions to our customers, which has driven significant revenue growth and share gains.

[0001571996-21-000040:mdna:7]
Dell Technologies’ integrated solutions help customers modernize their IT infrastructure, manage and operate in a multi-cloud world, address workforce transformation, and provide critical solutions that keep people and organizations connected, which has proven even more important in this current time of disruption caused by the COVID-19 pandemic.  We are helping customers accelerate their digital transformations to improve and strengthen business and workforce productivity.  With our extensive portfolio and our commitment to innovation, we offer secure, integrated solutions that extend from the edge to the core to the cloud, and we are at the forefront of the software-defined and cloud native infrastructure era.  As further evidence of our commitment to innovation, we are evolving and expanding our IT as-a-Service and cloud offerings through Apex, which will provide our customers with greater flexibility to scale IT to meet their evolving business needs and budgets.  In May 2021, we announced new offerings within our Apex portfolio.

[0001571996-21-000040:mdna:8]
[same as prior period, unchanged from 0001571996-21-000026:mdna:8]

[0001571996-21-000040:mdna:9]
Dell Technologies Vision and Innovation — Our vision is to be the essential technology company for the data era and a leader in end-user computing, software-defined data center solutions, data management, virtualization, edge computing, and cloud software.  We believe that our results will benefit from an integrated go-to-market strategy, including enhanced coordination across all segments of our business, and from our differentiated products and solutions capabilities.  We intend to continue to execute on our business model and seek to balance liquidity, profitability, and growth to position our company for long-term success.

[0001571996-21-000040:mdna:10]
[same as prior period, unchanged from 0001571996-21-000026:mdna:50]

[0001571996-21-000040:mdna:11]
[same as prior period, unchanged from 0001571996-21-000026:mdna:9]

[0001571996-21-000040:mdna:12]
On April 14, 2021, Dell Technologies entered into a Separation and Distribution Agreement with VMware, Inc, in which Dell Technologies owns a majority equity stake.  Subject to the terms and conditions set forth in the Separation and Distribution Agreement, the businesses of VMware, Inc. will be separated from the remaining businesses of Dell Technologies through a series of transactions that will result in the pre-transaction stockholders of Dell Technologies owning shares in two separate public companies: (1) VMware, Inc., which will own the businesses of VMware, Inc. and its subsidiaries, and (2) Dell Technologies, which will own Dell Technologies’ other businesses and subsidiaries (the “VMware Spin-off”).

[0001571996-21-000040:mdna:13]
[same as prior period, unchanged from 0001571996-21-000026:mdna:11]

[0001571996-21-000040:mdna:14]
The transaction is expected to close during the fourth quarter of calendar year 2021, subject to certain closing conditions, including receipt of a favorable private letter ruling from the Internal Revenue Service that the transaction will qualify as tax-free for Dell Technologies stockholders for U.S. federal income tax purposes.  Either Dell Technologies or VMware, Inc. may terminate the Separation and Distribution Agreement if the VMware Spin-off is not completed on or before January 28, 2022, among other termination rights.

[0001571996-21-000040:mdna:15]
[same as prior period, unchanged from 0001571996-21-000026:mdna:13]

[0001571996-21-000040:mdna:16]
The transaction announcement did not have any impact on Dell Technologies’ Condensed Consolidated Financial Statements or segment reporting.  Dell Technologies will report VMware results as discontinued operations upon the closing of the transaction.

[0001571996-21-000040:mdna:17]
[same as prior period, unchanged from 0001571996-21-000026:mdna:15]

[0001571996-21-000040:mdna:18]
[same as prior period, unchanged from 0001571996-21-000026:mdna:16]

[0001571996-21-000040:mdna:19]
[same as prior period, unchanged from 0001571996-21-000026:mdna:17]

[0001571996-21-000040:mdna:20]
60

[0001571996-21-000040:mdna:21]
Our comprehensive portfolio of advanced storage solutions includes traditional as well as next-generation storage solutions (such as all-flash arrays, scale-out file, object platforms, and software-defined solutions).  We have simplified our storage portfolio to ensure that we deliver the technology needed for our customers’ digital transformation.  We continue to make enhancements to our portfolio of storage solutions and expect that these enhancements will drive long-term improvements in the business.  In May 2020, we released our new PowerStore offering, a differentiated midrange storage solution that enables seamless updates using microservices and container-based software architecture.  This new offering allows us to compete more effectively within midrange storage and, as a result, we are seeing early signs of improving revenue velocity.

[0001571996-21-000040:mdna:22]
[same as prior period, unchanged from 0001571996-21-000026:mdna:19]

[0001571996-21-000040:mdna:23]
[same as prior period, unchanged from 0001571996-21-000026:mdna:20]

[0001571996-21-000040:mdna:24]
[same as prior period, unchanged from 0001571996-21-000026:mdna:21]

[0001571996-21-000040:mdna:25]
•Client Solutions Group (“CSG”) — CSG includes branded hardware (such as desktops, workstations, and notebooks) and branded peripherals (such as displays and projectors), as well as third-party software and peripherals.  Our computing devices are designed with our commercial and consumer customers’ needs in mind, and we seek to optimize performance, reliability, manageability, design, and security.  In addition to our traditional hardware business, we have a portfolio of thin client offerings that we believe will allow us to benefit from the growth trends in cloud computing.  For our customers that are seeking to simplify client lifecycle management, our PC as-a-Service offering combines hardware, software, lifecycle services, and financing into one all-encompassing solution that provides predictable pricing per seat per month through Dell Financial Services.  CSG also offers attached software, peripherals, and services, including support and deployment, configuration, and extended warranty services.

[0001571996-21-000040:mdna:26]
[same as prior period, unchanged from 0001571996-21-000026:mdna:23]

[0001571996-21-000040:mdna:27]
•VMware — The VMware reportable segment (“VMware”) reflects the operations of VMware, Inc. (NYSE: VMW) within Dell Technologies.  VMware works with customers in the areas of hybrid and multi-cloud, virtual cloud networking, digital workspaces, modern applications, and intrinsic security, helping customers manage their IT resources across private clouds and complex multi-cloud, multi-device environments.  VMware’s portfolio supports and addresses the key IT priorities of customers: accelerating their cloud journey, modernizing their applications, empowering digital workspaces, transforming networking, and embracing intrinsic security.  VMware enables its customers to digitally transform their operations as they ready their applications, infrastructure, and employees for constantly evolving business needs.

[0001571996-21-000040:mdna:28]
[same as prior period, unchanged from 0001571996-21-000026:mdna:25]

[0001571996-21-000040:mdna:29]
Our other businesses, described below, consist of products and services offerings of Secureworks, Virtustream, and Boomi, each of which is majority-owned by Dell Technologies.  These businesses are not classified as reportable segments, either individually or collectively, as the results of the businesses are not material to our overall results and the businesses do not meet the criteria for reportable segments.

[0001571996-21-000040:mdna:30]
[same as prior period, unchanged from 0001571996-21-000026:mdna:27]

[0001571996-21-000040:mdna:31]
[same as prior period, unchanged from 0001571996-21-000026:mdna:28]

[0001571996-21-000040:mdna:32]
•Boomi specializes in cloud-based integration, connecting information between existing on-premise and cloud-based applications to ensure that business processes are optimized, data is accurate and workflow is reliable.  In May 2021, we announced our entry into a definitive agreement with Francisco Partners and TPG Capital to sell Boomi and certain related assets from the Company in a cash transaction valued at $4 billion, subject to certain closing adjustments.  The transaction is expected to close in the third quarter of Fiscal 2022, subject to customary closing conditions.  See Note 1 of the Notes to the Condensed Consolidated Financial Statements included in this report for more information about this transaction.

[0001571996-21-000040:mdna:33]
[same as prior period, unchanged from 0001571996-21-000026:mdna:30]

[0001571996-21-000040:mdna:34]
[same as prior period, unchanged from 0001571996-21-000026:mdna:32]

[0001571996-21-000040:mdna:35]
[same as prior period, unchanged from 0001571996-21-000026:mdna:33]

[0001571996-21-000040:mdna:36]
DFS supports our businesses by offering and arranging various financing options and services for our customers primarily in North America, Europe, Australia, and New Zealand.  DFS originates, collects, and services customer receivables primarily related to the purchase or use of our product, software, and service solutions.  We also arrange financing for some of our customers in various countries where DFS does not currently operate as a captive enterprise.  DFS further strengthens our customer relationships through its flexible consumption models, which enable us to offer our customers the option to pay over time and, in certain cases, based on utilization, to provide them with financial flexibility to meet their changing technological requirements.  The results of these operations are allocated to our segments based on the underlying product or service financed.  For additional information about our financing arrangements, see Note 3 of the Notes to the Condensed Consolidated Financial Statements included in this report.

[0001571996-21-000040:mdna:37]
[same as prior period, unchanged from 0001571996-21-000026:mdna:35]

[0001571996-21-000040:mdna:38]
As part of our strategy, we will continue to evaluate opportunities for strategic investments through our venture capital investment arm, Dell Technologies Capital, with a focus on emerging technology areas that are relevant to all segments of our business and that will complement our existing portfolio of solutions.  Our investment areas include storage, software-defined networking, management and orchestration, security, machine learning and artificial intelligence, Big Data and analytics, cloud, edge computing, and software development operations.  As of July 30, 2021 and January 29, 2021, Dell Technologies held strategic investments of $1.5 billion and $1.4 billion, respectively.  In addition to these investments, we also may make disciplined acquisitions targeting businesses that advance our strategic objectives.

[0001571996-21-000040:mdna:39]
[same as prior period, unchanged from 0001571996-21-000026:mdna:37]

[0001571996-21-000040:mdna:40]
[same as prior period, unchanged from 0001571996-21-000026:mdna:38]

[0001571996-21-000040:mdna:41]
The health of our employees, customers, business partners, and communities remains our primary focus.  During Fiscal 2021, we took numerous actions in response to COVID-19, including a swift implementation of our business continuity plans.  Our crisis management team remains actively engaged to respond to changes in our environment quickly and effectively, and to ensure that our ongoing response activities are aligned with recommendations of the WHO and the U.S. Centers for Disease Control and Prevention, and with governmental regulations.  We are adjusting restrictions previously implemented as new information becomes available, governmental regulations are updated, and vaccines become more widely distributed.  Most of our employees were previously equipped with remote work capabilities over the past several years, which enabled us to quickly establish a work-from-home posture for the majority of our employees.  Further, we implemented pandemic-specific protocols for our essential employees whose jobs require them to be on-site or with customers.  We are deploying return-to-site processes in certain regions based on ongoing assessments of local conditions by our management team.  We will continue to monitor regional conditions and utilize remote work practices to ensure the health and safety of our employees, customers, and business partners.

[0001571996-21-000040:mdna:42]
We continue to work closely with our customers and business partners to support them as they expand their own remote work solutions and contingency plans and to help them access our products and services remotely.  Our agility, our breadth, and our scale has and will continue to benefit us in serving our customers and business partners during this period of accelerated digital transformation, evolution of the “do anything from anywhere” economy, and uncertainty relating to the effects of COVID-19.  Notable actions include the following:

[0001571996-21-000040:mdna:43]
[same as prior period, unchanged from 0001571996-21-000026:mdna:41]

[0001571996-21-000040:mdna:44]
[same as prior period, unchanged from 0001571996-21-000026:mdna:42]

[0001571996-21-000040:mdna:45]
•Our close relationships and ability to connect directly with our customers through our e-commerce business have enabled us to quickly meet the immediate demands of the work- and learn-from-home environments as well as the long-term demands of in office, remote, and hybrid workforce environments.

[0001571996-21-000040:mdna:46]
•The strength, scale, and resiliency of our global supply chain have afforded us flexibility to manage through the significant disruption in the supply chain environment.  We continue to adapt in real time to events as they unfold by applying predictive analytics to model a variety of outcomes to respond quickly to the changing environment.  We continue to optimize our global supply chain footprint to maximize factory uptime, for both Dell Technologies and our suppliers, by working through various local governmental regulations and mandates and by establishing robust safety measures to protect the health and safety of our essential team members.

[0001571996-21-000040:mdna:47]
•We continue to drive innovation and excellence in engineering with a largely remote workforce.  Engineers and product teams have delivered several critical solutions, including cloud updates, key client product refreshes,  PowerStore midrange storage and software, and recently announced IT as-a-Service and cloud offerings within the Apex portfolio.

[0001571996-21-000040:mdna:48]
[same as prior period, unchanged from 0001571996-21-000026:mdna:47]

[0001571996-21-000040:mdna:49]
The impact of COVID-19 is accelerating digital transformation, and we continue to see opportunities to create value and grow through the remainder of Fiscal 2022 in response to resilient demand for our IT solutions driven by a technology-enabled world.  We will continue to actively monitor global events and pursue prudent decisions to navigate in this uncertain and ever-changing environment.

[0001571996-21-000040:mdna:50]
[same as prior period, unchanged from 0001571996-21-000026:mdna:74]

[0001571996-21-000040:mdna:51]
Supply Chain — Dell Technologies maintains limited-source supplier relationships for certain components because the relationships are advantageous in the areas of performance, quality, support, delivery, capacity, and price considerations.

[0001571996-21-000040:mdna:52]
We continue to be impacted by industry-wide constraints in the supply of limited-source components in certain product offerings as a result of the impacts of COVID-19.  The acceleration of the “do anything from anywhere” economy, coupled with overall macroeconomic recovery, has led to growth in demand that has outpaced supply causing an increase in orders pending fulfillment and elongated lead times for our customers for certain products.

[0001571996-21-000040:mdna:53]
The aforementioned supply constraints coupled with increasing demand is causing increases in component costs and, during the second quarter of Fiscal 2022, component costs increased in the aggregate.  We expect the overall component cost environment to remain inflationary for the remainder of Fiscal 2022.  Component cost trends are dependent on the strength or weakness of actual end-user demand and supply dynamics, which will continue to evolve and ultimately impact the translation of the cost environment to pricing and operating results.  Further, we continue to experience increased freight costs for expedited shipments of components and rate increases in the freight network as capacity remains constrained.  We expect to continue navigating supply chain dynamics in to Fiscal 2023.

[0001571996-21-000040:mdna:54]
ISG — We expect that ISG will continue to be impacted by the changing nature of the IT infrastructure market and competitive environment.  During the first six months of Fiscal 2022,  ISG benefited from improvements in the macroeconomic environment which are forecasted to continue through the remaining six months of Fiscal 2022.  The cost environment will continue to fluctuate depending on supplier capacity and demand for certain components.  For the remainder of Fiscal 2022, we expect overall component costs to remain inflationary, most notably for servers, which will impact pricing and operating results as we seek to balance profitability and growth.  With our scale and strong solutions portfolio, we believe we are well-positioned to respond to ongoing competitive dynamics.  Within servers and networking, we will continue to be selective in determining whether to pursue certain large hyperscale and other server transactions.  We continue to focus on customer base expansion and lifetime value of customer relationships.

[0001571996-21-000040:mdna:55]
The unprecedented data growth throughout all industries is generating continued demand for our storage solutions and services.  Cloud-native applications are expected to continue as a primary growth driver in the infrastructure market.  We believe the complementary cloud solutions across our business position us to meet these demands for our customers.  We benefit from offering solutions that address the emerging trends of enterprises deploying software-defined storage, hyper-converged infrastructure, and modular solutions based on server-centric architectures.  These trends are changing the way customers are consuming our traditional storage offerings.  We continue to expand our offerings in external storage arrays, which incorporate flexible, cloud-based functionality.

[0001571996-21-000040:mdna:56]
[same as prior period, unchanged from 0001571996-21-000026:mdna:56]

[0001571996-21-000040:mdna:57]
CSG — Our CSG offerings are an important element of our strategy, generating strong cash flow and opportunities for cross-selling of complementary solutions.  During the first six months of Fiscal 2022, CSG net revenue continued to be strong across product offerings driven by ongoing high demand as customers seek improved connectivity and productivity in the “do anything from anywhere” economy.

[0001571996-21-000040:mdna:58]
While we expect that the CSG demand environment will continue to be subject to seasonal trends, we anticipate continued strong CSG demand through the remaining six months of Fiscal 2022, in line with industry demand forecasts.  The cost environment will continue to fluctuate depending on supplier capacity and demand for certain components and, for the remainder of Fiscal 2022, we expect overall component costs to remain inflationary.  The cost environment coupled with competitive dynamics continue to be a factor in our CSG business and will impact pricing and operating results as we seek to balance profitability and growth.  We remain committed to our long-term strategy for CSG and will continue to make investments to innovate across the portfolio, while benefiting from consolidation trends that are occurring in the markets in which we compete.

[0001571996-21-000040:mdna:59]
Recurring Revenue and Consumption Models — Our customers are seeking new and innovative models that address how they consume our solutions.  We offer options including as-a-service, utility, leases, and immediate pay models, all designed to match customers’ consumption and financing preferences.  Our multiyear agreements typically result in recurring revenue streams over the term of the arrangement.  In May 2021, we announced new offerings within our Apex portfolio to evolve and expand our IT as-a-Service and cloud offerings.  We expect that our flexible consumption models and as-a-service offerings through Apex will further strengthen our customer relationships and provide a foundation for growth in recurring revenue.

[0001571996-21-000040:mdna:60]
[same as prior period, unchanged from 0001571996-21-000026:mdna:60]

[0001571996-21-000040:mdna:61]
We manage our business on a U.S. dollar basis.  However, we have a large global presence, generating approximately half of our revenue by sales to customers outside of the United States during both the second quarter and first six months of Fiscal 2022 and Fiscal 2021.  As a result, our revenue can be, and in such periods has been, impacted by fluctuations in foreign currency exchange rates.  We utilize a comprehensive hedging strategy intended to mitigate the impact of foreign currency volatility over time, and we adjust pricing when possible to further minimize foreign currency impacts.

[0001571996-21-000040:mdna:62]
[same as prior period, unchanged from 0001571996-21-000026:mdna:63]

[0001571996-21-000040:mdna:63]
Our key performance metrics are net revenue, operating income, adjusted earnings before interest and other, net, taxes, depreciation, and amortization (“adjusted EBITDA”), and cash flows from operations, which are discussed elsewhere in this management’s discussion and analysis.

[0001571996-21-000040:mdna:64]
[same as prior period, unchanged from 0001571996-21-000026:mdna:83]

[0001571996-21-000040:mdna:65]
[same as prior period, unchanged from 0001571996-21-000026:mdna:66]

[0001571996-21-000040:mdna:66]
In this management’s discussion and analysis, we use supplemental measures of our performance which are derived from our consolidated financial information but which are not presented in our consolidated financial statements prepared in accordance with GAAP.  These non-GAAP financial measures include non-GAAP product net revenue; non-GAAP services net revenue; non-GAAP net revenue; non-GAAP product gross margin; non-GAAP services gross margin; non-GAAP gross margin; non-GAAP operating expenses; non-GAAP operating income; non-GAAP net income; EBITDA; and adjusted EBITDA.  The non-GAAP financial measures are not meant to be considered as indicators of performance in isolation from or as a substitute for net revenue, gross margin, operating expenses, operating income, or net income prepared in accordance with GAAP, and should be read only in conjunction with financial information presented on a GAAP basis.

[0001571996-21-000040:mdna:67]
[same as prior period, unchanged from 0001571996-21-000026:mdna:68]

[0001571996-21-000040:mdna:68]
Non-GAAP product net revenue, non-GAAP services net revenue, non-GAAP net revenue, non-GAAP product gross margin, non-GAAP services gross margin, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, and non-GAAP net income, as defined by us, exclude amortization of intangible assets, the impact of purchase accounting, transaction-related expenses, stock-based compensation expense, other corporate expenses and, for non-GAAP net income, fair value adjustments on equity investments and an aggregate adjustment for income taxes.  As the excluded items have a material impact on our financial results, our management compensates for this limitation by relying primarily on our GAAP results and using non-GAAP financial measures supplementally or for projections when comparable GAAP financial measures are not available.

[0001571996-21-000040:mdna:69]
[same as prior period, unchanged from 0001571996-21-000026:mdna:70]

[0001571996-21-000040:mdna:70]
[same as prior period, unchanged from 0001571996-21-000026:mdna:71]

[0001571996-21-000040:mdna:71]
•Amortization of Intangible Assets — Amortization of intangible assets primarily consists of amortization of customer relationships, developed technology, and trade names.  In connection with our acquisition by merger of EMC on September 7, 2016, referred to as the EMC merger transaction, and the acquisition of Dell Inc. by Dell Technologies Inc. on October 29, 2013, referred to as the going-private transaction, all of the tangible and intangible assets and liabilities of EMC and Dell, respectively, were accounted for and recognized at fair value on the transaction dates.  Accordingly, for the periods presented, amortization of intangible assets primarily represents amortization associated with intangible assets recognized in connection with the EMC merger transaction and the going-private transaction.  Amortization charges for purchased intangible assets are significantly impacted by the timing and magnitude of our acquisitions, and these charges may vary in amount from period to period.  We exclude these charges for purposes of calculating the non-GAAP financial measures presented below to facilitate an enhanced understanding of our current operating performance and provides more meaningful period to period comparisons.

[0001571996-21-000040:mdna:72]
[same as prior period, unchanged from 0001571996-21-000026:mdna:73]

[0001571996-21-000040:mdna:73]
transaction dates, and the fair value adjustments are being amortized over the estimated useful lives in the periods following the transactions.  The fair value adjustments primarily relate to deferred revenue and property, plant, and equipment.  Although the purchase accounting adjustments and related amortization of those adjustments are reflected in our GAAP results, we evaluate the operating results of the underlying businesses on a non-GAAP basis, after removing such adjustments.  We believe that excluding the impact of purchase accounting for purposes of calculating the non-GAAP financial measures presented below facilitates an enhanced understanding of our current operating performance and provides more meaningful period to period comparisons.

[0001571996-21-000040:mdna:74]
•Transaction-related Expenses — Transaction-related expenses typically consist of acquisition, integration, and divestiture related costs and are expensed as incurred.  These expenses primarily represent costs for legal, banking, consulting, and advisory services.  From time to time, this category also may include transaction-related gains on divestitures of businesses or asset sales.  During the first quarter of Fiscal 2021, we recognized a gain of $120 million on the sale of certain intellectual property assets.  We exclude these items for purposes of calculating the non-GAAP financial measures presented below to facilitate an enhanced understanding of our current operating performance and provides more meaningful period to period comparisons.

[0001571996-21-000040:mdna:75]
•Stock-based Compensation Expense — Stock-based compensation expense consists of equity awards granted based on the estimated fair value of those awards at grant date.  We estimate the fair value of service-based stock options using the Black-Scholes valuation model.  To estimate the fair value of performance-based awards containing a market condition, we use the Monte Carlo valuation model.  For all other share-based awards, the fair value is based on the closing price of the Class C Common Stock as reported on the NYSE on the date of grant.  Although stock-based compensation is an important aspect of the compensation of our employees and executives, the fair value of the stock-based awards may bear little resemblance to the actual value realized upon the vesting or future exercise of the related stock-based awards.  We believe that excluding stock-based compensation expense for purposes of calculating the non-GAAP financial measures presented below facilitates an enhanced understanding of our current operating performance and provides more meaningful period to period comparisons.

[0001571996-21-000040:mdna:76]
•Other Corporate Expenses — Other corporate expenses consist primarily of impairment charges, incentive charges related to equity investments, severance, facilities action, and other costs.  Severance costs are primarily related to severance and benefits for employees terminated pursuant to cost savings initiatives.  We continue to optimize our facilities footprint and may incur additional costs as we seek opportunities for operational efficiencies.  Other corporate expenses vary from period to period and are significantly impacted by the timing and nature of these events.  Therefore, although we may incur these types of expenses in the future, we believe that eliminating these charges for purposes of calculating the non-GAAP financial measures presented below facilitates an enhanced understanding of our current operating performance and provides more meaningful period to period comparisons.

[0001571996-21-000040:mdna:77]
•Fair Value Adjustments on Equity Investments — Fair value adjustments on equity investments primarily consist of the gain (loss) on our strategic investment portfolio, which includes the recurring fair value adjustments of investments in publicly-traded companies, as well as those in privately-held companies, which are adjusted for observable price changes and, to a lesser extent, any potential impairments.  Given the volatility in the ongoing adjustments to the valuation of these strategic investments, we believe that excluding these gains and losses for purposes of calculating non-GAAP net income presented below facilitates an enhanced understanding of our current operating performance and provides more meaningful period to period comparisons.

[0001571996-21-000040:mdna:78]
•Aggregate Adjustment for Income Taxes — The aggregate adjustment for income taxes is the estimated combined income tax effect for the adjustments described above, as well as an adjustment for discrete tax items.  Due to the variability in recognition of discrete tax items from period to period, we believe that excluding these benefits or charges for purposes of calculating non-GAAP net income facilitates an enhanced understanding of our current operating performance and provides more meaningful period to period comparisons.  The tax effects for the adjustments described above are determined based on the tax jurisdictions in which the items were incurred.  See Note 10 of the Notes to the Condensed Consolidated Financial Statements included in this report for additional information about our income taxes.

[0001571996-21-000040:mdna:79]
[same as prior period, unchanged from 0001571996-21-000026:mdna:81]

[0001571996-21-000040:mdna:80]
|  | Three Months Ended |  | Six Months Ended |
|  | July 30, 2021 |  | % Change |  | July 31, 2020 |  | July 30, 2021 |  | % Change |  | July 31, 2020 |
|  | (in millions, except percentages) |
| Product net revenue | $ | 19,394 |  |  | 16 | % |  | $ | 16,737 |  |  | $ | 37,428 |  |  | 14 | % |  | $ | 32,775 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | — |  |  |  |  | 2 |  |  | — |  |  |  |  | 6 |  |
| Non-GAAP product net revenue | $ | 19,394 |  |  | 16 | % |  | $ | 16,739 |  |  | $ | 37,428 |  |  | 14 | % |  | $ | 32,781 |  |
| Services net revenue | $ | 6,728 |  |  | 12 | % |  | $ | 5,996 |  |  | $ | 13,181 |  |  | 11 | % |  | $ | 11,855 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 11 |  |  |  |  | 40 |  |  | 23 |  |  |  |  | 84 |  |
| Non-GAAP services net revenue | $ | 6,739 |  |  | 12 | % |  | $ | 6,036 |  |  | $ | 13,204 |  |  | 11 | % |  | $ | 11,939 |  |
| Net revenue | $ | 26,122 |  |  | 15 | % |  | $ | 22,733 |  |  | $ | 50,609 |  |  | 13 | % |  | $ | 44,630 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 11 |  |  |  |  | 42 |  |  | 23 |  |  |  |  | 90 |  |
| Non-GAAP net revenue | $ | 26,133 |  |  | 15 | % |  | $ | 22,775 |  |  | $ | 50,632 |  |  | 13 | % |  | $ | 44,720 |  |
| Product gross margin | $ | 4,023 |  |  | 18 | % |  | $ | 3,407 |  |  | $ | 7,843 |  |  | 18 | % |  | $ | 6,641 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 275 |  |  |  |  | 374 |  |  | 551 |  |  |  |  | 746 |  |
| Impact of purchase accounting | 1 |  |  |  |  | 3 |  |  | 2 |  |  |  |  | 10 |  |
| Stock-based compensation expense | 12 |  |  |  |  | 6 |  |  | 21 |  |  |  |  | 10 |  |
| Other corporate expenses | 1 |  |  |  |  | 1 |  |  | 4 |  |  |  |  | 3 |  |
| Non-GAAP product gross margin | $ | 4,312 |  |  | 14 | % |  | $ | 3,791 |  |  | $ | 8,421 |  |  | 14 | % |  | $ | 7,410 |  |
| Services gross margin | $ | 3,962 |  |  | 6 | % |  | $ | 3,749 |  |  | $ | 7,800 |  |  | 6 | % |  | $ | 7,368 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | — |  |  |  |  | 1 |  |  | — |  |  |  |  | 1 |  |
| Impact of purchase accounting | 11 |  |  |  |  | 40 |  |  | 23 |  |  |  |  | 84 |  |
| Stock-based compensation expense | 51 |  |  |  |  | 44 |  |  | 100 |  |  |  |  | 80 |  |
| Other corporate expenses | 6 |  |  |  |  | 1 |  |  | 16 |  |  |  |  | 8 |  |
| Non-GAAP services gross margin | $ | 4,030 |  |  | 5 | % |  | $ | 3,835 |  |  | $ | 7,939 |  |  | 5 | % |  | $ | 7,541 |  |

[0001571996-21-000040:mdna:81]
68

[0001571996-21-000040:mdna:82]
|  | Three Months Ended |  | Six Months Ended |
|  | July 30, 2021 |  | % Change |  | July 31, 2020 |  | July 30, 2021 |  | % Change |  | July 31, 2020 |
|  | (in millions, except percentages) |
| Gross margin | $ | 7,985 |  |  | 12 | % |  | $ | 7,156 |  |  | $ | 15,643 |  |  | 12 | % |  | $ | 14,009 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 275 |  |  |  |  | 375 |  |  | 551 |  |  |  |  | 747 |  |
| Impact of purchase accounting | 12 |  |  |  |  | 43 |  |  | 25 |  |  |  |  | 94 |  |
| Stock-based compensation expense | 63 |  |  |  |  | 50 |  |  | 121 |  |  |  |  | 90 |  |
| Other corporate expenses | 7 |  |  |  |  | 2 |  |  | 20 |  |  |  |  | 11 |  |
| Non-GAAP gross margin | $ | 8,342 |  |  | 9 | % |  | $ | 7,626 |  |  | $ | 16,360 |  |  | 9 | % |  | $ | 14,951 |  |
| Operating expenses | $ | 6,613 |  |  | 10 | % |  | $ | 6,020 |  |  | $ | 12,896 |  |  | 6 | % |  | $ | 12,171 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | (436) |  |  |  |  | (472) |  |  | (869) |  |  |  |  | (955) |  |
| Impact of purchase accounting | (8) |  |  |  |  | (10) |  |  | (20) |  |  |  |  | (22) |  |
| Transaction-related expenses | (60) |  |  |  |  | (83) |  |  | (111) |  |  |  |  | (159) |  |
| Stock-based compensation expense | (436) |  |  |  |  | (363) |  |  | (813) |  |  |  |  | (693) |  |
| Other corporate expenses | (142) |  |  |  |  | (84) |  |  | (248) |  |  |  |  | (170) |  |
| Non-GAAP operating expenses | $ | 5,531 |  |  | 10 | % |  | $ | 5,008 |  |  | $ | 10,835 |  |  | 7 | % |  | $ | 10,172 |  |
| Operating income | $ | 1,372 |  |  | 21 | % |  | $ | 1,136 |  |  | $ | 2,747 |  |  | 49 | % |  | $ | 1,838 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 711 |  |  |  |  | 847 |  |  | 1,420 |  |  |  |  | 1,702 |  |
| Impact of purchase accounting | 20 |  |  |  |  | 53 |  |  | 45 |  |  |  |  | 116 |  |
| Transaction-related expenses | 60 |  |  |  |  | 83 |  |  | 111 |  |  |  |  | 159 |  |
| Stock-based compensation expense | 499 |  |  |  |  | 413 |  |  | 934 |  |  |  |  | 783 |  |
| Other corporate expenses | 149 |  |  |  |  | 86 |  |  | 268 |  |  |  |  | 181 |  |
| Non-GAAP operating income | $ | 2,811 |  |  | 7 | % |  | $ | 2,618 |  |  | $ | 5,525 |  |  | 16 | % |  | $ | 4,779 |  |
| Net income | $ | 880 |  |  | (20) | % |  | $ | 1,099 |  |  | $ | 1,818 |  |  | 42 | % |  | $ | 1,281 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 711 |  |  |  |  | 847 |  |  | 1,420 |  |  |  |  | 1,702 |  |
| Impact of purchase accounting | 20 |  |  |  |  | 53 |  |  | 45 |  |  |  |  | 116 |  |
| Transaction-related expenses | 48 |  |  |  |  | 83 |  |  | 99 |  |  |  |  | 39 |  |
| Stock-based compensation expense | 499 |  |  |  |  | 413 |  |  | 934 |  |  |  |  | 783 |  |
| Other corporate expenses | 149 |  |  |  |  | 86 |  |  | 268 |  |  |  |  | 181 |  |
| Fair value adjustments on equity investments | (168) |  |  |  |  | (8) |  |  | (325) |  |  |  |  | (102) |  |
| Aggregate adjustment for income taxes | (228) |  |  |  |  | (952) |  |  | (529) |  |  |  |  | (1,236) |  |
| Non-GAAP net income | $ | 1,911 |  |  | 18 | % |  | $ | 1,621 |  |  | $ | 3,730 |  |  | 35 | % |  | $ | 2,764 |  |

[0001571996-21-000040:mdna:83]
[same as prior period, unchanged from 0001571996-21-000026:mdna:114]

[0001571996-21-000040:mdna:84]
In addition to the above measures, we also use EBITDA and adjusted EBITDA to provide additional information for evaluation of our operating performance.  Adjusted EBITDA excludes purchase accounting adjustments, stock-based compensation expense, transaction-related expenses, and other corporate expenses.  Due to the nature of these transactions, we believe that it is appropriate to exclude these items.

[0001571996-21-000040:mdna:85]
[same as prior period, unchanged from 0001571996-21-000026:mdna:87]

[0001571996-21-000040:mdna:86]
[same as prior period, unchanged from 0001571996-21-000026:mdna:88]

[0001571996-21-000040:mdna:87]
|  | Three Months Ended |  | Six Months Ended |
|  | July 30, 2021 |  | % Change |  | July 31, 2020 |  | July 30, 2021 |  | % Change |  | July 31, 2020 |
|  | (in millions, except percentages) |
| Net income | $ | 880 |  |  | (20) | % |  | $ | 1,099 |  |  | $ | 1,818 |  |  | 42 | % |  | $ | 1,281 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Interest and other, net (a) | 359 |  |  |  |  | 636 |  |  | 747 |  |  |  |  | 1,202 |  |
| Income tax expense (benefit) (b) | 133 |  |  |  |  | (599) |  |  | 182 |  |  |  |  | (645) |  |
| Depreciation and amortization | 1,240 |  |  |  |  | 1,340 |  |  | 2,479 |  |  |  |  | 2,656 |  |
| EBITDA | $ | 2,612 |  |  | 5 | % |  | $ | 2,476 |  |  | $ | 5,226 |  |  | 16 | % |  | $ | 4,494 |  |
| EBITDA | $ | 2,612 |  |  | 5 | % |  | $ | 2,476 |  |  | $ | 5,226 |  |  | 16 | % |  | $ | 4,494 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense | 499 |  |  |  |  | 413 |  |  | 934 |  |  |  |  | 783 |  |
| Impact of purchase accounting (c) | 11 |  |  |  |  | 42 |  |  | 27 |  |  |  |  | 90 |  |
| Transaction-related expenses (d) | 60 |  |  |  |  | 83 |  |  | 111 |  |  |  |  | 159 |  |
| Other corporate expenses (e) | 149 |  |  |  |  | 86 |  |  | 268 |  |  |  |  | 181 |  |
| Adjusted EBITDA | $ | 3,331 |  |  | 7 | % |  | $ | 3,100 |  |  | $ | 6,566 |  |  | 15 | % |  | $ | 5,707 |  |

[0001571996-21-000040:mdna:88]
[same as prior period, unchanged from 0001571996-21-000026:mdna:90]

[0001571996-21-000040:mdna:89]
[same as prior period, unchanged from 0001571996-21-000026:mdna:91]

[0001571996-21-000040:mdna:90]
(b)See Note 10 of the Notes to the Condensed Consolidated Financial Statements included in this report for additional information on discrete tax items recorded during the second quarter and first six months of Fiscal 2022 and Fiscal 2021.

[0001571996-21-000040:mdna:91]
[same as prior period, unchanged from 0001571996-21-000026:mdna:93]

[0001571996-21-000040:mdna:92]
[same as prior period, unchanged from 0001571996-21-000026:mdna:94]

[0001571996-21-000040:mdna:93]
(e)Other corporate expenses include impairment charges, incentive charges related to equity investments, severance, facilities action, and other costs.

[0001571996-21-000040:mdna:94]
[same as prior period, unchanged from 0001571996-21-000026:mdna:96]

[0001571996-21-000040:mdna:95]
[same as prior period, unchanged from 0001571996-21-000026:mdna:97]

[0001571996-21-000040:mdna:96]
[same as prior period, unchanged from 0001571996-21-000026:mdna:98]

[0001571996-21-000040:mdna:97]
|  | Three Months Ended |  | Six Months Ended |
|  | July 30, 2021 |  |  |  | July 31, 2020 |  | July 30, 2021 |  |  |  | July 31, 2020 |
|  | Dollars |  | % ofNet Revenue |  | %Change |  | Dollars |  | % ofNet Revenue |  | Dollars |  | % ofNet Revenue |  | %Change |  | Dollars |  | % ofNet Revenue |
|  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products | $ | 19,394 |  |  | 74.2 | % |  | 16 | % |  | $ | 16,737 |  |  | 73.6 | % |  | $ | 37,428 |  |  | 74.0 | % |  | 14 | % |  | $ | 32,775 |  |  | 73.4 | % |
| Services | 6,728 |  |  | 25.8 | % |  | 12 | % |  | 5,996 |  |  | 26.4 | % |  | 13,181 |  |  | 26.0 | % |  | 11 | % |  | 11,855 |  |  | 26.6 | % |
| Total net revenue | $ | 26,122 |  |  | 100.0 | % |  | 15 | % |  | $ | 22,733 |  |  | 100.0 | % |  | $ | 50,609 |  |  | 100.0 | % |  | 13 | % |  | $ | 44,630 |  |  | 100.0 | % |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products (a) | $ | 4,023 |  |  | 20.7 | % |  | 18 | % |  | $ | 3,407 |  |  | 20.4 | % |  | $ | 7,843 |  |  | 21.0 | % |  | 18 | % |  | $ | 6,641 |  |  | 20.3 | % |
| Services (b) | 3,962 |  |  | 58.9 | % |  | 6 | % |  | 3,749 |  |  | 62.5 | % |  | 7,800 |  |  | 59.2 | % |  | 6 | % |  | 7,368 |  |  | 62.2 | % |
| Total gross margin | $ | 7,985 |  |  | 30.6 | % |  | 12 | % |  | $ | 7,156 |  |  | 31.5 | % |  | $ | 15,643 |  |  | 30.9 | % |  | 12 | % |  | $ | 14,009 |  |  | 31.4 | % |
| Operating expenses | $ | 6,613 |  |  | 25.3 | % |  | 10 | % |  | $ | 6,020 |  |  | 26.5 | % |  | $ | 12,896 |  |  | 25.4 | % |  | 6 | % |  | $ | 12,171 |  |  | 27.3 | % |
| Operating income | $ | 1,372 |  |  | 5.3 | % |  | 21 | % |  | $ | 1,136 |  |  | 5.0 | % |  | $ | 2,747 |  |  | 5.4 | % |  | 49 | % |  | $ | 1,838 |  |  | 4.1 | % |
| Net income | $ | 880 |  |  | 3.4 | % |  | (20) | % |  | $ | 1,099 |  |  | 4.8 | % |  | $ | 1,818 |  |  | 3.6 | % |  | 42 | % |  | $ | 1,281 |  |  | 2.9 | % |
| Net income attributable to Dell Technologies Inc. | $ | 831 |  |  | 3.2 | % |  | (21) | % |  | $ | 1,048 |  |  | 4.6 | % |  | $ | 1,718 |  |  | 3.4 | % |  | 44 | % |  | $ | 1,191 |  |  | 2.7 | % |
| Non-GAAP Financial Information |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products | $ | 19,394 |  |  | 74.2 | % |  | 16 | % |  | $ | 16,739 |  |  | 73.5 | % |  | $ | 37,428 |  |  | 73.9 | % |  | 14 | % |  | $ | 32,781 |  |  | 73.3 | % |
| Services | 6,739 |  |  | 25.8 | % |  | 12 | % |  | 6,036 |  |  | 26.5 | % |  | 13,204 |  |  | 26.1 | % |  | 11 | % |  | 11,939 |  |  | 26.7 | % |
| Total non-GAAP net revenue | $ | 26,133 |  |  | 100.0 | % |  | 15 | % |  | $ | 22,775 |  |  | 100.0 | % |  | $ | 50,632 |  |  | 100.0 | % |  | 13 | % |  | $ | 44,720 |  |  | 100.0 | % |
| Non-GAAP gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products (a) | $ | 4,312 |  |  | 22.2 | % |  | 14 | % |  | $ | 3,791 |  |  | 22.6 | % |  | $ | 8,421 |  |  | 22.5 | % |  | 14 | % |  | $ | 7,410 |  |  | 22.6 | % |
| Services (b) | 4,030 |  |  | 59.8 | % |  | 5 | % |  | 3,835 |  |  | 63.5 | % |  | 7,939 |  |  | 60.1 | % |  | 5 | % |  | 7,541 |  |  | 63.2 | % |
| Total non-GAAP gross margin | $ | 8,342 |  |  | 31.9 | % |  | 9 | % |  | $ | 7,626 |  |  | 33.5 | % |  | $ | 16,360 |  |  | 32.3 | % |  | 9 | % |  | $ | 14,951 |  |  | 33.4 | % |
| Non-GAAP operating expenses | $ | 5,531 |  |  | 21.2 | % |  | 10 | % |  | $ | 5,008 |  |  | 22.0 | % |  | $ | 10,835 |  |  | 21.4 | % |  | 7 | % |  | $ | 10,172 |  |  | 22.7 | % |
| Non-GAAP operating income | $ | 2,811 |  |  | 10.8 | % |  | 7 | % |  | $ | 2,618 |  |  | 11.5 | % |  | $ | 5,525 |  |  | 10.9 | % |  | 16 | % |  | $ | 4,779 |  |  | 10.7 | % |
| Non-GAAP net income | $ | 1,911 |  |  | 7.3 | % |  | 18 | % |  | $ | 1,621 |  |  | 7.1 | % |  | $ | 3,730 |  |  | 7.4 | % |  | 35 | % |  | $ | 2,764 |  |  | 6.2 | % |
| EBITDA | $ | 2,612 |  |  | 10.0 | % |  | 5 | % |  | $ | 2,476 |  |  | 10.9 | % |  | $ | 5,226 |  |  | 10.3 | % |  | 16 | % |  | $ | 4,494 |  |  | 10.0 | % |
| Adjusted EBITDA | $ | 3,331 |  |  | 12.7 | % |  | 7 | % |  | $ | 3,100 |  |  | 13.6 | % |  | $ | 6,566 |  |  | 13.0 | % |  | 15 | % |  | $ | 5,707 |  |  | 12.8 | % |

[0001571996-21-000040:mdna:98]
[same as prior period, unchanged from 0001571996-21-000026:mdna:100]

[0001571996-21-000040:mdna:99]
[same as prior period, unchanged from 0001571996-21-000026:mdna:101]

[0001571996-21-000040:mdna:100]
[same as prior period, unchanged from 0001571996-21-000026:mdna:102]

[0001571996-21-000040:mdna:101]
[same as prior period, unchanged from 0001571996-21-000026:mdna:103]

[0001571996-21-000040:mdna:102]
[same as prior period, unchanged from 0001571996-21-000026:mdna:104]

[0001571996-21-000040:mdna:103]
During the second quarter and first six months of Fiscal 2022, our net revenue and non-GAAP net revenue both increased 15% and 13%, respectively.  These increases were due primarily to growth in net revenue for CSG and, to a lesser extent, increases in net revenue for ISG and VMware.  CSG net revenue benefited from increased sales volume of commercial and consumer offerings driven by strong demand as customers seek improved connectivity and productivity in the “do anything from anywhere” economy.  ISG net revenue benefited from overall improvements in the macroeconomic environment and a shift towards investment in IT infrastructure.  VMware net revenue increased primarily due to continued growth in sales of subscriptions and software-as-a-service (“SaaS”) offerings.

[0001571996-21-000040:mdna:104]
During the second quarter and first six months of Fiscal 2022, our operating income increased 21% and 49%, respectively, and our non-GAAP operating income increased 7% and 16%, respectively.  The increases in our operating income and non-GAAP operating income were primarily due to increases in operating income for CSG, driven by both commercial and consumer offerings during the second quarter and first six months of Fiscal 2022.  Operating income also benefited from decreases in amortization of intangible assets during both Fiscal 2022 periods.

[0001571996-21-000040:mdna:105]
Cash provided by operating activities was $4.0 billion and $2.5 billion for the first six months of Fiscal 2022 and Fiscal 2021, respectively.  The increase in operating cash flows during the first six months of Fiscal 2022 was driven by strong profitability coupled with favorable working capital dynamics, compared to unfavorable working capital impacts related to the COVID-19 pandemic during the first six months of Fiscal 2021.  See “Market Conditions, Liquidity, and Capital Commitments” for further information on our cash flow metrics.

[0001571996-21-000040:mdna:106]
[same as prior period, unchanged from 0001571996-21-000026:mdna:108]

[0001571996-21-000040:mdna:107]
[same as prior period, unchanged from 0001571996-21-000026:mdna:109]

[0001571996-21-000040:mdna:108]
During the second quarter and first six months of Fiscal 2022, our net revenue and non-GAAP net revenue both increased 15% and 13%, respectively, driven primarily by increases in net revenue for CSG, and to a lesser extent, increases in net revenue for ISG and VMware.  See “Business Unit Results” for further information.

[0001571996-21-000040:mdna:109]
•Product Net Revenue — Product net revenue includes revenue from the sale of hardware products and software licenses.  During the second quarter and first six months of Fiscal 2022, both product net revenue and non-GAAP product net revenue increased 16% and 14%, respectively.  These increases were driven primarily by growth in CSG product net revenue due to increases in sales volume of both commercial and consumer product offerings as a result of continued strength in the demand environment.

[0001571996-21-000040:mdna:110]
•Services Net Revenue — Services net revenue includes revenue from our services offerings and support services related to hardware products and software licenses.  During the second quarter and first six months of Fiscal 2022, both services net revenue and non-GAAP services net revenue increased 12% and 11%, respectively.  These increases were driven primarily by growth in CSG services net revenue and, to a lesser extent, growth in both VMware and ISG services net revenue.  CSG services net revenue increases were primarily attributable to CSG hardware and software support and maintenance while VMware services net revenue increases were primarily driven by growth within VMware subscriptions and SaaS offerings.  A substantial portion of services net revenue is derived from offerings that have been deferred over a period of time, and, as a result, reported services net revenue growth rates will be different than reported product net revenue growth rates.

[0001571996-21-000040:mdna:111]
From a geographical perspective, net revenue generated by sales to customers in all regions increased during the second quarter and first six months of Fiscal 2022, driven by strong CSG performance.

[0001571996-21-000040:mdna:112]
[same as prior period, unchanged from 0001571996-21-000026:mdna:115]

[0001571996-21-000040:mdna:113]
During the second quarter and first six months of Fiscal 2022, our gross margin increased 12% to $8.0 billion and 12% to $15.6 billion, respectively. Our non-GAAP gross margin increased 9% to $8.3 billion and 9% to $16.4 billion during the second quarter and first six months of Fiscal 2022, respectively.  Both gross margin and non-GAAP gross margin benefited from an increase in gross margin for CSG and to a lesser extent, increases for both ISG and VMware.  These increases were partially offset by the impact of the divestiture of RSA Security during the third quarter of Fiscal 2021, which resulted in a decrease in gross margin for other businesses during the second quarter and first six months of Fiscal 2022.

[0001571996-21-000040:mdna:114]
During the second quarter and first six months of Fiscal 2022, our gross margin percentage decreased 90 basis points to 30.6% and 50 basis points to 30.9%, respectively.  Decreases in gross margin percentage during the second quarter and first six months of Fiscal 2022 were primarily due to unfavorable impacts in gross margin percentage from VMware coupled with a shift in mix towards CSG.  For the first six months of Fiscal 2022, gross margin percentage was further impacted by a decrease in gross margin percentage for ISG.  These unfavorable impacts were partially offset by an increase in gross margin percentage for CSG and a decrease in amortization of intangible assets during both the second quarter and first six months of Fiscal 2022.  Non-GAAP gross margin percentage decreased 160 basis points to 31.9% and 110 basis points to 32.3% during the second quarter and first six months of Fiscal 2022, respectively, driven by the same ISG, CSG, and VMware dynamics discussed above.

[0001571996-21-000040:mdna:115]
•Products — During the second quarter of Fiscal 2022, product gross margin increased 18% to $4.0 billion and product gross margin percentage increased 30 basis points to 20.7%.  The increase in product gross margin was primarily driven by growth in CSG product gross margin coupled with a decrease in amortization of intangible assets.  The increase in product gross margin percentage was driven by the same dynamics, partially offset by a shift in mix towards CSG.  During the same period, non-GAAP product gross margin increased 14% to $4.3 billion and non-GAAP product gross margin percentage decreased 40 basis points to 22.2%.  The increase in non-GAAP product gross margin was driven by an increase in CSG product gross margin.  The decrease in non-GAAP product gross margin percentage was primarily driven by a shift in mix towards CSG.

[0001571996-21-000040:mdna:116]
During the first six months of Fiscal 2022, product gross margin increased 18% to $7.8 billion and product gross margin percentage increased 70 basis points to 21.0%.  Non-GAAP product gross margin increased 14% to $8.4 billion and non-GAAP product gross margin percentage decreased 10 basis points to 22.5%.  The changes were driven by the same dynamics as in the second quarter of Fiscal 2022 as discussed above.

[0001571996-21-000040:mdna:117]
•Services — During the second quarter of Fiscal 2022, services gross margin increased 6% to $4.0 billion and services gross margin percentage decreased 360 basis points to 58.9%.  The increase in services gross margin was primarily driven by growth within VMware subscription and SaaS offerings and, to a lesser extent, ISG and CSG services gross margin.  The decline in services gross margin percentage was driven by decreases across VMware, ISG, and CSG.  Non-GAAP services gross margin increased 5% to $4.0 billion during the second quarter of Fiscal 2022, and non-GAAP services gross margin percentage decreased 370 basis points to 59.8% as a result of the same dynamics discussed above.

[0001571996-21-000040:mdna:118]
During the first six months of Fiscal 2022, services gross margin increased 6% to $7.8 billion and services gross margin percentage decreased 300 basis points to 59.2%.  During the first six months of Fiscal 2022, non-GAAP services gross margin increased 5% to $7.9 billion and services gross margin percentage decreased 310 basis points to 60.1%.  The changes were driven by the same dynamics as in the second quarter of Fiscal 2022 as discussed above.

[0001571996-21-000040:mdna:119]
[same as prior period, unchanged from 0001571996-21-000026:mdna:122]

[0001571996-21-000040:mdna:120]
[same as prior period, unchanged from 0001571996-21-000026:mdna:123]

[0001571996-21-000040:mdna:121]
The terms and conditions of our vendor rebate programs are largely based on product volumes and are generally negotiated either at the beginning of the annual or quarterly period, depending on the program.  The timing and amount of vendor rebates and other discounts we receive under the programs may vary from period to period, reflecting changes in the competitive environment.  We monitor our component costs and seek to address the effects of any changes to terms that might arise under our vendor rebate programs.  Our gross margins for the second quarter and first six months of Fiscal 2022 and Fiscal 2021 were not materially affected by any changes to the terms of our vendor rebate programs, as the amounts we received under these programs were generally stable relative to our total net cost.  We are not aware of any significant changes to vendor pricing or rebate programs that may impact our results in the near term.

[0001571996-21-000040:mdna:122]
[same as prior period, unchanged from 0001571996-21-000026:mdna:125]

[0001571996-21-000040:mdna:123]
[same as prior period, unchanged from 0001571996-21-000026:mdna:126]

[0001571996-21-000040:mdna:124]
|  | Three Months Ended |  | Six Months Ended |
|  | July 30, 2021 |  |  |  | July 31, 2020 |  | July 30, 2021 |  |  |  | July 31, 2020 |
|  | Dollars |  | % ofNet Revenue |  | %Change |  | Dollars |  | % ofNet Revenue |  | Dollars |  | % ofNet Revenue |  | %Change |  | Dollars |  | % ofNet Revenue |
|  | (in millions, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative | $ | 5,145 |  |  | 19.7 | % |  | 8 | % |  | $ | 4,761 |  |  | 21.0 | % |  | $ | 10,105 |  |  | 20.0 | % |  | 5 | % |  | $ | 9,647 |  |  | 21.6 | % |
| Research and development | 1,468 |  |  | 5.6 | % |  | 17 | % |  | 1,259 |  |  | 5.5 | % |  | 2,791 |  |  | 5.5 | % |  | 11 | % |  | 2,524 |  |  | 5.7 | % |
| Total operating expenses | $ | 6,613 |  |  | 25.3 | % |  | 10 | % |  | $ | 6,020 |  |  | 26.5 | % |  | $ | 12,896 |  |  | 25.5 | % |  | 6 | % |  | $ | 12,171 |  |  | 27.3 | % |
|  | Three Months Ended |  | Six Months Ended |
|  | July 30, 2021 |  |  |  | July 31, 2020 |  | July 30, 2021 |  |  |  | July 31, 2020 |
|  | Dollars |  | % of Non-GAAPNet Revenue |  | %Change |  | Dollars |  | % of Non-GAAPNet Revenue |  | Dollars |  | % ofNet Revenue |  | %Change |  | Dollars |  | % ofNet Revenue |
|  | (in millions, except percentages) |
| Non-GAAP operating expenses | $ | 5,531 |  |  | 21.2 | % |  | 10 | % |  | $ | 5,008 |  |  | 22.0 | % |  | $ | 10,835 |  |  | 21.4 | % |  | 7 | % |  | $ | 10,172 |  |  | 22.7 | % |

[0001571996-21-000040:mdna:125]
During the second quarter and first six months of Fiscal 2022, total operating expenses increased 10% and 6%, respectively. Non-GAAP operating expenses increased 10% and 7% for the second quarter and first six months of Fiscal 2022, respectively. These increases were primarily driven by employee-related expenses as a result of performance-based compensation associated with strong operating results, coupled with the reintroduction of expenses that were temporarily reduced during Fiscal 2021 in response to the COVID-19 pandemic.

[0001571996-21-000040:mdna:126]
•Selling, General, and Administrative — Selling, general, and administrative (“SG&A”) expenses increased 8% and 5%, respectively, during the second quarter and first six months of Fiscal 2022.  The increases were primarily due to an increase in employee-related compensation and benefits expense as well as an increase in advertising and promotion expense.

[0001571996-21-000040:mdna:127]
•Research and Development — Research and development (“R&D”) expenses are primarily composed of personnel-related expenses incurred to develop the software that powers our solutions.  R&D expenses as a percentage of net revenue were approximately 5.6% and 5.5% for the second quarter of Fiscal 2022 and Fiscal 2021, respectively, and 5.5% and 5.7% for the first six months of Fiscal 2022 and Fiscal 2021, respectively.  We intend to continue to support R&D initiatives to innovate and introduce new and enhanced solutions into the market.

[0001571996-21-000040:mdna:128]
[same as prior period, unchanged from 0001571996-21-000026:mdna:131]

[0001571996-21-000040:mdna:129]
[same as prior period, unchanged from 0001571996-21-000026:mdna:132]

[0001571996-21-000040:mdna:130]
During the second quarter and first six months of Fiscal 2022, our operating income increased 21% and 49% to $1.4 billion and $2.7 billion, respectively, primarily due to an increase in operating income for CSG.  Operating income during the second quarter and first six months of Fiscal 2022 also benefited from a decrease in amortization of intangible assets.  Non-GAAP operating income increased 7% and 16% to $2.8 billion and $5.5 billion during the second quarter and first six months of Fiscal 2022, respectively.  The increases in non-GAAP operating income for both Fiscal 2022 periods were primarily attributable to increases in operating income for CSG.

[0001571996-21-000040:mdna:131]
[same as prior period, unchanged from 0001571996-21-000026:mdna:134]

[0001571996-21-000040:mdna:132]
[same as prior period, unchanged from 0001571996-21-000026:mdna:135]

[0001571996-21-000040:mdna:133]
|  | Three Months Ended |  | Six Months Ended |
|  | July 30, 2021 |  | July 31, 2020 |  | July 30, 2021 |  | July 31, 2020 |
|  | (in millions) |
| Interest and other, net: |  |  |  |  |  |  |  |
| Investment income, primarily interest | $ | 10 |  |  | $ | 12 |  |  | $ | 21 |  |  | $ | 36 |  |
| Gain on investments, net | 168 |  |  | 8 |  |  | 325 |  |  | 102 |  |
| Interest expense | (483) |  |  | (617) |  |  | (993) |  |  | (1,289) |  |
| Foreign exchange | (64) |  |  | — |  |  | (113) |  |  | (99) |  |
| Other | 10 |  |  | (39) |  |  | 13 |  |  | 48 |  |
| Total interest and other, net | $ | (359) |  |  | $ | (636) |  |  | $ | (747) |  |  | $ | (1,202) |  |

[0001571996-21-000040:mdna:134]
During the second quarter and first six months of Fiscal 2022, the change in interest and other, net was favorable by $277 million and $455 million, respectively.  The favorability in both periods was primarily due to decreases in interest expense resulting from debt repayments and increases in net gains on our strategic investment portfolio.

[0001571996-21-000040:mdna:135]
[same as prior period, unchanged from 0001571996-21-000026:mdna:138]

[0001571996-21-000040:mdna:136]
[same as prior period, unchanged from 0001571996-21-000026:mdna:139]

[0001571996-21-000040:mdna:137]
|  | Three Months Ended |  | Six Months Ended |
|  | July 30, 2021 |  | July 31, 2020 |  | July 30, 2021 |  | July 31, 2020 |
|  | (in millions, except percentages) |  | (in millions, except percentages) |
| Income before income taxes | $ | 1,013 |  |  | $ | 500 |  |  | $ | 2,000 |  |  | $ | 636 |  |
| Income tax expense (benefit) | $ | 133 |  |  | $ | (599) |  |  | $ | 182 |  |  | $ | (645) |  |
| Effective income tax rate | 13.1 | % |  | -119.8 | % |  | 9.1 | % |  | -101.4 | % |

[0001571996-21-000040:mdna:138]
For the second quarter of Fiscal 2022 and Fiscal 2021, our effective income tax rate was 13.1%  and -119.8%, respectively.   For the first six months of Fiscal 2022 and Fiscal 2021, our effective income tax rate was 9.1% and -101.4%, respectively.  The changes in our effective income tax rate were primarily driven by lower discrete tax items on higher pre-tax income and a change in our jurisdictional mix of income.  For the first six months of Fiscal 2022, our effective income tax rate includes discrete tax benefits of $131 million related to stock-based compensation.  In comparison, for the first six months of Fiscal 2021, our effective income tax rate includes discrete tax benefits of $746 million related to an audit settlement that was recorded in the second quarter of that period.  The effective income tax rate for future quarters of Fiscal 2022 may be impacted by the actual mix of jurisdictions in which income is generated, as well as the impact of any discrete tax items.

[0001571996-21-000040:mdna:139]
Our effective income tax rate can fluctuate depending on the geographic distribution of our worldwide earnings, as our foreign earnings are generally taxed at lower rates than in the United States.  The differences between our effective income tax rate and the U.S. federal statutory rate of 21% principally result from the geographical distribution of income, differences between the book and tax treatment of certain items, and the discrete tax items discussed above.  In certain jurisdictions, our tax rate is significantly less than the applicable statutory rate as a result of tax holidays.  The majority of our foreign income that is subject to these tax holidays and lower tax rates is attributable to Singapore and China.  A significant portion of these income tax benefits relates to a tax holiday that will be effective until January 31, 2029.  Our other tax holidays will expire in whole or in part during Fiscal 2022 through Fiscal 2030.  Many of these tax holidays and reduced tax rates may be extended when certain conditions are met or may be terminated early if certain conditions are not met.  As of July 30, 2021, we were not aware of any matters of non-compliance related to these tax holidays.

[0001571996-21-000040:mdna:140]
[same as prior period, unchanged from 0001571996-21-000026:mdna:143]

[0001571996-21-000040:mdna:141]
[same as prior period, unchanged from 0001571996-21-000026:mdna:144]

[0001571996-21-000040:mdna:142]
During the second quarter of Fiscal 2022, net income decreased 20% to $0.9 billion, while net income increased 42% to $1.8 billion during the first six months of Fiscal 2022.  The decrease for the second quarter of Fiscal 2022 was primarily attributable to an increase in tax expense, partially offset by an increase in operating income and a favorable change in interest and other, net.  The increase during the first six months of Fiscal 2022 was as a result of an increase in operating income coupled with a favorable change in interest and other, net partially offset by an increase in tax expense. Non-GAAP net income increased 18% to $1.9 billion and 35% to $3.7 billion during the second quarter and first six months of Fiscal 2022, respectively.  The increase in non-GAAP net income during both the second quarter and first six months of Fiscal 2022 was primarily attributable to an increase in non-GAAP operating income coupled with a favorable change in interest and other, net.

[0001571996-21-000040:mdna:143]
[same as prior period, unchanged from 0001571996-21-000026:mdna:146]

[0001571996-21-000040:mdna:144]
Net income attributable to non-controlling interests consists of net income or loss attributable to our non-controlling interests in VMware, Inc. and Secureworks.  During the second quarter of Fiscal 2022 and Fiscal 2021, net income attributable to non-controlling interests was $49 million and $51 million, respectively.  The decrease in net income attributable to non-controlling interests during the second quarter of Fiscal 2022 was primarily due to a decrease in net income attributable to our non-controlling interest in VMware, Inc.

[0001571996-21-000040:mdna:145]
During the first six months of Fiscal 2022 and Fiscal 2021, net income attributable to non-controlling interests was $100 million and $90 million, respectively.  The increase in net income attributable to non-controlling interests during the first six months of Fiscal 2022 was primarily due to an increase in net income attributable to our non-controlling interest in VMware, Inc.  For more information about our non-controlling interests, see Note 12 of the Notes to the Condensed Consolidated Financial Statements included in this report.

[0001571996-21-000040:mdna:146]
[same as prior period, unchanged from 0001571996-21-000026:mdna:148]

[0001571996-21-000040:mdna:147]
Net income attributable to Dell Technologies Inc. represents net income and an adjustment for non-controlling interests.  During the second quarter of Fiscal 2022 and Fiscal 2021, net income attributable to Dell Technologies Inc. was $0.8 billion and $1.0 billion, respectively.  The decrease in net income attributable to Dell Technologies Inc. during the second quarter of Fiscal 2022 was primarily attributable to a decrease in net income for the period.  During the first six months of Fiscal 2022 and Fiscal 2021, net income attributable to Dell Technologies Inc. was $1.7 billion and $1.2 billion, respectively.  The increase in net income attributable to Dell Technologies Inc. during the first six months of Fiscal 2022 was primarily attributable to an increase in net income for the period.

[0001571996-21-000040:mdna:148]
[same as prior period, unchanged from 0001571996-21-000026:mdna:150]

[0001571996-21-000040:mdna:149]
[same as prior period, unchanged from 0001571996-21-000026:mdna:151]

[0001571996-21-000040:mdna:150]
[same as prior period, unchanged from 0001571996-21-000026:mdna:152]

[0001571996-21-000040:mdna:151]
[same as prior period, unchanged from 0001571996-21-000026:mdna:153]

[0001571996-21-000040:mdna:152]
|  | Three Months Ended |  | Six Months Ended |
|  | July 30, 2021 |  | % Change |  | July 31, 2020 |  | July 30, 2021 |  | % Change |  | July 31, 2020 |
|  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Servers and networking | $ | 4,462 |  |  | 6 | % |  | $ | 4,196 |  | $ | 8,571 |  | 8 | % |  | $ | 7,954 |
| Storage | 3,970 |  |  | (1) | % |  | 4,011 |  | 7,772 |  | (1) | % |  | 7,822 |
| Total ISG net revenue | $ | 8,432 |  |  | 3 | % |  | $ | 8,207 |  | $ | 16,343 |  | 4 | % |  | $ | 15,776 |
| Operating income: |  |  |  |  |  |  |  |  |  |  |  |
| ISG operating income | $ | 970 |  |  | — | % |  | $ | 973 |  | $ | 1,758 |  | 3 | % |  | $ | 1,705 |
| % of segment net revenue | 11.5 | % |  |  |  | 11.9 | % |  | 10.8 | % |  |  |  | 10.8 | % |

[0001571996-21-000040:mdna:153]
Net Revenue — During the second quarter and first six months of Fiscal 2022, ISG net revenue increased 3% and 4%, respectively.  These increases were due to improvements to the macroeconomic environment and a shift towards investment in IT infrastructure, focused on multi-cloud solutions and accelerating digital transformation, compared to a weaker demand environment during the second quarter and first six months of Fiscal 2021 as a result of COVID-19, when customers shifted their investments toward remote work and business continuity solutions.

[0001571996-21-000040:mdna:154]
Net revenue from sales of servers and networking increased 6% and 8% during the second quarter and first six months of Fiscal 2022, respectively, due to growing demand for our PowerEdge servers, partially offset by a decline in average selling price as a result of a mix shift within PowerEdge servers.

[0001571996-21-000040:mdna:155]
Storage revenue decreased 1% during both the second quarter and first six months of Fiscal 2022 primarily as a result of a weaker demand environment for our high-end storage offerings.  We are seeing improvements in the overall demand for our storage business, particularly in our midrange storage offerings, driven primarily by growth in our PowerStore storage array as well as hyper-converged infrastructure.

[0001571996-21-000040:mdna:156]
ISG customers are seeking new and innovative models that address how they consume our solutions.  We offer options including as-a-service, utility, leases, and immediate pay models, all designed to match customers’ consumption and financing preferences.  Our multiyear agreements typically result in recurring revenue streams over the term of the arrangement.  We expect our flexible consumption models and as-a-service offerings through Apex will further strengthen our customer relationships and provide a foundation for growth in recurring revenue.

[0001571996-21-000040:mdna:157]
From a geographical perspective, net revenue attributable to ISG increased in all regions during the second quarter and first six months of Fiscal 2022.

[0001571996-21-000040:mdna:158]
Operating Income — During the second quarter of Fiscal 2022, ISG operating income as a percentage of net revenue decreased 40 basis points to 11.5%.  The decrease was driven by an increase in ISG operating expenses as a percentage of net revenue, which was primarily attributable to employee compensation and benefit expense.

[0001571996-21-000040:mdna:159]
For the first six months of Fiscal 2022, ISG operating income as a percentage of net revenue remained flat at 10.8%.  ISG gross margin percentage decreased as a result of a mix shift within ISG towards servers and networking as well as a mix shift within storage towards midrange offerings.  The gross margin percentage decrease was offset by a decrease in operating expense as a percentage of net revenue.

[0001571996-21-000040:mdna:160]
78

[0001571996-21-000040:mdna:161]
[same as prior period, unchanged from 0001571996-21-000026:mdna:160]

[0001571996-21-000040:mdna:162]
[same as prior period, unchanged from 0001571996-21-000026:mdna:161]

[0001571996-21-000040:mdna:163]
|  | Three Months Ended |  | Six Months Ended |
|  | July 30, 2021 |  | % Change |  | July 31, 2020 |  | July 30, 2021 |  | % Change |  | July 31, 2020 |
|  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 10,573 |  | 32 | % |  | $ | 8,039 |  | $ | 20,376 |  |  | 22 | % |  | $ | 16,673 |  |
| Consumer | 3,690 |  | 17 | % |  | 3,164 |  | 7,192 |  |  | 28 | % |  | 5,634 |  |
| Total CSG net revenue | $ | 14,263 |  | 27 | % |  | $ | 11,203 |  | $ | 27,568 |  |  | 24 | % |  | $ | 22,307 |  |
| Operating income: |  |  |  |  |  |  |  |  |  |  |  |
| CSG operating income | $ | 995 |  | 39 | % |  | $ | 715 |  | $ | 2,085 |  |  | 60 | % |  | $ | 1,307 |  |
| % of segment net revenue | 7.0 | % |  |  |  | 6.4 | % |  | 7.6 | % |  |  |  | 5.9 | % |

[0001571996-21-000040:mdna:164]
Net Revenue — During the second quarter and first six months of Fiscal 2022, CSG net revenue increased 27% and 24%, respectively, driven by continued strong demand across the majority of product offerings as customers seek improved connectivity and productivity in the “do anything from anywhere” economy.

[0001571996-21-000040:mdna:165]
Commercial revenue increased 32% and 22% during the second quarter and first six months of Fiscal 2022, respectively, primarily due to an increase in sales of commercial desktops and notebooks driven by continued strong demand as customers invest in in-office, remote, and hybrid workforce environments.

[0001571996-21-000040:mdna:166]
Consumer revenue increased 17% and 28% during the second quarter and first six months of Fiscal 2022, respectively, primarily due to an increase in demand across the majority of consumer product offerings.

[0001571996-21-000040:mdna:167]
Average selling price also increased for both commercial and consumer offerings as we navigated through supply chain shortages and managed pricing in response to the shift to an overall inflationary component cost environment.

[0001571996-21-000040:mdna:168]
From a geographical perspective, net revenue attributable to CSG increased across all regions during the second quarter and first six months of Fiscal 2022.

[0001571996-21-000040:mdna:169]
Operating Income — During the second quarter and first six months of Fiscal 2022, CSG operating income as a percentage of net revenue increased 60 basis points to 7.0% and 170 basis points to 7.6%, respectively, which was primarily driven by both commercial and consumer gross margin percentage.  The increases in gross margin percentage were primarily driven by disciplined pricing as we managed through the component cost challenges discussed above.  For the second quarter of Fiscal 2022, the increase in gross margin percentage was further driven by a shift in mix towards commercial offerings.

[0001571996-21-000040:mdna:170]
[same as prior period, unchanged from 0001571996-21-000026:mdna:168]

[0001571996-21-000040:mdna:171]
[same as prior period, unchanged from 0001571996-21-000026:mdna:169]

[0001571996-21-000040:mdna:172]
|  | Three Months Ended |  | Six Months Ended |
|  | July 30, 2021 |  | % Change |  | July 31, 2020 |  | July 30, 2021 |  | % Change |  | July 31, 2020 |
|  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| VMware net revenue | $ | 3,148 |  | 8 | % |  | $ | 2,908 |  | $ | 6,139 |  |  | 8 | % |  | $ | 5,663 |  |
| Operating income: |  |  |  |  |  |  |  |  |  |  |  |
| VMware operating income | $ | 849 |  | (5) | % |  | $ | 894 |  | $ | 1,690 |  |  | 1 | % |  | $ | 1,667 |  |
| % of segment net revenue | 27.0 | % |  |  |  | 30.7 | % |  | 27.5 | % |  |  |  | 29.4 | % |

[0001571996-21-000040:mdna:173]
Net Revenue — VMware net revenue primarily consists of revenue from the sale of software licenses under perpetual licenses and subscription and SaaS offerings, as well as related software maintenance services, support, training, consulting services, and hosted services.  VMware net revenue for both the second quarter and first six months of Fiscal 2022 increased 8% primarily due to growth in sales of subscription and SaaS offerings, driven by increased demand for cloud offerings, coupled with growth in software maintenance revenue which continued to benefit from maintenance contracts sold in previous periods.

[0001571996-21-000040:mdna:174]
VMware net revenue for the second quarter and first six months of Fiscal 2022 increased in both the United States and internationally.

[0001571996-21-000040:mdna:175]
Operating Income — During the second quarter and first six months of Fiscal 2022, VMware operating income as a percentage of net revenue decreased 370 basis points to 27.0% and 190 basis points to 27.5%, respectively.  These decreases were due to a decline in VMware gross margin percentage and an increase in operating expense as a percentage of net revenue.  VMware gross margin percentage declined in part due to a transition towards subscription and SaaS offerings.  Operating expenses increased as a result of higher employee compensation expense primarily attributable to investments in key R&D initiatives, coupled with the reintroduction of expenses that were temporarily reduced in Fiscal 2021.

[0001571996-21-000040:mdna:176]
80

[0001571996-21-000040:mdna:177]
[same as prior period, unchanged from 0001571996-21-000026:mdna:175]

[0001571996-21-000040:mdna:178]
[same as prior period, unchanged from 0001571996-21-000026:mdna:176]

[0001571996-21-000040:mdna:179]
We sell products and services directly to customers and through a variety of sales channels, including retail distribution.  Our accounts receivable, net, was $12.9 billion and $12.8 billion as of July 30, 2021 and January 29, 2021, respectively.  We maintain an allowance for expected credit losses to cover receivables that may be deemed uncollectible.  The allowance for expected credit losses is an estimate based on an analysis of historical loss experience, current receivables aging, management’s assessment of current conditions and reasonable and supportable expectation of future conditions, and specific identifiable customer accounts that are deemed at risk.  Given this uncertainty, our allowance for expected credit losses in future periods may vary from our current estimates.  As of July 30, 2021 and January 29, 2021, the allowance for expected credit losses was $98 million and $104 million, respectively.  Based on our assessment, we believe that we are adequately reserved for expected credit losses.  We will continue to monitor the aging of our accounts receivable and take actions, where necessary, to reduce our exposure to credit losses.

[0001571996-21-000040:mdna:180]
[same as prior period, unchanged from 0001571996-21-000026:mdna:178]

[0001571996-21-000040:mdna:181]
Dell Financial Services and its affiliates (“DFS”) support Dell Technologies by offering and arranging various financing options and services for our customers globally, including through captive financing operations in North America, Europe, Australia, and New Zealand.  DFS originates, collects, and services customer receivables primarily related to the purchase of our product, software, and service solutions.  DFS further strengthens our customer relationships through its flexible consumption models, provided through Apex, which enable us to offer our customers the option to pay over time and, in certain cases, based on utilization, to provide them with financial flexibility to meet their changing technological requirements.  New financing originations were $1.9 billion and $2.6 billion for the second quarter of Fiscal 2022 and Fiscal 2021, respectively, and $3.8 billion and $4.4 billion for the first six months of Fiscal 2022 and Fiscal 2021, respectively.

[0001571996-21-000040:mdna:182]
DFS leases are classified as sales-type leases, direct financing leases, or operating leases.  Amounts due from lessees under sales-type leases or direct financing leases are recorded as part of financing receivables, with interest income recognized over the contract term.  On commencement of sales-type leases, we typically qualify for up-front revenue recognition.  On originations of operating leases, we record equipment under operating leases, classified as property, plant, and equipment, and recognize rental revenue and depreciation expense, classified as cost of net revenue, over the contract term.  Direct financing leases are immaterial.  Leases that commenced prior to the effective date of the current lease accounting standard continue to be accounted for under previous lease accounting guidance.

[0001571996-21-000040:mdna:183]
As of July 30, 2021 and January 29, 2021, our financing receivables, net were $10.3 billion and $10.5 billion, respectively.  We maintain an allowance to cover expected financing receivable credit losses and evaluate credit loss expectations based on our total portfolio.  Our allowance for expected credit losses in future periods may vary from our current estimates.  For the second quarter of Fiscal 2022 and Fiscal 2021, the principal charge-off rate for our financing receivables portfolio was 0.5% and 0.8%, respectively.  For the first six months of Fiscal 2022 and Fiscal 2021, the principal charge-off rate for our total portfolio was 0.5% and 0.9%, respectively.  The credit quality of our financing receivables has improved in recent years due to an overall improvement in the credit environment and as the mix of high-quality commercial accounts in our portfolio has continued to increase.  We continue to monitor broader economic indicators and their potential impact on future loss performance.  We have an extensive process to manage our exposure to customer credit risk, including active management of credit lines and our collection activities.  We also sell selected fixed-term financing receivables without recourse to unrelated third parties on a periodic basis, primarily to manage certain concentrations of customer credit exposure.  Based on our assessment of the customer financing receivables, we believe that we are adequately reserved.

[0001571996-21-000040:mdna:184]
We retain a residual interest in equipment leased under our fixed-term lease programs.  As of July 30, 2021 and January 29, 2021, the residual interest recorded as part of financing receivables was $319 million and $424 million, respectively.  The amount of the residual interest is established at the inception of the lease based upon estimates of the value of the equipment at the end of the lease term using historical studies, industry data, and future value-at-risk demand valuation methods.  We assess the carrying amount of our recorded residual values for expected losses.  Generally, expected losses as a result of residual value risk on equipment under lease are not considered to be significant primarily because of the existence of a secondary market with respect to the equipment.  The lease agreement also clearly defines applicable return conditions and remedies for non-compliance to ensure that the leased equipment will be in good operating condition upon return.  Model changes and updates, as well as market strength and product acceptance, are monitored and adjustments are made to residual values in accordance with the significance of any such changes.  To mitigate our exposure, we work closely with customers and dealers to manage the sale of returned assets.  No material expected losses were recorded related to residual assets during the second quarter and first six months of Fiscal 2022 and Fiscal 2021.

[0001571996-21-000040:mdna:185]
As of July 30, 2021 and January 29, 2021, equipment under operating leases, net was $1.4 billion and $1.3 billion, respectively.  Based on triggering events, we assess the carrying amount of the equipment under operating leases recorded for impairment.  No material impairment losses were recorded related to such equipment during the second quarter and first six months of Fiscal 2022 and Fiscal 2021.

[0001571996-21-000040:mdna:186]
[same as prior period, unchanged from 0001571996-21-000026:mdna:184]

[0001571996-21-000040:mdna:187]
[same as prior period, unchanged from 0001571996-21-000026:mdna:185]

[0001571996-21-000040:mdna:188]
[same as prior period, unchanged from 0001571996-21-000026:mdna:186]

[0001571996-21-000040:mdna:189]
As of July 30, 2021, we had no off-balance sheet arrangements that have or are reasonably likely to have a current or future material effect on our financial condition or results of operations.

[0001571996-21-000040:mdna:190]
[same as prior period, unchanged from 0001571996-21-000026:mdna:188]

[0001571996-21-000040:mdna:191]
[same as prior period, unchanged from 0001571996-21-000026:mdna:189]

[0001571996-21-000040:mdna:192]
[same as prior period, unchanged from 0001571996-21-000026:mdna:190]

[0001571996-21-000040:mdna:193]
[same as prior period, unchanged from 0001571996-21-000026:mdna:191]

[0001571996-21-000040:mdna:194]
[same as prior period, unchanged from 0001571996-21-000026:mdna:192]

[0001571996-21-000040:mdna:195]
[same as prior period, unchanged from 0001571996-21-000026:mdna:193]

[0001571996-21-000040:mdna:196]
[same as prior period, unchanged from 0001571996-21-000026:mdna:194]

[0001571996-21-000040:mdna:197]
[same as prior period, unchanged from 0001571996-21-000026:mdna:195]

[0001571996-21-000040:mdna:198]
[same as prior period, unchanged from 0001571996-21-000026:mdna:196]

[0001571996-21-000040:mdna:199]
[same as prior period, unchanged from 0001571996-21-000026:mdna:197]

[0001571996-21-000040:mdna:200]
|  | July 30, 2021 |  | January 29, 2021 |
|  | (in millions) |
| Cash and cash equivalents, and available borrowings: |  |  |  |
| Cash and cash equivalents (a) | $ | 11,719 |  |  | $ | 14,201 |  |
| Remaining available borrowings under revolving credit facilities (b) | 5,463 |  |  | 5,467 |  |
| Total cash, cash equivalents, and available borrowings | $ | 17,182 |  |  | $ | 19,668 |  |

[0001571996-21-000040:mdna:201]
[same as prior period, unchanged from 0001571996-21-000026:mdna:199]

[0001571996-21-000040:mdna:202]
(a)    Of the $11.7 billion of cash and cash equivalents as of July 30, 2021, $5.9 billion was held by VMware, Inc.

[0001571996-21-000040:mdna:203]
(b)    Of the $5.5 billion of remaining available borrowings under revolving credit facilities, $1.0 billion was attributable to the VMware Revolving Credit Facility.

[0001571996-21-000040:mdna:204]
Our revolving credit facilities as of July 30, 2021 consist of the Revolving Credit Facility and the VMware Revolving Credit Facility.  The Revolving Credit Facility has a maximum aggregate borrowing capacity of $4.5 billion, and available borrowings under this facility are reduced by draws on the facility and outstanding letters of credit.  As of July 30, 2021, there were no borrowings outstanding under the facility.  Borrowings under the Revolving Credit Facility are used for general corporate purposes on a short-term basis.

[0001571996-21-000040:mdna:205]
[same as prior period, unchanged from 0001571996-21-000026:mdna:228]

[0001571996-21-000040:mdna:206]
The VMware Revolving Credit Facility has a maximum capacity of $1.0 billion.  As of July 30, 2021, there were no outstanding borrowings under the facility.  None of the net proceeds of borrowings under the VMware Revolving Credit Facility will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.

[0001571996-21-000040:mdna:207]
[same as prior period, unchanged from 0001571996-21-000026:mdna:204]

[0001571996-21-000040:mdna:208]
[same as prior period, unchanged from 0001571996-21-000026:mdna:205]

[0001571996-21-000040:mdna:209]
[same as prior period, unchanged from 0001571996-21-000026:mdna:206]

[0001571996-21-000040:mdna:210]
[same as prior period, unchanged from 0001571996-21-000026:mdna:207]

[0001571996-21-000040:mdna:211]
|  | July 30, 2021 |  | Increase (decrease) |  | January 29, 2021 |
|  | (in millions) |
| Core debt |  |  |  |  |  |
| Senior Secured Credit Facilities and First Lien Notes | $ | 24,761 |  |  | $ | (16) |  |  | $ | 24,777 |  |
| Unsecured Notes and Debentures | 952 |  |  | (400) |  |  | 1,352 |  |
| Senior Notes | 1,625 |  |  | (1,075) |  |  | 2,700 |  |
| EMC Notes | 1,000 |  |  | — |  |  | 1,000 |  |
| DFS allocated debt | (700) |  |  | (34) |  |  | (666) |  |
| Total core debt | 27,638 |  |  | (1,525) |  |  | 29,163 |  |
| DFS related debt |  |  |  |  |  |
| DFS debt | 9,557 |  |  | (109) |  |  | 9,666 |  |
| DFS allocated debt | 700 |  |  | 34 |  |  | 666 |  |
| Total DFS related debt | 10,257 |  |  | (75) |  |  | 10,332 |  |
| Margin Loan Facility and other | 1,392 |  |  | (2,843) |  |  | 4,235 |  |
| Debt of public subsidiary |  |  |  |  |  |
| VMware Notes | 4,750 |  |  | — |  |  | 4,750 |  |
| Total public subsidiary debt | 4,750 |  |  | — |  |  | 4,750 |  |
| Total debt, principal amount | 44,037 |  |  | (4,443) |  |  | 48,480 |  |
| Carrying value adjustments | (443) |  |  | 53 |  |  | (496) |  |
| Total debt, carrying value | $ | 43,594 |  |  | $ | (4,390) |  |  | $ | 47,984 |  |

[0001571996-21-000040:mdna:212]
During the first six months of Fiscal 2022, the outstanding principal amount of our debt decreased by $4.4 billion to $44.0 billion as of July 30, 2021, primarily as a result of principal repayments, including $3.0 billion principal amount of the Margin Loan Facility paid in the second quarter of Fiscal 2022.

[0001571996-21-000040:mdna:213]
We define core debt as the total principal amount of our debt, less DFS related debt, our Margin Loan Facility and other debt, and public subsidiary debt.  Our core debt was $27.6 billion as of July 30, 2021.  During the first six months of Fiscal 2022, the decrease in our core debt was driven by principal repayments, including $1,075 million principal amount of our 5.875% Senior Notes due June 2021 and $400 million principal amount of our 4.625% Unsecured Notes due April 2021.  There are no scheduled maturities of core debt for the remainder of Fiscal 2022.  See Note 5 of the Notes to the Condensed Consolidated Financial Statements included in this report for more information about our debt.

[0001571996-21-000040:mdna:214]
[same as prior period, unchanged from 0001571996-21-000026:mdna:240]

[0001571996-21-000040:mdna:215]
As of July 30, 2021, Margin Loan Facility and other debt primarily consisted of the $1.0 billion Margin Loan Facility.  As described above, during the first six months of July 30, 2021, we repaid $3.0 billion principal amount of the Margin Loan Facility.  Subsequent to July 30, 2021, we repaid the remaining $1.0 billion principal amount. See Note 18 of the Notes to the Condensed Consolidated Financial Statements included in this report for more information.

[0001571996-21-000040:mdna:216]
[same as prior period, unchanged from 0001571996-21-000026:mdna:211]

[0001571996-21-000040:mdna:217]
[same as prior period, unchanged from 0001571996-21-000026:mdna:212]

[0001571996-21-000040:mdna:218]
Public subsidiary debt represents VMware, Inc. indebtedness.  VMware, Inc. and its respective subsidiaries are unrestricted subsidiaries for purposes of the core debt of Dell Technologies.  Neither Dell Technologies nor any of its subsidiaries, other than VMware, Inc., is obligated to make payment on the VMware Notes.  None of the net proceeds of the VMware Notes will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and its subsidiaries.   See Note 5 of the Notes to the Condensed Consolidated Financial Statements included in this report for more information about VMware, Inc. debt.

[0001571996-21-000040:mdna:219]
In connection with the planned VMware Spin-off announced on April 14, 2021, VMware, Inc. intends to pay a cash dividend, pro rata, to each of the holders of VMware, Inc. common stock in an aggregate amount equal to an amount to be mutually agreed by Dell Technologies and VMware, Inc. between $11.5 billion and $12.0 billion.  Subsequent to July 30, 2021, VMware, Inc. completed a public offering of unsecured senior notes in the aggregate principal amount of $6.0 billion, and expects to fund the cash dividend, in part, with proceeds from its new indebtedness for such purpose.  The transaction is expected to close during the fourth quarter of calendar 2021, subject to certain closing conditions.  Upon the closing of the transaction, we intend to use the net proceeds from our pro rata share of the cash dividend to repay debt as part of our capital strategy to position Dell Technologies for investment grade ratings.  See Note 1 of the Notes to the Condensed Consolidated Financial Statements included in this report for more information about the planned VMware Spin-off.  See Note 18 of the Notes to the Condensed Consolidated Financial Statements included in this report for more information about the VMware, Inc. debt issuance.

[0001571996-21-000040:mdna:220]
We have made steady progress in paying down debt and we will continue to focus on deleveraging.  We believe we will continue to be able to make our debt principal and interest payments, including the short-term maturities, from existing and expected sources of cash, primarily from operating cash flows.  Cash used for debt principal and interest payments may also include short-term borrowings under our revolving credit facilities.  Under our variable-rate debt, we could experience variations in our future interest expense from potential fluctuations in applicable reference rates, or from possible fluctuations in the level of DFS debt required to meet future demand for customer financing.  We or our affiliates or their related persons, at our or their sole discretion and without public announcement, may purchase, redeem, prepay, refinance, or otherwise retire any amount of our outstanding indebtedness under the terms of such indebtedness at any time and from time to time, in open market or negotiated transactions with the holders of such indebtedness or otherwise, as appropriate market conditions exist.

[0001571996-21-000040:mdna:221]
[same as prior period, unchanged from 0001571996-21-000026:mdna:217]

[0001571996-21-000040:mdna:222]
[same as prior period, unchanged from 0001571996-21-000026:mdna:218]

[0001571996-21-000040:mdna:223]
|  | Six Months Ended |
|  | July 30, 2021 |  | July 31, 2020 |
|  | (in millions) |
| Net change in cash from: |  |  |  |
| Operating activities | $ | 3,963 |  |  | $ | 2,536 |  |
| Investing activities | (1,188) |  |  | (1,409) |  |
| Financing activities | (5,311) |  |  | 827 |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash | (21) |  |  | (52) |  |
| Change in cash, cash equivalents, and restricted cash | $ | (2,557) |  |  | $ | 1,902 |  |

[0001571996-21-000040:mdna:224]
Operating Activities — Cash provided by operating activities was $4.0 billion for the first six months of Fiscal 2022 compared to cash provided by operating activities of $2.5 billion for the first six months of Fiscal 2021.  The increase in operating cash flows during the first six months of Fiscal 2022 was primarily driven by strong profitability coupled with favorable working capital dynamics, compared to unfavorable working capital impacts in the first six months of Fiscal 2021 related to the COVID-19 pandemic.

[0001571996-21-000040:mdna:225]
DFS offerings are initially funded through cash on hand at the time of origination, most of which is subsequently replaced with third-party financing.  For DFS offerings which qualify as sales-type leases, the initial funding of financing receivables is reflected as an impact to cash flows from operations, and is largely subsequently offset by cash proceeds from financing activities.  For DFS operating leases, which have increased under the current leasing standard, the initial funding is classified as a capital expenditure and reflected as cash flows used in investing activities.  DFS new financing originations were $3.8 billion  and $4.4 billion during the first six months of Fiscal 2022 and Fiscal 2021, respectively.  As of July 30, 2021, DFS had $10.3 billion of financing receivables, net and $1.4 billion of equipment under operating leases, net.

[0001571996-21-000040:mdna:226]
Investing Activities — Investing activities primarily consist of cash used to fund capital expenditures for property, plant, and equipment, which includes equipment under operating leases, as well as capitalized software development costs, acquisitions, strategic investments, and the maturities, sales, and purchases of investments.  During the first six months of Fiscal 2022, cash used in investing activities was $1.2 billion and was primarily driven by capital expenditures.  In comparison, cash used in investing activities was $1.4 billion during the first six months of Fiscal 2021 and was primarily driven by capital expenditures and acquisitions of businesses by our public subsidiaries.

[0001571996-21-000040:mdna:227]
Financing Activities — Financing activities primarily consist of the proceeds and repayments of debt, cash used to repurchase common stock, and proceeds from the issuance of common stock.  Cash used in financing activities was $5.3 billion during the first six months of Fiscal 2022 and primarily consisted of debt repayments and repurchases of common stock by our public subsidiaries, partially offset by net proceeds of DFS debt.  In comparison, cash provided by financing activities of $0.8 billion during the first six months of Fiscal 2021 primarily consisted of cash proceeds from the issuances of multiple series of First Lien Notes and VMware Notes, partially offset by debt repayments and repurchases of common stock by our public subsidiaries.

[0001571996-21-000040:mdna:228]
[same as prior period, unchanged from 0001571996-21-000026:mdna:224]

[0001571996-21-000040:mdna:229]
Capital Expenditures — During the first six months of Fiscal 2022 and Fiscal 2021, we spent $1.3 billion and $1.1 billion, respectively, on property, plant, and equipment and capitalized software development costs.  Product demand, product mix, and the use of contract manufacturers, as well as ongoing investments in operating and IT infrastructure and software development, influence the level and prioritization of our capital expenditures.  Aggregate capital expenditures for Fiscal 2022 are currently expected to total between $2.7 billion and $2.9 billion, of which approximately $0.9 billion is expected to be expended for equipment under operating leases and approximately $0.3 billion for capitalized software development costs.

[0001571996-21-000040:mdna:230]
[same as prior period, unchanged from 0001571996-21-000026:mdna:252]

[0001571996-21-000040:mdna:231]
[same as prior period, unchanged from 0001571996-21-000026:mdna:226]

[0001571996-21-000040:mdna:232]
[same as prior period, unchanged from 0001571996-21-000026:mdna:227]

[0001571996-21-000040:mdna:233]
As of July 30, 2021, purchase obligations were $5.2 billion, $0.6 billion, and $0.9 billion for the remaining six months of Fiscal 2022, Fiscal 2023, and Fiscal 2024 and thereafter, respectively.

[0001571996-21-000040:mdna:234]
87

[0001571996-21-000040:mdna:235]
[same as prior period, unchanged from 0001571996-21-000026:mdna:229]

[0001571996-21-000040:mdna:236]
As discussed in Note 5 of the Notes to the Condensed Consolidated Financial Statements included in this report, Dell International L.L.C. and EMC Corporation (the “Issuers”), both of which are wholly-owned subsidiaries of Dell Technologies, completed private offerings of multiple series of senior secured notes issued on June 1, 2016, March 20, 2019, and April 9, 2020 (collectively, the “First Lien Notes”).  On May 17, 2021, the Issuers launched an exchange offer of the outstanding First Lien Notes for registered senior secured notes with substantially similar terms (the “Exchange Notes”).  In June 2021, the Issuers completed the exchange offer and issued an aggregate of $18.4 billion principal amount of Exchange Notes in exchange for the same principal amount of First Lien Notes.  As of July 30, 2021, the aggregate principal amount of unregistered First Lien Notes remaining outstanding following the settlement of the exchange offer was approximately $0.1 billion.

[0001571996-21-000040:mdna:237]
Guarantees — The Exchange Notes are guaranteed on a joint and several unsecured basis by Dell Technologies and on a joint and several secured basis by Denali Intermediate, Inc. (“Denali Intermediate”), Dell and each of Denali Intermediate’s wholly-owned domestic subsidiaries that guarantees the Issuers’ Senior Credit Facility obligations (collectively, the “Guarantors”).  Not all of Denali Intermediate’s subsidiaries guarantee the Exchange Notes, including none of Denali Intermediate’s non-wholly-owned subsidiaries, foreign subsidiaries, receivables subsidiaries and subsidiaries designated as unrestricted subsidiaries under the  Senior Credit Facility (such non-guarantor subsidiaries, collectively, the “Non-Guarantor Subsidiaries”).  SecureWorks Corp., Boomi, Inc., Virtustream, Inc., VMware, Inc., EMC Equity Assets LLC and VMW Holdco L.L.C. (collectively, the “Unrestricted Subsidiaries”) have been designated as unrestricted subsidiaries under the Senior Credit Facility and therefore do not guarantee the Exchange Notes or the Senior Credit Facility obligations.  See Exhibit 22.1 incorporated by reference to this report for a list of subsidiary guarantors and issuers of guaranteed securities.

[0001571996-21-000040:mdna:238]
The guarantees are full and unconditional, subject to certain customary release provisions.  The indentures that govern the Exchange Notes provide that guarantees by subsidiaries of Denali Intermediate may be released in the event, among other things, (i) such Guarantor is sold or sells all of its assets in compliance with the applicable provisions of the indentures; (ii) such Guarantor is released from its guaranty under the Senior Credit Facility, including the declaration of such subsidiary as “unrestricted” under the Senior Credit Facility; (iii) the merger, amalgamation or consolidation, or liquidation, of such Guarantor; or (iv) the achievement of investment grade ratings with respect to the Issuers and the Exchange Notes.  In addition, all Guarantors will be released from their guarantees if the requirements for legal defeasance or covenant defeasance or to discharge the indentures have been satisfied.

[0001571996-21-000040:mdna:239]
[same as prior period, unchanged from 0001571996-21-000026:mdna:233]

[0001571996-21-000040:mdna:240]
[same as prior period, unchanged from 0001571996-21-000026:mdna:234]

[0001571996-21-000040:mdna:241]
|  | Six Months Ended |
|  | July 30, 2021 |
|  | (in millions) |
| Net revenue (a) | $ | 11,755 |  |
| Gross margin (b) | $ | 4,257 |  |
| Operating loss (c) | $ | (438) |  |
| Interest and other, net | (547) |  |
| Loss before income taxes | $ | (985) |  |
| Net loss attributable to Obligor Group | $ | (799) |  |

[0001571996-21-000040:mdna:242]
[same as prior period, unchanged from 0001571996-21-000026:mdna:236]

[0001571996-21-000040:mdna:243]
(a)  Includes net revenue from services provided and product sales to Non-Guarantor Subsidiaries of $1,341 million and $84 million, respectively.

[0001571996-21-000040:mdna:244]
(b)  Includes cost of net revenue from resale of solutions purchased from Non-Guarantor Subsidiaries of $1,189 million.

[0001571996-21-000040:mdna:245]
(c)  Includes operating expenses from shared services provided by Non-Guarantor Subsidiaries of $38 million.

[0001571996-21-000040:mdna:246]
[same as prior period, unchanged from 0001571996-21-000026:mdna:241]

[0001571996-21-000040:mdna:247]
|  | July 30, 2021 |  | January 29, 2021 |
|  | (in millions) |
| ASSETS |
| Current assets | $ | 12,579 |  |  | $ | 12,096 |  |
| Goodwill and intangible assets | 15,786 |  |  | 16,213 |  |
| Other non-current assets | 6,621 |  |  | 6,178 |  |
| Intercompany loan receivables | 3,477 |  |  | 4,714 |  |
| Total assets | $ | 38,463 |  |  | $ | 39,201 |  |
| LIABILITIES |
| Current liabilities | $ | 15,605 |  |  | $ | 15,736 |  |
| Intercompany payables | 4,619 |  |  | 5,527 |  |
| Total current liabilities | 20,224 |  |  | 21,263 |  |
| Long-term debt | 27,917 |  |  | 27,951 |  |
| Other non-current liabilities | 7,925 |  |  | 7,549 |  |
| Total liabilities | $ | 56,066 |  |  | $ | 56,763 |  |

[0001571996-21-000040:mdna:248]
[same as prior period, unchanged from 0001571996-21-000026:mdna:243]

[0001571996-21-000040:mdna:249]
The equity interests of various affiliates within Dell Technologies’ consolidated group have been pledged as collateral for the Exchange Notes.  Dell Technologies is therefore subject to Rule 13-02 of the SEC’s Regulation S-X, which requires that summarized financial information for the affiliates whose securities are pledged as collateral (collectively, the “Affiliate Group”) be provided on a combined basis to the extent such information is material and materially different than the corresponding amounts presented in the Consolidated Financial Statements of Dell Technologies.  The summarized financial information for the Affiliate Group would produce results materially consistent with information presented in Dell Technologies’ Consolidated Financial Statements and we have therefore not included such information in this report.  In particular, the assets, liabilities, and results of operations of the Affiliate Group are not materially different than the corresponding amounts presented in the Consolidated Financial Statements of Dell Technologies, except with respect to the redeemable shares as of January 29, 2021.  The redeemable shares balance was $472 million as reflected on the Condensed Consolidated Statements of Financial Position included in this report, as compared to no redeemable shares reflected on the Affiliate Group balance sheet as of the respective dates.

[0001571996-21-000040:mdna:250]
[same as prior period, unchanged from 0001571996-21-000026:mdna:245]

[0001571996-21-000040:mdna:251]
•100% of the equity interests of the Issuers, Dell and each Material Subsidiary (as defined in the applicable indenture) that is a wholly-owned subsidiary of the Issuers and the Guarantors (which pledge, in the case of capital stock of any Foreign Subsidiary or FSHCO (each as defined in the applicable indenture), is limited to 65% of the voting capital stock and 100% of the non-voting capital stock of such Foreign Subsidiary or FSHCO); and

[0001571996-21-000040:mdna:252]
[same as prior period, unchanged from 0001571996-21-000026:mdna:247]

[0001571996-21-000040:mdna:253]
See Exhibit 22.1 incorporated by reference to this report for a list of each affiliate of Dell Technologies whose security is pledged as collateral to secure the Exchange Notes.  There is no trading market for the applicable affiliates’ securities pledged as collateral.

[0001571996-21-000040:mdna:254]
Delivery of the Collateral securing the Exchange Notes would be required in certain customary events of default, including failure to make required payments, failure to comply with covenants, and the occurrence of certain events of bankruptcy and insolvency.

[0001571996-21-000040:mdna:255]
The Collateral may be released in certain circumstances, including, (i) to enable the sale, transfer or other disposition of such property or assets, (ii) upon the release of the guarantee of a Guarantor, (iii) upon such property or asset becoming an “excluded asset” as defined in the indentures governing the Exchange Notes, (iv) upon the achievement of investment grade ratings with respect to the Issuers and the Exchange Notes, and (v) to the extent the liens on the Collateral securing the Senior Credit Facility obligations are released (other than in connection with the payment in full of the Senior Credit Facility).

[0001571996-21-000040:mdna:256]
The Collateral does not include, and will not include, among other things, (i) a pledge of the assets or equity interests of certain subsidiaries, including the Unrestricted Subsidiaries and their respective subsidiaries, (ii) any fee-owned real property with a book value of less than $150 million, (iii) any commercial tort claims or letter of credit rights with an individual value of less than $50 million, (iv) any “principal property” as defined in the indentures governing the Unsecured Notes and Debentures of Dell and the EMC Notes, and capital stock of any subsidiary holding “principal property” as defined in the indenture governing the Unsecured Notes and Debentures of Dell, or (v) certain excluded assets.

[0001571996-21-000040:mdna:257]
90
