# DELL notes — 0001571996-23-000046


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001571996-23-000046:notes:1]
Basis of Presentation — The accompanying unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes filed with the U.S. Securities and Exchange Commission (“SEC”) in the Company’s Annual Report on Form 10-K for the fiscal year ended February 3, 2023.  These Condensed Consolidated Financial Statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“GAAP”).  In the opinion of management, the accompanying Condensed Consolidated Financial Statements reflect all adjustments of a normal recurring nature considered necessary to fairly state the financial position of the Company as of November 3, 2023 and February 3, 2023, the results of its operations, corresponding comprehensive income, and changes in stockholders’ equity for the three and nine months ended November 3, 2023 and October 28, 2022, and its cash flows for the nine months ended November 3, 2023 and October 28, 2022.

[0001571996-23-000046:notes:2]
The preparation of financial statements in accordance with GAAP requires management to make estimates and assumptions that affect the amounts reported in the Condensed Consolidated Financial Statements and the accompanying Notes.  Actual results could differ materially from those estimates.  The results of the Company’s operations, corresponding comprehensive income, and changes in stockholders’ equity for the three and nine months ended November 3, 2023 and October 28, 2022, and its cash flows for the nine months ended November 3, 2023 and October 28, 2022 are not necessarily indicative of the results to be expected for the full fiscal year or for any other fiscal period.

[0001571996-23-000046:notes:3]
[same as prior period, unchanged from 0001571996-23-000032:notes:3]


## us-gaap:ConsolidationPolicyTextBlock

[0001571996-23-000046:notes:4]
[same as prior period, unchanged from 0001571996-23-000032:notes:4]


## us-gaap:FairValueDisclosuresTextBlock

[0001571996-23-000046:notes:5]
[same as prior period, unchanged from 0001571996-23-000032:notes:5]

[0001571996-23-000046:notes:6]
|  | November 3, 2023 |  | February 3, 2023 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | Quoted Prices in Active Markets for Identical Assets |  | Significant Other Observable Inputs |  | Significant Unobservable Inputs |  |  |  | Quoted Prices in Active Markets for Identical Assets |  | Significant Other Observable Inputs |  | Significant Unobservable Inputs |  |  |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 4,176 |  |  | $ | — |  |  | $ | — |  |  | $ | 4,176 |  |  | $ | 4,301 |  |  | $ | — |  |  | $ | — |  |  | $ | 4,301 |  |
| Marketable equity and other securities | 5 |  |  | — |  |  | — |  |  | 5 |  |  | 33 |  |  | — |  |  | — |  |  | 33 |  |
| Derivative instruments | — |  |  | 215 |  |  | — |  |  | 215 |  |  | — |  |  | 295 |  |  | — |  |  | 295 |  |
| Total assets | $ | 4,181 |  |  | $ | 215 |  |  | $ | — |  |  | $ | 4,396 |  |  | $ | 4,334 |  |  | $ | 295 |  |  | $ | — |  |  | $ | 4,629 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative instruments | $ | — |  |  | $ | 76 |  |  | $ | — |  |  | $ | 76 |  |  | $ | — |  |  | $ | 460 |  |  | $ | — |  |  | $ | 460 |  |
| Total liabilities | $ | — |  |  | $ | 76 |  |  | $ | — |  |  | $ | 76 |  |  | $ | — |  |  | $ | 460 |  |  | $ | — |  |  | $ | 460 |  |

[0001571996-23-000046:notes:7]
[same as prior period, unchanged from 0001571996-23-000032:notes:7]

[0001571996-23-000046:notes:8]
Money Market Funds — The Company’s investment in money market funds that are classified as cash equivalents hold underlying investments with a weighted average maturity of 90 days or less and are recognized at fair value.  The valuations of these securities are based on quoted prices in active markets for identical assets, when available, or pricing models whereby all significant inputs are observable or can be derived from or corroborated by observable market data.  The Company reviews security pricing and assesses money market fund liquidity on a quarterly basis.  As of November 3, 2023, the Company’s portfolio had no material exposure to money market funds with a fluctuating net asset value.

[0001571996-23-000046:notes:9]
[same as prior period, unchanged from 0001571996-23-000032:notes:9]

[0001571996-23-000046:notes:10]
[same as prior period, unchanged from 0001571996-23-000032:notes:10]

[0001571996-23-000046:notes:11]
Deferred Compensation Plans — The Company offers deferred compensation plans for eligible employees, which allow participants to defer a portion of their compensation.  Assets were the same as liabilities associated with the plans at approximately $194 million and $179 million as of November 3, 2023 and February 3, 2023, respectively, and are included in other assets and other liabilities on the Condensed Consolidated Statements of Financial Position.  The net impact to the Condensed Consolidated Statements of Income is not material since changes in the fair value of the assets substantially offset changes in the fair value of the liabilities.  As such, assets and liabilities associated with these plans have not been included in the recurring fair value table above.

[0001571996-23-000046:notes:12]
[same as prior period, unchanged from 0001571996-23-000032:notes:12]

[0001571996-23-000046:notes:13]
As of November 3, 2023 and February 3, 2023, the Company held strategic investments in non-marketable equity and other securities of $1.2 billion and $1.3 billion, respectively.  As these investments represent early-stage companies without readily determinable fair values, they are not included in the recurring fair value table above.  See Note 3 of the Notes to the Condensed Consolidated Financial Statements for additional information about the Company’s strategic investments.

[0001571996-23-000046:notes:14]
[same as prior period, unchanged from 0001571996-23-000032:notes:14]

[0001571996-23-000046:notes:15]
|  | November 3, 2023 |  | February 3, 2023 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Notes | $ | 16.0 |  |  | $ | 15.6 |  |  | $ | 18.1 |  |  | $ | 18.2 |  |
| Legacy Notes and Debentures | $ | 0.9 |  |  | $ | 0.9 |  |  | $ | 0.9 |  |  | $ | 1.0 |  |
| DFS Debt | $ | 9.6 |  |  | $ | 9.1 |  |  | $ | 10.3 |  |  | $ | 9.9 |  |

[0001571996-23-000046:notes:16]
[same as prior period, unchanged from 0001571996-23-000032:notes:16]


## us-gaap:InvestmentTextBlock

[0001571996-23-000046:notes:17]
[same as prior period, unchanged from 0001571996-23-000032:notes:17]

[0001571996-23-000046:notes:18]
As of both November 3, 2023 and February 3, 2023, total investments were $1.6 billion.

[0001571996-23-000046:notes:19]
[same as prior period, unchanged from 0001571996-23-000032:notes:19]

[0001571996-23-000046:notes:20]
[same as prior period, unchanged from 0001571996-23-000032:notes:20]

[0001571996-23-000046:notes:21]
[same as prior period, unchanged from 0001571996-23-000032:notes:21]

[0001571996-23-000046:notes:22]
[same as prior period, unchanged from 0001571996-23-000032:notes:22]

[0001571996-23-000046:notes:23]
|  | November 3, 2023 |  | February 3, 2023 |
|  | Cost |  | Unrealized Gain |  | Unrealized Loss |  | Carrying Value |  | Cost |  | Unrealized Gain |  | Unrealized Loss |  | Carrying Value |
|  | (in millions) |
| Marketable | $ | 12 |  |  | $ | 19 |  |  | $ | (26) |  |  | $ | 5 |  |  | $ | 56 |  |  | $ | 17 |  |  | $ | (40) |  |  | $ | 33 |  |
| Non-marketable | 729 |  |  | 666 |  |  | (149) |  |  | 1,246 |  |  | 714 |  |  | 651 |  |  | (100) |  |  | 1,265 |  |
| Total equity and other securities | $ | 741 |  |  | $ | 685 |  |  | $ | (175) |  |  | $ | 1,251 |  |  | $ | 770 |  |  | $ | 668 |  |  | $ | (140) |  |  | $ | 1,298 |  |

[0001571996-23-000046:notes:24]
[same as prior period, unchanged from 0001571996-23-000032:notes:24]

[0001571996-23-000046:notes:25]
[same as prior period, unchanged from 0001571996-23-000032:notes:25]

[0001571996-23-000046:notes:26]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 3, 2023 |  | October 28, 2022 |  | November 3, 2023 |  | October 28, 2022 |
|  | (in millions) |
| Marketable securities: |  |  |  |  |  |  |  |
| Unrealized gain | $ | — |  |  | $ | 50 |  |  | $ | 1 |  |  | $ | 57 |  |
| Unrealized loss | — |  |  | (10) |  |  | (23) |  |  | (29) |  |
| Net unrealized gain (loss) | — |  |  | 40 |  |  | (22) |  |  | 28 |  |
| Non-marketable securities: |  |  |  |  |  |  |  |
| Unrealized gain | 6 |  |  | — |  |  | 15 |  |  | 72 |  |
| Unrealized loss | (3) |  |  | (13) |  |  | (49) |  |  | (333) |  |
| Net unrealized gain (loss) (a) (b) | 3 |  |  | (13) |  |  | (34) |  |  | (261) |  |
| Net unrealized gain (loss) on equity and other securities | $ | 3 |  |  | $ | 27 |  |  | $ | (56) |  |  | $ | (233) |  |

[0001571996-23-000046:notes:27]
[same as prior period, unchanged from 0001571996-23-000032:notes:27]

[0001571996-23-000046:notes:28]
(a)    For the three months ended November 3, 2023, net gains on non-marketable securities are due to upward adjustments for observable price changes offset by losses primarily attributable to impairments.

[0001571996-23-000046:notes:29]
(b)    For the nine months ended November 3, 2023 and the three and nine months ended October 28, 2022, net unrealized losses on non-marketable securities were primarily attributable to impairments.  For the three and nine months ended October 28, 2022, the impairments on equity and other securities were generally in line with extended public equity market declines.

[0001571996-23-000046:notes:30]
[same as prior period, unchanged from 0001571996-23-000032:notes:29]

[0001571996-23-000046:notes:31]
The Company has fixed income debt securities carried at amortized cost which are primarily held as collateral for borrowings.  The Company intends to hold the investments to maturity.  As of November 3, 2023, the Company held $267 million in fixed income debt securities which will mature within one year and $43 million in fixed income debt securities which will mature within five years.

[0001571996-23-000046:notes:32]
[same as prior period, unchanged from 0001571996-23-000032:notes:31]

[0001571996-23-000046:notes:33]
|  | November 3, 2023 |  | February 3, 2023 |
|  | Cost |  | Unrealized Gain |  | Unrealized Loss |  | Carrying Value |  | Cost |  | Unrealized Gain |  | Unrealized Loss |  | Carrying Value |
|  | (in millions) |
| Fixed income debt securities | $ | 343 |  |  | $ | 59 |  |  | $ | (92) |  |  | $ | 310 |  |  | $ | 348 |  |  | $ | 65 |  |  | $ | (95) |  |  | $ | 318 |  |


## dell:CreditLossFinancialInstrumentLeasesDebtVariableInterestEntitiesAndCustomerReceivablesSalesTextBlock

[0001571996-23-000046:notes:34]
FINANCIAL SERVICES
The Company offers or arranges various financing options and alternative payment structures for its customers globally.  Alternative payment structures consist of various flexible consumption models, including utility, subscription, and as-a-Service models.

[0001571996-23-000046:notes:35]
Financing options are offered to our customers primarily through Dell Financial Services and its affiliates (“DFS”).  The Company also arranges financing for some of its customers in various countries where DFS does not currently operate as a captive enterprise.  The key activities of DFS include originating, collecting, and servicing customer financing arrangements primarily related to the purchase or use of Dell Technologies products and services.  In some cases, DFS also offers financing for the purchase of third-party technology products that complement the Dell Technologies portfolio of products and services.  New financing originations were $1.8 billion and $2.3 billion for the three months ended November 3, 2023 and October 28, 2022, respectively, and $6.0 billion and $6.7 billion for the nine months ended November 3, 2023 and October 28, 2022, respectively.

[0001571996-23-000046:notes:36]
The Company’s lease and loan arrangements with customers are aggregated primarily into the following categories:

[0001571996-23-000046:notes:37]
Fixed-term leases and loans — The Company enters into financing arrangements with customers who seek lease financing for equipment.  DFS leases are generally classified as sales-type leases or operating leases.  Leases with business customers have fixed terms of generally two to four years.

[0001571996-23-000046:notes:38]
The Company also offers fixed-term loans to qualified small businesses, large commercial accounts, governmental organizations, educational entities, and certain individual consumer customers.  These loans are repaid in equal payments including interest and have defined terms of generally three to five years.  The fair value of the fixed-term loan portfolio is determined using market observable inputs.  The carrying value of these loans approximates fair value.

[0001571996-23-000046:notes:39]
Revolving loans — Revolving loans offered under a private label credit financing program,  referred to as Dell Business Credit (“DBC”), provide qualified customers with a revolving credit line for the purchase of products and services offered by Dell Technologies.  The DBC product is primarily offered to small and medium-sized commercial customers.  Revolving loans in the United States bear interest at a variable annual percentage rate that is tied to the prime rate.  Based on historical payment patterns, revolving loan transactions are typically repaid within twelve months on average.  Due to the short-term nature of the revolving loan portfolio, the carrying value of the portfolio approximates fair value.

[0001571996-23-000046:notes:40]
Prior to the sale of the U.S. consumer revolving customer receivables portfolio described in Note 1 of the Notes to the Condensed Consolidated Financial Statements, the Company also offered private label credit financing under the Dell Preferred Account (“DPA”) program.  The DPA product was primarily offered to individual consumer customers.

[0001571996-23-000046:notes:41]
Flexible consumption models, as defined above, further enable the Company to offer its customers the option to pay over time to provide them with financial flexibility to meet their changing technological requirements.  Such models may result in identification of embedded lease arrangements that lead to the recognition of operating or sales-type leases.

[0001571996-23-000046:notes:42]
Financing Receivables

[0001571996-23-000046:notes:43]
The following table presents the components of the Company’s financing receivables segregated by portfolio segment as of the dates indicated:

[0001571996-23-000046:notes:44]
|  | November 3, 2023 |  | February 3, 2023 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Financing receivables, net: |  |  |  |  |  |  |  |  |  |  |  |
| Customer receivables, gross (a) (b) | $ | 172 |  |  | $ | 10,144 |  |  | $ | 10,316 |  |  | $ | 685 |  |  | $ | 10,293 |  |  | $ | 10,978 |  |
| Allowances for losses | (9) |  |  | (144) |  |  | (153) |  |  | (88) |  |  | (113) |  |  | (201) |  |
| Customer receivables, net | 163 |  |  | 10,000 |  |  | 10,163 |  |  | 597 |  |  | 10,180 |  |  | 10,777 |  |
| Residual interest | — |  |  | 150 |  |  | 150 |  |  | — |  |  | 142 |  |  | 142 |  |
| Financing receivables, net | $ | 163 |  |  | $ | 10,150 |  |  | $ | 10,313 |  |  | $ | 597 |  |  | $ | 10,322 |  |  | $ | 10,919 |  |
| Short-term | $ | 163 |  |  | $ | 4,377 |  |  | $ | 4,540 |  |  | $ | 597 |  |  | $ | 4,684 |  |  | $ | 5,281 |  |
| Long-term | $ | — |  |  | $ | 5,773 |  |  | $ | 5,773 |  |  | $ | — |  |  | $ | 5,638 |  |  | $ | 5,638 |  |

[0001571996-23-000046:notes:45]
(a)    Customer receivables, gross include amounts due from customers under revolving loans, fixed-term loans, fixed-term leases, and accrued interest.

[0001571996-23-000046:notes:46]
(b)    The decrease in revolving customer financing receivables is primarily attributable to the sale of the U.S. consumer revolving customer receivables portfolio described in Note 1 of the Notes to the Condensed Consolidated Financial Statements.

[0001571996-23-000046:notes:47]
The following table presents the changes in allowance for financing receivable losses for the periods indicated:

[0001571996-23-000046:notes:48]
|  | Three Months Ended |
|  | November 3, 2023 |  | October 28, 2022 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |  |  |  |  |  |  |  |  |  |  |  |
| Balances at beginning of period | $ | 9 |  |  | $ | 140 |  |  | $ | 149 |  |  | $ | 91 |  |  | $ | 92 |  |  | $ | 183 |  |
| Charge-offs, net of recoveries | (4) |  |  | (3) |  |  | (7) |  |  | (12) |  |  | (1) |  |  | (13) |  |
| Provision charged to income statement | 4 |  |  | 7 |  |  | 11 |  |  | 8 |  |  | 8 |  |  | 16 |  |
| Balances at end of period | $ | 9 |  |  | $ | 144 |  |  | $ | 153 |  |  | $ | 87 |  |  | $ | 99 |  |  | $ | 186 |  |

[0001571996-23-000046:notes:49]
|  | Nine Months Ended |
|  | November 3, 2023 |  | October 28, 2022 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |  |  |  |  |  |  |  |  |  |  |  |
| Balances at beginning of period | $ | 88 |  |  | $ | 113 |  |  | $ | 201 |  |  | $ | 102 |  |  | $ | 87 |  |  | $ | 189 |  |
| Charge-offs, net of recoveries | (37) |  |  | (5) |  |  | (42) |  |  | (37) |  |  | (5) |  |  | (42) |  |
| Provision charged to income statement | 32 |  |  | 36 |  |  | 68 |  |  | 22 |  |  | 17 |  |  | 39 |  |
| Other (a) | (74) |  |  | — |  |  | (74) |  |  | — |  |  | — |  |  | — |  |
| Balances at end of period | $ | 9 |  |  | $ | 144 |  |  | $ | 153 |  |  | $ | 87 |  |  | $ | 99 |  |  | $ | 186 |  |

[0001571996-23-000046:notes:50]
(a)    Other represents the derecognition of the allowance for financing receivable losses related to the sale of the U.S. consumer revolving customer receivables portfolio described in Note 1 of the Notes to the Condensed Consolidated Financial Statements.

[0001571996-23-000046:notes:51]
The Company recognizes an allowance for financing receivable losses, including both the lease receivable and unguaranteed residual, in an amount equal to the expected losses net of recoveries.  The allowance for financing receivable losses on the lease receivable is determined based on various factors, including lifetime expected losses determined using macroeconomic forecast assumptions and management judgments applicable to and through the expected life of the portfolios as well as past due receivables, receivable type, and customer risk profile.  The Company continues to monitor broader economic indicators and their potential impact on future credit loss performance.

[0001571996-23-000046:notes:52]
Aging

[0001571996-23-000046:notes:53]
The following table presents the aging of the Company’s customer financing receivables, gross, including accrued interest, segregated by class, as of the dates indicated:

[0001571996-23-000046:notes:54]
|  | November 3, 2023 |  | February 3, 2023 |
|  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |
|  | (in millions) |
| Revolving — DPA | $ | 5 |  |  | $ | — |  |  | $ | — |  |  | $ | 5 |  |  | $ | 457 |  |  | $ | 34 |  |  | $ | 17 |  |  | $ | 508 |  |
| Revolving — DBC | 146 |  |  | 17 |  |  | 4 |  |  | 167 |  |  | 154 |  |  | 19 |  |  | 4 |  |  | 177 |  |
| Fixed-term — Consumer and Commercial | 9,140 |  |  | 868 |  |  | 136 |  |  | 10,144 |  |  | 9,309 |  |  | 927 |  |  | 57 |  |  | 10,293 |  |
| Total customer receivables, gross | $ | 9,291 |  |  | $ | 885 |  |  | $ | 140 |  |  | $ | 10,316 |  |  | $ | 9,920 |  |  | $ | 980 |  |  | $ | 78 |  |  | $ | 10,978 |  |

[0001571996-23-000046:notes:55]
Aging is likely to fluctuate as a result of the variability in volume of large transactions entered into over the period, and the administrative processes that accompany those transactions.  Aging is also impacted by the timing of the Company’s fiscal period end date relative to calendar month-end customer payment due dates.  As a result of these factors, fluctuations in aging from period to period do not necessarily indicate a material change in the collectibility of the portfolio.

[0001571996-23-000046:notes:56]
Fixed-term consumer and commercial customer receivables are placed on non-accrual status if principal or interest is past due and considered delinquent, or if there is concern about the collectibility of a specific customer receivable.  The receivables identified as doubtful for collectibility may be classified as current for aging purposes.  Aged revolving portfolio customer receivables identified as delinquent are charged off.

[0001571996-23-000046:notes:57]
Credit Quality

[0001571996-23-000046:notes:58]
The following tables present customer receivables, gross, including accrued interest, by credit quality indicator, segregated by class, as of the dates indicated:

[0001571996-23-000046:notes:59]
|  | November 3, 2023 |
|  | Fixed-term — Consumer and Commercial |  |  |  |  |  |  |
|  | Fiscal Year of Origination |  |  |  |  |  |  |
|  | 2024 |  | 2023 |  | 2022 |  | 2021 |  | 2020 |  | Years Prior |  | Revolving — DPA |  | Revolving — DBC |  | Total |
|  | (in millions) |
| Higher | $ | 2,494 |  |  | $ | 2,195 |  |  | $ | 1,076 |  |  | $ | 499 |  |  | $ | 127 |  |  | $ | 3 |  |  | $ | 1 |  |  | $ | 42 |  |  | $ | 6,437 |  |
| Mid | 849 |  |  | 1,047 |  |  | 378 |  |  | 159 |  |  | 40 |  |  | 2 |  |  | 2 |  |  | 49 |  |  | 2,526 |  |
| Lower | 454 |  |  | 516 |  |  | 210 |  |  | 69 |  |  | 25 |  |  | 1 |  |  | 2 |  |  | 76 |  |  | 1,353 |  |
| Total | $ | 3,797 |  |  | $ | 3,758 |  |  | $ | 1,664 |  |  | $ | 727 |  |  | $ | 192 |  |  | $ | 6 |  |  | $ | 5 |  |  | $ | 167 |  |  | $ | 10,316 |  |

[0001571996-23-000046:notes:60]
|  | February 3, 2023 |
|  | Fixed-term — Consumer and Commercial |  |  |  |  |  |  |
|  | Fiscal Year of Origination |  |  |  |  |  |  |
|  | 2023 |  | 2022 |  | 2021 |  | 2020 |  | 2019 |  | Years Prior |  | Revolving — DPA |  | Revolving — DBC |  | Total |
|  | (in millions) |
| Higher | $ | 3,210 |  |  | $ | 1,805 |  |  | $ | 914 |  |  | $ | 343 |  |  | $ | 37 |  |  | $ | 1 |  |  | $ | 123 |  |  | $ | 44 |  |  | $ | 6,477 |  |
| Mid | 1,242 |  |  | 631 |  |  | 362 |  |  | 119 |  |  | 17 |  |  | 1 |  |  | 136 |  |  | 54 |  |  | 2,562 |  |
| Lower | 1,017 |  |  | 364 |  |  | 157 |  |  | 65 |  |  | 7 |  |  | 1 |  |  | 249 |  |  | 79 |  |  | 1,939 |  |
| Total | $ | 5,469 |  |  | $ | 2,800 |  |  | $ | 1,433 |  |  | $ | 527 |  |  | $ | 61 |  |  | $ | 3 |  |  | $ | 508 |  |  | $ | 177 |  |  | $ | 10,978 |  |

[0001571996-23-000046:notes:61]
The categories shown in the tables above segregate customer receivables based on the relative degrees of credit risk.  Credit quality indicators for DBC revolving and fixed-term accounts are generally updated on a periodic basis.

[0001571996-23-000046:notes:62]
For the DBC revolving receivables and fixed-term commercial receivables shown in the table above, an internal grading system is utilized that assigns a credit level score based on a number of considerations, including liquidity, operating performance, and industry outlook.  The grading criteria and classifications for the fixed-term products differ from those for the revolving products as loss experience varies between these product and customer groups.  The credit quality categories cannot be compared between the different classes as loss experience varies substantially between the classes.  Prior to the sale of the U.S. consumer revolving customer receivables revolving portfolio described in Note 1 of the Notes to the Condensed Consolidated Financial Statements, the Company made credit decisions based on proprietary scorecards, which included the customer’s credit history, payment history, credit usage, and other credit agency-related elements.  The higher quality category included prime accounts generally comparable to U.S. customer FICO scores of 720 or above.  The mid category represented mid-tier accounts that are comparable to U.S. customer FICO scores from 660 to 719.  The lower category represented accounts that are comparable to U.S. customer FICO scores below 660.

[0001571996-23-000046:notes:63]
Leases

[0001571996-23-000046:notes:64]
The following table presents net revenue, cost of net revenue, and gross margin recognized at the commencement date of sales-type leases for the periods indicated:

[0001571996-23-000046:notes:65]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 3, 2023 |  | October 28, 2022 |  | November 3, 2023 |  | October 28, 2022 |
|  | (in millions) |
| Net revenue — products | $ | 227 |  |  | $ | 207 |  |  | $ | 766 |  |  | $ | 646 |  |
| Cost of net revenue — products | 176 |  |  | 164 |  |  | 564 |  |  | 532 |  |
| Gross margin — products | $ | 51 |  |  | $ | 43 |  |  | $ | 202 |  |  | $ | 114 |  |

[0001571996-23-000046:notes:66]
The following table presents the future maturity of the Company’s fixed-term customer leases and associated financing payments, and reconciles the undiscounted cash flows to the customer receivables, gross recognized on the Condensed Consolidated Statement of Financial Position as of the date indicated:

[0001571996-23-000046:notes:67]
|  | November 3, 2023 |
|  | (in millions) |
| Fiscal 2024 (remaining three months) | $ | 809 |  |
| Fiscal 2025 | 2,221 |  |
| Fiscal 2026 | 1,712 |  |
| Fiscal 2027 | 971 |  |
| Fiscal 2028 and beyond | 388 |  |
| Total undiscounted cash flows | 6,101 |  |
| Fixed-term loans | 4,954 |  |
| Revolving loans | 172 |  |
| Less: Unearned income | (911) |  |
| Total customer receivables, gross | $ | 10,316 |  |

[0001571996-23-000046:notes:68]
Operating Leases

[0001571996-23-000046:notes:69]
The Company’s operating leases primarily consist of DFS captive fixed-term leases and contractually committed embedded leases identified within flexible consumption arrangements.

[0001571996-23-000046:notes:70]
The following table presents the components of the Company’s operating lease portfolio included in property, plant, and equipment, net as of the dates indicated:

[0001571996-23-000046:notes:71]
|  | November 3, 2023 |  | February 3, 2023 |
|  | (in millions) |
| Equipment under operating lease, gross | $ | 3,855 |  |  | $ | 3,725 |  |
| Less: Accumulated depreciation | (1,721) |  |  | (1,517) |  |
| Equipment under operating lease, net | $ | 2,134 |  |  | $ | 2,208 |  |

[0001571996-23-000046:notes:72]
The following table presents operating lease income related to lease payments and depreciation expense for the Company’s operating lease portfolio for the periods indicated:

[0001571996-23-000046:notes:73]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 3, 2023 |  | October 28, 2022 |  | November 3, 2023 |  | October 28, 2022 |
|  | (in millions) |
| Income related to lease payments | $ | 341 |  |  | $ | 297 |  |  | $ | 992 |  |  | $ | 782 |  |
| Depreciation expense | $ | 234 |  |  | $ | 212 |  |  | $ | 703 |  |  | $ | 571 |  |

[0001571996-23-000046:notes:74]
The following table presents the future payments to be received by the Company in operating lease contracts as of the date indicated:

[0001571996-23-000046:notes:75]
|  | November 3, 2023 |
|  | (in millions) |
| Fiscal 2024 (remaining three months) | $ | 330 |  |
| Fiscal 2025 | 974 |  |
| Fiscal 2026 | 628 |  |
| Fiscal 2027 | 272 |  |
| Fiscal 2028 and beyond | 113 |  |
| Total | $ | 2,317 |  |

[0001571996-23-000046:notes:76]
DFS Debt

[0001571996-23-000046:notes:77]
The Company maintains programs that facilitate the funding of leases, loans, and other alternative payment structures in the capital markets.  The majority of DFS debt is non-recourse to Dell Technologies and represents borrowings under securitization programs and structured financing programs, for which the Company’s risk of loss is limited to transferred loan and lease payments and associated equipment.

[0001571996-23-000046:notes:78]
The following table presents DFS debt as of the dates indicated and excludes the allocated portion of the Company’s other borrowings, which represents the additional amount considered to fund the DFS business:

[0001571996-23-000046:notes:79]
|  | November 3, 2023 |  | February 3, 2023 |
| DFS debt | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing and securitization facilities | $ | 2,443 |  |  | $ | 3,987 |  |
| Fixed-term securitization offerings | 3,715 |  |  | 2,679 |  |
| Other | 31 |  |  | 76 |  |
| Total DFS U.S. debt | 6,189 |  |  | 6,742 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 749 |  |  | 790 |  |
| Other borrowings | 839 |  |  | 871 |  |
| Note payable | 250 |  |  | 250 |  |
| Dell Bank senior unsecured eurobonds | 1,593 |  |  | 1,637 |  |
| Total DFS international debt | 3,431 |  |  | 3,548 |  |
| Total DFS debt | $ | 9,620 |  |  | $ | 10,290 |  |
| Total short-term DFS debt | $ | 5,374 |  |  | $ | 5,400 |  |
| Total long-term DFS debt | $ | 4,246 |  |  | $ | 4,890 |  |

[0001571996-23-000046:notes:80]
DFS U.S. Debt

[0001571996-23-000046:notes:81]
Asset-Based Financing and Securitization Facilities — The Company maintains separate asset-based financing facilities in the United States, which are revolving facilities for fixed-term leases and loans.  This debt is collateralized solely by the U.S. loan and lease payments and associated equipment in the facilities.  The debt has a variable interest rate, and the duration of the debt is based on the terms of the underlying loan and lease payment streams.  As of November 3, 2023, the total debt capacity related to the U.S. asset-based financing facilities was $5.1 billion.  The Company enters into interest swap agreements to effectively convert a portion of this debt from a floating rate to a fixed rate.  See Note 7 of the Notes to the Condensed Consolidated Financial Statements for additional information about the Company’s interest rate swaps.

[0001571996-23-000046:notes:82]
The Company’s two U.S. asset-based financing facilities for fixed-term leases and loans are effective through July 7, 2025 and June 21, 2024, respectively.  The asset-based financing facilities contain standard structural features related to the performance of the funded receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the facility, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of November 3, 2023, these criteria were met.

[0001571996-23-000046:notes:83]
The Company previously maintained a U.S. securitization facility for revolving loans effective through June 25, 2025.  In connection with the sale of the U.S. consumer revolving customer receivables portfolio described in Note 1 of the Notes to the Condensed Consolidated Financial Statements, the Company’s U.S. securitization facility for revolving loans was paid down and terminated during the three months ended November 3, 2023.

[0001571996-23-000046:notes:84]
Fixed-Term Securitization Offerings — The Company periodically issues asset-backed debt securities under fixed-term securitization programs to private investors.  The asset-backed debt securities are collateralized solely by the U.S. fixed-term lease and loan payments and associated equipment, which are held by Special Purpose Entities (“SPEs”), as discussed below.  The interest rate on these securities is fixed and ranges from 0.53% to 6.80% per annum as of November 3, 2023, and the duration of these securities is based on the terms of the underlying lease and loan payment streams.

[0001571996-23-000046:notes:85]
DFS International Debt

[0001571996-23-000046:notes:86]
Securitization Facility — The Company maintains a securitization facility in Europe for fixed-term leases and loans.  The debt under this facility has a variable interest rate, and the duration of the debt is based on the terms of the underlying loan and lease payment streams.  This facility is effective through December 23, 2024 and had a total debt capacity of $850 million as of November 3, 2023.

[0001571996-23-000046:notes:87]
The securitization facility contains standard structural features related to the performance of the securitized receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the program, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of November 3, 2023, these criteria were met.

[0001571996-23-000046:notes:88]
Other Borrowings — In connection with the Company’s international financing operations, the Company has entered into revolving structured financing debt programs related to its fixed-term lease and loan products sold in Canada, Europe, Australia, New Zealand, and the Middle East.  The debt under these programs has a variable interest rate, and the duration of the debt is based on the terms of the underlying loan and lease payment streams.  The Canadian facility, which is collateralized solely by Canadian loan and lease payments and associated equipment, had a total debt capacity of $328 million as of November 3, 2023 and is effective through January 16, 2025.  The European facility, which is collateralized solely by European loan and lease payments and associated equipment, had a total debt capacity of $531 million as of November 3, 2023 and is effective through June 14, 2025.  The Australia and New Zealand facility, which is collateralized solely by Australia and New Zealand loan and lease payments and associated equipment, had a total debt capacity of $290 million as of November 3, 2023 and is effective through April 20, 2025. The Middle East facility, which is collateralized solely by Middle East loan and lease payments and associated equipment, had a total debt capacity of $150 million as of November 3, 2023 and is effective through March 24, 2025.

[0001571996-23-000046:notes:89]
Note Payable — On May 25, 2022, the Company entered into an unsecured credit agreement to fund receivables in Mexico.  As of November 3, 2023, the aggregate principal amount of the note payable was $250 million.  The note bears interest at an annual rate of 4.24% and will mature on May 31, 2024.

[0001571996-23-000046:notes:90]
Dell Bank Senior Unsecured Eurobonds — On June 24, 2020, Dell Bank issued 500 million Euro of 1.625% senior unsecured four year eurobonds due June 2024.  On October 27, 2021, Dell Bank issued 500 million Euro of 0.5% senior unsecured five year eurobonds due October 2026.  On October 18, 2022, Dell Bank issued 500 million Euro of 4.5% senior unsecured five year eurobonds due October 2027.  The issuances of the senior unsecured eurobonds support the expansion of the financing operations in Europe.

[0001571996-23-000046:notes:91]
Variable Interest Entities

[0001571996-23-000046:notes:92]
In connection with the asset-based financing facilities, securitization facilities, and fixed-term securitization offerings discussed above, the Company transfers certain U.S. and European lease and loan payments and associated equipment to SPEs that meet the definition of a VIE and are consolidated, along with the associated debt described above, into the Condensed Consolidated Financial Statements as the Company is the primary beneficiary of the VIEs.  The SPEs are bankruptcy-remote legal entities with separate assets and liabilities.  The purpose of the SPEs is to facilitate the funding of customer loan and lease payments and associated equipment in the capital markets.

[0001571996-23-000046:notes:93]
Some of the SPEs have entered into financing arrangements with multi-seller conduits that, in turn, issue asset-backed debt securities in the capital markets.  DFS debt outstanding held by the consolidated VIEs is collateralized by the lease and loan payments and associated equipment.  The Company’s risk of loss related to securitized receivables is limited to the amount by which the Company’s right to receive collections for assets securitized exceeds the amount required to pay interest, principal, and fees and expenses related to the asset-backed securities.  The Company provides credit enhancement to the securitization in the form of over-collateralization.

[0001571996-23-000046:notes:94]
The following table presents the assets and liabilities held by the consolidated VIEs as of the dates indicated, which are included in the Condensed Consolidated Statements of Financial Position:

[0001571996-23-000046:notes:95]
|  | November 3, 2023 |  | February 3, 2023 |
|  | (in millions) |
| Assets held by consolidated VIEs |  |  |  |
| Other current assets | $ | 146 |  |  | $ | 274 |  |
| Financing receivables, net of allowance |  |  |  |
| Short-term | $ | 3,059 |  |  | $ | 3,702 |  |
| Long-term | $ | 3,261 |  |  | $ | 3,295 |  |
| Property, plant, and equipment, net | $ | 1,097 |  |  | $ | 1,164 |  |
| Liabilities held by consolidated VIEs |  |  |  |
| Debt, net of unamortized debt issuance costs |  |  |  |
| Short-term | $ | 4,138 |  |  | $ | 4,761 |  |
| Long-term | $ | 2,753 |  |  | $ | 2,685 |  |

[0001571996-23-000046:notes:96]
Lease and loan payments and associated equipment transferred via securitization through SPEs were $1.1 billion and $1.6 billion for the three months ended November 3, 2023 and October 28, 2022, respectively, and $3.7 billion and $4.5 billion for the nine months ended November 3, 2023 and October 28, 2022, respectively.

[0001571996-23-000046:notes:97]
Customer Receivable Sales

[0001571996-23-000046:notes:98]
To manage certain concentrations of customer credit exposure, the Company may sell selected fixed-term customer receivables to unrelated third parties on a periodic basis, without recourse.  The amount of customer receivables sold for this purpose was $205 million and $431 million for the nine months ended November 3, 2023 and October 28, 2022, respectively.  The Company’s continuing involvement in these customer receivables is primarily limited to servicing arrangements.


## us-gaap:ScheduleOfDebtTableTextBlock

[0001571996-23-000046:notes:99]
The following table summarizes the Company’s outstanding debt as of the dates indicated:

[0001571996-23-000046:notes:100]
|  | November 3, 2023 |  | February 3, 2023 |
|  | (in millions) |
| Senior Notes: |  |  |  |
| 5.45% due June 2023 | $ | — |  |  | $ | 1,000 |  |
| 4.00% due July 2024 | 1,000 |  |  | 1,000 |  |
| 5.85% due July 2025 | 1,000 |  |  | 1,000 |  |
| 6.02% due June 2026 | 3,500 |  |  | 4,500 |  |
| 4.90% due October 2026 | 1,750 |  |  | 1,750 |  |
| 6.10% due July 2027 | 500 |  |  | 500 |  |
| 5.25% due February 2028 | 1,000 |  |  | 1,000 |  |
| 5.30% due October 2029 | 1,750 |  |  | 1,750 |  |
| 6.20% due July 2030 | 750 |  |  | 750 |  |
| 5.75% due February 2033 | 1,000 |  |  | 1,000 |  |
| 8.10% due July 2036 | 1,000 |  |  | 1,000 |  |
| 3.38% due December 2041 | 962 |  |  | 1,000 |  |
| 8.35% due July 2046 | 800 |  |  | 800 |  |
| 3.45% due December 2051 | 1,095 |  |  | 1,250 |  |
| Legacy Notes and Debentures: |  |  |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| DFS Debt (Note 4) | 9,620 |  |  | 10,290 |  |
| Other | 181 |  |  | 325 |  |
| Total debt, principal amount | $ | 26,860 |  |  | $ | 29,867 |  |
| Unamortized discount, net of unamortized premium | (117) |  |  | (133) |  |
| Debt issuance costs | (126) |  |  | (146) |  |
| Total debt, carrying value | $ | 26,617 |  |  | $ | 29,588 |  |
| Total short-term debt, carrying value | $ | 6,498 |  |  | $ | 6,573 |  |
| Total long-term debt, carrying value | $ | 20,119 |  |  | $ | 23,015 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0001571996-23-000046:notes:101]
LEASES 
The Company enters into leasing transactions in which the Company is the lessee.  These lease contracts are typically classified as operating leases.  The Company’s lease contracts are generally for office buildings used to conduct its business, and the determination of whether such contracts contain leases generally does not require significant estimates or judgments.  The Company also leases certain global logistics warehouses, employee vehicles, and equipment.  As of November 3, 2023, the remaining terms of the Company’s leases range from one month to approximately ten years.  As of November 3, 2023 and February 3, 2023, there were no material finance leases in which the Company was a lessee.

[0001571996-23-000046:notes:102]
[same as prior period, unchanged from 0001571996-23-000032:notes:102]

[0001571996-23-000046:notes:103]
[same as prior period, unchanged from 0001571996-23-000032:notes:103]

[0001571996-23-000046:notes:104]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 3, 2023 |  | October 28, 2022 |  | November 3, 2023 |  | October 28, 2022 |
|  | (in millions) |
| Operating lease costs | $ | 79 |  |  | $ | 67 |  |  | $ | 221 |  |  | $ | 207 |  |
| Variable costs | 19 |  |  | 25 |  |  | 62 |  |  | 73 |  |
| Total lease costs | $ | 98 |  |  | $ | 92 |  |  | $ | 283 |  |  | $ | 280 |  |

[0001571996-23-000046:notes:105]
For both the nine months ended November 3, 2023 and October 28, 2022, sublease income, finance lease costs, and short-term lease costs were immaterial.

[0001571996-23-000046:notes:106]
[same as prior period, unchanged from 0001571996-23-000032:notes:106]

[0001571996-23-000046:notes:107]
|  | Classification |  | November 3, 2023 |  | February 3, 2023 |  |  |
|  |  |  | (in millions, except for term and discount rate) |
| Operating lease right-of-use assets | Other non-current assets |  | $ | 711 |  | $ | 725 |  |  |
| Current operating lease liabilities | Accrued and other current liabilities |  | $ | 246 |  | $ | 260 |  |  |
| Non-current operating lease liabilities | Other non-current liabilities |  | 588 |  | 630 |  |  |
| Total operating lease liabilities |  |  | $ | 834 |  | $ | 890 |  |  |
| Weighted-average remaining lease term (in years) |  |  | 4.49 |  | 4.95 |  |  |
| Weighted-average discount rate |  |  | 4.71 | % |  | 3.48 | % |  |  |

[0001571996-23-000046:notes:108]
[same as prior period, unchanged from 0001571996-23-000032:notes:108]

[0001571996-23-000046:notes:109]
|  | Nine Months Ended |
|  | November 3, 2023 |  | October 28, 2022 |
|  | (in millions) |
| Cash paid for amounts included in the measurement of lease liabilities — operating cash outflows from operating leases | $ | 220 |  |  | $ | 230 |  |
| Right-of-use assets obtained in exchange for new operating lease liabilities | $ | 205 |  |  | $ | 134 |  |

[0001571996-23-000046:notes:110]
[same as prior period, unchanged from 0001571996-23-000032:notes:110]

[0001571996-23-000046:notes:111]
|  | November 3, 2023 |
|  | (in millions) |
| Fiscal 2024 (remaining three months) | $ | 63 |  |
| Fiscal 2025 | 240 |  |
| Fiscal 2026 | 194 |  |
| Fiscal 2027 | 157 |  |
| Fiscal 2028 | 113 |  |
| Thereafter | 145 |  |
| Total lease payments | 912 |  |
| Less: Imputed interest | (78) |  |
| Total | $ | 834 |  |
| Current operating lease liabilities | $ | 246 |  |
| Non-current operating lease liabilities | $ | 588 |  |

[0001571996-23-000046:notes:112]
As of November 3, 2023, the Company’s undiscounted operating leases that had not yet commenced were immaterial.


## us-gaap:DebtDisclosureTextBlock

[0001571996-23-000046:notes:113]
DEBT
The following table summarizes the Company’s outstanding debt as of the dates indicated:

[0001571996-23-000046:notes:114]
During the nine months ended November 3, 2023, the net decrease in the Company’s debt balance was principally attributable to:

[0001571996-23-000046:notes:115]
•the repayment of $1 billion principal amount of the 5.45% Senior Notes due June 2023; and

[0001571996-23-000046:notes:116]
•the repayment of $1 billion principal amount of the 6.02% Senior Notes due June 2026 in a tender offer, in connection with which the Company recognized an immaterial amount of debt extinguishment costs in interest and other, net in the Condensed Consolidated Statement of Income.

[0001571996-23-000046:notes:117]
Outstanding Debt

[0001571996-23-000046:notes:118]
Senior Notes — The Company completed offerings of multiple series of senior notes which were issued on June 1, 2016, June 22, 2016, March 20, 2019, April 9, 2020, December 13, 2021, and January 24, 2023 in aggregate principal amounts of $20.0 billion, $3.3 billion, $4.5 billion, $2.3 billion, $2.3 billion, and $2.0 billion, respectively (the “Senior Notes”).  Interest on these borrowings is payable semiannually.

[0001571996-23-000046:notes:119]
Legacy Notes and Debentures — The Company has outstanding unsecured notes and debentures (collectively, the “Legacy Notes and Debentures”) that were issued by Dell Inc. (“Dell”), a wholly-owned subsidiary of Dell Technologies Inc., prior to the acquisition of Dell by Dell Technologies Inc. in the going-private transaction that closed in October 2013.  Interest on these borrowings is payable semiannually.

[0001571996-23-000046:notes:120]
DFS Debt — See Note 4 and Note 7 of the Notes to the Condensed Consolidated Financial Statements, respectively, for discussion of DFS debt and the interest rate swap agreements that hedge a portion of that debt.

[0001571996-23-000046:notes:121]
2021 Revolving Credit Facility — The Company’s revolving credit facility, which was entered into on November 1, 2021 (the “2021 Revolving Credit Facility”), matures on November 1, 2027.  This facility provides the Company with revolving commitments in an aggregate principal amount of $6.0 billion for general corporate purposes, including liquidity support for the Company’s commercial paper program, and includes a letter of credit sub-facility of up to $0.5 billion and a swing-line loan sub-facility of up to $0.5 billion.  The 2021 Revolving Credit Facility also allows the Company to obtain incremental additional commitments on one or more occasions in minimum amounts of $10 million.

[0001571996-23-000046:notes:122]
Borrowings under the 2021 Revolving Credit Facility bear interest at a rate per annum equal to an applicable margin plus, at the borrowers’ option, either (a) the specified adjusted term Secured Overnight Financing Rate (“SOFR”) or (b) a base rate.  The margin applicable to SOFR and base rate borrowings varies based upon the Company’s existing credit ratings.  The base rate is calculated based upon the greatest of the specified prime rate, the specified federal reserve bank rate, or SOFR plus 1%.  The borrowers may voluntarily repay outstanding loans under the 2021 Revolving Credit Facility at any time without premium or penalty, other than customary breakage costs.

[0001571996-23-000046:notes:123]
As of November 3, 2023, the Company had no outstanding borrowings under the 2021 Revolving Credit Facility.

[0001571996-23-000046:notes:124]
Commercial Paper Program — During Fiscal 2023, the Company established a commercial paper program under which the Company may issue unsecured notes in a maximum aggregate face amount of $5.0 billion outstanding at any time, with maturities up to 397 days from the date of issuance.  The notes are sold on customary terms in the U.S. commercial paper market on a private placement basis.  The proceeds of the notes are used for general corporate purposes.  As of November 3, 2023, the Company had no outstanding borrowings under the commercial paper program.

[0001571996-23-000046:notes:125]
The Company may purchase, redeem, prepay, refinance, or otherwise retire any amount of outstanding indebtedness under the terms of such indebtedness at any time and from time to time, in open market or negotiated transactions with the holders of such indebtedness or otherwise, as considered appropriate in light of market conditions and other relevant factors.

[0001571996-23-000046:notes:126]
Covenants — The credit agreement governing the 2021 Revolving Credit Facility and the indentures governing the Senior Notes and the Legacy Notes and Debentures impose various limitations, subject to exceptions, on creating certain liens and entering into sale and lease-back transactions.  The foregoing credit agreement and indentures contain customary events of default, including failure to make required payments, failure to comply with covenants, and the occurrence of certain events of bankruptcy and insolvency.  The 2021 Revolving Credit Facility is also subject to an interest coverage ratio covenant that is tested at the end of each fiscal quarter with respect to the Company’s preceding four fiscal quarters.  The Company was in compliance with this financial covenant as of November 3, 2023.

[0001571996-23-000046:notes:127]
Aggregate Future Maturities

[0001571996-23-000046:notes:128]
The following table presents the aggregate future maturities of the Company’s debt as of November 3, 2023 for the periods indicated:

[0001571996-23-000046:notes:129]
|  | Maturities by Fiscal Year |
|  | 2024 (remaining three months) |  | 2025 |  | 2026 |  | 2027 |  | 2028 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Notes | $ | — |  |  | $ | 1,000 |  |  | $ | 1,000 |  |  | $ | 5,250 |  |  | $ | 500 |  |  | $ | 8,357 |  |  | $ | 16,107 |  |
| Legacy Notes and Debentures | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 952 |  |  | 952 |  |
| DFS Debt | 1,479 |  |  | 4,807 |  |  | 1,833 |  |  | 884 |  |  | 610 |  |  | 7 |  |  | 9,620 |  |
| Other | 13 |  |  | 124 |  |  | 29 |  |  | 8 |  |  | 6 |  |  | 1 |  |  | 181 |  |
| Total maturities, principal amount | 1,492 |  |  | 5,931 |  |  | 2,862 |  |  | 6,142 |  |  | 1,116 |  |  | 9,317 |  |  | 26,860 |  |
| Associated carrying value adjustments | (2) |  |  | (7) |  |  | (6) |  |  | (33) |  |  | (8) |  |  | (187) |  |  | (243) |  |
| Total maturities, carrying value amount | $ | 1,490 |  |  | $ | 5,924 |  |  | $ | 2,856 |  |  | $ | 6,109 |  |  | $ | 1,108 |  |  | $ | 9,130 |  |  | $ | 26,617 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001571996-23-000046:notes:130]
[same as prior period, unchanged from 0001571996-23-000032:notes:130]

[0001571996-23-000046:notes:131]
[same as prior period, unchanged from 0001571996-23-000032:notes:131]

[0001571996-23-000046:notes:132]
[same as prior period, unchanged from 0001571996-23-000032:notes:132]

[0001571996-23-000046:notes:133]
[same as prior period, unchanged from 0001571996-23-000032:notes:133]

[0001571996-23-000046:notes:134]
During the three and nine months ended November 3, 2023 and October 28, 2022, the Company did not discontinue any cash flow hedges related to foreign exchange contracts that had a material impact on the Company’s results of operations due to the probability that the forecasted cash flows would not occur.

[0001571996-23-000046:notes:135]
[same as prior period, unchanged from 0001571996-23-000032:notes:135]

[0001571996-23-000046:notes:136]
[same as prior period, unchanged from 0001571996-23-000032:notes:136]

[0001571996-23-000046:notes:137]
[same as prior period, unchanged from 0001571996-23-000032:notes:137]

[0001571996-23-000046:notes:138]
[same as prior period, unchanged from 0001571996-23-000032:notes:138]

[0001571996-23-000046:notes:139]
Interest rate swaps are utilized to manage the interest rate risk, at a portfolio level, associated with DFS operations in Europe.  The interest rate swaps economically convert the fixed rate on financing receivables to a three-month Euribor floating rate in order to match the floating rate nature of the banks’ funding pool.  The Company also uses interest rate swaps to manage the cash flows related to interest payments on Eurobonds.  The interest rate swaps economically convert the fixed rate on the Company’s bonds to a floating rate to match the underlying lease repayments profile.  These contracts are not designated for hedge accounting and most expire within five years or less.

[0001571996-23-000046:notes:140]
[same as prior period, unchanged from 0001571996-23-000032:notes:140]

[0001571996-23-000046:notes:141]
Periodically, the Company also uses interest rate swaps to modify the market risk exposures in connection with long-term debt.  During Fiscal 2023, the Company entered into interest rate swaps designated as fair value hedges intended to hedge a portion of its interest rate exposure by converting the fixed interest rate of a certain tranche of debt to a floating interest rate based on the benchmark SOFR Overnight Index Swap rate.  The gains and losses related to changes in the fair value of such interest rate swaps perfectly offset changes in the fair value of the hedged portion of the underlying debt that were attributable to the changes in the underlying benchmark interest rate.  During the nine months ended November 3, 2023, the Company repaid the hedged debt and terminated the associated interest rate swaps.

[0001571996-23-000046:notes:142]
[same as prior period, unchanged from 0001571996-23-000032:notes:142]

[0001571996-23-000046:notes:143]
[same as prior period, unchanged from 0001571996-23-000032:notes:143]

[0001571996-23-000046:notes:144]
|  | November 3, 2023 |  | February 3, 2023 |
|  | (in millions) |
| Foreign exchange contracts: |  |  |  |
| Designated as cash flow hedging instruments | $ | 7,317 |  |  | $ | 7,746 |  |
| Non-designated as hedging instruments | 6,290 |  |  | 6,833 |  |
| Total | $ | 13,607 |  |  | $ | 14,579 |  |
| Interest rate contracts: |  |  |  |
| Designated as fair value hedging instruments | $ | — |  |  | $ | 1,000 |  |
| Non-designated as hedging instruments | 6,107 |  |  | 7,214 |  |
| Total | $ | 6,107 |  |  | $ | 8,214 |  |

[0001571996-23-000046:notes:145]
[same as prior period, unchanged from 0001571996-23-000032:notes:145]

[0001571996-23-000046:notes:146]
| Derivatives in Cash Flow Hedging Relationships |  | Gain (Loss) Recognized in Accumulated OCI, Net of Tax, on Derivatives |  | Location of Gain (Loss) Reclassified from Accumulated OCI into Income |  | Gain (Loss) Reclassified from Accumulated OCI into Income |
|  |  | (in millions) |  |  |  | (in millions) |
| For the three months ended November 3, 2023: |
|  |  |  |  | Total net revenue |  | $ | 83 |  |
| Foreign exchange contracts |  | $ | 171 |  |  | Total cost of net revenue |  | 1 |  |
| Interest rate contracts |  | — |  |  | Interest and other, net |  | — |  |
| Total |  | $ | 171 |  |  | Total |  | $ | 84 |  |
| For the three months ended October 28, 2022: |
|  |  |  |  | Total net revenue |  | $ | 324 |  |
| Foreign exchange contracts |  | $ | 306 |  |  | Total cost of net revenue |  | — |  |
| Interest rate contracts |  | — |  |  | Interest and other, net |  | — |  |
| Total |  | $ | 306 |  |  | Total |  | $ | 324 |  |

[0001571996-23-000046:notes:147]
| Derivatives in Cash Flow Hedging Relationships |  | Gain (Loss) Recognized in Accumulated OCI, Net of Tax, on Derivatives |  | Location of Gain (Loss) Reclassified from Accumulated OCI into Income |  | Gain (Loss) Reclassified from Accumulated OCI into Income |
|  |  | (in millions) |  |  |  | (in millions) |
| For the nine months ended November 3, 2023: |
|  |  |  |  | Total net revenue |  | $ | (68) |  |
| Foreign exchange contracts |  | $ | 230 |  |  | Total cost of net revenue |  | (7) |  |
| Interest rate contracts |  | — |  |  | Interest and other, net |  | — |  |
| Total |  | $ | 230 |  |  | Total |  | $ | (75) |  |
| For the nine months ended October 28, 2022: |
|  |  |  |  | Total net revenue |  | $ | 754 |  |
| Foreign exchange contracts |  | $ | 844 |  |  | Total cost of net revenue |  | (28) |  |
| Interest rate contracts |  | — |  |  | Interest and other, net |  | — |  |
| Total |  | $ | 844 |  |  | Total |  | $ | 726 |  |

[0001571996-23-000046:notes:148]
[same as prior period, unchanged from 0001571996-23-000032:notes:148]

[0001571996-23-000046:notes:149]
|  | Three Months Ended |  | Nine Months Ended |  |  |  |  |
|  | November 3, 2023 |  | October 28, 2022 |  | November 3, 2023 |  | October 28, 2022 |  |  |  | Location of Gain (Loss) Recognized |
|  | (in millions) |  |  |
| Foreign exchange contracts | $ | (114) |  |  | $ | 71 |  |  | $ | (97) |  |  | $ | (234) |  |  |  |  | Interest and other, net |
| Interest rate contracts | 2 |  |  | 46 |  |  | 5 |  |  | 64 |  |  |  |  | Interest and other, net |
| Total | $ | (112) |  |  | $ | 117 |  |  | $ | (92) |  |  | $ | (170) |  |  |  |  |  |

[0001571996-23-000046:notes:150]
[same as prior period, unchanged from 0001571996-23-000032:notes:150]

[0001571996-23-000046:notes:151]
|  | November 3, 2023 |
|  | Other CurrentAssets |  | Other Non-Current Assets |  | Other Current Liabilities |  | Other Non-CurrentLiabilities |  | TotalFair Value |
|  | (in millions) |
| Derivatives designated as hedging instruments: |
| Foreign exchange contracts in an asset position | $ | 124 |  |  | $ | — |  |  | $ | 28 |  |  | $ | — |  |  | $ | 152 |  |
| Foreign exchange contracts in a liability position | (8) |  |  | — |  |  | (5) |  |  | — |  |  | (13) |  |
| Interest rate contracts in an asset position | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Interest rate contracts in a liability position | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Net asset (liability) | 116 |  |  | — |  |  | 23 |  |  | — |  |  | 139 |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts in an asset position | 213 |  |  | — |  |  | 86 |  |  | — |  |  | 299 |  |
| Foreign exchange contracts in a liability position | (177) |  |  | — |  |  | (153) |  |  | — |  |  | (330) |  |
| Interest rate contracts in an asset position | 6 |  |  | 57 |  |  | — |  |  | — |  |  | 63 |  |
| Interest rate contracts in a liability position | — |  |  | — |  |  | (15) |  |  | (17) |  |  | (32) |  |
| Net asset (liability) | 42 |  |  | 57 |  |  | (82) |  |  | (17) |  |  | — |  |
| Total derivatives at fair value | $ | 158 |  |  | $ | 57 |  |  | $ | (59) |  |  | $ | (17) |  |  | $ | 139 |  |
|  | February 3, 2023 |
|  | Other CurrentAssets |  | Other Non-Current Assets |  | Other Current Liabilities |  | Other Non-CurrentLiabilities |  | TotalFair Value |
|  | (in millions) |
| Derivatives designated as hedging instruments: |
| Foreign exchange contracts in an asset position | $ | 7 |  |  | $ | — |  |  | $ | 30 |  |  | $ | — |  |  | $ | 37 |  |
| Foreign exchange contracts in a liability position | (21) |  |  | — |  |  | (142) |  |  | — |  |  | (163) |  |
| Interest rate contracts in an asset position | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Interest rate contracts in a liability position | — |  |  | — |  |  | — |  |  | (6) |  |  | (6) |  |
| Net asset (liability) | (14) |  |  | — |  |  | (112) |  |  | (6) |  |  | (132) |  |
| Derivatives not designated as hedging instruments: |
| Foreign exchange contracts in an asset position | 282 |  |  | 1 |  |  | 368 |  |  | — |  |  | 651 |  |
| Foreign exchange contracts in a liability position | (121) |  |  | — |  |  | (614) |  |  | (1) |  |  | (736) |  |
| Interest rate contracts in an asset position | 14 |  |  | 133 |  |  | — |  |  | — |  |  | 147 |  |
| Interest rate contracts in a liability position | — |  |  | — |  |  | — |  |  | (95) |  |  | (95) |  |
| Net asset (liability) | 175 |  |  | 134 |  |  | (246) |  |  | (96) |  |  | (33) |  |
| Total derivatives at fair value | $ | 161 |  |  | $ | 134 |  |  | $ | (358) |  |  | $ | (102) |  |  | $ | (165) |  |

[0001571996-23-000046:notes:152]
[same as prior period, unchanged from 0001571996-23-000032:notes:152]

[0001571996-23-000046:notes:153]
|  | November 3, 2023 |
|  | Gross Amounts of Recognized Assets/ (Liabilities) |  | Gross Amounts Offset in the Statement of Financial Position |  | Net Amounts of Assets/(Liabilities) Presented in the Statement of Financial Position |  | Gross Amounts not Offset in the Statement of Financial Position |  | Net Amount of Assets/ (Liabilities) Recognized in the Statement of Financial Position |
|  | Financial Instruments |  | Cash Collateral Received or Pledged |  |
|  | (in millions) |
| Derivative instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Financial assets | $ | 514 |  |  | $ | (299) |  |  | $ | 215 |  |  | $ | — |  |  | $ | (21) |  |  | $ | 194 |  |
| Financial liabilities | (375) |  |  | 299 |  |  | (76) |  |  | — |  |  | 17 |  |  | (59) |  |
| Total derivative instruments | $ | 139 |  |  | $ | — |  |  | $ | 139 |  |  | $ | — |  |  | $ | (4) |  |  | $ | 135 |  |
|  | February 3, 2023 |
|  | Gross Amounts of Recognized Assets/ (Liabilities) |  | Gross Amounts Offset in the Statement of Financial Position |  | Net Amounts of Assets/(Liabilities) Presented in the Statement of Financial Position |  | Gross Amounts not Offset in the Statement of Financial Position |  | Net Amount of Assets/ (Liabilities) Recognized in the Statement of Financial Position |
|  | Financial Instruments |  | Cash Collateral Received or Pledged |  |
|  | (in millions) |
| Derivative instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Financial assets | $ | 835 |  |  | $ | (540) |  |  | $ | 295 |  |  | $ | — |  |  | $ | — |  |  | $ | 295 |  |
| Financial liabilities | (1,000) |  |  | 540 |  |  | (460) |  |  | — |  |  | 25 |  |  | (435) |  |
| Total derivative instruments | $ | (165) |  |  | $ | — |  |  | $ | (165) |  |  | $ | — |  |  | $ | 25 |  |  | $ | (140) |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001571996-23-000046:notes:154]
[same as prior period, unchanged from 0001571996-23-000032:notes:154]

[0001571996-23-000046:notes:155]
[same as prior period, unchanged from 0001571996-23-000032:notes:155]

[0001571996-23-000046:notes:156]
[same as prior period, unchanged from 0001571996-23-000032:notes:156]

[0001571996-23-000046:notes:157]
|  | Infrastructure Solutions Group |  | Client Solutions Group |  | Other Businesses |  | Total |
|  | (in millions) |
| Balances as of February 3, 2023 | $ | 15,017 |  |  | $ | 4,232 |  |  | $ | 427 |  |  | $ | 19,676 |  |
| Goodwill acquired (a) | 82 |  |  | — |  |  | — |  |  | 82 |  |
| Impact of foreign currency translation and other | (142) |  |  | — |  |  | — |  |  | (142) |  |
| Balances as of November 3, 2023 | $ | 14,957 |  |  | $ | 4,232 |  |  | $ | 427 |  |  | $ | 19,616 |  |

[0001571996-23-000046:notes:158]
(a)    Goodwill acquired represents goodwill recognized in connection with the Company’s acquisition of Moogsoft Inc. during the three months ended November 3, 2023.

[0001571996-23-000046:notes:159]
[same as prior period, unchanged from 0001571996-23-000032:notes:158]

[0001571996-23-000046:notes:160]
[same as prior period, unchanged from 0001571996-23-000032:notes:159]

[0001571996-23-000046:notes:161]
|  | November 3, 2023 |  | February 3, 2023 |
|  | Gross |  | AccumulatedAmortization |  | Net |  | Gross |  | AccumulatedAmortization |  | Net |
|  | (in millions) |
| Customer relationships | $ | 16,968 |  |  | $ | (14,817) |  |  | $ | 2,151 |  |  | $ | 16,956 |  |  | $ | (14,474) |  |  | $ | 2,482 |  |
| Developed technology | 9,506 |  |  | (8,897) |  |  | 609 |  |  | 9,466 |  |  | (8,660) |  |  | 806 |  |
| Trade names | 875 |  |  | (813) |  |  | 62 |  |  | 875 |  |  | (780) |  |  | 95 |  |
| Definite-lived intangible assets | 27,349 |  |  | (24,527) |  |  | 2,822 |  |  | 27,297 |  |  | (23,914) |  |  | 3,383 |  |
| Indefinite-lived trade names | 3,085 |  |  | — |  |  | 3,085 |  |  | 3,085 |  |  | — |  |  | 3,085 |  |
| Total intangible assets | $ | 30,434 |  |  | $ | (24,527) |  |  | $ | 5,907 |  |  | $ | 30,382 |  |  | $ | (23,914) |  |  | $ | 6,468 |  |

[0001571996-23-000046:notes:162]
Amortization expense related to definite-lived intangible assets was $205 million and $245 million for the three months ended November 3, 2023 and October 28, 2022, respectively, and $613 million and $732 million for the nine months ended November 3, 2023 and October 28, 2022, respectively. There were no material impairment charges related to intangible assets during the three and nine months ended November 3, 2023 and October 28, 2022.

[0001571996-23-000046:notes:163]
[same as prior period, unchanged from 0001571996-23-000032:notes:162]

[0001571996-23-000046:notes:164]
|  | November 3, 2023 |
|  | (in millions) |
| Fiscal 2024 (remaining three months) | $ | 205 |  |
| Fiscal 2025 | 654 |  |
| Fiscal 2026 | 495 |  |
| Fiscal 2027 | 386 |  |
| Fiscal 2028 | 230 |  |
| Thereafter | 852 |  |
| Total | $ | 2,822 |  |

[0001571996-23-000046:notes:165]
[same as prior period, unchanged from 0001571996-23-000032:notes:164]

[0001571996-23-000046:notes:166]
[same as prior period, unchanged from 0001571996-23-000032:notes:165]

[0001571996-23-000046:notes:167]
For the annual impairment review of the Infrastructure Solutions Group (“ISG”) and Client Solutions Group (“CSG”) reporting units during the third quarter of Fiscal 2024, the Company elected to bypass the assessment of qualitative factors to determine whether it was more likely than not that the fair value of a reporting unit was less than its carrying amount, including goodwill.  In electing to bypass the qualitative assessment, the Company proceeded directly to perform a quantitative goodwill impairment test to measure the fair value of each goodwill reporting unit relative to its carrying amount, and to determine the amount of goodwill impairment loss to be recognized, if any.  For the remaining reporting units, the Company performed a qualitative assessment of goodwill at the reporting unit level.  The qualitative assessment included consideration of the relevant events and circumstances affecting the reporting unit, including macroeconomic, industry and market conditions, overall financial performance, and trends in the public company market valuation, where applicable.

[0001571996-23-000046:notes:168]
Management exercised significant judgment related to the above assessment, including the identification of goodwill reporting units, assignment of assets and liabilities to goodwill reporting units, assignment of goodwill to reporting units, and determination of the fair value of each goodwill reporting unit.  For the quantitative goodwill impairment test, the fair value of each goodwill reporting unit is generally estimated using a combination of public company multiples and discounted cash flow methodologies.  The discounted cash flow and public company multiples methodologies require significant judgment, including estimation of future revenues, gross margins, and operating expenses, which are dependent on internal forecasts, current and anticipated economic conditions and trends, selection of market multiples through assessment of the reporting unit’s performance relative to peer competitors, the estimation of the long-term revenue growth rate and discount rate of the Company’s business, and the determination of the Company’s weighted average cost of capital.  Changes in these estimates and assumptions could materially affect the fair value of the goodwill reporting unit, potentially resulting in a non-cash impairment charge.

[0001571996-23-000046:notes:169]
[same as prior period, unchanged from 0001571996-23-000032:notes:168]

[0001571996-23-000046:notes:170]
Based on the results of the annual impairment test performed during the three months ended November 3, 2023, the fair values of each of the reporting units and indefinite-lived intangibles exceeded their carrying values.  No goodwill or indefinite-lived assets impairment test was performed during the nine months ended November 3, 2023 other than the Company’s annual impairment review.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001571996-23-000046:notes:171]
[same as prior period, unchanged from 0001571996-23-000032:notes:170]

[0001571996-23-000046:notes:172]
[same as prior period, unchanged from 0001571996-23-000032:notes:171]

[0001571996-23-000046:notes:173]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 3, 2023 |  | October 28, 2022 |  | November 3, 2023 |  | October 28, 2022 |
|  | (in millions) |
| Deferred revenue: |  |  |  |  |  |  |  |
| Deferred revenue at beginning of period | $ | 30,312 |  |  | $ | 28,025 |  |  | $ | 30,286 |  |  | $ | 27,573 |  |
| Revenue deferrals | 4,492 |  |  | 4,128 |  |  | 15,236 |  |  | 14,675 |  |
| Revenue recognized | (5,766) |  |  | (5,064) |  |  | (16,484) |  |  | (14,994) |  |
| Other (a) | 15 |  |  | — |  |  | 15 |  |  | (165) |  |
| Deferred revenue at end of period | $ | 29,053 |  |  | $ | 27,089 |  |  | $ | 29,053 |  |  | $ | 27,089 |  |
| Short-term deferred revenue | $ | 15,206 |  |  | $ | 14,106 |  |  | $ | 15,206 |  |  | $ | 14,106 |  |
| Long-term deferred revenue | $ | 13,847 |  |  | $ | 12,983 |  |  | $ | 13,847 |  |  | $ | 12,983 |  |

[0001571996-23-000046:notes:174]
(a)    For the nine months ended October 28, 2022, Other represents the reclassification of deferred revenue to accrued and other liabilities.

[0001571996-23-000046:notes:175]
Remaining Performance Obligations — Remaining performance obligations represent the aggregate amount of the transaction price allocated to performance obligations not delivered, or partially undelivered, as of the end of the reporting period.  Remaining performance obligations include deferred revenue plus unbilled amounts not yet recorded in deferred revenue.  The value of the transaction price allocated to remaining performance obligations as of November 3, 2023 was approximately $39 billion.  The Company expects to recognize approximately 58% of remaining performance obligations as revenue in the next twelve months, and the remainder thereafter.

[0001571996-23-000046:notes:176]
[same as prior period, unchanged from 0001571996-23-000032:notes:175]

[0001571996-23-000046:notes:177]
[same as prior period, unchanged from 0001571996-23-000032:notes:176]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001571996-23-000046:notes:178]
COMMITMENTS AND CONTINGENCIES 
Purchase Obligations

[0001571996-23-000046:notes:179]
The Company has contractual obligations to purchase goods or services, which specify significant terms (including fixed or minimum quantities to be purchased), fixed, minimum, or variable price provisions; and the approximate timing of the transaction.  As of November 3, 2023, such purchase obligations were $3.8 billion for the remaining three months of Fiscal 2024; $0.8 billion for Fiscal 2025; and $0.6 billion for Fiscal 2026 and thereafter.

[0001571996-23-000046:notes:180]
Legal Matters

[0001571996-23-000046:notes:181]
The Company is involved in various claims, suits, assessments, investigations, and legal proceedings that arise from time to time in the ordinary course of its business, including those identified below, consisting of matters involving consumer, antitrust, tax, intellectual property, and other issues on a global basis.

[0001571996-23-000046:notes:182]
The Company accrues a liability when it believes that it is both probable that a liability has been incurred and that it can reasonably estimate the amount of the loss.  The Company reviews these accruals at least quarterly and adjusts them to reflect ongoing negotiations, settlements, rulings, advice of legal counsel, and other relevant information.  To the extent new information is obtained and the Company’s views on the probable outcomes of claims, suits, assessments, investigations, or legal proceedings change, changes in the Company’s accrued liabilities are recorded in the period in which such a determination is made.  For some matters, the incurrence of a liability is not probable or the amount cannot be reasonably estimated and therefore accruals have not been made.

[0001571996-23-000046:notes:183]
The following is a discussion of the Company’s significant legal matters and other proceedings:

[0001571996-23-000046:notes:184]
Class Actions Related to the Class V Transaction — On December 28, 2018, the Company completed a transaction (the “Class V transaction”) in which it paid $14.0 billion in cash and issued 149,387,617 shares of its Class C Common Stock to holders of its Class V Common Stock in exchange for all outstanding shares of Class V Common Stock.  As a result of the Class V transaction, the tracking stock feature of the Company’s capital structure associated with the Class V Common Stock was terminated.  Certain stockholders of the Company, subsequently brought class action complaints arising out of the Class V transaction in which they named as defendants (collectively, the “defendants”) Michael S. Dell and certain other directors serving on the Company’s board of directors at the time of the Class V transaction (collectively, the “director defendants”), certain stockholders of the Company, consisting of Mr. Dell and Silver Lake Group LLC and certain of its affiliated funds (collectively, the “stockholder defendants”), and Goldman Sachs & Co. LLC (“Goldman Sachs”), which served as financial advisor to the Company in connection with the transaction.  The plaintiffs generally alleged that the director defendants and the stockholder defendants breached their fiduciary duties under Delaware law to the former holders of the Class V Common Stock in connection with the Class V transaction by offering a transaction value that was allegedly billions of dollars below fair value.

[0001571996-23-000046:notes:185]
As previously reported, during the fourth quarter of Fiscal 2023, the plaintiffs and the defendants entered into an agreement to settle the lawsuit.  Under the terms of the settlement, the plaintiffs agreed to the dismissal of all claims upon payment of a total of $1.0 billion (the “settlement amount”), which includes all costs, expenses and fees of the plaintiff class relating to the action and its resolution.  The settlement terms required that the settlement amount be paid by the Company and/or the Company’s insurers pursuant to indemnification obligations of the Company to the defendants.  The Company is subject to indemnification obligations, upon the satisfaction of specified conditions, to the director and stockholder defendants and their affiliates pursuant to provisions of the Delaware General Corporation Law, the Company’s certificate of incorporation and bylaws, and agreements with the defendants.  A special committee of the Board of Directors consisting of directors who were not defendants in the action, advised by independent counsel, informed the Board of Directors of its determination that the defendants are entitled to indemnification under the foregoing obligations.

[0001571996-23-000046:notes:186]
During Fiscal 2023, the Company established a $1.0 billion liability on the Consolidated Statements of Financial Position and recognized $0.9 billion expense, net of $106 million in insurance proceeds, within interest and other, net within the Consolidated Statements of Income related to the settlement agreement.  The Company accounted for the expected insurance proceeds as a loss recovery and recognized a benefit within interest and other, net within the Condensed Consolidated Statements of Income and corresponding receivable on the Condensed Consolidated Statements of Financial Position.

[0001571996-23-000046:notes:187]
On May 16, 2023, during the second quarter of Fiscal 2024, the Company paid the settlement amount following approval of the settlement by the Delaware Court of Chancery.  The payment is reflected within cash flows from operating activities within the Condensed Consolidated Statements of Cash Flows.  The Company does not expect to incur additional expenses with respect to the settlement.

[0001571996-23-000046:notes:188]
Other Litigation — Dell does not currently anticipate that any of the other various legal proceedings it is involved in will have a material adverse effect on its business, financial condition, results of operations, or cash flows.

[0001571996-23-000046:notes:189]
In accordance with the relevant accounting guidance, the Company provides disclosures of matters where it is at least reasonably possible that the Company could experience a material loss exceeding the amounts already accrued for these or other proceedings or matters.  In addition, the Company also discloses matters based on its consideration of other matters and qualitative factors, including the experience of other companies in the industry, and investor, customer, and employee relations considerations.  As of November 3, 2023, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for these or other proceedings or matters has been incurred.  However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company’s business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters.  Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company’s business, financial condition, results of operations, or cash flows will depend on a number of factors, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.

[0001571996-23-000046:notes:190]
Indemnifications Obligations

[0001571996-23-000046:notes:191]
In the ordinary course of business, the Company enters into various contracts under which it may agree to indemnify other parties for losses incurred from certain events as defined in the relevant contract, such as litigation, regulatory penalties, or claims relating to past performance.  Such indemnification obligations may not be subject to maximum loss clauses.  Historically, payments related to these indemnification obligations have not been material to the Company.

[0001571996-23-000046:notes:192]
Under the Separation and Distribution Agreement entered into with VMware, Inc. upon the completion of the spin-off of VMware, Inc. by means of a special stock dividend (the “VMware Spin-off”) on November 1, 2021, Dell Technologies agreed to indemnify VMware, Inc., each of its subsidiaries and each of their respective directors, officers, and employees from and against all liabilities relating to, arising out of or resulting from, among other matters, the liabilities allocated to Dell Technologies as part of the separation of Dell Technologies and VMware, Inc. (individually and together with its subsidiaries, “VMware”) and their respective businesses (the “Separation”). VMware similarly agreed to indemnify Dell Technologies Inc., each of its subsidiaries and each of their respective directors, officers, and employees from and against all liabilities relating to, arising out of or resulting from, among other matters, the liabilities allocated to VMware as part of the Separation. Dell Technologies expects VMware to fully perform under the terms of the Separation and Distribution Agreement.

[0001571996-23-000046:notes:193]
For information on the cross-indemnifications related to the tax matters agreement between the Company and VMware effective upon the Separation on November 1, 2021, see Note 15 of the Notes to the Condensed Consolidated Financial Statements.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001571996-23-000046:notes:194]
INCOME AND OTHER TAXES
For the three months ended November 3, 2023, the Company’s effective income tax rate was 14.9% on pre-tax income of $1.2 billion compared to 46.9% on pre-tax income of $0.5 billion for the three months ended October 28, 2022.  The decline in the Company’s effective tax rate was primarily attributable to the impact of expenses recognized during the three months ended October 28, 2022 in connection with the agreement to settle the Class V transaction litigation described in Note 10 of the Notes to the Condensed Consolidated Financial Statements.  Other changes in the Company’s effective income tax rate were attributable to higher U.S. tax on foreign operations, changes in the Company’s jurisdictional mix of income, and the impact of discrete tax items.

[0001571996-23-000046:notes:195]
For the nine months ended November 3, 2023, the Company’s effective income tax rate was 21.6% on pre-tax income of $2.6 billion compared to 21.1% on pre-tax income of $2.3 billion for the nine months ended October 28, 2022.  The increase in the Company’s effective tax rate was attributable to higher U.S. tax on the Company’s foreign operations, changes in the Company’s jurisdictional mix of income, and the impact of discrete tax items, largely offset by the impact of the litigation expenses discussed above.

[0001571996-23-000046:notes:196]
The differences between the estimated effective income tax rates and the U.S. federal statutory rate of 21% principally result from the geographical distribution of income, differences between the book and tax treatment of certain items, and discrete tax items.  In certain jurisdictions, the Company’s tax rate is significantly less than the applicable statutory rate as a result of tax holidays.  The majority of the Company’s foreign income subject to these tax holidays and lower tax rates is attributable to Singapore and China.  A significant portion of these income tax benefits relates to a tax holiday that will be effective until January 31, 2029.  Most of the Company’s other tax holidays will expire in whole or in part during fiscal years 2030 through 2031.  Many of these tax holidays and reduced tax rates may be extended when certain conditions are met or may be terminated early if certain conditions are not met or as a result of changes in tax legislation.  As of November 3, 2023, the Company was not aware of any matters of noncompliance related to these tax holidays or enacted tax legislative changes affecting these tax holidays.

[0001571996-23-000046:notes:197]
In June 2023, the Company received Revenue Agent’s Reports for the examination by the Internal Revenue Service (“IRS”) of fiscal years 2015 through 2017 and fiscal years 2018 through 2019.  The Company agreed with the IRS assessments relating to fiscal years 2015 through 2017 and settled those positions in August 2023.  The impact to the financial statements for that settlement was not material.  For fiscal years 2018 through 2019, the IRS proposed adjustments primarily relating to certain transactions the Company completed as part of its business integration efforts, with which the Company disagrees and which it will contest through the IRS administrative appeals procedures.  In August 2023, the Company submitted a written protest to the IRS relating to certain assessments.  The Company anticipates that the appeals process for the resolution of these matters will extend beyond the next twelve months. In September 2023, the IRS commenced a federal income tax examination of fiscal years 2020 through 2022.

[0001571996-23-000046:notes:198]
[same as prior period, unchanged from 0001571996-23-000032:notes:194]

[0001571996-23-000046:notes:199]
Judgment is required in evaluating the Company’s uncertain tax positions and determining the Company’s provision for income taxes.  Unrecognized tax benefits were $1.2 billion and $1.3 billion as of November 3, 2023 and February 3, 2023, respectively, and are included in other non-current liabilities in the Condensed Consolidated Statements of Financial Position.  Although the timing of resolution or closure of uncertain tax positions is not certain, the Company believes it is reasonably possible that certain tax matters in various jurisdictions could be concluded within the next twelve months.  The resolution of these matters could reduce the Company’s unrecognized tax benefits up to $0.4 billion including interest and penalties.  Such a reduction would have a material impact on the Company’s effective tax rate.

[0001571996-23-000046:notes:200]
The Company takes certain non-income tax positions in the jurisdictions in which it operates and has received certain non-income tax assessments from various jurisdictions.  The Company believes that a material loss in these matters is not probable and that it is not reasonably possible that a material loss exceeding amounts already accrued has been incurred.  The Company believes its positions in these non-income tax litigation matters are supportable and that it ultimately will prevail in the matters.  In the normal course of business, the Company’s positions and conclusions related to its non-income taxes could be challenged and assessments may be made.  To the extent new information is obtained and the Company’s views on its positions, probable outcomes of assessments, or litigation change, changes in estimates to the Company’s accrued liabilities would be recorded in the period in which such a determination is made.  In the resolution process for income tax and non-income tax audits, the Company is required in certain situations to provide collateral guarantees or indemnification to regulators and tax authorities until the matter is resolved.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001571996-23-000046:notes:201]
[same as prior period, unchanged from 0001571996-23-000032:notes:196]

[0001571996-23-000046:notes:202]
[same as prior period, unchanged from 0001571996-23-000032:notes:197]

[0001571996-23-000046:notes:203]
|  | Foreign Currency Translation Adjustments |  |  |  | Cash Flow Hedges |  | Pension and Other Postretirement Plans |  | Accumulated Other Comprehensive Income (Loss) |
|  | (in millions) |
| Balances as of February 3, 2023 | $ | (747) |  |  |  |  | $ | (222) |  |  | $ | (32) |  |  | $ | (1,001) |  |
| Other comprehensive income (loss) before reclassifications | (130) |  |  |  |  | 230 |  |  | 3 |  |  | 103 |  |
| Amounts reclassified from accumulated other comprehensive income (loss) | — |  |  |  |  | 75 |  |  | — |  |  | 75 |  |
| Total change for the period | (130) |  |  |  |  | 305 |  |  | 3 |  |  | 178 |  |
| Balances as of November 3, 2023 | $ | (877) |  |  |  |  | $ | 83 |  |  | $ | (29) |  |  | $ | (823) |  |

[0001571996-23-000046:notes:204]
[same as prior period, unchanged from 0001571996-23-000032:notes:199]

[0001571996-23-000046:notes:205]
[same as prior period, unchanged from 0001571996-23-000032:notes:200]

[0001571996-23-000046:notes:206]
|  |  |  | Three Months Ended |
|  |  |  | November 3, 2023 |  | October 28, 2022 |
|  |  |  | Cash Flow Hedges |  |  |  |  |  | Pensions |  |  |  | Total |  | Cash Flow Hedges |  | Pensions |  | Total |
|  |  |  | (in millions) |
| Total reclassifications, net of tax: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue |  |  | $ | 83 |  |  |  |  |  |  | $ | — |  |  |  |  | $ | 83 |  |  | $ | 324 |  |  | $ | — |  |  | $ | 324 |  |
| Cost of net revenue |  |  | 1 |  |  |  |  |  |  | — |  |  |  |  | 1 |  |  | — |  |  | — |  |  | — |  |
| Operating expenses |  |  | — |  |  |  |  |  |  | — |  |  |  |  | — |  |  | — |  |  | (1) |  |  | (1) |  |
| Total reclassifications, net of tax |  |  | $ | 84 |  |  |  |  |  |  | $ | — |  |  |  |  | $ | 84 |  |  | $ | 324 |  |  | $ | (1) |  |  | $ | 323 |  |

[0001571996-23-000046:notes:207]
|  |  |  | Nine Months Ended |
|  |  |  | November 3, 2023 |  | October 28, 2022 |
|  |  |  | Cash Flow Hedges |  |  |  |  |  | Pensions |  |  |  | Total |  | Cash Flow Hedges |  | Pensions |  | Total |
|  |  |  | (in millions) |
| Total reclassifications, net of tax: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue |  |  | $ | (68) |  |  |  |  |  |  | $ | — |  |  |  |  | $ | (68) |  |  | $ | 754 |  |  | $ | — |  |  | $ | 754 |  |
| Cost of net revenue |  |  | (7) |  |  |  |  |  |  | — |  |  |  |  | (7) |  |  | (28) |  |  | — |  |  | (28) |  |
| Operating expenses |  |  | — |  |  |  |  |  |  | — |  |  |  |  | — |  |  | — |  |  | (1) |  |  | (1) |  |
| Total reclassifications, net of tax |  |  | $ | (75) |  |  |  |  |  |  | $ | — |  |  |  |  | $ | (75) |  |  | $ | 726 |  |  | $ | (1) |  |  | $ | 725 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001571996-23-000046:notes:208]
[same as prior period, unchanged from 0001571996-23-000032:notes:202]

[0001571996-23-000046:notes:209]
|  | Authorized |  | Issued |  | Outstanding |
|  | (in millions) |
| Common stock as of November 3, 2023 |
| Class A | 600 |  |  | 379 |  |  | 379 |  |
| Class B | 200 |  |  | 91 |  |  | 91 |  |
| Class C | 7,900 |  |  | 349 |  |  | 245 |  |
| Class D | 100 |  |  | — |  |  | — |  |
|  | 8,800 |  |  | 819 |  |  | 715 |  |
| Common stock as of February 3, 2023 |
| Class A | 600 |  |  | 379 |  |  | 379 |  |
| Class B | 200 |  |  | 95 |  |  | 95 |  |
| Class C | 7,900 |  |  | 324 |  |  | 242 |  |
| Class D | 100 |  |  | — |  |  | — |  |
|  | 8,800 |  |  | 798 |  |  | 716 |  |

[0001571996-23-000046:notes:210]
[same as prior period, unchanged from 0001571996-23-000032:notes:204]

[0001571996-23-000046:notes:211]
The Company is authorized to issue one million shares of preferred stock, par value $0.01 per share.  As of November 3, 2023 and February 3, 2023, no shares of preferred stock were issued or outstanding.

[0001571996-23-000046:notes:212]
[same as prior period, unchanged from 0001571996-23-000032:notes:206]

[0001571996-23-000046:notes:213]
[same as prior period, unchanged from 0001571996-23-000032:notes:207]

[0001571996-23-000046:notes:214]
[same as prior period, unchanged from 0001571996-23-000032:notes:208]

[0001571996-23-000046:notes:215]
[same as prior period, unchanged from 0001571996-23-000032:notes:209]

[0001571996-23-000046:notes:216]
During the nine months ended November 3, 2023, the Company issued 4.7 million shares of Class C Common Stock to stockholders upon the conversion of the same number of shares of Class B Common Stock into Class C Common Stock in accordance with the Company’s certificate of incorporation. During the nine months ended October 28, 2022, there were no conversions of shares of Class A Common Stock or Class B Common Stock into shares of Class C Common Stock.

[0001571996-23-000046:notes:217]
[same as prior period, unchanged from 0001571996-23-000032:notes:211]

[0001571996-23-000046:notes:218]
On February 24, 2022, the Company announced that the Board of Directors adopted a dividend policy providing for our payment of quarterly cash dividends on the Dell Technologies common stock at a rate of $0.33 per share per fiscal quarter beginning in the first quarter of Fiscal 2023.  On March 2, 2023, the Company announced that the Board of Directors approved a 12% increase in the quarterly dividend rate from $0.33 per share per fiscal quarter to a rate of $0.37 per share per fiscal quarter beginning in the first quarter of Fiscal 2024.

[0001571996-23-000046:notes:219]
[same as prior period, unchanged from 0001571996-23-000032:notes:213]

[0001571996-23-000046:notes:220]
| Three Months Ended |  | Declaration Date |  | Record Date |  | Payment Date |  | Dividend per Share |  | Amount (in millions) |
| Fiscal 2024 |
| May 5, 2023 |  | March 2, 2023 |  | April 25, 2023 |  | May 5, 2023 |  | $ | 0.37 |  |  | $ | 270 |  |
| August 4, 2023 |  | June 16, 2023 |  | July 25, 2023 |  | August 4, 2023 |  | $ | 0.37 |  |  | $ | 268 |  |
| November 3, 2023 |  | September 28, 2023 |  | October 24, 2023 |  | November 3, 2023 |  | $ | 0.37 |  |  | $ | 266 |  |
| Fiscal 2023 |  |  |  |  |  |  |  |  |  |  |
| April 29, 2022 |  | February 24, 2022 |  | April 20, 2022 |  | April 29, 2022 |  | $ | 0.33 |  |  | $ | 248 |  |
| July 29, 2022 |  | June 7, 2022 |  | July 20, 2022 |  | July 29, 2022 |  | $ | 0.33 |  |  | $ | 242 |  |
| October 28, 2022 |  | September 6, 2022 |  | October 19, 2022 |  | October 28, 2022 |  | $ | 0.33 |  |  | $ | 238 |  |

[0001571996-23-000046:notes:221]
During the three and nine months ended November 3, 2023, the Company also paid an immaterial amount of dividend equivalents on eligible vested equity awards which are not reflected above.

[0001571996-23-000046:notes:222]
[same as prior period, unchanged from 0001571996-23-000032:notes:216]

[0001571996-23-000046:notes:223]
Effective as of September 23, 2021, the Company’s Board of Directors approved a stock repurchase program under which the Company is authorized to repurchase up to $5 billion of shares of Class C Common Stock with no fixed expiration date.

[0001571996-23-000046:notes:224]
Effective as of October 5, 2023, the Company’s Board of Directors approved the repurchase of an additional $5 billion of shares of the Company’s Class C Common Stock with no fixed expiration date. Following the approval, the Company had approximately $5.7 billion in authorized amount remaining under the stock repurchase program.

[0001571996-23-000046:notes:225]
During the nine months ended November 3, 2023, the Company repurchased approximately 22 million shares of Class C Common Stock for a total purchase price of approximately $1.3 billion.  During the nine months ended October 28, 2022, the Company repurchased approximately 59 million shares of Class C Common Stock for a total purchase price of approximately $2.7 billion.
The above repurchases of Class C Common Stock exclude shares withheld from stock awards to settle employee tax withholding obligations related to the vesting of such awards.


## us-gaap:EarningsPerShareTextBlock

[0001571996-23-000046:notes:226]
[same as prior period, unchanged from 0001571996-23-000032:notes:218]

[0001571996-23-000046:notes:227]
[same as prior period, unchanged from 0001571996-23-000032:notes:219]

[0001571996-23-000046:notes:228]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 3, 2023 |  | October 28, 2022 |  | November 3, 2023 |  | October 28, 2022 |
| Earnings per share attributable to Dell Technologies Inc. |
| Dell Technologies Common Stock — Basic | $ | 1.39 |  |  | $ | 0.34 |  |  | $ | 2.83 |  |  | $ | 2.47 |  |
| Dell Technologies Common Stock — Diluted | $ | 1.36 |  |  | $ | 0.33 |  |  | $ | 2.78 |  |  | $ | 2.41 |  |

[0001571996-23-000046:notes:229]
[same as prior period, unchanged from 0001571996-23-000032:notes:221]

[0001571996-23-000046:notes:230]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 3, 2023 |  | October 28, 2022 |  | November 3, 2023 |  | October 28, 2022 |
|  | (in millions) |
| Numerator: Dell Technologies Common Stock |  |  |  |  |  |  |  |
| Net income attributable to Dell Technologies Inc. - basic and diluted | $ | 1,006 |  |  | $ | 245 |  |  | $ | 2,051 |  |  | $ | 1,828 |  |
| Denominator: Dell Technologies Common Stock weighted-average shares outstanding |  |  |  |  |  |  |  |
| Weighted-average shares outstanding — basic | 722 |  |  | 728 |  |  | 724 |  |  | 740 |  |
| Dilutive effect of equity awards | 18 |  |  | 15 |  |  | 14 |  |  | 19 |  |
| Weighted-average shares outstanding — diluted | 740 |  |  | 743 |  |  | 738 |  |  | 759 |  |
| Weighted-average shares outstanding — antidilutive | — |  |  | 18 |  |  | 5 |  |  | 11 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001571996-23-000046:notes:231]
RELATED PARTY TRANSACTIONS 
For the periods presented within this report, VMware was considered to be a related party of the Company as a result of Michael Dell’s ownership interests in both Dell Technologies and VMware as well as Mr. Dell’s service as Chairman and Chief Executive Officer of Dell Technologies and as Chairman of the Board of VMware, Inc.

[0001571996-23-000046:notes:232]
Subsequent to the close of the Company’s third quarter of Fiscal 2024, Broadcom Inc. completed its acquisition of VMware and terminated the preexisting related party relationship.  See Note 18 of the Notes to the Condensed Consolidated Financial Statements for more information about the impact of the transaction on the Company’s relationship with VMware.

[0001571996-23-000046:notes:233]
The information provided below includes a summary of transactions with VMware for the periods presented.  Transactions with related parties other than VMware during the periods presented were immaterial, individually and in aggregate.

[0001571996-23-000046:notes:234]
Transactions with VMware

[0001571996-23-000046:notes:235]
•Pursuant to original equipment manufacturer and reseller arrangements, Dell Technologies integrates or bundles VMware’s products and services with Dell Technologies’ products and sells them to end-users.  Dell Technologies also acts as a distributor, purchasing VMware’s standalone products and services for resale to end-user customers.  Where applicable, costs under these arrangements are presented net of rebates received by Dell Technologies.

[0001571996-23-000046:notes:236]
•Dell Technologies may procure products and services from VMware for its internal use.  For the three and nine months ended November 3, 2023 and October 28, 2022, costs incurred associated with products and services purchased from VMware for internal use were immaterial.

[0001571996-23-000046:notes:237]
•Dell Technologies sells and leases products and sells services to VMware.  For the three and nine months ended November 3, 2023 and October 28, 2022, revenue recognized from sales of services to VMware was immaterial.

[0001571996-23-000046:notes:238]
•DFS provides financing to certain VMware end-users.  Upon acceptance of the financing arrangement by both VMware’s end-users and DFS, DFS recognizes amounts due to related parties on the Condensed Consolidated Statements of Financial Position.  Associated financing fees are recorded to product net revenue on the Condensed Consolidated Statements of Income and are reflected within sales and leases of products to VMware in the table below.

[0001571996-23-000046:notes:239]
•Dell Technologies and VMware also enter into joint marketing, sales, and branding arrangements, for which both parties may incur costs.  For the three and nine months ended November 3, 2023 and October 28, 2022, consideration received from VMware for joint marketing, sales, and branding arrangements was immaterial.

[0001571996-23-000046:notes:240]
•Dell Technologies and VMware entered into a transition services agreement in connection with the VMware Spin-off to provide various support services, including investment advisory services, certain support services from Dell Technologies personnel, and other transitional services.  Costs associated with this agreement were immaterial for the three and nine months ended October 28, 2022.  Activities under the agreement concluded during Fiscal 2023.

[0001571996-23-000046:notes:241]
The following table presents information about the impact of Dell Technologies’ related party transactions with VMware on the Condensed Consolidated Statements of Income for the periods indicated:

[0001571996-23-000046:notes:242]
|  |  |  | Three Months Ended |  | Nine Months Ended |  |  |
|  | Classification |  | November 3, 2023 |  | October 28, 2022 |  | November 3, 2023 |  | October 28, 2022 |  |  |
|  |  |  | (in millions) |
| Sales and leases of products to VMware | Net revenue - products |  | $ | 16 |  |  | $ | 49 |  |  | $ | 94 |  |  | $ | 130 |  |  |  |
| Purchase of VMware products for resale | Cost of net revenue - products |  | $ | 379 |  |  | $ | 281 |  |  | $ | 970 |  |  | $ | 962 |  |  |  |
| Purchase of VMware services for resale | Cost of net revenue - services |  | $ | 884 |  |  | $ | 733 |  |  | $ | 2,640 |  |  | $ | 2,204 |  |  |  |

[0001571996-23-000046:notes:243]
The following table presents information about the impact of Dell Technologies’ related party transactions with VMware on the Condensed Consolidated Statements of Financial Position as of the dates indicated:

[0001571996-23-000046:notes:244]
|  | Classification |  | November 3, 2023 |  | February 3, 2023 |
|  |  |  | (in millions) |
| Deferred costs related to VMware products and services for resale | Other current assets |  | $ | 2,926 |  |  | $ | 3,000 |  |
| Deferred costs related to VMware products and services for resale | Other non-current assets |  | $ | 2,201 |  |  | $ | 2,537 |  |

[0001571996-23-000046:notes:245]
|  | November 3, 2023 |  | February 3, 2023 |
|  | (in millions) |
| Due from related party, net, current (a) | $ | 386 |  |  | $ | 378 |  |
| Due from related party, net, non-current (b) | $ | 239 |  |  | $ | 440 |  |
| Due to related party, current (c) | $ | 1,246 |  |  | $ | 2,067 |  |
| Due to related party, non-current (d) | $ | 11 |  |  | $ | — |  |

[0001571996-23-000046:notes:246]
(a)      Amounts due from related party, net, current consisted of amounts due from VMware, inclusive of current net tax receivables from VMware under the Tax Agreements described below.  Amounts, excluding tax, are generally settled in cash within 60 days of each quarter-end.

[0001571996-23-000046:notes:247]
(b)      Amounts due from related party, net, non-current consisted of the non-current portion of net receivables from VMware under the Tax Agreements.

[0001571996-23-000046:notes:248]
(c)      Amounts due to related party, current included amounts due to VMware, which are generally settled in cash within 60 days of each quarter-end.

[0001571996-23-000046:notes:249]
(d)     Amounts due to related party, non-current are included in other non-current liabilities.

[0001571996-23-000046:notes:250]
Related Party Tax Matters

[0001571996-23-000046:notes:251]
Tax Agreements — In connection with the VMware Spin-off and concurrently with the execution of the Separation and Distribution Agreement, effective as of April 14, 2021, Dell Technologies and VMware entered into a Tax Matters Agreement (the “Tax Matters Agreement”) and agreed to terminate the tax sharing agreement as amended on December 30, 2019 (together with the Tax Matters Agreement, the “Tax Agreements”).  The Tax Matters Agreement governs Dell Technologies’ and VMware’s respective rights and obligations, both for pre-spin-off periods and post-spin-off periods, regarding income and other taxes, and related matters, including tax liabilities and benefits, attributes, and returns.

[0001571996-23-000046:notes:252]
The timing of the tax payments due to and from related parties is governed by the Tax Agreements.  VMware’s portion of the mandatory one-time transition tax on accumulated earnings of foreign subsidiaries (the “Transition Tax”) is governed by a letter agreement between VMware and Dell Technologies entered into on April 1, 2019.

[0001571996-23-000046:notes:253]
Pursuant to the Tax Agreements, net receipts from VMware during the nine months ended November 3, 2023 and net payments to VMware during the nine months ended October 28, 2022 were immaterial.

[0001571996-23-000046:notes:254]
As a result of the activity under the Tax Agreements with VMware, amounts due from VMware were $484 million and $599 million as of November 3, 2023 and February 3, 2023, respectively, and primarily related to VMware’s estimated tax obligation resulting from the Transition Tax.  The 2017 Tax Cuts and Jobs Act included a deferral election for an eight-year installment payment method on the Transition Tax.  Dell Technologies expects VMware to pay the remainder of its Transition Tax over a period of two years.

[0001571996-23-000046:notes:255]
Indemnification — Upon consummation of the VMware Spin-off, Dell Technologies recorded net income tax indemnification receivables from VMware related to certain income tax liabilities for which Dell Technologies is jointly and severally liable, but for which it is indemnified by VMware under the Tax Matters Agreement.  The amounts that VMware may be obligated to pay Dell Technologies could vary depending on the outcome of certain unresolved tax matters, which may not be resolved for several years.  The net receivable as of November 3, 2023 and February 3, 2023 was $95 million and $146 million, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001571996-23-000046:notes:256]
[same as prior period, unchanged from 0001571996-23-000032:notes:249]

[0001571996-23-000046:notes:257]
[same as prior period, unchanged from 0001571996-23-000032:notes:250]

[0001571996-23-000046:notes:258]
[same as prior period, unchanged from 0001571996-23-000032:notes:251]

[0001571996-23-000046:notes:259]
[same as prior period, unchanged from 0001571996-23-000032:notes:252]

[0001571996-23-000046:notes:260]
Pursuant to the Commercial Framework Agreement (the “CFA”) established between Dell Technologies and VMware in connection with the VMware Spin-off, Dell Technologies acts as a distributor of VMware’s standalone products and services and purchases such products and services for resale to end-user customers (“VMware Resale”).  Dell Technologies also integrates VMware’s products and services with Dell Technologies’ offerings and sells them to end users.  The results of standalone VMware Resale transactions are reflected in other businesses.  The results of integrated offering transactions are reflected within CSG or ISG, depending upon the nature of the underlying offering sold.  Subsequent to the close of the Company’s third quarter of Fiscal 2024, Broadcom Inc. completed its acquisition of VMware.  See Note 18 of the Notes to the Condensed Consolidated Financial Statements for more information about the impact of the transaction on the Company’s relationship with VMware.

[0001571996-23-000046:notes:261]
[same as prior period, unchanged from 0001571996-23-000032:notes:254]

[0001571996-23-000046:notes:262]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 3, 2023 |  | October 28, 2022 |  | November 3, 2023 |  | October 28, 2022 |
|  | (in millions) |
| Consolidated net revenue: |  |  |  |  |  |  |  |
| Infrastructure Solutions Group | $ | 8,499 |  |  | $ | 9,630 |  |  | $ | 24,553 |  |  | $ | 28,451 |  |
| Client Solutions Group | 12,276 |  |  | 13,775 |  |  | 37,201 |  |  | 44,852 |  |
| Reportable segment net revenue | 20,775 |  |  | 23,405 |  |  | 61,754 |  |  | 73,303 |  |
| Other businesses (a) | 1,474 |  |  | 1,313 |  |  | 4,345 |  |  | 3,951 |  |
| Unallocated transactions (b) | 2 |  |  | 3 |  |  | 8 |  |  | 8 |  |
| Total consolidated net revenue | $ | 22,251 |  |  | $ | 24,721 |  |  | $ | 66,107 |  |  | $ | 77,262 |  |
| Consolidated operating income: |  |  |  |  |  |  |  |
| Infrastructure Solutions Group | $ | 1,069 |  |  | $ | 1,374 |  |  | $ | 2,858 |  |  | $ | 3,502 |  |
| Client Solutions Group | 925 |  |  | 1,060 |  |  | 2,786 |  |  | 3,153 |  |
| Reportable segment operating income | 1,994 |  |  | 2,434 |  |  | 5,644 |  |  | 6,655 |  |
| Other businesses (a) | (32) |  |  | (57) |  |  | (112) |  |  | (192) |  |
| Unallocated transactions (b) | 2 |  |  | 3 |  |  | 7 |  |  | 4 |  |
| Impact of purchase accounting (c) | (2) |  |  | (21) |  |  | (10) |  |  | (33) |  |
| Amortization of intangibles | (205) |  |  | (245) |  |  | (613) |  |  | (732) |  |
| Transaction-related expenses (d) | (3) |  |  | (8) |  |  | (9) |  |  | (16) |  |
| Stock-based compensation expense (e) | (227) |  |  | (235) |  |  | (675) |  |  | (703) |  |
| Other corporate expenses (f) | (41) |  |  | (109) |  |  | (512) |  |  | (401) |  |
| Total consolidated operating income | $ | 1,486 |  |  | $ | 1,762 |  |  | $ | 3,720 |  |  | $ | 4,582 |  |

[0001571996-23-000046:notes:263]
[same as prior period, unchanged from 0001571996-23-000032:notes:256]

[0001571996-23-000046:notes:264]
[same as prior period, unchanged from 0001571996-23-000032:notes:257]

[0001571996-23-000046:notes:265]
[same as prior period, unchanged from 0001571996-23-000032:notes:258]

[0001571996-23-000046:notes:266]
[same as prior period, unchanged from 0001571996-23-000032:notes:259]

[0001571996-23-000046:notes:267]
[same as prior period, unchanged from 0001571996-23-000032:notes:260]

[0001571996-23-000046:notes:268]
[same as prior period, unchanged from 0001571996-23-000032:notes:261]

[0001571996-23-000046:notes:269]
[same as prior period, unchanged from 0001571996-23-000032:notes:262]

[0001571996-23-000046:notes:270]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 3, 2023 |  | October 28, 2022 |  | November 3, 2023 |  | October 28, 2022 |
|  | (in millions) |
| Net revenue: |  |  |  |  |  |  |  |
| Infrastructure Solutions Group: |  |  |  |  |  |  |  |
| Servers and networking | $ | 4,656 |  |  | $ | 5,201 |  |  | $ | 12,767 |  |  | $ | 15,458 |  |
| Storage | 3,843 |  |  | 4,429 |  |  | 11,786 |  |  | 12,993 |  |
| Total ISG net revenue | $ | 8,499 |  |  | $ | 9,630 |  |  | $ | 24,553 |  |  | $ | 28,451 |  |
| Client Solutions Group: |  |  |  |  |  |  |  |
| Commercial | $ | 9,835 |  |  | $ | 10,747 |  |  | $ | 30,251 |  |  | $ | 34,859 |  |
| Consumer | 2,441 |  |  | 3,028 |  |  | 6,950 |  |  | 9,993 |  |
| Total CSG net revenue | $ | 12,276 |  |  | $ | 13,775 |  |  | $ | 37,201 |  |  | $ | 44,852 |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001571996-23-000046:notes:271]
[same as prior period, unchanged from 0001571996-23-000032:notes:264]

[0001571996-23-000046:notes:272]
|  | November 3, 2023 |  | February 3, 2023 |
|  | (in millions) |
| Cash, cash equivalents, and restricted cash: |  |  |  |
| Cash and cash equivalents | $ | 8,298 |  |  | $ | 8,607 |  |
| Restricted cash - other current assets (a) | 145 |  |  | 272 |  |
| Restricted cash - other non-current assets (a) | 5 |  |  | 15 |  |
| Total cash, cash equivalents, and restricted cash | $ | 8,448 |  |  | $ | 8,894 |  |
| Inventories: |  |  |  |
| Production materials | $ | 1,875 |  |  | $ | 3,225 |  |
| Work-in-process | 679 |  |  | 708 |  |
| Finished goods | 827 |  |  | 843 |  |
| Total inventories | $ | 3,381 |  |  | $ | 4,776 |  |
| Deferred Costs: |  |  |  |
| Total deferred costs, current (b) | $ | 5,494 |  |  | $ | 5,459 |  |
| Property, plant, and equipment, net: |  |  |  |
| Computer equipment | $ | 7,534 |  |  | $ | 6,899 |  |
| Land and buildings | 2,894 |  |  | 3,059 |  |
| Machinery and other equipment | 3,310 |  |  | 3,134 |  |
| Total property, plant, and equipment | 13,738 |  |  | 13,092 |  |
| Accumulated depreciation and amortization | (7,516) |  |  | (6,883) |  |
| Total property, plant, and equipment, net | $ | 6,222 |  |  | $ | 6,209 |  |

[0001571996-23-000046:notes:273]
[same as prior period, unchanged from 0001571996-23-000032:notes:266]

[0001571996-23-000046:notes:274]
[same as prior period, unchanged from 0001571996-23-000032:notes:267]

[0001571996-23-000046:notes:275]
[same as prior period, unchanged from 0001571996-23-000032:notes:268]

[0001571996-23-000046:notes:276]
[same as prior period, unchanged from 0001571996-23-000032:notes:269]

[0001571996-23-000046:notes:277]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 3, 2023 |  | October 28, 2022 |  | November 3, 2023 |  | October 28, 2022 |  |  |
|  | (in millions) |
| Warranty liability: |  |  |  |  |  |  |  |  |  |
| Warranty liability at beginning of period | $ | 439 |  |  | $ | 463 |  |  | $ | 467 |  |  | $ | 480 |  |  |  |
| Costs accrued for new warranty contracts and changes in estimates for pre-existing warranties (a) | 208 |  |  | 243 |  |  | 605 |  |  | 710 |  |  |  |
| Service obligations honored | (203) |  |  | (241) |  |  | (628) |  |  | (725) |  |  |  |
| Warranty liability at end of period | $ | 444 |  |  | $ | 465 |  |  | $ | 444 |  |  | $ | 465 |  |  |  |

[0001571996-23-000046:notes:278]
[same as prior period, unchanged from 0001571996-23-000032:notes:271]

[0001571996-23-000046:notes:279]
[same as prior period, unchanged from 0001571996-23-000032:notes:272]

[0001571996-23-000046:notes:280]
[same as prior period, unchanged from 0001571996-23-000032:notes:273]

[0001571996-23-000046:notes:281]
[same as prior period, unchanged from 0001571996-23-000032:notes:274]

[0001571996-23-000046:notes:282]
|  | Three Months Ended |  | Nine Months Ended |  |  |  |  |
|  | November 3, 2023 |  | October 28, 2022 |  | November 3, 2023 |  | October 28, 2022 |  |  |  |  |  |  |
|  | (in millions) |  |  |  |  |
| Severance liability: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Severance liability at beginning of period | $ | 457 |  |  | $ | 88 |  |  | $ | 408 |  |  | $ | 74 |  |  |  |  |  |  |  |
| Severance charges | 22 |  |  | 97 |  |  | 434 |  |  | 160 |  |  |  |  |  |  |  |
| Cash paid and other | (277) |  |  | (105) |  |  | (640) |  |  | (154) |  |  |  |  |  |  |  |
| Severance liability at end of period | $ | 202 |  |  | $ | 80 |  |  | $ | 202 |  |  | $ | 80 |  |  |  |  |  |  |  |

[0001571996-23-000046:notes:283]
[same as prior period, unchanged from 0001571996-23-000032:notes:276]

[0001571996-23-000046:notes:284]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 3, 2023 |  | October 28, 2022 |  | November 3, 2023 |  | October 28, 2022 |
|  | (in millions) |
| Severance charges: |  |  |  |  |  |  |  |
| Cost of net revenue | $ | 7 |  |  | $ | 21 |  |  | $ | 54 |  |  | $ | 22 |  |
| Selling, general, and administrative | 14 |  |  | 57 |  |  | 365 |  |  | 114 |  |
| Research and development | 1 |  |  | 19 |  |  | 15 |  |  | 24 |  |
| Total severance charges | $ | 22 |  |  | $ | 97 |  |  | $ | 434 |  |  | $ | 160 |  |

[0001571996-23-000046:notes:285]
[same as prior period, unchanged from 0001571996-23-000032:notes:278]

[0001571996-23-000046:notes:286]
The Company maintains a Supply Chain Finance Program (the “SCF Program”), which enables eligible suppliers of the Company, at the supplier's sole discretion, to sell receivables due from the Company to a third-party financial institution.  The Company has no involvement in establishing the terms or conditions of the arrangement between its suppliers and the financial institution and no economic interest in a supplier's decision to sell a receivable.  Suppliers may elect to sell varying amounts of their outstanding receivables as part of the SCF Program.  The Company does not provide legally secured assets or other forms of guarantees under the arrangement.

[0001571996-23-000046:notes:287]
The SCF Program does not impact the Company's liquidity as payments for participating supplier invoices are remitted by the Company to the financial institution on the original invoice due date, regardless of whether an individual invoice is sold by the supplier to the financial institution.  Further, the Company negotiates payment terms with suppliers regardless of their decision to participate in the SCF Program.  Payment terms with such suppliers vary and do not exceed 120 days.

[0001571996-23-000046:notes:288]
[same as prior period, unchanged from 0001571996-23-000032:notes:281]

[0001571996-23-000046:notes:289]
As of both November 3, 2023 and February 3, 2023, the Company had $1.0 billion included within Accounts Payable representing invoices due to suppliers confirmed as valid under the SCF Program.

[0001571996-23-000046:notes:290]
[same as prior period, unchanged from 0001571996-23-000032:notes:283]

[0001571996-23-000046:notes:291]
[same as prior period, unchanged from 0001571996-23-000032:notes:284]

[0001571996-23-000046:notes:292]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 3, 2023 |  | October 28, 2022 |  | November 3, 2023 |  | October 28, 2022 |  |  |
|  | (in millions) |
| Interest and other, net: |  |  |  |  |  |  |  |  |  |
| Investment income, primarily interest | $ | 88 |  |  | $ | 21 |  |  | $ | 213 |  |  | $ | 52 |  |  |  |
| Gain (loss) on investments, net | 8 |  |  | 44 |  |  | (36) |  |  | (197) |  |  |  |
| Interest expense | (371) |  |  | (272) |  |  | (1,128) |  |  | (835) |  |  |  |
| Foreign exchange | (30) |  |  | (72) |  |  | (127) |  |  | (227) |  |  |  |
| Legal settlement, net | — |  |  | (1,000) |  |  | — |  |  | (1,000) |  |  |  |
| Other | (1) |  |  | (29) |  |  | (43) |  |  | (73) |  |  |  |
| Total interest and other, net | $ | (306) |  |  | $ | (1,308) |  |  | $ | (1,121) |  |  | $ | (2,280) |  |  |  |


## us-gaap:SubsequentEventsTextBlock

[0001571996-23-000046:notes:293]
SUBSEQUENT EVENTS 
On November 22, 2023, subsequent to the close of the Company’s third quarter of Fiscal 2024, VMware was acquired by Broadcom Inc. (“Broadcom”).  Upon the completion of Broadcom’s acquisition of VMware, Mr. Dell relinquished his direct ownership interest in VMware and his position as Chairman of the Board of VMware, Inc.  Mr. Dell’s subsequent ownership interest in Broadcom does not represent control or significant influence to an extent that the transacting parties might be prevented from fully pursuing their own separate interests.  As a result, the Company determined that the acquisition terminated the preexisting related party relationship with VMware and that no related party relationship exists with either Broadcom or VMware as of the date of issuance of this report.
Other than the matter identified above, there were no known events occurring after November 3, 2023 and up until the date of issuance of this report that would materially affect the information presented herein.
