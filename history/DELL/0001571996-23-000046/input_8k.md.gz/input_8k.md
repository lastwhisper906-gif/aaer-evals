# DELL 8-K — 0001571996-23-000039 filed 2023-11-30

## item codes, every 8-K on or before 2023-12-08

- 2023-12-05 0001571996-23-000042 — 3.02
- 2023-12-04 0001193125-23-288428 — 8.01, 9.01
- 2023-11-30 0001571996-23-000039 — 2.02, 9.01
- 2023-10-05 0001193125-23-251131 — 7.01, 8.01, 9.01
- 2023-10-02 0001571996-23-000036 — 5.02 — amendment of 0001571996-23-000034
- 2023-09-26 0001571996-23-000034 — 5.02
- 2023-08-31 0001571996-23-000029 — 2.02, 9.01
- 2023-08-09 0001571996-23-000026 — 5.02 — amendment of 0001571996-23-000002
- 2023-07-28 0001571996-23-000024 — 5.02
- 2023-07-13 0001193125-23-186639 — 3.02
- 2023-06-30 0001193125-23-180570 — 8.01, 9.01
- 2023-06-22 0001571996-23-000021 — 5.02, 5.07, 9.01
- 2023-06-15 0001193125-23-167472 — 8.01, 9.01
- 2023-06-01 0001571996-23-000014 — 2.02, 9.01
- 2023-03-02 0001571996-23-000002 — 2.02, 5.02, 9.01
- 2023-02-06 0001193125-23-024781 — 7.01, 9.01
- 2023-01-24 0001193125-23-014260 — 1.01, 2.03, 9.01
- 2023-01-11 0001193125-23-006528 — 8.01, 9.01
- 2022-11-21 0001571996-22-000041 — 2.02, 9.01
- 2022-11-16 0001571996-22-000038 — 8.01
- 2022-08-25 0001571996-22-000028 — 2.02, 9.01
- 2022-07-18 0001193125-22-196334 — 2.03, 8.01
- 2022-06-29 0001571996-22-000025 — 3.03, 5.03, 5.07, 8.01, 9.01
- 2022-05-26 0001571996-22-000013 — 2.02, 9.01
- 2022-02-24 0001571996-22-000004 — 2.02, 8.01, 9.01
- 2021-12-20 0001193125-21-362482 — 8.01, 9.01
- 2021-12-15 0001193125-21-357927 — 1.01, 2.03, 9.01
- 2021-12-07 0001193125-21-349218 — 8.01, 9.01
- 2021-11-23 0001571996-21-000060 — 2.02, 9.01
- 2021-11-05 0001571996-21-000057 — 1.02, 2.01, 7.01, 8.01, 9.01 — amendment, the index does not say of what
- 2021-11-01 0001571996-21-000052 — 8.01, 9.01
- 2021-11-01 0001193125-21-315488 — 1.01, 1.02, 2.01, 8.01, 9.01
- 2021-10-21 0001193125-21-304052 — 8.01, 9.01
- 2021-10-19 0001571996-21-000050 — 8.01, 9.01
- 2021-10-07 0001193125-21-294210 — 8.01, 9.01
- 2021-09-30 0001571996-21-000047 — 5.02
- 2021-09-27 0001571996-21-000045 — 8.01
- 2021-09-23 0001193125-21-280190 — 7.01, 8.01, 9.01
- 2021-09-20 0001193125-21-276810 — 7.01, 9.01
- 2021-08-26 0001571996-21-000037 — 2.02, 9.01
- 2021-07-01 0001571996-21-000034 — 3.02
- 2021-06-24 0001571996-21-000031 — 5.07
- 2021-06-24 0001193125-21-197644 — 7.01, 9.01
- 2021-06-16 0001571996-21-000029 — 5.02
- 2021-05-27 0001571996-21-000019 — 2.02, 9.01
- 2021-05-03 0001571996-21-000010 — 8.01, 9.01
- 2021-04-14 0001193125-21-116271 — 1.01, 7.01, 9.01
- 2021-02-25 0001571996-21-000003 — 2.02, 9.01
- 2021-02-18 0001193125-21-047844 — 1.01, 2.03, 9.01
- 2020-11-24 0001571996-20-000048 — 2.02, 9.01
- 2020-08-27 0001571996-20-000041 — 2.02, 9.01
- 2020-07-02 0001571996-20-000037 — 5.07
- 2020-05-28 0001571996-20-000028 — 2.02, 9.01
- 2020-04-09 0001193125-20-102602 — 1.01, 2.03, 9.01
- 2020-04-08 0001571996-20-000021 — 5.02
- 2020-04-03 0001571996-20-000019 — 8.01, 9.01
- 2020-03-26 0001571996-20-000015 — 7.01
- 2020-02-27 0001571996-20-000009 — 2.02, 8.01, 9.01
- 2020-02-18 0001571996-20-000005 — 8.01, 9.01
- 2020-01-09 0001571996-20-000002 — 3.02
- 2020-01-06 0001193125-20-002200 — 3.02
- 2019-12-13 0001193125-19-313947 — 3.02
- 2019-12-10 0001571996-19-000052 — 5.02
- 2019-12-02 0001571996-19-000044 — 5.02, 7.01, 9.01
- 2019-11-26 0001571996-19-000042 — 2.02, 9.01
- 2019-09-23 0001193125-19-252192 — 1.01, 2.03, 9.01
- 2019-08-29 0001571996-19-000036 — 2.02, 9.01
- 2019-08-22 0001193125-19-226939 — 7.01, 8.01, 9.01
- 2019-07-11 0001571996-19-000032 — 5.02, 5.07, 9.01
- 2019-07-03 0001571996-19-000030 — 3.02
- 2019-06-27 0001571996-19-000028 — 3.02
- 2019-05-30 0001571996-19-000021 — 2.02, 9.01
- 2019-04-02 0001571996-19-000010 — 5.02
- 2019-03-21 0001193125-19-082281 — 1.01, 1.02, 2.03, 9.01
- 2019-03-19 0001571996-19-000005 — 5.02, 9.01
- 2019-03-14 0001193125-19-074935 — 1.01, 2.03, 9.01
- 2019-03-07 0001193125-19-066045 — 8.01, 9.01
- 2019-02-28 0001571996-19-000002 — 2.02, 9.01
- 2018-12-28 0001193125-18-360943 — 1.01, 1.02, 3.01, 3.03, 5.02, 5.03, 7.01, 8.01, 9.01
- 2018-12-21 0001193125-18-356324 — 1.01, 2.03, 9.01
- 2018-12-14 0001193125-18-349469 — 8.01
- 2018-12-11 0001193125-18-346958 — 5.07, 8.01, 9.01
- 2018-11-29 0001571996-18-000041 — 2.02, 9.01
- 2018-11-28 0001571996-18-000037 — 7.01, 8.01, 9.01
- 2018-11-26 0001193125-18-333967 — 8.01, 9.01
- 2018-11-15 0001193125-18-328110 — 1.01, 9.01 — amendment of 0001193125-18-327222
- 2018-11-15 0001193125-18-327222 — 1.01, 7.01, 9.01
- 2018-10-03 0001193125-18-291390 — 8.01
- 2018-09-06 0001571996-18-000029 — 2.02, 9.01
- 2018-08-06 0001571996-18-000027 — 8.01, 9.01
- 2018-07-02 0001193125-18-210339 — 1.01, 7.01, 9.01
- 2018-06-28 0001571996-18-000024 — 5.07
- 2018-06-04 0001571996-18-000019 — 2.02, 9.01
- 2018-05-17 0001571996-18-000016 — 7.01
- 2018-04-26 0001571996-18-000009 — 7.01, 9.01
- 2018-03-08 0001193125-18-074168 — 2.02, 9.01
- 2018-02-02 0001193125-18-029947 — 7.01, 9.01
- 2017-12-07 0001571996-17-000042 — 2.02, 9.01
- 2017-10-24 0001571996-17-000037 — 1.01, 2.03, 9.01
- 2017-09-15 0001571996-17-000027 — 5.02
- 2017-09-07 0001571996-17-000017 — 2.02, 9.01
- 2017-08-24 0001571996-17-000014 — 8.01
- 2017-06-29 0001571996-17-000011 — 3.03, 5.07, 8.01, 9.01
- 2017-06-08 0001193125-17-197638 — 2.02, 9.01
- 2017-03-30 0001193125-17-102794 — 8.01
- 2017-03-30 0001193125-17-102777 — 2.02, 9.01
- 2017-03-09 0001193125-17-076981 — 1.01, 2.03, 9.01
- 2017-01-17 0001193125-17-011125 — 8.01
- 2016-12-15 0001193125-16-793722 — 8.01
- 2016-12-08 0001193125-16-787976 — 2.02, 9.01
- 2016-11-10 0001193125-16-765964 — 1.02, 8.01
- 2016-11-04 0001193125-16-760249 — 8.01
- 2016-09-13 0001193125-16-708600 — 3.02
- 2016-09-09 0001193125-16-706567 — 1.01, 1.02, 2.01, 2.03, 3.02, 3.03, 5.02, 9.01
- 2016-09-07 0001193125-16-703370 — 3.03, 5.07, 7.01, 8.01, 9.01
- 2016-09-06 0001193125-16-702057 — 2.02, 9.01
- 2016-08-31 0001193125-16-697268 — 8.01, 9.01
- 2016-08-26 0001193125-16-692921 — 8.01, 9.01
- 2016-07-11 0001193125-16-645610 — 8.01
- 2016-07-05 0001193125-16-641679 — 8.01
- 2016-06-22 0001193125-16-629055 — 1.01, 2.03, 8.01, 9.01
- 2016-06-21 0001193125-16-627071 — 8.01, 9.01
- 2016-06-10 0001193125-16-618483 — 2.02, 9.01
- 2016-06-09 0001193125-16-617893 — 8.01, 9.01

## late-filing notifications on or before 2023-12-08

- none on or before 2023-12-08

## item 2.02 — earnings release, exhibit 99.1

[0001571996-23-000039:8k_2_02:1]
EX-99.1
2
exhibit991earnings8kq3fy24.htm
EX-99.1

[0001571996-23-000039:8k_2_02:2]
Document

[0001571996-23-000039:8k_2_02:3]
Exhibit 99.1

[0001571996-23-000039:8k_2_02:4]
Dell Technologies Delivers Third Quarter Fiscal 2024 Financial Results

[0001571996-23-000039:8k_2_02:5]
News summary

[0001571996-23-000039:8k_2_02:6]
•Third quarter revenue of $22.3 billion

[0001571996-23-000039:8k_2_02:7]
•Operating income of $1.5 billion and non-GAAP operating income of $2 billion

[0001571996-23-000039:8k_2_02:8]
•Diluted earnings per share of $1.36, and non-GAAP diluted earnings per share of $1.88

[0001571996-23-000039:8k_2_02:9]
•Third quarter cash flow from operations of $2.2 billion, with $9.9 billion throughout the last 12 months

[0001571996-23-000039:8k_2_02:10]
ROUND ROCK, Texas — November 30, 2023

[0001571996-23-000039:8k_2_02:11]
Full story

[0001571996-23-000039:8k_2_02:12]
Dell Technologies (NYSE: DELL) announces financial results for its fiscal 2024 third quarter. Revenue was $22.3 billion, down 10% year-over-year. The company generated operating income of $1.5 billion and non-GAAP operating income of $2 billion, down 16% and 17% year-over-year, respectively. Diluted earnings per share was $1.36, and non-GAAP diluted earnings per share was $1.88. Cash flow from operations for the third quarter was $2.2 billion, driven by profitability and strong working capital performance. The company has generated $9.9 billion of cash flow from operations throughout the last 12 months.

[0001571996-23-000039:8k_2_02:13]
Dell ended the quarter with remaining performance obligations of $39 billion, recurring revenue of $5.6 billion, up 4% year-over-year, and deferred revenue of $29.1 billion, up 7% year-over-year, primarily due to increases in software and hardware maintenance agreements. The company’s cash and investment balance was $9.9 billion.

[0001571996-23-000039:8k_2_02:14]
“We have proven our ability to generate strong cash flow through profitability and working capital efficiency, including $9.9 billion of cash flow from operations over the last twelve months,” said Yvonne McGill, chief financial officer, Dell Technologies. “Our long-term financial framework and capital allocation plan continue to deliver results, with $1 billion returned to shareholders in the third quarter through share repurchases and dividends.”

[0001571996-23-000039:8k_2_02:15]
Third Quarter Fiscal 2024 Financial Results

[0001571996-23-000039:8k_2_02:16]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | November 3, 2023 |  | October 28, 2022 |  | Change |  | November 3, 2023 |  | October 28, 2022 |  | Change |
|  | (in millions, except per share amounts and percentages; unaudited) |
| Net revenue | $ | 22,251 |  |  | $ | 24,721 |  |  | (10)% |  | $ | 66,107 |  |  | $ | 77,262 |  |  | (14)% |
| Operating income | $ | 1,486 |  |  | $ | 1,762 |  |  | (16)% |  | $ | 3,720 |  |  | $ | 4,582 |  |  | (19)% |
| Net income | $ | 1,004 |  |  | $ | 241 |  |  | 317% |  | $ | 2,037 |  |  | $ | 1,816 |  |  | 12% |
| Earnings per share - diluted | $ | 1.36 |  |  | $ | 0.33 |  |  | 312% |  | $ | 2.78 |  |  | $ | 2.41 |  |  | 15% |
| Non-GAAP net revenue | $ | 22,251 |  |  | $ | 24,721 |  |  | (10)% |  | $ | 66,107 |  |  | $ | 77,262 |  |  | (14)% |
| Non-GAAP operating income | $ | 1,964 |  |  | $ | 2,380 |  |  | (17)% |  | $ | 5,539 |  |  | $ | 6,467 |  |  | (14)% |
| Non-GAAP net income | $ | 1,389 |  |  | $ | 1,705 |  |  | (19)% |  | $ | 3,635 |  |  | $ | 4,405 |  |  | (17)% |
| Adjusted EBITDA | $ | 2,579 |  |  | $ | 2,946 |  |  | (12)% |  | $ | 7,378 |  |  | $ | 8,004 |  |  | (8)% |
| Non-GAAP earnings per share - diluted | $ | 1.88 |  |  | $ | 2.30 |  |  | (18)% |  | $ | 4.93 |  |  | $ | 5.81 |  |  | (15)% |

[0001571996-23-000039:8k_2_02:17]
Information about Dell Technologies’ use of non-GAAP financial information is provided under “Non-GAAP Financial Measures” below. All comparisons in this press release are year-over-year unless otherwise noted.

[0001571996-23-000039:8k_2_02:18]
Infrastructure Solutions Group delivered third quarter revenue of $8.5 billion, flat sequentially and down 12% year-over-year. Servers and networking revenue was $4.7 billion, with 9% sequential growth driven by AI-optimized servers. Storage revenue was $3.8 billion, down 8% sequentially with demand strength in unstructured data solutions and data protection. Operating income was $1.1 billion.

[0001571996-23-000039:8k_2_02:19]
Client Solutions Group delivered third quarter revenue of $12.3 billion, down 11% year-over-year and 5% sequentially. Commercial client revenue was $9.8 billion, and Consumer revenue was $2.4 billion. Operating income was $925 million.

[0001571996-23-000039:8k_2_02:20]
“Technology is everywhere, and we continue to focus on extending our leadership positions and turning new opportunities into incremental growth,” said Jeff Clarke, vice chairman and chief operating officer. “Our servers and networking business was up 9% sequentially fueled by customer interest in generative AI. And heading into FY25, we expect revenue growth given the tailwinds to our business.”

[0001571996-23-000039:8k_2_02:21]
Dell continued to expand its broad portfolio to help customers meet their performance, cost and security requirements across clouds, on premises and at the edge.

[0001571996-23-000039:8k_2_02:22]
•The Dell Generative AI Solutions portfolio expanded with new on-premises offerings that make GenAI implementations simpler with high-performing IT infrastructure, multicloud access and professional services.

[0001571996-23-000039:8k_2_02:23]
•ObjectScale XF960 is an all-flash, scale-out appliance for GenAI and real-time analytics based on Dell’s software-defined object storage software, which can run on Linux and Red Hat Open Shift on PowerEdge servers.

[0001571996-23-000039:8k_2_02:24]
•Dell’s collaboration with Meta makes it easy for customers to deploy Meta's Llama 2 models on premises with Dell's GenAI portfolio of IT infrastructure, client devices and professional services.

[0001571996-23-000039:8k_2_02:25]
•Dell’s collaboration with Hugging Face helps enterprises create, fine-tune and implement their own open-source GenAI models with the Hugging Face community on Dell infrastructure products and services.

[0001571996-23-000039:8k_2_02:26]
2

[0001571996-23-000039:8k_2_02:27]
•Dell APEX Cloud Platform for Microsoft Azure simplifies the hybrid cloud experience by helping customers extend Azure to data center and edge locations.

[0001571996-23-000039:8k_2_02:28]
•Dell APEX Cloud Platform for Red Hat OpenShift, the first fully integrated application delivery platform purpose-built for Red Hat OpenShift, helps customers deploy, manage and run containers alongside virtual machines on premises.

[0001571996-23-000039:8k_2_02:29]
•The Precision 7875 Tower is Dell’s most scalable and powerful AMD processor-based workstation and lets companies develop and fine-tune complex GenAI models locally before deploying them at scale.

[0001571996-23-000039:8k_2_02:30]
Operating Segments Results

[0001571996-23-000039:8k_2_02:31]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | November 3, 2023 |  | October 28, 2022 |  | Change |  | November 3, 2023 |  | October 28, 2022 |  | Change |
|  | (in millions, except percentages; unaudited) |
| Infrastructure Solutions Group (ISG): |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Servers and networking | $ | 4,656 |  | $ | 5,201 |  |  | (10)% |  | $ | 12,767 |  |  | $ | 15,458 |  |  | (17)% |
| Storage | 3,843 |  |  | 4,429 |  |  | (13)% |  | 11,786 |  |  | 12,993 |  |  | (9)% |
| Total ISG net revenue | $ | 8,499 |  |  | $ | 9,630 |  |  | (12)% |  | $ | 24,553 |  |  | $ | 28,451 |  |  | (14)% |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| ISG operating income | $ | 1,069 |  |  | $ | 1,374 |  |  | (22)% |  | $ | 2,858 |  |  | $ | 3,502 |  |  | (18)% |
| % of ISG net revenue | 12.6 | % |  | 14.3 | % |  |  |  | 11.6 | % |  | 12.3 | % |  |  |
| % of total reportable segment operating income | 54 | % |  | 56 | % |  |  |  | 51 | % |  | 53 | % |  |  |
| Client Solutions Group (CSG): |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 9,835 |  |  | $ | 10,747 |  |  | (8)% |  | $ | 30,251 |  |  | $ | 34,859 |  |  | (13)% |
| Consumer | 2,441 |  |  | 3,028 |  |  | (19)% |  | 6,950 |  |  | 9,993 |  |  | (30)% |
| Total CSG net revenue | $ | 12,276 |  |  | $ | 13,775 |  |  | (11)% |  | $ | 37,201 |  |  | $ | 44,852 |  |  | (17)% |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| CSG operating income | $ | 925 |  |  | $ | 1,060 |  |  | (13)% |  | $ | 2,786 |  |  | $ | 3,153 |  |  | (12)% |
| % of CSG net revenue | 7.5 | % |  | 7.7 | % |  |  |  | 7.5 | % |  | 7.0 | % |  |  |
| % of total reportable segment operating income | 46 | % |  | 44 | % |  |  |  | 49 | % |  | 47 | % |  |  |

[0001571996-23-000039:8k_2_02:32]
Conference call information

[0001571996-23-000039:8k_2_02:33]
As previously announced, the company will hold a conference call to discuss its performance and financial guidance on Nov. 30 at 3:30 p.m. CST. Prior to the start of the conference call, prepared remarks and a presentation containing additional financial and operating information prior to financial guidance may be downloaded from investors.delltechnologies.com. The conference call will be broadcast live over the internet and can be accessed at https://investors.delltechnologies.com/news-events/upcoming-events

[0001571996-23-000039:8k_2_02:34]
For those unable to listen to the live broadcast, the final remarks and presentation with financial guidance will be available following the broadcast, and an archived version will be available at the same location for one year.

[0001571996-23-000039:8k_2_02:35]
3

[0001571996-23-000039:8k_2_02:36]
Environmental, Social and Governance (ESG)

[0001571996-23-000039:8k_2_02:37]
Our Environmental, Social and Governance (ESG) efforts focus on driving positive impact for people and our planet while delivering long-term value for our stakeholders. ESG resources can be accessed at https://www.dell.com/en-us/dt/corporate/social-impact/reporting/esg-governance.htm

[0001571996-23-000039:8k_2_02:38]
About Dell Technologies

[0001571996-23-000039:8k_2_02:39]
Dell Technologies (NYSE:DELL) helps organizations and individuals build their digital future and transform how they work, live and play. The company provides customers with the industry’s broadest and most innovative technology and services portfolio for the data era.

[0001571996-23-000039:8k_2_02:40]
Contacts

[0001571996-23-000039:8k_2_02:41]
Investors: Investor_Relations@Dell.com

[0001571996-23-000039:8k_2_02:42]
Media: Media.Relations@Dell.com

[0001571996-23-000039:8k_2_02:43]
# # #

[0001571996-23-000039:8k_2_02:44]
Copyright © 2023 Dell Inc. or its subsidiaries. All Rights Reserved. Dell Technologies, Dell, EMC and Dell EMC are trademarks of Dell Inc. or its subsidiaries. Other trademarks may be trademarks of their respective owners.

[0001571996-23-000039:8k_2_02:45]
Non-GAAP Financial Measures:

[0001571996-23-000039:8k_2_02:46]
This press release presents information about non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, non-GAAP net income attributable to Dell Technologies Inc., non-GAAP earnings per share attributable to Dell Technologies Inc. – basic, and non-GAAP earnings per share attributable to Dell Technologies Inc. – diluted, which are non-GAAP financial measures provided as a supplement to the results provided in accordance with generally accepted accounting principles in the United States of America (“GAAP”). A reconciliation of each non-GAAP financial measure to the most directly comparable GAAP financial measure is provided in the attached tables for each of the fiscal periods indicated.

[0001571996-23-000039:8k_2_02:47]
Special Note on Forward-Looking Statements:

[0001571996-23-000039:8k_2_02:48]
Dell Technologies’ results or events in future periods could differ materially from those expressed or implied by these forward-looking statements because of risks, uncertainties, and other factors that include, but are not limited to, the following: adverse global economic conditions and instability in financial markets; competitive pressures; Dell Technologies’ reliance on third-party suppliers for products and components, including reliance on single-source or limited-source suppliers; Dell Technologies’ ability to achieve favorable pricing from its vendors; Dell Technologies’ ability to achieve  the intended benefits of its continuing strategic relationship with VMware, Inc.; Dell Technologies’ execution of its strategy; Dell Technologies’ ability to manage solutions and products and services transitions in an effective manner; Dell Technologies’ ability to deliver high-quality products, software, and services; cyber attacks or other data security incidents; Dell Technologies’ ability to successfully execute on strategic initiatives including acquisitions, divestitures or cost savings measures; Dell Technologies’ foreign operations and ability to generate substantial non-U.S. net revenue; Dell Technologies’ product, services, customer, and geographic sales mix, and seasonal sales trends; the performance of Dell Technologies’ sales channel partners; access to the capital markets by Dell Technologies or its customers; material impairment of the value of goodwill or intangible assets; weak economic conditions and the effect of additional regulation on Dell Technologies’ financial services activities; counterparty default risks; the loss by Dell Technologies of any contracts for ISG services and solutions and its ability to perform such contracts at their estimated costs; loss by Dell Technologies of government contracts; Dell Technologies’ ability to develop and protect its proprietary intellectual property or obtain licenses to intellectual property developed by others on commercially reasonable and competitive terms; disruptions in Dell Technologies’ infrastructure; Dell Technologies’ ability to hedge effectively its exposure to fluctuations in foreign currency exchange rates and interest rates; expiration of tax holidays or favorable tax rate structures, or unfavorable outcomes in tax audits and other tax compliance matters; impairment of portfolio investments; unfavorable results of legal proceedings; expectations relating to environmental, social and governance (ESG) considerations; compliance requirements of changing environmental and safety laws, human rights laws, or other laws; the effect of armed hostilities, terrorism, natural disasters, or public health issues; the effect of global climate change and legal, regulatory, or market measures to address climate change; Dell Technologies’ dependence on the services of Michael Dell and key employees; Dell Technologies’ level of indebtedness; and business and financial factors and legal restrictions affecting continuation of Dell Technologies’ quarterly cash dividend policy and dividend rate.

[0001571996-23-000039:8k_2_02:49]
This list of risks, uncertainties, and other factors is not complete. Dell Technologies discusses some of these matters more fully, as well as certain risk factors that could affect Dell Technologies’ business, financial condition, results of operations, and prospects, in its reports filed

[0001571996-23-000039:8k_2_02:50]
4

[0001571996-23-000039:8k_2_02:51]
with the SEC, including Dell Technologies’ annual report on Form 10-K for the fiscal year ended February 3, 2023, quarterly reports on Form 10-Q, and current reports on Form 8-K. These filings are available for review through the SEC’s website at www.sec.gov. Any or all forward-looking statements Dell Technologies makes may turn out to be wrong and can be affected by inaccurate assumptions Dell Technologies might make or by known or unknown risks, uncertainties, and other factors, including those identified in this press release. Accordingly, you should not place undue reliance on the forward-looking statements made in this press release, which speak only as of its date. Dell Technologies does not undertake to update, and expressly disclaims any duty to update, its forward-looking statements, whether as a result of circumstances or events that arise after the date they are made, new information, or otherwise.

[0001571996-23-000039:8k_2_02:52]
5

[0001571996-23-000039:8k_2_02:53]
DELL TECHNOLOGIES INC.

[0001571996-23-000039:8k_2_02:54]
Consolidated Statements of Income and Related Financial Highlights

[0001571996-23-000039:8k_2_02:55]
(in millions, except percentages; unaudited)

[0001571996-23-000039:8k_2_02:56]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | November 3, 2023 |  | October 28, 2022 |  | Change |  | November 3, 2023 |  | October 28, 2022 |  | Change |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Products | $ | 16,233 |  |  | $ | 18,938 |  |  | (14)% |  | $ | 48,204 |  |  | $ | 60,212 |  |  | (20)% |
| Services | 6,018 |  |  | 5,783 |  |  | 4% |  | 17,903 |  |  | 17,050 |  |  | 5% |
| Total net revenue | 22,251 |  |  | 24,721 |  |  | (10)% |  | 66,107 |  |  | 77,262 |  |  | (14)% |
| Cost of net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Products | 13,546 |  |  | 15,601 |  |  | (13)% |  | 39,923 |  |  | 50,281 |  |  | (21)% |
| Services | 3,557 |  |  | 3,413 |  |  | 4% |  | 10,631 |  |  | 10,051 |  |  | 6% |
| Total cost of net revenue | 17,103 |  |  | 19,014 |  |  | (10)% |  | 50,554 |  |  | 60,332 |  |  | (16)% |
| Gross margin | 5,148 |  |  | 5,707 |  |  | (10)% |  | 15,553 |  |  | 16,930 |  |  | (8)% |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative | 2,970 |  |  | 3,268 |  |  | (9)% |  | 9,748 |  |  | 10,364 |  |  | (6)% |
| Research and development | 692 |  |  | 677 |  |  | 2% |  | 2,085 |  |  | 1,984 |  |  | 5% |
| Total operating expenses | 3,662 |  |  | 3,945 |  |  | (7)% |  | 11,833 |  |  | 12,348 |  |  | (4)% |
| Operating income | 1,486 |  |  | 1,762 |  |  | (16)% |  | 3,720 |  |  | 4,582 |  |  | (19)% |
| Interest and other, net | (306) |  |  | (1,308) |  |  | 77% |  | (1,121) |  |  | (2,280) |  |  | 51% |
| Income before income taxes | 1,180 |  |  | 454 |  |  | 160% |  | 2,599 |  |  | 2,302 |  |  | 13% |
| Income tax expense | 176 |  |  | 213 |  |  | (17)% |  | 562 |  |  | 486 |  |  | 16% |
| Net income | 1,004 |  |  | 241 |  |  | 317% |  | 2,037 |  |  | 1,816 |  |  | 12% |
| Less: Net loss attributable to non-controlling interests | (2) |  |  | (4) |  |  | 50% |  | (14) |  |  | (12) |  |  | (17)% |
| Net income attributable to Dell Technologies Inc. | $ | 1,006 |  |  | $ | 245 |  |  | 311% |  | $ | 2,051 |  |  | $ | 1,828 |  |  | 12% |
| Percentage of Total Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Gross margin | 23.1 | % |  | 23.1 | % |  |  |  | 23.5 | % |  | 21.9 | % |  |  |
| Selling, general, and administrative | 13.3 | % |  | 13.3 | % |  |  |  | 14.7 | % |  | 13.4 | % |  |  |
| Research and development | 3.1 | % |  | 2.7 | % |  |  |  | 3.2 | % |  | 2.6 | % |  |  |
| Operating expenses | 16.4 | % |  | 16.0 | % |  |  |  | 17.9 | % |  | 16.0 | % |  |  |
| Operating income | 6.7 | % |  | 7.1 | % |  |  |  | 5.6 | % |  | 5.9 | % |  |  |
| Income before income taxes | 5.3 | % |  | 1.8 | % |  |  |  | 3.9 | % |  | 3.0 | % |  |  |
| Net income | 4.5 | % |  | 1.0 | % |  |  |  | 3.1 | % |  | 2.4 | % |  |  |
| Income tax rate | 14.9 | % |  | 46.9 | % |  |  |  | 21.6 | % |  | 21.1 | % |  |  |

[0001571996-23-000039:8k_2_02:57]
Amounts are based on underlying data and may not visually foot due to rounding.

[0001571996-23-000039:8k_2_02:58]
6

[0001571996-23-000039:8k_2_02:59]
DELL TECHNOLOGIES INC.

[0001571996-23-000039:8k_2_02:60]
Consolidated Statements of Financial Position

[0001571996-23-000039:8k_2_02:61]
(in millions; unaudited)

[0001571996-23-000039:8k_2_02:62]
|  | November 3, 2023 |  | February 3, 2023 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 8,298 |  |  | $ | 8,607 |  |
| Accounts receivable, net of allowance of $74 and $78 | 9,720 |  |  | 12,482 |  |
| Due from related party, net | 386 |  |  | 378 |  |
| Short-term financing receivables, net of allowance of $73 and $142 | 4,540 |  |  | 5,281 |  |
| Inventories | 3,381 |  |  | 4,776 |  |
| Other current assets | 10,662 |  |  | 10,827 |  |
| Total current assets | 36,987 |  |  | 42,351 |  |
| Property, plant, and equipment, net | 6,222 |  |  | 6,209 |  |
| Long-term investments | 1,294 |  |  | 1,518 |  |
| Long-term financing receivables, net of allowance of $80 and $59 | 5,773 |  |  | 5,638 |  |
| Goodwill | 19,616 |  |  | 19,676 |  |
| Intangible assets, net | 5,907 |  |  | 6,468 |  |
| Due from related party, net | 239 |  |  | 440 |  |
| Other non-current assets | 7,226 |  |  | 7,311 |  |
| Total assets | $ | 83,264 |  |  | $ | 89,611 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Short-term debt | $ | 6,498 |  |  | $ | 6,573 |  |
| Accounts payable | 19,478 |  |  | 18,598 |  |
| Due to related party | 1,246 |  |  | 2,067 |  |
| Accrued and other | 6,449 |  |  | 8,874 |  |
| Short-term deferred revenue | 15,206 |  |  | 15,542 |  |
| Total current liabilities | 48,877 |  |  | 51,654 |  |
| Long-term debt | 20,119 |  |  | 23,015 |  |
| Long-term deferred revenue | 13,847 |  |  | 14,744 |  |
| Other non-current liabilities | 2,991 |  |  | 3,223 |  |
| Total liabilities | 85,834 |  |  | 92,636 |  |
| Stockholders’ equity (deficit): |  |  |  |
| Total Dell Technologies Inc. stockholders’ equity (deficit) | (2,664) |  |  | (3,122) |  |
| Non-controlling interests | 94 |  |  | 97 |  |
| Total stockholders’ equity (deficit) | (2,570) |  |  | (3,025) |  |
| Total liabilities and stockholders’ equity | $ | 83,264 |  |  | $ | 89,611 |  |

[0001571996-23-000039:8k_2_02:63]
7

[0001571996-23-000039:8k_2_02:64]
DELL TECHNOLOGIES INC.

[0001571996-23-000039:8k_2_02:65]
Consolidated Statements of Cash Flows

[0001571996-23-000039:8k_2_02:66]
(in millions; unaudited)

[0001571996-23-000039:8k_2_02:67]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 3, 2023 |  | October 28, 2022 |  | November 3, 2023 |  | October 28, 2022 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |
| Net income | $ | 1,004 |  |  | $ | 241 |  |  | $ | 2,037 |  |  | $ | 1,816 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: | 1,148 |  |  | 155 |  |  | 5,106 |  |  | (965) |  |
| Change in cash from operating activities | 2,152 |  |  | 396 |  |  | 7,143 |  |  | 851 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |
| Purchases of investments | (30) |  |  | (21) |  |  | (143) |  |  | (101) |  |
| Maturities and sales of investments | 23 |  |  | 31 |  |  | 150 |  |  | 99 |  |
| Capital expenditures and capitalized software development costs | (704) |  |  | (747) |  |  | (2,029) |  |  | (2,244) |  |
| Acquisition of businesses and assets, net | (127) |  |  | — |  |  | (127) |  |  | — |  |
| Other | 13 |  |  | 7 |  |  | 35 |  |  | 18 |  |
| Change in cash from investing activities | (825) |  |  | (730) |  |  | (2,114) |  |  | (2,228) |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |
| Proceeds from the issuance of common stock | 4 |  |  | — |  |  | 8 |  |  | 5 |  |
| Repurchases of common stock | (702) |  |  | (600) |  |  | (1,202) |  |  | (2,718) |  |
| Repurchases of common stock for employee tax withholdings | (42) |  |  | (22) |  |  | (354) |  |  | (380) |  |
| Payments of dividends and dividend equivalents | (266) |  |  | (238) |  |  | (811) |  |  | (728) |  |
| Proceeds from debt | 2,249 |  |  | 2,314 |  |  | 6,904 |  |  | 8,779 |  |
| Repayments of debt | (2,684) |  |  | (1,837) |  |  | (9,766) |  |  | (8,079) |  |
| Debt-related costs and other, net | (5) |  |  | (3) |  |  | (54) |  |  | (17) |  |
| Change in cash from financing activities | (1,446) |  |  | (386) |  |  | (5,275) |  |  | (3,138) |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash | (83) |  |  | (149) |  |  | (200) |  |  | (343) |  |
| Change in cash, cash equivalents, and restricted cash | (202) |  |  | (869) |  |  | (446) |  |  | (4,858) |  |
| Cash, cash equivalents, and restricted cash at beginning of the period | 8,650 |  |  | 6,093 |  |  | 8,894 |  |  | 10,082 |  |
| Cash, cash equivalents, and restricted cash at end of the period | $ | 8,448 |  |  | $ | 5,224 |  |  | $ | 8,448 |  |  | $ | 5,224 |  |

[0001571996-23-000039:8k_2_02:68]
8

[0001571996-23-000039:8k_2_02:69]
DELL TECHNOLOGIES INC.

[0001571996-23-000039:8k_2_02:70]
Segment Information

[0001571996-23-000039:8k_2_02:71]
(in millions, except percentages; unaudited; continued on next page)

[0001571996-23-000039:8k_2_02:72]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | November 3, 2023 |  | October 28, 2022 |  | Change |  | November 3, 2023 |  | October 28, 2022 |  | Change |
| Infrastructure Solutions Group (ISG): |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Servers and networking | $ | 4,656 |  | $ | 5,201 |  |  | (10)% |  | $ | 12,767 |  |  | $ | 15,458 |  |  | (17)% |
| Storage | 3,843 |  |  | 4,429 |  |  | (13)% |  | 11,786 |  |  | 12,993 |  |  | (9)% |
| Total ISG net revenue | $ | 8,499 |  |  | $ | 9,630 |  |  | (12)% |  | $ | 24,553 |  |  | $ | 28,451 |  |  | (14)% |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| ISG operating income | $ | 1,069 |  |  | $ | 1,374 |  |  | (22)% |  | $ | 2,858 |  |  | $ | 3,502 |  |  | (18)% |
| % of ISG net revenue | 12.6 | % |  | 14.3 | % |  |  |  | 11.6 | % |  | 12.3 | % |  |  |
| % of total reportable segment operating income | 54 | % |  | 56 | % |  |  |  | 51 | % |  | 53 | % |  |  |
| Client Solutions Group (CSG): |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 9,835 |  |  | $ | 10,747 |  |  | (8)% |  | $ | 30,251 |  |  | $ | 34,859 |  |  | (13)% |
| Consumer | 2,441 |  |  | 3,028 |  |  | (19)% |  | 6,950 |  |  | 9,993 |  |  | (30)% |
| Total CSG net revenue | $ | 12,276 |  |  | $ | 13,775 |  |  | (11)% |  | $ | 37,201 |  |  | $ | 44,852 |  |  | (17)% |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| CSG operating income | $ | 925 |  |  | $ | 1,060 |  |  | (13)% |  | $ | 2,786 |  |  | $ | 3,153 |  |  | (12)% |
| % of CSG net revenue | 7.5 | % |  | 7.7 | % |  |  |  | 7.5 | % |  | 7.0 | % |  |  |
| % of total reportable segment operating income | 46 | % |  | 44 | % |  |  |  | 49 | % |  | 47 | % |  |  |

[0001571996-23-000039:8k_2_02:73]
Amounts are based on underlying data and may not visually foot due to rounding.

[0001571996-23-000039:8k_2_02:74]
9

[0001571996-23-000039:8k_2_02:75]
DELL TECHNOLOGIES INC.

[0001571996-23-000039:8k_2_02:76]
Segment Information

[0001571996-23-000039:8k_2_02:77]
(in millions, except percentages; unaudited; continued)

[0001571996-23-000039:8k_2_02:78]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 3, 2023 |  | October 28, 2022 |  | November 3, 2023 |  | October 28, 2022 |
| Reconciliation to consolidated net revenue: |  |  |  |  |  |  |
| Reportable segment net revenue | $ | 20,775 |  |  | $ | 23,405 |  |  | $ | 61,754 |  |  | $ | 73,303 |  |
| Other businesses (a) | 1,474 |  |  | 1,313 |  |  | 4,345 |  |  | 3,951 |  |
| Unallocated transactions (b) | 2 |  |  | 3 |  |  | 8 |  |  | 8 |  |
| Total consolidated net revenue | $ | 22,251 |  |  | $ | 24,721 |  |  | $ | 66,107 |  |  | $ | 77,262 |  |
| Reconciliation to consolidated operating income: |  |  |  |  |  |  |  |
| Reportable segment operating income | $ | 1,994 |  |  | $ | 2,434 |  |  | $ | 5,644 |  |  | $ | 6,655 |  |
| Other businesses (a) | (32) |  |  | (57) |  |  | (112) |  |  | (192) |  |
| Unallocated transactions (b) | 2 |  |  | 3 |  |  | 7 |  |  | 4 |  |
| Impact of purchase accounting (c) | (2) |  |  | (21) |  |  | (10) |  |  | (33) |  |
| Amortization of intangibles | (205) |  |  | (245) |  |  | (613) |  |  | (732) |  |
| Transaction-related expenses (d) | (3) |  |  | (8) |  |  | (9) |  |  | (16) |  |
| Stock-based compensation expense (e) | (227) |  |  | (235) |  |  | (675) |  |  | (703) |  |
| Other corporate expenses (f) | (41) |  |  | (109) |  |  | (512) |  |  | (401) |  |
| Total consolidated operating income | $ | 1,486 |  |  | $ | 1,762 |  |  | $ | 3,720 |  |  | $ | 4,582 |  |

[0001571996-23-000039:8k_2_02:79]
_________________

[0001571996-23-000039:8k_2_02:80]
(a)Other businesses consists of: 1) Dell’s resale of standalone VMware, Inc. products and services, “VMware Resale,” 2) Secureworks, and 3) Virtustream, and do not meet the requirements for a reportable segment, either individually or collectively.

[0001571996-23-000039:8k_2_02:81]
(b)Unallocated transactions includes other corporate items that are not allocated to Dell Technologies’ reportable segments.

[0001571996-23-000039:8k_2_02:82]
(c)Impact of purchase accounting includes non-cash purchase accounting adjustments that are primarily related to the EMC merger transaction.

[0001571996-23-000039:8k_2_02:83]
(d)Transaction-related expenses includes acquisition, integration, and divestiture related costs. From time to time, this category also may include transaction-related income related to divestitures of businesses or asset sales.

[0001571996-23-000039:8k_2_02:84]
(e)Stock-based compensation expense consists of equity awards granted based on the estimated fair value of those awards at grant date.

[0001571996-23-000039:8k_2_02:85]
(f)Other corporate expenses includes severance, impairment charges, incentive charges related to equity investments, payroll taxes associated with stock-based compensation, facilities action, and other costs.

[0001571996-23-000039:8k_2_02:86]
10

[0001571996-23-000039:8k_2_02:87]
SUPPLEMENTAL SELECTED NON-GAAP FINANCIAL MEASURES

[0001571996-23-000039:8k_2_02:88]
These tables present information about the Company’s non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, non-GAAP net income attributable to Dell Technologies Inc., non-GAAP earnings per share attributable to Dell Technologies Inc. - basic, and non-GAAP earnings per share attributable to Dell Technologies Inc. - diluted, which are non-GAAP financial measures provided as a supplement to the results provided in accordance with generally accepted accounting principles in the United States of America (“GAAP”). A detailed discussion of Dell Technologies’ reasons for including these non-GAAP financial measures, the limitations associated with these measures, the items excluded from these measures, and our reason for excluding those items are presented in “Management’s Discussion and Analysis of Financial Condition and Results of Operations — Non-GAAP Financial Measures” in our periodic reports filed with the SEC. Dell Technologies encourages investors to review the non-GAAP discussion in these reports in conjunction with the presentation of non-GAAP financial measures.

[0001571996-23-000039:8k_2_02:89]
11

[0001571996-23-000039:8k_2_02:90]
DELL TECHNOLOGIES INC.

[0001571996-23-000039:8k_2_02:91]
Selected Financial Measures

[0001571996-23-000039:8k_2_02:92]
(in millions, except per share amounts and percentages; unaudited)

[0001571996-23-000039:8k_2_02:93]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | November 3, 2023 |  | October 28, 2022 |  | Change |  | November 3, 2023 |  | October 28, 2022 |  | Change |
| Net revenue (a) | $ | 22,251 |  |  | $ | 24,721 |  |  | (10)% |  | $ | 66,107 |  |  | $ | 77,262 |  |  | (14)% |
| Non-GAAP gross margin | $ | 5,276 |  |  | $ | 5,865 |  |  | (10)% |  | $ | 15,976 |  |  | $ | 17,456 |  |  | (8)% |
| % of non-GAAP net revenue | 23.7 | % |  | 23.7 | % |  |  |  | 24.2 | % |  | 22.6 | % |  |  |
| Non-GAAP operating expenses | $ | 3,312 |  |  | $ | 3,485 |  |  | (5)% |  | $ | 10,437 |  |  | $ | 10,989 |  |  | (5)% |
| % of non-GAAP net revenue | 14.9 | % |  | 14.1 | % |  |  |  | 15.8 | % |  | 14.2 | % |  |  |
| Non-GAAP operating income | $ | 1,964 |  |  | $ | 2,380 |  |  | (17)% |  | $ | 5,539 |  | $ | 6,467 |  | (14)% |
| % of non-GAAP net revenue | 8.8 | % |  | 9.6 | % |  |  |  | 8.4 | % |  | 8.4 | % |  |  |
| Non-GAAP net income | $ | 1,389 |  |  | $ | 1,705 |  |  | (19)% |  | $ | 3,635 |  |  | $ | 4,405 |  |  | (17)% |
| % of non-GAAP net revenue | 6.2 | % |  | 6.9 | % |  |  |  | 5.5 | % |  | 5.7 | % |  |  |
| Non-GAAP earnings per share - diluted | $ | 1.88 |  |  | $ | 2.30 |  |  | (18)% |  | $ | 4.93 |  |  | $ | 5.81 |  |  | (15)% |

[0001571996-23-000039:8k_2_02:94]
____________________

[0001571996-23-000039:8k_2_02:95]
(a)    Effective in the first quarter of Fiscal 2023, non-GAAP net revenue no longer differs from net revenue, the most comparable GAAP financial measure.

[0001571996-23-000039:8k_2_02:96]
Amounts are based on underlying data and may not visually foot due to rounding.

[0001571996-23-000039:8k_2_02:97]
DELL TECHNOLOGIES INC.

[0001571996-23-000039:8k_2_02:98]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-23-000039:8k_2_02:99]
(in millions, except percentages; unaudited; continued on next page)

[0001571996-23-000039:8k_2_02:100]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | November 3, 2023 |  | October 28, 2022 |  | Change |  | November 3, 2023 |  | October 28, 2022 |  | Change |
| Gross margin | $ | 5,148 |  |  | $ | 5,707 |  |  | (10)% |  | $ | 15,553 |  |  | $ | 16,930 |  |  | (8)% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 84 |  |  | 106 |  |  |  |  | 247 |  |  | 315 |  |  |  |
| Impact of purchase accounting | — |  |  | — |  |  |  |  | — |  |  | 2 |  |  |  |
| Stock-based compensation expense | 37 |  |  | 37 |  |  |  |  | 112 |  |  | 112 |  |  |  |
| Other corporate expenses | 7 |  |  | 15 |  |  |  |  | 64 |  |  | 97 |  |  |  |
| Non-GAAP gross margin | $ | 5,276 |  |  | $ | 5,865 |  |  | (10)% |  | $ | 15,976 |  |  | $ | 17,456 |  |  | (8)% |
| Operating expenses | $ | 3,662 |  |  | $ | 3,945 |  |  | (7)% |  | $ | 11,833 |  |  | $ | 12,348 |  |  | (4)% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | (121) |  |  | (139) |  |  |  |  | (366) |  |  | (417) |  |  |  |
| Impact of purchase accounting | (2) |  |  | (21) |  |  |  |  | (10) |  |  | (31) |  |  |  |
| Transaction-related expenses | (3) |  |  | (8) |  |  |  |  | (9) |  |  | (16) |  |  |  |
| Stock-based compensation expense | (190) |  |  | (198) |  |  |  |  | (563) |  |  | (591) |  |  |  |
| Other corporate expenses | (34) |  |  | (94) |  |  |  |  | (448) |  |  | (304) |  |  |  |
| Non-GAAP operating expenses | $ | 3,312 |  |  | $ | 3,485 |  |  | (5)% |  | $ | 10,437 |  |  | $ | 10,989 |  |  | (5)% |
| Operating income | $ | 1,486 |  |  | $ | 1,762 |  |  | (16)% |  | $ | 3,720 |  |  | $ | 4,582 |  |  | (19)% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 205 |  |  | 245 |  |  |  |  | 613 |  |  | 732 |  |  |  |
| Impact of purchase accounting | 2 |  |  | 21 |  |  |  |  | 10 |  |  | 33 |  |  |  |
| Transaction-related expenses | 3 |  |  | 8 |  |  |  |  | 9 |  |  | 16 |  |  |  |
| Stock-based compensation expense | 227 |  |  | 235 |  |  |  |  | 675 |  |  | 703 |  |  |  |
| Other corporate expenses | 41 |  |  | 109 |  |  |  |  | 512 |  |  | 401 |  |  |  |
| Non-GAAP operating income | $ | 1,964 |  |  | $ | 2,380 |  |  | (17)% |  | $ | 5,539 |  |  | $ | 6,467 |  |  | (14)% |
| Net income | $ | 1,004 |  |  | $ | 241 |  |  | 317 | % |  | $ | 2,037 |  |  | $ | 1,816 |  |  | 12% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 205 |  |  | 245 |  |  |  |  | 613 |  |  | 732 |  |  |  |
| Impact of purchase accounting | 2 |  |  | 21 |  |  |  |  | 10 |  |  | 33 |  |  |  |
| Transaction-related (income) expenses | (5) |  |  | 4 |  |  |  |  | 54 |  |  | (2) |  |  |  |
| Stock-based compensation expense | 227 |  |  | 235 |  |  |  |  | 675 |  |  | 703 |  |  |  |
| Other corporate expenses | 41 |  |  | 1,112 |  |  |  |  | 512 |  |  | 1,420 |  |  |  |
| Fair value adjustments on equity investments | (8) |  |  | (44) |  |  |  |  | 36 |  |  | 197 |  |  |  |
| Aggregate adjustment for income taxes | (77) |  |  | (109) |  |  |  |  | (302) |  |  | (494) |  |  |  |
| Non-GAAP net income | $ | 1,389 |  |  | $ | 1,705 |  |  | (19)% |  | $ | 3,635 |  |  | $ | 4,405 |  |  | (17)% |

[0001571996-23-000039:8k_2_02:101]
13

[0001571996-23-000039:8k_2_02:102]
DELL TECHNOLOGIES INC.

[0001571996-23-000039:8k_2_02:103]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-23-000039:8k_2_02:104]
(in millions, except percentages and per share amounts; unaudited; continued)

[0001571996-23-000039:8k_2_02:105]
|  | For the Three Months Ended November 3, 2023 |
|  | GAAP |  | Amortization of intangibles |  | Impact of purchase accounting |  | Transaction-related (income) expenses |  | Stock-based compensation expense |  | Other corporate expenses |  | Fair value adjustments on equity investments |  | Aggregate adjustment for income taxes |  | Aggregate adjustment for non-controlling interests |  | Non-GAAP |
| Net income attributable to Dell Technologies Inc. | $ | 1,006 |  |  | 205 |  |  | 2 |  |  | (5) |  |  | 227 |  |  | 41 |  |  | (8) |  |  | (77) |  |  | (2) |  |  | $ | 1,389 |  |
| Earnings per share - basic | $ | 1.39 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 1.92 |  |
| Earnings per share - diluted | $ | 1.36 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 1.88 |  |
| Weighted-average shares outstanding - basic | 722 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 722 |  |
| Weighted-average shares outstanding - diluted | 740 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 740 |  |

[0001571996-23-000039:8k_2_02:106]
|  | For the Three Months Ended October 28, 2022 |
|  | GAAP |  | Amortization of intangibles |  | Impact of purchase accounting |  | Transaction-related (income) expenses |  | Stock-based compensation expense |  | Other corporate expenses |  | Fair value adjustments on equity investments |  | Aggregate adjustment for income taxes |  | Aggregate adjustment for non-controlling interests |  | Non-GAAP |
| Net income attributable to Dell Technologies Inc. | $ | 245 |  |  | 245 |  |  | 21 |  |  | 4 |  |  | 235 |  |  | 1,112 |  |  | (44) |  |  | (109) |  |  | (2) |  |  | $ | 1,707 |  |
| Earnings per share - basic | $ | 0.34 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 2.34 |  |
| Earnings per share - diluted | $ | 0.33 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 2.30 |  |
| Weighted-average shares outstanding - basic | 728 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 728 |  |
| Weighted-average shares outstanding - diluted | 743 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 743 |  |

[0001571996-23-000039:8k_2_02:107]
DELL TECHNOLOGIES INC.

[0001571996-23-000039:8k_2_02:108]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-23-000039:8k_2_02:109]
(in millions, except percentages and per share amounts; unaudited; continued)

[0001571996-23-000039:8k_2_02:110]
|  | For the Nine Months Ended November 3, 2023 |
|  | GAAP |  | Amortization of intangibles |  | Impact of purchase accounting |  | Transaction-related (income) expenses |  | Stock-based compensation expense |  | Other corporate expenses |  | Fair value adjustments on equity investments |  | Aggregate adjustment for income taxes |  | Aggregate adjustment for non-controlling interests |  | Non-GAAP |
| Net income attributable to Dell Technologies Inc. | $ | 2,051 |  |  | 613 |  |  | 10 |  |  | 54 |  |  | 675 |  |  | 512 |  |  | 36 |  |  | (302) |  |  | (9) |  |  | $ | 3,640 |  |
| Earnings per share - basic | $ | 2.83 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 5.03 |  |
| Earnings per share - diluted | $ | 2.78 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 4.93 |  |
| Weighted-average shares outstanding - basic | 724 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 724 |  |
| Weighted-average shares outstanding - diluted | 738 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 738 |  |

[0001571996-23-000039:8k_2_02:111]
|  | For the Nine Months Ended October 28, 2022 |
|  | GAAP |  | Amortization of intangibles |  | Impact of purchase accounting |  | Transaction-related (income) expenses |  | Stock-based compensation expense |  | Other corporate expenses |  | Fair value adjustments on equity investments |  | Aggregate adjustment for income taxes |  | Aggregate adjustment for non-controlling interests |  | Non-GAAP |
| Net income attributable to Dell Technologies Inc. | $ | 1,828 |  |  | 732 |  |  | 33 |  |  | (2) |  |  | 703 |  |  | 1,420 |  |  | 197 |  |  | (494) |  |  | (7) |  |  | $ | 4,410 |  |
| Earnings per share - basic | $ | 2.47 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 5.96 |  |
| Earnings per share - diluted | $ | 2.41 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 5.81 |  |
| Weighted-average shares outstanding - basic | 740 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 740 |  |
| Weighted-average shares outstanding - diluted | 759 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 759 |  |

[0001571996-23-000039:8k_2_02:112]
15
