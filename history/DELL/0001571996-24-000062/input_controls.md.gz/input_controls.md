# DELL 10-Q controls and the auditor's report


## item_4_controls

[0001571996-24-000062:item_4_controls:1]
ITEM 4 — CONTROLS AND PROCEDURES

[0001571996-24-000062:item_4_controls:2]
This report includes the certifications of our Chief Executive Officer and Chief Financial Officer required by Rule 13a-14 under the Securities Exchange Act of 1934 (the “Exchange Act”).  See Exhibits 31.1 and 31.2 filed with this report.  This Item 4 includes information concerning the controls and control evaluations referred to in those certifications.

[0001571996-24-000062:item_4_controls:3]
Evaluation of Disclosure Controls and Procedures

[0001571996-24-000062:item_4_controls:4]
Disclosure controls and procedures (as defined in Rules 13a-15(e) and 15d-15(e) under the Exchange Act) are designed to provide reasonable assurance that information required to be disclosed in reports filed or submitted under the Exchange Act is recorded, processed, summarized, and reported within the time periods specified in SEC rules and forms and that such information is accumulated and communicated to management, including the Chief Executive Officer and the Chief Financial Officer, as appropriate to allow timely decisions regarding required disclosures.

[0001571996-24-000062:item_4_controls:5]
In connection with the preparation of this report, our management, under the supervision and with the participation of our Chief Executive Officer and Chief Financial Officer, conducted an evaluation of the effectiveness of the design and operation of our disclosure controls and procedures as of May 3, 2024.  Based on that evaluation, our Chief Executive Officer and Chief Financial Officer have concluded that our disclosure controls and procedures were effective at the reasonable assurance level as of May 3, 2024.

[0001571996-24-000062:item_4_controls:6]
Changes in Internal Control Over Financial Reporting

[0001571996-24-000062:item_4_controls:7]
We are in the process of an ongoing business transformation initiative to advance our capabilities and streamline systems and business processes to change the way we work and reduce costs.  As part of this initiative, we are upgrading and migrating certain accounting and finance systems.  During the fiscal quarter ended May 3, 2024, we implemented a new enterprise resource planning system, and we plan to migrate additional business processes in the future.  We have modified and will continue to modify the design and implementation of certain internal control processes to accommodate modifications to our business processes and finance procedures as the transformation continues.

[0001571996-24-000062:item_4_controls:8]
There were no other changes in our internal control over financial reporting during the fiscal quarter ended May 3, 2024 that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.

[0001571996-24-000062:item_4_controls:9]
77
