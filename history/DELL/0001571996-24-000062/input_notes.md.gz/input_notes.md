# DELL notes — 0001571996-24-000062


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001571996-24-000062:notes:1]
Basis of Presentation — The accompanying unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes filed with the U.S. Securities and Exchange Commission (“SEC”) in the Company’s Annual Report on Form 10-K for the fiscal year ended February 2, 2024.  These Condensed Consolidated Financial Statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“GAAP”).  In the opinion of management, the accompanying Condensed Consolidated Financial Statements reflect all adjustments of a normal recurring nature considered necessary to fairly state the financial position of the Company as of May 3, 2024 and February 2, 2024 and the results of its operations, corresponding comprehensive income, changes in stockholders’ equity, and cash flows for the three months ended May 3, 2024 and May 5, 2023.

[0001571996-24-000062:notes:2]
The preparation of financial statements in accordance with GAAP requires management to make estimates and assumptions that affect the amounts reported in the Condensed Consolidated Financial Statements and the accompanying Notes.  Actual results could differ materially from those estimates.  The results of its operations, corresponding comprehensive income, changes in stockholders’ equity, and cash flows for the three months ended May 3, 2024 and May 5, 2023 are not necessarily indicative of the results to be expected for the full fiscal year or for any other fiscal period.
The Company’s fiscal year is the 52- or 53-week period ending on the Friday nearest January 31.  Both the fiscal year ended February 2, 2024 (“Fiscal 2024”) and the fiscal year ending January 31, 2025 (“Fiscal 2025”) are 52-week periods.


## us-gaap:ConsolidationPolicyTextBlock

[0001571996-24-000062:notes:3]
Principles of Consolidation — These Condensed Consolidated Financial Statements include the accounts of Dell Technologies Inc., its wholly-owned subsidiaries, and the accounts of SecureWorks Corp. (“Secureworks”), which is majority-owned by Dell Technologies.  All intercompany transactions have been eliminated.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001571996-24-000062:notes:4]
Recently Issued Accounting Pronouncements

[0001571996-24-000062:notes:5]
Segment Reporting — In November 2023, the Financial Accounting Standards Board (“FASB”) issued guidance to improve disclosures about a public entity’s reportable segments by requiring disclosure of additional information about a reportable segment’s expenses on an annual and interim basis.  Public entities must adopt the new guidance for fiscal years beginning after December 15, 2023, with early adoption permitted.  Upon adoption, the guidance is required to be applied retrospectively to all prior periods presented in the financial statements.  Adoption of this new guidance will result in increased disclosures in the Notes to the Consolidated Financial Statements.

[0001571996-24-000062:notes:6]
Income Taxes — In December 2023, the FASB issued guidance which requires companies to provide disaggregated income tax disclosures within the income tax rate reconciliation and income taxes paid.  Public entities must adopt the new guidance for fiscal years beginning after December 15, 2024, with early adoption permitted.  Upon adoption, the guidance can be applied prospectively or retrospectively.  Adoption of this new guidance will result in increased disclosures in the Notes to the Consolidated Financial Statements.


## us-gaap:FairValueDisclosuresTextBlock

[0001571996-24-000062:notes:7]
[same as prior period, unchanged from 0001571996-23-000046:notes:5]

[0001571996-24-000062:notes:8]
|  | May 3, 2024 |  | February 2, 2024 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | Quoted Prices in Active Markets for Identical Assets |  | Significant Other Observable Inputs |  | Significant Unobservable Inputs |  |  |  | Quoted Prices in Active Markets for Identical Assets |  | Significant Other Observable Inputs |  | Significant Unobservable Inputs |  |  |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 1,915 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,915 |  |  | $ | 3,170 |  |  | $ | — |  |  | $ | — |  |  | $ | 3,170 |  |
| Marketable equity and other securities | 10 |  |  | — |  |  | — |  |  | 10 |  |  | 10 |  |  | — |  |  | — |  |  | 10 |  |
| Derivative instruments | — |  |  | 170 |  |  | — |  |  | 170 |  |  | — |  |  | 104 |  |  | — |  |  | 104 |  |
| Total assets | $ | 1,925 |  |  | $ | 170 |  |  | $ | — |  |  | $ | 2,095 |  |  | $ | 3,180 |  |  | $ | 104 |  |  | $ | — |  |  | $ | 3,284 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative instruments | $ | — |  |  | $ | 29 |  |  | $ | — |  |  | $ | 29 |  |  | $ | — |  |  | $ | 84 |  |  | $ | — |  |  | $ | 84 |  |
| Total liabilities | $ | — |  |  | $ | 29 |  |  | $ | — |  |  | $ | 29 |  |  | $ | — |  |  | $ | 84 |  |  | $ | — |  |  | $ | 84 |  |

[0001571996-24-000062:notes:9]
[same as prior period, unchanged from 0001571996-23-000046:notes:7]

[0001571996-24-000062:notes:10]
Money Market Funds — The Company’s investment in money market funds that are classified as cash equivalents hold underlying investments with a weighted average maturity of 90 days or less and are recognized at fair value.  The valuations of these securities are based on quoted prices in active markets for identical assets, when available, or pricing models whereby all significant inputs are observable or can be derived from, or corroborated by, observable market data.  The Company reviews security pricing and assesses money market fund liquidity on a quarterly basis.  As of May 3, 2024, the Company’s portfolio had no material exposure to money market funds with a fluctuating net asset value.

[0001571996-24-000062:notes:11]
[same as prior period, unchanged from 0001571996-23-000046:notes:9]

[0001571996-24-000062:notes:12]
[same as prior period, unchanged from 0001571996-23-000046:notes:10]

[0001571996-24-000062:notes:13]
Deferred Compensation Plans — The Company offers deferred compensation plans for eligible employees, which allow participants to defer a portion of their compensation.  Assets were the same as liabilities associated with the plans at approximately $227 million and $214 million as of May 3, 2024 and February 2, 2024, respectively, and are included in other assets and other liabilities on the Condensed Consolidated Statements of Financial Position.  The net impact to the Condensed Consolidated Statements of Income is not material since changes in the fair value of the assets substantially offset changes in the fair value of the liabilities.  As such, assets and liabilities associated with these plans have not been included in the recurring fair value table above.

[0001571996-24-000062:notes:14]
[same as prior period, unchanged from 0001571996-23-000046:notes:12]

[0001571996-24-000062:notes:15]
As of both May 3, 2024 and February 2, 2024, the Company held strategic investments in non-marketable equity and other securities of $1.3 billion.  As these investments represent early-stage companies without readily determinable fair values, they are not included in the recurring fair value table above.  See Note 3 of the Notes to the Condensed Consolidated Financial Statements for additional information about the Company’s strategic investments.

[0001571996-24-000062:notes:16]
[same as prior period, unchanged from 0001571996-23-000046:notes:14]

[0001571996-24-000062:notes:17]
|  | May 3, 2024 |  | February 2, 2024 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Notes | $ | 15.5 |  |  | $ | 15.5 |  |  | $ | 15.5 |  |  | $ | 15.8 |  |
| Legacy Notes | $ | 0.9 |  |  | $ | 1.0 |  |  | $ | 0.9 |  |  | $ | 1.0 |  |
| DFS Debt | $ | 9.0 |  |  | $ | 8.6 |  |  | $ | 9.5 |  |  | $ | 9.1 |  |

[0001571996-24-000062:notes:18]
[same as prior period, unchanged from 0001571996-23-000046:notes:16]


## us-gaap:InvestmentTextBlock

[0001571996-24-000062:notes:19]
INVESTMENTS
The Company has strategic investments in equity and other securities as well as investments in fixed income debt securities.  All equity and other securities as well as long-term fixed income debt securities are recorded as long-term investments while short-term fixed income debt securities are recorded as other current assets in the Condensed Consolidated Statements of Financial Position.

[0001571996-24-000062:notes:20]
Total investments were $1.5 billion as of May 3, 2024 and $1.6 billion as of February 2, 2024.

[0001571996-24-000062:notes:21]
[same as prior period, unchanged from 0001571996-23-000046:notes:19]

[0001571996-24-000062:notes:22]
[same as prior period, unchanged from 0001571996-23-000046:notes:20]

[0001571996-24-000062:notes:23]
[same as prior period, unchanged from 0001571996-23-000046:notes:21]

[0001571996-24-000062:notes:24]
The following table presents the cost, cumulative unrealized gains, cumulative unrealized losses, and carrying value of the Company's strategic investments in marketable and non-marketable equity and other securities as of the dates indicated:

[0001571996-24-000062:notes:25]
|  | May 3, 2024 |  | February 2, 2024 |
|  | Cost |  | Unrealized Gain |  | Unrealized Loss |  | Carrying Value |  | Cost |  | Unrealized Gain |  | Unrealized Loss |  | Carrying Value |
|  | (in millions) |
| Marketable | $ | 17 |  |  | $ | 24 |  |  | $ | (31) |  |  | $ | 10 |  |  | $ | 12 |  |  | $ | 24 |  |  | $ | (26) |  |  | $ | 10 |  |
| Non-marketable | 751 |  |  | 1,016 |  |  | (485) |  |  | 1,282 |  |  | 732 |  |  | 1,015 |  |  | (454) |  |  | 1,293 |  |
| Total equity and other securities | $ | 768 |  |  | $ | 1,040 |  |  | $ | (516) |  |  | $ | 1,292 |  |  | $ | 744 |  |  | $ | 1,039 |  |  | $ | (480) |  |  | $ | 1,303 |  |

[0001571996-24-000062:notes:26]
[same as prior period, unchanged from 0001571996-23-000046:notes:24]

[0001571996-24-000062:notes:27]
[same as prior period, unchanged from 0001571996-23-000046:notes:25]

[0001571996-24-000062:notes:28]
|  | Three Months Ended |
|  | May 3, 2024 |  | May 5, 2023 |
|  | (in millions) |
| Marketable securities: |  |  |  |
| Unrealized loss | $ | (5) |  |  | $ | (23) |  |
| Net unrealized loss | (5) |  |  | (23) |  |
| Non-marketable securities: |  |  |  |
| Unrealized gain | — |  |  | 9 |  |
| Unrealized loss | (30) |  |  | (5) |  |
| Net unrealized gain (loss) (a) (b) | (30) |  |  | 4 |  |
| Net unrealized loss on equity and other securities | $ | (35) |  |  | $ | (19) |  |

[0001571996-24-000062:notes:29]
[same as prior period, unchanged from 0001571996-23-000046:notes:27]

[0001571996-24-000062:notes:30]
(a)    For the three months ended May 3, 2024, net unrealized losses on non-marketable securities were primarily attributable to downward adjustments for observable price changes.

[0001571996-24-000062:notes:31]
(b)    For the three months ended May 5, 2023, net unrealized gains on non-marketable securities were primarily attributable to upward adjustments for observable price changes.

[0001571996-24-000062:notes:32]
[same as prior period, unchanged from 0001571996-23-000046:notes:30]

[0001571996-24-000062:notes:33]
The Company has fixed income debt securities carried at amortized cost which are primarily held as collateral for borrowings.  The Company intends to hold the investments to maturity.  As of May 3, 2024, the Company held $198 million in fixed income debt securities which will mature within one year and $1 million in fixed income debt securities which will mature within five years.

[0001571996-24-000062:notes:34]
[same as prior period, unchanged from 0001571996-23-000046:notes:32]

[0001571996-24-000062:notes:35]
|  | May 3, 2024 |  | February 2, 2024 |
|  | Cost |  | Unrealized Gain |  | Unrealized Loss |  | Carrying Value |  | Cost |  | Unrealized Gain |  | Unrealized Loss |  | Carrying Value |
|  | (in millions) |
| Fixed income debt securities | $ | 215 |  |  | $ | 36 |  |  | $ | (52) |  |  | $ | 199 |  |  | $ | 325 |  |  | $ | 67 |  |  | $ | (91) |  |  | $ | 301 |  |


## dell:CreditLossFinancialInstrumentLeasesDebtVariableInterestEntitiesAndCustomerReceivablesSalesTextBlock

[0001571996-24-000062:notes:36]
FINANCIAL SERVICES
The Company offers or arranges various financing options and alternative payment structures for its customers globally.  Alternative payment structures consist of various flexible consumption models, including utility, subscription, and as-a-Service models.

[0001571996-24-000062:notes:37]
Financing options are offered to the Company’s customers primarily through Dell Financial Services and its affiliates (“DFS”).  The Company also arranges financing for some of its customers in various countries where DFS does not currently operate as a captive enterprise.  The key activities of DFS include originating, collecting, and servicing customer financing arrangements primarily related to the purchase or use of Dell Technologies products and services.  In some cases, DFS also offers financing for the purchase of third-party technology products that complement the Dell Technologies portfolio of products and services.  New financing originations were $1.9 billion and $1.8 billion for the three months ended May 3, 2024 and May 5, 2023, respectively.

[0001571996-24-000062:notes:38]
The Company’s lease and loan arrangements with customers are aggregated primarily into the following categories:

[0001571996-24-000062:notes:39]
Fixed-term leases and loans — The Company enters into financing arrangements with customers who seek lease financing for equipment.  DFS leases are generally classified as sales-type leases or operating leases.  Leases with business customers have fixed terms of generally two to four years.

[0001571996-24-000062:notes:40]
The Company also offers fixed-term loans to qualified small businesses, large commercial accounts, governmental organizations, educational entities, and certain individual consumer customers.  These loans are repaid in equal payments including interest and have defined terms of generally three to five years.  The fair value of the fixed-term loan portfolio is determined using market observable inputs.  The carrying value of these loans approximates fair value.

[0001571996-24-000062:notes:41]
Revolving loans — Revolving loans provide qualified customers with a revolving credit line for the purchase of products and services offered by Dell Technologies.  The Company primarily offers revolving loans to small and medium-sized commercial customers.  Revolving loans in the United States bear interest at a variable annual percentage rate that is tied to the prime rate.  Based on historical payment patterns, revolving loan transactions are typically repaid within twelve months on average.  Due to the short-term nature of the revolving loan portfolio, the carrying value of the portfolio approximates fair value.

[0001571996-24-000062:notes:42]
Flexible consumption models, as defined above, further enable the Company to offer its customers the option to pay over time to provide them with financial and operational flexibility.  Such models may result in identification of embedded lease arrangements that lead to the recognition of operating or sales-type leases.

[0001571996-24-000062:notes:43]
Financing Receivables

[0001571996-24-000062:notes:44]
The following table presents the components of the Company’s financing receivables segregated by portfolio segment as of the dates indicated:

[0001571996-24-000062:notes:45]
|  | May 3, 2024 |  | February 2, 2024 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Financing receivables, net: |  |  |  |  |  |  |  |  |  |  |  |
| Customer receivables, gross (a) | $ | 163 |  |  | $ | 10,470 |  |  | $ | 10,633 |  |  | $ | 173 |  |  | $ | 10,360 |  |  | $ | 10,533 |  |
| Allowances for losses | (8) |  |  | (187) |  |  | (195) |  |  | (9) |  |  | (161) |  |  | (170) |  |
| Customer receivables, net | 155 |  |  | 10,283 |  |  | 10,438 |  |  | 164 |  |  | 10,199 |  |  | 10,363 |  |
| Residual interest | — |  |  | 163 |  |  | 163 |  |  | — |  |  | 157 |  |  | 157 |  |
| Financing receivables, net | $ | 155 |  |  | $ | 10,446 |  |  | $ | 10,601 |  |  | $ | 164 |  |  | $ | 10,356 |  |  | $ | 10,520 |  |
| Short-term | $ | 155 |  |  | $ | 4,505 |  |  | $ | 4,660 |  |  | $ | 164 |  |  | $ | 4,479 |  |  | $ | 4,643 |  |
| Long-term | $ | — |  |  | $ | 5,941 |  |  | $ | 5,941 |  |  | $ | — |  |  | $ | 5,877 |  |  | $ | 5,877 |  |

[0001571996-24-000062:notes:46]
(a)    Customer receivables, gross include amounts due from customers under revolving loans, fixed-term loans, fixed-term leases, and accrued interest.

[0001571996-24-000062:notes:47]
The following table presents the changes in allowance for financing receivables losses for the periods indicated:

[0001571996-24-000062:notes:48]
|  | Three Months Ended |
|  | May 3, 2024 |  | May 5, 2023 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |  |  |  |  |  |  |  |
| Balances at beginning of period | $ | 9 |  |  | $ | 161 |  |  | $ | 170 |  |  | $ | 88 |  |  | $ | 113 |  |  | $ | 201 |  |
| Charge-offs, net of recoveries | (2) |  |  | (6) |  |  | (8) |  |  | (17) |  |  | (1) |  |  | (18) |  |
| Provision charged to income statement | 1 |  |  | 32 |  |  | 33 |  |  | 13 |  |  | 23 |  |  | 36 |  |
| Balances at end of period | $ | 8 |  |  | $ | 187 |  |  | $ | 195 |  |  | $ | 84 |  |  | $ | 135 |  |  | $ | 219 |  |

[0001571996-24-000062:notes:49]
The Company recognizes an allowance for financing receivables losses, including both the lease receivable and unguaranteed residual, in an amount equal to the expected losses net of recoveries.  The allowance for financing receivables losses on the lease receivable is determined based on various factors, including lifetime expected losses determined using macroeconomic forecast assumptions and management judgments applicable to and through the expected life of the portfolios as well as past due receivables, receivable type, and customer risk profile.  The Company continues to monitor broader economic indicators and their potential impact on future credit loss performance.

[0001571996-24-000062:notes:50]
Aging

[0001571996-24-000062:notes:51]
The following table presents the aging of the Company’s customer financing receivables, gross, including accrued interest, segregated by class, as of the dates indicated:

[0001571996-24-000062:notes:52]
|  | May 3, 2024 |  | February 2, 2024 |
|  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |
|  | (in millions) |
| Revolving | $ | 142 |  |  | $ | 17 |  |  | $ | 4 |  |  | $ | 163 |  |  | $ | 151 |  |  | $ | 17 |  |  | $ | 5 |  |  | $ | 173 |  |
| Fixed-term — Consumer and Commercial | 9,477 |  |  | 891 |  |  | 102 |  |  | 10,470 |  |  | 9,345 |  |  | 889 |  |  | 126 |  |  | 10,360 |  |
| Total customer receivables, gross | $ | 9,619 |  |  | $ | 908 |  |  | $ | 106 |  |  | $ | 10,633 |  |  | $ | 9,496 |  |  | $ | 906 |  |  | $ | 131 |  |  | $ | 10,533 |  |

[0001571996-24-000062:notes:53]
Aging is likely to fluctuate as a result of the variability in volume of large transactions entered into over the period, and the administrative processes that accompany those transactions.  Aging is also impacted by the timing of the Company’s fiscal period end date relative to calendar month-end customer payment due dates.  As a result of these factors, fluctuations in aging from period to period do not necessarily indicate a material change in the collectibility of the portfolio.

[0001571996-24-000062:notes:54]
Fixed-term consumer and commercial customer receivables are placed on non-accrual status if principal or interest is past due and considered delinquent, or if there is concern about the collectibility of a specific customer receivable.  The receivables identified as doubtful for collectibility may be classified as current for aging purposes.  Aged revolving portfolio customer receivables identified as delinquent are charged off.

[0001571996-24-000062:notes:55]
Credit Quality

[0001571996-24-000062:notes:56]
The following tables present customer receivables, gross, including accrued interest, by credit quality indicator, segregated by class, as of the dates indicated:

[0001571996-24-000062:notes:57]
|  | May 3, 2024 |
|  | Fixed-term — Consumer and Commercial |  |  |  |  |
|  | Fiscal Year of Origination |  |  |  |  |
|  | 2025 |  | 2024 |  | 2023 |  | 2022 |  | 2021 |  | Years Prior |  | Revolving |  | Total |
|  | (in millions) |
| Higher | $ | 687 |  |  | $ | 2,827 |  |  | $ | 1,699 |  |  | $ | 683 |  |  | $ | 274 |  |  | $ | 46 |  |  | $ | 39 |  |  | $ | 6,255 |  |
| Mid | 237 |  |  | 1,030 |  |  | 783 |  |  | 202 |  |  | 55 |  |  | 13 |  |  | 49 |  |  | 2,369 |  |
| Lower | 764 |  |  | 578 |  |  | 374 |  |  | 143 |  |  | 61 |  |  | 14 |  |  | 75 |  |  | 2,009 |  |
| Total | $ | 1,688 |  |  | $ | 4,435 |  |  | $ | 2,856 |  |  | $ | 1,028 |  |  | $ | 390 |  |  | $ | 73 |  |  | $ | 163 |  |  | $ | 10,633 |  |

[0001571996-24-000062:notes:58]
|  | February 2, 2024 |
|  | Fixed-term — Consumer and Commercial |  |  |  |  |  |  |
|  | Fiscal Year of Origination |  |  |  |  |  |  |
|  | 2024 |  | 2023 |  | 2022 |  | 2021 |  | 2020 |  | Years Prior |  |  |  | Revolving |  | Total |
|  | (in millions) |
| Higher | $ | 3,261 |  |  | $ | 1,979 |  |  | $ | 833 |  |  | $ | 345 |  |  | $ | 64 |  |  | $ | — |  |  |  |  | $ | 47 |  |  | $ | 6,529 |  |
| Mid | 1,111 |  |  | 911 |  |  | 290 |  |  | 86 |  |  | 19 |  |  | — |  |  |  |  | 50 |  |  | 2,467 |  |
| Lower | 703 |  |  | 469 |  |  | 187 |  |  | 80 |  |  | 21 |  |  | 1 |  |  |  |  | 76 |  |  | 1,537 |  |
| Total | $ | 5,075 |  |  | $ | 3,359 |  |  | $ | 1,310 |  |  | $ | 511 |  |  | $ | 104 |  |  | $ | 1 |  |  |  |  | $ | 173 |  |  | $ | 10,533 |  |

[0001571996-24-000062:notes:59]
The categories shown in the tables above segregate customer receivables based on the relative degrees of credit risk.  Credit quality indicators for revolving and fixed-term accounts are generally updated on a periodic basis.

[0001571996-24-000062:notes:60]
For the revolving receivables and fixed-term commercial receivables shown in the tables above, an internal grading system is utilized that assigns a credit level score based on a number of considerations, including liquidity, operating performance, and industry outlook.  The grading criteria and classifications for the fixed-term products differ from those for the revolving products as loss experience varies between these product and customer groups.  The credit quality categories cannot be compared between the different classes as loss experience varies substantially between the classes.

[0001571996-24-000062:notes:61]
Leases

[0001571996-24-000062:notes:62]
The following table presents amounts included in the Condensed Consolidated Statements of Income related to sales-type lease activity for the periods indicated:

[0001571996-24-000062:notes:63]
|  |  |  | Three Months Ended |
|  |  |  |  |  | May 3, 2024 |  | May 5, 2023 |  |  |
|  |  |  |  |  | (in millions) |
| Net revenue — products |  |  |  |  | $ | 728 |  |  | $ | 247 |  |  |  |
| Cost of net revenue — products |  |  |  |  | 618 |  |  | 196 |  |  |  |
| Gross margin — products |  |  |  |  | $ | 110 |  |  | $ | 51 |  |  |  |

[0001571996-24-000062:notes:64]
The following table presents the future maturity of the Company’s fixed-term customer leases and associated financing payments, and reconciles the undiscounted cash flows to the customer receivables, gross recognized on the Condensed Consolidated Statements of Financial Position as of the date indicated:

[0001571996-24-000062:notes:65]
|  | May 3, 2024 |
|  | (in millions) |
| Fiscal 2025 (remaining nine months) | $ | 2,109 |  |
| Fiscal 2026 | 2,416 |  |
| Fiscal 2027 | 1,529 |  |
| Fiscal 2028 | 522 |  |
| Fiscal 2029 and beyond | 226 |  |
| Total undiscounted cash flows | 6,802 |  |
| Fixed-term loans | 4,740 |  |
| Revolving loans | 163 |  |
| Less: Unearned income | (1,072) |  |
| Total customer receivables, gross | $ | 10,633 |  |

[0001571996-24-000062:notes:66]
Operating Leases

[0001571996-24-000062:notes:67]
The Company’s operating leases primarily consist of DFS captive fixed-term leases and contractually committed embedded leases identified within flexible consumption arrangements.

[0001571996-24-000062:notes:68]
The following table presents the components of the Company’s operating lease portfolio included in property, plant, and equipment, net as of the dates indicated:

[0001571996-24-000062:notes:69]
|  | May 3, 2024 |  | February 2, 2024 |
|  | (in millions) |
| Equipment under operating lease, gross | $ | 3,951 |  |  | $ | 4,002 |  |
| Less: Accumulated depreciation | (1,827) |  |  | (1,800) |  |
| Equipment under operating lease, net | $ | 2,124 |  |  | $ | 2,202 |  |

[0001571996-24-000062:notes:70]
The following table presents operating lease income related to lease payments and depreciation expense for the Company’s operating lease portfolio for the periods indicated:

[0001571996-24-000062:notes:71]
|  |  |  | Three Months Ended |
|  |  |  |  |  | May 3, 2024 |  | May 5, 2023 |  |  |
|  |  |  |  |  | (in millions) |
| Income related to lease payments |  |  |  |  | $ | 356 |  |  | $ | 321 |  |  |  |
| Depreciation expense |  |  |  |  | $ | 240 |  |  | $ | 233 |  |  |  |

[0001571996-24-000062:notes:72]
The following table presents the future payments to be received by the Company in operating lease contracts as of the date indicated:

[0001571996-24-000062:notes:73]
|  | May 3, 2024 |
|  | (in millions) |
| Fiscal 2025 (remaining nine months) | $ | 852 |  |
| Fiscal 2026 | 819 |  |
| Fiscal 2027 | 443 |  |
| Fiscal 2028 | 169 |  |
| Fiscal 2029 and beyond | 60 |  |
| Total | $ | 2,343 |  |

[0001571996-24-000062:notes:74]
DFS Debt

[0001571996-24-000062:notes:75]
The Company maintains programs that facilitate the funding of leases, loans, and other alternative payment structures in the capital markets.  The majority of DFS debt is non-recourse to Dell Technologies and represents borrowings under securitization programs and structured financing programs, for which the Company’s risk of loss is limited to transferred loan and lease payments and associated equipment.

[0001571996-24-000062:notes:76]
The following table presents DFS debt as of the dates indicated and excludes the allocated portion of the Company’s other borrowings, which represents the additional amount considered to fund the DFS business:

[0001571996-24-000062:notes:77]
|  | May 3, 2024 |  | February 2, 2024 |
| DFS debt | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing facility | $ | 2,331 |  |  | $ | 2,730 |  |
| Fixed-term securitization offerings | 3,305 |  |  | 3,157 |  |
| Other | 26 |  |  | 28 |  |
| Total DFS U.S. debt, principal amount | 5,662 |  |  | 5,915 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 720 |  |  | 761 |  |
| Other borrowings | 797 |  |  | 935 |  |
| Note payable | 250 |  |  | 250 |  |
| Dell Bank senior unsecured eurobonds | 1,609 |  |  | 1,631 |  |
| Total DFS international debt, principal amount | 3,376 |  |  | 3,577 |  |
| Total DFS debt, principal amount | $ | 9,038 |  |  | $ | 9,492 |  |
| Total short-term DFS debt | $ | 5,038 |  |  | $ | 5,863 |  |
| Total long-term DFS debt | $ | 4,000 |  |  | $ | 3,629 |  |

[0001571996-24-000062:notes:78]
DFS U.S. Debt

[0001571996-24-000062:notes:79]
Asset-Based Financing Facility — During the three months ended May 3, 2024, the Company consolidated its two separate asset-based financing facilities into a single asset-based financing facility in the United States, which is a revolving facility for fixed-term leases and loans.  This debt is collateralized solely by the U.S. loan and lease payments and associated equipment in the facility.   The asset-based financing facility consists of two tranches, with effective dates through July 7, 2025 and July 7, 2026.  As of May 3, 2024, the total debt capacity related to the asset-based financing facility was $5.0 billion.  The debt has a variable interest rate, and the duration of the debt is based on the terms of the underlying loan and lease payment streams.  The Company enters into interest swap agreements to effectively convert a portion of this debt from a floating rate to a fixed rate.  See Note 7 of the Notes to the Condensed Consolidated Financial Statements for additional information about the Company’s interest rate swaps.

[0001571996-24-000062:notes:80]
The asset-based financing facility contains standard structural features related to the performance of the funded receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the facility, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of May 3, 2024, these criteria were met.

[0001571996-24-000062:notes:81]
Fixed-Term Securitization Offerings — The Company periodically issues asset-backed debt securities under fixed-term securitization programs to private investors.  The asset-backed debt securities are collateralized solely by the U.S. fixed-term lease and loan payments and associated equipment, which are held by Special Purpose Entities (“SPEs”), as discussed below.  The interest rate on these securities is fixed and ranged from 2.49% to 6.80% per annum as of May 3, 2024, and the duration of these securities is based on the terms of the underlying lease and loan payment streams.

[0001571996-24-000062:notes:82]
DFS International Debt

[0001571996-24-000062:notes:83]
Securitization Facility — The Company maintains a securitization facility in Europe for fixed-term leases and loans.  The debt under this facility has a variable interest rate, and the duration of the debt is based on the terms of the underlying loan and lease payment streams.  This facility is effective through December 23, 2024 and had a total debt capacity of $858 million as of May 3, 2024.

[0001571996-24-000062:notes:84]
The securitization facility contains standard structural features related to the performance of the securitized receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the program, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of May 3, 2024, these criteria were met.

[0001571996-24-000062:notes:85]
Other Borrowings — In connection with the Company’s international financing operations, the Company has entered into revolving structured financing debt programs related to its fixed-term lease and loan products sold in Canada, Europe, Australia, New Zealand, and the Middle East.  The debt under these programs has a variable interest rate, and the duration of the debt is based on the terms of the underlying loan and lease payment streams.  The Canadian facility, which is collateralized solely by Canadian loan and lease payments and associated equipment, had a total debt capacity of $329 million as of May 3, 2024 and is effective through January 16, 2025.  The European facility, which is collateralized solely by European loan and lease payments and associated equipment, had a total debt capacity of $536 million as of May 3, 2024 and is effective through June 14, 2025.  The Australia and New Zealand facility, which is collateralized solely by Australia and New Zealand loan and lease payments and associated equipment, had a total debt capacity of $295 million as of May 3, 2024 and is effective through April 20, 2025.  The Middle East facility, which is collateralized solely by Middle East loan and lease payments and associated equipment, had a total debt capacity of $150 million as of May 3, 2024 and is effective through March 24, 2025.

[0001571996-24-000062:notes:86]
Note Payable — On May 25, 2022, the Company entered into an unsecured credit agreement to fund receivables in Mexico.  As of May 3, 2024, the aggregate principal amount of the note payable was $250 million.  The note bore interest at an annual rate of 4.24% and matured and was paid in full on May 31, 2024.

[0001571996-24-000062:notes:87]
Dell Bank Senior Unsecured Eurobonds — On June 24, 2020, Dell Bank issued 500 million Euro of 1.625% senior unsecured four year eurobonds due June 2024.  On October 27, 2021, Dell Bank issued 500 million Euro of 0.5% senior unsecured five year eurobonds due October 2026.  On October 18, 2022, Dell Bank issued 500 million Euro of 4.5% senior unsecured five year eurobonds due October 2027.  The issuances of the senior unsecured eurobonds support the expansion of the financing operations in Europe.

[0001571996-24-000062:notes:88]
Variable Interest Entities

[0001571996-24-000062:notes:89]
In connection with the asset-based financing facility, securitization facility, and fixed-term securitization offerings discussed above, the Company transfers certain U.S. and European lease and loan payments and associated equipment to SPEs that meet the definition of a VIE and are consolidated, along with the associated debt described above, into the Condensed Consolidated Financial Statements, as the Company is the primary beneficiary of the VIEs.  The SPEs are bankruptcy-remote legal entities with separate assets and liabilities.  The purpose of the SPEs is to facilitate the funding of customer loan and lease payments and associated equipment in the capital markets.

[0001571996-24-000062:notes:90]
Some of the SPEs have entered into financing arrangements with multi-seller conduits that, in turn, issue asset-backed debt securities in the capital markets.  DFS debt outstanding held by the consolidated VIEs is collateralized by the lease and loan payments and associated equipment.  The Company’s risk of loss related to securitized receivables is limited to the amount by which the Company’s right to receive collections for assets securitized exceeds the amount required to pay interest, principal, and fees and expenses related to the asset-backed securities.  The Company provides credit enhancement to the securitization in the form of over-collateralization.

[0001571996-24-000062:notes:91]
The following table presents the assets and liabilities held by the consolidated VIEs as of the dates indicated, which are included in the Condensed Consolidated Statements of Financial Position:

[0001571996-24-000062:notes:92]
|  | May 3, 2024 |  | February 2, 2024 |
|  | (in millions) |
| Assets held by consolidated VIEs |  |  |  |
| Other current assets | $ | 124 |  |  | $ | 136 |  |
| Financing receivables, net of allowance |  |  |  |
| Short-term | $ | 3,140 |  |  | $ | 3,314 |  |
| Long-term | $ | 2,752 |  |  | $ | 2,747 |  |
| Property, plant, and equipment, net | $ | 1,031 |  |  | $ | 1,081 |  |
| Liabilities held by consolidated VIEs |  |  |  |
| Debt, net of unamortized debt issuance costs |  |  |  |
| Short-term | $ | 3,553 |  |  | $ | 4,450 |  |
| Long-term | $ | 2,804 |  |  | $ | 2,184 |  |

[0001571996-24-000062:notes:93]
Lease and loan payments and associated equipment transferred via securitization through SPEs were $0.8 billion and $1.5 billion for the three months ended May 3, 2024 and May 5, 2023, respectively.

[0001571996-24-000062:notes:94]
Customer Receivables Sales

[0001571996-24-000062:notes:95]
To manage certain concentrations of customer credit exposure, the Company may sell selected fixed-term customer receivables to unrelated third parties on a periodic basis, without recourse.  The amount of customer receivables sold for this purpose was $67 million and $169 million for the three months ended May 3, 2024 and May 5, 2023, respectively.  The Company’s continuing involvement in these customer receivables is primarily limited to servicing arrangements.


## us-gaap:ScheduleOfDebtTableTextBlock

[0001571996-24-000062:notes:96]
The following table summarizes the Company’s outstanding debt as of the dates indicated:

[0001571996-24-000062:notes:97]
|  | May 3, 2024 |  | February 2, 2024 |
|  | (in millions) |
| Senior Notes | $ | 15,607 |  |  | $ | 15,607 |  |
| Legacy Notes | 952 |  |  | 952 |  |
| DFS Debt (Note 4) | 9,038 |  |  | 9,492 |  |
| Other | 108 |  |  | 171 |  |
| Total debt, principal amount | 25,705 |  |  | 26,222 |  |
| Unamortized discount, net of unamortized premium | (111) |  |  | (114) |  |
| Debt issuance costs | (114) |  |  | (114) |  |
| Total debt, carrying value | $ | 25,480 |  |  | $ | 25,994 |  |
| Total short-term debt, carrying value | $ | 6,098 |  |  | $ | 6,982 |  |
| Total long-term debt, carrying value | $ | 19,382 |  |  | $ | 19,012 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0001571996-24-000062:notes:98]
LEASES 
The Company enters into leasing transactions in which the Company is the lessee.  These lease contracts are typically classified as operating leases.  The Company’s lease contracts are generally for office buildings used to conduct its business, and the determination of whether such contracts contain leases generally does not require significant estimates or judgments.  The Company also leases certain global logistics warehouses, employee vehicles, and equipment.  As of May 3, 2024, the remaining terms of the Company’s leases range from one month to approximately ten years.  As of May 3, 2024 and February 2, 2024, there were no material finance leases in which the Company was a lessee.

[0001571996-24-000062:notes:99]
[same as prior period, unchanged from 0001571996-23-000046:notes:102]

[0001571996-24-000062:notes:100]
[same as prior period, unchanged from 0001571996-23-000046:notes:103]

[0001571996-24-000062:notes:101]
|  |  |  | Three Months Ended |
|  |  |  |  |  | May 3, 2024 |  | May 5, 2023 |
|  |  |  |  |  | (in millions) |
| Operating lease costs |  |  |  |  | $ | 71 |  |  | $ | 79 |  |
| Variable costs |  |  |  |  | 18 |  |  | 24 |  |
| Total lease costs |  |  |  |  | $ | 89 |  |  | $ | 103 |  |

[0001571996-24-000062:notes:102]
During the three months ended May 3, 2024 and May 5, 2023, sublease income, finance lease costs, and short-term lease costs were immaterial.

[0001571996-24-000062:notes:103]
[same as prior period, unchanged from 0001571996-23-000046:notes:106]

[0001571996-24-000062:notes:104]
|  | Classification |  | May 3, 2024 |  | February 2, 2024 |  |  |
|  |  |  | (in millions, except for term and discount rate) |
| Operating lease right-of-use assets | Other non-current assets |  | $ | 643 |  | $ | 707 |  |  |
| Current operating lease liabilities | Accrued and other current liabilities |  | $ | 242 |  | $ | 253 |  |  |
| Non-current operating lease liabilities | Other non-current liabilities |  | 520 |  | 576 |  |  |
| Total operating lease liabilities |  |  | $ | 762 |  | $ | 829 |  |  |
| Weighted-average remaining lease term (in years) |  |  | 4.34 |  | 4.56 |  |  |
| Weighted-average discount rate |  |  | 4.93 | % |  | 4.79 | % |  |  |

[0001571996-24-000062:notes:105]
[same as prior period, unchanged from 0001571996-23-000046:notes:108]

[0001571996-24-000062:notes:106]
|  | Three Months Ended |
|  | May 3, 2024 |  | May 5, 2023 |
|  | (in millions) |
| Cash paid for amounts included in the measurement of lease liabilities — operating cash outflows from operating leases | $ | 69 |  |  | $ | 77 |  |
| Right-of-use assets obtained in exchange for new operating lease liabilities | $ | 10 |  |  | $ | 81 |  |

[0001571996-24-000062:notes:107]
[same as prior period, unchanged from 0001571996-23-000046:notes:110]

[0001571996-24-000062:notes:108]
|  | May 3, 2024 |
|  | (in millions) |
| Fiscal 2025 (remaining nine months) | $ | 187 |  |
| Fiscal 2026 | 205 |  |
| Fiscal 2027 | 167 |  |
| Fiscal 2028 | 121 |  |
| Fiscal 2029 | 73 |  |
| Thereafter | 84 |  |
| Total lease payments | 837 |  |
| Less: Imputed interest | 75 |  |
| Total | $ | 762 |  |
| Current operating lease liabilities | $ | 242 |  |
| Non-current operating lease liabilities | $ | 520 |  |

[0001571996-24-000062:notes:109]
As of May 3, 2024, the Company’s undiscounted operating leases that had not yet commenced were immaterial.


## us-gaap:DebtDisclosureTextBlock

[0001571996-24-000062:notes:110]
DEBT
The following table summarizes the Company’s outstanding debt as of the dates indicated:

[0001571996-24-000062:notes:111]
During the three months ended May 3, 2024, the Company issued $1.0 billion aggregate principal amount of 5.40% Senior Notes due 2034.  The Company used the net proceeds of the issuance to prepay a portion of the outstanding 6.02% Senior Notes due 2026.

[0001571996-24-000062:notes:112]
Outstanding Debt

[0001571996-24-000062:notes:113]
Senior Notes — The Company completed offerings of multiple series of senior notes which were issued on June 1, 2016, June 22, 2016, March 20, 2019, April 9, 2020, December 13, 2021, January 24, 2023 and March 18, 2024 in aggregate principal amounts of $20.0 billion, $3.3 billion, $4.5 billion, $2.3 billion, $2.3 billion, $2.0 billion and $1.0 billion, respectively (the “Senior Notes”).  The Senior Notes maturities range from 2024 through 2051.  Interest rates on these borrowings are fixed, ranging from 3.38% to 8.35%, and interest is payable semiannually.

[0001571996-24-000062:notes:114]
Legacy Notes — The Company has outstanding unsecured notes and debentures (collectively, the “Legacy Notes”) that were issued by Dell Inc. (“Dell”), a wholly-owned subsidiary of Dell Technologies Inc., prior to the acquisition of Dell by Dell Technologies Inc. in the going-private transaction that closed in October 2013.  The Legacy Notes’ maturities range from 2028 through 2040.  Interest rates on these borrowings are fixed, ranging from 5.40% to 7.10%, and interest is payable semiannually.

[0001571996-24-000062:notes:115]
DFS Debt — See Note 4 and Note 7 of the Notes to the Condensed Consolidated Financial Statements, respectively, for discussion of DFS debt and the interest rate swap agreements that hedge a portion of that debt.

[0001571996-24-000062:notes:116]
Revolving Credit Facility — The Company’s revolving credit facility provides the Company with revolving commitments in an aggregate principal amount of $6.0 billion for general corporate purposes and includes a letter of credit sub-facility of up to $0.5 billion and a swing-line loan sub-facility of up to $0.5 billion.  The revolving credit facility also allows the Company to obtain incremental additional commitments on one or more occasions in minimum amounts of $10 million.

[0001571996-24-000062:notes:117]
Borrowings under the revolving credit facility bear interest at a rate per annum equal to an applicable margin plus, at the borrowers’ option, either (a) the specified adjusted term Secured Overnight Financing Rate (“SOFR”) or (b) a base rate.  The margin applicable to SOFR and base rate borrowings varies based upon the Company’s existing credit ratings.  The base rate is calculated based upon the greatest of the specified prime rate, the specified federal reserve bank rate, or SOFR plus 1%.  The borrowers may voluntarily repay outstanding loans at any time without premium or penalty, other than customary breakage costs.  The facility matures on November 1, 2027.

[0001571996-24-000062:notes:118]
As of May 3, 2024, the Company had no outstanding borrowings under the revolving credit facility.

[0001571996-24-000062:notes:119]
Commercial Paper Program — The Company maintains a commercial paper program under which the Company may issue unsecured notes in a maximum aggregate face amount of $5.0 billion outstanding at any time, with maturities up to 397 days from the date of issuance.  The notes are sold on customary terms in the U.S. commercial paper market on a private placement basis.  The proceeds of the notes are used for general corporate purposes.  As of May 3, 2024, the Company had no outstanding issuances under the commercial paper program.

[0001571996-24-000062:notes:120]
The Company may purchase, redeem, prepay, refinance, or otherwise retire any amount of outstanding indebtedness under the terms of such indebtedness at any time and from time to time, in open market or negotiated transactions with the holders of such indebtedness or otherwise, as considered appropriate in light of market conditions and other relevant factors.

[0001571996-24-000062:notes:121]
Covenants — The credit agreement governing the revolving credit facility and the indentures governing the Senior Notes and the Legacy Notes impose various limitations, subject to exceptions, on creating certain liens and entering into sale and lease-back transactions.  The foregoing credit agreement and indentures contain customary events of default, and the revolving credit facility is subject to an interest coverage ratio covenant that is tested at the end of each fiscal quarter with respect to the Company’s preceding four fiscal quarters.  The Company was in compliance with this financial covenant as of May 3, 2024.

[0001571996-24-000062:notes:122]
Aggregate Future Maturities

[0001571996-24-000062:notes:123]
The following table presents the aggregate future maturities of the Company’s debt as of May 3, 2024, excluding associated carrying value adjustments, for the periods indicated:

[0001571996-24-000062:notes:124]
|  | May 3, 2024 |
|  | (in millions) |
| Fiscal 2025 (remaining nine months) | $ | 5,248 |  |
| Fiscal 2026 | 3,867 |  |
| Fiscal 2027 | 5,560 |  |
| Fiscal 2028 | 1,194 |  |
| Fiscal 2029 | 1,327 |  |
| Thereafter | 8,509 |  |
| Total maturities, principal amount | $ | 25,705 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001571996-24-000062:notes:125]
[same as prior period, unchanged from 0001571996-23-000046:notes:130]

[0001571996-24-000062:notes:126]
The Company’s objective is to offset gains and losses resulting from these exposures with gains and losses on the derivative contracts used to hedge the exposures, thereby reducing volatility of earnings and protecting the fair values of assets and liabilities.  The earnings effects of the derivative instruments are presented in the same line items on the Condensed Consolidated Statements of Income as the earnings effects of the hedged items.  For derivatives designated as cash flow hedges, the Company assesses hedge effectiveness both at the onset of the hedge and at regular intervals throughout the life of the instruments.  For derivatives designated as fair value hedges, the Company assesses hedge effectiveness on qualifying instruments using the shortcut method whereby the hedges are considered perfectly effective at the onset of the hedge and over the life of the hedging relationship.

[0001571996-24-000062:notes:127]
[same as prior period, unchanged from 0001571996-23-000046:notes:132]

[0001571996-24-000062:notes:128]
[same as prior period, unchanged from 0001571996-23-000046:notes:133]

[0001571996-24-000062:notes:129]
During the three months ended May 3, 2024 and May 5, 2023, the Company did not discontinue any cash flow hedges related to foreign exchange contracts that had a material impact on the Company’s results of operations due to the probability that the forecasted cash flows would not occur.

[0001571996-24-000062:notes:130]
[same as prior period, unchanged from 0001571996-23-000046:notes:135]

[0001571996-24-000062:notes:131]
[same as prior period, unchanged from 0001571996-23-000046:notes:136]

[0001571996-24-000062:notes:132]
[same as prior period, unchanged from 0001571996-23-000046:notes:137]

[0001571996-24-000062:notes:133]
[same as prior period, unchanged from 0001571996-23-000046:notes:138]

[0001571996-24-000062:notes:134]
[same as prior period, unchanged from 0001571996-23-000046:notes:139]

[0001571996-24-000062:notes:135]
[same as prior period, unchanged from 0001571996-23-000046:notes:140]

[0001571996-24-000062:notes:136]
[same as prior period, unchanged from 0001571996-23-000046:notes:142]

[0001571996-24-000062:notes:137]
[same as prior period, unchanged from 0001571996-23-000046:notes:143]

[0001571996-24-000062:notes:138]
|  | May 3, 2024 |  | February 2, 2024 |
|  | (in millions) |
| Foreign exchange contracts: |  |  |  |
| Designated as cash flow hedging instruments | $ | 7,454 |  |  | $ | 6,339 |  |
| Non-designated as hedging instruments | 5,830 |  |  | 5,844 |  |
| Total | $ | 13,284 |  |  | $ | 12,183 |  |
| Interest rate contracts: |  |  |  |
| Non-designated as hedging instruments | $ | 6,074 |  |  | $ | 6,551 |  |

[0001571996-24-000062:notes:139]
[same as prior period, unchanged from 0001571996-23-000046:notes:145]

[0001571996-24-000062:notes:140]
| Derivatives in Cash Flow Hedging Relationships |  | Gain Recognized in Accumulated OCI, Net of Tax, on Derivatives |  | Location of Gain (Loss) Reclassified from Accumulated OCI into Income |  | Gain (Loss) Reclassified from Accumulated OCI into Income |
|  |  | (in millions) |  |  |  | (in millions) |
| For the three months ended May 3, 2024: |
|  |  |  |  | Total net revenue |  | $ | 18 |  |
| Foreign exchange contracts |  | $ | 87 |  |  | Total cost of net revenue |  | 1 |  |
| Total |  | $ | 87 |  |  | Total |  | $ | 19 |  |
| For the three months ended May 5, 2023: |
|  |  |  |  | Total net revenue |  | $ | (88) |  |
| Foreign exchange contracts |  | $ | 10 |  |  | Total cost of net revenue |  | (3) |  |
| Total |  | $ | 10 |  |  | Total |  | $ | (91) |  |

[0001571996-24-000062:notes:141]
[same as prior period, unchanged from 0001571996-23-000046:notes:148]

[0001571996-24-000062:notes:142]
|  | Three Months Ended |  |  |  |  |  |  |  |  |
|  | May 3, 2024 |  | May 5, 2023 |  |  |  |  |  |  |  | Location of Gain (Loss) Recognized |
|  | (in millions) |  |  |
| Foreign exchange contracts | $ | (71) |  |  | $ | 57 |  |  |  |  |  |  |  |  | Interest and other, net |
| Interest rate contracts | 17 |  |  | (21) |  |  |  |  |  |  |  |  | Interest and other, net |
| Total | $ | (54) |  |  | $ | 36 |  |  |  |  |  |  |  |  |  |

[0001571996-24-000062:notes:143]
[same as prior period, unchanged from 0001571996-23-000046:notes:150]

[0001571996-24-000062:notes:144]
|  | May 3, 2024 |
|  | Other Current Assets |  | Other Non-Current Assets |  | Other Current Liabilities |  | Other Non-Current Liabilities |  | Total Fair Value |
|  | (in millions) |
| Derivatives designated as hedging instruments: |
| Foreign exchange contracts in an asset position | $ | 114 |  |  | $ | — |  |  | $ | 13 |  |  | $ | — |  |  | $ | 127 |  |
| Foreign exchange contracts in a liability position | (7) |  |  | — |  |  | (1) |  |  | — |  |  | (8) |  |
| Net asset (liability) | 107 |  |  | — |  |  | 12 |  |  | — |  |  | 119 |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts in an asset position | 156 |  |  | — |  |  | 41 |  |  | — |  |  | 197 |  |
| Foreign exchange contracts in a liability position | (129) |  |  | — |  |  | (63) |  |  | — |  |  | (192) |  |
| Interest rate contracts in an asset position | 2 |  |  | 34 |  |  | — |  |  | — |  |  | 36 |  |
| Interest rate contracts in a liability position | — |  |  | — |  |  | (5) |  |  | (14) |  |  | (19) |  |
| Net asset (liability) | 29 |  |  | 34 |  |  | (27) |  |  | (14) |  |  | 22 |  |
| Total derivatives at fair value | $ | 136 |  |  | $ | 34 |  |  | $ | (15) |  |  | $ | (14) |  |  | $ | 141 |  |
|  | February 2, 2024 |
|  | Other Current Assets |  | Other Non-Current Assets |  | Other Current Liabilities |  | Other Non-Current Liabilities |  | Total Fair Value |
|  | (in millions) |
| Derivatives designated as hedging instruments: |
| Foreign exchange contracts in an asset position | $ | 44 |  |  | $ | — |  |  | $ | 19 |  |  | $ | — |  |  | $ | 63 |  |
| Foreign exchange contracts in a liability position | (5) |  |  | — |  |  | (15) |  |  | — |  |  | (20) |  |
| Net asset (liability) | 39 |  |  | — |  |  | 4 |  |  | — |  |  | 43 |  |
| Derivatives not designated as hedging instruments: |
| Foreign exchange contracts in an asset position | 90 |  |  | — |  |  | 71 |  |  | — |  |  | 161 |  |
| Foreign exchange contracts in a liability position | (68) |  |  | — |  |  | (121) |  |  | — |  |  | (189) |  |
| Interest rate contracts in an asset position | 3 |  |  | 40 |  |  | — |  |  | — |  |  | 43 |  |
| Interest rate contracts in a liability position | — |  |  | — |  |  | (10) |  |  | (28) |  |  | (38) |  |
| Net asset (liability) | 25 |  |  | 40 |  |  | (60) |  |  | (28) |  |  | (23) |  |
| Total derivatives at fair value | $ | 64 |  |  | $ | 40 |  |  | $ | (56) |  |  | $ | (28) |  |  | $ | 20 |  |

[0001571996-24-000062:notes:145]
[same as prior period, unchanged from 0001571996-23-000046:notes:152]

[0001571996-24-000062:notes:146]
|  | May 3, 2024 |
|  | Gross Amounts of Recognized Assets/ (Liabilities) |  | Gross Amounts Offset in the Statement of Financial Position |  | Net Amounts of Assets/(Liabilities) Presented in the Statement of Financial Position |  | Gross Amounts not Offset in the Statement of Financial Position |  | Net Amount of Assets/ (Liabilities) Recognized in the Statement of Financial Position |
|  | Financial Instruments |  | Cash Collateral Received or Pledged |  |
|  | (in millions) |
| Derivative instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Financial assets | $ | 360 |  |  | $ | (190) |  |  | $ | 170 |  |  | $ | — |  |  | $ | (30) |  |  | $ | 140 |  |
| Financial liabilities | (219) |  |  | 190 |  |  | (29) |  |  | — |  |  | 1 |  |  | (28) |  |
| Total derivative instruments | $ | 141 |  |  | $ | — |  |  | $ | 141 |  |  | $ | — |  |  | $ | (29) |  |  | $ | 112 |  |
|  | February 2, 2024 |
|  | Gross Amounts of Recognized Assets/ (Liabilities) |  | Gross Amounts Offset in the Statement of Financial Position |  | Net Amounts of Assets/(Liabilities) Presented in the Statement of Financial Position |  | Gross Amounts not Offset in the Statement of Financial Position |  | Net Amount of Assets/ (Liabilities) Recognized in the Statement of Financial Position |
|  | Financial Instruments |  | Cash Collateral Received or Pledged |  |
|  | (in millions) |
| Derivative instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Financial assets | $ | 267 |  |  | $ | (163) |  |  | $ | 104 |  |  | $ | — |  |  | $ | (24) |  |  | $ | 80 |  |
| Financial liabilities | (247) |  |  | 163 |  |  | (84) |  |  | — |  |  | 9 |  |  | (75) |  |
| Total derivative instruments | $ | 20 |  |  | $ | — |  |  | $ | 20 |  |  | $ | — |  |  | $ | (15) |  |  | $ | 5 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001571996-24-000062:notes:147]
[same as prior period, unchanged from 0001571996-23-000046:notes:154]

[0001571996-24-000062:notes:148]
The Infrastructure Solutions Group and Client Solutions Group reporting units are consistent with the reportable segments identified in Note 16 of the Notes to the Condensed Consolidated Financial Statements.  Other businesses consists of Secureworks, VMware Resale, and Virtustream, each of which represents a separate reporting unit.

[0001571996-24-000062:notes:149]
[same as prior period, unchanged from 0001571996-23-000046:notes:156]

[0001571996-24-000062:notes:150]
|  | Infrastructure Solutions Group |  | Client Solutions Group |  | Other Businesses |  | Total |
|  | (in millions) |
| Balances as of February 2, 2024 | $ | 15,041 |  |  | $ | 4,232 |  |  | $ | 427 |  |  | $ | 19,700 |  |
| Impact of foreign currency translation and other | (60) |  |  | — |  |  | — |  |  | (60) |  |
| Balances as of May 3, 2024 | $ | 14,981 |  |  | $ | 4,232 |  |  | $ | 427 |  |  | $ | 19,640 |  |

[0001571996-24-000062:notes:151]
[same as prior period, unchanged from 0001571996-23-000046:notes:159]

[0001571996-24-000062:notes:152]
[same as prior period, unchanged from 0001571996-23-000046:notes:160]

[0001571996-24-000062:notes:153]
|  | May 3, 2024 |  | February 2, 2024 |
|  | Gross |  | AccumulatedAmortization |  | Net |  | Gross |  | AccumulatedAmortization |  | Net |
|  | (in millions) |
| Customer relationships | $ | 16,968 |  |  | $ | (15,025) |  |  | $ | 1,943 |  |  | $ | 16,968 |  |  | $ | (14,930) |  |  | $ | 2,038 |  |
| Developed technology | 9,506 |  |  | (9,038) |  |  | 468 |  |  | 9,506 |  |  | (8,980) |  |  | 526 |  |
| Trade names | 875 |  |  | (833) |  |  | 42 |  |  | 875 |  |  | (823) |  |  | 52 |  |
| Definite-lived intangible assets | 27,349 |  |  | (24,896) |  |  | 2,453 |  |  | 27,349 |  |  | (24,733) |  |  | 2,616 |  |
| Indefinite-lived trade names | 3,085 |  |  | — |  |  | 3,085 |  |  | 3,085 |  |  | — |  |  | 3,085 |  |
| Total intangible assets | $ | 30,434 |  |  | $ | (24,896) |  |  | $ | 5,538 |  |  | $ | 30,434 |  |  | $ | (24,733) |  |  | $ | 5,701 |  |

[0001571996-24-000062:notes:154]
For both the three months ended May 3, 2024 and May 5, 2023, amortization expense related to definite-lived intangible assets was $0.2 billion. There were no material impairment charges related to intangible assets during the three months ended May 3, 2024 and May 5, 2023.

[0001571996-24-000062:notes:155]
[same as prior period, unchanged from 0001571996-23-000046:notes:163]

[0001571996-24-000062:notes:156]
|  | May 3, 2024 |
|  | (in millions) |
| Fiscal 2025 (remaining nine months) | $ | 490 |  |
| Fiscal 2026 | 495 |  |
| Fiscal 2027 | 386 |  |
| Fiscal 2028 | 230 |  |
| Fiscal 2029 | 190 |  |
| Thereafter | 662 |  |
| Total | $ | 2,453 |  |

[0001571996-24-000062:notes:157]
[same as prior period, unchanged from 0001571996-23-000046:notes:165]

[0001571996-24-000062:notes:158]
[same as prior period, unchanged from 0001571996-23-000046:notes:166]

[0001571996-24-000062:notes:159]
[same as prior period, unchanged from 0001571996-23-000046:notes:167]

[0001571996-24-000062:notes:160]
Management exercised significant judgment related to the above assessments, including the identification of goodwill reporting units, assignment of assets and liabilities to goodwill reporting units, assignment of goodwill to reporting units, and determination of the fair value of each goodwill reporting unit.  For the quantitative goodwill impairment test, the fair value of each goodwill reporting unit is generally estimated using a combination of public company multiples and discounted cash flow methodologies.  The discounted cash flow and public company multiples methodologies require significant judgment, including estimation of future revenues, gross margins, and operating expenses, which are dependent on internal forecasts, current and anticipated economic conditions and trends, selection of market multiples through assessment of the reporting unit’s performance relative to peer competitors, the estimation of the long-term revenue growth rate and discount rate of the Company’s business, and the determination of the Company’s weighted average cost of capital.  Changes in these estimates and assumptions could materially affect the fair value of the goodwill reporting unit, potentially resulting in a non-cash impairment charge.

[0001571996-24-000062:notes:161]
The fair value of the indefinite-lived trade names is generally estimated using discounted cash flow methodologies.  These methodologies require significant judgment, including the estimation of future revenue, the estimation of the long-term revenue growth rate of the Company’s business and the determination of the Company’s weighted average cost of capital and royalty rates.  Changes in these estimates and assumptions could materially affect the fair value of the indefinite-lived intangible assets, potentially resulting in a non-cash impairment charge.

[0001571996-24-000062:notes:162]
Based on the results of the annual impairment test performed during Fiscal 2024, the fair values of each of the reporting units and indefinite-lived intangibles exceeded their carrying values.  No goodwill or indefinite-lived assets impairment test was performed during the three months ended May 3, 2024.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001571996-24-000062:notes:163]
[same as prior period, unchanged from 0001571996-23-000046:notes:171]

[0001571996-24-000062:notes:164]
[same as prior period, unchanged from 0001571996-23-000046:notes:172]

[0001571996-24-000062:notes:165]
|  |  |  | Three Months Ended |
|  |  |  |  |  | May 3, 2024 |  | May 5, 2023 |
|  |  |  |  |  | (in millions) |
| Deferred revenue: |  |  |  |  |  |  |  |
| Deferred revenue at beginning of period |  |  |  |  | $ | 29,145 |  |  | $ | 30,286 |  |
| Revenue deferrals |  |  |  |  | 4,469 |  |  | 4,719 |  |
| Revenue recognized |  |  |  |  | (5,464) |  |  | (5,310) |  |
| Deferred revenue at end of period |  |  |  |  | $ | 28,150 |  |  | $ | 29,695 |  |
| Short-term deferred revenue |  |  |  |  | $ | 15,034 |  |  | $ | 15,527 |  |
| Long-term deferred revenue |  |  |  |  | $ | 13,116 |  |  | $ | 14,168 |  |

[0001571996-24-000062:notes:166]
Remaining Performance Obligations — Remaining performance obligations represent the aggregate amount of the transaction price allocated to performance obligations not delivered, or partially undelivered, as of the end of the reporting period.  Remaining performance obligations include deferred revenue plus unbilled amounts not yet recorded in deferred revenue.  The value of the transaction price allocated to remaining performance obligations as of May 3, 2024 was approximately $39 billion.  The Company expects to recognize approximately 59% of remaining performance obligations as revenue in the next twelve months, and the remainder thereafter.

[0001571996-24-000062:notes:167]
[same as prior period, unchanged from 0001571996-23-000046:notes:176]

[0001571996-24-000062:notes:168]
[same as prior period, unchanged from 0001571996-23-000046:notes:177]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001571996-24-000062:notes:169]
COMMITMENTS AND CONTINGENCIES 
Legal Matters

[0001571996-24-000062:notes:170]
The Company is involved in various claims, suits, assessments, investigations, and legal proceedings that arise from time to time in the ordinary course of its business, including those identified below, consisting of matters involving consumer, antitrust, tax, intellectual property, and other issues on a global basis.

[0001571996-24-000062:notes:171]
The Company accrues a liability when it believes that it is both probable that a liability has been incurred and that it can reasonably estimate the amount of the loss.  The Company reviews these accruals at least quarterly and adjusts them to reflect ongoing negotiations, settlements, rulings, advice of legal counsel, and other relevant information.  To the extent new information is obtained and the Company’s views on the probable outcomes of claims, suits, assessments, investigations, or legal proceedings change, changes in the Company’s accrued liabilities are recorded in the period in which such a determination is made.  For some matters, the incurrence of a liability is not probable or the amount cannot be reasonably estimated and therefore accruals have not been made.

[0001571996-24-000062:notes:172]
The following is a discussion of the Company’s significant legal matters and other proceedings:

[0001571996-24-000062:notes:173]
Class Actions Related to the Class V Transaction — On December 28, 2018, the Company completed a transaction (the “Class V transaction”) in which it paid $14.0 billion in cash and issued 149,387,617 shares of its Class C Common Stock to holders of its Class V Common Stock in exchange for all outstanding shares of Class V Common Stock.  As a result of the Class V transaction, the tracking stock feature of the Company’s capital structure associated with the Class V Common Stock was terminated.  Certain stockholders of the Company, subsequently brought class action complaints arising out of the Class V transaction in which they named as defendants (collectively, the “defendants”) Michael S. Dell and certain other directors serving on the Company’s board of directors at the time of the Class V transaction (collectively, the “director defendants”), certain stockholders of the Company, consisting of Mr. Dell and Silver Lake Group, L.L.C. and certain of its affiliated funds (collectively, the “stockholder defendants”), and Goldman Sachs & Co. LLC (“Goldman Sachs”), which served as financial advisor to the Company in connection with the transaction.  The plaintiffs generally alleged that the director defendants and the stockholder defendants breached their fiduciary duties under Delaware law to the former holders of the Class V Common Stock in connection with the Class V transaction by offering a transaction value that was allegedly billions of dollars below fair value.

[0001571996-24-000062:notes:174]
As previously reported, during the fourth quarter of the fiscal year ended February 3, 2023, the plaintiffs and the defendants entered into an agreement to settle the lawsuit.  Under the terms of the settlement, the plaintiffs agreed to the dismissal of all claims upon payment of a total of $1.0 billion (the “settlement amount”), which includes all costs, expenses and fees of the plaintiff class relating to the action and its resolution.  On May 16, 2023, during the fiscal year ended February 2, 2024, the Company paid the settlement amount following approval of the settlement by the Delaware Court of Chancery.  This matter is no longer material to the Company.

[0001571996-24-000062:notes:175]
R2 Semiconductor Patent Litigation — In November 2022, R2 Semiconductor, Inc. (“R2”) filed a lawsuit in the Dusseldorf Regional Court in Germany against Intel Deutschland GmbH, Dell GmbH, and certain other customers of Intel Corporation.  R2 asserted that one European patent is infringed by certain Intel processors and those of the Company’s products that incorporate those processors (the “Accused Products”).  R2 sought an injunction prohibiting the sale of the allegedly infringing products and damages for the alleged infringement.  The Dusseldorf Regional Court (the “Court”) conducted a trial on December 7, 2023, and, on February 7, 2024, issued a decision in favor of R2.  The Court’s judgment imposes an injunction prohibiting (among other acts) the sale and use of the Accused Products in Germany by Dell GmbH, and requiring Dell GmbH to issue a communication to certain customers recalling the covered products sold since March 5, 2020.  These orders will not take effect until after notice of R2’s payment of the sureties required for enforcement and will remain in place unless stayed or overturned on appeal or until the parties reach an agreement.  On February 8, 2024, the Company filed an appeal which is in process with the appellate court.  The Court has not yet assessed damages arising out of R2’s claim.  In April 2024, R2 filed another action alleging infringement of the same patent in the Judicial Court of Paris, France and seeking an injunction prohibiting the sale of the allegedly infringing products and damages for the alleged infringement.  The defendants in the French case include, among others, Intel Corporation and Dell SAS.  Additionally, Dell SAS and its co-defendants filed a nullity action against the patent in France.  In May 2024, R2 filed a third-party action in the Court of Milan, Italy, against Dell S.p.A., Intel Corporation Italia S.p.A., and other Intel customers alleging infringement of the same patent and seeking similar relief.  Intel Corporation has agreed to defend the actions and indemnify the Company and its affiliates against certain losses incurred by the Company in connection with R2’s claims.  Given the status of these lawsuits, the nature of the dispute, and the Company’s agreements with Intel Corporation, the Company is unable to make a reasonable estimate of the potential loss or range of losses that might arise from the litigations.

[0001571996-24-000062:notes:176]
Other Litigation — Dell does not currently anticipate that any of the other legal proceedings it is involved in will have a material adverse effect on its business, financial condition, results of operations, or cash flows.

[0001571996-24-000062:notes:177]
In accordance with the relevant accounting guidance, the Company provides disclosures of matters where it is at least reasonably possible that the Company could experience a material loss exceeding the amounts already accrued for these or other proceedings or matters.  In addition, the Company also discloses matters based on its consideration of other matters and qualitative factors, including the experience of other companies in the industry, and investor, customer, and employee relations considerations.  As of May 3, 2024, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for these or other proceedings or matters has been incurred.  However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company’s business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters.  Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company’s business, financial condition, results of operations, or cash flows will depend on a number of factors, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.

[0001571996-24-000062:notes:178]
Indemnifications Obligations

[0001571996-24-000062:notes:179]
In the ordinary course of business, the Company enters into various contracts under which it may agree to indemnify other parties for losses incurred from certain events as defined in the relevant contract, such as litigation, regulatory penalties, or claims relating to past performance.  Such indemnification obligations may not be subject to maximum loss clauses.  Historically, payments related to these indemnification obligations have not been material to the Company.

[0001571996-24-000062:notes:180]
Under the Separation and Distribution Agreement entered into with VMware, Inc. upon completion of the spin-off of VMware, Inc. by means of a special stock dividend (the “VMware Spin-off”), Dell Technologies agreed to indemnify VMware, Inc., each of its subsidiaries and each of their respective directors, officers, employees, as well as any successors and assigns of the foregoing, from and against all liabilities relating to, arising out of or resulting from, among other matters, the liabilities allocated to Dell Technologies as part of the separation of Dell Technologies and VMware, Inc. (individually and together with its subsidiaries, “VMware”) and their respective businesses (the “Separation”).  VMware similarly agreed to indemnify Dell Technologies Inc., each of its subsidiaries and each of their respective directors, officers, and employees from and against all liabilities relating to, arising out of or resulting from, among other matters, the liabilities allocated to VMware as part of the Separation. The amounts that VMware and Dell Technologies may be obligated to pay each other could vary depending on the outcome of certain unresolved tax matters, which may not be resolved for several years.  Net income tax indemnification receivables from VMware were immaterial as of May 3, 2024 and February 2, 2024.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001571996-24-000062:notes:181]
INCOME AND OTHER TAXES
For the three months ended May 3, 2024, the Company’s effective income tax rate was (74.6)% on pre-tax income of $0.5 billion compared to 18.0% on pre-tax income of $0.7 billion for the three months ended May 5, 2023.   The change in the Company’s effective income tax rate was primarily driven by discrete tax benefits of $0.4 billion related to changes in uncertain tax benefits resulting from the expiration of certain statutes of limitations and $0.2 billion related to stock-based compensation.

[0001571996-24-000062:notes:182]
The differences between the estimated effective income tax rates and the U.S. federal statutory rate of 21% principally result from the geographical distribution of income, differences between the book and tax treatment of certain items, and discrete tax items.  In certain jurisdictions, the Company’s tax rate is significantly less than the applicable statutory rate as a result of tax holidays.  The majority of the Company’s foreign income subject to these tax holidays and lower tax rates is attributable to Singapore and China.  A significant portion of these income tax benefits relates to a tax holiday that will be effective until January 31, 2029.  Most of the Company’s other tax holidays will expire in whole or in part during fiscal years 2030 and 2031.  Many of these tax holidays and reduced tax rates may be extended when certain conditions are met or may be terminated early if certain conditions are not met or as a result of changes in tax legislation.  As of May 3, 2024, the Company was not aware of any matters of non-compliance related to these tax holidays or enacted tax legislative changes affecting these tax holidays.

[0001571996-24-000062:notes:183]
In June 2023, the Company received a Revenue Agent’s Report for the examination by the Internal Revenue Service (“IRS”) of fiscal years 2018 through 2019.  The IRS proposed adjustments primarily relating to certain transactions the Company completed as part of its business integration efforts.  In August 2023, the Company submitted a written protest to the IRS relating to certain assessments.  The Company received a rebuttal from the IRS to its written protest in April 2024.  The Company disagrees with the IRS proposed adjustments and will contest them through the IRS administrative appeals procedures.  The Company anticipates that the appeals process for the resolution of these matters will extend beyond the next twelve months.  In September 2023, the IRS commenced a federal income tax examination of fiscal years 2020 through 2022.

[0001571996-24-000062:notes:184]
The Company is also currently under income tax audits in various U.S. state and foreign taxing jurisdictions.  The Company is undergoing negotiations, and in some cases contested proceedings, relating to tax matters with the taxing authorities in these jurisdictions.  With respect to major U.S. state and foreign taxing jurisdictions, the Company is generally not subject to tax examinations for years prior to the fiscal year ended January 29, 2010.  The Company believes that it has provided adequate reserves related to all matters contained in tax periods open to examination, including the IRS audits described above.

[0001571996-24-000062:notes:185]
Although the Company believes it has made adequate provisions for the uncertainties with respect to these audits, should the Company experience unfavorable outcomes, such outcomes could have a material impact on its results of operations, financial position, and cash flows.

[0001571996-24-000062:notes:186]
Judgment is required in evaluating the Company’s uncertain tax positions and determining the Company’s provision for income taxes.  Unrecognized tax benefits were $1.0 billion and $1.3 billion as of May 3, 2024 and February 2, 2024, respectively, and are included in other non-current liabilities in the Condensed Consolidated Statements of Financial Position.  The Company does not anticipate a significant change to the total amount of unrecognized tax benefits within the next twelve months.

[0001571996-24-000062:notes:187]
The Company takes certain non-income tax positions in the jurisdictions in which it operates and has received certain non-income tax assessments from various jurisdictions.  The Company believes that a material loss in these matters is not probable and that it is not reasonably possible that a material loss exceeding amounts already accrued has been incurred.  The Company believes its positions in these non-income tax litigation matters are supportable and that it ultimately will prevail in the matters.  In the normal course of business, the Company’s positions and conclusions related to its non-income taxes could be challenged and assessments may be made.  To the extent new information is obtained and the Company’s views on its positions, probable outcomes of assessments, or litigation change, changes in estimates to the Company’s accrued liabilities would be recorded in the period in which such a determination is made.  In the resolution process for income tax and non-income tax audits, the Company is required in certain situations to provide collateral guarantees or indemnification to regulators and tax authorities until the matter is resolved.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001571996-24-000062:notes:188]
[same as prior period, unchanged from 0001571996-23-000046:notes:201]

[0001571996-24-000062:notes:189]
[same as prior period, unchanged from 0001571996-23-000046:notes:202]

[0001571996-24-000062:notes:190]
|  | Foreign Currency Translation Adjustments |  |  |  | Cash Flow Hedges |  | Pension and Other Postretirement Plans |  | Accumulated Other Comprehensive Income (Loss) |
|  | (in millions) |
| Balances as of February 2, 2024 | $ | (755) |  |  |  |  | $ | (30) |  |  | $ | (15) |  |  | $ | (800) |  |
| Other comprehensive income (loss) before reclassifications | (74) |  |  |  |  | 87 |  |  | 2 |  |  | 15 |  |
| Amounts reclassified from accumulated other comprehensive income (loss) | — |  |  |  |  | (19) |  |  | (1) |  |  | (20) |  |
| Total change for the period | (74) |  |  |  |  | 68 |  |  | 1 |  |  | (5) |  |
| Balances as of May 3, 2024 | $ | (829) |  |  |  |  | $ | 38 |  |  | $ | (14) |  |  | $ | (805) |  |

[0001571996-24-000062:notes:191]
Amounts related to the Company’s cash flow hedges are reclassified to net income during the same period in which the items being hedged are recognized in earnings.  See Note 7 of the Notes to the Condensed Consolidated Financial Statements for more information about the Company’s derivative instruments.

[0001571996-24-000062:notes:192]
[same as prior period, unchanged from 0001571996-23-000046:notes:205]

[0001571996-24-000062:notes:193]
|  |  |  | Three Months Ended |
|  |  |  | May 3, 2024 |  | May 5, 2023 |  |  |
|  |  |  | Cash Flow Hedges |  |  |  |  |  | Pensions |  |  |  | Total |  | Cash Flow Hedges |  | Pensions |  | Total |  |  |  |  |  |  |
|  |  |  | (in millions) |
| Total reclassifications, net of tax: |  |  |  |  |  |  |
| Net revenue |  |  | $ | 18 |  |  |  |  |  |  | $ | — |  |  |  |  | $ | 18 |  |  | $ | (88) |  |  | $ | — |  |  | $ | (88) |  |  |  |  |  |  |  |
| Cost of net revenue |  |  | 1 |  |  |  |  |  |  | — |  |  |  |  | 1 |  |  | (3) |  |  | — |  |  | (3) |  |  |  |  |  |  |  |
| Operating expenses |  |  | — |  |  |  |  |  |  | 1 |  |  |  |  | 1 |  |  | — |  |  | — |  |  | — |  |  |  |  |  |  |  |
| Total reclassifications, net of tax |  |  | $ | 19 |  |  |  |  |  |  | $ | 1 |  |  |  |  | $ | 20 |  |  | $ | (91) |  |  | $ | — |  |  | $ | (91) |  |  |  |  |  |  |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001571996-24-000062:notes:194]
[same as prior period, unchanged from 0001571996-23-000046:notes:208]

[0001571996-24-000062:notes:195]
|  | Authorized |  | Issued |  | Outstanding |
|  | (in millions) |
| Common stock as of May 3, 2024 |
| Class A | 600 |  |  | 328 |  |  | 328 |  |
| Class B | 200 |  |  | 76 |  |  | 76 |  |
| Class C | 7,900 |  |  | 429 |  |  | 306 |  |
| Class D | 100 |  |  | — |  |  | — |  |
|  | 8,800 |  |  | 833 |  |  | 710 |  |
| Common stock as of February 2, 2024 |
| Class A | 600 |  |  | 353 |  |  | 353 |  |
| Class B | 200 |  |  | 86 |  |  | 86 |  |
| Class C | 7,900 |  |  | 382 |  |  | 266 |  |
| Class D | 100 |  |  | — |  |  | — |  |
|  | 8,800 |  |  | 821 |  |  | 705 |  |

[0001571996-24-000062:notes:196]
[same as prior period, unchanged from 0001571996-23-000046:notes:210]

[0001571996-24-000062:notes:197]
The Company is authorized to issue one million shares of preferred stock, par value $0.01 per share.  As of May 3, 2024 and February 2, 2024, no shares of preferred stock were issued or outstanding.

[0001571996-24-000062:notes:198]
[same as prior period, unchanged from 0001571996-23-000046:notes:212]

[0001571996-24-000062:notes:199]
[same as prior period, unchanged from 0001571996-23-000046:notes:213]

[0001571996-24-000062:notes:200]
[same as prior period, unchanged from 0001571996-23-000046:notes:214]

[0001571996-24-000062:notes:201]
[same as prior period, unchanged from 0001571996-23-000046:notes:215]

[0001571996-24-000062:notes:202]
During the three months ended May 3, 2024, the Company issued 35 million shares of Class C Common Stock to stockholders upon the conversion of 25 million shares of Class A Common Stock and 10 million shares of Class B Common Stock in accordance with the Company’s certificate of incorporation.  During the three months ended May 5, 2023, there were no conversions of shares of Class A Common Stock or Class B Common Stock into shares of Class C Common Stock.

[0001571996-24-000062:notes:203]
[same as prior period, unchanged from 0001571996-23-000046:notes:217]

[0001571996-24-000062:notes:204]
On February 29, 2024, the Company announced that the Board of Directors approved a 20% increase in the quarterly dividend rate to $0.445 per share per fiscal quarter beginning in the first quarter of Fiscal 2025.

[0001571996-24-000062:notes:205]
[same as prior period, unchanged from 0001571996-23-000046:notes:219]

[0001571996-24-000062:notes:206]
| Three Months Ended |  | Declaration Date |  | Record Date |  | Payment Date |  | Dividend per Share |  | Amount (in millions) |
| Fiscal 2025 |
| May 3, 2024 |  | February 29, 2024 |  | April 23, 2024 |  | May 3, 2024 |  | $ | 0.445 |  |  | $ | 316 |  |
| Fiscal 2024 |
| May 5, 2023 |  | March 2, 2023 |  | April 25, 2023 |  | May 5, 2023 |  | $ | 0.37 |  |  | $ | 270 |  |

[0001571996-24-000062:notes:207]
During the three months ended May 3, 2024 and May 5, 2023, the Company also paid an immaterial amount of dividend equivalents on eligible vested equity awards which are not included above.

[0001571996-24-000062:notes:208]
[same as prior period, unchanged from 0001571996-23-000046:notes:222]

[0001571996-24-000062:notes:209]
[same as prior period, unchanged from 0001571996-23-000046:notes:223]

[0001571996-24-000062:notes:210]
Effective as of October 5, 2023, the Company’s Board of Directors approved the repurchase of an additional $5 billion of shares of the Company’s Class C Common Stock under the stock repurchase program.  Following the approval, the Company had approximately $5.7 billion in authorized amount remaining under the program.

[0001571996-24-000062:notes:211]
During the three months ended May 3, 2024, the Company repurchased approximately 6.7 million shares of Class C Common Stock for a total purchase price of approximately $0.7 billion.  During the three months ended May 5, 2023, the Company repurchased 6.1 million shares of Class C Common Stock for a total purchase price of approximately $0.3 billion.
The above repurchases of Class C Common Stock exclude shares withheld from stock awards to settle employee tax withholding obligations related to the vesting of such awards.


## us-gaap:EarningsPerShareTextBlock

[0001571996-24-000062:notes:212]
[same as prior period, unchanged from 0001571996-23-000046:notes:226]

[0001571996-24-000062:notes:213]
[same as prior period, unchanged from 0001571996-23-000046:notes:227]

[0001571996-24-000062:notes:214]
|  | Three Months Ended |  |  |
|  | May 3, 2024 |  | May 5, 2023 |  |  |  |  |  |  |
| Earnings per share attributable to Dell Technologies Inc. |  |  |
| Dell Technologies Common Stock — Basic | $ | 1.36 |  |  | $ | 0.81 |  |  |  |  |  |  |  |
| Dell Technologies Common Stock — Diluted | $ | 1.32 |  |  | $ | 0.79 |  |  |  |  |  |  |  |

[0001571996-24-000062:notes:215]
[same as prior period, unchanged from 0001571996-23-000046:notes:229]

[0001571996-24-000062:notes:216]
|  | Three Months Ended |  |  |
|  | May 3, 2024 |  | May 5, 2023 |  |  |  |  |  |  |
|  | (in millions) |
| Numerator: Dell Technologies Common Stock |  |  |  |  |  |  |  |  |  |
| Net income attributable to Dell Technologies Inc. — basic and diluted | $ | 960 |  |  | $ | 583 |  |  |  |  |  |  |  |
| Denominator: Dell Technologies Common Stock weighted-average shares outstanding |  |  |  |  |  |  |  |  |  |
| Weighted-average shares outstanding — basic | 708 |  |  | 724 |  |  |  |  |  |  |  |
| Dilutive effect of equity awards | 19 |  |  | 13 |  |  |  |  |  |  |  |
| Weighted-average shares outstanding — diluted | 727 |  |  | 737 |  |  |  |  |  |  |  |
| Weighted-average shares outstanding — antidilutive | — |  |  | 16 |  |  |  |  |  |  |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001571996-24-000062:notes:217]
RELATED PARTY TRANSACTIONS 
Prior to the acquisition on November 22, 2023 of VMware LLC (previously VMware, Inc. and individually and together with its consolidated subsidiaries, “VMware”) by Broadcom Inc. (“Broadcom”), VMware was considered a related party of the Company.  Upon Broadcom’s acquisition of VMware, Mr. Dell’s ownership interest in VMware and his position as Chairman of the Board of VMware terminated, and the Company determined no related party relationship exists with Broadcom or VMware effective as of November 22, 2023.  The information provided below includes a summary of related party transactions with VMware for the three months ended May 5, 2023.  The Company continues to engage in select transactions with VMware following the completion of Broadcom’s acquisition and the termination of the related party relationship.  See Note 16 of the Notes to the Consolidated Financial Statements for additional information.

[0001571996-24-000062:notes:218]
Related Party Transactions with VMware

[0001571996-24-000062:notes:219]
•Dell Technologies integrated or bundled select VMware products and services with Dell Technologies’ products and sold them to end-users.  Dell Technologies also acted as a distributor, purchasing VMware’s standalone products and services for resale to end-user customers.  Where applicable, costs under these arrangements were presented net of rebates received by Dell Technologies.

[0001571996-24-000062:notes:220]
•DFS provided financing to certain VMware end-users, which resulted in the recognition of amounts due to related parties on the Condensed Consolidated Statements of Financial Position.  Associated financing fees were recorded to product net revenue on the Condensed Consolidated Statements of Income and were reflected within sales and leases of products to VMware in the table below.

[0001571996-24-000062:notes:221]
•Dell Technologies procured products and services from VMware for its internal use.  For the three months ended  May 5, 2023, costs incurred associated with products and services purchased from VMware for internal use were immaterial.

[0001571996-24-000062:notes:222]
•Dell Technologies sold and leased products and sold services to VMware.  For the three months ended May 5, 2023,  revenue recognized from sales of services to VMware was immaterial.

[0001571996-24-000062:notes:223]
•Dell Technologies and VMware entered into joint marketing, sales, and branding arrangements, for which both parties incurred costs.  For the three months ended May 5, 2023, consideration received from VMware for joint marketing, sales, and branding arrangements was immaterial.

[0001571996-24-000062:notes:224]
The following table presents information about the impact of Dell Technologies’ related party transactions with VMware on the Consolidated Statements of Income for the three months ended May 5, 2023:

[0001571996-24-000062:notes:225]
|  |  |  |  |  |  |  | Three Months Ended |
|  | Classification |  |  |  |  |  |  |  | May 5, 2023 |  |  |
|  |  |  |  |  |  |  |  |  | (in millions) |
| Sales and leases of products to VMware | Net revenue - products |  |  |  |  |  |  |  | $ | 40 |  |  |  |
| Purchase of VMware products for resale | Cost of net revenue - products |  |  |  |  |  |  |  | $ | 207 |  |  |  |
| Purchase of VMware services for resale | Cost of net revenue - services |  |  |  |  |  |  |  | $ | 876 |  |  |  |

[0001571996-24-000062:notes:226]
In connection with the completion of the VMware Spin-off, Dell Technologies and VMware entered into a Tax Matters Agreement effective as of April 14, 2021 (the “Tax Matters Agreement”) which governs the respective rights and obligations of Dell Technologies and VMware regarding income and other taxes as well as related matters, including tax liabilities and benefits, attributes, and returns for periods both preceding and proceeding the VMware Spin-off.  Pursuant to the Tax Matters Agreement, net receipts for VMware during the three months ended May 5, 2023 were immaterial.

[0001571996-24-000062:notes:227]
Other Related Parties

[0001571996-24-000062:notes:228]
Transactions with other related parties during the periods presented were immaterial, individually and in aggregate.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001571996-24-000062:notes:229]
[same as prior period, unchanged from 0001571996-23-000046:notes:256]

[0001571996-24-000062:notes:230]
ISG includes the Company’s storage, server, and networking offerings.  The Company’s comprehensive storage portfolio includes modern and traditional storage solutions, including all-flash arrays, scale-out file, object platforms, hyper-converged infrastructure, and software-defined storage.  The Company’s server portfolio includes high-performance general-purpose and AI-optimized servers.  The Company’s networking portfolio includes wide area network infrastructure, data center and edge networking switches, and cables and optics.  ISG also offers software, peripherals, and services, including consulting and support and deployment.

[0001571996-24-000062:notes:231]
CSG includes offerings designed for commercial and consumer customers.  The Company’s CSG portfolio includes branded PCs including notebooks, desktops, and workstations, branded peripherals, and third-party software and peripherals.  CSG also includes services offerings, such as configuration, support and deployment, and extended warranties.

[0001571996-24-000062:notes:232]
The reportable segments disclosed herein are based on information reviewed by the Company’s management to evaluate the business segment results.  The Company’s measure of segment revenue and segment operating income for management reporting purposes excludes operating results of other businesses, unallocated corporate transactions, amortization of intangible assets, stock-based compensation expense, and other corporate expenses, as applicable.  The Company does not allocate assets to the above reportable segments for internal reporting purposes.

[0001571996-24-000062:notes:233]
Following its acquisition by Broadcom on November 22, 2023, VMware announced changes to its go-to-market approach for VMware offerings that impacted the Company’s commercial relationship with VMware.  On March 25, 2024, the Company terminated the Commercial Framework Agreement (“CFA”) with VMware, which provided the framework under which the Company and VMware continued the commercial relationship following the VMware Spin-off, where Dell Technologies acted as a distributor of VMware’s stand-alone products and services and purchased such products and services for resale to end-user customers (“VMware Resale”).  Dell Technologies no longer acts as a distributor of VMware’s standalone products and services, though the Company will continue to support customers that have purchased resale offerings sold in prior periods.  The results of VMware Resale transactions are reflected in other businesses.  The Company continues to integrate certain VMware products and services with select Dell Technologies’ offerings to end-users.  The results of such offerings are reflected within CSG or ISG, depending upon the nature of the underlying offering sold.

[0001571996-24-000062:notes:234]
[same as prior period, unchanged from 0001571996-23-000046:notes:261]

[0001571996-24-000062:notes:235]
|  | Three Months Ended |  |  |
|  | May 3, 2024 |  | May 5, 2023 |  |  |  |  |  |  |
|  | (in millions) |
| Consolidated net revenue: |  |  |  |  |  |  |  |  |  |
| Infrastructure Solutions Group | $ | 9,227 |  |  | $ | 7,593 |  |  |  |  |  |  |  |
| Client Solutions Group | 11,967 |  |  | 11,983 |  |  |  |  |  |  |  |
| Reportable segment net revenue | 21,194 |  |  | 19,576 |  |  |  |  |  |  |  |
| Other businesses (a) | 1,049 |  |  | 1,343 |  |  |  |  |  |  |  |
| Unallocated transactions (b) | 1 |  |  | 3 |  |  |  |  |  |  |  |
| Total consolidated net revenue | $ | 22,244 |  |  | $ | 20,922 |  |  |  |  |  |  |  |
| Consolidated operating income: |  |  |  |  |  |  |  |  |  |
| Infrastructure Solutions Group | $ | 736 |  |  | $ | 740 |  |  |  |  |  |  |  |
| Client Solutions Group | 732 |  |  | 892 |  |  |  |  |  |  |  |
| Reportable segment operating income | 1,468 |  |  | 1,632 |  |  |  |  |  |  |  |
| Other businesses (a) | 6 |  |  | (36) |  |  |  |  |  |  |  |
| Unallocated transactions (b) | — |  |  | 2 |  |  |  |  |  |  |  |
| Amortization of intangibles (c) | (168) |  |  | (203) |  |  |  |  |  |  |  |
| Stock-based compensation expense (d) | (210) |  |  | (225) |  |  |  |  |  |  |  |
| Other corporate expenses (e) | (176) |  |  | (101) |  |  |  |  |  |  |  |
| Total consolidated operating income | $ | 920 |  |  | $ | 1,069 |  |  |  |  |  |  |  |

[0001571996-24-000062:notes:236]
[same as prior period, unchanged from 0001571996-23-000046:notes:263]

[0001571996-24-000062:notes:237]
[same as prior period, unchanged from 0001571996-23-000046:notes:264]

[0001571996-24-000062:notes:238]
(c)Amortization of intangibles includes non-cash purchase accounting adjustments that are primarily related to the EMC merger transaction.

[0001571996-24-000062:notes:239]
(d)Stock-based compensation expense consists of equity awards granted based on the estimated fair value of those awards at grant date.

[0001571996-24-000062:notes:240]
(e)Other corporate expenses includes severance expenses, payroll taxes associated with stock-based compensation, facility action costs, transaction-related expenses, impairment charges, incentive charges related to equity investments, and other costs.

[0001571996-24-000062:notes:241]
The following table presents the disaggregation of net revenue by reportable segment and by major product categories within the segments for the periods indicated:

[0001571996-24-000062:notes:242]
|  | Three Months Ended |  |  |
|  | May 3, 2024 |  | May 5, 2023 |  |  |  |  |  |  |
|  | (in millions) |
| Net revenue: |  |  |  |  |  |  |  |  |  |
| Infrastructure Solutions Group: |  |  |  |  |  |  |  |  |  |
| Servers and networking | $ | 5,466 |  |  | $ | 3,837 |  |  |  |  |  |  |  |
| Storage | 3,761 |  |  | 3,756 |  |  |  |  |  |  |  |
| Total ISG net revenue | $ | 9,227 |  |  | $ | 7,593 |  |  |  |  |  |  |  |
| Client Solutions Group: |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 10,154 |  |  | $ | 9,862 |  |  |  |  |  |  |  |
| Consumer | 1,813 |  |  | 2,121 |  |  |  |  |  |  |  |
| Total CSG net revenue | $ | 11,967 |  |  | $ | 11,983 |  |  |  |  |  |  |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001571996-24-000062:notes:243]
[same as prior period, unchanged from 0001571996-23-000046:notes:271]

[0001571996-24-000062:notes:244]
|  | May 3, 2024 |  | February 2, 2024 |
|  | (in millions) |
| Cash, cash equivalents, and restricted cash: |  |  |  |
| Cash and cash equivalents | $ | 5,830 |  |  | $ | 7,366 |  |
| Restricted cash - other current assets (a) | 127 |  |  | 136 |  |
| Restricted cash - other non-current assets (a) | 5 |  |  | 5 |  |
| Total cash, cash equivalents, and restricted cash | $ | 5,962 |  |  | $ | 7,507 |  |
| Inventories: |  |  |  |
| Production materials | $ | 3,285 |  |  | $ | 2,321 |  |
| Work-in-process | 694 |  |  | 607 |  |
| Finished goods | 803 |  |  | 694 |  |
| Total inventories | $ | 4,782 |  |  | $ | 3,622 |  |
| Deferred costs: |  |  |  |
| Total deferred costs, current (b) | $ | 5,196 |  |  | $ | 5,548 |  |
| Property, plant, and equipment, net: |  |  |  |
| Assets in a customer contract | $ | 4,966 |  |  | $ | 5,022 |  |
| Computer and other equipment | 3,627 |  |  | 3,552 |  |
| Land and buildings | 2,817 |  |  | 2,877 |  |
| Internal use software | 2,253 |  |  | 2,166 |  |
| Total property, plant, and equipment | 13,663 |  |  | 13,617 |  |
| Accumulated depreciation and amortization | (7,426) |  |  | (7,185) |  |
| Total property, plant, and equipment, net | $ | 6,237 |  |  | $ | 6,432 |  |

[0001571996-24-000062:notes:245]
[same as prior period, unchanged from 0001571996-23-000046:notes:273]

[0001571996-24-000062:notes:246]
[same as prior period, unchanged from 0001571996-23-000046:notes:274]

[0001571996-24-000062:notes:247]
[same as prior period, unchanged from 0001571996-23-000046:notes:275]

[0001571996-24-000062:notes:248]
[same as prior period, unchanged from 0001571996-23-000046:notes:276]

[0001571996-24-000062:notes:249]
|  | Three Months Ended |  |  |
|  | May 3, 2024 |  | May 5, 2023 |  |  |  |  |  |  |
|  | (in millions) |
| Warranty liability: |  |  |  |  |  |  |  |  |  |
| Warranty liability at beginning of period | $ | 426 |  |  | $ | 467 |  |  |  |  |  |  |  |
| Costs accrued for new warranty contracts and changes in estimates for pre-existing warranties (a) | 229 |  |  | 196 |  |  |  |  |  |  |  |
| Service obligations honored | (229) |  |  | (225) |  |  |  |  |  |  |  |
| Warranty liability at end of period | $ | 426 |  |  | $ | 438 |  |  |  |  |  |  |  |

[0001571996-24-000062:notes:250]
[same as prior period, unchanged from 0001571996-23-000046:notes:278]

[0001571996-24-000062:notes:251]
[same as prior period, unchanged from 0001571996-23-000046:notes:279]

[0001571996-24-000062:notes:252]
[same as prior period, unchanged from 0001571996-23-000046:notes:280]

[0001571996-24-000062:notes:253]
[same as prior period, unchanged from 0001571996-23-000046:notes:281]

[0001571996-24-000062:notes:254]
|  | Three Months Ended |  |  |
|  | May 3, 2024 |  | May 5, 2023 |  |  |  |  |  |  |
|  | (in millions) |
| Severance liability: |  |  |  |  |  |  |  |  |  |
| Severance liability at beginning of period | $ | 352 |  |  | $ | 408 |  |  |  |  |  |  |  |
| Severance charges | 92 |  |  | 48 |  |  |  |  |  |  |  |
| Cash paid and other | (250) |  |  | (294) |  |  |  |  |  |  |  |
| Severance liability at end of period | $ | 194 |  |  | $ | 162 |  |  |  |  |  |  |  |

[0001571996-24-000062:notes:255]
[same as prior period, unchanged from 0001571996-23-000046:notes:283]

[0001571996-24-000062:notes:256]
|  | Three Months Ended |  |  |
|  | May 3, 2024 |  | May 5, 2023 |  |  |  |  |  |  |
|  | (in millions) |
| Severance charges: |  |  |  |  |  |  |  |  |  |
| Cost of net revenue | $ | 29 |  |  | $ | 21 |  |  |  |  |  |  |  |
| Selling, general, and administrative | 43 |  |  | 26 |  |  |  |  |  |  |  |
| Research and development | 20 |  |  | 1 |  |  |  |  |  |  |  |
| Total severance charges | $ | 92 |  |  | $ | 48 |  |  |  |  |  |  |  |

[0001571996-24-000062:notes:257]
[same as prior period, unchanged from 0001571996-23-000046:notes:285]

[0001571996-24-000062:notes:258]
The Company maintains a Supply Chain Finance Program (the “SCF Program”), which enables eligible suppliers, at the supplier's sole discretion, to sell receivables due from the Company to a third-party financial institution.  The Company has no involvement in establishing the terms or conditions of the arrangement between its suppliers and the financial institution, no economic interest in a supplier's decision to sell a receivable, and does not provide legally secured assets or other forms of guarantees under the arrangement.  The SCF Program does not impact the Company's liquidity as payments for participating supplier invoices are remitted by the Company to the financial institution on the original invoice due date, regardless of whether an individual invoice is sold by the supplier to the financial institution.  As of May 3, 2024 and February 2, 2024, the Company had $1.0 billion and $1.1 billion, respectively, included within Accounts Payable on the Condensed Consolidated Statements of Financial Position representing invoices due to suppliers confirmed as valid under the SCF Program.

[0001571996-24-000062:notes:259]
[same as prior period, unchanged from 0001571996-23-000046:notes:290]

[0001571996-24-000062:notes:260]
[same as prior period, unchanged from 0001571996-23-000046:notes:291]

[0001571996-24-000062:notes:261]
|  | Three Months Ended |  |  |
|  | May 3, 2024 |  | May 5, 2023 |  |  |  |  |  |  |
|  | (in millions) |
| Interest and other, net: |  |  |  |  |  |  |  |  |  |
| Investment income, primarily interest | $ | 54 |  |  | $ | 59 |  |  |  |  |  |  |  |
| Loss on investments, net | (30) |  |  | (15) |  |  |  |  |  |  |  |
| Interest expense | (343) |  |  | (405) |  |  |  |  |  |  |  |
| Foreign exchange | (38) |  |  | (32) |  |  |  |  |  |  |  |
| Other | (16) |  |  | 29 |  |  |  |  |  |  |  |
| Total interest and other, net | $ | (373) |  |  | $ | (364) |  |  |  |  |  |  |  |


## us-gaap:SubsequentEventsTextBlock

[0001571996-24-000062:notes:262]
SUBSEQUENT EVENTS 
There were no known events occurring after May 3, 2024, and up until the date of issuance of this report that would materially affect the information presented herein.
