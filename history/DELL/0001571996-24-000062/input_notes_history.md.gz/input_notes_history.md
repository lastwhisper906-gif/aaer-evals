# DELL note change history — 0001571996-23-000046 → 0001571996-24-000062


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-06-11):
[0001571996-24-000062:note_history:1]
COMMITMENTS AND CONTINGENCIES 
Legal Matters
  (was, 2023-12-08, similarity 0.7527):
[0001571996-23-000046:note_history:1]
COMMITMENTS AND CONTINGENCIES 
Purchase Obligations

- changed (2024-06-11):
[0001571996-24-000062:note_history:2]
Class Actions Related to the Class V Transaction — On December 28, 2018, the Company completed a transaction (the “Class V transaction”) in which it paid $14.0 billion in cash and issued 149,387,617 shares of its Class C Common Stock to holders of its Class V Common Stock in exchange for all outstanding shares of Class V Common Stock.  As a result of the Class V transaction, the tracking stock feature of the Company’s capital structure associated with the Class V Common Stock was terminated.  Certain stockholders of the Company, subsequently brought class action complaints arising out of the Class V transaction in which they named as defendants (collectively, the “defendants”) Michael S. Dell and certain other directors serving on the Company’s board of directors at the time of the Class V transaction (collectively, the “director defendants”), certain stockholders of the Company, consisting of Mr. Dell and Silver Lake Group, L.L.C. and certain of its affiliated funds (collectively, the “stockholder defendants”), and Goldman Sachs & Co. LLC (“Goldman Sachs”), which served as financial advisor to the Company in connection with the transaction.  The plaintiffs generally alleged that the director defendants and the stockholder defendants breached their fiduciary duties under Delaware law to the former holders of the Class V Common Stock in connection with the Class V transaction by offering a transaction value that was allegedly billions of dollars below fair value.
  (was, 2023-12-08, similarity 0.9959):
[0001571996-23-000046:note_history:2]
Class Actions Related to the Class V Transaction — On December 28, 2018, the Company completed a transaction (the “Class V transaction”) in which it paid $14.0 billion in cash and issued 149,387,617 shares of its Class C Common Stock to holders of its Class V Common Stock in exchange for all outstanding shares of Class V Common Stock.  As a result of the Class V transaction, the tracking stock feature of the Company’s capital structure associated with the Class V Common Stock was terminated.  Certain stockholders of the Company, subsequently brought class action complaints arising out of the Class V transaction in which they named as defendants (collectively, the “defendants”) Michael S. Dell and certain other directors serving on the Company’s board of directors at the time of the Class V transaction (collectively, the “director defendants”), certain stockholders of the Company, consisting of Mr. Dell and Silver Lake Group LLC and certain of its affiliated funds (collectively, the “stockholder defendants”), and Goldman Sachs & Co. LLC (“Goldman Sachs”), which served as financial advisor to the Company in connection with the transaction.  The plaintiffs generally alleged that the director defendants and the stockholder defendants breached their fiduciary duties under Delaware law to the former holders of the Class V Common Stock in connection with the Class V transaction by offering a transaction value that was allegedly billions of dollars below fair value.

- added (2024-06-11):
[0001571996-24-000062:note_history:3]
As previously reported, during the fourth quarter of the fiscal year ended February 3, 2023, the plaintiffs and the defendants entered into an agreement to settle the lawsuit.  Under the terms of the settlement, the plaintiffs agreed to the dismissal of all claims upon payment of a total of $1.0 billion (the “settlement amount”), which includes all costs, expenses and fees of the plaintiff class relating to the action and its resolution.  On May 16, 2023, during the fiscal year ended February 2, 2024, the Company paid the settlement amount following approval of the settlement by the Delaware Court of Chancery.  This matter is no longer material to the Company.

- added (2024-06-11):
[0001571996-24-000062:note_history:4]
R2 Semiconductor Patent Litigation — In November 2022, R2 Semiconductor, Inc. (“R2”) filed a lawsuit in the Dusseldorf Regional Court in Germany against Intel Deutschland GmbH, Dell GmbH, and certain other customers of Intel Corporation.  R2 asserted that one European patent is infringed by certain Intel processors and those of the Company’s products that incorporate those processors (the “Accused Products”).  R2 sought an injunction prohibiting the sale of the allegedly infringing products and damages for the alleged infringement.  The Dusseldorf Regional Court (the “Court”) conducted a trial on December 7, 2023, and, on February 7, 2024, issued a decision in favor of R2.  The Court’s judgment imposes an injunction prohibiting (among other acts) the sale and use of the Accused Products in Germany by Dell GmbH, and requiring Dell GmbH to issue a communication to certain customers recalling the covered products sold since March 5, 2020.  These orders will not take effect until after notice of R2’s payment of the sureties required for enforcement and will remain in place unless stayed or overturned on appeal or until the parties reach an agreement.  On February 8, 2024, the Company filed an appeal which is in process with the appellate court.  The Court has not yet assessed damages arising out of R2’s claim.  In April 2024, R2 filed another action alleging infringement of the same patent in the Judicial Court of Paris, France and seeking an injunction prohibiting the sale of the allegedly infringing products and damages for the alleged infringement.  The defendants in the French case include, among others, Intel Corporation and Dell SAS.  Additionally, Dell SAS and its co-defendants filed a nullity action against the patent in France.  In May 2024, R2 filed a third-party action in the Court of Milan, Italy, against Dell S.p.A., Intel Corporation Italia S.p.A., and other Intel customers alleging infringement of the same patent and seeking similar relief.  Intel Corporation has agreed to defend the actions and indemnify the Company and its affiliates against certain losses incurred by the Company in connection with R2’s claims.  Given the status of these lawsuits, the nature of the dispute, and the Company’s agreements with Intel Corporation, the Company is unable to make a reasonable estimate of the potential loss or range of losses that might arise from the litigations.

- changed (2024-06-11):
[0001571996-24-000062:note_history:5]
Other Litigation — Dell does not currently anticipate that any of the other legal proceedings it is involved in will have a material adverse effect on its business, financial condition, results of operations, or cash flows.
  (was, 2023-12-08, similarity 0.9824):
[0001571996-23-000046:note_history:5]
Other Litigation — Dell does not currently anticipate that any of the other various legal proceedings it is involved in will have a material adverse effect on its business, financial condition, results of operations, or cash flows.

- changed (2024-06-11):
[0001571996-24-000062:note_history:6]
In accordance with the relevant accounting guidance, the Company provides disclosures of matters where it is at least reasonably possible that the Company could experience a material loss exceeding the amounts already accrued for these or other proceedings or matters.  In addition, the Company also discloses matters based on its consideration of other matters and qualitative factors, including the experience of other companies in the industry, and investor, customer, and employee relations considerations.  As of May 3, 2024, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for these or other proceedings or matters has been incurred.  However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company’s business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters.  Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company’s business, financial condition, results of operations, or cash flows will depend on a number of factors, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.
  (was, 2023-12-08, similarity 0.9962):
[0001571996-23-000046:note_history:6]
In accordance with the relevant accounting guidance, the Company provides disclosures of matters where it is at least reasonably possible that the Company could experience a material loss exceeding the amounts already accrued for these or other proceedings or matters.  In addition, the Company also discloses matters based on its consideration of other matters and qualitative factors, including the experience of other companies in the industry, and investor, customer, and employee relations considerations.  As of November 3, 2023, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for these or other proceedings or matters has been incurred.  However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company’s business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters.  Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company’s business, financial condition, results of operations, or cash flows will depend on a number of factors, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.

- changed (2024-06-11):
[0001571996-24-000062:note_history:7]
Under the Separation and Distribution Agreement entered into with VMware, Inc. upon completion of the spin-off of VMware, Inc. by means of a special stock dividend (the “VMware Spin-off”), Dell Technologies agreed to indemnify VMware, Inc., each of its subsidiaries and each of their respective directors, officers, employees, as well as any successors and assigns of the foregoing, from and against all liabilities relating to, arising out of or resulting from, among other matters, the liabilities allocated to Dell Technologies as part of the separation of Dell Technologies and VMware, Inc. (individually and together with its subsidiaries, “VMware”) and their respective businesses (the “Separation”).  VMware similarly agreed to indemnify Dell Technologies Inc., each of its subsidiaries and each of their respective directors, officers, and employees from and against all liabilities relating to, arising out of or resulting from, among other matters, the liabilities allocated to VMware as part of the Separation. The amounts that VMware and Dell Technologies may be obligated to pay each other could vary depending on the outcome of certain unresolved tax matters, which may not be resolved for several years.  Net income tax indemnification receivables from VMware were immaterial as of May 3, 2024 and February 2, 2024.
  (was, 2023-12-08, similarity 0.806):
[0001571996-23-000046:note_history:7]
Under the Separation and Distribution Agreement entered into with VMware, Inc. upon the completion of the spin-off of VMware, Inc. by means of a special stock dividend (the “VMware Spin-off”) on November 1, 2021, Dell Technologies agreed to indemnify VMware, Inc., each of its subsidiaries and each of their respective directors, officers, and employees from and against all liabilities relating to, arising out of or resulting from, among other matters, the liabilities allocated to Dell Technologies as part of the separation of Dell Technologies and VMware, Inc. (individually and together with its subsidiaries, “VMware”) and their respective businesses (the “Separation”). VMware similarly agreed to indemnify Dell Technologies Inc., each of its subsidiaries and each of their respective directors, officers, and employees from and against all liabilities relating to, arising out of or resulting from, among other matters, the liabilities allocated to VMware as part of the Separation. Dell Technologies expects VMware to fully perform under the terms of the Separation and Distribution Agreement.

- removed (2024-06-11):
[0001571996-23-000046:note_history:8]
The Company has contractual obligations to purchase goods or services, which specify significant terms (including fixed or minimum quantities to be purchased), fixed, minimum, or variable price provisions; and the approximate timing of the transaction.  As of November 3, 2023, such purchase obligations were $3.8 billion for the remaining three months of Fiscal 2024; $0.8 billion for Fiscal 2025; and $0.6 billion for Fiscal 2026 and thereafter.

- removed (2024-06-11):
[0001571996-23-000046:note_history:9]
Legal Matters

- removed (2024-06-11):
[0001571996-23-000046:note_history:10]
As previously reported, during the fourth quarter of Fiscal 2023, the plaintiffs and the defendants entered into an agreement to settle the lawsuit.  Under the terms of the settlement, the plaintiffs agreed to the dismissal of all claims upon payment of a total of $1.0 billion (the “settlement amount”), which includes all costs, expenses and fees of the plaintiff class relating to the action and its resolution.  The settlement terms required that the settlement amount be paid by the Company and/or the Company’s insurers pursuant to indemnification obligations of the Company to the defendants.  The Company is subject to indemnification obligations, upon the satisfaction of specified conditions, to the director and stockholder defendants and their affiliates pursuant to provisions of the Delaware General Corporation Law, the Company’s certificate of incorporation and bylaws, and agreements with the defendants.  A special committee of the Board of Directors consisting of directors who were not defendants in the action, advised by independent counsel, informed the Board of Directors of its determination that the defendants are entitled to indemnification under the foregoing obligations.

- removed (2024-06-11):
[0001571996-23-000046:note_history:11]
During Fiscal 2023, the Company established a $1.0 billion liability on the Consolidated Statements of Financial Position and recognized $0.9 billion expense, net of $106 million in insurance proceeds, within interest and other, net within the Consolidated Statements of Income related to the settlement agreement.  The Company accounted for the expected insurance proceeds as a loss recovery and recognized a benefit within interest and other, net within the Condensed Consolidated Statements of Income and corresponding receivable on the Condensed Consolidated Statements of Financial Position.

- removed (2024-06-11):
[0001571996-23-000046:note_history:12]
On May 16, 2023, during the second quarter of Fiscal 2024, the Company paid the settlement amount following approval of the settlement by the Delaware Court of Chancery.  The payment is reflected within cash flows from operating activities within the Condensed Consolidated Statements of Cash Flows.  The Company does not expect to incur additional expenses with respect to the settlement.

- removed (2024-06-11):
[0001571996-23-000046:note_history:13]
For information on the cross-indemnifications related to the tax matters agreement between the Company and VMware effective upon the Separation on November 1, 2021, see Note 15 of the Notes to the Condensed Consolidated Financial Statements.


## dell:CreditLossFinancialInstrumentLeasesDebtVariableInterestEntitiesAndCustomerReceivablesSalesTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-06-11):
[0001571996-24-000062:note_history:14]
Financing options are offered to the Company’s customers primarily through Dell Financial Services and its affiliates (“DFS”).  The Company also arranges financing for some of its customers in various countries where DFS does not currently operate as a captive enterprise.  The key activities of DFS include originating, collecting, and servicing customer financing arrangements primarily related to the purchase or use of Dell Technologies products and services.  In some cases, DFS also offers financing for the purchase of third-party technology products that complement the Dell Technologies portfolio of products and services.  New financing originations were $1.9 billion and $1.8 billion for the three months ended May 3, 2024 and May 5, 2023, respectively.
  (was, 2023-12-08, similarity 0.9045):
[0001571996-23-000046:note_history:14]
Financing options are offered to our customers primarily through Dell Financial Services and its affiliates (“DFS”).  The Company also arranges financing for some of its customers in various countries where DFS does not currently operate as a captive enterprise.  The key activities of DFS include originating, collecting, and servicing customer financing arrangements primarily related to the purchase or use of Dell Technologies products and services.  In some cases, DFS also offers financing for the purchase of third-party technology products that complement the Dell Technologies portfolio of products and services.  New financing originations were $1.8 billion and $2.3 billion for the three months ended November 3, 2023 and October 28, 2022, respectively, and $6.0 billion and $6.7 billion for the nine months ended November 3, 2023 and October 28, 2022, respectively.

- added (2024-06-11):
[0001571996-24-000062:note_history:15]
Revolving loans — Revolving loans provide qualified customers with a revolving credit line for the purchase of products and services offered by Dell Technologies.  The Company primarily offers revolving loans to small and medium-sized commercial customers.  Revolving loans in the United States bear interest at a variable annual percentage rate that is tied to the prime rate.  Based on historical payment patterns, revolving loan transactions are typically repaid within twelve months on average.  Due to the short-term nature of the revolving loan portfolio, the carrying value of the portfolio approximates fair value.

- changed (2024-06-11):
[0001571996-24-000062:note_history:16]
Flexible consumption models, as defined above, further enable the Company to offer its customers the option to pay over time to provide them with financial and operational flexibility.  Such models may result in identification of embedded lease arrangements that lead to the recognition of operating or sales-type leases.
  (was, 2023-12-08, similarity 0.9021):
[0001571996-23-000046:note_history:16]
Flexible consumption models, as defined above, further enable the Company to offer its customers the option to pay over time to provide them with financial flexibility to meet their changing technological requirements.  Such models may result in identification of embedded lease arrangements that lead to the recognition of operating or sales-type leases.

- changed (2024-06-11):
[0001571996-24-000062:note_history:17]
|  | May 3, 2024 |  | February 2, 2024 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Financing receivables, net: |  |  |  |  |  |  |  |  |  |  |  |
| Customer receivables, gross (a) | $ | 163 |  |  | $ | 10,470 |  |  | $ | 10,633 |  |  | $ | 173 |  |  | $ | 10,360 |  |  | $ | 10,533 |  |
| Allowances for losses | (8) |  |  | (187) |  |  | (195) |  |  | (9) |  |  | (161) |  |  | (170) |  |
| Customer receivables, net | 155 |  |  | 10,283 |  |  | 10,438 |  |  | 164 |  |  | 10,199 |  |  | 10,363 |  |
| Residual interest | — |  |  | 163 |  |  | 163 |  |  | — |  |  | 157 |  |  | 157 |  |
| Financing receivables, net | $ | 155 |  |  | $ | 10,446 |  |  | $ | 10,601 |  |  | $ | 164 |  |  | $ | 10,356 |  |  | $ | 10,520 |  |
| Short-term | $ | 155 |  |  | $ | 4,505 |  |  | $ | 4,660 |  |  | $ | 164 |  |  | $ | 4,479 |  |  | $ | 4,643 |  |
| Long-term | $ | — |  |  | $ | 5,941 |  |  | $ | 5,941 |  |  | $ | — |  |  | $ | 5,877 |  |  | $ | 5,877 |  |
  (was, 2023-12-08, similarity 0.9918):
[0001571996-23-000046:note_history:17]
|  | November 3, 2023 |  | February 3, 2023 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Financing receivables, net: |  |  |  |  |  |  |  |  |  |  |  |
| Customer receivables, gross (a) (b) | $ | 172 |  |  | $ | 10,144 |  |  | $ | 10,316 |  |  | $ | 685 |  |  | $ | 10,293 |  |  | $ | 10,978 |  |
| Allowances for losses | (9) |  |  | (144) |  |  | (153) |  |  | (88) |  |  | (113) |  |  | (201) |  |
| Customer receivables, net | 163 |  |  | 10,000 |  |  | 10,163 |  |  | 597 |  |  | 10,180 |  |  | 10,777 |  |
| Residual interest | — |  |  | 150 |  |  | 150 |  |  | — |  |  | 142 |  |  | 142 |  |
| Financing receivables, net | $ | 163 |  |  | $ | 10,150 |  |  | $ | 10,313 |  |  | $ | 597 |  |  | $ | 10,322 |  |  | $ | 10,919 |  |
| Short-term | $ | 163 |  |  | $ | 4,377 |  |  | $ | 4,540 |  |  | $ | 597 |  |  | $ | 4,684 |  |  | $ | 5,281 |  |
| Long-term | $ | — |  |  | $ | 5,773 |  |  | $ | 5,773 |  |  | $ | — |  |  | $ | 5,638 |  |  | $ | 5,638 |  |

- changed (2024-06-11):
[0001571996-24-000062:note_history:18]
The following table presents the changes in allowance for financing receivables losses for the periods indicated:
  (was, 2023-12-08, similarity 0.9956):
[0001571996-23-000046:note_history:18]
The following table presents the changes in allowance for financing receivable losses for the periods indicated:

- added (2024-06-11):
[0001571996-24-000062:note_history:19]
|  | Three Months Ended |
|  | May 3, 2024 |  | May 5, 2023 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |  |  |  |  |  |  |  |
| Balances at beginning of period | $ | 9 |  |  | $ | 161 |  |  | $ | 170 |  |  | $ | 88 |  |  | $ | 113 |  |  | $ | 201 |  |
| Charge-offs, net of recoveries | (2) |  |  | (6) |  |  | (8) |  |  | (17) |  |  | (1) |  |  | (18) |  |
| Provision charged to income statement | 1 |  |  | 32 |  |  | 33 |  |  | 13 |  |  | 23 |  |  | 36 |  |
| Balances at end of period | $ | 8 |  |  | $ | 187 |  |  | $ | 195 |  |  | $ | 84 |  |  | $ | 135 |  |  | $ | 219 |  |

- changed (2024-06-11):
[0001571996-24-000062:note_history:20]
The Company recognizes an allowance for financing receivables losses, including both the lease receivable and unguaranteed residual, in an amount equal to the expected losses net of recoveries.  The allowance for financing receivables losses on the lease receivable is determined based on various factors, including lifetime expected losses determined using macroeconomic forecast assumptions and management judgments applicable to and through the expected life of the portfolios as well as past due receivables, receivable type, and customer risk profile.  The Company continues to monitor broader economic indicators and their potential impact on future credit loss performance.
  (was, 2023-12-08, similarity 0.9985):
[0001571996-23-000046:note_history:20]
The Company recognizes an allowance for financing receivable losses, including both the lease receivable and unguaranteed residual, in an amount equal to the expected losses net of recoveries.  The allowance for financing receivable losses on the lease receivable is determined based on various factors, including lifetime expected losses determined using macroeconomic forecast assumptions and management judgments applicable to and through the expected life of the portfolios as well as past due receivables, receivable type, and customer risk profile.  The Company continues to monitor broader economic indicators and their potential impact on future credit loss performance.

- added (2024-06-11):
[0001571996-24-000062:note_history:21]
|  | May 3, 2024 |  | February 2, 2024 |
|  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |
|  | (in millions) |
| Revolving | $ | 142 |  |  | $ | 17 |  |  | $ | 4 |  |  | $ | 163 |  |  | $ | 151 |  |  | $ | 17 |  |  | $ | 5 |  |  | $ | 173 |  |
| Fixed-term — Consumer and Commercial | 9,477 |  |  | 891 |  |  | 102 |  |  | 10,470 |  |  | 9,345 |  |  | 889 |  |  | 126 |  |  | 10,360 |  |
| Total customer receivables, gross | $ | 9,619 |  |  | $ | 908 |  |  | $ | 106 |  |  | $ | 10,633 |  |  | $ | 9,496 |  |  | $ | 906 |  |  | $ | 131 |  |  | $ | 10,533 |  |

- changed (2024-06-11):
[0001571996-24-000062:note_history:22]
|  | May 3, 2024 |
|  | Fixed-term — Consumer and Commercial |  |  |  |  |
|  | Fiscal Year of Origination |  |  |  |  |
|  | 2025 |  | 2024 |  | 2023 |  | 2022 |  | 2021 |  | Years Prior |  | Revolving |  | Total |
|  | (in millions) |
| Higher | $ | 687 |  |  | $ | 2,827 |  |  | $ | 1,699 |  |  | $ | 683 |  |  | $ | 274 |  |  | $ | 46 |  |  | $ | 39 |  |  | $ | 6,255 |  |
| Mid | 237 |  |  | 1,030 |  |  | 783 |  |  | 202 |  |  | 55 |  |  | 13 |  |  | 49 |  |  | 2,369 |  |
| Lower | 764 |  |  | 578 |  |  | 374 |  |  | 143 |  |  | 61 |  |  | 14 |  |  | 75 |  |  | 2,009 |  |
| Total | $ | 1,688 |  |  | $ | 4,435 |  |  | $ | 2,856 |  |  | $ | 1,028 |  |  | $ | 390 |  |  | $ | 73 |  |  | $ | 163 |  |  | $ | 10,633 |  |
  (was, 2023-12-08, similarity 0.9294):
[0001571996-23-000046:note_history:22]
|  | November 3, 2023 |
|  | Fixed-term — Consumer and Commercial |  |  |  |  |  |  |
|  | Fiscal Year of Origination |  |  |  |  |  |  |
|  | 2024 |  | 2023 |  | 2022 |  | 2021 |  | 2020 |  | Years Prior |  | Revolving — DPA |  | Revolving — DBC |  | Total |
|  | (in millions) |
| Higher | $ | 2,494 |  |  | $ | 2,195 |  |  | $ | 1,076 |  |  | $ | 499 |  |  | $ | 127 |  |  | $ | 3 |  |  | $ | 1 |  |  | $ | 42 |  |  | $ | 6,437 |  |
| Mid | 849 |  |  | 1,047 |  |  | 378 |  |  | 159 |  |  | 40 |  |  | 2 |  |  | 2 |  |  | 49 |  |  | 2,526 |  |
| Lower | 454 |  |  | 516 |  |  | 210 |  |  | 69 |  |  | 25 |  |  | 1 |  |  | 2 |  |  | 76 |  |  | 1,353 |  |
| Total | $ | 3,797 |  |  | $ | 3,758 |  |  | $ | 1,664 |  |  | $ | 727 |  |  | $ | 192 |  |  | $ | 6 |  |  | $ | 5 |  |  | $ | 167 |  |  | $ | 10,316 |  |

- changed (2024-06-11):
[0001571996-24-000062:note_history:23]
|  | February 2, 2024 |
|  | Fixed-term — Consumer and Commercial |  |  |  |  |  |  |
|  | Fiscal Year of Origination |  |  |  |  |  |  |
|  | 2024 |  | 2023 |  | 2022 |  | 2021 |  | 2020 |  | Years Prior |  |  |  | Revolving |  | Total |
|  | (in millions) |
| Higher | $ | 3,261 |  |  | $ | 1,979 |  |  | $ | 833 |  |  | $ | 345 |  |  | $ | 64 |  |  | $ | — |  |  |  |  | $ | 47 |  |  | $ | 6,529 |  |
| Mid | 1,111 |  |  | 911 |  |  | 290 |  |  | 86 |  |  | 19 |  |  | — |  |  |  |  | 50 |  |  | 2,467 |  |
| Lower | 703 |  |  | 469 |  |  | 187 |  |  | 80 |  |  | 21 |  |  | 1 |  |  |  |  | 76 |  |  | 1,537 |  |
| Total | $ | 5,075 |  |  | $ | 3,359 |  |  | $ | 1,310 |  |  | $ | 511 |  |  | $ | 104 |  |  | $ | 1 |  |  |  |  | $ | 173 |  |  | $ | 10,533 |  |
  (was, 2023-12-08, similarity 0.8974):
[0001571996-23-000046:note_history:23]
|  | February 3, 2023 |
|  | Fixed-term — Consumer and Commercial |  |  |  |  |  |  |
|  | Fiscal Year of Origination |  |  |  |  |  |  |
|  | 2023 |  | 2022 |  | 2021 |  | 2020 |  | 2019 |  | Years Prior |  | Revolving — DPA |  | Revolving — DBC |  | Total |
|  | (in millions) |
| Higher | $ | 3,210 |  |  | $ | 1,805 |  |  | $ | 914 |  |  | $ | 343 |  |  | $ | 37 |  |  | $ | 1 |  |  | $ | 123 |  |  | $ | 44 |  |  | $ | 6,477 |  |
| Mid | 1,242 |  |  | 631 |  |  | 362 |  |  | 119 |  |  | 17 |  |  | 1 |  |  | 136 |  |  | 54 |  |  | 2,562 |  |
| Lower | 1,017 |  |  | 364 |  |  | 157 |  |  | 65 |  |  | 7 |  |  | 1 |  |  | 249 |  |  | 79 |  |  | 1,939 |  |
| Total | $ | 5,469 |  |  | $ | 2,800 |  |  | $ | 1,433 |  |  | $ | 527 |  |  | $ | 61 |  |  | $ | 3 |  |  | $ | 508 |  |  | $ | 177 |  |  | $ | 10,978 |  |

- changed (2024-06-11):
[0001571996-24-000062:note_history:24]
The categories shown in the tables above segregate customer receivables based on the relative degrees of credit risk.  Credit quality indicators for revolving and fixed-term accounts are generally updated on a periodic basis.
  (was, 2023-12-08, similarity 0.9912):
[0001571996-23-000046:note_history:24]
The categories shown in the tables above segregate customer receivables based on the relative degrees of credit risk.  Credit quality indicators for DBC revolving and fixed-term accounts are generally updated on a periodic basis.

- changed (2024-06-11):
[0001571996-24-000062:note_history:25]
For the revolving receivables and fixed-term commercial receivables shown in the tables above, an internal grading system is utilized that assigns a credit level score based on a number of considerations, including liquidity, operating performance, and industry outlook.  The grading criteria and classifications for the fixed-term products differ from those for the revolving products as loss experience varies between these product and customer groups.  The credit quality categories cannot be compared between the different classes as loss experience varies substantially between the classes.
  (was, 2023-12-08, similarity 0.6325):
[0001571996-23-000046:note_history:25]
For the DBC revolving receivables and fixed-term commercial receivables shown in the table above, an internal grading system is utilized that assigns a credit level score based on a number of considerations, including liquidity, operating performance, and industry outlook.  The grading criteria and classifications for the fixed-term products differ from those for the revolving products as loss experience varies between these product and customer groups.  The credit quality categories cannot be compared between the different classes as loss experience varies substantially between the classes.  Prior to the sale of the U.S. consumer revolving customer receivables revolving portfolio described in Note 1 of the Notes to the Condensed Consolidated Financial Statements, the Company made credit decisions based on proprietary scorecards, which included the customer’s credit history, payment history, credit usage, and other credit agency-related elements.  The higher quality category included prime accounts generally comparable to U.S. customer FICO scores of 720 or above.  The mid category represented mid-tier accounts that are comparable to U.S. customer FICO scores from 660 to 719.  The lower category represented accounts that are comparable to U.S. customer FICO scores below 660.

- changed (2024-06-11):
[0001571996-24-000062:note_history:26]
The following table presents amounts included in the Condensed Consolidated Statements of Income related to sales-type lease activity for the periods indicated:
  (was, 2023-12-08, similarity 0.6254):
[0001571996-23-000046:note_history:26]
The following table presents net revenue, cost of net revenue, and gross margin recognized at the commencement date of sales-type leases for the periods indicated:

- added (2024-06-11):
[0001571996-24-000062:note_history:27]
|  |  |  | Three Months Ended |
|  |  |  |  |  | May 3, 2024 |  | May 5, 2023 |  |  |
|  |  |  |  |  | (in millions) |
| Net revenue — products |  |  |  |  | $ | 728 |  |  | $ | 247 |  |  |  |
| Cost of net revenue — products |  |  |  |  | 618 |  |  | 196 |  |  |  |
| Gross margin — products |  |  |  |  | $ | 110 |  |  | $ | 51 |  |  |  |

- changed (2024-06-11):
[0001571996-24-000062:note_history:28]
The following table presents the future maturity of the Company’s fixed-term customer leases and associated financing payments, and reconciles the undiscounted cash flows to the customer receivables, gross recognized on the Condensed Consolidated Statements of Financial Position as of the date indicated:
  (was, 2023-12-08, similarity 0.9984):
[0001571996-23-000046:note_history:28]
The following table presents the future maturity of the Company’s fixed-term customer leases and associated financing payments, and reconciles the undiscounted cash flows to the customer receivables, gross recognized on the Condensed Consolidated Statement of Financial Position as of the date indicated:

- changed (2024-06-11):
[0001571996-24-000062:note_history:29]
|  | May 3, 2024 |
|  | (in millions) |
| Fiscal 2025 (remaining nine months) | $ | 2,109 |  |
| Fiscal 2026 | 2,416 |  |
| Fiscal 2027 | 1,529 |  |
| Fiscal 2028 | 522 |  |
| Fiscal 2029 and beyond | 226 |  |
| Total undiscounted cash flows | 6,802 |  |
| Fixed-term loans | 4,740 |  |
| Revolving loans | 163 |  |
| Less: Unearned income | (1,072) |  |
| Total customer receivables, gross | $ | 10,633 |  |
  (was, 2023-12-08, similarity 0.6804):
[0001571996-23-000046:note_history:29]
|  | November 3, 2023 |
|  | (in millions) |
| Fiscal 2024 (remaining three months) | $ | 330 |  |
| Fiscal 2025 | 974 |  |
| Fiscal 2026 | 628 |  |
| Fiscal 2027 | 272 |  |
| Fiscal 2028 and beyond | 113 |  |
| Total | $ | 2,317 |  |

- changed (2024-06-11):
[0001571996-24-000062:note_history:30]
|  | May 3, 2024 |  | February 2, 2024 |
|  | (in millions) |
| Equipment under operating lease, gross | $ | 3,951 |  |  | $ | 4,002 |  |
| Less: Accumulated depreciation | (1,827) |  |  | (1,800) |  |
| Equipment under operating lease, net | $ | 2,124 |  |  | $ | 2,202 |  |
  (was, 2023-12-08, similarity 0.9764):
[0001571996-23-000046:note_history:30]
|  | November 3, 2023 |  | February 3, 2023 |
|  | (in millions) |
| Equipment under operating lease, gross | $ | 3,855 |  |  | $ | 3,725 |  |
| Less: Accumulated depreciation | (1,721) |  |  | (1,517) |  |
| Equipment under operating lease, net | $ | 2,134 |  |  | $ | 2,208 |  |

- added (2024-06-11):
[0001571996-24-000062:note_history:31]
|  |  |  | Three Months Ended |
|  |  |  |  |  | May 3, 2024 |  | May 5, 2023 |  |  |
|  |  |  |  |  | (in millions) |
| Income related to lease payments |  |  |  |  | $ | 356 |  |  | $ | 321 |  |  |  |
| Depreciation expense |  |  |  |  | $ | 240 |  |  | $ | 233 |  |  |  |

- added (2024-06-11):
[0001571996-24-000062:note_history:32]
|  | May 3, 2024 |
|  | (in millions) |
| Fiscal 2025 (remaining nine months) | $ | 852 |  |
| Fiscal 2026 | 819 |  |
| Fiscal 2027 | 443 |  |
| Fiscal 2028 | 169 |  |
| Fiscal 2029 and beyond | 60 |  |
| Total | $ | 2,343 |  |

- added (2024-06-11):
[0001571996-24-000062:note_history:33]
|  | May 3, 2024 |  | February 2, 2024 |
| DFS debt | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing facility | $ | 2,331 |  |  | $ | 2,730 |  |
| Fixed-term securitization offerings | 3,305 |  |  | 3,157 |  |
| Other | 26 |  |  | 28 |  |
| Total DFS U.S. debt, principal amount | 5,662 |  |  | 5,915 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 720 |  |  | 761 |  |
| Other borrowings | 797 |  |  | 935 |  |
| Note payable | 250 |  |  | 250 |  |
| Dell Bank senior unsecured eurobonds | 1,609 |  |  | 1,631 |  |
| Total DFS international debt, principal amount | 3,376 |  |  | 3,577 |  |
| Total DFS debt, principal amount | $ | 9,038 |  |  | $ | 9,492 |  |
| Total short-term DFS debt | $ | 5,038 |  |  | $ | 5,863 |  |
| Total long-term DFS debt | $ | 4,000 |  |  | $ | 3,629 |  |

- added (2024-06-11):
[0001571996-24-000062:note_history:34]
Asset-Based Financing Facility — During the three months ended May 3, 2024, the Company consolidated its two separate asset-based financing facilities into a single asset-based financing facility in the United States, which is a revolving facility for fixed-term leases and loans.  This debt is collateralized solely by the U.S. loan and lease payments and associated equipment in the facility.   The asset-based financing facility consists of two tranches, with effective dates through July 7, 2025 and July 7, 2026.  As of May 3, 2024, the total debt capacity related to the asset-based financing facility was $5.0 billion.  The debt has a variable interest rate, and the duration of the debt is based on the terms of the underlying loan and lease payment streams.  The Company enters into interest swap agreements to effectively convert a portion of this debt from a floating rate to a fixed rate.  See Note 7 of the Notes to the Condensed Consolidated Financial Statements for additional information about the Company’s interest rate swaps.

- changed (2024-06-11):
[0001571996-24-000062:note_history:35]
The asset-based financing facility contains standard structural features related to the performance of the funded receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the facility, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of May 3, 2024, these criteria were met.
  (was, 2023-12-08, similarity 0.8578):
[0001571996-23-000046:note_history:35]
The Company’s two U.S. asset-based financing facilities for fixed-term leases and loans are effective through July 7, 2025 and June 21, 2024, respectively.  The asset-based financing facilities contain standard structural features related to the performance of the funded receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the facility, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of November 3, 2023, these criteria were met.

- changed (2024-06-11):
[0001571996-24-000062:note_history:36]
Fixed-Term Securitization Offerings — The Company periodically issues asset-backed debt securities under fixed-term securitization programs to private investors.  The asset-backed debt securities are collateralized solely by the U.S. fixed-term lease and loan payments and associated equipment, which are held by Special Purpose Entities (“SPEs”), as discussed below.  The interest rate on these securities is fixed and ranged from 2.49% to 6.80% per annum as of May 3, 2024, and the duration of these securities is based on the terms of the underlying lease and loan payment streams.
  (was, 2023-12-08, similarity 0.9887):
[0001571996-23-000046:note_history:36]
Fixed-Term Securitization Offerings — The Company periodically issues asset-backed debt securities under fixed-term securitization programs to private investors.  The asset-backed debt securities are collateralized solely by the U.S. fixed-term lease and loan payments and associated equipment, which are held by Special Purpose Entities (“SPEs”), as discussed below.  The interest rate on these securities is fixed and ranges from 0.53% to 6.80% per annum as of November 3, 2023, and the duration of these securities is based on the terms of the underlying lease and loan payment streams.

- changed (2024-06-11):
[0001571996-24-000062:note_history:37]
Securitization Facility — The Company maintains a securitization facility in Europe for fixed-term leases and loans.  The debt under this facility has a variable interest rate, and the duration of the debt is based on the terms of the underlying loan and lease payment streams.  This facility is effective through December 23, 2024 and had a total debt capacity of $858 million as of May 3, 2024.
  (was, 2023-12-08, similarity 0.9753):
[0001571996-23-000046:note_history:37]
Securitization Facility — The Company maintains a securitization facility in Europe for fixed-term leases and loans.  The debt under this facility has a variable interest rate, and the duration of the debt is based on the terms of the underlying loan and lease payment streams.  This facility is effective through December 23, 2024 and had a total debt capacity of $850 million as of November 3, 2023.

- changed (2024-06-11):
[0001571996-24-000062:note_history:38]
The securitization facility contains standard structural features related to the performance of the securitized receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the program, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of May 3, 2024, these criteria were met.
  (was, 2023-12-08, similarity 0.9897):
[0001571996-23-000046:note_history:38]
The securitization facility contains standard structural features related to the performance of the securitized receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the program, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of November 3, 2023, these criteria were met.

- changed (2024-06-11):
[0001571996-24-000062:note_history:39]
Other Borrowings — In connection with the Company’s international financing operations, the Company has entered into revolving structured financing debt programs related to its fixed-term lease and loan products sold in Canada, Europe, Australia, New Zealand, and the Middle East.  The debt under these programs has a variable interest rate, and the duration of the debt is based on the terms of the underlying loan and lease payment streams.  The Canadian facility, which is collateralized solely by Canadian loan and lease payments and associated equipment, had a total debt capacity of $329 million as of May 3, 2024 and is effective through January 16, 2025.  The European facility, which is collateralized solely by European loan and lease payments and associated equipment, had a total debt capacity of $536 million as of May 3, 2024 and is effective through June 14, 2025.  The Australia and New Zealand facility, which is collateralized solely by Australia and New Zealand loan and lease payments and associated equipment, had a total debt capacity of $295 million as of May 3, 2024 and is effective through April 20, 2025.  The Middle East facility, which is collateralized solely by Middle East loan and lease payments and associated equipment, had a total debt capacity of $150 million as of May 3, 2024 and is effective through March 24, 2025.
  (was, 2023-12-08, similarity 0.9253):
[0001571996-23-000046:note_history:39]
Other Borrowings — In connection with the Company’s international financing operations, the Company has entered into revolving structured financing debt programs related to its fixed-term lease and loan products sold in Canada, Europe, Australia, New Zealand, and the Middle East.  The debt under these programs has a variable interest rate, and the duration of the debt is based on the terms of the underlying loan and lease payment streams.  The Canadian facility, which is collateralized solely by Canadian loan and lease payments and associated equipment, had a total debt capacity of $328 million as of November 3, 2023 and is effective through January 16, 2025.  The European facility, which is collateralized solely by European loan and lease payments and associated equipment, had a total debt capacity of $531 million as of November 3, 2023 and is effective through June 14, 2025.  The Australia and New Zealand facility, which is collateralized solely by Australia and New Zealand loan and lease payments and associated equipment, had a total debt capacity of $290 million as of November 3, 2023 and is effective through April 20, 2025. The Middle East facility, which is collateralized solely by Middle East loan and lease payments and associated equipment, had a total debt capacity of $150 million as of November 3, 2023 and is effective through March 24, 2025.

- changed (2024-06-11):
[0001571996-24-000062:note_history:40]
Note Payable — On May 25, 2022, the Company entered into an unsecured credit agreement to fund receivables in Mexico.  As of May 3, 2024, the aggregate principal amount of the note payable was $250 million.  The note bore interest at an annual rate of 4.24% and matured and was paid in full on May 31, 2024.
  (was, 2023-12-08, similarity 0.8613):
[0001571996-23-000046:note_history:40]
Note Payable — On May 25, 2022, the Company entered into an unsecured credit agreement to fund receivables in Mexico.  As of November 3, 2023, the aggregate principal amount of the note payable was $250 million.  The note bears interest at an annual rate of 4.24% and will mature on May 31, 2024.

- added (2024-06-11):
[0001571996-24-000062:note_history:41]
In connection with the asset-based financing facility, securitization facility, and fixed-term securitization offerings discussed above, the Company transfers certain U.S. and European lease and loan payments and associated equipment to SPEs that meet the definition of a VIE and are consolidated, along with the associated debt described above, into the Condensed Consolidated Financial Statements, as the Company is the primary beneficiary of the VIEs.  The SPEs are bankruptcy-remote legal entities with separate assets and liabilities.  The purpose of the SPEs is to facilitate the funding of customer loan and lease payments and associated equipment in the capital markets.

- changed (2024-06-11):
[0001571996-24-000062:note_history:42]
|  | May 3, 2024 |  | February 2, 2024 |
|  | (in millions) |
| Assets held by consolidated VIEs |  |  |  |
| Other current assets | $ | 124 |  |  | $ | 136 |  |
| Financing receivables, net of allowance |  |  |  |
| Short-term | $ | 3,140 |  |  | $ | 3,314 |  |
| Long-term | $ | 2,752 |  |  | $ | 2,747 |  |
| Property, plant, and equipment, net | $ | 1,031 |  |  | $ | 1,081 |  |
| Liabilities held by consolidated VIEs |  |  |  |
| Debt, net of unamortized debt issuance costs |  |  |  |
| Short-term | $ | 3,553 |  |  | $ | 4,450 |  |
| Long-term | $ | 2,804 |  |  | $ | 2,184 |  |
  (was, 2023-12-08, similarity 0.9891):
[0001571996-23-000046:note_history:42]
|  | November 3, 2023 |  | February 3, 2023 |
|  | (in millions) |
| Assets held by consolidated VIEs |  |  |  |
| Other current assets | $ | 146 |  |  | $ | 274 |  |
| Financing receivables, net of allowance |  |  |  |
| Short-term | $ | 3,059 |  |  | $ | 3,702 |  |
| Long-term | $ | 3,261 |  |  | $ | 3,295 |  |
| Property, plant, and equipment, net | $ | 1,097 |  |  | $ | 1,164 |  |
| Liabilities held by consolidated VIEs |  |  |  |
| Debt, net of unamortized debt issuance costs |  |  |  |
| Short-term | $ | 4,138 |  |  | $ | 4,761 |  |
| Long-term | $ | 2,753 |  |  | $ | 2,685 |  |

- changed (2024-06-11):
[0001571996-24-000062:note_history:43]
Lease and loan payments and associated equipment transferred via securitization through SPEs were $0.8 billion and $1.5 billion for the three months ended May 3, 2024 and May 5, 2023, respectively.
  (was, 2023-12-08, similarity 0.7143):
[0001571996-23-000046:note_history:43]
Lease and loan payments and associated equipment transferred via securitization through SPEs were $1.1 billion and $1.6 billion for the three months ended November 3, 2023 and October 28, 2022, respectively, and $3.7 billion and $4.5 billion for the nine months ended November 3, 2023 and October 28, 2022, respectively.

- changed (2024-06-11):
[0001571996-24-000062:note_history:44]
Customer Receivables Sales
  (was, 2023-12-08, similarity 0.9804):
[0001571996-23-000046:note_history:44]
Customer Receivable Sales

- changed (2024-06-11):
[0001571996-24-000062:note_history:45]
To manage certain concentrations of customer credit exposure, the Company may sell selected fixed-term customer receivables to unrelated third parties on a periodic basis, without recourse.  The amount of customer receivables sold for this purpose was $67 million and $169 million for the three months ended May 3, 2024 and May 5, 2023, respectively.  The Company’s continuing involvement in these customer receivables is primarily limited to servicing arrangements.
  (was, 2023-12-08, similarity 0.9167):
[0001571996-23-000046:note_history:45]
To manage certain concentrations of customer credit exposure, the Company may sell selected fixed-term customer receivables to unrelated third parties on a periodic basis, without recourse.  The amount of customer receivables sold for this purpose was $205 million and $431 million for the nine months ended November 3, 2023 and October 28, 2022, respectively.  The Company’s continuing involvement in these customer receivables is primarily limited to servicing arrangements.

- removed (2024-06-11):
[0001571996-23-000046:note_history:46]
Revolving loans — Revolving loans offered under a private label credit financing program,  referred to as Dell Business Credit (“DBC”), provide qualified customers with a revolving credit line for the purchase of products and services offered by Dell Technologies.  The DBC product is primarily offered to small and medium-sized commercial customers.  Revolving loans in the United States bear interest at a variable annual percentage rate that is tied to the prime rate.  Based on historical payment patterns, revolving loan transactions are typically repaid within twelve months on average.  Due to the short-term nature of the revolving loan portfolio, the carrying value of the portfolio approximates fair value.

- removed (2024-06-11):
[0001571996-23-000046:note_history:47]
Prior to the sale of the U.S. consumer revolving customer receivables portfolio described in Note 1 of the Notes to the Condensed Consolidated Financial Statements, the Company also offered private label credit financing under the Dell Preferred Account (“DPA”) program.  The DPA product was primarily offered to individual consumer customers.

- removed (2024-06-11):
[0001571996-23-000046:note_history:48]
(b)    The decrease in revolving customer financing receivables is primarily attributable to the sale of the U.S. consumer revolving customer receivables portfolio described in Note 1 of the Notes to the Condensed Consolidated Financial Statements.

- removed (2024-06-11):
[0001571996-23-000046:note_history:49]
|  | Three Months Ended |
|  | November 3, 2023 |  | October 28, 2022 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |  |  |  |  |  |  |  |  |  |  |  |
| Balances at beginning of period | $ | 9 |  |  | $ | 140 |  |  | $ | 149 |  |  | $ | 91 |  |  | $ | 92 |  |  | $ | 183 |  |
| Charge-offs, net of recoveries | (4) |  |  | (3) |  |  | (7) |  |  | (12) |  |  | (1) |  |  | (13) |  |
| Provision charged to income statement | 4 |  |  | 7 |  |  | 11 |  |  | 8 |  |  | 8 |  |  | 16 |  |
| Balances at end of period | $ | 9 |  |  | $ | 144 |  |  | $ | 153 |  |  | $ | 87 |  |  | $ | 99 |  |  | $ | 186 |  |

- removed (2024-06-11):
[0001571996-23-000046:note_history:50]
|  | Nine Months Ended |
|  | November 3, 2023 |  | October 28, 2022 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |  |  |  |  |  |  |  |  |  |  |  |
| Balances at beginning of period | $ | 88 |  |  | $ | 113 |  |  | $ | 201 |  |  | $ | 102 |  |  | $ | 87 |  |  | $ | 189 |  |
| Charge-offs, net of recoveries | (37) |  |  | (5) |  |  | (42) |  |  | (37) |  |  | (5) |  |  | (42) |  |
| Provision charged to income statement | 32 |  |  | 36 |  |  | 68 |  |  | 22 |  |  | 17 |  |  | 39 |  |
| Other (a) | (74) |  |  | — |  |  | (74) |  |  | — |  |  | — |  |  | — |  |
| Balances at end of period | $ | 9 |  |  | $ | 144 |  |  | $ | 153 |  |  | $ | 87 |  |  | $ | 99 |  |  | $ | 186 |  |

- removed (2024-06-11):
[0001571996-23-000046:note_history:51]
____________________

- removed (2024-06-11):
[0001571996-23-000046:note_history:52]
(a)    Other represents the derecognition of the allowance for financing receivable losses related to the sale of the U.S. consumer revolving customer receivables portfolio described in Note 1 of the Notes to the Condensed Consolidated Financial Statements.

- removed (2024-06-11):
[0001571996-23-000046:note_history:53]
|  | November 3, 2023 |  | February 3, 2023 |
|  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |
|  | (in millions) |
| Revolving — DPA | $ | 5 |  |  | $ | — |  |  | $ | — |  |  | $ | 5 |  |  | $ | 457 |  |  | $ | 34 |  |  | $ | 17 |  |  | $ | 508 |  |
| Revolving — DBC | 146 |  |  | 17 |  |  | 4 |  |  | 167 |  |  | 154 |  |  | 19 |  |  | 4 |  |  | 177 |  |
| Fixed-term — Consumer and Commercial | 9,140 |  |  | 868 |  |  | 136 |  |  | 10,144 |  |  | 9,309 |  |  | 927 |  |  | 57 |  |  | 10,293 |  |
| Total customer receivables, gross | $ | 9,291 |  |  | $ | 885 |  |  | $ | 140 |  |  | $ | 10,316 |  |  | $ | 9,920 |  |  | $ | 980 |  |  | $ | 78 |  |  | $ | 10,978 |  |

- removed (2024-06-11):
[0001571996-23-000046:note_history:54]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 3, 2023 |  | October 28, 2022 |  | November 3, 2023 |  | October 28, 2022 |
|  | (in millions) |
| Net revenue — products | $ | 227 |  |  | $ | 207 |  |  | $ | 766 |  |  | $ | 646 |  |
| Cost of net revenue — products | 176 |  |  | 164 |  |  | 564 |  |  | 532 |  |
| Gross margin — products | $ | 51 |  |  | $ | 43 |  |  | $ | 202 |  |  | $ | 114 |  |

- removed (2024-06-11):
[0001571996-23-000046:note_history:55]
|  | November 3, 2023 |
|  | (in millions) |
| Fiscal 2024 (remaining three months) | $ | 809 |  |
| Fiscal 2025 | 2,221 |  |
| Fiscal 2026 | 1,712 |  |
| Fiscal 2027 | 971 |  |
| Fiscal 2028 and beyond | 388 |  |
| Total undiscounted cash flows | 6,101 |  |
| Fixed-term loans | 4,954 |  |
| Revolving loans | 172 |  |
| Less: Unearned income | (911) |  |
| Total customer receivables, gross | $ | 10,316 |  |

- removed (2024-06-11):
[0001571996-23-000046:note_history:56]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 3, 2023 |  | October 28, 2022 |  | November 3, 2023 |  | October 28, 2022 |
|  | (in millions) |
| Income related to lease payments | $ | 341 |  |  | $ | 297 |  |  | $ | 992 |  |  | $ | 782 |  |
| Depreciation expense | $ | 234 |  |  | $ | 212 |  |  | $ | 703 |  |  | $ | 571 |  |

- removed (2024-06-11):
[0001571996-23-000046:note_history:57]
|  | November 3, 2023 |  | February 3, 2023 |
| DFS debt | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing and securitization facilities | $ | 2,443 |  |  | $ | 3,987 |  |
| Fixed-term securitization offerings | 3,715 |  |  | 2,679 |  |
| Other | 31 |  |  | 76 |  |
| Total DFS U.S. debt | 6,189 |  |  | 6,742 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 749 |  |  | 790 |  |
| Other borrowings | 839 |  |  | 871 |  |
| Note payable | 250 |  |  | 250 |  |
| Dell Bank senior unsecured eurobonds | 1,593 |  |  | 1,637 |  |
| Total DFS international debt | 3,431 |  |  | 3,548 |  |
| Total DFS debt | $ | 9,620 |  |  | $ | 10,290 |  |
| Total short-term DFS debt | $ | 5,374 |  |  | $ | 5,400 |  |
| Total long-term DFS debt | $ | 4,246 |  |  | $ | 4,890 |  |

- removed (2024-06-11):
[0001571996-23-000046:note_history:58]
Asset-Based Financing and Securitization Facilities — The Company maintains separate asset-based financing facilities in the United States, which are revolving facilities for fixed-term leases and loans.  This debt is collateralized solely by the U.S. loan and lease payments and associated equipment in the facilities.  The debt has a variable interest rate, and the duration of the debt is based on the terms of the underlying loan and lease payment streams.  As of November 3, 2023, the total debt capacity related to the U.S. asset-based financing facilities was $5.1 billion.  The Company enters into interest swap agreements to effectively convert a portion of this debt from a floating rate to a fixed rate.  See Note 7 of the Notes to the Condensed Consolidated Financial Statements for additional information about the Company’s interest rate swaps.

- removed (2024-06-11):
[0001571996-23-000046:note_history:59]
The Company previously maintained a U.S. securitization facility for revolving loans effective through June 25, 2025.  In connection with the sale of the U.S. consumer revolving customer receivables portfolio described in Note 1 of the Notes to the Condensed Consolidated Financial Statements, the Company’s U.S. securitization facility for revolving loans was paid down and terminated during the three months ended November 3, 2023.

- removed (2024-06-11):
[0001571996-23-000046:note_history:60]
In connection with the asset-based financing facilities, securitization facilities, and fixed-term securitization offerings discussed above, the Company transfers certain U.S. and European lease and loan payments and associated equipment to SPEs that meet the definition of a VIE and are consolidated, along with the associated debt described above, into the Condensed Consolidated Financial Statements as the Company is the primary beneficiary of the VIEs.  The SPEs are bankruptcy-remote legal entities with separate assets and liabilities.  The purpose of the SPEs is to facilitate the funding of customer loan and lease payments and associated equipment in the capital markets.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-06-11):
[0001571996-24-000062:note_history:61]
|  | May 3, 2024 |  | February 2, 2024 |
|  | (in millions) |
| Senior Notes | $ | 15,607 |  |  | $ | 15,607 |  |
| Legacy Notes | 952 |  |  | 952 |  |
| DFS Debt (Note 4) | 9,038 |  |  | 9,492 |  |
| Other | 108 |  |  | 171 |  |
| Total debt, principal amount | 25,705 |  |  | 26,222 |  |
| Unamortized discount, net of unamortized premium | (111) |  |  | (114) |  |
| Debt issuance costs | (114) |  |  | (114) |  |
| Total debt, carrying value | $ | 25,480 |  |  | $ | 25,994 |  |
| Total short-term debt, carrying value | $ | 6,098 |  |  | $ | 6,982 |  |
| Total long-term debt, carrying value | $ | 19,382 |  |  | $ | 19,012 |  |
  (was, 2023-12-08, similarity 0.6294):
[0001571996-23-000046:note_history:61]
|  | November 3, 2023 |  | February 3, 2023 |
|  | (in millions) |
| Senior Notes: |  |  |  |
| 5.45% due June 2023 | $ | — |  |  | $ | 1,000 |  |
| 4.00% due July 2024 | 1,000 |  |  | 1,000 |  |
| 5.85% due July 2025 | 1,000 |  |  | 1,000 |  |
| 6.02% due June 2026 | 3,500 |  |  | 4,500 |  |
| 4.90% due October 2026 | 1,750 |  |  | 1,750 |  |
| 6.10% due July 2027 | 500 |  |  | 500 |  |
| 5.25% due February 2028 | 1,000 |  |  | 1,000 |  |
| 5.30% due October 2029 | 1,750 |  |  | 1,750 |  |
| 6.20% due July 2030 | 750 |  |  | 750 |  |
| 5.75% due February 2033 | 1,000 |  |  | 1,000 |  |
| 8.10% due July 2036 | 1,000 |  |  | 1,000 |  |
| 3.38% due December 2041 | 962 |  |  | 1,000 |  |
| 8.35% due July 2046 | 800 |  |  | 800 |  |
| 3.45% due December 2051 | 1,095 |  |  | 1,250 |  |
| Legacy Notes and Debentures: |  |  |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| DFS Debt (Note 4) | 9,620 |  |  | 10,290 |  |
| Other | 181 |  |  | 325 |  |
| Total debt, principal amount | $ | 26,860 |  |  | $ | 29,867 |  |
| Unamortized discount, net of unamortized premium | (117) |  |  | (133) |  |
| Debt issuance costs | (126) |  |  | (146) |  |
| Total debt, carrying value | $ | 26,617 |  |  | $ | 29,588 |  |
| Total short-term debt, carrying value | $ | 6,498 |  |  | $ | 6,573 |  |
| Total long-term debt, carrying value | $ | 20,119 |  |  | $ | 23,015 |  |

- added (2024-06-11):
[0001571996-24-000062:note_history:62]
During the three months ended May 3, 2024, the Company issued $1.0 billion aggregate principal amount of 5.40% Senior Notes due 2034.  The Company used the net proceeds of the issuance to prepay a portion of the outstanding 6.02% Senior Notes due 2026.

- changed (2024-06-11):
[0001571996-24-000062:note_history:63]
Senior Notes — The Company completed offerings of multiple series of senior notes which were issued on June 1, 2016, June 22, 2016, March 20, 2019, April 9, 2020, December 13, 2021, January 24, 2023 and March 18, 2024 in aggregate principal amounts of $20.0 billion, $3.3 billion, $4.5 billion, $2.3 billion, $2.3 billion, $2.0 billion and $1.0 billion, respectively (the “Senior Notes”).  The Senior Notes maturities range from 2024 through 2051.  Interest rates on these borrowings are fixed, ranging from 3.38% to 8.35%, and interest is payable semiannually.
  (was, 2023-12-08, similarity 0.6109):
[0001571996-23-000046:note_history:63]
Senior Notes — The Company completed offerings of multiple series of senior notes which were issued on June 1, 2016, June 22, 2016, March 20, 2019, April 9, 2020, December 13, 2021, and January 24, 2023 in aggregate principal amounts of $20.0 billion, $3.3 billion, $4.5 billion, $2.3 billion, $2.3 billion, and $2.0 billion, respectively (the “Senior Notes”).  Interest on these borrowings is payable semiannually.

- changed (2024-06-11):
[0001571996-24-000062:note_history:64]
Legacy Notes — The Company has outstanding unsecured notes and debentures (collectively, the “Legacy Notes”) that were issued by Dell Inc. (“Dell”), a wholly-owned subsidiary of Dell Technologies Inc., prior to the acquisition of Dell by Dell Technologies Inc. in the going-private transaction that closed in October 2013.  The Legacy Notes’ maturities range from 2028 through 2040.  Interest rates on these borrowings are fixed, ranging from 5.40% to 7.10%, and interest is payable semiannually.
  (was, 2023-12-08, similarity 0.7509):
[0001571996-23-000046:note_history:64]
Legacy Notes and Debentures — The Company has outstanding unsecured notes and debentures (collectively, the “Legacy Notes and Debentures”) that were issued by Dell Inc. (“Dell”), a wholly-owned subsidiary of Dell Technologies Inc., prior to the acquisition of Dell by Dell Technologies Inc. in the going-private transaction that closed in October 2013.  Interest on these borrowings is payable semiannually.

- changed (2024-06-11):
[0001571996-24-000062:note_history:65]
Revolving Credit Facility — The Company’s revolving credit facility provides the Company with revolving commitments in an aggregate principal amount of $6.0 billion for general corporate purposes and includes a letter of credit sub-facility of up to $0.5 billion and a swing-line loan sub-facility of up to $0.5 billion.  The revolving credit facility also allows the Company to obtain incremental additional commitments on one or more occasions in minimum amounts of $10 million.
  (was, 2023-12-08, similarity 0.794):
[0001571996-23-000046:note_history:65]
2021 Revolving Credit Facility — The Company’s revolving credit facility, which was entered into on November 1, 2021 (the “2021 Revolving Credit Facility”), matures on November 1, 2027.  This facility provides the Company with revolving commitments in an aggregate principal amount of $6.0 billion for general corporate purposes, including liquidity support for the Company’s commercial paper program, and includes a letter of credit sub-facility of up to $0.5 billion and a swing-line loan sub-facility of up to $0.5 billion.  The 2021 Revolving Credit Facility also allows the Company to obtain incremental additional commitments on one or more occasions in minimum amounts of $10 million.

- changed (2024-06-11):
[0001571996-24-000062:note_history:66]
Borrowings under the revolving credit facility bear interest at a rate per annum equal to an applicable margin plus, at the borrowers’ option, either (a) the specified adjusted term Secured Overnight Financing Rate (“SOFR”) or (b) a base rate.  The margin applicable to SOFR and base rate borrowings varies based upon the Company’s existing credit ratings.  The base rate is calculated based upon the greatest of the specified prime rate, the specified federal reserve bank rate, or SOFR plus 1%.  The borrowers may voluntarily repay outstanding loans at any time without premium or penalty, other than customary breakage costs.  The facility matures on November 1, 2027.
  (was, 2023-12-08, similarity 0.942):
[0001571996-23-000046:note_history:66]
Borrowings under the 2021 Revolving Credit Facility bear interest at a rate per annum equal to an applicable margin plus, at the borrowers’ option, either (a) the specified adjusted term Secured Overnight Financing Rate (“SOFR”) or (b) a base rate.  The margin applicable to SOFR and base rate borrowings varies based upon the Company’s existing credit ratings.  The base rate is calculated based upon the greatest of the specified prime rate, the specified federal reserve bank rate, or SOFR plus 1%.  The borrowers may voluntarily repay outstanding loans under the 2021 Revolving Credit Facility at any time without premium or penalty, other than customary breakage costs.

- changed (2024-06-11):
[0001571996-24-000062:note_history:67]
As of May 3, 2024, the Company had no outstanding borrowings under the revolving credit facility.
  (was, 2023-12-08, similarity 0.9424):
[0001571996-23-000046:note_history:67]
As of November 3, 2023, the Company had no outstanding borrowings under the 2021 Revolving Credit Facility.

- changed (2024-06-11):
[0001571996-24-000062:note_history:68]
Commercial Paper Program — The Company maintains a commercial paper program under which the Company may issue unsecured notes in a maximum aggregate face amount of $5.0 billion outstanding at any time, with maturities up to 397 days from the date of issuance.  The notes are sold on customary terms in the U.S. commercial paper market on a private placement basis.  The proceeds of the notes are used for general corporate purposes.  As of May 3, 2024, the Company had no outstanding issuances under the commercial paper program.
  (was, 2023-12-08, similarity 0.9168):
[0001571996-23-000046:note_history:68]
Commercial Paper Program — During Fiscal 2023, the Company established a commercial paper program under which the Company may issue unsecured notes in a maximum aggregate face amount of $5.0 billion outstanding at any time, with maturities up to 397 days from the date of issuance.  The notes are sold on customary terms in the U.S. commercial paper market on a private placement basis.  The proceeds of the notes are used for general corporate purposes.  As of November 3, 2023, the Company had no outstanding borrowings under the commercial paper program.

- changed (2024-06-11):
[0001571996-24-000062:note_history:69]
Covenants — The credit agreement governing the revolving credit facility and the indentures governing the Senior Notes and the Legacy Notes impose various limitations, subject to exceptions, on creating certain liens and entering into sale and lease-back transactions.  The foregoing credit agreement and indentures contain customary events of default, and the revolving credit facility is subject to an interest coverage ratio covenant that is tested at the end of each fiscal quarter with respect to the Company’s preceding four fiscal quarters.  The Company was in compliance with this financial covenant as of May 3, 2024.
  (was, 2023-12-08, similarity 0.6955):
[0001571996-23-000046:note_history:69]
Covenants — The credit agreement governing the 2021 Revolving Credit Facility and the indentures governing the Senior Notes and the Legacy Notes and Debentures impose various limitations, subject to exceptions, on creating certain liens and entering into sale and lease-back transactions.  The foregoing credit agreement and indentures contain customary events of default, including failure to make required payments, failure to comply with covenants, and the occurrence of certain events of bankruptcy and insolvency.  The 2021 Revolving Credit Facility is also subject to an interest coverage ratio covenant that is tested at the end of each fiscal quarter with respect to the Company’s preceding four fiscal quarters.  The Company was in compliance with this financial covenant as of November 3, 2023.

- changed (2024-06-11):
[0001571996-24-000062:note_history:70]
The following table presents the aggregate future maturities of the Company’s debt as of May 3, 2024, excluding associated carrying value adjustments, for the periods indicated:
  (was, 2023-12-08, similarity 0.8067):
[0001571996-23-000046:note_history:70]
The following table presents the aggregate future maturities of the Company’s debt as of November 3, 2023 for the periods indicated:

- added (2024-06-11):
[0001571996-24-000062:note_history:71]
|  | May 3, 2024 |
|  | (in millions) |
| Fiscal 2025 (remaining nine months) | $ | 5,248 |  |
| Fiscal 2026 | 3,867 |  |
| Fiscal 2027 | 5,560 |  |
| Fiscal 2028 | 1,194 |  |
| Fiscal 2029 | 1,327 |  |
| Thereafter | 8,509 |  |
| Total maturities, principal amount | $ | 25,705 |  |

- removed (2024-06-11):
[0001571996-23-000046:note_history:72]
During the nine months ended November 3, 2023, the net decrease in the Company’s debt balance was principally attributable to:

- removed (2024-06-11):
[0001571996-23-000046:note_history:73]
•the repayment of $1 billion principal amount of the 5.45% Senior Notes due June 2023; and

- removed (2024-06-11):
[0001571996-23-000046:note_history:74]
•the repayment of $1 billion principal amount of the 6.02% Senior Notes due June 2026 in a tender offer, in connection with which the Company recognized an immaterial amount of debt extinguishment costs in interest and other, net in the Condensed Consolidated Statement of Income.

- removed (2024-06-11):
[0001571996-23-000046:note_history:75]
|  | Maturities by Fiscal Year |
|  | 2024 (remaining three months) |  | 2025 |  | 2026 |  | 2027 |  | 2028 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Notes | $ | — |  |  | $ | 1,000 |  |  | $ | 1,000 |  |  | $ | 5,250 |  |  | $ | 500 |  |  | $ | 8,357 |  |  | $ | 16,107 |  |
| Legacy Notes and Debentures | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 952 |  |  | 952 |  |
| DFS Debt | 1,479 |  |  | 4,807 |  |  | 1,833 |  |  | 884 |  |  | 610 |  |  | 7 |  |  | 9,620 |  |
| Other | 13 |  |  | 124 |  |  | 29 |  |  | 8 |  |  | 6 |  |  | 1 |  |  | 181 |  |
| Total maturities, principal amount | 1,492 |  |  | 5,931 |  |  | 2,862 |  |  | 6,142 |  |  | 1,116 |  |  | 9,317 |  |  | 26,860 |  |
| Associated carrying value adjustments | (2) |  |  | (7) |  |  | (6) |  |  | (33) |  |  | (8) |  |  | (187) |  |  | (243) |  |
| Total maturities, carrying value amount | $ | 1,490 |  |  | $ | 5,924 |  |  | $ | 2,856 |  |  | $ | 6,109 |  |  | $ | 1,108 |  |  | $ | 9,130 |  |  | $ | 26,617 |  |


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-06-11):
[0001571996-24-000062:note_history:76]
|  | May 3, 2024 |  | February 2, 2024 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Notes | $ | 15.5 |  |  | $ | 15.5 |  |  | $ | 15.5 |  |  | $ | 15.8 |  |
| Legacy Notes | $ | 0.9 |  |  | $ | 1.0 |  |  | $ | 0.9 |  |  | $ | 1.0 |  |
| DFS Debt | $ | 9.0 |  |  | $ | 8.6 |  |  | $ | 9.5 |  |  | $ | 9.1 |  |
  (was, 2023-12-08, similarity 0.9619):
[0001571996-23-000046:note_history:76]
|  | November 3, 2023 |  | February 3, 2023 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Notes | $ | 16.0 |  |  | $ | 15.6 |  |  | $ | 18.1 |  |  | $ | 18.2 |  |
| Legacy Notes and Debentures | $ | 0.9 |  |  | $ | 0.9 |  |  | $ | 0.9 |  |  | $ | 1.0 |  |
| DFS Debt | $ | 9.6 |  |  | $ | 9.1 |  |  | $ | 10.3 |  |  | $ | 9.9 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2024-06-11):
[0001571996-24-000062:note_history:77]
|  | May 3, 2024 |  | February 2, 2024 |
| DFS debt | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing facility | $ | 2,331 |  |  | $ | 2,730 |  |
| Fixed-term securitization offerings | 3,305 |  |  | 3,157 |  |
| Other | 26 |  |  | 28 |  |
| Total DFS U.S. debt, principal amount | 5,662 |  |  | 5,915 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 720 |  |  | 761 |  |
| Other borrowings | 797 |  |  | 935 |  |
| Note payable | 250 |  |  | 250 |  |
| Dell Bank senior unsecured eurobonds | 1,609 |  |  | 1,631 |  |
| Total DFS international debt, principal amount | 3,376 |  |  | 3,577 |  |
| Total DFS debt, principal amount | $ | 9,038 |  |  | $ | 9,492 |  |
| Total short-term DFS debt | $ | 5,038 |  |  | $ | 5,863 |  |
| Total long-term DFS debt | $ | 4,000 |  |  | $ | 3,629 |  |

- changed (2024-06-11):
[0001571996-24-000062:note_history:78]
|  | May 3, 2024 |  | February 2, 2024 |
|  | (in millions) |
| Senior Notes | $ | 15,607 |  |  | $ | 15,607 |  |
| Legacy Notes | 952 |  |  | 952 |  |
| DFS Debt (Note 4) | 9,038 |  |  | 9,492 |  |
| Other | 108 |  |  | 171 |  |
| Total debt, principal amount | 25,705 |  |  | 26,222 |  |
| Unamortized discount, net of unamortized premium | (111) |  |  | (114) |  |
| Debt issuance costs | (114) |  |  | (114) |  |
| Total debt, carrying value | $ | 25,480 |  |  | $ | 25,994 |  |
| Total short-term debt, carrying value | $ | 6,098 |  |  | $ | 6,982 |  |
| Total long-term debt, carrying value | $ | 19,382 |  |  | $ | 19,012 |  |
  (was, 2023-12-08, similarity 0.6294):
[0001571996-23-000046:note_history:78]
|  | November 3, 2023 |  | February 3, 2023 |
|  | (in millions) |
| Senior Notes: |  |  |  |
| 5.45% due June 2023 | $ | — |  |  | $ | 1,000 |  |
| 4.00% due July 2024 | 1,000 |  |  | 1,000 |  |
| 5.85% due July 2025 | 1,000 |  |  | 1,000 |  |
| 6.02% due June 2026 | 3,500 |  |  | 4,500 |  |
| 4.90% due October 2026 | 1,750 |  |  | 1,750 |  |
| 6.10% due July 2027 | 500 |  |  | 500 |  |
| 5.25% due February 2028 | 1,000 |  |  | 1,000 |  |
| 5.30% due October 2029 | 1,750 |  |  | 1,750 |  |
| 6.20% due July 2030 | 750 |  |  | 750 |  |
| 5.75% due February 2033 | 1,000 |  |  | 1,000 |  |
| 8.10% due July 2036 | 1,000 |  |  | 1,000 |  |
| 3.38% due December 2041 | 962 |  |  | 1,000 |  |
| 8.35% due July 2046 | 800 |  |  | 800 |  |
| 3.45% due December 2051 | 1,095 |  |  | 1,250 |  |
| Legacy Notes and Debentures: |  |  |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| DFS Debt (Note 4) | 9,620 |  |  | 10,290 |  |
| Other | 181 |  |  | 325 |  |
| Total debt, principal amount | $ | 26,860 |  |  | $ | 29,867 |  |
| Unamortized discount, net of unamortized premium | (117) |  |  | (133) |  |
| Debt issuance costs | (126) |  |  | (146) |  |
| Total debt, carrying value | $ | 26,617 |  |  | $ | 29,588 |  |
| Total short-term debt, carrying value | $ | 6,498 |  |  | $ | 6,573 |  |
| Total long-term debt, carrying value | $ | 20,119 |  |  | $ | 23,015 |  |

- removed (2024-06-11):
[0001571996-23-000046:note_history:79]
|  | November 3, 2023 |  | February 3, 2023 |
| DFS debt | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing and securitization facilities | $ | 2,443 |  |  | $ | 3,987 |  |
| Fixed-term securitization offerings | 3,715 |  |  | 2,679 |  |
| Other | 31 |  |  | 76 |  |
| Total DFS U.S. debt | 6,189 |  |  | 6,742 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 749 |  |  | 790 |  |
| Other borrowings | 839 |  |  | 871 |  |
| Note payable | 250 |  |  | 250 |  |
| Dell Bank senior unsecured eurobonds | 1,593 |  |  | 1,637 |  |
| Total DFS international debt | 3,431 |  |  | 3,548 |  |
| Total DFS debt | $ | 9,620 |  |  | $ | 10,290 |  |
| Total short-term DFS debt | $ | 5,374 |  |  | $ | 5,400 |  |
| Total long-term DFS debt | $ | 4,246 |  |  | $ | 4,890 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-06-11):
[0001571996-24-000062:note_history:80]
The following table presents the aggregate future maturities of the Company’s debt as of May 3, 2024, excluding associated carrying value adjustments, for the periods indicated:
  (was, 2023-12-08, similarity 0.8067):
[0001571996-23-000046:note_history:80]
The following table presents the aggregate future maturities of the Company’s debt as of November 3, 2023 for the periods indicated:

- added (2024-06-11):
[0001571996-24-000062:note_history:81]
|  | May 3, 2024 |
|  | (in millions) |
| Fiscal 2025 (remaining nine months) | $ | 5,248 |  |
| Fiscal 2026 | 3,867 |  |
| Fiscal 2027 | 5,560 |  |
| Fiscal 2028 | 1,194 |  |
| Fiscal 2029 | 1,327 |  |
| Thereafter | 8,509 |  |
| Total maturities, principal amount | $ | 25,705 |  |

- removed (2024-06-11):
[0001571996-23-000046:note_history:82]
|  | Maturities by Fiscal Year |
|  | 2024 (remaining three months) |  | 2025 |  | 2026 |  | 2027 |  | 2028 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Notes | $ | — |  |  | $ | 1,000 |  |  | $ | 1,000 |  |  | $ | 5,250 |  |  | $ | 500 |  |  | $ | 8,357 |  |  | $ | 16,107 |  |
| Legacy Notes and Debentures | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 952 |  |  | 952 |  |
| DFS Debt | 1,479 |  |  | 4,807 |  |  | 1,833 |  |  | 884 |  |  | 610 |  |  | 7 |  |  | 9,620 |  |
| Other | 13 |  |  | 124 |  |  | 29 |  |  | 8 |  |  | 6 |  |  | 1 |  |  | 181 |  |
| Total maturities, principal amount | 1,492 |  |  | 5,931 |  |  | 2,862 |  |  | 6,142 |  |  | 1,116 |  |  | 9,317 |  |  | 26,860 |  |
| Associated carrying value adjustments | (2) |  |  | (7) |  |  | (6) |  |  | (33) |  |  | (8) |  |  | (187) |  |  | (243) |  |
| Total maturities, carrying value amount | $ | 1,490 |  |  | $ | 5,924 |  |  | $ | 2,856 |  |  | $ | 6,109 |  |  | $ | 1,108 |  |  | $ | 9,130 |  |  | $ | 26,617 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- added (2024-06-11):
[0001571996-24-000062:note_history:83]
RELATED PARTY TRANSACTIONS 
Prior to the acquisition on November 22, 2023 of VMware LLC (previously VMware, Inc. and individually and together with its consolidated subsidiaries, “VMware”) by Broadcom Inc. (“Broadcom”), VMware was considered a related party of the Company.  Upon Broadcom’s acquisition of VMware, Mr. Dell’s ownership interest in VMware and his position as Chairman of the Board of VMware terminated, and the Company determined no related party relationship exists with Broadcom or VMware effective as of November 22, 2023.  The information provided below includes a summary of related party transactions with VMware for the three months ended May 5, 2023.  The Company continues to engage in select transactions with VMware following the completion of Broadcom’s acquisition and the termination of the related party relationship.  See Note 16 of the Notes to the Consolidated Financial Statements for additional information.

- changed (2024-06-11):
[0001571996-24-000062:note_history:84]
Related Party Transactions with VMware
  (was, 2023-12-08, similarity 0.7742):
[0001571996-23-000046:note_history:84]
Transactions with VMware

- changed (2024-06-11):
[0001571996-24-000062:note_history:85]
•Dell Technologies integrated or bundled select VMware products and services with Dell Technologies’ products and sold them to end-users.  Dell Technologies also acted as a distributor, purchasing VMware’s standalone products and services for resale to end-user customers.  Where applicable, costs under these arrangements were presented net of rebates received by Dell Technologies.
  (was, 2023-12-08, similarity 0.8174):
[0001571996-23-000046:note_history:85]
•Pursuant to original equipment manufacturer and reseller arrangements, Dell Technologies integrates or bundles VMware’s products and services with Dell Technologies’ products and sells them to end-users.  Dell Technologies also acts as a distributor, purchasing VMware’s standalone products and services for resale to end-user customers.  Where applicable, costs under these arrangements are presented net of rebates received by Dell Technologies.

- changed (2024-06-11):
[0001571996-24-000062:note_history:86]
•DFS provided financing to certain VMware end-users, which resulted in the recognition of amounts due to related parties on the Condensed Consolidated Statements of Financial Position.  Associated financing fees were recorded to product net revenue on the Condensed Consolidated Statements of Income and were reflected within sales and leases of products to VMware in the table below.
  (was, 2023-12-08, similarity 0.8505):
[0001571996-23-000046:note_history:86]
•DFS provides financing to certain VMware end-users.  Upon acceptance of the financing arrangement by both VMware’s end-users and DFS, DFS recognizes amounts due to related parties on the Condensed Consolidated Statements of Financial Position.  Associated financing fees are recorded to product net revenue on the Condensed Consolidated Statements of Income and are reflected within sales and leases of products to VMware in the table below.

- changed (2024-06-11):
[0001571996-24-000062:note_history:87]
•Dell Technologies procured products and services from VMware for its internal use.  For the three months ended  May 5, 2023, costs incurred associated with products and services purchased from VMware for internal use were immaterial.
  (was, 2023-12-08, similarity 0.8337):
[0001571996-23-000046:note_history:87]
•Dell Technologies may procure products and services from VMware for its internal use.  For the three and nine months ended November 3, 2023 and October 28, 2022, costs incurred associated with products and services purchased from VMware for internal use were immaterial.

- changed (2024-06-11):
[0001571996-24-000062:note_history:88]
•Dell Technologies sold and leased products and sold services to VMware.  For the three months ended May 5, 2023,  revenue recognized from sales of services to VMware was immaterial.
  (was, 2023-12-08, similarity 0.7435):
[0001571996-23-000046:note_history:88]
•Dell Technologies sells and leases products and sells services to VMware.  For the three and nine months ended November 3, 2023 and October 28, 2022, revenue recognized from sales of services to VMware was immaterial.

- changed (2024-06-11):
[0001571996-24-000062:note_history:89]
•Dell Technologies and VMware entered into joint marketing, sales, and branding arrangements, for which both parties incurred costs.  For the three months ended May 5, 2023, consideration received from VMware for joint marketing, sales, and branding arrangements was immaterial.
  (was, 2023-12-08, similarity 0.8512):
[0001571996-23-000046:note_history:89]
•Dell Technologies and VMware also enter into joint marketing, sales, and branding arrangements, for which both parties may incur costs.  For the three and nine months ended November 3, 2023 and October 28, 2022, consideration received from VMware for joint marketing, sales, and branding arrangements was immaterial.

- changed (2024-06-11):
[0001571996-24-000062:note_history:90]
The following table presents information about the impact of Dell Technologies’ related party transactions with VMware on the Consolidated Statements of Income for the three months ended May 5, 2023:
  (was, 2023-12-08, similarity 0.9054):
[0001571996-23-000046:note_history:90]
The following table presents information about the impact of Dell Technologies’ related party transactions with VMware on the Condensed Consolidated Statements of Income for the periods indicated:

- changed (2024-06-11):
[0001571996-24-000062:note_history:91]
|  |  |  |  |  |  |  | Three Months Ended |
|  | Classification |  |  |  |  |  |  |  | May 5, 2023 |  |  |
|  |  |  |  |  |  |  |  |  | (in millions) |
| Sales and leases of products to VMware | Net revenue - products |  |  |  |  |  |  |  | $ | 40 |  |  |  |
| Purchase of VMware products for resale | Cost of net revenue - products |  |  |  |  |  |  |  | $ | 207 |  |  |  |
| Purchase of VMware services for resale | Cost of net revenue - services |  |  |  |  |  |  |  | $ | 876 |  |  |  |
  (was, 2023-12-08, similarity 0.6804):
[0001571996-23-000046:note_history:91]
|  |  |  | Three Months Ended |  | Nine Months Ended |  |  |
|  | Classification |  | November 3, 2023 |  | October 28, 2022 |  | November 3, 2023 |  | October 28, 2022 |  |  |
|  |  |  | (in millions) |
| Sales and leases of products to VMware | Net revenue - products |  | $ | 16 |  |  | $ | 49 |  |  | $ | 94 |  |  | $ | 130 |  |  |  |
| Purchase of VMware products for resale | Cost of net revenue - products |  | $ | 379 |  |  | $ | 281 |  |  | $ | 970 |  |  | $ | 962 |  |  |  |
| Purchase of VMware services for resale | Cost of net revenue - services |  | $ | 884 |  |  | $ | 733 |  |  | $ | 2,640 |  |  | $ | 2,204 |  |  |  |

- added (2024-06-11):
[0001571996-24-000062:note_history:92]
In connection with the completion of the VMware Spin-off, Dell Technologies and VMware entered into a Tax Matters Agreement effective as of April 14, 2021 (the “Tax Matters Agreement”) which governs the respective rights and obligations of Dell Technologies and VMware regarding income and other taxes as well as related matters, including tax liabilities and benefits, attributes, and returns for periods both preceding and proceeding the VMware Spin-off.  Pursuant to the Tax Matters Agreement, net receipts for VMware during the three months ended May 5, 2023 were immaterial.

- changed (2024-06-11):
[0001571996-24-000062:note_history:93]
Other Related Parties
  (was, 2023-12-08, similarity 0.6087):
[0001571996-23-000046:note_history:93]
Related Party Tax Matters

- added (2024-06-11):
[0001571996-24-000062:note_history:94]
Transactions with other related parties during the periods presented were immaterial, individually and in aggregate.

- removed (2024-06-11):
[0001571996-23-000046:note_history:95]
RELATED PARTY TRANSACTIONS 
For the periods presented within this report, VMware was considered to be a related party of the Company as a result of Michael Dell’s ownership interests in both Dell Technologies and VMware as well as Mr. Dell’s service as Chairman and Chief Executive Officer of Dell Technologies and as Chairman of the Board of VMware, Inc.

- removed (2024-06-11):
[0001571996-23-000046:note_history:96]
Subsequent to the close of the Company’s third quarter of Fiscal 2024, Broadcom Inc. completed its acquisition of VMware and terminated the preexisting related party relationship.  See Note 18 of the Notes to the Condensed Consolidated Financial Statements for more information about the impact of the transaction on the Company’s relationship with VMware.

- removed (2024-06-11):
[0001571996-23-000046:note_history:97]
The information provided below includes a summary of transactions with VMware for the periods presented.  Transactions with related parties other than VMware during the periods presented were immaterial, individually and in aggregate.

- removed (2024-06-11):
[0001571996-23-000046:note_history:98]
•Dell Technologies and VMware entered into a transition services agreement in connection with the VMware Spin-off to provide various support services, including investment advisory services, certain support services from Dell Technologies personnel, and other transitional services.  Costs associated with this agreement were immaterial for the three and nine months ended October 28, 2022.  Activities under the agreement concluded during Fiscal 2023.

- removed (2024-06-11):
[0001571996-23-000046:note_history:99]
The following table presents information about the impact of Dell Technologies’ related party transactions with VMware on the Condensed Consolidated Statements of Financial Position as of the dates indicated:

- removed (2024-06-11):
[0001571996-23-000046:note_history:100]
|  | Classification |  | November 3, 2023 |  | February 3, 2023 |
|  |  |  | (in millions) |
| Deferred costs related to VMware products and services for resale | Other current assets |  | $ | 2,926 |  |  | $ | 3,000 |  |
| Deferred costs related to VMware products and services for resale | Other non-current assets |  | $ | 2,201 |  |  | $ | 2,537 |  |

- removed (2024-06-11):
[0001571996-23-000046:note_history:101]
|  | November 3, 2023 |  | February 3, 2023 |
|  | (in millions) |
| Due from related party, net, current (a) | $ | 386 |  |  | $ | 378 |  |
| Due from related party, net, non-current (b) | $ | 239 |  |  | $ | 440 |  |
| Due to related party, current (c) | $ | 1,246 |  |  | $ | 2,067 |  |
| Due to related party, non-current (d) | $ | 11 |  |  | $ | — |  |

- removed (2024-06-11):
[0001571996-23-000046:note_history:102]
____________________

- removed (2024-06-11):
[0001571996-23-000046:note_history:103]
(a)      Amounts due from related party, net, current consisted of amounts due from VMware, inclusive of current net tax receivables from VMware under the Tax Agreements described below.  Amounts, excluding tax, are generally settled in cash within 60 days of each quarter-end.

- removed (2024-06-11):
[0001571996-23-000046:note_history:104]
(b)      Amounts due from related party, net, non-current consisted of the non-current portion of net receivables from VMware under the Tax Agreements.

- removed (2024-06-11):
[0001571996-23-000046:note_history:105]
(c)      Amounts due to related party, current included amounts due to VMware, which are generally settled in cash within 60 days of each quarter-end.

- removed (2024-06-11):
[0001571996-23-000046:note_history:106]
(d)     Amounts due to related party, non-current are included in other non-current liabilities.

- removed (2024-06-11):
[0001571996-23-000046:note_history:107]
Tax Agreements — In connection with the VMware Spin-off and concurrently with the execution of the Separation and Distribution Agreement, effective as of April 14, 2021, Dell Technologies and VMware entered into a Tax Matters Agreement (the “Tax Matters Agreement”) and agreed to terminate the tax sharing agreement as amended on December 30, 2019 (together with the Tax Matters Agreement, the “Tax Agreements”).  The Tax Matters Agreement governs Dell Technologies’ and VMware’s respective rights and obligations, both for pre-spin-off periods and post-spin-off periods, regarding income and other taxes, and related matters, including tax liabilities and benefits, attributes, and returns.

- removed (2024-06-11):
[0001571996-23-000046:note_history:108]
The timing of the tax payments due to and from related parties is governed by the Tax Agreements.  VMware’s portion of the mandatory one-time transition tax on accumulated earnings of foreign subsidiaries (the “Transition Tax”) is governed by a letter agreement between VMware and Dell Technologies entered into on April 1, 2019.

- removed (2024-06-11):
[0001571996-23-000046:note_history:109]
Pursuant to the Tax Agreements, net receipts from VMware during the nine months ended November 3, 2023 and net payments to VMware during the nine months ended October 28, 2022 were immaterial.

- removed (2024-06-11):
[0001571996-23-000046:note_history:110]
As a result of the activity under the Tax Agreements with VMware, amounts due from VMware were $484 million and $599 million as of November 3, 2023 and February 3, 2023, respectively, and primarily related to VMware’s estimated tax obligation resulting from the Transition Tax.  The 2017 Tax Cuts and Jobs Act included a deferral election for an eight-year installment payment method on the Transition Tax.  Dell Technologies expects VMware to pay the remainder of its Transition Tax over a period of two years.

- removed (2024-06-11):
[0001571996-23-000046:note_history:111]
Indemnification — Upon consummation of the VMware Spin-off, Dell Technologies recorded net income tax indemnification receivables from VMware related to certain income tax liabilities for which Dell Technologies is jointly and severally liable, but for which it is indemnified by VMware under the Tax Matters Agreement.  The amounts that VMware may be obligated to pay Dell Technologies could vary depending on the outcome of certain unresolved tax matters, which may not be resolved for several years.  The net receivable as of November 3, 2023 and February 3, 2023 was $95 million and $146 million, respectively.


## us-gaap:ScheduleOfRelatedPartyTransactionsTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2024-06-11):
[0001571996-24-000062:note_history:112]
The following table presents information about the impact of Dell Technologies’ related party transactions with VMware on the Consolidated Statements of Income for the three months ended May 5, 2023:
  (was, 2023-12-08, similarity 0.9054):
[0001571996-23-000046:note_history:112]
The following table presents information about the impact of Dell Technologies’ related party transactions with VMware on the Condensed Consolidated Statements of Income for the periods indicated:

- changed (2024-06-11):
[0001571996-24-000062:note_history:113]
|  |  |  |  |  |  |  | Three Months Ended |
|  | Classification |  |  |  |  |  |  |  | May 5, 2023 |  |  |
|  |  |  |  |  |  |  |  |  | (in millions) |
| Sales and leases of products to VMware | Net revenue - products |  |  |  |  |  |  |  | $ | 40 |  |  |  |
| Purchase of VMware products for resale | Cost of net revenue - products |  |  |  |  |  |  |  | $ | 207 |  |  |  |
| Purchase of VMware services for resale | Cost of net revenue - services |  |  |  |  |  |  |  | $ | 876 |  |  |  |
  (was, 2023-12-08, similarity 0.6804):
[0001571996-23-000046:note_history:113]
|  |  |  | Three Months Ended |  | Nine Months Ended |  |  |
|  | Classification |  | November 3, 2023 |  | October 28, 2022 |  | November 3, 2023 |  | October 28, 2022 |  |  |
|  |  |  | (in millions) |
| Sales and leases of products to VMware | Net revenue - products |  | $ | 16 |  |  | $ | 49 |  |  | $ | 94 |  |  | $ | 130 |  |  |  |
| Purchase of VMware products for resale | Cost of net revenue - products |  | $ | 379 |  |  | $ | 281 |  |  | $ | 970 |  |  | $ | 962 |  |  |  |
| Purchase of VMware services for resale | Cost of net revenue - services |  | $ | 884 |  |  | $ | 733 |  |  | $ | 2,640 |  |  | $ | 2,204 |  |  |  |

- removed (2024-06-11):
[0001571996-23-000046:note_history:114]
The following table presents information about the impact of Dell Technologies’ related party transactions with VMware on the Condensed Consolidated Statements of Financial Position as of the dates indicated:

- removed (2024-06-11):
[0001571996-23-000046:note_history:115]
|  | Classification |  | November 3, 2023 |  | February 3, 2023 |
|  |  |  | (in millions) |
| Deferred costs related to VMware products and services for resale | Other current assets |  | $ | 2,926 |  |  | $ | 3,000 |  |
| Deferred costs related to VMware products and services for resale | Other non-current assets |  | $ | 2,201 |  |  | $ | 2,537 |  |

- removed (2024-06-11):
[0001571996-23-000046:note_history:116]
|  | November 3, 2023 |  | February 3, 2023 |
|  | (in millions) |
| Due from related party, net, current (a) | $ | 386 |  |  | $ | 378 |  |
| Due from related party, net, non-current (b) | $ | 239 |  |  | $ | 440 |  |
| Due to related party, current (c) | $ | 1,246 |  |  | $ | 2,067 |  |
| Due to related party, non-current (d) | $ | 11 |  |  | $ | — |  |

- removed (2024-06-11):
[0001571996-23-000046:note_history:117]
____________________

- removed (2024-06-11):
[0001571996-23-000046:note_history:118]
(a)      Amounts due from related party, net, current consisted of amounts due from VMware, inclusive of current net tax receivables from VMware under the Tax Agreements described below.  Amounts, excluding tax, are generally settled in cash within 60 days of each quarter-end.

- removed (2024-06-11):
[0001571996-23-000046:note_history:119]
(b)      Amounts due from related party, net, non-current consisted of the non-current portion of net receivables from VMware under the Tax Agreements.

- removed (2024-06-11):
[0001571996-23-000046:note_history:120]
(c)      Amounts due to related party, current included amounts due to VMware, which are generally settled in cash within 60 days of each quarter-end.
(d)     Amounts due to related party, non-current are included in other non-current liabilities.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-06-11):
[0001571996-24-000062:note_history:121]
The following table presents the disaggregation of net revenue by reportable segment and by major product categories within the segments for the periods indicated:
  (was, 2023-12-08, similarity 0.9969):
[0001571996-23-000046:note_history:121]
The following table presents the disaggregation of net revenue by reportable segment, and by major product categories within the segments for the periods indicated:

- changed (2024-06-11):
[0001571996-24-000062:note_history:122]
|  | Three Months Ended |  |  |
|  | May 3, 2024 |  | May 5, 2023 |  |  |  |  |  |  |
|  | (in millions) |
| Net revenue: |  |  |  |  |  |  |  |  |  |
| Infrastructure Solutions Group: |  |  |  |  |  |  |  |  |  |
| Servers and networking | $ | 5,466 |  |  | $ | 3,837 |  |  |  |  |  |  |  |
| Storage | 3,761 |  |  | 3,756 |  |  |  |  |  |  |  |
| Total ISG net revenue | $ | 9,227 |  |  | $ | 7,593 |  |  |  |  |  |  |  |
| Client Solutions Group: |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 10,154 |  |  | $ | 9,862 |  |  |  |  |  |  |  |
| Consumer | 1,813 |  |  | 2,121 |  |  |  |  |  |  |  |
| Total CSG net revenue | $ | 11,967 |  |  | $ | 11,983 |  |  |  |  |  |  |  |
  (was, 2023-12-08, similarity 0.716):
[0001571996-23-000046:note_history:122]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 3, 2023 |  | October 28, 2022 |  | November 3, 2023 |  | October 28, 2022 |
|  | (in millions) |
| Net revenue: |  |  |  |  |  |  |  |
| Infrastructure Solutions Group: |  |  |  |  |  |  |  |
| Servers and networking | $ | 4,656 |  |  | $ | 5,201 |  |  | $ | 12,767 |  |  | $ | 15,458 |  |
| Storage | 3,843 |  |  | 4,429 |  |  | 11,786 |  |  | 12,993 |  |
| Total ISG net revenue | $ | 8,499 |  |  | $ | 9,630 |  |  | $ | 24,553 |  |  | $ | 28,451 |  |
| Client Solutions Group: |  |  |  |  |  |  |  |
| Commercial | $ | 9,835 |  |  | $ | 10,747 |  |  | $ | 30,251 |  |  | $ | 34,859 |  |
| Consumer | 2,441 |  |  | 3,028 |  |  | 6,950 |  |  | 9,993 |  |
| Total CSG net revenue | $ | 12,276 |  |  | $ | 13,775 |  |  | $ | 37,201 |  |  | $ | 44,852 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-06-11):
[0001571996-24-000062:note_history:123]
|  |  |  | Three Months Ended |
|  |  |  |  |  | May 3, 2024 |  | May 5, 2023 |
|  |  |  |  |  | (in millions) |
| Deferred revenue: |  |  |  |  |  |  |  |
| Deferred revenue at beginning of period |  |  |  |  | $ | 29,145 |  |  | $ | 30,286 |  |
| Revenue deferrals |  |  |  |  | 4,469 |  |  | 4,719 |  |
| Revenue recognized |  |  |  |  | (5,464) |  |  | (5,310) |  |
| Deferred revenue at end of period |  |  |  |  | $ | 28,150 |  |  | $ | 29,695 |  |
| Short-term deferred revenue |  |  |  |  | $ | 15,034 |  |  | $ | 15,527 |  |
| Long-term deferred revenue |  |  |  |  | $ | 13,116 |  |  | $ | 14,168 |  |
  (was, 2023-12-08, similarity 0.7093):
[0001571996-23-000046:note_history:123]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 3, 2023 |  | October 28, 2022 |  | November 3, 2023 |  | October 28, 2022 |
|  | (in millions) |
| Deferred revenue: |  |  |  |  |  |  |  |
| Deferred revenue at beginning of period | $ | 30,312 |  |  | $ | 28,025 |  |  | $ | 30,286 |  |  | $ | 27,573 |  |
| Revenue deferrals | 4,492 |  |  | 4,128 |  |  | 15,236 |  |  | 14,675 |  |
| Revenue recognized | (5,766) |  |  | (5,064) |  |  | (16,484) |  |  | (14,994) |  |
| Other (a) | 15 |  |  | — |  |  | 15 |  |  | (165) |  |
| Deferred revenue at end of period | $ | 29,053 |  |  | $ | 27,089 |  |  | $ | 29,053 |  |  | $ | 27,089 |  |
| Short-term deferred revenue | $ | 15,206 |  |  | $ | 14,106 |  |  | $ | 15,206 |  |  | $ | 14,106 |  |
| Long-term deferred revenue | $ | 13,847 |  |  | $ | 12,983 |  |  | $ | 13,847 |  |  | $ | 12,983 |  |

- changed (2024-06-11):
[0001571996-24-000062:note_history:124]
Remaining Performance Obligations — Remaining performance obligations represent the aggregate amount of the transaction price allocated to performance obligations not delivered, or partially undelivered, as of the end of the reporting period.  Remaining performance obligations include deferred revenue plus unbilled amounts not yet recorded in deferred revenue.  The value of the transaction price allocated to remaining performance obligations as of May 3, 2024 was approximately $39 billion.  The Company expects to recognize approximately 59% of remaining performance obligations as revenue in the next twelve months, and the remainder thereafter.
  (was, 2023-12-08, similarity 0.9915):
[0001571996-23-000046:note_history:124]
Remaining Performance Obligations — Remaining performance obligations represent the aggregate amount of the transaction price allocated to performance obligations not delivered, or partially undelivered, as of the end of the reporting period.  Remaining performance obligations include deferred revenue plus unbilled amounts not yet recorded in deferred revenue.  The value of the transaction price allocated to remaining performance obligations as of November 3, 2023 was approximately $39 billion.  The Company expects to recognize approximately 58% of remaining performance obligations as revenue in the next twelve months, and the remainder thereafter.

- removed (2024-06-11):
[0001571996-23-000046:note_history:125]
____________________

- removed (2024-06-11):
[0001571996-23-000046:note_history:126]
(a)    For the nine months ended October 28, 2022, Other represents the reclassification of deferred revenue to accrued and other liabilities.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2024-06-11):
[0001571996-24-000062:note_history:127]
SUBSEQUENT EVENTS 
There were no known events occurring after May 3, 2024, and up until the date of issuance of this report that would materially affect the information presented herein.

- removed (2024-06-11):
[0001571996-23-000046:note_history:128]
SUBSEQUENT EVENTS 
On November 22, 2023, subsequent to the close of the Company’s third quarter of Fiscal 2024, VMware was acquired by Broadcom Inc. (“Broadcom”).  Upon the completion of Broadcom’s acquisition of VMware, Mr. Dell relinquished his direct ownership interest in VMware and his position as Chairman of the Board of VMware, Inc.  Mr. Dell’s subsequent ownership interest in Broadcom does not represent control or significant influence to an extent that the transacting parties might be prevented from fully pursuing their own separate interests.  As a result, the Company determined that the acquisition terminated the preexisting related party relationship with VMware and that no related party relationship exists with either Broadcom or VMware as of the date of issuance of this report.
Other than the matter identified above, there were no known events occurring after November 3, 2023 and up until the date of issuance of this report that would materially affect the information presented herein.
