# DELL 8-K — 0001571996-24-000050 filed 2024-05-30

## item codes, every 8-K on or before 2024-06-11

- 2024-06-10 0001571996-24-000059 — 3.02
- 2024-05-30 0001571996-24-000050 — 2.02, 9.01
- 2024-03-26 0001571996-24-000038 — 3.02
- 2024-03-18 0001193125-24-070193 — 1.01, 2.03, 9.01
- 2024-03-07 0001571996-24-000012 — 3.02
- 2024-03-06 0001193125-24-059631 — 8.01, 9.01
- 2024-02-29 0001571996-24-000008 — 2.02, 9.01
- 2024-01-30 0001571996-24-000004 — 1.02
- 2024-01-18 0001571996-24-000002 — 3.02
- 2023-12-18 0001193125-23-297664 — 8.01, 9.01
- 2023-12-05 0001571996-23-000042 — 3.02
- 2023-12-04 0001193125-23-288428 — 8.01, 9.01
- 2023-11-30 0001571996-23-000039 — 2.02, 9.01
- 2023-10-05 0001193125-23-251131 — 7.01, 8.01, 9.01
- 2023-10-02 0001571996-23-000036 — 5.02 — amendment of 0001571996-23-000034
- 2023-09-26 0001571996-23-000034 — 5.02
- 2023-08-31 0001571996-23-000029 — 2.02, 9.01
- 2023-08-09 0001571996-23-000026 — 5.02 — amendment of 0001571996-23-000002
- 2023-07-28 0001571996-23-000024 — 5.02
- 2023-07-13 0001193125-23-186639 — 3.02
- 2023-06-30 0001193125-23-180570 — 8.01, 9.01
- 2023-06-22 0001571996-23-000021 — 5.02, 5.07, 9.01
- 2023-06-15 0001193125-23-167472 — 8.01, 9.01
- 2023-06-01 0001571996-23-000014 — 2.02, 9.01
- 2023-03-02 0001571996-23-000002 — 2.02, 5.02, 9.01
- 2023-02-06 0001193125-23-024781 — 7.01, 9.01
- 2023-01-24 0001193125-23-014260 — 1.01, 2.03, 9.01
- 2023-01-11 0001193125-23-006528 — 8.01, 9.01
- 2022-11-21 0001571996-22-000041 — 2.02, 9.01
- 2022-11-16 0001571996-22-000038 — 8.01
- 2022-08-25 0001571996-22-000028 — 2.02, 9.01
- 2022-07-18 0001193125-22-196334 — 2.03, 8.01
- 2022-06-29 0001571996-22-000025 — 3.03, 5.03, 5.07, 8.01, 9.01
- 2022-05-26 0001571996-22-000013 — 2.02, 9.01
- 2022-02-24 0001571996-22-000004 — 2.02, 8.01, 9.01
- 2021-12-20 0001193125-21-362482 — 8.01, 9.01
- 2021-12-15 0001193125-21-357927 — 1.01, 2.03, 9.01
- 2021-12-07 0001193125-21-349218 — 8.01, 9.01
- 2021-11-23 0001571996-21-000060 — 2.02, 9.01
- 2021-11-05 0001571996-21-000057 — 1.02, 2.01, 7.01, 8.01, 9.01 — amendment, the index does not say of what
- 2021-11-01 0001571996-21-000052 — 8.01, 9.01
- 2021-11-01 0001193125-21-315488 — 1.01, 1.02, 2.01, 8.01, 9.01
- 2021-10-21 0001193125-21-304052 — 8.01, 9.01
- 2021-10-19 0001571996-21-000050 — 8.01, 9.01
- 2021-10-07 0001193125-21-294210 — 8.01, 9.01
- 2021-09-30 0001571996-21-000047 — 5.02
- 2021-09-27 0001571996-21-000045 — 8.01
- 2021-09-23 0001193125-21-280190 — 7.01, 8.01, 9.01
- 2021-09-20 0001193125-21-276810 — 7.01, 9.01
- 2021-08-26 0001571996-21-000037 — 2.02, 9.01
- 2021-07-01 0001571996-21-000034 — 3.02
- 2021-06-24 0001571996-21-000031 — 5.07
- 2021-06-24 0001193125-21-197644 — 7.01, 9.01
- 2021-06-16 0001571996-21-000029 — 5.02
- 2021-05-27 0001571996-21-000019 — 2.02, 9.01
- 2021-05-03 0001571996-21-000010 — 8.01, 9.01
- 2021-04-14 0001193125-21-116271 — 1.01, 7.01, 9.01
- 2021-02-25 0001571996-21-000003 — 2.02, 9.01
- 2021-02-18 0001193125-21-047844 — 1.01, 2.03, 9.01
- 2020-11-24 0001571996-20-000048 — 2.02, 9.01
- 2020-08-27 0001571996-20-000041 — 2.02, 9.01
- 2020-07-02 0001571996-20-000037 — 5.07
- 2020-05-28 0001571996-20-000028 — 2.02, 9.01
- 2020-04-09 0001193125-20-102602 — 1.01, 2.03, 9.01
- 2020-04-08 0001571996-20-000021 — 5.02
- 2020-04-03 0001571996-20-000019 — 8.01, 9.01
- 2020-03-26 0001571996-20-000015 — 7.01
- 2020-02-27 0001571996-20-000009 — 2.02, 8.01, 9.01
- 2020-02-18 0001571996-20-000005 — 8.01, 9.01
- 2020-01-09 0001571996-20-000002 — 3.02
- 2020-01-06 0001193125-20-002200 — 3.02
- 2019-12-13 0001193125-19-313947 — 3.02
- 2019-12-10 0001571996-19-000052 — 5.02
- 2019-12-02 0001571996-19-000044 — 5.02, 7.01, 9.01
- 2019-11-26 0001571996-19-000042 — 2.02, 9.01
- 2019-09-23 0001193125-19-252192 — 1.01, 2.03, 9.01
- 2019-08-29 0001571996-19-000036 — 2.02, 9.01
- 2019-08-22 0001193125-19-226939 — 7.01, 8.01, 9.01
- 2019-07-11 0001571996-19-000032 — 5.02, 5.07, 9.01
- 2019-07-03 0001571996-19-000030 — 3.02
- 2019-06-27 0001571996-19-000028 — 3.02
- 2019-05-30 0001571996-19-000021 — 2.02, 9.01
- 2019-04-02 0001571996-19-000010 — 5.02
- 2019-03-21 0001193125-19-082281 — 1.01, 1.02, 2.03, 9.01
- 2019-03-19 0001571996-19-000005 — 5.02, 9.01
- 2019-03-14 0001193125-19-074935 — 1.01, 2.03, 9.01
- 2019-03-07 0001193125-19-066045 — 8.01, 9.01
- 2019-02-28 0001571996-19-000002 — 2.02, 9.01
- 2018-12-28 0001193125-18-360943 — 1.01, 1.02, 3.01, 3.03, 5.02, 5.03, 7.01, 8.01, 9.01
- 2018-12-21 0001193125-18-356324 — 1.01, 2.03, 9.01
- 2018-12-14 0001193125-18-349469 — 8.01
- 2018-12-11 0001193125-18-346958 — 5.07, 8.01, 9.01
- 2018-11-29 0001571996-18-000041 — 2.02, 9.01
- 2018-11-28 0001571996-18-000037 — 7.01, 8.01, 9.01
- 2018-11-26 0001193125-18-333967 — 8.01, 9.01
- 2018-11-15 0001193125-18-328110 — 1.01, 9.01 — amendment of 0001193125-18-327222
- 2018-11-15 0001193125-18-327222 — 1.01, 7.01, 9.01
- 2018-10-03 0001193125-18-291390 — 8.01
- 2018-09-06 0001571996-18-000029 — 2.02, 9.01
- 2018-08-06 0001571996-18-000027 — 8.01, 9.01
- 2018-07-02 0001193125-18-210339 — 1.01, 7.01, 9.01
- 2018-06-28 0001571996-18-000024 — 5.07
- 2018-06-04 0001571996-18-000019 — 2.02, 9.01
- 2018-05-17 0001571996-18-000016 — 7.01
- 2018-04-26 0001571996-18-000009 — 7.01, 9.01
- 2018-03-08 0001193125-18-074168 — 2.02, 9.01
- 2018-02-02 0001193125-18-029947 — 7.01, 9.01
- 2017-12-07 0001571996-17-000042 — 2.02, 9.01
- 2017-10-24 0001571996-17-000037 — 1.01, 2.03, 9.01
- 2017-09-15 0001571996-17-000027 — 5.02
- 2017-09-07 0001571996-17-000017 — 2.02, 9.01
- 2017-08-24 0001571996-17-000014 — 8.01
- 2017-06-29 0001571996-17-000011 — 3.03, 5.07, 8.01, 9.01
- 2017-06-08 0001193125-17-197638 — 2.02, 9.01
- 2017-03-30 0001193125-17-102794 — 8.01
- 2017-03-30 0001193125-17-102777 — 2.02, 9.01
- 2017-03-09 0001193125-17-076981 — 1.01, 2.03, 9.01
- 2017-01-17 0001193125-17-011125 — 8.01
- 2016-12-15 0001193125-16-793722 — 8.01
- 2016-12-08 0001193125-16-787976 — 2.02, 9.01
- 2016-11-10 0001193125-16-765964 — 1.02, 8.01
- 2016-11-04 0001193125-16-760249 — 8.01
- 2016-09-13 0001193125-16-708600 — 3.02
- 2016-09-09 0001193125-16-706567 — 1.01, 1.02, 2.01, 2.03, 3.02, 3.03, 5.02, 9.01
- 2016-09-07 0001193125-16-703370 — 3.03, 5.07, 7.01, 8.01, 9.01
- 2016-09-06 0001193125-16-702057 — 2.02, 9.01
- 2016-08-31 0001193125-16-697268 — 8.01, 9.01
- 2016-08-26 0001193125-16-692921 — 8.01, 9.01
- 2016-07-11 0001193125-16-645610 — 8.01
- 2016-07-05 0001193125-16-641679 — 8.01
- 2016-06-22 0001193125-16-629055 — 1.01, 2.03, 8.01, 9.01
- 2016-06-21 0001193125-16-627071 — 8.01, 9.01
- 2016-06-10 0001193125-16-618483 — 2.02, 9.01
- 2016-06-09 0001193125-16-617893 — 8.01, 9.01

## late-filing notifications on or before 2024-06-11

- none on or before 2024-06-11

## item 2.02 — earnings release, exhibit 99.1

[0001571996-24-000050:8k_2_02:1]
EX-99.1
2
exhibit991earnings8kq1fy25.htm
EX-99.1

[0001571996-24-000050:8k_2_02:2]
Document

[0001571996-24-000050:8k_2_02:3]
Exhibit 99.1

[0001571996-24-000050:8k_2_02:4]
Dell Technologies Delivers First Quarter Fiscal 2025 Financial Results

[0001571996-24-000050:8k_2_02:5]
News summary

[0001571996-24-000050:8k_2_02:6]
•First quarter revenue of $22.2 billion, up 6% year over year

[0001571996-24-000050:8k_2_02:7]
•Infrastructure Solutions Group (ISG) revenue of $9.2 billion, up 22% year over year, with record servers and networking revenue of $5.5 billion, up 42%

[0001571996-24-000050:8k_2_02:8]
•Client Solutions Group (CSG) revenue of $12.0 billion, flat year over year, with commercial client revenue at $10.2 billion, up 3%

[0001571996-24-000050:8k_2_02:9]
•Diluted earnings per share of $1.32, up 67% year over year, and non-GAAP diluted earnings per share of $1.27, down 3%

[0001571996-24-000050:8k_2_02:10]
ROUND ROCK, Texas — May 30, 2024

[0001571996-24-000050:8k_2_02:11]
Full story

[0001571996-24-000050:8k_2_02:12]
Dell Technologies (NYSE: DELL) announces financial results for its fiscal 2025 first quarter. Revenue was $22.2 billion, up 6% year over year. Operating income was $920 million and non-GAAP operating income was $1.5 billion, down 14% and 8% year over year, respectively. Cash flow from operations was $1.0 billion. Diluted earnings per share was $1.32, and non-GAAP diluted earnings per share was $1.27, up 67% and down 3% year over year, respectively.

[0001571996-24-000050:8k_2_02:13]
Dell returned $1.1 billion to shareholders through share repurchases and dividends and ended the quarter with $7.3 billion in cash and investments.

[0001571996-24-000050:8k_2_02:14]
“We again demonstrated our ability to execute and deliver strong cash flow, with AI continuing to drive new growth,” said Yvonne McGill, chief financial officer, Dell Technologies. “Revenue was up 6% at $22.2 billion, servers and networking revenue was up 42%, and we generated $7.9 billion of cash flow from operations over the last 12 months.”

[0001571996-24-000050:8k_2_02:15]
1

[0001571996-24-000050:8k_2_02:16]
First Quarter Fiscal 2025 Financial Results

[0001571996-24-000050:8k_2_02:17]
|  | Three Months Ended |  |  |  |  |  |  |
|  | May 3, 2024 |  | May 5, 2023 |  | Change |  |  |  |  |  |  |
|  | (in millions, except per share amounts and percentages; unaudited) |
| Net revenue | $ | 22,244 |  |  | $ | 20,922 |  |  | 6% |  |  |  |  |  |  |
| Operating income | $ | 920 |  |  | $ | 1,069 |  |  | (14)% |  |  |  |  |  |  |
| Net income | $ | 955 |  |  | $ | 578 |  |  | 65% |  |  |  |  |  |  |
| Change in cash from operating activities | $ | 1,043 |  |  | $ | 1,777 |  |  | (41)% |  |  |  |  |  |  |
| Earnings per share - diluted | $ | 1.32 |  |  | $ | 0.79 |  |  | 67% |  |  |  |  |  |  |
| Non-GAAP operating income | $ | 1,474 |  |  | $ | 1,598 |  |  | (8)% |  |  |  |  |  |  |
| Non-GAAP net income | $ | 923 |  |  | $ | 963 |  |  | (4)% |  |  |  |  |  |  |
| Adjusted free cash flow | $ | 623 |  |  | $ | 687 |  |  | (9)% |  |  |  |  |  |  |
| Non-GAAP earnings per share - diluted | $ | 1.27 |  |  | $ | 1.31 |  |  | (3)% |  |  |  |  |  |  |

[0001571996-24-000050:8k_2_02:18]
Information about Dell Technologies’ use of non-GAAP financial information is provided under “Non-GAAP Financial Measures” below. All comparisons in this press release are year-over-year unless otherwise noted.

[0001571996-24-000050:8k_2_02:19]
Infrastructure Solutions Group (ISG) delivered first quarter revenue of $9.2 billion, up 22% year over year. Servers and networking revenue was a record $5.5 billion, up 42%, with demand strength across AI and traditional servers. Storage revenue was flat at $3.8 billion. Operating income was $736 million.

[0001571996-24-000050:8k_2_02:20]
Client Solutions Group (CSG) delivered first quarter revenue of $12.0 billion, flat year over year. Commercial client revenue was $10.2 billion, up 3% year over year, and Consumer revenue was $1.8 billion, down 15%. Operating income was $732 million.

[0001571996-24-000050:8k_2_02:21]
“No company is better positioned than Dell to bring AI to the enterprise,” said Jeff Clarke, vice chairman and chief operating officer, Dell Technologies. “Servers and networking hit record revenue in Q1, with our AI-optimized server orders increasing sequentially to $2.6 billion, shipments up more than 100% to $1.7 billion, and backlog growing more than 30% to $3.8 billion.”

[0001571996-24-000050:8k_2_02:22]
Dell Technologies World

[0001571996-24-000050:8k_2_02:23]
On May 20, Dell expanded the industry’s broadest AI solutions portfolio from desktop to data center to cloud with innovations designed to accelerate AI adoption and innovation:

[0001571996-24-000050:8k_2_02:24]
•The Dell AI Factory combines Dell infrastructure, solutions and services optimized for AI workloads with an open ecosystem of partners including NVIDIA, Meta, Microsoft and Hugging Face.

[0001571996-24-000050:8k_2_02:25]
•The Dell AI Factory with NVIDIA includes the new PowerEdge XE9680L server, which offers direct liquid cooling in a 4U form factor and can support 72 NVIDIA Blackwell GPUs in a single rack – 33% more GPU density per node compared to the XE9680.

[0001571996-24-000050:8k_2_02:26]
•Dell PowerStore software updates give customers up to a 66% performance boost, native sync replication for file and block and improved multicloud data mobility capabilities.

[0001571996-24-000050:8k_2_02:27]
•New AI PCs are Copilot+ and powered by Qualcomm Snapdragon® X Elite and Snapdragon® X Plus processors, delivering exceptional battery life and AI performance.

[0001571996-24-000050:8k_2_02:28]
2

[0001571996-24-000050:8k_2_02:29]
Operating Segments Results

[0001571996-24-000050:8k_2_02:30]
|  | Three Months Ended |  |  |  |  |  |  |
|  | May 3, 2024 |  | May 5, 2023 |  | Change |  |  |  |  |  |  |
|  | (in millions, except percentages; unaudited) |
| Infrastructure Solutions Group (ISG): |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Servers and networking | $ | 5,466 |  | $ | 3,837 |  |  | 42% |  |  |  |  |  |  |
| Storage | 3,761 |  |  | 3,756 |  |  | —% |  |  |  |  |  |  |
| Total ISG net revenue | $ | 9,227 |  |  | $ | 7,593 |  |  | 22% |  |  |  |  |  |  |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| ISG operating income | $ | 736 |  |  | $ | 740 |  |  | (1)% |  |  |  |  |  |  |
| % of ISG net revenue | 8.0 | % |  | 9.7 | % |  |  |  |  |  |  |  |  |
| % of total reportable segment operating income | 50 | % |  | 45 | % |  |  |  |  |  |  |  |  |
| Client Solutions Group (CSG): |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 10,154 |  |  | $ | 9,862 |  |  | 3% |  |  |  |  |  |  |
| Consumer | 1,813 |  |  | 2,121 |  |  | (15)% |  |  |  |  |  |  |
| Total CSG net revenue | $ | 11,967 |  |  | $ | 11,983 |  |  | —% |  |  |  |  |  |  |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| CSG operating income | $ | 732 |  |  | $ | 892 |  |  | (18)% |  |  |  |  |  |  |
| % of CSG net revenue | 6.1 | % |  | 7.4 | % |  |  |  |  |  |  |  |  |
| % of total reportable segment operating income | 50 | % |  | 55 | % |  |  |  |  |  |  |  |  |

[0001571996-24-000050:8k_2_02:31]
Conference call information

[0001571996-24-000050:8k_2_02:32]
As previously announced, the company will hold a conference call to discuss its performance and financial guidance on May 30 at 3:30 p.m. CDT. Prior to the start of the conference call, prepared remarks and a presentation containing additional financial and operating information prior to financial guidance may be downloaded from investors.delltechnologies.com. The conference call will be broadcast live over the internet and can be accessed at https://investors.delltechnologies.com/news-events/upcoming-events.

[0001571996-24-000050:8k_2_02:33]
For those unable to listen to the live broadcast, the final remarks and presentation with financial guidance will be available following the broadcast, and an archived version will be available at the same location for one year.

[0001571996-24-000050:8k_2_02:34]
About Dell Technologies

[0001571996-24-000050:8k_2_02:35]
Dell Technologies (NYSE:DELL) helps organizations and individuals build their digital future and transform how they work, live and play. The company provides customers with the industry’s broadest and most innovative technology and services portfolio for the AI era.

[0001571996-24-000050:8k_2_02:36]
Contacts

[0001571996-24-000050:8k_2_02:37]
Investors: Investor_Relations@Dell.com

[0001571996-24-000050:8k_2_02:38]
Media: Media.Relations@Dell.com

[0001571996-24-000050:8k_2_02:39]
# # #

[0001571996-24-000050:8k_2_02:40]
3

[0001571996-24-000050:8k_2_02:41]
Copyright © 2024 Dell Inc. or its subsidiaries. All Rights Reserved. Dell Technologies, Dell, EMC and Dell EMC are trademarks of Dell Inc. or its subsidiaries. Other trademarks may be trademarks of their respective owners.

[0001571996-24-000050:8k_2_02:42]
Non-GAAP Financial Measures:

[0001571996-24-000050:8k_2_02:43]
This press release presents information about non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, non-GAAP net income attributable to Dell Technologies Inc., non-GAAP earnings per share attributable to Dell Technologies Inc. – diluted, free cash flow, and adjusted free cash flow, all of which are non-GAAP financial measures provided as a supplement to the results provided in accordance with generally accepted accounting principles in the United States of America (“GAAP”). A reconciliation of each non-GAAP financial measure to the most directly comparable GAAP financial measure is provided in the attached tables for each of the fiscal periods indicated.

[0001571996-24-000050:8k_2_02:44]
Special Note on Forward-Looking Statements:

[0001571996-24-000050:8k_2_02:45]
Dell Technologies’ results or events in future periods could differ materially from those expressed or implied by these forward-looking statements because of risks, uncertainties, and other factors that include, but are not limited to, the following: adverse global economic conditions and instability in financial markets; competitive pressures; Dell Technologies’ reliance on third-party suppliers for products and components, including reliance on single-source or limited-source suppliers; Dell Technologies’ ability to achieve favorable pricing from its vendors; Dell Technologies’ execution of its strategy; social and ethical issues relating to the use of new and evolving technologies; Dell Technologies’ ability to manage solutions and products and services transitions in an effective manner; Dell Technologies’ ability to deliver high-quality products, software, and services; cyber attacks or other data security incidents; Dell Technologies’ ability to successfully execute on strategic initiatives including acquisitions, divestitures or cost savings measures; Dell Technologies’ foreign operations and ability to generate substantial non-U.S. net revenue; Dell Technologies’ product, services, customer, and geographic sales mix, and seasonal sales trends; the performance of Dell Technologies’ sales channel partners; access to the capital markets by Dell Technologies or its customers; material impairment of the value of goodwill or intangible assets; adverse economic conditions and the effect of additional regulation on Dell Technologies’ financial services activities; counterparty default risks; the loss by Dell Technologies of any contracts for ISG services and solutions and its ability to perform such contracts at their estimated costs; loss by Dell Technologies of government contracts; Dell Technologies’ ability to develop and protect its proprietary intellectual property or obtain licenses to intellectual property developed by others on commercially reasonable and competitive terms; disruptions in Dell Technologies’ infrastructure; Dell Technologies’ ability to hedge effectively its exposure to fluctuations in foreign currency exchange rates and interest rates; expiration of tax holidays or favorable tax rate structures, or unfavorable outcomes in tax audits and other tax compliance matters; impairment of portfolio investments; unfavorable results of legal proceedings; expectations relating to environmental, social and governance (ESG) considerations; compliance requirements of changing environmental and safety laws, human rights laws, or other laws; the effect of armed hostilities, terrorism, natural disasters, or public health issues; the effect of global climate change and legal, regulatory, or market measures to address climate change; Dell Technologies’ dependence on the services of Michael Dell and key employees; Dell Technologies’ level of indebtedness; and business and financial factors and legal restrictions affecting continuation of Dell Technologies’ quarterly cash dividend policy and dividend rate.

[0001571996-24-000050:8k_2_02:46]
This list of risks, uncertainties, and other factors is not complete. Dell Technologies discusses some of these matters more fully, as well as certain risk factors that could affect Dell Technologies’ business, financial condition, results of operations, and prospects, in its reports filed with the SEC, including Dell Technologies’ annual report on Form 10-K for the fiscal year ended February 2, 2024, quarterly reports on Form 10-Q, and current reports on Form 8-K. These filings are available for review through the SEC’s website at www.sec.gov. Any or all forward-looking statements Dell Technologies makes may turn out to be wrong and can be affected by inaccurate assumptions Dell Technologies might make or by known or unknown risks, uncertainties, and other factors, including those identified in this press release. Accordingly, you should not place undue reliance on the forward-looking statements made in this press release, which speak only as of its date. Dell Technologies does not undertake to update, and expressly disclaims any duty to update, its forward-looking statements, whether as a result of circumstances or events that arise after the date they are made, new information, or otherwise.

[0001571996-24-000050:8k_2_02:47]
DELL TECHNOLOGIES INC.

[0001571996-24-000050:8k_2_02:48]
Condensed Consolidated Statements of Income and Related Financial Highlights

[0001571996-24-000050:8k_2_02:49]
(in millions, except percentages; unaudited)

[0001571996-24-000050:8k_2_02:50]
|  | Three Months Ended |  |  |  |  |  |  |
|  | May 3, 2024 |  | May 5, 2023 |  | Change |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Products | $ | 16,127 |  |  | $ | 15,036 |  |  | 7% |  |  |  |  |  |  |
| Services | 6,117 |  |  | 5,886 |  |  | 4% |  |  |  |  |  |  |
| Total net revenue | 22,244 |  |  | 20,922 |  |  | 6% |  |  |  |  |  |  |
| Cost of net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Products | 13,766 |  |  | 12,375 |  |  | 11% |  |  |  |  |  |  |
| Services | 3,672 |  |  | 3,529 |  |  | 4% |  |  |  |  |  |  |
| Total cost of net revenue | 17,438 |  |  | 15,904 |  |  | 10% |  |  |  |  |  |  |
| Gross margin | 4,806 |  |  | 5,018 |  |  | (4)% |  |  |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative | 3,123 |  |  | 3,261 |  |  | (4)% |  |  |  |  |  |  |
| Research and development | 763 |  |  | 688 |  |  | 11% |  |  |  |  |  |  |
| Total operating expenses | 3,886 |  |  | 3,949 |  |  | (2)% |  |  |  |  |  |  |
| Operating income | 920 |  |  | 1,069 |  |  | (14)% |  |  |  |  |  |  |
| Interest and other, net | (373) |  |  | (364) |  |  | (2)% |  |  |  |  |  |  |
| Income before income taxes | 547 |  |  | 705 |  |  | (22)% |  |  |  |  |  |  |
| Income tax expense (benefit) | (408) |  |  | 127 |  |  | (421)% |  |  |  |  |  |  |
| Net income | 955 |  |  | 578 |  |  | 65% |  |  |  |  |  |  |
| Net income attributable to Dell Technologies Inc. | $ | 960 |  |  | $ | 583 |  |  | 65% |  |  |  |  |  |  |
| Percentage of Total Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Gross margin | 21.6 | % |  | 24.0 | % |  |  |  |  |  |  |  |  |
| Selling, general, and administrative | 14.1 | % |  | 15.6 | % |  |  |  |  |  |  |  |  |
| Research and development | 3.4 | % |  | 3.3 | % |  |  |  |  |  |  |  |  |
| Operating expenses | 17.5 | % |  | 18.9 | % |  |  |  |  |  |  |  |  |
| Operating income | 4.1 | % |  | 5.1 | % |  |  |  |  |  |  |  |  |
| Income before income taxes | 2.5 | % |  | 3.4 | % |  |  |  |  |  |  |  |  |
| Net income | 4.3 | % |  | 2.8 | % |  |  |  |  |  |  |  |  |
| Income tax rate | (74.6) | % |  | 18.0 | % |  |  |  |  |  |  |  |  |

[0001571996-24-000050:8k_2_02:51]
Amounts are based on underlying data and may not visually foot due to rounding.

[0001571996-24-000050:8k_2_02:52]
5

[0001571996-24-000050:8k_2_02:53]
DELL TECHNOLOGIES INC.

[0001571996-24-000050:8k_2_02:54]
Condensed Consolidated Statements of Financial Position

[0001571996-24-000050:8k_2_02:55]
(in millions; unaudited)

[0001571996-24-000050:8k_2_02:56]
|  | May 3, 2024 |  | February 2, 2024 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 5,830 |  |  | $ | 7,366 |  |
| Accounts receivable, net of allowance of $66 and $71 | 8,563 |  |  | 9,343 |  |
| Short-term financing receivables, net of allowance of $86 and $79 | 4,660 |  |  | 4,643 |  |
| Inventories | 4,782 |  |  | 3,622 |  |
| Other current assets | 10,792 |  |  | 10,973 |  |
| Total current assets | 34,627 |  |  | 35,947 |  |
| Property, plant, and equipment, net | 6,237 |  |  | 6,432 |  |
| Long-term investments | 1,293 |  |  | 1,316 |  |
| Long-term financing receivables, net of allowance of $109 and $91 | 5,941 |  |  | 5,877 |  |
| Goodwill | 19,640 |  |  | 19,700 |  |
| Intangible assets, net | 5,538 |  |  | 5,701 |  |
| Other non-current assets | 6,914 |  |  | 7,116 |  |
| Total assets | $ | 80,190 |  |  | $ | 82,089 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Short-term debt | $ | 6,098 |  |  | $ | 6,982 |  |
| Accounts payable | 20,586 |  |  | 19,389 |  |
| Accrued and other | 6,016 |  |  | 6,805 |  |
| Short-term deferred revenue | 15,034 |  |  | 15,318 |  |
| Total current liabilities | 47,734 |  |  | 48,494 |  |
| Long-term debt | 19,382 |  |  | 19,012 |  |
| Long-term deferred revenue | 13,116 |  |  | 13,827 |  |
| Other non-current liabilities | 2,681 |  |  | 3,065 |  |
| Total liabilities | 82,913 |  |  | 84,398 |  |
| Stockholders’ equity (deficit): |  |  |  |
| Total Dell Technologies Inc. stockholders’ equity (deficit) | (2,822) |  |  | (2,404) |  |
| Non-controlling interests | 99 |  |  | 95 |  |
| Total stockholders’ equity (deficit) | (2,723) |  |  | (2,309) |  |
| Total liabilities and stockholders’ equity | $ | 80,190 |  |  | $ | 82,089 |  |

[0001571996-24-000050:8k_2_02:57]
6

[0001571996-24-000050:8k_2_02:58]
DELL TECHNOLOGIES INC.

[0001571996-24-000050:8k_2_02:59]
Condensed Consolidated Statements of Cash Flows

[0001571996-24-000050:8k_2_02:60]
(in millions; unaudited)

[0001571996-24-000050:8k_2_02:61]
|  | Three Months Ended |  |  |
|  | May 3, 2024 |  | May 5, 2023 |  |  |  |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |
| Net income | $ | 955 |  |  | $ | 578 |  |  |  |  |  |
| Adjustments to reconcile net income to net cash provided by operating activities: | 88 |  |  | 1,199 |  |  |  |  |  |
| Change in cash from operating activities | 1,043 |  |  | 1,777 |  |  |  |  |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |
| Purchases of investments | (39) |  |  | (15) |  |  |  |  |  |
| Maturities and sales of investments | 119 |  |  | 19 |  |  |  |  |  |
| Capital expenditures and capitalized software development costs | (596) |  |  | (701) |  |  |  |  |  |
| Other | 60 |  |  | 13 |  |  |  |  |  |
| Change in cash from investing activities | (456) |  |  | (684) |  |  |  |  |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |
| Proceeds from the issuance of common stock | — |  |  | 2 |  |  |  |  |  |
| Repurchases of common stock | (700) |  |  | (240) |  |  |  |  |  |
| Repurchases of common stock for employee tax withholdings | (521) |  |  | (306) |  |  |  |  |  |
| Payments of dividends and dividend equivalents | (336) |  |  | (276) |  |  |  |  |  |
| Proceeds from debt | 2,992 |  |  | 2,521 |  |  |  |  |  |
| Repayments of debt | (3,477) |  |  | (3,698) |  |  |  |  |  |
| Debt-related costs and other, net | (35) |  |  | (5) |  |  |  |  |  |
| Change in cash from financing activities | (2,077) |  |  | (2,002) |  |  |  |  |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash | (55) |  |  | (58) |  |  |  |  |  |
| Change in cash, cash equivalents, and restricted cash | (1,545) |  |  | (967) |  |  |  |  |  |
| Cash, cash equivalents, and restricted cash at beginning of the period | 7,507 |  |  | 8,894 |  |  |  |  |  |
| Cash, cash equivalents, and restricted cash at end of the period | $ | 5,962 |  |  | $ | 7,927 |  |  |  |  |  |

[0001571996-24-000050:8k_2_02:62]
7

[0001571996-24-000050:8k_2_02:63]
DELL TECHNOLOGIES INC.

[0001571996-24-000050:8k_2_02:64]
Segment Information

[0001571996-24-000050:8k_2_02:65]
(in millions, except percentages; unaudited; continued on next page)

[0001571996-24-000050:8k_2_02:66]
|  | Three Months Ended |  |  |  |  |  |  |
|  | May 3, 2024 |  | May 5, 2023 |  | Change |  |  |  |  |  |  |
| Infrastructure Solutions Group (ISG): |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Servers and networking | $ | 5,466 |  | $ | 3,837 |  |  | 42% |  |  |  |  |  |  |
| Storage | 3,761 |  |  | 3,756 |  |  | —% |  |  |  |  |  |  |
| Total ISG net revenue | $ | 9,227 |  |  | $ | 7,593 |  |  | 22% |  |  |  |  |  |  |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| ISG operating income | $ | 736 |  |  | $ | 740 |  |  | (1)% |  |  |  |  |  |  |
| % of ISG net revenue | 8.0 | % |  | 9.7 | % |  |  |  |  |  |  |  |  |
| % of total reportable segment operating income | 50 | % |  | 45 | % |  |  |  |  |  |  |  |  |
| Client Solutions Group (CSG): |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 10,154 |  |  | $ | 9,862 |  |  | 3% |  |  |  |  |  |  |
| Consumer | 1,813 |  |  | 2,121 |  |  | (15)% |  |  |  |  |  |  |
| Total CSG net revenue | $ | 11,967 |  |  | $ | 11,983 |  |  | —% |  |  |  |  |  |  |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| CSG operating income | $ | 732 |  |  | $ | 892 |  |  | (18)% |  |  |  |  |  |  |
| % of CSG net revenue | 6.1 | % |  | 7.4 | % |  |  |  |  |  |  |  |  |
| % of total reportable segment operating income | 50 | % |  | 55 | % |  |  |  |  |  |  |  |  |

[0001571996-24-000050:8k_2_02:67]
Amounts are based on underlying data and may not visually foot due to rounding.

[0001571996-24-000050:8k_2_02:68]
DELL TECHNOLOGIES INC.

[0001571996-24-000050:8k_2_02:69]
Segment Information

[0001571996-24-000050:8k_2_02:70]
(in millions, except percentages; unaudited; continued)

[0001571996-24-000050:8k_2_02:71]
|  | Three Months Ended |  |  |
|  | May 3, 2024 |  | May 5, 2023 |  |  |  |  |
| Reconciliation to consolidated net revenue: |  |  |  |  |  |  |
| Reportable segment net revenue | $ | 21,194 |  |  | $ | 19,576 |  |  |  |  |  |
| Other businesses (a) | 1,049 |  |  | 1,343 |  |  |  |  |  |
| Unallocated transactions (b) | 1 |  |  | 3 |  |  |  |  |  |
| Total consolidated net revenue | $ | 22,244 |  |  | $ | 20,922 |  |  |  |  |  |
| Reconciliation to consolidated operating income: |  |  |  |  |  |  |  |
| Reportable segment operating income | $ | 1,468 |  |  | $ | 1,632 |  |  |  |  |  |
| Other businesses (a) | 6 |  |  | (36) |  |  |  |  |  |
| Unallocated transactions (b) | — |  |  | 2 |  |  |  |  |  |
| Amortization of intangibles (c) | (168) |  |  | (203) |  |  |  |  |  |
| Stock-based compensation expense (d) | (210) |  |  | (225) |  |  |  |  |  |
| Other corporate expenses (e) | (176) |  |  | (101) |  |  |  |  |  |
| Total consolidated operating income | $ | 920 |  |  | $ | 1,069 |  |  |  |  |  |

[0001571996-24-000050:8k_2_02:72]
_________________

[0001571996-24-000050:8k_2_02:73]
(a)Other businesses consists of: 1) Dell’s resale of standalone VMware, Inc. products and services, “VMware Resale,” 2) Secureworks, and 3) Virtustream, and do not meet the requirements for a reportable segment, either individually or collectively.

[0001571996-24-000050:8k_2_02:74]
(b)Unallocated transactions includes other corporate items that are not allocated to Dell Technologies’ reportable segments.

[0001571996-24-000050:8k_2_02:75]
(c)Amortization of intangibles includes non-cash purchase accounting adjustments that are primarily related to the EMC merger transaction.

[0001571996-24-000050:8k_2_02:76]
(d)Stock-based compensation expense consists of equity awards granted based on the estimated fair value of those awards at grant date.

[0001571996-24-000050:8k_2_02:77]
(e)Other corporate expenses consist primarily of severance expenses, payroll taxes associated with stock-based compensation, facility action costs, transaction-related expenses, impairment charges, and incentive charges related to equity investments.

[0001571996-24-000050:8k_2_02:78]
SUPPLEMENTAL SELECTED NON-GAAP FINANCIAL MEASURES

[0001571996-24-000050:8k_2_02:79]
These tables present information about the Company’s non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, non-GAAP net income attributable to Dell Technologies Inc., non-GAAP earnings per share attributable to Dell Technologies Inc. - diluted, free cash flow and adjusted free cash flow, all of which are non-GAAP financial measures provided as a supplement to the results provided in accordance with generally accepted accounting principles in the United States of America (“GAAP”). A detailed discussion of Dell Technologies’ reasons for including these non-GAAP financial measures, the limitations associated with these measures, the items excluded from these measures, and our reason for excluding those items are presented in “Management’s Discussion and Analysis of Financial Condition and Results of Operations — Non-GAAP Financial Measures” in our periodic reports filed with the SEC. Dell Technologies encourages investors to review the non-GAAP discussion in these reports in conjunction with the presentation of non-GAAP financial measures.

[0001571996-24-000050:8k_2_02:80]
10

[0001571996-24-000050:8k_2_02:81]
DELL TECHNOLOGIES INC.

[0001571996-24-000050:8k_2_02:82]
Selected Financial Measures

[0001571996-24-000050:8k_2_02:83]
(in millions, except per share amounts and percentages; unaudited)

[0001571996-24-000050:8k_2_02:84]
|  | Three Months Ended |  |  |  |  |  |  |
|  | May 3, 2024 |  | May 5, 2023 |  | % Change |  |  |  |  |  |  |
| Net revenue | $ | 22,244 |  |  | $ | 20,922 |  |  | 6% |  |  |  |  |  |  |
| Non-GAAP gross margin | $ | 4,947 |  |  | $ | 5,164 |  |  | (4)% |  |  |  |  |  |  |
| % of net revenue | 22.2 | % |  | 24.7 | % |  |  |  |  |  |  |  |  |
| Non-GAAP operating expenses | $ | 3,473 |  |  | $ | 3,566 |  |  | (3)% |  |  |  |  |  |  |
| % of net revenue | 15.6 | % |  | 17.1 | % |  |  |  |  |  |  |  |  |
| Non-GAAP operating income | $ | 1,474 |  |  | $ | 1,598 |  |  | (8)% |  |  |  |  |  |  |
| % of net revenue | 6.6 | % |  | 7.6 | % |  |  |  |  |  |  |  |  |
| Non-GAAP net income | $ | 923 |  |  | $ | 963 |  |  | (4)% |  |  |  |  |  |  |
| % of net revenue | 4.1 | % |  | 4.6 | % |  |  |  |  |  |  |  |  |
| Non-GAAP earnings per share - diluted | $ | 1.27 |  |  | $ | 1.31 |  |  | (3)% |  |  |  |  |  |  |

[0001571996-24-000050:8k_2_02:85]
Amounts are based on underlying data and may not visually foot due to rounding.

[0001571996-24-000050:8k_2_02:86]
DELL TECHNOLOGIES INC.

[0001571996-24-000050:8k_2_02:87]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-24-000050:8k_2_02:88]
(in millions, except percentages; unaudited; continued on next page)

[0001571996-24-000050:8k_2_02:89]
|  | Three Months Ended |  |  |  |  |  |  |
|  | May 3, 2024 |  | May 5, 2023 |  | % Change |  |  |  |  |  |  |
| Gross margin | $ | 4,806 |  |  | $ | 5,018 |  |  | (4)% |  |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 60 |  |  | 79 |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense | 38 |  |  | 38 |  |  |  |  |  |  |  |  |  |
| Other corporate expenses | 43 |  |  | 29 |  |  |  |  |  |  |  |  |  |
| Non-GAAP gross margin | $ | 4,947 |  |  | $ | 5,164 |  |  | (4)% |  |  |  |  |  |  |
| Operating expenses | $ | 3,886 |  |  | $ | 3,949 |  |  | (2)% |  |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | (108) |  |  | (124) |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense | (172) |  |  | (187) |  |  |  |  |  |  |  |  |  |
| Other corporate expenses | (133) |  |  | (72) |  |  |  |  |  |  |  |  |  |
| Non-GAAP operating expenses | $ | 3,473 |  |  | $ | 3,566 |  |  | (3)% |  |  |  |  |  |  |
| Operating income | $ | 920 |  |  | $ | 1,069 |  |  | (14)% |  |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 168 |  |  | 203 |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense | 210 |  |  | 225 |  |  |  |  |  |  |  |  |  |
| Other corporate expenses | 176 |  |  | 101 |  |  |  |  |  |  |  |  |  |
| Non-GAAP operating income | $ | 1,474 |  |  | $ | 1,598 |  |  | (8)% |  |  |  |  |  |  |
| Net income | $ | 955 |  |  | $ | 578 |  |  | 65 | % |  |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 168 |  |  | 203 |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense | 210 |  |  | 225 |  |  |  |  |  |  |  |  |  |
| Other corporate expenses | 170 |  |  | 98 |  |  |  |  |  |  |  |  |  |
| Fair value adjustments on equity investments | 30 |  |  | 15 |  |  |  |  |  |  |  |  |  |
| Aggregate adjustment for income taxes (a) | (610) |  |  | (156) |  |  |  |  |  |  |  |  |  |
| Non-GAAP net income | $ | 923 |  |  | $ | 963 |  |  | (4)% |  |  |  |  |  |  |

[0001571996-24-000050:8k_2_02:90]
____________________

[0001571996-24-000050:8k_2_02:91]
(a)    Beginning in Fiscal 2025, our non-GAAP income tax is calculated using a fixed estimated annual tax rate.

[0001571996-24-000050:8k_2_02:92]
12

[0001571996-24-000050:8k_2_02:93]
DELL TECHNOLOGIES INC.

[0001571996-24-000050:8k_2_02:94]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-24-000050:8k_2_02:95]
(unaudited; continued)

[0001571996-24-000050:8k_2_02:96]
|  | Three Months Ended |  |  |  |  |  |  |  |  |  |  |
|  | May 3, 2024 |  | May 5, 2023 |  | % Change |  |  |  |  |  |  |  |  |  |  |
| Earnings per share attributable to Dell Technologies, Inc. — diluted | $ | 1.32 |  |  | $ | 0.79 |  |  | 67 | % |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 0.23 |  |  | 0.28 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense | 0.29 |  |  | 0.30 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other corporate expenses | 0.24 |  |  | 0.13 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fair value adjustments on equity investments | 0.04 |  |  | 0.02 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aggregate adjustment for income taxes (a) | (0.84) |  |  | (0.21) |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total non-GAAP adjustments attributable to non-controlling interests | (0.01) |  |  | — |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP earnings per share attributable to Dell Technologies, Inc. — diluted | $ | 1.27 |  |  | $ | 1.31 |  |  | (3) | % |  |  |  |  |  |  |  |  |  |  |

[0001571996-24-000050:8k_2_02:97]
____________________

[0001571996-24-000050:8k_2_02:98]
(a)    Beginning in Fiscal 2025, our non-GAAP income tax is calculated using a fixed estimated annual tax rate.

[0001571996-24-000050:8k_2_02:99]
13

[0001571996-24-000050:8k_2_02:100]
DELL TECHNOLOGIES INC.

[0001571996-24-000050:8k_2_02:101]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-24-000050:8k_2_02:102]
(in millions, except percentages; unaudited; continued)

[0001571996-24-000050:8k_2_02:103]
|  | Three Months Ended |  |  |  |  |  |  |  |  |  |  |
|  | May 3, 2024 |  | May 5, 2023 |  | % Change |  |  |  |  |  |  |  |  |  |  |
| Cash flow from operations | $ | 1,043 |  |  | $ | 1,777 |  |  | (41) | % |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Capital expenditures and capitalized software development costs, net (a) | (586) |  |  | (698) |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Free cash flow | $ | 457 |  |  | $ | 1,079 |  |  | (58) | % |  |  |  |  |  |  |  |  |  |  |
| Free cash flow | $ | 457 |  |  | $ | 1,079 |  |  | (58) | % |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Financing receivables (b) | 165 |  |  | (367) |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equipment under operating leases (c) | 1 |  |  | (25) |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Adjusted free cash flow | $ | 623 |  |  | $ | 687 |  |  | (9) | % |  |  |  |  |  |  |  |  |  |  |

[0001571996-24-000050:8k_2_02:104]
____________________

[0001571996-24-000050:8k_2_02:105]
(a)    Capital expenditures and capitalized software development costs is net of proceeds from sales of facilities, land, and

[0001571996-24-000050:8k_2_02:106]
other assets.

[0001571996-24-000050:8k_2_02:107]
(b)    Financing receivables represent the operating cash flow impact from the change in DFS financing receivables.

[0001571996-24-000050:8k_2_02:108]
(c)    Equipment under operating leases represents the net change of capital expenditures and depreciation expense for DFS leases and contractually embedded leases identified within flexible consumption arrangements.
