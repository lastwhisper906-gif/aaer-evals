# DELL MD&A — 0001571996-24-000062


## mdna

[0001571996-24-000062:mdna:1]
[same as prior period, unchanged from 0001571996-23-000046:mdna:1]

[0001571996-24-000062:mdna:2]
[same as prior period, unchanged from 0001571996-23-000046:mdna:2]

[0001571996-24-000062:mdna:3]
[same as prior period, unchanged from 0001571996-23-000046:mdna:3]

[0001571996-24-000062:mdna:4]
Our fiscal year is the 52- or 53-week period ending on the Friday nearest January 31.  We refer to our fiscal year ending January 31, 2025 as “Fiscal 2025” and our fiscal year ended February 2, 2024 as “Fiscal 2024.”  Fiscal 2025 and Fiscal 2024 include 52 weeks.

[0001571996-24-000062:mdna:5]
[same as prior period, unchanged from 0001571996-23-000046:mdna:5]

[0001571996-24-000062:mdna:6]
[same as prior period, unchanged from 0001571996-23-000046:mdna:6]

[0001571996-24-000062:mdna:7]
Dell Technologies is a global technology company that provides customers with a broad and innovative solutions portfolio to help customers modernize their information technology (“IT”) infrastructure, address workforce transformation, and provide critical solutions that keep people and organizations connected.  With our extensive portfolio and our commitment to innovation, we offer secure, integrated solutions that extend from the edge to the core to the cloud, and we are at the forefront of artificial intelligence (“AI”), software-defined, and cloud native infrastructure solutions.  Our vision is to become the most essential technology partner.  We intend to realize our vision as we execute our strategy to leverage our strengths to extend our leadership positions and capture new growth.

[0001571996-24-000062:mdna:8]
We are organized into two business units which are also our reportable segments: Infrastructure Solutions Group and Client Solutions Group.

[0001571996-24-000062:mdna:9]
•Infrastructure Solutions Group (“ISG”) — ISG includes our storage, server, and networking offerings.  Our comprehensive storage portfolio includes modern and traditional storage solutions, including all-flash arrays, scale-out file, object platforms, hyper-converged infrastructure, and software-defined storage.  Our server portfolio includes high-performance general-purpose and AI-optimized servers.  Our networking portfolio includes wide area network infrastructure, data center and edge networking switches, and cables and optics.  ISG also offers software, peripherals, and services, including consulting and support and deployment.

[0001571996-24-000062:mdna:10]
•Client Solutions Group (“CSG”) — CSG includes offerings designed for commercial and consumer customers.  Our CSG portfolio includes branded PCs, including notebooks, desktops, and workstations, branded peripherals, and third-party software and peripherals.  CSG also includes services offerings, such as configuration, support and deployment, and extended warranties.

[0001571996-24-000062:mdna:11]
Our “other businesses” primarily consist of our resale of standalone offerings of VMware LLC (formerly “VMware, Inc.” and individually and together with its subsidiaries, “VMware”), referred to as “VMware Resale,” and offerings of SecureWorks Corp. (“Secureworks”).  These businesses are not classified as reportable segments, either individually or collectively.

[0001571996-24-000062:mdna:12]
For further discussion regarding our current reportable segments, see “Results of Operations — Business Unit Results” and Note 16 of the Notes to the Condensed Consolidated Financial Statements included in this report.

[0001571996-24-000062:mdna:13]
We offer customers choice in how they acquire our solutions including traditional purchasing and financing offerings provided by Dell Financial Services and its affiliates (“DFS”).  We also offer flexible consumption models, that include utility, subscription, and as-a-Service models.  These offerings allow our customers to pay over time and provide them with operational and financial flexibility.  For additional information about our financing arrangements, see Note 4 of the Notes to the Condensed Consolidated Financial Statements included in this report.

[0001571996-24-000062:mdna:14]
[same as prior period, unchanged from 0001571996-23-000046:mdna:40]

[0001571996-24-000062:mdna:15]
During the first quarter of Fiscal 2025, certain trends and conditions, including the following, continued to affect the environment in which we operate:

[0001571996-24-000062:mdna:16]
•Macroeconomic environment: During the first quarter of Fiscal 2025, the macroeconomic environment showed signs of stabilizing as the demand environment improved across a number of our offerings, resulting in overall net revenue growth.  While the demand environment improved, the pricing environment became increasingly competitive, which affected our ISG and CSG gross margin performance.

[0001571996-24-000062:mdna:17]
•Advancements in artificial intelligence: Our ISG business continued to benefit from increased demand for AI-optimized solutions due to the impact of AI advancements on customer spending behavior, as organizations look to integrate AI into their operations.  Demand for AI-optimized servers outpaced the supply of graphics processing units (“GPUs”) for these products, resulting in elevated backlog levels for such offerings as we exited the quarter.

[0001571996-24-000062:mdna:18]
•Supply Chain: Notwithstanding the elevated demand for AI-optimized solutions, our supply chain operated efficiently during the quarter.  We experienced a decline in input costs, which consist of both component and logistics costs.

[0001571996-24-000062:mdna:19]
•Broadcom’s acquisition of VMware: On November 22, 2023, Broadcom Inc. (“Broadcom”) completed its acquisition of VMware, leading to changes to our relationship with VMware as described below.  The changes continued to affect our other businesses net revenue for the first quarter of Fiscal 2025.

[0001571996-24-000062:mdna:20]
We expect the demand environment will continue to improve throughout the remainder of Fiscal 2025 as the macroeconomic environment continues to stabilize.  While we anticipate the pricing environment will remain competitive throughout Fiscal 2025, we expect net revenue growth for the full fiscal year, driven primarily by net revenue attributable to ISG and, to a lesser extent, net revenue attributable to CSG.  We expect ISG net revenue to grow, driven by our AI-optimized servers and continued demand improvement for our traditional servers and storage offerings.  We expect CSG net revenue to grow, driven in part by the anticipated PC refresh cycle in the latter part of Fiscal 2025.  We expect a continued reduction of our other businesses’ net revenue as we will no longer act as a distributor of VMware’s standalone products and services.

[0001571996-24-000062:mdna:21]
We expect input costs to increase during Fiscal 2025, notably in the second half of the year, principally driven by anticipated inflation for component costs.  Input cost trends are dependent on the strength or weakness of actual end-user demand and supply dynamics, which will continue to fluctuate and ultimately impact our costs, pricing, and operating results.

[0001571996-24-000062:mdna:22]
We remain focused on executing our key strategic priorities, building long-term value creation for our stakeholders, and addressing our customers’ needs while continuing to make prudent decisions in response to the environment.  We look to balance profitability and growth while maintaining disciplined pricing as we navigate through competitive pricing pressures.  We continue to remain committed to disciplined cost management, including limitation of external hiring, employee reorganizations, and other actions to align our investments with our strategic priorities and customer needs.

[0001571996-24-000062:mdna:23]
Throughout the year, we will continue to advance our own capabilities to change the way we work and make decisions, improve business outcomes and the customer experience, and reduce costs by leveraging new technology to streamline our own systems and optimize business processes.  We believe our unique operating advantages provide a foundation to foster growth, drive efficiencies, and continue to position us for long-term success.

[0001571996-24-000062:mdna:24]
Relationship with VMware — On November 22, 2023, VMware was acquired by Broadcom, and subsequently announced changes to its go-to-market approach for VMware offerings that impacted our commercial relationship with VMware.  On March 25, 2024, the Company terminated the Commercial Framework Agreement (“CFA”) with VMware, which provided the framework under which we and VMware continued our commercial relationship following our spin-off of VMware by means of a special stock dividend.  We no longer act as a distributor of VMware’s standalone products and services, though we will continue to support customers that have purchased resale offerings sold in prior periods.  The Company continues to integrate certain VMware products and services with select Dell Technologies’ offerings to end-users.  The results of such offerings are reflected within CSG or ISG, depending upon the nature of the underlying offering sold.

[0001571996-24-000062:mdna:25]
VMware was a related party until the date of its acquisition by Broadcom.  The acquisition terminated the preexisting related party relationship with VMware such that no related party relationship exists with either Broadcom or VMware effective as of November 22, 2023.  For more information regarding the impact of the Broadcom acquisition of VMware and our related party transactions with VMware, see Note 15 of the Notes to the Condensed Consolidated Financial Statements included in this report.

[0001571996-24-000062:mdna:26]
ISG — We expect that ISG will continue to be impacted by the evolving nature of the IT infrastructure market and competitive environment.  With our scale and strong solutions portfolio, we believe we are well-positioned to address the ongoing competitive dynamics and trends in technology and customer needs.  Through our collaborative, customer-focused approach to innovation, we strive to deliver new and relevant solutions and software to our customers quickly and efficiently.  We continue to focus on customer base expansion and the lifetime value of customer relationships.

[0001571996-24-000062:mdna:27]
We anticipate that ISG will continue to benefit from technology advances and customer interest in AI.  Through our server and networking and storage offerings, including our AI-optimized solutions, we are well-positioned to capture growth and support our customers’ needs.

[0001571996-24-000062:mdna:28]
We expect that growth in data will continue to generate long-term demand for our storage solutions and services.  Cloud native applications are expected to continue to be a key trend in the infrastructure market.  We continue to expand our offerings in external storage arrays, which incorporate flexible, cloud-based functionality.  We benefit from offering solutions that address software-defined storage, hyper-converged infrastructure, and modular solutions based on server-centric architectures.  Our storage business is subject to seasonal trends, which may continue to impact ISG results.

[0001571996-24-000062:mdna:29]
CSG — We participate in all segments of the PC market but focus on commercial and high-end consumer computing devices, as we believe they represent the most stable and profitable markets.  We anticipate that CSG will benefit from advances in AI over the long-term as customers will require PCs with the ability to run their complex AI workloads.

[0001571996-24-000062:mdna:30]
Competitive dynamics continue to be an important factor in our CSG business and continue to impact pricing and operating results.  We remain committed to our long-term CSG strategy and will continue to make investments to innovate across the portfolio.  We expect that the CSG demand environment will continue to be subject to seasonal trends.

[0001571996-24-000062:mdna:31]
Recurring Revenue and Consumption Models — We expect that our flexible consumption models will further strengthen our customer relationships and provide a foundation for growth in recurring revenue.  We define recurring revenue as revenue recognized that is primarily related to hardware and software maintenance as well as operating leases, subscription, as-a-Service, and usage-based offerings.

[0001571996-24-000062:mdna:32]
Strategic Investments and Acquisitions — As part of our strategy, we will continue to evaluate opportunities for strategic investments through our venture capital investment arm, Dell Technologies Capital, with a focus on emerging technology areas that are relevant to our business.  The technologies or products these companies have under development are typically in the early stages and may never have commercial value, which could result in a loss of a substantial part of our investment in the companies.

[0001571996-24-000062:mdna:33]
Foreign Currency Exposure — We manage our business on a U.S. dollar basis.  However, we have a large global presence, generating approximately half of our net revenue from sales to customers outside of the United States during the first quarter of Fiscal 2025 and Fiscal 2024.  As a result, our operating results can be, and particularly in recent periods have been, impacted by fluctuations in foreign currency exchange rates.  We utilize a comprehensive hedging strategy intended to mitigate the impact of foreign currency volatility over time, and we adjust pricing when possible to further minimize foreign currency impacts.

[0001571996-24-000062:mdna:34]
Other Macroeconomic Risks and Uncertainties — The impacts of trade protection measures, including increases in tariffs and trade barriers, changes in government policies and international trade arrangements, geopolitical volatility, and global macroeconomic conditions (including those in China), may affect our ability to conduct business in some non-U.S. markets.  We monitor and seek to mitigate these risks with adjustments to our manufacturing, supply chain, and distribution networks.

[0001571996-24-000062:mdna:35]
54

[0001571996-24-000062:mdna:36]
[same as prior period, unchanged from 0001571996-23-000046:mdna:58]

[0001571996-24-000062:mdna:37]
In this management’s discussion and analysis, we use supplemental measures of our performance which are derived from our consolidated financial information but which are not presented in our consolidated financial statements prepared in accordance with GAAP.  These non-GAAP financial measures include non-GAAP product gross margin; non-GAAP services gross margin; non-GAAP gross margin; non-GAAP operating expenses; non-GAAP operating income; non-GAAP net income; non-GAAP earnings per share attributable to Dell Technologies Inc. - diluted; free cash flow; and adjusted free cash flow.  These non-GAAP financial measures are not meant to be considered as indicators of performance or liquidity in isolation from or as a substitute for gross margin, operating expenses, operating income, net income, diluted earnings per share, or cash flows from operating activities prepared in accordance with GAAP, and should be read only in conjunction with financial information presented on a GAAP basis.

[0001571996-24-000062:mdna:38]
We use non-GAAP financial measures to supplement financial information presented on a GAAP basis.  Management uses these non-GAAP measures in financial planning and forecasting and when evaluating our financial results and operating trends and performance.  We believe, when used supplementally with GAAP financial measures, these non-GAAP financial measures provide our investors with useful and transparent information to help them evaluate our results by facilitating an enhanced understanding of our results of operations and enabling them to make period to period comparisons.  There are limitations to the use of the non-GAAP financial measures presented in this report.  Our non-GAAP financial measures may not be comparable to similarly titled measures of other companies.  Other companies, including companies in our industry, may calculate non-GAAP financial measures differently than we do, limiting the usefulness of those measures for comparative purposes.

[0001571996-24-000062:mdna:39]
Non-GAAP product gross margin, non-GAAP services gross margin, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, and non-GAAP earnings per share attributable to Dell Technologies Inc. - diluted, as defined by us, exclude amortization of intangible assets, stock-based compensation expense, other corporate expenses and, for non-GAAP net income and non-GAAP earnings per share attributable to Dell Technologies Inc. - diluted, fair value adjustments on equity investments and an aggregate adjustment for income taxes.  As the excluded items may have a material impact on our financial results, our management compensates for this limitation by relying primarily on our GAAP results and using non-GAAP financial measures supplementally or for projections when comparable GAAP financial measures are not available.

[0001571996-24-000062:mdna:40]
[same as prior period, unchanged from 0001571996-23-000046:mdna:62]

[0001571996-24-000062:mdna:41]
The following is a summary of the items excluded from the most comparable GAAP financial measures to calculate our non-GAAP financial measures.

[0001571996-24-000062:mdna:42]
•Amortization of Intangible Assets — Amortization of intangible assets primarily consists of the amortization of customer relationships, developed technology, and trade names.  In connection with our acquisition by merger of EMC, referred to as the “EMC merger transaction,” and the acquisition of Dell Inc. by Dell Technologies Inc., referred to as the “going-private transaction,” all of the tangible and intangible assets and liabilities of EMC and Dell Inc. and their consolidated subsidiaries, respectively, were accounted for and recognized at fair value on the transaction dates.  We exclude amortization charges for the amortization of intangible assets as they do not reflect our current operating performance and charges are significantly impacted by the timing and magnitude of our acquisitions and, as a result, may vary in amount from period to period.

[0001571996-24-000062:mdna:43]
•Stock-based Compensation Expense — Stock-based compensation expense consists of equity awards granted based on the estimated fair value of those awards at grant date.  To estimate the fair value of performance-based awards containing a market condition, we use the Monte Carlo valuation model.  For other share-based awards, the fair value is generally based on the closing price of the Class C Common Stock as reported on the New York Stock Exchange on the date of grant.  Although stock-based compensation is an important aspect of the compensation of our employees and executives, we exclude such expense because the fair value of the stock-based awards may fluctuate based on factors unrelated to the operating performance of the business and may bear little resemblance to the actual value realized upon the vesting or future exercise of the related stock-based awards.

[0001571996-24-000062:mdna:44]
•Other Corporate Expenses — Other corporate expenses consist primarily of severance expenses, payroll taxes associated with stock-based compensation, facility action costs, transaction-related expenses, impairment charges, and incentive charges related to equity investments.  Severance costs are primarily related to severance and benefits for employees terminated pursuant to cost management initiatives.  Transaction-related expenses typically consist of acquisition, integration, and divestitures related costs, primarily representing costs for legal, banking, consulting, and advisory services, and are expensed as incurred.  Although we may incur these types of expenses in the future, we exclude other corporate expenses as they can vary from period to period, are significantly impacted by the timing and nature of these events, and are not used by management in assessing operating performance of the business.

[0001571996-24-000062:mdna:45]
•Fair Value Adjustments on Equity Investments — Fair value adjustments on equity investments primarily consist of the gain (loss) on strategic investments, which includes recurring fair value adjustments of investments in publicly-traded companies, as well as those in privately-held companies, which are adjusted for observable price changes and any potential impairments.  See Note 3 of the Notes to the Condensed Consolidated Financial Statements included in this report for additional information on our strategic investment activity.  We exclude fair value adjustments on equity investments given the volatility in ongoing adjustments to the valuation of these strategic investments and because such adjustments are unrelated to the operating performance of our business.

[0001571996-24-000062:mdna:46]
•Aggregate Adjustment for Income Taxes — The aggregate adjustment for income taxes is the estimated combined income tax effect for the adjustments described above and determined based on the tax jurisdictions where those adjustments were incurred, as well as an adjustment for discrete tax items.  During the first quarter of Fiscal 2025, the aggregate adjustment for income taxes included discrete tax benefits of $0.4 billion related to changes in uncertain tax benefits resulting from the expiration of certain statutes of limitations and $0.2 billion related to stock-based compensation.  We exclude these benefits or charges for purposes of calculating non-GAAP net income due to the variability in recognition of discrete tax items from period to period.  The tax effects are determined based on the tax jurisdictions where the above items were incurred.  See Note 11 of the Notes to the Condensed Consolidated Financial Statements included in this report for additional information about our income taxes.  Beginning in Fiscal 2025, our non-GAAP income tax is calculated using a fixed estimated annual tax rate which is determined based on historical trends and projections for the current fiscal year.  We may adjust our estimated annual tax rate during the fiscal year to take into account events that would significantly impact our income tax expense, including significant changes resulting from tax legislation, material changes in geographic mix of revenue and expenses, changes to our corporate structure, and other significant events.

[0001571996-24-000062:mdna:47]
56

[0001571996-24-000062:mdna:48]
[same as prior period, unchanged from 0001571996-23-000046:mdna:72]

[0001571996-24-000062:mdna:49]
|  |  |  | Three Months Ended |
|  |  |  |  |  |  |  | May 3, 2024 |  | % Change |  | May 5, 2023 |  |  |  |  |
|  |  |  |  |  |  |  | (in millions, except percentages) |  |  |  |  |
| Product gross margin |  |  |  |  |  |  | $ | 2,361 |  |  | (11) | % |  | $ | 2,661 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles |  |  |  |  |  |  | 60 |  |  |  |  | 79 |  |  |  |  |  |
| Stock-based compensation expense |  |  |  |  |  |  | 14 |  |  |  |  | 13 |  |  |  |  |  |
| Other corporate expenses |  |  |  |  |  |  | 4 |  |  |  |  | 8 |  |  |  |  |  |
| Non-GAAP product gross margin |  |  |  |  |  |  | $ | 2,439 |  |  | (12) | % |  | $ | 2,761 |  |  |  |  |  |
| Services gross margin |  |  |  |  |  |  | $ | 2,445 |  |  | 4 | % |  | $ | 2,357 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense |  |  |  |  |  |  | 24 |  |  |  |  | 25 |  |  |  |  |  |
| Other corporate expenses |  |  |  |  |  |  | 39 |  |  |  |  | 21 |  |  |  |  |  |
| Non-GAAP services gross margin |  |  |  |  |  |  | $ | 2,508 |  |  | 4 | % |  | $ | 2,403 |  |  |  |  |  |
| Gross margin |  |  |  |  |  |  | $ | 4,806 |  |  | (4) | % |  | $ | 5,018 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles |  |  |  |  |  |  | 60 |  |  |  |  | 79 |  |  |  |  |  |
| Stock-based compensation expense |  |  |  |  |  |  | 38 |  |  |  |  | 38 |  |  |  |  |  |
| Other corporate expenses |  |  |  |  |  |  | 43 |  |  |  |  | 29 |  |  |  |  |  |
| Non-GAAP gross margin |  |  |  |  |  |  | $ | 4,947 |  |  | (4) | % |  | $ | 5,164 |  |  |  |  |  |
| Operating expenses |  |  |  |  |  |  | $ | 3,886 |  |  | (2) | % |  | $ | 3,949 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles |  |  |  |  |  |  | (108) |  |  |  |  | (124) |  |  |  |  |  |
| Stock-based compensation expense |  |  |  |  |  |  | (172) |  |  |  |  | (187) |  |  |  |  |  |
| Other corporate expenses |  |  |  |  |  |  | (133) |  |  |  |  | (72) |  |  |  |  |  |
| Non-GAAP operating expenses |  |  |  |  |  |  | $ | 3,473 |  |  | (3) | % |  | $ | 3,566 |  |  |  |  |  |

[0001571996-24-000062:mdna:50]
|  |  |  | Three Months Ended |
|  |  |  |  |  |  |  | May 3, 2024 |  | % Change |  | May 5, 2023 |  |  |  |  |
|  |  |  |  |  |  |  | (in millions, except percentages and per share amounts) |  |  |  |  |
| Operating income |  |  |  |  |  |  | $ | 920 |  |  | (14) | % |  | $ | 1,069 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles |  |  |  |  |  |  | 168 |  |  |  |  | 203 |  |  |  |  |  |
| Stock-based compensation expense |  |  |  |  |  |  | 210 |  |  |  |  | 225 |  |  |  |  |  |
| Other corporate expenses |  |  |  |  |  |  | 176 |  |  |  |  | 101 |  |  |  |  |  |
| Non-GAAP operating income |  |  |  |  |  |  | $ | 1,474 |  |  | (8) | % |  | $ | 1,598 |  |  |  |  |  |
| Net income |  |  |  |  |  |  | $ | 955 |  |  | 65 | % |  | $ | 578 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles |  |  |  |  |  |  | 168 |  |  |  |  | 203 |  |  |  |  |  |
| Stock-based compensation expense |  |  |  |  |  |  | 210 |  |  |  |  | 225 |  |  |  |  |  |
| Other corporate expenses |  |  |  |  |  |  | 170 |  |  |  |  | 98 |  |  |  |  |  |
| Fair value adjustments on equity investments |  |  |  |  |  |  | 30 |  |  |  |  | 15 |  |  |  |  |  |
| Aggregate adjustment for income taxes |  |  |  |  |  |  | (610) |  |  |  |  | (156) |  |  |  |  |  |
| Non-GAAP net income |  |  |  |  |  |  | $ | 923 |  |  | (4) | % |  | $ | 963 |  |  |  |  |  |
| Earnings per share attributable to Dell Technologies Inc. — diluted |  |  |  |  |  |  | $ | 1.32 |  |  | 67 | % |  | $ | 0.79 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles |  |  |  |  |  |  | 0.23 |  |  |  |  | 0.28 |  |  |  |  |  |
| Stock-based compensation expense |  |  |  |  |  |  | 0.29 |  |  |  |  | 0.30 |  |  |  |  |  |
| Other corporate expenses |  |  |  |  |  |  | 0.24 |  |  |  |  | 0.13 |  |  |  |  |  |
| Fair value adjustments on equity investments |  |  |  |  |  |  | 0.04 |  |  |  |  | 0.02 |  |  |  |  |  |
| Aggregate adjustment for income taxes |  |  |  |  |  |  | (0.84) |  |  |  |  | (0.21) |  |  |  |  |  |
| Total non-GAAP adjustments attributable to non-controlling interests |  |  |  |  |  |  | (0.01) |  |  |  |  | — |  |  |  |  |  |
| Non-GAAP earnings per share attributable to Dell Technologies Inc. — diluted |  |  |  |  |  |  | $ | 1.27 |  |  | (3) | % |  | $ | 1.31 |  |  |  |  |  |

[0001571996-24-000062:mdna:51]
58

[0001571996-24-000062:mdna:52]
In addition to the above measures, we use free cash flow and adjusted free cash flow as non-GAAP liquidity measures to evaluate our performance.  As presented in the following table, we define free cash flow to consist of cash flow from operations after excluding capital expenditures and capitalized software costs, net.  To measure adjusted free cash flow, we exclude the impact of financing receivables and equipment under operating leases from free cash flow, as the initial funding of these DFS offerings at the time of origination is largely subsequently replaced with cash inflows from our DFS debt, the majority of which is asset-backed.

[0001571996-24-000062:mdna:53]
Free cash flow and adjusted free cash flow provide useful information to management and investors in part because we use these metrics in our long-term capital allocation framework.  Further, we believe free cash flow and adjusted free cash flow are useful measures to management and investors because they reflect cash that we can use, among other purposes, to repurchase common stock, pay dividends on our common stock, invest in our business, pay down debt, and make strategic acquisitions.

[0001571996-24-000062:mdna:54]
As is the case with the non-GAAP measures presented above, users should consider the limitations of using free cash flow and adjusted free cash flow, including the fact that those measures do not provide a complete measure of our cash flows for any period.  Free cash flow and adjusted free cash flow do not purport to be alternatives to cash flows from operating activities as a measure of liquidity.  In particular, free cash flow and adjusted free cash flow are not intended to be a measure of cash flow available for management’s discretionary use, as these measures do not reflect certain cash requirements, such as debt service requirements and other contractual commitments.

[0001571996-24-000062:mdna:55]
The following table presents a reconciliation of free cash flow and adjusted free cash flow to cash from operating activities for the periods indicated:

[0001571996-24-000062:mdna:56]
|  |  |  | Three Months Ended |
|  |  |  |  |  |  |  | May 3, 2024 |  | % Change |  | May 5, 2023 |  |  |  |  |
|  |  |  |  |  |  |  | (in millions, except percentages) |  |  |  |  |
| Cash flow from operations |  |  |  |  |  |  | $ | 1,043 |  |  | (41) | % |  | $ | 1,777 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Capital expenditures and capitalized software development costs, net (a) |  |  |  |  |  |  | (586) |  |  |  |  | (698) |  |  |  |  |  |
| Free cash flow |  |  |  |  |  |  | $ | 457 |  |  | (58) | % |  | $ | 1,079 |  |  |  |  |  |
| Free cash flow |  |  |  |  |  |  | $ | 457 |  |  | (58) | % |  | $ | 1,079 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Financing receivables (b) |  |  |  |  |  |  | 165 |  |  |  |  | (367) |  |  |  |  |  |
| Equipment under operating leases (c) |  |  |  |  |  |  | 1 |  |  |  |  | (25) |  |  |  |  |  |
| Adjusted free cash flow |  |  |  |  |  |  | $ | 623 |  |  | (9) | % |  | $ | 687 |  |  |  |  |  |

[0001571996-24-000062:mdna:57]
[same as prior period, unchanged from 0001571996-23-000046:mdna:81]

[0001571996-24-000062:mdna:58]
(a)    Capital expenditures and capitalized software development costs, net include proceeds from sales of facilities, land, and other assets.

[0001571996-24-000062:mdna:59]
(b)    Financing receivables represent the operating cash flow impact from the change in DFS financing receivables.

[0001571996-24-000062:mdna:60]
(c)    Equipment under operating leases represents the net change of capital expenditures and depreciation expense for DFS leases and contractually embedded leases identified within flexible consumption arrangements.

[0001571996-24-000062:mdna:61]
59

[0001571996-24-000062:mdna:62]
[same as prior period, unchanged from 0001571996-23-000046:mdna:84]

[0001571996-24-000062:mdna:63]
[same as prior period, unchanged from 0001571996-23-000046:mdna:85]

[0001571996-24-000062:mdna:64]
[same as prior period, unchanged from 0001571996-23-000046:mdna:86]

[0001571996-24-000062:mdna:65]
|  |  |  | Three Months Ended |
|  |  |  |  |  |  |  | May 3, 2024 |  |  |  | May 5, 2023 |  |  |  |  |
|  |  |  |  |  |  |  |  |  |  |  | Dollars |  | % of Net Revenue |  | % Change |  | Dollars |  | % of Net Revenue |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |  |  |  | (in millions, except percentages and per share amounts) |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  |  |  |  |  |  |  |  |  |  | $ | 16,127 |  |  | 72.5 | % |  | 7 | % |  | $ | 15,036 |  |  | 71.9 | % |  |  |  |  |  |  |
| Services |  |  |  |  |  |  |  |  |  |  | 6,117 |  |  | 27.5 | % |  | 4 | % |  | 5,886 |  |  | 28.1 | % |  |  |  |  |  |  |
| Total net revenue |  |  |  |  |  |  |  |  |  |  | $ | 22,244 |  |  | 100.0 | % |  | 6 | % |  | $ | 20,922 |  |  | 100.0 | % |  |  |  |  |  |  |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  |  |  |  |  |  |  |  |  |  | $ | 2,361 |  |  | 14.6 | % |  | (11) | % |  | $ | 2,661 |  |  | 17.7 | % |  |  |  |  |  |  |
| Services |  |  |  |  |  |  |  |  |  |  | 2,445 |  |  | 40.0 | % |  | 4 | % |  | 2,357 |  |  | 40.0 | % |  |  |  |  |  |  |
| Total gross margin |  |  |  |  |  |  |  |  |  |  | $ | 4,806 |  |  | 21.6 | % |  | (4) | % |  | $ | 5,018 |  |  | 24.0 | % |  |  |  |  |  |  |
| Operating expenses |  |  |  |  |  |  |  |  |  |  | $ | 3,886 |  |  | 17.5 | % |  | (2) | % |  | $ | 3,949 |  |  | 19.0 | % |  |  |  |  |  |  |
| Operating income |  |  |  |  |  |  |  |  |  |  | $ | 920 |  |  | 4.1 | % |  | (14) | % |  | $ | 1,069 |  |  | 5.1 | % |  |  |  |  |  |  |
| Net income |  |  |  |  |  |  |  |  |  |  | $ | 955 |  |  | 4.3 | % |  | 65 | % |  | $ | 578 |  |  | 2.8 | % |  |  |  |  |  |  |
| Earnings per share attributable to Dell Technologies — diluted |  |  |  |  |  |  |  |  |  |  | $ | 1.32 |  |  |  |  | 67 | % |  | $ | 0.79 |  |  |  |  |  |  |  |  |  |
| Cash flow from operations |  |  |  |  |  |  |  |  |  |  | $ | 1,043 |  |  |  |  | (41) | % |  | $ | 1,777 |  |  |  |  |  |  |  |  |  |
| Non-GAAP Financial Information |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  |  | Three Months Ended |
|  |  |  |  |  |  |  | May 3, 2024 |  |  |  | May 5, 2023 |  |  |  |  |
|  |  |  |  |  |  |  |  |  |  |  | Dollars |  | % of Net Revenue |  | % Change |  | Dollars |  | % of Net Revenue |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |  |  |  | (in millions, except percentages and per share amounts) |
| Non-GAAP gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  |  |  |  |  |  |  |  |  |  | $ | 2,439 |  |  | 15.1 | % |  | (12) | % |  | $ | 2,761 |  |  | 18.4 | % |  |  |  |  |  |  |
| Services |  |  |  |  |  |  |  |  |  |  | 2,508 |  |  | 41.0 | % |  | 4 | % |  | 2,403 |  |  | 40.8 | % |  |  |  |  |  |  |
| Total non-GAAP gross margin |  |  |  |  |  |  |  |  |  |  | $ | 4,947 |  |  | 22.2 | % |  | (4) | % |  | $ | 5,164 |  |  | 24.7 | % |  |  |  |  |  |  |
| Non-GAAP operating expenses |  |  |  |  |  |  |  |  |  |  | $ | 3,473 |  |  | 15.6 | % |  | (3) | % |  | $ | 3,566 |  |  | 17.0 | % |  |  |  |  |  |  |
| Non-GAAP operating income |  |  |  |  |  |  |  |  |  |  | $ | 1,474 |  |  | 6.6 | % |  | (8) | % |  | $ | 1,598 |  |  | 7.6 | % |  |  |  |  |  |  |
| Non-GAAP net income |  |  |  |  |  |  |  |  |  |  | $ | 923 |  |  | 4.1 | % |  | (4) | % |  | $ | 963 |  |  | 4.6 | % |  |  |  |  |  |  |
| Non-GAAP earnings per share attributable to Dell Technologies — diluted |  |  |  |  |  |  |  |  |  |  | $ | 1.27 |  |  |  |  | (3) | % |  | $ | 1.31 |  |  |  |  |  |  |  |  |  |
| Free cash flow |  |  |  |  |  |  |  |  |  |  | $ | 457 |  |  |  |  | (58) | % |  | $ | 1,079 |  |  |  |  |  |  |  |  |  |
| Adjusted free cash flow |  |  |  |  |  |  |  |  |  |  | $ | 623 |  |  |  |  | (9) | % |  | $ | 687 |  |  |  |  |  |  |  |  |  |

[0001571996-24-000062:mdna:66]
Non-GAAP product gross margin, non-GAAP services gross margin, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, non-GAAP earnings per share attributable to Dell Technologies - diluted, free cash flow, and adjusted free cash flow are not measurements of financial performance prepared in accordance with GAAP.  See “Non‑GAAP Financial Measures” for additional information about these non-GAAP financial measures, including our reasons for including these measures, material limitations with respect to the usefulness of the measures, and a reconciliation of each non-GAAP financial measure to the most directly comparable GAAP financial measure.

[0001571996-24-000062:mdna:67]
60

[0001571996-24-000062:mdna:68]
[same as prior period, unchanged from 0001571996-23-000046:mdna:92]

[0001571996-24-000062:mdna:69]
During the first quarter of Fiscal 2025, net revenue increased by 6%, driven by an increase in ISG net revenue, that was partially offset by a decrease in other businesses net revenue.  The increase in ISG net revenue was primarily attributable to growth in our AI-optimized server offerings.  Other businesses net revenue declined primarily due to a decrease in VMware Resale revenue driven by the change in our distributor relationship with VMware.

[0001571996-24-000062:mdna:70]
Operating income and non-GAAP operating income decreased by 14% to $0.9 billion and 8% to $1.5 billion, respectively, during the first quarter of Fiscal 2025.  The declines were primarily driven by a decrease in CSG operating income from our commercial offerings and, to a lesser extent, our consumer offerings.

[0001571996-24-000062:mdna:71]
During the first three months of Fiscal 2025, both operating income and non-GAAP operating income as a percentage of net revenue decreased 100 basis points to 4.1% and 6.6%, respectively.  These decreases reflected a decline in gross margin as a percentage of net revenue, as a result of a competitive pricing environment coupled with a shift in mix towards AI-optimized server offerings. The decreases in operating income and non-GAAP operating income as a percentage of net revenue were offset by a decrease in operating expense rate that was driven by strong ISG net revenue growth coupled with continued disciplined cost management.

[0001571996-24-000062:mdna:72]
Cash provided by operating activities was $1.0 billion during the first three months of Fiscal 2025, and was primarily driven by profitability partially offset by annual incentive-based personnel-related payments.  Cash provided by operating activities was also impacted by other working capital dynamics, including strong cash collections performance, a shift in mix of the business, and timing of purchases and payments to vendors.  During the first three months of Fiscal 2024, cash provided by operating activities was $1.8 billion, which primarily reflected strong working capital performance as we reduced inventory and accounts receivable.  See “Liquidity, Cash Requirements, and Market Conditions” for additional information about our cash flow metrics.

[0001571996-24-000062:mdna:73]
We continue to see opportunities to create value and grow as we respond to long-term demand for our IT solutions driven by a data and AI-enabled world.  We have demonstrated our ability to adjust to changing market conditions with complementary solutions and innovation across both segments of our business, an agile workforce, and the strength of our global supply chain.  As we continue to innovate and modernize our offerings, we believe that Dell Technologies is well-positioned for long-term profitable growth.

[0001571996-24-000062:mdna:74]
[same as prior period, unchanged from 0001571996-23-000046:mdna:98]

[0001571996-24-000062:mdna:75]
During the first quarter of Fiscal 2025, net revenue increased 6%, primarily driven by an increase in ISG net revenue that was partially offset by a decrease in other businesses net revenue.  See “Business Unit Results” for further information.

[0001571996-24-000062:mdna:76]
•Product Net Revenue — Product net revenue includes revenue from the sale of hardware products and software licenses.  During the first quarter of Fiscal 2025, product net revenue increased 7%, due to an increase in ISG product net revenue, partially offset by a decline in CSG and other businesses product net revenue.  ISG product net revenue increased due to growth in our AI-optimized server offerings.  CSG product net revenue decreased as the decline in our average selling prices of our CSG offerings outpaced the favorable impact of an increase in units sold.  Other businesses product net revenue declined driven by the change in our distributor relationship with VMware.

[0001571996-24-000062:mdna:77]
•Services Net Revenue — Services net revenue includes revenue from our services offerings and support services related to hardware products and software licenses.  During the first quarter of Fiscal 2025, services net revenue increased 4%, driven primarily by growth within services net revenue attributable to CSG, partially offset by a decline in other businesses services net revenue.  The increase in CSG services net revenue was primarily attributable to third-party software support and maintenance and support and maintenance associated with products sold in prior periods.  Other businesses services net revenue declined driven by the change in our distributor relationship with VMware.

[0001571996-24-000062:mdna:78]
A substantial portion of services net revenue is derived from offerings that have been deferred over a period of time, and, as a result, reported growth rates for services net revenue will be different than reported growth rates for product net revenue.

[0001571996-24-000062:mdna:79]
From a geographical perspective, net revenue increased in the Americas and decreased in EMEA and APJ during the first quarter of Fiscal 2025.

[0001571996-24-000062:mdna:80]
[same as prior period, unchanged from 0001571996-23-000046:mdna:103]

[0001571996-24-000062:mdna:81]
During the first three months of Fiscal 2025, gross margin and non-GAAP gross margin both decreased 4% to $4.8 billion and $4.9 billion, respectively.  The declines in gross margin and non-GAAP gross margin were driven by a decrease in CSG gross margin that was primarily attributable to a competitive pricing environment.  The competitive pricing environment resulted in a decrease in the average selling prices of our CSG offerings that outpaced the favorable impact of an increase in units sold.

[0001571996-24-000062:mdna:82]
Gross margin and non-GAAP gross margin percentage decreased 240 basis points and 250 basis points to 21.6% and 22.2%, respectively, during the first three months of Fiscal 2025.  The decreases in gross margin percentage and non-GAAP gross margin percentage were driven by a competitive pricing environment coupled with a shift in mix towards AI-optimized server offerings.

[0001571996-24-000062:mdna:83]
•Product Gross Margin — During the first three months of Fiscal 2025, product gross margin and non-GAAP product gross margin decreased 11% and 12%, respectively, to $2.4 billion.  The decreases were primarily driven by a decline in CSG product gross margin, which was primarily attributable to the decline in the average selling prices of our CSG offerings as a result of a competitive pricing environment.

[0001571996-24-000062:mdna:84]
During the first three months of Fiscal 2025, product gross margin percentage and non-GAAP product gross margin percentage decreased 310 basis points and 330 basis points to 14.6% and 15.1%, respectively, due to a competitive pricing environment coupled with a decline in ISG product gross margin percentage due to a shift in mix towards AI-optimized server offerings.

[0001571996-24-000062:mdna:85]
•Services Gross Margin — During the first three months of Fiscal 2025, services gross margin and non-GAAP services gross margin both increased 4% to $2.4 billion and $2.5 billion, respectively.  The increases were primarily attributable to growth within CSG services gross margin that was driven by hardware and third-party software support and maintenance as well as support and maintenance associated with products sold in prior periods.

[0001571996-24-000062:mdna:86]
During the first three months of Fiscal 2025, services gross margin percentage remained flat at 40.0% and non-GAAP services gross margin percentage increased 20 basis points to 41.0%, primarily due to an increase in other businesses services gross margin percentage, which was offset by a decrease in CSG services gross margin percentage.

[0001571996-24-000062:mdna:87]
[same as prior period, unchanged from 0001571996-23-000046:mdna:112]

[0001571996-24-000062:mdna:88]
[same as prior period, unchanged from 0001571996-23-000046:mdna:113]

[0001571996-24-000062:mdna:89]
The terms and conditions of our vendor rebate programs are largely based on product volumes and are generally negotiated either at the beginning of the annual or quarterly period, depending on the program.  The timing and amount of vendor rebates and other discounts we receive under the programs may vary from period to period, reflecting changes in the competitive environment.  We monitor our component costs and seek to address the effects of any changes to terms that might arise under our vendor rebate programs.  Our gross margins for the first quarter of Fiscal 2025 were not materially affected by any changes to the terms of our vendor rebate programs, as the amounts we received under these programs were generally stable relative to our total net cost.  We are not aware of any significant changes to our vendor rebate programs that will materially impact our results in the near term.

[0001571996-24-000062:mdna:90]
[same as prior period, unchanged from 0001571996-23-000046:mdna:115]

[0001571996-24-000062:mdna:91]
[same as prior period, unchanged from 0001571996-23-000046:mdna:116]

[0001571996-24-000062:mdna:92]
|  |  |  | Three Months Ended |
|  |  |  |  |  |  |  | May 3, 2024 |  |  |  | May 5, 2023 |  |  |  |  |
|  |  |  |  |  |  |  |  |  |  |  | Dollars |  | % of Net Revenue |  | % Change |  | Dollars |  | % of Net Revenue |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |  |  |  | (in millions, except percentages) |  |  |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative |  |  |  |  |  |  |  |  |  |  | $ | 3,123 |  |  | 14.1 | % |  | (4) | % |  | $ | 3,261 |  |  | 15.7 | % |  |  |  |  |  |  |
| Research and development |  |  |  |  |  |  |  |  |  |  | 763 |  |  | 3.4 | % |  | 11 | % |  | 688 |  |  | 3.3 | % |  |  |  |  |  |  |
| Total operating expenses |  |  |  |  |  |  |  |  |  |  | $ | 3,886 |  |  | 17.5 | % |  | (2) | % |  | $ | 3,949 |  |  | 18.9 | % |  |  |  |  |  |  |
|  |  |  | Three Months Ended |
|  |  |  |  |  |  |  | May 3, 2024 |  |  |  | May 5, 2023 |  |  |  |  |
|  |  |  |  |  |  |  |  |  |  |  | Dollars |  | % of Net Revenue |  | % Change |  | Dollars |  | % of Net Revenue |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |  |  |  | (in millions, except percentages) |
| Non-GAAP operating expenses |  |  |  |  |  |  |  |  |  |  | $ | 3,473 |  |  | 15.6 | % |  | (3) | % |  | $ | 3,566 |  |  | 17.1 | % |  |  |  |  |  |  |

[0001571996-24-000062:mdna:93]
During the first quarter of Fiscal 2025, total operating expenses decreased 2%, due to a decline in selling, general, and administrative expenses.

[0001571996-24-000062:mdna:94]
•Selling, General, and Administrative — During the first quarter of Fiscal 2025, selling, general, and administrative (“SG&A”) expenses decreased 4%, driven by a decrease in employee compensation and benefits expense, principally due to a decline in overall headcount and, to a lesser extent, a decrease in advertising expenses as a result of continued disciplined cost management.

[0001571996-24-000062:mdna:95]
•Research and Development — Research and development (“R&D”) expenses are primarily composed of personnel-related expenses incurred in connection with product development.  R&D expenses increased 11% during the first quarter of Fiscal 2025, principally due to an increase in R&D-related employee compensation and benefits expense.

[0001571996-24-000062:mdna:96]
As a percentage of net revenue, R&D expenses for the first three months of Fiscal 2025 and Fiscal 2024 were 3.4% and 3.3%, respectively.  The increase in R&D expenses as a percentage of net revenue was attributable to continued support of R&D initiatives.

[0001571996-24-000062:mdna:97]
During the first quarter of Fiscal 2025, non-GAAP operating expenses decreased 3%, driven by a decline in employee compensation and benefits expense, primarily resulting from a decline in overall headcount, and advertising expenses due to continued disciplined cost management, partially offset by continued support of R&D initiatives.

[0001571996-24-000062:mdna:98]
We continue to make strategic investments designed to enable growth, marketing, and R&D, while balancing our efforts to drive cost efficiencies in the business.  We also expect to continue making investments in support of our own digital transformation which aims to streamline and optimize our business processes.

[0001571996-24-000062:mdna:99]
[same as prior period, unchanged from 0001571996-23-000046:mdna:124]

[0001571996-24-000062:mdna:100]
Operating income and non-GAAP operating income decreased by 14% to $0.9 billion and 8% to $1.5 billion, respectively, during the first quarter of Fiscal 2025.  The declines were primarily driven by a decrease in CSG operating income from our commercial offerings and, to a lesser extent, our consumer offerings.

[0001571996-24-000062:mdna:101]
During the first three months of Fiscal 2025, both operating income and non-GAAP operating income as a percentage of net revenue decreased 100 basis points to 4.1% and 6.6%, respectively.  These decreases reflected a decline in gross margin as a percentage of net revenue, as a result of a competitive pricing environment coupled with a shift in mix towards AI-optimized server offerings. The decreases in operating income and non-GAAP operating income as a percentage of net revenue were offset by a decrease in operating expense rate that was driven by strong ISG net revenue growth coupled with continued disciplined cost management.

[0001571996-24-000062:mdna:102]
[same as prior period, unchanged from 0001571996-23-000046:mdna:127]

[0001571996-24-000062:mdna:103]
[same as prior period, unchanged from 0001571996-23-000046:mdna:128]

[0001571996-24-000062:mdna:104]
|  | Three Months Ended |  |  |
|  | May 3, 2024 |  | May 5, 2023 |  |  |  |  |  |  |
|  | (in millions) |  |  |  |  |  |  |
| Interest and other, net: |  |  |  |  |  |  |  |  |  |
| Investment income, primarily interest | $ | 54 |  |  | $ | 59 |  |  |  |  |  |  |  |
| Loss on investments, net | (30) |  |  | (15) |  |  |  |  |  |  |  |
| Interest expense | (343) |  |  | (405) |  |  |  |  |  |  |  |
| Foreign exchange | (38) |  |  | (32) |  |  |  |  |  |  |  |
| Other | (16) |  |  | 29 |  |  |  |  |  |  |  |
| Total interest and other, net | $ | (373) |  |  | $ | (364) |  |  |  |  |  |  |  |

[0001571996-24-000062:mdna:105]
The change in interest and other, net was unfavorable, primarily as a result of an increase in debt extinguishment fees coupled with the impact of fair value adjustments on our non-marketable strategic investments portfolio during the first quarter of Fiscal 2025.  Unfavorable impacts within interest and other, net were partially offset by a reduction in interest expense.

[0001571996-24-000062:mdna:106]
[same as prior period, unchanged from 0001571996-23-000046:mdna:131]

[0001571996-24-000062:mdna:107]
[same as prior period, unchanged from 0001571996-23-000046:mdna:132]

[0001571996-24-000062:mdna:108]
|  |  |  | Three Months Ended |
|  |  |  |  |  | May 3, 2024 |  | May 5, 2023 |  |  |
|  |  |  |  |  | (in millions, except percentages) |  |  |
| Income before income taxes |  |  |  |  | $ | 547 |  |  | $ | 705 |  |  |  |
| Income tax expense (benefit) |  |  |  |  | $ | (408) |  |  | $ | 127 |  |  |  |
| Effective income tax rate |  |  |  |  | (74.6) | % |  | 18.0 | % |  |  |

[0001571996-24-000062:mdna:109]
For the first three months of Fiscal 2025 and Fiscal 2024, our effective income tax rate was (74.6)% and 18.0%, respectively.  The change in our effective income tax rate was primarily attributable to discrete tax benefits of $0.4 billion related to changes in uncertain tax benefits resulting from the expiration of certain statutes of limitations and $0.2 billion related to stock-based compensation.

[0001571996-24-000062:mdna:110]
Our effective income tax rate can fluctuate depending on the geographic distribution of our worldwide earnings, as our foreign earnings are generally taxed at lower rates than in the United States.  The differences between our effective income tax rates and the U.S. federal statutory rate of 21% principally result from the geographical distribution of income, differences between the book and tax treatment of certain items, and discrete tax items.  In certain jurisdictions, our tax rate is significantly less than the applicable statutory rate as a result of tax holidays.  The majority of our foreign income subject to these tax holidays is attributable to Singapore and China.  A significant portion of these income tax benefits relates to a tax holiday that will be effective until January 31, 2029.  Most of our other tax holidays will expire in whole or in part during Fiscal 2030 and Fiscal 2031.  Many of these tax holidays and reduced tax rates may be extended when certain conditions are met or may be terminated early if certain conditions are not met or as a result of changes in tax legislation.  As of May 3, 2024, we were not aware of any matters of non-compliance or enacted tax legislative changes affecting these tax holidays.

[0001571996-24-000062:mdna:111]
Many countries have enacted or are in the process of enacting laws based on the Pillar Two proposal relating to global minimum tax issued by the Organisation for Economic Co-operation and Development (“OECD”).  While we expect our effective income tax rate and cash income tax payments could increase in future years as a result of the global minimum tax, we do not expect it will have a material impact to our Fiscal 2025 consolidated results of operations.  Our assessment could be affected by legislative guidance and future enactment of additional provisions within the Pillar Two framework, particularly in countries in which we have tax holidays and incentives.

[0001571996-24-000062:mdna:112]
[same as prior period, unchanged from 0001571996-23-000046:mdna:137]

[0001571996-24-000062:mdna:113]
[same as prior period, unchanged from 0001571996-23-000046:mdna:138]

[0001571996-24-000062:mdna:114]
During the first quarter of Fiscal 2025, net income increased 65% to $1.0 billion, driven primarily by the impact of an income tax benefit, which was partially offset by a decline in operating income.

[0001571996-24-000062:mdna:115]
During the first quarter of Fiscal 2025, non-GAAP net income decreased 4% to $0.9 billion, driven by a decline in operating income, which was partially offset by a decline in income tax expense.

[0001571996-24-000062:mdna:116]
[same as prior period, unchanged from 0001571996-23-000046:mdna:74]

[0001571996-24-000062:mdna:117]
[same as prior period, unchanged from 0001571996-23-000046:mdna:142]

[0001571996-24-000062:mdna:118]
[same as prior period, unchanged from 0001571996-23-000046:mdna:143]

[0001571996-24-000062:mdna:119]
[same as prior period, unchanged from 0001571996-23-000046:mdna:144]

[0001571996-24-000062:mdna:120]
[same as prior period, unchanged from 0001571996-23-000046:mdna:145]

[0001571996-24-000062:mdna:121]
|  |  |  | Three Months Ended |
|  |  |  |  |  |  |  | May 3, 2024 |  | % Change |  | May 5, 2023 |  |  |  |  |
|  |  |  |  |  |  |  | (in millions, except percentages) |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Servers and networking |  |  |  |  |  |  | $ | 5,466 |  | 42 | % |  | $ | 3,837 |  |  |  |  |
| Storage |  |  |  |  |  |  | 3,761 |  | — | % |  | 3,756 |  |  |  |  |
| Total ISG net revenue |  |  |  |  |  |  | $ | 9,227 |  | 22 | % |  | $ | 7,593 |  |  |  |  |
| Operating income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| ISG operating income |  |  |  |  |  |  | $ | 736 |  | (1) | % |  | $ | 740 |  |  |  |  |
| % of segment net revenue |  |  |  |  |  |  | 8.0 | % |  |  |  | 9.7 | % |  |  |  |  |

[0001571996-24-000062:mdna:122]
Net Revenue — During the first quarter of Fiscal 2025, ISG net revenue increased 22% driven by strength in our servers and networking offerings.

[0001571996-24-000062:mdna:123]
Revenue from sales of servers and networking increased 42% and storage revenue remained flat during the first quarter of Fiscal 2025.  The increase in servers and networking revenue was driven by growth in our AI-optimized server offerings.

[0001571996-24-000062:mdna:124]
From a geographical perspective, net revenue attributable to ISG increased most notably in the Americas and, to a lesser extent, in APJ, and decreased in EMEA during the first quarter of Fiscal 2025.

[0001571996-24-000062:mdna:125]
Operating Income — During the first quarter of Fiscal 2025, ISG operating income as a percentage of net revenue decreased 170 basis points to 8.0%, principally due to a decrease in gross margin rate as a percentage of net revenue.  Gross margin rate decreased as a result of a competitive pricing environment coupled with a shift in mix towards AI-optimized server offerings.  The decrease in gross margin as a percentage of net revenue was offset by a decrease in operating expense as a percentage of net revenue primarily due to continued disciplined cost management.

[0001571996-24-000062:mdna:126]
[same as prior period, unchanged from 0001571996-23-000046:mdna:153]

[0001571996-24-000062:mdna:127]
[same as prior period, unchanged from 0001571996-23-000046:mdna:154]

[0001571996-24-000062:mdna:128]
|  |  |  | Three Months Ended |
|  |  |  |  |  |  |  | May 3, 2024 |  | % Change |  | May 5, 2023 |  |  |  |  |
|  |  |  |  |  |  |  | (in millions, except percentages) |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial |  |  |  |  |  |  | $ | 10,154 |  | 3 | % |  | $ | 9,862 |  |  |  |  |
| Consumer |  |  |  |  |  |  | 1,813 |  | (15) | % |  | 2,121 |  |  |  |  |
| Total CSG net revenue |  |  |  |  |  |  | $ | 11,967 |  | — | % |  | $ | 11,983 |  |  |  |  |
| Operating income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| CSG operating income |  |  |  |  |  |  | $ | 732 |  | (18) | % |  | $ | 892 |  |  |  |  |
| % of segment net revenue |  |  |  |  |  |  | 6.1 | % |  |  |  | 7.4 | % |  |  |  |  |

[0001571996-24-000062:mdna:129]
Net Revenue — During the first quarter of Fiscal 2025, CSG net revenue was flat as the impact of an increase in units sold was offset by a decrease in the average selling prices of our offerings due to a competitive pricing environment.

[0001571996-24-000062:mdna:130]
Commercial net revenue increased 3% during the first quarter of Fiscal 2025.  The increase was primarily due to an increase in units sold which was partially offset by the decrease in the average selling prices of our commercial offerings.

[0001571996-24-000062:mdna:131]
Consumer net revenue decreased 15% during the first quarter of Fiscal 2025, principally due to a decline in the average selling price of our consumer offerings.

[0001571996-24-000062:mdna:132]
From a geographical perspective, net revenue attributable to CSG decreased in APJ, and increased in EMEA and the Americas during the first quarter of Fiscal 2025.

[0001571996-24-000062:mdna:133]
Operating Income — During the first three months of Fiscal 2025, CSG operating income as a percentage of net revenue decreased 130 basis points to 6.1%, primarily due to a decrease in the average selling prices of our offerings as a result of a competitive pricing environment.  The impact of these factors was offset by a decrease in operating expenses as a percentage of net revenue, which declined as a result of continued disciplined cost management.

[0001571996-24-000062:mdna:134]
[same as prior period, unchanged from 0001571996-23-000046:mdna:83]

[0001571996-24-000062:mdna:135]
[same as prior period, unchanged from 0001571996-23-000046:mdna:162]

[0001571996-24-000062:mdna:136]
[same as prior period, unchanged from 0001571996-23-000046:mdna:163]

[0001571996-24-000062:mdna:137]
We sell products and services directly to customers and through a variety of sales channels, including retail distribution.  Our accounts receivable, net, was $8.6 billion and $9.3 billion as of May 3, 2024 and February 2, 2024, respectively.  The reduction in accounts receivable, net, was driven primarily by strong cash collections performance.  We maintain an allowance for expected credit losses to cover receivables that may be deemed uncollectible.  The allowance for expected credit losses is an estimate based on an analysis of historical loss experience, current receivables aging, and management’s assessment of current conditions and its reasonable and supportable expectation of future conditions, as well as specific identifiable customer accounts that are deemed at risk.  As of May 3, 2024 and February 2, 2024, the allowance for expected credit losses was $66 million and $71 million, respectively.  Based on our assessment, we believe that we are adequately reserved for expected credit losses.

[0001571996-24-000062:mdna:138]
[same as prior period, unchanged from 0001571996-23-000046:mdna:165]

[0001571996-24-000062:mdna:139]
We offer or arrange various financing options and services for our customers globally, including through captive financing operations.  DFS originates, collects, and services customer receivables primarily related to the purchase of our product, software, and service solutions.  We further strengthen customer relationships through flexible consumption models, including utility, subscription, and as-a-Service models, which enable our customers the option to pay over time to provide them with financial and operational flexibility.  New financing originations were $1.9 billion and $1.8 billion for the first quarter of Fiscal 2025 and Fiscal 2024, respectively.

[0001571996-24-000062:mdna:140]
[same as prior period, unchanged from 0001571996-23-000046:mdna:167]

[0001571996-24-000062:mdna:141]
As of May 3, 2024 and February 2, 2024, our financing receivables, net were $10.6 billion and $10.5 billion, respectively.  We maintain an allowance to cover expected financing receivable credit losses and evaluate credit loss expectations based on our total portfolio.  For the first quarter of Fiscal 2025 and Fiscal 2024, the principal charge-off rate for our financing receivables portfolio was 0.3% and 0.5%, respectively.  The credit quality of our financing receivables remains strong due to the mix of high-quality commercial accounts in our portfolio.  We continue to monitor broader economic indicators and their potential impact on future credit loss performance.  We have an extensive process to manage our exposure to customer credit risk, including active management of credit lines and our collection activities.  We also sell selected fixed-term financing receivables without recourse to unrelated third parties on a periodic basis, primarily to manage certain concentrations of customer credit exposure.  Based on our assessment of the customer financing receivables, we believe that we are adequately reserved.

[0001571996-24-000062:mdna:142]
We retain a residual interest in equipment leased under our lease programs.  As of May 3, 2024 and February 2, 2024, the residual interest recorded as part of financing receivables was $163 million and $157 million, respectively.  The amount of the residual interest is established at the inception of the lease based upon estimates of the value of the equipment at the end of the lease term using historical studies, industry data, and future value-at-risk demand valuation methods.  On a quarterly basis, we assess the carrying amount of our recorded residual values for expected losses.  Generally, expected losses as a result of residual value risk on equipment under lease are not considered to be significant primarily because of the existence of a secondary market with respect to the equipment.  Further, the lease agreement defines applicable return conditions and remedies for non-compliance to ensure that the leased equipment will be in good operating condition upon return.  No expected losses were recorded related to residual assets during the first quarter of Fiscal 2025 and Fiscal 2024.

[0001571996-24-000062:mdna:143]
As of May 3, 2024 and February 2, 2024, equipment under operating leases, net was $2.1 billion and $2.2 billion, respectively.  We assess the carrying amount of the equipment under operating leases for impairment whenever events or circumstances may indicate that an impairment has occurred.  No material impairment losses were recorded related to such equipment during the first quarter of Fiscal 2025 and Fiscal 2024.

[0001571996-24-000062:mdna:144]
[same as prior period, unchanged from 0001571996-23-000046:mdna:171]

[0001571996-24-000062:mdna:145]
[same as prior period, unchanged from 0001571996-23-000046:mdna:172]

[0001571996-24-000062:mdna:146]
69

[0001571996-24-000062:mdna:147]
[same as prior period, unchanged from 0001571996-23-000046:mdna:174]

[0001571996-24-000062:mdna:148]
[same as prior period, unchanged from 0001571996-23-000046:mdna:175]

[0001571996-24-000062:mdna:149]
[same as prior period, unchanged from 0001571996-23-000046:mdna:176]

[0001571996-24-000062:mdna:150]
[same as prior period, unchanged from 0001571996-23-000046:mdna:177]

[0001571996-24-000062:mdna:151]
We believe that our current cash and cash equivalents, together with cash that will be provided by future operations and borrowings and issuances expected to be available under our revolving credit facility and commercial paper program, respectively, will be sufficient over the next twelve months and for the foreseeable future thereafter to meet our material cash requirements, including funding of our operations, debt-related payments, capital expenditures, and other corporate needs.

[0001571996-24-000062:mdna:152]
As part of our overall capital allocation strategy, we intend to return capital to our stockholders through both share repurchase programs and dividend payments and use the remaining available cash to drive growth and maintain our investment grade credit rating.

[0001571996-24-000062:mdna:153]
[same as prior period, unchanged from 0001571996-23-000046:mdna:180]

[0001571996-24-000062:mdna:154]
|  | May 3, 2024 |  | February 2, 2024 |
|  | (in millions) |
| Cash and cash equivalents, and available borrowings: |  |  |  |
| Cash and cash equivalents | $ | 5,830 |  |  | $ | 7,366 |  |
| Remaining available borrowings under the revolving credit facility | 5,999 |  |  | 5,999 |  |
| Total cash and cash equivalents, and available borrowings | $ | 11,829 |  |  | $ | 13,365 |  |

[0001571996-24-000062:mdna:155]
During the first three months of Fiscal 2025, cash and cash equivalents decreased by $1.5 billion primarily due to the return of capital to our stockholders, capital expenditures, payments to settle employee tax withholdings, and net repayment of DFS debt, the effect of which was partially offset by cash flows from operations.

[0001571996-24-000062:mdna:156]
As of May 3, 2024, our revolving credit facility had a maximum capacity of $6.0 billion.  Available borrowings under this facility are reduced by draws on the facility and outstanding letters of credit.  As of May 3, 2024, there were no borrowings outstanding under the facility and remaining available borrowings totaled approximately $6.0 billion.  The revolving credit facility also acts as a backstop to provide liquidity support for our commercial paper program.

[0001571996-24-000062:mdna:157]
We maintain a commercial paper program under which we may issue unsecured notes in a maximum aggregate face amount of $5.0 billion outstanding at any time, with maturities up to 397 days from the date of issue.  As of May 3, 2024, we had no outstanding issuances under the program.

[0001571996-24-000062:mdna:158]
We may regularly use our available borrowings from the revolving credit facility and issuances under the commercial paper program on a short-term basis for general corporate purposes.  See the following discussion for additional information about our debt.

[0001571996-24-000062:mdna:159]
[same as prior period, unchanged from 0001571996-23-000046:mdna:186]

[0001571996-24-000062:mdna:160]
[same as prior period, unchanged from 0001571996-23-000046:mdna:187]

[0001571996-24-000062:mdna:161]
|  | May 3, 2024 |  | Change |  | February 2, 2024 |
|  | (in millions) |
| Core debt |  |  |  |  |  |
| Senior Notes | $ | 15,607 |  |  | $ | — |  |  | $ | 15,607 |  |
| Legacy Notes | 952 |  |  | — |  |  | 952 |  |
| DFS allocated debt | (2,097) |  |  | (457) |  |  | (1,640) |  |
| Total core debt | 14,462 |  |  | (457) |  |  | 14,919 |  |
| DFS related debt |  |  |  |  |  |
| DFS debt | 9,038 |  |  | (454) |  |  | 9,492 |  |
| DFS allocated debt | 2,097 |  |  | 457 |  |  | 1,640 |  |
| Total DFS related debt | 11,135 |  |  | 3 |  |  | 11,132 |  |
| Other | 108 |  |  | (63) |  |  | 171 |  |
| Total debt, principal amount | 25,705 |  |  | (517) |  |  | 26,222 |  |
| Carrying value adjustments | (225) |  |  | 3 |  |  | (228) |  |
| Total debt, carrying value | $ | 25,480 |  |  | $ | (514) |  |  | $ | 25,994 |  |

[0001571996-24-000062:mdna:162]
The outstanding principal amount of our debt decreased $0.5 billion to $25.7 billion as of May 3, 2024, driven primarily by net repayments on DFS debt.

[0001571996-24-000062:mdna:163]
We define core debt as the total principal amount of our debt, less DFS related debt and other debt.  Our core debt was $14.5 billion and $14.9 billion as of May 3, 2024 and February 2, 2024, respectively.  See Note 6 of the Notes to the Condensed Consolidated Financial Statements included in this report for additional information about our debt.

[0001571996-24-000062:mdna:164]
[same as prior period, unchanged from 0001571996-23-000046:mdna:191]

[0001571996-24-000062:mdna:165]
To fund expansion of the DFS business, we balance the use of the securitization and structured financing programs with other sources of liquidity.  We approximate the amount of our core debt used to fund the DFS business by applying a 7:1 debt-to-equity ratio to the sum of our financing receivables balance and equipment under operating leases, net.  The debt-to-equity ratio is based on the underlying credit quality of the assets.  See Note 4 of the Notes to the Condensed Consolidated Financial Statements included in this report for additional information about our DFS debt.

[0001571996-24-000062:mdna:166]
We believe we will continue to be able to make our debt principal and interest payments, including payment of short-term maturities, from existing and expected sources of cash, primarily from operating cash flows.  Cash used for debt principal and interest payments may include short-term borrowings under our commercial paper program, our revolving credit facility, or other borrowings.  Under our variable-rate debt, we could experience variations in our future interest expense from potential fluctuations in applicable reference rates, or from possible fluctuations in the level of DFS debt required to meet future demand for customer financing.

[0001571996-24-000062:mdna:167]
[same as prior period, unchanged from 0001571996-23-000046:mdna:194]

[0001571996-24-000062:mdna:168]
[same as prior period, unchanged from 0001571996-23-000046:mdna:195]

[0001571996-24-000062:mdna:169]
[same as prior period, unchanged from 0001571996-23-000046:mdna:196]

[0001571996-24-000062:mdna:170]
|  | Three Months Ended |
|  | May 3, 2024 |  | May 5, 2023 |  |  |
|  | (in millions) |
| Net change in cash from: |  |  |  |  |  |
| Operating activities | $ | 1,043 |  |  | $ | 1,777 |  |  |  |
| Investing activities | (456) |  |  | (684) |  |  |  |
| Financing activities | (2,077) |  |  | (2,002) |  |  |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash | (55) |  |  | (58) |  |  |  |
| Change in cash, cash equivalents, and restricted cash | $ | (1,545) |  |  | $ | (967) |  |  |  |

[0001571996-24-000062:mdna:171]
Operating Activities — Cash provided by operating activities was $1.0 billion during the first three months of Fiscal 2025, and was primarily driven by profitability, partially offset by annual incentive-based personnel-related payments.  Cash provided by operating activities was also impacted by other working capital dynamics, including strong cash collections performance, a shift in mix of the business, and timing of purchases and payments to vendors.  During the first three months of Fiscal 2024, cash provided by operating activities was $1.8 billion, which primarily reflected strong working capital performance as we reduced inventory and accounts receivable.  The impact of strong working capital performance was partially offset by the effect of a decline in revenue and annual incentive-based personnel-related payments.

[0001571996-24-000062:mdna:172]
Investing Activities — Investing activities primarily consist of cash used to fund capital expenditures for property, plant, and equipment inclusive of equipment under DFS operating leases and equipment used to support our as-a-Service offerings, which we refer to collectively as assets in a customer contract.  Additional activities may include capitalized software development costs, acquisitions and divestitures, and the maturities, sales, and purchases of investments.  Cash used in investing activities was $0.5 billion and $0.7 billion during the first three months of Fiscal 2025 and Fiscal 2024, respectively, and was primarily applied to capital expenditures.

[0001571996-24-000062:mdna:173]
Financing Activities — Financing activities primarily consist of the proceeds and repayments of debt and return of capital to our stockholders.  Cash used in financing activities was $2.1 billion during the first three months of Fiscal 2025 and primarily consisted of repurchases of common stock, inclusive of payments to settle employee tax withholdings on stock-based compensation, net repayments on DFS debt, and the payment of quarterly dividends.  During the first three months of Fiscal 2024, cash used in financing activities was $2.0 billion and primarily consisted of principal repayments of our senior notes, repurchases of common stock, inclusive of payments to settle employee tax withholdings on stock-based compensation, and the payment of quarterly dividends.

[0001571996-24-000062:mdna:174]
DFS Cash Flow Impacts — DFS offerings are initially funded through cash on hand at the time of origination, most of which is subsequently replaced with asset-backed financing.  For DFS offerings that qualify as sales-type leases, the initial funding of financing receivables is reflected as an impact to cash flows from operations and is largely subsequently offset by cash proceeds from financing.  For operating leases, the initial funding is classified as a capital expenditure and reflected as cash flows used in investing activities.  DFS new financing originations were $1.9 billion and $1.8 billion during the first three months of Fiscal 2025 and Fiscal 2024, respectively.  As of May 3, 2024, we had $10.6 billion of total net financing receivables and $2.1 billion of equipment under operating leases, net.

[0001571996-24-000062:mdna:175]
Supply Chain Finance Program — We maintain a Supply Chain Finance Program (the “SCF Program”) that enables eligible suppliers to sell receivables due from us to a third-party financial institution at the suppliers’ sole discretion.  The SCF Program does not impact our liquidity, as payments by us to participating suppliers are remitted to the financial institution on the original invoice due date.  Further, we negotiate payment terms with our suppliers regardless of their decision to participate in the SCF Program.  Payments made under the SCF Program are included in cash flows from operating activities on the Condensed Consolidated Statements of Cash Flows.  See Note 17 of the Notes to the Condensed Consolidated Financial Statements included in this report for more information regarding the SCF Program.

[0001571996-24-000062:mdna:176]
[same as prior period, unchanged from 0001571996-23-000046:mdna:203]

[0001571996-24-000062:mdna:177]
Capital Expenditures — We spent $0.6 billion and $0.7 billion during the first three months of Fiscal 2025 and Fiscal 2024, respectively, on property, plant, and equipment and capitalized software development costs.  Of total expenditures incurred, funding of assets in a customer contract totaled $0.3 billion during both the first three months of Fiscal 2025 and Fiscal 2024.  Product demand, product mix, the use of contract manufacturers, and ongoing investments in operating and information technology infrastructure influence the level and prioritization of our capital expenditures.

[0001571996-24-000062:mdna:178]
Repurchases of Common Stock — Effective as of September 23, 2021, our Board of Directors approved a stock repurchase program with no fixed expiration date under which we are authorized to repurchase up to $5.0 billion of shares of our Class C Common Stock.  Effective as of October 5, 2023, the Board of Directors approved the repurchase of an additional $5.0 billion of shares of the Class C Common Stock with no fixed expiration date.  Following the additional approval, we had approximately $5.7 billion in cumulative authorized amount remaining under the stock repurchase program.

[0001571996-24-000062:mdna:179]
During the first three months of Fiscal 2025, we repurchased approximately 6.7 million shares of Class C Common Stock for a total purchase price of approximately $0.7 billion.  During the first three months of Fiscal 2024, we repurchased approximately 6.1 million shares of Class C Common Stock for a total purchase price of approximately $0.3 billion.

[0001571996-24-000062:mdna:180]
Dividend Payments — On February 29, 2024, we announced that the Board of Directors approved a 20% increase in the dividend rate to $0.445 per share per fiscal quarter beginning in the first quarter of Fiscal 2025.  During both the first three months of Fiscal 2025 and Fiscal 2024, the Company paid $0.3 billion, in dividends and dividend equivalents at a rate of $0.445 and $0.37 per share per fiscal quarter, respectively.

[0001571996-24-000062:mdna:181]
[same as prior period, unchanged from 0001571996-23-000046:mdna:208]

[0001571996-24-000062:mdna:182]
[same as prior period, unchanged from 0001571996-23-000046:mdna:209]

[0001571996-24-000062:mdna:183]
[same as prior period, unchanged from 0001571996-23-000046:mdna:210]

[0001571996-24-000062:mdna:184]
[same as prior period, unchanged from 0001571996-23-000046:mdna:211]

[0001571996-24-000062:mdna:185]
[same as prior period, unchanged from 0001571996-23-000046:mdna:212]

[0001571996-24-000062:mdna:186]
[same as prior period, unchanged from 0001571996-23-000046:mdna:213]

[0001571996-24-000062:mdna:187]
[same as prior period, unchanged from 0001571996-23-000046:mdna:214]

[0001571996-24-000062:mdna:188]
[same as prior period, unchanged from 0001571996-23-000046:mdna:141]

[0001571996-24-000062:mdna:189]
[same as prior period, unchanged from 0001571996-23-000046:mdna:216]

[0001571996-24-000062:mdna:190]
The Company’s outstanding senior notes (“Senior Notes”) are registered, unsecured, and issued by Dell International L.L.C. and EMC Corporation (the “Issuers”), both of which are wholly-owned subsidiaries of Dell Technologies Inc.  The Senior Notes are guaranteed on a joint and several unsecured basis by Dell Technologies Inc. and its wholly-owned subsidiaries, Denali Intermediate, Inc. and Dell Inc. (collectively, the “Guarantors”).

[0001571996-24-000062:mdna:191]
Basis of Preparation of the Summarized Financial Information — The tables below are summarized financial information provided in conformity with Rule 13-01 of the SEC’s Regulation S-X.  The summarized financial information of the Issuers and Guarantors (collectively, the “Obligor Group”) is presented on a combined basis, excluding intercompany balances and transactions between entities in the Obligor Group.  The Obligor Group’s investment balances in Non-Obligor Subsidiaries have been excluded.  The Obligor Group’s amounts due from, amounts due to, and transactions with Non-Obligor Subsidiaries have been presented separately.

[0001571996-24-000062:mdna:192]
[same as prior period, unchanged from 0001571996-23-000046:mdna:222]

[0001571996-24-000062:mdna:193]
|  | Three Months Ended |
|  | May 3, 2024 |
|  | (in millions) |
| Net revenue (a) | $ | 2,103 |  |
| Gross margin (b) | 1,098 |  |
| Operating income (c) | 185 |  |
| Interest and other, net (d) | (1,093) |  |
| Loss before income taxes | $ | (908) |  |
| Net loss attributable to Obligor Group | $ | (613) |  |

[0001571996-24-000062:mdna:194]
[same as prior period, unchanged from 0001571996-23-000046:mdna:88]

[0001571996-24-000062:mdna:195]
(a)    Includes net revenue from services provided to Non-Obligor Subsidiaries of $197 million.

[0001571996-24-000062:mdna:196]
(b)    Includes cost of net revenue from the resale of solutions purchased from Non-Obligor Subsidiaries of $284 million.

[0001571996-24-000062:mdna:197]
(c)    Includes operating expenses from shared services provided by Non-Guarantor Subsidiaries of $117 million.

[0001571996-24-000062:mdna:198]
(d)    Includes interest expense on intercompany loan payables of $785 million.

[0001571996-24-000062:mdna:199]
[same as prior period, unchanged from 0001571996-23-000046:mdna:229]

[0001571996-24-000062:mdna:200]
|  | May 3, 2024 |  | February 2, 2024 |
|  | (in millions) |
| ASSETS |
| Current assets | $ | 2,497 |  |  | $ | 2,631 |  |
| Intercompany receivables | — |  |  | 281 |  |
| Short-term intercompany loan receivables | 134 |  |  | 92 |  |
| Total current assets | 2,631 |  |  | 3,004 |  |
| Goodwill and intangible assets | 14,354 |  |  | 14,447 |  |
| Other non-current assets | 3,409 |  |  | 3,437 |  |
| Total assets | $ | 20,394 |  |  | $ | 20,888 |  |
| LIABILITIES |
| Current liabilities | $ | 4,833 |  |  | $ | 5,255 |  |
| Intercompany payable | 468 |  |  | — |  |
| Total current liabilities | 5,301 |  |  | 5,255 |  |
| Long-term debt | 15,354 |  |  | 15,353 |  |
| Intercompany loan payables | 41,628 |  |  | 41,617 |  |
| Other non-current liabilities | 3,266 |  |  | 3,473 |  |
| Total liabilities | $ | 65,549 |  |  | $ | 65,698 |  |

[0001571996-24-000062:mdna:201]
76
