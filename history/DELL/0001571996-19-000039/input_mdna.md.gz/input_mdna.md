# DELL MD&A — 0001571996-19-000039


## mdna

[0001571996-19-000039:mdna:1]
[same as prior period, unchanged from 0001571996-19-000025:mdna:1]

[0001571996-19-000039:mdna:2]
[same as prior period, unchanged from 0001571996-19-000025:mdna:2]

[0001571996-19-000039:mdna:3]
[same as prior period, unchanged from 0001571996-19-000025:mdna:3]

[0001571996-19-000039:mdna:4]
[same as prior period, unchanged from 0001571996-19-000025:mdna:4]

[0001571996-19-000039:mdna:5]
[same as prior period, unchanged from 0001571996-19-000025:mdna:5]

[0001571996-19-000039:mdna:6]
Dell Technologies is a leading global end-to-end technology provider, with a comprehensive portfolio of IT hardware, software, and service solutions spanning both traditional infrastructure and emerging multi-cloud technologies that enable our customers to build their digital future and transform how they work and live.  We collaborate across key functional areas such as technology and product development and solutions, marketing, go-to-market and global services, and are supported by Dell Financial Services.  We believe this operational philosophy enables our platform to seamlessly deliver differentiated and holistic IT solutions to our customers, which has driven significant revenue growth and share gains.

[0001571996-19-000039:mdna:7]
[same as prior period, unchanged from 0001571996-19-000025:mdna:7]

[0001571996-19-000039:mdna:8]
[same as prior period, unchanged from 0001571996-19-000025:mdna:8]

[0001571996-19-000039:mdna:9]
[same as prior period, unchanged from 0001571996-19-000025:mdna:9]

[0001571996-19-000039:mdna:10]
[same as prior period, unchanged from 0001571996-19-000025:mdna:10]

[0001571996-19-000039:mdna:11]
[same as prior period, unchanged from 0001571996-19-000025:mdna:11]

[0001571996-19-000039:mdna:12]
[same as prior period, unchanged from 0001571996-19-000025:mdna:12]

[0001571996-19-000039:mdna:13]
[same as prior period, unchanged from 0001571996-19-000025:mdna:13]

[0001571996-19-000039:mdna:14]
[same as prior period, unchanged from 0001571996-19-000025:mdna:14]

[0001571996-19-000039:mdna:15]
[same as prior period, unchanged from 0001571996-19-000025:mdna:15]

[0001571996-19-000039:mdna:16]
[same as prior period, unchanged from 0001571996-19-000025:mdna:16]

[0001571996-19-000039:mdna:17]
[same as prior period, unchanged from 0001571996-19-000025:mdna:17]

[0001571996-19-000039:mdna:18]
[same as prior period, unchanged from 0001571996-19-000025:mdna:18]

[0001571996-19-000039:mdna:19]
| • | Pivotal (NYSE: PVTL) provides a leading cloud-native platform that makes software development and IT operations a strategic advantage for customers. Pivotal’s cloud-native platform, Pivotal Cloud Foundry, accelerates and streamlines software development by reducing the complexity of building, deploying, and operating new cloud-native applications and modernizing legacy applications. On April 24, 2018, Pivotal completed a registered underwritten initial public offering of its Class A common stock. On August 22, 2019, Pivotal entered into a definitive merger agreement pursuant to which VMware, Inc. will acquire Pivotal. For more information on our ownership of Pivotal and Pivotal’s merger agreement with VMware, Inc., refer to Note 13 and Note 20 of the Notes to the Condensed Consolidated Financial Statements. |

[0001571996-19-000039:mdna:20]
[same as prior period, unchanged from 0001571996-19-000025:mdna:20]

[0001571996-19-000039:mdna:21]
[same as prior period, unchanged from 0001571996-19-000025:mdna:21]

[0001571996-19-000039:mdna:22]
[same as prior period, unchanged from 0001571996-19-000025:mdna:22]

[0001571996-19-000039:mdna:23]
[same as prior period, unchanged from 0001571996-19-000025:mdna:23]

[0001571996-19-000039:mdna:24]
We recently unveiled the Dell Technologies Cloud, a new set of cloud infrastructure solutions to make hybrid cloud environments simpler to deploy and manage.  The Dell Technologies Cloud portfolio consists of the new Dell Technologies Cloud Platforms and the new Data Center-as-a-Service offering, VMware Cloud on Dell EMC.  These solutions enable a flexible range of IT and management options with tight integration and a single vendor experience for purchasing, deployment, services, and financing, giving customers more control as the operational hub of their hybrid clouds.

[0001571996-19-000039:mdna:25]
We believe the increasing collaboration, innovation, and coordination of the operations and strategies of our businesses, as well as our differentiated go-to-market model, will continue to drive revenue synergies.  Through our coordinated research and development activities, we are able to jointly engineer leading innovative solutions that incorporate the distinct set of hardware, software, and services across our businesses.

[0001571996-19-000039:mdna:26]
[same as prior period, unchanged from 0001571996-19-000025:mdna:25]

[0001571996-19-000039:mdna:27]
[same as prior period, unchanged from 0001571996-19-000025:mdna:26]

[0001571996-19-000039:mdna:28]
[same as prior period, unchanged from 0001571996-19-000025:mdna:27]

[0001571996-19-000039:mdna:29]
[same as prior period, unchanged from 0001571996-19-000025:mdna:29]

[0001571996-19-000039:mdna:30]
As part of our strategy, we will continue to evaluate opportunities for strategic investments through our venture capital investment arm, Dell Technologies Capital, with a focus on emerging technology areas that are relevant to the Dell Technologies unique family of businesses and that will complement our existing portfolio of solutions.  Our investment areas include storage, software-defined networking, management and orchestration, security, machine learning and artificial intelligence, Big Data and analytics, cloud, Internet of Things (“IoT”), and software development operations.  In addition to these investments, we also may make disciplined acquisitions targeting businesses that advance our strategic objectives.  As of August 2, 2019 and February 1, 2019, Dell Technologies held strategic investments of $0.8 billion and $1.0 billion, respectively.

[0001571996-19-000039:mdna:31]
[same as prior period, unchanged from 0001571996-19-000025:mdna:31]

[0001571996-19-000039:mdna:32]
[same as prior period, unchanged from 0001571996-19-000025:mdna:32]

[0001571996-19-000039:mdna:33]
[same as prior period, unchanged from 0001571996-19-000025:mdna:33]

[0001571996-19-000039:mdna:34]
[same as prior period, unchanged from 0001571996-19-000025:mdna:34]

[0001571996-19-000039:mdna:35]
[same as prior period, unchanged from 0001571996-19-000025:mdna:35]

[0001571996-19-000039:mdna:36]
[same as prior period, unchanged from 0001571996-19-000025:mdna:36]

[0001571996-19-000039:mdna:37]
We manage our business on a U.S. dollar basis.  However, we have a large global presence, generating approximately half of our revenue by sales to customers outside of the United States during both the first six months of Fiscal 2020 and Fiscal 2019.  As a result, our revenue can be impacted by fluctuations in foreign currency exchange rates.  We utilize a comprehensive hedging strategy intended to mitigate the impact of foreign currency volatility over time, and we adjust pricing when possible to further minimize foreign currency impacts.  During the past twelve months, there has been a sustained weakening of foreign currencies relative to the U.S. dollar, and we will continue to respond to foreign currency fluctuations with appropriate strategies in the second half of Fiscal 2020.

[0001571996-19-000039:mdna:38]
[same as prior period, unchanged from 0001571996-19-000025:mdna:38]

[0001571996-19-000039:mdna:39]
[same as prior period, unchanged from 0001571996-19-000025:mdna:39]

[0001571996-19-000039:mdna:40]
[same as prior period, unchanged from 0001571996-19-000025:mdna:40]

[0001571996-19-000039:mdna:41]
[same as prior period, unchanged from 0001571996-19-000025:mdna:41]

[0001571996-19-000039:mdna:42]
[same as prior period, unchanged from 0001571996-19-000025:mdna:42]

[0001571996-19-000039:mdna:43]
[same as prior period, unchanged from 0001571996-19-000025:mdna:44]

[0001571996-19-000039:mdna:44]
[same as prior period, unchanged from 0001571996-19-000025:mdna:45]

[0001571996-19-000039:mdna:45]
[same as prior period, unchanged from 0001571996-19-000025:mdna:46]

[0001571996-19-000039:mdna:46]
[same as prior period, unchanged from 0001571996-19-000025:mdna:47]

[0001571996-19-000039:mdna:47]
[same as prior period, unchanged from 0001571996-19-000025:mdna:48]

[0001571996-19-000039:mdna:48]
Dell Technologies’ non-GAAP net income now excludes, among other items, fair value adjustments on equity investments as well as discrete tax items.  These items were not excluded in the prior presentation of our non-GAAP net income for the three and six months ended August 3, 2018.  Upon our return to the public markets in December 2018 as a result of the Class V transaction, we reevaluated the presentation of non-GAAP net income and made these changes to facilitate the evaluation of our current operating performance and the comparability of our current operating performance to our past operating performance.  Non-GAAP net income for the three and six months ended August 3, 2018 has been recast to reflect the current presentation.

[0001571996-19-000039:mdna:49]
The following is a summary of the items excluded from the most comparable GAAP financial measures to calculate our non-GAAP financial measures:

[0001571996-19-000039:mdna:50]
| • | Amortization of Intangible Assets — Amortization of intangible assets primarily consists of amortization of customer relationships, developed technology, and trade names. In connection with our acquisition by merger of EMC on September 7, 2016, referred to as the EMC merger transaction, and the acquisition of Dell Inc. by Dell Technologies Inc. on October 29, 2013, referred to as the going-private transaction, all of the tangible and intangible assets and liabilities of EMC and Dell, respectively, were accounted for and recognized at fair value on the transaction dates. Accordingly, for the periods presented, amortization of intangible assets represents amortization associated with intangible assets recognized in connection with the EMC merger transaction and the going-private transaction. Amortization charges for purchased intangible assets are significantly impacted by the timing and magnitude of our acquisitions, and these charges may vary in amount from period to period. We exclude these charges for purposes of calculating the non-GAAP financial measures presented below to facilitate a more meaningful evaluation of our current operating performance and comparisons to our past operating performance. |

[0001571996-19-000039:mdna:51]
| • | Impact of Purchase Accounting — The impact of purchase accounting includes purchase accounting adjustments related to the EMC merger transaction and, to a lesser extent, the going-private transaction, recorded under the acquisition method of accounting in accordance with the accounting guidance for business combinations. This guidance prescribes that the purchase price be allocated to assets acquired and liabilities assumed based on the estimated fair value of such assets and liabilities on the date of the transaction. Accordingly, all of the assets and liabilities acquired in the EMC merger transaction and the going-private transaction were accounted for and recognized at fair value as of the respective transaction dates, and the fair value adjustments are being amortized over the estimated useful lives in the periods following the transactions. The fair value adjustments primarily relate to deferred revenue, inventory, and property, plant, and equipment. Although the purchase accounting adjustments and related amortization of those adjustments are reflected in our GAAP results, we evaluate the operating results of the underlying businesses on a non-GAAP basis, after removing such adjustments. We believe that excluding the impact of purchase accounting provides results that are useful in understanding our current operating performance and provides more meaningful comparisons to our past operating performance. |

[0001571996-19-000039:mdna:52]
| • | Transaction-related Expenses — Transaction-related expenses consist of acquisition, integration, and divestiture related costs, and are expensed as incurred. These expenses primarily represent costs for legal, banking, consulting, and advisory services, as well as certain compensatory retention awards directly related to the EMC merger transaction. During the first six months of Fiscal 2019, this category also included $116 million of expenses related to integration of our inventory policies and management process related to customer evaluation units. |

[0001571996-19-000039:mdna:53]
| • | Stock-based Compensation Expense — Stock-based compensation expense consists of equity awards granted based on the estimated fair value of those awards at grant date. For service-based stock options, we typically estimate the fair value using the Black-Scholes valuation model and for performance-based awards containing a market condition, we estimate the fair value using the Monte Carlo valuation model. Our non-GAAP adjustment for stock-based compensation expense was previously included within the non-GAAP adjustment for other corporate expenses. Due to the growth in our stock-based compensation expense, we have revised our presentation to present stock-based compensation expense separately in our reconciliations presented below. Stock-based compensation expense varies from period to period and is significantly impacted by our share price and the various assumptions used for valuation purposes. Therefore, although we will incur this type of expense in the future, we believe that eliminating these charges for purposes of calculating the non-GAAP financial measures presented below facilitates a more meaningful evaluation of our current operating performance and comparisons to our past operating performance. See Note 16 of the Notes to the Condensed Consolidated Financial Statements for additional information on equity award issuances. |

[0001571996-19-000039:mdna:54]
73

[0001571996-19-000039:mdna:55]
| • | Other Corporate Expenses — Other corporate expenses consists primarily of severance, facility action, and other costs. Severance costs are primarily related to severance and benefits for employees terminated pursuant to cost savings initiatives. We continue to integrate owned and leased facilities and may incur additional costs as we seek opportunities for operational efficiencies. Other corporate expenses vary from period to period and are significantly impacted by the timing and nature of these events. Therefore, although we may incur these types of expenses in the future, we believe that eliminating these charges for purposes of calculating the non-GAAP financial measures presented below facilitates a more meaningful evaluation of our current operating performance and comparisons to our past operating performance. During the second quarter and first six months of Fiscal 2020, this category includes Virtustream gross impairment charges of $619 million. See Note 8 of the Notes to the Condensed Consolidated Financial Statements for additional information on Virtustream impairment charges. |

[0001571996-19-000039:mdna:56]
[same as prior period, unchanged from 0001571996-19-000025:mdna:55]

[0001571996-19-000039:mdna:57]
| • | Aggregate Adjustment for Income Taxes — The aggregate adjustment for income taxes is the estimated combined income tax effect for the adjustments described above, as well as an adjustment for discrete tax items. Due to the variability in recognition of discrete tax items from period to period, we believe that excluding these benefits or charges for purposes of calculating non-GAAP net income facilitates a more meaningful evaluation of our current operating performance and comparisons to our past operating performance. The tax effects are determined based on the tax jurisdictions where the above items were incurred. This category includes discrete tax benefits of $405 million and $4.5 billion, recorded in the first and second quarters of Fiscal 2020, respectively, for intra-entity asset transfers that were completed during the respective quarters. See Note 11 of the Notes to the Condensed Consolidated Financial Statements for additional information on our income taxes. |

[0001571996-19-000039:mdna:58]
74

[0001571996-19-000039:mdna:59]
The table below presents a reconciliation of each non-GAAP financial measure to the most directly comparable GAAP measure for the periods indicated:

[0001571996-19-000039:mdna:60]
|  | Three Months Ended |  | Six Months Ended |
|  | August 2, 2019 |  | % Change |  | August 3, 2018 |  | August 2, 2019 |  | % Change |  | August 3, 2018 |
|  | (in millions, except percentages) |
| Product net revenue | $ | 18,110 |  |  | — | % |  | $ | 18,149 |  |  | $ | 34,864 |  |  | — | % |  | $ | 34,820 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 6 |  |  |  |  | 18 |  |  | 10 |  |  |  |  | 35 |  |
| Non-GAAP product net revenue | $ | 18,116 |  |  | — | % |  | $ | 18,167 |  |  | $ | 34,874 |  |  | — | % |  | $ | 34,855 |  |
| Services net revenue | $ | 5,260 |  |  | 10 | % |  | $ | 4,793 |  |  | $ | 10,414 |  |  | 10 | % |  | $ | 9,478 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 78 |  |  |  |  | 162 |  |  | 156 |  |  |  |  | 332 |  |
| Non-GAAP services net revenue | $ | 5,338 |  |  | 8 | % |  | $ | 4,955 |  |  | $ | 10,570 |  |  | 8 | % |  | $ | 9,810 |  |
| Net revenue | $ | 23,370 |  |  | 2 | % |  | $ | 22,942 |  |  | $ | 45,278 |  |  | 2 | % |  | $ | 44,298 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 84 |  |  |  |  | 180 |  |  | 166 |  |  |  |  | 367 |  |
| Non-GAAP net revenue | $ | 23,454 |  |  | 1 | % |  | $ | 23,122 |  |  | $ | 45,444 |  |  | 2 | % |  | $ | 44,665 |  |
| Product gross margin | $ | 4,221 |  |  | 32 | % |  | $ | 3,206 |  |  | $ | 7,896 |  |  | 26 | % |  | $ | 6,271 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 519 |  |  |  |  | 718 |  |  | 1,038 |  |  |  |  | 1,428 |  |
| Impact of purchase accounting | 7 |  |  |  |  | 23 |  |  | 13 |  |  |  |  | 46 |  |
| Transaction-related expenses | (3 | ) |  |  |  | 21 |  |  | (5 | ) |  |  |  | 137 |  |
| Stock-based compensation expense | 4 |  |  |  |  | 1 |  |  | 6 |  |  |  |  | 3 |  |
| Other corporate expenses | 5 |  |  |  |  | 1 |  |  | 9 |  |  |  |  | 3 |  |
| Non-GAAP product gross margin | $ | 4,753 |  |  | 20 | % |  | $ | 3,970 |  |  | $ | 8,957 |  |  | 14 | % |  | $ | 7,888 |  |
| Services gross margin | $ | 3,105 |  |  | 6 | % |  | $ | 2,917 |  |  | $ | 6,227 |  |  | 9 | % |  | $ | 5,730 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 78 |  |  |  |  | 162 |  |  | 156 |  |  |  |  | 332 |  |
| Transaction-related expenses | 3 |  |  |  |  | — |  |  | — |  |  |  |  | — |  |
| Stock-based compensation expense | 28 |  |  |  |  | 17 |  |  | 52 |  |  |  |  | 31 |  |
| Other corporate expenses | 19 |  |  |  |  | — |  |  | 28 |  |  |  |  | 4 |  |
| Non-GAAP services gross margin | $ | 3,233 |  |  | 4 | % |  | $ | 3,096 |  |  | $ | 6,463 |  |  | 6 | % |  | $ | 6,097 |  |

[0001571996-19-000039:mdna:61]
|  | Three Months Ended |  | Six Months Ended |
|  | August 2, 2019 |  | % Change |  | August 3, 2018 |  | August 2, 2019 |  | % Change |  | August 3, 2018 |
|  | (in millions, except percentages) |
| Gross margin | $ | 7,326 |  |  | 20 | % |  | $ | 6,123 |  |  | $ | 14,123 |  |  | 18 | % |  | $ | 12,001 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 519 |  |  |  |  | 718 |  |  | 1,038 |  |  |  |  | 1,428 |  |
| Impact of purchase accounting | 85 |  |  |  |  | 185 |  |  | 169 |  |  |  |  | 378 |  |
| Transaction-related expenses | — |  |  |  |  | 21 |  |  | (5 | ) |  |  |  | 137 |  |
| Stock-based compensation expense | 32 |  |  |  |  | 18 |  |  | 58 |  |  |  |  | 34 |  |
| Other corporate expenses | 24 |  |  |  |  | 1 |  |  | 37 |  |  |  |  | 7 |  |
| Non-GAAP gross margin | $ | 7,986 |  |  | 13 | % |  | $ | 7,066 |  |  | $ | 15,420 |  |  | 10 | % |  | $ | 13,985 |  |
| Operating expenses | $ | 6,807 |  |  | 11 | % |  | $ | 6,136 |  |  | $ | 13,054 |  |  | 7 | % |  | $ | 12,167 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | (541 | ) |  |  |  | (808 | ) |  | (1,239 | ) |  |  |  | (1,620 | ) |
| Impact of purchase accounting | (17 | ) |  |  |  | (30 | ) |  | (34 | ) |  |  |  | (59 | ) |
| Transaction-related expenses | (47 | ) |  |  |  | (83 | ) |  | (94 | ) |  |  |  | (133 | ) |
| Stock-based compensation expense | (269 | ) |  |  |  | (198 | ) |  | (506 | ) |  |  |  | (381 | ) |
| Other corporate expenses | (690 | ) |  |  |  | (59 | ) |  | (700 | ) |  |  |  | (123 | ) |
| Non-GAAP operating expenses | $ | 5,243 |  |  | 6 | % |  | $ | 4,958 |  |  | $ | 10,481 |  |  | 6 | % |  | $ | 9,851 |  |
| Operating income (loss) | $ | 519 |  |  | NM |  |  | $ | (13 | ) |  | $ | 1,069 |  |  | 744 | % |  | $ | (166 | ) |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 1,060 |  |  |  |  | 1,526 |  |  | 2,277 |  |  |  |  | 3,048 |  |
| Impact of purchase accounting | 102 |  |  |  |  | 215 |  |  | 203 |  |  |  |  | 437 |  |
| Transaction-related expenses | 47 |  |  |  |  | 104 |  |  | 89 |  |  |  |  | 270 |  |
| Stock-based compensation expense | 301 |  |  |  |  | 216 |  |  | 564 |  |  |  |  | 415 |  |
| Other corporate expenses | 714 |  |  |  |  | 60 |  |  | 737 |  |  |  |  | 130 |  |
| Non-GAAP operating income | $ | 2,743 |  |  | 30 | % |  | $ | 2,108 |  |  | $ | 4,939 |  |  | 19 | % |  | $ | 4,134 |  |
| Net income (loss) | $ | 4,232 |  |  | NM |  |  | $ | (461 | ) |  | $ | 4,561 |  |  | 557 | % |  | $ | (999 | ) |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 1,060 |  |  |  |  | 1,526 |  |  | 2,277 |  |  |  |  | 3,048 |  |
| Impact of purchase accounting | 102 |  |  |  |  | 215 |  |  | 203 |  |  |  |  | 437 |  |
| Transaction-related expenses | 47 |  |  |  |  | 104 |  |  | 89 |  |  |  |  | 270 |  |
| Stock-based compensation expense | 301 |  |  |  |  | 216 |  |  | 564 |  |  |  |  | 415 |  |
| Other corporate expenses | 714 |  |  |  |  | 60 |  |  | 737 |  |  |  |  | 130 |  |
| Fair value adjustments on equity investments | (80 | ) |  |  |  | (139 | ) |  | (142 | ) |  |  |  | (246 | ) |
| Aggregate adjustment for income taxes | (4,625 | ) |  |  |  | (262 | ) |  | (5,329 | ) |  |  |  | (617 | ) |
| Non-GAAP net income (a) | $ | 1,751 |  |  | 39 | % |  | $ | 1,259 |  |  | $ | 2,960 |  |  | 21 | % |  | $ | 2,438 |  |

[0001571996-19-000039:mdna:62]
[same as prior period, unchanged from 0001571996-19-000025:mdna:62]

[0001571996-19-000039:mdna:63]
[same as prior period, unchanged from 0001571996-19-000025:mdna:63]

[0001571996-19-000039:mdna:64]
76

[0001571996-19-000039:mdna:65]
[same as prior period, unchanged from 0001571996-19-000025:mdna:64]

[0001571996-19-000039:mdna:66]
[same as prior period, unchanged from 0001571996-19-000025:mdna:65]

[0001571996-19-000039:mdna:67]
The table below presents a reconciliation of EBITDA and adjusted EBITDA to net income (loss) for the periods indicated:

[0001571996-19-000039:mdna:68]
|  | Three Months Ended |  | Six Months Ended |
|  | August 2, 2019 |  | % Change |  | August 3, 2018 |  | August 2, 2019 |  | % Change |  | August 3, 2018 |
|  | (in millions, except percentages) |
| Net income (loss) | $ | 4,232 |  |  | NM |  |  | $ | (461 | ) |  | $ | 4,561 |  |  | 557 | % |  | $ | (999 | ) |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Interest and other, net (a) | 630 |  |  |  |  | 455 |  |  | 1,323 |  |  |  |  | 925 |  |
| Income tax benefit (b) | (4,343 | ) |  |  |  | (7 | ) |  | (4,815 | ) |  |  |  | (92 | ) |
| Depreciation and amortization | 1,498 |  |  |  |  | 1,931 |  |  | 3,114 |  |  |  |  | 3,845 |  |
| EBITDA | $ | 2,017 |  |  | 5 | % |  | $ | 1,918 |  |  | $ | 4,183 |  |  | 14 | % |  | $ | 3,679 |  |
| EBITDA | $ | 2,017 |  |  | 5 | % |  | $ | 1,918 |  |  | $ | 4,183 |  |  | 14 | % |  | $ | 3,679 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense | 301 |  |  |  |  | 216 |  |  | 564 |  |  |  |  | 415 |  |
| Impact of purchase accounting (c) | 84 |  |  |  |  | 145 |  |  | 167 |  |  |  |  | 367 |  |
| Transaction-related expenses (d) | 47 |  |  |  |  | 85 |  |  | 89 |  |  |  |  | 251 |  |
| Other corporate expenses (e) | 707 |  |  |  |  | 95 |  |  | 726 |  |  |  |  | 130 |  |
| Adjusted EBITDA | $ | 3,156 |  |  | 28 | % |  | $ | 2,459 |  |  | $ | 5,729 |  |  | 18 | % |  | $ | 4,842 |  |

[0001571996-19-000039:mdna:69]
[same as prior period, unchanged from 0001571996-19-000025:mdna:68]

[0001571996-19-000039:mdna:70]
[same as prior period, unchanged from 0001571996-19-000025:mdna:69]

[0001571996-19-000039:mdna:71]
| (b) | See Note 11 of the Notes to the Condensed Consolidated Financial Statements for additional information on discrete tax benefits recorded for intra-company asset transfers during the second quarter and first six months of Fiscal 2020. |

[0001571996-19-000039:mdna:72]
| (c) | This amount includes the non-cash purchase accounting adjustments related to the EMC merger transaction and the going-private transaction. |

[0001571996-19-000039:mdna:73]
| (d) | Transaction-related expenses includes acquisition, integration, and divestiture related costs. |

[0001571996-19-000039:mdna:74]
| (e) | Other corporate expenses includes impairment charges and severance, facility action, and other costs. See Note 8 of the Notes to the Condensed Consolidated Financial Statements for additional information on Virtustream impairment charges. |

[0001571996-19-000039:mdna:75]
[same as prior period, unchanged from 0001571996-19-000025:mdna:74]

[0001571996-19-000039:mdna:76]
[same as prior period, unchanged from 0001571996-19-000025:mdna:75]

[0001571996-19-000039:mdna:77]
The following table summarizes our consolidated results for each of the periods presented.  Unless otherwise indicated, all changes identified for the current-period results represent comparisons to results for the prior corresponding fiscal period.

[0001571996-19-000039:mdna:78]
|  | Three Months Ended |  | Six Months Ended |
|  | August 2, 2019 |  |  |  | August 3, 2018 |  | August 2, 2019 |  |  |  | August 3, 2018 |
|  | Dollars |  | % ofNet Revenue |  | %Change |  | Dollars |  | % ofNet Revenue |  | Dollars |  | % ofNet Revenue |  | %Change |  | Dollars |  | % ofNet Revenue |
|  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 18,110 |  |  | 77.5 | % |  | — | % |  | $ | 18,149 |  |  | 79.1 | % |  | $ | 34,864 |  |  | 77.0 | % |  | — | % |  | $ | 34,820 |  |  | 78.6 | % |
| Services | 5,260 |  |  | 22.5 | % |  | 10 | % |  | 4,793 |  |  | 20.9 | % |  | 10,414 |  |  | 23.0 | % |  | 10 | % |  | 9,478 |  |  | 21.4 | % |
| Total net revenue | $ | 23,370 |  |  | 100.0 | % |  | 2 | % |  | $ | 22,942 |  |  | 100.0 | % |  | $ | 45,278 |  |  | 100.0 | % |  | 2 | % |  | $ | 44,298 |  |  | 100.0 | % |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product (a) | $ | 4,221 |  |  | 23.3 | % |  | 32 | % |  | $ | 3,206 |  |  | 17.7 | % |  | $ | 7,896 |  |  | 22.6 | % |  | 26 | % |  | $ | 6,271 |  |  | 18.0 | % |
| Services (b) | 3,105 |  |  | 59.0 | % |  | 6 | % |  | 2,917 |  |  | 60.9 | % |  | 6,227 |  |  | 59.8 | % |  | 9 | % |  | 5,730 |  |  | 60.5 | % |
| Total gross margin | $ | 7,326 |  |  | 31.3 | % |  | 20 | % |  | $ | 6,123 |  |  | 26.7 | % |  | $ | 14,123 |  |  | 31.2 | % |  | 18 | % |  | $ | 12,001 |  |  | 27.1 | % |
| Operating expenses | $ | 6,807 |  |  | 29.1 | % |  | 11 | % |  | $ | 6,136 |  |  | 26.8 | % |  | $ | 13,054 |  |  | 28.8 | % |  | 7 | % |  | $ | 12,167 |  |  | 27.5 | % |
| Operating income (loss) | $ | 519 |  |  | 2.2 | % |  | NM |  |  | $ | (13 | ) |  | (0.1 | )% |  | $ | 1,069 |  |  | 2.4 | % |  | 744 | % |  | $ | (166 | ) |  | (0.4 | )% |
| Net income (loss) | $ | 4,232 |  |  | 18.1 | % |  | NM |  |  | $ | (461 | ) |  | (2.0 | )% |  | $ | 4,561 |  |  | 10.1 | % |  | 557 | % |  | $ | (999 | ) |  | (2.3 | )% |
| Net income (loss) attributable to Dell Technologies Inc. | $ | 3,416 |  |  | 14.6 | % |  | 785 | % |  | $ | (499 | ) |  | (2.2 | )% |  | $ | 3,709 |  |  | 8.2 | % |  | 427 | % |  | $ | (1,135 | ) |  | (2.6 | )% |
| Non-GAAP Financial Information |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 18,116 |  |  | 77.2 | % |  | — | % |  | $ | 18,167 |  |  | 78.6 | % |  | $ | 34,874 |  |  | 76.7 | % |  | — | % |  | $ | 34,855 |  |  | 78.0 | % |
| Services | 5,338 |  |  | 22.8 | % |  | 8 | % |  | 4,955 |  |  | 21.4 | % |  | 10,570 |  |  | 23.3 | % |  | 8 | % |  | 9,810 |  |  | 22.0 | % |
| Total non-GAAP net revenue | $ | 23,454 |  |  | 100.0 | % |  | 1 | % |  | $ | 23,122 |  |  | 100.0 | % |  | $ | 45,444 |  |  | 100.0 | % |  | 2 | % |  | $ | 44,665 |  |  | 100.0 | % |
| Non-GAAP gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product (a) | $ | 4,753 |  |  | 26.2 | % |  | 20 | % |  | $ | 3,970 |  |  | 21.9 | % |  | $ | 8,957 |  |  | 25.7 | % |  | 14 | % |  | $ | 7,888 |  |  | 22.6 | % |
| Services (b) | 3,233 |  |  | 60.6 | % |  | 4 | % |  | 3,096 |  |  | 62.5 | % |  | 6,463 |  |  | 61.1 | % |  | 6 | % |  | 6,097 |  |  | 62.2 | % |
| Total non-GAAP gross margin | $ | 7,986 |  |  | 34.0 | % |  | 13 | % |  | $ | 7,066 |  |  | 30.6 | % |  | $ | 15,420 |  |  | 33.9 | % |  | 10 | % |  | $ | 13,985 |  |  | 31.3 | % |
| Non-GAAP operating expenses | $ | 5,243 |  |  | 22.4 | % |  | 6 | % |  | $ | 4,958 |  |  | 21.4 | % |  | $ | 10,481 |  |  | 23.1 | % |  | 6 | % |  | $ | 9,851 |  |  | 22.1 | % |
| Non-GAAP operating income | $ | 2,743 |  |  | 11.7 | % |  | 30 | % |  | $ | 2,108 |  |  | 9.1 | % |  | $ | 4,939 |  |  | 10.9 | % |  | 19 | % |  | $ | 4,134 |  |  | 9.3 | % |
| Non-GAAP net income (c) | $ | 1,751 |  |  | 7.5 | % |  | 39 | % |  | $ | 1,259 |  |  | 5.4 | % |  | $ | 2,960 |  |  | 6.5 | % |  | 21 | % |  | $ | 2,438 |  |  | 5.5 | % |
| EBITDA | $ | 2,017 |  |  | 8.6 | % |  | 5 | % |  | $ | 1,918 |  |  | 8.3 | % |  | $ | 4,183 |  |  | 9.2 | % |  | 14 | % |  | $ | 3,679 |  |  | 8.2 | % |
| Adjusted EBITDA | $ | 3,156 |  |  | 13.5 | % |  | 28 | % |  | $ | 2,459 |  |  | 10.6 | % |  | $ | 5,729 |  |  | 12.6 | % |  | 18 | % |  | $ | 4,842 |  |  | 10.8 | % |

[0001571996-19-000039:mdna:79]
[same as prior period, unchanged from 0001571996-19-000025:mdna:78]

[0001571996-19-000039:mdna:80]
[same as prior period, unchanged from 0001571996-19-000025:mdna:79]

[0001571996-19-000039:mdna:81]
[same as prior period, unchanged from 0001571996-19-000025:mdna:80]

[0001571996-19-000039:mdna:82]
[same as prior period, unchanged from 0001571996-19-000025:mdna:81]

[0001571996-19-000039:mdna:83]
| NM | Not meaningful |

[0001571996-19-000039:mdna:84]
[same as prior period, unchanged from 0001571996-19-000025:mdna:150]

[0001571996-19-000039:mdna:85]
[same as prior period, unchanged from 0001571996-19-000025:mdna:83]

[0001571996-19-000039:mdna:86]
[same as prior period, unchanged from 0001571996-19-000025:mdna:84]

[0001571996-19-000039:mdna:87]
During both the second quarter and first six months of Fiscal 2020, our net revenue increased 2%.  During the second quarter and first six months of Fiscal 2020, our non-GAAP net revenue increased 1% and 2%, respectively.  The increases in net revenue and non-GAAP net revenue were attributable to increases in net revenue in CSG and VMware.  The increase in CSG revenue primarily resulted from strong execution by the business, aided by the Microsoft Windows 10 operating system refresh cycle.  During the first six months of Fiscal 2020, we benefited from the strength of our broad IT solutions portfolio, which helped us navigate market volatility and competitive pressures.  We believe we are well-positioned for long-term profitable growth while also maintaining the ability to adjust as needed to changing market conditions with complementary solutions across our businesses.

[0001571996-19-000039:mdna:88]
During the second quarter of Fiscal 2020, our operating income was $519 million compared to an operating loss of $13 million during the second quarter of Fiscal 2019.  During the first six months of Fiscal 2020, our operating income was $1.1 billion compared to an operating loss of $166 million during the first six months of Fiscal 2019.  The increases in our operating income for the second quarter and first six months of Fiscal 2020 were primarily attributable to an increase in operating income for CSG due to lower component costs and a decrease in amortization of intangible assets.  These benefits were partially offset by an increase in other corporate expenses, which primarily include Virtustream impairment charges.

[0001571996-19-000039:mdna:89]
Amortization of intangible assets and other corporate expenses that impacted our operating income totaled $1.8 billion and $1.6 billion for the second quarter of Fiscal 2020 and Fiscal 2019, respectively, and $3.0 billion and 3.2 billion for the first six months of Fiscal 2020 and Fiscal 2019, respectively.  Excluding these costs, the impact of purchase accounting, stock-based compensation expense, and transaction-related expenses, our non-GAAP operating income was $2.7 billion and $2.1 billion during the second quarter of Fiscal 2020 and Fiscal 2019, respectively.  During the first six months of Fiscal 2020 and Fiscal 2019, our non-GAAP operating income was $4.9 billion and $4.1 billion, respectively.  The increases in our non-GAAP operating income for the second quarter and first six months of Fiscal 2020 were primarily due to an increase in operating income for CSG.

[0001571996-19-000039:mdna:90]
Cash provided by operating activities was $4.0 billion during the first six months of Fiscal 2020 compared to $3.8 billion for the first six months of Fiscal 2019.  The increase in operating cash flows during the first six months of Fiscal 2020 was primarily driven by improved profitability and continued working capital discipline.  See “Market Conditions, Liquidity, and Capital Commitments” for further information on our cash flow metrics.

[0001571996-19-000039:mdna:91]
[same as prior period, unchanged from 0001571996-19-000025:mdna:89]

[0001571996-19-000039:mdna:92]
During both the second quarter and first six months of Fiscal 2020, our net revenue increased 2%.  During the second quarter and first six months of Fiscal 2020, our non-GAAP net revenue increased 1% and 2%, respectively.  The increases in net revenue and non-GAAP net revenue were primarily attributable to increases in net revenue in CSG and VMware.  See “Business Unit Results” for further information.

[0001571996-19-000039:mdna:93]
| • | Product Net Revenue — Product net revenue includes revenue from the sale of hardware products and software licenses. During the second quarter and first six months of Fiscal 2020, product net revenue and non-GAAP product net revenue were both unchanged. Increases in product revenue for CSG and VMware were offset during the period by declines in ISG server and networking revenue. |

[0001571996-19-000039:mdna:94]
| • | Services Net Revenue — Services net revenue includes revenue from our services offerings and support services related to hardware products and software licenses. During both the second quarter and first six months of Fiscal 2020, services net revenue and non-GAAP services net revenue increased 10% and 8%, respectively. These increases were primarily due to an increase in services revenue for hardware support and deployment and software maintenance due to growth in the business. A substantial portion of services net revenue is derived from offerings that have been deferred over a period of |

[0001571996-19-000039:mdna:95]
time, and, as a result, reported services net revenue growth rates will be different than reported product net revenue growth rates.

[0001571996-19-000039:mdna:96]
From a geographical perspective, net revenue generated by sales to customers in the Americas and APJ increased during the second quarter of Fiscal 2020 due to strong performance globally in CSG and VMware.  Net revenue from sales to customers in EMEA decreased slightly during the second quarter of Fiscal 2020.

[0001571996-19-000039:mdna:97]
Net revenue generated by sales to customers in the Americas and EMEA increased during the first six months of Fiscal 2020 due to strong performance globally in CSG and VMware.  Net revenue from sales to customers in APJ remained flat during the first six months of Fiscal 2020.

[0001571996-19-000039:mdna:98]
[same as prior period, unchanged from 0001571996-19-000025:mdna:94]

[0001571996-19-000039:mdna:99]
During the second quarter and first six months of Fiscal 2020, our gross margin increased 20% to $7.3 billion and 18% to $14.1 billion, respectively.  During the second quarter and first six months of Fiscal 2020, our gross margin percentage increased 460 basis points to 31.3% and 410 basis points to 31.2%, respectively.  The increases in our gross margin percentage during the second quarter and first six months of Fiscal 2020 were primarily attributable to a decrease in amortization of intangibles and purchase accounting adjustments, and a deflationary component cost environment.

[0001571996-19-000039:mdna:100]
Our gross margin for the second quarter and first six months of Fiscal 2020 included the impact of amortization of intangibles and purchase accounting adjustments of $0.6 billion and $1.2 billion, respectively.  Excluding these costs, transaction-related expenses, stock-based compensation expense, and other corporate expenses, non-GAAP gross margin for the second quarter and first six months of Fiscal 2020 increased 13% to $8.0 billion and 10% to $15.4 billion, respectively, and non-GAAP gross margin percentage increased 340 basis points to 34.0% and 260 basis points to 33.9%, respectively.  The increase in our non-GAAP gross margin were attributable to increases in gross margin across all three business units.  The increases in our non-GAAP gross margin percentage were primarily due to higher gross margin percentages for both ISG and CSG which benefited from the deflationary component cost environment.

[0001571996-19-000039:mdna:101]
| • | Products — During the second quarter of Fiscal 2020, product gross margin increased 32% to $4.2 billion, and product gross margin percentage increased 560 basis points to 23.3%. The increases in both product gross margin and product gross margin percentage were primarily attributable to a decrease in amortization of intangibles and the deflationary cost environment. During the second quarter of Fiscal 2020, non-GAAP product gross margin increased 20% to $4.8 billion, and non-GAAP product gross margin percentage increased 430 basis points to 26.2%. The increases in product gross margin and non-GAAP product gross margin were driven primarily by increases in product revenue due to strength in sales of CSG commercial products and VMware software licenses. Product gross margin percentage and non-GAAP product gross margin percentage increased primarily as a result of higher product gross margin percentages for both ISG and CSG which benefited from the deflationary component cost environment. |

[0001571996-19-000039:mdna:102]
During the first six months of Fiscal 2020, product gross margin increased 26% to $7.9 billion, and product gross margin percentage increased 460 basis points to 22.6%.  The increases in both product gross margin and product gross margin percentage were primarily attributable to a decrease in amortization of intangibles and transaction-related expenses  and the deflationary cost environment.  During the first six months of Fiscal 2020, non-GAAP product gross margin increased 14% to $9.0 billion, and non-GAAP product gross margin percentage increased 310 basis points to 25.7%.  The increases in product gross margin and non-GAAP product gross margin were driven primarily by increases in product revenue due to strength in sales of CSG commercial products and VMware software licenses.  Product gross margin percentage and non-GAAP product gross margin percentage increased primarily as a result of higher product gross margin percentages for both ISG and CSG which benefited from the deflationary component cost environment.

[0001571996-19-000039:mdna:103]
| • | Services — During the second quarter of Fiscal 2020, services gross margin increased 6% to $3.1 billion, and services gross margin percentage decreased 190 basis points to 59.0%. Services gross margin increased due to growth in services gross margin across all three business units, particularly in hardware warranty, hardware support and deployment, and software maintenance. The decrease in services gross margin percentage was attributable to a shift in mix to more CSG services offerings sold relative to ISG, particularly support and deployment. During the second quarter of Fiscal 2020 and Fiscal 2019, services gross margin also benefited from a decrease in purchase accounting adjustments, which totaled $78 million and $162 million, respectively. Excluding these costs, transaction-related expenses, stock-based compensation expense, and other corporate expenses, non-GAAP services gross margin increased 4% to $3.2 billion, and non-GAAP services gross margin percentage decreased 190 basis points to 60.6%. |

[0001571996-19-000039:mdna:104]
[same as prior period, unchanged from 0001571996-19-000025:mdna:164]

[0001571996-19-000039:mdna:105]
During the first six months of Fiscal 2020, services gross margin increased 9% to $6.2 billion, and services gross margin percentage decreased 70 basis points to 59.8%.  Services gross margin increased due to growth in services gross margin across all three business units, particularly in hardware support and deployment and software maintenance.  The decrease in services gross margin percentage was attributable to a shift in  mix to more CSG services offerings sold relative to ISG, particularly support and deployment.  During the first six months of Fiscal 2020 and Fiscal 2019, services gross margin also benefited from a decrease in purchase accounting adjustments, which totaled $156 million and $332 million, respectively.  Excluding these costs, transaction-related expenses, stock-based compensation expense, and other corporate expenses, non-GAAP services gross margin increased 6% to $6.5 billion, and non-GAAP services gross margin percentage decreased 110 basis points to 61.1%.

[0001571996-19-000039:mdna:106]
[same as prior period, unchanged from 0001571996-19-000025:mdna:99]

[0001571996-19-000039:mdna:107]
[same as prior period, unchanged from 0001571996-19-000025:mdna:100]

[0001571996-19-000039:mdna:108]
The terms and conditions of our vendor rebate programs are largely based on product volumes and are generally negotiated either at the beginning of the annual or quarterly period, depending on the program.  The timing and amount of vendor rebates and other discounts we receive under the programs may vary from period to period, reflecting changes in the competitive environment.  We monitor our component costs and seek to address the effects of any changes to terms that might arise under our vendor rebate programs.  Our gross margins for the second quarter and first six months of Fiscal 2020 and Fiscal 2019 were not materially affected by any changes to the terms of our vendor rebate programs, as the amounts we received under these programs were generally stable relative to our total net cost.  We are not aware of any significant changes to vendor pricing or rebate programs that may impact our results in the near term.

[0001571996-19-000039:mdna:109]
[same as prior period, unchanged from 0001571996-19-000025:mdna:102]

[0001571996-19-000039:mdna:110]
[same as prior period, unchanged from 0001571996-19-000025:mdna:103]

[0001571996-19-000039:mdna:111]
The following table presents information regarding our operating expenses for the periods indicated:

[0001571996-19-000039:mdna:112]
|  | Three Months Ended |  | Six Months Ended |
|  | August 2, 2019 |  |  |  | August 3, 2018 |  | August 2, 2019 |  |  |  | August 3, 2018 |
|  | Dollars |  | % ofNet Revenue |  | %Change |  | Dollars |  | % ofNet Revenue |  | Dollars |  | % ofNet Revenue |  | %Change |  | Dollars |  | % ofNet Revenue |
|  | (in millions, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative | $ | 5,578 |  |  | 23.8 | % |  | 12 | % |  | $ | 4,961 |  |  | 21.7 | % |  | $ | 10,649 |  |  | 23.5 | % |  | 8 | % |  | $ | 9,905 |  |  | 22.4 | % |
| Research and development | 1,229 |  |  | 5.3 | % |  | 5 | % |  | 1,175 |  |  | 5.1 | % |  | 2,405 |  |  | 5.3 | % |  | 6 | % |  | 2,262 |  |  | 5.1 | % |
| Total operating expenses | $ | 6,807 |  |  | 29.1 | % |  | 11 | % |  | $ | 6,136 |  |  | 26.8 | % |  | $ | 13,054 |  |  | 28.8 | % |  | 7 | % |  | $ | 12,167 |  |  | 27.5 | % |
| Other Financial Information |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP operating expenses | $ | 5,243 |  |  | 22.4 | % |  | 6 | % |  | $ | 4,958 |  |  | 21.4 | % |  | $ | 10,481 |  |  | 23.1 | % |  | 6 | % |  | $ | 9,851 |  |  | 22.1 | % |

[0001571996-19-000039:mdna:113]
During the second quarter and first six months of Fiscal 2020, total operating expenses increased 11% and 7%, respectively.  Our operating expenses include the impact of purchase accounting, amortization of intangible assets, transaction-related expenses, stock-based compensation expense, and other corporate expenses.  In aggregate, these items totaled $1.6 billion and $1.2 billion for the second quarter of Fiscal 2020 and Fiscal 2019, respectively, and $2.6 billion and $2.3 billion for the first six months of Fiscal 2020 and Fiscal 2019, respectively.  Excluding these costs, total non-GAAP operating expenses increased 6% for both the second quarter and first six months of Fiscal 2020.  The increases in operating expenses and non-GAAP operating expenses were primarily due to an increase in selling, general, and administrative expenses associated with our revenue growth and sales headcount.

[0001571996-19-000039:mdna:114]
| • | Selling, General, and Administrative — Selling, general, and administrative (“SG&A”) expenses increased 12% and 8%, respectively, during the second quarter and first six months of Fiscal 2020. The increases in SG&A expenses were primarily driven by investments in our go-to-market capabilities, including sales headcount, and higher performance-based compensation and commission costs. The increases in SG&A expenses also included Virtustream impairment charges during the second quarter of Fiscal 2020, which were partially offset by a decrease in amortization of intangible assets. |

[0001571996-19-000039:mdna:115]
| • | Research and Development — Research and development (“R&D”) expenses are primarily composed of personnel-related expenses related to product development. R&D expenses as a percentage of net revenue were approximately 5.3% and 5.1% for the second quarter and first six months of Fiscal 2020 and Fiscal 2019, respectively. As our industry continues to change and as the needs of our customers evolve, we intend to support R&D initiatives to innovate and introduce new and enhanced solutions into the market. |

[0001571996-19-000039:mdna:116]
[same as prior period, unchanged from 0001571996-19-000025:mdna:109]

[0001571996-19-000039:mdna:117]
[same as prior period, unchanged from 0001571996-19-000025:mdna:110]

[0001571996-19-000039:mdna:118]
During the second quarter of Fiscal 2020, our operating income was $519 million compared to an operating loss of $13 million during the second quarter of Fiscal 2019.  During the first six months of Fiscal 2020, our operating income was $1.1 billion compared to an operating loss of $166 million during the first six months of Fiscal 2019.  The increases in our operating income for the second quarter and first six months of Fiscal 2020 were primarily attributable to an increase in operating income for CSG and a decrease in amortization of intangible assets.  These benefits were partially offset by an increase in other corporate expenses, which primarily include Virtustream impairment charges.

[0001571996-19-000039:mdna:119]
Amortization of intangible assets and other corporate expenses that impacted our operating income totaled $1.8 billion and $1.6 billion for the second quarter of Fiscal 2020 and Fiscal 2019, respectively, and $3.0 billion and 3.2 billion for the first six months of Fiscal 2020 and Fiscal 2019, respectively.  Excluding these costs, the impact of purchase accounting, stock-based compensation expense, and transaction-related expenses, our non-GAAP operating income was $2.7 billion and $2.1 billion during the second quarter of Fiscal 2020 and Fiscal 2019, respectively.  During the first six months of Fiscal 2020 and Fiscal 2019, our non-GAAP operating income was $4.9 billion and $4.1 billion, respectively.  The increases in our non-GAAP operating income for the second quarter and first six months of Fiscal 2020 were primarily due to an increase in operating income for CSG.

[0001571996-19-000039:mdna:120]
[same as prior period, unchanged from 0001571996-19-000025:mdna:186]

[0001571996-19-000039:mdna:121]
[same as prior period, unchanged from 0001571996-19-000025:mdna:113]

[0001571996-19-000039:mdna:122]
The following table provides information regarding interest and other, net for the periods indicated:

[0001571996-19-000039:mdna:123]
|  | Three Months Ended |  | Six Months Ended |
|  | August 2, 2019 |  | August 3, 2018 |  | August 2, 2019 |  | August 3, 2018 |
|  | (in millions) |
| Interest and other, net: |  |  |  |  |  |  |  |  |  |  |  |
| Investment income, primarily interest | $ | 42 |  |  | $ | 85 |  |  | $ | 86 |  |  | $ | 163 |  |
| Gain on investments, net | 80 |  |  | 139 |  |  | 142 |  |  | 246 |  |
| Interest expense | (692 | ) |  | (622 | ) |  | (1,391 | ) |  | (1,218 | ) |
| Foreign exchange | (35 | ) |  | (34 | ) |  | (80 | ) |  | (111 | ) |
| Other | (25 | ) |  | (23 | ) |  | (80 | ) |  | (5 | ) |
| Total interest and other, net | $ | (630 | ) |  | $ | (455 | ) |  | $ | (1,323 | ) |  | $ | (925 | ) |

[0001571996-19-000039:mdna:124]
During the second quarter and first six months of Fiscal 2020, the change in interest and other, net was unfavorable by $175 million and $398 million, respectively, primarily due to higher interest expense and a decrease in net gain on investments.  To fund a portion of the cash consideration paid in the Class V transaction, we incurred additional debt and liquidated a significant amount of our investments.  As a result, we expect higher interest expense and lower investment income to continue in Fiscal 2020.  See Note 3 and Note 6 of the Notes to the Condensed Consolidated Financial Statements included in this report for further information regarding our investments and debt, respectively.

[0001571996-19-000039:mdna:125]
[same as prior period, unchanged from 0001571996-19-000025:mdna:117]

[0001571996-19-000039:mdna:126]
For the second quarter of Fiscal 2020 and Fiscal 2019, our effective income tax rates were 3912.6% and 1.5%, respectively, on pre-tax losses of $111 million and $468 million, respectively.  For the first six months of Fiscal 2020 and Fiscal 2019, our effective income tax rates were 1895.7% and 8.4%, respectively, on pre-tax losses of $254 million and $1.1 billion, respectively.  The changes in our effective tax rates were primarily driven by discrete tax items and a change in our jurisdictional mix of income.  During the first quarter of Fiscal 2020, we completed an intra-entity asset transfer of certain of our intellectual property to an Irish subsidiary, resulting in a discrete tax benefit of $405 million.  During the second quarter of Fiscal 2020, our VMware business unit completed a similar transaction, resulting in a discrete tax benefit of $4.5 billion.  The tax benefit for each intra-entity asset transfer was recorded as a deferred tax asset in the period of transaction and represents the book and tax basis difference on the transferred assets measured based on the applicable Irish statutory tax rate.  The tax deductions for amortization of the assets will be recognized in the future and any amortization not deducted for tax purposes will be carried forward indefinitely under Irish Tax laws.  We expect to be able to realize the deferred tax assets resulting from these intra-entity asset transfers.  For the second quarter and first six months of Fiscal 2020, our effective tax rates include $273 million discrete tax expense related to certain foreign tax credits associated with U.S. Tax Reform.  Our effective tax rates for the second quarter and first six months of Fiscal 2020 also include $95 million of discrete tax benefits relating to Virtustream impairment charges.  For the first six months of Fiscal 2019, our effective tax rate includes $154 million of discrete tax benefits resulting from the impact of our adoption of the new revenue recognition standard in the first quarter of Fiscal 2019.

[0001571996-19-000039:mdna:127]
The Tax Cuts and Jobs Act of 2017 (“U.S. Tax Reform”) was signed into law on December 22, 2017.  Among other things, U.S. Tax Reform lowers the U.S. corporate income tax rate to 21% from 35%, establishes a modified territorial system requiring a mandatory deemed repatriation tax on undistributed earnings of foreign subsidiaries, requires a minimum tax on certain future earnings generated by foreign subsidiaries while providing for future tax-free repatriation of earnings through a 100% dividends-received deduction, and places limitations on the deductibility of net interest expense.  We anticipate that the U.S. Department of the Treasury and the Internal Revenue Service will continue to issue regulatory guidance clarifying certain provisions of U.S. Tax Reform.  When additional guidance is issued, we will recognize the related tax impact in the fiscal quarter of such issuance.

[0001571996-19-000039:mdna:128]
Our effective income tax rate can fluctuate depending on the geographic distribution of our worldwide earnings, as our foreign earnings are generally taxed at lower rates than in the United States.  The differences between our effective income tax rate and the U.S. federal statutory rate of 21% principally result from the geographical distribution of income and differences between the book and tax treatment of certain items.  In certain jurisdictions, our tax rate is significantly less than the applicable statutory rate as a result of tax holidays.  The majority of our foreign income that is subject to these tax holidays and lower tax rates is attributable to Singapore, China, and Malaysia.  A significant portion of these income tax benefits relates to a tax holiday that will be effective until January 31, 2029.  Our other tax holidays will expire in whole or in part during Fiscal 2022 through Fiscal 2030.  Many of these tax holidays and reduced tax rates may be extended when certain conditions are met or may be terminated early if certain conditions are not met.  As of August 2, 2019, we were not aware of any matters of non-compliance related to these tax holidays.

[0001571996-19-000039:mdna:129]
[same as prior period, unchanged from 0001571996-19-000025:mdna:121]

[0001571996-19-000039:mdna:130]
[same as prior period, unchanged from 0001571996-19-000025:mdna:122]

[0001571996-19-000039:mdna:131]
During the second quarter and first six months of Fiscal 2020, net income was $4.2 billion and $4.6 billion, respectively, and net loss was $0.5 billion and $1.0 billion, respectively, during the second quarter and first six months of Fiscal 2019.  The increase in net income during the second quarter and first six months of Fiscal 2020 was primarily attributable to an increase in tax benefit and, to a lesser extent, an increase in operating income, which was partially offset by an increase in interest and other, net expense.

[0001571996-19-000039:mdna:132]
Net income for the second quarter and first six months of Fiscal 2020 and Fiscal 2019 included amortization of intangible assets, the impact of purchase accounting, transaction-related expenses, stock-based compensation expense, other corporate expenses, fair value adjustments on equity investments, and discrete tax items.  Excluding these costs and the related tax impacts, non-GAAP net income was $1.8 billion and $3.0 billion, respectively, during the second quarter and first six months of Fiscal 2020, and was $1.3 billion and $2.4 billion, respectively, during the second quarter and first six months of Fiscal 2019.  The increase in non-GAAP net income during the second quarter and first six months of Fiscal 2020 was primarily attributable to an increase in operating income, which was partially offset by an increase in interest and other, net expense.

[0001571996-19-000039:mdna:133]
[same as prior period, unchanged from 0001571996-19-000025:mdna:125]

[0001571996-19-000039:mdna:134]
Net income or loss attributable to non-controlling interests consisted of net income or loss attributable to our non-controlling interests in VMware, Inc., Pivotal, and Secureworks.  During the second quarter and first six months of Fiscal 2020, net income attributable to non-controlling interests was $816 million and $852 million, respectively, and net income attributable to non-controlling interests was $38 million and $136 million, respectively, during the second quarter and first six months of Fiscal 2019.  The increase in net income attributable to non-controlling interests during the second quarter and first six months of Fiscal 2020 was attributable to an increase in net income attributable to our non-controlling interest in VMware, Inc.  For more information about our non-controlling interests, see Note 13 of the Notes to the Condensed Consolidated Financial Statements included in this report.

[0001571996-19-000039:mdna:135]
[same as prior period, unchanged from 0001571996-19-000025:mdna:127]

[0001571996-19-000039:mdna:136]
Net income (loss) attributable to Dell Technologies Inc. represents net income (loss) and an adjustment for non-controlling interests.  During the second quarter and first six months of Fiscal 2020, net income attributable to Dell Technologies Inc. was $3.4 billion and $3.7 billion, respectively, and net loss attributable to Dell Technologies Inc. was $0.5 billion and $1.1 billion, respectively, during the second quarter and first six months of Fiscal 2019.  The increase in net income attributable to Dell Technologies Inc. during the second quarter and first six months of Fiscal 2020 was primarily attributable to an increase in net income for the period.

[0001571996-19-000039:mdna:137]
[same as prior period, unchanged from 0001571996-19-000025:mdna:204]

[0001571996-19-000039:mdna:138]
[same as prior period, unchanged from 0001571996-19-000025:mdna:129]

[0001571996-19-000039:mdna:139]
Our reportable segments are based on the following business units: ISG, CSG, and VMware.  A description of our three business units is provided under “Introduction.”  See Note 18 of the Notes to the Condensed Consolidated Financial Statements included in this report for a reconciliation of net revenue and operating income by reportable segment to consolidated net revenue and consolidated operating income (loss), respectively.

[0001571996-19-000039:mdna:140]
[same as prior period, unchanged from 0001571996-19-000025:mdna:131]

[0001571996-19-000039:mdna:141]
The following table presents net revenue and operating income attributable to ISG for the periods indicated:

[0001571996-19-000039:mdna:142]
|  | Three Months Ended |  | Six Months Ended |
|  | August 2, 2019 |  | % Change |  | August 3, 2018 |  | August 2, 2019 |  | % Change |  | August 3, 2018 |
|  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Servers and networking | $ | 4,437 |  |  | (12)% |  | $ | 5,061 |  |  | $ | 8,617 |  |  | (11)% |  | $ | 9,646 |  |
| Storage | 4,184 |  |  | —% |  | 4,166 |  |  | 8,206 |  |  | (1)% |  | 8,248 |  |
| Total ISG net revenue | $ | 8,621 |  |  | (7)% |  | $ | 9,227 |  |  | $ | 16,823 |  |  | (6)% |  | $ | 17,894 |  |
| Operating income: |  |  |  |  |  |  |  |  |  |  |  |
| ISG operating income | $ | 1,050 |  |  | 4% |  | $ | 1,012 |  |  | $ | 1,893 |  |  | (3)% |  | $ | 1,951 |  |
| % of segment net revenue | 12.2 | % |  |  |  | 11.0 | % |  | 11.3 | % |  |  |  | 10.9 | % |

[0001571996-19-000039:mdna:143]
Net Revenue — During the second quarter and first six months of Fiscal 2020, ISG net revenue decreased 7% and 6%, respectively, primarily due to a decrease in sales of servers and networking.  Revenue from servers and networking decreased 12% and 11%, respectively, during the second quarter and first six months of Fiscal 2020, driven by a decline in units sold of our PowerEdge servers due to a weaker demand environment.  Certain competitive dynamics also contributed to lower server volumes, as we focused on profitability over net revenue growth.  The impact of the lower volume of PowerEdge sales was partially mitigated by an increase in average selling prices due to the sale of servers with more robust compute capacity and higher memory and storage content, which was driven by customer demand for servers that enable big data analytics.  Storage revenue remained flat during both the second quarter and first six months of Fiscal 2020.  We continue to make go-to-market investments and enhancements to our storage solutions offerings and expect that these investments will drive long-term improvements in the business.  Component costs were deflationary in the aggregate for ISG during the first six months of Fiscal 2020, and we continue to monitor our pricing in response to changes in the component cost environment.  We expect the aggregate ISG component cost environment to continue to be deflationary in the near term, but to a lesser degree relative to the first half of Fiscal 2020.

[0001571996-19-000039:mdna:144]
[same as prior period, unchanged from 0001571996-19-000025:mdna:135]

[0001571996-19-000039:mdna:145]
From a geographical perspective, net revenue attributable to ISG was relatively flat in the Americas and EMEA, and decreased in APJ during the second quarter of Fiscal 2020.  Net revenue attributable to ISG increased in EMEA, decreased slightly in the Americas, and decreased in APJ during the the first six months of Fiscal 2020.

[0001571996-19-000039:mdna:146]
Operating Income — During the second quarter and first six months of Fiscal 2020, ISG operating income as a percentage of net revenue increased 120 basis points to 12.2% and 40 basis points to 11.3%, respectively, primarily as a result of an increase in ISG gross margin percentage due to higher average selling prices of servers and the deflationary cost environment as described above.  The increase in ISG gross margin percentage was partially offset by an increase in operating expenses as a percentage of net revenue as we continue to make investments in go-to-market capabilities.

[0001571996-19-000039:mdna:147]
85

[0001571996-19-000039:mdna:148]
[same as prior period, unchanged from 0001571996-19-000025:mdna:138]

[0001571996-19-000039:mdna:149]
The following table presents net revenue and operating income attributable to CSG for the periods indicated:

[0001571996-19-000039:mdna:150]
|  | Three Months Ended |  | Six Months Ended |
|  | August 2, 2019 |  | % Change |  | August 3, 2018 |  | August 2, 2019 |  | % Change |  | August 3, 2018 |
|  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 9,077 |  |  | 12% |  | $ | 8,109 |  |  | $ | 17,384 |  |  | 12% |  | $ | 15,472 |  |
| Consumer | 2,671 |  |  | (12)% |  | 3,019 |  |  | 5,274 |  |  | (11)% |  | 5,927 |  |
| Total CSG net revenue | $ | 11,748 |  |  | 6% |  | $ | 11,128 |  |  | $ | 22,658 |  |  | 6% |  | $ | 21,399 |  |
| Operating income: |  |  |  |  |  |  |  |  |  |  |  |
| CSG operating income | $ | 982 |  |  | 131% |  | $ | 425 |  |  | $ | 1,775 |  | — |  | 85% |  | $ | 958 |  |
| % of segment net revenue | 8.4 | % |  |  |  | 3.8 | % |  | 7.8 | % |  |  |  | 4.5 | % |

[0001571996-19-000039:mdna:151]
Net Revenue — During both the second quarter and first six months of Fiscal 2020, CSG net revenue increased 6% primarily driven by strong execution by the business.  CSG also benefited from the Microsoft Windows 10 operating system refresh cycle, which we expect to continue through at least the end of Fiscal 2020.  During both the second quarter and first six months of Fiscal 2020, commercial revenue increased 12% due to continued strong demand for our commercial products across all product categories.  Consumer revenue decreased 12% and 11%, respectively, during the second quarter and first six months of Fiscal 2020 due to lower sales of notebooks, which was partially offset by higher average selling prices as we shifted our product mix to higher-priced consumer notebooks.  The aggregate CSG component cost environment was deflationary in the second quarter and first six months of Fiscal 2020, and we expect deflationary conditions to continue in the near term, but to a lesser degree relative to the first half of Fiscal 2020.

[0001571996-19-000039:mdna:152]
From a geographical perspective, net revenue attributable to CSG increased in the Americas and APJ and decreased in EMEA during the second quarter of Fiscal 2020.  Net revenue attributable to CSG increased in the Americas and APJ and increased to a lesser extent in EMEA in the first six months of Fiscal 2020.

[0001571996-19-000039:mdna:153]
Operating Income — During the second quarter and first six months of Fiscal 2020, CSG operating income as a percentage of net revenue increased 460 basis points to 8.4% and 330 basis points to 7.8%, respectively.  The increases were primarily due to lower component costs that positively impacted CSG gross margin and a shift in product mix to higher-margin product offerings.

[0001571996-19-000039:mdna:154]
86

[0001571996-19-000039:mdna:155]
[same as prior period, unchanged from 0001571996-19-000025:mdna:144]

[0001571996-19-000039:mdna:156]
The following table presents net revenue and operating income attributable to VMware for the periods indicated:

[0001571996-19-000039:mdna:157]
|  | Three Months Ended |  | Six Months Ended |
|  | August 2, 2019 |  | % Change |  | August 3, 2018 |  | August 2, 2019 |  | % Change |  | August 3, 2018 |
|  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| VMware net revenue | $ | 2,466 |  |  | 12% |  | $ | 2,194 |  |  | $ | 4,748 |  |  | 12 | % |  | $ | 4,222 |  |
| Operating income: |  |  |  |  |  |  |  |  |  |  |  |
| VMware operating income | $ | 762 |  |  | 4% |  | $ | 736 |  |  | $ | 1,376 |  |  | 2 | % |  | $ | 1,349 |  |
| % of segment net revenue | 30.9 | % |  |  |  | 33.5 | % |  | 29.0 | % |  |  |  | 32.0 | % |

[0001571996-19-000039:mdna:158]
Net Revenue — VMware net revenue primarily consists of revenue from the sale of software licenses under perpetual licenses, related software maintenance and support, training, consulting services, and hosted services.  VMware net revenue for both the second quarter and first six months of Fiscal 2020 increased 12%, primarily due to growth in software license revenue and sales of software maintenance services.  Software license revenue reflected broad-based growth across the product portfolio.  Software maintenance revenue benefited from strong renewals, revenue recognized from maintenance contracts sold in prior periods, and new maintenance contracts sold during the current periods.

[0001571996-19-000039:mdna:159]
From a geographical perspective, approximately half of VMware net revenue during the second quarter and first six months of Fiscal 2020 was generated by sales to customers in the United States.  VMware net revenue for the second quarter and first six months of Fiscal 2020 was positively affected by growth across U.S. and international markets.

[0001571996-19-000039:mdna:160]
Operating Income — During the second quarter and first six months of Fiscal 2020, VMware operating income as a percentage of net revenue decreased 260 basis points to 30.9% and 300 basis points to 29.0%, respectively.  The decrease was driven by an increase in operating expenses as a percentage of net revenue as the result of an increase in compensation-related expense associated with sales and sales support, primarily due to increased headcount, as well as to an increase in R&D expenses.

[0001571996-19-000039:mdna:161]
[same as prior period, unchanged from 0001571996-19-000025:mdna:151]

[0001571996-19-000039:mdna:162]
[same as prior period, unchanged from 0001571996-19-000025:mdna:152]

[0001571996-19-000039:mdna:163]
We sell products and services directly to customers and through a variety of sales channels, including retail distribution.  Our accounts receivable, net, was $11.6 billion and $12.4 billion as of August 2, 2019 and February 1, 2019, respectively.  We maintain an allowance for doubtful accounts to cover receivables that may be deemed uncollectible.  The allowance for losses is based on a provision for accounts that are collectively evaluated based on historical bad debt experience as well as specific identifiable customer accounts that are deemed at risk.  As of August 2, 2019 and February 1, 2019, the allowance for doubtful accounts was $89 million and $85 million, respectively.  Based on our assessment, we believe that we are adequately reserved for expected credit losses.  We monitor the aging of our accounts receivable and continue to take actions to reduce our exposure to credit losses.

[0001571996-19-000039:mdna:164]
[same as prior period, unchanged from 0001571996-19-000025:mdna:154]

[0001571996-19-000039:mdna:165]
Dell Financial Services and its affiliates (“DFS”) support Dell Technologies by offering and arranging various financing options and services for our customers globally, including through captive financing operations in North America, Europe, Australia, and New Zealand.  DFS originates, collects, and services customer receivables primarily related to the purchase of our product, software, and service solutions.  DFS further strengthens our customer relationships through its flexible consumption models, which enable us to offer our customers the option to pay over time and, in certain cases, based on utilization, to provide them with financial flexibility to meet their changing technological requirements.  New financing originations were $2.0 billion and $1.9 billion for the second quarter of Fiscal 2020 and Fiscal 2019, respectively, and $3.7 billion and $3.6 billion for the first six months of Fiscal 2020 and Fiscal 2019, respectively.

[0001571996-19-000039:mdna:166]
As of February 2, 2019, we adopted the new lease standard discussed in Note 1 and Note 2 of the Notes to the Condensed Consolidated Financial Statements included in this report.  The adoption of the new lease standard did not result in a change to leases that commenced prior to adoption.  For new leases that commenced subsequent to the adoption of the new lease standard, DFS accounts for the leases as sales-type leases, direct financing leases, or operating leases depending on lease classification guidance.  Amounts due from lessees under sales-type leases or direct financing leases are recorded as part of financing receivables, with interest income recognized over the contract term.  On commencement of sales-type leases, we typically qualify for up-front revenue recognition.  On originations of operating leases, we record equipment under operating leases, classified as property, plant, and equipment, and recognize rental revenue and depreciation expense, classified as cost of net revenue, over the contract term.  Direct financing leases under the new lease standard are immaterial.

[0001571996-19-000039:mdna:167]
As of August 2, 2019 and February 1, 2019, our financing receivables, net were $8.8 billion and $8.6 billion, respectively.  We maintain an allowance to cover expected financing receivable credit losses and evaluate credit loss expectations based on our total portfolio.  For the second quarter of Fiscal 2020 and Fiscal 2019, the principal charge-off rate for our total portfolio was 1.1% and 1.4%, respectively.  For the first six months of Fiscal 2020 and Fiscal 2019, the principal charge-off rate for our total portfolio was 1.0% and 1.3%, respectively.  The credit quality of our financing receivables has improved in recent years due to an overall improvement in the credit environment and as the mix of high-quality commercial accounts in our portfolio has continued to increase.  We continue to monitor broader economic indicators and their potential impact on future loss performance.  We have an extensive process to manage our exposure to customer credit risk, including active management of credit lines and our collection activities.  We also sell selected fixed-term financing receivables without recourse to unrelated third parties on a periodic basis, primarily to manage certain concentrations of customer credit exposure.  Based on our assessment of the customer financing receivables, we believe that we are adequately reserved.

[0001571996-19-000039:mdna:168]
We retain a residual interest in equipment leased under our lease programs.  As of August 2, 2019 and February 1, 2019, the residual interest recorded as part of financing receivables was $639 million and $674 million, respectively.  The amount of the residual interest is established at the inception of the lease based upon estimates of the value of the equipment at the end of the lease term using historical studies, industry data, and future value-at-risk demand valuation methods.  On a quarterly basis, we assess the carrying amount of our recorded residual values for impairment.  Generally, residual value risk on equipment under lease is not considered to be significant, because of the existence of a secondary market with respect to the equipment.  The lease agreement also clearly defines applicable return conditions and remedies for non-compliance, to ensure that the leased equipment will be in good operating condition upon return.  Model changes and updates, as well as market strength and product acceptance, are monitored and adjustments are made to residual values in accordance with the significance of any such changes.  Our remarketing sales staff works closely with customers and dealers to manage the sale of lease returns and the recovery of residual exposure.  No impairment losses were recorded related to residual assets during the second quarter and first six months of Fiscal 2020.

[0001571996-19-000039:mdna:169]
As of August 2, 2019, equipment under operating leases, net was $426 million and was immaterial as of February 1, 2019.  The increase in equipment under operating leases, net is due to our adoption of the new lease standard and the elimination of the third-party residual value guarantee insurance in the lease classification test for sales-type leases.  Based on triggering events, we assess the carrying amount of the equipment under operating leases recorded for impairment.  No impairment losses were recorded related to such equipment during the second quarter and first six months of Fiscal 2020.

[0001571996-19-000039:mdna:170]
[same as prior period, unchanged from 0001571996-19-000025:mdna:160]

[0001571996-19-000039:mdna:171]
[same as prior period, unchanged from 0001571996-19-000025:mdna:161]

[0001571996-19-000039:mdna:172]
[same as prior period, unchanged from 0001571996-19-000025:mdna:162]

[0001571996-19-000039:mdna:173]
As of August 2, 2019, we had no off-balance sheet arrangements that have or are reasonably likely to have a current or future material effect on our financial condition or results of operations.

[0001571996-19-000039:mdna:174]
89

[0001571996-19-000039:mdna:175]
[same as prior period, unchanged from 0001571996-19-000025:mdna:165]

[0001571996-19-000039:mdna:176]
[same as prior period, unchanged from 0001571996-19-000025:mdna:166]

[0001571996-19-000039:mdna:177]
[same as prior period, unchanged from 0001571996-19-000025:mdna:167]

[0001571996-19-000039:mdna:178]
[same as prior period, unchanged from 0001571996-19-000025:mdna:168]

[0001571996-19-000039:mdna:179]
[same as prior period, unchanged from 0001571996-19-000025:mdna:169]

[0001571996-19-000039:mdna:180]
[same as prior period, unchanged from 0001571996-19-000025:mdna:170]

[0001571996-19-000039:mdna:181]
[same as prior period, unchanged from 0001571996-19-000025:mdna:171]

[0001571996-19-000039:mdna:182]
[same as prior period, unchanged from 0001571996-19-000025:mdna:172]

[0001571996-19-000039:mdna:183]
To support our ongoing business operations, we rely on operating cash flows as our primary source of liquidity.  We monitor the efficiency of our balance sheet to ensure that we have adequate liquidity to support our strategic initiatives.  In addition to internally generated cash, we have access to other capital sources to finance our strategic initiatives and fund growth in our financing operations.  As of August 2, 2019, we had $9.2 billion of total cash and cash equivalents.  Our strategy is to deploy capital from any potential source, whether internally generated cash or debt, depending on the adequacy and availability of that source of capital and whether it can be accessed in a cost-effective manner.

[0001571996-19-000039:mdna:184]
[same as prior period, unchanged from 0001571996-19-000025:mdna:174]

[0001571996-19-000039:mdna:185]
During the fourth quarter of Fiscal 2019, as discussed above in “Introduction — Class V Transaction,” we completed a transaction in which all issued and outstanding shares of our Class V Common Stock were exchanged for cash or shares of Class C Common Stock at the stockholder’s election.  We paid a total of $14 billion of cash to holders of Class V Common Stock.  To fund a majority of the cash payment to stockholders, VMware, Inc. declared a conditional $11 billion one-time special cash dividend (the “Special Dividend”), which was paid pro-rata to VMware, Inc. stockholders as of the dividend record date of December 27, 2018 and in connection with the completion of the Class V transaction.  Our cash, cash equivalents, and investments declined significantly, commensurate with the cash required to fund this transaction.

[0001571996-19-000039:mdna:186]
VMware, Inc. has advised us that, following its payment of the Special Dividend, VMware, Inc. will remain committed to a balanced capital allocation policy through investment in its product and solutions offerings, acquisitions, and returning capital to its stockholders through share repurchases.  As of August 2, 2019, $1.3 billion remained available for repurchases.  During the first six months of Fiscal 2020, VMware, Inc. repurchased 5.7 million shares of its Class A common stock in the open market for approximately $1.0 billion.  During the first six months of Fiscal 2019, VMware, Inc. did not repurchase any shares of its Class A common stock.

[0001571996-19-000039:mdna:187]
[same as prior period, unchanged from 0001571996-19-000025:mdna:177]

[0001571996-19-000039:mdna:188]
The following table summarizes our cash and cash equivalents as well as our available borrowings as of the dates indicated:

[0001571996-19-000039:mdna:189]
|  | August 2, 2019 |  | February 1, 2019 |
|  | (in millions) |
| Cash and cash equivalents, and available borrowings: |  |  |  |
| Cash and cash equivalents (a) | $ | 9,193 |  |  | $ | 9,676 |  |
| Remaining available borrowings under revolving credit facilities | 6,086 |  |  | 5,586 |  |
| Total cash, cash equivalents, and available borrowings | $ | 15,279 |  |  | $ | 15,262 |  |

[0001571996-19-000039:mdna:190]
[same as prior period, unchanged from 0001571996-19-000025:mdna:180]

[0001571996-19-000039:mdna:191]
| (a) | Of the $9.2 billion of cash and cash equivalents as of August 2, 2019, $2.9 billion was held by VMware, Inc. |

[0001571996-19-000039:mdna:192]
Our revolving credit facilities include the Revolving Credit Facility and the China Revolving Credit Facility, which we renewed during the first quarter of Fiscal 2020.  The Revolving Credit Facility and the China Revolving Credit Facility have maximum aggregate borrowings of $4.5 billion and $0.5 billion, respectively.  Available borrowings under these facilities are reduced by draws on the facility and, under the Revolving Credit Facility, outstanding letters of credit.  As of August 2, 2019, there were no borrowings outstanding under the facilities and remaining available borrowings totaled approximately $5.0 billion.  We may regularly use our available borrowings from both our Revolving Credit Facility and our China Revolving Credit Facility on a short-term basis for general corporate purposes.

[0001571996-19-000039:mdna:193]
The VMware Revolving Credit Facility and the Pivotal Revolving Credit Facility have maximum aggregate borrowings of $1.0 billion and $100 million, respectively.  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc., Pivotal, and their respective subsidiaries under the applicable facility.  As of August 2, 2019, $1.0 billion was available under the VMware Revolving Credit Facility and $100 million was available under the Pivotal Revolving Credit Facility.

[0001571996-19-000039:mdna:194]
[same as prior period, unchanged from 0001571996-19-000025:mdna:184]

[0001571996-19-000039:mdna:195]
[same as prior period, unchanged from 0001571996-19-000025:mdna:185]

[0001571996-19-000039:mdna:196]
[same as prior period, unchanged from 0001571996-19-000025:mdna:187]

[0001571996-19-000039:mdna:197]
The following table summarizes our outstanding debt as of the dates indicated:

[0001571996-19-000039:mdna:198]
|  | August 2, 2019 |  | February 1, 2019 |
|  | (in millions) |
| Restricted Subsidiary Debt |  |  |  |
| Core debt: |  |  |  |
| Senior Secured Credit Facilities and First Lien Notes | $ | 30,260 |  |  | $ | 32,720 |  |
| Unsecured Notes and Debentures | 1,352 |  |  | 1,952 |  |
| Senior Notes | 3,250 |  |  | 3,250 |  |
| EMC Notes | 3,000 |  |  | 3,000 |  |
| DFS allocated debt | (1,448 | ) |  | (1,615 | ) |
| Total core debt | 36,414 |  |  | 39,307 |  |
| DFS related debt: |  |  |  |
| DFS debt | 6,645 |  |  | 5,929 |  |
| DFS allocated debt | 1,448 |  |  | 1,615 |  |
| Total DFS related debt | 8,093 |  |  | 7,544 |  |
| Margin Loan and Other | 4,023 |  |  | 3,388 |  |
| Unrestricted Subsidiary Debt |  |  |  |
| VMware Notes | 4,000 |  |  | 4,000 |  |
| Other | 62 |  |  | — |  |
| Total unrestricted subsidiary debt | 4,062 |  |  | 4,000 |  |
| Total debt, principal amount | 52,592 |  |  | 54,239 |  |
| Carrying value adjustments | (670 | ) |  | (718 | ) |
| Total debt, carrying value | $ | 51,922 |  |  | $ | 53,521 |  |

[0001571996-19-000039:mdna:199]
The outstanding principal amount of our debt was $52.6 billion as of August 2, 2019, which included core debt of $36.4 billion.  We define core debt as the total principal amount of our debt, less DFS related debt, our margin loan and other debt, and unrestricted subsidiary debt.

[0001571996-19-000039:mdna:200]
DFS related debt primarily represents debt from our securitization and structured financing programs.  To fund expansion of the DFS business, we balance the use of the securitization and structured financing programs with other sources of liquidity.  We approximate the amount of our debt used to fund the DFS business by applying a 7:1 debt to equity ratio to the sum of our financing receivables balance and equipment under our DFS operating leases, net.  The debt to equity ratio used is based on the underlying credit quality of the assets.  See Note 4 of the Notes to the Condensed Consolidated Financial Statements included in this report for more information about our DFS debt.

[0001571996-19-000039:mdna:201]
As of August 2, 2019, margin loan and other debt primarily consisted of the $4.0 billion Margin Loan Facility.  In addition, as of August 2, 2019, other unrestricted subsidiary debt consisted of $62 million in finance leases entered into by VMware, Inc. during the second quarter of Fiscal 2020.

[0001571996-19-000039:mdna:202]
[same as prior period, unchanged from 0001571996-19-000025:mdna:193]

[0001571996-19-000039:mdna:203]
Our requirements for cash to pay principal and interest on our debt increased significantly due to the borrowings we incurred to finance the EMC merger transaction, and to a lesser extent, the Class V transaction.  We have made good progress in paying down core debt since the EMC merger transaction.  We believe we will continue to be able to make our debt principal and interest payments, including the short-term maturities, from existing and expected sources of cash.  Cash used for debt principal and interest payments may include short-term borrowings under our revolving credit facilities.  We will continue to focus on paying down core debt.  Related to our variable-rate debt, we could have variations in our future interest expense from potential fluctuations in LIBOR, or from possible fluctuations in the level of DFS debt required to meet future demand for customer financing.  We or our affiliates or their related persons, at our or their sole discretion, may purchase, redeem, prepay, refinance, or otherwise retire any amount of our outstanding indebtedness under the terms of such indebtedness at any time and from time to time, in open market or negotiated transactions with the holders of such indebtedness or otherwise, as appropriate market conditions exist.

[0001571996-19-000039:mdna:204]
During the second quarter of Fiscal 2020, we repaid approximately $2.0 billion of debt, including $0.7 billion of our Term Loan A-2 Facility, $0.6 billion of our Term A-4 Facility, and $0.6 billion of our 5.875% senior notes due June 2019 upon maturity, and approximately $58 million of principal amortization under our term loan facilities.

[0001571996-19-000039:mdna:205]
[same as prior period, unchanged from 0001571996-19-000025:mdna:199]

[0001571996-19-000039:mdna:206]
[same as prior period, unchanged from 0001571996-19-000025:mdna:200]

[0001571996-19-000039:mdna:207]
The following table contains a summary of our Condensed Consolidated Statements of Cash Flows for the periods indicated:

[0001571996-19-000039:mdna:208]
|  | Six Months Ended |
|  | August 2, 2019 |  | August 3, 2018 |
|  | (in millions) |
| Net change in cash from: |  |  |  |
| Operating activities | $ | 3,962 |  |  | $ | 3,792 |  |
| Investing activities | (1,283 | ) |  | (162 | ) |
| Financing activities | (2,922 | ) |  | (1,987 | ) |
| Effect of exchange rate changes on cash and cash equivalents | (62 | ) |  | (216 | ) |
| Change in cash and cash equivalents | $ | (305 | ) |  | $ | 1,427 |  |

[0001571996-19-000039:mdna:209]
Operating Activities — Cash provided by operating activities was $4.0 billion for the first six months of Fiscal 2020 compared to $3.8 billion for the first six months of Fiscal 2019.  The increase in operating cash flows during the first six months of Fiscal 2020 was attributable to improved profitability and continued working capital discipline.

[0001571996-19-000039:mdna:210]
DFS offerings are initially funded through cash on hand at the time of origination, most of which is subsequently replaced with third-party financing.  As a result, while the initial funding of financing receivables is reflected as an impact to cash flows from operations, this funding impact is largely subsequently offset by cash flows from financing.  Additionally, as a result of our adoption of the new leasing standard on lessor accounting in the first quarter of Fiscal 2020, the increase to future originations of operating leases results in a shift from financing receivables to capital expenditures, which benefits our cash flows provided by operating activities by the increase in capital expenditures being reported as cash flows used in investing activities.  DFS new financing originations were $2.0 billion and $1.9 billion during the second quarter of Fiscal 2020 and Fiscal 2019, respectively.  As of August 2, 2019, DFS had $8.8 billion of total net financing receivables and $426 million of equipment under DFS operating leases, net.

[0001571996-19-000039:mdna:211]
Investing Activities — Investing activities primarily consist of cash used to fund capital expenditures for property, plant, and equipment, which includes equipment under DFS operating leases, capitalized software development costs, strategic investments, and the maturities, sales, and purchases of investments.  During the first six months of Fiscal 2020, cash used in investing activities was $1.3 billion and was primarily driven by capital expenditures and acquisitions of businesses, which were partially offset by net cash proceeds from the net sales of strategic investments.  In comparison, cash used by investing activities was $162 million during the first six months of Fiscal 2019 and was primarily driven by capital expenditures, partially offset by net cash proceeds from the divestitures of businesses and by the net sales of investments.

[0001571996-19-000039:mdna:212]
Financing Activities — Financing activities primarily consist of the proceeds and repayments of debt, cash used to repurchase common stock, and proceeds from the issuance of common stock of subsidiaries.  Cash used by financing activities of $2.9 billion during the first six months of Fiscal 2020 primarily consisted of repayments of debt and repurchases of common stock by our public subsidiaries.  In comparison, cash used by financing activities of $2.0 billion during the first six months of Fiscal 2019 was primarily driven by repayments of debt, including an EMC senior note issued in the principal amount of $2.5 billion we repaid during the second quarter of Fiscal 2019.

[0001571996-19-000039:mdna:213]
[same as prior period, unchanged from 0001571996-19-000025:mdna:208]

[0001571996-19-000039:mdna:214]
Capital Expenditures — During the first six months of Fiscal 2020, we spent $1.1 billion on property, plant, and equipment, which included gross equipment under DFS operating leases of $455 million.  During the first six months of Fiscal 2019, we spent $561 million on property, plant, and equipment.  These expenditures were incurred in connection with our global expansion efforts and infrastructure investments made to support future growth, and, in Fiscal 2020, the funding of equipment under DFS operating leases.  Product demand, product mix, and the use of contract manufacturers, as well as ongoing investments in operating and information technology infrastructure, influence the level and prioritization of our capital expenditures.  Aggregate capital expenditures for Fiscal 2020, which will involve infrastructure investments, strategic initiatives, and funding our DFS leasing operations, are currently expected to total between $2.2 billion and $2.4 billion, of which approximately $1.0 billion relates to the property, plant, and equipment to be recognized under the new lease accounting standard.

[0001571996-19-000039:mdna:215]
[same as prior period, unchanged from 0001571996-19-000025:mdna:210]

[0001571996-19-000039:mdna:216]
[same as prior period, unchanged from 0001571996-19-000025:mdna:211]

[0001571996-19-000039:mdna:217]
94
