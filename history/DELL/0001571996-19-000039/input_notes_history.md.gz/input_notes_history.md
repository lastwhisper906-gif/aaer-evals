# DELL note change history — 0001571996-19-000025 → 0001571996-19-000039


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2019-09-10):
[0001571996-19-000039:note_history:1]
Securities Litigation — On May 21, 2014, a securities class action seeking compensatory damages was filed in the United States District Court for the Southern District of New York, captioned City of Pontiac General Employees’ Retirement System v. Dell Inc., et. al. (Case No. 1:14-cv-03644).  The action names as defendants Dell Inc. (“Dell”)

- added (2019-09-10):
[0001571996-19-000039:note_history:2]
and certain current and former executive officers, and alleges that Dell made false and misleading statements about Dell’s financial results and future prospects between February 21, 2012 and May 22, 2012, which resulted in artificially inflated stock prices.  The case was transferred to the United States District Court for the Western District of Texas under the same caption (Case No. 1:15-cv-00374), where the defendants filed a motion to dismiss.  On September 16, 2016, the Court denied the motion to dismiss.  On March 29, 2018, the Court granted the plaintiffs’ motion for class certification, and certified a class consisting of all purchasers of Dell common stock between February 22, 2012 and May 22, 2012.  Fact and expert discovery is now closed.  Dell filed a motion for summary judgment on February 18, 2019, which is pending before the Court.  The parties have been engaged in settlement discussions and have agreed to an immaterial settlement amount pending the Court’s preliminary approval in the next few months.

- changed (2019-09-10):
[0001571996-19-000039:note_history:3]
Class Actions Related to the Class V Transaction — Four purported stockholders brought putative class action complaints arising out of the Class V transaction described in Note 14 of the Notes to the Condensed Consolidated Financial Statements.  The actions were captioned Hallandale Beach Police and Fire Retirement Plan v. Michael Dell et al. (Civil Action No. 2018-0816-JTL), Howard Karp v. Michael Dell et al. (Civil Action No. 2019-0032-JTL), Miramar Police Officers’ Retirement Plan v. Michael Dell et al. (Civil Action No. 2019-0049-JTL), and Steamfitters Local 449 Pension Plan v. Michael Dell et al. (Civil Action No. 2019-0115-JTL).  The four actions were consolidated into In Re Dell Class V Litigation (Consol. C.A. No. 2018-0816-JTL), which names as defendants the Company’s board of directors and certain stockholders of the Company, including Michael S. Dell.  The plaintiffs generally allege that the defendants breached their fiduciary duties to the former holders of Class V Common Stock in connection with the Class V transaction by allegedly causing the Company to enter into a transaction that favored the interests of the controlling stockholders at the expense of such former stockholders.  The plaintiffs filed an amended complaint on August 9, 2019 making substantially similar allegations as described above.  The defendants intend to file a motion to dismiss the action, which will be due on September 30, 2019.
  (was, 2019-06-10, similarity 0.8633):
[0001571996-19-000025:note_history:3]
Class Actions Related to the Class V Transaction — Four purported stockholders brought putative class action complaints arising out of the Class V transaction described in Note 14 of the Notes to the Consolidated Financial Statements.  The actions were captioned Hallandale Beach Police and Fire Retirement Plan v. Michael Dell et al. (Civil Action No. 2018-0816-JTL), Howard Karp v. Michael Dell et al. (Civil Action No. 2019-0032-JTL), Miramar Police Officers’ Retirement Plan v. Michael Dell et al. (Civil Action No. 2019-0049-JTL), and Steamfitters Local 449 Pension Plan v. Michael Dell et al. (Civil Action No. 2019-0115-JTL).  The four actions were consolidated into In Re Dell Class V Litigation (Consol. C.A. No. 2018-0816-JTL), which names as defendants the Company’s board of directors and certain stockholders of the Company, including Michael S. Dell and entities through which Mr. Dell allegedly holds a portion of his and/or his family’s stock.  The plaintiffs generally allege that the defendants breached their fiduciary duties to the former holders of Class V Common Stock in connection with the Class V transaction by allegedly causing the Company to enter into a transaction that favored the interests of the controlling stockholders at the expense of such former stockholders.  The Defendants intend to file a motion to dismiss the action.

- added (2019-09-10):
[0001571996-19-000039:note_history:4]
As of August 2, 2019, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for these or other proceedings or matters has been incurred.  However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company’s business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters.  Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company’s business, financial condition, results of operations, or cash flows will depend on a number of variables, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.

- removed (2019-09-10):
[0001571996-19-000025:note_history:5]
NOTE 10 — COMMITMENTS AND CONTINGENCIES

- removed (2019-09-10):
[0001571996-19-000025:note_history:6]
Securities Litigation — On May 21, 2014, a securities class action seeking compensatory damages was filed in the United States District Court for the Southern District of New York, captioned City of Pontiac General Employees’ Retirement System v. Dell Inc., et. al. (Case No. 1:14-cv-03644).  The action names as defendants Dell Inc. and certain current and former executive officers, and alleges that Dell made false and misleading statements about Dell’s financial results and future prospects between February 21, 2012 and May 22, 2012, which resulted in artificially inflated stock prices.  The case was transferred to the United States District Court for the Western District of Texas under the same caption (Case No. 1:15-cv-00374), where the defendants filed a motion to dismiss.  On September 16, 2016, the Court denied the motion to dismiss.  On March 29, 2018, the Court granted the plaintiffs’ motion for class certification, and certified a class consisting of all purchasers of Dell common stock between February 22, 2012 and May 22, 2012.  Fact and expert discovery is now closed.  Dell filed a motion for summary judgment on February 18, 2019, which is now fully-briefed and pending before the Court.  If the matter is not dismissed, a trial is currently set for October 2019.

- removed (2019-09-10):
[0001571996-19-000025:note_history:7]
As of May 3, 2019, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for these or other proceedings or matters has been incurred.  However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company’s business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters.  Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company’s business, financial condition, results of operations, or cash flows will depend on a number of variables, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2019-09-10):
[0001571996-19-000039:note_history:8]
The Company uses the implicit rate when readily determinable.  As most of the leases do not provide an implicit rate, the Company uses its incremental borrowing rate based on the information available at the commencement date to determine the present value of lease payments.  Incremental borrowing rates used to determine the present value of lease payments were derived by reference to the Company’s secured-debt yields corresponding to the lease commencement date.
  (was, 2019-06-10, similarity 0.9957):
[0001571996-19-000025:note_history:8]
The Company uses the implicit rate when readily determinable.  As most of the leases do not provide an implicit rate, the Company uses its incremental borrowing rate based on the information available at the commencement date to determine the present value of lease payments.  Incremental borrowing rates used to determine the present value of lease payments were derived in reference to the Company’s secured-debt yields corresponding to the lease commencement date.

- changed (2019-09-10):
[0001571996-19-000039:note_history:9]
The Company’s office building agreements contain costs such as common area maintenance and other executory costs that are variable in nature.  Variable lease costs are expensed as incurred.  The Company combines lease and non-lease components, such as common area and other maintenance costs, in calculating the ROU assets and lease liabilities for its office buildings and employee vehicles.  Under certain service agreements with third-party logistics providers, the Company directs the use of the inventory within the warehouses and, therefore, controls the assets.  The warehouses and some of the equipment used are considered embedded leases.  The Company accounts for the lease and non-lease components separately.  The lease components consist of the warehouses and some of the equipment, such as conveyor belts.  The non-lease components consist of services and other shared equipment, such as material handling and transportation.  The Company allocates the consideration to the lease and non-lease components using their relative standalone values.  See Note 5 of the Notes to the Condensed Consolidated Financial Statements for additional information.
  (was, 2019-06-10, similarity 0.9996):
[0001571996-19-000025:note_history:9]
The Company’s office building agreements contain costs such as common area maintenance and other executory costs that are variable in nature.  Variable lease costs are expensed as incurred.  The Company combines lease and non-lease components, such as common area and other maintenance costs, in calculating the ROU assets and lease liabilities for its office buildings and employee vehicles.  Under certain service agreements with third-party logistic providers, the Company directs the use of the inventory within the warehouses and, therefore, controls the assets.  The warehouses and some of the equipment used are considered embedded leases.  The Company accounts for the lease and non-lease components separately.  The lease components consist of the warehouses and some of the equipment, such as conveyor belts.  The non-lease components consist of services and other shared equipment, such as material handling and transportation.  The Company allocates the consideration to the lease and non-lease components using their relative standalone values.  See Note 5 of the Notes to the Condensed Consolidated Financial Statements for additional information.

- changed (2019-09-10):
[0001571996-19-000039:note_history:10]
Accounting for Leases as a Lessor — The Company’s wholly-owned subsidiary Dell Financial Services and its affiliates (“DFS”) acts as a lessor to provide equipment financing to customers through a variety of lease arrangements (“DFS leases”).  Subsequent to the adoption of the new lease standard, new DFS leases are classified as sales-type leases, direct financing leases, or operating leases.  Direct financing leases under the new lease standard are immaterial.  Leases that commenced prior to the adoption of the new lease standard were not reassessed or restated pursuant to the practical expedients elected and will continue to be accounted for under previous lease accounting guidance.
  (was, 2019-06-10, similarity 0.9986):
[0001571996-19-000025:note_history:10]
Accounting for Leases as a Lessor — The Company’s wholly-owned subsidiary, Dell Financial Services and its affiliates (“DFS”), acts as a lessor to provide equipment financing to customers through a variety of lease arrangements (“DFS leases”).  Subsequent to the adoption of the new lease standard, new DFS leases are classified as sales-type leases, direct financing leases, or operating leases.  Direct financing leases under the new lease standard are immaterial.  Leases that commenced prior to the adoption of the new lease standard were not reassessed or restated pursuant to the practical expedients elected and will continue to be accounted for under previous lease accounting guidance.

- changed (2019-09-10):
[0001571996-19-000039:note_history:11]
When a contract includes lease and non-lease components, DFS allocates consideration under the contract to each component based on relative standalone selling price.  Whenever the terms of the lease transfer control to the lessee, the contract is typically classified as a sales-type lease.  Through these arrangements, the lessee has the right to substantially all of the economic benefits from use of the identified asset and has the right to direct the use of such asset during the period of use.  In many arrangements, the lessee also retains ownership at the end of the lease term.  On commencement of sales-type leases, the Company recognizes profit up-front, and amounts due from the customer under the lease contract are recognized as financing receivables on the Consolidated Statements of Financial Position.  Interest income is recognized as Net revenue over the term of the lease based on the effective interest method.  For sales and other taxes collected from the lessee, the Company has elected not to include such taxes as part of lease revenue.
  (was, 2019-06-10, similarity 0.9294):
[0001571996-19-000025:note_history:11]
When a contract includes lease and non-lease components, DFS allocates consideration under the contract to each component based on relative standalone selling price.  Whenever the terms of the lease transfer control to the lessee, the contract is typically classified as a sales-type lease.  Through these arrangements, the lessee has the right to substantially all of the economic benefits from use of the identified asset and has the right to direct the use of such asset during the period of use.  In many arrangements, the lessee also retains ownership at the end of the lease term.  On commencement of sales-type leases, the Company recognizes profit up-front, and amounts due from the customer under the lease contract are recognized as financing receivables on the Consolidated Statement of Financial Position.  Interest income is recognized over the term of the lease based on the effective interest method as Net revenue.  For sales and other taxes collected from the lessee, the Company has elected not to include such taxes as part of lease revenue.

- changed (2019-09-10):
[0001571996-19-000039:note_history:12]
All other leases which do not meet the definition of a sales-type lease or direct financing lease are classified as operating leases.  The underlying asset in an operating lease arrangement is carried at depreciated cost as “Equipment under operating leases” within Property, plant, and equipment, net on the Consolidated Statements of Financial Position.  Depreciation is calculated using the straight-line method over the term of the underlying lease contract and is recognized as Cost of net revenue.  The depreciable basis is the original cost of the equipment less the estimated residual value of the equipment at the end of the lease term.  The Company recognizes operating lease revenue on a straight-line basis over the lease term and expenses deferred initial direct costs on the same basis.  Impairment of equipment under operating leases is assessed on the same basis as other long-lived assets.
  (was, 2019-06-10, similarity 0.9994):
[0001571996-19-000025:note_history:12]
All other leases which do not meet the definition of a sales-type lease or direct financing lease are classified as operating leases.  The underlying asset in an operating lease arrangement is carried at depreciated cost as “Equipment under operating leases” within Property, plant, and equipment, net on the Consolidated Statement of Financial Position.  Depreciation is calculated using the straight-line method over the term of the underlying lease contract and is recognized as Cost of net revenue.  The depreciable basis is the original cost of the equipment less the estimated residual value of the equipment at the end of the lease term.  The Company recognizes operating lease revenue on a straight-line basis over the lease term and expenses deferred initial direct costs on the same basis.  Impairment of equipment under operating leases is assessed on the same basis as other long-lived assets.

- changed (2019-09-10):
[0001571996-19-000039:note_history:13]
Financing Receivables — Financing receivables are presented net of allowance for losses and consist of customer receivables and residual interest.  Customer receivables, gross includes amounts due from customers under revolving loans, fixed-term loans, fixed-term sales-type or direct financing leases, and accrued interest.  The Company has two portfolios, consisting of: (1) fixed-term leases and loans and (2) revolving loans, and assesses risk at the portfolio level to determine the appropriate allowance levels.  The portfolio segments are further segregated into classes based on products, customer type, and credit risk evaluation: (1) Revolving - Dell Preferred Account (“DPA”); (2) Revolving - Dell Business Credit (“DBC”); and (3) Fixed-term - Consumer and Commercial.  Fixed-term leases and loans are offered to qualified small and medium-sized businesses, large commercial accounts, governmental organizations, and educational entities.  Additionally, fixed-term loans are also offered to certain individual consumer customers.  Revolving loans are offered under private label credit financing programs.  The DPA revolving loan programs are offered to individual consumer customers and the DBC revolving loan programs are offered to small and medium-sized business customers.
  (was, 2019-06-10, similarity 0.9941):
[0001571996-19-000025:note_history:13]
Financing Receivables — Financing receivables are presented net of allowance for losses and consist of customer receivables and residual interest.  Customer receivables, gross includes amounts due from customers under revolving loans, fixed-term loans, fixed-term sales-type or direct financing leases, and accrued interest.  The Company has two portfolios: (1) fixed-term leases and loans and (2) revolving loans, and assesses risk at the portfolio level to determine the appropriate allowance levels.  The portfolio segments are further segregated into classes based on products, customer type, and credit risk evaluation: (1) Revolving - Dell Preferred Account (“DPA”); (2) Revolving - Dell Business Credit (“DBC”); and (3) Fixed-term - Consumer and Commercial.  Fixed-term leases and loans are offered to qualified small and medium-sized businesses, large commercial accounts, governmental organizations, and educational entities.  Additionally, fixed-term loans are also offered to certain individual consumer customers.  Revolving loans are offered under private label credit financing programs.  The DPA revolving loan programs are offered to individual consumer customers and the DBC revolving loan programs are offered to small and medium-sized business customers.

- changed (2019-09-10):
[0001571996-19-000039:note_history:14]
The Company retains a residual interest in equipment leased under its fixed-term lease programs.  The amount of the residual interest is established at the inception of the lease based upon estimates of the value of the equipment at the end of the lease term using historical studies, industry data, and future value-at-risk demand valuation methods.  On a quarterly basis, the Company assesses the carrying amount of its recorded residual values for impairment.  Anticipated declines in specific future residual values that are considered to be other-than-temporary are recorded currently in earnings.  Generally, residual value risk on equipment under lease is not considered to be significant because of the existence of a secondary market with respect to the equipment.  The lease agreement also clearly defines applicable return conditions and remedies for non-compliance, to ensure that the leased equipment will be in good operating condition upon return.  Model changes and updates, as well as market strength and product acceptance, are monitored and adjustments are made to residual values in accordance with the significance of any such changes.  Remarketing sales staff works closely with customers and dealers to manage the sale of lease returns and the recovery of residual exposure.  As of August 2, 2019, the Company has not recorded significant residual value impairment.
  (was, 2019-06-10, similarity 0.9967):
[0001571996-19-000025:note_history:14]
The Company retains a residual interest in equipment leased under its fixed-term lease programs.  The amount of the residual interest is established at the inception of the lease based upon estimates of the value of the equipment at the end of the lease term using historical studies, industry data, and future value-at-risk demand valuation methods.  On a quarterly basis, the Company assesses the carrying amount of its recorded residual values for impairment.  Anticipated declines in specific future residual values that are considered to be other-than-temporary are recorded currently in earnings.  Generally, residual value risk on equipment under lease is not considered to be significant because of the existence of a secondary market with respect to the equipment.  The lease agreement also clearly defines applicable return conditions and remedies for non-compliance, to ensure that the leased equipment will be in good operating condition upon return.  Model changes and updates, as well as market strength and product acceptance, are monitored and adjustments are made to residual values in accordance with the significance of any such changes.  Remarketing sales staff works closely with customers and dealers to manage the sale of lease returns and the recovery of residual exposure.  As of May 3, 2019, the Company has not recorded significant residual value impairment.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2019-09-10):
[0001571996-19-000039:note_history:15]
|  | August 2, 2019 |  | February 1, 2019 |
|  | (in millions) |
| Secured Debt |  |  |  |
| Senior Secured Credit Facilities: |  |  |  |
| 4.24% Term Loan B Facility due September 2023 | $ | 4,913 |  |  | $ | 4,938 |  |
| 4.16% Term Loan A-2 Facility due September 2021 | — |  |  | 4,116 |  |
| 3.99% Term Loan A-4 Facility due December 2023 | 1,009 |  |  | 1,650 |  |
| 4.25% Term Loan A-5 Facility due December 2019 | — |  |  | 2,016 |  |
| 4.07% Term Loan A-6 Facility due March 2024 | 3,588 |  |  | — |  |
| First Lien Notes: |  |  |  |
| 3.48% due June 2019 | — |  |  | 3,750 |  |
| 4.42% due June 2021 | 4,500 |  |  | 4,500 |  |
| 5.45% due June 2023 | 3,750 |  |  | 3,750 |  |
| 4.00% due July 2024 | 1,000 |  |  | — |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 4.90% due October 2026 | 1,750 |  |  | — |  |
| 5.30% due October 2029 | 1,750 |  |  | — |  |
| 8.10% due July 2036 | 1,500 |  |  | 1,500 |  |
| 8.35% due July 2046 | 2,000 |  |  | 2,000 |  |
| Unsecured Debt |  |  |  |
| Unsecured Notes and Debentures: |  |  |  |
| 5.875% due June 2019 | — |  |  | 600 |  |
| 4.625% due April 2021 | 400 |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| Senior Notes: |  |  |  |
| 5.875% due June 2021 | 1,625 |  |  | 1,625 |  |
| 7.125% due June 2024 | 1,625 |  |  | 1,625 |  |
| EMC Notes: |  |  |  |
| 2.650% due June 2020 | 2,000 |  |  | 2,000 |  |
| 3.375% due June 2023 | 1,000 |  |  | 1,000 |  |
| VMware Notes: |  |  |  |
| 2.30% due August 2020 | 1,250 |  |  | 1,250 |  |
| 2.95% due August 2022 | 1,500 |  |  | 1,500 |  |
| 3.90% due August 2027 | 1,250 |  |  | 1,250 |  |
| DFS Debt (Note 4) | 6,645 |  |  | 5,929 |  |
| Other |  |  |  |
| 4.51% Margin Loan Facility due April 2022 | 4,000 |  |  | 3,350 |  |
| Other | 85 |  |  | 38 |  |
| Total debt, principal amount | $ | 52,592 |  |  | $ | 54,239 |  |

- changed (2019-09-10):
[0001571996-19-000039:note_history:16]
|  | August 2, 2019 |  | February 1, 2019 |
|  | (in millions) |
| Total debt, principal amount | $ | 52,592 |  |  | $ | 54,239 |  |
| Unamortized discount, net of unamortized premium | (252 | ) |  | (271 | ) |
| Debt issuance costs | (418 | ) |  | (447 | ) |
| Total debt, carrying value | $ | 51,922 |  |  | $ | 53,521 |  |
| Total short-term debt, carrying value | $ | 5,949 |  |  | $ | 4,320 |  |
| Total long-term debt, carrying value | $ | 45,973 |  |  | $ | 49,201 |  |
  (was, 2019-06-10, similarity 0.9888):
[0001571996-19-000025:note_history:16]
|  | May 3, 2019 |  | February 1, 2019 |
|  | (in millions) |
| Total debt, principal amount | $ | 54,237 |  |  | $ | 54,239 |  |
| Unamortized discount, net of unamortized premium | (268 | ) |  | (271 | ) |
| Debt issuance costs | (445 | ) |  | (447 | ) |
| Total debt, carrying value | $ | 53,524 |  |  | $ | 53,521 |  |
| Total short-term debt, carrying value | $ | 4,884 |  |  | $ | 4,320 |  |
| Total long-term debt, carrying value | $ | 48,640 |  |  | $ | 49,201 |  |

- added (2019-09-10):
[0001571996-19-000039:note_history:17]
During the six months ended August 2, 2019, the Company repaid the remaining principal amount of approximately $1,277 million of its Term Loan A-2 Facility described below under “Refinancing Transactions,” $620 million principal amount of its Term Loan A-4 Facility, $600 million principal amount of  its 5.875% senior notes due June 2019 upon maturity, and approximately $91 million of principal amortization under its term loan facilities.  Additionally, during the six months ended August 2, 2019, the Company issued an additional $0.7 billion, net, in DFS debt to support the expansion of its financing receivables portfolio.

- added (2019-09-10):
[0001571996-19-000039:note_history:18]
Refinancing Transactions

- changed (2019-09-10):
[0001571996-19-000039:note_history:19]
On March 20, 2019, Dell International L.L.C. and EMC Corporation, both which are wholly-owned subsidiaries of Dell Technologies Inc., completed a private offering of multiple series of First Lien Notes in an aggregate principal amount of $4.5 billion.  The principal amount, interest rate, and maturity of each series of such First Lien Notes were $1,000 million of 4.00% First Lien Notes due July 15, 2024, $1,750 million of 4.90% First Lien Notes due October 1, 2026, and $1,750 million of 5.30% First Lien Notes due October 1, 2029.
  (was, 2019-06-10, similarity 0.8081):
[0001571996-19-000025:note_history:19]
On March 20, 2019, Dell International L.L.C. and EMC Corporation, both which are wholly-owned subsidiaries of Dell Technologies Inc., completed a private offering of multiple series of First Lien Notes in an aggregate principal amount of $4.5 billion.  The principal amount, interest rate, and maturity of each series of such First Lien Notes were as follows:

- changed (2019-09-10):
[0001571996-19-000039:note_history:20]
A majority of the proceeds from the First Lien Notes issued on March 20, 2019 was used to repay all of the outstanding $3,750 million First Lien Notes due June 2019.  In addition, proceeds of approximately $800 million of borrowings under the new Term Loan A-6 Facility, the proceeds of the $650 million increase in the Margin Loan Facility, and a portion of the proceeds from the 2019 First Lien Notes were used to repay all of the Company’s outstanding amounts under the Term Loan A-5 Facility due December 2019.  During the three months ended May 3, 2019, the remaining proceeds available from the 2019 First Lien Notes were used to repay $550 million of outstanding amounts under the Term Loan A-2 Facility and to pay related premiums, accrued interest, fees, and expenses.  The Term Loan A-2 Facility was subsequently paid off as of August 2, 2019.
  (was, 2019-06-10, similarity 0.8067):
[0001571996-19-000025:note_history:20]
A majority of the proceeds from the First Lien Notes issued on March 20, 2019 was used to repay all of the outstanding $3,750 million First Lien Notes due June 2019.  In addition, proceeds of approximately $800 million of borrowings under the new Term Loan A-6 Facility, the proceeds of the $650 million increase in the Margin Loan Facility, and a portion of the proceeds from the 2019 First Lien Notes were used to repay all of the Company’s outstanding amounts under the Term Loan A-5 Facility due December 2019.  The remaining proceeds available from the 2019 First Lien Notes were used to repay outstanding amounts under the Term Loan A-2 Facility and to pay related premiums, accrued interest, fees, and expenses.

- changed (2019-09-10):
[0001571996-19-000039:note_history:21]
As of August 2, 2019, available borrowings under the Revolving Credit Facility totaled $4.5 billion.  The Senior Secured Credit Facilities provide that the borrowers have the right at any time, subject to customary conditions, to request incremental term loans or incremental revolving commitments.
  (was, 2019-06-10, similarity 0.9844):
[0001571996-19-000025:note_history:21]
As of May 3, 2019, available borrowings under the Revolving Credit Facility totaled $4.5 billion.  The Senior Secured Credit Facilities provide that the borrowers have the right at any time, subject to customary conditions, to request incremental term loans or incremental revolving commitments.

- changed (2019-09-10):
[0001571996-19-000039:note_history:22]
The Term Loan B Facility amortizes in equal quarterly installments in aggregate annual amounts equal to 1% of the original principal amount.  The Term Loan A-4 Facility amortizes in equal quarterly installments in aggregate annual amounts equal to 5% of the original principal amount in each of the first four years after the facility closing date of December 20, 2018, and 80% of the original principal amount in the fifth year after December 20, 2018.  The Term Loan A-6 Facility amortizes in equal quarterly installments in aggregate annual amounts equal to 5% of the original principal amount in each of the first four years after the facility closing date of March 13, 2019, and 80% of the original principal amount in the fifth year after March 13, 2019.  The Revolving Credit Facility has no amortization.
  (was, 2019-06-10, similarity 0.8067):
[0001571996-19-000025:note_history:22]
The Term Loan B Facility amortizes in equal quarterly installments in aggregate annual amounts equal to 1% of the original principal amount.  The Term Loan A-2 Facility amortizes in equal quarterly installments in aggregate annual amounts equal to 5% of the original principal amount in the first year after the closing date of the refinancing transaction on October 20, 2017, 10% of the original principal amount in each of the second and third years after October 20, 2017, and 75% of the original principal amount in the fourth year after October 20, 2017.  The Term Loan A-4 Facility amortizes in equal quarterly installments in aggregate annual amounts equal to 5% of the original principal amount in each of the first four years after the facility closing date of December 20, 2018, and 80% of the original principal amount in the fifth year after December 20, 2018.  The Revolving Credit Facility has no amortization.

- changed (2019-09-10):
[0001571996-19-000039:note_history:23]
First Lien Notes — The senior secured notes (collectively, the “First Lien Notes”) were issued on June 1, 2016 and March 20, 2019 in an aggregate principal amount of $20.0 billion and $4.5 billion, respectively.  As stated above, the Company used a portion of the $4.5 billion proceeds to repay all of the outstanding $3,750 million First Lien Notes due June 2019.  Interest on these borrowings is payable semiannually.  The First Lien Notes are secured on a pari passu basis with the Senior Secured Credit Facilities, on a first-priority basis by substantially all of the tangible and intangible assets of the issuers and guarantors that secure obligations under the Senior Secured Credit Facilities, including pledges of all capital stock of the issuers, Dell, and certain wholly-owned material subsidiaries of the issuers and the guarantors, subject to certain exceptions.
  (was, 2019-06-10, similarity 0.9994):
[0001571996-19-000025:note_history:23]
First Lien Notes — The senior secured notes (collectively, the “First Lien Notes”) were issued on June 1, 2016 and March 20, 2019 in an aggregate principal amount of $20.0 billion and $4.5 billion, respectively.  As stated above, the Company used a portion of the $4.5 billion proceeds to repay all of the outstanding $3,750 million First Lien Notes due June 2019.  Interest on these borrowings is payable semiannually.  The First Lien Notes are secured, on a pari passu basis with the Senior Secured Credit Facilities, on a first-priority basis by substantially all of the tangible and intangible assets of the issuers and guarantors that secure obligations under the Senior Secured Credit Facilities, including pledges of all capital stock of the issuers, Dell, and certain wholly-owned material subsidiaries of the issuers and the guarantors, subject to certain exceptions.

- changed (2019-09-10):
[0001571996-19-000039:note_history:24]
The Company has agreed to use commercially reasonable efforts to register with the SEC notes having terms substantially identical to the terms of the First Lien Notes as part of an offer to exchange such registered notes for the First Lien Notes.  The Company will be obligated to pay additional interest on the First Lien Notes if it fails to consummate such an exchange offer within five years after the closing date of the EMC merger transaction, in the case of the First Lien Notes issued on June 1, 2016, and within five years after their issue date, in the case of the First Lien Notes issued on March 20, 2019.
  (was, 2019-06-10, similarity 0.849):
[0001571996-19-000025:note_history:24]
The Company has agreed to use commercially reasonable efforts to register with the SEC notes having terms substantially identical to the terms of the First Lien Notes as part of an offer to exchange such registered notes for the First Lien Notes.  The Company will be obligated to pay additional interest on the First Lien Notes if it fails to consummate such an exchange offer within five years after the closing date of the EMC merger transaction.

- added (2019-09-10):
[0001571996-19-000039:note_history:25]
.

- changed (2019-09-10):
[0001571996-19-000039:note_history:26]
China Revolving Credit Facility — During the three months ended May 3, 2019, the Company renewed its credit agreement (the “China Revolving Credit Facility”) with a bank lender for a secured revolving loan facility in an aggregate principal amount not to exceed $500 million at an interest rate of LIBOR plus 0.6% per annum.  The facility will expire on February 26, 2020.  As of August 2, 2019, there were no outstanding borrowings under the China Revolving Credit Facility.
  (was, 2019-06-10, similarity 0.99):
[0001571996-19-000025:note_history:26]
China Revolving Credit Facility — During the three months ended May 3, 2019, the Company renewed its credit agreement (the “China Revolving Credit Facility”) with a bank lender for a secured revolving loan facility in an aggregate principal amount not to exceed $500 million at an interest rate of LIBOR plus 0.6% per annum.  The facility will expire on February 26, 2020.  As of May 3, 2019, there were no outstanding borrowings under the China Revolving Credit Facility.

- changed (2019-09-10):
[0001571996-19-000039:note_history:27]
VMware Revolving Credit Facility — On September 12, 2017, VMware, Inc. entered into an unsecured credit agreement, establishing a revolving credit facility (the “VMware Revolving Credit Facility”) with a syndicate of lenders that provides the company with a borrowing capacity of up to $1.0 billion which may be used for VMware, Inc. general corporate purposes.  Commitments under the VMware Revolving Credit Facility are available for a period of five years, which may be extended, subject to the satisfaction of certain conditions, by up to two one year periods.  The credit agreement contains certain representations, warranties, and covenants.  Commitment fees, interest rates, and other terms of borrowing under the VMware Revolving Credit Facility may vary based on VMware, Inc.’s external credit ratings.  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.  As of August 2, 2019, there were no outstanding borrowings under the VMware Revolving Credit Facility.
  (was, 2019-06-10, similarity 0.9961):
[0001571996-19-000025:note_history:27]
VMware Revolving Credit Facility — On September 12, 2017, VMware, Inc. entered into an unsecured credit agreement, establishing a revolving credit facility (the “VMware Revolving Credit Facility”) with a syndicate of lenders that provides the company with a borrowing capacity of up to $1.0 billion which may be used for VMware, Inc. general corporate purposes.  Commitments under the VMware Revolving Credit Facility are available for a period of five years, which may be extended, subject to the satisfaction of certain conditions, by up to two one year periods.  The credit agreement contains certain representations, warranties, and covenants.  Commitment fees, interest rates, and other terms of borrowing under the VMware Revolving Credit Facility may vary based on VMware, Inc.’s external credit ratings.  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.  As of May 3, 2019, there were no outstanding borrowings under the VMware Revolving Credit Facility.

- changed (2019-09-10):
[0001571996-19-000039:note_history:28]
Pivotal Revolving Credit Facility — On September 7, 2017, Pivotal entered into a credit agreement (the “Pivotal Revolving Credit Facility”) that provides for a senior secured revolving loan facility in an aggregate principal amount not to exceed $100 million.  The credit facility contains customary representations, warranties, and covenants, including financial covenants.  The credit agreement will expire on September 8, 2020, unless it is terminated earlier.  None of the net proceeds of borrowings under the facility will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of Pivotal and Pivotal’s subsidiaries.  As of August 2, 2019, there were no outstanding borrowings under the Pivotal Revolving Credit Facility.
  (was, 2019-06-10, similarity 0.9944):
[0001571996-19-000025:note_history:28]
Pivotal Revolving Credit Facility — On September 7, 2017, Pivotal entered into a credit agreement (the “Pivotal Revolving Credit Facility”) that provides for a senior secured revolving loan facility in an aggregate principal amount not to exceed $100 million.  The credit facility contains customary representations, warranties, and covenants, including financial covenants.  The credit agreement will expire on September 8, 2020, unless it is terminated earlier.  None of the net proceeds of borrowings under the facility will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of Pivotal and Pivotal’s subsidiaries.  As of May 3, 2019, there were no outstanding borrowings under the Pivotal Revolving Credit Facility.

- changed (2019-09-10):
[0001571996-19-000039:note_history:29]
The following table presents the aggregate future maturities of the Company’s debt as of August 2, 2019 for the periods indicated:
  (was, 2019-06-10, similarity 0.9719):
[0001571996-19-000025:note_history:29]
The following table presents the aggregate future maturities of the Company’s debt as of May 3, 2019 for the periods indicated:

- changed (2019-09-10):
[0001571996-19-000039:note_history:30]
|  | Maturities by Fiscal Year |
|  | 2020 (remaining six months) |  | 2021 |  | 2022 |  | 2023 |  | 2024 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Secured Credit Facilities and First Lien Notes | $ | 116 |  |  | $ | 174 |  |  | $ | 4,732 |  |  | $ | 290 |  |  | $ | 11,722 |  |  | $ | 13,226 |  |  | $ | 30,260 |  |
| Unsecured Notes and Debentures | — |  |  | — |  |  | 400 |  |  | — |  |  | — |  |  | 952 |  |  | 1,352 |  |
| Senior Notes and EMC Notes | — |  |  | 2,000 |  |  | 1,625 |  |  | — |  |  | 1,000 |  |  | 1,625 |  |  | 6,250 |  |
| VMware Notes | — |  |  | 1,250 |  |  | — |  |  | 1,500 |  |  | — |  |  | 1,250 |  |  | 4,000 |  |
| DFS Debt | 2,140 |  |  | 3,051 |  |  | 980 |  |  | 438 |  |  | 36 |  |  | — |  |  | 6,645 |  |
| Margin Loan Facility | — |  |  | — |  |  | — |  |  | 4,000 |  |  | — |  |  | — |  |  | 4,000 |  |
| Other | 13 |  |  | 18 |  |  | 7 |  |  | 8 |  |  | 7 |  |  | 32 |  |  | 85 |  |
| Total maturities, principal amount | 2,269 |  |  | 6,493 |  |  | 7,744 |  |  | 6,236 |  |  | 12,765 |  |  | 17,085 |  |  | 52,592 |  |
| Associated carrying value adjustments | — |  |  | (5 | ) |  | (78 | ) |  | (28 | ) |  | (142 | ) |  | (417 | ) |  | (670 | ) |
| Total maturities, carrying value amount | $ | 2,269 |  |  | $ | 6,488 |  |  | $ | 7,666 |  |  | $ | 6,208 |  |  | $ | 12,623 |  |  | $ | 16,668 |  |  | $ | 51,922 |  |
  (was, 2019-06-10, similarity 0.9722):
[0001571996-19-000025:note_history:30]
|  | Maturities by Fiscal Year |
|  | 2020 (remaining nine months) |  | 2021 |  | 2022 |  | 2023 |  | 2024 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Secured Credit Facilities and First Lien Notes | $ | 248 |  |  | $ | 236 |  |  | $ | 5,542 |  |  | $ | 393 |  |  | $ | 12,033 |  |  | $ | 13,213 |  |  | $ | 31,665 |  |
| Unsecured Notes and Debentures | 600 |  |  | — |  |  | 400 |  |  | — |  |  | — |  |  | 952 |  |  | 1,952 |  |
| Senior Notes and EMC Notes | — |  |  | 2,000 |  |  | 1,625 |  |  | — |  |  | 1,000 |  |  | 1,625 |  |  | 6,250 |  |
| VMware Notes | — |  |  | 1,250 |  |  | — |  |  | 1,500 |  |  | — |  |  | 1,250 |  |  | 4,000 |  |
| DFS Debt | 3,124 |  |  | 2,402 |  |  | 594 |  |  | 187 |  |  | 36 |  |  | — |  |  | 6,343 |  |
| Margin Loan Facility | — |  |  | — |  |  | — |  |  | 4,000 |  |  | — |  |  | — |  |  | 4,000 |  |
| Other | 16 |  |  | 11 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 27 |  |
| Total maturities, principal amount | 3,988 |  |  | 5,899 |  |  | 8,161 |  |  | 6,080 |  |  | 13,069 |  |  | 17,040 |  |  | 54,237 |  |
| Associated carrying value adjustments | — |  |  | (6 | ) |  | (93 | ) |  | (30 | ) |  | (153 | ) |  | (431 | ) |  | (713 | ) |
| Total maturities, carrying value amount | $ | 3,988 |  |  | $ | 5,893 |  |  | $ | 8,068 |  |  | $ | 6,050 |  |  | $ | 12,916 |  |  | $ | 16,609 |  |  | $ | 53,524 |  |

- changed (2019-09-10):
[0001571996-19-000039:note_history:31]
Covenants and Unrestricted Net Assets — The credit agreement for the Senior Secured Credit Facilities contains customary negative covenants that generally limit the ability of Denali Intermediate Inc., a wholly-owned subsidiary of Dell Technologies (“Dell Intermediate”), Dell, and Dell’s and Denali Intermediate’s other restricted subsidiaries to incur debt, create liens, make fundamental changes, enter into asset sales, make certain investments, pay dividends or distribute or redeem certain equity interests, prepay or redeem certain debt, and enter into certain transactions with affiliates.  The indenture governing the Senior Notes contains customary negative covenants that generally limit the ability of Denali Intermediate, Dell, and Dell’s and Denali Intermediate’s other restricted subsidiaries to incur additional debt or issue certain preferred shares, pay dividends on or make other distributions in respect of capital stock or make other restricted payments, make certain investments, sell or transfer certain assets, create liens on certain assets to secure debt, consolidate, merge, sell, or otherwise dispose of all or substantially all assets, enter into certain transactions with affiliates, and designate subsidiaries as unrestricted subsidiaries.  The negative covenants under such credit agreements and indenture are subject to certain exceptions, qualifications, and “baskets.”  The indentures governing the First Lien Notes, the Unsecured Notes and Debentures, and the EMC Notes variously impose limitations, subject to specified exceptions, on creating certain liens, entering into sale and lease-back transactions, and entering into certain asset sales.  The foregoing credit agreements and indentures contain customary events of default, including failure to make required payments, failure to comply with covenants, and the occurrence of certain events of bankruptcy and insolvency.
  (was, 2019-06-10, similarity 0.7986):
[0001571996-19-000025:note_history:31]
Covenants and Unrestricted Net Assets — The credit agreement for the Senior Secured Credit Facilities contains customary negative covenants that generally limit the ability of Denali Intermediate Inc., a wholly-owned subsidiary of Dell Technologies (“Dell Intermediate”), Dell, and Dell’s and Denali Intermediate’s other restricted subsidiaries to incur debt, create liens, make fundamental changes, enter into asset sales, make certain investments, pay dividends or distribute or redeem certain equity interests, prepay or redeem certain debt, and enter into certain transactions with affiliates.  The indenture governing the Senior Notes contains customary negative covenants that generally limit the ability of Denali Intermediate, Dell, and Dell’s and Denali Intermediate’s other restricted subsidiaries to incur additional debt or issue certain preferred shares, pay dividends on or make other distributions in respect of capital stock or make other restricted payments, make certain investments, sell or transfer certain assets, create liens on certain assets to secure debt, consolidate, merge, sell, or otherwise dispose of all or substantially all assets, enter into certain transactions with affiliates, and designate subsidiaries as unrestricted subsidiaries.

- added (2019-09-10):
[0001571996-19-000039:note_history:32]
As of August 2, 2019, the Company had certain consolidated subsidiaries that were designated as unrestricted subsidiaries for all purposes of the applicable credit agreements and the indentures governing the First Lien Notes and the Senior Notes.  Substantially all of the net assets of the Company’s consolidated subsidiaries were restricted, with the exception of the Company’s unrestricted subsidiaries, primarily VMware, Inc., Pivotal, Secureworks, and their respective subsidiaries, as of August 2, 2019.

- changed (2019-09-10):
[0001571996-19-000039:note_history:33]
The Term Loan A-4 Facility, the Term Loan A-6 Facility, and the Revolving Credit Facility are subject to a first lien leverage ratio covenant that is tested at the end of each fiscal quarter of Dell with respect to Dell’s preceding four fiscal quarters.  The Company was in compliance with all financial covenants as of August 2, 2019.
  (was, 2019-06-10, similarity 0.9341):
[0001571996-19-000025:note_history:33]
The Term Loan A-2 Facility, the Term Loan A-4 Facility, the Term Loan A-6 Facility, and the Revolving Credit Facility are subject to a first lien leverage ratio covenant that is tested at the end of each fiscal quarter of Dell with respect to Dell’s preceding four fiscal quarters.  The Company was in compliance with all financial covenants as of May 3, 2019.

- removed (2019-09-10):
[0001571996-19-000025:note_history:34]
|  | May 3, 2019 |  | February 1, 2019 |
|  | (in millions) |
| Secured Debt |  |  |  |
| Senior Secured Credit Facilities: |  |  |  |
| 4.49% Term Loan B Facility due September 2023 | $ | 4,925 |  |  | $ | 4,938 |  |
| 4.24% Term Loan A-2 Facility due September 2021 | 727 |  |  | 4,116 |  |
| 4.24% Term Loan A-4 Facility due December 2023 | 1,629 |  |  | 1,650 |  |
| 4.25% Term Loan A-5 Facility due December 2019 | — |  |  | 2,016 |  |
| 4.23% Term Loan A-6 Facility due March 2024 | 3,634 |  |  | — |  |
| First Lien Notes: |  |  |  |
| 3.48% due June 2019 | — |  |  | 3,750 |  |
| 4.42% due June 2021 | 4,500 |  |  | 4,500 |  |
| 5.45% due June 2023 | 3,750 |  |  | 3,750 |  |
| 4.00% due July 2024 | 1,000 |  |  | — |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 4.90% due October 2026 | 1,750 |  |  | — |  |
| 5.30% due October 2029 | 1,750 |  |  | — |  |
| 8.10% due July 2036 | 1,500 |  |  | 1,500 |  |
| 8.35% due July 2046 | 2,000 |  |  | 2,000 |  |
| Unsecured Debt |  |  |  |
| Unsecured Notes and Debentures: |  |  |  |
| 5.875% due June 2019 | 600 |  |  | 600 |  |
| 4.625% due April 2021 | 400 |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| Senior Notes: |  |  |  |
| 5.875% due June 2021 | 1,625 |  |  | 1,625 |  |
| 7.125% due June 2024 | 1,625 |  |  | 1,625 |  |
| EMC Notes: |  |  |  |
| 2.650% due June 2020 | 2,000 |  |  | 2,000 |  |
| 3.375% due June 2023 | 1,000 |  |  | 1,000 |  |
| VMware Notes: |  |  |  |
| 2.30% due August 2020 | 1,250 |  |  | 1,250 |  |
| 2.95% due August 2022 | 1,500 |  |  | 1,500 |  |
| 3.90% due August 2027 | 1,250 |  |  | 1,250 |  |
| DFS Debt (Note 4) | 6,343 |  |  | 5,929 |  |
| Other |  |  |  |
| 4.83% Margin Loan Facility due April 2022 | 4,000 |  |  | 3,350 |  |
| Other | 27 |  |  | 38 |  |
| Total debt, principal amount | $ | 54,237 |  |  | $ | 54,239 |  |

- removed (2019-09-10):
[0001571996-19-000025:note_history:35]
| • | $1,000 million 4.00% First Lien Notes due July 15, 2024 |

- removed (2019-09-10):
[0001571996-19-000025:note_history:36]
| • | $1,750 million 4.90% First Lien Notes due October 1, 2026 |

- removed (2019-09-10):
[0001571996-19-000025:note_history:37]
| • | $1,750 million 5.30% First Lien Notes due October 1, 2029 |

- removed (2019-09-10):
[0001571996-19-000025:note_history:38]
During the three months ended May 3, 2019, the Company also repaid $400 million of its Term Loan A-2 Facility and approximately $33 million of principal amortization under its term loan facilities.

- removed (2019-09-10):
[0001571996-19-000025:note_history:39]
The Company issued an additional $0.4 billion, net, in DFS debt to support the expansion of its financing receivables portfolio during the three months ended May 3, 2019.

- removed (2019-09-10):
[0001571996-19-000025:note_history:40]
The negative covenants under such credit agreements and indenture are subject to certain exceptions, qualifications, and “baskets.”  The indentures governing the First Lien Notes, the Unsecured Notes and Debentures, and the EMC Notes variously impose limitations, subject to specified exceptions, on creating certain liens, entering into sale and lease-back transactions, and entering into certain asset sales.  The foregoing credit agreements and indentures contain customary events of default, including failure to make required payments, failure to comply with covenants, and the occurrence of certain events of bankruptcy and insolvency.

- removed (2019-09-10):
[0001571996-19-000025:note_history:41]
As of May 3, 2019, the Company had certain consolidated subsidiaries that were designated as unrestricted subsidiaries for all purposes of the applicable credit agreements and the indentures governing the First Lien Notes and the Senior Notes.  Substantially all of the net assets of the Company’s consolidated subsidiaries were restricted, with the exception of the Company’s unrestricted subsidiaries, primarily VMware Inc., Secureworks, Pivotal, and their respective subsidiaries, as of May 3, 2019.


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-09-10):
[0001571996-19-000039:note_history:42]
|  | August 2, 2019 |  | February 1, 2019 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Secured Credit Facilities | $ | 9.4 |  |  | $ | 9.5 |  |  | $ | 12.5 |  |  | $ | 12.6 |  |
| First Lien Notes | $ | 20.5 |  |  | $ | 22.8 |  |  | $ | 19.8 |  |  | $ | 21.0 |  |
| Unsecured Notes and Debentures | $ | 1.2 |  |  | $ | 1.4 |  |  | $ | 1.8 |  |  | $ | 1.9 |  |
| Senior Notes | $ | 3.2 |  |  | $ | 3.4 |  |  | $ | 3.1 |  |  | $ | 3.4 |  |
| EMC Notes | $ | 3.0 |  |  | $ | 3.0 |  |  | $ | 3.0 |  |  | $ | 2.9 |  |
| VMware Notes | $ | 4.0 |  |  | $ | 4.0 |  |  | $ | 4.0 |  |  | $ | 3.9 |  |
| Margin Loan Facility | $ | 4.0 |  |  | $ | 4.0 |  |  | $ | 3.3 |  |  | $ | 3.4 |  |
  (was, 2019-06-10, similarity 0.9926):
[0001571996-19-000025:note_history:42]
|  | May 3, 2019 |  | February 1, 2019 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Secured Credit Facilities | $ | 10.8 |  |  | $ | 10.9 |  |  | $ | 12.5 |  |  | $ | 12.6 |  |
| First Lien Notes | $ | 20.5 |  |  | $ | 22.3 |  |  | $ | 19.8 |  |  | $ | 21.0 |  |
| Unsecured Notes and Debentures | $ | 1.8 |  |  | $ | 2.0 |  |  | $ | 1.8 |  |  | $ | 1.9 |  |
| Senior Notes | $ | 3.1 |  |  | $ | 3.4 |  |  | $ | 3.1 |  |  | $ | 3.4 |  |
| EMC Notes | $ | 3.0 |  |  | $ | 3.0 |  |  | $ | 3.0 |  |  | $ | 2.9 |  |
| VMware Notes | $ | 4.0 |  |  | $ | 3.9 |  |  | $ | 4.0 |  |  | $ | 3.9 |  |
| Margin Loan Facility | $ | 4.0 |  |  | $ | 4.0 |  |  | $ | 3.3 |  |  | $ | 3.4 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-09-10):
[0001571996-19-000039:note_history:43]
|  | August 2, 2019 |  | February 1, 2019 |
|  | (in millions) |
| DFS U.S. debt: |  |  |  |
| Securitization facilities | $ | 2,287 |  |  | $ | 1,914 |  |
| Fixed-term securitization offerings | 2,438 |  |  | 2,303 |  |
| Other | 201 |  |  | 223 |  |
| Total DFS U.S. debt | 4,926 |  |  | 4,440 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 690 |  |  | 584 |  |
| Other borrowings | 831 |  |  | 708 |  |
| Note payable | 198 |  |  | 197 |  |
| Total DFS international debt | 1,719 |  |  | 1,489 |  |
| Total DFS debt | $ | 6,645 |  |  | $ | 5,929 |  |
| Total short-term DFS debt | $ | 3,703 |  |  | $ | 3,113 |  |
| Total long-term DFS debt | $ | 2,942 |  |  | $ | 2,816 |  |
  (was, 2019-06-10, similarity 0.9922):
[0001571996-19-000025:note_history:43]
|  | May 3, 2019 |  | February 1, 2019 |
|  | (in millions) |
| DFS U.S. debt: |  |  |  |
| Securitization facilities | $ | 1,692 |  |  | $ | 1,914 |  |
| Fixed-term securitization offerings | 2,836 |  |  | 2,303 |  |
| Other | 201 |  |  | 223 |  |
| Total DFS U.S. debt | 4,729 |  |  | 4,440 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 646 |  |  | 584 |  |
| Other borrowings | 766 |  |  | 708 |  |
| Note payable | 202 |  |  | 197 |  |
| Total DFS international debt | 1,614 |  |  | 1,489 |  |
| Total DFS debt | $ | 6,343 |  |  | $ | 5,929 |  |
| Total short-term DFS debt | $ | 3,952 |  |  | $ | 3,113 |  |
| Total long-term DFS debt | $ | 2,391 |  |  | $ | 2,816 |  |

- added (2019-09-10):
[0001571996-19-000039:note_history:44]
|  | August 2, 2019 |  | February 1, 2019 |
|  | (in millions) |
| Secured Debt |  |  |  |
| Senior Secured Credit Facilities: |  |  |  |
| 4.24% Term Loan B Facility due September 2023 | $ | 4,913 |  |  | $ | 4,938 |  |
| 4.16% Term Loan A-2 Facility due September 2021 | — |  |  | 4,116 |  |
| 3.99% Term Loan A-4 Facility due December 2023 | 1,009 |  |  | 1,650 |  |
| 4.25% Term Loan A-5 Facility due December 2019 | — |  |  | 2,016 |  |
| 4.07% Term Loan A-6 Facility due March 2024 | 3,588 |  |  | — |  |
| First Lien Notes: |  |  |  |
| 3.48% due June 2019 | — |  |  | 3,750 |  |
| 4.42% due June 2021 | 4,500 |  |  | 4,500 |  |
| 5.45% due June 2023 | 3,750 |  |  | 3,750 |  |
| 4.00% due July 2024 | 1,000 |  |  | — |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 4.90% due October 2026 | 1,750 |  |  | — |  |
| 5.30% due October 2029 | 1,750 |  |  | — |  |
| 8.10% due July 2036 | 1,500 |  |  | 1,500 |  |
| 8.35% due July 2046 | 2,000 |  |  | 2,000 |  |
| Unsecured Debt |  |  |  |
| Unsecured Notes and Debentures: |  |  |  |
| 5.875% due June 2019 | — |  |  | 600 |  |
| 4.625% due April 2021 | 400 |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| Senior Notes: |  |  |  |
| 5.875% due June 2021 | 1,625 |  |  | 1,625 |  |
| 7.125% due June 2024 | 1,625 |  |  | 1,625 |  |
| EMC Notes: |  |  |  |
| 2.650% due June 2020 | 2,000 |  |  | 2,000 |  |
| 3.375% due June 2023 | 1,000 |  |  | 1,000 |  |
| VMware Notes: |  |  |  |
| 2.30% due August 2020 | 1,250 |  |  | 1,250 |  |
| 2.95% due August 2022 | 1,500 |  |  | 1,500 |  |
| 3.90% due August 2027 | 1,250 |  |  | 1,250 |  |
| DFS Debt (Note 4) | 6,645 |  |  | 5,929 |  |
| Other |  |  |  |
| 4.51% Margin Loan Facility due April 2022 | 4,000 |  |  | 3,350 |  |
| Other | 85 |  |  | 38 |  |
| Total debt, principal amount | $ | 52,592 |  |  | $ | 54,239 |  |

- changed (2019-09-10):
[0001571996-19-000039:note_history:45]
|  | August 2, 2019 |  | February 1, 2019 |
|  | (in millions) |
| Total debt, principal amount | $ | 52,592 |  |  | $ | 54,239 |  |
| Unamortized discount, net of unamortized premium | (252 | ) |  | (271 | ) |
| Debt issuance costs | (418 | ) |  | (447 | ) |
| Total debt, carrying value | $ | 51,922 |  |  | $ | 53,521 |  |
| Total short-term debt, carrying value | $ | 5,949 |  |  | $ | 4,320 |  |
| Total long-term debt, carrying value | $ | 45,973 |  |  | $ | 49,201 |  |
  (was, 2019-06-10, similarity 0.9888):
[0001571996-19-000025:note_history:45]
|  | May 3, 2019 |  | February 1, 2019 |
|  | (in millions) |
| Total debt, principal amount | $ | 54,237 |  |  | $ | 54,239 |  |
| Unamortized discount, net of unamortized premium | (268 | ) |  | (271 | ) |
| Debt issuance costs | (445 | ) |  | (447 | ) |
| Total debt, carrying value | $ | 53,524 |  |  | $ | 53,521 |  |
| Total short-term debt, carrying value | $ | 4,884 |  |  | $ | 4,320 |  |
| Total long-term debt, carrying value | $ | 48,640 |  |  | $ | 49,201 |  |

- removed (2019-09-10):
[0001571996-19-000025:note_history:46]
|  | May 3, 2019 |  | February 1, 2019 |
|  | (in millions) |
| Secured Debt |  |  |  |
| Senior Secured Credit Facilities: |  |  |  |
| 4.49% Term Loan B Facility due September 2023 | $ | 4,925 |  |  | $ | 4,938 |  |
| 4.24% Term Loan A-2 Facility due September 2021 | 727 |  |  | 4,116 |  |
| 4.24% Term Loan A-4 Facility due December 2023 | 1,629 |  |  | 1,650 |  |
| 4.25% Term Loan A-5 Facility due December 2019 | — |  |  | 2,016 |  |
| 4.23% Term Loan A-6 Facility due March 2024 | 3,634 |  |  | — |  |
| First Lien Notes: |  |  |  |
| 3.48% due June 2019 | — |  |  | 3,750 |  |
| 4.42% due June 2021 | 4,500 |  |  | 4,500 |  |
| 5.45% due June 2023 | 3,750 |  |  | 3,750 |  |
| 4.00% due July 2024 | 1,000 |  |  | — |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 4.90% due October 2026 | 1,750 |  |  | — |  |
| 5.30% due October 2029 | 1,750 |  |  | — |  |
| 8.10% due July 2036 | 1,500 |  |  | 1,500 |  |
| 8.35% due July 2046 | 2,000 |  |  | 2,000 |  |
| Unsecured Debt |  |  |  |
| Unsecured Notes and Debentures: |  |  |  |
| 5.875% due June 2019 | 600 |  |  | 600 |  |
| 4.625% due April 2021 | 400 |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| Senior Notes: |  |  |  |
| 5.875% due June 2021 | 1,625 |  |  | 1,625 |  |
| 7.125% due June 2024 | 1,625 |  |  | 1,625 |  |
| EMC Notes: |  |  |  |
| 2.650% due June 2020 | 2,000 |  |  | 2,000 |  |
| 3.375% due June 2023 | 1,000 |  |  | 1,000 |  |
| VMware Notes: |  |  |  |
| 2.30% due August 2020 | 1,250 |  |  | 1,250 |  |
| 2.95% due August 2022 | 1,500 |  |  | 1,500 |  |
| 3.90% due August 2027 | 1,250 |  |  | 1,250 |  |
| DFS Debt (Note 4) | 6,343 |  |  | 5,929 |  |
| Other |  |  |  |
| 4.83% Margin Loan Facility due April 2022 | 4,000 |  |  | 3,350 |  |
| Other | 27 |  |  | 38 |  |
| Total debt, principal amount | $ | 54,237 |  |  | $ | 54,239 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-09-10):
[0001571996-19-000039:note_history:47]
The following table presents the aggregate future maturities of the Company’s debt as of August 2, 2019 for the periods indicated:
  (was, 2019-06-10, similarity 0.9719):
[0001571996-19-000025:note_history:47]
The following table presents the aggregate future maturities of the Company’s debt as of May 3, 2019 for the periods indicated:

- changed (2019-09-10):
[0001571996-19-000039:note_history:48]
|  | Maturities by Fiscal Year |
|  | 2020 (remaining six months) |  | 2021 |  | 2022 |  | 2023 |  | 2024 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Secured Credit Facilities and First Lien Notes | $ | 116 |  |  | $ | 174 |  |  | $ | 4,732 |  |  | $ | 290 |  |  | $ | 11,722 |  |  | $ | 13,226 |  |  | $ | 30,260 |  |
| Unsecured Notes and Debentures | — |  |  | — |  |  | 400 |  |  | — |  |  | — |  |  | 952 |  |  | 1,352 |  |
| Senior Notes and EMC Notes | — |  |  | 2,000 |  |  | 1,625 |  |  | — |  |  | 1,000 |  |  | 1,625 |  |  | 6,250 |  |
| VMware Notes | — |  |  | 1,250 |  |  | — |  |  | 1,500 |  |  | — |  |  | 1,250 |  |  | 4,000 |  |
| DFS Debt | 2,140 |  |  | 3,051 |  |  | 980 |  |  | 438 |  |  | 36 |  |  | — |  |  | 6,645 |  |
| Margin Loan Facility | — |  |  | — |  |  | — |  |  | 4,000 |  |  | — |  |  | — |  |  | 4,000 |  |
| Other | 13 |  |  | 18 |  |  | 7 |  |  | 8 |  |  | 7 |  |  | 32 |  |  | 85 |  |
| Total maturities, principal amount | 2,269 |  |  | 6,493 |  |  | 7,744 |  |  | 6,236 |  |  | 12,765 |  |  | 17,085 |  |  | 52,592 |  |
| Associated carrying value adjustments | — |  |  | (5 | ) |  | (78 | ) |  | (28 | ) |  | (142 | ) |  | (417 | ) |  | (670 | ) |
| Total maturities, carrying value amount | $ | 2,269 |  |  | $ | 6,488 |  |  | $ | 7,666 |  |  | $ | 6,208 |  |  | $ | 12,623 |  |  | $ | 16,668 |  |  | $ | 51,922 |  |
  (was, 2019-06-10, similarity 0.9722):
[0001571996-19-000025:note_history:48]
|  | Maturities by Fiscal Year |
|  | 2020 (remaining nine months) |  | 2021 |  | 2022 |  | 2023 |  | 2024 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Secured Credit Facilities and First Lien Notes | $ | 248 |  |  | $ | 236 |  |  | $ | 5,542 |  |  | $ | 393 |  |  | $ | 12,033 |  |  | $ | 13,213 |  |  | $ | 31,665 |  |
| Unsecured Notes and Debentures | 600 |  |  | — |  |  | 400 |  |  | — |  |  | — |  |  | 952 |  |  | 1,952 |  |
| Senior Notes and EMC Notes | — |  |  | 2,000 |  |  | 1,625 |  |  | — |  |  | 1,000 |  |  | 1,625 |  |  | 6,250 |  |
| VMware Notes | — |  |  | 1,250 |  |  | — |  |  | 1,500 |  |  | — |  |  | 1,250 |  |  | 4,000 |  |
| DFS Debt | 3,124 |  |  | 2,402 |  |  | 594 |  |  | 187 |  |  | 36 |  |  | — |  |  | 6,343 |  |
| Margin Loan Facility | — |  |  | — |  |  | — |  |  | 4,000 |  |  | — |  |  | — |  |  | 4,000 |  |
| Other | 16 |  |  | 11 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 27 |  |
| Total maturities, principal amount | 3,988 |  |  | 5,899 |  |  | 8,161 |  |  | 6,080 |  |  | 13,069 |  |  | 17,040 |  |  | 54,237 |  |
| Associated carrying value adjustments | — |  |  | (6 | ) |  | (93 | ) |  | (30 | ) |  | (153 | ) |  | (431 | ) |  | (713 | ) |
| Total maturities, carrying value amount | $ | 3,988 |  |  | $ | 5,893 |  |  | $ | 8,068 |  |  | $ | 6,050 |  |  | $ | 12,916 |  |  | $ | 16,609 |  |  | $ | 53,524 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-09-10):
[0001571996-19-000039:note_history:49]
|  | Three Months Ended |  | Six Months Ended |
|  | August 2, 2019 |  | August 3, 2018 |  | August 2, 2019 |  | August 3, 2018 |
|  | (in millions) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |
| Infrastructure Solutions Group: |  |  |  |  |  |  |  |
| Servers and networking | $ | 4,437 |  |  | $ | 5,061 |  |  | $ | 8,617 |  |  | $ | 9,646 |  |
| Storage | 4,184 |  |  | 4,166 |  |  | 8,206 |  |  | 8,248 |  |
| Total ISG net revenue | 8,621 |  |  | 9,227 |  |  | 16,823 |  |  | 17,894 |  |
| Client Solutions Group: |  |  |  |  |  |  |  |
| Commercial | 9,077 |  |  | 8,109 |  |  | 17,384 |  |  | 15,472 |  |
| Consumer | 2,671 |  |  | 3,019 |  |  | 5,274 |  |  | 5,927 |  |
| Total CSG net revenue | 11,748 |  |  | 11,128 |  |  | 22,658 |  |  | 21,399 |  |
| VMware: |  |  |  |  |  |  |  |
| Total VMware net revenue | 2,466 |  |  | 2,194 |  |  | 4,748 |  |  | 4,222 |  |
| Total segment net revenue | $ | 22,835 |  |  | $ | 22,549 |  |  | $ | 44,229 |  |  | $ | 43,515 |  |
  (was, 2019-06-10, similarity 0.6937):
[0001571996-19-000025:note_history:49]
|  | Three Months Ended |
|  | May 3, 2019 |  | May 4, 2018 |
|  | (in millions) |
| Net revenue: |  |  |  |  |  |
| Infrastructure Solutions Group: |  |  |  |
| Servers and networking | $ | 4,180 |  |  | $ | 4,585 |  |
| Storage | 4,022 |  |  | 4,082 |  |
| Total ISG net revenue | 8,202 |  |  | 8,667 |  |
| Client Solutions Group: |  |  |  |
| Commercial | 8,307 |  |  | 7,363 |  |
| Consumer | 2,603 |  |  | 2,908 |  |
| Total CSG net revenue | 10,910 |  |  | 10,271 |  |
| VMware: |  |  |  |
| Total VMware net revenue | 2,282 |  |  | 2,028 |  |
| Reportable segment net revenue | $ | 21,394 |  |  | $ | 20,966 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2019-09-10):
[0001571996-19-000039:note_history:50]
NOTE 9 — DEFERRED REVENUE

- added (2019-09-10):
[0001571996-19-000039:note_history:51]
Deferred Revenue — Deferred revenue is recorded for support and deployment services, software maintenance, professional services, training, and SaaS when the Company has a right to invoice or payments have been received for undelivered products or services where transfer of control has not occurred.  Revenue is recognized on these items when the revenue recognition criteria are met, generally resulting in ratable recognition over the contract term.  The Company also has deferred revenue related to undelivered hardware and professional services, consisting of installations and consulting engagements, which are recognized as the Company’s performance obligations under the contract are completed.

- added (2019-09-10):
[0001571996-19-000039:note_history:52]
The following table presents the changes in the Company’s deferred revenue for the periods indicated:

- added (2019-09-10):
[0001571996-19-000039:note_history:53]
|  | Three Months Ended |  | Six Months Ended |
|  | August 2, 2019 |  | August 3, 2018 |  | August 2, 2019 |  | August 3, 2018 |
|  | (in millions) |
| Deferred revenue: |  |  |  |  |  |  |  |
| Deferred revenue at beginning of period | $ | 24,178 |  |  | $ | 20,959 |  |  | $ | 24,010 |  |  | $ | 20,816 |  |
| Revenue deferrals for new contracts and changes in estimates for pre-existing contracts (a) (b) | 5,975 |  |  | 4,988 |  |  | 10,875 |  |  | 9,313 |  |
| Revenue recognized (b) | (4,805 | ) |  | (4,247 | ) |  | (9,537 | ) |  | (8,429 | ) |
| Deferred revenue at end of period | $ | 25,348 |  |  | $ | 21,700 |  |  | $ | 25,348 |  |  | $ | 21,700 |  |
| Short-term deferred revenue | $ | 13,568 |  |  | $ | 11,965 |  |  | $ | 13,568 |  |  | $ | 11,965 |  |
| Long-term deferred revenue | $ | 11,780 |  |  | $ | 9,735 |  |  | $ | 11,780 |  |  | $ | 9,735 |  |

- added (2019-09-10):
[0001571996-19-000039:note_history:54]
____________________

- added (2019-09-10):
[0001571996-19-000039:note_history:55]
| (a) | Includes the impact of foreign currency exchange rate fluctuations. |

- added (2019-09-10):
[0001571996-19-000039:note_history:56]
| (b) | The Company conformed the presentation of certain deferred revenue rollforward activity for the three and six months ended August 3, 2018 to align current year presentation. The beginning and ending deferred revenue liability balances remain unchanged. |

- added (2019-09-10):
[0001571996-19-000039:note_history:57]
Remaining Performance Obligations — Remaining performance obligations represent the aggregate amount of the transaction price allocated to performance obligations not delivered, or partially undelivered, as of the end of the reporting period.

- added (2019-09-10):
[0001571996-19-000039:note_history:58]
Remaining performance obligations include deferred revenue plus unbilled amounts not yet recorded in deferred revenue.  The aggregate amount of the transaction price allocated to remaining performance obligations does not include amounts owed under cancelable contracts where there is no substantive termination penalty.

- added (2019-09-10):
[0001571996-19-000039:note_history:59]
The Company applied the practical expedient to exclude the value of remaining performance obligations for contracts for which revenue is recognized at the amount to which the Company has the right to invoice for services performed.  The Company also applied the practical expedient to not disclose the amount of transaction price allocated to remaining performance obligations for the periods prior to adoption of the new revenue standard.

- added (2019-09-10):
[0001571996-19-000039:note_history:60]
Remaining performance obligation estimates are subject to change and are affected by several factors, including terminations, changes in the scope of contracts, periodic revalidation, adjustments for revenue that have not materialized, and adjustments for currency.

- added (2019-09-10):
[0001571996-19-000039:note_history:61]
The value of the transaction price allocated to remaining performance obligations as of August 2, 2019 was approximately $33 billion.  The Company expects to recognize approximately 61% of remaining performance obligations as revenue in the next twelve months, and the remainder thereafter.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2019-09-10):
[0001571996-19-000039:note_history:62]
NOTE 20 — SUBSEQUENT EVENTS

- added (2019-09-10):
[0001571996-19-000039:note_history:63]
VMware, Inc. Acquisition Agreements

- added (2019-09-10):
[0001571996-19-000039:note_history:64]
Carbon Black  — VMware, Inc. entered into a definitive agreement to acquire Carbon Black, Inc. through a cash tender offer of $26.00 per share, resulting in an expected net cash payment of $1.9 billion by VMware, Inc.  Carbon Black, Inc. develops cloud-native endpoint security software.  The acquisition has been approved by the boards of directors of both VMware, Inc. and Carbon Black, Inc. and is expected to close during the second half of Fiscal 2020, subject to completion of the tender offer, regulatory approvals and other customary closing conditions.

- added (2019-09-10):
[0001571996-19-000039:note_history:65]
Pivotal — VMware, Inc. entered into a definitive merger agreement (the “Merger Agreement”) to acquire Pivotal at a blended price per share of $11.71 per share, consisting of $15.00 per share in cash to the holders of Pivotal’s Class A common stock, and the exchange of VMware, Inc.’s Class B common stock for Pivotal’s Class B common stock held by Dell Technologies, at an exchange ratio of 0.0550 VMware, Inc. shares for each Pivotal share.  In aggregate, this transaction will result in an expected net cash payment of $0.8 billion by VMware, Inc. and the issuance of approximately 7.2 million shares of VMware, Inc.’s Class B common stock to Dell Technologies.  The VMware, Inc. Class B common stock issued to Dell Technologies would increase its ownership stake in VMware, Inc. by approximately 0.3 percentage points to 81.1% based on the shares outstanding as of the announcement of the Merger Agreement.  The acquisition has been approved by the boards of directors of both VMware, Inc. and Pivotal and is expected to close during the second half of Fiscal 2020, subject to approval of the Merger Agreement by Pivotal stockholders, regulatory approvals and other customary closing conditions.  The purchase of Pivotal will be accounted for as a transaction by entities under common control. Assets and liabilities transferred will be recorded at their historical carrying amounts on the date of the transfer, with no goodwill being recognized.

- added (2019-09-10):
[0001571996-19-000039:note_history:66]
Support Agreement — In connection with VMware, Inc.’s entry into the Merger Agreement to acquire Pivotal as described above, Dell Technologies entered into a Consent and Support Agreement (the “Support Agreement”) with EMC Equity Assets LLC (“EMC Equity,” and together with Dell Technologies, the “Dell Stockholders”), VMware, Inc. and, solely with respect to certain sections therein, EMC and VMW Holdco LLC (“VMW Holdco”).  Each of EMC Equity, EMC, and VMW Holdco is a wholly owned subsidiary of Dell Technologies.  Pursuant to the Support Agreement, the Dell Stockholders have agreed, among other matters and subject to the terms and conditions therein, in their capacity as holders of shares of Pivotal, to vote in favor of adopting the Merger Agreement, the merger and each of the actions contemplated by the Merger Agreement.  The Dell Stockholders also have agreed to certain restrictions on transfer of their shares of the Class B common stock of Pivotal, as further set forth in the Support Agreement.  Additionally, pursuant to the Support Agreement, EMC and VMW Holdco, together as the holders of all of the outstanding shares of Class B common stock of VMware, Inc., irrevocably have consented to VMware, Inc. entering into the Merger Agreement and the consummation of the transactions contemplated thereby.  The Support Agreement provides that, subject to VMware, Inc.’s ability to consummate the Pivotal acquisition and prior to the transaction closing, VMware, Inc. and Dell Technologies will execute an amendment to the tax sharing agreement between the two companies.

- added (2019-09-10):
[0001571996-19-000039:note_history:67]
Commitment For Senior Unsecured Term Loan Facility of VMware, Inc.

- added (2019-09-10):
[0001571996-19-000039:note_history:68]
VMware, Inc. received a commitment from a financial institution for a senior unsecured 364-day term loan facility that would provide VMware, Inc. with a borrowing capacity of up to $2.0 billion (the “Commitment”), which, if funded, may be used for general corporate purposes.  The initial funding of the Commitment is subject to various customary conditions, including execution and delivery of the definitive loan agreement and related documentation.

- added (2019-09-10):
[0001571996-19-000039:note_history:69]
Refinancing Transaction

- added (2019-09-10):
[0001571996-19-000039:note_history:70]
On September 5, 2019, the Company initiated a refinancing of its existing $4.9 billion Term Loan B Facility due September 2023, which it intends to replace with a modified $4.0 billion Term Loan B Facility due 2025.  The transaction is expected to close on or about September 18, 2019.
