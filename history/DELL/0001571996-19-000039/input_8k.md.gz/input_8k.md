# DELL 8-K — 0001571996-19-000036 filed 2019-08-29

## item codes, every 8-K on or before 2019-09-10

- 2019-08-29 0001571996-19-000036 — 2.02, 9.01
- 2019-08-22 0001193125-19-226939 — 7.01, 8.01, 9.01
- 2019-07-11 0001571996-19-000032 — 5.02, 5.07, 9.01
- 2019-07-03 0001571996-19-000030 — 3.02
- 2019-06-27 0001571996-19-000028 — 3.02
- 2019-05-30 0001571996-19-000021 — 2.02, 9.01
- 2019-04-02 0001571996-19-000010 — 5.02
- 2019-03-21 0001193125-19-082281 — 1.01, 1.02, 2.03, 9.01
- 2019-03-19 0001571996-19-000005 — 5.02, 9.01
- 2019-03-14 0001193125-19-074935 — 1.01, 2.03, 9.01
- 2019-03-07 0001193125-19-066045 — 8.01, 9.01
- 2019-02-28 0001571996-19-000002 — 2.02, 9.01
- 2018-12-28 0001193125-18-360943 — 1.01, 1.02, 3.01, 3.03, 5.02, 5.03, 7.01, 8.01, 9.01
- 2018-12-21 0001193125-18-356324 — 1.01, 2.03, 9.01
- 2018-12-14 0001193125-18-349469 — 8.01
- 2018-12-11 0001193125-18-346958 — 5.07, 8.01, 9.01
- 2018-11-29 0001571996-18-000041 — 2.02, 9.01
- 2018-11-28 0001571996-18-000037 — 7.01, 8.01, 9.01
- 2018-11-26 0001193125-18-333967 — 8.01, 9.01
- 2018-11-15 0001193125-18-328110 — 1.01, 9.01 — amendment of 0001193125-18-327222
- 2018-11-15 0001193125-18-327222 — 1.01, 7.01, 9.01
- 2018-10-03 0001193125-18-291390 — 8.01
- 2018-09-06 0001571996-18-000029 — 2.02, 9.01
- 2018-08-06 0001571996-18-000027 — 8.01, 9.01
- 2018-07-02 0001193125-18-210339 — 1.01, 7.01, 9.01
- 2018-06-28 0001571996-18-000024 — 5.07
- 2018-06-04 0001571996-18-000019 — 2.02, 9.01
- 2018-05-17 0001571996-18-000016 — 7.01
- 2018-04-26 0001571996-18-000009 — 7.01, 9.01
- 2018-03-08 0001193125-18-074168 — 2.02, 9.01
- 2018-02-02 0001193125-18-029947 — 7.01, 9.01
- 2017-12-07 0001571996-17-000042 — 2.02, 9.01
- 2017-10-24 0001571996-17-000037 — 1.01, 2.03, 9.01
- 2017-09-15 0001571996-17-000027 — 5.02
- 2017-09-07 0001571996-17-000017 — 2.02, 9.01
- 2017-08-24 0001571996-17-000014 — 8.01
- 2017-06-29 0001571996-17-000011 — 3.03, 5.07, 8.01, 9.01
- 2017-06-08 0001193125-17-197638 — 2.02, 9.01
- 2017-03-30 0001193125-17-102794 — 8.01
- 2017-03-30 0001193125-17-102777 — 2.02, 9.01
- 2017-03-09 0001193125-17-076981 — 1.01, 2.03, 9.01
- 2017-01-17 0001193125-17-011125 — 8.01
- 2016-12-15 0001193125-16-793722 — 8.01
- 2016-12-08 0001193125-16-787976 — 2.02, 9.01
- 2016-11-10 0001193125-16-765964 — 1.02, 8.01
- 2016-11-04 0001193125-16-760249 — 8.01
- 2016-09-13 0001193125-16-708600 — 3.02
- 2016-09-09 0001193125-16-706567 — 1.01, 1.02, 2.01, 2.03, 3.02, 3.03, 5.02, 9.01
- 2016-09-07 0001193125-16-703370 — 3.03, 5.07, 7.01, 8.01, 9.01
- 2016-09-06 0001193125-16-702057 — 2.02, 9.01
- 2016-08-31 0001193125-16-697268 — 8.01, 9.01
- 2016-08-26 0001193125-16-692921 — 8.01, 9.01
- 2016-07-11 0001193125-16-645610 — 8.01
- 2016-07-05 0001193125-16-641679 — 8.01
- 2016-06-22 0001193125-16-629055 — 1.01, 2.03, 8.01, 9.01
- 2016-06-21 0001193125-16-627071 — 8.01, 9.01
- 2016-06-10 0001193125-16-618483 — 2.02, 9.01
- 2016-06-09 0001193125-16-617893 — 8.01, 9.01

## late-filing notifications on or before 2019-09-10

- none on or before 2019-09-10

## item 2.02 — earnings release, exhibit 99.1

[0001571996-19-000036:8k_2_02:1]
EX-99.1
2
exhibit991earnings8k.htm
EXHIBIT 99.1

[0001571996-19-000036:8k_2_02:2]
Exhibit

[0001571996-19-000036:8k_2_02:3]
Exhibit 99.1

[0001571996-19-000036:8k_2_02:4]
News Release

[0001571996-19-000036:8k_2_02:5]
Dell Technologies Reports Second Quarter Results;

[0001571996-19-000036:8k_2_02:6]
Revenue and Profits Grow Year-Over-Year

[0001571996-19-000036:8k_2_02:7]
ROUND ROCK, Texas — August 29, 2019

[0001571996-19-000036:8k_2_02:8]
News summary

[0001571996-19-000036:8k_2_02:9]
| • | Operating income of $519 million; non-GAAP operating income of $2.7 billion |

[0001571996-19-000036:8k_2_02:10]
| • | Client Solutions Group posts record revenue and units |

[0001571996-19-000036:8k_2_02:11]
| • | VMware revenue up 12% |

[0001571996-19-000036:8k_2_02:12]
| • | Record cash flow from operations of $3.3 billion |

[0001571996-19-000036:8k_2_02:13]
Full story

[0001571996-19-000036:8k_2_02:14]
Dell Technologies (NYSE: DELL) today announced financial results for its fiscal 2020 second quarter ended August 2, 2019.  Second quarter revenue was $23.4 billion, up 2 percent, and non-GAAP revenue was $23.5 billion, up 1 percent over the same period last year.  Operating income was $519 million1 compared to an operating loss of $13 million last year, and non-GAAP operating income was $2.7 billion  compared to $2.1 billion in fiscal 2019.  Net income was $4.5 billion or 19.3 percent of revenue, non-GAAP net income was $1.8 billion or 7.5 percent of non-GAAP revenue, and adjusted EBITDA was $3.2 billion or 13.5 percent of non-GAAP revenue.  Record cash flow from operations was $3.3 billion.  Diluted earnings per share was $4.83 and non-GAAP diluted earnings per share was $2.15.

[0001571996-19-000036:8k_2_02:15]
“We are in the early stages of a technology-led investment cycle.  IT spending remains healthy and our business drivers remain strong,” said Jeff Clarke, vice chairman, Dell Technologies.  “We are innovating and integrating across the Dell Technologies portfolio, from the edge to the core to the cloud, with a diverse business designed to succeed in any macro environment.  For example, core Dell orders were up four percent in the quarter excluding China.”

[0001571996-19-000036:8k_2_02:16]
1

[0001571996-19-000036:8k_2_02:17]
Second Quarter Fiscal 2020 Financial Results

[0001571996-19-000036:8k_2_02:18]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | August 2, 2019 |  | August 3, 2018 |  | Change |  | August 2, 2019 |  | August 3, 2018 |  | Change |
|  | (in millions, except percentages; unaudited) |
| Total net revenue | $ | 23,370 |  |  | $ | 22,942 |  |  | 2% |  | $ | 45,278 |  |  | $ | 44,298 |  |  | 2% |
| Operating income (loss) | $ | 519 |  |  | $ | (13 | ) |  | NM |  | $ | 1,069 |  |  | $ | (166 | ) |  | 744% |
| Net income (loss) | $ | 4,505 |  |  | $ | (461 | ) |  | NM |  | $ | 4,834 |  |  | $ | (999 | ) |  | 584% |
| Non-GAAP net revenue | $ | 23,454 |  |  | $ | 23,122 |  |  | 1% |  | $ | 45,444 |  |  | $ | 44,665 |  |  | 2% |
| Non-GAAP operating income | $ | 2,743 |  |  | $ | 2,108 |  |  | 30% |  | $ | 4,939 |  |  | $ | 4,134 |  |  | 19% |
| Non-GAAP net income | $ | 1,751 |  |  | $ | 1,259 |  |  | 39% |  | $ | 2,960 |  |  | $ | 2,438 |  |  | 21% |
| Adjusted EBITDA | $ | 3,156 |  |  | $ | 2,459 |  |  | 28% |  | $ | 5,729 |  |  | $ | 4,842 |  |  | 18% |

[0001571996-19-000036:8k_2_02:19]
Information about Dell Technologies’ use of non-GAAP financial information is provided under “Non-GAAP Financial Measures” below. All comparisons in this press release are year-over-year unless otherwise noted.

[0001571996-19-000036:8k_2_02:20]
Dell Technologies ended the quarter with a cash and investments balance of $10 billion.  The company repaid approximately $2 billion of gross debt in the quarter and approximately $2.4 billion year-to-date.  The company has paid down approximately $17 billion in gross debt over the three years since closing the EMC transaction and is on track to repay approximately $5 billion of gross debt in fiscal 2020.

[0001571996-19-000036:8k_2_02:21]
“This quarter’s results are strong thanks to our leading and diverse portfolio and consistent execution.  Operating income, gross margin and deferred revenue are up double digits, our PC business produced record results, and we saw record cash flow,” said Tom Sweet, chief financial officer, Dell Technologies.  “Couple this with our focus on long-term value creation, growing faster than competitors and the industry, growing operating income and EPS faster than revenue, and generating strong cash flow over time.  We are well-positioned for the future.”

[0001571996-19-000036:8k_2_02:22]
Operating segments summary

[0001571996-19-000036:8k_2_02:23]
Infrastructure Solutions Group revenue for the second quarter was $8.6 billion, a 7 percent decrease year-over-year.  Storage revenue was flat at $4.2 billion, while servers and networking decreased 12 percent to $4.4 billion.  Operating income was $1.1 billion for the second quarter or 12.2 percent of Infrastructure Solutions Group revenue.

[0001571996-19-000036:8k_2_02:24]
Key highlights:

[0001571996-19-000036:8k_2_02:25]
| • | Launch of the Dell Technologies Cloud, which combines the power of VMware and Dell Technologies to make hybrid cloud environments simpler to deploy and manage with consistent infrastructure, operations, and services |

[0001571996-19-000036:8k_2_02:26]
| • | Initial availability of VMware Cloud on Dell EMC, the industry’s first fully managed on-premises Data Center-as-a-Service |

[0001571996-19-000036:8k_2_02:27]
| • | Strong customer receptivity to the recently launched Unity XT midrange storage solution |

[0001571996-19-000036:8k_2_02:28]
2

[0001571996-19-000036:8k_2_02:29]
Client Solutions Group revenue for the second quarter was $11.7 billion, up 6 percent versus the second quarter of last year.  Commercial revenue grew 12 percent to $9.1 billion, and Consumer revenue was down 12 percent to $2.7 billion.  Operating income was $982 million for the second quarter or 8.4 percent of Client Solutions Group revenue.

[0001571996-19-000036:8k_2_02:30]
Key highlights:

[0001571996-19-000036:8k_2_02:31]
| • | Record revenue and units |

[0001571996-19-000036:8k_2_02:32]
| • | Double-digit revenue growth in commercial notebooks, desktops, and workstations |

[0001571996-19-000036:8k_2_02:33]
| • | Launch of the new OptiPlex 7070 Ultra, an innovative desktop with the industry’s most flexible, zero-footprint desktop design |

[0001571996-19-000036:8k_2_02:34]
| • | Launch of Unified Workspace, an integrated solution for end-user computing that simplifies the entire device lifecycle for IT while providing workers with the personalized, frictionless, ready-to-work experience they demand |

[0001571996-19-000036:8k_2_02:35]
VMware revenue was $2.5 billion for the second quarter, up 12 percent driven by broad-based strength across a diverse product portfolio.  Operating income for the second quarter was $762 million, or 30.9 percent of VMware revenue.

[0001571996-19-000036:8k_2_02:36]
Conference call information

[0001571996-19-000036:8k_2_02:37]
As previously announced, the company will hold a conference call to discuss its second quarter performance today, August 29, 2019 at 4:00 p.m. CDT.  The conference call will be broadcast live over the internet and can be accessed at https://investors.delltechnologies.com/events-and-presentations/upcoming-events

[0001571996-19-000036:8k_2_02:38]
For those unable to listen to the live broadcast, an archived version will be available at the same location for one year.

[0001571996-19-000036:8k_2_02:39]
A slide presentation containing additional financial and operating information may be downloaded from Dell Technologies’ website at https://investors.delltechnologies.com/financial-information/quarterly-results

[0001571996-19-000036:8k_2_02:40]
About Dell Technologies

[0001571996-19-000036:8k_2_02:41]
Dell Technologies (NYSE:DELL) is a unique family of businesses that helps organizations and individuals build their digital future and transform how they work and live.  The company provides customers with the industry’s broadest and most innovative technology and services portfolio spanning from edge to core to cloud.  The Dell Technologies family includes Dell, Dell EMC, Pivotal, RSA, Secureworks, Virtustream and VMware.

[0001571996-19-000036:8k_2_02:42]
CONTACTS:

[0001571996-19-000036:8k_2_02:43]
Investor Relations: Investor_Relations@Dell.com

[0001571996-19-000036:8k_2_02:44]
Media Relations: Media.Relations@Dell.com

[0001571996-19-000036:8k_2_02:45]
# # #

[0001571996-19-000036:8k_2_02:46]
Copyright © 2019 Dell Inc. or its subsidiaries.  All Rights Reserved. Dell Technologies, Dell, EMC and Dell EMC are trademarks of Dell Inc. or its subsidiaries.  Other trademarks may be trademarks of their respective owners.

[0001571996-19-000036:8k_2_02:47]
| 1 | Due to the EMC transaction, significant non-cash bridging items will remain between GAAP and non-GAAP results for the next few years. |

[0001571996-19-000036:8k_2_02:48]
Non-GAAP Financial Measures:

[0001571996-19-000036:8k_2_02:49]
This press release presents information about Dell Technologies’ non-GAAP net revenue, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, non-GAAP net income attributable to non-controlling interests, non-GAAP net income attributable to Dell Technologies Inc. - basic, non-GAAP net income attributable to Dell Technologies Inc. - diluted, non-GAAP earnings per share attributable to Dell Technologies Inc. - basic, non-GAAP earnings per share attributable to Dell Technologies Inc. - diluted, EBITDA, and adjusted EBITDA, which are non-GAAP financial measures provided as a supplement to the results provided in accordance with generally accepted accounting principles in the United States of America (“GAAP”). A reconciliation of each non-GAAP financial measure to the most directly comparable historical GAAP financial measure is provided in the attached tables for each of the fiscal periods indicated.

[0001571996-19-000036:8k_2_02:50]
Special Note on Forward-Looking Statements:

[0001571996-19-000036:8k_2_02:51]
Dell Technologies’ results or events in future periods could differ materially from those expressed or implied by these forward-looking statements because of risks, uncertainties, and other factors that include, but are not limited to, the following: competitive pressures; Dell Technologies’ reliance on third-party suppliers for products and components, including reliance on single-source or limited-source suppliers; Dell Technologies’ ability to achieve favorable pricing from its vendors; adverse global economic conditions and instability in financial markets; Dell Technologies’ execution of its growth, business and acquisition strategies; the success of Dell Technologies’ cost efficiency measures; Dell Technologies’ ability to manage solutions and products and services transitions in an effective manner; Dell Technologies’ ability to deliver high-quality products and services; Dell Technologies’ foreign operations and ability to generate substantial non-U.S. net revenue; Dell Technologies’ product, customer, and geographic sales mix, and seasonal sales trends; the performance of Dell Technologies’ sales channel partners; access to the capital markets by Dell Technologies or its customers; weak economic conditions and additional regulation; counterparty default risks; the loss by Dell Technologies of any services contracts with its customers, including government contracts, and its ability to perform such contracts at its estimated costs; Dell Technologies’ ability to develop and protect its proprietary intellectual property or obtain licenses to intellectual property developed by others on commercially reasonable and competitive terms; infrastructure disruptions, cyberattacks, or other data security breaches; Dell Technologies’ ability to hedge effectively its exposure to fluctuations in foreign currency exchange rates and interest rates; expiration of tax holidays or favorable tax rate structures, or unfavorable outcomes in tax audits and other tax compliance matters; impairment of portfolio investments; unfavorable results of legal proceedings; increased costs and additional regulations and requirements as a result of Dell Technologies’ operation as a public company; Dell Technologies’ ability to develop and maintain effective internal control over financial reporting; compliance requirements of changing environmental and safety laws; the effect of armed hostilities, terrorism, natural disasters, and public health issues; Dell Technologies’ substantial level of indebtedness; the impact of the financial performance of VMware; and the market volatility of Dell Technologies’ pension plan assets.

[0001571996-19-000036:8k_2_02:52]
This list of risks, uncertainties, and other factors is not complete. Dell Technologies discusses some of these matters more fully, as well as certain risk factors that could affect Dell Technologies’ business, financial condition, results of operations, and prospects, in its reports filed with the SEC, including Dell Technologies’ annual report on Form 10-K for the fiscal year ended February 1, 2019, quarterly reports on Form 10-Q, and current reports on Form 8-K. These filings are available for review through the SEC’s website at www.sec.gov. Any or all forward-looking statements Dell Technologies makes may turn out to be wrong and can be affected by inaccurate assumptions Dell Technologies might make or by known or unknown risks, uncertainties and other factors, including those identified in this press release. Accordingly, you should not place undue reliance on the forward-looking statements made in this press release, which speak only as of its date. Dell Technologies does not undertake to update, and expressly disclaims any duty to update, its forward-looking statements, whether as a result of circumstances or events that arise after the date they are made, new information, or otherwise.

[0001571996-19-000036:8k_2_02:53]
4

[0001571996-19-000036:8k_2_02:54]
DELL TECHNOLOGIES INC.

[0001571996-19-000036:8k_2_02:55]
Condensed Consolidated Statements of Income (Loss) and Related Financial Highlights

[0001571996-19-000036:8k_2_02:56]
(in millions, except percentages; unaudited)

[0001571996-19-000036:8k_2_02:57]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | August 2, 2019 |  | August 3, 2018 |  | Change |  | August 2, 2019 |  | August 3, 2018 |  | Change |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Products | $ | 18,110 |  |  | $ | 18,149 |  |  | —% |  | $ | 34,864 |  |  | $ | 34,820 |  |  | —% |
| Services | 5,260 |  |  | 4,793 |  |  | 10% |  | 10,414 |  |  | 9,478 |  |  | 10% |
| Total net revenue | 23,370 |  |  | 22,942 |  |  | 2% |  | 45,278 |  |  | 44,298 |  |  | 2% |
| Cost of net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Products | 13,889 |  |  | 14,943 |  |  | (7)% |  | 26,968 |  |  | 28,549 |  |  | (6)% |
| Services | 2,155 |  |  | 1,876 |  |  | 15% |  | 4,187 |  |  | 3,748 |  |  | 12% |
| Total cost of net revenue | 16,044 |  |  | 16,819 |  |  | (5)% |  | 31,155 |  |  | 32,297 |  |  | (4)% |
| Gross margin | 7,326 |  |  | 6,123 |  |  | 20% |  | 14,123 |  |  | 12,001 |  |  | 18% |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative | 5,578 |  |  | 4,961 |  |  | 12% |  | 10,649 |  |  | 9,905 |  |  | 8% |
| Research and development | 1,229 |  |  | 1,175 |  |  | 5% |  | 2,405 |  |  | 2,262 |  |  | 6% |
| Total operating expenses | 6,807 |  |  | 6,136 |  |  | 11% |  | 13,054 |  |  | 12,167 |  |  | 7% |
| Operating income (loss) | 519 |  |  | (13 | ) |  | NM |  | 1,069 |  |  | (166 | ) |  | 744% |
| Interest and other, net | (630 | ) |  | (455 | ) |  | (38)% |  | (1,323 | ) |  | (925 | ) |  | (43)% |
| Loss before income taxes | (111 | ) |  | (468 | ) |  | 76% |  | (254 | ) |  | (1,091 | ) |  | 77% |
| Income tax benefit | (4,616 | ) |  | (7 | ) |  | NM |  | (5,088 | ) |  | (92 | ) |  | NM |
| Net income (loss) | 4,505 |  |  | (461 | ) |  | NM |  | 4,834 |  |  | (999 | ) |  | 584% |
| Less: Net income attributable to non-controlling interests | 816 |  |  | 38 |  |  | NM |  | 852 |  |  | 136 |  |  | 526% |
| Net income (loss) attributable to Dell Technologies Inc. | $ | 3,689 |  |  | $ | (499 | ) |  | 839% |  | $ | 3,982 |  |  | $ | (1,135 | ) |  | 451% |
| Percentage of Total Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Gross margin | 31 | % |  | 27 | % |  |  |  | 31 | % |  | 27 | % |  |  |
| Selling, general, and administrative | 24 | % |  | 22 | % |  |  |  | 24 | % |  | 22 | % |  |  |
| Research and development | 5 | % |  | 5 | % |  |  |  | 5 | % |  | 5 | % |  |  |
| Operating expenses | 29 | % |  | 27 | % |  |  |  | 29 | % |  | 28 | % |  |  |
| Operating income (loss) | 2 | % |  | — | % |  |  |  | 2 | % |  | — | % |  |  |
| Loss before income taxes | — | % |  | (2 | )% |  |  |  | (1 | )% |  | (3 | )% |  |  |
| Net income (loss) | 19 | % |  | (2 | )% |  |  |  | 11 | % |  | (2 | )% |  |  |
| Income tax rate | 4158.6 | % |  | 1.5 | % |  |  |  | 2003.1 | % |  | 8.4 | % |  |  |

[0001571996-19-000036:8k_2_02:58]
5

[0001571996-19-000036:8k_2_02:59]
DELL TECHNOLOGIES INC.

[0001571996-19-000036:8k_2_02:60]
Consolidated Statements of Financial Position

[0001571996-19-000036:8k_2_02:61]
(in millions; unaudited)

[0001571996-19-000036:8k_2_02:62]
|  | August 2, 2019 |  | February 1, 2019 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 9,193 |  |  | $ | 9,676 |  |
| Accounts receivable, net | 11,586 |  |  | 12,371 |  |
| Short-term financing receivables, net | 4,473 |  |  | 4,398 |  |
| Inventories, net | 3,135 |  |  | 3,649 |  |
| Other current assets | 6,929 |  |  | 6,044 |  |
| Total current assets | 35,316 |  |  | 36,138 |  |
| Property, plant, and equipment, net | 5,568 |  |  | 5,259 |  |
| Long-term investments | 768 |  |  | 1,005 |  |
| Long-term financing receivables, net | 4,350 |  |  | 4,224 |  |
| Goodwill | 39,998 |  |  | 40,089 |  |
| Intangible assets, net | 19,719 |  |  | 22,270 |  |
| Other non-current assets | 9,801 |  |  | 2,835 |  |
| Total assets | $ | 115,520 |  |  | $ | 111,820 |  |
| LIABILITIES, REDEEMABLE SHARES, AND STOCKHOLDERS’ EQUITY (DEFICIT) |
| Current liabilities: |  |  |  |
| Short-term debt | $ | 5,949 |  |  | $ | 4,320 |  |
| Accounts payable | 19,411 |  |  | 19,213 |  |
| Accrued and other | 8,092 |  |  | 8,495 |  |
| Short-term deferred revenue | 13,568 |  |  | 12,944 |  |
| Total current liabilities | 47,020 |  |  | 44,972 |  |
| Long-term debt | 45,973 |  |  | 49,201 |  |
| Long-term deferred revenue | 11,780 |  |  | 11,066 |  |
| Other non-current liabilities | 6,355 |  |  | 6,327 |  |
| Total liabilities | 111,128 |  |  | 111,566 |  |
| Redeemable shares | 1,024 |  |  | 1,196 |  |
| Stockholders’ equity (deficit): |  |  |  |
| Total Dell Technologies Inc. stockholders’ equity (deficit) | (2,176 | ) |  | (5,765 | ) |
| Non-controlling interests | 5,544 |  |  | 4,823 |  |
| Total stockholders’ equity (deficit) | 3,368 |  |  | (942 | ) |
| Total liabilities, redeemable shares, and stockholders’ equity (deficit) | $ | 115,520 |  |  | $ | 111,820 |  |

[0001571996-19-000036:8k_2_02:63]
6

[0001571996-19-000036:8k_2_02:64]
DELL TECHNOLOGIES INC.

[0001571996-19-000036:8k_2_02:65]
Condensed Consolidated Statements of Cash Flows

[0001571996-19-000036:8k_2_02:66]
(in millions; unaudited)

[0001571996-19-000036:8k_2_02:67]
|  | Three Months Ended |  | Six Months Ended |
|  | August 2, 2019 |  | August 3, 2018 |  | August 2, 2019 |  | August 3, 2018 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |
| Net income (loss) | $ | 4,505 |  |  | $ | (461 | ) |  | $ | 4,834 |  |  | $ | (999 | ) |
| Adjustments to reconcile net income (loss) to net cash provided by operating activities | (1,225 | ) |  | 3,094 |  |  | (872 | ) |  | 4,791 |  |
| Change in cash from operating activities | 3,280 |  |  | 2,633 |  |  | 3,962 |  |  | 3,792 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |
| Investments: |  |  |  |  |  |  |  |
| Purchases | (32 | ) |  | (449 | ) |  | (70 | ) |  | (888 | ) |
| Maturities and sales | 93 |  |  | 791 |  |  | 430 |  |  | 1,322 |  |
| Capital expenditures | (473 | ) |  | (288 | ) |  | (1,083 | ) |  | (561 | ) |
| Capitalized software development costs | (78 | ) |  | (71 | ) |  | (184 | ) |  | (160 | ) |
| Acquisition of businesses, net | (339 | ) |  | — |  |  | (384 | ) |  | — |  |
| Divestitures of businesses, net | — |  |  | — |  |  | — |  |  | 142 |  |
| Asset acquisitions, net | — |  |  | — |  |  | — |  |  | (38 | ) |
| Asset dispositions, net | — |  |  | (3 | ) |  | (3 | ) |  | (6 | ) |
| Other | 4 |  |  | 7 |  |  | 11 |  |  | 27 |  |
| Change in cash from investing activities | (825 | ) |  | (13 | ) |  | (1,283 | ) |  | (162 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |
| Share repurchases for tax withholdings of equity awards | (148 | ) |  | (99 | ) |  | (363 | ) |  | (199 | ) |
| Proceeds from the issuance of common stock of subsidiaries | 18 |  |  | 11 |  |  | 151 |  |  | 653 |  |
| Repurchases of common stock of subsidiaries | (452 | ) |  | — |  |  | (1,044 | ) |  | — |  |
| Proceeds from debt | 2,638 |  |  | 2,774 |  |  | 12,201 |  |  | 4,637 |  |
| Repayments of debt | (4,342 | ) |  | (5,126 | ) |  | (13,911 | ) |  | (6,948 | ) |
| Other | 83 |  |  | (90 | ) |  | 44 |  |  | (130 | ) |
| Change in cash from financing activities | (2,203 | ) |  | (2,530 | ) |  | (2,922 | ) |  | (1,987 | ) |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash | (26 | ) |  | (130 | ) |  | (62 | ) |  | (216 | ) |
| Change in cash, cash equivalents, and restricted cash | 226 |  |  | (40 | ) |  | (305 | ) |  | 1,427 |  |
| Cash, cash equivalents, and restricted cash at beginning of the period | 9,709 |  |  | 15,845 |  |  | 10,240 |  |  | 14,378 |  |
| Cash, cash equivalents, and restricted cash at end of the period | $ | 9,935 |  |  | $ | 15,805 |  |  | $ | 9,935 |  |  | $ | 15,805 |  |

[0001571996-19-000036:8k_2_02:68]
7

[0001571996-19-000036:8k_2_02:69]
DELL TECHNOLOGIES INC.

[0001571996-19-000036:8k_2_02:70]
Segment Information

[0001571996-19-000036:8k_2_02:71]
(in millions, except percentages; unaudited; continued on next page)

[0001571996-19-000036:8k_2_02:72]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | August 2, 2019 |  | August 3, 2018 |  | Change |  | August 2, 2019 |  | August 3, 2018 |  | Change |
| Infrastructure Solutions Group (ISG): |
| Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Servers and networking | $ | 4,437 |  |  | $ | 5,061 |  |  | (12)% |  | $ | 8,617 |  |  | $ | 9,646 |  |  | (11)% |
| Storage | 4,184 |  |  | 4,166 |  |  | —% |  | 8,206 |  |  | 8,248 |  |  | (1)% |
| Total ISG net revenue | $ | 8,621 |  |  | $ | 9,227 |  |  | (7)% |  | $ | 16,823 |  |  | $ | 17,894 |  |  | (6)% |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| ISG operating income | $ | 1,050 |  |  | $ | 1,012 |  |  | 4% |  | $ | 1,893 |  |  | $ | 1,951 |  |  | (3)% |
| % of ISG net revenue | 12 | % |  | 11 | % |  |  |  | 11 | % |  | 11 | % |  |  |
| % of total reportable segment operating income | 38 | % |  | 47 | % |  |  |  | 38 | % |  | 46 | % |  |  |
| Client Solutions Group (CSG): |
| Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 9,077 |  |  | $ | 8,109 |  |  | 12% |  | $ | 17,384 |  |  | $ | 15,472 |  |  | 12% |
| Consumer | 2,671 |  |  | 3,019 |  |  | (12)% |  | 5,274 |  |  | 5,927 |  |  | (11)% |
| Total CSG net revenue | $ | 11,748 |  |  | $ | 11,128 |  |  | 6% |  | $ | 22,658 |  |  | $ | 21,399 |  |  | 6% |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| CSG operating income | $ | 982 |  |  | $ | 425 |  |  | 131% |  | $ | 1,775 |  |  | $ | 958 |  |  | 85% |
| % of CSG net revenue | 8 | % |  | 4 | % |  |  |  | 8 | % |  | 4 | % |  |  |
| % of total reportable segment operating income | 35 | % |  | 20 | % |  |  |  | 35 | % |  | 22 | % |  |  |
| VMware: |
| Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Total VMware net revenue | $ | 2,466 |  |  | $ | 2,194 |  |  | 12% |  | $ | 4,748 |  |  | $ | 4,222 |  |  | 12% |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| VMware operating income | $ | 762 |  |  | $ | 736 |  |  | 4% |  | $ | 1,376 |  |  | $ | 1,349 |  |  | 2% |
| % of VMware net revenue | 31 | % |  | 34 | % |  |  |  | 29 | % |  | 32 | % |  |  |
| % of total reportable segment operating income | 27 | % |  | 34 | % |  |  |  | 27 | % |  | 32 | % |  |  |

[0001571996-19-000036:8k_2_02:73]
8

[0001571996-19-000036:8k_2_02:74]
DELL TECHNOLOGIES INC.

[0001571996-19-000036:8k_2_02:75]
Segment Information

[0001571996-19-000036:8k_2_02:76]
(in millions, except percentages; unaudited; continued)

[0001571996-19-000036:8k_2_02:77]
|  | Three Months Ended |  | Six Months Ended |
|  | August 2, 2019 |  | August 3, 2018 |  | August 2, 2019 |  | August 3, 2018 |
| Reconciliation to consolidated net revenue: |  |  |  |  |  |  |
| Reportable segment net revenue | $ | 22,835 |  |  | $ | 22,549 |  |  | $ | 44,229 |  |  | $ | 43,515 |  |
| Other businesses (a) | 619 |  |  | 574 |  |  | 1,215 |  |  | 1,153 |  |
| Unallocated transactions (b) | — |  |  | (1 | ) |  | — |  |  | (3 | ) |
| Impact of purchase accounting (c) | (84 | ) |  | (180 | ) |  | (166 | ) |  | (367 | ) |
| Total consolidated net revenue | $ | 23,370 |  |  | $ | 22,942 |  |  | $ | 45,278 |  |  | $ | 44,298 |  |
| Reconciliation to consolidated operating income (loss): |  |  |  |  |
| Reportable segment operating income | $ | 2,794 |  |  | $ | 2,173 |  |  | $ | 5,044 |  |  | $ | 4,258 |  |
| Other businesses (a) | (25 | ) |  | (49 | ) |  | (78 | ) |  | (99 | ) |
| Unallocated transactions (b) | (26 | ) |  | (16 | ) |  | (27 | ) |  | (25 | ) |
| Impact of purchase accounting (c) | (102 | ) |  | (215 | ) |  | (203 | ) |  | (437 | ) |
| Amortization of intangibles | (1,060 | ) |  | (1,526 | ) |  | (2,277 | ) |  | (3,048 | ) |
| Transaction-related expenses (d) | (47 | ) |  | (104 | ) |  | (89 | ) |  | (270 | ) |
| Stock-based compensation expense (e) | (301 | ) |  | (216 | ) |  | (564 | ) |  | (415 | ) |
| Other corporate expenses (f) | (714 | ) |  | (60 | ) |  | (737 | ) |  | (130 | ) |
| Total consolidated operating income (loss) | $ | 519 |  |  | $ | (13 | ) |  | $ | 1,069 |  |  | $ | (166 | ) |

[0001571996-19-000036:8k_2_02:78]
_________________

[0001571996-19-000036:8k_2_02:79]
| (a) | Pivotal, SecureWorks, RSA Security, Virtustream, and Boomi constitute “Other businesses” and do not meet the requirements for a reportable segment, either individually or collectively. The results of Other businesses are not material to the Company’s overall results. |

[0001571996-19-000036:8k_2_02:80]
| (b) | Unallocated transactions includes other corporate items that are not allocated to Dell Technologies’ reportable segments. |

[0001571996-19-000036:8k_2_02:81]
| (c) | Impact of purchase accounting includes non-cash purchase accounting adjustments that are primarily related to the EMC merger transaction. |

[0001571996-19-000036:8k_2_02:82]
| (d) | Transaction-related expenses includes acquisition, integration, and divestiture related costs, as well as the costs incurred in the Class V transaction. |

[0001571996-19-000036:8k_2_02:83]
| (e) | Stock-based compensation expense consists of equity awards granted based on the estimated fair value of those awards at grant date. |

[0001571996-19-000036:8k_2_02:84]
| (f) | Other corporate expenses includes impairment charges and severance, facility action, and other costs. |

[0001571996-19-000036:8k_2_02:85]
9

[0001571996-19-000036:8k_2_02:86]
SUPPLEMENTAL SELECTED NON-GAAP FINANCIAL MEASURES

[0001571996-19-000036:8k_2_02:87]
These tables present information about the Company’s non-GAAP net revenue, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, non-GAAP net income attributable to non-controlling interests, non-GAAP net income attributable to Dell Technologies Inc. - basic, non-GAAP net income attributable to Dell Technologies Inc. - diluted, non-GAAP earnings per share attributable to Dell Technologies Inc. - basic, non-GAAP earnings per share attributable to Dell Technologies Inc. - diluted, EBITDA, and adjusted EBITDA, which are non-GAAP financial measures provided as a supplement to the results provided in accordance with generally accepted accounting principles in the United States of America (“GAAP”). A detailed discussion of Dell Technologies’ reasons for including these non-GAAP financial measures, the limitations associated with these measures, the items excluded from these measures, and our reason for excluding those items are presented in “Management’s Discussion and Analysis of Financial Condition and Results of Operations - Non-GAAP Financial Measures” in our periodic reports filed with the SEC. Dell Technologies encourages investors to review the non-GAAP discussion in conjunction with the presentation of non-GAAP financial measures.

[0001571996-19-000036:8k_2_02:88]
10

[0001571996-19-000036:8k_2_02:89]
DELL TECHNOLOGIES INC.

[0001571996-19-000036:8k_2_02:90]
Selected Non-GAAP Financial Measures

[0001571996-19-000036:8k_2_02:91]
(in millions, except percentages; unaudited)

[0001571996-19-000036:8k_2_02:92]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | August 2, 2019 |  | August 3, 2018 |  | Change |  | August 2, 2019 |  | August 3, 2018 |  | Change |
| Non-GAAP net revenue | $ | 23,454 |  |  | $ | 23,122 |  |  | 1% |  | $ | 45,444 |  |  | $ | 44,665 |  |  | 2% |
| Non-GAAP gross margin | $ | 7,986 |  |  | $ | 7,066 |  |  | 13% |  | $ | 15,420 |  |  | $ | 13,985 |  |  | 10% |
| % of non-GAAP net revenue | 34 | % |  | 31 | % |  |  |  | 34 | % |  | 31 | % |  |  |
| Non-GAAP operating expenses | $ | 5,243 |  |  | $ | 4,958 |  |  | 6% |  | $ | 10,481 |  |  | $ | 9,851 |  |  | 6% |
| % of non-GAAP net revenue | 22 | % |  | 21 | % |  |  |  | 23 | % |  | 22 | % |  |  |
| Non-GAAP operating income | $ | 2,743 |  |  | $ | 2,108 |  |  | 30% |  | $ | 4,939 |  |  | $ | 4,134 |  |  | 19% |
| % of non-GAAP net revenue | 12 | % |  | 9 | % |  |  |  | 11 | % |  | 9 | % |  |  |
| Non-GAAP net income (a) | $ | 1,751 |  |  | $ | 1,259 |  |  | 39% |  | $ | 2,960 |  |  | $ | 2,438 |  |  | 21% |
| % of non-GAAP net revenue | 7 | % |  | 5 | % |  |  |  | 7 | % |  | 5 | % |  |  |
| Adjusted EBITDA | $ | 3,156 |  |  | $ | 2,459 |  |  | 28% |  | $ | 5,729 |  |  | $ | 4,842 |  |  | 18% |
| % of non-GAAP net revenue | 13 | % |  | 11 | % |  |  |  | 13 | % |  | 11 | % |  |  |

[0001571996-19-000036:8k_2_02:93]
_________________

[0001571996-19-000036:8k_2_02:94]
| (a) | Non-GAAP net income has been recast to exclude fair value adjustments on equity investments, the corresponding tax effects of those adjustments, and discrete tax items. |

[0001571996-19-000036:8k_2_02:95]
11

[0001571996-19-000036:8k_2_02:96]
DELL TECHNOLOGIES INC.

[0001571996-19-000036:8k_2_02:97]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-19-000036:8k_2_02:98]
(in millions, except percentages; unaudited; continued on next page)

[0001571996-19-000036:8k_2_02:99]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | August 2, 2019 |  | August 3, 2018 |  | Change |  | August 2, 2019 |  | August 3, 2018 |  | Change |
| Net revenue | $ | 23,370 |  |  | $ | 22,942 |  |  | 2% |  | $ | 45,278 |  |  | $ | 44,298 |  |  | 2% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 84 |  |  | 180 |  |  |  |  | 166 |  |  | 367 |  |  |  |
| Non-GAAP net revenue | $ | 23,454 |  |  | $ | 23,122 |  |  | 1% |  | $ | 45,444 |  |  | $ | 44,665 |  |  | 2% |
| Gross margin | $ | 7,326 |  |  | $ | 6,123 |  |  | 20% |  | $ | 14,123 |  |  | $ | 12,001 |  |  | 18% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 519 |  |  | 718 |  |  |  |  | 1,038 |  |  | 1,428 |  |  |  |
| Impact of purchase accounting | 85 |  |  | 185 |  |  |  |  | 169 |  |  | 378 |  |  |  |
| Transaction-related expenses | — |  |  | 21 |  |  |  |  | (5 | ) |  | 137 |  |  |  |
| Stock-based compensation expense | 32 |  |  | 18 |  |  |  |  | 58 |  |  | 34 |  |  |  |
| Other corporate expenses | 24 |  |  | 1 |  |  |  |  | 37 |  |  | 7 |  |  |  |
| Non-GAAP gross margin | $ | 7,986 |  |  | $ | 7,066 |  |  | 13% |  | $ | 15,420 |  |  | $ | 13,985 |  |  | 10% |
| Operating expenses | $ | 6,807 |  |  | $ | 6,136 |  |  | 11% |  | $ | 13,054 |  |  | $ | 12,167 |  |  | 7% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | (541 | ) |  | (808 | ) |  |  |  | (1,239 | ) |  | (1,620 | ) |  |  |
| Impact of purchase accounting | (17 | ) |  | (30 | ) |  |  |  | (34 | ) |  | (59 | ) |  |  |
| Transaction-related expenses | (47 | ) |  | (83 | ) |  |  |  | (94 | ) |  | (133 | ) |  |  |
| Stock-based compensation expense | (269 | ) |  | (198 | ) |  |  |  | (506 | ) |  | (381 | ) |  |  |
| Other corporate expenses | (690 | ) |  | (59 | ) |  |  |  | (700 | ) |  | (123 | ) |  |  |
| Non-GAAP operating expenses | $ | 5,243 |  |  | $ | 4,958 |  |  | 6% |  | $ | 10,481 |  |  | $ | 9,851 |  |  | 6% |
| Operating income (loss) | $ | 519 |  |  | $ | (13 | ) |  | NM |  | $ | 1,069 |  |  | $ | (166 | ) |  | 744% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 1,060 |  |  | 1,526 |  |  |  |  | 2,277 |  |  | 3,048 |  |  |  |
| Impact of purchase accounting | 102 |  |  | 215 |  |  |  |  | 203 |  |  | 437 |  |  |  |
| Transaction-related expenses | 47 |  |  | 104 |  |  |  |  | 89 |  |  | 270 |  |  |  |
| Stock-based compensation expense | 301 |  |  | 216 |  |  |  |  | 564 |  |  | 415 |  |  |  |
| Other corporate expenses | 714 |  |  | 60 |  |  |  |  | 737 |  |  | 130 |  |  |  |
| Non-GAAP operating income | $ | 2,743 |  |  | $ | 2,108 |  |  | 30% |  | $ | 4,939 |  |  | $ | 4,134 |  |  | 19% |

[0001571996-19-000036:8k_2_02:100]
12

[0001571996-19-000036:8k_2_02:101]
DELL TECHNOLOGIES INC.

[0001571996-19-000036:8k_2_02:102]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-19-000036:8k_2_02:103]
(in millions, except percentages; unaudited; continued)

[0001571996-19-000036:8k_2_02:104]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | August 2, 2019 |  | August 3, 2018 |  | Change |  | August 2, 2019 |  | August 3, 2018 |  | Change |
| Net income (loss) | $ | 4,505 |  |  | $ | (461 | ) |  | NM |  | $ | 4,834 |  |  | $ | (999 | ) |  | 584% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 1,060 |  |  | 1,526 |  |  |  |  | 2,277 |  |  | 3,048 |  |  |  |
| Impact of purchase accounting | 102 |  |  | 215 |  |  |  |  | 203 |  |  | 437 |  |  |  |
| Transaction-related expenses | 47 |  |  | 104 |  |  |  |  | 89 |  |  | 270 |  |  |  |
| Stock-based compensation expense | 301 |  |  | 216 |  |  |  |  | 564 |  |  | 415 |  |  |  |
| Other corporate expenses | 714 |  |  | 60 |  |  |  |  | 737 |  |  | 130 |  |  |  |
| Fair value adjustments on equity investments | (80 | ) |  | (139 | ) |  |  |  | (142 | ) |  | (246 | ) |  |  |
| Aggregate adjustment for income taxes | (4,898 | ) |  | (262 | ) |  |  |  | (5,602 | ) |  | (617 | ) |  |  |
| Non-GAAP net income (a) | $ | 1,751 |  |  | $ | 1,259 |  |  | 39% |  | $ | 2,960 |  |  | $ | 2,438 |  |  | 21% |
| Net income (loss) | $ | 4,505 |  |  | $ | (461 | ) |  | NM |  | $ | 4,834 |  |  | $ | (999 | ) |  | 584% |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Interest and other, net | 630 |  |  | 455 |  |  |  |  | 1,323 |  |  | 925 |  |  |  |
| Income tax benefit | (4,616 | ) |  | (7 | ) |  |  |  | (5,088 | ) |  | (92 | ) |  |  |
| Depreciation and amortization | 1,498 |  |  | 1,931 |  |  |  |  | 3,114 |  |  | 3,845 |  |  |  |
| EBITDA | $ | 2,017 |  |  | $ | 1,918 |  |  | 5% |  | $ | 4,183 |  |  | $ | 3,679 |  |  | 14% |
| EBITDA | $ | 2,017 |  |  | $ | 1,918 |  |  | 5% |  | $ | 4,183 |  |  | $ | 3,679 |  |  | 14% |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense | 301 |  |  | 216 |  |  |  |  | 564 |  |  | 415 |  |  |  |
| Impact of purchase accounting | 84 |  |  | 145 |  |  |  |  | 167 |  |  | 367 |  |  |  |
| Transaction-related expenses | 47 |  |  | 85 |  |  |  |  | 89 |  |  | 251 |  |  |  |
| Other corporate expenses | 707 |  |  | 95 |  |  |  |  | 726 |  |  | 130 |  |  |  |
| Adjusted EBITDA | $ | 3,156 |  |  | $ | 2,459 |  |  | 28% |  | $ | 5,729 |  |  | $ | 4,842 |  |  | 18% |

[0001571996-19-000036:8k_2_02:105]
_________________

[0001571996-19-000036:8k_2_02:106]
| (a) | Non-GAAP net income has been recast to exclude fair value adjustments on equity investments, the corresponding tax effects of those adjustments, and discrete tax items. |

[0001571996-19-000036:8k_2_02:107]
13

[0001571996-19-000036:8k_2_02:108]
DELL TECHNOLOGIES INC.

[0001571996-19-000036:8k_2_02:109]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-19-000036:8k_2_02:110]
For the Three Months Ended August 2, 2019

[0001571996-19-000036:8k_2_02:111]
(in millions, except per share amounts; unaudited)

[0001571996-19-000036:8k_2_02:112]
|  | GAAP |  | Amortization of intangibles |  | Impact of purchase accounting |  | Transaction-related expenses |  | Stock-based compensation expense |  | Other corporate expenses |  | Fair value adjustments on equity investments |  | Aggregate adjustment for income taxes |  | Non-GAAP |
| Net income | $ | 4,505 |  |  | 1,060 |  |  | 102 |  |  | 47 |  |  | 301 |  |  | 714 |  |  | (80 | ) |  | (4,898 | ) |  | $ | 1,751 |  |
| Less: Net income attributable to non-controlling interests (a) | 816 |  |  | 71 |  |  | 6 |  |  | 2 |  |  | 51 |  |  | — |  |  | 100 |  |  | (915 | ) |  | 131 |  |
| Net income attributable to Dell Technologies Inc. - basic | 3,689 |  |  | 989 |  |  | 96 |  |  | 45 |  |  | 250 |  |  | 714 |  |  | (180 | ) |  | (3,983 | ) |  | 1,620 |  |
| Incremental dilution from VMware, Inc. attributable to Dell Technologies Inc. (b) | (62 | ) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (9 | ) |
| Net income attributable to Dell Technologies Inc. - diluted | $ | 3,627 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 1,611 |  |
| Earnings per share - basic | $ | 5.13 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 2.25 |  |
| Earnings per share - diluted | $ | 4.83 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 2.15 |  |
| Weighted-average shares outstanding - basic | 719 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 719 |  |
| Weighted-average shares outstanding - diluted | 751 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 751 |  |

[0001571996-19-000036:8k_2_02:113]
_________________

[0001571996-19-000036:8k_2_02:114]
| (a) | Net income attributable to non-controlling interests is calculated by multiplying the minority interest percentage of VMware, Inc., Pivotal Software, Inc., and SecureWorks Corp. by their non-GAAP net income adjustments for the period presented. |

[0001571996-19-000036:8k_2_02:115]
| (b) | Incremental dilution from VMware, Inc. attributable to Dell Technologies Inc. represents the impact of VMware, Inc.’s dilutive securities on the diluted earnings per share of Dell Technologies Inc. and is calculated by multiplying the difference between VMware’s basic and diluted earnings per share by the number of shares of VMware, Inc. common stock held by Dell Technologies Inc. |

[0001571996-19-000036:8k_2_02:116]
14

[0001571996-19-000036:8k_2_02:117]
DELL TECHNOLOGIES INC.

[0001571996-19-000036:8k_2_02:118]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-19-000036:8k_2_02:119]
For the Six Months Ended August 2, 2019

[0001571996-19-000036:8k_2_02:120]
(in millions, except per share amounts; unaudited)

[0001571996-19-000036:8k_2_02:121]
|  | GAAP |  | Amortization of intangibles |  | Impact of purchase accounting |  | Transaction-related expenses |  | Stock-based compensation expense |  | Other corporate expenses |  | Fair value adjustments on equity investments |  | Aggregate adjustment for income taxes |  | Non-GAAP |
| Net income | $ | 4,834 |  |  | 2,277 |  |  | 203 |  |  | 89 |  |  | 564 |  |  | 737 |  |  | (142 | ) |  | (5,602 | ) |  | $ | 2,960 |  |
| Less: Net income attributable to non-controlling interests (a) | 852 |  |  | 144 |  |  | 12 |  |  | 5 |  |  | 97 |  |  | — |  |  | 74 |  |  | (944 | ) |  | 240 |  |
| Net income attributable to Dell Technologies Inc. - basic | 3,982 |  |  | 2,133 |  |  | 191 |  |  | 84 |  |  | 467 |  |  | 737 |  |  | (216 | ) |  | (4,658 | ) |  | 2,720 |  |
| Incremental dilution from VMware, Inc. attributable to Dell Technologies Inc. (b) | (78 | ) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (17 | ) |
| Net income attributable to Dell Technologies Inc. - diluted | $ | 3,904 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 2,703 |  |
| Earnings per share - basic | $ | 5.55 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 3.79 |  |
| Earnings per share - diluted | $ | 5.21 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 3.60 |  |
| Weighted-average shares outstanding - basic | 718 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 718 |  |
| Weighted-average shares outstanding - diluted | 750 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 750 |  |

[0001571996-19-000036:8k_2_02:122]
_________________

[0001571996-19-000036:8k_2_02:123]
| (a) | Net income attributable to non-controlling interests is calculated by multiplying the minority interest percentage of VMware, Inc., Pivotal Software, Inc., and SecureWorks Corp. by their non-GAAP net income adjustments for the period presented. |

[0001571996-19-000036:8k_2_02:124]
| (b) | Incremental dilution from VMware, Inc. attributable to Dell Technologies Inc. represents the impact of VMware, Inc.’s dilutive securities on the diluted earnings per share of Dell Technologies Inc. and is calculated by multiplying the difference between VMware’s basic and diluted earnings per share by the number of shares of VMware, Inc. common stock held by Dell Technologies Inc. |
