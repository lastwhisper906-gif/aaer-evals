# DELL notes — 0001571996-19-000039


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001571996-19-000039:notes:1]
Basis of Presentation — The accompanying unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes filed with the U.S. Securities and Exchange Commission (“SEC”) in the Company’s Annual Report on Form 10-K for the fiscal year ended February 1, 2019.  These Condensed Consolidated Financial Statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“GAAP”).  In the opinion of management, the accompanying Condensed Consolidated Financial Statements reflect all adjustments of a normal recurring nature considered necessary to fairly state the financial position of Dell Technologies Inc. as of August 2, 2019 and February 1, 2019, the results of its operations and corresponding comprehensive income (loss) for the three and six months ended August 2, 2019 and August 3, 2018, and its cash flows for the six months ended August 2, 2019 and August 3, 2018.


## us-gaap:ConsolidationPolicyTextBlock

[0001571996-19-000039:notes:2]
[same as prior period, unchanged from 0001571996-19-000025:notes:2]


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001571996-19-000039:notes:3]
Recently Issued Accounting Pronouncements

[0001571996-19-000039:notes:4]
Measurement of Credit Losses on Financial Instruments — In June 2016, the Financial Accounting Standards Board (“FASB”) issued amended guidance which replaces the current incurred loss impairment methodology for measurement of credit losses on financial instruments with a methodology that reflects expected credit losses and requires consideration of a broader range of reasonable and supportable information to inform credit loss estimates.  Public entities must adopt the new guidance for fiscal years beginning after December 15, 2019, and interim periods within those fiscal years, with early adoption permitted for fiscal periods beginning after December 15, 2018.  The Company is currently evaluating the impact that the standard will have on the Condensed Consolidated Financial Statements.

[0001571996-19-000039:notes:5]
Intangibles - Goodwill and Other - Internal-Use Software — In August 2018, the FASB issued guidance on a customer’s accounting for implementation costs incurred in a cloud-computing arrangement when hosted by a vendor.  In a hosting arrangement that is a service contract, certain implementation costs should be capitalized and amortized over the term of the arrangement.  Public entities must adopt the new guidance for fiscal years beginning after December 15, 2019, and interim periods within those fiscal years, with early adoption permitted for fiscal periods beginning after December 15, 2018.  The Company does not expect the adoption of this guidance to have a material impact on the Condensed Consolidated Financial Statements.

[0001571996-19-000039:notes:6]
Recently Adopted Accounting Pronouncements

[0001571996-19-000039:notes:7]
Leases — In February 2016, the FASB issued amended guidance on the accounting for leasing transactions.  The primary objective of this update is to increase transparency and comparability among organizations by requiring lessees to recognize a lease liability for the obligation to make lease payments and a right-of-use (“ROU”) asset for the right to use the underlying asset for the lease term.  The guidance also results in some changes to lessor accounting and requires additional disclosures about all leasing arrangements.

[0001571996-19-000039:notes:8]
The Company adopted the standard (the “new lease standard”) as of February 2, 2019 using a modified retrospective approach, with the cumulative-effect adjustment to the opening balance of stockholders’ equity (deficit) as of the adoption date.  The Company elected to apply the practical expedient using the transition option whereby prior comparative periods were not retrospectively adjusted in the Consolidated Financial Statements.  Accordingly, prior comparative periods have not been adjusted in the Condensed Consolidated Financial Statements.  The Company also elected the package of practical expedients which does not require reassessment of initial direct costs, classification of a lease, and definition of a lease.

[0001571996-19-000039:notes:9]
The adoption of the new lease standard resulted in the recognition of $1.6 billion in operating lease liabilities and related ROU assets on the Consolidated Statements of Financial Position.  The Company recorded an immaterial adjustment to stockholders’ equity (deficit) as of February 2, 2019 to reflect the cumulative effect of adoption of the new lease standard.  As of February 2, 2019, there were no material finance leases for which the Company was a lessee.

[0001571996-19-000039:notes:10]
In the area of lessor accounting, as of February 2, 2019, the Company began to originate operating leases due to the elimination of third-party residual value guarantee insurance from the sales-type lease classification test.  Leases that commenced prior to the adoption of the new lease standard were not reassessed or restated pursuant to the practical expedients elected.  Accordingly, there was no cumulative adjustment to stockholders’ equity (deficit) related to lessor accounting.

[0001571996-19-000039:notes:11]
See Note 4 and Note 5 of the Notes to the Condensed Consolidated Financial Statements for additional information about the Company’s leases from a lessor and lessee perspective, respectively.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001571996-19-000039:notes:12]
[same as prior period, unchanged from 0001571996-19-000025:notes:12]

[0001571996-19-000039:notes:13]
[same as prior period, unchanged from 0001571996-19-000025:notes:13]

[0001571996-19-000039:notes:14]
[same as prior period, unchanged from 0001571996-19-000025:notes:14]

[0001571996-19-000039:notes:15]
[same as prior period, unchanged from 0001571996-19-000025:notes:15]

[0001571996-19-000039:notes:16]
The Company uses the implicit rate when readily determinable.  As most of the leases do not provide an implicit rate, the Company uses its incremental borrowing rate based on the information available at the commencement date to determine the present value of lease payments.  Incremental borrowing rates used to determine the present value of lease payments were derived by reference to the Company’s secured-debt yields corresponding to the lease commencement date.

[0001571996-19-000039:notes:17]
[same as prior period, unchanged from 0001571996-19-000025:notes:17]

[0001571996-19-000039:notes:18]
The Company has elected not to record leases with an initial term of 12 months or less on the Consolidated Statements of Financial Position.  Lease expense on such leases is recognized on a straight-line basis over the lease term.  The Company does not generate material sublease income and has no material related party leases.  The Company’s lease agreements do not contain any material residual value guarantees or material restrictive covenants.

[0001571996-19-000039:notes:19]
The Company’s office building agreements contain costs such as common area maintenance and other executory costs that are variable in nature.  Variable lease costs are expensed as incurred.  The Company combines lease and non-lease components, such as common area and other maintenance costs, in calculating the ROU assets and lease liabilities for its office buildings and employee vehicles.  Under certain service agreements with third-party logistics providers, the Company directs the use of the inventory within the warehouses and, therefore, controls the assets.  The warehouses and some of the equipment used are considered embedded leases.  The Company accounts for the lease and non-lease components separately.  The lease components consist of the warehouses and some of the equipment, such as conveyor belts.  The non-lease components consist of services and other shared equipment, such as material handling and transportation.  The Company allocates the consideration to the lease and non-lease components using their relative standalone values.  See Note 5 of the Notes to the Condensed Consolidated Financial Statements for additional information.

[0001571996-19-000039:notes:20]
Accounting for Leases as a Lessor — The Company’s wholly-owned subsidiary Dell Financial Services and its affiliates (“DFS”) acts as a lessor to provide equipment financing to customers through a variety of lease arrangements (“DFS leases”).  Subsequent to the adoption of the new lease standard, new DFS leases are classified as sales-type leases, direct financing leases, or operating leases.  Direct financing leases under the new lease standard are immaterial.  Leases that commenced prior to the adoption of the new lease standard were not reassessed or restated pursuant to the practical expedients elected and will continue to be accounted for under previous lease accounting guidance.

[0001571996-19-000039:notes:21]
When a contract includes lease and non-lease components, DFS allocates consideration under the contract to each component based on relative standalone selling price.  Whenever the terms of the lease transfer control to the lessee, the contract is typically classified as a sales-type lease.  Through these arrangements, the lessee has the right to substantially all of the economic benefits from use of the identified asset and has the right to direct the use of such asset during the period of use.  In many arrangements, the lessee also retains ownership at the end of the lease term.  On commencement of sales-type leases, the Company recognizes profit up-front, and amounts due from the customer under the lease contract are recognized as financing receivables on the Consolidated Statements of Financial Position.  Interest income is recognized as Net revenue over the term of the lease based on the effective interest method.  For sales and other taxes collected from the lessee, the Company has elected not to include such taxes as part of lease revenue.

[0001571996-19-000039:notes:22]
All other leases which do not meet the definition of a sales-type lease or direct financing lease are classified as operating leases.  The underlying asset in an operating lease arrangement is carried at depreciated cost as “Equipment under operating leases” within Property, plant, and equipment, net on the Consolidated Statements of Financial Position.  Depreciation is calculated using the straight-line method over the term of the underlying lease contract and is recognized as Cost of net revenue.  The depreciable basis is the original cost of the equipment less the estimated residual value of the equipment at the end of the lease term.  The Company recognizes operating lease revenue on a straight-line basis over the lease term and expenses deferred initial direct costs on the same basis.  Impairment of equipment under operating leases is assessed on the same basis as other long-lived assets.

[0001571996-19-000039:notes:23]
[same as prior period, unchanged from 0001571996-19-000025:notes:23]

[0001571996-19-000039:notes:24]
[same as prior period, unchanged from 0001571996-19-000025:notes:24]

[0001571996-19-000039:notes:25]
Financing Receivables — Financing receivables are presented net of allowance for losses and consist of customer receivables and residual interest.  Customer receivables, gross includes amounts due from customers under revolving loans, fixed-term loans, fixed-term sales-type or direct financing leases, and accrued interest.  The Company has two portfolios, consisting of: (1) fixed-term leases and loans and (2) revolving loans, and assesses risk at the portfolio level to determine the appropriate allowance levels.  The portfolio segments are further segregated into classes based on products, customer type, and credit risk evaluation: (1) Revolving - Dell Preferred Account (“DPA”); (2) Revolving - Dell Business Credit (“DBC”); and (3) Fixed-term - Consumer and Commercial.  Fixed-term leases and loans are offered to qualified small and medium-sized businesses, large commercial accounts, governmental organizations, and educational entities.  Additionally, fixed-term loans are also offered to certain individual consumer customers.  Revolving loans are offered under private label credit financing programs.  The DPA revolving loan programs are offered to individual consumer customers and the DBC revolving loan programs are offered to small and medium-sized business customers.

[0001571996-19-000039:notes:26]
The Company retains a residual interest in equipment leased under its fixed-term lease programs.  The amount of the residual interest is established at the inception of the lease based upon estimates of the value of the equipment at the end of the lease term using historical studies, industry data, and future value-at-risk demand valuation methods.  On a quarterly basis, the Company assesses the carrying amount of its recorded residual values for impairment.  Anticipated declines in specific future residual values that are considered to be other-than-temporary are recorded currently in earnings.  Generally, residual value risk on equipment under lease is not considered to be significant because of the existence of a secondary market with respect to the equipment.  The lease agreement also clearly defines applicable return conditions and remedies for non-compliance, to ensure that the leased equipment will be in good operating condition upon return.  Model changes and updates, as well as market strength and product acceptance, are monitored and adjustments are made to residual values in accordance with the significance of any such changes.  Remarketing sales staff works closely with customers and dealers to manage the sale of lease returns and the recovery of residual exposure.  As of August 2, 2019, the Company has not recorded significant residual value impairment.

[0001571996-19-000039:notes:27]
[same as prior period, unchanged from 0001571996-19-000025:notes:27]


## us-gaap:FairValueDisclosuresTextBlock

[0001571996-19-000039:notes:28]
[same as prior period, unchanged from 0001571996-19-000025:notes:28]

[0001571996-19-000039:notes:29]
[same as prior period, unchanged from 0001571996-19-000025:notes:29]

[0001571996-19-000039:notes:30]
|  | August 2, 2019 |  | February 1, 2019 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | QuotedPricesin ActiveMarkets forIdenticalAssets |  | SignificantOtherObservableInputs |  | SignificantUnobservableInputs |  |  |  | QuotedPricesin ActiveMarkets forIdenticalAssets |  | SignificantOtherObservableInputs |  | SignificantUnobservableInputs |  |  |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 4,832 |  |  | $ | — |  |  | $ | — |  |  | $ | 4,832 |  |  | $ | 5,221 |  |  | $ | — |  |  | $ | — |  |  | $ | 5,221 |  |
| Equity and other securities | 8 |  |  | — |  |  | — |  |  | 8 |  |  | 314 |  |  | 20 |  |  | — |  |  | 334 |  |
| Derivative instruments | — |  |  | 251 |  |  | — |  |  | 251 |  |  | — |  |  | 97 |  |  | — |  |  | 97 |  |
| Total assets | $ | 4,840 |  |  | $ | 251 |  |  | $ | — |  |  | $ | 5,091 |  |  | $ | 5,535 |  |  | $ | 117 |  |  | $ | — |  |  | $ | 5,652 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative instruments | $ | — |  |  | $ | 36 |  |  | $ | — |  |  | $ | 36 |  |  | $ | — |  |  | $ | 60 |  |  | $ | — |  |  | $ | 60 |  |
| Total liabilities | $ | — |  |  | $ | 36 |  |  | $ | — |  |  | $ | 36 |  |  | $ | — |  |  | $ | 60 |  |  | $ | — |  |  | $ | 60 |  |

[0001571996-19-000039:notes:31]
[same as prior period, unchanged from 0001571996-19-000025:notes:31]

[0001571996-19-000039:notes:32]
Money Market Funds — The Company’s investment in money market funds that are classified as cash equivalents hold underlying investments with a weighted average maturity of 90 days or less and are recognized at fair value.  The valuations of these securities are based on quoted prices in active markets for identical assets, when available, or pricing models whereby all significant inputs are observable or can be derived from or corroborated by observable market data.  The Company reviews security pricing and assesses liquidity on a quarterly basis.  As of August 2, 2019, the Company’s U.S. portfolio had no material exposure to money market funds with a fluctuating net asset value.

[0001571996-19-000039:notes:33]
[same as prior period, unchanged from 0001571996-19-000025:notes:33]

[0001571996-19-000039:notes:34]
[same as prior period, unchanged from 0001571996-19-000025:notes:34]

[0001571996-19-000039:notes:35]
Deferred Compensation Plans —The Company offers deferred compensation plans for eligible employees, which allow participants to defer payment for a portion of their compensation.  Assets were the same as liabilities associated with the plans at approximately $226 million and $192 million as of August 2, 2019 and February 1, 2019, respectively, and are included in other assets and other liabilities on the Condensed Consolidated Statements of Financial Position.  The net impact to the Condensed Consolidated Statements of Income (Loss) is not material since changes in the fair value of the assets substantially offset changes in the fair value of the liabilities.  As such, assets and liabilities associated with these plans have not been included in the above table.  These fair values were determined based on observable market prices in a less active market or based on valuation methodologies using observable inputs and were categorized as Level 2 in the fair value hierarchy.

[0001571996-19-000039:notes:36]
[same as prior period, unchanged from 0001571996-19-000025:notes:35]

[0001571996-19-000039:notes:37]
As of August 2, 2019 and February 1, 2019, the Company held private strategic investments of $760 million and $671 million, respectively.  As these investments represent early-stage companies without readily determinable fair values, they are not included in the recurring fair value table above.

[0001571996-19-000039:notes:38]
[same as prior period, unchanged from 0001571996-19-000025:notes:37]

[0001571996-19-000039:notes:39]
[same as prior period, unchanged from 0001571996-19-000025:notes:38]

[0001571996-19-000039:notes:40]
|  | August 2, 2019 |  | February 1, 2019 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Secured Credit Facilities | $ | 9.4 |  |  | $ | 9.5 |  |  | $ | 12.5 |  |  | $ | 12.6 |  |
| First Lien Notes | $ | 20.5 |  |  | $ | 22.8 |  |  | $ | 19.8 |  |  | $ | 21.0 |  |
| Unsecured Notes and Debentures | $ | 1.2 |  |  | $ | 1.4 |  |  | $ | 1.8 |  |  | $ | 1.9 |  |
| Senior Notes | $ | 3.2 |  |  | $ | 3.4 |  |  | $ | 3.1 |  |  | $ | 3.4 |  |
| EMC Notes | $ | 3.0 |  |  | $ | 3.0 |  |  | $ | 3.0 |  |  | $ | 2.9 |  |
| VMware Notes | $ | 4.0 |  |  | $ | 4.0 |  |  | $ | 4.0 |  |  | $ | 3.9 |  |
| Margin Loan Facility | $ | 4.0 |  |  | $ | 4.0 |  |  | $ | 3.3 |  |  | $ | 3.4 |  |

[0001571996-19-000039:notes:41]
[same as prior period, unchanged from 0001571996-19-000025:notes:40]

[0001571996-19-000039:notes:42]
[same as prior period, unchanged from 0001571996-19-000025:notes:41]

[0001571996-19-000039:notes:43]
The following table presents the carrying value of the Company’s strategic investments in publicly-traded and privately-held companies as of the dates indicated:

[0001571996-19-000039:notes:44]
|  | August 2, 2019 |  | February 1, 2019 |
|  | Cost |  | Unrealized Gain |  | Unrealized (Loss) |  | Carrying Value |  | Cost |  | Unrealized Gain |  | Unrealized (Loss) |  | Carrying Value |
|  | (in millions) |
| Equity and other securities | $ | 715 |  |  | $ | 78 |  |  | $ | (25 | ) |  | $ | 768 |  |  | $ | 638 |  |  | $ | 539 |  |  | $ | (172 | ) |  | $ | 1,005 |  |

[0001571996-19-000039:notes:45]
For the six months ended August 2, 2019, the equity and other securities without readily determinable fair values increased by $78 million, due to upward adjustments for observable price changes, offset by $8 million of downward adjustments that were primarily attributable to impairments.  The remainder of equity and other securities consists of publicly-traded investments that are measured at fair value on a recurring basis.


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0001571996-19-000039:notes:46]
The Company offers or arranges various financing options, services, and alternative payment structures for its customers in North America, Europe, Australia, and New Zealand through DFS.  The Company also arranges financing for some of its customers in various countries where DFS does not currently operate as a captive enterprise.  The key activities of DFS include originating, collecting, and servicing customer financing arrangements primarily related to the purchase or use of Dell Technologies products and services.  In some cases, DFS also offers financing on the purchase of third-party technology products that complement the Dell Technologies portfolio of products and services.  New financing originations were $2.0 billion and $1.9 billion for the three months ended August 2, 2019 and August 3, 2018, respectively, and were $3.7 billion and $3.6 billion for the six months ended August 2, 2019 and August 3, 2018, respectively.

[0001571996-19-000039:notes:47]
[same as prior period, unchanged from 0001571996-19-000025:notes:47]

[0001571996-19-000039:notes:48]
[same as prior period, unchanged from 0001571996-19-000025:notes:48]

[0001571996-19-000039:notes:49]
[same as prior period, unchanged from 0001571996-19-000025:notes:49]

[0001571996-19-000039:notes:50]
[same as prior period, unchanged from 0001571996-19-000025:notes:50]

[0001571996-19-000039:notes:51]
[same as prior period, unchanged from 0001571996-19-000025:notes:51]

[0001571996-19-000039:notes:52]
[same as prior period, unchanged from 0001571996-19-000025:notes:52]

[0001571996-19-000039:notes:53]
|  | August 2, 2019 |  | February 1, 2019 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Financing receivables, net: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer receivables, gross (a) | $ | 778 |  |  | $ | 7,544 |  |  | $ | 8,322 |  |  | $ | 835 |  |  | $ | 7,249 |  |  | $ | 8,084 |  |
| Allowances for losses | (67 | ) |  | (71 | ) |  | (138 | ) |  | (75 | ) |  | (61 | ) |  | (136 | ) |
| Customer receivables, net | 711 |  |  | 7,473 |  |  | 8,184 |  |  | 760 |  |  | 7,188 |  |  | 7,948 |  |
| Residual interest | — |  |  | 639 |  |  | 639 |  |  | — |  |  | 674 |  |  | 674 |  |
| Financing receivables, net | $ | 711 |  |  | $ | 8,112 |  |  | $ | 8,823 |  |  | $ | 760 |  |  | $ | 7,862 |  |  | $ | 8,622 |  |
| Short-term | $ | 711 |  |  | $ | 3,762 |  |  | $ | 4,473 |  |  | $ | 760 |  |  | $ | 3,638 |  |  | $ | 4,398 |  |
| Long-term | $ | — |  |  | $ | 4,350 |  |  | $ | 4,350 |  |  | $ | — |  |  | $ | 4,224 |  |  | $ | 4,224 |  |

[0001571996-19-000039:notes:54]
[same as prior period, unchanged from 0001571996-19-000025:notes:54]

[0001571996-19-000039:notes:55]
[same as prior period, unchanged from 0001571996-19-000025:notes:55]

[0001571996-19-000039:notes:56]
The following tables present the changes in allowance for financing receivable losses for the periods indicated:

[0001571996-19-000039:notes:57]
|  | Three Months Ended |
|  | August 2, 2019 |  | August 3, 2018 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |  |  |  |  |  |  |  |  |  |  |  |
| Balances at beginning of period | $ | 70 |  |  | $ | 73 |  |  | $ | 143 |  |  | $ | 77 |  |  | $ | 62 |  |  | $ | 139 |  |
| Charge-offs, net of recoveries | (15 | ) |  | (9 | ) |  | (24 | ) |  | (19 | ) |  | (12 | ) |  | (31 | ) |
| Provision charged to income statement | 12 |  |  | 7 |  |  | 19 |  |  | 17 |  |  | 1 |  |  | 18 |  |
| Balances at end of period | $ | 67 |  |  | $ | 71 |  |  | $ | 138 |  |  | $ | 75 |  |  | $ | 51 |  |  | $ | 126 |  |
|  | Six Months Ended |
|  | August 2, 2019 |  | August 3, 2018 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |  |  |  |  |  |  |  |  |  |  |  |
| Balances at beginning of period | $ | 75 |  |  | $ | 61 |  |  | $ | 136 |  |  | $ | 81 |  |  | $ | 64 |  |  | $ | 145 |  |
| Charge-offs, net of recoveries | (35 | ) |  | (12 | ) |  | (47 | ) |  | (39 | ) |  | (17 | ) |  | (56 | ) |
| Provision charged to income statement | 27 |  |  | 22 |  |  | 49 |  |  | 33 |  |  | 4 |  |  | 37 |  |
| Balances at end of period | $ | 67 |  |  | $ | 71 |  |  | $ | 138 |  |  | $ | 75 |  |  | $ | 51 |  |  | $ | 126 |  |

[0001571996-19-000039:notes:58]
[same as prior period, unchanged from 0001571996-19-000025:notes:58]

[0001571996-19-000039:notes:59]
[same as prior period, unchanged from 0001571996-19-000025:notes:59]

[0001571996-19-000039:notes:60]
|  | August 2, 2019 |  | February 1, 2019 |
|  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |
|  | (in millions) |
| Revolving — DPA | $ | 537 |  |  | $ | 47 |  |  | $ | 18 |  |  | $ | 602 |  |  | $ | 583 |  |  | $ | 53 |  |  | $ | 21 |  |  | $ | 657 |  |
| Revolving — DBC | 153 |  |  | 19 |  |  | 4 |  |  | 176 |  |  | 155 |  |  | 19 |  |  | 4 |  |  | 178 |  |
| Fixed-term — Consumer and Commercial | 6,749 |  |  | 688 |  |  | 107 |  |  | 7,544 |  |  | 6,282 |  |  | 878 |  |  | 89 |  |  | 7,249 |  |
| Total customer receivables, gross | $ | 7,439 |  |  | $ | 754 |  |  | $ | 129 |  |  | $ | 8,322 |  |  | $ | 7,020 |  |  | $ | 950 |  |  | $ | 114 |  |  | $ | 8,084 |  |

[0001571996-19-000039:notes:61]
[same as prior period, unchanged from 0001571996-19-000025:notes:61]

[0001571996-19-000039:notes:62]
[same as prior period, unchanged from 0001571996-19-000025:notes:62]

[0001571996-19-000039:notes:63]
[same as prior period, unchanged from 0001571996-19-000025:notes:63]

[0001571996-19-000039:notes:64]
|  | August 2, 2019 |  | February 1, 2019 |
|  | Higher |  | Mid |  | Lower |  | Total |  | Higher |  | Mid |  | Lower |  | Total |
|  | (in millions) |
| Revolving — DPA | $ | 121 |  |  | $ | 178 |  |  | $ | 303 |  |  | $ | 602 |  |  | $ | 128 |  |  | $ | 192 |  |  | $ | 337 |  |  | $ | 657 |  |
| Revolving — DBC | $ | 45 |  |  | $ | 54 |  |  | $ | 77 |  |  | $ | 176 |  |  | $ | 47 |  |  | $ | 54 |  |  | $ | 77 |  |  | $ | 178 |  |
| Fixed-term — Consumer and Commercial | $ | 4,377 |  |  | $ | 1,892 |  |  | $ | 1,275 |  |  | $ | 7,544 |  |  | $ | 3,980 |  |  | $ | 1,984 |  |  | $ | 1,285 |  |  | $ | 7,249 |  |

[0001571996-19-000039:notes:65]
[same as prior period, unchanged from 0001571996-19-000025:notes:65]

[0001571996-19-000039:notes:66]
[same as prior period, unchanged from 0001571996-19-000025:notes:66]

[0001571996-19-000039:notes:67]
Interest income on sales-type lease receivables was $66 million and $130 million for the three and six months ended August 2, 2019, respectively.

[0001571996-19-000039:notes:68]
The following table presents the net revenue, cost of net revenue, and gross margin recognized at the commencement date of  sales-type leases for the periods indicated:

[0001571996-19-000039:notes:69]
|  | Three Months Ended |  | Six Months Ended |
|  | August 2, 2019 |  | August 2, 2019 |
|  | (in millions) |
| Net revenue — products | $ | 223 |  |  | $ | 353 |  |
| Cost of net revenue — products | 179 |  |  | 260 |  |
| Gross margin — products | $ | 44 |  |  | $ | 93 |  |

[0001571996-19-000039:notes:70]
The following table presents the future maturity of the Company’s fixed-term customer leases and associated financing payments, and reconciles the undiscounted cash flows to the customer receivables, gross recognized on the Condensed Consolidated Statements of Financial Position as of the date indicated:

[0001571996-19-000039:notes:71]
|  | August 2, 2019 |
| Fiscal Years | (in millions) |
| Fiscal 2020 (remaining six months) | $ | 1,488 |  |
| Fiscal 2021 | 2,115 |  |
| Fiscal 2022 | 1,322 |  |
| Fiscal 2023 | 542 |  |
| Fiscal 2024 and beyond | 198 |  |
| Total undiscounted cash flows | 5,665 |  |
| Fixed-term loans | 2,373 |  |
| Revolving loans | 778 |  |
| Less: unearned income | (494 | ) |
| Total customer receivables, gross | $ | 8,322 |  |

[0001571996-19-000039:notes:72]
[same as prior period, unchanged from 0001571996-19-000025:notes:72]

[0001571996-19-000039:notes:73]
[same as prior period, unchanged from 0001571996-19-000025:notes:73]

[0001571996-19-000039:notes:74]
[same as prior period, unchanged from 0001571996-19-000025:notes:74]

[0001571996-19-000039:notes:75]
|  | August 2, 2019 |
|  | (in millions) |
| Equipment under operating lease, gross | $ | 455 |  |
| Less: accumulated depreciation | (29 | ) |
| Equipment under operating lease, net | $ | 426 |  |

[0001571996-19-000039:notes:76]
As of February 1, 2019, the Company’s equipment under operating lease, net was immaterial.

[0001571996-19-000039:notes:77]
Operating lease income relating to lease payments was $27 million and $31 million for the three and six months ended August 2, 2019, respectively.  Depreciation expense was $21 million and $24 million for the three and six months ended August 2, 2019, respectively.

[0001571996-19-000039:notes:78]
The following table presents the future payments to be received by the Company as lessor in operating lease contracts as of the date indicated:

[0001571996-19-000039:notes:79]
|  | August 2, 2019 |
| Fiscal Years | (in millions) |
| Fiscal 2020 (remaining six months) | $ | 79 |  |
| Fiscal 2021 | 140 |  |
| Fiscal 2022 | 132 |  |
| Fiscal 2023 | 55 |  |
| Fiscal 2024 and beyond | 3 |  |
| Total | $ | 409 |  |

[0001571996-19-000039:notes:80]
[same as prior period, unchanged from 0001571996-19-000025:notes:80]

[0001571996-19-000039:notes:81]
The Company maintains programs that facilitate the funding of leases, loans, and other alternative payment structures in the capital markets.  For DFS debt under securitization programs, the Company’s risk of loss is limited to transferred lease and loan payments and associated equipment, and the credit holders under these programs have no recourse to the Company.  The following table presents DFS debt as of the dates indicated.  The table excludes the allocated portion of the Company’s other borrowings, which represents the additional amount considered to fund the DFS business.

[0001571996-19-000039:notes:82]
|  | August 2, 2019 |  | February 1, 2019 |
|  | (in millions) |
| DFS U.S. debt: |  |  |  |
| Securitization facilities | $ | 2,287 |  |  | $ | 1,914 |  |
| Fixed-term securitization offerings | 2,438 |  |  | 2,303 |  |
| Other | 201 |  |  | 223 |  |
| Total DFS U.S. debt | 4,926 |  |  | 4,440 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 690 |  |  | 584 |  |
| Other borrowings | 831 |  |  | 708 |  |
| Note payable | 198 |  |  | 197 |  |
| Total DFS international debt | 1,719 |  |  | 1,489 |  |
| Total DFS debt | $ | 6,645 |  |  | $ | 5,929 |  |
| Total short-term DFS debt | $ | 3,703 |  |  | $ | 3,113 |  |
| Total long-term DFS debt | $ | 2,942 |  |  | $ | 2,816 |  |

[0001571996-19-000039:notes:83]
[same as prior period, unchanged from 0001571996-19-000025:notes:83]

[0001571996-19-000039:notes:84]
Securitization Facilities — The Company maintains separate securitization facilities in the United States for fixed-term leases and loans and for revolving loans.  This debt is collateralized solely by the U.S. loan and lease payments and associated equipment in the facilities.  The debt has a variable interest rate and the duration of the debt is based on the terms of the underlying loan and lease payment streams.  As of August 2, 2019, the total debt capacity related to the U.S. securitization facilities was $3.9 billion.  The Company enters into interest swap agreements to effectively convert a portion of its securitization debt from a floating rate to a fixed rate.  See Note 7 of the Notes to the Condensed Consolidated Financial Statements for additional information about interest rate swaps.

[0001571996-19-000039:notes:85]
The Company’s U.S. securitization facility for revolving loans is effective through June 25, 2022.  The Company’s two U.S. securitization facilities for fixed-term leases and loans are effective through February 22, 2020 and July 26, 2022, respectively.  Subsequent to August 2, 2019, the Company renewed one of its facilities to extend the effective date from February 22, 2020 to August 22, 2021, and to increase the total U.S. securitization debt capacity by $0.1 billion.

[0001571996-19-000039:notes:86]
The securitization facilities contain standard structural features related to the performance of the securitized receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the facility, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of August 2, 2019, these criteria were met.

[0001571996-19-000039:notes:87]
Fixed-Term Securitization Offerings — The Company periodically issues asset-backed debt securities under fixed-term securitization programs to private investors.  The asset-backed debt securities are collateralized solely by the U.S. fixed-term leases and loans in the offerings, which are held by Special Purpose Entities (“SPEs”), as discussed below.  The interest rate on these securities is fixed and ranges from 2.14% to 3.97% per annum, and the duration of these securities is based on the terms of the underlying lease and loan payment streams.

[0001571996-19-000039:notes:88]
[same as prior period, unchanged from 0001571996-19-000025:notes:88]

[0001571996-19-000039:notes:89]
Securitization Facility — The Company maintains a securitization facility in Europe for fixed-term leases and loans.  This facility is effective through December 21, 2020 and has a total debt capacity of $887 million as of August 2, 2019.

[0001571996-19-000039:notes:90]
The securitization facility contains standard structural features related to the performance of the securitized receivables which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the program, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of August 2, 2019, these criteria were met.

[0001571996-19-000039:notes:91]
Other Borrowings — In connection with the Company’s international financing operations, the Company has entered into revolving structured financing debt programs related to its fixed-term lease and loan products sold in Canada, Europe, Australia, and New Zealand.  The Canadian facility, which is collateralized solely by Canadian loan and lease payments and associated equipment, had a total debt capacity of $227 million as of August 2, 2019, and is effective through January 16, 2023.  The European facility, which is collateralized solely by European loan and lease payments and associated equipment, had a total debt capacity of $665 million as of August 2, 2019, and is effective through December 14, 2020.  The Australia and New Zealand facility, which is collateralized solely by Australia and New Zealand loan and lease payments and associated equipment, had a total debt capacity of $190 million as of August 2, 2019, and is effective through January 29, 2020.

[0001571996-19-000039:notes:92]
Note Payable — On November 27, 2017, the Company entered into an unsecured credit agreement to fund receivables in Mexico.  As of August 2, 2019, the aggregate principal amount of the note payable is $198 million.  The note bears interest at either the applicable London Interbank Offered Rate (“LIBOR”) plus 2.25%, for the borrowings denominated in U.S. dollars, or the Mexican Interbank Equilibrium Interest Rate (“TIIE”) plus 2.00%, for the borrowings denominated in Mexican pesos.  The note will mature on December 1, 2020.  Although the note is unsecured, the Company intends to manage the note in the same manner as its structured financing programs, so that the collections from loan and lease payments and associated equipment in Mexico will be used to pay down principal and interest of the note.

[0001571996-19-000039:notes:93]
[same as prior period, unchanged from 0001571996-19-000025:notes:93]

[0001571996-19-000039:notes:94]
[same as prior period, unchanged from 0001571996-19-000025:notes:94]

[0001571996-19-000039:notes:95]
[same as prior period, unchanged from 0001571996-19-000025:notes:95]

[0001571996-19-000039:notes:96]
|  | August 2, 2019 |  | February 1, 2019 |
|  | (in millions) |
| Assets held by consolidated VIEs, net: |  |  |  |  |  |
| Short-term, net | $ | 3,072 |  |  | $ | 2,940 |  |
| Long-term, net | 3,011 |  |  | 2,508 |  |
| Assets held by consolidated VIEs, net | $ | 6,083 |  |  | $ | 5,448 |  |

[0001571996-19-000039:notes:97]
Loan and lease payments and associated equipment transferred via securitization through SPEs were $1.3 billion and $1.2 billion for the three months ended August 2, 2019 and August 3, 2018, respectively, and $2.8 billion and $2.5 billion for the six months ended August 2, 2019 and August 3, 2018, respectively.

[0001571996-19-000039:notes:98]
Some of the SPEs have entered into financing arrangements with multi-seller conduits that, in turn, issue asset-backed debt securities in the capital markets.  The DFS debt outstanding, which is collateralized by the loan and lease payments and associated equipment held by the consolidated VIEs, was $5.4 billion and $4.8 billion as of August 2, 2019 and February 1, 2019, respectively.  The Company’s risk of loss related to securitized receivables is limited to the amount by which the Company’s right to receive collections for assets securitized exceeds the amount required to pay interest, principal, and fees and expenses related to the asset-backed securities.  The Company provides credit enhancement to the securitization in the form of over-collateralization.

[0001571996-19-000039:notes:99]
[same as prior period, unchanged from 0001571996-19-000025:notes:99]

[0001571996-19-000039:notes:100]
To manage certain concentrations of customer credit exposure, the Company may sell selected fixed-term customer receivables to unrelated third parties on a periodic basis.  The amount of customer receivables sold was $246 million and $271 million for the six months ended August 2, 2019 and August 3, 2018, respectively.


## us-gaap:ScheduleOfDebtTableTextBlock

[0001571996-19-000039:notes:101]
The following table presents DFS debt as of the dates indicated.  The table excludes the allocated portion of the Company’s other borrowings, which represents the additional amount considered to fund the DFS business.

[0001571996-19-000039:notes:102]
The following table presents the Company’s outstanding debt as of the dates indicated:

[0001571996-19-000039:notes:103]
|  | August 2, 2019 |  | February 1, 2019 |
|  | (in millions) |
| Secured Debt |  |  |  |
| Senior Secured Credit Facilities: |  |  |  |
| 4.24% Term Loan B Facility due September 2023 | $ | 4,913 |  |  | $ | 4,938 |  |
| 4.16% Term Loan A-2 Facility due September 2021 | — |  |  | 4,116 |  |
| 3.99% Term Loan A-4 Facility due December 2023 | 1,009 |  |  | 1,650 |  |
| 4.25% Term Loan A-5 Facility due December 2019 | — |  |  | 2,016 |  |
| 4.07% Term Loan A-6 Facility due March 2024 | 3,588 |  |  | — |  |
| First Lien Notes: |  |  |  |
| 3.48% due June 2019 | — |  |  | 3,750 |  |
| 4.42% due June 2021 | 4,500 |  |  | 4,500 |  |
| 5.45% due June 2023 | 3,750 |  |  | 3,750 |  |
| 4.00% due July 2024 | 1,000 |  |  | — |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 4.90% due October 2026 | 1,750 |  |  | — |  |
| 5.30% due October 2029 | 1,750 |  |  | — |  |
| 8.10% due July 2036 | 1,500 |  |  | 1,500 |  |
| 8.35% due July 2046 | 2,000 |  |  | 2,000 |  |
| Unsecured Debt |  |  |  |
| Unsecured Notes and Debentures: |  |  |  |
| 5.875% due June 2019 | — |  |  | 600 |  |
| 4.625% due April 2021 | 400 |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| Senior Notes: |  |  |  |
| 5.875% due June 2021 | 1,625 |  |  | 1,625 |  |
| 7.125% due June 2024 | 1,625 |  |  | 1,625 |  |
| EMC Notes: |  |  |  |
| 2.650% due June 2020 | 2,000 |  |  | 2,000 |  |
| 3.375% due June 2023 | 1,000 |  |  | 1,000 |  |
| VMware Notes: |  |  |  |
| 2.30% due August 2020 | 1,250 |  |  | 1,250 |  |
| 2.95% due August 2022 | 1,500 |  |  | 1,500 |  |
| 3.90% due August 2027 | 1,250 |  |  | 1,250 |  |
| DFS Debt (Note 4) | 6,645 |  |  | 5,929 |  |
| Other |  |  |  |
| 4.51% Margin Loan Facility due April 2022 | 4,000 |  |  | 3,350 |  |
| Other | 85 |  |  | 38 |  |
| Total debt, principal amount | $ | 52,592 |  |  | $ | 54,239 |  |

[0001571996-19-000039:notes:104]
|  | August 2, 2019 |  | February 1, 2019 |
|  | (in millions) |
| Total debt, principal amount | $ | 52,592 |  |  | $ | 54,239 |  |
| Unamortized discount, net of unamortized premium | (252 | ) |  | (271 | ) |
| Debt issuance costs | (418 | ) |  | (447 | ) |
| Total debt, carrying value | $ | 51,922 |  |  | $ | 53,521 |  |
| Total short-term debt, carrying value | $ | 5,949 |  |  | $ | 4,320 |  |
| Total long-term debt, carrying value | $ | 45,973 |  |  | $ | 49,201 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0001571996-19-000039:notes:105]
[same as prior period, unchanged from 0001571996-19-000025:notes:105]

[0001571996-19-000039:notes:106]
The Company enters into leasing transactions in which the Company is lessee.  These lease contracts are typically classified as operating leases.  The Company’s lease contracts are generally for office buildings used to conduct its business, and the determination of whether such contracts contain leases generally does not require significant estimates or judgments.  The Company also leases certain global logistics warehouses, employee vehicles, and equipment.  As of August 2, 2019, the remaining terms of the Company’s leases range from one year to 27 years.

[0001571996-19-000039:notes:107]
[same as prior period, unchanged from 0001571996-19-000025:notes:107]

[0001571996-19-000039:notes:108]
In adopting the new lease standard discussed in Note 1 and Note 2 of the Notes to the Condensed Consolidated Financial Statements, the Company elected to apply a transition method that does not require the retrospective application to periods prior to adoption.  Financial information associated with the Company’s leases in which the Company is lessee is contained in this footnote.  As of August 2, 2019, there were no material finance leases for which the Company was a lessee.

[0001571996-19-000039:notes:109]
The following table presents components of lease costs included in the Condensed Consolidated Statements of Income (Loss) for the periods indicated:

[0001571996-19-000039:notes:110]
|  | Three Months Ended |  | Six Months Ended |
|  | August 2, 2019 |  | August 2, 2019 |
|  | (in millions) |
| Operating lease costs | $ | 126 |  |  | $ | 243 |  |
| Variable costs | 41 |  |  | 79 |  |
| Total lease costs | $ | 167 |  |  | $ | 322 |  |

[0001571996-19-000039:notes:111]
During the six months ended August 2, 2019, sublease income, finance lease costs, and short-term lease costs were immaterial.

[0001571996-19-000039:notes:112]
The following table presents supplemental information related to operating leases included in the Condensed Consolidated Statements of Financial Position as of the date indicated:

[0001571996-19-000039:notes:113]
|  | Classification |  | August 2, 2019 |
|  |  |  | (in millions, except for term and discount rate) |
| Operating lease ROU assets | Other non-current assets |  | $ | 1,630 |  |
| Current operating lease liabilities | Accrued and other current liabilities |  | $ | 412 |  |
| Non-current operating lease liabilities | Other non-current liabilities |  | 1,234 |  |
| Total operating lease liabilities |  |  | $ | 1,646 |  |
| Weighted-average remaining lease term (in years) |  |  | 8.82 |  |
| Weighted-average discount rate |  |  | 3.99 | % |

[0001571996-19-000039:notes:114]
The following table presents supplemental cash flow information related to leases for the period indicated:

[0001571996-19-000039:notes:115]
|  | Six Months Ended |
|  | August 2, 2019 |
|  | (in millions) |
| Cash paid for amounts included in the measurement of lease liabilities - operating cash outflows from operating leases | $ | 241 |  |
| ROU assets obtained in exchange for new operating lease liabilities | $ | 254 |  |

[0001571996-19-000039:notes:116]
The following table presents the future maturity of the Company’s operating lease liabilities under non-cancelable leases and reconciles the undiscounted cash flows for these leases to the lease liability recognized on the Condensed Consolidated Statements of Financial Position as of the date indicated:

[0001571996-19-000039:notes:117]
|  | August 2, 2019 |
| Fiscal Years | (in millions) |
| Fiscal 2020 (remaining six months) | $ | 224 |  |
| Fiscal 2021 | 419 |  |
| Fiscal 2022 | 321 |  |
| Fiscal 2023 | 234 |  |
| Fiscal 2024 | 153 |  |
| Thereafter | 696 |  |
| Total lease payments | $ | 2,047 |  |
| Less: Imputed interest | (401 | ) |
| Total | $ | 1,646 |  |
| Current operating lease liabilities | $ | 412 |  |
| Non-current operating lease liabilities | $ | 1,234 |  |

[0001571996-19-000039:notes:118]
[same as prior period, unchanged from 0001571996-19-000025:notes:118]

[0001571996-19-000039:notes:119]
As of August 2, 2019, the Company has additional operating leases that have not yet commenced of $393 million.  These operating leases will commence during Fiscal 2020 and Fiscal 2021 with lease terms of one year to 16 years.

[0001571996-19-000039:notes:120]
[same as prior period, unchanged from 0001571996-19-000025:notes:120]

[0001571996-19-000039:notes:121]
Prior to the adoption of the new lease standard, the Company had the following future minimum lease payments under non-cancelable leases:

[0001571996-19-000039:notes:122]
|  | February 1, 2019 |
| Fiscal Years | (in millions) |
| Fiscal 2020 | $ | 371 |  |
| Fiscal 2021 | 314 |  |
| Fiscal 2022 | 240 |  |
| Fiscal 2023 | 175 |  |
| Fiscal 2024 | 113 |  |
| Thereafter | 643 |  |
| Total | $ | 1,856 |  |


## us-gaap:DebtDisclosureTextBlock

[0001571996-19-000039:notes:123]
NOTE 6 — DEBT

[0001571996-19-000039:notes:124]
During the six months ended August 2, 2019, the Company repaid the remaining principal amount of approximately $1,277 million of its Term Loan A-2 Facility described below under “Refinancing Transactions,” $620 million principal amount of its Term Loan A-4 Facility, $600 million principal amount of  its 5.875% senior notes due June 2019 upon maturity, and approximately $91 million of principal amortization under its term loan facilities.  Additionally, during the six months ended August 2, 2019, the Company issued an additional $0.7 billion, net, in DFS debt to support the expansion of its financing receivables portfolio.

[0001571996-19-000039:notes:125]
Refinancing Transactions

[0001571996-19-000039:notes:126]
On March 7, 2019, the Company amended the Margin Loan Agreement to increase the aggregate principal amount of borrowings under the Margin Loan Facility by $650 million.

[0001571996-19-000039:notes:127]
On March 13, 2019, the Company entered into an amendment to the credit agreement for the Senior Secured Credit Facilities to obtain a new senior secured Term Loan A-6 Facility in order to refinance the $5 billion aggregate principal amount of debt incurred in connection with the Class V transaction described in Note 14 of the Notes to the Condensed Consolidated Financial Statements.  The Term Loan A-6 Facility aggregate principal amount of $3,634 million matures on March 13, 2024, of which $2,839 million aggregate principal amount represents the amounts outstanding under the Term Loan A-2 Facility that rolled-over into the new facility.  Immediately after the rollover, an aggregate principal amount of $1,277 million remained outstanding under the Term Loan A-2 Facility.  The Term Loan A-6 Facility amortizes quarterly and bears interest at the London Interbank Offered Rate (“LIBOR”) plus an applicable margin ranging from 1.25% to 2.00% or a base rate plus an applicable margin of 0.25% to 1.00%.

[0001571996-19-000039:notes:128]
On March 20, 2019, Dell International L.L.C. and EMC Corporation, both which are wholly-owned subsidiaries of Dell Technologies Inc., completed a private offering of multiple series of First Lien Notes in an aggregate principal amount of $4.5 billion.  The principal amount, interest rate, and maturity of each series of such First Lien Notes were $1,000 million of 4.00% First Lien Notes due July 15, 2024, $1,750 million of 4.90% First Lien Notes due October 1, 2026, and $1,750 million of 5.30% First Lien Notes due October 1, 2029.

[0001571996-19-000039:notes:129]
A majority of the proceeds from the First Lien Notes issued on March 20, 2019 was used to repay all of the outstanding $3,750 million First Lien Notes due June 2019.  In addition, proceeds of approximately $800 million of borrowings under the new Term Loan A-6 Facility, the proceeds of the $650 million increase in the Margin Loan Facility, and a portion of the proceeds from the 2019 First Lien Notes were used to repay all of the Company’s outstanding amounts under the Term Loan A-5 Facility due December 2019.  During the three months ended May 3, 2019, the remaining proceeds available from the 2019 First Lien Notes were used to repay $550 million of outstanding amounts under the Term Loan A-2 Facility and to pay related premiums, accrued interest, fees, and expenses.  The Term Loan A-2 Facility was subsequently paid off as of August 2, 2019.

[0001571996-19-000039:notes:130]
The refinancing and amendments were evaluated in accordance with FASB ASC 470, “Debt-Modifications and Extinguishments.”  The amendment to the Margin Loan Agreement and the term debt refinancing were accounted for as modifications for all existing lenders and as new issuances for new lenders.  The First Lien Notes issued on March 20, 2019 were accounted for as new issuances for all lenders, and repayment of the Company’s outstanding amounts under the Term Loan A-5 Facility was accounted for as an extinguishment.  During the three months ended May 3, 2019, the Company capitalized $74.5 million in new fees paid to creditors as a result of the modifications and new issuances.  In addition, the Company recognized expenses of $32.3 million in unamortized costs and $7.1 million in new third-party costs during the three months ended May 3, 2019.

[0001571996-19-000039:notes:131]
Secured Debt

[0001571996-19-000039:notes:132]
Senior Secured Credit Facilities — The Company has entered into a credit agreement that provides for senior secured credit facilities (the “Senior Secured Credit Facilities”) comprising (a) term loan facilities and (b) a senior secured Revolving Credit Facility, which includes capacity for up to $0.5 billion of letters of credit and for borrowings of up to $0.4 billion under swing-line loans.

[0001571996-19-000039:notes:133]
As of August 2, 2019, available borrowings under the Revolving Credit Facility totaled $4.5 billion.  The Senior Secured Credit Facilities provide that the borrowers have the right at any time, subject to customary conditions, to request incremental term loans or incremental revolving commitments.

[0001571996-19-000039:notes:134]
Borrowings under the Senior Secured Credit Facilities bear interest at a rate per annum equal to an applicable margin, plus, at the borrowers’ option, either (a) a base rate, which, under the Term Loan B Facility, is subject to an interest rate floor of 1.75% per annum, and under all other borrowings is subject to an interest rate floor of 0% per annum, or (b) LIBOR, which, under the Term Loan B Facility, is subject to an interest rate floor of 0.75% per annum, and under all other borrowings is subject to an interest rate floor of 0% per annum.  Interest is payable, in the case of loans bearing interest based on LIBOR, at the end of each interest period (but at least every three months), in arrears and, in the case of loans bearing interest based on the base rate, quarterly in arrears.

[0001571996-19-000039:notes:135]
The Term Loan B Facility amortizes in equal quarterly installments in aggregate annual amounts equal to 1% of the original principal amount.  The Term Loan A-4 Facility amortizes in equal quarterly installments in aggregate annual amounts equal to 5% of the original principal amount in each of the first four years after the facility closing date of December 20, 2018, and 80% of the original principal amount in the fifth year after December 20, 2018.  The Term Loan A-6 Facility amortizes in equal quarterly installments in aggregate annual amounts equal to 5% of the original principal amount in each of the first four years after the facility closing date of March 13, 2019, and 80% of the original principal amount in the fifth year after March 13, 2019.  The Revolving Credit Facility has no amortization.

[0001571996-19-000039:notes:136]
The borrowers may voluntarily repay outstanding loans under the term loan facilities and the Revolving Credit Facility at any time without premium or penalty, other than customary “breakage” costs.

[0001571996-19-000039:notes:137]
All obligations of the borrowers under the Senior Secured Credit Facilities and certain swap agreements, cash management arrangements, and certain letters of credit provided by any lender or agent party to the Senior Secured Credit Facilities or any of its affiliates and certain other persons are secured by (a) a first-priority security interest in certain tangible and intangible assets of the borrowers and the guarantors and (b) a first-priority pledge of 100% of the capital stock of the borrowers, Dell Inc., a wholly‑owned subsidiary of the Company (“Dell”), and each wholly-owned material restricted subsidiary of the borrowers and the guarantors, in each case subject to certain thresholds, exceptions, and permitted liens.

[0001571996-19-000039:notes:138]
First Lien Notes — The senior secured notes (collectively, the “First Lien Notes”) were issued on June 1, 2016 and March 20, 2019 in an aggregate principal amount of $20.0 billion and $4.5 billion, respectively.  As stated above, the Company used a portion of the $4.5 billion proceeds to repay all of the outstanding $3,750 million First Lien Notes due June 2019.  Interest on these borrowings is payable semiannually.  The First Lien Notes are secured on a pari passu basis with the Senior Secured Credit Facilities, on a first-priority basis by substantially all of the tangible and intangible assets of the issuers and guarantors that secure obligations under the Senior Secured Credit Facilities, including pledges of all capital stock of the issuers, Dell, and certain wholly-owned material subsidiaries of the issuers and the guarantors, subject to certain exceptions.

[0001571996-19-000039:notes:139]
The Company has agreed to use commercially reasonable efforts to register with the SEC notes having terms substantially identical to the terms of the First Lien Notes as part of an offer to exchange such registered notes for the First Lien Notes.  The Company will be obligated to pay additional interest on the First Lien Notes if it fails to consummate such an exchange offer within five years after the closing date of the EMC merger transaction, in the case of the First Lien Notes issued on June 1, 2016, and within five years after their issue date, in the case of the First Lien Notes issued on March 20, 2019.

[0001571996-19-000039:notes:140]
.

[0001571996-19-000039:notes:141]
China Revolving Credit Facility — During the three months ended May 3, 2019, the Company renewed its credit agreement (the “China Revolving Credit Facility”) with a bank lender for a secured revolving loan facility in an aggregate principal amount not to exceed $500 million at an interest rate of LIBOR plus 0.6% per annum.  The facility will expire on February 26, 2020.  As of August 2, 2019, there were no outstanding borrowings under the China Revolving Credit Facility.

[0001571996-19-000039:notes:142]
Unsecured Debt

[0001571996-19-000039:notes:143]
Unsecured Notes and Debentures — The Company has outstanding unsecured notes and debentures (collectively, the “Unsecured Notes and Debentures”) that were issued by Dell prior to the acquisition of Dell by Dell Technologies Inc. in the going-private transaction that closed in October 2013.  Interest on these borrowings is payable semiannually.

[0001571996-19-000039:notes:144]
Senior Notes — The senior unsecured notes (collectively, the “Senior Notes”) were issued on June 22, 2016 in an aggregate principal amount of $3.25 billion.  Interest on these borrowings is payable semiannually.

[0001571996-19-000039:notes:145]
EMC Notes — On September 7, 2016, EMC had outstanding $2.5 billion aggregate principal amount of its 1.875% Notes due June 2018, which the Company fully repaid during the three months ended August 3, 2018, $2.0 billion aggregate principal amount of its 2.650% Notes due June 2020, and $1.0 billion aggregate principal amount of its 3.375% Notes due June 2023 (collectively, the “EMC Notes”).  Interest on these borrowings is payable semiannually.

[0001571996-19-000039:notes:146]
VMware Notes — On August 21, 2017, VMware, Inc. completed a public offering of unsecured senior notes in the aggregate amount of $4.0 billion, consisting of outstanding principal due on the following dates: $1.25 billion due August 21, 2020, $1.5 billion due August 21, 2022, and $1.25 billion due August 21, 2027 (collectively, the “VMware Notes”).  The VMware Notes bear interest, payable semiannually, at annual rates of 2.30%, 2.95%, and 3.90%, respectively.  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.

[0001571996-19-000039:notes:147]
VMware Revolving Credit Facility — On September 12, 2017, VMware, Inc. entered into an unsecured credit agreement, establishing a revolving credit facility (the “VMware Revolving Credit Facility”) with a syndicate of lenders that provides the company with a borrowing capacity of up to $1.0 billion which may be used for VMware, Inc. general corporate purposes.  Commitments under the VMware Revolving Credit Facility are available for a period of five years, which may be extended, subject to the satisfaction of certain conditions, by up to two one year periods.  The credit agreement contains certain representations, warranties, and covenants.  Commitment fees, interest rates, and other terms of borrowing under the VMware Revolving Credit Facility may vary based on VMware, Inc.’s external credit ratings.  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.  As of August 2, 2019, there were no outstanding borrowings under the VMware Revolving Credit Facility.

[0001571996-19-000039:notes:148]
See Note 4 and Note 7 of the Notes to the Condensed Consolidated Financial Statements, respectively, for discussion of DFS debt and the interest rate swap agreements that hedge a portion of that debt.

[0001571996-19-000039:notes:149]
Other

[0001571996-19-000039:notes:150]
Margin Loan Facility — On April 12, 2017, the Company entered into the Margin Loan Facility in an aggregate principal amount of $2.0 billion.  In connection with the Class V transaction, on December 20, 2018, the Company amended the Margin Loan Facility to increase the aggregate principal amount to $3.35 billion.  In connection with obtaining the Term Loan A-6 Facility, the Company increased the aggregate principal amount of the facility to $4.0 billion.  VMW Holdco LLC, a wholly-owned subsidiary of EMC, is the borrower under the Margin Loan Facility, which is secured by 60 million shares of Class B common stock of VMware, Inc. and 20 million shares of Class A common stock of VMware, Inc.  Loans under the Margin Loan Facility bear interest at a rate per annum payable, at the borrower’s option, either at (a) a base rate plus 1.25% per annum or (b) a LIBOR-based rate plus 2.25% per annum.  Interest under the Margin Loan Facility is payable quarterly.

[0001571996-19-000039:notes:151]
The Margin Loan Facility will mature in April 2022.  The borrower may voluntarily repay outstanding loans under the Margin Loan Facility at any time without premium or penalty, other than customary “breakage” costs, subject to certain minimum threshold amounts for prepayment.

[0001571996-19-000039:notes:152]
Pivotal Revolving Credit Facility — On September 7, 2017, Pivotal entered into a credit agreement (the “Pivotal Revolving Credit Facility”) that provides for a senior secured revolving loan facility in an aggregate principal amount not to exceed $100 million.  The credit facility contains customary representations, warranties, and covenants, including financial covenants.  The credit agreement will expire on September 8, 2020, unless it is terminated earlier.  None of the net proceeds of borrowings under the facility will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of Pivotal and Pivotal’s subsidiaries.  As of August 2, 2019, there were no outstanding borrowings under the Pivotal Revolving Credit Facility.

[0001571996-19-000039:notes:153]
Aggregate Future Maturities

[0001571996-19-000039:notes:154]
The following table presents the aggregate future maturities of the Company’s debt as of August 2, 2019 for the periods indicated:

[0001571996-19-000039:notes:155]
|  | Maturities by Fiscal Year |
|  | 2020 (remaining six months) |  | 2021 |  | 2022 |  | 2023 |  | 2024 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Secured Credit Facilities and First Lien Notes | $ | 116 |  |  | $ | 174 |  |  | $ | 4,732 |  |  | $ | 290 |  |  | $ | 11,722 |  |  | $ | 13,226 |  |  | $ | 30,260 |  |
| Unsecured Notes and Debentures | — |  |  | — |  |  | 400 |  |  | — |  |  | — |  |  | 952 |  |  | 1,352 |  |
| Senior Notes and EMC Notes | — |  |  | 2,000 |  |  | 1,625 |  |  | — |  |  | 1,000 |  |  | 1,625 |  |  | 6,250 |  |
| VMware Notes | — |  |  | 1,250 |  |  | — |  |  | 1,500 |  |  | — |  |  | 1,250 |  |  | 4,000 |  |
| DFS Debt | 2,140 |  |  | 3,051 |  |  | 980 |  |  | 438 |  |  | 36 |  |  | — |  |  | 6,645 |  |
| Margin Loan Facility | — |  |  | — |  |  | — |  |  | 4,000 |  |  | — |  |  | — |  |  | 4,000 |  |
| Other | 13 |  |  | 18 |  |  | 7 |  |  | 8 |  |  | 7 |  |  | 32 |  |  | 85 |  |
| Total maturities, principal amount | 2,269 |  |  | 6,493 |  |  | 7,744 |  |  | 6,236 |  |  | 12,765 |  |  | 17,085 |  |  | 52,592 |  |
| Associated carrying value adjustments | — |  |  | (5 | ) |  | (78 | ) |  | (28 | ) |  | (142 | ) |  | (417 | ) |  | (670 | ) |
| Total maturities, carrying value amount | $ | 2,269 |  |  | $ | 6,488 |  |  | $ | 7,666 |  |  | $ | 6,208 |  |  | $ | 12,623 |  |  | $ | 16,668 |  |  | $ | 51,922 |  |

[0001571996-19-000039:notes:156]
Covenants and Unrestricted Net Assets — The credit agreement for the Senior Secured Credit Facilities contains customary negative covenants that generally limit the ability of Denali Intermediate Inc., a wholly-owned subsidiary of Dell Technologies (“Dell Intermediate”), Dell, and Dell’s and Denali Intermediate’s other restricted subsidiaries to incur debt, create liens, make fundamental changes, enter into asset sales, make certain investments, pay dividends or distribute or redeem certain equity interests, prepay or redeem certain debt, and enter into certain transactions with affiliates.  The indenture governing the Senior Notes contains customary negative covenants that generally limit the ability of Denali Intermediate, Dell, and Dell’s and Denali Intermediate’s other restricted subsidiaries to incur additional debt or issue certain preferred shares, pay dividends on or make other distributions in respect of capital stock or make other restricted payments, make certain investments, sell or transfer certain assets, create liens on certain assets to secure debt, consolidate, merge, sell, or otherwise dispose of all or substantially all assets, enter into certain transactions with affiliates, and designate subsidiaries as unrestricted subsidiaries.  The negative covenants under such credit agreements and indenture are subject to certain exceptions, qualifications, and “baskets.”  The indentures governing the First Lien Notes, the Unsecured Notes and Debentures, and the EMC Notes variously impose limitations, subject to specified exceptions, on creating certain liens, entering into sale and lease-back transactions, and entering into certain asset sales.  The foregoing credit agreements and indentures contain customary events of default, including failure to make required payments, failure to comply with covenants, and the occurrence of certain events of bankruptcy and insolvency.

[0001571996-19-000039:notes:157]
As of August 2, 2019, the Company had certain consolidated subsidiaries that were designated as unrestricted subsidiaries for all purposes of the applicable credit agreements and the indentures governing the First Lien Notes and the Senior Notes.  Substantially all of the net assets of the Company’s consolidated subsidiaries were restricted, with the exception of the Company’s unrestricted subsidiaries, primarily VMware, Inc., Pivotal, Secureworks, and their respective subsidiaries, as of August 2, 2019.

[0001571996-19-000039:notes:158]
The Term Loan A-4 Facility, the Term Loan A-6 Facility, and the Revolving Credit Facility are subject to a first lien leverage ratio covenant that is tested at the end of each fiscal quarter of Dell with respect to Dell’s preceding four fiscal quarters.  The Company was in compliance with all financial covenants as of August 2, 2019.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001571996-19-000039:notes:159]
[same as prior period, unchanged from 0001571996-19-000025:notes:162]

[0001571996-19-000039:notes:160]
[same as prior period, unchanged from 0001571996-19-000025:notes:163]

[0001571996-19-000039:notes:161]
[same as prior period, unchanged from 0001571996-19-000025:notes:164]

[0001571996-19-000039:notes:162]
[same as prior period, unchanged from 0001571996-19-000025:notes:165]

[0001571996-19-000039:notes:163]
[same as prior period, unchanged from 0001571996-19-000025:notes:166]

[0001571996-19-000039:notes:164]
During the six months ended August 2, 2019 and August 3, 2018, the Company did not discontinue any cash flow hedges related to foreign exchange contracts that had a material impact on the Company’s results of operations due to the probability that the forecasted cash flows would not occur.

[0001571996-19-000039:notes:165]
[same as prior period, unchanged from 0001571996-19-000025:notes:168]

[0001571996-19-000039:notes:166]
In connection with expanded offerings of DFS in Europe, forward contracts are used to hedge financing receivables denominated in foreign currencies other than Euro.  These contracts are not designated for hedge accounting and most expire within three years or less.

[0001571996-19-000039:notes:167]
[same as prior period, unchanged from 0001571996-19-000025:notes:170]

[0001571996-19-000039:notes:168]
[same as prior period, unchanged from 0001571996-19-000025:notes:171]

[0001571996-19-000039:notes:169]
[same as prior period, unchanged from 0001571996-19-000025:notes:172]

[0001571996-19-000039:notes:170]
[same as prior period, unchanged from 0001571996-19-000025:notes:173]

[0001571996-19-000039:notes:171]
[same as prior period, unchanged from 0001571996-19-000025:notes:174]

[0001571996-19-000039:notes:172]
[same as prior period, unchanged from 0001571996-19-000025:notes:175]

[0001571996-19-000039:notes:173]
|  | August 2, 2019 |  | February 1, 2019 |
|  | (in millions) |
| Foreign exchange contracts: |  |  |  |  |  |
| Designated as cash flow hedging instruments | $ | 8,017 |  |  | $ | 7,573 |  |
| Non-designated as hedging instruments | 6,345 |  |  | 6,129 |  |
| Total | $ | 14,362 |  |  | $ | 13,702 |  |
| Interest rate contracts: |  |  |  |
| Non-designated as hedging instruments | $ | 3,121 |  |  | $ | 2,674 |  |

[0001571996-19-000039:notes:174]
[same as prior period, unchanged from 0001571996-19-000025:notes:177]

[0001571996-19-000039:notes:175]
| Derivatives in Cash Flow Hedging Relationships |  | Gain (Loss) Recognized in Accumulated OCI, Net of Tax, on Derivatives |  | Location of Gain (Loss) Reclassified from Accumulated OCI into Income |  | Gain (Loss) Reclassified from Accumulated OCI into Income |
|  |  | (in millions) |  |  |  | (in millions) |
| For the three months ended August 2, 2019 |
|  |  |  |  |  | Total net revenue |  | $ | 68 |  |
| Foreign exchange contracts |  | $ | 105 |  |  | Total cost of net revenue |  | — |  |
| Interest rate contracts |  | — |  |  | Interest and other, net |  | — |  |
| Total |  | $ | 105 |  |  |  |  | $ | 68 |  |
| For the three months ended August 3, 2018 |
|  |  |  |  |  | Total net revenue |  | $ | 77 |  |
| Foreign exchange contracts |  | $ | 120 |  |  | Total cost of net revenue |  | — |  |
| Interest rate contracts |  | — |  |  | Interest and other, net |  | — |  |
| Total |  | $ | 120 |  |  |  |  | $ | 77 |  |
| For the six months ended August 2, 2019 |
|  |  |  |  |  | Total net revenue |  | $ | 126 |  |
| Foreign exchange contracts |  | $ | 257 |  |  | Total cost of net revenue |  | — |  |
| Interest rate contracts |  | — |  |  | Interest and other, net |  | — |  |
| Total |  | $ | 257 |  |  |  |  | $ | 126 |  |
| For the six months ended August 3, 2018 |
|  |  |  |  |  | Total net revenue |  | $ | 46 |  |
| Foreign exchange contracts |  | $ | 241 |  |  | Total cost of net revenue |  | — |  |
| Interest rate contracts |  | — |  |  | Interest and other, net |  | — |  |
| Total |  | $ | 241 |  |  |  |  | $ | 46 |  |

[0001571996-19-000039:notes:176]
[same as prior period, unchanged from 0001571996-19-000025:notes:179]

[0001571996-19-000039:notes:177]
|  |  | Three Months Ended |  | Six Months Ended |  |  |
|  |  | August 2, 2019 |  | August 3, 2018 |  | August 2, 2019 |  | August 3, 2018 |  | Location of Gain (Loss) Recognized |
|  |  | (in millions) |  |  |
| Gain (Loss) Recognized: |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | 7 |  |  | $ | 75 |  |  | $ | (59 | ) |  | $ | 32 |  |  | Interest and other, net |
| Interest rate contracts |  | (15 | ) |  | (1 | ) |  | (22 | ) |  | 1 |  |  | Interest and other, net |
| Total |  | $ | (8 | ) |  | $ | 74 |  |  | $ | (81 | ) |  | $ | 33 |  |  |  |

[0001571996-19-000039:notes:178]
[same as prior period, unchanged from 0001571996-19-000025:notes:181]

[0001571996-19-000039:notes:179]
[same as prior period, unchanged from 0001571996-19-000025:notes:182]

[0001571996-19-000039:notes:180]
|  | August 2, 2019 |
|  | Other CurrentAssets |  | Other Non-Current Assets |  | Other CurrentLiabilities |  | Other Non-CurrentLiabilities |  | TotalFair Value |
|  |  |  | (in millions) |  |  |
| Derivatives designated as hedging instruments: |
| Foreign exchange contracts in an asset position | $ | 211 |  |  | $ | — |  |  | $ | 3 |  |  | $ | — |  |  | $ | 214 |  |
| Foreign exchange contracts in a liability position | (10 | ) |  | — |  |  | (1 | ) |  | — |  |  | (11 | ) |
| Net asset (liability) | 201 |  |  | — |  |  | 2 |  |  | — |  |  | 203 |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts in an asset position | 278 |  |  | 1 |  |  | 8 |  |  | — |  |  | 287 |  |
| Foreign exchange contracts in a liability position | (238 | ) |  | — |  |  | (23 | ) |  | (2 | ) |  | (263 | ) |
| Interest rate contracts in an asset position | — |  |  | 9 |  |  | — |  |  | — |  |  | 9 |  |
| Interest rate contracts in a liability position | — |  |  | — |  |  | — |  |  | (21 | ) |  | (21 | ) |
| Net asset (liability) | 40 |  |  | 10 |  |  | (15 | ) |  | (23 | ) |  | 12 |  |
| Total derivatives at fair value | $ | 241 |  |  | $ | 10 |  |  | $ | (13 | ) |  | $ | (23 | ) |  | $ | 215 |  |
|  | February 1, 2019 |
|  | Other CurrentAssets |  | Other Non-Current Assets |  | Other CurrentLiabilities |  | Other Non-CurrentLiabilities |  | TotalFair Value |
|  |  |  | (in millions) |  |  |
| Derivatives designated as hedging instruments: |
| Foreign exchange contracts in an asset position | $ | 45 |  |  | $ | — |  |  | $ | 29 |  |  | $ | — |  |  | $ | 74 |  |
| Foreign exchange contracts in a liability position | (19 | ) |  | — |  |  | (20 | ) |  | — |  |  | (39 | ) |
| Net asset (liability) | 26 |  |  | — |  |  | 9 |  |  | — |  |  | 35 |  |
| Derivatives not designated as hedging instruments: |
| Foreign exchange contracts in an asset position | 178 |  |  | — |  |  | 57 |  |  | — |  |  | 235 |  |
| Foreign exchange contracts in a liability position | (110 | ) |  | — |  |  | (115 | ) |  | (2 | ) |  | (227 | ) |
| Interest rate contracts in an asset position | — |  |  | 3 |  |  | — |  |  | — |  |  | 3 |  |
| Interest rate contracts in a liability position | — |  |  | — |  |  | — |  |  | (9 | ) |  | (9 | ) |
| Net asset (liability) | 68 |  |  | 3 |  |  | (58 | ) |  | (11 | ) |  | 2 |  |
| Total derivatives at fair value | $ | 94 |  |  | $ | 3 |  |  | $ | (49 | ) |  | $ | (11 | ) |  | $ | 37 |  |

[0001571996-19-000039:notes:181]
[same as prior period, unchanged from 0001571996-19-000025:notes:184]

[0001571996-19-000039:notes:182]
|  | August 2, 2019 |
|  | Gross Amounts of Recognized Assets/ (Liabilities) |  | Gross Amounts Offset in the Statement of Financial Position |  | Net Amounts of Assets/ (Liabilities) Presented in the Statement of Financial Position |  | Gross Amounts not Offset in the Statement of Financial Position |  | Net Amount |
|  | Financial Instruments |  | Cash Collateral Received or Pledged |  |
|  | (in millions) |
| Derivative instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Financial assets | $ | 510 |  |  | $ | (259 | ) |  | $ | 251 |  |  | $ | — |  |  | $ | — |  |  | $ | 251 |  |
| Financial liabilities | (295 | ) |  | 259 |  |  | (36 | ) |  | — |  |  | 5 |  |  | (31 | ) |
| Total derivative instruments | $ | 215 |  |  | $ | — |  |  | $ | 215 |  |  | $ | — |  |  | $ | 5 |  |  | $ | 220 |  |
|  | February 1, 2019 |
|  | Gross Amounts of Recognized Assets/ (Liabilities) |  | Gross Amounts Offset in the Statement of Financial Position |  | Net Amounts of Assets/ (Liabilities) Presented in the Statement of Financial Position |  | Gross Amounts not Offset in the Statement of Financial Position |  | Net Amount |
|  | Financial Instruments |  | Cash Collateral Received or Pledged |  |
|  | (in millions) |
| Derivative instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Financial assets | $ | 312 |  |  | $ | (215 | ) |  | $ | 97 |  |  | $ | — |  |  | $ | — |  |  | $ | 97 |  |
| Financial liabilities | (275 | ) |  | 215 |  |  | (60 | ) |  | — |  |  | 4 |  |  | (56 | ) |
| Total derivative instruments | $ | 37 |  |  | $ | — |  |  | $ | 37 |  |  | $ | — |  |  | $ | 4 |  |  | $ | 41 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001571996-19-000039:notes:183]
[same as prior period, unchanged from 0001571996-19-000025:notes:186]

[0001571996-19-000039:notes:184]
[same as prior period, unchanged from 0001571996-19-000025:notes:187]

[0001571996-19-000039:notes:185]
[same as prior period, unchanged from 0001571996-19-000025:notes:188]

[0001571996-19-000039:notes:186]
|  | Infrastructure Solutions Group |  | Client Solutions Group |  | VMware |  | Other Businesses (a) |  | Total |
|  | (in millions) |
| Balance as of February 1, 2019 | $ | 15,199 |  |  | $ | 4,237 |  |  | $ | 16,419 |  |  | $ | 4,234 |  |  | $ | 40,089 |  |
| Goodwill acquired (b) | — |  |  | — |  |  | 272 |  |  | — |  |  | 272 |  |
| Impact of foreign currency translation | (123 | ) |  | — |  |  | — |  |  | (33 | ) |  | (156 | ) |
| Goodwill impaired (c) | — |  |  | — |  |  | — |  |  | (207 | ) |  | (207 | ) |
| Balance as of August 2, 2019 | $ | 15,076 |  |  | $ | 4,237 |  |  | $ | 16,691 |  |  | $ | 3,994 |  |  | $ | 39,998 |  |

[0001571996-19-000039:notes:187]
[same as prior period, unchanged from 0001571996-19-000025:notes:190]

[0001571996-19-000039:notes:188]
(b)  VMware, Inc. acquisitions, as discussed below.

[0001571996-19-000039:notes:189]
(c)  The Company recognized a goodwill impairment charge related to Virtustream, as discussed below.

[0001571996-19-000039:notes:190]
VMware, Inc. Acquisitions — During the three months ended August 2, 2019, VMware, Inc. completed the acquisition of Avi Networks, Inc., a provider of multi-cloud application delivery services.  The total purchase price was $326 million, net of cash acquired of $9 million.  The purchase price primarily included $94 million of identifiable intangible assets and $228 million of goodwill that is not expected to be deductible for tax purposes.

[0001571996-19-000039:notes:191]
During the three months ended May 3, 2019, VMware, Inc. completed the acquisition of AetherPal, Inc., a provider of remote support solutions.  The total purchase price was $45 million, which primarily included $12 million of identifiable intangible assets and $33 million of goodwill that is not expected to be deductible for tax purposes.

[0001571996-19-000039:notes:192]
For each of the acquisitions, the initial allocation of the purchase price was based on preliminary valuations and assumptions and is subject to change within the measurement period.  VMware, Inc. expects to finalize the allocation of the purchase price for each of the acquisitions as soon as practicable and not later than one year from the respective acquisition dates.

[0001571996-19-000039:notes:193]
See Note 20 of the Notes to the Condensed Consolidated Financial Statements for information regarding acquisition agreements entered into by VMware, Inc. subsequent to August 2, 2019.

[0001571996-19-000039:notes:194]
Goodwill Impairment Tests — Goodwill and indefinite-lived intangible assets are tested for impairment annually during the third fiscal quarter and whenever events or circumstances may indicate that an impairment has occurred.  Based on the results of the annual impairment test performed for the fiscal year ended February 1, 2019, which was a quantitative test for all goodwill reporting units, the fair values of each of the reporting units, except for the Virtustream reporting unit, exceeded their carrying values.  Virtustream’s results, which are reported within the Company’s Other Businesses, do not meet the requirements for a reportable segment and are not material to the Company’s overall results.  See Note 18 of the Notes to the Condensed Consolidated Financial Statements for additional segment information.

[0001571996-19-000039:notes:195]
Virtustream delivers an application management cloud platform for enterprise mission-critical workloads in the Infrastructure-as-a-Service market, and had approximately $0.4 billion in goodwill that was derived from the EMC merger transaction during the fiscal year ended February 3, 2017.

[0001571996-19-000039:notes:196]
During fiscal year ended February 1, 2019, Virtustream forecasts were revised downward due to a resetting of the longer-term business model that is focused on a streamlined product portfolio.  Based on the results of the annual impairment test performed for the fiscal year ended February 1, 2019, it was determined that the carrying value of the Virtustream reporting unit exceeded its fair value, and, as such, a goodwill impairment charge of approximately $190 million was recognized during the three months ended November 2, 2018 to write the goodwill down to a fair value of approximately $200 million.

[0001571996-19-000039:notes:197]
During the three months ended August 2, 2019, strategic alternatives were evaluated for Virtustream that provided new fair value indicators and resulted in the need to perform an impairment assessment of both long-lived assets and goodwill.  Based on the results of the impairment assessment, it was determined that the fair value of the asset group was less than its carrying value.  A gross impairment charge of $619 million and $524 million net of tax benefits, was recognized related to Virtustream intangible assets, property, plant, and equipment, and remaining goodwill during the three months ended August 2, 2019.  The gross impairment charge related to Virtustream was classified in selling, general, and administrative in the Condensed Consolidated Statements of Income (Loss).  Additionally, required deferred tax adjustments associated with the intangible assets and property, plant, and equipment resulted in the recognition of an income tax benefit of $95 million in the Condensed Consolidated Statements of Income (Loss).

[0001571996-19-000039:notes:198]
The impairment is reflected in the Condensed Consolidated Statements of Financial Position as of August 2, 2019 as a reduction in Goodwill of $207 million, a reduction in Intangible assets, net of $266 million, a reduction in Property, plant, and equipment, net of $146 million, and a reduction in Other non-current liabilities of $95 million related to deferred income taxes.  There were no remaining balances of Virtustream goodwill, intangible assets, or property, plant, and equipment as of August 2, 2019 following the impairment charge recognized during the three months ended August 2, 2019 due to the combined effect of that impairment charge and the Virtustream goodwill impairment charge recognized during the three months ended November 2, 2018.

[0001571996-19-000039:notes:199]
In conjunction with the annual impairment test performed for the fiscal year ended February 1, 2019, it was determined that the excess of fair value over carrying amount was less than 20% for the RSA Security reporting unit, which had an excess of fair value over carrying amount of 11% as of November 2, 2018.  Management continues to monitor the RSA Security goodwill reporting unit and consider potential impacts to the impairment assessment.

[0001571996-19-000039:notes:200]
Following the closing of the Class V transaction described in Note 14 of the Notes to the Condensed Consolidated Financial Statements, the Company performed an interim impairment analysis during the three months ended February 1, 2019 given the availability of market data for the fair value of the Class C Common Stock.  Other than the impairment indicators disclosed during the Company’s annual goodwill impairment test during the three months ended November 2, 2018, there were no impairment indicators resulting from the interim impairment analysis.  No events or circumstances transpired subsequent to this interim impairment analysis test that would indicate a potential impairment of goodwill as of August 2, 2019, other than the impairment charge related to Virtustream as discussed above.

[0001571996-19-000039:notes:201]
[same as prior period, unchanged from 0001571996-19-000025:notes:197]

[0001571996-19-000039:notes:202]
[same as prior period, unchanged from 0001571996-19-000025:notes:198]

[0001571996-19-000039:notes:203]
[same as prior period, unchanged from 0001571996-19-000025:notes:199]

[0001571996-19-000039:notes:204]
|  | August 2, 2019 |  | February 1, 2019 |
|  | Gross |  | AccumulatedAmortization |  | Net |  | Gross |  | AccumulatedAmortization |  | Net |
|  | (in millions) |
| Customer relationships | $ | 22,712 |  |  | $ | (12,828 | ) |  | $ | 9,884 |  |  | $ | 22,750 |  |  | $ | (11,703 | ) |  | $ | 11,047 |  |
| Developed technology | 15,450 |  |  | (9,941 | ) |  | 5,509 |  |  | 15,701 |  |  | (9,036 | ) |  | 6,665 |  |
| Trade names | 1,282 |  |  | (711 | ) |  | 571 |  |  | 1,291 |  |  | (606 | ) |  | 685 |  |
| Leasehold assets (liabilities) | — |  |  | — |  |  | — |  |  | 128 |  |  | (10 | ) |  | 118 |  |
| Definite-lived intangible assets | 39,444 |  |  | (23,480 | ) |  | 15,964 |  |  | 39,870 |  |  | (21,355 | ) |  | 18,515 |  |
| Indefinite-lived trade names | 3,755 |  |  | — |  |  | 3,755 |  |  | 3,755 |  |  | — |  |  | 3,755 |  |
| Total intangible assets | $ | 43,199 |  |  | $ | (23,480 | ) |  | $ | 19,719 |  |  | $ | 43,625 |  |  | $ | (21,355 | ) |  | $ | 22,270 |  |

[0001571996-19-000039:notes:205]
Amortization expense related to definite-lived intangible assets was approximately $1.1 billion and $1.5 billion for the three months ended August 2, 2019 and August 3, 2018, respectively, and $2.3 billion and $3.0 billion for the six months ended August 2, 2019 and August 3, 2018, respectively.  During the three months ended August 2, 2019, an impairment charge related to Virtustream intangible assets, net was approximately $266 million, as discussed above.  There were no material impairment charges related to intangible assets during the three months ended August 3, 2018.  Due to the adoption of the new lease standard discussed in Note 1 and Note 2 of the Notes to the Condensed Consolidated Financial Statements, the Company derecognized all intangible leasehold assets and adjusted the carrying amount of the ROU assets by a corresponding amount as of February 2, 2019.

[0001571996-19-000039:notes:206]
The following table presents the estimated future annual pre-tax amortization expense of definite-lived intangible assets as of the date indicated:

[0001571996-19-000039:notes:207]
|  | August 2, 2019 |
| Fiscal Years | (in millions) |
| 2020 (remaining six months) | $ | 2,095 |  |
| 2021 | 3,325 |  |
| 2022 | 2,619 |  |
| 2023 | 1,743 |  |
| 2024 | 1,386 |  |
| Thereafter | 4,796 |  |
| Total | $ | 15,964 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001571996-19-000039:notes:208]
NOTE 9 — DEFERRED REVENUE

[0001571996-19-000039:notes:209]
Deferred Revenue — Deferred revenue is recorded for support and deployment services, software maintenance, professional services, training, and SaaS when the Company has a right to invoice or payments have been received for undelivered products or services where transfer of control has not occurred.  Revenue is recognized on these items when the revenue recognition criteria are met, generally resulting in ratable recognition over the contract term.  The Company also has deferred revenue related to undelivered hardware and professional services, consisting of installations and consulting engagements, which are recognized as the Company’s performance obligations under the contract are completed.

[0001571996-19-000039:notes:210]
The following table presents the changes in the Company’s deferred revenue for the periods indicated:

[0001571996-19-000039:notes:211]
|  | Three Months Ended |  | Six Months Ended |
|  | August 2, 2019 |  | August 3, 2018 |  | August 2, 2019 |  | August 3, 2018 |
|  | (in millions) |
| Deferred revenue: |  |  |  |  |  |  |  |
| Deferred revenue at beginning of period | $ | 24,178 |  |  | $ | 20,959 |  |  | $ | 24,010 |  |  | $ | 20,816 |  |
| Revenue deferrals for new contracts and changes in estimates for pre-existing contracts (a) (b) | 5,975 |  |  | 4,988 |  |  | 10,875 |  |  | 9,313 |  |
| Revenue recognized (b) | (4,805 | ) |  | (4,247 | ) |  | (9,537 | ) |  | (8,429 | ) |
| Deferred revenue at end of period | $ | 25,348 |  |  | $ | 21,700 |  |  | $ | 25,348 |  |  | $ | 21,700 |  |
| Short-term deferred revenue | $ | 13,568 |  |  | $ | 11,965 |  |  | $ | 13,568 |  |  | $ | 11,965 |  |
| Long-term deferred revenue | $ | 11,780 |  |  | $ | 9,735 |  |  | $ | 11,780 |  |  | $ | 9,735 |  |

[0001571996-19-000039:notes:212]
| (a) | Includes the impact of foreign currency exchange rate fluctuations. |

[0001571996-19-000039:notes:213]
| (b) | The Company conformed the presentation of certain deferred revenue rollforward activity for the three and six months ended August 3, 2018 to align current year presentation. The beginning and ending deferred revenue liability balances remain unchanged. |

[0001571996-19-000039:notes:214]
Remaining Performance Obligations — Remaining performance obligations represent the aggregate amount of the transaction price allocated to performance obligations not delivered, or partially undelivered, as of the end of the reporting period.

[0001571996-19-000039:notes:215]
Remaining performance obligations include deferred revenue plus unbilled amounts not yet recorded in deferred revenue.  The aggregate amount of the transaction price allocated to remaining performance obligations does not include amounts owed under cancelable contracts where there is no substantive termination penalty.

[0001571996-19-000039:notes:216]
The Company applied the practical expedient to exclude the value of remaining performance obligations for contracts for which revenue is recognized at the amount to which the Company has the right to invoice for services performed.  The Company also applied the practical expedient to not disclose the amount of transaction price allocated to remaining performance obligations for the periods prior to adoption of the new revenue standard.

[0001571996-19-000039:notes:217]
Remaining performance obligation estimates are subject to change and are affected by several factors, including terminations, changes in the scope of contracts, periodic revalidation, adjustments for revenue that have not materialized, and adjustments for currency.

[0001571996-19-000039:notes:218]
The value of the transaction price allocated to remaining performance obligations as of August 2, 2019 was approximately $33 billion.  The Company expects to recognize approximately 61% of remaining performance obligations as revenue in the next twelve months, and the remainder thereafter.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001571996-19-000039:notes:219]
Legal Matters

[0001571996-19-000039:notes:220]
The Company is involved in various claims, suits, assessments, investigations, and legal proceedings that arise from time to time in the ordinary course of its business, including those identified below, consisting of matters involving consumer, antitrust, tax, intellectual property, and other issues on a global basis.

[0001571996-19-000039:notes:221]
The Company accrues a liability when it believes that it is both probable that a liability has been incurred and that it can reasonably estimate the amount of the loss.  The Company reviews these accruals at least quarterly and adjusts them to reflect ongoing negotiations, settlements, rulings, advice of legal counsel, and other relevant information.  To the extent new information is obtained and the Company’s views on the probable outcomes of claims, suits, assessments, investigations, or legal proceedings change, changes in the Company’s accrued liabilities would be recorded in the period in which such a determination is made.  For some matters, the amount of liability is not probable or the amount cannot be reasonably estimated and therefore accruals have not been made.

[0001571996-19-000039:notes:222]
The following is a discussion of the Company’s significant legal matters and other proceedings:

[0001571996-19-000039:notes:223]
Securities Litigation — On May 21, 2014, a securities class action seeking compensatory damages was filed in the United States District Court for the Southern District of New York, captioned City of Pontiac General Employees’ Retirement System v. Dell Inc., et. al. (Case No. 1:14-cv-03644).  The action names as defendants Dell Inc. (“Dell”)

[0001571996-19-000039:notes:224]
and certain current and former executive officers, and alleges that Dell made false and misleading statements about Dell’s financial results and future prospects between February 21, 2012 and May 22, 2012, which resulted in artificially inflated stock prices.  The case was transferred to the United States District Court for the Western District of Texas under the same caption (Case No. 1:15-cv-00374), where the defendants filed a motion to dismiss.  On September 16, 2016, the Court denied the motion to dismiss.  On March 29, 2018, the Court granted the plaintiffs’ motion for class certification, and certified a class consisting of all purchasers of Dell common stock between February 22, 2012 and May 22, 2012.  Fact and expert discovery is now closed.  Dell filed a motion for summary judgment on February 18, 2019, which is pending before the Court.  The parties have been engaged in settlement discussions and have agreed to an immaterial settlement amount pending the Court’s preliminary approval in the next few months.

[0001571996-19-000039:notes:225]
Class Actions Related to the Class V Transaction — Four purported stockholders brought putative class action complaints arising out of the Class V transaction described in Note 14 of the Notes to the Condensed Consolidated Financial Statements.  The actions were captioned Hallandale Beach Police and Fire Retirement Plan v. Michael Dell et al. (Civil Action No. 2018-0816-JTL), Howard Karp v. Michael Dell et al. (Civil Action No. 2019-0032-JTL), Miramar Police Officers’ Retirement Plan v. Michael Dell et al. (Civil Action No. 2019-0049-JTL), and Steamfitters Local 449 Pension Plan v. Michael Dell et al. (Civil Action No. 2019-0115-JTL).  The four actions were consolidated into In Re Dell Class V Litigation (Consol. C.A. No. 2018-0816-JTL), which names as defendants the Company’s board of directors and certain stockholders of the Company, including Michael S. Dell.  The plaintiffs generally allege that the defendants breached their fiduciary duties to the former holders of Class V Common Stock in connection with the Class V transaction by allegedly causing the Company to enter into a transaction that favored the interests of the controlling stockholders at the expense of such former stockholders.  The plaintiffs filed an amended complaint on August 9, 2019 making substantially similar allegations as described above.  The defendants intend to file a motion to dismiss the action, which will be due on September 30, 2019.

[0001571996-19-000039:notes:226]
Copyright Levies — The Company is involved in various proceedings and negotiations regarding Dell’s obligation to collect and remit copyright levies in certain European Union (“EU”) countries.  The Company continues to collect levies in EU countries where it has determined that local laws require payment.  The Company, along with other companies and/or industry associations, also continues to oppose levy schemes that do not comply with EU law.  The Company does not currently anticipate that any of these matters will have a material adverse effect on its business, financial condition, results of operations, or cash flows.

[0001571996-19-000039:notes:227]
Other Litigation — The various legal proceedings in which Dell is involved include commercial and intellectual property litigation.  Dell does not currently anticipate that any of these matters will have a material adverse effect on its business, financial condition, results of operations, or cash flows.

[0001571996-19-000039:notes:228]
As of August 2, 2019, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for these or other proceedings or matters has been incurred.  However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company’s business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters.  Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company’s business, financial condition, results of operations, or cash flows will depend on a number of variables, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.

[0001571996-19-000039:notes:229]
Indemnifications

[0001571996-19-000039:notes:230]
In the ordinary course of business, the Company enters into contractual arrangements under which it may agree to indemnify the third party to such arrangements from any losses incurred relating to the services it performs on behalf of the Company or for losses arising from certain events as defined in the particular contract, such as litigation or claims relating to past performance.  Such indemnification obligations may not be subject to maximum loss clauses.  Historically, payments related to these indemnifications have not been material to the Company.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001571996-19-000039:notes:231]
[same as prior period, unchanged from 0001571996-19-000025:notes:228]

[0001571996-19-000039:notes:232]
For the three months ended August 2, 2019 and August 3, 2018, the Company’s effective income tax rates were 3912.6% and 1.5%, respectively, on pre-tax losses of $111 million and $468 million, respectively.  For the six months ended August 2, 2019 and August 3, 2018, the Company’s effective income tax rates were 1895.7% and 8.4%, respectively, on pre-tax losses of $254 million and $1.1 billion, respectively.  The changes in the Company’s effective tax rates are primarily driven by discrete tax items and a change in the Company’s jurisdictional mix of income.  During the three months ended May 3, 2019, the Company completed an intra-entity asset transfer of certain of its intellectual property to an Irish subsidiary, resulting in a discrete tax benefit of $405 million.  During the three months ended August 2, 2019, the Company’s VMware business unit completed a similar transaction, resulting in a discrete tax benefit of $4.5 billion.  The tax benefit for each intra-entity asset transfer was recorded as a deferred tax asset in the period of transaction and represents the book and tax basis difference on the transferred assets measured based on the applicable Irish statutory tax rate.  The tax deductions for amortization of the assets will be recognized in the future, and any amortization not deducted for tax purposes will be carried forward indefinitely under Irish Tax laws.  The Company expects to be able to realize the deferred tax assets resulting from these intra-company asset transfers.  For the three and six months ended August 2, 2019, the Company’s effective tax rates include $273 million discrete tax expense related to certain foreign tax credits associated with U.S. Tax Reform discussed below.  The Company’s effective tax rates for the three and six months ended August 2, 2019 also include $95 million of discrete tax benefits relating to Virtustream impairment charges discussed in Note 8 of the Notes to the Condensed Consolidated Financial Statements.  For the six months ended August 3, 2018, the Company’s effective tax rate included $154 million of discrete tax benefits resulting from the impact of its adoption of the new revenue recognition standard during the three months ended May 4, 2018.

[0001571996-19-000039:notes:233]
The Tax Cuts and Jobs Act of 2017 (“U.S. Tax Reform”) was signed into law on December 22, 2017.  Among other things, U.S. Tax Reform lowers the U.S. corporate income tax rate to 21% from 35%, establishes a modified territorial system requiring a mandatory deemed repatriation tax on undistributed earnings of foreign subsidiaries, requires a minimum tax on certain future earnings generated by foreign subsidiaries while providing for future tax-free repatriation of earnings through a 100% dividends-received deduction, and places limitations on the deductibility of net interest expense.  The Company anticipates that the U.S. Department of the Treasury and the Internal Revenue Service (“IRS”) will continue to issue regulatory guidance clarifying certain provisions of U.S. Tax Reform.  When additional guidance is issued, the Company will recognize the related tax impact in the fiscal quarter of such issuance.

[0001571996-19-000039:notes:234]
The differences between the estimated effective income tax rates and the U.S. federal statutory rate of 21% principally result from the Company’s geographical distribution of income and differences between the book and tax treatment of certain items.  In certain jurisdictions, the Company’s tax rate is significantly less than the applicable statutory rate as a result of tax holidays.  The majority of the Company’s foreign income that is subject to these tax holidays and lower tax rates is attributable to Singapore, China, and Malaysia.  A significant portion of these income tax benefits relates to a tax holiday that will be effective until January 31, 2029.  The Company’s other tax holidays will expire in whole or in part during fiscal years 2022 through 2030.  Many of these tax holidays and reduced tax rates may be extended when certain conditions are met or may be terminated early if certain conditions are not met.  As of August 2, 2019, the Company was not aware of any matters of non-compliance related to these tax holidays.

[0001571996-19-000039:notes:235]
The Company’s U.S. federal income tax returns for fiscal years 2007 through 2009 are currently under consideration by the Office of Appeals of the IRS.  The IRS issued a Revenue Agent’s Report (“RAR”) related to those years during the fiscal year ended February 3, 2017.  The IRS has proposed adjustments primarily relating to transfer pricing matters with which the Company disagrees and has been contesting through the IRS administrative appeals process.  Although this process has been progressing and the timing of any resolution remains uncertain, the Company anticipates reaching a settlement with the IRS before the end of Fiscal 2020.  In May 2017, the IRS commenced a federal income tax audit for fiscal years 2010 through 2014, for which the Company expects to receive a RAR in early 2020.

[0001571996-19-000039:notes:236]
[same as prior period, unchanged from 0001571996-19-000025:notes:233]

[0001571996-19-000039:notes:237]
Judgment is required in evaluating the Company’s uncertain tax positions and determining the Company’s provision for income taxes.  The unrecognized tax benefits were $3.5 billion and $3.4 billion as of August 2, 2019 and February 1, 2019, respectively, and are included in accrued and other and other non-current liabilities in the Condensed Consolidated Statements of Financial Position.  Although timing of resolution or closure of audits is not certain, the Company believes it is reasonably possible that certain tax matters in various jurisdictions, including those matters discussed above, could be concluded within the next twelve months.  The resolution of these audits could reduce the Company’s unrecognized tax benefits by an estimated amount of between $500 million to $800 million.  Such a reduction will have a material effect on the Company’s effective tax rate.

[0001571996-19-000039:notes:238]
The Company takes certain non-income tax positions in the jurisdictions in which it operates and has received certain non-income tax assessments from various jurisdictions.  The Company believes that a material loss in these matters is not probable and that it is not reasonably possible that a material loss exceeding amounts already accrued has been incurred.  The Company believes its positions in these non-income tax litigation matters are supportable and that it ultimately will prevail in the matters.  In the normal course of business, the Company’s positions and conclusions related to its non-income taxes could be challenged and assessments may be made.  To the extent new information is obtained and the Company’s views on its positions, probable outcomes of assessments, or litigation change, changes in estimates to the Company’s accrued liabilities would be recorded in the period in which such a determination is made.  In the resolution process for income tax and non-income tax audits, the Company is required in certain situations to provide collateral guarantees or indemnification to regulators and tax authorities until the matter is resolved.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001571996-19-000039:notes:239]
[same as prior period, unchanged from 0001571996-19-000025:notes:236]

[0001571996-19-000039:notes:240]
[same as prior period, unchanged from 0001571996-19-000025:notes:237]

[0001571996-19-000039:notes:241]
[same as prior period, unchanged from 0001571996-19-000025:notes:238]

[0001571996-19-000039:notes:242]
|  | Foreign Currency Translation Adjustments |  | Investments |  | Cash Flow Hedges |  | Pension and Other Postretirement Plans |  | Accumulated Other Comprehensive Income (Loss) |
|  | (in millions) |
| Balances as of February 1, 2019 | $ | (452 | ) |  | $ | — |  |  | $ | (29 | ) |  | $ | 14 |  |  | $ | (467 | ) |
| Other comprehensive income (loss) before reclassifications | (236 | ) |  | — |  |  | 257 |  |  | 8 |  |  | 29 |  |
| Amounts reclassified from accumulated other comprehensive income (loss) | — |  |  | — |  |  | (126 | ) |  | — |  |  | (126 | ) |
| Total change for the period | (236 | ) |  | — |  |  | 131 |  |  | 8 |  |  | (97 | ) |
| Less: Change in comprehensive income attributable to non-controlling interests | — |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Balances as of August 2, 2019 | $ | (688 | ) |  | $ | — |  |  | $ | 101 |  |  | $ | 22 |  |  | $ | (565 | ) |

[0001571996-19-000039:notes:243]
[same as prior period, unchanged from 0001571996-19-000025:notes:240]

[0001571996-19-000039:notes:244]
[same as prior period, unchanged from 0001571996-19-000025:notes:241]

[0001571996-19-000039:notes:245]
|  | Three Months Ended |
|  | August 2, 2019 |  | August 3, 2018 |
|  | Investments |  | Cash Flow Hedges |  | Total |  | Investments |  | Cash Flow Hedges |  | Total |
|  | (in millions) |
| Total reclassifications, net of tax: |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue | $ | — |  |  | $ | 68 |  |  | $ | 68 |  |  | $ | — |  |  | $ | 77 |  |  | $ | 77 |  |
| Cost of net revenue | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Interest and other, net | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total reclassifications, net of tax | $ | — |  |  | $ | 68 |  |  | $ | 68 |  |  | $ | — |  |  | $ | 77 |  |  | $ | 77 |  |
|  | Six Months Ended |
|  | August 2, 2019 |  | August 3, 2018 |
|  | Investments |  | Cash Flow Hedges |  | Total |  | Investments |  | Cash Flow Hedges |  | Total |
|  | (in millions) |
| Total reclassifications, net of tax: |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue | $ | — |  |  | $ | 126 |  |  | $ | 126 |  |  | $ | — |  |  | $ | 46 |  |  | $ | 46 |  |
| Cost of net revenue | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Interest and other, net | — |  |  | — |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Total reclassifications, net of tax | $ | — |  |  | $ | 126 |  |  | $ | 126 |  |  | $ | 1 |  |  | $ | 46 |  |  | $ | 47 |  |


## us-gaap:MinorityInterestDisclosureTextBlock

[0001571996-19-000039:notes:246]
[same as prior period, unchanged from 0001571996-19-000025:notes:243]

[0001571996-19-000039:notes:247]
VMware, Inc. — The non-controlling interests’ share of equity in VMware, Inc. is reflected as a component of the non-controlling interests in the accompanying Condensed Consolidated Statements of Financial Position and was $4.4 billion and $3.8 billion as of August 2, 2019 and February 1, 2019, respectively.  As of August 2, 2019 and February 1, 2019, the Company held approximately 80.8% and 80.5%, respectively, of the outstanding equity interest in VMware, Inc.

[0001571996-19-000039:notes:248]
Pivotal — The non-controlling interests’ share of equity in Pivotal is reflected as a component of the non-controlling interest in the accompanying Condensed Consolidated Statements of Financial Position and was $1.0 billion as of August 2, 2019 and February 1, 2019.  As of August 2, 2019 and February 1, 2019, the Company held approximately 60.9% and 62.8%, respectively, of the outstanding equity interest in Pivotal.

[0001571996-19-000039:notes:249]
Secureworks — The non-controlling interests’ share of equity in Secureworks is reflected as a component of the non-controlling interests in the accompanying Condensed Consolidated Statements of Financial Position and was $87 million as of August 2, 2019 and February 1, 2019.  As of August 2, 2019 and February 1, 2019, the Company held approximately 87.0% and 87.4%, respectively, of the outstanding equity interest in Secureworks, excluding restricted stock awards (“RSAs”).  As of August 2, 2019 and February 1, 2019, the Company held approximately 86.2% and 86.4%, respectively, of the outstanding equity interest in Secureworks, including RSAs.

[0001571996-19-000039:notes:250]
[same as prior period, unchanged from 0001571996-19-000025:notes:247]

[0001571996-19-000039:notes:251]
|  | Six Months Ended |
|  | August 2, 2019 |
|  | (in millions) |
| Net income attributable to Dell Technologies Inc. | $ | 3,709 |  |
| Transfers (to)/from the non-controlling interests: |  |
| Increase in Dell Technologies Inc. additional paid-in-capital for equity issuances and other equity activity | 379 |  |
| Decrease in Dell Technologies Inc. additional paid-in-capital and accumulated deficit for equity issuances and other equity activity | (1,036 | ) |
| Net transfers to non-controlling interests | (657 | ) |
| Change from net income attributable to Dell Technologies Inc. and transfers to the non-controlling interests | $ | 3,052 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001571996-19-000039:notes:252]
[same as prior period, unchanged from 0001571996-19-000025:notes:249]

[0001571996-19-000039:notes:253]
[same as prior period, unchanged from 0001571996-19-000025:notes:250]

[0001571996-19-000039:notes:254]
|  | Authorized |  | Issued |  | Outstanding |
|  | (in millions) |
| Common stock as of August 2, 2019 |
| Class A | 600 |  |  | 374 |  |  | 374 |  |
| Class B | 200 |  |  | 119 |  |  | 119 |  |
| Class C | 7,900 |  |  | 233 |  |  | 231 |  |
| Class D | 100 |  |  | — |  |  | — |  |
| Class V | 343 |  |  | — |  |  | — |  |
|  | 9,143 |  |  | 726 |  |  | 724 |  |
| Common stock as of February 1, 2019 |
| Class A | 600 |  |  | 410 |  |  | 410 |  |
| Class B | 200 |  |  | 137 |  |  | 137 |  |
| Class C | 7,900 |  |  | 174 |  |  | 172 |  |
| Class D | 100 |  |  | — |  |  | — |  |
| Class V | 343 |  |  | — |  |  | — |  |
|  | 9,143 |  |  | 721 |  |  | 719 |  |

[0001571996-19-000039:notes:255]
[same as prior period, unchanged from 0001571996-19-000025:notes:252]

[0001571996-19-000039:notes:256]
[same as prior period, unchanged from 0001571996-19-000025:notes:253]

[0001571996-19-000039:notes:257]
The Company is authorized to issue one million shares of preferred stock, par value $0.01 per share.  As of August 2, 2019 and February 1, 2019, no shares of preferred stock were issued or outstanding.

[0001571996-19-000039:notes:258]
[same as prior period, unchanged from 0001571996-19-000025:notes:255]

[0001571996-19-000039:notes:259]
[same as prior period, unchanged from 0001571996-19-000025:notes:256]

[0001571996-19-000039:notes:260]
Dell Technologies Common Stock — For fiscal periods beginning with the first quarter of Fiscal 2020, the Class A Common Stock, the Class B Common Stock, the Class C Common Stock, and the Class D Common Stock, formerly collectively referred to as the DHI Group Common Stock, are collectively referred to as Dell Technologies Common Stock.  The redesignation of such classes of common stock from DHI Group Common Stock to Dell Technologies Common Stock is intended to align the Company’s reporting with how such classes are referred to by securities analysts, investors, and other users of the financial statements since the completion on December 28, 2018 of the Class V transaction described below.  As a result of the cancellation of all outstanding Class V Common Stock upon the closing of that transaction, there is no requirement after the fourth quarter of Fiscal 2019 to allocate net income (loss) between two separate groups of common stock denoted the DHI Group Common Stock and the Class V Common Stock or to report earnings (loss) per share for each such group.  Accordingly, net income (loss), earnings (loss) per share and other relevant information will be reported for Dell Technologies Common Stock for all fiscal periods beginning with the first quarter of Fiscal 2020 and, because of lack of comparability with the new reporting, will be reported separately for the DHI Group and the Class V Common Stock, as applicable, for prior fiscal periods.  The par value for all classes of Dell Technologies Common Stock is $0.01 per share.  The Class A Common Stock, the Class B Common Stock, the Class C Common Stock, and the Class D Common Stock share equally in dividends declared or accumulated and have equal participation rights in undistributed earnings.

[0001571996-19-000039:notes:261]
[same as prior period, unchanged from 0001571996-19-000025:notes:258]

[0001571996-19-000039:notes:262]
DHI Group Common Stock and DHI Group — For the fiscal periods prior to the first quarter of Fiscal 2020, the Class A Common Stock, the Class B Common Stock, the Class C Common Stock, and the Class D Common Stock were collectively referred to as the DHI Group Common Stock.  All classes of DHI Group Common Stock have a par value of $0.01 per share and the Class A Common Stock, the Class B Common Stock, the Class C Common Stock, and the Class D Common Stock share equally in dividends declared or accumulated and have equal participation rights in undistributed earnings.  Prior to the completion on December 28, 2018 of the Class V transaction, the DHI Group referred to the direct and indirect interest of Dell Technologies in all of Dell Technologies’ business, assets, properties, liabilities, and preferred stock other than those attributable to the Class V Group, as well as the DHI Group’s retained interest in the Class V Group.  Subsequent to the completion of the Class V transaction, the DHI Group refers to all classes of issued and outstanding DHI Group Common Stock.

[0001571996-19-000039:notes:263]
Class V Common Stock and Class V Group — The Class V Common Stock was a class of common stock intended to track the performance of a portion of Dell Technologies’ economic interest in the Class V Group.  The Class V Group consisted solely of VMware, Inc. common stock held by the Company.  As of August 2, 2019, no shares of Class V Common Stock were outstanding.

[0001571996-19-000039:notes:264]
Voting Rights — Each holder of record of (a) Class A Common Stock is entitled to ten votes per share of Class A Common Stock; (b) Class B Common Stock is entitled to ten votes per share of Class B Common Stock; (c) Class C Common Stock is entitled to one vote per share of Class C Common Stock; and (d) Class D Common Stock is not entitled to any vote on any matter except to the extent required by provisions of Delaware law (in which case such holder is entitled to one vote per share of Class D Common Stock).

[0001571996-19-000039:notes:265]
Conversion Rights — Under the Company’s certificate of incorporation, at any time and from time to time, any holder of Class A Common Stock or Class B Common Stock has the right to convert all or any of the shares of Class A Common Stock or Class B Common Stock, as applicable, held by such holder into shares of Class C Common Stock on a one-to-one basis.  During the six months ended August 2, 2019, the Company issued 35,673,230 shares of Class C Common Stock to  stockholders upon their conversion of the same number of shares of Class A Common Stock into Class C Common Stock in accordance with the Company’s certificate of incorporation.  During the six months ended August 2, 2019, the Company issued 17,650,820 shares of Class C Common Stock to stockholders upon their conversion of the same number of shares of Class B Common Stock into Class C Common Stock in accordance with the Company’s certificate of incorporation.

[0001571996-19-000039:notes:266]
[same as prior period, unchanged from 0001571996-19-000025:notes:263]

[0001571996-19-000039:notes:267]
[same as prior period, unchanged from 0001571996-19-000025:notes:264]

[0001571996-19-000039:notes:268]
[same as prior period, unchanged from 0001571996-19-000025:notes:265]

[0001571996-19-000039:notes:269]
[same as prior period, unchanged from 0001571996-19-000025:notes:266]

[0001571996-19-000039:notes:270]
[same as prior period, unchanged from 0001571996-19-000025:notes:267]

[0001571996-19-000039:notes:271]
[same as prior period, unchanged from 0001571996-19-000025:notes:268]

[0001571996-19-000039:notes:272]
On May 29, 2019, VMware, Inc.’s board of directors authorized the repurchase of an additional $1.5 billion of VMware, Inc.’s Class A common stock.  Since the date of the EMC merger transaction, VMware, Inc.’s board of directors has authorized total repurchases of $3.7 billion, of which $1.3 billion remained available as of August 2, 2019.  During the six months ended August 2, 2019, VMware, Inc. repurchased 5.7 million shares of its Class A common stock in the open market for approximately $1.0 billion, of which approximately $0.1 billion impacted Dell Technologies’ accumulated deficit balance as of August 2, 2019 as a result of the full depletion of VMware, Inc.’s additional paid-in capital balance in the current period.  During the six months ended August 3, 2018, VMware, Inc. did not repurchase any shares of its Class A common stock.

[0001571996-19-000039:notes:273]
[same as prior period, unchanged from 0001571996-19-000025:notes:270]


## us-gaap:EarningsPerShareTextBlock

[0001571996-19-000039:notes:274]
[same as prior period, unchanged from 0001571996-19-000025:notes:271]

[0001571996-19-000039:notes:275]
[same as prior period, unchanged from 0001571996-19-000025:notes:272]

[0001571996-19-000039:notes:276]
Until the completion on December 28, 2018 of the Class V transaction described in Note 14 of the Notes to the Condensed Consolidated Financial Statements, the Company had two groups of common stock, denoted as the DHI Group Common Stock and the Class V Common Stock.

[0001571996-19-000039:notes:277]
[same as prior period, unchanged from 0001571996-19-000025:notes:274]

[0001571996-19-000039:notes:278]
[same as prior period, unchanged from 0001571996-19-000025:notes:275]

[0001571996-19-000039:notes:279]
[same as prior period, unchanged from 0001571996-19-000025:notes:276]

[0001571996-19-000039:notes:280]
[same as prior period, unchanged from 0001571996-19-000025:notes:277]

[0001571996-19-000039:notes:281]
[same as prior period, unchanged from 0001571996-19-000025:notes:278]

[0001571996-19-000039:notes:282]
|  | Three Months Ended |  | Six Months Ended |
|  | August 2, 2019 |  | August 3, 2018 |  | August 2, 2019 |  | August 3, 2018 |
| Earnings (loss) per share attributable to Dell Technologies Inc. - basic: |  |  |  |  |
| Dell Technologies Common Stock | $ | 4.75 |  |  |  |  | $ | 5.17 |  |  |  |
| Class V Common Stock |  |  | $ | 1.61 |  |  |  |  | $ | 3.97 |  |
| DHI Group |  |  | $ | (1.44 | ) |  |  |  | $ | (3.39 | ) |
| Earnings (loss) per share attributable to Dell Technologies Inc. - diluted: |  |  |  |  |
| Dell Technologies Common Stock | $ | 4.47 |  |  |  |  | $ | 4.84 |  |  |  |
| Class V Common Stock |  |  | $ | 1.58 |  |  |  |  | $ | 3.91 |  |
| DHI Group |  |  | $ | (1.45 | ) |  |  |  | $ | (3.40 | ) |

[0001571996-19-000039:notes:283]
The following table presents the computation of basic and diluted earnings (loss) per share for the periods indicated:

[0001571996-19-000039:notes:284]
|  | Three Months Ended |  | Six Months Ended |
|  | August 2, 2019 |  | August 2, 2019 |
|  | (in millions) |
| Numerator: Dell Technologies Common Stock |  |  |  |
| Net income attributable to Dell Technologies - basic | $ | 3,416 |  |  | $ | 3,709 |  |
| Incremental dilution from VMware, Inc. attributable to Dell Technologies (a) | (62 | ) |  | (78 | ) |
| Net income attributable to Dell Technologies - diluted | $ | 3,354 |  |  | $ | 3,631 |  |
| Denominator: Dell Technologies Common Stock weighted-average shares outstanding |  |
| Weighted-average shares outstanding - basic | 719 |  |  | 718 |  |
| Dilutive effect of options, restricted stock units, restricted stock, and other | 32 |  |  | 32 |  |
| Weighted-average shares outstanding - diluted | 751 |  |  | 750 |  |
| Weighted-average shares outstanding - antidilutive | 1 |  |  | 1 |  |

[0001571996-19-000039:notes:285]
[same as prior period, unchanged from 0001571996-19-000025:notes:282]

[0001571996-19-000039:notes:286]
The following table presents the computation of basic and diluted earnings (loss) per share prior to Fiscal 2020 for the periods indicated:

[0001571996-19-000039:notes:287]
|  | Three Months Ended |  | Six Months Ended |
|  | August 3, 2018 |  | August 3, 2018 |
|  | (in millions) |
| Numerator: Class V Common Stock |  |  |  |
| Net income attributable to Class V Common Stock - basic | $ | 320 |  |  | $ | 790 |  |
| Incremental dilution from VMware, Inc. attributable to Class V Common Stock (a) | (5 | ) |  | (12 | ) |
| Net income attributable to Class V Common Stock - diluted | $ | 315 |  |  | $ | 778 |  |
| Numerator: DHI Group |  |  |  |
| Net loss attributable to DHI Group - basic | $ | (819 | ) |  | $ | (1,925 | ) |
| Incremental dilution from VMware, Inc. attributable to DHI Group (a) | (4 | ) |  | (8 | ) |
| Net loss attributable to DHI Group - diluted | $ | (823 | ) |  | $ | (1,933 | ) |
| Denominator: Class V Common Stock weighted-average shares outstanding |  |  |  |  |  |
| Weighted-average shares outstanding - basic | 199 |  |  | 199 |  |
| Dilutive effect of options, restricted stock units, restricted stock, and other (b) | — |  |  | — |  |
| Weighted-average shares outstanding - diluted | 199 |  |  | 199 |  |
| Weighted-average shares outstanding - antidilutive (b) | — |  |  | — |  |
| Denominator: DHI Group weighted-average shares outstanding |  |  |  |
| Weighted-average shares outstanding - basic | 567 |  |  | 568 |  |
| Dilutive effect of options, restricted stock units, restricted stock, and other | — |  |  | — |  |
| Weighted-average shares outstanding - diluted | 567 |  |  | 568 |  |
| Weighted-average shares outstanding - antidilutive (c) | 47 |  |  | 48 |  |

[0001571996-19-000039:notes:288]
[same as prior period, unchanged from 0001571996-19-000025:notes:285]

[0001571996-19-000039:notes:289]
[same as prior period, unchanged from 0001571996-19-000025:notes:286]

[0001571996-19-000039:notes:290]
[same as prior period, unchanged from 0001571996-19-000025:notes:287]

[0001571996-19-000039:notes:291]
The following table presents a reconciliation to the consolidated net loss attributable to Dell Technologies Inc. prior to Fiscal 2020 for the periods indicated:

[0001571996-19-000039:notes:292]
|  | Three Months Ended |  | Six Months Ended |
|  | August 3, 2018 |  | August 3, 2018 |
|  | (in millions) |
| Net income attributable to Class V Common Stock (a) | $ | 320 |  |  | $ | 790 |  |
| Net loss attributable to DHI Group | (819 | ) |  | (1,925 | ) |
| Net loss attributable to Dell Technologies Inc. | $ | (499 | ) |  | $ | (1,135 | ) |

[0001571996-19-000039:notes:293]
[same as prior period, unchanged from 0001571996-19-000025:notes:290]

[0001571996-19-000039:notes:294]
See Exhibit 99.1 filed with the Company’s Quarterly Report on Form 10-Q for the quarterly period ended August 3, 2018 for a reconciliation of VMware net income to net income attributable to Class V Common Stock.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001571996-19-000039:notes:295]
[same as prior period, unchanged from 0001571996-19-000025:notes:292]

[0001571996-19-000039:notes:296]
Dell Technologies Inc. 2013 Stock Incentive Plan (As Amended and Restated as of July, 9, 2019) — During the three months ended August 2, 2019, the Company’s stockholders approved an amendment to the Dell Technologies Inc. 2013 Stock Incentive Plan (the “Plan”) to authorize an additional 35 million shares of Class C Common Stock for issuance pursuant to the Plan.  Upon effectiveness of the amendment, a total of 110.5 million shares of Class C Common Stock are authorized for issuance.  As of August 2, 2019, there were 54 million shares of Class C Common Stock available for future grants under the Plan.

[0001571996-19-000039:notes:297]
Restricted Stock Units — During the six months ended August 2, 2019, the Company granted long-term incentive awards in the form of 10.0 million service-based restricted stock units (“RSUs”) and 1.9 million performance-based RSUs in order to align critical talent retention programs with the interests of holders of the Class C Common Stock.

[0001571996-19-000039:notes:298]
The service-based RSUs have a fair value based on the closing price of the Class C Common Stock price as reported on the New York Stock Exchange (“NYSE”) on the grant date.  Most of such RSUs vest ratably over a three-year period.  Each service-based RSU represents the right to acquire one share of Class C Common Stock upon vesting.

[0001571996-19-000039:notes:299]
The performance-based RSUs are reflected at target units while the actual number of units that ultimately vest will range from 0% to 200% of target, based on the level of achievement of the performance goals and continued employment with the Company over a performance period ending March 14, 2022.  Approximately 0.9 million of the performance-based RSUs are subject to achievement of market-based performance goals based on relative total shareholder return.  For the non-market performance-based RSUs, the fair values will be based on the closing price of the Class C Common Stock as reported on the NYSE on the accounting grant date.  For the six months ended August 2, 2019, approximately one-third of the non-market performance awards have been valued and are considered outstanding for accounting purposes.  Market-based performance awards utilized a Monte Carlo valuation model to simulate the probabilities of achievement of relative total shareholder return in order to determine the awards’ fair value.

[0001571996-19-000039:notes:300]
[same as prior period, unchanged from 0001571996-19-000025:notes:296]

[0001571996-19-000039:notes:301]
|  | Six Months Ended |
|  | August 2, 2019 |
| Weighted-average grant date fair value | $ | 87.17 |  |
| Expected term (in years) | 3.0 |  |
| Risk-free rate (U.S. Government Treasury Note) | 2.4 | % |
| Expected volatility | 45 | % |
| Expected dividend yield | — | % |

[0001571996-19-000039:notes:302]
As of August 2, 2019, 15 million RSUs were outstanding, of which 5 million RSUs were subject to performance conditions.  The awards outstanding have a weighted-average grant date fair value of $49.80 per share and an aggregate intrinsic value of $812 million based on the closing price of the Class C Common Stock as reported on the NYSE on August 2, 2019.  As of August 2, 2019, there was $512 million of unrecognized stock-based compensation expense, net of estimated forfeitures, related to these awards expected to be recognized over a weighted-average period of approximately 2.6 years.

[0001571996-19-000039:notes:303]
Stock Options - Of the 42 million stock options outstanding as of February 1, 2019, 5 million were exercised under the Plan during the six months ended August 2, 2019 with a weighted-average exercise price of $16.74.  Cash proceeds were $88 million and the pre-tax intrinsic value of the options exercised was $189 million during the six months ended August 2, 2019.


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001571996-19-000039:notes:304]
[same as prior period, unchanged from 0001571996-19-000025:notes:300]

[0001571996-19-000039:notes:305]
[same as prior period, unchanged from 0001571996-19-000025:notes:301]

[0001571996-19-000039:notes:306]
[same as prior period, unchanged from 0001571996-19-000025:notes:302]

[0001571996-19-000039:notes:307]
[same as prior period, unchanged from 0001571996-19-000025:notes:303]

[0001571996-19-000039:notes:308]
| • | For share-based arrangements that are subject to the occurrence of a contingent event, those amounts are not reclassified to temporary equity until the contingency has been satisfied. Contingent events include the achievement of performance-based metrics. |

[0001571996-19-000039:notes:309]
In connection with the Class V transaction described in Note 14 of the Notes to the Condensed Consolidated Financial Statements, the put feature provisions were amended to provide that the put feature applicable to transfers of Dell Technologies securities will terminate upon the earlier of two years after the expiration on June 27, 2019 of the post-transaction lock-up or consummation of any underwritten public offering of shares of Class C Common Stock.

[0001571996-19-000039:notes:310]
The following table presents the amount of redeemable shares classified as temporary equity and summarizes the award type as of the dates indicated:

[0001571996-19-000039:notes:311]
|  | August 2, 2019 |  | February 1, 2019 |
|  | (in millions) |
| Redeemable shares classified as temporary equity | $ | 1,024 |  |  | $ | 1,196 |  |
| Issued and outstanding unrestricted common shares | 2 |  |  | 3 |  |
| Restricted stock units | 1 |  |  | 1 |  |
| Restricted stock awards | — |  |  | — |  |
| Outstanding stock options | 23 |  |  | 31 |  |

[0001571996-19-000039:notes:312]
The decrease in the value of redeemable shares during the six months ended August 2, 2019 was primarily attributable to a decrease in Class C Common Stock fair value, reassessment of vesting probability for performance-based awards and a reduction in the number of shares eligible for put rights as market sales of shares occur.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001571996-19-000039:notes:313]
[same as prior period, unchanged from 0001571996-19-000025:notes:309]

[0001571996-19-000039:notes:314]
[same as prior period, unchanged from 0001571996-19-000025:notes:310]

[0001571996-19-000039:notes:315]
[same as prior period, unchanged from 0001571996-19-000025:notes:311]

[0001571996-19-000039:notes:316]
[same as prior period, unchanged from 0001571996-19-000025:notes:312]

[0001571996-19-000039:notes:317]
VMware works with customers in the areas of hybrid cloud, multi-cloud, modern applications, networking and security, and digital workspaces, helping customers manage their IT resources across private clouds and complex multi-cloud, multi-device environments.  VMware solutions provide a flexible digital foundation to enable the digital transformation of VMware’s customers as they ready their applications, infrastructure, and devices for their future business needs.

[0001571996-19-000039:notes:318]
The reportable segments disclosed herein are based on information reviewed by the Company’s management to evaluate the business segment results.  The Company’s measure of segment operating income for management reporting purposes excludes the impact of Other businesses, purchase accounting, amortization of intangible assets, unallocated corporate transactions, other corporate expenses, stock-based compensation expense, and transaction-related expenses.  The Company does not allocate assets to the above reportable segments for internal reporting purposes.

[0001571996-19-000039:notes:319]
[same as prior period, unchanged from 0001571996-19-000025:notes:315]

[0001571996-19-000039:notes:320]
|  | Three Months Ended |  | Six Months Ended |
|  | August 2, 2019 |  | August 3, 2018 |  | August 2, 2019 |  | August 3, 2018 |
|  | (in millions) |
| Consolidated net revenue: |  |  |  |  |  |  |  |  |  |  |
| Infrastructure Solutions Group | $ | 8,621 |  |  | $ | 9,227 |  |  | $ | 16,823 |  |  | $ | 17,894 |  |
| Client Solutions Group | 11,748 |  |  | 11,128 |  |  | 22,658 |  |  | 21,399 |  |
| VMware | 2,466 |  |  | 2,194 |  |  | 4,748 |  |  | 4,222 |  |
| Reportable segment net revenue | 22,835 |  |  | 22,549 |  |  | 44,229 |  |  | 43,515 |  |
| Other businesses (a) | 619 |  |  | 574 |  |  | 1,215 |  |  | 1,153 |  |
| Unallocated transactions (b) | — |  |  | (1 | ) |  | — |  |  | (3 | ) |
| Impact of purchase accounting (c) | (84 | ) |  | (180 | ) |  | (166 | ) |  | (367 | ) |
| Total consolidated net revenue | $ | 23,370 |  |  | $ | 22,942 |  |  | $ | 45,278 |  |  | $ | 44,298 |  |
| Consolidated operating income (loss): |  |  |  |  |  |  |  |
| Infrastructure Solutions Group | $ | 1,050 |  |  | $ | 1,012 |  |  | $ | 1,893 |  |  | $ | 1,951 |  |
| Client Solutions Group | 982 |  |  | 425 |  |  | 1,775 |  |  | 958 |  |
| VMware | 762 |  |  | 736 |  |  | 1,376 |  |  | 1,349 |  |
| Reportable segment operating income | 2,794 |  |  | 2,173 |  |  | 5,044 |  |  | 4,258 |  |
| Other businesses (a) | (25 | ) |  | (49 | ) |  | (78 | ) |  | (99 | ) |
| Unallocated transactions (b) | (26 | ) |  | (16 | ) |  | (27 | ) |  | (25 | ) |
| Impact of purchase accounting (c) | (102 | ) |  | (215 | ) |  | (203 | ) |  | (437 | ) |
| Amortization of intangibles | (1,060 | ) |  | (1,526 | ) |  | (2,277 | ) |  | (3,048 | ) |
| Transaction-related expenses (d) | (47 | ) |  | (104 | ) |  | (89 | ) |  | (270 | ) |
| Stock-based compensation expense (e) | (301 | ) |  | (216 | ) |  | (564 | ) |  | (415 | ) |
| Other corporate expenses (f) | (714 | ) |  | (60 | ) |  | (737 | ) |  | (130 | ) |
| Total consolidated operating income (loss) | $ | 519 |  |  | $ | (13 | ) |  | $ | 1,069 |  |  | $ | (166 | ) |

[0001571996-19-000039:notes:321]
[same as prior period, unchanged from 0001571996-19-000025:notes:317]

[0001571996-19-000039:notes:322]
| (b) | Unallocated transactions includes other corporate items that are not allocated to Dell Technologies’ reportable segments. |

[0001571996-19-000039:notes:323]
[same as prior period, unchanged from 0001571996-19-000025:notes:319]

[0001571996-19-000039:notes:324]
[same as prior period, unchanged from 0001571996-19-000025:notes:320]

[0001571996-19-000039:notes:325]
[same as prior period, unchanged from 0001571996-19-000025:notes:321]

[0001571996-19-000039:notes:326]
| (f) | Other corporate expenses includes impairment charges and severance, facility action, and other costs. See Note 8 of the Notes to the Condensed Consolidated Financial Statements for additional information on Virtustream impairment charges. |

[0001571996-19-000039:notes:327]
[same as prior period, unchanged from 0001571996-19-000025:notes:323]

[0001571996-19-000039:notes:328]
|  | Three Months Ended |  | Six Months Ended |
|  | August 2, 2019 |  | August 3, 2018 |  | August 2, 2019 |  | August 3, 2018 |
|  | (in millions) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |
| Infrastructure Solutions Group: |  |  |  |  |  |  |  |
| Servers and networking | $ | 4,437 |  |  | $ | 5,061 |  |  | $ | 8,617 |  |  | $ | 9,646 |  |
| Storage | 4,184 |  |  | 4,166 |  |  | 8,206 |  |  | 8,248 |  |
| Total ISG net revenue | 8,621 |  |  | 9,227 |  |  | 16,823 |  |  | 17,894 |  |
| Client Solutions Group: |  |  |  |  |  |  |  |
| Commercial | 9,077 |  |  | 8,109 |  |  | 17,384 |  |  | 15,472 |  |
| Consumer | 2,671 |  |  | 3,019 |  |  | 5,274 |  |  | 5,927 |  |
| Total CSG net revenue | 11,748 |  |  | 11,128 |  |  | 22,658 |  |  | 21,399 |  |
| VMware: |  |  |  |  |  |  |  |
| Total VMware net revenue | 2,466 |  |  | 2,194 |  |  | 4,748 |  |  | 4,222 |  |
| Total segment net revenue | $ | 22,835 |  |  | $ | 22,549 |  |  | $ | 44,229 |  |  | $ | 43,515 |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001571996-19-000039:notes:329]
[same as prior period, unchanged from 0001571996-19-000025:notes:325]

[0001571996-19-000039:notes:330]
[same as prior period, unchanged from 0001571996-19-000025:notes:326]

[0001571996-19-000039:notes:331]
|  | August 2, 2019 |  | February 1, 2019 |
|  | (in millions) |
| Cash, cash equivalents, and restricted cash: |  |  |  |
| Cash and cash equivalents | $ | 9,193 |  |  | $ | 9,676 |  |
| Restricted cash - other current assets (a) | 616 |  |  | 522 |  |
| Restricted cash - other non-current assets (a) | 126 |  |  | 42 |  |
| Total cash, cash equivalents, and restricted cash | $ | 9,935 |  |  | $ | 10,240 |  |
| Inventories, net: |  |  |  |
| Production materials | $ | 1,441 |  |  | $ | 1,794 |  |
| Work-in-process | 623 |  |  | 702 |  |
| Finished goods | 1,071 |  |  | 1,153 |  |
| Total inventories, net | $ | 3,135 |  |  | $ | 3,649 |  |
| Other non-current liabilities: |  |  |  |
| Warranty liability | $ | 170 |  |  | $ | 169 |  |
| Deferred and other tax liabilities | 4,605 |  |  | 5,527 |  |
| Non-current operating lease liabilities | 1,234 |  |  | — |  |
| Other | 619 |  |  | 631 |  |
| Total other non-current liabilities | $ | 6,628 |  |  | $ | 6,327 |  |

[0001571996-19-000039:notes:332]
| (a) | Restricted cash primarily includes cash required to be held in escrow pursuant to DFS securitization arrangements and VMware, Inc. restricted cash. |

[0001571996-19-000039:notes:333]
[same as prior period, unchanged from 0001571996-19-000025:notes:329]

[0001571996-19-000039:notes:334]
[same as prior period, unchanged from 0001571996-19-000025:notes:330]

[0001571996-19-000039:notes:335]
|  | Three Months Ended |  | Six Months Ended |
|  | August 2, 2019 |  | August 3, 2018 |  | August 2, 2019 |  | August 3, 2018 |
|  | (in millions) |
| Warranty liability: |  |  |  |  |  |  |  |
| Warranty liability at beginning of period | $ | 500 |  |  | $ | 527 |  |  | $ | 524 |  |  | $ | 539 |  |
| Costs accrued for new warranty contracts and changes in estimates for pre-existing warranties (a) (b) | 237 |  |  | 236 |  |  | 440 |  |  | 430 |  |
| Service obligations honored | (212 | ) |  | (221 | ) |  | (439 | ) |  | (427 | ) |
| Warranty liability at end of period | $ | 525 |  |  | $ | 542 |  |  | $ | 525 |  |  | $ | 542 |  |
| Current portion | $ | 355 |  |  | $ | 366 |  |  | $ | 355 |  |  | $ | 366 |  |
| Non-current portion | $ | 170 |  |  | $ | 176 |  |  | $ | 170 |  |  | $ | 176 |  |

[0001571996-19-000039:notes:336]
[same as prior period, unchanged from 0001571996-19-000025:notes:332]

[0001571996-19-000039:notes:337]
[same as prior period, unchanged from 0001571996-19-000025:notes:333]

[0001571996-19-000039:notes:338]
[same as prior period, unchanged from 0001571996-19-000025:notes:334]


## us-gaap:SubsequentEventsTextBlock

[0001571996-19-000039:notes:339]
NOTE 20 — SUBSEQUENT EVENTS

[0001571996-19-000039:notes:340]
VMware, Inc. Acquisition Agreements

[0001571996-19-000039:notes:341]
Carbon Black  — VMware, Inc. entered into a definitive agreement to acquire Carbon Black, Inc. through a cash tender offer of $26.00 per share, resulting in an expected net cash payment of $1.9 billion by VMware, Inc.  Carbon Black, Inc. develops cloud-native endpoint security software.  The acquisition has been approved by the boards of directors of both VMware, Inc. and Carbon Black, Inc. and is expected to close during the second half of Fiscal 2020, subject to completion of the tender offer, regulatory approvals and other customary closing conditions.

[0001571996-19-000039:notes:342]
Pivotal — VMware, Inc. entered into a definitive merger agreement (the “Merger Agreement”) to acquire Pivotal at a blended price per share of $11.71 per share, consisting of $15.00 per share in cash to the holders of Pivotal’s Class A common stock, and the exchange of VMware, Inc.’s Class B common stock for Pivotal’s Class B common stock held by Dell Technologies, at an exchange ratio of 0.0550 VMware, Inc. shares for each Pivotal share.  In aggregate, this transaction will result in an expected net cash payment of $0.8 billion by VMware, Inc. and the issuance of approximately 7.2 million shares of VMware, Inc.’s Class B common stock to Dell Technologies.  The VMware, Inc. Class B common stock issued to Dell Technologies would increase its ownership stake in VMware, Inc. by approximately 0.3 percentage points to 81.1% based on the shares outstanding as of the announcement of the Merger Agreement.  The acquisition has been approved by the boards of directors of both VMware, Inc. and Pivotal and is expected to close during the second half of Fiscal 2020, subject to approval of the Merger Agreement by Pivotal stockholders, regulatory approvals and other customary closing conditions.  The purchase of Pivotal will be accounted for as a transaction by entities under common control. Assets and liabilities transferred will be recorded at their historical carrying amounts on the date of the transfer, with no goodwill being recognized.

[0001571996-19-000039:notes:343]
Support Agreement — In connection with VMware, Inc.’s entry into the Merger Agreement to acquire Pivotal as described above, Dell Technologies entered into a Consent and Support Agreement (the “Support Agreement”) with EMC Equity Assets LLC (“EMC Equity,” and together with Dell Technologies, the “Dell Stockholders”), VMware, Inc. and, solely with respect to certain sections therein, EMC and VMW Holdco LLC (“VMW Holdco”).  Each of EMC Equity, EMC, and VMW Holdco is a wholly owned subsidiary of Dell Technologies.  Pursuant to the Support Agreement, the Dell Stockholders have agreed, among other matters and subject to the terms and conditions therein, in their capacity as holders of shares of Pivotal, to vote in favor of adopting the Merger Agreement, the merger and each of the actions contemplated by the Merger Agreement.  The Dell Stockholders also have agreed to certain restrictions on transfer of their shares of the Class B common stock of Pivotal, as further set forth in the Support Agreement.  Additionally, pursuant to the Support Agreement, EMC and VMW Holdco, together as the holders of all of the outstanding shares of Class B common stock of VMware, Inc., irrevocably have consented to VMware, Inc. entering into the Merger Agreement and the consummation of the transactions contemplated thereby.  The Support Agreement provides that, subject to VMware, Inc.’s ability to consummate the Pivotal acquisition and prior to the transaction closing, VMware, Inc. and Dell Technologies will execute an amendment to the tax sharing agreement between the two companies.

[0001571996-19-000039:notes:344]
Commitment For Senior Unsecured Term Loan Facility of VMware, Inc.

[0001571996-19-000039:notes:345]
VMware, Inc. received a commitment from a financial institution for a senior unsecured 364-day term loan facility that would provide VMware, Inc. with a borrowing capacity of up to $2.0 billion (the “Commitment”), which, if funded, may be used for general corporate purposes.  The initial funding of the Commitment is subject to various customary conditions, including execution and delivery of the definitive loan agreement and related documentation.

[0001571996-19-000039:notes:346]
Refinancing Transaction

[0001571996-19-000039:notes:347]
On September 5, 2019, the Company initiated a refinancing of its existing $4.9 billion Term Loan B Facility due September 2023, which it intends to replace with a modified $4.0 billion Term Loan B Facility due 2025.  The transaction is expected to close on or about September 18, 2019.
