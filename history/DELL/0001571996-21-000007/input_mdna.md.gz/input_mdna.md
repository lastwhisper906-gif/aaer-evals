# DELL MD&A — 0001571996-21-000007


## mdna

[0001571996-21-000007:mdna:1]
ITEM 7 — MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0001571996-21-000007:mdna:2]
This management’s discussion and analysis should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in this Annual Report on Form 10-K.  This section of this Form 10-K generally discusses Fiscal 2021 and Fiscal 2020 items and year-to-year comparisons between Fiscal 2021 and Fiscal 2020.  Discussions of Fiscal 2019 items and year-to-year comparisons between Fiscal 2020 and Fiscal 2019 that are not included in this Form 10-K can be found in “Part II — Item 7 — Management’s Discussion and Analysis of Financial Condition and Results of Operations” of the Company’s Annual Report on Form 10-K for the fiscal year ended January 31, 2020, as filed with the SEC on March 27, 2020, which is available free of charge on the SEC’s website at www.sec.gov and on our Investor Relations website at investors.delltechnologies.com.

[0001571996-21-000007:mdna:3]
Unless otherwise indicated, all results presented are prepared in a manner that complies, in all material respects, with accounting principles generally accepted in the United States of America (“GAAP”).  Additionally, unless otherwise indicated, all changes identified for the current-period results represent comparisons to results for the prior corresponding fiscal period.

[0001571996-21-000007:mdna:4]
Unless the context indicates otherwise, references in this report to “we,” “us,” “our,” the “Company,” and “Dell Technologies” mean Dell Technologies Inc. and its consolidated subsidiaries, references to “Dell” mean Dell Inc. and Dell Inc.’s consolidated subsidiaries, and references to “EMC” mean EMC Corporation and EMC Corporation’s consolidated subsidiaries.

[0001571996-21-000007:mdna:5]
Our fiscal year is the 52- or 53-week period ending on the Friday nearest January 31.  We refer to our fiscal years ended January 29, 2021, January 31, 2020, and February 1, 2019 as “Fiscal 2021,” “Fiscal 2020,” and “Fiscal 2019,” respectively.  All fiscal years presented included 52 weeks.

[0001571996-21-000007:mdna:6]
INTRODUCTION

[0001571996-21-000007:mdna:7]
Dell Technologies helps organizations and individuals build their digital future and transform how they work, live and play.  We provide customers with the industry’s broadest and most innovative technology and services portfolio for the data era, spanning both traditional infrastructure and emerging multi-cloud technologies.  We continue to seamlessly deliver differentiated and holistic IT solutions to our customers, which has driven significant revenue growth and share gains.

[0001571996-21-000007:mdna:8]
Dell Technologies’ integrated solutions help customers modernize their IT infrastructure, manage and operate in a multi-cloud world, address workforce transformation, and provide critical solutions that keep people and organizations connected, which has proven even more important in this current time of disruption caused by the coronavirus pandemic.  We are helping customers accelerate their digital transformations to improve and strengthen business and workforce productivity.  With our extensive portfolio and our commitment to innovation, we offer secure, integrated solutions that extend from the edge to the core to the cloud, and we are at the forefront of the software-defined and cloud native infrastructure era.  As further evidence of our commitment to innovation, in Fiscal 2021 we announced our plan to evolve and expand our IT as-a-Service and cloud offerings through Apex.  Apex will provide our customers with greater flexibility to scale IT to meet their evolving business needs and budgets.

[0001571996-21-000007:mdna:9]
Dell Technologies’ end-to-end portfolio is supported by a world-class organization with unmatched size and scale.  We operate globally in 180 countries across key functional areas, including technology and product development, marketing, sales, financial services, and global services.  Our go-to-market engine includes a 39,000-person sales force and a global network of over 200,000 channel partners.  Dell Financial Services and its affiliates (“DFS”) offer customer payment flexibility and enables synergies across the business.  DFS funded $9 billion of originations in Fiscal 2021 and maintains a $10 billion global portfolio of high-quality financing receivables.  We employ 34,000 full-time service and support professionals and maintain more than 2,400 vendor-managed service centers.  We manage a world-class supply chain that drives long-term growth and operating efficiencies, with approximately $70 billion in annual procurement expenditures and over 750 parts distribution centers.  Together, these elements provide a critical foundation for our success.

[0001571996-21-000007:mdna:10]
Products and Services

[0001571996-21-000007:mdna:11]
We design, develop, manufacture, market, sell, and support a wide range of comprehensive and integrated solutions, products, and services.  We are organized into the following business units, which are our reportable segments: Infrastructure Solutions Group; Client Solutions Group; and VMware.

[0001571996-21-000007:mdna:12]
•Infrastructure Solutions Group (“ISG”) — ISG enables the digital transformation of our customers through our trusted multi-cloud and big data solutions, which are built upon a modern data center infrastructure.  ISG works with customers in the area of hybrid cloud deployment with the goal of simplifying, streamlining, and automating cloud operations.  ISG solutions are built for multi-cloud environments and are optimized to run cloud native workloads in both public and private clouds, as well as traditional on-premise workloads.

[0001571996-21-000007:mdna:13]
Our comprehensive portfolio of advanced storage solutions includes traditional storage solutions as well as next-generation storage solutions (such as all-flash arrays, scale-out file, object platforms, and software-defined solutions).  We have simplified our storage portfolio to ensure that we deliver the technology needed for our customers’ digital transformation.  We continue to make enhancements to our storage solutions offerings and expect that these offerings, including our new PowerStore storage array released in May 2020, will drive long-term improvements in the business.  Our server portfolio includes high-performance rack, blade, tower, and hyperscale servers, optimized for artificial intelligence and machine learning workloads.  Our networking portfolio helps our business customers transform and modernize their infrastructure, mobilize and enrich end-user experiences, and accelerate business applications and processes.  Our strengths in server, storage, and virtualization software solutions enable us to offer leading converged and hyper-converged solutions, allowing our customers to accelerate their IT transformation by acquiring scalable integrated IT solutions instead of building and assembling their own IT platforms.  ISG also offers attached software, peripherals and services, including support and deployment, configuration, and extended warranty services.

[0001571996-21-000007:mdna:14]
Approximately half of ISG revenue is generated by sales to customers in the Americas, with the remaining portion derived from sales to customers in the Europe, Middle East, and Africa region (“EMEA”) and the Asia-Pacific and Japan region (“APJ”).

[0001571996-21-000007:mdna:15]
•Client Solutions Group (“CSG”) — CSG includes branded hardware (such as desktops, workstations, and notebooks) and branded peripherals (such as displays and projectors), as well as third-party software and peripherals.  Our computing devices are designed with our commercial and consumer customers’ needs in mind, and we seek to optimize performance, reliability, manageability, design, and security.  In addition to our traditional hardware business, we have a portfolio of thin client offerings that we believe will allow us to benefit from the growth trends in cloud computing.  For our customers that are seeking to simplify client lifecycle management, Dell PC as a Service offering combines hardware, software, lifecycle services, and financing into one all-encompassing solution that provides predictable pricing per seat per month.  CSG also offers attached software, peripherals, and services, including support and deployment, configuration, and extended warranty services.

[0001571996-21-000007:mdna:16]
Approximately half of CSG revenue is generated by sales to customers in the Americas, with the remaining portion derived from sales to customers in EMEA and APJ.

[0001571996-21-000007:mdna:17]
•VMware — The VMware reportable segment (“VMware”) reflects the operations of VMware, Inc. (NYSE: VMW) within Dell Technologies.  VMware works with customers in the areas of hybrid and multi-cloud, modern applications, networking, security, and digital workspaces, helping customers manage their IT resources across private clouds and complex multi-cloud, multi-device environments.  VMware’s portfolio supports and addresses the key IT priorities of customers: accelerating their cloud journey, migrating and modernizing their applications, empowering digital workspaces, transforming networking, and embracing intrinsic security.  VMware enables its customers to digitally transform their operations as they ready their applications, infrastructure, and employees for constantly evolving business needs.

[0001571996-21-000007:mdna:18]
During the third quarter of Fiscal 2020, VMware, Inc. completed its acquisition of Carbon Black, Inc. (“Carbon Black”), a developer of cloud-native endpoint protection.

[0001571996-21-000007:mdna:19]
36

[0001571996-21-000007:mdna:20]
On December 30, 2019, VMware, Inc. completed its acquisition of Pivotal, Inc. (“Pivotal”).  Before the transaction, Pivotal was a majority-owned subsidiary of Dell Technologies through EMC and VMware, Inc.  Pivotal provides a leading cloud-native platform that makes software development and IT operations a strategic advantage for customers.  Pivotal’s cloud-native platform, Pivotal Cloud Foundry, accelerates and streamlines software development by reducing the complexity of building, deploying and operating new cloud-native applications, and modernizing legacy applications.  With the acquisition, which aligns key software assets, VMware, Inc. builds on a comprehensive development platform with Kubernetes.

[0001571996-21-000007:mdna:21]
Dell Technologies now reports Pivotal results within the VMware reportable segment, and the historical segment results were recast to reflect this change.  Pivotal results were previously reported within Other businesses.  See Note 19 of the Notes to the Consolidated Financial Statements included in this report for the recast of segment results.

[0001571996-21-000007:mdna:22]
Approximately half of VMware revenue is generated by sales to customers in the United States.

[0001571996-21-000007:mdna:23]
Our other businesses, described below, consist of product and service offerings of Secureworks, Virtustream, and Boomi, each of which is majority-owned by Dell Technologies.  These businesses are not classified as reportable segments, either individually or collectively, as the results of the businesses are not material to our overall results and the businesses do not meet the criteria for reportable segments.

[0001571996-21-000007:mdna:24]
•Secureworks (NASDAQ: SCWX) is a leading global provider of intelligence-driven information security solutions singularly focused on protecting its clients from cyber attacks.  The solutions offered by Secureworks enable organizations of varying size and complexity to fortify their cyber defenses to prevent security breaches, detect malicious activity in near real time, prioritize and respond rapidly to security incidents and predict emerging threats.

[0001571996-21-000007:mdna:25]
•Virtustream offers cloud software and infrastructure-as-a-service solutions that enable customers to migrate, run, and manage mission-critical applications in cloud-based IT environments.  Beginning in the first quarter of Fiscal 2019, Virtustream results are reported within other businesses, rather than within ISG.  This change in reporting structure did not impact our previously reported consolidated financial results, but our prior period segment results have been recast to reflect the change.

[0001571996-21-000007:mdna:26]
•Boomi specializes in cloud-based integration, connecting information between existing on-premise and cloud-based applications to ensure business processes are optimized, data is accurate and workflow is reliable.

[0001571996-21-000007:mdna:27]
On February 18, 2020, we announced our entry into a definitive agreement with a consortium of investors to sell RSA Security, which provides cybersecurity solutions.  On September 1, 2020, the parties closed the transaction.  At the completion of the sale, we received total cash consideration of approximately $2.082 billion, resulting in a pre-tax gain on sale of $338 million.  The Company ultimately recorded a $21 million loss net of taxes.  The transaction was intended to further simplify our product portfolio and corporate structure.  Prior to the divestiture, RSA Security’s operating results were included within Other businesses.  See Note 1 of the Notes to the Consolidated Financial Statements included in this report for more information about this transaction.

[0001571996-21-000007:mdna:28]
We believe the collaboration, innovation, and coordination of the operations and strategies across all segments of our business, as well as our differentiated go-to-market model, will continue to drive revenue synergies.  Through our coordinated research and development activities, we are able to jointly engineer leading innovative solutions that incorporate the distinct set of hardware, software, and services across all segments of our business.

[0001571996-21-000007:mdna:29]
Our products and services offerings are continually evolving in response to industry dynamics.  As a result, reclassifications of certain products and services solutions in major product categories may be required.  For further discussion regarding our current reportable segments, see “Results of Operations — Business Unit Results” and Note 19 of the Notes to the Consolidated Financial Statements included in this report.

[0001571996-21-000007:mdna:30]
Dell Financial Services

[0001571996-21-000007:mdna:31]
DFS supports our businesses by offering and arranging various financing options and services for our customers primarily in North America, Europe, Australia, and New Zealand.  DFS originates, collects, and services customer receivables primarily related to the purchase or use of our product, software, and services solutions.  We also arrange financing for some of our customers in various countries where DFS does not currently operate as a captive.  DFS further strengthens our customer

[0001571996-21-000007:mdna:32]
relationships through its flexible consumption models, which enable us to offer our customers the option to pay over time and, in certain cases, based on utilization, provide them with financial flexibility to meet their changing technological requirements.  The results of these operations are allocated to our segments based on the underlying product or service financed.  For additional information about our financing arrangements, see Note 4 of the Notes to the Consolidated Financial Statements included in this report.

[0001571996-21-000007:mdna:33]
Strategic Investments and Acquisitions

[0001571996-21-000007:mdna:34]
As part of our strategy, we will continue to evaluate opportunities for strategic investments through our venture capital investment arm, Dell Technologies Capital, with a focus on emerging technology areas that are relevant to all segments of our business and that will complement our existing portfolio of solutions.  Our investment areas include storage, software-defined networking, management and orchestration, security, machine learning and artificial intelligence, Big Data and analytics, cloud, Internet of Things (“IoT”), and software development operations.  In addition to these investments, we also may make disciplined acquisitions targeting businesses that advance our strategic objectives.  As of January 29, 2021 and January 31, 2020, Dell Technologies held strategic investments of $1.4 billion and $0.9 billion, respectively.

[0001571996-21-000007:mdna:35]
Business Trends and Challenges

[0001571996-21-000007:mdna:36]
COVID-19 Pandemic and Response — In March 2020, the World Health Organization (“WHO”) declared the outbreak of the COVID-19 a pandemic.  This declaration was followed by significant governmental measures implemented in the United States and globally, including travel bans and restrictions, shelter-in-place orders, limitations and closures of non-essential businesses, and social distancing requirements in efforts to slow down and control the spread of the virus.

[0001571996-21-000007:mdna:37]
The health of our employees, customers, business partners, and communities remains our primary focus.  During Fiscal 2021, we took numerous actions in response to COVID-19, including a swift implementation of our business continuity plans.  Our crisis management team is actively engaged to respond to changes in our environment quickly and effectively, and to ensure that our ongoing response activities are aligned with recommendations of the WHO and the U.S. Centers for Disease Control and Prevention, and with governmental regulations.  We are adjusting restrictions previously implemented as new information becomes available, governmental regulations are updated, and vaccines become more widely distributed.  Most of our employees were previously equipped with remote work capabilities over the past several years, which enabled us to quickly establish a work-from-home posture for the majority of our employees.  Further, we implemented pandemic-specific protocols for our essential employees whose jobs require them to be on-site or with customers.  We are deploying return-to-site processes in certain regions based on ongoing assessments of local conditions by our management team.  We will continue to monitor regional conditions and utilize remote work practices to ensure the health and safety of our employees, customers, and business partners.

[0001571996-21-000007:mdna:38]
During Fiscal 2021, we worked closely with our customers and business partners to support them as they expanded their own remote work solutions and contingency plans and to help them access our products and services remotely.  Our agility, our breadth, and our scale will continue to benefit us in serving our customers and business partners during this period of accelerated digital transformation and uncertainty relating to the effects of COVID-19.  Notable actions we have taken to date include the following:

[0001571996-21-000007:mdna:39]
•Our global sales teams embraced a new selling process and are successfully supporting our customers and partners remotely.

[0001571996-21-000007:mdna:40]
•We are helping to address our customers’ cash flow requirements by expanding our as-a-service and financing offerings.

[0001571996-21-000007:mdna:41]
•Our close relationships and ability to connect directly with our customers through our e-commerce business have enabled us to quickly meet the immediate demands of the new work- and learn-from-home environments.

[0001571996-21-000007:mdna:42]
•The strength, scale, and resiliency of our global supply chain have afforded us flexibility to manage through this challenging period.  We adapted to events unfolding real-time by applying predictive analytics to model a variety of outcomes to respond quickly to the changing environment.  We optimized our global supply chain footprint to maximize factory uptime, for both Dell Technologies and our suppliers, by working through various local governmental regulations and mandates.  During this period, we established robust safety measures to protect the health and safety of our essential team members.

[0001571996-21-000007:mdna:43]
•We continue to drive innovation and excellence in engineering with a largely remote workforce.  Engineers and product teams delivered several critical solutions during Fiscal 2021, including cloud updates and key client product refreshes, as well as the May 2020 launch of the PowerStore midrange storage solution.

[0001571996-21-000007:mdna:44]
During Fiscal 2021, we took precautionary measures to increase our cash position and preserve financial flexibility.  We also took a series of prudent steps to manage expenses and preserve liquidity that included, among others, global hiring limitations, reductions in consulting and contractor costs and facilities-related costs, global travel restrictions, and temporary suspension of the Dell 401(k) match program for U.S. employees.

[0001571996-21-000007:mdna:45]
In the fourth quarter of Fiscal 2021, we began to reinstate selected employee-related compensation benefits, which we expect will put pressure on operating income in Fiscal 2022.  Effective January 1, 2021, we resumed the Dell 401(k) match program for U.S. employees.  We will continue to invest in long-term projects, while focusing on operating expense controls in certain areas of the business.  All of these actions are aligned with our strategy, which remains unchanged, of focusing on gaining market share, integrating and innovating across the Dell Technologies portfolio, and strengthening our capital structure.

[0001571996-21-000007:mdna:46]
We saw unique demand dynamics during Fiscal 2021.  In CSG, strong demand was driven by the imperative for remote work and remote learning solutions, as business, government, and education customers sought to maintain productivity in the midst of COVID-19.  In ISG, the demand environment weakened as enterprise customers shifted their investments towards remote work and business continuity solutions.  For additional information about impacts of COVID-19 on our operations, see “Results of Operations—Consolidated Results” and “—Business Unit Results.”

[0001571996-21-000007:mdna:47]
Although we continue to experience some uncertainty in the global markets as a result of the ongoing COVID-19 pandemic, we see opportunities to create value and grow in Fiscal 2022 in the midst of resilient demand for our IT solutions driven by a technology-enabled world.  We will continue to actively monitor global events and pursue prudent decisions to navigate in this uncertain and ever-changing environment.

[0001571996-21-000007:mdna:48]
Dell Technologies Vision and Innovation — Our vision is to be the essential technology company for the data era and a leader in end-user computing, software-defined data center solutions, data management, virtualization, IoT, and cloud software.  We believe that our results will benefit from an integrated go-to-market strategy, including enhanced coordination across all segments of our business, and from our differentiated products and solutions capabilities.  We intend to continue to execute on our business model and seek to balance liquidity, profitability, and growth to position our company for long-term success.

[0001571996-21-000007:mdna:49]
We are seeing an accelerated rate of change in the IT industry.  We seek to address our customers’ evolving needs and their broader digital transformation objectives as they embrace the hybrid multi-cloud environment of today.  Currently for many customers, a top digital priority is to build stable and resilient remote operational capabilities.  We are seeing demand for simpler, more agile IT across multiple clouds.  The pandemic has accelerated the introduction and adoption of new technologies to ensure productivity and collaboration from anywhere.  In light of this rapid pace of innovation, we continue to invest in research and development, sales, and other key areas of our business to deliver superior products and solutions capabilities and to drive long-term sustainable growth.

[0001571996-21-000007:mdna:50]
ISG — We expect that ISG will continue to be impacted by the changing nature of the IT infrastructure market and competitive environment.  The overall server demand environment was down for Fiscal 2021 and continues to exhibit variability across international regions.  However, we expect ISG will benefit from forecasted improvements to the macroeconomic environment as we move through Fiscal 2022.  We will continue to be selective in determining whether to pursue certain large hyperscale and other server transactions as we drive for balanced growth and profitability.  With our scale and strong solutions portfolio, we believe we are well-positioned to respond to ongoing competitive dynamics.  We continue to focus on customer base expansion and lifetime value of customer relationships.

[0001571996-21-000007:mdna:51]
Cloud-native applications are expected to continue as a primary growth driver in the infrastructure market.  We believe the complementary cloud solutions across our business position us to meet these demands for our customers.  The unprecedented data growth throughout all industries is generating continued demand for our storage solutions and services.  We benefit by offering solutions that address the emerging trends of enterprises deploying software-defined storage, hyper-converged infrastructure, and modular solutions based on server-centric architectures.  These trends are changing the way customers are consuming our traditional storage offerings.  We continue to expand our offerings in external storage arrays, which incorporate flexible, cloud-based functionality.  Through our research and development efforts, we are developing new solutions in this rapidly changing industry that we believe will enable us to continue to provide superior solutions to our customers.

[0001571996-21-000007:mdna:52]
CSG — Our CSG offerings are an important element of our strategy, generating strong cash flow and opportunities for cross-selling of complementary solutions.  During Fiscal 2021, CSG demand was strong in certain product lines, particularly for notebooks and gaming systems, while demand for commercial desktops decreased.  These demand dynamics were driven by the imperative for remote work and remote learning solutions, as business, government, and education customers sought to maintain productivity in the midst of COVID-19.  We continue to deploy Dell PC as-a-Service offerings for customers who are seeking simplified solutions and lifecycle management with predictable pricing through DFS.  We expect that the CSG demand environment will continue to be cyclical.

[0001571996-21-000007:mdna:53]
We anticipate continued strong CSG demand in Fiscal 2022, particularly in the first half of the fiscal year, in line with industry demand forecasts, although the cost environment will continue to fluctuate depending on supplier capacity and demand for certain components.  We remain committed to our long-term strategy for CSG and will continue to innovate across the portfolio, while benefiting from consolidation trends that are occurring in the markets in which we compete.  Competitive dynamics will continue to be a factor in our CSG business as we seek to balance profitability and growth.

[0001571996-21-000007:mdna:54]
Recurring Revenue and Consumption Models — Our customers are interested in new and innovative models that address how they consume our solutions.  We offer options that include as-a-service, utility, leases, and immediate pay models, all designed to match customers’ consumption and financing preferences.  Our multiyear agreements typically result in recurring revenue streams over the term of the arrangement.  During Fiscal 2021, we announced our intention to continue to evolve and expand our IT as-a-Service and cloud offerings through Apex.  We expect that our flexible consumption models and as-a-service offerings will further strengthen our customer relationships and provide a foundation for growth in recurring revenue.

[0001571996-21-000007:mdna:55]
Supply Chain — During Fiscal 2020, we recognized benefits to our CSG and ISG operating results from significant component cost declines.  During Fiscal 2021, component costs continued to decline in the aggregate, but at a lower rate than in Fiscal 2020.  We expect the deflationary trends in the overall component cost environment to taper off and then shift to inflationary during the first half of Fiscal 2022.  Component cost trends are dependent on the strength or weakness of actual end user demand and supply dynamics, which will continue to evolve and ultimately impact the translation of the cost environment to pricing and operating results.

[0001571996-21-000007:mdna:56]
Dell Technologies maintains limited-source supplier relationships for certain components, because the relationships are advantageous in the areas of performance, quality, support, delivery, capacity, and price considerations.  In recent periods, we have been impacted by component supply constraints in certain product offerings, some of which resulted from COVID-19 driven demand patterns.  Delays in the supply of limited-source components, including as a result of COVID-19, are affecting the timing of shipments of certain products in desired quantities or configurations.  Additionally, we have experienced increased freight costs for expedited shipments of components and rate increases in the freight network as air capacity remains constrained.  We expect elevated freight costs to continue to put pressure on operating results through the first half of Fiscal 2022.

[0001571996-21-000007:mdna:57]
Macroeconomic Risks and Uncertainties — The impacts of trade protection measures, including increases in tariffs and trade barriers, and changes in government policies and international trade arrangements may affect our ability to conduct business in some non-U.S. markets.  We monitor and seek to mitigate these risks with adjustments to our manufacturing, supply chain, and distribution networks.

[0001571996-21-000007:mdna:58]
We manage our business on a U.S. dollar basis.  However, we have a large global presence, generating approximately half of our net revenue from sales to customers outside of the United States during Fiscal 2021, Fiscal 2020, and Fiscal 2019.  As a result, our revenue can be impacted by fluctuations in foreign currency exchange rates.  We utilize a comprehensive hedging strategy intended to mitigate the impact of foreign currency volatility over time, and we adjust pricing when possible to further minimize foreign currency impacts.

[0001571996-21-000007:mdna:59]
Key Performance Metrics

[0001571996-21-000007:mdna:60]
Our key performance metrics are net revenue, operating income, adjusted EBITDA, and cash flows from operations, which are discussed elsewhere in this management’s discussion and analysis.

[0001571996-21-000007:mdna:61]
Class V Transaction

[0001571996-21-000007:mdna:62]
On December 28, 2018, we completed a transaction (“Class V transaction”) in which we paid $14.0 billion in cash and issued 149,387,617 shares of our Class C Common Stock to holders of our Class V Common Stock in exchange for all outstanding shares of Class V Common Stock.  The non-cash consideration portion of the Class V transaction totaled $6.9 billion.  As a result of the Class V transaction, the tracking stock feature of Dell Technologies’ capital structure was terminated.  The Class C Common Stock is traded on the New York Stock Exchange.  See Note 1 of the Notes to the Consolidated Financial Statements included in this report for more information about the Class V transaction.

[0001571996-21-000007:mdna:63]
VMware, Inc. Ownership

[0001571996-21-000007:mdna:64]
On July 15, 2020, we announced that we are exploring potential alternatives with respect to our ownership in VMware, Inc., including a potential spin-off of that ownership interest to Dell Technologies’ stockholders.  Although this process is currently only at an exploratory stage, we believe a spin-off could benefit both Dell Technologies’ and VMware, Inc.’s stockholders by simplifying capital structures and enhancing strategic flexibility, while still maintaining a mutually beneficial strategic and commercial partnership.  Any potential spin-off would not occur prior to September 2021.  Other strategic options include maintaining the status quo with respect to our ownership interest in VMware, Inc.

[0001571996-21-000007:mdna:65]
41

[0001571996-21-000007:mdna:66]
NON-GAAP FINANCIAL MEASURES

[0001571996-21-000007:mdna:67]
In this management’s discussion and analysis, we use supplemental measures of our performance which are derived from our consolidated financial information but which are not presented in our consolidated financial statements prepared in accordance with GAAP.  These non-GAAP financial measures include non-GAAP product net revenue; non-GAAP services net revenue; non-GAAP net revenue; non-GAAP product gross margin; non-GAAP services gross margin; non-GAAP gross margin; non-GAAP operating expenses; non-GAAP operating income; non-GAAP net income; earnings before interest and other, net, taxes, depreciation, and amortization (“EBITDA”); and adjusted EBITDA.

[0001571996-21-000007:mdna:68]
We use non-GAAP financial measures to supplement financial information presented on a GAAP basis.  Management considers these non-GAAP measures in evaluating our operating trends and performance.  Moreover, we believe these non-GAAP financial measures provide our stakeholders with useful and transparent information to help them evaluate our operating results by facilitating an enhanced understanding of our operating performance and enabling them to make more meaningful period to period comparisons.  There are limitations to the use of the non-GAAP financial measures presented in this report.  Our non-GAAP financial measures may not be comparable to similarly titled measures of other companies.  Other companies, including companies in our industry, may calculate non-GAAP financial measures differently than we do, limiting the usefulness of those measures for comparative purposes.

[0001571996-21-000007:mdna:69]
Non-GAAP product net revenue, non-GAAP services net revenue, non-GAAP net revenue, non-GAAP product gross margin, non-GAAP services gross margin, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, and non-GAAP net income, as defined by us, exclude amortization of intangible assets, the impact of purchase accounting, transaction-related expenses, stock-based compensation expense, other corporate expenses and, for non-GAAP net income, fair value adjustments on equity adjustments and an aggregate adjustment for income taxes.  As the excluded items have a material impact on our financial results, our management compensates for this limitation by relying primarily on our GAAP results and using non-GAAP financial measures supplementally or for projections when comparable GAAP financial measures are not available.  The non-GAAP financial measures are not meant to be considered as indicators of performance in isolation from or as a substitute for net revenue, gross margin, operating expenses, operating income, or net income prepared in accordance with GAAP, and should be read only in conjunction with financial information presented on a GAAP basis.

[0001571996-21-000007:mdna:70]
Reconciliations of each non-GAAP financial measure to its most directly comparable GAAP financial measure are presented below.  We encourage you to review the reconciliations in conjunction with the presentation of the non-GAAP financial measures for each of the periods presented.  The discussion below includes information on each of the excluded items as well as our reasons for excluding them from our non-GAAP results.  In future fiscal periods, we may exclude such items and may incur income and expenses similar to these excluded items.  Accordingly, the exclusion of these items and other similar items in our non-GAAP presentation should not be interpreted as implying that these items are non-recurring, infrequent, or unusual.

[0001571996-21-000007:mdna:71]
The following is a summary of the items excluded from the most comparable GAAP financial measures to calculate our non-GAAP financial measures:

[0001571996-21-000007:mdna:72]
•Amortization of Intangible Assets — Amortization of intangible assets primarily consists of amortization of customer relationships, developed technology, and trade names.  In connection with our acquisition by merger of EMC on September 7, 2016, referred to as the EMC merger transaction, and the acquisition of Dell Inc. by Dell Technologies Inc. on October 29, 2013, referred to as the going-private transaction, all of the tangible and intangible assets and liabilities of EMC and Dell, respectively, were accounted for and recognized at fair value on the transaction dates.  Accordingly, for the periods presented, amortization of intangible assets represents amortization associated with intangible assets recognized in connection with the EMC merger transaction and the going-private transaction.  Amortization charges for purchased intangible assets are significantly impacted by the timing and magnitude of our acquisitions, and these charges may vary in amount from period to period.  We exclude these charges for purposes of calculating the non-GAAP financial measures presented below to facilitate a more meaningful evaluation of our current operating performance and comparisons to our past operating performance.

[0001571996-21-000007:mdna:73]
•Impact of Purchase Accounting — The impact of purchase accounting includes purchase accounting adjustments related to the EMC merger transaction and, to a lesser extent, the going-private transaction, recorded under the acquisition method of accounting in accordance with the accounting guidance for business combinations.  This guidance prescribes that the purchase price be allocated to assets acquired and liabilities assumed based on the estimated fair value of such assets and liabilities on the date of the transaction.  Accordingly, all of the assets and liabilities acquired in the EMC merger transaction and the going-private transaction were accounted for and recognized at fair value as of the respective transaction dates, and the fair value adjustments are being amortized over the estimated useful lives in the periods following the transactions.  The fair value adjustments primarily relate to deferred revenue, inventory, and property, plant, and equipment.  Although purchase accounting adjustments and related amortization of those adjustments are reflected in our GAAP results, we evaluate the operating results of the underlying businesses on a non-GAAP basis, after removing such adjustments.  We believe that excluding the impact of purchase accounting provides results that are useful in understanding our current operating performance and provides more meaningful comparisons to our past operating performance.

[0001571996-21-000007:mdna:74]
•Transaction-related Expenses — Transaction-related expenses typically consist of acquisition, integration, and divestiture related costs, as well as the costs incurred in the Class V transaction, and are expensed as incurred.  These expenses primarily represent costs for legal, banking, consulting, and advisory services.  From time to time, this category also may include transaction-related gains on divestitures of businesses or asset sales.  During Fiscal 2021, we recognized a gain of $120 million on the sale of certain intellectual property assets and a pre-tax gain of $338 million on the sale of RSA Security.  During Fiscal 2020, transaction expenses included various acquisition costs that primarily consisted of costs of VMware, Inc.’s acquisitions of Carbon Black and Pivotal.  During Fiscal 2019, we incurred expenses of approximately $316 million for the completion of the Class V transaction, approximately $116 million for customer evaluation units, and approximately $100 million for manufacturing and engineering inventory.  We exclude these items for purposes of calculating the non-GAAP financial measures presented below to facilitate a more meaningful evaluation of our current operating performance and comparisons to our past operating performance.

[0001571996-21-000007:mdna:75]
•Stock-based Compensation Expense — Stock-based compensation expense consists of equity awards granted based on the estimated fair value of those awards at grant date.  We estimate the fair value of service-based stock options using the Black-Scholes valuation model.  To estimate the fair value of performance-based awards containing a market condition, we use the Monte Carlo valuation model.  For all other share-based awards, the fair value is based on the closing price of the Class C Common Stock as reported on the NYSE on the date of grant.  Although stock-based compensation is an important aspect of the compensation of our employees and executives, the fair value of the stock-based awards may bear little resemblance to the actual value realized upon the vesting or future exercise of the related stock-based awards.  We believe that excluding stock-based compensation expense for purposes of calculating the non-GAAP financial measures presented below facilitates a more meaningful evaluation of our current operating performance and comparisons to our past operating performance.  See Note 16 of the Notes to the Consolidated Financial Statements included in this report for additional information on equity award issuances.

[0001571996-21-000007:mdna:76]
•Other Corporate Expenses — Other corporate expenses consist of impairment charges, severance, facility action, and other costs.  Virtustream non-cash pre-tax asset impairment charges of $619 million and $190 million were recognized in Fiscal 2020 and Fiscal 2019, respectively.  This category also includes the derecognition of a $237 million previously accrued litigation loss as a result of a jury verdict in January 2020 against VMware, Inc. in a patent litigation matter.  In December 2020, the United States District Court of the District of Delaware set aside the jury verdict and ordered a new trial.  See Note 10 of the Notes to the Consolidated Financial Statements included in this report for more information about this patent litigation matter.  Severance costs are primarily related to severance and benefits for employees terminated pursuant to cost savings initiatives.  We continue to integrate owned and leased facilities and may incur additional costs as we seek opportunities for operational efficiencies.  Other corporate expenses vary from period to period and are significantly impacted by the timing and nature of these events.  Therefore, although we may incur these types of expenses in the future, we believe that eliminating these charges for purposes of calculating the non-GAAP financial measures presented below facilitates a more meaningful evaluation of our current operating performance and comparisons to our past operating performance.

[0001571996-21-000007:mdna:77]
43

[0001571996-21-000007:mdna:78]
•Fair Value Adjustments on Equity Investments — Fair value adjustments on equity investments primarily consists of the gain (loss) on strategic investments, which includes the recurring fair value adjustments of investments in publicly-traded companies, as well as those in privately-held companies, which are adjusted for observable price changes, and to a lesser extent, any potential impairments.  During Fiscal 2021, this category included an unrealized net gain of $396 million related to one of our strategic investments.  See Note 3 of the Notes to the Consolidated Financial Statements included in this report for additional information on our strategic investment activity.  Given the volatility in the ongoing adjustments to the valuation of these strategic investments, we believe that excluding these gains and losses for purposes of calculating non-GAAP net income presented below facilitates a more meaningful evaluation of our current operating performance and comparisons to our past operating performance.

[0001571996-21-000007:mdna:79]
•Aggregate Adjustment for Income Taxes — The aggregate adjustment for income taxes is the estimated combined income tax effect for the adjustments described above, as well as an adjustment for discrete tax items.  Due to the variability in recognition of discrete tax items from period to period, we believe that excluding these benefits or charges for purposes of calculating non-GAAP net income facilitates a more meaningful evaluation of our current operating performance and comparisons to our past operating performance.  The tax effects are determined based on the tax jurisdictions where the above items were incurred.  See Note 11 of the Notes to the Consolidated Financial Statements included in this report for additional information on our income taxes.

[0001571996-21-000007:mdna:80]
The following table presents a reconciliation of each non-GAAP financial measure to the most directly comparable GAAP measure for the periods indicated:

[0001571996-21-000007:mdna:81]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  |  |  | January 29,2021 |  | % Change |  | January 31,2020 |  | % Change |  | February 1,2019 |
|  |  |  |  |  |  |  | (in millions, except percentages) |
| Product net revenue |  |  |  |  |  |  | $ | 69,911 |  |  | — | % |  | $ | 69,918 |  |  | (1) | % |  | $ | 70,707 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting |  |  |  |  |  |  | 8 |  |  |  |  | 19 |  |  |  |  | 61 |  |
| Non-GAAP product net revenue |  |  |  |  |  |  | $ | 69,919 |  |  | — | % |  | $ | 69,937 |  |  | (1) | % |  | $ | 70,768 |  |
| Services net revenue |  |  |  |  |  |  | $ | 24,313 |  |  | 9 | % |  | $ | 22,236 |  |  | 12 | % |  | $ | 19,914 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting |  |  |  |  |  |  | 157 |  |  |  |  | 328 |  |  |  |  | 642 |  |
| Non-GAAP services net revenue |  |  |  |  |  |  | $ | 24,470 |  |  | 8 | % |  | $ | 22,564 |  |  | 10 | % |  | $ | 20,556 |  |
| Net revenue |  |  |  |  |  |  | $ | 94,224 |  |  | 2 | % |  | $ | 92,154 |  |  | 2 | % |  | $ | 90,621 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting |  |  |  |  |  |  | 165 |  |  |  |  | 347 |  |  |  |  | 703 |  |
| Non-GAAP net revenue |  |  |  |  |  |  | $ | 94,389 |  |  | 2 | % |  | $ | 92,501 |  |  | 1 | % |  | $ | 91,324 |  |
| Product gross margin |  |  |  |  |  |  | $ | 14,564 |  |  | (5) | % |  | $ | 15,393 |  |  | 20 | % |  | $ | 12,818 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles |  |  |  |  |  |  | 1,503 |  |  |  |  | 2,081 |  |  |  |  | 2,883 |  |
| Impact of purchase accounting |  |  |  |  |  |  | 14 |  |  |  |  | 28 |  |  |  |  | 78 |  |
| Transaction-related (income) expenses |  |  |  |  |  |  | — |  |  |  |  | (5) |  |  |  |  | 210 |  |
| Stock-based compensation expense |  |  |  |  |  |  | 24 |  |  |  |  | 10 |  |  |  |  | 27 |  |
| Other corporate expenses |  |  |  |  |  |  | 17 |  |  |  |  | 16 |  |  |  |  | 5 |  |
| Non-GAAP product gross margin |  |  |  |  |  |  | $ | 16,122 |  |  | (8) | % |  | $ | 17,523 |  |  | 9 | % |  | $ | 16,021 |  |
| Services gross margin |  |  |  |  |  |  | $ | 14,853 |  |  | 10 | % |  | $ | 13,540 |  |  | 11 | % |  | $ | 12,235 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles |  |  |  |  |  |  | (1) |  |  |  |  | — |  |  |  |  | — |  |
| Impact of purchase accounting |  |  |  |  |  |  | 157 |  |  |  |  | 325 |  |  |  |  | 642 |  |
| Transaction-related expenses |  |  |  |  |  |  | — |  |  |  |  | — |  |  |  |  | 3 |  |
| Stock-based compensation expense |  |  |  |  |  |  | 170 |  |  |  |  | 119 |  |  |  |  | 64 |  |
| Other corporate expenses |  |  |  |  |  |  | 45 |  |  |  |  | 56 |  |  |  |  | 57 |  |
| Non-GAAP services gross margin |  |  |  |  |  |  | $ | 15,224 |  |  | 8 | % |  | $ | 14,040 |  |  | 8 | % |  | $ | 13,001 |  |

[0001571996-21-000007:mdna:82]
45

[0001571996-21-000007:mdna:83]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  |  |  | January 29,2021 |  | % Change |  | January 31,2020 |  | % Change |  | February 1,2019 |
|  |  |  |  |  |  |  | (in millions, except percentages) |
| Gross margin |  |  |  |  |  |  | $ | 29,417 |  |  | 2 | % |  | $ | 28,933 |  |  | 15 | % |  | $ | 25,053 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles |  |  |  |  |  |  | 1,502 |  |  |  |  | 2,081 |  |  |  |  | 2,883 |  |
| Impact of purchase accounting |  |  |  |  |  |  | 171 |  |  |  |  | 353 |  |  |  |  | 720 |  |
| Transaction-related (income) expenses |  |  |  |  |  |  | — |  |  |  |  | (5) |  |  |  |  | 213 |  |
| Stock-based compensation expense |  |  |  |  |  |  | 194 |  |  |  |  | 129 |  |  |  |  | 91 |  |
| Other corporate expenses |  |  |  |  |  |  | 62 |  |  |  |  | 72 |  |  |  |  | 62 |  |
| Non-GAAP gross margin |  |  |  |  |  |  | $ | 31,346 |  |  | (1) | % |  | $ | 31,563 |  |  | 9 | % |  | $ | 29,022 |  |
| Operating expenses |  |  |  |  |  |  | $ | 24,273 |  |  | (8) | % |  | $ | 26,311 |  |  | 4 | % |  | $ | 25,244 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles |  |  |  |  |  |  | (1,891) |  |  |  |  | (2,327) |  |  |  |  | (3,255) |  |
| Impact of purchase accounting |  |  |  |  |  |  | (42) |  |  |  |  | (58) |  |  |  |  | (100) |  |
| Transaction-related expenses |  |  |  |  |  |  | (257) |  |  |  |  | (290) |  |  |  |  | (537) |  |
| Stock-based compensation expense |  |  |  |  |  |  | (1,415) |  |  |  |  | (1,133) |  |  |  |  | (827) |  |
| Other corporate expenses |  |  |  |  |  |  | (120) |  |  |  |  | (1,088) |  |  |  |  | (357) |  |
| Non-GAAP operating expenses |  |  |  |  |  |  | $ | 20,548 |  |  | (4) | % |  | $ | 21,415 |  |  | 6 | % |  | $ | 20,168 |  |
| Operating income |  |  |  |  |  |  | $ | 5,144 |  |  | 96 | % |  | $ | 2,622 |  |  | NM |  | $ | (191) |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles |  |  |  |  |  |  | 3,393 |  |  |  |  | 4,408 |  |  |  |  | 6,138 |  |
| Impact of purchase accounting |  |  |  |  |  |  | 213 |  |  |  |  | 411 |  |  |  |  | 820 |  |
| Transaction-related expenses |  |  |  |  |  |  | 257 |  |  |  |  | 285 |  |  |  |  | 750 |  |
| Stock-based compensation expense |  |  |  |  |  |  | 1,609 |  |  |  |  | 1,262 |  |  |  |  | 918 |  |
| Other corporate expenses |  |  |  |  |  |  | 182 |  |  |  |  | 1,160 |  |  |  |  | 419 |  |
| Non-GAAP operating income |  |  |  |  |  |  | $ | 10,798 |  |  | 6 | % |  | $ | 10,148 |  |  | 15 | % |  | $ | 8,854 |  |
| Net income (loss) |  |  |  |  |  |  | $ | 3,505 |  |  | (37) | % |  | $ | 5,529 |  |  | 354 | % |  | $ | (2,181) |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles |  |  |  |  |  |  | 3,393 |  |  |  |  | 4,408 |  |  |  |  | 6,138 |  |
| Impact of purchase accounting |  |  |  |  |  |  | 213 |  |  |  |  | 411 |  |  |  |  | 820 |  |
| Transaction-related (income) expenses |  |  |  |  |  |  | (201) |  |  |  |  | 285 |  |  |  |  | 824 |  |
| Stock-based compensation expense |  |  |  |  |  |  | 1,609 |  |  |  |  | 1,262 |  |  |  |  | 918 |  |
| Other corporate expenses |  |  |  |  |  |  | 74 |  |  |  |  | 1,160 |  |  |  |  | 419 |  |
| Fair value adjustments on equity investments |  |  |  |  |  |  | (582) |  |  |  |  | (194) |  |  |  |  | (342) |  |
| Aggregate adjustment for income taxes |  |  |  |  |  |  | (1,248) |  |  |  |  | (6,772) |  |  |  |  | (1,369) |  |
| Non-GAAP net income |  |  |  |  |  |  | $ | 6,763 |  |  | 11 | % |  | $ | 6,089 |  |  | 16 | % |  | $ | 5,227 |  |

[0001571996-21-000007:mdna:84]
____________________

[0001571996-21-000007:mdna:85]
NM Not meaningful

[0001571996-21-000007:mdna:86]
46

[0001571996-21-000007:mdna:87]
In addition to the above measures, we also use EBITDA and adjusted EBITDA to provide additional information for evaluation of our operating performance.  Adjusted EBITDA excludes purchase accounting adjustments related to the EMC merger transaction and the going-private transaction, acquisition, integration, and divestiture related costs, impairment charges, and severance, facility action, and other costs, and stock-based compensation expense.  We believe that, due to the non-operational nature of the purchase accounting entries, it is appropriate to exclude these adjustments.

[0001571996-21-000007:mdna:88]
As is the case with the non-GAAP measures presented above, users should consider the limitations of using EBITDA and adjusted EBITDA, including the fact that those measures do not provide a complete measure of our operating performance.  EBITDA and adjusted EBITDA do not purport to be alternatives to net income (loss) as measures of operating performance or to cash flows from operating activities as a measure of liquidity.  In particular, EBITDA and adjusted EBITDA are not intended to be a measure of free cash flow available for management’s discretionary use, as these measures do not consider certain cash requirements, such as working capital needs, capital expenditures, contractual commitments, interest payments, tax payments, and other debt service requirements.

[0001571996-21-000007:mdna:89]
The following table presents a reconciliation of EBITDA and adjusted EBITDA to net income (loss) for the periods indicated:

[0001571996-21-000007:mdna:90]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  |  |  | January 29,2021 |  | % Change |  | January 31,2020 |  | % Change |  | February 1,2019 |
|  |  |  |  |  |  |  | (in millions, except percentages) |
| Net income (loss) |  |  |  |  |  |  | $ | 3,505 |  |  | (37) | % |  | $ | 5,529 |  |  | 354 | % |  | $ | (2,181) |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest and other, net (a) |  |  |  |  |  |  | 1,474 |  |  |  |  | 2,626 |  |  |  |  | 2,170 |  |
| Income tax expense (benefit) (b) |  |  |  |  |  |  | 165 |  |  |  |  | (5,533) |  |  |  |  | (180) |  |
| Depreciation and amortization |  |  |  |  |  |  | 5,390 |  |  |  |  | 6,143 |  |  |  |  | 7,746 |  |
| EBITDA |  |  |  |  |  |  | $ | 10,534 |  |  | 20 | % |  | $ | 8,765 |  |  | 16 | % |  | $ | 7,555 |  |
| EBITDA |  |  |  |  |  |  | $ | 10,534 |  |  | 20 | % |  | $ | 8,765 |  |  | 16 | % |  | $ | 7,555 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense |  |  |  |  |  |  | 1,609 |  |  |  |  | 1,262 |  |  |  |  | 918 |  |
| Impact of purchase accounting (c) |  |  |  |  |  |  | 165 |  |  |  |  | 347 |  |  |  |  | 704 |  |
| Transaction-related expenses (d) |  |  |  |  |  |  | 257 |  |  |  |  | 285 |  |  |  |  | 722 |  |
| Other corporate expenses (e) |  |  |  |  |  |  | 182 |  |  |  |  | 1,128 |  |  |  |  | 397 |  |
| Adjusted EBITDA |  |  |  |  |  |  | $ | 12,747 |  |  | 8 | % |  | $ | 11,787 |  |  | 14 | % |  | $ | 10,296 |  |

[0001571996-21-000007:mdna:91]
____________________

[0001571996-21-000007:mdna:92]
(a)See “Results of Operations — Interest and Other, Net” for more information on the components of interest and other, net.

[0001571996-21-000007:mdna:93]
(b)See Note 11 of the Notes to the Consolidated Financial Statements included in this report for additional information on discrete tax items.

[0001571996-21-000007:mdna:94]
(c)This amount includes the non-cash purchase accounting adjustments related to the EMC merger transaction and the going-private transaction.

[0001571996-21-000007:mdna:95]
(d)Transaction-related expenses consist of acquisition, integration, and divestiture related costs, as well as the costs incurred in the Class V transaction.

[0001571996-21-000007:mdna:96]
(e)Other corporate expenses includes impairment charges, severance, facility action, and other costs.

[0001571996-21-000007:mdna:97]
RESULTS OF OPERATIONS

[0001571996-21-000007:mdna:98]
Consolidated Results

[0001571996-21-000007:mdna:99]
The following table summarizes our consolidated results for the periods indicated.  Unless otherwise indicated, all changes identified for the current period results represent comparisons to results for the prior corresponding fiscal period.

[0001571996-21-000007:mdna:100]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  |  |  | January 29, 2021 |  |  |  | January 31, 2020 |  |  |  | February 1, 2019 |
|  |  |  |  |  |  |  |  |  |  |  | Dollars |  | % ofNet Revenue |  | %Change |  | Dollars |  | % ofNet Revenue |  | %Change |  | Dollars |  | % ofNet Revenue |
|  |  |  |  |  |  |  |  |  |  |  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  |  |  |  |  |  |  |  |  |  | $ | 69,911 |  |  | 74.2 | % |  | — | % |  | $ | 69,918 |  |  | 75.9 | % |  | (1) | % |  | $ | 70,707 |  |  | 78.0 | % |
| Services |  |  |  |  |  |  |  |  |  |  | 24,313 |  |  | 25.8 | % |  | 9 | % |  | 22,236 |  |  | 24.1 | % |  | 12 | % |  | 19,914 |  |  | 22.0 | % |
| Total net revenue |  |  |  |  |  |  |  |  |  |  | $ | 94,224 |  |  | 100.0 | % |  | 2 | % |  | $ | 92,154 |  |  | 100.0 | % |  | 2 | % |  | $ | 90,621 |  |  | 100.0 | % |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products (a) |  |  |  |  |  |  |  |  |  |  | $ | 14,564 |  |  | 20.8 | % |  | (5) | % |  | $ | 15,393 |  |  | 22.0 | % |  | 20 | % |  | $ | 12,818 |  |  | 18.1 | % |
| Services (b) |  |  |  |  |  |  |  |  |  |  | 14,853 |  |  | 61.1 | % |  | 10 | % |  | 13,540 |  |  | 60.9 | % |  | 11 | % |  | 12,235 |  |  | 61.4 | % |
| Total gross margin |  |  |  |  |  |  |  |  |  |  | $ | 29,417 |  |  | 31.2 | % |  | 2 | % |  | $ | 28,933 |  |  | 31.4 | % |  | 15 | % |  | $ | 25,053 |  |  | 27.6 | % |
| Operating expenses |  |  |  |  |  |  |  |  |  |  | $ | 24,273 |  |  | 25.7 | % |  | (8) | % |  | $ | 26,311 |  |  | 28.6 | % |  | 4 | % |  | $ | 25,244 |  |  | 27.8 | % |
| Operating income (loss) |  |  |  |  |  |  |  |  |  |  | $ | 5,144 |  |  | 5.5 | % |  | 96 | % |  | $ | 2,622 |  |  | 2.8 | % |  | NM |  | $ | (191) |  |  | (0.2) | % |
| Net income (loss) |  |  |  |  |  |  |  |  |  |  | $ | 3,505 |  |  | 3.7 | % |  | (37) | % |  | $ | 5,529 |  |  | 6.0 | % |  | 354 | % |  | $ | (2,181) |  |  | (2.4) | % |
| Net income (loss) attributable to Dell Technologies Inc. |  |  |  |  |  |  |  |  |  |  | $ | 3,250 |  |  | 3.4 | % |  | (30) | % |  | $ | 4,616 |  |  | 5.0 | % |  | 300 | % |  | $ | (2,310) |  |  | (2.5) | % |
| Non-GAAP Information |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |  |  |  | Fiscal Year Ended |
|  |  |  |  |  |  |  |  |  |  |  | January 29, 2021 |  |  |  | January 31, 2020 |  |  |  | February 1, 2019 |
|  |  |  |  |  |  |  |  |  |  | Dollars |  | % of Non-GAAP Net Revenue |  | %Change |  | Dollars |  | % of Non-GAAP Net Revenue |  | %Change |  | Dollars |  | % of Non-GAAP Net Revenue |
|  |  |  |  |  |  |  |  |  |  |  | (in millions, except percentages) |
| Non-GAAP net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  |  |  |  |  |  |  |  |  |  | $ | 69,919 |  |  | 74.1 | % |  | — | % |  | $ | 69,937 |  |  | 75.6 | % |  | (1) | % |  | $ | 70,768 |  |  | 77.5 | % |
| Services |  |  |  |  |  |  |  |  |  |  | 24,470 |  |  | 25.9 | % |  | 8 | % |  | 22,564 |  |  | 24.4 | % |  | 10 | % |  | 20,556 |  |  | 22.5 | % |
| Total non-GAAP net revenue |  |  |  |  |  |  |  |  |  |  | $ | 94,389 |  |  | 100.0 | % |  | 2 | % |  | $ | 92,501 |  |  | 100.0 | % |  | 1 | % |  | $ | 91,324 |  |  | 100.0 | % |
| Non-GAAP gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products (a) |  |  |  |  |  |  |  |  |  |  | $ | 16,122 |  |  | 23.1 | % |  | (8) | % |  | $ | 17,523 |  |  | 25.1 | % |  | 9 | % |  | $ | 16,021 |  |  | 22.6 | % |
| Services (b) |  |  |  |  |  |  |  |  |  |  | 15,224 |  |  | 62.2 | % |  | 8 | % |  | 14,040 |  |  | 62.2 | % |  | 8 | % |  | 13,001 |  |  | 63.2 | % |
| Total non-GAAP gross margin |  |  |  |  |  |  |  |  |  |  | $ | 31,346 |  |  | 33.2 | % |  | (1) | % |  | $ | 31,563 |  |  | 34.1 | % |  | 9 | % |  | $ | 29,022 |  |  | 31.8 | % |
| Non-GAAP operating expenses |  |  |  |  |  |  |  |  |  |  | $ | 20,548 |  |  | 21.8 | % |  | (4) | % |  | $ | 21,415 |  |  | 23.2 | % |  | 6 | % |  | $ | 20,168 |  |  | 22.1 | % |
| Non-GAAP operating income |  |  |  |  |  |  |  |  |  |  | $ | 10,798 |  |  | 11.4 | % |  | 6 | % |  | $ | 10,148 |  |  | 11.0 | % |  | 15 | % |  | $ | 8,854 |  |  | 9.7 | % |
| Non-GAAP net income |  |  |  |  |  |  |  |  |  |  | $ | 6,763 |  |  | 7.2 | % |  | 11 | % |  | $ | 6,089 |  |  | 6.6 | % |  | 16 | % |  | $ | 5,227 |  |  | 5.7 | % |
| EBITDA |  |  |  |  |  |  |  |  |  |  | $ | 10,534 |  |  | 11.2 | % |  | 20 | % |  | $ | 8,765 |  |  | 9.5 | % |  | 16 | % |  | $ | 7,555 |  |  | 8.3 | % |
| Adjusted EBITDA |  |  |  |  |  |  |  |  |  |  | $ | 12,747 |  |  | 13.5 | % |  | 8 | % |  | $ | 11,787 |  |  | 12.7 | % |  | 14 | % |  | $ | 10,296 |  |  | 11.3 | % |

[0001571996-21-000007:mdna:101]
____________________

[0001571996-21-000007:mdna:102]
(a)Product gross margin percentages represent product gross margin as a percentage of product net revenue, and non-GAAP product gross margin percentages represent non-GAAP product gross margin as a percentage of non-GAAP product net revenue.

[0001571996-21-000007:mdna:103]
(b)Services gross margin percentages represent services gross margin as a percentage of services net revenue, and non-GAAP services gross margin percentages represent non-GAAP services gross margin as a percentage of non-GAAP services net revenue.

[0001571996-21-000007:mdna:104]
NM Not meaningful

[0001571996-21-000007:mdna:105]
Non-GAAP product net revenue, non-GAAP services net revenue, non-GAAP net revenue, non-GAAP product gross margin, non-GAAP services gross margin, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, EBITDA, and adjusted EBITDA are not measurements of financial performance prepared in accordance with GAAP.  Non-GAAP financial measures as a percentage of revenue are calculated based on non-GAAP net revenue.  See “Non‑GAAP Financial Measures” for additional information about these non-GAAP financial measures, including our reasons for including these measures, material limitations with respect to the usefulness of the measures, and a reconciliation of each non-GAAP financial measure to the most directly comparable GAAP financial measure.

[0001571996-21-000007:mdna:106]
Overview

[0001571996-21-000007:mdna:107]
During Fiscal 2021, our net revenue and non-GAAP net revenue both increased 2% as we benefited from the strength of our broad technology solutions portfolio, which helped us navigate market volatility and competitive pressures, particularly due to the COVID-19 environment.  The increases in net revenue and non-GAAP net revenue were attributable to increases in net revenue in CSG and VMware, which were partially offset by declines in ISG net revenue.  The increase in CSG net revenue was primarily driven by growth in consumer solutions and continued strong demand for commercial notebooks, partially offset by lower demand for commercial desktops.  VMware net revenue increased due to growth in sales of subscriptions and software-as-a-service offerings and software maintenance.  ISG net revenue decreased primarily due to a weaker demand environment as customers continued to direct their investments towards remote work and business continuity solutions.  Although we continue to experience some uncertainty as a result of the ongoing COVID-19 pandemic, we see opportunities to create value and grow in Fiscal 2022 in the midst of resilient demand for our IT solutions driven by a technology-enabled world.  We have demonstrated our ability to adjust as needed to changing market conditions with complementary solutions across all segments of our business, an agile workforce, and the strength of our global supply chain.  As we continue to innovate and modernize our core offerings, we believe Dell Technologies is well-positioned for long-term profitable growth.

[0001571996-21-000007:mdna:108]
During Fiscal 2021, our operating income increased 96% to $5.1 billion, primarily due to increases in net revenue and operating income for CSG and VMware.  Operating income during Fiscal 2021 also benefited from lower selling, general, and administrative expenses as we realized the benefit of cost reduction initiatives.  We also realized a decrease in amortization of intangible assets and other corporate expenses, most notably resulting from the absence of Virtustream impairment charges of $619 million recognized in Fiscal 2020 and the derecognition of a VMware, Inc. patent litigation accrual in Fiscal 2021 of $237 million, which was initially recognized in Fiscal 2020.  These benefits were partially offset by a decrease in operating income for ISG.

[0001571996-21-000007:mdna:109]
Amortization of intangible assets, stock-based compensation expense, and other corporate expenses that impacted operating income totaled $5.2 billion and $6.8 billion for Fiscal 2021 and Fiscal 2020, respectively.  Excluding these adjustments, and the impact of purchase accounting and transaction-related expenses, our non-GAAP operating income increased 6% to $10.8 billion during Fiscal 2021.  The increase in non-GAAP operating income for Fiscal 2021 was due to increases in net revenue and operating income for CSG and VMware, which were partially offset by a decrease in operating income for ISG.

[0001571996-21-000007:mdna:110]
Cash provided by operating activities was $11.4 billion and $9.3 billion during Fiscal 2021 and Fiscal 2020, respectively.  Our record cash flow from operations in Fiscal 2021 was due to strong profitability, revenue growth, and working capital dynamics.  COVID-19 impacts to working capital normalized by the end of Fiscal 2021.  See “Market Conditions, Liquidity, Capital Commitments, and Contractual Cash Obligations” for further information on our cash flow metrics.

[0001571996-21-000007:mdna:111]
Net Revenue

[0001571996-21-000007:mdna:112]
During Fiscal 2021, our net revenue and non-GAAP net revenue both increased 2%.  The increases in net revenue and non-GAAP net revenue were primarily attributable to increases in net revenue for CSG and VMware, which were partially offset by declines in ISG net revenue.  See “Business Unit Results” for further information.

[0001571996-21-000007:mdna:113]
•Product Net Revenue — Product net revenue includes revenue from the sale of hardware products and software licenses.  During Fiscal 2021, both product net revenue and non-GAAP product net revenue remained flat, primarily due to a decrease in product net revenue for ISG, which was offset by an increase in product net revenue for CSG.

[0001571996-21-000007:mdna:114]
•Services Net Revenue — Services net revenue includes revenue from our services offerings and support services related to hardware products and software licenses.  During Fiscal 2021, services net revenue and non-GAAP services net revenue increased 9% and 8%, respectively.  These increases were primarily attributable to increases in services net revenue for CSG third-party software and maintenance and VMware software, in particular, increases in subscription-based licenses.  A

[0001571996-21-000007:mdna:115]
substantial portion of services net revenue is derived from offerings that have been deferred over a period of time, and, as a result, reported services net revenue growth rates will be different than reported product net revenue growth rates.

[0001571996-21-000007:mdna:116]
From a geographical perspective, net revenue generated by sales to customers in the Americas and EMEA both increased during Fiscal 2021 due to strong CSG performance.  These increases were partially offset by declines in net revenue generated by sales to customers in APJ as a result of a weaker demand environment.

[0001571996-21-000007:mdna:117]
Gross Margin

[0001571996-21-000007:mdna:118]
During Fiscal 2021, our gross margin increased 2% to $29.4 billion, as the favorable impact of a gross margin increase for VMware and a decrease in amortization of intangible assets were partially offset by gross margin decreases for ISG and other businesses.  The decline in gross margin of other businesses was driven by the divestiture of RSA Security on September 1, 2020.

[0001571996-21-000007:mdna:119]
During Fiscal 2021, our gross margin percentage decreased 20 basis points to 31.2%, as a result of a shift in product mix due to strong CSG sales, as well as decreases in gross margin percentages for ISG and CSG.  The decline was partially offset by a decrease in amortization of intangible assets.

[0001571996-21-000007:mdna:120]
Our gross margin for Fiscal 2021 and Fiscal 2020 included the impact of amortization of intangibles and purchase accounting adjustments of $1.7 billion and $2.4 billion, respectively.  Excluding these costs, and transaction-related expenses, stock-based compensation expense, and other corporate expenses, non-GAAP gross margin for Fiscal 2021 decreased 1% to $31.3 billion.  The decrease in our non-GAAP gross margin due to gross margin decreases for ISG and other businesses was partially offset by a gross margin increase for VMware.  The decline in gross margin of other businesses was driven by the divestiture of RSA Security.

[0001571996-21-000007:mdna:121]
Non-GAAP gross margin percentage decreased 90 basis points to 33.2%.  The decrease in our non-GAAP gross margin percentage was attributable to a shift in product mix due to strong CSG sales, as well as decreases in gross margin percentages for ISG and CSG.

[0001571996-21-000007:mdna:122]
•Products — During Fiscal 2021, product gross margin decreased 5% to $14.6 billion and non-GAAP product gross margin decreased 8% to $16.1 billion.  The decreases in product gross margin and non-GAAP product gross margin were primarily driven by a shift in product mix due to strong CSG sales, as well as a decrease in ISG product net revenue.  These unfavorable impacts to product net revenue were partially offset by a decrease in amortization of intangibles.

[0001571996-21-000007:mdna:123]
During Fiscal 2021, product gross margin percentage decreased 120 basis points to 20.8% and non-GAAP product gross margin percentage decreased 200 basis points to 23.1%.  The decreases in product gross margin percentage and non-GAAP product gross margin percentage were attributable to a shift in product mix due to strong CSG sales, as well as decreases in product gross margin percentages for ISG and CSG.

[0001571996-21-000007:mdna:124]
•Services — During Fiscal 2021, services gross margin increased 10% to $14.9 billion primarily due to growth in VMware software maintenance.  Services gross margin also benefited from growth in CSG third-party software and maintenance, in particular, from an increase in subscription-based licenses, as well as from a decrease in purchase accounting adjustments.  Excluding purchase accounting adjustments, transaction-related expenses, stock-based compensation expense, and other corporate expenses, non-GAAP services gross margin increased 8% to $15.2 billion as a result of the same CSG and VMware growth drivers discussed above.

[0001571996-21-000007:mdna:125]
Services gross margin percentage increased 20 basis points to 61.1%  primarily due to the favorable impact of a decrease in purchase accounting and an increase in VMware services gross margin percentage.  These favorable impacts were partially offset by a decrease in CSG services gross margin percentage due to a product mix shift within CSG to entry-level commercial notebooks.  Non-GAAP services gross margin percentage remained flat at 62.2% primarily due to an increase in VMware services gross margin percentage, offset by a decrease in CSG services gross margin percentage.

[0001571996-21-000007:mdna:126]
Vendor Programs and Settlements

[0001571996-21-000007:mdna:127]
Our gross margin is affected by our ability to achieve competitive pricing with our vendors and contract manufacturers, including through our negotiation of a variety of vendor rebate programs to achieve lower net costs for the various components we include in our products.  Under these programs, vendors provide us with rebates or other discounts from the list prices for the components, which are generally elements of their pricing strategy.  We account for vendor rebates and other discounts as a reduction in cost of net revenue.  We manage our costs on a total net cost basis, which includes supplier list prices reduced by vendor rebates and other discounts.

[0001571996-21-000007:mdna:128]
The terms and conditions of our vendor rebate programs are largely based on product volumes and are generally negotiated either at the beginning of the annual or quarterly period, depending on the program.  The timing and amount of vendor rebates and other discounts we receive under the programs may vary from period to period, reflecting changes in the competitive environment.  We monitor our component costs and seek to address the effects of any changes to terms that might arise under our vendor rebate programs.  Our gross margins for Fiscal 2021, Fiscal 2020, and Fiscal 2019 were not materially affected by any changes to the terms of our vendor rebate programs, as the amounts we received under these programs were generally stable relative to our total net cost.  We are not aware of any significant changes to vendor pricing or rebate programs that may impact our results in the near term.

[0001571996-21-000007:mdna:129]
Operating Expenses

[0001571996-21-000007:mdna:130]
The following table presents information regarding our operating expenses for the periods indicated:

[0001571996-21-000007:mdna:131]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  |  |  | January 29, 2021 |  |  |  | January 31, 2020 |  |  |  | February 1, 2019 |
|  |  |  |  |  |  |  |  |  |  |  | Dollars |  | % ofNet Revenue |  | %Change |  | Dollars |  | % ofNet Revenue |  | %Change |  | Dollars |  | % ofNet Revenue |
|  |  |  |  |  |  |  |  |  |  |  | (in millions, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative |  |  |  |  |  |  |  |  |  |  | $ | 18,998 |  |  | 20.1 | % |  | (11) | % |  | $ | 21,319 |  |  | 23.2 | % |  | 3 | % |  | $ | 20,640 |  |  | 22.7 | % |
| Research and development |  |  |  |  |  |  |  |  |  |  | 5,275 |  |  | 5.6 | % |  | 6 | % |  | 4,992 |  |  | 5.4 | % |  | 8 | % |  | 4,604 |  |  | 5.1 | % |
| Total operating expenses |  |  |  |  |  |  |  |  |  |  | $ | 24,273 |  |  | 25.7 | % |  | (8) | % |  | $ | 26,311 |  |  | 28.6 | % |  | 4 | % |  | $ | 25,244 |  |  | 27.8 | % |
|  |  |  |  |  |  |  |  |  |  |  | Fiscal Year Ended |
|  |  |  |  |  |  |  |  |  |  |  | January 29, 2021 |  |  |  | January 31, 2020 |  |  |  | February 1, 2019 |
|  |  |  |  |  |  |  |  |  |  |  | Dollars |  | % of Non-GAAP Net Revenue |  | %Change |  | Dollars |  | % of Non-GAAP Net Revenue |  | %Change |  | Dollars |  | % of Non-GAAP Net Revenue |
|  |  |  |  |  |  |  |  |  |  | (in millions, except percentages) |
| Non-GAAP operating expenses |  |  |  |  |  |  |  |  |  |  | $ | 20,548 |  |  | 21.8 | % |  | (4) | % |  | $ | 21,415 |  |  | 23.2 | % |  | 6 | % |  | $ | 20,168 |  |  | 22.1 | % |

[0001571996-21-000007:mdna:132]
During Fiscal 2021, total operating expenses decreased 8% primarily due to a decrease in selling, general, and administrative expenses, partially offset by an increase in research and development expenses.  Our operating expenses include the impact of purchase accounting, amortization of intangible assets, transaction-related expenses, stock-based compensation expense, and other corporate expenses.  In aggregate, these items totaled $3.7 billion and $4.9 billion in Fiscal 2021 and Fiscal 2020, respectively.  Excluding these costs, total non-GAAP operating expenses decreased 4% for Fiscal 2021.

[0001571996-21-000007:mdna:133]
•Selling, General, and Administrative — Selling, general, and administrative (“SG&A”) expenses decreased 11% during Fiscal 2021.  The decrease in SG&A expenses was partly attributable to measures taken as a result of the COVID-19 pandemic, which included global hiring limitations, reductions in consulting and contractor costs and facilities-related costs, global travel restrictions, and suspension of the Dell 401(k) match program for U.S. employees, as well as a decrease in amortization of intangible assets.  Additionally during Fiscal 2021, SG&A expenses benefited from the absence of Virtustream pre-tax impairment charges of $619 million recognized in Fiscal 2020 and from the derecognition of a VMware, Inc. patent litigation accrual in Fiscal 2021 of $237 million, which was initially recognized in Fiscal 2020.

[0001571996-21-000007:mdna:134]
Effective January 1, 2021, the Dell 401(k) match program for U.S. employees was reinstated.  We expect that operating expenses will increase in Fiscal 2022 as we reinstate selected employee-related compensation benefits.  We continue to  invest in long-term projects, while focusing on operating expense controls in certain areas of the business.

[0001571996-21-000007:mdna:135]
•Research and Development — Research and development (“R&D”) expenses are primarily composed of personnel-related expenses related to product development.  R&D expenses as a percentage of net revenue for Fiscal 2021 and Fiscal 2020 were approximately 5.6% and 5.4%, respectively.  R&D expenses as a percentage of net revenue increased during Fiscal 2021 primarily due to an increase in compensation-related expense, including stock-based compensation expense, driven by VMware.  As our industry continues to change and as the needs of our customers evolve, we intend to support R&D initiatives to innovate and introduce new and enhanced solutions into the market.

[0001571996-21-000007:mdna:136]
We continue to make selective investments designed to enable growth, marketing, and R&D, while balancing our efforts to drive cost efficiencies in the business.  We also expect to continue to make investments in support of our own digital transformation to modernize and streamline our IT operations.

[0001571996-21-000007:mdna:137]
Operating Income

[0001571996-21-000007:mdna:138]
During Fiscal 2021, our operating income increased 96% to $5.1 billion, primarily due to increases in net revenue and operating income for CSG and VMware.  Operating income during Fiscal 2021 also benefited from lower selling, general, and administrative expenses as we realized the benefit of cost reduction initiatives.  We also realized a decrease in amortization of intangible assets and other corporate expenses, most notably resulting from the absence of Virtustream impairment charges of $619 million recognized in Fiscal 2020 and the derecognition of a VMware, Inc. patent litigation accrual in Fiscal 2021 of $237 million, which was initially recognized in Fiscal 2020.  These benefits were partially offset by a decrease in operating income for ISG.

[0001571996-21-000007:mdna:139]
In the fourth quarter of Fiscal 2021, we began to reinstate selected employee-related compensation benefits, which we expect will put pressure on operating income in Fiscal 2022.  We will continue to invest in long-term projects, while focusing on operating expense controls in certain areas of the business.

[0001571996-21-000007:mdna:140]
Amortization of intangible assets, stock-based compensation expense, and other corporate expenses that impacted operating income totaled $5.2 billion and $6.8 billion for Fiscal 2021 and Fiscal 2020, respectively.  Excluding these adjustments, and the impact of purchase accounting and transaction-related expenses, our non-GAAP operating income increased 6% to $10.8 billion during Fiscal 2021.  The increase in non-GAAP operating income for Fiscal 2021 was due to increases in net revenue and operating income for CSG and VMware, which were partially offset by a decrease in operating income for ISG.

[0001571996-21-000007:mdna:141]
Interest and Other, Net

[0001571996-21-000007:mdna:142]
The following table presents information regarding interest and other, net for the periods indicated:

[0001571996-21-000007:mdna:143]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  | January 29, 2021 |  | January 31, 2020 |  | February 1, 2019 |
|  |  |  |  |  | (in millions) |
| Interest and other, net: |  |  |  |  |  |  |  |  |  |
| Investment income, primarily interest |  |  |  |  | $ | 54 |  |  | $ | 160 |  |  | $ | 313 |  |
| Gain on strategic investments, net |  |  |  |  | 582 |  |  | 194 |  |  | 342 |  |
| Interest expense |  |  |  |  | (2,389) |  |  | (2,675) |  |  | (2,488) |  |
| Foreign exchange |  |  |  |  | (127) |  |  | (162) |  |  | (206) |  |
| Other |  |  |  |  | 406 |  |  | (143) |  |  | (131) |  |
| Total interest and other, net |  |  |  |  | $ | (1,474) |  |  | $ | (2,626) |  |  | $ | (2,170) |  |

[0001571996-21-000007:mdna:144]
During Fiscal 2021, the change in interest and other, net was favorable by $1,152 million, primarily due to a $396 million net gain on the fair value adjustment of one of our strategic investments and a pre-tax gain of $338 million on the sale of RSA Security reflected in Other in the table above.  Interest and other, net also benefited from a decrease in interest expense due to debt paydowns over the periods and a gain of $120 million recognized from the sale of certain intellectual property assets.

[0001571996-21-000007:mdna:145]
52

[0001571996-21-000007:mdna:146]
Income and Other Taxes

[0001571996-21-000007:mdna:147]
The following table presents information regarding our income and other taxes for the periods indicated:

[0001571996-21-000007:mdna:148]
|  | Fiscal Year Ended |
|  | January 29, 2021 |  | January 31, 2020 |  | February 1, 2019 |
|  | (in millions, except percentages) |
| Income (loss) before income taxes | $ | 3,670 |  |  | $ | (4) |  |  | $ | (2,361) |  |
| Income tax expense (benefit) | $ | 165 |  |  | $ | (5,533) |  |  | $ | (180) |  |
| Effective income tax rate | 4.5 | % |  | 138325.0 | % |  | 7.6 | % |

[0001571996-21-000007:mdna:149]
For Fiscal 2021 and Fiscal 2020, our effective income tax rates were 4.5% on pre-tax income of $3,670 million and 138325.0% on pre-tax losses of $4 million, respectively.  The change in our effective income tax rate was primarily driven by discrete tax items and a change in our jurisdictional mix of income.

[0001571996-21-000007:mdna:150]
For Fiscal 2021, our effective income tax rate includes discrete tax benefits of $746 million related to an audit settlement, $159 million related to stock-based compensation, and $59 million from an intra-entity asset transfer of certain of Pivotal’s intellectual property to an Irish subsidiary that was completed by VMware, Inc.  Our effective income tax rate also includes discrete tax expense of $359 million related to the divestiture of RSA Security during Fiscal 2021.  For Fiscal 2020, our effective income tax rate includes discrete tax benefits of $4.9 billion related to similar intra-entity asset transfers.  The tax benefit for each intra-entity asset transfer was recorded as a deferred tax asset in the period of transaction and represents the book and tax basis difference on the transferred assets measured based on the applicable Irish statutory tax rate.  We expect to be able to realize the deferred tax assets resulting from these intra-entity asset transfers.  Our effective income tax rate for Fiscal 2020 also includes discrete tax benefits of $351 million related to stock-based compensation, $305 million related to an audit settlement, and $95 million related to Virtustream impairment charges.

[0001571996-21-000007:mdna:151]
Our effective income tax rate can fluctuate depending on the geographic distribution of our worldwide earnings, as our foreign earnings are generally taxed at lower rates than in the United States.  The differences between our effective income tax rate and the U.S. federal statutory rate of 21% principally result from the geographical distribution of income, differences between the book and tax treatment of certain items and the discrete tax items described above.  In certain jurisdictions, our tax rate is significantly less than the applicable statutory rate as a result of tax holidays.  The majority of our foreign income that is subject to these tax holidays and lower tax rates is attributable to Singapore, China, and Malaysia.  A significant portion of these income tax benefits relates to a tax holiday that will be effective until January 31, 2029.  Our other tax holidays will expire in whole or in part during Fiscal 2022 through Fiscal 2030.  Many of these tax holidays and reduced tax rates may be extended when certain conditions are met or may be terminated early if certain conditions are not met.  As of January 29, 2021, we were not aware of any matters of noncompliance related to these tax holidays.

[0001571996-21-000007:mdna:152]
For further discussion regarding tax matters, including the status of income tax audits, see Note 11 of the Notes to the Consolidated Financial Statements included in this report.

[0001571996-21-000007:mdna:153]
Net Income

[0001571996-21-000007:mdna:154]
During Fiscal 2021, net income decreased 37% to $3.5 billion.  The decrease in net income during Fiscal 2021 was primarily due to lower discrete tax benefits, which was partially offset by an increase in operating income.

[0001571996-21-000007:mdna:155]
Net income for Fiscal 2021 and Fiscal 2020 included amortization of intangible assets, the impact of purchase accounting, transaction-related expenses, stock-based compensation expense, other corporate expenses, fair value adjustments on equity investments, and discrete tax items.  Excluding these costs and the related tax impacts, non-GAAP net income increased 11% to $6.8 billion during Fiscal 2021.  The increase in non-GAAP net income during Fiscal 2021 was primarily attributable to an increase in non-GAAP operating income.

[0001571996-21-000007:mdna:156]
Non-controlling Interests

[0001571996-21-000007:mdna:157]
During Fiscal 2021, net income attributable to non-controlling interests was $255 million, and consisted of net income or loss attributable to our non-controlling interests in VMware, Inc. and Secureworks.  During Fiscal 2020, net income attributable to non-controlling interests was $913 million, and consisted of net income or loss attributable to our non-controlling interests in VMware, Inc., Pivotal, and Secureworks.  Pivotal was acquired by VMware, Inc. on December 30, 2019 and, as a result, we no longer have a separate non-controlling interest in Pivotal.  The decrease in net income attributable to non-controlling interests in Fiscal 2021 was driven by lower discrete tax benefits for VMware, Inc.  For more information about our non-controlling interests, see Note 13 of the Notes to the Consolidated Financial Statements included in this report.

[0001571996-21-000007:mdna:158]
Net Income Attributable to Dell Technologies Inc.

[0001571996-21-000007:mdna:159]
Net income attributable to Dell Technologies Inc. represents net income and an adjustment for non-controlling interests.  Net income attributable to Dell Technologies Inc. was $3.3 billion in Fiscal 2021, compared to $4.6 billion in Fiscal 2020.  The decrease in net income attributable to Dell Technologies Inc. during Fiscal 2021 was primarily attributable to a decrease in net income for the period.

[0001571996-21-000007:mdna:160]
54

[0001571996-21-000007:mdna:161]
Business Unit Results

[0001571996-21-000007:mdna:162]
Our reportable segments are based on the following business units: ISG, CSG, and VMware.  A description of our three business units is provided under “Introduction.”  See Note 19 of the Notes to the Consolidated Financial Statements included in this report for a reconciliation of net revenue and operating income by reportable segment to consolidated net revenue and consolidated operating income (loss), respectively.

[0001571996-21-000007:mdna:163]
Infrastructure Solutions Group

[0001571996-21-000007:mdna:164]
The following table presents net revenue and operating income attributable to ISG for the periods indicated:

[0001571996-21-000007:mdna:165]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  |  |  | January 29, 2021 |  | % Change |  | January 31, 2020 |  | % Change |  | February 1, 2019 |
|  |  |  |  |  |  |  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Servers and networking |  |  |  |  |  |  | $ | 16,497 |  | (4) | % |  | $ | 17,127 |  | (14) | % |  | $ | 19,953 |
| Storage |  |  |  |  |  |  | 16,091 |  | (4) | % |  | 16,842 |  | — | % |  | 16,767 |
| Total ISG net revenue |  |  |  |  |  |  | $ | 32,588 |  | (4) | % |  | $ | 33,969 |  | (7) | % |  | $ | 36,720 |
| Operating income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| ISG operating income |  |  |  |  |  |  | $ | 3,776 |  | (6) | % |  | $ | 4,001 |  | (4) | % |  | $ | 4,151 |
| % of segment net revenue |  |  |  |  |  |  | 11.6 | % |  |  |  | 11.8 | % |  |  |  | 11.3 | % |

[0001571996-21-000007:mdna:166]
Net Revenue — During Fiscal 2021, ISG net revenue decreased 4% due to decreases in sales of servers and networking and storage.  ISG net revenue decreased primarily due to a weaker demand environment, as customers shifted their investments toward remote work and business continuity solutions.

[0001571996-21-000007:mdna:167]
Revenue from the sales of servers and networking decreased 4% during Fiscal 2021, primarily driven by a decline in demand of our PowerEdge servers due to the broader macroeconomic environment, including the effects of COVID-19.

[0001571996-21-000007:mdna:168]
Storage revenue decreased 4% during Fiscal 2021 primarily due to declines in demand for our core storage solutions offerings, partially offset by increased demand for converged and hyper-converged infrastructure solutions.  We continue to make enhancements to our storage solutions offerings and expect that these offerings, including our new PowerStore storage array released in May 2020, will drive long-term improvements in the business.

[0001571996-21-000007:mdna:169]
ISG customers are interested in new and innovative models that address how they consume our solutions.  We offer options that include as-a-service, utility, leases, and immediate pay models, all designed to match customers’ consumption and financing preferences.  Our multiyear agreements typically result in recurring revenue streams over the term of the arrangement.  We expect our flexible consumption models and as-a-service offerings will further strengthen our customer relationships and provide a foundation for growth in recurring revenue.

[0001571996-21-000007:mdna:170]
From a geographical perspective, net revenue attributable to ISG decreased in all regions during Fiscal 2021, driven by a weaker demand environment as a result of pervasive global COVID-19 disruptions.

[0001571996-21-000007:mdna:171]
Operating Income — During Fiscal 2021, ISG operating income as a percentage of net revenue decreased 20 basis points to 11.6%.  The decline in ISG operating income percentage during Fiscal 2021 was driven by a decrease in ISG gross margin percentage from higher server configuration costs, increased freight costs, and lower benefits from component cost deflation.  During Fiscal 2021, ISG component costs remained deflationary in the aggregate, but to a lesser degree relative to Fiscal 2020.  The decline in ISG gross margin percentage in Fiscal 2021 was partially offset by a decrease in ISG operating expenses as a percentage of net revenue, as we realized the benefit of cost reduction initiatives.

[0001571996-21-000007:mdna:172]
Client Solutions Group

[0001571996-21-000007:mdna:173]
The following table presents net revenue and operating income attributable to CSG for the periods indicated:

[0001571996-21-000007:mdna:174]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  |  |  | January 29, 2021 |  | % Change |  | January 31, 2020 |  | % Change |  | February 1, 2019 |
|  |  |  |  |  |  |  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial |  |  |  |  |  |  | $ | 35,396 |  | 3 | % |  | $ | 34,277 |  | 11 | % |  | $ | 30,893 |
| Consumer |  |  |  |  |  |  | 12,959 |  | 12 | % |  | 11,561 |  | (6) | % |  | 12,303 |
| Total CSG net revenue |  |  |  |  |  |  | $ | 48,355 |  | 5 | % |  | $ | 45,838 |  | 6 | % |  | $ | 43,196 |
| Operating income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| CSG operating income |  |  |  |  |  |  | $ | 3,352 |  | 7 | % |  | $ | 3,138 |  | 60 | % |  | $ | 1,960 |
| % of segment net revenue |  |  |  |  |  |  | 6.9 | % |  |  |  | 6.8 | % |  |  |  | 4.5 | % |

[0001571996-21-000007:mdna:175]
Net Revenue — During Fiscal 2021, CSG net revenue increased 5% primarily due to an increase in commercial and consumer notebook sales, partially offset by a decrease in commercial desktop sales.  Much of this demand was driven by the imperative for remote work and remote learning solutions, as business, government, and education customers sought to maintain productivity in the midst of COVID-19.

[0001571996-21-000007:mdna:176]
Commercial revenue increased 3% during Fiscal 2021 due to an increase in commercial notebooks sales, and particularly for entry-level commercial notebooks driven by customers in education and state and local government.  The increases were partially offset by lower sales of commercial desktops.

[0001571996-21-000007:mdna:177]
Consumer revenue increased 12% during Fiscal 2021 due to increases in average selling prices across all consumer product offerings, coupled with continued strong demand for consumer notebooks and high-end and gaming systems.

[0001571996-21-000007:mdna:178]
From a geographical perspective, net revenue attributable to CSG increased in the Americas and EMEA during Fiscal 2021.  These increases were partially offset by a decline in net revenue attributable to CSG in APJ during the period.

[0001571996-21-000007:mdna:179]
Operating Income — During Fiscal 2021, CSG operating income as a percentage of net revenue increased 10 basis points to 6.9%.  This increase was primarily attributable to a decrease in CSG operating expenses as a percentage of revenue, as we realized the benefit of cost reduction initiatives.  This benefit was mostly offset by a decrease in CSG gross margin percentage driven by a shift in product mix to entry-level commercial notebooks and lower component cost deflation relative to pricing.

[0001571996-21-000007:mdna:180]
56

[0001571996-21-000007:mdna:181]
VMware

[0001571996-21-000007:mdna:182]
The following table presents net revenue and operating income attributable to VMware for the periods indicated.  During Fiscal 2020, the Company reclassified Pivotal operating results from other businesses to the VMware reportable segment.  Prior period results were recast to conform with the current period presentation.

[0001571996-21-000007:mdna:183]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  |  |  | January 29, 2021 |  | % Change |  | January 31, 2020 |  | % Change |  | February 1, 2019 |
|  |  |  |  |  |  |  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| VMware net revenue |  |  |  |  |  |  | $ | 11,873 |  | 9 | % |  | $ | 10,905 |  | 12 | % |  | $ | 9,741 |
| Operating income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| VMware operating income |  |  |  |  |  |  | $ | 3,571 |  | 16 | % |  | $ | 3,081 |  | 5 | % |  | $ | 2,926 |
| % of segment net revenue |  |  |  |  |  |  | 30.1 | % |  |  |  | 28.3 | % |  |  |  | 30.0 | % |

[0001571996-21-000007:mdna:184]
Net Revenue — VMware net revenue, inclusive of Pivotal, primarily consists of revenue from the sale of software licenses under perpetual licenses and subscription and software-as-a-service (“SaaS”) offerings, as well as related software maintenance services, support, training, consulting services, and hosted services.  VMware net revenue during Fiscal 2021 increased 9% primarily due to growth in sales of subscriptions and SaaS offerings, as well as an increase in sales of software maintenance services.  Growth in sales of subscriptions and SaaS offerings was primarily driven by increased demand for hybrid cloud offerings and digital workspaces.  Software maintenance revenue benefited from maintenance contracts sold in previous periods.

[0001571996-21-000007:mdna:185]
From a geographical perspective, approximately half of VMware net revenue during Fiscal 2021 was generated by sales to customers in the United States.  VMware net revenue for Fiscal 2021 increased in both the United States and internationally.

[0001571996-21-000007:mdna:186]
Operating Income — During Fiscal 2021, VMware operating income as a percentage of net revenue increased 180 basis points to 30.1%.  The increase was primarily driven by a decrease in VMware selling, general, and administrative expenses as a percentage of net revenue, as we benefited from decreased travel-related costs resulting from travel restrictions imposed in response to the COVID-19 pandemic.  While the COVID-19 pandemic has not had a significant adverse financial impact on VMware operations to date, there continues to be significant uncertainty regarding the economic effects of the COVID-19 pandemic and the extent to which it may have a negative impact on VMware’s sales and results of operations in Fiscal 2022.

[0001571996-21-000007:mdna:187]
57

[0001571996-21-000007:mdna:188]
OTHER BALANCE SHEET ITEMS

[0001571996-21-000007:mdna:189]
Accounts Receivable

[0001571996-21-000007:mdna:190]
We sell products and services directly to customers and through a variety sales channels, including retail distribution.  Our accounts receivable, net, was $12.8 billion and $12.5 billion as of January 29, 2021 and January 31, 2020, respectively.  We maintain an allowance for expected credit losses to cover receivables that may be deemed uncollectible.  The allowance for expected credit losses is an estimate based on an analysis of historical loss experience, current receivables aging, and management’s assessment of current conditions and reasonable and supportable expectation of future conditions, as well as specific identifiable customer accounts that are deemed at risk.  Our analysis includes assumptions regarding the impact of COVID-19 and continued market volatility, which is highly uncertain and subject to significant judgment.  Given this uncertainty, our allowance for expected credit losses in future periods may vary from our current estimates.  As of January 29, 2021 and January 31, 2020, the allowance for expected credit losses was $104 million and $94 million, respectively.  Allowance for expected credit losses of trade receivables as of January 29, 2021 includes the impact of adoption of the new current expected credit losses (“CECL”) standard, which was adopted as of February 1, 2020 using the modified retrospective method.  Based on our assessment, we believe that we are adequately reserved for expected credit losses.  We will continue to monitor the aging of our accounts receivable and take actions, where necessary, to reduce our exposure to credit losses.

[0001571996-21-000007:mdna:191]
Dell Financial Services and Financing Receivables

[0001571996-21-000007:mdna:192]
DFS supports Dell Technologies by offering and arranging various financing options and services for our customers globally, including through captive financing operations in North America, Europe, Australia, and New Zealand.  DFS originates, collects, and services customer receivables primarily related to the purchase of our product, software, and service solutions.  DFS further strengthens our customer relationships through its flexible consumption models, which enable us to offer our customers the option to pay over time and, in certain cases, based on utilization, to provide them with financial flexibility to meet their changing technological requirements.  New financing originations were $8.9 billion, $8.5 billion, and $7.3 billion for Fiscal 2021, Fiscal 2020, and Fiscal 2019, respectively.

[0001571996-21-000007:mdna:193]
Pursuant to the current lease accounting standard effective February 2, 2019, new DFS leases are classified as sales-type leases, direct financing leases, or operating leases.  Amounts due from lessees under sales-type leases or direct financing leases are recorded as part of financing receivables, with interest income recognized over the contract term.  On commencement of sales-type leases, we typically qualify for up-front revenue recognition.  On originations of operating leases, we record equipment under operating leases, classified as property, plant, and equipment, and recognize rental revenue and depreciation expense, classified as cost of net revenue, over the contract term.  Direct financing leases are immaterial.  Leases that commenced prior to the effective date of the current lease accounting standard continue to be accounted for under previous lease accounting guidance.

[0001571996-21-000007:mdna:194]
As of January 29, 2021 and January 31, 2020, our financing receivables, net were $10.5 billion and $9.7 billion, respectively.  We maintain an allowance to cover expected financing receivable credit losses and evaluate credit loss expectations based on our total portfolio.  Allowance for expected credit losses of financing receivables as of January 29, 2021 includes the impact of adoption of the CECL standard referred to above.  Our analysis includes assumptions regarding the impact of COVID-19 and continued market volatility, which is highly uncertain and subject to significant judgment.  Given this uncertainty, our allowance for expected credit losses in future periods may vary from our current estimates.  For Fiscal 2021, Fiscal 2020, and Fiscal 2019, the principal charge-off rate for our financing receivables portfolio was 0.7%, 1.0%, and 1.2%, respectively.  The credit quality of our financing receivables has improved in recent years as the mix of high-quality commercial accounts in our portfolio has continued to increase.  We continue to monitor broader economic indicators and their potential impact on future loss performance.  We have an extensive process to manage our exposure to customer credit risk, including active management of credit lines and our collection activities.  We also sell selected fixed-term financing receivables without recourse to unrelated third parties on a periodic basis, primarily to manage certain concentrations of customer credit exposure.  Based on our assessment of the customer financing receivables, we believe that we are adequately reserved.

[0001571996-21-000007:mdna:195]
We retain a residual interest in equipment leased under our lease programs.  As of January 29, 2021 and January 31, 2020, the residual interest recorded as part of financing receivables was $424 million and $582 million, respectively.  The amount of the residual interest is established at the inception of the lease based upon estimates of the value of the equipment at the end of the lease term using historical studies, industry data, and future value-at-risk demand valuation methods.  On a quarterly basis, we assess the carrying amount of our recorded residual values for impairment.  Generally, residual value risk on equipment under lease is not considered to be significant, because of the existence of a secondary market with respect to the equipment.  The

[0001571996-21-000007:mdna:196]
lease agreement also clearly defines applicable return conditions and remedies for non-compliance, to ensure that the leased equipment will be in good operating condition upon return.  Model changes and updates, as well as market strength and product acceptance, are monitored and adjustments are made to residual values in accordance with the significance of any such changes.  To mitigate our exposure, we work closely with customers and dealers to manage the sale of returned assets.  No material impairment losses were recorded related to residual assets during Fiscal 2021 and Fiscal 2020.

[0001571996-21-000007:mdna:197]
As of January 29, 2021 and January 31, 2020, equipment under operating leases, net was $1.3 billion and $0.8 billion, respectively.  Based on triggering events, we assess the carrying amount of the equipment under operating leases recorded for impairment.  No material impairment losses were recorded related to such equipment during Fiscal 2021 and Fiscal 2020.

[0001571996-21-000007:mdna:198]
DFS offerings are initially funded through cash on hand at the time of origination, most of which is subsequently replaced with third-party financing.  For DFS offerings which qualify as sales-type leases, the initial funding of financing receivables is reflected as an impact to cash flows from operations, and is largely subsequently offset by cash proceeds from financing.  For DFS operating leases, which have increased under the current lease accounting standard, the initial funding is classified as a capital expenditure and reflected as an impact to cash flows used in investing activities.

[0001571996-21-000007:mdna:199]
See Note 4 of the Notes to the Consolidated Financial Statements included in this report for additional information about our financing receivables and the associated allowances, and equipment under operating leases.

[0001571996-21-000007:mdna:200]
Off-Balance Sheet Arrangements

[0001571996-21-000007:mdna:201]
As of January 29, 2021, we had no off-balance sheet arrangements that have or are reasonably likely to have a current or future material effect on our financial condition or results of operations.

[0001571996-21-000007:mdna:202]
MARKET CONDITIONS, LIQUIDITY, CAPITAL COMMITMENTS, AND CONTRACTUAL CASH OBLIGATIONS

[0001571996-21-000007:mdna:203]
Market Conditions

[0001571996-21-000007:mdna:204]
We regularly monitor economic conditions and associated impacts on the financial markets and our business.  We consistently evaluate the financial health of our supplier base, carefully manage customer credit, diversify counterparty risk, and monitor the concentration risk of our cash and cash equivalents balances globally.  We routinely monitor our financial exposure to borrowers and counterparties.

[0001571996-21-000007:mdna:205]
We monitor credit risk associated with our financial counterparties using various market credit risk indicators such as credit ratings issued by nationally recognized credit rating agencies and changes in market credit default swap levels.  We perform periodic evaluations of our positions with these counterparties and may limit exposure to any one counterparty in accordance with our policies.  We monitor and manage these activities depending on current and expected market developments.

[0001571996-21-000007:mdna:206]
We use derivative instruments to hedge certain foreign currency exposures.  We use forward contracts and purchased options designated as cash flow hedges to protect against the foreign currency exchange rate risks inherent in our forecasted transactions denominated in currencies other than the U.S. dollar.  In addition, we primarily use forward contracts and may use purchased options to hedge monetary assets and liabilities denominated in a foreign currency.  See Note 7 of the Notes to the Consolidated Financial Statements included in this report for more information about our use of derivative instruments.

[0001571996-21-000007:mdna:207]
We are exposed to interest rate risk related to our variable-rate debt portfolio.  In the normal course of business, we follow established policies and procedures to manage this risk, including monitoring of our asset and liability mix.  As a result, we do not anticipate any material losses from interest rate risk.

[0001571996-21-000007:mdna:208]
The impact of any credit adjustments related to our use of counterparties on our Consolidated Financial Statements included in this report has been immaterial.

[0001571996-21-000007:mdna:209]
Liquidity and Capital Resources

[0001571996-21-000007:mdna:210]
To support our ongoing business operations, we rely on operating cash flows as our primary source of liquidity.  We monitor the efficiency of our balance sheet to ensure that we have adequate liquidity to support our business and strategic initiatives.  In addition to internally generated cash, we have access to other capital sources to finance our strategic initiatives and fund growth in our financing operations.  Our strategy is to deploy capital from any potential source, whether internally generated cash or debt, depending on the adequacy and availability of that source of capital and whether it can be accessed in a cost-effective manner.

[0001571996-21-000007:mdna:211]
The following table presents our cash and cash equivalents as well as our available borrowings as of the dates indicated:

[0001571996-21-000007:mdna:212]
|  | January 29, 2021 |  | January 31, 2020 |
|  | (in millions) |
| Cash and cash equivalents, and available borrowings: |  |  |  |
| Cash and cash equivalents (a) | $ | 14,201 |  |  | $ | 9,302 |  |
| Remaining available borrowings under revolving credit facilities (b) | 5,467 |  |  | 5,972 |  |
| Total cash, cash equivalents, and available borrowings | $ | 19,668 |  |  | $ | 15,274 |  |

[0001571996-21-000007:mdna:213]
____________________

[0001571996-21-000007:mdna:214]
(a)    Of the $14.2 billion of cash and cash equivalents as of January 29, 2021, $4.7 billion was held by VMware, Inc.

[0001571996-21-000007:mdna:215]
(b)    Of the $5.5 billion of remaining available borrowings under revolving credit facilities, $1.0 billion was attributable to the VMware Revolving Credit Facility.

[0001571996-21-000007:mdna:216]
Our revolving credit facilities as of January 29, 2021 include the Revolving Credit Facility.  The Revolving Credit Facility has a maximum capacity of $4.5 billion, and available borrowings under this facility are reduced by draws on the facility and outstanding letters of credit.  As of January 29, 2021, there were no borrowings outstanding under the facility and remaining available borrowings totaled approximately $4.5 billion.  We may regularly use our available borrowings from our Revolving Credit Facility on a short-term basis for general corporate purposes.

[0001571996-21-000007:mdna:217]
60

[0001571996-21-000007:mdna:218]
The VMware Revolving Credit Facility has a maximum capacity of $1.0 billion.  As of January 29, 2021, $1.0 billion was available under the VMware Revolving Credit Facility.  None of the net proceeds of borrowings under the VMware Revolving Credit Facility will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.

[0001571996-21-000007:mdna:219]
See Note 6 of the Notes to the Consolidated Financial Statements included in this report for additional information about each of the foregoing revolving credit facilities.

[0001571996-21-000007:mdna:220]
We believe that our current cash and cash equivalents, together with cash that will be provided by future operations and borrowings expected to be available under our revolving credit facilities, will be sufficient over at least the next twelve months and for the foreseeable future thereafter to fund our operations, debt service requirements and maturities, capital expenditures, share repurchases, and other corporate needs.

[0001571996-21-000007:mdna:221]
Debt

[0001571996-21-000007:mdna:222]
The following table presents our outstanding debt as of the dates indicated:

[0001571996-21-000007:mdna:223]
|  | January 29, 2021 |  | Increase (Decrease) |  | January 31, 2020 |
|  | (in millions) |
| Core debt |  |  |  |  |  |
| Senior Secured Credit Facilities and First Lien Notes | $ | 24,777 |  |  | $ | (4,887) |  |  | $ | 29,664 |  |
| Unsecured Notes and Debentures | 1,352 |  |  | — |  |  | 1,352 |  |
| Senior Notes | 2,700 |  |  | — |  |  | 2,700 |  |
| EMC Notes | 1,000 |  |  | (600) |  |  | 1,600 |  |
| DFS allocated debt | (666) |  |  | 829 |  |  | (1,495) |  |
| Total core debt | 29,163 |  |  | (4,658) |  |  | 33,821 |  |
| DFS related debt |  |  |  |  |  |
| DFS debt | 9,666 |  |  | 1,901 |  |  | 7,765 |  |
| DFS allocated debt | 666 |  |  | (829) |  |  | 1,495 |  |
| Total DFS related debt | 10,332 |  |  | 1,072 |  |  | 9,260 |  |
| Margin Loan Facility and other | 4,235 |  |  | 151 |  |  | 4,084 |  |
| Debt of public subsidiary |  |  |  |  |  |
| VMware Notes | 4,750 |  |  | 750 |  |  | 4,000 |  |
| VMware Term Loan Facility | — |  |  | (1,500) |  |  | 1,500 |  |
| Total public subsidiary debt | 4,750 |  |  | (750) |  |  | 5,500 |  |
| Total debt, principal amount | 48,480 |  |  | (4,185) |  |  | 52,665 |  |
| Carrying value adjustments | (496) |  |  | 113 |  |  | (609) |  |
| Total debt, carrying value | $ | 47,984 |  |  | $ | (4,072) |  |  | $ | 52,056 |  |

[0001571996-21-000007:mdna:224]
During Fiscal 2021, the outstanding principal amount of our debt decreased by $4.2 billion to $48.5 billion as of January 29, 2021, primarily driven by net repayments of core debt and VMware, Inc. debt, partially offset by a net increase in DFS debt.

[0001571996-21-000007:mdna:225]
We define core debt as the total principal amount of our debt, less DFS related debt, our Margin Loan Facility and other debt, and public subsidiary debt.  Our core debt was $29.2 billion and $33.8 billion as of January 29, 2021 and January 31, 2020, respectively.  The decrease in our core debt during Fiscal 2021 was driven by principal repayments.  Proceeds of $2.082 billion from the sale of RSA Security in Fiscal 2021 were used to pay down core debt.  See Note 6 of the Notes to the Consolidated Financial Statements included in this report for more information about our debt.

[0001571996-21-000007:mdna:226]
We will continue to prioritize debt paydown as part of our overall capital allocation strategy, including $1.5 billion of scheduled maturities due in Fiscal 2022.  Subsequent to January 29, 2021, we repaid $400 million principal amount of our 4.625% Unsecured Notes due April 2021 and $600 million principal amount of our 5.875% Senior Notes due June 2021.

[0001571996-21-000007:mdna:227]
61

[0001571996-21-000007:mdna:228]
During Fiscal 2021, we issued an additional $1.9 billion, net, in DFS debt to support the expansion of its financing receivables portfolio.  DFS related debt primarily represents debt from our securitization and structured financing programs.  The majority of DFS debt represents borrowings under securitization programs and structured financing programs, for which our risk of loss is limited to transferred lease and loan payments and associated equipment, and under which the credit holders have no recourse to Dell Technologies.

[0001571996-21-000007:mdna:229]
To fund expansion of the DFS business, we balance the use of the securitization and structured financing programs with other sources of liquidity.  We approximate the amount of our debt used to fund the DFS business by applying a 7:1 debt to equity ratio to the sum of our financing receivables balance and equipment under our DFS operating leases, net.  The debt to equity ratio is based on the underlying credit quality of the assets.  See Note 4 of the Notes to the Consolidated Financial Statements included in this report for more information about our DFS debt.

[0001571996-21-000007:mdna:230]
As of January 29, 2021 and January 31, 2020, margin loan and other debt primarily consisted of the $4.0 billion Margin Loan Facility.

[0001571996-21-000007:mdna:231]
Public subsidiary debt represents VMware, Inc. indebtedness.  The decrease in debt of public subsidiary during Fiscal 2021 was driven by principal repayments by VMware, Inc.  VMware, Inc. and its respective subsidiaries are unrestricted subsidiaries for purposes of the core debt of Dell Technologies.  Neither Dell Technologies nor any of its subsidiaries, other than VMware, Inc., is obligated to make payment on the VMware Notes.  None of the net proceeds of the VMware Notes are made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and its subsidiaries.  See Note 6 of the Notes to the Consolidated Financial Statements included in this report for more information about VMware, Inc. debt.

[0001571996-21-000007:mdna:232]
We have made steady progress in paying down core debt.  We believe we will continue to be able to make our debt principal and interest payments, including the short-term maturities, from existing and expected sources of cash, primarily from operating cash flows.  Cash used for debt principal and interest payments may include short-term borrowings under our revolving credit facilities.  We will continue to focus on paying down core debt.  Under our variable-rate debt, we could experience variations in our future interest expense from potential fluctuations in applicable reference rates, or from possible fluctuations in the level of DFS debt required to meet future demand for customer financing.  We or our affiliates or their related persons, at our or their sole discretion, may purchase, redeem, prepay, refinance, or otherwise retire any amount of our outstanding indebtedness under the terms of such indebtedness at any time and from time to time, in open market or negotiated transactions with the holders of such indebtedness or otherwise, as appropriate market conditions exist.

[0001571996-21-000007:mdna:233]
Cash Flows

[0001571996-21-000007:mdna:234]
The following table presents a summary of our Consolidated Statements of Cash Flows for the periods indicated:

[0001571996-21-000007:mdna:235]
|  | Fiscal Year Ended |
|  | January 29, 2021 |  | January 31, 2020 |  | February 1, 2019 |
|  | (in millions) |
| Net change in cash from: |  |  |  |  |  |
| Operating activities | $ | 11,407 |  |  | $ | 9,291 |  |  | $ | 6,991 |  |
| Investing activities | (460) |  |  | (4,686) |  |  | 3,389 |  |
| Financing activities | (5,950) |  |  | (4,604) |  |  | (14,329) |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash | 36 |  |  | (90) |  |  | (189) |  |
| Change in cash, cash equivalents, and restricted cash | $ | 5,033 |  |  | $ | (89) |  |  | $ | (4,138) |  |

[0001571996-21-000007:mdna:236]
Operating Activities — Cash provided by operating activities was $11.4 billion and $9.3 billion during Fiscal 2021 and Fiscal 2020, respectively.  Our record cash flow from operations in Fiscal 2021 was due to strong profitability, revenue growth, and working capital dynamics.  COVID-19 impacts to working capital normalized by the end of Fiscal 2021.

[0001571996-21-000007:mdna:237]
DFS offerings are initially funded through cash on hand at the time of origination, most of which is subsequently replaced with third-party financing.  For DFS offerings that qualify as sales-type leases, the initial funding of financing receivables is reflected as an impact to cash flows from operations, and is largely subsequently offset by cash proceeds from financing.  For

[0001571996-21-000007:mdna:238]
62

[0001571996-21-000007:mdna:239]
DFS operating leases, which have increased under the current lease accounting standard,  the initial funding is classified as a capital expenditure and reflected as cash flows used in investing activities.  DFS new financing originations were $8.9 billion and $8.5 billion during Fiscal 2021 and Fiscal 2020, respectively.  As of January 29, 2021, DFS had $10.5 billion of total net financing receivables and $1.3 billion of equipment under DFS operating leases, net.

[0001571996-21-000007:mdna:240]
Investing Activities — Investing activities primarily consist of cash used to fund capital expenditures for property, plant, and equipment, which includes equipment under DFS operating leases, capitalized software development costs, strategic investments, acquisitions of businesses, and the maturities, sales, and purchases of investments.  During Fiscal 2021, cash used in investing activities was $460 million and was primarily driven by capital expenditures and cash used in acquisition of businesses, largely offset by net cash proceeds from the divestiture of RSA Security.  In comparison, cash used in investing activities was $4.7 billion during Fiscal 2020 and was primarily driven by capital expenditures and acquisitions of businesses.

[0001571996-21-000007:mdna:241]
Financing Activities — Financing activities primarily consist of the proceeds and repayments of debt, cash used to repurchase common stock, and proceeds from the issuance of common stock.  Cash used in financing activities of $6.0 billion during Fiscal 2021 primarily consisted of debt repayments and repurchases of common stock by our public subsidiaries, partially offset by cash proceeds from the issuances of multiple series of First Lien Notes and VMware Notes.  In comparison, cash used in financing activities of $4.6 billion during Fiscal 2020 primarily consisted of net repayments of debt and repurchases of common stock by our public subsidiaries, primarily related to VMware Inc.’s acquisition of Pivotal.

[0001571996-21-000007:mdna:242]
Capital Commitments

[0001571996-21-000007:mdna:243]
Capital Expenditures — During Fiscal 2021 and Fiscal 2020, we spent $1.8 billion and $2.2 billion, respectively, on property, plant, and equipment.  These expenditures were incurred in connection with our global expansion efforts and infrastructure investments made to support future growth, and the funding of equipment under DFS operating leases.  During Fiscal 2021 and Fiscal 2020, funding of equipment under DFS operating leases was $0.7 billion and $0.9 billion, respectively.  Product demand, product mix, and the use of contract manufacturers, as well as ongoing investments in operating and information technology infrastructure, influence the level and prioritization of our capital expenditures.  Aggregate capital expenditures for Fiscal 2022 are currently expected to total between $2.4 billion and $2.6 billion, of which approximately $0.8 billion is expected for equipment under DFS operating leases.

[0001571996-21-000007:mdna:244]
Repurchases of Common Stock

[0001571996-21-000007:mdna:245]
Dell Technologies Common Stock Repurchases by Dell Technologies

[0001571996-21-000007:mdna:246]
On February 24, 2020, our board of directors approved a stock repurchase program under which we are authorized to repurchase up to $1.0 billion of shares of Class C Common Stock over a 24-month period expiring on February 28, 2022, of which approximately $760 million remained available as of January 29, 2021.  During Fiscal 2021, we repurchased approximately 6 million shares of Class C Common Stock for approximately $240 million.  During the first quarter of Fiscal 2021, we suspended activity under our stock repurchase program.  During Fiscal 2020, Dell Technologies Common Stock repurchases were immaterial.

[0001571996-21-000007:mdna:247]
VMware, Inc. Class A Common Stock Repurchases by VMware, Inc.

[0001571996-21-000007:mdna:248]
On May 29, 2019, VMware, Inc.’s board of directors authorized the repurchase of up to $1.5 billion of VMware, Inc.’s Class A common stock through January 29, 2021.  On July 15, 2020, VMware, Inc.’s board of directors extended authorization of VMware, Inc.’s existing repurchase program and authorized the repurchase of up to an additional $1.0 billion of VMware, Inc.’s Class A common stock through January 28, 2022.  As of January 29, 2021, the cumulative authorized amount remaining for stock repurchases was $1.1 billion.

[0001571996-21-000007:mdna:249]
During Fiscal 2021, VMware, Inc. repurchased 6.9 million shares of its Class A common stock in the open market for approximately $945 million.  During Fiscal 2020, VMware, Inc. repurchased 7.7 million shares of its Class A common stock in the open market for approximately $1.3 billion, of which approximately $0.2 billion impacted Dell Technologies’ accumulated deficit balance as of January 31, 2020 as a result of the full depletion of VMware, Inc.’s additional paid-in capital balance in the same period.

[0001571996-21-000007:mdna:250]
Contractual Cash Obligations

[0001571996-21-000007:mdna:251]
The following table presents a summary our contractual cash obligations as of January 29, 2021:

[0001571996-21-000007:mdna:252]
|  |  |  | Payments Due by Fiscal Year |
|  | Total |  | 2022 |  | 2023-2024 |  | 2025-2026 |  | Thereafter |
|  | (in millions) |
| Contractual cash obligations: |  |  |  |  |  |  |  |  |  |
| Principal payments on long-term debt: |  |  |  |  |  |  |  |  |  |
| Core debt | $ | 29,829 |  |  | $ | 1,475 |  |  | $ | 7,264 |  |  | $ | 7,388 |  |  | $ | 13,702 |  |
| DFS debt | 9,666 |  |  | 4,888 |  |  | 4,061 |  |  | 717 |  |  | — |  |
| Margin Loan Facility and other | 4,235 |  |  | 11 |  |  | 4,184 |  |  | 16 |  |  | 24 |  |
| VMware Notes | 4,750 |  |  | — |  |  | 1,500 |  |  | 750 |  |  | 2,500 |  |
| Total principal payments on long-term debt | 48,480 |  |  | 6,374 |  |  | 17,009 |  |  | 8,871 |  |  | 16,226 |  |
| Interest | 13,966 |  |  | 1,911 |  |  | 3,256 |  |  | 2,368 |  |  | 6,431 |  |
| Purchase obligations | 5,878 |  |  | 4,885 |  |  | 922 |  |  | 52 |  |  | 19 |  |
| Operating leases | 2,652 |  |  | 472 |  |  | 769 |  |  | 436 |  |  | 975 |  |
| Tax obligations | 164 |  |  | 19 |  |  | 84 |  |  | 61 |  |  | — |  |
| Contractual cash obligations | $ | 71,140 |  |  | $ | 13,661 |  |  | $ | 22,040 |  |  | $ | 11,788 |  |  | $ | 23,651 |  |

[0001571996-21-000007:mdna:253]
Principal Payments on Long-Term Debt — Our expected principal cash payments on borrowings are exclusive of discounts and premiums.  We have outstanding long-term notes with varying maturities.  For additional information about our debt, see Note 6 of the Notes to the Consolidated Financial Statements included in this report.

[0001571996-21-000007:mdna:254]
Interest —  Of the total cash obligations for interest presented in the table above, the amounts related to our DFS debt were expected to be $105 million in Fiscal 2022, $48 million in Fiscal 2023-2024, and $1 million in Fiscal 2025-2026.  See Note 6 of the Notes to the Consolidated Financial Statements included in this report for further discussion of our debt and related interest expense.

[0001571996-21-000007:mdna:255]
Purchase Obligations — Purchase obligations are defined as contractual obligations to purchase goods or services that are enforceable and legally binding on us.  These obligations specify all significant terms, including fixed or minimum quantities to be purchased; fixed, minimum, or variable price provisions; and the approximate timing of the transaction.  Purchase obligations do not include contracts that may be canceled without penalty.

[0001571996-21-000007:mdna:256]
We utilize several suppliers to manufacture sub-assemblies for our products.  Our efficient supply chain management allows us to enter into flexible and mutually beneficial purchase arrangements with our suppliers in order to minimize inventory risk.  Consistent with industry practice, we acquire raw materials or other goods and services, including product components, by issuing to suppliers authorizations to purchase based on our projected demand and manufacturing needs.  These purchase orders are typically fulfilled within 30 days and are entered into during the ordinary course of business in order to establish best pricing and continuity of supply for our production.  Purchase orders are not included in purchase obligations, as they typically represent our authorization to purchase rather than binding purchase obligations.

[0001571996-21-000007:mdna:257]
Operating Leases — We lease property and equipment, manufacturing facilities, and office space under non-cancelable leases.  Certain of these leases obligate us to pay taxes, maintenance, and repair costs.  See Note 5 of the Notes to the Consolidated Financial Statements included in this report for additional information about our leasing transactions in which we are the lessee.

[0001571996-21-000007:mdna:258]
Tax Obligations — Tax obligations represent a one-time mandatory deemed repatriation tax on undistributed earnings of foreign subsidiaries.  Excluded from the table above are $1.4 billion in additional liabilities associated with uncertain tax positions as of January 29, 2021.  We are unable to reliably estimate the expected payment dates for any liabilities for uncertain tax positions.  See Note 11 of the Notes to the Consolidated Financial Statements included in this report for more information on these tax matters.

[0001571996-21-000007:mdna:259]
64

[0001571996-21-000007:mdna:260]
Critical Accounting Policies and Estimates

[0001571996-21-000007:mdna:261]
We prepare our financial statements in conformity with GAAP, which requires certain estimates, assumptions, and judgments to be made that may affect our Consolidated Statements of Financial Position and Consolidated Statements of Income (Loss).  Accounting policies that have a significant impact on our Consolidated Financial Statements are described in Note 2 of the Notes to the Consolidated Financial Statements included in this report.  The accounting estimates and assumptions discussed in this section are those that we consider to be the most critical.  We consider an accounting policy to be critical if the nature of the estimate or assumption is subject to a material level of judgment and if changes in those estimates or assumptions are reasonably likely to materially impact our Consolidated Financial Statements.  We have discussed the development, selection, and disclosure of our critical accounting policies with the Audit Committee of our board of directors.

[0001571996-21-000007:mdna:262]
Revenue Recognition — We sell a wide portfolio of products and services offerings to our customers.  Our agreements have varying requirements depending on the goods and services being sold, the rights and obligations conveyed, and the legal jurisdiction of the arrangement.

[0001571996-21-000007:mdna:263]
Our contracts with customers often include multiple performance obligations for various distinct goods and services such as hardware, software licenses, support and maintenance agreements, and other service offerings and solutions.  We use significant judgment to assess whether these promises are distinct performance obligations that should be accounted for separately.  In certain hardware solutions, the hardware is highly interdependent on, and interrelated with, the embedded software.  In these offerings, the hardware and software licenses are accounted for as a single performance obligation.

[0001571996-21-000007:mdna:264]
The transaction price reflects the amount of consideration to which we expect to be entitled in exchange for transferring goods or services to the customer.  If the consideration promised in a contract includes a variable amount, we estimate the amount to which we expect to be entitled using either the expected value or most likely amount method.  Estimates are updated each reporting period as the variability is resolved or if additional information becomes available.  Generally, volume discounts, rebates, and sales returns reduce the transaction price.  When we determine the transaction price, we only include amounts that are not subject to significant future reversal.

[0001571996-21-000007:mdna:265]
When a contract includes multiple performance obligations, the transaction price is allocated to each performance obligation in proportion to the standalone selling price (“SSP”) of each performance obligation.

[0001571996-21-000007:mdna:266]
Judgment is required when determining the SSP of our performance obligations.  If the observable price is available, we utilize that price for the SSP.  If the observable price is not available, the SSP must be estimated.  We estimate SSP by considering multiple factors, including, but not limited to, pricing practices, internal costs, and profit objectives as well as overall market conditions, which include geographic or regional specific factors, competitive positioning, and competitor actions.  SSP for our performance obligations is periodically reassessed.

[0001571996-21-000007:mdna:267]
Business Combinations — We allocate the purchase price of acquired companies to the identifiable assets acquired and liabilities assumed, which are measured based on acquisition date fair value.  Goodwill is measured as the excess of consideration transferred over the net amounts of the identifiable tangible and intangible assets acquired and the liabilities assumed at the acquisition date.  The allocation of the purchase price requires us to make significant estimates and assumptions, including fair value estimates, to determine the fair value of assets acquired and liabilities assumed and the related useful lives of the acquired assets, when applicable, as of the acquisition date.  Although we believe the assumptions and estimates we have made are reasonable, they are based in part on historical experience and information obtained from the management of the acquired companies and are inherently uncertain.  Examples of critical estimates used in valuing certain of the intangible assets we have acquired or may acquire in the future include but are not limited to:

[0001571996-21-000007:mdna:268]
•future expected cash flows from sales, maintenance agreements, and acquired developed technologies;

[0001571996-21-000007:mdna:269]
•the acquired company’s trade name and customer relationships as well as assumptions about the period of time the acquired trade name and customer relationships will continue to be used in the combined company’s product portfolio; and

[0001571996-21-000007:mdna:270]
•discount rates used to determine the present value of estimated future cash flows.

[0001571996-21-000007:mdna:271]
These estimates are inherently uncertain and unpredictable, and if different estimates were used, the purchase price for the acquisition could be allocated to the acquired assets and assumed liabilities differently from the allocation that we have made. Additionally, unanticipated events and circumstances may occur, which may affect the accuracy or validity of such assumptions, estimates, or actual results.

[0001571996-21-000007:mdna:272]
Goodwill and Indefinite-Lived Intangible Assets Impairment Assessments — Goodwill and indefinite-lived intangible assets are tested for impairment annually during the third fiscal quarter and whenever events or circumstances may indicate that an impairment has occurred.  To determine whether goodwill is impaired, we first assess certain qualitative factors.  Based on this assessment, if it is determined more likely than not that the fair value of a goodwill reporting unit is less than its carrying amount, we perform the quantitative analysis of the goodwill impairment test.  Significant judgment is exercised in the identification of goodwill reporting units, assignment of assets and liabilities to goodwill reporting units, assignment of goodwill to reporting units, and determination of the fair value of each goodwill reporting unit.  The fair value of each of our goodwill reporting units is generally estimated using a combination of public company multiples and discounted cash flow methodologies, and then compared to the carrying value of each goodwill reporting unit.  The discounted cash flow and public company multiples methodologies require significant judgment, including estimation of future revenues, gross margins, and operating expenses, which are dependent on internal forecasts, current and anticipated economic conditions and trends, selection of market multiples through assessment of the reporting unit’s performance relative to peer competitors, the estimation of the long-term revenue growth rate and discount rate of our business, and the determination of our weighted average cost of capital.  Changes in these estimates and assumptions could materially affect the fair value of the goodwill reporting unit, potentially resulting in a non-cash impairment charge.

[0001571996-21-000007:mdna:273]
The fair value of the indefinite-lived trade names is generally estimated using discounted cash flow methodologies.  The discounted cash flow methodology requires significant judgment, including estimation of future revenue, the estimation of the long-term revenue growth rate of our business, and the determination of the our weighted average cost of capital and royalty rates.  Changes in these estimates and assumptions could materially affect the fair value of the indefinite-lived intangible assets, potentially resulting in a non-cash impairment charge.

[0001571996-21-000007:mdna:274]
Income Taxes — We are subject to income tax in the United States and numerous foreign jurisdictions.  Significant judgments are required in determining the consolidated provision for income taxes.  We calculate a provision for income taxes using the asset and liability method, under which deferred tax assets and liabilities are recognized by identifying the temporary differences arising from the different treatment of items for tax and accounting purposes.  We account for the tax impact of including Global Intangible Low-Taxed Income (GILTI) in U.S. taxable income as a period cost.  We provide related valuation allowances for deferred tax assets, where appropriate.  Significant judgment is required in determining any valuation allowance against deferred tax assets.  In assessing the need for a valuation allowance, we consider all available evidence for each jurisdiction, including past operating results, estimates of future taxable income, and the feasibility of ongoing tax planning strategies.  In the event we determine that all or part of the net deferred tax assets are not realizable in the future, we will make an adjustment to the valuation allowance that would be charged to earnings in the period such determination is made.

[0001571996-21-000007:mdna:275]
Significant judgment is also required in evaluating our uncertain tax positions.  Although we believe our tax return positions are sustainable, we recognize tax benefits from uncertain tax positions in the financial statements only when it is more likely than not that the positions will be sustained upon examination, including resolution of any related appeals or litigation processes, based on the technical merits and a consideration of the relevant taxing authority’s administrative practices and precedents.  To the extent that the final tax outcome of these matters is different from the amounts recorded, such differences will impact the provision for income taxes in the period in which such determination is made.  The provision for income taxes includes the impact of reserve provisions and changes to reserves that are considered appropriate, as well as the related net interest and penalties.  We believe we have provided adequate reserves for all uncertain tax positions.

[0001571996-21-000007:mdna:276]
Legal and Other Contingencies — The outcomes of legal proceedings and claims brought against us are subject to significant uncertainty.  An estimated loss from a loss contingency such as a legal proceeding or claim is accrued by a charge to income if it is probable that an asset has been impaired or a liability has been incurred and the amount of the loss can be reasonably estimated.  In determining whether a loss should be accrued we evaluate, among other factors, the degree of probability of an unfavorable outcome and the ability to make a reasonable estimate of the amount of loss.  Changes in these factors could materially impact our consolidated financial statements.

[0001571996-21-000007:mdna:277]
Inventories — We state our inventory at the lower of cost or net realizable value.  We record a write-down for inventories of components and products, including third-party products held for resale, which have become obsolete or are in excess of anticipated demand or net realizable value.  We perform a detailed review of inventory each fiscal quarter that considers multiple factors, including demand forecasts, product life cycle status, product development plans, current sales levels, product pricing, and component cost trends.  The industries in which we compete are subject to demand changes.  If future demand or market conditions for our products are less favorable than forecasted or if unforeseen technological changes negatively impact the utility of component inventory, we may be required to record additional write-downs, which would adversely affect our gross margin.

[0001571996-21-000007:mdna:278]
Recently Issued Accounting Pronouncements

[0001571996-21-000007:mdna:279]
See Note 2 of the Notes to the Consolidated Financial Statements included in this report for a summary of recently issued accounting pronouncements that are applicable to our Consolidated Financial Statements.

[0001571996-21-000007:mdna:280]
67
