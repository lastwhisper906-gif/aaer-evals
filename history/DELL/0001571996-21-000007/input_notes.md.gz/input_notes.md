# DELL notes — 0001571996-21-000007


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001571996-21-000007:notes:1]
DOCUMENTS INCORPORATED BY REFERENCE

[0001571996-21-000007:notes:2]
The information required by Part III of this report, to the extent not set forth herein, is incorporated by reference from the registrant’s proxy statement relating to its annual meeting of stockholders to be held in 2021.  The proxy statement will be filed with the Securities and Exchange Commission within 120 days after the end of the fiscal year to which this report relates.


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001571996-21-000007:notes:3]
Basis of Presentation — These Consolidated Financial Statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“GAAP”)


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001571996-21-000007:notes:4]
NOTE 2 — DESCRIPTION OF BUSINESS AND SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES

[0001571996-21-000007:notes:5]
Description of Business — The Company is a leading global end-to-end technology provider that offers a broad range of comprehensive and integrated solutions, which include servers and networking products, storage products, cloud solutions products, desktops, notebooks, services, software, and third-party software and peripherals.

[0001571996-21-000007:notes:6]
The Company’s fiscal year is the 52- or 53-week period ending on the Friday nearest January 31.  The fiscal years ended January 29, 2021, January 31, 2020, and February 1, 2019 were 52-week periods.

[0001571996-21-000007:notes:7]
Principles of Consolidation — These Consolidated Financial Statements include the accounts of Dell Technologies and its wholly-owned subsidiaries, as well as the accounts of VMware, Inc. and SecureWorks Corp. (“Secureworks”), each of which is majority-owned by Dell Technologies.  All intercompany transactions have been eliminated.

[0001571996-21-000007:notes:8]
The Company also consolidates Variable Interest Entities ("VIEs") where it has been determined that the Company is the primary beneficiary of the applicable entities’ operations.  For each VIE, the primary beneficiary is the party that has both the power to direct the activities that most significantly impact the VIE's economic performance and the obligation to absorb losses or the right to receive benefits of the VIE that could potentially be significant to such VIE.  In evaluating whether the Company is the primary beneficiary of each entity, the Company evaluates its power to direct the most significant activities of the VIE by considering the purpose and design of each entity and the risks each entity was designed to create and pass through to its respective variable interest holders.  The Company also evaluates its economic interests in each of the VIEs.  See Note 4 of the Notes to the Consolidated Financial Statements for more information regarding consolidated VIEs.

[0001571996-21-000007:notes:9]
Use of Estimates — The preparation of financial statements in accordance with GAAP requires management to make estimates and assumptions that affect the amounts reported in the Consolidated Financial Statements and the accompanying Notes.  Management has considered the actual and potential impacts of the coronavirus disease 2019 (“COVID-19”) pandemic on the Company’s critical and significant accounting estimates.  Actual results could differ materially from those estimates.

[0001571996-21-000007:notes:10]
Cash and Cash Equivalents — All highly liquid investments, including credit card receivables due from banks, with original maturities of 90 days or less at date of purchase, are reported at fair value and are considered to be cash equivalents.  All other investments not considered to be cash equivalents are separately categorized as investments.

[0001571996-21-000007:notes:11]
Investments — All equity and other securities are recorded as long-term investments in the Consolidated Statements of Financial Position.

[0001571996-21-000007:notes:12]
Strategic investments in publicly-traded companies are recorded at fair value based on quoted prices in active markets.  Strategic investments in privately-held companies without readily determinable fair values are recorded at cost, less impairment, and are adjusted for observable price changes.  Fair value measurements and impairments for strategic investments are recognized in interest and other, net in the Consolidated Statements of Income (Loss).  In evaluating equity investments without readily determinable fair values for impairment or observable price changes, the Company uses inputs that include pre- and post-money valuations of recent financing events and the impact of those events on its fully diluted ownership percentages, as well as other available information regarding the issuer’s historical and forecasted performance.

[0001571996-21-000007:notes:13]
Allowance for Expected Credit Losses — The Company recognizes an allowance for losses on accounts receivable in an amount equal to the current expected credit losses.  The estimation of the allowance is based on an analysis of historical loss experience, current receivables aging, and management’s assessment of current conditions and reasonable and supportable expectation of future conditions, as well as an assessment of specific identifiable customer accounts considered at risk or uncollectible.  The Company assesses collectibility by pooling receivables where similar characteristics exist and evaluates receivables individually when specific customer balances no longer share those risk characteristics and are considered at risk or uncollectible.  The expense associated with the allowance for expected credit losses is recognized in selling, general, and administrative expenses.

[0001571996-21-000007:notes:14]
The Company’s policy for estimating this allowance is based on an expected loss model and reflects the adoption of the new accounting standard related to current expected credit losses in the most recent fiscal year.  See “Recently Adopted Accounting Pronouncements” in this Note 2 for more information.  In prior periods, this allowance was estimated using an incurred loss model, which did not require the consideration of forward-looking information and conditions in the reserve calculation.

[0001571996-21-000007:notes:15]
Accounting for Operating Leases as a Lessee — In its ordinary course of business, the Company enters into leases as a lessee for office buildings, warehouses, employee vehicles, and equipment.  The Company determines if an arrangement is a lease or contains a lease at inception.  Operating leases result in the recognition of right of use (“ROU”) assets and lease liabilities on the Consolidated Statements of Financial Position.  ROU assets represent the right to use an underlying asset for the lease term and lease liabilities represent the obligation to make lease payments arising from the lease, measured on a discounted basis.  At lease inception, the lease liability is measured at the present value of the lease payments over the lease term.  The operating lease ROU asset equals the lease liability adjusted for any initial direct costs, prepaid or deferred rent, and lease incentives.  The Company uses the implicit rate when readily determinable.  As most of the leases do not provide an implicit rate, the Company uses its incremental borrowing rate based on the information available at the commencement date to determine the present value of lease payments.  Incremental borrowing rates used to determine the present value of lease payments were derived by reference to the Company’s secured-debt yields corresponding to the lease commencement date.

[0001571996-21-000007:notes:16]
The lease term may include options to extend or to terminate the lease that the Company is reasonably certain to exercise.  Lease expense is recognized on a straight-line basis over the lease term in most instances.  The Company has elected not to record leases with an initial term of 12 months or less on the Consolidated Statements of Financial Position.  Lease expense on such leases is recognized on a straight-line basis over the lease term.  The Company does not generate material sublease income and has no material related party leases.  The Company’s lease agreements do not contain any material residual value guarantees or material restrictive covenants.

[0001571996-21-000007:notes:17]
The Company’s office building agreements contain costs such as common area maintenance and other executory costs that are variable in nature.  Variable lease costs are expensed as incurred.  The Company combines lease and non-lease components, such as common area and other maintenance costs, in calculating the ROU assets and lease liabilities for its office buildings and employee vehicles.  Under certain service agreements with third-party logistics providers, the Company directs the use of the inventory within the warehouses and, therefore, controls the assets.  The warehouses and some of the equipment used are considered embedded leases.  The Company accounts for the lease and non-lease components separately.  The lease components consist of the warehouses and some of the equipment, such as conveyor belts.  The non-lease components consist of services and other shared equipment, such as material handling and transportation.  The Company allocates the consideration to the lease and non-lease components using their relative standalone values.  See Note 5 of the Notes to the Consolidated Financial Statements for additional information.

[0001571996-21-000007:notes:18]
Accounting for Leases as a Lessor — The Company’s wholly-owned subsidiary Dell Financial Services and its affiliates (“DFS”) act as a lessor to provide equipment financing to customers through a variety of lease arrangements (“DFS leases”).  Subsequent to the adoption of amended accounting guidance for leasing transactions (the “current lease standard”), new DFS leases are classified as sales-type leases, direct financing leases, or operating leases.  Direct financing leases under the current lease standard are immaterial.  Leases that commenced prior to the adoption of the current lease standard were not reassessed or restated pursuant to the practical expedients elected and continue to be accounted for under previous lease accounting guidance.

[0001571996-21-000007:notes:19]
The Company also offers alternative payment structures and “as-a-service” offerings that are assessed to determine whether an embedded lease arrangement exists.  The Company accounts for those contracts as a lease arrangement under the current lease standard if it is determined that the contract contains an identified asset and that control of that asset has transferred to the customer.

[0001571996-21-000007:notes:20]
When a contract includes lease and non-lease components, the Company allocates consideration under the contract to each component based on relative standalone selling price and subsequently assesses lease classification for each lease component within a contract.  DFS provides lessees with the option to extend the lease or purchase the underlying asset at the end of the lease term, which is considered when evaluating lease classification.  In general, DFS’s lease arrangements do not have variable payment terms and are typically non-cancelable.

[0001571996-21-000007:notes:21]
On commencement of sales-type leases, the Company recognizes profit up-front, and amounts due from the customer under the lease contract are recognized as financing receivables on the Consolidated Statements of Financial Position.  Interest income is recognized as Net revenue over the term of the lease based on the effective interest method.  The Company has elected not to include sales and other taxes collected from the lessee as part of lease revenue.

[0001571996-21-000007:notes:22]
All other leases that do not meet the definition of a sales-type lease or direct financing lease are classified as operating leases.  The underlying asset in an operating lease arrangement is carried at depreciated cost as “Equipment under operating leases” within Property, plant, and equipment, net on the Consolidated Statements of Financial Position.  Depreciation is calculated using the straight-line method over the term of the underlying lease contract and is recognized as Cost of net revenue.  The depreciable basis is the original cost of the equipment less the estimated residual value of the equipment at the end of the lease term.  The residual value is based upon estimates of the value of the equipment at the end of the lease term using historical studies, industry data, and future value-at-risk demand valuation methods.  The Company recognizes operating lease income to product revenue on a straight-line basis over the lease term and expenses deferred initial direct costs on the same basis.  Impairment of equipment under operating leases is assessed on the same basis as other long-lived assets.

[0001571996-21-000007:notes:23]
See Note 4 of the Notes to the Consolidated Financial Statements for more information regarding the Company’s lessor arrangements.

[0001571996-21-000007:notes:24]
Financing Receivables — Financing receivables are presented net of allowance for losses and consist of customer receivables and residual interest.  Gross customer receivables includes amounts due from customers under revolving loans, fixed-term loans, fixed-term sales-type or direct financing leases, and accrued interest.  The Company has two portfolios, consisting of (i) fixed-term leases and loans and (ii) revolving loans, and assesses risk at the portfolio level to determine the appropriate allowance levels.  The portfolio segments are further segregated into classes based on products, customer type, and credit risk evaluation: (i) Revolving — Dell Preferred Account (“DPA”); (ii) Revolving — Dell Business Credit (“DBC”); and (iii) Fixed-term — Consumer and Commercial.  Fixed-term leases and loans are offered to qualified small and medium-sized businesses, large commercial accounts, governmental organizations, and educational entities.  Fixed-term loans are also offered to qualified individual consumers.  Revolving loans are offered under private label credit financing programs.  The DPA revolving loan programs are primarily offered to individual consumers and the DBC revolving loan programs are primarily offered to small and medium-sized business customers.

[0001571996-21-000007:notes:25]
The Company retains a residual interest in equipment leased under its fixed-term lease programs.  The amount of the residual interest is established at the inception of the lease based upon estimates of the value of the equipment at the end of the lease term using historical studies, industry data, and future value-at-risk demand valuation methods.

[0001571996-21-000007:notes:26]
Allowance for Financing Receivables Losses — The Company recognizes an allowance for losses on financing receivables, including both the lease receivable and unguaranteed residual, in an amount equal to the probable losses net of recoveries.  The allowance for losses on the lease receivable is determined based on various factors, including lifetime expected losses determined using macroeconomic forecast assumptions and management judgments applicable to and through the expected life of the portfolios as well as past due receivables, receivable type, and customer risk profile.  Both fixed and revolving receivable loss rates are affected by macroeconomic conditions, including the level of gross domestic product (“GDP”) growth, the level of commercial capital equipment investment, unemployment rates, and the credit quality of the borrower.

[0001571996-21-000007:notes:27]
Generally, expected credit losses as a result of residual value risk on equipment under lease are not considered to be significant primarily because of the existence of a secondary market with respect to the equipment.  The lease agreement also clearly defines applicable return conditions and remedies for non-compliance, to ensure that the leased equipment will be in good operating condition upon return.  Model changes and updates, as well as market strength and product acceptance, are monitored and adjustments are made to residual values in accordance with the significance of any such changes.

[0001571996-21-000007:notes:28]
When an account is deemed to be uncollectible, customer account principal and interest are charged off to the allowance for losses.  While the Company does not generally place financing receivables on non-accrual status during the delinquency period, accrued interest is included in the allowance for loss calculation and, therefore, the Company is adequately reserved in the event of charge off.  Recoveries on receivables previously charged off as uncollectible are recorded to the allowance for financing receivables losses.  The expense associated with the allowance for financing receivables losses is recognized as cost of net revenue.

[0001571996-21-000007:notes:29]
Asset Securitization — The Company transfers certain U.S. and European customer loan and lease payments and associated equipment to Special Purpose Entities (“SPEs”) that meet the definition of a Variable Interest Entity (“VIE”) and are consolidated into the Consolidated Financial Statements.  These SPEs are bankruptcy-remote legal entities with separate assets and liabilities.  The purpose of the SPEs is to facilitate the funding of customer loan and lease payments and associated equipment in the capital markets.  These SPEs have entered into financing arrangements with multi-seller conduits that, in turn, issue asset-backed debt securities in the capital markets.  The asset securitizations in the SPEs are accounted for as secured borrowings.  See Note 4 of the Notes to the Consolidated Financial Statements for additional information on the impact of the consolidation.

[0001571996-21-000007:notes:30]
Inventories — Inventories are stated at the lower of cost or net realizable value, with cost being determined on a first-in, first-out basis.  Adjustments to reduce the cost of inventory to its net realizable value are made, if required, for estimated excess, obsolescence, or impaired balances.  At the point of the loss recognition, a new, lower cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis.

[0001571996-21-000007:notes:31]
Property, Plant, and Equipment — Property, plant, and equipment are carried at depreciated cost.  Depreciation is determined using the straight-line method over the shorter of the estimated economic lives of the assets or the lease term, as applicable.  The estimated useful lives of the Company’s property, plant, and equipment are generally as follows:

[0001571996-21-000007:notes:32]
|  | Estimated Useful Life |
| Computer equipment | 3-5 years |
| Equipment under operating leases | Term of underlying lease contract |
| Buildings | 10-30 years or term of underlying land lease |
| Leasehold improvements | Shorter of 5-20 years or lease term |
| Machinery and equipment | 3-5 years |

[0001571996-21-000007:notes:33]
Gains or losses related to retirements or dispositions of fixed assets are recognized in the period during which the retirement or disposition occurs.

[0001571996-21-000007:notes:34]
Capitalized Software Development Costs — Software development costs related to the development of new product offerings are capitalized subsequent to the establishment of technological feasibility, which is demonstrated by the completion of a detailed program design or working model, if no program design is completed.  The Company amortizes capitalized costs on a straight-line basis over the estimated useful lives of the products, which generally range from two to four years.

[0001571996-21-000007:notes:35]
As of January 29, 2021 and January 31, 2020, capitalized software development costs were $610 million and $679 million, respectively, and are included in other non-current assets, net in the accompanying Consolidated Statements of Financial Position.  Amortization expense for the fiscal years ended January 29, 2021, January 31, 2020, and February 1, 2019 was $315 million, $273 million, and $211 million, respectively.

[0001571996-21-000007:notes:36]
The Company capitalizes certain internal and external costs to acquire or create internal use software which are incurred subsequent to the completion of the preliminary project stage.  Development costs are generally amortized on a straight-line basis over five years.  Costs associated with maintenance and minor enhancements to the features and functionality of the Company’s internal use software, including its website are expensed as incurred.

[0001571996-21-000007:notes:37]
Impairment of Long-Lived Assets — The Company reviews long-lived assets for impairment when events or changes in circumstances indicate the carrying amount of an asset may not be recoverable.  The Company assesses the recoverability of the assets based on the undiscounted future cash flows expected from the use and eventual disposition of the asset.  If the carrying amount of the asset is determined not to be recoverable, a write-down to fair value is recorded.  Fair values are determined based on quoted market values, discounted cash flows, or external appraisals, as applicable.  Long-lived assets to be disposed of are reported at the lower of carrying amount or fair value less costs to sell.

[0001571996-21-000007:notes:38]
Business Combinations — The assets and liabilities of acquired businesses are recorded at their fair values at the date of acquisition.  The excess of the purchase price over the fair value of the tangible and intangible assets acquired and the liabilities assumed is recorded as goodwill.  During the measurement period, which expires one year from the acquisition date, if new information is obtained about facts and circumstances that existed as of the acquisition date, cumulative changes in the estimated fair values of the net assets recorded may change the amount of the purchase price allocable to goodwill.  If material, the amount will be adjusted in the reporting period in which the adjustment amount is determined.  See Note 8 of the Notes to the Consolidated Financial Statements for more information on business combinations.

[0001571996-21-000007:notes:39]
In-process research and development costs are recorded at fair value as an indefinite-lived intangible asset and assessed for impairment thereafter until completion, at which point the asset is amortized over its expected useful life.  All acquisition costs are expensed as incurred, and the results of operations of acquired businesses are included in the Consolidated Financial Statements from the acquisition date.

[0001571996-21-000007:notes:40]
Intangible Assets Including Goodwill — Identifiable intangible assets with finite lives are amortized over their estimated useful lives.  Definite-lived intangible assets are reviewed for impairment when events and circumstances indicate the asset may be impaired.  Goodwill and indefinite-lived intangible assets are tested for impairment annually during the third fiscal quarter and whenever events or circumstances indicate that an impairment may have occurred.

[0001571996-21-000007:notes:41]
Foreign Currency Translation — The majority of the Company’s international sales are made by international subsidiaries, some of which have the U.S. Dollar as their functional currency.  The Company’s subsidiaries that do not use the U.S. Dollar as their functional currency translate assets and liabilities at current exchange rates in effect at the balance sheet date.  Revenue and expenses from these international subsidiaries are translated using either the monthly average exchange rates in effect for the period in which the activity was recognized or the specific daily exchange rate associated with the date the transactions actually occur.  Foreign currency translation adjustments are included as a component of accumulated other comprehensive income (loss) (“OCI”) in stockholders’ equity (deficit).

[0001571996-21-000007:notes:42]
Local currency transactions of international subsidiaries that have the U.S. Dollar as their functional currency are remeasured into U.S. Dollars using the current rates of exchange for monetary assets and liabilities and historical rates of exchange for nonmonetary assets and liabilities.  Gains and losses from remeasurement of monetary assets and liabilities are included in interest and other, net on the Consolidated Statements of Income (Loss).  See Note 20 of the Notes to the Consolidated Financial Statements for amounts recognized from remeasurement during the periods presented.

[0001571996-21-000007:notes:43]
Hedging Instruments — The Company uses derivative financial instruments, primarily forward contracts, options, and swaps, to hedge certain foreign currency and interest rate exposures.  The relationships between hedging instruments and hedged items, as well as the risk management objectives and strategies for undertaking hedge transactions, are formally documented.  The Company does not use derivatives for speculative purposes.  All derivative instruments are recognized as either assets or liabilities in the Consolidated Statements of Financial Position and are measured at fair value.

[0001571996-21-000007:notes:44]
The Company’s hedge portfolio includes non-designated derivatives and derivatives designated as cash flow hedges.  For derivative instruments that are designated as cash flow hedges, the Company assesses hedge effectiveness at the onset of the hedge, then performs qualitative assessments at regular intervals throughout the life of the derivative.  The gain or loss on cash flow hedges is recorded in accumulated other comprehensive income (loss), as a separate component of stockholders’ equity (deficit), and reclassified into earnings in the period during which the hedged transaction is recognized in earnings.  For derivatives that are not designated as hedges or do not qualify for hedge accounting treatment, the Company recognizes the change in the instrument’s fair value currently in earnings as a component of interest and other, net.

[0001571996-21-000007:notes:45]
Cash flows from derivative instruments are presented in the same category on the Consolidated Statements of Cash Flows as the cash flows from the underlying hedged items.  See Note 7 of the Notes to the Consolidated Financial Statements for a description of the Company’s derivative financial instrument activities.

[0001571996-21-000007:notes:46]
Revenue Recognition — The Company sells a wide portfolio of products and services to its customers.  The Company’s agreements have varying requirements depending on the goods and services being sold, the rights and obligations conveyed, and the legal jurisdiction of the arrangement.

[0001571996-21-000007:notes:47]
Revenue is recognized for these arrangements based on the following five steps:

[0001571996-21-000007:notes:48]
(1)    Identify the contract with a customer.  The Company evaluates facts and circumstances regarding sales transactions in order to identify contracts with its customers.  An agreement must meet all of the following criteria to qualify as a contract eligible for revenue recognition under the model:  (i) the contract must be approved by all parties who are committed to perform their respective obligations; (ii) each party’s rights regarding the goods and services to be transferred to the customer can be identified; (iii) the payment terms for the goods and services can be identified; (iv) the customer has the ability and intent to pay and it is probable that the Company will collect substantially all of the consideration to which it will be entitled; and (v) the contract must have commercial substance.  Judgment is used in determining the customer’s ability and intent to pay, which is based upon various factors, including the customer’s historical payment experience or customer credit and financial information.

[0001571996-21-000007:notes:49]
(2)    Identify the performance obligations in the contract.  The Company’s contracts with customers often include the promise to transfer multiple goods and services to the customer.  Distinct promises within a contract are referred to as “performance obligations” and are accounted for as separate units of account.  The Company assesses whether each promised good or service is distinct for the purpose of identifying the performance obligations in the contract.  This assessment involves subjective determinations and requires management to make judgments about the individual promised goods or services and whether such goods or services are separable from the other aspects of the contractual relationship.  Promised goods and services are considered distinct provided that: (i) the customer can benefit from the good or service either on its own or together with other resources that are readily available to the customer (that is, the good or service is capable of being distinct); and (ii) the Company’s promise to transfer the good or service to the customer is separately identifiable from other promises in the contract (that is, the promise to transfer the good or service is distinct within the context of the contract).  The Company’s performance obligations include various distinct goods and services such as hardware, software licenses, support and maintenance agreements, and other service offerings and solutions.  Promised goods and services are explicitly identified in the Company’s contracts and may be sold on a standalone basis or bundled as part of a combined solution.  In certain hardware solutions, the hardware is highly interdependent on, and interrelated with, the embedded software.  In these offerings, the hardware and software licenses are accounted for as a single performance obligation.

[0001571996-21-000007:notes:50]
(3)    Determine the transaction price.  The transaction price reflects the amount of consideration to which the Company expects to be entitled in exchange for transferring goods or services to the customer.  If the consideration promised in a contract includes a variable amount, the Company estimates the amount to which it expects to be entitled using either the expected value or most likely amount method.  Generally, volume discounts, rebates, and sales returns reduce the transaction price.  In determining the transaction price, the Company only includes amounts that are not subject to significant future reversal.

[0001571996-21-000007:notes:51]
(4)    Allocate the transaction price to performance obligations in the contract.  When a contract includes multiple performance obligations, the transaction price is allocated to each performance obligation in an amount that depicts the consideration to which the Company expects to be entitled in exchange for transferring the promised goods or services.  For contracts with multiple performance obligations, the transaction price is allocated in proportion to the standalone selling price (“SSP”) of each performance obligation.

[0001571996-21-000007:notes:52]
The best evidence of SSP is the observable price of a good or service when the Company sells that good or service separately in similar circumstances to similar customers.  If a directly observable price is available, the Company will utilize that price for the SSP.  If a directly observable price is not available, the SSP must be estimated.  The Company estimates SSP by considering multiple factors, including, but not limited to, pricing practices, internal costs, and profit objectives as well as overall market conditions, which include geographic or regional specific factors, competitive positioning, and competitor actions.

[0001571996-21-000007:notes:53]
(5)    Recognize revenue when (or as) the performance obligation is satisfied.  Revenue is recognized when obligations under the terms of the contract with the Company’s customer are satisfied.  Revenue is recognized either over time or at a point in time, depending on when the underlying products or services are transferred to the customer.  Revenue is recognized at a point in time for products upon transfer of control.  Revenue is recognized over time for support and deployment services, software support, software-as-a-service (“SaaS”), and infrastructure-as-a-service (“IaaS”).  Revenue is recognized either over time or at a point in time for professional services and training depending on the nature of the offering to the customer.

[0001571996-21-000007:notes:54]
The Company reports revenue net of any revenue-based taxes assessed by governmental authorities that are imposed on and concurrently with specific revenue-producing transactions.

[0001571996-21-000007:notes:55]
The Company has elected the following practical expedients:

[0001571996-21-000007:notes:56]
•The Company does not account for significant financing components if the period between revenue recognition and when the customer pays for the product or service will be one year or less.

[0001571996-21-000007:notes:57]
•The Company recognizes revenue equal to the amount it has a right to invoice when the amount corresponds directly with the value to the customer of the Company’s performance to date.

[0001571996-21-000007:notes:58]
•The Company does not account for shipping and handling activities as a separate performance obligation, but rather as an activity performed to transfer the promised good.

[0001571996-21-000007:notes:59]
The following summarizes the nature of revenue recognized and the manner in which the Company accounts for sales transactions.

[0001571996-21-000007:notes:60]
Products

[0001571996-21-000007:notes:61]
Product revenue consists of revenue from sales of hardware products, including notebooks and desktop PCs, servers, storage hardware, and other hardware-related devices, as well as revenue from software license sales, including non-essential software applications and third-party software licenses.

[0001571996-21-000007:notes:62]
Revenue from sales of hardware products is recognized when control has transferred to the customer, which typically occurs when the hardware has been shipped to the customer, risk of loss has transferred to the customer, the Company has a present right to payment, and customer acceptance has been satisfied.  Customer acceptance is satisfied if acceptance is obtained from the customer, if all acceptance provisions lapse, or if the Company has evidence that all acceptance provisions will be, or have been, satisfied.  Revenue from software license sales is generally recognized when control has transferred to the customer, which is typically upon shipment, electronic delivery, or when the software is available for download by the customer.  For certain software arrangements in which the customer is granted a right to additional unspecified future software licenses, the Company’s promise to the customer is considered a stand-ready obligation in which the transfer of control and revenue recognition will occur over time.

[0001571996-21-000007:notes:63]
Services

[0001571996-21-000007:notes:64]
Services revenue consists of revenue from sales of support services, including hardware support that extends beyond the Company’s standard warranties, software maintenance, and installation; professional services; training; SaaS; and IaaS.  Revenue associated with undelivered performance obligations is deferred and recognized when or as control is transferred to the customer.  Revenue from fixed-price support or maintenance contracts sold for both hardware and software is recognized on a straight-line basis over the period of performance because the Company is required to provide services at any given time.  Other services revenue is recognized when the Company performs the services and the customer receives and consumes the benefits.

[0001571996-21-000007:notes:65]
Other

[0001571996-21-000007:notes:66]
Revenue from leasing arrangements is not subject to the revenue standard for contracts with customers and remains separately accounted for under existing lease accounting guidance.  The Company records operating lease rental revenue as product revenue on a straight-line basis over the lease term.  The Company records revenue from the sale of equipment under sales-type leases as product revenue in an amount equal to the present value of minimum lease payments at the inception of the lease.  Sales-type leases also produce financing income, which is included in products net revenue in the Consolidated Statements of Income (Loss) and is recognized at effective rates of return over the lease term.  The Company also offers qualified customers fixed-term loans and revolving credit lines for the purchase of products and services offered by the Company.  Financing income attributable to these loans is recognized in products net revenue on an accrual basis.

[0001571996-21-000007:notes:67]
Disaggregation of Revenue — The Company’s revenue is presented on a disaggregated basis on the Consolidated Statements of Income (Loss) and in Note 19 of the Notes to the Consolidated Financial Statements based on an evaluation of disclosures outside of the financial statements, information regularly reviewed by the chief operating decision maker for evaluating the financial performance of operating segments, and other information that is used to evaluate the Company’s financial performance or make resource allocations.  This information includes revenue from products and services, revenue from reportable segments, and revenue by major product categories within the segments.

[0001571996-21-000007:notes:68]
Contract Assets — Contract assets are rights to consideration in exchange for goods or services that the Company has transferred to a customer when such a right is conditional on something other than the passage of time.  Such amounts have been insignificant to date.

[0001571996-21-000007:notes:69]
Contract Liabilities — Contract liabilities primarily consist of deferred revenue.  Deferred revenue is recorded when the Company has a right to invoice or payments have been received for undelivered products or services, or in situations where revenue recognition criteria have not been met.  Deferred revenue primarily includes amounts received in advance for extended warranty services and software maintenance.  Revenue is recognized on these items when the revenue recognition criteria are met, generally resulting in ratable recognition over the contract term.  The Company also has deferred revenue related to undelivered hardware and professional services, consisting of installations and consulting engagements, which are recognized when the Company’s performance obligations under the contract are completed.  See Note 9 of the Notes to the Consolidated Financial Statements for additional information about deferred revenue.

[0001571996-21-000007:notes:70]
Costs to Obtain a Contract — The Company capitalizes incremental direct costs to obtain a contract, primarily sales commissions and employer taxes related to commission payments, if the costs are deemed to be recoverable.  The Company has elected, as a practical expedient, to expense as incurred costs to obtain a contract equal to or less than one year in duration.  Capitalized costs are deferred and amortized over the period of contract performance or the estimated life of the customer relationship, if renewals are expected, and are typically amortized over an average period of three to seven years.  Amortization expense is recognized on a straight-line basis and included in selling, general, and administrative expenses in the Consolidated Statements of Income (Loss).

[0001571996-21-000007:notes:71]
The Company periodically reviews these deferred costs to determine whether events or changes in circumstances have occurred that could impact the carrying value or period of benefit of the deferred sales commissions. There were no material impairment losses for deferred costs to obtain a contract during the fiscal years ended January 29, 2021, January 31, 2020, and February 1, 2019.

[0001571996-21-000007:notes:72]
Deferred costs to obtain a contract as of January 29, 2021 and January 31, 2020 were $1.8 billion and $1.6 billion, respectively.  Deferred costs to obtain a contract are classified as current assets and other non-current assets on the Consolidated Statements of Financial Position, based on when the expense is expected to be recognized.  Amortization of costs to obtain a contract during the fiscal years ended January 29, 2021, January 31, 2020, and February 1, 2019 was $768 million, $675 million, and $517 million, respectively.

[0001571996-21-000007:notes:73]
Standard Warranty Liabilities — The Company records warranty liabilities for estimated costs of fulfilling its obligations under standard limited hardware and software warranties at the time of sale.  The liability for standard warranties is included in accrued and other current and other non-current liabilities in the Consolidated Statements of Financial Position.  The specific warranty terms and conditions vary depending upon the product sold and the country in which the Company does business, but generally includes technical support, parts, and labor over a period ranging from one to three years.  Factors that affect the Company’s warranty liability include the number of installed units currently under warranty, historical and anticipated rates of warranty claims on those units, and cost per claim to satisfy the Company’s warranty obligation.  The anticipated rate of warranty claims is the primary factor impacting the estimated warranty obligation.  The other factors are less significant due to the fact that the average remaining aggregate warranty period of the covered installed base is approximately 18 months, repair parts are generally already in stock or available at pre-determined prices, and labor rates are generally arranged at preestablished amounts with service providers.  Warranty claims are relatively predictable based on historical experience of failure rates.  If actual results differ from the estimates, the Company revises its estimated warranty liability.  Each quarter, the Company reevaluates its estimates to assess the adequacy of its recorded warranty liabilities and adjusts the amounts as necessary.

[0001571996-21-000007:notes:74]
Vendor Rebates and Settlements — The Company may receive consideration from vendors in the normal course of business.  Certain of these funds are rebates of purchase price paid and others are related to reimbursement of costs incurred by the Company to sell the vendor’s products.  The Company recognizes a reduction of cost of goods sold if the funds are determined to be a reduction of the price of the vendor’s products.  If the consideration is a reimbursement of costs incurred by the Company to sell or develop the vendor’s products, then the consideration is classified as a reduction of such costs, most often operating expenses, in the Consolidated Statements of Income (Loss).  In order to be recognized as a reduction of operating expenses, the reimbursement must be for a specific, incremental, and identifiable cost incurred by the Company in selling the vendor’s products or services.

[0001571996-21-000007:notes:75]
In addition, the Company may settle commercial disputes with vendors from time to time.  Claims for loss recoveries are recognized when a loss event has occurred, recovery is considered probable, the agreement is finalized, and collectibility is assured.  Amounts received by the Company from vendors for loss recoveries are generally recorded as a reduction of cost of goods sold.

[0001571996-21-000007:notes:76]
Loss Contingencies — The Company is subject to the possibility of various losses arising in the ordinary course of business.  The Company considers the likelihood of loss or impairment of an asset or the incurrence of a liability, as well as the Company’s ability to reasonably estimate the amount of loss, in determining loss contingencies.  An estimated loss contingency is accrued when it is probable that an asset has been impaired or a liability has been incurred and the amount of loss can be reasonably estimated.  The Company regularly evaluates current information available to determine whether such accruals should be adjusted and whether new accruals are required.

[0001571996-21-000007:notes:77]
Shipping Costs — The Company’s shipping and handling costs are included in cost of net revenue in the Consolidated Statements of Income (Loss).

[0001571996-21-000007:notes:78]
Selling, General, and Administrative — Selling expenses include items such as sales salaries and commissions, marketing and advertising costs, contractor services, and allowance for expected credit losses.  Advertising costs are expensed as incurred in selling, general, and administrative expenses in the Consolidated Statements of Income (Loss).  For the fiscal years ended January 29, 2021, January 31, 2020, and February 1, 2019, advertising expenses were $1.3 billion, $1.3 billion, and $1.1 billion, respectively.  General and administrative expenses include items for the Company’s administrative functions, such as finance, legal, human resources, and information technology support.  These functions include costs for items such as salaries and benefits and other personnel-related costs, maintenance and supplies, outside services, intangible asset amortization, and depreciation expense.

[0001571996-21-000007:notes:79]
Research and Development — Research and development (“R&D”) costs are expensed as incurred.  R&D costs include salaries and benefits and other personnel-related costs associated with product development.  Also included in R&D expenses are infrastructure costs, which consist of equipment and material costs, facilities-related costs, and depreciation expense.

[0001571996-21-000007:notes:80]
Income Taxes — Deferred tax assets and liabilities are recorded based on the difference between the financial statement and tax basis of assets and liabilities using enacted tax rates in effect for the year in which the differences are expected to reverse.  The Company calculates a provision for income taxes using the asset and liability method, under which deferred tax assets and liabilities are recognized by identifying the temporary differences arising from the different treatment of items for tax and accounting purposes.  The Company accounts for the tax impact of including Global Intangible Low-Taxed Income (GILTI) in U.S. taxable income as a period cost.  The Company provides valuation allowances for deferred tax assets, where appropriate.  In assessing the need for a valuation allowance, the Company considers all available evidence for each jurisdiction, including past operating results, estimates of future taxable income, and the feasibility of ongoing tax planning strategies.  In the event the Company determines that all or part of the net deferred tax assets are not realizable in the future, the Company will make an adjustment to the valuation allowance that will be charged to earnings in the period in which such a determination is made.

[0001571996-21-000007:notes:81]
The accounting guidance for uncertainties in income tax prescribes a comprehensive model for the financial statement recognition, measurement, presentation, and disclosure of uncertain tax positions taken or expected to be taken in income tax returns.  The Company recognizes a tax benefit from an uncertain tax position in the financial statements only when it is more likely than not that the position will be sustained upon examination, including resolution of any related appeals or litigation processes, based on the technical merits and a consideration of the relevant taxing authority’s administrative practices and precedents.

[0001571996-21-000007:notes:82]
Stock-Based Compensation — The Company measures stock-based compensation expense for all share-based awards granted based on the estimated fair value of those awards at grant date.  The Company estimates the fair value of service-based stock options using the Black-Scholes valuation model.  To estimate the fair value of performance-based awards containing a market condition, the Company uses the Monte Carlo valuation model.  The fair value of all other share-based awards is based on the closing price of the Class C Common Stock as reported on the NYSE on the date of grant.

[0001571996-21-000007:notes:83]
The compensation cost of service-based stock options, restricted stock, and restricted stock units is recognized net of any estimated forfeitures on a straight-line basis over the employee requisite service period.  Compensation cost for performance-based awards is recognized on a graded accelerated basis net of estimated forfeitures over the requisite service period.  Forfeiture rates are estimated at grant date based on historical experience and adjusted in subsequent periods for differences in actual forfeitures from those estimates.  See Note 16 of the Notes to the Consolidated Financial Statements for further discussion of stock-based compensation.

[0001571996-21-000007:notes:84]
Recently Issued Accounting Pronouncements

[0001571996-21-000007:notes:85]
Reference Rate Reform — In March 2020, the Financial Accounting Standards Board (“FASB”) issued guidance which provides temporary optional expedients and exceptions to GAAP guidance on contract modifications and certain hedging relationships to ease the financial reporting burdens related to the expected market transition from the London Interbank Offered Rate to alternative reference rates.  The Company may elect to apply the amendments prospectively through December 31, 2022.  Adoption of the new guidance is not expected to have a material impact on the Company’s financial results.

[0001571996-21-000007:notes:86]
Accounting for Convertible Instruments and Contracts in an Entity’s Own Equity — In August 2020, the FASB issued guidance to simplify the accounting for convertible debt instruments and convertible preferred stock, and the derivatives scope exception for contracts in an entity's own equity.  In addition, the guidance on calculating diluted earnings per share has been simplified and made more internally consistent.  Public entities must adopt the new guidance for fiscal years beginning after December 15, 2021, and interim periods within those fiscal years, with early adoption permitted for fiscal periods beginning after December 15, 2020.  The Company will early adopt this guidance for the fiscal year beginning January 30, 2021 on a modified retrospective basis.  Adoption of the new guidance is not expected to have a material impact on the Company’s financial results.

[0001571996-21-000007:notes:87]
Simplifying Accounting for Income Taxes — In December 2019, the FASB issued guidance to simplify the accounting for income taxes by removing certain exceptions to the general principles in Topic 740, Income Taxes, and by clarifying and amending existing guidance in order to improve consistent application of GAAP for other areas of Topic 740.  Public entities must adopt the new guidance for fiscal years beginning after December 15, 2020, and interim periods within those fiscal years, with early adoption permitted for fiscal periods beginning after December 15, 2019.  The Company will adopt this guidance for the fiscal year beginning January 30, 2021.  Adoption of the new guidance is not expected to have a material impact on the Company’s financial results.

[0001571996-21-000007:notes:88]
Recently Adopted Accounting Pronouncements

[0001571996-21-000007:notes:89]
Measurement of Credit Losses on Financial Instruments — In June 2016, the FASB issued amended guidance which replaced the current incurred loss impairment methodology for measurement of credit losses on financial instruments with a methodology (the “current expected credit losses model” or “CECL model”) that reflects expected credit losses and requires consideration of a broader range of reasonable and supportable information to inform credit loss estimates.  Under the CECL model, the allowance for losses on financial assets, measured at amortized cost, reflects management’s estimate of credit losses over the remaining expected life of such assets.

[0001571996-21-000007:notes:90]
The Company adopted the standard (the “new CECL standard”) as of February 1, 2020 using the modified retrospective method, with the cumulative-effect adjustment to the opening balance of stockholders’ equity (deficit) as of the adoption date.  The cumulative effect of adopting the new CECL standard resulted in an increase of $111 million and $27 million to the allowance for expected credit losses within financing receivables, net and accounts receivable, net, respectively, on the Consolidated Statements of Financial Position, and a corresponding decrease of $28 million to other non-current liabilities related to deferred taxes and $110 million to stockholders’ equity (deficit) as of February 1, 2020.  See Note 2, Note 4, and Note 20 of the Notes to the Consolidated Financial Statements for additional information about the Company’s allowance for financing receivables losses and allowance for expected credit losses of accounts receivable.

[0001571996-21-000007:notes:91]
Intangibles - Goodwill and Other - Internal-Use Software — In August 2018, the FASB issued guidance on a customer’s accounting for implementation costs incurred in a cloud-computing arrangement when hosted by a vendor.  The guidance provides that, in a hosting arrangement that is a service contract, certain implementation costs should be capitalized and amortized over the term of the arrangement.  The Company adopted the standard during the three months ended May 1, 2020 using the prospective method.  The impact of the adoption of this standard was immaterial to the Consolidated Financial Statements.

[0001571996-21-000007:notes:92]
Leases — In February 2016, the FASB issued amended guidance on the accounting for leasing transactions.  The primary objective of this update is to increase transparency and comparability among organizations by requiring lessees to recognize a lease liability for the obligation to make lease payments and an ROU asset for the right to use the underlying asset for the lease term.  The guidance also results in some changes to lessor accounting and requires additional disclosures about all leasing arrangements.

[0001571996-21-000007:notes:93]
The Company adopted the new lease standard as of February 2, 2019 using the modified retrospective approach, with the cumulative-effect adjustment to the opening balance of stockholders’ equity (deficit) as of the adoption date.  The Company elected to apply the practical expedient using the transition option whereby prior comparative periods were not retrospectively adjusted in the Consolidated Financial Statements.  Accordingly, prior comparative periods have not been adjusted in the Consolidated Financial Statements.  The Company also elected the package of practical expedients that does not require reassessment of initial direct costs, classification of a lease, and definition of a lease.

[0001571996-21-000007:notes:94]
The adoption of the new lease standard resulted in the recognition of $1.6 billion in operating lease liabilities and related right of use (“ROU”) assets on the Consolidated Statements of Financial Position.  The Company recorded an immaterial adjustment to stockholders’ equity (deficit) as of February 2, 2019 to reflect the cumulative effect of adoption of the new lease standard.  As of February 2, 2019, there were no material finance leases for which the Company was a lessee.

[0001571996-21-000007:notes:95]
In the area of lessor accounting, as of February 2, 2019, the Company began to originate operating leases due to the elimination of third-party residual value guarantee insurance from the sales-type lease classification test.  Leases that commenced prior to the adoption of the new lease standard were not reassessed or restated pursuant to the practical expedients elected.  Accordingly, there was no cumulative adjustment to stockholders’ equity (deficit) related to lessor accounting.

[0001571996-21-000007:notes:96]
See Note 4 and Note 5 of the Notes to the Consolidated Financial Statements for additional information about the Company’s leases from a lessor and lessee perspective, respectively.
Revenue from Contracts with Customers — In May 2014, the FASB issued amended guidance on the recognition of revenue from contracts with customers.  The new standard established a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes substantially all of the previous revenue recognition guidance, including industry-specific guidance.  The new standard requires entities to recognize revenue when it transfers promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services.  Further, the new standard requires additional disclosures to help enable users of the financial statements to better understand the nature, amount, timing, risks, and judgments related to revenue recognition and related cash flows from contracts with customers.  Concurrently, the FASB issued guidance on the accounting for costs to fulfill or obtain a customer contract.  The Company adopted these standards during the three months ended May 4, 2018 using the full retrospective method, which requires the Company to recast each prior period presented consistent with the new guidance.  The Company recorded a credit of approximately $1 billion to retained earnings as of January 29, 2016 to reflect the cumulative effect of the adoption. Recognition and Measurement of Financial Assets and Financial Liabilities — In January 2016, the FASB issued amended guidance that generally requires changes in the fair value of equity investments, other than those accounted for under the equity method, to be recognized through net income, rather than other comprehensive income.  For equity investments without readily determinable fair values, the Company is no longer permitted to use the cost method of accounting.  The Company has elected to apply the measurement alternative for those investments.  Under the alternative, the Company measures investments without readily determinable fair values at cost, less impairment, adjusted by observable price changes on a prospective basis.  The Company must make a separate election to use the alternative for each eligible investment and is required to reassess at each reporting period whether an investment qualifies for the alternative.  The Company adopted this standard during the three months ended May 4, 2018.  Adoption of the standard was applied through a cumulative one-time adjustment to accumulated deficit of $56 million for the accumulated unrealized gain previously recorded in other comprehensive income.


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001571996-21-000007:notes:97]
The estimated useful lives of the Company’s property, plant, and equipment are generally as follows:

[0001571996-21-000007:notes:98]
The following table presents the components of the Company’s operating lease portfolio included in Property, plant, and equipment, net as of the dates indicated:

[0001571996-21-000007:notes:99]
|  | January 29, 2021 |  | January 31, 2020 |
|  | (in millions) |
| Equipment under operating lease, gross | $ | 1,746 |  |  | $ | 956 |  |
| Less: accumulated depreciation | (432) |  |  | (116) |  |
| Equipment under operating lease, net | $ | 1,314 |  |  | $ | 840 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0001571996-21-000007:notes:100]
The Company periodically reviews these deferred costs to determine whether events or changes in circumstances have occurred that could impact the carrying value or period of benefit of the deferred sales commissions. There were no material impairment losses for deferred costs to obtain a contract during the fiscal years ended January 29, 2021, January 31, 2020, and February 1, 2019.
Deferred costs to obtain a contract as of January 29, 2021 and January 31, 2020 were $1.8 billion and $1.6 billion, respectively.  Deferred costs to obtain a contract are classified as current assets and other non-current assets on the Consolidated Statements of Financial Position, based on when the expense is expected to be recognized.
Vendor Rebates and Settlements — The Company may receive consideration from vendors in the normal course of business.  Certain of these funds are rebates of purchase price paid and others are related to reimbursement of costs incurred by the Company to sell the vendor’s products.  The Company recognizes a reduction of cost of goods sold if the funds are determined to be a reduction of the price of the vendor’s products.  If the consideration is a reimbursement of costs incurred by the Company to sell or develop the vendor’s products, then the consideration is classified as a reduction of such costs, most often operating expenses, in the Consolidated Statements of Income (Loss).  In order to be recognized as a reduction of operating expenses, the reimbursement must be for a specific, incremental, and identifiable cost incurred by the Company in selling the vendor’s products or services.

[0001571996-21-000007:notes:101]
In addition, the Company may settle commercial disputes with vendors from time to time.  Claims for loss recoveries are recognized when a loss event has occurred, recovery is considered probable, the agreement is finalized, and collectibility is assured.  Amounts received by the Company from vendors for loss recoveries are generally recorded as a reduction of cost of goods sold.
Shipping Costs — The Company’s shipping and handling costs are included in cost of net revenue in the Consolidated Statements of Income (Loss).


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock

[0001571996-21-000007:notes:102]
Loss Contingencies — The Company is subject to the possibility of various losses arising in the ordinary course of business.  The Company considers the likelihood of loss or impairment of an asset or the incurrence of a liability, as well as the Company’s ability to reasonably estimate the amount of loss, in determining loss contingencies.  An estimated loss contingency is accrued when it is probable that an asset has been impaired or a liability has been incurred and the amount of loss can be reasonably estimated.  The Company regularly evaluates current information available to determine whether such accruals should be adjusted and whether new accruals are required.The Company accrues a liability when it believes that it is both probable that a liability has been incurred and that it can reasonably estimate the amount of the loss.  The Company reviews these accruals at least quarterly and adjusts them to reflect ongoing negotiations, settlements, rulings, advice of legal counsel, and other relevant information.  To the extent new information is obtained and the Company’s views on the probable outcomes of claims, suits, assessments, investigations, or legal proceedings change, changes in the Company’s accrued liabilities would be recorded in the period in which such a determination is made.  For some matters, the amount of liability is not probable or the amount cannot be reasonably estimated and therefore accruals have not been made.


## us-gaap:FairValueDisclosuresTextBlock

[0001571996-21-000007:notes:103]
NOTE 3 — FAIR VALUE MEASUREMENTS AND INVESTMENTS

[0001571996-21-000007:notes:104]
The following table presents the Company’s hierarchy for its assets and liabilities measured at fair value on a recurring basis as of the dates indicated:

[0001571996-21-000007:notes:105]
|  | January 29, 2021 |  | January 31, 2020 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | Quoted Prices in Active Markets for Identical Assets |  | Significant Other Observable Inputs |  | Significant Unobservable Inputs |  |  |  | Quoted Prices in Active Markets for Identical Assets |  | Significant Other Observable Inputs |  | Significant Unobservable Inputs |  |  |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 8,846 |  |  | $ | — |  |  | $ | — |  |  | $ | 8,846 |  |  | $ | 4,621 |  |  | $ | — |  |  | $ | — |  |  | $ | 4,621 |  |
| Equity and other securities | 449 |  |  | — |  |  | — |  |  | 449 |  |  | 12 |  |  | — |  |  | — |  |  | 12 |  |
| Derivative instruments | — |  |  | 104 |  |  | — |  |  | 104 |  |  | — |  |  | 81 |  |  | — |  |  | 81 |  |
| Total assets | $ | 9,295 |  |  | $ | 104 |  |  | $ | — |  |  | $ | 9,399 |  |  | $ | 4,633 |  |  | $ | 81 |  |  | $ | — |  |  | $ | 4,714 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative instruments | $ | — |  |  | $ | 133 |  |  | $ | — |  |  | $ | 133 |  |  | $ | — |  |  | $ | 68 |  |  | $ | — |  |  | $ | 68 |  |
| Total liabilities | $ | — |  |  | $ | 133 |  |  | $ | — |  |  | $ | 133 |  |  | $ | — |  |  | $ | 68 |  |  | $ | — |  |  | $ | 68 |  |

[0001571996-21-000007:notes:106]
The following section describes the valuation methodologies the Company uses to measure financial instruments at fair value:

[0001571996-21-000007:notes:107]
Money Market Funds — The Company’s investment in money market funds that are classified as cash equivalents hold underlying investments with a weighted average maturity of 90 days or less and are recognized at fair value.  The valuations of these securities are based on quoted prices in active markets for identical assets, when available, or pricing models whereby all significant inputs are observable or can be derived from or corroborated by observable market data.  The Company reviews security pricing and assesses liquidity on a quarterly basis.  As of January 29, 2021, the Company’s U.S. portfolio had no material exposure to money market funds with a fluctuating net asset value.

[0001571996-21-000007:notes:108]
Equity and Other Securities — The majority of the Company’s investments in equity and other securities that are measured at fair value on a recurring basis consist of strategic investments in publicly-traded companies.  The valuation of these securities is based on quoted prices in active markets.

[0001571996-21-000007:notes:109]
Derivative Instruments — The Company’s derivative financial instruments consist primarily of foreign currency forward and purchased option contracts and interest rate swaps.  The fair value of the portfolio is determined using valuation models based on market observable inputs, including interest rate curves, forward and spot prices for currencies, and implied volatilities.  Credit risk is also factored into the fair value calculation of the Company’s derivative financial instrument portfolio.  See Note 7 of the Notes to the Consolidated Financial Statements for a description of the Company’s derivative financial instrument activities.

[0001571996-21-000007:notes:110]
Deferred Compensation Plans —The Company offers deferred compensation plans for eligible employees, which allow participants to defer payment for a portion of their compensation.  Assets were the same as liabilities associated with the plans at approximately $308 million and $241 million as of January 29, 2021 and January 31, 2020, respectively, and are included in other assets and other liabilities on the Consolidated Statements of Financial Position.  The net impact to the Consolidated Statements of Income (Loss) is not material since changes in the fair value of the assets substantially offset changes in the fair value of the liabilities.  As such, assets and liabilities associated with these plans have not been included in the recurring fair value table above.

[0001571996-21-000007:notes:111]
Assets and Liabilities Measured at Fair Value on a Nonrecurring Basis — Certain assets are measured at fair value on a nonrecurring basis and therefore are not included in the recurring fair value table above.  These assets consist primarily of non-financial assets such as goodwill and intangible assets.  See Note 8 of the Notes to the Consolidated Financial Statements for additional information about goodwill and intangible assets.

[0001571996-21-000007:notes:112]
As of January 29, 2021 and January 31, 2020, the Company held private strategic investments of $990 million and $852 million, respectively.  As these investments represent early-stage companies without readily determinable fair values, they are not included in the recurring fair value table above.

[0001571996-21-000007:notes:113]
The Company has elected to apply the measurement alternative for these investments.  Under the alternative, the Company measures investments without readily determinable fair values at cost, less impairment, adjusted by observable price changes.  The Company must make a separate election to use the alternative for each eligible investment and is required to reassess at each reporting period whether an investment qualifies for the alternative.  In evaluating these investments for impairment or observable price changes, the Company uses inputs including pre- and post-money valuations of recent financing events and the impact of those events on its fully diluted ownership percentages, as well as other available information regarding the issuer’s historical and forecasted performance.

[0001571996-21-000007:notes:114]
Carrying Value and Estimated Fair Value of Outstanding Debt — The following table presents the carrying value and estimated fair value of the Company’s outstanding debt as described in Note 6 of the Notes to the Consolidated Financial Statements, including the current portion, as of the dates indicated:

[0001571996-21-000007:notes:115]
|  | January 29, 2021 |  | January 31, 2020 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Secured Credit Facilities | $ | 6.2 |  |  | $ | 6.3 |  |  | $ | 8.8 |  |  | $ | 9.0 |  |
| First Lien Notes | $ | 18.3 |  |  | $ | 22.8 |  |  | $ | 20.5 |  |  | $ | 23.9 |  |
| Unsecured Notes and Debentures | $ | 1.2 |  |  | $ | 1.6 |  |  | $ | 1.2 |  |  | $ | 1.5 |  |
| Senior Notes | $ | 2.7 |  |  | $ | 2.8 |  |  | $ | 2.6 |  |  | $ | 2.8 |  |
| EMC Notes | $ | 1.0 |  |  | $ | 1.0 |  |  | $ | 1.6 |  |  | $ | 1.6 |  |
| VMware Notes and VMware Term Loan Facility | $ | 4.7 |  |  | $ | 5.3 |  |  | $ | 5.5 |  |  | $ | 5.6 |  |
| Margin Loan Facility | $ | 4.0 |  |  | $ | 3.9 |  |  | $ | 4.0 |  |  | $ | 3.9 |  |

[0001571996-21-000007:notes:116]
The fair values of the outstanding debt shown in the table above, as well as the DFS debt described in Note 4 of the Notes to the Consolidated Financial Statements, were determined based on observable market prices in a less active market or based on valuation methodologies using observable inputs and were categorized as Level 2 in the fair value hierarchy.  The carrying value of DFS debt approximates fair value.

[0001571996-21-000007:notes:117]
Investments

[0001571996-21-000007:notes:118]
The following table presents the carrying value of the Company’s investments as of the dates indicated:

[0001571996-21-000007:notes:119]
|  | January 29, 2021 |  | January 31, 2020 |
|  | Cost |  | Unrealized Gain |  | Unrealized (Loss) |  | Carrying Value |  | Cost |  | Unrealized Gain |  | Unrealized (Loss) |  | Carrying Value |
|  | (in millions) |
| Equity and other securities | $ | 907 |  |  | $ | 677 |  |  | $ | (145) |  |  | $ | 1,439 |  |  | $ | 783 |  |  | $ | 116 |  |  | $ | (35) |  |  | $ | 864 |  |
| Fixed income debt securities | 176 |  |  | 9 |  |  | — |  |  | 185 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total securities |  |  |  |  |  |  | $ | 1,624 |  |  |  |  |  |  |  |  | $ | 864 |  |

[0001571996-21-000007:notes:120]
Equity and other securities — The Company has strategic investments in publicly-traded and privately-held companies. For the fiscal year ended January 29, 2021, the equity and other securities without readily determinable fair values of $990 million increased by $200 million, due to upward adjustments for observable price changes, offset by $74 million of downward adjustments primarily attributable to impairments.  For the fiscal year ended January 31, 2020, the equity and other securities without readily determinable fair values increased by $110 million due to upward adjustments for observable price changes, offset by $15 million of downward adjustments that were primarily attributable to impairments.  The remainder of equity and other securities consisted of publicly-traded investments that are measured at fair value on a recurring basis for both the fiscal years ended January 29, 2021 and January 31, 2020.

[0001571996-21-000007:notes:121]
In September 2020, one of the Company’s strategic investments, which previously did not have a readily determinable fair value, completed its initial public offering which resulted in the investment having a readily determinable fair value and in the recognition of an unrealized net gain of $396 million during the fiscal year ended January 29, 2021, which is reflected in the table above.  The unrealized net gain was reflected in Interest and other, net on the Consolidated Statements of Income (Loss) and in Other, net as a non-cash adjustment within cash flows from operating activities on the Consolidated Statements of Cash Flows.  As of January 29, 2021, the carrying value of this investment was $428 million.

[0001571996-21-000007:notes:122]
Fixed income debt securities — The Company has fixed income debt securities carried at amortized cost.  The debt securities are held as collateral for borrowings.  The Company intends to hold the investments to maturity.  Unrealized gains represent foreign currency impacts.


## dell:CreditLossFinancialInstrumentLeasesDebtVariableInterestEntitiesAndCustomerReceivablesSalesTextBlock

[0001571996-21-000007:notes:123]
NOTE 4 — FINANCIAL SERVICES

[0001571996-21-000007:notes:124]
The Company offers or arranges various financing options and services, and alternative payment structures for its customers in North America, Europe, Australia, and New Zealand through DFS.  The Company also arranges financing for some of its customers in various countries where DFS does not currently operate as a captive enterprise.  The key activities of DFS include originating, collecting, and servicing customer financing arrangements primarily related to the purchase or use of Dell Technologies products and services.  In some cases, DFS also offers financing for the purchase of third-party technology products that complement the Dell Technologies portfolio of products and services.  New financing originations were $8.9 billion, $8.5 billion, and $7.3 billion for the fiscal years ended January 29, 2021, January 31, 2020, and February 1, 2019, respectively.

[0001571996-21-000007:notes:125]
The Company’s lease and loan arrangements with customers are aggregated into the following categories:

[0001571996-21-000007:notes:126]
Revolving loans — Revolving loans offered under private label credit financing programs provide qualified customers with a revolving credit line for the purchase of products and services offered by Dell Technologies.  These private label credit financing programs are referred to as Dell Preferred Account (“DPA”) and Dell Business Credit (“DBC”).  The DPA product is primarily offered to individual consumer customers, and the DBC product is primarily offered to small and medium-sized commercial customers.  Revolving loans in the United States bear interest at a variable annual percentage rate that is tied to the prime rate.  Based on historical payment patterns, revolving loan transactions are typically repaid within twelve months on average.  Due to the short-term nature of the revolving loan portfolio, the carrying value of the portfolio approximates fair value.

[0001571996-21-000007:notes:127]
Fixed-term leases and loans — The Company enters into financing arrangements with customers who seek lease financing for equipment.  Pursuant to the current lease accounting standard effective February 2, 2019, new DFS leases are classified as sales-type leases, direct financing leases, or operating leases.  When the terms of the DFS lease transfer control of the underlying asset to the lessee, the contract is typically classified as a sales-type lease.  Direct financing leases are immaterial.  All other new DFS leases are classified as operating leases.  Leases that commenced prior to the effective date of the current lease accounting standard continue to be accounted for under previous lease accounting guidance.  Leases with business customers have fixed terms of generally two to four years.

[0001571996-21-000007:notes:128]
The Company also offers fixed-term loans to qualified small businesses, large commercial accounts, governmental organizations, educational entities, and certain individual consumer customers.  These loans are repaid in equal payments including interest and have defined terms of generally three to five years.  The fair value of the fixed-term loan portfolio is determined using market observable inputs.  The carrying value of these loans approximates fair value.

[0001571996-21-000007:notes:129]
Financing Receivables

[0001571996-21-000007:notes:130]
The following table presents the components of the Company’s financing receivables segregated by portfolio segment as of the dates indicated:

[0001571996-21-000007:notes:131]
|  | January 29, 2021 |  | January 31, 2020 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Financing receivables, net: |  |  |  |  |  |  |  |  |  |  |  |
| Customer receivables, gross (a) | $ | 796 |  |  | $ | 9,595 |  |  | $ | 10,391 |  |  | $ | 824 |  |  | $ | 8,486 |  |  | $ | 9,310 |  |
| Allowances for losses | (148) |  |  | (173) |  |  | (321) |  |  | (70) |  |  | (79) |  |  | (149) |  |
| Customer receivables, net | 648 |  |  | 9,422 |  |  | 10,070 |  |  | 754 |  |  | 8,407 |  |  | 9,161 |  |
| Residual interest | — |  |  | 424 |  |  | 424 |  |  | — |  |  | 582 |  |  | 582 |  |
| Financing receivables, net | $ | 648 |  |  | $ | 9,846 |  |  | $ | 10,494 |  |  | $ | 754 |  |  | $ | 8,989 |  |  | $ | 9,743 |  |
| Short-term | $ | 648 |  |  | $ | 4,507 |  |  | $ | 5,155 |  |  | $ | 754 |  |  | $ | 4,141 |  |  | $ | 4,895 |  |
| Long-term | $ | — |  |  | $ | 5,339 |  |  | $ | 5,339 |  |  | $ | — |  |  | $ | 4,848 |  |  | $ | 4,848 |  |

[0001571996-21-000007:notes:132]
____________________

[0001571996-21-000007:notes:133]
(a)    Customer receivables, gross includes amounts due from customers under revolving loans, fixed-term loans, fixed-term sales-type or direct financing leases, and accrued interest.

[0001571996-21-000007:notes:134]
The allowance for losses as of January 29, 2021 includes the adoption of the new CECL standard, which was adopted as of February 1, 2020 using the modified retrospective method.  Prior period amounts have not been recast.  The provision recognized on the Consolidated Statements of Income (Loss) for the fiscal year ended January 29, 2021 is based on an assessment of the impact of current and expected future economic conditions, inclusive of the effect of the COVID-19 pandemic on credit losses.  The duration and severity of COVID-19 and continued market volatility is highly uncertain and, as such, the impact on expected losses is subject to significant judgment and may cause variability in the Company’s allowance for credit losses in future periods.  See Note 2 of the Notes to the Consolidated Financial Statements for additional information about the new CECL standard.

[0001571996-21-000007:notes:135]
The following table presents the changes in allowance for financing receivable losses for the periods indicated:

[0001571996-21-000007:notes:136]
|  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |  |  |  |  |  |
| Balances as of February 2, 2018 | $ | 81 |  |  | $ | 64 |  |  | $ | 145 |  |
| Charge-offs, net of recoveries | (78) |  |  | (26) |  |  | (104) |  |
| Provision charged to income statement | 72 |  |  | 23 |  |  | 95 |  |
| Balances as of February 1, 2019 | 75 |  |  | 61 |  |  | 136 |  |
| Charge-offs, net of recoveries | (71) |  |  | (23) |  |  | (94) |  |
| Provision charged to income statement | 66 |  |  | 41 |  |  | 107 |  |
| Balances as of January 31, 2020 | 70 |  |  | 79 |  |  | 149 |  |
| Adjustment for adoption of accounting standard (Note 2) | 40 |  |  | 71 |  |  | 111 |  |
| Charge-offs, net of recoveries | (62) |  |  | (29) |  |  | (91) |  |
| Provision charged to income statement | 100 |  |  | 52 |  |  | 152 |  |
| Balances as of January 29, 2021 | $ | 148 |  |  | $ | 173 |  |  | $ | 321 |  |

[0001571996-21-000007:notes:137]
Aging

[0001571996-21-000007:notes:138]
The following table presents the aging of the Company’s customer financing receivables, gross, including accrued interest, segregated by class, as of the dates indicated:

[0001571996-21-000007:notes:139]
|  | January 29, 2021 |  | January 31, 2020 |
|  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |
|  | (in millions) |
| Revolving — DPA | $ | 578 |  |  | $ | 30 |  |  | $ | 13 |  |  | $ | 621 |  |  | $ | 550 |  |  | $ | 51 |  |  | $ | 20 |  |  | $ | 621 |  |
| Revolving — DBC | 157 |  |  | 14 |  |  | 4 |  |  | 175 |  |  | 184 |  |  | 15 |  |  | 4 |  |  | 203 |  |
| Fixed-term — Consumer and Commercial | 9,192 |  |  | 316 |  |  | 87 |  |  | 9,595 |  |  | 8,005 |  |  | 373 |  |  | 108 |  |  | 8,486 |  |
| Total customer receivables, gross | $ | 9,927 |  |  | $ | 360 |  |  | $ | 104 |  |  | $ | 10,391 |  |  | $ | 8,739 |  |  | $ | 439 |  |  | $ | 132 |  |  | $ | 9,310 |  |

[0001571996-21-000007:notes:140]
Aging is likely to fluctuate as a result of the variability in volume of large transactions entered into over the period, and the administrative processes that accompany those transactions.  Aging is also impacted by the timing of the Dell Technologies fiscal period end date relative to calendar month-end customer payment due dates.  As a result of these factors, fluctuations in aging from period to period do not necessarily indicate a material change in the collectibility of the portfolio.

[0001571996-21-000007:notes:141]
Fixed-term consumer and commercial customer receivables are placed on non-accrual status if principal or interest is past due and considered delinquent, or if there is concern about collectibility of a specific customer receivable.  These receivables identified as doubtful for collectibility may be classified as current for aging purposes.  Aged revolving portfolio customer receivables identified as delinquent are charged off.

[0001571996-21-000007:notes:142]
Credit Quality

[0001571996-21-000007:notes:143]
The following tables present customer receivables, gross, including accrued interest, by credit quality indicator segregated by class, as of the dates indicated.  The categories shown in the tables below segregate customer receivables based on the relative degrees of credit risk.  The credit quality indicators for DPA revolving accounts are measured primarily as of each quarter-end date, while all other indicators are generally updated on a periodic basis.  The table presented as of January 31, 2020 was not recast to reflect the impact of the new CECL standard.

[0001571996-21-000007:notes:144]
|  | January 29, 2021 |
|  | Fixed-term — Consumer and Commercial |  |  |  |  |  |  |
|  | Fiscal Year of Origination |  |  |  |  |  |  |
|  | 2021 |  | 2020 |  | 2019 |  | 2018 |  | 2017 |  | Years Prior |  | Revolving — DPA (a) |  | Revolving — DBC (a) |  | Total |
|  | (in millions) |
| Higher | $ | 3,125 |  |  | $ | 1,802 |  |  | $ | 661 |  |  | $ | 166 |  |  | $ | 26 |  |  | $ | — |  |  | $ | 172 |  |  | $ | 47 |  |  | $ | 5,999 |  |
| Mid | 1,121 |  |  | 671 |  |  | 287 |  |  | 73 |  |  | 9 |  |  | — |  |  | 188 |  |  | 52 |  |  | 2,401 |  |
| Lower | 865 |  |  | 499 |  |  | 243 |  |  | 38 |  |  | 9 |  |  | — |  |  | 261 |  |  | 76 |  |  | 1,991 |  |
| Total | $ | 5,111 |  |  | $ | 2,972 |  |  | $ | 1,191 |  |  | $ | 277 |  |  | $ | 44 |  |  | $ | — |  |  | $ | 621 |  |  | $ | 175 |  |  | $ | 10,391 |  |

[0001571996-21-000007:notes:145]
(a)    The revolving portfolio is exempt from the requirement to disclose the amortized cost basis by year of origination since determining the appropriate origination year can be complex due to the nature of the revolving portfolio.

[0001571996-21-000007:notes:146]
|  | January 31, 2020 |
|  | Fixed-term — Consumer and Commercial |  | Revolving — DPA |  | Revolving — DBC |  | Total |
|  | (in millions) |
| Higher | $ | 5,042 |  |  | $ | 137 |  |  | $ | 55 |  |  | $ | 5,234 |  |
| Mid | 2,036 |  |  | 175 |  |  | 63 |  |  | 2,274 |  |
| Lower | 1,408 |  |  | 309 |  |  | 85 |  |  | 1,802 |  |
| Total | $ | 8,486 |  |  | $ | 621 |  |  | $ | 203 |  |  | $ | 9,310 |  |

[0001571996-21-000007:notes:147]
For DPA revolving receivables shown in the table above, the Company makes credit decisions based on proprietary scorecards, which include the customer’s credit history, payment history, credit usage, and other credit agency-related elements.  The higher quality category includes prime accounts generally of a higher credit quality that are comparable to U.S. customer FICO scores of 720 or above.  The mid-category represents the mid-tier accounts that are comparable to U.S. customer FICO scores from 660 to 719.  The lower category is generally sub-prime and represents lower credit quality accounts that are comparable to U.S. customer FICO scores below 660.  For the DBC revolving receivables and fixed-term commercial receivables shown in the table above, an internal grading system is utilized that assigns a credit level score based on a number of considerations, including liquidity, operating performance, and industry outlook.  The grading criteria and classifications for the fixed-term products differ from those for the revolving products as loss experience varies between these product and customer groups.  The credit quality categories cannot be compared between the different classes as loss experience varies substantially between the classes.

[0001571996-21-000007:notes:148]
Leases

[0001571996-21-000007:notes:149]
Interest income on sales-type lease receivables was $270 million and $259 million for the fiscal years ended January 29, 2021 and January 31, 2020, respectively.

[0001571996-21-000007:notes:150]
The following table presents the net revenue, cost of net revenue, and gross margin recognized at the commencement date of sales-type leases for the periods indicated:

[0001571996-21-000007:notes:151]
|  | Fiscal Year Ended |
|  | January 29, 2021 |  | January 31, 2020 |
|  | (in millions) |
| Net revenue — products | $ | 824 |  |  | $ | 770 |  |
| Cost of net revenue — products | 578 |  |  | 582 |  |
| Gross margin — products | $ | 246 |  |  | $ | 188 |  |

[0001571996-21-000007:notes:152]
The following table presents the future maturity of the Company’s fixed-term customer leases and associated financing payments, and reconciles the undiscounted cash flows to the customer receivables, gross recognized on the Consolidated Statements of Financial Position as of the date indicated:

[0001571996-21-000007:notes:153]
|  | January 29, 2021 |
|  | (in millions) |
| Fiscal 2022 | $ | 2,797 |  |
| Fiscal 2023 | 1,660 |  |
| Fiscal 2024 | 931 |  |
| Fiscal 2025 | 354 |  |
| Fiscal 2026 and beyond | 98 |  |
| Total undiscounted cash flows | 5,840 |  |
| Fixed-term loans | 4,440 |  |
| Revolving loans | 796 |  |
| Less: unearned income | (685) |  |
| Total customer receivables, gross | $ | 10,391 |  |

[0001571996-21-000007:notes:154]
Operating Leases

[0001571996-21-000007:notes:155]
Operating lease income relating to lease payments was $452 million and $169 million for the fiscal years ended January 29, 2021 and January 31, 2020, respectively.  Depreciation expense was $334 million and $115 million for the fiscal years ended January 29, 2021 and January 31, 2020, respectively.

[0001571996-21-000007:notes:156]
The following table presents the future payments to be received by the Company as lessor in operating lease contracts as of the date indicated:

[0001571996-21-000007:notes:157]
|  | January 29, 2021 |
|  | (in millions) |
| Fiscal 2022 | $ | 622 |  |
| Fiscal 2023 | 454 |  |
| Fiscal 2024 | 202 |  |
| Fiscal 2025 | 36 |  |
| Fiscal 2026 and beyond | — |  |
| Total | $ | 1,314 |  |

[0001571996-21-000007:notes:158]
DFS Debt

[0001571996-21-000007:notes:159]
The Company maintains programs that facilitate the funding of leases, loans, and other alternative payment structures in the capital markets.  The majority of  DFS debt is non-recourse to Dell Technologies and represents borrowings under securitization programs and structured financing programs, for which the Company’s risk of loss is limited to transferred loan and lease payments and associated equipment.  The following table presents DFS debt as of the dates indicated.  The table excludes the allocated portion of the Company’s other borrowings, which represents the additional amount considered to fund the DFS business.

[0001571996-21-000007:notes:160]
|  | January 29, 2021 |  | January 31, 2020 |
| DFS debt | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing and securitization facilities | $ | 3,311 |  |  | $ | 2,606 |  |
| Fixed-term securitization offerings | 2,961 |  |  | 2,593 |  |
| Other | 140 |  |  | 141 |  |
| Total DFS U.S. debt | 6,412 |  |  | 5,340 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 786 |  |  | 743 |  |
| Other borrowings | 1,006 |  |  | 931 |  |
| Note payable | 250 |  |  | 200 |  |
| Dell Bank Senior Unsecured Eurobonds | 1,212 |  |  | 551 |  |
| Total DFS international debt | 3,254 |  |  | 2,425 |  |
| Total DFS debt | $ | 9,666 |  |  | $ | 7,765 |  |
| Total short-term DFS debt | $ | 4,888 |  |  | $ | 4,152 |  |
| Total long-term DFS debt | $ | 4,778 |  |  | $ | 3,613 |  |

[0001571996-21-000007:notes:161]
DFS U.S. Debt

[0001571996-21-000007:notes:162]
Asset-Based Financing and Securitization Facilities — The Company maintains separate asset-based financing facilities and a securitization facility in the United States, which are revolving facilities for fixed-term leases and loans and for revolving loans, respectively.  This debt is collateralized solely by the U.S. loan and lease payments and associated equipment in the facilities.  The debt has a variable interest rate and the duration of the debt is based on the terms of the underlying loan and lease payment streams.  As of January 29, 2021, the total debt capacity related to the U.S. asset-based financing and securitization facilities was $4.1 billion.  The Company enters into interest swap agreements to effectively convert a portion of this debt from a floating rate to a fixed rate. See Note 7 of the Notes to the Consolidated Financial Statements for additional information about interest rate swaps.

[0001571996-21-000007:notes:163]
The Company’s U.S. securitization facility for revolving loans is effective through June 25, 2022.  The Company’s two U.S. asset-based financing facilities for fixed-term leases and loans are effective through August 22, 2021 and July 26, 2022, respectively.

[0001571996-21-000007:notes:164]
The asset-based financing and securitization facilities contain standard structural features related to the performance of the funded receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the facility, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of January 29, 2021, these criteria were met.

[0001571996-21-000007:notes:165]
Fixed-Term Securitization Offerings — The Company periodically issues asset-backed debt securities under fixed-term securitization programs to private investors.  The asset-backed debt securities are collateralized solely by the U.S. fixed-term leases and loans in the offerings, which are held by Special Purpose Entities (“SPEs”), as discussed below.  The interest rate on these securities is fixed and ranges from 0.31% to 5.92% per annum, and the duration of these securities is based on the terms of the underlying lease and loan payment streams.

[0001571996-21-000007:notes:166]
DFS International Debt

[0001571996-21-000007:notes:167]
Securitization Facility — The Company maintains a securitization facility in Europe for fixed-term leases and loans.  This facility is effective through December 21, 2022 and had a total debt capacity of $970 million as of January 29, 2021.

[0001571996-21-000007:notes:168]
The securitization facility contains standard structural features related to the performance of the securitized receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the program, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of January 29, 2021, these criteria were met.

[0001571996-21-000007:notes:169]
Other Borrowings — In connection with the Company’s international financing operations, the Company has entered into revolving structured financing debt programs related to its fixed-term lease and loan products sold in Canada, Europe, Australia, and New Zealand.  The Canadian facility, which is collateralized solely by Canadian loan and lease payments and associated equipment, had a total debt capacity of $292 million as of January 29, 2021, and is effective through January 16, 2023.  The European facility, which is collateralized solely by European loan and lease payments and associated equipment, had a total debt capacity of $727 million as of January 29, 2021, and is effective through June 14, 2022.  The Australia and New Zealand facility, which is collateralized solely by Australia and New Zealand loan and lease payments and associated equipment, had a total debt capacity of $269 million as of January 29, 2021, and is effective through December 20, 2021.

[0001571996-21-000007:notes:170]
Note Payable — On November 27, 2017, the Company entered into an unsecured credit agreement to fund receivables in Mexico.  As of July 31, 2020, the aggregate principal amount of the note payable was $187 million.  This note was repaid in full during the three months ended October 30, 2020.

[0001571996-21-000007:notes:171]
On August 7, 2020, the Company entered into two new unsecured credit agreements to fund receivables in Mexico.  As of January 29, 2021, the aggregate principal amount of the notes payable was $250 million.  The notes bear interest at 3.37% and will mature on June 1, 2022.

[0001571996-21-000007:notes:172]
Dell Bank Senior Unsecured Eurobonds  — On October 17, 2019, Dell Bank International D.A.C. issued 500 million Euro of 0.625% senior unsecured three year eurobonds due October 2022.  On June 24, 2020, Dell Bank International D.A.C. issued an additional 500 million Euro of 1.625% senior unsecured four year eurobonds due June 2024.  The issuance of the senior unsecured eurobonds supports the expansion of the financing operations in Europe.

[0001571996-21-000007:notes:173]
Variable Interest Entities

[0001571996-21-000007:notes:174]
In connection with the asset-based financing facilities, securitization facilities, and fixed-term securitization offerings discussed above, the Company transfers certain U.S. and European loan and lease payments and associated equipment to SPEs that meet the definition of a Variable Interest Entity (“VIE”) and are consolidated, along with the associated debt detailed above, into the Consolidated Financial Statements, as the Company is the primary beneficiary of the VIEs.  The SPEs are bankruptcy-remote legal entities with separate assets and liabilities.  The purpose of the SPEs is to facilitate the funding of customer loan and lease payments and associated equipment in the capital markets.

[0001571996-21-000007:notes:175]
Some of the SPEs have entered into financing arrangements with multi-seller conduits that, in turn, issue asset-backed debt securities in the capital markets.  DFS debt outstanding held by the consolidated VIEs is collateralized by the loan and lease payments and associated equipment.  The Company’s risk of loss related to securitized receivables is limited to the amount by which the Company’s right to receive collections for assets securitized exceeds the amount required to pay interest, principal, and fees and expenses related to the asset-backed securities.  The Company provides credit enhancement to the securitization in the form of over-collateralization.

[0001571996-21-000007:notes:176]
The following table presents the assets and liabilities held by the consolidated VIEs as of the dates indicated, which are included in the Consolidated Statements of Financial Position:

[0001571996-21-000007:notes:177]
|  | January 29, 2021 |  | January 31, 2020 |
|  | (in millions) |
| Assets held by consolidated VIEs |  |  |  |
| Other current assets | $ | 838 |  |  | $ | 643 |  |
| Financing receivables, net of allowance |  |  |  |
| Short-term | $ | 3,534 |  |  | $ | 3,316 |  |
| Long-term | $ | 3,314 |  |  | $ | 2,913 |  |
| Property, plant, and equipment, net | $ | 792 |  |  | $ | 435 |  |
| Liabilities held by consolidated VIEs |  |  |  |
| Debt, net of unamortized debt issuance costs |  |  |  |
| Short-term | $ | 4,208 |  |  | $ | 3,423 |  |
| Long-term | $ | 2,841 |  |  | $ | 2,509 |  |

[0001571996-21-000007:notes:178]
Loan and lease payments and associated equipment transferred via securitization through SPEs were $6.1 billion and $5.4 billion for the fiscal years ended January 29, 2021 and January 31, 2020, respectively.

[0001571996-21-000007:notes:179]
Customer Receivable Sales

[0001571996-21-000007:notes:180]
To manage certain concentrations of customer credit exposure, the Company may sell selected fixed-term customer receivables to unrelated third parties on a periodic basis, without recourse.  The amount of customer receivables sold for this purpose was $648 million, $538 million, and $949 million for the fiscal years ended January 29, 2021, January 31, 2020, and February 1, 2019, respectively.  The Company’s continuing involvement in the above mentioned customer receivables is primarily limited to servicing arrangements.


## us-gaap:ScheduleOfDebtTableTextBlock

[0001571996-21-000007:notes:181]
The majority of  DFS debt is non-recourse to Dell Technologies and represents borrowings under securitization programs and structured financing programs, for which the Company’s risk of loss is limited to transferred loan and lease payments and associated equipment.  The following table presents DFS debt as of the dates indicated.  The table excludes the allocated portion of the Company’s other borrowings, which represents the additional amount considered to fund the DFS business.

[0001571996-21-000007:notes:182]
The following table summarizes the Company’s outstanding debt as of the dates indicated:

[0001571996-21-000007:notes:183]
|  | January 29, 2021 |  | January 31, 2020 |
|  | (in millions) |
| Secured Debt |  |  |  |
| Senior Secured Credit Facilities: |  |  |  |
| 2.75% Term Loan B-1 Facility due September 2025 | $ | 3,143 |  |  | $ | 4,738 |  |
| 1.90% Term Loan A-4 Facility due December 2023 | — |  |  | 679 |  |
| 1.90% Term Loan A-6 Facility due March 2024 | 3,134 |  |  | 3,497 |  |
| First Lien Notes: |  |  |  |
| 4.42% due June 2021 | — |  |  | 4,500 |  |
| 5.45% due June 2023 | 3,750 |  |  | 3,750 |  |
| 4.00% due July 2024 | 1,000 |  |  | 1,000 |  |
| 5.85% due July 2025 | 1,000 |  |  | — |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 4.90% due October 2026 | 1,750 |  |  | 1,750 |  |
| 6.10% due July 2027 | 500 |  |  | — |  |
| 5.30% due October 2029 | 1,750 |  |  | 1,750 |  |
| 6.20% due July 2030 | 750 |  |  | — |  |
| 8.10% due July 2036 | 1,500 |  |  | 1,500 |  |
| 8.35% due July 2046 | 2,000 |  |  | 2,000 |  |
| Unsecured Debt |  |  |  |
| Unsecured Notes and Debentures: |  |  |  |
| 4.625% due April 2021 | 400 |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| Senior Notes: |  |  |  |
| 5.875% due June 2021 | 1,075 |  |  | 1,075 |  |
| 7.125% due June 2024 | 1,625 |  |  | 1,625 |  |
| EMC Notes: |  |  |  |
| 2.650% due June 2020 | — |  |  | 600 |  |
| 3.375% due June 2023 | 1,000 |  |  | 1,000 |  |
| Debt of Public Subsidiary |  |  |  |
| VMware Notes: |  |  |  |
| 2.30% due August 2020 | — |  |  | 1,250 |  |
| 2.95% due August 2022 | 1,500 |  |  | 1,500 |  |
| 4.50% due May 2025 | 750 |  |  | — |  |
| 4.65% due May 2027 | 500 |  |  | — |  |
| 3.90% due August 2027 | 1,250 |  |  | 1,250 |  |
| 4.70% due May 2030 | 750 |  |  | — |  |
| VMware Term Loan Facility | — |  |  | 1,500 |  |
| DFS Debt (Note 4) | 9,666 |  |  | 7,765 |  |
| Other |  |  |  |
| 2.46% Margin Loan Facility due April 2022 | 4,000 |  |  | 4,000 |  |
| Other | 235 |  |  | 84 |  |
| Total debt, principal amount | $ | 48,480 |  |  | $ | 52,665 |  |

[0001571996-21-000007:notes:184]
|  | January 29, 2021 |  | January 31, 2020 |
|  | (in millions) |
| Total debt, principal amount | $ | 48,480 |  |  | $ | 52,665 |  |
| Unamortized discount, net of unamortized premium | (194) |  |  | (241) |  |
| Debt issuance costs | (302) |  |  | (368) |  |
| Total debt, carrying value | $ | 47,984 |  |  | $ | 52,056 |  |
| Total short-term debt, carrying value | $ | 6,362 |  |  | $ | 7,737 |  |
| Total long-term debt, carrying value | $ | 41,622 |  |  | $ | 44,319 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0001571996-21-000007:notes:185]
NOTE 5 — LEASES

[0001571996-21-000007:notes:186]
The Company enters into leasing transactions in which the Company is the lessee.  These lease contracts are typically classified as operating leases.  The Company’s lease contracts are generally for office buildings used to conduct its business, and the determination of whether such contracts contain leases generally does not require significant estimates or judgments.  The Company also leases certain global logistics warehouses, employee vehicles, and equipment.  As of January 29, 2021, the remaining terms of the Company’s leases range from less than one month to 26 years.

[0001571996-21-000007:notes:187]
The Company also enters into leasing transactions in which the Company is the lessor, primarily through customer financing arrangements offered through DFS.  DFS originates leases that are primarily classified as either sales-type leases or operating leases.  See Note 4 of the Notes to the Consolidated Financial Statements for more information on the DFS lease portfolio and related lease disclosures.

[0001571996-21-000007:notes:188]
In adopting the current lease accounting standard effective February 2, 2019, the Company elected to apply a transition method that does not require the retrospective application to periods prior to the effective date.  Financial information associated with the Company’s leases in which the Company is the lessee is contained in this Note 5.  As of January 29, 2021 and January 31, 2020, there were no material finance leases for which the Company was a lessee.

[0001571996-21-000007:notes:189]
The following table presents components of lease costs included in the Consolidated Statements of Income (Loss) for the periods indicated:

[0001571996-21-000007:notes:190]
|  | Fiscal Year Ended |
|  | January 29, 2021 |  | January 31, 2020 |
|  | (in millions) |
| Operating lease costs | $ | 535 |  |  | $ | 510 |  |
| Variable costs | 161 |  |  | 161 |  |
| Total lease costs | $ | 696 |  |  | $ | 671 |  |

[0001571996-21-000007:notes:191]
During both the fiscal years ended January 29, 2021 and January 31, 2020, sublease income, finance lease costs, and short-term lease costs were immaterial.

[0001571996-21-000007:notes:192]
The following table presents supplemental information related to operating leases included in the Consolidated Statements of Financial Position as of the dates indicated:

[0001571996-21-000007:notes:193]
|  | Classification | January 29, 2021 |  | January 31, 2020 |  |  |
|  |  | (in millions, except for term and discount rate) |
| Operating lease ROU assets | Other non-current assets | $ | 2,117 |  | $ | 1,780 |  |  |
| Current operating lease liabilities | Accrued and other current liabilities | $ | 436 |  | $ | 432 |  |  |
| Non-current operating lease liabilities | Other non-current liabilities | 1,787 |  | 1,360 |  |  |
| Total operating lease liabilities |  | $ | 2,223 |  | $ | 1,792 |  |  |
| Weighted-average remaining lease term (in years) |  | 8.85 |  | 8.57 |  |  |
| Weighted-average discount rate |  | 3.47 | % |  | 3.81 | % |  |  |

[0001571996-21-000007:notes:194]
The following table presents supplemental cash flow information related to leases for the periods indicated:

[0001571996-21-000007:notes:195]
|  | Fiscal Year Ended |
|  | January 29, 2021 |  | January 31, 2020 |
|  | (in millions) |
| Cash paid for amounts included in the measurement of lease liabilities — operating cash outflows from operating leases | $ | 523 |  |  | $ | 501 |  |
| ROU assets obtained in exchange for new operating lease liabilities | $ | 824 |  |  | $ | 630 |  |

[0001571996-21-000007:notes:196]
The following table presents the future maturity of the Company’s operating lease liabilities under non-cancelable leases and reconciles the undiscounted cash flows for these leases to the lease liability recognized on the Consolidated Statements of Financial Position as of the date indicated:

[0001571996-21-000007:notes:197]
|  | January 29, 2021 |  |  |
|  | (in millions) |
| Fiscal 2022 | $ | 472 |  |  |  |
| Fiscal 2023 | 445 |  |  |  |
| Fiscal 2024 | 324 |  |  |  |
| Fiscal 2025 | 242 |  |  |  |
| Fiscal 2026 | 194 |  |  |  |
| Thereafter | 975 |  |  |  |
| Total lease payments | 2,652 |  |  |  |
| Less: Imputed interest | (429) |  |  |  |
| Total | $ | 2,223 |  |  |  |
| Current operating lease liabilities | $ | 436 |  |  |  |
| Non-current operating lease liabilities | $ | 1,787 |  |  |  |

[0001571996-21-000007:notes:198]
Future lease commitments after Fiscal 2026 include the ground lease on VMware, Inc.’s Palo Alto, California headquarter facilities, which expires in Fiscal 2047.

[0001571996-21-000007:notes:199]
As of January 29, 2021, the Company has additional operating leases that have not yet commenced of $72 million.  These operating leases will commence during Fiscal 2022 with lease terms of one year to 10 years.


## us-gaap:DebtDisclosureTextBlock

[0001571996-21-000007:notes:200]
NOTE 6 — DEBT

[0001571996-21-000007:notes:201]
During the fiscal year ended January 29, 2021, the net decrease in the Company’s debt balance was primarily due to:

[0001571996-21-000007:notes:202]
•retirement of $4.5 billion principal amount of 4.42% First Lien Notes due June 2021 via repayment of $4,265 million and open market repurchases of $235 million;

[0001571996-21-000007:notes:203]
•repayment of the remaining $679 million principal amount of the Term Loan A-4 Facility;

[0001571996-21-000007:notes:204]
•repayment of $1,595 million principal amount of the Term Loan B-1 Facility;

[0001571996-21-000007:notes:205]
•repayment of $363 million principal amount of the Term Loan A-6 Facility;

[0001571996-21-000007:notes:206]
•repayment of $1.5 billion principal amount of the VMware Term Loan Facility upon maturity;

[0001571996-21-000007:notes:207]
•repayment of $1.25 billion principal amount of 2.30% VMware Notes due August 2020; and

[0001571996-21-000007:notes:208]
•repayment of $600 million principal amount of 2.650% EMC Notes due June 2020 upon maturity.

[0001571996-21-000007:notes:209]
These decreases in the Company’s debt balance during the fiscal year ended January 29, 2021 were partially offset by:

[0001571996-21-000007:notes:210]
•issuance of $2.25 billion aggregate principal amount of First Lien Notes on April 9, 2020, described below;

[0001571996-21-000007:notes:211]
•issuance of $2.0 billion aggregate principal amount of VMware Notes on April 7, 2020, described below; and

[0001571996-21-000007:notes:212]
•incurrence of an additional $1.9 billion, net, in DFS debt to support the expansion of its financing receivables portfolio.

[0001571996-21-000007:notes:213]
During the fiscal year ended January 31, 2020, the net decrease in the Company’s debt balance was primarily due to:

[0001571996-21-000007:notes:214]
•repayment of $1.4 billion principal amount of 2.650% EMC Notes due June 2020;

[0001571996-21-000007:notes:215]
•repayment of $550 million principal amount of 5.875% senior unsecured notes due June 2021;

[0001571996-21-000007:notes:216]
•repayment of $600 million principal amount of 5.875% senior unsecured notes due June 2019;

[0001571996-21-000007:notes:217]
•repayment of $950 million principal amount of the Term Loan A-4 Facility;

[0001571996-21-000007:notes:218]
•amortization of approximately $193 million of principal under the Company’s term loan facilities;

[0001571996-21-000007:notes:219]
•repayment of $162.5 million principal amount as part of the Term Loan B Facility refinancing as described below under “Refinancing Transactions during Fiscal 2020”; and

[0001571996-21-000007:notes:220]
•repayment of the remaining principal amount of approximately $1,277 million of the Term Loan A-2 Facility in connection with the First Lien Notes issued on March 20, 2019, as described below under “Refinancing Transactions during Fiscal 2020.”

[0001571996-21-000007:notes:221]
These decreases in the Company’s debt balance during the fiscal year ended January 31, 2020 were partially offset by:

[0001571996-21-000007:notes:222]
•debt issuances in connection with refinancing activities described below under “Refinancing Transactions during Fiscal 2020”; and

[0001571996-21-000007:notes:223]
•incurrence of an additional $1.8 billion, net, in DFS debt to support the expansion of its financing receivables portfolio.  See Note 4 of the Notes to the Consolidated Financial Statements for more information about DFS debt.

[0001571996-21-000007:notes:224]
Refinancing Transactions during Fiscal 2020

[0001571996-21-000007:notes:225]
In connection with the Class V transaction described in Note 1 of the Notes to the Consolidated Financial Statements, on December 20, 2018, the Company entered into an amendment to the credit agreement for the Senior Secured Credit Facilities, described below, which included (a) a new senior secured Term Loan A-4 Facility under its Senior Secured Credit Facilities consisting of an aggregate principal amount of $1.7 billion term A-4 loans, (b) a new senior secured Term Loan A-5 Facility under the Senior Secured Credit Facilities consisting of an aggregate principal amount of $2.0 billion term A-5 loans, (c) $1.4 billion in incremental loans under the Margin Loan Facility, and (d) an increase in the aggregate revolving commitments available under the Revolving Credit Facility to $4.5 billion.  See below for additional information regarding the Senior Secured Credit Facilities, the Margin Loan Facility, and the Revolving Credit Facility.

[0001571996-21-000007:notes:226]
On March 7, 2019, the Company amended the Margin Loan Facility agreement to increase the aggregate principal amount of borrowings under the Margin Loan Facility by $650 million.

[0001571996-21-000007:notes:227]
On March 13, 2019, the Company entered into an amendment to the credit agreement for the Senior Secured Credit Facilities to obtain a new senior secured Term Loan A-6 Facility in order to refinance the $5 billion aggregate principal amount of debt incurred in connection with the Class V transaction described in Note 1 of the Notes to the Consolidated Financial Statements.  The Term Loan A-6 Facility aggregate principal amount of $3,634 million matures on March 13, 2024, of which $2,839 million aggregate principal amount represents the amounts outstanding under the Term Loan A-2 Facility that rolled over into the new facility.  The remaining principal amount outstanding under the Term Loan A-2 Facility was subsequently repaid in full during the fiscal year ended January 31, 2020, partially with proceeds from a private offering of First Lien Notes described below.

[0001571996-21-000007:notes:228]
On March 20, 2019, Dell International L.L.C. and EMC Corporation, both of which are wholly-owned subsidiaries of Dell Technologies Inc., completed a private offering of multiple series of First Lien Notes in an aggregate principal amount of $4.5 billion.  A majority of the proceeds from the First Lien Notes issued on March 20, 2019 was used to repay all of the outstanding $3,750 million principal amount of 3.48% First Lien Notes due June 2019.  In addition, proceeds of approximately $800 million of borrowings under the new Term Loan A-6 Facility, the proceeds of the $650 million increase in the Margin Loan Facility, and a portion of the proceeds from the 2019 First Lien Notes were used to repay all $2,016 million of outstanding amounts under the Term Loan A-5 Facility due December 2019.  The remaining proceeds available from the 2019 First Lien Notes were used to repay a portion of outstanding amounts under the Term Loan A-2 Facility as described above, and to pay related premiums, accrued interest, fees, and expenses.

[0001571996-21-000007:notes:229]
On September 19, 2019, the Company entered into a sixth refinancing amendment to the Senior Secured Credit Agreement (the “Sixth Refinancing Amendment”) to refinance the Term Loan B Facility due September 2023 with a new term loan B facility consisting of an aggregate principal amount of $4,750 million refinancing term B-1 loans maturing on September 19, 2025 (the “Term Loan B-1 Facility”).  The Company used the proceeds from the Term Loan B-1 Facility, together with other available funds, to repay $4,913 million of outstanding amounts under the Term Loan B Facility due September 2023 and to pay related accrued interest, fees, and expenses.

[0001571996-21-000007:notes:230]
The refinancing and amendments were evaluated in accordance with FASB ASC 470, “Debt-Modifications and Extinguishments.”  The amendment to the Margin Loan Facility agreement on March 7, 2019, the term debt refinancing on March 13, 2019, and the Term Loan B Facility refinancing on September 19, 2019 were accounted for as modifications for all existing lenders and as new issuances for new lenders.  The First Lien Notes issued on March 20, 2019 were accounted for as new issuances for all lenders, and repayment of the Company’s outstanding amounts under the Term Loan A-5 Facility was accounted for as an extinguishment.

[0001571996-21-000007:notes:231]
Secured Debt

[0001571996-21-000007:notes:232]
Senior Secured Credit Facilities — The Company has entered into a credit agreement that provides for senior secured credit facilities (the “Senior Secured Credit Facilities”) comprising (a) term loan facilities and (b) a senior secured Revolving Credit Facility, which provides for a borrowing capacity of up to $4.5 billion for general corporate purposes, including capacity for up to $0.5 billion of letters of credit and for borrowings of up to $0.4 billion under swing-line loans.

[0001571996-21-000007:notes:233]
As of January 29, 2021, available borrowings under the Revolving Credit Facility totaled $4.5 billion.  The Senior Secured Credit Facilities provide that the borrowers have the right at any time, subject to customary conditions, to request incremental term loans or incremental revolving commitments.

[0001571996-21-000007:notes:234]
Borrowings under the Senior Secured Credit Facilities bear interest at a rate per annum equal to an applicable margin, plus, at the borrowers’ option, either (a) a base rate, or (b) a London Interbank Offered Rate (“LIBOR”).  The Term Loan B-1 Facility bears interest at LIBOR plus an applicable margin of 2.00% or a base rate plus an applicable margin of 1.00%.  The Term Loan A-6 Facility bears interest at LIBOR plus an applicable margin ranging from 1.25% to 2.00% or a base rate plus an applicable margin ranging from 0.25% to 1.00%.  Interest is payable, in the case of loans bearing interest based on LIBOR, at the end of each interest period (but at least every three months), in arrears and, in the case of loans bearing interest based on the base rate, quarterly in arrears.

[0001571996-21-000007:notes:235]
The Term Loan B-1 Facility amortizes in equal quarterly installments in aggregate annual amounts equal to 1% of the original principal amount.  The Term Loan A-6 Facility amortizes in equal quarterly installments in aggregate annual amounts equal to 5% of the original principal amount in each of the first four years after the facility closing date of March 13, 2019, and 80% of the original principal amount in the fifth year after March 13, 2019.  The Revolving Credit Facility has no amortization.

[0001571996-21-000007:notes:236]
The borrowers may voluntarily repay outstanding loans under the term loan facilities and the Revolving Credit Facility at any time without premium or penalty, other than customary “breakage” costs.

[0001571996-21-000007:notes:237]
All obligations of the borrowers under the Senior Secured Credit Facilities and certain swap agreements, cash management arrangements, and certain letters of credit provided by any lender or agent party to the Senior Secured Credit Facilities or any of its affiliates and certain other persons are secured by (a) a first-priority security interest in certain tangible and intangible assets of the borrowers and the guarantors and (b) a first-priority pledge of 100% of the capital stock of the borrowers, Dell Inc., a wholly‑owned subsidiary of the Company (“Dell”), and each wholly-owned material restricted subsidiary of the borrowers and the guarantors, in each case subject to certain thresholds, exceptions, and permitted liens.

[0001571996-21-000007:notes:238]
First Lien Notes — Dell International L.L.C. and EMC Corporation, both of which are wholly-owned subsidiaries of Dell Technologies Inc., completed private offerings of multiple series of senior secured notes (collectively, the “First Lien Notes”) which were issued on June 1, 2016, March 20, 2019, and April 9, 2020 in aggregate principal amounts of $20.0 billion, $4.5 billion, and $2.25 billion, respectively.  Interest on these borrowings is payable semiannually.  The First Lien Notes are secured on a pari passu basis with the Senior Secured Credit Facilities, on a first-priority basis by substantially all of the tangible and intangible assets of the issuers and guarantors that secure obligations under the Senior Secured Credit Facilities, including pledges of all capital stock of the issuers, Dell, and certain wholly-owned material subsidiaries of the issuers and the guarantors, subject to certain exceptions.

[0001571996-21-000007:notes:239]
The Company has agreed to use commercially reasonable efforts to register with the SEC notes having terms substantially identical to the terms of the First Lien Notes as part of an offer to exchange such registered notes for the First Lien Notes.  The Company will be obligated to pay additional interest on the First Lien Notes if it fails to consummate such an exchange offer within five years after the closing date of the EMC merger transaction, in the case of the First Lien Notes issued on June 1, 2016, and within five years after their respective issue dates, in the case of the First Lien Notes issued on March 20, 2019 and April 9, 2020.  The Company intends to register with the SEC notes having terms substantially identical to the terms of the First Lien Notes as part of an offer to exchange such registered notes for such First Lien Notes during the first half of Fiscal 2022.

[0001571996-21-000007:notes:240]
China Revolving Credit Facility — The Company entered into a new revolving credit facility for China (the “China Revolving Credit Facility”) effective May 25, 2020. The new terms provide for collateralized and non-collateralized principal amounts not to exceed $1.0 billion Chinese renminbi and $1.8 billion Chinese renminbi, respectively, or equivalent amounts in U.S. dollars. Outstanding borrowings under the collateralized portion of the China Revolving Credit Facility bore interest at the loan prime rate (“LPR”) less 0.2%, for borrowings denominated in Chinese renminbi, or LIBOR plus 1.0%, for borrowings denominated in U.S. dollars, and outstanding borrowings under the non-collateralized portion bore interest at LPR less 0.2%, for borrowings denominated in Chinese renminbi, or LIBOR plus 1.4%, for borrowings denominated in U.S. dollars. The new facility expired on August 30, 2020.

[0001571996-21-000007:notes:241]
During the fiscal year ended January 31, 2020, the Company renewed the credit agreement for its legacy China revolving credit facility with a bank lender, which provided an uncommitted line with an aggregate principal amount not to exceed $500 million at an interest rate of LIBOR plus 0.6% per annum.  The facility was terminated upon expiration on February 26, 2020.

[0001571996-21-000007:notes:242]
Unsecured Debt

[0001571996-21-000007:notes:243]
Unsecured Notes and Debentures — The Company has outstanding unsecured notes and debentures (collectively, the “Unsecured Notes and Debentures”) that were issued by Dell prior to the acquisition of Dell by Dell Technologies Inc. in the going-private transaction that closed in October 2013.  Interest on these borrowings is payable semiannually.

[0001571996-21-000007:notes:244]
Senior Notes — The senior unsecured notes (collectively, the “Senior Notes”) were issued on June 22, 2016 in an aggregate principal amount of $3.25 billion.  Interest on these borrowings is payable semiannually.

[0001571996-21-000007:notes:245]
EMC Notes — On September 7, 2016, EMC had outstanding $2.5 billion aggregate principal amount of its 1.875% Notes due June 2018 and $2.0 billion aggregate principal amount of its 2.650% Notes due June 2020, each of which was fully repaid as of the respective maturity dates, and $1.0 billion aggregate principal amount of its 3.375% Notes due June 2023 (collectively, the “EMC Notes”).  Interest on the outstanding borrowings is payable semiannually.

[0001571996-21-000007:notes:246]
VMware Notes — VMware, Inc. completed public offerings of unsecured senior notes in the aggregate amounts of $4.0 billion and $2.0 billion on August 21, 2017 and April 7, 2020, respectively (collectively, the “VMware Notes”).  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.

[0001571996-21-000007:notes:247]
VMware Revolving Credit Facility — On September 12, 2017, VMware, Inc. entered into an unsecured credit agreement, establishing a revolving credit facility (the “VMware Revolving Credit Facility”), with a syndicate of lenders that provides the company with a borrowing capacity of up to $1.0 billion for VMware, Inc. general corporate purposes.  Commitments under the VMware Revolving Credit Facility are available for a period of five years, which may be extended, subject to the satisfaction of certain conditions, by up to two one year periods.  The credit agreement contains certain representations, warranties, and covenants.  Commitment fees, interest rates, and other terms of borrowings under the VMware Revolving Credit Facility may vary based on VMware, Inc.’s external credit ratings.  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.  As of January 29, 2021, there were no outstanding borrowings under the VMware Revolving Credit Facility.

[0001571996-21-000007:notes:248]
VMware Term Loan Facility — On September 26, 2019, VMware, Inc. entered into a senior unsecured term loan facility (the “VMware Term Loan Facility”) with a syndicate of lenders that provided VMware, Inc. with a borrowing capacity of up to $2.0 billion through February 7, 2020 for VMware, Inc. general corporate purposes.  During the three months ended October 30, 2020, VMware, Inc. repaid the outstanding borrowings of $1.5 billion under the VMware Term Loan Facility.

[0001571996-21-000007:notes:249]
See Note 4 and Note 7 of the Notes to the Consolidated Financial Statements, respectively, for discussion of DFS debt and the interest rate swap agreements that hedge a portion of that debt.

[0001571996-21-000007:notes:250]
Margin Loan Facility — On April 12, 2017, the Company entered into the Margin Loan Facility in an aggregate principal amount of $2.0 billion, under which VMW Holdco LLC, a wholly-owned subsidiary of EMC, is the borrower.  In connection with the Class V transaction described in Note 1 of the Notes to the Consolidated Financial Statements, on December 20, 2018, the Company amended the Margin Loan Facility to increase the aggregate principal amount of the facility to $3.35 billion.  In connection with obtaining the Term Loan A-6 Facility during the fiscal year ended January 31, 2020, the Company increased the aggregate principal amount of the Margin Loan Facility to $4.0 billion.

[0001571996-21-000007:notes:251]
During the three months ended May 1, 2020, due to volatility in the U.S. stock market resulting from the outbreak of COVID-19, VMware Holdco LLC proactively pledged additional shares of VMware, Inc. common stock to secure its obligations under the Margin Loan Facility agreement.  This resulted in an aggregate number of shares pledged of approximately 76 million shares of Class B common stock of VMware, Inc. and approximately 24 million shares of Class A common stock of VMware, Inc.

[0001571996-21-000007:notes:252]
Loans under the Margin Loan Facility bear interest at a rate per annum payable, at the borrower’s option, either at (a) a base rate plus 1.25% or (b) a LIBOR-based rate plus 2.25%.  Interest under the Margin Loan Facility is payable quarterly.  The Margin Loan Facility will mature in April 2022.  The borrower may voluntarily repay outstanding loans under the Margin Loan Facility at any time without premium or penalty, other than customary “breakage” costs, subject to certain minimum threshold amounts for prepayment.

[0001571996-21-000007:notes:253]
Aggregate Future Maturities

[0001571996-21-000007:notes:254]
The following tables presents the aggregate future maturities of the Company’s debt as of January 29, 2021 for the periods indicated:

[0001571996-21-000007:notes:255]
|  | Maturities by Fiscal Year |
|  | 2022 |  | 2023 |  | 2024 |  | 2025 |  | 2026 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Secured Credit Facilities and First Lien Notes | $ | — |  |  | $ | 241 |  |  | $ | 6,023 |  |  | $ | 1,774 |  |  | $ | 3,989 |  |  | $ | 12,750 |  |  | $ | 24,777 |  |
| Unsecured Notes and Debentures | 400 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 952 |  |  | 1,352 |  |
| Senior Notes and EMC Notes | 1,075 |  |  | — |  |  | 1,000 |  |  | 1,625 |  |  | — |  |  | — |  |  | 3,700 |  |
| VMware Notes | — |  |  | 1,500 |  |  | — |  |  | — |  |  | 750 |  |  | 2,500 |  |  | 4,750 |  |
| DFS Debt | 4,888 |  |  | 3,722 |  |  | 339 |  |  | 709 |  |  | 8 |  |  | — |  |  | 9,666 |  |
| Margin Loan Facility | — |  |  | 4,000 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 4,000 |  |
| Other | 11 |  |  | 12 |  |  | 172 |  |  | 7 |  |  | 9 |  |  | 24 |  |  | 235 |  |
| Total maturities, principal amount | 6,374 |  |  | 9,475 |  |  | 7,534 |  |  | 4,115 |  |  | 4,756 |  |  | 16,226 |  |  | 48,480 |  |
| Associated carrying value adjustments | (12) |  |  | (17) |  |  | (33) |  |  | (74) |  |  | (44) |  |  | (316) |  |  | (496) |  |
| Total maturities, carrying value amount | $ | 6,362 |  |  | $ | 9,458 |  |  | $ | 7,501 |  |  | $ | 4,041 |  |  | $ | 4,712 |  |  | $ | 15,910 |  |  | $ | 47,984 |  |

[0001571996-21-000007:notes:256]
Covenants and Unrestricted Net Assets — The credit agreement for the Senior Secured Credit Facilities contains customary negative covenants that generally limit the ability of Denali Intermediate Inc., a wholly-owned subsidiary of Dell Technologies, Dell, and Dell’s and Denali Intermediate’s other restricted subsidiaries to incur debt, create liens, make fundamental changes, enter into asset sales, make certain investments, pay dividends or distribute or redeem certain equity interests, prepay or redeem certain debt, and enter into certain transactions with affiliates.  The indenture governing the Senior Notes contains customary negative covenants that generally limit the ability of Denali Intermediate, Dell, and Dell’s and Denali Intermediate’s other restricted subsidiaries to incur additional debt or issue certain preferred shares, pay dividends on or make other distributions in respect of capital stock or make other restricted payments, make certain investments, sell or transfer certain assets, create liens on certain assets to secure debt, consolidate, merge, sell, or otherwise dispose of all or substantially all assets, enter into certain transactions with affiliates, and designate subsidiaries as unrestricted subsidiaries.  The negative covenants under such credit agreements and indenture are subject to certain exceptions, qualifications, and “baskets.”  The indentures governing the First Lien Notes, the Unsecured Notes and Debentures, and the EMC Notes variously impose limitations, subject to specified exceptions, on creating certain liens, entering into sale and lease-back transactions, and entering into certain asset sales.  The foregoing credit agreements and indentures contain customary events of default, including failure to make required payments, failure to comply with covenants, and the occurrence of certain events of bankruptcy and insolvency.

[0001571996-21-000007:notes:257]
As of January 29, 2021, the Company had certain consolidated subsidiaries that were designated as unrestricted subsidiaries for all purposes of the applicable credit agreements and the indentures governing the First Lien Notes and the Senior Notes.   Substantially all of the net assets of the Company’s consolidated subsidiaries were restricted, with the exception of the Company’s unrestricted subsidiaries, primarily VMware Inc., Secureworks, and their respective subsidiaries, as of January 29, 2021.

[0001571996-21-000007:notes:258]
The Term Loan A-6 Facility and the Revolving Credit Facility are subject to a first lien leverage ratio covenant that is tested at the end of each fiscal quarter of Dell with respect to Dell’s preceding four fiscal quarters.  The Company was in compliance with all financial covenants as of January 29, 2021.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001571996-21-000007:notes:259]
NOTE 7 — DERIVATIVE INSTRUMENTS AND HEDGING ACTIVITIES

[0001571996-21-000007:notes:260]
As part of its risk management strategy, the Company uses derivative instruments, primarily foreign currency forward and option contracts and interest rate swaps, to hedge certain foreign currency and interest rate exposures, respectively.

[0001571996-21-000007:notes:261]
The Company’s objective is to offset gains and losses resulting from these exposures with gains and losses on the derivative contracts used to hedge the exposures, thereby reducing volatility of earnings and protecting the fair values of assets and liabilities.  The earnings effects of the derivative instruments are presented in the same income statement line items as the earnings effects of the hedged items.  For derivatives designated as cash flow hedges, the Company assesses hedge effectiveness both at the onset of the hedge and at regular intervals throughout the life of the derivative.  The Company does not have any derivatives designated as fair value hedges.

[0001571996-21-000007:notes:262]
Foreign Exchange Risk

[0001571996-21-000007:notes:263]
The Company uses foreign currency forward and option contracts designated as cash flow hedges to protect against the foreign currency exchange rate risks inherent in its forecasted transactions denominated in currencies other than the U.S. Dollar.  Hedge accounting is applied based upon the criteria established by accounting guidance for derivative instruments and hedging activities.  The risk of loss associated with purchased options is limited to premium amounts paid for the option contracts.  The risk of loss associated with forward contracts is equal to the exchange rate differential from the time the contract is entered into until the time it is settled.  The majority of these contracts typically expire in twelve months or less.

[0001571996-21-000007:notes:264]
During the fiscal years ended January 29, 2021, January 31, 2020, and February 1, 2019, the Company did not discontinue any cash flow hedges related to foreign exchange contracts that had a material impact on the Company’s results of operations due to the probability that the forecasted cash flows would not occur.

[0001571996-21-000007:notes:265]
The Company uses forward contracts to hedge monetary assets and liabilities denominated in a foreign currency.  These contracts generally expire in three months or less, are considered economic hedges, and are not designated for hedge accounting.  The change in the fair value of these instruments represents a natural hedge as their gains and losses offset the changes in the underlying fair value of the monetary assets and liabilities due to movements in currency exchange rates.

[0001571996-21-000007:notes:266]
In connection with expanded offerings of DFS in Europe, forward contracts are used to hedge financing receivables denominated in foreign currencies other than Euro.  These contracts are not designated for hedge accounting and most expire within three years or less.

[0001571996-21-000007:notes:267]
Interest Rate Risk

[0001571996-21-000007:notes:268]
The Company uses interest rate swaps to hedge the variability in cash flows related to the interest rate payments on structured financing debt.  The interest rate swaps economically convert the variable rate on the structured financing debt to a fixed interest rate to match the underlying fixed rate being received on fixed-term customer leases and loans.  These contracts are not designated for hedge accounting and most expire within three years or less.

[0001571996-21-000007:notes:269]
Interest rate swaps are utilized to manage the interest rate risk, at a portfolio level, associated with DFS operations in Europe.  The interest rate swaps economically convert the fixed rate on financing receivables to a three-month Euribor floating rate basis in order to match the floating rate nature of the banks’ funding pool.  These contracts are not designated for hedge accounting and most expire within five years or less.

[0001571996-21-000007:notes:270]
The Company utilizes cross currency amortizing swaps to hedge the currency and interest rate risk exposure associated with the securitization program that was established in Europe in January 2017.  The cross currency swaps combine a Euro-based interest rate swap with a British Pound or U.S. Dollar foreign exchange forward contract in which the Company pays a fixed British Pound or U.S. Dollar amount and receives a floating amount in Euros linked to the one-month Euribor.  The notional value of the swaps amortizes in line with the expected cash flows and run-off of the securitized assets.  The swaps are not designated for hedge accounting and expire within five years or less.

[0001571996-21-000007:notes:271]
Derivative Instruments

[0001571996-21-000007:notes:272]
Notional Amounts of Outstanding Derivative Instruments

[0001571996-21-000007:notes:273]
|  | January 29, 2021 |  | January 31, 2020 |
|  | (in millions) |
| Foreign exchange contracts: |  |  |  |
| Designated as cash flow hedging instruments | $ | 6,840 |  |  | $ | 8,703 |  |
| Non-designated as hedging instruments | 9,890 |  |  | 7,711 |  |
| Total | $ | 16,730 |  |  | $ | 16,414 |  |
| Interest rate contracts: |  |  |  |
| Non-designated as hedging instruments | $ | 5,859 |  |  | $ | 4,043 |  |

[0001571996-21-000007:notes:274]
Effect of Derivative Instruments Designated as Hedging Instruments on the Consolidated Statements of Financial Position and the Consolidated Statements of Income (Loss)

[0001571996-21-000007:notes:275]
| Derivatives in Cash Flow Hedging Relationships |  | Gain (Loss) Recognized in Accumulated OCI, Net of Tax, on Derivatives |  | Location of Gain (Loss) Reclassified from Accumulated OCI into Income |  | Gain (Loss) Reclassified from Accumulated OCI into Income |
|  |  | (in millions) |  |  |  | (in millions) |
| For the fiscal year ended January 29, 2021 |
|  |  |  |  | Total net revenue |  | $ | (105) |  |
| Foreign exchange contracts |  | $ | (200) |  |  | Total cost of net revenue |  | 5 |  |
| Interest rate contracts |  | — |  |  | Interest and other, net |  | — |  |
| Total |  | $ | (200) |  |  |  |  | $ | (100) |  |
| For the fiscal year ended January 31, 2020 |
|  |  |  |  | Total net revenue |  | $ | 226 |  |
| Foreign exchange contracts |  | $ | 269 |  |  | Total cost of net revenue |  | — |  |
| Interest rate contracts |  | — |  |  | Interest and other, net |  | — |  |
| Total |  | $ | 269 |  |  |  |  | $ | 226 |  |
| For the fiscal year ended February 1, 2019 |
|  |  |  |  | Total net revenue |  | $ | 225 |  |
| Foreign exchange contracts |  | $ | 299 |  |  | Total cost of net revenue |  | — |  |
| Interest rate contracts |  | — |  |  | Interest and other, net |  | — |  |
| Total |  | $ | 299 |  |  |  |  | $ | 225 |  |

[0001571996-21-000007:notes:276]
Effect of Derivative Instruments Not Designated as Hedging Instruments on the Consolidated Statements of Income (Loss)

[0001571996-21-000007:notes:277]
|  | Fiscal Year Ended |  |  |
|  | January 29, 2021 |  | January 31, 2020 |  | February 1, 2019 |  | Location of Gain (Loss) Recognized |
|  | (in millions) |  |  |
| Foreign exchange contracts | $ | 107 |  |  | $ | (152) |  |  | $ | (67) |  |  | Interest and other, net |
| Interest rate contracts | (45) |  |  | (28) |  |  | (8) |  |  | Interest and other, net |
| Total | $ | 62 |  |  | $ | (180) |  |  | $ | (75) |  |  |  |

[0001571996-21-000007:notes:278]
Fair Value of Derivative Instruments in the Consolidated Statements of Financial Position

[0001571996-21-000007:notes:279]
The Company presents its foreign exchange derivative instruments on a net basis in the Consolidated Statements of Financial Position due to the right of offset by its counterparties under master netting arrangements.  The following tables present the fair value of those derivative instruments presented on a gross basis as the dates indicated:

[0001571996-21-000007:notes:280]
|  | January 29, 2021 |
|  | Other CurrentAssets |  | Other Non-Current Assets |  | Other CurrentLiabilities |  | Other Non-CurrentLiabilities |  | TotalFair Value |
|  | (in millions) |
| Derivatives designated as hedging instruments: |
| Foreign exchange contracts in an asset position | $ | 28 |  |  | $ | — |  |  | $ | 18 |  |  | $ | — |  |  | $ | 46 |  |
| Foreign exchange contracts in a liability position | (10) |  |  | — |  |  | (15) |  |  | — |  |  | (25) |  |
| Net asset (liability) | 18 |  |  | — |  |  | 3 |  |  | — |  |  | 21 |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts in an asset position | 184 |  |  | — |  |  | 58 |  |  | — |  |  | 242 |  |
| Foreign exchange contracts in a liability position | (108) |  |  | — |  |  | (159) |  |  | (4) |  |  | (271) |  |
| Interest rate contracts in an asset position | — |  |  | 10 |  |  | — |  |  | — |  |  | 10 |  |
| Interest rate contracts in a liability position | — |  |  | — |  |  | — |  |  | (31) |  |  | (31) |  |
| Net asset (liability) | 76 |  |  | 10 |  |  | (101) |  |  | (35) |  |  | (50) |  |
| Total derivatives at fair value | $ | 94 |  |  | $ | 10 |  |  | $ | (98) |  |  | $ | (35) |  |  | $ | (29) |  |
|  | January 31, 2020 |
|  | Other CurrentAssets |  | Other Non-Current Assets |  | Other CurrentLiabilities |  | Other Non-CurrentLiabilities |  | TotalFair Value |
|  | (in millions) |
| Derivatives designated as hedging instruments: |
| Foreign exchange contracts in an asset position | $ | 108 |  |  | $ | — |  |  | $ | 15 |  |  | $ | — |  |  | $ | 123 |  |
| Foreign exchange contracts in a liability position | (2) |  |  | — |  |  | (3) |  |  | — |  |  | (5) |  |
| Net asset (liability) | 106 |  |  | — |  |  | 12 |  |  | — |  |  | 118 |  |
| Derivatives not designated as hedging instruments: |
| Foreign exchange contracts in an asset position | 136 |  |  | — |  |  | 39 |  |  | — |  |  | 175 |  |
| Foreign exchange contracts in a liability position | (162) |  |  | — |  |  | (81) |  |  | (6) |  |  | (249) |  |
| Interest rate contracts in an asset position | — |  |  | 1 |  |  | — |  |  | — |  |  | 1 |  |
| Interest rate contracts in a liability position | — |  |  | — |  |  | — |  |  | (32) |  |  | (32) |  |
| Net asset (liability) | (26) |  |  | 1 |  |  | (42) |  |  | (38) |  |  | (105) |  |
| Total derivatives at fair value | $ | 80 |  |  | $ | 1 |  |  | $ | (30) |  |  | $ | (38) |  |  | $ | 13 |  |

[0001571996-21-000007:notes:281]
The following tables present the gross amounts of the Company’s derivative instruments, amounts offset due to master netting agreements with the Company’s counterparties, and the net amounts recognized in the Consolidated Statements of Financial Position as of the dates indicated:

[0001571996-21-000007:notes:282]
|  | January 29, 2021 |
|  | Gross Amounts of Recognized Assets/ (Liabilities) |  | Gross Amounts Offset in the Statement of Financial Position |  | Net Amounts of Assets/ (Liabilities) Presented in the Statement of Financial Position |  | Gross Amounts not Offset in the Statement of Financial Position |  | Net Amount of Assets/ (Liabilities) Recognized in the Consolidated Statement of Financial Position |
|  | Financial Instruments |  | Cash Collateral Received or Pledged |  |
|  | (in millions) |
| Derivative instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Financial assets | $ | 298 |  |  | $ | (194) |  |  | $ | 104 |  |  | $ | — |  |  | $ | — |  |  | $ | 104 |  |
| Financial liabilities | (327) |  |  | 194 |  |  | (133) |  |  | — |  |  | 2 |  |  | (131) |  |
| Total derivative instruments | $ | (29) |  |  | $ | — |  |  | $ | (29) |  |  | $ | — |  |  | $ | 2 |  |  | $ | (27) |  |
|  | January 31, 2020 |
|  | Gross Amounts of Recognized Assets/ (Liabilities) |  | Gross Amounts Offset in the Statement of Financial Position |  | Net Amounts of Assets/ (Liabilities) Presented in the Statement of Financial Position |  | Gross Amounts not Offset in the Statement of Financial Position |  | Net Amount of Assets/ (Liabilities) Recognized in the Consolidated Statement of Financial Position |
|  | Financial Instruments |  | Cash Collateral Received or Pledged |  |
|  | (in millions) |
| Derivative instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Financial assets | $ | 299 |  |  | $ | (218) |  |  | $ | 81 |  |  | $ | — |  |  | $ | — |  |  | $ | 81 |  |
| Financial liabilities | (286) |  |  | 218 |  |  | (68) |  |  | — |  |  | 15 |  |  | (53) |  |
| Total derivative instruments | $ | 13 |  |  | $ | — |  |  | $ | 13 |  |  | $ | — |  |  | $ | 15 |  |  | $ | 28 |  |


## dell:BusinessCombinationGoodwillAndIntangibleAssetsTextBlock

[0001571996-21-000007:notes:283]
NOTE 8 — BUSINESS COMBINATIONS, GOODWILL AND INTANGIBLE ASSETS

[0001571996-21-000007:notes:284]
Business Combinations

[0001571996-21-000007:notes:285]
Fiscal year ended January 29, 2021

[0001571996-21-000007:notes:286]
VMware, Inc. Acquisitions

[0001571996-21-000007:notes:287]
SaltStack, Inc. — During the three months ended October 30, 2020, VMware, Inc. completed the acquisition of SaltStack, Inc., a developer of intelligent, event-driven automation software, to broaden VMware, Inc.’s Cloud Management capabilities from infrastructure to applications.  The total purchase price, net of cash acquired, was $51 million. The purchase price primarily included $29 million of intangible assets and $24 million of goodwill that is not expected to be deductible for tax purposes.  The identifiable intangible assets, which primarily consisted of completed technology, have estimated useful lives of three years.

[0001571996-21-000007:notes:288]
Datrium, Inc. — During the three months ended July 31, 2020, VMware, Inc. completed the acquisition of Datrium, Inc., a provider of cloud-native disaster recovery solutions, to broaden the VMware Site Recovery Disaster Recovery as a Service offerings.  The total purchase price, net of cash acquired, was $137 million.  The purchase price primarily included $25 million of identifiable intangible assets and $91 million of goodwill.  The identifiable intangible assets, which primarily consisted of completed technology, have estimated useful lives of three years to five years.  During the three months ended January 29, 2021, VMware, Inc. evaluated facts and circumstances that existed as of the acquisition date and adjusted the provisional amount recorded to deferred tax asset, resulting in an increase of $40 million to goodwill, and determined that intangible assets and goodwill are expected to be deductible for tax purposes.

[0001571996-21-000007:notes:289]
Lastline, Inc. — During the three months ended July 31, 2020, VMware, Inc. completed the acquisition of Lastline, Inc., a provider of network-based security breach detection products and services, to enhance capabilities for network detection and threat analysis on VMware NSX and SD-WAN offerings.  The total purchase price, net of cash acquired, was $114 million.  The purchase price primarily included $29 million of identifiable intangible assets and $86 million of goodwill that is not expected to be deductible for tax purposes.  The identifiable intangible assets, which primarily consisted of completed technology, have estimated useful lives of one year to four years.

[0001571996-21-000007:notes:290]
Nyansa, Inc. — During the three months ended May 1, 2020, VMware, Inc. completed the acquisition of Nyansa, Inc., a developer of artificial intelligence-based network analytics, to accelerate the delivery of end-to-end monitoring and troubleshooting capabilities within VMware SD-WAN by VeloCloud.  The total purchase price, net of cash acquired, was $38 million.  The purchase price primarily included $14 million of identifiable intangible assets and $24 million of goodwill that is not expected to be deductible for tax purposes.  The identifiable intangible assets, which primarily consisted of completed technology, have estimated useful lives of one year to four years.

[0001571996-21-000007:notes:291]
Other Fiscal 2021 Acquisitions — During the fiscal year ended January 29, 2021, VMware, Inc. completed five other acquisitions, which were not material, individually or in aggregate, to the Consolidated Financial Statements.  VMware, Inc. expects these acquisitions to enhance its product features and capabilities for its VMware Carbon Black Cloud and vRealize Operations offerings.  The aggregate purchase price for these five acquisitions, net of cash acquired, was $62 million and primarily included $52 million of identifiable intangible assets and $16 million of goodwill, of which $24 million is expected to be deductible for tax purposes.  The identifiable intangible assets, which primarily consisted of completed technology, have estimated useful lives of one year to five years.

[0001571996-21-000007:notes:292]
For each of the acquisitions completed during the fiscal year ended January 29, 2021, the excess of the purchase consideration over the fair value of net tangible and identifiable intangible assets acquired was recorded as goodwill, which management believes represents synergies expected from combining the technologies of VMware, Inc. with those of the acquired businesses.  The estimated fair value assigned to the tangible assets, identifiable intangible assets, and assumed liabilities were based on management's estimates and assumptions.  The initial allocation of the purchase price was based on preliminary valuations and assumptions and is subject to change within the measurement period.  VMware, Inc. expects to finalize the allocation of the purchase price within the measurement period.

[0001571996-21-000007:notes:293]
The pro forma financial information assuming these Fiscal 2021 acquisitions had occurred as of the beginning of the fiscal year prior to the fiscal year of acquisition, as well as the revenue and earnings generated during the current fiscal year, were not material for disclosure purposes.

[0001571996-21-000007:notes:294]
Fiscal year ended January 31, 2020

[0001571996-21-000007:notes:295]
VMware, Inc. Acquisition of Carbon Black, Inc.

[0001571996-21-000007:notes:296]
On October 8, 2019, VMware, Inc. completed the acquisition of Carbon Black, Inc. (“Carbon Black”), a developer of cloud-native endpoint protection, in a cash tender offer for all of the outstanding shares of Carbon Black’s common stock, at a price of $26.00 per share.  VMware, Inc. acquired Carbon Black to create a comprehensive intrinsic security portfolio to protect workloads, clients, and infrastructure from cloud to edge.  VMware, Inc. believes that the acquisition will result in synergies with the Carbon Black platform and VMware NSX and VMware Workspace ONE offerings, among others, and enable VMware, Inc. to offer a highly-differentiated intrinsic security platform addressing multiple concerns of the security industry.  The total purchase price was $2.0 billion, net of cash acquired of $111 million.

[0001571996-21-000007:notes:297]
Merger consideration totaling $18 million is held with a third-party paying agent and is payable to a certain employee of Carbon Black subject to specified future employment conditions, and is being recognized as an expense over the requisite service period of approximately two years on a straight-line basis.

[0001571996-21-000007:notes:298]
VMware, Inc. assumed all of Carbon Black’s unvested stock options and restricted stock awards outstanding at the completion of the acquisition with an estimated fair value of $181 million.  Of the total consideration, $10 million was allocated to the purchase price and $171 million was allocated to future services and will be expensed over the remaining requisite service periods of approximately three years on a straight-line basis.  The estimated fair value of the stock options assumed by VMware, Inc. was determined using the Black-Scholes option pricing model.  A share conversion ratio of 0.2 was applied to convert Carbon Black’s outstanding stock awards into awards for shares of VMware, Inc.'s common stock.

[0001571996-21-000007:notes:299]
The following table summarizes the allocation of the consideration to the fair value of the assets acquired and liabilities assumed on the date of acquisition (in millions):

[0001571996-21-000007:notes:300]
| Cash | $ | 111 |  |
| Accounts receivable | 58 |  |
| Intangible assets | 492 |  |
| Goodwill | 1,588 |  |
| Other acquired assets | 52 |  |
| Total assets acquired | 2,301 |  |
| Deferred revenue | 151 |  |
| Other assumed liabilities | 45 |  |
| Total liabilities assumed | 196 |  |
| Fair value of assets acquired and liabilities assumed | $ | 2,105 |  |

[0001571996-21-000007:notes:301]
The following table summarizes the components of the intangible assets acquired and their estimated useful lives by VMware, Inc. in conjunction with the acquisition:

[0001571996-21-000007:notes:302]
|  | Weighted-Average Useful Lives |  | Fair Value Amount |
|  | (in years) |  | (in millions) |
| Purchased technology | 4.2 |  | $ | 232 |  |
| Customer relationships and customer lists | 7.0 |  | 215 |  |
| Trademarks and tradenames | 5.0 |  | 25 |  |
| Other | 2.0 |  | 20 |  |
| Total definite-lived intangible assets |  |  | $ | 492 |  |

[0001571996-21-000007:notes:303]
The excess of the purchase consideration over the fair value of net tangible and identifiable intangible assets acquired was recorded as goodwill.  The estimated fair value assigned to the tangible assets, identifiable intangible assets, and assumed liabilities were based on VMware, Inc. management's estimates and assumptions.  Goodwill and identifiable intangible assets were not deductible for tax purposes.

[0001571996-21-000007:notes:304]
Other VMware, Inc. Acquisitions

[0001571996-21-000007:notes:305]
During the fiscal year ended January 31, 2020, VMware, Inc. completed the acquisition of Avi Networks, Inc., a provider of multi-cloud application delivery services.  Together, VMware, Inc. and Avi Networks, Inc. expect to deliver a software defined networking stack built for the multi-cloud environment.  The total purchase price was $326 million, net of cash acquired of $9 million.  The purchase price primarily included $94 million of identifiable intangible assets and $228 million of goodwill that was not deductible for tax purposes.

[0001571996-21-000007:notes:306]
VMware, Inc. completed other acquisitions during the fiscal year ended January 31, 2020 which were not material, individually or in aggregate, to the Consolidated Financial Statements.  VMware, Inc. expects that these acquisitions will enhance its product features and capabilities for its software-defined data center solutions and software-as-a-service offerings.

[0001571996-21-000007:notes:307]
Fiscal year ended February 1, 2019

[0001571996-21-000007:notes:308]
CloudHealth Technologies, Inc. — During the third quarter of the fiscal year ended February 1, 2019, VMware, Inc. completed the acquisition of CloudHealth Technologies, Inc. (“CloudHealth Technologies”).  CloudHealth Technologies delivers a cloud operations platform that enables customers to analyze and manage cloud cost, usage, security, and performance centrally for native public clouds, which expanded VMware, Inc’s portfolio of multi-cloud management solutions.  The total purchase price was $495 million, net of cash acquired of $26 million.  The fair value of assumed unvested equity awards attributed to post-combination services was $39 million and will be expensed over the remaining requisite service periods on a straight-line basis.

[0001571996-21-000007:notes:309]
Heptio Inc. — During the fourth quarter of the fiscal year ended February 1, 2019, VMware, Inc. completed the acquisition of Heptio Inc. (“Heptio”), a provider of products and services that help enterprises deploy and operationalize Kubernetes.  VMware, Inc. acquired Heptio to enhance VMware, Inc’s Kubernetes portfolio and cloud native strategy.  The total purchase price was $420 million, net of cash acquired of $15 million.  Merger consideration totaling $117 million, including $24 million being held in escrow, is payable to certain employees of Heptio subject to specified future employment conditions and is being recognized as expense over the requisite service period of approximately four years on a straight-line basis.  The fair value of assumed unvested equity awards attributed to post-combination services was $47 million and will be expensed over the remaining requisite service periods on a straight-line basis.

[0001571996-21-000007:notes:310]
Goodwill

[0001571996-21-000007:notes:311]
The Infrastructure Solutions Group, Client Solutions Group, and VMware reporting units are consistent with the reportable segments identified in Note 19 of the Notes to the Consolidated Financial Statements.  Offerings within Other businesses as defined below represent separate reporting units.

[0001571996-21-000007:notes:312]
During the fiscal year ended January 31, 2020, VMware, Inc. completed its acquisition of Pivotal which was accounted for as a transaction by entities under common control, and Dell Technologies now reports Pivotal results within the VMware reportable segment.  Pivotal results and goodwill were previously included within Other businesses.  The historical segment results and the historical carrying amounts of goodwill attributable to Pivotal ($2.2 billion as of February 1, 2019) were recast to reflect this change.  See Note 19 of the Notes to the Consolidated Financial Statements for the recast of segment results.

[0001571996-21-000007:notes:313]
The following table presents goodwill allocated to the Company’s reportable segments and changes in the carrying amount of goodwill as of the dates indicated:

[0001571996-21-000007:notes:314]
|  | Infrastructure Solutions Group |  | Client Solutions Group |  | VMware |  | Other Businesses (a) |  | Total |
|  | (in millions) |
| Balances as of February 1, 2019 | $ | 15,199 |  |  | $ | 4,237 |  |  | $ | 18,621 |  |  | $ | 2,032 |  |  | $ | 40,089 |  |
| Goodwill acquired (b) | — |  |  | — |  |  | 1,911 |  |  | 16 |  |  | 1,927 |  |
| Impact of foreign currency translation | (110) |  |  | — |  |  | — |  |  | (8) |  |  | (118) |  |
| Goodwill impaired (c) | — |  |  | — |  |  | — |  |  | (207) |  |  | (207) |  |
| Balances as of January 31, 2020 | 15,089 |  |  | 4,237 |  |  | 20,532 |  |  | 1,833 |  |  | 41,691 |  |
| Goodwill acquired (b) | — |  |  | — |  |  | 270 |  |  | 9 |  |  | 279 |  |
| Impact of foreign currency translation | 235 |  |  | — |  |  | — |  |  | 9 |  |  | 244 |  |
| Goodwill divested (d) | — |  |  | — |  |  | — |  |  | (1,385) |  |  | (1,385) |  |
| Balances as of January 29, 2021 | $ | 15,324 |  |  | $ | 4,237 |  |  | $ | 20,802 |  |  | $ | 466 |  |  | $ | 40,829 |  |

[0001571996-21-000007:notes:315]
(a)    As of January 29, 2021, goodwill allocated to Other businesses consists of Secureworks, Virtustream, and Boomi.

[0001571996-21-000007:notes:316]
(b)    Related primarily to VMware, Inc. business combinations completed during the fiscal years ended January 29, 2021 and January 31, 2020, as discussed above.

[0001571996-21-000007:notes:317]
(c)    The Company recognized goodwill impairment charges related to Virtustream during the fiscal year ended January 31, 2020, as discussed below.

[0001571996-21-000007:notes:318]
(d)  During the three months ended October 30, 2020, Dell Technologies closed the transaction to sell RSA Security.  Prior to the divestiture, RSA Security was included within Other businesses.  See Note 1 of the Notes to the Consolidated Financial Statements for additional information about the divestiture of RSA Security.

[0001571996-21-000007:notes:319]
Goodwill Impairment Tests — Goodwill and indefinite-lived intangible assets are tested for impairment annually during the third fiscal quarter and whenever events or circumstances may indicate that an impairment has occurred.  As a result of the changes in the current economic environment related to the COVID-19 pandemic, the Company considered whether there was a potential triggering event requiring the evaluation of whether goodwill of any of the reporting units should be tested for impairment.  The Company determined there was no triggering event in previous quarters during Fiscal 2021, and no impairment test was performed other than the Company’s annual impairment review in the third quarter of Fiscal 2021.

[0001571996-21-000007:notes:320]
For the annual impairment review in the third quarter of Fiscal 2021, the Company elected to bypass the assessment of qualitative factors to determine whether it was more likely than not that the fair value of a reporting unit was less than its carrying amount, including goodwill.  In electing to bypass the qualitative assessment, the Company proceeded directly to performing a quantitative goodwill impairment test to measure the fair value of each goodwill reporting unit relative to its carrying amount, and to determine the amount of goodwill impairment loss to be recognized, if any.

[0001571996-21-000007:notes:321]
Management exercised significant judgment related to the above assessment, including the identification of goodwill reporting units, assignment of assets and liabilities to goodwill reporting units, assignment of goodwill to reporting units, and determination of the fair value of each goodwill reporting unit.  The fair value of each goodwill reporting unit is generally estimated using a combination of public company multiples and discounted cash flow methodologies, unless the reporting unit relates to a publicly-traded entity (VMware, Inc. or Secureworks), in which case the fair value is determined based primarily on the public company market valuation.  The discounted cash flow and public company multiples methodologies require significant judgment, including estimation of future revenues, gross margins, and operating expenses, which are dependent on internal forecasts, current and anticipated economic conditions and trends, selection of market multiples through assessment of the reporting unit’s performance relative to peer competitors, the estimation of the long-term revenue growth rate and discount rate of the Company’s business, and the determination of the Company’s weighted average cost of capital.  Changes in these estimates and assumptions could materially affect the fair value of the goodwill reporting unit, potentially resulting in a non-cash impairment charge.

[0001571996-21-000007:notes:322]
The fair value of the indefinite-lived trade names is generally estimated using discounted cash flow methodologies.  The discounted cash flow methodology requires significant judgment, including estimation of future revenue, the estimation of the long-term revenue growth rate of the Company’s business and the determination of the Company’s weighted average cost of capital and royalty rates.  Changes in these estimates and assumptions could materially affect the fair value of the indefinite-lived intangible assets, potentially resulting in a non-cash impairment charge.

[0001571996-21-000007:notes:323]
Based on the results of the annual impairment test performed during the fiscal year ended January 29, 2021, the fair values of each of the reporting units exceeded their carrying values.

[0001571996-21-000007:notes:324]
During the fiscal year ended January 31, 2020, an interim impairment assessment of Virtustream was required.  There were no remaining balances of Virtustream goodwill, intangible assets, or property, plant, and equipment as of January 31, 2020 following the pre-tax asset impairment charge of $619 million ($524 million net of tax benefits) recognized during the fiscal year ended January 31, 2020, and a gross goodwill impairment charge of $190 million recognized during the fiscal year ended February 1, 2019.  The asset impairment charge during the fiscal year ended January 31, 2020 was comprised of $207 million of goodwill, $266 million of intangible assets, net, $146 million of property plant and equipment, net, and $95 million of other non-current liabilities related to deferred income taxes.  The impairments were reflected in Other, net within cash flows from operating activities on the Consolidated Statements of Cash Flows.

[0001571996-21-000007:notes:325]
Intangible Assets

[0001571996-21-000007:notes:326]
The following table presents the Company’s intangible assets as of the dates indicated:

[0001571996-21-000007:notes:327]
|  | January 29, 2021 |  | January 31, 2020 |
|  | Gross |  | AccumulatedAmortization |  | Net |  | Gross |  | AccumulatedAmortization |  | Net |
|  | (in millions) |
| Customer relationships | $ | 22,394 |  |  | $ | (15,448) |  |  | $ | 6,946 |  |  | $ | 22,950 |  |  | $ | (13,821) |  |  | $ | 9,129 |  |
| Developed technology | 15,488 |  |  | (12,136) |  |  | 3,352 |  |  | 15,707 |  |  | (10,974) |  |  | 4,733 |  |
| Trade names | 1,285 |  |  | (909) |  |  | 376 |  |  | 1,306 |  |  | (816) |  |  | 490 |  |
| Definite-lived intangible assets | 39,167 |  |  | (28,493) |  |  | 10,674 |  |  | 39,963 |  |  | (25,611) |  |  | 14,352 |  |
| Indefinite-lived trade names | 3,755 |  |  | — |  |  | 3,755 |  |  | 3,755 |  |  | — |  |  | 3,755 |  |
| Total intangible assets | $ | 42,922 |  |  | $ | (28,493) |  |  | $ | 14,429 |  |  | $ | 43,718 |  |  | $ | (25,611) |  |  | $ | 18,107 |  |

[0001571996-21-000007:notes:328]
Amortization expense related to definite-lived intangible assets was approximately $3.4 billion, $4.4 billion, and $6.1 billion for the fiscal years ended January 29, 2021, January 31, 2020, and February 1, 2019, respectively.  There were no material impairment charges related to intangible assets during the fiscal year ended January 29, 2021.  During the fiscal year ended January 31, 2020, an impairment charge related to Virtustream intangible assets, net was approximately $266 million, as discussed above.  During the fiscal year ended February 1, 2019, due to Virtustream business changes, the Virtustream definite-lived intangible assets were tested for impairment using a quantitative analysis, and no impairment was identified.

[0001571996-21-000007:notes:329]
During the three months ended May 1, 2020, the Company recognized proceeds and a gain of $120 million from the sale of certain internally developed intellectual property assets.

[0001571996-21-000007:notes:330]
The following table presents the estimated future annual pre-tax amortization expense of definite-lived intangible assets as of the date indicated:

[0001571996-21-000007:notes:331]
|  | January 29, 2021 |
|  | (in millions) |
| Fiscal 2022 | $ | 2,702 |  |
| Fiscal 2023 | 1,824 |  |
| Fiscal 2024 | 1,455 |  |
| Fiscal 2025 | 1,105 |  |
| Fiscal 2026 | 859 |  |
| Thereafter | 2,729 |  |
| Total | $ | 10,674 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001571996-21-000007:notes:332]
NOTE 9 — DEFERRED REVENUE

[0001571996-21-000007:notes:333]
Deferred Revenue — Deferred revenue is recorded for support and deployment services, software maintenance, professional services, training, and software-as-a-service when the Company has a right to invoice or payments have been received for undelivered products or services where transfer of control has not occurred.  Revenue is recognized on these items when the revenue recognition criteria are met, generally resulting in ratable recognition over the contract term.  The Company also has deferred revenue related to undelivered hardware and professional services, consisting of installations and consulting engagements, which are recognized as the Company’s performance obligations under the contract are completed.

[0001571996-21-000007:notes:334]
The following table presents the changes in the Company’s deferred revenue for the periods indicated:

[0001571996-21-000007:notes:335]
|  | Fiscal Year Ended |
|  | January 29, 2021 |  | January 31, 2020 |
|  | (in millions) |
| Deferred revenue: |  |  |  |
| Deferred revenue at beginning of period | $ | 27,800 |  |  | $ | 24,010 |  |
| Revenue deferrals | 25,475 |  |  | 23,315 |  |
| Revenue recognized | (22,213) |  |  | (19,676) |  |
| Other (a) (b) | (261) |  |  | 151 |  |
| Deferred revenue at end of period | $ | 30,801 |  |  | $ | 27,800 |  |
| Short-term deferred revenue | $ | 16,525 |  |  | $ | 14,881 |  |
| Long-term deferred revenue | $ | 14,276 |  |  | $ | 12,919 |  |

[0001571996-21-000007:notes:336]
(a)    For the fiscal year ended January 29, 2021, Other consists of divested deferred revenue from the sale of RSA Security.  See Note 1 of the Notes to the Consolidated Financial Statements for more information about the divestiture of RSA Security.

[0001571996-21-000007:notes:337]
(b)    For the fiscal year ended January 31, 2020, Other consists of acquired deferred revenue from Carbon Black, Inc. by VMware, Inc.

[0001571996-21-000007:notes:338]
Remaining Performance Obligations — Remaining performance obligations represent the aggregate amount of the transaction price allocated to performance obligations not delivered, or partially undelivered, as of the end of the reporting period.  Remaining performance obligations include deferred revenue plus unbilled amounts not yet recorded in deferred revenue.  The value of the transaction price allocated to remaining performance obligations as of January 29, 2021 was approximately $41 billion.  The Company expects to recognize approximately 60% of remaining performance obligations as revenue in the next twelve months, and the remainder thereafter.

[0001571996-21-000007:notes:339]
The aggregate amount of the transaction price allocated to remaining performance obligations does not include amounts owed under cancelable contracts where there is no substantive termination penalty.  The Company applied the practical expedient to exclude the value of remaining performance obligations for contracts for which revenue is recognized at the amount to which the Company has the right to invoice for services performed.

[0001571996-21-000007:notes:340]
Remaining performance obligation estimates are subject to change and are affected by several factors, including terminations, changes in the scope of contracts, periodic revalidation, adjustments for revenue that have not materialized, and adjustments for currency.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001571996-21-000007:notes:341]
NOTE 10 — COMMITMENTS AND CONTINGENCIES

[0001571996-21-000007:notes:342]
Purchase Obligations

[0001571996-21-000007:notes:343]
The Company has contractual obligations to purchase goods or services, which specify significant terms, including fixed or minimum quantities to be purchased; fixed, minimum, or variable price provisions; and the approximate timing of the transaction.  As of January 29, 2021, purchase obligations were $4,885 million, $462 million, and $531 million for Fiscal 2022, Fiscal 2023, and Fiscal 2024 and thereafter, respectively.

[0001571996-21-000007:notes:344]
Lease Commitments

[0001571996-21-000007:notes:345]
The Company leases property and equipment, manufacturing facilities, and office space under non-cancelable leases.  As of January 29, 2021, the future maturity of the Company’s operating lease liabilities under non-cancelable leases was as follows:  $472 million in Fiscal 2022; $445 million  in Fiscal 2023; $324 million in Fiscal 2024; $242 million in Fiscal 2025; $194 million in Fiscal 2026; and $975 million thereafter.

[0001571996-21-000007:notes:346]
The amount of future lease commitments after Fiscal 2026 includes the ground lease on VMware, Inc.’s Palo Alto, California headquarter facilities, which expires in Fiscal 2047.

[0001571996-21-000007:notes:347]
Legal Matters

[0001571996-21-000007:notes:348]
The Company is involved in various claims, suits, assessments, investigations, and legal proceedings that arise from time to time in the ordinary course of its business, including those identified below, consisting of matters involving consumer, antitrust, tax, intellectual property, and other issues on a global basis.

[0001571996-21-000007:notes:349]
The Company accrues a liability when it believes that it is both probable that a liability has been incurred and that it can reasonably estimate the amount of the loss.  The Company reviews these accruals at least quarterly and adjusts them to reflect ongoing negotiations, settlements, rulings, advice of legal counsel, and other relevant information.  To the extent new information is obtained and the Company’s views on the probable outcomes of claims, suits, assessments, investigations, or legal proceedings change, changes in the Company’s accrued liabilities would be recorded in the period in which such a determination is made.  For some matters, the amount of liability is not probable or the amount cannot be reasonably estimated and therefore accruals have not been made.

[0001571996-21-000007:notes:350]
The following is a discussion of the Company’s significant legal matters and other proceedings:

[0001571996-21-000007:notes:351]
Class Actions Related to the Class V Transaction — Four purported stockholders brought putative class action complaints arising out of the Class V transaction described in Note 1 of the Notes to the Consolidated Financial Statements.  The actions were captioned Hallandale Beach Police and Fire Retirement Plan v. Michael Dell et al. (Civil Action No. 2018-0816-JTL), Howard Karp v. Michael Dell et al. (Civil Action No. 2019-0032-JTL), Miramar Police Officers’ Retirement Plan v. Michael Dell et al. (Civil Action No. 2019-0049-JTL), and Steamfitters Local 449 Pension Plan v. Michael Dell et al. (Civil Action No. 2019-0115-JTL).  The four actions were consolidated in the Delaware Chancery Court into In Re Dell Class V Litigation (Consol. C.A. No. 2018-0816-JTL), which names as defendants the Company’s board of directors and certain stockholders of the Company, including Michael S. Dell.  The plaintiffs generally allege that the defendants breached their fiduciary duties to the former holders of Class V Common Stock in connection with the Class V transaction by allegedly causing the Company to enter into a transaction that favored the interests of the controlling stockholders at the expense of such former stockholders.  The plaintiffs seek, among other remedies, a judicial declaration that the defendants breached their fiduciary duties and an award of damages, fees, and costs.  The plaintiffs filed an amended complaint in August 2019 making substantially similar allegations to those described above.  The defendants filed a motion to dismiss the action in September 2019.  The court denied the motion in June 2020 and the case is currently in the discovery phase.

[0001571996-21-000007:notes:352]
Patent Litigation — On April 25, 2019, Cirba Inc. and Cirba IP, Inc. (collectively, “Cirba”) filed a lawsuit against VMware, Inc. in the United States District Court for the District of Delaware (the “Delaware Court”), alleging two patent infringement claims and three trademark infringement-related claims (the “First Action”).  On May 6, 2019, Cirba filed a motion seeking a preliminary injunction tied to one of the two patents it alleges VMware, Inc. infringes.  Following a hearing on August 6, 2019, the Delaware Court denied Cirba’s preliminary injunction motion.  On August 20, 2019, VMware, Inc. filed counterclaims against Cirba, asserting among other claims that Cirba is infringing four VMware, Inc. patents.  The Delaware Court severed those claims from the January 2020 trial on Cirba’s claims.  The trial on Cirba’s claims in Delaware was completed on January 23, 2020, and on January 24, 2020, the jury returned a verdict finding that VMware, Inc. willfully infringed the two asserted patents and awarding approximately $237 million in damages.  The jury further found that VMware, Inc. was not liable on Cirba’s trademark infringement-related claims.  A total of $237 million was accrued for the First Action, which reflected the estimated losses that were considered both probable and reasonably estimable at that time.  The amount accrued for this matter was included in Accrued and other in the Consolidated Statements of Financial Position as of January 31, 2020, and the charge was classified in Selling, general and administrative in the Consolidated Statements of Income (Loss) during the fiscal year ended January 31, 2020.  On March 9, 2020, the parties filed post-trial motions in the First Action.  On December 21, 2020, the Delaware Court granted VMware, Inc.’s request for a new trial based, in part, on Cirba Inc.’s lack of standing, set aside the verdict and damages award, and denied Cirba’s post-trial motions (the “Post-Trial Order”).

[0001571996-21-000007:notes:353]
On October 22, 2019, VMware, Inc. filed a separate patent infringement lawsuit against Cirba Inc. in the United States District Court for the Eastern District of Virginia, asserting that Cirba infringes four additional VMware, Inc. patents (the “Second Action”).  The Virginia court transferred the Second Action to the Delaware Court on February 25, 2020.  On March 23, 2020, Cirba filed a counterclaim asserting one additional patent infringement claim against VMware, Inc.   The Delaware Court consolidated the First and Second Actions and ordered a consolidated trial on all of the parties’ patent infringement claims and counterclaims.  The parties have proposed April 24, 2023 as the date for a consolidated trial.  On January 20, 2021, Cirba moved to certify the Post-Trial Order to enable an interlocutory appeal to the United States Court of Appeals for the Federal Circuit.  This motion has been fully briefed and is now pending before the Delaware Court.  As of January 29, 2021, VMware, Inc. reassessed its estimated loss accrual for the First Action based on the Post-Trial Order and determined that a loss is no longer probable and reasonably estimable with respect to the consolidated First and Second Actions.  Accordingly, the estimated loss accrual recognized during the fiscal year ended January 31, 2020 totaling $237 million was adjusted to $0 with the credit included in Selling, general, and administrative in the Consolidated Statements of Income (Loss) during the fiscal year ended January 29, 2021.  VMware, Inc. is unable at this time to assess whether, or to what extent, it may be found liable and, if found liable, what the damages may be.  VMware, Inc. intends to vigorously defend itself in this matter.

[0001571996-21-000007:notes:354]
Class Actions Related to VMware, Inc.’s Acquisition of Pivotal — Two purported stockholders brought putative class action complaints arising out of VMware, Inc.’s acquisition of Pivotal Software, Inc. on December 30, 2019 as described in Note 1 of the Notes to the Consolidated Financial Statements.  The two actions were consolidated in the Delaware Chancery Court into In re: Pivotal Software, Inc. Stockholders Litigation (Civil Action No. 2020-0440-KSJM).  The complaint names as defendants the Company, VMware, Inc., Michael S. Dell, and certain officers of Pivotal.  The plaintiffs generally allege that the defendants breached their fiduciary duties to the former holders of Pivotal Class A Common Stock in connection with VMware, Inc.’s acquisition of Pivotal by allegedly causing Pivotal to enter into a transaction that favored the interests of Pivotal’s controlling stockholders at the expense of such former stockholders.  The plaintiffs seek, among other remedies, a judicial declaration that the defendants breached their fiduciary duties and an award of damages, fees, and costs.

[0001571996-21-000007:notes:355]
Other Litigation — Dell does not currently anticipate that any of the other various legal proceedings it is involved in will have a material adverse effect on its business, financial condition, results of operations, or cash flows.

[0001571996-21-000007:notes:356]
As of January 29, 2021, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for these or other proceedings or matters has been incurred.  However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company’s business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters.  Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company’s business, financial condition, results of operations, or cash flows will depend on a number of variables, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.

[0001571996-21-000007:notes:357]
Indemnifications

[0001571996-21-000007:notes:358]
In the ordinary course of business, the Company enters into various contracts under which it may agree to indemnify other parties for losses incurred from certain events as defined in the relevant contract, such as litigation, regulatory penalties, or claims relating to past performance.  Such indemnification obligations may not be subject to maximum loss clauses.  Historically, payments related to these indemnifications have not been material to the Company.

[0001571996-21-000007:notes:359]
Certain Concentrations

[0001571996-21-000007:notes:360]
The Company maintains cash and cash equivalents, derivatives, and certain other financial instruments with various financial institutions that potentially subject it to concentration of credit risk.  As part of its risk management processes, the Company performs periodic evaluations of the relative credit standing of these financial institutions.  The Company has not sustained material credit losses from instruments held at these financial institutions.  Further, the Company does not anticipate nonperformance by any of the counterparties.

[0001571996-21-000007:notes:361]
The Company markets and sells its products and services to large corporate clients, governments, and health care and education accounts, as well as to small and medium-sized businesses and individuals.  No single customer accounted for more than 10% of the Company’s consolidated net revenue during the fiscal year ended January 29, 2021, January 31, 2020, or February 1, 2019.

[0001571996-21-000007:notes:362]
The Company utilizes a limited number of contract manufacturers that assemble a portion of its products.  The Company may purchase components from suppliers and sell those components to such contract manufacturers, thereby creating receivables balances from the contract manufacturers.  The agreements with the majority of the contract manufacturers permit the Company to offset its payables against these receivables, thus mitigating the credit risk wholly or in part.  Receivables from the Company’s four largest contract manufacturers represented the majority of the Company’s gross non-trade receivables of $4.1 billion and $3.2 billion as of January 29, 2021 and January 31, 2020, respectively, of which $3.1 billion and $2.6 billion as of January 29, 2021 and January 31, 2020, respectively, have been offset against the corresponding payables.  The portion of receivables not offset against payables is included in other current assets in the Consolidated Statements of Financial Position.  The Company does not reflect the sale of the components in revenue and does not recognize any profit on the component sales until the related products are sold.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001571996-21-000007:notes:363]
NOTE 11 — INCOME AND OTHER TAXES

[0001571996-21-000007:notes:364]
The following table presents components of the income tax expense (benefit) recognized for the periods indicated:

[0001571996-21-000007:notes:365]
|  | Fiscal Year Ended |
|  | January 29, 2021 |  | January 31, 2020 |  | February 1, 2019 |
|  | (in millions) |
| Current: |  |  |  |  |  |
| Federal | $ | (526) |  |  | $ | (150) |  |  | $ | 461 |  |
| State/local | 29 |  |  | 69 |  |  | 74 |  |
| Foreign | 1,061 |  |  | 887 |  |  | 616 |  |
| Current | 564 |  |  | 806 |  |  | 1,151 |  |
| Deferred: |  |  |  |  |  |
| Federal | 23 |  |  | (862) |  |  | (1,150) |  |
| State/local | (145) |  |  | (150) |  |  | (85) |  |
| Foreign | (277) |  |  | (5,327) |  |  | (96) |  |
| Deferred | (399) |  |  | (6,339) |  |  | (1,331) |  |
| Income tax expense (benefit) | $ | 165 |  |  | $ | (5,533) |  |  | $ | (180) |  |

[0001571996-21-000007:notes:366]
The Company’s provision for income taxes for the fiscal periods reflected in the Consolidated Financial Statements are not directly comparable primarily due to the intra-entity asset transfers of certain of its intellectual property (“IP”) completed in the fiscal year ended January 31, 2020.  During the fiscal years ended January 29, 2021 and January 31, 2020, the Company completed intra-entity asset transfers of certain of its IP to Irish subsidiaries, resulting in discrete tax benefits of $59 million and $4.9 billion, respectively.  The tax benefit for each intra-entity asset transfer was recorded as a deferred tax asset in the period of transaction and represents the book and tax basis difference on the transferred assets measured based on the IP’s current fair value and applicable Irish statutory tax rate.  The Company expects to be able to realize the deferred tax assets resulting from these intra-entity asset transfers.

[0001571996-21-000007:notes:367]
The following table presents components of income (loss) before income taxes for the periods indicated:

[0001571996-21-000007:notes:368]
|  | Fiscal Year Ended |
|  | January 29, 2021 |  | January 31, 2020 |  | February 1, 2019 |
|  | (in millions) |
| Domestic | $ | (1,066) |  |  | $ | (3,067) |  |  | $ | (4,645) |  |
| Foreign | 4,736 |  |  | 3,063 |  |  | 2,284 |  |
| Income (loss) before income taxes | $ | 3,670 |  |  | $ | (4) |  |  | $ | (2,361) |  |

[0001571996-21-000007:notes:369]
The following table presents a reconciliation of the Company’s effective tax rate to the statutory U.S. federal tax rate for the periods indicated:

[0001571996-21-000007:notes:370]
|  | Fiscal Year Ended |
|  | January 29, 2021 |  | January 31, 2020 |  | February 1, 2019 |
| U.S. federal statutory rate | 21.0 | % |  | 21.0 | % |  | 21.0 | % |
| State income taxes, net of federal tax benefit | (1.5) |  |  | 1194.6 |  |  | 0.5 |  |
| Tax impact of foreign operations | 2.2 |  |  | (2741.3) |  |  | (19.5) |  |
| Impact of intangible property transfers | (1.6) |  |  | 123367.9 |  |  | — |  |
| Change in valuation allowance | 0.5 |  |  | 1030.6 |  |  | (6.6) |  |
| Indirect tax effects of adoption of new revenue standard | — |  |  | — |  |  | 6.5 |  |
| U.S. Tax Reform (a) | — |  |  | — |  |  | 1.5 |  |
| U.S. tax audit settlement | (20.3) |  |  | 7615.7 |  |  | — |  |
| Non-deductible transaction-related costs | 0.7 |  |  | (700.0) |  |  | (1.9) |  |
| Stock-based compensation | (1.6) |  |  | 5873.2 |  |  | 4.1 |  |
| U.S. R&D tax credits | (3.8) |  |  | 4424.9 |  |  | 6.9 |  |
| RSA Security divestiture | 7.8 |  |  | — |  |  | — |  |
| Other | 1.1 |  |  | (1761.6) |  |  | (4.9) |  |
| Total | 4.5 | % |  | 138325.0 | % |  | 7.6 | % |

[0001571996-21-000007:notes:371]
(a)    Impact of the Tax Cuts and Jobs Act (“U.S. Tax Reform”), which was enacted by the U.S. federal government in December 2017.  The Company completed its accounting for the income tax effects of U.S. Tax Reform during the fourth quarter of the fiscal year ended February 1, 2019.

[0001571996-21-000007:notes:372]
The changes in the Company’s effective tax rates for the fiscal year ended January 29, 2021 as compared to the fiscal year ended January 31, 2020 and for the fiscal year ended January 31, 2020 as compared to the fiscal year ended February 1, 2019 were primarily driven by discrete tax items and a change in the Company’s jurisdictional mix of income.

[0001571996-21-000007:notes:373]
The Company’s effective tax rate for the fiscal year ended January 29, 2021 includes discrete tax benefits of $746 million related to an audit settlement, $159 million related to stock-based compensation, and $59 million from an intra-entity asset transfer as described above.  For the fiscal year ended January 29, 2021, the Company’s effective income tax rate also includes a discrete tax expense of $359 million relating to the divestiture of RSA Security during the period due to the relatively low tax basis for the assets sold, particularly goodwill, as discussed in Note 1 of the Notes to the Consolidated Financial Statements.  The Company’s effective tax rate for the fiscal year ended January 31, 2020 includes discrete tax benefits of $4.9 billion related to similar intra-entity asset transfers as described above, $351 million related to stock-based compensation, $305 million related to an audit settlement, and $95 million related to Virtustream impairment charges discussed in Note 8 of the Notes to the Consolidated Financial Statements and included in Other in the table above.  For the fiscal year ended February 1, 2019, the Company’s effective tax rate included $154 million of discrete tax benefits resulting from the impact of its adoption of the new revenue recognition standard.

[0001571996-21-000007:notes:374]
The differences between the Company’s effective income tax rates and the U.S. federal statutory rate of 21% principally result from the geographical distribution of income, differences between the book and tax treatment of certain items, and the discrete tax items discussed above.  In certain jurisdictions, the Company’s tax rate is significantly less than the applicable statutory rate as a result of tax holidays.  The majority of the Company’s foreign income that is subject to these tax holidays and lower tax rates is attributable to Singapore, China, and Malaysia.  A significant portion of these income tax benefits relate to a tax holiday that will be effective until January 31, 2029.  The Company’s other tax holidays will expire in whole or in part during fiscal years 2022 through 2030.  Many of these tax holidays and reduced tax rates may be extended when certain conditions are met or may be terminated early if certain conditions are not met.  As of January 29, 2021, the Company was not aware of any matters of noncompliance related to these tax holidays.  For the fiscal years ended January 29, 2021, January 31, 2020, and February 1, 2019, the income tax benefits attributable to the tax status of the affected subsidiaries were estimated to be approximately $359 million ($0.47 per share of Dell Technologies Common Stock), $444 million ($0.59 per share of Dell Technologies Common Stock), and $313 million ($0.54 per share of DHI Group Common Stock), respectively.  These income tax benefits are included in tax impact of foreign operations in the table above.

[0001571996-21-000007:notes:375]
The Company believes a significant portion of the Company’s undistributed earnings as of January 29, 2021 will not be subject to further U.S. federal taxation.  As of January 29, 2021, the Company has undistributed earnings of certain foreign subsidiaries of approximately $36.5 billion that remain indefinitely reinvested, and as such has not recognized a deferred tax liability.  Determination of the amount of unrecognized deferred income tax liability related to these undistributed earnings is not practicable.

[0001571996-21-000007:notes:376]
The following table presents the components of the Company’s net deferred tax assets (liabilities) as of the dates indicated:

[0001571996-21-000007:notes:377]
|  | January 29, 2021 |  | January 31, 2020 |
|  | (in millions) |
| Deferred tax assets: |  |  |  |
| Deferred revenue and warranty provisions | $ | 1,851 |  |  | $ | 1,672 |  |
| Provisions for product returns and doubtful accounts | 133 |  |  | 107 |  |
| Credit carryforwards | 1,531 |  |  | 1,951 |  |
| Loss carryforwards | 614 |  |  | 580 |  |
| Operating and compensation related accruals | 774 |  |  | 744 |  |
| Operating leases | 238 |  |  | 239 |  |
| Intangible assets | 3,060 |  |  | 2,420 |  |
| Other | 361 |  |  | 205 |  |
| Deferred tax assets | 8,562 |  |  | 7,918 |  |
| Valuation allowance | (1,709) |  |  | (1,687) |  |
| Deferred tax assets, net of valuation allowance | 6,853 |  |  | 6,231 |  |
| Deferred tax liabilities: |  |  |  |
| Leasing and financing | (375) |  |  | (369) |  |
| Operating leases | (208) |  |  | (210) |  |
| Property and equipment | (539) |  |  | (509) |  |
| Other | (303) |  |  | (205) |  |
| Deferred tax liabilities | (1,425) |  |  | (1,293) |  |
| Net deferred tax assets (liabilities) | $ | 5,428 |  |  | $ | 4,938 |  |

[0001571996-21-000007:notes:378]
The following tables present the net operating loss carryforwards, tax credit carryforwards, and other deferred tax assets with related valuation allowances recognized as of the dates indicated:

[0001571996-21-000007:notes:379]
|  | January 29, 2021 |  |  |
|  | Deferred Tax Assets |  | Valuation Allowance |  | Net Deferred Tax Assets |  | First Year Expiring |
|  | (in millions) |  |  |
| Credit carryforwards | $ | 1,531 |  |  | $ | (1,219) |  |  | $ | 312 |  |  | Fiscal 2022 |
| Loss carryforwards | 614 |  |  | (265) |  |  | 349 |  |  | Fiscal 2022 |
| Other deferred tax assets | 6,417 |  |  | (225) |  |  | 6,192 |  |  | NA |
| Total | $ | 8,562 |  |  | $ | (1,709) |  |  | $ | 6,853 |  |  |  |
|  | January 31, 2020 |  |  |
|  | Deferred Tax Assets |  | Valuation Allowance |  | Net Deferred Tax Assets |  | First Year Expiring |
|  | (in millions) |  |  |
| Credit carryforwards | $ | 1,951 |  |  | $ | (1,257) |  |  | $ | 694 |  |  | Fiscal 2021 |
| Loss carryforwards | 580 |  |  | (348) |  |  | 232 |  |  | Fiscal 2021 |
| Other deferred tax assets | 5,387 |  |  | (82) |  |  | 5,305 |  |  | NA |
| Total | $ | 7,918 |  |  | $ | (1,687) |  |  | $ | 6,231 |  |  |  |

[0001571996-21-000007:notes:380]
The Company’s credit carryforwards as of January 29, 2021 and January 31, 2020 relate primarily to U.S. tax credits and include state and federal tax credits associated with research and development, as well as foreign tax credits associated with U.S. Tax Reform.  The more significant amounts of the Company’s carryforwards begin expiring in Fiscal 2028.  The Company assessed the realizability of these U.S. tax credits and has recorded a valuation allowance against the credits it does not expect to utilize.  The change in the valuation allowance against these credits is included in Change in valuation allowance in the Company’s effective tax reconciliations for the fiscal years ended January 29, 2021 and January 31, 2020.  The Company’s loss carryforwards as of January 29, 2021 and January 31, 2020 include net operating loss carryforwards from federal, state, and foreign jurisdictions.  The valuation allowances for other deferred tax assets as of January 29, 2021 and January 31, 2020 primarily relate to foreign jurisdictions, the changes in which are included in Tax impact of foreign operations in the Company’s effective tax reconciliation.  The Company has determined that it will be able to realize the remainder of its deferred tax assets, based on the future reversal of deferred tax liabilities.

[0001571996-21-000007:notes:381]
The following table presents a reconciliation of the Company’s beginning and ending balances of unrecognized tax benefits for the periods indicated:

[0001571996-21-000007:notes:382]
|  | Fiscal Year Ended |
|  | January 29, 2021 |  | January 31, 2020 |  | February 1, 2019 |
|  | (in millions) |
| Beginning Balance | $ | 2,447 |  |  | $ | 2,989 |  |  | $ | 2,867 |  |
| Increases related to tax positions of the current year | 136 |  |  | 145 |  |  | 116 |  |
| Increases related to tax position of prior years | 393 |  |  | 332 |  |  | 288 |  |
| Reductions for tax positions of prior years | (698) |  |  | (490) |  |  | (170) |  |
| Lapse of statute of limitations | (40) |  |  | (127) |  |  | (90) |  |
| Audit settlements | (405) |  |  | (402) |  |  | (22) |  |
| Ending Balance | $ | 1,833 |  |  | $ | 2,447 |  |  | $ | 2,989 |  |

[0001571996-21-000007:notes:383]
The Company’s net unrecognized tax benefits were $1.4 billion, $2.5 billion, and $3.4 billion as of January 29, 2021, January 31, 2020, and February 1, 2019, respectively, and are included in accrued and other and other non-current liabilities in the Consolidated Statements of Financial Position.

[0001571996-21-000007:notes:384]
The unrecognized tax benefits in the table above include $1.1 billion, $2.0 billion, and $2.4 billion as of January 29, 2021, January 31, 2020, and February 1, 2019, respectively, that, if recognized, would have impacted income tax expense.  The table does not include accrued interest and penalties of $0.4 billion, $0.8 billion, and $1.0 billion as of January 29, 2021, January 31, 2020, and February 1, 2019, respectively.  Tax benefits associated with interest and state tax deductions and other indirect jurisdictional effects of uncertain tax positions were $862 million, $629 million, and $611 million as of January 29, 2021, January 31, 2020, and February 1, 2019, respectively.  Interest and penalties related to income tax liabilities are included in income tax expense.  The Company recorded tax benefits for interest and penalties of $251 million and $174 million for the fiscal years ended January 29, 2021 and January 31, 2020, respectively, and tax expense of $127 million for the fiscal year ended February 1, 2019.

[0001571996-21-000007:notes:385]
During the fiscal year ended January 29, 2021, the Company settled the Internal Revenue Service (“IRS”) audit for fiscal years 2010 through 2014, for which the Company made a cash payment of $435 million to the IRS on August 3, 2020.  During the fiscal year ended January 31, 2020, the Company made a cash payment of $438 million in settlement of the IRS audit for fiscal years 2007 through 2009.  The IRS is currently examining fiscal years 2015 through 2019.  The Company believes it has valid positions supporting its tax returns and that it is adequately reserved.

[0001571996-21-000007:notes:386]
The Company is also currently under income tax audits in various state and foreign taxing jurisdictions.  The Company is undergoing negotiations, and in some cases contested proceedings, relating to tax matters with the taxing authorities in these jurisdictions.  The Company believes that it has provided adequate reserves related to all matters contained in tax periods open to examination.  Although the Company believes it has made adequate provisions for the uncertainties surrounding these audits, should the Company experience unfavorable outcomes, such outcomes could have a material impact on its results of operations, financial position, and cash flows.  With respect to major U.S. state and foreign taxing jurisdictions, the Company is generally not subject to tax examinations for years prior to the fiscal year ended January 29, 2010.

[0001571996-21-000007:notes:387]
Judgment is required in evaluating the Company’s uncertain tax positions and determining the Company’s provision for income taxes.  The Company does not anticipate a significant change to the total amount of unrecognized tax benefits within the next twelve months.

[0001571996-21-000007:notes:388]
The Company takes certain non-income tax positions in the jurisdictions in which it operates and has received certain non-income tax assessments from various jurisdictions.  The Company believes that a material loss in these matters is not probable and that it is not reasonably possible that a material loss exceeding amounts already accrued has been incurred.  The Company believes its positions in these non-income tax litigation matters are supportable and that it ultimately will prevail in the matters.  In the normal course of business, the Company’s positions and conclusions related to its non-income taxes could be challenged and assessments may be made.  To the extent new information is obtained and the Company’s views on its positions, probable outcomes of assessments, or litigation change, changes in estimates to the Company’s accrued liabilities would be recorded in the period in which such a determination is made.  In the resolution process for income tax and non-income tax audits, the Company is required in certain situations to provide collateral guarantees or indemnification to regulators and tax authorities until the matter is resolved.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001571996-21-000007:notes:389]
NOTE 12 — ACCUMULATED OTHER COMPREHENSIVE INCOME (LOSS)

[0001571996-21-000007:notes:390]
Accumulated other comprehensive income (loss) is presented in stockholders’ equity (deficit) in the Consolidated Statements of Financial Position and consists of amounts related to foreign currency translation adjustments, unrealized net gains (losses) on investments, unrealized net gains (losses) on cash flow hedges, and actuarial net gains (losses) from pension and other postretirement plans.

[0001571996-21-000007:notes:391]
The following table presents changes in accumulated other comprehensive income (loss), net of tax, by the following components as of the dates indicated:

[0001571996-21-000007:notes:392]
|  | Foreign Currency Translation Adjustments |  | Investments |  | Cash Flow Hedges |  | Pension and Other Postretirement Plans |  | Accumulated Other Comprehensive Income (Loss) |
|  | (in millions) |
| Balances as of February 2, 2018 | $ | 179 |  |  | $ | 22 |  |  | $ | (103) |  |  | $ | 32 |  |  | $ | 130 |  |
| Adjustment for adoption of accounting standards (Note 2) | — |  |  | (61) |  |  | — |  |  | 3 |  |  | (58) |  |
| Other comprehensive income (loss) before reclassifications | (631) |  |  | 2 |  |  | 299 |  |  | (21) |  |  | (351) |  |
| Amounts reclassified from accumulated other comprehensive income (loss) | — |  |  | 43 |  |  | (225) |  |  | — |  |  | (182) |  |
| Total change for the period | (631) |  |  | (16) |  |  | 74 |  |  | (18) |  |  | (591) |  |
| Less: Change in comprehensive income attributable to non-controlling interests | — |  |  | 6 |  |  | — |  |  | — |  |  | 6 |  |
| Balances as of February 1, 2019 | (452) |  |  | — |  |  | (29) |  |  | 14 |  |  | (467) |  |
| Other comprehensive income (loss) before reclassifications | (226) |  |  | — |  |  | 269 |  |  | (60) |  |  | (17) |  |
| Amounts reclassified from accumulated other comprehensive income (loss) | — |  |  | — |  |  | (226) |  |  | 1 |  |  | (225) |  |
| Total change for the period | (226) |  |  | — |  |  | 43 |  |  | (59) |  |  | (242) |  |
| Less: Change in comprehensive income (loss) attributable to non-controlling interests | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Balances as of January 31, 2020 | (678) |  |  | — |  |  | 14 |  |  | (45) |  |  | (709) |  |
| Other comprehensive income (loss) before reclassifications | 528 |  |  | — |  |  | (200) |  |  | (38) |  |  | 290 |  |
| Amounts reclassified from accumulated other comprehensive income (loss) | — |  |  | — |  |  | 100 |  |  | 5 |  |  | 105 |  |
| Total change for the period | 528 |  |  | — |  |  | (100) |  |  | (33) |  |  | 395 |  |
| Less: Change in comprehensive income (loss) attributable to non-controlling interests | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Balances as of January 29, 2021 | $ | (150) |  |  | $ | — |  |  | $ | (86) |  |  | $ | (78) |  |  | $ | (314) |  |

[0001571996-21-000007:notes:393]
Amounts related to investments are reclassified to net income (loss) when gains and losses are realized.  See Note 3 of the Notes to the Consolidated Financial Statements for more information on the Company’s investments.  Amounts related to the Company’s cash flow hedges are reclassified to net income during the same period in which the items being hedged are recognized in earnings.  See Note 7 of the Notes to the Consolidated Financial Statements for more information on the Company’s derivative instruments.

[0001571996-21-000007:notes:394]
The following table presents reclassifications out of accumulated other comprehensive income (loss), net of tax, to net income for the periods indicated:

[0001571996-21-000007:notes:395]
|  |  |  | Fiscal Year Ended |
|  |  |  | January 29, 2021 |  |  |  | January 31, 2020 |
|  |  |  | Cash Flow Hedges |  | Pensions |  | Total |  |  |  | Cash Flow Hedges |  | Pensions |  | Total |
|  |  |  | (in millions) |
| Total reclassifications, net of tax: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue |  |  | $ | (105) |  |  | $ | — |  |  | $ | (105) |  |  |  |  | $ | 226 |  |  | $ | — |  |  | $ | 226 |  |
| Cost of net revenue |  |  | 5 |  |  | — |  |  | 5 |  |  |  |  | — |  |  | — |  |  | — |  |
| Operating expenses |  |  | — |  |  | (5) |  |  | (5) |  |  |  |  | — |  |  | (1) |  |  | (1) |  |
| Total reclassifications, net of tax |  |  | $ | (100) |  |  | $ | (5) |  |  | $ | (105) |  |  |  |  | $ | 226 |  |  | $ | (1) |  |  | $ | 225 |  |


## us-gaap:MinorityInterestDisclosureTextBlock

[0001571996-21-000007:notes:396]
NOTE 13 — NON-CONTROLLING INTERESTS

[0001571996-21-000007:notes:397]
VMware, Inc. — The non-controlling interests’ share of equity in VMware, Inc. is reflected as a component of the non-controlling interests in the Consolidated Statements of Financial Position and was $5.0 billion and $4.6 billion as of January 29, 2021 and January 31, 2020, respectively.  As of January 29, 2021 and January 31, 2020, the Company held approximately 80.6% and 80.9%, respectively, of the outstanding equity interest in VMware, Inc.

[0001571996-21-000007:notes:398]
As a result of VMware, Inc.’s acquisition of the non-controlling interest in Pivotal from Pivotal’s public stockholders on December 30, 2019, as described in Note 1 of the Notes to the Consolidated Financial Statements, the non-controlling interests’ share of equity in Pivotal is only reflected as a component of the non-controlling interest through December 30, 2019.  Pivotal’s Class A common stock ceased to be listed and traded on the NYSE as of the acquisition date, and there was no non-controlling interest in Pivotal as of January 29, 2021 and January 31, 2020.

[0001571996-21-000007:notes:399]
Secureworks — The non-controlling interests’ share of equity in Secureworks is reflected as a component of the non-controlling interests in the Consolidated Statements of Financial Position and was $96 million and $88 million as of January 29, 2021 and January 31, 2020, respectively.  As of January 29, 2021 and January 31, 2020, the Company held approximately 85.7% and 86.8%, respectively, of the outstanding equity interest in Secureworks, excluding restricted stock awards (“RSAs”).  As of January 29, 2021 and January 31, 2020, the Company held approximately 84.9% and 86.2%, respectively, of the outstanding equity interest in Secureworks, including RSAs.

[0001571996-21-000007:notes:400]
The following table presents the effect of changes in the Company’s ownership interest in VMware, Inc. and Secureworks on the Company’s equity for the period indicated:

[0001571996-21-000007:notes:401]
|  | Fiscal Year Ended |
|  | January 29, 2021 |  | January 31, 2020 |  | February 1, 2019 |
|  | (in millions) |
| Net income attributable to Dell Technologies Inc. | $ | 3,250 |  |  | $ | 4,616 |  |  | $ | (2,310) |  |
| Transfers (to)/from the non-controlling interests: |  |  |  |  |  |
| Increase in Dell Technologies Inc. additional paid-in-capital for equity issuances and other equity activity | 980 |  |  | 1,997 |  |  | 954 |  |
| Decrease in Dell Technologies Inc. additional paid-in-capital for equity issuances and other equity activity | (1,019) |  |  | (3,318) |  |  | (820) |  |
| Net transfers to non-controlling interests | (39) |  |  | (1,321) |  |  | 134 |  |
| Change from net income attributable to Dell Technologies Inc. and transfers to the non-controlling interests | $ | 3,211 |  |  | $ | 3,295 |  |  | $ | (2,176) |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001571996-21-000007:notes:402]
NOTE 14 — CAPITALIZATION

[0001571996-21-000007:notes:403]
The following table presents the Company’s authorized, issued, and outstanding common stock as of the dates indicated:

[0001571996-21-000007:notes:404]
|  | Authorized |  | Issued |  | Outstanding |
|  | (in millions) |
| Common stock as of January 29, 2021 |
| Class A | 600 |  |  | 385 |  |  | 385 |  |
| Class B | 200 |  |  | 102 |  |  | 102 |  |
| Class C | 7,900 |  |  | 274 |  |  | 266 |  |
| Class D | 100 |  |  | — |  |  | — |  |
| Class V | 343 |  |  | — |  |  | — |  |
|  | 9,143 |  |  | 761 |  |  | 753 |  |
| Common stock as of January 31, 2020 |
| Class A | 600 |  |  | 385 |  |  | 385 |  |
| Class B | 200 |  |  | 102 |  |  | 102 |  |
| Class C | 7,900 |  |  | 258 |  |  | 256 |  |
| Class D | 100 |  |  | — |  |  | — |  |
| Class V | 343 |  |  | — |  |  | — |  |
|  | 9,143 |  |  | 745 |  |  | 743 |  |

[0001571996-21-000007:notes:405]
Under the Company’s certificate of incorporation as amended and restated upon the completion of the Class V transaction described in Note 1 of the Notes to the Consolidated Financial Statements, the Company is prohibited from issuing any of the authorized shares of Class V Common Stock.

[0001571996-21-000007:notes:406]
Preferred Stock

[0001571996-21-000007:notes:407]
The Company is authorized to issue one million shares of preferred stock, par value $0.01 per share.  As of January 29, 2021 and January 31, 2020, no shares of preferred stock were issued or outstanding.

[0001571996-21-000007:notes:408]
Common Stock

[0001571996-21-000007:notes:409]
Common Stock for Fiscal 2020 and Thereafter

[0001571996-21-000007:notes:410]
Dell Technologies Common Stock — For Fiscal 2020 and thereafter, the Class A Common Stock, the Class B Common Stock, the Class C Common Stock, and the Class D Common Stock, formerly collectively referred to as the DHI Group Common Stock, are collectively referred to as Dell Technologies Common Stock.  The redesignation of such classes of common stock from DHI Group Common Stock to Dell Technologies Common Stock is intended to align the Company’s reporting with how such classes are referred to by securities analysts, investors, and other users of the financial statements since the completion on December 28, 2018 of the Class V transaction described in Note 1 of the Notes to the Consolidated Financial Statements.  As a result of the cancellation of all outstanding Class V Common Stock upon the closing of that transaction, there is no requirement after the fourth quarter of Fiscal 2019 to allocate net income (loss) between two separate groups of common stock, denoted as DHI Group Common Stock and Class V Common Stock, or to report earnings (loss) per share for each such group.  Accordingly, net income (loss), earnings (loss) per share and other relevant information are reported for Dell Technologies Common Stock for all fiscal periods beginning with the first quarter of Fiscal 2020 and, because of lack of comparability with the new reporting, are reported separately for the DHI Group and the Class V Common Stock, as applicable, for prior fiscal periods.  The par value for all classes of Dell Technologies Common Stock is $0.01 per share.  For purposes of calculating earnings (loss) per share, the Company continues to use the two-class method.  The Class A Common Stock, the Class B Common Stock, the Class C Common Stock, and the Class D Common Stock share equally in dividends declared or accumulated and have equal participation rights in undistributed

[0001571996-21-000007:notes:411]
earnings.  As a result, earnings (loss) per share are the same for all classes of Dell Technologies Common Stock and are presented together.

[0001571996-21-000007:notes:412]
Common Stock prior to Fiscal 2020

[0001571996-21-000007:notes:413]
DHI Group Common Stock and DHI Group — For the fiscal periods prior to Fiscal 2020, the Class A Common Stock, the Class B Common Stock, the Class C Common Stock, and the Class D Common Stock were collectively referred to as the DHI Group Common Stock.  All classes of DHI Group Common Stock have a par value of $0.01 per share, and the Class A Common Stock, the Class B Common Stock, the Class C Common Stock, and the Class D Common Stock share equally in dividends declared or accumulated and have equal participation rights in undistributed earnings.  Prior to the completion on December 28, 2018 of the Class V transaction, the DHI Group referred to the direct and indirect interest of Dell Technologies in all of Dell Technologies’ business, assets, properties, liabilities, and preferred stock other than those attributable to the Class V Group, as well as the DHI Group’s retained interest in the Class V Group.  Subsequent to the completion of the Class V transaction, the DHI Group refers to all classes of issued and outstanding DHI Group Common Stock.

[0001571996-21-000007:notes:414]
Class V Common Stock and Class V Group — The Class V Common Stock was a class of common stock intended to track the performance of a portion of Dell Technologies’ economic interest in the Class V Group.  The Class V Group consisted solely of VMware, Inc. common stock held by the Company.  As of January 29, 2021 and January 31, 2020, no shares of Class V Common Stock remained outstanding.

[0001571996-21-000007:notes:415]
Voting Rights — Each holder of record of (a) Class A Common Stock is entitled to ten votes per share of Class A Common Stock; (b) Class B Common Stock is entitled to ten votes per share of Class B Common Stock; (c) Class C Common Stock is entitled to one vote per share of Class C Common Stock; and (d) Class D Common Stock is not entitled to any vote on any matter except to the extent required by provisions of Delaware law (in which case such holder is entitled to one vote per share of Class D Common Stock).

[0001571996-21-000007:notes:416]
Conversion Rights — Under the Company’s certificate of incorporation, at any time and from time to time, any holder of Class A Common Stock or Class B Common Stock has the right to convert all or any of the shares of Class A Common Stock or Class B Common Stock, as applicable, held by such holder into shares of Class C Common Stock on a one-to-one basis.

[0001571996-21-000007:notes:417]
During the fiscal year ended January 29, 2021, the Company issued an aggregate of 72,727 shares of Class C Common Stock to stockholders upon their conversion of the same number of shares of Class A Common Stock into Class C Common Stock in accordance with the Company’s certificate of incorporation.

[0001571996-21-000007:notes:418]
During the fiscal year ended January 31, 2020, the Company issued 35,822,123 shares of Class C Common Stock to stockholders upon their conversion of the same number of shares of Class A Common Stock into Class C Common Stock in accordance with the Company’s certificate of incorporation.  During the fiscal year ended January 31, 2020, the Company issued 35,301,641 shares of Class C Common Stock to stockholders upon their conversion of the same number of shares of Class B Common Stock into Class C Common Stock in accordance with the Company’s certificate of incorporation.

[0001571996-21-000007:notes:419]
Class V Transaction

[0001571996-21-000007:notes:420]
On December 28, 2018, the Company completed the Class V transaction in which Dell Technologies paid $14.0 billion in cash and issued 149,387,617 shares of its Class C Common Stock to holders of its Class V Common Stock in exchange for all outstanding shares of Class V Common Stock.  The non-cash consideration portion of the Class V transaction totaled $6.9 billion.  As a result of the Class V transaction, the tracking stock feature of Dell Technologies’ capital structure was terminated.  The Class C Common Stock is traded on the New York Stock Exchange.  See Note 1 of the Notes to the Consolidated Financial Statements for more information about the Class V transaction.

[0001571996-21-000007:notes:421]
Repurchases of Common Stock and Treasury Stock

[0001571996-21-000007:notes:422]
Dell Technologies Common Stock Repurchases by Dell Technologies

[0001571996-21-000007:notes:423]
On February 24, 2020, the Company’s board of directors approved a stock repurchase program under which the Company is authorized to repurchase up to $1.0 billion of shares of the Class C Common Stock over a 24-month period expiring on February 28, 2022, of which approximately $760 million remained available as of January 29, 2021.  During the fiscal year ended January 29, 2021, the Company repurchased approximately 6 million shares of Class C Common Stock for approximately $240 million.  During the three months ended May 1, 2020, the Company suspended activity under its stock repurchase program.  During the fiscal year ended January 31, 2020, Dell Technologies Common Stock repurchases were immaterial.

[0001571996-21-000007:notes:424]
To the extent not retired, shares repurchased under the repurchase program are placed in the Company’s treasury.

[0001571996-21-000007:notes:425]
Class V Common Stock Repurchases by Dell Technologies

[0001571996-21-000007:notes:426]
Prior to the Class V transaction and since the date of the EMC merger transaction, the Company authorized several programs to repurchase shares of its Class V Common Stock.  The Company did not repurchase any shares of Class V Common Stock during the fiscal year ended February 1, 2019 under the repurchase programs.

[0001571996-21-000007:notes:427]
As a result of the Class V transaction, pursuant to which all of the approximately 199 million outstanding shares of Class V Common Stock ceased to be outstanding, the tracking stock feature of the Company’s capital structure was terminated.  Additionally, as a result of the Class V transaction, all of the approximately 127 million shares of DHI Group retained interest shares ceased to be outstanding.

[0001571996-21-000007:notes:428]
DHI Group Common Stock Repurchases by Dell Technologies

[0001571996-21-000007:notes:429]
Prior to the Class V transaction during the fiscal year ended February 1, 2019, the Company repurchased approximately one million shares of DHI Group Common Stock for approximately $47 million.  All shares of DHI Group Common Stock repurchased by the Company were held as treasury stock at cost.

[0001571996-21-000007:notes:430]
VMware, Inc. Class A Common Stock Repurchases by VMware, Inc.

[0001571996-21-000007:notes:431]
In August 2017, VMware, Inc.’s board of directors authorized the repurchase of up to $1.0 billion shares of VMware, Inc. Class A common stock through August 31, 2018 and subsequently, in July 2018, extended that authorization through August 31, 2019.  On May 29, 2019, VMware, Inc.’s board of directors authorized the repurchase of an additional $1.5 billion of VMware, Inc.’s Class A common stock through January 29, 2021.  On July 15, 2020, VMware, Inc.’s board of directors extended authorization of VMware, Inc.’s existing repurchase program and authorized the repurchase of up to an additional $1.0 billion of VMware, Inc.’s Class A common stock through January 28, 2022.  As of January 29, 2021, the cumulative authorized amount remaining for stock repurchases was $1.1 billion.

[0001571996-21-000007:notes:432]
During the fiscal year ended January 29, 2021, VMware, Inc. repurchased 6.9 million shares of its Class A common stock in the open market for approximately $945 million.  During the fiscal year ended January 31, 2020, VMware, Inc. repurchased 7.7 million shares of its Class A common stock in the open market for approximately $1.3 billion, of which approximately $0.2 billion impacted Dell Technologies’ accumulated deficit balance as of January 31, 2020 as a result of the full depletion of VMware, Inc’s additional paid-in capital in the same period.  During the fiscal year ended February 1, 2019, VMware, Inc. repurchased 0.3 million shares of its Class A common stock in the open market for approximately $42 million.

[0001571996-21-000007:notes:433]
All shares repurchased under VMware, Inc.’s stock repurchase programs are retired.
The above VMware, Inc. Class A common stock repurchases for the fiscal years ended January 29, 2021, January 31, 2020, and February 1, 2019 exclude shares repurchased to settle employee tax withholding related to the vesting of VMware, Inc. stock awards of $413 million, $521 million, and $373 million, respectively.


## us-gaap:EarningsPerShareTextBlock

[0001571996-21-000007:notes:434]
NOTE 15 — EARNINGS PER SHARE

[0001571996-21-000007:notes:435]
Basic earnings (loss) per share is based on the weighted-average effect of all common shares issued and outstanding and is calculated by dividing net income (loss) by the weighted-average shares outstanding during the period.  Diluted earnings (loss) per share is calculated by dividing net income (loss) by the weighted-average number of common shares used in the basic earnings (loss) per share calculation plus the number of common shares that would be issued assuming exercise or conversion of all potentially dilutive instruments.  The Company excludes equity instruments from the calculation of diluted earnings (loss) per share if the effect of including such instruments is antidilutive.

[0001571996-21-000007:notes:436]
Until the completion on December 28, 2018 of the Class V transaction described in Note 1 of the Notes to the Consolidated Financial Statements, the Company had two groups of common stock, denoted as the DHI Group Common Stock and the Class V Common Stock.

[0001571996-21-000007:notes:437]
The Class V Common Stock was a class of common stock intended to track the economic performance of 61% of the Company’s interest in the Class V Group, which consisted solely of VMware, Inc. common stock held by the Company as of immediately before the completion of the Class V transaction.  Upon the completion of the Class V transaction, all outstanding shares of Class V Common Stock ceased to be outstanding, and the tracking stock structure was terminated.  The Class C Common Stock issued to former holders of the Class V Common Stock in the Class V transaction represents an interest in the Company’s entire business and, unlike the Class V Common Stock, is not intended to track the performance of any distinct assets or business.

[0001571996-21-000007:notes:438]
Prior to the fiscal year ended January 31, 2020, the DHI Group Common Stock consisted of four classes of common stock, including the Class A Common Stock, the Class B Common Stock, the Class C Common Stock, and the Class D Common Stock.  Prior to the completion of the Class V transaction, the DHI Group referred to the direct and indirect interest of Dell Technologies in all of Dell Technologies’ business, assets, properties, liabilities, and preferred stock other than those attributable to the Class V Group, as well as the DHI Group’s retained interest in the Class V Group.  Subsequent to the completion of the Class V transaction, the DHI Group refers to all classes of issued and outstanding DHI Group Common Stock.

[0001571996-21-000007:notes:439]
For purposes of calculating earnings (loss) per share, the Company continues to use the two-class method.  The Class A Common Stock, the Class B Common Stock, the Class C Common Stock, and the Class D Common Stock share equally in dividends declared or accumulated and have equal participation rights in undistributed earnings.  As a result, earnings (loss) per share are the same for all classes of Dell Technologies Common Stock and are presented together.

[0001571996-21-000007:notes:440]
The Company accounted for the VMware, Inc. acquisition of the controlling interest in Pivotal from Dell Technologies described in Note 1 of the Notes to the Consolidated Financial Statements as a transaction by entities under common control.  Consequently, the Pivotal acquisition had no net effect on the Company’s consolidated financial statements or earnings (loss) per share as previously reported, which includes the period in which the Class V Common Stock was outstanding.

[0001571996-21-000007:notes:441]
The following table presents basic and diluted earnings (loss) per share for the periods indicated:

[0001571996-21-000007:notes:442]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  | January 29, 2021 |  | January 31, 2020 |  | February 1, 2019 |
| Earnings (loss) per share attributable to Dell Technologies Inc. — basic: |
| Dell Technologies Common Stock |  |  |  |  | $ | 4.37 |  |  | $ | 6.38 |  |  |  |
| Class V Common Stock |  |  |  |  |  |  |  |  | $ | 6.01 |  |
| DHI Group |  |  |  |  |  |  |  |  | $ | (6.02) |  |
| Earnings (loss) per share attributable to Dell Technologies Inc. — diluted: |
| Dell Technologies Common Stock |  |  |  |  | $ | 4.22 |  |  | $ | 6.03 |  |  |  |
| Class V Common Stock |  |  |  |  |  |  |  |  | $ | 5.91 |  |
| DHI Group |  |  |  |  |  |  |  |  | $ | (6.04) |  |

[0001571996-21-000007:notes:443]
The following table presents the computation of basic and diluted earnings per share for the periods indicated:

[0001571996-21-000007:notes:444]
|  | Fiscal Year Ended |  |  |  |
|  | January 29, 2021 |  | January 31, 2020 |  |  |  |
|  | (in millions) |  |  |  |
| Numerator: Dell Technologies Common Stock |  |  |  |  |  |  |
| Net income attributable to Dell Technologies — basic | $ | 3,250 |  |  | $ | 4,616 |  |  |  |  |
| Incremental dilution from VMware, Inc. attributable to Dell Technologies (a) | (13) |  |  | (84) |  |  |  |  |
| Net income attributable to Dell Technologies — diluted | $ | 3,237 |  |  | $ | 4,532 |  |  |  |  |
| Denominator: Dell Technologies Common Stock weighted-average shares outstanding |  |  |  |  |  |  |
| Weighted-average shares outstanding — basic | 744 |  |  | 724 |  |  |  |  |
| Dilutive effect of options, restricted stock units, restricted stock, and other | 23 |  |  | 27 |  |  |  |  |
| Weighted-average shares outstanding — diluted | 767 |  |  | 751 |  |  |  |  |
| Weighted-average shares outstanding — antidilutive | — |  |  | — |  |  |  |  |

[0001571996-21-000007:notes:445]
(a)The incremental dilution from VMware, Inc. represents the impact of VMware, Inc.’s dilutive securities on diluted earnings (loss) per share of Dell Technologies Common Stock, and is calculated by multiplying the difference between VMware, Inc.’s basic and diluted earnings (loss) per share by the number of shares of VMware, Inc. common stock held by the Company.  For the fiscal year ended January 31, 2020, incremental dilution from VMware, Inc. was calculated by the Company without regard to VMware Inc.’s required retrospective adjustments for the Pivotal acquisition in its stand-alone financial statements.  There is no incremental dilution from Secureworks due to its net loss position for the periods presented.

[0001571996-21-000007:notes:446]
The following table presents the computation of basic and diluted earnings (loss) per share prior to the fiscal year ended January 31, 2020 for the period indicated:

[0001571996-21-000007:notes:447]
|  | Fiscal Year Ended |
|  | February 1, 2019 |
| Numerator: Class V Common Stock |  |
| Net income attributable to Class V Common Stock — basic (a) | $ | 1,195 |  |
| Incremental dilution from VMware, Inc. attributable to Class V Common Stock (b) | (18) |  |
| Net income attributable to Class V Common Stock — diluted | $ | 1,177 |  |
| Numerator: DHI Group |  |
| Net loss attributable to DHI Group — basic | $ | (3,505) |  |
| Incremental dilution from VMware, Inc. attributable to DHI Group (b) | (13) |  |
| Net loss attributable to DHI Group — diluted | $ | (3,518) |  |
| Denominator: Class V Common Stock weighted-average shares outstanding |  |
| Weighted-average shares outstanding — basic (c) | 199 |  |
| Dilutive effect of options, restricted stock units, restricted stock, and other (d) | — |  |
| Weighted-average shares outstanding — diluted | 199 |  |
| Weighted-average shares outstanding — antidilutive (d) | — |  |
| Denominator: DHI Group weighted-average shares outstanding |  |
| Weighted-average shares outstanding — basic (e) | 582 |  |
| Dilutive effect of options, restricted stock units, restricted stock, and other | — |  |
| Weighted-average shares outstanding — diluted | 582 |  |
| Weighted-average shares outstanding — antidilutive (f) | 44 |  |

[0001571996-21-000007:notes:448]
(a)For the fiscal year ended February 1, 2019, net income attributable to the Class V Common Stock - basic represents net income attributable to the Class V Group for the period ended December 27, 2018, the last date on which the Class V Common Stock was traded on the NYSE.

[0001571996-21-000007:notes:449]
(b)The incremental dilution from VMware, Inc. represents the impact of VMware, Inc.’s dilutive securities on the diluted earnings (loss) per share of the DHI Group and the Class V Common Stock, respectively, and is calculated by multiplying the difference between VMware, Inc.’s basic and diluted earnings (loss) per share by the number of shares of VMware, Inc. common stock held by the Company.

[0001571996-21-000007:notes:450]
(c)For the fiscal year ended February 1, 2019, the Class V Common Stock weighted-average shares outstanding - basic represents the weighted-average for the period ended December 27, 2018, the last date on which the Class V Common Stock was traded on the NYSE.

[0001571996-21-000007:notes:451]
(d)The dilutive effect of Class V Common Stock-based incentive awards was not material to the calculation of the weighted-average Class V Common Stock shares outstanding.  The antidilutive effect of these awards was also not material.

[0001571996-21-000007:notes:452]
(e)For the fiscal year ended February 1, 2019, the DHI Group weighted-average shares outstanding - basic represents the weighted-average shares over the twelve month period, with the Class C shares weighted for the number of days outstanding before and after the completion of the Class V transaction.

[0001571996-21-000007:notes:453]
(f)Stock-based incentive awards have been excluded from the calculation of the DHI Group’s diluted loss per share because their effect would have been antidilutive, as the Company had a net loss attributable to the DHI Group for the period presented.

[0001571996-21-000007:notes:454]
The income allocation and earnings per share for the fiscal year ended February 1, 2019 were not impacted by the acquisition of Pivotal by VMware, Inc., because shares of Class V Common Stock were no longer outstanding.  The following table presents a summary of the net loss attributable to Dell Technologies Inc. for the period indicated:

[0001571996-21-000007:notes:455]
|  | Fiscal Year Ended |
|  | February 1, 2019 |
|  | (in millions) |
| Net income attributable to Class V Common Stock | $ | 1,195 |  |
| Net loss attributable to DHI Group | (3,505) |  |
| Net loss attributable to Dell Technologies Inc. | $ | (2,310) |  |

[0001571996-21-000007:notes:456]
The following table presents the basis of allocation of net income attributable to the Class V Group for the period indicated:

[0001571996-21-000007:notes:457]
|  | Fiscal Year Ended |
|  | February 1, 2019 |
|  | (in millions) |
| Net income attributable to VMware | $ | 2,422 |  |
| Less: Net income attributable to VMware for the period from December 28, 2018 to February 1, 2019 | (15) |  |
| Less: Net income attributable to non-controlling interests | (452) |  |
| Net income attributable to Class V Group | 1,955 |  |
| Less: DHI Group's 38.90% weighted average retained interest in Class V Group | (760) |  |
| Class V Common Stock economic interest in Class V Group (a) | $ | 1,195 |  |

[0001571996-21-000007:notes:458]
(a)    For the fiscal year ended February 1, 2019, Class V Common Stock economic interest in the Class V Group represents net income attributable to the Class V Group for the period ended December 27, 2018, the last date on which the Class V Common Stock was traded on the NYSE.

[0001571996-21-000007:notes:459]
The following table presents a reconciliation of the VMware reportable segment results to the VMware, Inc. results attributable to the Class V Group pursuant to the tracking stock policy for the period indicated.  The VMware reportable segment results presented below were recast as discussed in Note 19 of the Notes to the Consolidated Financial Statements.  The VMware, Inc. results were not impacted by the Pivotal acquisition.

[0001571996-21-000007:notes:460]
|  | Fiscal Year Ended |
|  | February 1, 2019 |
|  | VMware Reportable Segment |  | Adjustments and Eliminations (a) |  | VMware |
|  | (in millions) |
| Net revenue | $ | 9,741 |  |  | $ | (767) |  |  | $ | 8,974 |  |
| Cost of net revenue | 1,312 |  |  | (54) |  |  | 1,258 |  |
| Gross margin | 8,429 |  |  | (713) |  |  | 7,716 |  |
| Operating expenses: |  |  |  |  |  |
| Selling, general, and administrative | 3,720 |  |  | (29) |  |  | 3,691 |  |
| Research and development | 1,783 |  |  | 192 |  |  | 1,975 |  |
| Total operating expenses | 5,503 |  |  | 163 |  |  | 5,666 |  |
| Operating income (loss) | $ | 2,926 |  |  | $ | (876) |  |  | $ | 2,050 |  |
| Interest and other income (expense), net attributable to VMware |  |  |  |  | 833 |  |
| Income before income taxes attributable to VMware |  |  |  |  | 2,883 |  |
| Income tax provision attributable to VMware |  |  |  |  | 461 |  |
| Net income attributable to VMware |  |  |  |  | $ | 2,422 |  |

[0001571996-21-000007:notes:461]
(a)    Adjustments and eliminations primarily consist of intercompany sales and allocated expenses, as well as expenses that are excluded from the VMware reportable segment, such as amortization of intangible assets, stock-based compensation expense, severance, and integration and acquisition-related costs.  Adjustments also include adjustments and eliminations pertaining to Pivotal results.


## dell:ReconciliationofConsolidatedNetIncomeLossTableTextBlock

[0001571996-21-000007:notes:462]
The following table presents a summary of the net loss attributable to Dell Technologies Inc. for the period indicated:

[0001571996-21-000007:notes:463]
The following table presents a reconciliation of the equity in net income (loss) of subsidiaries to the net income (loss) attributable to Dell Technologies Inc., and a reconciliation of consolidated net income (loss) to comprehensive net income (loss) attributable to Dell Technologies Inc. for the periods indicated:

[0001571996-21-000007:notes:464]
|  | Fiscal Year Ended |
|  | January 29, 2021 |  | January 31, 2020 |  | February 1, 2019 |
|  | (in millions) |
| Equity in net income (loss) of subsidiaries attributable to Dell Technologies Inc. | $ | 3,267 |  |  | $ | 4,643 |  |  | $ | (2,042) |  |
| Parent - Total operating expense (a) | (16) |  |  | (21) |  |  | (273) |  |
| Parent - Interest and other, net | — |  |  | — |  |  | (20) |  |
| Parent - Income tax (expense) benefit (a) | (1) |  |  | (6) |  |  | 25 |  |
| Parent - Loss before equity in net income of subsidiaries | $ | (17) |  |  | $ | (27) |  |  | $ | (268) |  |
| Consolidated net income (loss) attributable to Dell Technologies Inc. | 3,250 |  |  | 4,616 |  |  | (2,310) |  |
| Other comprehensive income (loss) of subsidiaries attributable to Dell Technologies Inc. | 395 |  |  | (242) |  |  | (539) |  |
| Comprehensive income (loss) attributable to Dell Technologies Inc. | $ | 3,645 |  |  | $ | 4,374 |  |  | $ | (2,849) |  |

[0001571996-21-000007:notes:465]
(a)    During the fiscal years ended January 29, 2021, January 31, 2020, and February 1, 2019, the total operating expense and the associated income tax (expense) benefit were primarily related to the costs incurred in the Class V transaction described in Note 1 of the Notes to the Consolidated Financial Statements.


## us-gaap:ReconciliationOfRevenueFromSegmentsToConsolidatedTextBlock

[0001571996-21-000007:notes:466]
The following table presents a reconciliation of net revenue by the Company’s reportable segments to the Company’s consolidated net revenue as well as a reconciliation of consolidated segment operating income to the Company’s consolidated operating income (loss) for the periods indicated:

[0001571996-21-000007:notes:467]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  | January 29, 2021 |  | January 31, 2020 |  | February 1, 2019 |
|  |  |  |  |  | (in millions) |
| Consolidated net revenue: |  |  |  |  |  |  |  |  |  |
| Infrastructure Solutions Group |  |  |  |  | $ | 32,588 |  |  | $ | 33,969 |  |  | $ | 36,720 |  |
| Client Solutions Group |  |  |  |  | 48,355 |  |  | 45,838 |  |  | 43,196 |  |
| VMware |  |  |  |  | 11,873 |  |  | 10,905 |  |  | 9,741 |  |
| Reportable segment net revenue |  |  |  |  | 92,816 |  |  | 90,712 |  |  | 89,657 |  |
| Other businesses (a) |  |  |  |  | 1,567 |  |  | 1,788 |  |  | 1,676 |  |
| Unallocated transactions (b) |  |  |  |  | 6 |  |  | 1 |  |  | (9) |  |
| Impact of purchase accounting (c) |  |  |  |  | (165) |  |  | (347) |  |  | (703) |  |
| Total consolidated net revenue |  |  |  |  | $ | 94,224 |  |  | $ | 92,154 |  |  | $ | 90,621 |  |
| Consolidated operating income: |  |  |  |  |  |  |  |  |  |
| Infrastructure Solutions Group |  |  |  |  | $ | 3,776 |  |  | $ | 4,001 |  |  | $ | 4,151 |  |
| Client Solutions Group |  |  |  |  | 3,352 |  |  | 3,138 |  |  | 1,960 |  |
| VMware |  |  |  |  | 3,571 |  |  | 3,081 |  |  | 2,926 |  |
| Reportable segment operating income |  |  |  |  | 10,699 |  |  | 10,220 |  |  | 9,037 |  |
| Other businesses (a) |  |  |  |  | 99 |  |  | (43) |  |  | (111) |  |
| Unallocated transactions (b) |  |  |  |  | — |  |  | (29) |  |  | (72) |  |
| Impact of purchase accounting (c) |  |  |  |  | (213) |  |  | (411) |  |  | (820) |  |
| Amortization of intangibles |  |  |  |  | (3,393) |  |  | (4,408) |  |  | (6,138) |  |
| Transaction-related expenses (d) |  |  |  |  | (257) |  |  | (285) |  |  | (750) |  |
| Stock-based compensation expense (e) |  |  |  |  | (1,609) |  |  | (1,262) |  |  | (918) |  |
| Other corporate expenses (f) |  |  |  |  | (182) |  |  | (1,160) |  |  | (419) |  |
| Total consolidated operating income (loss) |  |  |  |  | $ | 5,144 |  |  | $ | 2,622 |  |  | $ | (191) |  |

[0001571996-21-000007:notes:468]
(a)Secureworks, Virtustream, and Boomi constitute Other businesses and do not meet the requirements for a reportable segment, either individually or collectively.  The results of Other businesses are not material to the Company’s overall results.  On September 1, 2020, the Company completed the sale of RSA Security.  Prior to the divestiture, RSA Security’s results were included within Other businesses.  See Note 1 of the Notes to the Consolidated Financial Statements for more information about the divestiture of RSA Security.

[0001571996-21-000007:notes:469]
(b)Unallocated transactions includes other corporate items that are not allocated to Dell Technologies’ reportable segments.

[0001571996-21-000007:notes:470]
(c)Impact of purchase accounting includes non-cash purchase accounting adjustments that are primarily related to the EMC merger transaction.

[0001571996-21-000007:notes:471]
(d)Transaction-related expenses includes acquisition, integration, and divestiture related costs, as well as the costs incurred in the Class V transaction described in Note 1 of the Notes to the Consolidated Financial Statements.

[0001571996-21-000007:notes:472]
(e)Stock-based compensation expense consists of equity awards granted based on the estimated fair value of those awards at grant date.

[0001571996-21-000007:notes:473]
(f)Other corporate expenses includes impairment charges, severance, facility action, and other costs.  This category also includes the derecognition of a VMware, Inc. patent litigation accrual of $237 million, which was initially recognized during the fiscal year ended January 31, 2020 and was subsequently fully reversed during the fiscal year ended January 29, 2021.  See Note 10 of the Notes to the Consolidated Financial Statements for additional information about this litigation matter.  For the fiscal years ended January 31, 2020 and February 1, 2019, this category includes Virtustream pre-tax impairment charges of $619 million and $190 million, respectively.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001571996-21-000007:notes:474]
NOTE 16 — STOCK-BASED COMPENSATION

[0001571996-21-000007:notes:475]
Stock-Based Compensation Expense

[0001571996-21-000007:notes:476]
The following table presents stock-based compensation expense recognized in the Consolidated Statements of Income (Loss) for the periods indicated:

[0001571996-21-000007:notes:477]
|  | Fiscal Year Ended |
|  | January 29, 2021 |  | January 31, 2020 |  | February 1, 2019 |
|  | (in millions) |
| Stock-based compensation expense (a): |  |  |  |  |  |
| Cost of net revenue | $ | 194 |  |  | $ | 129 |  |  | $ | 76 |  |
| Operating expenses | 1,415 |  |  | 1,133 |  |  | 842 |  |
| Stock-based compensation expense before taxes | 1,609 |  |  | 1,262 |  |  | 918 |  |
| Income tax benefit | (313) |  |  | (392) |  |  | (260) |  |
| Stock-based compensation expense, net of income taxes | $ | 1,296 |  |  | $ | 870 |  |  | $ | 658 |  |

[0001571996-21-000007:notes:478]
(a)    Stock-based compensation expense before taxes for the fiscal years ended January 29, 2021, January 31, 2020, and February 1, 2019 includes $1,122 million, $892 million and $731 million, respectively, related to the VMware, Inc. plans discussed below.

[0001571996-21-000007:notes:479]
Dell Technologies Inc. Stock-Based Compensation Plans

[0001571996-21-000007:notes:480]
Dell Technologies Inc. 2013 Stock Incentive Plan (As Amended and Restated as of July, 9, 2019) — On September 7, 2016, at the effective time of the EMC merger transaction, the Denali Holding Inc. 2013 Stock Incentive Plan (the “2013 Plan”) was amended and restated as the Dell Technologies Inc. 2013 Stock Incentive Plan (the “Restated Plan”).  Employees, consultants, non-employee directors, and other service providers of the Company or its affiliates are eligible to participate in the Restated Plan.  The Restated Plan authorized the issuance of an aggregate of 75 million shares of the Company’s Class C Common Stock and 500,000 shares of the Company’s Class V Common Stock, of which 61 million shares of Class C Common Stock were previously reserved for issuance under the 2013 Plan.  The Restated Plan authorizes the Company to grant stock options, restricted stock units (“RSUs”), stock appreciation rights (“SARs”), RSAs, and dividend equivalents.

[0001571996-21-000007:notes:481]
Upon the completion of the Class V transaction on December 28, 2018, the Restated Plan was amended to remove allowance for employee awards to be settled in Class V Common Stock and reflected an increase in the total authorized shares of Class C Common Stock issued under the plan to 75.5 million shares from 75 million shares upon the conversion of 500,000 shares of Class V Common Stock previously authorized under the plan into the same number of shares of Class C Common Stock.  In connection with the Class V transaction, an immaterial number of Class V Common Stock awards issued to the Company’s independent directors were converted into an immaterial number of Class C Common Stock awards, which are reflected in the underlying stock option and restricted stock data as outstanding.  See Note 1 of the Notes to the Consolidated Financial Statements for additional information on the Class V transaction.

[0001571996-21-000007:notes:482]
During the second quarter of the fiscal year ended January 31, 2020, the Company’s stockholders approved an amendment to the Restated Plan to authorize an additional 35 million shares of Class C Common Stock for issuance pursuant to the Plan.  Upon effectiveness of the amendment, a total of 110.5 million shares of Class C Common Stock are authorized for issuance.  As of January 29, 2021, there were approximately 32 million shares of Class C Common Stock available for future grants under the Restated Plan.

[0001571996-21-000007:notes:483]
Stock Option Agreements — Stock options granted under the Restated Plan include service-based awards and performance-based awards.  A majority of the service-based stock options vest pro-rata at each option anniversary date over a five-year period.  Outstanding performance-based stock options became fully vested upon the achievement of a prescribed return on equity (“ROE”) measurement that was approved by the Company’s board of directors in connection with the Class V transaction.  Both service-based and performance-based stock options are granted with option exercise prices equal to the fair market value of the Company’s common stock.  Prior to the Class V transaction, the fair market value was determined by the Company’s board of directors or authorized committee.  After the Class V transaction, the fair market value is based on the closing price of the Class C Common Stock as reported on the NYSE on the grant date.  A majority of the stock options expire ten years after the date of grant.

[0001571996-21-000007:notes:484]
Stock Option Activity — The following table presents stock option activity settled in Dell Technologies Common Stock or DHI Group Common Stock for the periods indicated:

[0001571996-21-000007:notes:485]
|  | Number of Options |  | Weighted-Average Exercise Price |  | Weighted-Average Remaining Contractual Term |  | Aggregate Intrinsic Value (a) |
|  | (in millions) |  | (per share) |  | (in years) |  | (in millions) |
| Options outstanding as of February 2, 2018 | 42 |  |  | $ | 14.80 |  |  |  |  |  |
| Granted | — |  |  | — |  |  |  |  |  |
| Exercised | — |  |  | — |  |  |  |  |  |
| Forfeited | — |  |  | — |  |  |  |  |  |
| Canceled/expired | — |  |  | — |  |  |  |  |  |
| Options outstanding as of February 1, 2019 (b) | 42 |  |  | 14.76 |  |  |  |  |  |
| Granted | — |  |  | — |  |  |  |  |  |
| Exercised | (24) |  |  | 14.86 |  |  |  |  |  |
| Forfeited | — |  |  | — |  |  |  |  |  |
| Canceled/expired | — |  |  | — |  |  |  |  |  |
| Options outstanding as of January 31, 2020 (c) | 18 |  |  | 14.82 |  |  |  |  |  |
| Granted | — |  |  | — |  |  |  |  |  |
| Exercised | (12) |  |  | 14.32 |  |  |  |  |  |
| Forfeited | — |  |  | — |  |  |  |  |  |
| Canceled/expired | — |  |  | — |  |  |  |  |  |
| Options outstanding as of January 29, 2021(c) | 6 |  |  | $ | 15.87 |  |  | 3.2 |  | $ | 322 |  |
| Exercisable as of January 29, 2021 | 6 |  |  | $ | 15.65 |  |  | 3.2 |  | $ | 321 |  |
| Vested and expected to vest (net of estimated forfeitures) as of January 29, 2021 | 6 |  |  | $ | 15.87 |  |  | 3.2 |  | $ | 322 |  |

[0001571996-21-000007:notes:486]
(a)    The aggregate intrinsic values represent the total pre-tax intrinsic values based on the closing price of $72.89 of the Company’s Class C Common Stock on January 29, 2021 as reported on the NYSE that would have been received by the option holders had all in-the-money options been exercised as of that date.

[0001571996-21-000007:notes:487]
(b)    Stock option activity during the period was immaterial.  The ending weighted-average exercise price was calculated based on underlying options outstanding as of February 1, 2019.

[0001571996-21-000007:notes:488]
(c)    Other than stock option exercises, stock option activity during the period was immaterial.  The ending weighted-average exercise price was calculated based on underlying options outstanding as of January 31, 2020 and January 29, 2021, respectively.  Of the 6 million stock options outstanding on January 29, 2021, 4 million related to performance-based awards and 2 million related to service-based awards.

[0001571996-21-000007:notes:489]
The total fair value of options vested was $3 million, $4 million, and $150 million for the fiscal years ended January 29, 2021, January 31, 2020, and February 1, 2019, respectively.  The pre-tax intrinsic value of the options exercised was $591 million, $835 million, and $18 million for the fiscal years ended January 29, 2021, January 31, 2020, and February 1, 2019, respectively.  Cash proceeds from the exercise of stock options was $179 million, $350 million, and immaterial for the fiscal years ended January 29, 2021, January 31, 2020, and  February 1, 2019, respectively.

[0001571996-21-000007:notes:490]
The tax benefit realized from the exercise of stock options was $139 million, $197 million, and $5 million for the fiscal years ended January 29, 2021, January 31, 2020, and February 1, 2019, respectively.  As of January 29, 2021, there was $1 million of total unrecognized stock-based compensation expense, net of estimated forfeitures, related to unvested stock options expected to be recognized over a weighted-average period of 2.2 years.

[0001571996-21-000007:notes:491]
Restricted Stock — The Company’s restricted stock primarily consists of RSUs granted to employees.  During the fiscal year ended January 29, 2021 and January 31, 2020, the Company granted long-term incentive awards in the form of service-based RSUs and performance-based RSUs (“PSUs”) in order to align critical talent retention programs with the interests of holders of the Class C Common Stock.

[0001571996-21-000007:notes:492]
Service-based RSUs have a fair value based on the closing price of the Class C Common Stock price as reported on the NYSE on the grant date or the trade day immediately preceding the grant date, if the grant date falls on a non-trading day.  Most of such RSUs vest ratably over a three-year period.  Each service-based RSU represents the right to acquire one share of Class C Common Stock upon vesting.  Prior to the Class V transaction, each RSU converted into one share of DHI Group Common Stock upon vesting.

[0001571996-21-000007:notes:493]
The PSUs granted after the Class V transaction are reflected as target units while the actual number of units that ultimately vest will range from 0% to 200% of target, based on the level of achievement of the performance goals and continued employment with the Company over a three-year performance period.  Approximately half of the PSUs granted are subject to achievement of market-based performance goals based on relative total shareholder return and were valued utilizing a Monte Carlo valuation model to simulate the probabilities of achievement.  The remaining PSUs are subject to internal financial metrics and have fair values based on the closing price of the Class C Common Stock as reported on the NYSE on the accounting grant date.

[0001571996-21-000007:notes:494]
Prior to the Class V transaction, the Company granted market-based PSUs to certain members of the Company’s senior leadership team, which were also valued using the Monte Carlo model.  The vesting and payout of the PSU awards depends upon the return on equity achieved on various measurement dates through the five year anniversary of the EMC merger transaction or specified liquidity events.

[0001571996-21-000007:notes:495]
The following table presents the assumptions utilized in the Monte Carlo valuation model for the periods indicated:

[0001571996-21-000007:notes:496]
|  | Fiscal Year Ended |
|  | January 29, 2021 |  | January 31, 2020 |
| Weighted-average grant date fair value | $ | 40.01 |  |  | $ | 87.17 |  |
| Term (in years) | 3.0 |  | 3.0 |
| Risk-free rate (U.S. Government Treasury Note) | 0.6 | % |  | 2.4 | % |
| Expected volatility | 47 | % |  | 45 | % |
| Expected dividend yield | — | % |  | — | % |

[0001571996-21-000007:notes:497]
The following table presents restricted stock and restricted stock units activity settled in Dell Technologies Common Stock or DHI Group Common Stock for the periods indicated:

[0001571996-21-000007:notes:498]
|  | Number of Units |  | Weighted-Average Grant Date Fair Value |
|  | (in millions) |  | (per unit) |
| Outstanding, February 2, 2018 | 7 |  |  | $ | 18.73 |  |
| Granted (a) | — |  |  | — |  |
| Vested | (1) |  |  | 28.03 |  |
| Forfeited | (1) |  |  | 17.88 |  |
| Outstanding, February 1, 2019 | 5 |  |  | $ | 18.90 |  |
| Granted | 13 |  |  | 60.55 |  |
| Vested | (1) |  |  | 30.24 |  |
| Forfeited | (1) |  |  | 46.50 |  |
| Outstanding, January 31, 2020 | 16 |  |  | $ | 50.78 |  |
| Granted | 25 |  |  | 39.14 |  |
| Vested | (5) |  |  | 48.15 |  |
| Forfeited | (3) |  |  | 41.56 |  |
| Outstanding, January 29, 2021 (b) | 33 |  |  | $ | 43.09 |  |

[0001571996-21-000007:notes:499]
(a)    The Company granted an immaterial number of restricted stock awards during the fiscal year ended February 1, 2019.

[0001571996-21-000007:notes:500]
(b)    As of January 29, 2021, the 33 million units outstanding included 28 million RSUs and 5 million PSUs.

[0001571996-21-000007:notes:501]
The following table presents restricted stock that is expected to vest as of the date indicated:

[0001571996-21-000007:notes:502]
|  | Number of Units |  | Weighted-Average Remaining Contractual Term |  | Aggregate Intrinsic Value (a) |
|  | (in millions) |  | (in years) |  | (in millions) |
| Expected to vest, January 29, 2021 | 30 |  |  | 1.3 |  | $ | 2,166 |  |

[0001571996-21-000007:notes:503]
(a)The aggregate intrinsic value represents the total pre-tax intrinsic values based on the closing price of $72.89 of the Company’s Class C Common Stock on January 29, 2021 as reported on the NYSE that would have been received by the RSU holders had the RSUs been issued as of January 29, 2021.

[0001571996-21-000007:notes:504]
The total fair value of restricted stock that vested during the fiscal years ended January 29, 2021, January 31, 2020, and February 1, 2019 was $235 million, $27 million, and $24 million, respectively, and the pre-tax intrinsic value was $226 million, $47 million, and $63 million, respectively.  As of January 29, 2021, 33 million shares of restricted stock were outstanding, with an aggregate intrinsic value of $2,421 million.

[0001571996-21-000007:notes:505]
As of January 29, 2021, there was $809 million of unrecognized stock-based compensation expense, net of estimated forfeitures, related to these awards expected to be recognized over a weighted-average period of approximately 1.9 years.

[0001571996-21-000007:notes:506]
Dell Technologies Shares Withheld for Taxes — Under certain situations, shares are withheld from issuance to cover employee taxes for both the vesting of restricted stock units and the exercise of stock options.  For the fiscal years ended January 29, 2021, February 1, 2019, and February 2, 2018, 0.1 million, 0.1 million, and 0.4 million shares, respectively, were withheld to cover $1 million, $4 million, and $28 million, respectively, of employees’ tax obligations.

[0001571996-21-000007:notes:507]
VMware, Inc. Stock-Based Compensation Plans

[0001571996-21-000007:notes:508]
VMware, Inc. 2007 Equity and Incentive Plan — In June 2007, VMware, Inc. adopted its 2007 Equity and Incentive Plan (the “2007 Plan”).  In June 2019, VMware, Inc. amended its 2007 Plan to increase the number of shares of Class A common stock available for issuance by 13 million.  As of January 29, 2021, the number of authorized shares of VMware, Inc. Class A common stock under the 2007 Plan was approximately 145 million.  The number of shares underlying outstanding equity awards that VMware, Inc. assumes in the course of business acquisitions are also added to the 2007 Plan reserve on an as-converted basis.  VMware, Inc. has assumed approximately 12 million shares, which accordingly have been added to the authorized shares under the 2007 Plan reserve.

[0001571996-21-000007:notes:509]
Awards under the 2007 Plan may be in the form of stock-based awards such as RSUs or stock options.  VMware, Inc.’s Compensation and Corporate Governance Committee determines the vesting schedule for all equity awards.  Generally, restricted stock grants made under the 2007 Plan have a three-year to four-year period over which they vest and vest 25% the first year and semiannually thereafter.  The value of RSU grants is based on VMware, Inc.’s stock price on the date of grant.  The shares underlying the RSU awards are not issued until the RSUs vest.  Upon vesting, each RSU converts into one share of VMware, Inc. Class A common stock.  VMware, Inc.’s restricted stock also includes PSU awards which have been granted to certain VMware, Inc. executives and employees.  The PSU awards include performance conditions and, in certain cases, a time-based or market-based vesting component.  Upon vesting, each PSU award will convert into VMware, Inc.’s Class A common stock at various ratios ranging from 0.1 to 2.0 shares per PSU, depending upon the degree of achievement of the performance or market based target designated by each award.  If minimum performance thresholds are not achieved, then no shares will be issued.

[0001571996-21-000007:notes:510]
The per share exercise price for a stock option awarded under the 2007 Plan will not be less than 100% of the per share fair market value of VMware, Inc. Class A common stock on the date of grant.  Most options granted under the 2007 Plan vest 25% after the first year and monthly thereafter over the following three years and expire between six and seven years from the date of grant.  VMware, Inc. utilizes authorized and unissued shares to satisfy all shares issued under the 2007 Plan.  As of January 29, 2021, there was an aggregate of approximately 18 million shares of common stock available for issuance pursuant to future grants under the 2007 Plan.

[0001571996-21-000007:notes:511]
Pivotal Equity Plan — Upon the completion of the acquisition of Pivotal by VMware, Inc. as described in Note 1 of the Notes to the Consolidated Financial Statements, Pivotal’s equity plan was terminated and no further awards may be granted under the plan.  Pivotal’s outstanding unvested RSUs and options on the date of the acquisition were converted to VMware, Inc. RSUs and options and valued at their historical carrying amounts.  The activity under Pivotal’s equity plan was not material during the fiscal years ended January 31, 2020 and February 1, 2019.

[0001571996-21-000007:notes:512]
VMware, Inc. Employee Stock Purchase Plan — In June 2007, VMware, Inc. adopted its 2007 Employee Stock Purchase Plan (the “ESPP”), which is intended to be qualified under Section 423 of the Internal Revenue Code.  In June 2019, VMware, Inc. amended its ESPP to increase the number of shares of Class A common stock available for issuance by 9 million.  As of January 29, 2021, the number of authorized shares under the ESPP was approximately 32 million.  Under the ESPP, eligible VMware, Inc. employees are granted options to purchase shares at the lower of 85% of the fair market value of the stock at the time of grant or 85% of the fair market value at the time of exercise.

[0001571996-21-000007:notes:513]
The option period is generally twelve months and includes two embedded six-month option periods.  Options are exercised at the end of each embedded option period.  If the fair market value of the stock is lower on the first day of the second embedded option period than it was at the time of grant, then the twelve-month option period expires and each enrolled participant is granted a new twelve-month option.  As of January 29, 2021, approximately 12 million shares of VMware, Inc. Class A common stock were available for issuance under the ESPP.

[0001571996-21-000007:notes:514]
The following table presents ESPP activity for the periods indicated:

[0001571996-21-000007:notes:515]
|  | Fiscal Year Ended |
|  | January 29, 2021 (a) |  | January 31, 2020 |  | February 1, 2019 |
|  | (in millions, except per share amounts) |
| Cash proceeds | $ | 207 |  |  | $ | 172 |  |  | $ | 161 |  |
| Class A common shares purchased | 2.0 |  |  | 1.5 |  |  | 1.9 |  |
| Weighted-average price per share | $ | 102.44 |  |  | $ | 115.51 |  |  | $ | 84.95 |  |

[0001571996-21-000007:notes:516]
(a)  During the fiscal year ended January 29, 2021, $107 million of ESPP withholdings was recorded as a liability in accrued and other on the Consolidated Statements of Financial Position related to a purchase under the ESPP that occurred on February 28, 2021, subsequent to the fiscal year ended January 29, 2021.

[0001571996-21-000007:notes:517]
Total unrecognized stock-based compensation expense as of January 29, 2021 for the ESPP was $11 million.

[0001571996-21-000007:notes:518]
VMware, Inc. 2007 Equity and Incentive Plan Stock Options — The following table presents stock option activity for VMware, Inc. employees in VMware, Inc. stock options for the periods indicated:

[0001571996-21-000007:notes:519]
|  | Number of Options |  | Weighted-Average Exercise Price |  | Weighted-Average Remaining Contractual Term |  | Aggregate Intrinsic Value (a) |
|  | (in millions) |  | (per share) |  | (in years) |  | (in millions) |
| Options outstanding as of February 2, 2018 | 2 |  |  | $ | 54.63 |  |  |  |  |  |
| Granted | 1 |  |  | 16.07 |  |  |  |  |  |
| Adjustment for special cash dividend | — |  |  | — |  |  |  |  |  |
| Exercised | (1) |  |  | 46.73 |  |  |  |  |  |
| Forfeited | — |  |  | — |  |  |  |  |  |
| Canceled/expired | — |  |  | — |  |  |  |  |  |
| Options outstanding as of February 1, 2019 (b) | 2 |  |  | 36.50 |  |  |  |  |  |
| Granted | 2 |  |  | 73.19 |  |  |  |  |  |
| Exercised | (1) |  |  | 39.94 |  |  |  |  |  |
| Forfeited | — |  |  | — |  |  |  |  |  |
| Canceled/expired | — |  |  | — |  |  |  |  |  |
| Options outstanding as of January 31, 2020 | 3 |  |  | 56.58 |  |  |  |  |  |
| Granted | — |  |  | — |  |  |  |  |  |
| Exercised | (2) |  |  | 52.34 |  |  |  |  |  |
| Forfeited | — |  |  | — |  |  |  |  |  |
| Canceled/expired | — |  |  | — |  |  |  |  |  |
| Options outstanding as of January 29, 2021 | 1 |  |  | $ | 58.68 |  |  | 5.9 |  | $ | 98 |  |
| Exercisable as of January 29, 2021 | 1 |  |  | $ | 54.72 |  |  | 5.1 |  | $ | 64 |  |
| Vested and expected to vest (net of estimated forfeitures) as of January 29, 2021 | 1 |  |  | $ | 58.26 |  |  | 5.9 |  | $ | 98 |  |

[0001571996-21-000007:notes:520]
(a)    The aggregate intrinsic value represents the total pre-tax intrinsic values based on VMware, Inc.’s closing stock price of $137.85 on January 29, 2021 as reported on the NYSE that would have been received by the option holders had all in-the-money options been exercised as of that date.

[0001571996-21-000007:notes:521]
(b)    The number of options and weighted-average exercise price of options outstanding as of February 1, 2019 reflect the non-cash adjustments to the options as a result of the special cash dividend paid by VMware, Inc. in connection with the Class V transaction described in Note 1 of the Notes to the Consolidated Financial Statements and below.

[0001571996-21-000007:notes:522]
The above table includes stock options granted in conjunction with unvested stock options assumed in business combinations, including 0.6 million options issued for unvested options assumed as part of the Pivotal acquisition.  As a result, the weighted-average exercise price per share may vary from the VMware, Inc. stock price at time of grant.  The total fair value of VMware, Inc. stock options that vested during the fiscal years ended January 29, 2021, January 31, 2020, and February 1, 2019 was $92 million, $64 million, and $35 million, respectively.  The pre-tax intrinsic value of the options exercised during the fiscal years ended January 29, 2021, January 31, 2020, and February 1, 2019 was $111 million, $103 million, and $56 million, respectively.

[0001571996-21-000007:notes:523]
The tax benefit realized from the exercise of stock options was $24 million, $25 million, and $13 million for the fiscal years ended January 29, 2021, January 31, 2020, and February 1, 2019, respectively.  As of January 29, 2021, there was $35 million of total unrecognized stock-based compensation expense, net of estimated forfeitures, related to unvested stock options expected to be recognized over a weighted-average period of less than one year.

[0001571996-21-000007:notes:524]
Fair Value of VMware, Inc. Options — The fair value of each option to acquire VMware, Inc. Class A common stock granted is estimated on the date of grant using the Black-Scholes option-pricing model.  The following tables present the assumptions utilized in this model, as well as the weighted-average assumptions for the periods indicated:

[0001571996-21-000007:notes:525]
|  | Fiscal Year Ended |
|  | January 29, 2021 |  | January 31, 2020 |  | February 1, 2019 |
| VMware, Inc. 2007 Equity and Incentive Plan |  |  |  |  |  |
| Weighted-average grant date fair value of stock options granted per option | $ | 102.55 |  | $ | 98.00 |  | $ | 143.01 |
| Expected term (in years) | 2.6 |  | 2.7 |  | 3.2 |
| Risk-free rate (U.S. Government Treasury Note) | 0.4 | % |  | 1.5 | % |  | 2.9 | % |
| Expected volatility | 39 | % |  | 34 | % |  | 32 | % |
| Expected dividend yield | — | % |  | — | % |  | — | % |

[0001571996-21-000007:notes:526]
|  | Fiscal Year Ended |
|  | January 29, 2021 |  | January 31, 2020 |  | February 1, 2019 |
| VMware, Inc. Employee Stock Purchase Plan |  |  |  |  |  |
| Weighted-average grant date fair value of stock options granted per option | $ | 33.60 |  | $ | 35.66 |  | $ | 34.72 |
| Expected term (in years) | 0.7 |  | 0.6 |  | 0.8 |
| Risk-free rate (U.S. Government Treasury Note) | 1.0 | % |  | 1.7 | % |  | 2.0 | % |
| Expected volatility | 36 | % |  | 27 | % |  | 33 | % |
| Expected dividend yield | — | % |  | — | % |  | — | % |

[0001571996-21-000007:notes:527]
The weighted-average grant date fair value of VMware, Inc. stock options can fluctuate from period to period primarily due to higher valued options assumed through business combinations with exercise prices lower than the fair market value of VMware, Inc.’s stock on the date of grant.

[0001571996-21-000007:notes:528]
For equity awards granted, volatility was based on an analysis of historical stock prices and implied volatilities of VMware, Inc.’s Class A common stock.  The expected term was based on historical exercise patterns and post-vesting termination behavior, the term of the option period for grants made under the ESPP, or the weighted-average remaining term for options assumed in acquisitions.  VMware, Inc.’s expected dividend yield input was zero as it has not historically paid cash dividends on its common stock, other than the special cash dividend paid in connection with the Class V transaction described in Note 1 of the Notes to the Consolidated Financial Statements and below, and does not expect to pay cash dividends in the future.  The risk-free interest rate was based on a U.S. Treasury instrument whose term is consistent with the expected term of the stock options.

[0001571996-21-000007:notes:529]
On July 1, 2018, in connection with the Class V transaction, VMware, Inc.’s board of directors declared a $11 billion special cash dividend, paid pro-rata to VMware, Inc. stockholders on December 28, 2018 in the amount of $26.81 per outstanding share of VMware, Inc. common stock.

[0001571996-21-000007:notes:530]
VMware, Inc. stock awards that were outstanding at the time of the special cash dividend were adjusted pursuant to anti-dilution provisions in VMware, Inc. equity incentive plan documents that provide for equitable adjustments to be determined by VMware’s Compensation and Corporate Governance Committee in the event of an extraordinary cash dividend.  The adjustments to awards included increasing the number of outstanding restricted stock units and stock options, as well as reducing the exercise prices of outstanding stock options.  The adjustments did not result in incremental stock-based compensation expense as the anti-dilutive adjustments were required by VMware, Inc.’s equity incentive plan.

[0001571996-21-000007:notes:531]
VMware, Inc. Restricted Stock — The following table presents VMware, Inc.’s restricted stock activity for the periods indicated:

[0001571996-21-000007:notes:532]
|  | Number of Units |  | Weighted-Average Grant Date Fair Value |
|  | (in millions) |  | (per unit) |
| Outstanding, February 2, 2018 | 17 |  |  | $ | 78.62 |  |
| Granted | 7 |  |  | 146.61 |  |
| Adjustment for special cash dividend (a) | 3 |  |  | NA |
| Vested | (7) |  |  | 75.45 |  |
| Forfeited | (2) |  |  | 86.90 |  |
| Outstanding, February 1, 2019 (a) | 18 |  |  | $ | 90.06 |  |
| Granted | 9 |  |  | 157.07 |  |
| Vested | (8) |  |  | 80.28 |  |
| Forfeited | (2) |  |  | 101.29 |  |
| Outstanding, January 31, 2020 | 17 |  |  | $ | 128.38 |  |
| Granted | 11 |  |  | 149.63 |  |
| Vested | (8) |  |  | 114.59 |  |
| Forfeited | (2) |  |  | 137.55 |  |
| Outstanding, January 29, 2021(b) | 18 |  |  | $ | 147.46 |  |

[0001571996-21-000007:notes:533]
(a)    The weighted-average grant date fair value of outstanding RSU awards as of February 1, 2019 reflects the non-cash adjustments to the awards as a result of the special cash dividend.

[0001571996-21-000007:notes:534]
(b)    During the fiscal year ended January 29, 2021, 18 million units outstanding included 17 million RSUs and 1 million PSUs.  The above table includes RSUs issued for outstanding unvested RSUs in connection with business combinations, including 2.2 million RSUs issued for unvested RSUs assumed as part of the Pivotal acquisition during the fiscal year ended January 31, 2020.

[0001571996-21-000007:notes:535]
|  | Number of Units |  | Weighted-Average Remaining Contractual Term |  | Aggregate Intrinsic Value (a) |
|  | (in millions) |  | (in years) |  | (in millions) |
| Expected to vest, January 29, 2021 | 15 |  |  | 2.6 |  | $ | 2,097 |  |

[0001571996-21-000007:notes:536]
(a)The aggregate intrinsic value represents the total pre-tax intrinsic values based on VMware, Inc.’s closing stock price of $137.85 on January 29, 2021 as reported on the NYSE that would have been received by the RSU holders had the RSUs been issued as of January 29, 2021.

[0001571996-21-000007:notes:537]
The total fair value of VMware, Inc. restricted stock awards that vested during the fiscal years ended January 29, 2021, January 31, 2020, and February 1, 2019 was $951 million, $657 million, and $556 million, respectively, and the pre-tax intrinsic value was $1,143 million, $1,414 million, and $1,061 million, respectively.  As of January 29, 2021, 18 million restricted shares of VMware, Inc.’s Class A common stock were outstanding, with an aggregate intrinsic value of $2,452 million based on VMware, Inc.’s closing stock price on January 29, 2021 as reported on the NYSE.

[0001571996-21-000007:notes:538]
As of January 29, 2021, there was $1,830 million of unrecognized stock-based compensation expense, net of estimated forfeitures, related to these awards expected to be recognized over a weighted-average period of approximately 1.6 years.

[0001571996-21-000007:notes:539]
VMware, Inc. Shares Withheld for Taxes — For the fiscal years ended January 29, 2021, January 31, 2020, and February 1, 2019, VMware, Inc. repurchased and retired or withheld 3 million shares of VMware, Inc. Class A common stock, each year; for $413 million, $521 million, and $373 million, respectively, to cover tax withholding obligations.  These amounts may differ from the amounts of cash remitted for tax withholding obligations on the Consolidated Statements of Cash Flows due to the timing of payments.  Pursuant to the respective award agreements, these shares were withheld in conjunction with the net share settlement upon the vesting of restricted stock and restricted stock units (including PSUs) during the period.  The value of the withheld shares, including restricted stock units, was classified as a reduction to additional paid-in capital.

[0001571996-21-000007:notes:540]
Other Plans
In addition to the plans disclosed above, the Company has a consolidated subsidiary, Secureworks, that maintains its own equity plan and issues equity grants settling in its own Class A common stock.  The stock option and restricted stock unit activity under this plan was not material during the fiscal years ended January 29, 2021, January 31, 2020, and February 1, 2019.


## us-gaap:ScheduleOfShareBasedPaymentAwardStockOptionsValuationAssumptionsTableTextBlock

[0001571996-21-000007:notes:541]
The following tables present the assumptions utilized in this model, as well as the weighted-average assumptions for the periods indicated:


## us-gaap:ScheduleOfShareBasedCompensationEmployeeStockPurchasePlanActivityTableTextBlock

[0001571996-21-000007:notes:542]
(a)  During the fiscal year ended January 29, 2021, $107 million of ESPP withholdings was recorded as a liability in accrued and other on the Consolidated Statements of Financial Position related to a purchase under the ESPP that occurred on February 28, 2021, subsequent to the fiscal year ended January 29, 2021.
The following table presents stock option activity for VMware, Inc. employees in VMware, Inc. stock options for the periods indicated:


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001571996-21-000007:notes:543]
NOTE 17 — REDEEMABLE SHARES

[0001571996-21-000007:notes:544]
Awards under the Company’s stock incentive plans include certain rights that allow the holder to exercise a put feature for the underlying Class A or Class C Common Stock after a six-month holding period following the issuance of such common stock.  The put feature requires the Company to purchase the stock at its fair market value.  Accordingly, these awards and such common stock are subject to reclassification from equity to temporary equity, and the Company determines the award amounts to be classified as temporary equity as follows:

[0001571996-21-000007:notes:545]
•For stock options to purchase Class C Common Stock subject to service requirements, the intrinsic value of the option is multiplied by the portion of the option for which services have been rendered.  Upon exercise of the option, the amount in temporary equity represents the fair value of the Class C Common Stock.

[0001571996-21-000007:notes:546]
•For stock appreciation rights, RSUs, or RSAs, any of which stock award types are subject to service requirements, the fair value of the share is multiplied by the portion of the share for which services have been rendered.

[0001571996-21-000007:notes:547]
•For share-based arrangements that are subject to the occurrence of a contingent event, those amounts are reclassified to temporary equity based on a probability assessment performed by the Company on a periodic basis.  Contingent events include the achievement of performance-based metrics.

[0001571996-21-000007:notes:548]
In connection with the Class V transaction described in Note 1 of the Notes to the Consolidated Financial Statements, the put feature provisions were amended to provide that the put feature will terminate upon the earlier of June 27, 2021 or the consummation of any underwritten public offering of shares of Class C Common Stock.

[0001571996-21-000007:notes:549]
The following table presents the amount of redeemable shares classified as temporary equity and summarizes the award type as of the dates indicated:

[0001571996-21-000007:notes:550]
|  | January 29, 2021 |  | January 31, 2020 |
|  | (in millions) |
| Redeemable shares classified as temporary equity | $ | 472 |  |  | $ | 629 |  |
| Issued and outstanding unrestricted common shares | 2 |  |  | 2 |  |
| Restricted stock units | — |  |  | 1 |  |
| Outstanding stock options | 6 |  |  | 15 |  |

[0001571996-21-000007:notes:551]
The decrease in the value of redeemable shares during the fiscal year ended January 29, 2021 was primarily attributable to the reduction in the number of shares eligible for put rights, offset by an increase in Class C Common Stock fair value.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001571996-21-000007:notes:552]
NOTE 18 — RETIREMENT PLAN BENEFITS

[0001571996-21-000007:notes:553]
Defined Benefit Retirement Plans

[0001571996-21-000007:notes:554]
The Company sponsors retirement plans for certain employees in the United States and internationally, and some of these plans meet the criteria of a defined benefit retirement plan.  Benefits under defined benefit retirement plans guarantee a particular payment to the employee in retirement.  The amount of retirement benefit is defined by the plan, and is typically a function of the number of years of service rendered by the employee and the employee’s average salary or salary at retirement.  The annual costs of the plans are determined using the projected unit credit actuarial cost method that includes actuarial assumptions and estimates which are subject to change.

[0001571996-21-000007:notes:555]
Net periodic benefit costs related to defined benefit retirement plans were immaterial for the fiscal years ended January 29, 2021, January 31, 2020, and February 1, 2019.  The Company did not make any significant contributions to defined benefit retirement plans for the fiscal years ended January 29, 2021, January 31, 2020, and February 1, 2019, and does not expect to make any significant contributions in Fiscal 2022.

[0001571996-21-000007:notes:556]
U.S. Pension Plan — The Company sponsors a noncontributory defined benefit retirement plan in the United States (the “U.S. pension plan”) which was assumed in connection with the EMC merger transaction.  As of December 1999, the U.S. pension plan was frozen, so employees no longer accrue retirement benefits for future services.  The measurement date for the U.S. pension plan is the end of the Company’s fiscal year.

[0001571996-21-000007:notes:557]
The following table presents attributes of the U.S. pension plan as of the dates indicated:

[0001571996-21-000007:notes:558]
|  | January 29, 2021 |  | January 31, 2020 |
|  | (in millions) |
| Plan assets at fair value (a) | $ | 572 |  |  | $ | 547 |  |
| Benefit obligations | (635) |  |  | (588) |  |
| Underfunded position (b) | $ | (63) |  |  | $ | (41) |  |

[0001571996-21-000007:notes:559]
(a)    Plan assets are managed by outside investment managers.  The Company’s investment strategy with respect to plan assets is to achieve a long-term growth of capital, consistent with an appropriate level of risk.  Assets are recognized at fair value and are primarily classified within Level 2 of the fair value hierarchy.

[0001571996-21-000007:notes:560]
(b)    The underfunded position of the U.S. pension plan is recognized in other non-current liabilities in the Consolidated Statements of Financial Position.

[0001571996-21-000007:notes:561]
As of January 29, 2021, future benefit payments for the U.S. pension plan are expected to be paid as follows: $33 million in Fiscal 2022; $35 million in Fiscal 2023; $36 million in Fiscal 2024; $37 million in Fiscal 2025; $37 million in Fiscal 2026; and $185 million thereafter.

[0001571996-21-000007:notes:562]
International Pension Plans — The Company also sponsors retirement plans outside of the United States which qualify as defined benefit plans.  As of January 29, 2021, the aggregate fair value of plan assets for the international pension plans was $0.2 billion, the aggregate benefit obligations were $0.5 billion, and the aggregate net underfunded position was $0.3 billion.  As of January 31, 2020, the aggregate fair value of plan assets for the international pension plans was $0.2 billion, the aggregate benefit obligations were $0.4 billion, and the aggregate net underfunded position was $0.2 billion.  The underfunded position of the international pension plans is presented within other non-current liabilities on the Consolidated Statements of Financial Position as of the respective dates.

[0001571996-21-000007:notes:563]
Defined Contribution Retirement Plans

[0001571996-21-000007:notes:564]
Dell 401(k) Plan — The Company has a defined contribution retirement plan (the “Dell 401(k) Plan”) that complies with Section 401(k) of the Internal Revenue Code.  Only U.S. employees are eligible to participate in the Dell 401(k) plan.  Historically through May 31, 2020, the Company matched 100% of each participant’s voluntary contributions (the “Dell 401(k) employer match”), subject to a maximum contribution of 6% of the participant’s eligible compensation, up to an annual limit of $7,500, and participants vest immediately in all contributions to the Dell 401(k) Plan.  Effective June 1, 2020, the Company suspended the Dell 401(k) employer match for U.S. employees as a precautionary measure to preserve financial flexibility in light of COVID-19.  Effective January 1, 2021, The Dell 401(k) employer match was reinstated, with no change to the employer match policy or participant eligibility requirements.

[0001571996-21-000007:notes:565]
The Company’s matching contributions as well as participants’ voluntary contributions are invested according to each participant’s elections in the investment options provided under the Dell 401(k) Plan.  The Company’s contributions during the fiscal years ended January 29, 2021, January 31, 2020, and February 1, 2019 were $154 million, $267 million, and $254 million, respectively.  The Company’s contributions decreased during the fiscal year ended January 29, 2021 due to the suspension of the Dell 401(k) employer match between June 1, 2020 and December 31, 2020, as discussed above.

[0001571996-21-000007:notes:566]
VMware, Inc. and Pivotal have defined contribution programs for certain employees that comply with Section 401(k) of the Internal Revenue Code.  Pivotal’s defined contribution program was acquired by VMware, Inc. in connection with VMware Inc.’s acquisition of Pivotal on December 30, 2019.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001571996-21-000007:notes:567]
NOTE 19 — SEGMENT INFORMATION

[0001571996-21-000007:notes:568]
The Company has three reportable segments that are based on the following business units:  Infrastructure Solutions Group (“ISG”); Client Solutions Group (“CSG”); and VMware.

[0001571996-21-000007:notes:569]
On December 30, 2019, VMware, Inc. completed its acquisition of Pivotal.  Due to the Company’s ownership of a controlling interest in Pivotal, the Company and VMware, Inc. accounted for the Pivotal acquisition as a transaction by entities under common control, and consequently the transaction had no net effect to the Company’s consolidated financial statements.  Pivotal now operates as a wholly-owned subsidiary of VMware, Inc. and Dell Technologies reports Pivotal results within the VMware reportable segment.  Previously, Pivotal results were reported within Other businesses. Prior period results have been recast to conform with the current period presentation.

[0001571996-21-000007:notes:570]
ISG enables the digital transformation of the Company’s customers through its trusted multi-cloud and big data solutions, which are built upon a modern data center infrastructure. The ISG comprehensive portfolio of advanced storage solutions includes traditional storage solutions as well as next-generation storage solutions (such as all-flash arrays, scale-out file, object platforms, and software-defined solutions), while the Company’s server portfolio  includes high-performance rack, blade, tower, and hyperscale servers.  The ISG networking portfolio helps business customers transform and modernize their infrastructure, mobilize and enrich end-user experiences, and accelerate business applications and processes.  ISG also offers attached software, peripherals, and services, including support and deployment, configuration, and extended warranty services.

[0001571996-21-000007:notes:571]
CSG includes sales to commercial and consumer customers of branded hardware (such as desktops, workstations, and notebooks) and branded peripherals (such as displays and projectors), as well as services and third-party software and peripherals.  CSG also offers attached software, peripherals, and services, including support and deployment, configuration, and extended warranty services.

[0001571996-21-000007:notes:572]
VMware works with customers in the areas of hybrid and multi-cloud, modern applications, networking, security, and digital workspaces, helping customers manage their IT resources across private clouds and complex multi-cloud, multi-device environments.  VMware enables its customers to digitally transform their operations as they ready their applications, infrastructure, and employees for constantly evolving business needs.

[0001571996-21-000007:notes:573]
The reportable segments disclosed herein are based on information reviewed by the Company’s management to evaluate the business segment results.  The Company’s measure of segment revenue and segment operating income for management reporting purposes excludes operating results of Other businesses, unallocated corporate transactions, the impact of purchase accounting, amortization of intangible assets, transaction-related expenses, stock-based compensation expense, and other corporate expenses, as applicable.  The Company does not allocate assets to the above reportable segments for internal reporting purposes.

[0001571996-21-000007:notes:574]
The following table presents the disaggregation of net revenue by reportable segment, and by major product categories within the segments for the periods indicated:

[0001571996-21-000007:notes:575]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  | January 29, 2021 |  | January 31, 2020 |  | February 1, 2019 |
|  |  |  |  |  | (in millions) |
| Net revenue: |  |  |  |  |  |  |  |  |  |
| Infrastructure Solutions Group: |  |  |  |  |  |  |  |  |  |
| Servers and networking |  |  |  |  | $ | 16,497 |  |  | $ | 17,127 |  |  | $ | 19,953 |  |
| Storage |  |  |  |  | 16,091 |  |  | 16,842 |  |  | 16,767 |  |
| Total ISG net revenue |  |  |  |  | 32,588 |  |  | 33,969 |  |  | 36,720 |  |
| Client Solutions Group: |  |  |  |  |  |  |  |  |  |
| Commercial |  |  |  |  | 35,396 |  |  | 34,277 |  |  | 30,893 |  |
| Consumer |  |  |  |  | 12,959 |  |  | 11,561 |  |  | 12,303 |  |
| Total CSG net revenue |  |  |  |  | 48,355 |  |  | 45,838 |  |  | 43,196 |  |
| VMware: |  |  |  |  |  |  |  |  |  |
| Total VMware net revenue |  |  |  |  | 11,873 |  |  | 10,905 |  |  | 9,741 |  |
| Total segment net revenue |  |  |  |  | $ | 92,816 |  |  | $ | 90,712 |  |  | $ | 89,657 |  |

[0001571996-21-000007:notes:576]
The following table presents net revenue allocated between the United States and foreign countries for the periods indicated:

[0001571996-21-000007:notes:577]
|  | Fiscal Year Ended |
|  | January 29, 2021 |  | January 31, 2020 |  | February 1, 2019 |
|  | (in millions) |
| Net revenue: |  |  |  |  |  |
| United States | $ | 45,671 |  |  | $ | 43,829 |  |  | $ | 42,803 |  |
| Foreign countries | 48,553 |  |  | 48,325 |  |  | 47,818 |  |
| Total net revenue | $ | 94,224 |  |  | $ | 92,154 |  |  | $ | 90,621 |  |

[0001571996-21-000007:notes:578]
The following table presents property, plant, and equipment, net allocated between the United States and foreign countries as of the dates indicated:

[0001571996-21-000007:notes:579]
|  | January 29, 2021 |  | January 31, 2020 |
|  | (in millions) |
| Property, plant, and equipment, net: |  |  |  |
| United States | $ | 4,524 |  |  | $ | 4,322 |  |
| Foreign countries | 1,907 |  |  | 1,733 |  |
| Total property, plant, and equipment, net | $ | 6,431 |  |  | $ | 6,055 |  |

[0001571996-21-000007:notes:580]
The allocation between domestic and foreign net revenue is based on the location of the customers.  Net revenue from any single foreign country did not constitute more than 10% of the Company’s consolidated net revenue for any of the fiscal years ended January 29, 2021, January 31, 2020, and February 1, 2019.  Property, plant, and equipment, net from any single foreign country did not constitute more than 10% of the Company’s consolidated property, plant, and equipment, net as of January 29, 2021 or January 31, 2020.


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001571996-21-000007:notes:581]
NOTE 20 — SUPPLEMENTAL CONSOLIDATED FINANCIAL INFORMATION

[0001571996-21-000007:notes:582]
The following table presents additional information on selected asset accounts included in the Consolidated Statements of Financial Position as of the dates indicated:

[0001571996-21-000007:notes:583]
|  | January 29, 2021 |  | January 31, 2020 |
|  | (in millions) |
| Cash, cash equivalents, and restricted cash: |  |  |  |
| Cash and cash equivalents | $ | 14,201 |  |  | $ | 9,302 |  |
| Restricted cash - other current assets (a) | 891 |  |  | 730 |  |
| Restricted cash - other non-current assets (a) | 92 |  |  | 119 |  |
| Total cash, cash equivalents, and restricted cash | $ | 15,184 |  |  | $ | 10,151 |  |
| Inventories, net: |  |  |  |
| Production materials | $ | 1,717 |  |  | $ | 1,590 |  |
| Work-in-process | 677 |  |  | 563 |  |
| Finished goods | 1,008 |  |  | 1,128 |  |
| Total inventories, net | $ | 3,402 |  |  | $ | 3,281 |  |
| Prepaid expenses: |  |  |  |
| Total prepaid expenses (b) | $ | 887 |  |  | $ | 885 |  |
| Property, plant, and equipment, net: |  |  |  |
| Computer equipment | $ | 6,506 |  |  | $ | 6,330 |  |
| Land and buildings | 4,745 |  |  | 4,700 |  |
| Machinery and other equipment | 3,933 |  |  | 3,597 |  |
| Total property, plant, and equipment | 15,184 |  |  | 14,627 |  |
| Accumulated depreciation and amortization (c) | (8,753) |  |  | (8,572) |  |
| Total property, plant, and equipment, net | $ | 6,431 |  |  | $ | 6,055 |  |
| Other non-current assets: |  |  |  |
| Deferred and other tax assets | $ | 6,230 |  |  | $ | 5,960 |  |
| Operating lease ROU assets | 2,117 |  |  | 1,780 |  |
| Deferred Commissions | 1,094 |  |  | 998 |  |
| Other | 1,755 |  |  | 1,690 |  |
| Total other non-current assets | $ | 11,196 |  |  | $ | 10,428 |  |

[0001571996-21-000007:notes:584]
(a)    Restricted cash includes cash required to be held in escrow pursuant to DFS securitization arrangements and VMware, Inc. restricted cash.

[0001571996-21-000007:notes:585]
(b)    Prepaid expenses are included in other current assets in the Consolidated Statements of Financial Position.

[0001571996-21-000007:notes:586]
(c)    During the fiscal years ended January 29, 2021, January 31, 2020, and February 1, 2019, the Company recognized $1.6 billion, $1.3 billion, and $1.3 billion, respectively, in depreciation expense.  Additionally, during the fiscal years ended January 29, 2021, January 31, 2020, and February 1, 2019, the Company retired $1.4 billion, $0.8 billion, and $0.8 billion, respectively, of depreciated property, plant, and equipment.

[0001571996-21-000007:notes:587]
The following table presents additional information on selected liability accounts included in the Consolidated Statements of Financial Position as of the dates indicated:

[0001571996-21-000007:notes:588]
|  | January 29, 2021 |  | January 31, 2020 |
|  | (in millions) |
| Accrued and other current liabilities: |  |  |  |
| Compensation | $ | 3,818 |  |  | $ | 3,717 |  |
| Income and other taxes | 1,621 |  |  | 1,767 |  |
| Sales and marketing programs | 1,526 |  |  | 1,387 |  |
| Operating lease liabilities | 436 |  |  | 432 |  |
| Warranty liability | 356 |  |  | 341 |  |
| Other | 1,792 |  |  | 2,129 |  |
| Total accrued and other current liabilities | $ | 9,549 |  |  | $ | 9,773 |  |
| Other non-current liabilities: |  |  |  |
| Deferred and other tax liabilities | $ | 2,173 |  |  | $ | 3,110 |  |
| Operating lease liabilities | 1,787 |  |  | 1,360 |  |
| Warranty liability | 117 |  |  | 155 |  |
| Other | 1,283 |  |  | 758 |  |
| Total other non-current liabilities | $ | 5,360 |  |  | $ | 5,383 |  |

[0001571996-21-000007:notes:589]
Valuation and Qualifying Accounts

[0001571996-21-000007:notes:590]
The allowance for expected credit losses of trade receivables and the allowance for financing receivables losses as of January 29, 2021 include the impacts of adoption of the new CECL standard, which was adopted as of February 1, 2020 using the modified retrospective method.  The provisions recognized on the Consolidated Statements of Income (Loss) during the fiscal year ended January 29, 2021 are based on assessments of the impact of current and expected future economic conditions, inclusive of the effect of the COVID-19 pandemic on credit losses related to trade receivables and financing receivables.  The duration and severity of COVID-19 and continued market volatility is highly uncertain and, as such, the impacts on expected credit losses for trade receivables and financing receivables are subject to significant judgment and may cause variability in the Company’s allowance for credit losses in future periods for trade receivables and financing receivables.  See Note 2 of the Notes to the Consolidated Financial Statements for additional information about the new CECL standard.

[0001571996-21-000007:notes:591]
The following table presents the Company’s valuation and qualifying accounts for the periods indicated:

[0001571996-21-000007:notes:592]
|  | Fiscal Year Ended |
|  | January 29, 2021 |  | January 31, 2020 |  | February 1, 2019 |
|  | (in millions) |
| Trade Receivables — Allowance for expected credit losses: |  |  |  |  |  |
| Balance at beginning of period | $ | 94 |  |  | $ | 85 |  |  | $ | 103 |  |
| Adjustment for adoption of the new CECL standard (Note 2) | 27 |  |  | — |  |  | — |  |
| Provision charged to income statement | 45 |  |  | 71 |  |  | 77 |  |
| Bad debt write-offs | (62) |  |  | (62) |  |  | (95) |  |
| Balance at end of period | $ | 104 |  |  | $ | 94 |  |  | $ | 85 |  |
| Customer Financing Receivables — Allowance for financing receivable losses: |  |  |  |  |  |
| Balance at beginning of period | $ | 149 |  |  | $ | 136 |  |  | $ | 145 |  |
| Adjustment for adoption of the new CECL standard (Note 2) | 111 |  |  | — |  |  | — |  |
| Charge-offs, net of recoveries (a) | (91) |  |  | (94) |  |  | (104) |  |
| Provision charged to income statement | 152 |  |  | 107 |  |  | 95 |  |
| Balance at end of period | $ | 321 |  |  | $ | 149 |  |  | $ | 136 |  |
| Tax Valuation Allowance: |  |  |  |  |  |
| Balance at beginning of period | $ | 1,687 |  |  | $ | 1,704 |  |  | $ | 777 |  |
| Charged to income tax provision | 80 |  |  | 32 |  |  | 927 |  |
| Charged to other accounts | (58) |  |  | (49) |  |  | — |  |
| Balance at end of period | $ | 1,709 |  |  | $ | 1,687 |  |  | $ | 1,704 |  |

[0001571996-21-000007:notes:593]
(a)    Charge-offs for customer financing receivables includes principal and interest.

[0001571996-21-000007:notes:594]
Warranty Liability

[0001571996-21-000007:notes:595]
The following table presents changes in the Company’s liability for standard limited warranties for the periods indicated:

[0001571996-21-000007:notes:596]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  | January 29, 2021 |  | January 31, 2020 |  | February 1, 2019 |
|  |  |  |  |  | (in millions) |
| Warranty liability: |  |  |  |  |  |  |  |  |  |
| Warranty liability at beginning of period |  |  |  |  | $ | 496 |  |  | $ | 524 |  |  | $ | 539 |  |
| Costs accrued for new warranty contracts and changes in estimates for pre-existing warranties (a) (b) |  |  |  |  | 782 |  |  | 853 |  |  | 856 |  |
| Service obligations honored |  |  |  |  | (805) |  |  | (882) |  |  | (871) |  |
| Warranty liability at end of period |  |  |  |  | $ | 473 |  |  | $ | 496 |  |  | $ | 524 |  |
| Current portion |  |  |  |  | $ | 356 |  |  | $ | 341 |  |  | $ | 355 |  |
| Non-current portion |  |  |  |  | $ | 117 |  |  | $ | 155 |  |  | $ | 169 |  |

[0001571996-21-000007:notes:597]
(a)Changes in cost estimates related to pre-existing warranties are aggregated with accruals for new standard warranty contracts.  The Company’s warranty liability process does not differentiate between estimates made for pre-existing warranties and new warranty obligations.

[0001571996-21-000007:notes:598]
(b)Includes the impact of foreign currency exchange rate fluctuations.

[0001571996-21-000007:notes:599]
Severance Charges

[0001571996-21-000007:notes:600]
The Company incurs costs related to employee severance and records a liability for these costs when it is probable that employees will be entitled to termination benefits and the amounts can be reasonably estimated.  The liability related to these actions is included in accrued and other current liabilities in the Consolidated Statements of Financial Position.

[0001571996-21-000007:notes:601]
The following table presents the activity related to the Company’s severance liability for the periods indicated:

[0001571996-21-000007:notes:602]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  | January 29, 2021 |  | January 31, 2020 |  | February 1, 2019 |
|  |  |  |  |  | (in millions) |
| Severance liability: |  |  |  |  |  |  |  |  |  |
| Severance liability at beginning of period |  |  |  |  | $ | 196 |  |  | $ | 146 |  |  | $ | 175 |  |
| Severance charges to provision |  |  |  |  | 452 |  |  | 266 |  |  | 215 |  |
| Cash paid and other (a) |  |  |  |  | (510) |  |  | (216) |  |  | (244) |  |
| Severance liability at end of period |  |  |  |  | $ | 138 |  |  | $ | 196 |  |  | $ | 146 |  |

[0001571996-21-000007:notes:603]
(a)    Other adjustments include the impact of foreign currency exchange rate fluctuations.

[0001571996-21-000007:notes:604]
The following table presents severance charges as included in the Consolidated Statements of Income (Loss) for the periods indicated:

[0001571996-21-000007:notes:605]
|  | Fiscal Year Ended |
|  | January 29, 2021 |  | January 31, 2020 |  | February 1, 2019 |
|  | (in millions) |
| Severance charges: |  |  |  |  |  |
| Cost of net revenue | $ | 68 |  |  | $ | 37 |  |  | $ | 17 |  |
| Selling, general, and administrative | 313 |  |  | 177 |  |  | 146 |  |
| Research and development | 71 |  |  | 52 |  |  | 52 |  |
| Total severance charges | $ | 452 |  |  | $ | 266 |  |  | $ | 215 |  |

[0001571996-21-000007:notes:606]
Interest and other, net

[0001571996-21-000007:notes:607]
The following table presents information regarding interest and other, net for the periods indicated:

[0001571996-21-000007:notes:608]
|  | Fiscal Year Ended |
|  | January 29, 2021 |  | January 31, 2020 |  | February 1, 2019 |
|  | (in millions) |
| Interest and other, net: |  |  |  |  |  |
| Investment income, primarily interest | $ | 54 |  |  | $ | 160 |  |  | $ | 313 |  |
| Gain on strategic investments, net (a) | 582 |  |  | 194 |  |  | 342 |  |
| Interest expense | (2,389) |  |  | (2,675) |  |  | (2,488) |  |
| Foreign exchange | (127) |  |  | (162) |  |  | (206) |  |
| Other (b) | 406 |  |  | (143) |  |  | (131) |  |
| Total interest and other, net | $ | (1,474) |  |  | $ | (2,626) |  |  | $ | (2,170) |  |

[0001571996-21-000007:notes:609]
(a)    Gain on strategic investments, net includes a $396 million net gain on the fair value adjustment of one of the Company’s strategic investments during the fiscal year ended January 29, 2021.

[0001571996-21-000007:notes:610]
(b)  Other includes a pre-tax gain of $338 million on the sale of RSA Security and a gain of $120 million recognized from the sale of certain intellectual property assets during the fiscal year ended January 29, 2021.


## us-gaap:CondensedFinancialInformationOfParentCompanyOnlyDisclosureTextBlock

[0001571996-21-000007:notes:611]
NOTE 21 — CONDENSED FINANCIAL INFORMATION OF PARENT COMPANY

[0001571996-21-000007:notes:612]
Dell Technologies Inc. has no material assets or standalone operations other than its ownership in its consolidated subsidiaries.  There are restrictions under credit agreements and indentures governing the First Lien Notes and the Senior Notes, described in Note 6 of the Notes to the Consolidated Financial Statements, on the Company’s ability to obtain funds from any of its subsidiaries through dividends, loans, or advances.  As of January 29, 2021, the Company had certain consolidated subsidiaries that were designated as unrestricted subsidiaries for all purposes of the applicable credit agreements and such indentures.  As of January 29, 2021, substantially all of the net assets of the Company’s consolidated subsidiaries were restricted, with the exception of the Company’s unrestricted subsidiaries, primarily VMware, Inc., Secureworks, and their respective subsidiaries.  Accordingly, this condensed financial information is presented on a “Parent-only” basis.  Under a Parent-only presentation, Dell Technologies Inc.’s investments in its consolidated subsidiaries are presented under the equity method of accounting.

[0001571996-21-000007:notes:613]
The following table presents the financial position of Dell Technologies Inc. (Parent) as of the dates indicated:

[0001571996-21-000007:notes:614]
|  | January 29, 2021 |  | January 31, 2020 |
|  | (in millions) |
| Assets: |  |  |  |
| Cash and cash equivalents | $ | 1 |  |  | $ | — |  |
| Investments in subsidiaries | 2,950 |  |  | — |  |
| Total assets | $ | 2,951 |  |  | $ | — |  |
| Liabilities: |  |  |  |
| Short-term debt | $ | — |  |  | $ | — |  |
| Guarantees of subsidiary obligations (a) | — |  |  | 945 |  |
| Total liabilities | — |  |  | 945 |  |
| Redeemable shares | 472 |  |  | 629 |  |
| Stockholders’ equity (deficit): |  |  |  |
| Common stock and capital in excess of $0.01 par value | 16,849 |  |  | 16,091 |  |
| Treasury stock at cost | (305) |  |  | (65) |  |
| Accumulated deficit | (13,751) |  |  | (16,891) |  |
| Accumulated other comprehensive income (loss) | (314) |  |  | (709) |  |
| Total stockholders’ equity (deficit) | 2,479 |  |  | (1,574) |  |
| Total liabilities, redeemable shares, and stockholders’ equity (deficit) | $ | 2,951 |  |  | $ | — |  |

[0001571996-21-000007:notes:615]
(a)    Guarantees of subsidiary obligations represents the capital Dell Technologies Inc. received in excess of the carrying amount of its investments in subsidiaries.

[0001571996-21-000007:notes:616]
The following table presents the cash flows of Dell Technologies Inc. (Parent) for the periods indicated:

[0001571996-21-000007:notes:617]
|  | Fiscal Year Ended |
|  | January 29, 2021 |  | January 31, 2020 |  | February 1, 2019 |
|  | (in millions) |
| Change in cash from operating activities | $ | (16) |  |  | $ | (21) |  |  | $ | (274) |  |
| Cash flows from investing activities: |  |  |  |  |  |
| Transfer (to)/from subsidiary | 79 |  |  | (308) |  |  | 14,360 |  |
| Change in cash from investing activities | 79 |  |  | (308) |  |  | 14,360 |  |
| Cash flows from financing activities: |  |  |  |  |  |
| Proceeds from the issuance of common stock | 179 |  |  | 350 |  |  | 2 |  |
| Repurchases of parent common stock | (241) |  |  | (8) |  |  | (14,075) |  |
| Repayments of debt | — |  |  | (13) |  |  | (13) |  |
| Change in cash from financing activities | (62) |  |  | 329 |  |  | (14,086) |  |
| Change in cash, cash equivalents, and restricted cash | 1 |  |  | — |  |  | — |  |
| Cash, cash equivalents, and restricted cash at beginning of the period | — |  |  | — |  |  | — |  |
| Cash, cash equivalents, and restricted cash at end of the period | $ | 1 |  |  | $ | — |  |  | $ | — |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001571996-21-000007:notes:618]
NOTE 22 — RELATED PARTY TRANSACTIONS

[0001571996-21-000007:notes:619]
Dell Technologies is a large global organization that engages in millions of purchase, sales, and other transactions during the fiscal year.  The Company enters into purchase and sales transactions with other publicly-traded and privately-held companies, as well as not-for-profit organizations, that could be influenced by members of the Company’s board of directors or the Company’s executive officers.  The Company enters into these arrangements in the ordinary course of its business.  Transactions with related parties were immaterial for the fiscal years ended January 29, 2021, January 31, 2020, and February 1, 2019.


## us-gaap:SubsequentEventsTextBlock

[0001571996-21-000007:notes:620]
NOTE 23 — SUBSEQUENT EVENTS

[0001571996-21-000007:notes:621]
Debt Repayments — Subsequent to January 29, 2021, the Company repaid $400 million principal amount of the 4.625% Unsecured Notes due April 2021 and $600 million principal amount of the 5.875% Senior Notes due June 2021.

[0001571996-21-000007:notes:622]
Senior Secured Credit Facilities — On February 18, 2021, the Company entered into an eighth refinancing amendment to the credit agreement for the Senior Secured Credit Facilities to refinance the existing term B loans (the “Original Term B Loans”) with a new term loan B facility consisting of an aggregate principal amount of $3,143 million refinancing term B-2 loans (the “Refinancing Term B-2 Loans”) maturing on September 19, 2025.  Proceeds from the Refinancing Term B-2 Loans, together with other funds available to the borrowers, were used to repay in full the Original Term B Loans and all accrued and unpaid fees in respect thereof.

[0001571996-21-000007:notes:623]
Except for a change in the interest rate, the Refinancing Term B-2 Loans have substantially the same terms as the Original Term B Loans under the sixth refinancing amendment to the Senior Secured Credit Agreement.  Amortization payments on the Refinancing Term B-2 Loans are equal to 0.25% of the aggregate principal amount of Refinancing Term B-2 Loans outstanding on the effective date of the eighth refinancing amendment, payable at the end of each fiscal quarter, commencing with the fiscal quarter ending April 30, 2021.  The Refinancing Term B-2 Loans will bear interest at LIBOR plus an applicable margin of 1.75% or a base rate plus an applicable margin of 0.75%.

[0001571996-21-000007:notes:624]
See Note 6 of the Notes to the Consolidated Financial Statements for more information about the Company’s Senior Secured Credit Facilities.
