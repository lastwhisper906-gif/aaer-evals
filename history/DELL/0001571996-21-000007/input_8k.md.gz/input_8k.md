# DELL 8-K — 0001571996-21-000003 filed 2021-02-25

## item codes, every 8-K on or before 2021-03-26

- 2021-02-25 0001571996-21-000003 — 2.02, 9.01
- 2021-02-18 0001193125-21-047844 — 1.01, 2.03, 9.01
- 2020-11-24 0001571996-20-000048 — 2.02, 9.01
- 2020-08-27 0001571996-20-000041 — 2.02, 9.01
- 2020-07-02 0001571996-20-000037 — 5.07
- 2020-05-28 0001571996-20-000028 — 2.02, 9.01
- 2020-04-09 0001193125-20-102602 — 1.01, 2.03, 9.01
- 2020-04-08 0001571996-20-000021 — 5.02
- 2020-04-03 0001571996-20-000019 — 8.01, 9.01
- 2020-03-26 0001571996-20-000015 — 7.01
- 2020-02-27 0001571996-20-000009 — 2.02, 8.01, 9.01
- 2020-02-18 0001571996-20-000005 — 8.01, 9.01
- 2020-01-09 0001571996-20-000002 — 3.02
- 2020-01-06 0001193125-20-002200 — 3.02
- 2019-12-13 0001193125-19-313947 — 3.02
- 2019-12-10 0001571996-19-000052 — 5.02
- 2019-12-02 0001571996-19-000044 — 5.02, 7.01, 9.01
- 2019-11-26 0001571996-19-000042 — 2.02, 9.01
- 2019-09-23 0001193125-19-252192 — 1.01, 2.03, 9.01
- 2019-08-29 0001571996-19-000036 — 2.02, 9.01
- 2019-08-22 0001193125-19-226939 — 7.01, 8.01, 9.01
- 2019-07-11 0001571996-19-000032 — 5.02, 5.07, 9.01
- 2019-07-03 0001571996-19-000030 — 3.02
- 2019-06-27 0001571996-19-000028 — 3.02
- 2019-05-30 0001571996-19-000021 — 2.02, 9.01
- 2019-04-02 0001571996-19-000010 — 5.02
- 2019-03-21 0001193125-19-082281 — 1.01, 1.02, 2.03, 9.01
- 2019-03-19 0001571996-19-000005 — 5.02, 9.01
- 2019-03-14 0001193125-19-074935 — 1.01, 2.03, 9.01
- 2019-03-07 0001193125-19-066045 — 8.01, 9.01
- 2019-02-28 0001571996-19-000002 — 2.02, 9.01
- 2018-12-28 0001193125-18-360943 — 1.01, 1.02, 3.01, 3.03, 5.02, 5.03, 7.01, 8.01, 9.01
- 2018-12-21 0001193125-18-356324 — 1.01, 2.03, 9.01
- 2018-12-14 0001193125-18-349469 — 8.01
- 2018-12-11 0001193125-18-346958 — 5.07, 8.01, 9.01
- 2018-11-29 0001571996-18-000041 — 2.02, 9.01
- 2018-11-28 0001571996-18-000037 — 7.01, 8.01, 9.01
- 2018-11-26 0001193125-18-333967 — 8.01, 9.01
- 2018-11-15 0001193125-18-328110 — 1.01, 9.01 — amendment of 0001193125-18-327222
- 2018-11-15 0001193125-18-327222 — 1.01, 7.01, 9.01
- 2018-10-03 0001193125-18-291390 — 8.01
- 2018-09-06 0001571996-18-000029 — 2.02, 9.01
- 2018-08-06 0001571996-18-000027 — 8.01, 9.01
- 2018-07-02 0001193125-18-210339 — 1.01, 7.01, 9.01
- 2018-06-28 0001571996-18-000024 — 5.07
- 2018-06-04 0001571996-18-000019 — 2.02, 9.01
- 2018-05-17 0001571996-18-000016 — 7.01
- 2018-04-26 0001571996-18-000009 — 7.01, 9.01
- 2018-03-08 0001193125-18-074168 — 2.02, 9.01
- 2018-02-02 0001193125-18-029947 — 7.01, 9.01
- 2017-12-07 0001571996-17-000042 — 2.02, 9.01
- 2017-10-24 0001571996-17-000037 — 1.01, 2.03, 9.01
- 2017-09-15 0001571996-17-000027 — 5.02
- 2017-09-07 0001571996-17-000017 — 2.02, 9.01
- 2017-08-24 0001571996-17-000014 — 8.01
- 2017-06-29 0001571996-17-000011 — 3.03, 5.07, 8.01, 9.01
- 2017-06-08 0001193125-17-197638 — 2.02, 9.01
- 2017-03-30 0001193125-17-102794 — 8.01
- 2017-03-30 0001193125-17-102777 — 2.02, 9.01
- 2017-03-09 0001193125-17-076981 — 1.01, 2.03, 9.01
- 2017-01-17 0001193125-17-011125 — 8.01
- 2016-12-15 0001193125-16-793722 — 8.01
- 2016-12-08 0001193125-16-787976 — 2.02, 9.01
- 2016-11-10 0001193125-16-765964 — 1.02, 8.01
- 2016-11-04 0001193125-16-760249 — 8.01
- 2016-09-13 0001193125-16-708600 — 3.02
- 2016-09-09 0001193125-16-706567 — 1.01, 1.02, 2.01, 2.03, 3.02, 3.03, 5.02, 9.01
- 2016-09-07 0001193125-16-703370 — 3.03, 5.07, 7.01, 8.01, 9.01
- 2016-09-06 0001193125-16-702057 — 2.02, 9.01
- 2016-08-31 0001193125-16-697268 — 8.01, 9.01
- 2016-08-26 0001193125-16-692921 — 8.01, 9.01
- 2016-07-11 0001193125-16-645610 — 8.01
- 2016-07-05 0001193125-16-641679 — 8.01
- 2016-06-22 0001193125-16-629055 — 1.01, 2.03, 8.01, 9.01
- 2016-06-21 0001193125-16-627071 — 8.01, 9.01
- 2016-06-10 0001193125-16-618483 — 2.02, 9.01
- 2016-06-09 0001193125-16-617893 — 8.01, 9.01

## late-filing notifications on or before 2021-03-26

- none on or before 2021-03-26

## item 2.02 — earnings release, exhibit 99.1

[0001571996-21-000003:8k_2_02:1]
EX-99.1
2
exhibit991earnings8kq4fy21.htm
EX-99.1

[0001571996-21-000003:8k_2_02:2]
Document

[0001571996-21-000003:8k_2_02:3]
Exhibit 99.1

[0001571996-21-000003:8k_2_02:4]
News Release

[0001571996-21-000003:8k_2_02:5]
Future of Work Solutions Fuel Dell Technologies’

[0001571996-21-000003:8k_2_02:6]
Record Fiscal Year 2021 Financial Results

[0001571996-21-000003:8k_2_02:7]
ROUND ROCK, Texas — February 25, 2021

[0001571996-21-000003:8k_2_02:8]
News summary

[0001571996-21-000003:8k_2_02:9]
•Record full-year revenue of $94.2 billion

[0001571996-21-000003:8k_2_02:10]
•Record full-year operating income of $5.1 billion and record non-GAAP operating income of $10.8 billion

[0001571996-21-000003:8k_2_02:11]
•Record cash flow from operations of $11.4 billion

[0001571996-21-000003:8k_2_02:12]
•Record Client Solutions Group shipments, revenue and operating income

[0001571996-21-000003:8k_2_02:13]
Full story

[0001571996-21-000003:8k_2_02:14]
Dell Technologies (NYSE: DELL) announces financial results for its fiscal 2021 fourth quarter and full year.

[0001571996-21-000003:8k_2_02:15]
Full-year revenue was a record $94.2 billion, up 2% over the prior year. The company generated record operating income of $5.1 billion, a 96% increase over the prior year, and record non-GAAP operating income of $10.8 billion, up 6%. For the full year, net income was $3.5 billion and non-GAAP net income was $6.8 billion. Cash flow from operations was a record $11.4 billion. Full-year diluted earnings per share was $4.22, and non-GAAP diluted earnings per share was $8.00.

[0001571996-21-000003:8k_2_02:16]
Fourth quarter revenue was up 9% to $26.1 billion. The company generated operating income of $2.2 billion, a 204% increase over the same period in the prior year, and non-GAAP operating income of $3.3 billion, up 19%. Net income was $1.3 billion, non-GAAP net income was $2.3 billion and adjusted EBITDA was $3.8 billion. Cash flow from operations was $5.9 billion. Fourth quarter diluted earnings per share was $1.57 and non-GAAP diluted earnings per share was $2.70.

[0001571996-21-000003:8k_2_02:17]
“In the past year, our team rallied to support our customers and partners worldwide as technology played a central role in keeping our society, economy and lives moving forward,” said Jeff Clarke, chief operating officer, Dell Technologies. “We generated record revenue of $94.2 billion this year by helping customers adapt to new work-and-learn-from-anywhere realities and are in an advantaged position to capitalize on the projected mid-single digits growth in IT spending in 2021.”

[0001571996-21-000003:8k_2_02:18]
1

[0001571996-21-000003:8k_2_02:19]
Fourth Quarter and Full-Year Fiscal 2021 Financial Results

[0001571996-21-000003:8k_2_02:20]
|  | Three Months Ended |  |  |  | Fiscal Year Ended |  |  |
|  | January 29, 2021 |  | January 31, 2020 |  | Change |  | January 29, 2021 |  | January 31, 2020 |  | Change |
|  | (in millions, except per share amounts and percentages; unaudited) |
| Total net revenue | $ | 26,112 |  |  | $ | 24,032 |  |  | 9% |  | $ | 94,224 |  |  | $ | 92,154 |  |  | 2% |
| Operating income | $ | 2,177 |  |  | $ | 717 |  |  | 204% |  | $ | 5,144 |  |  | $ | 2,622 |  |  | 96% |
| Net income | $ | 1,343 |  |  | $ | 416 |  |  | 223% |  | $ | 3,505 |  |  | $ | 5,529 |  |  | (37)% |
| Earnings per share - diluted | $ | 1.57 |  |  | $ | 0.54 |  |  | 191% |  | $ | 4.22 |  |  | $ | 6.03 |  |  | (30)% |
| Non-GAAP net revenue | $ | 26,148 |  |  | $ | 24,129 |  |  | 8% |  | $ | 94,389 |  |  | $ | 92,501 |  |  | 2% |
| Non-GAAP operating income | $ | 3,294 |  |  | $ | 2,767 |  |  | 19% |  | $ | 10,798 |  |  | $ | 10,148 |  |  | 6% |
| Non-GAAP net income | $ | 2,288 |  |  | $ | 1,684 |  |  | 36% |  | $ | 6,763 |  |  | $ | 6,089 |  |  | 11% |
| Adjusted EBITDA | $ | 3,809 |  |  | $ | 3,201 |  |  | 19% |  | $ | 12,747 |  |  | $ | 11,787 |  |  | 8% |
| Non-GAAP earnings per share - diluted | $ | 2.70 |  |  | $ | 2.00 |  |  | 35% |  | $ | 8.00 |  |  | $ | 7.35 |  |  | 9% |

[0001571996-21-000003:8k_2_02:21]
Information about Dell Technologies’ use of non-GAAP financial information is provided under “Non-GAAP Financial Measures” below.  All comparisons in this press release are year-over-year unless otherwise noted.

[0001571996-21-000003:8k_2_02:22]
Dell Technologies ended the fiscal year with cash and investments of $15.8 billion and delivered on its fiscal 2021 core debt paydown target of $5.5 billion. The company ended the year with total deferred revenue of $30.8 billion, up $3 billion year-over-year. Recurring revenue, which includes deferred revenue amortization, utility and as-a-Service models was approximately $6 billion for the quarter, up 8% year-over-year, as the company’s aaS models give customers greater flexibility to scale IT to meet business needs and budgets.

[0001571996-21-000003:8k_2_02:23]
“This year’s strong results are a testament to the flexibility of Dell Technologies’ business model and the resilience of our team,” said Tom Sweet, chief financial officer, Dell Technologies. “Focus on our people, customers, innovation and execution resulted in record cash flow from operations of $11.4 billion, and we’ll continue to deliver differentiated value for our all stakeholders.”

[0001571996-21-000003:8k_2_02:24]
Operating segments summary

[0001571996-21-000003:8k_2_02:25]
Client Solutions Group delivered record results, with revenue for the fourth quarter of $13.8 billion, up 17% year over year. This was driven by $9.9 billion in commercial revenue – a 16% increase – and $3.8 billion in consumer revenue – a 19% increase. Operating income was $1.0 billion or approximately 7.6% of Client Solutions Group revenue. For the full year, the Client Solutions Group delivered record revenue of $48.4 billion, up 5% versus the prior year. Client Solutions Group full-year operating income was $3.4 billion, a 7% increase.

[0001571996-21-000003:8k_2_02:26]
Key highlights:

[0001571996-21-000003:8k_2_02:27]
•Shipped a record 50.3 million units during the 2020 calendar year1, an 8% increase year-over-year

[0001571996-21-000003:8k_2_02:28]
•Only big 3 vendor to gain Commercial PC share in calendar year 20201

[0001571996-21-000003:8k_2_02:29]
•Continued to see strong growth in Latitude and Precision notebooks and Commercial Chromebooks

[0001571996-21-000003:8k_2_02:30]
2

[0001571996-21-000003:8k_2_02:31]
Infrastructure Solutions Group revenue for the fourth quarter was $8.8 billion, flat year-over-year. Storage revenue was $4.4 billion – down 2% – while servers and networking revenue was $4.4 billion – up 3%. Operating income was a record $1.2 billion or approximately 13.5% of Infrastructure Solutions Group revenue. For the full year, revenue was $32.6 billion, with operating income of $3.8 billion.

[0001571996-21-000003:8k_2_02:32]
Key highlights:

[0001571996-21-000003:8k_2_02:33]
•PowerStore orders up 4X quarter-over-quarter, as customers embrace the next generation of modern data center technology and applications

[0001571996-21-000003:8k_2_02:34]
•Strong year-over-year growth in PowerMax, HCI and PowerProtect Data Domain

[0001571996-21-000003:8k_2_02:35]
•Launch of new HCI, cloud, storage and data protection integration with latest VMware releases to help customers innovate across edge locations, data centers and hybrid clouds

[0001571996-21-000003:8k_2_02:36]
VMware revenue for the fourth quarter was $3.3 billion, with operating income of $1.1 billion driven by broad-based strength across a diverse product portfolio. For the full year, VMware delivered $11.9 billion in revenue and $3.6 billion in operating income.

[0001571996-21-000003:8k_2_02:37]
Dell Technologies World

[0001571996-21-000003:8k_2_02:38]
Join us May 5 – May 6 for the Dell Technologies World Experience, the company’s flagship event that brings together latest emerging trends, technology and gurus. During the event, we will demonstrate to customers and partners the connected ecosystem of IT infrastructure, applications, devices and security – and our new APEX as-a-Service portfolio and simplified IT consumption experience that gives customers greater flexibility to scale IT to meet business needs and budgets. Register here.

[0001571996-21-000003:8k_2_02:39]
Conference call information

[0001571996-21-000003:8k_2_02:40]
As previously announced, the Company will hold a conference call to discuss its fiscal 2021 fourth quarter/full year performance and financial guidance, February 25, 2021 at 4:30 p.m. CST. The conference call will be broadcast live over the internet and can be accessed at https://investors.delltechnologies.com/events-and-presentations/upcoming-events

[0001571996-21-000003:8k_2_02:41]
For those unable to listen to the live broadcast, an archived version will be available at the same location for one year.

[0001571996-21-000003:8k_2_02:42]
Additional financial and operating information may be downloaded from

[0001571996-21-000003:8k_2_02:43]
https://investors.delltechnologies.com/financial-information/quarterly-results

[0001571996-21-000003:8k_2_02:44]
About Dell Technologies

[0001571996-21-000003:8k_2_02:45]
Dell Technologies (NYSE:DELL) helps organizations and individuals build their digital future and transform how they work, live and play.  The company provides customers with the industry’s broadest and most innovative technology and services portfolio for the data era.

[0001571996-21-000003:8k_2_02:46]
Contacts

[0001571996-21-000003:8k_2_02:47]
Investors: Investor_Relations@Dell.com

[0001571996-21-000003:8k_2_02:48]
Media: Media.Relations@Dell.com

[0001571996-21-000003:8k_2_02:49]
# # #

[0001571996-21-000003:8k_2_02:50]
Copyright © 2021 Dell Inc. or its subsidiaries. All Rights Reserved. Dell Technologies, Dell, EMC and Dell EMC are trademarks of Dell Inc. or its subsidiaries. Other trademarks may be trademarks of their respective owners.

[0001571996-21-000003:8k_2_02:51]
1    IDC WW Personal Computing Device Tracker CY20Q4, WW commercial PC, on a Y/Y basis

[0001571996-21-000003:8k_2_02:52]
3

[0001571996-21-000003:8k_2_02:53]
Non-GAAP Financial Measures:

[0001571996-21-000003:8k_2_02:54]
This press release presents information about Dell Technologies’ non-GAAP net revenue, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, non-GAAP net income attributable to non-controlling interests, non-GAAP net income attributable to Dell Technologies Inc. - basic, non-GAAP net income attributable to Dell Technologies Inc. - diluted, non-GAAP earnings per share attributable to Dell Technologies Inc. - basic, non-GAAP earnings per share attributable to Dell Technologies Inc. - diluted, EBITDA, and adjusted EBITDA, which are non-GAAP financial measures provided as a supplement to the results provided in accordance with generally accepted accounting principles in the United States of America (“GAAP”). A reconciliation of each non-GAAP financial measure to the most directly comparable GAAP financial measure is provided in the attached tables for each of the fiscal periods indicated.

[0001571996-21-000003:8k_2_02:55]
Special Note on Forward-Looking Statements:

[0001571996-21-000003:8k_2_02:56]
Dell Technologies’ results or events in future periods could differ materially from those expressed or implied by these forward-looking statements because of risks, uncertainties, and other factors that include, but are not limited to, the following: competitive pressures; Dell Technologies’ reliance on third-party suppliers for products and components, including reliance on single-source or limited-source suppliers; Dell Technologies’ ability to achieve favorable pricing from its vendors; adverse global economic conditions and instability in financial markets, including as a result of the COVID-19 pandemic; Dell Technologies’ execution of its growth, business and acquisition strategies; the success of Dell Technologies’ cost efficiency measures; Dell Technologies’ ability to manage solutions and products and services transitions in an effective manner; Dell Technologies’ ability to deliver high-quality products and services; Dell Technologies’ foreign operations and ability to generate substantial non-U.S. net revenue; Dell Technologies’ product, customer, and geographic sales mix, and seasonal sales trends; the performance of Dell Technologies’ sales channel partners; access to the capital markets by Dell Technologies or its customers; weak economic conditions and additional regulation including tariffs and other effects of trade regulation; counterparty default risks; the loss by Dell Technologies of any services contracts with its customers, including government contracts, and its ability to perform such contracts at its estimated costs; Dell Technologies’ ability to develop and protect its proprietary intellectual property or obtain licenses to intellectual property developed by others on commercially reasonable and competitive terms; infrastructure disruptions, cyberattacks, or other data security breaches; Dell Technologies’ ability to hedge effectively its exposure to fluctuations in foreign currency exchange rates and interest rates; expiration of tax holidays or favorable tax rate structures, or unfavorable outcomes in tax audits and other tax compliance matters; impairment of portfolio investments; unfavorable results of legal proceedings; increased costs and additional regulations and requirements as a result of Dell Technologies’ operation as a public company; Dell Technologies’ ability to develop and maintain effective internal control over financial reporting; compliance requirements of changing environmental and safety laws; the effect of armed hostilities, terrorism, natural disasters, and public health issues, including as a result of the COVID-19 pandemic; Dell Technologies’ substantial level of indebtedness; the impact of the financial performance of VMware, Inc.; and the market volatility of Dell Technologies’ pension plan assets.

[0001571996-21-000003:8k_2_02:57]
This list of risks, uncertainties, and other factors is not complete. Dell Technologies discusses some of these matters more fully, as well as certain risk factors that could affect Dell Technologies’ business, financial condition, results of operations, and prospects, in its reports filed with the SEC, including Dell Technologies’ annual report on Form 10-K for the fiscal year ended January 31, 2020, quarterly reports on Form 10-Q, and current reports on Form 8-K. These filings are available for review through the SEC’s website at www.sec.gov. Any or all forward-looking statements Dell Technologies makes may turn out to be wrong and can be affected by inaccurate assumptions Dell Technologies might make or by known or unknown risks, uncertainties and other factors, including those identified in this press release. Accordingly, you should not place undue reliance on the forward-looking statements made in this press release, which speak only as of its date. Dell Technologies does not undertake to update, and expressly disclaims any duty to update, its forward-looking statements, whether as a result of circumstances or events that arise after the date they are made, new information, or otherwise.

[0001571996-21-000003:8k_2_02:58]
4

[0001571996-21-000003:8k_2_02:59]
DELL TECHNOLOGIES INC.

[0001571996-21-000003:8k_2_02:60]
Condensed Consolidated Statements of Income (Loss) and Related Financial Highlights

[0001571996-21-000003:8k_2_02:61]
(in millions, except percentages; unaudited)

[0001571996-21-000003:8k_2_02:62]
|  | Three Months Ended |  |  |  | Fiscal Year Ended |  |  |
|  | January 29, 2021 |  | January 31, 2020 |  | Change |  | January 29, 2021 |  | January 31, 2020 |  | Change |
| Net revenue (a): |  |  |  |  |  |  |  |  |  |  |  |
| Products | $ | 19,784 |  |  | $ | 18,153 |  |  | 9% |  | $ | 69,911 |  |  | $ | 69,918 |  |  | —% |
| Services | 6,328 |  |  | 5,879 |  |  | 8% |  | 24,313 |  |  | 22,236 |  |  | 9% |
| Total net revenue | 26,112 |  |  | 24,032 |  |  | 9% |  | 94,224 |  |  | 92,154 |  |  | 2% |
| Cost of net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Products | 15,424 |  |  | 13,999 |  |  | 10% |  | 55,347 |  |  | 54,525 |  |  | 2% |
| Services | 2,541 |  |  | 2,349 |  |  | 8% |  | 9,460 |  |  | 8,696 |  |  | 9% |
| Total cost of net revenue | 17,965 |  |  | 16,348 |  |  | 10% |  | 64,807 |  |  | 63,221 |  |  | 3% |
| Gross margin | 8,147 |  |  | 7,684 |  |  | 6% |  | 29,417 |  |  | 28,933 |  |  | 2% |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative | 4,579 |  |  | 5,642 |  |  | (19)% |  | 18,998 |  |  | 21,319 |  |  | (11)% |
| Research and development | 1,391 |  |  | 1,325 |  |  | 5% |  | 5,275 |  |  | 4,992 |  |  | 6% |
| Total operating expenses | 5,970 |  |  | 6,967 |  |  | (14)% |  | 24,273 |  |  | 26,311 |  |  | (8)% |
| Operating income | 2,177 |  |  | 717 |  |  | 204% |  | 5,144 |  |  | 2,622 |  |  | 96% |
| Interest and other, net | (545) |  |  | (626) |  |  | 13% |  | (1,474) |  |  | (2,626) |  |  | 44% |
| Income (loss) before income taxes | 1,632 |  |  | 91 |  |  | NM |  | 3,670 |  |  | (4) |  |  | NM |
| Income tax provision (benefit) | 289 |  |  | (325) |  |  | 189% |  | 165 |  |  | (5,533) |  |  | 103% |
| Net income | 1,343 |  |  | 416 |  |  | 223% |  | 3,505 |  |  | 5,529 |  |  | (37)% |
| Less: Net income attributable to non-controlling interests | 116 |  |  | 8 |  |  | NM |  | 255 |  |  | 913 |  |  | (72)% |
| Net income attributable to Dell Technologies Inc. | $ | 1,227 |  |  | $ | 408 |  |  | 201% |  | $ | 3,250 |  |  | $ | 4,616 |  |  | (30)% |
| Percentage of Total Net Revenue: |  |  |  |  |  |  |  |  |  |  |
| Gross margin | 31 | % |  | 32 | % |  |  |  | 31 | % |  | 31 | % |  |  |
| Selling, general, and administrative | 18 | % |  | 23 | % |  |  |  | 20 | % |  | 23 | % |  |  |
| Research and development | 5 | % |  | 6 | % |  |  |  | 6 | % |  | 5 | % |  |  |
| Operating expenses | 23 | % |  | 29 | % |  |  |  | 26 | % |  | 29 | % |  |  |
| Operating income | 8 | % |  | 3 | % |  |  |  | 5 | % |  | 3 | % |  |  |
| Income (loss) before income taxes | 6 | % |  | — | % |  |  |  | 4 | % |  | — | % |  |  |
| Net income | 5 | % |  | 2 | % |  |  |  | 4 | % |  | 6 | % |  |  |
| Income tax rate | 17.7 | % |  | -357.1 | % |  |  |  | 4.5 | % |  | 138325.0 | % |  |  |

[0001571996-21-000003:8k_2_02:63]
____________________

[0001571996-21-000003:8k_2_02:64]
(a)    During Fiscal 2020, the Company reclassified revenue associated with certain service and software-as-a-service offerings from product revenue to services revenue. There was no change to total revenue as a result of the reclassifications.

[0001571996-21-000003:8k_2_02:65]
5

[0001571996-21-000003:8k_2_02:66]
DELL TECHNOLOGIES INC.

[0001571996-21-000003:8k_2_02:67]
Consolidated Statements of Financial Position

[0001571996-21-000003:8k_2_02:68]
(in millions; unaudited)

[0001571996-21-000003:8k_2_02:69]
|  | January 29, 2021 |  | January 31, 2020 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 14,201 |  |  | $ | 9,302 |  |
| Accounts receivable, net | 12,788 |  |  | 12,484 |  |
| Short-term financing receivables, net | 5,155 |  |  | 4,895 |  |
| Inventories, net | 3,402 |  |  | 3,281 |  |
| Other current assets | 8,021 |  |  | 6,906 |  |
| Total current assets | 43,567 |  |  | 36,868 |  |
| Property, plant, and equipment, net | 6,431 |  |  | 6,055 |  |
| Long-term investments | 1,624 |  |  | 864 |  |
| Long-term financing receivables, net | 5,339 |  |  | 4,848 |  |
| Goodwill | 40,829 |  |  | 41,691 |  |
| Intangible assets, net | 14,429 |  |  | 18,107 |  |
| Other non-current assets | 11,196 |  |  | 10,428 |  |
| Total assets | $ | 123,415 |  |  | $ | 118,861 |  |
| LIABILITIES, REDEEMABLE SHARES, AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Short-term debt | $ | 6,362 |  |  | $ | 7,737 |  |
| Accounts payable | 21,696 |  |  | 20,065 |  |
| Accrued and other | 9,549 |  |  | 9,773 |  |
| Short-term deferred revenue | 16,525 |  |  | 14,881 |  |
| Total current liabilities | 54,132 |  |  | 52,456 |  |
| Long-term debt | 41,622 |  |  | 44,319 |  |
| Long-term deferred revenue | 14,276 |  |  | 12,919 |  |
| Other non-current liabilities | 5,360 |  |  | 5,383 |  |
| Total liabilities | 115,390 |  |  | 115,077 |  |
| Redeemable shares | 472 |  |  | 629 |  |
| Stockholders’ equity (deficit): |  |  |  |
| Total Dell Technologies Inc. stockholders’ equity (deficit) | 2,479 |  |  | (1,574) |  |
| Non-controlling interests | 5,074 |  |  | 4,729 |  |
| Total stockholders’ equity | 7,553 |  |  | 3,155 |  |
| Total liabilities, redeemable shares, and stockholders’ equity | $ | 123,415 |  |  | $ | 118,861 |  |

[0001571996-21-000003:8k_2_02:70]
6

[0001571996-21-000003:8k_2_02:71]
DELL TECHNOLOGIES INC.

[0001571996-21-000003:8k_2_02:72]
Condensed Consolidated Statements of Cash Flows

[0001571996-21-000003:8k_2_02:73]
(in millions; unaudited)

[0001571996-21-000003:8k_2_02:74]
|  | Three Months Ended |  | Fiscal Year Ended |
|  | January 29, 2021 |  | January 31, 2020 |  | January 29, 2021 |  | January 31, 2020 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |
| Net income | $ | 1,343 |  |  | $ | 416 |  |  | $ | 3,505 |  |  | $ | 5,529 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: | 4,534 |  |  | 3,092 |  |  | 7,902 |  |  | 3,762 |  |
| Change in cash from operating activities | 5,877 |  |  | 3,508 |  |  | 11,407 |  |  | 9,291 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |
| Purchases of investments | (42) |  |  | (39) |  |  | (338) |  |  | (181) |  |
| Maturities and sales of investments | 71 |  |  | 48 |  |  | 169 |  |  | 497 |  |
| Capital expenditures and capitalized software development costs | (498) |  |  | (700) |  |  | (2,082) |  |  | (2,576) |  |
| Acquisition of businesses and assets, net | (19) |  |  | (26) |  |  | (424) |  |  | (2,463) |  |
| Divestitures of businesses and assets, net | — |  |  | — |  |  | 2,187 |  |  | (3) |  |
| Other | 2 |  |  | 13 |  |  | 28 |  |  | 40 |  |
| Change in cash from investing activities | (486) |  |  | (704) |  |  | (460) |  |  | (4,686) |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |
| Proceeds from the issuance of common stock | 63 |  |  | 207 |  |  | 452 |  |  | 658 |  |
| Repurchases of parent common stock | (1) |  |  | (2) |  |  | (241) |  |  | (8) |  |
| Repurchases of subsidiary common stock (a) | (473) |  |  | (1,861) |  |  | (1,363) |  |  | (3,547) |  |
| Proceeds from debt | 1,619 |  |  | 2,825 |  |  | 16,391 |  |  | 20,481 |  |
| Repayments of debt | (3,675) |  |  | (3,169) |  |  | (20,919) |  |  | (22,117) |  |
| Other | — |  |  | (4) |  |  | (270) |  |  | (71) |  |
| Change in cash from financing activities | (2,467) |  |  | (2,004) |  |  | (5,950) |  |  | (4,604) |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash | 103 |  |  | 10 |  |  | 36 |  |  | (90) |  |
| Change in cash, cash equivalents, and restricted cash | 3,027 |  |  | 810 |  |  | 5,033 |  |  | (89) |  |
| Cash, cash equivalents, and restricted cash at beginning of the period | 12,157 |  |  | 9,341 |  |  | 10,151 |  |  | 10,240 |  |
| Cash, cash equivalents, and restricted cash at end of the period | $ | 15,184 |  |  | $ | 10,151 |  |  | $ | 15,184 |  |  | $ | 10,151 |  |

[0001571996-21-000003:8k_2_02:75]
_________________

[0001571996-21-000003:8k_2_02:76]
(a)     Subsidiary common stock repurchases are inclusive of employee tax withholding on stock-based compensation.

[0001571996-21-000003:8k_2_02:77]
7

[0001571996-21-000003:8k_2_02:78]
DELL TECHNOLOGIES INC.

[0001571996-21-000003:8k_2_02:79]
Segment Information

[0001571996-21-000003:8k_2_02:80]
(in millions, except percentages; unaudited; continued on next page)

[0001571996-21-000003:8k_2_02:81]
|  | Three Months Ended |  |  |  | Fiscal Year Ended |  |  |
|  | January 29, 2021 |  | January 31, 2020 |  | Change |  | January 29, 2021 |  | January 31, 2020 |  | Change |
| Infrastructure Solutions Group (ISG): |
| Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Servers and networking | $ | 4,379 |  |  | $ | 4,269 |  |  | 3% |  | $ | 16,497 |  |  | $ | 17,127 |  |  | (4)% |
| Storage | 4,409 |  |  | 4,487 |  |  | (2)% |  | 16,091 |  |  | 16,842 |  |  | (4)% |
| Total ISG net revenue | $ | 8,788 |  |  | $ | 8,756 |  |  | —% |  | $ | 32,588 |  |  | $ | 33,969 |  |  | (4)% |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| ISG operating income | $ | 1,189 |  |  | $ | 1,112 |  |  | 7% |  | $ | 3,776 |  |  | $ | 4,001 |  |  | (6)% |
| % of ISG net revenue | 14 | % |  | 13 | % |  |  |  | 12 | % |  | 12 | % |  |  |
| % of total reportable segment operating income | 36 | % |  | 40 | % |  |  |  | 35 | % |  | 39 | % |  |  |
| Client Solutions Group (CSG): |
| Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 9,940 |  |  | $ | 8,563 |  |  | 16% |  | $ | 35,396 |  |  | $ | 34,277 |  |  | 3% |
| Consumer | 3,822 |  |  | 3,207 |  |  | 19% |  | 12,959 |  |  | 11,561 |  |  | 12% |
| Total CSG net revenue | $ | 13,762 |  |  | $ | 11,770 |  |  | 17% |  | $ | 48,355 |  |  | $ | 45,838 |  |  | 5% |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| CSG operating income | $ | 1,043 |  |  | $ | 624 |  |  | 67% |  | $ | 3,352 |  |  | $ | 3,138 |  |  | 7% |
| % of CSG net revenue | 8 | % |  | 5 | % |  |  |  | 7 | % |  | 7 | % |  |  |
| % of total reportable segment operating income | 32 | % |  | 23 | % |  |  |  | 31 | % |  | 31 | % |  |  |
| VMware (a): |
| Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Total VMware net revenue | $ | 3,317 |  |  | $ | 3,126 |  |  | 6% |  | $ | 11,873 |  |  | $ | 10,905 |  |  | 9% |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| VMware operating income | $ | 1,067 |  |  | $ | 1,026 |  |  | 4% |  | $ | 3,571 |  |  | $ | 3,081 |  |  | 16% |
| % of VMware net revenue | 32 | % |  | 33 | % |  |  |  | 30 | % |  | 28 | % |  |  |
| % of total reportable segment operating income | 32 | % |  | 37 | % |  |  |  | 33 | % |  | 30 | % |  |  |

[0001571996-21-000003:8k_2_02:82]
____________________

[0001571996-21-000003:8k_2_02:83]
(a)    During Fiscal 2020, the Company reclassified Pivotal operating results from Other businesses to the VMware reportable segment. There was no change to consolidated results as a result of the reclassification.

[0001571996-21-000003:8k_2_02:84]
8

[0001571996-21-000003:8k_2_02:85]
DELL TECHNOLOGIES INC.

[0001571996-21-000003:8k_2_02:86]
Segment Information

[0001571996-21-000003:8k_2_02:87]
(in millions, except percentages; unaudited; continued)

[0001571996-21-000003:8k_2_02:88]
|  | Three Months Ended |  | Fiscal Year Ended |
|  | January 29, 2021 |  | January 31, 2020 |  | January 29, 2021 |  | January 31, 2020 |
| Reconciliation to consolidated net revenue: |  |  |  |  |  |  |
| Reportable segment net revenue (a) | $ | 25,867 |  |  | $ | 23,652 |  |  | $ | 92,816 |  |  | $ | 90,712 |  |
| Other businesses (a) (b) | 279 |  |  | 477 |  |  | 1,567 |  |  | 1,788 |  |
| Unallocated transactions (c) | 2 |  |  | — |  |  | 6 |  |  | 1 |  |
| Impact of purchase accounting (d) | (36) |  |  | (97) |  |  | (165) |  |  | (347) |  |
| Total consolidated net revenue | $ | 26,112 |  |  | $ | 24,032 |  |  | $ | 94,224 |  |  | $ | 92,154 |  |
| Reconciliation to consolidated operating income: |  |  |  |  |
| Reportable segment operating income (a) | $ | 3,299 |  |  | $ | 2,762 |  |  | $ | 10,699 |  |  | $ | 10,220 |  |
| Other businesses (a) (b) | (6) |  |  | 5 |  |  | 99 |  |  | (43) |  |
| Unallocated transactions (c) | 1 |  |  | — |  |  | — |  |  | (29) |  |
| Impact of purchase accounting (d) | (48) |  |  | (112) |  |  | (213) |  |  | (411) |  |
| Amortization of intangibles | (846) |  |  | (1,074) |  |  | (3,393) |  |  | (4,408) |  |
| Transaction-related expenses (e) | (46) |  |  | (120) |  |  | (257) |  |  | (285) |  |
| Stock-based compensation expense (f) | (390) |  |  | (376) |  |  | (1,609) |  |  | (1,262) |  |
| Other corporate expenses (g) | 213 |  |  | (368) |  |  | (182) |  |  | (1,160) |  |
| Total consolidated operating income | $ | 2,177 |  |  | $ | 717 |  |  | $ | 5,144 |  |  | $ | 2,622 |  |

[0001571996-21-000003:8k_2_02:89]
_________________

[0001571996-21-000003:8k_2_02:90]
(a)During Fiscal 2020, the Company reclassified Pivotal operating results from Other businesses to the VMware reportable segment.

[0001571996-21-000003:8k_2_02:91]
(b)Secureworks, Virtustream, and Boomi constitute “Other businesses” and do not meet the requirements for a reportable segment, either individually or collectively. The Company completed the sale of RSA Security on September 1, 2020; prior to divestiture, RSA Security’s operating results were also included in Other Businesses and did not meet the requirements for a reportable segment. The results of Other businesses are not material to the Company’s overall results.

[0001571996-21-000003:8k_2_02:92]
(c)Unallocated transactions includes other corporate items that are not allocated to Dell Technologies’ reportable segments.

[0001571996-21-000003:8k_2_02:93]
(d)Impact of purchase accounting includes non-cash purchase accounting adjustments that are primarily related to the EMC merger transaction.

[0001571996-21-000003:8k_2_02:94]
(e)Transaction-related expenses includes acquisition, integration, and divestiture related costs.

[0001571996-21-000003:8k_2_02:95]
(f)Stock-based compensation expense consists of equity awards granted based on the estimated fair value of those awards at grant date.

[0001571996-21-000003:8k_2_02:96]
(g)Other corporate expenses includes impairment charges, severance, facility action, and other costs.  The fourth quarter of Fiscal 2021 includes derecognition of a $237 million previously accrued litigation loss as a result of a jury verdict in January 2020 against VMware, Inc. in a patent litigation matter.  On December 21, 2020, the United States District Court of the District of Delaware set aside the jury verdict and ordered a new trial.

[0001571996-21-000003:8k_2_02:97]
9

[0001571996-21-000003:8k_2_02:98]
SUPPLEMENTAL SELECTED NON-GAAP FINANCIAL MEASURES

[0001571996-21-000003:8k_2_02:99]
These tables present information about the Company’s non-GAAP net revenue, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, non-GAAP net income attributable to non-controlling interests, non-GAAP net income attributable to Dell Technologies Inc. - basic, non-GAAP net income attributable to Dell Technologies Inc. - diluted, non-GAAP earnings per share attributable to Dell Technologies Inc. - basic, non-GAAP earnings per share attributable to Dell Technologies Inc. - diluted, EBITDA, and adjusted EBITDA, which are non-GAAP financial measures provided as a supplement to the results provided in accordance with generally accepted accounting principles in the United States of America (“GAAP”). A detailed discussion of Dell Technologies’ reasons for including these non-GAAP financial measures, the limitations associated with these measures, the items excluded from these measures, and our reason for excluding those items are presented in “Management’s Discussion and Analysis of Financial Condition and Results of Operations — Non-GAAP Financial Measures” in our periodic reports filed with the SEC. Dell Technologies encourages investors to review the non-GAAP discussion in these reports in conjunction with the presentation of non-GAAP financial measures.

[0001571996-21-000003:8k_2_02:100]
10

[0001571996-21-000003:8k_2_02:101]
DELL TECHNOLOGIES INC.

[0001571996-21-000003:8k_2_02:102]
Selected Non-GAAP Financial Measures

[0001571996-21-000003:8k_2_02:103]
(in millions, except per share amounts and percentages; unaudited)

[0001571996-21-000003:8k_2_02:104]
|  | Three Months Ended |  |  |  | Fiscal Year Ended |  |  |
|  | January 29, 2021 |  | January 31, 2020 |  | Change |  | January 29, 2021 |  | January 31, 2020 |  | Change |
| Non-GAAP net revenue | $ | 26,148 |  |  | $ | 24,129 |  |  | 8% |  | $ | 94,389 |  |  | $ | 92,501 |  |  | 2% |
| Non-GAAP gross margin | $ | 8,624 |  |  | $ | 8,375 |  |  | 3% |  | $ | 31,346 |  |  | $ | 31,563 |  |  | (1)% |
| % of non-GAAP net revenue | 33 | % |  | 35 | % |  |  |  | 33 | % |  | 34 | % |  |  |
| Non-GAAP operating expenses | $ | 5,330 |  |  | $ | 5,608 |  |  | (5)% |  | $ | 20,548 |  |  | $ | 21,415 |  |  | (4)% |
| % of non-GAAP net revenue | 20 | % |  | 23 | % |  |  |  | 22 | % |  | 23 | % |  |  |
| Non-GAAP operating income | $ | 3,294 |  |  | $ | 2,767 |  |  | 19% |  | $ | 10,798 |  |  | $ | 10,148 |  |  | 6% |
| % of non-GAAP net revenue | 13 | % |  | 11 | % |  |  |  | 11 | % |  | 11 | % |  |  |
| Non-GAAP net income | $ | 2,288 |  |  | $ | 1,684 |  |  | 36% |  | $ | 6,763 |  |  | $ | 6,089 |  |  | 11% |
| % of non-GAAP net revenue | 9 | % |  | 7 | % |  |  |  | 7 | % |  | 7 | % |  |  |
| Adjusted EBITDA | $ | 3,809 |  |  | $ | 3,201 |  |  | 19% |  | $ | 12,747 |  |  | $ | 11,787 |  |  | 8% |
| % of non-GAAP net revenue | 15 | % |  | 13 | % |  |  |  | 14 | % |  | 13 | % |  |  |
| Non-GAAP earnings per share - diluted | $ | 2.70 |  |  | $ | 2.00 |  |  | 35% |  | $ | 8.00 |  |  | $ | 7.35 |  |  | 9% |

[0001571996-21-000003:8k_2_02:105]
11

[0001571996-21-000003:8k_2_02:106]
DELL TECHNOLOGIES INC.

[0001571996-21-000003:8k_2_02:107]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-21-000003:8k_2_02:108]
(in millions, except percentages; unaudited; continued on next page)

[0001571996-21-000003:8k_2_02:109]
|  | Three Months Ended |  |  |  | Fiscal Year Ended |  |  |
|  | January 29, 2021 |  | January 31, 2020 |  | Change |  | January 29, 2021 |  | January 31, 2020 |  | Change |
| Net revenue | $ | 26,112 |  |  | $ | 24,032 |  |  | 9% |  | $ | 94,224 |  |  | $ | 92,154 |  |  | 2% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 36 |  |  | 97 |  |  |  |  | 165 |  |  | 347 |  |  |  |
| Non-GAAP net revenue | $ | 26,148 |  |  | $ | 24,129 |  |  | 8% |  | $ | 94,389 |  |  | $ | 92,501 |  |  | 2% |
| Gross margin | $ | 8,147 |  |  | $ | 7,684 |  |  | 6% |  | $ | 29,417 |  |  | $ | 28,933 |  |  | 2% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 380 |  |  | 526 |  |  |  |  | 1,502 |  |  | 2,081 |  |  |  |
| Impact of purchase accounting | 37 |  |  | 98 |  |  |  |  | 171 |  |  | 353 |  |  |  |
| Transaction-related expenses | — |  |  | — |  |  |  |  | — |  |  | (5) |  |  |  |
| Stock-based compensation expense | 53 |  |  | 38 |  |  |  |  | 194 |  |  | 129 |  |  |  |
| Other corporate expenses | 7 |  |  | 29 |  |  |  |  | 62 |  |  | 72 |  |  |  |
| Non-GAAP gross margin | $ | 8,624 |  |  | $ | 8,375 |  |  | 3% |  | $ | 31,346 |  |  | $ | 31,563 |  |  | (1)% |
| Operating expenses | $ | 5,970 |  |  | $ | 6,967 |  |  | (14)% |  | $ | 24,273 |  |  | $ | 26,311 |  |  | (8)% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | (466) |  |  | (548) |  |  |  |  | (1,891) |  |  | (2,327) |  |  |  |
| Impact of purchase accounting | (11) |  |  | (14) |  |  |  |  | (42) |  |  | (58) |  |  |  |
| Transaction-related expenses | (46) |  |  | (120) |  |  |  |  | (257) |  |  | (290) |  |  |  |
| Stock-based compensation expense | (337) |  |  | (338) |  |  |  |  | (1,415) |  |  | (1,133) |  |  |  |
| Other corporate expenses | 220 |  |  | (339) |  |  |  |  | (120) |  |  | (1,088) |  |  |  |
| Non-GAAP operating expenses | $ | 5,330 |  |  | $ | 5,608 |  |  | (5)% |  | $ | 20,548 |  |  | $ | 21,415 |  |  | (4)% |
| Operating income | $ | 2,177 |  |  | $ | 717 |  |  | 204% |  | $ | 5,144 |  |  | $ | 2,622 |  |  | 96% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 846 |  |  | 1,074 |  |  |  |  | 3,393 |  |  | 4,408 |  |  |  |
| Impact of purchase accounting | 48 |  |  | 112 |  |  |  |  | 213 |  |  | 411 |  |  |  |
| Transaction-related expenses | 46 |  |  | 120 |  |  |  |  | 257 |  |  | 285 |  |  |  |
| Stock-based compensation expense | 390 |  |  | 376 |  |  |  |  | 1,609 |  |  | 1,262 |  |  |  |
| Other corporate expenses | (213) |  |  | 368 |  |  |  |  | 182 |  |  | 1,160 |  |  |  |
| Non-GAAP operating income | $ | 3,294 |  |  | $ | 2,767 |  |  | 19% |  | $ | 10,798 |  |  | $ | 10,148 |  |  | 6% |

[0001571996-21-000003:8k_2_02:110]
12

[0001571996-21-000003:8k_2_02:111]
DELL TECHNOLOGIES INC.

[0001571996-21-000003:8k_2_02:112]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-21-000003:8k_2_02:113]
(in millions, except percentages; unaudited; continued)

[0001571996-21-000003:8k_2_02:114]
|  | Three Months Ended |  |  |  | Fiscal Year Ended |  |  |
|  | January 29, 2021 |  | January 31, 2020 |  | Change |  | January 29, 2021 |  | January 31, 2020 |  | Change |
| Net income | $ | 1,343 |  |  | $ | 416 |  |  | 223% |  | $ | 3,505 |  |  | $ | 5,529 |  |  | (37)% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 846 |  |  | 1,074 |  |  |  |  | 3,393 |  |  | 4,408 |  |  |  |
| Impact of purchase accounting | 48 |  |  | 112 |  |  |  |  | 213 |  |  | 411 |  |  |  |
| Transaction-related expenses | 46 |  |  | 120 |  |  |  |  | (201) |  |  | 285 |  |  |  |
| Stock-based compensation expense | 390 |  |  | 376 |  |  |  |  | 1,609 |  |  | 1,262 |  |  |  |
| Other corporate expenses | (213) |  |  | 368 |  |  |  |  | 74 |  |  | 1,160 |  |  |  |
| Fair value adjustments on equity investments | 9 |  |  | (34) |  |  |  |  | (582) |  |  | (194) |  |  |  |
| Aggregate adjustment for income taxes | (181) |  |  | (748) |  |  |  |  | (1,248) |  |  | (6,772) |  |  |  |
| Non-GAAP net income | $ | 2,288 |  |  | $ | 1,684 |  |  | 36% |  | $ | 6,763 |  |  | $ | 6,089 |  |  | 11% |
| Net income | $ | 1,343 |  |  | $ | 416 |  |  | 223% |  | $ | 3,505 |  |  | $ | 5,529 |  |  | (37)% |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Interest and other, net | 545 |  |  | 626 |  |  |  |  | 1,474 |  |  | 2,626 |  |  |  |
| Income tax provision (benefit) | 289 |  |  | (325) |  |  |  |  | 165 |  |  | (5,533) |  |  |  |
| Depreciation and amortization | 1,373 |  |  | 1,535 |  |  |  |  | 5,390 |  |  | 6,143 |  |  |  |
| EBITDA | $ | 3,550 |  |  | $ | 2,252 |  |  | 58% |  | $ | 10,534 |  |  | $ | 8,765 |  |  | 20% |
| EBITDA | $ | 3,550 |  |  | $ | 2,252 |  |  | 58% |  | $ | 10,534 |  |  | $ | 8,765 |  |  | 20% |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense | 390 |  |  | 376 |  |  |  |  | 1,609 |  |  | 1,262 |  |  |  |
| Impact of purchase accounting | 36 |  |  | 96 |  |  |  |  | 165 |  |  | 347 |  |  |  |
| Transaction-related expenses | 46 |  |  | 120 |  |  |  |  | 257 |  |  | 285 |  |  |  |
| Other corporate expenses | (213) |  |  | 357 |  |  |  |  | 182 |  |  | 1,128 |  |  |  |
| Adjusted EBITDA | $ | 3,809 |  |  | $ | 3,201 |  |  | 19% |  | $ | 12,747 |  |  | $ | 11,787 |  |  | 8% |

[0001571996-21-000003:8k_2_02:115]
13

[0001571996-21-000003:8k_2_02:116]
DELL TECHNOLOGIES INC.

[0001571996-21-000003:8k_2_02:117]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-21-000003:8k_2_02:118]
For the Three Months Ended January 29, 2021

[0001571996-21-000003:8k_2_02:119]
(in millions, except per share amounts; unaudited)

[0001571996-21-000003:8k_2_02:120]
|  | GAAP |  | Amortization of intangibles |  | Impact of purchase accounting |  | Transaction-related expenses |  | Stock-based compensation expense |  | Other corporate expenses |  | Fair value adjustments on equity investments |  | Aggregate adjustment for income taxes |  | Non-GAAP |
| Net income | $ | 1,343 |  |  | 846 |  |  | 48 |  |  | 46 |  |  | 390 |  |  | (213) |  |  | 9 |  |  | (181) |  |  | $ | 2,288 |  |
| Less: Net income attributable to non-controlling interests (a) | 116 |  |  | 62 |  |  | 3 |  |  | 6 |  |  | 51 |  |  | (47) |  |  | 4 |  |  | (10) |  |  | 185 |  |
| Net income attributable to Dell Technologies Inc. - basic | 1,227 |  |  | 784 |  |  | 45 |  |  | 40 |  |  | 339 |  |  | (166) |  |  | 5 |  |  | (171) |  |  | 2,103 |  |
| Incremental dilution from VMware, Inc. attributable to Dell Technologies Inc. (b) | (5) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (5) |  |
| Net income attributable to Dell Technologies Inc. - diluted | $ | 1,222 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 2,098 |  |
| Earnings per share - basic | $ | 1.64 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 2.80 |  |
| Earnings per share - diluted | $ | 1.57 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 2.70 |  |
| Weighted-average shares outstanding - basic | 750 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 750 |  |
| Weighted-average shares outstanding - diluted | 776 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 776 |  |

[0001571996-21-000003:8k_2_02:121]
_________________

[0001571996-21-000003:8k_2_02:122]
(a)     Net income attributable to non-controlling interests is calculated by multiplying the minority interest percentage of VMware, Inc. and SecureWorks Corp. by their non-GAAP net income adjustments for the period presented.

[0001571996-21-000003:8k_2_02:123]
(b)     Incremental dilution from VMware, Inc. attributable to Dell Technologies Inc. represents the impact of VMware, Inc.’s dilutive securities on the diluted earnings per share of Dell Technologies Inc. and is calculated by multiplying the difference between VMware, Inc.’s basic and diluted earnings per share by the number of shares of VMware, Inc. common stock held by Dell Technologies Inc.

[0001571996-21-000003:8k_2_02:124]
14

[0001571996-21-000003:8k_2_02:125]
DELL TECHNOLOGIES INC.

[0001571996-21-000003:8k_2_02:126]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-21-000003:8k_2_02:127]
For the Fiscal Year Ended January 29, 2021

[0001571996-21-000003:8k_2_02:128]
(in millions, except per share amounts; unaudited)

[0001571996-21-000003:8k_2_02:129]
|  | GAAP |  | Amortization of intangibles |  | Impact of purchase accounting |  | Transaction-related expenses |  | Stock-based compensation expense |  | Other corporate expenses |  | Fair value adjustments on equity investments |  | Aggregate adjustment for income taxes |  | Non-GAAP |
| Net income | $ | 3,505 |  |  | 3,393 |  |  | 213 |  |  | (201) |  |  | 1,609 |  |  | 74 |  |  | (582) |  |  | (1,248) |  |  | $ | 6,763 |  |
| Less: Net income attributable to non-controlling interests (a) | 255 |  |  | 249 |  |  | 13 |  |  | 26 |  |  | 223 |  |  | (38) |  |  | (31) |  |  | (87) |  |  | 610 |  |
| Net income attributable to Dell Technologies Inc. - basic | 3,250 |  |  | $ | 3,144 |  |  | $ | 200 |  |  | $ | (227) |  |  | $ | 1,386 |  |  | $ | 112 |  |  | $ | (551) |  |  | $ | (1,161) |  |  | 6,153 |  |
| Incremental dilution from VMware, Inc. attributable to Dell Technologies Inc. (b) | (13) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (20) |  |
| Net income attributable to Dell Technologies Inc. - diluted | $ | 3,237 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 6,133 |  |
| Earnings per share - basic | $ | 4.37 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 8.27 |  |
| Earnings per share - diluted | $ | 4.22 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 8.00 |  |
| Weighted-average shares outstanding - basic | 744 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 744 |  |
| Weighted-average shares outstanding - diluted | 767 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 767 |  |

[0001571996-21-000003:8k_2_02:130]
_________________

[0001571996-21-000003:8k_2_02:131]
(a)     Net income attributable to non-controlling interests is calculated by multiplying the minority interest percentage of VMware, Inc. and SecureWorks Corp. by their non-GAAP net income adjustments for the period presented.

[0001571996-21-000003:8k_2_02:132]
(b)     Incremental dilution from VMware, Inc. attributable to Dell Technologies Inc. represents the impact of VMware, Inc.’s dilutive securities on the diluted earnings per share of Dell Technologies Inc. and is calculated by multiplying the difference between VMware, Inc.’s basic and diluted earnings per share by the number of shares of VMware, Inc. common stock held by Dell Technologies Inc.

[0001571996-21-000003:8k_2_02:133]
15

[0001571996-21-000003:8k_2_02:134]
DELL TECHNOLOGIES INC.

[0001571996-21-000003:8k_2_02:135]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-21-000003:8k_2_02:136]
For the Three Months Ended January 31, 2020

[0001571996-21-000003:8k_2_02:137]
(in millions, except per share amounts; unaudited)

[0001571996-21-000003:8k_2_02:138]
|  | GAAP |  | Amortization of intangibles |  | Impact of purchase accounting |  | Transaction-related expenses |  | Stock-based compensation expense |  | Other corporate expenses |  | Fair value adjustments on equity investments |  | Aggregate adjustment for income taxes |  | Non-GAAP |
| Net income | $ | 416 |  |  | 1,074 |  |  | 112 |  |  | 120 |  |  | 376 |  |  | 368 |  |  | (34) |  |  | (748) |  |  | $ | 1,684 |  |
| Less: Net income attributable to non-controlling interests (a) | 8 |  |  | 76 |  |  | 6 |  |  | 32 |  |  | 65 |  |  | 45 |  |  | — |  |  | (61) |  |  | 171 |  |
| Net income attributable to Dell Technologies Inc. - basic | 408 |  |  | 998 |  |  | 106 |  |  | 88 |  |  | 311 |  |  | 323 |  |  | (34) |  |  | (687) |  |  | 1,513 |  |
| Incremental dilution from VMware, Inc. attributable to Dell Technologies Inc. (b) | (3) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (8) |  |
| Net income attributable to Dell Technologies Inc. - diluted | $ | 405 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 1,505 |  |
| Earnings per share - basic | $ | 0.56 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 2.06 |  |
| Earnings per share - diluted | $ | 0.54 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 2.00 |  |
| Weighted-average shares outstanding - basic | 734 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 734 |  |
| Weighted-average shares outstanding - diluted | 754 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 754 |  |

[0001571996-21-000003:8k_2_02:139]
_________________

[0001571996-21-000003:8k_2_02:140]
(a)     Net income attributable to non-controlling interests is calculated by multiplying the minority interest percentage of VMware, Inc., Pivotal Software, Inc., and SecureWorks Corp. by their non-GAAP net income adjustments for the period presented.

[0001571996-21-000003:8k_2_02:141]
(b)     Incremental dilution from VMware, Inc. attributable to Dell Technologies Inc. represents the impact of VMware, Inc.’s dilutive securities on the diluted earnings per share of Dell Technologies Inc. and is calculated by multiplying the difference between VMware, Inc.’s basic and diluted earnings per share by the number of shares of VMware, Inc. common stock held by Dell Technologies Inc.

[0001571996-21-000003:8k_2_02:142]
DELL TECHNOLOGIES INC.

[0001571996-21-000003:8k_2_02:143]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-21-000003:8k_2_02:144]
For the Fiscal Year Ended January 31, 2020

[0001571996-21-000003:8k_2_02:145]
(in millions, except per share amounts; unaudited)

[0001571996-21-000003:8k_2_02:146]
|  | GAAP |  | Amortization of intangibles |  | Impact of purchase accounting |  | Transaction-related expenses |  | Stock-based compensation expense |  | Other corporate expenses |  | Fair value adjustments on equity investments |  | Aggregate adjustment for income taxes |  | Non-GAAP |
| Net income | $ | 5,529 |  |  | 4,408 |  |  | 411 |  |  | 285 |  |  | 1,262 |  |  | 1,160 |  |  | (194) |  |  | (6,772) |  |  | $ | 6,089 |  |
| Less: Net income attributable to non-controlling interests (a) | 913 |  |  | 295 |  |  | 23 |  |  | 50 |  |  | 217 |  |  | 45 |  |  | 24 |  |  | (1,032) |  |  | 535 |  |
| Net income attributable to Dell Technologies Inc. - basic | 4,616 |  |  | 4,113 |  |  | 388 |  |  | 235 |  |  | 1,045 |  |  | 1,115 |  |  | (218) |  |  | (5,740) |  |  | 5,554 |  |
| Incremental dilution from VMware, Inc. attributable to Dell Technologies Inc. (b) | (84) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (35) |  |
| Net income attributable to Dell Technologies Inc. - diluted | $ | 4,532 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 5,519 |  |
| Earnings per share - basic | $ | 6.38 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 7.67 |  |
| Earnings per share - diluted | $ | 6.03 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 7.35 |  |
| Weighted-average shares outstanding - basic | 724 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 724 |  |
| Weighted-average shares outstanding - diluted | 751 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 751 |  |

[0001571996-21-000003:8k_2_02:147]
_________________

[0001571996-21-000003:8k_2_02:148]
(a)     Net income attributable to non-controlling interests is calculated by multiplying the minority interest percentage of VMware, Inc., Pivotal Software, Inc., and SecureWorks Corp. by their non-GAAP net income adjustments for the period presented.

[0001571996-21-000003:8k_2_02:149]
(b)     Incremental dilution from VMware, Inc. attributable to Dell Technologies Inc. represents the impact of VMware, Inc.’s dilutive securities on the diluted earnings per share of Dell Technologies Inc. and is calculated by multiplying the difference between VMware, Inc.’s basic and diluted earnings per share by the number of shares of VMware, Inc. common stock held by Dell Technologies Inc.
