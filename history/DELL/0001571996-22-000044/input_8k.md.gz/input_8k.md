# DELL 8-K — 0001571996-22-000041 filed 2022-11-21

## item codes, every 8-K on or before 2022-12-05

- 2022-11-21 0001571996-22-000041 — 2.02, 9.01
- 2022-11-16 0001571996-22-000038 — 8.01
- 2022-08-25 0001571996-22-000028 — 2.02, 9.01
- 2022-07-18 0001193125-22-196334 — 2.03, 8.01
- 2022-06-29 0001571996-22-000025 — 3.03, 5.03, 5.07, 8.01, 9.01
- 2022-05-26 0001571996-22-000013 — 2.02, 9.01
- 2022-02-24 0001571996-22-000004 — 2.02, 8.01, 9.01
- 2021-12-20 0001193125-21-362482 — 8.01, 9.01
- 2021-12-15 0001193125-21-357927 — 1.01, 2.03, 9.01
- 2021-12-07 0001193125-21-349218 — 8.01, 9.01
- 2021-11-23 0001571996-21-000060 — 2.02, 9.01
- 2021-11-05 0001571996-21-000057 — 1.02, 2.01, 7.01, 8.01, 9.01 — amendment, the index does not say of what
- 2021-11-01 0001571996-21-000052 — 8.01, 9.01
- 2021-11-01 0001193125-21-315488 — 1.01, 1.02, 2.01, 8.01, 9.01
- 2021-10-21 0001193125-21-304052 — 8.01, 9.01
- 2021-10-19 0001571996-21-000050 — 8.01, 9.01
- 2021-10-07 0001193125-21-294210 — 8.01, 9.01
- 2021-09-30 0001571996-21-000047 — 5.02
- 2021-09-27 0001571996-21-000045 — 8.01
- 2021-09-23 0001193125-21-280190 — 7.01, 8.01, 9.01
- 2021-09-20 0001193125-21-276810 — 7.01, 9.01
- 2021-08-26 0001571996-21-000037 — 2.02, 9.01
- 2021-07-01 0001571996-21-000034 — 3.02
- 2021-06-24 0001571996-21-000031 — 5.07
- 2021-06-24 0001193125-21-197644 — 7.01, 9.01
- 2021-06-16 0001571996-21-000029 — 5.02
- 2021-05-27 0001571996-21-000019 — 2.02, 9.01
- 2021-05-03 0001571996-21-000010 — 8.01, 9.01
- 2021-04-14 0001193125-21-116271 — 1.01, 7.01, 9.01
- 2021-02-25 0001571996-21-000003 — 2.02, 9.01
- 2021-02-18 0001193125-21-047844 — 1.01, 2.03, 9.01
- 2020-11-24 0001571996-20-000048 — 2.02, 9.01
- 2020-08-27 0001571996-20-000041 — 2.02, 9.01
- 2020-07-02 0001571996-20-000037 — 5.07
- 2020-05-28 0001571996-20-000028 — 2.02, 9.01
- 2020-04-09 0001193125-20-102602 — 1.01, 2.03, 9.01
- 2020-04-08 0001571996-20-000021 — 5.02
- 2020-04-03 0001571996-20-000019 — 8.01, 9.01
- 2020-03-26 0001571996-20-000015 — 7.01
- 2020-02-27 0001571996-20-000009 — 2.02, 8.01, 9.01
- 2020-02-18 0001571996-20-000005 — 8.01, 9.01
- 2020-01-09 0001571996-20-000002 — 3.02
- 2020-01-06 0001193125-20-002200 — 3.02
- 2019-12-13 0001193125-19-313947 — 3.02
- 2019-12-10 0001571996-19-000052 — 5.02
- 2019-12-02 0001571996-19-000044 — 5.02, 7.01, 9.01
- 2019-11-26 0001571996-19-000042 — 2.02, 9.01
- 2019-09-23 0001193125-19-252192 — 1.01, 2.03, 9.01
- 2019-08-29 0001571996-19-000036 — 2.02, 9.01
- 2019-08-22 0001193125-19-226939 — 7.01, 8.01, 9.01
- 2019-07-11 0001571996-19-000032 — 5.02, 5.07, 9.01
- 2019-07-03 0001571996-19-000030 — 3.02
- 2019-06-27 0001571996-19-000028 — 3.02
- 2019-05-30 0001571996-19-000021 — 2.02, 9.01
- 2019-04-02 0001571996-19-000010 — 5.02
- 2019-03-21 0001193125-19-082281 — 1.01, 1.02, 2.03, 9.01
- 2019-03-19 0001571996-19-000005 — 5.02, 9.01
- 2019-03-14 0001193125-19-074935 — 1.01, 2.03, 9.01
- 2019-03-07 0001193125-19-066045 — 8.01, 9.01
- 2019-02-28 0001571996-19-000002 — 2.02, 9.01
- 2018-12-28 0001193125-18-360943 — 1.01, 1.02, 3.01, 3.03, 5.02, 5.03, 7.01, 8.01, 9.01
- 2018-12-21 0001193125-18-356324 — 1.01, 2.03, 9.01
- 2018-12-14 0001193125-18-349469 — 8.01
- 2018-12-11 0001193125-18-346958 — 5.07, 8.01, 9.01
- 2018-11-29 0001571996-18-000041 — 2.02, 9.01
- 2018-11-28 0001571996-18-000037 — 7.01, 8.01, 9.01
- 2018-11-26 0001193125-18-333967 — 8.01, 9.01
- 2018-11-15 0001193125-18-328110 — 1.01, 9.01 — amendment of 0001193125-18-327222
- 2018-11-15 0001193125-18-327222 — 1.01, 7.01, 9.01
- 2018-10-03 0001193125-18-291390 — 8.01
- 2018-09-06 0001571996-18-000029 — 2.02, 9.01
- 2018-08-06 0001571996-18-000027 — 8.01, 9.01
- 2018-07-02 0001193125-18-210339 — 1.01, 7.01, 9.01
- 2018-06-28 0001571996-18-000024 — 5.07
- 2018-06-04 0001571996-18-000019 — 2.02, 9.01
- 2018-05-17 0001571996-18-000016 — 7.01
- 2018-04-26 0001571996-18-000009 — 7.01, 9.01
- 2018-03-08 0001193125-18-074168 — 2.02, 9.01
- 2018-02-02 0001193125-18-029947 — 7.01, 9.01
- 2017-12-07 0001571996-17-000042 — 2.02, 9.01
- 2017-10-24 0001571996-17-000037 — 1.01, 2.03, 9.01
- 2017-09-15 0001571996-17-000027 — 5.02
- 2017-09-07 0001571996-17-000017 — 2.02, 9.01
- 2017-08-24 0001571996-17-000014 — 8.01
- 2017-06-29 0001571996-17-000011 — 3.03, 5.07, 8.01, 9.01
- 2017-06-08 0001193125-17-197638 — 2.02, 9.01
- 2017-03-30 0001193125-17-102794 — 8.01
- 2017-03-30 0001193125-17-102777 — 2.02, 9.01
- 2017-03-09 0001193125-17-076981 — 1.01, 2.03, 9.01
- 2017-01-17 0001193125-17-011125 — 8.01
- 2016-12-15 0001193125-16-793722 — 8.01
- 2016-12-08 0001193125-16-787976 — 2.02, 9.01
- 2016-11-10 0001193125-16-765964 — 1.02, 8.01
- 2016-11-04 0001193125-16-760249 — 8.01
- 2016-09-13 0001193125-16-708600 — 3.02
- 2016-09-09 0001193125-16-706567 — 1.01, 1.02, 2.01, 2.03, 3.02, 3.03, 5.02, 9.01
- 2016-09-07 0001193125-16-703370 — 3.03, 5.07, 7.01, 8.01, 9.01
- 2016-09-06 0001193125-16-702057 — 2.02, 9.01
- 2016-08-31 0001193125-16-697268 — 8.01, 9.01
- 2016-08-26 0001193125-16-692921 — 8.01, 9.01
- 2016-07-11 0001193125-16-645610 — 8.01
- 2016-07-05 0001193125-16-641679 — 8.01
- 2016-06-22 0001193125-16-629055 — 1.01, 2.03, 8.01, 9.01
- 2016-06-21 0001193125-16-627071 — 8.01, 9.01
- 2016-06-10 0001193125-16-618483 — 2.02, 9.01
- 2016-06-09 0001193125-16-617893 — 8.01, 9.01

## late-filing notifications on or before 2022-12-05

- none on or before 2022-12-05

## item 2.02 — earnings release, exhibit 99.1

[0001571996-22-000041:8k_2_02:1]
EX-99.1
2
exhibit991earnings8kq3fy23.htm
EX-99.1

[0001571996-22-000041:8k_2_02:2]
Document

[0001571996-22-000041:8k_2_02:3]
Exhibit 99.1

[0001571996-22-000041:8k_2_02:4]
Dell Technologies Announces Third Quarter Fiscal 2023 Financial Results

[0001571996-22-000041:8k_2_02:5]
News summary

[0001571996-22-000041:8k_2_02:6]
•Third quarter revenue down 6% at $24.7 billion

[0001571996-22-000041:8k_2_02:7]
•Operating income up 68% at a record $1.8 billion, and non-GAAP operating income up 22% at a record $2.4 billion

[0001571996-22-000041:8k_2_02:8]
•Diluted earnings per share at $0.33, and non-GAAP diluted earnings per share at $2.30

[0001571996-22-000041:8k_2_02:9]
ROUND ROCK, Texas — November 21, 2022

[0001571996-22-000041:8k_2_02:10]
Full story

[0001571996-22-000041:8k_2_02:11]
Dell Technologies (NYSE: DELL) announces financial results for its fiscal 2023 third quarter. Revenue was $24.7 billion, down 6%. Operating income was a record $1.8 billion, up 68%, representing 7.1% of revenue, and non-GAAP operating income was a record $2.4 billion, up 22%, representing 9.6% of revenue. Net income from continuing operations was $241 million, and non-GAAP net income was $1.7 billion. Diluted earnings per share was $0.33, and non-GAAP diluted earnings per share was $2.30.

[0001571996-22-000041:8k_2_02:12]
Dell Technologies ended the quarter with remaining performance obligations of $39 billion and deferred revenue of $27.1 billion. Recurring revenue for the third quarter was approximately $5.4 billion, up 11% year-over-year. Cash and investments were $6.5 billion, and $847 million was returned to shareholders in the third quarter through share repurchases and dividends.

[0001571996-22-000041:8k_2_02:13]
1

[0001571996-22-000041:8k_2_02:14]
Third Quarter Fiscal 2023 Financial Results

[0001571996-22-000041:8k_2_02:15]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | October 28, 2022 |  | October 29, 2021 |  | Change |  | October 28, 2022 |  | October 29, 2021 |  | Change |
|  | (in millions, except per share amounts and percentages; unaudited) |
| Total net revenue | $ | 24,721 |  |  | $ | 26,424 |  |  | (6)% |  | $ | 77,262 |  |  | $ | 73,205 |  |  | 6% |
| Operating income | $ | 1,762 |  |  | $ | 1,046 |  |  | 68% |  | $ | 4,582 |  |  | $ | 3,050 |  |  | 50% |
| Net income from continuing operations | $ | 241 |  |  | $ | 3,683 |  |  | (93)% |  | $ | 1,816 |  |  | $ | 4,971 |  |  | (63)% |
| Earnings per share - diluted | $ | 0.33 |  |  | $ | 4.68 |  |  | (93)% |  | $ | 2.41 |  |  | $ | 6.34 |  |  | (62)% |
| Non-GAAP net revenue | $ | 24,721 |  |  | $ | 26,432 |  |  | (6)% |  | $ | 77,262 |  |  | $ | 73,229 |  |  | 6% |
| Non-GAAP operating income | $ | 2,380 |  |  | $ | 1,956 |  |  | 22% |  | $ | 6,467 |  |  | $ | 5,594 |  |  | 16% |
| Non-GAAP net income | $ | 1,705 |  |  | $ | 1,313 |  |  | 30% |  | $ | 4,405 |  |  | $ | 3,534 |  |  | 25% |
| Non-GAAP earnings per share - diluted | $ | 2.30 |  |  | $ | 1.66 |  |  | 39% |  | $ | 5.81 |  |  | $ | 4.50 |  |  | 29% |

[0001571996-22-000041:8k_2_02:16]
____________________

[0001571996-22-000041:8k_2_02:17]
During the three and nine months ended October 28, 2022, net income from continuing operations and earnings per share-diluted include a $1.0 billion expense recognized within interest and other, net, in connection with a previously reported litigation settlement agreement.

[0001571996-22-000041:8k_2_02:18]
Information about Dell Technologies’ use of non-GAAP financial information is provided under “Non-GAAP Financial Measures” below. All comparisons in this press release are year-over-year unless otherwise noted.

[0001571996-22-000041:8k_2_02:19]
Operating segments summary

[0001571996-22-000041:8k_2_02:20]
Infrastructure Solutions Group delivered record third quarter revenue of $9.6 billion, up 12% year-over-year and its seventh consecutive quarter of year-over-year growth. Servers and networking revenue was $5.2 billion, up 14%. Storage revenue was $4.4 billion, up 11%. Operating income was a record $1.4 billion, up 54% and approximately 14.3% of Infrastructure Solutions Group revenue.

[0001571996-22-000041:8k_2_02:21]
Client Solutions Group delivered third quarter revenue of $13.8 billion, down 17% year-over-year. Commercial revenue was $10.7 billion, down 13%, and Consumer revenue was $3 billion, down 29%. Operating income was $1.1 billion, down 7% and approximately 7.7% of Client Solutions Group revenue.

[0001571996-22-000041:8k_2_02:22]
Key areas of innovation:

[0001571996-22-000041:8k_2_02:23]
•Dell launched Cybersecurity Advisory Services and a new vulnerability management service, providing organizations with tools and actionable insights to secure their IT environments.

[0001571996-22-000041:8k_2_02:24]
•As part of continuing APEX momentum, Dell PowerFlex block storage is now available in the AWS Marketplace.

[0001571996-22-000041:8k_2_02:25]
•Dell added a customer-managed option for APEX Data Storage Services, helping customers easily transition to an as-a-Service environment.

[0001571996-22-000041:8k_2_02:26]
•Dell announced Project Frontier, an edge operations software platform that centralizes customers’ software applications, operational technologies and multicloud environments with Zero Trust-enabled security protection to securely scale edge operations for any enterprise use case.

[0001571996-22-000041:8k_2_02:27]
•As part of Dell’s edge portfolio, the Latitude 7230 Rugged Extreme Tablet is now available and is the lightest and most powerful 12” fully rugged tablet on the market, offering more speed and reduced energy consumption for workers in extreme environments.

[0001571996-22-000041:8k_2_02:28]
2

[0001571996-22-000041:8k_2_02:29]
Executive Quotes:

[0001571996-22-000041:8k_2_02:30]
•“We played our hand in Q3 exceptionally well; it’s what we do,” said Jeff Clarke, vice chairman and co-chief operating officer, Dell Technologies. “We reduced backlog to meet customer needs and deliver record business results, including record third quarter ISG revenue of $9.6 billion. At the same time, our innovation engine is operating at full throttle in strategic areas like edge, multicloud and as-a-Service.”

[0001571996-22-000041:8k_2_02:31]
•“We executed Q3 with focus and delivered strong operating results, successfully navigating the challenging environment we highlighted in our Q2 earnings call," said Chuck Whitten, co-chief operating officer, Dell Technologies. “With the industry’s largest direct sales force and our technology ecosystem, we anticipated the changing landscape and responded quickly. We combatted slower demand and drove record profitability, with record operating income of $1.8 billion.”

[0001571996-22-000041:8k_2_02:32]
•“We continue to perform well in any environment, driving record operating income and growing revenue 6% year-to-date to $77 billion,” said Tom Sweet, chief financial officer, Dell Technologies. “We’re creating long-term value with strong share positions in the most profitable parts of the market, generating solid free cash flow over time and returning capital to shareholders.”

[0001571996-22-000041:8k_2_02:33]
Conference call information

[0001571996-22-000041:8k_2_02:34]
As previously announced, the Company will hold a conference call to discuss its performance and financial guidance on Nov. 21, 2022, at 3:30 p.m. CST. Prior to the start of the conference call, prepared remarks and a presentation containing additional financial and operating information prior to financial guidance may be downloaded from investors.delltechnologies.com. The conference call will be broadcast live over the internet and can be accessed at

[0001571996-22-000041:8k_2_02:35]
https://investors.delltechnologies.com/events-and-presentations/upcoming-events

[0001571996-22-000041:8k_2_02:36]
For those unable to listen to the live broadcast, the final remarks and presentation with financial guidance will be available following the broadcast, and an archived version will be available at the same location for one year.

[0001571996-22-000041:8k_2_02:37]
Customer Highlights Blog

[0001571996-22-000041:8k_2_02:38]
Read our quarterly blog from Bill Scannell, Dell Technologies president of Global Sales & Customer Operations, to learn more about how we are helping customers with their digital transformations:

[0001571996-22-000041:8k_2_02:39]
https://www.dell.com/en-us/blog/driving-our-customers-businesses-forward/

[0001571996-22-000041:8k_2_02:40]
Environmental, Social and Governance (ESG)

[0001571996-22-000041:8k_2_02:41]
Our Environmental, Social and Governance (ESG) efforts focus on driving positive impact for people and our planet while delivering long-term value for our stakeholders. Explore our ESG resources at

[0001571996-22-000041:8k_2_02:42]
https://www.dell.com/en-us/dt/corporate/social-impact/reporting/esg-governance.htm

[0001571996-22-000041:8k_2_02:43]
About Dell Technologies

[0001571996-22-000041:8k_2_02:44]
Dell Technologies (NYSE:DELL) helps organizations and individuals build their digital future and transform how they work, live and play. The company provides customers with the industry’s broadest and most innovative technology and services portfolio for the data era.

[0001571996-22-000041:8k_2_02:45]
Contacts

[0001571996-22-000041:8k_2_02:46]
Investors: Investor_Relations@Dell.com

[0001571996-22-000041:8k_2_02:47]
Media: Media.Relations@Dell.com

[0001571996-22-000041:8k_2_02:48]
3

[0001571996-22-000041:8k_2_02:49]
# # #

[0001571996-22-000041:8k_2_02:50]
Copyright © 2022 Dell Inc. or its subsidiaries. All Rights Reserved. Dell Technologies, Dell, EMC and Dell EMC are trademarks of Dell Inc. or its subsidiaries. Other trademarks may be trademarks of their respective owners.

[0001571996-22-000041:8k_2_02:51]
Non-GAAP Financial Measures:

[0001571996-22-000041:8k_2_02:52]
This press release presents information about Dell Technologies’ non-GAAP net revenue, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, non-GAAP net income attributable to non-controlling interests, non-GAAP net income attributable to Dell Technologies Inc. - basic, non-GAAP net income attributable to Dell Technologies Inc. - diluted, non-GAAP earnings per share attributable to Dell Technologies Inc. - basic, and non-GAAP earnings per share attributable to Dell Technologies Inc. - diluted, which are non-GAAP financial measures provided as a supplement to the results provided in accordance with generally accepted accounting principles in the United States of America (“GAAP”). A reconciliation of each non-GAAP financial measure to the most directly comparable GAAP financial measure is provided in the attached tables for each of the fiscal periods indicated.

[0001571996-22-000041:8k_2_02:53]
Special Note on Forward-Looking Statements:

[0001571996-22-000041:8k_2_02:54]
Dell Technologies’ results or events in future periods could differ materially from those expressed or implied by these forward-looking statements because of risks, uncertainties, and other factors that include, but are not limited to, the following: risks and uncertainties relating to our spin-off of VMware, Inc., including the potential effects on our business of the transaction; the effects of the COVID-19 pandemic; competitive pressures; Dell Technologies’ reliance on third-party suppliers for products and components, including reliance on single-source or limited-source suppliers; Dell Technologies’ ability to achieve favorable pricing from its vendors; adverse global economic conditions and instability in financial markets; Dell Technologies’ execution of its growth, business and acquisition strategies; the success of Dell Technologies’ cost efficiency measures; Dell Technologies’ ability to manage solutions and products and services transitions in an effective manner; Dell Technologies’ ability to deliver high-quality products, software, and services; cyber attacks or other data security incidents; Dell Technologies’ foreign operations and ability to generate substantial non-U.S. net revenue; Dell Technologies’ product, services, customer, and geographic sales mix, and seasonal sales trends; the performance of Dell Technologies’ sales channel partners; access to the capital markets by Dell Technologies or its customers; material impairment of the value of goodwill or intangible assets; weak economic conditions and the effect of additional regulation on Dell Technologies’ financial services activities; counterparty default risks; the loss by Dell Technologies of any contracts for ISG services and solutions and its ability to perform such contracts at their estimated costs; loss by Dell Technologies of government contracts; Dell Technologies’ ability to develop and protect its proprietary intellectual property or obtain licenses to intellectual property developed by others on commercially reasonable and competitive terms; disruptions in Dell Technologies’ infrastructure; Dell Technologies’ ability to hedge effectively its exposure to fluctuations in foreign currency exchange rates and interest rates; expiration of tax holidays or favorable tax rate structures, or unfavorable outcomes in tax audits and other tax compliance matters; impairment of portfolio investments; unfavorable results of legal proceedings, including the risk associated with final court approval of the recently announced litigation settlement; compliance requirements of changing environmental and safety laws or other laws; the effect of armed hostilities, terrorism, natural disasters, and public health issues; the effect of global climate change and legal, regulatory, or market measures to address climate change; Dell Technologies’ dependence on the services of Michael Dell and key employees; Dell Technologies’ level of indebtedness; the effect of the transition from LIBOR as a reference rate to calculate interest rates under our variable-rate indebtedness; and business and financial factors and legal restrictions affecting continuation of Dell Technologies’ quarterly cash dividend policy and dividend rate.

[0001571996-22-000041:8k_2_02:55]
This list of risks, uncertainties, and other factors is not complete. Dell Technologies discusses some of these matters more fully, as well as certain risk factors that could affect Dell Technologies’ business, financial condition, results of operations, and prospects, in its reports filed with the SEC, including Dell Technologies’ annual report on Form 10-K for the fiscal year ended January 28, 2022, quarterly reports on Form 10-Q, and current reports on Form 8-K. These filings are available for review through the SEC’s website at www.sec.gov. Any or all forward-looking statements Dell Technologies makes may turn out to be wrong and can be affected by inaccurate assumptions Dell Technologies might make or by known or unknown risks, uncertainties and other factors, including those identified in this press release. Accordingly, you should not place undue reliance on the forward-looking statements made in this press release, which speak only as of its date. Dell Technologies does not undertake to update, and expressly disclaims any duty to update, its forward-looking statements, whether as a result of circumstances or events that arise after the date they are made, new information, or otherwise.

[0001571996-22-000041:8k_2_02:56]
4

[0001571996-22-000041:8k_2_02:57]
DELL TECHNOLOGIES INC. FINANCIAL INFORMATION

[0001571996-22-000041:8k_2_02:58]
Basis of Presentation

[0001571996-22-000041:8k_2_02:59]
Spin-Off of VMware, Inc. — On November 1, 2021, Dell Technologies Inc. completed its spin-off of VMware, Inc. (“VMware”) by means of a special stock dividend (the “VMware Spin-off”). In accordance with applicable accounting guidance, the results of VMware, excluding Dell’s resale of VMware offerings, are presented as discontinued operations in the Condensed Consolidated Statements of Income and, as such, have been excluded from both continuing operations and segment results for the three and nine months ended October 29, 2021. The Condensed Consolidated Statements of Cash Flows are presented on a consolidated basis for both continuing operations and discontinued operations.

[0001571996-22-000041:8k_2_02:60]
5

[0001571996-22-000041:8k_2_02:61]
DELL TECHNOLOGIES INC.

[0001571996-22-000041:8k_2_02:62]
Consolidated Statements of Income and Related Financial Highlights

[0001571996-22-000041:8k_2_02:63]
(in millions, except percentages; unaudited)

[0001571996-22-000041:8k_2_02:64]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | October 28, 2022 |  | October 29, 2021 |  | Change |  | October 28, 2022 |  | October 29, 2021 |  | Change |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Products | $ | 18,938 |  | $ | 20,979 |  | (10)% |  | $ | 60,212 |  |  | $ | 57,361 |  |  | 5% |
| Services | 5,783 |  | 5,445 |  | 6% |  | 17,050 |  |  | 15,844 |  |  | 8% |
| Total net revenue | 24,721 |  | 26,424 |  | (6)% |  | 77,262 |  |  | 73,205 |  |  | 6% |
| Cost of net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Products | 15,601 |  | 17,833 |  | (13)% |  | 50,281 |  |  | 47,959 |  |  | 5% |
| Services | 3,413 |  | 3,057 |  | 12% |  | 10,051 |  |  | 8,973 |  |  | 12% |
| Total cost of net revenue | 19,014 |  | 20,890 |  | (9)% |  | 60,332 |  |  | 56,932 |  |  | 6% |
| Gross margin | 5,707 |  | 5,534 |  | 3% |  | 16,930 |  |  | 16,273 |  |  | 4% |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative | 3,268 |  | 3,838 |  | (15)% |  | 10,364 |  |  | 11,257 |  |  | (8)% |
| Research and development | 677 |  | 650 |  | 4% |  | 1,984 |  |  | 1,966 |  |  | 1% |
| Total operating expenses | 3,945 |  | 4,488 |  | (12)% |  | 12,348 |  |  | 13,223 |  |  | (7)% |
| Operating income | 1,762 |  | 1,046 |  | 68% |  | 4,582 |  |  | 3,050 |  |  | 50% |
| Interest and other, net | (1,308) |  | 3,501 |  | (137)% |  | (2,280) |  |  | 2,921 |  |  | (178)% |
| Income before income taxes | 454 |  | 4,547 |  | (90)% |  | 2,302 |  |  | 5,971 |  |  | (61)% |
| Income tax expense | 213 |  | 864 |  | (75)% |  | 486 |  |  | 1,000 |  |  | (51)% |
| Net income from continuing operations | 241 |  | 3,683 |  | (93)% |  | 1,816 |  |  | 4,971 |  |  | (63)% |
| Income from discontinued operations, net of income taxes | — |  | 205 |  | (100)% |  | — |  |  | 735 |  |  | (100)% |
| Net income | 241 |  | 3,888 |  | (94)% |  | 1,816 |  |  | 5,706 |  |  | (68)% |
| Less: Net loss attributable to non-controlling interests | (4) |  | (2) |  | (100)% |  | (12) |  |  | (5) |  |  | (140)% |
| Less: Net income attributable to non-controlling interests of discontinued operations | — |  | 47 |  | (100)% |  | — |  |  | 150 |  |  | (100)% |
| Net income attributable to Dell Technologies Inc. | $ | 245 |  | $ | 3,843 |  | (94)% |  | $ | 1,828 |  |  | $ | 5,561 |  |  | (67)% |
| Percentage of Total Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Gross margin | 23.1 | % |  | 20.9 | % |  |  |  | 21.9 | % |  | 22.2 | % |  |  |
| Selling, general, and administrative | 13.3 | % |  | 14.4 | % |  |  |  | 13.4 | % |  | 15.3 | % |  |  |
| Research and development | 2.7 | % |  | 2.5 | % |  |  |  | 2.6 | % |  | 2.7 | % |  |  |
| Operating expenses | 16.0 | % |  | 16.9 | % |  |  |  | 16.0 | % |  | 18.0 | % |  |  |
| Operating income | 7.1 | % |  | 4.0 | % |  |  |  | 5.9 | % |  | 4.2 | % |  |  |
| Income before income taxes | 1.8 | % |  | 17.2 | % |  |  |  | 3.0 | % |  | 8.2 | % |  |  |
| Net income from continuing operations | 1.0 | % |  | 13.9 | % |  |  |  | 2.4 | % |  | 6.8 | % |  |  |
| Income tax rate | 46.9 | % |  | 19.0 | % |  |  |  | 21.1 | % |  | 16.7 | % |  |  |

[0001571996-22-000041:8k_2_02:65]
____________________

[0001571996-22-000041:8k_2_02:66]
During the three and nine months ended October 28, 2022, net income from continuing operations includes the impact of $1.0 billion expense recognized within interest and other, net, in connection with a previously reported litigation settlement agreement.

[0001571996-22-000041:8k_2_02:67]
Amounts are based on underlying data and may not visually foot due to rounding.

[0001571996-22-000041:8k_2_02:68]
DELL TECHNOLOGIES INC.

[0001571996-22-000041:8k_2_02:69]
Consolidated Statements of Financial Position

[0001571996-22-000041:8k_2_02:70]
(in millions; unaudited)

[0001571996-22-000041:8k_2_02:71]
|  | October 28, 2022 |  | January 28, 2022 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 4,909 |  |  | $ | 9,477 |  |
| Accounts receivable, net | 11,431 |  |  | 12,912 |  |
| Due from related party, net | 203 |  |  | 131 |  |
| Short-term financing receivables, net | 4,915 |  |  | 5,089 |  |
| Inventories | 6,172 |  |  | 5,898 |  |
| Other current assets | 11,157 |  |  | 11,526 |  |
| Total current assets | 38,787 |  |  | 45,033 |  |
| Property, plant, and equipment, net | 5,847 |  |  | 5,415 |  |
| Long-term investments | 1,534 |  |  | 1,839 |  |
| Long-term financing receivables, net | 5,659 |  |  | 5,522 |  |
| Goodwill | 19,366 |  |  | 19,770 |  |
| Intangible assets, net | 6,728 |  |  | 7,461 |  |
| Due from related party, net | 612 |  |  | 710 |  |
| Other non-current assets | 6,639 |  |  | 6,985 |  |
| Total assets | $ | 85,172 |  |  | $ | 92,735 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Short-term debt | $ | 6,767 |  |  | $ | 5,823 |  |
| Accounts payable | 22,507 |  |  | 27,143 |  |
| Due to related party | 712 |  |  | 1,414 |  |
| Accrued and other | 7,915 |  |  | 7,578 |  |
| Short-term deferred revenue | 14,106 |  |  | 14,261 |  |
| Total current liabilities | 52,007 |  |  | 56,219 |  |
| Long-term debt | 20,562 |  |  | 21,131 |  |
| Long-term deferred revenue | 12,983 |  |  | 13,312 |  |
| Other non-current liabilities | 2,988 |  |  | 3,653 |  |
| Total liabilities | 88,540 |  |  | 94,315 |  |
| Stockholders’ equity (deficit): |  |  |  |
| Total Dell Technologies Inc. stockholders’ equity (deficit) | (3,469) |  |  | (1,685) |  |
| Non-controlling interests | 101 |  |  | 105 |  |
| Total stockholders’ equity (deficit) | (3,368) |  |  | (1,580) |  |
| Total liabilities and stockholders’ equity | $ | 85,172 |  |  | $ | 92,735 |  |

[0001571996-22-000041:8k_2_02:72]
7

[0001571996-22-000041:8k_2_02:73]
DELL TECHNOLOGIES INC.

[0001571996-22-000041:8k_2_02:74]
Consolidated Statements of Cash Flows

[0001571996-22-000041:8k_2_02:75]
(in millions; unaudited)

[0001571996-22-000041:8k_2_02:76]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 28, 2022 |  | October 29, 2021 |  | October 28, 2022 |  | October 29, 2021 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |
| Net income | $ | 241 |  |  | $ | 3,888 |  |  | $ | 1,816 |  |  | $ | 5,706 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: | 155 |  |  | (637) |  |  | (965) |  |  | 1,508 |  |
| Change in cash from operating activities | 396 |  |  | 3,251 |  |  | 851 |  |  | 7,214 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |
| Purchases of investments | (21) |  |  | (50) |  |  | (101) |  |  | (320) |  |
| Maturities and sales of investments | 31 |  |  | 119 |  |  | 99 |  |  | 454 |  |
| Capital expenditures and capitalized software development costs | (747) |  |  | (799) |  |  | (2,244) |  |  | (2,056) |  |
| Acquisition of businesses and assets, net | — |  |  | — |  |  | — |  |  | (16) |  |
| Divestitures of businesses and assets, net | — |  |  | 3,957 |  |  | — |  |  | 3,957 |  |
| Other | 7 |  |  | 14 |  |  | 18 |  |  | 34 |  |
| Change in cash from investing activities | (730) |  |  | 3,241 |  |  | (2,228) |  |  | 2,053 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |
| Proceeds from the issuance of common stock | — |  |  | 140 |  |  | 5 |  |  | 326 |  |
| Repurchases of parent common stock (a) | (622) |  |  | (18) |  |  | (3,090) |  |  | (35) |  |
| Repurchases of subsidiary common stock (a) | — |  |  | (196) |  |  | (8) |  |  | (1,174) |  |
| Payments of dividends to stockholders | (238) |  |  | — |  |  | (728) |  |  | — |  |
| Proceeds from debt | 2,314 |  |  | 9,102 |  |  | 8,779 |  |  | 13,037 |  |
| Repayments of debt | (1,837) |  |  | (4,646) |  |  | (8,079) |  |  | (13,069) |  |
| Debt-related costs and other, net | (3) |  |  | (99) |  |  | (17) |  |  | (113) |  |
| Change in cash from financing activities | (386) |  |  | 4,283 |  |  | (3,138) |  |  | (1,028) |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash | (149) |  |  | (33) |  |  | (343) |  |  | (54) |  |
| Change in cash, cash equivalents, and restricted cash | (869) |  |  | 10,742 |  |  | (4,858) |  |  | 8,185 |  |
| Cash, cash equivalents, and restricted cash at beginning of the period, including cash attributable to discontinued operations | 6,093 |  |  | 12,627 |  |  | 10,082 |  |  | 15,184 |  |
| Cash, cash equivalents, and restricted cash at end of the period, including cash attributable to discontinued operations | 5,224 |  |  | 23,369 |  |  | 5,224 |  |  | 23,369 |  |
| Less: Cash, cash equivalents, and restricted cash attributable to discontinued operations | — |  |  | 12,553 |  |  | — |  |  | 12,553 |  |
| Cash, cash equivalents, and restricted cash from continuing operations | $ | 5,224 |  |  | $ | 10,816 |  |  | $ | 5,224 |  |  | $ | 10,816 |  |

[0001571996-22-000041:8k_2_02:77]
_________________

[0001571996-22-000041:8k_2_02:78]
(a)Common stock repurchases are inclusive of employee tax withholding on stock-based compensation.

[0001571996-22-000041:8k_2_02:79]
8

[0001571996-22-000041:8k_2_02:80]
DELL TECHNOLOGIES INC.

[0001571996-22-000041:8k_2_02:81]
Segment Information

[0001571996-22-000041:8k_2_02:82]
(in millions, except percentages; unaudited; continued on next page)

[0001571996-22-000041:8k_2_02:83]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | October 28, 2022 |  | October 29, 2021 |  | Change |  | October 28, 2022 |  | October 29, 2021 |  | Change |
| Infrastructure Solutions Group (ISG): |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Servers and networking | $ | 5,201 |  | $ | 4,561 |  | 14% |  | $ | 15,458 |  | $ | 13,181 |  | 17% |
| Storage | 4,429 |  | 4,003 |  | 11% |  | 12,993 |  | 11,966 |  | 9% |
| Total ISG net revenue | $ | 9,630 |  | $ | 8,564 |  | 12% |  | $ | 28,451 |  | $ | 25,147 |  | 13% |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| ISG operating income | $ | 1,374 |  | $ | 894 |  | 54% |  | $ | 3,502 |  | $ | 2,634 |  | 33% |
| % of ISG net revenue | 14.3 | % |  | 10.4 | % |  |  |  | 12.3 | % |  | 10.5 | % |  |  |
| % of total reportable segment operating income | 56 | % |  | 44 | % |  |  |  | 53 | % |  | 45 | % |  |  |
| Client Solutions Group (CSG): |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 10,747 |  | $ | 12,300 |  | (13)% |  | $ | 34,859 |  | $ | 32,685 |  | 7% |
| Consumer | 3,028 |  | 4,256 |  | (29)% |  | 9,993 |  | 11,450 |  | (13)% |
| Total CSG net revenue | $ | 13,775 |  | $ | 16,556 |  | (17)% |  | $ | 44,852 |  | $ | 44,135 |  | 2% |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| CSG operating income | $ | 1,060 |  | $ | 1,142 |  | (7)% |  | $ | 3,153 |  | $ | 3,208 |  | (2)% |
| % of CSG net revenue | 7.7 | % |  | 6.9 | % |  |  |  | 7.0 | % |  | 7.3 | % |  |  |
| % of total reportable segment operating income | 44 | % |  | 56 | % |  |  |  | 47 | % |  | 55 | % |  |  |

[0001571996-22-000041:8k_2_02:84]
Amounts are based on underlying data and may not visually foot due to rounding.

[0001571996-22-000041:8k_2_02:85]
9

[0001571996-22-000041:8k_2_02:86]
DELL TECHNOLOGIES INC.

[0001571996-22-000041:8k_2_02:87]
Segment Information

[0001571996-22-000041:8k_2_02:88]
(in millions, except percentages; unaudited; continued)

[0001571996-22-000041:8k_2_02:89]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 28, 2022 |  | October 29, 2021 |  | October 28, 2022 |  | October 29, 2021 |
| Reconciliation to consolidated net revenue: |  |  |  |  |  |  |
| Reportable segment net revenue | $ | 23,405 |  |  | $ | 25,120 |  |  | $ | 73,303 |  |  | $ | 69,282 |  |
| Other businesses (a) | 1,313 |  |  | 1,310 |  |  | 3,951 |  |  | 3,940 |  |
| Unallocated transactions (b) | 3 |  |  | 2 |  |  | 8 |  |  | 7 |  |
| Impact of purchase accounting (c) | — |  |  | (8) |  |  | — |  |  | (24) |  |
| Total consolidated net revenue | $ | 24,721 |  |  | $ | 26,424 |  |  | $ | 77,262 |  |  | $ | 73,205 |  |
| Reconciliation to consolidated operating income: |  |  |  |  |  |  |  |
| Reportable segment operating income | $ | 2,434 |  |  | $ | 2,036 |  |  | $ | 6,655 |  |  | $ | 5,842 |  |
| Other businesses (a) | (57) |  |  | (81) |  |  | (192) |  |  | (248) |  |
| Unallocated transactions (b) | 3 |  |  | 1 |  |  | 4 |  |  | — |  |
| Impact of purchase accounting (c) | (21) |  |  | (12) |  |  | (33) |  |  | (47) |  |
| Amortization of intangibles | (245) |  |  | (431) |  |  | (732) |  |  | (1,318) |  |
| Transaction-related expenses (d) | (8) |  |  | (229) |  |  | (16) |  |  | (295) |  |
| Stock-based compensation expense (e) | (235) |  |  | (214) |  |  | (703) |  |  | (592) |  |
| Other corporate expenses (f) | (109) |  |  | (24) |  |  | (401) |  |  | (292) |  |
| Total consolidated operating income | $ | 1,762 |  |  | $ | 1,046 |  |  | $ | 4,582 |  |  | $ | 3,050 |  |

[0001571996-22-000041:8k_2_02:90]
_________________

[0001571996-22-000041:8k_2_02:91]
(a)Other businesses consists of: 1) Dell’s resale of standalone VMware, Inc. products and services, “VMware Resale,” 2) Secureworks, and 3) Virtustream, and do not meet the requirements for a reportable segment, either individually or collectively.

[0001571996-22-000041:8k_2_02:92]
(b)Unallocated transactions includes other corporate items that are not allocated to Dell Technologies’ reportable segments.

[0001571996-22-000041:8k_2_02:93]
(c)Impact of purchase accounting includes non-cash purchase accounting adjustments that are primarily related to the EMC merger transaction.

[0001571996-22-000041:8k_2_02:94]
(d)Transaction-related expenses includes acquisition, integration, and divestiture related costs.

[0001571996-22-000041:8k_2_02:95]
(e)Stock-based compensation expense consists of equity awards granted based on the estimated fair value of those awards at grant date.

[0001571996-22-000041:8k_2_02:96]
(f)Other corporate expenses includes impairment charges, incentive charges related to equity investments, severance, payroll taxes associated with stock-based compensation, facilities action, and other costs. During the nine months ended October 28, 2022, other corporate expenses includes impairment and other costs incurred in connection with exiting the Company’s business in Russia.

[0001571996-22-000041:8k_2_02:97]
SUPPLEMENTAL SELECTED NON-GAAP FINANCIAL MEASURES

[0001571996-22-000041:8k_2_02:98]
These tables present information about the Company’s non-GAAP net revenue, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, non-GAAP net income attributable to Dell Technologies Inc. - basic and diluted, non-GAAP earnings per share attributable to Dell Technologies Inc. - basic, and non-GAAP earnings per share attributable to Dell Technologies Inc. - diluted, which are non-GAAP financial measures provided as a supplement to the results provided in accordance with generally accepted accounting principles in the United States of America (“GAAP”). A detailed discussion of Dell Technologies’ reasons for including these non-GAAP financial measures, the limitations associated with these measures, the items excluded from these measures, and our reason for excluding those items are presented in “Management’s Discussion and Analysis of Financial Condition and Results of Operations — Non-GAAP Financial Measures” in our periodic reports filed with the SEC. Dell Technologies encourages investors to review the non-GAAP discussion in these reports in conjunction with the presentation of non-GAAP financial measures.

[0001571996-22-000041:8k_2_02:99]
11

[0001571996-22-000041:8k_2_02:100]
DELL TECHNOLOGIES INC.

[0001571996-22-000041:8k_2_02:101]
Selected Non-GAAP Financial Measures

[0001571996-22-000041:8k_2_02:102]
(in millions, except per share amounts and percentages; unaudited)

[0001571996-22-000041:8k_2_02:103]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | October 28, 2022 |  | October 29, 2021 |  | Change |  | October 28, 2022 |  | October 29, 2021 |  | Change |
| Non-GAAP net revenue | $ | 24,721 |  | $ | 26,432 |  | (6)% |  | $ | 77,262 |  | $ | 73,229 |  | 6% |
| Non-GAAP gross margin | $ | 5,865 |  | $ | 5,729 |  | 2% |  | $ | 17,456 |  | $ | 16,866 |  | 3% |
| % of non-GAAP net revenue | 23.7 | % |  | 21.7 | % |  |  |  | 22.6 | % |  | 23.0 | % |  |  |
| Non-GAAP operating expenses | $ | 3,485 |  | $ | 3,773 |  | (8)% |  | $ | 10,989 |  | $ | 11,272 |  | (3)% |
| % of non-GAAP net revenue | 14.1 | % |  | 14.3 | % |  |  |  | 14.2 | % |  | 15.4 | % |  |  |
| Non-GAAP operating income | $ | 2,380 |  | $ | 1,956 |  | 22% |  | $ | 6,467 |  | $ | 5,594 |  | 16% |
| % of non-GAAP net revenue | 9.6 | % |  | 7.4 | % |  |  |  | 8.4 | % |  | 7.6 | % |  |  |
| Non-GAAP net income | $ | 1,705 |  | $ | 1,313 |  | 30% |  | $ | 4,405 |  | $ | 3,534 |  | 25% |
| % of non-GAAP net revenue | 6.9 | % |  | 5.0 | % |  |  |  | 5.7 | % |  | 4.8 | % |  |  |
| Non-GAAP earnings per share - diluted | $ | 2.30 |  | $ | 1.66 |  | 39% |  | $ | 5.81 |  | $ | 4.50 |  | 29% |

[0001571996-22-000041:8k_2_02:104]
Amounts are based on underlying data and may not visually foot due to rounding.

[0001571996-22-000041:8k_2_02:105]
12

[0001571996-22-000041:8k_2_02:106]
DELL TECHNOLOGIES INC.

[0001571996-22-000041:8k_2_02:107]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-22-000041:8k_2_02:108]
(in millions, except percentages; unaudited; continued on next page)

[0001571996-22-000041:8k_2_02:109]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | October 28, 2022 |  | October 29, 2021 |  | Change |  | October 28, 2022 |  | October 29, 2021 |  | Change |
| Net revenue | $ | 24,721 |  |  | $ | 26,424 |  |  | (6)% |  | $ | 77,262 |  |  | $ | 73,205 |  |  | 6% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | — |  |  | 8 |  |  |  |  | — |  |  | 24 |  |  |  |
| Non-GAAP net revenue | $ | 24,721 |  |  | $ | 26,432 |  |  | (6)% |  | $ | 77,262 |  |  | $ | 73,229 |  |  | 6% |
| Gross margin | $ | 5,707 |  |  | $ | 5,534 |  |  | 3% |  | $ | 16,930 |  |  | $ | 16,273 |  |  | 4% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 106 |  |  | 148 |  |  |  |  | 315 |  |  | 448 |  |  |  |
| Impact of purchase accounting | — |  |  | 9 |  |  |  |  | 2 |  |  | 27 |  |  |  |
| Stock-based compensation expense | 37 |  |  | 36 |  |  |  |  | 112 |  |  | 96 |  |  |  |
| Other corporate expenses | 15 |  |  | 2 |  |  |  |  | 97 |  |  | 22 |  |  |  |
| Non-GAAP gross margin | $ | 5,865 |  |  | $ | 5,729 |  |  | 2% |  | $ | 17,456 |  |  | $ | 16,866 |  |  | 3% |
| Operating expenses | $ | 3,945 |  |  | $ | 4,488 |  |  | (12)% |  | $ | 12,348 |  |  | $ | 13,223 |  |  | (7)% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | (139) |  |  | (283) |  |  |  |  | (417) |  |  | (870) |  |  |  |
| Impact of purchase accounting | (21) |  |  | (3) |  |  |  |  | (31) |  |  | (20) |  |  |  |
| Transaction-related expenses | (8) |  |  | (229) |  |  |  |  | (16) |  |  | (295) |  |  |  |
| Stock-based compensation expense | (198) |  |  | (178) |  |  |  |  | (591) |  |  | (496) |  |  |  |
| Other corporate expenses | (94) |  |  | (22) |  |  |  |  | (304) |  |  | (270) |  |  |  |
| Non-GAAP operating expenses | $ | 3,485 |  |  | $ | 3,773 |  |  | (8)% |  | $ | 10,989 |  |  | $ | 11,272 |  |  | (3)% |
| Operating income | $ | 1,762 |  |  | $ | 1,046 |  |  | 68% |  | $ | 4,582 |  |  | $ | 3,050 |  |  | 50% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 245 |  |  | 431 |  |  |  |  | 732 |  |  | 1,318 |  |  |  |
| Impact of purchase accounting | 21 |  |  | 12 |  |  |  |  | 33 |  |  | 47 |  |  |  |
| Transaction-related expenses | 8 |  |  | 229 |  |  |  |  | 16 |  |  | 295 |  |  |  |
| Stock-based compensation expense | 235 |  |  | 214 |  |  |  |  | 703 |  |  | 592 |  |  |  |
| Other corporate expenses | 109 |  |  | 24 |  |  |  |  | 401 |  |  | 292 |  |  |  |
| Non-GAAP operating income | $ | 2,380 |  |  | $ | 1,956 |  |  | 22% |  | $ | 6,467 |  |  | $ | 5,594 |  |  | 16% |

[0001571996-22-000041:8k_2_02:110]
13

[0001571996-22-000041:8k_2_02:111]
DELL TECHNOLOGIES INC.

[0001571996-22-000041:8k_2_02:112]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-22-000041:8k_2_02:113]
(in millions, except percentages; unaudited; continued)

[0001571996-22-000041:8k_2_02:114]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | October 28, 2022 |  | October 29, 2021 |  | Change |  | October 28, 2022 |  | October 29, 2021 |  | Change |
| Net income from continuing operations | $ | 241 |  |  | $ | 3,683 |  |  | (93)% |  | $ | 1,816 |  |  | $ | 4,971 |  |  | (63)% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 245 |  |  | 431 |  |  |  |  | 732 |  |  | 1,318 |  |  |  |
| Impact of purchase accounting | 21 |  |  | 12 |  |  |  |  | 33 |  |  | 47 |  |  |  |
| Transaction-related (income) expenses | 4 |  |  | (3,689) |  |  |  |  | (2) |  |  | (3,635) |  |  |  |
| Stock-based compensation expense | 235 |  |  | 214 |  |  |  |  | 703 |  |  | 592 |  |  |  |
| Other corporate expenses | 1,112 |  |  | 24 |  |  |  |  | 1,420 |  |  | 292 |  |  |  |
| Fair value adjustments on equity investments | (44) |  |  | (18) |  |  |  |  | 197 |  |  | (380) |  |  |  |
| Aggregate adjustment for income taxes | (109) |  |  | 656 |  |  |  |  | (494) |  |  | 329 |  |  |  |
| Non-GAAP net income | $ | 1,705 |  |  | $ | 1,313 |  |  | 30% |  | $ | 4,405 |  |  | $ | 3,534 |  |  | 25% |
| Net income from continuing operations attributable to Dell Technologies Inc. | $ | 245 |  |  | $ | 3,685 |  |  | (93)% |  | $ | 1,828 |  |  | $ | 4,976 |  |  | (63)% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 245 |  |  | 431 |  |  |  |  | 732 |  |  | 1,318 |  |  |  |
| Impact of purchase accounting | 21 |  |  | 12 |  |  |  |  | 33 |  |  | 47 |  |  |  |
| Transaction-related (income) expenses | 4 |  |  | (3,689) |  |  |  |  | (2) |  |  | (3,635) |  |  |  |
| Stock-based compensation expense | 235 |  |  | 214 |  |  |  |  | 703 |  |  | 592 |  |  |  |
| Other corporate expenses | 1,112 |  |  | 24 |  |  |  |  | 1,420 |  |  | 292 |  |  |  |
| Fair value adjustments on equity investments | (44) |  |  | (18) |  |  |  |  | 197 |  |  | (380) |  |  |  |
| Aggregate adjustment for income taxes | (109) |  |  | 656 |  |  |  |  | (494) |  |  | 329 |  |  |  |
| Total non-GAAP adjustments attributable to non-controlling interests | (2) |  |  | (3) |  |  |  |  | (7) |  |  | (6) |  |  |  |
| Non-GAAP net income attributable to Dell Technologies Inc. | $ | 1,707 |  |  | $ | 1,312 |  |  | 30% |  | $ | 4,410 |  |  | $ | 3,533 |  |  | 25% |

[0001571996-22-000041:8k_2_02:115]
14

[0001571996-22-000041:8k_2_02:116]
DELL TECHNOLOGIES INC.

[0001571996-22-000041:8k_2_02:117]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-22-000041:8k_2_02:118]
(in millions, except percentages and per share amounts; unaudited; continued)

[0001571996-22-000041:8k_2_02:119]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | October 28, 2022 |  | October 29, 2021 |  | Change |  | October 28, 2022 |  | October 29, 2021 |  | Change |
| Earnings per share from continuing operations attributable to Dell Technologies Inc. |  |  |  |  |
| Net income from continuing operations attributable to Dell Technologies Inc. — basic | $ | 245 |  |  | $ | 3,685 |  |  |  |  | $ | 1,828 |  |  | $ | 4,976 |  |  |  |
| Weighted-average shares outstanding — basic | 728 |  |  | 766 |  |  |  |  | 740 |  |  | 762 |  |  |  |
| Earnings per share attributable to Dell Technologies Inc. — basic | $ | 0.34 |  |  | $ | 4.81 |  |  | (93)% |  | $ | 2.47 |  |  | $ | 6.53 |  |  | (62)% |
| Net income from continuing operations attributable to Dell Technologies Inc. — diluted | $ | 245 |  |  | $ | 3,685 |  |  |  |  | $ | 1,828 |  |  | $ | 4,976 |  |  |  |
| Weighted-average shares outstanding — diluted | 743 |  |  | 788 |  |  |  |  | 759 |  |  | 785 |  |  |  |
| Earnings per share attributable to Dell Technologies Inc. — diluted | $ | 0.33 |  |  | $ | 4.68 |  |  | (93)% |  | $ | 2.41 |  |  | $ | 6.34 |  |  | (62)% |
| Earnings per share from discontinued operations attributable to Dell Technologies Inc. |  |  |  |  |
| Net income from discontinued operations attributable to Dell Technologies Inc. — basic | $ | — |  |  | $ | 158 |  |  |  |  | $ | — |  |  | $ | 585 |  |  |  |
| Weighted-average shares outstanding — basic | — |  |  | 766 |  |  |  |  | — |  |  | 762 |  |  |  |
| Earnings per share attributable to Dell Technologies Inc. — basic | $ | — |  |  | $ | 0.21 |  |  | NM |  | $ | — |  |  | $ | 0.77 |  |  | NM |
| Incremental dilution from VMware, Inc. attributable to Dell Technologies | — |  |  | (2) |  |  |  |  | — |  |  | (7) |  |  |  |
| Net income from discontinued operations attributable to Dell Technologies Inc. — diluted | $ | — |  |  | $ | 156 |  |  |  |  | $ | — |  |  | $ | 578 |  |  |  |
| Weighted-average shares outstanding — diluted | — |  |  | 788 |  |  |  |  | — |  |  | 785 |  |  |  |
| Earnings per share attributable to Dell Technologies Inc. — diluted | $ | — |  |  | $ | 0.19 |  |  | NM |  | $ | — |  |  | $ | 0.74 |  |  | NM |
| Non-GAAP earnings per share attributable to Dell Technologies Inc. |  |  |
| Non-GAAP net income attributable to Dell Technologies Inc. — basic | $ | 1,707 |  |  | $ | 1,312 |  |  |  |  | $ | 4,410 |  |  | $ | 3,533 |  |  |  |
| Weighted-average shares outstanding — basic | 728 |  |  | 766 |  |  |  |  | 740 |  |  | 762 |  |  |  |
| Earnings per share attributable to Dell Technologies Inc. — basic | $ | 2.34 |  |  | $ | 1.71 |  |  | 37% |  | $ | 5.96 |  |  | $ | 4.64 |  |  | 28% |
| Non-GAAP net income attributable to Dell Technologies Inc. — diluted | $ | 1,707 |  |  | $ | 1,312 |  |  |  |  | $ | 4,410 |  |  | $ | 3,533 |  |  |  |
| Weighted-average shares outstanding — diluted | 743 |  |  | 788 |  |  |  |  | 759 |  |  | 785 |  |  |  |
| Earnings per share attributable to Dell Technologies Inc. — diluted | $ | 2.30 |  |  | $ | 1.66 |  |  | 39% |  | $ | 5.81 |  |  | $ | 4.50 |  |  | 29% |

[0001571996-22-000041:8k_2_02:120]
Amounts may not visually recalculate due to rounding.

[0001571996-22-000041:8k_2_02:121]
15
