# DELL MD&A — 0001571996-22-000044


## mdna

[0001571996-22-000044:mdna:1]
[same as prior period, unchanged from 0001571996-22-000031:mdna:1]

[0001571996-22-000044:mdna:2]
[same as prior period, unchanged from 0001571996-22-000031:mdna:2]

[0001571996-22-000044:mdna:3]
[same as prior period, unchanged from 0001571996-22-000031:mdna:3]

[0001571996-22-000044:mdna:4]
On November 1, 2021, the Company completed its spin-off of VMware, Inc. (individually and together with its consolidated subsidiaries, “VMware”).  In accordance with applicable accounting guidance, the results of VMware, excluding Dell's resale of VMware offerings, are presented as discontinued operations in the Condensed Consolidated Statements of Income and, as such, have been excluded from both continuing operations and segment results for the three and nine months ended October 29, 2021.  The Condensed Consolidated Statements of Cash Flows are presented on a consolidated basis for both continuing operations and discontinued operations for the three and nine months ended October 29, 2021.

[0001571996-22-000044:mdna:5]
[same as prior period, unchanged from 0001571996-22-000031:mdna:5]

[0001571996-22-000044:mdna:6]
[same as prior period, unchanged from 0001571996-22-000031:mdna:6]

[0001571996-22-000044:mdna:7]
[same as prior period, unchanged from 0001571996-22-000031:mdna:7]

[0001571996-22-000044:mdna:8]
Dell Technologies helps organizations build their digital futures and individuals transform how they work, live and play.  We provide customers with one of the industry’s broadest and most innovative solutions portfolios for the data era, including traditional infrastructure and extending to multi-cloud environments.  We continue to seamlessly deliver differentiated and holistic IT solutions to our customers which has helped drive consistent revenue growth.

[0001571996-22-000044:mdna:9]
Dell Technologies’ integrated solutions help customers modernize their IT infrastructure, manage and operate in a multi-cloud world, address workforce transformation, and provide critical solutions that keep people and organizations connected.  We are helping customers accelerate their digital transformations to improve and strengthen business and workforce productivity.  With our extensive portfolio and our commitment to innovation, we offer secure, integrated solutions that extend from the edge to the core to the cloud, and we are at the forefront of the software-defined and cloud native infrastructure era.  As further evidence of our commitment to innovation, we are evolving and expanding our IT as-a-Service and cloud offerings including Dell APEX solutions which provide our customers with greater flexibility to scale IT to meet their evolving business needs and budgets.

[0001571996-22-000044:mdna:10]
[same as prior period, unchanged from 0001571996-22-000031:mdna:10]

[0001571996-22-000044:mdna:11]
[same as prior period, unchanged from 0001571996-22-000031:mdna:11]

[0001571996-22-000044:mdna:12]
[same as prior period, unchanged from 0001571996-22-000031:mdna:12]

[0001571996-22-000044:mdna:13]
[same as prior period, unchanged from 0001571996-22-000031:mdna:13]

[0001571996-22-000044:mdna:14]
[same as prior period, unchanged from 0001571996-22-000031:mdna:14]

[0001571996-22-000044:mdna:15]
[same as prior period, unchanged from 0001571996-22-000031:mdna:15]

[0001571996-22-000044:mdna:16]
We are seeing an accelerated rate of change in the IT industry and increased demand for simpler, more agile IT as companies leverage multiple clouds in their IT environments.  COVID-19 accelerated the introduction and adoption of new technologies to ensure productivity and collaboration from anywhere.  To meet our customer needs, we continue to invest in research and development, sales, and other key areas of our business to deliver superior products and solutions capabilities and to drive long-term sustainable growth.

[0001571996-22-000044:mdna:17]
[same as prior period, unchanged from 0001571996-22-000031:mdna:17]

[0001571996-22-000044:mdna:18]
[same as prior period, unchanged from 0001571996-22-000031:mdna:18]

[0001571996-22-000044:mdna:19]
[same as prior period, unchanged from 0001571996-22-000031:mdna:19]

[0001571996-22-000044:mdna:20]
[same as prior period, unchanged from 0001571996-22-000031:mdna:20]

[0001571996-22-000044:mdna:21]
[same as prior period, unchanged from 0001571996-22-000031:mdna:21]

[0001571996-22-000044:mdna:22]
[same as prior period, unchanged from 0001571996-22-000031:mdna:22]

[0001571996-22-000044:mdna:23]
[same as prior period, unchanged from 0001571996-22-000031:mdna:23]

[0001571996-22-000044:mdna:24]
[same as prior period, unchanged from 0001571996-22-000031:mdna:24]

[0001571996-22-000044:mdna:25]
•Client Solutions Group (“CSG”) — CSG includes branded hardware (such as desktops, workstations, and notebooks) and branded peripherals (such as displays, docking stations, and other electronics), as well as third-party software and peripherals.  CSG also includes services offerings, including support and deployment, configuration, and extended warranty services.  Our computing devices are designed with our commercial and consumer customers’ needs in mind, and we seek to optimize performance, reliability, manageability, design, and security.  For our customers that are seeking to simplify client lifecycle management, our Dell PC as-a-Service offering combines hardware, software, lifecycle services, and financing into one all-encompassing solution that provides predictable pricing per seat per month.

[0001571996-22-000044:mdna:26]
[same as prior period, unchanged from 0001571996-22-000031:mdna:26]

[0001571996-22-000044:mdna:27]
[same as prior period, unchanged from 0001571996-22-000031:mdna:27]

[0001571996-22-000044:mdna:28]
[same as prior period, unchanged from 0001571996-22-000031:mdna:28]

[0001571996-22-000044:mdna:29]
[same as prior period, unchanged from 0001571996-22-000031:mdna:29]

[0001571996-22-000044:mdna:30]
[same as prior period, unchanged from 0001571996-22-000031:mdna:30]

[0001571996-22-000044:mdna:31]
[same as prior period, unchanged from 0001571996-22-000031:mdna:31]

[0001571996-22-000044:mdna:32]
[same as prior period, unchanged from 0001571996-22-000031:mdna:32]

[0001571996-22-000044:mdna:33]
[same as prior period, unchanged from 0001571996-22-000031:mdna:33]

[0001571996-22-000044:mdna:34]
[same as prior period, unchanged from 0001571996-22-000031:mdna:34]

[0001571996-22-000044:mdna:35]
DFS supports our businesses by offering and arranging various financing options and services for our customers globally.  DFS originates, collects, and services customer receivables primarily related to the purchase or use of our product, software, and services solutions.  We also arrange financing for some of our customers in various countries where DFS does not currently operate as a captive entity.  We further strengthen customer relationships through flexible consumption models, including utility, subscription, and as-a-Service models, which enable us to offer our customers the option to pay over time to provide them with financial flexibility to meet their changing technological requirements.  We have historically seen an increasing interest in our various financing options during times of macroeconomic uncertainty.  The results of these operations are allocated to our segments based on the underlying product or service financed and may be impacted by, among other items, changes in the interest rate environment and the translation of those changes to pricing.  For additional information about our financing arrangements, see Note 5 of the Notes to the Condensed Consolidated Financial Statements included in this report.

[0001571996-22-000044:mdna:36]
[same as prior period, unchanged from 0001571996-22-000031:mdna:37]

[0001571996-22-000044:mdna:37]
[same as prior period, unchanged from 0001571996-22-000031:mdna:38]

[0001571996-22-000044:mdna:38]
[same as prior period, unchanged from 0001571996-22-000031:mdna:39]

[0001571996-22-000044:mdna:39]
The results of VMware, excluding Dell's resale of VMware offerings, are presented as discontinued operations in the Condensed Consolidated Statements of Income and, as such, have been excluded from both continuing operations and segment results for the three and nine months ended October 29, 2021.  The Condensed Consolidated Statements of Cash Flows are presented on a consolidated basis for both continuing operations and discontinued operations.  See Note 2 of the Notes to the Condensed Consolidated Financial Statements included in this report for additional information about the VMware Spin-off.

[0001571996-22-000044:mdna:40]
[same as prior period, unchanged from 0001571996-22-000031:mdna:41]

[0001571996-22-000044:mdna:41]
[same as prior period, unchanged from 0001571996-22-000031:mdna:42]

[0001571996-22-000044:mdna:42]
The Company is considered to be a related party of VMware as a result of Michael Dell’s ownership interests in both Dell Technologies and VMware and Mr. Dell’s continued service as Chairman and Chief Executive Officer of Dell Technologies and as Chairman of the Board of VMware, Inc.  Following the completion of the VMware Spin-off, the majority of transactions that occur between Dell Technologies and VMware consist of Dell Technologies’ purchase of VMware products and services for resale, either on a standalone basis or as a part of integrated offerings.  For more information regarding related party transactions with VMware, see Note 16 of the Notes to the Condensed Consolidated Financial Statements included in this report.

[0001571996-22-000044:mdna:43]
[same as prior period, unchanged from 0001571996-22-000031:mdna:44]

[0001571996-22-000044:mdna:44]
As part of our strategy, we will continue to evaluate opportunities for strategic investments through our venture capital investment arm, Dell Technologies Capital, with a focus on emerging technology areas that are relevant to all segments of our business and that will complement our existing portfolio of solutions.  Our investment areas include storage, software-defined networking, management and orchestration, security, machine learning and artificial intelligence, Big Data and analytics, cloud, edge computing, and software development operations.  The technologies or products these companies have under development are typically in the early stages and may never have commercial value, which could result in a loss of a substantial part of our investment in the companies.

[0001571996-22-000044:mdna:45]
During the first nine months of Fiscal 2023, we recognized a net loss of $197 million on our strategic investments, which was generally in line with overall public equity market declines.  As of October 28, 2022 and January 28, 2022, we held strategic investments in non-marketable securities of $1.3 billion and $1.4 billion, respectively.  See Note 4 of the Notes to the Condensed Consolidated Financial Statements included in this report for additional information.

[0001571996-22-000044:mdna:46]
[same as prior period, unchanged from 0001571996-22-000031:mdna:47]

[0001571996-22-000044:mdna:47]
[same as prior period, unchanged from 0001571996-22-000031:mdna:48]

[0001571996-22-000044:mdna:48]
Macroeconomic conditions continue to evolve globally and to affect the demand for our offerings.  During the third quarter of Fiscal 2023, we experienced a decline in the demand for our CSG offerings, which continued to decrease in line with industry-wide declines.  During the quarter, demand for our ISG offerings also declined, most notably for our server product offerings, as a result of customer uncertainty in response to the macroeconomic environment.  We anticipate that challenges in the demand environment will impact ISG net revenue growth for the remainder of Fiscal 2023.  Within CSG, we expect that demand for our offerings will result in a decrease in CSG net revenue for the remainder of Fiscal 2023.

[0001571996-22-000044:mdna:49]
We will continue to actively monitor global events and make prudent decisions to navigate this environment.  We believe our durable competitive advantages continue to position us for long-term success.

[0001571996-22-000044:mdna:50]
Supply Chain — Dell Technologies maintains limited-source supplier relationships for certain components because the relationships are advantageous in the areas of performance, quality, support, delivery, capacity, and price considerations.

[0001571996-22-000044:mdna:51]
During the first nine months of Fiscal 2023, we continued to be affected by industry-wide constraints in the supply of limited-source components in certain product offerings, principally within ISG.  These constraints began to diminish during the third quarter of Fiscal 2023, primarily as a result of declines in overall demand environment as well as improving supply positions.  We anticipate the supply of such components will continue to normalize through the remainder of Fiscal 2023 and as we enter Fiscal 2024.

[0001571996-22-000044:mdna:52]
Supply chain dynamics also continue to impact logistics and component costs, which we refer to as input costs.  Logistics costs remained elevated for the first nine months of Fiscal 2023 as a result of both expedited shipments and overall rate costs in the freight network.  During the third quarter of Fiscal 2023, logistics costs began to decline as rate costs decreased and we reduced our use of expedited shipments.  We expect that our logistics costs will continue to decline for the remainder of Fiscal 2023.

[0001571996-22-000044:mdna:53]
Component costs were deflationary during the third quarter and first nine months of Fiscal 2023, a trend we expect to continue for the remainder of Fiscal 2023.  We expect that industry-wide price increases of certain processors will affect our cost of net revenue beginning in Fiscal 2024.  We anticipate that costs of our other key commodities will remain deflationary as we enter Fiscal 2024.  Component cost trends are dependent on the strength or weakness of actual end-user demand and supply dynamics, which will continue to evolve and ultimately impact the translation of the cost environment to pricing and operating results.

[0001571996-22-000044:mdna:54]
[same as prior period, unchanged from 0001571996-22-000031:mdna:52]

[0001571996-22-000044:mdna:55]
Product Backlog — Product backlog represents the value of unfulfilled manufacturing orders and is included as a component of remaining performance obligations to the extent we determine that the manufacturing orders are non-cancelable.  Our business model generally gives us the ability to optimize product backlog at any point in time, such as by expediting shipping or prioritizing customer orders for products that have shorter lead times.  We exited Fiscal 2022 with elevated backlog levels as a result of industry-wide constraints in the supply of limited-source components.  During the first nine months of Fiscal 2023, we  lowered our backlog levels across both CSG and ISG as supply positions improved and demand declined.

[0001571996-22-000044:mdna:56]
Foreign Currency Exposure — We manage our business on a U.S. dollar basis.  However, we have a large global presence, generating approximately half of our net revenue from sales to customers outside of the United States during the third quarter and first nine months of Fiscal 2023 and Fiscal 2022.  As a result, our operating results can be, and particularly in recent periods have been, impacted by fluctuations in foreign currency exchange rates.  We utilize a comprehensive hedging strategy intended to mitigate the impact of foreign currency volatility over time, and we adjust pricing when possible to further minimize foreign currency impacts.

[0001571996-22-000044:mdna:57]
Ukraine War — We are monitoring and responding to effects of the ongoing war in Ukraine.  When Russia invaded Ukraine, we made the decision to not sell, service, or support products in Russia, Belarus, and restricted regions of Ukraine.  Operations in Russia and Ukraine accounted for less than 1% of net revenue in Fiscal 2022.  During the first nine months of Fiscal 2023, we recognized $181 million in costs associated with exiting our business in Russia, primarily related to asset impairments and other exit related costs.  We have resumed product sales to non-sanctioned areas in Ukraine.  We are focused on providing products and support to Ukrainian customers as they rebuild infrastructure and restore businesses and the financial sector.

[0001571996-22-000044:mdna:58]
62

[0001571996-22-000044:mdna:59]
The war and the related economic sanctions are impacting markets worldwide.  Our business may be adversely affected by potential effects of the war and such sanctions, including supply chain disruptions, product shipping delays, macroeconomic impacts resulting from the exclusion of Russian financial institutions from the global banking system, volatility in foreign exchange rates and interest rates, inflationary pressures, and heightened cybersecurity and data theft threats.  The full impact of the war on our business operations and financial performance will depend on future developments.  We will continue to monitor and assess the related restrictions and other effects and pursue prudent decisions for our team members, customers, and business.

[0001571996-22-000044:mdna:60]
[same as prior period, unchanged from 0001571996-22-000031:mdna:56]

[0001571996-22-000044:mdna:61]
Inflation Reduction Act — During the third quarter of Fiscal 2023, the Inflation Reduction Act of 2022 (the “2022 Act”) was enacted into law.  The statute includes a 15% corporate alternative minimum tax on adjusted financial statement income which is effective for the fiscal year ended February 2, 2024.  The new law also imposes a 1% excise tax on share repurchases, which will be effective for repurchases made after December 31, 2022.  We do not expect the 2022 Act to have a material impact on our consolidated financial statements or on our capital allocation decisions.  We will continue to evaluate the impact of the law as further information becomes available.

[0001571996-22-000044:mdna:62]
[same as prior period, unchanged from 0001571996-22-000031:mdna:58]

[0001571996-22-000044:mdna:63]
ISG — We expect that ISG will continue to be impacted by the changing nature of the IT infrastructure market and competitive environment.  With our scale and strong solutions portfolio, we believe we are well-positioned to respond to ongoing competitive dynamics.  Within our server and networking offerings, we will continue to be selective in determining whether to pursue certain large hyperscale and other server transactions.  We continue to focus on customer base expansion and lifetime value of customer relationships.

[0001571996-22-000044:mdna:64]
We expect that growth throughout industries will continue to generate long-term demand for our storage solutions and services.  Cloud native applications are expected to continue as a primary growth driver in the infrastructure market.  We benefit from offering solutions that address the emerging trends of enterprises deploying software-defined storage, hyper-converged infrastructure, and modular solutions based on server-centric architectures.  These trends are changing the way customers are consuming our traditional storage offerings.  We continue to expand our offerings in external storage arrays, which incorporate flexible, cloud-based functionality.

[0001571996-22-000044:mdna:65]
[same as prior period, unchanged from 0001571996-22-000031:mdna:61]

[0001571996-22-000044:mdna:66]
CSG — Our CSG offerings are an important element of our strategy, generating strong cash flow and opportunities for cross-selling of complementary solutions.  We are focused on commercial and high-end consumer computing devices as we believe they are the most stable and profitable segments of the PC market.  Competitive dynamics continue to be a factor in our CSG business and to impact pricing and operating results.  We remain committed to our long-term strategy for CSG and will continue to make investments to innovate across the portfolio while benefiting from consolidation trends that are occurring in the markets in which we compete. We expect that the CSG demand environment will continue to be subject to seasonal trends.

[0001571996-22-000044:mdna:67]
Recurring Revenue and Consumption Models — Our customers are seeking new and innovative models that address how they consume our solutions.  We offer options including as-a-Service, utility, leases, loans, and immediate pay models designed to match customers’ consumption and financing preferences.  We believe these options are particularly advantageous for our customers during times of economic uncertainty as they provide customers with financial flexibility to further enable them to procure our solutions.

[0001571996-22-000044:mdna:68]
We continue to evolve and build momentum across our family of as-a-Service offerings as we pursue our strategy of modernizing our core business solutions, with Dell APEX at the forefront.  We expect that our flexible consumption models and as-a-Service offerings will further strengthen our customer relationships and provide a foundation for growth in recurring revenue.

[0001571996-22-000044:mdna:69]
These offerings typically result in multiyear agreements which generate recurring revenue streams over the term of the arrangement.  We define recurring revenue as revenue recognized that is primarily related to hardware and software maintenance as well as subscription, as-a-Service, usage-based offerings, and operating leases.

[0001571996-22-000044:mdna:70]
[same as prior period, unchanged from 0001571996-22-000031:mdna:66]

[0001571996-22-000044:mdna:71]
[same as prior period, unchanged from 0001571996-22-000031:mdna:67]

[0001571996-22-000044:mdna:72]
[same as prior period, unchanged from 0001571996-22-000031:mdna:68]

[0001571996-22-000044:mdna:73]
[same as prior period, unchanged from 0001571996-22-000031:mdna:69]

[0001571996-22-000044:mdna:74]
[same as prior period, unchanged from 0001571996-22-000031:mdna:70]

[0001571996-22-000044:mdna:75]
Effective in the first quarter of Fiscal 2023, non-GAAP product net revenue, services net revenue, and net revenue no longer differ from the most comparable GAAP financial measures.  Such non-GAAP financial measures are provided below for all periods presented to show purchase accounting adjustments that impacted such financial measures in prior periods.

[0001571996-22-000044:mdna:76]
[same as prior period, unchanged from 0001571996-22-000031:mdna:72]

[0001571996-22-000044:mdna:77]
[same as prior period, unchanged from 0001571996-22-000031:mdna:73]

[0001571996-22-000044:mdna:78]
[same as prior period, unchanged from 0001571996-22-000031:mdna:74]

[0001571996-22-000044:mdna:79]
[same as prior period, unchanged from 0001571996-22-000031:mdna:75]

[0001571996-22-000044:mdna:80]
•Amortization of Intangible Assets — Amortization of intangible assets primarily consists of amortization of customer relationships, developed technology, and trade names.  In connection with our acquisition by merger of EMC on September 7, 2016, referred to as the “EMC merger transaction,” and the acquisition of Dell Inc. by Dell Technologies Inc. on October 29, 2013, referred to as the “going-private transaction,” all of the tangible and intangible assets and liabilities of EMC and Dell Inc. and its consolidated subsidiaries, respectively, were accounted for and recognized at fair value on the transaction dates.  Accordingly, for the periods presented, amortization of intangible assets represents amortization associated with intangible assets recognized in connection with the EMC merger transaction and the going-private transaction.  Amortization charges for purchased intangible assets are significantly impacted by the timing and magnitude of our acquisitions, and these charges may vary in amount from period to period.  We exclude these charges for purposes of calculating the non-GAAP financial measures presented below to facilitate an enhanced understanding of our current operating performance and provide more meaningful period to period comparisons.

[0001571996-22-000044:mdna:81]
•Impact of Purchase Accounting — The impact of purchase accounting includes purchase accounting adjustments related to the EMC merger transaction and, to a lesser extent, the going-private transaction, recorded under the acquisition method of accounting in accordance with the accounting guidance for business combinations.  Accordingly, all of the assets and liabilities acquired in such transactions were accounted for and recognized at fair value as of the respective transaction dates, and the fair value adjustments continue to amortize over the estimated useful lives in the periods following the transactions.  The fair value adjustments that are still amortizing primarily relate to property, plant, and equipment.  We believe that excluding the impact of purchase accounting for purposes of calculating the non-GAAP financial measures presented below facilitates an enhanced understanding of our current operating performance and provides more meaningful period to period comparisons.

[0001571996-22-000044:mdna:82]
•Transaction-related (income) Expenses — Transaction-related expenses typically consist of acquisition, integration, and divestiture related costs, as well as the costs incurred in the VMware Spin-off, and are expensed as incurred.  These expenses primarily represent costs for legal, banking, consulting, and advisory services.  From time to time, this category also may include transaction-related income related to divestitures of businesses or asset sales.  During the third quarter of Fiscal 2022, we recognized a pre-tax gain of $4.0 billion on the sale of Boomi.  We exclude these items for purposes of calculating the non-GAAP financial measures presented below to facilitate an enhanced understanding of our current operating performance and provide more meaningful period to period comparisons.

[0001571996-22-000044:mdna:83]
[same as prior period, unchanged from 0001571996-22-000031:mdna:79]

[0001571996-22-000044:mdna:84]
•Other Corporate Expenses — Other corporate expenses consist of impairment charges, incentive charges related to equity investments, severance, facility action, payroll taxes associated with stock-based compensation, and other costs.  During the third quarter of Fiscal 2023, we recognized $1.0 billion of expense within interest and other, net, in connection with an agreement to settle the Class V transaction litigation.  See Note 19 of the Notes to the Condensed Consolidated Financial Statements included in this report for information about this matter.  Further, during the first nine months of Fiscal 2023, we recognized $181 million in costs associated with exiting our business in Russia, primarily related to asset impairments and other exit related costs.  Severance costs are primarily related to severance and benefits for employees terminated pursuant to cost savings initiatives.  We continue to optimize our facilities footprint and may incur additional costs as we seek opportunities for operational efficiencies.  Other corporate expenses vary from period to period and are significantly impacted by the timing and nature of these events.  Therefore, although we may incur these types of expenses in the future, we believe that eliminating these charges for purposes of calculating the non-GAAP financial measures presented below facilitates an enhanced understanding of our current operating performance and provides more meaningful period to period comparisons.

[0001571996-22-000044:mdna:85]
[same as prior period, unchanged from 0001571996-22-000031:mdna:81]

[0001571996-22-000044:mdna:86]
[same as prior period, unchanged from 0001571996-22-000031:mdna:83]

[0001571996-22-000044:mdna:87]
[same as prior period, unchanged from 0001571996-22-000031:mdna:82]

[0001571996-22-000044:mdna:88]
[same as prior period, unchanged from 0001571996-22-000031:mdna:84]

[0001571996-22-000044:mdna:89]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 28,2022 |  | % Change |  | October 29,2021 |  | October 28,2022 |  | % Change |  | October 29,2021 |  |  |  |  |
|  | (in millions, except percentages) |
| Product net revenue | $ | 18,938 |  |  | (10) | % |  | $ | 20,979 |  |  | $ | 60,212 |  |  | 5 | % |  | $ | 57,361 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | — |  |  |  |  | — |  |  | — |  |  |  |  | — |  |  |  |  |  |
| Non-GAAP product net revenue | $ | 18,938 |  |  | (10) | % |  | $ | 20,979 |  |  | $ | 60,212 |  |  | 5 | % |  | $ | 57,361 |  |  |  |  |  |
| Services net revenue | $ | 5,783 |  |  | 6 | % |  | $ | 5,445 |  |  | $ | 17,050 |  |  | 8 | % |  | $ | 15,844 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | — |  |  |  |  | 8 |  |  | — |  |  |  |  | 24 |  |  |  |  |  |
| Non-GAAP services net revenue | $ | 5,783 |  |  | 6 | % |  | $ | 5,453 |  |  | $ | 17,050 |  |  | 7 | % |  | $ | 15,868 |  |  |  |  |  |
| Net revenue | $ | 24,721 |  |  | (6) | % |  | $ | 26,424 |  |  | $ | 77,262 |  |  | 6 | % |  | $ | 73,205 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | — |  |  |  |  | 8 |  |  | — |  |  |  |  | 24 |  |  |  |  |  |
| Non-GAAP net revenue | $ | 24,721 |  |  | (6) | % |  | $ | 26,432 |  |  | $ | 77,262 |  |  | 6 | % |  | $ | 73,229 |  |  |  |  |  |
| Product gross margin | $ | 3,337 |  |  | 6 | % |  | $ | 3,146 |  |  | $ | 9,931 |  |  | 6 | % |  | $ | 9,402 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 106 |  |  |  |  | 148 |  |  | 315 |  |  |  |  | 448 |  |  |  |  |  |
| Impact of purchase accounting | — |  |  |  |  | 1 |  |  | 2 |  |  |  |  | 3 |  |  |  |  |  |
| Stock-based compensation expense | 12 |  |  |  |  | 14 |  |  | 38 |  |  |  |  | 34 |  |  |  |  |  |
| Other corporate expenses | (2) |  |  |  |  | 1 |  |  | 14 |  |  |  |  | 5 |  |  |  |  |  |
| Non-GAAP product gross margin | $ | 3,453 |  |  | 4 | % |  | $ | 3,310 |  |  | $ | 10,300 |  |  | 4 | % |  | $ | 9,892 |  |  |  |  |  |
| Services gross margin | $ | 2,370 |  |  | (1) | % |  | $ | 2,388 |  |  | $ | 6,999 |  |  | 2 | % |  | $ | 6,871 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | — |  |  |  |  | 8 |  |  | — |  |  |  |  | 24 |  |  |  |  |  |
| Stock-based compensation expense | 25 |  |  |  |  | 22 |  |  | 74 |  |  |  |  | 62 |  |  |  |  |  |
| Other corporate expenses | 17 |  |  |  |  | 1 |  |  | 83 |  |  |  |  | 17 |  |  |  |  |  |
| Non-GAAP services gross margin | $ | 2,412 |  |  | — | % |  | $ | 2,419 |  |  | $ | 7,156 |  |  | 3 | % |  | $ | 6,974 |  |  |  |  |  |

[0001571996-22-000044:mdna:90]
[same as prior period, unchanged from 0001571996-22-000031:mdna:88]

[0001571996-22-000044:mdna:91]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 28,2022 |  | % Change |  | October 29,2021 |  | October 28,2022 |  | % Change |  | October 29,2021 |  |  |  |  |
|  | (in millions, except percentages) |
| Gross margin | $ | 5,707 |  |  | 3 | % |  | $ | 5,534 |  |  | $ | 16,930 |  |  | 4 | % |  | $ | 16,273 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 106 |  |  |  |  | 148 |  |  | 315 |  |  |  |  | 448 |  |  |  |  |  |
| Impact of purchase accounting | — |  |  |  |  | 9 |  |  | 2 |  |  |  |  | 27 |  |  |  |  |  |
| Stock-based compensation expense | 37 |  |  |  |  | 36 |  |  | 112 |  |  |  |  | 96 |  |  |  |  |  |
| Other corporate expenses | 15 |  |  |  |  | 2 |  |  | 97 |  |  |  |  | 22 |  |  |  |  |  |
| Non-GAAP gross margin | $ | 5,865 |  |  | 2 | % |  | $ | 5,729 |  |  | $ | 17,456 |  |  | 3 | % |  | $ | 16,866 |  |  |  |  |  |
| Operating expenses | $ | 3,945 |  |  | (12) | % |  | $ | 4,488 |  |  | $ | 12,348 |  |  | (7) | % |  | $ | 13,223 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | (139) |  |  |  |  | (283) |  |  | (417) |  |  |  |  | (870) |  |  |  |  |  |
| Impact of purchase accounting | (21) |  |  |  |  | (3) |  |  | (31) |  |  |  |  | (20) |  |  |  |  |  |
| Transaction-related expenses | (8) |  |  |  |  | (229) |  |  | (16) |  |  |  |  | (295) |  |  |  |  |  |
| Stock-based compensation expense | (198) |  |  |  |  | (178) |  |  | (591) |  |  |  |  | (496) |  |  |  |  |  |
| Other corporate expenses | (94) |  |  |  |  | (22) |  |  | (304) |  |  |  |  | (270) |  |  |  |  |  |
| Non-GAAP operating expenses | $ | 3,485 |  |  | (8) | % |  | $ | 3,773 |  |  | $ | 10,989 |  |  | (3) | % |  | $ | 11,272 |  |  |  |  |  |
| Operating income | $ | 1,762 |  |  | 68 | % |  | $ | 1,046 |  |  | $ | 4,582 |  |  | 50 | % |  | $ | 3,050 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 245 |  |  |  |  | 431 |  |  | 732 |  |  |  |  | 1,318 |  |  |  |  |  |
| Impact of purchase accounting | 21 |  |  |  |  | 12 |  |  | 33 |  |  |  |  | 47 |  |  |  |  |  |
| Transaction-related expenses | 8 |  |  |  |  | 229 |  |  | 16 |  |  |  |  | 295 |  |  |  |  |  |
| Stock-based compensation expense | 235 |  |  |  |  | 214 |  |  | 703 |  |  |  |  | 592 |  |  |  |  |  |
| Other corporate expenses | 109 |  |  |  |  | 24 |  |  | 401 |  |  |  |  | 292 |  |  |  |  |  |
| Non-GAAP operating income | $ | 2,380 |  |  | 22 | % |  | $ | 1,956 |  |  | $ | 6,467 |  |  | 16 | % |  | $ | 5,594 |  |  |  |  |  |
| Net income from continuing operations | $ | 241 |  |  | (93) | % |  | $ | 3,683 |  |  | $ | 1,816 |  |  | (63) | % |  | $ | 4,971 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 245 |  |  |  |  | 431 |  |  | 732 |  |  |  |  | 1,318 |  |  |  |  |  |
| Impact of purchase accounting | 21 |  |  |  |  | 12 |  |  | 33 |  |  |  |  | 47 |  |  |  |  |  |
| Transaction-related (income) expenses | 4 |  |  |  |  | (3,689) |  |  | (2) |  |  |  |  | (3,635) |  |  |  |  |  |
| Stock-based compensation expense | 235 |  |  |  |  | 214 |  |  | 703 |  |  |  |  | 592 |  |  |  |  |  |
| Other corporate expenses | 1,112 |  |  |  |  | 24 |  |  | 1,420 |  |  |  |  | 292 |  |  |  |  |  |
| Fair value adjustments on equity investments | (44) |  |  |  |  | (18) |  |  | 197 |  |  |  |  | (380) |  |  |  |  |  |
| Aggregate adjustment for income taxes | (109) |  |  |  |  | 656 |  |  | (494) |  |  |  |  | 329 |  |  |  |  |  |
| Non-GAAP net income | $ | 1,705 |  |  | 30 | % |  | $ | 1,313 |  |  | $ | 4,405 |  |  | 25 | % |  | $ | 3,534 |  |  |  |  |  |

[0001571996-22-000044:mdna:92]
[same as prior period, unchanged from 0001571996-22-000031:mdna:89]

[0001571996-22-000044:mdna:93]
[same as prior period, unchanged from 0001571996-22-000031:mdna:98]

[0001571996-22-000044:mdna:94]
[same as prior period, unchanged from 0001571996-22-000031:mdna:90]

[0001571996-22-000044:mdna:95]
[same as prior period, unchanged from 0001571996-22-000031:mdna:91]

[0001571996-22-000044:mdna:96]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 28,2022 |  | % Change |  | October 29,2021 |  | October 28,2022 |  | % Change |  | October 29,2021 |  |  |  |  |
|  | (in millions, except percentages) |
| Net income from continuing operations | $ | 241 |  |  | (93) | % |  | $ | 3,683 |  |  | $ | 1,816 |  |  | (63) | % |  | $ | 4,971 |  |  |  |  |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest and other, net (a) | 1,308 |  |  |  |  | (3,501) |  |  | 2,280 |  |  |  |  | (2,921) |  |  |  |  |  |
| Income tax expense (benefit) | 213 |  |  |  |  | 864 |  |  | 486 |  |  |  |  | 1,000 |  |  |  |  |  |
| Depreciation and amortization | 832 |  |  |  |  | 908 |  |  | 2,302 |  |  |  |  | 2,717 |  |  |  |  |  |
| EBITDA | $ | 2,594 |  |  | 33 | % |  | $ | 1,954 |  |  | $ | 6,884 |  |  | 19 | % |  | $ | 5,767 |  |  |  |  |  |
| EBITDA | $ | 2,594 |  |  | 33 | % |  | $ | 1,954 |  |  | $ | 6,884 |  |  | 19 | % |  | $ | 5,767 |  |  |  |  |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense | 235 |  |  |  |  | 214 |  |  | 703 |  |  |  |  | 592 |  |  |  |  |  |
| Impact of purchase accounting (b) | — |  |  |  |  | 8 |  |  | — |  |  |  |  | 28 |  |  |  |  |  |
| Transaction-related expenses (c) | 8 |  |  |  |  | 229 |  |  | 16 |  |  |  |  | 295 |  |  |  |  |  |
| Other corporate expenses (d) | 109 |  |  |  |  | 24 |  |  | 401 |  |  |  |  | 292 |  |  |  |  |  |
| Adjusted EBITDA | $ | 2,946 |  |  | 21 | % |  | $ | 2,429 |  |  | $ | 8,004 |  |  | 15 | % |  | $ | 6,974 |  |  |  |  |  |

[0001571996-22-000044:mdna:97]
[same as prior period, unchanged from 0001571996-22-000031:mdna:93]

[0001571996-22-000044:mdna:98]
[same as prior period, unchanged from 0001571996-22-000031:mdna:94]

[0001571996-22-000044:mdna:99]
[same as prior period, unchanged from 0001571996-22-000031:mdna:95]

[0001571996-22-000044:mdna:100]
[same as prior period, unchanged from 0001571996-22-000031:mdna:96]

[0001571996-22-000044:mdna:101]
(d)Other corporate expenses includes impairment charges, incentive charges related to equity investments, severance, facility action, payroll taxes associated with stock-based compensation, and other costs.  During the first nine months of Fiscal 2023, other corporate expenses includes $181 million of costs incurred in connection with exiting our business in Russia.

[0001571996-22-000044:mdna:102]
[same as prior period, unchanged from 0001571996-22-000031:mdna:99]

[0001571996-22-000044:mdna:103]
[same as prior period, unchanged from 0001571996-22-000031:mdna:100]

[0001571996-22-000044:mdna:104]
[same as prior period, unchanged from 0001571996-22-000031:mdna:101]

[0001571996-22-000044:mdna:105]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 28, 2022 |  |  |  | October 29, 2021 |  | October 28, 2022 |  |  |  | October 29, 2021 |  |  |  |  |
|  | Dollars |  | % of Net Revenue |  | %Change |  | Dollars |  | % of Net Revenue |  | Dollars |  | % ofNet Revenue |  | %Change |  | Dollars |  | % ofNet Revenue |  |  |  |  |  |  |
|  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products | $ | 18,938 |  |  | 76.6 | % |  | (10) | % |  | $ | 20,979 |  |  | 79.4 | % |  | $ | 60,212 |  |  | 77.9 | % |  | 5 | % |  | $ | 57,361 |  |  | 78.4 | % |  |  |  |  |  |  |
| Services | 5,783 |  |  | 23.4 | % |  | 6 | % |  | 5,445 |  |  | 20.6 | % |  | 17,050 |  |  | 22.1 | % |  | 8 | % |  | 15,844 |  |  | 21.6 | % |  |  |  |  |  |  |
| Total net revenue | $ | 24,721 |  |  | 100.0 | % |  | (6) | % |  | $ | 26,424 |  |  | 100.0 | % |  | $ | 77,262 |  |  | 100.0 | % |  | 6 | % |  | $ | 73,205 |  |  | 100.0 | % |  |  |  |  |  |  |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products (a) | $ | 3,337 |  |  | 17.6 | % |  | 6 | % |  | $ | 3,146 |  |  | 15.0 | % |  | $ | 9,931 |  |  | 16.5 | % |  | 6 | % |  | $ | 9,402 |  |  | 16.4 | % |  |  |  |  |  |  |
| Services (b) | 2,370 |  |  | 41.0 | % |  | (1) | % |  | 2,388 |  |  | 43.9 | % |  | 6,999 |  |  | 41.0 | % |  | 2 | % |  | 6,871 |  |  | 43.4 | % |  |  |  |  |  |  |
| Total gross margin | $ | 5,707 |  |  | 23.1 | % |  | 3 | % |  | $ | 5,534 |  |  | 20.9 | % |  | $ | 16,930 |  |  | 21.9 | % |  | 4 | % |  | $ | 16,273 |  |  | 22.2 | % |  |  |  |  |  |  |
| Operating expenses | $ | 3,945 |  |  | 16.0 | % |  | (12) | % |  | $ | 4,488 |  |  | 16.9 | % |  | $ | 12,348 |  |  | 16.0 | % |  | (7) | % |  | $ | 13,223 |  |  | 18.0 | % |  |  |  |  |  |  |
| Operating income | $ | 1,762 |  |  | 7.1 | % |  | 68 | % |  | $ | 1,046 |  |  | 4.0 | % |  | $ | 4,582 |  |  | 5.9 | % |  | 50 | % |  | $ | 3,050 |  |  | 4.2 | % |  |  |  |  |  |  |
| Net income from continuing operations | $ | 241 |  |  | 1.0 | % |  | (93) | % |  | $ | 3,683 |  |  | 13.9 | % |  | $ | 1,816 |  |  | 2.4 | % |  | (63) | % |  | $ | 4,971 |  |  | 6.8 | % |  |  |  |  |  |  |
| Non-GAAP Financial Information |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | Three Months Ended |  | Nine Months Ended |
|  | October 28, 2022 |  |  |  | October 29, 2021 |  | October 28, 2022 |  |  |  | October 29, 2021 |  |  |  |  |
|  | Dollars |  | % of Non-GAAP Net Revenue |  | %Change |  | Dollars |  | % of Non-GAAP Net Revenue |  | Dollars |  | % of Non-GAAP Net Revenue |  | %Change |  | Dollars |  | % of Non-GAAP Net Revenue |  |  |  |  |  |  |
|  | (in millions, except percentages) |
| Non-GAAP net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products | $ | 18,938 |  |  | 76.6 | % |  | (10) | % |  | $ | 20,979 |  |  | 79.4 | % |  | $ | 60,212 |  |  | 77.9 | % |  | 5 | % |  | $ | 57,361 |  |  | 78.3 | % |  |  |  |  |  |  |
| Services | 5,783 |  |  | 23.4 | % |  | 6 | % |  | 5,453 |  |  | 20.6 | % |  | 17,050 |  |  | 22.1 | % |  | 7 | % |  | 15,868 |  |  | 21.7 | % |  |  |  |  |  |  |
| Total non-GAAP net revenue | $ | 24,721 |  |  | 100.0 | % |  | (6) | % |  | $ | 26,432 |  |  | 100.0 | % |  | $ | 77,262 |  |  | 100.0 | % |  | 6 | % |  | $ | 73,229 |  |  | 100.0 | % |  |  |  |  |  |  |
| Non-GAAP gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products (a) | $ | 3,453 |  |  | 18.2 | % |  | 4 | % |  | $ | 3,310 |  |  | 15.8 | % |  | $ | 10,300 |  |  | 17.1 | % |  | 4 | % |  | $ | 9,892 |  |  | 17.2 | % |  |  |  |  |  |  |
| Services (b) | 2,412 |  |  | 41.7 | % |  | — | % |  | 2,419 |  |  | 44.4 | % |  | 7,156 |  |  | 42.0 | % |  | 3 | % |  | 6,974 |  |  | 44.0 | % |  |  |  |  |  |  |
| Total non-GAAP gross margin | $ | 5,865 |  |  | 23.7 | % |  | 2 | % |  | $ | 5,729 |  |  | 21.7 | % |  | $ | 17,456 |  |  | 22.6 | % |  | 3 | % |  | $ | 16,866 |  |  | 23.0 | % |  |  |  |  |  |  |
| Non-GAAP operating expenses | $ | 3,485 |  |  | 14.1 | % |  | (8) | % |  | $ | 3,773 |  |  | 14.3 | % |  | $ | 10,989 |  |  | 14.2 | % |  | (3) | % |  | $ | 11,272 |  |  | 15.4 | % |  |  |  |  |  |  |
| Non-GAAP operating income | $ | 2,380 |  |  | 9.6 | % |  | 22 | % |  | $ | 1,956 |  |  | 7.4 | % |  | $ | 6,467 |  |  | 8.4 | % |  | 16 | % |  | $ | 5,594 |  |  | 7.6 | % |  |  |  |  |  |  |
| Non-GAAP net income | $ | 1,705 |  |  | 6.9 | % |  | 30 | % |  | $ | 1,313 |  |  | 5.0 | % |  | $ | 4,405 |  |  | 5.7 | % |  | 25 | % |  | $ | 3,534 |  |  | 4.8 | % |  |  |  |  |  |  |
| EBITDA | $ | 2,594 |  |  | 10.5 | % |  | 33 | % |  | $ | 1,954 |  |  | 7.4 | % |  | $ | 6,884 |  |  | 8.9 | % |  | 19 | % |  | $ | 5,767 |  |  | 7.9 | % |  |  |  |  |  |  |
| Adjusted EBITDA | $ | 2,946 |  |  | 11.9 | % |  | 21 | % |  | $ | 2,429 |  |  | 9.2 | % |  | $ | 8,004 |  |  | 10.4 | % |  | 15 | % |  | $ | 6,974 |  |  | 9.5 | % |  |  |  |  |  |  |

[0001571996-22-000044:mdna:106]
[same as prior period, unchanged from 0001571996-22-000031:mdna:103]

[0001571996-22-000044:mdna:107]
[same as prior period, unchanged from 0001571996-22-000031:mdna:104]

[0001571996-22-000044:mdna:108]
[same as prior period, unchanged from 0001571996-22-000031:mdna:105]

[0001571996-22-000044:mdna:109]
[same as prior period, unchanged from 0001571996-22-000031:mdna:106]

[0001571996-22-000044:mdna:110]
[same as prior period, unchanged from 0001571996-22-000031:mdna:107]

[0001571996-22-000044:mdna:111]
During the third quarter of Fiscal 2023, our net revenue decreased 6%, primarily driven by a decrease in net revenue for CSG which was partially offset by growth in net revenue for ISG.  CSG net revenue decreased as a result of an overall decline in the demand environment for our CSG offerings.  Our net revenue during the first nine months of Fiscal 2023 increased 6%, primarily due to growth in net revenue for ISG.  Growth in net revenue for ISG for the third quarter and first nine months of Fiscal 2023 was driven by strength across both servers and networking and storage.

[0001571996-22-000044:mdna:112]
During the third quarter and first nine months of Fiscal 2023, our operating income increased 68% to $1.8 billion and 50% to $4.6 billion, respectively.  These increases were primarily driven by growth in operating income for ISG and the favorable impact of a decrease in amortization of intangible assets.  For the third quarter of Fiscal 2023, the increase was also attributable to a decrease in transaction-related expenses primarily associated with costs incurred in connection with the VMware Spin-off during the third quarter of Fiscal 2022 that did not reoccur during Fiscal 2023.  Growth in ISG operating income for the third quarter and first nine months of Fiscal 2023 was driven by both our server and networking and storage offerings.  During the third quarter and first nine months of Fiscal 2023, our non-GAAP operating income increased 22% to $2.4 billion and 16% to $6.5 billion driven by the same ISG dynamics discussed above.

[0001571996-22-000044:mdna:113]
Operating income as a percentage of net revenue increased 310 basis points to 7.1% during the third quarter of Fiscal 2023 and 170 basis points to 5.9% during the first nine months of Fiscal 2023.

[0001571996-22-000044:mdna:114]
For the third quarter of Fiscal 2023, the increase was principally attributable to improvement in gross margin as percentage of net revenue and to a decrease in operating expenses as a percentage of net revenue.  Gross margin as a percentage of net revenue increased as a result of a shift in mix towards ISG and, to a lesser extent, a decrease in cost of net revenue as a result of a decline in input costs.

[0001571996-22-000044:mdna:115]
For the first nine months of Fiscal 2023, the increase was principally due to a decrease in operating expenses as a percentage of net revenue, partially offset by a decline in gross margin as a percentage of net revenue.  Gross margin percentage declined primarily due to the impacts of an overall increase in input costs and foreign currency exchange rate fluctuations, which were not entirely offset by pricing adjustments, as we balanced profitability with competitive positioning.

[0001571996-22-000044:mdna:116]
For both the third quarter and first nine months of Fiscal 2023, operating expense as a percentage of net revenue declined due to disciplined cost management, a reduction in performance-based compensation, and the favorable impacts of a decrease in both the amortization of intangible assets and transaction-related expenses incurred in connection with the VMware Spin-off in Fiscal 2022.

[0001571996-22-000044:mdna:117]
Non-GAAP operating income as a percentage of net revenue increased 220 basis points to 9.6% during the third quarter of Fiscal 2023 and 80 basis points to 8.4% during the first nine months of Fiscal 2023, driven by the same disciplined cost management and gross margin dynamics discussed above.

[0001571996-22-000044:mdna:118]
Cash provided by operating activities was $0.9 billion and $7.2 billion during the first nine months of Fiscal 2023 and Fiscal 2022, respectively.  During the first nine months of Fiscal 2022, $3.2 billion of the $7.2 billion total represented cash provided by operating activities attributable to VMware, Inc.  Cash provided by operating activities during the first nine months of Fiscal 2023 declined primarily as a result of unfavorable working capital dynamics as compared to the first nine months of Fiscal 2022.  Working capital was primarily impacted by increased inventory balances, as we proactively managed supply chain dynamics, coupled with the timing of purchases and payments to vendors during a declining demand environment.  See “Liquidity, Cash Requirements, and Market Conditions” for further information on our cash flow metrics.

[0001571996-22-000044:mdna:119]
[same as prior period, unchanged from 0001571996-22-000031:mdna:112]

[0001571996-22-000044:mdna:120]
[same as prior period, unchanged from 0001571996-22-000031:mdna:113]

[0001571996-22-000044:mdna:121]
During the third quarter of Fiscal 2023, our net revenue decreased 6% primarily driven by a decline in net revenue for CSG that was partially offset by growth in net revenue for ISG.  Our net revenue during the first nine months of Fiscal 2023 increased 6%, primarily due to growth in net revenue for ISG.  See “Business Unit Results” for further information.

[0001571996-22-000044:mdna:122]
•Product Net Revenue — Product net revenue includes revenue from the sale of hardware products and software licenses.  During the third quarter of Fiscal 2023, our product net revenue decreased 10%, primarily driven by a decline in CSG product net revenue, which was partially offset by growth in ISG product net revenue.  CSG product net revenue decreased primarily due to a decline in units sold for both our consumer and commercial offerings.  During the first nine months of Fiscal 2023, our product net revenue increased 5%, driven primarily by growth within ISG product net revenue.  For both the third quarter and first nine months of Fiscal 2023, ISG product net revenue growth was driven primarily by an increase in product net revenue from our server and networking offerings and, to a lesser extent, growth in product net revenue attributable to our storage offerings.

[0001571996-22-000044:mdna:123]
•Services Net Revenue — Services net revenue includes revenue from our services offerings and support services related to hardware products and software licenses.  During the third quarter and first nine months of Fiscal 2023, services net revenue increased 6% and 8%, respectively, driven principally by strength in hardware support and maintenance and third-party software support and maintenance within CSG.  A substantial portion of services net revenue is derived from offerings that have been deferred over a period of time, and, as a result, reported services net revenue growth rates will be different than reported product net revenue growth rates.

[0001571996-22-000044:mdna:124]
From a geographical perspective, net revenue generated by sales to customers in all regions decreased during the third quarter of Fiscal 2023, driven by declines in CSG product net revenue, which was partially offset by growth in ISG product net revenue.  During the first nine months of Fiscal 2023, net revenue increased in all regions, driven primarily by growth in ISG.

[0001571996-22-000044:mdna:125]
[same as prior period, unchanged from 0001571996-22-000031:mdna:118]

[0001571996-22-000044:mdna:126]
During the third quarter and first nine months of Fiscal 2023, gross margin increased 3% to $5.7 billion and 4% to $16.9 billion, respectively, and non-GAAP gross margin increased 2% to $5.9 billion and 3% to $17.5 billion, respectively.  These increases were driven by growth in ISG gross margin, partially offset by declines in CSG gross margin.  For the first nine months of Fiscal 2023, the increase was further offset by a decline in other businesses gross margin.

[0001571996-22-000044:mdna:127]
During the third quarter of Fiscal 2023, our gross margin and non-GAAP gross margin percentage increased 220 basis points to 23.1% and 200 basis points to 23.7%, respectively.  These increases in gross margin percentage were primarily attributable to a shift in mix towards ISG and, to a lesser extent, a decrease in cost of net revenue as a result of a decline in input costs.

[0001571996-22-000044:mdna:128]
During the first nine months of Fiscal 2023, gross margin and non-GAAP gross margin percentage decreased 30 basis points to 21.9% and 40 basis points to 22.6%, respectively.  The declines in gross margin percentage were primarily due to the impacts of an overall increase in input costs and foreign currency exchange rate fluctuations, which were not entirely offset by pricing adjustments, as we balanced profitability with competitive positioning.

[0001571996-22-000044:mdna:129]
•Product Gross Margin — During both the third quarter and first nine months of Fiscal 2023, product gross margin increased 6% to $3.3 billion and $9.9 billion, respectively, and non-GAAP product gross margin increased 4% to $3.5 billion and $10.3 billion, respectively.  These increases were driven primarily by growth in ISG product gross margin due to continued growth in product net revenue for our server and networking offerings and, to a lesser extent, growth in product net revenue for our storage offerings.  The increases in ISG product gross margin were partially offset by declines in CSG product gross margin.  The decline in CSG product gross margin for the third quarter of Fiscal 2023 was principally due to a decrease in product net revenue for both our consumer and commercial offerings.  For the first nine months of Fiscal 2023, the decline in CSG product gross margin was driven by a decrease in product net revenue for our consumer offerings.

[0001571996-22-000044:mdna:130]
During the third quarter of Fiscal 2023, product gross margin percentage and non-GAAP product gross margin percentage increased 260 basis points to 17.6% and 240 basis points to 18.2%, respectively.  The increases in product gross margin percentage were primarily attributable to growth in both ISG and CSG product gross margin percentages coupled with a shift in mix towards ISG.

[0001571996-22-000044:mdna:131]
During the first nine months of Fiscal 2023, product gross margin percentage increased 10 basis points to 16.5%.  The favorable impacts of a decrease in amortization of intangible assets coupled with a shift in mix towards ISG were mostly offset by an increase in input costs and foreign currency exchange rate fluctuations, which were not entirely offset by pricing adjustments.  During the first nine months of Fiscal 2023, non-GAAP product gross margin percentage decreased 10 basis points to 17.1%, driven by the mix and input cost dynamics discussed above.

[0001571996-22-000044:mdna:132]
•Services Gross Margin — During the third quarter of Fiscal 2023, both services gross margin and non-GAAP services gross margin remained flat at $2.4 billion, while, during the first nine months of Fiscal 2023, services gross margin and non-GAAP services gross margin increased 2% to $7.0 billion and 3% to $7.2 billion, respectively.  Increases in CSG services gross margin for both periods were mostly offset by declines in other businesses services gross margin.  CSG services gross margin increased as a result of growth within hardware support and maintenance associated with products sold in prior periods, while other businesses services gross margin declined due to the impacts of the divestiture of Boomi during the third quarter of Fiscal 2022.

[0001571996-22-000044:mdna:133]
During the third quarter and first nine months of Fiscal 2023, services gross margin percentage decreased 290 basis points to 41.0% and 240 basis points to 41.0%, respectively, and non-GAAP services gross margin percentage decreased 270 basis points to 41.7% and 200 basis points to 42.0%, respectively.  These decreases were driven by the impacts of the divestiture of Boomi during the third quarter of Fiscal 2022 coupled with declines in services gross margin percentage for ISG and, to a lesser extent, a shift in mix towards CSG.

[0001571996-22-000044:mdna:134]
Vendor Programs

[0001571996-22-000044:mdna:135]
[same as prior period, unchanged from 0001571996-22-000031:mdna:128]

[0001571996-22-000044:mdna:136]
The terms and conditions of our vendor rebate programs are largely based on product volumes and are generally negotiated either at the beginning of the annual or quarterly period, depending on the program.  The timing and amount of vendor rebates and other discounts we receive under the programs may vary from period to period, reflecting changes in the competitive environment.  We monitor our component costs and seek to address the effects of any changes to terms that might arise under our vendor rebate programs.  Our gross margins for the third quarter and first nine months of Fiscal 2023 and for the third quarter and first nine months of Fiscal 2022 were not materially affected by any changes to the terms of our vendor rebate programs, as the amounts we received under these programs were generally stable relative to our total net cost.

[0001571996-22-000044:mdna:137]
We are not aware of any significant changes to our vendor rebate programs that will materially impact our results in the near term.  We anticipate that the impact of industry-wide price increases of certain processors will impact our cost of net revenue beginning in Fiscal 2024.  We will continue to take pricing actions to balance profitability and growth while actively addressing our customers’ demands.

[0001571996-22-000044:mdna:138]
74

[0001571996-22-000044:mdna:139]
[same as prior period, unchanged from 0001571996-22-000031:mdna:131]

[0001571996-22-000044:mdna:140]
[same as prior period, unchanged from 0001571996-22-000031:mdna:132]

[0001571996-22-000044:mdna:141]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 28, 2022 |  |  |  | October 29, 2021 |  | October 28, 2022 |  |  |  | October 29, 2021 |  |  |  |  |
|  | Dollars |  | % of Net Revenue |  | %Change |  | Dollars |  | % of Net Revenue |  | Dollars |  | % of Net Revenue |  | %Change |  | Dollars |  | % of Net Revenue |  |  |  |  |  |  |
|  | (in millions, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative | $ | 3,268 |  |  | 13.3 | % |  | (15) | % |  | $ | 3,838 |  |  | 14.4 | % |  | $ | 10,364 |  |  | 13.4 | % |  | (8) | % |  | $ | 11,257 |  |  | 15.3 | % |  |  |  |  |  |  |
| Research and development | 677 |  |  | 2.7 | % |  | 4 | % |  | 650 |  |  | 2.5 | % |  | 1,984 |  |  | 2.6 | % |  | 1 | % |  | 1,966 |  |  | 2.7 | % |  |  |  |  |  |  |
| Total operating expenses | $ | 3,945 |  |  | 16.0 | % |  | (12) | % |  | $ | 4,488 |  |  | 16.9 | % |  | $ | 12,348 |  |  | 16.0 | % |  | (7) | % |  | $ | 13,223 |  |  | 18.0 | % |  |  |  |  |  |  |
|  | Three Months Ended |  | Nine Months Ended |
|  | October 28, 2022 |  |  |  | October 29, 2021 |  | October 28, 2022 |  |  |  | October 29, 2021 |  |  |  |  |
|  | Dollars |  | % of Net Revenue |  | %Change |  | Dollars |  | % of Net Revenue |  | Dollars |  | % of Net Revenue |  | %Change |  | Dollars |  | % of Net Revenue |  |  |  |  |  |  |
|  | (in millions, except percentages) |
| Non-GAAP operating expenses | $ | 3,485 |  |  | 14.1 | % |  | (8) | % |  | $ | 3,773 |  |  | 14.3 | % |  | $ | 10,989 |  |  | 14.2 | % |  | (3) | % |  | $ | 11,272 |  |  | 15.4 | % |  |  |  |  |  |  |

[0001571996-22-000044:mdna:142]
During the third quarter and first nine months of Fiscal 2023, total operating expenses decreased 12% and 7%, respectively, primarily driven by a decrease in selling, general, and administrative expenses.

[0001571996-22-000044:mdna:143]
•Selling, General, and Administrative — Selling, general, and administrative (“SG&A”) expenses decreased 15% and 8% during the third quarter and first nine months of Fiscal 2023, respectively.  The decreases in SG&A expenses were primarily attributable to decreases in amortization of intangible assets, employee compensation and benefits, and outside services expenses.  Employee compensation and benefits expense decreased primarily as a result of a reduction in performance-based compensation and disciplined cost management.  The decline in outside services expense was primarily attributable to expenses incurred in Fiscal 2022, principally related to the VMware Spin-off, that did not reoccur in Fiscal 2023.

[0001571996-22-000044:mdna:144]
•Research and Development — Research and development (“R&D”) expenses are primarily composed of personnel-related expenses incurred in connection with product development.  R&D expenses increased 4% and 1% during the third quarter and first nine months of Fiscal 2023, respectively, driven by an increase in employee compensation and benefits as we continue to invest in R&D initiatives.

[0001571996-22-000044:mdna:145]
As a percentage of net revenue, R&D expenses for the third quarter of Fiscal 2023 and Fiscal 2022 were 2.7% and 2.5%, respectively, and for the first nine months of Fiscal 2023 and Fiscal 2022, were 2.6% and 2.7%, respectively.  We intend to continue supporting R&D initiatives to innovate and introduce new and enhanced solutions into the market.

[0001571996-22-000044:mdna:146]
During the third quarter and first nine months of Fiscal 2023, non-GAAP operating expenses decreased 8% and 3%, respectively, principally due to a decline in employee compensation and benefits expense primarily resulting from a reduction in performance-based compensation and disciplined cost management.

[0001571996-22-000044:mdna:147]
[same as prior period, unchanged from 0001571996-22-000031:mdna:138]

[0001571996-22-000044:mdna:148]
[same as prior period, unchanged from 0001571996-22-000031:mdna:139]

[0001571996-22-000044:mdna:149]
During the third quarter and first nine months of Fiscal 2023, our operating income increased 68% to $1.8 billion and 50% to $4.6 billion, respectively.  These increases were primarily driven by growth in operating income for ISG and the favorable impact of a decrease in amortization of intangible assets.  For the third quarter of Fiscal 2023, the increase was also attributable to a decrease in transaction-related expenses primarily associated with costs incurred in connection with the VMware Spin-off during the third quarter of Fiscal 2022 that did not reoccur during Fiscal 2023.  Growth in ISG operating income for the third quarter and first nine months of Fiscal 2023 was driven by both our server and networking and storage offerings.  During the third quarter and first nine months of Fiscal 2023, our non-GAAP operating income increased 22% to $2.4 billion and 16% to $6.5 billion, driven by the same ISG dynamics discussed above.

[0001571996-22-000044:mdna:150]
Operating income as a percentage of net revenue increased 310 basis points to 7.1% during the third quarter of Fiscal 2023 and 170 basis points to 5.9% during the first nine months of Fiscal 2023.

[0001571996-22-000044:mdna:151]
For the third quarter of Fiscal 2023, the increase was due to improvement in gross margin as percentage of net revenue and to a decrease in operating expenses as a percentage of net revenue.  Gross margin as a percentage of net revenue increased as a result of a shift in mix towards ISG and, to a lesser extent, a decrease in cost of net revenue as a result of a decline in input costs.

[0001571996-22-000044:mdna:152]
For the first nine months of Fiscal 2023, the increase was principally due to a decrease in operating expenses as a percentage of net revenue, partially offset by a decline in gross margin as a percentage of net revenue.  Gross margin percentage declined primarily due to the impacts of an overall increase in input costs and foreign currency exchange rate fluctuations, which were not entirely offset by pricing adjustments, as we balanced profitability with competitive positioning.

[0001571996-22-000044:mdna:153]
For both the third quarter and first nine months of Fiscal 2023, operating expense percentage declined due to disciplined cost management coupled with the favorable impacts of a decrease in the amortization of intangible assets and a decrease in transaction-related expenses incurred in connection with the VMware Spin-off in Fiscal 2022.

[0001571996-22-000044:mdna:154]
Non-GAAP operating income as a percentage of net revenue increased 220 basis points to 9.6% during the third quarter of Fiscal 2023 and 80 basis points to 8.4% during the first nine months of Fiscal 2023, driven by the same disciplined cost management and gross margin dynamics discussed above.

[0001571996-22-000044:mdna:155]
[same as prior period, unchanged from 0001571996-22-000031:mdna:142]

[0001571996-22-000044:mdna:156]
[same as prior period, unchanged from 0001571996-22-000031:mdna:143]

[0001571996-22-000044:mdna:157]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 28, 2022 |  | October 29, 2021 |  | October 28, 2022 |  | October 29, 2021 |  |  |
|  | (in millions) |
| Interest and other, net: |  |  |  |  |  |  |  |  |  |
| Investment income, primarily interest | $ | 21 |  |  | $ | 10 |  |  | $ | 52 |  |  | $ | 30 |  |  |  |
| Gain (loss) on investments, net | 44 |  |  | 18 |  |  | (197) |  |  | 377 |  |  |  |
| Interest expense | (272) |  |  | (406) |  |  | (835) |  |  | (1,255) |  |  |  |
| Foreign exchange | (72) |  |  | (33) |  |  | (227) |  |  | (152) |  |  |  |
| Gain on disposition of businesses and assets | — |  |  | 3,968 |  |  | — |  |  | 3,968 |  |  |  |
| Legal settlement | (1,000) |  |  | — |  |  | (1,000) |  |  | — |  |  |  |
| Other | (29) |  |  | (56) |  |  | (73) |  |  | (47) |  |  |  |
| Total interest and other, net | $ | (1,308) |  |  | $ | 3,501 |  |  | $ | (2,280) |  |  | $ | 2,921 |  |  |  |

[0001571996-22-000044:mdna:158]
During the third quarter and first nine months of Fiscal 2023, the change in interest and other, net was unfavorable by $4.8 billion and $5.2 billion, respectively.  The unfavorable change was primarily attributable to the pre-tax gain of $4.0 billion on the sale of Boomi recognized during the third quarter of Fiscal 2022 and $1.0 billion of expense recognized in the third quarter of Fiscal 2023 in connection with an agreement to settle the Class V transaction litigation.  These factors were partially offset by a decrease in interest expense as a result of lower average outstanding debt balances.

[0001571996-22-000044:mdna:159]
For additional information about the settlement agreement, see Note 19 of the Notes to the Condensed Consolidated Financial Statements included in this report.

[0001571996-22-000044:mdna:160]
[same as prior period, unchanged from 0001571996-22-000031:mdna:146]

[0001571996-22-000044:mdna:161]
[same as prior period, unchanged from 0001571996-22-000031:mdna:147]

[0001571996-22-000044:mdna:162]
|  | Three Months Ended |  | Nine Months Ended |  |  |
|  | October 28, 2022 |  | October 29, 2021 |  | October 28, 2022 |  | October 29, 2021 |  |  |
|  | (in millions, except percentages) |  |  |
| Income before income taxes | $ | 454 |  |  | $ | 4,547 |  |  | $ | 2,302 |  |  | $ | 5,971 |  |  |  |
| Income tax expense | $ | 213 |  |  | $ | 864 |  |  | $ | 486 |  |  | $ | 1,000 |  |  |  |
| Effective income tax rate | 46.9 | % |  | 19.0 | % |  | 21.1 | % |  | 16.7 | % |  |  |

[0001571996-22-000044:mdna:163]
For the third quarter of Fiscal 2023 and Fiscal 2022, our effective income tax rate was 46.9% and 19.0%, respectively.  For the first nine months of Fiscal 2023 and Fiscal 2022, our effective income tax rate was 21.1% and 16.7%, respectively.  For the third quarter and first nine months of Fiscal 2023, the changes in our effective tax rates were primarily attributable to changes in discrete tax items.  Our effective tax rate for both the three and nine months ended October 28, 2022, includes the impact of a $1.0 billion expense recognized in connection with an agreement to settle the Class V transaction litigation.  Other changes to our effective income tax rates were primarily driven by a change in the jurisdictional mix of income and higher U.S. tax on foreign operations, the effects of which were partially offset by higher benefits from foreign tax credits.  See Note 19 of the Notes to the Condensed Consolidated Financial Statements included in this report for additional information about the Class V litigation settlement agreement.

[0001571996-22-000044:mdna:164]
Higher U.S. tax on foreign operations was due to the capitalization of research and development costs.  Under the Tax Cuts and Jobs Act, which was enacted on December 22, 2017, research and development expenses incurred for tax years beginning after December 31, 2021 must be capitalized and amortized ratably over five or 15 years for tax purposes, depending on where the research activities were conducted.  Our effective income tax rate for the remaining quarter of Fiscal 2023 may be impacted by actions taken by the U.S. government to defer or repeal this provision, as well as by the actual mix of jurisdictions in which income is generated and the impact of any discrete tax items.  If the provision is not deferred or repealed, we expect that its application will result in a significant increase in our cash tax liabilities for Fiscal 2023, as well as a significant increase to our deferred tax assets.

[0001571996-22-000044:mdna:165]
Our effective income tax rate can fluctuate depending on the geographic distribution of our worldwide earnings, as our foreign earnings are generally taxed at lower rates than in the United States.  The differences between our effective income tax rate and the U.S. federal statutory rate of 21% principally result from the geographical distribution of income, differences between the book and tax treatment of certain items, and discrete tax items.  In certain jurisdictions, our tax rate is significantly less than the applicable statutory rate as a result of tax holidays.  The majority of our foreign income that is subject to these tax holidays is attributable to Singapore and China.  A significant portion of these income tax benefits relates to a tax holiday that will be effective until January 31, 2029.  Our other tax holidays will expire in whole or in part during Fiscal 2030 through Fiscal 2031.  Many of these tax holidays and reduced tax rates may be extended when certain conditions are met or may be terminated early if certain conditions are not met.  As of October 28, 2022, we were not aware of any matters of noncompliance related to these tax holidays.

[0001571996-22-000044:mdna:166]
[same as prior period, unchanged from 0001571996-22-000031:mdna:153]

[0001571996-22-000044:mdna:167]
[same as prior period, unchanged from 0001571996-22-000031:mdna:154]

[0001571996-22-000044:mdna:168]
[same as prior period, unchanged from 0001571996-22-000031:mdna:171]

[0001571996-22-000044:mdna:169]
[same as prior period, unchanged from 0001571996-22-000031:mdna:155]

[0001571996-22-000044:mdna:170]
Net income from continuing operations was $0.2 billion and $3.7 billion for the third quarter of Fiscal 2023 and Fiscal 2022, respectively, and $1.8 billion and $5.0 billion for the first nine months of Fiscal 2023 and Fiscal 2022, respectively.  The decreases were driven principally by an unfavorable change in interest and other, net, partially offset by an increase in operating income coupled with a decrease in tax expense.

[0001571996-22-000044:mdna:171]
Non-GAAP net income was $1.7 billion and $1.3 billion for the third quarter of Fiscal 2023 and Fiscal 2022, respectively, and $4.4 billion and $3.5 billion for the first nine months of Fiscal 2023 and Fiscal 2022, respectively.  The increases were primarily attributable to an increase in non-GAAP operating income and a favorable change in interest and other, net, partially offset by an increase in tax expense.

[0001571996-22-000044:mdna:172]
[same as prior period, unchanged from 0001571996-22-000031:mdna:159]

[0001571996-22-000044:mdna:173]
[same as prior period, unchanged from 0001571996-22-000031:mdna:160]

[0001571996-22-000044:mdna:174]
[same as prior period, unchanged from 0001571996-22-000031:mdna:161]

[0001571996-22-000044:mdna:175]
[same as prior period, unchanged from 0001571996-22-000031:mdna:162]

[0001571996-22-000044:mdna:176]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 28, 2022 |  | % Change |  | October 29, 2021 |  | October 28, 2022 |  | % Change |  | October 29, 2021 |  |  |  |  |
|  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Servers and networking | $ | 5,201 |  |  | 14 | % |  | $ | 4,561 |  | $ | 15,458 |  | 17 | % |  | $ | 13,181 |  |  |  |  |
| Storage | 4,429 |  |  | 11 | % |  | 4,003 |  | 12,993 |  | 9 | % |  | 11,966 |  |  |  |  |
| Total ISG net revenue | $ | 9,630 |  |  | 12 | % |  | $ | 8,564 |  | $ | 28,451 |  | 13 | % |  | $ | 25,147 |  |  |  |  |
| Operating income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| ISG operating income | $ | 1,374 |  |  | 54 | % |  | $ | 894 |  | $ | 3,502 |  | 33 | % |  | $ | 2,634 |  |  |  |  |
| % of segment net revenue | 14.3 | % |  |  |  | 10.4 | % |  | 12.3 | % |  |  |  | 10.5 | % |  |  |  |  |

[0001571996-22-000044:mdna:177]
Net Revenue — During the third quarter and first nine months of Fiscal 2023, ISG net revenue increased 12% and 13%, respectively, driven by strength across both server and networking and storage offerings.

[0001571996-22-000044:mdna:178]
Revenue from sales of servers and networking increased 14% and 17% during the third quarter and first nine months of Fiscal 2023, respectively.  The increases were primarily driven by an increase in average selling price of our server offerings, the effect of which was partially offset by a decrease in units sold.  The average selling price for our server offerings increased as a result of richer configurations and continued pricing discipline in response to the macroeconomic environment.

[0001571996-22-000044:mdna:179]
During the third quarter and first nine months of Fiscal 2023, storage revenue increased 11% and 9%, respectively, due to continued strength across the majority of our storage offerings.

[0001571996-22-000044:mdna:180]
ISG customers are interested in new and innovative models that address how they consume our solutions.  We offer options that include as-a-Service, utility, leases, and immediate pay models which are designed to match customers’ consumption and financing preferences.  Our multiyear agreements typically result in recurring revenue streams over the term of the arrangement.  We expect that our flexible consumption models and as-a-Service offerings through Dell APEX will further strengthen our customer relationships and provide a foundation for growth in recurring revenue.

[0001571996-22-000044:mdna:181]
From a geographical perspective, net revenue attributable to ISG increased in all regions during the third quarter and first nine months of Fiscal 2023.

[0001571996-22-000044:mdna:182]
Operating Income — During the third quarter and first nine months of Fiscal 2023, ISG operating income as a percentage of net revenue increased 390 basis points to 14.3% and 180 basis points to 12.3%, respectively, principally due to a decrease in operating expenses as a percentage of net revenue that resulted from strong revenue growth and disciplined cost management.  The increase in ISG operating income as a percentage of net revenue during the first nine months of Fiscal 2023 was partially offset by the impacts of an increase in cost of net revenue and foreign currency exchange rate fluctuations which were not entirely offset by pricing adjustments.

[0001571996-22-000044:mdna:183]
[same as prior period, unchanged from 0001571996-22-000031:mdna:172]

[0001571996-22-000044:mdna:184]
[same as prior period, unchanged from 0001571996-22-000031:mdna:173]

[0001571996-22-000044:mdna:185]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 28, 2022 |  | % Change |  | October 29, 2021 |  | October 28, 2022 |  | % Change |  | October 29, 2021 |  |  |  |  |
|  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 10,747 |  |  | (13) | % |  | $ | 12,300 |  | $ | 34,859 |  | 7 | % |  | $ | 32,685 |  |  |  |  |
| Consumer | 3,028 |  |  | (29) | % |  | 4,256 |  | 9,993 |  | (13) | % |  | 11,450 |  |  |  |  |
| Total CSG net revenue | $ | 13,775 |  |  | (17) | % |  | $ | 16,556 |  | $ | 44,852 |  | 2 | % |  | $ | 44,135 |  |  |  |  |
| Operating income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| CSG operating income | $ | 1,060 |  |  | (7) | % |  | $ | 1,142 |  | $ | 3,153 |  | (2) | % |  | $ | 3,208 |  |  |  |  |
| % of segment net revenue | 7.7 | % |  |  |  | 6.9 | % |  | 7.0 | % |  |  |  | 7.3 | % |  |  |  |  |

[0001571996-22-000044:mdna:186]
Net Revenue — During the third quarter of Fiscal 2023, CSG net revenue decreased 17% primarily driven by declines in net revenue across both our commercial and consumer offerings.  CSG net revenue during the first nine months of Fiscal 2023 increased 2%, driven by an increase in revenue attributable to our commercial offerings, which was partially offset by a decline in consumer net revenue.

[0001571996-22-000044:mdna:187]
Commercial net revenue decreased 13% during the third quarter of Fiscal 2023 due to a decline in units sold, partially offset by the effect of an increase in the average selling price of our commercial offerings.

[0001571996-22-000044:mdna:188]
During the first nine months of Fiscal 2023, commercial net revenue increased 7% as a result of an increase in the average selling price of our commercial offerings, the effect of which was partially offset by a decrease in units sold.

[0001571996-22-000044:mdna:189]
Consumer net revenue decreased 29% and 13% during the third quarter and first nine months of Fiscal 2023, respectively, primarily due to a decrease in units sold, which was partially offset by the effect of an increase in the average selling price of our consumer offerings.

[0001571996-22-000044:mdna:190]
Our average selling prices for our CSG offerings increased as a result of richer configurations, a shift in mix towards commercial offerings, and continued actions to manage pricing in response to the macroeconomic environment.

[0001571996-22-000044:mdna:191]
From a geographical perspective, net revenue attributable to CSG decreased across all regions during the third quarter of Fiscal 2023.  During the first nine months of Fiscal 2023, CSG net revenue increased in the Americas, remained flat in APJ, and decreased in EMEA.

[0001571996-22-000044:mdna:192]
Operating Income — During the third quarter of Fiscal 2023, CSG operating income as a percentage of net revenue increased 80 basis points to 7.7% primarily as a result of a decrease in input costs.  The effect of this impact was partially offset by operating expenses as a percentage of revenue, which increased as a result of a decline in CSG net revenue that outpaced a reduction in operating expenses.

[0001571996-22-000044:mdna:193]
During the first nine months of Fiscal 2023, CSG operating income as a percentage of net revenue decreased 30 basis points to 7.0%, primarily due to the impacts of an increase in input costs and foreign currency exchange rate fluctuations which were not entirely offset by pricing adjustments, as we balanced profitability with competitive positioning.  The effect of these impacts was partially offset by a decrease in operating expenses as a percentage of revenue as a result of disciplined cost management and a decline in performance-based compensation.

[0001571996-22-000044:mdna:194]
[same as prior period, unchanged from 0001571996-22-000031:mdna:181]

[0001571996-22-000044:mdna:195]
[same as prior period, unchanged from 0001571996-22-000031:mdna:182]

[0001571996-22-000044:mdna:196]
We sell products and services directly to customers and through a variety of sales channels, including retail distribution.  Our accounts receivable, net, was $11.4 billion and $12.9 billion as of October 28, 2022 and January 28, 2022, respectively.  We maintain an allowance for expected credit losses to cover receivables that may be deemed uncollectible.  The allowance for expected credit losses is an estimate based on an analysis of historical loss experience, current receivables aging, and management’s assessment of current conditions and its reasonable and supportable expectation of future conditions, as well as specific identifiable customer accounts that are deemed at risk.  As of October 28, 2022 and January 28, 2022, the allowance for expected credit losses was $75 million and $90 million, respectively.  Based on our assessment, we believe that we are adequately reserved for expected credit losses.  We are monitoring the impact of current economic conditions on our expected losses and have not experienced deterioration in delinquency or loss rates.  We will continue to monitor the aging of our accounts receivable and take actions, where necessary, to reduce our exposure to credit losses.

[0001571996-22-000044:mdna:197]
[same as prior period, unchanged from 0001571996-22-000031:mdna:184]

[0001571996-22-000044:mdna:198]
We offer or arranges various financing options and services for our customers globally, including through captive financing operations.  DFS originates, collects, and services customer receivables primarily related to the purchase of our product, software, and service solutions.  We further strengthen customer relationships through flexible consumption models, including utility, subscription, and as-a-Service models, which enable us to offer our customers the option to pay over time to provide them with financial flexibility to meet their changing technological requirements.  We have historically seen an increasing interest in our various financing options during times of macroeconomic uncertainty.  New financing originations were $2.3 billion and $2.0 billion for the third quarter of Fiscal 2023 and Fiscal 2022, respectively, and $6.7 billion and $5.8 billion for the first nine months of Fiscal 2023 and Fiscal 2022, respectively.

[0001571996-22-000044:mdna:199]
Our leases are generally classified as sales-type leases or operating leases.  Amounts due from lessees under sales-type leases or direct financing leases are recorded as part of financing receivables, with interest income recognized over the contract term.  Upon commencement of sales-type leases, we typically qualify for up-front revenue recognition.  Upon origination of operating leases, we record equipment under operating leases, classified as property, plant, and equipment.  Over the contract term of an operating lease, we recognize rental revenue and depreciation expense, classified as cost of net revenue.

[0001571996-22-000044:mdna:200]
As of both October 28, 2022 and January 28, 2022, our financing receivables, net were $10.6 billion.  We maintain an allowance to cover expected financing receivable credit losses and evaluate credit loss expectations based on our total portfolio.  For the third quarter of Fiscal 2023 and Fiscal 2022, the principal charge-off rate for our financing receivables portfolio was 0.5% and 1.1%, respectively.  For the first nine months of Fiscal 2023 and Fiscal 2022, the principal charge-off rate for our financing receivables portfolio was 0.5% and 0.7%, respectively.  The credit quality of our financing receivables has improved in recent years as the mix of high-quality commercial accounts in our portfolio has continued to increase.  We continue to monitor broader economic indicators and their potential impact on future credit loss performance.  We have an extensive process to manage our exposure to customer credit risk, including active management of credit lines and our collection activities.  We also sell selected fixed-term financing receivables without recourse to unrelated third parties on a periodic basis, primarily to manage certain concentrations of customer credit exposure.  Based on our assessment of the customer financing receivables, we believe that we are adequately reserved.

[0001571996-22-000044:mdna:201]
We retain a residual interest in equipment leased under our lease programs.  As of October 28, 2022 and January 28, 2022, the residual interest recorded as part of financing receivables was $137 million and $217 million, respectively.  The decline in residual interest was principally attributable to a corresponding increase in originations of operating leases.  The amount of the residual interest is established at the inception of the lease based upon estimates of the value of the equipment at the end of the lease term using historical studies, industry data, and future value-at-risk demand valuation methods.  On a quarterly basis, we assess the carrying amount of our recorded residual values for expected losses.  Generally, expected losses as a result of residual value risk on equipment under lease are not considered to be significant primarily because of the existence of a secondary market with respect to the equipment.  Further, the lease agreement defines applicable return conditions and remedies for non-compliance to ensure that the leased equipment will be in good operating condition upon return.  No expected losses were recorded related to residual assets during the third quarter and first nine months of Fiscal 2023 and Fiscal 2022.

[0001571996-22-000044:mdna:202]
As of October 28, 2022 and January 28, 2022, equipment under operating leases, net was $2.1 billion and $1.7 billion, respectively.  We assess the carrying amount of the equipment under operating leases for impairment whenever events or circumstances may indicate that an impairment has occurred.  No material impairment losses were recorded related to such equipment during the third quarter and first nine months of Fiscal 2023 and Fiscal 2022.

[0001571996-22-000044:mdna:203]
[same as prior period, unchanged from 0001571996-22-000031:mdna:190]

[0001571996-22-000044:mdna:204]
[same as prior period, unchanged from 0001571996-22-000031:mdna:191]

[0001571996-22-000044:mdna:205]
[same as prior period, unchanged from 0001571996-22-000031:mdna:192]

[0001571996-22-000044:mdna:206]
83

[0001571996-22-000044:mdna:207]
[same as prior period, unchanged from 0001571996-22-000031:mdna:194]

[0001571996-22-000044:mdna:208]
[same as prior period, unchanged from 0001571996-22-000031:mdna:195]

[0001571996-22-000044:mdna:209]
To support our ongoing business operations, we rely on operating cash flows, which are impacted by trends in the demand environment, as our primary source of liquidity.  We monitor the efficiency of our balance sheet to ensure that we have adequate liquidity to support our business and strategic initiatives.  In addition to internally generated cash, we have access to other capital sources to finance our strategic initiatives and fund growth in our financing operations.  Our strategy is to deploy capital from any potential source, whether internally generated cash or debt, depending on the adequacy and availability of that source of capital and whether it can be accessed in a cost-effective manner.

[0001571996-22-000044:mdna:210]
We believe that our current cash and cash equivalents, together with cash that will be provided by future operations and borrowings expected to be available under our revolving credit facility and commercial paper program, will be sufficient over at least the next twelve months and for the foreseeable future thereafter to meet our material cash requirements, including funding of our operations, debt-related payments, capital expenditures, and other corporate needs.  Our cash and cash equivalent balances will be impacted in the near-term as a result of certain non-recurring cash outflows, including payment of the Class V transaction litigation settlement.

[0001571996-22-000044:mdna:211]
[same as prior period, unchanged from 0001571996-22-000031:mdna:198]

[0001571996-22-000044:mdna:212]
[same as prior period, unchanged from 0001571996-22-000031:mdna:199]

[0001571996-22-000044:mdna:213]
|  | October 28, 2022 |  | January 28, 2022 |
|  | (in millions) |
| Cash and cash equivalents, and available borrowings: |  |  |  |
| Cash and cash equivalents | $ | 4,909 |  |  | $ | 9,477 |  |
| Remaining available borrowings under revolving credit facilities | 4,999 |  |  | 4,969 |  |
| Total cash, cash equivalents, and available borrowings | $ | 9,908 |  |  | $ | 14,446 |  |

[0001571996-22-000044:mdna:214]
During the first nine months of Fiscal 2023, cash and cash equivalents decreased by $4.6 billion, as a result of the return of capital to our stockholders through share repurchases and dividend payments, as well as capital expenditures.

[0001571996-22-000044:mdna:215]
Our revolving credit facilities as of October 28, 2022 consist of the 2021 Revolving Credit Facility, which has a maximum capacity of $5.0 billion.  Available borrowings under this facility are reduced by draws on the facility and outstanding letters of credit.  As of October 28, 2022, there were no borrowings outstanding under the facility and remaining available borrowings totaled approximately $5.0 billion.  The 2021 Revolving Credit Facility also acts as a backstop to provide liquidity support for our commercial paper program discussed below.  Subsequent to the close of the third quarter of Fiscal 2023, we entered into an amendment to the 2021 Revolving Credit Facility which, in part, increased the aggregate borrowing capacity to $6.0 billion.

[0001571996-22-000044:mdna:216]
During the second quarter of Fiscal 2023, we established a commercial paper program under which we may issue unsecured notes in a maximum aggregate face amount of $5.0 billion outstanding at any time, with maturities up to 397 days from the date of issue.  During the third quarter of Fiscal 2023, we issued and repaid unsecured notes under the program, which we utilized to support general corporate activities.  As of October 28, 2022, we had no outstanding borrowings under the program.

[0001571996-22-000044:mdna:217]
We may regularly use our available borrowings from the 2021 Revolving Credit Facility and issuances under the commercial paper program on a short-term basis for general corporate purposes.  See Note 7 of the Notes to the Condensed Consolidated Financial Statements included in this report for additional information about our debt.

[0001571996-22-000044:mdna:218]
During the third quarter of Fiscal 2023, we entered into a factoring arrangement with a third-party financial institution to sell certain high-quality trade accounts receivable on a non-recourse basis and sold $500 million of receivables pursuant to this arrangement.  Proceeds from the sales of trade receivables are included in cash from operating activities in the Condensed Consolidated Statements of Cash Flows.  We may elect to factor trade accounts receivable from time to time as part of our overall liquidity and working capital management strategy.

[0001571996-22-000044:mdna:219]
[same as prior period, unchanged from 0001571996-22-000031:mdna:206]

[0001571996-22-000044:mdna:220]
[same as prior period, unchanged from 0001571996-22-000031:mdna:207]

[0001571996-22-000044:mdna:221]
|  | October 28, 2022 |  | Change |  | January 28, 2022 |
|  | (in millions) |
| Core debt |  |  |  |  |  |
| Senior Notes | $ | 16,300 |  |  | $ | — |  |  | $ | 16,300 |  |
| Legacy Notes and Debentures | 952 |  |  | — |  |  | 952 |  |
| DFS allocated debt | (1,023) |  |  | 110 |  |  | (1,133) |  |
| Total core debt | 16,229 |  |  | 110 |  |  | 16,119 |  |
| DFS related debt |  |  |  |  |  |
| DFS debt | 10,051 |  |  | 405 |  |  | 9,646 |  |
| DFS allocated debt | 1,023 |  |  | (110) |  |  | 1,133 |  |
| Total DFS related debt | 11,074 |  |  | 295 |  |  | 10,779 |  |
| Other | 287 |  |  | (50) |  |  | 337 |  |
| Total debt, principal amount | 27,590 |  |  | 355 |  |  | 27,235 |  |
| Carrying value adjustments | (261) |  |  | 20 |  |  | (281) |  |
| Total debt, carrying value | $ | 27,329 |  |  | $ | 375 |  |  | $ | 26,954 |  |

[0001571996-22-000044:mdna:222]
As of October 28, 2022, the outstanding principal amount of our debt of increased $0.4 billion from January 28, 2022 to $27.6 billion, driven primarily by net DFS activity.

[0001571996-22-000044:mdna:223]
We define core debt as the total principal amount of our debt, less DFS related debt and other debt.  Our core debt was $16.2 billion and $16.1 billion as of October 28, 2022 and January 28, 2022, respectively.  See Note 7 of the Notes to the Condensed Consolidated Financial Statements included in this report for additional information about our debt.

[0001571996-22-000044:mdna:224]
[same as prior period, unchanged from 0001571996-22-000031:mdna:211]

[0001571996-22-000044:mdna:225]
To fund expansion of the DFS business, we balance the use of the securitization and structured financing programs with other sources of liquidity.  We approximate the amount of our debt used to fund the DFS business by applying a 7:1 debt-to-equity ratio to the sum of our financing receivables balance and equipment under our DFS operating leases, net.  The debt-to-equity ratio is based on the underlying credit quality of the assets.  See Note 5 of the Notes to the Condensed Consolidated Financial Statements included in this report for additional information about our DFS debt.

[0001571996-22-000044:mdna:226]
[same as prior period, unchanged from 0001571996-22-000031:mdna:213]

[0001571996-22-000044:mdna:227]
We believe we will continue to be able to make our debt principal and interest payments, including the short-term maturities, from existing and expected sources of cash, primarily from operating cash flows.  Cash used for debt principal and interest payments may include short-term borrowings under our commercial paper program or our revolving credit facility.  Under our variable-rate debt, we could experience variations in our future interest expense from potential fluctuations in applicable reference rates, or from possible fluctuations in the level of DFS debt required to meet future demand for customer financing.  There are no scheduled maturities related to our outstanding core debt during Fiscal 2023.  However, at our sole discretion, we may purchase, redeem, prepay, refinance, or otherwise retire any amount of our outstanding indebtedness under the terms of such indebtedness at any time and from time to time, in open market or negotiated transactions with the holders of such indebtedness or otherwise, as we consider appropriate in light of market conditions and other relevant factors.

[0001571996-22-000044:mdna:228]
[same as prior period, unchanged from 0001571996-22-000031:mdna:215]

[0001571996-22-000044:mdna:229]
[same as prior period, unchanged from 0001571996-22-000031:mdna:216]

[0001571996-22-000044:mdna:230]
|  | Nine Months Ended |
|  | October 28, 2022 |  | October 29, 2021 |  |  |
|  | (in millions) |
| Net change in cash from: |  |  |  |  |  |
| Operating activities | $ | 851 |  |  | $ | 7,214 |  |  |  |
| Investing activities | (2,228) |  |  | 2,053 |  |  |  |
| Financing activities | (3,138) |  |  | (1,028) |  |  |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash | (343) |  |  | (54) |  |  |  |
| Change in cash, cash equivalents, and restricted cash | $ | (4,858) |  |  | $ | 8,185 |  |  |  |

[0001571996-22-000044:mdna:231]
Cash flows for the nine months ended October 29, 2021 are inclusive of cash flows attributable to VMware, Inc..  Effective November 1, 2021, as a result of the VMware Spin-off, cash flows ceased to include cash flows attributable to VMware, Inc.  See “Introduction” and Note 1 and Note 2 of the Notes to the Condensed Consolidated Financial Statements included in this report for additional information regarding the VMware Spin-off.

[0001571996-22-000044:mdna:232]
Operating Activities — Cash provided by operating activities was $0.9 billion during the first nine months of Fiscal 2023 compared to $7.2 billion during the first nine months of Fiscal 2022.  During the first nine months of Fiscal 2022, $3.2 billion of the total $7.2 billion represents cash provided by operating activities attributable to VMware, Inc.

[0001571996-22-000044:mdna:233]
The decline in cash provided by operating activities was primarily attributable to unfavorable working capital dynamics as compared to the first nine months of Fiscal 2022.  Working capital was primarily impacted by increased inventory balances, as we proactively managed supply chain dynamics, coupled with the timing of purchases and payments to vendors during a declining demand environment.

[0001571996-22-000044:mdna:234]
Cash provided by operating activities during the first nine months of Fiscal 2022 was driven by strong profitability coupled with favorable working capital dynamics.

[0001571996-22-000044:mdna:235]
Investing Activities — Investing activities primarily consist of cash used to fund capital expenditures for property, plant, and equipment, which includes equipment under DFS operating leases.  Additional activities include capitalized software development costs, acquisitions and divestitures, strategic investments, and the maturities, sales, and purchases of investments.  During the first nine months of Fiscal 2023, cash used in investing activities was $2.2 billion and was primarily applied to capital expenditures.  For the first nine months of Fiscal 2022, cash provided by investing activities was $2.1 billion, primarily driven by net cash proceeds related to the divestiture of Boomi in the third quarter of Fiscal 2022, partially offset by cash used for capital expenditures.

[0001571996-22-000044:mdna:236]
Financing Activities — Financing activities primarily consist of the proceeds and repayments of debt and cash used to repurchase common stock.  Cash used in financing activities was $3.1 billion during the first nine months of Fiscal 2023 and primarily consisted of repurchases of common stock, inclusive of payments to settle employee tax withholding on stock-based compensation, and the payment of quarterly dividends.  The effects of these financing activities were partially offset by net cash proceeds from DFS debt issuances. Cash used in financing activities was $1.0 billion during the first nine months of Fiscal 2022 and primarily consisted of debt repayments and repurchases of common stock by our public subsidiaries, partially offset by net cash proceeds from the issuance of VMware Notes and DFS debt.

[0001571996-22-000044:mdna:237]
DFS Cash Flow Impacts — DFS offerings are initially funded through cash on hand at the time of origination, most of which is subsequently replaced with asset-backed financing.  For DFS offerings that qualify as sales-type leases, the initial funding of financing receivables is reflected as an impact to cash flows from operations and is largely subsequently offset by cash proceeds from financing.  For DFS operating leases, the initial funding is classified as a capital expenditure and reflected as cash flows used in investing activities.  DFS new financing originations were $6.7 billion and $5.8 billion during the first nine months of Fiscal 2023 and Fiscal 2022, respectively.  As of October 28, 2022, DFS had $10.6 billion of total net financing receivables and $2.1 billion of equipment under DFS operating leases, net.

[0001571996-22-000044:mdna:238]
[same as prior period, unchanged from 0001571996-22-000031:mdna:223]

[0001571996-22-000044:mdna:239]
Capital Expenditures — We spent $2.2 billion and $2.1 billion during the first nine months of Fiscal 2023 and Fiscal 2022, respectively, on property, plant, and equipment and capitalized software development costs, of which the funding of equipment under DFS operating leases totaled $0.8 billion and $0.6 billion, respectively.  Product demand, product mix, the use of contract manufacturers, and ongoing investments in operating and information technology infrastructure influence the level and prioritization of our capital expenditures.  Aggregate capital expenditures for Fiscal 2023 are currently expected to total between $3.1 billion and $3.3 billion, of which approximately $1.1 billion of expenditures are expected to be applied to equipment under DFS operating leases and approximately $0.3 billion to capitalized software development costs.

[0001571996-22-000044:mdna:240]
Repurchases of Common Stock — Effective as of September 23, 2021, our Board of Directors approved a stock repurchase program with no fixed expiration date under which we are authorized to repurchase up to $5 billion of shares of our Class C Common Stock.  During the first nine months of Fiscal 2023, we repurchased approximately 59 million shares of Class C Common Stock under this program for a total purchase price of approximately $2.7 billion.

[0001571996-22-000044:mdna:241]
Dividend Payments — On February 24, 2022, the Company announced that its Board of Directors has adopted a dividend policy under which the Company intends to pay quarterly cash dividends on its common stock at an initial rate of $0.33 per share per fiscal quarter.  During the nine months ended October 28, 2022, the Company paid the following dividends:

[0001571996-22-000044:mdna:242]
| Declaration Date |  | Record Date |  | Payment Date |  | Dividend per Share |  | Amount (in millions) |
| February 24, 2022 |  | April 20, 2022 |  | April 29, 2022 |  | $ | 0.33 |  |  | $ | 248 |  |
| June 7, 2022 |  | July 20, 2022 |  | July 29, 2022 |  | $ | 0.33 |  |  | $ | 242 |  |
| September 6, 2022 |  | October 19, 2022 |  | October 28, 2022 |  | $ | 0.33 |  |  | $ | 238 |  |

[0001571996-22-000044:mdna:243]
[same as prior period, unchanged from 0001571996-22-000031:mdna:228]

[0001571996-22-000044:mdna:244]
We utilize several suppliers to manufacture sub-assemblies for our products.  Our efficient supply chain management allows us to enter into flexible and mutually beneficial purchase arrangements with our suppliers in order to minimize inventory risk.  Consistent with industry practice, we acquire raw materials or other goods and services, including product components, by issuing to suppliers authorizations to purchase based on our projected demand and manufacturing needs.  These purchase orders are typically fulfilled within 30 days and are entered into during the ordinary course of business in order to establish best pricing and continuity of supply for our production.  Purchase orders are not included in purchase obligations, as they typically represent our authorization to purchase rather than binding purchase obligations.

[0001571996-22-000044:mdna:245]
As of October 28, 2022, such purchase obligations were $2.7 billion, $0.6 billion, and $0.8 billion for the remaining three months of Fiscal 2023, Fiscal 2024, and Fiscal 2025 and thereafter, respectively.

[0001571996-22-000044:mdna:246]
[same as prior period, unchanged from 0001571996-22-000031:mdna:231]

[0001571996-22-000044:mdna:247]
[same as prior period, unchanged from 0001571996-22-000031:mdna:232]

[0001571996-22-000044:mdna:248]
[same as prior period, unchanged from 0001571996-22-000031:mdna:233]

[0001571996-22-000044:mdna:249]
We use derivative instruments to hedge certain foreign currency exposures.  We use forward contracts and purchased options designated as cash flow hedges to protect against the foreign currency exchange rate risks inherent in our forecasted transactions denominated in currencies other than the U.S. dollar.  In addition, we primarily use forward contracts and may use purchased options to hedge monetary assets and liabilities denominated in a foreign currency.  See Note 8 of the Notes to the Condensed Consolidated Financial Statements included in this report for additional information about our use of derivative instruments.

[0001571996-22-000044:mdna:250]
[same as prior period, unchanged from 0001571996-22-000031:mdna:235]

[0001571996-22-000044:mdna:251]
88

[0001571996-22-000044:mdna:252]
[same as prior period, unchanged from 0001571996-22-000031:mdna:236]

[0001571996-22-000044:mdna:253]
[same as prior period, unchanged from 0001571996-22-000031:mdna:237]

[0001571996-22-000044:mdna:254]
[same as prior period, unchanged from 0001571996-22-000031:mdna:238]

[0001571996-22-000044:mdna:255]
Basis of Preparation of the Summarized Financial Information — The tables below are summarized financial information provided in conformity with Rule 13-01 of the SEC’s Regulation S-X.  The summarized financial information of the Issuers and Guarantors (collectively, the “Obligor Group”) is presented on a combined basis, excluding intercompany balances and transactions between entities in the Obligor Group.  The Obligor Group’s amounts due from, amounts due to, and transactions with Non-Obligor Subsidiaries and VMware, Inc. and its consolidated subsidiaries (the “Related Party”) have been presented separately.  The Obligor Group’s investment balances in Non-Obligor Subsidiaries have been excluded.

[0001571996-22-000044:mdna:256]
[same as prior period, unchanged from 0001571996-22-000031:mdna:240]

[0001571996-22-000044:mdna:257]
|  | Nine Months Ended |
|  | October 28, 2022 |
|  | (in millions) |
| Net revenue (a) | $ | 7,462 |  |
| Gross margin (b) | 3,148 |  |
| Operating income | 788 |  |
| Interest and other, net (c) | (2,778) |  |
| Loss before income taxes | (1,990) |  |
| Net loss attributable to Obligor Group | $ | (1,705) |  |

[0001571996-22-000044:mdna:258]
[same as prior period, unchanged from 0001571996-22-000031:mdna:242]

[0001571996-22-000044:mdna:259]
(a)  Includes net revenue from services provided and product sales to Non-Obligor Subsidiaries of $625 million and $128 million, respectively.

[0001571996-22-000044:mdna:260]
(b)  Includes cost of net revenue from resale of solutions purchased from Non-Obligor Subsidiaries and the Related Party of $747 million and $382 million, respectively.  Includes costs of net revenue from shared services provided by Non-Obligor Subsidiaries of $486 million.

[0001571996-22-000044:mdna:261]
(c)   Includes interest expense on inter-company loan payables of $969 million.

[0001571996-22-000044:mdna:262]
[same as prior period, unchanged from 0001571996-22-000031:mdna:246]

[0001571996-22-000044:mdna:263]
|  | October 28, 2022 |  | January 28, 2022 |
|  | (in millions) |
| ASSETS |
| Current assets | $ | 2,975 |  |  | $ | 3,106 |  |
| Intercompany receivables | — |  |  | 988 |  |
| Due from related party, net | 118 |  |  | 59 |  |
| Short-term intercompany loan receivables | 207 |  |  | — |  |
| Total current assets | 3,300 |  |  | 4,153 |  |
| Due from related party, net | 612 |  |  | 710 |  |
| Goodwill and intangible assets | 14,980 |  |  | 15,399 |  |
| Other non-current assets | 2,877 |  |  | 2,810 |  |
| Total assets | $ | 21,769 |  |  | $ | 23,072 |  |
| LIABILITIES |
| Current liabilities | $ | 6,582 |  |  | $ | 4,625 |  |
| Intercompany payable | 563 |  |  | — |  |
| Due to related party | 98 |  |  | 192 |  |
| Total current liabilities | 7,243 |  |  | 4,817 |  |
| Long-term debt | 16,018 |  |  | 17,001 |  |
| Intercompany loan payables | 37,602 |  |  | 37,509 |  |
| Other non-current liabilities | 3,307 |  |  | 3,473 |  |
| Total liabilities | $ | 64,170 |  |  | $ | 62,800 |  |

[0001571996-22-000044:mdna:264]
90
