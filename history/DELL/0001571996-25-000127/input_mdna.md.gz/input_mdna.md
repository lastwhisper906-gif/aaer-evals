# DELL MD&A — 0001571996-25-000127


## mdna

[0001571996-25-000127:mdna:1]
[same as prior period, unchanged from 0001571996-25-000102:mdna:1]

[0001571996-25-000127:mdna:2]
[same as prior period, unchanged from 0001571996-25-000102:mdna:2]

[0001571996-25-000127:mdna:3]
[same as prior period, unchanged from 0001571996-25-000102:mdna:3]

[0001571996-25-000127:mdna:4]
[same as prior period, unchanged from 0001571996-25-000102:mdna:4]

[0001571996-25-000127:mdna:5]
[same as prior period, unchanged from 0001571996-25-000102:mdna:5]

[0001571996-25-000127:mdna:6]
[same as prior period, unchanged from 0001571996-25-000102:mdna:6]

[0001571996-25-000127:mdna:7]
[same as prior period, unchanged from 0001571996-25-000102:mdna:7]

[0001571996-25-000127:mdna:8]
[same as prior period, unchanged from 0001571996-25-000102:mdna:8]

[0001571996-25-000127:mdna:9]
•Infrastructure Solutions Group (“ISG”) — ISG includes our servers and networking offerings and our storage offerings. Our server portfolio includes high-performance general-purpose and AI-optimized servers. Our networking portfolio includes wide area network infrastructure, data center and edge networking switches, and cables and optics. Our comprehensive storage portfolio includes modern and traditional storage solutions that span primary, unstructured and data protection offerings and are delivered through multiple architectures, including all-flash, purpose-built, software-defined and hyper-converged infrastructure platforms. ISG also offers software, peripherals, and services, including consulting and support and deployment.

[0001571996-25-000127:mdna:10]
[same as prior period, unchanged from 0001571996-25-000102:mdna:10]

[0001571996-25-000127:mdna:11]
[same as prior period, unchanged from 0001571996-25-000102:mdna:36]

[0001571996-25-000127:mdna:12]
Our other businesses primarily consist of our historical resale of standalone offerings of VMware LLC (formerly VMware, Inc. and individually and together with its subsidiaries, “VMware”), referred to as “VMware Resale,” and offerings of SecureWorks Corp. (“Secureworks”) through the date of the sale of Secureworks as discussed below. These businesses are divested businesses or their offerings are no longer actively sold, and are not classified as reportable segments, either individually or collectively. Their operating results are reported within Corporate and other. On February 3, 2025, the sale of Secureworks to Sophos Inc., an affiliate of Thoma Bravo, L.P., was completed in an all-cash transaction for a purchase price of approximately $0.9 billion. We received total cash consideration for the equity interest held in Secureworks of approximately $0.6 billion, resulting in a gain on sale recorded of $0.2 billion recognized in interest and other, net in the Condensed Consolidated Statements of Income during the nine months ended October 31, 2025.

[0001571996-25-000127:mdna:13]
[same as prior period, unchanged from 0001571996-25-000102:mdna:13]

[0001571996-25-000127:mdna:14]
[same as prior period, unchanged from 0001571996-25-000102:mdna:14]

[0001571996-25-000127:mdna:15]
[same as prior period, unchanged from 0001571996-25-000102:mdna:15]

[0001571996-25-000127:mdna:16]
During the third quarter and first nine months of Fiscal 2026, we executed our strategy with strong operating results, generating overall net revenue and operating income growth. The following trends and conditions affected the environment in which we operated:

[0001571996-25-000127:mdna:17]
•Macroeconomic environment: We experienced continued significant demand for our AI-optimized server offerings, resulting in ISG net revenue growth and a shift in the mix of the business towards our ISG offerings. Additionally, the demand environment remained strong for our traditional servers and networking offerings and commercial offerings, for which we saw sequential improvement in our domestic market.

[0001571996-25-000127:mdna:18]
•Demand of AI-optimized solutions: Our ISG business continued to benefit from significant increased demand for AI-optimized solutions as customers continue to adopt and further integrate AI, which resulted in significant backlog levels that remained elevated as we exited the quarter. Given the scale of the AI opportunities, the varying stages of customer readiness, and the frequency of component part updates or transitions, there is inherent non-linearity in the timing of demand and subsequent shipments for our AI-optimized server offerings, which continues to drive variability in our revenue.

[0001571996-25-000127:mdna:19]
•Technology refresh in core markets: Within our CSG business, the PC refresh cycle is underway as customers continue to upgrade their devices, which has contributed to increased demand for our commercial offerings and modest CSG net revenue growth. Additionally, within our ISG business, we continue to see customers modernize and consolidate their data centers as more customers transition to next-generation products, which has contributed to strong demand and moderate net revenue growth during the year within our traditional servers and networking offerings.

[0001571996-25-000127:mdna:20]
[same as prior period, unchanged from 0001571996-25-000102:mdna:20]

[0001571996-25-000127:mdna:21]
For both the fourth quarter and the full fiscal year, we expect ISG and CSG net revenue growth, most notably within ISG. We expect that ISG net revenue growth will be driven by increased demand across our servers and networking offerings, largely in our AI-optimized server offerings. We expect modest CSG net revenue growth to be driven in part by the continuation of the PC refresh cycle. Additionally, we expect a continued reduction of our Corporate and other net revenue due to offerings that are no longer actively sold and businesses that have been divested.

[0001571996-25-000127:mdna:22]
We expect margin growth for both the fourth quarter and the full fiscal year, while balancing anticipated margin rate pressure resulting from a continuing shift in mix towards our AI-optimized servers and a competitive environment. We continue to monitor the commodity supply environment and anticipate increased inflation for component costs, with a modest increase in input costs expected for the remainder of Fiscal 2026 and more notable dynamics expected for Fiscal 2027. We continue to leverage the agility and scale of our world-class supply chain and seek to balance profitability and growth while maintaining disciplined pricing as we navigate through competitive pricing pressures. We remain focused on executing our key strategic priorities, creating long-term value for our shareholders, and addressing our customers’ needs.

[0001571996-25-000127:mdna:23]
We continue to advance our own capabilities to change the way we work and make decisions, improve business outcomes and the customer experience, and reduce costs by leveraging new technology and optimizing business processes. We remain committed to disciplined cost management in coordination with our ongoing business modernization initiatives, and expect to continue to scale operating expenses as we take targeted measures to reduce costs, including employee reorganizations, limitation of external hiring, and other actions to align our investments with our strategic priorities and customer needs. We anticipate these actions will result in additional reductions in our overall headcount. We believe our unique operating advantages provide a foundation to foster business growth, enable innovation, drive efficiencies, and continue to position us for long-term success.

[0001571996-25-000127:mdna:24]
Relationship with VMware — On March 25, 2024, we terminated our Commercial Framework Agreement with VMware, whereby we acted as a distributor of Broadcom Inc.’s VMware standalone products and services. We no longer act as a distributor of such products and services, although we continue to support customers that have purchased resale offerings sold in prior periods. We continue to integrate and embed certain VMware products and services with our VxRail solution for end-user customers. The results for this integrated offering are reflected within ISG.

[0001571996-25-000127:mdna:25]
[same as prior period, unchanged from 0001571996-25-000102:mdna:27]

[0001571996-25-000127:mdna:26]
[same as prior period, unchanged from 0001571996-25-000102:mdna:28]

[0001571996-25-000127:mdna:27]
We expect that growth in data will continue to generate long-term demand for our storage solutions and services. We continue to expand our offerings in external storage arrays, which incorporate flexible, cloud-based functionality. We benefit from offering solutions that provide the foundation for AI, enabling organizations to store, protect, and manage data across environments for both traditional and AI workloads. Our storage business is subject to seasonal trends, which may continue to impact ISG results.

[0001571996-25-000127:mdna:28]
[same as prior period, unchanged from 0001571996-25-000102:mdna:30]

[0001571996-25-000127:mdna:29]
Competitive dynamics remain an important factor in our CSG business and continue to impact pricing and operating results. We are committed to our long-term CSG strategy and will continue to make investments to innovate across the portfolio. We expect that the CSG demand environment will continue to be subject to seasonal trends and to be influenced by the PC refresh cycle.

[0001571996-25-000127:mdna:30]
[same as prior period, unchanged from 0001571996-25-000102:mdna:32]

[0001571996-25-000127:mdna:31]
[same as prior period, unchanged from 0001571996-25-000102:mdna:33]

[0001571996-25-000127:mdna:32]
Foreign Currency Exposure — We manage our business on a U.S. Dollar basis. However, we have a large global presence, generating approximately 40% and 45% of our net revenue from sales to customers outside of the United States during the third quarter and first nine months of Fiscal 2026, respectively, and 50% during both the third quarter and first nine months of Fiscal 2025. As a result, our operating results can be, and particularly in recent periods have been, impacted by fluctuations in foreign currency exchange rates. We utilize a comprehensive hedging strategy intended to mitigate the impact of foreign currency volatility over time, and we adjust pricing when possible to further minimize foreign currency impacts.

[0001571996-25-000127:mdna:33]
Other Macroeconomic Risks and Uncertainties — During the first nine months of Fiscal 2026, a number of countries, including the United States, imposed or proposed tariffs on imports, and may continue to do so. The impacts of trade protection measures, including increases or changes in tariffs and trade barriers, changes in government policies and international trade arrangements, geopolitical volatility, and global macroeconomic conditions, or uncertainty regarding the impact of proposed or future trade protection measures, may affect our results of operations in some markets. We continue to leverage the agility and scale of our world-class supply chain to mitigate impacts of tariffs and will continue to respond to changing market conditions as needed.

[0001571996-25-000127:mdna:34]
55

[0001571996-25-000127:mdna:35]
[same as prior period, unchanged from 0001571996-25-000102:mdna:37]

[0001571996-25-000127:mdna:36]
[same as prior period, unchanged from 0001571996-25-000102:mdna:38]

[0001571996-25-000127:mdna:37]
[same as prior period, unchanged from 0001571996-25-000102:mdna:39]

[0001571996-25-000127:mdna:38]
[same as prior period, unchanged from 0001571996-25-000102:mdna:40]

[0001571996-25-000127:mdna:39]
[same as prior period, unchanged from 0001571996-25-000102:mdna:41]

[0001571996-25-000127:mdna:40]
[same as prior period, unchanged from 0001571996-25-000102:mdna:42]

[0001571996-25-000127:mdna:41]
[same as prior period, unchanged from 0001571996-25-000102:mdna:43]

[0001571996-25-000127:mdna:42]
[same as prior period, unchanged from 0001571996-25-000102:mdna:44]

[0001571996-25-000127:mdna:43]
•Other Corporate Expenses — Other corporate expenses consist primarily of severance expenses, transaction-related impacts on the sales of businesses, payroll taxes associated with stock-based compensation, incentive charges related to equity investments, transaction-related expenses, facility action costs, and impairment charges. Severance costs are primarily related to severance and benefits for employees impacted by cost management initiatives. During the first nine months of Fiscal 2026 and Fiscal 2025, we recognized $0.4 billion and $0.6 billion, respectively, of severance expense related to workforce reduction activities. During the first nine months of Fiscal 2026, we recognized a $0.2 billion gain related to the sale of Secureworks. Although we may incur these types of items in the future, we exclude other corporate expenses as they can vary from period to period, are significantly impacted by the timing and nature of these events, and are not used by management in assessing operating performance of the business.

[0001571996-25-000127:mdna:44]
[same as prior period, unchanged from 0001571996-25-000102:mdna:46]

[0001571996-25-000127:mdna:45]
•Aggregate Adjustment for Income Taxes — The aggregate adjustment for income taxes is the estimated combined income tax effect for the adjustments described above and determined based on the tax jurisdictions where those adjustments were incurred, as well as an adjustment for discrete tax items. During the first nine months of Fiscal 2025, the aggregate adjustment for income taxes included discrete tax benefits of $0.4 billion related to changes in uncertain tax benefits resulting from the expiration of certain U.S. statutes of limitations and $0.2 billion related to stock-based compensation. We exclude these benefits or charges for purposes of calculating non-GAAP net income due to the variability in recognition of discrete tax items from period to period. The tax effects are determined based on the tax jurisdictions where the above items were incurred. See Note 11 of the Notes to the Condensed Consolidated Financial Statements included in this report for additional information about our income taxes. Our non-GAAP income tax was calculated using a fixed estimated annual tax rate that is determined based on historical trends and projections for the current fiscal year. We may adjust our estimated annual tax rate during the fiscal year to take into account events that would significantly impact our income tax expense, including significant changes resulting from tax legislation, material changes in geographic mix of net revenue and expenses, changes to our corporate structure, and other significant events.

[0001571996-25-000127:mdna:46]
57

[0001571996-25-000127:mdna:47]
[same as prior period, unchanged from 0001571996-25-000102:mdna:49]

[0001571996-25-000127:mdna:48]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 31, 2025 |  | % Change |  | November 1, 2024 |  | October 31, 2025 |  | % Change |  | November 1, 2024 |  |  |  |  |
|  | (in millions, except percentages) |
| Product gross margin | $ | 2,976 |  |  | 6 | % |  | $ | 2,802 |  |  | $ | 8,350 |  |  | 3 | % |  | $ | 8,133 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 41 |  |  |  |  | 60 |  |  | 121 |  |  |  |  | 179 |  |  |  |  |  |
| Stock-based compensation expense | 16 |  |  |  |  | 14 |  |  | 46 |  |  |  |  | 42 |  |  |  |  |  |
| Other corporate expenses | 1 |  |  |  |  | 4 |  |  | 17 |  |  |  |  | 14 |  |  |  |  |  |
| Non-GAAP product gross margin | $ | 3,034 |  |  | 5 | % |  | $ | 2,880 |  |  | $ | 8,534 |  |  | 2 | % |  | $ | 8,368 |  |  |  |  |  |
| Services gross margin | $ | 2,617 |  |  | 2 | % |  | $ | 2,558 |  |  | $ | 7,627 |  |  | 3 | % |  | $ | 7,439 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense | 22 |  |  |  |  | 25 |  |  | 68 |  |  |  |  | 73 |  |  |  |  |  |
| Other corporate expenses | 13 |  |  |  |  | 27 |  |  | 86 |  |  |  |  | 116 |  |  |  |  |  |
| Non-GAAP services gross margin | $ | 2,652 |  |  | 2 | % |  | $ | 2,610 |  |  | $ | 7,781 |  |  | 2 | % |  | $ | 7,628 |  |  |  |  |  |
| Gross margin | $ | 5,593 |  |  | 4 | % |  | $ | 5,360 |  |  | $ | 15,977 |  |  | 3 | % |  | $ | 15,572 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 41 |  |  |  |  | 60 |  |  | 121 |  |  |  |  | 179 |  |  |  |  |  |
| Stock-based compensation expense | 38 |  |  |  |  | 39 |  |  | 114 |  |  |  |  | 115 |  |  |  |  |  |
| Other corporate expenses | 14 |  |  |  |  | 31 |  |  | 103 |  |  |  |  | 130 |  |  |  |  |  |
| Non-GAAP gross margin | $ | 5,686 |  |  | 4 | % |  | $ | 5,490 |  |  | $ | 16,315 |  |  | 2 | % |  | $ | 15,996 |  |  |  |  |  |
| Operating expenses | $ | 3,474 |  |  | (5) | % |  | $ | 3,639 |  |  | $ | 10,920 |  |  | (5) | % |  | $ | 11,494 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | (80) |  |  |  |  | (108) |  |  | (251) |  |  |  |  | (325) |  |  |  |  |  |
| Stock-based compensation expense | (127) |  |  |  |  | (159) |  |  | (420) |  |  |  |  | (484) |  |  |  |  |  |
| Other corporate expenses | (84) |  |  |  |  | (134) |  |  | (387) |  |  |  |  | (544) |  |  |  |  |  |
| Non-GAAP operating expenses | $ | 3,183 |  |  | (2) | % |  | $ | 3,238 |  |  | $ | 9,862 |  |  | (3) | % |  | $ | 10,141 |  |  |  |  |  |

[0001571996-25-000127:mdna:49]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 31, 2025 |  | % Change |  | November 1, 2024 |  | October 31, 2025 |  | % Change |  | November 1, 2024 |  |  |  |  |
|  | (in millions, except percentages and per share amounts) |
| Operating income | $ | 2,119 |  |  | 23 | % |  | $ | 1,721 |  |  | $ | 5,057 |  |  | 24 | % |  | $ | 4,078 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 121 |  |  |  |  | 168 |  |  | 372 |  |  |  |  | 504 |  |  |  |  |  |
| Stock-based compensation expense | 165 |  |  |  |  | 198 |  |  | 534 |  |  |  |  | 599 |  |  |  |  |  |
| Other corporate expenses | 98 |  |  |  |  | 165 |  |  | 490 |  |  |  |  | 674 |  |  |  |  |  |
| Non-GAAP operating income | $ | 2,503 |  |  | 11 | % |  | $ | 2,252 |  |  | $ | 6,453 |  |  | 10 | % |  | $ | 5,855 |  |  |  |  |  |
| Net income | $ | 1,548 |  |  | 32 | % |  | $ | 1,170 |  |  | $ | 3,677 |  |  | 21 | % |  | $ | 3,044 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 121 |  |  |  |  | 168 |  |  | 372 |  |  |  |  | 504 |  |  |  |  |  |
| Stock-based compensation expense | 165 |  |  |  |  | 198 |  |  | 534 |  |  |  |  | 599 |  |  |  |  |  |
| Other corporate expenses | 95 |  |  |  |  | 166 |  |  | 237 |  |  |  |  | 665 |  |  |  |  |  |
| Fair value adjustments on equity investments | (173) |  |  |  |  | (46) |  |  | (194) |  |  |  |  | (21) |  |  |  |  |  |
| Aggregate adjustment for income taxes | 6 |  |  |  |  | (73) |  |  | (187) |  |  |  |  | (837) |  |  |  |  |  |
| Non-GAAP net income | $ | 1,762 |  |  | 11 | % |  | $ | 1,583 |  |  | $ | 4,439 |  |  | 12 | % |  | $ | 3,954 |  |  |  |  |  |
| Earnings per share attributable to Dell Technologies Inc. — diluted | $ | 2.28 |  |  | 39 | % |  | $ | 1.64 |  |  | $ | 5.34 |  |  | 26 | % |  | $ | 4.24 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 0.18 |  |  |  |  | 0.23 |  |  | 0.54 |  |  |  |  | 0.70 |  |  |  |  |  |
| Stock-based compensation expense | 0.24 |  |  |  |  | 0.28 |  |  | 0.78 |  |  |  |  | 0.83 |  |  |  |  |  |
| Other corporate expenses | 0.14 |  |  |  |  | 0.23 |  |  | 0.35 |  |  |  |  | 0.92 |  |  |  |  |  |
| Fair value adjustments on equity investments | (0.25) |  |  |  |  | (0.06) |  |  | (0.28) |  |  |  |  | (0.03) |  |  |  |  |  |
| Aggregate adjustment for income taxes | — |  |  |  |  | (0.10) |  |  | (0.29) |  |  |  |  | (1.17) |  |  |  |  |  |
| Total non-GAAP adjustments attributable to non-controlling interests | — |  |  |  |  | (0.01) |  |  | — |  |  |  |  | (0.02) |  |  |  |  |  |
| Non-GAAP earnings per share attributable to Dell Technologies Inc. — diluted | $ | 2.59 |  |  | 17 | % |  | $ | 2.21 |  |  | $ | 6.44 |  |  | 18 | % |  | $ | 5.47 |  |  |  |  |  |

[0001571996-25-000127:mdna:50]
[same as prior period, unchanged from 0001571996-25-000102:mdna:78]

[0001571996-25-000127:mdna:51]
In addition to the above measures, we use free cash flow and adjusted free cash flow as non-GAAP liquidity measures to evaluate our performance. As presented in the following table, we define free cash flow as cash flow from operations after excluding capital expenditures and capitalized software development costs, net. To measure adjusted free cash flow, we exclude the impact of financing receivables and equipment under operating leases from free cash flow, as the initial funding of these DFS offerings at the time of origination is largely subsequently replaced with cash inflows from our DFS debt, the majority of which is asset-backed.

[0001571996-25-000127:mdna:52]
[same as prior period, unchanged from 0001571996-25-000102:mdna:54]

[0001571996-25-000127:mdna:53]
[same as prior period, unchanged from 0001571996-25-000102:mdna:55]

[0001571996-25-000127:mdna:54]
[same as prior period, unchanged from 0001571996-25-000102:mdna:56]

[0001571996-25-000127:mdna:55]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 31, 2025 |  | % Change |  | November 1, 2024 |  | October 31, 2025 |  | % Change |  | November 1, 2024 |  |  |  |  |
|  | (in millions, except percentages) |
| Cash flow from operations | $ | 1,172 |  |  | (25) | % |  | $ | 1,553 |  |  | $ | 6,511 |  |  | 65 | % |  | $ | 3,936 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Capital expenditures and capitalized software development costs, net (a) | (666) |  |  |  |  | (639) |  |  | (1,909) |  |  |  |  | (1,861) |  |  |  |  |  |
| Free cash flow | $ | 506 |  |  | (45) | % |  | $ | 914 |  |  | $ | 4,602 |  |  | 122 | % |  | $ | 2,075 |  |  |  |  |  |
| Free cash flow | $ | 506 |  |  | (45) | % |  | $ | 914 |  |  | $ | 4,602 |  |  | 122 | % |  | $ | 2,075 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Financing receivables (b) | 1,135 |  |  |  |  | (233) |  |  | 1,704 |  |  |  |  | 419 |  |  |  |  |  |
| Equipment under operating leases (c) | 29 |  |  |  |  | 35 |  |  | 114 |  |  |  |  | 129 |  |  |  |  |  |
| Adjusted free cash flow | $ | 1,670 |  |  | 133 | % |  | $ | 716 |  |  | $ | 6,420 |  |  | 145 | % |  | $ | 2,623 |  |  |  |  |  |

[0001571996-25-000127:mdna:56]
[same as prior period, unchanged from 0001571996-25-000102:mdna:58]

[0001571996-25-000127:mdna:57]
[same as prior period, unchanged from 0001571996-25-000102:mdna:59]

[0001571996-25-000127:mdna:58]
[same as prior period, unchanged from 0001571996-25-000102:mdna:60]

[0001571996-25-000127:mdna:59]
[same as prior period, unchanged from 0001571996-25-000102:mdna:61]

[0001571996-25-000127:mdna:60]
60

[0001571996-25-000127:mdna:61]
[same as prior period, unchanged from 0001571996-25-000102:mdna:62]

[0001571996-25-000127:mdna:62]
[same as prior period, unchanged from 0001571996-25-000102:mdna:63]

[0001571996-25-000127:mdna:63]
[same as prior period, unchanged from 0001571996-25-000102:mdna:64]

[0001571996-25-000127:mdna:64]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 31, 2025 |  |  |  | November 1, 2024 |  | October 31, 2025 |  |  |  | November 1, 2024 |  |  |  |  |
|  | Dollars |  | % of Net Revenue |  | % Change |  | Dollars |  | % of Net Revenue |  | Dollars |  | % of Net Revenue |  | % Change |  | Dollars |  | % of Net Revenue |  |  |  |  |  |  |
|  | (in millions, except percentages and per share amounts) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products | $ | 21,255 |  |  | 78.7 | % |  | 16 | % |  | $ | 18,290 |  |  | 75.1 | % |  | $ | 62,789 |  |  | 78.3 | % |  | 18 | % |  | $ | 53,371 |  |  | 74.5 | % |  |  |  |  |  |  |
| Services | 5,750 |  |  | 21.3 | % |  | (5) | % |  | 6,076 |  |  | 24.9 | % |  | 17,370 |  |  | 21.7 | % |  | (5) | % |  | 18,265 |  |  | 25.5 | % |  |  |  |  |  |  |
| Total net revenue | $ | 27,005 |  |  | 100.0 | % |  | 11 | % |  | $ | 24,366 |  |  | 100.0 | % |  | $ | 80,159 |  |  | 100.0 | % |  | 12 | % |  | $ | 71,636 |  |  | 100.0 | % |  |  |  |  |  |  |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products | $ | 2,976 |  |  | 14.0 | % |  | 6 | % |  | $ | 2,802 |  |  | 15.3 | % |  | $ | 8,350 |  |  | 13.3 | % |  | 3 | % |  | $ | 8,133 |  |  | 15.2 | % |  |  |  |  |  |  |
| Services | 2,617 |  |  | 45.5 | % |  | 2 | % |  | 2,558 |  |  | 42.1 | % |  | 7,627 |  |  | 43.9 | % |  | 3 | % |  | 7,439 |  |  | 40.7 | % |  |  |  |  |  |  |
| Total gross margin | $ | 5,593 |  |  | 20.7 | % |  | 4 | % |  | $ | 5,360 |  |  | 22.0 | % |  | $ | 15,977 |  |  | 19.9 | % |  | 3 | % |  | $ | 15,572 |  |  | 21.7 | % |  |  |  |  |  |  |
| Operating expenses | $ | 3,474 |  |  | 12.9 | % |  | (5) | % |  | $ | 3,639 |  |  | 15.0 | % |  | $ | 10,920 |  |  | 13.6 | % |  | (5) | % |  | $ | 11,494 |  |  | 16.0 | % |  |  |  |  |  |  |
| Operating income | $ | 2,119 |  |  | 7.8 | % |  | 23 | % |  | $ | 1,721 |  |  | 7.1 | % |  | $ | 5,057 |  |  | 6.3 | % |  | 24 | % |  | $ | 4,078 |  |  | 5.7 | % |  |  |  |  |  |  |
| Net income | $ | 1,548 |  |  | 5.7 | % |  | 32 | % |  | $ | 1,170 |  |  | 4.8 | % |  | $ | 3,677 |  |  | 4.6 | % |  | 21 | % |  | $ | 3,044 |  |  | 4.2 | % |  |  |  |  |  |  |
| Earnings per share attributable to Dell Technologies — diluted | $ | 2.28 |  |  |  |  | 39 | % |  | $ | 1.64 |  |  |  |  | $ | 5.34 |  |  |  |  | 26 | % |  | $ | 4.24 |  |  |  |  |  |  |  |  |  |
| Cash flow from operations | $ | 1,172 |  |  |  |  | (25) | % |  | $ | 1,553 |  |  |  |  | $ | 6,511 |  |  |  |  | 65 | % |  | $ | 3,936 |  |  |  |  |  |  |  |  |  |
| Non-GAAP Financial Information |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | Three Months Ended |  | Nine Months Ended |
|  | October 31, 2025 |  |  |  | November 1, 2024 |  | October 31, 2025 |  |  |  | November 1, 2024 |  |  |  |  |
|  | Dollars |  | % of Net Revenue |  | % Change |  | Dollars |  | % of Net Revenue |  | Dollars |  | % of Net Revenue |  | % Change |  | Dollars |  | % of Net Revenue |  |  |  |  |  |  |
|  | (in millions, except percentages and per share amounts) |
| Non-GAAP gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products | $ | 3,034 |  |  | 14.3 | % |  | 5 | % |  | $ | 2,880 |  |  | 15.7 | % |  | $ | 8,534 |  |  | 13.6 | % |  | 2 | % |  | $ | 8,368 |  |  | 15.7 | % |  |  |  |  |  |  |
| Services | 2,652 |  |  | 46.1 | % |  | 2 | % |  | 2,610 |  |  | 43.0 | % |  | 7,781 |  |  | 44.8 | % |  | 2 | % |  | 7,628 |  |  | 41.8 | % |  |  |  |  |  |  |
| Total non-GAAP gross margin | $ | 5,686 |  |  | 21.1 | % |  | 4 | % |  | $ | 5,490 |  |  | 22.5 | % |  | $ | 16,315 |  |  | 20.4 | % |  | 2 | % |  | $ | 15,996 |  |  | 22.3 | % |  |  |  |  |  |  |
| Non-GAAP operating expenses | $ | 3,183 |  |  | 11.8 | % |  | (2) | % |  | $ | 3,238 |  |  | 13.3 | % |  | $ | 9,862 |  |  | 12.3 | % |  | (3) | % |  | $ | 10,141 |  |  | 14.1 | % |  |  |  |  |  |  |
| Non-GAAP operating income | $ | 2,503 |  |  | 9.3 | % |  | 11 | % |  | $ | 2,252 |  |  | 9.2 | % |  | $ | 6,453 |  |  | 8.1 | % |  | 10 | % |  | $ | 5,855 |  |  | 8.2 | % |  |  |  |  |  |  |
| Non-GAAP net income | $ | 1,762 |  |  | 6.5 | % |  | 11 | % |  | $ | 1,583 |  |  | 6.5 | % |  | $ | 4,439 |  |  | 5.5 | % |  | 12 | % |  | $ | 3,954 |  |  | 5.5 | % |  |  |  |  |  |  |
| Non-GAAP earnings per share attributable to Dell Technologies — diluted | $ | 2.59 |  |  |  |  | 17 | % |  | $ | 2.21 |  |  |  |  | $ | 6.44 |  |  |  |  | 18 | % |  | $ | 5.47 |  |  |  |  |  |  |  |  |  |
| Free cash flow | $ | 506 |  |  |  |  | (45) | % |  | $ | 914 |  |  |  |  | $ | 4,602 |  |  |  |  | 122 | % |  | $ | 2,075 |  |  |  |  |  |  |  |  |  |
| Adjusted free cash flow | $ | 1,670 |  |  |  |  | 133 | % |  | $ | 716 |  |  |  |  | $ | 6,420 |  |  |  |  | 145 | % |  | $ | 2,623 |  |  |  |  |  |  |  |  |  |

[0001571996-25-000127:mdna:65]
[same as prior period, unchanged from 0001571996-25-000102:mdna:66]

[0001571996-25-000127:mdna:66]
61

[0001571996-25-000127:mdna:67]
[same as prior period, unchanged from 0001571996-25-000102:mdna:68]

[0001571996-25-000127:mdna:68]
During the third quarter and first nine months of Fiscal 2026, net revenue increased by 11% and 12%, respectively, driven by an increase in ISG net revenue and, to a lesser extent, CSG net revenue that was partially offset by a decrease in Corporate and other net revenue. The increase in ISG net revenue was driven by growth in our servers and networking offerings. The increase in CSG net revenue was attributable to an increase in sales of our commercial offerings. Corporate and other net revenue declined primarily due to a decrease in VMware Resale revenue, as we no longer act as a distributor of standalone VMware offerings.

[0001571996-25-000127:mdna:69]
During the third quarter of Fiscal 2026, operating income and non-GAAP operating income increased by 23% to $2.1 billion and 11% to $2.5 billion, respectively. During the first nine months of Fiscal 2026, operating income and non-GAAP operating income increased by 24% to $5.1 billion and 10% to $6.5 billion, respectively. The increases for both periods were primarily attributable to an increase in ISG operating income that was driven primarily by our storage offerings and, to a lesser extent, our servers and networking offerings.

[0001571996-25-000127:mdna:70]
During the third quarter and first nine months of Fiscal 2026, operating income as a percentage of net revenue increased 70 basis points to 7.8% and 60 basis points to 6.3%, respectively. During the third quarter and first nine months of Fiscal 2026, non-GAAP operating income as a percentage of net revenue increased 10 basis points to 9.3% and decreased 10 basis points to 8.1%, respectively. Operating income and non-GAAP operating income as a percentage of net revenue during both the third quarter and first nine months of Fiscal 2026 benefitted from the favorable impact of a decline in operating expense rate as a result of strong net revenue growth coupled with continued disciplined cost management. The favorable impact of operating expense rate was largely offset by a decline in gross margin rate as a result of a shift in mix towards our AI-optimized server offerings. During the first nine months of Fiscal 2026, operating income as a percentage of net revenue was further impacted by lower other corporate expenses.

[0001571996-25-000127:mdna:71]
Cash provided by operating activities was $6.5 billion during the first nine months of Fiscal 2026 and was driven by net revenue growth and profitability, partially offset by higher financing receivables and working capital levels, both of which were primarily impacted by increased demand for our AI-optimized server offerings. During the first nine months of Fiscal 2025, cash provided by operating activities was $3.9 billion and was driven by profitability, partially offset by working capital dynamics. Working capital during the Fiscal 2025 period was primarily impacted by AI dynamics, which led to higher inventory, accounts receivable, and accounts payable levels. See “Liquidity, Cash Requirements, and Market Conditions” for additional information about our cash flow metrics.

[0001571996-25-000127:mdna:72]
[same as prior period, unchanged from 0001571996-25-000102:mdna:73]

[0001571996-25-000127:mdna:73]
[same as prior period, unchanged from 0001571996-25-000102:mdna:74]

[0001571996-25-000127:mdna:74]
During the third quarter and first nine months of Fiscal 2026, net revenue increased 11% and 12%, respectively, driven by an increase in ISG net revenue and, to a lesser extent, CSG net revenue that was partially offset by a decrease in Corporate and other net revenue. See “Business Unit Results” for further information.

[0001571996-25-000127:mdna:75]
•Product Net Revenue — Product net revenue includes revenue from the sale of hardware products and software licenses. During the third quarter and first nine months of Fiscal 2026, product net revenue increased 16% and 18%, respectively, due to an increase in ISG product net revenue and, to a lesser extent, CSG product net revenue. The increase in ISG product net revenue was driven by growth in our servers and networking offerings. The increase in CSG product net revenue reflected growth in our commercial offerings during both periods, which was partially offset by lower demand for our consumer offerings during the first nine months of Fiscal 2026.

[0001571996-25-000127:mdna:76]
•Services Net Revenue — Services net revenue includes revenue from our services offerings and support services related to hardware products and software licenses. During both the third quarter and first nine months of Fiscal 2026, services net revenue decreased 5% due to a decline in Corporate and other services net revenue, as we no longer act as a distributor of standalone VMware offerings. During the first nine months of Fiscal 2026, this decrease was partially offset by growth within services net revenue attributable to ISG and CSG, which was driven by support and maintenance associated with products sold in prior periods within both CSG and ISG and higher AI-optimized server offerings within ISG.

[0001571996-25-000127:mdna:77]
[same as prior period, unchanged from 0001571996-25-000102:mdna:79]

[0001571996-25-000127:mdna:78]
From a geographical perspective, net revenue increased in the Americas, driven by our AI-optimized server offerings, and, to a lesser extent, EMEA during the third quarter and first nine months of Fiscal 2026. Net revenue decreased in APJ during the third quarter of Fiscal 2026 and remained flat during the first nine months of Fiscal 2026.

[0001571996-25-000127:mdna:79]
[same as prior period, unchanged from 0001571996-25-000102:mdna:81]

[0001571996-25-000127:mdna:80]
During the third quarter of Fiscal 2026, gross margin and non-GAAP gross margin increased 4% to $5.6 billion and 4% to $5.7 billion, respectively, primarily due to an increase in ISG gross margin that was driven by growth in our AI-optimized server offerings and our core storage offerings. During the first nine months of Fiscal 2026, gross margin and non-GAAP gross margin increased 3% to $16.0 billion and 2% to $16.3 billion, respectively, primarily due to an increase in ISG gross margin that was driven by growth in our core storage offerings and our AI-optimized server offerings.

[0001571996-25-000127:mdna:81]
During the third quarter of Fiscal 2026, gross margin and non-GAAP gross margin percentage decreased 130 basis points to 20.7% and 140 basis points to 21.1%, respectively. During the first nine months of Fiscal 2026, gross margin and non-GAAP gross margin percentage decreased 180 basis points to 19.9% and 190 basis points to 20.4%, respectively. The decreases in gross margin percentage and non-GAAP gross margin percentage were primarily driven by a shift in mix towards our AI-optimized server offerings.

[0001571996-25-000127:mdna:82]
•Product Gross Margin — During the third quarter of Fiscal 2026, product gross margin and non-GAAP product gross margin increased 6% to $3.0 billion and 5% to $3.0 billion, respectively. During the first nine months of Fiscal 2026, product gross margin and non-GAAP product gross margin increased 3% to $8.4 billion and 2% to $8.5 billion, respectively. The increases in product gross margin and non-GAAP product gross margin were primarily attributable to an increase in ISG product gross margin due to the mix in our storage offerings.

[0001571996-25-000127:mdna:83]
During the third quarter of Fiscal 2026, product gross margin percentage and non-GAAP product gross margin percentage decreased 130 basis points to 14.0% and 140 basis points to 14.3%, respectively. During the first nine months of Fiscal 2026, product gross margin percentage and non-GAAP product gross margin percentage decreased 190 basis points to 13.3% and 210 basis points to 13.6%, respectively. The decreases for both periods were primarily attributable to a shift in mix towards our AI-optimized server offerings.

[0001571996-25-000127:mdna:84]
•Services Gross Margin — During the third quarter of Fiscal 2026, services gross margin and non-GAAP services gross margin increased 2% to $2.6 billion and 2% to $2.7 billion, respectively. During the first nine months of Fiscal 2026, services gross margin and non-GAAP services gross margin increased 3% to $7.6 billion and 2% to $7.8 billion, respectively. The increases for both periods were principally attributable to an increase in ISG services gross margin, which was primarily driven by higher AI-optimized server offerings and hardware support and maintenance associated with products sold in prior periods.

[0001571996-25-000127:mdna:85]
During the third quarter of Fiscal 2026, services gross margin percentage and non-GAAP services gross margin percentage increased 340 basis points to 45.5% and 310 basis points to 46.1%, respectively. During the first nine months of Fiscal 2026, services gross margin percentage and non-GAAP services gross margin percentage increased 320 basis points to 43.9% and 300 basis points to 44.8%, respectively. The increases for both periods were primarily driven by a shift in mix, as we no longer act as a distributor of standalone VMware offerings.

[0001571996-25-000127:mdna:86]
[same as prior period, unchanged from 0001571996-25-000102:mdna:88]

[0001571996-25-000127:mdna:87]
[same as prior period, unchanged from 0001571996-25-000102:mdna:89]

[0001571996-25-000127:mdna:88]
The terms and conditions of our vendor rebate programs are largely based on product volumes and are generally negotiated either at the beginning of the annual or quarterly period, depending on the program. The timing and amount of vendor rebates and other discounts we receive under the programs may vary from period to period, reflecting changes in the competitive environment. We monitor our component costs and seek to address the effects of any changes to terms that might arise under our vendor rebate programs. Our gross margins for the third quarter and first nine months of Fiscal 2026 were not materially affected by any changes to the terms of our vendor rebate programs, as the amounts we received under these programs were generally stable relative to our total net cost. We are not aware of any significant changes to our vendor rebate programs that will materially impact our results in the near term.

[0001571996-25-000127:mdna:89]
[same as prior period, unchanged from 0001571996-25-000102:mdna:91]

[0001571996-25-000127:mdna:90]
[same as prior period, unchanged from 0001571996-25-000102:mdna:92]

[0001571996-25-000127:mdna:91]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 31, 2025 |  |  |  | November 1, 2024 |  | October 31, 2025 |  |  |  | November 1, 2024 |  |  |  |  |
|  | Dollars |  | % of Net Revenue |  | % Change |  | Dollars |  | % of Net Revenue |  | Dollars |  | % of Net Revenue |  | % Change |  | Dollars |  | % of Net Revenue |  |  |  |  |  |  |
|  | (in millions, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative | $ | 2,722 |  |  | 10.1 | % |  | (6) | % |  | $ | 2,894 |  |  | 11.9 | % |  | $ | 8,575 |  |  | 10.7 | % |  | (7) | % |  | $ | 9,206 |  |  | 12.8 | % |  |  |  |  |  |  |
| Research and development | 752 |  |  | 2.8 | % |  | 1 | % |  | 745 |  |  | 3.1 | % |  | 2,345 |  |  | 2.9 | % |  | 2 | % |  | 2,288 |  |  | 3.2 | % |  |  |  |  |  |  |
| Total operating expenses | $ | 3,474 |  |  | 12.9 | % |  | (5) | % |  | $ | 3,639 |  |  | 15.0 | % |  | $ | 10,920 |  |  | 13.6 | % |  | (5) | % |  | $ | 11,494 |  |  | 16.0 | % |  |  |  |  |  |  |
|  | Three Months Ended |  | Nine Months Ended |
|  | October 31, 2025 |  |  |  | November 1, 2024 |  | October 31, 2025 |  |  |  | November 1, 2024 |  |  |  |  |
|  | Dollars |  | % of Net Revenue |  | % Change |  | Dollars |  | % of Net Revenue |  | Dollars |  | % of Net Revenue |  | % Change |  | Dollars |  | % of Net Revenue |  |  |  |  |  |  |
|  | (in millions, except percentages) |
| Non-GAAP operating expenses | $ | 3,183 |  |  | 11.8 | % |  | (2) | % |  | $ | 3,238 |  |  | 13.3 | % |  | $ | 9,862 |  |  | 12.3 | % |  | (3) | % |  | $ | 10,141 |  |  | 14.1 | % |  |  |  |  |  |  |

[0001571996-25-000127:mdna:92]
During both the third quarter and first nine months of Fiscal 2026, total operating expenses decreased 5% primarily due to a decline in selling, general, and administrative (“SG&A”) expenses.

[0001571996-25-000127:mdna:93]
•Selling, General, and Administrative — During the third quarter and first nine months of Fiscal 2026, SG&A expenses decreased 6% and 7%, respectively, driven by a decrease in employee compensation and benefits expense that primarily resulted from a decline in overall headcount.

[0001571996-25-000127:mdna:94]
•Research and Development — Research and development (“R&D”) expenses are primarily composed of personnel-related expenses incurred in connection with product development. R&D expenses increased 1% and 2% during the third quarter and first nine months of Fiscal 2026, respectively, principally due to continued support of investments in R&D initiatives.

[0001571996-25-000127:mdna:95]
As a percentage of net revenue, R&D expenses for the third quarter of Fiscal 2026 and Fiscal 2025 were 2.8% and 3.1%, respectively, and for the first nine months of Fiscal 2026 and Fiscal 2025 were 2.9% and 3.2%, respectively. We continue to support R&D initiatives to innovate and introduce new and enhanced solutions into the market.

[0001571996-25-000127:mdna:96]
During the third quarter and first nine months of Fiscal 2026, non-GAAP operating expenses decreased 2% and 3%, respectively, driven by a decline in employee compensation and benefits expense that primarily resulted from a decline in overall headcount. The decline in employee compensation and benefits expense was partially offset by continued support of investments in R&D initiatives.

[0001571996-25-000127:mdna:97]
[same as prior period, unchanged from 0001571996-25-000102:mdna:99]

[0001571996-25-000127:mdna:98]
[same as prior period, unchanged from 0001571996-25-000102:mdna:100]

[0001571996-25-000127:mdna:99]
During the third quarter of Fiscal 2026, operating income and non-GAAP operating income increased by 23% to $2.1 billion and 11% to $2.5 billion, respectively. During the first nine months of Fiscal 2026, operating income and non-GAAP operating income increased by 24% to $5.1 billion and 10% to $6.5 billion, respectively. The increases for both periods were primarily attributable to an increase in ISG operating income that was driven primarily by our storage offerings and, to a lesser extent, our servers and networking offerings.

[0001571996-25-000127:mdna:100]
During the third quarter and first nine months of Fiscal 2026, operating income as a percentage of net revenue increased 70 basis points to 7.8% and 60 basis points to 6.3%, respectively. During the third quarter and first nine months of Fiscal 2026, non-GAAP operating income as a percentage of net revenue increased 10 basis points to 9.3% and decreased 10 basis points to 8.1%, respectively. Operating income and non-GAAP operating income as a percentage of net revenue during both the third quarter and first nine months of Fiscal 2026 benefitted from the favorable impact of a decline in operating expense rate as a result of strong net revenue growth coupled with continued disciplined cost management. The favorable impact of operating expense rate was largely offset by a decline in gross margin rate as a result of a shift in mix towards our AI-optimized server offerings. During the first nine months of Fiscal 2026, operating income as a percentage of net revenue was further impacted by lower other corporate expenses.

[0001571996-25-000127:mdna:101]
[same as prior period, unchanged from 0001571996-25-000102:mdna:103]

[0001571996-25-000127:mdna:102]
[same as prior period, unchanged from 0001571996-25-000102:mdna:104]

[0001571996-25-000127:mdna:103]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 31, 2025 |  | November 1, 2024 |  | October 31, 2025 |  | November 1, 2024 |  |  |
|  | (in millions) |
| Interest and other, net: |  |  |  |  |  |  |  |  |  |
| Investment income, primarily interest | $ | 72 |  |  | $ | 35 |  |  | $ | 167 |  |  | $ | 127 |  |  |  |
| Gain on investments, net | 173 |  |  | 46 |  |  | 194 |  |  | 21 |  |  |  |
| Interest expense | (396) |  |  | (321) |  |  | (1,149) |  |  | (1,051) |  |  |  |
| Foreign exchange | (37) |  |  | (29) |  |  | (57) |  |  | (80) |  |  |  |
| Gain on disposition of businesses and assets | — |  |  | — |  |  | 236 |  |  | — |  |  |  |
| Other | 10 |  |  | (7) |  |  | 16 |  |  | (19) |  |  |  |
| Total interest and other, net | $ | (178) |  |  | $ | (276) |  |  | $ | (593) |  |  | $ | (1,002) |  |  |  |

[0001571996-25-000127:mdna:104]
During the third quarter of Fiscal 2026, the change in interest and other, net was favorable primarily due to gains recognized within our strategic investments portfolio, partially offset by increased interest expense. During the first nine months of Fiscal 2026, the change in interest and other, net was favorable primarily due to the gain on the sale of Secureworks and gains recognized within our strategic investments portfolio, partially offset by increased interest expense.

[0001571996-25-000127:mdna:105]
65

[0001571996-25-000127:mdna:106]
[same as prior period, unchanged from 0001571996-25-000102:mdna:107]

[0001571996-25-000127:mdna:107]
[same as prior period, unchanged from 0001571996-25-000102:mdna:108]

[0001571996-25-000127:mdna:108]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 31, 2025 |  | November 1, 2024 |  | October 31, 2025 |  | November 1, 2024 |  |  |
|  | (in millions, except percentages) |
| Income before income taxes | $ | 1,941 |  |  | $ | 1,445 |  |  | $ | 4,464 |  |  | $ | 3,076 |  |  |  |
| Income tax expense | $ | 393 |  |  | $ | 275 |  |  | $ | 787 |  |  | $ | 32 |  |  |  |
| Effective income tax rate | 20.2 | % |  | 19.0 | % |  | 17.6 | % |  | 1.0 | % |  |  |

[0001571996-25-000127:mdna:109]
For the third quarter of Fiscal 2026 and Fiscal 2025, our effective income tax rates were 20.2% and 19.0%, respectively. For the first nine months of Fiscal 2026 and Fiscal 2025, our effective income tax rates were 17.6% and 1.0%, respectively. The changes in our effective tax rates for the Fiscal 2026 periods as compared to the Fiscal 2025 periods were primarily attributable to discrete tax items. For the first nine months of Fiscal 2025, we recorded discrete tax benefits of $0.4 billion related to changes in uncertain tax benefits resulting from the expiration of certain U.S. statutes of limitations and $0.2 billion related to stock-based compensation.

[0001571996-25-000127:mdna:110]
On July 4, 2025, the One Big Beautiful Bill Act (“OBBBA”) was enacted into law in the United States. The new law contains a broad range of tax reform provisions, which include the extension and modification of certain provisions of the Tax Cuts and Jobs Act. Effective for Fiscal 2026, changes include, but are not limited to, immediate expensing of domestic research and development expenditures, the restoration of 100% bonus depreciation, and an EBITDA-based interest expense limitation. These provisions did not have a material impact on the Company’s Condensed Consolidated Financial Statements for the first nine months of Fiscal 2026. Effective starting in Fiscal 2027, additional changes will include certain modifications to the international tax framework. We currently do not anticipate these changes to have a material impact to our results in future periods. The Company will continue to monitor any developments and guidance related to OBBBA.

[0001571996-25-000127:mdna:111]
Our effective income tax rate can fluctuate depending on the geographic distribution of our worldwide earnings, as our foreign earnings are generally taxed at lower rates than in the United States. The differences between our effective income tax rates and the U.S. federal statutory rate of 21% principally result from the geographical distribution of income, differences between the book and tax treatment of certain items, and discrete tax items. In certain jurisdictions, our tax rate is significantly less than the applicable statutory rate as a result of tax holidays. The majority of our foreign income subject to these tax holidays is attributable to Singapore and China. A significant portion of these income tax benefits relates to a tax holiday that will be effective until January 31, 2029. Most of our other tax holidays will expire in whole or in part during Fiscal 2030 and Fiscal 2031. Many of these tax holidays and reduced tax rates may be extended when certain conditions are met or may be terminated early if certain conditions are not met or as a result of changes in tax legislation. As of October 31, 2025, we were not aware of any matters of non-compliance.

[0001571996-25-000127:mdna:112]
Many countries, including Singapore, a country in which we have a tax holiday, have enacted or are in the process of enacting laws based on the Pillar Two proposal relating to a global minimum tax issued by the Organisation for Economic Co-operation and Development (“OECD”). While our effective income tax rate and cash income tax payments may increase in future years as a result of the global minimum tax, we do not expect this tax will have a material impact for Fiscal 2026. Our assessment could be affected by legislative guidance and future enactment of additional provisions within the OECD’s Pillar Two framework.

[0001571996-25-000127:mdna:113]
[same as prior period, unchanged from 0001571996-25-000102:mdna:114]

[0001571996-25-000127:mdna:114]
[same as prior period, unchanged from 0001571996-25-000102:mdna:115]

[0001571996-25-000127:mdna:115]
During the third quarter of Fiscal 2026, net income increased 32% to $1.5 billion primarily due to an increase in operating income. During the first nine months of Fiscal 2026, net income increased 21% to $3.7 billion primarily due to an increase in operating income and, to a lesser extent, a favorable change in interest and other, net, the effects of which were partially offset by higher income tax expense.

[0001571996-25-000127:mdna:116]
During both the third quarter and first nine months of Fiscal 2026, non-GAAP net income increased 11% to $1.8 billion and 12% to $4.4 billion, respectively, primarily due to an increase in operating income.

[0001571996-25-000127:mdna:117]
[same as prior period, unchanged from 0001571996-25-000102:mdna:148]

[0001571996-25-000127:mdna:118]
[same as prior period, unchanged from 0001571996-25-000102:mdna:118]

[0001571996-25-000127:mdna:119]
[same as prior period, unchanged from 0001571996-25-000102:mdna:119]

[0001571996-25-000127:mdna:120]
[same as prior period, unchanged from 0001571996-25-000102:mdna:120]

[0001571996-25-000127:mdna:121]
[same as prior period, unchanged from 0001571996-25-000102:mdna:121]

[0001571996-25-000127:mdna:122]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 31, 2025 |  | % Change |  | November 1, 2024 |  | October 31, 2025 |  | % Change |  | November 1, 2024 |  |  |  |  |
|  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Servers and networking | $ | 10,125 |  |  | 37 | % |  | $ | 7,364 |  | $ | 29,390 |  | 43 | % |  | $ | 20,502 |  |  |  |  |
| Storage | 3,982 |  |  | (1) | % |  | 4,004 |  | 11,834 |  | 1 | % |  | 11,739 |  |  |  |  |
| Total ISG net revenue | $ | 14,107 |  |  | 24 | % |  | $ | 11,368 |  | $ | 41,224 |  | 28 | % |  | $ | 32,241 |  |  |  |  |
| Operating income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| ISG operating income | $ | 1,743 |  |  | 16 | % |  | $ | 1,508 |  | $ | 4,211 |  | 19 | % |  | $ | 3,528 |  |  |  |  |
| % of segment net revenue | 12.4 | % |  |  |  | 13.3 | % |  | 10.2 | % |  |  |  | 10.9 | % |  |  |  |  |

[0001571996-25-000127:mdna:123]
Net Revenue — During the third quarter and first nine months of Fiscal 2026, ISG net revenue increased 24% and 28%, respectively, driven primarily by strength in our servers and networking offerings.

[0001571996-25-000127:mdna:124]
Servers and networking net revenue increased 37% and 43% during the third quarter and first nine months of Fiscal 2026, respectively. The increase was driven by growth primarily in our AI-optimized server offerings during the third quarter and first nine months of Fiscal 2026 and, to a lesser extent, our traditional servers and networking offerings during the first nine months of Fiscal 2026.

[0001571996-25-000127:mdna:125]
During the third quarter of Fiscal 2026, storage net revenue decreased 1% due to lower demand in our hyper-converged infrastructure offerings largely offset by an increase in our core storage offerings. During the first nine months of Fiscal 2026, storage net revenue increased 1% primarily due to an increase in our core storage offerings.

[0001571996-25-000127:mdna:126]
From a geographical perspective, ISG net revenue increased in the Americas, driven by our AI-optimized server offerings, during the third quarter and first nine months of Fiscal 2026 and, to a lesser extent, in EMEA and APJ during the first nine months of Fiscal 2026. ISG net revenue decreased in APJ and remained flat in EMEA during the third quarter of Fiscal 2026.

[0001571996-25-000127:mdna:127]
Operating Income — During the third quarter and first nine months of Fiscal 2026, ISG operating income as a percentage of net revenue decreased 90 basis points to 12.4% and 70 basis points to 10.2%, respectively, due to a decline in gross margin rate that outpaced the decline in operating expense rate. Gross margin rate decreased primarily as the result of a shift in mix towards our AI-optimized server offerings. Operating expense rate declined primarily due to strong ISG net revenue growth coupled with continued disciplined cost management.

[0001571996-25-000127:mdna:128]
68

[0001571996-25-000127:mdna:129]
[same as prior period, unchanged from 0001571996-25-000102:mdna:129]

[0001571996-25-000127:mdna:130]
[same as prior period, unchanged from 0001571996-25-000102:mdna:130]

[0001571996-25-000127:mdna:131]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 31, 2025 |  | % Change |  | November 1, 2024 |  | October 31, 2025 |  | % Change |  | November 1, 2024 |  |  |  |  |
|  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 10,621 |  |  | 5 | % |  | $ | 10,138 |  | $ | 32,448 |  | 5 | % |  | $ | 30,848 |  |  |  |  |
| Consumer | 1,857 |  |  | (7) | % |  | 1,993 |  | 5,042 |  | (11) | % |  | 5,664 |  |  |  |  |
| Total CSG net revenue | $ | 12,478 |  |  | 3 | % |  | $ | 12,131 |  | $ | 37,490 |  | 3 | % |  | $ | 36,512 |  |  |  |  |
| Operating income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| CSG operating income | $ | 748 |  |  | — | % |  | $ | 747 |  | $ | 2,204 |  | (6) | % |  | $ | 2,341 |  |  |  |  |
| % of segment net revenue | 6.0 | % |  |  |  | 6.2 | % |  | 5.9 | % |  |  |  | 6.4 | % |  |  |  |  |

[0001571996-25-000127:mdna:132]
Net Revenue — During both the third quarter and first nine months of Fiscal 2026, CSG net revenue increased 3%, driven primarily by strength in our commercial offerings, partially offset by our consumer offerings.

[0001571996-25-000127:mdna:133]
During both the third quarter and first nine months of Fiscal 2026, commercial net revenue increased 5% primarily due to an increase in units sold and richer configurations, partially offset by a decline in average selling prices.

[0001571996-25-000127:mdna:134]
Consumer net revenue decreased 7% during the third quarter of Fiscal 2026, primarily due to mix of configurations. Consumer net revenue decreased 11% during the first nine months of Fiscal 2026 due to a decline in units sold and mix of configurations.

[0001571996-25-000127:mdna:135]
From a geographical perspective, net revenue attributable to CSG increased in EMEA and remained flat in the Americas and APJ during the third quarter and first nine months of Fiscal 2026.

[0001571996-25-000127:mdna:136]
Operating Income — During the third quarter and first nine months of Fiscal 2026, CSG operating income as a percentage of net revenue decreased 20 basis points to 6.0% and 50 basis points to 5.9%, respectively. The decline in operating income rate during the first nine months of Fiscal 2026 was primarily due to a decline in gross margin rate driven by a change in mix within our offerings.

[0001571996-25-000127:mdna:137]
[same as prior period, unchanged from 0001571996-25-000102:mdna:137]

[0001571996-25-000127:mdna:138]
[same as prior period, unchanged from 0001571996-25-000102:mdna:138]

[0001571996-25-000127:mdna:139]
We sell products and services directly to customers and through a variety of sales channels, including retail distribution. Our accounts receivable, net was $11.7 billion and $10.3 billion as of October 31, 2025 and January 31, 2025, respectively. The increase in accounts receivable, net was primarily driven by an increase in net revenue largely due to our AI-optimized offerings. We maintain an allowance for expected credit losses to cover receivables that may be deemed uncollectible. The allowance for expected credit losses is an estimate based on an analysis of historical loss experience, current receivables aging, and management’s assessment of current conditions and its reasonable and supportable expectation of future conditions, as well as specific identifiable customer accounts that are deemed at risk. As of October 31, 2025 and January 31, 2025, the allowance for expected credit losses was $75 million and $63 million, respectively. Based on our assessment, we believe that we are adequately reserved for expected credit losses.

[0001571996-25-000127:mdna:140]
[same as prior period, unchanged from 0001571996-25-000102:mdna:140]

[0001571996-25-000127:mdna:141]
We offer or arrange a portfolio of payment and consumption solutions and services for our customers globally, including as-a-Service, subscription, utility, leases, and loans, designed to match customers' consumption and financing preferences. We believe these options provide operational and financial flexibility and strengthen our customer relationships. To support financing solutions and services as part of the portfolio, DFS originates, collects, and services customer receivables primarily related to the purchase of our product and services solutions. New financing originations were $3.1 billion and $1.6 billion for the third quarter of Fiscal 2026 and Fiscal 2025, respectively, and $7.1 billion and $5.9 billion for the first nine months of Fiscal 2026 and Fiscal 2025, respectively.

[0001571996-25-000127:mdna:142]
[same as prior period, unchanged from 0001571996-25-000102:mdna:142]

[0001571996-25-000127:mdna:143]
As of October 31, 2025 and January 31, 2025, our financing receivables, net were $13.2 billion and $11.2 billion, respectively. The increase in financing receivables, net was primarily attributable to our AI-optimized offerings. We maintain an allowance to cover expected financing receivables credit losses and evaluate credit loss expectations based on our total portfolio. The principal charge-off rate for our financing receivables portfolio was 0.2% and 1.4% for the third quarter of Fiscal 2026 and Fiscal 2025, respectively, and 0.2% and 0.8% for the first nine months of Fiscal 2026 and Fiscal 2025, respectively. The credit quality of our financing receivables remains strong due to the mix of high-quality commercial accounts in our portfolio. We continue to monitor broader economic indicators and their potential impact on future credit loss performance. We have an extensive process to manage our exposure to customer credit risk that includes active management of credit lines and collection activities. We also sell select fixed-term financing receivables without recourse to unrelated third parties on a periodic basis, primarily to manage certain concentrations of customer credit exposure. Based on our assessment of the customer financing receivables, we believe that we are adequately reserved.

[0001571996-25-000127:mdna:144]
We retain a residual interest in equipment leased under our lease programs. As of October 31, 2025 and January 31, 2025, the residual interest recorded as part of financing receivables was $186 million and $168 million, respectively. The amount of the residual interest is established at the inception of the lease based upon estimates of the value of the equipment at the end of the lease term using historical studies, industry data, and future value-at-risk demand valuation methods. On a quarterly basis, we assess the carrying amount of our recorded residual values for expected losses. Generally, expected losses as a result of residual value risk on equipment under lease are not considered to be significant primarily because of the existence of a secondary market with respect to the equipment. Further, the lease agreement defines applicable return conditions and remedies for non-compliance to ensure that the leased equipment will be in good operating condition upon return. No expected losses were recorded related to residual assets during the third quarter and first nine months of Fiscal 2026 and Fiscal 2025.

[0001571996-25-000127:mdna:145]
As of October 31, 2025 and January 31, 2025, equipment under operating leases, net was $2.4 billion and $2.2 billion, respectively. We assess the carrying amount of the equipment under operating leases for impairment whenever events or circumstances may indicate that an impairment has occurred. No material impairment losses were recorded related to such equipment during the third quarter and first nine months of Fiscal 2026 and Fiscal 2025.

[0001571996-25-000127:mdna:146]
[same as prior period, unchanged from 0001571996-25-000102:mdna:146]

[0001571996-25-000127:mdna:147]
[same as prior period, unchanged from 0001571996-25-000102:mdna:147]

[0001571996-25-000127:mdna:148]
71

[0001571996-25-000127:mdna:149]
[same as prior period, unchanged from 0001571996-25-000102:mdna:149]

[0001571996-25-000127:mdna:150]
[same as prior period, unchanged from 0001571996-25-000102:mdna:150]

[0001571996-25-000127:mdna:151]
[same as prior period, unchanged from 0001571996-25-000102:mdna:151]

[0001571996-25-000127:mdna:152]
[same as prior period, unchanged from 0001571996-25-000102:mdna:152]

[0001571996-25-000127:mdna:153]
We believe that our current cash and cash equivalents, together with cash that will be provided by future operations and borrowings and issuances expected to be available under our revolving credit facility and commercial paper program, will be sufficient over the next twelve months and for the foreseeable future thereafter to meet our material cash requirements, including funding of our operations, debt-related payments, capital expenditures, and other corporate needs.

[0001571996-25-000127:mdna:154]
[same as prior period, unchanged from 0001571996-25-000102:mdna:154]

[0001571996-25-000127:mdna:155]
[same as prior period, unchanged from 0001571996-25-000102:mdna:155]

[0001571996-25-000127:mdna:156]
|  | October 31, 2025 |  | January 31, 2025 |
|  | (in millions) |
| Cash and cash equivalents, and available borrowings: |  |  |  |
| Cash and cash equivalents | $ | 9,569 |  |  | $ | 3,633 |  |
| Remaining available borrowings under the revolving credit facility | 5,886 |  |  | 5,999 |  |
| Total cash and cash equivalents, and available borrowings | $ | 15,455 |  |  | $ | 9,632 |  |

[0001571996-25-000127:mdna:157]
During the first nine months of Fiscal 2026, cash and cash equivalents increased by $5.9 billion primarily due to an increase in cash flows from operations, net debt from the issuance of Senior Notes and DFS debt, and the proceeds from the sale of Secureworks, the effects of which were partially offset by the return of capital to our stockholders, capital expenditures, and payments to settle employee tax withholdings on stock-based compensation.

[0001571996-25-000127:mdna:158]
As of October 31, 2025, our revolving credit facility had a maximum capacity of $6.0 billion. Available borrowings under this facility are reduced by draws on the facility and outstanding letters of credit. As of October 31, 2025, there were no borrowings outstanding under the facility and remaining available borrowings totaled approximately $5.9 billion. The revolving credit facility also acts as a backstop to provide liquidity support for our commercial paper program.

[0001571996-25-000127:mdna:159]
We maintain a commercial paper program under which we may issue unsecured notes in a maximum aggregate face amount of $5.0 billion outstanding at any time, with maturities of up to 397 days from the date of issue. As of October 31, 2025, we had no outstanding issuances under the program.

[0001571996-25-000127:mdna:160]
We may regularly use our available borrowings from the revolving credit facility and issuances under the commercial paper program, generally on a short-term basis, for general corporate purposes. See the following discussion for additional information about our debt.

[0001571996-25-000127:mdna:161]
[same as prior period, unchanged from 0001571996-25-000102:mdna:194]

[0001571996-25-000127:mdna:162]
[same as prior period, unchanged from 0001571996-25-000102:mdna:161]

[0001571996-25-000127:mdna:163]
[same as prior period, unchanged from 0001571996-25-000102:mdna:162]

[0001571996-25-000127:mdna:164]
|  | October 31, 2025 |  | Change |  | January 31, 2025 |
|  | (in millions) |
| Core debt |  |  |  |  |  |
| Senior Notes | $ | 21,573 |  |  | $ | 6,500 |  |  | $ | 15,073 |  |
| Legacy Notes | 952 |  |  | — |  |  | 952 |  |
| DFS allocated debt | (4,659) |  |  | (1,631) |  |  | (3,028) |  |
| Total core debt | 17,866 |  |  | 4,869 |  |  | 12,997 |  |
| DFS related debt |  |  |  |  |  |
| DFS debt | 8,905 |  |  | 194 |  |  | 8,711 |  |
| DFS allocated debt | 4,659 |  |  | 1,631 |  |  | 3,028 |  |
| Total DFS related debt | 13,564 |  |  | 1,825 |  |  | 11,739 |  |
| Other | 85 |  |  | 33 |  |  | 52 |  |
| Total debt, principal amount | 31,515 |  |  | 6,727 |  |  | 24,788 |  |
| Carrying value adjustments | (272) |  |  | (51) |  |  | (221) |  |
| Total debt, carrying value | $ | 31,243 |  |  | $ | 6,676 |  |  | $ | 24,567 |  |

[0001571996-25-000127:mdna:165]
The outstanding principal amount of our debt increased $6.7 billion to $31.5 billion as of October 31, 2025, driven primarily by an increase in net debt from the issuance of Senior Notes.

[0001571996-25-000127:mdna:166]
We define core debt as the total principal amount of our debt, less DFS related debt and other debt. Our core debt was $17.9 billion and $13.0 billion as of October 31, 2025 and January 31, 2025, respectively. See Note 6 of the Notes to the Condensed Consolidated Financial Statements included in this report for additional information about our debt.

[0001571996-25-000127:mdna:167]
DFS debt primarily represents debt from our securitization and structured financing programs. Our risk of loss under these programs is limited to transferred lease and loan payments and associated equipment, as the credit holders have no recourse to Dell Technologies.

[0001571996-25-000127:mdna:168]
[same as prior period, unchanged from 0001571996-25-000102:mdna:167]

[0001571996-25-000127:mdna:169]
[same as prior period, unchanged from 0001571996-25-000102:mdna:168]

[0001571996-25-000127:mdna:170]
|  | October 31, 2025 |  | January 31, 2025 |
|  | (in millions) |
| Financing receivables, net | $ | 13,152 |  |  | $ | 11,231 |  |
| Equipment under operating leases, net | 2,350 |  |  | 2,185 |  |
| DFS owned assets | $ | 15,502 |  |  | $ | 13,416 |  |

[0001571996-25-000127:mdna:171]
We believe we will continue to be able to make our debt principal and interest payments, including payment of short-term maturities, from existing and expected sources of cash. Cash used for debt principal and interest payments may include operating cash flows, short-term borrowings under our commercial paper program or our revolving credit facility, or other borrowings. Under our variable-rate debt, we could experience variations in our future interest expense from potential fluctuations in applicable reference rates, or from possible fluctuations in the level of DFS debt required to meet future demand for customer financing.

[0001571996-25-000127:mdna:172]
[same as prior period, unchanged from 0001571996-25-000102:mdna:202]

[0001571996-25-000127:mdna:173]
[same as prior period, unchanged from 0001571996-25-000102:mdna:172]

[0001571996-25-000127:mdna:174]
[same as prior period, unchanged from 0001571996-25-000102:mdna:173]

[0001571996-25-000127:mdna:175]
[same as prior period, unchanged from 0001571996-25-000102:mdna:174]

[0001571996-25-000127:mdna:176]
|  | Nine Months Ended |
|  | October 31, 2025 |  | November 1, 2024 |  |  |
|  | (in millions) |
| Net change in cash from: |  |  |  |  |  |
| Operating activities | $ | 6,511 |  |  | $ | 3,936 |  |  |  |
| Investing activities | (1,360) |  |  | (1,537) |  |  |  |
| Financing activities | 629 |  |  | (4,424) |  |  |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash | 134 |  |  | (78) |  |  |  |
| Change in cash, cash equivalents, and restricted cash | $ | 5,914 |  |  | $ | (2,103) |  |  |  |

[0001571996-25-000127:mdna:177]
Operating Activities — Cash provided by operating activities was $6.5 billion during the first nine months of Fiscal 2026 and was driven by net revenue growth and profitability, partially offset by higher financing receivables and working capital levels, both of which were primarily impacted by increased demand for our AI-optimized server offerings. During the first nine months of Fiscal 2025, cash provided by operating activities was $3.9 billion and was driven by profitability, partially offset by working capital dynamics. Working capital was primarily impacted by AI dynamics, which led to higher inventory, accounts receivable, and accounts payable levels.

[0001571996-25-000127:mdna:178]
Investing Activities — Investing activities primarily consist of cash used to fund capital expenditures for property, plant, and equipment inclusive of equipment under operating leases and equipment used to support our as-a-Service offerings, which we refer to collectively as assets in a customer contract. Additional activities may include capitalized software development costs, the maturities, sales, and purchases of investments, and acquisitions and divestitures. Cash used in investing activities was $1.4 billion during the first nine months of Fiscal 2026 and consisted of cash used for capital expenditures, partially offset by cash proceeds from the sale of Secureworks. Cash used in investing activities was $1.5 billion during the first nine months of Fiscal 2025 and was primarily used for capital expenditures.

[0001571996-25-000127:mdna:179]
Financing Activities — Financing activities primarily consist of the proceeds and repayments of debt and return of capital to our stockholders. Cash provided by financing activities was $0.6 billion during the first nine months of Fiscal 2026 and primarily consisted of net proceeds from the issuance of Senior Notes and DFS debt, partially offset by repurchases of common stock, inclusive of payments to settle employee tax withholdings on stock-based compensation, and the payment of quarterly dividends. Cash used in financing activities was $4.4 billion during the first nine months of Fiscal 2025 and primarily consisted of repurchases of common stock, inclusive of payments to settle employee tax withholdings on stock-based compensation, net repayments on our Senior Notes and DFS debt, and the payment of quarterly dividends.

[0001571996-25-000127:mdna:180]
DFS Cash Flow Impacts — DFS offerings are initially funded through cash on hand at the time of origination, most of which is subsequently replaced with asset-backed financing. For offerings that qualify as sales-type leases, the initial funding of financing receivables is reflected as an impact to cash flows from operations and is largely subsequently offset by cash proceeds from financing. For offerings that qualify as operating leases, the initial funding is classified as a capital expenditure and reflected as cash flows used in investing activities. DFS new financing originations were $7.1 billion and $5.9 billion during the first nine months of Fiscal 2026 and Fiscal 2025, respectively. As of October 31, 2025, we had $13.2 billion of total net financing receivables and $2.4 billion of equipment under operating leases, net.

[0001571996-25-000127:mdna:181]
[same as prior period, unchanged from 0001571996-25-000102:mdna:180]

[0001571996-25-000127:mdna:182]
[same as prior period, unchanged from 0001571996-25-000102:mdna:181]

[0001571996-25-000127:mdna:183]
Capital Expenditures — We spent $1.9 billion during both the first nine months of Fiscal 2026 and Fiscal 2025 on property, plant, and equipment and capitalized software development costs. Of total expenditures incurred, funding of assets in a customer contract totaled $1.0 billion during both the first nine months of Fiscal 2026 and Fiscal 2025. Product demand, product mix, the use of contract manufacturers, and ongoing investments in operating and information technology infrastructure influence the level and prioritization of our capital expenditures.

[0001571996-25-000127:mdna:184]
[same as prior period, unchanged from 0001571996-25-000102:mdna:183]

[0001571996-25-000127:mdna:185]
During the first nine months of Fiscal 2026, we repurchased approximately 39 million shares of Class C Common Stock for a total purchase price of approximately $4.2 billion. During the first nine months of Fiscal 2025, we repurchased approximately 16 million shares of Class C Common Stock for a total purchase price of approximately $1.8 billion.

[0001571996-25-000127:mdna:186]
Dividend Payments — During the first nine months of Fiscal 2026 and Fiscal 2025, the Company paid $1.1 billion and $1.0 billion in dividends and dividend equivalents, respectively, at a rate of $0.525 and $0.445 per share per fiscal quarter, respectively.

[0001571996-25-000127:mdna:187]
[same as prior period, unchanged from 0001571996-25-000102:mdna:186]

[0001571996-25-000127:mdna:188]
[same as prior period, unchanged from 0001571996-25-000102:mdna:187]

[0001571996-25-000127:mdna:189]
As of October 31, 2025, we had purchase obligations of $8.5 billion, of which $6.5 billion is payable within twelve months.

[0001571996-25-000127:mdna:190]
[same as prior period, unchanged from 0001571996-25-000102:mdna:189]

[0001571996-25-000127:mdna:191]
[same as prior period, unchanged from 0001571996-25-000102:mdna:190]

[0001571996-25-000127:mdna:192]
[same as prior period, unchanged from 0001571996-25-000102:mdna:191]

[0001571996-25-000127:mdna:193]
[same as prior period, unchanged from 0001571996-25-000102:mdna:192]

[0001571996-25-000127:mdna:194]
[same as prior period, unchanged from 0001571996-25-000102:mdna:193]

[0001571996-25-000127:mdna:195]
76

[0001571996-25-000127:mdna:196]
[same as prior period, unchanged from 0001571996-25-000102:mdna:195]

[0001571996-25-000127:mdna:197]
[same as prior period, unchanged from 0001571996-25-000102:mdna:196]

[0001571996-25-000127:mdna:198]
[same as prior period, unchanged from 0001571996-25-000102:mdna:197]

[0001571996-25-000127:mdna:199]
[same as prior period, unchanged from 0001571996-25-000102:mdna:198]

[0001571996-25-000127:mdna:200]
|  | Nine Months Ended |
|  | October 31, 2025 |
|  | (in millions) |
| Net revenue | $ | 5,899 |  |
| Gross margin | 3,013 |  |
| Operating income | 733 |  |
| Interest and other, net | (3,031) |  |
| Loss before income taxes | $ | (2,298) |  |
| Net loss attributable to Obligor Group (a) | $ | (1,704) |  |

[0001571996-25-000127:mdna:201]
[same as prior period, unchanged from 0001571996-25-000102:mdna:200]

[0001571996-25-000127:mdna:202]
(a)Includes net loss from intercompany transactions with Non-Obligor Subsidiaries of $3,299 million, which primarily consists of interest expense, shared services, and the resale of solutions.

[0001571996-25-000127:mdna:203]
[same as prior period, unchanged from 0001571996-25-000102:mdna:203]

[0001571996-25-000127:mdna:204]
|  | October 31, 2025 |  | January 31, 2025 |
|  | (in millions) |
| ASSETS |
| Current assets | $ | 3,057 |  |  | $ | 3,132 |  |
| Intercompany receivables | — |  |  | 175 |  |
| Total current assets | 3,057 |  |  | 3,307 |  |
| Goodwill and intangible assets | 13,858 |  |  | 14,073 |  |
| Other non-current assets | 3,305 |  |  | 3,412 |  |
| Total assets | $ | 20,220 |  |  | $ | 20,792 |  |
| LIABILITIES |
| Current liabilities | $ | 5,668 |  |  | $ | 4,097 |  |
| Intercompany payable | 440 |  |  | — |  |
| Total current liabilities | 6,108 |  |  | 4,097 |  |
| Long-term debt | 20,028 |  |  | 15,824 |  |
| Long-term intercompany loan payables | 44,372 |  |  | 44,516 |  |
| Other non-current liabilities | 3,063 |  |  | 3,339 |  |
| Total liabilities | $ | 73,571 |  |  | $ | 67,776 |  |

[0001571996-25-000127:mdna:205]
78
