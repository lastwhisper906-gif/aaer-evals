# DELL 8-K — 0001571996-25-000118 filed 2025-11-25

## item codes, every 8-K on or before 2025-12-09

- 2025-11-25 0001571996-25-000120 — 5.02 — amendment of 0001571996-25-000104
- 2025-11-25 0001571996-25-000118 — 2.02, 9.01
- 2025-10-17 0001571996-25-000114 — 5.02 — amendment of 0001571996-25-000093
- 2025-10-07 0001193125-25-232662 — 7.01, 9.01
- 2025-10-06 0001193125-25-231904 — 1.01, 2.03, 9.01
- 2025-10-02 0001571996-25-000112 — 5.02 — amendment of 0001571996-25-000104
- 2025-10-02 0001571996-25-000111 — 5.02, 9.01
- 2025-09-26 0001571996-25-000107 — 3.02
- 2025-09-23 0001193125-25-213629 — 8.01, 9.01
- 2025-09-08 0001571996-25-000104 — 5.02
- 2025-08-28 0001571996-25-000096 — 2.02, 9.01
- 2025-08-12 0001571996-25-000093 — 5.02
- 2025-07-16 0001571996-25-000081 — 3.02
- 2025-07-01 0001571996-25-000078 — 5.07
- 2025-05-29 0001571996-25-000046 — 2.02, 9.01
- 2025-04-01 0001193125-25-070461 — 1.01, 2.03, 9.01
- 2025-03-27 0001193125-25-065594 — 8.01, 9.01
- 2025-02-27 0001571996-25-000014 — 2.02, 8.01, 9.01
- 2025-01-14 0001571996-25-000004 — 3.02
- 2024-12-03 0001571996-24-000136 — 3.02
- 2024-11-26 0001571996-24-000130 — 2.02, 9.01
- 2024-10-08 0001193125-24-234446 — 1.01, 2.03, 9.01
- 2024-10-02 0001193125-24-231195 — 8.01, 9.01
- 2024-09-19 0001571996-24-000105 — 3.02
- 2024-08-29 0001571996-24-000081 — 2.02, 9.01
- 2024-07-12 0001193125-24-178608 — 3.02
- 2024-07-02 0001571996-24-000074 — 5.07
- 2024-06-10 0001571996-24-000059 — 3.02
- 2024-05-30 0001571996-24-000050 — 2.02, 9.01
- 2024-03-26 0001571996-24-000038 — 3.02
- 2024-03-18 0001193125-24-070193 — 1.01, 2.03, 9.01
- 2024-03-07 0001571996-24-000012 — 3.02
- 2024-03-06 0001193125-24-059631 — 8.01, 9.01
- 2024-02-29 0001571996-24-000008 — 2.02, 9.01
- 2024-01-30 0001571996-24-000004 — 1.02
- 2024-01-18 0001571996-24-000002 — 3.02
- 2023-12-18 0001193125-23-297664 — 8.01, 9.01
- 2023-12-05 0001571996-23-000042 — 3.02
- 2023-12-04 0001193125-23-288428 — 8.01, 9.01
- 2023-11-30 0001571996-23-000039 — 2.02, 9.01
- 2023-10-05 0001193125-23-251131 — 7.01, 8.01, 9.01
- 2023-10-02 0001571996-23-000036 — 5.02 — amendment of 0001571996-23-000034
- 2023-09-26 0001571996-23-000034 — 5.02
- 2023-08-31 0001571996-23-000029 — 2.02, 9.01
- 2023-08-09 0001571996-23-000026 — 5.02 — amendment of 0001571996-23-000002
- 2023-07-28 0001571996-23-000024 — 5.02
- 2023-07-13 0001193125-23-186639 — 3.02
- 2023-06-30 0001193125-23-180570 — 8.01, 9.01
- 2023-06-22 0001571996-23-000021 — 5.02, 5.07, 9.01
- 2023-06-15 0001193125-23-167472 — 8.01, 9.01
- 2023-06-01 0001571996-23-000014 — 2.02, 9.01
- 2023-03-02 0001571996-23-000002 — 2.02, 5.02, 9.01
- 2023-02-06 0001193125-23-024781 — 7.01, 9.01
- 2023-01-24 0001193125-23-014260 — 1.01, 2.03, 9.01
- 2023-01-11 0001193125-23-006528 — 8.01, 9.01
- 2022-11-21 0001571996-22-000041 — 2.02, 9.01
- 2022-11-16 0001571996-22-000038 — 8.01
- 2022-08-25 0001571996-22-000028 — 2.02, 9.01
- 2022-07-18 0001193125-22-196334 — 2.03, 8.01
- 2022-06-29 0001571996-22-000025 — 3.03, 5.03, 5.07, 8.01, 9.01
- 2022-05-26 0001571996-22-000013 — 2.02, 9.01
- 2022-02-24 0001571996-22-000004 — 2.02, 8.01, 9.01
- 2021-12-20 0001193125-21-362482 — 8.01, 9.01
- 2021-12-15 0001193125-21-357927 — 1.01, 2.03, 9.01
- 2021-12-07 0001193125-21-349218 — 8.01, 9.01
- 2021-11-23 0001571996-21-000060 — 2.02, 9.01
- 2021-11-05 0001571996-21-000057 — 1.02, 2.01, 7.01, 8.01, 9.01 — amendment, the index does not say of what
- 2021-11-01 0001571996-21-000052 — 8.01, 9.01
- 2021-11-01 0001193125-21-315488 — 1.01, 1.02, 2.01, 8.01, 9.01
- 2021-10-21 0001193125-21-304052 — 8.01, 9.01
- 2021-10-19 0001571996-21-000050 — 8.01, 9.01
- 2021-10-07 0001193125-21-294210 — 8.01, 9.01
- 2021-09-30 0001571996-21-000047 — 5.02
- 2021-09-27 0001571996-21-000045 — 8.01
- 2021-09-23 0001193125-21-280190 — 7.01, 8.01, 9.01
- 2021-09-20 0001193125-21-276810 — 7.01, 9.01
- 2021-08-26 0001571996-21-000037 — 2.02, 9.01
- 2021-07-01 0001571996-21-000034 — 3.02
- 2021-06-24 0001571996-21-000031 — 5.07
- 2021-06-24 0001193125-21-197644 — 7.01, 9.01
- 2021-06-16 0001571996-21-000029 — 5.02
- 2021-05-27 0001571996-21-000019 — 2.02, 9.01
- 2021-05-03 0001571996-21-000010 — 8.01, 9.01
- 2021-04-14 0001193125-21-116271 — 1.01, 7.01, 9.01
- 2021-02-25 0001571996-21-000003 — 2.02, 9.01
- 2021-02-18 0001193125-21-047844 — 1.01, 2.03, 9.01
- 2020-11-24 0001571996-20-000048 — 2.02, 9.01
- 2020-08-27 0001571996-20-000041 — 2.02, 9.01
- 2020-07-02 0001571996-20-000037 — 5.07
- 2020-05-28 0001571996-20-000028 — 2.02, 9.01
- 2020-04-09 0001193125-20-102602 — 1.01, 2.03, 9.01
- 2020-04-08 0001571996-20-000021 — 5.02
- 2020-04-03 0001571996-20-000019 — 8.01, 9.01
- 2020-03-26 0001571996-20-000015 — 7.01
- 2020-02-27 0001571996-20-000009 — 2.02, 8.01, 9.01
- 2020-02-18 0001571996-20-000005 — 8.01, 9.01
- 2020-01-09 0001571996-20-000002 — 3.02
- 2020-01-06 0001193125-20-002200 — 3.02
- 2019-12-13 0001193125-19-313947 — 3.02
- 2019-12-10 0001571996-19-000052 — 5.02
- 2019-12-02 0001571996-19-000044 — 5.02, 7.01, 9.01
- 2019-11-26 0001571996-19-000042 — 2.02, 9.01
- 2019-09-23 0001193125-19-252192 — 1.01, 2.03, 9.01
- 2019-08-29 0001571996-19-000036 — 2.02, 9.01
- 2019-08-22 0001193125-19-226939 — 7.01, 8.01, 9.01
- 2019-07-11 0001571996-19-000032 — 5.02, 5.07, 9.01
- 2019-07-03 0001571996-19-000030 — 3.02
- 2019-06-27 0001571996-19-000028 — 3.02
- 2019-05-30 0001571996-19-000021 — 2.02, 9.01
- 2019-04-02 0001571996-19-000010 — 5.02
- 2019-03-21 0001193125-19-082281 — 1.01, 1.02, 2.03, 9.01
- 2019-03-19 0001571996-19-000005 — 5.02, 9.01
- 2019-03-14 0001193125-19-074935 — 1.01, 2.03, 9.01
- 2019-03-07 0001193125-19-066045 — 8.01, 9.01
- 2019-02-28 0001571996-19-000002 — 2.02, 9.01
- 2018-12-28 0001193125-18-360943 — 1.01, 1.02, 3.01, 3.03, 5.02, 5.03, 7.01, 8.01, 9.01
- 2018-12-21 0001193125-18-356324 — 1.01, 2.03, 9.01
- 2018-12-14 0001193125-18-349469 — 8.01
- 2018-12-11 0001193125-18-346958 — 5.07, 8.01, 9.01
- 2018-11-29 0001571996-18-000041 — 2.02, 9.01
- 2018-11-28 0001571996-18-000037 — 7.01, 8.01, 9.01
- 2018-11-26 0001193125-18-333967 — 8.01, 9.01
- 2018-11-15 0001193125-18-328110 — 1.01, 9.01 — amendment of 0001193125-18-327222
- 2018-11-15 0001193125-18-327222 — 1.01, 7.01, 9.01
- 2018-10-03 0001193125-18-291390 — 8.01
- 2018-09-06 0001571996-18-000029 — 2.02, 9.01
- 2018-08-06 0001571996-18-000027 — 8.01, 9.01
- 2018-07-02 0001193125-18-210339 — 1.01, 7.01, 9.01
- 2018-06-28 0001571996-18-000024 — 5.07
- 2018-06-04 0001571996-18-000019 — 2.02, 9.01
- 2018-05-17 0001571996-18-000016 — 7.01
- 2018-04-26 0001571996-18-000009 — 7.01, 9.01
- 2018-03-08 0001193125-18-074168 — 2.02, 9.01
- 2018-02-02 0001193125-18-029947 — 7.01, 9.01
- 2017-12-07 0001571996-17-000042 — 2.02, 9.01
- 2017-10-24 0001571996-17-000037 — 1.01, 2.03, 9.01
- 2017-09-15 0001571996-17-000027 — 5.02
- 2017-09-07 0001571996-17-000017 — 2.02, 9.01
- 2017-08-24 0001571996-17-000014 — 8.01
- 2017-06-29 0001571996-17-000011 — 3.03, 5.07, 8.01, 9.01
- 2017-06-08 0001193125-17-197638 — 2.02, 9.01
- 2017-03-30 0001193125-17-102794 — 8.01
- 2017-03-30 0001193125-17-102777 — 2.02, 9.01
- 2017-03-09 0001193125-17-076981 — 1.01, 2.03, 9.01
- 2017-01-17 0001193125-17-011125 — 8.01
- 2016-12-15 0001193125-16-793722 — 8.01
- 2016-12-08 0001193125-16-787976 — 2.02, 9.01
- 2016-11-10 0001193125-16-765964 — 1.02, 8.01
- 2016-11-04 0001193125-16-760249 — 8.01
- 2016-09-13 0001193125-16-708600 — 3.02
- 2016-09-09 0001193125-16-706567 — 1.01, 1.02, 2.01, 2.03, 3.02, 3.03, 5.02, 9.01
- 2016-09-07 0001193125-16-703370 — 3.03, 5.07, 7.01, 8.01, 9.01
- 2016-09-06 0001193125-16-702057 — 2.02, 9.01
- 2016-08-31 0001193125-16-697268 — 8.01, 9.01
- 2016-08-26 0001193125-16-692921 — 8.01, 9.01
- 2016-07-11 0001193125-16-645610 — 8.01
- 2016-07-05 0001193125-16-641679 — 8.01
- 2016-06-22 0001193125-16-629055 — 1.01, 2.03, 8.01, 9.01
- 2016-06-21 0001193125-16-627071 — 8.01, 9.01
- 2016-06-10 0001193125-16-618483 — 2.02, 9.01
- 2016-06-09 0001193125-16-617893 — 8.01, 9.01

## late-filing notifications on or before 2025-12-09

- none on or before 2025-12-09

## item 2.02 — earnings release, exhibit 99.1

[0001571996-25-000118:8k_2_02:1]
EX-99.1
2
exhibit991earnings8kq3fy26.htm
EX-99.1

[0001571996-25-000118:8k_2_02:2]
Document

[0001571996-25-000118:8k_2_02:3]
Exhibit 99.1

[0001571996-25-000118:8k_2_02:4]
Dell Technologies Delivers Third Quarter Fiscal 2026 Financial Results

[0001571996-25-000118:8k_2_02:5]
ROUND ROCK, Texas — November 25, 2025 — Dell Technologies (NYSE: DELL) announces financial results for its fiscal 2026 third quarter and provides guidance for its fiscal 2026 fourth quarter and full year. The company also names David Kennedy its chief financial officer on a permanent basis.

[0001571996-25-000118:8k_2_02:6]
Third-Quarter Summary

[0001571996-25-000118:8k_2_02:7]
•Record third-quarter revenue of $27.0 billion, up 11% year over year

[0001571996-25-000118:8k_2_02:8]
•Diluted earnings per share (EPS) of $2.28, up 39% year over year, and record third-quarter non-GAAP diluted EPS of $2.59, up 17%

[0001571996-25-000118:8k_2_02:9]
•Cash flow from operations of $1.2 billion

[0001571996-25-000118:8k_2_02:10]
“In the third quarter we delivered record Q3 revenue of $27 billion, record Q3 profitability, strong cash generation and above-trend capital return of $1.6 billion,” said David Kennedy, chief financial officer, Dell Technologies. “FY26 will be another record year, and we’re raising our AI shipment guidance to roughly $25 billion, up over 150% year over year, and revenue guidance to $111.7 billion, up 17%.”

[0001571996-25-000118:8k_2_02:11]
“AI momentum is accelerating in the second half of the year, leading to record AI server orders of $12.3 billion and an unprecedented $30 billion in orders year to date,” said Jeff Clarke, vice chairman and chief operating officer, Dell Technologies. “Our five-quarter pipeline is multiples of our $18.4 billion backlog with a mix of neocloud, sovereign and enterprise customers. Dell is winning in AI because of our unique ability to engineer bespoke high-performance solutions, rapidly deploy large, complex clusters, and provide global support.”

[0001571996-25-000118:8k_2_02:12]
Infrastructure Solutions Group (ISG)

[0001571996-25-000118:8k_2_02:13]
•Record third-quarter revenue: $14.1 billion, up 24% year over year

[0001571996-25-000118:8k_2_02:14]
•Record third-quarter Servers and Networking revenue: $10.1 billion, up 37%

[0001571996-25-000118:8k_2_02:15]
•Storage revenue: $4.0 billion, down 1%

[0001571996-25-000118:8k_2_02:16]
•Record third-quarter operating income: $1.7 billion, up 16% year over year

[0001571996-25-000118:8k_2_02:17]
Client Solutions Group (CSG)

[0001571996-25-000118:8k_2_02:18]
•Revenue: $12.5 billion, up 3% year over year

[0001571996-25-000118:8k_2_02:19]
•Commercial Client revenue: $10.6 billion, up 5%

[0001571996-25-000118:8k_2_02:20]
•Consumer revenue: $1.9 billion, down 7%

[0001571996-25-000118:8k_2_02:21]
•Operating income: $748 million, flat year over year

[0001571996-25-000118:8k_2_02:22]
Capital Return

[0001571996-25-000118:8k_2_02:23]
Dell Technologies returned $1.6 billion to shareholders in the third quarter through share repurchases and dividends. Year to date, the company has returned $5.3 billion to shareholders and repurchased over 39 million shares.

[0001571996-25-000118:8k_2_02:24]
1

[0001571996-25-000118:8k_2_02:25]
Guidance Summary

[0001571996-25-000118:8k_2_02:26]
•Full-year FY26 revenue expected between $111.2 billion and $112.2 billion, up 17% year over year at the midpoint of $111.7 billion

[0001571996-25-000118:8k_2_02:27]
•Full-year AI server shipments expected to be roughly $25 billion, up over 150%

[0001571996-25-000118:8k_2_02:28]
•Full-year FY26 GAAP diluted EPS expected to be $8.38 at the midpoint, up 31% year over year, and non-GAAP diluted EPS to be $9.92 at the midpoint, up 22%

[0001571996-25-000118:8k_2_02:29]
•Fourth-quarter FY26 revenue expected between $31.0 billion and $32.0 billion, up 32% year over year at the midpoint of $31.5 billion

[0001571996-25-000118:8k_2_02:30]
•Fourth-quarter FY26 GAAP diluted EPS expected to be $3.05 at the midpoint, up 42% year over year, and non-GAAP diluted EPS to be $3.50 at the midpoint, up 31%

[0001571996-25-000118:8k_2_02:31]
2

[0001571996-25-000118:8k_2_02:32]
Third Quarter Fiscal 2026 Financial Results

[0001571996-25-000118:8k_2_02:33]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | October 31, 2025 |  | November 1, 2024 |  | Change |  | October 31, 2025 |  | November 1, 2024 |  | Change |
|  | (in millions, except per share amounts and percentages; unaudited) |
| Net revenue | $ | 27,005 |  |  | $ | 24,366 |  |  | 11% |  | $ | 80,159 |  |  | $ | 71,636 |  |  | 12% |
| Operating income | $ | 2,119 |  |  | $ | 1,721 |  |  | 23% |  | $ | 5,057 |  |  | $ | 4,078 |  |  | 24% |
| Net income | $ | 1,548 |  |  | $ | 1,170 |  |  | 32% |  | $ | 3,677 |  |  | $ | 3,044 |  |  | 21% |
| Change in cash from operating activities | $ | 1,172 |  |  | $ | 1,553 |  |  | (25)% |  | $ | 6,511 |  |  | $ | 3,936 |  |  | 65% |
| Earnings per share — diluted | $ | 2.28 |  |  | $ | 1.64 |  |  | 39% |  | $ | 5.34 |  |  | $ | 4.24 |  |  | 26% |
| Non-GAAP operating income | $ | 2,503 |  |  | $ | 2,252 |  |  | 11% |  | $ | 6,453 |  |  | $ | 5,855 |  |  | 10% |
| Non-GAAP net income | $ | 1,762 |  |  | $ | 1,583 |  |  | 11% |  | $ | 4,439 |  |  | $ | 3,954 |  |  | 12% |
| Adjusted free cash flow | $ | 1,670 |  |  | $ | 716 |  |  | 133% |  | $ | 6,420 |  |  | $ | 2,623 |  |  | 145% |
| Non-GAAP earnings per share — diluted | $ | 2.59 |  |  | $ | 2.21 |  |  | 17% |  | $ | 6.44 |  |  | $ | 5.47 |  |  | 18% |

[0001571996-25-000118:8k_2_02:34]
Information about Dell Technologies’ non-GAAP financial measures is provided under “Non-GAAP Financial Measures” below. All comparisons in this press release are year over year unless otherwise noted.

[0001571996-25-000118:8k_2_02:35]
Operating Segments Results

[0001571996-25-000118:8k_2_02:36]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | October 31, 2025 |  | November 1, 2024 |  | Change |  | October 31, 2025 |  | November 1, 2024 |  | Change |
|  | (in millions, except percentages; unaudited) |
| Infrastructure Solutions Group (ISG): |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Servers and networking | $ | 10,125 |  | $ | 7,364 |  |  | 37% |  | $ | 29,390 |  |  | $ | 20,502 |  |  | 43% |
| Storage | 3,982 |  |  | 4,004 |  |  | (1)% |  | 11,834 |  |  | 11,739 |  |  | 1% |
| Total ISG net revenue | $ | 14,107 |  |  | $ | 11,368 |  |  | 24% |  | $ | 41,224 |  |  | $ | 32,241 |  |  | 28% |
| Operating income: |  |  |  |  |  |  |  |  |  |  |  |
| ISG operating income | $ | 1,743 |  |  | $ | 1,508 |  |  | 16% |  | $ | 4,211 |  |  | $ | 3,528 |  |  | 19% |
| % of ISG net revenue | 12.4 | % |  | 13.3 | % |  |  |  | 10.2 | % |  | 10.9 | % |  |  |
| % of total reportable segment operating income | 70 | % |  | 67 | % |  |  |  | 66 | % |  | 60 | % |  |  |
| Client Solutions Group (CSG): |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 10,621 |  |  | $ | 10,138 |  |  | 5% |  | $ | 32,448 |  |  | $ | 30,848 |  |  | 5% |
| Consumer | 1,857 |  |  | 1,993 |  |  | (7)% |  | 5,042 |  |  | 5,664 |  |  | (11)% |
| Total CSG net revenue | $ | 12,478 |  |  | $ | 12,131 |  |  | 3% |  | $ | 37,490 |  |  | $ | 36,512 |  |  | 3% |
| Operating income: |  |  |  |  |  |  |  |  |  |  |  |
| CSG operating income | $ | 748 |  |  | $ | 747 |  |  | —% |  | $ | 2,204 |  |  | $ | 2,341 |  |  | (6)% |
| % of CSG net revenue | 6.0 | % |  | 6.2 | % |  |  |  | 5.9 | % |  | 6.4 | % |  |  |
| % of total reportable segment operating income | 30 | % |  | 33 | % |  |  |  | 34 | % |  | 40 | % |  |  |

[0001571996-25-000118:8k_2_02:37]
Conference call information

[0001571996-25-000118:8k_2_02:38]
As previously announced, the company will hold a conference call to discuss its performance and financial guidance on November 25 at 3:30 p.m. CST. Prior to the start of the conference call, prepared remarks and a presentation containing additional financial and operating information may be downloaded from investors.delltechnologies.com. The conference call will be presented live over the internet and can be accessed at https://investors.delltechnologies.com/news-events/upcoming-events.

[0001571996-25-000118:8k_2_02:39]
For those unable to listen to the live presentation, the final remarks and presentation with additional financial and operating information will be available following the presentation, and an archived version will be available at the same location for one year.

[0001571996-25-000118:8k_2_02:40]
About Dell Technologies

[0001571996-25-000118:8k_2_02:41]
Dell Technologies (NYSE:DELL) helps organizations and individuals build their digital future and transform how they work, live and play. The company provides customers with the industry’s broadest and most innovative technology and services portfolio for the AI era.

[0001571996-25-000118:8k_2_02:42]
Contacts

[0001571996-25-000118:8k_2_02:43]
Investors: Investor_Relations@Dell.com

[0001571996-25-000118:8k_2_02:44]
Media: Media.Relations@Dell.com

[0001571996-25-000118:8k_2_02:45]
# # #

[0001571996-25-000118:8k_2_02:46]
Copyright © 2025 Dell Inc. or its subsidiaries. All Rights Reserved. Dell Technologies, Dell, EMC and Dell EMC are trademarks of Dell Inc. or its subsidiaries. Other trademarks may be trademarks of their respective owners.

[0001571996-25-000118:8k_2_02:47]
Non-GAAP Financial Measures:

[0001571996-25-000118:8k_2_02:48]
This press release presents information about non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, non-GAAP earnings per share attributable to Dell Technologies Inc. – diluted, free cash flow, and adjusted free cash flow, all of which are non-GAAP financial measures provided as a supplement to the results provided in accordance with generally accepted accounting principles in the United States of America (“GAAP”). A reconciliation of each non-GAAP financial measure to the most directly comparable GAAP financial measure is provided in the attached tables for each of the fiscal periods indicated.

[0001571996-25-000118:8k_2_02:49]
Special Note on Forward-Looking Statements:

[0001571996-25-000118:8k_2_02:50]
Forward-looking statements include, among others, any statements regarding Dell Technologies’ expectations for fourth-quarter and full-year fiscal 2026 revenue, GAAP diluted earnings per share and non-GAAP diluted earnings per share, and any other statements regarding Dell Technologies’ prospects and its future operations, financial condition, volumes, cash flows, expenses or other financial items, including management’s plans or strategies and objectives for any of the foregoing and any assumptions, expectations or beliefs underlying any of the foregoing.

[0001571996-25-000118:8k_2_02:51]
Dell Technologies’ results or events in future periods could differ materially from those expressed or implied by these forward-looking statements because of risks, uncertainties, and other factors that include, but are not limited to, the following: adverse global economic conditions, trade disruptions, and instability in financial markets; competitive pressures; Dell Technologies’ ability to successfully execute its strategy; Dell Technologies’ relationships with third-party suppliers for products and components; Dell Technologies’ use of single-source or limited-source suppliers; effects on Dell Technologies’ operating performance related to demand for AI solutions; management of Dell Technologies’ AI solutions and use of AI in internal functions and operations; Dell Technologies’ ability to deliver high-quality products, software, and services and to manage solutions and products and services transitions in an effective manner; Dell Technologies’ ability to successfully implement its cost efficiency plans; Dell Technologies’ ability to successfully execute on strategic initiatives including acquisitions and divestitures; security incidents, including cyber-attacks; Dell Technologies’ foreign operations and ability to generate

[0001571996-25-000118:8k_2_02:52]
4

[0001571996-25-000118:8k_2_02:53]
substantial non-U.S. net revenue; Dell Technologies’ product, services, customer, and geographic sales mix, and seasonal sales trends; the performance of Dell Technologies’ sales channel partners; access to the capital markets by Dell Technologies or its customers; adverse economic conditions, changing customer mix, and the effect of additional regulation on Dell Technologies’ financial services activities; counterparty default risks; material impairment of the value of goodwill or intangible assets; the loss by Dell Technologies of any contracts for ISG services and solutions and its ability to perform such contracts at their estimated costs; loss by Dell Technologies of government contracts; Dell Technologies’ ability to develop and protect its proprietary intellectual property or obtain licenses to intellectual property developed by others on commercially reasonable and competitive terms; disruptions in Dell Technologies’ infrastructure; Dell Technologies’ ability to hedge effectively its exposure to fluctuations in foreign currency exchange rates and interest rates; expiration of tax holidays or favorable tax rate structures, or unfavorable outcomes in tax audits and other tax compliance matters; impairment of portfolio investments; unfavorable results of legal proceedings; evolving and varied expectations and regulatory requirements relating to sustainability issues; the effect of global climate change and related legal, regulatory or market measures; compliance with environmental and safety laws; compliance requirements of anti-corruption laws, economic sanctions and other trade laws, human rights laws, or other laws; Dell Technologies’ dependence on the services of Michael Dell and key employees; Dell Technologies’ level of indebtedness; and business and financial factors and legal restrictions affecting continuation of Dell Technologies’ quarterly cash dividend policy and dividend rate.

[0001571996-25-000118:8k_2_02:54]
This list of risks, uncertainties, and other factors is not complete. Dell Technologies discusses some of these matters more fully, as well as certain risk factors that could affect Dell Technologies’ business, financial condition, results of operations, and prospects, in its reports filed with the SEC, including Dell Technologies’ annual report on Form 10-K for the fiscal year ended January 31, 2025, quarterly reports on Form 10-Q, and current reports on Form 8-K. These filings are available for review through the SEC’s website at www.sec.gov. Any or all forward-looking statements Dell Technologies makes may turn out to be wrong and can be affected by inaccurate assumptions Dell Technologies might make or by known or unknown risks, uncertainties, and other factors, including those identified in this press release. Accordingly, you should not place undue reliance on the forward-looking statements made in this press release, which speak only as of its date. Dell Technologies does not undertake to update, and expressly disclaims any duty to update, its forward-looking statements, whether as a result of circumstances or events that arise after the date they are made, new information, or otherwise.

[0001571996-25-000118:8k_2_02:55]
5

[0001571996-25-000118:8k_2_02:56]
DELL TECHNOLOGIES INC.

[0001571996-25-000118:8k_2_02:57]
Condensed Consolidated Statements of Income and Related Financial Highlights

[0001571996-25-000118:8k_2_02:58]
(in millions, except percentages; unaudited)

[0001571996-25-000118:8k_2_02:59]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | October 31, 2025 |  | November 1, 2024 |  | Change |  | October 31, 2025 |  | November 1, 2024 |  | Change |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Products | $ | 21,255 |  |  | $ | 18,290 |  |  | 16% |  | $ | 62,789 |  |  | $ | 53,371 |  |  | 18% |
| Services | 5,750 |  |  | 6,076 |  |  | (5)% |  | 17,370 |  |  | 18,265 |  |  | (5)% |
| Total net revenue | 27,005 |  |  | 24,366 |  |  | 11% |  | 80,159 |  |  | 71,636 |  |  | 12% |
| Cost of net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Products | 18,279 |  |  | 15,488 |  |  | 18% |  | 54,439 |  |  | 45,238 |  |  | 20% |
| Services | 3,133 |  |  | 3,518 |  |  | (11)% |  | 9,743 |  |  | 10,826 |  |  | (10)% |
| Total cost of net revenue | 21,412 |  |  | 19,006 |  |  | 13% |  | 64,182 |  |  | 56,064 |  |  | 14% |
| Gross margin | 5,593 |  |  | 5,360 |  |  | 4% |  | 15,977 |  |  | 15,572 |  |  | 3% |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative | 2,722 |  |  | 2,894 |  |  | (6)% |  | 8,575 |  |  | 9,206 |  |  | (7)% |
| Research and development | 752 |  |  | 745 |  |  | 1% |  | 2,345 |  |  | 2,288 |  |  | 2% |
| Total operating expenses | 3,474 |  |  | 3,639 |  |  | (5)% |  | 10,920 |  |  | 11,494 |  |  | (5)% |
| Operating income | 2,119 |  |  | 1,721 |  |  | 23% |  | 5,057 |  |  | 4,078 |  |  | 24% |
| Interest and other, net | (178) |  |  | (276) |  |  | 36% |  | (593) |  |  | (1,002) |  |  | 41% |
| Income before income taxes | 1,941 |  |  | 1,445 |  |  | 34% |  | 4,464 |  |  | 3,076 |  |  | 45% |
| Income tax expense | 393 |  |  | 275 |  |  | 43% |  | 787 |  |  | 32 |  |  | NM |
| Net income | 1,548 |  |  | 1,170 |  |  | 32% |  | 3,677 |  |  | 3,044 |  |  | 21% |
| Less: Net loss attributable to non-controlling interests | — |  |  | (5) |  |  | 100% |  | — |  |  | (15) |  |  | 100% |
| Net income attributable to Dell Technologies Inc. | $ | 1,548 |  |  | $ | 1,175 |  |  | 32% |  | $ | 3,677 |  |  | $ | 3,059 |  |  | 20% |
| Percentage of Total Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Gross margin | 20.7 | % |  | 22.0 | % |  |  |  | 19.9 | % |  | 21.7 | % |  |  |
| Selling, general, and administrative | 10.1 | % |  | 11.9 | % |  |  |  | 10.7 | % |  | 12.8 | % |  |  |
| Research and development | 2.8 | % |  | 3.1 | % |  |  |  | 2.9 | % |  | 3.2 | % |  |  |
| Operating expenses | 12.9 | % |  | 15.0 | % |  |  |  | 13.6 | % |  | 16.0 | % |  |  |
| Operating income | 7.8 | % |  | 7.1 | % |  |  |  | 6.3 | % |  | 5.7 | % |  |  |
| Income before income taxes | 7.2 | % |  | 5.9 | % |  |  |  | 5.6 | % |  | 4.3 | % |  |  |
| Net income | 5.7 | % |  | 4.8 | % |  |  |  | 4.6 | % |  | 4.2 | % |  |  |
| Income tax rate | 20.2 | % |  | 19.0 | % |  |  |  | 17.6 | % |  | 1.0 | % |  |  |

[0001571996-25-000118:8k_2_02:60]
Amounts are based on underlying data and may not visually foot due to rounding.

[0001571996-25-000118:8k_2_02:61]
6

[0001571996-25-000118:8k_2_02:62]
DELL TECHNOLOGIES INC.

[0001571996-25-000118:8k_2_02:63]
Condensed Consolidated Statements of Financial Position

[0001571996-25-000118:8k_2_02:64]
(in millions; unaudited)

[0001571996-25-000118:8k_2_02:65]
|  | October 31, 2025 |  | January 31, 2025 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 9,569 |  |  | $ | 3,633 |  |
| Accounts receivable, net of allowance of $75 and $63 | 11,721 |  |  | 10,298 |  |
| Short-term financing receivables, net of allowance of $96 and $78 | 6,427 |  |  | 5,304 |  |
| Inventories | 6,949 |  |  | 6,716 |  |
| Other current assets | 8,436 |  |  | 9,610 |  |
| Current assets held for sale | — |  |  | 668 |  |
| Total current assets | 43,102 |  |  | 36,229 |  |
| Property, plant, and equipment, net | 6,538 |  |  | 6,336 |  |
| Long-term investments | 1,760 |  |  | 1,496 |  |
| Long-term financing receivables, net of allowance of $81 and $75 | 6,725 |  |  | 5,927 |  |
| Goodwill | 19,358 |  |  | 19,120 |  |
| Intangible assets, net | 4,628 |  |  | 4,988 |  |
| Other non-current assets | 5,368 |  |  | 5,650 |  |
| Total assets | $ | 87,479 |  |  | $ | 79,746 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Short-term debt | $ | 7,394 |  |  | $ | 5,204 |  |
| Accounts payable | 23,794 |  |  | 20,832 |  |
| Accrued and other | 6,679 |  |  | 6,597 |  |
| Short-term deferred revenue | 12,649 |  |  | 13,673 |  |
| Current liabilities held for sale | — |  |  | 221 |  |
| Total current liabilities | 50,516 |  |  | 46,527 |  |
| Long-term debt | 23,849 |  |  | 19,363 |  |
| Long-term deferred revenue | 12,459 |  |  | 12,292 |  |
| Other non-current liabilities | 3,275 |  |  | 2,951 |  |
| Total liabilities | 90,099 |  |  | 81,133 |  |
| Stockholders’ equity (deficit): |  |  |  |
| Common stock and capital in excess of $0.01 par value | 9,279 |  |  | 9,119 |  |
| Treasury stock at cost | (12,665) |  |  | (8,502) |  |
| Retained earnings (accumulated deficit) | 1,420 |  |  | (1,160) |  |
| Accumulated other comprehensive loss | (654) |  |  | (939) |  |
| Total Dell Technologies Inc. stockholders’ equity (deficit) | (2,620) |  |  | (1,482) |  |
| Non-controlling interests | — |  |  | 95 |  |
| Total stockholders’ equity (deficit) | (2,620) |  |  | (1,387) |  |
| Total liabilities and stockholders’ equity | $ | 87,479 |  |  | $ | 79,746 |  |

[0001571996-25-000118:8k_2_02:66]
7

[0001571996-25-000118:8k_2_02:67]
DELL TECHNOLOGIES INC.

[0001571996-25-000118:8k_2_02:68]
Condensed Consolidated Statements of Cash Flows

[0001571996-25-000118:8k_2_02:69]
(in millions; unaudited)

[0001571996-25-000118:8k_2_02:70]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 31, 2025 |  | November 1, 2024 |  | October 31, 2025 |  | November 1, 2024 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |
| Net income | $ | 1,548 |  |  | $ | 1,170 |  |  | $ | 3,677 |  |  | $ | 3,044 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: | (376) |  |  | 383 |  |  | 2,834 |  |  | 892 |  |
| Change in cash from operating activities | 1,172 |  |  | 1,553 |  |  | 6,511 |  |  | 3,936 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |
| Purchases of investments | (46) |  |  | (19) |  |  | (171) |  |  | (83) |  |
| Maturities and sales of investments | 71 |  |  | 121 |  |  | 130 |  |  | 337 |  |
| Capital expenditures and capitalized software development costs | (669) |  |  | (639) |  |  | (1,912) |  |  | (1,917) |  |
| Divestitures of businesses and assets, net | — |  |  | — |  |  | 533 |  |  | — |  |
| Other | 27 |  |  | 13 |  |  | 60 |  |  | 126 |  |
| Change in cash from investing activities | (617) |  |  | (524) |  |  | (1,360) |  |  | (1,537) |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |
| Proceeds from the issuance of common stock | 4 |  |  | — |  |  | 5 |  |  | 1 |  |
| Repurchases of common stock | (1,247) |  |  | (429) |  |  | (4,167) |  |  | (1,854) |  |
| Repurchases of common stock for employee tax withholdings | (22) |  |  | (25) |  |  | (379) |  |  | (560) |  |
| Payments of dividends and dividend equivalents | (351) |  |  | (312) |  |  | (1,113) |  |  | (964) |  |
| Proceeds from debt | 6,502 |  |  | 3,680 |  |  | 13,772 |  |  | 8,613 |  |
| Repayments of debt | (3,977) |  |  | (3,200) |  |  | (7,401) |  |  | (9,594) |  |
| Debt-related costs and other, net | (52) |  |  | (29) |  |  | (88) |  |  | (66) |  |
| Change in cash from financing activities | 857 |  |  | (315) |  |  | 629 |  |  | (4,424) |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash | 30 |  |  | 19 |  |  | 134 |  |  | (78) |  |
| Change in cash, cash equivalents, and restricted cash | 1,442 |  |  | 733 |  |  | 5,914 |  |  | (2,103) |  |
| Cash, cash equivalents, and restricted cash at beginning of the period | 8,291 |  |  | 4,671 |  |  | 3,819 |  |  | 7,507 |  |
| Cash, cash equivalents, and restricted cash at end of the period | $ | 9,733 |  |  | $ | 5,404 |  |  | $ | 9,733 |  |  | $ | 5,404 |  |

[0001571996-25-000118:8k_2_02:71]
DELL TECHNOLOGIES INC.

[0001571996-25-000118:8k_2_02:72]
Segment Information

[0001571996-25-000118:8k_2_02:73]
(in millions, except percentages; unaudited; continued on next page)

[0001571996-25-000118:8k_2_02:74]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | October 31, 2025 |  | November 1, 2024 |  | Change |  | October 31, 2025 |  | November 1, 2024 |  | Change |
| Infrastructure Solutions Group (ISG): |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Servers and networking | $ | 10,125 |  | $ | 7,364 |  |  | 37% |  | $ | 29,390 |  |  | $ | 20,502 |  |  | 43% |
| Storage | 3,982 |  |  | 4,004 |  |  | (1)% |  | 11,834 |  |  | 11,739 |  |  | 1% |
| Total ISG net revenue | $ | 14,107 |  |  | $ | 11,368 |  |  | 24% |  | $ | 41,224 |  |  | $ | 32,241 |  |  | 28% |
| Operating income: |  |  |  |  |  |  |  |  |  |  |  |
| ISG operating income | $ | 1,743 |  |  | $ | 1,508 |  |  | 16% |  | $ | 4,211 |  |  | $ | 3,528 |  |  | 19% |
| % of ISG net revenue | 12.4 | % |  | 13.3 | % |  |  |  | 10.2 | % |  | 10.9 | % |  |  |
| % of total reportable segment operating income | 70 | % |  | 67 | % |  |  |  | 66 | % |  | 60 | % |  |  |
| Client Solutions Group (CSG): |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 10,621 |  |  | $ | 10,138 |  |  | 5% |  | $ | 32,448 |  |  | $ | 30,848 |  |  | 5% |
| Consumer | 1,857 |  |  | 1,993 |  |  | (7)% |  | 5,042 |  |  | 5,664 |  |  | (11)% |
| Total CSG net revenue | $ | 12,478 |  |  | $ | 12,131 |  |  | 3% |  | $ | 37,490 |  |  | $ | 36,512 |  |  | 3% |
| Operating income: |  |  |  |  |  |  |  |  |  |  |  |
| CSG operating income | $ | 748 |  |  | $ | 747 |  |  | —% |  | $ | 2,204 |  |  | $ | 2,341 |  |  | (6)% |
| % of CSG net revenue | 6.0 | % |  | 6.2 | % |  |  |  | 5.9 | % |  | 6.4 | % |  |  |
| % of total reportable segment operating income | 30 | % |  | 33 | % |  |  |  | 34 | % |  | 40 | % |  |  |

[0001571996-25-000118:8k_2_02:75]
Amounts are based on underlying data and may not visually foot due to rounding.

[0001571996-25-000118:8k_2_02:76]
9

[0001571996-25-000118:8k_2_02:77]
DELL TECHNOLOGIES INC.

[0001571996-25-000118:8k_2_02:78]
Segment Information

[0001571996-25-000118:8k_2_02:79]
(in millions; unaudited; continued)

[0001571996-25-000118:8k_2_02:80]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 31, 2025 |  | November 1, 2024 |  | October 31, 2025 |  | November 1, 2024 |
| Reconciliation to consolidated net revenue: |  |  |  |  |  |  |  |
| Reportable segment net revenue | $ | 26,585 |  |  | $ | 23,499 |  |  | $ | 78,714 |  |  | $ | 68,753 |  |
| Corporate and other (a) | 420 |  |  | 867 |  |  | 1,445 |  |  | 2,883 |  |
| Total consolidated net revenue | $ | 27,005 |  |  | $ | 24,366 |  |  | $ | 80,159 |  |  | $ | 71,636 |  |
| Reconciliation to consolidated operating income: |  |  |  |  |  |  |
| Reportable segment operating income (b) | $ | 2,491 |  |  | $ | 2,255 |  |  | $ | 6,415 |  |  | $ | 5,869 |  |
| Corporate and other (a) | 12 |  |  | (3) |  |  | 38 |  |  | (14) |  |
| Amortization of intangibles (c) | (121) |  |  | (168) |  |  | (372) |  |  | (504) |  |
| Stock-based compensation expense (d) | (165) |  |  | (198) |  |  | (534) |  |  | (599) |  |
| Other corporate expenses (e) | (98) |  |  | (165) |  |  | (490) |  |  | (674) |  |
| Total consolidated operating income (f) | $ | 2,119 |  |  | $ | 1,721 |  |  | $ | 5,057 |  |  | $ | 4,078 |  |

[0001571996-25-000118:8k_2_02:81]
_________________

[0001571996-25-000118:8k_2_02:82]
(a)Corporate and other consists of results of divested businesses or non-reportable segments whose offerings are no longer actively sold, including (i) VMware Resale, (ii) Secureworks, and (iii) Virtustream, and do not meet the requirements for a reportable segment, either individually or collectively. Additionally, Corporate and other includes other items that are managed at the corporate level and are not allocated to reportable segments.

[0001571996-25-000118:8k_2_02:83]
(b)Depreciation expense directly attributable to each reportable segment is included in the operating results of each segment. However, the Chief Operating Decision Maker does not evaluate depreciation expense by operating segment, and therefore such expense is not separately presented.

[0001571996-25-000118:8k_2_02:84]
(c)Amortization of intangibles includes non-cash purchase accounting adjustments that are primarily related to the EMC merger transaction in 3QFY17.

[0001571996-25-000118:8k_2_02:85]
(d)Stock-based compensation expense consists of equity awards granted based on the estimated fair value of those awards at grant date.

[0001571996-25-000118:8k_2_02:86]
(e)Other corporate expenses includes severance expenses, payroll taxes associated with stock-based compensation, incentive charges related to equity investments, facility action costs, transaction-related expenses, and impairment charges.

[0001571996-25-000118:8k_2_02:87]
(f)Income and expenses within Interest and other, net, is not allocated to the reportable segments. Therefore, the company only reports reportable segment operating income.

[0001571996-25-000118:8k_2_02:88]
SUPPLEMENTAL SELECTED NON-GAAP FINANCIAL MEASURES

[0001571996-25-000118:8k_2_02:89]
These tables present information about the company’s non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, non-GAAP earnings per share attributable to Dell Technologies Inc. - diluted, free cash flow and adjusted free cash flow, all of which are non-GAAP financial measures provided as a supplement to the results provided in accordance with generally accepted accounting principles in the United States of America (“GAAP”). A detailed discussion of Dell Technologies’ reasons for including certain of these non-GAAP financial measures, the limitations associated with these measures, the items excluded from these measures, and the company’s reason for excluding those items are presented in “Management’s Discussion and Analysis of Financial Condition and Results of Operations — Non-GAAP Financial Measures” in the company’s periodic reports filed with the SEC. Dell Technologies encourages investors to review the non-GAAP discussion in these reports in conjunction with the presentation of non-GAAP financial measures.

[0001571996-25-000118:8k_2_02:90]
11

[0001571996-25-000118:8k_2_02:91]
DELL TECHNOLOGIES INC.

[0001571996-25-000118:8k_2_02:92]
Selected Financial Measures

[0001571996-25-000118:8k_2_02:93]
(in millions, except per share amounts and percentages; unaudited)

[0001571996-25-000118:8k_2_02:94]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | October 31, 2025 |  | November 1, 2024 |  | Change |  | October 31, 2025 |  | November 1, 2024 |  | Change |
| Net revenue | $ | 27,005 |  |  | $ | 24,366 |  |  | 11% |  | $ | 80,159 |  |  | $ | 71,636 |  |  | 12% |
| Non-GAAP gross margin | $ | 5,686 |  |  | $ | 5,490 |  |  | 4% |  | $ | 16,315 |  |  | $ | 15,996 |  |  | 2% |
| % of net revenue | 21.1 | % |  | 22.5 | % |  |  |  | 20.4 | % |  | 22.3 | % |  |  |
| Non-GAAP operating expenses | $ | 3,183 |  |  | $ | 3,238 |  |  | (2)% |  | $ | 9,862 |  |  | $ | 10,141 |  |  | (3)% |
| % of net revenue | 11.8 | % |  | 13.3 | % |  |  |  | 12.3 | % |  | 14.1 | % |  |  |
| Non-GAAP operating income | $ | 2,503 |  |  | $ | 2,252 |  |  | 11% |  | $ | 6,453 |  |  | $ | 5,855 |  |  | 10% |
| % of net revenue | 9.3 | % |  | 9.2 | % |  |  |  | 8.1 | % |  | 8.2 | % |  |  |
| Non-GAAP net income | $ | 1,762 |  |  | $ | 1,583 |  |  | 11% |  | $ | 4,439 |  |  | $ | 3,954 |  |  | 12% |
| % of net revenue | 6.5 | % |  | 6.5 | % |  |  |  | 5.5 | % |  | 5.5 | % |  |  |
| Non-GAAP earnings per share — diluted | $ | 2.59 |  |  | $ | 2.21 |  |  | 17% |  | $ | 6.44 |  |  | $ | 5.47 |  |  | 18% |

[0001571996-25-000118:8k_2_02:95]
Amounts are based on underlying data and may not visually foot due to rounding.

[0001571996-25-000118:8k_2_02:96]
12

[0001571996-25-000118:8k_2_02:97]
DELL TECHNOLOGIES INC.

[0001571996-25-000118:8k_2_02:98]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-25-000118:8k_2_02:99]
(in millions, except percentages; unaudited; continued on next page)

[0001571996-25-000118:8k_2_02:100]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | October 31, 2025 |  | November 1, 2024 |  | Change |  | October 31, 2025 |  | November 1, 2024 |  | Change |
| Gross margin | $ | 5,593 |  |  | $ | 5,360 |  |  | 4% |  | $ | 15,977 |  |  | $ | 15,572 |  |  | 3% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 41 |  |  | 60 |  |  |  |  | 121 |  |  | 179 |  |  |  |
| Stock-based compensation expense | 38 |  |  | 39 |  |  |  |  | 114 |  |  | 115 |  |  |  |
| Other corporate expenses | 14 |  |  | 31 |  |  |  |  | 103 |  |  | 130 |  |  |  |
| Non-GAAP gross margin | $ | 5,686 |  |  | $ | 5,490 |  |  | 4% |  | $ | 16,315 |  |  | $ | 15,996 |  |  | 2% |
| Operating expenses | $ | 3,474 |  |  | $ | 3,639 |  |  | (5)% |  | $ | 10,920 |  |  | $ | 11,494 |  |  | (5)% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | (80) |  |  | (108) |  |  |  |  | (251) |  |  | (325) |  |  |  |
| Stock-based compensation expense | (127) |  |  | (159) |  |  |  |  | (420) |  |  | (484) |  |  |  |
| Other corporate expenses | (84) |  |  | (134) |  |  |  |  | (387) |  |  | (544) |  |  |  |
| Non-GAAP operating expenses | $ | 3,183 |  |  | $ | 3,238 |  |  | (2)% |  | $ | 9,862 |  |  | $ | 10,141 |  |  | (3)% |
| Operating income | $ | 2,119 |  |  | $ | 1,721 |  |  | 23% |  | $ | 5,057 |  |  | $ | 4,078 |  |  | 24% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 121 |  |  | 168 |  |  |  |  | 372 |  |  | 504 |  |  |  |
| Stock-based compensation expense | 165 |  |  | 198 |  |  |  |  | 534 |  |  | 599 |  |  |  |
| Other corporate expenses | 98 |  |  | 165 |  |  |  |  | 490 |  |  | 674 |  |  |  |
| Non-GAAP operating income | $ | 2,503 |  |  | $ | 2,252 |  |  | 11% |  | $ | 6,453 |  |  | $ | 5,855 |  |  | 10% |
| Net income | $ | 1,548 |  |  | $ | 1,170 |  |  | 32% |  | $ | 3,677 |  |  | $ | 3,044 |  |  | 21% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 121 |  |  | 168 |  |  |  |  | 372 |  |  | 504 |  |  |  |
| Stock-based compensation expense | 165 |  |  | 198 |  |  |  |  | 534 |  |  | 599 |  |  |  |
| Other corporate expenses | 95 |  |  | 166 |  |  |  |  | 237 |  |  | 665 |  |  |  |
| Fair value adjustments on equity investments | (173) |  |  | (46) |  |  |  |  | (194) |  |  | (21) |  |  |  |
| Aggregate adjustment for income taxes (a) | 6 |  |  | (73) |  |  |  |  | (187) |  |  | (837) |  |  |  |
| Non-GAAP net income | $ | 1,762 |  |  | $ | 1,583 |  |  | 11% |  | $ | 4,439 |  |  | $ | 3,954 |  |  | 12% |

[0001571996-25-000118:8k_2_02:101]
____________________

[0001571996-25-000118:8k_2_02:102]
(a)The company’s non-GAAP income tax is calculated using a fixed estimated annual tax rate.

[0001571996-25-000118:8k_2_02:103]
13

[0001571996-25-000118:8k_2_02:104]
DELL TECHNOLOGIES INC.

[0001571996-25-000118:8k_2_02:105]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-25-000118:8k_2_02:106]
(unaudited; continued)

[0001571996-25-000118:8k_2_02:107]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | October 31, 2025 |  | November 1, 2024 |  | Change |  | October 31, 2025 |  | November 1, 2024 |  | Change |
| Earnings per share attributable to Dell Technologies Inc. — diluted | $ | 2.28 |  |  | $ | 1.64 |  |  | 39 | % |  | $ | 5.34 |  |  | $ | 4.24 |  |  | 26 | % |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 0.18 |  |  | 0.23 |  |  |  |  | 0.54 |  |  | 0.70 |  |  |  |
| Stock-based compensation expense | 0.24 |  |  | 0.28 |  |  |  |  | 0.78 |  |  | 0.83 |  |  |  |
| Other corporate expenses | 0.14 |  |  | 0.23 |  |  |  |  | 0.35 |  |  | 0.92 |  |  |  |
| Fair value adjustments on equity investments | (0.25) |  |  | (0.06) |  |  |  |  | (0.28) |  |  | (0.03) |  |  |  |
| Aggregate adjustment for income taxes (a) | — |  |  | (0.10) |  |  |  |  | (0.29) |  |  | (1.17) |  |  |  |
| Total non-GAAP adjustments attributable to non-controlling interests | — |  |  | (0.01) |  |  |  |  | — |  |  | (0.02) |  |  |  |
| Non-GAAP earnings per share attributable to Dell Technologies Inc. — diluted | $ | 2.59 |  |  | $ | 2.21 |  |  | 17 | % |  | $ | 6.44 |  |  | $ | 5.47 |  |  | 18 | % |

[0001571996-25-000118:8k_2_02:108]
____________________

[0001571996-25-000118:8k_2_02:109]
(a)The company’s non-GAAP income tax is calculated using a fixed estimated annual tax rate.

[0001571996-25-000118:8k_2_02:110]
14

[0001571996-25-000118:8k_2_02:111]
DELL TECHNOLOGIES INC.

[0001571996-25-000118:8k_2_02:112]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-25-000118:8k_2_02:113]
(in millions, except percentages; unaudited; continued)

[0001571996-25-000118:8k_2_02:114]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | October 31, 2025 |  | November 1, 2024 |  | Change |  | October 31, 2025 |  | November 1, 2024 |  | Change |
| Cash flow from operations | $ | 1,172 |  |  | $ | 1,553 |  |  | (25) | % |  | $ | 6,511 |  |  | $ | 3,936 |  |  | 65 | % |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Capital expenditures and capitalized software development costs, net (a) | (666) |  |  | (639) |  |  |  |  | (1,909) |  |  | (1,861) |  |  |  |
| Free cash flow | $ | 506 |  |  | $ | 914 |  |  | (45) | % |  | $ | 4,602 |  |  | $ | 2,075 |  |  | 122 | % |
| Free cash flow | $ | 506 |  |  | $ | 914 |  |  | (45) | % |  | $ | 4,602 |  |  | $ | 2,075 |  |  | 122 | % |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Financing receivables (b) | 1,135 |  |  | (233) |  |  |  |  | 1,704 |  |  | 419 |  |  |  |
| Equipment under operating leases (c) | 29 |  |  | 35 |  |  |  |  | 114 |  |  | 129 |  |  |  |
| Adjusted free cash flow | $ | 1,670 |  |  | $ | 716 |  |  | 133 | % |  | $ | 6,420 |  |  | $ | 2,623 |  |  | 145 | % |

[0001571996-25-000118:8k_2_02:115]
____________________

[0001571996-25-000118:8k_2_02:116]
(a)Capital expenditures and capitalized software development costs, net includes proceeds from sales of facilities, land, and other assets.

[0001571996-25-000118:8k_2_02:117]
(b)Financing receivables represent the operating cash flow impact from the change in financing receivables.

[0001571996-25-000118:8k_2_02:118]
(c)Equipment under operating leases represents the net impact of capital expenditures and depreciation expense for leases and contractually embedded leases identified within flexible consumption arrangements.

[0001571996-25-000118:8k_2_02:119]
DELL TECHNOLOGIES INC.

[0001571996-25-000118:8k_2_02:120]
Reconciliation of Non-GAAP Financial Measures in Summary Guidance

[0001571996-25-000118:8k_2_02:121]
(unaudited)

[0001571996-25-000118:8k_2_02:122]
|  |  |  |  |  | Three Months Ending |  |  |  |  |  | Fiscal Year Ending |
|  |  |  |  |  | January 30, 2026 |  |  |  |  |  | January 30, 2026 |
| Earnings per share attributable to Dell Technologies Inc. — diluted |  |  |  |  | $ | 3.05 |  |  |  |  |  |  | $ | 8.38 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles (a) |  |  |  |  | 0.18 |  |  |  |  |  |  | 0.72 |  |
| Stock-based compensation |  |  |  |  | 0.27 |  |  |  |  |  |  | 1.04 |  |
| Other corporate expenses (b) |  |  |  |  | 0.01 |  |  |  |  |  |  | 0.35 |  |
| Fair value adjustments on equity investments (c) |  |  |  |  | — |  |  |  |  |  |  | (0.28) |  |
| Aggregate adjustment for income taxes (d) |  |  |  |  | (0.01) |  |  |  |  |  |  | (0.29) |  |
| Non-GAAP earnings per share attributable to Dell Technologies Inc. — diluted |  |  |  |  | $ | 3.50 |  |  |  |  |  |  | $ | 9.92 |  |

[0001571996-25-000118:8k_2_02:123]
____________________

[0001571996-25-000118:8k_2_02:124]
(a)Amortization of intangibles represents an estimate for acquisitions completed as of October 31, 2025 and does not include estimates for potential acquisitions, if any, during fiscal 2026.

[0001571996-25-000118:8k_2_02:125]
(b)Consists primarily of severance expenses, payroll taxes associated with stock-based compensation, facility action costs, transaction-related expenses, impairment charges, and incentive charges related to equity investments. Additionally, the amount shown includes transaction-related gains on sales of businesses that have been completed as of October 31, 2025 and does not include estimates for potential transactions, if any, during fiscal 2026. No estimate is included for severance expense as such expense cannot be reasonably estimated at this time.

[0001571996-25-000118:8k_2_02:126]
(c)No estimates are included for potential fair value adjustments on strategic investments given the potential volatility of either gains or losses on those equity investments.

[0001571996-25-000118:8k_2_02:127]
(d)The fiscal 2026 aggregate adjustment to reconcile from GAAP to Non-GAAP income tax expense is approximately $0.2 billion. The aggregate adjustment for income taxes is the estimated combined income tax effect for the adjustments shown above as well as an adjustment for discrete tax items. The company’s non-GAAP income tax is calculated using a fixed estimated annual tax rate.
