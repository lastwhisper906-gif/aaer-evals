# DELL notes — 0001571996-25-000127


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001571996-25-000127:notes:1]
Basis of Presentation — The accompanying unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes filed with the U.S. Securities and Exchange Commission (“SEC”) in the Company’s Annual Report on Form 10-K for the fiscal year ended January 31, 2025. These Condensed Consolidated Financial Statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“GAAP”). In the opinion of management, the accompanying Condensed Consolidated Financial Statements reflect all adjustments of a normal recurring nature considered necessary to fairly state the financial position of the Company as of October 31, 2025 and January 31, 2025 and the results of its operations, corresponding comprehensive income, changes in stockholders’ equity (deficit) for the three and nine months ended October 31, 2025 and November 1, 2024, and cash flows for the nine months ended October 31, 2025 and November 1, 2024.

[0001571996-25-000127:notes:2]
The preparation of financial statements in accordance with GAAP requires management to make estimates and assumptions that affect the amounts reported in the Condensed Consolidated Financial Statements and the accompanying Notes. Actual results could differ materially from those estimates. The results of its operations, corresponding comprehensive income, and changes in stockholders’ equity (deficit) for the three and nine months ended October 31, 2025 and November 1, 2024, and cash flows for the nine months ended October 31, 2025 and November 1, 2024 are not necessarily indicative of the results to be expected for the full fiscal year or for any other fiscal period.
The Company’s fiscal year is the 52- or 53-week period ending on the Friday nearest January 31. Both the fiscal year ending January 30, 2026 (“Fiscal 2026”) and the fiscal year ended January 31, 2025 (“Fiscal 2025”) are 52-week periods.


## us-gaap:ConsolidationPolicyTextBlock

[0001571996-25-000127:notes:3]
[same as prior period, unchanged from 0001571996-25-000102:notes:3]


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001571996-25-000127:notes:4]
Recently Issued Accounting Pronouncements

[0001571996-25-000127:notes:5]
Internal-Use Software — In September 2025, the Financial Accounting Standards Board (the “FASB”) issued guidance to modernize internal-use software capitalization by removing references to software development project stages, increasing the operability of the recognition guidance considering different methods of software development, including the agile method. Public entities must adopt the new guidance for fiscal years beginning after December 15, 2027, with early adoption permitted. Upon adoption, the guidance can be applied prospectively, retrospectively, or through a modified approach. The Company is currently evaluating the impact and timing of adoption of this guidance.

[0001571996-25-000127:notes:6]
Expense Disaggregation Disclosures — In November 2024, the FASB issued guidance to improve disclosures about a public entity’s expenses by requiring disclosure of additional information about the types of expenses commonly presented in the financial statements on an annual and interim basis. Public entities must adopt the new guidance for fiscal years beginning after December 15, 2026, with early adoption permitted. Upon adoption, the guidance can be applied prospectively or retrospectively. Adoption of this new guidance will result in increased disclosures in the Notes to the Consolidated Financial Statements.

[0001571996-25-000127:notes:7]
Income Taxes — In December 2023, the FASB issued guidance which requires companies to provide disaggregated income tax disclosures within the income tax rate reconciliation and income taxes paid. Public entities must adopt the new guidance for fiscal years beginning after December 15, 2024, with early adoption permitted. The Company will adopt the guidance prospectively. Adoption of this new guidance will result in increased disclosures in the Notes to the Consolidated Financial Statements.


## us-gaap:FairValueDisclosuresTextBlock

[0001571996-25-000127:notes:8]
[same as prior period, unchanged from 0001571996-25-000102:notes:7]

[0001571996-25-000127:notes:9]
|  | October 31, 2025 |  | January 31, 2025 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | Quoted Prices in Active Markets for Identical Assets |  | Significant Other Observable Inputs |  | Significant Unobservable Inputs |  |  |  | Quoted Prices in Active Markets for Identical Assets |  | Significant Other Observable Inputs |  | Significant Unobservable Inputs |  |  |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 6,189 |  |  | $ | — |  |  | $ | — |  |  | $ | 6,189 |  |  | $ | 571 |  |  | $ | — |  |  | $ | — |  |  | $ | 571 |  |
| Marketable equity and other securities | 122 |  |  | — |  |  | — |  |  | 122 |  |  | 8 |  |  | — |  |  | — |  |  | 8 |  |
| Derivative instruments | — |  |  | 196 |  |  | — |  |  | 196 |  |  | — |  |  | 302 |  |  | — |  |  | 302 |  |
| Total assets | $ | 6,311 |  |  | $ | 196 |  |  | $ | — |  |  | $ | 6,507 |  |  | $ | 579 |  |  | $ | 302 |  |  | $ | — |  |  | $ | 881 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative instruments | $ | — |  |  | $ | 84 |  |  | $ | — |  |  | $ | 84 |  |  | $ | — |  |  | $ | 75 |  |  | $ | — |  |  | $ | 75 |  |
| Total liabilities | $ | — |  |  | $ | 84 |  |  | $ | — |  |  | $ | 84 |  |  | $ | — |  |  | $ | 75 |  |  | $ | — |  |  | $ | 75 |  |

[0001571996-25-000127:notes:10]
[same as prior period, unchanged from 0001571996-25-000102:notes:9]

[0001571996-25-000127:notes:11]
Money Market Funds — The Company’s investment in money market funds that are classified as cash equivalents hold underlying investments with a weighted average maturity of 90 days or less and are recognized at fair value. The valuations of these securities are based on quoted prices for identical assets in active markets, when available, or pricing models whereby all significant inputs are observable, or can be derived from, or corroborated by, observable market data. The Company reviews security pricing and assesses money market fund liquidity on a quarterly basis. As of October 31, 2025, the Company’s portfolio had no exposure to money market funds with a fluctuating net asset value.

[0001571996-25-000127:notes:12]
[same as prior period, unchanged from 0001571996-25-000102:notes:11]

[0001571996-25-000127:notes:13]
[same as prior period, unchanged from 0001571996-25-000102:notes:12]

[0001571996-25-000127:notes:14]
Deferred Compensation Plans — The Company offers deferred compensation plans for eligible employees which allow participants to defer a portion of their compensation. Assets and liabilities associated with the plans are measured at fair value using Level 1 inputs. Assets were the same as liabilities associated with the plans at approximately $269 million and $244 million as of October 31, 2025 and January 31, 2025, respectively, and are included in other assets and other liabilities on the Condensed Consolidated Statements of Financial Position. The net impact on the Condensed Consolidated Statements of Income is not material since changes in the fair value of the assets substantially offset changes in the fair value of the liabilities. As such, assets and liabilities associated with these plans have not been included in the recurring fair value table above.

[0001571996-25-000127:notes:15]
[same as prior period, unchanged from 0001571996-25-000102:notes:14]

[0001571996-25-000127:notes:16]
[same as prior period, unchanged from 0001571996-25-000102:notes:15]

[0001571996-25-000127:notes:17]
[same as prior period, unchanged from 0001571996-25-000102:notes:16]

[0001571996-25-000127:notes:18]
|  | October 31, 2025 |  | January 31, 2025 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Notes | $ | 21.4 |  |  | $ | 21.9 |  |  | $ | 15.0 |  |  | $ | 15.0 |  |
| Legacy Notes | $ | 0.9 |  |  | $ | 1.0 |  |  | $ | 0.9 |  |  | $ | 1.0 |  |
| DFS Debt | $ | 8.9 |  |  | $ | 8.6 |  |  | $ | 8.7 |  |  | $ | 8.5 |  |

[0001571996-25-000127:notes:19]
[same as prior period, unchanged from 0001571996-25-000102:notes:18]


## us-gaap:InvestmentTextBlock

[0001571996-25-000127:notes:20]
INVESTMENTS
The Company has strategic investments in equity and other securities as well as immaterial investments in fixed income debt securities that are primarily recorded as long-term investments in the Condensed Consolidated Statements of Financial Position. As of October 31, 2025 and January 31, 2025, total investments were $1.8 billion and $1.5 billion, respectively.

[0001571996-25-000127:notes:21]
[same as prior period, unchanged from 0001571996-25-000102:notes:20]

[0001571996-25-000127:notes:22]
[same as prior period, unchanged from 0001571996-25-000102:notes:21]

[0001571996-25-000127:notes:23]
[same as prior period, unchanged from 0001571996-25-000102:notes:22]

[0001571996-25-000127:notes:24]
|  | October 31, 2025 |  | January 31, 2025 |
|  | Cost |  | Unrealized Gain |  | Unrealized Loss |  | Carrying Value |  | Cost |  | Unrealized Gain |  | Unrealized Loss |  | Carrying Value |
|  | (in millions) |
| Marketable | $ | 119 |  |  | $ | 3 |  |  | $ | — |  |  | $ | 122 |  |  | $ | 11 |  |  | $ | 24 |  |  | $ | (27) |  |  | $ | 8 |  |
| Non-marketable | 856 |  |  | 1,026 |  |  | (257) |  |  | 1,625 |  |  | 739 |  |  | 1,009 |  |  | (261) |  |  | 1,487 |  |
| Total equity and other securities | $ | 975 |  |  | $ | 1,029 |  |  | $ | (257) |  |  | $ | 1,747 |  |  | $ | 750 |  |  | $ | 1,033 |  |  | $ | (288) |  |  | $ | 1,495 |  |

[0001571996-25-000127:notes:25]
[same as prior period, unchanged from 0001571996-25-000102:notes:24]

[0001571996-25-000127:notes:26]
[same as prior period, unchanged from 0001571996-25-000102:notes:25]

[0001571996-25-000127:notes:27]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 31, 2025 |  | November 1, 2024 |  | October 31, 2025 |  | November 1, 2024 |  |  |
|  | (in millions) |
| Marketable securities: |  |  |  |  |  |  |  |  |  |
| Unrealized gain | $ | 53 |  |  | $ | 3 |  |  | $ | 53 |  |  | $ | 3 |  |  |  |
| Unrealized loss | — |  |  | — |  |  | (1) |  |  | (6) |  |  |  |
| Net unrealized gain (loss) | 53 |  |  | 3 |  |  | 52 |  |  | (3) |  |  |  |
| Non-marketable securities: |  |  |  |  |  |  |  |  |  |
| Unrealized gain | 89 |  |  | 7 |  |  | 111 |  |  | 7 |  |  |  |
| Unrealized loss | (10) |  |  | — |  |  | (33) |  |  | (31) |  |  |  |
| Net unrealized gain (loss) (a) (b) | 79 |  |  | 7 |  |  | 78 |  |  | (24) |  |  |  |
| Net unrealized gain (loss) on equity and other securities | $ | 132 |  |  | $ | 10 |  |  | $ | 130 |  |  | $ | (27) |  |  |  |

[0001571996-25-000127:notes:28]
[same as prior period, unchanged from 0001571996-25-000102:notes:27]

[0001571996-25-000127:notes:29]
(a)For the three and nine months ended October 31, 2025, net unrealized gains on non-marketable securities were primarily attributable to net adjustments for observable price changes.
(b)For the three months ended November 1, 2024, net unrealized gains on non-marketable securities were attributable to upward adjustments for observable price changes. For the nine months ended November 1, 2024, net unrealized losses on non-marketable securities were primarily attributable to downward adjustments for observable price changes.


## dell:CreditLossFinancialInstrumentLeasesDebtVariableInterestEntitiesAndCustomerReceivablesSalesTextBlock

[0001571996-25-000127:notes:30]
FINANCIAL SERVICES 
The Company offers or arranges a portfolio of payment and consumption solutions and services for its customers globally, including utility, subscription, as-a-Service, leases, and loans, designed to match customers' consumption and financing preferences and to provide operational and financial flexibility.

[0001571996-25-000127:notes:31]
To support financing solutions and services as part of the Dell Technologies portfolio, Dell Financial Services and its affiliates (“DFS”) originates, collects, and services customer financing arrangements primarily related to the purchase and use of Dell Technologies products and services. In some cases, the Company also offers financing for the purchase of third-party technology products that complement the portfolio of products and services. New financing originations were $3.1 billion and $1.6 billion for the three months ended October 31, 2025 and November 1, 2024, respectively, and $7.1 billion and $5.9 billion for the nine months ended October 31, 2025 and November 1, 2024, respectively.

[0001571996-25-000127:notes:32]
The Company’s financing arrangements with customers are aggregated primarily as fixed-term leases and loans as described below.

[0001571996-25-000127:notes:33]
Leases — The Company enters into fixed-term financing arrangements with customers who seek lease financing for equipment. Leases are generally classified as sales-type leases or operating leases. Additionally, utility, subscription, and as-a-Service flexible consumption models may result in identification of embedded lease arrangements that require the recognition of sales-type leases or operating leases. Leases with business customers generally have fixed terms of two to five years.

[0001571996-25-000127:notes:34]
Loans — The Company also offers fixed-term loans to qualified small businesses, large commercial accounts, governmental organizations, educational entities, and certain individual consumer customers. These loans are repaid in periodic payments including interest and have defined terms typically ranging from one to five years. The fair value of the fixed-term loan portfolio is determined using market observable inputs. The carrying value of these loans approximates fair value.

[0001571996-25-000127:notes:35]
The Company historically offered revolving loans primarily to small and medium-sized commercial customers. During Fiscal 2025, the Company discontinued remaining offerings under the revolving loan portfolio. The Company continues to support existing customer arrangements as well as to transition these customers to fixed-term offerings. Due to the short-term nature of the revolving loan portfolio, in which transactions are typically repaid within twelve months on average, the portfolio had substantially transitioned to fixed-term offerings as of October 31, 2025.

[0001571996-25-000127:notes:36]
Financing Receivables

[0001571996-25-000127:notes:37]
The following table presents the components of the Company’s financing receivables as of the dates indicated:

[0001571996-25-000127:notes:38]
|  |  |  |  |  | October 31, 2025 |  |  |  |  |  | January 31, 2025 |
|  |  |  |  |  | (in millions) |
| Financing receivables, net: |  |  |  |  |  |  |  |  |  |  |  |
| Customer receivables, gross (a) |  |  |  |  | $ | 13,143 |  |  |  |  |  |  | $ | 11,216 |  |
| Allowance for losses |  |  |  |  | (177) |  |  |  |  |  |  | (153) |  |
| Customer receivables, net |  |  |  |  | 12,966 |  |  |  |  |  |  | 11,063 |  |
| Residual interest |  |  |  |  | 186 |  |  |  |  |  |  | 168 |  |
| Financing receivables, net |  |  |  |  | $ | 13,152 |  |  |  |  |  |  | $ | 11,231 |  |
| Short-term |  |  |  |  | $ | 6,427 |  |  |  |  |  |  | $ | 5,304 |  |
| Long-term |  |  |  |  | $ | 6,725 |  |  |  |  |  |  | $ | 5,927 |  |

[0001571996-25-000127:notes:39]
(a)Customer receivables, gross include amounts due from customers under fixed-term leases, fixed-term loans, and accrued interest, as well as immaterial remaining amounts under the revolving loans.

[0001571996-25-000127:notes:40]
The following table presents the changes in allowance for financing receivable losses for the periods indicated:

[0001571996-25-000127:notes:41]
|  | Three Months Ended |  |  |  |  |  | Nine Months Ended |
|  | October 31, 2025 |  | November 1, 2024 |  |  |  |  |  | October 31, 2025 |  |  |  |  |  | November 1, 2024 |  |  |
|  | (in millions) |  |  |  |  |  |  |
| Allowance for financing receivable losses: |
| Balances at beginning of period | $ | 151 |  |  | $ | 166 |  |  |  |  |  |  | $ | 153 |  |  |  |  |  |  | $ | 170 |  |  |  |  |  |  |  |
| Charge-offs, net of recoveries | (7) |  |  | (38) |  |  |  |  |  |  | (21) |  |  |  |  |  |  | (65) |  |  |  |  |  |  |  |
| Provision charged to income statement | 33 |  |  | 16 |  |  |  |  |  |  | 45 |  |  |  |  |  |  | 39 |  |  |  |  |  |  |  |
| Balances at end of period | $ | 177 |  |  | $ | 144 |  |  |  |  |  |  | $ | 177 |  |  |  |  |  |  | $ | 144 |  |  |  |  |  |  |  |

[0001571996-25-000127:notes:42]
The Company recognizes an allowance for financing receivable losses, including both the lease receivable and unguaranteed residual, in an amount equal to the expected losses, net of recoveries. The allowance for financing receivable losses on the lease receivable is determined based on various factors, including lifetime expected losses determined using macroeconomic forecast assumptions and management judgments applicable to and through the expected life of the portfolios as well as past due receivables, receivable type, and customer risk profile. The Company continues to monitor broader economic indicators and their potential impact on future credit loss performance.

[0001571996-25-000127:notes:43]
Aging

[0001571996-25-000127:notes:44]
The following table presents the aging of the Company’s customer financing receivables, gross, including accrued interest, as of the dates indicated:

[0001571996-25-000127:notes:45]
|  | October 31, 2025 |  | January 31, 2025 |
|  | (in millions) |
| Current 0 — 30 Days | $ | 12,802 |  |  | $ | 10,796 |  |
| Past Due 31 — 90 Days | 180 |  |  | 201 |  |
| Past Due > 90 Days | 161 |  |  | 219 |  |
| Total | $ | 13,143 |  |  | $ | 11,216 |  |

[0001571996-25-000127:notes:46]
Aging is likely to fluctuate as a result of the variability in volume of large transactions entered into over the period, and the administrative processes that accompany those transactions. Aging is also impacted by the timing of the Company’s fiscal period end date relative to calendar month-end customer payment due dates. As a result of these factors, fluctuations in aging from period to period do not necessarily indicate a material change in the collectibility of the portfolio.

[0001571996-25-000127:notes:47]
Customer receivables are placed on non-accrual status if principal or interest is past due and considered delinquent, or if there is concern about the collectibility of a specific customer receivable. The receivables identified as doubtful for collectibility may be classified as current for aging purposes.

[0001571996-25-000127:notes:48]
Credit Quality

[0001571996-25-000127:notes:49]
The following tables present customer receivables, gross, including accrued interest, by credit quality indicator, as of the dates indicated:

[0001571996-25-000127:notes:50]
|  | October 31, 2025 |
|  | Fiscal Year of Origination |  |  |
|  | 2026 |  | 2025 |  | 2024 |  | 2023 |  | 2022 |  | Years Prior |  | Total |
|  | (in millions) |
| Higher | $ | 2,342 |  |  | $ | 1,832 |  |  | $ | 1,618 |  |  | $ | 679 |  |  | $ | 142 |  |  | $ | 27 |  |  | $ | 6,640 |  |
| Mid | 2,550 |  |  | 1,538 |  |  | 473 |  |  | 249 |  |  | 35 |  |  | 2 |  |  | 4,847 |  |
| Lower | 875 |  |  | 361 |  |  | 248 |  |  | 138 |  |  | 16 |  |  | 18 |  |  | 1,656 |  |
| Total | $ | 5,767 |  |  | $ | 3,731 |  |  | $ | 2,339 |  |  | $ | 1,066 |  |  | $ | 193 |  |  | $ | 47 |  |  | $ | 13,143 |  |

[0001571996-25-000127:notes:51]
|  | January 31, 2025 |
|  | Fiscal Year of Origination |  |  |
|  | 2025 |  | 2024 |  | 2023 |  | 2022 |  | 2021 |  | Years Prior |  | Total |
|  | (in millions) |
| Higher | $ | 2,295 |  |  | $ | 2,160 |  |  | $ | 1,217 |  |  | $ | 357 |  |  | $ | 102 |  |  | $ | 4 |  |  | $ | 6,135 |  |
| Mid | 2,455 |  |  | 695 |  |  | 464 |  |  | 107 |  |  | 17 |  |  | 4 |  |  | 3,742 |  |
| Lower | 552 |  |  | 407 |  |  | 283 |  |  | 68 |  |  | 28 |  |  | 1 |  |  | 1,339 |  |
| Total | $ | 5,302 |  |  | $ | 3,262 |  |  | $ | 1,964 |  |  | $ | 532 |  |  | $ | 147 |  |  | $ | 9 |  |  | $ | 11,216 |  |

[0001571996-25-000127:notes:52]
The categories shown in the tables above segregate customer receivables, gross, based on the relative degrees of credit risk. Credit quality indicators are updated on a periodic basis. An internal grading system is utilized that assigns a credit level score based on a number of considerations, including liquidity, operating performance, and industry outlook.

[0001571996-25-000127:notes:53]
Leases

[0001571996-25-000127:notes:54]
The following table presents amounts included in the Condensed Consolidated Statements of Income related to sales-type lease activity for the periods indicated:

[0001571996-25-000127:notes:55]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 31, 2025 |  | November 1, 2024 |  | October 31, 2025 |  | November 1, 2024 |  |  |
|  | (in millions) |
| Interest income — products | $ | 94 |  |  | $ | 82 |  |  | $ | 279 |  |  | $ | 221 |  |  |  |
| Net revenue — products | $ | 222 |  |  | $ | 401 |  |  | $ | 522 |  |  | $ | 1,751 |  |  |  |
| Cost of net revenue — products | 191 |  |  | 333 |  |  | 500 |  |  | 1,488 |  |  |  |
| Gross margin — products | $ | 31 |  |  | $ | 68 |  |  | $ | 22 |  |  | $ | 263 |  |  |  |

[0001571996-25-000127:notes:56]
The following table presents the future maturity of the Company’s customer leases and associated financing payments, and reconciles the undiscounted cash flows to the customer receivables, gross recognized on the Condensed Consolidated Statements of Financial Position as of the date indicated:

[0001571996-25-000127:notes:57]
|  | October 31, 2025 |
|  | (in millions) |
| Fiscal 2026 (remaining three months) | $ | 956 |  |
| Fiscal 2027 | 2,832 |  |
| Fiscal 2028 | 1,484 |  |
| Fiscal 2029 | 879 |  |
| Fiscal 2030 and thereafter | 470 |  |
| Total undiscounted cash flows | 6,621 |  |
| Loans | 7,593 |  |
| Less: Unearned income | (1,071) |  |
| Total customer receivables, gross | $ | 13,143 |  |

[0001571996-25-000127:notes:58]
Operating Leases

[0001571996-25-000127:notes:59]
The Company’s operating leases primarily consist of fixed-term leases and contractually committed embedded leases identified within flexible consumption arrangements.

[0001571996-25-000127:notes:60]
The following table presents the components of the Company’s operating lease portfolio included in property, plant, and equipment, net as of the dates indicated:

[0001571996-25-000127:notes:61]
|  | October 31, 2025 |  | January 31, 2025 |
|  | (in millions) |
| Equipment under operating lease, gross | $ | 4,529 |  |  | $ | 4,180 |  |
| Less: Accumulated depreciation | (2,179) |  |  | (1,995) |  |
| Equipment under operating lease, net | $ | 2,350 |  |  | $ | 2,185 |  |

[0001571996-25-000127:notes:62]
The following table presents operating lease income related to lease payments and depreciation expense for the Company’s operating lease portfolio for the periods indicated:

[0001571996-25-000127:notes:63]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 31, 2025 |  | November 1, 2024 |  | October 31, 2025 |  | November 1, 2024 |  |  |
|  | (in millions) |
| Income related to lease payments | $ | 409 |  |  | $ | 372 |  |  | $ | 1,157 |  |  | $ | 1,090 |  |  |  |
| Depreciation expense | $ | 251 |  |  | $ | 247 |  |  | $ | 751 |  |  | $ | 732 |  |  |  |

[0001571996-25-000127:notes:64]
The following table presents the future payments to be received by the Company in operating lease contracts as of the date indicated:

[0001571996-25-000127:notes:65]
|  | October 31, 2025 |
|  | (in millions) |
| Fiscal 2026 (remaining three months) | $ | 362 |  |
| Fiscal 2027 | 1,171 |  |
| Fiscal 2028 | 726 |  |
| Fiscal 2029 | 357 |  |
| Fiscal 2030 and thereafter | 137 |  |
| Total | $ | 2,753 |  |

[0001571996-25-000127:notes:66]
DFS Debt

[0001571996-25-000127:notes:67]
The Company maintains programs that facilitate the funding of leases, loans, and other alternative payment structures in the capital markets. The majority of DFS debt is non-recourse to Dell Technologies and represents borrowings under securitization programs and structured financing programs for which the Company’s risk of loss is limited to transferred lease and loan payments and associated equipment.

[0001571996-25-000127:notes:68]
The following table presents DFS debt as of the dates indicated and excludes the allocated portion of the Company’s other borrowings, which represents the additional amount considered to fund the DFS business:

[0001571996-25-000127:notes:69]
|  | October 31, 2025 |  | January 31, 2025 |
| DFS debt | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing facility | $ | 2,508 |  |  | $ | 3,018 |  |
| Fixed-term securitization offerings | 3,252 |  |  | 2,756 |  |
| Total DFS U.S. debt, principal amount | 5,760 |  |  | 5,774 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 667 |  |  | 624 |  |
| Other borrowings | 743 |  |  | 754 |  |
| Dell Bank senior unsecured eurobonds | 1,735 |  |  | 1,559 |  |
| Total DFS international debt, principal amount | 3,145 |  |  | 2,937 |  |
| Total DFS debt, principal amount | $ | 8,905 |  |  | $ | 8,711 |  |
| Total short-term DFS debt | $ | 5,130 |  |  | $ | 5,175 |  |
| Total long-term DFS debt | $ | 3,775 |  |  | $ | 3,536 |  |

[0001571996-25-000127:notes:70]
DFS U.S. Debt

[0001571996-25-000127:notes:71]
Asset-Based Financing Facility — The Company maintains an asset-based financing facility in the United States, which is a revolving facility for fixed-term leases and loans. This debt is collateralized solely by the U.S. lease and loan payments and associated equipment in the facility. The asset-based financing facility consists of two tranches, with effective dates through July 7, 2026 and July 7, 2027, respectively. As of October 31, 2025, the total debt capacity related to the asset-based financing facility was $4.6 billion. The debt has a variable interest rate, and the duration of the debt is based on the terms of the underlying lease and loan payment streams. The Company enters into interest rate swap agreements to economically convert a portion of this debt from a floating rate to a fixed rate. See Note 7 of the Notes to the Condensed Consolidated Financial Statements for additional information about the Company’s interest rate swaps.

[0001571996-25-000127:notes:72]
The asset-based financing facility contains standard structural features related to the performance of the funded receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements. In the event one or more of these criteria are not met and the Company is unable to restructure the facility, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed. As of October 31, 2025, these criteria were met.

[0001571996-25-000127:notes:73]
Fixed-Term Securitization Offerings — The Company periodically issues asset-backed debt securities under fixed-term securitization programs to private investors. The asset-backed debt securities are collateralized solely by the U.S. fixed-term lease and loan payments and associated equipment, which are held by Special Purpose Entities (“SPEs”), as discussed below. The interest rate on these securities is fixed and ranges from 4.10% to 6.80% per annum as of October 31, 2025, and the duration of these securities is based on the terms of the underlying lease and loan payment streams.

[0001571996-25-000127:notes:74]
DFS International Debt

[0001571996-25-000127:notes:75]
Securitization Facility — The Company maintains a securitization facility in Europe for fixed-term leases and loans. The debt under this facility has a variable interest rate, and the duration of the debt is based on the terms of the underlying lease and loan payment streams. This facility is effective through December 22, 2026 and had a total debt capacity of $925 million as of October 31, 2025.

[0001571996-25-000127:notes:76]
The securitization facility contains standard structural features related to the performance of the securitized receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements. In the event one or more of these criteria are not met and the Company is unable to restructure the program, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed. As of October 31, 2025, these criteria were met.

[0001571996-25-000127:notes:77]
Other Borrowings — In connection with the Company’s international financing operations, the Company has entered into revolving structured financing debt programs related to its fixed-term lease and loan products sold in Canada, Europe, Australia and New Zealand, the Middle East, and Singapore. The debt under these programs has a variable interest rate.

[0001571996-25-000127:notes:78]
The duration of the debt in Canada, Europe, Australia and New Zealand, and the Middle East is based on the terms of the underlying lease and loan payment streams. These facilities are collateralized solely by the lease and loan payments and associated equipment in their respective region or country. The Canadian facility had a total debt capacity of $250 million as of October 31, 2025 and is effective through January 15, 2028. The European facility had a total debt capacity of $463 million as of October 31, 2025 and is effective through December 14, 2026. The Australia and New Zealand facility had a total debt capacity of $279 million as of October 31, 2025 and is effective through April 17, 2027. The Middle East facility had a total debt capacity of $150 million as of October 31, 2025 and is effective through March 14, 2027.

[0001571996-25-000127:notes:79]
The Company also has two unsecured Singapore facilities, which had a total debt capacity of $254 million as of October 31, 2025 and are effective through July 3, 2026 and July 3, 2027, respectively.

[0001571996-25-000127:notes:80]
Dell Bank Senior Unsecured Eurobonds — On October 27, 2021, Dell Bank issued 500 million Euro of 0.5% senior unsecured five-year eurobonds due October 2026. On October 18, 2022, Dell Bank issued 500 million Euro of 4.5% senior unsecured five-year eurobonds due October 2027. On June 13, 2024, Dell Bank issued 500 million Euro of 3.6% senior unsecured five-year eurobonds due June 2029. The issuances of the senior unsecured eurobonds support the expansion of the financing operations in Europe.

[0001571996-25-000127:notes:81]
Variable Interest Entities

[0001571996-25-000127:notes:82]
In connection with the asset-based financing facility, fixed-term securitization offerings, and securitization facility discussed above, the Company transfers certain U.S. and European lease and loan payments and associated equipment to SPEs that meet the definition of a VIE and are consolidated, along with the associated debt described above, into the Condensed Consolidated Financial Statements, as the Company is the primary beneficiary of the VIEs. The SPEs are bankruptcy-remote legal entities with separate assets and liabilities. The purpose of the SPEs is to facilitate the funding of customer lease and loan payments and associated equipment in the capital markets.

[0001571996-25-000127:notes:83]
Some of the SPEs have entered into financing arrangements with multi-seller conduits that, in turn, issue asset-backed debt securities in the capital markets. DFS debt outstanding held by the consolidated VIEs is collateralized by the lease and loan payments and associated equipment. The Company’s risk of loss related to securitized receivables is limited to the amount by which the Company’s right to receive collections for assets securitized exceeds the amount required to pay interest, principal, and fees and expenses related to the asset-backed securities. The Company provides credit enhancement to the securitization offerings in the form of over-collateralization.

[0001571996-25-000127:notes:84]
The following table presents the assets and liabilities held by the consolidated VIEs as of the dates indicated, which are included in the Condensed Consolidated Statements of Financial Position:

[0001571996-25-000127:notes:85]
|  | October 31, 2025 |  | January 31, 2025 |
|  | (in millions) |
| Assets held by consolidated VIEs |  |  |  |
| Other current assets | $ | 164 |  |  | $ | 123 |  |
| Financing receivables, net of allowance |  |  |  |
| Short-term | $ | 3,292 |  |  | $ | 3,262 |  |
| Long-term | $ | 2,726 |  |  | $ | 2,725 |  |
| Property, plant, and equipment, net | $ | 974 |  |  | $ | 984 |  |
| Liabilities held by consolidated VIEs |  |  |  |
| Debt, net of unamortized debt issuance costs |  |  |  |
| Short-term | $ | 4,069 |  |  | $ | 4,598 |  |
| Long-term | $ | 2,343 |  |  | $ | 1,788 |  |

[0001571996-25-000127:notes:86]
Lease and loan payments and associated equipment transferred via securitization through SPEs were $1.0 billion for both the three months ended October 31, 2025 and November 1, 2024, and $3.0 billion for both the nine months ended October 31, 2025 and November 1, 2024.

[0001571996-25-000127:notes:87]
Customer Receivables Sales

[0001571996-25-000127:notes:88]
To manage certain concentrations of customer credit exposure, the Company may sell selected fixed-term customer receivables to unrelated third parties on a periodic basis, without recourse. The amounts of customer receivables sold for this purpose were immaterial for both the nine months ended October 31, 2025 and November 1, 2024. The Company’s continuing involvement in these customer receivables is primarily limited to servicing arrangements.


## us-gaap:ScheduleOfDebtTableTextBlock

[0001571996-25-000127:notes:89]
The following table summarizes the Company’s outstanding debt as of the dates indicated:

[0001571996-25-000127:notes:90]
|  | October 31, 2025 |  | January 31, 2025 |
|  | (in millions) |
| Senior Notes | $ | 21,573 |  |  | $ | 15,073 |  |
| Legacy Notes | 952 |  |  | 952 |  |
| DFS Debt (Note 4) | 8,905 |  |  | 8,711 |  |
| Other | 85 |  |  | 52 |  |
| Total debt, principal amount | 31,515 |  |  | 24,788 |  |
| Unamortized discount, net of unamortized premium | (115) |  |  | (110) |  |
| Debt issuance costs | (157) |  |  | (111) |  |
| Total debt, carrying value | $ | 31,243 |  |  | $ | 24,567 |  |
| Total short-term debt, carrying value | $ | 7,394 |  |  | $ | 5,204 |  |
| Total long-term debt, carrying value | $ | 23,849 |  |  | $ | 19,363 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0001571996-25-000127:notes:91]
LEASES 
The Company enters into leasing transactions in which the Company is the lessee. These lease contracts are typically classified as operating leases. The Company’s lease contracts are generally for office buildings used to conduct its business, and the determination of whether such contracts contain leases generally does not require significant estimates or judgments. The Company also leases certain global logistics warehouses, employee vehicles, and equipment. As of October 31, 2025, the remaining terms of the Company’s leases generally range from one month to approximately eleven years. As of October 31, 2025 and January 31, 2025, there were no material finance leases in which the Company was a lessee.

[0001571996-25-000127:notes:92]
[same as prior period, unchanged from 0001571996-25-000102:notes:91]

[0001571996-25-000127:notes:93]
[same as prior period, unchanged from 0001571996-25-000102:notes:92]

[0001571996-25-000127:notes:94]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 31, 2025 |  | November 1, 2024 |  | October 31, 2025 |  | November 1, 2024 |  |  |
|  | (in millions) |
| Operating lease costs | $ | 62 |  |  | $ | 75 |  |  | $ | 181 |  |  | $ | 221 |  |  |  |
| Variable costs | 16 |  |  | 15 |  |  | 57 |  |  | 48 |  |  |  |
| Total lease costs | $ | 78 |  |  | $ | 90 |  |  | $ | 238 |  |  | $ | 269 |  |  |  |

[0001571996-25-000127:notes:95]
During the three and nine months ended October 31, 2025 and November 1, 2024, sublease income, finance lease costs, and short-term lease costs were immaterial.

[0001571996-25-000127:notes:96]
[same as prior period, unchanged from 0001571996-25-000102:notes:95]

[0001571996-25-000127:notes:97]
|  | Classification |  | October 31, 2025 |  | January 31, 2025 |  |  |
|  |  |  | (in millions, except for term and discount rate) |
| Operating lease right-of-use assets | Other non-current assets |  | $ | 675 |  | $ | 660 |  |  |
| Current operating lease liabilities | Accrued and other current liabilities |  | $ | 247 |  | $ | 236 |  |  |
| Non-current operating lease liabilities | Other non-current liabilities |  | 517 |  | 522 |  |  |
| Total operating lease liabilities |  |  | $ | 764 |  | $ | 758 |  |  |
| Weighted-average remaining lease term (in years) |  |  | 4.21 |  | 4.36 |  |  |
| Weighted-average discount rate |  |  | 4.90 | % |  | 5.14 | % |  |  |

[0001571996-25-000127:notes:98]
[same as prior period, unchanged from 0001571996-25-000102:notes:97]

[0001571996-25-000127:notes:99]
|  | Nine Months Ended |
|  | October 31, 2025 |  | November 1, 2024 |  |  |
|  | (in millions) |
| Cash paid for amounts included in the measurement of lease liabilities — operating cash outflows from operating leases | $ | 194 |  |  | $ | 201 |  |  |  |
| Right-of-use assets obtained in exchange for new operating lease liabilities | $ | 144 |  |  | $ | 165 |  |  |  |

[0001571996-25-000127:notes:100]
[same as prior period, unchanged from 0001571996-25-000102:notes:99]

[0001571996-25-000127:notes:101]
|  | October 31, 2025 |
|  | (in millions) |
| Fiscal 2026 (remaining three months) | $ | 62 |  |
| Fiscal 2027 | 244 |  |
| Fiscal 2028 | 197 |  |
| Fiscal 2029 | 139 |  |
| Fiscal 2030 | 98 |  |
| Thereafter | 101 |  |
| Total lease payments | 841 |  |
| Less: Imputed interest | 77 |  |
| Total | $ | 764 |  |
| Current operating lease liabilities | $ | 247 |  |
| Non-current operating lease liabilities | $ | 517 |  |

[0001571996-25-000127:notes:102]
As of October 31, 2025, the Company’s undiscounted operating leases that had not yet commenced were immaterial.


## us-gaap:DebtDisclosureTextBlock

[0001571996-25-000127:notes:103]
DEBT
The following table summarizes the Company’s outstanding debt as of the dates indicated:

[0001571996-25-000127:notes:104]
The Company completed the following transactions during the nine months ended October 31, 2025:

[0001571996-25-000127:notes:105]
•the issuance of $1.0 billion principal amount of 4.75% Senior Notes due April 2028, $1.0 billion principal amount of 5.00% Senior Notes due April 2030, $1.0 billion principal amount of 5.30% Senior Notes due April 2032, and $1.0 billion principal amount of 5.50% Senior Notes due April 2035, the proceeds of which were utilized for general corporate purposes; and

[0001571996-25-000127:notes:106]
•the issuance of $0.75 billion principal amount of 4.15% Senior Notes due February 2029, $1.25 billion principal amount of 4.50% Senior Notes due February 2031, $1.25 billion principal amount of 4.75% Senior Notes due October 2032, and $1.25 billion principal amount of 5.10% Senior Notes due February 2036, the proceeds of which were utilized for general corporate purposes and to prepay a portion of the outstanding 6.02% Senior Notes due June 2026.

[0001571996-25-000127:notes:107]
Outstanding Debt

[0001571996-25-000127:notes:108]
Senior Notes — The Company completed offerings of multiple series of senior notes which were issued on June 1, 2016, June 22, 2016, March 20, 2019, April 9, 2020, December 13, 2021, January 24, 2023, March 18, 2024, October 8, 2024, April 1, 2025, and October 6, 2025 in aggregate principal amounts of $20.0 billion, $3.3 billion, $4.5 billion, $2.3 billion, $2.3 billion, $2.0 billion, $1.0 billion, $1.5 billion, $4.0 billion, and $4.5 billion, respectively (collectively, the “Senior Notes”). The Senior Notes currently outstanding have maturity dates ranging from 2026 through 2051. Interest rates on these borrowings are fixed, ranging from 3.38% to 8.35% per annum, and interest is payable semiannually.

[0001571996-25-000127:notes:109]
Legacy Notes — The Company has outstanding unsecured notes and debentures (collectively, the “Legacy Notes”) that were issued by Dell Inc. (“Dell”), a wholly-owned subsidiary of Dell Technologies Inc., prior to the acquisition of Dell by Dell Technologies Inc. in the going-private transaction that closed in October 2013. The Legacy Notes’ maturities range from 2028 through 2040. Interest rates on these borrowings are fixed, ranging from 5.40% to 7.10% per annum, and interest is payable semiannually.

[0001571996-25-000127:notes:110]
DFS Debt — See Note 4 and Note 7 of the Notes to the Condensed Consolidated Financial Statements, respectively, for discussion of DFS debt and the interest rate swap agreements that hedge a portion of that debt.

[0001571996-25-000127:notes:111]
Revolving Credit Facility — The Company’s revolving credit facility provides the Company with revolving commitments in an aggregate principal amount of $6.0 billion for general corporate purposes and includes a letter of credit sub-facility of up to $0.5 billion and a swing-line loan sub-facility of up to $0.5 billion. The revolving credit facility also allows the Company to obtain incremental additional commitments on one or more occasions in minimum amounts of $10 million.

[0001571996-25-000127:notes:112]
Borrowings under the revolving credit facility bear interest at a rate per annum equal to an applicable margin plus, at the borrowers’ option, either (a) the specified adjusted term Secured Overnight Financing Rate (“SOFR”) or (b) a base rate. The margin applicable to SOFR and base rate borrowings varies based upon the Company’s existing credit ratings. The base rate is calculated based upon the greatest of the specified prime rate, the specified federal reserve bank rate, or SOFR plus 1%. The borrowers may voluntarily repay outstanding loans at any time without premium or penalty, other than customary breakage costs. The facility matures on November 1, 2027.

[0001571996-25-000127:notes:113]
As of October 31, 2025, the Company had no outstanding borrowings under the revolving credit facility.

[0001571996-25-000127:notes:114]
Commercial Paper Program — The Company maintains a commercial paper program under which the Company may issue unsecured notes in a maximum aggregate face amount of $5.0 billion outstanding at any time, with maturities of up to 397 days from the date of issuance. The notes are sold on customary terms in the U.S. commercial paper market on a private placement basis. The proceeds of the notes are used for general corporate purposes. As of October 31, 2025, the Company had no outstanding issuances under the commercial paper program.

[0001571996-25-000127:notes:115]
The Company may purchase, redeem, prepay, refinance, or otherwise retire any amount of outstanding indebtedness under the terms of such indebtedness at any time and from time to time, in open market or negotiated transactions with the holders of such indebtedness or otherwise, as considered appropriate in light of market conditions and other relevant factors.

[0001571996-25-000127:notes:116]
Covenants — The credit agreement governing the revolving credit facility and the indentures governing the Senior Notes and the Legacy Notes impose various limitations, subject to exceptions, on creating certain liens and entering into sale and lease-back transactions. The foregoing credit agreement and indentures contain customary events of default, and the revolving credit facility is subject to an interest coverage ratio covenant that is tested at the end of each fiscal quarter with respect to the Company’s preceding four fiscal quarters. The Company was in compliance with this financial covenant as of October 31, 2025.

[0001571996-25-000127:notes:117]
Aggregate Future Maturities

[0001571996-25-000127:notes:118]
The following table presents the aggregate future maturities of the Company’s debt as of October 31, 2025, excluding associated carrying value adjustments, for the periods indicated:

[0001571996-25-000127:notes:119]
|  | October 31, 2025 |
|  | (in millions) |
| Fiscal 2026 (remaining three months) | $ | 1,307 |  |
| Fiscal 2027 | 6,819 |  |
| Fiscal 2028 | 2,621 |  |
| Fiscal 2029 | 2,613 |  |
| Fiscal 2030 | 3,855 |  |
| Thereafter | 14,300 |  |
| Total maturities, principal amount | $ | 31,515 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001571996-25-000127:notes:120]
[same as prior period, unchanged from 0001571996-25-000102:notes:117]

[0001571996-25-000127:notes:121]
[same as prior period, unchanged from 0001571996-25-000102:notes:118]

[0001571996-25-000127:notes:122]
[same as prior period, unchanged from 0001571996-25-000102:notes:119]

[0001571996-25-000127:notes:123]
[same as prior period, unchanged from 0001571996-25-000102:notes:120]

[0001571996-25-000127:notes:124]
During the three and nine months ended October 31, 2025 and November 1, 2024, the Company did not discontinue any cash flow hedges related to foreign exchange contracts that had a material impact on the Company’s results of operations due to the probability that the forecasted cash flows would not occur.

[0001571996-25-000127:notes:125]
[same as prior period, unchanged from 0001571996-25-000102:notes:122]

[0001571996-25-000127:notes:126]
[same as prior period, unchanged from 0001571996-25-000102:notes:123]

[0001571996-25-000127:notes:127]
[same as prior period, unchanged from 0001571996-25-000102:notes:124]

[0001571996-25-000127:notes:128]
[same as prior period, unchanged from 0001571996-25-000102:notes:125]

[0001571996-25-000127:notes:129]
[same as prior period, unchanged from 0001571996-25-000102:notes:126]

[0001571996-25-000127:notes:130]
[same as prior period, unchanged from 0001571996-25-000102:notes:127]

[0001571996-25-000127:notes:131]
[same as prior period, unchanged from 0001571996-25-000102:notes:128]

[0001571996-25-000127:notes:132]
[same as prior period, unchanged from 0001571996-25-000102:notes:129]

[0001571996-25-000127:notes:133]
|  | October 31, 2025 |  | January 31, 2025 |
|  | (in millions) |
| Foreign exchange contracts: |  |  |  |
| Designated as cash flow hedging instruments | $ | 7,589 |  |  | $ | 5,965 |  |
| Non-designated as hedging instruments | 6,324 |  |  | 5,683 |  |
| Total | $ | 13,913 |  |  | $ | 11,648 |  |
| Interest rate contracts: |  |  |  |
| Non-designated as hedging instruments | $ | 6,331 |  |  | $ | 6,353 |  |

[0001571996-25-000127:notes:134]
[same as prior period, unchanged from 0001571996-25-000102:notes:131]

[0001571996-25-000127:notes:135]
| Derivatives in Cash Flow Hedging Relationships |  | Gain (Loss) Recognized in Accumulated OCI, Net of Tax, on Derivatives |  | Location of Gain (Loss) Reclassified from Accumulated OCI into Income |  | Gain (Loss) Reclassified from Accumulated OCI into Income |
|  |  | (in millions) |  |  |  | (in millions) |
| For the three months ended October 31, 2025: |
|  |  |  |  | Total net revenue |  | $ | (40) |  |
| Foreign exchange contracts |  | $ | (19) |  |  | Total cost of net revenue |  | (3) |  |
| Total |  | $ | (19) |  |  | Total |  | $ | (43) |  |
| For the three months ended November 1, 2024: |
|  |  |  |  | Total net revenue |  | $ | (57) |  |
| Foreign exchange contracts |  | $ | (9) |  |  | Total cost of net revenue |  | 3 |  |
| Total |  | $ | (9) |  |  | Total |  | $ | (54) |  |
| For the nine months ended October 31, 2025: |
|  |  |  |  | Total net revenue |  | $ | (207) |  |
| Foreign exchange contracts |  | $ | (280) |  |  | Total cost of net revenue |  | (9) |  |
| Total |  | $ | (280) |  |  | Total |  | $ | (216) |  |
| For the nine months ended November 1, 2024: |
|  |  |  |  | Total net revenue |  | $ | (25) |  |
| Foreign exchange contracts |  | $ | 58 |  |  | Total cost of net revenue |  | 8 |  |
| Total |  | $ | 58 |  |  | Total |  | $ | (17) |  |

[0001571996-25-000127:notes:136]
[same as prior period, unchanged from 0001571996-25-000102:notes:133]

[0001571996-25-000127:notes:137]
|  | Three Months Ended |  | Nine Months Ended |  |  |  |  |
|  | October 31, 2025 |  | November 1, 2024 |  | October 31, 2025 |  | November 1, 2024 |  |  |  | Location of Gain (Loss) Recognized |
|  | (in millions) |  |  |
| Foreign exchange contracts | $ | 16 |  |  | $ | (13) |  |  | $ | 345 |  |  | $ | (58) |  |  |  |  | Interest and other, net |
| Interest rate contracts | (4) |  |  | 32 |  |  | (32) |  |  | 21 |  |  |  |  | Interest and other, net |
| Total | $ | 12 |  |  | $ | 19 |  |  | $ | 313 |  |  | $ | (37) |  |  |  |  |  |

[0001571996-25-000127:notes:138]
[same as prior period, unchanged from 0001571996-25-000102:notes:135]

[0001571996-25-000127:notes:139]
|  | October 31, 2025 |
|  | Other Current Assets |  | Other Non-Current Assets |  | Other Current Liabilities |  | Other Non-Current Liabilities |  | Total Fair Value |
|  | (in millions) |
| Derivatives designated as hedging instruments: |
| Foreign exchange contracts in an asset position | $ | 122 |  |  | $ | — |  |  | $ | 26 |  |  | $ | — |  |  | $ | 148 |  |
| Foreign exchange contracts in a liability position | (2) |  |  | — |  |  | (4) |  |  | — |  |  | (6) |  |
| Net asset (liability) | 120 |  |  | — |  |  | 22 |  |  | — |  |  | 142 |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts in an asset position | 141 |  |  | — |  |  | 49 |  |  | — |  |  | 190 |  |
| Foreign exchange contracts in a liability position | (121) |  |  | — |  |  | (124) |  |  | — |  |  | (245) |  |
| Interest rate contracts in an asset position | 7 |  |  | 49 |  |  | — |  |  | — |  |  | 56 |  |
| Interest rate contracts in a liability position | — |  |  | — |  |  | (1) |  |  | (30) |  |  | (31) |  |
| Net asset (liability) | 27 |  |  | 49 |  |  | (76) |  |  | (30) |  |  | (30) |  |
| Total derivatives at fair value | $ | 147 |  |  | $ | 49 |  |  | $ | (54) |  |  | $ | (30) |  |  | $ | 112 |  |
|  | January 31, 2025 |
|  | Other Current Assets |  | Other Non-Current Assets |  | Other Current Liabilities |  | Other Non-Current Liabilities |  | Total Fair Value |
|  | (in millions) |
| Derivatives designated as hedging instruments: |
| Foreign exchange contracts in an asset position | $ | 136 |  |  | $ | — |  |  | $ | 9 |  |  | $ | — |  |  | $ | 145 |  |
| Foreign exchange contracts in a liability position | (7) |  |  | — |  |  | (3) |  |  | — |  |  | (10) |  |
| Net asset (liability) | 129 |  |  | — |  |  | 6 |  |  | — |  |  | 135 |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts in an asset position | 430 |  |  | — |  |  | 53 |  |  | — |  |  | 483 |  |
| Foreign exchange contracts in a liability position | (297) |  |  | — |  |  | (90) |  |  | — |  |  | (387) |  |
| Interest rate contracts in an asset position | — |  |  | 40 |  |  | — |  |  | — |  |  | 40 |  |
| Interest rate contracts in a liability position | — |  |  | — |  |  | (1) |  |  | (43) |  |  | (44) |  |
| Net asset (liability) | 133 |  |  | 40 |  |  | (38) |  |  | (43) |  |  | 92 |  |
| Total derivatives at fair value | $ | 262 |  |  | $ | 40 |  |  | $ | (32) |  |  | $ | (43) |  |  | $ | 227 |  |

[0001571996-25-000127:notes:140]
[same as prior period, unchanged from 0001571996-25-000102:notes:137]

[0001571996-25-000127:notes:141]
|  | October 31, 2025 |
|  | Gross Amounts of Recognized Assets/(Liabilities) |  | Gross Amounts Offset in the Statement of Financial Position |  | Net Amounts of Assets/(Liabilities) Presented in the Statement of Financial Position |  | Gross Amounts not Offset in the Statement of Financial Position |  | Net Amount of Assets/ (Liabilities) Recognized in the Statement of Financial Position |
|  | Financial Instruments |  | Cash Collateral Received or Pledged |  |
|  | (in millions) |
| Derivative instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Financial assets | $ | 394 |  |  | $ | (198) |  |  | $ | 196 |  |  | $ | — |  |  | $ | (39) |  |  | $ | 157 |  |
| Financial liabilities | (282) |  |  | 198 |  |  | (84) |  |  | — |  |  | 1 |  |  | (83) |  |
| Total derivative instruments | $ | 112 |  |  | $ | — |  |  | $ | 112 |  |  | $ | — |  |  | $ | (38) |  |  | $ | 74 |  |
|  | January 31, 2025 |
|  | Gross Amounts of Recognized Assets/(Liabilities) |  | Gross Amounts Offset in the Statement of Financial Position |  | Net Amounts of Assets/(Liabilities) Presented in the Statement of Financial Position |  | Gross Amounts not Offset in the Statement of Financial Position |  | Net Amount of Assets/ (Liabilities) Recognized in the Statement of Financial Position |
|  | Financial Instruments |  | Cash Collateral Received or Pledged |  |
|  | (in millions) |
| Derivative instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Financial assets | $ | 668 |  |  | $ | (366) |  |  | $ | 302 |  |  | $ | — |  |  | $ | (36) |  |  | $ | 266 |  |
| Financial liabilities | (441) |  |  | 366 |  |  | (75) |  |  | — |  |  | 8 |  |  | (67) |  |
| Total derivative instruments | $ | 227 |  |  | $ | — |  |  | $ | 227 |  |  | $ | — |  |  | $ | (28) |  |  | $ | 199 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001571996-25-000127:notes:142]
[same as prior period, unchanged from 0001571996-25-000102:notes:139]

[0001571996-25-000127:notes:143]
[same as prior period, unchanged from 0001571996-25-000102:notes:140]

[0001571996-25-000127:notes:144]
[same as prior period, unchanged from 0001571996-25-000102:notes:141]

[0001571996-25-000127:notes:145]
|  | Infrastructure Solutions Group |  | Client Solutions Group |  |  |  | Total |
|  | (in millions) |
| Balances as of January 31, 2025 | $ | 14,888 |  |  | $ | 4,232 |  |  |  |  | $ | 19,120 |  |
| Impact of foreign currency translation | 238 |  |  | — |  |  |  |  | 238 |  |
| Balances as of October 31, 2025 | $ | 15,126 |  |  | $ | 4,232 |  |  |  |  | $ | 19,358 |  |

[0001571996-25-000127:notes:146]
[same as prior period, unchanged from 0001571996-25-000102:notes:143]

[0001571996-25-000127:notes:147]
[same as prior period, unchanged from 0001571996-25-000102:notes:144]

[0001571996-25-000127:notes:148]
|  | October 31, 2025 |  | January 31, 2025 |
|  | Gross |  | Accumulated Amortization |  | Net |  | Gross |  | Accumulated Amortization |  | Net |
|  | (in millions) |
| Customer relationships | $ | 16,644 |  |  | $ | (15,244) |  |  | $ | 1,400 |  |  | $ | 16,642 |  |  | $ | (15,013) |  |  | $ | 1,629 |  |
| Developed technology | 9,500 |  |  | (9,335) |  |  | 165 |  |  | 9,500 |  |  | (9,211) |  |  | 289 |  |
| Trade names | 875 |  |  | (867) |  |  | 8 |  |  | 875 |  |  | (860) |  |  | 15 |  |
| Definite-lived intangible assets | 27,019 |  |  | (25,446) |  |  | 1,573 |  |  | 27,017 |  |  | (25,084) |  |  | 1,933 |  |
| Indefinite-lived trade names | 3,055 |  |  | — |  |  | 3,055 |  |  | 3,055 |  |  | — |  |  | 3,055 |  |
| Total intangible assets | $ | 30,074 |  |  | $ | (25,446) |  |  | $ | 4,628 |  |  | $ | 30,072 |  |  | $ | (25,084) |  |  | $ | 4,988 |  |

[0001571996-25-000127:notes:149]
Amortization expense related to definite-lived intangible assets was $0.1 billion and $0.2 billion for the three months ended October 31, 2025 and November 1, 2024, respectively, and $0.4 billion and $0.5 billion for the nine months ended October 31, 2025 and November 1, 2024, respectively. There were no material impairment charges related to intangible assets during the three or nine months ended October 31, 2025 and November 1, 2024.

[0001571996-25-000127:notes:150]
[same as prior period, unchanged from 0001571996-25-000102:notes:147]

[0001571996-25-000127:notes:151]
|  | October 31, 2025 |
|  | (in millions) |
| Fiscal 2026 (remaining three months) | $ | 120 |  |
| Fiscal 2027 | 372 |  |
| Fiscal 2028 | 230 |  |
| Fiscal 2029 | 190 |  |
| Fiscal 2030 | 153 |  |
| Thereafter | 508 |  |
| Total | $ | 1,573 |  |

[0001571996-25-000127:notes:152]
[same as prior period, unchanged from 0001571996-25-000102:notes:149]

[0001571996-25-000127:notes:153]
Goodwill and indefinite-lived intangible assets are tested for impairment annually during the third fiscal quarter and whenever events or circumstances may indicate that an impairment has occurred.
During the third quarter of Fiscal 2026, the Company performed the annual assessment for goodwill in each of its reporting units and indefinite-lived intangible assets. The Company is permitted to conduct a qualitative assessment to determine whether it is necessary to perform a quantitative goodwill impairment test. The Company’s qualitative assessment included consideration of the relevant events and circumstances affecting the reporting unit, including macroeconomic, industry and market conditions, recent market transactions, overall financial performance, trends in the public company market valuation, changes in projected future cash flows, and the results of the most recent quantitative assessment, where applicable. Based on this assessment, the Company concluded that it was more likely than not that the estimated fair value of the reporting units and indefinite-lived intangible assets were higher than their respective carrying values.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001571996-25-000127:notes:154]
[same as prior period, unchanged from 0001571996-25-000102:notes:155]

[0001571996-25-000127:notes:155]
[same as prior period, unchanged from 0001571996-25-000102:notes:156]

[0001571996-25-000127:notes:156]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 31, 2025 |  | November 1, 2024 |  | October 31, 2025 |  | November 1, 2024 |
|  | (in millions) |
| Deferred revenue: |  |  |  |  |  |  |  |
| Deferred revenue at beginning of period | $ | 26,181 |  |  | $ | 27,712 |  |  | $ | 25,965 |  |  | $ | 29,145 |  |
| Revenue deferrals | 3,944 |  |  | 3,897 |  |  | 14,371 |  |  | 13,286 |  |
| Revenue recognized | (5,017) |  |  | (5,262) |  |  | (15,228) |  |  | (16,084) |  |
| Other (a) | — |  |  | (136) |  |  | — |  |  | (136) |  |
| Deferred revenue at end of period | $ | 25,108 |  |  | $ | 26,211 |  |  | $ | 25,108 |  |  | $ | 26,211 |  |
| Short-term deferred revenue | $ | 12,649 |  |  | $ | 13,787 |  |  | $ | 12,649 |  |  | $ | 13,787 |  |
| Long-term deferred revenue | $ | 12,459 |  |  | $ | 12,424 |  |  | $ | 12,459 |  |  | $ | 12,424 |  |

[0001571996-25-000127:notes:157]
(a) For the three and nine months ended November 1, 2024, Other represents the reclassification of Secureworks deferred revenue to liabilities held for sale. See Note 1 of the Notes to the Condensed Consolidated Financial Statements for more information about the sale of Secureworks

[0001571996-25-000127:notes:158]
Remaining Performance Obligations — Remaining performance obligations represent the aggregate amount of the transaction price allocated to performance obligations not delivered, or partially undelivered, as of the end of the reporting period. Remaining performance obligations include deferred revenue plus unbilled amounts not yet recorded in deferred revenue. The value of the transaction price allocated to remaining performance obligations as of October 31, 2025 was approximately $51 billion. The Company expects to recognize approximately 67% of remaining performance obligations as revenue in the next twelve months, 16% in the following twelve months, and the remainder thereafter.

[0001571996-25-000127:notes:159]
[same as prior period, unchanged from 0001571996-25-000102:notes:159]

[0001571996-25-000127:notes:160]
Remaining performance obligation estimates are subject to change and are affected by multiple factors, including terminations, changes in the scope of contracts, periodic revalidation, adjustments for revenue that have not materialized, and adjustments for currency.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001571996-25-000127:notes:161]
COMMITMENTS AND CONTINGENCIES 
Purchase Obligations

[0001571996-25-000127:notes:162]
The Company has contractual obligations to purchase goods or services, which specify significant terms (including fixed or minimum quantities to be purchased), fixed, minimum, or variable price provisions, and the approximate timing of the transaction. Purchase obligations are primarily related to commitments with suppliers and software maintenance and support services. As of October 31, 2025, such purchase obligations were $6.0 billion for the remainder of Fiscal 2026, $0.7 billion for Fiscal 2027, $0.6 billion for Fiscal 2028, $0.5 billion for Fiscal 2029, and $0.7 billion for Fiscal 2030 and thereafter.

[0001571996-25-000127:notes:163]
Legal Matters

[0001571996-25-000127:notes:164]
The Company is involved in various claims, suits, assessments, investigations, and legal proceedings that arise from time to time in the ordinary course of its business, consisting of matters involving consumer, antitrust, tax, intellectual property, and other issues on a global basis.

[0001571996-25-000127:notes:165]
The Company accrues a liability when it believes that it is both probable that a liability has been incurred and that it can reasonably estimate the amount of the loss. The Company reviews these accruals at least quarterly and adjusts them to reflect ongoing negotiations, settlements, rulings, advice of legal counsel, and other relevant information. To the extent new information is obtained and the Company’s views on the probable outcomes of claims, suits, assessments, investigations, or legal proceedings change, changes in the Company’s accrued liabilities are recorded in the period in which such a determination is made. For some matters, the incurrence of a liability is not probable or the amount cannot be reasonably estimated and therefore accruals have not been made. As of October 31, 2025, the Company does not currently anticipate that any of the legal proceedings it is involved in will have a material adverse effect on its business, financial condition, results of operations, or cash flows.

[0001571996-25-000127:notes:166]
In accordance with the relevant accounting guidance, the Company provides disclosures of matters where it is at least reasonably possible that the Company could experience a material loss exceeding the amounts already accrued for across all proceedings or matters. In addition, the Company also discloses matters based on its consideration of other matters and qualitative factors, including the experience of other companies in the industry, and investor, customer, and employee relations considerations. As of October 31, 2025, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for across all proceedings or matters has been incurred. However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company’s business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters. Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company’s business, financial condition, results of operations, or cash flows will depend on a number of factors, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.

[0001571996-25-000127:notes:167]
Indemnifications Obligations

[0001571996-25-000127:notes:168]
In the ordinary course of business, the Company enters into various contracts under which it may agree to indemnify other parties for losses incurred from certain events as defined in the relevant contract, such as litigation, regulatory penalties, or claims relating to past performance. Such indemnification obligations may not be subject to maximum loss clauses. Historically, payments related to these indemnification obligations have not been material to the Company.

[0001571996-25-000127:notes:169]
Under the Separation and Distribution Agreement entered into with VMware, Inc. upon completion of its spin-off of VMware, Inc. on November 1, 2021, Dell Technologies agreed to indemnify VMware, Inc., each of its subsidiaries and each of their respective directors, officers, employees, as well as any successors and assigns of the foregoing, from and against all liabilities relating to, arising out of or resulting from, among other matters, the liabilities allocated to Dell Technologies as part of the separation of Dell Technologies and VMware, Inc. (currently operating under the name VMware LLC, and individually and together with its subsidiaries, “VMware”) and their respective businesses (the “Separation”). VMware similarly agreed to indemnify Dell Technologies Inc., each of its subsidiaries and each of their respective directors, officers, and employees from and against all liabilities relating to, arising out of or resulting from, among other matters, the liabilities allocated to VMware as part of the Separation. The amounts that VMware and Dell Technologies may be obligated to pay each other could vary depending on the outcome of certain unresolved tax matters, which may not be resolved for several years. Net income tax indemnification receivables from VMware were immaterial as of October 31, 2025 and January 31, 2025.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001571996-25-000127:notes:170]
INCOME AND OTHER TAXES
For the three months ended October 31, 2025, the Company’s effective income tax rate was 20.2% on pre-tax income of $1.9 billion compared to 19.0% on pre-tax income of $1.4 billion for the three months ended November 1, 2024. For the nine months ended October 31, 2025, the Company’s effective income tax rate was 17.6% on pre-tax income of $4.5 billion compared to 1.0% on pre-tax income of $3.1 billion for the nine months ended November 1, 2024. The changes in the Company’s effective income tax rate were primarily driven by discrete tax items. For the nine months ended November 1, 2024, the Company recorded discrete tax benefits of $0.4 billion related to changes in uncertain tax benefits resulting from the expiration of certain U.S. statutes of limitations and $0.2 billion related to stock-based compensation.

[0001571996-25-000127:notes:171]
On July 4, 2025, the One Big Beautiful Bill Act (“OBBBA”) was enacted into law in the United States. The new law contains a broad range of tax reform provisions, which include the extension and modification of certain provisions of the Tax Cuts and Jobs Act. Effective for Fiscal 2026, changes include, but are not limited to, immediate expensing of domestic research and development expenditures, the restoration of 100% bonus depreciation, and an EBITDA-based interest expense limitation. These provisions did not have a material impact on the Company’s Condensed Consolidated Financial Statements for the nine months ended October 31, 2025.

[0001571996-25-000127:notes:172]
The differences between the estimated effective income tax rates and the U.S. federal statutory rate of 21% principally result from the geographical distribution of income, differences between the book and tax treatment of certain items, and discrete tax items. In certain jurisdictions, the Company’s tax rate is significantly less than the applicable statutory rate as a result of tax holidays. The majority of the Company’s foreign income subject to these tax holidays and lower tax rates is attributable to Singapore and China. As of October 31, 2025, the Company was not aware of any matters of non-compliance related to these tax holidays.

[0001571996-25-000127:notes:173]
[same as prior period, unchanged from 0001571996-25-000102:notes:173]

[0001571996-25-000127:notes:174]
[same as prior period, unchanged from 0001571996-25-000102:notes:174]

[0001571996-25-000127:notes:175]
[same as prior period, unchanged from 0001571996-25-000102:notes:175]

[0001571996-25-000127:notes:176]
Judgment is required in evaluating the Company’s uncertain tax positions and determining the Company’s provision for income taxes. Net unrecognized tax benefits were $1.0 billion and $0.9 billion as of October 31, 2025 and January 31, 2025, respectively, and are included in other non-current liabilities in the Condensed Consolidated Statements of Financial Position.

[0001571996-25-000127:notes:177]
The Company takes certain non-income tax positions in the jurisdictions in which it operates and has received certain non-income tax assessments from various jurisdictions. The Company believes that a material loss in these matters is not probable and that it is not reasonably possible that a material loss exceeding amounts already accrued has been incurred. The Company believes its positions in these non-income tax litigation matters are supportable and that it ultimately will prevail in the matters. In the normal course of business, the Company’s positions and conclusions related to its non-income taxes could be challenged and assessments may be made. To the extent new information is obtained and the Company’s views on its positions, probable outcomes of assessments, or litigation change, changes in estimates to the Company’s accrued liabilities would be recorded in the period in which such a determination is made. In the resolution process for income tax and non-income tax audits, the Company is required in certain situations to provide collateral guarantees or indemnification to regulators and tax authorities until the matter is resolved.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001571996-25-000127:notes:178]
[same as prior period, unchanged from 0001571996-25-000102:notes:178]

[0001571996-25-000127:notes:179]
[same as prior period, unchanged from 0001571996-25-000102:notes:179]

[0001571996-25-000127:notes:180]
|  | Foreign Currency Translation Adjustments |  |  |  | Cash Flow Hedges |  | Pension and Other Postretirement Plans |  | Accumulated Other Comprehensive Income (Loss) |
|  | (in millions) |
| Balances as of January 31, 2025 | $ | (1,023) |  |  |  |  | $ | 105 |  |  | $ | (21) |  |  | $ | (939) |  |
| Other comprehensive income (loss) before reclassifications | 345 |  |  |  |  | (280) |  |  | (1) |  |  | 64 |  |
| Amounts reclassified from accumulated other comprehensive income (loss) | — |  |  |  |  | 216 |  |  | (3) |  |  | 213 |  |
| Sale of Secureworks (a) | 8 |  |  |  |  | — |  |  | — |  |  | 8 |  |
| Total change for the period | 353 |  |  |  |  | (64) |  |  | (4) |  |  | 285 |  |
| Balances as of October 31, 2025 | $ | (670) |  |  |  |  | $ | 41 |  |  | $ | (25) |  |  | $ | (654) |  |

[0001571996-25-000127:notes:181]
[same as prior period, unchanged from 0001571996-25-000102:notes:181]

[0001571996-25-000127:notes:182]
[same as prior period, unchanged from 0001571996-25-000102:notes:182]

[0001571996-25-000127:notes:183]
[same as prior period, unchanged from 0001571996-25-000102:notes:183]

[0001571996-25-000127:notes:184]
|  | Three Months Ended |  |  |  |  |  |  |  |  |
|  | October 31, 2025 |  | November 1, 2024 |  |  |  |  |  |  |  |  |
|  | Cash Flow Hedges |  | Pensions |  | Total |  | Cash Flow Hedges |  | Pensions |  | Total |  |  |  |  |  |  |  |  |
|  | (in millions) |  |  |  |  |  |  |  |  |
| Total reclassifications, net of tax: |  |  |  |  |  |  |  |  |
| Net revenue | $ | (40) |  |  | $ | — |  |  | $ | (40) |  |  | $ | (57) |  |  | $ | — |  |  | $ | (57) |  |  |  |  |  |  |  |  |  |
| Cost of net revenue | (3) |  |  | — |  |  | (3) |  |  | 3 |  |  | — |  |  | 3 |  |  |  |  |  |  |  |  |  |
| Interest and other, net | — |  |  | 3 |  |  | 3 |  |  | — |  |  | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Total reclassifications, net of tax | $ | (43) |  |  | $ | 3 |  |  | $ | (40) |  |  | $ | (54) |  |  | $ | — |  |  | $ | (54) |  |  |  |  |  |  |  |  |  |

[0001571996-25-000127:notes:185]
|  |  |  | Nine Months Ended |
|  |  |  | October 31, 2025 |  | November 1, 2024 |  |  |
|  |  |  | Cash Flow Hedges |  |  |  |  |  | Pensions |  |  |  | Total |  | Cash Flow Hedges |  | Pensions |  | Total |  |  |  |  |  |  |
|  |  |  | (in millions) |
| Total reclassifications, net of tax: |  |  |  |  |  |  |
| Net revenue |  |  | $ | (207) |  |  |  |  |  |  | $ | — |  |  |  |  | $ | (207) |  |  | $ | (25) |  |  | $ | — |  |  | $ | (25) |  |  |  |  |  |  |  |
| Cost of net revenue |  |  | (9) |  |  |  |  |  |  | — |  |  |  |  | (9) |  |  | 8 |  |  | — |  |  | 8 |  |  |  |  |  |  |  |
| Operating expenses |  |  | — |  |  |  |  |  |  | — |  |  |  |  | — |  |  | — |  |  | 1 |  |  | 1 |  |  |  |  |  |  |  |
| Interest and other, net |  |  | — |  |  |  |  |  |  | 3 |  |  |  |  | 3 |  |  | — |  |  | — |  |  | — |  |  |  |  |  |  |  |
| Total reclassifications, net of tax |  |  | $ | (216) |  |  |  |  |  |  | $ | 3 |  |  |  |  | $ | (213) |  |  | $ | (17) |  |  | $ | 1 |  |  | $ | (16) |  |  |  |  |  |  |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001571996-25-000127:notes:186]
[same as prior period, unchanged from 0001571996-25-000102:notes:186]

[0001571996-25-000127:notes:187]
|  | Authorized |  | Issued |  | Outstanding |
|  | (in millions) |
| Common stock as of October 31, 2025 |
| Class A | 600 |  |  | 277 |  |  | 277 |  |
| Class B | 200 |  |  | 52 |  |  | 52 |  |
| Class C | 7,900 |  |  | 515 |  |  | 338 |  |
| Class D | 100 |  |  | — |  |  | — |  |
|  | 8,800 |  |  | 844 |  |  | 667 |  |
| Common stock as of January 31, 2025 |
| Class A | 600 |  |  | 277 |  |  | 277 |  |
| Class B | 200 |  |  | 62 |  |  | 62 |  |
| Class C | 7,900 |  |  | 495 |  |  | 357 |  |
| Class D | 100 |  |  | — |  |  | — |  |
|  | 8,800 |  |  | 834 |  |  | 696 |  |

[0001571996-25-000127:notes:188]
[same as prior period, unchanged from 0001571996-25-000102:notes:188]

[0001571996-25-000127:notes:189]
The Company is authorized to issue one million shares of preferred stock, par value $0.01 per share. As of October 31, 2025 and January 31, 2025, no shares of preferred stock were issued or outstanding.

[0001571996-25-000127:notes:190]
[same as prior period, unchanged from 0001571996-25-000102:notes:190]

[0001571996-25-000127:notes:191]
[same as prior period, unchanged from 0001571996-25-000102:notes:191]

[0001571996-25-000127:notes:192]
[same as prior period, unchanged from 0001571996-25-000102:notes:192]

[0001571996-25-000127:notes:193]
[same as prior period, unchanged from 0001571996-25-000102:notes:193]

[0001571996-25-000127:notes:194]
During the nine months ended October 31, 2025, the Company issued 10 million shares of Class C Common Stock to stockholders upon the conversion of 10 million shares of Class B Common Stock in accordance with the Company’s certificate of incorporation. During the fiscal year ended January 31, 2025, the Company issued 100 million shares of Class C Common Stock to stockholders upon the conversion of 76 million shares of Class A Common Stock and 24 million shares of Class B Common Stock in accordance with the Company’s certificate of incorporation.

[0001571996-25-000127:notes:195]
[same as prior period, unchanged from 0001571996-25-000102:notes:195]

[0001571996-25-000127:notes:196]
[same as prior period, unchanged from 0001571996-25-000102:notes:196]

[0001571996-25-000127:notes:197]
[same as prior period, unchanged from 0001571996-25-000102:notes:197]

[0001571996-25-000127:notes:198]
|  |  | Declaration Date |  | Record Date |  | Payment Date |  | Dividend per Share |  | Amount (in millions) |
|  |  | Fiscal 2026 |
|  |  | February 27, 2025 |  | April 22, 2025 |  | May 2, 2025 |  | $ | 0.525 |  |  | $ | 360 |  |
|  |  | June 17, 2025 |  | July 22, 2025 |  | August 1, 2025 |  | $ | 0.525 |  |  | $ | 355 |  |
|  |  | September 4, 2025 |  | October 21, 2025 |  | October 31, 2025 |  | $ | 0.525 |  |  | $ | 351 |  |
|  |  | Fiscal 2025 |
|  |  | February 29, 2024 |  | April 23, 2024 |  | May 3, 2024 |  | $ | 0.445 |  |  | $ | 316 |  |
|  |  | June 11, 2024 |  | July 23, 2024 |  | August 2, 2024 |  | $ | 0.445 |  |  | $ | 314 |  |
|  |  | September 18, 2024 |  | October 22, 2024 |  | November 1, 2024 |  | $ | 0.445 |  |  | $ | 312 |  |

[0001571996-25-000127:notes:199]
During the three and nine months ended October 31, 2025 and November 1, 2024, the Company also paid an immaterial amount of dividend equivalents on eligible vested equity awards which are not included above.

[0001571996-25-000127:notes:200]
[same as prior period, unchanged from 0001571996-25-000102:notes:200]

[0001571996-25-000127:notes:201]
[same as prior period, unchanged from 0001571996-25-000102:notes:201]

[0001571996-25-000127:notes:202]
During the nine months ended October 31, 2025, the Company repurchased approximately 39 million shares of Class C Common Stock for a total purchase price of approximately $4.2 billion. During the nine months ended November 1, 2024, the Company repurchased approximately 16 million shares of Class C Common Stock for a total purchase price of approximately $1.8 billion. 
The above repurchases of Class C Common Stock exclude U.S. federal excise taxes and shares withheld from stock awards to settle employee tax withholding obligations related to the vesting of such awards.


## us-gaap:EarningsPerShareTextBlock

[0001571996-25-000127:notes:203]
[same as prior period, unchanged from 0001571996-25-000102:notes:203]

[0001571996-25-000127:notes:204]
[same as prior period, unchanged from 0001571996-25-000102:notes:204]

[0001571996-25-000127:notes:205]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 31, 2025 |  | November 1, 2024 |  | October 31, 2025 |  | November 1, 2024 |  |  |
| Earnings per share attributable to Dell Technologies Inc. |  |  |
| Dell Technologies Common Stock — Basic | $ | 2.31 |  |  | $ | 1.67 |  |  | $ | 5.41 |  |  | $ | 4.33 |  |  |  |
| Dell Technologies Common Stock — Diluted | $ | 2.28 |  |  | $ | 1.64 |  |  | $ | 5.34 |  |  | $ | 4.24 |  |  |  |

[0001571996-25-000127:notes:206]
[same as prior period, unchanged from 0001571996-25-000102:notes:206]

[0001571996-25-000127:notes:207]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 31, 2025 |  | November 1, 2024 |  | October 31, 2025 |  | November 1, 2024 |  |  |
|  | (in millions) |
| Numerator: Dell Technologies Common Stock |  |  |  |  |  |  |  |  |  |
| Net income attributable to Dell Technologies Inc. — basic and diluted | $ | 1,548 |  |  | $ | 1,175 |  |  | $ | 3,677 |  |  | $ | 3,059 |  |  |  |
| Denominator: Dell Technologies Common Stock weighted-average shares outstanding |  |  |  |  |  |  |  |  |  |
| Weighted-average shares outstanding — basic | 671 |  |  | 703 |  |  | 680 |  |  | 706 |  |  |  |
| Dilutive effect of equity awards | 9 |  |  | 14 |  |  | 9 |  |  | 16 |  |  |  |
| Weighted-average shares outstanding — diluted | 680 |  |  | 717 |  |  | 689 |  |  | 722 |  |  |  |
| Weighted-average shares outstanding — antidilutive | — |  |  | — |  |  | 1 |  |  | — |  |  |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001571996-25-000127:notes:208]
[same as prior period, unchanged from 0001571996-25-000102:notes:208]

[0001571996-25-000127:notes:209]
The Company’s Chief Executive Officer is the Chief Operating Decision Maker (“CODM”). The CODM is regularly provided and reviews segment revenue and segment operating income to assess the performance of each segment and allocate resources to the segments in the annual planning process. The Company’s measure of segment revenue and segment operating income for management reporting purposes excludes Corporate and other, amortization of intangible assets, stock-based compensation expense, and other corporate expenses, as applicable, which are not used in evaluating the results of, or in allocating resources to, the segments. The Company does not allocate assets to the above reportable segments for internal reporting purposes. Additionally, the accounting policies of the segments are the same as those described in Note 2 to the Company’s Annual Report on Form 10-K for the fiscal year ended January 31, 2025.

[0001571996-25-000127:notes:210]
ISG includes the Company’s servers and networking offerings and storage offerings. The Company’s server portfolio includes high-performance general-purpose and AI-optimized servers. The Company’s networking portfolio includes wide area network infrastructure, data center and edge networking switches, and cables and optics. The Company’s comprehensive storage portfolio includes modern and traditional storage solutions that span primary, unstructured and data protection offerings and are delivered through multiple architectures, including all-flash, purpose-built, software-defined and hyper-converged infrastructure platforms. ISG also offers software, peripherals, and services, including consulting and support and deployment.

[0001571996-25-000127:notes:211]
[same as prior period, unchanged from 0001571996-25-000102:notes:211]

[0001571996-25-000127:notes:212]
[same as prior period, unchanged from 0001571996-25-000102:notes:212]

[0001571996-25-000127:notes:213]
[same as prior period, unchanged from 0001571996-25-000102:notes:213]

[0001571996-25-000127:notes:214]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 31, 2025 |  | November 1, 2024 |  | October 31, 2025 |  | November 1, 2024 |  |  |
|  | (in millions) |
| Consolidated net revenue: |  |  |  |  |  |  |  |  |  |
| Infrastructure Solutions Group | $ | 14,107 |  |  | $ | 11,368 |  |  | $ | 41,224 |  |  | $ | 32,241 |  |  |  |
| Client Solutions Group | 12,478 |  |  | 12,131 |  |  | 37,490 |  |  | 36,512 |  |  |  |
| Reportable segment net revenue | 26,585 |  |  | 23,499 |  |  | 78,714 |  |  | 68,753 |  |  |  |
| Corporate and other (a) | 420 |  |  | 867 |  |  | 1,445 |  |  | 2,883 |  |  |  |
| Total consolidated net revenue | $ | 27,005 |  |  | $ | 24,366 |  |  | $ | 80,159 |  |  | $ | 71,636 |  |  |  |
| Consolidated operating income: |  |  |  |  |  |  |  |  |  |
| Infrastructure Solutions Group | $ | 1,743 |  |  | $ | 1,508 |  |  | $ | 4,211 |  |  | $ | 3,528 |  |  |  |
| Client Solutions Group | 748 |  |  | 747 |  |  | 2,204 |  |  | 2,341 |  |  |  |
| Reportable segment operating income (b) | 2,491 |  |  | 2,255 |  |  | 6,415 |  |  | 5,869 |  |  |  |
| Corporate and other (a) | 12 |  |  | (3) |  |  | 38 |  |  | (14) |  |  |  |
| Amortization of intangibles (c) | (121) |  |  | (168) |  |  | (372) |  |  | (504) |  |  |  |
| Stock-based compensation expense (d) | (165) |  |  | (198) |  |  | (534) |  |  | (599) |  |  |  |
| Other corporate expenses (e) | (98) |  |  | (165) |  |  | (490) |  |  | (674) |  |  |  |
| Total consolidated operating income (f) | $ | 2,119 |  |  | $ | 1,721 |  |  | $ | 5,057 |  |  | $ | 4,078 |  |  |  |

[0001571996-25-000127:notes:215]
[same as prior period, unchanged from 0001571996-25-000102:notes:215]

[0001571996-25-000127:notes:216]
[same as prior period, unchanged from 0001571996-25-000102:notes:216]

[0001571996-25-000127:notes:217]
[same as prior period, unchanged from 0001571996-25-000102:notes:217]

[0001571996-25-000127:notes:218]
[same as prior period, unchanged from 0001571996-25-000102:notes:218]

[0001571996-25-000127:notes:219]
[same as prior period, unchanged from 0001571996-25-000102:notes:219]

[0001571996-25-000127:notes:220]
[same as prior period, unchanged from 0001571996-25-000102:notes:220]

[0001571996-25-000127:notes:221]
[same as prior period, unchanged from 0001571996-25-000102:notes:221]

[0001571996-25-000127:notes:222]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 31, 2025 |  | November 1, 2024 |  | October 31, 2025 |  | November 1, 2024 |  |  |
|  | (in millions) |
| Infrastructure Solutions Group: |  |  |  |  |  |  |  |  |  |
| Cost of net revenue | $ | 10,274 |  |  | $ | 7,762 |  |  | $ | 30,488 |  |  | $ | 22,095 |  |  |  |
| Selling, general, and administrative | $ | 1,550 |  |  | $ | 1,597 |  |  | $ | 4,849 |  |  | $ | 5,054 |  |  |  |
| Research and development | $ | 540 |  |  | $ | 501 |  |  | $ | 1,676 |  |  | $ | 1,564 |  |  |  |
| Client Solutions Group: |  |  |  |  |  |  |  |  |  |
| Cost of net revenue | $ | 10,639 |  |  | $ | 10,337 |  |  | $ | 31,959 |  |  | $ | 30,963 |  |  |  |
| Selling, general, and administrative | $ | 958 |  |  | $ | 928 |  |  | $ | 2,912 |  |  | $ | 2,849 |  |  |  |
| Research and development | $ | 133 |  |  | $ | 119 |  |  | $ | 415 |  |  | $ | 359 |  |  |  |

[0001571996-25-000127:notes:223]
[same as prior period, unchanged from 0001571996-25-000102:notes:223]

[0001571996-25-000127:notes:224]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 31, 2025 |  | November 1, 2024 |  | October 31, 2025 |  | November 1, 2024 |  |  |
|  | (in millions) |
| Net revenue: |  |  |  |  |  |  |  |  |  |
| Infrastructure Solutions Group: |  |  |  |  |  |  |  |  |  |
| Servers and networking | $ | 10,125 |  |  | $ | 7,364 |  |  | $ | 29,390 |  |  | $ | 20,502 |  |  |  |
| Storage | 3,982 |  |  | 4,004 |  |  | 11,834 |  |  | 11,739 |  |  |  |
| Total ISG net revenue | $ | 14,107 |  |  | $ | 11,368 |  |  | $ | 41,224 |  |  | $ | 32,241 |  |  |  |
| Client Solutions Group: |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 10,621 |  |  | $ | 10,138 |  |  | $ | 32,448 |  |  | $ | 30,848 |  |  |  |
| Consumer | 1,857 |  |  | 1,993 |  |  | 5,042 |  |  | 5,664 |  |  |  |
| Total CSG net revenue | $ | 12,478 |  |  | $ | 12,131 |  |  | $ | 37,490 |  |  | $ | 36,512 |  |  |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001571996-25-000127:notes:225]
[same as prior period, unchanged from 0001571996-25-000102:notes:225]

[0001571996-25-000127:notes:226]
|  | October 31, 2025 |  | January 31, 2025 |
|  | (in millions) |
| Cash, cash equivalents, and restricted cash: |  |  |  |
| Cash and cash equivalents | $ | 9,569 |  |  | $ | 3,633 |  |
| Cash and cash equivalents — held for sale (a) | — |  |  | 62 |  |
| Restricted cash (b) | 164 |  |  | 124 |  |
| Total cash, cash equivalents, and restricted cash | $ | 9,733 |  |  | $ | 3,819 |  |
| Inventories: |  |  |  |
| Production materials | $ | 4,596 |  |  | $ | 4,432 |  |
| Work-in-process | 1,268 |  |  | 1,128 |  |
| Finished goods | 1,085 |  |  | 1,156 |  |
| Total inventories | $ | 6,949 |  |  | $ | 6,716 |  |
| Deferred costs: |  |  |  |
| Total deferred costs, current (c) | $ | 2,763 |  |  | $ | 4,129 |  |
| Property, plant, and equipment, net: |  |  |  |
| Assets in a customer contract | $ | 5,634 |  |  | $ | 5,204 |  |
| Computer and other equipment | 4,042 |  |  | 3,651 |  |
| Land and buildings | 3,052 |  |  | 2,838 |  |
| Internal use software | 2,528 |  |  | 2,403 |  |
| Total property, plant, and equipment | 15,256 |  |  | 14,096 |  |
| Accumulated depreciation and amortization | (8,718) |  |  | (7,760) |  |
| Total property, plant, and equipment, net | $ | 6,538 |  |  | $ | 6,336 |  |

[0001571996-25-000127:notes:227]
[same as prior period, unchanged from 0001571996-25-000102:notes:227]

[0001571996-25-000127:notes:228]
[same as prior period, unchanged from 0001571996-25-000102:notes:228]

[0001571996-25-000127:notes:229]
(c)Deferred costs are included in other current assets in the Condensed Consolidated Statements of Financial Position. Amounts classified as long-term deferred costs are included in other non-current assets and are not disclosed above.

[0001571996-25-000127:notes:230]
[same as prior period, unchanged from 0001571996-25-000102:notes:230]

[0001571996-25-000127:notes:231]
[same as prior period, unchanged from 0001571996-25-000102:notes:231]

[0001571996-25-000127:notes:232]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 31, 2025 |  | November 1, 2024 |  | October 31, 2025 |  | November 1, 2024 |  |  |
|  | (in millions) |
| Warranty liability: |  |  |  |  |  |  |  |  |  |
| Warranty liability at beginning of period | $ | 439 |  |  | $ | 439 |  |  | $ | 424 |  |  | $ | 426 |  |  |  |
| Costs accrued for new warranty contracts and changes in estimates for pre-existing warranties (a) | 231 |  |  | 228 |  |  | 691 |  |  | 673 |  |  |  |
| Service obligations honored | (239) |  |  | (239) |  |  | (684) |  |  | (671) |  |  |  |
| Warranty liability at end of period (b) | $ | 431 |  |  | $ | 428 |  |  | $ | 431 |  |  | $ | 428 |  |  |  |

[0001571996-25-000127:notes:233]
[same as prior period, unchanged from 0001571996-25-000102:notes:233]

[0001571996-25-000127:notes:234]
[same as prior period, unchanged from 0001571996-25-000102:notes:234]

[0001571996-25-000127:notes:235]
[same as prior period, unchanged from 0001571996-25-000102:notes:235]

[0001571996-25-000127:notes:236]
[same as prior period, unchanged from 0001571996-25-000102:notes:236]

[0001571996-25-000127:notes:237]
[same as prior period, unchanged from 0001571996-25-000102:notes:237]

[0001571996-25-000127:notes:238]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 31, 2025 |  | November 1, 2024 |  | October 31, 2025 |  | November 1, 2024 |  |  |
|  | (in millions) |
| Severance liability: |  |  |  |  |  |  |  |  |  |
| Severance liability at beginning of period | $ | 211 |  |  | $ | 392 |  |  | $ | 238 |  |  | $ | 352 |  |  |  |
| Severance charges | 115 |  |  | 145 |  |  | 449 |  |  | 565 |  |  |  |
| Cash paid and other | (200) |  |  | (296) |  |  | (561) |  |  | (676) |  |  |  |
| Severance liability at end of period | $ | 126 |  |  | $ | 241 |  |  | $ | 126 |  |  | $ | 241 |  |  |  |

[0001571996-25-000127:notes:239]
[same as prior period, unchanged from 0001571996-25-000102:notes:239]

[0001571996-25-000127:notes:240]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 31, 2025 |  | November 1, 2024 |  | October 31, 2025 |  | November 1, 2024 |  |  |
|  | (in millions) |
| Severance charges: |  |  |  |  |  |  |  |  |  |
| Cost of net revenue | $ | 33 |  |  | $ | 31 |  |  | $ | 111 |  |  | $ | 116 |  |  |  |
| Selling, general, and administrative | 49 |  |  | 71 |  |  | 244 |  |  | 341 |  |  |  |
| Research and development | 33 |  |  | 43 |  |  | 94 |  |  | 108 |  |  |  |
| Total severance charges | $ | 115 |  |  | $ | 145 |  |  | $ | 449 |  |  | $ | 565 |  |  |  |

[0001571996-25-000127:notes:241]
[same as prior period, unchanged from 0001571996-25-000102:notes:241]

[0001571996-25-000127:notes:242]
The Company maintains a Supply Chain Finance Program (the “SCF Program”), which enables eligible suppliers, at the supplier's sole discretion, to sell receivables due from the Company to a third-party financial institution. The Company has no involvement in establishing the terms or conditions of the arrangement between its suppliers and the financial institution and no economic interest in a supplier's decision to sell a receivable, and does not provide legally secured assets or other forms of guarantees under the arrangement. The SCF Program does not impact the Company's liquidity, as payments for participating supplier invoices are remitted by the Company to the financial institution on the original invoice due date, regardless of whether an individual invoice is sold by the supplier to the financial institution. As of October 31, 2025 and January 31, 2025, the Company had $1.1 billion and $1.4 billion, respectively, included within accounts payable on the Condensed Consolidated Statements of Financial Position representing invoices due to suppliers confirmed as valid under the SCF Program.

[0001571996-25-000127:notes:243]
[same as prior period, unchanged from 0001571996-25-000102:notes:243]

[0001571996-25-000127:notes:244]
[same as prior period, unchanged from 0001571996-25-000102:notes:244]

[0001571996-25-000127:notes:245]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 31, 2025 |  | November 1, 2024 |  | October 31, 2025 |  | November 1, 2024 |  |  |
|  | (in millions) |
| Interest and other, net: |  |  |  |  |  |  |  |  |  |
| Investment income, primarily interest | $ | 72 |  |  | $ | 35 |  |  | $ | 167 |  |  | $ | 127 |  |  |  |
| Gain on investments, net | 173 |  |  | 46 |  |  | 194 |  |  | 21 |  |  |  |
| Interest expense | (396) |  |  | (321) |  |  | (1,149) |  |  | (1,051) |  |  |  |
| Foreign exchange | (37) |  |  | (29) |  |  | (57) |  |  | (80) |  |  |  |
| Gain on disposition of businesses and assets | — |  |  | — |  |  | 236 |  |  | — |  |  |  |
| Other | 10 |  |  | (7) |  |  | 16 |  |  | (19) |  |  |  |
| Total interest and other, net | $ | (178) |  |  | $ | (276) |  |  | $ | (593) |  |  | $ | (1,002) |  |  |  |


## us-gaap:ErrorCorrectionTextBlock

[0001571996-25-000127:notes:246]
REVISION OF PREVIOUSLY ISSUED FINANCIAL STATEMENTS
As discussed in Note 1 of the Notes to the Condensed Consolidated Financial Statements and as previously reported in the Company’s Annual Report on Form 10-K for the fiscal year ended January 31, 2025, the Company discovered accumulated credits from certain suppliers that were not recorded or not recorded in the correct period in its previously reported financial results. Accordingly, the Company has revised its previously reported quarterly financial information for the three and nine months ended November 1, 2024 based on the summary presented below to correct for the overstatement of cost of net revenue to the Condensed Consolidated Statements of Income, net of the related income tax effect. The revision did not have an impact on the Company’s net revenue.

[0001571996-25-000127:notes:247]
A summary of the corrections to the affected financial statement line items in these Condensed Consolidated Financial Statements is presented below.

[0001571996-25-000127:notes:248]
Condensed Consolidated Statements of Income

[0001571996-25-000127:notes:249]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 1, 2024 |  | November 1, 2024 |
|  | As Reported |  | Adjustment |  | As Revised |  | As Reported |  | Adjustment |  | As Revised |
|  | (in millions, except per share amounts) |
| Cost of net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Products | $ | 15,541 |  |  | $ | (53) |  |  | $ | 15,488 |  |  | $ | 45,386 |  |  | $ | (148) |  |  | $ | 45,238 |  |
| Total cost of net revenue | $ | 19,059 |  |  | $ | (53) |  |  | $ | 19,006 |  |  | $ | 56,212 |  |  | $ | (148) |  |  | $ | 56,064 |  |
| Gross margin | $ | 5,307 |  |  | $ | 53 |  |  | $ | 5,360 |  |  | $ | 15,424 |  |  | $ | 148 |  |  | $ | 15,572 |  |
| Operating income | $ | 1,668 |  |  | $ | 53 |  |  | $ | 1,721 |  |  | $ | 3,930 |  |  | $ | 148 |  |  | $ | 4,078 |  |
| Income before income taxes | $ | 1,392 |  |  | $ | 53 |  |  | $ | 1,445 |  |  | $ | 2,928 |  |  | $ | 148 |  |  | $ | 3,076 |  |
| Income tax expense | $ | 265 |  |  | $ | 10 |  |  | $ | 275 |  |  | $ | 5 |  |  | $ | 27 |  |  | $ | 32 |  |
| Net income | $ | 1,127 |  |  | $ | 43 |  |  | $ | 1,170 |  |  | $ | 2,923 |  |  | $ | 121 |  |  | $ | 3,044 |  |
| Net income attributable to Dell Technologies Inc. | $ | 1,132 |  |  | $ | 43 |  |  | $ | 1,175 |  |  | $ | 2,938 |  |  | $ | 121 |  |  | $ | 3,059 |  |
| Earnings per share attributable to Dell Technologies Inc. |  |  |  |  |  |  |
| Basic | $ | 1.61 |  |  | $ | 0.06 |  |  | $ | 1.67 |  |  | $ | 4.16 |  |  | $ | 0.17 |  |  | $ | 4.33 |  |
| Diluted | $ | 1.58 |  |  | $ | 0.06 |  |  | $ | 1.64 |  |  | $ | 4.07 |  |  | $ | 0.17 |  |  | $ | 4.24 |  |

[0001571996-25-000127:notes:250]
(a)The Company’s Condensed Consolidated Statements of Comprehensive Income were also affected by the revised net income amounts for the period presented above.

[0001571996-25-000127:notes:251]
Condensed Consolidated Statements of Cash Flows

[0001571996-25-000127:notes:252]
|  |  |  |  |  | Nine Months Ended |
|  |  |  |  |  | November 1, 2024 |
|  |  |  |  |  |  |  |  |  |  |  |  |  | As Reported |  | Adjustment |  | As Revised |
|  |  |  |  |  |  |  |  |  |  |  |  | (in millions) |
| Cash flow from operations: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  |  |  |  |  |  |  |  |  |  |  |  | $ | 2,923 |  |  | $ | 121 |  |  | $ | 3,044 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |
| Other assets and liabilities |  |  |  |  |  |  |  |  |  |  |  |  | $ | 2,147 |  |  | $ | (7) |  |  | $ | 2,140 |  |
| Accounts payable |  |  |  |  |  |  |  |  |  |  |  |  | $ | 4,089 |  |  | $ | (114) |  |  | $ | 3,975 |  |


## us-gaap:SubsequentEventsTextBlock

[0001571996-25-000127:notes:253]
SUBSEQUENT EVENTS 
There were no known events occurring after October 31, 2025 and up until the date of issuance of this report that would materially affect the information presented herein.
