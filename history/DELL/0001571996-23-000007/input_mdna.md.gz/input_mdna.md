# DELL MD&A — 0001571996-23-000007


## mdna

[0001571996-23-000007:mdna:1]
ITEM 7 — MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0001571996-23-000007:mdna:2]
This management’s discussion and analysis should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in this Annual Report on Form 10-K.  This section of this Form 10-K generally discusses Fiscal 2023 and Fiscal 2022 items and presents year-to-year comparisons between Fiscal 2023 and Fiscal 2022 results.  Discussion of Fiscal 2021 items and year-to-year comparisons between Fiscal 2022 and Fiscal 2021 results that are not included in this Form 10-K are presented in “Part II — Item 7 — Management’s Discussion and Analysis of Financial Condition and Results of Operations” of the Company’s Annual Report on Form 10-K for the fiscal year ended January 28, 2022, as filed with the SEC on March 24, 2022, which is available free of charge on the SEC’s website at www.sec.gov and on our Investor Relations website at investors.delltechnologies.com.

[0001571996-23-000007:mdna:3]
Unless otherwise indicated, all results presented are prepared in a manner that complies, in all material respects, with generally accepted accounting principles in the United States of America (“GAAP”).  Unless otherwise indicated, all changes identified for the current-period results represent comparisons to results for the prior corresponding fiscal period.

[0001571996-23-000007:mdna:4]
Unless the context indicates otherwise, references in this report to “we,” “us,” “our,” the “Company,” and “Dell Technologies” mean Dell Technologies Inc. and its consolidated subsidiaries, references to “Dell” mean Dell Inc. and Dell Inc.’s consolidated subsidiaries, and references to “EMC” mean EMC Corporation and EMC Corporation’s consolidated subsidiaries.

[0001571996-23-000007:mdna:5]
On November 1, 2021, the Company completed its spin-off of VMware, Inc. (individually and together with its consolidated subsidiaries, “VMware”).  In accordance with applicable accounting guidance, the results of VMware, excluding Dell's resale of VMware offerings, are presented as discontinued operations in the Consolidated Statements of Income and, as such, have been excluded from both continuing operations and segment results for all periods prior to the spin-off.  The Consolidated Statements of Cash Flows are presented on a consolidated basis for both continuing operations and discontinued operations for all periods presented.

[0001571996-23-000007:mdna:6]
Our fiscal year is the 52- or 53-week period ending on the Friday nearest January 31.  We refer to our fiscal years ended February 3, 2023, January 28, 2022, and January 29, 2021 as “Fiscal 2023,” “Fiscal 2022,” and “Fiscal 2021,” respectively.  Fiscal 2023 included 53 weeks, while Fiscal 2022 and Fiscal 2021 each included 52 weeks.

[0001571996-23-000007:mdna:7]
INTRODUCTION

[0001571996-23-000007:mdna:8]
Company Overview

[0001571996-23-000007:mdna:9]
Dell Technologies helps organizations build their digital futures and individuals transform how they work, live, and play.  We provide customers with one of the industry’s broadest and most innovative solutions portfolio for the data era, including traditional infrastructure and extending to multi-cloud environments.  Our differentiated and holistic IT solutions benefit our results and enable us to capture revenue growth as customer spending priorities evolve.

[0001571996-23-000007:mdna:10]
Dell Technologies’ integrated solutions help customers modernize their IT infrastructure, manage and operate in a multicloud world, address workforce transformation, and provide critical solutions that keep people and organizations connected.  We are helping customers accelerate their digital transformations to improve and strengthen business and workforce productivity.  With our extensive portfolio and our commitment to innovation, we offer secure, integrated solutions that extend from the edge to the core to the cloud, and we are at the forefront of software-defined and cloud native infrastructure solutions.

[0001571996-23-000007:mdna:11]
Dell Technologies operates globally in approximately 180 countries, supported by a world-class organization across key functional areas, including technology and product development, marketing, sales, financial services, and services.  We have a number of durable competitive advantages that provide a critical foundation for our success.  Our go-to-market engine includes a 31,000-person direct sales force and a global network of approximately 240,000 channel partners.  We employ approximately 35,000 full-time service and support professionals and maintain approximately 2,200 vendor-managed service centers.  We also

[0001571996-23-000007:mdna:12]
36

[0001571996-23-000007:mdna:13]
manage a world-class supply chain at significant scale with approximately $77 billion in annual procurement expenditures and over 725 parts distribution centers.

[0001571996-23-000007:mdna:14]
We further strengthen customer relationships through our financing offerings provided by Dell Financial Services and its affiliates (“DFS”) and our flexible consumption models, including utility, subscription, and as-a-Service models, which we continue to expand under Dell APEX.  These offerings enable our customers to pay over time and provide them with financial flexibility to meet their changing technological requirements.

[0001571996-23-000007:mdna:15]
Our Vision and Strategy

[0001571996-23-000007:mdna:16]
Our vision is to become the most essential technology company for the data era.  We help customers address their evolving IT needs and their broader digital transformation objectives as they embrace today’s multicloud world.  We intend to execute our vision by focusing on two strategic priorities:

[0001571996-23-000007:mdna:17]
•Grow and modernize our core offerings in the markets in which we predominantly compete

[0001571996-23-000007:mdna:18]
•Pursue attractive new growth opportunities such as Edge, Telecom, data management, and as-a-Service consumption models

[0001571996-23-000007:mdna:19]
We believe we are uniquely positioned in the data and multicloud era and that our results will continue to benefit from our durable competitive advantages.  We intend to continue to execute our business model and position our company for long-term success while balancing liquidity, profitability, and growth and keeping our purpose at the forefront of our decision-making: to create technologies that drive human progress.

[0001571996-23-000007:mdna:20]
The IT industry is rapidly evolving with demand for simpler, more agile solutions as companies leverage multiple clouds across their increasingly complex IT environments.  To meet our customer needs, we continue to invest in research and development, sales, and other key areas of our business to deliver superior products and solutions capabilities and to drive long-term sustainable growth.

[0001571996-23-000007:mdna:21]
Products and Services

[0001571996-23-000007:mdna:22]
We design, develop, manufacture, market, sell, and support a wide range of comprehensive and integrated solutions, products, and services.  We are organized into two business units, referred to as Infrastructure Solutions Group and Client Solutions Group, which are our reportable segments.

[0001571996-23-000007:mdna:23]
•Infrastructure Solutions Group (“ISG”) — ISG enables our customers’ digital transformation with solutions that address the fundamental shift to multicloud environments, machine learning, artificial intelligence, and data analytics.  ISG helps customers simplify, streamline, and automate cloud operations.  ISG solutions are built for multicloud environments and are optimized to run cloud native workloads in both public and private clouds, as well as traditional on-premise workloads.

[0001571996-23-000007:mdna:24]
Our comprehensive storage portfolio includes traditional as well as next-generation storage solutions, including all-flash arrays, scale-out file, object platforms, hyper-converged infrastructure, and software-defined storage.  We have simplified our storage portfolio and continue to make enhancements to our storage offerings that we expect will drive long-term improvements in the business.

[0001571996-23-000007:mdna:25]
Our server portfolio includes high-performance rack, blade, and tower servers.  Our servers are designed with the capability to run high value workloads across customers’ IT environments, including artificial intelligence, machine learning, and edge workloads.  Our networking portfolio helps our business customers transform and modernize their infrastructure, mobilize and enrich end-user experiences, and accelerate business applications and processes.

[0001571996-23-000007:mdna:26]
Our strengths in server, storage, and virtualization software solutions allow us to offer leading converged and hyper-converged solutions, enabling our customers to accelerate their IT transformation with scalable integrated solutions instead of building and assembling their own IT platforms.  ISG also offers software, peripherals and services, including configuration, and support and deployment.

[0001571996-23-000007:mdna:27]
Approximately half of ISG revenue is generated by sales to customers in the Americas, with the remaining portion derived from sales to customers in the Europe, Middle East, and Africa region (“EMEA”) and the Asia-Pacific and Japan region (“APJ”).

[0001571996-23-000007:mdna:28]
•Client Solutions Group (“CSG”) — CSG includes branded PCs including notebooks, desktops, and workstations and branded peripherals including displays and docking stations, as well as third-party software and peripherals.  CSG also includes services offerings, including support and deployment, configuration, and extended warranties.  Our CSG offerings are designed with our customers’ needs in mind and we seek to optimize performance, reliability, manageability, design, and security.

[0001571996-23-000007:mdna:29]
Our commercial portfolio provides our customers with solutions centered around flexibility to address their complex needs such as IT modernization, hybrid work transformation, and other critical needs.  Within our high-end consumer offerings, we provide our customers with powerful performance, processing, and end-user experiences.

[0001571996-23-000007:mdna:30]
Approximately half of CSG revenue is generated by sales to customers in the Americas, with the remaining portion derived from sales to customers in EMEA and APJ.

[0001571996-23-000007:mdna:31]
Our “other businesses,” described below, primarily consists of our resale of standalone offerings of VMware, Inc. (individually and together with its subsidiaries, “VMware”), referred to as “VMware Resale,” and offerings of SecureWorks Corp. (“Secureworks”).  These businesses are not classified as reportable segments, either individually or collectively.

[0001571996-23-000007:mdna:32]
•VMware Resale consists of our sale of standalone VMware offerings.  Under our Commercial Framework Agreement with VMware discussed in this report, Dell Technologies continues to act as a key channel partner for VMware, reselling VMware’s offerings to our customers.  This partnership is intended to facilitate mutually beneficial growth for both Dell Technologies and VMware.

[0001571996-23-000007:mdna:33]
VMware works with customers in the areas of hybrid and multicloud, modern applications, networking, security, and digital workspaces, helping customers manage their IT resources across private clouds and complex multicloud, multi-device environments.

[0001571996-23-000007:mdna:34]
•Secureworks (NASDAQ: SCWX) is a leading global cybersecurity provider of technology-driven security solutions singularly focused on protecting its customers by outpacing and outmaneuvering the adversary.  The solutions offered by Secureworks enable organizations of varying size and complexity to prevent security breaches, detect malicious activity, respond rapidly when a security breach occurs, and identify emerging threats.

[0001571996-23-000007:mdna:35]
Our offerings are continually evolving in response to customer needs.  As a result, reclassifications of certain products and services solutions in major product categories may be required.  For further discussion regarding our current reportable segments, see “Results of Operations — Business Unit Results” and Note 19 of the Notes to the Consolidated Financial Statements included in this report.

[0001571996-23-000007:mdna:36]
Dell Financial Services

[0001571996-23-000007:mdna:37]
DFS supports our businesses by offering and arranging various financing options and services for our customers globally.  DFS originates, collects, and services customer receivables primarily related to the purchase or use of our product, software, and services solutions.  We also arrange financing for some of our customers in various countries where DFS does not currently operate as a captive entity.  We further strengthen customer relationships through flexible consumption models, including utility, subscription, and as-a-Service models, which enable us to offer our customers the option to pay over time to provide them with financial flexibility to meet their changing technological requirements.  DFS funded $9.7 billion of originations in Fiscal 2023 and maintains an $11 billion global portfolio of high-quality financing receivables.  The results of these operations are allocated to our segments based on the underlying product or service financed and may be impacted by, among other items, changes in the interest rate environment and the translation of those changes to pricing.  For additional information about our financing arrangements, see Note 6 of the Notes to the Consolidated Financial Statements included in this report.

[0001571996-23-000007:mdna:38]
Product Backlog

[0001571996-23-000007:mdna:39]
Product backlog represents the value of unfulfilled manufacturing orders and is included as a component of remaining performance obligations to the extent we determine that the manufacturing orders are non-cancelable.  Our business model generally gives us the ability to optimize product backlog at any point in time, such as by expediting shipping or prioritizing customer orders for products that have shorter lead times.

[0001571996-23-000007:mdna:40]
Recent Transactions

[0001571996-23-000007:mdna:41]
Spin-Off of VMware, Inc. —  On November 1, 2021, we completed our spin-off of VMware by means of a special stock dividend (the “VMware Spin-off”).  The VMware Spin-off was effectuated pursuant to a Separation and Distribution Agreement, dated as of April 14, 2021, between Dell Technologies and VMware.  As part of the transaction, VMware paid a special cash dividend, pro rata, to each holder of VMware common stock in an aggregate amount equal to $11.5 billion, of which Dell Technologies received $9.3 billion.

[0001571996-23-000007:mdna:42]
In connection with and upon completion of the VMware Spin-off, we entered into a Commercial Framework Agreement (the “CFA”) with VMware, which provides the framework under which we and VMware continue our commercial relationship.  Pursuant to the CFA, we continue to act as a distributor of VMware’s standalone products and services and purchase such products and services for resale to customers.  We also continue to integrate VMware’s products and services with Dell Technologies’ offerings and sell them to customers.  The results of such operations are presented as continuing operations within our Consolidated Statements of Income for all periods presented.

[0001571996-23-000007:mdna:43]
The results of VMware, excluding Dell's resale of VMware offerings, are presented as discontinued operations in the Consolidated Statements of Income and, as such, have been excluded from both continuing operations and segment results for Fiscal 2021 and Fiscal 2022.  The Consolidated Statements of Cash Flows are presented on a consolidated basis for both continuing operations and discontinued operations.  See Note 3 of the Notes to the Consolidated Financial Statements included in this report for additional information about the VMware Spin-off.

[0001571996-23-000007:mdna:44]
Boomi Divestiture — On October 1, 2021, we completed the sale of Boomi, Inc. (“Boomi”) and certain related assets for a total cash consideration of approximately $4.0 billion, resulting in a pre-tax gain on sale of $4.0 billion.  The Company ultimately recorded a $3.0 billion gain, net of $1.0 billion in tax expense.

[0001571996-23-000007:mdna:45]
RSA Divestiture — On September 1, 2020, we completed the sale of RSA Security LLC (“RSA Security”) for total cash consideration of approximately $2.1 billion, resulting in a pre-tax gain on sale of $338 million.  The Company ultimately recorded a $21 million loss net of taxes.

[0001571996-23-000007:mdna:46]
Prior to the divestitures, the operating results of Boomi and RSA Security were included within other businesses and did not qualify for presentation as discontinued operations.

[0001571996-23-000007:mdna:47]
Relationship with VMware

[0001571996-23-000007:mdna:48]
VMware is considered to be a related party of the Company as a result of Michael Dell’s ownership interests in both Dell Technologies and VMware and Mr. Dell’s continued service as Chairman and Chief Executive Officer of Dell Technologies and as Chairman of the Board of VMware, Inc.  Following the completion of the VMware Spin-off, the majority of transactions that occur between Dell Technologies and VMware consist of Dell Technologies’ purchase of VMware products and services for resale, either on a standalone basis or as a part of integrated offerings.  For more information regarding related party transactions with VMware, see Note 21 of the Notes to the Consolidated Financial Statements included in this report.

[0001571996-23-000007:mdna:49]
39

[0001571996-23-000007:mdna:50]
Strategic Investments and Acquisitions

[0001571996-23-000007:mdna:51]
As part of our strategy, we will continue to evaluate opportunities for strategic investments through our venture capital investment arm, Dell Technologies Capital, with a focus on emerging technology areas that are relevant to our business and that will complement our existing portfolio of solutions.  Our investment areas include storage, software-defined networking, management and orchestration, security, machine learning and artificial intelligence, Big Data and analytics, cloud, edge computing, and software development operations.  The technologies or products these companies have under development are typically in the early stages and may never have commercial value, which could result in a loss of a substantial part of our investment in the companies.

[0001571996-23-000007:mdna:52]
During Fiscal 2023, we recognized a net loss of $206 million on our strategic investments, which was generally in line with overall public equity market declines.  As of February 3, 2023 and January 28, 2022, we held strategic investments in non-marketable securities of $1.3 billion and $1.4 billion, respectively.  See Note 5 of the Notes to the Consolidated Financial Statements included in this report for additional information.

[0001571996-23-000007:mdna:53]
In addition to these investments, we also may make disciplined acquisitions targeting businesses that advance our strategic objectives and accelerate our innovation agenda.

[0001571996-23-000007:mdna:54]
Business Trends and Challenges

[0001571996-23-000007:mdna:55]
Fiscal 2023 Significant Developments — During Fiscal 2023, we continued to execute against our strategy and performed well in a challenging macroeconomic environment, generating net revenue and operating income growth. We benefited from our holistic offerings across IT infrastructure as customer spending priorities changed and we saw a shift in the mix of our net revenue towards ISG.

[0001571996-23-000007:mdna:56]
As the fiscal year progressed, we experienced rapidly evolving macroeconomic conditions which impacted the overall demand environment, the availability and cost of components and logistics, and the foreign currency environment.  In response to these conditions, we took certain measures intended to mitigate impacts to our operations, profitability, and liquidity while continuing to proactively address our customers’ demands.  Such measures included disciplined pricing as well as, beginning in the second fiscal quarter, actions to decrease operating expenses, including limiting both discretionary spending and, as announced on February 6, 2023, a decision to reduce our workforce by approximately 5% to align our investments more closely with our previously discussed strategic and customer priorities.

[0001571996-23-000007:mdna:57]
The change in the macroeconomic environment had the greatest effect on CSG, which was impacted by industry-wide demand declines beginning in the first half of Fiscal 2023 that worsened throughout the remainder of the year.  Such dynamics impacted CSG net revenue growth when compared to Fiscal 2022, during which we experienced continued strong demand as a result of global economic recovery.  Within ISG, demand for our server offerings began to moderate in the second quarter of Fiscal 2023, with a decline beginning in the third fiscal quarter as customers exercised caution in response to the macroeconomic conditions.

[0001571996-23-000007:mdna:58]
The impact of the macroeconomic environment caused a shift in component availability as the year progressed.  For the first half of Fiscal 2023, we continued to be affected by industry-wide constraints in the supply of limited-source components, primarily within ISG.  These constraints began to diminish during the third quarter of Fiscal 2023, primarily as a result of the aforementioned declines in the overall demand environment as well as improving supply positions.  As a result, during Fiscal 2023, we lowered our backlog across both CSG and ISG from previously elevated levels.

[0001571996-23-000007:mdna:59]
In addition to impacts to both supply and demand, our input costs, which include logistics and component costs, were also impacted throughout the fiscal year.  Component costs were deflationary for Fiscal 2023.  Although logistics costs remained elevated during the first half of Fiscal 2023, we experienced a significant reduction in these costs during the second half of Fiscal 2023 as we began to see declining rate costs coupled with a reduction in the need to utilize expedited shipments.  We expect that our logistics costs will continue to decline as we enter Fiscal 2024.

[0001571996-23-000007:mdna:60]
We expect that the macroeconomic environment will continue to impact our consolidated financial results in Fiscal 2024.  We currently anticipate a decline in net revenue for the full fiscal year, notably in the first half of the year, which may put pressure on operating margins.  We will continue to actively monitor global events and make prudent decisions to navigate this environment.  We believe our durable competitive advantages continue to position us for long-term success.

[0001571996-23-000007:mdna:61]
Supply Chain — Dell Technologies maintains single-source and limited-source supplier relationships for certain components because the relationships are advantageous in the areas of performance, quality, support, delivery, capacity, and price considerations.

[0001571996-23-000007:mdna:62]
Component cost trends are dependent on the strength or weakness of actual end-user demand and supply dynamics, which will continue to evolve and ultimately impact the translation of the cost environment to pricing and operating results.

[0001571996-23-000007:mdna:63]
We anticipate that overall costs of our key commodities will remain deflationary through the first half of Fiscal 2024.  We expect this favorability to be partially offset by the impacts of industry-wide price increases of certain processors that will affect our cost of net revenue beginning in Fiscal 2024.

[0001571996-23-000007:mdna:64]
Foreign Currency Exposure — We manage our business on a U.S. dollar basis.  However, we have a large global presence, generating approximately half of our net revenue from sales to customers outside of the United States during Fiscal 2023, Fiscal 2022, and Fiscal 2021.  As a result, our operating results can be, and particularly in recent periods have been, impacted by fluctuations in foreign currency exchange rates.  We utilize a comprehensive hedging strategy intended to mitigate the impact of foreign currency volatility over time, and we adjust pricing when possible to further minimize foreign currency impacts.

[0001571996-23-000007:mdna:65]
Ukraine War — We are monitoring and responding to effects of the ongoing war in Ukraine.  When Russia invaded Ukraine, we made the decision to not sell, service, or support products in Russia, Belarus, and restricted regions of Ukraine.  Operations in Russia and Ukraine accounted for less than 1% of net revenue in Fiscal 2022.  During Fiscal 2023, we recognized $171 million in costs associated with exiting our business in Russia, primarily related to asset impairments and other exit related costs.  We have resumed product sales to non-sanctioned areas in Ukraine.  We are focused on providing products and support to Ukrainian customers as they rebuild infrastructure and restore businesses and the financial sector.

[0001571996-23-000007:mdna:66]
The war and the related economic sanctions are impacting markets worldwide.  Our business may be adversely affected by  effects of the war and such sanctions, including supply chain disruptions, product shipping delays, macroeconomic impacts resulting from the exclusion of Russian financial institutions from the global banking system, volatility in foreign exchange rates and interest rates, inflationary pressures, and heightened cybersecurity and data theft threats.  The full impact of the war on our business operations and financial performance will depend on future developments.  We will continue to monitor and assess the related restrictions and other effects and pursue prudent decisions for our team members, customers, and business.

[0001571996-23-000007:mdna:67]
COVID-19 Pandemic and Response — We continue to monitor the COVID-19 pandemic and variants of the coronavirus, as well as the impact the pandemic has on our employees, customers, business partners, and communities.  We will continue to actively monitor global events and pursue prudent decisions to navigate in this uncertain and ever-changing environment.

[0001571996-23-000007:mdna:68]
Inflation Reduction Act — During the third quarter of Fiscal 2023, the Inflation Reduction Act of 2022 (the “2022 Act”) was enacted into law.  The statute includes a 15% corporate alternative minimum tax on adjusted financial statement income which is effective for Fiscal 2024.  The new law also imposes a 1% excise tax on share repurchases, which is effective for repurchases made after December 31, 2022.  We do not expect the 2022 Act to have a material impact on our consolidated financial statements or on our capital allocation decisions.  We will continue to evaluate the law’s impact as further information becomes available.

[0001571996-23-000007:mdna:69]
Other Macroeconomic Risks and Uncertainties — The impacts of trade protection measures, including increases in tariffs and trade barriers, changes in government policies and international trade arrangements, and geopolitical issues may affect our ability to conduct business in some non-U.S. markets.  We monitor and seek to mitigate these risks with adjustments to our manufacturing, supply chain, and distribution networks.

[0001571996-23-000007:mdna:70]
ISG — We expect that ISG will continue to be impacted by the changing nature of the IT infrastructure market and competitive environment.  With our scale and strong solutions portfolio, we believe we are well-positioned to respond to ongoing competitive dynamics.

[0001571996-23-000007:mdna:71]
Through our collaborative, customer-focused approach to innovation, we strive to deliver new and relevant solutions and software to our customers quickly and efficiently.  We continue to focus on customer base expansion and lifetime value of customer relationships.  Our customer base includes a growing number of service providers, such as cloud service providers, Software-as-a-Service companies, consumer webtech providers, and telecommunications companies.  These service providers turn to Dell Technologies for our advanced solutions that enable efficient infrastructure and service delivery at cloud scale.

[0001571996-23-000007:mdna:72]
While we are anticipating challenges in the demand environment as a result of customer caution in response to macroeconomic conditions, we expect that data growth will continue to generate long-term demand for our storage solutions and services.    Cloud native applications are expected to continue to be a key trend in the infrastructure market.  We benefit from offering solutions that address the emerging trends of enterprises deploying software-defined storage, hyper-converged infrastructure, and modular solutions based on server-centric architectures.  These trends are changing the way customers are consuming our storage offerings.  We continue to expand our offerings in external storage arrays, which incorporate flexible, cloud-based functionality.  Our storage business is subject to seasonal trends which we expect to continue.

[0001571996-23-000007:mdna:73]
We anticipate that ISG will benefit from the continued expansion of, and advances in, Artificial Intelligence (“AI”). Through our server and storage offerings, as well as our AI validated design solutions, we are well positioned to capture growth and support our customers needs.  We continue to optimize and enhance our offerings to run high value and transformational workloads, such as AI.

[0001571996-23-000007:mdna:74]
CSG — Our CSG offerings are an important element of our strategy, generating strong cash flow and opportunities for cross-selling of complementary solutions.  Within CSG, we are focused on commercial and high-end consumer computing devices as we believe they are the most stable and profitable segments of the PC market.  Competitive dynamics continue to be a factor in our CSG business and continue to impact pricing and operating results.

[0001571996-23-000007:mdna:75]
We expect industry-wide demand will remain a challenge as we begin Fiscal 2024.  We remain committed to our long-term CSG strategy and will continue to make investments to innovate across the portfolio.  We expect that the CSG demand environment will continue to be subject to seasonal trends.

[0001571996-23-000007:mdna:76]
Recurring Revenue and Consumption Models — Our customers are seeking new and innovative models that address how they consume our solutions.  In part, customers are looking to remove unnecessary cost and complexity, align solution offerings to their business needs, and provide consistent operations throughout their IT enterprise.

[0001571996-23-000007:mdna:77]
We offer options including as-a-Service, subscription, utility, leases, loans, and immediate pay models designed to match customers' consumption and financing preferences.  We believe these options are particularly advantageous for our customers during times of economic uncertainty as they provide customers with financial flexibility to further enable them to procure our solutions.

[0001571996-23-000007:mdna:78]
These offerings typically result in multiyear agreements which generate recurring revenue streams over the term of the arrangement.  We expect that these offerings will further strengthen our customer relationships and provide a foundation for growth in recurring revenue.  We define recurring revenue as revenue recognized that is primarily related to hardware and software maintenance as well as subscription, as-a-Service, usage-based offerings, and operating leases.

[0001571996-23-000007:mdna:79]
Key Performance Metrics

[0001571996-23-000007:mdna:80]
Our key performance metrics include net revenue, operating income, and cash flows from operations, which are discussed elsewhere in this management’s discussion and analysis.

[0001571996-23-000007:mdna:81]
42

[0001571996-23-000007:mdna:82]
NON-GAAP FINANCIAL MEASURES

[0001571996-23-000007:mdna:83]
In this management’s discussion and analysis, we use supplemental measures of our performance which are derived from our consolidated financial information but which are not presented in our consolidated financial statements prepared in accordance with GAAP.  These non-GAAP financial measures include non-GAAP product net revenue; non-GAAP services net revenue; non-GAAP net revenue; non-GAAP product gross margin; non-GAAP services gross margin; non-GAAP gross margin; non-GAAP operating expenses; non-GAAP operating income; non-GAAP net income; earnings before interest and other, net, taxes, depreciation, and amortization (“EBITDA”); and adjusted EBITDA.  The non-GAAP financial measures are not meant to be considered as indicators of performance in isolation from or as a substitute for net revenue, gross margin, operating expenses, operating income, or net income from continuing operations prepared in accordance with GAAP, and should be read only in conjunction with financial information presented on a GAAP basis.

[0001571996-23-000007:mdna:84]
Effective in the first quarter of Fiscal 2023, non-GAAP product net revenue, services net revenue, and net revenue no longer differ from the most comparable GAAP financial measures.  Such non-GAAP financial measures are provided below for all periods presented to show the impact of purchase accounting adjustments on such financial measures in prior periods.

[0001571996-23-000007:mdna:85]
We use non-GAAP financial measures to supplement financial information presented on a GAAP basis.  Management considers these non-GAAP measures in evaluating our operating trends and performance.  Moreover, we believe these non-GAAP financial measures provide our stakeholders with useful and transparent information to help them evaluate our operating results by facilitating an enhanced understanding of our operating performance and enabling them to make more meaningful period to period comparisons.  There are limitations to the use of the non-GAAP financial measures presented in this report.  Our non-GAAP financial measures may not be comparable to similarly titled measures of other companies.  Other companies, including companies in our industry, may calculate non-GAAP financial measures differently than we do, limiting the usefulness of those measures for comparative purposes.

[0001571996-23-000007:mdna:86]
Non-GAAP product net revenue, non-GAAP services net revenue, non-GAAP net revenue, non-GAAP product gross margin, non-GAAP services gross margin, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, and non-GAAP net income, as defined by us, exclude amortization of intangible assets, the impact of purchase accounting, transaction-related expenses, stock-based compensation expense, other corporate expenses and, for non-GAAP net income, fair value adjustments on equity adjustments and an aggregate adjustment for income taxes.  As the excluded items have a material impact on our financial results, our management compensates for this limitation by relying primarily on our GAAP results and using non-GAAP financial measures supplementally or for projections when comparable GAAP financial measures are not available.

[0001571996-23-000007:mdna:87]
Reconciliations of each non-GAAP financial measure to its most directly comparable GAAP financial measure are presented below.  We encourage you to review the reconciliations in conjunction with the presentation of the non-GAAP financial measures for each of the periods presented.  The discussion below includes information on each of the excluded items as well as our reasons for excluding them from our non-GAAP results.  In future fiscal periods, we may exclude such items and may incur income and expenses similar to these excluded items.  Accordingly, the exclusion of these items and other similar items in our non-GAAP presentation should not be interpreted as implying that these items are non-recurring, infrequent, or unusual.

[0001571996-23-000007:mdna:88]
The following is a summary of the items excluded from the most comparable GAAP financial measures to calculate our non-GAAP financial measures:

[0001571996-23-000007:mdna:89]
•Amortization of Intangible Assets — Amortization of intangible assets primarily consists of amortization of customer relationships, developed technology, and trade names.  In connection with our acquisition by merger of EMC, referred to as the “EMC merger transaction,” and the acquisition of Dell Inc. by Dell Technologies Inc., referred to as the “going-private transaction,” all of the tangible and intangible assets and liabilities of EMC and Dell Inc. and its consolidated subsidiaries, respectively, were accounted for and recognized at fair value on the transaction dates.  Accordingly, for the periods presented, amortization of intangible assets represents amortization associated with intangible assets recognized in connection with the EMC merger transaction and the going-private transaction.  Amortization charges for purchased intangible assets are significantly impacted by the timing and magnitude of our acquisitions, and these charges may vary in amount from period to period.  We exclude these charges for purposes of calculating the non-GAAP financial measures presented below to facilitate an enhanced understanding of our current operating performance and provide more meaningful period to period comparisons.

[0001571996-23-000007:mdna:90]
•Impact of Purchase Accounting — The impact of purchase accounting includes purchase accounting adjustments primarily related to the EMC merger transaction recorded under the acquisition method of accounting in accordance with the accounting guidance for business combinations.  Accordingly, all of the assets and liabilities acquired in such transactions were accounted for and recognized at fair value as of the respective transaction dates, and the fair value adjustments continue to amortize over the estimated useful lives in the periods following the transactions.  The fair value adjustments that are still amortizing primarily relate to property, plant, and equipment.  We believe that excluding the impact of purchase accounting for purposes of calculating the non-GAAP financial measures presented below facilitates an enhanced understanding of our current operating performance and provides more meaningful period to period comparisons.

[0001571996-23-000007:mdna:91]
•Transaction-Related (Income) Expenses — Transaction-related expenses typically consist of acquisition, integration, and divestiture related costs, as well as the costs incurred in the VMware Spin-off, and are expensed as incurred.  These expenses primarily represent costs for legal, banking, consulting, and advisory services.  During Fiscal 2022, this category includes $1.5 billion in debt extinguishment fees primarily associated with the early retirement of certain senior notes.  See Note 8 of the Notes to the Consolidated Financial Statements included in this report for additional information on our debt activity.  From time to time, this category also may include transaction-related income related to divestitures of businesses or asset sales.  During Fiscal 2022, we recognized a pre-tax gain of $4.0 billion on the sale of Boomi and during Fiscal 2021, we recognized a pre-tax gain of $338 million on the sale of RSA Security.  We exclude these items for purposes of calculating the non-GAAP financial measures presented below to facilitate an enhanced understanding of our current operating performance and provide more meaningful period to period comparisons.

[0001571996-23-000007:mdna:92]
•Stock-based Compensation Expense — Stock-based compensation expense consists of equity awards granted based on the estimated fair value of those awards at grant date.  To estimate the fair value of performance-based awards containing a market condition, we use the Monte Carlo valuation model.  For other share-based awards, the fair value is generally based on the closing price of the Class C Common Stock as reported on the NYSE on the date of grant.  Although stock-based compensation is an important aspect of the compensation of our employees and executives, the fair value of the stock-based awards may bear little resemblance to the actual value realized upon the vesting or future exercise of the related stock-based awards.  We believe that excluding stock-based compensation expense for purposes of calculating the non-GAAP financial measures presented below facilitates an enhanced understanding of our current operating performance and provides more meaningful period to period comparisons.

[0001571996-23-000007:mdna:93]
•Other Corporate Expenses — Other corporate expenses consist of impairment charges, incentive charges related to equity investments, severance, facility action, payroll taxes associated with stock-based compensation, and other costs.  During Fiscal 2023, other corporate expenses includes $0.9 billion of net expense recognized within interest and other, net, in connection with an agreement to settle the Class V transaction litigation.  See Note 12 of the Notes to the Consolidated Financial Statements included in this report for information about this matter.  Severance costs are primarily related to severance and benefits for employees terminated pursuant to cost savings initiatives.  During Fiscal 2023, other corporate expenses includes $0.5 billion in costs primarily associated with our strategic workforce reduction announced subsequent to the close of Fiscal 2023.  See Note 20 of the Notes to the Consolidated Financial Statements included in this report for information about our severance costs.  Further, during Fiscal 2023, other corporate expenses includes $0.2 billion in costs associated with exiting our business in Russia, primarily related to asset impairments and other exit related costs.  Other corporate expenses vary from period to period and are significantly impacted by the timing and nature of these events.  Therefore, although we may incur these types of expenses in the future, we believe that eliminating these charges for purposes of calculating the non-GAAP financial measures presented below facilitates an enhanced understanding of our current operating performance and provides more meaningful period to period comparisons.

[0001571996-23-000007:mdna:94]
•Fair Value Adjustments on Equity Investments — Fair value adjustments on equity investments primarily consist of the gain (loss) on strategic investments, which includes the recurring fair value adjustments of investments in publicly-traded companies, as well as those in privately-held companies, which are adjusted for observable price changes and any potential impairments.  See Note 4 of the Notes to the Consolidated Financial Statements included in this report for additional information on our strategic investment activity.  Given the volatility in the ongoing adjustments to the valuation of these strategic investments, we believe that excluding these gains and losses for purposes of calculating non-GAAP net income presented below facilitates an enhanced understanding of our current operating performance and provides more meaningful period to period comparisons.

[0001571996-23-000007:mdna:95]
44

[0001571996-23-000007:mdna:96]
•Aggregate Adjustment for Income Taxes — The aggregate adjustment for income taxes is the estimated combined income tax effect for the adjustments described above, as well as an adjustment for discrete tax items.  Due to the variability in recognition of discrete tax items from period to period, we believe that excluding these benefits or charges for purposes of calculating non-GAAP net income facilitates an enhanced understanding of our current operating performance and provides more meaningful period to period comparisons.  The tax effects are determined based on the tax jurisdictions where the above items were incurred.  See Note 13 of the Notes to the Consolidated Financial Statements included in this report for additional information on our income taxes.

[0001571996-23-000007:mdna:97]
The following table presents a reconciliation of each non-GAAP financial measure to the most directly comparable GAAP measure for the periods indicated:

[0001571996-23-000007:mdna:98]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  |  |  | February 3,2023 |  | % Change |  | January 28,2022 |  | % Change |  | January 29,2021 |
|  |  |  |  |  |  |  | (in millions, except percentages) |
| Product net revenue |  |  |  |  |  |  | $ | 79,250 |  |  | (1) | % |  | $ | 79,830 |  |  | 18 | % |  | $ | 67,744 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting |  |  |  |  |  |  | — |  |  |  |  | — |  |  |  |  | 2 |  |
| Non-GAAP product net revenue |  |  |  |  |  |  | $ | 79,250 |  |  | (1) | % |  | $ | 79,830 |  |  | 18 | % |  | $ | 67,746 |  |
| Services net revenue |  |  |  |  |  |  | $ | 23,051 |  |  | 8 | % |  | $ | 21,367 |  |  | 13 | % |  | $ | 18,926 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting |  |  |  |  |  |  | — |  |  |  |  | 32 |  |  |  |  | 104 |  |
| Non-GAAP services net revenue |  |  |  |  |  |  | $ | 23,051 |  |  | 8 | % |  | $ | 21,399 |  |  | 12 | % |  | $ | 19,030 |  |
| Net revenue |  |  |  |  |  |  | $ | 102,301 |  |  | 1 | % |  | $ | 101,197 |  |  | 17 | % |  | $ | 86,670 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting |  |  |  |  |  |  | — |  |  |  |  | 32 |  |  |  |  | 106 |  |
| Non-GAAP net revenue |  |  |  |  |  |  | $ | 102,301 |  |  | 1 | % |  | $ | 101,229 |  |  | 17 | % |  | $ | 86,776 |  |
| Product gross margin |  |  |  |  |  |  | $ | 13,221 |  |  | 5 | % |  | $ | 12,606 |  |  | 11 | % |  | $ | 11,313 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles |  |  |  |  |  |  | 414 |  |  |  |  | 598 |  |  |  |  | 853 |  |
| Impact of purchase accounting |  |  |  |  |  |  | 2 |  |  |  |  | 3 |  |  |  |  | 5 |  |
| Stock-based compensation expense |  |  |  |  |  |  | 52 |  |  |  |  | 48 |  |  |  |  | 23 |  |
| Other corporate expenses |  |  |  |  |  |  | 32 |  |  |  |  | 6 |  |  |  |  | 17 |  |
| Non-GAAP product gross margin |  |  |  |  |  |  | $ | 13,721 |  |  | 3 | % |  | $ | 13,261 |  |  | 9 | % |  | $ | 12,211 |  |
| Services gross margin |  |  |  |  |  |  | $ | 9,465 |  |  | 2 | % |  | $ | 9,285 |  |  | 5 | % |  | $ | 8,827 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting |  |  |  |  |  |  | — |  |  |  |  | 32 |  |  |  |  | 104 |  |
| Stock-based compensation expense |  |  |  |  |  |  | 100 |  |  |  |  | 85 |  |  |  |  | 52 |  |
| Other corporate expenses |  |  |  |  |  |  | 141 |  |  |  |  | 21 |  |  |  |  | 39 |  |
| Non-GAAP services gross margin |  |  |  |  |  |  | $ | 9,706 |  |  | 3 | % |  | $ | 9,423 |  |  | 4 | % |  | $ | 9,022 |  |

[0001571996-23-000007:mdna:99]
46

[0001571996-23-000007:mdna:100]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  |  |  | February 3,2023 |  | % Change |  | January 28,2022 |  | % Change |  | January 29,2021 |
|  |  |  |  |  |  |  | (in millions, except percentages) |
| Gross margin |  |  |  |  |  |  | $ | 22,686 |  |  | 4 | % |  | $ | 21,891 |  |  | 9 | % |  | $ | 20,140 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles |  |  |  |  |  |  | 414 |  |  |  |  | 598 |  |  |  |  | 853 |  |
| Impact of purchase accounting |  |  |  |  |  |  | 2 |  |  |  |  | 35 |  |  |  |  | 109 |  |
| Stock-based compensation expense |  |  |  |  |  |  | 152 |  |  |  |  | 133 |  |  |  |  | 75 |  |
| Other corporate expenses |  |  |  |  |  |  | 173 |  |  |  |  | 27 |  |  |  |  | 56 |  |
| Non-GAAP gross margin |  |  |  |  |  |  | $ | 23,427 |  |  | 3 | % |  | $ | 22,684 |  |  | 7 | % |  | $ | 21,233 |  |
| Operating expenses |  |  |  |  |  |  | $ | 16,915 |  |  | (2) | % |  | $ | 17,232 |  |  | 5 | % |  | $ | 16,455 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles |  |  |  |  |  |  | (556) |  |  |  |  | (1,043) |  |  |  |  | (1,280) |  |
| Impact of purchase accounting |  |  |  |  |  |  | (42) |  |  |  |  | (32) |  |  |  |  | (35) |  |
| Transaction-related expenses |  |  |  |  |  |  | (22) |  |  |  |  | (273) |  |  |  |  | (124) |  |
| Stock-based compensation expense |  |  |  |  |  |  | (779) |  |  |  |  | (675) |  |  |  |  | (412) |  |
| Other corporate expenses |  |  |  |  |  |  | (726) |  |  |  |  | (310) |  |  |  |  | (320) |  |
| Non-GAAP operating expenses |  |  |  |  |  |  | $ | 14,790 |  |  | (1) | % |  | $ | 14,899 |  |  | 4 | % |  | $ | 14,284 |  |
| Operating income |  |  |  |  |  |  | $ | 5,771 |  |  | 24 | % |  | $ | 4,659 |  |  | 26 | % |  | $ | 3,685 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles |  |  |  |  |  |  | 970 |  |  |  |  | 1,641 |  |  |  |  | 2,133 |  |
| Impact of purchase accounting |  |  |  |  |  |  | 44 |  |  |  |  | 67 |  |  |  |  | 144 |  |
| Transaction-related expenses |  |  |  |  |  |  | 22 |  |  |  |  | 273 |  |  |  |  | 124 |  |
| Stock-based compensation expense |  |  |  |  |  |  | 931 |  |  |  |  | 808 |  |  |  |  | 487 |  |
| Other corporate expenses |  |  |  |  |  |  | 899 |  |  |  |  | 337 |  |  |  |  | 376 |  |
| Non-GAAP operating income |  |  |  |  |  |  | $ | 8,637 |  |  | 11 | % |  | $ | 7,785 |  |  | 12 | % |  | $ | 6,949 |  |
| Net income (loss) from continuing operations |  |  |  |  |  |  | $ | 2,422 |  |  | (51) | % |  | $ | 4,942 |  |  | 120 | % |  | $ | 2,245 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles |  |  |  |  |  |  | 970 |  |  |  |  | 1,641 |  |  |  |  | 2,133 |  |
| Impact of purchase accounting |  |  |  |  |  |  | 44 |  |  |  |  | 67 |  |  |  |  | 144 |  |
| Transaction-related (income) expenses |  |  |  |  |  |  | (16) |  |  |  |  | (2,143) |  |  |  |  | (332) |  |
| Stock-based compensation expense |  |  |  |  |  |  | 931 |  |  |  |  | 808 |  |  |  |  | 487 |  |
| Other corporate expenses |  |  |  |  |  |  | 1,812 |  |  |  |  | 337 |  |  |  |  | 268 |  |
| Fair value adjustments on equity investments |  |  |  |  |  |  | 206 |  |  |  |  | (572) |  |  |  |  | (427) |  |
| Aggregate adjustment for income taxes |  |  |  |  |  |  | (642) |  |  |  |  | (156) |  |  |  |  | (772) |  |
| Non-GAAP net income |  |  |  |  |  |  | $ | 5,727 |  |  | 16 | % |  | $ | 4,924 |  |  | 31 | % |  | $ | 3,746 |  |

[0001571996-23-000007:mdna:101]
47

[0001571996-23-000007:mdna:102]
In addition to the above measures, we also use EBITDA and adjusted EBITDA to provide additional information for evaluation of our operating performance.  Adjusted EBITDA excludes purchase accounting adjustments related to the EMC merger transaction and the going-private transaction, acquisition, integration, and divestiture related costs, impairment charges, and severance, facility action, and other costs, and stock-based compensation expense.  We believe that, due to the non-operational nature of the purchase accounting entries, it is appropriate to exclude these adjustments.

[0001571996-23-000007:mdna:103]
As is the case with the non-GAAP measures presented above, users should consider the limitations of using EBITDA and adjusted EBITDA, including the fact that those measures do not provide a complete measure of our operating performance.  EBITDA and adjusted EBITDA do not purport to be alternatives to net income from continuing operations as measures of operating performance or to cash flows from operating activities as a measure of liquidity.  In particular, EBITDA and adjusted EBITDA are not intended to be a measure of free cash flow available for management’s discretionary use, as these measures do not consider certain cash requirements, such as working capital needs, capital expenditures, contractual commitments, interest payments, tax payments, and other debt service requirements.

[0001571996-23-000007:mdna:104]
The following table presents a reconciliation of EBITDA and adjusted EBITDA to net income from continuing operations for the periods indicated:

[0001571996-23-000007:mdna:105]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  |  |  | February 3,2023 |  | % Change |  | January 28,2022 |  | % Change |  | January 29,2021 |
|  |  |  |  |  |  |  | (in millions, except percentages) |
| Net income from continuing operations |  |  |  |  |  |  | $ | 2,422 |  |  | (51) | % |  | $ | 4,942 |  |  | 120 | % |  | $ | 2,245 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest and other, net (a) |  |  |  |  |  |  | 2,546 |  |  |  |  | (1,264) |  |  |  |  | 1,339 |  |
| Income tax expense (benefit) |  |  |  |  |  |  | 803 |  |  |  |  | 981 |  |  |  |  | 101 |  |
| Depreciation and amortization |  |  |  |  |  |  | 3,156 |  |  |  |  | 3,547 |  |  |  |  | 3,867 |  |
| EBITDA |  |  |  |  |  |  | $ | 8,927 |  |  | 9 | % |  | $ | 8,206 |  |  | 9 | % |  | $ | 7,552 |  |
| EBITDA |  |  |  |  |  |  | $ | 8,927 |  |  | 9 | % |  | $ | 8,206 |  |  | 9 | % |  | $ | 7,552 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense |  |  |  |  |  |  | 931 |  |  |  |  | 808 |  |  |  |  | 487 |  |
| Impact of purchase accounting |  |  |  |  |  |  | — |  |  |  |  | 36 |  |  |  |  | 106 |  |
| Transaction-related expenses |  |  |  |  |  |  | 22 |  |  |  |  | 273 |  |  |  |  | 124 |  |
| Other corporate expenses |  |  |  |  |  |  | 899 |  |  |  |  | 337 |  |  |  |  | 376 |  |
| Adjusted EBITDA |  |  |  |  |  |  | $ | 10,779 |  |  | 12 | % |  | $ | 9,660 |  |  | 12 | % |  | $ | 8,645 |  |

[0001571996-23-000007:mdna:106]
____________________

[0001571996-23-000007:mdna:107]
(a)See “Results of Operations — Interest and Other, Net” for more information on the components of interest and other, net.

[0001571996-23-000007:mdna:108]
48

[0001571996-23-000007:mdna:109]
RESULTS OF OPERATIONS

[0001571996-23-000007:mdna:110]
Consolidated Results

[0001571996-23-000007:mdna:111]
The following table summarizes our consolidated results for the periods indicated.  Unless otherwise indicated, all changes identified for the current period results represent comparisons to results for the prior corresponding fiscal period.

[0001571996-23-000007:mdna:112]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  |  |  | February 3, 2023 |  |  |  | January 28, 2022 |  |  |  | January 29, 2021 |
|  |  |  |  |  |  |  |  |  |  |  | Dollars |  | % ofNet Revenue |  | %Change |  | Dollars |  | % ofNet Revenue |  | %Change |  | Dollars |  | % ofNet Revenue |
|  |  |  |  |  |  |  |  |  |  |  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  |  |  |  |  |  |  |  |  |  | $ | 79,250 |  |  | 77.5 | % |  | (1) | % |  | $ | 79,830 |  |  | 78.9 | % |  | 18 | % |  | $ | 67,744 |  |  | 78.2 | % |
| Services |  |  |  |  |  |  |  |  |  |  | 23,051 |  |  | 22.5 | % |  | 8 | % |  | 21,367 |  |  | 21.1 | % |  | 13 | % |  | 18,926 |  |  | 21.8 | % |
| Total net revenue |  |  |  |  |  |  |  |  |  |  | $ | 102,301 |  |  | 100.0 | % |  | 1 | % |  | $ | 101,197 |  |  | 100.0 | % |  | 17 | % |  | $ | 86,670 |  |  | 100.0 | % |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products (a) |  |  |  |  |  |  |  |  |  |  | $ | 13,221 |  |  | 16.7 | % |  | 5 | % |  | $ | 12,606 |  |  | 15.8 | % |  | 11 | % |  | $ | 11,313 |  |  | 16.7 | % |
| Services (b) |  |  |  |  |  |  |  |  |  |  | 9,465 |  |  | 41.1 | % |  | 2 | % |  | 9,285 |  |  | 43.5 | % |  | 5 | % |  | 8,827 |  |  | 46.6 | % |
| Total gross margin |  |  |  |  |  |  |  |  |  |  | $ | 22,686 |  |  | 22.2 | % |  | 4 | % |  | $ | 21,891 |  |  | 21.6 | % |  | 9 | % |  | $ | 20,140 |  |  | 23.2 | % |
| Operating expenses |  |  |  |  |  |  |  |  |  |  | $ | 16,915 |  |  | 16.6 | % |  | (2) | % |  | $ | 17,232 |  |  | 17.0 | % |  | 5 | % |  | $ | 16,455 |  |  | 18.9 | % |
| Operating income |  |  |  |  |  |  |  |  |  |  | $ | 5,771 |  |  | 5.6 | % |  | 24 | % |  | $ | 4,659 |  |  | 4.6 | % |  | 26 | % |  | $ | 3,685 |  |  | 4.3 | % |
| Net income from continuing operations |  |  |  |  |  |  |  |  |  |  | $ | 2,422 |  |  | 2.4 | % |  | (51) | % |  | $ | 4,942 |  |  | 4.9 | % |  | 120 | % |  | $ | 2,245 |  |  | 2.6 | % |
| Non-GAAP Financial Information |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  |  |  | February 3, 2023 |  |  |  | January 28, 2022 |  |  |  | January 29, 2021 |
|  |  |  |  |  |  |  |  |  |  |  | Dollars |  | % of Non-GAAP Net Revenue |  | %Change |  | Dollars |  | % of Non-GAAP Net Revenue |  | %Change |  | Dollars |  | % of Non-GAAP Net Revenue |
|  |  |  |  |  |  |  |  |  |  |  | (in millions, except percentages) |
| Non-GAAP net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  |  |  |  |  |  |  |  |  |  | $ | 79,250 |  |  | 77.5 | % |  | (1) | % |  | $ | 79,830 |  |  | 78.9 | % |  | 18 | % |  | $ | 67,746 |  |  | 78.1 | % |
| Services |  |  |  |  |  |  |  |  |  |  | 23,051 |  |  | 22.5 | % |  | 8 | % |  | 21,399 |  |  | 21.1 | % |  | 12 | % |  | 19,030 |  |  | 21.9 | % |
| Total non-GAAP net revenue |  |  |  |  |  |  |  |  |  |  | $ | 102,301 |  |  | 100.0 | % |  | 1 | % |  | $ | 101,229 |  |  | 100.0 | % |  | 17 | % |  | $ | 86,776 |  |  | 100.0 | % |
| Non-GAAP gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products (a) |  |  |  |  |  |  |  |  |  |  | $ | 13,721 |  |  | 17.3 | % |  | 3 | % |  | $ | 13,261 |  |  | 16.6 | % |  | 9 | % |  | $ | 12,211 |  |  | 18.0 | % |
| Services (b) |  |  |  |  |  |  |  |  |  |  | 9,706 |  |  | 42.1 | % |  | 3 | % |  | 9,423 |  |  | 44.0 | % |  | 4 | % |  | 9,022 |  |  | 47.4 | % |
| Total non-GAAP gross margin |  |  |  |  |  |  |  |  |  |  | $ | 23,427 |  |  | 22.9 | % |  | 3 | % |  | $ | 22,684 |  |  | 22.4 | % |  | 7 | % |  | $ | 21,233 |  |  | 24.5 | % |
| Non-GAAP operating expenses |  |  |  |  |  |  |  |  |  |  | $ | 14,790 |  |  | 14.5 | % |  | (1) | % |  | $ | 14,899 |  |  | 14.7 | % |  | 4 | % |  | $ | 14,284 |  |  | 16.5 | % |
| Non-GAAP operating income |  |  |  |  |  |  |  |  |  |  | $ | 8,637 |  |  | 8.4 | % |  | 11 | % |  | $ | 7,785 |  |  | 7.7 | % |  | 12 | % |  | $ | 6,949 |  |  | 8.0 | % |
| Non-GAAP net income |  |  |  |  |  |  |  |  |  |  | $ | 5,727 |  |  | 5.6 | % |  | 16 | % |  | $ | 4,924 |  |  | 4.9 | % |  | 31 | % |  | $ | 3,746 |  |  | 4.3 | % |
| EBITDA |  |  |  |  |  |  |  |  |  |  | $ | 8,927 |  |  | 8.7 | % |  | 9 | % |  | $ | 8,206 |  |  | 8.1 | % |  | 9 | % |  | $ | 7,552 |  |  | 8.7 | % |
| Adjusted EBITDA |  |  |  |  |  |  |  |  |  |  | $ | 10,779 |  |  | 10.5 | % |  | 12 | % |  | $ | 9,660 |  |  | 9.5 | % |  | 12 | % |  | $ | 8,645 |  |  | 10.0 | % |

[0001571996-23-000007:mdna:113]
____________________

[0001571996-23-000007:mdna:114]
(a)    Product gross margin and non-GAAP product gross margin percentages are calculated as a percentage of product net revenue and non-GAAP product net revenue, respectively.

[0001571996-23-000007:mdna:115]
(b)    Services gross margin and non-GAAP services gross margin percentages are calculated as a percentage of services net revenue and non-GAAP services net revenue, respectively.

[0001571996-23-000007:mdna:116]
Non-GAAP product net revenue, non-GAAP services net revenue, non-GAAP net revenue, non-GAAP product gross margin, non-GAAP services gross margin, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, EBITDA, and adjusted EBITDA are not measurements of financial performance prepared in accordance with GAAP.  Non-GAAP financial measures as a percentage of revenue are calculated based on non-GAAP net revenue.  See “Non‑GAAP Financial Measures” for additional information about these non-GAAP financial measures, including our reasons for including these measures, material limitations with respect to the usefulness of the measures, and a reconciliation of each non-GAAP financial measure to the most directly comparable GAAP financial measure.

[0001571996-23-000007:mdna:117]
Overview

[0001571996-23-000007:mdna:118]
During Fiscal 2023, our net revenue increased 1%, driven by an increase in net revenue for ISG which was mostly offset by a decline in net revenue for CSG.  ISG net revenue increased primarily as a result of continued net revenue growth within both our servers and networking and storage offerings.  CSG net revenue decreased as a result of a decrease in units sold due to an overall decline in the demand environment.

[0001571996-23-000007:mdna:119]
During Fiscal 2023, our operating income increased 24% to $5.8 billion, primarily driven by growth in ISG operating income and the favorable impact of a decrease in amortization of intangible assets.  Growth in ISG operating income for Fiscal 2023 was driven by both our server and networking and storage offerings.  The increase in operating income was partially offset by a decline in CSG operating income as well as the unfavorable impact of an increase in other corporate expenses.  CSG operating income declined during the period principally driven by our consumer offerings.  During Fiscal 2023, our non-GAAP operating income increased 11% to $8.6 billion due to the same ISG and CSG dynamics discussed above.

[0001571996-23-000007:mdna:120]
For Fiscal 2023, operating income as a percentage of net revenue increased 100 basis points to 5.6% principally driven by improvement in gross margin as percentage of net revenue coupled with a decrease in operating expenses as a percentage of net revenue.  Gross margin as a percentage of net revenue increased primarily as a result of a shift in mix towards ISG.  The decline in operating expense as a percentage of net revenue was driven by disciplined cost management and the favorable impact of a decrease in the amortization of intangible assets, partially offset by the unfavorable impact of an increase in other corporate expenses.  Non-GAAP operating income as a percentage of net revenue increased 70 basis points to 8.4% during Fiscal 2023, driven by the same gross margin and disciplined cost management dynamics discussed above.

[0001571996-23-000007:mdna:121]
Cash provided by operating activities was $3.6 billion and $10.3 billion during Fiscal 2023 and Fiscal 2022, respectively.  During Fiscal 2022, $3.2 billion of the $10.3 billion total represented cash provided by operating activities attributable to VMware, Inc.  Cash provided by operating activities during Fiscal 2023 declined primarily as a result of unfavorable working capital dynamics as compared to Fiscal 2022.  Working capital was primarily impacted by a shift in mix of the business, the timing of purchases and payments to vendors during a declining demand environment, and linearity of sales during the fourth quarter of Fiscal 2023.  See “Liquidity, Cash Requirements, and Market Conditions” for further information on our cash flow metrics.

[0001571996-23-000007:mdna:122]
We continue to see opportunities to create value and grow in response to long-term demand for our IT solutions driven by a technology-enabled world.  We have demonstrated our ability to adjust to changing market conditions with complementary solutions across both segments of our business, an agile workforce, and the strength of our global supply chain.  As we continue to innovate and modernize our core offerings, we believe that Dell Technologies is well-positioned for long-term profitable growth.

[0001571996-23-000007:mdna:123]
Net Revenue

[0001571996-23-000007:mdna:124]
During Fiscal 2023, our net revenue increased 1%, primarily driven by growth within ISG net revenue that was mostly offset by a decline in net revenue for CSG.  See “Business Unit Results” for further information.

[0001571996-23-000007:mdna:125]
•Product Net Revenue — Product net revenue includes revenue from the sale of hardware products and software licenses.  During Fiscal 2023, our product net revenue decreased 1%, primarily due to a decline in CSG product net revenue, which was partially offset by growth in ISG product net revenue.  CSG product net revenue decreased primarily as a result of a decline in consumer product net revenue and, to a lesser extent, commercial product net revenue.  These declines were both driven by a decrease in units sold, partially offset by an increase in average selling prices.  ISG product net revenue growth was driven by an increase in product net revenue from both our server and networking and storage offerings.

[0001571996-23-000007:mdna:126]
•Services Net Revenue — Services net revenue includes revenue from our services offerings and support services related to hardware products and software licenses.  During Fiscal 2023, services net revenue increased 8%, driven principally by strength in CSG hardware support and maintenance and third-party software support and maintenance, primarily associated with commercial offerings sold in prior periods.  A substantial portion of services net revenue is derived from offerings that have been deferred over a period of time, and, as a result, reported services net revenue growth rates will be different than reported product net revenue growth rates.

[0001571996-23-000007:mdna:127]
From a geographical perspective, net revenue increased in the Americas and EMEA regions and decreased in the APJ region during Fiscal 2023.

[0001571996-23-000007:mdna:128]
Gross Margin

[0001571996-23-000007:mdna:129]
During Fiscal 2023, gross margin and non-GAAP gross margin increased 4% to $22.7 billion and 3% to $23.4 billion, respectively.  The increases were driven by growth in ISG gross margin which was partially offset by a decline in CSG gross margin.

[0001571996-23-000007:mdna:130]
During Fiscal 2023, our gross margin and non-GAAP gross margin percentages increased 60 basis points to 22.2% and 50 basis points to 22.9%, respectively, primarily due to a shift in mix towards our ISG offerings.

[0001571996-23-000007:mdna:131]
•Product Gross Margin — During Fiscal 2023, product gross margin and non-GAAP product gross margin increased 5% to $13.2 billion and 3% to $13.7 billion, respectively.  These increases were driven primarily by growth in ISG product gross margin due to growth in product net revenue for both our server and networking and storage offerings.  The increases in ISG product gross margin were partially offset by declines in CSG product gross margin primarily due to a decrease in product net revenue for our consumer offerings and, to a lesser extent, a decrease in product net revenue for our commercial offerings.

[0001571996-23-000007:mdna:132]
During Fiscal 2023, product gross margin and non-GAAP product gross margin percentages increased 90 basis points to 16.7% and 70 basis points to 17.3%, respectively, primarily attributable to a shift in mix towards our ISG offerings.

[0001571996-23-000007:mdna:133]
•Services Gross Margin — During Fiscal 2023, services gross margin and non-GAAP services gross margin increased 2% to $9.5 billion and 3% to $9.7 billion, respectively.  The increases were primarily driven by growth in CSG services gross margin, which was partially offset by a decline in other businesses services gross margin.  CSG services gross margin increased as a result of growth within hardware support and maintenance, primarily associated with commercial offerings sold in prior periods, while other businesses services gross margin declined due to the impact of the divestiture of Boomi in Fiscal 2022.

[0001571996-23-000007:mdna:134]
During Fiscal 2023, services gross margin percentage decreased 240 basis points to 41.1%.  The decrease was driven by a decline in services gross margin percentage for ISG, due to a shift in mix of services delivered, coupled with a shift in mix towards CSG services net revenue and the impact of the Boomi divestiture during Fiscal 2022.  Further, the unfavorable impact of an increase in other corporate expenses contributed to the decline.  Non-GAAP services gross margin percentage decreased 190 basis points to 42.1% and was driven by the same ISG, CSG, and Boomi dynamics discussed above.

[0001571996-23-000007:mdna:135]
Vendor Programs

[0001571996-23-000007:mdna:136]
Our gross margin is affected by our ability to achieve competitive pricing with our vendors and contract manufacturers, including through our negotiation of a variety of vendor rebate programs to achieve lower net costs for the various components we include in our products.  Under these programs, vendors provide us with rebates or other discounts from the list prices for the components, which are generally elements of their pricing strategy.  We account for vendor rebates and other discounts as a reduction in cost of net revenue.  We manage our costs on a total net cost basis, which includes supplier list prices reduced by vendor rebates and other discounts.

[0001571996-23-000007:mdna:137]
The terms and conditions of our vendor rebate programs are largely based on product volumes and are generally negotiated either at the beginning of the annual or quarterly period, depending on the program.  The timing and amount of vendor rebates and other discounts we receive under the programs may vary from period to period, reflecting changes in the competitive environment.  We monitor our component costs and seek to address the effects of any changes to terms that might arise under our vendor rebate programs.  Our gross margins for Fiscal 2023 and for Fiscal 2022 were not materially affected by any changes to the terms of our vendor rebate programs, as the amounts we received under these programs were generally stable relative to our total net cost.

[0001571996-23-000007:mdna:138]
We are not aware of any significant changes to our vendor rebate programs that will materially impact our results in the near term. While we anticipate that the impact of industry-wide price increases of certain processors will impact our cost of net revenue beginning in Fiscal 2024, we are also experiencing cost deflation on component parts as a result of overall demand softness.  We will continue to take pricing actions to balance profitability and growth while actively addressing our customers’ demands.

[0001571996-23-000007:mdna:139]
52

[0001571996-23-000007:mdna:140]
Operating Expenses

[0001571996-23-000007:mdna:141]
The following table presents information regarding our operating expenses for the periods indicated:

[0001571996-23-000007:mdna:142]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  |  |  | February 3, 2023 |  |  |  | January 28, 2022 |  |  |  | January 29, 2021 |
|  |  |  |  |  |  |  |  |  |  |  | Dollars |  | % of Net Revenue |  | %Change |  | Dollars |  | % of Net Revenue |  | %Change |  | Dollars |  | % of Net Revenue |
|  |  |  |  |  |  |  |  |  |  |  | (in millions, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative |  |  |  |  |  |  |  |  |  |  | $ | 14,136 |  |  | 13.9 | % |  | (4) | % |  | $ | 14,655 |  |  | 14.5 | % |  | 5 | % |  | $ | 14,000 |  |  | 16.1 | % |
| Research and development |  |  |  |  |  |  |  |  |  |  | 2,779 |  |  | 2.7 | % |  | 8 | % |  | 2,577 |  |  | 2.5 | % |  | 5 | % |  | 2,455 |  |  | 2.8 | % |
| Total operating expenses |  |  |  |  |  |  |  |  |  |  | $ | 16,915 |  |  | 16.6 | % |  | (2) | % |  | $ | 17,232 |  |  | 17.0 | % |  | 5 | % |  | $ | 16,455 |  |  | 18.9 | % |
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  |  |  | February 3, 2023 |  |  |  | January 28, 2022 |  |  |  | January 29, 2021 |
|  |  |  |  |  |  |  |  |  |  |  | Dollars |  | % of Net Revenue |  | %Change |  | Dollars |  | % of Net Revenue |  | %Change |  | Dollars |  | % of Non-GAAP Net Revenue |
|  |  |  |  |  |  |  |  |  |  |  | (in millions, except percentages) |
| Non-GAAP operating expenses |  |  |  |  |  |  |  |  |  |  | $ | 14,790 |  |  | 14.5 | % |  | (1) | % |  | $ | 14,899 |  |  | 14.7 | % |  | 4 | % |  | $ | 14,284 |  |  | 16.5 | % |

[0001571996-23-000007:mdna:143]
During Fiscal 2023, total operating expenses decreased 2% driven by a decrease in selling, general, and administrative expenses.

[0001571996-23-000007:mdna:144]
•Selling, General, and Administrative — Selling, general, and administrative (“SG&A”) expenses decreased 4% during Fiscal 2023, primarily due to decreases in amortization of intangible assets and outside services expenses which were partially offset by an increase in employee compensation and benefits.  The decline in outside services expense was primarily attributable to expenses incurred in Fiscal 2022, principally related to the VMware Spin-off, that did not reoccur in Fiscal 2023.  Employee compensation and benefits increased primarily as a result of costs incurred in connection with our strategic workforce reduction.

[0001571996-23-000007:mdna:145]
•Research and Development — Research and development (“R&D”) expenses are primarily composed of personnel-related expenses incurred in connection with product development.  R&D expenses increased 8% during Fiscal 2023 driven by an increase in employee compensation and benefits expense.

[0001571996-23-000007:mdna:146]
As a percentage of net revenue, R&D expenses for Fiscal 2023 and Fiscal 2022 were 2.7% and 2.5%, respectively.  We intend to continue supporting R&D initiatives to innovate and introduce new and enhanced solutions into the market.

[0001571996-23-000007:mdna:147]
During Fiscal 2023, non-GAAP operating expenses decreased 1% principally due to continued disciplined cost management.

[0001571996-23-000007:mdna:148]
We continue to make selective investments designed to enable growth, marketing, and R&D, while balancing our efforts to drive cost efficiencies in the business.  We also expect to continue making investments in support of our own digital transformation to modernize our IT operations.

[0001571996-23-000007:mdna:149]
Operating Income

[0001571996-23-000007:mdna:150]
During Fiscal 2023, our operating income increased 24% to $5.8 billion, primarily driven by growth in ISG operating income and the favorable impact of a decrease in amortization of intangible assets.  Growth in ISG operating income for Fiscal 2023 was driven by both our server and networking and storage offerings.  The increase in operating income was partially offset by a decline in CSG operating income coupled with the unfavorable impact of an increase in other corporate expenses.  CSG operating income declined during the period principally driven by our consumer offerings.  During Fiscal 2023, our non-GAAP operating income increased 11% to $8.6 billion driven by the same ISG and CSG dynamics discussed above.

[0001571996-23-000007:mdna:151]
For Fiscal 2023, operating income as a percentage of net revenue increased 100 basis points to 5.6% principally driven by improvement in gross margin as percentage of net revenue coupled with a decrease in operating expenses as a percentage of net revenue.  Gross margin as a percentage of net revenue increased primarily as a result of a shift in mix towards ISG.  The decline in operating expense as a percentage of net revenue was driven by disciplined cost management and the favorable impact of a decrease in both the amortization of intangible assets, partially offset by the unfavorable impact of an increase in other corporate expenses.  Non-GAAP operating income as a percentage of net revenue increased 70 basis points to 8.4% during Fiscal 2023, driven by the same gross margin and disciplined cost management dynamics discussed above.

[0001571996-23-000007:mdna:152]
Interest and Other, Net

[0001571996-23-000007:mdna:153]
The following table presents information regarding interest and other, net for the periods indicated:

[0001571996-23-000007:mdna:154]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  | February 3, 2023 |  | January 28, 2022 |  | January 29, 2021 |
|  |  |  |  |  | (in millions) |
| Interest and other, net: |  |  |  |  |  |  |  |  |  |
| Investment income, primarily interest |  |  |  |  | $ | 100 |  |  | $ | 42 |  |  | $ | 47 |  |
| Gain (loss) on investments, net |  |  |  |  | (206) |  |  | 569 |  |  | 425 |  |
| Interest expense |  |  |  |  | (1,222) |  |  | (1,542) |  |  | (2,052) |  |
| Foreign exchange |  |  |  |  | (265) |  |  | (221) |  |  | (160) |  |
| Gain on disposition of businesses and assets |  |  |  |  | — |  |  | 3,968 |  |  | 458 |  |
| Debt extinguishment fees |  |  |  |  | — |  |  | (1,572) |  |  | (158) |  |
| Legal settlement, net |  |  |  |  | (894) |  |  | — |  |  | — |  |
| Other |  |  |  |  | (59) |  |  | 20 |  |  | 101 |  |
| Total interest and other, net |  |  |  |  | $ | (2,546) |  |  | $ | 1,264 |  |  | $ | (1,339) |  |

[0001571996-23-000007:mdna:155]
During Fiscal 2023, the change in interest and other, net was unfavorable by $3.8 billion.  The unfavorable change was attributable to the pre-tax gain of $4.0 billion on the sale of Boomi recognized during Fiscal 2022, $0.9 billion of net expense recognized in Fiscal 2023 in connection with an agreement to settle the Class V transaction litigation, and the impact of fair value adjustments on our non-marketable strategic investments portfolio.  These factors were partially offset by a decrease in debt extinguishment fees, as we incurred $1.6 billion in Fiscal 2022 primarily associated with the early retirement of certain senior notes, and a reduction in interest expense.

[0001571996-23-000007:mdna:156]
Income and Other Taxes

[0001571996-23-000007:mdna:157]
The following table presents information regarding our income and other taxes for the periods indicated:

[0001571996-23-000007:mdna:158]
|  |  |  |  | Fiscal Year Ended |
|  |  |  |  |  |  |  |  | February 3, 2023 |  | January 28, 2022 |  | January 29, 2021 |
|  |  | (in millions, except percentages) |
| Income before income taxes |  |  |  |  |  |  |  | $ | 3,225 |  |  | $ | 5,923 |  |  | $ | 2,346 |  |
| Income tax expense |  |  |  |  |  |  |  | $ | 803 |  |  | $ | 981 |  |  | $ | 101 |  |
| Effective income tax rate |  |  |  |  |  |  |  | 24.9 | % |  | 16.6 | % |  | 4.3 | % |

[0001571996-23-000007:mdna:159]
For Fiscal 2023 and Fiscal 2022, our effective income tax rate was 24.9% and 16.6%, respectively, with the change being primarily driven by discrete items in those years.  Our effective tax rate for the Fiscal 2023 includes the impact of a $0.9 billion expense recognized in connection with an agreement to settle the Class V transaction litigation.  In comparison, our effective tax rate for Fiscal 2022 includes tax expense of $1.0 billion on a pre-tax gain of $4.0 billion related to the divestiture of Boomi during the period, as well as tax benefits of $367 million on $1.6 billion of debt extinguishment fees and $244 million related to the restructuring of certain legal entities.

[0001571996-23-000007:mdna:160]
Other changes to our effective income tax rates for Fiscal 2023 as compared to Fiscal 2022 were attributable to the tax impact of foreign operations, which included the impacts of a higher jurisdictional mix of income in lower tax jurisdictions and higher tax benefits from foreign-derived intangible income offset by the impact of the capitalization of research and development costs under the Tax Cuts and Jobs Act.  Under the Tax Cuts and Jobs Act, which was enacted on December 22, 2017, research and development costs incurred for tax years beginning after December 31, 2021 must be capitalized and amortized ratably over five or 15 years for tax purposes, depending on where the research activities were conducted.

[0001571996-23-000007:mdna:161]
Our effective income tax rate can fluctuate depending on the geographic distribution of our worldwide earnings, as our foreign earnings are generally taxed at lower rates than in the United States.  The differences between our effective income tax rates and the U.S. federal statutory rate of 21% principally result from the geographical distribution of income, differences between the book and tax treatment of certain items, and the tax items discussed above.  In certain jurisdictions, our tax rate is significantly less than the applicable statutory rate as a result of tax holidays.  The majority of our foreign income that is subject to these tax holidays is attributable to Singapore and China.  A significant portion of these income tax benefits relates to a tax holiday that will be effective until January 31, 2029.  Our other tax holidays will expire in whole or in part during Fiscal 2030 through Fiscal 2031.  Many of these tax holidays and reduced tax rates may be extended when certain conditions are met or may be terminated early if certain conditions are not met or as a result of changes in tax legislation.  As of February 3, 2023, we were not aware of any matters of noncompliance or enacted tax legislative changes affecting these tax holidays.

[0001571996-23-000007:mdna:162]
For further discussion regarding tax matters, including the status of income tax audits, see Note 13 of the Notes to the Consolidated Financial Statements included in this report.

[0001571996-23-000007:mdna:163]
See “Introduction – Business Trends and Challenges – Inflation Reduction Act” for a discussion of recent tax legislation.

[0001571996-23-000007:mdna:164]
Net Income from Continuing Operations

[0001571996-23-000007:mdna:165]
Net income from continuing operations was $2.4 billion and $4.9 billion for Fiscal 2023 and Fiscal 2022, respectively.  The decrease was principally attributable to an unfavorable change in interest and other, net, partially offset by an increase in operating income.

[0001571996-23-000007:mdna:166]
Non-GAAP net income was $5.7 billion and $4.9 billion for Fiscal 2023 and Fiscal 2022, respectively.  The increase was primarily attributable to an increase in non-GAAP operating income and a decrease in interest expense, partially offset by an increase in tax expense.

[0001571996-23-000007:mdna:167]
Business Unit Results

[0001571996-23-000007:mdna:168]
Our reportable segments are based on the ISG and CSG business units.  A description of our business units is provided under “Introduction.”  See Note 19 of the Notes to the Consolidated Financial Statements included in this report for a reconciliation of net revenue and operating income by reportable segment to consolidated net revenue and consolidated operating income (loss), respectively.

[0001571996-23-000007:mdna:169]
Infrastructure Solutions Group

[0001571996-23-000007:mdna:170]
The following table presents net revenue and operating income attributable to ISG for the periods indicated:

[0001571996-23-000007:mdna:171]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  |  |  | February 3, 2023 |  | % Change |  | January 28, 2022 |  | % Change |  | January 29, 2021 |
|  |  |  |  |  |  |  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Servers and networking |  |  |  |  |  |  | $ | 20,398 |  | 14 | % |  | $ | 17,901 |  | 8 | % |  | $ | 16,592 |
| Storage |  |  |  |  |  |  | 17,958 |  | 9 | % |  | 16,465 |  | — | % |  | 16,410 |
| Total ISG net revenue |  |  |  |  |  |  | $ | 38,356 |  | 12 | % |  | $ | 34,366 |  | 4 | % |  | $ | 33,002 |
| Operating income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| ISG operating income |  |  |  |  |  |  | $ | 5,045 |  | 35 | % |  | $ | 3,736 |  | — | % |  | $ | 3,753 |
| % of segment net revenue |  |  |  |  |  |  | 13.2 | % |  |  |  | 10.9 | % |  |  |  | 11.4 | % |

[0001571996-23-000007:mdna:172]
Net Revenue — During Fiscal 2023, ISG net revenue increased 12%, driven by strength across both server and networking and storage offerings.

[0001571996-23-000007:mdna:173]
Revenue from sales of servers and networking increased 14% during Fiscal 2023, primarily driven by an increase in average selling price of our server offerings, the effect of which was partially offset by a decrease in units sold.  The average selling price for our server offerings increased as a result of richer configurations and continued pricing discipline in response to the macroeconomic environment.

[0001571996-23-000007:mdna:174]
During Fiscal 2023, storage revenue increased 9% due to continued strength across the majority of our storage offerings.

[0001571996-23-000007:mdna:175]
ISG customers are interested in new and innovative models that address how they consume our solutions.  We offer options that include as-a-Service, subscription, utility, leases, and immediate pay models which are designed to match customers’ consumption and financing preferences.  Our multiyear agreements typically result in recurring revenue streams over the term of the arrangement.  We expect that our flexible consumption models and as-a-Service offerings through Dell APEX will further strengthen our customer relationships and provide a foundation for growth in recurring revenue.

[0001571996-23-000007:mdna:176]
From a geographical perspective, net revenue attributable to ISG increased in the Americas and EMEA and, to a lesser extent, in APJ during Fiscal 2023.

[0001571996-23-000007:mdna:177]
Operating Income — During Fiscal 2023, ISG operating income as a percentage of net revenue increased 230 basis points to 13.2% principally due to a decrease in operating expenses as a percentage of net revenue that resulted from strong revenue growth coupled with disciplined cost management.

[0001571996-23-000007:mdna:178]
56

[0001571996-23-000007:mdna:179]
Client Solutions Group

[0001571996-23-000007:mdna:180]
The following table presents net revenue and operating income attributable to CSG for the periods indicated:

[0001571996-23-000007:mdna:181]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  |  |  | February 3, 2023 |  | % Change |  | January 28, 2022 |  | % Change |  | January 29, 2021 |
|  |  |  |  |  |  |  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial |  |  |  |  |  |  | $ | 45,556 |  | — | % |  | $ | 45,576 |  | 29 | % |  | $ | 35,423 |
| Consumer |  |  |  |  |  |  | 12,657 |  | (20) | % |  | 15,888 |  | 23 | % |  | 12,964 |
| Total CSG net revenue |  |  |  |  |  |  | $ | 58,213 |  | (5) | % |  | $ | 61,464 |  | 27 | % |  | $ | 48,387 |
| Operating income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| CSG operating income |  |  |  |  |  |  | $ | 3,824 |  | (12) | % |  | $ | 4,365 |  | 31 | % |  | $ | 3,333 |
| % of segment net revenue |  |  |  |  |  |  | 6.6 | % |  |  |  | 7.1 | % |  |  |  | 6.9 | % |

[0001571996-23-000007:mdna:182]
Net Revenue — During Fiscal 2023, CSG net revenue decreased 5%, driven by a decline in units sold as deteriorating macroeconomic conditions led to an overall decline in demand industry-wide.  The impact of the decline in units sold was partially offset by an increase in the average selling prices of our offerings.  We continue to take necessary actions to manage pricing while also balancing competitive pressures, profitability, and growth.

[0001571996-23-000007:mdna:183]
Consumer net revenue decreased 20% during Fiscal 2023, primarily due to a decrease in units sold, which was only partially offset by the effect of an increase in the average selling price of our consumer offerings.

[0001571996-23-000007:mdna:184]
During Fiscal 2023, commercial net revenue remained flat as the effect of an increase in the average selling price of our commercial offerings was entirely offset by a decrease in units sold.

[0001571996-23-000007:mdna:185]
Our average selling prices for our CSG offerings increased during Fiscal 2023 primarily as a result of a shift in mix towards our commercial offerings coupled with richer configurations and the impact of attached offerings.

[0001571996-23-000007:mdna:186]
From a geographical perspective, net revenue attributable to CSG remained flat in the Americas and decreased in both EMEA and APJ during Fiscal 2023.

[0001571996-23-000007:mdna:187]
Operating Income — During Fiscal 2023, CSG operating income as a percentage of net revenue decreased 50 basis points to 6.6%, primarily due to an increase in operating expenses as a percentage of net revenue, which increased as a result of a decline in CSG net revenue that outpaced the impacts of cost management measures.

[0001571996-23-000007:mdna:188]
OTHER BALANCE SHEET ITEMS

[0001571996-23-000007:mdna:189]
Accounts Receivable

[0001571996-23-000007:mdna:190]
We sell products and services directly to customers and through a variety of sales channels, including retail distribution.  Our accounts receivable, net, was $12.5 billion and $12.9 billion as of February 3, 2023 and January 28, 2022, respectively.  We maintain an allowance for expected credit losses to cover receivables that may be deemed uncollectible.  The allowance for expected credit losses is an estimate based on an analysis of historical loss experience, current receivables aging, and management’s assessment of current conditions and its reasonable and supportable expectation of future conditions, as well as specific identifiable customer accounts that are deemed at risk.  As of February 3, 2023 and January 28, 2022, the allowance for expected credit losses was $78 million and $90 million, respectively.  Based on our assessment, we believe that we are adequately reserved for expected credit losses.  We are monitoring the impact of current economic conditions and the aging of our accounts receivable on our expected losses and have not experienced deterioration in delinquency or loss rates.  We will continue to take actions, where necessary, to reduce our exposure to credit losses.

[0001571996-23-000007:mdna:191]
Dell Financial Services and Financing Receivables

[0001571996-23-000007:mdna:192]
We offer or arrange various financing options and services for our customers globally, including through captive financing operations.  DFS originates, collects, and services customer receivables primarily related to the purchase of our product, software, and service solutions.  We further strengthen customer relationships through flexible consumption models, including utility, subscription, and as-a-Service models, which enable us to offer our customers the option to pay over time to provide them with financial flexibility to meet their changing technological requirements.  We have historically seen an increasing interest in our various financing options during times of macroeconomic uncertainty.  New financing originations were $9.7 billion, $8.5 billion, and $8.9 billion for Fiscal 2023, Fiscal 2022, and Fiscal 2021, respectively.

[0001571996-23-000007:mdna:193]
Our leases are generally classified as sales-type leases or operating leases.  On commencement of sales-type leases, the Company recognizes profit up-front, and amounts due from the customer under the lease contract are recognized as financing receivables.  Interest income is recognized as net product revenue over the term of the lease.  Upon origination of operating leases, we record equipment under operating leases, classified as property, plant, and equipment.  Over the contract term of an operating lease, we recognize rental revenue and depreciation expense, classified as cost of net revenue.

[0001571996-23-000007:mdna:194]
As of February 3, 2023 and January 28, 2022, our financing receivables, net were $10.9 billion and $10.6 billion, respectively.  We maintain an allowance to cover expected financing receivable credit losses and evaluate credit loss expectations based on our total portfolio.  For Fiscal 2023, Fiscal 2022, and Fiscal 2021, the principal charge-off rate for our financing receivables portfolio was 0.5%, 0.6% and 0.7%, respectively.  The credit quality of our financing receivables has improved in recent years as the mix of high-quality commercial accounts in our portfolio has continued to increase.  We continue to monitor broader economic indicators and their potential impact on future credit loss performance.  We have an extensive process to manage our exposure to customer credit risk, including active management of credit lines and our collection activities.  We also sell selected fixed-term financing receivables without recourse to unrelated third parties on a periodic basis, primarily to manage certain concentrations of customer credit exposure.  Based on our assessment of the customer financing receivables, we believe that we are adequately reserved.

[0001571996-23-000007:mdna:195]
We retain a residual interest in equipment leased under our lease programs.  As of February 3, 2023 and January 28, 2022, the residual interest recorded as part of financing receivables was $142 million and $217 million, respectively.  The decline in residual interest was principally attributable to a corresponding increase in originations of operating leases.  The amount of the residual interest is established at the inception of the lease based upon estimates of the value of the equipment at the end of the lease term using historical studies, industry data, and future value-at-risk demand valuation methods.  On a quarterly basis, we assess the carrying amount of our recorded residual values for expected losses.  Generally, expected losses as a result of residual value risk on equipment under lease are not considered to be significant primarily because of the existence of a secondary market with respect to the equipment.  Further, the lease agreement defines applicable return conditions and remedies for non-compliance to ensure that the leased equipment will be in good operating condition upon return.  No expected losses were recorded related to residual assets during Fiscal 2023 and Fiscal 2022.

[0001571996-23-000007:mdna:196]
As of February 3, 2023 and January 28, 2022, equipment under operating leases, net was $2.2 billion and $1.7 billion, respectively.  We assess the carrying amount of the equipment under operating leases for impairment whenever events or circumstances may indicate that an impairment has occurred.  No material impairment losses were recorded related to such equipment during Fiscal 2023, Fiscal 2022, and Fiscal 2021.

[0001571996-23-000007:mdna:197]
DFS offerings are initially funded through cash on hand at the time of origination, most of which is subsequently replaced with asset-backed financing.  For DFS offerings which qualify as sales-type leases, the initial funding of financing receivables is reflected as an impact to cash flows from operations, and is largely subsequently offset by cash proceeds from financing.

[0001571996-23-000007:mdna:198]
For DFS operating leases, the initial funding is classified as a capital expenditure and reflected as an impact to cash flows used in investing activities.

[0001571996-23-000007:mdna:199]
See Note 6 of the Notes to the Consolidated Financial Statements included in this report for additional information about our financing receivables and the associated allowances, and equipment under operating leases.

[0001571996-23-000007:mdna:200]
59

[0001571996-23-000007:mdna:201]
LIQUIDITY, CASH REQUIREMENTS, AND MARKET CONDITIONS

[0001571996-23-000007:mdna:202]
Liquidity and Capital Resources

[0001571996-23-000007:mdna:203]
We rely on operating cash flows, which are impacted by trends in the demand environment, as our primary source of liquidity for our ongoing business operations.  We monitor the efficiency of our balance sheet to ensure that we have adequate liquidity to support our business and strategic initiatives.  In addition to internally generated cash, we have access to other capital sources to finance our strategic initiatives and fund growth in our financing operations.  Our strategy is to deploy capital from any potential source, whether internally generated cash or debt, depending on the adequacy and availability of that source of capital and whether it can be accessed in a cost-effective manner.

[0001571996-23-000007:mdna:204]
We believe that our current cash and cash equivalents, together with cash that will be provided by future operations and borrowings expected to be available under our revolving credit facility and commercial paper program, will be sufficient over at least the next twelve months and for the foreseeable future thereafter to meet our material cash requirements, including funding of our operations, debt-related payments, capital expenditures, and other corporate needs.  Our cash and cash equivalent balances will be impacted in the near-term as a result of certain non-recurring cash outflows, including payment of the Class V transaction litigation settlement.

[0001571996-23-000007:mdna:205]
As part of our overall capital allocation strategy, we intend to drive growth while maintaining our investment grade rating and focusing on returning capital to our stockholders through both share repurchase programs and dividend payments.

[0001571996-23-000007:mdna:206]
The following table presents our cash and cash equivalents as well as our available borrowings as of the dates indicated:

[0001571996-23-000007:mdna:207]
|  | February 3, 2023 |  | January 28, 2022 |
|  | (in millions) |
| Cash and cash equivalents, and available borrowings: |  |  |  |
| Cash and cash equivalents | $ | 8,607 |  |  | $ | 9,477 |  |
| Remaining available borrowings under 2021 Revolving Credit Facility | 5,999 |  |  | 4,969 |  |
| Total cash, cash equivalents, and available borrowings | $ | 14,606 |  |  | $ | 14,446 |  |

[0001571996-23-000007:mdna:208]
During Fiscal 2023, cash and cash equivalents decreased by $0.9 billion, primarily as a result of the return of capital to our stockholders through share repurchases and dividend payments, and capital expenditures, partially offset by cash flows from operations and net cash proceeds from the issuance of senior notes.

[0001571996-23-000007:mdna:209]
As of February 3, 2023, our 2021 Revolving Credit Facility had a maximum capacity of $6.0 billion.  Available borrowings under this facility are reduced by draws on the facility and outstanding letters of credit.  As of February 3, 2023, there were no borrowings outstanding under the facility and remaining available borrowings totaled approximately $6.0 billion.  The 2021 Revolving Credit Facility also acts as a backstop to provide liquidity support for our commercial paper program.

[0001571996-23-000007:mdna:210]
During Fiscal 2023, we established a commercial paper program under which we may issue unsecured notes in a maximum aggregate face amount of $5.0 billion outstanding at any time, with maturities up to 397 days from the date of issue.  As of February 3, 2023, we had no outstanding borrowings under the program.

[0001571996-23-000007:mdna:211]
We may regularly use our available borrowings from the 2021 Revolving Credit Facility and issuances under the commercial paper program on a short-term basis for general corporate purposes.  See Note 8 of the Notes to the Consolidated Financial Statements included in this report for additional information about our debt.

[0001571996-23-000007:mdna:212]
During Fiscal 2023, we entered into a factoring arrangement with a third-party financial institution to sell certain high-quality trade accounts receivable on a non-recourse basis.  We may elect to factor trade accounts receivable from time to time as part of our overall liquidity and working capital management strategy.

[0001571996-23-000007:mdna:213]
Debt

[0001571996-23-000007:mdna:214]
The following table presents our outstanding debt as of the dates indicated:

[0001571996-23-000007:mdna:215]
|  | February 3, 2023 |  | Change |  | January 28, 2022 |
|  | (in millions) |
| Core debt |  |  |  |  |  |
| Senior Notes | $ | 18,300 |  |  | $ | 2,000 |  |  | $ | 16,300 |  |
| Legacy Notes and Debentures | 952 |  |  | — |  |  | 952 |  |
| DFS allocated debt | (1,196) |  |  | (63) |  |  | (1,133) |  |
| Total core debt | 18,056 |  |  | 1,937 |  |  | 16,119 |  |
| DFS related debt |  |  |  |  |  |
| DFS debt | 10,290 |  |  | 644 |  |  | 9,646 |  |
| DFS allocated debt | 1,196 |  |  | 63 |  |  | 1,133 |  |
| Total DFS related debt | 11,486 |  |  | 707 |  |  | 10,779 |  |
| Other | 325 |  |  | (12) |  |  | 337 |  |
| Total debt, principal amount | 29,867 |  |  | 2,632 |  |  | 27,235 |  |
| Carrying value adjustments | (279) |  |  | 2 |  |  | (281) |  |
| Total debt, carrying value | $ | 29,588 |  |  | $ | 2,634 |  |  | $ | 26,954 |  |

[0001571996-23-000007:mdna:216]
The outstanding principal amount of our debt increased $2.6 billion from January 28, 2022 to $29.9 billion as of February 3, 2023, driven primarily by the issuance of $2.0 billion principal amount of senior notes and, to a lesser extent, net DFS activity.

[0001571996-23-000007:mdna:217]
We define core debt as the total principal amount of our debt, less DFS related debt and other debt.  Our core debt was $18.1 billion and $16.1 billion as of February 3, 2023 and January 28, 2022, respectively.  The increase in our core debt during Fiscal 2023 was primarily driven by the issuance of $2.0 billion principal amount of senior notes.  We intend to utilize the proceeds of such senior notes to repay the 5.45% senior notes due June 2023 and to utilize the remaining proceeds for general corporate purposes, including repayment of other debt.  See Note 8 of the Notes to the Consolidated Financial Statements included in this report for additional information about our debt.

[0001571996-23-000007:mdna:218]
DFS related debt primarily represents debt from our securitization and structured financing programs.  Our risk of loss under these programs is limited to transferred lease and loan payments and associated equipment, as the credit holders have no recourse to Dell Technologies.

[0001571996-23-000007:mdna:219]
To fund expansion of the DFS business, we balance the use of the securitization and structured financing programs with other sources of liquidity.  We approximate the amount of our debt used to fund the DFS business by applying a 7:1 debt-to-equity ratio to the sum of our financing receivables balance and equipment under our DFS operating leases, net.  The debt-to-equity ratio is based on the underlying credit quality of the assets.  See Note 6 of the Notes to the Consolidated Financial Statements included in this report for additional information about our DFS debt.

[0001571996-23-000007:mdna:220]
We believe we will continue to be able to make our debt principal and interest payments, including short-term maturities, from existing and expected sources of cash, primarily from operating cash flows.  Cash used for debt principal and interest payments may include short-term borrowings under our commercial paper program, our revolving credit facility, or other borrowings.  Under our variable-rate debt, we could experience variations in our future interest expense from potential fluctuations in applicable reference rates, or from possible fluctuations in the level of DFS debt required to meet future demand for customer financing.

[0001571996-23-000007:mdna:221]
We have made steady progress in paying down debt and we will continue to pursue deleveraging over the long-term as an important component of our overall capital allocation strategy.  At our sole discretion, we may purchase, redeem, prepay, refinance, or otherwise retire any amount of our outstanding indebtedness under the terms of such indebtedness at any time and from time to time, in open market or negotiated transactions with the holders of such indebtedness or otherwise, as we consider appropriate in light of market conditions and other relevant factors.

[0001571996-23-000007:mdna:222]
Cash Flows

[0001571996-23-000007:mdna:223]
The following table presents a summary of our Consolidated Statements of Cash Flows for the periods indicated:

[0001571996-23-000007:mdna:224]
|  | Fiscal Year Ended |
|  | February 3, 2023 |  | January 28, 2022 |  | January 29, 2021 |
|  | (in millions) |
| Net change in cash from: |  |  |  |  |  |
| Operating activities | $ | 3,565 |  |  | $ | 10,307 |  |  | $ | 11,407 |  |
| Investing activities | (3,024) |  |  | 1,306 |  |  | (460) |  |
| Financing activities | (1,625) |  |  | (16,609) |  |  | (5,950) |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash | (104) |  |  | (106) |  |  | 36 |  |
| Change in cash, cash equivalents, and restricted cash | $ | (1,188) |  |  | $ | (5,102) |  |  | $ | 5,033 |  |

[0001571996-23-000007:mdna:225]
Cash flows for both Fiscal 2022 and Fiscal 2021 are inclusive of cash flows attributable to VMware, Inc.  Effective November 1, 2021, as a result of the VMware Spin-off, cash flows ceased to include cash flows attributable to VMware, Inc.  See “Introduction” and Note 1 and Note 3 of the Notes to the Consolidated Financial Statements included in this report for additional information regarding the VMware Spin-off.

[0001571996-23-000007:mdna:226]
Operating Activities — Cash provided by operating activities was $3.6 billion during Fiscal 2023 compared to $10.3 billion during Fiscal 2022.  Cash provided by operating activities for Fiscal 2022 included $3.2 billion attributable to VMware, Inc.

[0001571996-23-000007:mdna:227]
The decline in cash provided by operating activities was primarily attributable to unfavorable working capital dynamics as compared to Fiscal 2022.  Working capital was primarily impacted by a shift in mix of the business, the timing of purchases and payments to vendors during a declining demand environment, and linearity of sales during the fourth quarter of Fiscal 2023.

[0001571996-23-000007:mdna:228]
Investing Activities — Investing activities primarily consist of cash used to fund capital expenditures for property, plant, and equipment inclusive of equipment under DFS operating leases and equipment used to support our as-a-Service offerings (collectively “revenue generating assets”).  Additional activities include capitalized software development costs, acquisitions and divestitures, strategic investments, and the maturities, sales, and purchases of investments.  During Fiscal 2023, cash used in investing activities was $3.0 billion and was primarily applied to capital expenditures.

[0001571996-23-000007:mdna:229]
Cash provided by investing activities was $1.3 billion during Fiscal 2022, primarily driven by net cash proceeds related to the divestiture of Boomi, which was partially offset by cash used for capital expenditures.

[0001571996-23-000007:mdna:230]
Financing Activities — Financing activities primarily consist of the proceeds and repayments of debt and return of capital to our stockholders.  Cash used in financing activities was $1.6 billion during Fiscal 2023 and primarily consisted of repurchases of common stock, inclusive of payments to settle employee tax withholding on stock-based compensation, and the payment of quarterly dividends.  The effects of these activities were partially offset by net cash proceeds from debt issuances, primarily related to the issuance of senior notes.  See Note 8 of the Notes to the Consolidated Financial Statements included in this report for additional information regarding our debt.

[0001571996-23-000007:mdna:231]
Cash used in financing activities was $16.6 billion during Fiscal 2022 and primarily consisted of debt repayments and associated debt extinguishment fees, as well as cash transferred to VMware in connection with the VMware Spin-off.  The effect of these activities was partially offset by cash proceeds from the issuance of senior notes by Dell Technologies and VMware.

[0001571996-23-000007:mdna:232]
DFS Cash Flow Impacts — DFS offerings are initially funded through cash on hand at the time of origination, most of which is subsequently replaced with asset-backed financing.  For DFS offerings that qualify as sales-type leases, the initial funding of financing receivables is reflected as an impact to cash flows from operations and is largely subsequently offset by cash proceeds from financing.  For DFS operating leases, the initial funding is classified as a capital expenditure and reflected as cash flows used in investing activities.  DFS new financing originations were $9.7 billion, $8.5 billion, and $8.9 billion during Fiscal 2023, Fiscal 2022, and Fiscal 2021, respectively.  As of February 3, 2023, DFS had $10.9 billion of total net financing receivables and $2.2 billion of equipment under DFS operating leases, net.

[0001571996-23-000007:mdna:233]
Capital Commitments

[0001571996-23-000007:mdna:234]
Capital Expenditures — We spent $3.0 billion and $2.8 billion during Fiscal 2023 and Fiscal 2022, respectively, on property, plant, and equipment and capitalized software development costs.  Of total expenditures incurred during Fiscal 2023 and Fiscal 2022, funding of revenue generating assets totaled $1.5 billion and $1.3 billion, respectively.  Product demand, product mix, the use of contract manufacturers, and ongoing investments in operating and information technology infrastructure influence the level and prioritization of our capital expenditures.  Aggregate capital expenditures for Fiscal 2024 are currently expected to total between $2.9 billion and $3.1 billion, of which approximately $1.8 billion are expected to relate to revenue generating assets.

[0001571996-23-000007:mdna:235]
Repurchases of Common Stock

[0001571996-23-000007:mdna:236]
Repurchases of Common Stock — Effective as of September 23, 2021, our Board of Directors approved a stock repurchase program with no fixed expiration date under which we are authorized to repurchase up to $5 billion of shares of our Class C Common Stock.  During Fiscal 2023, we repurchased approximately 62 million shares of Class C Common Stock under this program for a total purchase price of approximately $2.8 billion.

[0001571996-23-000007:mdna:237]
Dividend Payments

[0001571996-23-000007:mdna:238]
Dividend Payments — On February 24, 2022, we announced that our Board of Directors adopted a dividend policy providing for our payment of quarterly cash dividends on our common stock at a rate of $0.33 per share per fiscal quarter beginning in the first quarter of Fiscal 2023.  During Fiscal 2023, the Company paid the following dividends:

[0001571996-23-000007:mdna:239]
| Declaration Date |  | Record Date |  | Payment Date |  | Dividend per Share |  | Amount (in millions) |
| February 24, 2022 |  | April 20, 2022 |  | April 29, 2022 |  | $ | 0.33 |  |  | $ | 248 |  |
| June 7, 2022 |  | July 20, 2022 |  | July 29, 2022 |  | $ | 0.33 |  |  | $ | 242 |  |
| September 6, 2022 |  | October 19, 2022 |  | October 28, 2022 |  | $ | 0.33 |  |  | $ | 238 |  |
| December 6, 2022 |  | January 25, 2023 |  | February 3, 2023 |  | $ | 0.33 |  |  | $ | 236 |  |

[0001571996-23-000007:mdna:240]
On March 2, 2023, we announced that the Board of Directors approved a 12% increase in the quarterly dividend rate to a rate of $0.37 per share per fiscal quarter beginning in the first quarter of Fiscal 2024.

[0001571996-23-000007:mdna:241]
63

[0001571996-23-000007:mdna:242]
Contractual Cash Obligations

[0001571996-23-000007:mdna:243]
The following table presents a summary of our contractual cash obligations as of February 3, 2023:

[0001571996-23-000007:mdna:244]
|  |  |  | Payments Due by Fiscal Year |
|  | Total |  | 2024 |  | 2025-2026 |  | 2027-2028 |  | Thereafter |
|  | (in millions) |
| Contractual cash obligations: |  |  |  |  |  |  |  |  |  |
| Principal payments on debt: |  |  |  |  |  |  |  |  |  |
| Core debt (a) | $ | 19,252 |  |  | $ | 1,000 |  |  | $ | 2,000 |  |  | $ | 6,750 |  |  | $ | 9,502 |  |
| DFS debt (b) | 10,290 |  |  | 5,400 |  |  | 3,747 |  |  | 1,143 |  |  | — |  |
| Other | 325 |  |  | 177 |  |  | 140 |  |  | 8 |  |  | — |  |
| Total principal payments on debt | 29,867 |  |  | 6,577 |  |  | 5,887 |  |  | 7,901 |  |  | 9,502 |  |
| Interest | 9,173 |  |  | 1,250 |  |  | 2,014 |  |  | 1,345 |  |  | 4,564 |  |
| Purchase obligations | 4,383 |  |  | 3,460 |  |  | 617 |  |  | 298 |  |  | 8 |  |
| Operating leases | 966 |  |  | 260 |  |  | 362 |  |  | 206 |  |  | 138 |  |
| Tax obligations | 144 |  |  | 36 |  |  | 108 |  |  | — |  |  | — |  |
| Contractual cash obligations | $ | 44,533 |  |  | $ | 11,583 |  |  | $ | 8,988 |  |  | $ | 9,750 |  |  | $ | 14,212 |  |

[0001571996-23-000007:mdna:245]
____________________

[0001571996-23-000007:mdna:246]
(a)    Contractual cash obligations associated with core debt exclude DFS allocated debt.

[0001571996-23-000007:mdna:247]
(b)  DFS debt primarily represents debt from our securitization and structured financing programs.

[0001571996-23-000007:mdna:248]
Principal Payments on Debt — Our expected principal cash payments on borrowings are exclusive of discounts and premiums.  We have outstanding long-term notes with varying maturities.  For additional information about our debt, see Note 6 and Note 8 of the Notes to the Consolidated Financial Statements included in this report.

[0001571996-23-000007:mdna:249]
Interest —  Of the total cash obligations for interest presented in the table above, the amounts related to our DFS debt were expected to be $185 million in Fiscal 2024, $89 million in Fiscal 2025-2026, and $1 million in Fiscal 2027-2028.  See Note 6 and Note 8 of the Notes to the Consolidated Financial Statements included in this report for further discussion of our debt and related interest expense.

[0001571996-23-000007:mdna:250]
Purchase Obligations — Purchase obligations are defined as contractual obligations to purchase goods or services that are enforceable and legally binding on us.  These obligations specify all significant terms, including fixed or minimum quantities to be purchased; fixed, minimum, or variable price provisions; and the approximate timing of the transaction.  Purchase obligations do not include contracts that may be canceled without penalty.

[0001571996-23-000007:mdna:251]
We utilize several suppliers to manufacture sub-assemblies for our products.  Our efficient supply chain management allows us to enter into flexible and mutually beneficial purchase arrangements with our suppliers in order to minimize inventory risk.  Consistent with industry practice, we acquire raw materials or other goods and services, including product components, by issuing to suppliers authorizations to purchase based on our projected demand and manufacturing needs.  These purchase orders are typically fulfilled within 30 days and are entered into during the ordinary course of business in order to establish best pricing and continuity of supply for our production.  Purchase orders are not included in purchase obligations, as they typically represent our authorization to purchase rather than binding purchase obligations.

[0001571996-23-000007:mdna:252]
Operating Leases — We lease property and equipment, manufacturing facilities, and office space under non-cancelable leases.  Certain of these leases obligate us to pay taxes, maintenance, and repair costs.  See Note 7 of the Notes to the Consolidated Financial Statements included in this report for additional information about our leasing transactions in which we are the lessee.

[0001571996-23-000007:mdna:253]
Tax Obligations — Tax obligations represent a one-time mandatory deemed repatriation tax on undistributed earnings of foreign subsidiaries.  Excluded from the table above are $1.3 billion in additional liabilities associated with uncertain tax positions as of February 3, 2023.  We are unable to reliably estimate the expected payment dates for any liabilities for uncertain tax positions.  See Note 13 of the Notes to the Consolidated Financial Statements included in this report for more information on these tax matters.

[0001571996-23-000007:mdna:254]
Market Conditions

[0001571996-23-000007:mdna:255]
We regularly monitor economic conditions and associated impacts on the financial markets and our business.  We consistently evaluate the financial health of our supplier base, carefully manage customer credit, diversify counterparty risk, and monitor the concentration risk of our cash and cash equivalents balances globally.  We routinely monitor our financial exposure to borrowers and counterparties.

[0001571996-23-000007:mdna:256]
We monitor credit risk associated with our financial counterparties using various market credit risk indicators such as credit ratings issued by nationally recognized credit rating agencies and changes in market credit default swap levels.  We perform periodic evaluations of our positions with these counterparties and may limit exposure to any one counterparty in accordance with our policies.  We monitor and manage these activities depending on current and expected market developments.

[0001571996-23-000007:mdna:257]
We use derivative instruments to hedge certain foreign currency exposures.  We use forward contracts and purchased options designated as cash flow hedges to protect against the foreign currency exchange rate risks inherent in our forecasted transactions denominated in currencies other than the U.S. dollar.  In addition, we primarily use forward contracts and may use purchased options to hedge monetary assets and liabilities denominated in a foreign currency.  See Note 9 of the Notes to the Consolidated Financial Statements included in this report for additional information about our use of derivative instruments.

[0001571996-23-000007:mdna:258]
We are exposed to interest rate risk related to our variable-rate debt portfolio.  In the normal course of business we follow established policies and procedures to manage this risk, including monitoring of our asset and liability mix and the use of derivative instruments.  As a result, we do not anticipate any material losses from interest rate risk.

[0001571996-23-000007:mdna:259]
65

[0001571996-23-000007:mdna:260]
Summarized Guarantor Financial Information

[0001571996-23-000007:mdna:261]
As discussed in Note 8 of the Notes to the Consolidated Financial Statements included in this report, Dell International L.L.C. and EMC Corporation (the “Issuers”), both of which are wholly-owned subsidiaries of Dell Technologies Inc., completed private offerings of multiple series of senior secured notes issued on June 1, 2016, March 20, 2019, and April 9, 2020 (the “Senior Notes”).  In June 2021, the Issuers completed an exchange offer and issued $18.4 billion aggregate principal amount of registered senior notes under the Securities Act of 1933 in exchange for the same principal amount and substantially identical terms of the Senior Notes.  The aggregate principal amount of unregistered Senior Notes remaining outstanding following the settlement of the exchange offer was approximately $0.1 billion.  During Fiscal 2022, the tangible and intangible assets of the Issuers and guarantors that secured obligations under the Senior Notes were released as collateral.  As a result, the Senior Notes became fully unsecured.  In addition, all guarantees of the Senior Notes by subsidiaries of Dell Inc. were released.

[0001571996-23-000007:mdna:262]
On January 24, 2023, the Issuers completed a public offering of unsecured senior notes (together with the Senior Notes, the “Registered Senior Notes”) in the aggregate principal amount of $2.0 billion.  The unsecured senior notes were sold pursuant to a shelf registration statement.

[0001571996-23-000007:mdna:263]
Guarantees — The Registered Senior Notes are guaranteed on a joint and several unsecured basis by Dell Technologies Inc. and its wholly-owned subsidiaries, Denali Intermediate, Inc. and Dell Inc. (collectively, the “Guarantors”).

[0001571996-23-000007:mdna:264]
Basis of Preparation of the Summarized Financial Information — The tables below are summarized financial information provided in conformity with Rule 13-01 of the SEC’s Regulation S-X.  The summarized financial information of the Issuers and Guarantors (collectively, the “Obligor Group”) is presented on a combined basis, excluding intercompany balances and transactions between entities in the Obligor Group.  The Obligor Group’s amounts due from, amounts due to, and transactions with Non-Obligor Subsidiaries and VMware, Inc. and its consolidated subsidiaries (the “Related Party”) have been presented separately.  The Obligor Group’s investment balances in Non-Obligor Subsidiaries have been excluded.

[0001571996-23-000007:mdna:265]
The following table presents summarized results of operations information for the Obligor Group for the period indicated:

[0001571996-23-000007:mdna:266]
|  | Fiscal Year Ended |
|  | February 3, 2023 |
|  | (in millions) |
| Net revenue (a) | $ | 10,327 |  |
| Gross margin (b) | 4,517 |  |
| Operating income (c) | 1,203 |  |
| Interest and other, net (d) | (3,284) |  |
| Loss before income taxes | $ | (2,081) |  |
| Net loss attributable to Obligor Group | $ | (1,720) |  |

[0001571996-23-000007:mdna:267]
____________________

[0001571996-23-000007:mdna:268]
(a)  Includes net revenue from services provided and product sales to Non-Obligor Subsidiaries of $841 million and $171 million, respectively.

[0001571996-23-000007:mdna:269]
(b)  Includes cost of net revenue from resale of solutions purchased from Non-Obligor Subsidiaries and the Related Party of $1,034 million and $491 million, respectively.  Includes costs of net revenue from shared services provided by Non-Obligor Subsidiaries of $634 million.

[0001571996-23-000007:mdna:270]
(c)   Includes operating expenses from shared services provided by Non-Obligor Subsidiaries of $22 million.

[0001571996-23-000007:mdna:271]
(d)   Includes interest expense on inter-company loan payables of $1,379 million.

[0001571996-23-000007:mdna:272]
The following table presents summarized balance sheet information for the Obligor Group as of the dates indicated:

[0001571996-23-000007:mdna:273]
|  | February 3, 2023 |  | January 28, 2022 |
|  | (in millions) |
| ASSETS |
| Current assets | $ | 2,972 |  |  | $ | 3,106 |  |
| Intercompany receivables | 595 |  |  | 988 |  |
| Due from related party, net | 312 |  |  | 59 |  |
| Short-term intercompany loan receivables | 227 |  |  | — |  |
| Total current assets | 4,106 |  |  | 4,153 |  |
| Due from related party, net | 440 |  |  | 710 |  |
| Goodwill and intangible assets | 14,818 |  |  | 15,399 |  |
| Other non-current assets | 3,009 |  |  | 2,810 |  |
| Total assets | $ | 22,373 |  |  | $ | 23,072 |  |
| LIABILITIES |
| Current liabilities | $ | 6,611 |  |  | $ | 4,625 |  |
| Due to related party | 110 |  |  | 192 |  |
| Total current liabilities | 6,721 |  |  | 4,817 |  |
| Long-term debt | 17,996 |  |  | 17,001 |  |
| Intercompany loan payables | 38,896 |  |  | 37,509 |  |
| Other non-current liabilities | 3,891 |  |  | 3,473 |  |
| Total liabilities | $ | 67,504 |  |  | $ | 62,800 |  |

[0001571996-23-000007:mdna:274]
67

[0001571996-23-000007:mdna:275]
Critical Accounting Estimates

[0001571996-23-000007:mdna:276]
We prepare our financial statements in conformity with GAAP, which requires certain estimates, assumptions, and judgments to be made that may affect our Consolidated Statements of Financial Position and Consolidated Statements of Income.  Accounting policies that have a significant impact on our Consolidated Financial Statements are described in Note 2 of the Notes to the Consolidated Financial Statements included in this report.  The accounting estimates and assumptions discussed in this section are those that we consider to be the most critical.  We consider an accounting policy to be critical if the nature of the estimate or assumption is subject to a material level of judgment and if changes in those estimates or assumptions are reasonably likely to materially impact our Consolidated Financial Statements.  We have discussed the development, selection, and disclosure of our critical accounting policies with the Audit Committee of our Board of Directors.

[0001571996-23-000007:mdna:277]
Revenue Recognition — We sell a wide portfolio of products and services offerings to our customers.  Our agreements have varying terms and conditions depending on the goods and services being sold, the rights and obligations conveyed, and the legal jurisdiction of the arrangement.  While most of our agreements have standard terms and conditions, more complex agreements may contain nonstandard terms and conditions.  There are significant judgements in interpreting agreements to determine the appropriate accounting for nonstandard terms and conditions.

[0001571996-23-000007:mdna:278]
Our contracts with customers often include multiple performance obligations for various distinct goods and services such as hardware, software licenses, support and maintenance agreements, and other service offerings and solutions.  We use significant judgment to assess whether these promises are distinct performance obligations that should be accounted for separately.  In certain hardware solutions, the hardware is highly interdependent on, and interrelated with, the embedded software.  In these offerings, the hardware and software licenses are accounted for as a single performance obligation.

[0001571996-23-000007:mdna:279]
The transaction price reflects the amount of consideration to which we expect to be entitled in exchange for transferring goods or services to the customer.  If the consideration promised in a contract includes a variable amount, we estimate the amount to which we expect to be entitled using either the expected value or most likely amount method.  Estimates are updated each reporting period as the variability is resolved or if additional information becomes available.  Generally, volume discounts, rebates, and sales returns reduce the transaction price.  When we determine the transaction price, we only include amounts that are not subject to significant future reversal.

[0001571996-23-000007:mdna:280]
When a contract includes multiple performance obligations, the transaction price is allocated to each performance obligation in proportion to the standalone selling price (“SSP”) of each performance obligation.

[0001571996-23-000007:mdna:281]
Judgment is required when determining the SSP of our performance obligations.  If the observable price is available, we utilize that price for the SSP.  If the observable price is not available, the SSP must be estimated.  We estimate SSP by considering multiple factors, including, but not limited to, pricing practices, internal costs, and profit objectives as well as overall market conditions, which include geographic or regional specific factors, competitive positioning, and competitor actions.  Our SSP estimates rely, in part, on company pricing trends.  Market conditions could impact the selling price in the current period which may not be reflective of trends, and could lead to revenue timing, classification, and segment differences when compared to similar contracts in other periods.  SSP for our performance obligations is periodically reassessed.

[0001571996-23-000007:mdna:282]
For transactions that involve a third party, the Company evaluates whether it is acting as the principal or the agent in the transaction.  This determination requires significant judgement and impacts the amount and timing of revenue recognized.  If the Company determines that it controls a good or service before it is transferred to the customer, the Company is acting as the principal and recognizes revenue at the gross amount of consideration it is entitled to from the customer. Indicators that the Company controls a good or service before transferring to a customer include, but are not limited to, the Company being the primary obligor to the customer, establishing its own pricing, and having inventory and credit risks.

[0001571996-23-000007:mdna:283]
Goodwill and Indefinite-Lived Intangible Assets Impairment Assessments — Goodwill and indefinite-lived intangible assets are tested for impairment annually during the third fiscal quarter and whenever events or circumstances may indicate that an impairment has occurred.

[0001571996-23-000007:mdna:284]
To determine whether goodwill is impaired, we first assess certain qualitative factors.  Qualitative factors that may be assessed include, but are not limited to, macroeconomic conditions, industry and market considerations, cost factors, overall financial performance, or other relevant company-specific events.  Based on this assessment, if it is determined more likely than not that the fair value of a goodwill reporting unit is less than its carrying amount, we perform a quantitative analysis of the goodwill impairment test.  Alternatively, we may bypass the qualitative assessment and perform a quantitative impairment test.

[0001571996-23-000007:mdna:285]
Significant judgment is exercised in the identification of goodwill reporting units, assignment of assets and liabilities to goodwill reporting units, assignment of goodwill to reporting units, and determination of the fair value of each goodwill reporting unit.  The fair value of each of our goodwill reporting units is generally estimated using a combination of public company multiples and discounted cash flow methodologies, and then compared to the carrying value of each goodwill reporting unit.  The discounted cash flow and public company multiples methodologies require significant judgment, including estimation of future revenues, gross margins, and operating expenses, which are dependent on internal forecasts, current and anticipated economic conditions and trends, selection of market multiples through assessment of the reporting unit’s performance relative to peer competitors, the estimation of the long-term revenue growth rate and discount rate of our business, and the determination of our weighted average cost of capital.  Changes in these estimates and assumptions could materially affect the fair value of the goodwill reporting unit, potentially resulting in a non-cash impairment charge.

[0001571996-23-000007:mdna:286]
The fair value of the indefinite-lived intangible assets is generally estimated using discounted cash flow methodologies.  The discounted cash flow methodologies require significant judgment, including estimation of future revenue, the estimation of the long-term revenue growth rate of our business, and the determination of the weighted average cost of capital and royalty rates.  Changes in these estimates and assumptions could materially affect the fair value of the indefinite-lived intangible assets, potentially resulting in a non-cash impairment charge.

[0001571996-23-000007:mdna:287]
For more information about our goodwill and intangible assets, see Note 10 of the Notes to the Consolidated Financial Statements included in this report.

[0001571996-23-000007:mdna:288]
Income Taxes — We are subject to income tax in the United States and numerous foreign jurisdictions.  Significant judgments are required in determining the consolidated provision for income taxes.  We calculate a provision for income taxes using the asset and liability method, under which deferred tax assets and liabilities are recognized by identifying the temporary differences arising from the different treatment of items for tax and accounting purposes.  We account for the tax impact of including Global Intangible Low-Taxed Income (GILTI) in U.S. taxable income as a period cost.  We provide related valuation allowances for deferred tax assets, where appropriate.  Significant judgment is required in determining any valuation allowance against deferred tax assets.  In assessing the need for a valuation allowance, we consider all available evidence for each jurisdiction, including past operating results, estimates of future taxable income, and the feasibility of ongoing tax planning strategies.  In the event we determine that all or part of the net deferred tax assets are not realizable in the future, we will make an adjustment to the valuation allowance that would be charged to earnings in the period such determination is made.

[0001571996-23-000007:mdna:289]
Significant judgment is also required in evaluating our uncertain tax positions.  Although we believe our tax return positions are sustainable, we recognize tax benefits from uncertain tax positions in the financial statements only when it is more likely than not that the positions will be sustained upon examination, including resolution of any related appeals or litigation processes, based on the technical merits and a consideration of the relevant taxing authority’s administrative practices and precedents.  To the extent that the final tax outcome of these matters is different from the amounts recorded, such differences will impact the provision for income taxes in the period in which such determination is made.  The provision for income taxes includes the impact of reserve provisions and changes to reserves that are considered appropriate, as well as the related net interest and penalties.  We believe we have provided adequate reserves for all uncertain tax positions.

[0001571996-23-000007:mdna:290]
Legal and Other Contingencies — The outcomes of legal proceedings and claims brought against us are subject to significant uncertainty.  An estimated loss from a loss contingency such as a legal proceeding or claim is accrued by a charge to income if it is probable that an asset has been impaired or a liability has been incurred and the amount of the loss can be reasonably estimated.  In determining whether a loss should be accrued, we evaluate, among other factors, the degree of probability of an unfavorable outcome and the ability to make a reasonable estimate of the amount of loss.  Significant judgement is required in determining whether a loss should be accrued, and changes in these factors could materially impact our Consolidated Financial Statements.

[0001571996-23-000007:mdna:291]
Inventories — We state our inventory at the lower of cost or net realizable value.  We record a write-down for inventories of components and products, including third-party products held for resale, which have become obsolete or are in excess of anticipated demand or net realizable value.  We perform a detailed review of inventory each fiscal quarter that considers multiple factors, including demand forecasts, product life cycle status, product development plans, current sales levels, product pricing, and component cost trends.  The industries in which we compete are subject to demand changes.  If future demand or market conditions for our products are less favorable than forecasted or if unforeseen technological changes negatively impact the utility of component inventory, we may be required to record additional write-downs, which would adversely affect our gross margin.

[0001571996-23-000007:mdna:292]
Recently Issued Accounting Pronouncements

[0001571996-23-000007:mdna:293]
See Note 2 of the Notes to the Consolidated Financial Statements included in this report for a summary of recently issued accounting pronouncements that are applicable to our Consolidated Financial Statements.

[0001571996-23-000007:mdna:294]
70
