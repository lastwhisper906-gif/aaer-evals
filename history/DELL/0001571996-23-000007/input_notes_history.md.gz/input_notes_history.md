# DELL note change history — 0001571996-22-000031 → 0001571996-22-000044


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-12-05):
[0001571996-22-000044:note_history:1]
The Company has contractual obligations to purchase goods or services, which specify significant terms (including fixed or minimum quantities to be purchased), fixed, minimum, or variable price provisions; and the approximate timing of the transaction.  As of October 28, 2022, such purchase obligations were $2.7 billion, $0.6 billion, and $0.8 billion for the remaining three months of Fiscal 2023, Fiscal 2024, and Fiscal 2025 and thereafter, respectively.
  (was, 2022-09-01, similarity 0.978):
[0001571996-22-000031:note_history:1]
The Company has contractual obligations to purchase goods or services, which specify significant terms (including fixed or minimum quantities to be purchased), fixed, minimum, or variable price provisions; and the approximate timing of the transaction.  As of July 29, 2022, such purchase obligations were $4.0 billion, $0.5 billion, and $0.8 billion for the remaining six months of Fiscal 2023, Fiscal 2024, and Fiscal 2025 and thereafter, respectively.

- changed (2022-12-05):
[0001571996-22-000044:note_history:2]
Class Actions Related to the Class V Transaction — On December 28, 2018, the Company completed a transaction (the “Class V transaction”) in which it paid $14.0 billion in cash and issued 149,387,617 shares of its Class C Common Stock to holders of its Class V Common Stock in exchange for all outstanding shares of Class V Common Stock.  As a result of the Class V transaction, the tracking stock feature of the Company’s capital structure associated with the Class V Common Stock was terminated.  In November 2018, four purported stockholders brought putative class action complaints arising out of the Class V transaction.  The actions were captioned Hallandale Beach Police and Fire Retirement Plan v. Michael Dell et al. (Civil Action No. 2018-0816-JTL), Howard Karp v. Michael Dell et al. (Civil Action No. 2019-0032-JTL), Miramar Police Officers’ Retirement Plan v. Michael Dell et al. (Civil Action No. 2019-0049-JTL), and Steamfitters Local 449 Pension Plan v. Michael Dell et al. (Civil Action No. 2019-0115-JTL).  The four actions were consolidated in the Delaware Chancery Court into In Re Dell Class V Litigation (Consol. C.A. No. 2018-0816-JTL).  The suit currently names as defendants Michael S. Dell and certain of the other directors serving on the Board of Directors at the time of the Class V transaction, certain stockholders of the Company, consisting of Michael S. Dell and Silver Lake Group LLC and certain of its affiliated funds, and Goldman Sachs & Co. LLC (“Goldman Sachs”), which served as financial advisor to the Company in connection with the Class V transaction.  In an amended complaint filed in August 2019, the plaintiffs generally allege that the director and stockholder defendants breached their fiduciary duties under Delaware law to the former holders of Class V Common Stock in connection with the Class V transaction by offering a transaction value that was allegedly billions of dollars below the fair value.  The plaintiffs contend that the offer understated the value of shares surrendered by the former stockholders, which the plaintiffs allege should have reflected higher alternative valuations, including a valuation related to the value of the shares of VMware, Inc. common stock, and that the difference in values was wrongfully appropriated by the stockholder defendants.  On August 20, 2021, the plaintiffs added Goldman Sachs as a defendant and allege that it aided and abetted the alleged primary violations.  In the complaint, the plaintiffs seek, among other remedies, a judicial declaration that the director and stockholder defendants breached their fiduciary duties.  The plaintiffs also seek in the complaint disgorgement of all profits, benefits, and other compensation obtained by the defendants as a result of such alleged conduct and an award of unspecified damages, fees, and costs.  The defendants filed a motion to dismiss the action in September 2019.  The court denied the motion in June 2020.  Trial was scheduled to begin on December 5, 2022.  The Company is not a defendant in this action but is subject to director indemnification provisions under its certificate of incorporation and bylaws, and is a party to agreements with the defendants that contain indemnification
  (was, 2022-09-01, similarity 0.9827):
[0001571996-22-000031:note_history:2]
Class Actions Related to the Class V Transaction — On December 28, 2018, the Company completed a transaction (the “Class V transaction”) in which it paid $14.0 billion in cash and issued 149,387,617 shares of its Class C Common Stock to holders of its Class V Common Stock in exchange for all outstanding shares of Class V Common Stock.  As a result of the Class V transaction, the tracking stock feature of the Company’s capital structure associated with the Class V Common Stock was terminated.  In November 2018, four purported stockholders brought putative class action complaints arising out of the Class V transaction.  The actions were captioned Hallandale Beach Police and Fire Retirement Plan v. Michael Dell et al. (Civil Action No. 2018-0816-JTL), Howard Karp v. Michael Dell et al. (Civil Action No. 2019-0032-JTL), Miramar Police Officers’ Retirement Plan v. Michael Dell et al. (Civil Action No. 2019-0049-JTL), and Steamfitters Local 449 Pension Plan v. Michael Dell et al. (Civil Action No. 2019-0115-JTL).  The four actions were consolidated in the Delaware Chancery Court into In Re Dell Class V Litigation (Consol. C.A. No. 2018-0816-JTL).  The suit currently names as defendants Michael S. Dell and certain of the other directors serving on the Board of Directors at the time of the Class V transaction, certain stockholders of the Company, consisting of Michael S. Dell and Silver Lake Group LLC and certain of its affiliated funds, and Goldman Sachs & Co. LLC (“Goldman Sachs”), which served as financial advisor to the Company in connection with the Class V transaction.  In an amended complaint filed in August 2019, the plaintiffs generally allege that the director and stockholder defendants breached their fiduciary duties under Delaware law to the former holders of Class V Common Stock in connection with the Class V transaction by offering a transaction value that was allegedly billions of dollars below the fair value.  The plaintiffs contend that the offer understated the value of shares surrendered by the former stockholders, which the plaintiffs allege should have reflected higher alternative valuations, including a valuation related to the value of the shares of VMware, Inc. common stock, and that the difference in values was wrongfully appropriated by the stockholder defendants.  On August 20, 2021, the plaintiffs added Goldman Sachs as a defendant and allege that it aided and abetted the alleged primary violations.  In the complaint, the plaintiffs seek, among other remedies, a judicial declaration that the director and stockholder defendants breached their fiduciary duties.  The plaintiffs also seek in the complaint disgorgement of all profits, benefits, and other compensation obtained by the defendants as a result of such alleged conduct and an award of unspecified damages, fees, and costs.  The defendants filed a motion to dismiss the action in September 2019.  The court denied the motion in June 2020 and the case is currently in the discovery phase.  Trial is scheduled to begin on December 5, 2022.  The Company is not a defendant in this action but is subject to director indemnification provisions under its certificate of incorporation and bylaws, and is a party to agreements with

- changed (2022-12-05):
[0001571996-22-000044:note_history:3]
obligations of the Company, conditioned on the satisfaction of the requirements set forth in such agreements, relating to service as a director, ownership of the Company’s securities, and provision of services, as applicable.  As described in Note 19 of the Notes to the Condensed Consolidated Financial Statements, the plaintiffs and the defendants agreed to settle this action, subject to court approval, subsequent to October 28, 2022.
  (was, 2022-09-01, similarity 0.6438):
[0001571996-22-000031:note_history:3]
the defendants that contain indemnification obligations of the Company, conditioned on the satisfaction of the requirements set forth in such agreements, relating to service as a director, ownership of the Company’s securities, and provision of services, as applicable.

- changed (2022-12-05):
[0001571996-22-000044:note_history:4]
Class Actions Related to VMware, Inc.’s Acquisition of Pivotal Software, Inc. — Two purported stockholders brought putative class action complaints arising out of VMware, Inc.’s acquisition of Pivotal Software, Inc. (“Pivotal”) on December 30, 2019.  The two actions were consolidated in the Delaware Chancery Court into In re: Pivotal Software, Inc. Stockholders Litigation (Civil Action No. 2020-0440-KSJM).  The complaint names as defendants the Company, VMware, Inc., Michael S. Dell, and certain officers of Pivotal.  The plaintiffs generally allege that the defendants breached their fiduciary duties to the former holders of Pivotal Class A Common Stock in connection with VMware, Inc.’s acquisition of Pivotal by allegedly causing Pivotal to enter into a transaction that favored the interests of Pivotal’s controlling stockholders at the expense of such former stockholders.  The parties reached a settlement on June 2, 2022, subject to court approval.  On October 4, 2022, the court entered a final order and judgment approving the settlement.
  (was, 2022-09-01, similarity 0.8753):
[0001571996-22-000031:note_history:4]
Class Actions Related to VMware, Inc.’s Acquisition of Pivotal Software, Inc. — Two purported stockholders brought putative class action complaints arising out of VMware, Inc.’s acquisition of Pivotal Software, Inc. (“Pivotal”) on December 30, 2019.  The two actions were consolidated in the Delaware Chancery Court into In re: Pivotal Software, Inc. Stockholders Litigation (Civil Action No. 2020-0440-KSJM).  The complaint names as defendants the Company, VMware, Inc., Michael S. Dell, and certain officers of Pivotal.  The plaintiffs generally allege that the defendants breached their fiduciary duties to the former holders of Pivotal Class A Common Stock in connection with VMware, Inc.’s acquisition of Pivotal by allegedly causing Pivotal to enter into a transaction that favored the interests of Pivotal’s controlling stockholders at the expense of such former stockholders.  The parties have reached an agreement to settle the litigation and are seeking the court’s approval of the settlement.

- added (2022-12-05):
[0001571996-22-000044:note_history:5]
In accordance with the relevant accounting guidance, the Company provides disclosures of matters where it is at least reasonably possible that the Company could experience a material loss exceeding the amounts already accrued for these or other proceedings or matters.  In addition, the Company also discloses matters based on its consideration of other matters and qualitative factors, including the experience of other companies in the industry, and investor, customer, and employee relations considerations.  As of October 28, 2022, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for these or other proceedings or matters has been incurred.  However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company’s business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters.  Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company’s business, financial condition, results of operations, or cash flows will depend on a number of factors, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.

- removed (2022-12-05):
[0001571996-22-000031:note_history:6]
In accordance with the relevant accounting guidance, the Company provides disclosures of matters where it is at least reasonably possible that the Company could experience a material loss exceeding the amounts already accrued for these or other proceedings or matters.  In addition, the Company also discloses matters based on its consideration of other matters and qualitative factors, including the experience of other companies in the industry, and investor, customer, and employee relations considerations.  As of July 29, 2022, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for these or other proceedings or matters has been incurred.  However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company’s business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters.  Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company’s business, financial condition, results of operations, or cash flows will depend on a number of factors, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.


## dell:CreditLossFinancialInstrumentLeasesDebtVariableInterestEntitiesAndCustomerReceivablesSalesTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-12-05):
[0001571996-22-000044:note_history:7]
FINANCIAL SERVICES
The Company offers or arranges various financing options and services and alternative payment structures for its customers globally primarily through Dell Financial Services and its affiliates (“DFS”).  The Company also arranges financing for some of its customers in various countries where DFS does not currently operate as a captive enterprise.  The key activities of DFS include originating, collecting, and servicing customer financing arrangements primarily related to the purchase or use of Dell Technologies products and services.  In some cases, DFS also offers financing for the purchase of third-party technology products that complement the Dell Technologies portfolio of products and services.  New financing originations were $2.3 billion and $2.0 billion for the three months ended October 28, 2022 and October 29, 2021, respectively, and $6.7 billion and $5.8 billion for the nine months ended October 28, 2022 and October 29, 2021, respectively.
  (was, 2022-09-01, similarity 0.8804):
[0001571996-22-000031:note_history:7]
FINANCIAL SERVICES
The Company offers or arranges various financing options and services and alternative payment structures for its customers globally primarily through Dell Financial Services and its affiliates (“DFS”).  The Company also arranges financing for some of its customers in various countries where DFS does not currently operate as a captive enterprise.  The key activities of DFS include originating, collecting, and servicing customer financing arrangements primarily related to the purchase or use of Dell Technologies products and services.  In some cases, DFS also offers financing for the purchase of third-party technology products that complement the Dell Technologies portfolio of products and services.  New financing originations were $2.3 billion and $1.9 billion for the three months ended July 29, 2022 and July 30, 2021, respectively, and $4.4 billion and $3.8 billion for the six months ended July 29, 2022 and July 30, 2021, respectively.

- added (2022-12-05):
[0001571996-22-000044:note_history:8]
The Company further strengthens customer relationships through flexible consumption models, including utility, subscription, and as-a-Service models, which enable the Company to offer its customers the option to pay over time to provide them with financial flexibility to meet their changing technological requirements.

- changed (2022-12-05):
[0001571996-22-000044:note_history:9]
|  | October 28, 2022 |  | January 28, 2022 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Financing receivables, net: |  |  |  |  |  |  |  |  |  |  |  |
| Customer receivables, gross (a) | $ | 685 |  |  | $ | 9,938 |  |  | $ | 10,623 |  |  | $ | 750 |  |  | $ | 9,833 |  |  | $ | 10,583 |  |
| Allowances for losses | (87) |  |  | (99) |  |  | (186) |  |  | (102) |  |  | (87) |  |  | (189) |  |
| Customer receivables, net | 598 |  |  | 9,839 |  |  | 10,437 |  |  | 648 |  |  | 9,746 |  |  | 10,394 |  |
| Residual interest | — |  |  | 137 |  |  | 137 |  |  | — |  |  | 217 |  |  | 217 |  |
| Financing receivables, net | $ | 598 |  |  | $ | 9,976 |  |  | $ | 10,574 |  |  | $ | 648 |  |  | $ | 9,963 |  |  | $ | 10,611 |  |
| Short-term | $ | 598 |  |  | $ | 4,317 |  |  | $ | 4,915 |  |  | $ | 648 |  |  | $ | 4,441 |  |  | $ | 5,089 |  |
| Long-term | $ | — |  |  | $ | 5,659 |  |  | $ | 5,659 |  |  | $ | — |  |  | $ | 5,522 |  |  | $ | 5,522 |  |
  (was, 2022-09-01, similarity 0.993):
[0001571996-22-000031:note_history:9]
|  | July 29, 2022 |  | January 28, 2022 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Financing receivables, net: |  |  |  |  |  |  |  |  |  |  |  |
| Customer receivables, gross (a) | $ | 705 |  |  | $ | 9,638 |  |  | $ | 10,343 |  |  | $ | 750 |  |  | $ | 9,833 |  |  | $ | 10,583 |  |
| Allowances for losses | (91) |  |  | (92) |  |  | (183) |  |  | (102) |  |  | (87) |  |  | (189) |  |
| Customer receivables, net | 614 |  |  | 9,546 |  |  | 10,160 |  |  | 648 |  |  | 9,746 |  |  | 10,394 |  |
| Residual interest | — |  |  | 150 |  |  | 150 |  |  | — |  |  | 217 |  |  | 217 |  |
| Financing receivables, net | $ | 614 |  |  | $ | 9,696 |  |  | $ | 10,310 |  |  | $ | 648 |  |  | $ | 9,963 |  |  | $ | 10,611 |  |
| Short-term | $ | 614 |  |  | $ | 4,246 |  |  | $ | 4,860 |  |  | $ | 648 |  |  | $ | 4,441 |  |  | $ | 5,089 |  |
| Long-term | $ | — |  |  | $ | 5,450 |  |  | $ | 5,450 |  |  | $ | — |  |  | $ | 5,522 |  |  | $ | 5,522 |  |

- added (2022-12-05):
[0001571996-22-000044:note_history:10]
|  | Three Months Ended |
|  | October 28, 2022 |  | October 29, 2021 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |  |  |  |  |  |  |  |  |  |  |  |
| Balances at beginning of period | $ | 91 |  |  | $ | 92 |  |  | $ | 183 |  |  | $ | 126 |  |  | $ | 161 |  |  | $ | 287 |  |
| Charge-offs, net of recoveries | (12) |  |  | (1) |  |  | (13) |  |  | (9) |  |  | (20) |  |  | (29) |  |
| Provision charged to income statement | 8 |  |  | 8 |  |  | 16 |  |  | (5) |  |  | (28) |  |  | (33) |  |
| Balances at end of period | $ | 87 |  |  | $ | 99 |  |  | $ | 186 |  |  | $ | 112 |  |  | $ | 113 |  |  | $ | 225 |  |

- added (2022-12-05):
[0001571996-22-000044:note_history:11]
|  | Nine Months Ended |
|  | October 28, 2022 |  | October 29, 2021 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |  |  |  |  |  |  |  |  |  |  |  |
| Balances at beginning of period | $ | 102 |  |  | $ | 87 |  |  | $ | 189 |  |  | $ | 148 |  |  | $ | 173 |  |  | $ | 321 |  |
| Charge-offs, net of recoveries | (37) |  |  | (5) |  |  | (42) |  |  | (32) |  |  | (25) |  |  | (57) |  |
| Provision charged to income statement | 22 |  |  | 17 |  |  | 39 |  |  | (4) |  |  | (35) |  |  | (39) |  |
| Balances at end of period | $ | 87 |  |  | $ | 99 |  |  | $ | 186 |  |  | $ | 112 |  |  | $ | 113 |  |  | $ | 225 |  |

- changed (2022-12-05):
[0001571996-22-000044:note_history:12]
|  | October 28, 2022 |  | January 28, 2022 |
|  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |
|  | (in millions) |
| Revolving — DPA | $ | 444 |  |  | $ | 42 |  |  | $ | 15 |  |  | $ | 501 |  |  | $ | 520 |  |  | $ | 40 |  |  | $ | 11 |  |  | $ | 571 |  |
| Revolving — DBC | 165 |  |  | 16 |  |  | 3 |  |  | 184 |  |  | 158 |  |  | 18 |  |  | 3 |  |  | 179 |  |
| Fixed-term — Consumer and Commercial | 9,524 |  |  | 391 |  |  | 23 |  |  | 9,938 |  |  | 9,444 |  |  | 345 |  |  | 44 |  |  | 9,833 |  |
| Total customer receivables, gross | $ | 10,133 |  |  | $ | 449 |  |  | $ | 41 |  |  | $ | 10,623 |  |  | $ | 10,122 |  |  | $ | 403 |  |  | $ | 58 |  |  | $ | 10,583 |  |
  (was, 2022-09-01, similarity 0.991):
[0001571996-22-000031:note_history:12]
|  | July 29, 2022 |  | January 28, 2022 |
|  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |
|  | (in millions) |
| Revolving — DPA | $ | 472 |  |  | $ | 37 |  |  | $ | 13 |  |  | $ | 522 |  |  | $ | 520 |  |  | $ | 40 |  |  | $ | 11 |  |  | $ | 571 |  |
| Revolving — DBC | 164 |  |  | 16 |  |  | 3 |  |  | 183 |  |  | 158 |  |  | 18 |  |  | 3 |  |  | 179 |  |
| Fixed-term — Consumer and Commercial | 9,343 |  |  | 271 |  |  | 24 |  |  | 9,638 |  |  | 9,444 |  |  | 345 |  |  | 44 |  |  | 9,833 |  |
| Total customer receivables, gross | $ | 9,979 |  |  | $ | 324 |  |  | $ | 40 |  |  | $ | 10,343 |  |  | $ | 10,122 |  |  | $ | 403 |  |  | $ | 58 |  |  | $ | 10,583 |  |

- changed (2022-12-05):
[0001571996-22-000044:note_history:13]
Aging is likely to fluctuate as a result of the variability in volume of large transactions entered into over the period, and the administrative processes that accompany those transactions.  Aging is also impacted by the timing of the Company’s fiscal period end date relative to calendar month-end customer payment due dates.  As a result of these factors, fluctuations in aging from period to period do not necessarily indicate a material change in the collectibility of the portfolio.
  (was, 2022-09-01, similarity 0.9755):
[0001571996-22-000031:note_history:13]
Aging is likely to fluctuate as a result of the variability in volume of large transactions entered into over the period, and the administrative processes that accompany those transactions.  Aging is also impacted by the timing of the Dell Technologies fiscal period end date relative to calendar month-end customer payment due dates.  As a result of these factors, fluctuations in aging from period to period do not necessarily indicate a material change in the collectibility of the portfolio.

- changed (2022-12-05):
[0001571996-22-000044:note_history:14]
|  | October 28, 2022 |
|  | Fixed-term — Consumer and Commercial |  |  |  |  |  |  |
|  | Fiscal Year of Origination |  |  |  |  |  |  |
|  | 2023 |  | 2022 |  | 2021 |  | 2020 |  | 2019 |  | Years Prior |  | Revolving — DPA |  | Revolving — DBC |  | Total |
|  | (in millions) |
| Higher | $ | 2,504 |  |  | $ | 2,055 |  |  | $ | 1,086 |  |  | $ | 447 |  |  | $ | 70 |  |  | $ | 2 |  |  | $ | 124 |  |  | $ | 49 |  |  | $ | 6,337 |  |
| Mid | 946 |  |  | 691 |  |  | 450 |  |  | 154 |  |  | 30 |  |  | 2 |  |  | 144 |  |  | 54 |  |  | 2,471 |  |
| Lower | 791 |  |  | 416 |  |  | 199 |  |  | 81 |  |  | 12 |  |  | 2 |  |  | 233 |  |  | 81 |  |  | 1,815 |  |
| Total | $ | 4,241 |  |  | $ | 3,162 |  |  | $ | 1,735 |  |  | $ | 682 |  |  | $ | 112 |  |  | $ | 6 |  |  | $ | 501 |  |  | $ | 184 |  |  | $ | 10,623 |  |
  (was, 2022-09-01, similarity 0.9912):
[0001571996-22-000031:note_history:14]
|  | July 29, 2022 |
|  | Fixed-term — Consumer and Commercial |  |  |  |  |  |  |
|  | Fiscal Year of Origination |  |  |  |  |  |  |
|  | 2023 |  | 2022 |  | 2021 |  | 2020 |  | 2019 |  | Years Prior |  | Revolving — DPA |  | Revolving — DBC |  | Total |
|  | (in millions) |
| Higher | $ | 1,785 |  |  | $ | 2,347 |  |  | $ | 1,291 |  |  | $ | 578 |  |  | $ | 109 |  |  | $ | 7 |  |  | $ | 126 |  |  | $ | 46 |  |  | $ | 6,289 |  |
| Mid | 690 |  |  | 773 |  |  | 540 |  |  | 194 |  |  | 47 |  |  | 4 |  |  | 149 |  |  | 57 |  |  | 2,454 |  |
| Lower | 392 |  |  | 458 |  |  | 297 |  |  | 104 |  |  | 19 |  |  | 3 |  |  | 247 |  |  | 80 |  |  | 1,600 |  |
| Total | $ | 2,867 |  |  | $ | 3,578 |  |  | $ | 2,128 |  |  | $ | 876 |  |  | $ | 175 |  |  | $ | 14 |  |  | $ | 522 |  |  | $ | 183 |  |  | $ | 10,343 |  |

- changed (2022-12-05):
[0001571996-22-000044:note_history:15]
For DPA revolving receivables shown in the table above, the Company makes credit decisions based on proprietary scorecards, which include the customer’s credit history, payment history, credit usage, and other credit agency-related elements.  The higher quality category includes prime accounts generally of a higher credit quality that are comparable to U.S. customer FICO scores of 720 or above.  The mid category represents the mid-tier accounts that are comparable to U.S. customer FICO scores from 660 to 719.  The lower category is generally sub-prime and represents lower credit quality accounts that are comparable to U.S. customer FICO scores below 660.  For the DBC revolving receivables and fixed-term commercial receivables shown in the table above, an internal grading system is utilized that assigns a credit level score based on a number of considerations, including liquidity, operating performance, and industry outlook.  The grading criteria and classifications for the fixed-term products differ from those for the revolving products as loss experience varies between these product and customer groups.  The credit quality categories cannot be compared between the different classes as loss experience varies substantially between the classes.
  (was, 2022-09-01, similarity 0.9992):
[0001571996-22-000031:note_history:15]
For DPA revolving receivables shown in the table above, the Company makes credit decisions based on proprietary scorecards, which include the customer’s credit history, payment history, credit usage, and other credit agency-related elements.  The higher quality category includes prime accounts generally of a higher credit quality that are comparable to U.S. customer FICO scores of 720 or above.  The mid-category represents the mid-tier accounts that are comparable to U.S. customer FICO scores from 660 to 719.  The lower category is generally sub-prime and represents lower credit quality accounts that are comparable to U.S. customer FICO scores below 660.  For the DBC revolving receivables and fixed-term commercial receivables shown in the table above, an internal grading system is utilized that assigns a credit level score based on a number of considerations, including liquidity, operating performance, and industry outlook.  The grading criteria and classifications for the fixed-term products differ from those for the revolving products as loss experience varies between these product and customer groups.  The credit quality categories cannot be compared between the different classes as loss experience varies substantially between the classes.

- changed (2022-12-05):
[0001571996-22-000044:note_history:16]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 28, 2022 |  | October 29, 2021 |  | October 28, 2022 |  | October 29, 2021 |
|  | (in millions) |
| Net revenue — products | $ | 207 |  |  | $ | 183 |  |  | $ | 646 |  |  | $ | 607 |  |
| Cost of net revenue — products | 164 |  |  | 162 |  |  | 532 |  |  | 467 |  |
| Gross margin — products | $ | 43 |  |  | $ | 21 |  |  | $ | 114 |  |  | $ | 140 |  |
  (was, 2022-09-01, similarity 0.8444):
[0001571996-22-000031:note_history:16]
|  | Three Months Ended |  | Six Months Ended |
|  | July 29, 2022 |  | July 30, 2021 |  | July 29, 2022 |  | July 30, 2021 |
|  | (in millions) |
| Net revenue — products | $ | 219 |  |  | $ | 194 |  |  | $ | 439 |  |  | $ | 424 |  |
| Cost of net revenue — products | 164 |  |  | 142 |  |  | 368 |  |  | 305 |  |
| Gross margin — products | $ | 55 |  |  | $ | 52 |  |  | $ | 71 |  |  | $ | 119 |  |

- changed (2022-12-05):
[0001571996-22-000044:note_history:17]
|  | October 28, 2022 |
|  | (in millions) |
| Fiscal 2023 (remaining three months) | $ | 723 |  |
| Fiscal 2024 | 2,191 |  |
| Fiscal 2025 | 1,524 |  |
| Fiscal 2026 | 895 |  |
| Fiscal 2027 and beyond | 387 |  |
| Total undiscounted cash flows | 5,720 |  |
| Fixed-term loans | 4,864 |  |
| Revolving loans | 685 |  |
| Less: Unearned income | (646) |  |
| Total customer receivables, gross | $ | 10,623 |  |
  (was, 2022-09-01, similarity 0.6742):
[0001571996-22-000031:note_history:17]
|  | July 29, 2022 |
|  | (in millions) |
| Fiscal 2023 (remaining six months) | $ | 469 |  |
| Fiscal 2024 | 760 |  |
| Fiscal 2025 | 512 |  |
| Fiscal 2026 | 198 |  |
| Fiscal 2027 and beyond | 64 |  |
| Total | $ | 2,003 |  |

- changed (2022-12-05):
[0001571996-22-000044:note_history:18]
|  | October 28, 2022 |  | January 28, 2022 |
|  | (in millions) |
| Equipment under operating lease, gross | $ | 3,417 |  |  | $ | 2,643 |  |
| Less: Accumulated depreciation | (1,336) |  |  | (935) |  |
| Equipment under operating lease, net | $ | 2,081 |  |  | $ | 1,708 |  |
  (was, 2022-09-01, similarity 0.9763):
[0001571996-22-000031:note_history:18]
|  | July 29, 2022 |  | January 28, 2022 |
|  | (in millions) |
| Equipment under operating lease, gross | $ | 3,202 |  |  | $ | 2,643 |  |
| Less: Accumulated depreciation | (1,202) |  |  | (935) |  |
| Equipment under operating lease, net | $ | 2,000 |  |  | $ | 1,708 |  |

- changed (2022-12-05):
[0001571996-22-000044:note_history:19]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 28, 2022 |  | October 29, 2021 |  | October 28, 2022 |  | October 29, 2021 |
|  | (in millions) |
| Income related to lease payments | $ | 297 |  |  | $ | 187 |  |  | $ | 782 |  |  | $ | 510 |  |
| Depreciation expense | $ | 212 |  |  | $ | 140 |  |  | $ | 571 |  |  | $ | 383 |  |
  (was, 2022-09-01, similarity 0.8122):
[0001571996-22-000031:note_history:19]
|  | Three Months Ended |  | Six Months Ended |
|  | July 29, 2022 |  | July 30, 2021 |  | July 29, 2022 |  | July 30, 2021 |
|  | (in millions) |
| Income related to lease payments | $ | 253 |  |  | $ | 167 |  |  | $ | 485 |  |  | $ | 323 |  |
| Depreciation expense | $ | 194 |  |  | $ | 127 |  |  | $ | 359 |  |  | $ | 243 |  |

- added (2022-12-05):
[0001571996-22-000044:note_history:20]
|  | October 28, 2022 |
|  | (in millions) |
| Fiscal 2023 (remaining three months) | $ | 287 |  |
| Fiscal 2024 | 865 |  |
| Fiscal 2025 | 604 |  |
| Fiscal 2026 | 256 |  |
| Fiscal 2027 and beyond | 65 |  |
| Total | $ | 2,077 |  |

- changed (2022-12-05):
[0001571996-22-000044:note_history:21]
|  | October 28, 2022 |  | January 28, 2022 |
| DFS debt | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing and securitization facilities | $ | 3,226 |  |  | $ | 3,054 |  |
| Fixed-term securitization offerings | 3,302 |  |  | 3,011 |  |
| Other | 87 |  |  | 135 |  |
| Total DFS U.S. debt | 6,615 |  |  | 6,200 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 688 |  |  | 739 |  |
| Other borrowings | 1,004 |  |  | 785 |  |
| Note payable | 250 |  |  | 250 |  |
| Dell Bank senior unsecured eurobonds | 1,494 |  |  | 1,672 |  |
| Total DFS international debt | 3,436 |  |  | 3,446 |  |
| Total DFS debt | $ | 10,051 |  |  | $ | 9,646 |  |
| Total short-term DFS debt | $ | 5,626 |  |  | $ | 5,803 |  |
| Total long-term DFS debt | $ | 4,425 |  |  | $ | 3,843 |  |
  (was, 2022-09-01, similarity 0.9918):
[0001571996-22-000031:note_history:21]
|  | July 29, 2022 |  | January 28, 2022 |
| DFS debt | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing and securitization facilities | $ | 2,271 |  |  | $ | 3,054 |  |
| Fixed-term securitization offerings | 3,968 |  |  | 3,011 |  |
| Other | 117 |  |  | 135 |  |
| Total DFS U.S. debt | 6,356 |  |  | 6,200 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 694 |  |  | 739 |  |
| Other borrowings | 810 |  |  | 785 |  |
| Note payable | 250 |  |  | 250 |  |
| Dell Bank senior unsecured eurobonds | 1,530 |  |  | 1,672 |  |
| Total DFS international debt | 3,284 |  |  | 3,446 |  |
| Total DFS debt | $ | 9,640 |  |  | $ | 9,646 |  |
| Total short-term DFS debt | $ | 5,565 |  |  | $ | 5,803 |  |
| Total long-term DFS debt | $ | 4,075 |  |  | $ | 3,843 |  |

- changed (2022-12-05):
[0001571996-22-000044:note_history:22]
Asset-Based Financing and Securitization Facilities — The Company maintains separate asset-based financing facilities and a securitization facility in the United States, which are revolving facilities for fixed-term leases and loans and for revolving loans, respectively.  This debt is collateralized solely by the U.S. loan and lease payments and associated equipment in the facilities.  The debt has a variable interest rate, and the duration of the debt is based on the terms of the underlying loan and lease payment streams.  As of October 28, 2022, the total debt capacity related to the U.S. asset-based financing and securitization facilities was $5.0 billion.  The Company enters into interest swap agreements to effectively convert a portion of this debt from a floating rate to a fixed rate.  See Note 8 of the Notes to the Condensed Consolidated Financial Statements for additional information about interest rate swaps.
  (was, 2022-09-01, similarity 0.9934):
[0001571996-22-000031:note_history:22]
Asset-Based Financing and Securitization Facilities — The Company maintains separate asset-based financing facilities and a securitization facility in the United States, which are revolving facilities for fixed-term leases and loans and for revolving loans, respectively.  This debt is collateralized solely by the U.S. loan and lease payments and associated equipment in the facilities.  The debt has a variable interest rate and the duration of the debt is based on the terms of the underlying loan and lease payment streams.  As of July 29, 2022, the total debt capacity related to the U.S. asset-based financing and securitization facilities was $5.0 billion.  The Company enters into interest swap agreements to effectively convert a portion of this debt from a floating rate to a fixed rate.  See Note 8 of the Notes to the Condensed Consolidated Financial Statements for additional information about interest rate swaps.

- changed (2022-12-05):
[0001571996-22-000044:note_history:23]
The asset-based financing and securitization facilities contain standard structural features related to the performance of the funded receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the facility, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of October 28, 2022, these criteria were met.
  (was, 2022-09-01, similarity 0.9902):
[0001571996-22-000031:note_history:23]
The asset-based financing and securitization facilities contain standard structural features related to the performance of the funded receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the facility, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of July 29, 2022, these criteria were met.

- changed (2022-12-05):
[0001571996-22-000044:note_history:24]
Securitization Facility — The Company maintains a securitization facility in Europe for fixed-term leases and loans.  This facility is effective through December 21, 2022 and had a total debt capacity of $797 million as of October 28, 2022.  Subsequent to October 28, 2022, the Company extended the term of this facility to be effective through December 21, 2024.
  (was, 2022-09-01, similarity 0.7692):
[0001571996-22-000031:note_history:24]
Securitization Facility — The Company maintains a securitization facility in Europe for fixed-term leases and loans.  This facility is effective through December 21, 2022 and had a total debt capacity of $816 million as of July 29, 2022.

- changed (2022-12-05):
[0001571996-22-000044:note_history:25]
The securitization facility contains standard structural features related to the performance of the securitized receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the program, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of October 28, 2022, these criteria were met.
  (was, 2022-09-01, similarity 0.9897):
[0001571996-22-000031:note_history:25]
The securitization facility contains standard structural features related to the performance of the securitized receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the program, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of July 29, 2022, these criteria were met.

- added (2022-12-05):
[0001571996-22-000044:note_history:26]
Other Borrowings — In connection with the Company’s international financing operations, the Company has entered into revolving structured financing debt programs related to its fixed-term lease and loan products sold in Canada, Europe, Australia, and New Zealand.  The Canadian facility, which is collateralized solely by Canadian loan and lease payments and associated equipment, had a total debt capacity of $332 million as of October 28, 2022 and is effective through January 16, 2025.  The European facility, which is collateralized solely by European loan and lease payments and associated equipment, had a total debt capacity of $598 million as of October 28, 2022 and is effective through December 14, 2023.  The Australia and New Zealand facility, which is collateralized solely by Australia and New Zealand loan and lease payments and associated equipment, had a total debt capacity of $290 million as of October 28, 2022 and is effective through April 20, 2023.

- changed (2022-12-05):
[0001571996-22-000044:note_history:27]
Note Payable — On May 25, 2022, the Company entered into an unsecured credit agreement to fund receivables in Mexico.  As of October 28, 2022, the aggregate principal amount of the note payable was $250 million.  The note bears interest at an annual rate of 4.24% and will mature on May 31, 2024.
  (was, 2022-09-01, similarity 0.9796):
[0001571996-22-000031:note_history:27]
Note Payable — On May 25, 2022, the Company entered into an unsecured credit agreement to fund receivables in Mexico.  As of July 29, 2022, the aggregate principal amount of the note payable was $250 million.  The note bears interest at an annual rate of 4.24% and will mature on May 31, 2024.

- changed (2022-12-05):
[0001571996-22-000044:note_history:28]
Dell Bank Senior Unsecured Eurobonds — On June 24, 2020, Dell Bank issued 500 million Euro of 1.625% senior unsecured four year eurobonds due June 2024.  On October 27, 2021, Dell Bank issued 500 million Euro of 0.5% senior unsecured five year eurobonds due October 2026.  On October 18, 2022, Dell Bank issued 500 million Euro of 4.5% senior unsecured five year eurobonds due October 2027.  The issuances of the senior unsecured eurobonds support the expansion of the financing operations in Europe.
  (was, 2022-09-01, similarity 0.741):
[0001571996-22-000031:note_history:28]
Dell Bank Senior Unsecured Eurobonds — On October 17, 2019, Dell Bank International D.A.C. (“Dell Bank”) issued 500 million Euro of 0.625% senior unsecured three year eurobonds due October 2022.  On June 24, 2020, Dell Bank issued 500 million Euro of 1.625% senior unsecured four year eurobonds due June 2024.  On October 27, 2021, Dell Bank issued 500 million Euro of 0.5% senior unsecured five year eurobonds due October 2026.  The issuances of the senior unsecured eurobonds support the expansion of the financing operations in Europe.

- changed (2022-12-05):
[0001571996-22-000044:note_history:29]
|  | October 28, 2022 |  | January 28, 2022 |
|  | (in millions) |
| Assets held by consolidated VIEs |  |  |  |
| Other current assets | $ | 302 |  |  | $ | 535 |  |
| Financing receivables, net of allowance |  |  |  |
| Short-term | $ | 3,791 |  |  | $ | 3,368 |  |
| Long-term | $ | 3,022 |  |  | $ | 3,141 |  |
| Property, plant, and equipment, net | $ | 1,094 |  |  | $ | 945 |  |
| Liabilities held by consolidated VIEs |  |  |  |
| Debt, net of unamortized debt issuance costs |  |  |  |
| Short-term | $ | 4,996 |  |  | $ | 4,560 |  |
| Long-term | $ | 2,207 |  |  | $ | 2,235 |  |
  (was, 2022-09-01, similarity 0.9891):
[0001571996-22-000031:note_history:29]
|  | July 29, 2022 |  | January 28, 2022 |
|  | (in millions) |
| Assets held by consolidated VIEs |  |  |  |
| Other current assets | $ | 574 |  |  | $ | 535 |  |
| Financing receivables, net of allowance |  |  |  |
| Short-term | $ | 3,313 |  |  | $ | 3,368 |  |
| Long-term | $ | 3,181 |  |  | $ | 3,141 |  |
| Property, plant, and equipment, net | $ | 1,069 |  |  | $ | 945 |  |
| Liabilities held by consolidated VIEs |  |  |  |
| Debt, net of unamortized debt issuance costs |  |  |  |
| Short-term | $ | 4,469 |  |  | $ | 4,560 |  |
| Long-term | $ | 2,450 |  |  | $ | 2,235 |  |

- changed (2022-12-05):
[0001571996-22-000044:note_history:30]
Lease and loan payments and associated equipment transferred via securitization through SPEs were $1.6 billion and $1.4 billion for the three months ended October 28, 2022 and October 29, 2021, respectively, and $4.5 billion and $4.1 billion for the nine months ended October 28, 2022 and October 29, 2021, respectively.
  (was, 2022-09-01, similarity 0.7972):
[0001571996-22-000031:note_history:30]
Lease and loan payments and associated equipment transferred via securitization through SPEs were $1.2 billion and $1.3 billion for the three months ended July 29, 2022 and July 30, 2021, respectively, and $2.9 billion and $2.7 billion for the six months ended July 29, 2022 and July 30, 2021, respectively.

- changed (2022-12-05):
[0001571996-22-000044:note_history:31]
To manage certain concentrations of customer credit exposure, the Company may sell selected fixed-term customer receivables to unrelated third parties on a periodic basis, without recourse.  The amount of customer receivables sold for this purpose was $431 million and $180 million for the nine months ended October 28, 2022 and October 29, 2021, respectively.  The Company’s continuing involvement in these customer receivables is primarily limited to servicing arrangements.
  (was, 2022-09-01, similarity 0.6301):
[0001571996-22-000031:note_history:31]
To manage certain concentrations of customer credit exposure, the Company may sell selected fixed-term customer receivables to unrelated third parties on a periodic basis, without recourse.  The amount of customer receivables sold for this purpose was $425 million and $101 million for the six months ended July 29, 2022 and July 30, 2021, respectively.  The Company’s continuing involvement in these customer receivables is primarily limited to servicing arrangements.

- removed (2022-12-05):
[0001571996-22-000031:note_history:32]
The Company further strengthens customer relationships through flexible consumption models, which enable the Company to offer its customers the option to pay over time and, in certain cases, based on utilization, to provide them with financial flexibility to meet their changing technological requirements.

- removed (2022-12-05):
[0001571996-22-000031:note_history:33]
|  | Three Months Ended |
|  | July 29, 2022 |  | July 30, 2021 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |  |  |  |  |  |  |  |  |  |  |  |
| Balances at beginning of period | $ | 94 |  |  | $ | 87 |  |  | $ | 181 |  |  | $ | 139 |  |  | $ | 177 |  |  | $ | 316 |  |
| Charge-offs, net of recoveries | (12) |  |  | (2) |  |  | (14) |  |  | (10) |  |  | (3) |  |  | (13) |  |
| Provision charged to income statement | 9 |  |  | 7 |  |  | 16 |  |  | (3) |  |  | (13) |  |  | (16) |  |
| Balances at end of period | $ | 91 |  |  | $ | 92 |  |  | $ | 183 |  |  | $ | 126 |  |  | $ | 161 |  |  | $ | 287 |  |

- removed (2022-12-05):
[0001571996-22-000031:note_history:34]
|  | Six Months Ended |
|  | July 29, 2022 |  | July 30, 2021 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |  |  |  |  |  |  |  |  |  |  |  |
| Balances at beginning of period | $ | 102 |  |  | $ | 87 |  |  | $ | 189 |  |  | $ | 148 |  |  | $ | 173 |  |  | $ | 321 |  |
| Charge-offs, net of recoveries | (25) |  |  | (4) |  |  | (29) |  |  | (23) |  |  | (5) |  |  | (28) |  |
| Provision charged to income statement | 14 |  |  | 9 |  |  | 23 |  |  | 1 |  |  | (7) |  |  | (6) |  |
| Balances at end of period | $ | 91 |  |  | $ | 92 |  |  | $ | 183 |  |  | $ | 126 |  |  | $ | 161 |  |  | $ | 287 |  |

- removed (2022-12-05):
[0001571996-22-000031:note_history:35]
|  | July 29, 2022 |
|  | (in millions) |
| Fiscal 2023 (remaining six months) | $ | 1,329 |  |
| Fiscal 2024 | 1,950 |  |
| Fiscal 2025 | 1,277 |  |
| Fiscal 2026 | 659 |  |
| Fiscal 2027 and beyond | 217 |  |
| Total undiscounted cash flows | 5,432 |  |
| Fixed-term loans | 4,795 |  |
| Revolving loans | 705 |  |
| Less: Unearned income | (589) |  |
| Total customer receivables, gross | $ | 10,343 |  |

- removed (2022-12-05):
[0001571996-22-000031:note_history:36]
Other Borrowings — In connection with the Company’s international financing operations, the Company has entered into revolving structured financing debt programs related to its fixed-term lease and loan products sold in Canada, Europe, Australia, and New Zealand.  The Canadian facility, which is collateralized solely by Canadian loan and lease payments and associated equipment, had a total debt capacity of $351 million as of July 29, 2022 and is effective through January 16, 2025.  The European facility, which is collateralized solely by European loan and lease payments and associated equipment, had a total debt capacity of $612 million as of July 29, 2022 and is effective through December 14, 2023.  The Australia and New Zealand facility, which is collateralized solely by Australia and New Zealand loan and lease payments and associated equipment, had a total debt capacity of $315 million as of July 29, 2022 and is effective through April 20, 2023.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-12-05):
[0001571996-22-000044:note_history:37]
|  | October 28, 2022 |  | January 28, 2022 |
|  | (in millions) |
| Senior Notes: |  |  |  |
| 5.45% due June 2023 | $ | 1,000 |  |  | $ | 1,000 |  |
| 4.00% due July 2024 | 1,000 |  |  | 1,000 |  |
| 5.85% due July 2025 | 1,000 |  |  | 1,000 |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 4.90% due October 2026 | 1,750 |  |  | 1,750 |  |
| 6.10% due July 2027 | 500 |  |  | 500 |  |
| 5.30% due October 2029 | 1,750 |  |  | 1,750 |  |
| 6.20% due July 2030 | 750 |  |  | 750 |  |
| 8.10% due July 2036 | 1,000 |  |  | 1,000 |  |
| 3.38% due December 2041 | 1,000 |  |  | 1,000 |  |
| 8.35% due July 2046 | 800 |  |  | 800 |  |
| 3.45% due December 2051 | 1,250 |  |  | 1,250 |  |
| Legacy Notes and Debentures: |  |  |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| DFS Debt (Note 5) | 10,051 |  |  | 9,646 |  |
| Other | 287 |  |  | 337 |  |
| Total debt, principal amount | $ | 27,590 |  |  | $ | 27,235 |  |
| Unamortized discount, net of unamortized premium | (126) |  |  | (134) |  |
| Debt issuance costs | (135) |  |  | (147) |  |
| Total debt, carrying value | $ | 27,329 |  |  | $ | 26,954 |  |
| Total short-term debt, carrying value | $ | 6,767 |  |  | $ | 5,823 |  |
| Total long-term debt, carrying value | $ | 20,562 |  |  | $ | 21,131 |  |
  (was, 2022-09-01, similarity 0.9947):
[0001571996-22-000031:note_history:37]
|  | July 29, 2022 |  | January 28, 2022 |
|  | (in millions) |
| Senior Notes: |  |  |  |
| 5.45% due June 2023 | $ | 1,000 |  |  | $ | 1,000 |  |
| 4.00% due July 2024 | 1,000 |  |  | 1,000 |  |
| 5.85% due July 2025 | 1,000 |  |  | 1,000 |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 4.90% due October 2026 | 1,750 |  |  | 1,750 |  |
| 6.10% due July 2027 | 500 |  |  | 500 |  |
| 5.30% due October 2029 | 1,750 |  |  | 1,750 |  |
| 6.20% due July 2030 | 750 |  |  | 750 |  |
| 8.10% due July 2036 | 1,000 |  |  | 1,000 |  |
| 3.38% due December 2041 | 1,000 |  |  | 1,000 |  |
| 8.35% due July 2046 | 800 |  |  | 800 |  |
| 3.45% due December 2051 | 1,250 |  |  | 1,250 |  |
| Legacy Notes and Debentures: |  |  |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| DFS Debt (Note 5) | 9,640 |  |  | 9,646 |  |
| Other | 311 |  |  | 337 |  |
| Total debt, principal amount | $ | 27,203 |  |  | $ | 27,235 |  |
| Unamortized discount, net of unamortized premium | (128) |  |  | (134) |  |
| Debt issuance costs | (141) |  |  | (147) |  |
| Total debt, carrying value | $ | 26,934 |  |  | $ | 26,954 |  |
| Total short-term debt, carrying value | $ | 6,647 |  |  | $ | 5,823 |  |
| Total long-term debt, carrying value | $ | 20,287 |  |  | $ | 21,131 |  |

- changed (2022-12-05):
[0001571996-22-000044:note_history:38]
On July 18, 2022, the Company established a commercial paper program under which the Company may issue unsecured notes in a maximum aggregate face amount of $5.0 billion outstanding at any time, with maturities up to 397 days from the date of issue.  The notes will be sold on customary terms in the U.S. commercial paper market on a private placement basis.  The proceeds of the notes will be used for general corporate purposes.  As of October 28, 2022, the Company had no outstanding borrowings under the commercial paper program.  Commercial paper issuances and repayments with maturities of 90 days or less are presented on a net basis within cash flows from financing activities on the Condensed Consolidated Statements of Cash Flows.
  (was, 2022-09-01, similarity 0.77):
[0001571996-22-000031:note_history:38]
On July 18, 2022, the Company established a commercial paper program under which the Company may issue unsecured notes in a maximum aggregate face amount of $5.0 billion outstanding at any time, with maturities up to 397 days from the date of issue.  The notes will be sold on customary terms in the U.S. commercial paper market on a private placement basis.  The proceeds of the notes will be used for general corporate purposes.  As of July 29, 2022, the Company had no outstanding borrowings under the commercial paper program.  Subsequent to July 29, 2022, the Company issued and subsequently repaid notes under this program.

- changed (2022-12-05):
[0001571996-22-000044:note_history:39]
Senior Notes — The Company completed private offerings of multiple series of senior notes which were issued on June 1, 2016, June 22, 2016, March 20, 2019, April 9, 2020, and December 13, 2021 in aggregate principal amounts of $20.0 billion, $3.3 billion, $4.5 billion, $2.3 billion, and $2.3 billion, respectively (together with the registered senior notes subsequently issued in exchange, the “Senior Notes”).  Interest on these borrowings is payable semiannually.
  (was, 2022-09-01, similarity 0.9988):
[0001571996-22-000031:note_history:39]
Senior Notes — The Company completed private offerings of multiple series of senior notes which were issued on June 1, 2016, June 22, 2016, March 20, 2019, April 9, 2020, and December 13, 2021 in aggregate principal amounts of $20.0 billion, $3.3 billion, $4.5 billion, $2.3 billion, and $2.3 billion respectively (together with the registered senior notes subsequently issued in exchange, the “Senior Notes”).  Interest on these borrowings is payable semiannually.

- changed (2022-12-05):
[0001571996-22-000044:note_history:40]
In June 2021, Dell International L.L.C. and EMC Corporation, wholly-owned subsidiaries of Dell Technologies Inc. and issuers of the Senior Notes (the “Issuers”), completed an offer to exchange any and all outstanding Senior Notes issued on June 1, 2016, March 20, 2019, and April 9, 2020 for senior notes registered under the Securities Act of 1933 having terms substantially identical to the terms of the outstanding Senior Notes.  The Issuers issued $18.4 billion aggregate principal amount of registered Senior Notes in exchange for the same aggregate principal amount of unregistered Senior Notes.  The aggregate principal amount of unregistered Senior Notes remaining outstanding following the settlement of the exchange offer was approximately $0.1 billion.
  (was, 2022-09-01, similarity 0.9898):
[0001571996-22-000031:note_history:40]
In June 2021, Dell International L.L.C. and EMC Corporation, wholly-owned subsidiaries of Dell Technologies Inc. and issuers of the Senior Notes (the “Issuers”), completed offers to exchange any and all outstanding Senior Notes issued on June 1, 2016, March 20, 2019, and April 9, 2020 for senior notes registered under the Securities Act of 1933 having terms substantially identical to the terms of the outstanding Senior Notes.  The Issuers issued $18.4 billion aggregate principal amount of registered Senior Notes in exchange for the same aggregate principal amount of unregistered Senior Notes.  The aggregate principal amount of unregistered Senior Notes remaining outstanding following the settlement of the exchange offers was approximately $0.1 billion.

- changed (2022-12-05):
[0001571996-22-000044:note_history:41]
2021 Revolving Credit Facility — As of October 28, 2022, the Company’s revolving credit facility, which was entered into on November 1, 2021 (the “2021 Revolving Credit Facility”), matures on November 1, 2026.  This facility provides the Company with revolving commitments in an aggregate principal amount of $5.0 billion as of October 28, 2022 for general corporate purposes, including liquidity support for the Company’s commercial paper program, and includes a letter of credit sub-facility of up to $0.5 billion and a swing-line loan sub-facility of up to $0.5 billion.  The 2021 Revolving Credit Facility also allows the Company to obtain incremental additional commitments on one or more occasions in minimum amounts of $10 million.
  (was, 2022-09-01, similarity 0.9736):
[0001571996-22-000031:note_history:41]
2021 Revolving Credit Facility — The Company’s revolving credit facility, which was entered into on November 1, 2021 (the “2021 Revolving Credit Facility”), matures on November 1, 2026.  This facility provides the Company with revolving commitments in an aggregate principal amount of $5.0 billion for general corporate purposes, including liquidity support for the Company’s commercial paper program, and includes a letter of credit sub-facility of up to $0.5 billion and a swing-line loan sub-facility of up to $0.5 billion.  The 2021 Revolving Credit Facility also allows the Company to obtain incremental additional commitments on one or more occasions in minimum amounts of $10 million.

- changed (2022-12-05):
[0001571996-22-000044:note_history:42]
Borrowings under the 2021 Revolving Credit Facility bear interest at a rate per annum equal to an applicable margin plus, at the borrowers’ option, either (a) the specified London Interbank Offered Rate (“LIBOR”) or (b) a base rate.  The margin applicable to LIBOR and base rate borrowings varies based upon the Company’s existing date ratings.  The base rate is calculated based upon the greatest of the specified prime rate, the specified federal reserve bank rate, or LIBOR plus 1%.  The borrowers may voluntarily repay outstanding loans under the 2021 Revolving Credit Facility at any time without premium or penalty, other than customary breakage costs.
  (was, 2022-09-01, similarity 0.8503):
[0001571996-22-000031:note_history:42]
Borrowings under the 2021 Revolving Credit Facility bear interest at a rate per annum equal to an applicable margin plus, at the borrowers’ option, either (a) the specified London Interbank Offered Rate (“LIBOR”) or (b) a base rate.  The margin applicable to LIBOR and base rate borrowings varies based upon the Company’s existing date ratings.  The base rate is calculated based upon the greatest of the specified prime rate, the specified federal reserve bank rate, or LIBOR plus 1%.

- changed (2022-12-05):
[0001571996-22-000044:note_history:43]
As of October 28, 2022, available borrowings under the 2021 Revolving Credit Facility totaled $5.0 billion.
  (was, 2022-09-01, similarity 0.9418):
[0001571996-22-000031:note_history:43]
As of July 29, 2022, available borrowings under the 2021 Revolving Credit Facility totaled $5.0 billion.

- added (2022-12-05):
[0001571996-22-000044:note_history:44]
Subsequent to October 28, 2022, the Company entered into an amendment to the 2021 Revolving Credit Facility to (i) transition from a LIBOR-based borrowing rate to a borrowing rate based on SOFR (Secured Overnight Financing Rate), (ii) extend the maturity date by one year to November 1, 2027, and (iii) increase the revolving commitments by $1.0 billion to an aggregate principal amount of $6.0 billion.  The other terms of the 2021 Revolving Credit Facility remain unchanged.

- changed (2022-12-05):
[0001571996-22-000044:note_history:45]
Covenants — The credit agreement governing the 2021 Revolving Credit Facility and the indentures governing the Senior Notes and the Legacy Notes and Debentures impose various limitations, subject to exceptions, on creating certain liens and entering into sale and lease-back transactions.  The foregoing credit agreement and indentures contain customary events of default, including failure to make required payments, failure to comply with covenants, and the occurrence of certain events of bankruptcy and insolvency.  The 2021 Revolving Credit Facility is also subject to an interest coverage ratio covenant that is tested at the end of each fiscal quarter with respect to the Company’s preceding four fiscal quarters.  The Company was in compliance with this financial covenant as of October 28, 2022.
  (was, 2022-09-01, similarity 0.993):
[0001571996-22-000031:note_history:45]
Covenants — The credit agreement governing the 2021 Revolving Credit Facility and the indentures governing the Senior Notes and the Legacy Notes and Debentures impose various limitations, subject to exceptions, on creating certain liens and entering into sale and lease-back transactions.  The foregoing credit agreement and indentures contain customary events of default, including failure to make required payments, failure to comply with covenants, and the occurrence of certain events of bankruptcy and insolvency.  The 2021 Revolving Credit Facility is also subject to an interest coverage ratio covenant that is tested at the end of each fiscal quarter with respect to the Company’s preceding four fiscal quarters.  The Company was in compliance with this financial covenant as of July 29, 2022.

- changed (2022-12-05):
[0001571996-22-000044:note_history:46]
The following table presents the aggregate future maturities of the Company’s debt as of October 28, 2022 for the periods indicated:
  (was, 2022-09-01, similarity 0.9562):
[0001571996-22-000031:note_history:46]
The following table presents the aggregate future maturities of the Company’s debt as of July 29, 2022 for the periods indicated:

- changed (2022-12-05):
[0001571996-22-000044:note_history:47]
|  | Maturities by Fiscal Year |
|  | 2023 (remaining three months) |  | 2024 |  | 2025 |  | 2026 |  | 2027 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Notes | $ | — |  |  | $ | 1,000 |  |  | $ | 1,000 |  |  | $ | 1,000 |  |  | $ | 6,250 |  |  | $ | 7,050 |  |  | $ | 16,300 |  |
| Legacy Notes and Debentures | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 952 |  |  | 952 |  |
| DFS Debt | 2,166 |  |  | 4,154 |  |  | 2,424 |  |  | 255 |  |  | 552 |  |  | 500 |  |  | 10,051 |  |
| Other | 2 |  |  | 157 |  |  | 105 |  |  | 20 |  |  | 1 |  |  | 2 |  |  | 287 |  |
| Total maturities, principal amount | 2,168 |  |  | 5,311 |  |  | 3,529 |  |  | 1,275 |  |  | 6,803 |  |  | 8,504 |  |  | 27,590 |  |
| Associated carrying value adjustments | (5) |  |  | (5) |  |  | (9) |  |  | (8) |  |  | (51) |  |  | (183) |  |  | (261) |  |
| Total maturities, carrying value amount | $ | 2,163 |  |  | $ | 5,306 |  |  | $ | 3,520 |  |  | $ | 1,267 |  |  | $ | 6,752 |  |  | $ | 8,321 |  |  | $ | 27,329 |  |
  (was, 2022-09-01, similarity 0.9949):
[0001571996-22-000031:note_history:47]
|  | Maturities by Fiscal Year |
|  | 2023 (remaining six months) |  | 2024 |  | 2025 |  | 2026 |  | 2027 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Notes | $ | — |  |  | $ | 1,000 |  |  | $ | 1,000 |  |  | $ | 1,000 |  |  | $ | 6,250 |  |  | $ | 7,050 |  |  | $ | 16,300 |  |
| Legacy Notes and Debentures | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 952 |  |  | 952 |  |
| DFS Debt | 3,538 |  |  | 3,027 |  |  | 2,245 |  |  | 263 |  |  | 565 |  |  | 2 |  |  | 9,640 |  |
| Other | 21 |  |  | 161 |  |  | 107 |  |  | 20 |  |  | 1 |  |  | 1 |  |  | 311 |  |
| Total maturities, principal amount | 3,559 |  |  | 4,188 |  |  | 3,352 |  |  | 1,283 |  |  | 6,816 |  |  | 8,005 |  |  | 27,203 |  |
| Associated carrying value adjustments | (3) |  |  | (7) |  |  | (10) |  |  | (8) |  |  | (54) |  |  | (187) |  |  | (269) |  |
| Total maturities, carrying value amount | $ | 3,556 |  |  | $ | 4,181 |  |  | $ | 3,342 |  |  | $ | 1,275 |  |  | $ | 6,762 |  |  | $ | 7,818 |  |  | $ | 26,934 |  |

- removed (2022-12-05):
[0001571996-22-000031:note_history:48]
The borrowers may voluntarily repay outstanding loans under the 2021 Revolving Credit Facility at any time without premium or penalty, other than customary breakage costs.


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2022-12-05):
[0001571996-22-000044:note_history:49]
|  | October 28, 2022 |  | January 28, 2022 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Notes | $ | 16.2 |  |  | $ | 15.3 |  |  | $ | 16.1 |  |  | $ | 18.5 |  |
| Legacy Notes and Debentures | $ | 0.9 |  |  | $ | 0.9 |  |  | $ | 0.8 |  |  | $ | 1.1 |  |

- removed (2022-12-05):
[0001571996-22-000031:note_history:50]
|  | July 29, 2022 |  | January 28, 2022 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Notes | $ | 16.2 |  |  | $ | 16.7 |  |  | $ | 16.1 |  |  | $ | 18.5 |  |
| Legacy Notes and Debentures | $ | 0.8 |  |  | $ | 1.0 |  |  | $ | 0.8 |  |  | $ | 1.1 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-12-05):
[0001571996-22-000044:note_history:51]
|  | October 28, 2022 |  | January 28, 2022 |
| DFS debt | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing and securitization facilities | $ | 3,226 |  |  | $ | 3,054 |  |
| Fixed-term securitization offerings | 3,302 |  |  | 3,011 |  |
| Other | 87 |  |  | 135 |  |
| Total DFS U.S. debt | 6,615 |  |  | 6,200 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 688 |  |  | 739 |  |
| Other borrowings | 1,004 |  |  | 785 |  |
| Note payable | 250 |  |  | 250 |  |
| Dell Bank senior unsecured eurobonds | 1,494 |  |  | 1,672 |  |
| Total DFS international debt | 3,436 |  |  | 3,446 |  |
| Total DFS debt | $ | 10,051 |  |  | $ | 9,646 |  |
| Total short-term DFS debt | $ | 5,626 |  |  | $ | 5,803 |  |
| Total long-term DFS debt | $ | 4,425 |  |  | $ | 3,843 |  |
  (was, 2022-09-01, similarity 0.9918):
[0001571996-22-000031:note_history:51]
|  | July 29, 2022 |  | January 28, 2022 |
| DFS debt | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing and securitization facilities | $ | 2,271 |  |  | $ | 3,054 |  |
| Fixed-term securitization offerings | 3,968 |  |  | 3,011 |  |
| Other | 117 |  |  | 135 |  |
| Total DFS U.S. debt | 6,356 |  |  | 6,200 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 694 |  |  | 739 |  |
| Other borrowings | 810 |  |  | 785 |  |
| Note payable | 250 |  |  | 250 |  |
| Dell Bank senior unsecured eurobonds | 1,530 |  |  | 1,672 |  |
| Total DFS international debt | 3,284 |  |  | 3,446 |  |
| Total DFS debt | $ | 9,640 |  |  | $ | 9,646 |  |
| Total short-term DFS debt | $ | 5,565 |  |  | $ | 5,803 |  |
| Total long-term DFS debt | $ | 4,075 |  |  | $ | 3,843 |  |

- changed (2022-12-05):
[0001571996-22-000044:note_history:52]
|  | October 28, 2022 |  | January 28, 2022 |
|  | (in millions) |
| Senior Notes: |  |  |  |
| 5.45% due June 2023 | $ | 1,000 |  |  | $ | 1,000 |  |
| 4.00% due July 2024 | 1,000 |  |  | 1,000 |  |
| 5.85% due July 2025 | 1,000 |  |  | 1,000 |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 4.90% due October 2026 | 1,750 |  |  | 1,750 |  |
| 6.10% due July 2027 | 500 |  |  | 500 |  |
| 5.30% due October 2029 | 1,750 |  |  | 1,750 |  |
| 6.20% due July 2030 | 750 |  |  | 750 |  |
| 8.10% due July 2036 | 1,000 |  |  | 1,000 |  |
| 3.38% due December 2041 | 1,000 |  |  | 1,000 |  |
| 8.35% due July 2046 | 800 |  |  | 800 |  |
| 3.45% due December 2051 | 1,250 |  |  | 1,250 |  |
| Legacy Notes and Debentures: |  |  |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| DFS Debt (Note 5) | 10,051 |  |  | 9,646 |  |
| Other | 287 |  |  | 337 |  |
| Total debt, principal amount | $ | 27,590 |  |  | $ | 27,235 |  |
| Unamortized discount, net of unamortized premium | (126) |  |  | (134) |  |
| Debt issuance costs | (135) |  |  | (147) |  |
| Total debt, carrying value | $ | 27,329 |  |  | $ | 26,954 |  |
| Total short-term debt, carrying value | $ | 6,767 |  |  | $ | 5,823 |  |
| Total long-term debt, carrying value | $ | 20,562 |  |  | $ | 21,131 |  |
  (was, 2022-09-01, similarity 0.9947):
[0001571996-22-000031:note_history:52]
|  | July 29, 2022 |  | January 28, 2022 |
|  | (in millions) |
| Senior Notes: |  |  |  |
| 5.45% due June 2023 | $ | 1,000 |  |  | $ | 1,000 |  |
| 4.00% due July 2024 | 1,000 |  |  | 1,000 |  |
| 5.85% due July 2025 | 1,000 |  |  | 1,000 |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 4.90% due October 2026 | 1,750 |  |  | 1,750 |  |
| 6.10% due July 2027 | 500 |  |  | 500 |  |
| 5.30% due October 2029 | 1,750 |  |  | 1,750 |  |
| 6.20% due July 2030 | 750 |  |  | 750 |  |
| 8.10% due July 2036 | 1,000 |  |  | 1,000 |  |
| 3.38% due December 2041 | 1,000 |  |  | 1,000 |  |
| 8.35% due July 2046 | 800 |  |  | 800 |  |
| 3.45% due December 2051 | 1,250 |  |  | 1,250 |  |
| Legacy Notes and Debentures: |  |  |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| DFS Debt (Note 5) | 9,640 |  |  | 9,646 |  |
| Other | 311 |  |  | 337 |  |
| Total debt, principal amount | $ | 27,203 |  |  | $ | 27,235 |  |
| Unamortized discount, net of unamortized premium | (128) |  |  | (134) |  |
| Debt issuance costs | (141) |  |  | (147) |  |
| Total debt, carrying value | $ | 26,934 |  |  | $ | 26,954 |  |
| Total short-term debt, carrying value | $ | 6,647 |  |  | $ | 5,823 |  |
| Total long-term debt, carrying value | $ | 20,287 |  |  | $ | 21,131 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-12-05):
[0001571996-22-000044:note_history:53]
The following table presents the aggregate future maturities of the Company’s debt as of October 28, 2022 for the periods indicated:
  (was, 2022-09-01, similarity 0.9562):
[0001571996-22-000031:note_history:53]
The following table presents the aggregate future maturities of the Company’s debt as of July 29, 2022 for the periods indicated:

- changed (2022-12-05):
[0001571996-22-000044:note_history:54]
|  | Maturities by Fiscal Year |
|  | 2023 (remaining three months) |  | 2024 |  | 2025 |  | 2026 |  | 2027 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Notes | $ | — |  |  | $ | 1,000 |  |  | $ | 1,000 |  |  | $ | 1,000 |  |  | $ | 6,250 |  |  | $ | 7,050 |  |  | $ | 16,300 |  |
| Legacy Notes and Debentures | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 952 |  |  | 952 |  |
| DFS Debt | 2,166 |  |  | 4,154 |  |  | 2,424 |  |  | 255 |  |  | 552 |  |  | 500 |  |  | 10,051 |  |
| Other | 2 |  |  | 157 |  |  | 105 |  |  | 20 |  |  | 1 |  |  | 2 |  |  | 287 |  |
| Total maturities, principal amount | 2,168 |  |  | 5,311 |  |  | 3,529 |  |  | 1,275 |  |  | 6,803 |  |  | 8,504 |  |  | 27,590 |  |
| Associated carrying value adjustments | (5) |  |  | (5) |  |  | (9) |  |  | (8) |  |  | (51) |  |  | (183) |  |  | (261) |  |
| Total maturities, carrying value amount | $ | 2,163 |  |  | $ | 5,306 |  |  | $ | 3,520 |  |  | $ | 1,267 |  |  | $ | 6,752 |  |  | $ | 8,321 |  |  | $ | 27,329 |  |
  (was, 2022-09-01, similarity 0.9949):
[0001571996-22-000031:note_history:54]
|  | Maturities by Fiscal Year |
|  | 2023 (remaining six months) |  | 2024 |  | 2025 |  | 2026 |  | 2027 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Notes | $ | — |  |  | $ | 1,000 |  |  | $ | 1,000 |  |  | $ | 1,000 |  |  | $ | 6,250 |  |  | $ | 7,050 |  |  | $ | 16,300 |  |
| Legacy Notes and Debentures | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 952 |  |  | 952 |  |
| DFS Debt | 3,538 |  |  | 3,027 |  |  | 2,245 |  |  | 263 |  |  | 565 |  |  | 2 |  |  | 9,640 |  |
| Other | 21 |  |  | 161 |  |  | 107 |  |  | 20 |  |  | 1 |  |  | 1 |  |  | 311 |  |
| Total maturities, principal amount | 3,559 |  |  | 4,188 |  |  | 3,352 |  |  | 1,283 |  |  | 6,816 |  |  | 8,005 |  |  | 27,203 |  |
| Associated carrying value adjustments | (3) |  |  | (7) |  |  | (10) |  |  | (8) |  |  | (54) |  |  | (187) |  |  | (269) |  |
| Total maturities, carrying value amount | $ | 3,556 |  |  | $ | 4,181 |  |  | $ | 3,342 |  |  | $ | 1,275 |  |  | $ | 6,762 |  |  | $ | 7,818 |  |  | $ | 26,934 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2022-12-05):
[0001571996-22-000044:note_history:55]
RELATED PARTY TRANSACTIONS 
VMware is considered to be a related party of the Company as a result of Michael Dell’s ownership interests in both Dell Technologies and VMware as well as Mr. Dell’s continued service as Chairman and Chief Executive Officer of Dell Technologies and as Chairman of the Board of VMware, Inc.  See Note 1 and Note 2 of the Notes to the Condensed Consolidated Financial Statements for more information about the VMware Spin-off.
  (was, 2022-09-01, similarity 0.9989):
[0001571996-22-000031:note_history:55]
RELATED PARTY TRANSACTIONS 
VMware is considered to be a related party of the Company as a result of Michael Dell’s ownership interest in both Dell Technologies and VMware as well as Mr. Dell’s continued service as Chairman and Chief Executive Officer of Dell Technologies and as Chairman of the Board of VMware, Inc.  See Note 1 and Note 2 of the Notes to the Condensed Consolidated Financial Statements for more information about the VMware Spin-off.

- added (2022-12-05):
[0001571996-22-000044:note_history:56]
The information provided below includes a summary of transactions with VMware.  Transactions with related parties other than VMware during the periods presented were immaterial, individually and in aggregate.

- changed (2022-12-05):
[0001571996-22-000044:note_history:57]
•Dell Technologies procures products and services from VMware for its internal use.  For the three and nine months ended October 28, 2022 and October 29, 2021, costs incurred associated with products and services purchased from VMware for internal use were immaterial.
  (was, 2022-09-01, similarity 0.8515):
[0001571996-22-000031:note_history:57]
•Dell Technologies procures products and services from VMware for its internal use.  For the three and six months ended July 29, 2022 and July 30, 2021, costs incurred associated with products and services purchased from VMware for internal use were immaterial.

- changed (2022-12-05):
[0001571996-22-000044:note_history:58]
•Dell Technologies sells and leases products and sells services to VMware.  For the three and nine months ended October 28, 2022 and October 29, 2021, revenue recognized from sales of services to VMware was immaterial.
  (was, 2022-09-01, similarity 0.9333):
[0001571996-22-000031:note_history:58]
•Dell Technologies sells and leases products and sells services to VMware.  For the three and six months ended July 29, 2022 and July 30, 2021, revenue recognized from sales of services to VMware was immaterial.

- changed (2022-12-05):
[0001571996-22-000044:note_history:59]
•DFS provides financing to certain VMware end users.  Upon acceptance of the financing arrangement by both VMware’s end users and DFS, DFS recognizes amounts due to related parties on the Condensed Consolidated Statements of Financial Position.  Associated financing fees are recorded to product net revenue on the Condensed Consolidated Statements of Income and are reflected within sales and leases of products to VMware in the table below.
  (was, 2022-09-01, similarity 0.8959):
[0001571996-22-000031:note_history:59]
•DFS provides financing to certain VMware end users.  Upon acceptance of the financing arrangement by both VMware’s end users and DFS, DFS recognizes amounts due to related parties on the Condensed Consolidated Statements of Financial Position.  Associated financing fees are recorded to product net revenue on the Condensed Consolidated Statements of Income.

- changed (2022-12-05):
[0001571996-22-000044:note_history:60]
•Dell Technologies and VMware also enter into joint marketing, sales, and branding arrangements, for which both parties may incur costs.  For the three and nine months ended October 28, 2022 and October 29, 2021, consideration received from VMware for joint marketing, sales, and branding arrangements was immaterial.
  (was, 2022-09-01, similarity 0.6368):
[0001571996-22-000031:note_history:60]
•Dell Technologies and VMware also enter into joint marketing, sales, and branding arrangements, for which both parties may incur costs.  For the three and six months ended July 29, 2022 and July 30, 2021, consideration received from VMware for joint marketing, sales, and branding arrangements was immaterial.

- changed (2022-12-05):
[0001571996-22-000044:note_history:61]
•Dell Technologies and VMware enter into agreements to collaborate on technology projects in which one party pays the corresponding party for services or the reimbursement of costs.  For the three and nine months ended October 28, 2022 and October 29, 2021, collaborative technology projects were immaterial.
  (was, 2022-09-01, similarity 0.8376):
[0001571996-22-000031:note_history:61]
•Dell Technologies and VMware enter into agreements to collaborate on technology projects in which one party pays the corresponding party for services or the reimbursement of costs.  For the three and six months ended July 29, 2022 and July 30, 2021, collaborative technology projects were immaterial.

- added (2022-12-05):
[0001571996-22-000044:note_history:62]
•Dell Technologies and VMware entered into a transition services agreement in connection with the VMware Spin-off to provide various support services, including investment advisory services, certain support services from Dell Technologies personnel, and other transitional services.  Costs associated with this agreement were immaterial for the three and nine months ended October 28, 2022.

- added (2022-12-05):
[0001571996-22-000044:note_history:63]
•Prior to the completion of the VMware Spin-off, Dell Technologies provided support services and support from Dell Technologies personnel to VMware in certain geographic regions where VMware did not have an established legal entity.  These employees were managed by VMware but Dell Technologies incurred the costs for these such services.  The costs incurred by Dell Technologies on VMware’s behalf to these employees were charged to VMware.  For the three and nine months ended October 29, 2021, costs associated with such seconded employees were immaterial.  Remaining activity related to seconded employees occurring after the completion of the VMware Spin-off is governed by the transition services agreement discussed above.

- changed (2022-12-05):
[0001571996-22-000044:note_history:64]
|  |  |  | Three Months Ended |  | Nine Months Ended |
|  | Classification |  | October 28, 2022 |  | October 29, 2021 |  | October 28, 2022 |  | October 29, 2021 |
|  |  |  | (in millions) |
| Sales and leases of products to VMware | Net revenue - products |  | $ | 49 |  |  | $ | 56 |  |  | $ | 130 |  |  | $ | 134 |  |
| Purchase of VMware products for resale | Cost of net revenue - products |  | $ | 281 |  |  | $ | 355 |  |  | $ | 962 |  |  | $ | 1,061 |  |
| Purchase of VMware services for resale | Cost of net revenue - services |  | $ | 733 |  |  | $ | 636 |  |  | $ | 2,204 |  |  | $ | 1,830 |  |
  (was, 2022-09-01, similarity 0.8984):
[0001571996-22-000031:note_history:64]
|  |  |  | Three Months Ended |  | Six Months Ended |
|  | Classification |  | July 29, 2022 |  | July 30, 2021 |  | July 29, 2022 |  | July 30, 2021 |
|  |  |  | (in millions) |
| Sales and leases of products to VMware | Net revenue - products |  | $ | 35 |  |  | $ | 31 |  |  | $ | 81 |  |  | $ | 78 |  |
| Purchase of VMware products for resale | Cost of net revenue - products |  | $ | 426 |  |  | $ | 387 |  |  | $ | 681 |  |  | $ | 706 |  |
| Purchase of VMware services for resale | Cost of net revenue - services |  | $ | 762 |  |  | $ | 616 |  |  | $ | 1,471 |  |  | $ | 1,194 |  |

- changed (2022-12-05):
[0001571996-22-000044:note_history:65]
The following table presents information about the impact of Dell Technologies’ related party transactions with VMware on the Condensed Consolidated Statements of Financial Position as of the dates indicated:
  (was, 2022-09-01, similarity 0.9327):
[0001571996-22-000031:note_history:65]
The following table presents information about the impact of Dell Technologies’ related party transactions with VMware on the Condensed Consolidated Statements of Financial Position for the periods indicated:

- changed (2022-12-05):
[0001571996-22-000044:note_history:66]
|  | Classification |  | October 28, 2022 |  | January 28, 2022 |
|  |  |  | (in millions) |
| Deferred costs related to VMware products and services for resale | Other current assets |  | $ | 2,560 |  |  | $ | 2,571 |  |
| Deferred costs related to VMware products and services for resale | Other non-current assets |  | $ | 1,984 |  |  | $ | 2,311 |  |
  (was, 2022-09-01, similarity 0.9824):
[0001571996-22-000031:note_history:66]
|  | Classification |  | July 29, 2022 |  | January 28, 2022 |
|  |  |  | (in millions) |
| Deferred costs related to VMware products and services for resale | Other current assets |  | $ | 2,652 |  |  | $ | 2,571 |  |
| Deferred costs related to VMware products and services for resale | Other non-current assets |  | $ | 2,166 |  |  | $ | 2,311 |  |

- changed (2022-12-05):
[0001571996-22-000044:note_history:67]
|  | October 28, 2022 |  | January 28, 2022 |
|  | (in millions) |
| Due from related party, net, current (a) | $ | 203 |  |  | $ | 131 |  |
| Due from related party, net, non-current (b) | $ | 612 |  |  | $ | 710 |  |
| Due to related party, current (c) | $ | 712 |  |  | $ | 1,414 |  |
  (was, 2022-09-01, similarity 0.978):
[0001571996-22-000031:note_history:67]
|  | July 29, 2022 |  | January 28, 2022 |
|  | (in millions) |
| Due from related party, net, current (a) | $ | 195 |  |  | $ | 131 |  |
| Due from related party, net, non-current (b) | $ | 609 |  |  | $ | 710 |  |
| Due to related party, current (c) | $ | 1,269 |  |  | $ | 1,414 |  |

- changed (2022-12-05):
[0001571996-22-000044:note_history:68]
(a)    Amounts due from related party, net, current consists of amounts due from VMware, inclusive of current net tax receivables from VMware under the Tax Agreements described below.  Amounts, excluding tax, are generally settled in cash within 60 days of each quarter-end.
  (was, 2022-09-01, similarity 0.619):
[0001571996-22-000031:note_history:68]
(a)    Amounts due from related party, current consists of amounts due from VMware, inclusive of current net tax receivables from VMware under the Tax Agreements.  Amounts, excluding tax, are generally settled in cash within 60 days of each quarter-end.

- changed (2022-12-05):
[0001571996-22-000044:note_history:69]
(b)  Amounts due from related party, net, non-current consists of non-current portion of net receivables from VMware under the Tax Agreements.
  (was, 2022-09-01, similarity 0.9819):
[0001571996-22-000031:note_history:69]
(b)  Amounts due from related party, non-current consists of non-current portion of net receivables from VMware under the Tax Agreements.

- added (2022-12-05):
[0001571996-22-000044:note_history:70]
Net receipts from VMware pursuant to the Tax Agreements were immaterial during the three and nine months ended October 28, 2022 and October 29, 2021, and primarily relate to VMware’s portion of the Transition Tax, federal income taxes on Dell Technologies’ consolidated tax return, and state tax payments for combined states.

- added (2022-12-05):
[0001571996-22-000044:note_history:71]
As a result of the activity under the Tax Agreements with VMware, amounts due from VMware were $569 million and $621 million as of October 28, 2022 and January 28, 2022, respectively, primarily related to VMware’s estimated tax obligation resulting from the Transition Tax.  The 2017 Tax Cuts and Jobs Act included a deferral election for an eight-year installment payment method on the Transition Tax.  Dell Technologies expects VMware to pay the remainder of its Transition Tax over a period of three years.

- changed (2022-12-05):
[0001571996-22-000044:note_history:72]
Indemnification — Upon consummation of the VMware Spin-off, Dell Technologies recorded net income tax indemnification receivables from VMware related to certain income tax liabilities for which Dell Technologies is jointly and severally liable, but for which it is indemnified by VMware under the Tax Matters Agreement.  The amounts that VMware may be obligated to pay Dell Technologies could vary depending on the outcome of certain unresolved tax matters, which may not be resolved for several years.  The net receivable as of October 28, 2022 and January 28, 2022 was $157 million and$144 million, respectively.
  (was, 2022-09-01, similarity 0.9908):
[0001571996-22-000031:note_history:72]
Indemnification — Upon consummation of the VMware Spin-off, Dell Technologies recorded net income tax indemnification receivables from VMware related to certain income tax liabilities for which Dell Technologies is jointly and severally liable, but for which it is indemnified by VMware under the Tax Matters Agreement.  The amounts that VMware may be obligated to pay Dell Technologies could vary depending on the outcome of certain unresolved tax matters, which may not be resolved for several years.  The net receivable as of July 29, 2022 and January 28, 2022 was $154 million and$144 million, respectively.

- removed (2022-12-05):
[0001571996-22-000031:note_history:73]
The information provided below includes a summary of transactions with VMware, Inc. and with its consolidated subsidiaries (collectively, “VMware”).  Transactions with related parties other than VMware during the periods presented were immaterial, individually and in aggregate.

- removed (2022-12-05):
[0001571996-22-000031:note_history:74]
•Dell Technologies provides support services and support from Dell Technologies personnel to VMware in certain geographic regions where VMware does not have an established legal entity.  These employees are managed by VMware but Dell Technologies incurs the costs for these such services.  The costs incurred by Dell Technologies on VMware’s behalf to these employees are charged to VMware.  For the three and six months ended July 29, 2022 and July 30, 2021, costs associated with such seconded employees were immaterial.

- removed (2022-12-05):
[0001571996-22-000031:note_history:75]
•Dell Technologies and VMware entered into a transition services agreement in connection with the VMware Spin-off to provide various support services including investment advisory services, certain support services from Dell Technologies personnel, and other transitional services.  Costs associated with this agreement were immaterial for the three and six months ended July 29, 2022.

- removed (2022-12-05):
[0001571996-22-000031:note_history:76]
Net receipts from VMware pursuant to the Tax Agreements were immaterial during the three and six months ended July 29, 2022 and July 30, 2021, and primarily relate to VMware’s portion of the Transition Tax, federal income taxes on Dell Technologies’ consolidated tax return, and state tax payments for combined states.

- removed (2022-12-05):
[0001571996-22-000031:note_history:77]
As a result of the activity under the Tax Agreements with VMware, amounts due from VMware were $570 million and $621 million as of July 29, 2022 and January 28, 2022, respectively, primarily related to VMware’s estimated tax obligation resulting from the Transition Tax.  The 2017 Tax Cuts and Jobs Act included a deferral election for an eight-year installment payment method on the Transition Tax.  Dell Technologies expects VMware to pay the remainder of its Transition Tax over a period of three years.


## us-gaap:ScheduleOfRelatedPartyTransactionsTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2022-12-05):
[0001571996-22-000044:note_history:78]
|  |  |  | Three Months Ended |  | Nine Months Ended |
|  | Classification |  | October 28, 2022 |  | October 29, 2021 |  | October 28, 2022 |  | October 29, 2021 |
|  |  |  | (in millions) |
| Sales and leases of products to VMware | Net revenue - products |  | $ | 49 |  |  | $ | 56 |  |  | $ | 130 |  |  | $ | 134 |  |
| Purchase of VMware products for resale | Cost of net revenue - products |  | $ | 281 |  |  | $ | 355 |  |  | $ | 962 |  |  | $ | 1,061 |  |
| Purchase of VMware services for resale | Cost of net revenue - services |  | $ | 733 |  |  | $ | 636 |  |  | $ | 2,204 |  |  | $ | 1,830 |  |
  (was, 2022-09-01, similarity 0.8984):
[0001571996-22-000031:note_history:78]
|  |  |  | Three Months Ended |  | Six Months Ended |
|  | Classification |  | July 29, 2022 |  | July 30, 2021 |  | July 29, 2022 |  | July 30, 2021 |
|  |  |  | (in millions) |
| Sales and leases of products to VMware | Net revenue - products |  | $ | 35 |  |  | $ | 31 |  |  | $ | 81 |  |  | $ | 78 |  |
| Purchase of VMware products for resale | Cost of net revenue - products |  | $ | 426 |  |  | $ | 387 |  |  | $ | 681 |  |  | $ | 706 |  |
| Purchase of VMware services for resale | Cost of net revenue - services |  | $ | 762 |  |  | $ | 616 |  |  | $ | 1,471 |  |  | $ | 1,194 |  |

- changed (2022-12-05):
[0001571996-22-000044:note_history:79]
The following table presents information about the impact of Dell Technologies’ related party transactions with VMware on the Condensed Consolidated Statements of Financial Position as of the dates indicated:
  (was, 2022-09-01, similarity 0.9327):
[0001571996-22-000031:note_history:79]
The following table presents information about the impact of Dell Technologies’ related party transactions with VMware on the Condensed Consolidated Statements of Financial Position for the periods indicated:

- changed (2022-12-05):
[0001571996-22-000044:note_history:80]
|  | Classification |  | October 28, 2022 |  | January 28, 2022 |
|  |  |  | (in millions) |
| Deferred costs related to VMware products and services for resale | Other current assets |  | $ | 2,560 |  |  | $ | 2,571 |  |
| Deferred costs related to VMware products and services for resale | Other non-current assets |  | $ | 1,984 |  |  | $ | 2,311 |  |
  (was, 2022-09-01, similarity 0.9824):
[0001571996-22-000031:note_history:80]
|  | Classification |  | July 29, 2022 |  | January 28, 2022 |
|  |  |  | (in millions) |
| Deferred costs related to VMware products and services for resale | Other current assets |  | $ | 2,652 |  |  | $ | 2,571 |  |
| Deferred costs related to VMware products and services for resale | Other non-current assets |  | $ | 2,166 |  |  | $ | 2,311 |  |

- changed (2022-12-05):
[0001571996-22-000044:note_history:81]
|  | October 28, 2022 |  | January 28, 2022 |
|  | (in millions) |
| Due from related party, net, current (a) | $ | 203 |  |  | $ | 131 |  |
| Due from related party, net, non-current (b) | $ | 612 |  |  | $ | 710 |  |
| Due to related party, current (c) | $ | 712 |  |  | $ | 1,414 |  |
  (was, 2022-09-01, similarity 0.978):
[0001571996-22-000031:note_history:81]
|  | July 29, 2022 |  | January 28, 2022 |
|  | (in millions) |
| Due from related party, net, current (a) | $ | 195 |  |  | $ | 131 |  |
| Due from related party, net, non-current (b) | $ | 609 |  |  | $ | 710 |  |
| Due to related party, current (c) | $ | 1,269 |  |  | $ | 1,414 |  |

- changed (2022-12-05):
[0001571996-22-000044:note_history:82]
(a)    Amounts due from related party, net, current consists of amounts due from VMware, inclusive of current net tax receivables from VMware under the Tax Agreements described below.  Amounts, excluding tax, are generally settled in cash within 60 days of each quarter-end.
  (was, 2022-09-01, similarity 0.619):
[0001571996-22-000031:note_history:82]
(a)    Amounts due from related party, current consists of amounts due from VMware, inclusive of current net tax receivables from VMware under the Tax Agreements.  Amounts, excluding tax, are generally settled in cash within 60 days of each quarter-end.

- changed (2022-12-05):
[0001571996-22-000044:note_history:83]
(b)  Amounts due from related party, net, non-current consists of non-current portion of net receivables from VMware under the Tax Agreements.
  (was, 2022-09-01, similarity 0.9819):
[0001571996-22-000031:note_history:83]
(b)  Amounts due from related party, non-current consists of non-current portion of net receivables from VMware under the Tax Agreements.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-12-05):
[0001571996-22-000044:note_history:84]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 28, 2022 |  | October 29, 2021 |  | October 28, 2022 |  | October 29, 2021 |  |  |
|  | (in millions) |
| Net revenue: |  |  |  |  |  |  |  |  |  |
| Infrastructure Solutions Group: |  |  |  |  |  |  |  |  |  |
| Servers and networking | $ | 5,201 |  |  | $ | 4,561 |  |  | $ | 15,458 |  |  | $ | 13,181 |  |  |  |
| Storage | 4,429 |  |  | 4,003 |  |  | 12,993 |  |  | 11,966 |  |  |  |
| Total ISG net revenue | $ | 9,630 |  |  | $ | 8,564 |  |  | $ | 28,451 |  |  | $ | 25,147 |  |  |  |
| Client Solutions Group: |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 10,747 |  |  | $ | 12,300 |  |  | $ | 34,859 |  |  | $ | 32,685 |  |  |  |
| Consumer | 3,028 |  |  | 4,256 |  |  | 9,993 |  |  | 11,450 |  |  |  |
| Total CSG net revenue | $ | 13,775 |  |  | $ | 16,556 |  |  | $ | 44,852 |  |  | $ | 44,135 |  |  |  |
  (was, 2022-09-01, similarity 0.9194):
[0001571996-22-000031:note_history:84]
|  | Three Months Ended |  | Six Months Ended |
|  | July 29, 2022 |  | July 30, 2021 |  | July 29, 2022 |  | July 30, 2021 |  |  |
|  | (in millions) |
| Net revenue: |  |  |  |  |  |  |  |  |  |
| Infrastructure Solutions Group: |  |  |  |  |  |  |  |  |  |
| Servers and networking | $ | 5,209 |  |  | $ | 4,480 |  |  | $ | 10,257 |  |  | $ | 8,620 |  |  |  |
| Storage | 4,327 |  |  | 4,070 |  |  | 8,564 |  |  | 7,963 |  |  |  |
| Total ISG net revenue | $ | 9,536 |  |  | $ | 8,550 |  |  | $ | 18,821 |  |  | $ | 16,583 |  |  |  |
| Client Solutions Group: |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 12,141 |  |  | $ | 10,577 |  |  | $ | 24,112 |  |  | $ | 20,385 |  |  |  |
| Consumer | 3,349 |  |  | 3,691 |  |  | 6,965 |  |  | 7,194 |  |  |  |
| Total CSG net revenue | $ | 15,490 |  |  | $ | 14,268 |  |  | $ | 31,077 |  |  | $ | 27,579 |  |  |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2022-12-05):
[0001571996-22-000044:note_history:85]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 28, 2022 |  | October 29, 2021 |  | October 28, 2022 |  | October 29, 2021 |
|  | (in millions) |
| Deferred revenue: |  |  |  |  |  |  |  |
| Deferred revenue at beginning of period | $ | 28,025 |  |  | $ | 26,668 |  |  | $ | 27,573 |  |  | $ | 25,592 |  |
| Revenue deferrals | 4,128 |  |  | 4,459 |  |  | 14,675 |  |  | 15,048 |  |
| Revenue recognized | (5,064) |  |  | (4,786) |  |  | (14,994) |  |  | (14,155) |  |
| Other (a) | — |  |  | — |  |  | (165) |  |  | (144) |  |
| Deferred revenue at end of period | $ | 27,089 |  |  | $ | 26,341 |  |  | $ | 27,089 |  |  | $ | 26,341 |  |
| Short-term deferred revenue | $ | 14,106 |  |  | $ | 13,426 |  |  | $ | 14,106 |  |  | $ | 13,426 |  |
| Long-term deferred revenue | $ | 12,983 |  |  | $ | 12,915 |  |  | $ | 12,983 |  |  | $ | 12,915 |  |

- added (2022-12-05):
[0001571996-22-000044:note_history:86]
(a)    For the nine months ended October 28, 2022, Other represents the reclassification of deferred revenue to accrued and other liabilities.  For the nine months ended October 29, 2021, Other consists of divested deferred revenue from the sale of Boomi.

- changed (2022-12-05):
[0001571996-22-000044:note_history:87]
Remaining Performance Obligations — Remaining performance obligations represent the aggregate amount of the transaction price allocated to performance obligations not delivered, or partially undelivered, as of the end of the reporting period.  Remaining performance obligations include deferred revenue plus unbilled amounts not yet recorded in deferred revenue.  The value of the transaction price allocated to remaining performance obligations as of October 28, 2022 was approximately $39 billion.  The Company expects to recognize approximately 60% of remaining performance obligations as revenue in the next twelve months, and the remainder thereafter.
  (was, 2022-09-01, similarity 0.9915):
[0001571996-22-000031:note_history:87]
Remaining Performance Obligations — Remaining performance obligations represent the aggregate amount of the transaction price allocated to performance obligations not delivered, or partially undelivered, as of the end of the reporting period.  Remaining performance obligations include deferred revenue plus unbilled amounts not yet recorded in deferred revenue.  The value of the transaction price allocated to remaining performance obligations as of July 29, 2022 was approximately $41 billion.  The Company expects to recognize approximately 61% of remaining performance obligations as revenue in the next twelve months, and the remainder thereafter.

- removed (2022-12-05):
[0001571996-22-000031:note_history:88]
|  | Three Months Ended |  | Six Months Ended |
|  | July 29, 2022 |  | July 30, 2021 |  | July 29, 2022 |  | July 30, 2021 |
|  | (in millions) |
| Deferred revenue: |  |  |  |  |  |  |  |
| Deferred revenue at beginning of period | $ | 27,403 |  |  | $ | 26,282 |  |  | $ | 27,573 |  |  | $ | 25,592 |  |
| Revenue deferrals | 5,572 |  |  | 5,281 |  |  | 10,547 |  |  | 10,560 |  |
| Revenue recognized | (4,950) |  |  | (4,740) |  |  | (9,930) |  |  | (9,329) |  |
| Other (a) | — |  |  | (155) |  |  | (165) |  |  | (155) |  |
| Deferred revenue at end of period | $ | 28,025 |  |  | $ | 26,668 |  |  | $ | 28,025 |  |  | $ | 26,668 |  |
| Short-term deferred revenue | $ | 14,724 |  |  | $ | 13,765 |  |  | $ | 14,724 |  |  | $ | 13,765 |  |
| Long-term deferred revenue | $ | 13,301 |  |  | $ | 12,903 |  |  | $ | 13,301 |  |  | $ | 12,903 |  |

- removed (2022-12-05):
[0001571996-22-000031:note_history:89]
(a)    For the six months ended July 29, 2022, Other represents the reclassification of deferred revenue to accrued and other liabilities.  For the three and six months ended July 30, 2021, Other consists of divested deferred revenue from the sale of Boomi.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2022-12-05):
[0001571996-22-000044:note_history:90]
SUBSEQUENT EVENTS 
Settlement of Class Action Litigation Related to the Class V Transaction

- added (2022-12-05):
[0001571996-22-000044:note_history:91]
Subsequent to October 28, 2022, the plaintiffs and the defendants in the class action litigation related to the Class V transaction described in Note 11 of the Notes to the Condensed Consolidated Financial Statements agreed to settle the action (the “settlement”), subject to approval of the settlement by the Delaware Chancery Court.

- added (2022-12-05):
[0001571996-22-000044:note_history:92]
Under the terms of the settlement, the plaintiffs have agreed to dismissal of all claims upon payment of a total of $1.0 billion (the “settlement amount”), which amount will include all costs, expenses and fees of the plaintiff class relating to the action and its resolution.  The settlement terms provide that it is a condition of the settlement that the settlement amount will be paid by the Company and/or the Company’s insurers on behalf of the defendants pursuant to indemnification obligations of the Company to the defendants.

- added (2022-12-05):
[0001571996-22-000044:note_history:93]
The settlement is further conditioned on the execution of a definitive settlement agreement containing the foregoing terms and customary terms for class action settlements, and final approval of the settlement by the court.

- added (2022-12-05):
[0001571996-22-000044:note_history:94]
If the court does not grant final approval of the settlement and all of its material terms, or the settlement does not otherwise become final or effective, proceedings in the action will continue.

- added (2022-12-05):
[0001571996-22-000044:note_history:95]
The settlement agreement provided additional information surrounding conditions that existed as of October 28, 2022 and, as such, was treated as a recognized subsequent event.  The Company accrues a liability when it believes that it is both probable that a liability has been incurred and that it can reasonably estimate the amount of the loss.  Accordingly, the Company established a $1.0 billion liability on the Condensed Consolidated Statements of Financial Position as of October 28, 2022 and recognized $1.0 billion expense within interest and other, net within the Condensed Consolidated Statements of Income for the three months ended October 28, 2022.

- changed (2022-12-05):
[0001571996-22-000044:note_history:96]
Other than the matter identified above, there were no known events occurring after October 28, 2022 and up until the date of issuance of this report that would materially affect the information presented herein.
  (was, 2022-09-01, similarity 0.863):
[0001571996-22-000031:note_history:96]
SUBSEQUENT EVENTS There were no known events occurring after July 29, 2022 and up until the date of issuance of this report that would materially affect the information presented herein.
