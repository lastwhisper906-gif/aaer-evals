# DELL 8-K — 0001571996-23-000002 filed 2023-03-02

## item codes, every 8-K on or before 2023-03-30

- 2023-03-02 0001571996-23-000002 — 2.02, 5.02, 9.01
- 2023-02-06 0001193125-23-024781 — 7.01, 9.01
- 2023-01-24 0001193125-23-014260 — 1.01, 2.03, 9.01
- 2023-01-11 0001193125-23-006528 — 8.01, 9.01
- 2022-11-21 0001571996-22-000041 — 2.02, 9.01
- 2022-11-16 0001571996-22-000038 — 8.01
- 2022-08-25 0001571996-22-000028 — 2.02, 9.01
- 2022-07-18 0001193125-22-196334 — 2.03, 8.01
- 2022-06-29 0001571996-22-000025 — 3.03, 5.03, 5.07, 8.01, 9.01
- 2022-05-26 0001571996-22-000013 — 2.02, 9.01
- 2022-02-24 0001571996-22-000004 — 2.02, 8.01, 9.01
- 2021-12-20 0001193125-21-362482 — 8.01, 9.01
- 2021-12-15 0001193125-21-357927 — 1.01, 2.03, 9.01
- 2021-12-07 0001193125-21-349218 — 8.01, 9.01
- 2021-11-23 0001571996-21-000060 — 2.02, 9.01
- 2021-11-05 0001571996-21-000057 — 1.02, 2.01, 7.01, 8.01, 9.01 — amendment, the index does not say of what
- 2021-11-01 0001571996-21-000052 — 8.01, 9.01
- 2021-11-01 0001193125-21-315488 — 1.01, 1.02, 2.01, 8.01, 9.01
- 2021-10-21 0001193125-21-304052 — 8.01, 9.01
- 2021-10-19 0001571996-21-000050 — 8.01, 9.01
- 2021-10-07 0001193125-21-294210 — 8.01, 9.01
- 2021-09-30 0001571996-21-000047 — 5.02
- 2021-09-27 0001571996-21-000045 — 8.01
- 2021-09-23 0001193125-21-280190 — 7.01, 8.01, 9.01
- 2021-09-20 0001193125-21-276810 — 7.01, 9.01
- 2021-08-26 0001571996-21-000037 — 2.02, 9.01
- 2021-07-01 0001571996-21-000034 — 3.02
- 2021-06-24 0001571996-21-000031 — 5.07
- 2021-06-24 0001193125-21-197644 — 7.01, 9.01
- 2021-06-16 0001571996-21-000029 — 5.02
- 2021-05-27 0001571996-21-000019 — 2.02, 9.01
- 2021-05-03 0001571996-21-000010 — 8.01, 9.01
- 2021-04-14 0001193125-21-116271 — 1.01, 7.01, 9.01
- 2021-02-25 0001571996-21-000003 — 2.02, 9.01
- 2021-02-18 0001193125-21-047844 — 1.01, 2.03, 9.01
- 2020-11-24 0001571996-20-000048 — 2.02, 9.01
- 2020-08-27 0001571996-20-000041 — 2.02, 9.01
- 2020-07-02 0001571996-20-000037 — 5.07
- 2020-05-28 0001571996-20-000028 — 2.02, 9.01
- 2020-04-09 0001193125-20-102602 — 1.01, 2.03, 9.01
- 2020-04-08 0001571996-20-000021 — 5.02
- 2020-04-03 0001571996-20-000019 — 8.01, 9.01
- 2020-03-26 0001571996-20-000015 — 7.01
- 2020-02-27 0001571996-20-000009 — 2.02, 8.01, 9.01
- 2020-02-18 0001571996-20-000005 — 8.01, 9.01
- 2020-01-09 0001571996-20-000002 — 3.02
- 2020-01-06 0001193125-20-002200 — 3.02
- 2019-12-13 0001193125-19-313947 — 3.02
- 2019-12-10 0001571996-19-000052 — 5.02
- 2019-12-02 0001571996-19-000044 — 5.02, 7.01, 9.01
- 2019-11-26 0001571996-19-000042 — 2.02, 9.01
- 2019-09-23 0001193125-19-252192 — 1.01, 2.03, 9.01
- 2019-08-29 0001571996-19-000036 — 2.02, 9.01
- 2019-08-22 0001193125-19-226939 — 7.01, 8.01, 9.01
- 2019-07-11 0001571996-19-000032 — 5.02, 5.07, 9.01
- 2019-07-03 0001571996-19-000030 — 3.02
- 2019-06-27 0001571996-19-000028 — 3.02
- 2019-05-30 0001571996-19-000021 — 2.02, 9.01
- 2019-04-02 0001571996-19-000010 — 5.02
- 2019-03-21 0001193125-19-082281 — 1.01, 1.02, 2.03, 9.01
- 2019-03-19 0001571996-19-000005 — 5.02, 9.01
- 2019-03-14 0001193125-19-074935 — 1.01, 2.03, 9.01
- 2019-03-07 0001193125-19-066045 — 8.01, 9.01
- 2019-02-28 0001571996-19-000002 — 2.02, 9.01
- 2018-12-28 0001193125-18-360943 — 1.01, 1.02, 3.01, 3.03, 5.02, 5.03, 7.01, 8.01, 9.01
- 2018-12-21 0001193125-18-356324 — 1.01, 2.03, 9.01
- 2018-12-14 0001193125-18-349469 — 8.01
- 2018-12-11 0001193125-18-346958 — 5.07, 8.01, 9.01
- 2018-11-29 0001571996-18-000041 — 2.02, 9.01
- 2018-11-28 0001571996-18-000037 — 7.01, 8.01, 9.01
- 2018-11-26 0001193125-18-333967 — 8.01, 9.01
- 2018-11-15 0001193125-18-328110 — 1.01, 9.01 — amendment of 0001193125-18-327222
- 2018-11-15 0001193125-18-327222 — 1.01, 7.01, 9.01
- 2018-10-03 0001193125-18-291390 — 8.01
- 2018-09-06 0001571996-18-000029 — 2.02, 9.01
- 2018-08-06 0001571996-18-000027 — 8.01, 9.01
- 2018-07-02 0001193125-18-210339 — 1.01, 7.01, 9.01
- 2018-06-28 0001571996-18-000024 — 5.07
- 2018-06-04 0001571996-18-000019 — 2.02, 9.01
- 2018-05-17 0001571996-18-000016 — 7.01
- 2018-04-26 0001571996-18-000009 — 7.01, 9.01
- 2018-03-08 0001193125-18-074168 — 2.02, 9.01
- 2018-02-02 0001193125-18-029947 — 7.01, 9.01
- 2017-12-07 0001571996-17-000042 — 2.02, 9.01
- 2017-10-24 0001571996-17-000037 — 1.01, 2.03, 9.01
- 2017-09-15 0001571996-17-000027 — 5.02
- 2017-09-07 0001571996-17-000017 — 2.02, 9.01
- 2017-08-24 0001571996-17-000014 — 8.01
- 2017-06-29 0001571996-17-000011 — 3.03, 5.07, 8.01, 9.01
- 2017-06-08 0001193125-17-197638 — 2.02, 9.01
- 2017-03-30 0001193125-17-102794 — 8.01
- 2017-03-30 0001193125-17-102777 — 2.02, 9.01
- 2017-03-09 0001193125-17-076981 — 1.01, 2.03, 9.01
- 2017-01-17 0001193125-17-011125 — 8.01
- 2016-12-15 0001193125-16-793722 — 8.01
- 2016-12-08 0001193125-16-787976 — 2.02, 9.01
- 2016-11-10 0001193125-16-765964 — 1.02, 8.01
- 2016-11-04 0001193125-16-760249 — 8.01
- 2016-09-13 0001193125-16-708600 — 3.02
- 2016-09-09 0001193125-16-706567 — 1.01, 1.02, 2.01, 2.03, 3.02, 3.03, 5.02, 9.01
- 2016-09-07 0001193125-16-703370 — 3.03, 5.07, 7.01, 8.01, 9.01
- 2016-09-06 0001193125-16-702057 — 2.02, 9.01
- 2016-08-31 0001193125-16-697268 — 8.01, 9.01
- 2016-08-26 0001193125-16-692921 — 8.01, 9.01
- 2016-07-11 0001193125-16-645610 — 8.01
- 2016-07-05 0001193125-16-641679 — 8.01
- 2016-06-22 0001193125-16-629055 — 1.01, 2.03, 8.01, 9.01
- 2016-06-21 0001193125-16-627071 — 8.01, 9.01
- 2016-06-10 0001193125-16-618483 — 2.02, 9.01
- 2016-06-09 0001193125-16-617893 — 8.01, 9.01

## late-filing notifications on or before 2023-03-30

- none on or before 2023-03-30

## item 2.02 — earnings release, exhibit 99.1

[0001571996-23-000002:8k_2_02:1]
EX-99.1
2
exhibit991earnings8kq4fy23.htm
EX-99.1

[0001571996-23-000002:8k_2_02:2]
Document

[0001571996-23-000002:8k_2_02:3]
Exhibit 99.1

[0001571996-23-000002:8k_2_02:4]
Dell Technologies Delivers Fourth Quarter and Full Year Fiscal 2023 Financial Results

[0001571996-23-000002:8k_2_02:5]
News summary

[0001571996-23-000002:8k_2_02:6]
•Record full-year revenue of $102.3 billion, up 1%, and fourth quarter revenue of $25 billion, down 11%

[0001571996-23-000002:8k_2_02:7]
•Record full-year operating income of $5.8 billion, up 24%, and record non-GAAP operating income of $8.6 billion, up 11%

[0001571996-23-000002:8k_2_02:8]
•Full-year diluted earnings per share at $3.24, and non-GAAP diluted earnings per share at $7.61

[0001571996-23-000002:8k_2_02:9]
•Announcing a 12% increase in annual cash dividend to $1.48 per common share

[0001571996-23-000002:8k_2_02:10]
ROUND ROCK, Texas — March 2, 2023

[0001571996-23-000002:8k_2_02:11]
Full story

[0001571996-23-000002:8k_2_02:12]
Dell Technologies (NYSE: DELL) announces financial results for its fiscal 2023 fourth quarter and full year. Revenue for the year was a record $102.3 billion, up 1% over fiscal year 2022. The company generated record operating income of $5.8 billion, up 24% over the prior year, and record non-GAAP operating income of $8.6 billion, up 11%. For the full year, net income from continuing operations was $2.4 billion and non-GAAP net income was $5.7 billion. Cash flow from operations was $3.6 billion. Full-year diluted earnings per share from continuing operations was $3.24, and non-GAAP diluted earnings per share was $7.61.

[0001571996-23-000002:8k_2_02:13]
Fourth quarter revenue was $25 billion, down 11%. Operating income was $1.2 billion, representing 4.7% of revenue, and non-GAAP operating income was $2.2 billion, representing 8.7% of revenue. Net income from continuing operations for the quarter was $606 million, and non-GAAP net income was $1.3 billion. Cash flow from operations for the quarter was $2.7 billion. Diluted earnings per share from continuing operations was $0.84, and non-GAAP diluted earnings per share was $1.80.

[0001571996-23-000002:8k_2_02:14]
Dell ended the quarter with remaining performance obligations of $40 billion, deferred revenue of $30.3 billion and recurring revenue of approximately $5.6 billion, up 12% year-over-year. Cash and investments were $10.2 billion, and $3.8 billion was returned to shareholders in fiscal year 2023 through share repurchases and dividends. The company will increase its annual cash dividend by 12% to $1.48 per common share, with $0.37 per common share for the first quarterly distribution payable on May 5 to shareholders of record as of April 25.

[0001571996-23-000002:8k_2_02:15]
1

[0001571996-23-000002:8k_2_02:16]
Fourth Quarter and Full Year Fiscal 2023 Financial Results

[0001571996-23-000002:8k_2_02:17]
|  | Three Months Ended |  |  |  | Fiscal Year Ended |  |  |
|  | February 3, 2023 |  | January 28, 2022 |  | Change |  | February 3, 2023 |  | January 28, 2022 |  | Change |
|  | (in millions, except per share amounts and percentages; unaudited) |
| Total net revenue | $ | 25,039 |  |  | $ | 27,992 |  |  | (11)% |  | $ | 102,301 |  |  | $ | 101,197 |  |  | 1% |
| Operating income | $ | 1,189 |  |  | $ | 1,609 |  |  | (26)% |  | $ | 5,771 |  |  | $ | 4,659 |  |  | 24% |
| Net income from continuing operations | $ | 606 |  |  | $ | (29) |  |  | NM |  | $ | 2,422 |  |  | $ | 4,942 |  |  | (51)% |
| Earnings per share - diluted | $ | 0.84 |  |  | $ | (0.04) |  |  | NM |  | $ | 3.24 |  |  | $ | 6.26 |  |  | (48)% |
| Non-GAAP net revenue | $ | 25,039 |  |  | $ | 28,000 |  |  | (11)% |  | $ | 102,301 |  |  | $ | 101,229 |  |  | 1% |
| Non-GAAP operating income | $ | 2,170 |  |  | $ | 2,191 |  |  | (1)% |  | $ | 8,637 |  |  | $ | 7,785 |  |  | 11% |
| Non-GAAP net income | $ | 1,322 |  |  | $ | 1,390 |  |  | (5)% |  | $ | 5,727 |  |  | $ | 4,924 |  |  | 16% |
| Non-GAAP earnings per share - diluted | $ | 1.80 |  |  | $ | 1.72 |  |  | 5% |  | $ | 7.61 |  |  | $ | 6.22 |  |  | 22% |

[0001571996-23-000002:8k_2_02:18]
____________________

[0001571996-23-000002:8k_2_02:19]
Fiscal year 2023 and its fourth quarter had an extra week compared to the prior corresponding periods.

[0001571996-23-000002:8k_2_02:20]
Information about Dell Technologies’ use of non-GAAP financial information is provided under “Non-GAAP Financial Measures” below. All comparisons in this press release are year-over-year unless otherwise noted.

[0001571996-23-000002:8k_2_02:21]
Operating segments summary

[0001571996-23-000002:8k_2_02:22]
Infrastructure Solutions Group delivered record revenue of $38.4 billion for the full year, up 12% versus the prior year, and record operating income of $5 billion, up 35% versus the prior year. Fourth quarter revenue was $9.9 billion, up 7% year-over-year and its eighth consecutive quarter of year-over-year growth. Servers and networking revenue for the fourth quarter was $4.9 billion, up 5%. Storage revenue was a record $5 billion, up 10%. Operating income was a record $1.5 billion, up 40% and approximately 15.6% of Infrastructure Solutions Group revenue.

[0001571996-23-000002:8k_2_02:23]
Client Solutions Group delivered revenue of $58.2 billion for the full year, down 5% versus the prior year, and operating income of $3.8 billion, down 12% versus the prior year. Fourth quarter revenue was $13.4 billion, down 23% year-over-year. Commercial revenue for the fourth quarter was $10.7 billion, down 17%, and Consumer revenue was $2.7 billion, down 40%. Operating income was $671 million, down 42% and approximately 5% of Client Solutions Group revenue.

[0001571996-23-000002:8k_2_02:24]
Key areas of innovation:

[0001571996-23-000002:8k_2_02:25]
•Dell expanded its leading server portfolio with new PowerEdge servers, which improve energy and cost efficiency and make systems more intelligent with up to 2.9x greater AI inferencing across data centers, large-scale public clouds, telecom and edge locations.

[0001571996-23-000002:8k_2_02:26]
•Dell expanded its technology ecosystem and solutions, including Dell Telecom Infrastructure Blocks for Red Hat, to accelerate the adoption of open, cloud-native technologies in the telecommunications industry.

[0001571996-23-000002:8k_2_02:27]
•Dell launched offerings for hybrid work, including:

[0001571996-23-000002:8k_2_02:28]
◦The UltraSharp 6K Monitor with intelligent and secure collaboration, better sharpness and higher contrast as the world’s first 6K resolution monitor with IPS black panel technology.

[0001571996-23-000002:8k_2_02:29]
◦The Dell Premier Collaboration Keyboard, the world’s first keyboard certified by Zoom, with dedicated touch controls to easily manage Zoom calls.

[0001571996-23-000002:8k_2_02:30]
2

[0001571996-23-000002:8k_2_02:31]
Executive Quotes:

[0001571996-23-000002:8k_2_02:32]
•“In FY23, we accelerated our innovation agenda, drove share gains and delivered strong profitability in a challenging environment – resulting in record revenue of $102.3 billion, record operating income and record ISG revenue of $38.4 billion,” said Chuck Whitten, co-chief operating officer, Dell Technologies. “The long-term trends are in our favor, as data increases exponentially and we continue to help customers navigate the complexities of hybrid work, multicloud and edge.”

[0001571996-23-000002:8k_2_02:33]
•“Our end-to-end portfolio is a proven competitive advantage in this changing environment,” said Jeff Clarke, vice chairman and co-chief operating officer, Dell Technologies. “In ISG we had our eighth consecutive quarter of growth in the fourth quarter with revenue of $9.9 billion, record profitability, and record storage revenue of $5 billion. In CSG, we are focusing on the most profitable segments of the PC market to outperform the industry. We are poised to capture growth even as customer spending priorities shift.”

[0001571996-23-000002:8k_2_02:34]
•“We continue to deliver for our customers and meet our capital return commitments by taking a disciplined approach to managing our business,” said Tom Sweet, chief financial officer, Dell Technologies. “We returned approximately $3.8 billion of capital to our shareholders in FY23 and are increasing our annual dividend by 12% in FY24, reflecting our confidence in our long-term business model and ability to generate and grow our cash flow over time.”

[0001571996-23-000002:8k_2_02:35]
Dell Technologies World

[0001571996-23-000002:8k_2_02:36]
Join us May 22 – 25 for Dell Technologies World, the company’s flagship event that brings together the latest trends, technology and thought leaders. During the event, customers and partners will explore the connected ecosystem of IT infrastructure, applications, devices and security along with our Dell APEX and multicloud solutions that give customers greater flexibility to scale IT to meet business needs and transform their ideas into the innovations that shape our future. Register here.

[0001571996-23-000002:8k_2_02:37]
Conference call information

[0001571996-23-000002:8k_2_02:38]
As previously announced, the Company will hold a conference call to discuss its performance and financial guidance on March 2, 2023, at 3:30 p.m. CST. Prior to the start of the conference call, prepared remarks and a presentation containing additional financial and operating information prior to financial guidance may be downloaded from investors.delltechnologies.com. The conference call will be broadcast live over the internet and can be accessed at

[0001571996-23-000002:8k_2_02:39]
https://investors.delltechnologies.com/news-events/upcoming-events

[0001571996-23-000002:8k_2_02:40]
For those unable to listen to the live broadcast, the final remarks and presentation with financial guidance will be available following the broadcast, and an archived version will be available at the same location for one year.

[0001571996-23-000002:8k_2_02:41]
Environmental, Social and Governance (ESG)

[0001571996-23-000002:8k_2_02:42]
Our Environmental, Social and Governance (ESG) efforts focus on driving positive impact for people and our planet while delivering long-term value for our stakeholders. Explore our ESG resources at

[0001571996-23-000002:8k_2_02:43]
https://www.dell.com/en-us/dt/corporate/social-impact/reporting/esg-governance.htm.

[0001571996-23-000002:8k_2_02:44]
About Dell Technologies

[0001571996-23-000002:8k_2_02:45]
Dell Technologies (NYSE:DELL) helps organizations and individuals build their digital future and transform how they work, live and play. The company provides customers with the industry’s broadest and most innovative technology and services portfolio for the data era.

[0001571996-23-000002:8k_2_02:46]
3

[0001571996-23-000002:8k_2_02:47]
Contacts

[0001571996-23-000002:8k_2_02:48]
Investors: Investor_Relations@Dell.com

[0001571996-23-000002:8k_2_02:49]
Media: Media.Relations@Dell.com

[0001571996-23-000002:8k_2_02:50]
# # #

[0001571996-23-000002:8k_2_02:51]
Copyright © 2023 Dell Inc. or its subsidiaries. All Rights Reserved. Dell Technologies, Dell, EMC and Dell EMC are trademarks of Dell Inc. or its subsidiaries. Other trademarks may be trademarks of their respective owners.

[0001571996-23-000002:8k_2_02:52]
Non-GAAP Financial Measures:

[0001571996-23-000002:8k_2_02:53]
This press release presents information about Dell Technologies’ non-GAAP net revenue, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, non-GAAP net income attributable to non-controlling interests, non-GAAP net income attributable to Dell Technologies Inc. - basic, non-GAAP net income attributable to Dell Technologies Inc. - diluted, non-GAAP earnings per share attributable to Dell Technologies Inc. - basic, and non-GAAP earnings per share attributable to Dell Technologies Inc. - diluted, which are non-GAAP financial measures provided as a supplement to the results provided in accordance with generally accepted accounting principles in the United States of America (“GAAP”). A reconciliation of each non-GAAP financial measure to the most directly comparable GAAP financial measure is provided in the attached tables for each of the fiscal periods indicated.

[0001571996-23-000002:8k_2_02:54]
Special Note on Forward-Looking Statements:

[0001571996-23-000002:8k_2_02:55]
Dell Technologies’ results or events in future periods could differ materially from those expressed or implied by these forward-looking statements because of risks, uncertainties, and other factors that include, but are not limited to, the following: risks and uncertainties relating to our spin-off of VMware, Inc., including the potential effects on our business of the transaction; the effects of the COVID-19 pandemic; competitive pressures; Dell Technologies’ reliance on third-party suppliers for products and components, including reliance on single-source or limited-source suppliers; Dell Technologies’ ability to achieve favorable pricing from its vendors; adverse global economic conditions and instability in financial markets; Dell Technologies’ execution of its growth, business and acquisition strategies; the success of Dell Technologies’ cost efficiency measures; Dell Technologies’ ability to manage solutions and products and services transitions in an effective manner; Dell Technologies’ ability to deliver high-quality products, software, and services; cyber attacks or other data security incidents; Dell Technologies’ foreign operations and ability to generate substantial non-U.S. net revenue; Dell Technologies’ product, services, customer, and geographic sales mix, and seasonal sales trends; the performance of Dell Technologies’ sales channel partners; access to the capital markets by Dell Technologies or its customers; material impairment of the value of goodwill or intangible assets; weak economic conditions and the effect of additional regulation on Dell Technologies’ financial services activities; counterparty default risks; the loss by Dell Technologies of any contracts for ISG services and solutions and its ability to perform such contracts at their estimated costs; loss by Dell Technologies of government contracts; Dell Technologies’ ability to develop and protect its proprietary intellectual property or obtain licenses to intellectual property developed by others on commercially reasonable and competitive terms; disruptions in Dell Technologies’ infrastructure; Dell Technologies’ ability to hedge effectively its exposure to fluctuations in foreign currency exchange rates and interest rates; expiration of tax holidays or favorable tax rate structures, or unfavorable outcomes in tax audits and other tax compliance matters; impairment of portfolio investments; unfavorable results of legal proceedings, including the risk associated with final court approval of the recently announced litigation settlement; compliance requirements of changing environmental and safety laws or other laws; the effect of armed hostilities, terrorism, natural disasters, and public health issues; the effect of global climate change and legal, regulatory, or market measures to address climate change; Dell Technologies’ dependence on the services of Michael Dell and key employees; Dell Technologies’ level of indebtedness; the effect of the transition from LIBOR as a reference rate to calculate interest rates under our variable-rate indebtedness; and business and financial factors and legal restrictions affecting continuation of Dell Technologies’ quarterly cash dividend policy and dividend rate.

[0001571996-23-000002:8k_2_02:56]
This list of risks, uncertainties, and other factors is not complete. Dell Technologies discusses some of these matters more fully, as well as certain risk factors that could affect Dell Technologies’ business, financial condition, results of operations, and prospects, in its reports filed with the SEC, including Dell Technologies’ annual report on Form 10-K for the fiscal year ended January 28, 2022, quarterly reports on Form 10-Q, and current reports on Form 8-K. These filings are available for review through the SEC’s website at www.sec.gov. Any or all forward-looking statements Dell Technologies makes may turn out to be wrong and can be affected by inaccurate assumptions Dell Technologies might make or by known or unknown risks, uncertainties and other factors, including those identified in this press release. Accordingly, you should not place undue reliance on the forward-looking statements made in this press release, which speak only as of its date. Dell Technologies does not undertake to update, and expressly disclaims any duty to update, its forward-looking statements, whether as a result of circumstances or events that arise after the date they are made, new information, or otherwise.

[0001571996-23-000002:8k_2_02:57]
4

[0001571996-23-000002:8k_2_02:58]
DELL TECHNOLOGIES INC. FINANCIAL INFORMATION

[0001571996-23-000002:8k_2_02:59]
Basis of Presentation

[0001571996-23-000002:8k_2_02:60]
Spin-Off of VMware, Inc. — On November 1, 2021, Dell Technologies Inc. completed its spin-off of VMware, Inc. (“VMware”) by means of a special stock dividend (the “VMware Spin-off”). In accordance with applicable accounting guidance, the results of VMware, excluding Dell’s resale of VMware offerings, are presented as discontinued operations in the Condensed Consolidated Statements of Income and, as such, have been excluded from both continuing operations and segment results for all periods presented prior to the completion of the spin-off. The Condensed Consolidated Statements of Cash Flows are presented on a consolidated basis for both continuing operations and discontinued operations

[0001571996-23-000002:8k_2_02:61]
5

[0001571996-23-000002:8k_2_02:62]
DELL TECHNOLOGIES INC.

[0001571996-23-000002:8k_2_02:63]
Consolidated Statements of Income and Related Financial Highlights

[0001571996-23-000002:8k_2_02:64]
(in millions, except percentages; unaudited)

[0001571996-23-000002:8k_2_02:65]
|  | Three Months Ended |  |  |  | Fiscal Year Ended |  |  |
|  | February 3, 2023 |  | January 28, 2022 |  | Change |  | February 3, 2023 |  | January 28, 2022 |  | Change |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Products | $ | 19,038 |  | $ | 22,469 |  | (15)% |  | $ | 79,250 |  |  | $ | 79,830 |  |  | (1)% |
| Services | 6,001 |  | 5,523 |  | 9% |  | 23,051 |  |  | 21,367 |  |  | 8% |
| Total net revenue | 25,039 |  | 27,992 |  | (11)% |  | 102,301 |  |  | 101,197 |  |  | 1% |
| Cost of net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Products | 15,748 |  | 19,265 |  | (18)% |  | 66,029 |  |  | 67,224 |  |  | (2)% |
| Services | 3,535 |  | 3,109 |  | 14% |  | 13,586 |  |  | 12,082 |  |  | 12% |
| Total cost of net revenue | 19,283 |  | 22,374 |  | (14)% |  | 79,615 |  |  | 79,306 |  |  | —% |
| Gross margin | 5,756 |  | 5,618 |  | 2% |  | 22,686 |  |  | 21,891 |  |  | 4% |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative | 3,772 |  | 3,398 |  | 11% |  | 14,136 |  |  | 14,655 |  |  | (4)% |
| Research and development | 795 |  | 611 |  | 30% |  | 2,779 |  |  | 2,577 |  |  | 8% |
| Total operating expenses | 4,567 |  | 4,009 |  | 14% |  | 16,915 |  |  | 17,232 |  |  | (2)% |
| Operating income | 1,189 |  | 1,609 |  | (26)% |  | 5,771 |  |  | 4,659 |  |  | 24% |
| Interest and other, net | (266) |  | (1,657) |  | 84% |  | (2,546) |  |  | 1,264 |  |  | (301)% |
| Income before income taxes | 923 |  | (48) |  | NM |  | 3,225 |  |  | 5,923 |  |  | (46)% |
| Income tax expense (benefit) | 317 |  | (19) |  | NM |  | 803 |  |  | 981 |  |  | (18)% |
| Net income from continuing operations | 606 |  | (29) |  | NM |  | 2,422 |  |  | 4,942 |  |  | (51)% |
| Income from discontinued operations, net of income taxes | — |  | 30 |  | (100)% |  | — |  |  | 765 |  |  | (100)% |
| Net income | 606 |  | 1 |  | NM |  | 2,422 |  |  | 5,707 |  |  | (58)% |
| Less: Net loss attributable to non-controlling interests | (8) |  | (1) |  | (700)% |  | (20) |  |  | (6) |  |  | (233)% |
| Less: Net income attributable to non-controlling interests of discontinued operations | — |  | — |  | —% |  | — |  |  | 150 |  |  | (100)% |
| Net income attributable to Dell Technologies Inc. | $ | 614 |  | $ | 2 |  | NM |  | $ | 2,442 |  |  | $ | 5,563 |  |  | (56)% |
| Percentage of Total Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Gross margin | 23.0 | % |  | 20.1 | % |  |  |  | 22.2 | % |  | 21.6 | % |  |  |
| Selling, general, and administrative | 15.1 | % |  | 12.2 | % |  |  |  | 13.9 | % |  | 14.5 | % |  |  |
| Research and development | 3.2 | % |  | 2.2 | % |  |  |  | 2.7 | % |  | 2.5 | % |  |  |
| Operating expenses | 18.3 | % |  | 14.2 | % |  |  |  | 16.6 | % |  | 17.0 | % |  |  |
| Operating income | 4.7 | % |  | 5.7 | % |  |  |  | 5.6 | % |  | 4.6 | % |  |  |
| Income before income taxes | 3.7 | % |  | (0.2) | % |  |  |  | 3.2 | % |  | 5.9 | % |  |  |
| Net income (loss) from continuing operations | 2.4 | % |  | (0.1) | % |  |  |  | 2.4 | % |  | 4.9 | % |  |  |
| Income tax rate | 34.3 | % |  | 39.6 | % |  |  |  | 24.9 | % |  | 16.6 | % |  |  |

[0001571996-23-000002:8k_2_02:66]
Amounts are based on underlying data and may not visually foot due to rounding.

[0001571996-23-000002:8k_2_02:67]
6

[0001571996-23-000002:8k_2_02:68]
DELL TECHNOLOGIES INC.

[0001571996-23-000002:8k_2_02:69]
Consolidated Statements of Financial Position

[0001571996-23-000002:8k_2_02:70]
(in millions; unaudited)

[0001571996-23-000002:8k_2_02:71]
|  | February 3, 2023 |  | January 28, 2022 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 8,607 |  |  | $ | 9,477 |  |
| Accounts receivable, net | 12,482 |  |  | 12,912 |  |
| Due from related party, net | 378 |  |  | 131 |  |
| Short-term financing receivables, net | 5,281 |  |  | 5,089 |  |
| Inventories | 4,776 |  |  | 5,898 |  |
| Other current assets | 10,827 |  |  | 11,526 |  |
| Total current assets | 42,351 |  |  | 45,033 |  |
| Property, plant, and equipment, net | 6,209 |  |  | 5,415 |  |
| Long-term investments | 1,518 |  |  | 1,839 |  |
| Long-term financing receivables, net | 5,638 |  |  | 5,522 |  |
| Goodwill | 19,676 |  |  | 19,770 |  |
| Intangible assets, net | 6,468 |  |  | 7,461 |  |
| Due from related party, net | 440 |  |  | 710 |  |
| Other non-current assets | 7,311 |  |  | 6,985 |  |
| Total assets | $ | 89,611 |  |  | $ | 92,735 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Short-term debt | $ | 6,573 |  |  | $ | 5,823 |  |
| Accounts payable | 18,598 |  |  | 27,143 |  |
| Due to related party | 2,067 |  |  | 1,414 |  |
| Accrued and other | 8,874 |  |  | 7,578 |  |
| Short-term deferred revenue | 15,542 |  |  | 14,261 |  |
| Total current liabilities | 51,654 |  |  | 56,219 |  |
| Long-term debt | 23,015 |  |  | 21,131 |  |
| Long-term deferred revenue | 14,744 |  |  | 13,312 |  |
| Other non-current liabilities | 3,223 |  |  | 3,653 |  |
| Total liabilities | 92,636 |  |  | 94,315 |  |
| Stockholders’ equity (deficit): |  |  |  |
| Total Dell Technologies Inc. stockholders’ equity (deficit) | (3,122) |  |  | (1,685) |  |
| Non-controlling interests | 97 |  |  | 105 |  |
| Total stockholders’ equity (deficit) | (3,025) |  |  | (1,580) |  |
| Total liabilities and stockholders’ equity | $ | 89,611 |  |  | $ | 92,735 |  |

[0001571996-23-000002:8k_2_02:72]
7

[0001571996-23-000002:8k_2_02:73]
DELL TECHNOLOGIES INC.

[0001571996-23-000002:8k_2_02:74]
Consolidated Statements of Cash Flows

[0001571996-23-000002:8k_2_02:75]
(in millions; unaudited)

[0001571996-23-000002:8k_2_02:76]
|  | Three Months Ended |  | Fiscal Year Ended |
|  | February 3, 2023 |  | January 28, 2022 |  | February 3, 2023 |  | January 28, 2022 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |
| Net income | $ | 606 |  |  | $ | 1 |  |  | $ | 2,422 |  |  | $ | 5,707 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: | 2,108 |  |  | 3,092 |  |  | 1,143 |  |  | 4,600 |  |
| Change in cash from operating activities | 2,714 |  |  | 3,093 |  |  | 3,565 |  |  | 10,307 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |
| Purchases of equity and other investments | (7) |  |  | (93) |  |  | (94) |  |  | (256) |  |
| Purchases of held-to-maturity investments | — |  |  | (1) |  |  | (14) |  |  | (158) |  |
| Maturities and sales of equity and other investments | 17 |  |  | 59 |  |  | 116 |  |  | 513 |  |
| Capital expenditures and capitalized software development costs | (759) |  |  | (740) |  |  | (3,003) |  |  | (2,796) |  |
| Acquisition of businesses and assets, net | (70) |  |  | — |  |  | (70) |  |  | (16) |  |
| Divestitures of businesses and assets, net | — |  |  | — |  |  | — |  |  | 3,957 |  |
| Other | 23 |  |  | 28 |  |  | 41 |  |  | 62 |  |
| Change in cash from investing activities | (796) |  |  | (747) |  |  | (3,024) |  |  | 1,306 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |
| Dividends paid by VMware, Inc. to non-controlling interests | — |  |  | (2,240) |  |  | — |  |  | (2,240) |  |
| Proceeds from the issuance of common stock | — |  |  | 8 |  |  | 5 |  |  | 334 |  |
| Repurchases of parent common stock (a) | (182) |  |  | (628) |  |  | (3,272) |  |  | (663) |  |
| Repurchases of subsidiary common stock (a) | (1) |  |  | (1) |  |  | (9) |  |  | (1,175) |  |
| Payments of dividends to stockholders | (236) |  |  | — |  |  | (964) |  |  | — |  |
| Proceeds from debt | 3,700 |  |  | 7,388 |  |  | 12,479 |  |  | 20,425 |  |
| Repayments of debt | (1,746) |  |  | (13,654) |  |  | (9,825) |  |  | (26,723) |  |
| Net transfer of cash, cash equivalents, and restricted cash to VMware, Inc. | — |  |  | (5,052) |  |  | — |  |  | (5,052) |  |
| Debt-related costs and other, net | (22) |  |  | (1,402) |  |  | (39) |  |  | (1,515) |  |
| Change in cash from financing activities | 1,513 |  |  | (15,581) |  |  | (1,625) |  |  | (16,609) |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash | 239 |  |  | (52) |  |  | (104) |  |  | (106) |  |
| Change in cash, cash equivalents, and restricted cash | 3,670 |  |  | (13,287) |  |  | (1,188) |  |  | (5,102) |  |
| Cash, cash equivalents, and restricted cash at beginning of the period, including cash attributable to discontinued operations | 5,224 |  |  | 23,369 |  |  | 10,082 |  |  | 15,184 |  |
| Cash, cash equivalents, and restricted cash from continuing operations | $ | 8,894 |  |  | $ | 10,082 |  |  | $ | 8,894 |  |  | $ | 10,082 |  |

[0001571996-23-000002:8k_2_02:77]
_________________

[0001571996-23-000002:8k_2_02:78]
(a)Common stock repurchases are inclusive of employee tax withholding on stock-based compensation.

[0001571996-23-000002:8k_2_02:79]
8

[0001571996-23-000002:8k_2_02:80]
DELL TECHNOLOGIES INC.

[0001571996-23-000002:8k_2_02:81]
Segment Information

[0001571996-23-000002:8k_2_02:82]
(in millions, except percentages; unaudited; continued on next page)

[0001571996-23-000002:8k_2_02:83]
|  | Three Months Ended |  |  |  | Fiscal Year Ended |  |  |
|  | February 3, 2023 |  | January 28, 2022 |  | Change |  | February 3, 2023 |  | January 28, 2022 |  | Change |
| Infrastructure Solutions Group (ISG): |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Servers and networking | $ | 4,940 |  | $ | 4,720 |  | 5% |  | $ | 20,398 |  | $ | 17,901 |  | 14% |
| Storage | 4,965 |  | 4,499 |  | 10% |  | 17,958 |  | 16,465 |  | 9% |
| Total ISG net revenue | $ | 9,905 |  | $ | 9,219 |  | 7% |  | $ | 38,356 |  | $ | 34,366 |  | 12% |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| ISG operating income | $ | 1,543 |  | $ | 1,102 |  | 40% |  | $ | 5,045 |  | $ | 3,736 |  | 35% |
| % of ISG net revenue | 15.6 | % |  | 12.0 | % |  |  |  | 13.2 | % |  | 10.9 | % |  |  |
| % of total reportable segment operating income | 70 | % |  | 49 | % |  |  |  | 57 | % |  | 46 | % |  |  |
| Client Solutions Group (CSG): |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 10,697 |  | $ | 12,891 |  | (17)% |  | $ | 45,556 |  | $ | 45,576 |  | 0% |
| Consumer | 2,664 |  | 4,438 |  | (40)% |  | 12,657 |  | 15,888 |  | (20)% |
| Total CSG net revenue | $ | 13,361 |  | $ | 17,329 |  | (23)% |  | $ | 58,213 |  | $ | 61,464 |  | (5)% |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| CSG operating income | $ | 671 |  | $ | 1,157 |  | (42)% |  | $ | 3,824 |  | $ | 4,365 |  | (12)% |
| % of CSG net revenue | 5.0 | % |  | 6.7 | % |  |  |  | 6.6 | % |  | 7.1 | % |  |  |
| % of total reportable segment operating income | 30 | % |  | 51 | % |  |  |  | 43 | % |  | 54 | % |  |  |

[0001571996-23-000002:8k_2_02:84]
Amounts are based on underlying data and may not visually foot due to rounding.

[0001571996-23-000002:8k_2_02:85]
9

[0001571996-23-000002:8k_2_02:86]
DELL TECHNOLOGIES INC.

[0001571996-23-000002:8k_2_02:87]
Segment Information

[0001571996-23-000002:8k_2_02:88]
(in millions, except percentages; unaudited; continued)

[0001571996-23-000002:8k_2_02:89]
|  | Three Months Ended |  | Fiscal Year Ended |
|  | February 3, 2023 |  | January 28, 2022 |  | February 3, 2023 |  | January 28, 2022 |
| Reconciliation to consolidated net revenue: |  |  |  |  |  |  |
| Reportable segment net revenue | $ | 23,266 |  |  | $ | 26,548 |  |  | $ | 96,569 |  |  | $ | 95,830 |  |
| Other businesses (a) | 1,770 |  |  | 1,448 |  |  | 5,721 |  |  | 5,388 |  |
| Unallocated transactions (b) | 3 |  |  | 4 |  |  | 11 |  |  | 11 |  |
| Impact of purchase accounting (c) | — |  |  | (8) |  |  | — |  |  | (32) |  |
| Total consolidated net revenue | $ | 25,039 |  |  | $ | 27,992 |  |  | $ | 102,301 |  |  | $ | 101,197 |  |
| Reconciliation to consolidated operating income: |  |  |  |  |  |  |  |
| Reportable segment operating income | $ | 2,214 |  |  | $ | 2,259 |  |  | $ | 8,869 |  |  | $ | 8,101 |  |
| Other businesses (a) | (48) |  |  | (71) |  |  | (240) |  |  | (319) |  |
| Unallocated transactions (b) | 4 |  |  | 3 |  |  | 8 |  |  | 3 |  |
| Impact of purchase accounting (c) | (11) |  |  | (20) |  |  | (44) |  |  | (67) |  |
| Amortization of intangibles | (238) |  |  | (323) |  |  | (970) |  |  | (1,641) |  |
| Transaction-related (income) expenses (d) | (6) |  |  | 22 |  |  | (22) |  |  | (273) |  |
| Stock-based compensation expense (e) | (228) |  |  | (216) |  |  | (931) |  |  | (808) |  |
| Other corporate expenses (f) | (498) |  |  | (45) |  |  | (899) |  |  | (337) |  |
| Total consolidated operating income | $ | 1,189 |  |  | $ | 1,609 |  |  | $ | 5,771 |  |  | $ | 4,659 |  |

[0001571996-23-000002:8k_2_02:90]
_________________

[0001571996-23-000002:8k_2_02:91]
(a)Other businesses consists of: 1) Dell’s resale of standalone VMware, Inc. products and services, “VMware Resale,” 2) Secureworks, and 3) Virtustream, and do not meet the requirements for a reportable segment, either individually or collectively.

[0001571996-23-000002:8k_2_02:92]
(b)Unallocated transactions includes other corporate items that are not allocated to Dell Technologies’ reportable segments.

[0001571996-23-000002:8k_2_02:93]
(c)Impact of purchase accounting includes non-cash purchase accounting adjustments that are primarily related to the EMC merger transaction.

[0001571996-23-000002:8k_2_02:94]
(d)Transaction-related (income) expenses includes acquisition, integration, and divestiture related costs. From time to time, this category also may include transaction-related income related to divestitures of businesses or asset sales.

[0001571996-23-000002:8k_2_02:95]
(e)Stock-based compensation expense consists of equity awards granted based on the estimated fair value of those awards at grant date.

[0001571996-23-000002:8k_2_02:96]
(f)Other corporate expenses includes impairment charges, incentive charges related to equity investments, severance, payroll taxes associated with stock-based compensation, facilities action, and other costs.  During the three months ended February 3, 2023, other corporate expenses includes $367 million of severance expense incurred in connection with the Company’s workforce reduction announced on February 6, 2023.  During the fiscal year ended February 3, 2023, other corporate expenses includes impairment and other costs incurred in connection with exiting the Company’s business in Russia.

[0001571996-23-000002:8k_2_02:97]
SUPPLEMENTAL SELECTED NON-GAAP FINANCIAL MEASURES

[0001571996-23-000002:8k_2_02:98]
These tables present information about the Company’s non-GAAP net revenue, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, non-GAAP net income attributable to Dell Technologies Inc. - basic and diluted, non-GAAP earnings per share attributable to Dell Technologies Inc. - basic, and non-GAAP earnings per share attributable to Dell Technologies Inc. - diluted, which are non-GAAP financial measures provided as a supplement to the results provided in accordance with generally accepted accounting principles in the United States of America (“GAAP”). A detailed discussion of Dell Technologies’ reasons for including these non-GAAP financial measures, the limitations associated with these measures, the items excluded from these measures, and our reason for excluding those items are presented in “Management’s Discussion and Analysis of Financial Condition and Results of Operations — Non-GAAP Financial Measures” in our periodic reports filed with the SEC. Dell Technologies encourages investors to review the non-GAAP discussion in these reports in conjunction with the presentation of non-GAAP financial measures.

[0001571996-23-000002:8k_2_02:99]
11

[0001571996-23-000002:8k_2_02:100]
DELL TECHNOLOGIES INC.

[0001571996-23-000002:8k_2_02:101]
Selected Non-GAAP Financial Measures

[0001571996-23-000002:8k_2_02:102]
(in millions, except per share amounts and percentages; unaudited)

[0001571996-23-000002:8k_2_02:103]
|  | Three Months Ended |  |  |  | Fiscal Year Ended |  |  |
|  | February 3, 2023 |  | January 28, 2022 |  | Change |  | February 3, 2023 |  | January 28, 2022 |  | Change |
| Non-GAAP net revenue | $ | 25,039 |  | $ | 28,000 |  | (11)% |  | $ | 102,301 |  | $ | 101,229 |  | 1% |
| Non-GAAP gross margin | $ | 5,971 |  | $ | 5,818 |  | 3% |  | $ | 23,427 |  | $ | 22,684 |  | 3% |
| % of non-GAAP net revenue | 23.8 | % |  | 20.8 | % |  |  |  | 22.9 | % |  | 22.4 | % |  |  |
| Non-GAAP operating expenses | $ | 3,801 |  | $ | 3,627 |  | 5% |  | $ | 14,790 |  | $ | 14,899 |  | (1)% |
| % of non-GAAP net revenue | 15.1 | % |  | 13.0 | % |  |  |  | 14.5 | % |  | 14.7 | % |  |  |
| Non-GAAP operating income | $ | 2,170 |  | $ | 2,191 |  | (1)% |  | $ | 8,637 |  | $ | 7,785 |  | 11% |
| % of non-GAAP net revenue | 8.7 | % |  | 7.8 | % |  |  |  | 8.4 | % |  | 7.7 | % |  |  |
| Non-GAAP net income | $ | 1,322 |  | $ | 1,390 |  | (5)% |  | $ | 5,727 |  | $ | 4,924 |  | 16% |
| % of non-GAAP net revenue | 5.3 | % |  | 5.0 | % |  |  |  | 5.6 | % |  | 4.9 | % |  |  |
| Non-GAAP earnings per share - diluted | $ | 1.80 |  | $ | 1.72 |  | 5% |  | $ | 7.61 |  | $ | 6.22 |  | 22% |

[0001571996-23-000002:8k_2_02:104]
Amounts are based on underlying data and may not visually foot due to rounding.

[0001571996-23-000002:8k_2_02:105]
DELL TECHNOLOGIES INC.

[0001571996-23-000002:8k_2_02:106]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-23-000002:8k_2_02:107]
(in millions, except percentages; unaudited; continued on next page)

[0001571996-23-000002:8k_2_02:108]
|  | Three Months Ended |  |  |  | Fiscal Year Ended |  |  |
|  | February 3, 2023 |  | January 28, 2022 |  | Change |  | February 3, 2023 |  | January 28, 2022 |  | Change |
| Net revenue | $ | 25,039 |  |  | $ | 27,992 |  |  | (11)% |  | $ | 102,301 |  |  | $ | 101,197 |  |  | 1% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | — |  |  | 8 |  |  |  |  | — |  |  | 32 |  |  |  |
| Non-GAAP net revenue | $ | 25,039 |  |  | $ | 28,000 |  |  | (11)% |  | $ | 102,301 |  |  | $ | 101,229 |  |  | 1% |
| Gross margin | $ | 5,756 |  |  | $ | 5,618 |  |  | 2% |  | $ | 22,686 |  |  | $ | 21,891 |  |  | 4% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 99 |  |  | 150 |  |  |  |  | 414 |  |  | 598 |  |  |  |
| Impact of purchase accounting | — |  |  | 8 |  |  |  |  | 2 |  |  | 35 |  |  |  |
| Stock-based compensation expense | 40 |  |  | 37 |  |  |  |  | 152 |  |  | 133 |  |  |  |
| Other corporate expenses | 76 |  |  | 5 |  |  |  |  | 173 |  |  | 27 |  |  |  |
| Non-GAAP gross margin | $ | 5,971 |  |  | $ | 5,818 |  |  | 3% |  | $ | 23,427 |  |  | $ | 22,684 |  |  | 3% |
| Operating expenses | $ | 4,567 |  |  | $ | 4,009 |  |  | 14% |  | $ | 16,915 |  |  | $ | 17,232 |  |  | (2)% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | (139) |  |  | (173) |  |  |  |  | (556) |  |  | (1,043) |  |  |  |
| Impact of purchase accounting | (11) |  |  | (12) |  |  |  |  | (42) |  |  | (32) |  |  |  |
| Transaction-related (income) expenses | (6) |  |  | 22 |  |  |  |  | (22) |  |  | (273) |  |  |  |
| Stock-based compensation expense | (188) |  |  | (179) |  |  |  |  | (779) |  |  | (675) |  |  |  |
| Other corporate expenses | (422) |  |  | (40) |  |  |  |  | (726) |  |  | (310) |  |  |  |
| Non-GAAP operating expenses | $ | 3,801 |  |  | $ | 3,627 |  |  | 5% |  | $ | 14,790 |  |  | $ | 14,899 |  |  | (1)% |
| Operating income | $ | 1,189 |  |  | $ | 1,609 |  |  | (26)% |  | $ | 5,771 |  |  | $ | 4,659 |  |  | 24% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 238 |  |  | 323 |  |  |  |  | 970 |  |  | 1,641 |  |  |  |
| Impact of purchase accounting | 11 |  |  | 20 |  |  |  |  | 44 |  |  | 67 |  |  |  |
| Transaction-related (income) expenses | 6 |  |  | (22) |  |  |  |  | 22 |  |  | 273 |  |  |  |
| Stock-based compensation expense | 228 |  |  | 216 |  |  |  |  | 931 |  |  | 808 |  |  |  |
| Other corporate expenses | 498 |  |  | 45 |  |  |  |  | 899 |  |  | 337 |  |  |  |
| Non-GAAP operating income | $ | 2,170 |  |  | $ | 2,191 |  |  | (1)% |  | $ | 8,637 |  |  | $ | 7,785 |  |  | 11% |

[0001571996-23-000002:8k_2_02:109]
13

[0001571996-23-000002:8k_2_02:110]
DELL TECHNOLOGIES INC.

[0001571996-23-000002:8k_2_02:111]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-23-000002:8k_2_02:112]
(in millions, except percentages; unaudited; continued)

[0001571996-23-000002:8k_2_02:113]
|  | Three Months Ended |  |  |  | Fiscal Year Ended |  |  |
|  | February 3, 2023 |  | January 28, 2022 |  | Change |  | February 3, 2023 |  | January 28, 2022 |  | Change |
| Net income (loss) from continuing operations | $ | 606 |  |  | $ | (29) |  |  | NM |  | $ | 2,422 |  |  | $ | 4,942 |  |  | (51)% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 238 |  |  | 323 |  |  |  |  | 970 |  |  | 1,641 |  |  |  |
| Impact of purchase accounting | 11 |  |  | 20 |  |  |  |  | 44 |  |  | 67 |  |  |  |
| Transaction-related (income) expenses | (14) |  |  | 1,492 |  |  |  |  | (16) |  |  | (2,143) |  |  |  |
| Stock-based compensation expense | 228 |  |  | 216 |  |  |  |  | 931 |  |  | 808 |  |  |  |
| Other corporate expenses | 392 |  |  | 45 |  |  |  |  | 1,812 |  |  | 337 |  |  |  |
| Fair value adjustments on equity investments | 9 |  |  | (192) |  |  |  |  | 206 |  |  | (572) |  |  |  |
| Aggregate adjustment for income taxes | (148) |  |  | (485) |  |  |  |  | (642) |  |  | (156) |  |  |  |
| Non-GAAP net income | $ | 1,322 |  |  | $ | 1,390 |  |  | (5)% |  | $ | 5,727 |  |  | $ | 4,924 |  |  | 16% |
| Net income (loss) from continuing operations attributable to Dell Technologies Inc. | $ | 614 |  |  | $ | (28) |  |  | NM |  | $ | 2,442 |  |  | $ | 4,948 |  |  | (51)% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 238 |  |  | 323 |  |  |  |  | 970 |  |  | 1,641 |  |  |  |
| Impact of purchase accounting | 11 |  |  | 20 |  |  |  |  | 44 |  |  | 67 |  |  |  |
| Transaction-related (income) expenses | (14) |  |  | 1,492 |  |  |  |  | (16) |  |  | (2,143) |  |  |  |
| Stock-based compensation expense | 228 |  |  | 216 |  |  |  |  | 931 |  |  | 808 |  |  |  |
| Other corporate expenses | 392 |  |  | 45 |  |  |  |  | 1,812 |  |  | 337 |  |  |  |
| Fair value adjustments on equity investments | 9 |  |  | (192) |  |  |  |  | 206 |  |  | (572) |  |  |  |
| Aggregate adjustment for income taxes | (148) |  |  | (485) |  |  |  |  | (642) |  |  | (156) |  |  |  |
| Total non-GAAP adjustments attributable to non-controlling interests | (6) |  |  | (1) |  |  |  |  | (13) |  |  | (7) |  |  |  |
| Non-GAAP net income attributable to Dell Technologies Inc. | $ | 1,324 |  |  | $ | 1,390 |  |  | (5)% |  | $ | 5,734 |  |  | $ | 4,923 |  |  | 16% |

[0001571996-23-000002:8k_2_02:114]
DELL TECHNOLOGIES INC.

[0001571996-23-000002:8k_2_02:115]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-23-000002:8k_2_02:116]
(in millions, except percentages and per share amounts; unaudited; continued)

[0001571996-23-000002:8k_2_02:117]
|  | Three Months Ended |  |  |  | Fiscal Year Ended |  |  |
|  | February 3, 2023 |  | January 28, 2022 |  | Change |  | February 3, 2023 |  | January 28, 2022 |  | Change |
| Earnings per share from continuing operations attributable to Dell Technologies Inc. |  |  |  |  |
| Net income (loss) from continuing operations attributable to Dell Technologies Inc. — basic | $ | 614 |  |  | $ | (28) |  |  |  |  | $ | 2,442 |  |  | $ | 4,948 |  |  |  |
| Weighted-average shares outstanding — basic | 716 |  |  | 763 |  |  |  |  | 734 |  |  | 762 |  |  |  |
| Earnings (loss) per share attributable to Dell Technologies Inc. — basic | $ | 0.86 |  |  | $ | (0.04) |  |  | NM |  | $ | 3.33 |  |  | $ | 6.49 |  |  | (49)% |
| Net income (loss) from continuing operations attributable to Dell Technologies Inc. — diluted | $ | 614 |  |  | $ | (28) |  |  |  |  | $ | 2,442 |  |  | $ | 4,948 |  |  |  |
| Weighted-average shares outstanding — diluted | 735 |  |  | 763 |  |  |  |  | 753 |  |  | 791 |  |  |  |
| Earnings (loss) per share attributable to Dell Technologies Inc. — diluted | $ | 0.84 |  |  | $ | (0.04) |  |  | NM |  | $ | 3.24 |  |  | $ | 6.26 |  |  | (48)% |
| Earnings per share from discontinued operations attributable to Dell Technologies Inc. |  |  |  |  |
| Net income from discontinued operations attributable to Dell Technologies Inc. — basic | $ | — |  |  | $ | 30 |  |  |  |  | $ | — |  |  | $ | 615 |  |  |  |
| Weighted-average shares outstanding — basic | — |  |  | 763 |  |  |  |  | — |  |  | 762 |  |  |  |
| Earnings per share attributable to Dell Technologies Inc. — basic | $ | — |  |  | $ | 0.04 |  |  | NM |  | $ | — |  |  | $ | 0.81 |  |  | NM |
| Incremental dilution from VMware, Inc. attributable to Dell Technologies | — |  |  | — |  |  |  |  | — |  |  | (7) |  |  |  |
| Net income from discontinued operations attributable to Dell Technologies Inc. — diluted | $ | — |  |  | $ | 30 |  |  |  |  | $ | — |  |  | $ | 608 |  |  |  |
| Weighted-average shares outstanding — diluted | — |  |  | 763 |  |  |  |  | — |  |  | 791 |  |  |  |
| Earnings per share attributable to Dell Technologies Inc. — diluted | $ | — |  |  | $ | 0.04 |  |  | NM |  | $ | — |  |  | $ | 0.76 |  |  | NM |
| Non-GAAP earnings per share attributable to Dell Technologies Inc. |  |  |
| Non-GAAP net income attributable to Dell Technologies Inc. — basic | $ | 1,324 |  |  | $ | 1,390 |  |  |  |  | $ | 5,734 |  |  | $ | 4,923 |  |  |  |
| Weighted-average shares outstanding — basic | 716 |  |  | 763 |  |  |  |  | 734 |  |  | 762 |  |  |  |
| Earnings per share attributable to Dell Technologies Inc. — basic | $ | 1.85 |  |  | $ | 1.82 |  |  | 2% |  | $ | 7.81 |  |  | $ | 6.46 |  |  | 21% |
| Non-GAAP net income attributable to Dell Technologies Inc. — diluted | $ | 1,324 |  |  | $ | 1,389 |  |  |  |  | $ | 5,734 |  |  | $ | 4,923 |  |  |  |
| Weighted-average shares outstanding — diluted | 735 |  |  | 810 |  |  |  |  | 753 |  |  | 791 |  |  |  |
| Earnings per share attributable to Dell Technologies Inc. — diluted | $ | 1.80 |  |  | $ | 1.72 |  |  | 5% |  | $ | 7.61 |  |  | $ | 6.22 |  |  | 22% |

[0001571996-23-000002:8k_2_02:118]
Amounts may not visually recalculate due to rounding.

[0001571996-23-000002:8k_2_02:119]
15

## item 5.02 — body, verbatim

[0001571996-23-000002:8k_body:1]
Item 5.02    Departure of Directors or Certain Officers; Election of Directors; Appointment of Certain Officers; Compensatory Arrangements of Certain Officers.

[0001571996-23-000002:8k_body:2]
(b) On February 26, 2023, Thomas W. Sweet, Chief Financial Officer of the Company, notified the Company of his decision to retire from his position as Chief Financial Officer, in which position he served as the Company’s principal financial officer, effective as of August 4, 2023.

[0001571996-23-000002:8k_body:3]
(c) On March 2, 2023, the Board of Directors appointed Yvonne McGill, who currently serves as the Company’s Corporate Controller, as the Company’s Chief Financial Officer, to succeed Mr. Sweet in that position and as the Company’s principal financial officer, effective as of August 5, 2023.

[0001571996-23-000002:8k_body:4]
Ms. McGill, age 56, has served as the Company’s Corporate Controller since February 2020, where she has responsibility for accounting, tax, treasury and investor relations. Previously, Ms. McGill served as Chief Financial Officer and Senior Vice President, Infrastructure Solutions Group, from March 2018 to February 2020, and Senior Vice President, Global Financial Planning and Analysis, from August 2015 to March 2020.  Since joining Dell in 1997, Ms. McGill served in various other finance leadership roles, including heading finance for the Company’s Asia-Pacific, Japan and China region.  Before beginning her service with Dell, Ms. McGill worked at ManTech International Corporation, a company providing technology solutions and services to U.S. intelligence, defense and federal civilian agencies, and Price Waterhouse LLP, a professional services company. Ms. McGill serves on the board of directors of Applied Materials, Inc., an international materials engineering company.

[0001571996-23-000002:8k_body:5]
The spouse of Ms. McGill, Bryan McGill, has been an employee of Dell since 1997. Since the beginning of the fiscal year ended February 3, 2023, the Company paid Mr. McGill total compensation of approximately $400,000, consisting of base salary and cash incentive compensation. Mr. McGill also received benefits generally available to all employees of Dell. The compensation for Mr. McGill was determined in accordance with the Company’s standard employment and compensation practices applicable to employees with similar responsibilities and positions.

[0001571996-23-000002:8k_body:6]
Information referred to in Item 5.02(c)(3) of Form 8-K has not been determined as of the date of this report.
