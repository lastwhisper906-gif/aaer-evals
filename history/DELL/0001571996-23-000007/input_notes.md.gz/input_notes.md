# DELL notes — 0001571996-23-000007


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001571996-23-000007:notes:1]
DOCUMENTS INCORPORATED BY REFERENCE

[0001571996-23-000007:notes:2]
The information required by Part III of this report, to the extent not set forth herein, is incorporated by reference from the registrant’s proxy statement relating to its annual meeting of stockholders to be held in 2023.  The proxy statement will be filed with the Securities and Exchange Commission within 120 days after the end of the fiscal year to which this report relates.


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001571996-23-000007:notes:3]
Basis of Presentation — These Consolidated Financial Statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“GAAP”).

[0001571996-23-000007:notes:4]
The Company’s fiscal year is the 52- or 53-week period ending on the Friday nearest January 31.  The fiscal year ended February 3, 2023 was a 53-week period.  The fiscal years ended January 28, 2022 and January 29, 2021 were 52-week periods.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001571996-23-000007:notes:5]
DESCRIPTION OF BUSINESS AND SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES 
Description of Business — Dell Technologies is a leading global end-to-end technology provider that designs, develops, manufactures, markets, sells, and supports a wide range of comprehensive and integrated solutions, products, and services.  Dell Technologies offerings include servers and networking, storage, cloud solutions, desktops, notebooks, services, software, and third-party software and peripherals.

[0001571996-23-000007:notes:6]
Principles of Consolidation — These Consolidated Financial Statements include the accounts of Dell Technologies and its wholly-owned subsidiaries, as well as the accounts of Secureworks, which, as indicated above, is majority-owned by Dell Technologies, and VMware through the date of the VMware Spin-off.  All intercompany transactions have been eliminated.

[0001571996-23-000007:notes:7]
The Company also consolidates Variable Interest Entities ("VIEs") where it has been determined that the Company is the primary beneficiary of the applicable entities’ operations.  For each VIE, the primary beneficiary is the party that has both the power to direct the activities that most significantly impact the VIE's economic performance and the obligation to absorb losses or the right to receive benefits of the VIE that could potentially be significant to such VIE.  In evaluating whether the Company is the primary beneficiary of each entity, the Company evaluates its power to direct the most significant activities of the VIE by considering the purpose and design of each entity and the risks each entity was designed to create and pass through to its respective variable interest holders.  The Company also evaluates its economic interests in each of the VIEs.  See Note 6 of the Notes to the Consolidated Financial Statements for more information regarding consolidated VIEs.

[0001571996-23-000007:notes:8]
Use of Estimates — The preparation of financial statements in accordance with GAAP requires management to make estimates and assumptions that affect the amounts reported in the Consolidated Financial Statements and the accompanying Notes.   Actual results could differ materially from those estimates.

[0001571996-23-000007:notes:9]
Cash and Cash Equivalents — All highly liquid investments, including credit card receivables due from banks, with original maturities of 90 days or less at date of purchase, are reported at fair value and are considered to be cash equivalents.  All other investments not considered to be cash equivalents are separately categorized as investments.

[0001571996-23-000007:notes:10]
Investments — The Company has strategic investments in equity securities as well as investments in fixed-income debt securities.  All equity and other securities and long-term fixed income debt securities are recorded as long-term investments in the Consolidated Statements of Financial Position.  Short-term fixed income debt securities are recorded as other current assets in the Consolidated Statements of Financial Position.

[0001571996-23-000007:notes:11]
Strategic investments in marketable equity and other securities are recorded at fair value based on quoted prices in active markets.  Strategic investments in non-marketable equity and other securities without readily determinable fair values are recorded at cost, less impairment, and are adjusted for observable price changes.  Fair value measurements and impairments for strategic investments are recognized in interest and other, net in the Consolidated Statements of Income.  In evaluating equity investments without readily determinable fair values for impairment or observable price changes, the Company uses inputs that include pre- and post-money valuations of recent financing events and the impact of those events on its fully diluted ownership percentages, as well as other available information regarding the issuer’s historical and forecasted performance.

[0001571996-23-000007:notes:12]
Fixed-income debt securities are carried at amortized cost.  The Company intends to hold the fixed-income debt securities to maturity.

[0001571996-23-000007:notes:13]
Allowance for Expected Credit Losses — The Company recognizes an allowance for losses on accounts receivable in an amount equal to the current expected credit losses.  The estimation of the allowance is based on an analysis of historical loss experience, current receivables aging, and management’s assessment of current conditions and reasonable and supportable expectation of future conditions, as well as an assessment of specific identifiable customer accounts considered at risk or uncollectible.  The Company assesses collectibility by pooling receivables where similar characteristics exist and evaluates receivables individually when specific customer balances no longer share those risk characteristics and are considered at risk or uncollectible.  The expense associated with the allowance for expected credit losses is recognized in selling, general, and administrative expenses.

[0001571996-23-000007:notes:14]
Accounting for Operating Leases as a Lessee — In its ordinary course of business, the Company enters into leases as a lessee for office buildings, warehouses, employee vehicles, and equipment.  The Company determines if an arrangement is a lease or contains a lease at inception.  The Company’s leases are generally classified as operating leases.  Finance leases are immaterial.  Operating leases result in the recognition of right of use (“ROU”) assets and lease liabilities on the Consolidated Statements of Financial Position.  ROU assets represent the right to use an underlying asset for the lease term and lease liabilities represent the obligation to make lease payments arising from the lease, measured on a discounted basis.  At lease commencement, the lease liability is measured at the present value of the lease payments over the lease term.  The operating lease ROU asset equals the lease liability adjusted for any initial direct costs, prepaid or deferred rent, and lease incentives.  The Company uses the implicit rate when readily determinable.  As most of the leases do not provide an implicit rate, the Company uses its incremental borrowing rate based on the information available at the commencement date to determine the present value of lease payments.

[0001571996-23-000007:notes:15]
The lease term may include options to extend or to terminate the lease that the Company is reasonably certain to exercise.  The Company has elected not to record leases with an initial term of 12 months or less on the Consolidated Statements of Financial Position.  Lease expense is recognized on a straight-line basis over the lease term in most instances.  The Company does not generate material sublease income and has no material related party leases.  The Company’s lease agreements do not contain any material residual value guarantees or material restrictive covenants.

[0001571996-23-000007:notes:16]
The Company’s office building agreements contain costs such as common area maintenance and other executory costs that may be either fixed or variable in nature.  Variable lease costs are expensed as incurred.  The Company combines lease and non-lease components, including fixed common area and other maintenance costs, in calculating the ROU assets and lease liabilities for its office buildings and employee vehicles.  Under certain service agreements with third-party logistics providers, the Company directs the use of the inventory within the warehouses and, therefore, controls the assets.  The warehouses and some of the equipment used are considered embedded leases.  The Company accounts for the lease and non-lease components separately.  The lease components consist of the warehouses and some of the equipment, such as conveyor belts.  The non-lease components consist of services and other shared equipment, such as material handling and transportation.  The Company allocates the consideration to the lease and non-lease components using their relative standalone values.  See Note 7 of the Notes to the Consolidated Financial Statements for additional information.

[0001571996-23-000007:notes:17]
Accounting for Leases as a Lessor — The Company’s wholly-owned subsidiary Dell Financial Services and its affiliates (“DFS”) act as a lessor to provide equipment financing to customers through a variety of lease arrangements (“DFS leases”).  The Company’s leases are classified as sales-type leases, direct financing leases, or operating leases.  Direct financing leases are immaterial.

[0001571996-23-000007:notes:18]
The Company also offers alternative payment structures and as-a-Service offerings that are assessed to determine whether an embedded lease arrangement exists.  The Company accounts for those contracts as a lease arrangement if it is determined that the contract contains an identified asset and that control of that asset has transferred to the customer.

[0001571996-23-000007:notes:19]
When a contract includes lease and non-lease components, the Company allocates consideration under the contract to each component based on relative standalone selling price and subsequently assesses lease classification for each lease component within a contract.  DFS provides lessees with the option to extend the lease or purchase the underlying asset at the end of the lease term, which is considered when evaluating lease classification.  In general, DFS’s lease arrangements do not have variable payment terms and are typically non-cancelable.

[0001571996-23-000007:notes:20]
On commencement of sales-type leases, the Company recognizes profit up-front, and amounts due from the customer under the lease contract are recognized as financing receivables on the Consolidated Statements of Financial Position.  Interest income is recognized as net product revenue over the term of the lease based on the effective interest method.  The Company has elected not to include sales and other taxes collected from the lessee as part of lease revenue.

[0001571996-23-000007:notes:21]
All other leases that do not meet the definition of a sales-type lease or direct financing lease are classified as operating leases.  The underlying asset in an operating lease arrangement is carried at depreciated cost as “Equipment under operating leases” within Property, plant, and equipment, net on the Consolidated Statements of Financial Position.  Depreciation is calculated using the straight-line method over the term of the underlying lease contract and is recognized as cost of net revenue.  The depreciable basis is the original cost of the equipment less the estimated residual value of the equipment at the end of the lease term.  The residual value is based upon estimates of the value of the equipment at the end of the lease term using historical studies, industry data, and future value-at-risk demand valuation methods.  The Company recognizes operating lease income to product revenue generally on a straight-line basis over the lease term and expenses deferred initial direct costs on the same basis.  The Company recognizes variable lease income to product revenue generally as earned.  Impairment of equipment under operating leases is assessed on the same basis as other long-lived assets.

[0001571996-23-000007:notes:22]
Accounting for Fixed-Term Loans — On commencement of fixed-term loans, the Company may recognize profit up-front or over time depending on the product or service offering, and amounts due from the customer under the loan agreement are recognized as financing receivables on the Consolidated Statements of Financial Position.  The Company generally recognizes interest income to product revenue based on the effective interest method and expenses deferred initial direct costs on a straight-line basis over the loan term.

[0001571996-23-000007:notes:23]
Financing Receivables — Financing receivables are presented net of allowance for losses and consist of customer receivables and residual interest.  Gross customer receivables include amounts due from customers under revolving loans, fixed-term loans, fixed-term sales-type or direct financing leases, and accrued interest.  The Company has two portfolios, consisting of (i) fixed-term leases and loans and (ii) revolving loans, and assesses risk at the portfolio level to determine the appropriate allowance levels.  The portfolio segments are further segregated into classes based on products, customer type, and credit risk evaluation: (i) Revolving — Dell Preferred Account (“DPA”); (ii) Revolving — Dell Business Credit (“DBC”); and (iii) Fixed-term — Consumer and Commercial.  Fixed-term leases and loans are offered to qualified small and medium-sized businesses, large commercial accounts, governmental organizations, and educational entities.  Fixed-term loans are also offered to qualified individual consumers.  Revolving loans are offered under private label credit financing programs.  The DPA revolving loan programs are primarily offered to individual consumers and the DBC revolving loan programs are primarily offered to small and medium-sized business customers.

[0001571996-23-000007:notes:24]
The Company retains a residual interest in equipment leased under its fixed-term lease programs.  The amount of the residual interest is established at the inception of the lease based upon estimates of the value of the equipment at the end of the lease term using historical studies, industry data, and future value-at-risk demand valuation methods.

[0001571996-23-000007:notes:25]
Allowance for Financing Receivables Losses — The Company recognizes an allowance for financing receivable losses, including both the lease receivable and unguaranteed residual, in an amount equal to the expected losses net of recoveries.  The allowance for financing receivable losses on the lease receivable is determined based on various factors, including lifetime expected losses determined using macroeconomic forecast assumptions and management judgments applicable to and through the expected life of the portfolios as well as past due receivables, receivable type, and customer risk profile.  Both fixed and revolving financing receivable loss rates are affected by macroeconomic conditions, including the level of gross domestic product (“GDP”) growth, the level of commercial capital equipment investment, unemployment rates, and the credit quality of the borrower.

[0001571996-23-000007:notes:26]
Generally, expected credit losses as a result of residual value risk on equipment under lease are not considered to be significant primarily because of the existence of a secondary market with respect to the equipment.  The Company’s lease agreements also generally define applicable return conditions and remedies for non-compliance to ensure that the leased equipment will be in good operating condition upon return.  Model changes and updates, as well as market strength and product acceptance, are monitored and adjustments are made to residual values in accordance with the significance of any such changes.

[0001571996-23-000007:notes:27]
When an account is deemed to be uncollectible, customer account principal and interest are charged off to the allowance for losses.  While the Company does not generally place financing receivables on non-accrual status during the delinquency period, accrued interest is included in the allowance for loss calculation and, therefore, the Company is adequately reserved in the event of charge off.  Recoveries on receivables previously charged off as uncollectible are recorded to the allowance for financing receivables losses.  The expense associated with the allowance for financing receivables losses is recognized as cost of net revenue.

[0001571996-23-000007:notes:28]
Asset Securitization — The Company transfers certain U.S. and European customer loan and lease payments and associated equipment to Special Purpose Entities (“SPEs”) that meet the definition of a Variable Interest Entity (“VIE”) and are consolidated into the Consolidated Financial Statements.  These SPEs are bankruptcy-remote legal entities with separate assets and liabilities.  The purpose of the SPEs is to facilitate the funding of customer loan and lease payments and associated equipment in the capital markets.  Some of these SPEs have entered into financing arrangements with multi-seller conduits that, in turn, issue asset-backed debt securities in the capital markets.  The asset securitizations in the SPEs are accounted for as secured borrowings.

[0001571996-23-000007:notes:29]
Inventories — The Company generally records inventory on the Consolidated Statements of Financial Position when legal title and risk of loss has passed to the Company for items that are held for sale in the ordinary course of business, that are in process of production for sale, or that will be consumed in the production of goods or services that will be held for sale.  Inventories are stated at the lower of cost or net realizable value, with cost being determined on a first-in, first-out basis.  Adjustments to reduce the cost of inventory to its net realizable value are made, if required, for estimated excess, obsolescence, or impaired balances.  At the point of the loss recognition, a new, lower cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in the newly established cost basis.

[0001571996-23-000007:notes:30]
Property, Plant, and Equipment — Property, plant, and equipment are carried at depreciated cost.  Depreciation is determined using the straight-line method over the shorter of the estimated useful lives of the assets or the lease term, as applicable.  The estimated useful lives of the Company’s property, plant, and equipment are generally as follows:

[0001571996-23-000007:notes:31]
|  | Estimated Useful Life |
| Computer equipment | 3-5 years |
| Equipment under operating leases | Term of underlying lease contract |
| Buildings and building improvements | 10-30 years or term of underlying land lease |
| Leasehold improvements | 5 years or contract term |
| Machinery and equipment | 3-5 years |

[0001571996-23-000007:notes:32]
Gains or losses related to retirements or dispositions of fixed assets are recognized in the period during which the retirement or disposition occurs.

[0001571996-23-000007:notes:33]
Capitalized Software Development Costs — Software development costs related to the development of new product offerings are capitalized subsequent to the establishment of technological feasibility, which is demonstrated by the completion of a detailed program design or working model, if no program design is completed.  The Company amortizes capitalized costs on a straight-line basis over the estimated useful lives of the products, which generally range from two to four years.

[0001571996-23-000007:notes:34]
As of February 3, 2023 and January 28, 2022, capitalized software development costs were $673 million and $672 million, respectively, and are included in other non-current assets, net in the accompanying Consolidated Statements of Financial Position.  Amortization expense for the fiscal years ended February 3, 2023, January 28, 2022, and January 29, 2021 was $317 million, $263 million, and $315 million, respectively.

[0001571996-23-000007:notes:35]
The Company capitalizes certain internal and external costs to acquire or create internal use software which are incurred subsequent to the completion of the preliminary project stage.  Development costs are generally amortized on a straight-line basis over five years.  Costs associated with maintenance and minor enhancements to the features and functionality of the Company’s internal use software are expensed as incurred.

[0001571996-23-000007:notes:36]
Impairment of Long-Lived Assets — The Company reviews long-lived assets for impairment when events or changes in circumstances indicate the carrying amount of an asset may not be recoverable.  The Company assesses the recoverability of the assets based on the undiscounted future cash flows expected from the use and eventual disposition of the asset.  If the carrying amount of the asset is determined not to be recoverable, a write-down to fair value is recorded.  Fair values are determined based on quoted market values, discounted cash flows, or external appraisals, as applicable.  Long-lived assets to be disposed of are reported at the lower of carrying amount or fair value less costs to sell.

[0001571996-23-000007:notes:37]
Intangible Assets Including Goodwill — Identifiable intangible assets with finite lives are amortized over their estimated useful lives.  Indefinite-lived intangible assets are not amortized.  Definite-lived intangible assets are reviewed for impairment when

[0001571996-23-000007:notes:38]
events and circumstances indicate the asset may be impaired.  Goodwill and indefinite-lived intangible assets are tested for impairment annually during the third fiscal quarter and whenever events or circumstances indicate that an impairment may have occurred.

[0001571996-23-000007:notes:39]
Foreign Currency Translation — The majority of the Company’s international sales are made by international subsidiaries, some of which have the U.S. Dollar as their functional currency.  The Company’s subsidiaries that do not use the U.S. Dollar as their functional currency translate assets and liabilities at current exchange rates in effect at the balance sheet date.  Revenue and expenses from these international subsidiaries are translated using either the monthly average exchange rates in effect for the period in which the activity was recognized or the specific daily exchange rate associated with the date the transactions actually occur.  Foreign currency translation adjustments are included as a component of accumulated other comprehensive income (loss) (“AOCI”) in stockholders’ equity (deficit).

[0001571996-23-000007:notes:40]
Local currency transactions of international subsidiaries that have the U.S. Dollar as their functional currency are remeasured into U.S. Dollars using the current rates of exchange for monetary assets and liabilities and historical rates of exchange for nonmonetary assets and liabilities.  Gains and losses from remeasurement of monetary assets and liabilities are included in interest and other, net on the Consolidated Statements of Income.  See Note 20 of the Notes to the Consolidated Financial Statements for amounts recognized from remeasurement during the periods presented.

[0001571996-23-000007:notes:41]
Hedging Instruments — The Company uses derivative financial instruments, primarily forward contracts, options, and swaps, to hedge certain foreign currency and interest rate exposures.  The relationships between hedging instruments and hedged items, as well as the risk management objectives and strategies for undertaking hedge transactions, are formally documented.  The Company does not use derivatives for speculative purposes.  All derivative instruments are recognized as either assets or liabilities in the Consolidated Statements of Financial Position and are measured at fair value.  The Company’s hedge portfolio includes non-designated derivatives and derivatives designated as cash flow hedges and, from time to time, fair value hedges.

[0001571996-23-000007:notes:42]
For derivative instruments designated as a cash flow hedge, the Company assesses hedge effectiveness at the onset of the hedge, then performs qualitative assessments at regular intervals throughout the life of the derivative.  The gain or loss on the hedge is recorded in AOCI, as a separate component of stockholders’ equity (deficit), and reclassified into earnings in the period during which the hedged transaction is recognized in earnings.  For derivatives that are designated as a fair value hedge, the Company evaluates the effectiveness of the qualifying fair value hedge using the shortcut method of accounting under which hedges are assumed to be perfectly effective.  The change in fair value of the hedge exactly offsets the fair value of the hedged item and there is no net impact recognized in earnings from the fair value of the derivative.  For derivatives that are not designated as hedges or do not qualify for hedge accounting treatment, the Company recognizes the change in the instrument’s fair value in earnings as a component of interest and other, net.

[0001571996-23-000007:notes:43]
Cash flows from derivative instruments are presented in the same category on the Consolidated Statements of Cash Flows as the cash flows from the underlying hedged items.  See Note 9 of the Notes to the Consolidated Financial Statements for a description of the Company’s derivative financial instrument activities.

[0001571996-23-000007:notes:44]
Revenue Recognition — The Company sells a wide portfolio of products and services to its customers.  The Company’s agreements have varying requirements depending on the goods and services being sold, the rights and obligations conveyed, and the legal jurisdiction of the arrangement.

[0001571996-23-000007:notes:45]
Revenue is recognized for these arrangements based on the following five steps:

[0001571996-23-000007:notes:46]
(1)    Identify the contract with a customer.  The Company evaluates facts and circumstances regarding sales transactions in order to identify contracts with its customers.  An agreement must meet all of the following criteria to qualify as a contract eligible for revenue recognition under the model:  (i) the contract must be approved by all parties who are committed to perform their respective obligations; (ii) each party’s rights regarding the goods and services to be transferred to the customer can be identified; (iii) the payment terms for the goods and services can be identified; (iv) the customer has the ability and intent to pay and it is probable that the Company will collect substantially all of the consideration to which it will be entitled; and (v) the contract must have commercial substance.  Judgment is used in determining the customer’s ability and intent to pay, which is based upon various factors, including the customer’s historical payment experience or customer credit and financial information.

[0001571996-23-000007:notes:47]
(2)    Identify the performance obligations in the contract.  The Company’s contracts with customers often include the promise to transfer multiple goods and services to the customer.  Distinct promises within a contract are referred to as “performance obligations” and are accounted for as separate units of account.  The Company assesses whether each promised good or service is distinct for the purpose of identifying the performance obligations in the contract.  This assessment involves subjective determinations and requires management to make judgments about the individual promised goods or services and whether such goods or services are separable from the other aspects of the contractual relationship.  Promised goods and services are considered distinct provided that: (i) the customer can benefit from the good or service either on its own or together with other resources that are readily available to the customer (that is, the good or service is capable of being distinct); and (ii) the Company’s promise to transfer the good or service to the customer is separately identifiable from other promises in the contract (that is, the promise to transfer the good or service is distinct within the context of the contract).  The Company’s performance obligations include various distinct goods and services such as hardware, software licenses, support and maintenance agreements, and other service offerings and solutions.  Promised goods and services are explicitly identified in the Company’s contracts and may be sold on a standalone basis or bundled as part of a combined solution.  In certain hardware solutions, the hardware is highly interdependent on, and interrelated with, the embedded software.  In these offerings, the hardware and software licenses are accounted for as a single performance obligation.

[0001571996-23-000007:notes:48]
(3)    Determine the transaction price.  The transaction price reflects the amount of consideration to which the Company expects to be entitled in exchange for transferring goods or services to the customer.  If the consideration promised in a contract includes a variable amount, the Company estimates the amount to which it expects to be entitled using either the expected value or most likely amount method.  Generally, volume discounts, rebates, and sales returns reduce the transaction price.  In determining the transaction price, the Company only includes amounts that are not subject to significant future reversal.

[0001571996-23-000007:notes:49]
(4)    Allocate the transaction price to performance obligations in the contract.  When a contract includes multiple performance obligations, the transaction price is allocated to each performance obligation in an amount that depicts the consideration to which the Company expects to be entitled in exchange for transferring the promised goods or services.  For contracts with multiple performance obligations, the transaction price is allocated in proportion to the standalone selling price (“SSP”) of each performance obligation.

[0001571996-23-000007:notes:50]
The best evidence of SSP is the observable price of a good or service when the Company sells that good or service separately in similar circumstances to similar customers.  If a directly observable price is available, the Company will utilize that price for the SSP.  If a directly observable price is not available, the SSP must be estimated.  The Company estimates SSP by considering multiple factors, including, but not limited to, pricing practices, internal costs, and profit objectives as well as overall market conditions, which include geographic or regional specific factors, competitive positioning, and competitor actions.

[0001571996-23-000007:notes:51]
(5)    Recognize revenue when (or as) the performance obligation is satisfied.  Revenue is recognized when obligations under the terms of the contract with the Company’s customer are satisfied.  Revenue is recognized either over time or at a point in time, depending on when the underlying products or services are transferred to the customer.  Revenue is recognized at a point in time for products upon transfer of control.  Revenue is recognized over time for support and deployment services, software support, Software-as-a-Service (“SaaS”), and Infrastructure-as-a-Service (“IaaS”).  Revenue is recognized either over time or at a point in time for professional services and training depending on the nature of the offering to the customer.

[0001571996-23-000007:notes:52]
The Company reports revenue net of any revenue-based taxes assessed by governmental authorities that are imposed on and concurrently with specific revenue-producing transactions.

[0001571996-23-000007:notes:53]
The Company has elected the following practical expedients:

[0001571996-23-000007:notes:54]
•The Company does not account for significant financing components if the period between revenue recognition and when the customer pays for the product or service will be one year or less.

[0001571996-23-000007:notes:55]
•The Company recognizes revenue equal to the amount it has a right to invoice when the amount corresponds directly with the value to the customer of the Company’s performance to date.

[0001571996-23-000007:notes:56]
•The Company does not account for shipping and handling activities as a separate performance obligation, but rather as an activity performed to transfer the promised good.

[0001571996-23-000007:notes:57]
The following summarizes the nature of revenue recognized and the manner in which the Company accounts for sales transactions.

[0001571996-23-000007:notes:58]
Products

[0001571996-23-000007:notes:59]
Product revenue consists of revenue from sales of hardware products, including notebooks and desktop PCs, servers, storage hardware, and other hardware-related devices, as well as revenue from software license sales, including non-essential software applications and third-party software licenses.

[0001571996-23-000007:notes:60]
Revenue from sales of hardware products is recognized when control has transferred to the customer, which typically occurs when the hardware has been shipped to the customer, risk of loss has transferred to the customer, the Company has a present right to payment, and customer acceptance has been satisfied.  Customer acceptance is satisfied if acceptance is obtained from the customer, if all acceptance provisions lapse, or if the Company has evidence that all acceptance provisions will be, or have been, satisfied.  Revenue from software license sales is generally recognized when control has transferred to the customer, which is typically upon shipment, electronic delivery, or when the software is available for download by the customer.  For certain software arrangements in which the customer is granted a right to additional unspecified future software licenses, the Company’s promise to the customer is considered a stand-ready obligation in which the transfer of control and revenue recognition will occur over time.

[0001571996-23-000007:notes:61]
Services

[0001571996-23-000007:notes:62]
Services revenue consists of revenue from sales of support services, including hardware support that extends beyond the Company’s standard warranties, software maintenance, and installation; professional services; training; SaaS; and IaaS.  Revenue associated with undelivered performance obligations is deferred and recognized when or as control is transferred to the customer.  Revenue from fixed-price support or maintenance contracts sold for both hardware and software is recognized on a straight-line basis over the period of performance because the Company is required to provide services at any given time.  Other services revenue is recognized when the Company performs the services and the customer receives and consumes the benefits.

[0001571996-23-000007:notes:63]
Other

[0001571996-23-000007:notes:64]
Revenue from leasing arrangements is not subject to the revenue standard for contracts with customers and remains separately accounted for under lease accounting guidance.  The Company records operating lease rental revenue as product revenue on a straight-line basis over the lease term.  The Company records revenue under sales-type leases as product revenue in an amount equal to the present value of minimum lease payments at the inception of the lease.  Sales-type leases also produce financing income, which is included in product net revenue in the Consolidated Statements of Income and is recognized at effective rates of return over the lease term.  The Company also offers qualified customers fixed-term loans and revolving credit lines for the purchase of products and services offered by the Company.  Financing income attributable to these loans is recognized in product net revenue on an accrual basis.

[0001571996-23-000007:notes:65]
Principal versus Agent — For transactions that involve a third party, the Company evaluates whether it is acting as the principal or the agent in the transaction.  This determination requires significant judgement and impacts the amount and timing of revenue recognized.  If the Company determines that it controls a good or service before it is transferred to the customer, the Company is acting as the principal and recognizes revenue at the gross amount of consideration it is entitled to from the customer.  Indicators that the Company controls a good or service before transferring to a customer include, but are not limited to, the Company being the primary obligor to the customer, establishing its own pricing, and having inventory and credit risks.  Conversely, if the Company determines that it does not control the good or service before it is transferred to the customer, the Company is acting as an agent in the transaction.  As an agent, the Company is arranging for the good or service to be provided by another party and recognizes revenue at the net amount of consideration retained.

[0001571996-23-000007:notes:66]
Disaggregation of Revenue — The Company’s revenue is presented on a disaggregated basis on the Consolidated Statements of Income and in Note 19 of the Notes to the Consolidated Financial Statements based on an evaluation of disclosures outside of the financial statements, information regularly reviewed by the chief operating decision maker for evaluating the financial performance of operating segments, and other information that is used to evaluate the Company’s financial performance or make resource allocations.  This information includes revenue from products and services, revenue from reportable segments, and revenue by major product categories within the segments.

[0001571996-23-000007:notes:67]
Contract Assets — Contract assets are rights to consideration in exchange for goods or services that the Company has transferred to a customer when such a right is conditional on something other than the passage of time.  Such amounts have been insignificant to date.

[0001571996-23-000007:notes:68]
Contract Liabilities — Contract liabilities primarily consist of deferred revenue.  Deferred revenue is recorded when the Company has invoiced or payments have been received for undelivered products or services, or in situations where revenue recognition criteria have not been met.  Deferred revenue primarily includes amounts received in advance for extended warranty services and software maintenance.  Revenue is recognized on these items when the revenue recognition criteria are met, generally resulting in ratable recognition over the contract term.  The Company also has deferred revenue related to undelivered hardware and professional services, consisting of installations and consulting engagements, which are recognized when the Company’s performance obligations under the contract are completed.  See Note 11 of the Notes to the Consolidated Financial Statements for additional information about deferred revenue.

[0001571996-23-000007:notes:69]
Deferred Costs — Deferred costs primarily consist of costs incurred to fulfill revenue-generating contracts mainly associated with VMware Resale discussed in Note 21 of the Notes to the Consolidated Financial Statements and third-party software support and maintenance.  The Company defers these charges in line with the deferred revenue associated with the contract to obtain the appropriate expense recognition timing.  These costs are typically amortized on a straight-line basis over the life of the contract or the average contract duration.

[0001571996-23-000007:notes:70]
Costs to Obtain a Contract — The Company capitalizes incremental direct costs to obtain a contract, primarily sales commissions and employer taxes related to commission payments, if the costs are deemed to be recoverable.  The Company has elected, as a practical expedient, to expense as incurred costs to obtain a contract equal to or less than one year in duration.  Capitalized costs are deferred and amortized over the period of contract performance or the estimated life of the customer relationship, if renewals are expected, and are typically amortized over an average period of three to five years.  Amortization expense is recognized on a straight-line basis and included in selling, general, and administrative expenses in the Consolidated Statements of Income.

[0001571996-23-000007:notes:71]
The Company periodically reviews these deferred costs to determine whether events or changes in circumstances have occurred that could impact the carrying value or period of benefit of the deferred sales commissions.  There were no material impairment losses for deferred costs to obtain a contract during the fiscal years ended February 3, 2023, January 28, 2022, and January 29, 2021.

[0001571996-23-000007:notes:72]
Deferred costs to obtain a contract as of February 3, 2023 and January 28, 2022 were $726 million and $734 million, respectively.  Deferred costs to obtain a contract are classified as current assets and other non-current assets on the Consolidated Statements of Financial Position, based on when the expense is expected to be recognized.  Amortization of costs to obtain a contract during the fiscal years ended February 3, 2023, January 28, 2022, and January 29, 2021 was $390 million, $380 million, and $385 million, respectively.

[0001571996-23-000007:notes:73]
Standard Warranty Liabilities — The Company records warranty liabilities for estimated costs of fulfilling its obligations under standard limited hardware and software warranties at the time of sale.  The liabilities for standard warranties are included in accrued and other current and other non-current liabilities in the Consolidated Statements of Financial Position.  The specific warranty terms and conditions vary depending upon the product sold and the country in which the Company does business, but generally includes technical support, parts, and labor over a period ranging from one to three years.  Factors that affect the Company’s warranty liabilities include the number of installed units currently under warranty, historical and anticipated rates of warranty claims on those units, and cost per claim to satisfy the Company’s warranty obligation.  The anticipated rate of warranty claims is the primary factor impacting the estimated warranty obligation.  The other factors are less significant due to the fact that the average remaining aggregate warranty period of the covered installed base is approximately 18 months, repair parts are generally already in stock or available at pre-determined prices, and labor rates are generally arranged at

[0001571996-23-000007:notes:74]
preestablished amounts with service providers.  Warranty claims are relatively predictable based on historical experience of failure rates.  If actual results differ from the estimates, the Company revises its estimated warranty liability.  Each quarter, the Company reevaluates its estimates to assess the adequacy of its recorded warranty liabilities and adjusts the amounts as necessary.

[0001571996-23-000007:notes:75]
Vendor Rebates — The Company may receive consideration from vendors in the normal course of business.  Certain of these funds are rebates of purchase price paid and others are related to reimbursement of costs incurred by the Company to sell the vendor’s products.  The Company recognizes a reduction of cost of goods sold if the funds are determined to be a reduction of the price of the vendor’s products.  If the consideration is a reimbursement of costs incurred by the Company to sell or develop the vendor’s products, then the consideration is classified as a reduction of such costs, most often operating expenses, in the Consolidated Statements of Income.  In order to be recognized as a reduction of operating expenses, the reimbursement must be for a specific, incremental, and identifiable cost incurred by the Company in selling the vendor’s products or services.

[0001571996-23-000007:notes:76]
Loss Contingencies — The Company is subject to the possibility of various losses arising in the ordinary course of business.  The Company considers the likelihood of loss or impairment of an asset or the incurrence of a liability, as well as the Company’s ability to reasonably estimate the amount of loss, in determining loss contingencies.  An estimated loss contingency is accrued when it is probable that an asset has been impaired or a liability has been incurred and the amount of loss can be reasonably estimated.  The Company regularly evaluates current information available to determine whether such accruals should be adjusted and whether new accruals are required.

[0001571996-23-000007:notes:77]
Shipping Costs — The Company’s shipping and handling costs are included in cost of net revenue in the Consolidated Statements of Income.

[0001571996-23-000007:notes:78]
Selling, General, and Administrative — Selling expenses include items such as sales salaries and commissions, marketing and advertising costs, and contractor services.  Advertising costs are expensed as incurred in selling, general, and administrative expenses in the Consolidated Statements of Income.  For the fiscal years ended February 3, 2023, January 28, 2022, and January 29, 2021, advertising expenses were $1.1 billion, $1.3 billion, and $1.0 billion, respectively.  General and administrative expenses include items for the Company’s administrative functions, such as finance, legal, human resources, and information technology support.  These functions include costs for items such as salaries and benefits and other personnel-related costs, maintenance and supplies, outside services, intangible asset amortization, and depreciation expense.

[0001571996-23-000007:notes:79]
Research and Development — Research and development (“R&D”) costs are expensed as incurred.  As noted in Capitalized Software Development Costs in this Note, qualifying software development costs are capitalized and amortized over time.  R&D costs include salaries and benefits and other personnel-related costs associated with product development.  Also included in R&D expenses are infrastructure costs, which consist of equipment and material costs, facilities-related costs, and depreciation expense.

[0001571996-23-000007:notes:80]
Income Taxes — Deferred tax assets and liabilities are recorded based on the difference between the financial statement and tax basis of assets and liabilities using enacted tax rates in effect for the year in which the differences are expected to reverse.  The Company calculates a provision for income taxes using the asset and liability method, under which deferred tax assets and liabilities are recognized by identifying the temporary differences arising from the different treatment of items for tax and accounting purposes.  The Company accounts for the tax impact of including Global Intangible Low-Taxed Income (GILTI) in U.S. taxable income as a period cost.  The Company provides valuation allowances for deferred tax assets, where appropriate.  In assessing the need for a valuation allowance, the Company considers all available evidence for each jurisdiction, including past operating results, estimates of future taxable income, and the feasibility of ongoing tax planning strategies.  In the event the Company determines that all or part of the net deferred tax assets are not realizable in the future, the Company will make an adjustment to the valuation allowance that will be charged to earnings in the period in which such a determination is made.

[0001571996-23-000007:notes:81]
The accounting guidance for uncertainties in income tax prescribes a comprehensive model for the financial statement recognition, measurement, presentation, and disclosure of uncertain tax positions taken or expected to be taken in income tax returns.  The Company recognizes a tax benefit from an uncertain tax position in the financial statements only when it is more likely than not that the position will be sustained upon examination, including resolution of any related appeals or litigation processes, based on the technical merits and a consideration of the relevant taxing authority’s administrative practices and precedents.

[0001571996-23-000007:notes:82]
Stock-Based Compensation — The Company measures stock-based compensation expense for all share-based awards granted based on the estimated fair value of those awards at grant date.  To estimate the fair value of performance-based awards containing a market condition, the Company uses the Monte Carlo valuation model.  The fair value of other share-based awards is generally based on the closing price of the Class C Common Stock as reported on the New York Stock Exchange (“NYSE”) on the date of grant.

[0001571996-23-000007:notes:83]
The compensation cost of service-based stock options, restricted stock, and restricted stock units is recognized net of any estimated forfeitures on a straight-line basis over the employee requisite service period.  Compensation cost for performance-based awards is recognized on a graded accelerated basis net of estimated forfeitures over the requisite service period.  Forfeiture rates are estimated at grant date based on historical experience and adjusted in subsequent periods for differences in actual forfeitures from those estimates.

[0001571996-23-000007:notes:84]
Recently Issued Accounting Pronouncements

[0001571996-23-000007:notes:85]
Accounting for Contract Assets and Contract Liabilities from Contracts with Customers — In October 2021, the Financial Accounting Standards Board (“FASB”) issued guidance which requires companies to apply Topic 606, Revenue from Contracts with Customers, to recognize and measure contract assets and contract liabilities from contracts with customers acquired in a business combination.  Public entities must adopt the new guidance for fiscal years beginning after December 15, 2022 and interim periods within those fiscal years, with early adoption permitted.  Adoption of the guidance is not expected to have a material impact on the Company’s financial results.
Reference Rate Reform — In March 2020, the FASB issued guidance which provides temporary optional expedients and exceptions to GAAP guidance on contract modifications and certain hedging relationships to ease the financial reporting burdens related to the expected market transition from the London Interbank Offered Rate to alternative reference rates.  The Company may elect to apply the amendments prospectively through December 31, 2024.  Adoption of the new guidance is not expected to have a material impact on the Company’s financial results.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0001571996-23-000007:notes:86]
The Company periodically reviews these deferred costs to determine whether events or changes in circumstances have occurred that could impact the carrying value or period of benefit of the deferred sales commissions.  There were no material impairment losses for deferred costs to obtain a contract during the fiscal years ended February 3, 2023, January 28, 2022, and January 29, 2021.
Vendor Rebates — The Company may receive consideration from vendors in the normal course of business.  Certain of these funds are rebates of purchase price paid and others are related to reimbursement of costs incurred by the Company to sell the vendor’s products.  The Company recognizes a reduction of cost of goods sold if the funds are determined to be a reduction of the price of the vendor’s products.  If the consideration is a reimbursement of costs incurred by the Company to sell or develop the vendor’s products, then the consideration is classified as a reduction of such costs, most often operating expenses, in the Consolidated Statements of Income.  In order to be recognized as a reduction of operating expenses, the reimbursement must be for a specific, incremental, and identifiable cost incurred by the Company in selling the vendor’s products or services.Shipping Costs — The Company’s shipping and handling costs are included in cost of net revenue in the Consolidated Statements of Income.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001571996-23-000007:notes:87]
DISCONTINUED OPERATIONS
VMware Spin-Off — As disclosed in Note 1 of the Notes to the Consolidated Financial Statements, on November 1, 2021, the Company completed its spin-off of VMware by means of a special stock dividend of 30,678,605 shares of Class A common stock and 307,221,836 shares of Class B common stock of VMware to Dell Technologies stockholders of record as of October 29, 2021.

[0001571996-23-000007:notes:88]
Prior to receipt of the VMware common stock by the Company’s stockholders, each share of VMware Class B common stock automatically converted into one share of VMware Class A common stock.  As a result of these transactions, each holder of record of shares of Dell Technologies common stock as of the distribution record date received approximately 0.440626 of a share of VMware Class A common stock for each share of Dell Technologies common stock held as of such date, based on shares outstanding as of the completion of the VMware Spin-off.  Following completion of the transaction, the pre-transaction stockholders of Dell Technologies owned shares in two separate public companies, consisting of (1) VMware, which continues to own the businesses of VMware, Inc. and its subsidiaries, and (2) Dell Technologies, which continues to own Dell Technologies’ other businesses and subsidiaries.  After the separation, Dell Technologies does not beneficially own any shares of VMware common stock.

[0001571996-23-000007:notes:89]
VMware paid a cash dividend, pro rata, to each of the holders of VMware common stock in an aggregate amount equal to $11.5 billion, of which Dell Technologies received $9.3 billion.  Following the payment by VMware to its stockholders, the separation of VMware from Dell Technologies occurred, including the termination or settlement of certain intercompany accounts and intercompany contracts.  Dell Technologies used the net proceeds from its pro rata share of the cash dividend to repay a portion of its outstanding debt.

[0001571996-23-000007:notes:90]
Dell Technologies determined that the VMware Spin-off, and related distributions, qualified as tax-free for U.S. federal income tax purposes, which required significant judgment by management.  In making these determinations, Dell Technologies applied U.S. federal tax law to relevant facts and circumstances and obtained a favorable private letter ruling from the Internal Revenue Service, a tax opinion, and other external tax advice related to the concluded tax treatment.  If the completed transactions were to fail to qualify for tax-free treatment for U.S. federal income tax purposes, the Company could be subject to significant liabilities, which could have material adverse impacts on the Company’s business, financial condition, results of operations and cash flows in future reporting periods.

[0001571996-23-000007:notes:91]
In connection with and upon completion of the VMware Spin-off, Dell Technologies and VMware entered into various agreements that provide a framework for the relationship between the companies after the transaction, including, among others, a commercial framework agreement, a tax matters agreement, and a transition services agreement.

[0001571996-23-000007:notes:92]
The CFA referred to in Note 1 to the Notes to the Consolidated Financial Statements provides a framework under which the Company and VMware will continue their commercial relationship after the transaction, particularly with respect to projects mutually agreed by the parties as having the potential to accelerate the growth of an industry, product, service, or platform that may provide one or both companies with a strategic market opportunity.  The CFA has an initial term of five years, with automatic one-year renewals occurring annually thereafter, subject to certain terms and conditions.

[0001571996-23-000007:notes:93]
Pursuant to the CFA, Dell Technologies continues to act as a distributor of VMware’s standalone products and services and purchases such products and services for resale to end-user customers.  Dell Technologies also continues to integrate VMware’s products and services with Dell Technologies’ offerings and sell them to end users.  Cash flows between Dell Technologies and VMware primarily relate to such transactions.  The Company has determined that it is generally acting as principal in these arrangements.  The results of such operations are classified as continuing operations within the Company’s Consolidated Statements of Income.  See Note 21 of the Notes to the Consolidated Financial Statements for additional information regarding transactions between Dell Technologies and VMware.

[0001571996-23-000007:notes:94]
In accordance with applicable accounting guidance, the results of VMware, excluding Dell Technologies’ resale of VMware offerings, are presented as discontinued operations in the Consolidated Statements of Income and, as such, have been excluded from both continuing operations and segment results for the fiscal years ended January 28, 2022 and January 29, 2021.  The Consolidated Statements of Cash Flows are presented on a consolidated basis for both continuing operations and discontinued operations.

[0001571996-23-000007:notes:95]
The tax matters agreement between the Company and VMware governs the respective rights, responsibilities, and obligations of Dell Technologies and VMware with respect to tax liabilities (including taxes, if any, incurred as a result of any failure of the VMware Spin-off to qualify for tax-free treatment for U.S. federal income tax purposes) and benefits, tax attributes, the preparation and filing of tax returns, the control of audits and other tax proceedings, cooperation, and other matters regarding tax.

[0001571996-23-000007:notes:96]
The transition services agreement between the Company and VMware governed the various administrative services which the Company provided to VMware on an interim transitional basis.  Transition services were fulfilled and concluded during the fiscal year ended February 3, 2023.

[0001571996-23-000007:notes:97]
The following table presents key components of “Income from discontinued operations, net of income taxes” for the fiscal years ended January 28, 2022 and January 29, 2021:

[0001571996-23-000007:notes:98]
|  |  |  |  | Fiscal Year Ended |
|  |  |  |  | January 28, 2022 |  | January 29, 2021 |
|  |  |  |  | (in millions) |
| Net revenue |  |  |  | $ | 5,798 |  |  | $ | 7,554 |  |
| Cost of net revenue |  |  |  | (1,632) |  |  | (1,723) |  |
| Operating expenses |  |  |  | 6,384 |  |  | 7,818 |  |
| Interest and other, net |  |  |  | 232 |  |  | 135 |  |
| Income from discontinued operations before income taxes |  |  |  | 814 |  |  | 1,324 |  |
| Income tax expense |  |  |  | 49 |  |  | 64 |  |
| Income from discontinued operations, net of income taxes |  |  |  | $ | 765 |  |  | $ | 1,260 |  |

[0001571996-23-000007:notes:99]
____________________

[0001571996-23-000007:notes:100]
The table above reflects the offsetting effects of historical intercompany transactions which are presented on a gross basis within continuing operations on the Consolidated Statements of Income.

[0001571996-23-000007:notes:101]
The following table presents significant cash flow items from discontinued operations for the fiscal years ended January 28, 2022 and January 29, 2021 included within the Consolidated Statements of Cash Flows:

[0001571996-23-000007:notes:102]
|  |  |  |  | Fiscal Year Ended |
|  |  |  |  | January 28, 2022 |  | January 29, 2021 |
|  |  |  |  | (in millions) |
| Depreciation and amortization |  |  |  | $ | 1,004 |  |  | $ | 1,523 |  |
| Capital expenditures |  |  |  | $ | 263 |  |  | $ | 329 |  |
| Stock-based compensation expense |  |  |  | $ | 814 |  |  | $ | 1,122 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001571996-23-000007:notes:103]
FAIR VALUE MEASUREMENTS
The following table presents the Company’s hierarchy for its assets and liabilities measured at fair value on a recurring basis as of the dates indicated:

[0001571996-23-000007:notes:104]
|  | February 3, 2023 |  | January 28, 2022 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | Quoted Prices in Active Markets for Identical Assets |  | Significant Other Observable Inputs |  | Significant Unobservable Inputs |  |  |  | Quoted Prices in Active Markets for Identical Assets |  | Significant Other Observable Inputs |  | Significant Unobservable Inputs |  |  |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 4,301 |  |  | $ | — |  |  | $ | — |  |  | $ | 4,301 |  |  | $ | 3,737 |  |  | $ | — |  |  | $ | — |  |  | $ | 3,737 |  |
| Marketable equity and other securities | 33 |  |  | — |  |  | — |  |  | 33 |  |  | 86 |  |  | — |  |  | — |  |  | 86 |  |
| Derivative instruments | — |  |  | 295 |  |  | — |  |  | 295 |  |  | — |  |  | 253 |  |  | — |  |  | 253 |  |
| Total assets | $ | 4,334 |  |  | $ | 295 |  |  | $ | — |  |  | $ | 4,629 |  |  | $ | 3,823 |  |  | $ | 253 |  |  | $ | — |  |  | $ | 4,076 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative instruments | $ | — |  |  | $ | 460 |  |  | $ | — |  |  | $ | 460 |  |  | $ | — |  |  | $ | 138 |  |  | $ | — |  |  | $ | 138 |  |
| Total liabilities | $ | — |  |  | $ | 460 |  |  | $ | — |  |  | $ | 460 |  |  | $ | — |  |  | $ | 138 |  |  | $ | — |  |  | $ | 138 |  |

[0001571996-23-000007:notes:105]
The following section describes the valuation methodologies the Company uses to measure financial instruments at fair value:

[0001571996-23-000007:notes:106]
Money Market Funds — The Company’s investment in money market funds that are classified as cash equivalents hold underlying investments with a weighted average maturity of 90 days or less and are recognized at fair value.  The valuations of these securities are based on quoted prices in active markets for identical assets, when available, or pricing models whereby all significant inputs are observable or can be derived from or corroborated by observable market data.  The Company reviews security pricing and assesses liquidity on a quarterly basis.  As of February 3, 2023, the Company’s portfolio had no material exposure to money market funds with a fluctuating net asset value.

[0001571996-23-000007:notes:107]
Marketable Equity and Other Securities — The majority of the Company’s investments in equity and other securities that are measured at fair value on a recurring basis consist of strategic investments in publicly-traded companies.  The valuation of these securities is based on quoted prices in active markets.

[0001571996-23-000007:notes:108]
Derivative Instruments — The Company’s derivative financial instruments consist primarily of foreign currency forward and purchased option contracts and interest rate swaps.  The fair value of the portfolio is determined using valuation models based on market observable inputs, including interest rate curves, forward and spot prices for currencies, and implied volatilities.  Credit risk is also factored into the fair value calculation of the Company’s derivative financial instrument portfolio.  See Note 9 of the Notes to the Consolidated Financial Statements for a description of the Company’s derivative financial instrument activities.

[0001571996-23-000007:notes:109]
Deferred Compensation Plans —The Company offers deferred compensation plans for eligible employees, which allow participants to defer a portion of their compensation.  Assets were the same as liabilities associated with the plans at approximately $179 million and $192 million as of February 3, 2023 and January 28, 2022, respectively, and are included in other assets and other liabilities on the Consolidated Statements of Financial Position.  The net impact to the Consolidated Statements of Income is not material since changes in the fair value of the assets substantially offset changes in the fair value of the liabilities.  As such, assets and liabilities associated with these plans have not been included in the recurring fair value table above.

[0001571996-23-000007:notes:110]
Assets and Liabilities Measured at Fair Value on a Nonrecurring Basis — Certain assets are measured at fair value on a nonrecurring basis and therefore are not included in the recurring fair value table above.  These assets consist primarily of non-financial assets such as goodwill and intangible assets.  See Note 10 of the Notes to the Consolidated Financial Statements for additional information about goodwill and intangible assets.

[0001571996-23-000007:notes:111]
As of February 3, 2023 and January 28, 2022, the Company held strategic investments in non-marketable equity and other securities of $1.3 billion and $1.4 billion, respectively.  As these investments represent early-stage companies without readily determinable fair values, they are not included in the recurring fair value table above.  See Note 5 of the Notes to the Consolidated Financial Statements for additional information about our strategic investments.

[0001571996-23-000007:notes:112]
Carrying Value and Estimated Fair Value of Outstanding Debt — The following table presents the carrying value and estimated fair value of the Company’s outstanding debt as described in Note 8 of the Notes to the Consolidated Financial Statements, including the current portion, as of the dates indicated:

[0001571996-23-000007:notes:113]
|  | February 3, 2023 |  | January 28, 2022 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Notes | $ | 18.1 |  |  | $ | 18.2 |  |  | $ | 16.1 |  |  | $ | 18.5 |  |
| Legacy Notes and Debentures | $ | 0.9 |  |  | $ | 1.0 |  |  | $ | 0.8 |  |  | $ | 1.1 |  |
| DFS Debt | $ | 10.3 |  |  | $ | 9.9 |  |  | $ | 9.6 |  |  | $ | 9.6 |  |

[0001571996-23-000007:notes:114]
The fair values of the outstanding debt shown in the table above were determined based on observable market prices in a less active market or based on valuation methodologies using observable inputs and were categorized as Level 2 in the fair value hierarchy.


## us-gaap:InvestmentTextBlock

[0001571996-23-000007:notes:115]
INVESTMENTS
The Company has strategic investments in equity and other securities as well as investments in fixed income debt securities.   All equity and other securities as well as long-term fixed income debt securities are recorded as long-term investments in the Consolidated Statements of Financial Position.  Short-term fixed income debt securities are recorded as other current assets in the Consolidated Statements of Financial Position.

[0001571996-23-000007:notes:116]
As of February 3, 2023 and January 28, 2022, total investments were $1.6 billion and $1.8 billion, respectively.

[0001571996-23-000007:notes:117]
Equity and Other Securities

[0001571996-23-000007:notes:118]
Equity and other securities include strategic investments in marketable and non-marketable securities.  Investments in marketable securities are measured at fair value on a recurring basis.  The Company has elected to apply the measurement alternative for non-marketable securities.  Under the alternative, the Company measures investments without readily determinable fair values at cost, less impairment, adjusted by observable price changes.  The Company makes a separate election to use the alternative for each eligible investment and is required to reassess at each reporting period whether an investment qualifies for the alternative.  In evaluating these investments for impairment or observable price changes, the Company uses inputs including pre- and post-money valuations of recent financing events and the impact of those events on its fully diluted ownership percentages, as well as other available information regarding the issuer’s historical and forecasted performance.

[0001571996-23-000007:notes:119]
Carrying Value of Equity and Other Securities

[0001571996-23-000007:notes:120]
The following table presents the cost, cumulative unrealized gains, cumulative unrealized losses, and carrying value of the Company's strategic investments in marketable and non-marketable equity securities as of the dates indicated:

[0001571996-23-000007:notes:121]
|  | February 3, 2023 |  | January 28, 2022 |
|  | Cost |  | Unrealized Gain |  | Unrealized Loss |  | Carrying Value |  | Cost |  | Unrealized Gain |  | Unrealized Loss |  | Carrying Value |
|  | (in millions) |
| Marketable | $ | 56 |  |  | $ | 17 |  |  | $ | (40) |  |  | $ | 33 |  |  | $ | 126 |  |  | $ | 79 |  |  | $ | (119) |  |  | $ | 86 |  |
| Non-marketable | 714 |  |  | 651 |  |  | (100) |  |  | 1,265 |  |  | 593 |  |  | 900 |  |  | (52) |  |  | 1,441 |  |
| Total equity and other securities | $ | 770 |  |  | $ | 668 |  |  | $ | (140) |  |  | $ | 1,298 |  |  | $ | 719 |  |  | $ | 979 |  |  | $ | (171) |  |  | $ | 1,527 |  |

[0001571996-23-000007:notes:122]
Gains and Losses on Equity and Other Securities

[0001571996-23-000007:notes:123]
The following table presents unrealized gains and losses on marketable and non-marketable equity and other securities for the periods indicated:

[0001571996-23-000007:notes:124]
|  |  |  |  | Fiscal Year Ended |
|  |  |  |  |  |  |  |  | February 3, 2023 |  | January 28, 2022 |  | January 29, 2021 |
|  |  | (in millions) |
| Marketable securities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Unrealized gain |  |  |  |  |  |  |  | $ | 57 |  |  | $ | 45 |  |  | $ | 288 |  |
| Unrealized loss |  |  |  |  |  |  |  | (47) |  |  | (151) |  |  | (45) |  |
| Net unrealized gain (loss) |  |  |  |  |  |  |  | 10 |  |  | (106) |  |  | 243 |  |
| Non-marketable securities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Unrealized gain |  |  |  |  |  |  |  | 90 |  |  | 604 |  |  | 190 |  |
| Unrealized loss |  |  |  |  |  |  |  | (349) |  |  | (43) |  |  | (59) |  |
| Net unrealized gain (loss) (a) (b) |  |  |  |  |  |  |  | (259) |  |  | 561 |  |  | 131 |  |
| Net unrealized gain (loss) on equity and other securities |  |  |  |  |  |  |  | $ | (249) |  |  | $ | 455 |  |  | $ | 374 |  |

[0001571996-23-000007:notes:125]
(a)    For the fiscal year ended February 3, 2023, net unrealized losses on non-marketable securities were primarily attributable to the recognition of impairments on equity and other securities, which were generally in line with extended public equity market declines.  In evaluating these investments for impairment, the Company used inputs including pre- and post-money valuations of recent financing events and the impact of those events on its fully diluted ownership percentages, as well as other available information regarding the issuer’s historical and forecasted performance.

[0001571996-23-000007:notes:126]
(b)  For the fiscal years ended January 28, 2022 and January 29, 2021, net unrealized gains on non-marketable securities were due to upward adjustments for observable price changes offset by losses primarily attributable to downward adjustments for observable price changes and impairments.

[0001571996-23-000007:notes:127]
Fixed Income Debt Securities

[0001571996-23-000007:notes:128]
The Company has fixed income debt securities carried at amortized cost which are held as collateral for borrowings.  The Company intends to hold the investments to maturity.  As of the balance sheet dates presented, the Company holds $98 million in fixed income debt securities which will mature within one year and $220 million in fixed income debt securities which will mature within two to five years.

[0001571996-23-000007:notes:129]
The following table summarizes the Company’s debt securities as of the dates indicated:

[0001571996-23-000007:notes:130]
|  | February 3, 2023 |  | January 28, 2022 |
|  | Cost |  | Unrealized Gains |  | Unrealized Loss |  | Carrying Value |  | Cost |  | Unrealized Gains |  | Unrealized Loss |  | Carrying Value |
|  | (in millions) |
| Fixed income debt securities | $ | 348 |  |  | $ | 65 |  |  | $ | (95) |  |  | $ | 318 |  |  | $ | 333 |  |  | $ | 26 |  |  | $ | (47) |  |  | $ | 312 |  |


## dell:CreditLossFinancialInstrumentLeasesDebtVariableInterestEntitiesAndCustomerReceivablesSalesTextBlock

[0001571996-23-000007:notes:131]
FINANCIAL SERVICES
The Company offers or arranges various financing options and alternative payment structures for its customers globally.  Alternative payment structures consist of various flexible consumption models, including utility, subscription, and as-a-Service models.

[0001571996-23-000007:notes:132]
Financing options are offered primarily through Dell Financial Services and its affiliates (“DFS”).  The Company also arranges financing for some of its customers in various countries where DFS does not currently operate as a captive enterprise.  The key activities of DFS include originating, collecting, and servicing customer financing arrangements primarily related to the purchase or use of Dell Technologies products and services.  In some cases, DFS also offers financing for the purchase of third-party technology products that complement the Dell Technologies portfolio of products and services.  New financing originations were $9.7 billion, $8.5 billion, and $8.9 billion for the fiscal years ended February 3, 2023, January 28, 2022, and January 29, 2021, respectively.

[0001571996-23-000007:notes:133]
The Company’s lease and loan arrangements with customers are aggregated primarily into the following categories:

[0001571996-23-000007:notes:134]
Revolving loans — Revolving loans offered under private label credit financing programs provide qualified customers with a revolving credit line for the purchase of products and services offered by Dell Technologies.  These private label credit financing programs are referred to as Dell Preferred Account (“DPA”) and Dell Business Credit (“DBC”).  The DPA product is primarily offered to individual consumer customers, and the DBC product is primarily offered to small and medium-sized commercial customers.  Revolving loans in the United States bear interest at a variable annual percentage rate that is tied to the prime rate.  Based on historical payment patterns, revolving loan transactions are typically repaid within twelve months on average.  Due to the short-term nature of the revolving loan portfolio, the carrying value of the portfolio approximates fair value.

[0001571996-23-000007:notes:135]
Fixed-term leases and loans — The Company enters into financing arrangements with customers who seek lease financing for equipment.  DFS leases are generally classified as sales-type leases or operating leases.  Leases with business customers have fixed terms of generally two to four years.

[0001571996-23-000007:notes:136]
The Company also offers fixed-term loans to qualified small businesses, large commercial accounts, governmental organizations, educational entities, and certain individual consumer customers.  These loans are repaid in equal payments including interest and have defined terms of generally three to five years.  The fair value of the fixed-term loan portfolio is determined using market observable inputs.  The carrying value of these loans approximates fair value.

[0001571996-23-000007:notes:137]
Flexible consumption models, as defined above, enable the Company to offer its customers the option to pay over time to provide them with financial flexibility to meet their changing technological requirements.  Such models may result in identification of embedded lease arrangements that lead to the recognition of operating or sales-type leases.

[0001571996-23-000007:notes:138]
Financing Receivables

[0001571996-23-000007:notes:139]
The following table presents the components of the Company’s financing receivables segregated by portfolio segment as of the dates indicated:

[0001571996-23-000007:notes:140]
|  | February 3, 2023 |  | January 28, 2022 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Financing receivables, net: |  |  |  |  |  |  |  |  |  |  |  |
| Customer receivables, gross (a) | $ | 685 |  |  | $ | 10,293 |  |  | $ | 10,978 |  |  | $ | 750 |  |  | $ | 9,833 |  |  | $ | 10,583 |  |
| Allowances for losses | (88) |  |  | (113) |  |  | (201) |  |  | (102) |  |  | (87) |  |  | (189) |  |
| Customer receivables, net | 597 |  |  | 10,180 |  |  | 10,777 |  |  | 648 |  |  | 9,746 |  |  | 10,394 |  |
| Residual interest | — |  |  | 142 |  |  | 142 |  |  | — |  |  | 217 |  |  | 217 |  |
| Financing receivables, net | $ | 597 |  |  | $ | 10,322 |  |  | $ | 10,919 |  |  | $ | 648 |  |  | $ | 9,963 |  |  | $ | 10,611 |  |
| Short-term | $ | 597 |  |  | $ | 4,684 |  |  | $ | 5,281 |  |  | $ | 648 |  |  | $ | 4,441 |  |  | $ | 5,089 |  |
| Long-term | $ | — |  |  | $ | 5,638 |  |  | $ | 5,638 |  |  | $ | — |  |  | $ | 5,522 |  |  | $ | 5,522 |  |

[0001571996-23-000007:notes:141]
(a)    Customer receivables, gross include amounts due from customers under revolving loans, fixed-term loans, fixed-term sales-type or direct financing leases, and accrued interest.

[0001571996-23-000007:notes:142]
The following table presents the changes in allowance for financing receivable losses for the periods indicated:

[0001571996-23-000007:notes:143]
|  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |  |  |  |  |  |
| Balances as of January 31, 2020 | $ | 70 |  |  | $ | 79 |  |  | $ | 149 |  |
| Adjustment for adoption of accounting standard (Note 2) | 40 |  |  | 71 |  |  | 111 |  |
| Charge-offs, net of recoveries | (62) |  |  | (29) |  |  | (91) |  |
| Provision charged to income statement | 100 |  |  | 52 |  |  | 152 |  |
| Balances as of January 29, 2021 | 148 |  |  | 173 |  |  | 321 |  |
| Charge-offs, net of recoveries | (43) |  |  | (29) |  |  | (72) |  |
| Provision charged to income statement | (3) |  |  | (57) |  |  | (60) |  |
| Balances as of January 28, 2022 | 102 |  |  | 87 |  |  | 189 |  |
| Charge-offs, net of recoveries | (52) |  |  | (8) |  |  | (60) |  |
| Provision charged to income statement | 38 |  |  | 34 |  |  | 72 |  |
| Balances as of February 2, 2023 | $ | 88 |  |  | $ | 113 |  |  | $ | 201 |  |

[0001571996-23-000007:notes:144]
Aging

[0001571996-23-000007:notes:145]
The following table presents the aging of the Company’s customer financing receivables, gross, including accrued interest, segregated by class, as of the dates indicated:

[0001571996-23-000007:notes:146]
|  | February 3, 2023 |  | January 28, 2022 |
|  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |
|  | (in millions) |
| Revolving — DPA | $ | 457 |  |  | $ | 34 |  |  | $ | 17 |  |  | $ | 508 |  |  | $ | 520 |  |  | $ | 40 |  |  | $ | 11 |  |  | $ | 571 |  |
| Revolving — DBC | 154 |  |  | 19 |  |  | 4 |  |  | 177 |  |  | 158 |  |  | 18 |  |  | 3 |  |  | 179 |  |
| Fixed-term — Consumer and Commercial | 9,309 |  |  | 927 |  |  | 57 |  |  | 10,293 |  |  | 9,444 |  |  | 345 |  |  | 44 |  |  | 9,833 |  |
| Total customer receivables, gross | $ | 9,920 |  |  | $ | 980 |  |  | $ | 78 |  |  | $ | 10,978 |  |  | $ | 10,122 |  |  | $ | 403 |  |  | $ | 58 |  |  | $ | 10,583 |  |

[0001571996-23-000007:notes:147]
Aging is likely to fluctuate as a result of the variability in volume of large transactions entered into over the period, and the administrative processes that accompany those transactions.  Aging is also impacted by the timing of the Company’s fiscal period end date relative to calendar month-end customer payment due dates.  As a result of these factors, fluctuations in aging from period to period do not necessarily indicate a material change in the collectibility of the portfolio.  The increase in past-due amounts as of February 3, 2023 is primarily attributable to the timing of the Company’s fiscal period end date relative to calendar month-end customer payment due dates.

[0001571996-23-000007:notes:148]
Fixed-term consumer and commercial customer receivables are placed on non-accrual status if principal or interest is past due and considered delinquent, or if there is concern about the collectibility of a specific customer receivable.  The receivables identified as doubtful for collectibility may be classified as current for aging purposes.  Aged revolving portfolio customer receivables identified as delinquent are charged off.

[0001571996-23-000007:notes:149]
Credit Quality

[0001571996-23-000007:notes:150]
The following tables present customer receivables, gross, including accrued interest, by credit quality indicator, segregated by class, as of the dates indicated:

[0001571996-23-000007:notes:151]
|  | February 3, 2023 |
|  | Fixed-term — Consumer and Commercial |  |  |  |  |  |  |
|  | Fiscal Year of Origination |  |  |  |  |  |  |
|  | 2023 |  | 2022 |  | 2021 |  | 2020 |  | 2019 |  | Years Prior |  | Revolving — DPA |  | Revolving — DBC |  | Total |
|  | (in millions) |
| Higher | $ | 3,210 |  |  | $ | 1,805 |  |  | $ | 914 |  |  | $ | 343 |  |  | $ | 37 |  |  | $ | 1 |  |  | $ | 123 |  |  | $ | 44 |  |  | $ | 6,477 |  |
| Mid | 1,242 |  |  | 631 |  |  | 362 |  |  | 119 |  |  | 17 |  |  | 1 |  |  | 136 |  |  | 54 |  |  | 2,562 |  |
| Lower | 1,017 |  |  | 364 |  |  | 157 |  |  | 65 |  |  | 7 |  |  | 1 |  |  | 249 |  |  | 79 |  |  | 1,939 |  |
| Total | $ | 5,469 |  |  | $ | 2,800 |  |  | $ | 1,433 |  |  | $ | 527 |  |  | $ | 61 |  |  | $ | 3 |  |  | $ | 508 |  |  | $ | 177 |  |  | $ | 10,978 |  |

[0001571996-23-000007:notes:152]
|  | January 28, 2022 |
|  | Fixed-term — Consumer and Commercial |  |  |  |  |  |  |
|  | Fiscal Year of Origination |  |  |  |  |  |  |
|  | 2022 |  | 2021 |  | 2020 |  | 2019 |  | 2018 |  | Years Prior |  | Revolving — DPA |  | Revolving — DBC |  | Total |
|  | (in millions) |
| Higher | $ | 3,279 |  |  | $ | 1,824 |  |  | $ | 914 |  |  | $ | 221 |  |  | $ | 25 |  |  | $ | 3 |  |  | $ | 150 |  |  | $ | 46 |  |  | $ | 6,462 |  |
| Mid | 1,071 |  |  | 751 |  |  | 329 |  |  | 94 |  |  | 17 |  |  | — |  |  | 166 |  |  | 57 |  |  | 2,485 |  |
| Lower | 599 |  |  | 450 |  |  | 208 |  |  | 42 |  |  | 6 |  |  | — |  |  | 255 |  |  | 76 |  |  | 1,636 |  |
| Total | $ | 4,949 |  |  | $ | 3,025 |  |  | $ | 1,451 |  |  | $ | 357 |  |  | $ | 48 |  |  | $ | 3 |  |  | $ | 571 |  |  | $ | 179 |  |  | $ | 10,583 |  |

[0001571996-23-000007:notes:153]
The categories shown in the tables above segregate customer receivables based on the relative degrees of credit risk.  The credit quality indicators for DPA revolving accounts are measured primarily as of each quarter-end date, while all other indicators are generally updated on a periodic basis.

[0001571996-23-000007:notes:154]
For DPA revolving receivables shown in the table above, the Company makes credit decisions based on proprietary scorecards, which include the customer’s credit history, payment history, credit usage, and other credit agency-related elements.  The higher quality category includes prime accounts generally comparable to U.S. customer FICO scores of 720 or above.  The mid category represents the mid-tier accounts that are comparable to U.S. customer FICO scores from 660 to 719.  The lower category is generally sub-prime and represents accounts that are comparable to U.S. customer FICO scores below 660.  For the DBC revolving receivables and fixed-term commercial receivables shown in the table above, an internal grading system is utilized that assigns a credit level score based on a number of considerations, including liquidity, operating performance, and industry outlook.  The grading criteria and classifications for the fixed-term products differ from those for the revolving products as loss experience varies between these product and customer groups.  The credit quality categories cannot be compared between the different classes as loss experience varies substantially between the classes.

[0001571996-23-000007:notes:155]
Leases

[0001571996-23-000007:notes:156]
Interest income on sales-type lease receivables was $161 million, $246 million, and $270 million for the fiscal years ended February 3, 2023, January 28, 2022, and January 29, 2021, respectively.

[0001571996-23-000007:notes:157]
The following table presents the net revenue, cost of net revenue, and gross margin recognized at the commencement date of sales-type leases for the periods indicated:

[0001571996-23-000007:notes:158]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  | February 3, 2023 |  | January 28, 2022 |  | January 29, 2021 |
|  |  |  |  |  | (in millions) |
| Net revenue — products |  |  |  |  | $ | 851 |  |  | $ | 756 |  |  | $ | 824 |  |
| Cost of net revenue — products |  |  |  |  | 727 |  |  | 583 |  |  | 578 |  |
| Gross margin — products |  |  |  |  | $ | 124 |  |  | $ | 173 |  |  | $ | 246 |  |

[0001571996-23-000007:notes:159]
The following table presents the future maturity of the Company’s fixed-term customer leases and associated financing payments, and reconciles the undiscounted cash flows to the customer receivables, gross recognized on the Consolidated Statements of Financial Position as of the date indicated:

[0001571996-23-000007:notes:160]
|  | February 3, 2023 |
|  | (in millions) |
| Fiscal 2024 | $ | 2,514 |  |
| Fiscal 2025 | 1,690 |  |
| Fiscal 2026 | 1,144 |  |
| Fiscal 2027 | 482 |  |
| Fiscal 2028 and beyond | 112 |  |
| Total undiscounted cash flows | 5,942 |  |
| Fixed-term loans | 5,109 |  |
| Revolving loans | 685 |  |
| Less: Unearned income | (758) |  |
| Total customer receivables, gross | $ | 10,978 |  |

[0001571996-23-000007:notes:161]
Operating Leases

[0001571996-23-000007:notes:162]
The Company’s operating leases primarily consist of DFS captive fixed-term leases and contractually committed embedded leases identified within flexible consumption arrangements.

[0001571996-23-000007:notes:163]
The following table presents the components of the Company’s operating lease portfolio included in property, plant, and equipment, net as of the dates indicated:

[0001571996-23-000007:notes:164]
|  | February 3, 2023 |  | January 28, 2022 |
|  | (in millions) |
| Equipment under operating lease, gross | $ | 3,725 |  |  | $ | 2,643 |  |
| Less: Accumulated depreciation | (1,517) |  |  | (935) |  |
| Equipment under operating lease, net | $ | 2,208 |  |  | $ | 1,708 |  |

[0001571996-23-000007:notes:165]
The following table presents operating lease income related to lease payments and depreciation expense for the Company’s operating lease portfolio for the periods indicated:

[0001571996-23-000007:notes:166]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  | February 3, 2023 |  | January 28, 2022 |  | January 29, 2021 |
|  |  |  |  |  | (in millions) |
| Income related to lease payments |  |  |  |  | $ | 1,091 |  |  | $ | 717 |  |  | $ | 452 |  |
| Depreciation expense |  |  |  |  | $ | 803 |  |  | $ | 536 |  |  | $ | 334 |  |

[0001571996-23-000007:notes:167]
The following table presents the future payments to be received by the Company as lessor in operating lease contracts as of the date indicated:

[0001571996-23-000007:notes:168]
|  | February 3, 2023 |
|  | (in millions) |
| Fiscal 2024 | $ | 1,088 |  |
| Fiscal 2025 | 721 |  |
| Fiscal 2026 | 375 |  |
| Fiscal 2027 | 90 |  |
| Fiscal 2028 and beyond | 32 |  |
| Total | $ | 2,306 |  |

[0001571996-23-000007:notes:169]
DFS Debt

[0001571996-23-000007:notes:170]
The Company maintains programs that facilitate the funding of leases, loans, and other alternative payment structures in the capital markets.  The majority of DFS debt is non-recourse to Dell Technologies and represents borrowings under securitization programs and structured financing programs, for which the Company’s risk of loss is limited to transferred loan and lease payments and associated equipment.

[0001571996-23-000007:notes:171]
The following table presents DFS debt as of the dates indicated and excludes the allocated portion of the Company’s other borrowings, which represents the additional amount considered to fund the DFS business:

[0001571996-23-000007:notes:172]
|  | February 3, 2023 |  | January 28, 2022 |
| DFS debt | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing and securitization facilities | $ | 3,987 |  |  | $ | 3,054 |  |
| Fixed-term securitization offerings | 2,679 |  |  | 3,011 |  |
| Other | 76 |  |  | 135 |  |
| Total DFS U.S. debt | 6,742 |  |  | 6,200 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 790 |  |  | 739 |  |
| Other borrowings | 871 |  |  | 785 |  |
| Note payable | 250 |  |  | 250 |  |
| Dell Bank senior unsecured eurobonds | 1,637 |  |  | 1,672 |  |
| Total DFS international debt | 3,548 |  |  | 3,446 |  |
| Total DFS debt | $ | 10,290 |  |  | $ | 9,646 |  |
| Total short-term DFS debt | $ | 5,400 |  |  | $ | 5,803 |  |
| Total long-term DFS debt | $ | 4,890 |  |  | $ | 3,843 |  |

[0001571996-23-000007:notes:173]
DFS U.S. Debt

[0001571996-23-000007:notes:174]
Asset-Based Financing and Securitization Facilities — The Company maintains separate asset-based financing facilities and a securitization facility in the United States, which are revolving facilities for fixed-term leases and loans and for revolving loans, respectively.  This debt is collateralized solely by the U.S. loan and lease payments and associated equipment in the facilities.  The debt has a variable interest rate, and the duration of the debt is based on the terms of the underlying loan and lease payment streams.  As of February 3, 2023, the total debt capacity related to the U.S. asset-based financing and securitization facilities was $5.6 billion.  The Company enters into interest swap agreements to effectively convert a portion of this debt from a floating rate to a fixed rate.  See Note 9 of the Notes to the Consolidated Financial Statements for additional information about interest rate swaps.

[0001571996-23-000007:notes:175]
The Company’s U.S. securitization facility for revolving loans is effective through June 25, 2025.  The Company’s two U.S. asset-based financing facilities for fixed-term leases and loans are effective through July 10, 2023 and June 21, 2024, respectively.  The Company intends to extend the facility currently effective through July 10, 2023.

[0001571996-23-000007:notes:176]
The asset-based financing and securitization facilities contain standard structural features related to the performance of the funded receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the facility, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of February 3, 2023, these criteria were met.

[0001571996-23-000007:notes:177]
Fixed-Term Securitization Offerings — The Company periodically issues asset-backed debt securities under fixed-term securitization programs to private investors.  The asset-backed debt securities are collateralized solely by the U.S. fixed-term leases and loans in the offerings, which are held by Special Purpose Entities (“SPEs”), as discussed below.  The interest rate on these securities is fixed and ranges from 0.33% to 5.72% per annum, and the duration of these securities is based on the terms of the underlying lease and loan payment streams.

[0001571996-23-000007:notes:178]
DFS International Debt

[0001571996-23-000007:notes:179]
Securitization Facility — The Company maintains a securitization facility in Europe for fixed-term leases and loans. The debt under this facility has a variable interest rate, and the duration of the debt is based on the terms of the underlying loan and lease payment streams.  This facility is effective through December 23, 2024 and had a total debt capacity of $873 million as of February 3, 2023.

[0001571996-23-000007:notes:180]
The securitization facility contains standard structural features related to the performance of the securitized receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the program, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of February 3, 2023, these criteria were met.

[0001571996-23-000007:notes:181]
Other Borrowings — In connection with the Company’s international financing operations, the Company has entered into revolving structured financing debt programs related to its fixed-term lease and loan products sold in Canada, Europe, Australia, and New Zealand.  The debt under these programs has a variable interest rate, and the duration of the debt is based on the terms of the underlying loan and lease payment streams.  The Canadian facility, which is collateralized solely by Canadian loan and lease payments and associated equipment, had a total debt capacity of $338 million as of February 3, 2023 and is effective through January 16, 2025.  The European facility, which is collateralized solely by European loan and lease payments and associated equipment, had a total debt capacity of $655 million as of February 3, 2023 and is effective through June 14, 2025.  The Australia and New Zealand facility, which is collateralized solely by Australia and New Zealand loan and lease payments and associated equipment, had a total debt capacity of $318 million as of February 3, 2023 and is effective through April 20, 2023.

[0001571996-23-000007:notes:182]
Note Payable — On May 25, 2022, the Company entered into an unsecured credit agreement to fund receivables in Mexico.  As of February 3, 2023, the aggregate principal amount of the note payable was $250 million.  The note bears interest at an annual rate of 4.24% and will mature on May 31, 2024.

[0001571996-23-000007:notes:183]
Dell Bank Senior Unsecured Eurobonds — On June 24, 2020, Dell Bank issued 500 million Euro of 1.625% senior unsecured four year eurobonds due June 2024.  On October 27, 2021, Dell Bank issued 500 million Euro of 0.5% senior unsecured five year eurobonds due October 2026.  On October 18, 2022, Dell Bank issued 500 million Euro of 4.5% senior unsecured five year eurobonds due October 2027.  The issuances of the senior unsecured eurobonds support the expansion of the financing operations in Europe.

[0001571996-23-000007:notes:184]
Variable Interest Entities

[0001571996-23-000007:notes:185]
In connection with the asset-based financing facilities, securitization facilities, and fixed-term securitization offerings discussed above, the Company transfers certain U.S. and European lease and loan payments and associated equipment to SPEs that meet the definition of a VIE and are consolidated, along with the associated debt described above, into the Consolidated Financial Statements, as the Company is the primary beneficiary of the VIEs.  The SPEs are bankruptcy-remote legal entities with separate assets and liabilities.  The purpose of the SPEs is to facilitate the funding of customer loan and lease payments and associated equipment in the capital markets.

[0001571996-23-000007:notes:186]
Some of the SPEs have entered into financing arrangements with multi-seller conduits that, in turn, issue asset-backed debt securities in the capital markets.  DFS debt outstanding held by the consolidated VIEs is collateralized by the lease and loan payments and associated equipment.  The Company’s risk of loss related to securitized receivables is limited to the amount by which the Company’s right to receive collections for assets securitized exceeds the amount required to pay interest, principal, and fees and expenses related to the asset-backed securities.  The Company provides credit enhancement to the securitization in the form of over-collateralization.

[0001571996-23-000007:notes:187]
The following table presents the assets and liabilities held by the consolidated VIEs as of the dates indicated, which are included in the Consolidated Statements of Financial Position:

[0001571996-23-000007:notes:188]
|  | February 3, 2023 |  | January 28, 2022 |
|  | (in millions) |
| Assets held by consolidated VIEs |  |  |  |
| Other current assets | $ | 274 |  |  | $ | 535 |  |
| Financing receivables, net of allowance |  |  |  |
| Short-term | $ | 3,702 |  |  | $ | 3,368 |  |
| Long-term | $ | 3,295 |  |  | $ | 3,141 |  |
| Property, plant, and equipment, net | $ | 1,164 |  |  | $ | 945 |  |
| Liabilities held by consolidated VIEs |  |  |  |
| Debt, net of unamortized debt issuance costs |  |  |  |
| Short-term | $ | 4,761 |  |  | $ | 4,560 |  |
| Long-term | $ | 2,685 |  |  | $ | 2,235 |  |

[0001571996-23-000007:notes:189]
Lease and loan payments and associated equipment transferred via securitization through SPEs were $6.2 billion and $5.3 billion for the fiscal years ended February 3, 2023 and January 28, 2022, respectively.

[0001571996-23-000007:notes:190]
Customer Receivable Sales

[0001571996-23-000007:notes:191]
To manage certain concentrations of customer credit exposure, the Company may sell selected fixed-term customer receivables to unrelated third parties on a periodic basis, without recourse.  The amount of customer receivables sold for this purpose was $680 million, $201 million, and $648 million for the fiscal years ended February 3, 2023, January 28, 2022, and January 29, 2021, respectively.  The Company’s continuing involvement in these customer receivables is primarily limited to servicing arrangements.


## us-gaap:ScheduleOfDebtTableTextBlock

[0001571996-23-000007:notes:192]
The majority of DFS debt is non-recourse to Dell Technologies and represents borrowings under securitization programs and structured financing programs, for which the Company’s risk of loss is limited to transferred loan and lease payments and associated equipment.  
The following table presents DFS debt as of the dates indicated and excludes the allocated portion of the Company’s other borrowings, which represents the additional amount considered to fund the DFS business:

[0001571996-23-000007:notes:193]
The following table summarizes the Company’s outstanding debt as of the dates indicated:

[0001571996-23-000007:notes:194]
|  | February 3, 2023 |  | January 28, 2022 |
|  | (in millions) |
| Senior Notes: |  |  |  |
| 5.45% due June 2023 | $ | 1,000 |  |  | $ | 1,000 |  |
| 4.00% due July 2024 | 1,000 |  |  | 1,000 |  |
| 5.85% due July 2025 | 1,000 |  |  | 1,000 |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 4.90% due October 2026 | 1,750 |  |  | 1,750 |  |
| 6.10% due July 2027 | 500 |  |  | 500 |  |
| 5.25% due February 2028 | 1,000 |  |  | — |  |
| 5.30% due October 2029 | 1,750 |  |  | 1,750 |  |
| 6.20% due July 2030 | 750 |  |  | 750 |  |
| 5.75% due February 2033 | 1,000 |  |  | — |  |
| 8.10% due July 2036 | 1,000 |  |  | 1,000 |  |
| 3.38% due December 2041 | 1,000 |  |  | 1,000 |  |
| 8.35% due July 2046 | 800 |  |  | 800 |  |
| 3.45% due December 2051 | 1,250 |  |  | 1,250 |  |
| Legacy Notes and Debentures: |  |  |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| DFS Debt (Note 6) | 10,290 |  |  | 9,646 |  |
| Other | 325 |  |  | 337 |  |
| Total debt, principal amount | $ | 29,867 |  |  | $ | 27,235 |  |
| Unamortized discount, net of unamortized premium | (133) |  |  | (134) |  |
| Debt issuance costs | (146) |  |  | (147) |  |
| Total debt, carrying value | $ | 29,588 |  |  | $ | 26,954 |  |
| Total short-term debt, carrying value | $ | 6,573 |  |  | $ | 5,823 |  |
| Total long-term debt, carrying value | $ | 23,015 |  |  | $ | 21,131 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0001571996-23-000007:notes:195]
LEASES 
The Company enters into leasing transactions in which the Company is the lessee.  These lease contracts are typically classified as operating leases.  The Company’s lease contracts are generally for office buildings used to conduct its business, and the determination of whether such contracts contain leases generally does not require significant estimates or judgments.  The Company also leases certain global logistics warehouses, employee vehicles, and equipment.  As of February 3, 2023, the remaining terms of the Company’s leases range from one month to approximately ten years.  As of February 3, 2023 and January 28, 2022, there were no material finance leases for which the Company was a lessee.

[0001571996-23-000007:notes:196]
The Company also enters into leasing transactions in which the Company is the lessor, primarily through customer financing arrangements offered through DFS.  DFS originates leases that are primarily classified as either sales-type leases or operating leases.  See Note 6 of the Notes to the Consolidated Financial Statements for more information on the Company’s lessor arrangements.

[0001571996-23-000007:notes:197]
The following table presents components of lease costs included in the Consolidated Statements of Income for the periods indicated:

[0001571996-23-000007:notes:198]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  | February 3, 2023 |  | January 28, 2022 |
|  |  |  |  |  | (in millions) |
| Operating lease costs |  |  |  |  | $ | 283 |  |  | $ | 335 |  |
| Variable costs |  |  |  |  | 113 |  |  | 96 |  |
| Total lease costs |  |  |  |  | $ | 396 |  |  | $ | 431 |  |

[0001571996-23-000007:notes:199]
During the fiscal years ended February 3, 2023 and January 28, 2022, sublease income, finance lease costs, and short-term lease costs were immaterial.

[0001571996-23-000007:notes:200]
The following table presents supplemental information related to operating leases included in the Consolidated Statements of Financial Position as of the dates indicated:

[0001571996-23-000007:notes:201]
|  | Classification | February 3, 2023 |  | January 28, 2022 |  |  |
|  |  | (in millions, except for term and discount rate) |
| Operating lease right-of-use assets | Other non-current assets | $ | 725 |  | $ | 871 |  |  |
| Current operating lease liabilities | Accrued and other current liabilities | $ | 260 |  | $ | 287 |  |  |
| Non-current operating lease liabilities | Other non-current liabilities | 630 |  | 720 |  |  |
| Total operating lease liabilities |  | $ | 890 |  | $ | 1,007 |  |  |
| Weighted-average remaining lease term (in years) |  | 4.95 |  | 5.51 |  |  |
| Weighted-average discount rate |  | 3.48 | % |  | 3.01 | % |  |  |

[0001571996-23-000007:notes:202]
The following table presents supplemental cash flow information related to leases for the periods indicated:

[0001571996-23-000007:notes:203]
|  | Fiscal Year Ended |
|  | February 3, 2023 |  | January 28, 2022 |
|  | (in millions) |
| Cash paid for amounts included in the measurement of lease liabilities — operating cash outflows from operating leases (a) | $ | 306 |  |  | $ | 459 |  |
| Right-of-use assets obtained in exchange for new operating lease liabilities | $ | 226 |  |  | $ | 144 |  |

[0001571996-23-000007:notes:204]
(a) Cash paid for amounts included in the measurement of lease liabilities - operating cash outflows from operating leases from discontinued operations was $135 million for the fiscal year ended January 28, 2022.

[0001571996-23-000007:notes:205]
The following table presents the future maturity of the Company’s operating lease liabilities under non-cancelable leases and reconciles the undiscounted cash flows for these leases to the lease liability recognized on the Consolidated Statements of Financial Position as of the date indicated:

[0001571996-23-000007:notes:206]
|  | February 3, 2023 |
|  | (in millions) |
| Fiscal 2024 | $ | 260 |  |
| Fiscal 2025 | 200 |  |
| Fiscal 2026 | 162 |  |
| Fiscal 2027 | 121 |  |
| Fiscal 2028 | 85 |  |
| Thereafter | 138 |  |
| Total lease payments | 966 |  |
| Less: Imputed interest | (76) |  |
| Total | $ | 890 |  |
| Current operating lease liabilities | $ | 260 |  |
| Non-current operating lease liabilities | $ | 630 |  |

[0001571996-23-000007:notes:207]
As of February 3, 2023, the Company’s undiscounted operating leases that had not yet commenced were immaterial.


## us-gaap:DebtDisclosureTextBlock

[0001571996-23-000007:notes:208]
DEBT
The following table summarizes the Company’s outstanding debt as of the dates indicated:

[0001571996-23-000007:notes:209]
Fiscal 2023 Senior Note Issuance

[0001571996-23-000007:notes:210]
On January 24, 2023, the Company completed a public offering of senior notes in the aggregate principal amount of $2.0 billion.  In the public offering, the Company issued $1.0 billion aggregate principal amount of 5.25% senior notes due 2028 and $1.0 billion aggregate principal amount of 5.75% senior notes due 2033.  Interest on these borrowings is payable semiannually.  The Company intends to utilize the proceeds of the issued senior notes to repay the 5.45% senior notes due June 2023 and to utilize the remaining proceeds for general corporate purposes, including repayment of other debt.

[0001571996-23-000007:notes:211]
Commercial Paper Program

[0001571996-23-000007:notes:212]
On July 18, 2022, the Company established a commercial paper program under which the Company may issue unsecured notes in a maximum aggregate face amount of $5.0 billion outstanding at any time, with maturities up to 397 days from the date of issuance.  The notes will be sold on customary terms in the U.S. commercial paper market on a private placement basis.  The proceeds of the notes will be used for general corporate purposes.  As of February 3, 2023, the Company had no outstanding borrowings under the commercial paper program.  Commercial paper issuances and repayments with maturities of 90 days or less are presented on a net basis within cash flows from financing activities on the Consolidated Statements of Cash Flows.

[0001571996-23-000007:notes:213]
Outstanding Debt

[0001571996-23-000007:notes:214]
Senior Notes — The Company completed private offerings of multiple series of senior notes which were issued on June 1, 2016, June 22, 2016, March 20, 2019, April 9, 2020, and December 13, 2021 in aggregate principal amounts of $20.0 billion, $3.3 billion, $4.5 billion, $2.3 billion, and $2.3 billion, respectively (together with the registered senior notes subsequently issued in exchange and the senior notes issued on January 24, 2023, the “Senior Notes”).  Interest on these borrowings is payable semiannually.

[0001571996-23-000007:notes:215]
In June 2021, Dell International L.L.C. and EMC Corporation, wholly-owned subsidiaries of Dell Technologies Inc. and issuers of the Senior Notes (the “Issuers”), completed an offer to exchange any and all outstanding Senior Notes issued on June 1, 2016, March 20, 2019, and April 9, 2020 for senior notes registered under the Securities Act of 1933 having terms substantially identical to the terms of the outstanding Senior Notes.  The Issuers issued $18.4 billion aggregate principal amount of registered Senior Notes in exchange for the same aggregate principal amount of unregistered Senior Notes.  The aggregate principal amount of unregistered Senior Notes remaining outstanding following the settlement of the exchange offer was approximately $0.1 billion.

[0001571996-23-000007:notes:216]
Legacy Notes and Debentures — The Company has outstanding unsecured notes and debentures (collectively, the “Legacy Notes and Debentures”) that were issued by Dell Inc. (“Dell”), a wholly-owned subsidiary of Dell Technologies Inc., prior to the acquisition of Dell by Dell Technologies Inc. in the going-private transaction that closed in October 2013.  Interest on these borrowings is payable semiannually.

[0001571996-23-000007:notes:217]
DFS Debt — See Note 6 and Note 9 of the Notes to the Consolidated Financial Statements, respectively, for discussion of DFS debt and the interest rate swap agreements that hedge a portion of that debt.

[0001571996-23-000007:notes:218]
2021 Revolving Credit Facility — As of February 3, 2023, the Company’s revolving credit facility, which was entered into on November 1, 2021 (the “2021 Revolving Credit Facility”), matures on November 1, 2027.  This facility provides the Company with revolving commitments in an aggregate principal amount of $6.0 billion as of February 3, 2023 for general corporate purposes, including liquidity support for the Company’s commercial paper program, and includes a letter of credit sub-facility of up to $0.5 billion and a swing-line loan sub-facility of up to $0.5 billion.  The 2021 Revolving Credit Facility also allows the Company to obtain incremental additional commitments on one or more occasions in minimum amounts of $10 million.

[0001571996-23-000007:notes:219]
Borrowings under the 2021 Revolving Credit Facility bear interest at a rate per annum equal to an applicable margin plus, at the borrowers’ option, either (a) the specified adjusted term Secured Overnight Financing Rate (“SOFR”) or (b) a base rate.  The margin applicable to SOFR and base rate borrowings varies based upon the Company’s existing date ratings.  The base rate is calculated based upon the greatest of the specified prime rate, the specified federal reserve bank rate, or SOFR plus 1%.  The borrowers may voluntarily repay outstanding loans under the 2021 Revolving Credit Facility at any time without premium or penalty, other than customary breakage costs.

[0001571996-23-000007:notes:220]
As of February 3, 2023, available borrowings under the 2021 Revolving Credit Facility totaled $6.0 billion.

[0001571996-23-000007:notes:221]
The Company may purchase, redeem, prepay, refinance, or otherwise retire any amount of outstanding indebtedness under the terms of such indebtedness at any time and from time to time, in open market or negotiated transactions with the holders of such indebtedness or otherwise, as considered appropriate in light of market conditions and other relevant factors.

[0001571996-23-000007:notes:222]
Covenants — The credit agreement governing the 2021 Revolving Credit Facility and the indentures governing the Senior Notes and the Legacy Notes and Debentures impose various limitations, subject to exceptions, on creating certain liens and entering into sale and lease-back transactions.  The foregoing credit agreement and indentures contain customary events of default, including failure to make required payments, failure to comply with covenants, and the occurrence of certain events of bankruptcy and insolvency.  The 2021 Revolving Credit Facility is also subject to an interest coverage ratio covenant that is tested at the end of each fiscal quarter with respect to the Company’s preceding four fiscal quarters.  The Company was in compliance with this financial covenant as of February 3, 2023.

[0001571996-23-000007:notes:223]
Aggregate Future Maturities

[0001571996-23-000007:notes:224]
The following table presents the aggregate future maturities of the Company’s debt as of February 3, 2023 for the periods indicated:

[0001571996-23-000007:notes:225]
|  | Maturities by Fiscal Year |
|  | 2024 |  | 2025 |  | 2026 |  | 2027 |  | 2028 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Notes | $ | 1,000 |  |  | $ | 1,000 |  |  | $ | 1,000 |  |  | $ | 6,250 |  |  | $ | 500 |  |  | $ | 8,550 |  |  | $ | 18,300 |  |
| Legacy Notes and Debentures | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 952 |  |  | 952 |  |
| DFS Debt | 5,400 |  |  | 3,442 |  |  | 305 |  |  | 595 |  |  | 548 |  |  | — |  |  | 10,290 |  |
| Other | 177 |  |  | 116 |  |  | 24 |  |  | 5 |  |  | 3 |  |  | — |  |  | 325 |  |
| Total maturities, principal amount | 6,577 |  |  | 4,558 |  |  | 1,329 |  |  | 6,850 |  |  | 1,051 |  |  | 9,502 |  |  | 29,867 |  |
| Associated carrying value adjustments | (4) |  |  | (8) |  |  | (2) |  |  | (54) |  |  | (5) |  |  | (206) |  |  | (279) |  |
| Total maturities, carrying value amount | $ | 6,573 |  |  | $ | 4,550 |  |  | $ | 1,327 |  |  | $ | 6,796 |  |  | $ | 1,046 |  |  | $ | 9,296 |  |  | $ | 29,588 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001571996-23-000007:notes:226]
DERIVATIVE INSTRUMENTS AND HEDGING ACTIVITIES 
As part of its risk management strategy, the Company uses derivative instruments, primarily foreign currency forward and option contracts and interest rate swaps, to hedge certain foreign currency and interest rate exposures, respectively.

[0001571996-23-000007:notes:227]
The Company’s objective is to offset gains and losses resulting from these exposures with gains and losses on the derivative contracts used to hedge the exposures, thereby reducing volatility of earnings and protecting the fair values of assets and liabilities.  The earnings effects of the derivative instruments are presented in the same income statement line items as the earnings effects of the hedged items.  For derivatives designated as cash flow hedges, the Company assesses hedge effectiveness both at the onset of the hedge and at regular intervals throughout the life of the instruments.  For derivatives designated as fair value hedges, the Company assesses hedge effectiveness on qualifying instruments using the shortcut method whereby the hedges are considered perfectly effective at the onset of the hedge and over the life of the hedging relationship.

[0001571996-23-000007:notes:228]
Foreign Exchange Risk

[0001571996-23-000007:notes:229]
The Company uses foreign currency forward and option contracts designated as cash flow hedges to protect against the foreign currency exchange rate risks inherent in its forecasted transactions denominated in currencies other than the U.S. Dollar.  Hedge accounting is applied based upon the criteria established by accounting guidance for derivative instruments and hedging activities.  The risk of loss associated with purchased options is limited to premium amounts paid for the option contracts.  The risk of loss associated with forward contracts is equal to the exchange rate differential from the time the contract is entered into until the time it is settled.  The majority of these contracts typically expire in twelve months or less.

[0001571996-23-000007:notes:230]
During the fiscal years ended February 3, 2023, January 28, 2022, and January 29, 2021, the Company did not discontinue any cash flow hedges related to foreign exchange contracts that had a material impact on the Company’s results of operations due to the probability that the forecasted cash flows would not occur.

[0001571996-23-000007:notes:231]
The Company uses forward contracts to hedge monetary assets and liabilities denominated in a foreign currency.  These contracts generally expire in three months or less, are considered economic hedges, and are not designated for hedge accounting.  The change in the fair value of these instruments represents a natural hedge as their gains and losses offset the changes in the underlying fair value of the monetary assets and liabilities due to movements in currency exchange rates.

[0001571996-23-000007:notes:232]
In connection with DFS operations in Europe, forward contracts are used to hedge financing receivables denominated in foreign currencies other than Euro.  These contracts are not designated for hedge accounting and most expire within three years or less.

[0001571996-23-000007:notes:233]
Interest Rate Risk

[0001571996-23-000007:notes:234]
The Company uses interest rate swaps to hedge the variability in cash flows related to the interest rate payments on structured financing debt.  The interest rate swaps economically convert the variable rate on the structured financing debt to a fixed interest rate to match the underlying fixed rate being received on fixed-term customer leases and loans.  These contracts are not designated for hedge accounting and most expire within four years or less.

[0001571996-23-000007:notes:235]
Interest rate swaps are utilized to manage the interest rate risk, at a portfolio level, associated with DFS operations in Europe.  The interest rate swaps economically convert the fixed rate on financing receivables to a three-month Euribor floating rate in order to match the floating rate nature of the banks’ funding pool.  The Company also uses interest rate swaps to manage the cash flows related to interest payments on Eurobonds.  The interest rate swaps economically convert the fixed rate on its bonds to a floating rate to match the underlying lease repayments profile.  None of these contracts are designated for hedge accounting and most expire within five years or less.

[0001571996-23-000007:notes:236]
The Company utilizes cross-currency amortizing swaps to hedge the currency and interest rate risk exposure associated with the European securitization program.  The cross-currency swaps combine a Euro-based interest rate swap with a British Pound or U.S. Dollar foreign exchange forward contract in which the Company pays a fixed or floating British Pound or U.S. Dollar amount and receives a fixed or floating amount in Euros linked to the one-month Euribor.  The notional value of the swaps amortizes in line with the expected cash flows and run-off of the securitized assets.  The swaps are not designated for hedge accounting and expire within five years or less.

[0001571996-23-000007:notes:237]
Periodically, the Company also uses interest rate swaps to modify the market risk exposures in connection with long-term debt.  During the fiscal year ended February 3, 2023, the Company entered into interest rate swaps designated as fair value hedges intended to hedge a portion of its interest rate exposure by converting the fixed interest rate of a certain tranche of debt to a floating interest rate based on the benchmark SOFR Overnight Index Swap rate.  As of February 3, 2023, the carrying amount of the hedged debt was $1 billion.  The gains and losses related to changes in the fair value of the interest rate swaps perfectly offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in the underlying benchmark interest rate.  During the fiscal year ended February 3, 2023, the cumulative amount of fair value hedge accounting adjustments was immaterial.  These contracts expire within four years.

[0001571996-23-000007:notes:238]
Derivative Instruments

[0001571996-23-000007:notes:239]
The following table presents the notional amounts of outstanding derivative instruments as of the dates indicated:

[0001571996-23-000007:notes:240]
|  | February 3, 2023 |  | January 28, 2022 |
|  | (in millions) |
| Foreign exchange contracts: |  |  |  |
| Designated as cash flow hedging instruments | $ | 7,746 |  |  | $ | 7,879 |  |
| Non-designated as hedging instruments | 6,833 |  |  | 8,713 |  |
| Total | $ | 14,579 |  |  | $ | 16,592 |  |
| Interest rate contracts: |  |  |  |
| Designated as fair value hedging instruments | $ | 1,000 |  |  | $ | — |  |
| Non-designated as hedging instruments | 7,214 |  |  | 6,715 |  |
| Total | $ | 8,214 |  |  | $ | 6,715 |  |

[0001571996-23-000007:notes:241]
The following table presents the effect of derivative instruments designated as cash flow hedging instruments on the Consolidated Statements of Financial Position and the Consolidated Statements of Income for the periods indicated:

[0001571996-23-000007:notes:242]
| Derivatives in Cash Flow Hedging Relationships |  | Gain (Loss) Recognized in Accumulated OCI, Net of Tax, on Derivatives |  | Location of Gain (Loss) Reclassified from Accumulated OCI into Income |  | Gain (Loss) Reclassified from Accumulated OCI into Income |
|  |  | (in millions) |  |  |  | (in millions) |
| For the fiscal year ended February 3, 2023: |
|  |  |  |  | Total net revenue |  | $ | 736 |  |
| Foreign exchange contracts |  | $ | 354 |  |  | Total cost of net revenue |  | (31) |  |
| Total |  | $ | 354 |  |  | Total |  | $ | 705 |  |
| For the fiscal year ended January 28, 2022: |
|  |  |  |  | Total net revenue |  | $ | 158 |  |
|  |  |  |  | Total cost of net revenue |  | (3) |  |
| Foreign exchange contracts |  | $ | 374 |  |  | Income from discontinued operations |  | 3 |  |
| Total |  | $ | 374 |  |  | Total |  | $ | 158 |  |
| For the fiscal year ended January 29, 2021 |
|  |  |  |  | Total net revenue |  | $ | (98) |  |
|  |  |  |  | Total cost of net revenue |  | 5 |  |
| Foreign exchange contracts |  | $ | (200) |  |  | Income from discontinued operations |  | (7) |  |
| Total |  | $ | (200) |  |  | Total |  | $ | (100) |  |

[0001571996-23-000007:notes:243]
The following table presents the effect of derivative instruments not designated as hedging instruments on the Consolidated Statements of Income as of the dates indicated:

[0001571996-23-000007:notes:244]
|  |  |  | Fiscal Year Ended |  |  |
|  |  |  |  |  | February 3, 2023 |  | January 28, 2022 |  | January 29, 2021 |  | Location of Gain (Loss) Recognized |
|  |  |  |  |  | (in millions) |  |  |
| Foreign exchange contracts |  |  |  |  | $ | (174) |  |  | $ | (469) |  |  | $ | 169 |  |  | Interest and other, net |
| Interest rate contracts |  |  |  |  | 50 |  |  | 10 |  |  | (45) |  |  | Interest and other, net |
| Foreign exchange contracts |  |  |  |  | — |  |  | 26 |  |  | (62) |  |  | Income from discontinued operations |
| Total |  |  |  |  | $ | (124) |  |  | $ | (433) |  |  | $ | 62 |  |  |  |

[0001571996-23-000007:notes:245]
The Company presents its derivative instruments on a net basis in the Consolidated Statements of Financial Position due to the right of offset by its counterparties under master netting arrangements.  The following tables present the fair value of those derivative instruments presented on a gross basis as of the dates indicated:

[0001571996-23-000007:notes:246]
|  | February 3, 2023 |
|  | Other CurrentAssets |  | Other Non-Current Assets |  | Other CurrentLiabilities |  | Other Non-CurrentLiabilities |  | TotalFair Value |
|  | (in millions) |
| Derivatives designated as hedging instruments: |
| Foreign exchange contracts in an asset position | $ | 7 |  |  | $ | — |  |  | $ | 30 |  |  | $ | — |  |  | $ | 37 |  |
| Foreign exchange contracts in a liability position | (21) |  |  | — |  |  | (142) |  |  | — |  |  | (163) |  |
| Interest rate contracts in an asset position | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Interest rate contracts in a liability position | — |  |  | — |  |  | — |  |  | (6) |  |  | (6) |  |
| Net asset (liability) | (14) |  |  | — |  |  | (112) |  |  | (6) |  |  | (132) |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts in an asset position | 282 |  |  | 1 |  |  | 368 |  |  | — |  |  | 651 |  |
| Foreign exchange contracts in a liability position | (121) |  |  | — |  |  | (614) |  |  | (1) |  |  | (736) |  |
| Interest rate contracts in an asset position | 14 |  |  | 133 |  |  | — |  |  | — |  |  | 147 |  |
| Interest rate contracts in a liability position | — |  |  | — |  |  | — |  |  | (95) |  |  | (95) |  |
| Net asset (liability) | 175 |  |  | 134 |  |  | (246) |  |  | (96) |  |  | (33) |  |
| Total derivatives at fair value | $ | 161 |  |  | $ | 134 |  |  | $ | (358) |  |  | $ | (102) |  |  | $ | (165) |  |
|  | January 28, 2022 |
|  | Other CurrentAssets |  | Other Non-Current Assets |  | Other CurrentLiabilities |  | Other Non-CurrentLiabilities |  | TotalFair Value |
|  | (in millions) |
| Derivatives designated as hedging instruments: |
| Foreign exchange contracts in an asset position | $ | 135 |  |  | $ | — |  |  | $ | 50 |  |  | $ | — |  |  | $ | 185 |  |
| Foreign exchange contracts in a liability position | (5) |  |  | — |  |  | (8) |  |  | — |  |  | (13) |  |
| Net asset | 130 |  |  | — |  |  | 42 |  |  | — |  |  | 172 |  |
| Derivatives not designated as hedging instruments: |
| Foreign exchange contracts in an asset position | 280 |  |  | 2 |  |  | 106 |  |  | — |  |  | 388 |  |
| Foreign exchange contracts in a liability position | (189) |  |  | — |  |  | (244) |  |  | (5) |  |  | (438) |  |
| Interest rate contracts in an asset position | — |  |  | 30 |  |  | — |  |  | — |  |  | 30 |  |
| Interest rate contracts in a liability position | — |  |  | — |  |  | — |  |  | (37) |  |  | (37) |  |
| Net asset (liability) | 91 |  |  | 32 |  |  | (138) |  |  | (42) |  |  | (57) |  |
| Total derivatives at fair value | $ | 221 |  |  | $ | 32 |  |  | $ | (96) |  |  | $ | (42) |  |  | $ | 115 |  |

[0001571996-23-000007:notes:247]
The following tables present the gross amounts of the Company’s derivative instruments, amounts offset due to master netting agreements with the Company’s counterparties, and the net amounts recognized in the Consolidated Statements of Financial Position as of the dates indicated:

[0001571996-23-000007:notes:248]
|  | February 3, 2023 |
|  | Gross Amounts of Recognized Assets/ (Liabilities) |  | Gross Amounts Offset in the Statement of Financial Position |  | Net Amounts of Assets/ (Liabilities) Presented in the Statement of Financial Position |  | Gross Amounts not Offset in the Statement of Financial Position |  | Net Amount of Assets/ (Liabilities) Recognized in the Statement of Financial Position |
|  | Financial Instruments |  | Cash Collateral Received or Pledged |  |
|  | (in millions) |
| Derivative instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Financial assets | $ | 835 |  |  | $ | (540) |  |  | $ | 295 |  |  | $ | — |  |  | $ | — |  |  | $ | 295 |  |
| Financial liabilities | (1,000) |  |  | 540 |  |  | (460) |  |  | — |  |  | 25 |  |  | (435) |  |
| Total derivative instruments | $ | (165) |  |  | $ | — |  |  | $ | (165) |  |  | $ | — |  |  | $ | 25 |  |  | $ | (140) |  |
|  | January 28, 2022 |
|  | Gross Amounts of Recognized Assets/ (Liabilities) |  | Gross Amounts Offset in the Statement of Financial Position |  | Net Amounts of Assets/ (Liabilities) Presented in the Statement of Financial Position |  | Gross Amounts not Offset in the Statement of Financial Position |  | Net Amount of Assets/ (Liabilities) Recognized in the Statement of Financial Position |
|  | Financial Instruments |  | Cash Collateral Received or Pledged |  |
|  | (in millions) |
| Derivative instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Financial assets | $ | 603 |  |  | $ | (350) |  |  | $ | 253 |  |  | $ | — |  |  | $ | — |  |  | $ | 253 |  |
| Financial liabilities | (488) |  |  | 350 |  |  | (138) |  |  | — |  |  | 24 |  |  | (114) |  |
| Total derivative instruments | $ | 115 |  |  | $ | — |  |  | $ | 115 |  |  | $ | — |  |  | $ | 24 |  |  | $ | 139 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001571996-23-000007:notes:249]
GOODWILL AND INTANGIBLE ASSETS
Goodwill

[0001571996-23-000007:notes:250]
The Infrastructure Solutions Group and Client Solutions Group reporting units are consistent with the reportable segments identified in Note 19 of the Notes to the Consolidated Financial Statements.  Other businesses consists of VMware Resale, Secureworks, and Virtustream, which each represent separate reporting units.

[0001571996-23-000007:notes:251]
The following table presents goodwill allocated to the Company’s reportable segments and changes in the carrying amount of goodwill as of the dates indicated:

[0001571996-23-000007:notes:252]
|  | Infrastructure Solutions Group |  | Client Solutions Group |  | Other Businesses |  | Total |
|  | (in millions) |
| Balances as of January 29, 2021 | $ | 15,325 |  |  | $ | 4,237 |  |  | $ | 466 |  |  | $ | 20,028 |  |
| Impact of foreign currency translation | (219) |  |  | — |  |  | — |  |  | (219) |  |
| Goodwill divested | — |  |  | — |  |  | (39) |  |  | (39) |  |
| Balances as of January 28, 2022 | $ | 15,106 |  |  | $ | 4,237 |  |  | $ | 427 |  |  | $ | 19,770 |  |
| Goodwill acquired | 48 |  |  | — |  |  | — |  |  | 48 |  |
| Impact of foreign currency translation and other | (137) |  |  | (5) |  |  | — |  |  | (142) |  |
| Balances as of February 3, 2023 | $ | 15,017 |  |  | $ | 4,232 |  |  | $ | 427 |  |  | $ | 19,676 |  |

[0001571996-23-000007:notes:253]
Intangible Assets

[0001571996-23-000007:notes:254]
The following table presents the Company’s intangible assets as of the dates indicated:

[0001571996-23-000007:notes:255]
|  | February 3, 2023 |  | January 28, 2022 |
|  | Gross |  | AccumulatedAmortization |  | Net |  | Gross |  | AccumulatedAmortization |  | Net |
|  | (in millions) |
| Customer relationships | $ | 16,956 |  |  | $ | (14,474) |  |  | $ | 2,482 |  |  | $ | 16,956 |  |  | $ | (13,938) |  |  | $ | 3,018 |  |
| Developed technology | 9,466 |  |  | (8,660) |  |  | 806 |  |  | 9,635 |  |  | (8,405) |  |  | 1,230 |  |
| Trade names | 875 |  |  | (780) |  |  | 95 |  |  | 885 |  |  | (757) |  |  | 128 |  |
| Definite-lived intangible assets | 27,297 |  |  | (23,914) |  |  | 3,383 |  |  | 27,476 |  |  | (23,100) |  |  | 4,376 |  |
| Indefinite-lived trade names | 3,085 |  |  | — |  |  | 3,085 |  |  | 3,085 |  |  | — |  |  | 3,085 |  |
| Total intangible assets | $ | 30,382 |  |  | $ | (23,914) |  |  | $ | 6,468 |  |  | $ | 30,561 |  |  | $ | (23,100) |  |  | $ | 7,461 |  |

[0001571996-23-000007:notes:256]
Amortization expense related to definite-lived intangible assets was $1.0 billion, $1.6 billion, and $2.1 billion for the fiscal years ended February 3, 2023, January 28, 2022, and January 29, 2021, respectively.  There were no material impairment charges related to intangible assets during the fiscal years ended February 3, 2023, January 28, 2022, and January 29, 2021.

[0001571996-23-000007:notes:257]
The following table presents the estimated future annual pre-tax amortization expense of definite-lived intangible assets as of the date indicated:

[0001571996-23-000007:notes:258]
|  | February 3, 2023 |
|  | (in millions) |
| Fiscal 2024 | $ | 764 |  |
| Fiscal 2025 | 599 |  |
| Fiscal 2026 | 472 |  |
| Fiscal 2027 | 364 |  |
| Fiscal 2028 | 268 |  |
| Thereafter | 916 |  |
| Total | $ | 3,383 |  |

[0001571996-23-000007:notes:259]
Goodwill and Indefinite-Lived Intangible Assets Impairment Testing

[0001571996-23-000007:notes:260]
Goodwill and indefinite-lived intangible assets are tested for impairment annually during the third fiscal quarter and whenever events or circumstances may indicate that an impairment has occurred.

[0001571996-23-000007:notes:261]
For the annual impairment review during the third quarter of Fiscal 2023, the Company elected to bypass the assessment of qualitative factors to determine whether it was more likely than not that the fair value of a reporting unit was less than its carrying amount, including goodwill.  In electing to bypass the qualitative assessment, the Company proceeded directly to perform a quantitative goodwill impairment test to measure the fair value of each goodwill reporting unit relative to its carrying amount, and to determine the amount of goodwill impairment loss to be recognized, if any.

[0001571996-23-000007:notes:262]
Management exercised significant judgment related to the above assessment, including the identification of goodwill reporting units, assignment of assets and liabilities to goodwill reporting units, assignment of goodwill to reporting units, and determination of the fair value of each goodwill reporting unit.  The fair value of each goodwill reporting unit is generally estimated using a combination of public company multiples and discounted cash flow methodologies.  The discounted cash flow and public company multiples methodologies require significant judgment, including estimation of future revenues, gross margins, and operating expenses, which are dependent on internal forecasts, current and anticipated economic conditions and trends, selection of market multiples through assessment of the reporting unit’s performance relative to peer competitors, the estimation of the long-term revenue growth rate and discount rate of the Company’s business, and the determination of the Company’s weighted average cost of capital.  Changes in these estimates and assumptions could materially affect the fair value of the goodwill reporting unit, potentially resulting in a non-cash impairment charge.

[0001571996-23-000007:notes:263]
The fair value of the indefinite-lived trade names is generally estimated using discounted cash flow methodologies.  These methodologies require significant judgment, including estimation of future revenue, the estimation of the long-term revenue growth rate of the Company’s business and the determination of the Company’s weighted average cost of capital and royalty rates.  Changes in these estimates and assumptions could materially affect the fair value of the indefinite-lived intangible assets, potentially resulting in a non-cash impairment charge.

[0001571996-23-000007:notes:264]
Based on the results of the annual impairment test performed during the fiscal year ended February 3, 2023, the fair values of each of the reporting units exceeded their carrying values.  No goodwill impairment test was performed during the fiscal year ended February 3, 2023 other than the Company’s annual impairment review.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001571996-23-000007:notes:265]
DEFERRED REVENUE 
Deferred Revenue — Deferred revenue consists of support and deployment services, software maintenance, training, Software-as-a-Service, and undelivered hardware and professional services, consisting of installations and consulting engagements.  Deferred revenue is recorded when the Company has invoiced or payments have been received for undelivered products or services where transfer of control has not occurred.  Revenue is recognized as the Company’s performance obligations under the contract are completed.

[0001571996-23-000007:notes:266]
The following table presents the changes in the Company’s deferred revenue for the periods indicated:

[0001571996-23-000007:notes:267]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  | February 3, 2023 |  | January 28, 2022 |
|  |  |  |  |  | (in millions) |
| Deferred revenue: |  |  |  |  |  |  |  |
| Deferred revenue at beginning of period |  |  |  |  | $ | 27,573 |  |  | $ | 25,592 |  |
| Revenue deferrals |  |  |  |  | 23,166 |  |  | 20,968 |  |
| Revenue recognized |  |  |  |  | (20,288) |  |  | (18,843) |  |
| Other (a) |  |  |  |  | (165) |  |  | (144) |  |
| Deferred revenue at end of period |  |  |  |  | $ | 30,286 |  |  | $ | 27,573 |  |
| Short-term deferred revenue |  |  |  |  | $ | 15,542 |  |  | $ | 14,261 |  |
| Long-term deferred revenue |  |  |  |  | $ | 14,744 |  |  | $ | 13,312 |  |

[0001571996-23-000007:notes:268]
(a)    For the fiscal year ended February 3, 2023, Other represents the reclassification of deferred revenue to accrued and other liabilities.  For the fiscal year ended January 28, 2022, Other consists of divested deferred revenue from the sale of Boomi.  See Note 1 of the Notes to the Consolidated Financial Statements for more information about the divestiture of Boomi.

[0001571996-23-000007:notes:269]
Remaining Performance Obligations — Remaining performance obligations represent the aggregate amount of the transaction price allocated to performance obligations not delivered, or partially undelivered, as of the end of the reporting period.  Remaining performance obligations include deferred revenue plus unbilled amounts not yet recorded in deferred revenue.  The value of the transaction price allocated to remaining performance obligations as of February 3, 2023 was approximately $40 billion.  The Company expects to recognize approximately 57% of remaining performance obligations as revenue in the next twelve months, and the remainder thereafter.

[0001571996-23-000007:notes:270]
The aggregate amount of the transaction price allocated to remaining performance obligations does not include amounts owed under cancelable contracts where there is no substantive termination penalty.  The Company applied the practical expedient to exclude the value of remaining performance obligations for contracts for which revenue is recognized at the amount to which the Company has the right to invoice for services performed.

[0001571996-23-000007:notes:271]
Remaining performance obligation estimates are subject to change and are affected by several factors, including terminations, changes in the scope of contracts, periodic revalidation, adjustments for revenue that have not materialized, and adjustments for currency.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001571996-23-000007:notes:272]
COMMITMENTS AND CONTINGENCIES 
Purchase Obligations

[0001571996-23-000007:notes:273]
The Company has contractual obligations to purchase goods or services, which specify significant terms (including fixed or minimum quantities to be purchased), fixed, minimum, or variable price provisions; and the approximate timing of the transaction.  As of February 3, 2023, such purchase obligations were $3.5 billion for Fiscal 2024; $0.4 billion for Fiscal 2025; $0.2 billion for Fiscal 2026; $0.2 billion for Fiscal 2027; $0.1 billion for Fiscal 2028; and immaterial thereafter.

[0001571996-23-000007:notes:274]
Legal Matters

[0001571996-23-000007:notes:275]
The Company is involved in various claims, suits, assessments, investigations, and legal proceedings that arise from time to time in the ordinary course of its business, including those identified below, consisting of matters involving consumer, antitrust, tax, intellectual property, and other issues on a global basis.  Pursuant to the Separation and Distribution Agreement referred to below, Dell Technologies shares responsibility with VMware for certain matters, as indicated below, and VMware has agreed to indemnify Dell Technologies in whole or in part with respect to certain matters.

[0001571996-23-000007:notes:276]
The Company accrues a liability when it believes that it is both probable that a liability has been incurred and that it can reasonably estimate the amount of the loss.  The Company reviews these accruals at least quarterly and adjusts them to reflect ongoing negotiations, settlements, rulings, advice of legal counsel, and other relevant information.  To the extent new information is obtained and the Company’s views on the probable outcomes of claims, suits, assessments, investigations, or legal proceedings change, changes in the Company’s accrued liabilities are recorded in the period in which such a determination is made.  For some matters, the incurrence of a liability is not probable or the amount cannot be reasonably estimated and therefore accruals have not been made.

[0001571996-23-000007:notes:277]
The following is a discussion of the Company’s significant legal matters and other proceedings:

[0001571996-23-000007:notes:278]
Class Actions Related to the Class V Transaction — On December 28, 2018, the Company completed a transaction (the “Class V transaction”) in which it paid $14.0 billion in cash and issued 149,387,617 shares of its Class C Common Stock to holders of its Class V Common Stock in exchange for all outstanding shares of Class V Common Stock.  As a result of the Class V transaction, the tracking stock feature of the Company’s capital structure associated with the Class V Common Stock was terminated.  In November 2018, four purported stockholders brought putative class action complaints arising out of the Class V transaction.  The actions were captioned Hallandale Beach Police and Fire Retirement Plan v. Michael Dell et al. (Civil Action No. 2018-0816-JTL), Howard Karp v. Michael Dell et al. (Civil Action No. 2019-0032-JTL), Miramar Police Officers’ Retirement Plan v. Michael Dell et al. (Civil Action No. 2019-0049-JTL), and Steamfitters Local 449 Pension Plan v. Michael Dell et al. (Civil Action No. 2019-0115-JTL).  The four actions were consolidated in the Delaware Chancery Court into In Re Dell Class V Litigation (Consol. C.A. No. 2018-0816-JTL).  The suit currently names as defendants Michael S. Dell and certain of the other directors serving on the Board of Directors at the time of the Class V transaction, certain stockholders of the Company, consisting of Michael S. Dell and Silver Lake Group LLC and certain of its affiliated funds, and Goldman Sachs & Co. LLC (“Goldman Sachs”), which served as financial advisor to the Company in connection with the Class V transaction.  In an amended complaint filed in August 2019, the plaintiffs generally allege that the director and stockholder defendants breached their fiduciary duties under Delaware law to the former holders of Class V Common Stock in connection with the Class V transaction by offering a transaction value that was allegedly billions of dollars below the fair value.  The plaintiffs contend that the offer understated the value of shares surrendered by the former stockholders, which the plaintiffs allege should have reflected higher alternative valuations, including a valuation related to the value of the shares of VMware, Inc. common stock, and that the difference in values was wrongfully appropriated by the stockholder defendants.  On August 20, 2021, the plaintiffs added Goldman Sachs as a defendant and allege that it aided and abetted the alleged primary violations.  The Company is not a defendant in this action but is subject to director indemnification provisions under its certificate of incorporation and bylaws, and is a party to agreements with the defendants that contain indemnification obligations of the Company, conditioned on the satisfaction of the requirements set forth in such agreements, relating to service as a director, ownership of the Company’s securities, and provision of services, as applicable.  In the complaint, the plaintiffs seek, among other remedies, a judicial declaration that the director and stockholder defendants breached their fiduciary duties.  The plaintiffs also seek in the complaint disgorgement of all profits, benefits, and other compensation obtained by the defendants as a result of such alleged conduct and an award of unspecified damages, fees, and costs.  The defendants filed a motion to dismiss the action in September 2019.  The court denied the motion in June 2020.  The plaintiffs and the defendants agreed to settle this

[0001571996-23-000007:notes:279]
action, subject to court approval, in November 2022.  Under the terms of the settlement, the plaintiffs have agreed to dismissal of all claims upon payment of a total of $1.0 billion (the “settlement amount”), which amount will include all costs, expenses and fees of the plaintiff class relating to the action and its resolution.  The settlement terms provide that it is a condition of the settlement that the settlement amount will be paid by the Company and/or the Company’s insurers on behalf of the defendants pursuant to indemnification obligations of the Company to the defendants.  A special committee of the Company’s board of directors composed of directors who are not defendants, advised by independent counsel, has informed the board of directors that the committee has determined that the director defendants and the stockholder defendants are entitled to such indemnification.  The Company is subject to indemnification obligations pursuant to the provisions of the Delaware General Corporation Law, the terms of the Company’s certificate of incorporation and bylaws, and agreements with the defendants.  The settlement is conditioned on final approval of the settlement by the court.  If the court does not grant final approval of the settlement and all of its material terms, or the settlement does not otherwise become final or effective, proceedings in the action will continue.  The hearing for final approval of the settlement is scheduled for April 19, 2023.  During the fiscal year ended February 3, 2023, the Company established a $1.0 billion liability on the Consolidated Statements of Financial Position and recognized $1.0 billion expense within interest and other, net within the Consolidated Statements of Income related to the settlement agreement.  The Company expects to recover $106 million in insurance proceeds related to the settlement agreement, with cash proceeds to be received upon payment of the settlement.  The Company accounted for the expected insurance proceeds as a loss recovery and recognized a benefit within interest and other, net within the Consolidated Statements of Income and corresponding receivable on the Consolidated Statements of Financial Position.  Pending final approval of the settlement by the court, payment would be made in the Company’s second quarter of Fiscal 2024.

[0001571996-23-000007:notes:280]
Other Litigation — Dell does not currently anticipate that any of the other various legal proceedings it is involved in will have a material adverse effect on its business, financial condition, results of operations, or cash flows.

[0001571996-23-000007:notes:281]
In accordance with the relevant accounting guidance, the Company provides disclosures of matters where it is at least reasonably possible that the Company could experience a material loss exceeding the amounts already accrued for these or other proceedings or matters.  In addition, the Company also discloses matters based on its consideration of other matters and qualitative factors, including the experience of other companies in the industry, and investor, customer, and employee relations considerations.  As of February 3, 2023, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for these or other proceedings or matters has been incurred.  However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company’s business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters.  Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company’s business, financial condition, results of operations, or cash flows will depend on a number of factors, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.

[0001571996-23-000007:notes:282]
Indemnifications Obligations

[0001571996-23-000007:notes:283]
In the ordinary course of business, the Company enters into various contracts under which it may agree to indemnify other parties for losses incurred from certain events as defined in the relevant contract, such as litigation, regulatory penalties, or claims relating to past performance.  Such indemnification obligations may not be subject to maximum loss clauses.  Historically, payments related to these indemnification obligations have not been material to the Company.

[0001571996-23-000007:notes:284]
Under the Separation and Distribution Agreement described in Note 3 of the Notes to the Consolidated Financial Statements, Dell Technologies has agreed to indemnify VMware, Inc., each of its subsidiaries and each of their respective directors, officers, and employees from and against all liabilities relating to, arising out of or resulting from, among other matters, the liabilities allocated to Dell Technologies as part of the separation of  Dell Technologies and VMware and their respective businesses as a result of the VMware Spin-off (the “Separation”).  VMware similarly has agreed to indemnify Dell Technologies Inc., each of its subsidiaries and each of their respective directors, officers, and employees from and against all liabilities relating to, arising out of or resulting from, among other matters, the liabilities allocated to VMware as part of the Separation.  Dell Technologies expects VMware to fully perform under the terms of the Separation and Distribution Agreement.

[0001571996-23-000007:notes:285]
For information on the cross-indemnifications related to the tax matters agreement between the Company and VMware described in Note 3 of the Notes to the Consolidated Financial Statements effective upon the Separation on November 1, 2021, see Note 3 and Note 21 of the Notes to the Consolidated Financial Statements.

[0001571996-23-000007:notes:286]
Certain Concentrations

[0001571996-23-000007:notes:287]
The Company maintains cash and cash equivalents, derivatives, and certain other financial instruments with various financial institutions that potentially subject it to concentration of credit risk.  As part of its risk management processes, the Company performs periodic evaluations of the relative credit standing of these financial institutions.  The Company has not sustained material credit losses from instruments held at these financial institutions.  Further, the Company does not anticipate nonperformance by any of the counterparties.

[0001571996-23-000007:notes:288]
The Company markets and sells its products and services to large corporate clients, governments, and health care and education accounts, as well as to small and medium-sized businesses and individuals.  No single customer accounted for more than 10% of the Company’s consolidated net revenue during the fiscal year ended February 3, 2023, January 28, 2022, and January 29, 2021.

[0001571996-23-000007:notes:289]
The Company utilizes a limited number of contract manufacturers that assemble a portion of its products.  The Company purchases components from suppliers and sells those components to such contract manufacturers.  The Company reflects the sale of such components by recognizing non-trade receivables from the contract manufacturers and a reduction in inventory when title and risk of loss passes to the manufacturer.  Cash flows related to such transactions are recorded within cash flows from operating activities.  The Company does not reflect the sale of the components in revenue and does not recognize any profit on the component sales until the related products are sold.
The agreements with the majority of the contract manufacturers permit the Company to offset its payables against the receivables, thus mitigating the credit risk wholly or in part.  Receivables from the Company’s four largest contract manufacturers represented the majority of the Company’s gross non-trade receivables of $3.3 billion and $5.7 billion as of February 3, 2023 and January 28, 2022, respectively.  The Company offset its corresponding payables against $2.5 billion and $4.2 billion of such receivables as of February 3, 2023 and January 28, 2022, respectively.  The portion of receivables not offset is included in other current assets in the Consolidated Statements of Financial Position.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001571996-23-000007:notes:290]
INCOME AND OTHER TAXES
The following table presents components of the income tax expense (benefit) for continuing operations recognized for the periods indicated:

[0001571996-23-000007:notes:291]
|  | Fiscal Year Ended |
|  | February 3, 2023 |  | January 28, 2022 |  | January 29, 2021 |
|  | (in millions) |
| Current: |  |  |  |  |  |
| Federal | $ | 605 |  |  | $ | 166 |  |  | $ | (514) |  |
| State/local | 176 |  |  | 76 |  |  | (22) |  |
| Foreign | 739 |  |  | 960 |  |  | 825 |  |
| Current | 1,520 |  |  | 1,202 |  |  | 289 |  |
| Deferred: |  |  |  |  |  |
| Federal | (483) |  |  | (54) |  |  | (16) |  |
| State/local | (103) |  |  | — |  |  | (115) |  |
| Foreign | (131) |  |  | (167) |  |  | (57) |  |
| Deferred | (717) |  |  | (221) |  |  | (188) |  |
| Income tax expense | $ | 803 |  |  | $ | 981 |  |  | $ | 101 |  |

[0001571996-23-000007:notes:292]
The following table presents components of income (loss) before income taxes for continuing operations for the periods indicated:

[0001571996-23-000007:notes:293]
|  | Fiscal Year Ended |
|  | February 3, 2023 |  | January 28, 2022 |  | January 29, 2021 |
|  | (in millions) |
| Domestic | $ | (1,316) |  |  | $ | 1,414 |  |  | $ | (1,361) |  |
| Foreign | 4,541 |  |  | 4,509 |  |  | 3,707 |  |
| Income before income taxes | $ | 3,225 |  |  | $ | 5,923 |  |  | $ | 2,346 |  |

[0001571996-23-000007:notes:294]
The following table presents a reconciliation of the Company’s effective tax rate to the statutory U.S. federal tax rate for continuing operations for the periods indicated:

[0001571996-23-000007:notes:295]
|  | Fiscal Year Ended |
|  | February 3, 2023 |  | January 28, 2022 |  | January 29, 2021 |
| U.S. federal statutory rate | 21.0 | % |  | 21.0 | % |  | 21.0 | % |
| State income taxes, net of federal tax benefit | 2.0 |  |  | 1.7 |  |  | (3.5) |  |
| Tax impact of foreign operations | (0.8) |  |  | (0.3) |  |  | 8.9 |  |
| Change in valuation allowance | 0.4 |  |  | 0.4 |  |  | — |  |
| U.S. tax audit settlement | — |  |  | — |  |  | (31.8) |  |
| Non-deductible transaction-related costs | 0.8 |  |  | 1.2 |  |  | 1.0 |  |
| Stock-based compensation expense | (2.4) |  |  | (2.4) |  |  | (3.2) |  |
| U.S. R&D tax credits | (2.6) |  |  | (1.3) |  |  | (2.5) |  |
| Legal entity restructuring | — |  |  | (4.1) |  |  | — |  |
| RSA Security divestiture | — |  |  | — |  |  | 12.3 |  |
| Class V transaction litigation settlement | 5.8 |  |  | — |  |  | — |  |
| Other | 0.7 |  |  | 0.4 |  |  | 2.1 |  |
| Total | 24.9 | % |  | 16.6 | % |  | 4.3 | % |

[0001571996-23-000007:notes:296]
Changes to the Company’s effective tax rates for the fiscal years ended February 3, 2023, January 28, 2022, and January 29, 2021 were primarily driven by items discrete to those years.  The Company’s effective tax rate for the fiscal year ended February 3, 2023 includes the impact of a $0.9 billion expense recognized in connection with an agreement to settle the Class V transaction litigation.  The Company’s effective tax rate for the fiscal year ended January 28, 2022 includes tax expense of $1.0 billion on a pre-tax gain of $4.0 billion related to the divestiture of Boomi during the period, as well as tax benefits of $367 million on $1.6 billion of debt extinguishment fees and $244 million related to the restructuring of certain legal entities.

[0001571996-23-000007:notes:297]
Other changes to the Company’s effective income tax rates for the fiscal years ended February 3, 2023 as compared to January 28, 2022 were attributable to the tax impact of foreign operations, which included the impacts of higher jurisdictional mix of income in lower tax jurisdictions and higher tax benefits from foreign-derived intangible income offset by the impact of the capitalization of research and development costs under the Tax Cuts and Jobs Act.  Under the Tax Cuts and Jobs Act, which was enacted on December 22, 2017, research and development costs incurred for tax years beginning after December 31, 2021 must be capitalized and amortized ratably over five or 15 years for tax purposes, depending on where the research activities were conducted.

[0001571996-23-000007:notes:298]
The differences between the Company’s effective income tax rates and the U.S. federal statutory rate of 21% principally result from the geographical distribution of income, differences between the book and tax treatment of certain items, and the tax items discussed above.  In certain jurisdictions, the Company’s tax rate is significantly less than the applicable statutory rate as a result of tax holidays.  The majority of the Company’s foreign income that is subject to these tax holidays is attributable to Singapore and China.  A significant portion of these income tax benefits relates to a tax holiday that will be effective until January 31, 2029.  The Company’s other tax holidays will expire in whole or in part during fiscal years 2030 through 2031.  Many of these tax holidays and reduced tax rates may be extended when certain conditions are met or may be terminated early if certain conditions are not met or as a result of changes in tax legislation.  As of February 3, 2023, the Company was not aware of any matters of noncompliance related to these tax holidays or enacted tax legislative changes affecting these tax holidays.  For the fiscal years ended February 3, 2023, January 28, 2022, and January 29, 2021, the income tax benefits attributable to the tax status of the affected subsidiaries were estimated to be approximately $123 million ($0.16 per share), $466 million ($0.59 per share), and $359 million ($0.47 per share), respectively.  These income tax benefits are included in tax impact of foreign operations in the table above.

[0001571996-23-000007:notes:299]
The Company believes that a significant portion of the Company’s undistributed earnings as of February 3, 2023 will not be subject to further U.S. federal taxation.  As of February 3, 2023, the Company has undistributed earnings of certain foreign subsidiaries of approximately $36.5 billion that remain indefinitely reinvested, and as such has not recognized a deferred tax liability.  Determination of the amount of unrecognized deferred income tax liability related to these undistributed earnings is not practicable.

[0001571996-23-000007:notes:300]
The following table presents the components of the Company’s net deferred tax assets (liabilities) as of the dates indicated:

[0001571996-23-000007:notes:301]
|  | February 3, 2023 |  | January 28, 2022 |
|  | (in millions) |
| Deferred tax assets: |  |  |  |
| Deferred revenue and warranty provisions | $ | 1,959 |  |  | $ | 1,555 |  |
| Provisions for product returns and doubtful accounts | 85 |  |  | 95 |  |
| Credit carryforwards | 938 |  |  | 1,094 |  |
| Loss carryforwards | 467 |  |  | 379 |  |
| Operating and compensation related accruals | 506 |  |  | 512 |  |
| Capitalized research and development | 263 |  |  | — |  |
| Other | 332 |  |  | 301 |  |
| Deferred tax assets (a) | 4,550 |  |  | 3,936 |  |
| Valuation allowance | (1,535) |  |  | (1,423) |  |
| Deferred tax assets, net of valuation allowance | 3,015 |  |  | 2,513 |  |
| Deferred tax liabilities: |  |  |  |
| Leasing and financing | (363) |  |  | (382) |  |
| Property and equipment | (470) |  |  | (452) |  |
| Intangibles | (483) |  |  | (673) |  |
| Other | (339) |  |  | (363) |  |
| Deferred tax liabilities (a) | (1,655) |  |  | (1,870) |  |
| Net deferred tax assets | $ | 1,360 |  |  | $ | 643 |  |

[0001571996-23-000007:notes:302]
(a)    Deferred tax assets and deferred tax liabilities are included in other non-current assets and other non-current liabilities, respectively, in the Consolidated Statements of Financial Position.

[0001571996-23-000007:notes:303]
The following tables present the net operating loss carryforwards, tax credit carryforwards, and other deferred tax assets with related valuation allowances recognized as of the dates indicated:

[0001571996-23-000007:notes:304]
|  | February 3, 2023 |  |  |
|  | Deferred Tax Assets |  | Valuation Allowance |  | Net Deferred Tax Assets |  | First Year Expiring |
|  | (in millions) |  |  |
| Credit carryforwards | $ | 938 |  |  | $ | (935) |  |  | $ | 3 |  |  | Fiscal 2024 |
| Loss carryforwards | 467 |  |  | (317) |  |  | 150 |  |  | Fiscal 2024 |
| Other deferred tax assets | 3,145 |  |  | (283) |  |  | 2,862 |  |  | NA |
| Total | $ | 4,550 |  |  | $ | (1,535) |  |  | $ | 3,015 |  |  |  |
|  | January 28, 2022 |  |  |
|  | Deferred Tax Assets |  | Valuation Allowance |  | Net Deferred Tax Assets |  | First Year Expiring |
|  | (in millions) |  |  |
| Credit carryforwards | $ | 1,094 |  |  | $ | (917) |  |  | $ | 177 |  |  | Fiscal 2023 |
| Loss carryforwards | 379 |  |  | (276) |  |  | 103 |  |  | Fiscal 2023 |
| Other deferred tax assets | 2,463 |  |  | (230) |  |  | 2,233 |  |  | NA |
| Total | $ | 3,936 |  |  | $ | (1,423) |  |  | $ | 2,513 |  |  |  |

[0001571996-23-000007:notes:305]
The Company’s credit carryforwards as of February 3, 2023 and January 28, 2022 relate primarily to U.S. tax credits and include state and federal tax credits associated with research and development, as well as foreign tax credits associated with the U.S. Tax Cuts and Jobs Act.  The more significant amounts of the Company’s credit carryforwards will begin expiring in fiscal year 2028.  The Company assessed the realizability of these U.S. tax credits and has recorded a valuation allowance against the credits it does not expect to utilize.  The Company’s loss carryforwards as of February 3, 2023 and January 28, 2022 include net operating loss carryforwards from federal, state, and foreign jurisdictions.  The valuation allowances for other deferred tax assets as of February 3, 2023 and January 28, 2022 primarily relate to foreign jurisdictions, the changes in which are included in tax impact of foreign operations in the Company’s effective tax reconciliation.  The Company has determined that it will be able to realize the remainder of its deferred tax assets, based on the future reversal of deferred tax liabilities.

[0001571996-23-000007:notes:306]
The following table presents a reconciliation of the Company’s beginning and ending balances of unrecognized tax benefits for the periods indicated:

[0001571996-23-000007:notes:307]
|  | Fiscal Year Ended |
|  | February 3, 2023 |  | January 28, 2022 |  | January 29, 2021 |
|  | (in millions) |
| Beginning Balance | $ | 1,595 |  |  | $ | 1,620 |  |  | $ | 2,235 |  |
| Increases related to tax positions of the current year | 132 |  |  | 113 |  |  | 102 |  |
| Increases related to tax position of prior years | 181 |  |  | 143 |  |  | 385 |  |
| Reductions for tax positions of prior years | (46) |  |  | (153) |  |  | (673) |  |
| Lapse of statute of limitations | (41) |  |  | (78) |  |  | (27) |  |
| Audit settlements | (9) |  |  | (50) |  |  | (402) |  |
| Ending Balance | $ | 1,812 |  |  | $ | 1,595 |  |  | $ | 1,620 |  |

[0001571996-23-000007:notes:308]
The table does not include accrued interest and penalties of $394 million, $383 million, and $404 million as of February 3, 2023, January 28, 2022, and January 29, 2021, respectively.  Additionally, the table does not include certain tax benefits associated with interest and state tax deductions and other indirect jurisdictional effects of uncertain tax positions, which were $910 million, $817 million, and $835 million as of February 3, 2023, January 28, 2022, and January 29, 2021, respectively.

[0001571996-23-000007:notes:309]
After taking these items into account, the Company’s net unrecognized tax benefits were $1.3 billion, $1.2 billion, and $1.2 billion as of February 3, 2023, January 28, 2022, and January 29, 2021, respectively, and are included in other non-current liabilities in the Consolidated Statements of Financial Position.

[0001571996-23-000007:notes:310]
The unrecognized tax benefits in the table above include $1.1 billion, $0.9 billion, and $0.9 billion as of February 3, 2023, January 28, 2022, and January 29, 2021, respectively, that, if recognized, would have impacted income tax expense.  Interest and penalties related to income tax liabilities are included in income tax expense.  The Company recorded tax expense for interest and penalties of $16 million for the fiscal year ended February 3, 2023, and tax benefit of $14 million and $247 million for the fiscal years ended January 28, 2022 and January 29, 2021, respectively.

[0001571996-23-000007:notes:311]
The Internal Revenue Service is currently conducting tax examinations of the Company for fiscal years 2015 through 2019.  The Company is also currently under income tax audits in various U.S. state and foreign taxing jurisdictions.  The Company is undergoing negotiations, and in some cases contested proceedings, relating to tax matters with the taxing authorities in these jurisdictions.  The Company believes that it has provided adequate reserves related to all matters contained in tax periods open to examination.  Although the Company believes it has made adequate provisions for the uncertainties surrounding these audits, should the Company experience unfavorable outcomes, such outcomes could have a material impact on its results of operations, financial position, and cash flows.  With respect to major U.S. state and foreign taxing jurisdictions, the Company is generally not subject to tax examinations for years prior to the fiscal year ended January 29, 2010.

[0001571996-23-000007:notes:312]
Judgment is required in evaluating the Company’s uncertain tax positions and determining the Company’s provision for income taxes.  The Company does not expect a significant change to the total amount of unrecognized tax benefits within the next twelve months.

[0001571996-23-000007:notes:313]
The Company takes certain non-income tax positions in the jurisdictions in which it operates and has received certain non-income tax assessments from various jurisdictions.  The Company believes that a material loss in these matters is not probable and that it is not reasonably possible that a material loss exceeding amounts already accrued has been incurred.  The Company believes its positions in these non-income tax litigation matters are supportable and that it ultimately will prevail in the matters.  In the normal course of business, the Company’s positions and conclusions related to its non-income taxes could be challenged and assessments may be made.  To the extent new information is obtained and the Company’s views on its positions, probable outcomes of assessments, or litigation change, changes in estimates to the Company’s accrued liabilities would be recorded in the period in which such a determination is made.  In the resolution process for income tax and non-income tax audits, the Company is required in certain situations to provide collateral guarantees or indemnification to regulators and tax authorities until the matter is resolved.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001571996-23-000007:notes:314]
ACCUMULATED OTHER COMPREHENSIVE INCOME (LOSS) 
Accumulated other comprehensive income (loss) is presented in stockholders’ equity (deficit) in the Consolidated Statements of Financial Position and consists of amounts related to foreign currency translation adjustments, unrealized net gains (losses) on cash flow hedges, and actuarial net gains (losses) from pension and other postretirement plans.

[0001571996-23-000007:notes:315]
The following table presents changes in accumulated other comprehensive income (loss), net of tax, by the following components as of the dates indicated:

[0001571996-23-000007:notes:316]
|  | Foreign Currency Translation Adjustments |  |  |  | Cash Flow Hedges |  | Pension and Other Postretirement Plans |  | Accumulated Other Comprehensive Income (Loss) |
|  | (in millions) |
| Balances as of January 31, 2020 | $ | (678) |  |  |  |  | $ | 14 |  |  | $ | (45) |  |  | $ | (709) |  |
| Other comprehensive income (loss) before reclassifications | 528 |  |  |  |  | (200) |  |  | (38) |  |  | 290 |  |
| Amounts reclassified from accumulated other comprehensive income (loss) | — |  |  |  |  | 100 |  |  | 5 |  |  | 105 |  |
| Total change for the period | 528 |  |  |  |  | (100) |  |  | (33) |  |  | 395 |  |
| Balances as of January 29, 2021 | $ | (150) |  |  |  |  | $ | (86) |  |  | $ | (78) |  |  | $ | (314) |  |
| Other comprehensive income (loss) before reclassifications | (385) |  |  |  |  | 374 |  |  | 37 |  |  | 26 |  |
| Amounts reclassified from accumulated other comprehensive income (loss) | — |  |  |  |  | (158) |  |  | 7 |  |  | (151) |  |
| Spin-off of VMware | 9 |  |  |  |  | (1) |  |  | — |  |  | 8 |  |
| Total change for the period | (376) |  |  |  |  | 215 |  |  | 44 |  |  | (117) |  |
| Balances as of January 28, 2022 | $ | (526) |  |  |  |  | $ | 129 |  |  | $ | (34) |  |  | $ | (431) |  |
| Other comprehensive income (loss) before reclassifications | (222) |  |  |  |  | 354 |  |  | 1 |  |  | 133 |  |
| Amounts reclassified from accumulated other comprehensive income (loss) | — |  |  |  |  | (705) |  |  | 1 |  |  | (704) |  |
| Total change for the period | (222) |  |  |  |  | (351) |  |  | 2 |  |  | (571) |  |
| Less: Change in comprehensive (loss) attributable to non-controlling interests | (1) |  |  |  |  | — |  |  | — |  |  | (1) |  |
| Balances as of February 3, 2023 | $ | (747) |  |  |  |  | $ | (222) |  |  | $ | (32) |  |  | $ | (1,001) |  |

[0001571996-23-000007:notes:317]
Amounts related to the Company’s cash flow hedges are reclassified to net income during the same period in which the items being hedged are recognized in earnings.  See Note 9 of the Notes to the Consolidated Financial Statements for more information on the Company’s derivative instruments.

[0001571996-23-000007:notes:318]
The following table presents reclassifications out of accumulated other comprehensive income (loss), net of tax, to net income for the periods indicated:

[0001571996-23-000007:notes:319]
|  |  |  | Fiscal Year Ended |
|  |  |  | February 3, 2023 |  |  |  | January 28, 2022 |
|  |  |  | Cash Flow Hedges |  | Pensions |  | Total |  |  |  | Cash Flow Hedges |  | Pensions |  | Total |
|  |  |  | (in millions) |
| Total reclassifications, net of tax: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue |  |  | $ | 736 |  |  | $ | — |  |  | $ | 736 |  |  |  |  | $ | 158 |  |  | $ | — |  |  | $ | 158 |  |
| Cost of net revenue |  |  | (31) |  |  | — |  |  | (31) |  |  |  |  | (3) |  |  | — |  |  | (3) |  |
| Operating expenses |  |  | — |  |  | (1) |  |  | (1) |  |  |  |  | — |  |  | (7) |  |  | (7) |  |
| Income from discontinued operations |  |  | — |  |  | — |  |  | — |  |  |  |  | 3 |  |  | — |  |  | 3 |  |
| Total reclassifications, net of tax |  |  | $ | 705 |  |  | $ | (1) |  |  | $ | 704 |  |  |  |  | $ | 158 |  |  | $ | (7) |  |  | $ | 151 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001571996-23-000007:notes:320]
CAPITALIZATION 
The following table presents the Company’s authorized, issued, and outstanding common stock as of the dates indicated:

[0001571996-23-000007:notes:321]
|  | Authorized |  | Issued |  | Outstanding |
|  | (in millions) |
| Common stock as of February 3, 2023 |
| Class A | 600 |  |  | 379 |  |  | 379 |  |
| Class B | 200 |  |  | 95 |  |  | 95 |  |
| Class C | 7,900 |  |  | 324 |  |  | 242 |  |
| Class D | 100 |  |  | — |  |  | — |  |
|  | 8,800 |  |  | 798 |  |  | 716 |  |
| Common stock as of January 28, 2022 |
| Class A | 600 |  |  | 379 |  |  | 379 |  |
| Class B | 200 |  |  | 95 |  |  | 95 |  |
| Class C | 7,900 |  |  | 303 |  |  | 283 |  |
| Class D | 100 |  |  | — |  |  | — |  |
| Class V | 343 |  |  | — |  |  | — |  |
|  | 9,143 |  |  | 777 |  |  | 757 |  |

[0001571996-23-000007:notes:322]
On June 29, 2022, the authorized capital stock provisions of the Company’s certificate of incorporation were amended to eliminate the Class V Common Stock as the fifth authorized series of Dell Technologies common stock.  In connection with the elimination of authorized Class V Common Stock, the Company’s certificate of incorporation also was amended to decrease by 343 million shares the total number of shares of common stock which Dell Technologies is authorized to issue.

[0001571996-23-000007:notes:323]
Preferred Stock

[0001571996-23-000007:notes:324]
The Company is authorized to issue one million shares of preferred stock, par value $0.01 per share.  As of February 3, 2023 and January 28, 2022, no shares of preferred stock were issued or outstanding.

[0001571996-23-000007:notes:325]
Common Stock

[0001571996-23-000007:notes:326]
Dell Technologies Common Stock — The Class A Common Stock, the Class B Common Stock, the Class C Common Stock, and the Class D Common Stock are collectively referred to as Dell Technologies Common Stock.  The par value for all series of Dell Technologies Common Stock is $0.01 per share.  The Class A Common Stock, the Class B Common Stock, the Class C Common Stock, and the Class D Common Stock share equally in dividends declared or accumulated and have equal participation rights in undistributed earnings.

[0001571996-23-000007:notes:327]
Voting Rights — Each holder of record of (a) Class A Common Stock is entitled to ten votes per share of Class A Common Stock; (b) Class B Common Stock is entitled to ten votes per share of Class B Common Stock; (c) Class C Common Stock is entitled to one vote per share of Class C Common Stock; and (d) Class D Common Stock is not entitled to any vote on any matter except to the extent required by provisions of Delaware law (in which case such holder is entitled to one vote per share of Class D Common Stock).

[0001571996-23-000007:notes:328]
Conversion Rights — Under the Company’s certificate of incorporation, at any time and from time to time, any holder of Class A Common Stock or Class B Common Stock has the right to convert all or any of the shares of Class A Common Stock or Class B Common Stock, as applicable, held by such holder into shares of Class C Common Stock on a one-to-one basis.

[0001571996-23-000007:notes:329]
During the fiscal year ended February 3, 2023, there were no conversions of shares of Class A Common Stock or Class B Common Stock into shares of Class C Common Stock.

[0001571996-23-000007:notes:330]
During the fiscal year ended January 28, 2022, the Company issued an aggregate of 5,985,573 shares of Class C Common Stock to stockholders upon their conversion of the same number of shares of Class A Common Stock into Class C Common Stock in accordance with the Company’s certificate of incorporation.

[0001571996-23-000007:notes:331]
During the fiscal year ended January 29, 2021, the Company issued 6,334,990 shares of Class C Common Stock to stockholders upon their conversion of the same number of shares of Class B Common Stock into Class C Common Stock in accordance with the Company’s certificate of incorporation.

[0001571996-23-000007:notes:332]
Dividends

[0001571996-23-000007:notes:333]
On February 24, 2022, the Company announced that its Board of Directors adopted a dividend policy providing for payment by the Company of quarterly cash dividends on the outstanding Dell Technologies Common Stock at a rate of $0.33 per share per fiscal quarter beginning in the first quarter of Fiscal 2023.  On March 2, 2023, the Company announced that the Board of Directors approved a 12% increase in the quarterly dividend rate to a rate of $0.37 per share per fiscal quarter beginning in the first quarter of Fiscal 2024.

[0001571996-23-000007:notes:334]
The Company paid the following dividends during the fiscal year ended February 3, 2023:

[0001571996-23-000007:notes:335]
| Declaration Date |  | Record Date |  | Payment Date |  | Dividend per Share |  | Amount (in millions) |
| February 24, 2022 |  | April 20, 2022 |  | April 29, 2022 |  | $ | 0.33 |  |  | $ | 248 |  |
| June 7, 2022 |  | July 20, 2022 |  | July 29, 2022 |  | $ | 0.33 |  |  | $ | 242 |  |
| September 6, 2022 |  | October 19, 2022 |  | October 28, 2022 |  | $ | 0.33 |  |  | $ | 238 |  |
| December 6, 2022 |  | January 25, 2023 |  | February 3, 2023 |  | $ | 0.33 |  |  | $ | 236 |  |

[0001571996-23-000007:notes:336]
Repurchases of Common Stock

[0001571996-23-000007:notes:337]
Effective as of September 23, 2021, the Company’s Board of Directors approved a stock repurchase program under which the Company is authorized to repurchase up to $5 billion of shares of the Company’s Class C Common Stock with no fixed expiration date.  During the fiscal year ended February 3, 2023, the Company repurchased approximately 62 million shares of Class C Common Stock for a total purchase price of approximately $2.8 billion.  During the fiscal year ended January 28, 2022, the Company repurchased approximately 12 million shares of Class C Common Stock for a total purchase price of approximately $659 million.
The above repurchases of Class C Common Stock exclude shares withheld from stock awards to settle employee tax withholding obligations related to the vesting of such awards.


## us-gaap:EarningsPerShareTextBlock

[0001571996-23-000007:notes:338]
EARNINGS PER SHARE
Basic earnings per share is based on the weighted-average effect of all common shares issued and outstanding and is calculated by dividing net income by the weighted-average shares outstanding during the period.  Diluted earnings per share is calculated by dividing net income by the weighted-average number of common shares used in the basic earnings per share calculation plus the number of common shares that would be issued assuming exercise or conversion of all potentially dilutive instruments.  The Company excludes equity instruments from the calculation of diluted earnings per share if the effect of including such instruments is antidilutive.

[0001571996-23-000007:notes:339]
The following table presents basic and diluted earnings per share for the periods indicated:

[0001571996-23-000007:notes:340]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  | February 3, 2023 |  | January 28, 2022 |  | January 29, 2021 |
| Earnings per share attributable to Dell Technologies Inc. — basic |
| Continuing operations |  |  |  |  | $ | 3.33 |  |  | $ | 6.49 |  |  | $ | 3.02 |  |
| Discontinued operations |  |  |  |  | $ | — |  |  | $ | 0.81 |  |  | $ | 1.35 |  |
| Earnings per share attributable to Dell Technologies Inc. — diluted |
| Continuing operations |  |  |  |  | $ | 3.24 |  |  | $ | 6.26 |  |  | $ | 2.93 |  |
| Discontinued operations |  |  |  |  | $ | — |  |  | $ | 0.76 |  |  | $ | 1.29 |  |

[0001571996-23-000007:notes:341]
The following table presents the computation of basic and diluted earnings per share for the periods indicated:

[0001571996-23-000007:notes:342]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  | February 3, 2023 |  | January 28, 2022 |  | January 29, 2021 |
|  |  |  |  |  | (in millions) |
| Numerator: Continuing operations |  |  |  |  |  |  |  |  |  |
| Net income attributable to Dell Technologies Inc. from continuing operations - basic and diluted |  |  |  |  | $ | 2,442 |  |  | $ | 4,948 |  |  | $ | 2,249 |  |
| Numerator: Discontinued operations |  |  |  |  |  |  |  |  |  |
| Income from discontinued operations, net of income taxes - basic |  |  |  |  | $ | — |  |  | $ | 615 |  |  | $ | 1,001 |  |
| Incremental dilution from VMware, Inc. (a) |  |  |  |  | — |  |  | (7) |  |  | (13) |  |
| Income from discontinued operations, net of income taxes, attributable to Dell Technologies Inc. - diluted |  |  |  |  | $ | — |  |  | $ | 608 |  |  | $ | 988 |  |
| Denominator: Dell Technologies Common Stock weighted-average shares outstanding |  |  |  |  |  |  |  |  |  |
| Weighted-average shares outstanding — basic |  |  |  |  | 734 |  |  | 762 |  |  | 744 |  |
| Dilutive effect of options, restricted stock units, restricted stock, and other |  |  |  |  | 19 |  |  | 29 |  |  | 23 |  |
| Weighted-average shares outstanding — diluted |  |  |  |  | 753 |  |  | 791 |  |  | 767 |  |
| Weighted-average shares outstanding — antidilutive |  |  |  |  | 9 |  |  | — |  |  | — |  |

[0001571996-23-000007:notes:343]
(a)    The incremental dilution from VMware, Inc. represents the impact of VMware, Inc.’s dilutive securities on diluted earnings per share of Dell Technologies Common Stock, and is calculated by multiplying the difference between VMware, Inc.’s basic and diluted earnings (loss) per share by the number of shares of VMware, Inc. common stock held by the Company before the VMware Spin-off.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001571996-23-000007:notes:344]
STOCK-BASED COMPENSATION 
Stock-Based Compensation Expense

[0001571996-23-000007:notes:345]
The following table presents stock-based compensation expense recognized in the Consolidated Statements of Income for the periods indicated:

[0001571996-23-000007:notes:346]
|  | Fiscal Year Ended |
|  | February 3, 2023 |  | January 28, 2022 |  | January 29, 2021 |
|  | (in millions) |
| Stock-based compensation expense: |  |  |  |  |  |
| Cost of net revenue | $ | 152 |  |  | $ | 133 |  |  | $ | 75 |  |
| Operating expenses | 779 |  |  | 675 |  |  | 412 |  |
| Stock-based compensation expense from continuing operations before taxes | 931 |  |  | 808 |  |  | 487 |  |
| Stock-based compensation expense from discontinued operations before taxes (a) | — |  |  | 814 |  |  | 1,122 |  |
| Total stock-based compensation expense before taxes | 931 |  |  | 1,622 |  |  | 1,609 |  |
| Income tax benefit | (163) |  |  | (296) |  |  | (313) |  |
| Total stock-based compensation expense, net of income taxes | $ | 768 |  |  | $ | 1,326 |  |  | $ | 1,296 |  |

[0001571996-23-000007:notes:347]
(a)    Stock-based compensation expense from discontinued operations before taxes represents VMware stock-based compensation expense and is included in income from discontinued operations, net of taxes, on the Consolidated Statements of Income for periods prior to the VMware Spin-off.

[0001571996-23-000007:notes:348]
Dell Technologies Inc. Stock-Based Compensation Plan

[0001571996-23-000007:notes:349]
Dell Technologies Inc. 2013 Stock Incentive Plan  — Employees, consultants, non-employee directors, and other service providers of the Company or its affiliates are eligible to participate in the Dell Technologies Inc. 2013 Stock Incentive Plan, as amended and restated as of July 9, 2019 (the “2013 Plan”).  The 2013 Plan authorizes the Company to grant stock options, restricted stock units (“RSUs”), stock appreciation rights (“SARs”), restricted stock awards, and dividend equivalents.  Stock options have been granted with option exercise prices equal to the fair market value of the Company’s Class C Common Stock and expire ten years after the grant date.

[0001571996-23-000007:notes:350]
The 2013 Plan authorizes the issuance of an aggregate of 165.5 million shares of the Class C Common Stock, including 55.0 million shares automatically added to the share pool pursuant to the equitable adjustment provisions relating to the VMware Spin-off.  As of February 3, 2023, there were approximately 28 million shares of Class C Common Stock available for future grants under the 2013 Plan.

[0001571996-23-000007:notes:351]
Stock Option Activity — The following table presents stock option activity settled in Dell Technologies Common Stock for the periods indicated:

[0001571996-23-000007:notes:352]
|  | Number of Options |  | Weighted-Average Exercise Price |  | Weighted-Average Remaining Contractual Term |  | Aggregate Intrinsic Value (a) |
|  | (in millions) |  | (per share) |  | (in years) |  | (in millions) |
| Options outstanding as of January 31, 2020 | 18 |  |  | $ | 14.82 |  |  |  |  |  |
| Granted | — |  |  | — |  |  |  |  |  |
| Exercised | (12) |  |  | 14.32 |  |  |  |  |  |
| Forfeited | — |  |  | — |  |  |  |  |  |
| Canceled/expired | — |  |  | — |  |  |  |  |  |
| Options outstanding as of January 29, 2021 | 6 |  |  | 15.87 |  |  |  |  |  |
| Granted | — |  |  | — |  |  |  |  |  |
| VMware Spin-off adjustment (b) | 2 |  |  | NA |  |  |  |  |
| Exercised | (5) |  |  | 13.36 |  |  |  |  |  |
| Forfeited | — |  |  | — |  |  |  |  |  |
| Canceled/expired | — |  |  | — |  |  |  |  |  |
| Options outstanding as of January 28, 2022 | 3 |  |  | 9.62 |  |  |  |  |  |
| Granted | — |  |  | — |  |  |  |  |  |
| Exercised | (1) |  |  | 6.99 |  |  |  |  |  |
| Forfeited | — |  |  | — |  |  |  |  |  |
| Canceled/expired | — |  |  | — |  |  |  |  |  |
| Options outstanding as of February 3, 2023 (c) | 2 |  |  | $ | 10.29 |  |  | 2.5 |  | $ | 69 |  |
| Exercisable as of February 3, 2023 | 2 |  |  | $ | 10.43 |  |  | 2.0 |  | $ | 65 |  |
| Vested and expected to vest (net of estimated forfeitures) as of February 3, 2023 | 2 |  |  | $ | 10.32 |  |  | 2.4 |  | $ | 69 |  |

[0001571996-23-000007:notes:353]
(a)    The aggregate intrinsic values represent the total pre-tax intrinsic values based on the closing price of $42.24 of the Class C Common Stock on February 3, 2023 as reported on the NYSE that would have been received by the option holders had all in-the-money options been exercised as of that date.

[0001571996-23-000007:notes:354]
(b)    In connection with the VMware Spin-off, and as authorized by the 2013 Plan, Dell Technologies made certain adjustments to the number of stock options and the exercise price of unexercised stock options using a conversion ratio of approximately 1.97 to 1 to preserve the intrinsic value of the awards prior to the VMware Spin-off.

[0001571996-23-000007:notes:355]
(c)    The ending weighted-average exercise price was calculated based on underlying options outstanding as of February 3, 2023.

[0001571996-23-000007:notes:356]
The total fair value of options vested was not material for the fiscal years ended February 3, 2023, January 28, 2022, and January 29, 2021.  The pre-tax intrinsic value of the options exercised was $35 million, $340 million, and $591 million for the fiscal years ended February 3, 2023, January 28, 2022, and January 29, 2021, respectively.  Cash proceeds from the exercise of stock options was $5 million, $62 million, and $179 million for the fiscal years ended February 3, 2023, January 28, 2022, and  January 29, 2021, respectively.

[0001571996-23-000007:notes:357]
The tax benefit realized from the exercise of stock options was $8 million, $76 million, and $139 million for the fiscal years ended February 3, 2023, January 28, 2022, and January 29, 2021, respectively.

[0001571996-23-000007:notes:358]
Restricted Stock — The Company’s restricted stock primarily consists of RSUs granted to employees.  During the fiscal years ended February 3, 2023, January 28, 2022, and January 29, 2021, the Company granted long-term incentive awards in the form of service-based RSUs and performance-based RSUs (“PSUs”) in order to align critical talent retention programs with the interests of holders of the Class C Common Stock.

[0001571996-23-000007:notes:359]
Service-based RSUs have a fair value based on the closing price of the Class C Common Stock price as reported on the NYSE on the grant date or the trade day immediately preceding the grant date, if the grant date falls on a non-trading day.  The majority of such RSUs vest ratably over a three-year period.  Each service-based RSU represents the right to acquire one share of Class C Common Stock upon vesting.

[0001571996-23-000007:notes:360]
The PSUs granted during the periods presented are reflected as target units for performance periods not yet complete.  The actual number of units that ultimately vest will range from 0% to 200% of target, based on the level of achievement of the performance goals and continued employment with the Company over a three-year performance period.  Approximately half of the PSUs granted are subject to achievement of market-based performance goals based on relative total shareholder return and were valued utilizing a Monte Carlo valuation model to simulate the probabilities of achievement.  The remaining PSUs are subject to internal financial measures and have fair values based on the closing price of the Class C Common Stock as reported on the NYSE on the accounting grant date.

[0001571996-23-000007:notes:361]
Beginning with grants made during the fiscal year ended February 3, 2023, dividend equivalents will accrue on outstanding RSUs and PSUs when a dividend is paid to the Company’s common stockholders.  Accrued dividend equivalents will be paid when the underlying RSUs and PSUs vest.

[0001571996-23-000007:notes:362]
The following table presents the assumptions utilized in the Monte Carlo valuation model for the periods indicated:

[0001571996-23-000007:notes:363]
|  | Fiscal Year Ended |
|  | February 3, 2023 |  | January 28, 2022 |  | January 29, 2021 |
| Weighted-average grant date fair value (a) | $ | 73.26 |  |  | $ | 134.01 |  |  | $ | 40.01 |  |
| Term (in years) | 3 |  | 3 |  | 3 |
| Risk-free rate (U.S. Government Treasury Note) | 2.0 | % |  | 0.3 | % |  | 0.6 | % |
| Expected volatility | 39 | % |  | 43 | % |  | 47 | % |
| Expected dividend yield | — | % |  | — | % |  | — | % |

[0001571996-23-000007:notes:364]
(a)    Weighted-average grant date fair value for periods prior to the completion of the VMware Spin-off is calculated using pre-spin off stock prices and has not been adjusted to reflect the impact of the conversion ratio on the Class C Common Stock.

[0001571996-23-000007:notes:365]
The following table presents restricted stock and restricted stock units activity settled in Dell Technologies Common Stock for the periods indicated:

[0001571996-23-000007:notes:366]
|  | Number of Units |  | Weighted-Average Grant Date Fair Value |  | Aggregate Intrinsic Value (a) |
|  | (in millions) |  | (per unit) |  |  |
| Outstanding as of January 31, 2020 | 16 |  |  | $ | 50.78 |  |  |  |
| Granted | 25 |  |  | 39.14 |  |  |  |
| Vested | (5) |  |  | 48.15 |  |  |  |
| Forfeited | (3) |  |  | 41.56 |  |  |  |
| Outstanding as of January 29, 2021 | 33 |  |  | 43.09 |  |  |  |
| Granted | 13 |  |  | 88.13 |  |  |  |
| VMware Spin-off adjustment (b) | 30 |  |  | NA |  |  |
| Vested | (13) |  |  | 39.33 |  |  |  |
| Forfeited | (4) |  |  | 46.27 |  |  |  |
| Outstanding as of January 28, 2022 | 59 |  |  | 31.67 |  |  |  |
| Granted | 23 |  |  | 48.11 |  |  |  |
| Vested | (27) |  |  | 29.96 |  |  |  |
| Forfeited | (5) |  |  | 39.26 |  |  |  |
| Outstanding as of February 3, 2023 (c) | 50 |  |  | $ | 39.44 |  |  | $ | 2,110 |  |
| Vested and expected to vest, February 3, 2023 | 48 |  |  | $ | 38.97 |  |  | $ | 2,008 |  |

[0001571996-23-000007:notes:367]
(a)    The aggregate intrinsic value represents the total pre-tax intrinsic values based on the closing price of $42.24 of the Class C Common Stock on February 3, 2023 as reported on the NYSE that would have been received by the RSU holders had the RSUs been issued as of February 3, 2023.

[0001571996-23-000007:notes:368]
(b)    In connection with the VMware Spin-off, and as authorized by the 2013 Plan, Dell Technologies made certain adjustments to the number of RSUs using a conversion ratio of approximately 1.97 to 1 to preserve the intrinsic value of the awards prior to the VMware Spin-off.

[0001571996-23-000007:notes:369]
(c)    As of February 3, 2023, the 50 million units outstanding included 38 million RSUs and 12 million PSUs.

[0001571996-23-000007:notes:370]
The total fair value of restricted stock that vested during the fiscal years ended February 3, 2023, January 28, 2022, and January 29, 2021 was $827 million, $493 million, and $235 million, respectively, with a pre-tax intrinsic value of $1,371 million, $1,097 million, and $226 million, respectively.

[0001571996-23-000007:notes:371]
As of February 3, 2023, there was $953 million of unrecognized stock-based compensation expense, net of estimated forfeitures, related to these awards expected to be recognized over a weighted-average period of approximately 1.8 years.

[0001571996-23-000007:notes:372]
Dell Technologies Shares Withheld for Taxes — Beginning in the fiscal year ended February 3, 2023, shares of Class C Common Stock are generally withheld from issuance to cover employee taxes for the vesting of restricted stock units.  During the fiscal years ended January 28, 2022 and January 29, 2021, shares of Class C Common Stock were withheld from issuance to cover employee taxes for both the vesting of restricted stock units and the exercise of stock options only under certain situations.  For the fiscal years ended February 3, 2023, January 28, 2022, and January 29, 2021, 8 million, 0.4 million, and 0.1 million shares, respectively, were withheld to cover $388 million, $40 million, and $1 million, respectively, of employees’ tax obligations.  The value of the withheld shares was classified as a reduction to common stock and capital in excess of par value.

[0001571996-23-000007:notes:373]
Other Plans
In addition to the 2013 Plan described above, the Company’s consolidated subsidiary, Secureworks, maintains its own equity plan and issues equity grants settling in its own Class A common stock.  The stock option and restricted stock unit activity under this plan was not material during the fiscal years ended February 3, 2023, January 28, 2022, and January 29, 2021.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001571996-23-000007:notes:374]
RETIREMENT PLAN BENEFITS 
Defined Benefit Retirement Plans

[0001571996-23-000007:notes:375]
The Company sponsors retirement plans for certain employees in the United States and internationally, some of which meet the criteria of a defined benefit retirement plan.  Benefits under defined benefit retirement plans guarantee a particular payment to the employee in retirement.  The amount of retirement benefit is defined by the plan and is typically a function of the number of years of service rendered by the employee and the employee’s average salary or salary at retirement.  The annual costs of the plans are determined using the projected unit credit actuarial cost method that includes actuarial assumptions and estimates which are subject to change.

[0001571996-23-000007:notes:376]
U.S. Pension Plan — The Company sponsors a noncontributory defined benefit retirement plan in the United States (the “U.S. pension plan”) which was assumed in connection with the EMC merger transaction.  As of December 1999, the U.S. pension plan was frozen, so employees no longer accrue retirement benefits for future services.  The measurement date for the U.S. pension plan is the end of the Company’s fiscal year.  The Company did not make any significant contributions to the U.S. pension plan for the fiscal years ended February 3, 2023, January 28, 2022, and January 29, 2021, and does not expect to make any significant contributions in Fiscal 2024.

[0001571996-23-000007:notes:377]
Net periodic benefit costs related to the U.S. pension plan were immaterial for the fiscal years ended February 3, 2023, January 28, 2022, and January 29, 2021.

[0001571996-23-000007:notes:378]
The following table presents attributes of the U.S. pension plan as of the dates indicated:

[0001571996-23-000007:notes:379]
|  | February 3, 2023 |  | January 28, 2022 |
|  | (in millions) |
| Plan assets at fair value (a) | $ | 439 |  |  | $ | 550 |  |
| Benefit obligations | (484) |  |  | (582) |  |
| Underfunded position (b) | $ | (45) |  |  | $ | (32) |  |

[0001571996-23-000007:notes:380]
(a)    Plan assets are managed by outside investment managers.  The Company’s investment strategy with respect to plan assets is to achieve a long-term growth of capital, consistent with an appropriate level of risk.  Assets are recognized at fair value and are primarily classified within Level 2 of the fair value hierarchy.

[0001571996-23-000007:notes:381]
(b)    The underfunded position of the U.S. pension plan is recognized in other non-current liabilities in the Consolidated Statements of Financial Position.

[0001571996-23-000007:notes:382]
As of February 3, 2023, future benefit payments for the U.S. pension plan are expected to be paid as follows: $36 million in Fiscal 2024; $37 million in Fiscal 2025; $38 million in Fiscal 2026; $38 million in Fiscal 2027; $38 million in Fiscal 2028; and $182 million thereafter.

[0001571996-23-000007:notes:383]
International Pension Plans — The Company also sponsors retirement plans outside of the United States which qualify as defined benefit plans.  The following table presents attributes of the international pension plans as of the dates indicated:

[0001571996-23-000007:notes:384]
|  | February 3, 2023 |  | January 28, 2022 |
|  | (in millions) |
| Plan assets at fair value (a) | $ | 221 |  |  | $ | 245 |  |
| Benefit obligations | (423) |  |  | (479) |  |
| Underfunded position (b) | $ | (202) |  |  | $ | (234) |  |

[0001571996-23-000007:notes:385]
(a)    Plan assets are managed by outside investment managers.  The Company’s investment strategy with respect to plan assets is to achieve a long-term growth of capital, consistent with an appropriate level of risk.  Assets are recognized at fair value and are primarily classified within Level 1 of the fair value hierarchy.

[0001571996-23-000007:notes:386]
(b)    The underfunded position is recognized in other non-current liabilities in the Consolidated Statements of Financial Position.

[0001571996-23-000007:notes:387]
Defined Contribution Retirement Plans

[0001571996-23-000007:notes:388]
Dell 401(k) Plan — The Company has a defined contribution retirement plan (the “Dell 401(k) Plan”) that complies with Section 401(k) of the Internal Revenue Code.  Only U.S. employees and employees of certain subsidiaries, except those who are covered by a collective bargaining agreement, classified as a leased employee or a nonresident alien, or are covered under a separate plan, are eligible to participate in the Dell 401(k) Plan.  Participation in the Dell 401(k) Plan is at the election of the employee.  As of February 3, 2023, the Company matched 100% of each participant’s voluntary contributions (the “Dell 401(k) employer match”), subject to a maximum contribution of 6% of the participant’s eligible compensation, up to an annual limit of $7,500, and participants vest immediately in all contributions to the Dell 401(k) Plan.  On June 1, 2020, the Company suspended the Dell 401(k) employer match for U.S. employees as a precautionary measure to preserve financial flexibility in light of COVID-19.  Effective January 1, 2021, the Dell 401(k) employer match was reinstated, with no change to the employer match policy or participant eligibility requirements.
The Company’s matching contributions as well as participants’ voluntary contributions are invested according to each participant’s elections in the investment options provided under the Dell 401(k) Plan.  The Company’s contributions during the fiscal years ended February 3, 2023, January 28, 2022, and January 29, 2021 were $263 million, $249 million, and $154 million, respectively.


## us-gaap:ScheduleOfChangesInFairValueOfPlanAssetsTableTextBlock

[0001571996-23-000007:notes:389]
(b)    The underfunded position of the U.S. pension plan is recognized in other non-current liabilities in the Consolidated Statements of Financial Position.  
The following table presents attributes of the international pension plans as of the dates indicated:

[0001571996-23-000007:notes:390]
(a)    Plan assets are managed by outside investment managers.  The Company’s investment strategy with respect to plan assets is to achieve a long-term growth of capital, consistent with an appropriate level of risk.  Assets are recognized at fair value and are primarily classified within Level 1 of the fair value hierarchy.
(b)    The underfunded position is recognized in other non-current liabilities in the Consolidated Statements of Financial Position.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001571996-23-000007:notes:391]
SEGMENT INFORMATION 
The Company has two reportable segments that are based on the following business units:  Infrastructure Solutions Group (“ISG”) and Client Solutions Group (“CSG”).

[0001571996-23-000007:notes:392]
ISG enables the Company’s customers’ digital transformation with solutions that address the fundamental shift to multicloud environments, machine learning, artificial intelligence, and data analytics.  The Company’s comprehensive storage portfolio includes traditional as well as next-generation storage solutions, including all-flash arrays, scale-out file, object platforms, hyperconverged infrastructure, and software-defined storage.  The Company’s server portfolio includes high-performance rack, blade, and tower servers.  The ISG networking portfolio helps the Company’s business customers transform and modernize their infrastructure, mobilize and enrich end-user experiences, and accelerate business applications and processes.   ISG also offers attached software, peripherals, and services, including support and deployment, configuration, and extended warranty services.

[0001571996-23-000007:notes:393]
CSG includes sales to commercial and consumer customers of branded hardware (such as desktops, workstations, and notebooks) and branded peripherals (such as displays, docking stations, and other electronics), as well as third-party software and peripherals.  CSG also includes services offerings, including support and deployment, configuration, and extended warranty services.

[0001571996-23-000007:notes:394]
The reportable segments disclosed herein are based on information reviewed by the Company’s management to evaluate the business segment results.  The Company’s measure of segment revenue and segment operating income for management reporting purposes excludes operating results of other businesses, unallocated corporate transactions, the impact of purchase accounting, amortization of intangible assets, transaction-related expenses, stock-based compensation expense, and other corporate expenses, as applicable.  The Company does not allocate assets to the above reportable segments for internal reporting purposes.

[0001571996-23-000007:notes:395]
As described in Note 1 and Note 3 of the Notes to the Consolidated Financial Statements, the Company completed the VMware Spin-off on November 1, 2021.

[0001571996-23-000007:notes:396]
Pursuant to the CFA described in such Notes, Dell Technologies continues to act as a distributor of VMware’s standalone products and services and purchase such products and services for resale to end-user customers (“VMware Resale”).  Dell Technologies also continues to integrate VMware’s products and services with Dell Technologies’ offerings and sell them to end users.  The results of such operations are classified as continuing operations within the Company’s Consolidated Statements of Income.  The results of standalone VMware Resale transactions are reflected in other businesses.  The results of integrated offering transactions are reflected within CSG or ISG, depending upon the nature of the underlying offering sold.  The Company's prior period segment results have been recast to reflect this change.

[0001571996-23-000007:notes:397]
In accordance with applicable accounting guidance, the results of VMware, excluding Dell's resale of VMware offerings, are presented as discontinued operations in the Consolidated Statements of Income and, as such, have been excluded from both continuing operations and segment results for periods presented prior to the completion of the VMware Spin-off.

[0001571996-23-000007:notes:398]
The following table presents a reconciliation of net revenue by the Company’s reportable segments to the Company’s consolidated net revenue as well as a reconciliation of segment operating income to the Company’s consolidated operating income for the periods indicated:

[0001571996-23-000007:notes:399]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  | February 3, 2023 |  | January 28, 2022 |  | January 29, 2021 |
|  |  |  |  |  | (in millions) |
| Consolidated net revenue: |  |  |  |  |  |  |  |  |  |
| Infrastructure Solutions Group |  |  |  |  | $ | 38,356 |  |  | $ | 34,366 |  |  | $ | 33,002 |  |
| Client Solutions Group |  |  |  |  | 58,213 |  |  | 61,464 |  |  | 48,387 |  |
| Reportable segment net revenue |  |  |  |  | 96,569 |  |  | 95,830 |  |  | 81,389 |  |
| Other businesses (a) (b) |  |  |  |  | 5,721 |  |  | 5,388 |  |  | 5,382 |  |
| Unallocated transactions (c) |  |  |  |  | 11 |  |  | 11 |  |  | 5 |  |
| Impact of purchase accounting (d) |  |  |  |  | — |  |  | (32) |  |  | (106) |  |
| Total consolidated net revenue |  |  |  |  | $ | 102,301 |  |  | $ | 101,197 |  |  | $ | 86,670 |  |
| Consolidated operating income: |  |  |  |  |  |  |  |  |  |
| Infrastructure Solutions Group |  |  |  |  | $ | 5,045 |  |  | $ | 3,736 |  |  | $ | 3,753 |  |
| Client Solutions Group |  |  |  |  | 3,824 |  |  | 4,365 |  |  | 3,333 |  |
| Reportable segment operating income |  |  |  |  | 8,869 |  |  | 8,101 |  |  | 7,086 |  |
| Other businesses (a) (b) |  |  |  |  | (240) |  |  | (319) |  |  | (139) |  |
| Unallocated transactions (c) |  |  |  |  | 8 |  |  | 3 |  |  | 2 |  |
| Impact of purchase accounting (d) |  |  |  |  | (44) |  |  | (67) |  |  | (144) |  |
| Amortization of intangibles |  |  |  |  | (970) |  |  | (1,641) |  |  | (2,133) |  |
| Transaction-related expenses (e) |  |  |  |  | (22) |  |  | (273) |  |  | (124) |  |
| Stock-based compensation expense (f) |  |  |  |  | (931) |  |  | (808) |  |  | (487) |  |
| Other corporate expenses (g) |  |  |  |  | (899) |  |  | (337) |  |  | (376) |  |
| Total consolidated operating income |  |  |  |  | $ | 5,771 |  |  | $ | 4,659 |  |  | $ | 3,685 |  |

[0001571996-23-000007:notes:400]
(a)Other businesses consists of (i) VMware Resale, (ii) Secureworks, and (iii) Virtustream, and do not meet the requirements for a reportable segment, either individually or collectively.

[0001571996-23-000007:notes:401]
(b)The Company completed the sale of RSA Security on September 1, 2020, and the sale of Boomi on October 1, 2021.  Prior to the divestitures, RSA Security and Boomi’s results were included within other businesses.  See Note 1 of the Notes to the Consolidated Financial Statements for further details related to the divestitures of RSA Security and Boomi.

[0001571996-23-000007:notes:402]
(c)Unallocated transactions includes other corporate items that are not allocated to Dell Technologies’ reportable segments.

[0001571996-23-000007:notes:403]
(d)Impact of purchase accounting includes non-cash purchase accounting adjustments that are primarily related to the EMC merger transaction that was completed in September 2016.

[0001571996-23-000007:notes:404]
(e)Transaction-related expenses includes acquisition, integration, and divestiture related costs, as well as the costs incurred in the VMware Spin-off described in Note 1 and Note 3 of the Notes to the Consolidated Financial Statements.

[0001571996-23-000007:notes:405]
(f)Stock-based compensation expense consists of equity awards granted based on the estimated fair value of those awards at grant date.

[0001571996-23-000007:notes:406]
(g)Other corporate expenses includes impairment charges, incentive charges related to equity investments, severance, facility action, payroll taxes associated with stock-based compensation, and other costs.

[0001571996-23-000007:notes:407]
The following table presents the disaggregation of net revenue by reportable segment, and by major product categories within the segments for the periods indicated:

[0001571996-23-000007:notes:408]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  | February 3, 2023 |  | January 28, 2022 |  | January 29, 2021 |
|  |  |  |  |  | (in millions) |
| Net revenue: |  |  |  |  |  |  |  |  |  |
| Infrastructure Solutions Group: |  |  |  |  |  |  |  |  |  |
| Servers and networking |  |  |  |  | $ | 20,398 |  |  | $ | 17,901 |  |  | $ | 16,592 |  |
| Storage |  |  |  |  | 17,958 |  |  | 16,465 |  |  | 16,410 |  |
| Total ISG net revenue |  |  |  |  | $ | 38,356 |  |  | $ | 34,366 |  |  | $ | 33,002 |  |
| Client Solutions Group: |  |  |  |  |  |  |  |  |  |
| Commercial |  |  |  |  | $ | 45,556 |  |  | $ | 45,576 |  |  | $ | 35,423 |  |
| Consumer |  |  |  |  | 12,657 |  |  | 15,888 |  |  | 12,964 |  |
| Total CSG net revenue |  |  |  |  | $ | 58,213 |  |  | $ | 61,464 |  |  | $ | 48,387 |  |

[0001571996-23-000007:notes:409]
The following table presents net revenue allocated between the United States and foreign countries for the periods indicated:

[0001571996-23-000007:notes:410]
|  | Fiscal Year Ended |
|  | February 3, 2023 |  | January 28, 2022 |  | January 29, 2021 |
|  | (in millions) |
| Net revenue: |  |  |  |  |  |
| United States | $ | 49,201 |  |  | $ | 46,752 |  |  | $ | 42,009 |  |
| Foreign countries | 53,100 |  |  | 54,445 |  |  | 44,661 |  |
| Total net revenue | $ | 102,301 |  |  | $ | 101,197 |  |  | $ | 86,670 |  |

[0001571996-23-000007:notes:411]
The following table presents property, plant, and equipment, net allocated between the United States and foreign countries as of the dates indicated:

[0001571996-23-000007:notes:412]
|  | February 3, 2023 |  | January 28, 2022 |
|  | (in millions) |
| Property, plant, and equipment, net: |  |  |  |
| United States | $ | 4,163 |  |  | $ | 3,667 |  |
| Foreign countries | 2,046 |  |  | 1,748 |  |
| Total property, plant, and equipment, net | $ | 6,209 |  |  | $ | 5,415 |  |

[0001571996-23-000007:notes:413]
The allocation between domestic and foreign net revenue is based on the location of the customers.  Net revenue from any single foreign country did not constitute more than 10% of the Company’s consolidated net revenue for any of the fiscal years ended February 3, 2023, January 28, 2022, and January 29, 2021.  As of February 3, 2023 and January 28, 2022, property, plant, and equipment, net primarily related to domestic ownership.  Within foreign countries, property, plant, and equipment, net of $0.7 billion was located in Ireland


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001571996-23-000007:notes:414]
SUPPLEMENTAL CONSOLIDATED FINANCIAL INFORMATION
The following table presents additional information on selected assets included in the Consolidated Statements of Financial Position as of the dates indicated:

[0001571996-23-000007:notes:415]
|  | February 3, 2023 |  | January 28, 2022 |
|  | (in millions) |
| Cash, cash equivalents, and restricted cash: |  |  |  |
| Cash and cash equivalents | $ | 8,607 |  |  | $ | 9,477 |  |
| Restricted cash - other current assets (a) | 272 |  |  | 534 |  |
| Restricted cash - other non-current assets (a) | 15 |  |  | 71 |  |
| Total cash, cash equivalents, and restricted cash | $ | 8,894 |  |  | $ | 10,082 |  |
| Inventories, net: |  |  |  |
| Production materials | $ | 3,225 |  |  | $ | 3,653 |  |
| Work-in-process | 708 |  |  | 855 |  |
| Finished goods | 843 |  |  | 1,390 |  |
| Total inventories, net | $ | 4,776 |  |  | $ | 5,898 |  |
| Prepaid expenses: |  |  |  |
| Total prepaid expenses (b) | $ | 641 |  |  | $ | 886 |  |
| Deferred Costs: |  |  |  |
| Total deferred costs, current (b) | $ | 5,459 |  |  | $ | 4,996 |  |
| Property, plant, and equipment, net: |  |  |  |
| Computer equipment | $ | 6,899 |  |  | $ | 6,497 |  |
| Land and buildings | 3,059 |  |  | 3,095 |  |
| Machinery and other equipment | 3,134 |  |  | 2,714 |  |
| Total property, plant, and equipment | 13,092 |  |  | 12,306 |  |
| Accumulated depreciation and amortization (c) | (6,883) |  |  | (6,891) |  |
| Total property, plant, and equipment, net | $ | 6,209 |  |  | $ | 5,415 |  |

[0001571996-23-000007:notes:416]
(a)    Restricted cash includes cash required to be held in escrow pursuant to DFS securitization arrangements.

[0001571996-23-000007:notes:417]
(b)    Deferred costs and prepaid expenses are included in other current assets in the Consolidated Statements of Financial Position.  Amounts classified as long-term deferred costs are included in other non current assets and are not disclosed above.

[0001571996-23-000007:notes:418]
(c)    During the fiscal years ended February 3, 2023, January 28, 2022, and January 29, 2021, the Company recognized $1.8 billion, $1.6 billion, and $1.3 billion, respectively, in depreciation expense.

[0001571996-23-000007:notes:419]
Valuation and Qualifying Accounts

[0001571996-23-000007:notes:420]
The provisions recognized on the Consolidated Statements of Income during the fiscal years presented are based on assessments of the impact of current and expected future economic conditions.  The duration and severity of continued market volatility is highly uncertain and, as such, the impacts on expected credit losses for trade receivables and financing receivables are subject to significant judgment and may cause variability in the Company’s allowance for credit losses in future periods for trade receivables and financing receivables.

[0001571996-23-000007:notes:421]
The following table presents the Company’s valuation and qualifying accounts for the periods indicated:

[0001571996-23-000007:notes:422]
|  | Fiscal Year Ended |
|  | February 3, 2023 |  | January 28, 2022 |  | January 29, 2021 |
|  | (in millions) |
| Customer Financing Receivables - Allowance for financing receivable losses: |  |  |  |  |  |
| Balance at beginning of period | $ | 189 |  |  | $ | 321 |  |  | $ | 149 |  |
| Adjustment for adoption of accounting standard | — |  |  | — |  |  | 111 |  |
| Charge-offs, net of recoveries | (60) |  |  | (72) |  |  | (91) |  |
| Provision charged to income statement | 72 |  |  | (60) |  |  | 152 |  |
| Balance at end of period | $ | 201 |  |  | $ | 189 |  |  | $ | 321 |  |
| Tax Valuation Allowance: |  |  |  |  |  |
| Balance at beginning of period | $ | 1,423 |  |  | $ | 1,297 |  |  | $ | 1,313 |  |
| Charged to income tax provision | 84 |  |  | 155 |  |  | 41 |  |
| Charged to other accounts | 28 |  |  | (29) |  |  | (57) |  |
| Balance at end of period | $ | 1,535 |  |  | $ | 1,423 |  |  | $ | 1,297 |  |

[0001571996-23-000007:notes:423]
Warranty Liability

[0001571996-23-000007:notes:424]
The following table presents changes in the Company’s liability for standard limited warranties for the periods indicated:

[0001571996-23-000007:notes:425]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  | February 3, 2023 |  | January 28, 2022 |  | January 29, 2021 |
|  |  |  |  |  | (in millions) |
| Warranty liability: |  |  |  |  |  |  |  |  |  |
| Warranty liability at beginning of period |  |  |  |  | $ | 480 |  |  | $ | 473 |  |  | $ | 496 |  |
| Costs accrued for new warranty contracts and changes in estimates for pre-existing warranties (a) |  |  |  |  | 956 |  |  | 957 |  |  | 782 |  |
| Service obligations honored |  |  |  |  | (969) |  |  | (950) |  |  | (805) |  |
| Warranty liability at end of period |  |  |  |  | $ | 467 |  |  | $ | 480 |  |  | $ | 473 |  |
| Current portion |  |  |  |  | $ | 324 |  |  | $ | 353 |  |  | $ | 356 |  |
| Non-current portion |  |  |  |  | $ | 143 |  |  | $ | 127 |  |  | $ | 117 |  |

[0001571996-23-000007:notes:426]
(a)Changes in cost estimates related to pre-existing warranties are aggregated with accruals for new standard warranty contracts.  The Company’s warranty liability process does not differentiate between estimates made for pre-existing warranties and those made for new warranty obligations.

[0001571996-23-000007:notes:427]
Severance Charges

[0001571996-23-000007:notes:428]
The Company incurs costs related to employee severance and records a liability for these costs when it is probable that employees will be entitled to termination benefits and the amounts can be reasonably estimated.  The liability related to these actions is included in accrued and other current liabilities in the Consolidated Statements of Financial Position.

[0001571996-23-000007:notes:429]
On February 6, 2023, subsequent to close of the fiscal year ended February 3, 2023, the Company announced to its employees reorganizations and actions to align its investments more closely with its previously discussed strategic and customer priorities.  These actions will reduce the Company’s workforce by approximately 5% as the Company continues to take prudent steps in light of a challenging global economic environment.  The Company recognized $367 million of expense associated with these actions in the fourth quarter of the fiscal year ended February 3, 2023.

[0001571996-23-000007:notes:430]
The following table presents the activity related to the Company’s severance liability for the periods indicated:

[0001571996-23-000007:notes:431]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  | February 3, 2023 |  | January 28, 2022 |  | January 29, 2021 |
|  |  |  |  |  | (in millions) |
| Severance liability: |  |  |  |  |  |  |  |  |  |
| Severance liability at beginning of period |  |  |  |  | $ | 74 |  |  | $ | 109 |  |  | $ | 117 |  |
| Severance charges |  |  |  |  | 527 |  |  | 134 |  |  | 368 |  |
| Cash paid and other |  |  |  |  | (193) |  |  | (169) |  |  | (376) |  |
| Severance liability at end of period |  |  |  |  | $ | 408 |  |  | $ | 74 |  |  | $ | 109 |  |

[0001571996-23-000007:notes:432]
The following table presents severance charges as included in the Consolidated Statements of Income for the periods indicated:

[0001571996-23-000007:notes:433]
|  | Fiscal Year Ended |
|  | February 3, 2023 |  | January 28, 2022 |  | January 29, 2021 |
|  | (in millions) |
| Severance charges: |  |  |  |  |  |
| Cost of net revenue | $ | 108 |  |  | $ | 29 |  |  | $ | 58 |  |
| Selling, general, and administrative | 363 |  |  | 98 |  |  | 262 |  |
| Research and development | 56 |  |  | 7 |  |  | 48 |  |
| Total severance charges | $ | 527 |  |  | $ | 134 |  |  | $ | 368 |  |

[0001571996-23-000007:notes:434]
Interest and other, net

[0001571996-23-000007:notes:435]
The following table presents information regarding interest and other, net for the periods indicated:

[0001571996-23-000007:notes:436]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  | February 3, 2023 |  | January 28, 2022 |  | January 29, 2021 |
|  |  |  |  |  | (in millions) |
| Interest and other, net: |  |  |  |  |  |  |  |  |  |
| Investment income, primarily interest |  |  |  |  | $ | 100 |  |  | $ | 42 |  |  | $ | 47 |  |
| Gain (loss) on investments, net |  |  |  |  | (206) |  |  | 569 |  |  | 425 |  |
| Interest expense |  |  |  |  | (1,222) |  |  | (1,542) |  |  | (2,052) |  |
| Foreign exchange |  |  |  |  | (265) |  |  | (221) |  |  | (160) |  |
| Gain on disposition of businesses and assets |  |  |  |  | — |  |  | 3,968 |  |  | 458 |  |
| Debt extinguishment fees |  |  |  |  | — |  |  | (1,572) |  |  | (158) |  |
| Legal settlement, net |  |  |  |  | (894) |  |  | — |  |  | — |  |
| Other |  |  |  |  | (59) |  |  | 20 |  |  | 101 |  |
| Total interest and other, net |  |  |  |  | $ | (2,546) |  |  | $ | 1,264 |  |  | $ | (1,339) |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001571996-23-000007:notes:437]
RELATED PARTY TRANSACTIONS 
VMware is considered to be a related party of the Company as a result of Michael Dell’s ownership interests in both Dell Technologies and VMware as well as Mr. Dell’s continued service as Chairman and Chief Executive Officer of Dell Technologies and as Chairman of the Board of VMware, Inc.  See Note 1 and Note 3 of the Notes to the Consolidated Financial Statements for more information about the VMware Spin-off.

[0001571996-23-000007:notes:438]
The information provided below includes a summary of transactions with VMware.  Transactions with related parties other than VMware during the periods presented were immaterial, individually and in aggregate.

[0001571996-23-000007:notes:439]
Transactions with VMware

[0001571996-23-000007:notes:440]
Dell Technologies and VMware engage in the following ongoing related party transactions:

[0001571996-23-000007:notes:441]
•Pursuant to original equipment manufacturer and reseller arrangements, Dell Technologies integrates or bundles VMware’s products and services with Dell Technologies’ products and sells them to end-users.  Dell Technologies also acts as a distributor, purchasing VMware’s standalone products and services for resale to end-user customers.  Where applicable, costs under these arrangements are presented net of rebates received by Dell Technologies.

[0001571996-23-000007:notes:442]
•Dell Technologies procures products and services from VMware for its internal use.  For the fiscal years ended February 3, 2023, January 28, 2022, and January 29, 2021, costs incurred associated with products and services purchased from VMware for internal use were immaterial.

[0001571996-23-000007:notes:443]
•Dell Technologies sells and leases products and sells services to VMware.  For the fiscal years ended February 3, 2023, January 28, 2022, and January 29, 2021, revenue recognized from sales of services to VMware was immaterial.

[0001571996-23-000007:notes:444]
•DFS provides financing to certain VMware end-users.  Upon acceptance of the financing arrangement by both VMware’s end-users and DFS, DFS recognizes amounts due to related parties on the Consolidated Statements of Financial Position.  Associated financing fees are recorded to product net revenue on the Consolidated Statements of Income and are reflected within sales and leases of products to VMware in the table below.

[0001571996-23-000007:notes:445]
•Dell Technologies and VMware also enter into joint marketing, sales, and branding arrangements, for which both parties may incur costs.  For the fiscal years ended February 3, 2023, January 28, 2022, and January 29, 2021, consideration received from VMware for joint marketing, sales, and branding arrangements was immaterial.

[0001571996-23-000007:notes:446]
•Dell Technologies and VMware entered into a transition services agreement in connection with the VMware Spin-off to provide various support services, including investment advisory services, certain support services from Dell Technologies personnel, and other transitional services.  Costs associated with this agreement were immaterial for the fiscal years ended February 3, 2023 and January 28, 2022.  Activities under the agreement concluded during the fiscal year ended February 3, 2023.

[0001571996-23-000007:notes:447]
•Prior to the completion of the VMware Spin-off, Dell Technologies provided support services and support from Dell Technologies personnel to VMware in certain geographic regions where VMware did not have an established legal entity.  These employees were managed by VMware, but Dell Technologies incurred the costs for these such services.  The costs incurred by Dell Technologies on VMware’s behalf to these employees were charged to VMware.  For the fiscal years ended January 28, 2022 and January 29, 2021, costs associated with such seconded employees were immaterial.  Remaining activity related to seconded employees occurring after the completion of the VMware Spin-off was governed by the transition services agreement discussed above.

[0001571996-23-000007:notes:448]
The following table presents information about the impact of Dell Technologies’ related party transactions with VMware on the Consolidated Statements of Income for the periods indicated:

[0001571996-23-000007:notes:449]
|  |  |  |  |  | Fiscal Year Ended |
|  | Classification |  |  |  |  |  | February 3, 2023 |  | January 28, 2022 |  | January 29, 2021 |
|  |  |  |  |  |  |  | (in millions) |
| Sales and leases of products to VMware | Net revenue - products |  |  |  |  |  | $ | 154 |  |  | $ | 188 |  |  | $ | 166 |  |
| Purchase of VMware products for resale | Cost of net revenue - products |  |  |  |  |  | $ | 1,634 |  |  | $ | 1,577 |  |  | $ | 1,493 |  |
| Purchase of VMware services for resale | Cost of net revenue - services |  |  |  |  |  | $ | 3,065 |  |  | $ | 2,487 |  |  | $ | 1,848 |  |

[0001571996-23-000007:notes:450]
The following table presents information about the impact of Dell Technologies’ related party transactions with VMware on the Consolidated Statements of Financial Position as of the dates indicated:

[0001571996-23-000007:notes:451]
|  | Classification |  | February 3, 2023 |  | January 28, 2022 |
|  |  |  | (in millions) |
| Deferred costs related to VMware products and services for resale | Other current assets |  | $ | 3,000 |  |  | $ | 2,571 |  |
| Deferred costs related to VMware products and services for resale | Other non-current assets |  | $ | 2,537 |  |  | $ | 2,311 |  |

[0001571996-23-000007:notes:452]
Due To/From Related Party

[0001571996-23-000007:notes:453]
The following table presents amounts due to and from VMware as of the dates indicated:

[0001571996-23-000007:notes:454]
|  | February 3, 2023 |  | January 28, 2022 |
|  | (in millions) |
| Due from related party, net, current (a) | $ | 378 |  |  | $ | 131 |  |
| Due from related party, net, non-current (b) | $ | 440 |  |  | $ | 710 |  |
| Due to related party, current (c) | $ | 2,067 |  |  | $ | 1,414 |  |

[0001571996-23-000007:notes:455]
(a)    Amounts due from related party, net, current consists of amounts due from VMware, inclusive of current net tax receivables from VMware under the Tax Agreements described below.  Amounts, excluding tax, are generally settled in cash within 60 days of each quarter-end.

[0001571996-23-000007:notes:456]
(b)  Amounts due from related party, net, non-current consists of non-current portion of net receivables from VMware under the Tax Agreements.

[0001571996-23-000007:notes:457]
(c)  Amounts due to related party, current includes amounts due to VMware, which are generally settled in cash within 60 days of each quarter-end.

[0001571996-23-000007:notes:458]
Related Party Tax Matters

[0001571996-23-000007:notes:459]
Tax Agreements — In connection with the VMware Spin-off and concurrently with the execution of the Separation and Distribution Agreement, effective as of April 14, 2021, Dell Technologies and VMware entered into a Tax Matters Agreement (the “Tax Matters Agreement”) and agreed to terminate the tax sharing agreement as amended on December 30, 2019 (together with the Tax Matters Agreement, the “Tax Agreements”).  The Tax Matters Agreement governs Dell Technologies’ and VMware’s respective rights and obligations, both for pre-spin-off periods and post-spin-off periods, regarding income and other taxes, and related matters, including tax liabilities and benefits, attributes, and returns.

[0001571996-23-000007:notes:460]
The timing of the tax payments due to and from related parties is governed by the Tax Agreements.  VMware’s portion of the mandatory one-time transition tax on accumulated earnings of foreign subsidiaries (the “Transition Tax”) is governed by a letter agreement between VMware and Dell Technologies entered into on April 1, 2019.

[0001571996-23-000007:notes:461]
Net receipts from VMware pursuant to the Tax Agreements were immaterial during the fiscal years ended February 3, 2023 and January 28, 2022, and $307 million during the fiscal year ended January 29, 2021, and primarily related to VMware’s portion of the Transition Tax, federal income taxes on Dell Technologies’ consolidated tax return, and state tax payments for combined states.

[0001571996-23-000007:notes:462]
As a result of the activity under the Tax Agreements with VMware, amounts due from VMware were $599 million and $621 million as of February 3, 2023 and January 28, 2022, respectively, primarily related to VMware’s estimated tax obligation resulting from the Transition Tax.  The 2017 Tax Cuts and Jobs Act included a deferral election for an eight-year installment payment method on the Transition Tax.  Dell Technologies expects VMware to pay the remainder of its Transition Tax over a period of three years.

[0001571996-23-000007:notes:463]
Indemnification — Upon consummation of the VMware Spin-off, Dell Technologies recorded net income tax indemnification receivables from VMware related to certain income tax liabilities for which Dell Technologies is jointly and severally liable, but for which it is indemnified by VMware under the Tax Matters Agreement.  The amounts that VMware may be obligated to pay Dell Technologies could vary depending on the outcome of certain unresolved tax matters, which may not be resolved for several years.  The net receivable as of February 3, 2023 and January 28, 2022 was $146 million and $144 million, respectively.


## us-gaap:GovernmentAssistanceTextBlock

[0001571996-23-000007:notes:464]
GOVERNMENT ASSISTANCE
The Company receives government assistance in the form of grants and incentives which vary in size, duration, and conditions from various domestic and international governing bodies and related entities.  For government assistance in which no specific US GAAP applies, the Company accounts for such transactions as a gain contingency and by analogy to a grant model.  Under such model, the Company recognizes the impact of the government assistance on the Consolidated Statements of Income upon reaching reasonable assurance that the Company will comply with the conditions of the assistance and that the grant will be received.  The Company classifies the impact of government assistance on the Consolidated Statements of Income based on the underlying nature and purpose of the assistance.

[0001571996-23-000007:notes:465]
During the fiscal year ended February 3, 2023, government assistance received primarily consisted of the following:

[0001571996-23-000007:notes:466]
The Company received assistance from foreign governmental entities designed, in part, to promote competitive pricing by providing companies with an offset to local sales taxes incurred on the sales of products to customers.  The assistance received is broadly available to companies.  To qualify for this assistance, companies are required to invest a portion of local revenue, derived from goods manufactured locally, into research and development activities.  The incentives in place are currently set to expire at various dates through 2029.  Such expirations could be impacted by future legislation.  During the fiscal year ended February 3, 2023, the Company recognized $297 million within net revenue on the Consolidated Statements of Income related to such assistance.

[0001571996-23-000007:notes:467]
The Company received incentives from foreign governmental entities to provide reimbursement for various costs incurred that are directly tied to the production or delivery of offerings sold to customers.  The agreements governing such assistance require that the Company comply with certain conditions including, but not limited to, the achievement of future operational targets. These agreements currently expire at various dates through 2029.  During the fiscal year ended February 3, 2023, the Company recognized a benefit of $318 million to cost of net revenue on the Consolidated Statements of Income related to such assistance.


## us-gaap:SubsequentEventsTextBlock

[0001571996-23-000007:notes:468]
SUBSEQUENT EVENTS There were no known events occurring after February 3, 2023 and up until the date of issuance of this report that would materially affect the information presented herein.
