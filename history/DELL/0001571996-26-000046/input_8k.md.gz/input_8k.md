# DELL 8-K — 0001571996-26-000039 filed 2026-09-01

## item codes, every 8-K on or before 2026-09-08

- 2026-09-01 0001571996-26-000039 — 2.02, 9.01
- 2026-07-06 0001193125-26-296224 — 3.03, 5.03, 9.01
- 2026-07-01 0001571996-26-000036 — 3.03, 5.07, 8.01, 9.01
- 2026-06-17 0001571996-26-000032 — 3.02
- 2026-06-16 0001193125-26-272720 — 1.01, 2.03, 9.01
- 2026-06-12 0001193125-26-269594 — 8.01, 9.01
- 2026-06-10 0001193125-26-265877 — 1.01, 1.02, 2.03, 9.01
- 2026-05-28 0001571996-26-000021 — 2.02, 9.01
- 2026-04-20 0001571996-26-000013 — 3.02
- 2026-02-26 0001571996-26-000003 — 2.02, 9.01
- 2025-11-25 0001571996-25-000120 — 5.02 — amendment of 0001571996-25-000104
- 2025-11-25 0001571996-25-000118 — 2.02, 9.01
- 2025-10-17 0001571996-25-000114 — 5.02 — amendment of 0001571996-25-000093
- 2025-10-07 0001193125-25-232662 — 7.01, 9.01
- 2025-10-06 0001193125-25-231904 — 1.01, 2.03, 9.01
- 2025-10-02 0001571996-25-000112 — 5.02 — amendment of 0001571996-25-000104
- 2025-10-02 0001571996-25-000111 — 5.02, 9.01
- 2025-09-26 0001571996-25-000107 — 3.02
- 2025-09-23 0001193125-25-213629 — 8.01, 9.01
- 2025-09-08 0001571996-25-000104 — 5.02
- 2025-08-28 0001571996-25-000096 — 2.02, 9.01
- 2025-08-12 0001571996-25-000093 — 5.02
- 2025-07-16 0001571996-25-000081 — 3.02
- 2025-07-01 0001571996-25-000078 — 5.07
- 2025-05-29 0001571996-25-000046 — 2.02, 9.01
- 2025-04-01 0001193125-25-070461 — 1.01, 2.03, 9.01
- 2025-03-27 0001193125-25-065594 — 8.01, 9.01
- 2025-02-27 0001571996-25-000014 — 2.02, 8.01, 9.01
- 2025-01-14 0001571996-25-000004 — 3.02
- 2024-12-03 0001571996-24-000136 — 3.02
- 2024-11-26 0001571996-24-000130 — 2.02, 9.01
- 2024-10-08 0001193125-24-234446 — 1.01, 2.03, 9.01
- 2024-10-02 0001193125-24-231195 — 8.01, 9.01
- 2024-09-19 0001571996-24-000105 — 3.02
- 2024-08-29 0001571996-24-000081 — 2.02, 9.01
- 2024-07-12 0001193125-24-178608 — 3.02
- 2024-07-02 0001571996-24-000074 — 5.07
- 2024-06-10 0001571996-24-000059 — 3.02
- 2024-05-30 0001571996-24-000050 — 2.02, 9.01
- 2024-03-26 0001571996-24-000038 — 3.02
- 2024-03-18 0001193125-24-070193 — 1.01, 2.03, 9.01
- 2024-03-07 0001571996-24-000012 — 3.02
- 2024-03-06 0001193125-24-059631 — 8.01, 9.01
- 2024-02-29 0001571996-24-000008 — 2.02, 9.01
- 2024-01-30 0001571996-24-000004 — 1.02
- 2024-01-18 0001571996-24-000002 — 3.02
- 2023-12-18 0001193125-23-297664 — 8.01, 9.01
- 2023-12-05 0001571996-23-000042 — 3.02
- 2023-12-04 0001193125-23-288428 — 8.01, 9.01
- 2023-11-30 0001571996-23-000039 — 2.02, 9.01
- 2023-10-05 0001193125-23-251131 — 7.01, 8.01, 9.01
- 2023-10-02 0001571996-23-000036 — 5.02 — amendment of 0001571996-23-000034
- 2023-09-26 0001571996-23-000034 — 5.02
- 2023-08-31 0001571996-23-000029 — 2.02, 9.01
- 2023-08-09 0001571996-23-000026 — 5.02 — amendment of 0001571996-23-000002
- 2023-07-28 0001571996-23-000024 — 5.02
- 2023-07-13 0001193125-23-186639 — 3.02
- 2023-06-30 0001193125-23-180570 — 8.01, 9.01
- 2023-06-22 0001571996-23-000021 — 5.02, 5.07, 9.01
- 2023-06-15 0001193125-23-167472 — 8.01, 9.01
- 2023-06-01 0001571996-23-000014 — 2.02, 9.01
- 2023-03-02 0001571996-23-000002 — 2.02, 5.02, 9.01
- 2023-02-06 0001193125-23-024781 — 7.01, 9.01
- 2023-01-24 0001193125-23-014260 — 1.01, 2.03, 9.01
- 2023-01-11 0001193125-23-006528 — 8.01, 9.01
- 2022-11-21 0001571996-22-000041 — 2.02, 9.01
- 2022-11-16 0001571996-22-000038 — 8.01
- 2022-08-25 0001571996-22-000028 — 2.02, 9.01
- 2022-07-18 0001193125-22-196334 — 2.03, 8.01
- 2022-06-29 0001571996-22-000025 — 3.03, 5.03, 5.07, 8.01, 9.01
- 2022-05-26 0001571996-22-000013 — 2.02, 9.01
- 2022-02-24 0001571996-22-000004 — 2.02, 8.01, 9.01
- 2021-12-20 0001193125-21-362482 — 8.01, 9.01
- 2021-12-15 0001193125-21-357927 — 1.01, 2.03, 9.01
- 2021-12-07 0001193125-21-349218 — 8.01, 9.01
- 2021-11-23 0001571996-21-000060 — 2.02, 9.01
- 2021-11-05 0001571996-21-000057 — 1.02, 2.01, 7.01, 8.01, 9.01 — amendment, the index does not say of what
- 2021-11-01 0001571996-21-000052 — 8.01, 9.01
- 2021-11-01 0001193125-21-315488 — 1.01, 1.02, 2.01, 8.01, 9.01
- 2021-10-21 0001193125-21-304052 — 8.01, 9.01
- 2021-10-19 0001571996-21-000050 — 8.01, 9.01
- 2021-10-07 0001193125-21-294210 — 8.01, 9.01
- 2021-09-30 0001571996-21-000047 — 5.02
- 2021-09-27 0001571996-21-000045 — 8.01
- 2021-09-23 0001193125-21-280190 — 7.01, 8.01, 9.01
- 2021-09-20 0001193125-21-276810 — 7.01, 9.01
- 2021-08-26 0001571996-21-000037 — 2.02, 9.01
- 2021-07-01 0001571996-21-000034 — 3.02
- 2021-06-24 0001571996-21-000031 — 5.07
- 2021-06-24 0001193125-21-197644 — 7.01, 9.01
- 2021-06-16 0001571996-21-000029 — 5.02
- 2021-05-27 0001571996-21-000019 — 2.02, 9.01
- 2021-05-03 0001571996-21-000010 — 8.01, 9.01
- 2021-04-14 0001193125-21-116271 — 1.01, 7.01, 9.01
- 2021-02-25 0001571996-21-000003 — 2.02, 9.01
- 2021-02-18 0001193125-21-047844 — 1.01, 2.03, 9.01
- 2020-11-24 0001571996-20-000048 — 2.02, 9.01
- 2020-08-27 0001571996-20-000041 — 2.02, 9.01
- 2020-07-02 0001571996-20-000037 — 5.07
- 2020-05-28 0001571996-20-000028 — 2.02, 9.01
- 2020-04-09 0001193125-20-102602 — 1.01, 2.03, 9.01
- 2020-04-08 0001571996-20-000021 — 5.02
- 2020-04-03 0001571996-20-000019 — 8.01, 9.01
- 2020-03-26 0001571996-20-000015 — 7.01
- 2020-02-27 0001571996-20-000009 — 2.02, 8.01, 9.01
- 2020-02-18 0001571996-20-000005 — 8.01, 9.01
- 2020-01-09 0001571996-20-000002 — 3.02
- 2020-01-06 0001193125-20-002200 — 3.02
- 2019-12-13 0001193125-19-313947 — 3.02
- 2019-12-10 0001571996-19-000052 — 5.02
- 2019-12-02 0001571996-19-000044 — 5.02, 7.01, 9.01
- 2019-11-26 0001571996-19-000042 — 2.02, 9.01
- 2019-09-23 0001193125-19-252192 — 1.01, 2.03, 9.01
- 2019-08-29 0001571996-19-000036 — 2.02, 9.01
- 2019-08-22 0001193125-19-226939 — 7.01, 8.01, 9.01
- 2019-07-11 0001571996-19-000032 — 5.02, 5.07, 9.01
- 2019-07-03 0001571996-19-000030 — 3.02
- 2019-06-27 0001571996-19-000028 — 3.02
- 2019-05-30 0001571996-19-000021 — 2.02, 9.01
- 2019-04-02 0001571996-19-000010 — 5.02
- 2019-03-21 0001193125-19-082281 — 1.01, 1.02, 2.03, 9.01
- 2019-03-19 0001571996-19-000005 — 5.02, 9.01
- 2019-03-14 0001193125-19-074935 — 1.01, 2.03, 9.01
- 2019-03-07 0001193125-19-066045 — 8.01, 9.01
- 2019-02-28 0001571996-19-000002 — 2.02, 9.01
- 2018-12-28 0001193125-18-360943 — 1.01, 1.02, 3.01, 3.03, 5.02, 5.03, 7.01, 8.01, 9.01
- 2018-12-21 0001193125-18-356324 — 1.01, 2.03, 9.01
- 2018-12-14 0001193125-18-349469 — 8.01
- 2018-12-11 0001193125-18-346958 — 5.07, 8.01, 9.01
- 2018-11-29 0001571996-18-000041 — 2.02, 9.01
- 2018-11-28 0001571996-18-000037 — 7.01, 8.01, 9.01
- 2018-11-26 0001193125-18-333967 — 8.01, 9.01
- 2018-11-15 0001193125-18-328110 — 1.01, 9.01 — amendment of 0001193125-18-327222
- 2018-11-15 0001193125-18-327222 — 1.01, 7.01, 9.01
- 2018-10-03 0001193125-18-291390 — 8.01
- 2018-09-06 0001571996-18-000029 — 2.02, 9.01
- 2018-08-06 0001571996-18-000027 — 8.01, 9.01
- 2018-07-02 0001193125-18-210339 — 1.01, 7.01, 9.01
- 2018-06-28 0001571996-18-000024 — 5.07
- 2018-06-04 0001571996-18-000019 — 2.02, 9.01
- 2018-05-17 0001571996-18-000016 — 7.01
- 2018-04-26 0001571996-18-000009 — 7.01, 9.01
- 2018-03-08 0001193125-18-074168 — 2.02, 9.01
- 2018-02-02 0001193125-18-029947 — 7.01, 9.01
- 2017-12-07 0001571996-17-000042 — 2.02, 9.01
- 2017-10-24 0001571996-17-000037 — 1.01, 2.03, 9.01
- 2017-09-15 0001571996-17-000027 — 5.02
- 2017-09-07 0001571996-17-000017 — 2.02, 9.01
- 2017-08-24 0001571996-17-000014 — 8.01
- 2017-06-29 0001571996-17-000011 — 3.03, 5.07, 8.01, 9.01
- 2017-06-08 0001193125-17-197638 — 2.02, 9.01
- 2017-03-30 0001193125-17-102794 — 8.01
- 2017-03-30 0001193125-17-102777 — 2.02, 9.01
- 2017-03-09 0001193125-17-076981 — 1.01, 2.03, 9.01
- 2017-01-17 0001193125-17-011125 — 8.01
- 2016-12-15 0001193125-16-793722 — 8.01
- 2016-12-08 0001193125-16-787976 — 2.02, 9.01
- 2016-11-10 0001193125-16-765964 — 1.02, 8.01
- 2016-11-04 0001193125-16-760249 — 8.01
- 2016-09-13 0001193125-16-708600 — 3.02
- 2016-09-09 0001193125-16-706567 — 1.01, 1.02, 2.01, 2.03, 3.02, 3.03, 5.02, 9.01
- 2016-09-07 0001193125-16-703370 — 3.03, 5.07, 7.01, 8.01, 9.01
- 2016-09-06 0001193125-16-702057 — 2.02, 9.01
- 2016-08-31 0001193125-16-697268 — 8.01, 9.01
- 2016-08-26 0001193125-16-692921 — 8.01, 9.01
- 2016-07-11 0001193125-16-645610 — 8.01
- 2016-07-05 0001193125-16-641679 — 8.01
- 2016-06-22 0001193125-16-629055 — 1.01, 2.03, 8.01, 9.01
- 2016-06-21 0001193125-16-627071 — 8.01, 9.01
- 2016-06-10 0001193125-16-618483 — 2.02, 9.01
- 2016-06-09 0001193125-16-617893 — 8.01, 9.01

## late-filing notifications on or before 2026-09-08

- none on or before 2026-09-08

## item 2.02 — earnings release, exhibit 99.1

[0001571996-26-000039:8k_2_02:1]
EX-99.1
2
exhibit991earnings8kq2fy27.htm
EX-99.1

[0001571996-26-000039:8k_2_02:2]
Document

[0001571996-26-000039:8k_2_02:3]
Exhibit 99.1

[0001571996-26-000039:8k_2_02:4]
Dell Technologies Delivers Second Quarter Fiscal 2027 Financial Results

[0001571996-26-000039:8k_2_02:5]
ROUND ROCK, Texas — Sept. 1, 2026 — Dell Technologies (NYSE: DELL) announces financial results for its fiscal 2027 second quarter and provides guidance for its fiscal 2027 third quarter and full year.

[0001571996-26-000039:8k_2_02:6]
Second-Quarter Summary

[0001571996-26-000039:8k_2_02:7]
•Record revenue of $47.0 billion, up 58% year over year

[0001571996-26-000039:8k_2_02:8]
•Record diluted earnings per share (EPS) of $6.34, up 273% year over year, and record non-GAAP diluted EPS of $7.04, up 203%

[0001571996-26-000039:8k_2_02:9]
•Cash flow from operations of $2.2 billion

[0001571996-26-000039:8k_2_02:10]
•Full-year FY27 revenue guidance of $192.0 billion, up 69% year over year

[0001571996-26-000039:8k_2_02:11]
•Full-year FY27 EPS guidance of $24.37 and non-GAAP EPS guidance of $25.50, up 181% and 148% year over year, respectively

[0001571996-26-000039:8k_2_02:12]
“IT environments have shifted from cost centers to value drivers that fuel growth and competitive advantage, and customers are investing accordingly – creating opportunity across our portfolio,” said Jeff Clarke, vice chairman and chief operating officer, Dell Technologies. “That’s clearest in our AI server business where we booked a record $60.9 billion in orders, recognized a record $16.4 billion in revenue and exited the quarter with a record $95 billion backlog. We’re seeing broader revenue growth as well, with traditional servers and networking up 122%, storage up 26% and our client solutions up 20% year over year. Our second quarter results underscore the compounding benefits of our competitive advantages, the breadth of our portfolio and the strength of our operating model.”

[0001571996-26-000039:8k_2_02:13]
“In our second quarter, we delivered record revenue of $47 billion, record EPS and a record $4.3 billion returned to shareholders,” said David Kennedy, chief financial officer, Dell Technologies. “Our advantages reinforce one another, and throughout the quarter we used these strengths to drive growth, share gains, profitability and cash generation. With AI momentum accelerating and our opportunity expanding across the portfolio, we’re raising our full-year FY27 revenue outlook by $25 billion to $192 billion, up nearly 70% year over year.”

[0001571996-26-000039:8k_2_02:14]
Infrastructure Solutions Group (ISG)

[0001571996-26-000039:8k_2_02:15]
•Record revenue: $31.8 billion, up 89% year over year

[0001571996-26-000039:8k_2_02:16]
•Record AI-Optimized Servers revenue: $16.4 billion, up 100% year over year

[0001571996-26-000039:8k_2_02:17]
•Record Traditional Servers and Networking revenue: $10.5 billion, up 122% year over year

[0001571996-26-000039:8k_2_02:18]
•Record second-quarter Storage revenue: $4.9 billion, up 26% year over year

[0001571996-26-000039:8k_2_02:19]
•Record operating income: $4.8 billion, up 225% year over year

[0001571996-26-000039:8k_2_02:20]
Client Solutions Group (CSG)

[0001571996-26-000039:8k_2_02:21]
•Revenue: $15.0 billion, up 20% year over year

[0001571996-26-000039:8k_2_02:22]
•Record Commercial Client revenue: $13.2 billion, up 22% year over year

[0001571996-26-000039:8k_2_02:23]
•Consumer revenue: $1.8 billion, up 7% year over year

[0001571996-26-000039:8k_2_02:24]
•Operating income: $1.1 billion, up 42% year over year

[0001571996-26-000039:8k_2_02:25]
Capital Return

[0001571996-26-000039:8k_2_02:26]
Dell Technologies returned a record $4.3 billion to shareholders in the second quarter through share repurchases and dividends.

[0001571996-26-000039:8k_2_02:27]
Additionally, on Sept. 1 the company’s board of directors declared a quarterly cash dividend of $0.63 per common share, which will be payable on Oct. 30 to shareholders of record as of Oct. 20.

[0001571996-26-000039:8k_2_02:28]
Guidance Summary

[0001571996-26-000039:8k_2_02:29]
(in billions, except percentages and per share amounts)

[0001571996-26-000039:8k_2_02:30]
Third-Quarter Guidance

[0001571996-26-000039:8k_2_02:31]
|  | Q3FY27 (% Y/Y) |
| Revenue | $ | 49.0 |  |  | 81 | % |
| GAAP diluted EPS | $ | 6.10 |  |  | 168 | % |
| Non-GAAP diluted EPS | $ | 6.50 |  |  | 151 | % |

[0001571996-26-000039:8k_2_02:32]
Full-Year Guidance

[0001571996-26-000039:8k_2_02:33]
|  | FY27 Previous |  | FY27 Updated (% Y/Y) |
| Revenue | $ | 167.0 |  |  | $ | 192.0 |  |  | 69 | % |
| AI-Optimized Servers revenue | $ | 60.0 |  |  | $ | 74.0 |  |  | 200 | % |
| GAAP diluted EPS | $ | 17.31 |  |  | $ | 24.37 |  |  | 181 | % |
| Non-GAAP diluted EPS | $ | 17.90 |  |  | $ | 25.50 |  |  | 148 | % |

[0001571996-26-000039:8k_2_02:34]
Second Quarter Fiscal 2027 Financial Results

[0001571996-26-000039:8k_2_02:35]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | July 31, 2026 |  | August 1, 2025 |  | Change |  | July 31, 2026 |  | August 1, 2025 |  | Change |
|  | (in millions, except per share amounts and percentages; unaudited) |
| Net revenue | $ | 46,971 |  |  | $ | 29,776 |  |  | 58% |  | $ | 90,813 |  |  | $ | 53,154 |  |  | 71% |
| Operating income | $ | 5,385 |  |  | $ | 1,773 |  |  | 204% |  | $ | 9,041 |  |  | $ | 2,938 |  |  | 208% |
| Net income | $ | 4,133 |  |  | $ | 1,164 |  |  | 255% |  | $ | 7,571 |  |  | $ | 2,129 |  |  | 256% |
| Change in cash from operating activities | $ | 2,225 |  |  | $ | 2,543 |  |  | (13)% |  | $ | 6,306 |  |  | $ | 5,339 |  |  | 18% |
| Earnings per share — diluted | $ | 6.34 |  |  | $ | 1.70 |  |  | 273% |  | $ | 11.58 |  |  | $ | 3.07 |  |  | 277% |
| Non-GAAP operating income | $ | 5,929 |  |  | $ | 2,284 |  |  | 160% |  | $ | 10,164 |  |  | $ | 3,950 |  |  | 157% |
| Non-GAAP net income | $ | 4,591 |  |  | $ | 1,591 |  |  | 189% |  | $ | 7,781 |  |  | $ | 2,677 |  |  | 191% |
| Adjusted free cash flow | $ | 8,149 |  |  | $ | 2,518 |  |  | 224% |  | $ | 11,314 |  |  | $ | 4,750 |  |  | 138% |
| Non-GAAP earnings per share — diluted | $ | 7.04 |  |  | $ | 2.32 |  |  | 203% |  | $ | 11.90 |  |  | $ | 3.86 |  |  | 208% |

[0001571996-26-000039:8k_2_02:36]
Information about Dell Technologies’ non-GAAP financial measures is provided under “Non-GAAP Financial Measures” below. All comparisons in this press release are year over year unless otherwise noted.

[0001571996-26-000039:8k_2_02:37]
Operating Segments Results

[0001571996-26-000039:8k_2_02:38]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | July 31, 2026 |  | August 1, 2025 |  | Change |  | July 31, 2026 |  | August 1, 2025 |  | Change |
|  | (in millions, except percentages; unaudited) |
| Infrastructure Solutions Group (ISG): |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| AI-Optimized Servers | $ | 16,401 |  |  | $ | 8,208 |  |  | 100% |  | $ | 32,533 |  |  | $ | 10,090 |  |  | 222% |
| Traditional Servers and Networking | 10,531 |  |  | 4,736 |  |  | 122% |  | 19,074 |  |  | 9,175 |  |  | 108% |
| Storage | 4,850 |  |  | 3,856 |  |  | 26% |  | 9,184 |  |  | 7,852 |  |  | 17% |
| Total ISG net revenue | $ | 31,782 |  |  | $ | 16,800 |  |  | 89% |  | $ | 60,791 |  |  | $ | 27,117 |  |  | 124% |
| Operating income: |  |  |  |  |  |  |  |  |  |  |  |
| ISG operating income | $ | 4,781 |  |  | $ | 1,470 |  |  | 225% |  | $ | 7,836 |  |  | $ | 2,468 |  |  | 218% |
| % of ISG net revenue | 15.0 | % |  | 8.8 | % |  |  |  | 12.9 | % |  | 9.1 | % |  |  |
| % of total reportable segment operating income | 81 | % |  | 65 | % |  |  |  | 77 | % |  | 63 | % |  |  |
| Client Solutions Group (CSG): |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 13,192 |  |  | $ | 10,781 |  |  | 22% |  | $ | 26,212 |  |  | $ | 21,827 |  |  | 20% |
| Consumer | 1,842 |  |  | 1,722 |  |  | 7% |  | 3,431 |  |  | 3,185 |  |  | 8% |
| Total CSG net revenue | $ | 15,034 |  |  | $ | 12,503 |  |  | 20% |  | $ | 29,643 |  |  | $ | 25,012 |  |  | 19% |
| Operating income: |  |  |  |  |  |  |  |  |  |  |  |
| CSG operating income | $ | 1,142 |  |  | $ | 803 |  |  | 42% |  | $ | 2,312 |  |  | $ | 1,456 |  |  | 59% |
| % of CSG net revenue | 7.6 | % |  | 6.4 | % |  |  |  | 7.8 | % |  | 5.8 | % |  |  |
| % of total reportable segment operating income | 19 | % |  | 35 | % |  |  |  | 23 | % |  | 37 | % |  |  |

[0001571996-26-000039:8k_2_02:39]
3

[0001571996-26-000039:8k_2_02:40]
Conference call information

[0001571996-26-000039:8k_2_02:41]
As previously announced, the company will hold a conference call to discuss its performance and financial guidance on Sept. 1 at 3:30 p.m. CST. Prior to the start of the conference call, prepared remarks and a presentation containing additional financial and operating information may be downloaded from investors.delltechnologies.com. The conference call will be presented live over the internet and can be accessed at https://investors.delltechnologies.com/news-events/upcoming-events.

[0001571996-26-000039:8k_2_02:42]
For those unable to listen to the live presentation, the final remarks and presentation with additional financial and operating information will be available following the presentation, and an archived version will be available at the same location for one year.

[0001571996-26-000039:8k_2_02:43]
About Dell Technologies

[0001571996-26-000039:8k_2_02:44]
Dell Technologies (NYSE: DELL) helps organizations and individuals build their digital future and

[0001571996-26-000039:8k_2_02:45]
transform how they work, live and play. The company provides customers with the industry’s broadest

[0001571996-26-000039:8k_2_02:46]
and most innovative technology and services portfolio for the AI era.

[0001571996-26-000039:8k_2_02:47]
Contacts

[0001571996-26-000039:8k_2_02:48]
Investors: Investor_Relations@Dell.com

[0001571996-26-000039:8k_2_02:49]
Media: Media.Relations@Dell.com

[0001571996-26-000039:8k_2_02:50]
# # #

[0001571996-26-000039:8k_2_02:51]
Copyright © 2026 Dell Inc. or its subsidiaries. All Rights Reserved. Dell Technologies, Dell, EMC and Dell EMC are trademarks of Dell Inc. or its subsidiaries. Other trademarks may be trademarks of their respective owners.

[0001571996-26-000039:8k_2_02:52]
Non-GAAP Financial Measures:

[0001571996-26-000039:8k_2_02:53]
This press release presents information about non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, non-GAAP earnings per share  – diluted, free cash flow, and adjusted free cash flow, all of which are non-GAAP financial measures provided as a supplement to the results provided in accordance with generally accepted accounting principles in the United States of America (“GAAP”). A reconciliation of each non-GAAP financial measure to the most directly comparable GAAP financial measure is provided in the attached tables for each of the fiscal periods indicated.

[0001571996-26-000039:8k_2_02:54]
Special Note on Forward-Looking Statements:

[0001571996-26-000039:8k_2_02:55]
Forward-looking statements include, among others, any statements regarding Dell Technologies’ expectations for third-quarter and full-year fiscal 2027 revenue, GAAP diluted earnings per share and non-GAAP diluted earnings per share, and for full-year fiscal 2027 AI-optimized servers revenue, as well as any other statements regarding Dell Technologies’ prospects and its future operations, financial condition, volumes, cash flows, expenses or other financial items, including management’s plans or strategies and objectives for any of the foregoing and any assumptions, expectations or beliefs underlying any of the foregoing.

[0001571996-26-000039:8k_2_02:56]
Dell Technologies’ results or events in future periods could differ materially from those expressed or implied by these forward-looking statements because of risks, uncertainties, and other factors that include, but are not limited to, the following: adverse global economic conditions; competitive pressures; Dell Technologies’ ability to successfully execute its strategy; Dell Technologies’ relationships with third-party suppliers for products and components; Dell Technologies’ use of single-source or limited-source suppliers; effects on Dell Technologies’ operating performance related to demand for AI solutions; management of Dell Technologies’ AI solutions and use of AI in internal functions and operations; Dell Technologies’ ability to deliver high-quality products, software, and services and to manage solutions and products and services transitions in an effective manner; Dell Technologies’ ability to successfully implement its cost efficiency plans; security incidents, including cyber-attacks; Dell Technologies’ foreign operations and ability to generate substantial non-U.S. net revenue; Dell Technologies’ product, services, customer, and geographic sales mix, and seasonal sales trends; the performance of Dell Technologies’ sales channel partners; Dell Technologies’ ability to successfully execute on strategic initiatives including acquisitions and divestitures; access to the capital markets by Dell Technologies or its customers; weak economic conditions, changing customer mix, and the effect of additional regulation on Dell Technologies’ financial services activities; counterparty default risks; material impairment of the value of

[0001571996-26-000039:8k_2_02:57]
goodwill or intangible assets; the loss by Dell Technologies of any contracts for ISG services and solutions and its ability to perform such contracts at their estimated costs; loss by Dell Technologies of government contracts; Dell Technologies’ ability to develop and protect its proprietary intellectual property or obtain licenses to intellectual property developed by others on commercially reasonable and competitive terms; disruptions in Dell Technologies’ infrastructure; Dell Technologies’ ability to hedge effectively its exposure to fluctuations in foreign currency exchange rates and interest rates; adverse legislative or regulatory tax changes, expiration of tax holidays or favorable tax rate structures, or unfavorable outcomes in tax audits and other tax compliance matters; declines in fair value or impairment of portfolio investments; unfavorable results of legal proceedings; evolving and varied expectations and regulatory requirements relating to sustainability issues; the effect of global climate change and related legal, regulatory or market measures; compliance with environmental and safety laws; compliance requirements of anti-corruption laws, economic sanctions and other trade laws, human rights laws, or other laws regulating its international operations; Dell Technologies’ dependence on the services of Michael Dell and key employees; Dell Technologies’ level of indebtedness; and business and financial factors and legal restrictions affecting continuation of Dell Technologies’ quarterly cash dividend policy and dividend rate.

[0001571996-26-000039:8k_2_02:58]
This list of risks, uncertainties, and other factors is not complete. Dell Technologies discusses some of these matters more fully, as well as certain risk factors that could affect Dell Technologies’ business, financial condition, results of operations, and prospects, in its reports filed with the SEC, including Dell Technologies’ annual report on Form 10-K for the fiscal year ended January 30, 2026, quarterly reports on Form 10-Q, and current reports on Form 8-K. These filings are available for review through the SEC’s website at www.sec.gov. Any or all forward-looking statements Dell Technologies makes may turn out to be wrong and can be affected by inaccurate assumptions Dell Technologies might make or by known or unknown risks, uncertainties, and other factors, including those identified in this press release. Accordingly, you should not place undue reliance on the forward-looking statements made in this press release, which speak only as of its date. Dell Technologies does not undertake to update, and expressly disclaims any duty to update, its forward-looking statements, whether as a result of circumstances or events that arise after the date they are made, new information, or otherwise.

[0001571996-26-000039:8k_2_02:59]
5

[0001571996-26-000039:8k_2_02:60]
DELL TECHNOLOGIES INC.

[0001571996-26-000039:8k_2_02:61]
Condensed Consolidated Statements of Income and Related Financial Highlights

[0001571996-26-000039:8k_2_02:62]
(in millions, except per share amounts and percentages; unaudited)

[0001571996-26-000039:8k_2_02:63]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | July 31, 2026 |  | August 1, 2025 |  | Change |  | July 31, 2026 |  | August 1, 2025 |  | Change |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Products | $ | 41,112 |  |  | $ | 23,935 |  |  | 72% |  | $ | 79,217 |  |  | $ | 41,534 |  |  | 91% |
| Services | 5,859 |  |  | 5,841 |  |  | —% |  | 11,596 |  |  | 11,620 |  |  | —% |
| Total net revenue | 46,971 |  |  | 29,776 |  |  | 58% |  | 90,813 |  |  | 53,154 |  |  | 71% |
| Cost of net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Products | 33,990 |  |  | 21,044 |  |  | 62% |  | 66,842 |  |  | 36,160 |  |  | 85% |
| Services | 3,151 |  |  | 3,285 |  |  | (4)% |  | 6,359 |  |  | 6,610 |  |  | (4)% |
| Total cost of revenue | 37,141 |  |  | 24,329 |  |  | 53% |  | 73,201 |  |  | 42,770 |  |  | 71% |
| Gross margin | 9,830 |  |  | 5,447 |  |  | 80% |  | 17,612 |  |  | 10,384 |  |  | 70% |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative | 3,336 |  |  | 2,889 |  |  | 15% |  | 6,479 |  |  | 5,853 |  |  | 11% |
| Research and development | 1,109 |  |  | 785 |  |  | 41% |  | 2,092 |  |  | 1,593 |  |  | 31% |
| Total operating expenses | 4,445 |  |  | 3,674 |  |  | 21% |  | 8,571 |  |  | 7,446 |  |  | 15% |
| Operating income | 5,385 |  |  | 1,773 |  |  | 204% |  | 9,041 |  |  | 2,938 |  |  | 208% |
| Interest and other, net | (254) |  |  | (333) |  |  | 24% |  | 38 |  |  | (415) |  |  | 109% |
| Income before income taxes | 5,131 |  |  | 1,440 |  |  | 256% |  | 9,079 |  |  | 2,523 |  |  | 260% |
| Income tax expense | 998 |  |  | 276 |  |  | 262% |  | 1,508 |  |  | 394 |  |  | 283% |
| Net income | $ | 4,133 |  |  | $ | 1,164 |  |  | 255% |  | $ | 7,571 |  |  | $ | 2,129 |  |  | 256% |
| Earnings per share: |  |  |  |  |  |  |  |  |  |  |  |
| Basic | $ | 6.41 |  |  | $ | 1.72 |  |  | 273% |  | $ | 11.70 |  |  | $ | 3.11 |  |  | 276% |
| Diluted | $ | 6.34 |  |  | $ | 1.70 |  |  | 273% |  | $ | 11.58 |  |  | $ | 3.07 |  |  | 277% |
| Weighted average shares: |  |  |  |  |  |  |  |  |  |  |  |
| Basic | 645 |  |  | 678 |  |  | (5)% |  | 647 |  | 685 |  | (6)% |
| Diluted | 652 |  |  | 686 |  |  | (5)% |  | 654 |  | 694 |  | (6)% |
| Percentage of Total Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Gross margin | 20.9 | % |  | 18.3 | % |  |  |  | 19.4 | % |  | 19.5 | % |  |  |
| Selling, general, and administrative | 7.1 | % |  | 9.7 | % |  |  |  | 7.1 | % |  | 11.0 | % |  |  |
| Research and development | 2.4 | % |  | 2.6 | % |  |  |  | 2.3 | % |  | 3.0 | % |  |  |
| Operating expenses | 9.5 | % |  | 12.3 | % |  |  |  | 9.4 | % |  | 14.0 | % |  |  |
| Operating income | 11.5 | % |  | 6.0 | % |  |  |  | 10.0 | % |  | 5.5 | % |  |  |
| Income before income taxes | 10.9 | % |  | 4.8 | % |  |  |  | 10.0 | % |  | 4.7 | % |  |  |
| Net income | 8.8 | % |  | 3.9 | % |  |  |  | 8.3 | % |  | 4.0 | % |  |  |
| Income tax rate | 19.5 | % |  | 19.2 | % |  |  |  | 16.6 | % |  | 15.6 | % |  |  |

[0001571996-26-000039:8k_2_02:64]
Amounts are based on underlying data and may not visually foot due to rounding.

[0001571996-26-000039:8k_2_02:65]
6

[0001571996-26-000039:8k_2_02:66]
DELL TECHNOLOGIES INC.

[0001571996-26-000039:8k_2_02:67]
Condensed Consolidated Statements of Financial Position

[0001571996-26-000039:8k_2_02:68]
(in millions; unaudited)

[0001571996-26-000039:8k_2_02:69]
|  | July 31, 2026 |  | January 30, 2026 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 11,569 |  |  | $ | 11,528 |  |
| Accounts receivable, net of allowance of $56 and $77 | 22,918 |  |  | 17,585 |  |
| Short-term financing receivables, net of allowance of $186 and $121 | 12,805 |  |  | 8,458 |  |
| Inventories | 21,290 |  |  | 10,437 |  |
| Other current assets | 11,965 |  |  | 9,594 |  |
| Total current assets | 80,547 |  |  | 57,602 |  |
| Property, plant, and equipment, net | 7,417 |  |  | 6,676 |  |
| Long-term investments | 2,679 |  |  | 1,730 |  |
| Long-term financing receivables, net of allowance of $128 and $92 | 7,625 |  |  | 5,822 |  |
| Goodwill | 19,448 |  |  | 19,547 |  |
| Intangible assets, net | 4,347 |  |  | 4,533 |  |
| Other non-current assets | 5,330 |  |  | 5,376 |  |
| Total assets | $ | 127,393 |  |  | $ | 101,286 |  |
| LIABILITIES AND SHAREHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Short-term debt | $ | 8,481 |  |  | $ | 7,990 |  |
| Accounts payable | 49,723 |  |  | 33,630 |  |
| Accrued and other | 10,738 |  |  | 8,315 |  |
| Short-term deferred revenue | 14,761 |  |  | 13,334 |  |
| Total current liabilities | 83,703 |  |  | 63,269 |  |
| Long-term debt | 25,985 |  |  | 23,513 |  |
| Long-term deferred revenue | 14,957 |  |  | 13,596 |  |
| Other non-current liabilities | 4,175 |  |  | 3,378 |  |
| Total liabilities | 128,820 |  |  | 103,756 |  |
| Shareholders’ equity (deficit): |  |  |  |
| Common stock and capital in excess of $0.01 par value | 9,277 |  |  | 9,457 |  |
| Treasury stock at cost | (20,010) |  |  | (14,533) |  |
| Retained earnings | 10,065 |  |  | 3,325 |  |
| Accumulated other comprehensive loss | (759) |  |  | (719) |  |
| Total shareholders' equity (deficit) | (1,427) |  |  | (2,470) |  |
| Total liabilities and shareholders' equity | $ | 127,393 |  |  | $ | 101,286 |  |

[0001571996-26-000039:8k_2_02:70]
7

[0001571996-26-000039:8k_2_02:71]
DELL TECHNOLOGIES INC.

[0001571996-26-000039:8k_2_02:72]
Condensed Consolidated Statements of Cash Flows

[0001571996-26-000039:8k_2_02:73]
(in millions; unaudited)

[0001571996-26-000039:8k_2_02:74]
|  | Three Months Ended |  | Six Months Ended |
|  | July 31, 2026 |  | August 1, 2025 |  | July 31, 2026 |  | August 1, 2025 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |
| Net income | $ | 4,133 |  |  | $ | 1,164 |  |  | $ | 7,571 |  |  | $ | 2,129 |  |
| Adjustments to reconcile net income to net cash provided by operating activities | (1,908) |  |  | 1,379 |  |  | (1,265) |  |  | 3,210 |  |
| Change in cash from operating activities | 2,225 |  |  | 2,543 |  |  | 6,306 |  |  | 5,339 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |
| Purchases of investments | (211) |  |  | (28) |  |  | (335) |  |  | (125) |  |
| Maturities and sales of investments | 89 |  |  | 28 |  |  | 90 |  |  | 59 |  |
| Capital expenditures and capitalized software development costs | (1,239) |  |  | (675) |  |  | (2,202) |  |  | (1,243) |  |
| Divestitures of businesses and assets, net | — |  |  | — |  |  | — |  |  | 533 |  |
| Other | 24 |  |  | 20 |  |  | 43 |  |  | 33 |  |
| Change in cash from investing activities | (1,337) |  |  | (655) |  |  | (2,404) |  |  | (743) |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |
| Repurchases of common stock | (3,796) |  |  | (940) |  |  | (5,424) |  |  | (2,920) |  |
| Repurchases of common stock for employee tax withholdings | (18) |  |  | (5) |  |  | (555) |  |  | (357) |  |
| Payments of dividends and dividend equivalents | (405) |  |  | (366) |  |  | (869) |  |  | (762) |  |
| Proceeds from debt | 4,386 |  |  | 962 |  |  | 6,851 |  |  | 7,270 |  |
| Repayments of debt | (1,017) |  |  | (1,114) |  |  | (3,805) |  |  | (3,424) |  |
| Debt-related costs and other, net | (32) |  |  | (2) |  |  | (34) |  |  | (35) |  |
| Change in cash from financing activities | (882) |  |  | (1,465) |  |  | (3,836) |  |  | (228) |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash | (22) |  |  | 15 |  |  | (35) |  |  | 104 |  |
| Change in cash, cash equivalents, and restricted cash | (16) |  |  | 438 |  |  | 31 |  |  | 4,472 |  |
| Cash, cash equivalents, and restricted cash at beginning of the period | 11,753 |  |  | 7,853 |  |  | 11,706 |  |  | 3,819 |  |
| Cash, cash equivalents, and restricted cash at end of the period | $ | 11,737 |  |  | $ | 8,291 |  |  | $ | 11,737 |  |  | $ | 8,291 |  |

[0001571996-26-000039:8k_2_02:75]
DELL TECHNOLOGIES INC.

[0001571996-26-000039:8k_2_02:76]
Segment Information

[0001571996-26-000039:8k_2_02:77]
(in millions, except percentages; unaudited; continued on next page)

[0001571996-26-000039:8k_2_02:78]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | July 31, 2026 |  | August 1, 2025 |  | Change |  | July 31, 2026 |  | August 1, 2025 |  | Change |
| Infrastructure Solutions Group (ISG): |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| AI-Optimized Servers | $ | 16,401 |  |  | $ | 8,208 |  |  | 100% |  | $ | 32,533 |  |  | $ | 10,090 |  |  | 222% |
| Traditional Servers and Networking | 10,531 |  |  | 4,736 |  |  | 122% |  | 19,074 |  |  | 9,175 |  |  | 108% |
| Storage | 4,850 |  |  | 3,856 |  |  | 26% |  | 9,184 |  |  | 7,852 |  |  | 17% |
| Total ISG net revenue | $ | 31,782 |  |  | $ | 16,800 |  |  | 89% |  | $ | 60,791 |  |  | $ | 27,117 |  |  | 124% |
| Operating income: |  |  |  |  |  |  |  |  |  |  |  |
| ISG operating income | $ | 4,781 |  |  | $ | 1,470 |  |  | 225% |  | $ | 7,836 |  |  | $ | 2,468 |  |  | 218% |
| % of ISG net revenue | 15.0 | % |  | 8.8 | % |  |  |  | 12.9 | % |  | 9.1 | % |  |  |
| % of total reportable segment operating income | 81 | % |  | 65 | % |  |  |  | 77 | % |  | 63 | % |  |  |
| Client Solutions Group (CSG): |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 13,192 |  |  | $ | 10,781 |  |  | 22% |  | $ | 26,212 |  |  | $ | 21,827 |  |  | 20% |
| Consumer | 1,842 |  |  | 1,722 |  |  | 7% |  | 3,431 |  |  | 3,185 |  |  | 8% |
| Total CSG net revenue | $ | 15,034 |  |  | $ | 12,503 |  |  | 20% |  | $ | 29,643 |  |  | $ | 25,012 |  |  | 19% |
| Operating income: |  |  |  |  |  |  |  |  |  |  |  |
| CSG operating income | $ | 1,142 |  |  | $ | 803 |  |  | 42% |  | $ | 2,312 |  |  | $ | 1,456 |  |  | 59% |
| % of CSG net revenue | 7.6 | % |  | 6.4 | % |  |  |  | 7.8 | % |  | 5.8 | % |  |  |
| % of total reportable segment operating income | 19 | % |  | 35 | % |  |  |  | 23 | % |  | 37 | % |  |  |

[0001571996-26-000039:8k_2_02:79]
Amounts are based on underlying data and may not visually foot due to rounding.

[0001571996-26-000039:8k_2_02:80]
9

[0001571996-26-000039:8k_2_02:81]
DELL TECHNOLOGIES INC.

[0001571996-26-000039:8k_2_02:82]
Segment Information

[0001571996-26-000039:8k_2_02:83]
(in millions; unaudited; continued)

[0001571996-26-000039:8k_2_02:84]
|  | Three Months Ended |  | Six Months Ended |
|  | July 31, 2026 |  | August 1, 2025 |  | July 31, 2026 |  | August 1, 2025 |
| Reconciliation to consolidated net revenue: |  |  |  |  |  |  |  |
| Reportable segment net revenue | $ | 46,816 |  |  | $ | 29,303 |  |  | $ | 90,434 |  |  | $ | 52,129 |  |
| Corporate and other (a) | 155 |  |  | 473 |  |  | 379 |  |  | 1,025 |  |
| Total consolidated net revenue | $ | 46,971 |  |  | $ | 29,776 |  |  | $ | 90,813 |  |  | $ | 53,154 |  |
| Reconciliation to consolidated operating income: |  |  |  |  |  |  |  |
| Reportable segment operating income (b) | $ | 5,923 |  |  | $ | 2,273 |  |  | $ | 10,148 |  |  | $ | 3,924 |  |
| Corporate and other (a) | 6 |  |  | 11 |  |  | 16 |  |  | 26 |  |
| Amortization of intangibles (c) | (96) |  |  | (125) |  |  | (193) |  |  | (251) |  |
| Stock-based compensation expense (d) | (184) |  |  | (179) |  |  | (373) |  |  | (369) |  |
| Other corporate expenses (e) | (264) |  |  | (207) |  |  | (557) |  |  | (392) |  |
| Total consolidated operating income (f) | $ | 5,385 |  |  | $ | 1,773 |  |  | $ | 9,041 |  |  | $ | 2,938 |  |

[0001571996-26-000039:8k_2_02:85]
_________________

[0001571996-26-000039:8k_2_02:86]
(a)Corporate and other includes VMware Resale and other items that are managed at the corporate level and are not allocated to reportable segments.

[0001571996-26-000039:8k_2_02:87]
(b)Depreciation expense directly attributable to each reportable segment is included in the operating results of each segment. However, the Chief Operating Decision Maker does not evaluate depreciation expense by operating segment, and therefore such expense is not separately presented.

[0001571996-26-000039:8k_2_02:88]
(c)Amortization of intangibles includes non-cash purchase accounting adjustments that are primarily related to the EMC merger transaction completed in September 2016.

[0001571996-26-000039:8k_2_02:89]
(d)Stock-based compensation expense consists of equity awards granted based on the estimated fair value of those awards at grant date.

[0001571996-26-000039:8k_2_02:90]
(e)Other corporate expenses includes severance expenses, payroll taxes associated with stock-based compensation, incentive charges related to equity investments, transaction-related expenses, and impairment charges.

[0001571996-26-000039:8k_2_02:91]
(f)Income and expenses within Interest and other, net, is not allocated to the reportable segments. Therefore, the company only reports reportable segment operating income.

[0001571996-26-000039:8k_2_02:92]
SUPPLEMENTAL SELECTED NON-GAAP FINANCIAL MEASURES

[0001571996-26-000039:8k_2_02:93]
These tables present information about the company’s non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, non-GAAP earnings per share - diluted, free cash flow and adjusted free cash flow, all of which are non-GAAP financial measures provided as a supplement to the results provided in accordance with generally accepted accounting principles in the United States of America (“GAAP”). A detailed discussion of Dell Technologies’ reasons for including certain of these non-GAAP financial measures, the limitations associated with these measures, the items excluded from these measures, and the company’s reason for excluding those items are presented in “Management’s Discussion and Analysis of Financial Condition and Results of Operations — Non-GAAP Financial Measures” in the company’s periodic reports filed with the SEC. Dell Technologies encourages investors to review the non-GAAP discussion in these reports in conjunction with the presentation of non-GAAP financial measures.

[0001571996-26-000039:8k_2_02:94]
11

[0001571996-26-000039:8k_2_02:95]
DELL TECHNOLOGIES INC.

[0001571996-26-000039:8k_2_02:96]
Selected Financial Measures

[0001571996-26-000039:8k_2_02:97]
(in millions, except per share amounts and percentages; unaudited)

[0001571996-26-000039:8k_2_02:98]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | July 31, 2026 |  | August 1, 2025 |  | Change |  | July 31, 2026 |  | August 1, 2025 |  | Change |
| Net revenue | $ | 46,971 |  |  | $ | 29,776 |  |  | 58% |  | $ | 90,813 |  |  | $ | 53,154 |  |  | 71% |
| Non-GAAP gross margin | $ | 9,929 |  |  | $ | 5,572 |  |  | 78% |  | $ | 17,876 |  |  | $ | 10,629 |  |  | 68% |
| % of net revenue | 21.1 | % |  | 18.7 | % |  |  |  | 19.7 | % |  | 20.0 | % |  |  |
| Non-GAAP operating expenses | $ | 4,000 |  |  | $ | 3,288 |  |  | 22% |  | $ | 7,712 |  |  | $ | 6,679 |  |  | 15% |
| % of net revenue | 8.5 | % |  | 11.0 | % |  |  |  | 8.5 | % |  | 12.6 | % |  |  |
| Non-GAAP operating income | $ | 5,929 |  |  | $ | 2,284 |  |  | 160% |  | $ | 10,164 |  |  | $ | 3,950 |  |  | 157% |
| % of net revenue | 12.6 | % |  | 7.7 | % |  |  |  | 11.2 | % |  | 7.4 | % |  |  |
| Non-GAAP net income | $ | 4,591 |  |  | $ | 1,591 |  |  | 189% |  | $ | 7,781 |  |  | $ | 2,677 |  |  | 191% |
| % of net revenue | 9.8 | % |  | 5.3 | % |  |  |  | 8.6 | % |  | 5.0 | % |  |  |
| Non-GAAP earnings per share — diluted | $ | 7.04 |  |  | $ | 2.32 |  |  | 203% |  | $ | 11.90 |  |  | $ | 3.86 |  |  | 208% |

[0001571996-26-000039:8k_2_02:99]
Amounts are based on underlying data and may not visually foot due to rounding.

[0001571996-26-000039:8k_2_02:100]
DELL TECHNOLOGIES INC.

[0001571996-26-000039:8k_2_02:101]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-26-000039:8k_2_02:102]
(in millions, except percentages; unaudited; continued on next page)

[0001571996-26-000039:8k_2_02:103]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | July 31, 2026 |  | August 1, 2025 |  | Change |  | July 31, 2026 |  | August 1, 2025 |  | Change |
| Gross margin | $ | 9,830 |  |  | $ | 5,447 |  |  | 80% |  | $ | 17,612 |  |  | $ | 10,384 |  |  | 70% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 31 |  |  | 39 |  |  |  |  | 57 |  |  | 80 |  |  |  |
| Stock-based compensation expense | 43 |  |  | 37 |  |  |  |  | 87 |  |  | 76 |  |  |  |
| Other corporate expenses | 25 |  |  | 49 |  |  |  |  | 120 |  |  | 89 |  |  |  |
| Non-GAAP gross margin | $ | 9,929 |  |  | $ | 5,572 |  |  | 78% |  | $ | 17,876 |  |  | $ | 10,629 |  |  | 68% |
| Operating expenses | $ | 4,445 |  |  | $ | 3,674 |  |  | 21% |  | $ | 8,571 |  |  | $ | 7,446 |  |  | 15% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | (65) |  |  | (86) |  |  |  |  | (136) |  |  | (171) |  |  |  |
| Stock-based compensation expense | (141) |  |  | (142) |  |  |  |  | (286) |  |  | (293) |  |  |  |
| Other corporate expenses | (239) |  |  | (158) |  |  |  |  | (437) |  |  | (303) |  |  |  |
| Non-GAAP operating expenses | $ | 4,000 |  |  | $ | 3,288 |  |  | 22% |  | $ | 7,712 |  |  | $ | 6,679 |  |  | 15% |
| Operating income | $ | 5,385 |  |  | $ | 1,773 |  |  | 204% |  | $ | 9,041 |  |  | $ | 2,938 |  |  | 208% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 96 |  |  | 125 |  |  |  |  | 193 |  |  | 251 |  |  |  |
| Stock-based compensation expense | 184 |  |  | 179 |  |  |  |  | 373 |  |  | 369 |  |  |  |
| Other corporate expenses | 264 |  |  | 207 |  |  |  |  | 557 |  |  | 392 |  |  |  |
| Non-GAAP operating income | $ | 5,929 |  |  | $ | 2,284 |  |  | 160% |  | $ | 10,164 |  |  | $ | 3,950 |  |  | 157% |
| Net income | $ | 4,133 |  |  | $ | 1,164 |  |  | 255% |  | $ | 7,571 |  |  | $ | 2,129 |  |  | 256% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 96 |  |  | 125 |  |  |  |  | 193 |  |  | 251 |  |  |  |
| Stock-based compensation expense | 184 |  |  | 179 |  |  |  |  | 373 |  |  | 369 |  |  |  |
| Other corporate expenses | 260 |  |  | 200 |  |  |  |  | 548 |  |  | 142 |  |  |  |
| Fair value adjustments on equity investments | (73) |  |  | (4) |  |  |  |  | (704) |  |  | (21) |  |  |  |
| Aggregate adjustment for income taxes (a) | (9) |  |  | (73) |  |  |  |  | (200) |  |  | (193) |  |  |  |
| Non-GAAP net income | $ | 4,591 |  |  | $ | 1,591 |  |  | 189% |  | $ | 7,781 |  |  | $ | 2,677 |  |  | 191% |

[0001571996-26-000039:8k_2_02:104]
____________________

[0001571996-26-000039:8k_2_02:105]
(a)The company’s non-GAAP income tax is calculated using a fixed estimated annual tax rate.

[0001571996-26-000039:8k_2_02:106]
13

[0001571996-26-000039:8k_2_02:107]
DELL TECHNOLOGIES INC.

[0001571996-26-000039:8k_2_02:108]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-26-000039:8k_2_02:109]
(unaudited; continued)

[0001571996-26-000039:8k_2_02:110]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | July 31, 2026 |  | August 1, 2025 |  | Change |  | July 31, 2026 |  | August 1, 2025 |  | Change |
| Earnings per share — diluted | $ | 6.34 |  |  | $ | 1.70 |  |  | 273 | % |  | $ | 11.58 |  |  | $ | 3.07 |  |  | 277 | % |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 0.15 |  |  | 0.19 |  |  |  |  | 0.29 |  |  | 0.36 |  |  |  |
| Stock-based compensation expense | 0.28 |  |  | 0.26 |  |  |  |  | 0.57 |  |  | 0.53 |  |  |  |
| Other corporate expenses | 0.39 |  |  | 0.29 |  |  |  |  | 0.84 |  |  | 0.21 |  |  |  |
| Fair value adjustments on equity investments | (0.11) |  |  | (0.01) |  |  |  |  | (1.08) |  |  | (0.03) |  |  |  |
| Aggregate adjustment for income taxes (a) | (0.01) |  |  | (0.11) |  |  |  |  | (0.30) |  |  | (0.28) |  |  |  |
| Non-GAAP earnings per share — diluted | $ | 7.04 |  |  | $ | 2.32 |  |  | 203 | % |  | $ | 11.90 |  |  | $ | 3.86 |  |  | 208 | % |

[0001571996-26-000039:8k_2_02:111]
____________________

[0001571996-26-000039:8k_2_02:112]
(a)The company’s non-GAAP income tax is calculated using a fixed estimated annual tax rate.

[0001571996-26-000039:8k_2_02:113]
DELL TECHNOLOGIES INC.

[0001571996-26-000039:8k_2_02:114]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-26-000039:8k_2_02:115]
(in millions, except percentages; unaudited; continued)

[0001571996-26-000039:8k_2_02:116]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |  |  |  |  |
|  | July 31, 2026 |  | August 1, 2025 |  | Change |  | July 31, 2026 |  | August 1, 2025 |  | Change |  |  |  |  |
| Cash flow from operations | $ | 2,225 |  |  | $ | 2,543 |  |  | (13) | % |  | $ | 6,306 |  |  | $ | 5,339 |  |  | 18 | % |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Capital expenditures and capitalized software development costs, net (a) | (1,239) |  |  | (675) |  |  |  |  | (2,202) |  |  | (1,243) |  |  |  |  |  |  |  |
| Free cash flow | $ | 986 |  |  | $ | 1,868 |  |  | (47) | % |  | $ | 4,104 |  |  | $ | 4,096 |  |  | — | % |  |  |  |  |
| Free cash flow | $ | 986 |  |  | $ | 1,868 |  |  | (47) | % |  | $ | 4,104 |  |  | $ | 4,096 |  |  | — | % |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Financing receivables (b) | 6,667 |  |  | 592 |  |  |  |  | 6,404 |  |  | 569 |  |  |  |  |  |  |  |
| Equipment under operating leases (c) | 496 |  |  | 58 |  |  |  |  | 806 |  |  | 85 |  |  |  |  |  |  |  |
| Adjusted free cash flow | $ | 8,149 |  |  | $ | 2,518 |  |  | 224 | % |  | $ | 11,314 |  |  | $ | 4,750 |  |  | 138 | % |  |  |  |  |

[0001571996-26-000039:8k_2_02:117]
____________________

[0001571996-26-000039:8k_2_02:118]
(a)Capital expenditures and capitalized software development costs, net includes proceeds from sales of facilities, land, and other assets.

[0001571996-26-000039:8k_2_02:119]
(b)Financing receivables represent the operating cash flow impact from the change in financing receivables.

[0001571996-26-000039:8k_2_02:120]
(c)Equipment under operating leases represents the net impact of capital expenditures and depreciation expense for leases and contractually embedded leases identified within flexible consumption arrangements.

[0001571996-26-000039:8k_2_02:121]
15

[0001571996-26-000039:8k_2_02:122]
DELL TECHNOLOGIES INC.

[0001571996-26-000039:8k_2_02:123]
Reconciliation of Non-GAAP Financial Measures in Summary Guidance

[0001571996-26-000039:8k_2_02:124]
(unaudited)

[0001571996-26-000039:8k_2_02:125]
|  | Three Months Ending |  | Fiscal Year Ending |
|  | October 30, 2026 |  | January 29, 2027 |
|  |  |  | Previous |  | Updated |
| Earnings per share — diluted | $ | 6.10 |  |  | $ | 17.31 |  |  | $ | 24.37 |  |
| Non-GAAP adjustments: |  |  |  |  |  |
| Amortization of intangibles (a) | 0.15 |  |  | 0.59 |  |  | 0.60 |  |
| Stock-based compensation | 0.29 |  |  | 1.16 |  |  | 1.16 |  |
| Other corporate expenses (b) | — |  |  | 0.45 |  |  | 0.84 |  |
| Fair value adjustments on equity investments (c) | — |  |  | (0.97) |  |  | (1.08) |  |
| Aggregate adjustment for income taxes (d) | (0.04) |  |  | (0.64) |  |  | (0.39) |  |
| Non-GAAP earnings per share — diluted | $ | 6.50 |  |  | $ | 17.90 |  |  | $ | 25.50 |  |

[0001571996-26-000039:8k_2_02:126]
____________________

[0001571996-26-000039:8k_2_02:127]
(a)Amortization of intangibles represents an estimate for acquisitions completed as of July 31, 2026 and does not include estimates for potential acquisitions, if any, during fiscal 2027.

[0001571996-26-000039:8k_2_02:128]
(b)Consists primarily of severance expenses, payroll taxes associated with stock-based compensation, transaction-related expenses, impairment charges, and incentive charges related to equity investments. No estimate is included for severance expense as such expense cannot be reasonably estimated at this time.

[0001571996-26-000039:8k_2_02:129]
(c)No estimates are included for potential fair value adjustments on strategic investments given the potential volatility of either gains or losses on those equity investments.

[0001571996-26-000039:8k_2_02:130]
(d)The fiscal 2027 aggregate adjustment to reconcile non-GAAP income tax expense to GAAP income tax expense is approximately $0.3 billion. The aggregate adjustment for income taxes is the estimated combined income tax effect for the adjustments shown above as well as an adjustment for discrete tax items. The company’s non-GAAP income tax is calculated using a fixed estimated annual tax rate.

[0001571996-26-000039:8k_2_02:131]
16
