# DELL MD&A — 0001571996-17-000045


## mdna

[0001571996-17-000045:mdna:1]
[same as prior period, unchanged from 0001571996-17-000020:mdna:1]

[0001571996-17-000045:mdna:2]
[same as prior period, unchanged from 0001571996-17-000020:mdna:2]

[0001571996-17-000045:mdna:3]
[same as prior period, unchanged from 0001571996-17-000020:mdna:3]

[0001571996-17-000045:mdna:4]
[same as prior period, unchanged from 0001571996-17-000020:mdna:4]

[0001571996-17-000045:mdna:5]
[same as prior period, unchanged from 0001571996-17-000020:mdna:5]

[0001571996-17-000045:mdna:6]
[same as prior period, unchanged from 0001571996-17-000020:mdna:6]

[0001571996-17-000045:mdna:7]
Dell Technologies is a strategically aligned family of businesses that brings together the entire infrastructure from hardware to software to services — from the edge to the core to the cloud.  The core of IT is evolving in our hyper-connected world, containing both centralized data centers and geographically distributed hyper-converged infrastructure.  Dell Technologies is a leader in the traditional technology of today and a leader in the cloud-native infrastructure of tomorrow.  We are a leading provider of scalable IT solutions enabling customers to be more efficient, mobile, informed, and secure.  Through our recent combination with EMC, Dell Technologies now primarily encompasses our Client Solutions Group, Infrastructure Solutions Group, VMware, Inc., RSA Information Security, SecureWorks Corp. ("SecureWorks"), Pivotal Software, Inc. ("Pivotal"), and Boomi, Inc ("Boomi").  We are focused on providing technology solutions and services that accelerate digital transformation.  We believe technology exists to drive human progress on a global scale — to create new markets, reshape industries, and improve lives.  We are positioned to help customers of any size build the essential infrastructure to modernize IT and enable digital business, and are differentiated by our practical innovation and efficient, simple, and affordable solutions.

[0001571996-17-000045:mdna:8]
[same as prior period, unchanged from 0001571996-17-000020:mdna:8]

[0001571996-17-000045:mdna:9]
We celebrated the one year anniversary of our historic merger with EMC in September 2017, and recognize the many accomplishments we have made over that year.  These accomplishments include the broad expansion of our product portfolio, integration of our supply chain, and achievement of revenue synergies across the business.  We continue to work on the integration of EMC acquired businesses and on strengthening our combined go-to-market initiatives.  During this period of transition and integration, we remain focused on supporting our customers with outstanding solutions, products, and services.  We will continue our focus on building superior customer relationships through our direct model and our network of channel

[0001571996-17-000045:mdna:10]
[same as prior period, unchanged from 0001571996-17-000020:mdna:47]

[0001571996-17-000045:mdna:11]
partners, which includes value-added resellers, system integrators, distributors, and retailers.  We also will continue investing in strategic solutions and enhancing our go-to-market sales and marketing capabilities as we seek to strengthen our position as leading global technology company poised for long-term sustainable growth and innovation.

[0001571996-17-000045:mdna:12]
[same as prior period, unchanged from 0001571996-17-000020:mdna:10]

[0001571996-17-000045:mdna:13]
[same as prior period, unchanged from 0001571996-17-000020:mdna:11]

[0001571996-17-000045:mdna:14]
[same as prior period, unchanged from 0001571996-17-000020:mdna:12]

[0001571996-17-000045:mdna:15]
[same as prior period, unchanged from 0001571996-17-000020:mdna:13]

[0001571996-17-000045:mdna:16]
[same as prior period, unchanged from 0001571996-17-000020:mdna:14]

[0001571996-17-000045:mdna:17]
[same as prior period, unchanged from 0001571996-17-000020:mdna:15]

[0001571996-17-000045:mdna:18]
[same as prior period, unchanged from 0001571996-17-000020:mdna:16]

[0001571996-17-000045:mdna:19]
[same as prior period, unchanged from 0001571996-17-000020:mdna:17]

[0001571996-17-000045:mdna:20]
[same as prior period, unchanged from 0001571996-17-000020:mdna:18]

[0001571996-17-000045:mdna:21]
[same as prior period, unchanged from 0001571996-17-000020:mdna:19]

[0001571996-17-000045:mdna:22]
| • | Infrastructure Solutions Group (ISG) — EMC's Information Storage segment and our former Enterprise Solutions Group were merged to create the Infrastructure Solutions Group, or ISG, which contains storage, server, and networking offerings. The comprehensive portfolio of advanced storage solutions includes traditional storage solutions as well as next-generation storage solutions (including all flash arrays and scale-out file, and object platforms). The server portfolio includes high-performance rack, blade, tower, and hyperscale servers. The networking portfolio enables our business customers to transform and modernize their infrastructure, mobilize and enrich end-user experiences, and accelerate business applications and processes. Similar to CSG, ISG also offers attached software, peripherals, and services, including support and deployment, configuration, and extended warranty services. |

[0001571996-17-000045:mdna:23]
[same as prior period, unchanged from 0001571996-17-000020:mdna:21]

[0001571996-17-000045:mdna:24]
[same as prior period, unchanged from 0001571996-17-000020:mdna:22]

[0001571996-17-000045:mdna:25]
VMware is a leader in virtualization and cloud infrastructure and business mobility solutions that enable organizations to manage IT resources across private clouds and complex multi-cloud, multi-device environments.  VMware offers a

[0001571996-17-000045:mdna:26]
64

[0001571996-17-000045:mdna:27]
broad portfolio of virtualization technologies across three main product groups: software-defined data center; hybrid cloud computing; and end-user computing.

[0001571996-17-000045:mdna:28]
[same as prior period, unchanged from 0001571996-17-000020:mdna:24]

[0001571996-17-000045:mdna:29]
[same as prior period, unchanged from 0001571996-17-000020:mdna:25]

[0001571996-17-000045:mdna:30]
[same as prior period, unchanged from 0001571996-17-000020:mdna:26]

[0001571996-17-000045:mdna:31]
[same as prior period, unchanged from 0001571996-17-000020:mdna:27]

[0001571996-17-000045:mdna:32]
[same as prior period, unchanged from 0001571996-17-000020:mdna:28]

[0001571996-17-000045:mdna:33]
[same as prior period, unchanged from 0001571996-17-000020:mdna:29]

[0001571996-17-000045:mdna:34]
[same as prior period, unchanged from 0001571996-17-000020:mdna:30]

[0001571996-17-000045:mdna:35]
[same as prior period, unchanged from 0001571996-17-000020:mdna:31]

[0001571996-17-000045:mdna:36]
[same as prior period, unchanged from 0001571996-17-000020:mdna:32]

[0001571996-17-000045:mdna:37]
[same as prior period, unchanged from 0001571996-17-000020:mdna:33]

[0001571996-17-000045:mdna:38]
[same as prior period, unchanged from 0001571996-17-000020:mdna:34]

[0001571996-17-000045:mdna:39]
We are seeing an unprecedented rate of change in the IT industry.  Organizations of all kinds are embracing digital technology to achieve their business objectives.  Our vision is to be the essential infrastructure company and leader in end-user computing, data center infrastructure solutions, virtualization, Internet of Things ("IoT"), and cloud software that our customers continue to trust and rely on for their IT solutions and transformations.  To further advance this vision, we recently unveiled a new IoT strategy, division, and an array of solutions to support IoT adoption for our customers.  We accelerate results for our customers by enabling them to be more efficient, mobile, informed, and secure.  We continue to invest in research and development, sales, and other key areas of our business to deliver superior products and solutions capabilities and to drive execution of long-term sustainable growth.  We believe that our results will benefit from an integrated go-to-market strategy, including enhanced coordination among the family of Dell Technologies companies, and from our differentiated products and solutions capabilities.  We intend to continue to execute on our business model and seek to balance liquidity, profitability, and growth to position our company for long-term success.

[0001571996-17-000045:mdna:40]
[same as prior period, unchanged from 0001571996-17-000020:mdna:36]

[0001571996-17-000045:mdna:41]
[same as prior period, unchanged from 0001571996-17-000020:mdna:60]

[0001571996-17-000045:mdna:42]
We expect that ISG will continue to be impacted by the changing nature of the IT infrastructure market and competitive environment.  Cloud-native applications are expected to continue as a primary growth driver in the infrastructure market as IT organizations increasingly become multi-cloud environments.  We believe the complementary cloud solutions across our business, created through our combination with EMC, strongly position us to meet these demands for our customers who are increasingly looking to leverage cloud-based computing.  Further, we will provide new and more robust storage and data center solutions to meet the evolving needs of our customers.  We also continue to be impacted by the emerging trends of enterprises deploying software-defined storage, hyper-converged, and modular solutions based on server-centric architectures.  These trends have put pressure on our traditional storage offerings, and we are focused on rapidly developing new capabilities and solutions to reposition our storage portfolio.  We have leading solutions through our ISG and VMware data center offerings.  In addition, through our research and development efforts, we expect to develop new solutions in this rapidly changing industry that we believe will enable us to continue to provide superior solutions to our customers.

[0001571996-17-000045:mdna:43]
In ISG, we are also seeing increased interest in "as a service" flexible consumption models by our customers as they seek to build greater flexibility into their cost structures.  We have introduced various financing and consumption models to meet our customers' needs.

[0001571996-17-000045:mdna:44]
During the first nine months of Fiscal 2018, we have experienced higher component costs which primarily impacted CSG and ISG.  We expect this trend to moderate but continue into Fiscal 2019.

[0001571996-17-000045:mdna:45]
We manage our business on a U.S. dollar basis.  However, we have a large global presence, generating approximately half of our revenue by sales to customers outside of the United States during the third quarter and first nine months of Fiscal 2018 and the third quarter and first nine months of Fiscal 2017.  Our revenues, therefore, can be impacted by fluctuations in foreign currency exchange rates.  We utilize a comprehensive hedging strategy intended to mitigate the impact of foreign currency volatility over time, and we adjust pricing when possible to further minimize foreign currency impacts.  The percentage of our revenues generated in regions outside of the United States did not change substantially as a result of the EMC merger transaction.

[0001571996-17-000045:mdna:46]
[same as prior period, unchanged from 0001571996-17-000020:mdna:41]

[0001571996-17-000045:mdna:47]
[same as prior period, unchanged from 0001571996-17-000020:mdna:42]

[0001571996-17-000045:mdna:48]
[same as prior period, unchanged from 0001571996-17-000020:mdna:43]

[0001571996-17-000045:mdna:49]
In connection with the EMC merger transaction, all principal, accrued but unpaid interest, fees, and other amounts (other than certain contingent obligations) outstanding at the effective time of the EMC merger transaction under EMC's unsecured revolving credit facility, Dell's asset-based revolving credit facility, and Dell's term facilities were substantially repaid concurrently with the closing.  Further, all commitments to lend and guarantees and security interests, as applicable, in connection therewith were terminated or released.  The aggregate amounts of principal, interest, and premium necessary to redeem in full the outstanding $1.4 billion in aggregate principal amount of 5.625% Senior First Lien Notes due 2020 co-issued by Dell International and Denali Finance Corp. were deposited with the trustee for such notes, and such notes were thereby satisfied and discharged, concurrently with the effective time of the EMC merger transaction.  All of Dell's other outstanding senior notes and all of EMC's outstanding senior notes remained outstanding after the effective time of the EMC merger transaction in accordance with their respective terms.

[0001571996-17-000045:mdna:50]
[same as prior period, unchanged from 0001571996-17-000020:mdna:45]

[0001571996-17-000045:mdna:51]
[same as prior period, unchanged from 0001571996-17-000020:mdna:46]

[0001571996-17-000045:mdna:52]
[same as prior period, unchanged from 0001571996-17-000020:mdna:48]

[0001571996-17-000045:mdna:53]
In management's discussion and analysis, we use supplemental measures of our performance which are derived from our consolidated financial information but which are not presented in our consolidated financial statements prepared in accordance with accounting principles generally accepted in the United States of America, or GAAP.  These non-GAAP financial measures include non-GAAP product net revenue; non-GAAP services net revenue; non-GAAP net revenue; non-GAAP product gross margin; non-GAAP services gross margin; non-GAAP gross margin; non-GAAP operating expenses; non-GAAP operating income; non-GAAP net income from continuing operations; earnings before interest and other, net, taxes, depreciation and amortization, referred to as EBITDA; and adjusted EBITDA.

[0001571996-17-000045:mdna:54]
[same as prior period, unchanged from 0001571996-17-000020:mdna:50]

[0001571996-17-000045:mdna:55]
[same as prior period, unchanged from 0001571996-17-000020:mdna:51]

[0001571996-17-000045:mdna:56]
[same as prior period, unchanged from 0001571996-17-000020:mdna:52]

[0001571996-17-000045:mdna:57]
[same as prior period, unchanged from 0001571996-17-000020:mdna:53]

[0001571996-17-000045:mdna:58]
[same as prior period, unchanged from 0001571996-17-000020:mdna:54]

[0001571996-17-000045:mdna:59]
[same as prior period, unchanged from 0001571996-17-000020:mdna:55]

[0001571996-17-000045:mdna:60]
[same as prior period, unchanged from 0001571996-17-000020:mdna:56]

[0001571996-17-000045:mdna:61]
| • | Transaction-related Expenses — Transaction-related expenses consist of acquisition, integration, and divestiture related costs, and are expensed as incurred. These expenses primarily represent costs for legal, banking, consulting, and advisory services, as well as certain compensatory retention awards directly related to the EMC merger transaction and related integration. During the third quarter and first nine months of Fiscal 2017, transaction-related expenses includes $807 million in day one stock-based compensation charges primarily related to the acceleration of vesting of EMC stock options and related taxes incurred in connection with the EMC merger transaction. |

[0001571996-17-000045:mdna:62]
| • | Other Corporate Expenses — Other corporate expenses consists of severance, facility action costs, and stock-based compensation expense associated with equity awards. Severance costs are primarily related to severance and benefits for employees terminated pursuant to cost savings initiatives. Facility action costs included in the third quarter and first nine months of Fiscal 2018 were $67 million and $175 million, respectively. We expect to incur these costs over the remainder of the year as we continue to integrate owned and leased facilities and as we seek opportunities for operational efficiencies and cost savings. Other corporate expenses vary from period to period and are significantly impacted by the timing and nature of these events. Therefore, although we may incur these types of expenses in the future, we believe that eliminating these charges for purposes of calculating the non-GAAP financial measures presented below facilitates a more meaningful evaluation of our current operating performance and comparisons to our past operating performance. |

[0001571996-17-000045:mdna:63]
| • | Aggregate Adjustment for Income Taxes — The aggregate adjustment for income taxes is the estimated combined income tax effect for the adjustments described above. During the first nine months of Fiscal 2017, this amount also includes tax charges of approximately $201 million, recorded during the first six months of Fiscal 2017, on previously untaxed earnings of a foreign subsidiary that will no longer be permanently reinvested as a result of the Dell Services and DSG divestitures. The tax effects are determined based on the tax jurisdictions where the above items were incurred. |

[0001571996-17-000045:mdna:64]
[same as prior period, unchanged from 0001571996-17-000020:mdna:77]

[0001571996-17-000045:mdna:65]
[same as prior period, unchanged from 0001571996-17-000020:mdna:61]

[0001571996-17-000045:mdna:66]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 3, 2017 |  | % Change |  | October 28, 2016 |  | November 3, 2017 |  | % Change |  | October 28, 2016 |
|  | (in millions, except percentages) |
| Product net revenue | $ | 14,680 |  |  | 19 | % |  | $ | 12,366 |  |  | $ | 42,003 |  |  | 25 | % |  | $ | 33,510 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 33 |  |  |  |  | 261 |  |  | 138 |  |  |  |  | 260 |  |
| Non-GAAP product net revenue | $ | 14,713 |  |  | 17 | % |  | $ | 12,627 |  |  | $ | 42,141 |  |  | 25 | % |  | $ | 33,770 |  |
| Services net revenue | $ | 4,930 |  |  | 27 | % |  | $ | 3,881 |  |  | $ | 14,722 |  |  | 83 | % |  | $ | 8,058 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 262 |  |  |  |  | 269 |  |  | 847 |  |  |  |  | 413 |  |
| Non-GAAP services net revenue | $ | 5,192 |  |  | 25 | % |  | $ | 4,150 |  |  | $ | 15,569 |  |  | 84 | % |  | $ | 8,471 |  |
| Net revenue | $ | 19,610 |  |  | 21 | % |  | $ | 16,247 |  |  | $ | 56,725 |  |  | 36 | % |  | $ | 41,568 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 295 |  |  |  |  | 530 |  |  | 985 |  |  |  |  | 673 |  |
| Non-GAAP net revenue | $ | 19,905 |  |  | 19 | % |  | $ | 16,777 |  |  | $ | 57,710 |  |  | 37 | % |  | $ | 42,241 |  |
| Product gross margin | $ | 2,311 |  |  | 28 | % |  | $ | 1,804 |  |  | $ | 5,797 |  |  | 25 | % |  | $ | 4,654 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 45 |  |  |  |  | 437 |  |  | 173 |  |  |  |  | 461 |  |
| Amortization of intangibles | 914 |  |  |  |  | 604 |  |  | 2,784 |  |  |  |  | 806 |  |
| Transaction-related expenses | 1 |  |  |  |  | 18 |  |  | 9 |  |  |  |  | 16 |  |
| Other corporate expenses | 2 |  |  |  |  | 10 |  |  | 8 |  |  |  |  | 14 |  |
| Non-GAAP product gross margin | $ | 3,273 |  |  | 14 | % |  | $ | 2,873 |  |  | $ | 8,771 |  |  | 47 | % |  | $ | 5,951 |  |
| Services gross margin | $ | 2,852 |  |  | 36 | % |  | $ | 2,095 |  |  | $ | 8,477 |  |  | 125 | % |  | $ | 3,774 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 262 |  |  |  |  | 292 |  |  | 847 |  |  |  |  | 436 |  |
| Amortization of intangibles | — |  |  |  |  | — |  |  | — |  |  |  |  | — |  |
| Transaction-related expenses | 4 |  |  |  |  | 12 |  |  | 13 |  |  |  |  | 9 |  |
| Other corporate expenses | 26 |  |  |  |  | 52 |  |  | 55 |  |  |  |  | 54 |  |
| Non-GAAP services gross margin | $ | 3,144 |  |  | 28 | % |  | $ | 2,451 |  |  | $ | 9,392 |  |  | 120 | % |  | $ | 4,273 |  |
| Gross margin | $ | 5,163 |  |  | 32 | % |  | $ | 3,899 |  |  | $ | 14,274 |  |  | 69 | % |  | $ | 8,428 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 307 |  |  |  |  | 729 |  |  | 1,020 |  |  |  |  | 897 |  |
| Amortization of intangibles | 914 |  |  |  |  | 604 |  |  | 2,784 |  |  |  |  | 806 |  |
| Transaction-related expenses | 5 |  |  |  |  | 30 |  |  | 22 |  |  |  |  | 25 |  |
| Other corporate expenses | 28 |  |  |  |  | 62 |  |  | 63 |  |  |  |  | 68 |  |
| Non-GAAP gross margin | $ | 6,417 |  |  | 21 | % |  | $ | 5,324 |  |  | $ | 18,163 |  |  | 78 | % |  | $ | 10,224 |  |

[0001571996-17-000045:mdna:67]
[same as prior period, unchanged from 0001571996-17-000020:mdna:87]

[0001571996-17-000045:mdna:68]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 3, 2017 |  | % Change |  | October 28, 2016 |  | November 3, 2017 |  | % Change |  | October 28, 2016 |
|  | (in millions, except percentages) |
| Operating expenses | $ | 5,696 |  |  | 5 | % |  | $ | 5,411 |  |  | $ | 17,286 |  |  | 73 | % |  | $ | 10,012 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | (59 | ) |  |  |  | (121 | ) |  | (175 | ) |  |  |  | (157 | ) |
| Amortization of intangibles | (820 | ) |  |  |  | (560 | ) |  | (2,466 | ) |  |  |  | (1,340 | ) |
| Transaction-related expenses | (81 | ) |  |  |  | (1,170 | ) |  | (393 | ) |  |  |  | (1,304 | ) |
| Other corporate expenses | (305 | ) |  |  |  | (211 | ) |  | (824 | ) |  |  |  | (257 | ) |
| Non-GAAP operating expenses | $ | 4,431 |  |  | 32 | % |  | $ | 3,349 |  |  | $ | 13,428 |  |  | 93 | % |  | $ | 6,954 |  |
| Operating loss | $ | (533 | ) |  | 65 | % |  | $ | (1,512 | ) |  | $ | (3,012 | ) |  | (90 | )% |  | $ | (1,584 | ) |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 366 |  |  |  |  | 850 |  |  | 1,195 |  |  |  |  | 1,054 |  |
| Amortization of intangibles | 1,734 |  |  |  |  | 1,164 |  |  | 5,250 |  |  |  |  | 2,146 |  |
| Transaction-related expenses | 86 |  |  |  |  | 1,200 |  |  | 415 |  |  |  |  | 1,329 |  |
| Other corporate expenses | 333 |  |  |  |  | 273 |  |  | 887 |  |  |  |  | 325 |  |
| Non-GAAP operating income | $ | 1,986 |  |  | 1 | % |  | $ | 1,975 |  |  | $ | 4,735 |  |  | 45 | % |  | $ | 3,270 |  |
| Net loss from continuing operations | $ | (941 | ) |  | 43 | % |  | $ | (1,637 | ) |  | $ | (3,302 | ) |  | (42 | )% |  | $ | (2,323 | ) |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 366 |  |  |  |  | 850 |  |  | 1,195 |  |  |  |  | 1,054 |  |
| Amortization of intangibles | 1,734 |  |  |  |  | 1,164 |  |  | 5,250 |  |  |  |  | 2,146 |  |
| Transaction-related expenses | 86 |  |  |  |  | 1,200 |  |  | 415 |  |  |  |  | 1,326 |  |
| Other corporate expenses | 333 |  |  |  |  | 273 |  |  | 887 |  |  |  |  | 325 |  |
| Aggregate adjustment for income taxes | (469 | ) |  |  |  | (880 | ) |  | (1,882 | ) |  |  |  | (932 | ) |
| Non-GAAP net income from continuing operations | $ | 1,109 |  |  | 14 | % |  | $ | 970 |  |  | $ | 2,563 |  |  | 61 | % |  | $ | 1,596 |  |

[0001571996-17-000045:mdna:69]
[same as prior period, unchanged from 0001571996-17-000020:mdna:67]

[0001571996-17-000045:mdna:70]
[same as prior period, unchanged from 0001571996-17-000020:mdna:68]

[0001571996-17-000045:mdna:71]
[same as prior period, unchanged from 0001571996-17-000020:mdna:70]

[0001571996-17-000045:mdna:72]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 3, 2017 |  | % Change |  | October 28, 2016 |  | November 3, 2017 |  | % Change |  | October 28, 2016 |
|  | (in millions, except percentages) |
| Net loss from continuing operations | $ | (941 | ) |  | 43 | % |  | $ | (1,637 | ) |  | $ | (3,302 | ) |  | (42 | )% |  | $ | (2,323 | ) |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Interest and other, net (a) | 682 |  |  |  |  | 794 |  |  | 1,800 |  |  |  |  | 1,362 |  |
| Income tax provision (benefit) | (274 | ) |  |  |  | (669 | ) |  | (1,510 | ) |  |  |  | (623 | ) |
| Depreciation and amortization | 2,137 |  |  |  |  | 1,576 |  |  | 6,491 |  |  |  |  | 2,799 |  |
| EBITDA | $ | 1,604 |  |  | NM |  |  | $ | 64 |  |  | $ | 3,479 |  |  | 186 | % |  | $ | 1,215 |  |
| EBITDA | $ | 1,604 |  |  | NM |  |  | $ | 64 |  |  | $ | 3,479 |  |  | 186 | % |  | $ | 1,215 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense | 221 |  |  |  |  | 144 |  |  | 630 |  |  |  |  | 177 |  |
| Impact of purchase accounting (b) | 298 |  |  |  |  | 693 |  |  | 990 |  |  |  |  | 851 |  |
| Transaction-related expenses (c) | 86 |  |  |  |  | 1,200 |  |  | 415 |  |  |  |  | 1,366 |  |
| Other corporate expenses (d) | 109 |  |  |  |  | 129 |  |  | 237 |  |  |  |  | 148 |  |
| Adjusted EBITDA | $ | 2,318 |  |  | 4 | % |  | $ | 2,230 |  |  | $ | 5,751 |  |  | 53 | % |  | $ | 3,757 |  |

[0001571996-17-000045:mdna:73]
[same as prior period, unchanged from 0001571996-17-000020:mdna:72]

[0001571996-17-000045:mdna:74]
[same as prior period, unchanged from 0001571996-17-000020:mdna:73]

[0001571996-17-000045:mdna:75]
[same as prior period, unchanged from 0001571996-17-000020:mdna:74]

[0001571996-17-000045:mdna:76]
[same as prior period, unchanged from 0001571996-17-000020:mdna:75]

[0001571996-17-000045:mdna:77]
[same as prior period, unchanged from 0001571996-17-000020:mdna:76]

[0001571996-17-000045:mdna:78]
[same as prior period, unchanged from 0001571996-17-000020:mdna:86]

[0001571996-17-000045:mdna:79]
71

[0001571996-17-000045:mdna:80]
[same as prior period, unchanged from 0001571996-17-000020:mdna:78]

[0001571996-17-000045:mdna:81]
[same as prior period, unchanged from 0001571996-17-000020:mdna:79]

[0001571996-17-000045:mdna:82]
[same as prior period, unchanged from 0001571996-17-000020:mdna:80]

[0001571996-17-000045:mdna:83]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 3, 2017 |  |  |  | October 28, 2016 |  | November 3, 2017 |  |  |  | October 28, 2016 |
|  | Dollars |  | % ofNet Revenue |  | %Change |  | Dollars |  | % ofNet Revenue |  | Dollars |  | % ofNet Revenue |  | %Change |  | Dollars |  | % ofNet Revenue |
|  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 14,680 |  |  | 74.9 | % |  | 19 | % |  | $ | 12,366 |  |  | 76.1 | % |  | $ | 42,003 |  |  | 74.0 | % |  | 25 | % |  | $ | 33,510 |  |  | 80.6 | % |
| Services | 4,930 |  |  | 25.1 | % |  | 27 | % |  | 3,881 |  |  | 23.9 | % |  | 14,722 |  |  | 26.0 | % |  | 83 | % |  | 8,058 |  |  | 19.4 | % |
| Total net revenue | $ | 19,610 |  |  | 100.0 | % |  | 21 | % |  | $ | 16,247 |  |  | 100.0 | % |  | $ | 56,725 |  |  | 100.0 | % |  | 36 | % |  | $ | 41,568 |  |  | 100.0 | % |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product (a) | $ | 2,311 |  |  | 15.7 | % |  | 28 | % |  | $ | 1,804 |  |  | 14.6 | % |  | $ | 5,797 |  |  | 13.8 | % |  | 25 | % |  | $ | 4,654 |  |  | 13.9 | % |
| Services (b) | 2,852 |  |  | 57.8 | % |  | 36 | % |  | 2,095 |  |  | 54.0 | % |  | 8,477 |  |  | 57.6 | % |  | 125 | % |  | 3,774 |  |  | 46.8 | % |
| Total gross margin | $ | 5,163 |  |  | 26.3 | % |  | 32 | % |  | $ | 3,899 |  |  | 24.0 | % |  | $ | 14,274 |  |  | 25.2 | % |  | 69 | % |  | $ | 8,428 |  |  | 20.3 | % |
| Operating expenses | $ | 5,696 |  |  | 29.0 | % |  | 5 | % |  | $ | 5,411 |  |  | 33.3 | % |  | $ | 17,286 |  |  | 30.5 | % |  | 73 | % |  | $ | 10,012 |  |  | 24.1 | % |
| Operating loss | $ | (533 | ) |  | (2.7 | )% |  | 65 | % |  | $ | (1,512 | ) |  | (9.3 | )% |  | $ | (3,012 | ) |  | (5.3 | )% |  | (90 | )% |  | $ | (1,584 | ) |  | (3.8 | )% |
| Net loss from continuing operations | $ | (941 | ) |  | (4.8 | )% |  | 43 | % |  | $ | (1,637 | ) |  | (10.1 | )% |  | $ | (3,302 | ) |  | (5.8 | )% |  | (42 | )% |  | $ | (2,323 | ) |  | (5.6 | )% |
| Net loss attributable to Dell Technologies Inc. | $ | (937 | ) |  | (4.8 | )% |  | 55 | % |  | $ | (2,064 | ) |  | (12.7 | )% |  | $ | (3,217 | ) |  | (5.7 | )% |  | (124 | )% |  | $ | (1,436 | ) |  | (3.5 | )% |
| Non-GAAP Financial Information |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 14,713 |  |  | 73.9 | % |  | 17 | % |  | $ | 12,627 |  |  | 75.3 | % |  | $ | 42,141 |  |  | 73.0 | % |  | 25 | % |  | $ | 33,770 |  |  | 79.9 | % |
| Services | 5,192 |  |  | 26.1 | % |  | 25 | % |  | 4,150 |  |  | 24.7 | % |  | 15,569 |  |  | 27.0 | % |  | 84 | % |  | 8,471 |  |  | 20.1 | % |
| Total non-GAAP net revenue | $ | 19,905 |  |  | 100.0 | % |  | 19 | % |  | $ | 16,777 |  |  | 100.0 | % |  | $ | 57,710 |  |  | 100.0 | % |  | 37 | % |  | $ | 42,241 |  |  | 100.0 | % |
| Non-GAAP gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product (a) | $ | 3,273 |  |  | 22.2 | % |  | 14 | % |  | $ | 2,873 |  |  | 22.8 | % |  | $ | 8,771 |  |  | 20.8 | % |  | 47 | % |  | $ | 5,951 |  |  | 17.6 | % |
| Services (b) | 3,144 |  |  | 60.6 | % |  | 28 | % |  | 2,451 |  |  | 59.1 | % |  | 9,392 |  |  | 60.3 | % |  | 120 | % |  | 4,273 |  |  | 50.4 | % |
| Total non-GAAP gross margin | $ | 6,417 |  |  | 32.2 | % |  | 21 | % |  | $ | 5,324 |  |  | 31.7 | % |  | $ | 18,163 |  |  | 31.5 | % |  | 78 | % |  | $ | 10,224 |  |  | 24.2 | % |
| Non-GAAP operating expenses | $ | 4,431 |  |  | 22.3 | % |  | 32 | % |  | $ | 3,349 |  |  | 20.0 | % |  | $ | 13,428 |  |  | 23.3 | % |  | 93 | % |  | $ | 6,954 |  |  | 16.5 | % |
| Non-GAAP operating income | $ | 1,986 |  |  | 10.0 | % |  | 1 | % |  | $ | 1,975 |  |  | 11.8 | % |  | $ | 4,735 |  |  | 8.2 | % |  | 45 | % |  | $ | 3,270 |  |  | 7.7 | % |
| Non-GAAP net income from continuing operations | $ | 1,109 |  |  | 5.6 | % |  | 14 | % |  | $ | 970 |  |  | 5.8 | % |  | $ | 2,563 |  |  | 4.4 | % |  | 61 | % |  | $ | 1,596 |  |  | 3.8 | % |
| EBITDA | $ | 1,604 |  |  | 8.1 | % |  | NM |  |  | $ | 64 |  |  | 0.4 | % |  | $ | 3,479 |  |  | 6.0 | % |  | 186 | % |  | $ | 1,215 |  |  | 2.9 | % |
| Adjusted EBITDA | $ | 2,318 |  |  | 11.6 | % |  | 4 | % |  | $ | 2,230 |  |  | 13.3 | % |  | $ | 5,751 |  |  | 10.0 | % |  | 53 | % |  | $ | 3,757 |  |  | 8.9 | % |

[0001571996-17-000045:mdna:84]
[same as prior period, unchanged from 0001571996-17-000020:mdna:82]

[0001571996-17-000045:mdna:85]
| (a) | Product gross margin percentages represent product gross margin as a percentage of product net revenue, and non-GAAP product gross margin as a percentage of non-GAAP product net revenue. |

[0001571996-17-000045:mdna:86]
| (b) | Services gross margin percentages represent services gross margin as a percentage of services net revenue, and non-GAAP services gross margin as a percentage of non-GAAP services net revenue. |

[0001571996-17-000045:mdna:87]
| NM | Not meaningful. |

[0001571996-17-000045:mdna:88]
[same as prior period, unchanged from 0001571996-17-000020:mdna:88]

[0001571996-17-000045:mdna:89]
As a result of the EMC merger transaction completed on September 7, 2016 and its impact on the third quarter and first nine months of Fiscal 2018, our results for the fiscal periods discussed below are not directly comparable.

[0001571996-17-000045:mdna:90]
[same as prior period, unchanged from 0001571996-17-000020:mdna:90]

[0001571996-17-000045:mdna:91]
During the third quarter and first nine months of Fiscal 2018, our net revenue increased 21% and 36%, respectively.  During the third quarter and first nine months of Fiscal 2018, our non-GAAP net revenue increased 19% and 37%, respectively.  The increase in net revenue and non-GAAP net revenue was attributable to an increase in revenue across all three business units.  The EMC merger transaction had an impact on the mix of revenue contributed by our business units.  CSG net revenue represented approximately 50% of our net revenue during the third quarter and first nine months of Fiscal 2018.  In comparison, CSG net revenue comprised a higher proportion of our net revenue during the third quarter and first nine months of Fiscal 2017, representing approximately 60% and 65% of our net revenue, respectively.

[0001571996-17-000045:mdna:92]
During the third quarter of Fiscal 2018 and Fiscal 2017, our operating loss was $0.5 billion and $1.5 billion, respectively.  The decrease in our operating loss for the third quarter of Fiscal 2018 was attributable to an increase in revenue and gross margin, offset partially by an increase in operating expenses, all of which were driven by the timing of the EMC merger transaction.  During the first nine months of Fiscal 2018 and Fiscal 2017, our operating loss was $3.0 billion and $1.6 billion, respectively.  The increase in our operating loss for the first nine months of Fiscal 2018 was primarily attributable to an increase in amortization of intangible assets and purchase accounting adjustments related to the EMC merger transaction, partially offset by the incremental operating income from the EMC acquired businesses.

[0001571996-17-000045:mdna:93]
Our operating loss was impacted by purchase accounting adjustments associated with the EMC merger transaction and, to a lesser extent, the going-private transaction, amortization of intangible assets, transaction-related expenses, and other corporate expenses.  In aggregate, these items totaled $2.5 billion and $7.7 billion for the third quarter and first nine months of Fiscal 2018, respectively.  In comparison, these items totaled $3.5 billion and $4.9 billion for the third quarter and first nine months of Fiscal 2017, respectively.  Excluding these adjustments, non-GAAP operating income was relatively unchanged during the third quarter of Fiscal 2018 and increased 45% to $4.7 billion during the first nine months of Fiscal 2018.  Non-GAAP operating income during the third quarter of Fiscal 2018 was relatively flat due to an increase in operating income for CSG and VMware, which was largely offset by a decrease in ISG operating income.  The increase in non-GAAP operating income for the first nine months of Fiscal 2018 was attributable to an increase in non-GAAP operating income across all three business units, but most significantly by VMware.

[0001571996-17-000045:mdna:94]
Cash provided by operating activities was $3.7 billion and $1.6 billion during the first nine months of Fiscal 2018 and Fiscal 2017, respectively. The increase in operating cash flows during the first nine months of Fiscal 2018 was driven by improved profitability, including the incremental profitability from the EMC acquired businesses, and ongoing working capital initiatives.  See "Market Conditions, Liquidity, and Capital Commitments" for further information on our cash flow metrics.

[0001571996-17-000045:mdna:95]
[same as prior period, unchanged from 0001571996-17-000020:mdna:95]

[0001571996-17-000045:mdna:96]
During the third quarter and first nine months of Fiscal 2018, our net revenue increased 21% and 36%, respectively, primarily due to an increase in revenue across all three business units. During the first nine months of Fiscal 2018, these increases were offset partially by an increase in purchase accounting adjustments as a result of the EMC merger transaction.  Our non-GAAP net revenue increased 19% and 37% during the third quarter and first nine months of Fiscal 2018, respectively, primarily due to an increase in revenue across all three business units.  See "Business Unit Results" for further information.

[0001571996-17-000045:mdna:97]
[same as prior period, unchanged from 0001571996-17-000020:mdna:122]

[0001571996-17-000045:mdna:98]
| • | Product Net Revenue — Product net revenue includes revenue from the sale of hardware products and Dell Technologies-owned software licenses. During the third quarter of Fiscal 2018, product net revenue and non-GAAP product net revenue increased 19% and 17%, respectively, due to an increase in product revenue across all three business units, driven by strength in sales of notebooks, workstations, and servers. The increases in product net revenue and non-GAAP product net revenue during the third quarter of Fiscal 2018 were also partially due to the incremental product net revenue from the EMC acquired businesses. During the first nine months of Fiscal 2018, product net revenue and non-GAAP product net revenue both increased 25%, primarily due to incremental product net revenue from the EMC acquired businesses. |

[0001571996-17-000045:mdna:99]
| • | Services Net Revenue — Services net revenue includes revenue from our services offerings, third-party software license sales, and support services related to Dell Technologies-owned software and hardware. During the third quarter of Fiscal 2018, services net revenue and non-GAAP services net revenue increased 27% and 25%, respectively. During the first nine months of Fiscal 2018, services net revenue and non-GAAP services net revenue increased 83% and 84%, respectively. These increases were primarily due to the incremental services net revenue from the EMC acquired businesses. |

[0001571996-17-000045:mdna:100]
[same as prior period, unchanged from 0001571996-17-000020:mdna:99]

[0001571996-17-000045:mdna:101]
From a geographical perspective, net revenue generated by sales to customers in all regions increased during the third quarter and first nine months of Fiscal 2018 primarily as a result of the incremental net revenue from the EMC acquired businesses.  Our mix of revenues generated in the Americas, EMEA, and APJ did not change substantially as a result of the EMC merger transaction.

[0001571996-17-000045:mdna:102]
[same as prior period, unchanged from 0001571996-17-000020:mdna:101]

[0001571996-17-000045:mdna:103]
During the third quarter and first nine months of Fiscal 2018, our gross margin increased 32% to $5.2 billion, and 69% to $14.3 billion, respectively.  During the third quarter and first nine months of Fiscal 2018 our gross margin percentage increased 230 basis points to 26.3%, and 490 basis points to 25.2%, respectively.  The increases in our gross margin and gross margin percentage were primarily attributable to incremental gross margin from the EMC acquired businesses, which have higher gross margin percentages.  During the third quarter of Fiscal 2018, gross margin also benefited from a lower combined impact of purchase accounting adjustments and amortization of intangibles as a result of the EMC merger transaction. During the first nine months of Fiscal 2018, the incremental gross margins from the EMC acquired businesses were partially offset by the impact of purchase accounting adjustments and amortization of intangibles as a result of the EMC merger transaction.

[0001571996-17-000045:mdna:104]
Our gross margin for the third quarter and first nine months of Fiscal 2018 included the effect of $1.2 billion and $3.8 billion, respectively, of amortization of intangibles and purchase accounting adjustments related to the EMC merger transaction and, to a lesser extent, the going-private transaction.  In comparison, the impact of purchase accounting and amortization of intangibles totaled $1.3 billion and $1.7 billion in the third quarter and first nine months of Fiscal 2017, respectively.  Excluding these costs, transaction-related expenses, and other corporate expenses, non-GAAP gross margin for the third quarter increased 21% to $6.4 billion and non-GAAP gross margin percentage increased 50 basis points to 32.2%.  For the first nine months of Fiscal 2018, non-GAAP gross margin increased 78% to $18.2 billion and non-GAAP gross margin percentage increased 730 basis points to 31.5%.  The increase in non-GAAP gross margin and non-GAAP gross margin percentage was primarily attributable to incremental gross margin from the EMC acquired businesses, which have higher gross margin percentages.

[0001571996-17-000045:mdna:105]
| • | Products — During the third quarter of Fiscal 2018, product gross margin increased 28% to $2.3 billion and product gross margin percentage increased 110 basis points to 15.7%. The increase in product gross margin and product gross margin percentage was driven primarily by incremental product gross margin from VMware. |

[0001571996-17-000045:mdna:106]
During the first nine months of Fiscal 2018, product gross margin increased 25% to $5.8 billion and product gross margin percentage remained relatively unchanged at 13.8%.  The increase in product gross margin was driven primarily by additional product gross margin from the EMC acquired businesses, which was partially offset by an increase in amortization of intangibles related to the EMC merger transaction, and to a lesser extent, an increase in component costs during the period.

[0001571996-17-000045:mdna:107]
During the third quarter of Fiscal 2018, non-GAAP product gross margin increased 14% to $3.3 billion and non-GAAP product gross margin percentage decreased 60 basis points to 22.2%.  During the third quarter of Fiscal 2018, non-GAAP gross margin benefited from increases in revenue across all three business units, but non-GAAP product gross margin percentage decreased due to component cost pressures in CSG and ISG and mix shift in ISG.  During the first nine months of Fiscal 2018, non-GAAP product gross margin increased 47% to $8.8 billion and non-GAAP product gross margin percentage increased 320 basis points to 20.8%.  The increases in non-GAAP product gross margin and non-GAAP product

[0001571996-17-000045:mdna:108]
gross margin percentage were primarily attributable to the incremental product gross margin from the EMC acquired businesses, which have higher gross margin percentages, partially offset by component cost pressures in CSG and ISG.

[0001571996-17-000045:mdna:109]
In the third quarter of Fiscal 2017, we entered into a settlement agreement with a vendor to resolve a dispute regarding past pricing practices.  Our gross margin for the third quarter of Fiscal 2017 included a benefit of $80 million related to receipt of this settlement.  Vendor settlements are allocated to our segments based on the relative amount of affected vendor products sold by each segment.  The $80 million settlement benefit was entirely allocated to CSG.  While this settlement does materially impact comparability of product gross margins for the third quarter, there is minimal impact to comparability for the first nine months due to the offsetting impact of a settlement recorded in the second quarter of Fiscal 2018 as discussed below in Vendor Programs and Settlements.

[0001571996-17-000045:mdna:110]
| • | Services — During the third quarter of Fiscal 2018, services gross margin increased 36% to $2.9 billion and services gross margin percentage increased 380 basis points to 57.8%. The increase in services gross margin and services gross margin percentage was primarily attributable to the incremental services gross margin from the EMC acquired businesses, which have higher gross margin percentages. Purchase accounting adjustments totaled $0.3 billion both during the third quarter of Fiscal 2018 and the third quarter of Fiscal 2017. Excluding these costs, transaction-related expenses, and other corporate expenses, non-GAAP services gross margin increased 28% to $3.1 billion and non-GAAP services gross margin percentage increased 150 basis points to 60.6%. |

[0001571996-17-000045:mdna:111]
During the first nine months of Fiscal 2018, services gross margin increased 125% to $8.5 billion and services gross margin percentage increased 1,080 basis points to 57.6%.  The increase in services gross margin and gross margin percentage was primarily attributable to the incremental services gross margin from the EMC acquired businesses, which have higher gross margin percentages.  Purchase accounting adjustments totaled $0.8 billion during the first nine months of Fiscal 2018, compared to $0.4 billion during the first nine months of Fiscal 2017.  Excluding these costs, transaction-related expenses, and other corporate expenses, non-GAAP services gross margin increased 120% to $9.4 billion and non-GAAP services gross margin percentage increased 990 basis points to 60.3%.

[0001571996-17-000045:mdna:112]
[same as prior period, unchanged from 0001571996-17-000020:mdna:110]

[0001571996-17-000045:mdna:113]
[same as prior period, unchanged from 0001571996-17-000020:mdna:111]

[0001571996-17-000045:mdna:114]
The terms and conditions of our vendor rebate programs are largely based on product volumes and are generally negotiated either at the beginning of the annual or quarterly period, depending on the program.  The timing and amount of vendor rebates and other discounts we receive under the programs may vary from period to period, reflecting changes in the competitive environment.  We monitor our component costs and seek to address the effects of any changes to terms that might arise under our vendor rebate programs.  Our gross margins for the third quarter and first nine months of Fiscal 2018 and Fiscal 2017 were not materially affected by any changes to the terms of our vendor rebate programs, as the amounts we received under these programs were generally stable relative to our total net cost.  We are not aware of any significant changes to vendor pricing or rebate programs that may impact our results in the near term.

[0001571996-17-000045:mdna:115]
In addition, we have pursued legal action against certain vendors and are currently involved in negotiations with other vendors regarding their past pricing practices.  We have negotiated settlements with some of these vendors and may have additional settlements in future periods.  These settlements are allocated to our segments based on the relative amount of affected vendor products sold by each segment.  A pricing settlement was recorded in the second quarter of Fiscal 2018 that benefited product gross margins by $68 million, and it was entirely allocated to CSG.  Additionally, a pricing settlement was recorded in the third quarter of Fiscal 2017 that benefited product gross margins by $80 million, and was entirely allocated to CSG.  During the third quarter of Fiscal 2018, no such settlements were recorded that would have a material impact on product gross margins in the current quarter or affect comparability with other periods.

[0001571996-17-000045:mdna:116]
[same as prior period, unchanged from 0001571996-17-000020:mdna:115]

[0001571996-17-000045:mdna:117]
[same as prior period, unchanged from 0001571996-17-000020:mdna:116]

[0001571996-17-000045:mdna:118]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 3, 2017 |  |  |  | October 28, 2016 |  | November 3, 2017 |  |  |  | October 28, 2016 |
|  | Dollars |  | % ofNet Revenue |  | %Change |  | Dollars |  | % ofNet Revenue |  | Dollars |  | % ofNet Revenue |  | %Change |  | Dollars |  | % ofNet Revenue |
|  | (in millions, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative | $ | 4,625 |  |  | 23.5 | % |  | 2 | % |  | $ | 4,556 |  |  | 28.0 | % |  | $ | 13,989 |  |  | 24.7 | % |  | 62 | % |  | $ | 8,647 |  |  | 20.8 | % |
| Research and development | 1,071 |  |  | 5.5 | % |  | 25 | % |  | 855 |  |  | 5.3 | % |  | 3,297 |  |  | 5.8 | % |  | 142 | % |  | 1,365 |  |  | 3.3 | % |
| Total operating expenses | $ | 5,696 |  |  | 29.0 | % |  | 5 | % |  | $ | 5,411 |  |  | 33.3 | % |  | $ | 17,286 |  |  | 30.5 | % |  | 73 | % |  | $ | 10,012 |  |  | 24.1 | % |
| Other Financial Information |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP operating expenses | $ | 4,431 |  |  | 22.3 | % |  | 32 | % |  | $ | 3,349 |  |  | 20.0 | % |  | $ | 13,428 |  |  | 23.3 | % |  | 93 | % |  | $ | 6,954 |  |  | 16.5 | % |

[0001571996-17-000045:mdna:119]
During the third quarter and first nine months of Fiscal 2018, total operating expenses increased 5% and 73%, respectively.  These increases were primarily due to incremental operating costs of the EMC acquired businesses.  In the third quarter of Fiscal 2018, this increase was partially offset by a reduction in operating expenses due to $1.2 billion of transaction-related expenses incurred in the third quarter of Fiscal 2017, which did not recur in Fiscal 2018.  Our operating expenses include the impact of purchase accounting associated with the EMC merger transaction and, to a lesser extent, the going-private transaction, amortization of intangible assets, transaction-related expenses, and other corporate expenses.  In aggregate, these items totaled $1.3 billion and $2.1 billion for the third quarter of Fiscal 2018 and Fiscal 2017, respectively, and $3.9 billion and $3.1 billion for the first nine months of Fiscal 2018 and Fiscal 2017, respectively.  Excluding these costs, total non-GAAP operating expenses for the third quarter and first nine months of Fiscal 2018 increased 32% and 93%, respectively, primarily due to the incremental operating costs from the EMC acquired businesses.

[0001571996-17-000045:mdna:120]
| • | Selling, General, and Administrative — Selling, general, and administrative ("SG&A") expenses increased 2% and 62%, respectively, during the third quarter and first nine months of Fiscal 2018. The increases in SG&A expenses were primarily driven by incremental operating costs of the EMC acquired businesses. The increase during the third quarter of Fiscal 2018 was mostly offset by the reduction in operating expenses attributable to transaction costs incurred in the third quarter of Fiscal 2017 that did not recur in Fiscal 2018. |

[0001571996-17-000045:mdna:121]
| • | Research and Development — Research and development ("R&D") expenses are primarily composed of personnel-related expenses related to product development. R&D expenses as a percentage of net revenue for the third quarter and first nine months of Fiscal 2018 were approximately 5.5% and 5.8%, respectively. In comparison, R&D expenses as a percentage of net revenue for the third quarter and first nine months of Fiscal 2017 were 5.3% and 3.3%, respectively. The increase in R&D expenses during the first nine months of Fiscal 2018 was attributable to the expansion of our R&D capability through the EMC merger transaction. As our industry continues to change and as the needs of our customers evolve, we intend to support R&D initiatives to innovate and introduce new and enhanced solutions into the market. |

[0001571996-17-000045:mdna:122]
[same as prior period, unchanged from 0001571996-17-000020:mdna:121]

[0001571996-17-000045:mdna:123]
[same as prior period, unchanged from 0001571996-17-000020:mdna:123]

[0001571996-17-000045:mdna:124]
Our operating loss was $0.5 billion during the third quarter of Fiscal 2018, compared to $1.5 billion during the third quarter of Fiscal 2017.  Operating loss was $3.0 billion during the first nine months of Fiscal 2018 compared to $1.6 billion during the first nine months of Fiscal 2017.  The decrease in operating loss during the third quarter of Fiscal 2018 was primarily attributable to an increase in gross margin.  The increase in operating loss during the first nine months of Fiscal 2018 was primarily attributable to amortization of intangible assets and purchase accounting adjustments related to the EMC merger transaction, partially offset by an increase in gross margin from the EMC acquired businesses.

[0001571996-17-000045:mdna:125]
Our operating loss includes the impact of purchase accounting associated with the EMC merger transaction and, to a lesser extent, the going-private transaction, amortization of intangible assets, transaction-related expenses, and other corporate expenses.  In aggregate, these items totaled $2.5 billion and $3.5 billion for the third quarter of Fiscal 2018 and Fiscal 2017, respectively, and $7.7 billion and $4.9 billion for the first nine months of Fiscal 2018 and Fiscal 2017, respectively.  Excluding these costs, non-GAAP operating income for the third quarter of Fiscal 2018 was relatively unchanged, and non-GAAP operating income for the first nine months of Fiscal 2018 increased 45% to $4.7 billion.  Non-GAAP operating income during the third quarter of Fiscal 2018 was relatively flat due to the offsetting impacts of an increase in operating income for CSG and VMware and a decrease in ISG operating income. The increase in non-GAAP operating income for the first nine months of Fiscal 2018 was attributable to an increase in non-GAAP operating income across all three business units, but most significantly by VMware.

[0001571996-17-000045:mdna:126]
[same as prior period, unchanged from 0001571996-17-000020:mdna:125]

[0001571996-17-000045:mdna:127]
[same as prior period, unchanged from 0001571996-17-000020:mdna:126]

[0001571996-17-000045:mdna:128]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 3, 2017 |  | October 28, 2016 |  | November 3, 2017 |  | October 28, 2016 |
|  | (in millions) |
| Interest and other, net: |  |  |  |  |  |  |  |  |  |  |
| Investment income, primarily interest | $ | 57 |  |  | $ | 38 |  |  | $ | 142 |  |  | $ | 62 |  |
| Gain (loss) on investments, net | (3 | ) |  | (6 | ) |  | 22 |  |  | (4 | ) |
| Interest expense | (607 | ) |  | (585 | ) |  | (1,802 | ) |  | (1,100 | ) |
| Foreign exchange | (35 | ) |  | 4 |  |  | (77 | ) |  | (51 | ) |
| Other | (94 | ) |  | (245 | ) |  | (85 | ) |  | (269 | ) |
| Total interest and other, net | $ | (682 | ) |  | $ | (794 | ) |  | $ | (1,800 | ) |  | $ | (1,362 | ) |

[0001571996-17-000045:mdna:129]
During the third quarter of Fiscal 2018, changes in interest and other, net were favorable by $112 million primarily due to other non-recurring expenses of approximately $245 million incurred in the third quarter of Fiscal 2017 related to debt extinguishment and new borrowings associated with the EMC merger transaction.  During the first nine months of Fiscal 2018, changes in interest and other, net were unfavorable by $438 million primarily due to an increase in interest expense from higher average debt balances from debt issued in connection with the EMC merger transaction, partially offset by the decrease in other non-recurring expenses referred to above.  See Note 7 of the Notes to the Condensed Consolidated Financial Statements included in this report for further information regarding our debt.

[0001571996-17-000045:mdna:130]
[same as prior period, unchanged from 0001571996-17-000020:mdna:129]

[0001571996-17-000045:mdna:131]
For the third quarter and first nine months of Fiscal 2018 our effective income tax rates for continuing operations were 22.6% and 31.4%, respectively, on pre-tax losses from continuing operations of $1.2 billion and $4.8 billion, respectively.  For the third quarter and first nine months of Fiscal 2017, our effective income tax rates for continuing operations were 29.0% and 21.1%, respectively, on pre-tax losses from continuing operations of $2.3 billion and $2.9 billion, respectively.  The changes in our effective income tax rates for the third quarter and first nine months of Fiscal 2018 were primarily attributable to tax benefits from charges incurred associated with the EMC merger transaction, including purchase accounting adjustments, interest charges, and stock-based compensation expense.  See Note 2 of the Notes to the Condensed Consolidated Financial Statements included in this report for more information on the EMC merger transaction.  The change in our effective income tax rate for the first nine months of Fiscal 2018 was also impacted by tax charges recognized in the prior year during the three and six months ended July 29, 2016 related to the divestiture of Dell Services and DSG.  The income tax rate for future quarters of Fiscal 2018 will be impacted by the actual mix of jurisdictions in which income is generated.

[0001571996-17-000045:mdna:132]
Our effective tax rate can fluctuate depending on the geographic distribution of our world-wide earnings, as our foreign earnings are generally taxed at lower rates than in the United States.  In certain jurisdictions, our tax rate is significantly less than the applicable statutory rate as a result of tax holidays.  The majority of our foreign income that is subject to these tax holidays and lower tax rates is attributable to Singapore, China, and Malaysia.  A significant portion of these income tax benefits relate to a tax holiday that expires in January 2019.  Our other tax holidays will expire in whole or in part during Fiscal

[0001571996-17-000045:mdna:133]
2019 through Fiscal 2023.  Many of these tax holidays and reduced tax rates may be extended when certain conditions are met or may be terminated early if certain conditions are not met.  The differences between our effective tax rate and the U.S. federal statutory rate of 35% principally resulted from the geographical distribution of taxable income discussed above and permanent differences between the book and tax treatment of certain items.  We continue to assess our business model and its impact in various taxing jurisdictions.

[0001571996-17-000045:mdna:134]
As noted in "Part I — Item 1A — Risk Factors" in our Annual Report on Form 10-K for the fiscal year ended February 3, 2017, changes in tax law (including laws relating to U.S. taxes on foreign operations) could adversely affect our operations and profitability.  Pending U.S. tax reform legislation would result in certain changes to U.S. tax laws, specifically U.S. taxation on earnings from international business operations and new restrictions on the deductibility of interest expense, which may materially impact our effective tax rate and the amount of taxes we pay.  The ultimate impact of any proposed tax reform legislation will not be known until such legislation is finalized.

[0001571996-17-000045:mdna:135]
[same as prior period, unchanged from 0001571996-17-000020:mdna:132]

[0001571996-17-000045:mdna:136]
[same as prior period, unchanged from 0001571996-17-000020:mdna:133]

[0001571996-17-000045:mdna:137]
During the third quarter of Fiscal 2018, net loss from continuing operations decreased 43% to a net loss of $0.9 billion, and during the first nine months of Fiscal 2018 net loss from continuing operations increased 42% to a net loss of $3.3 billion.  The decrease in net loss from continuing operations during the third quarter of Fiscal 2018 was attributable to a decrease in operating loss and a decrease in interest and other, net expense, offset partially by a decrease in tax benefit.  The increase in net loss from continuing operations during the first nine months of Fiscal 2018 was primarily attributable to an increase in operating loss and to an increase in interest and other, net expense, which was partially offset by an increase in tax benefit.  See Note 13 of the Notes to the Condensed Consolidated Financial Statements included in this report for more information regarding our effective tax rate.

[0001571996-17-000045:mdna:138]
Net loss from continuing operations for the third quarter and first nine months of Fiscal 2018 included amortization of intangible assets, the impact of purchase accounting, transaction-related expenses, and other corporate expenses.  Excluding these costs, non-GAAP net income from continuing operations increased 14% to $1.1 billion and 61% to $2.6 billion during the third quarter and first nine months of Fiscal 2018, respectively.  The increase in non-GAAP net income from continuing operations during the third quarter of Fiscal 2018 was primarily attributable to a decrease in interest and other, net expense.  The increase in non-GAAP net income from continuing operations during the first nine months of Fiscal 2018 was primarily attributable to increases in operating income, the effects of which were partially offset by increases in interest and other, net expense.

[0001571996-17-000045:mdna:139]
[same as prior period, unchanged from 0001571996-17-000020:mdna:136]

[0001571996-17-000045:mdna:140]
During the third quarter and first nine months of Fiscal 2018, net loss attributable to non-controlling interests was $4 million and $85 million, respectively.  During the third quarter and first nine months of Fiscal 2017, net loss attributable to non-controlling interest was $11 million and $12 million, respectively.  Non-controlling interests primarily consisted of net loss attributable to non-controlling interest in VMware, Inc.  For more information about our non-controlling interests, see Note 15 of the Notes to the Condensed Consolidated Financial Statements included in this report.

[0001571996-17-000045:mdna:141]
[same as prior period, unchanged from 0001571996-17-000020:mdna:138]

[0001571996-17-000045:mdna:142]
Net loss attributable to Dell Technologies Inc. represents net income/loss from continuing operations, an adjustment for non-controlling interests, and, in Fiscal 2017, an adjustment for discontinued operations.  During the third quarter and first nine months of Fiscal 2018, net loss attributable to Dell Technologies Inc. was $0.9 billion and $3.2 billion, respectively, compared to $2.1 billion and $1.4 billion during the third quarter and first nine months of Fiscal 2017, respectively.  The decrease in net loss attributable to Dell Technologies Inc. during the third quarter of Fiscal 2018 was primarily attributable to a decrease in net loss from continuing operations and the absence of loss from our discontinued operations in Fiscal 2018, due to completion of the divestiture transactions in Fiscal 2017.  The increase in net loss attributable to Dell Technologies Inc. during the first nine months of Fiscal 2018 was primarily attributable to an increase in net loss from continuing operations and the absence of income from our discontinued operations in Fiscal 2018, due to the completion of the divestiture transactions in Fiscal 2017.  For more information regarding our discontinued operations, see Note 3 of the Notes to the Condensed Consolidated Financial Statements included in this report.

[0001571996-17-000045:mdna:143]
78

[0001571996-17-000045:mdna:144]
[same as prior period, unchanged from 0001571996-17-000020:mdna:141]

[0001571996-17-000045:mdna:145]
[same as prior period, unchanged from 0001571996-17-000020:mdna:142]

[0001571996-17-000045:mdna:146]
[same as prior period, unchanged from 0001571996-17-000020:mdna:143]

[0001571996-17-000045:mdna:147]
[same as prior period, unchanged from 0001571996-17-000020:mdna:144]

[0001571996-17-000045:mdna:148]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 3, 2017 |  | % Change |  | October 28, 2016 |  | November 3, 2017 |  | % Change |  | October 28, 2016 |
|  | (in millions, except percentages) |
| Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 6,907 |  |  | 8% |  | $ | 6,400 |  |  | $ | 20,453 |  |  | 6% |  | $ | 19,343 |  |
| Consumer | 3,052 |  |  | 10% |  | 2,787 |  |  | 8,413 |  |  | 10% |  | 7,635 |  |
| Total CSG net revenue | $ | 9,959 |  |  | 8% |  | $ | 9,187 |  |  | $ | 28,866 |  |  | 7% |  | $ | 26,978 |  |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| CSG operating income | $ | 672 |  |  | 6% |  | $ | 634 |  |  | $ | 1,612 |  |  | 7% |  | $ | 1,503 |  |
| % of segment net revenue | 6.7 | % |  |  |  | 6.9 | % |  | 5.6 | % |  |  |  | 5.6 | % |

[0001571996-17-000045:mdna:149]
Net Revenue — During the third quarter and first nine months of Fiscal 2018, CSG net revenue increased 8% and 7%, respectively, driven by an increase in overall average selling price, as we managed our pricing in response to the cost environment during the periods, in both the commercial and consumer product categories.  While demand was relatively flat during the third quarter of Fiscal 2018, during the first nine months of Fiscal 2018, the increases in CSG net revenue benefited from increases in units sold as we experienced a general improvement in customer demand for our products, which favored premium notebooks and workstations.

[0001571996-17-000045:mdna:150]
From a geographical perspective, net revenue attributable to CSG increased across all regions during the third quarter and first nine months of Fiscal 2018.

[0001571996-17-000045:mdna:151]
Operating Income — During the third quarter of Fiscal 2018, CSG operating income as a percentage of net revenue decreased 20 basis points to 6.7%.  The decline in our operating income was attributable to an $80 million vendor settlement recorded in the third quarter of Fiscal 2017, which resulted in an incremental 90 basis points to our operating income percentage during the that period which did not recur.  Removing the effect of this vendor settlement, CSG operating income increased 70 basis points during the third quarter of Fiscal 2018 due to increases in average selling prices as discussed above as well as favorability in our operating expense percentage as we continue to manage our cost position.  Despite this increase, our operating income percentage was negatively impacted by increasing component costs.  We expect that component cost increases will moderate but continue to be challenging into Fiscal 2019.  We will continue to adjust our pricing practices as needed based upon a multitude of factors including the competitive environment and component costs.

[0001571996-17-000045:mdna:152]
During the first nine months of Fiscal 2018, CSG operating income remained unchanged at 5.6%.  The increase in component costs was offset by favorability in our operating expense percentage as we continue to manage our cost position.  The impact of the vendor settlements recorded in first nine months of Fiscal 2018 and Fiscal 2017 did not affect comparability for these periods.

[0001571996-17-000045:mdna:153]
[same as prior period, unchanged from 0001571996-17-000020:mdna:148]

[0001571996-17-000045:mdna:154]
[same as prior period, unchanged from 0001571996-17-000020:mdna:149]

[0001571996-17-000045:mdna:155]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 3, 2017 |  | % Change |  | October 28, 2016 |  | November 3, 2017 |  | % Change |  | October 28, 2016 |
|  | (in millions, except percentages) |
| Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Servers and networking | $ | 3,851 |  |  | 32% |  | $ | 2,910 |  |  | $ | 10,822 |  |  | 17% |  | $ | 9,222 |  |
| Storage | 3,667 |  |  | 19% |  | 3,079 |  |  | 11,018 |  |  | 165% |  | 4,159 |  |
| Total ISG net revenue | $ | 7,518 |  |  | 26% |  | $ | 5,989 |  |  | $ | 21,840 |  |  | 63% |  | $ | 13,381 |  |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| ISG operating income | $ | 678 |  |  | (24)% |  | $ | 897 |  |  | $ | 1,431 |  |  | 3% |  | $ | 1,389 |  |
| % of segment net revenue | 9.0 | % |  |  |  | 15.0 | % |  | 6.6 | % |  |  |  | 10.4 | % |

[0001571996-17-000045:mdna:156]
Net Revenue — During the third quarter of Fiscal 2018, ISG net revenue increased 26% driven by revenue growth in both product categories.  Servers and networking revenue increased 32% during the third quarter of Fiscal 2018, primarily resulting from an increase in sale of PowerEdge units, and an increase in average selling prices of PowerEdge.  Average selling prices increased as we managed our pricing in response to the current component cost environment, and also reflected the sale of servers with higher memory and storage content.  Storage revenue increased 19% during the third quarter of Fiscal 2018 due to the incremental revenue from the EMC acquired business, although we are experiencing reduced demand in ISG for certain elements of our storage portfolio, including high-end and traditional midrange storage offerings which are priced greater than $25,000.  We are addressing this dynamic through investments in our go-to-market capability and product enhancements.

[0001571996-17-000045:mdna:157]
During the first nine months of Fiscal 2018, ISG net revenue increased 63% primarily due to incremental storage net revenue associated with the acquired EMC storage business, and to a lesser extent, increases in servers and networking.  Revenue from servers and networking increased 17% during the first nine months of Fiscal 2018, primarily resulting from an increase in sale of PowerEdge units, and an increase in average selling prices of PowerEdge due to the dynamics mentioned above.

[0001571996-17-000045:mdna:158]
This year we introduced "as-a-service" flexible consumption models that are generally multi-year contracts which typically result in recognition of revenue over the term of the arrangement.  We are seeing increased interest in these new models, which will further strengthen our customer relationships. We expect that the impact of these arrangements will vary from quarter to quarter and build over time, but overall the impact to revenue was not significant during the first nine months of Fiscal 2018.

[0001571996-17-000045:mdna:159]
From a geographical perspective, during the third quarter and first nine months of Fiscal 2018, ISG net revenue increased in all regions due to the incremental revenue from the EMC acquired storage business.  The EMC acquired storage business operates on a world-wide basis with a geographic mix similar to that of the legacy Dell ISG business.

[0001571996-17-000045:mdna:160]
Operating Income — During the third quarter of Fiscal 2018, ISG operating income as a percentage of net revenue decreased 600 basis points to 9.0%.  During the third quarter of Fiscal 2018 we experienced gross margin pressure due to component cost inflation, which we expect to continue into Fiscal 2019.  ISG operating income was also affected by increased operating expenses reflecting larger investments in go-to-market capabilities and research and development.

[0001571996-17-000045:mdna:161]
During the first nine months of Fiscal 2018, ISG operating income decreased 380 basis points to 6.6% primarily due to increased operating expenses from the EMC acquired businesses and larger investments in go-to-market capabilities and research and development.  While the acquired EMC storage business contributed higher gross margin overall, we experienced gross margin pressure due to changing product mix within ISG as well as component cost inflation, which we expect to continue in the near term.

[0001571996-17-000045:mdna:162]
[same as prior period, unchanged from 0001571996-17-000020:mdna:155]

[0001571996-17-000045:mdna:163]
[same as prior period, unchanged from 0001571996-17-000020:mdna:156]

[0001571996-17-000045:mdna:164]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 3, 2017 |  | % Change |  | October 28, 2016 |  | November 3, 2017 |  | % Change |  | October 28, 2016 |
|  | (in millions, except percentages) |
| Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| VMware net revenue | $ | 1,953 |  |  | 52% |  | $ | 1,289 |  |  | $ | 5,596 |  |  | 334% |  | $ | 1,289 |  |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| VMware operating income | $ | 639 |  |  | 17% |  | $ | 548 |  |  | $ | 1,686 |  |  | 208% |  | $ | 548 |  |
| % of segment net revenue | 32.7 | % |  |  |  | 42.5 | % |  | 30.1 | % |  |  |  | 42.5 | % |

[0001571996-17-000045:mdna:165]
Net Revenue — VMware net revenue during the third quarter and first nine months of Fiscal 2018 primarily consisted of revenue from the sale of software licenses under perpetual licenses, related software maintenance and support, training, consulting services, and hosted services.  VMware net revenue for the third quarter of Fiscal 2018 grew 2% relative to the second quarter of Fiscal 2018, benefiting from balanced performance in all major geographies and broad strength across the product portfolio, particularly in our emerging product offerings.

[0001571996-17-000045:mdna:166]
From a geographical perspective, approximately half of VMware net revenue during the third quarter and first nine months of Fiscal 2018 was generated from sales to customers in the United States.

[0001571996-17-000045:mdna:167]
Operating Income — During the third quarter and first nine months of Fiscal 2018, VMware operating income as a percentage of net revenue was 32.7% and 30.1%, respectively.  VMware operating income as of percentage of net revenue for the third quarter of Fiscal 2018 increased 330 basis points relative to the second quarter of Fiscal 2018 as we effectively managed our cost position.

[0001571996-17-000045:mdna:168]
81

[0001571996-17-000045:mdna:169]
[same as prior period, unchanged from 0001571996-17-000020:mdna:161]

[0001571996-17-000045:mdna:170]
[same as prior period, unchanged from 0001571996-17-000020:mdna:162]

[0001571996-17-000045:mdna:171]
We sell products and services directly to customers and through a variety of sales channels, including retail distribution.  Our accounts receivable, net, was $9.2 billion and $9.4 billion as of November 3, 2017 and February 3, 2017, respectively.  We maintain an allowance for doubtful accounts to cover receivables that may be deemed uncollectible.  The allowance for losses is based on a provision for accounts that are collectively evaluated based on historical bad debt experience as well as specific identifiable customer accounts that are deemed at risk.  As of November 3, 2017 and February 3, 2017, the allowance for doubtful accounts was $80 million and $57 million, respectively.  Based on our assessment, we believe that we are adequately reserved for expected credit losses.  We monitor the aging of our accounts receivable and continue to take actions to reduce our exposure to credit losses.

[0001571996-17-000045:mdna:172]
[same as prior period, unchanged from 0001571996-17-000020:mdna:164]

[0001571996-17-000045:mdna:173]
Dell Financial Services, referred to as DFS, offers a wide range of financial services, including originating, collecting, and servicing customer receivables primarily related to the purchase of Dell products.  Following the closing of the EMC merger transaction, DFS began offering similar financial services related to the purchase of Dell EMC and VMware products.  In some cases, we originate financing activities for our commercial customers related to the purchase of third-party technology products that complement our portfolio of products and services.  New financing originations, which represent the amounts of financing provided by DFS to customers for equipment and related software and services, including originations of third-party technology products, were $1.6 billion and $1.1 billion for the third quarter of Fiscal 2018 and Fiscal 2017, respectively, and $4.3 billion and $3.0 billion for the first nine months of Fiscal 2018 and Fiscal 2017, respectively.  As of November 3, 2017 and February 3, 2017, our financing receivables, net were $7.0 billion and $5.9 billion, respectively.

[0001571996-17-000045:mdna:174]
We have securitization programs to fund revolving loans and fixed-term leases and loans through consolidated special purpose entities, referred to as SPEs, which we account for as secured borrowings.  We transfer certain U.S. and European customer financing receivables to these SPEs, whose purpose is to facilitate the funding of customer receivables through financing arrangements with multi-seller conduits that issue asset-backed debt securities in the capital markets and to private investors.  During the third quarter of Fiscal 2018 and Fiscal 2017, we transferred $1.0 billion and $0.6 billion, respectively, to these SPEs, and during the first nine months of Fiscal 2018 and Fiscal 2017, we transferred $2.9 billion and $2.0 billion, respectively, to the SPEs.  The structured financing debt related to all of our securitization programs included as secured borrowing was $3.9 billion and $3.1 billion as of November 3, 2017 and February 3, 2017, respectively.  In addition, the carrying amount of the corresponding financing receivables was $4.4 billion and $3.6 billion as of November 3, 2017 and February 3, 2017, respectively.  As a result of the EMC merger transaction, we are expanding our existing securitization programs to allow for additional funding of customer receivables in the capital markets.

[0001571996-17-000045:mdna:175]
We maintain an allowance to cover expected financing receivable credit losses and evaluate credit loss expectations based on our total portfolio.  For the third quarter of Fiscal 2018 and Fiscal 2017, the principal charge-off rate for our total portfolio was 1.5% and 2.1%, respectively.  For the first nine months of Fiscal 2018 and Fiscal 2017, the principal charge-off rate for our total portfolio was 1.6% and 2.1%, respectively.  The decreases in our total portfolio charge-off rates were attributable to growth in our fixed-term, high quality commercial accounts, which generally have lower charge-off rates.  This growth in the portfolio resulted from the expansion of commercial originations, subsequent to the EMC merger transaction.  We expect that principal charge-off rates will continue to trend favorably over the coming year as DFS expands its volume of commercial originations.  The allowance for losses is determined based on several factors, including historical and anticipated experience, past due receivables, receivable type, and customer risk profile.  At November 3, 2017 and February 3, 2017, the allowance for financing receivable losses was $131 million and $143 million, respectively.  In general, the loss rates on our financing receivables have improved over the periods presented.  We expect relatively stable loss rates in future periods, with movements in these rates being primarily driven by seasonality and a continued shift in portfolio composition to lower risk commercial assets.  We continue to monitor broader economic indicators and their potential impact on future loss performance.  We have an extensive process to manage our exposure to customer credit risk, including active management of credit lines and our collection activities.  We also sell selected fixed-term financing receivables to unrelated third parties on a periodic basis, primarily to manage certain concentrations of customer credit exposure.  Based on our assessment of the customer financing receivables, we believe that we are adequately reserved.

[0001571996-17-000045:mdna:176]
[same as prior period, unchanged from 0001571996-17-000020:mdna:168]

[0001571996-17-000045:mdna:177]
[same as prior period, unchanged from 0001571996-17-000020:mdna:170]

[0001571996-17-000045:mdna:178]
[same as prior period, unchanged from 0001571996-17-000020:mdna:171]

[0001571996-17-000045:mdna:179]
Our total deferred revenue was $20.1 billion and $18.7 billion as of November 3, 2017 and February 3, 2017, respectively.  A majority of our deferred revenue as of November 3, 2017 is expected to be recognized over the next two years.

[0001571996-17-000045:mdna:180]
[same as prior period, unchanged from 0001571996-17-000020:mdna:173]

[0001571996-17-000045:mdna:181]
As of November 3, 2017, we had no off-balance sheet arrangements that have or are reasonably likely to have a current or future material effect on our financial condition or results of operations.

[0001571996-17-000045:mdna:182]
83

[0001571996-17-000045:mdna:183]
[same as prior period, unchanged from 0001571996-17-000020:mdna:176]

[0001571996-17-000045:mdna:184]
[same as prior period, unchanged from 0001571996-17-000020:mdna:177]

[0001571996-17-000045:mdna:185]
[same as prior period, unchanged from 0001571996-17-000020:mdna:178]

[0001571996-17-000045:mdna:186]
[same as prior period, unchanged from 0001571996-17-000020:mdna:179]

[0001571996-17-000045:mdna:187]
[same as prior period, unchanged from 0001571996-17-000020:mdna:180]

[0001571996-17-000045:mdna:188]
[same as prior period, unchanged from 0001571996-17-000020:mdna:181]

[0001571996-17-000045:mdna:189]
[same as prior period, unchanged from 0001571996-17-000020:mdna:182]

[0001571996-17-000045:mdna:190]
[same as prior period, unchanged from 0001571996-17-000020:mdna:183]

[0001571996-17-000045:mdna:191]
To support our ongoing business operations, we rely on operating cash flows as our primary source of liquidity.  We monitor the efficiency of our balance sheet to ensure that we have adequate liquidity to support our strategic initiatives.  In addition to internally generated cash, we have access to other capital sources to finance our strategic initiatives and fund growth in our financing operations.  As of November 3, 2017, we had $11.7 billion of total cash and cash equivalents, the majority of which was held outside of the United States.  Our strategy is to deploy capital from any potential source, whether internally generated cash or debt, depending on the adequacy and availability of that source of capital and whether it can be accessed in a cost-effective manner.

[0001571996-17-000045:mdna:192]
[same as prior period, unchanged from 0001571996-17-000020:mdna:185]

[0001571996-17-000045:mdna:193]
[same as prior period, unchanged from 0001571996-17-000020:mdna:218]

[0001571996-17-000045:mdna:194]
The following table summarizes our cash and cash equivalents as well as our available borrowings as of November 3, 2017 and February 3, 2017:

[0001571996-17-000045:mdna:195]
|  | November 3, 2017 |  | February 3, 2017 |
|  | (in millions) |
| Cash and cash equivalents, and available borrowings: |  |  |  |
| Cash and cash equivalents (a) | $ | 11,706 |  |  | $ | 9,474 |  |
| Remaining available borrowings under revolving credit facilities (b) | 4,895 |  |  | 2,678 |  |
| Total cash, cash equivalents, and available borrowings | $ | 16,601 |  |  | $ | 12,152 |  |

[0001571996-17-000045:mdna:196]
[same as prior period, unchanged from 0001571996-17-000020:mdna:188]

[0001571996-17-000045:mdna:197]
(a)  Of the $11.7 billion of cash and cash equivalents as of November 3, 2017, $6.0 billion was held by VMware, Inc.

[0001571996-17-000045:mdna:198]
(b)  Of the $4.9 billion in remaining available borrowings as of November 3, 2017, $1.0 billion was available under the VMware Revolving Credit Facility and $100 million was available under the Pivotal Revolving Credit Facility.

[0001571996-17-000045:mdna:199]
The Revolving Credit Facility and China Revolving Credit Facility have combined maximum aggregate borrowings of approximately $3.8 billion.  Available borrowings under these facilities are reduced by draws on the facility and, under the Revolving Credit Facility, outstanding letters of credit. As of November 3, 2017, there were no borrowings outstanding under either facility and remaining available borrowings totaled approximately $3.8 billion.  These available borrowings may be used periodically for general corporate purposes.

[0001571996-17-000045:mdna:200]
The VMware Revolving Credit Facility and Pivotal Revolving Credit Facility have maximum aggregate borrowings of $1.0 billion and $100 million, respectively.  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc., Pivotal, and their respective subsidiaries.

[0001571996-17-000045:mdna:201]
We believe that our current cash and cash equivalents, along with cash that will be provided by future operations and borrowings expected to be available under the Revolving Credit Facility and China Revolving Credit Facility, will be sufficient over at least the next twelve months to fund our operations, capital expenditures, share repurchases, debt service requirements, and other corporate needs.  We expect that our cash balance will increase in the near term as we prepare for upcoming debt maturities in the first half of Fiscal 2019.

[0001571996-17-000045:mdna:202]
[same as prior period, unchanged from 0001571996-17-000020:mdna:192]

[0001571996-17-000045:mdna:203]
The following table summarizes our outstanding debt as of November 3, 2017 and February 3, 2017:

[0001571996-17-000045:mdna:204]
|  | November 3, 2017 |  | February 3, 2017 |
|  | (in millions) |
| Outstanding Debt: |  |  |  |
| Structured financing debt | $ | 4,348 |  |  | $ | 3,464 |  |
| Senior Secured Credit Facilities and First Lien Notes | 30,888 |  |  | 31,638 |  |
| Unsecured Notes and Debentures | 2,453 |  |  | 2,453 |  |
| Senior Notes | 3,250 |  |  | 3,250 |  |
| EMC Notes | 5,500 |  |  | 5,500 |  |
| VMware Notes | 4,000 |  |  | — |  |
| Margin Loan Facility | 2,000 |  |  | — |  |
| Bridge Facilities | — |  |  | 4,000 |  |
| Other | 83 |  |  | 51 |  |
| Total debt, principal amount | 52,522 |  |  | 50,356 |  |
| Carrying value adjustments | (871 | ) |  | (966 | ) |
| Total debt, carrying value | $ | 51,651 |  |  | $ | 49,390 |  |

[0001571996-17-000045:mdna:205]
To finance the EMC merger transaction, we issued an aggregate principal amount of $45.9 billion in new debt, which included proceeds from the sale of the First Lien Notes and Senior Notes, as well as borrowings under the Senior Secured Credit Facilities (including the Revolving Credit Facility), the Asset Sale Bridge Facility, the Margin Bridge Facility, and the VMware Bridge Facility at the closing of the transaction.  Additionally, on September 7, 2016, EMC had outstanding senior notes (the "EMC Notes") consisting of $2.5 billion aggregate principal amount of its 1.875% Notes due June 2018, $2.0 billion aggregate principal amount of its 2.650% Notes due June 2020 and $1.0 billion aggregate principal amount of its 3.375% Notes due June 2023.  The EMC Notes remain outstanding following the closing of the EMC merger transaction.

[0001571996-17-000045:mdna:206]
During the nine months ended November 3, 2017, we completed two refinancing transactions of the Senior Secured Credit Facilities.  In the first refinancing transaction, which occurred during the first quarter of Fiscal 2018, we refinanced the Term Loan B Facility to reduce the interest rate margin by 0.75% and to increase the outstanding principal amount by $0.5 billion.  We applied the proceeds from the Term Loan B Facility refinancing to repay $0.5 billion principal amount of the Margin Bridge Facility.  Additionally, during the first quarter of Fiscal 2018, we entered into the Margin Loan Facility in the principal amount of $2.0 billion, and used the proceeds of the new facility to repay the Margin Bridge Facility.

[0001571996-17-000045:mdna:207]
In the second refinancing transaction, which occurred during the third quarter of Fiscal 2018, we refinanced the Term Loan A-2 Facility, Term Loan A-3 Facility, Term Loan B Facility, and the Revolving Credit Facility.  As a result of the refinancing, the interest rate margin under each of these facilities decreased 0.50% and the outstanding principal amount of the Term Loan A-2 Facility increased by $672 million, which was used to pay $212 million principal amount of the Term Loan A-3 Facility and $460 million of principal amount of the Term Loan B Facility, as well as related fees and expenses. Further, the Revolving Credit Facility's borrowing capacity increased by $180 million to $3.3 billion.

[0001571996-17-000045:mdna:208]
During the first nine months of Fiscal 2018, the Company repaid approximately $0.9 billion principal amount of its term loan facilities and $0.4 billion under the Revolving Credit Facility and issued an additional $0.9 billion, net, in structured financing debt to support the expansion of its financing receivables portfolio.

[0001571996-17-000045:mdna:209]
Further, during the third quarter of Fiscal 2018, VMware, Inc. completed a public offering of senior notes in the aggregate principal amount of $4.0 billion (the "VMware Notes").  VMware, Inc. used a portion of the net proceeds from the offering to repay certain intercompany promissory notes previously issued by it to EMC in the aggregate principal amount of $1.2 billion.  We applied the proceeds of this repayment, and other cash, to repay $1.5 billion principal amount of the VMware Note Bridge Facility, without premium or penalty.  VMware, Inc. has disclosed that it intends to use the remaining net proceeds of the debt issuance to fund additional repurchases of up to $1.0 billion of its Class A common stock over the next 12 months, and for general VMware, Inc. corporate purposes, including mergers and acquisitions and repaying other indebtedness.

[0001571996-17-000045:mdna:210]
VMware, Inc. and its subsidiaries are unrestricted subsidiaries for purposes of the existing debt of Dell Technologies.  Neither Dell Technologies nor any of its subsidiaries, other than VMware, Inc., is obligated to make payment on the VMware Notes.  None of the net proceeds of the VMware Notes will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.

[0001571996-17-000045:mdna:211]
We balance the use of our securitization programs with working capital and other sources of liquidity to fund growth in DFS.  Of the $52.5 billion in outstanding principal debt as of November 3, 2017, $6.1 billion, which includes $4.3 billion in structured financing debt, is used to fund this business.

[0001571996-17-000045:mdna:212]
[same as prior period, unchanged from 0001571996-17-000020:mdna:197]

[0001571996-17-000045:mdna:213]
See Note 7 of the Notes to the Condensed Consolidated Financial Statements included in this report for more information about our debt and our unrestricted subsidiaries.  See Note 21 of the Notes to the Condensed Consolidated Financial Statements included in this report for more information about subsequent events.

[0001571996-17-000045:mdna:214]
[same as prior period, unchanged from 0001571996-17-000020:mdna:233]

[0001571996-17-000045:mdna:215]
[same as prior period, unchanged from 0001571996-17-000020:mdna:202]

[0001571996-17-000045:mdna:216]
[same as prior period, unchanged from 0001571996-17-000020:mdna:203]

[0001571996-17-000045:mdna:217]
|  | Nine Months Ended |
|  | November 3, 2017 |  | October 28, 2016 |
|  | (in millions) |
| Net change in cash from: |  |  |  |
| Operating activities | $ | 3,679 |  |  | $ | 1,569 |  |
| Investing activities | (1,990 | ) |  | (38,059 | ) |
| Financing activities | 496 |  |  | 38,787 |  |
| Effect of exchange rate changes on cash and cash equivalents | 47 |  |  | 31 |  |
| Change in cash and cash equivalents | $ | 2,232 |  |  | $ | 2,328 |  |

[0001571996-17-000045:mdna:218]
Operating Activities — Cash provided by operating activities was $3.7 billion and $1.6 billion during the first nine months of Fiscal 2018 and Fiscal 2017, respectively.  The increase in operating cash flows during the first nine months of Fiscal 2018 was driven by improved profitability, including the incremental profitability from the EMC acquired businesses, and ongoing working capital initiatives.  Further, cash paid for transaction costs during the first nine months of Fiscal 2017 did not recur in Fiscal 2018.  The increase in operating cash flows was partially offset by the growth in our financing receivables portfolio and cash paid for interest and taxes.

[0001571996-17-000045:mdna:219]
Investing Activities — Investing activities primarily consist of cash used to fund strategic investments, the maturities, sales, and purchases of investments, capital expenditures for property, plant, and equipment, and capitalized software development costs.  Cash used by investing activities was $2.0 billion and $38.1 billion during the first nine months of Fiscal 2018 and Fiscal 2017, respectively.  The decrease in cash used in investing activities was primarily driven by $37.6 billion, net cash used to fund our acquisition of EMC during the first nine months of Fiscal 2017 that did not recur during Fiscal 2018.

[0001571996-17-000045:mdna:220]
Financing Activities — Financing activities primarily consist of the proceeds and repayments of debt and cash used to repurchase common stock.  Cash provided by financing activities was $0.5 billion during the first nine months of Fiscal 2018 driven by net proceeds from debt, primarily due to the issuance of the VMware Notes, partially offset by cash used for share repurchases.  In comparison, cash provided by financing activities was $38.8 billion during the first nine months of Fiscal 2017 and primarily consisted of $46.0 billion in cash proceeds from debt, $43.2 billion of which was issued in connection with the EMC merger transaction, and $4.4 billion in proceeds from the sale and issuance of our Class A, Class B, and Class C Common Stock for financing of that transaction.  These issuances were partially offset by $9.6 billion in repayments of debt, $0.8 billion in payments for debt issuance costs, $0.8 billion in payments to repurchase common stock, and $0.4 billion in payments related to the appraisal litigation from the going-private transaction.  See Note 7 and Note 17 of the Notes to the Condensed Consolidated Financial Statements included in this report for more information about our debt and share repurchase programs, respectively.

[0001571996-17-000045:mdna:221]
87

[0001571996-17-000045:mdna:222]
[same as prior period, unchanged from 0001571996-17-000020:mdna:208]

[0001571996-17-000045:mdna:223]
[same as prior period, unchanged from 0001571996-17-000020:mdna:209]

[0001571996-17-000045:mdna:224]
[same as prior period, unchanged from 0001571996-17-000020:mdna:210]

[0001571996-17-000045:mdna:225]
[same as prior period, unchanged from 0001571996-17-000020:mdna:211]

[0001571996-17-000045:mdna:226]
|  | Three Months Ended |
|  | November 3, 2017 |  | October 28, 2016 |
| Days of sales outstanding (a) | 46 |  |  | 52 |  |
| Days of supply in inventory (b) | 17 |  |  | 23 |  |
| Days in accounts payable (c) | (112 | ) |  | (115 | ) |
| Cash conversion cycle (d) | (49 | ) |  | (40 | ) |

[0001571996-17-000045:mdna:227]
[same as prior period, unchanged from 0001571996-17-000020:mdna:213]

[0001571996-17-000045:mdna:228]
| (a) | Days of sales outstanding, referred to as DSO, calculates the average collection period of our receivables. DSO is based on the ending net trade receivables and the most recent quarterly non-GAAP net revenue for each period. DSO also includes the effect of product costs related to customer shipments not yet recognized as revenue that are classified in other current assets, as we believe this provides a more relevant metric that aligns with actual sales activity in the quarter, regardless of revenue recognition under GAAP. DSO is calculated by adding accounts receivable, net of allowance for doubtful accounts, and customer shipments in transit and dividing that sum by average non-GAAP net revenue per day for the current quarter (90 days for the three months ended November 3, 2017 and October 28, 2016). As of November 3, 2017, DSO and days of customer shipments not yet recognized were 42 and 4 days, respectively. As of October 28, 2016, DSO and days of customer shipments not yet recognized were 47 and 5 days, respectively. |

[0001571996-17-000045:mdna:229]
| (b) | Days of supply in inventory, referred to as DSI, measures the average number of days from procurement to sale of our products. DSI is based on ending inventory adjusted to exclude purchase accounting adjustments and non-GAAP cost of goods sold for each period. DSI is calculated by dividing ending inventory by average non-GAAP cost of goods sold per day for the current quarter (90 days for the three months ended November 3, 2017 and October 28, 2016). |

[0001571996-17-000045:mdna:230]
| (c) | Days in accounts payable, referred to as DPO, calculates the average number of days our payables remain outstanding before payment. DPO is based on ending accounts payable and non-GAAP cost of goods sold for each period. DPO is calculated by dividing accounts payable by average non-GAAP cost of goods sold per day for the current quarter (90 days for the three months ended November 3, 2017 and October 28, 2016). |

[0001571996-17-000045:mdna:231]
[same as prior period, unchanged from 0001571996-17-000020:mdna:217]

[0001571996-17-000045:mdna:232]
[same as prior period, unchanged from 0001571996-17-000020:mdna:219]

[0001571996-17-000045:mdna:233]
|  | Three Months Ended |
|  | November 3, 2017 |  | October 28, 2016 |
|  | (in millions) |
| Cost of goods sold | $ | 14,447 |  |  | $ | 12,348 |  |
| Non-GAAP adjustments: |  |  |  |
| Impact of purchase accounting | (12 | ) |  | (199 | ) |
| Amortization of intangibles | (914 | ) |  | (604 | ) |
| Transaction-related expenses | (5 | ) |  | (30 | ) |
| Other corporate expenses | (28 | ) |  | (62 | ) |
| Non-GAAP cost of goods sold | $ | 13,488 |  |  | $ | 11,453 |  |

[0001571996-17-000045:mdna:234]
|  | November 3, 2017 |  | October 28, 2016 |
|  | (in millions) |
| Inventory | 2,582 |  |  | 3,504 |  |
| Less: Impact of purchase accounting | — |  |  | (565 | ) |
| Inventory adjusted to exclude purchase accounting adjustments | 2,582 |  |  | 2,939 |  |

[0001571996-17-000045:mdna:235]
For the three months ended November 3, 2017, the change in our cash conversion cycle was favorable by 9 days when compared to the three months ended October 28, 2016.  DSO and DSI both improved 6 days in part due to continued integration of our operations with EMC.  Also, the comparison to the prior period was affected by the timing of the EMC merger transaction.  DSO and DSI for the three months ended October 28, 2016 were both negatively impacted by the timing of that transaction as we assumed all of EMC's accounts receivable and inventory, but only included the portion of EMC's revenue and cost of goods sold for the period from September 7, 2016 to October 28, 2016.

[0001571996-17-000045:mdna:236]
The improvement in DSO and DSI was partially offset by an unfavorable change in DPO.  The unfavorable change in DPO was  primarily attributable to a benefit in the prior year driven by the timing dynamic discussed above, as we assumed all of EMC's accounts payable, but only included the portion of EMC's cost of goods sold for the period from September 7, 2016 to October 28, 2016.  This unfavorable change in DPO for the three months ended November 3, 2017 was offset partially by alignment of supplier payment terms as part of ongoing integration efforts.

[0001571996-17-000045:mdna:237]
We believe our business model allows us to maintain an efficient cash conversion cycle, which compares favorably with that of others in our industry.

[0001571996-17-000045:mdna:238]
[same as prior period, unchanged from 0001571996-17-000020:mdna:222]

[0001571996-17-000045:mdna:239]
Capital Expenditures — During the first nine months of Fiscal 2018 and Fiscal 2017, we spent $902 million and $417 million, respectively, on property, plant, and equipment.  These expenditures were primarily incurred in connection with our global expansion efforts and infrastructure investments made to support future growth.  Product demand, product mix, and the use of contract manufacturers, as well as ongoing investments in operating and information technology infrastructure, influence the level and prioritization of our capital expenditures.  Aggregate capital expenditures for Fiscal 2018, which will be primarily related to infrastructure investments and strategic initiatives, are currently expected to total approximately $1.2 billion.

[0001571996-17-000045:mdna:240]
[same as prior period, unchanged from 0001571996-17-000020:mdna:224]

[0001571996-17-000045:mdna:241]
Class V Common Stock Repurchases — On December 13, 2016, the board of directors approved a stock repurchase program under which we were authorized to use assets of the Class V Group to repurchase up to $500 million of shares of Class V Common Stock over a period of six months.  During the first quarter of Fiscal 2018, we repurchased 1.3 million shares of Class V Common Stock for $82 million pursuant to this initial authorization.  A total of 8.4 million shares have been repurchased under this program.

[0001571996-17-000045:mdna:242]
On March 27, 2017 and August 18, 2017, the board of directors approved two amendments of the Class V Group Repurchase Program (the "March 2017 Class V Group Repurchase Program" and the “August 2017 Class V Group Repurchase Program,” respectively) which, when combined, authorized us to use assets of the Class V Group to repurchase up to an additional $600 million of shares of Class V Common Stock over additional six month periods from the respective board approval dates.  On May 9, 2017, the March 2017 Class V Group Repurchase Program was completed, with us having repurchased 4.6 million shares of Class V Common Stock for $300 million.  On October 31, 2017, the August 2017 Class V Group Repurchase Program was completed, with us having repurchased 3.8 million shares of Class V Common Stock for $300 million.

[0001571996-17-000045:mdna:243]
VMware, Inc. Class A Common Stock Repurchases — On December 15, 2016, we entered into a stock purchase agreement with VMware, Inc. (the "December 2016 Stock Purchase Agreement"), pursuant to which VMware, Inc. agreed to repurchase for cash $500 million of shares of VMware, Inc. Class A common stock from a subsidiary of Dell Technologies.  During the first quarter of Fiscal 2018, VMware, Inc. repurchased 1.4 million shares pursuant to the December 2016 Stock Purchase Agreement.  VMware, Inc. repurchased a total of 6.2 million shares under this agreement.  We applied the proceeds from the sale to the repurchase of shares of our Class V Common Stock under the Class V Group Repurchase Program described above.  All shares repurchased under VMware, Inc.'s stock repurchase programs are retired.

[0001571996-17-000045:mdna:244]
In January 2017 and August 2017, VMware, Inc.'s board of directors authorized the repurchase of up to $2.2 billion of shares of VMware, Inc. Class A common stock (the "January 2017 Authorization" for up to $1.2 billion through the end of Fiscal 2018, and the "August 2017 Authorization" for up to $1 billion through August 31, 2018). On March 29, 2017 and August 23, 2017, we entered into two new stock purchase agreements with VMware, Inc. (the "March 2017 Stock Purchase Agreement" and the "August 2017 Stock Purchase Agreement," respectively), pursuant to which VMware, Inc. agreed to repurchase for cash a total of $600 million of shares of VMware, Inc. Class A common stock from a subsidiary of Dell Technologies.  VMware, Inc. repurchased approximately 6.1 million shares of Class A common stock (consisting of 3.4 million shares pursuant to the March 2017 Stock Purchase Agreement and 2.7 million shares pursuant to the August 2017 Stock Purchase Agreement).  We applied the proceeds of the sales to the repurchase of shares of the Class V Common Stock under the March 2017 and August 2017 Class V Group Repurchase Programs described above.  As of November 3, 2017, the sale transactions under the March 2017 and August 2017 Stock Purchase Agreements were completed.  The purchase prices of the 3.4 million shares and 2.7 million shares repurchased by VMware, Inc. were each based on separate volume-weighted average per share prices of the Class A common stock as reported on the New York Stock Exchange during separate specified reference periods, less a discount of 3.5% from the respective volume-weighted average per share price.

[0001571996-17-000045:mdna:245]
During the three and nine months ended November 3, 2017, VMware, Inc. repurchased 5.1 million shares of Class A common stock in the open market for $555 million.

[0001571996-17-000045:mdna:246]
As of November 3, 2017, the cumulative authorized amount remaining for share repurchases by VMware, Inc. was $1,045 million, which represents the $2.2 billion authorized since January 2017, less the cumulative Class A common stock repurchases from a subsidiary of Dell Technologies of $600 million, and less the cumulative Class A common stock repurchases in the open market of $555 million.

[0001571996-17-000045:mdna:247]
For more information regarding share repurchase programs, see Note 17 and Note 21 of the Notes to the Condensed Consolidated Financial Statements included in this report, and "Part II — Item 2 — Unregistered Sales of Equity Securities and Use of Proceeds."

[0001571996-17-000045:mdna:248]
[same as prior period, unchanged from 0001571996-17-000020:mdna:230]

[0001571996-17-000045:mdna:249]
[same as prior period, unchanged from 0001571996-17-000020:mdna:231]

[0001571996-17-000045:mdna:250]
As of November 3, 2017, we had $3.1 billion, $0.3 billion, and $0.5 billion in purchase obligations for Fiscal 2018 (remaining three months), Fiscal 2019, and Fiscal 2020 and thereafter, respectively.

[0001571996-17-000045:mdna:251]
91
