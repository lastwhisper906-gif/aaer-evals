# DELL notes — 0001571996-17-000045


## dvmt:ReconciliationofConsolidatedNetIncomeLossTableTextBlock

[0001571996-17-000045:notes:1]
[same as prior period, unchanged from 0001571996-17-000020:notes:1]

[0001571996-17-000045:notes:2]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 3, 2017 |  | October 28, 2016 |  | November 3, 2017 |  | October 28, 2016 |
|  | (in millions) |
| Net income from continuing operations attributable to Class V Common Stock | $ | 223 |  |  | $ | 175 |  |  | $ | 509 |  |  | $ | 175 |  |
| Net loss from continuing operations attributable to DHI Group | (1,160 | ) |  | (1,801 | ) |  | (3,726 | ) |  | (2,486 | ) |
| Net loss from continuing operations attributable to Dell Technologies Inc. | (937 | ) |  | (1,626 | ) |  | (3,217 | ) |  | (2,311 | ) |
| Income (loss) from discontinued operations, net of income taxes (Note 3) | — |  |  | (438 | ) |  | — |  |  | 875 |  |
| Net loss attributable to Dell Technologies Inc. | $ | (937 | ) |  | $ | (2,064 | ) |  | $ | (3,217 | ) |  | $ | (1,436 | ) |


## invest:InvestmentTableTextBlock

[0001571996-17-000045:notes:3]
[same as prior period, unchanged from 0001571996-17-000020:notes:3]

[0001571996-17-000045:notes:4]
|  | November 3, 2017 |  | February 3, 2017 |
|  | Cost |  | Unrealized Gain |  | Unrealized (Loss) |  | Carrying Value |  | Cost |  | Unrealized Gain |  | Unrealized (Loss) |  | Carrying Value |
|  | (in millions) |
| Investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government and agencies | $ | 479 |  |  | $ | — |  |  | $ | (1 | ) |  | $ | 478 |  |  | $ | 231 |  |  | $ | — |  |  | $ | — |  |  | $ | 231 |  |
| U.S. corporate debt securities | 649 |  |  | — |  |  | (1 | ) |  | 648 |  |  | 651 |  |  | — |  |  | (1 | ) |  | 650 |  |
| Foreign debt securities | 883 |  |  | — |  |  | (1 | ) |  | 882 |  |  | 743 |  |  | — |  |  | (1 | ) |  | 742 |  |
| Municipal obligations | — |  |  | — |  |  | — |  |  | — |  |  | 348 |  |  | — |  |  | — |  |  | 348 |  |
| Asset-backed securities | — |  |  | — |  |  | — |  |  | — |  |  | 4 |  |  | — |  |  | — |  |  | 4 |  |
| Total short-term investments | 2,011 |  |  | — |  |  | (3 | ) |  | 2,008 |  |  | 1,977 |  |  | — |  |  | (2 | ) |  | 1,975 |  |
| U.S. government and agencies | 652 |  |  | — |  |  | (4 | ) |  | 648 |  |  | 689 |  |  | — |  |  | (6 | ) |  | 683 |  |
| U.S. corporate debt securities | 1,349 |  |  | 2 |  |  | (7 | ) |  | 1,344 |  |  | 1,164 |  |  | — |  |  | (14 | ) |  | 1,150 |  |
| Foreign debt securities | 1,550 |  |  | 1 |  |  | (7 | ) |  | 1,544 |  |  | 1,356 |  |  | — |  |  | (15 | ) |  | 1,341 |  |
| Municipal obligations | — |  |  | — |  |  | — |  |  | — |  |  | 4 |  |  | — |  |  | — |  |  | 4 |  |
| Equity and other securities (a) | 659 |  |  | 78 |  |  | — |  |  | 737 |  |  | 604 |  |  | 22 |  |  | (2 | ) |  | 624 |  |
| Total long-term investments | 4,210 |  |  | 81 |  |  | (18 | ) |  | 4,273 |  |  | 3,817 |  |  | 22 |  |  | (37 | ) |  | 3,802 |  |
| Total investments | $ | 6,221 |  |  | $ | 81 |  |  | $ | (21 | ) |  | $ | 6,281 |  |  | $ | 5,794 |  |  | $ | 22 |  |  | $ | (39 | ) |  | $ | 5,777 |  |

[0001571996-17-000045:notes:5]
[same as prior period, unchanged from 0001571996-17-000020:notes:5]

[0001571996-17-000045:notes:6]
[same as prior period, unchanged from 0001571996-17-000020:notes:6]


## invest:InvestmentTextBlock

[0001571996-17-000045:notes:7]
[same as prior period, unchanged from 0001571996-17-000020:notes:7]

[0001571996-17-000045:notes:8]
The Company's investments in debt securities are classified as available-for-sale securities, which are carried at fair value.  As of November 3, 2017, the aggregate fair value of investments held in a continuous unrealized loss position for greater than 12 months was $1.7 billion, and the unrealized loss of these investments was $13 million.

[0001571996-17-000045:notes:9]
The maturities of debt securities held at November 3, 2017 are as follows:

[0001571996-17-000045:notes:10]
|  | Amortized Cost |  | Carrying Value |
|  | (in millions) |
| Due within one year | $ | 2,011 |  |  | $ | 2,008 |  |
| Due after 1 year through 5 years | 3,491 |  |  | 3,476 |  |
| Due after 5 years through 10 years | 60 |  |  | 60 |  |
| Total | $ | 5,562 |  |  | $ | 5,544 |  |


## us-gaap:AllowanceForCreditLossesOnFinancingReceivablesTableTextBlock

[0001571996-17-000045:notes:11]
[same as prior period, unchanged from 0001571996-17-000020:notes:11]

[0001571996-17-000045:notes:12]
|  | Three Months Ended |
|  | November 3, 2017 |  | October 28, 2016 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |
| Balances at beginning of period | $ | 81 |  |  | $ | 54 |  |  | $ | 135 |  |  | $ | 100 |  |  | $ | 56 |  |  | $ | 156 |  |
| Charge-offs, net of recoveries | (21 | ) |  | (5 | ) |  | (26 | ) |  | (21 | ) |  | (8 | ) |  | (29 | ) |
| Provision charged to income statement | 19 |  |  | 3 |  |  | 22 |  |  | 16 |  |  | 3 |  |  | 19 |  |
| Balances at end of period | $ | 79 |  |  | $ | 52 |  |  | $ | 131 |  |  | $ | 95 |  |  | $ | 51 |  |  | $ | 146 |  |

[0001571996-17-000045:notes:13]
|  | Nine Months Ended |
|  | November 3, 2017 |  | October 28, 2016 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |
| Balances at beginning of period | $ | 91 |  |  | $ | 52 |  |  | $ | 143 |  |  | $ | 118 |  |  | $ | 58 |  |  | $ | 176 |  |
| Charge-offs, net of recoveries | (63 | ) |  | (13 | ) |  | (76 | ) |  | (69 | ) |  | (13 | ) |  | (82 | ) |
| Provision charged to income statement | 51 |  |  | 13 |  |  | 64 |  |  | 46 |  |  | 6 |  |  | 52 |  |
| Balances at end of period | $ | 79 |  |  | $ | 52 |  |  | $ | 131 |  |  | $ | 95 |  |  | $ | 51 |  |  | $ | 146 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001571996-17-000045:notes:14]
The accompanying unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes filed with the U.S. Securities and Exchange Commission ("SEC") in the Company's Annual Report on Form 10-K for the fiscal year ended February 3, 2017.  These Condensed Consolidated Financial Statements have been prepared in accordance with accounting principles generally accepted in the United States of America ("GAAP").  In the opinion of management, the accompanying Condensed Consolidated Financial Statements reflect all adjustments of a normal recurring nature considered necessary to fairly state the financial position of Dell Technologies Inc. (individually and together with its consolidated subsidiaries, the "Company" or "Dell Technologies") as of November 3, 2017 and February 3, 2017, the results of its operations and corresponding comprehensive income (loss) for the three and nine months ended November 3, 2017 and October 28, 2016, as well as its cash flows for the nine months ended November 3, 2017 and October 28, 2016.

[0001571996-17-000045:notes:15]
The preparation of financial statements in accordance with GAAP requires management to make estimates and assumptions that affect the amounts reported in the Condensed Consolidated Financial Statements and the accompanying Notes.  Actual results could differ materially from those estimates.  The results of operations and comprehensive income (loss) for the three and nine months ended November 3, 2017 and October 28, 2016 and cash flows for the nine months ended November 3, 2017 and October 28, 2016 are not necessarily indicative of the results to be expected for the full fiscal year or for any other fiscal period.


## us-gaap:BusinessAcquisitionProFormaInformationTextBlock

[0001571996-17-000045:notes:16]
[same as prior period, unchanged from 0001571996-17-000020:notes:16]

[0001571996-17-000045:notes:17]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 28, 2016 |  | October 28, 2016 |
|  | (in millions, except per share amounts) |
| Total net revenue (a) | $ | 17,891 |  |  | $ | 53,658 |  |
| Net loss attributable to Dell Technologies Inc. (a) | $ | (810 | ) |  | $ | (3,352 | ) |
| Earnings (loss) per share attributable to Dell Technologies Inc. - basic (b): |  |  |  |
| Continuing operations - Class V Common Stock | $ | 0.79 |  |  | $ | 1.84 |  |
| Continuing operations - DHI Group | $ | (1.71 | ) |  | $ | (6.58 | ) |
| Earnings (loss) per share attributable to Dell Technologies Inc. - diluted (b): |  |  |  |
| Continuing operations - Class V Common Stock | $ | 0.78 |  |  | $ | 1.83 |  |
| Continuing operations - DHI Group | $ | (1.71 | ) |  | $ | (6.58 | ) |

[0001571996-17-000045:notes:18]
(a)  The amounts presented for the three and nine months ended October 28, 2016 are different from those reported in the Company's Form 10-Q for the quarterly period ended October 28, 2016 previously filed with the SEC due to the finalization of purchase accounting related to the amortization amount and periods for deferred revenue and intangible asset fair value adjustments.

[0001571996-17-000045:notes:19]
| (b) | For purposes of calculating pro forma earnings (loss) per share, the Company used the two-class method. Earnings are allocated between the Class V Common Stock and the DHI Group on a basis consistent with historical earnings (loss) per share. |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001571996-17-000045:notes:20]
[same as prior period, unchanged from 0001571996-17-000020:notes:19]

[0001571996-17-000045:notes:21]
[same as prior period, unchanged from 0001571996-17-000020:notes:20]

[0001571996-17-000045:notes:22]
Transaction Overview — On September 7, 2016, EMC became a wholly-owned subsidiary of the Company as a result of the merger of Merger Sub with and into EMC, with EMC surviving as a wholly-owned subsidiary of the Company.  Pursuant to the terms of the merger agreement, upon the completion of the EMC merger transaction, each issued and outstanding share of common stock, par value $0.01 per share, of EMC (approximately 2.0 billion shares as of September 7, 2016) was converted into the right to receive (1) $24.05 in cash, without interest, and (2) 0.11146 validly issued, fully paid, and non-assessable shares of common stock of the Company designated as Class V Common Stock, par value $0.01 per share (the "Class V Common Stock"), plus cash in lieu of any fractional shares.  Shares of the Class V Common Stock were approved for listing on the New York Stock Exchange (the "NYSE") under the ticker symbol "DVMT" and began trading on September 7, 2016.

[0001571996-17-000045:notes:23]
In connection with the EMC merger transaction, the Company authorized 343 million shares of Class V Common Stock.  On September 7, 2016, Dell Technologies issued 223 million shares of Class V Common Stock to EMC shareholders at a purchase price of $45.07 per share for an aggregate purchase price of approximately $10 billion.  The total fair value of consideration transferred to effect the EMC merger transaction was approximately $64 billion, which primarily consisted of cash and such shares of Class V Common Stock, as well as the fair value of non-controlling interests in VMware, Inc. and Pivotal Software, Inc. ("Pivotal"), majority-owned consolidated subsidiaries of EMC.  See Note 17 of the Notes to the Condensed Consolidated Financial Statements for additional information on the Class V Common Stock.

[0001571996-17-000045:notes:24]
Assets Acquired and Liabilities Assumed — The EMC merger transaction has been accounted for as a business combination under the acquisition method of accounting.  The cumulative impact of any subsequent changes resulting from the facts and circumstances that existed as of the transaction date will be adjusted in the reporting period in which the adjustment amount is determined.  The following table summarizes, as of November 3, 2017, the purchase price allocation to the assets acquired and the liabilities assumed in the EMC merger transaction (in millions):

[0001571996-17-000045:notes:25]
[same as prior period, unchanged from 0001571996-17-000020:notes:24]

[0001571996-17-000045:notes:26]
[same as prior period, unchanged from 0001571996-17-000020:notes:25]

[0001571996-17-000045:notes:27]
[same as prior period, unchanged from 0001571996-17-000020:notes:26]

[0001571996-17-000045:notes:28]
The pro forma information for the three and nine months ended October 28, 2016 combines the Company's historical results for the three and nine months ended October 28, 2016 and EMC's historical results for the three and nine months ended October 28, 2016.  The historical results have been adjusted in the pro forma information to give effect to items that are (a) directly attributable to the EMC merger transaction, (b) factually supportable, and (c) expected to have a continuing impact on the combined company's results.  The pro forma information is presented for informational purposes only.  The unaudited pro forma results include the elimination of non-recurring transaction and integration costs of $1.2 billion and $1.4 billion for the three and nine months ended October 28, 2016, respectively.  The pro forma information does not purport to represent what the combined company's results of operations or financial condition would have been had the EMC merger transaction actually occurred on the date indicated, and does not purport to project the combined company's results of operations for any future period or as of any future date.

[0001571996-17-000045:notes:29]
[same as prior period, unchanged from 0001571996-17-000020:notes:28]

[0001571996-17-000045:notes:30]
During the three months ended August 4, 2017, VMware, Inc. completed the acquisitions of Wavefront and Apteligent, Inc., which were not material to the Condensed Consolidated Financial Statements.  These acquisitions are a part of VMware, Inc.’s

[0001571996-17-000045:notes:31]
strategy to accelerate the development of VMware Inc.'s Cloud services and other technologies.  The aggregate purchase price for the two acquisitions was $323 million, inclusive of the fair value of the Company's existing investment in Wavefront of $69 million and cash acquired of $35 million.  The aggregate purchase price included $36 million of identifiable intangible assets and $238 million of goodwill that is not expected to be deductible for tax purposes.  The identifiable intangible assets primarily relate to purchased technology, with estimated useful lives of five years.  The fair value of assumed unvested equity attributable to post-combination services was $37 million and will be expensed over the remaining requisite service periods on a straight-line basis.  The estimated fair value of the stock options assumed by the Company was determined using the Black-Scholes option pricing model.

[0001571996-17-000045:notes:32]
Prior to the closing of the acquisition, Dell Technologies, including VMware, Inc., held an ownership interest in Wavefront.  Upon completion of the step acquisition, Dell Technologies recognized a $45 million gain in interest and other, net for the remeasurement of its ownership interest to fair value.  The gain recognized in the step acquisition is not expected to be taxable.

[0001571996-17-000045:notes:33]
[same as prior period, unchanged from 0001571996-17-000020:notes:31]


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock

[0001571996-17-000045:notes:34]
[same as prior period, unchanged from 0001571996-17-000020:notes:32]

[0001571996-17-000045:notes:35]
[same as prior period, unchanged from 0001571996-17-000020:notes:33]

[0001571996-17-000045:notes:36]
[same as prior period, unchanged from 0001571996-17-000020:notes:34]

[0001571996-17-000045:notes:37]
[same as prior period, unchanged from 0001571996-17-000020:notes:35]

[0001571996-17-000045:notes:38]
Basis of Presentation — The accompanying unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes filed with the U.S. Securities and Exchange Commission ("SEC") in the Company's Annual Report on Form 10-K for the fiscal year ended February 3, 2017.  These Condensed Consolidated Financial Statements have been prepared in accordance with accounting principles generally accepted in the United States of America ("GAAP").  In the opinion of management, the accompanying Condensed Consolidated Financial Statements reflect all adjustments of a normal recurring nature considered necessary to fairly state the financial position of Dell Technologies Inc. (individually and together with its consolidated subsidiaries, the "Company" or "Dell Technologies") as of November 3, 2017 and February 3, 2017, the results of its operations and corresponding comprehensive income (loss) for the three and nine months ended November 3, 2017 and October 28, 2016, as well as its cash flows for the nine months ended November 3, 2017 and October 28, 2016.

[0001571996-17-000045:notes:39]
[same as prior period, unchanged from 0001571996-17-000020:notes:37]

[0001571996-17-000045:notes:40]
As a result of the EMC merger transaction completed on September 7, 2016, the Company's results of operations, comprehensive income (loss), and cash flows for the fiscal periods reflected in these Condensed Consolidated Financial Statements are not directly comparable as the results of the acquired businesses are only included in the consolidated results from September 7, 2016.

[0001571996-17-000045:notes:41]
Unless the context indicates otherwise, references in these Notes to the Condensed Consolidated Financial Statements to "VMware" mean the VMware reportable segment, which reflects the operations of VMware, Inc. (NYSE: VMW) within Dell Technologies.  See Exhibit 99.1 filed with the Company's quarterly report on Form 10-Q for the quarterly period ended November 3, 2017 for information on the differences between VMware reportable segment results and VMware, Inc. results.

[0001571996-17-000045:notes:42]
Recently Issued Accounting Pronouncements

[0001571996-17-000045:notes:43]
[same as prior period, unchanged from 0001571996-17-000020:notes:42]

[0001571996-17-000045:notes:44]
[same as prior period, unchanged from 0001571996-17-000020:notes:43]

[0001571996-17-000045:notes:45]
[same as prior period, unchanged from 0001571996-17-000020:notes:44]

[0001571996-17-000045:notes:46]
Recognition and Measurement of Financial Assets and Financial Liabilities — In January 2016, the FASB issued amended guidance that addresses certain aspects of recognition, measurement, presentation, and disclosure of financial instruments.  Public entities must adopt the new guidance for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017.  The amended guidance requires changes in the fair value of equity investments to be recognized through net income, rather than other comprehensive income.  Adoption of the standard will be applied through a cumulative one-time adjustment to retained earnings.  For the Company’s equity investments without readily determinable fair values, the Company expects to elect the measurement alternative to record those investments at cost, less impairment, and adjusted by observable price changes on a prospective basis.  The impact of the standard on the Consolidated Statements of Income (Loss) will depend on the relative changes in market price of the equity investments.

[0001571996-17-000045:notes:47]
Leases — In February 2016, the FASB issued amended guidance on the accounting for leasing transactions.  The primary objective of this update is to increase transparency and comparability among organizations by requiring lessees to recognize lease assets and lease liabilities on the balance sheet and disclosing key information about leasing arrangements.  The guidance makes some changes to lessor accounting, including the elimination of the use of third-party residual value guarantee insurance in the sales-type lease test.  Public entities must adopt the new guidance for reporting periods beginning after December 15, 2018, with early adoption permitted.  Companies are required to use a modified retrospective approach for leases that exist or are entered into after the beginning of the earliest comparative period in the financial statements.  The Company is currently evaluating the impact that the standard will have on the Consolidated Financial Statements.

[0001571996-17-000045:notes:48]
[same as prior period, unchanged from 0001571996-17-000020:notes:47]

[0001571996-17-000045:notes:49]
Classification of Certain Cash Receipts and Cash Payments — In August 2016, the FASB issued amended guidance on the presentation and classification of eight specific cash flow issues with the objective of reducing existing diversity in practice.  Public entities must adopt the new guidance for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017, with early adoption permitted.  Companies should reflect any adjustments on a retrospective basis, if practicable; otherwise, adoption is required to be applied as of the earliest date practicable.  The Company will adopt this standard as of May 4, 2018, and will apply adjustments retrospectively to each prior period presented on the Condensed Consolidated Statements of Cash Flows for that period.  The Company is currently evaluating the impact of the standard, and other than certain reclassifications on the Consolidated Statements of Cash Flows, it is not expected to have a material impact on the Consolidated Financial Statements.

[0001571996-17-000045:notes:50]
Statement of Cash Flows, Restricted Cash — In November 2016, the FASB issued amended guidance requiring entities to include explanations of changes in restricted cash and restricted cash equivalents on the cash flow statement, and also to provide a supplemental reconciliation of cash, cash equivalents and restricted cash.  Public entities must adopt the new guidance for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017, with early adoption permitted. The Company will adopt this standard as of May 4, 2018, and will apply adjustments retrospectively to each prior period presented on the Condensed Consolidated Statements of Cash Flows for that period and provide the supplemental reconciliation.  The Company does not expect that the standard will have a material impact on its Consolidated Financial Statements as its restricted cash balance does not change significantly from period to period.

[0001571996-17-000045:notes:51]
[same as prior period, unchanged from 0001571996-17-000020:notes:49]

[0001571996-17-000045:notes:52]
Derivatives and Hedging — In August 2017, the FASB issued amended guidance that will make more financial and non-financial hedging strategies eligible for hedge accounting.  The amended guidance changes how companies assess effectiveness, and also amends the presentation and disclosure requirements.  The guidance is intended to simplify the application of hedge accounting and increase transparency as to the scope and results of hedging programs.  Immediate early adoption is permitted in any interim or annual period.  The Company will early adopt this guidance at the beginning of the fiscal year ending February 1, 2019.  The Company is currently evaluating the application of the new guidance, but does not expect that it will have a material impact on the Consolidated Financial Statements.

[0001571996-17-000045:notes:53]
Recently Adopted Accounting Pronouncements

[0001571996-17-000045:notes:54]
[same as prior period, unchanged from 0001571996-17-000020:notes:52]

[0001571996-17-000045:notes:55]
[same as prior period, unchanged from 0001571996-17-000020:notes:53]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001571996-17-000045:notes:56]
COMMITMENTS AND CONTINGENCIES

[0001571996-17-000045:notes:57]
Legal Matters

[0001571996-17-000045:notes:58]
The Company is involved in various claims, suits, assessments, investigations, and legal proceedings that arise from time to time in the ordinary course of its business, including those identified below, consisting of matters involving consumer, antitrust, tax, intellectual property, and other issues on a global basis.  The Company accrues a liability when it believes that it is both probable that a liability has been incurred and that it can reasonably estimate the amount of the loss.  The Company reviews these accruals at least quarterly and adjusts them to reflect ongoing negotiations, settlements, rulings, advice of legal counsel, and other relevant information.  To the extent new information is obtained and the Company's views on the probable outcomes of claims, suits, assessments, investigations, or legal proceedings change, changes in the Company's accrued liabilities would be recorded in the period in which such a determination is made.  For some matters, the amount of liability is not probable or the amount cannot be reasonably estimated and therefore accruals have not been made.  The following is a discussion of the Company's significant legal matters and other proceedings:

[0001571996-17-000045:notes:59]
EMC Merger Litigation — The Company, Dell, and Universal Acquisition Co. ("Universal") were named as defendants in fifteen putative class-action lawsuits brought by purported EMC shareholders and VMware, Inc. stockholders challenging the proposed merger between the Company, Dell, and Universal on the one hand, and EMC on the other (the "EMC merger").  Those suits are captioned as follows:

[0001571996-17-000045:notes:60]
| Case | Court | Filing Date |
| 1. | IBEW Local No. 129 Benefit Fund v. Tucci,Civ. No. 1584-3130-BLS1 | Mass. Superior Court, Suffolk County | 10/15/2015 |
| 2. | Barrett v. Tucci,Civ. No. 15-6023-A | Mass. Superior Court, Middlesex County | 10/16/2015 |
| 3. | Graulich v. Tucci,Civ. No. 1584-3169-BLS1 | Mass. Superior Court, Suffolk County | 10/19/2015 |
| 4. | Vassallo v. EMC Corp.,Civ. No. 1584-3173-BLS1 | Mass. Superior Court, Suffolk County | 10/19/2015 |
| 5. | City of Miami Police Relief & Pension Fund v. Tucci,Civ. No. 1584-3174-BLS1 | Mass. Superior Court, Suffolk County | 10/19/2015 |
| 6. | Lasker v. EMC Corp.,Civ. No. 1584-3214-BLS1 | Mass. Superior Court, Suffolk County | 10/23/2015 |
| 7. | Walsh v. EMC Corp.,Civ. No. 15-13654 | U.S. District Court,District of Massachusetts | 10/27/2015 |
| 8. | Local Union No. 373 U.A. Pension Plan v. EMC Corp.,Civ. No. 1584-3253-BLS1 | Mass. Superior Court, Suffolk County | 10/28/2015 |
| 9. | City of Lakeland Emps.' Pension & Ret. Fund v. Tucci,Civ. No. 1584-3269-BLS1 | Mass. Superior Court, Suffolk County | 10/28/2015 |
| 10. | Ma v. Tucci,Civ. No. 1584-3281-BLS1 | Mass. Superior Court, Suffolk County | 10/29/2015 |
| 11. | Stull v. EMC Corp.,Civ. No. 15-13692 | U.S. District Court,District of Massachusetts | 10/30/2015 |
| 12. | Jacobs v. EMC Corp.,Civ. No. 15-6318-H | Mass. Superior Court, Middlesex County | 11/12/2015 |
| 13. | Ford v. VMware, Inc.,C.A. No. 11714-VCL | Delaware Chancery Court | 11/17/2015 |
| 14. | Pancake v. EMC Corp.,Civ. No. 16-10040 | U.S. District Court,District of Massachusetts | 1/11/2016 |
| 15. | Booth Family Trust v. EMC Corp.,Civ. No. 16-10114 | U.S. District Court,District of Massachusetts | 1/26/2016 |

[0001571996-17-000045:notes:61]
The fifteen lawsuits sought, among other things, injunctive relief enjoining the EMC merger, rescission of the EMC merger if consummated, an award of fees and costs, and/or an award of damages.

[0001571996-17-000045:notes:62]
The complaints in the IBEW, Barrett, Graulich, Vassallo, City of Miami, Lasker, Local Union No. 373, City of Lakeland, and Ma actions generally allege that the EMC directors breached their fiduciary duties to EMC shareholders in connection with the EMC merger by, among other things, failing to maximize shareholder value and agreeing to provisions in the EMC merger agreement that discouraged competing bids.  After consolidating the fifteen complaints, by decision dated December 7, 2015, the Business Litigation Session of the Suffolk County Superior Court in Massachusetts dismissed all nine complaints for failure to make a demand on the EMC board of directors.  Three of the nine plaintiffs in the consolidated actions appealed the judgment dismissing their complaints.  The Massachusetts Supreme Judicial Court granted an application for direct appellate review, and heard oral argument on the appeal on November 7, 2016.  On March 6, 2017, the Supreme Judicial Court issued a decision affirming the dismissal.  This decision terminated the consolidated actions.

[0001571996-17-000045:notes:63]
The complaints in the Walsh, Stull, Pancake, and Booth actions allege that the EMC directors breached their fiduciary duties to EMC shareholders in connection with the EMC merger by, among other things, failing to maximize shareholder value and agreeing to provisions in the EMC merger agreement that discouraged competing bids.  The complaints generally further allege that the preliminary registration statement on Form S-4 filed by the Company on December 14, 2015, in connection with the transaction contained material misstatements and omissions, in violation of Section 14(a) of the Securities Exchange Act of 1934 (the "Exchange Act") and SEC Rule 14a-9 promulgated thereunder and that the Company, Dell, and Universal acted as controlling persons of EMC under Section 20(a) of the Exchange Act.  On June 6, 2016, the Securities and Exchange Commission declared effective the Company's registration statement on Form S-4 relating to the EMC merger (the "SEC Form S-4"), including the amendments thereto.  On June 17, 2016, the parties to the Walsh, Stull, Pancake, and Booth actions submitted to the Court a Stipulation and Proposed Order Dismissing Action and Retaining Jurisdiction to Determine Plaintiffs' Counsel's Application for an Award of Attorneys' Fees and Reimbursement of Expenses.  In the stipulation, the plaintiffs represented to the Court that they believe sufficient information had been disclosed to warrant dismissal of the actions as moot in light of the disclosures in the SEC Form S-4, including the amendments thereto.  On October 25, 2016, following an agreement between the parties with respect to payment of attorneys' fees and expenses, the Court entered an order terminating the four actions for all purposes.

[0001571996-17-000045:notes:64]
The amended complaints in the Jacobs and Ford actions allege that EMC, as the majority stockholder of VMware, Inc., and the individual defendants, who were directors of EMC, VMware, Inc., or both, breached their fiduciary duties to minority stockholders of VMware, Inc. in connection with the proposed EMC merger by allegedly entering into or approving a merger that favors the interests of EMC and Dell at the expense of the minority stockholders.  The plaintiffs in the Jacobs action also brought suit against the Company, Dell, and Universal as alleged aiders and abettors.  Effective December 2, 2016, the parties entered into an agreement to resolve the Jacobs action, pursuant to which the plaintiff voluntarily dismissed the action with prejudice.  Under the operative amended complaint in the Ford action, the plaintiffs also brought suit against the Company and Dell for alleged breach of fiduciary duties to VMware, Inc. and its stockholders, and against the Company, Dell, and Universal for aiding and abetting the alleged breach of fiduciary duties by EMC's and VMware, Inc.'s directors.  Certain defendants filed motions to dismiss the amended complaint on June 21, 2016.  A hearing on those motions was held on February 3, 2017.  On May 2, 2017, the Court dismissed the amended complaint for failure to state a claim upon which relief could be granted and no appeal was taken.  All fifteen EMC merger-related lawsuits are now fully and finally resolved.

[0001571996-17-000045:notes:65]
Appraisal Proceedings — On October 29, 2013, Dell Technologies acquired Dell in a transaction referred to as the going-private transaction.  Holders of shares of Dell common stock who did not vote on September 12, 2013 in favor of the proposal to adopt the amended going-private transaction agreement and who properly demanded appraisal of their shares and who otherwise comply with the requirements of Section 262 of the Delaware General Corporate Law ("DGCL") are entitled to seek appraisal for, and obtain payment in cash for the judicially determined "fair value" (as defined pursuant to Section 262 of the DGCL) of, their shares in lieu of receiving the going-private transaction consideration.  Dell initially recorded a liability of $13.75 for each share with respect to which appraisal has been demanded and as to which the demand has not been withdrawn, together with interest at the statutory rate discussed below.  This liability was approximately $129 million as of both November 3, 2017 and February 3, 2017.  The Court of Chancery ruled that the fair value of the appraisal shares as of October 29, 2013, the date on which the going-private transaction became effective, was $17.62 per share.  This ruling would entitle the holders of the remaining 5,505,730 shares subject to the appraisal proceedings to $17.62 per share, plus interest at a statutory rate, compounded quarterly.  On November 21, 2016, the Court of Chancery entered final judgment in the appraisal action.  On November 22, 2016, Dell filed a notice of appeal to the Delaware Supreme Court, and a hearing was held on that appeal on September 27, 2017.  A ruling on the appeal is pending.  The Company believes it was adequately reserved for the appraisal proceedings as of November 3, 2017.

[0001571996-17-000045:notes:66]
Securities Litigation — On May 22, 2014, a securities class action seeking compensatory damages was filed in the United States District Court for the Southern District of New York, captioned the City of Pontiac Employee Retirement System vs. Dell Inc. et. al. (Case No. 1:14-cv-03644).  The action names as defendants Dell Inc. and certain current and former executive officers, and alleges that Dell made false and misleading statements about Dell's business operations and products between February 22, 2012 and May 22, 2012, which resulted in artificially inflated stock prices.  The case was transferred to the United States District Court for the Western District of Texas, where the defendants filed a motion to dismiss.  On September 16, 2016, the Court denied the motion to dismiss and the case is proceeding with discovery.  The defendants believe the claims asserted are without merit and the risk of material loss is remote.

[0001571996-17-000045:notes:67]
Copyright Levies — The Company's obligation to collect and remit copyright levies in certain European Union ("EU") countries may be affected by the resolution of legal proceedings pending in Germany and other EU member states against various companies, including Dell subsidiaries.  The plaintiffs in those proceedings generally seek to impose or modify the levies with respect to sales of such equipment as multifunction devices, phones, personal computers, storage devices, and printers, alleging that such products enable the copying of copyrighted materials.  Some of the proceedings also challenge whether the levy schemes in those countries comply with EU law.  Certain EU member countries that do not yet impose levies on digital devices are expected to implement legislation to enable them to extend existing levy schemes, while some other EU member countries are expected to limit the scope of levy schemes and their applicability in the digital hardware environment.  Dell, other companies, and various industry associations have opposed the extension of levies to the digital environment and have advocated alternative models of compensation to rights holders.  The Company continues to collect levies in certain EU countries where it has determined that based on local laws it is probable that it has a payment obligation.  The amount of levies is generally based on the number of products sold and the per-product amounts of the levies, which vary.  The Company accrues a liability when it believes that it is both probable that a loss has been incurred and when it can reasonably estimate the amount of the loss.

[0001571996-17-000045:notes:68]
Other Litigation — The various legal proceedings in which Dell is involved include commercial litigation and a variety of patent suits.  In some of these cases, Dell is the sole defendant.  More often, particularly in the patent suits, Dell is one of a number of defendants in the electronics and technology industries.  Dell is actively defending a number of patent infringement suits, and several pending claims are in various stages of evaluation.  While the number of patent cases varies over time, Dell does not currently anticipate that any of these matters will have a material adverse effect on its business, financial condition, results of operations, or cash flows.

[0001571996-17-000045:notes:69]
As of November 3, 2017, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for these or other proceedings or matters has been incurred.  However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company's business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters.  Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company's business, financial condition, results of operations, or cash flows will depend on a number of variables, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.

[0001571996-17-000045:notes:70]
Indemnifications

[0001571996-17-000045:notes:71]
In the ordinary course of business, the Company enters into contractual arrangements under which it may agree to indemnify the third party to such arrangements from any losses incurred relating to the services it performs on behalf of the Company or for losses arising from certain events as defined in the particular contract, such as litigation or claims relating to past performance.  Such indemnification obligations may not be subject to maximum loss clauses.  Historically, payments related to these indemnifications have not been material to the Company.

[0001571996-17-000045:notes:72]
In connection with the divestitures discussed in Note 3 of the Notes to the Condensed Consolidated Financial Statements, the Company has indemnified the purchasers of businesses for the occurrence of specified events.  The Company does not currently believe that contingent obligations to provide indemnification in connection with these divestitures will have a material adverse effect on the Company.

[0001571996-17-000045:notes:73]
Purchase Obligations

[0001571996-17-000045:notes:74]
The Company has contractual obligations to purchase goods or services, which specify significant terms, including fixed or minimum quantities to be purchased; fixed, minimum, or variable price provisions; and the approximate timing of the transaction.  As of November 3, 2017, the Company had $3,055 million, $278 million, and $458 million in purchase obligations for Fiscal 2018 (remaining three months), Fiscal 2019, and Fiscal 2020 and thereafter, respectively.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001571996-17-000045:notes:75]
[same as prior period, unchanged from 0001571996-17-000020:notes:73]

[0001571996-17-000045:notes:76]
[same as prior period, unchanged from 0001571996-17-000020:notes:74]

[0001571996-17-000045:notes:77]
[same as prior period, unchanged from 0001571996-17-000020:notes:75]

[0001571996-17-000045:notes:78]
|  | Foreign Currency Translation Adjustments |  | Investments |  | Cash Flow Hedges |  | Pension and Other Postretirement Plans |  | Accumulated Other Comprehensive Loss |
|  | (in millions) |
| Balances as of February 3, 2017 | $ | (612 | ) |  | $ | (13 | ) |  | $ | 11 |  |  | $ | 19 |  |  | $ | (595 | ) |
| Other comprehensive income (loss) before reclassifications | 325 |  |  | 44 |  |  | (81 | ) |  | — |  |  | 288 |  |
| Amounts reclassified from accumulated other comprehensive loss | — |  |  | 3 |  |  | 80 |  |  | — |  |  | 83 |  |
| Total change for the period | 325 |  |  | 47 |  |  | (1 | ) |  | — |  |  | 371 |  |
| Less: Change in comprehensive income attributable to non-controlling interests | — |  |  | 2 |  |  | — |  |  | — |  |  | 2 |  |
| Balances as of November 3, 2017 | $ | (287 | ) |  | $ | 32 |  |  | $ | 10 |  |  | $ | 19 |  |  | $ | (226 | ) |

[0001571996-17-000045:notes:79]
[same as prior period, unchanged from 0001571996-17-000020:notes:77]

[0001571996-17-000045:notes:80]
[same as prior period, unchanged from 0001571996-17-000020:notes:78]

[0001571996-17-000045:notes:81]
|  | Three Months Ended |
|  | November 3, 2017 |  | October 28, 2016 |
|  | Investments |  | Cash Flow Hedges |  | Total |  | Investments |  | Cash Flow Hedges |  | Total |
|  | (in millions) |
| Total reclassifications, net of tax: |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue | $ | — |  |  | $ | (18 | ) |  | $ | (18 | ) |  | $ | — |  |  | $ | 23 |  |  | $ | 23 |  |
| Cost of net revenue | — |  |  | (13 | ) |  | (13 | ) |  | — |  |  | (6 | ) |  | (6 | ) |
| Interest and other, net | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total reclassifications, net of tax | $ | — |  |  | $ | (31 | ) |  | $ | (31 | ) |  | $ | — |  |  | $ | 17 |  |  | $ | 17 |  |

[0001571996-17-000045:notes:82]
|  | Nine Months Ended |
|  | November 3, 2017 |  | October 28, 2016 |
|  | Investments |  | Cash Flow Hedges |  | Total |  | Investments |  | Cash Flow Hedges |  | Total |
|  | (in millions) |
| Total reclassifications, net of tax: |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue | $ | — |  |  | $ | (50 | ) |  | $ | (50 | ) |  | $ | — |  |  | $ | (44 | ) |  | $ | (44 | ) |
| Cost of net revenue | — |  |  | (30 | ) |  | (30 | ) |  | — |  |  | (20 | ) |  | (20 | ) |
| Interest and other, net | (3 | ) |  | — |  |  | (3 | ) |  | — |  |  | — |  |  | — |  |
| Total reclassifications, net of tax | $ | (3 | ) |  | $ | (80 | ) |  | $ | (83 | ) |  | $ | — |  |  | $ | (64 | ) |  | $ | (64 | ) |


## us-gaap:ConsolidationLessThanWhollyOwnedSubsidiaryParentOwnershipInterestEffectsOfChangesNetTextBlock

[0001571996-17-000045:notes:83]
[same as prior period, unchanged from 0001571996-17-000020:notes:81]

[0001571996-17-000045:notes:84]
|  | Nine Months Ended |
|  | November 3, 2017 |
|  | (in millions) |
| Net loss attributable to Dell Technologies Inc. | $ | (3,217 | ) |
| Transfers (to) from the non-controlling interests: |  |
| Increase in Dell Technologies Inc. additional paid-in-capital for equity issuances and other equity activity | 482 |  |
| Decrease in Dell Technologies Inc. additional paid-in-capital for equity issuances and other equity activity | (684 | ) |
| Net transfers to non-controlling interests | (202 | ) |
| Change from net loss attributable to Dell Technologies Inc. and transfers to/from the non-controlling interests | $ | (3,419 | ) |


## us-gaap:DebtDisclosureTextBlock

[0001571996-17-000045:notes:85]
DEBT

[0001571996-17-000045:notes:86]
The following table summarizes the Company's outstanding debt as of the dates indicated:

[0001571996-17-000045:notes:87]
|  | November 3, 2017 |  | February 3, 2017 |
|  | (in millions) |
| Secured Debt |  |  |  |
| Structured financing debt | $ | 4,348 |  |  | $ | 3,464 |  |
| Senior Secured Credit Facilities: |  |  |  |
| 3.25% Term Loan B Facility due September 2023 | 5,000 |  |  | 4,987 |  |
| Term Loan A-1 Facility due December 2018 | — |  |  | 600 |  |
| 3.00% Term Loan A-2 Facility due September 2021 | 4,450 |  |  | 3,876 |  |
| 2.75% Term Loan A-3 Facility due December 2018 | 1,438 |  |  | 1,800 |  |
| 2.75% Revolving Credit Facility due September 2021 | — |  |  | 375 |  |
| First Lien Notes: |  |  |  |
| 3.48% due June 2019 | 3,750 |  |  | 3,750 |  |
| 4.42% due June 2021 | 4,500 |  |  | 4,500 |  |
| 5.45% due June 2023 | 3,750 |  |  | 3,750 |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 8.10% due June 2036 | 1,500 |  |  | 1,500 |  |
| 8.35% due June 2046 | 2,000 |  |  | 2,000 |  |
| Unsecured Debt |  |  |  |
| Unsecured Notes and Debentures: |  |  |  |
| 5.65% due April 2018 | 500 |  |  | 500 |  |
| 5.875% due June 2019 | 600 |  |  | 600 |  |
| 4.625% due April 2021 | 400 |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 265 |  |  | 265 |  |
| Senior Notes: |  |  |  |
| 5.875% due June 2021 | 1,625 |  |  | 1,625 |  |
| 7.125% due June 2024 | 1,625 |  |  | 1,625 |  |
| EMC Notes: |  |  |  |
| 1.875% due June 2018 | 2,500 |  |  | 2,500 |  |
| 2.650% due June 2020 | 2,000 |  |  | 2,000 |  |
| 3.375% due June 2023 | 1,000 |  |  | 1,000 |  |
| VMware Notes: |  |  |  |
| 2.30% due August 2020 | 1,250 |  |  | — |  |
| 2.95% due August 2022 | 1,500 |  |  | — |  |
| 3.90% due August 2027 | 1,250 |  |  | — |  |
| Other |  |  |  |
| 3.63% Margin Loan Facility due April 2022 | 2,000 |  |  | — |  |
| Margin Bridge Facility due September 2017 | — |  |  | 2,500 |  |
| VMware Note Bridge Facility due September 2017 | — |  |  | 1,500 |  |
| Other | 83 |  |  | 51 |  |
| Total debt, principal amount | $ | 52,522 |  |  | $ | 50,356 |  |
| Unamortized discount, net of unamortized premium | (268 | ) |  | (284 | ) |
| Debt issuance costs | (603 | ) |  | (682 | ) |
| Total debt, carrying value | $ | 51,651 |  |  | $ | 49,390 |  |
| Total short-term debt, carrying value | $ | 6,235 |  |  | $ | 6,329 |  |
| Total long-term debt, carrying value | $ | 45,416 |  |  | $ | 43,061 |  |

[0001571996-17-000045:notes:88]
During the nine months ended November 3, 2017 the Company completed two refinancing transactions of the Senior Secured Credit Facilities described below.  In the first refinancing transaction, which occurred during the three months ended May 5, 2017, the Company refinanced the Term Loan B Facility to reduce the interest rate margin by 0.75% and to increase the outstanding principal amount by $500 million.  The Company applied the proceeds from the Term Loan B Facility refinancing to repay $500 million principal amount of the Margin Bridge Facility, without premium or penalty, and accrued and unpaid interest thereon.  Additionally, during the three months ended May 5, 2017, the Company entered into the Margin Loan Facility in the principal amount of $2.0 billion, and used the proceeds of the new facility to repay the Margin Bridge Facility, without premium or penalty.

[0001571996-17-000045:notes:89]
In the second refinancing transaction, which occurred during the three months ended November 3, 2017, the Company refinanced the Term Loan A-2 Facility, Term Loan A-3 Facility, Term Loan B Facility, and the Revolving Credit Facility.  As a result, the interest rate margin decreased 0.50% for each of the Term Loan A-2 Facility, Term Loan A-3 Facility, Term Loan B Facility, and the Revolving Credit Facility.  Additionally, the outstanding principal amount of the Term Loan A-2 Facility increased by $672 million which was used to pay $212 million of principal outstanding of the Term Loan A-3 Facility and $460 million of principal outstanding of the Term Loan B Facility.  Further, the Revolving Credit Facility's borrowing capacity increased $180 million to $3.3 billion.

[0001571996-17-000045:notes:90]
During the nine months ended November 3, 2017, the Company repaid approximately $0.9 billion principal amount of its term loan facilities and $0.4 billion under the Revolving Credit Facility and issued an additional $0.9 billion, net, in structured financing debt to support the expansion of its financing receivables portfolio.

[0001571996-17-000045:notes:91]
Further, during the three months ended November 3, 2017, VMware, Inc. completed a public offering of senior notes in the aggregate amount of $4.0 billion.  VMware, Inc. used a portion of the net proceeds from the offering to repay certain intercompany promissory notes previously issued by it to EMC in the aggregate principal amount of $1.2 billion.  The Company applied the proceeds of this repayment, and other cash, to repay $1.5 billion principal amount of the VMware Note Bridge Facility, without premium or penalty.

[0001571996-17-000045:notes:92]
Senior Secured Credit Facilities — At the closing of the EMC merger transaction on September 7, 2016, the Company entered into a credit agreement that provides for senior secured credit facilities (the "Senior Secured Credit Facilities") in the aggregate principal amount of $17.8 billion comprising (a) term loan facilities and (b) a senior secured Revolving Credit Facility, which includes capacity for up to $0.5 billion of letters of credit and for borrowings of up to $0.4 billion under swing-line loans.  As of November 3, 2017, available borrowings under the Revolving Credit Facility totaled $3.3 billion.  The Senior Secured Credit Facilities provide that the borrowers have the right at any time, subject to customary conditions, to request incremental term loans or incremental revolving commitments.

[0001571996-17-000045:notes:93]
Borrowings under the Senior Secured Credit Facilities bear interest at a rate per annum equal to an applicable margin, plus, at the borrowers' option, either (a) a base rate, which, under the Term Loan B Facility, is subject to an interest rate floor of 1.75% per annum, and under all other borrowings is subject to an interest rate floor of 0% per annum, or (b) a London interbank offered rate ("LIBOR"), which, under the Term Loan B Facility, is subject to an interest rate floor of 0.75% per annum, and under all other borrowings is subject to an interest rate floor of 0% per annum.  Interest is payable, in the case of loans bearing interest based on LIBOR, at the end of each interest period (but at least every three months), in arrears and, in the case of loans bearing interest based on the base rate, quarterly in arrears.

[0001571996-17-000045:notes:94]
The Term Loan A-2 Facility amortizes in equal quarterly installments in aggregate annual amounts equal to 5% of the original principal amount in the first year after the closing date of the refinancing transaction on October 20, 2017, 10% of the original principal amount in each of the second and third years after October 20, 2017, and 70% of the original principal amount in the fourth year after October 20, 2017.  The Term Loan B Facility amortizes in equal quarterly installments in aggregate annual amounts equal to 1% of the original principal amount.  The Term Loan A-3 Facility and the Revolving Credit Facility have no amortization. The Term Loan A-3 Facility requires the borrowers to prepay outstanding borrowings under these facilities with 100% of the net cash proceeds of certain non-ordinary course asset sales or dispositions.  The borrowers may voluntarily repay outstanding loans under the term loan facilities and the Revolving Credit Facility at any time without premium or penalty, other than customary "breakage" costs.

[0001571996-17-000045:notes:95]
All obligations of the borrowers under the Senior Secured Credit Facilities and certain swap agreements, cash management arrangements, and certain letters of credit provided by any lender or agent party to the Senior Secured Credit Facilities or any of its affiliates and certain other persons are secured by (a) a first-priority security interest in certain tangible and intangible assets of the borrowers and the guarantors and (b) a first-priority pledge of 100% of the capital stock of the borrowers, Dell Inc., and each wholly-owned material restricted subsidiary of the borrowers and the guarantors, in each case subject to certain thresholds, exceptions, and permitted liens.

[0001571996-17-000045:notes:96]
China Revolving Credit Facility — On October 31, 2017, the Company entered into a credit agreement (the "China Revolving Credit Facility") with the Bank of China (Hong Kong) Limited for a secured revolving loan facility in an aggregate principal amount not to exceed $500 million.  Borrowings under the China Revolving Credit Facility bear interest at a rate per annum of 0.6% plus LIBOR.  The Company may voluntarily repay outstanding loans under the China Revolving Credit Facility at any time without premium or penalty, other than customary "breakage" costs.  The facility will expire on October 31, 2018.  As of November 3, 2017, there were no outstanding borrowings under the China Revolving Credit Facility.

[0001571996-17-000045:notes:97]
Pivotal Revolving Credit Facility — On September 7, 2017, Pivotal entered into a credit agreement (the "Pivotal Revolving Credit Facility") with Silicon Valley Bank and certain other banks for a senior secured revolving loan facility in an aggregate principal amount not to exceed $100 million.  The credit facility contains customary representations, warranties, and covenants, including financial covenants that require compliance with minimum earnings attainment and liquidity ratios as well as covenants by Pivotal limiting additional indebtedness, liens, guaranties, mergers and consolidations, asset sales, investments and loans, sale and leasebacks, transactions with affiliates and fundamental changes. The credit agreement will expire on September 8, 2020, unless it is terminated by Pivotal or an event of default has occurred prior to such date.  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of Pivotal and Pivotal's subsidiaries.  As of November 3, 2017, there were no outstanding borrowings under the Pivotal Revolving Credit Facility.

[0001571996-17-000045:notes:98]
First Lien Notes — The senior secured notes (collectively, the "First Lien Notes") were issued on June 1, 2016 in an aggregate principal amount of $20.0 billion.  Interest on these borrowings is payable semiannually.  The First Lien Notes are secured, on a pari passu basis with the Senior Secured Credit Facilities, on a first-priority basis by substantially all of the tangible and intangible assets of the issuers and guarantors that secure obligations under the Senior Secured Credit Facilities, including pledges of all capital stock of the issuers, of Dell, and of certain wholly-owned material subsidiaries of the issuers and the guarantors, subject to certain exceptions.

[0001571996-17-000045:notes:99]
The Company has agreed to use commercially reasonable efforts to register with the SEC notes having terms substantially identical to the terms of the First Lien Notes as part of an offer to exchange such registered notes for the First Lien Notes.  The Company will be obligated to pay additional interest on the First Lien Notes if it fails to consummate such an exchange offer within five years after the closing date of the EMC merger transaction.

[0001571996-17-000045:notes:100]
Senior Notes — The senior unsecured notes (collectively, the "Senior Notes") were issued on June 22, 2016 in an aggregate principal amount of $3.25 billion.  Interest on these borrowings is payable semiannually.

[0001571996-17-000045:notes:101]
EMC Notes — On September 7, 2016, EMC had outstanding $2.5 billion aggregate principal amount of its 1.875% Notes due June 2018, $2.0 billion aggregate principal amount of its 2.650% Notes due June 2020, and $1.0 billion aggregate principal amount of its 3.375% Notes due June 2023 (collectively, the "EMC Notes").  Interest on these borrowings is payable semiannually.  The EMC Notes remain outstanding following the closing of the EMC merger transaction.

[0001571996-17-000045:notes:102]
VMware Notes — On August 21, 2017, VMware, Inc. completed a public offering of senior notes in the aggregate amount of $4.0 billion, consisting of outstanding principal due on the following dates: $1.25 billion due August 21, 2020, $1.50 billion due August 21, 2022, and $1.25 billion due August 21, 2027 (collectively, the "VMware Notes"). The VMware Notes bear interest, payable semiannually, at annual rates of 2.30%, 2.95%, and 3.90%, respectively.  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.

[0001571996-17-000045:notes:103]
VMware Revolving Credit Facility —  On September 12, 2017, VMware, Inc. entered into an unsecured credit agreement, establishing a revolving credit facility (the “VMware Revolving Credit Facility”), with a syndicate of lenders that provides the company with a borrowing capacity of up to $1.0 billion which may be used for VMware, Inc. corporate purposes.  Commitments under the VMware Revolving Credit Facility are available for a period of five years, which may be extended, subject to the satisfaction of certain conditions, by up to two one year periods.  As of November 3, 2017, there were no outstanding borrowings under the VMware Revolving Credit Facility.  The credit agreement contains certain representations, warranties, and covenants. Commitment fees, interest rates, and other terms of borrowing under the VMware Revolving Credit Facility may vary based on VMware, Inc.’s external credit ratings.  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.

[0001571996-17-000045:notes:104]
Margin Loan Facility — During the three months ended May 5, 2017, the Company entered into the Margin Loan Facility in an aggregate principal amount of $2.0 billion.  VMW Holdco LLC, a wholly-owned subsidiary of EMC, is the borrower under the Margin Loan Facility, which is secured by 60 million shares of Class B common stock of VMware, Inc. and 20 million shares of Class A common stock of VMware, Inc.  Loans under the Margin Loan Facility bear interest at a rate per annum payable, at the borrower's option, either at (a) a base rate plus 1.25% per annum or (b) a LIBOR-based rate plus 2.25% per annum.  Interest under the Margin Loan Facility is payable quarterly.

[0001571996-17-000045:notes:105]
The Margin Loan Facility will mature in April 2022.  The borrower may voluntarily repay outstanding loans under the Margin Loan Facility at any time without premium or penalty, other than customary "breakage" costs, subject to certain minimum threshold amounts for prepayment.

[0001571996-17-000045:notes:106]
Margin Bridge Facility — On September 7, 2016, Merger Sub and EMC entered into a credit agreement providing for a senior secured margin bridge facility in an aggregate principal amount of $2.5 billion (the "Margin Bridge Facility").

[0001571996-17-000045:notes:107]
During the three months ended May 5, 2017, the Company separately applied the proceeds from the Term Loan B Facility refinancing and the issuance of the Margin Loan Facility to repay the Margin Bridge Facility, without premium or penalty.

[0001571996-17-000045:notes:108]
VMware Note Bridge Facility — On September 7, 2016, Merger Sub and EMC entered into a credit agreement providing for a senior secured note bridge facility in an aggregate principal amount of $1.5 billion (the "VMware Note Bridge Facility").  As described above, the Company repaid the VMware Note Bridge Facility during the three months ended November 3, 2017.

[0001571996-17-000045:notes:109]
Structured Financing Debt — As of November 3, 2017 and February 3, 2017, the Company had $4.3 billion and $3.5 billion, respectively, in outstanding structured financing debt, which was primarily related to the fixed-term lease and loan securitization programs and the revolving loan securitization programs.  See Note 6 and Note 8 of the Notes to the Condensed Consolidated Financial Statements for further discussion of the structured financing debt and the interest rate swap agreements that hedge a portion of that debt.

[0001571996-17-000045:notes:110]
Unsecured Notes and Debentures — The Company has outstanding unsecured notes and debentures (collectively, the "Unsecured Notes and Debentures") that were issued prior to the acquisition of Dell by Dell Technologies Inc.  Interest on these borrowings is payable semiannually.

[0001571996-17-000045:notes:111]
Aggregate Future Maturities — As of November 3, 2017, aggregate future maturities of the Company's debt were as follows:

[0001571996-17-000045:notes:112]
|  | Maturities by Fiscal Year |
|  | 2018 (remaining three months) |  | 2019 |  | 2020 |  | 2021 |  | 2022 |  | Thereafter |  | Total |
|  | (in millions) |
| Structured Financing Debt | $ | 909 |  |  | $ | 2,470 |  |  | $ | 649 |  |  | $ | 254 |  |  | $ | 62 |  |  | $ | 4 |  |  | $ | 4,348 |  |
| Senior Secured Credit Facilities and First Lien Notes | 81 |  |  | 1,765 |  |  | 4,245 |  |  | 371 |  |  | 7,888 |  |  | 16,538 |  |  | 30,888 |  |
| Unsecured Notes and Debentures | — |  |  | 500 |  |  | 600 |  |  | — |  |  | 400 |  |  | 953 |  |  | 2,453 |  |
| Senior Notes and EMC Notes | — |  |  | 2,500 |  |  | — |  |  | 2,000 |  |  | 1,625 |  |  | 2,625 |  |  | 8,750 |  |
| VMware Notes | — |  |  | — |  |  | — |  |  | 1,250 |  |  | — |  |  | 2,750 |  |  | 4,000 |  |
| Margin Loan Facility | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 2,000 |  |  | 2,000 |  |
| Other | 13 |  |  | 10 |  |  | 8 |  |  | 26 |  |  | — |  |  | 26 |  |  | 83 |  |
| Total maturities, principal amount | 1,003 |  |  | 7,245 |  |  | 5,502 |  |  | 3,901 |  |  | 9,975 |  |  | 24,896 |  |  | 52,522 |  |
| Associated carrying value adjustments | (1 | ) |  | (24 | ) |  | (40 | ) |  | (10 | ) |  | (206 | ) |  | (590 | ) |  | (871 | ) |
| Total maturities, carrying value amount | $ | 1,002 |  |  | $ | 7,221 |  |  | $ | 5,462 |  |  | $ | 3,891 |  |  | $ | 9,769 |  |  | $ | 24,306 |  |  | $ | 51,651 |  |

[0001571996-17-000045:notes:113]
Covenants and Unrestricted Net Assets — The credit agreement for the Senior Secured Credit Facilities contain customary negative covenants that generally limit the ability of Denali Intermediate Inc., a wholly-owned subsidiary of Dell Technologies ("Dell Intermediate"), Dell, and Dell's and Denali Intermediate's other restricted subsidiaries to incur debt, create liens, make fundamental changes, enter into asset sales, make certain investments, pay dividends or distribute or redeem certain equity interests, prepay or redeem certain debt, and enter into certain transactions with affiliates.  The indenture governing the Senior Notes contains customary negative covenants that generally limit the ability of Denali Intermediate, Dell, and Dell's and Denali Intermediate's other restricted subsidiaries to incur additional debt or issue certain preferred shares, pay dividends on or make other distributions in respect of capital stock or make other restricted payments, make certain investments, sell or transfer certain assets, create liens on certain assets to secure debt, consolidate, merge, sell, or otherwise dispose of all or substantially all assets, enter into certain transactions with affiliates, and designate subsidiaries as unrestricted subsidiaries.  The negative covenants under such credit agreements and indenture are subject to certain exceptions, qualifications, and "baskets."  The indentures governing the First Lien Notes, the Unsecured Notes and Debentures, and the EMC Notes variously impose limitations, subject to specified exceptions, on creating certain liens, entering into sale and lease-back transactions, and entering into certain asset sales.  As of November 3, 2017, the Company had certain consolidated subsidiaries that were designated as unrestricted subsidiaries for all purposes of the applicable credit agreements and the indentures governing the First Lien Notes and the Senior Notes.  The foregoing credit agreements and indentures contain customary events of default, including failure to make required payments, failure to comply with covenants, and the occurrence of certain events of bankruptcy and insolvency.

[0001571996-17-000045:notes:114]
The Term Loan A-2 Facility, the Term Loan A-3 Facility, and the Revolving Credit Facility are subject to a first lien net leverage ratio covenant that is tested at the end of each fiscal quarter of Dell with respect to Dell's preceding four fiscal quarters.  The Company was in compliance with all financial covenants as of November 3, 2017.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001571996-17-000045:notes:115]
[same as prior period, unchanged from 0001571996-17-000020:notes:108]

[0001571996-17-000045:notes:116]
[same as prior period, unchanged from 0001571996-17-000020:notes:109]

[0001571996-17-000045:notes:117]
[same as prior period, unchanged from 0001571996-17-000020:notes:110]

[0001571996-17-000045:notes:118]
The Company's objective is to offset gains and losses resulting from these exposures with gains and losses on the derivative contracts used to hedge the exposures, thereby reducing volatility of earnings and protecting the fair values of assets and liabilities.  For derivatives designated as cash flow hedges, the Company assesses hedge effectiveness both at the onset of the hedge and at regular intervals throughout the life of the derivative and recognizes any ineffective portion of the hedge in earnings as a component of interest and other, net.  Hedge ineffectiveness recognized in earnings was not material during the three and nine months ended November 3, 2017 and October 28, 2016.

[0001571996-17-000045:notes:119]
[same as prior period, unchanged from 0001571996-17-000020:notes:112]

[0001571996-17-000045:notes:120]
[same as prior period, unchanged from 0001571996-17-000020:notes:113]

[0001571996-17-000045:notes:121]
During the three and nine months ended November 3, 2017 and October 28, 2016, the Company did not discontinue any cash flow hedges related to foreign exchange contracts that had a material impact on the Company's results of operations due to the probability that the forecasted cash flows would not occur.

[0001571996-17-000045:notes:122]
[same as prior period, unchanged from 0001571996-17-000020:notes:115]

[0001571996-17-000045:notes:123]
[same as prior period, unchanged from 0001571996-17-000020:notes:116]

[0001571996-17-000045:notes:124]
[same as prior period, unchanged from 0001571996-17-000020:notes:117]

[0001571996-17-000045:notes:125]
[same as prior period, unchanged from 0001571996-17-000020:notes:118]

[0001571996-17-000045:notes:126]
[same as prior period, unchanged from 0001571996-17-000020:notes:119]

[0001571996-17-000045:notes:127]
[same as prior period, unchanged from 0001571996-17-000020:notes:120]

[0001571996-17-000045:notes:128]
[same as prior period, unchanged from 0001571996-17-000020:notes:121]

[0001571996-17-000045:notes:129]
[same as prior period, unchanged from 0001571996-17-000020:notes:122]

[0001571996-17-000045:notes:130]
|  | November 3, 2017 |  | February 3, 2017 (a) |
|  | (in millions) |
| Foreign exchange contracts: |  |  |  |  |  |
| Designated as cash flow hedging instruments | $ | 4,099 |  |  | $ | 3,781 |  |
| Non-designated as hedging instruments | 5,962 |  |  | 5,146 |  |
| Total | $ | 10,061 |  |  | $ | 8,927 |  |
| Interest rate contracts: |  |  |  |
| Non-designated as hedging instruments | $ | 1,303 |  |  | $ | 1,251 |  |

[0001571996-17-000045:notes:131]
[same as prior period, unchanged from 0001571996-17-000020:notes:124]

[0001571996-17-000045:notes:132]
[same as prior period, unchanged from 0001571996-17-000020:notes:125]

[0001571996-17-000045:notes:133]
| Derivatives inCash FlowHedging Relationships |  | Gain (Loss)Recognizedin AccumulatedOCI, Netof Tax, onDerivatives(Effective Portion) |  | Location of Gain (Loss)Reclassifiedfrom AccumulatedOCI into Income(Effective Portion) |  | Gain (Loss)Reclassifiedfrom AccumulatedOCI into Income(Effective Portion) |  | Location of Gain (Loss) Recognized in Income on Derivative (Ineffective Portion) |  | Gain (Loss) Recognized in Income on Derivative (Ineffective Portion) |
| (in millions) |
| For the three months ended November 3, 2017 |  |  |  |  |  |  |
|  |  |  |  |  | Total net revenue |  | $ | (18 | ) |  |  |  |  |
| Foreign exchange contracts |  | $ | 76 |  |  | Total cost of net revenue |  | (13 | ) |  |  |  |  |
| Interest rate contracts |  | — |  |  | Interest and other, net |  | — |  |  | Interest and other, net |  | $ | — |  |
| Total |  | $ | 76 |  |  |  |  | $ | (31 | ) |  |  |  | $ | — |  |
| For the three months ended October 28, 2016 |  |  |  |  |  |  |
|  |  |  |  |  | Total net revenue |  | $ | 23 |  |  |  |  |  |
| Foreign exchange contracts |  | $ | 82 |  |  | Total cost of net revenue |  | (6 | ) |  |  |  |  |
| Interest rate contracts |  | — |  |  | Interest and other, net |  | — |  |  | Interest and other, net |  | $ | — |  |
| Total |  | $ | 82 |  |  |  |  | $ | 17 |  |  |  |  | $ | — |  |
| For the nine months ended November 3, 2017 |  |  |  |  |  |  |
|  |  |  |  |  | Total net revenue |  | $ | (50 | ) |  |  |  |  |
| Foreign exchange contracts |  | $ | (81 | ) |  | Total cost of net revenue |  | (30 | ) |  |  |  |  |
| Interest rate contracts |  | — |  |  | Interest and other, net |  | — |  |  | Interest and other, net |  | $ | — |  |
| Total |  | $ | (81 | ) |  |  |  | $ | (80 | ) |  |  |  | $ | — |  |
| For the nine months ended October 28, 2016 |  |  |  |  |  |  |
|  |  |  |  |  | Total net revenue |  | $ | (44 | ) |  |  |  |  |
| Foreign exchange contracts |  | $ | (25 | ) |  | Total cost of net revenue |  | (20 | ) |  |  |  |  |
| Interest rate contracts |  | — |  |  | Interest and other, net |  | — |  |  | Interest and other, net |  | $ | — |  |
| Total |  | $ | (25 | ) |  |  |  | $ | (64 | ) |  |  |  | $ | — |  |

[0001571996-17-000045:notes:134]
[same as prior period, unchanged from 0001571996-17-000020:notes:127]

[0001571996-17-000045:notes:135]
[same as prior period, unchanged from 0001571996-17-000020:notes:128]

[0001571996-17-000045:notes:136]
|  | November 3, 2017 |
|  | Other CurrentAssets |  | Other Non-Current Assets |  | Other CurrentLiabilities |  | Other Non-CurrentLiabilities |  | TotalFair Value |
|  |  |  | (in millions) |  |  |
| Derivatives designated as hedging instruments: |
| Foreign exchange contracts in an asset position | $ | 65 |  |  | $ | — |  |  | $ | 20 |  |  | $ | — |  |  | $ | 85 |  |
| Foreign exchange contracts in a liability position | (5 | ) |  | — |  |  | (1 | ) |  | — |  |  | (6 | ) |
| Net asset (liability) | 60 |  |  | — |  |  | 19 |  |  | — |  |  | 79 |  |
| Derivatives not designated as hedging instruments: |
| Foreign exchange contracts in an asset position | 98 |  |  | 1 |  |  | 25 |  |  | — |  |  | 124 |  |
| Foreign exchange contracts in a liability position | (73 | ) |  | — |  |  | (72 | ) |  | — |  |  | (145 | ) |
| Interest rate contracts in an asset position | — |  |  | 5 |  |  | — |  |  | — |  |  | 5 |  |
| Interest rate contracts in a liability position | — |  |  | — |  |  | — |  |  | (2 | ) |  | (2 | ) |
| Net asset (liability) | 25 |  |  | 6 |  |  | (47 | ) |  | (2 | ) |  | (18 | ) |
| Total derivatives at fair value | $ | 85 |  |  | $ | 6 |  |  | $ | (28 | ) |  | $ | (2 | ) |  | $ | 61 |  |
|  | February 3, 2017 |
|  | Other CurrentAssets |  | Other Non-Current Assets |  | Other CurrentLiabilities |  | Other Non-CurrentLiabilities |  | TotalFair Value |
|  |  |  | (in millions) |  |  |
| Derivatives designated as hedging instruments: |
| Foreign exchange contracts in an asset position | $ | 41 |  |  | $ | — |  |  | $ | 17 |  |  | $ | — |  |  | $ | 58 |  |
| Foreign exchange contracts in a liability position | (19 | ) |  | — |  |  | (6 | ) |  | — |  |  | (25 | ) |
| Net asset (liability) | 22 |  |  | — |  |  | 11 |  |  | — |  |  | 33 |  |
| Derivatives not designated as hedging instruments: |
| Foreign exchange contracts in an asset position | 309 |  |  | 2 |  |  | 31 |  |  | — |  |  | 342 |  |
| Foreign exchange contracts in a liability position | (131 | ) |  | — |  |  | (103 | ) |  | — |  |  | (234 | ) |
| Interest rate contracts in an asset position | — |  |  | 3 |  |  | — |  |  | — |  |  | 3 |  |
| Interest rate contracts in a liability position | — |  |  | — |  |  | — |  |  | (3 | ) |  | (3 | ) |
| Net asset (liability) | 178 |  |  | 5 |  |  | (72 | ) |  | (3 | ) |  | 108 |  |
| Total derivatives at fair value | $ | 200 |  |  | $ | 5 |  |  | $ | (61 | ) |  | $ | (3 | ) |  | $ | 141 |  |

[0001571996-17-000045:notes:137]
[same as prior period, unchanged from 0001571996-17-000020:notes:130]

[0001571996-17-000045:notes:138]
|  | November 3, 2017 |
|  | Gross Amounts of Recognized Assets/ (Liabilities) |  | Gross Amounts Offset in the Statement of Financial Position |  | Net Amounts of Assets/ (Liabilities) Presented in the Statement of Financial Position |  | Gross Amounts not Offset in the Statement of Financial Position |  | Net Amount |
|  | Financial Instruments |  | Cash Collateral Received or Pledged |  |
|  | (in millions) |
| Derivative instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Financial assets | $ | 214 |  |  | $ | (123 | ) |  | $ | 91 |  |  | $ | — |  |  | $ | — |  |  | $ | 91 |  |
| Financial liabilities | (153 | ) |  | 123 |  |  | (30 | ) |  | — |  |  | — |  |  | (30 | ) |
| Total derivative instruments | $ | 61 |  |  | $ | — |  |  | $ | 61 |  |  | $ | — |  |  | $ | — |  |  | $ | 61 |  |
|  | February 3, 2017 |
|  | Gross Amounts of Recognized Assets/ (Liabilities) |  | Gross Amounts Offset in the Statement of Financial Position |  | Net Amounts of Assets/ (Liabilities) Presented in the Statement of Financial Position |  | Gross Amounts not Offset in the Statement of Financial Position |  | Net Amount |
|  | Financial Instruments |  | Cash Collateral Received or Pledged |  |
|  | (in millions) |
| Derivative instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Financial assets | $ | 403 |  |  | $ | (198 | ) |  | $ | 205 |  |  | $ | — |  |  | $ | — |  |  | $ | 205 |  |
| Financial liabilities | (262 | ) |  | 198 |  |  | (64 | ) |  | — |  |  | — |  |  | (64 | ) |
| Total derivative instruments | $ | 141 |  |  | $ | — |  |  | $ | 141 |  |  | $ | — |  |  | $ | — |  |  | $ | 141 |  |


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001571996-17-000045:notes:139]
[same as prior period, unchanged from 0001571996-17-000020:notes:132]

[0001571996-17-000045:notes:140]
[same as prior period, unchanged from 0001571996-17-000020:notes:133]

[0001571996-17-000045:notes:141]
In accordance with applicable accounting guidance, the Company reclassified the financial results of Dell Services, DSG, and ECD as discontinued operations in the Condensed Consolidated Statements of Income (Loss) for the relevant periods.  The following two tables present key financial results of Dell Services, DSG, and ECD included in "Income from discontinued operations, net of income taxes" for the three and nine months ended October 28, 2016:

[0001571996-17-000045:notes:142]
|  | Three Months Ended October 28, 2016 |
|  | Dell Services |  | DSG |  | ECD (b) |  | Total |
|  | (in millions) |
| Net revenue | $ | 658 |  |  | $ | 326 |  |  | $ | 74 |  |  | $ | 1,058 |  |
| Cost of net revenue | 523 |  |  | 74 |  |  | 28 |  |  | 625 |  |
| Operating expenses | 116 |  |  | 233 |  |  | 66 |  |  | 415 |  |
| Interest and other, net | — |  |  | (8 | ) |  | — |  |  | (8 | ) |
| Income from discontinued operations before income taxes | 19 |  |  | 11 |  |  | (20 | ) |  | 10 |  |
| Income tax provision (benefit) (a) | (37 | ) |  | 489 |  |  | (4 | ) |  | 448 |  |
| Income (loss) from discontinued operations, net of income taxes | $ | 56 |  |  | $ | (478 | ) |  | $ | (16 | ) |  | $ | (438 | ) |

[0001571996-17-000045:notes:143]
| (a) | The income tax provision (benefit) for Dell Services and DSG for the three months ended October 28, 2016 was primarily due to the Company's determination that it could no longer assert permanent reinvestment in the outside basis of the entities that would be divested. |

[0001571996-17-000045:notes:144]
| (b) | The results for ECD are shown for the period from September 7, 2016 through October 28, 2016. |

[0001571996-17-000045:notes:145]
|  | Nine Months Ended October 28, 2016 |
|  | Dell Services |  | DSG |  | ECD (b) |  | Total |
|  | (in millions) |
| Net revenue | $ | 1,968 |  |  | $ | 968 |  |  | $ | 74 |  |  | $ | 3,010 |  |
| Cost of net revenue | 1,555 |  |  | 249 |  |  | 28 |  |  | 1,832 |  |
| Operating expenses | 322 |  |  | 721 |  |  | 66 |  |  | 1,109 |  |
| Interest and other, net | — |  |  | (1 | ) |  | — |  |  | (1 | ) |
| Income from discontinued operations before income taxes | 91 |  |  | (3 | ) |  | (20 | ) |  | 68 |  |
| Income tax provision (benefit) (a) | (955 | ) |  | 152 |  |  | (4 | ) |  | (807 | ) |
| Income (loss) from discontinued operations, net of income taxes | $ | 1,046 |  |  | $ | (155 | ) |  | $ | (16 | ) |  | $ | 875 |  |

[0001571996-17-000045:notes:146]
| (a) | The income tax provision (benefit) for Dell Services and DSG for the nine months ended October 28, 2016 was primarily due to the Company's determination that it could no longer assert permanent reinvestment in the outside basis of the entities that would be divested. |

[0001571996-17-000045:notes:147]
Cash flows from the Company's discontinued operations are included in the accompanying Condensed Consolidated Statements of Cash Flows.  The significant cash flow items from Dell Services and DSG for the nine months ended October 28, 2016 were as follows:

[0001571996-17-000045:notes:148]
|  | Nine Months Ended October 28, 2016 |
|  | Dell Services |  | DSG |  | Total |
|  | (in millions) |
| Depreciation and amortization (a) | $ | 32 |  |  | $ | 66 |  |  | $ | 98 |  |
| Capital expenditures | $ | 82 |  |  | $ | 20 |  |  | $ | 102 |  |

[0001571996-17-000045:notes:149]
[same as prior period, unchanged from 0001571996-17-000020:notes:140]

[0001571996-17-000045:notes:150]
Depreciation and amortization for ECD ceased upon determination that the held-for-sale criteria were met. Capital expenditures for ECD were immaterial for the period from September 7, 2016 through October 28, 2016.


## us-gaap:EarningsPerShareTextBlock

[0001571996-17-000045:notes:151]
[same as prior period, unchanged from 0001571996-17-000020:notes:141]

[0001571996-17-000045:notes:152]
[same as prior period, unchanged from 0001571996-17-000020:notes:142]

[0001571996-17-000045:notes:153]
The Company has two groups of common stock, denoted as the DHI Group Common Stock and the Class V Common Stock.  The DHI Group Common Stock consists of four classes of common stock, referred to as Class A Common Stock, Class B Common Stock, Class C Common Stock, and Class D Common Stock.  The DHI Group generally refers to the direct and indirect interest of Dell Technologies in all of Dell Technologies' business, assets, properties, liabilities, and preferred stock other than those attributable to the Class V Group, as well as its retained interest in the Class V Group equal to approximately 39% of the Company's economic interest in the Class V Group as of November 3, 2017.  The Class V Common Stock is intended to track the economic performance of approximately 61% of the Company's economic interest in the Class V Group as of such date.  As of November 3, 2017, the Class V Group consisted solely of approximately 331 million shares of VMware, Inc. common stock held by the Company.  See Note 17 of the Notes to the Condensed Consolidated Financial Statements and Exhibit 99.1 to the Company's quarterly report on Form 10-Q for the quarterly period ended November 3, 2017 for more information regarding the allocation of earnings from Dell Technologies' interest in VMware, Inc. between the DHI Group and the Class V Common Stock.

[0001571996-17-000045:notes:154]
[same as prior period, unchanged from 0001571996-17-000020:notes:144]

[0001571996-17-000045:notes:155]
[same as prior period, unchanged from 0001571996-17-000020:notes:145]

[0001571996-17-000045:notes:156]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 3, 2017 |  | October 28, 2016 |  | November 3, 2017 |  | October 28, 2016 |
| Earnings (loss) per share attributable to Dell Technologies Inc. - basic: |  |  |  |  |
| Continuing operations - Class V Common Stock - basic | $ | 1.10 |  |  | $ | 0.79 |  |  | $ | 2.50 |  |  | $ | 0.79 |  |
| Continuing operations - DHI Group - basic | $ | (2.05 | ) |  | $ | (3.62 | ) |  | $ | (6.57 | ) |  | $ | (5.70 | ) |
| Discontinued operations - DHI Group - basic | $ | — |  |  | $ | (0.88 | ) |  | $ | — |  |  | $ | 2.01 |  |
| Earnings (loss) per share attributable to Dell Technologies Inc. - diluted: |  |  |  |  |
| Continuing operations - Class V Common Stock - diluted | $ | 1.09 |  |  | $ | 0.78 |  |  | $ | 2.46 |  |  | $ | 0.78 |  |
| Continuing operations - DHI Group - diluted | $ | (2.05 | ) |  | $ | (3.63 | ) |  | $ | (6.58 | ) |  | $ | (5.70 | ) |
| Discontinued operations - DHI Group - diluted | $ | — |  |  | $ | (0.88 | ) |  | $ | — |  |  | $ | 2.01 |  |

[0001571996-17-000045:notes:157]
[same as prior period, unchanged from 0001571996-17-000020:notes:147]

[0001571996-17-000045:notes:158]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 3, 2017 |  | October 28, 2016 |  | November 3, 2017 |  | October 28, 2016 |
|  | (in millions) |
| Numerator: Continuing operations - Class V Common Stock |  |  |  |  |  |  |  |
| Net income from continuing operations attributable to Class V Common Stock - basic | $ | 223 |  |  | $ | 175 |  |  | $ | 509 |  |  | $ | 175 |  |
| Incremental dilution from VMware, Inc. attributable to Class V Common Stock (a) | (3 | ) |  | (2 | ) |  | (7 | ) |  | (2 | ) |
| Net income from continuing operations attributable to Class V Common Stock - diluted | $ | 220 |  |  | $ | 173 |  |  | $ | 502 |  |  | $ | 173 |  |
| Numerator: Continuing operations - DHI Group |  |  |  |  |  |  |  |
| Net loss from continuing operations attributable to DHI Group - basic | $ | (1,160 | ) |  | $ | (1,801 | ) |  | $ | (3,726 | ) |  | $ | (2,486 | ) |
| Incremental dilution from VMware, Inc. attributable to DHI Group (a) | (3 | ) |  | (1 | ) |  | (5 | ) |  | (1 | ) |
| Net loss from continuing operations attributable to DHI Group - diluted | $ | (1,163 | ) |  | $ | (1,802 | ) |  | $ | (3,731 | ) |  | $ | (2,487 | ) |
| Numerator: Discontinued operations - DHI Group |  |  |  |  |  |  |  |
| Income (loss) from discontinued operations, net of income taxes - basic and diluted | $ | — |  |  | $ | (438 | ) |  | $ | — |  |  | $ | 875 |  |
| Denominator: Class V Common Stock weighted-average shares outstanding |  |  |  |  |  |  |  |  |  |  |  |
| Weighted-average shares outstanding - basic | 202 |  |  | 222 |  |  | 204 |  |  | 222 |  |
| Dilutive effect of options, restricted stock units, restricted stock, and other (b) | — |  |  | — |  |  | — |  |  | — |  |
| Weighted-average shares outstanding - diluted | 202 |  |  | 222 |  |  | 204 |  |  | 222 |  |
| Weighted-average shares outstanding - antidilutive (b) | — |  |  | — |  |  | — |  |  | — |  |
| Denominator: DHI Group weighted-average shares outstanding |  |  |  |  |  |  |  |
| Weighted-average shares outstanding - basic | 567 |  |  | 497 |  |  | 567 |  |  | 436 |  |
| Dilutive effect of options, restricted stock units, restricted stock, and other | — |  |  | — |  |  | — |  |  | — |  |
| Weighted-average shares outstanding - diluted | 567 |  |  | 497 |  |  | 567 |  |  | 436 |  |
| Weighted-average shares outstanding - antidilutive (c) | 34 |  |  | 33 |  |  | 36 |  |  | 30 |  |

[0001571996-17-000045:notes:159]
[same as prior period, unchanged from 0001571996-17-000020:notes:149]

[0001571996-17-000045:notes:160]
[same as prior period, unchanged from 0001571996-17-000020:notes:150]

[0001571996-17-000045:notes:161]
[same as prior period, unchanged from 0001571996-17-000020:notes:151]


## us-gaap:FairValueDisclosuresTextBlock

[0001571996-17-000045:notes:162]
[same as prior period, unchanged from 0001571996-17-000020:notes:152]

[0001571996-17-000045:notes:163]
The following table presents the Company's hierarchy for its assets and liabilities measured at fair value on a recurring basis as of November 3, 2017 and February 3, 2017:

[0001571996-17-000045:notes:164]
|  | November 3, 2017 (a) |  | February 3, 2017 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | QuotedPricesin ActiveMarkets forIdenticalAssets |  | SignificantOtherObservableInputs |  | SignificantUnobservableInputs |  |  |  | QuotedPricesin ActiveMarkets forIdenticalAssets |  | SignificantOtherObservableInputs |  | SignificantUnobservableInputs |  |  |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 7,256 |  |  | $ | — |  |  | $ | — |  |  | $ | 7,256 |  |  | $ | 4,866 |  |  | $ | — |  |  | $ | — |  |  | $ | 4,866 |  |
| Municipal obligations | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 3 |  |  | — |  |  | 3 |  |
| U.S. and foreign corporate debt securities | — |  |  | 89 |  |  | — |  |  | 89 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| U.S. government and agencies | 5 |  |  | — |  |  | — |  |  | 5 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Debt securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government and agencies | 726 |  |  | 400 |  |  | — |  |  | 1,126 |  |  | 444 |  |  | 470 |  |  | — |  |  | 914 |  |
| U.S. corporate | — |  |  | 1,992 |  |  | — |  |  | 1,992 |  |  | — |  |  | 1,800 |  |  | — |  |  | 1,800 |  |
| Foreign | — |  |  | 2,426 |  |  | — |  |  | 2,426 |  |  | — |  |  | 2,083 |  |  | — |  |  | 2,083 |  |
| Municipal obligations | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 352 |  |  | — |  |  | 352 |  |
| Asset-backed securities | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Equity and other securities | 227 |  |  | 3 |  |  | — |  |  | 230 |  |  | 169 |  |  | — |  |  | — |  |  | 169 |  |
| Derivative instruments | — |  |  | 91 |  |  | — |  |  | 91 |  |  | — |  |  | 205 |  |  | — |  |  | 205 |  |
| Total assets | $ | 8,214 |  |  | $ | 5,001 |  |  | $ | — |  |  | $ | 13,215 |  |  | $ | 5,479 |  |  | $ | 4,917 |  |  | $ | — |  |  | $ | 10,396 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative instruments | $ | — |  |  | $ | 30 |  |  | $ | — |  |  | $ | 30 |  |  | $ | — |  |  | $ | 64 |  |  | $ | — |  |  | $ | 64 |  |
| Total liabilities | $ | — |  |  | $ | 30 |  |  | $ | — |  |  | $ | 30 |  |  | $ | — |  |  | $ | 64 |  |  | $ | — |  |  | $ | 64 |  |

[0001571996-17-000045:notes:165]
(a)   The Company did not transfer any securities between levels during the nine months ended November 3, 2017.

[0001571996-17-000045:notes:166]
[same as prior period, unchanged from 0001571996-17-000020:notes:156]

[0001571996-17-000045:notes:167]
Money Market Funds — The Company's investment in money market funds that are classified as cash equivalents hold underlying investments with a weighted average maturity of 90 days or less and are recognized at fair value.  The valuations of these securities are based on quoted prices in active markets for identical assets, when available, or pricing models whereby all significant inputs are observable or can be derived from or corroborated by observable market data.  The Company reviews security pricing and assesses liquidity on a quarterly basis.  As of November 3, 2017, the Company's U.S. portfolio had no material exposure to money market funds with a fluctuating net asset value.

[0001571996-17-000045:notes:168]
[same as prior period, unchanged from 0001571996-17-000020:notes:158]

[0001571996-17-000045:notes:169]
Debt Securities — The majority of the Company's debt securities consists of various fixed income securities such as U.S. government and agencies, U.S. corporate, and foreign.  Valuation is based on pricing models whereby all significant inputs, including benchmark yields, reported trades, broker-dealer quotes, issue spreads, benchmark securities, bids, offers, and other market related data, are observable or can be derived from or corroborated by observable market data for substantially the full term of the asset.  Inputs are documented in accordance with the fair value measurements hierarchy.  The Company reviews security pricing and assesses liquidity on a quarterly basis.  See Note 5 of the Notes to the Condensed Consolidated Financial Statements for additional information about investments.

[0001571996-17-000045:notes:170]
[same as prior period, unchanged from 0001571996-17-000020:notes:160]

[0001571996-17-000045:notes:171]
[same as prior period, unchanged from 0001571996-17-000020:notes:161]

[0001571996-17-000045:notes:172]
As of November 3, 2017 and February 3, 2017, the Company held strategic investments of $507 million and $455 million, respectively.  These investments are accounted for under the cost method and are not included in the recurring fair value table above.  Investments accounted for under the cost method are recorded at cost initially, which approximates fair value.  Subsequently, if there is an indicator of impairment, the impairment is recognized.  In evaluating these investments for impairment, the Company uses inputs including pre- and post-money valuations of recent financing events and the impact of those on its fully diluted ownership percentages, as well as other available information regarding the issuer's historical and forecasted performance.  As these investments are early-stage companies which are not publicly traded, it is not practicable for the Company to reliably estimate the fair value of these investments.

[0001571996-17-000045:notes:173]
[same as prior period, unchanged from 0001571996-17-000020:notes:163]

[0001571996-17-000045:notes:174]
|  | November 3, 2017 |  | February 3, 2017 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Secured Credit Facilities | $ | 10.7 |  |  | $ | 10.9 |  |  | $ | 11.4 |  |  | $ | 11.7 |  |
| First Lien Notes | $ | 19.7 |  |  | $ | 22.2 |  |  | $ | 19.7 |  |  | $ | 21.8 |  |
| Unsecured Notes and Debentures | $ | 2.3 |  |  | $ | 2.5 |  |  | $ | 2.3 |  |  | $ | 2.5 |  |
| Senior Notes | $ | 3.1 |  |  | $ | 3.5 |  |  | $ | 3.1 |  |  | $ | 3.5 |  |
| EMC Notes | $ | 5.5 |  |  | $ | 5.4 |  |  | $ | 5.5 |  |  | $ | 5.4 |  |
| VMware Notes | $ | 4.0 |  |  | $ | 4.0 |  |  | $ | — |  |  | $ | — |  |
| Margin Loan Facility | $ | 2.0 |  |  | $ | 2.0 |  |  | $ | — |  |  | $ | — |  |
| Bridge Facilities | $ | — |  |  | $ | — |  |  | $ | 4.0 |  |  | $ | 4.0 |  |

[0001571996-17-000045:notes:175]
The fair values of the outstanding Senior Secured Credit Facilities, First Lien Notes, Unsecured Notes and Debentures, Senior Notes, EMC Notes, VMware Notes, Margin Loan Facility, and Bridge Facilities were determined based on observable market prices in a less active market or based on valuation methodologies using observable inputs and were categorized as Level 2 in the fair value hierarchy.  The fair values of the other short-term debt and the structured financing debt approximate their carrying values due to their short-term maturities.


## us-gaap:FinancingReceivableCreditQualityIndicatorsTableTextBlock

[0001571996-17-000045:notes:176]
The following table summarizes customer receivables, gross, including accrued interest, by credit quality indicator segregated by class, as of November 3, 2017 and February 3, 2017.  The categories shown in the table below segregate customer receivables based on the relative degrees of credit risk.  The credit quality indicators for DPA revolving accounts are measured primarily as of each quarter-end date, while all other indicators are generally updated on a periodic basis.

[0001571996-17-000045:notes:177]
[same as prior period, unchanged from 0001571996-17-000020:notes:167]

[0001571996-17-000045:notes:178]
|  | November 3, 2017 |  | February 3, 2017 |
|  | Higher |  | Mid |  | Lower |  | Total |  | Higher |  | Mid |  | Lower |  | Total |
|  | (in millions) |
| Revolving — DPA | $ | 126 |  |  | $ | 214 |  |  | $ | 353 |  |  | $ | 693 |  |  | $ | 136 |  |  | $ | 244 |  |  | $ | 428 |  |  | $ | 808 |  |
| Revolving — DBC | $ | 46 |  |  | $ | 54 |  |  | $ | 78 |  |  | $ | 178 |  |  | $ | 61 |  |  | $ | 60 |  |  | $ | 80 |  |  | $ | 201 |  |
| Fixed-term — Consumer and Commercial (a) | $ | 2,843 |  |  | $ | 1,694 |  |  | $ | 1,128 |  |  | $ | 5,665 |  |  | $ | 2,232 |  |  | $ | 1,428 |  |  | $ | 870 |  |  | $ | 4,530 |  |

[0001571996-17-000045:notes:179]
[same as prior period, unchanged from 0001571996-17-000020:notes:169]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001571996-17-000045:notes:180]
[same as prior period, unchanged from 0001571996-17-000020:notes:170]

[0001571996-17-000045:notes:181]
[same as prior period, unchanged from 0001571996-17-000020:notes:171]

[0001571996-17-000045:notes:182]
The following table presents goodwill allocated to the Company's business segments as of November 3, 2017 and February 3, 2017, and changes in the carrying amount of goodwill for the respective periods:

[0001571996-17-000045:notes:183]
|  | Client Solutions Group |  | Infrastructure Solutions Group (a) |  | VMware |  | Other Businesses (b) |  | Total |
|  | (in millions) |
| Balances as of February 3, 2017 | $ | 4,237 |  |  | $ | 15,607 |  |  | $ | 15,070 |  |  | $ | 3,996 |  |  | $ | 38,910 |  |
| Goodwill acquired during the period | — |  |  | — |  |  | 238 |  |  | 9 |  |  | 247 |  |
| Goodwill divested | — |  |  | (13 | ) |  | — |  |  | — |  |  | (13 | ) |
| Impact of foreign currency translation | — |  |  | 155 |  |  | — |  |  | 31 |  |  | 186 |  |
| Balances as of November 3, 2017 | $ | 4,237 |  |  | $ | 15,749 |  |  | $ | 15,308 |  |  | $ | 4,036 |  |  | $ | 39,330 |  |

[0001571996-17-000045:notes:184]
| (a) | Infrastructure Solutions Group is composed of Core Storage, Servers, and Networking, and Virtustream. |

[0001571996-17-000045:notes:185]
(b)  Other Businesses consists of offerings by RSA Information Security, SecureWorks, Pivotal, and Boomi.

[0001571996-17-000045:notes:186]
Goodwill and indefinite-lived intangible assets are tested for impairment annually during the third fiscal quarter and whenever events or circumstances may indicate that an impairment has occurred.  Based on the results of the annual impairment test, which was a quantitative test for certain goodwill reporting units and a qualitative test for others, no impairment of goodwill or indefinite-lived intangible assets existed for any reporting unit as of November 3, 2017.  As a result of this analysis, it was determined that the excess of fair value over carrying amount was greater than 20% for all of the Company's existing goodwill reporting units as of November 3, 2017, with the exception of the Core Storage, Servers and Networking reporting unit within the Infrastructure Solutions Group segment, which had an excess of fair value over carrying amount of 18% as of such date.  Management will continue to monitor the Core Storage, Servers, and Networking goodwill reporting unit and consider potential impacts to the impairment assessment.  Further, the Company did not have any accumulated goodwill impairment charges as of November 3, 2017.

[0001571996-17-000045:notes:187]
Management exercised significant judgment related to the above assessment, including the identification of goodwill reporting units, assignment of assets and liabilities to goodwill reporting units, assignment of goodwill to reporting units, and determination of the fair value of each goodwill reporting unit.  The fair value of each goodwill reporting unit is generally estimated using a combination of public company multiples and discounted cash flow methodologies.  This analysis requires significant judgment, including estimation of future cash flows, which is dependent on internal forecasts, the estimation of the long-term growth rate of the Company's business, and the determination of the Company's weighted average cost of capital.  Changes in these estimates and assumptions could materially affect the fair value of the goodwill reporting unit, potentially resulting in a non-cash impairment charge.

[0001571996-17-000045:notes:188]
[same as prior period, unchanged from 0001571996-17-000020:notes:177]

[0001571996-17-000045:notes:189]
The Company's intangible assets as of November 3, 2017 and February 3, 2017 were as follows:

[0001571996-17-000045:notes:190]
|  | November 3, 2017 |  | February 3, 2017 |
|  | Gross |  | AccumulatedAmortization |  | Net |  | Gross |  | AccumulatedAmortization |  | Net |
|  | (in millions) |
| Customer relationships | $ | 22,714 |  |  | $ | (7,865 | ) |  | $ | 14,849 |  |  | $ | 22,708 |  |  | $ | (5,552 | ) |  | $ | 17,156 |  |
| Developed technology | 15,493 |  |  | (5,287 | ) |  | 10,206 |  |  | 14,569 |  |  | (2,510 | ) |  | 12,059 |  |
| Trade names | 1,270 |  |  | (357 | ) |  | 913 |  |  | 1,268 |  |  | (201 | ) |  | 1,067 |  |
| Leasehold assets (liabilities) | 128 |  |  | (5 | ) |  | 123 |  |  | 128 |  |  | (1 | ) |  | 127 |  |
| Definite-lived intangible assets | 39,605 |  |  | (13,514 | ) |  | 26,091 |  |  | 38,673 |  |  | (8,264 | ) |  | 30,409 |  |
| In-process research and development | — |  |  | — |  |  | — |  |  | 890 |  |  | — |  |  | 890 |  |
| Indefinite-lived trade names | 3,755 |  |  | — |  |  | 3,755 |  |  | 3,754 |  |  | — |  |  | 3,754 |  |
| Total intangible assets | $ | 43,360 |  |  | $ | (13,514 | ) |  | $ | 29,846 |  |  | $ | 43,317 |  |  | $ | (8,264 | ) |  | $ | 35,053 |  |

[0001571996-17-000045:notes:191]
Amortization expense related to definite-lived intangible assets was approximately $1,734 million and $1,164 million during the three months ended November 3, 2017 and October 28, 2016, respectively, and $5,250 million and $2,146 million during the nine months ended November 3, 2017 and October 28, 2016, respectively.  There were no material impairment charges related to intangible assets during the three and nine months ended November 3, 2017 and October 28, 2016.

[0001571996-17-000045:notes:192]
Estimated future annual pre-tax amortization expense of definite-lived intangible assets as of November 3, 2017 over the next five fiscal years and thereafter is as follows:

[0001571996-17-000045:notes:193]
| Fiscal Years | (in millions) |
| 2018 (remaining three months) | $ | 1,730 |  |
| 2019 | 6,059 |  |
| 2020 | 4,274 |  |
| 2021 | 3,333 |  |
| 2022 | 2,616 |  |
| Thereafter | 8,079 |  |
| Total | $ | 26,091 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001571996-17-000045:notes:194]
[same as prior period, unchanged from 0001571996-17-000020:notes:183]

[0001571996-17-000045:notes:195]
For the three and nine months ended November 3, 2017, the Company's effective income tax rates for continuing operations were 22.6% and 31.4%, respectively, on pre-tax losses from continuing operations of $1.2 billion and $4.8 billion, respectively.  For the three and nine months ended October 28, 2016, the Company's effective income tax rates for continuing operations were 29.0% and 21.1%, respectively, on pre-tax losses from continuing operations of $2.3 billion and $2.9 billion, respectively.  The changes in the Company's effective income tax rates for the three and nine months ended November 3, 2017 were primarily attributable to tax benefits from charges incurred associated with the EMC merger transaction, including purchase accounting adjustments, interest charges, and stock-based compensation expense.  For more information regarding the EMC merger transaction, see Note 2 of the Notes to the Condensed Consolidated Financial Statements.  The change in the Company's effective income tax rate for the nine months ended November 3, 2017 was also impacted by tax charges recognized in the prior year during the three and six months ended July 29, 2016 related to the divestitures of Dell Services and DSG.  The income tax rate for the remaining quarter of Fiscal 2018 will be impacted by the actual mix of jurisdictions in which income is generated.

[0001571996-17-000045:notes:196]
[same as prior period, unchanged from 0001571996-17-000020:notes:185]

[0001571996-17-000045:notes:197]
[same as prior period, unchanged from 0001571996-17-000020:notes:186]

[0001571996-17-000045:notes:198]
[same as prior period, unchanged from 0001571996-17-000020:notes:187]

[0001571996-17-000045:notes:199]
Judgment is required in evaluating the Company's uncertain tax positions and determining the Company's provision for income taxes.  The Company's net unrecognized tax benefits were $3.2 billion and $3.1 billion as of November 3, 2017 and February 3, 2017, respectively, and are included in other non-current liabilities in the Condensed Consolidated Statements of Financial Position.  The Company does not anticipate a significant change to the total amount of unrecognized tax benefits within the next twelve months.

[0001571996-17-000045:notes:200]
The Company takes certain non-income tax positions in the jurisdictions in which it operates and has received certain non-income tax assessments from various jurisdictions.  The Company believes that a material loss in these matters is not probable and that it is not reasonably possible that a material loss exceeding amounts already accrued has been incurred.  The Company believes its positions in these non-income tax litigation matters are supportable and that it ultimately will prevail in the matters.  In the normal course of business, the Company's positions and conclusions related to its non-income taxes could be challenged and assessments may be made.  To the extent new information is obtained and the Company's views on its positions, probable outcomes of assessments, or litigation change, changes in estimates to the Company's accrued liabilities would be recorded in the period in which such a determination is made.  In the resolution process for income tax and non-income tax audits, in certain situations the Company will be required to provide collateral guarantees or indemnification to regulators and tax authorities until the matter is resolved.


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0001571996-17-000045:notes:201]
[same as prior period, unchanged from 0001571996-17-000020:notes:190]

[0001571996-17-000045:notes:202]
The Company offers or arranges various financing options and services for its business and consumer customers in North America, Europe, Australia, and New Zealand through Dell Financial Services and its affiliates (collectively, "DFS").  The key activities of DFS include the origination, collection, and servicing of customer receivables primarily related to the purchase of Dell Technologies' products and services.  New financing originations, which represent the amounts of financing provided by DFS to customers for equipment and related software and services, including originations of third-party technology products, were $1.6 billion and $1.1 billion for three months ended November 3, 2017 and October 28, 2016, respectively, and $4.3 billion and $3.0 billion for the nine months ended November 3, 2017 and October 28, 2016, respectively.

[0001571996-17-000045:notes:203]
[same as prior period, unchanged from 0001571996-17-000020:notes:192]

[0001571996-17-000045:notes:204]
[same as prior period, unchanged from 0001571996-17-000020:notes:193]

[0001571996-17-000045:notes:205]
[same as prior period, unchanged from 0001571996-17-000020:notes:194]

[0001571996-17-000045:notes:206]
| • | Fixed-term sales-type leases and loans — The Company enters into sales-type lease arrangements with customers who seek lease financing. Leases with business customers have fixed terms of generally two to four years. Future maturities of minimum lease payments as of November 3, 2017 were as follows: Fiscal 2018 (remaining three months) - $665 million; Fiscal 2019 - $1,755 million; Fiscal 2020 - $1,151 million; Fiscal 2021 - $503 million; Fiscal 2022 and beyond - $148 million. The Company also offers fixed-term loans to qualified small businesses, large commercial accounts, governmental organizations, educational entities, and certain individual consumer customers. These loans are repaid in equal payments including interest and have defined terms of generally three to five years. |

[0001571996-17-000045:notes:207]
The following table summarizes the components of the Company's financing receivables segregated by portfolio segment as of November 3, 2017 and February 3, 2017:

[0001571996-17-000045:notes:208]
|  | November 3, 2017 |  | February 3, 2017 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Financing receivables, net: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer receivables, gross | $ | 871 |  |  | $ | 5,665 |  |  | $ | 6,536 |  |  | $ | 1,009 |  |  | $ | 4,530 |  |  | $ | 5,539 |  |
| Allowances for losses | (79 | ) |  | (52 | ) |  | (131 | ) |  | (91 | ) |  | (52 | ) |  | (143 | ) |
| Customer receivables, net | 792 |  |  | 5,613 |  |  | 6,405 |  |  | 918 |  |  | 4,478 |  |  | 5,396 |  |
| Residual interest | — |  |  | 555 |  |  | 555 |  |  | — |  |  | 477 |  |  | 477 |  |
| Financing receivables, net | $ | 792 |  |  | $ | 6,168 |  |  | $ | 6,960 |  |  | $ | 918 |  |  | $ | 4,955 |  |  | $ | 5,873 |  |
| Short-term | $ | 792 |  |  | $ | 2,851 |  |  | $ | 3,643 |  |  | $ | 918 |  |  | $ | 2,304 |  |  | $ | 3,222 |  |
| Long-term | $ | — |  |  | $ | 3,317 |  |  | $ | 3,317 |  |  | $ | — |  |  | $ | 2,651 |  |  | $ | 2,651 |  |

[0001571996-17-000045:notes:209]
The following table summarizes the aging of the Company's customer financing receivables, gross, including accrued interest, as of November 3, 2017 and February 3, 2017, segregated by class:

[0001571996-17-000045:notes:210]
|  | November 3, 2017 |  | February 3, 2017 |
|  | Current |  | Past Due 1 — 90 Days |  | Past Due > 90 Days |  | Total |  | Current |  | Past Due 1 — 90 Days |  | Past Due > 90 Days |  | Total |
|  | (in millions) |
| Revolving — DPA | $ | 613 |  |  | $ | 57 |  |  | $ | 23 |  |  | $ | 693 |  |  | $ | 715 |  |  | $ | 66 |  |  | $ | 27 |  |  | $ | 808 |  |
| Revolving — DBC | 154 |  |  | 19 |  |  | 5 |  |  | 178 |  |  | 175 |  |  | 22 |  |  | 4 |  |  | 201 |  |
| Fixed-term — Consumer and Commercial | 4,759 |  |  | 809 |  |  | 97 |  |  | 5,665 |  |  | 3,994 |  |  | 506 |  |  | 30 |  |  | 4,530 |  |
| Total customer receivables, gross | $ | 5,526 |  |  | $ | 885 |  |  | $ | 125 |  |  | $ | 6,536 |  |  | $ | 4,884 |  |  | $ | 594 |  |  | $ | 61 |  |  | $ | 5,539 |  |

[0001571996-17-000045:notes:211]
The increase in our fixed-term past due balances is primarily due to administrative processes for larger transactions, in part due to additional originations from the EMC merger transaction, and does not indicate a deterioration in the credit quality of the portfolio.

[0001571996-17-000045:notes:212]
[same as prior period, unchanged from 0001571996-17-000020:notes:200]

[0001571996-17-000045:notes:213]
[same as prior period, unchanged from 0001571996-17-000020:notes:201]

[0001571996-17-000045:notes:214]
The Company maintains programs which facilitate the funding of financing receivables in the capital markets in the United States, Canada, and Europe.  The Company's total structured financing debt, which is collateralized by financing receivables, was $4.3 billion and $3.5 billion as of November 3, 2017 and February 3, 2017, respectively, under the following programs:

[0001571996-17-000045:notes:215]
| • | Securitization Programs — The Company maintains securitization programs in the United States and Europe. The securitization programs in the United States include the fixed-term lease and loan securitization program and the revolving loan securitization program. The outstanding balance of debt under these U.S. programs was $1.0 billion and $1.5 billion as of November 3, 2017 and February 3, 2017, respectively. This debt is collateralized solely by the U.S. financing receivables in the programs. The debt has a variable interest rate and the duration of this debt is based on the terms of the underlying financing receivables. As of November 3, 2017, the total debt capacity related to the U.S. securitization programs was $2.1 billion. The Company enters into interest swap agreements to effectively convert this portion of its structured financing debt from a floating rate to a fixed rate. See Note 8 of the Notes to the Condensed Consolidated Financial Statements for additional information about interest rate swaps. |

[0001571996-17-000045:notes:216]
The Company's U.S. securitization programs became effective on October 29, 2013.  The revolving program, which was extended during the third quarter of Fiscal 2017, is effective through June 10, 2018.  The fixed-term program, which was extended during the second quarter of Fiscal 2018, is effective through June 10, 2018.

[0001571996-17-000045:notes:217]
The Company established a securitization program in Europe for fixed-term leases and loans.  This program is effective through January 13, 2019.  As of November 3, 2017, the outstanding balance of debt under this program was $387 million, and the total debt capacity related to the securitization program was $699 million.

[0001571996-17-000045:notes:218]
The securitization programs contain standard structural features related to the performance of the securitized receivables which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the program, no further funding of receivables will be permitted and the timing of the Company's expected cash flows from over-collateralization will be delayed.  As of November 3, 2017, these criteria were met.

[0001571996-17-000045:notes:219]
| • | Fixed-Term Securitization Programs — The Company periodically issues asset-backed debt securities under fixed-term securitization programs to private investors. As of November 3, 2017 and February 3, 2017, the associated debt balance of these securities was $2.5 billion and $1.4 billion, respectively. The asset-backed debt securities are collateralized solely by the U.S. fixed-term financing receivables in the offerings, which are held by SPEs, as discussed below. The interest rate on these securities is fixed and ranges from 0.42% to 3.61%, and the duration of these securities is based on the terms of the underlying financing receivables. |

[0001571996-17-000045:notes:220]
| • | Other Structured Financing Programs — In connection with the Company's international financing operations, the Company has entered into revolving structured financing debt programs related to its fixed-term lease and loan products sold in Canada and Europe. The aggregate outstanding balances of the Canadian and European revolving structured loans as of November 3, 2017 and February 3, 2017 were $460 million and $382 million, respectively. As of November 3, 2017, the Canadian program, which was extended during the fiscal year ended February 3, 2017, had a total debt capacity of $172 million. This program is effective through April 15, 2018, and is collateralized solely by the Canadian financing receivables. The European program is effective through February 14, 2018. The program is collateralized solely by the European financing receivables and had a total debt capacity of $350 million as of November 3, 2017. |

[0001571996-17-000045:notes:221]
[same as prior period, unchanged from 0001571996-17-000020:notes:209]

[0001571996-17-000045:notes:222]
[same as prior period, unchanged from 0001571996-17-000020:notes:210]

[0001571996-17-000045:notes:223]
[same as prior period, unchanged from 0001571996-17-000020:notes:211]

[0001571996-17-000045:notes:224]
|  | November 3, 2017 |  | February 3, 2017 |
|  | (in millions) |
| Financing receivables held by consolidated VIEs, net: |  |  |  |  |  |
| Short-term, net | $ | 2,552 |  |  | $ | 2,227 |  |
| Long-term, net | 1,896 |  |  | 1,381 |  |
| Financing receivables held by consolidated VIEs, net | $ | 4,448 |  |  | $ | 3,608 |  |

[0001571996-17-000045:notes:225]
Financing receivables transferred via securitization through SPEs were $1.0 billion and $0.6 billion for the three months ended November 3, 2017 and October 28, 2016, respectively, and $2.9 billion and $2.0 billion for the nine months ended November 3, 2017 and October 28, 2016, respectively.

[0001571996-17-000045:notes:226]
Some of the SPEs have entered into financing arrangements with multi-seller conduits that, in turn, issue asset-backed debt securities in the capital markets.  The structured financing debt outstanding, which is collateralized by the financing receivables held by the consolidated VIEs, was $3.9 billion and $3.1 billion as of November 3, 2017 and February 3, 2017, respectively.  The Company's risk of loss related to securitized receivables is limited to the amount by which the Company's right to receive collections for assets securitized exceeds the amount required to pay interest, principal, and fees and expenses related to the asset-backed securities.  The Company provides credit enhancement to the securitization in the form of over-collateralization.

[0001571996-17-000045:notes:227]
[same as prior period, unchanged from 0001571996-17-000020:notes:215]

[0001571996-17-000045:notes:228]
To manage certain concentrations of customer credit exposure, the Company may sell selected fixed-term financing receivables to unrelated third parties on a periodic basis.  The amount of financing receivables sold was $541 million and $200 million for the nine months ended November 3, 2017 and October 28, 2016, respectively.


## us-gaap:MinorityInterestDisclosureTextBlock

[0001571996-17-000045:notes:229]
[same as prior period, unchanged from 0001571996-17-000020:notes:217]

[0001571996-17-000045:notes:230]
VMware, Inc. — The non-controlling interests' share of equity in VMware, Inc. is reflected as a component of the non-controlling interests in the accompanying Condensed Consolidated Statements of Financial Position and was $5.1 billion and $5.2 billion as of November 3, 2017 and February 3, 2017, respectively.  As of November 3, 2017 and February 3, 2017, the Company held approximately 81.9% and 82.5%, respectively, of the outstanding equity interest in VMware, Inc.

[0001571996-17-000045:notes:231]
SecureWorks — On April 27, 2016, SecureWorks completed a registered underwritten IPO of its Class A common stock.  The non-controlling interests' share of equity in SecureWorks is reflected as a component of the non-controlling interests in the accompanying Condensed Consolidated Statements of Financial Position and was $85 million and $86 million as of November 3, 2017 and February 3, 2017, respectively.  As of November 3, 2017 and February 3, 2017, the Company held approximately 87.1% and 87.5%, respectively, of the outstanding equity interest in SecureWorks.

[0001571996-17-000045:notes:232]
Pivotal — A portion of the non-controlling interests in Pivotal is held by third parties in the form of preferred equity instruments.  Due to the terms of such instruments, Pivotal's results of operations and equity activity are not attributable to such interests in Pivotal in the Condensed Consolidated Statements of Income (Loss) and Condensed Consolidated Statements of Financial Position.  The preferred equity instruments are convertible into common shares at the non-controlling owner's election at any time.  The remaining portion of the non-controlling interests in Pivotal is held by third parties in the form of common stock.  Pivotal's results of operations and equity activity are attributable to such interests in Pivotal in the Condensed Consolidated Statements of Income (Loss) and Condensed Consolidated Statements of Financial Position.  The non-controlling interests' share of equity in Pivotal, including both preferred equity instruments and common stock, is reflected as a component of the non-controlling interests in the accompanying Condensed Consolidated Statements of Financial Position and was $481 million and $472 million as of November 3, 2017 and February 3, 2017, respectively.  As of November 3, 2017 and February 3, 2017, the Company held approximately 77.3% and 77.8%, respectively, of the outstanding equity interest in Pivotal.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001571996-17-000045:notes:233]
[same as prior period, unchanged from 0001571996-17-000020:notes:221]

[0001571996-17-000045:notes:234]
[same as prior period, unchanged from 0001571996-17-000020:notes:222]

[0001571996-17-000045:notes:235]
[same as prior period, unchanged from 0001571996-17-000020:notes:223]

[0001571996-17-000045:notes:236]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 3, 2017 |  | October 28, 2016 |  | November 3, 2017 |  | October 28, 2016 |
|  | (in millions) |
| Warranty liability: |  |  |  |  |  |  |  |
| Warranty liability at beginning of period | $ | 588 |  |  | $ | 565 |  |  | $ | 604 |  |  | $ | 574 |  |
| Warranty liability assumed through EMC merger transaction | — |  |  | 125 |  |  | — |  |  | 125 |  |
| Costs accrued for new warranty contracts and changes in estimates for pre-existing warranties (a) (b) | 209 |  |  | 196 |  |  | 672 |  |  | 578 |  |
| Service obligations honored | (239 | ) |  | (248 | ) |  | (718 | ) |  | (639 | ) |
| Warranty liability at end of period | $ | 558 |  |  | $ | 638 |  |  | $ | 558 |  |  | $ | 638 |  |
| Current portion | $ | 371 |  |  | $ | 425 |  |  | $ | 371 |  |  | $ | 425 |  |
| Non-current portion | $ | 187 |  |  | $ | 213 |  |  | $ | 187 |  |  | $ | 213 |  |

[0001571996-17-000045:notes:237]
[same as prior period, unchanged from 0001571996-17-000020:notes:225]

[0001571996-17-000045:notes:238]
[same as prior period, unchanged from 0001571996-17-000020:notes:226]


## us-gaap:ReconciliationOfRevenueFromSegmentsToConsolidatedTextBlock

[0001571996-17-000045:notes:239]
[same as prior period, unchanged from 0001571996-17-000020:notes:227]

[0001571996-17-000045:notes:240]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 3, 2017 |  | October 28, 2016 |  | November 3, 2017 |  | October 28, 2016 |
|  | (in millions) |
| Consolidated net revenue: |  |  |  |  |  |  |  |  |
| Client Solutions Group | $ | 9,959 |  |  | $ | 9,187 |  |  | $ | 28,866 |  |  | $ | 26,978 |  |
| Infrastructure Solutions Group | 7,518 |  |  | 5,989 |  |  | 21,840 |  |  | 13,381 |  |
| VMware | 1,953 |  |  | 1,289 |  |  | 5,596 |  |  | 1,289 |  |
| Reportable segment net revenue | 19,430 |  |  | 16,465 |  |  | 56,302 |  |  | 41,648 |  |
| Other businesses (a) | 475 |  |  | 312 |  |  | 1,409 |  |  | 530 |  |
| Unallocated transactions (b) | — |  |  | — |  |  | (1 | ) |  | 63 |  |
| Impact of purchase accounting (c) | (295 | ) |  | (530 | ) |  | (985 | ) |  | (673 | ) |
| Total net revenue | $ | 19,610 |  |  | $ | 16,247 |  |  | $ | 56,725 |  |  | $ | 41,568 |  |
| Consolidated operating income (loss): |  |  |  |  |  |  |  |
| Client Solutions Group | $ | 672 |  |  | $ | 634 |  |  | $ | 1,612 |  |  | $ | 1,503 |  |
| Infrastructure Solutions Group | 678 |  |  | 897 |  |  | 1,431 |  |  | 1,389 |  |
| VMware | 639 |  |  | 548 |  |  | 1,686 |  |  | 548 |  |
| Reportable segment operating income | 1,989 |  |  | 2,079 |  |  | 4,729 |  |  | 3,440 |  |
| Other businesses (a) | 6 |  |  | (13 | ) |  | 10 |  |  | (48 | ) |
| Unallocated transactions (b) | (9 | ) |  | (91 | ) |  | (4 | ) |  | (122 | ) |
| Impact of purchase accounting (c) | (366 | ) |  | (850 | ) |  | (1,195 | ) |  | (1,054 | ) |
| Amortization of intangibles | (1,734 | ) |  | (1,164 | ) |  | (5,250 | ) |  | (2,146 | ) |
| Transaction-related expenses (d) | (86 | ) |  | (1,200 | ) |  | (415 | ) |  | (1,329 | ) |
| Other corporate expenses (e) | (333 | ) |  | (273 | ) |  | (887 | ) |  | (325 | ) |
| Total operating loss | $ | (533 | ) |  | $ | (1,512 | ) |  | $ | (3,012 | ) |  | $ | (1,584 | ) |

[0001571996-17-000045:notes:241]
[same as prior period, unchanged from 0001571996-17-000020:notes:229]

[0001571996-17-000045:notes:242]
[same as prior period, unchanged from 0001571996-17-000020:notes:230]

[0001571996-17-000045:notes:243]
[same as prior period, unchanged from 0001571996-17-000020:notes:231]

[0001571996-17-000045:notes:244]
[same as prior period, unchanged from 0001571996-17-000020:notes:232]

[0001571996-17-000045:notes:245]
[same as prior period, unchanged from 0001571996-17-000020:notes:233]

[0001571996-17-000045:notes:246]
[same as prior period, unchanged from 0001571996-17-000020:notes:234]


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001571996-17-000045:notes:247]
[same as prior period, unchanged from 0001571996-17-000020:notes:235]

[0001571996-17-000045:notes:248]
[same as prior period, unchanged from 0001571996-17-000020:notes:236]

[0001571996-17-000045:notes:249]
[same as prior period, unchanged from 0001571996-17-000020:notes:237]

[0001571996-17-000045:notes:250]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 3, 2017 |  | October 28, 2016 |  | November 3, 2017 |  | October 28, 2016 |
|  | (in millions) |
| Balance at beginning of period | $ | 186 |  |  | $ | 22 |  |  | $ | 416 |  |  | $ | 26 |  |
| Severance liability assumed through EMC merger transaction | — |  |  | 70 |  |  | — |  |  | 70 |  |
| Severance charges to provision | 41 |  |  | 130 |  |  | 85 |  |  | 156 |  |
| Cash paid and other | (74 | ) |  | (47 | ) |  | (348 | ) |  | (77 | ) |
| Balance at end of period | $ | 153 |  |  | $ | 175 |  |  | $ | 153 |  |  | $ | 175 |  |

[0001571996-17-000045:notes:251]
[same as prior period, unchanged from 0001571996-17-000020:notes:239]

[0001571996-17-000045:notes:252]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 3, 2017 |  | October 28, 2016 |  | November 3, 2017 |  | October 28, 2016 |
|  | (in millions) |
| Severance charges: |  |  |  |  |  |  |  |
| Cost of net revenue | $ | 10 |  |  | $ | 49 |  |  | $ | 14 |  |  | $ | 54 |  |
| Selling, general, and administrative | 7 |  |  | 69 |  |  | 21 |  |  | 82 |  |
| Research and development | 24 |  |  | 12 |  |  | 50 |  |  | 20 |  |
| Total | $ | 41 |  |  | $ | 130 |  |  | $ | 85 |  |  | $ | 156 |  |


## us-gaap:ScheduleOfAmountsRecognizedInBalanceSheetTableTextBlock

[0001571996-17-000045:notes:253]
The following table provides additional information on selected accounts included in the Condensed Consolidated Statements of Financial Position as of November 3, 2017 and February 3, 2017:

[0001571996-17-000045:notes:254]
|  | November 3, 2017 |  | February 3, 2017 |
|  | (in millions) |
| Inventories, net: |  |  |  |
| Production materials | $ | 787 |  |  | $ | 925 |  |
| Work-in-process | 607 |  |  | 503 |  |
| Finished goods | 1,188 |  |  | 1,110 |  |
| Total inventories, net | 2,582 |  |  | 2,538 |  |
| Other non-current liabilities: |  |  |  |
| Warranty liability | 187 |  |  | 199 |  |
| Deferred and other tax liabilities | 6,740 |  |  | 8,607 |  |
| Other | 560 |  |  | 533 |  |
| Total other non-current liabilities | $ | 7,487 |  |  | $ | 9,339 |  |


## us-gaap:ScheduleOfDisposalGroupsIncludingDiscontinuedOperationsIncomeStatementBalanceSheetAndAdditionalDisclosuresTextBlock

[0001571996-17-000045:notes:255]
The following two tables present key financial results of Dell Services, DSG, and ECD included in "Income from discontinued operations, net of income taxes" for the three and nine months ended October 28, 2016:

[0001571996-17-000045:notes:256]
The significant cash flow items from Dell Services and DSG for the nine months ended October 28, 2016 were as follows:


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0001571996-17-000045:notes:257]
[same as prior period, unchanged from 0001571996-17-000020:notes:245]

[0001571996-17-000045:notes:258]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 3, 2017 |  | October 28, 2016 |  | November 3, 2017 |  | October 28, 2016 |
|  | (in millions) |
| Net revenue: |  |  |  |  |  |  |  |  |  |
| Client Solutions Group: |  |  |  |  |  |  |  |
| Commercial | $ | 6,907 |  |  | $ | 6,400 |  |  | $ | 20,453 |  |  | $ | 19,343 |  |
| Consumer | 3,052 |  |  | 2,787 |  |  | 8,413 |  |  | 7,635 |  |
| Total CSG net revenue | 9,959 |  |  | 9,187 |  |  | 28,866 |  |  | 26,978 |  |
| Infrastructure Solutions Group: |  |  |  |  |  |  |  |
| Servers and networking | 3,851 |  |  | 2,910 |  |  | 10,822 |  |  | 9,222 |  |
| Storage | 3,667 |  |  | 3,079 |  |  | 11,018 |  |  | 4,159 |  |
| Total ISG net revenue | 7,518 |  |  | 5,989 |  |  | 21,840 |  |  | 13,381 |  |
| VMware: |  |  |  |  |  |  |  |
| Total VMware net revenue | 1,953 |  |  | 1,289 |  |  | 5,596 |  |  | 1,289 |  |
| Total segment net revenue | $ | 19,430 |  |  | $ | 16,465 |  |  | $ | 56,302 |  |  | $ | 41,648 |  |


## us-gaap:ScheduleOfStockByClassTextBlock

[0001571996-17-000045:notes:259]
The following table presents the repurchase activity with respect to the Class V Common Stock for the nine months ended November 3, 2017, and the attribution of the Class V Group between the Class V Common Stock and the DHI Group's retained interest as of the dates indicated:

[0001571996-17-000045:notes:260]
|  | Class V Common Stock |  | DHI Group Retained Interest |
|  | Shares of Class V Common Stock |  | Interest in Class V Group |  | Retained Interest Shares |  | Interest in Class V Group |
|  | (in millions of shares) |
| As of February 3, 2017 | 209 |  |  | 62 | % |  | 127 |  |  | 38 | % |
| Repurchases of Class V Common Stock | (10 | ) |  |  |  | — |  |  |  |
| As of November 3, 2017 | 199 |  |  | 61 | % |  | 127 |  |  | 39 | % |

[0001571996-17-000045:notes:261]
[same as prior period, unchanged from 0001571996-17-000020:notes:249]

[0001571996-17-000045:notes:262]
|  | Authorized |  | Issued |  | Outstanding |
|  | (in millions of shares) |
| Common stock as of February 3, 2017 |
| Class A | 600 |  |  | 410 |  |  | 410 |  |
| Class B | 200 |  |  | 137 |  |  | 137 |  |
| Class C | 900 |  |  | 22 |  |  | 22 |  |
| Class D | 100 |  |  | — |  |  | — |  |
| Class V | 343 |  |  | 223 |  |  | 209 |  |
|  | 2,143 |  |  | 792 |  |  | 778 |  |
| Common stock as of November 3, 2017 |
| Class A | 600 |  |  | 410 |  |  | 410 |  |
| Class B | 200 |  |  | 137 |  |  | 137 |  |
| Class C | 7,900 |  |  | 24 |  |  | 23 |  |
| Class D | 100 |  |  | — |  |  | — |  |
| Class V | 343 |  |  | 223 |  |  | 199 |  |
|  | 9,143 |  |  | 794 |  |  | 769 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001571996-17-000045:notes:263]
[same as prior period, unchanged from 0001571996-17-000020:notes:251]

[0001571996-17-000045:notes:264]
[same as prior period, unchanged from 0001571996-17-000020:notes:252]

[0001571996-17-000045:notes:265]
CSG includes sales to commercial and consumer customers of desktops, thin client products, and notebooks, as well as services and third-party software and peripherals that are closely tied to the sale of CSG hardware.  ISG includes servers, networking, and storage, as well as services and third-party software and peripherals that are closely tied to the sale of ISG hardware.  VMware includes a broad portfolio of virtualization technologies across three main product groups: software-defined data center; hybrid cloud computing; and end-user computing.

[0001571996-17-000045:notes:266]
[same as prior period, unchanged from 0001571996-17-000020:notes:254]


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001571996-17-000045:notes:267]
[same as prior period, unchanged from 0001571996-17-000020:notes:255]

[0001571996-17-000045:notes:268]
[same as prior period, unchanged from 0001571996-17-000020:notes:256]

[0001571996-17-000045:notes:269]
[same as prior period, unchanged from 0001571996-17-000020:notes:257]

[0001571996-17-000045:notes:270]
[same as prior period, unchanged from 0001571996-17-000020:notes:258]

[0001571996-17-000045:notes:271]
| • | For share-based arrangements that are subject to the occurrence of a contingent event, those amounts are not reclassified to temporary equity until the contingency has been satisfied. |

[0001571996-17-000045:notes:272]
The amount of redeemable shares classified as temporary equity as of November 3, 2017 was $362 million, which consisted of 2.6 million issued and outstanding unrestricted common shares, 0.3 million RSUs, 0.1 million RSAs, and 15.3 million outstanding stock options.  The amount of redeemable shares classified as temporary equity as of February 3, 2017 was $231 million, which consisted of 1.1 million issued and outstanding unrestricted common shares, 0.4 million RSUs, 0.1 million RSAs, and 13.7 million outstanding stock options.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001571996-17-000045:notes:273]
[same as prior period, unchanged from 0001571996-17-000020:notes:261]

[0001571996-17-000045:notes:274]
[same as prior period, unchanged from 0001571996-17-000020:notes:262]

[0001571996-17-000045:notes:275]
Preferred Stock — The Company is authorized to issue one million shares of preferred stock, par value $.01 per share.  As of November 3, 2017, no shares of preferred stock were issued or outstanding.

[0001571996-17-000045:notes:276]
Class V Common Stock and Class V Group — In connection with the EMC merger transaction, the Company authorized 343 million shares of Class V Common Stock.  The Class V Common Stock is a type of common stock commonly referred to as a tracking stock, which is a class of common stock that is intended to track the economic performance of a defined set of assets and liabilities.  As of November 3, 2017, the 199 million shares of outstanding Class V Common Stock were intended to track the economic performance of approximately 61% of Dell Technologies' economic interest in the Class V Group.  The Class V Group as of such date consisted solely of approximately 331 million shares of VMware, Inc. common stock held by the Company.  The remaining 39% economic interest in the Class V Group as of November 3, 2017 was represented by the approximately 127 million retained interest shares held by the DHI Group.  The DHI Group generally refers, in addition to such retained interest, to the direct and indirect interest of Dell Technologies in all of Dell Technologies' business, assets, properties, liabilities, and preferred stock other than those attributable to the Class V Group.

[0001571996-17-000045:notes:277]
[same as prior period, unchanged from 0001571996-17-000020:notes:265]

[0001571996-17-000045:notes:278]
Class V Common Stock Repurchases — On December 13, 2016, the board of directors approved a stock repurchase program (the "Class V Group Repurchase Program") which authorized the Company to use assets of the Class V Group to repurchase up to $500 million of shares of Class V Common Stock over a period of six months.  During the three months ended May 5, 2017, the Company repurchased 1.3 million shares of Class V Common Stock for $82 million pursuant to this initial authorization.  The Company repurchased a total of 8.4 million shares under this program.

[0001571996-17-000045:notes:279]
On March 27, 2017 and August 18, 2017, the board of directors approved two amendments of the Class V Group Repurchase Program (the "March 2017 Class V Group Repurchase Program" and the “August 2017 Class V Group Repurchase Program,” respectively) which, when combined, authorized the Company to use assets of the Class V Group to repurchase up to an additional $600 million of shares of Class V Common Stock over additional six-month periods from the respective board approval dates.  On May 9, 2017, the March 2017 Class V Group Repurchase Program was completed, with the Company having repurchased 4.6 million shares of Class V Common Stock for $300 million.  On October 31, 2017, the August 2017 Class V Group Repurchase Program was completed, with the Company having repurchased 3.8 million shares of Class V Common Stock for $300 million.

[0001571996-17-000045:notes:280]
All shares of Class V Common Stock repurchased by the Company pursuant to the repurchase programs are held as treasury stock at cost.  The repurchase of shares pursuant to the Class V Common Stock repurchase programs was funded from proceeds received by the Class V Group from the sale by a subsidiary of the Company of shares of Class A common stock of VMware, Inc. owned by such subsidiary, as described below under "VMware, Inc. Class A Common Stock Repurchases."  Share repurchases made by VMware, Inc. of its Class A common stock from a subsidiary of the Company do not affect the determination of the respective interests of the Class V Common Stock and the DHI Group in the Class V Group.  See Exhibit 99.1 to the Company's quarterly report on Form 10-Q for the quarterly period ended November 3, 2017 for more information regarding Unaudited Attributed Financial Information for the Class V Group.

[0001571996-17-000045:notes:281]
[same as prior period, unchanged from 0001571996-17-000020:notes:269]

[0001571996-17-000045:notes:282]
In January 2017 and August 2017, VMware, Inc.'s board of directors authorized the repurchase of up to $2.2 billion of shares of VMware, Inc. Class A common stock (the "January 2017 Authorization" for up to $1.2 billion through the end of Fiscal 2018, and the "August 2017 Authorization" for up to $1 billion through August 31, 2018). On March 29, 2017 and August 23, 2017, the Company entered into two new stock purchase agreements with VMware, Inc. (the "March 2017 Stock Purchase Agreement" and the "August 2017 Stock Purchase Agreement," respectively), pursuant to which VMware, Inc. agreed to repurchase for cash a total of $600 million of shares of VMware, Inc. Class A common stock from a subsidiary of the Company.  VMware, Inc. repurchased approximately 6.1 million shares of Class A common stock (consisting of 3.4 million shares pursuant to the March 2017 Stock Purchase Agreement and 2.7 million shares pursuant to the August 2017 Stock Purchase Agreement).  The proceeds from the sales were applied by the Company to the repurchase of shares of the Class V Common Stock under the March 2017 and August 2017 Class V Group Repurchase Programs described above.  As of November 3, 2017, the sale transactions under the March 2017 and August 2017 Stock Purchase Agreements were completed.  The purchase prices of the 3.4 million shares and 2.7 million shares repurchased by VMware, Inc. were each based on separate volume-weighted average per share prices of the Class A common stock as reported on the New York Stock Exchange during separate specified reference periods, less a discount of 3.5% from the respective volume-weighted average per share price.

[0001571996-17-000045:notes:283]
During the three and nine months ended November 3, 2017, VMware, Inc. repurchased 5.1 million shares of Class A common stock in the open market for $555 million.

[0001571996-17-000045:notes:284]
As of November 3, 2017, the cumulative authorized amount remaining for share repurchases by VMware, Inc. was $1,045 million, which represents the $2.2 billion authorized since January 2017, less the cumulative Class A common stock repurchases from the Company of $600 million, and less the cumulative Class A common stock repurchases in the open market of $555 million.


## us-gaap:SubsequentEventsTextBlock

[0001571996-17-000045:notes:285]
SUBSEQUENT EVENTS

[0001571996-17-000045:notes:286]
On November 27, 2017, DFS entered into a credit agreement that provided for borrowings in an aggregate principal amount of $200 million.  The borrowings will accrue interest at a rate per annum of either 3.67%, if denominated in U.S. dollars, or 9.43%, if denominated in Mexican pesos.  The note will mature on December 1, 2020.

[0001571996-17-000045:notes:287]
During November 2017, VMware, Inc. entered into a definitive agreement to acquire VeloCloud Networks, Inc. (“VeloCloud”), a provider of cloud-delivered software-defined wide-area network (SD-WAN) technology for enterprises and service providers.  The acquisition of VeloCloud will enable VMware to build on its network virtualization platform, VMware NSX, and expand its networking portfolio.  The cash payment upon closing of the transaction is estimated to be approximately $470 million; however, the determination of the purchase price is dependent upon several factors at the date of closing and cannot be reasonably estimated until such time.  The transaction is expected to close during the fourth quarter of Fiscal 2018 and is subject to regulatory approvals and customary closing conditions.

[0001571996-17-000045:notes:288]
Other than the matters identified above, there were no known events occurring after the balance sheet date and up until the date of the issuance of this report that would materially affect the information presented herein.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001571996-17-000045:notes:289]
[same as prior period, unchanged from 0001571996-17-000020:notes:278]
