# DELL 8-K — 0001571996-17-000042 filed 2017-12-07

## item codes, every 8-K on or before 2017-12-12

- 2017-12-07 0001571996-17-000042 — 2.02, 9.01
- 2017-10-24 0001571996-17-000037 — 1.01, 2.03, 9.01
- 2017-09-15 0001571996-17-000027 — 5.02
- 2017-09-07 0001571996-17-000017 — 2.02, 9.01
- 2017-08-24 0001571996-17-000014 — 8.01
- 2017-06-29 0001571996-17-000011 — 3.03, 5.07, 8.01, 9.01
- 2017-06-08 0001193125-17-197638 — 2.02, 9.01
- 2017-03-30 0001193125-17-102794 — 8.01
- 2017-03-30 0001193125-17-102777 — 2.02, 9.01
- 2017-03-09 0001193125-17-076981 — 1.01, 2.03, 9.01
- 2017-01-17 0001193125-17-011125 — 8.01
- 2016-12-15 0001193125-16-793722 — 8.01
- 2016-12-08 0001193125-16-787976 — 2.02, 9.01
- 2016-11-10 0001193125-16-765964 — 1.02, 8.01
- 2016-11-04 0001193125-16-760249 — 8.01
- 2016-09-13 0001193125-16-708600 — 3.02
- 2016-09-09 0001193125-16-706567 — 1.01, 1.02, 2.01, 2.03, 3.02, 3.03, 5.02, 9.01
- 2016-09-07 0001193125-16-703370 — 3.03, 5.07, 7.01, 8.01, 9.01
- 2016-09-06 0001193125-16-702057 — 2.02, 9.01
- 2016-08-31 0001193125-16-697268 — 8.01, 9.01
- 2016-08-26 0001193125-16-692921 — 8.01, 9.01
- 2016-07-11 0001193125-16-645610 — 8.01
- 2016-07-05 0001193125-16-641679 — 8.01
- 2016-06-22 0001193125-16-629055 — 1.01, 2.03, 8.01, 9.01
- 2016-06-21 0001193125-16-627071 — 8.01, 9.01
- 2016-06-10 0001193125-16-618483 — 2.02, 9.01
- 2016-06-09 0001193125-16-617893 — 8.01, 9.01

## late-filing notifications on or before 2017-12-12

- none on or before 2017-12-12

## item 2.02 — earnings release, exhibit 99.1

[0001571996-17-000042:8k_2_02:1]
EX-99.1
2
exhibit991earnings8k110317.htm
EXHIBIT 99.1

[0001571996-17-000042:8k_2_02:2]
Exhibit

[0001571996-17-000042:8k_2_02:3]
Exhibit 99.1

[0001571996-17-000042:8k_2_02:4]
Dell Technologies Reports Fiscal Year 2018 Third Quarter

[0001571996-17-000042:8k_2_02:5]
Financial Results

[0001571996-17-000042:8k_2_02:6]
ROUND ROCK, Texas - Dec. 7, 2017

[0001571996-17-000042:8k_2_02:7]
News summary

[0001571996-17-000042:8k_2_02:8]
| • | Third quarter revenue of $19.6 billion, non-GAAP revenue of $19.9 billion |

[0001571996-17-000042:8k_2_02:9]
| • | Cash flow from operations of $1.6 billion |

[0001571996-17-000042:8k_2_02:10]
| • | Company unveils new capabilities and offerings, including new midrange storage solutions and Future-Proof Storage Loyalty Program |

[0001571996-17-000042:8k_2_02:11]
Full story

[0001571996-17-000042:8k_2_02:12]
Dell Technologies (NYSE: DVMT) announces its fiscal 2018 third quarter results. For the third quarter, consolidated revenue was $19.6 billion and non-GAAP revenue was $19.9 billion. During the quarter, the company generated an operating loss of $533 million1, with non-GAAP operating income of $2.0 billion. The company generated cash flow from operations of $1.6 billion.

[0001571996-17-000042:8k_2_02:13]
“In the third fiscal quarter, we delivered solid performance across the business,” said Tom Sweet, chief financial officer, Dell Technologies. “Moving forward, we’ll maintain our focus on profitable growth, generating strong cash flow and delivering a comprehensive and seamless solutions portfolio, incorporating the capabilities of all of the companies under Dell Technologies.”

[0001571996-17-000042:8k_2_02:14]
Fiscal third quarter 2018 results

[0001571996-17-000042:8k_2_02:15]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | November 3, 2017 |  | October 28, 2016 |  | Change |  | November 3, 2017 |  | October 28, 2016 |  | Change |
|  | (in millions, except percentages; unaudited) |
| Net revenue | $ | 19,610 |  |  | $ | 16,247 |  |  | 21% |  | $ | 56,725 |  |  | $ | 41,568 |  |  | 36% |
| Operating loss | $ | (533 | ) |  | $ | (1,512 | ) |  | 65% |  | $ | (3,012 | ) |  | $ | (1,584 | ) |  | (90)% |
| Net loss from continuing operations | $ | (941 | ) |  | $ | (1,637 | ) |  | 43% |  | $ | (3,302 | ) |  | $ | (2,323 | ) |  | (42)% |
| Non-GAAP net revenue | $ | 19,905 |  |  | $ | 16,777 |  |  | 19% |  | $ | 57,710 |  |  | $ | 42,241 |  |  | 37% |
| Non-GAAP operating income | $ | 1,986 |  |  | $ | 1,975 |  |  | 1% |  | $ | 4,735 |  |  | $ | 3,270 |  |  | 45% |
| Non-GAAP net income from continuing operations | $ | 1,109 |  |  | $ | 970 |  |  | 14% |  | $ | 2,563 |  |  | $ | 1,596 |  |  | 61% |
| Adjusted EBITDA | $ | 2,318 |  |  | $ | 2,230 |  |  | 4% |  | $ | 5,751 |  |  | $ | 3,757 |  |  | 53% |

[0001571996-17-000042:8k_2_02:16]
Information about Dell Technologies' use of non-GAAP financial information is provided under "Non-GAAP Financial Measures" below. All comparisons in this press release are year over year unless otherwise noted.

[0001571996-17-000042:8k_2_02:17]
“Our strategy to be the essential infrastructure provider is resonating with our customers, who turn to Dell Technologies to transform and digitize their environments,” said Jeff Clarke, vice-chairman, Products & Operations, Dell Technologies. “We deliver a more holistic view and set of solutions, offering a higher level of innovation and integration across the edge, core and cloud that is unmatched in the industry.”

[0001571996-17-000042:8k_2_02:18]
Operating segments summary

[0001571996-17-000042:8k_2_02:19]
Client Solutions Group (Dell) continued to outperform the market worldwide as the overall PC market moved back to positive year-over-year growth during the calendar quarter. Revenue for the third fiscal quarter was $10.0 billion, up 8 percent from the same quarter of fiscal 2017. Operating income was $672 million, a 6 percent increase.

[0001571996-17-000042:8k_2_02:20]
Key highlights:

[0001571996-17-000042:8k_2_02:21]
| • | Double-digit revenue growth in notebooks for both commercial and consumer |

[0001571996-17-000042:8k_2_02:22]
| • | Delivered 19th consecutive quarter of year-over-year PC unit share growth2 |

[0001571996-17-000042:8k_2_02:23]
| • | No. 1 workstation vendor worldwide, outperforming the industry and positive growth in every major region3 |

[0001571996-17-000042:8k_2_02:24]
| • | No. 1 displays provider worldwide for the 17th consecutive quarter4 |

[0001571996-17-000042:8k_2_02:25]
Infrastructure Solutions Group (Dell EMC) experienced growth of 2 percent quarter over quarter, with third quarter revenue of $7.5 billion and operating income of $678 million. Servers and networking revenue was $3.9 billion, which was an increase of 32 percent year over year and 3 percent quarter over quarter. Storage revenue remained flat at $3.7 billion quarter over quarter.

[0001571996-17-000042:8k_2_02:26]
Key highlights:

[0001571996-17-000042:8k_2_02:27]
| • | Record revenue and double-digit growth for servers for 2nd consecutive quarter |

[0001571996-17-000042:8k_2_02:28]
| • | Worldwide leader in servers, outgrowing the market in units and revenue for both mainstream and hyperscale5 |

[0001571996-17-000042:8k_2_02:29]
| • | Triple-digit growth in hyperconverged portfolio, led by VxRail |

[0001571996-17-000042:8k_2_02:30]
| • | Double-digit demand growth for Isilon scale-out NAS and all-flash arrays |

[0001571996-17-000042:8k_2_02:31]
VMware segment revenue for the third quarter was $2.0 billion, with operating income of $639 million, or 32.7 percent of revenue.

[0001571996-17-000042:8k_2_02:32]
Additional highlights

[0001571996-17-000042:8k_2_02:33]
During the third quarter, Dell Technologies paid down $1.7 billion in debt, and since the close of the EMC transaction, it has paid down $9.7 billion of gross debt, excluding DFS-related debt. Also since closing the EMC transaction, the company has repurchased a total of 23.4 million shares of Class V common stock under the previously announced repurchase programs. The company ended the quarter with a cash and investments balance of $18.0 billion.

[0001571996-17-000042:8k_2_02:34]
During the quarter, Dell Technologies launched a dedicated Internet of Things (IoT) division aimed at coordinating development of IoT products and services across all of our businesses. This comprehensive approach includes IoT-specific products, labs, partner program and consumption models to help customers speed the implementation of their IoT solutions.

[0001571996-17-000042:8k_2_02:35]
Subsequent to the end of the quarter, Dell EMC announced the expansion of its industry-leading midrange storage portfolio with two new SC All-Flash data storage arrays, along with key software updates to Dell EMC Unity designed to boost efficiency and cost savings for mixed block and file workloads. Additionally, Dell EMC launched its new Future-Proof Storage Loyalty Program to help customers protect their investment.

[0001571996-17-000042:8k_2_02:36]
Conference call information

[0001571996-17-000042:8k_2_02:37]
As previously announced, the company will hold a conference call to discuss its third quarter performance this morning at 7 a.m. CST. The conference call will be broadcast live over the internet and can be accessed at investors.delltechnologies.com. For those unable to listen to the live broadcast, an archived version will be available at the same location for one year.

[0001571996-17-000042:8k_2_02:38]
A slide presentation containing additional financial and operating information may be downloaded from Dell Technologies' website at investors.delltechnologies.com.

[0001571996-17-000042:8k_2_02:39]
Additional resources

[0001571996-17-000042:8k_2_02:40]
| • | Find out more about how Dell Technologies is collaboratively solving customers’ biggest challenges by visiting our Annual Report to Customers |

[0001571996-17-000042:8k_2_02:41]
| • | Follow the latest news on Twitter from @DellTech |

[0001571996-17-000042:8k_2_02:42]
About Dell Technologies

[0001571996-17-000042:8k_2_02:43]
Dell Technologies is a unique family of businesses that provides the essential infrastructure for organizations to build their digital future, transform IT and protect their most important asset, information. The company services customers of all sizes across 180 countries - ranging from 98 percent of the Fortune 500 to individual consumers - with the industry's most comprehensive and innovative portfolio from the edge to the core to the cloud.

[0001571996-17-000042:8k_2_02:44]
MEDIA CONTACTS:

[0001571996-17-000042:8k_2_02:45]
Dave Farmer

[0001571996-17-000042:8k_2_02:46]
(508) 293-7206

[0001571996-17-000042:8k_2_02:47]
dave.farmer@dell.com

[0001571996-17-000042:8k_2_02:48]
Lauren Lee

[0001571996-17-000042:8k_2_02:49]
(512) 728-4374

[0001571996-17-000042:8k_2_02:50]
lauren.lee@dell.com

[0001571996-17-000042:8k_2_02:51]
INVESTOR RELATIONS CONTACTS:

[0001571996-17-000042:8k_2_02:52]
Karen Litzler-Hollier

[0001571996-17-000042:8k_2_02:53]
(512) 728-0388

[0001571996-17-000042:8k_2_02:54]
karen.litzler-hollie@dell.com

[0001571996-17-000042:8k_2_02:55]
Hall Butler

[0001571996-17-000042:8k_2_02:56]
(512) 723-4963

[0001571996-17-000042:8k_2_02:57]
hall.butler@dell.com

[0001571996-17-000042:8k_2_02:58]
# # #

[0001571996-17-000042:8k_2_02:59]
Copyright © 2017 Dell Inc. or its subsidiaries. All Rights Reserved. Dell, Dell Inc. and the Dell logo are trademarks of Dell Technologies in the United States and/or other jurisdictions. All other marks and names mentioned herein may be trademarks of their respective companies.

[0001571996-17-000042:8k_2_02:60]
1 Due to the EMC transaction and to a lesser extent the Dell going-private transaction, significant non-cash bridging items will remain between GAAP and non-GAAP results for the next few years. As a result of the EMC merger transaction completed on September 7, 2016 and its impact on the third quarter and first nine months of Fiscal 2018, our results for the fiscal periods discussed herein are not directly comparable.

[0001571996-17-000042:8k_2_02:61]
2 IDC WW Quarterly Personal Computing Device (PCD) Tracker CY17Q3

[0001571996-17-000042:8k_2_02:62]
3 IDC WW Quarterly Workstation Tracker CY17Q3

[0001571996-17-000042:8k_2_02:63]
4 DisplaySearch Desktop Monitor Market Tracker CY17Q2

[0001571996-17-000042:8k_2_02:64]
5 IDC WW Quarterly Server Tracker CY17Q3

[0001571996-17-000042:8k_2_02:65]
Non-GAAP Financial Measures:

[0001571996-17-000042:8k_2_02:66]
This press release presents information about the Company's non-GAAP net revenue, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income from continuing operations, EBITDA and adjusted EBITDA, which are non-GAAP financial measures provided as a supplement to the results provided in accordance with generally accepted accounting principles in the United States of America ("GAAP"). A reconciliation of each of the foregoing historical non-GAAP financial measures to the most directly comparable historical GAAP financial measures is provided in the attached tables for each of the fiscal periods indicated.

[0001571996-17-000042:8k_2_02:67]
Special Note on Forward-Looking Statements:

[0001571996-17-000042:8k_2_02:68]
"plan," "project," "possible," "potential," "should," "will" and "would," or similar words or expressions that refer to future events or outcomes.

[0001571996-17-000042:8k_2_02:69]
Dell Technologies' results or events in future periods could differ materially from those expressed or implied by these forward-looking statements because of risks, uncertainties, and other factors that include, but are not limited to, the following: competitive pressures; Dell Technologies' reliance on third-party suppliers for products and components, including reliance on single-source or limited-source suppliers; Dell Technologies' ability to achieve favorable pricing from its vendors; adverse global economic conditions and instability in financial markets; Dell Technologies' execution of its growth, business and acquisition strategies; the success of Dell Technologies' cost efficiency measures; Dell Technologies' ability to manage solutions and products and services transitions in an effective manner; Dell Technologies' ability to deliver high-quality products and services; Dell Technologies' foreign operations and ability to generate substantial non-U.S.net revenue; Dell Technologies' product, customer, and geographic sales mix, and seasonal sales trends; the performance of Dell Technologies' sales channel partners; access to the capital markets by Dell Technologies or its customers; weak economic conditions and additional regulation; counterparty default risks; the loss by Dell Technologies of any services contracts with its customers, including government contracts, and its ability to perform such contracts at its estimated costs; Dell Technologies' ability to develop and protect its proprietary intellectual property or obtain licenses to intellectual property developed by others on commercially reasonable and competitive terms; infrastructure disruptions, cyberattacks, or other data security breaches; Dell Technologies' ability to hedge effectively its exposure to fluctuations in foreign currency exchange rates and interest rates; expiration of tax holidays or favorable tax rate structures, or unfavorable outcomes in tax audits and other tax compliance matters; impairment of portfolio investments; unfavorable results of legal proceedings; increased costs and additional regulations and requirements as a result of Dell Technologies operation as a public company; Dell Technologies' ability to develop and maintain effective internal control over financial reporting; compliance requirements of changing environmental and safety laws; the effect of armed hostilities, terrorism, natural disasters, and public health issues; the costs, time, and effort required to be dedicated to the integration of the Dell and EMC businesses; the ability to realize the anticipated synergies from the merger with EMC; the ability to integrate EMC's technology, solutions, products, and services with those of Dell in an effective manner; the impact of the financial performance of VMware; and the market volatility of Dell Technologies' pension plan assets.

[0001571996-17-000042:8k_2_02:70]
This list of risks, uncertainties, and other factors is not complete. Dell Technologies discusses some of these matters more fully, as well as certain risk factors that could affect the Dell Technologies' business, financial condition, results of operations, and prospects, in its reports filed with the Securities and Exchange Commission, including Dell Technologies' Annual Report on Form 10-K for the fiscal year ended February 3, 2017, quarterly reports on Form 10-Q, and current reports on Form 8-K. These filings are available for review through the Securities and Exchange Commission's website at www.sec.gov. Any or all forward-looking statements Dell Technologies makes may turn out to be wrong and can be affected by inaccurate assumptions Dell Technologies might make or by known or unknown risks, uncertainties and other factors, including those identified in this press release. Accordingly, you should not place undue reliance on the forward-looking statements made in this press release, which speak only as of its date. Dell Technologies does not undertake to update, and expressly disclaims any duty to update, its forward-looking statements, whether as a result of circumstances or events that arise after the date they are made, new information, or otherwise.

[0001571996-17-000042:8k_2_02:71]
DELL TECHNOLOGIES INC.

[0001571996-17-000042:8k_2_02:72]
Condensed Consolidated Statements of Income (Loss) and Related Financial Highlights

[0001571996-17-000042:8k_2_02:73]
(in millions, except per share amounts and percentages; unaudited; continued on next page)

[0001571996-17-000042:8k_2_02:74]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | November 3, 2017 |  | October 28, 2016 |  | Change |  | November 3, 2017 |  | October 28, 2016 |  | Change |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Products | $ | 14,680 |  |  | $ | 12,366 |  |  | 19% |  | $ | 42,003 |  |  | $ | 33,510 |  |  | 25% |
| Services | 4,930 |  |  | 3,881 |  |  | 27% |  | 14,722 |  |  | 8,058 |  |  | 83% |
| Total net revenue | 19,610 |  |  | 16,247 |  |  | 21% |  | 56,725 |  |  | 41,568 |  |  | 36% |
| Cost of net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Products | 12,369 |  |  | 10,562 |  |  | 17% |  | 36,206 |  |  | 28,856 |  |  | 25% |
| Services | 2,078 |  |  | 1,786 |  |  | 16% |  | 6,245 |  |  | 4,284 |  |  | 46% |
| Total cost of net revenue | 14,447 |  |  | 12,348 |  |  | 17% |  | 42,451 |  |  | 33,140 |  |  | 28% |
| Gross margin | 5,163 |  |  | 3,899 |  |  | 32% |  | 14,274 |  |  | 8,428 |  |  | 69% |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative | 4,625 |  |  | 4,556 |  |  | 2% |  | 13,989 |  |  | 8,647 |  |  | 62% |
| Research and development | 1,071 |  |  | 855 |  |  | 25% |  | 3,297 |  |  | 1,365 |  |  | 142% |
| Total operating expenses | 5,696 |  |  | 5,411 |  |  | 5% |  | 17,286 |  |  | 10,012 |  |  | 73% |
| Operating loss | (533 | ) |  | (1,512 | ) |  | 65% |  | (3,012 | ) |  | (1,584 | ) |  | (90)% |
| Interest and other, net | (682 | ) |  | (794 | ) |  | 14% |  | (1,800 | ) |  | (1,362 | ) |  | (32)% |
| Loss from continuing operations before income taxes | (1,215 | ) |  | (2,306 | ) |  | 47% |  | (4,812 | ) |  | (2,946 | ) |  | (63)% |
| Income tax benefit | (274 | ) |  | (669 | ) |  | 59% |  | (1,510 | ) |  | (623 | ) |  | (142)% |
| Net loss from continuing operations | (941 | ) |  | (1,637 | ) |  | 43% |  | (3,302 | ) |  | (2,323 | ) |  | (42)% |
| Income (loss) from discontinued operations, net of income taxes | — |  |  | (438 | ) |  | 100% |  | — |  |  | 875 |  |  | (100)% |
| Net loss | (941 | ) |  | (2,075 | ) |  | 55% |  | (3,302 | ) |  | (1,448 | ) |  | (128)% |
| Less: Net loss attributable to non-controlling interests | (4 | ) |  | (11 | ) |  | 64% |  | (85 | ) |  | (12 | ) |  | (608)% |
| Net loss attributable to Dell Technologies Inc. | $ | (937 | ) |  | $ | (2,064 | ) |  | 55% |  | $ | (3,217 | ) |  | $ | (1,436 | ) |  | (124)% |

[0001571996-17-000042:8k_2_02:75]
DELL TECHNOLOGIES INC.

[0001571996-17-000042:8k_2_02:76]
Condensed Consolidated Statements of Income (Loss) and Related Financial Highlights

[0001571996-17-000042:8k_2_02:77]
(in millions, except per share amounts and percentages; unaudited; continued)

[0001571996-17-000042:8k_2_02:78]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | November 3, 2017 |  | October 28, 2016 |  |  |  | November 3, 2017 |  | October 28, 2016 |  |  |
| Earnings (loss) per share attributable to Dell Technologies Inc. - basic: |  |  |  |  |  |  |  |  |  |  |  |
| Continuing operations - Class V Common Stock - basic | $ | 1.10 |  |  | $ | 0.79 |  |  |  |  | $ | 2.50 |  |  | $ | 0.79 |  |  |  |
| Continuing operations - DHI Group - basic | $ | (2.05 | ) |  | $ | (3.62 | ) |  |  |  | $ | (6.57 | ) |  | $ | (5.70 | ) |  |  |
| Discontinued operations - DHI Group - basic | $ | — |  |  | $ | (0.88 | ) |  |  |  | $ | — |  |  | $ | 2.01 |  |  |  |
| Earnings (loss) per share attributable to Dell Technologies Inc. - diluted: |  |  |  |  |  |  |  |  |  |  |  |
| Continuing operations - Class V Common Stock - diluted | $ | 1.09 |  |  | $ | 0.78 |  |  |  |  | $ | 2.46 |  |  | $ | 0.78 |  |  |  |
| Continuing operations - DHI Group - diluted | $ | (2.05 | ) |  | $ | (3.63 | ) |  |  |  | $ | (6.58 | ) |  | $ | (5.70 | ) |  |  |
| Discontinued operations - DHI Group - diluted | $ | — |  |  | $ | (0.88 | ) |  |  |  | $ | — |  |  | $ | 2.01 |  |  |  |
| Weighted-average shares outstanding: |  |  |  |  |  |  |  |  |  |  |  |
| Basic - Class V Common Stock | 202 |  |  | 222 |  |  |  |  | 204 |  |  | 222 |  |  |  |
| Diluted - Class V Common Stock | 202 |  |  | 222 |  |  |  |  | 204 |  |  | 222 |  |  |  |
| Basic - DHI Group | 567 |  |  | 497 |  |  |  |  | 567 |  |  | 436 |  |  |  |
| Diluted - DHI Group | 567 |  |  | 497 |  |  |  |  | 567 |  |  | 436 |  |  |  |
| Percentage of Total Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Gross margin | 26 | % |  | 24 | % |  |  |  | 25 | % |  | 20 | % |  |  |
| Selling, general, and administrative | 24 | % |  | 28 | % |  |  |  | 25 | % |  | 21 | % |  |  |
| Research and development | 5 | % |  | 5 | % |  |  |  | 6 | % |  | 3 | % |  |  |
| Operating expenses | 29 | % |  | 33 | % |  |  |  | 30 | % |  | 24 | % |  |  |
| Operating loss | (3 | )% |  | (9 | )% |  |  |  | (5 | )% |  | (4 | )% |  |  |
| Loss from continuing operations before income taxes | (6 | )% |  | (14 | )% |  |  |  | (8 | )% |  | (7 | )% |  |  |
| Net loss from continuing operations | (5 | )% |  | (10 | )% |  |  |  | (6 | )% |  | (6 | )% |  |  |
| Income tax rate | 23 | % |  | 29 | % |  |  |  | 31 | % |  | 21 | % |  |  |

[0001571996-17-000042:8k_2_02:79]
DELL TECHNOLOGIES INC.

[0001571996-17-000042:8k_2_02:80]
Condensed Consolidated Statements of Financial Position

[0001571996-17-000042:8k_2_02:81]
(in millions; unaudited)

[0001571996-17-000042:8k_2_02:82]
|  | November 3, 2017 |  | February 3, 2017 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 11,706 |  |  | $ | 9,474 |  |
| Short-term investments | 2,008 |  |  | 1,975 |  |
| Accounts receivable, net | 9,189 |  |  | 9,420 |  |
| Short-term financing receivables, net | 3,643 |  |  | 3,222 |  |
| Inventories, net | 2,582 |  |  | 2,538 |  |
| Other current assets | 5,397 |  |  | 4,144 |  |
| Total current assets | 34,525 |  |  | 30,773 |  |
| Property, plant, and equipment, net | 5,378 |  |  | 5,653 |  |
| Long-term investments | 4,273 |  |  | 3,802 |  |
| Long-term financing receivables, net | 3,317 |  |  | 2,651 |  |
| Goodwill | 39,330 |  |  | 38,910 |  |
| Intangible assets, net | 29,846 |  |  | 35,053 |  |
| Other non-current assets | 1,725 |  |  | 1,364 |  |
| Total assets | $ | 118,394 |  |  | $ | 118,206 |  |
| LIABILITIES, REDEEMABLE SHARES, AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Short-term debt | $ | 6,235 |  |  | $ | 6,329 |  |
| Accounts payable | 16,711 |  |  | 14,422 |  |
| Accrued and other | 6,901 |  |  | 7,119 |  |
| Short-term deferred revenue | 10,895 |  |  | 10,265 |  |
| Total current liabilities | 40,742 |  |  | 38,135 |  |
| Long-term debt | 45,416 |  |  | 43,061 |  |
| Long-term deferred revenue | 9,161 |  |  | 8,431 |  |
| Other non-current liabilities | 7,487 |  |  | 9,339 |  |
| Total liabilities | 102,806 |  |  | 98,966 |  |
| Redeemable shares | 362 |  |  | 231 |  |
| Stockholders' equity: |  |  |  |
| Total Dell Technologies Inc. stockholders’ equity | 9,519 |  |  | 13,243 |  |
| Non-controlling interests | 5,707 |  |  | 5,766 |  |
| Total stockholders' equity | 15,226 |  |  | 19,009 |  |
| Total liabilities, redeemable shares, and stockholders' equity | $ | 118,394 |  |  | $ | 118,206 |  |

[0001571996-17-000042:8k_2_02:83]
DELL TECHNOLOGIES INC.

[0001571996-17-000042:8k_2_02:84]
Condensed Consolidated Statements of Cash Flows

[0001571996-17-000042:8k_2_02:85]
(in millions; unaudited)

[0001571996-17-000042:8k_2_02:86]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 3, 2017 |  | October 28, 2016 |  | November 3, 2017 |  | October 28, 2016 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |
| Net loss | $ | (941 | ) |  | $ | (2,075 | ) |  | $ | (3,302 | ) |  | $ | (1,448 | ) |
| Adjustments to reconcile net loss to net cash provided by operating activities | 2,564 |  |  | 1,829 |  |  | 6,981 |  |  | 3,017 |  |
| Change in cash from operating activities | 1,623 |  |  | (246 | ) |  | 3,679 |  |  | 1,569 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |
| Investments: |  |  |  |  |  |  |  |
| Purchases | (1,194 | ) |  | (503 | ) |  | (3,454 | ) |  | (511 | ) |
| Maturities and sales | 935 |  |  | 543 |  |  | 2,993 |  |  | 561 |  |
| Capital expenditures | (341 | ) |  | (182 | ) |  | (902 | ) |  | (417 | ) |
| Proceeds from sale of facilities, land, and other assets | — |  |  | 5 |  |  | — |  |  | 24 |  |
| Capitalized software development costs | (94 | ) |  | (85 | ) |  | (281 | ) |  | (85 | ) |
| Collections on purchased financing receivables | 15 |  |  | 6 |  |  | 25 |  |  | 31 |  |
| Acquisition of businesses, net | — |  |  | (37,614 | ) |  | (223 | ) |  | (37,614 | ) |
| Divestitures of businesses, net | — |  |  | — |  |  | — |  |  | — |  |
| Asset acquisitions, net | (9 | ) |  | — |  |  | (95 | ) |  | — |  |
| Asset dispositions, net | (12 | ) |  | — |  |  | (53 | ) |  | — |  |
| Other | — |  |  | (8 | ) |  | — |  |  | (48 | ) |
| Change in cash from investing activities | (700 | ) |  | (37,838 | ) |  | (1,990 | ) |  | (38,059 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |
| Payment of dissenting shares obligation | — |  |  | — |  |  | — |  |  | (446 | ) |
| Proceeds from the issuance of DHI Group Common Stock | — |  |  | 4,404 |  |  |  |  | 4,404 |  |
| Proceeds from the issuance of common stock of subsidiaries | 30 |  |  | 1 |  |  | 110 |  |  | 101 |  |
| Repurchases of DHI Group Common Stock | (4 | ) |  | (8 | ) |  | (6 | ) |  | (10 | ) |
| Repurchases of Class V Common Stock | (300 | ) |  | (132 | ) |  | (722 | ) |  | (132 | ) |
| Repurchases of common stock of subsidiaries | (555 | ) |  | (611 | ) |  |  |  | (611 | ) |
| Issuance of common stock under employee plans | — |  |  | — |  |  | 1 |  |  | — |  |
| Payments for debt issuance costs | (39 | ) |  | (834 | ) |  | (44 | ) |  | (849 | ) |
| Proceeds from debt | 8,416 |  |  | 43,838 |  |  | 13,192 |  |  | 45,986 |  |
| Repayments of debt | (5,872 | ) |  | (7,000 | ) |  | (11,181 | ) |  | (9,638 | ) |
| Share repurchases for tax withholdings on vesting of equity awards | (105 | ) |  | (26 | ) |  | (299 | ) |  | (28 | ) |
| Other | — |  |  | 4 |  |  | — |  |  | 10 |  |
| Change in cash from financing activities | 1,571 |  |  | 39,636 |  |  | 496 |  |  | 38,787 |  |
| Effect of exchange rate changes on cash and cash equivalents | (1 | ) |  | (21 | ) |  | 47 |  |  | 31 |  |
| Change in cash and cash equivalents | 2,493 |  |  | 1,531 |  |  | 2,232 |  |  | 2,328 |  |
| Cash and cash equivalents at beginning of period, including amounts held for sale | 9,213 |  |  | 7,373 |  |  | 9,474 |  |  | 6,576 |  |
| Cash and cash equivalents at end of the period | $ | 11,706 |  |  | $ | 8,904 |  |  | $ | 11,706 |  |  | $ | 8,904 |  |
| Less: Cash included in current assets held for sale | — |  |  | 82 |  |  | — |  |  | 82 |  |
| Cash and cash equivalents from continuing operations | $ | 11,706 |  |  | $ | 8,822 |  |  | $ | 11,706 |  |  | $ | 8,822 |  |

[0001571996-17-000042:8k_2_02:87]
DELL TECHNOLOGIES INC.

[0001571996-17-000042:8k_2_02:88]
Segment Information

[0001571996-17-000042:8k_2_02:89]
(in millions, except percentages; unaudited; continued on next page)

[0001571996-17-000042:8k_2_02:90]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | November 3, 2017 |  | October 28, 2016 |  | Change |  | November 3, 2017 |  | October 28, 2016 |  | Change |
| Client Solutions Group (CSG): |  |  |  |  |  |  |  |  |  |  |  |
| Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 6,907 |  |  | $ | 6,400 |  |  | 8% |  | $ | 20,453 |  |  | $ | 19,343 |  |  | 6% |
| Consumer | 3,052 |  |  | 2,787 |  |  | 10% |  | 8,413 |  |  | 7,635 |  |  | 10% |
| Total CSG net revenue | $ | 9,959 |  |  | $ | 9,187 |  |  | 8% |  | $ | 28,866 |  |  | $ | 26,978 |  |  | 7% |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| CSG operating income | $ | 672 |  |  | $ | 634 |  |  | 6% |  | $ | 1,612 |  |  | $ | 1,503 |  |  | 7% |
| % of CSG net revenue | 7 | % |  | 7 | % |  |  |  | 6 | % |  | 6 | % |  |  |
| % of total segment operating income | 34 | % |  | 30 | % |  |  |  | 34 | % |  | 44 | % |  |  |
| Infrastructure Solutions Group (ISG): |  |  |  |  |  |  |  |  |  |  |  |
| Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Servers and networking | $ | 3,851 |  |  | $ | 2,910 |  |  | 32% |  | $ | 10,822 |  |  | $ | 9,222 |  |  | 17% |
| Storage | 3,667 |  |  | 3,079 |  |  | 19% |  | 11,018 |  |  | 4,159 |  |  | 165% |
| Total ISG net revenue | $ | 7,518 |  |  | $ | 5,989 |  |  | 26% |  | $ | 21,840 |  |  | $ | 13,381 |  |  | 63% |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| ISG operating income | $ | 678 |  |  | $ | 897 |  |  | (24)% |  | $ | 1,431 |  |  | $ | 1,389 |  |  | 3% |
| % of ISG net revenue | 9 | % |  | 15 | % |  |  |  | 7 | % |  | 10 | % |  |  |
| % of total segment operating income | 34 | % |  | 43 | % |  |  |  | 30 | % |  | 40 | % |  |  |
| VMware: |  |  |  |  |  |  |  |  |  |  |  |
| Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Total VMware net revenue | $ | 1,953 |  |  | $ | 1,289 |  |  | 52% |  | $ | 5,596 |  |  | $ | 1,289 |  |  | 334% |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| VMware operating income | $ | 639 |  |  | $ | 548 |  |  | 17% |  | $ | 1,686 |  |  | $ | 548 |  |  | 208% |
| % of VMware net revenue | 33 | % |  | 43 | % |  |  |  | 30 | % |  | 43 | % |  |  |
| % of total segment operating income | 32 | % |  | 26 | % |  |  |  | 36 | % |  | 16 | % |  |  |

[0001571996-17-000042:8k_2_02:91]
DELL TECHNOLOGIES INC.

[0001571996-17-000042:8k_2_02:92]
Segment Information

[0001571996-17-000042:8k_2_02:93]
(in millions, except percentages; unaudited; continued)

[0001571996-17-000042:8k_2_02:94]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | November 3, 2017 |  | October 28, 2016 |  |  |  | November 3, 2017 |  | October 28, 2016 |  |  |
| Reconciliation to consolidated net revenue: |  |  |  |  |  |  |  |  |  |  |
| Reportable segment net revenue | $ | 19,430 |  |  | $ | 16,465 |  |  |  |  | $ | 56,302 |  |  | $ | 41,648 |  |  |  |
| Other businesses (a) | 475 |  |  | 312 |  |  |  |  | 1,409 |  |  | 530 |  |  |  |
| Unallocated transactions (b) | — |  |  | — |  |  |  |  | (1 | ) |  | 63 |  |  |  |
| Impact of purchase accounting (c) | (295 | ) |  | (530 | ) |  |  |  | (985 | ) |  | (673 | ) |  |  |
| Total net revenue | $ | 19,610 |  |  | $ | 16,247 |  |  |  |  | $ | 56,725 |  |  | $ | 41,568 |  |  |  |
| Reconciliation to consolidated operating income (loss): |  |  |  |  |  |  |  |  |
| Reportable segment operating income | $ | 1,989 |  |  | $ | 2,079 |  |  |  |  | $ | 4,729 |  |  | $ | 3,440 |  |  |  |
| Other businesses (a) | 6 |  |  | (13 | ) |  |  |  | 10 |  |  | (48 | ) |  |  |
| Unallocated transactions (b) | (9 | ) |  | (91 | ) |  |  |  | (4 | ) |  | (122 | ) |  |  |
| Impact of purchase accounting (c) | (366 | ) |  | (850 | ) |  |  |  | (1,195 | ) |  | (1,054 | ) |  |  |
| Amortization of intangibles | (1,734 | ) |  | (1,164 | ) |  |  |  | (5,250 | ) |  | (2,146 | ) |  |  |
| Transaction-related expenses (d) | (86 | ) |  | (1,200 | ) |  |  |  | (415 | ) |  | (1,329 | ) |  |  |
| Other corporate expenses (e) | (333 | ) |  | (273 | ) |  |  |  | (887 | ) |  | (325 | ) |  |  |
| Total operating loss | $ | (533 | ) |  | $ | (1,512 | ) |  |  |  | $ | (3,012 | ) |  | $ | (1,584 | ) |  |  |

[0001571996-17-000042:8k_2_02:95]
_________________

[0001571996-17-000042:8k_2_02:96]
| (a) | Other businesses consist of RSA Information Security, SecureWorks, Pivotal, and Boomi, and do not constitute a reportable segment, either individually or collectively, as the results of the businesses are not material to the Company's overall results and the businesses do not meet the criteria for reportable segments. |

[0001571996-17-000042:8k_2_02:97]
| (b) | Unallocated transactions includes long-term incentives, certain short-term incentive compensation expenses, and other corporate items that are not allocated to Dell Technologies' reportable segments. |

[0001571996-17-000042:8k_2_02:98]
| (c) | Impact of purchase accounting includes non-cash purchase accounting adjustments that are primarily related to the EMC merger transaction. |

[0001571996-17-000042:8k_2_02:99]
| (d) | Transaction-related expenses includes acquisition, integration, and divestiture related costs. |

[0001571996-17-000042:8k_2_02:100]
| (e) | Other corporate expenses includes severance and facility action costs as well as stock-based compensation expense. |

[0001571996-17-000042:8k_2_02:101]
SUPPLEMENTAL SELECTED NON-GAAP FINANCIAL MEASURES

[0001571996-17-000042:8k_2_02:102]
These tables present information about the Company’s non-GAAP net revenue, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income from continuing operations, EBITDA, and adjusted EBITDA, which are non-GAAP financial measures provided as a supplement to the results provided in accordance with generally accepted accounting principles in the United States of America (“GAAP”). A detailed discussion of Dell Technologies’ reasons for including these non-GAAP financial measures, the limitations associated with these measures, the items excluded from these measures, and our reason for excluding those items are presented in “Management’s Discussion and Analysis of Financial Condition and Results of Operations - Non-GAAP Financial Measures” in our periodic reports filed with the SEC. Dell Technologies encourages investors to review the non-GAAP discussion in conjunction with the presentation of non-GAAP financial measures.

[0001571996-17-000042:8k_2_02:103]
DELL TECHNOLOGIES INC.

[0001571996-17-000042:8k_2_02:104]
Selected Non-GAAP Financial Measures

[0001571996-17-000042:8k_2_02:105]
(in millions, except percentages; unaudited)

[0001571996-17-000042:8k_2_02:106]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | November 3, 2017 |  | October 28, 2016 |  | Change |  | November 3, 2017 |  | October 28, 2016 |  | Change |
| Non-GAAP net revenue | $ | 19,905 |  |  | $ | 16,777 |  |  | 19% |  | $ | 57,710 |  |  | $ | 42,241 |  |  | 37% |
| Non-GAAP gross margin | $ | 6,417 |  |  | $ | 5,324 |  |  | 21% |  | $ | 18,163 |  |  | $ | 10,224 |  |  | 78% |
| % of non-GAAP net revenue | 32 | % |  | 32 | % |  |  |  | 31 | % |  | 24 | % |  |  |
| Non-GAAP operating expenses | $ | 4,431 |  |  | $ | 3,349 |  |  | 32% |  | $ | 13,428 |  |  | $ | 6,954 |  |  | 93% |
| % of non-GAAP net revenue | 22 | % |  | 20 | % |  |  |  | 23 | % |  | 16 | % |  |  |
| Non-GAAP operating income | $ | 1,986 |  |  | $ | 1,975 |  |  | 1% |  | $ | 4,735 |  |  | $ | 3,270 |  |  | 45% |
| % of non-GAAP net revenue | 10 | % |  | 12 | % |  |  |  | 8 | % |  | 8 | % |  |  |
| Non-GAAP net income from continuing operations | $ | 1,109 |  |  | $ | 970 |  |  | 14% |  | $ | 2,563 |  |  | $ | 1,596 |  |  | 61% |
| % of non-GAAP net revenue | 6 | % |  | 6 | % |  |  |  | 4 | % |  | 4 | % |  |  |
| Adjusted EBITDA | $ | 2,318 |  |  | $ | 2,230 |  |  | 4% |  | $ | 5,751 |  |  | $ | 3,757 |  |  | 53% |
| % of non-GAAP net revenue | 12 | % |  | 13 | % |  |  |  | 10 | % |  | 9 | % |  |  |

[0001571996-17-000042:8k_2_02:107]
DELL TECHNOLOGIES INC.

[0001571996-17-000042:8k_2_02:108]
Reconciliation of Non-GAAP Financial Measures

[0001571996-17-000042:8k_2_02:109]
(in millions, except percentages; unaudited; continued on next page)

[0001571996-17-000042:8k_2_02:110]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | November 3, 2017 |  | October 28, 2016 |  | Change |  | November 3, 2017 |  | October 28, 2016 |  | Change |
| Net revenue | $ | 19,610 |  |  | $ | 16,247 |  |  | 21% |  | $ | 56,725 |  |  | $ | 41,568 |  |  | 36% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 295 |  |  | 530 |  |  |  |  | 985 |  |  | 673 |  |  |  |
| Non-GAAP net revenue | $ | 19,905 |  |  | $ | 16,777 |  |  | 19% |  | $ | 57,710 |  |  | $ | 42,241 |  |  | 37% |
| Gross margin | $ | 5,163 |  |  | $ | 3,899 |  |  | 32% |  | $ | 14,274 |  |  | $ | 8,428 |  |  | 69% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 307 |  |  | 729 |  |  |  |  | 1,020 |  |  | 897 |  |  |  |
| Amortization of intangibles | 914 |  |  | 604 |  |  |  |  | 2,784 |  |  | 806 |  |  |  |
| Transaction-related expenses | 5 |  |  | 30 |  |  |  |  | 22 |  |  | 25 |  |  |  |
| Other corporate expenses | 28 |  |  | 62 |  |  |  |  | 63 |  |  | 68 |  |  |  |
| Non-GAAP gross margin | $ | 6,417 |  |  | $ | 5,324 |  |  | 21% |  | $ | 18,163 |  |  | $ | 10,224 |  |  | 78% |
| Operating expenses | $ | 5,696 |  |  | $ | 5,411 |  |  | 5% |  | $ | 17,286 |  |  | $ | 10,012 |  |  | 73% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | (59 | ) |  | (121 | ) |  |  |  | (175 | ) |  | (157 | ) |  |  |
| Amortization of intangibles | (820 | ) |  | (560 | ) |  |  |  | (2,466 | ) |  | (1,340 | ) |  |  |
| Transaction-related expenses | (81 | ) |  | (1,170 | ) |  |  |  | (393 | ) |  | (1,304 | ) |  |  |
| Other corporate expenses | (305 | ) |  | (211 | ) |  |  |  | (824 | ) |  | (257 | ) |  |  |
| Non-GAAP operating expenses | $ | 4,431 |  |  | $ | 3,349 |  |  | 32% |  | $ | 13,428 |  |  | $ | 6,954 |  |  | 93% |
| Operating loss | $ | (533 | ) |  | $ | (1,512 | ) |  | 65% |  | $ | (3,012 | ) |  | $ | (1,584 | ) |  | (90)% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 366 |  |  | 850 |  |  |  |  | 1,195 |  |  | 1,054 |  |  |  |
| Amortization of intangibles | 1,734 |  |  | 1,164 |  |  |  |  | 5,250 |  |  | 2,146 |  |  |  |
| Transaction-related expenses | 86 |  |  | 1,200 |  |  |  |  | 415 |  |  | 1,329 |  |  |  |
| Other corporate expenses | 333 |  |  | 273 |  |  |  |  | 887 |  |  | 325 |  |  |  |
| Non-GAAP operating income | $ | 1,986 |  |  | $ | 1,975 |  |  | 1% |  | $ | 4,735 |  |  | $ | 3,270 |  |  | 45% |
| Net loss from continuing operations | $ | (941 | ) |  | $ | (1,637 | ) |  | 43% |  | $ | (3,302 | ) |  | $ | (2,323 | ) |  | (42)% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 366 |  |  | 850 |  |  |  |  | 1,195 |  |  | 1,054 |  |  |  |
| Amortization of intangibles | 1,734 |  |  | 1,164 |  |  |  |  | 5,250 |  |  | 2,146 |  |  |  |
| Transaction-related expenses | 86 |  |  | 1,200 |  |  |  |  | 415 |  |  | 1,326 |  |  |  |
| Other corporate expenses | 333 |  |  | 273 |  |  |  |  | 887 |  |  | 325 |  |  |  |
| Aggregate adjustment for income taxes | (469 | ) |  | (880 | ) |  |  |  | (1,882 | ) |  | (932 | ) |  |  |
| Non-GAAP net income from continuing operations | $ | 1,109 |  |  | $ | 970 |  |  | 14% |  | $ | 2,563 |  |  | $ | 1,596 |  |  | 61% |

[0001571996-17-000042:8k_2_02:111]
DELL TECHNOLOGIES INC.

[0001571996-17-000042:8k_2_02:112]
Reconciliation of Non-GAAP Financial Measures

[0001571996-17-000042:8k_2_02:113]
(in millions, except percentages; unaudited; continued)

[0001571996-17-000042:8k_2_02:114]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | November 3, 2017 |  | October 28, 2016 |  | Change |  | November 3, 2017 |  | October 28, 2016 |  | Change |
| Net loss from continuing operations | $ | (941 | ) |  | $ | (1,637 | ) |  | 43% |  | $ | (3,302 | ) |  | $ | (2,323 | ) |  | (42)% |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Interest and other, net | 682 |  |  | 794 |  |  |  |  | 1,800 |  |  | 1,362 |  |  |  |
| Income tax benefit | (274 | ) |  | (669 | ) |  |  |  | (1,510 | ) |  | (623 | ) |  |  |
| Depreciation and amortization | 2,137 |  |  | 1,576 |  |  |  |  | 6,491 |  |  | 2,799 |  |  |  |
| EBITDA | $ | 1,604 |  |  | $ | 64 |  |  | NM |  | $ | 3,479 |  |  | $ | 1,215 |  |  | 186% |
| EBITDA | $ | 1,604 |  |  | $ | 64 |  |  | NM |  | $ | 3,479 |  |  | $ | 1,215 |  |  | 186% |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense | 221 |  |  | 144 |  |  |  |  | 630 |  |  | 177 |  |  |  |
| Impact of purchase accounting | 298 |  |  | 693 |  |  |  |  | 990 |  |  | 851 |  |  |  |
| Transaction-related expenses | 86 |  |  | 1,200 |  |  |  |  | 415 |  |  | 1,366 |  |  |  |
| Other corporate expenses | 109 |  |  | 129 |  |  |  |  | 237 |  |  | 148 |  |  |  |
| Adjusted EBITDA | $ | 2,318 |  |  | $ | 2,230 |  |  | 4% |  | $ | 5,751 |  |  | $ | 3,757 |  |  | 53% |
