# DELL MD&A — 0001571996-18-000034


## mdna

[0001571996-18-000034:mdna:1]
[same as prior period, unchanged from 0001571996-18-000022:mdna:1]

[0001571996-18-000034:mdna:2]
This management's discussion and analysis should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company's Annual Report on Form 10-K for the fiscal year ended February 2, 2018 and the recast audited Consolidated Financial Statements and accompanying Notes for the fiscal years ended February 2, 2018 and February 3, 2017 and other financial information included in the Current Report on Form 8-K filed with the SEC on August 6, 2018.  Multiple accounting standards were adopted during the three months ended May 4, 2018, which resulted in adjustment or reclassification of amounts previously reported.  See Note 1 of the Notes to the Condensed Consolidated Financial Statements included in this report for further information regarding our recently adopted accounting standards.

[0001571996-18-000034:mdna:3]
[same as prior period, unchanged from 0001571996-18-000022:mdna:3]

[0001571996-18-000034:mdna:4]
[same as prior period, unchanged from 0001571996-18-000022:mdna:4]

[0001571996-18-000034:mdna:5]
[same as prior period, unchanged from 0001571996-18-000022:mdna:5]

[0001571996-18-000034:mdna:6]
[same as prior period, unchanged from 0001571996-18-000022:mdna:6]

[0001571996-18-000034:mdna:7]
Dell Technologies is a leading global end-to-end technology provider, with a comprehensive portfolio of IT hardware, software and service solutions spanning both traditional infrastructure and emerging, multi-cloud technologies that enable our customers to meet the business needs of tomorrow.  We operate eight complementary businesses:  our Infrastructure Solutions Group and our Client Solutions Group, as well as VMware, Inc., Pivotal Software, Inc. ("Pivotal"), SecureWorks Corp. ("SecureWorks"), RSA Security LLC ("RSA Security"), Virtustream Group Holdings, Inc. ("Virtustream"), and Boomi, Inc. ("Boomi").  Together our strategically aligned family of businesses operates in close coordination across key functional areas such as product development, go-to-market and global services, and are supported by Dell Financial Services.  We believe this operational philosophy enables our platform to seamlessly deliver differentiated and holistic IT solutions to our customers, which has driven significant revenue growth and share gains.

[0001571996-18-000034:mdna:8]
As a result of our significant transformation since the going-private transaction in 2013, Dell Technologies today operates on an extraordinary scale with an unmatched breadth of complementary offerings.  Digital transformation has become essential to all businesses, and we have expanded our portfolio to include holistic solutions that enable our customers to drive their ongoing digital transformation initiatives.  Dell Technologies’ integrated solutions help customers modernize their IT infrastructure, address workforce transformation and provide critical security solutions to protect against the ever increasing and evolving security threats.  With our extensive portfolio and our commitment to innovation, we have the ability to offer secure, integrated solutions that extend from the intelligent edge to the multi-cloud data center ecosystem, and we are at the forefront of the software-defined and cloud native infrastructure era.  Our end-to-end portfolio is supported by a differentiated go-to-market engine, which includes a 40,000-person sales force and 150,000 channel partners across 180 countries, and a world-class supply chain that together drive revenue growth and operating efficiencies.

[0001571996-18-000034:mdna:9]
[same as prior period, unchanged from 0001571996-18-000022:mdna:12]

[0001571996-18-000034:mdna:10]
We design, develop, manufacture, market, sell, and support a wide range of hardware, software, and services.  We are organized into the following business units, which are our reportable segments: Infrastructure Solutions Group; Client Solutions Group; and VMware.

[0001571996-18-000034:mdna:11]
| • | Infrastructure Solutions Group ("ISG") — Our Infrastructure Solutions Group, provides comprehensive data solutions and services, including storage, server, networking and services. Our comprehensive portfolio of advanced storage solutions includes traditional storage solutions as well as next-generation storage solutions (such as all-flash arrays, scale-out file, object platforms, and software-defined solutions), while our server portfolio includes high-performance rack, blade, tower, and hyperscale servers. Our networking portfolio helps our business customers transform and modernize their infrastructure, mobilize and enrich end-user experiences, and accelerate business applications and processes. ISG also offers attached software, peripherals, and services, including support and deployment, configuration, and extended warranty services. |

[0001571996-18-000034:mdna:12]
[same as prior period, unchanged from 0001571996-18-000022:mdna:15]

[0001571996-18-000034:mdna:13]
[same as prior period, unchanged from 0001571996-18-000022:mdna:16]

[0001571996-18-000034:mdna:14]
| • | Client Solutions Group ("CSG") — CSG includes branded hardware (such as PCs, workstations, and notebooks) and branded peripherals (such as displays and projectors), as well as third-party software and peripherals. CSG also offers attached services, including support and deployment, configuration, and extended warranty services. |

[0001571996-18-000034:mdna:15]
[same as prior period, unchanged from 0001571996-18-000022:mdna:18]

[0001571996-18-000034:mdna:16]
[same as prior period, unchanged from 0001571996-18-000022:mdna:19]

[0001571996-18-000034:mdna:17]
VMware provides compute, management, cloud, networking, and security storage, mobility, and other end-user computing infrastructure software to businesses that provides a flexible digital foundation for the applications that empower businesses to serve their customers globally.  VMware has continued to broaden its portfolio and solution offerings beyond software-defined compute software to enable customers to modernize data centers, integrate public clouds, transform networking and security, and empower digital workspaces.

[0001571996-18-000034:mdna:18]
[same as prior period, unchanged from 0001571996-18-000022:mdna:21]

[0001571996-18-000034:mdna:19]
Our other businesses, described below, consist of product and service offerings of Pivotal, SecureWorks, RSA Security, Virtustream, and Boomi.  These businesses are not classified as reportable segments, either individually or collectively, as the results of the businesses are not material to our overall results and the businesses do not meet the criteria for reportable segments.

[0001571996-18-000034:mdna:20]
[same as prior period, unchanged from 0001571996-18-000022:mdna:24]

[0001571996-18-000034:mdna:21]
| • | SecureWorks (NASDAQ: SCWX) is a leading global provider of intelligence-driven information security solutions singularly focused on protecting its clients from cyber attacks. SecureWorks’s solutions enable organizations of varying size and complexity to fortify their cyber defenses to prevent security breaches, detect malicious activity in near real time, prioritize and respond rapidly to security incidents and predict emerging threats. |

[0001571996-18-000034:mdna:22]
| • | RSA Security provides essential cybersecurity solutions engineered to enable organizations to detect, investigate, and respond to advanced attacks, confirm and manage identities, and, ultimately, help reduce IP theft, fraud, and cybercrime. |

[0001571996-18-000034:mdna:23]
| • | Virtustream offers cloud software and infrastructure-as-a-service solutions that enable customers to migrate, run, and manage mission-critical applications in cloud-based IT environments, which is a key element of our strategy to help customers support their applications in a variety of cloud-native environments. Beginning in the first quarter of Fiscal 2019, Virtustream results are reported within other businesses, rather than within ISG. This change in reporting structure did not impact our previously reported consolidated financial results, but our prior period segment results have been recast to reflect the change. |

[0001571996-18-000034:mdna:24]
[same as prior period, unchanged from 0001571996-18-000022:mdna:27]

[0001571996-18-000034:mdna:25]
[same as prior period, unchanged from 0001571996-18-000022:mdna:28]

[0001571996-18-000034:mdna:26]
[same as prior period, unchanged from 0001571996-18-000022:mdna:29]

[0001571996-18-000034:mdna:27]
[same as prior period, unchanged from 0001571996-18-000022:mdna:30]

[0001571996-18-000034:mdna:28]
Dell Financial Services and its affiliates ("DFS") supports our businesses by offering and arranging various financing options and services for our customers in North America, Europe, Australia, and New Zealand.  DFS originates, collects, and services customer receivables primarily related to the purchase of our product, software, and service solutions.  DFS further strengthens our customer relationships through its flexible consumption models, which enable us to offer our customers the option to pay over time and, in certain cases, based on utilization, providing them with financial flexibility to meet their changing technological requirements.  The results of these operations are allocated to our segments based on the underlying product or service financed.  For additional information about our financing arrangements, see Note 5 of the Notes to the Condensed Consolidated Financial Statements included in this report.

[0001571996-18-000034:mdna:29]
[same as prior period, unchanged from 0001571996-18-000022:mdna:32]

[0001571996-18-000034:mdna:30]
As part of our strategy, we will continue to evaluate opportunities for strategic investments through our venture capital investment arm, Dell Technologies Capital, with a focus on emerging technology areas that are relevant to the Dell Technologies unique family of businesses and that will complement our existing portfolio of solutions.  Our investment areas include storage, software-defined networking, management and orchestration, security, machine learning and artificial intelligence, Big Data and analytics, cloud, Internet of Things, and software development operations.  In addition to these investments, we also may make disciplined acquisitions targeting businesses that advance our strategic objectives.  As of August 3, 2018 and February 2, 2018, Dell Technologies held strategic investments of $1.0 billion and $0.7 billion, respectively.

[0001571996-18-000034:mdna:31]
[same as prior period, unchanged from 0001571996-18-000022:mdna:34]

[0001571996-18-000034:mdna:32]
[same as prior period, unchanged from 0001571996-18-000022:mdna:35]

[0001571996-18-000034:mdna:33]
We expect that ISG will continue to be impacted by the changing nature of the IT infrastructure market and competitive environment.  Cloud-native applications are expected to continue as a primary growth driver in the infrastructure market as IT organizations increasingly become multi-cloud environments.  We believe the complementary cloud solutions across our business strongly position us to meet these demands for our customers who are increasingly looking to leverage cloud-based computing.  We also continue to be impacted by the emerging trends of enterprises deploying software-defined storage, hyper-converged infrastructure, and modular solutions based on server-centric architectures.  These trends have put pressure on our traditional storage offerings, and we are focused on strategically repositioning our storage portfolio.  Offsetting this, however, is the unprecedented data growth throughout all industries, which is generating continued demand for our storage products and services.  We have leading solutions through our ISG and VMware data center offerings.  In addition, through our research and development efforts, we expect to develop new solutions in this rapidly changing industry that we believe will enable us to continue to provide superior solutions to our customers.

[0001571996-18-000034:mdna:34]
[same as prior period, unchanged from 0001571996-18-000022:mdna:37]

[0001571996-18-000034:mdna:35]
We are able to leverage our traditional strength in the PC market to offer solutions and services that provide higher-value, recurring revenue streams.  Given current market trends, we expect that the demand environment will continue to be cyclical and that competitive dynamics will continue to pressure our CSG business.  However, we are committed to a long-term growth strategy that we believe will benefit from the consolidation trends that are occurring in our markets.  Our CSG offerings remain an important element of our strategy, generating strong cash flow and opportunities for cross-selling of complementary solutions.  CSG net revenue represented approximately half of our net revenue during both the second quarter of Fiscal 2019 and the second quarter of Fiscal 2018.

[0001571996-18-000034:mdna:36]
We manage our business on a U.S. dollar basis.  However, we have a large global presence, generating approximately half of our revenue by sales to customers outside of the United States during the first six months of Fiscal 2019 and the first six months of Fiscal 2018.  Our revenues, therefore, can be impacted by fluctuations in foreign currency exchange rates.  We utilize a comprehensive hedging strategy intended to mitigate the impact of foreign currency volatility over time, and we adjust pricing when possible to further minimize foreign currency impacts.

[0001571996-18-000034:mdna:37]
[same as prior period, unchanged from 0001571996-18-000022:mdna:40]

[0001571996-18-000034:mdna:38]
Our key performance metrics are net revenue, operating income, adjusted EBITDA, and cash flows from operations, which are discussed elsewhere in this report.

[0001571996-18-000034:mdna:39]
Class V Transaction

[0001571996-18-000034:mdna:40]
On July 2, 2018, the Company announced that it had completed its evaluation of potential strategic business opportunities.  As a result of such evaluation, the Company has determined to pursue a transaction, referred to as the "Class V transaction,"  pursuant to an Agreement and Plan of Merger (the "Merger Agreement"), dated as of July 1, 2018, between the Company and  Teton Merger Sub Inc. ("Merger Sub"), a Delaware corporation and wholly-owned subsidiary of the Company.  The Merger Agreement provides, among other things and subject to the terms and conditions set forth therein, that Merger Sub will be merged with and into the Company (the "Merger"), with the Company continuing as the surviving corporation.

[0001571996-18-000034:mdna:41]
The Merger Agreement provides that, subject to the terms and conditions thereof, at the effective time of the Merger (the "Effective Time"), each share of Class V Common Stock that is issued and outstanding immediately prior to the Effective Time will be canceled and converted into the right to receive, at the holder’s election, (i) 1.3665 shares (the "Share Consideration") of Class C Common Stock or (ii) $109.00 in cash, without interest (the "Cash Consideration"), subject to an aggregate amount of Cash Consideration that may be received by holders of Class V Common Stock in the Merger not exceeding $9 billion (the "Aggregate Cash Consideration Cap").  If the total amount of Cash Consideration elected by holders of Class V Common Stock would exceed the Aggregate Cash Consideration Cap, a portion of the shares with respect to which a holder elects to receive the Cash Consideration equal to a fraction, the numerator of which is the Aggregate Cash Consideration Cap and the denominator of which is the aggregate amount of Cash Consideration elected by holders, will be converted into the right to receive the Cash Consideration and the remaining portion of such shares held by such holders will be converted into the right to receive the Share Consideration.  Any share of Class V Common Stock for which a valid election to receive Cash Consideration is not in effect at the Effective Time will be converted into Share Consideration.  Upon consummation of the Merger, all shares of the

[0001571996-18-000034:mdna:42]
Class V Common Stock would be delisted from the New York Stock Exchange and the Class C Common Stock would be listed on the New York Stock Exchange.

[0001571996-18-000034:mdna:43]
In addition, pursuant to the Merger Agreement, as of the Effective Time and unless otherwise agreed by the Company and a holder of a Class V Common Stock-based equity award granted by the Company (a "Class V Award"), each Class V Award will be converted into a new equity award on the same terms and conditions (including applicable vesting requirements and deferral provisions) with respect to the number of shares of Class C Common Stock that is equal to the number of shares of Class V Common Stock that were subject to the Class V Award multiplied by 1.3665 (rounded down to the nearest whole share).  The exercise price for any Class V Award options so converted will equal the exercise price of such Class V Award options immediately prior to the Effective Time divided by 1.3665 (rounded up to the nearest whole penny).

[0001571996-18-000034:mdna:44]
In connection with the Merger Agreement, the board of directors of VMware, Inc. declared a conditional $11 billion one‑time special cash dividend pro rata to holders of VMware, Inc. common stock.  Immediately prior to the completion of the Class V transaction, subject to the satisfaction of other conditions of the Class V transaction, as well as certain other conditions, VMware, Inc. will pay the special cash dividend to its stockholders.  Approximately $8.95 billion of the VMware, Inc. cash dividend will be received by the Company and used to fund all or substantially all of the Cash Consideration paid to holders of the Class V Common Stock in the Class V transaction.  The Company will fund any remaining cash consideration, which is not expected to be material, from cash on hand.

[0001571996-18-000034:mdna:45]
The obligation of the Company to complete the Merger and the Class V transaction is subject to stockholder approval and certain other closing conditions as further described in a Current Report on Form 8-K filed by the Company with the SEC on July 2, 2018.

[0001571996-18-000034:mdna:46]
68

[0001571996-18-000034:mdna:47]
[same as prior period, unchanged from 0001571996-18-000022:mdna:42]

[0001571996-18-000034:mdna:48]
[same as prior period, unchanged from 0001571996-18-000022:mdna:43]

[0001571996-18-000034:mdna:49]
[same as prior period, unchanged from 0001571996-18-000022:mdna:44]

[0001571996-18-000034:mdna:50]
[same as prior period, unchanged from 0001571996-18-000022:mdna:45]

[0001571996-18-000034:mdna:51]
Non-GAAP product net revenue, non-GAAP services net revenue, non-GAAP net revenue, non-GAAP product gross margin, non-GAAP services gross margin, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, and non-GAAP net income, as defined by us, exclude the impact of amortization of intangible assets, purchase accounting, transaction-related expenses, other corporate expenses and, for non-GAAP net income from continuing operations, an aggregate adjustment for income taxes.  As the excluded items have a material impact on our financial results, our management compensates for this limitation by relying primarily on our GAAP results and using non-GAAP financial measures supplementally or for projections when comparable GAAP financial measures are not available.  The non-GAAP financial measures are not meant to be considered as indicators of performance in isolation from or as a substitute for net revenue, gross margin, operating expenses, operating income, or net income prepared in accordance with GAAP, and should be read only in conjunction with financial information presented on a GAAP basis.

[0001571996-18-000034:mdna:52]
[same as prior period, unchanged from 0001571996-18-000022:mdna:47]

[0001571996-18-000034:mdna:53]
[same as prior period, unchanged from 0001571996-18-000022:mdna:48]

[0001571996-18-000034:mdna:54]
[same as prior period, unchanged from 0001571996-18-000022:mdna:49]

[0001571996-18-000034:mdna:55]
| • | Impact of Purchase Accounting — The impact of purchase accounting includes purchase accounting adjustments, related to the EMC merger transaction and, to a lesser extent, the going-private transaction, recorded under the acquisition method of accounting in accordance with the accounting guidance for business combinations. This guidance prescribes that the purchase price be allocated to assets acquired and liabilities assumed based on the estimated fair value of such assets and liabilities on the date of the transaction. Accordingly, all of the assets and liabilities acquired in the EMC merger transaction and the going-private transaction were accounted for and recognized at fair value as of the respective transaction dates, and the fair value adjustments are being amortized over the estimated useful lives in the periods following the transactions. The fair value adjustments primarily relate to deferred revenue, inventory, and property, plant, and equipment. The purchase accounting adjustments and related amortization of those adjustments are reflected in our GAAP results; however, we evaluate the operating results of the underlying businesses on a non-GAAP basis, after removing such adjustments. We believe that excluding the impact of purchase accounting provides results that are useful in understanding our current operating performance and provides more meaningful comparisons to our past operating performance. |

[0001571996-18-000034:mdna:56]
| • | Transaction-related Expenses — Transaction-related expenses consist of acquisition, integration, and divestiture related costs, and are expensed as incurred. These expenses primarily represent costs for legal, banking, consulting, and advisory services, as well as certain compensatory retention awards directly related to the EMC merger transaction. During the first six months of Fiscal 2019, this category also included approximately $116 million of expenses incurred in the first quarter of Fiscal 2019 related to integration of our inventory policies and management process related to customer evaluation units. |

[0001571996-18-000034:mdna:57]
| • | Other Corporate Expenses — Other corporate expenses consists of severance, facility action costs, and stock-based compensation expense associated with equity awards. Severance costs are primarily related to severance and benefits for employees terminated pursuant to cost savings initiatives. Facility action costs were $5 million and $14 million, respectively, during the second quarter and first six months of Fiscal 2019, compared to $29 million and $109 million, respectively, during the second quarter and first six months of Fiscal 2018. We continue to integrate owned and leased facilities and may incur additional costs as we seek opportunities for operational efficiencies. Other corporate expenses vary from period to period and are significantly impacted by the timing and nature of these events. Therefore, although we may incur these types of expenses in the future, we believe that eliminating these charges for purposes of calculating the non-GAAP financial measures presented below facilitates a more meaningful evaluation of our current operating performance and comparisons to our past operating performance. |

[0001571996-18-000034:mdna:58]
| • | Aggregate Adjustment for Income Taxes — The aggregate adjustment for income taxes is the estimated combined income tax effect for the adjustments described above. During the first six months of Fiscal 2019, this category also includes approximately $154 million of tax benefits resulting from the impact of adopting the new revenue standard in the first quarter of Fiscal 2019. The tax effects are determined based on the tax jurisdictions where the above items were incurred. |

[0001571996-18-000034:mdna:59]
[same as prior period, unchanged from 0001571996-18-000022:mdna:99]

[0001571996-18-000034:mdna:60]
[same as prior period, unchanged from 0001571996-18-000022:mdna:56]

[0001571996-18-000034:mdna:61]
|  | Three Months Ended |  | Six Months Ended |
|  | August 3, 2018 |  | % Change |  | August 4, 2017 |  | August 3, 2018 |  | % Change |  | August 4, 2017 |
|  | (in millions, except percentages) |
| Product net revenue | $ | 18,149 |  |  | 20 | % |  | $ | 15,102 |  |  | $ | 34,820 |  |  | 21 | % |  | $ | 28,736 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 18 |  |  |  |  | 50 |  |  | 35 |  |  |  |  | 105 |  |
| Non-GAAP product net revenue | $ | 18,167 |  |  | 20 | % |  | $ | 15,152 |  |  | $ | 34,855 |  |  | 21 | % |  | $ | 28,841 |  |
| Services net revenue | $ | 4,793 |  |  | 8 | % |  | $ | 4,419 |  |  | $ | 9,478 |  |  | 8 | % |  | $ | 8,785 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 162 |  |  |  |  | 285 |  |  | 332 |  |  |  |  | 585 |  |
| Non-GAAP services net revenue | $ | 4,955 |  |  | 5 | % |  | $ | 4,704 |  |  | $ | 9,810 |  |  | 5 | % |  | $ | 9,370 |  |
| Net revenue | $ | 22,942 |  |  | 18 | % |  | $ | 19,521 |  |  | $ | 44,298 |  |  | 18 | % |  | $ | 37,521 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 180 |  |  |  |  | 335 |  |  | 367 |  |  |  |  | 690 |  |
| Non-GAAP net revenue | $ | 23,122 |  |  | 16 | % |  | $ | 19,856 |  |  | $ | 44,665 |  |  | 17 | % |  | $ | 38,211 |  |
| Product gross margin | $ | 3,206 |  |  | 38 | % |  | $ | 2,327 |  |  | $ | 6,271 |  |  | 52 | % |  | $ | 4,138 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 718 |  |  |  |  | 920 |  |  | 1,428 |  |  |  |  | 1,870 |  |
| Impact of purchase accounting | 23 |  |  |  |  | 63 |  |  | 46 |  |  |  |  | 128 |  |
| Transaction-related expenses | 21 |  |  |  |  | 6 |  |  | 137 |  |  |  |  | 8 |  |
| Other corporate expenses | 2 |  |  |  |  | 3 |  |  | 6 |  |  |  |  | 6 |  |
| Non-GAAP product gross margin | $ | 3,970 |  |  | 20 | % |  | $ | 3,319 |  |  | $ | 7,888 |  |  | 28 | % |  | $ | 6,150 |  |
| Services gross margin | $ | 2,917 |  |  | 10 | % |  | $ | 2,641 |  |  | $ | 5,730 |  |  | 8 | % |  | $ | 5,287 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | — |  |  |  |  | — |  |  | 46 |  |  |  |  | — |  |
| Impact of purchase accounting | 162 |  |  |  |  | 285 |  |  | 332 |  |  |  |  | 585 |  |
| Transaction-related expenses | — |  |  |  |  | 4 |  |  | — |  |  |  |  | 9 |  |
| Other corporate expenses | 17 |  |  |  |  | 10 |  |  | 35 |  |  |  |  | 29 |  |
| Non-GAAP services gross margin | $ | 3,096 |  |  | 5 | % |  | $ | 2,940 |  |  | $ | 6,143 |  |  | 4 | % |  | $ | 5,910 |  |
| Gross margin | $ | 6,123 |  |  | 23 | % |  | $ | 4,968 |  |  | $ | 12,001 |  |  | 27 | % |  | $ | 9,425 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 718 |  |  |  |  | 920 |  |  | 1,428 |  |  |  |  | 1,870 |  |
| Impact of purchase accounting | 185 |  |  |  |  | 348 |  |  | 378 |  |  |  |  | 713 |  |
| Transaction-related expenses | 21 |  |  |  |  | 10 |  |  | 137 |  |  |  |  | 17 |  |
| Other corporate expenses | 19 |  |  |  |  | 13 |  |  | 41 |  |  |  |  | 35 |  |
| Non-GAAP gross margin | $ | 7,066 |  |  | 13 | % |  | $ | 6,259 |  |  | $ | 13,985 |  |  | 16 | % |  | $ | 12,060 |  |

[0001571996-18-000034:mdna:62]
71

[0001571996-18-000034:mdna:63]
|  | Three Months Ended |  | Six Months Ended |
|  | August 3, 2018 |  | % Change |  | August 4, 2017 |  | August 3, 2018 |  | % Change |  | August 4, 2017 |
|  | (in millions, except percentages) |
| Operating expenses | $ | 6,136 |  |  | 9 | % |  | $ | 5,633 |  |  | $ | 12,167 |  |  | 7 | % |  | $ | 11,362 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | (808 | ) |  |  |  | (820 | ) |  | (1,620 | ) |  |  |  | (1,646 | ) |
| Impact of purchase accounting | (30 | ) |  |  |  | (58 | ) |  | (59 | ) |  |  |  | (116 | ) |
| Transaction-related expenses | (83 | ) |  |  |  | (128 | ) |  | (133 | ) |  |  |  | (312 | ) |
| Other corporate expenses | (257 | ) |  |  |  | (234 | ) |  | (504 | ) |  |  |  | (519 | ) |
| Non-GAAP operating expenses | $ | 4,958 |  |  | 13 | % |  | $ | 4,393 |  |  | $ | 9,851 |  |  | 12 | % |  | $ | 8,769 |  |
| Operating loss | $ | (13 | ) |  | 98 | % |  | $ | (665 | ) |  | $ | (166 | ) |  | 91 | % |  | $ | (1,937 | ) |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 1,526 |  |  |  |  | 1,740 |  |  | 3,048 |  |  |  |  | 3,516 |  |
| Impact of purchase accounting | 215 |  |  |  |  | 406 |  |  | 437 |  |  |  |  | 829 |  |
| Transaction-related expenses | 104 |  |  |  |  | 138 |  |  | 270 |  |  |  |  | 329 |  |
| Other corporate expenses | 276 |  |  |  |  | 247 |  |  | 545 |  |  |  |  | 554 |  |
| Non-GAAP operating income | $ | 2,108 |  |  | 13 | % |  | $ | 1,866 |  |  | $ | 4,134 |  |  | 26 | % |  | $ | 3,291 |  |
| Net loss | $ | (461 | ) |  | 38 | % |  | $ | (739 | ) |  | $ | (999 | ) |  | 49 | % |  | $ | (1,942 | ) |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 1,526 |  |  |  |  | 1,740 |  |  | 3,048 |  |  |  |  | 3,516 |  |
| Impact of purchase accounting | 215 |  |  |  |  | 406 |  |  | 437 |  |  |  |  | 829 |  |
| Transaction-related expenses | 104 |  |  |  |  | 138 |  |  | 270 |  |  |  |  | 329 |  |
| Other corporate expenses | 276 |  |  |  |  | 247 |  |  | 545 |  |  |  |  | 554 |  |
| Aggregate adjustment for income taxes | (311 | ) |  |  |  | (680 | ) |  | (778 | ) |  |  |  | (1,413 | ) |
| Non-GAAP net income | $ | 1,349 |  |  | 21 | % |  | $ | 1,112 |  |  | $ | 2,523 |  |  | 35 | % |  | $ | 1,873 |  |

[0001571996-18-000034:mdna:64]
[same as prior period, unchanged from 0001571996-18-000022:mdna:60]

[0001571996-18-000034:mdna:65]
[same as prior period, unchanged from 0001571996-18-000022:mdna:61]

[0001571996-18-000034:mdna:66]
[same as prior period, unchanged from 0001571996-18-000022:mdna:62]

[0001571996-18-000034:mdna:67]
|  | Three Months Ended |  | Six Months Ended |
|  | August 3, 2018 |  | % Change |  | August 4, 2017 |  | August 3, 2018 |  | % Change |  | August 4, 2017 |
|  | (in millions, except percentages) |
| Net loss | $ | (461 | ) |  | 38 | % |  | $ | (739 | ) |  | $ | (999 | ) |  | 49 | % |  | $ | (1,942 | ) |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Interest and other, net (a) | 455 |  |  |  |  | 545 |  |  | 925 |  |  |  |  | 1,117 |  |
| Income tax benefit | (7 | ) |  |  |  | (471 | ) |  | (92 | ) |  |  |  | (1,112 | ) |
| Depreciation and amortization | 1,931 |  |  |  |  | 2,142 |  |  | 3,845 |  |  |  |  | 4,354 |  |
| EBITDA | $ | 1,918 |  |  | 30 | % |  | $ | 1,477 |  |  | $ | 3,679 |  |  | 52 | % |  | $ | 2,417 |  |
| EBITDA | $ | 1,918 |  |  | 30 | % |  | $ | 1,477 |  |  | $ | 3,679 |  |  | 52 | % |  | $ | 2,417 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense | 216 |  |  |  |  | 208 |  |  | 415 |  |  |  |  | 409 |  |
| Impact of purchase accounting (b) | 145 |  |  |  |  | 335 |  |  | 367 |  |  |  |  | 692 |  |
| Transaction-related expenses (c) | 85 |  |  |  |  | 138 |  |  | 251 |  |  |  |  | 329 |  |
| Other corporate expenses (d) | 95 |  |  |  |  | 22 |  |  | 130 |  |  |  |  | 128 |  |
| Adjusted EBITDA | $ | 2,459 |  |  | 13 | % |  | $ | 2,180 |  |  | $ | 4,842 |  |  | 22 | % |  | $ | 3,975 |  |

[0001571996-18-000034:mdna:68]
[same as prior period, unchanged from 0001571996-18-000022:mdna:64]

[0001571996-18-000034:mdna:69]
[same as prior period, unchanged from 0001571996-18-000022:mdna:65]

[0001571996-18-000034:mdna:70]
[same as prior period, unchanged from 0001571996-18-000022:mdna:66]

[0001571996-18-000034:mdna:71]
[same as prior period, unchanged from 0001571996-18-000022:mdna:67]

[0001571996-18-000034:mdna:72]
[same as prior period, unchanged from 0001571996-18-000022:mdna:68]

[0001571996-18-000034:mdna:73]
73

[0001571996-18-000034:mdna:74]
[same as prior period, unchanged from 0001571996-18-000022:mdna:70]

[0001571996-18-000034:mdna:75]
[same as prior period, unchanged from 0001571996-18-000022:mdna:71]

[0001571996-18-000034:mdna:76]
The following table summarizes our consolidated results from continuing operations for each of the periods presented.  Unless otherwise indicated, all changes identified for the current-period results represent comparisons to results for the prior corresponding fiscal period.  Multiple accounting standards were adopted during the three months ended May 4, 2018, which resulted in adjustment or reclassification of amounts previously reported.  See Note 1 of the Notes to the Condensed Consolidated Financial Statements included in this report for further information regarding our recently adopted accounting standards.

[0001571996-18-000034:mdna:77]
|  | Three Months Ended |  | Six Months Ended |
|  | August 3, 2018 |  |  |  | August 4, 2017 |  | August 3, 2018 |  |  |  | August 4, 2017 |
|  | Dollars |  | % ofNet Revenue |  | %Change |  | Dollars |  | % ofNet Revenue |  | Dollars |  | % ofNet Revenue |  | %Change |  | Dollars |  | % ofNet Revenue |
|  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 18,149 |  |  | 79.1 | % |  | 20 | % |  | $ | 15,102 |  |  | 77.4 | % |  | $ | 34,820 |  |  | 78.6 | % |  | 21 | % |  | $ | 28,736 |  |  | 76.6 | % |
| Services | 4,793 |  |  | 20.9 | % |  | 8 | % |  | 4,419 |  |  | 22.6 | % |  | 9,478 |  |  | 21.4 | % |  | 8 | % |  | 8,785 |  |  | 23.4 | % |
| Total net revenue | $ | 22,942 |  |  | 100.0 | % |  | 18 | % |  | $ | 19,521 |  |  | 100.0 | % |  | $ | 44,298 |  |  | 100.0 | % |  | 18 | % |  | $ | 37,521 |  |  | 100.0 | % |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product (a) | $ | 3,206 |  |  | 17.7 | % |  | 38 | % |  | $ | 2,327 |  |  | 15.4 | % |  | $ | 6,271 |  |  | 18.0 | % |  | 52 | % |  | $ | 4,138 |  |  | 14.4 | % |
| Services (b) | 2,917 |  |  | 60.9 | % |  | 10 | % |  | 2,641 |  |  | 59.8 | % |  | 5,730 |  |  | 60.5 | % |  | 8 | % |  | 5,287 |  |  | 60.2 | % |
| Total gross margin | $ | 6,123 |  |  | 26.7 | % |  | 23 | % |  | $ | 4,968 |  |  | 25.4 | % |  | $ | 12,001 |  |  | 27.1 | % |  | 27 | % |  | $ | 9,425 |  |  | 25.1 | % |
| Operating expenses | $ | 6,136 |  |  | 26.8 | % |  | 9 | % |  | $ | 5,633 |  |  | 28.8 | % |  | $ | 12,167 |  |  | 27.5 | % |  | 7 | % |  | $ | 11,362 |  |  | 30.3 | % |
| Operating loss | $ | (13 | ) |  | (0.1 | )% |  | 98 | % |  | $ | (665 | ) |  | (3.4 | )% |  | $ | (166 | ) |  | (0.4 | )% |  | 91 | % |  | $ | (1,937 | ) |  | (5.2 | )% |
| Net loss | $ | (461 | ) |  | (2.0 | )% |  | 38 | % |  | $ | (739 | ) |  | (3.8 | )% |  | $ | (999 | ) |  | (2.3 | )% |  | 49 | % |  | $ | (1,942 | ) |  | (5.2 | )% |
| Net loss attributable to Dell Technologies Inc. | $ | (499 | ) |  | (2.2 | )% |  | 32 | % |  | $ | (732 | ) |  | (3.7 | )% |  | $ | (1,135 | ) |  | (2.6 | )% |  | 40 | % |  | $ | (1,903 | ) |  | (5.1 | )% |
| Non-GAAP Financial Information |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 18,167 |  |  | 78.6 | % |  | 20 | % |  | $ | 15,152 |  |  | 76.3 | % |  | $ | 34,855 |  |  | 78.0 | % |  | 21 | % |  | $ | 28,841 |  |  | 75.5 | % |
| Services | 4,955 |  |  | 21.4 | % |  | 5 | % |  | 4,704 |  |  | 23.7 | % |  | 9,810 |  |  | 22.0 | % |  | 5 | % |  | 9,370 |  |  | 24.5 | % |
| Total non-GAAP net revenue | $ | 23,122 |  |  | 100.0 | % |  | 16 | % |  | $ | 19,856 |  |  | 100.0 | % |  | $ | 44,665 |  |  | 100.0 | % |  | 17 | % |  | $ | 38,211 |  |  | 100.0 | % |
| Non-GAAP gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product (a) | $ | 3,970 |  |  | 21.9 | % |  | 20 | % |  | $ | 3,319 |  |  | 21.9 | % |  | $ | 7,888 |  |  | 22.6 | % |  | 28 | % |  | $ | 6,150 |  |  | 21.3 | % |
| Services (b) | 3,096 |  |  | 62.5 | % |  | 5 | % |  | 2,940 |  |  | 62.5 | % |  | 6,097 |  |  | 62.2 | % |  | 3 | % |  | 5,910 |  |  | 63.1 | % |
| Total non-GAAP gross margin | $ | 7,066 |  |  | 30.6 | % |  | 13 | % |  | $ | 6,259 |  |  | 31.5 | % |  | $ | 13,985 |  |  | 31.3 | % |  | 16 | % |  | $ | 12,060 |  |  | 31.6 | % |
| Non-GAAP operating expenses | $ | 4,958 |  |  | 21.4 | % |  | 13 | % |  | $ | 4,393 |  |  | 22.1 | % |  | $ | 9,851 |  |  | 22.1 | % |  | 12 | % |  | $ | 8,769 |  |  | 22.9 | % |
| Non-GAAP operating income | $ | 2,108 |  |  | 9.1 | % |  | 13 | % |  | $ | 1,866 |  |  | 9.4 | % |  | $ | 4,134 |  |  | 9.3 | % |  | 26 | % |  | $ | 3,291 |  |  | 8.6 | % |
| Non-GAAP net income | $ | 1,349 |  |  | 5.8 | % |  | 21 | % |  | $ | 1,112 |  |  | 5.6 | % |  | $ | 2,523 |  |  | 5.6 | % |  | 35 | % |  | $ | 1,873 |  |  | 4.9 | % |
| EBITDA | $ | 1,918 |  |  | 8.3 | % |  | 30 | % |  | $ | 1,477 |  |  | 7.4 | % |  | $ | 3,679 |  |  | 8.2 | % |  | 52 | % |  | $ | 2,417 |  |  | 6.3 | % |
| Adjusted EBITDA | $ | 2,459 |  |  | 10.6 | % |  | 13 | % |  | $ | 2,180 |  |  | 11.0 | % |  | $ | 4,842 |  |  | 10.8 | % |  | 22 | % |  | $ | 3,975 |  |  | 10.4 | % |

[0001571996-18-000034:mdna:78]
[same as prior period, unchanged from 0001571996-18-000022:mdna:74]

[0001571996-18-000034:mdna:79]
[same as prior period, unchanged from 0001571996-18-000022:mdna:75]

[0001571996-18-000034:mdna:80]
[same as prior period, unchanged from 0001571996-18-000022:mdna:76]

[0001571996-18-000034:mdna:81]
Non-GAAP product net revenue, non-GAAP services net revenue, non-GAAP net revenue, non-GAAP product gross margin, non-GAAP services gross margin, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income from continuing operations, EBITDA, and adjusted EBITDA are not measurements of financial performance prepared in accordance with GAAP.  Non-GAAP financial measures as a percentage of revenue are calculated based on non-GAAP net revenue.  See "Non‑GAAP Financial Measures" for additional information about these non-GAAP financial measures, including our reasons for including these measures, material limitations with respect to the usefulness of the measures, and a reconciliation of each non-GAAP financial measure to the most directly comparable GAAP financial measure.

[0001571996-18-000034:mdna:82]
[same as prior period, unchanged from 0001571996-18-000022:mdna:78]

[0001571996-18-000034:mdna:83]
The strong global macro environment has generated strong demand for our products.  Dell Technologies is well-positioned to meet this demand with complementary solutions across our strategically aligned family of businesses.  During both the second quarter and first six months of Fiscal 2019, our net revenue increased 18%.  During the second quarter and first six months of Fiscal 2019, our non-GAAP net revenue increased 16% and 17%, respectively.  The increases in net revenue and non-GAAP net revenue were attributable to increases in net revenue across all three business units.  The momentum in server, client, and VMware that started building last year has continued into Fiscal 2019 and we are seeing progress in the growth of our storage business revenue.

[0001571996-18-000034:mdna:84]
During the second quarter of Fiscal 2019 and Fiscal 2018, our operating loss was $13 million and $0.7 billion, respectively.  The decrease in our operating loss for the second quarter of Fiscal 2019 was primarily attributable to a decrease in amortization of intangible assets and purchase accounting adjustments related to the EMC merger transaction and an increase in operating income for ISG.  During the first six months of Fiscal 2019 and Fiscal 2018, our operating loss was $0.2 billion and $1.9 billion, respectively.  The decrease in our operating loss for the first six months of Fiscal 2019 was primarily attributable to a decrease in amortization of intangible assets and purchase accounting adjustments and an increase in operating income for ISG and CSG.

[0001571996-18-000034:mdna:85]
Amortization of intangible assets and purchase accounting adjustments that impacted operating income totaled $1.7 billion and $2.1 billion for the second quarter of Fiscal 2019 and Fiscal 2018, respectively, and $3.5 billion and $4.3 billion for the first six months of Fiscal 2019 and Fiscal 2018, respectively.  Excluding these costs, transaction-related expenses, and other corporate expenses, non-GAAP operating income during the second quarter of Fiscal 2019 increased 13% to $2.1 billion, and during the first six months of Fiscal 2019 non-GAAP operating income increased 26% to $4.1 billion.  Non-GAAP operating income during the second quarter of Fiscal 2019 increased primarily due to an increase in operating income for ISG.  The increase in non-GAAP operating income for the first six months of Fiscal 2019 was primarily due to an increase in operating income for ISG and CSG.

[0001571996-18-000034:mdna:86]
Cash provided by operating activities was $3.8 billion and $2.1 billion during the first six months of Fiscal 2019 and Fiscal 2018, respectively.  The increase in operating cash flows during the first six months of Fiscal 2019 was driven by business momentum, improved profitability, and working capital discipline.  See "Market Conditions, Liquidity, and Capital Commitments" for further information on our cash flow metrics.

[0001571996-18-000034:mdna:87]
[same as prior period, unchanged from 0001571996-18-000022:mdna:82]

[0001571996-18-000034:mdna:88]
During both the second quarter and first six months of Fiscal 2019, our net revenue increased 18%.  During the second quarter and first six months of Fiscal 2019, our non-GAAP net revenue increased 16% and 17%, respectively.  The increases in net revenue and non-GAAP net revenue were attributable to increases in net revenue across all three business units.  See "Business Unit Results" for further information.

[0001571996-18-000034:mdna:89]
| • | Product Net Revenue — Product net revenue includes revenue from the sale of hardware products and software licenses. During the second quarter of Fiscal 2019, product net revenue and non-GAAP product net revenue both increased 20%, and during the first six months of Fiscal 2019, product net revenue and non-GAAP product net revenue both increased 21%. These increases were attributable to an increase in product revenue for ISG, CSG, and VMware, driven by strength in sales across all product categories. |

[0001571996-18-000034:mdna:90]
| • | Services Net Revenue — Services net revenue includes revenue from our services offerings and support services related to hardware products and software licenses. During the second quarter of Fiscal 2019, services net revenue and non-GAAP services net revenue increased 8% and 5%, respectively. During the first six months of Fiscal 2019, services net revenue |

[0001571996-18-000034:mdna:91]
and non-GAAP services net revenue increased 8% and 5%, respectively.  These increases were primarily due to an increase in services revenue for support and deployment and VMware software maintenance.

[0001571996-18-000034:mdna:92]
From a geographical perspective, net revenue generated by sales to customers in all regions increased in the second quarter and first six months of Fiscal 2019 due to strong performance globally in all three business units.

[0001571996-18-000034:mdna:93]
[same as prior period, unchanged from 0001571996-18-000022:mdna:88]

[0001571996-18-000034:mdna:94]
During the second quarter and first six months of Fiscal 2019, our gross margin increased 23% to $6.1 billion and 27% to $12.0 billion, respectively.  Our gross margin percentage increased 130 basis points to 26.7% and 200 basis points to 27.1%, respectively, during the second quarter and first six months of Fiscal 2019.  The increases in our gross margin were primarily attributable to higher gross margin across all three business units and, to a lesser extent, a decrease in the combined impact of amortization of intangibles and purchase accounting adjustments.  The increases in our gross margin percentage during the second quarter and first six months of Fiscal 2019 were primarily attributable to a decrease in amortization of intangibles and purchase accounting adjustments, offset partially by gross margin rate pressure in CSG and product mix dynamics in ISG due to growth in sales of servers.

[0001571996-18-000034:mdna:95]
Our gross margin for the second quarter and first six months of Fiscal 2019 included the effect of amortization of intangibles and purchase accounting adjustments of $0.9 billion and $1.8 billion, respectively.  In comparison, the impact of amortization of intangibles and purchase accounting adjustments in the second quarter and first six months of Fiscal 2018 totaled $1.3 billion and $2.6 billion, respectively.  Excluding these costs, transaction-related expenses, and other corporate expenses, total non-GAAP gross margin for the second quarter and first six months of Fiscal 2019 increased 13% to $7.1 billion and 16% to $14.0 billion, respectively, and non-GAAP gross margin percentage decreased 90 basis points to 30.6% and 30 basis points to 31.3%, respectively.  The increases in our non-GAAP gross margin were attributable to increases in gross margin across all three business units.  The decreases in our non-GAAP gross margin percentage were primarily due to gross margin rate pressure in CSG and product mix dynamics in ISG due to growth in sales of servers.

[0001571996-18-000034:mdna:96]
| • | Products — During the second quarter of Fiscal 2019, product gross margin increased 38% to $3.2 billion, and product gross margin percentage increased 230 basis points to 17.7%. During the second quarter of Fiscal 2019, non-GAAP product gross margin increased 20% to $4.0 billion, and non-GAAP product gross margin percentage remained constant at 21.9%. These increases in product gross margin and non-GAAP product gross margin were driven primarily by increases in product revenue in all three business units due to strength in sales of ISG servers and storage, CSG commercial products, and VMware software licenses. Product gross margin also benefited from a decrease in the impact of amortization of intangibles and purchase accounting adjustments. Product gross margin percentage increased primarily as a result of a decrease in the impact of amortization of intangibles and purchase accounting adjustments. Non-GAAP product gross margin percentage remained unchanged, due to increases in product gross margin percentages for ISG and VMware that were offset by a decrease in product gross margin percentage for CSG. |

[0001571996-18-000034:mdna:97]
During the first six months of Fiscal 2019 product gross margin increased 52% to $6.3 billion, and product gross margin percentage increased 360 basis points to 18.0%.  During the first six months of Fiscal 2019, non-GAAP product gross margin increased 28% to $7.9 billion, and non-GAAP product gross margin percentage increased 130 basis points to 22.6%.  These increases in product gross margin and non-GAAP product gross margin were driven primarily by increases in product revenue in all three business units due to strength in sales of ISG servers and storage, CSG commercial products, and VMware software licenses.  Product gross margin percentage and non-GAAP product gross margin percentage increased primarily as a result of higher product gross margin percentages for ISG and CSG commercial products.

[0001571996-18-000034:mdna:98]
In the second quarter of Fiscal 2018, we entered into a settlement agreement with a vendor to resolve a dispute regarding past pricing practices.  Our gross margin for the second quarter of Fiscal 2018 included a benefit of $68 million related to receipt of payment under the settlement.  Vendor settlements are allocated to our segments based on the relative amount of affected vendor products sold by each segment.  The $68 million settlement benefit was entirely allocated to CSG.

[0001571996-18-000034:mdna:99]
| • | Services — During the second quarter of Fiscal 2019, services gross margin increased 10% to $2.9 billion, and services gross margin percentage increased 110 basis points to 60.9%. Services gross margin and gross margin percentage increased due to growth in services gross margin across all business units, particularly in VMware services and ISG support and deployment. Services gross margin also benefited from a decrease in purchase accounting adjustments, which totaled $0.2 billion and $0.3 billion, respectively, during the second quarter of Fiscal 2019 and Fiscal 2018. Excluding |

[0001571996-18-000034:mdna:100]
these costs, transaction-related expenses, and other corporate expenses, non-GAAP services gross margin increased 5% to $3.1 billion, and non-GAAP services gross margin percentage remained unchanged at 62.5%.

[0001571996-18-000034:mdna:101]
During the first six months of Fiscal 2019, services gross margin increased 8% to $5.7 billion, and services gross margin percentage increased 30 basis points to 60.5%.  Services gross margin and gross margin percentage increased due to growth in services gross margin across all business units, particularly in VMware services and ISG support and deployment.  Services gross margin also benefited from a decrease in purchase accounting adjustments, which totaled $0.3 billion and $0.6 billion, respectively, during the first six months of Fiscal 2019 and Fiscal 2018.  Excluding these costs, transaction-related expenses, and other corporate expenses, non-GAAP services gross margin increased 3% to $6.1 billion, and non-GAAP services gross margin percentage decreased 90 basis points to 62.2%.

[0001571996-18-000034:mdna:102]
[same as prior period, unchanged from 0001571996-18-000022:mdna:95]

[0001571996-18-000034:mdna:103]
[same as prior period, unchanged from 0001571996-18-000022:mdna:96]

[0001571996-18-000034:mdna:104]
The terms and conditions of our vendor rebate programs are largely based on product volumes and are generally negotiated either at the beginning of the annual or quarterly period, depending on the program.  The timing and amount of vendor rebates and other discounts we receive under the programs may vary from period to period, reflecting changes in the competitive environment.  We monitor our component costs and seek to address the effects of any changes to terms that might arise under our vendor rebate programs.  Our gross margins for the second quarter and first six months of Fiscal 2019 and Fiscal 2018 were not materially affected by any changes to the terms of our vendor rebate programs, as the amounts we received under these programs were generally stable relative to our total net cost.  We are not aware of any significant changes to vendor pricing or rebate programs that may impact our results in the near term.

[0001571996-18-000034:mdna:105]
In addition, we have pursued legal action against certain vendors and are currently involved in negotiations with other vendors regarding their past pricing practices.  We have negotiated settlements with some of these vendors and may have additional settlements in future periods.  These settlements are allocated to our segments based on the relative amount of affected vendor products sold by each segment.  As discussed above, a pricing settlement was recorded in the second quarter of Fiscal 2018 that benefited product gross margins by $68 million in the second quarter and first six months of Fiscal 2018.  No such settlements were recorded in the second quarter and first six months of Fiscal 2019 that would have a material impact on product gross margins in the current quarter or affect comparability with product gross margin in the second quarter and first six months of Fiscal 2018.

[0001571996-18-000034:mdna:106]
[same as prior period, unchanged from 0001571996-18-000022:mdna:100]

[0001571996-18-000034:mdna:107]
[same as prior period, unchanged from 0001571996-18-000022:mdna:101]

[0001571996-18-000034:mdna:108]
|  | Three Months Ended |  | Six Months Ended |
|  | August 3, 2018 |  |  |  | August 4, 2017 |  | August 3, 2018 |  |  |  | August 4, 2017 |
|  | Dollars |  | % ofNet Revenue |  | %Change |  | Dollars |  | % ofNet Revenue |  | Dollars |  | % ofNet Revenue |  | %Change |  | Dollars |  | % ofNet Revenue |
|  | (in millions, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative | $ | 4,961 |  |  | 21.7 | % |  | 9 | % |  | $ | 4,540 |  |  | 23.2 | % |  | $ | 9,905 |  |  | 22.4 | % |  | 8 | % |  | $ | 9,136 |  |  | 24.4 | % |
| Research and development | 1,175 |  |  | 5.1 | % |  | 8 | % |  | 1,093 |  |  | 5.6 | % |  | 2,262 |  |  | 5.1 | % |  | 2 | % |  | 2,226 |  |  | 5.9 | % |
| Total operating expenses | $ | 6,136 |  |  | 26.8 | % |  | 9 | % |  | $ | 5,633 |  |  | 28.8 | % |  | $ | 12,167 |  |  | 27.5 | % |  | 7 | % |  | $ | 11,362 |  |  | 30.3 | % |
| Other Financial Information |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP operating expenses | $ | 4,958 |  |  | 21.4 | % |  | 13 | % |  | $ | 4,393 |  |  | 22.1 | % |  | $ | 9,851 |  |  | 22.1 | % |  | 12 | % |  | $ | 8,769 |  |  | 22.9 | % |

[0001571996-18-000034:mdna:109]
During the second quarter and first six months of Fiscal 2019, total operating expenses increased 9% and 7%, respectively.  Our operating expenses include the impact of purchase accounting, amortization of intangible assets, transaction-related expenses, and other corporate expenses.  In aggregate, these items totaled $1.2 billion for both the second quarter of Fiscal 2019 and Fiscal 2018, and $2.3 billion and $2.6 billion for the first six months of Fiscal 2019 and Fiscal 2018, respectively.  Excluding these costs, total non-GAAP operating expenses for the second quarter and first six months of Fiscal 2019 increased 13% and 12%, respectively.  The increases in operating expenses and non-GAAP operating expenses were primarily due to an increase in selling expenses associated with our revenue growth and sales headcount.

[0001571996-18-000034:mdna:110]
| • | Selling, General, and Administrative — Selling, general, and administrative ("SG&A") expenses increased 9% and 8%, respectively, during the second quarter and first six months of Fiscal 2019. The increases in SG&A expenses were primarily driven by investments in our go-to-market capabilities and higher performance-driven commission costs. |

[0001571996-18-000034:mdna:111]
| • | Research and Development — Research and development ("R&D") expenses are primarily composed of personnel-related expenses related to product development. R&D expenses as a percentage of net revenue for the second quarter of Fiscal 2019 and Fiscal 2018 were approximately 5.1% and 5.6%, respectively. In comparison, R&D expenses as a percentage of net revenue for the first six months of Fiscal 2019 and Fiscal 2018 were approximately 5.1% and 5.9%, respectively. The decreases in R&D expenses as a percentage of net revenue was attributable to revenue growth that outpaced the scale of R&D investments. As our industry continues to change and as the needs of our customers evolve, we intend to support R&D initiatives to innovate and introduce new and enhanced solutions into the market. |

[0001571996-18-000034:mdna:112]
We continue to make investments designed to enable growth, particularly in our sales force, marketing, and R&D, while balancing our efforts to drive cost efficiencies in the business.

[0001571996-18-000034:mdna:113]
[same as prior period, unchanged from 0001571996-18-000022:mdna:107]

[0001571996-18-000034:mdna:114]
During the second quarter of Fiscal 2019, our operating loss decreased 98% to $13 million.  The decrease in our operating loss for the second quarter of Fiscal 2019 was primarily attributable to a decrease in amortization of intangible assets and purchase accounting adjustments and an increase in operating income for ISG.  During the first six months of Fiscal 2019, our operating loss decreased to 91% to $0.2 billion.  The decrease in our operating loss for the first six months of Fiscal 2019 was primarily attributable to a decrease in amortization of intangible assets and purchase accounting adjustments and an increase in operating income for ISG and CSG.

[0001571996-18-000034:mdna:115]
Amortization of intangible assets and purchase accounting adjustments that impacted operating income totaled $1.7 billion and $2.1 billion for second quarter of Fiscal 2019 and Fiscal 2018, respectively, and $3.5 billion and $4.3 billion for the first six months of Fiscal 2019 and Fiscal 2018, respectively.  Excluding these costs, transaction-related expenses, and other corporate

[0001571996-18-000034:mdna:116]
expenses, non-GAAP operating income during the second quarter of Fiscal 2019 increased 13% to $2.1 billion, and non-GAAP operating income increased 26% to $4.1 billion during the first six months of Fiscal 2019.  Non-GAAP operating income during the second quarter of Fiscal 2019 increased primarily due to an increase in operating income for ISG.  The increase in non-GAAP operating income for the first six months of Fiscal 2019 was primarily due to an increase in operating income for ISG and CSG.

[0001571996-18-000034:mdna:117]
[same as prior period, unchanged from 0001571996-18-000022:mdna:109]

[0001571996-18-000034:mdna:118]
[same as prior period, unchanged from 0001571996-18-000022:mdna:110]

[0001571996-18-000034:mdna:119]
|  | Three Months Ended |  | Six Months Ended |
|  | August 3, 2018 |  | August 4, 2017 |  | August 3, 2018 |  | August 4, 2017 |
|  | (in millions) |
| Interest and other, net: |  |  |  |  |  |  |  |  |  |  |  |
| Investment income, primarily interest | $ | 85 |  |  | $ | 47 |  |  | $ | 163 |  |  | $ | 85 |  |
| Gain (loss) on investments, net | 139 |  |  | 26 |  |  | 246 |  |  | 25 |  |
| Interest expense | (622 | ) |  | (598 | ) |  | (1,218 | ) |  | (1,195 | ) |
| Foreign exchange | (34 | ) |  | (15 | ) |  | (111 | ) |  | (42 | ) |
| Other | (23 | ) |  | (5 | ) |  | (5 | ) |  | 10 |  |
| Total interest and other, net | $ | (455 | ) |  | $ | (545 | ) |  | $ | (925 | ) |  | $ | (1,117 | ) |

[0001571996-18-000034:mdna:120]
Effective in the first quarter of Fiscal 2019, we adopted the new accounting guidance for "Recognition and Measurement of Financial Assets and Financial Liabilities."  As a result, we record in interest and other, net, changes in the fair value of our publicly-traded strategic investments and changes in the value of our strategic investments without readily determinable fair values when adjusted to fair value upon observable price changes or impairment.  During the second quarter and first six months of Fiscal 2019, changes in interest and other, net were favorable by $90 million and $192 million, respectively, primarily due gains on strategic investments.  See Note 1 and Note 4 of the Notes to the Condensed Consolidated Financial Statements included in this report for further information regarding our recently adopted accounting standards and our investments, respectively.

[0001571996-18-000034:mdna:121]
[same as prior period, unchanged from 0001571996-18-000022:mdna:113]

[0001571996-18-000034:mdna:122]
For the second quarter and first six months of Fiscal 2019, our effective income tax rates were 1.5% and 8.4%, respectively, on pre-tax losses of $0.5 billion and $1.1 billion, respectively.  For the second quarter and first six months of Fiscal 2018, our effective income tax rates were 38.9% and 36.4%, respectively, on pre-tax losses of $1.2 billion and $3.1 billion, respectively.  The changes in our effective income tax rates for the second quarter and first six months of Fiscal 2019 were primarily attributable to impacts of U.S. Tax Reform.  The change in our effective income tax rate for the first six months of Fiscal 2019, was also impacted by discrete tax benefits resulting from the impact of adopting the new revenue standard.

[0001571996-18-000034:mdna:123]
[same as prior period, unchanged from 0001571996-18-000022:mdna:115]

[0001571996-18-000034:mdna:124]
GAAP requires the effect of a change in tax laws to be recognized in the period that includes the enactment date.  Accordingly, for Fiscal 2018 we recognized a provisional tax benefit of $0.5 billion related to U.S. Tax Reform, primarily driven by a $1.5 billion tax benefit related to the remeasurement of deferred tax assets and liabilities, offset by $1.0 billion of current and future income tax expenses related to the Transition Tax.  Our provisional benefit will be adjusted once the analysis is complete, but no later than the fourth quarter of Fiscal 2019.  We continue to collect and process the data necessary to complete the analysis.  In addition, the U.S. Treasury Department issued proposed regulations as guidance for the Transition Tax on August 1, 2018.  We are also evaluating the impact of this guidance on the calculation of our provisional benefit.  As a result, no adjustments have been made to the provisional amount recorded for Fiscal 2018.  Revisions to our provisional estimates may be material.  Any final guidance to be issued by the U.S. Treasury Department also could further affect the provisional calculation.

[0001571996-18-000034:mdna:125]
Additionally, when we file our U.S. tax return for the fiscal year ended February 2, 2018, any changes to the tax positions for temporary differences compared to the estimates used for the provisional estimate will result in an adjustment of the estimated tax benefit recorded for Fiscal 2018.

[0001571996-18-000034:mdna:126]
Our effective income tax rate can fluctuate depending on the geographic distribution of our worldwide earnings, as our foreign earnings are generally taxed at lower rates than in the United States.  The differences between our effective income tax rate and the U.S. federal statutory rate of 21% principally result from the geographical distribution of income and differences between the book and tax treatment of certain items.  In certain jurisdictions, our tax rate is significantly less than the applicable statutory rate as a result of tax holidays.  The majority of our foreign income that is subject to these tax holidays and lower tax rates is attributable to Singapore, China, and Malaysia.  A significant portion of these income tax benefits is related to a tax holiday that will expire at the end of Fiscal 2019.  We are currently seeking new terms for the affected subsidiary beyond Fiscal 2019, and it is uncertain whether any terms will be agreed upon.  Our other tax holidays will expire in whole or in part during Fiscal 2019 through Fiscal 2023.  Many of these tax holidays and reduced tax rates may be extended when certain conditions are met or may be terminated early if certain conditions are not met.

[0001571996-18-000034:mdna:127]
For further discussion regarding tax matters, including the status of income tax audits, see Note 12 of the Notes to the Condensed Consolidated Financial Statements included in this report.

[0001571996-18-000034:mdna:128]
[same as prior period, unchanged from 0001571996-18-000022:mdna:119]

[0001571996-18-000034:mdna:129]
During the second quarter and first six months of Fiscal 2019, net loss decreased 38% to $0.5 billion and 49% to $1.0 billion, respectively.  The decreases in net loss during the second quarter and first six months of Fiscal 2019 were primarily attributable to a decrease in operating loss and, to a lesser extent, a decrease in interest and other, net expense, which was partially offset by a decrease in tax benefit.

[0001571996-18-000034:mdna:130]
Net loss for the second quarter and first six months of Fiscal 2019 included amortization of intangible assets, the impact of purchase accounting, transaction-related expenses, and other corporate expenses.  Excluding these costs and the related tax impacts, non-GAAP net income increased 21% to $1.3 billion and 35% to $2.5 billion during the second quarter and first six months of Fiscal 2019, respectively.  The increases in non-GAAP net income were primarily attributable to an increase in operating income and a decrease in interest and other, net expense, which was partially offset by an increase in income tax expense.

[0001571996-18-000034:mdna:131]
[same as prior period, unchanged from 0001571996-18-000022:mdna:121]

[0001571996-18-000034:mdna:132]
During the second quarter and first six months of Fiscal 2019, net income attributable to non-controlling interests was $38 million and $136 million, respectively, compared to a net loss attributable to non-controlling interests of $7 million and $39 million, respectively, during the second quarter and first six months of Fiscal 2018.  Net income or loss attributable to non-controlling interests consisted of net income or loss attributable to our non-controlling interests in VMware, Inc., Pivotal, and SecureWorks.  For more information about our non-controlling interests, see Note 14 of the Notes to the Condensed Consolidated Financial Statements included in this report.

[0001571996-18-000034:mdna:133]
[same as prior period, unchanged from 0001571996-18-000022:mdna:123]

[0001571996-18-000034:mdna:134]
Net loss attributable to Dell Technologies Inc. represents net loss and an adjustment for non-controlling interests.  During the second quarter of Fiscal 2019 and Fiscal 2018, net loss attributable to Dell Technologies Inc. was $0.5 billion and $0.7 billion, respectively, compared to $1.1 billion and $1.9 billion, respectively, during the first six months of Fiscal 2019 and Fiscal 2018.  The decreases in net loss attributable to Dell Technologies Inc. were primarily attributable to decreases in net loss over both periods.

[0001571996-18-000034:mdna:135]
[same as prior period, unchanged from 0001571996-18-000022:mdna:125]

[0001571996-18-000034:mdna:136]
[same as prior period, unchanged from 0001571996-18-000022:mdna:126]

[0001571996-18-000034:mdna:137]
During the first quarter of Fiscal 2019, we made certain segment reporting changes, which included the movement of Virtustream results from ISG to other businesses.  None of these changes impacted our previously reported consolidated financial results, but our prior period segment results have been recast to reflect this change.

[0001571996-18-000034:mdna:138]
[same as prior period, unchanged from 0001571996-18-000022:mdna:128]

[0001571996-18-000034:mdna:139]
[same as prior period, unchanged from 0001571996-18-000022:mdna:129]

[0001571996-18-000034:mdna:140]
|  | Three Months Ended |  | Six Months Ended |
|  | August 3, 2018 |  | % Change |  | August 4, 2017 |  | August 3, 2018 |  | % Change |  | August 4, 2017 |
|  | (in millions, except percentages) |
| Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Servers and networking | $ | 5,061 |  |  | 34% |  | $ | 3,777 |  |  | $ | 9,646 |  |  | 37% |  | $ | 7,033 |  |
| Storage | 4,166 |  |  | 13% |  | 3,690 |  |  | 8,248 |  |  | 12% |  | 7,395 |  |
| Total ISG net revenue | $ | 9,227 |  |  | 24% |  | $ | 7,467 |  |  | $ | 17,894 |  |  | 24% |  | $ | 14,428 |  |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| ISG operating income | $ | 1,012 |  |  | 56% |  | $ | 647 |  |  | $ | 1,951 |  |  | 69% |  | $ | 1,153 |  |
| % of segment net revenue | 11.0 | % |  |  |  | 8.7 | % |  | 10.9 | % |  |  |  | 8.0 | % |

[0001571996-18-000034:mdna:141]
Net Revenue — During both the second quarter and first six months of Fiscal 2019, ISG net revenue increased 24%, primarily due to an increase in sales of servers and networking as well as an increase in sales of storage.  Revenue from servers and networking increased 34% and 37%, respectively, during the second quarter and first six months of Fiscal 2019, driven by an increase in both average selling price and units sold of our PowerEdge servers.  Average selling prices increased due to the sale of servers with higher memory and storage content, which is driven by customer demand for servers that enable big data analytics and software-defined solutions, as well as increased component costs.  Storage revenue increased 13% and 12%, respectively, during the second quarter and first six months of Fiscal 2019 due to accumulated demand from the fourth quarter of Fiscal 2018 that was realized in the first half of the year, as well as strong growth in our unstructured storage array solutions and our hyper-converged infrastructure products.  We were encouraged by the improved demand for our storage products, where we have been making go-to-market investments and enhancements to our solutions offerings.  Component costs during the second quarter and first six months of Fiscal 2019 were slightly inflationary in the aggregate for ISG, and we continue to monitor our pricing in response to the current component cost environment.  However, we expect the aggregate ISG component cost environment to become slightly deflationary through the second half of Fiscal 2019.

[0001571996-18-000034:mdna:142]
In ISG, we continue to see interest in flexible consumption models by our customers as they seek to build greater flexibility into their cost structures.  We generally provide these solutions under multi-year contracts that typically result in recognition of revenue over the term of the arrangement.  We expect these flexible consumption models will further strengthen our customer relationships and will build more predictable revenue streams over time.

[0001571996-18-000034:mdna:143]
From a geographical perspective, net revenue attributable to ISG increased across all regions during the second quarter and first six months of Fiscal 2019.

[0001571996-18-000034:mdna:144]
Operating Income — During the second quarter and first six months of Fiscal 2019, ISG operating income increased 230 basis points to 11.0% and 290 basis points to 10.9%, respectively, primarily due to a decrease in operating expenses as a percentage of revenue.  Despite the investments we have been making in our go-to-market capabilities and solutions offerings, operating

[0001571996-18-000034:mdna:145]
expenses decreased as a percentage of revenue as a result of revenue growth that outpaced the scale of these investments.  The benefit from the decrease in operating expense percentage was partially offset by a decrease in ISG gross margin percentage due to a shift in product mix to servers, which typically have a lower gross margin than storage products.

[0001571996-18-000034:mdna:146]
[same as prior period, unchanged from 0001571996-18-000022:mdna:135]

[0001571996-18-000034:mdna:147]
[same as prior period, unchanged from 0001571996-18-000022:mdna:136]

[0001571996-18-000034:mdna:148]
|  | Three Months Ended |  | Six Months Ended |
|  | August 3, 2018 |  | % Change |  | August 4, 2017 |  | August 3, 2018 |  | % Change |  | August 4, 2017 |
|  | (in millions, except percentages) |
| Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 8,109 |  |  | 13% |  | $ | 7,207 |  |  | $ | 15,472 |  |  | 14% |  | $ | 13,549 |  |
| Consumer | 3,019 |  |  | 14% |  | 2,659 |  |  | 5,927 |  |  | 10% |  | 5,365 |  |
| Total CSG net revenue | $ | 11,128 |  |  | 13% |  | $ | 9,866 |  |  | $ | 21,399 |  |  | 13% |  | $ | 18,914 |  |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| CSG operating income | $ | 425 |  |  | (20)% |  | $ | 528 |  |  | $ | 958 |  |  | 12% |  | $ | 853 |  |
| % of segment net revenue | 3.8 | % |  |  |  | 5.4 | % |  | 4.5 | % |  |  |  | 4.5 | % |

[0001571996-18-000034:mdna:149]
Net Revenue — During both the second quarter and first six months of Fiscal 2019, CSG net revenue increased 13%, driven by continued strong demand and increased sales volume across both commercial and consumer categories in notebooks, workstations, and desktops, as we were able to deliver strong performance in a better than expected demand environment.  Overall average selling prices were higher, driven by an increase in both the commercial and consumer product categories, as we managed our pricing in response to the inflationary cost environment over the past year.  We expect the cost environment for CSG to be deflationary for the remainder of Fiscal 2019.

[0001571996-18-000034:mdna:150]
From a geographical perspective, net revenue attributable to CSG increased across all regions during the second quarter and first six months of Fiscal 2019.

[0001571996-18-000034:mdna:151]
Operating Income — During the second quarter of Fiscal 2019, CSG operating income as a percentage of net revenue decreased 160 basis points to 3.8%.  The changes in our CSG operating income percentage included a $68 million favorable impact from a vendor pricing settlement received during the second quarter of Fiscal 2018, which resulted in an incremental benefit of 70 basis points to our operating income percentage during the period.  Excluding the benefit of the vendor settlement to operating income in the second quarter of Fiscal 2018, we experienced a decrease of 90 basis points in our operating income percentage.  This decrease was primarily due to higher component costs that negatively impacted CSG gross margin and to an increase in CSG operating expense as a percentage of revenue resulting from higher performance-driven commission costs and marketing expense related to our net revenue growth.

[0001571996-18-000034:mdna:152]
During the first six months of Fiscal 2019, CSG operating income as a percentage of net revenue and was unchanged at 4.5%.  The vendor pricing settlement received during the second quarter of Fiscal 2018 resulted in an incremental benefit of 40 basis points to our operating income percentage during the first six months of Fiscal 2018.  Excluding the benefit of the vendor settlement to operating income in the second quarter of Fiscal 2018, we experienced a decrease of 40 basis points in CSG operating income.  The decrease was attributable to higher component costs that negatively impacted CSG gross margin and to an increase in CSG operating expense as a percentage of revenue due to higher performance-driven commission costs and marketing expense related to our net revenue growth.

[0001571996-18-000034:mdna:153]
[same as prior period, unchanged from 0001571996-18-000022:mdna:142]

[0001571996-18-000034:mdna:154]
The following table presents net revenue and operating income attributable to VMWare for the respective periods:

[0001571996-18-000034:mdna:155]
|  | Three Months Ended |  | Six Months Ended |
|  | August 3, 2018 |  | % Change |  | August 4, 2017 |  | August 3, 2018 |  | % Change |  | August 4, 2017 |
|  | (in millions, except percentages) |
| Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| VMware net revenue | $ | 2,194 |  |  | 11% |  | $ | 1,984 |  |  | $ | 4,222 |  |  | 11% |  | $ | 3,802 |  |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| VMware operating income | $ | 736 |  |  | 1% |  | $ | 728 |  |  | $ | 1,349 |  |  | 1% |  | $ | 1,339 |  |
| % of segment net revenue | 33.5 | % |  |  |  | 36.7 | % |  | 32.0 | % |  |  |  | 35.2 | % |

[0001571996-18-000034:mdna:156]
Net Revenue — VMware net revenue primarily consisted of revenue from the sale of software licenses under perpetual licenses, related software maintenance and support, training, consulting services, and hosted services.  VMware net revenue during both the second quarter and first six months of Fiscal 2019 increased 11%, primarily due to growth in software license revenue and sales of maintenance services.  Software license revenue benefited from broad-based growth across the product portfolio.  Software maintenance revenue benefited from strong renewals, revenue recognized from maintenance contracts sold in prior periods, and new maintenance contracts sold during the period.

[0001571996-18-000034:mdna:157]
From a geographical perspective, approximately half of VMware net revenue during the second quarter and first six months of Fiscal 2019 was generated by sales to customers in the United States.  VMware net revenue for the second quarter and first six months of Fiscal 2019 benefited from growth in all major geographies.

[0001571996-18-000034:mdna:158]
Operating Income — During the second quarter and first six months of Fiscal 2019, VMware operating income as a percentage of net revenue decreased 320 basis points to 33.5% and 320 basis points to 32.0%, respectively, driven by an increase in operating expenses as a percentage of revenue due to an increase in compensation-related expense associated with sales and sales support, resulting from increased performance-driven commission costs and headcount, as well as an increase in R&D expenses.

[0001571996-18-000034:mdna:159]
[same as prior period, unchanged from 0001571996-18-000022:mdna:148]

[0001571996-18-000034:mdna:160]
[same as prior period, unchanged from 0001571996-18-000022:mdna:149]

[0001571996-18-000034:mdna:161]
[same as prior period, unchanged from 0001571996-18-000022:mdna:150]

[0001571996-18-000034:mdna:162]
We sell products and services directly to customers and through a variety of sales channels, including retail distribution.  Our accounts receivable, net, was $11.2 billion and $11.7 billion as of August 3, 2018 and February 2, 2018, respectively.  We maintain an allowance for doubtful accounts to cover receivables that may be deemed uncollectible.  The allowance for losses is based on a provision for accounts that are collectively evaluated based on historical bad debt experience as well as specific identifiable customer accounts that are deemed at risk.  As of August 3, 2018 and February 2, 2018, the allowance for doubtful accounts was $102 million and $103 million, respectively.  Based on our assessment, we believe that we are adequately reserved for expected credit losses.  We monitor the aging of our accounts receivable and continue to take actions to reduce our exposure to credit losses.

[0001571996-18-000034:mdna:163]
[same as prior period, unchanged from 0001571996-18-000022:mdna:152]

[0001571996-18-000034:mdna:164]
Dell Financial Services and its affiliates ("DFS") offers a wide range of financial services, including originating, collecting, and servicing customer receivables primarily related to the purchase of Dell Technologies' products and services.  In some cases, we also offer financing on the purchase of third-party technology products that complement our portfolio of products and services.  New financing originations were $1.9 billion and $1.6 billion for the second quarter of Fiscal 2019 and Fiscal 2018, respectively, and $3.6 billion and $2.7 billion for the first six months of Fiscal 2019 and Fiscal 2018, respectively.  As of August 3, 2018 and February 2, 2018, our financing receivables, net were $8.2 billion and $7.6 billion, respectively.

[0001571996-18-000034:mdna:165]
We have securitization facilities to fund revolving loans and fixed-term leases and loans through consolidated special purpose entities, referred to as SPEs, which we account for as secured borrowings.  We transfer certain U.S. and European customer financing receivables to these SPEs, whose purpose is to facilitate the funding of customer receivables through financing arrangements with multi-seller conduits that issue asset-backed debt securities in the capital markets and to private investors.  During the second quarter of Fiscal 2019 and Fiscal 2018, we transferred $1.2 billion and $1.0 billion, respectively, to these SPEs, and during the first six months of Fiscal 2019 and Fiscal 2018, we transferred $2.5 billion and $1.9 billion, respectively, to the SPEs.  The DFS debt related to all of our securitization facilities included as secured borrowings was $4.6 billion and $3.9 billion as of August 3, 2018 and February 2, 2018, respectively.  In addition, the carrying amount of the corresponding financing receivables was $5.2 billion and $4.6 billion as of August 3, 2018 and February 2, 2018, respectively.

[0001571996-18-000034:mdna:166]
We maintain an allowance to cover expected financing receivable credit losses and evaluate credit loss expectations based on our total portfolio.  For the second quarter of Fiscal 2019 and Fiscal 2018, the principal charge-off rate for our total portfolio was 1.4% and 1.8%, respectively.  For the first six months of Fiscal 2019 and Fiscal 2018, the principal charge-off rate for our total portfolio was 1.3% and 1.7%, respectively.  The credit quality of our financing receivables has improved in recent years due to an overall improvement in the credit environment and as the mix of high-quality commercial accounts in our portfolio has continued to increase.  The allowance for losses is determined based on various factors, including historical and anticipated experience, past due receivables, receivable type, and customer risk profile.  As of August 3, 2018 and February 2, 2018, the allowance for financing receivable losses was $126 million and $145 million, respectively.  In general, the loss rates on our financing receivables have improved over the periods presented.  We expect relatively stable loss rates in future periods, with movements in these rates being primarily driven by seasonality and a continued shift in portfolio composition to lower risk commercial assets.  We continue to monitor broader economic indicators and their potential impact on future loss performance.  We have an extensive process to manage our exposure to customer credit risk, including active management of credit lines and our collection activities.  We also sell selected fixed-term financing receivables to unrelated third parties on a periodic basis, primarily to manage certain concentrations of customer credit exposure.  Based on our assessment of the customer financing receivables, we believe that we are adequately reserved.

[0001571996-18-000034:mdna:167]
[same as prior period, unchanged from 0001571996-18-000022:mdna:156]

[0001571996-18-000034:mdna:168]
[same as prior period, unchanged from 0001571996-18-000022:mdna:157]

[0001571996-18-000034:mdna:169]
As of August 3, 2018, we had no off-balance sheet arrangements that have or are reasonably likely to have a current or future material effect on our financial condition or results of operations.

[0001571996-18-000034:mdna:170]
[same as prior period, unchanged from 0001571996-18-000022:mdna:159]

[0001571996-18-000034:mdna:171]
[same as prior period, unchanged from 0001571996-18-000022:mdna:160]

[0001571996-18-000034:mdna:172]
[same as prior period, unchanged from 0001571996-18-000022:mdna:161]

[0001571996-18-000034:mdna:173]
[same as prior period, unchanged from 0001571996-18-000022:mdna:162]

[0001571996-18-000034:mdna:174]
[same as prior period, unchanged from 0001571996-18-000022:mdna:163]

[0001571996-18-000034:mdna:175]
[same as prior period, unchanged from 0001571996-18-000022:mdna:164]

[0001571996-18-000034:mdna:176]
[same as prior period, unchanged from 0001571996-18-000022:mdna:165]

[0001571996-18-000034:mdna:177]
[same as prior period, unchanged from 0001571996-18-000022:mdna:166]

[0001571996-18-000034:mdna:178]
To support our ongoing business operations, we rely on operating cash flows as our primary source of liquidity.  We monitor the efficiency of our balance sheet to ensure that we have adequate liquidity to support our strategic initiatives.  In addition to internally generated cash, we have access to other capital sources to finance our strategic initiatives and fund growth in our financing operations.  As of August 3, 2018, we had $15.3 billion of total cash and cash equivalents, just over half of which was held outside of the United States.  Our strategy is to deploy capital from any potential source, whether internally generated cash or debt, depending on the adequacy and availability of that source of capital and whether it can be accessed in a cost-effective manner.

[0001571996-18-000034:mdna:179]
A significant portion of our income is earned in non-U.S. jurisdictions.  Prior to the enactment of U.S. Tax Reform as discussed above in "Results of Operations — Income and Other Taxes", earnings available to be repatriated to the United States would be subject to U.S. federal income tax, less applicable foreign tax credits.  U.S. Tax Reform fundamentally changes the U.S. approach to taxation of foreign earnings to a modified territorial tax system, which generally allows companies to make distributions of non-U.S. earnings to the United States without incurring additional U.S. federal tax.  However, local and U.S. state taxes may still apply.  We have provided for future tax liabilities on income earned in non-U.S. jurisdictions, except for foreign earnings that are considered indefinitely reinvested outside of the United States.

[0001571996-18-000034:mdna:180]
During the second half of Fiscal 2019, as discussed above in "Introduction — Class V Transaction," we expect to complete a transaction in which the issued and outstanding shares of Class V Common Stock will be exchanged for shares of Class C Common Stock or cash at the stockholder’s election.  The Merger Agreement provides that no more than $9 billion of cash, in the aggregate, will be paid to holders of Class V Common Stock in connection with the Class V transaction.

[0001571996-18-000034:mdna:181]
To fund the cash payment to stockholders, VMware, Inc. declared a conditional $11 billion one-time special cash dividend (the "Special Dividend"), payable pro-rata to VMware, Inc. stockholders as of the dividend record date and in connection with the closing of the proposed Class V transaction.  The payment of the dividend is subject to the satisfaction of the conditions to the Class V transaction and other specified conditions.  We will fund all, or substantially all, of the cash consideration to be paid in the Class V transaction from our portion of the proceeds of the Special Dividend.  Our cash, cash equivalents, and investments

[0001571996-18-000034:mdna:182]
85

[0001571996-18-000034:mdna:183]
will decline significantly, commensurate with the cash required to fund this transaction.  VMware, Inc. has advised us that, following its payment of the Special Dividend, VMware, Inc. expects to return to its historical capital allocation policy.

[0001571996-18-000034:mdna:184]
The following table summarizes our cash and cash equivalents as well as our available borrowings as of August 3, 2018 and February 2, 2018:

[0001571996-18-000034:mdna:185]
|  | August 3, 2018 |  | February 2, 2018 |
|  | (in millions) |
| Cash and cash equivalents, and available borrowings: |  |  |  |
| Cash and cash equivalents (a) | $ | 15,312 |  |  | $ | 13,942 |  |
| Remaining available borrowings under revolving credit facilities | 4,914 |  |  | 4,875 |  |
| Total cash, cash equivalents, and available borrowings | $ | 20,226 |  |  | $ | 18,817 |  |

[0001571996-18-000034:mdna:186]
[same as prior period, unchanged from 0001571996-18-000022:mdna:172]

[0001571996-18-000034:mdna:187]
(a)  Of the $15.3 billion of cash and cash equivalents as of August 3, 2018, $8.1 billion was held by VMware, Inc.  Of the $13.9 billion of cash and cash equivalents as of February 2, 2018, $6.0 billion was held by VMware, Inc.  Amounts exclude restricted cash.

[0001571996-18-000034:mdna:188]
Our revolving credit facilities include the Revolving Credit Facility and China Revolving Credit Facility.  Available borrowings under these facilities are reduced by draws on the facility and, under the Revolving Credit Facility, outstanding letters of credit.  As of August 3, 2018, there were no borrowings outstanding under either facility and remaining available borrowings totaled approximately $3.8 billion.  These available borrowings may be used periodically for general corporate purposes.

[0001571996-18-000034:mdna:189]
The VMware Revolving Credit Facility and the Pivotal Revolving Credit Facility have maximum aggregate borrowings of $1.0 billion and $100 million, respectively.  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc., Pivotal, and their respective subsidiaries.  As of August 3, 2018, $1.0 billion was available under the VMware Revolving Credit Facility and $100 million was available under the Pivotal Revolving Credit Facility.

[0001571996-18-000034:mdna:190]
[same as prior period, unchanged from 0001571996-18-000022:mdna:176]

[0001571996-18-000034:mdna:191]
We believe that our current cash and cash equivalents, along with cash that will be provided by future operations and borrowings expected to be available under the Revolving Credit Facility and China Revolving Credit Facility, will be sufficient over at least the next twelve months to fund our operations, capital expenditures, share repurchases, debt service requirements, and other corporate needs.

[0001571996-18-000034:mdna:192]
[same as prior period, unchanged from 0001571996-18-000022:mdna:178]

[0001571996-18-000034:mdna:193]
The following table summarizes our outstanding debt as of August 3, 2018 and February 2, 2018:

[0001571996-18-000034:mdna:194]
|  | August 3, 2018 |  | February 2, 2018 |
|  | (in millions) |
| Restricted Subsidiary Debt |  |  |  |
| Core debt: |  |  |  |
| Senior Secured Credit Facilities and First Lien Notes | $ | 30,459 |  |  | $ | 30,595 |  |
| Unsecured Notes and Debentures | 1,952 |  |  | 2,452 |  |
| Senior Notes | 3,250 |  |  | 3,250 |  |
| EMC Notes | 3,000 |  |  | 5,500 |  |
| DFS allocated debt | (1,563 | ) |  | (1,892 | ) |
| Total core debt | 37,098 |  |  | 39,905 |  |
| DFS related debt: |  |  |  |
| DFS debt | 5,586 |  |  | 4,796 |  |
| DFS allocated debt | 1,563 |  |  | 1,892 |  |
| Total DFS related debt | 7,149 |  |  | 6,688 |  |
| Other | 2,057 |  |  | 2,054 |  |
| Unrestricted Subsidiary Debt |  |  |  |
| VMware Notes | 4,000 |  |  | 4,000 |  |
| Other | — |  |  | 47 |  |
| Total unrestricted subsidiary debt | 4,000 |  |  | 4,047 |  |
| Total debt, principal amount | 50,304 |  |  | 52,694 |  |
| Carrying value adjustments | (784 | ) |  | (823 | ) |
| Total debt, carrying value | $ | 49,520 |  |  | $ | 51,871 |  |

[0001571996-18-000034:mdna:195]
The outstanding principal amount of our debt was $50.3 billion as of August 3, 2018, which included core debt of $37.1 billion.  We define core debt as the total principal amount of our debt, less DFS related debt, other debt, and unrestricted subsidiary debt.

[0001571996-18-000034:mdna:196]
DFS related debt primarily represents debt from securitization and structured financing programs.  To fund expansion of the DFS business, we balance the use of our securitization and structured financing programs with other sources of liquidity.  We approximate the amount of our debt used to fund the DFS business by applying a 7:1 debt to equity ratio to our financing receivables balance, based on the underlying credit quality of the assets.  See Note 5 of the Notes to the Condensed Consolidated Financial Statements included in this report for more information about our DFS debt.

[0001571996-18-000034:mdna:197]
As of August 3, 2018 and February 2, 2018, other debt primarily consisted of the $2.0 billion Margin Loan Facility.

[0001571996-18-000034:mdna:198]
[same as prior period, unchanged from 0001571996-18-000022:mdna:184]

[0001571996-18-000034:mdna:199]
Our requirements for cash to pay principal and interest on our debt increased significantly due to the borrowings we incurred to finance the EMC merger transaction.  We have made good progress in paying down core debt since the EMC merger transaction.  We believe we will continue to be able to make our debt principal and interest payments, including the short-term maturities, from existing and expected sources of cash and we will continue to focus on paying down core debt.  Despite the debt repayments, interest expense was $1.2 billion during both the six months ended August 3, 2018 and August 4, 2017 due to an increase in LIBOR, and also due to an increase in the debt used to fund the DFS business, as we see continued demand for customer financing.  We expect that continued demand for customer financing as well as an increase in LIBOR will impact

[0001571996-18-000034:mdna:200]
future interest expense on our variable-rate debt.  We or our affiliates, at our or their sole discretion, may purchase, redeem, prepay, refinance, or otherwise retire any amount of our outstanding indebtedness under the terms of such indebtedness at any time and from time to time, in open market or negotiated transactions with the holders of such indebtedness, as appropriate market conditions exist.

[0001571996-18-000034:mdna:201]
During the second quarter of Fiscal 2019, we repaid approximately$2.5 billion principal amount of our 1.875% unsecured notes due April 2018 and $68 million principal amount of our term loan facilities.  Further, we issued an additional $868 million, net, in DFS debt to support the expansion of our financing receivables portfolio.

[0001571996-18-000034:mdna:202]
[same as prior period, unchanged from 0001571996-18-000022:mdna:187]

[0001571996-18-000034:mdna:203]
[same as prior period, unchanged from 0001571996-18-000022:mdna:188]

[0001571996-18-000034:mdna:204]
[same as prior period, unchanged from 0001571996-18-000022:mdna:189]

[0001571996-18-000034:mdna:205]
|  | Six Months Ended |
|  | August 3, 2018 |  | August 4, 2017 |
|  | (in millions) |
| Net change in cash from: |  |  |  |
| Operating activities | $ | 3,792 |  |  | $ | 2,105 |  |
| Investing activities | (162 | ) |  | (1,290 | ) |
| Financing activities | (1,987 | ) |  | (1,077 | ) |
| Effect of exchange rate changes on cash and cash equivalents | (216 | ) |  | 48 |  |
| Change in cash and cash equivalents | $ | 1,427 |  |  | $ | (214 | ) |

[0001571996-18-000034:mdna:206]
Operating Activities — Cash provided by operating activities was $3.8 billion for the first six months of Fiscal 2019 compared to $2.1 billion for the first six months of Fiscal 2018.  The increase in operating cash flows during the first six months of Fiscal 2019 was driven by business momentum, improved profitability, and working capital discipline.

[0001571996-18-000034:mdna:207]
Investing Activities — Investing activities primarily consist of cash used to fund strategic investments, the maturities, sales, and purchases of investments, capital expenditures for property, plant, and equipment, and capitalized software development costs.  During the first six months of Fiscal 2019, cash used by investing activities was $0.2 billion and was primarily driven by capital expenditures partially offset by the net sales of investments.  In comparison, cash used by investing activities was $1.3 billion during the first six months of Fiscal 2018 and was primarily driven by capital expenditures, capitalized software development costs, and net purchases of investments.

[0001571996-18-000034:mdna:208]
Financing Activities — Financing activities primarily consist of the proceeds and repayments of debt, cash used to repurchase common stock, and proceeds from the issuance of common stock of subsidiaries.  Cash used by financing activities of $2.0 billion during the first six months of Fiscal 2019 was primarily driven repayments of debt, including the EMC Note in the amount of $2.5 billion we repaid during the second quarter of Fiscal 2019.  In comparison, cash used by financing activities of $1.1 billion during the first six months of Fiscal 2018 was primarily driven by repayments of debt and share repurchases.

[0001571996-18-000034:mdna:209]
[same as prior period, unchanged from 0001571996-18-000022:mdna:194]

[0001571996-18-000034:mdna:210]
Capital Expenditures — During both the first six months of Fiscal 2019 and Fiscal 2018, we spent $0.6 billion on property, plant, and equipment.  These expenditures were primarily incurred in connection with our global expansion efforts and infrastructure investments made to support future growth.  Product demand, product mix, and the use of contract manufacturers, as well as ongoing investments in operating and information technology infrastructure, influence the level and prioritization of our capital expenditures.  Aggregate capital expenditures for Fiscal 2019, which will be primarily related to infrastructure investments and strategic initiatives, are currently expected to total between $1.1 billion and $1.3 billion.

[0001571996-18-000034:mdna:211]
Purchase Obligations — Purchase obligations are defined as contractual obligations to purchase goods or services that are enforceable and legally binding on us.  These obligations specify all significant terms, including fixed or minimum quantities to

[0001571996-18-000034:mdna:212]
be purchased; fixed, minimum, or variable price provisions; and the approximate timing of the transaction.  Purchase obligations do not include contracts that may be canceled without penalty.

[0001571996-18-000034:mdna:213]
[same as prior period, unchanged from 0001571996-18-000022:mdna:197]

[0001571996-18-000034:mdna:214]
[same as prior period, unchanged from 0001571996-18-000022:mdna:198]

[0001571996-18-000034:mdna:215]
[same as prior period, unchanged from 0001571996-18-000022:mdna:199]

[0001571996-18-000034:mdna:216]
Since the date of the EMC merger transaction, our board of directors has authorized several programs to repurchase shares of our Class V Common Stock.  Of the $2.1 billion total authorized, $676 million remained as of August 3, 2018, all of which is attributable to the DHI Group Repurchase Program, which the board of directors suspended on December 13, 2016 until such time as it authorizes the reinstatement of that program.

[0001571996-18-000034:mdna:217]
During the first six months of Fiscal 2019, we did not repurchase any shares of Class V Common Stock.  During the first six months of Fiscal 2018, we repurchased 5.9 million shares of Class V Common Stock for an aggregate purchase price of $382 million.  The repurchase of these shares was funded by proceeds received by the Class V Group from the sale by a subsidiary of the Company of shares of Class A common stock of VMware, Inc. owned by such subsidiary, as discussed below.

[0001571996-18-000034:mdna:218]
[same as prior period, unchanged from 0001571996-18-000022:mdna:202]

[0001571996-18-000034:mdna:219]
During the second quarter and first six months of Fiscal 2019, we repurchased an immaterial number of shares of DHI Group Common Stock for approximately $10 million and $48 million, respectively.  During the second quarter of Fiscal 2018, the Company did not repurchase any shares of DHI Group Common Stock.  During the first six months of Fiscal 2018, the Company repurchased an immaterial number of shares of DHI Group Common Stock for approximately $2 million.

[0001571996-18-000034:mdna:220]
[same as prior period, unchanged from 0001571996-18-000022:mdna:204]

[0001571996-18-000034:mdna:221]
Since the date of the EMC merger transaction, VMware Inc.'s board of directors has authorized the repurchase of a total of $2.2 billion of VMware Inc.'s Class A common stock, of which $876 million remained available as of August 3, 2018.

[0001571996-18-000034:mdna:222]
During the first six months of Fiscal 2019, VMware, Inc. did not repurchase any shares of its Class A common stock.  During the first six months of Fiscal 2018, pursuant to stock repurchase agreements between Dell Technologies Inc. and VMware, Inc., VMware, Inc. repurchased 4.8 million shares of its Class A common stock from us for an aggregate purchase price of $425 million.  VMware, Inc. received the initial 4.1 million shares of its Class A common stock during the first quarter of Fiscal 2018 and the remaining 0.7 million shares during the second quarter of Fiscal 2018.  The proceeds from the sales were used by us to repurchase shares of our Class V Common Stock, as described above.
