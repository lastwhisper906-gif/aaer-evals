# DELL note change history — 0001571996-18-000022 → 0001571996-18-000034


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2018-09-11):
[0001571996-18-000034:note_history:1]
Appraisal Proceedings — On October 29, 2013, Dell Technologies acquired Dell in a transaction referred to as the going-private transaction.  Holders of shares of Dell common stock who did not vote on September 12, 2013 in favor of the proposal to adopt the amended going-private transaction agreement and who properly demanded appraisal of their shares and who otherwise comply with the requirements of Section 262 of the Delaware General Corporate Law ("DGCL") are entitled to seek appraisal for, and obtain payment in cash for the judicially determined "fair value" (as defined pursuant to Section 262 of the DGCL) of, their shares in lieu of receiving the going-private transaction consideration.  Dell initially recorded a liability of $13.75 for each share with respect to which appraisal has been demanded and as to which the demand has not been withdrawn, together with interest at the statutory rate discussed below.  The Court of Chancery ruled that the fair value of the appraisal shares as of October 29, 2013, the date on which the going-private transaction became effective, was $17.62 per share.  This ruling would entitle the holders of the remaining 5,505,630 shares subject to the appraisal proceedings to $17.62 per share, plus interest at a statutory rate, compounded quarterly.  On November 21, 2016, the Court of Chancery entered final judgment in the appraisal action.  On November 22, 2016, Dell filed a notice of appeal to the Delaware Supreme Court, which issued a decision on December 14, 2017.  In its decision, the Delaware Supreme Court reversed, in part, and affirmed, in part, the decision of the Delaware Court of Chancery.  On January 2, 2018, the Delaware Supreme Court issued its formal mandate remanding the matter to the Court of Chancery for further proceedings consistent with its opinion.  In accordance with direction by the Court of Chancery, the parties submitted proposals to the Court of Chancery outlining the remaining issues to be adjudicated.  The liability for the appraisal proceedings was approximately $129 million as of February 2, 2018.  On May 8, 2018, the Company entered into an agreement to settle a portion of the liability related to the appraisal proceedings in the amount of approximately $70 million, and on May 18, 2018, this portion of the liability was fully paid.  The Company settled with the remaining plaintiffs as of July 16, 2018 in the amount of approximately $30 million.  The remaining liability accrual was released to Interest and other, net during the three months ended August 3, 2018.  As of August 3, 2018, there was no remaining liability for appraisal proceedings.
  (was, 2018-06-12, similarity 0.8774):
[0001571996-18-000022:note_history:1]
Appraisal Proceedings — On October 29, 2013, Dell Technologies acquired Dell in a transaction referred to as the going-private transaction.  Holders of shares of Dell common stock who did not vote on September 12, 2013 in favor of the proposal to adopt the amended going-private transaction agreement and who properly demanded appraisal of their shares and who otherwise comply with the requirements of Section 262 of the Delaware General Corporate Law ("DGCL") are entitled to seek appraisal for, and obtain payment in cash for the judicially determined "fair value" (as defined pursuant to Section 262 of the DGCL) of, their shares in lieu of receiving the going-private transaction consideration.  Dell initially recorded a liability of $13.75 for each share with respect to which appraisal has been demanded and as to which the demand has not been withdrawn, together with interest at the statutory rate discussed below.  The Court of Chancery ruled that the fair value of the appraisal shares as of October 29, 2013, the date on which the going-private transaction became effective, was $17.62 per share.  This ruling would entitle the holders of the remaining 5,505,630 shares subject to the appraisal proceedings to $17.62 per share, plus interest at a statutory rate, compounded quarterly.  On November 21, 2016, the Court of Chancery entered final judgment in the appraisal action.  On November 22, 2016, Dell filed a notice of appeal to the Delaware Supreme Court, which issued a decision on December 14, 2017.  In its decision, the Delaware Supreme Court reversed, in part, and affirmed, in part, the decision of the Delaware Court of Chancery.  On January 2, 2018, the Delaware Supreme Court issued its formal mandate remanding the matter to the Court of Chancery for further proceedings consistent with its opinion.  In accordance with direction by the Court of Chancery, the parties have submitted proposals to the Court of Chancery outlining the remaining issues to be adjudicated.  The liability for the appraisal proceedings was approximately $108 million and $129 million as of May 4, 2018 and February 2, 2018, respectively.  The Company believes it was adequately reserved for the appraisal proceedings as of May 4, 2018.  On May 8, 2018, the Company entered into an agreement to settle a portion of the liability related to the appraisal proceedings in the amount of approximately $70 million, and on May 18, 2018 this portion of the liability was fully paid.

- added (2018-09-11):
[0001571996-18-000034:note_history:2]
CamSoft Litigation — CamSoft Data Systems, Inc. ("CamSoft") filed in 2009 a lawsuit, captioned CamSoft Data Systems, Inc. v. Southern Electronics Supply, Inc., et al., in the 19th Judicial District Court, Parish of East Baton Rouge, Louisiana, alleging that Dell conspired with others to misappropriate CamSoft’s trade secrets relating to municipal wireless video surveillance systems and engaged in unfair trade practices.  CamSoft asserted Louisiana state law claims for misappropriation of trade secrets, unfair trade practices, antitrust and other torts.  CamSoft seeks compensatory and punitive damages in excess of $2 billion.  The Company believes the claims are without merit and has motions to dismiss pending before the court.  The case is scheduled for trial in October 2018.

- added (2018-09-11):
[0001571996-18-000034:note_history:3]
As of August 3, 2018, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for these or other proceedings or matters has been incurred.  However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company's business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters.  Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company's business, financial condition, results of operations, or cash flows will depend on a number of variables, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.

- removed (2018-09-11):
[0001571996-18-000022:note_history:4]
As of May 4, 2018, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for these or other proceedings or matters has been incurred.  However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company's business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters.  Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company's business, financial condition, results of operations, or cash flows will depend on a number of variables, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2018-09-11):
[0001571996-18-000034:note_history:5]
References in these Notes to the Condensed Consolidated Financial Statements to the "Company" or "Dell Technologies" mean Dell Technologies Inc. individually and together with its consolidated subsidiaries.

- added (2018-09-11):
[0001571996-18-000034:note_history:6]
Basis of Presentation — The accompanying unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company's Annual Report on Form 10-K for the fiscal year ended February 2, 2018, and the recast audited Consolidated Financial Statements and accompanying Notes for the fiscal years ended February 2, 2018  and February 3, 2017 (the "Recast Financial Statements")

- added (2018-09-11):
[0001571996-18-000034:note_history:7]
and other financial information included in the Company's Current Report on Form 8-K filed with the Securities and Exchange Commission (the "SEC") on August 6, 2018.  The Recast Financial Statements were recast from and supersede the audited Consolidated Financial Statements for the fiscal years ended February 2, 2018  and February 3, 2017 included in the Company's Annual Report on Form 10-K for the fiscal year ended February 2, 2018.  Such audited Consolidated Financial Statements were recast to present certain previously reported financial statements and other related financial information on a basis consistent with the new accounting standards adopted during the three months ended May 4, 2018.  Further, segment information was recast to conform with certain segment reporting changes the Company made during the three months ended May 4, 2018.  See below for additional information regarding recently adopted accounting pronouncements.

- added (2018-09-11):
[0001571996-18-000034:note_history:8]
These Condensed Consolidated Financial Statements have been prepared in accordance with accounting principles generally accepted in the United States of America ("GAAP").  In the opinion of management, the accompanying Condensed  Consolidated Financial Statements reflect all adjustments of a normal recurring nature considered necessary to fairly state the financial position of Dell Technologies Inc. as of August 3, 2018, the results of its operations and corresponding comprehensive income (loss) for the three and six months ended August 3, 2018 and August 4, 2017, and its cash flows for the six months ended August 3, 2018 and August 4, 2017.  The February 2, 2018 condensed consolidated balance sheet included herein was derived from the Recast Financial Statements.

- changed (2018-09-11):
[0001571996-18-000034:note_history:9]
The preparation of financial statements in accordance with GAAP requires management to make estimates and assumptions that affect the amounts reported in the Condensed Consolidated Financial Statements and the accompanying Notes.  Actual results could differ materially from those estimates.  The results of operations and comprehensive income (loss) for the three and six months ended August 3, 2018 and August 4, 2017 and the cash flows for the six months ended August 3, 2018 and August 4, 2017 are not necessarily indicative of the results to be expected for the full fiscal year or for any other fiscal period.
  (was, 2018-06-12, similarity 0.7266):
[0001571996-18-000022:note_history:9]
The preparation of financial statements in accordance with GAAP requires management to make estimates and assumptions that affect the amounts reported in the Condensed Consolidated Financial Statements and the accompanying Notes.  Actual results could differ materially from those estimates.  The results of operations, comprehensive income (loss), and cash flows for the three months ended May 4, 2018 and May 5, 2017 are not necessarily indicative of the results to be expected for the full fiscal year or for any other fiscal period.

- changed (2018-09-11):
[0001571996-18-000034:note_history:10]
Principles of Consolidation — These Condensed Consolidated Financial Statements include the accounts of Dell Technologies and its wholly-owned subsidiaries, as well as the accounts of SecureWorks Corp. ("SecureWorks"), VMware, Inc., and Pivotal Software, Inc. ("Pivotal"), each of which is majority-owned by Dell Technologies.  All intercompany transactions have been eliminated.
  (was, 2018-06-12, similarity 0.9974):
[0001571996-18-000022:note_history:10]
Principles of Consolidation — These Condensed Consolidated Financial Statements include the accounts of Dell Technologies and its wholly-owned subsidiaries, as well as the accounts of SecureWorks Corp. (“SecureWorks"), VMware, Inc., and Pivotal Software, Inc. ("Pivotal"), each of which is majority-owned by Dell Technologies.  All intercompany transactions have been eliminated.

- changed (2018-09-11):
[0001571996-18-000034:note_history:11]
Unless the context indicates otherwise, references in these Notes to the Condensed Consolidated Financial Statements to "VMware" mean the VMware reportable segment, which reflects the operations of VMware, Inc. (NYSE: VMW) within Dell Technologies.  See Exhibit 99.1 filed with the quarterly report on Form 10-Q for the quarterly period ended August 3, 2018 for information on the differences between VMware reportable segment results and VMware, Inc. results.
  (was, 2018-06-12, similarity 0.7586):
[0001571996-18-000022:note_history:11]
Unless the context indicates otherwise, references in these Notes to the Condensed Consolidated Financial Statements to "VMware" mean the VMware reportable segment, which reflects the operations of VMware, Inc. (NYSE: VMW) within Dell Technologies.  See Exhibit 99.1 filed with the quarterly report on Form 10-Q for the quarterly period ended May 4, 2018 for information on the differences between VMware reportable segment results and VMware, Inc. results.

- added (2018-09-11):
[0001571996-18-000034:note_history:12]
Leases — In February 2016, the Financial Accounting Standards Board ("FASB") issued amended guidance on the accounting for leasing transactions.  The primary objective of this update is to increase transparency and comparability among organizations by requiring lessees to recognize a lease liability for the obligation to make lease payments and a right-of-use asset for the right to use the underlying asset for the lease term.  The guidance also makes some changes to lessor accounting and requires additional disclosures about all leasing arrangements.  Companies are required to use a modified retrospective approach, with the option of applying the requirements of the standard either (1) retrospectively to each prior comparative reporting period presented, or (2) retrospectively at the beginning of the period of adoption.  The Company will adopt this standard for the fiscal year beginning February 2, 2019, and will apply it at the beginning of the period of adoption through a cumulative-effect adjustment to retained earnings.  In the area of lessee accounting, the Company anticipates that the most significant change will be recognition of right-of-use assets and lease liabilities on the Consolidated Statements of Financial Position.  In the area of lessor accounting, the Company anticipates that the most significant change will be an increase to future originations of operating leases due to elimination of the third-party residual value guarantee insurance in the sales-type lease test.

- changed (2018-09-11):
[0001571996-18-000034:note_history:13]
Simplifying the Test for Goodwill Impairment — In January 2017, the FASB issued amended guidance to simplify the subsequent measurement of goodwill by removing Step 2 of the goodwill impairment test.  Instead, under the amendments in the new guidance, an entity should perform its annual, or interim, goodwill impairment test by comparing the fair value of a reporting unit with its carrying amount.  An entity should recognize an impairment charge for the amount by which the carrying amount exceeds the reporting unit's fair value.  Public entities must adopt the new guidance in fiscal years beginning after December 15, 2019, with early adoption permitted.  The Company is currently evaluating the impact of the new guidance but does not expect that the standard will have an impact on its Consolidated Financial Statements.
  (was, 2018-06-12, similarity 0.9963):
[0001571996-18-000022:note_history:13]
Simplifying the Test for Goodwill Impairment — In January 2017, the FASB issued amended guidance to simplify the subsequent measurement of goodwill by removing Step 2 of the goodwill impairment test.  Instead, under the amendments in the new guidance, an entity should perform its annual, or interim, goodwill impairment test by comparing the fair value of a reporting unit with its carrying amount.  The entity should recognize an impairment charge for the amount by which the carrying amount exceeds the reporting unit's fair value.  Public entities must adopt the new guidance in fiscal years beginning after December 15, 2019, with early adoption permitted.  The Company is currently evaluating the impact of the new guidance, but does not expect that the standard will have an impact on its Consolidated Financial Statements.

- changed (2018-09-11):
[0001571996-18-000034:note_history:14]
Revenue from Contracts with Customers — In May 2014, the FASB issued amended guidance on the recognition of revenue from contracts with customers.  The objective of the new standard is to establish a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and will supersede substantially all of the existing revenue recognition guidance, including industry-specific guidance.  The new standard requires entities to recognize revenue when it transfers promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services.  Further, the new standard requires additional disclosures to help enable users of the financial statements to better understand the nature, amount, timing, risks, and judgments related to revenue recognition and related cash flows from contracts with customers.  Concurrently, the FASB issued guidance on the accounting for costs to fulfill or obtain a customer contract.  The Company adopted these standards during the three months ended May 4, 2018 using the full retrospective method, which requires the Company to recast each prior period presented consistent with the new guidance.  The Company recorded a credit of approximately $1 billion to retained earnings as of January 29, 2016 to reflect the cumulative effect of the adoption.  See tables provided below which present the impact of the new accounting standards to the Company's previously reported financial results.  See also Note 2 of the Notes to the Condensed Consolidated Financial Statements for a summary of significant policies related to the new accounting standards.
  (was, 2018-06-12, similarity 0.9472):
[0001571996-18-000022:note_history:14]
Revenue from Contracts with Customers — In May 2014, the FASB issued amended guidance on the recognition of revenue from contracts with customers.  The objective of the new standard is to establish a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and will supersede substantially all of the existing revenue recognition guidance, including industry-specific guidance.  The new standard requires entities to recognize revenue when it transfers promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services.  Further, the new standard requires additional disclosures to help enable users of the financial statements to better understand the nature, amount, timing, risks, and judgments related to revenue recognition and related cash flows from contracts with customers.  Concurrently, the FASB issued guidance on the accounting for costs to fulfill or obtain a customer contract.  The Company adopted this standard during the three months ended May 4, 2018 using the full retrospective method, which requires the Company to recast each prior period presented consistent with the new guidance.  See tables provided below which present the impact of the new accounting standards to the Company's previously reported financial results.  See also Note 2 of the Notes to the Condensed Consolidated Financial Statements for a summary of significant policies related to the new accounting standards.

- changed (2018-09-11):
[0001571996-18-000034:note_history:15]
Recognition and Measurement of Financial Assets and Financial Liabilities — In January 2016, the FASB issued amended guidance that generally requires changes in the fair value of equity investments, other than those accounted for under the equity method, to be recognized through net income, rather than other comprehensive income.  For equity investments without readily determinable fair values, the Company is no longer permitted to use the cost method of accounting.  The Company has elected to apply the measurement alternative for those investments.  Under the alternative, the Company measures investments without readily determinable fair values at cost, less impairment, adjusted by observable price changes on a prospective basis.  The Company must make a separate election to use the alternative for each eligible investment, and is required to reassess at each reporting period whether an investment qualifies for the alternative.  The Company adopted this standard during the three months ended May 4, 2018.  Adoption of the standard was applied through a cumulative one-time adjustment to accumulated deficit of $56 million for the accumulated unrealized gain previously recorded in other comprehensive income.  The impact of the standard on the Condensed Consolidated Statements of Income (Loss) during the three and six months ended August 3, 2018 was a gain of approximately $123 million and $223 million, respectively, recognized in interest and other, net, and the impact in future periods will depend on the relative changes in market price of the equity investments.
  (was, 2018-06-12, similarity 0.9553):
[0001571996-18-000022:note_history:15]
Recognition and Measurement of Financial Assets and Financial Liabilities — In January 2016, the FASB issued amended guidance that generally requires changes in the fair value of equity investments, other than those accounted for under the equity method, to be recognized through net income, rather than other comprehensive income.  For equity investments without readily determinable fair values, the Company is no longer permitted to use the cost method of accounting.  The Company has elected to apply the measurement alternative for those investments.  Under the alternative, the Company measures investments without readily determinable fair values at cost, less impairment, adjusted by observable price changes on a prospective basis.  The Company must make a separate election to use the alternative for each eligible investment, and is required to reassess at each reporting period whether an investment qualifies for the alternative.  The Company adopted this standard during the three months ended May 4, 2018.  Adoption of the standard was applied through a cumulative one-time adjustment to accumulated deficit of $56 million for the accumulated unrealized gain previously recorded in other comprehensive income.  The impact of the standard on the Condensed Consolidated Statements of Income (Loss) during the three months ended May 4, 2018 was a gain of approximately $100 million, recognized in interest and other, net, and the impact in future periods will depend on the relative changes in market price of the equity investments.

- changed (2018-09-11):
[0001571996-18-000034:note_history:16]
|  | February 2, 2018 |
|  | As Reported (a) |  | Revenue from Contracts with Customers |  | As Recast |
|  | (in millions) |
| Assets |  |  |  |  |  |
| Accounts receivable, net | $ | 11,177 |  |  | $ | 544 |  |  | $ | 11,721 |  |
| Other current assets | $ | 5,054 |  |  | $ | 827 |  |  | $ | 5,881 |  |
| Other non-current assets | $ | 1,862 |  |  | $ | 541 |  |  | $ | 2,403 |  |
| Liabilities and Stockholders' Equity |  |  |  |  |  |
| Accrued and other | $ | 7,661 |  |  | $ | 365 |  |  | $ | 8,026 |  |
| Short-term deferred revenue | $ | 12,024 |  |  | $ | (418 | ) |  | $ | 11,606 |  |
| Long-term deferred revenue | $ | 10,223 |  |  | $ | (1,013 | ) |  | $ | 9,210 |  |
| Other non-current liabilities | $ | 6,797 |  |  | $ | 480 |  |  | $ | 7,277 |  |
| Accumulated deficit | $ | (9,253 | ) |  | $ | 2,393 |  |  | $ | (6,860 | ) |
| Non-controlling interests | $ | 5,661 |  |  | $ | 105 |  |  | $ | 5,766 |  |
  (was, 2018-06-12, similarity 0.9974):
[0001571996-18-000022:note_history:16]
|  | February 2, 2018 |
|  | As Reported |  | Revenue from Contracts with Customers |  | As Recast |
|  | (in millions) |
| Assets |  |  |  |  |  |
| Accounts receivable, net | $ | 11,177 |  |  | $ | 544 |  |  | $ | 11,721 |  |
| Other current assets | $ | 5,054 |  |  | $ | 827 |  |  | $ | 5,881 |  |
| Other non-current assets | $ | 1,862 |  |  | $ | 541 |  |  | $ | 2,403 |  |
| Liabilities and Stockholders' Equity |  |  |  |  |  |
| Accrued and other | $ | 7,661 |  |  | $ | 365 |  |  | $ | 8,026 |  |
| Short-term deferred revenue | $ | 12,024 |  |  | $ | (418 | ) |  | $ | 11,606 |  |
| Long-term deferred revenue | $ | 10,223 |  |  | $ | (1,013 | ) |  | $ | 9,210 |  |
| Other non-current liabilities | $ | 6,797 |  |  | $ | 480 |  |  | $ | 7,277 |  |
| Accumulated deficit | $ | (9,253 | ) |  | $ | 2,393 |  |  | $ | (6,860 | ) |
| Non-controlling interests | $ | 5,661 |  |  | $ | 105 |  |  | $ | 5,766 |  |

- added (2018-09-11):
[0001571996-18-000034:note_history:17]
____________________

- added (2018-09-11):
[0001571996-18-000034:note_history:18]
| (a) | Amounts as reported in the Company's Annual Report on Form 10-K for the fiscal year ended February 2, 2018. |

- changed (2018-09-11):
[0001571996-18-000034:note_history:19]
| • | First, the return rights provision, which represents an estimate of expected customer returns, which was previously presented as a reduction of accounts receivable, net, is now being presented outside of accounts receivable, net in two separate balance sheet line items. A liability is recorded in accrued and other for the estimated value of the sales amounts to be returned to the customer, and an asset is recorded in other current assets representing the recoverable cost of the inventory estimated to be returned. |
  (was, 2018-06-12, similarity 0.9615):
[0001571996-18-000022:note_history:19]
| • | First, the return rights provision, which represents an estimate of expected customer returns, which was previously presented as a reduction of accounts receivable, net, is now being presented outside of accounts receivable, net in two separate balance sheet line items. A liability is recorded in accrued and other for the estimated value of the sales amounts to be returned to the customer, and an asset is recorded in other current assets representing the cost of the inventory estimated to be returned. |

- changed (2018-09-11):
[0001571996-18-000034:note_history:20]
Deferred revenue.  The adoption of the new revenue standard resulted in a decline in deferred revenue due to earlier recognition of revenue for software licenses, and less of the aggregate transaction price being allocated to extended warranty.  Deferred revenue was also reduced by the impact of variable consideration (i.e., price concessions, rebates, and refunds).  The reduction in deferred revenue was partially offset by an increase resulting from the change in presentation of deferred costs on third-party software offerings, which are reported in other assets, and are either sold on a standalone basis or as an attached component of the Company's hardware offering.  The Company previously reported the associated deferred revenue net of these deferred costs in deferred revenue.
  (was, 2018-06-12, similarity 0.9157):
[0001571996-18-000022:note_history:20]
Deferred revenue.  The adoption of the new revenue standard resulted in a decline in deferred revenue due to earlier recognition of revenue for software licenses, and less of the aggregate transaction price being allocated to extended warranty.  Deferred revenue was also reduced by the impact of variable consideration, i.e., price concessions, rebates, and refunds.  The reduction in deferred revenue was partially offset by an increase resulting from the change in presentation of deferred costs on third-party software offerings, which are either sold on a standalone basis or as an attached component of the Company's hardware offering.  The Company previously reported deferred costs net of revenue in deferred revenue.

- added (2018-09-11):
[0001571996-18-000034:note_history:21]
|  | Three Months Ended |  | Six Months Ended |
|  | August 4, 2017 |  | August 4, 2017 |
|  | As Reported (a) |  | Revenue from Contracts with Customers |  | As Recast |  | As Reported (a) |  | Revenue from Contracts with Customers |  | As Recast |
|  | (in millions, except per share amounts) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Products | $ | 14,355 |  |  | $ | 747 |  |  | $ | 15,102 |  |  | $ | 27,323 |  |  | $ | 1,413 |  |  | $ | 28,736 |  |
| Services | 4,944 |  |  | (525 | ) |  | 4,419 |  |  | 9,792 |  |  | (1,007 | ) |  | 8,785 |  |
| Total net revenue | 19,299 |  |  | 222 |  |  | 19,521 |  |  | 37,115 |  |  | 406 |  |  | 37,521 |  |
| Cost of net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Products | 12,378 |  |  | 397 |  |  | 12,775 |  |  | 23,837 |  |  | 761 |  |  | 24,598 |  |
| Services | 2,112 |  |  | (334 | ) |  | 1,778 |  |  | 4,167 |  |  | (669 | ) |  | 3,498 |  |
| Total cost of net revenue | 14,490 |  |  | 63 |  |  | 14,553 |  |  | 28,004 |  |  | 92 |  |  | 28,096 |  |
| Gross margin | 4,809 |  |  | 159 |  |  | 4,968 |  |  | 9,111 |  |  | 314 |  |  | 9,425 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative | 4,695 |  |  | (155 | ) |  | 4,540 |  |  | 9,364 |  |  | (228 | ) |  | 9,136 |  |
| Research and development | 1,093 |  |  | — |  |  | 1,093 |  |  | 2,226 |  |  | — |  |  | 2,226 |  |
| Total operating expenses | 5,788 |  |  | (155 | ) |  | 5,633 |  |  | 11,590 |  |  | (228 | ) |  | 11,362 |  |
| Operating loss | (979 | ) |  | 314 |  |  | (665 | ) |  | (2,479 | ) |  | 542 |  |  | (1,937 | ) |
| Interest and other, net | (545 | ) |  | — |  |  | (545 | ) |  | (1,118 | ) |  | 1 |  |  | (1,117 | ) |
| Income (loss) before income taxes | (1,524 | ) |  | 314 |  |  | (1,210 | ) |  | (3,597 | ) |  | 543 |  |  | (3,054 | ) |
| Income tax provision (benefit) | (546 | ) |  | 75 |  |  | (471 | ) |  | (1,236 | ) |  | 124 |  |  | (1,112 | ) |
| Net income (loss) | (978 | ) |  | 239 |  |  | (739 | ) |  | (2,361 | ) |  | 419 |  |  | (1,942 | ) |
| Less: Net income (loss) attributable to non-controlling interests | (32 | ) |  | 25 |  |  | (7 | ) |  | (81 | ) |  | 42 |  |  | (39 | ) |
| Net income (loss) attributable to Dell Technologies Inc. | $ | (946 | ) |  | $ | 214 |  |  | $ | (732 | ) |  | $ | (2,280 | ) |  | $ | 377 |  |  | $ | (1,903 | ) |
| Earnings (loss) per share attributable to Dell Technologies Inc. - basic: |  |  |  |  |  |  |
| Class V Common Stock - basic | $ | 0.83 |  |  | $ | 0.17 |  |  | $ | 1.00 |  |  | $ | 1.40 |  |  | $ | 0.20 |  |  | $ | 1.60 |  |
| DHI Group - basic | $ | (1.97 | ) |  | $ | 0.32 |  |  | $ | (1.65 | ) |  | $ | (4.53 | ) |  | $ | 0.59 |  |  | $ | (3.94 | ) |
| Earnings (loss) per share attributable to Dell Technologies Inc. - diluted: |  |  |  |  |  |  |
| Class V Common Stock - diluted | $ | 0.82 |  |  | $ | 0.18 |  |  | $ | 1.00 |  |  | $ | 1.38 |  |  | $ | 0.21 |  |  | $ | 1.59 |  |
| DHI Group - diluted | $ | (1.97 | ) |  | $ | 0.31 |  |  | $ | (1.66 | ) |  | $ | (4.54 | ) |  | $ | 0.59 |  |  | $ | (3.95 | ) |

- added (2018-09-11):
[0001571996-18-000034:note_history:22]
____________________

- added (2018-09-11):
[0001571996-18-000034:note_history:23]
| (a) | Amounts as reported in the Company's Quarterly Report on Form 10-Q for the quarterly period ended August 4, 2017. |

- changed (2018-09-11):
[0001571996-18-000034:note_history:24]
| • | Under the new revenue standard, amounts within a contract are now allocated to the product and services performance obligations based on their respective standalone selling prices, which generally increases product revenue and decreases services revenue relative to previously reported results. |
  (was, 2018-06-12, similarity 0.9291):
[0001571996-18-000022:note_history:24]
| • | Under the new revenue standard, amounts within a contract are now allocated to the product and services performance obligations based on their respective standalone selling prices, which generally increases product revenue and decreases services revenue. |

- changed (2018-09-11):
[0001571996-18-000034:note_history:25]
Operating expenses.   The adoption of the new revenue standard resulted in a decrease to operating expenses due to the deferral of the incremental direct costs of obtaining a contract.
  (was, 2018-06-12, similarity 0.8483):
[0001571996-18-000022:note_history:25]
Operating expenses.   The adoption of the new revenue standard resulted in a decrease to operating expenses due to the deferral of commissions.

- changed (2018-09-11):
[0001571996-18-000034:note_history:26]
|  | Six Months Ended |
|  | August 4, 2017 |
|  | As Reported (a) |  | Classification of Certain Cash Receipts and Cash Payments |  | Statement of Cash Flows, Restricted Cash |  | As Recast |
|  | (in millions) |
| Change in cash from operating activities | $ | 2,056 |  |  | $ | 32 |  |  | $ | 17 |  |  | $ | 2,105 |  |
| Change in cash from investing activities | $ | (1,290 | ) |  | $ | — |  |  | $ | — |  |  | $ | (1,290 | ) |
| Change in cash from financing activities | $ | (1,075 | ) |  | $ | (32 | ) |  | $ | 30 |  |  | $ | (1,077 | ) |
| Change in cash, cash equivalents, and restricted cash | $ | (261 | ) |  | $ | — |  |  | $ | 47 |  |  | $ | (214 | ) |
| Cash, cash equivalents, and restricted cash at beginning of the period | 9,474 |  |  | — |  |  | 358 |  |  | 9,832 |  |
| Cash, cash equivalents, and restricted cash at end of the period | $ | 9,213 |  |  | $ | — |  |  | $ | 405 |  |  | $ | 9,618 |  |
  (was, 2018-06-12, similarity 0.9649):
[0001571996-18-000022:note_history:26]
|  | Three Months Ended |
|  | May 5, 2017 |
|  | As Reported |  | Classification of Certain Cash Receipts and Cash Payments |  | Statement of Cash Flows, Restricted Cash |  | As Recast |
|  | (in millions) |
| Change in cash from operating activities | $ | 240 |  |  | $ | 29 |  |  | $ | 16 |  |  | $ | 285 |  |
| Change in cash from investing activities | $ | 51 |  |  | $ | — |  |  | $ | — |  |  | $ | 51 |  |
| Change in cash from financing activities | $ | (205 | ) |  | $ | (29 | ) |  | $ | 47 |  |  | $ | (187 | ) |
| Change in cash, cash equivalents, and restricted cash | $ | 80 |  |  | $ | — |  |  | $ | 63 |  |  | $ | 143 |  |
| Cash, cash equivalents, and restricted cash at beginning of the period | 9,474 |  |  | — |  |  | 358 |  |  | 9,832 |  |
| Cash, cash equivalents, and restricted cash at end of the period | $ | 9,554 |  |  | $ | — |  |  | $ | 421 |  |  | $ | 9,975 |  |

- added (2018-09-11):
[0001571996-18-000034:note_history:27]
____________________

- added (2018-09-11):
[0001571996-18-000034:note_history:28]
| (a) | Amounts as reported in the Company's Quarterly Report on Form 10-Q for the quarterly period ended August 4, 2017. |

- removed (2018-09-11):
[0001571996-18-000022:note_history:29]
Basis of Presentation — The accompanying unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes filed with the U.S. Securities and Exchange Commission ("SEC") in the Company's Annual Report on Form 10-K for the fiscal year ended February 2, 2018.  These Condensed Consolidated Financial Statements have been prepared in accordance with accounting principles generally accepted in the United States of America ("GAAP").  In the opinion of management, the accompanying Condensed  Consolidated Financial Statements reflect all adjustments of a normal recurring nature considered necessary to fairly state the financial position of Dell Technologies Inc. as of May 4, 2018 and February 2, 2018, the results of its operations and corresponding comprehensive income (loss) for the three months ended May 4, 2018 and May 5, 2017, and its cash flows for the three months ended May 4, 2018 and May 5, 2017.  References in these Notes to the Condensed Consolidated Financial Statements to the "Company" or "Dell Technologies" means Dell Technologies Inc. individually and together with its consolidated subsidiaries.

- removed (2018-09-11):
[0001571996-18-000022:note_history:30]
Leases — In February 2016, the Financial Accounting Standards Board ("FASB")  issued amended guidance on the accounting for leasing transactions.  The primary objective of this update is to increase transparency and comparability among organizations by requiring lessees to recognize a lease liability for the obligation to make lease payments and a right-of-use asset for the right to use the underlying asset for the lease term.  The guidance also makes some changes to lessor accounting and requires additional disclosures about all leasing arrangements.  The Company will adopt this standard for the fiscal year beginning February 2, 2019, using a modified retrospective approach.  The Company is currently evaluating the impact that the standard will have on the Consolidated Financial Statements.  In the area of lessee accounting, the Company anticipates that the most significant change will be recognition of right-of-use assets and lease liabilities on the Consolidated Statements of Financial Position.  In the area of lessor accounting, the Company anticipates that the most significant change will be an increase in originations of operating leases due to elimination of the third-party residual value guarantee insurance in the sales-type lease test.

- removed (2018-09-11):
[0001571996-18-000022:note_history:31]
|  | Three Months Ended |
|  | May 5, 2017 |
|  | As Reported |  | Revenue from Contracts with Customers |  | As Recast |
|  | (in millions, except per share amounts) |
| Net revenue: |  |  |  |  |  |
| Products | $ | 12,968 |  |  | $ | 666 |  |  | $ | 13,634 |  |
| Services | 4,848 |  |  | (482 | ) |  | 4,366 |  |
| Total net revenue | 17,816 |  |  | 184 |  |  | 18,000 |  |
| Cost of net revenue: |  |  |  |  |  |
| Products | 11,459 |  |  | 364 |  |  | 11,823 |  |
| Services | 2,055 |  |  | (335 | ) |  | 1,720 |  |
| Total cost of net revenue | 13,514 |  |  | 29 |  |  | 13,543 |  |
| Gross margin | 4,302 |  |  | 155 |  |  | 4,457 |  |
| Operating expenses: |  |  |  |  |  |
| Selling, general, and administrative | 4,669 |  |  | (73 | ) |  | 4,596 |  |
| Research and development | 1,133 |  |  | — |  |  | 1,133 |  |
| Total operating expenses | 5,802 |  |  | (73 | ) |  | 5,729 |  |
| Operating loss | (1,500 | ) |  | 228 |  |  | (1,272 | ) |
| Interest and other, net | (573 | ) |  | 1 |  |  | (572 | ) |
| Income (loss) before income taxes | (2,073 | ) |  | 229 |  |  | (1,844 | ) |
| Income tax provision (benefit) | (690 | ) |  | 49 |  |  | (641 | ) |
| Net income (loss) | (1,383 | ) |  | 180 |  |  | (1,203 | ) |
| Less: Net income (loss) attributable to non-controlling interests | (49 | ) |  | 17 |  |  | (32 | ) |
| Net income (loss) attributable to Dell Technologies Inc. | $ | (1,334 | ) |  | $ | 163 |  |  | $ | (1,171 | ) |
| Earnings (loss) per share attributable to Dell Technologies Inc. - basic: |  |  |  |  |
| Class V Common Stock - basic | $ | 0.57 |  |  | 0.03 |  |  | $ | 0.60 |  |
| DHI Group - basic | $ | (2.57 | ) |  | 0.28 |  |  | $ | (2.29 | ) |
| Earnings (loss) per share attributable to Dell Technologies Inc. - diluted: |  |  |  |  |
| Class V Common Stock - diluted | $ | 0.56 |  |  | 0.03 |  |  | $ | 0.59 |  |
| DHI Group - diluted | $ | (2.57 | ) |  | 0.28 |  |  | $ | (2.29 | ) |


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2018-09-11):
[0001571996-18-000034:note_history:32]
| (1) | Identify the contract with a customer. The term "contract" refers to the enforceable rights and obligations provided in an agreement between the Company and one or more other parties in exchange for payment. The Company evaluates facts and circumstances regarding sales transactions in order to identify contracts with its customers. An agreement must meet all of the following criteria to qualify as a contract eligible for revenue recognition under the model: (i) the contract must be approved by all parties; (ii) each party's rights regarding the goods and services to be transferred to the customer can be identified; (iii) the payment terms for the goods and services can be identified; (iv) the customer has the ability and intent to pay and it is probable that the Company will collect substantially all of the consideration to which it will be entitled; and (v) the contract must have commercial substance. Judgment is used in determining the customer's ability and intent to pay, which is based upon various factors including the customer's historical payment experience or customer credit and financial information. |
  (was, 2018-06-12, similarity 0.9872):
[0001571996-18-000022:note_history:32]
| (1) | Identify the contract with a customer. The term “contract” refers to the enforceable rights and obligations provided in an agreement between the Company and one or more other parties in exchange for payment. The Company evaluates facts and circumstances regarding sales transactions in order to identify contracts with its customers. An agreement must meet all of the following criteria to qualify as a contract eligible for revenue recognition under the model: (i) the contract must be approved by all parties; (ii) each party's rights regarding the goods and services to be transferred to the customer can be identified; (iii) the payment terms for the good and services can be identified; (iv) the customer has the ability and intent to pay and it is probable that the Company will collect substantially all of the consideration to which it will be entitled; and (v) the contract must have commercial substance. Judgment is used in determining the customer's ability and intent to pay, which is based upon factors including the customer's historical payment experience or customer credit and financial information. |

- changed (2018-09-11):
[0001571996-18-000034:note_history:33]
| (2) | Identify the performance obligations in the contract. Distinct promises within a contract are referred to as "performance obligations" and are accounted for as separate units of account. The Company assesses whether each promised good or service is distinct for the purpose of identifying the performance obligations in the contract. This assessment involves subjective determinations and requires management to make judgments about the individual promised goods or services and whether such goods or services are separable from the other aspects of the contractual relationship. Promised goods and services are considered distinct provided that: (i) the customer can benefit from the good or service either on its own or together with other resources that are readily available to the customer (that is, the good or service is capable of being distinct); and (ii) the Company's promise to transfer the good or service to the customer is separately identifiable from other promises in the contract (that is, the promise to transfer the good or service is distinct within the context of the contract). The Company's performance obligations consist of a variety of products and services offerings which include: hardware, such as servers, storage, networking, personal computers, workstations, and peripherals; third-party software; proprietary software licenses; support and deployment services, which include hardware support that extends beyond the Company's standard warranties, software maintenance, and installation; professional services; training; software as a service ("SaaS"); and infrastructure as a service ("IaaS"). |
  (was, 2018-06-12, similarity 0.9213):
[0001571996-18-000022:note_history:33]
| (2) | Identify the performance obligations in the contract. Distinct promises within a contract are referred to as "performance obligations" and are accounted for as separate units of account. The Company assesses whether each promised good or service is distinct for the purpose of identifying the performance obligations in the contract. This assessment involves subjective determinations and requires management to make judgments about the individual promised goods or services and whether such goods or services are separable from the other aspects of the contractual relationship. Promised goods and services are considered distinct provided that: (i) the customer can benefit from the good or service either on its own or together with other resources that are readily available to the customer (that is, the good or service is capable of being distinct); and (ii) the Company's promise to transfer the good or service to the customer is separately identifiable from other promises in the contract (that is, the promise to transfer the good or service is distinct within the context of the contract). The Company's performance obligations consist of a variety of products and services offerings which include: computer and enterprise hardware, such as servers, storage, networking products, personal computers, workstations and peripherals; third-party software; proprietary software licenses; support and deployment services, including hardware support that extends beyond the Company's standard warranties, software maintenance, and installation; professional services; training; software as a service ("SaaS"); and infrastructure as a service ("IaaS"). |

- changed (2018-09-11):
[0001571996-18-000034:note_history:34]
| (5) | Recognize revenue when (or as) the performance obligation is satisfied. Revenue is recognized when obligations under the terms of the contract with the Company's customer are satisfied. Revenue is recognized either over time or at a point in time, depending on when the underlying products or services are transferred to the customer. Revenue is recognized at a point in time for products upon transfer of control. Revenue is recognized over time for support and deployment services, professional services, training, software support, SaaS, and IaaS. |
  (was, 2018-06-12, similarity 0.8874):
[0001571996-18-000022:note_history:34]
| (5) | Recognize revenue when (or as) the performance obligation is satisfied. Revenue is recognized when obligations under the terms of the contract with our customer are satisfied. Revenue is recognized either over time or at a point in time, depending on when the underlying products or services are transferred to the customer. Revenue is recorded at a point in time for products upon transfer of control. Revenue is recognized over time for support services, professional services, training, SaaS, and IaaS. |

- changed (2018-09-11):
[0001571996-18-000034:note_history:35]
Revenue from leasing arrangements is not subject to the revenue standard for contracts with customers, and remains separately accounted for under existing lease accounting guidance.  The Company records revenue from the sale of equipment under sales-type leases as product revenue in an amount equal to the present value of minimum lease payments at the inception of the lease.  Sales-type leases also produce financing income, which is included in products net revenue in the Consolidated Statements of Income (Loss) and is recognized at consistent rates of return over the lease term.  The Company also offers qualified customers fixed-term loans and revolving credit lines for the purchase of products and services offered by the Company.  Financing income attributable to these loans is recognized in products net revenue on an accrual basis.
  (was, 2018-06-12, similarity 0.943):
[0001571996-18-000022:note_history:35]
Revenue from leasing arrangements is not subject to the new revenue standard from contracts with customers, and remains separately accounted for under existing lease accounting guidance.  The Company records revenue from the sale of equipment under sales-type leases as product revenue in an amount equal to the present value of minimum lease payments at the inception of the lease.  Sales-type leases also produce financing income, which is included in net products revenue in the Consolidated Statements of Income (Loss) and is recognized at consistent rates of return over the lease term.  The Company also offers qualified customers fixed-term loans and revolving credit lines for the purchase of products and services offered by the Company.  Financing income attributable to these loans is recognized in product revenue on an accrual basis.

- changed (2018-09-11):
[0001571996-18-000034:note_history:36]
Disaggregation of Revenue — The Company's revenue is presented on a disaggregated basis on the Condensed Consolidated Statements of Income (Loss) and in Note 18 of the Notes to the Condensed Consolidated Financial Statements based on an evaluation of disclosures outside of the financial statements, information regularly reviewed by the chief operating decision maker for evaluating the financial performance of operating segments, and other information that is used to evaluate the Company's financial performance or make resource allocations.  This information includes revenue from products and services, revenue from reportable segments, and revenue by major product categories within the segments.
  (was, 2018-06-12, similarity 0.9914):
[0001571996-18-000022:note_history:36]
Disaggregation of Revenue — The Company's revenue is presented on a disaggregated basis on the Condensed Consolidated Statements of Income (Loss) and in Note 18 of the Notes to the Condensed Consolidated Financial Statements based on an evaluation of disclosures outside of the financial statements, information regularly reviewed by the chief operating decision maker for evaluating the financial performance of operating segments, and other information that is used to evaluate the Company's financial performance or make resource allocations.  This information includes revenue from product and services, revenue from reportable segments, and revenue by major product lines within the segments.

- changed (2018-09-11):
[0001571996-18-000034:note_history:37]
Costs to Obtain a Contract — The incremental direct costs of obtaining a contract primarily consist of sales commissions and employer taxes related to commission payments.  The Company has elected, as a practical expedient, to expense as incurred costs to obtain a contract equal to or less than one year in duration.  For contracts greater than one year in duration, the associated costs to obtain a contract are deferred and amortized over the period of contract performance or a longer period, generally the estimated life of the customer relationship, if renewals are expected and the renewal commission is not commensurate with the initial commission.  Deferred costs to obtain a contract are typically amortized over a period of three to seven years, depending on the contract term and expectation of the period of benefit for the costs, which may exceed the contract term.  Amortization expense is recognized on a straight-line basis and included in selling, general, and administrative expenses in the Condensed Consolidated Statements of Income (Loss).  The Company periodically reviews these deferred costs to determine whether events or changes in circumstances have occurred that could impact the carrying value or period of benefit of the deferred sales commissions.  There were no material impairment losses for deferred sales commissions during the six months ended August 3, 2018 and August 4, 2017.
  (was, 2018-06-12, similarity 0.9735):
[0001571996-18-000022:note_history:37]
Costs to Obtain a Contract — The incremental direct costs of obtaining a contract primarily consist of sales commissions and employer taxes related to commission payments.  The Company has elected, as a practical expedient, to expense as incurred costs to obtain a contract equal to or less than one year in duration.  For contracts greater than one year in duration, the associated costs to obtain a contract are deferred and amortized over the period of contract performance or a longer period, generally the estimated life of the customer relationship, if renewals are expected and the renewal commission is not commensurate with the initial commission.  Deferred costs to obtain a contract are typically amortized over a period of 3 to 7 years, depending on the contract term and expectation of the period of benefit for the costs, which may exceed the contract term.  Amortization expense is recognized on a straight-line basis and included in selling, general, and administrative expenses in the Condensed Consolidated Statements of Income (Loss).  The Company periodically reviews these deferred costs to determine whether events or changes in circumstances have occurred that could impact the carrying value or period of benefit of the deferred sales commissions.  There were no material impairment losses for deferred sales commissions during the three months ended May 4, 2018 and May 5, 2017.

- changed (2018-09-11):
[0001571996-18-000034:note_history:38]
Deferred costs to obtain a contract as of August 3, 2018 and February 2, 2018 were $1.0 billion and $0.8 billion, respectively.  Deferred costs to obtain a contract are classified as current assets and other non-current assets on the Condensed Consolidated Statements of Financial Position, based on when the expense is expected to be recognized.  Amortization of costs to obtain a contract during the three months ended August 3, 2018 and August 4, 2017 was $113 million and $62 million, respectively.  Amortization of costs to obtain a contract during the six months ended August 3, 2018 and August 4, 2017 was $219 million and $115 million, respectively.
  (was, 2018-06-12, similarity 0.8004):
[0001571996-18-000022:note_history:38]
Deferred costs to obtain a contract as of May 4, 2018 and February 2, 2018 were $909 million and $834 million, respectively.  Deferred costs to obtain a contract are classified as current assets and other non-current assets on the Condensed Consolidated Statements of Financial Position, based on when the expense is expected to be recognized.  Amortization of costs to obtain a contract during the three months ended May 4, 2018 and May 5, 2017 was $108 million and $54 million, respectively.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-09-11):
[0001571996-18-000034:note_history:39]
|  | August 3, 2018 |  | February 2, 2018 |
|  | (in millions) |
| Secured Debt |  |  |  |
| Senior Secured Credit Facilities: |  |  |  |
| 4.08% Term Loan B Facility due September 2023 | $ | 4,963 |  |  | $ | 4,988 |  |
| 3.83% Term Loan A-2 Facility due September 2021 | 4,283 |  |  | 4,394 |  |
| 3.58% Term Loan A-3 Facility due December 2018 | 1,213 |  |  | 1,213 |  |
| First Lien Notes: |  |  |  |
| 3.48% due June 2019 | 3,750 |  |  | 3,750 |  |
| 4.42% due June 2021 | 4,500 |  |  | 4,500 |  |
| 5.45% due June 2023 | 3,750 |  |  | 3,750 |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 8.10% due July 2036 | 1,500 |  |  | 1,500 |  |
| 8.35% due July 2046 | 2,000 |  |  | 2,000 |  |
| Unsecured Debt |  |  |  |
| Unsecured Notes and Debentures: |  |  |  |
| 5.65% due April 2018 | — |  |  | 500 |  |
| 5.875% due June 2019 | 600 |  |  | 600 |  |
| 4.625% due April 2021 | 400 |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| Senior Notes: |  |  |  |
| 5.875% due June 2021 | 1,625 |  |  | 1,625 |  |
| 7.125% due June 2024 | 1,625 |  |  | 1,625 |  |
| EMC Notes: |  |  |  |
| 1.875% due June 2018 | — |  |  | 2,500 |  |
| 2.650% due June 2020 | 2,000 |  |  | 2,000 |  |
| 3.375% due June 2023 | 1,000 |  |  | 1,000 |  |
| VMware Notes: |  |  |  |
| 2.30% due August 2020 | 1,250 |  |  | 1,250 |  |
| 2.95% due August 2022 | 1,500 |  |  | 1,500 |  |
| 3.90% due August 2027 | 1,250 |  |  | 1,250 |  |
| DFS Debt (Note 5) | 5,586 |  |  | 4,796 |  |
| Other |  |  |  |
| 4.59% Margin Loan Facility due April 2022 | 2,000 |  |  | 2,000 |  |
| Other | 56 |  |  | 101 |  |
| Total debt, principal amount | $ | 50,303 |  |  | $ | 52,694 |  |
  (was, 2018-06-12, similarity 0.9958):
[0001571996-18-000022:note_history:39]
|  | May 4, 2018 |  | February 2, 2018 |
|  | (in millions) |
| Secured Debt |  |  |  |
| Senior Secured Credit Facilities: |  |  |  |
| 3.91% Term Loan B Facility due September 2023 | $ | 4,975 |  |  | $ | 4,988 |  |
| 3.66% Term Loan A-2 Facility due September 2021 | 4,339 |  |  | 4,394 |  |
| 3.41% Term Loan A-3 Facility due December 2018 | 1,213 |  |  | 1,213 |  |
| First Lien Notes: |  |  |  |
| 3.48% due June 2019 | 3,750 |  |  | 3,750 |  |
| 4.42% due June 2021 | 4,500 |  |  | 4,500 |  |
| 5.45% due June 2023 | 3,750 |  |  | 3,750 |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 8.10% due July 2036 | 1,500 |  |  | 1,500 |  |
| 8.35% due July 2046 | 2,000 |  |  | 2,000 |  |
| Unsecured Debt |  |  |  |
| Unsecured Notes and Debentures: |  |  |  |
| 5.65% due April 2018 | — |  |  | 500 |  |
| 5.875% due June 2019 | 600 |  |  | 600 |  |
| 4.625% due April 2021 | 400 |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| Senior Notes: |  |  |  |
| 5.875% due June 2021 | 1,625 |  |  | 1,625 |  |
| 7.125% due June 2024 | 1,625 |  |  | 1,625 |  |
| EMC Notes: |  |  |  |
| 1.875% due June 2018 | 2,500 |  |  | 2,500 |  |
| 2.650% due June 2020 | 2,000 |  |  | 2,000 |  |
| 3.375% due June 2023 | 1,000 |  |  | 1,000 |  |
| VMware Notes: |  |  |  |
| 2.30% due August 2020 | 1,250 |  |  | 1,250 |  |
| 2.95% due August 2022 | 1,500 |  |  | 1,500 |  |
| 3.90% due August 2027 | 1,250 |  |  | 1,250 |  |
| DFS Debt (Note 5) | 5,359 |  |  | 4,796 |  |
| Other |  |  |  |
| 4.61% Margin Loan Facility due April 2022 | 2,000 |  |  | 2,000 |  |
| Other | 99 |  |  | 101 |  |
| Total debt, principal amount | $ | 52,687 |  |  | $ | 52,694 |  |

- changed (2018-09-11):
[0001571996-18-000034:note_history:40]
|  | August 3, 2018 |  | February 2, 2018 |
|  | (in millions) |
| Total debt, principal amount | $ | 50,303 |  |  | $ | 52,694 |  |
| Unamortized discount, net of unamortized premium | (246 | ) |  | (266 | ) |
| Debt issuance costs | (499 | ) |  | (557 | ) |
| Total debt, carrying value | $ | 49,558 |  |  | $ | 51,871 |  |
| Total short-term debt, carrying value | $ | 9,144 |  |  | $ | 7,873 |  |
| Total long-term debt, carrying value | $ | 40,414 |  |  | $ | 43,998 |  |
  (was, 2018-06-12, similarity 0.9888):
[0001571996-18-000022:note_history:40]
|  | May 4, 2018 |  | February 2, 2018 |
|  | (in millions) |
| Total debt, principal amount | $ | 52,687 |  |  | $ | 52,694 |  |
| Unamortized discount, net of unamortized premium | (256 | ) |  | (266 | ) |
| Debt issuance costs | (528 | ) |  | (557 | ) |
| Total debt, carrying value | $ | 51,903 |  |  | $ | 51,871 |  |
| Total short-term debt, carrying value | $ | 7,133 |  |  | $ | 7,873 |  |
| Total long-term debt, carrying value | $ | 44,770 |  |  | $ | 43,998 |  |

- added (2018-09-11):
[0001571996-18-000034:note_history:41]
During the six months ended August 3, 2018, the Company repaid $3 billion principal amount of its unsecured notes and $136 million principal amount of its term loan facilities.  Additionally, during the six months ended August 3, 2018, the Company issued an additional $868 million, net, in DFS debt to support the expansion of its financing receivables portfolio.

- changed (2018-09-11):
[0001571996-18-000034:note_history:42]
Senior Secured Credit Facilities — The Company has entered into a credit agreement that provides for senior secured credit facilities (the "Senior Secured Credit Facilities") in the aggregate principal amount of $17.6 billion comprising (a) term loan facilities and (b) a senior secured Revolving Credit Facility, which includes capacity for up to $0.5 billion of letters of credit and for borrowings of up to $0.4 billion under swing-line loans.  As of August 3, 2018, available borrowings under the Revolving Credit Facility totaled $3.3 billion.  The Senior Secured Credit Facilities provide that the borrowers have the right at any time, subject to customary conditions, to request incremental term loans or incremental revolving commitments.
  (was, 2018-06-12, similarity 0.9938):
[0001571996-18-000022:note_history:42]
Senior Secured Credit Facilities — The Company has entered into a credit agreement that provides for senior secured credit facilities (the "Senior Secured Credit Facilities") in the aggregate principal amount of $17.6 billion comprising (a) term loan facilities and (b) a senior secured Revolving Credit Facility, which includes capacity for up to $0.5 billion of letters of credit and for borrowings of up to $0.4 billion under swing-line loans.  As of May 4, 2018, available borrowings under the Revolving Credit Facility totaled $3.3 billion.  The Senior Secured Credit Facilities provide that the borrowers have the right at any time, subject to customary conditions, to request incremental term loans or incremental revolving commitments.

- changed (2018-09-11):
[0001571996-18-000034:note_history:43]
All obligations of the borrowers under the Senior Secured Credit Facilities and certain swap agreements, cash management arrangements, and certain letters of credit provided by any lender or agent party to the Senior Secured Credit Facilities or any of its affiliates and certain other persons are secured by (a) a first-priority security interest in certain tangible and intangible assets of the borrowers and the guarantors and (b) a first-priority pledge of 100% of the capital stock of the borrowers, Dell Inc., a wholly‑owned subsidiary of the Company ("Dell"), and each wholly-owned material restricted subsidiary of the borrowers and the guarantors, in each case subject to certain thresholds, exceptions, and permitted liens.
  (was, 2018-06-12, similarity 0.7711):
[0001571996-18-000022:note_history:43]
All obligations of the borrowers under the Senior Secured Credit Facilities and certain swap agreements, cash management arrangements, and certain letters of credit provided by any lender or agent party to the Senior Secured Credit Facilities or any of its affiliates and certain other persons are secured by (a) a first-priority security interest in certain tangible and intangible assets of the borrowers and the guarantors and (b) a first-priority pledge of 100% of the capital stock of the borrowers, Dell Inc., and each wholly-owned material restricted subsidiary of the borrowers and the guarantors, in each case subject to certain thresholds, exceptions, and permitted liens.

- changed (2018-09-11):
[0001571996-18-000034:note_history:44]
First Lien Notes — The senior secured notes (collectively, the "First Lien Notes") were issued on June 1, 2016 in an aggregate principal amount of $20.0 billion.  Interest on these borrowings is payable semiannually.  The First Lien Notes are secured, on a pari passu basis with the Senior Secured Credit Facilities, on a first-priority basis by substantially all of the tangible and intangible assets of the issuers and guarantors that secure obligations under the Senior Secured Credit Facilities, including pledges of all capital stock of the issuers, Dell, and certain wholly-owned material subsidiaries of the issuers and the guarantors, subject to certain exceptions.
  (was, 2018-06-12, similarity 0.9312):
[0001571996-18-000022:note_history:44]
First Lien Notes — The senior secured notes (collectively, the "First Lien Notes") were issued on June 1, 2016 in an aggregate principal amount of $20.0 billion.  Interest on these borrowings is payable semiannually.  The First Lien Notes are secured, on a pari passu basis with the Senior Secured Credit Facilities, on a first-priority basis by substantially all of the tangible and intangible assets of the issuers and guarantors that secure obligations under the Senior Secured Credit Facilities, including pledges of all capital stock of the issuers, of Dell Inc., a wholly‑owned subsidiary of Dell Technologies ("Dell"), and of certain wholly-owned material subsidiaries of the issuers and the guarantors, subject to certain exceptions.

- changed (2018-09-11):
[0001571996-18-000034:note_history:45]
China Revolving Credit Facility — On October 31, 2017, the Company entered into a credit agreement (the "China Revolving Credit Facility") with a bank lender for a secured revolving loan facility in an aggregate principal amount not to exceed $500 million.  Borrowings under the China Revolving Credit Facility bear interest at LIBOR plus 0.6% per annum.  The Company may voluntarily repay outstanding loans under the China Revolving Credit Facility at any time without premium or penalty, other than customary "breakage" costs.  The facility will expire on October 31, 2018.  As of August 3, 2018, there were no outstanding borrowings under the China Revolving Credit Facility.
  (was, 2018-06-12, similarity 0.9923):
[0001571996-18-000022:note_history:45]
China Revolving Credit Facility — On October 31, 2017, the Company entered into a credit agreement (the "China Revolving Credit Facility") with a bank lender for a secured revolving loan facility in an aggregate principal amount not to exceed $500 million.  Borrowings under the China Revolving Credit Facility bear interest at LIBOR plus 0.6% per annum .  The Company may voluntarily repay outstanding loans under the China Revolving Credit Facility at any time without premium or penalty, other than customary "breakage" costs.  The facility will expire on October 31, 2018.  As of May 4, 2018, there were no outstanding borrowings under the China Revolving Credit Facility.

- changed (2018-09-11):
[0001571996-18-000034:note_history:46]
EMC Notes — On September 7, 2016, EMC had outstanding $2.5 billion aggregate principal amount of its 1.875% Notes due June 2018, which the Company fully repaid during the three months ended August 3, 2018, $2.0 billion aggregate principal amount of its 2.650% Notes due June 2020, and $1.0 billion aggregate principal amount of its 3.375% Notes due June 2023 (collectively, the "EMC Notes").  Interest on these borrowings is payable semiannually.  The EMC Notes remain outstanding following the closing of the EMC merger transaction.
  (was, 2018-06-12, similarity 0.9211):
[0001571996-18-000022:note_history:46]
EMC Notes — On September 7, 2016, EMC had outstanding $2.5 billion aggregate principal amount of its 1.875% Notes due June 2018, $2.0 billion aggregate principal amount of its 2.650% Notes due June 2020, and $1.0 billion aggregate principal amount of its 3.375% Notes due June 2023 (collectively, the "EMC Notes").  Interest on these borrowings is payable semiannually.  The EMC Notes remain outstanding following the closing of the EMC merger transaction.

- changed (2018-09-11):
[0001571996-18-000034:note_history:47]
VMware Revolving Credit Facility —  On September 12, 2017, VMware, Inc. entered into an unsecured credit agreement, establishing a revolving credit facility (the "VMware Revolving Credit Facility"), with a syndicate of lenders that provides the company with a borrowing capacity of up to $1.0 billion which may be used for VMware, Inc. general corporate purposes.  Commitments under the VMware Revolving Credit Facility are available for a period of five years, which may be extended, subject to the satisfaction of certain conditions, by up to two one year periods.  The credit agreement contains certain representations, warranties, and covenants.  Commitment fees, interest rates, and other terms of borrowing under the VMware Revolving Credit Facility may vary based on VMware, Inc.’s external credit ratings.  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.  As of August 3, 2018, there were no outstanding borrowings under the VMware Revolving Credit Facility.
  (was, 2018-06-12, similarity 0.9664):
[0001571996-18-000022:note_history:47]
VMware Revolving Credit Facility —  On September 12, 2017, VMware, Inc. entered into an unsecured credit agreement, establishing a revolving credit facility (the “VMware Revolving Credit Facility”), with a syndicate of lenders that provides the company with a borrowing capacity of up to $1.0 billion which may be used for VMware, Inc. general corporate purposes.  Commitments under the VMware Revolving Credit Facility are available for a period of five years, which may be extended, subject to the satisfaction of certain conditions, by up to two one year periods.  The credit agreement contains certain representations, warranties, and covenants.  Commitment fees, interest rates, and other terms of borrowing under the VMware Revolving Credit Facility may vary based on VMware, Inc.’s external credit ratings.  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.  As of May 4, 2018, there were no outstanding borrowings under the VMware Revolving Credit Facility.

- changed (2018-09-11):
[0001571996-18-000034:note_history:48]
Pivotal Revolving Credit Facility — On September 7, 2017, Pivotal entered into a credit agreement (the "Pivotal Revolving Credit Facility") that provides for a senior secured revolving loan facility in an aggregate principal amount not to exceed $100 million.  The credit facility contains customary representations, warranties, and covenants, including financial covenants.  The credit agreement will expire on September 8, 2020, unless it is terminated earlier.  None of the net proceeds of borrowings under the facility will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of Pivotal and Pivotal's subsidiaries.  As of August 3, 2018, there were no outstanding borrowings under the Pivotal Revolving Credit Facility.
  (was, 2018-06-12, similarity 0.9944):
[0001571996-18-000022:note_history:48]
Pivotal Revolving Credit Facility — On September 7, 2017, Pivotal entered into a credit agreement (the "Pivotal Revolving Credit Facility") that provides for a senior secured revolving loan facility in an aggregate principal amount not to exceed $100 million.  The credit facility contains customary representations, warranties, and covenants, including financial covenants.  The credit agreement will expire on September 8, 2020, unless it is terminated earlier.  None of the net proceeds of borrowings under the facility will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of Pivotal and Pivotal's subsidiaries.  As of May 4, 2018, there were no outstanding borrowings under the Pivotal Revolving Credit Facility.

- changed (2018-09-11):
[0001571996-18-000034:note_history:49]
As of August 3, 2018, aggregate future maturities of the Company's debt were as follows:
  (was, 2018-06-12, similarity 0.9571):
[0001571996-18-000022:note_history:49]
As of May 4, 2018, aggregate future maturities of the Company's debt were as follows:

- changed (2018-09-11):
[0001571996-18-000034:note_history:50]
|  | Maturities by Fiscal Year |
|  | 2019 (remaining six months) |  | 2020 |  | 2021 |  | 2022 |  | 2023 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Secured Credit Facilities and First Lien Notes | $ | 1,405 |  |  | $ | 4,245 |  |  | $ | 371 |  |  | $ | 7,888 |  |  | $ | 63 |  |  | $ | 16,488 |  |  | $ | 30,460 |  |
| Unsecured Notes and Debentures | — |  |  | 600 |  |  | — |  |  | 400 |  |  | — |  |  | 952 |  |  | 1,952 |  |
| Senior Notes and EMC Notes | — |  |  | — |  |  | 2,000 |  |  | 1,625 |  |  | — |  |  | 2,625 |  |  | 6,250 |  |
| VMware Notes | — |  |  | — |  |  | 1,250 |  |  | — |  |  | 1,500 |  |  | 1,250 |  |  | 4,000 |  |
| DFS Debt | 1,931 |  |  | 1,998 |  |  | 1,459 |  |  | 165 |  |  | 31 |  |  | 1 |  |  | 5,585 |  |
| Margin Loan Facility | — |  |  | — |  |  | — |  |  | — |  |  | 2,000 |  |  | — |  |  | 2,000 |  |
| Other | 16 |  |  | 24 |  |  | 14 |  |  | — |  |  | — |  |  | 2 |  |  | 56 |  |
| Total maturities, principal amount | 3,352 |  |  | 6,867 |  |  | 5,094 |  |  | 10,078 |  |  | 3,594 |  |  | 21,318 |  |  | 50,303 |  |
| Associated carrying value adjustments | (4 | ) |  | (21 | ) |  | (7 | ) |  | (164 | ) |  | (27 | ) |  | (522 | ) |  | (745 | ) |
| Total maturities, carrying value amount | $ | 3,348 |  |  | $ | 6,846 |  |  | $ | 5,087 |  |  | $ | 9,914 |  |  | $ | 3,567 |  |  | $ | 20,796 |  |  | $ | 49,558 |  |
  (was, 2018-06-12, similarity 0.9958):
[0001571996-18-000022:note_history:50]
|  | Maturities by Fiscal Year |
|  | 2019 (remaining nine months) |  | 2020 |  | 2021 |  | 2022 |  | 2023 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Secured Credit Facilities and First Lien Notes | $ | 1,473 |  |  | $ | 4,245 |  |  | $ | 371 |  |  | $ | 7,888 |  |  | $ | 63 |  |  | $ | 16,487 |  |  | $ | 30,527 |  |
| Unsecured Notes and Debentures | — |  |  | 600 |  |  | — |  |  | 400 |  |  | — |  |  | 952 |  |  | 1,952 |  |
| Senior Notes and EMC Notes | 2,500 |  |  | — |  |  | 2,000 |  |  | 1,625 |  |  | — |  |  | 2,625 |  |  | 8,750 |  |
| VMware Notes | — |  |  | — |  |  | 1,250 |  |  | — |  |  | 1,500 |  |  | 1,250 |  |  | 4,000 |  |
| DFS Debt | 2,565 |  |  | 1,538 |  |  | 1,158 |  |  | 84 |  |  | 13 |  |  | 1 |  |  | 5,359 |  |
| Margin Loan Facility | — |  |  | — |  |  | — |  |  | — |  |  | 2,000 |  |  | — |  |  | 2,000 |  |
| Other | 11 |  |  | 10 |  |  | 46 |  |  | — |  |  | — |  |  | 32 |  |  | 99 |  |
| Total maturities, principal amount | 6,549 |  |  | 6,393 |  |  | 4,825 |  |  | 9,997 |  |  | 3,576 |  |  | 21,347 |  |  | 52,687 |  |
| Associated carrying value adjustments | (8 | ) |  | (27 | ) |  | (8 | ) |  | (178 | ) |  | (30 | ) |  | (533 | ) |  | (784 | ) |
| Total maturities, carrying value amount | $ | 6,541 |  |  | $ | 6,366 |  |  | $ | 4,817 |  |  | $ | 9,819 |  |  | $ | 3,546 |  |  | $ | 20,814 |  |  | $ | 51,903 |  |

- changed (2018-09-11):
[0001571996-18-000034:note_history:51]
Covenants and Unrestricted Net Assets — The credit agreement for the Senior Secured Credit Facilities contains customary negative covenants that generally limit the ability of Denali Intermediate Inc., a wholly-owned subsidiary of Dell Technologies ("Dell Intermediate"), Dell, and Dell's and Denali Intermediate's other restricted subsidiaries to incur debt, create liens, make fundamental changes, enter into asset sales, make certain investments, pay dividends or distribute or redeem certain equity interests, prepay or redeem certain debt, and enter into certain transactions with affiliates.  The indenture governing the Senior Notes contains customary negative covenants that generally limit the ability of Denali Intermediate, Dell, and Dell's and Denali Intermediate's other restricted subsidiaries to incur additional debt or issue certain preferred shares, pay dividends on or make other distributions in respect of capital stock or make other restricted payments, make certain investments, sell or transfer certain assets, create liens on certain assets to secure debt, consolidate, merge, sell, or otherwise dispose of all or substantially all assets, enter into certain transactions with affiliates, and designate subsidiaries as unrestricted subsidiaries.  The negative covenants under such credit agreements and indenture are subject to certain exceptions, qualifications, and "baskets."  The indentures governing the First Lien Notes, the Unsecured Notes and Debentures, and the EMC Notes variously impose limitations, subject to specified exceptions, on creating certain liens, entering into sale and lease-back transactions, and entering into certain asset sales.  The foregoing credit agreements and indentures contain customary events of default, including failure to make required payments, failure to comply with covenants, and the occurrence of certain events of bankruptcy and insolvency.
  (was, 2018-06-12, similarity 0.9997):
[0001571996-18-000022:note_history:51]
Covenants and Unrestricted Net Assets — The credit agreement for the Senior Secured Credit Facilities contain customary negative covenants that generally limit the ability of Denali Intermediate Inc., a wholly-owned subsidiary of Dell Technologies ("Dell Intermediate"), Dell, and Dell's and Denali Intermediate's other restricted subsidiaries to incur debt, create liens, make fundamental changes, enter into asset sales, make certain investments, pay dividends or distribute or redeem certain equity interests, prepay or redeem certain debt, and enter into certain transactions with affiliates.  The indenture governing the Senior Notes contains customary negative covenants that generally limit the ability of Denali Intermediate, Dell, and Dell's and Denali Intermediate's other restricted subsidiaries to incur additional debt or issue certain preferred shares, pay dividends on or make other distributions in respect of capital stock or make other restricted payments, make certain investments, sell or transfer certain assets, create liens on certain assets to secure debt, consolidate, merge, sell, or otherwise dispose of all or substantially all assets, enter into certain transactions with affiliates, and designate subsidiaries as unrestricted subsidiaries.  The negative covenants under such credit agreements and indenture are subject to certain exceptions, qualifications, and "baskets."  The indentures governing the First Lien Notes, the Unsecured Notes and Debentures, and the EMC Notes variously impose limitations, subject to specified exceptions, on creating certain liens, entering into sale and lease-back transactions, and entering into certain asset sales.  The foregoing credit agreements and indentures contain customary events of default, including failure to make required payments, failure to comply with covenants, and the occurrence of certain events of bankruptcy and insolvency.

- changed (2018-09-11):
[0001571996-18-000034:note_history:52]
As of August 3, 2018, the Company had certain consolidated subsidiaries that were designated as unrestricted subsidiaries for all purposes of the applicable credit agreements and the indentures governing the First Lien Notes and the Senior Notes.
  (was, 2018-06-12, similarity 0.9812):
[0001571996-18-000022:note_history:52]
As of May 4, 2018, the Company had certain consolidated subsidiaries that were designated as unrestricted subsidiaries for all purposes of the applicable credit agreements and the indentures governing the First Lien Notes and the Senior Notes.

- changed (2018-09-11):
[0001571996-18-000034:note_history:53]
The Term Loan A-2 Facility, the Term Loan A-3 Facility, and the Revolving Credit Facility are subject to a first lien net leverage ratio covenant that is tested at the end of each fiscal quarter of Dell with respect to Dell's preceding four fiscal quarters.  The Company was in compliance with all financial covenants as of August 3, 2018.
  (was, 2018-06-12, similarity 0.9864):
[0001571996-18-000022:note_history:53]
The Term Loan A-2 Facility, the Term Loan A-3 Facility, and the Revolving Credit Facility are subject to a first lien net leverage ratio covenant that is tested at the end of each fiscal quarter of Dell with respect to Dell's preceding four fiscal quarters.  The Company was in compliance with all financial covenants as of May 4, 2018.

- removed (2018-09-11):
[0001571996-18-000022:note_history:54]
During the three months ended May 4, 2018, the Company repaid $500 million principal amount of its 5.65% unsecured notes due April 2018 and $68 million principal amount of its term loan facilities.  Further, the Company issued an additional $611 million, net, in DFS debt to support the expansion of its financing receivables portfolio.


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-09-11):
[0001571996-18-000034:note_history:55]
|  | August 3, 2018 |  | February 2, 2018 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Secured Credit Facilities | $ | 10.3 |  |  | $ | 10.5 |  |  | $ | 10.4 |  |  | $ | 10.6 |  |
| First Lien Notes | $ | 19.7 |  |  | $ | 21.3 |  |  | $ | 19.7 |  |  | $ | 21.9 |  |
| Unsecured Notes and Debentures | $ | 1.8 |  |  | $ | 2.0 |  |  | $ | 2.3 |  |  | $ | 2.5 |  |
| Senior Notes | $ | 3.1 |  |  | $ | 3.4 |  |  | $ | 3.1 |  |  | $ | 3.4 |  |
| EMC Notes | $ | 3.0 |  |  | $ | 2.9 |  |  | $ | 5.5 |  |  | $ | 5.4 |  |
| VMware Notes | $ | 4.0 |  |  | $ | 3.9 |  |  | $ | 4.0 |  |  | $ | 3.9 |  |
| Margin Loan Facility | $ | 2.0 |  |  | $ | 2.0 |  |  | $ | 2.0 |  |  | $ | 2.0 |  |
  (was, 2018-06-12, similarity 0.9926):
[0001571996-18-000022:note_history:55]
|  | May 4, 2018 |  | February 2, 2018 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Secured Credit Facilities | $ | 10.4 |  |  | $ | 10.6 |  |  | $ | 10.4 |  |  | $ | 10.6 |  |
| First Lien Notes | $ | 19.7 |  |  | $ | 21.2 |  |  | $ | 19.7 |  |  | $ | 21.9 |  |
| Unsecured Notes and Debentures | $ | 1.8 |  |  | $ | 2.0 |  |  | $ | 2.3 |  |  | $ | 2.5 |  |
| Senior Notes | $ | 3.1 |  |  | $ | 3.4 |  |  | $ | 3.1 |  |  | $ | 3.4 |  |
| EMC Notes | $ | 5.5 |  |  | $ | 5.4 |  |  | $ | 5.5 |  |  | $ | 5.4 |  |
| VMware Notes | $ | 4.0 |  |  | $ | 3.8 |  |  | $ | 4.0 |  |  | $ | 3.9 |  |
| Margin Loan Facility | $ | 2.0 |  |  | $ | 2.0 |  |  | $ | 2.0 |  |  | $ | 2.0 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-09-11):
[0001571996-18-000034:note_history:56]
|  | August 3, 2018 |  | February 2, 2018 |
|  | (in millions) |
| DFS U.S. debt |  |  |  |
| Securitization facilities | $ | 1,782 |  |  | $ | 1,498 |  |
| Fixed-term securitization offerings | 2,305 |  |  | 2,034 |  |
| Other | 132 |  |  | 32 |  |
| Total DFS U.S. debt | 4,219 |  |  | 3,564 |  |
| DFS international debt |  |  |  |
| Securitization facility | 497 |  |  | 404 |  |
| Other structured facilities | 670 |  |  | 628 |  |
| Note payable | 200 |  |  | 200 |  |
| Total DFS international debt | 1,367 |  |  | 1,232 |  |
| Total DFS debt | $ | 5,586 |  |  | $ | 4,796 |  |
| Total short-term DFS debt | $ | 3,130 |  |  | $ | 3,327 |  |
| Total long-term DFS debt | $ | 2,456 |  |  | $ | 1,469 |  |
  (was, 2018-06-12, similarity 0.9923):
[0001571996-18-000022:note_history:56]
|  | May 4, 2018 |  | February 2, 2018 |
|  | (in millions) |
| DFS U.S. debt |  |  |  |
| Securitization facilities | $ | 2,256 |  |  | $ | 1,498 |  |
| Fixed-term securitization offerings | 1,666 |  |  | 2,034 |  |
| Other | 150 |  |  | 32 |  |
| Total DFS U.S. debt | 4,072 |  |  | 3,564 |  |
| DFS international debt |  |  |  |
| Securitization facility | 471 |  |  | 404 |  |
| Other structured facilities | 618 |  |  | 628 |  |
| Note payable | 198 |  |  | 200 |  |
| Total DFS international debt | 1,287 |  |  | 1,232 |  |
| Total DFS debt | $ | 5,359 |  |  | $ | 4,796 |  |
| Total short-term DFS debt | $ | 3,019 |  |  | $ | 3,327 |  |
| Total long-term DFS debt | $ | 2,340 |  |  | $ | 1,469 |  |

- changed (2018-09-11):
[0001571996-18-000034:note_history:57]
|  | August 3, 2018 |  | February 2, 2018 |
|  | (in millions) |
| Secured Debt |  |  |  |
| Senior Secured Credit Facilities: |  |  |  |
| 4.08% Term Loan B Facility due September 2023 | $ | 4,963 |  |  | $ | 4,988 |  |
| 3.83% Term Loan A-2 Facility due September 2021 | 4,283 |  |  | 4,394 |  |
| 3.58% Term Loan A-3 Facility due December 2018 | 1,213 |  |  | 1,213 |  |
| First Lien Notes: |  |  |  |
| 3.48% due June 2019 | 3,750 |  |  | 3,750 |  |
| 4.42% due June 2021 | 4,500 |  |  | 4,500 |  |
| 5.45% due June 2023 | 3,750 |  |  | 3,750 |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 8.10% due July 2036 | 1,500 |  |  | 1,500 |  |
| 8.35% due July 2046 | 2,000 |  |  | 2,000 |  |
| Unsecured Debt |  |  |  |
| Unsecured Notes and Debentures: |  |  |  |
| 5.65% due April 2018 | — |  |  | 500 |  |
| 5.875% due June 2019 | 600 |  |  | 600 |  |
| 4.625% due April 2021 | 400 |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| Senior Notes: |  |  |  |
| 5.875% due June 2021 | 1,625 |  |  | 1,625 |  |
| 7.125% due June 2024 | 1,625 |  |  | 1,625 |  |
| EMC Notes: |  |  |  |
| 1.875% due June 2018 | — |  |  | 2,500 |  |
| 2.650% due June 2020 | 2,000 |  |  | 2,000 |  |
| 3.375% due June 2023 | 1,000 |  |  | 1,000 |  |
| VMware Notes: |  |  |  |
| 2.30% due August 2020 | 1,250 |  |  | 1,250 |  |
| 2.95% due August 2022 | 1,500 |  |  | 1,500 |  |
| 3.90% due August 2027 | 1,250 |  |  | 1,250 |  |
| DFS Debt (Note 5) | 5,586 |  |  | 4,796 |  |
| Other |  |  |  |
| 4.59% Margin Loan Facility due April 2022 | 2,000 |  |  | 2,000 |  |
| Other | 56 |  |  | 101 |  |
| Total debt, principal amount | $ | 50,303 |  |  | $ | 52,694 |  |
  (was, 2018-06-12, similarity 0.9958):
[0001571996-18-000022:note_history:57]
|  | May 4, 2018 |  | February 2, 2018 |
|  | (in millions) |
| Secured Debt |  |  |  |
| Senior Secured Credit Facilities: |  |  |  |
| 3.91% Term Loan B Facility due September 2023 | $ | 4,975 |  |  | $ | 4,988 |  |
| 3.66% Term Loan A-2 Facility due September 2021 | 4,339 |  |  | 4,394 |  |
| 3.41% Term Loan A-3 Facility due December 2018 | 1,213 |  |  | 1,213 |  |
| First Lien Notes: |  |  |  |
| 3.48% due June 2019 | 3,750 |  |  | 3,750 |  |
| 4.42% due June 2021 | 4,500 |  |  | 4,500 |  |
| 5.45% due June 2023 | 3,750 |  |  | 3,750 |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 8.10% due July 2036 | 1,500 |  |  | 1,500 |  |
| 8.35% due July 2046 | 2,000 |  |  | 2,000 |  |
| Unsecured Debt |  |  |  |
| Unsecured Notes and Debentures: |  |  |  |
| 5.65% due April 2018 | — |  |  | 500 |  |
| 5.875% due June 2019 | 600 |  |  | 600 |  |
| 4.625% due April 2021 | 400 |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| Senior Notes: |  |  |  |
| 5.875% due June 2021 | 1,625 |  |  | 1,625 |  |
| 7.125% due June 2024 | 1,625 |  |  | 1,625 |  |
| EMC Notes: |  |  |  |
| 1.875% due June 2018 | 2,500 |  |  | 2,500 |  |
| 2.650% due June 2020 | 2,000 |  |  | 2,000 |  |
| 3.375% due June 2023 | 1,000 |  |  | 1,000 |  |
| VMware Notes: |  |  |  |
| 2.30% due August 2020 | 1,250 |  |  | 1,250 |  |
| 2.95% due August 2022 | 1,500 |  |  | 1,500 |  |
| 3.90% due August 2027 | 1,250 |  |  | 1,250 |  |
| DFS Debt (Note 5) | 5,359 |  |  | 4,796 |  |
| Other |  |  |  |
| 4.61% Margin Loan Facility due April 2022 | 2,000 |  |  | 2,000 |  |
| Other | 99 |  |  | 101 |  |
| Total debt, principal amount | $ | 52,687 |  |  | $ | 52,694 |  |

- changed (2018-09-11):
[0001571996-18-000034:note_history:58]
|  | August 3, 2018 |  | February 2, 2018 |
|  | (in millions) |
| Total debt, principal amount | $ | 50,303 |  |  | $ | 52,694 |  |
| Unamortized discount, net of unamortized premium | (246 | ) |  | (266 | ) |
| Debt issuance costs | (499 | ) |  | (557 | ) |
| Total debt, carrying value | $ | 49,558 |  |  | $ | 51,871 |  |
| Total short-term debt, carrying value | $ | 9,144 |  |  | $ | 7,873 |  |
| Total long-term debt, carrying value | $ | 40,414 |  |  | $ | 43,998 |  |
  (was, 2018-06-12, similarity 0.9888):
[0001571996-18-000022:note_history:58]
|  | May 4, 2018 |  | February 2, 2018 |
|  | (in millions) |
| Total debt, principal amount | $ | 52,687 |  |  | $ | 52,694 |  |
| Unamortized discount, net of unamortized premium | (256 | ) |  | (266 | ) |
| Debt issuance costs | (528 | ) |  | (557 | ) |
| Total debt, carrying value | $ | 51,903 |  |  | $ | 51,871 |  |
| Total short-term debt, carrying value | $ | 7,133 |  |  | $ | 7,873 |  |
| Total long-term debt, carrying value | $ | 44,770 |  |  | $ | 43,998 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-09-11):
[0001571996-18-000034:note_history:59]
As of August 3, 2018, aggregate future maturities of the Company's debt were as follows:
  (was, 2018-06-12, similarity 0.9571):
[0001571996-18-000022:note_history:59]
As of May 4, 2018, aggregate future maturities of the Company's debt were as follows:

- changed (2018-09-11):
[0001571996-18-000034:note_history:60]
|  | Maturities by Fiscal Year |
|  | 2019 (remaining six months) |  | 2020 |  | 2021 |  | 2022 |  | 2023 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Secured Credit Facilities and First Lien Notes | $ | 1,405 |  |  | $ | 4,245 |  |  | $ | 371 |  |  | $ | 7,888 |  |  | $ | 63 |  |  | $ | 16,488 |  |  | $ | 30,460 |  |
| Unsecured Notes and Debentures | — |  |  | 600 |  |  | — |  |  | 400 |  |  | — |  |  | 952 |  |  | 1,952 |  |
| Senior Notes and EMC Notes | — |  |  | — |  |  | 2,000 |  |  | 1,625 |  |  | — |  |  | 2,625 |  |  | 6,250 |  |
| VMware Notes | — |  |  | — |  |  | 1,250 |  |  | — |  |  | 1,500 |  |  | 1,250 |  |  | 4,000 |  |
| DFS Debt | 1,931 |  |  | 1,998 |  |  | 1,459 |  |  | 165 |  |  | 31 |  |  | 1 |  |  | 5,585 |  |
| Margin Loan Facility | — |  |  | — |  |  | — |  |  | — |  |  | 2,000 |  |  | — |  |  | 2,000 |  |
| Other | 16 |  |  | 24 |  |  | 14 |  |  | — |  |  | — |  |  | 2 |  |  | 56 |  |
| Total maturities, principal amount | 3,352 |  |  | 6,867 |  |  | 5,094 |  |  | 10,078 |  |  | 3,594 |  |  | 21,318 |  |  | 50,303 |  |
| Associated carrying value adjustments | (4 | ) |  | (21 | ) |  | (7 | ) |  | (164 | ) |  | (27 | ) |  | (522 | ) |  | (745 | ) |
| Total maturities, carrying value amount | $ | 3,348 |  |  | $ | 6,846 |  |  | $ | 5,087 |  |  | $ | 9,914 |  |  | $ | 3,567 |  |  | $ | 20,796 |  |  | $ | 49,558 |  |
  (was, 2018-06-12, similarity 0.9958):
[0001571996-18-000022:note_history:60]
|  | Maturities by Fiscal Year |
|  | 2019 (remaining nine months) |  | 2020 |  | 2021 |  | 2022 |  | 2023 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Secured Credit Facilities and First Lien Notes | $ | 1,473 |  |  | $ | 4,245 |  |  | $ | 371 |  |  | $ | 7,888 |  |  | $ | 63 |  |  | $ | 16,487 |  |  | $ | 30,527 |  |
| Unsecured Notes and Debentures | — |  |  | 600 |  |  | — |  |  | 400 |  |  | — |  |  | 952 |  |  | 1,952 |  |
| Senior Notes and EMC Notes | 2,500 |  |  | — |  |  | 2,000 |  |  | 1,625 |  |  | — |  |  | 2,625 |  |  | 8,750 |  |
| VMware Notes | — |  |  | — |  |  | 1,250 |  |  | — |  |  | 1,500 |  |  | 1,250 |  |  | 4,000 |  |
| DFS Debt | 2,565 |  |  | 1,538 |  |  | 1,158 |  |  | 84 |  |  | 13 |  |  | 1 |  |  | 5,359 |  |
| Margin Loan Facility | — |  |  | — |  |  | — |  |  | — |  |  | 2,000 |  |  | — |  |  | 2,000 |  |
| Other | 11 |  |  | 10 |  |  | 46 |  |  | — |  |  | — |  |  | 32 |  |  | 99 |  |
| Total maturities, principal amount | 6,549 |  |  | 6,393 |  |  | 4,825 |  |  | 9,997 |  |  | 3,576 |  |  | 21,347 |  |  | 52,687 |  |
| Associated carrying value adjustments | (8 | ) |  | (27 | ) |  | (8 | ) |  | (178 | ) |  | (30 | ) |  | (533 | ) |  | (784 | ) |
| Total maturities, carrying value amount | $ | 6,541 |  |  | $ | 6,366 |  |  | $ | 4,817 |  |  | $ | 9,819 |  |  | $ | 3,546 |  |  | $ | 20,814 |  |  | $ | 51,903 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2018-09-11):
[0001571996-18-000034:note_history:61]
|  | Three Months Ended |  | Six Months Ended |
|  | August 3, 2018 |  | August 4, 2017 |  | August 3, 2018 |  | August 4, 2017 |
|  | (in millions) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |
| Infrastructure Solutions Group: |  |  |  |  |  |  |  |
| Servers and networking | $ | 5,061 |  |  | $ | 3,777 |  |  | $ | 9,646 |  |  | $ | 7,033 |  |
| Storage | 4,166 |  |  | 3,690 |  |  | 8,248 |  |  | 7,395 |  |
| Total ISG net revenue | 9,227 |  |  | 7,467 |  |  | 17,894 |  |  | 14,428 |  |
| Client Solutions Group: |  |  |  |  |  |  |  |
| Commercial | 8,109 |  |  | 7,207 |  |  | 15,472 |  |  | 13,549 |  |
| Consumer | 3,019 |  |  | 2,659 |  |  | 5,927 |  |  | 5,365 |  |
| Total CSG net revenue | 11,128 |  |  | 9,866 |  |  | 21,399 |  |  | 18,914 |  |
| VMware: |  |  |  |  |  |  |  |
| Total VMware net revenue | 2,194 |  |  | 1,984 |  |  | 4,222 |  |  | 3,802 |  |
| Total segment net revenue | $ | 22,549 |  |  | $ | 19,317 |  |  | $ | 43,515 |  |  | $ | 37,144 |  |

- removed (2018-09-11):
[0001571996-18-000022:note_history:62]
|  | Three Months Ended |
|  | May 4, 2018 |  | May 5, 2017 |
|  | (in millions) |
| Net revenue: |  |  |  |  |  |
| Infrastructure Solutions Group: |  |  |  |
| Servers and networking | $ | 4,585 |  |  | $ | 3,256 |  |
| Storage | 4,082 |  |  | 3,705 |  |
| Total ISG net revenue | 8,667 |  |  | 6,961 |  |
| Client Solutions Group: |  |  |  |
| Commercial | 7,363 |  |  | 6,342 |  |
| Consumer | 2,908 |  |  | 2,706 |  |
| Total CSG net revenue | 10,271 |  |  | 9,048 |  |
| VMware: |  |  |  |
| Total VMware net revenue | 2,028 |  |  | 1,818 |  |
| Total segment net revenue | $ | 20,966 |  |  | $ | 17,827 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: title_similarity, score: 1.0

- changed (2018-09-11):
[0001571996-18-000034:note_history:63]
| (1) | Identify the contract with a customer. The term "contract" refers to the enforceable rights and obligations provided in an agreement between the Company and one or more other parties in exchange for payment. The Company evaluates facts and circumstances regarding sales transactions in order to identify contracts with its customers. An agreement must meet all of the following criteria to qualify as a contract eligible for revenue recognition under the model: (i) the contract must be approved by all parties; (ii) each party's rights regarding the goods and services to be transferred to the customer can be identified; (iii) the payment terms for the goods and services can be identified; (iv) the customer has the ability and intent to pay and it is probable that the Company will collect substantially all of the consideration to which it will be entitled; and (v) the contract must have commercial substance. Judgment is used in determining the customer's ability and intent to pay, which is based upon various factors including the customer's historical payment experience or customer credit and financial information. |
  (was, 2018-06-12, similarity 0.9872):
[0001571996-18-000022:note_history:63]
| (1) | Identify the contract with a customer. The term “contract” refers to the enforceable rights and obligations provided in an agreement between the Company and one or more other parties in exchange for payment. The Company evaluates facts and circumstances regarding sales transactions in order to identify contracts with its customers. An agreement must meet all of the following criteria to qualify as a contract eligible for revenue recognition under the model: (i) the contract must be approved by all parties; (ii) each party's rights regarding the goods and services to be transferred to the customer can be identified; (iii) the payment terms for the good and services can be identified; (iv) the customer has the ability and intent to pay and it is probable that the Company will collect substantially all of the consideration to which it will be entitled; and (v) the contract must have commercial substance. Judgment is used in determining the customer's ability and intent to pay, which is based upon factors including the customer's historical payment experience or customer credit and financial information. |

- changed (2018-09-11):
[0001571996-18-000034:note_history:64]
| (2) | Identify the performance obligations in the contract. Distinct promises within a contract are referred to as "performance obligations" and are accounted for as separate units of account. The Company assesses whether each promised good or service is distinct for the purpose of identifying the performance obligations in the contract. This assessment involves subjective determinations and requires management to make judgments about the individual promised goods or services and whether such goods or services are separable from the other aspects of the contractual relationship. Promised goods and services are considered distinct provided that: (i) the customer can benefit from the good or service either on its own or together with other resources that are readily available to the customer (that is, the good or service is capable of being distinct); and (ii) the Company's promise to transfer the good or service to the customer is separately identifiable from other promises in the contract (that is, the promise to transfer the good or service is distinct within the context of the contract). The Company's performance obligations consist of a variety of products and services offerings which include: hardware, such as servers, storage, networking, personal computers, workstations, and peripherals; third-party software; proprietary software licenses; support and deployment services, which include hardware support that extends beyond the Company's standard warranties, software maintenance, and installation; professional services; training; software as a service ("SaaS"); and infrastructure as a service ("IaaS"). |
  (was, 2018-06-12, similarity 0.9213):
[0001571996-18-000022:note_history:64]
| (2) | Identify the performance obligations in the contract. Distinct promises within a contract are referred to as "performance obligations" and are accounted for as separate units of account. The Company assesses whether each promised good or service is distinct for the purpose of identifying the performance obligations in the contract. This assessment involves subjective determinations and requires management to make judgments about the individual promised goods or services and whether such goods or services are separable from the other aspects of the contractual relationship. Promised goods and services are considered distinct provided that: (i) the customer can benefit from the good or service either on its own or together with other resources that are readily available to the customer (that is, the good or service is capable of being distinct); and (ii) the Company's promise to transfer the good or service to the customer is separately identifiable from other promises in the contract (that is, the promise to transfer the good or service is distinct within the context of the contract). The Company's performance obligations consist of a variety of products and services offerings which include: computer and enterprise hardware, such as servers, storage, networking products, personal computers, workstations and peripherals; third-party software; proprietary software licenses; support and deployment services, including hardware support that extends beyond the Company's standard warranties, software maintenance, and installation; professional services; training; software as a service ("SaaS"); and infrastructure as a service ("IaaS"). |

- changed (2018-09-11):
[0001571996-18-000034:note_history:65]
| (5) | Recognize revenue when (or as) the performance obligation is satisfied. Revenue is recognized when obligations under the terms of the contract with the Company's customer are satisfied. Revenue is recognized either over time or at a point in time, depending on when the underlying products or services are transferred to the customer. Revenue is recognized at a point in time for products upon transfer of control. Revenue is recognized over time for support and deployment services, professional services, training, software support, SaaS, and IaaS. |
  (was, 2018-06-12, similarity 0.8874):
[0001571996-18-000022:note_history:65]
| (5) | Recognize revenue when (or as) the performance obligation is satisfied. Revenue is recognized when obligations under the terms of the contract with our customer are satisfied. Revenue is recognized either over time or at a point in time, depending on when the underlying products or services are transferred to the customer. Revenue is recorded at a point in time for products upon transfer of control. Revenue is recognized over time for support services, professional services, training, SaaS, and IaaS. |

- changed (2018-09-11):
[0001571996-18-000034:note_history:66]
Revenue from leasing arrangements is not subject to the revenue standard for contracts with customers, and remains separately accounted for under existing lease accounting guidance.  The Company records revenue from the sale of equipment under sales-type leases as product revenue in an amount equal to the present value of minimum lease payments at the inception of the lease.  Sales-type leases also produce financing income, which is included in products net revenue in the Consolidated Statements of Income (Loss) and is recognized at consistent rates of return over the lease term.  The Company also offers qualified customers fixed-term loans and revolving credit lines for the purchase of products and services offered by the Company.  Financing income attributable to these loans is recognized in products net revenue on an accrual basis.
  (was, 2018-06-12, similarity 0.943):
[0001571996-18-000022:note_history:66]
Revenue from leasing arrangements is not subject to the new revenue standard from contracts with customers, and remains separately accounted for under existing lease accounting guidance.  The Company records revenue from the sale of equipment under sales-type leases as product revenue in an amount equal to the present value of minimum lease payments at the inception of the lease.  Sales-type leases also produce financing income, which is included in net products revenue in the Consolidated Statements of Income (Loss) and is recognized at consistent rates of return over the lease term.  The Company also offers qualified customers fixed-term loans and revolving credit lines for the purchase of products and services offered by the Company.  Financing income attributable to these loans is recognized in product revenue on an accrual basis.

- changed (2018-09-11):
[0001571996-18-000034:note_history:67]
Disaggregation of Revenue — The Company's revenue is presented on a disaggregated basis on the Condensed Consolidated Statements of Income (Loss) and in Note 18 of the Notes to the Condensed Consolidated Financial Statements based on an evaluation of disclosures outside of the financial statements, information regularly reviewed by the chief operating decision maker for evaluating the financial performance of operating segments, and other information that is used to evaluate the Company's financial performance or make resource allocations.  This information includes revenue from products and services, revenue from reportable segments, and revenue by major product categories within the segments.
  (was, 2018-06-12, similarity 0.9914):
[0001571996-18-000022:note_history:67]
Disaggregation of Revenue — The Company's revenue is presented on a disaggregated basis on the Condensed Consolidated Statements of Income (Loss) and in Note 18 of the Notes to the Condensed Consolidated Financial Statements based on an evaluation of disclosures outside of the financial statements, information regularly reviewed by the chief operating decision maker for evaluating the financial performance of operating segments, and other information that is used to evaluate the Company's financial performance or make resource allocations.  This information includes revenue from product and services, revenue from reportable segments, and revenue by major product lines within the segments.

- changed (2018-09-11):
[0001571996-18-000034:note_history:68]
Costs to Obtain a Contract — The incremental direct costs of obtaining a contract primarily consist of sales commissions and employer taxes related to commission payments.  The Company has elected, as a practical expedient, to expense as incurred costs to obtain a contract equal to or less than one year in duration.  For contracts greater than one year in duration, the associated costs to obtain a contract are deferred and amortized over the period of contract performance or a longer period, generally the estimated life of the customer relationship, if renewals are expected and the renewal commission is not commensurate with the initial commission.  Deferred costs to obtain a contract are typically amortized over a period of three to seven years, depending on the contract term and expectation of the period of benefit for the costs, which may exceed the contract term.  Amortization expense is recognized on a straight-line basis and included in selling, general, and administrative expenses in the Condensed Consolidated Statements of Income (Loss).  The Company periodically reviews these deferred costs to determine whether events or changes in circumstances have occurred that could impact the carrying value or period of benefit of the deferred sales commissions.  There were no material impairment losses for deferred sales commissions during the six months ended August 3, 2018 and August 4, 2017.
  (was, 2018-06-12, similarity 0.9735):
[0001571996-18-000022:note_history:68]
Costs to Obtain a Contract — The incremental direct costs of obtaining a contract primarily consist of sales commissions and employer taxes related to commission payments.  The Company has elected, as a practical expedient, to expense as incurred costs to obtain a contract equal to or less than one year in duration.  For contracts greater than one year in duration, the associated costs to obtain a contract are deferred and amortized over the period of contract performance or a longer period, generally the estimated life of the customer relationship, if renewals are expected and the renewal commission is not commensurate with the initial commission.  Deferred costs to obtain a contract are typically amortized over a period of 3 to 7 years, depending on the contract term and expectation of the period of benefit for the costs, which may exceed the contract term.  Amortization expense is recognized on a straight-line basis and included in selling, general, and administrative expenses in the Condensed Consolidated Statements of Income (Loss).  The Company periodically reviews these deferred costs to determine whether events or changes in circumstances have occurred that could impact the carrying value or period of benefit of the deferred sales commissions.  There were no material impairment losses for deferred sales commissions during the three months ended May 4, 2018 and May 5, 2017.

- added (2018-09-11):
[0001571996-18-000034:note_history:69]
Deferred costs to obtain a contract as of August 3, 2018 and February 2, 2018 were $1.0 billion and $0.8 billion, respectively.  Deferred costs to obtain a contract are classified as current assets and other non-current assets on the Condensed Consolidated Statements of Financial Position, based on when the expense is expected to be recognized.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2018-09-11):
[0001571996-18-000034:note_history:70]
Deferred Revenue — Deferred revenue is recorded for support and deployment services, software maintenance, professional services, training, and SaaS when the Company has a right to invoice or payments have been received for undelivered products or services where transfer of control has not occurred.  Revenue is recognized on these items when the revenue recognition criteria are met, generally resulting in ratable recognition over the contract term.  The Company also has deferred revenue related to undelivered hardware and professional services, consisting of installations and consulting engagements, which are recognized as the Company's performance obligations under the contract are completed.
  (was, 2018-06-12, similarity 0.7184):
[0001571996-18-000022:note_history:70]
Deferred Revenue — Deferred revenue is recorded when the Company has a right to invoice or payments have been received for undelivered products or services in contracts where transfer of control has not occurred.  Deferred revenue represents amounts received in advance for support and deployment services, software maintenance, professional services, training, and SaaS.  Revenue is recognized on these items when the revenue recognition criteria are met, generally resulting in ratable recognition over the contract term.  The Company also has deferred revenue related to undelivered hardware and professional services, consisting of installations and consulting engagements, which are recognized as the Company's performance obligations under the contract are completed.

- added (2018-09-11):
[0001571996-18-000034:note_history:71]
|  | Three Months Ended |  | Six Months Ended |
|  | August 3, 2018 |  | August 3, 2018 |
|  | (in millions) |
| Deferred revenue: |  |  |  |
| Deferred revenue at beginning of period | $ | 20,959 |  |  | $ | 20,816 |  |
| Revenue deferrals for new contracts and changes in estimates for pre-existing contracts (a) | 6,123 |  |  | 11,460 |  |
| Revenue recognized | (5,382 | ) |  | (10,576 | ) |
| Deferred revenue at end of period | $ | 21,700 |  |  | $ | 21,700 |  |
| Short-term deferred revenue | $ | 11,965 |  |  | $ | 11,965 |  |
| Long-term deferred revenue | $ | 9,735 |  |  | $ | 9,735 |  |

- added (2018-09-11):
[0001571996-18-000034:note_history:72]
Remaining Performance Obligations — Remaining performance obligations represent the aggregate amount of the transaction price allocated to performance obligations not delivered, or partially undelivered, as of the end of the reporting period.

- added (2018-09-11):
[0001571996-18-000034:note_history:73]
Remaining performance obligations include deferred revenue plus unbilled amounts not yet recorded in deferred revenue.  The aggregate amount of the transaction price allocated to remaining performance obligations does not include amounts owed under cancelable contracts where there is no substantive termination penalty.

- added (2018-09-11):
[0001571996-18-000034:note_history:74]
The value of the transaction price allocated to remaining performance obligations as of August 3, 2018 was approximately $29 billion.  The Company expects to recognize approximately 62% of remaining performance obligations as revenue in the next 12 months, and the remainder thereafter.

- removed (2018-09-11):
[0001571996-18-000022:note_history:75]
|  | Three Months Ended |
|  | May 4, 2018 |
|  | (in millions) |
| Deferred revenue: |  |
| Deferred revenue at beginning of period | $ | 20,816 |  |
| Revenue deferrals for new contracts and changes in estimates for pre-existing contracts (a) | 5,337 |  |
| Revenue recognized | (5,194 | ) |
| Deferred revenue at end of period | $ | 20,959 |  |
| Short-term deferred revenue | $ | 11,495 |  |
| Long-term deferred revenue | $ | 9,464 |  |

- removed (2018-09-11):
[0001571996-18-000022:note_history:76]
Remaining Performance Obligations — Remaining performance obligations represent the aggregate amount of the transaction price in contracts allocated to performance obligations not delivered, or partially undelivered, as of the end of the reporting period.  Remaining performance obligations include deferred revenue plus unbilled amounts not yet recorded in deferred revenue.  The aggregate amount of transaction price allocated to remaining performance obligations does not include amounts owed under cancelable contracts where there is no substantive termination penalty.

- removed (2018-09-11):
[0001571996-18-000022:note_history:77]
The value of the transaction price allocated to remaining performance obligations as of May 4, 2018 was approximately $29 billion.  The Company expects to recognize approximately 65% of remaining performance obligations as revenue in the next 12 months, and the remainder thereafter.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2018-09-11):
[0001571996-18-000034:note_history:78]
During August 2018, VMware, Inc. announced that it signed a definitive agreement to acquire CloudHealth Technologies, Inc. ("CloudHealth Technologies").  Total consideration for the acquisition, subject to purchase price adjustments, will consist of approximately $500 million in cash and assumed unvested equity awards of the acquiree.  CloudHealth Technologies delivers a cloud operations platform that enables customers to help analyze and manage cloud cost, usage, security, and performance centrally for native public clouds.  The transaction is expected to close during the three months ended November 2, 2018 and is subject to regulatory approvals and customary closing conditions.

- added (2018-09-11):
[0001571996-18-000034:note_history:79]
On September 4, 2018, the Company repaid $600 million of the Term Loan A-3 Facility that matures in December 2018.

- removed (2018-09-11):
[0001571996-18-000022:note_history:80]
On May 24, 2018, the Company drew down $500 million under the China Revolving Credit Facility.

- removed (2018-09-11):
[0001571996-18-000022:note_history:81]
On June 1, 2018, the Company fully repaid the 1.875% EMC Note in the amount of $2.5 billion in accordance with the contractual maturity date.
