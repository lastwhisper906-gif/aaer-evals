# DELL notes — 0001571996-18-000034


## dvmt:ReconciliationofConsolidatedNetIncomeLossTableTextBlock

[0001571996-18-000034:notes:1]
[same as prior period, unchanged from 0001571996-18-000022:notes:1]

[0001571996-18-000034:notes:2]
|  | Three Months Ended |  | Six Months Ended |
|  | August 3, 2018 |  | August 4, 2017 |  | August 3, 2018 |  | August 4, 2017 |
|  | (in millions) |
| Net income attributable to Class V Common Stock | $ | 320 |  |  | $ | 204 |  |  | $ | 790 |  |  | $ | 329 |  |
| Net loss attributable to DHI Group | (819 | ) |  | (936 | ) |  | (1,925 | ) |  | (2,232 | ) |
| Net loss attributable to Dell Technologies Inc. | $ | (499 | ) |  | $ | (732 | ) |  | $ | (1,135 | ) |  | $ | (1,903 | ) |


## invest:InvestmentTableTextBlock

[0001571996-18-000034:notes:3]
[same as prior period, unchanged from 0001571996-18-000022:notes:30]

[0001571996-18-000034:notes:4]
|  | August 3, 2018 |  | February 2, 2018 |
|  | Cost |  | Unrealized Gain |  | Unrealized (Loss) |  | Carrying Value |  | Cost |  | Unrealized Gain |  | Unrealized (Loss) |  | Carrying Value |
|  | (in millions) |
| Investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government and agencies | $ | 501 |  |  | $ | — |  |  | $ | (2 | ) |  | $ | 499 |  |  | $ | 485 |  |  | $ | — |  |  | $ | (2 | ) |  | $ | 483 |  |
| U.S. corporate debt securities | 819 |  |  | — |  |  | (3 | ) |  | 816 |  |  | 660 |  |  | — |  |  | (2 | ) |  | 658 |  |
| Foreign debt securities | 1,192 |  |  | — |  |  | (3 | ) |  | 1,189 |  |  | 1,048 |  |  | — |  |  | (2 | ) |  | 1,046 |  |
| Total short-term investments | 2,512 |  |  | — |  |  | (8 | ) |  | 2,504 |  |  | 2,193 |  |  | — |  |  | (6 | ) |  | 2,187 |  |
| U.S. government and agencies | 450 |  |  | — |  |  | (8 | ) |  | 442 |  |  | 600 |  |  | — |  |  | (9 | ) |  | 591 |  |
| U.S. corporate debt securities | 1,067 |  |  | — |  |  | (20 | ) |  | 1,047 |  |  | 1,361 |  |  | — |  |  | (16 | ) |  | 1,345 |  |
| Foreign debt securities | 1,155 |  |  | — |  |  | (21 | ) |  | 1,134 |  |  | 1,518 |  |  | — |  |  | (17 | ) |  | 1,501 |  |
| Equity and other securities (a) | 717 |  |  | 309 |  |  | — |  |  | 1,026 |  |  | 640 |  |  | 86 |  |  | — |  |  | 726 |  |
| Total long-term investments | 3,389 |  |  | 309 |  |  | (49 | ) |  | 3,649 |  |  | 4,119 |  |  | 86 |  |  | (42 | ) |  | 4,163 |  |
| Total investments | $ | 5,901 |  |  | $ | 309 |  |  | $ | (57 | ) |  | $ | 6,153 |  |  | $ | 6,312 |  |  | $ | 86 |  |  | $ | (48 | ) |  | $ | 6,350 |  |

[0001571996-18-000034:notes:5]
[same as prior period, unchanged from 0001571996-18-000022:notes:32]

[0001571996-18-000034:notes:6]
| (a) | $582 million and $485 million of equity and other securities as of August 3, 2018 and February 2, 2018, respectively, are strategic investments without readily determinable fair values, which are recorded at cost, less impairment, and adjusted for observable price changes. The remainder are publicly-traded investments that are measured at fair value on a recurring basis. See Note 3 of the Notes to the Condensed Consolidated Financial Statements for additional information on investments measured at fair value. |


## invest:InvestmentTextBlock

[0001571996-18-000034:notes:7]
[same as prior period, unchanged from 0001571996-18-000022:notes:34]

[0001571996-18-000034:notes:8]
The Company's investments in debt securities are classified as available-for-sale securities, which are carried at fair value.  As of August 3, 2018, the aggregate fair value of investments held in a continuous unrealized loss position for greater than 12 months was $1.5 billion, and the unrealized loss on these investments was $25 million.  As of February 2, 2018, the aggregate fair value of investments held in a continuous unrealized loss position for greater than 12 months was $1.9 billion, and the unrealized loss on these investments was $25 million.

[0001571996-18-000034:notes:9]
The maturities of debt securities held as of August 3, 2018 are as follows:

[0001571996-18-000034:notes:10]
|  | Carrying Value |  | Amortized Cost |
|  | (in millions) |
| Due within one year | $ | 2,504 |  |  | $ | 2,512 |  |
| Due after 1 year through 5 years | 2,576 |  |  | 2,624 |  |
| Due after 5 years through 10 years | 46 |  |  | 48 |  |
| Total | $ | 5,126 |  |  | $ | 5,184 |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001571996-18-000034:notes:11]
[same as prior period, unchanged from 0001571996-18-000022:notes:38]

[0001571996-18-000034:notes:12]
The following table provides additional information on selected accounts included in the Consolidated Statements of Financial Position as of August 3, 2018 and February 2, 2018:

[0001571996-18-000034:notes:13]
|  | August 3, 2018 |  | February 2, 2018 |
|  | (in millions) |
| Inventories, net: |  |  |  |
| Production materials | $ | 1,502 |  |  | $ | 967 |  |
| Work-in-process | 782 |  |  | 514 |  |
| Finished goods | 1,358 |  |  | 1,197 |  |
| Total inventories, net | $ | 3,642 |  |  | $ | 2,678 |  |
| Other non-current liabilities: |  |  |  |
| Warranty liability | $ | 176 |  |  | $ | 172 |  |
| Deferred and other tax liabilities | 6,046 |  |  | 6,590 |  |
| Other | 565 |  |  | 515 |  |
| Total other non-current liabilities | $ | 6,787 |  |  | $ | 7,277 |  |

[0001571996-18-000034:notes:14]
[same as prior period, unchanged from 0001571996-18-000022:notes:41]

[0001571996-18-000034:notes:15]
The following table presents cash, cash equivalents, and restricted cash as reported on the Condensed Consolidated Statements of Financial Position as of August 3, 2018 and February 2, 2018:

[0001571996-18-000034:notes:16]
|  | August 3, 2018 |  | February 2, 2018 |
|  | (in millions) |
| Cash and cash equivalents | $ | 15,312 |  |  | $ | 13,942 |  |
| Restricted cash - current assets | 473 |  |  | 423 |  |
| Restricted cash - other non-current assets | 20 |  |  | 13 |  |
| Total cash, cash equivalents, and restricted cash | $ | 15,805 |  |  | $ | 14,378 |  |

[0001571996-18-000034:notes:17]
[same as prior period, unchanged from 0001571996-18-000022:notes:44]


## us-gaap:AllowanceForCreditLossesOnFinancingReceivablesTableTextBlock

[0001571996-18-000034:notes:18]
The following tables present the allowance for financing receivable losses for the three months ended August 3, 2018 and August 4, 2017, and the six months ended August 3, 2018 and August 4, 2017, and changes in allowance for financing receivable losses for the respective periods:

[0001571996-18-000034:notes:19]
|  | Three Months Ended |
|  | August 3, 2018 |  | August 4, 2017 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |
| Balances at beginning of period | $ | 77 |  |  | $ | 62 |  |  | $ | 139 |  |  | $ | 85 |  |  | $ | 51 |  |  | $ | 136 |  |
| Charge-offs, net of recoveries | (19 | ) |  | (12 | ) |  | (31 | ) |  | (20 | ) |  | (5 | ) |  | (25 | ) |
| Provision charged to income statement | 17 |  |  | 1 |  |  | 18 |  |  | 16 |  |  | 8 |  |  | 24 |  |
| Balances at end of period | $ | 75 |  |  | $ | 51 |  |  | $ | 126 |  |  | $ | 81 |  |  | $ | 54 |  |  | $ | 135 |  |

[0001571996-18-000034:notes:20]
|  | Six Months Ended |
|  | August 3, 2018 |  | August 4, 2017 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |  |  |  |  |  |  |  |  |  |  |  |
| Balances at beginning of period | $ | 81 |  |  | $ | 64 |  |  | $ | 145 |  |  | $ | 91 |  |  | $ | 52 |  |  | $ | 143 |  |
| Charge-offs, net of recoveries | (39 | ) |  | (17 | ) |  | (56 | ) |  | (42 | ) |  | (8 | ) |  | (50 | ) |
| Provision charged to income statement | 33 |  |  | 4 |  |  | 37 |  |  | 32 |  |  | 10 |  |  | 42 |  |
| Balances at end of period | $ | 75 |  |  | $ | 51 |  |  | $ | 126 |  |  | $ | 81 |  |  | $ | 54 |  |  | $ | 135 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001571996-18-000034:notes:21]
Basis of Presentation — The accompanying unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company's Annual Report on Form 10-K for the fiscal year ended February 2, 2018, and the recast audited Consolidated Financial Statements and accompanying Notes for the fiscal years ended February 2, 2018  and February 3, 2017 (the "Recast Financial Statements")

[0001571996-18-000034:notes:22]
and other financial information included in the Company's Current Report on Form 8-K filed with the Securities and Exchange Commission (the "SEC") on August 6, 2018.  The Recast Financial Statements were recast from and supersede the audited Consolidated Financial Statements for the fiscal years ended February 2, 2018  and February 3, 2017 included in the Company's Annual Report on Form 10-K for the fiscal year ended February 2, 2018.  Such audited Consolidated Financial Statements were recast to present certain previously reported financial statements and other related financial information on a basis consistent with the new accounting standards adopted during the three months ended May 4, 2018.  Further, segment information was recast to conform with certain segment reporting changes the Company made during the three months ended May 4, 2018.  See below for additional information regarding recently adopted accounting pronouncements.

[0001571996-18-000034:notes:23]
These Condensed Consolidated Financial Statements have been prepared in accordance with accounting principles generally accepted in the United States of America ("GAAP").  In the opinion of management, the accompanying Condensed  Consolidated Financial Statements reflect all adjustments of a normal recurring nature considered necessary to fairly state the financial position of Dell Technologies Inc. as of August 3, 2018, the results of its operations and corresponding comprehensive income (loss) for the three and six months ended August 3, 2018 and August 4, 2017, and its cash flows for the six months ended August 3, 2018 and August 4, 2017.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock

[0001571996-18-000034:notes:24]
[same as prior period, unchanged from 0001571996-18-000022:notes:48]

[0001571996-18-000034:notes:25]
References in these Notes to the Condensed Consolidated Financial Statements to the "Company" or "Dell Technologies" mean Dell Technologies Inc. individually and together with its consolidated subsidiaries.

[0001571996-18-000034:notes:26]
These Condensed Consolidated Financial Statements have been prepared in accordance with accounting principles generally accepted in the United States of America ("GAAP").  In the opinion of management, the accompanying Condensed  Consolidated Financial Statements reflect all adjustments of a normal recurring nature considered necessary to fairly state the financial position of Dell Technologies Inc. as of August 3, 2018, the results of its operations and corresponding comprehensive income (loss) for the three and six months ended August 3, 2018 and August 4, 2017, and its cash flows for the six months ended August 3, 2018 and August 4, 2017.  The February 2, 2018 condensed consolidated balance sheet included herein was derived from the Recast Financial Statements.

[0001571996-18-000034:notes:27]
The preparation of financial statements in accordance with GAAP requires management to make estimates and assumptions that affect the amounts reported in the Condensed Consolidated Financial Statements and the accompanying Notes.  Actual results could differ materially from those estimates.  The results of operations and comprehensive income (loss) for the three and six months ended August 3, 2018 and August 4, 2017 and the cash flows for the six months ended August 3, 2018 and August 4, 2017 are not necessarily indicative of the results to be expected for the full fiscal year or for any other fiscal period.

[0001571996-18-000034:notes:28]
[same as prior period, unchanged from 0001571996-18-000022:notes:50]

[0001571996-18-000034:notes:29]
Principles of Consolidation — These Condensed Consolidated Financial Statements include the accounts of Dell Technologies and its wholly-owned subsidiaries, as well as the accounts of SecureWorks Corp. ("SecureWorks"), VMware, Inc., and Pivotal Software, Inc. ("Pivotal"), each of which is majority-owned by Dell Technologies.  All intercompany transactions have been eliminated.

[0001571996-18-000034:notes:30]
Unless the context indicates otherwise, references in these Notes to the Condensed Consolidated Financial Statements to "VMware" mean the VMware reportable segment, which reflects the operations of VMware, Inc. (NYSE: VMW) within Dell Technologies.  See Exhibit 99.1 filed with the quarterly report on Form 10-Q for the quarterly period ended August 3, 2018 for information on the differences between VMware reportable segment results and VMware, Inc. results.

[0001571996-18-000034:notes:31]
[same as prior period, unchanged from 0001571996-18-000022:notes:53]

[0001571996-18-000034:notes:32]
[same as prior period, unchanged from 0001571996-18-000022:notes:54]

[0001571996-18-000034:notes:33]
Recently Issued Accounting Pronouncements

[0001571996-18-000034:notes:34]
Leases — In February 2016, the Financial Accounting Standards Board ("FASB") issued amended guidance on the accounting for leasing transactions.  The primary objective of this update is to increase transparency and comparability among organizations by requiring lessees to recognize a lease liability for the obligation to make lease payments and a right-of-use asset for the right to use the underlying asset for the lease term.  The guidance also makes some changes to lessor accounting and requires additional disclosures about all leasing arrangements.  Companies are required to use a modified retrospective approach, with the option of applying the requirements of the standard either (1) retrospectively to each prior comparative reporting period presented, or (2) retrospectively at the beginning of the period of adoption.  The Company will adopt this standard for the fiscal year beginning February 2, 2019, and will apply it at the beginning of the period of adoption through a cumulative-effect adjustment to retained earnings.  In the area of lessee accounting, the Company anticipates that the most significant change will be recognition of right-of-use assets and lease liabilities on the Consolidated Statements of Financial Position.  In the area of lessor accounting, the Company anticipates that the most significant change will be an increase to future originations of operating leases due to elimination of the third-party residual value guarantee insurance in the sales-type lease test.

[0001571996-18-000034:notes:35]
[same as prior period, unchanged from 0001571996-18-000022:notes:57]

[0001571996-18-000034:notes:36]
Simplifying the Test for Goodwill Impairment — In January 2017, the FASB issued amended guidance to simplify the subsequent measurement of goodwill by removing Step 2 of the goodwill impairment test.  Instead, under the amendments in the new guidance, an entity should perform its annual, or interim, goodwill impairment test by comparing the fair value of a reporting unit with its carrying amount.  An entity should recognize an impairment charge for the amount by which the carrying amount exceeds the reporting unit's fair value.  Public entities must adopt the new guidance in fiscal years beginning after December 15, 2019, with early adoption permitted.  The Company is currently evaluating the impact of the new guidance but does not expect that the standard will have an impact on its Consolidated Financial Statements.

[0001571996-18-000034:notes:37]
Recently Adopted Accounting Pronouncements

[0001571996-18-000034:notes:38]
Revenue from Contracts with Customers — In May 2014, the FASB issued amended guidance on the recognition of revenue from contracts with customers.  The objective of the new standard is to establish a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and will supersede substantially all of the existing revenue recognition guidance, including industry-specific guidance.  The new standard requires entities to recognize revenue when it transfers promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services.  Further, the new standard requires additional disclosures to help enable users of the financial statements to better understand the nature, amount, timing, risks, and judgments related to revenue recognition and related cash flows from contracts with customers.  Concurrently, the FASB issued guidance on the accounting for costs to fulfill or obtain a customer contract.  The Company adopted these standards during the three months ended May 4, 2018 using the full retrospective method, which requires the Company to recast each prior period presented consistent with the new guidance.  The Company recorded a credit of approximately $1 billion to retained earnings as of January 29, 2016 to reflect the cumulative effect of the adoption.  See tables provided below which present the impact of the new accounting standards to the Company's previously reported financial results.  See also Note 2 of the Notes to the Condensed Consolidated Financial Statements for a summary of significant policies related to the new accounting standards.

[0001571996-18-000034:notes:39]
Recognition and Measurement of Financial Assets and Financial Liabilities — In January 2016, the FASB issued amended guidance that generally requires changes in the fair value of equity investments, other than those accounted for under the equity method, to be recognized through net income, rather than other comprehensive income.  For equity investments without readily determinable fair values, the Company is no longer permitted to use the cost method of accounting.  The Company has elected to apply the measurement alternative for those investments.  Under the alternative, the Company measures investments without readily determinable fair values at cost, less impairment, adjusted by observable price changes on a prospective basis.  The Company must make a separate election to use the alternative for each eligible investment, and is required to reassess at each reporting period whether an investment qualifies for the alternative.  The Company adopted this standard during the three months ended May 4, 2018.  Adoption of the standard was applied through a cumulative one-time adjustment to accumulated deficit of $56 million for the accumulated unrealized gain previously recorded in other comprehensive income.  The impact of the standard on the Condensed Consolidated Statements of Income (Loss) during the three and six months ended August 3, 2018 was a gain of approximately $123 million and $223 million, respectively, recognized in interest and other, net, and the impact in future periods will depend on the relative changes in market price of the equity investments.

[0001571996-18-000034:notes:40]
Classification of Certain Cash Receipts and Cash Payments — In August 2016, the FASB issued amended guidance on the presentation and classification of eight specific cash flow issues with the objective of reducing existing diversity in practice.  Companies should reflect any adjustments on a retrospective basis, if practicable; otherwise, adoption is required to be applied as of the earliest date practicable.  The Company adopted this standard during the three months ended May 4, 2018.  Prior period amounts on the Condensed Consolidated Statements of Cash Flows have been recast to conform with current period presentation as shown in the reconciliation provided below.

[0001571996-18-000034:notes:41]
[same as prior period, unchanged from 0001571996-18-000022:notes:63]

[0001571996-18-000034:notes:42]
Statement of Cash Flows, Restricted Cash — In November 2016, the FASB issued amended guidance requiring entities to include restricted cash and restricted cash equivalents in cash balances on the cash flow statement, and also to provide a supplemental reconciliation of cash, cash equivalents and restricted cash.  Public entities must adopt the new guidance for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017, with early adoption permitted.  The Company adopted this standard during the three months ended May 4, 2018.  See Note 19 of the Notes to the Condensed Consolidated Financial Statements for supplemental cash flow information.  Prior period amounts on the Condensed Consolidated Statements of Cash Flows have been recast to conform with current period presentation as shown in the reconciliation provided below.

[0001571996-18-000034:notes:43]
[same as prior period, unchanged from 0001571996-18-000022:notes:65]

[0001571996-18-000034:notes:44]
Derivatives and Hedging — In August 2017, the FASB issued amended guidance that will make more financial and non-financial hedging strategies eligible for hedge accounting.  The amended guidance changes how companies assess effectiveness, and also amends the presentation and disclosure requirements.  The guidance is intended to simplify the application of hedge accounting and increase transparency as to the scope and results of hedging programs.  Immediate early adoption is permitted in any interim or annual period.  The Company elected to early adopt this standard during the three months ended May 4, 2018.  The impact of the adoption of the standard was immaterial to the Condensed Consolidated Financial Statements.

[0001571996-18-000034:notes:45]
Income Statement - Reporting Comprehensive Income — In February 2018, the FASB issued guidance that will permit entities to reclassify the tax effects stranded in accumulated other comprehensive income to accumulated deficit as a result of U.S. Tax Reform, discussed in Note 12 of the Notes to the Condensed Consolidated Financial Statements.  The guidance gives entities the option to reclassify these amounts, but requires new disclosures regardless of whether they elect to do so.  The guidance is effective for fiscal years beginning after December 15, 2018, and interim periods within those fiscal years.  Early adoption is permitted.  The Company elected to early adopt this standard during the three months ended May 4, 2018, and recorded the impact of the adoption as a cumulative adjustment to accumulated deficit.  The impact of the adoption was immaterial to the Condensed Consolidated Financial Statements.

[0001571996-18-000034:notes:46]
[same as prior period, unchanged from 0001571996-18-000022:notes:68]

[0001571996-18-000034:notes:47]
[same as prior period, unchanged from 0001571996-18-000022:notes:69]

[0001571996-18-000034:notes:48]
[same as prior period, unchanged from 0001571996-18-000022:notes:70]

[0001571996-18-000034:notes:49]
|  | February 2, 2018 |
|  | As Reported (a) |  | Revenue from Contracts with Customers |  | As Recast |
|  | (in millions) |
| Assets |  |  |  |  |  |
| Accounts receivable, net | $ | 11,177 |  |  | $ | 544 |  |  | $ | 11,721 |  |
| Other current assets | $ | 5,054 |  |  | $ | 827 |  |  | $ | 5,881 |  |
| Other non-current assets | $ | 1,862 |  |  | $ | 541 |  |  | $ | 2,403 |  |
| Liabilities and Stockholders' Equity |  |  |  |  |  |
| Accrued and other | $ | 7,661 |  |  | $ | 365 |  |  | $ | 8,026 |  |
| Short-term deferred revenue | $ | 12,024 |  |  | $ | (418 | ) |  | $ | 11,606 |  |
| Long-term deferred revenue | $ | 10,223 |  |  | $ | (1,013 | ) |  | $ | 9,210 |  |
| Other non-current liabilities | $ | 6,797 |  |  | $ | 480 |  |  | $ | 7,277 |  |
| Accumulated deficit | $ | (9,253 | ) |  | $ | 2,393 |  |  | $ | (6,860 | ) |
| Non-controlling interests | $ | 5,661 |  |  | $ | 105 |  |  | $ | 5,766 |  |

[0001571996-18-000034:notes:50]
| (a) | Amounts as reported in the Company's Annual Report on Form 10-K for the fiscal year ended February 2, 2018. |

[0001571996-18-000034:notes:51]
[same as prior period, unchanged from 0001571996-18-000022:notes:72]

[0001571996-18-000034:notes:52]
[same as prior period, unchanged from 0001571996-18-000022:notes:73]

[0001571996-18-000034:notes:53]
| • | First, the return rights provision, which represents an estimate of expected customer returns, which was previously presented as a reduction of accounts receivable, net, is now being presented outside of accounts receivable, net in two separate balance sheet line items. A liability is recorded in accrued and other for the estimated value of the sales amounts to be returned to the customer, and an asset is recorded in other current assets representing the recoverable cost of the inventory estimated to be returned. |

[0001571996-18-000034:notes:54]
[same as prior period, unchanged from 0001571996-18-000022:notes:75]

[0001571996-18-000034:notes:55]
[same as prior period, unchanged from 0001571996-18-000022:notes:76]

[0001571996-18-000034:notes:56]
Deferred revenue.  The adoption of the new revenue standard resulted in a decline in deferred revenue due to earlier recognition of revenue for software licenses, and less of the aggregate transaction price being allocated to extended warranty.  Deferred revenue was also reduced by the impact of variable consideration (i.e., price concessions, rebates, and refunds).  The reduction in deferred revenue was partially offset by an increase resulting from the change in presentation of deferred costs on third-party software offerings, which are reported in other assets, and are either sold on a standalone basis or as an attached component of the Company's hardware offering.  The Company previously reported the associated deferred revenue net of these deferred costs in deferred revenue.

[0001571996-18-000034:notes:57]
[same as prior period, unchanged from 0001571996-18-000022:notes:78]

[0001571996-18-000034:notes:58]
|  | Three Months Ended |  | Six Months Ended |
|  | August 4, 2017 |  | August 4, 2017 |
|  | As Reported (a) |  | Revenue from Contracts with Customers |  | As Recast |  | As Reported (a) |  | Revenue from Contracts with Customers |  | As Recast |
|  | (in millions, except per share amounts) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Products | $ | 14,355 |  |  | $ | 747 |  |  | $ | 15,102 |  |  | $ | 27,323 |  |  | $ | 1,413 |  |  | $ | 28,736 |  |
| Services | 4,944 |  |  | (525 | ) |  | 4,419 |  |  | 9,792 |  |  | (1,007 | ) |  | 8,785 |  |
| Total net revenue | 19,299 |  |  | 222 |  |  | 19,521 |  |  | 37,115 |  |  | 406 |  |  | 37,521 |  |
| Cost of net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Products | 12,378 |  |  | 397 |  |  | 12,775 |  |  | 23,837 |  |  | 761 |  |  | 24,598 |  |
| Services | 2,112 |  |  | (334 | ) |  | 1,778 |  |  | 4,167 |  |  | (669 | ) |  | 3,498 |  |
| Total cost of net revenue | 14,490 |  |  | 63 |  |  | 14,553 |  |  | 28,004 |  |  | 92 |  |  | 28,096 |  |
| Gross margin | 4,809 |  |  | 159 |  |  | 4,968 |  |  | 9,111 |  |  | 314 |  |  | 9,425 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative | 4,695 |  |  | (155 | ) |  | 4,540 |  |  | 9,364 |  |  | (228 | ) |  | 9,136 |  |
| Research and development | 1,093 |  |  | — |  |  | 1,093 |  |  | 2,226 |  |  | — |  |  | 2,226 |  |
| Total operating expenses | 5,788 |  |  | (155 | ) |  | 5,633 |  |  | 11,590 |  |  | (228 | ) |  | 11,362 |  |
| Operating loss | (979 | ) |  | 314 |  |  | (665 | ) |  | (2,479 | ) |  | 542 |  |  | (1,937 | ) |
| Interest and other, net | (545 | ) |  | — |  |  | (545 | ) |  | (1,118 | ) |  | 1 |  |  | (1,117 | ) |
| Income (loss) before income taxes | (1,524 | ) |  | 314 |  |  | (1,210 | ) |  | (3,597 | ) |  | 543 |  |  | (3,054 | ) |
| Income tax provision (benefit) | (546 | ) |  | 75 |  |  | (471 | ) |  | (1,236 | ) |  | 124 |  |  | (1,112 | ) |
| Net income (loss) | (978 | ) |  | 239 |  |  | (739 | ) |  | (2,361 | ) |  | 419 |  |  | (1,942 | ) |
| Less: Net income (loss) attributable to non-controlling interests | (32 | ) |  | 25 |  |  | (7 | ) |  | (81 | ) |  | 42 |  |  | (39 | ) |
| Net income (loss) attributable to Dell Technologies Inc. | $ | (946 | ) |  | $ | 214 |  |  | $ | (732 | ) |  | $ | (2,280 | ) |  | $ | 377 |  |  | $ | (1,903 | ) |
| Earnings (loss) per share attributable to Dell Technologies Inc. - basic: |  |  |  |  |  |  |
| Class V Common Stock - basic | $ | 0.83 |  |  | $ | 0.17 |  |  | $ | 1.00 |  |  | $ | 1.40 |  |  | $ | 0.20 |  |  | $ | 1.60 |  |
| DHI Group - basic | $ | (1.97 | ) |  | $ | 0.32 |  |  | $ | (1.65 | ) |  | $ | (4.53 | ) |  | $ | 0.59 |  |  | $ | (3.94 | ) |
| Earnings (loss) per share attributable to Dell Technologies Inc. - diluted: |  |  |  |  |  |  |
| Class V Common Stock - diluted | $ | 0.82 |  |  | $ | 0.18 |  |  | $ | 1.00 |  |  | $ | 1.38 |  |  | $ | 0.21 |  |  | $ | 1.59 |  |
| DHI Group - diluted | $ | (1.97 | ) |  | $ | 0.31 |  |  | $ | (1.66 | ) |  | $ | (4.54 | ) |  | $ | 0.59 |  |  | $ | (3.95 | ) |

[0001571996-18-000034:notes:59]
| (a) | Amounts as reported in the Company's Quarterly Report on Form 10-Q for the quarterly period ended August 4, 2017. |

[0001571996-18-000034:notes:60]
[same as prior period, unchanged from 0001571996-18-000022:notes:80]

[0001571996-18-000034:notes:61]
[same as prior period, unchanged from 0001571996-18-000022:notes:81]

[0001571996-18-000034:notes:62]
| • | Under the new revenue standard, amounts within a contract are now allocated to the product and services performance obligations based on their respective standalone selling prices, which generally increases product revenue and decreases services revenue relative to previously reported results. |

[0001571996-18-000034:notes:63]
[same as prior period, unchanged from 0001571996-18-000022:notes:83]

[0001571996-18-000034:notes:64]
Operating expenses.   The adoption of the new revenue standard resulted in a decrease to operating expenses due to the deferral of the incremental direct costs of obtaining a contract.

[0001571996-18-000034:notes:65]
[same as prior period, unchanged from 0001571996-18-000022:notes:85]

[0001571996-18-000034:notes:66]
|  | Six Months Ended |
|  | August 4, 2017 |
|  | As Reported (a) |  | Classification of Certain Cash Receipts and Cash Payments |  | Statement of Cash Flows, Restricted Cash |  | As Recast |
|  | (in millions) |
| Change in cash from operating activities | $ | 2,056 |  |  | $ | 32 |  |  | $ | 17 |  |  | $ | 2,105 |  |
| Change in cash from investing activities | $ | (1,290 | ) |  | $ | — |  |  | $ | — |  |  | $ | (1,290 | ) |
| Change in cash from financing activities | $ | (1,075 | ) |  | $ | (32 | ) |  | $ | 30 |  |  | $ | (1,077 | ) |
| Change in cash, cash equivalents, and restricted cash | $ | (261 | ) |  | $ | — |  |  | $ | 47 |  |  | $ | (214 | ) |
| Cash, cash equivalents, and restricted cash at beginning of the period | 9,474 |  |  | — |  |  | 358 |  |  | 9,832 |  |
| Cash, cash equivalents, and restricted cash at end of the period | $ | 9,213 |  |  | $ | — |  |  | $ | 405 |  |  | $ | 9,618 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001571996-18-000034:notes:67]
COMMITMENTS AND CONTINGENCIES

[0001571996-18-000034:notes:68]
Legal Matters

[0001571996-18-000034:notes:69]
The Company is involved in various claims, suits, assessments, investigations, and legal proceedings that arise from time to time in the ordinary course of its business, including those identified below, consisting of matters involving consumer, antitrust, tax, intellectual property, and other issues on a global basis.  The Company accrues a liability when it believes that it is both probable that a liability has been incurred and that it can reasonably estimate the amount of the loss.  The Company reviews these accruals at least quarterly and adjusts them to reflect ongoing negotiations, settlements, rulings, advice of legal counsel, and other relevant information.  To the extent new information is obtained and the Company's views on the probable outcomes of claims, suits, assessments, investigations, or legal proceedings change, changes in the Company's accrued liabilities would be recorded in the period in which such a determination is made.  For some matters, the amount of liability is not probable or the amount cannot be reasonably estimated and therefore accruals have not been made.  The following is a discussion of the Company's significant legal matters and other proceedings:

[0001571996-18-000034:notes:70]
Appraisal Proceedings — On October 29, 2013, Dell Technologies acquired Dell in a transaction referred to as the going-private transaction.  Holders of shares of Dell common stock who did not vote on September 12, 2013 in favor of the proposal to adopt the amended going-private transaction agreement and who properly demanded appraisal of their shares and who otherwise comply with the requirements of Section 262 of the Delaware General Corporate Law ("DGCL") are entitled to seek appraisal for, and obtain payment in cash for the judicially determined "fair value" (as defined pursuant to Section 262 of the DGCL) of, their shares in lieu of receiving the going-private transaction consideration.  Dell initially recorded a liability of $13.75 for each share with respect to which appraisal has been demanded and as to which the demand has not been withdrawn, together with interest at the statutory rate discussed below.  The Court of Chancery ruled that the fair value of the appraisal shares as of October 29, 2013, the date on which the going-private transaction became effective, was $17.62 per share.  This ruling would entitle the holders of the remaining 5,505,630 shares subject to the appraisal proceedings to $17.62 per share, plus interest at a statutory rate, compounded quarterly.  On November 21, 2016, the Court of Chancery entered final judgment in the appraisal action.  On November 22, 2016, Dell filed a notice of appeal to the Delaware Supreme Court, which issued a decision on December 14, 2017.  In its decision, the Delaware Supreme Court reversed, in part, and affirmed, in part, the decision of the Delaware Court of Chancery.  On January 2, 2018, the Delaware Supreme Court issued its formal mandate remanding the matter to the Court of Chancery for further proceedings consistent with its opinion.  In accordance with direction by the Court of Chancery, the parties submitted proposals to the Court of Chancery outlining the remaining issues to be adjudicated.  The liability for the appraisal proceedings was approximately $129 million as of February 2, 2018.  On May 8, 2018, the Company entered into an agreement to settle a portion of the liability related to the appraisal proceedings in the amount of approximately $70 million, and on May 18, 2018, this portion of the liability was fully paid.  The Company settled with the remaining plaintiffs as of July 16, 2018 in the amount of approximately $30 million.  The remaining liability accrual was released to Interest and other, net during the three months ended August 3, 2018.  As of August 3, 2018, there was no remaining liability for appraisal proceedings.

[0001571996-18-000034:notes:71]
Securities Litigation — On May 22, 2014, a securities class action seeking compensatory damages was filed in the United States District Court for the Southern District of New York, captioned the City of Pontiac Employee Retirement System vs. Dell Inc. et. al. (Case No. 1:14-cv-03644).  The action names as defendants Dell Inc. and certain current and former executive officers, and alleges that Dell made false and misleading statements about Dell's business operations and products between February 22, 2012 and May 22, 2012, which resulted in artificially inflated stock prices.  The case was transferred to the United States District Court for the Western District of Texas, where the defendants filed a motion to dismiss.  On September 16, 2016, the Court denied the motion to dismiss and the case is proceeding with discovery.  The defendants believe the claims asserted are without merit and the risk of material loss is remote.

[0001571996-18-000034:notes:72]
Copyright Levies — The Company's obligation to collect and remit copyright levies in certain European Union ("EU") countries may be affected by the resolution of legal proceedings pending in Germany and other EU member states against various companies, including Dell subsidiaries.  The plaintiffs in those proceedings generally seek to impose or modify the levies with respect to sales of such equipment as multifunction devices, phones, personal computers, storage devices, and printers, alleging that such products enable the copying of copyrighted materials.  Some of the proceedings also challenge whether the levy schemes in those countries comply with EU law.  Certain EU member countries that do not yet impose levies on digital devices are expected to implement legislation to enable them to extend existing levy schemes, while some other EU member countries are expected to limit the scope of levy schemes and their applicability in the digital hardware environment.  Dell, other companies, and various industry associations have opposed the extension of levies to the digital environment and have advocated alternative models of compensation to rights holders.  The Company continues to collect levies in certain EU countries where it has determined that based on local laws it is probable that it has a payment obligation.  The amount of levies is generally based on the number of products sold and the per-product amounts of the levies, which vary.  The Company accrues a liability when it believes that it is both probable that a loss has been incurred and when it can reasonably estimate the amount of the loss.

[0001571996-18-000034:notes:73]
CamSoft Litigation — CamSoft Data Systems, Inc. ("CamSoft") filed in 2009 a lawsuit, captioned CamSoft Data Systems, Inc. v. Southern Electronics Supply, Inc., et al., in the 19th Judicial District Court, Parish of East Baton Rouge, Louisiana, alleging that Dell conspired with others to misappropriate CamSoft’s trade secrets relating to municipal wireless video surveillance systems and engaged in unfair trade practices.  CamSoft asserted Louisiana state law claims for misappropriation of trade secrets, unfair trade practices, antitrust and other torts.  CamSoft seeks compensatory and punitive damages in excess of $2 billion.  The Company believes the claims are without merit and has motions to dismiss pending before the court.  The case is scheduled for trial in October 2018.

[0001571996-18-000034:notes:74]
Other Litigation — The various legal proceedings in which Dell is involved include commercial litigation and a variety of patent suits.  In some of these cases, Dell is the sole defendant.  More often, particularly in the patent suits, Dell is one of a number of defendants in the electronics and technology industries.  Dell is actively defending a number of patent infringement suits, and several pending claims are in various stages of evaluation.  While the number of patent cases varies over time, Dell does not currently anticipate that any of these matters will have a material adverse effect on its business, financial condition, results of operations, or cash flows.

[0001571996-18-000034:notes:75]
As of August 3, 2018, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for these or other proceedings or matters has been incurred.  However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company's business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters.  Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company's business, financial condition, results of operations, or cash flows will depend on a number of variables, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.

[0001571996-18-000034:notes:76]
Indemnifications

[0001571996-18-000034:notes:77]
In the ordinary course of business, the Company enters into contractual arrangements under which it may agree to indemnify the third party to such arrangements from any losses incurred relating to the services it performs on behalf of the Company or for losses arising from certain events as defined in the particular contract, such as litigation or claims relating to past performance.  Such indemnification obligations may not be subject to maximum loss clauses.  Historically, payments related to these indemnifications have not been material to the Company.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001571996-18-000034:notes:78]
[same as prior period, unchanged from 0001571996-18-000022:notes:97]

[0001571996-18-000034:notes:79]
[same as prior period, unchanged from 0001571996-18-000022:notes:98]

[0001571996-18-000034:notes:80]
[same as prior period, unchanged from 0001571996-18-000022:notes:99]

[0001571996-18-000034:notes:81]
|  | Foreign Currency Translation Adjustments |  | Investments |  | Cash Flow Hedges |  | Pension and Other Postretirement Plans |  | Accumulated Other Comprehensive Income (Loss) |
|  | (in millions) |
| Balances as of February 2, 2018 | $ | 179 |  |  | $ | 22 |  |  | $ | (103 | ) |  | $ | 32 |  |  | $ | 130 |  |
| Adjustment for adoption of accounting standards (Note 1) | — |  |  | (61 | ) |  | — |  |  | 3 |  |  | (58 | ) |
| Other comprehensive income (loss) before reclassifications | (603 | ) |  | (1 | ) |  | 241 |  |  | — |  |  | (363 | ) |
| Amounts reclassified from accumulated other comprehensive income (loss) | — |  |  | (1 | ) |  | (46 | ) |  | — |  |  | (47 | ) |
| Total change for the period | (603 | ) |  | (63 | ) |  | 195 |  |  | 3 |  |  | (468 | ) |
| Less: Change in comprehensive loss attributable to non-controlling interests | — |  |  | (2 | ) |  | (2 | ) |  | — |  |  | (4 | ) |
| Balances as of August 3, 2018 | $ | (424 | ) |  | $ | (39 | ) |  | $ | 94 |  |  | $ | 35 |  |  | $ | (334 | ) |

[0001571996-18-000034:notes:82]
[same as prior period, unchanged from 0001571996-18-000022:notes:101]

[0001571996-18-000034:notes:83]
The following tables present reclassifications out of accumulated other comprehensive income (loss), net of tax, to net income (loss) for the periods presented:

[0001571996-18-000034:notes:84]
|  | Three Months Ended |
|  | August 3, 2018 |  | August 4, 2017 |
|  | Investments |  | Cash Flow Hedges |  | Total |  | Investments |  | Cash Flow Hedges |  | Total |
|  | (in millions) |
| Total reclassifications, net of tax: |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue | $ | — |  |  | $ | 77 |  |  | $ | 77 |  |  | $ | — |  |  | $ | (49 | ) |  | $ | (49 | ) |
| Cost of net revenue | — |  |  | — |  |  | — |  |  | — |  |  | (21 | ) |  | (21 | ) |
| Interest and other, net | — |  |  | — |  |  | — |  |  | (2 | ) |  | — |  |  | (2 | ) |
| Total reclassifications, net of tax | $ | — |  |  | $ | 77 |  |  | $ | 77 |  |  | $ | (2 | ) |  | $ | (70 | ) |  | $ | (72 | ) |
|  | Six Months Ended |
|  | August 3, 2018 |  | August 4, 2017 |
|  | Investments |  | Cash Flow Hedges |  | Total |  | Investments |  | Cash Flow Hedges |  | Total |
|  | (in millions) |
| Total reclassifications, net of tax: |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue | $ | — |  |  | $ | 46 |  |  | $ | 46 |  |  | $ | — |  |  | $ | (32 | ) |  | $ | (32 | ) |
| Cost of net revenue | — |  |  | — |  |  | — |  |  | — |  |  | (17 | ) |  | (17 | ) |
| Interest and other, net | 1 |  |  | — |  |  | 1 |  |  | (3 | ) |  | — |  |  | (3 | ) |
| Total reclassifications, net of tax | $ | 1 |  |  | $ | 46 |  |  | $ | 47 |  |  | $ | (3 | ) |  | $ | (49 | ) |  | $ | (52 | ) |


## us-gaap:ConsolidationLessThanWhollyOwnedSubsidiaryParentOwnershipInterestEffectsOfChangesNetTextBlock

[0001571996-18-000034:notes:85]
The effect of changes in the Company's ownership interest in VMware, Inc., Pivotal, and SecureWorks on the Company's equity was as follows:

[0001571996-18-000034:notes:86]
|  | Six Months Ended |
|  | August 3, 2018 |
|  | (in millions) |
| Net loss attributable to Dell Technologies Inc. | $ | (1,135 | ) |
| Transfers (to) from the non-controlling interests: |  |
| Increase in Dell Technologies Inc. additional paid-in-capital for equity issuances and other equity activity | 606 |  |
| Decrease in Dell Technologies Inc. additional paid-in-capital for equity issuances and other equity activity | (535 | ) |
| Net transfers from non-controlling interests | 71 |  |
| Change from net loss attributable to Dell Technologies Inc. and transfers to/from the non-controlling interests | $ | (1,064 | ) |


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0001571996-18-000034:notes:87]
[same as prior period, unchanged from 0001571996-18-000022:notes:106]

[0001571996-18-000034:notes:88]
|  | Three Months Ended |  | Six Months Ended |
|  | August 3, 2018 |  | August 3, 2018 |
|  | (in millions) |
| Deferred revenue: |  |  |  |
| Deferred revenue at beginning of period | $ | 20,959 |  |  | $ | 20,816 |  |
| Revenue deferrals for new contracts and changes in estimates for pre-existing contracts (a) | 6,123 |  |  | 11,460 |  |
| Revenue recognized | (5,382 | ) |  | (10,576 | ) |
| Deferred revenue at end of period | $ | 21,700 |  |  | $ | 21,700 |  |
| Short-term deferred revenue | $ | 11,965 |  |  | $ | 11,965 |  |
| Long-term deferred revenue | $ | 9,735 |  |  | $ | 9,735 |  |

[0001571996-18-000034:notes:89]
[same as prior period, unchanged from 0001571996-18-000022:notes:108]


## us-gaap:DebtDisclosureTextBlock

[0001571996-18-000034:notes:90]
DEBT

[0001571996-18-000034:notes:91]
The following table summarizes the Company's outstanding debt as of the dates indicated:

[0001571996-18-000034:notes:92]
|  | August 3, 2018 |  | February 2, 2018 |
|  | (in millions) |
| Secured Debt |  |  |  |
| Senior Secured Credit Facilities: |  |  |  |
| 4.08% Term Loan B Facility due September 2023 | $ | 4,963 |  |  | $ | 4,988 |  |
| 3.83% Term Loan A-2 Facility due September 2021 | 4,283 |  |  | 4,394 |  |
| 3.58% Term Loan A-3 Facility due December 2018 | 1,213 |  |  | 1,213 |  |
| First Lien Notes: |  |  |  |
| 3.48% due June 2019 | 3,750 |  |  | 3,750 |  |
| 4.42% due June 2021 | 4,500 |  |  | 4,500 |  |
| 5.45% due June 2023 | 3,750 |  |  | 3,750 |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 8.10% due July 2036 | 1,500 |  |  | 1,500 |  |
| 8.35% due July 2046 | 2,000 |  |  | 2,000 |  |
| Unsecured Debt |  |  |  |
| Unsecured Notes and Debentures: |  |  |  |
| 5.65% due April 2018 | — |  |  | 500 |  |
| 5.875% due June 2019 | 600 |  |  | 600 |  |
| 4.625% due April 2021 | 400 |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| Senior Notes: |  |  |  |
| 5.875% due June 2021 | 1,625 |  |  | 1,625 |  |
| 7.125% due June 2024 | 1,625 |  |  | 1,625 |  |
| EMC Notes: |  |  |  |
| 1.875% due June 2018 | — |  |  | 2,500 |  |
| 2.650% due June 2020 | 2,000 |  |  | 2,000 |  |
| 3.375% due June 2023 | 1,000 |  |  | 1,000 |  |
| VMware Notes: |  |  |  |
| 2.30% due August 2020 | 1,250 |  |  | 1,250 |  |
| 2.95% due August 2022 | 1,500 |  |  | 1,500 |  |
| 3.90% due August 2027 | 1,250 |  |  | 1,250 |  |
| DFS Debt (Note 5) | 5,586 |  |  | 4,796 |  |
| Other |  |  |  |
| 4.59% Margin Loan Facility due April 2022 | 2,000 |  |  | 2,000 |  |
| Other | 56 |  |  | 101 |  |
| Total debt, principal amount | $ | 50,303 |  |  | $ | 52,694 |  |

[0001571996-18-000034:notes:93]
|  | August 3, 2018 |  | February 2, 2018 |
|  | (in millions) |
| Total debt, principal amount | $ | 50,303 |  |  | $ | 52,694 |  |
| Unamortized discount, net of unamortized premium | (246 | ) |  | (266 | ) |
| Debt issuance costs | (499 | ) |  | (557 | ) |
| Total debt, carrying value | $ | 49,558 |  |  | $ | 51,871 |  |
| Total short-term debt, carrying value | $ | 9,144 |  |  | $ | 7,873 |  |
| Total long-term debt, carrying value | $ | 40,414 |  |  | $ | 43,998 |  |

[0001571996-18-000034:notes:94]
During the six months ended August 3, 2018, the Company repaid $3 billion principal amount of its unsecured notes and $136 million principal amount of its term loan facilities.  Additionally, during the six months ended August 3, 2018, the Company issued an additional $868 million, net, in DFS debt to support the expansion of its financing receivables portfolio.

[0001571996-18-000034:notes:95]
Secured Debt

[0001571996-18-000034:notes:96]
Senior Secured Credit Facilities — The Company has entered into a credit agreement that provides for senior secured credit facilities (the "Senior Secured Credit Facilities") in the aggregate principal amount of $17.6 billion comprising (a) term loan facilities and (b) a senior secured Revolving Credit Facility, which includes capacity for up to $0.5 billion of letters of credit and for borrowings of up to $0.4 billion under swing-line loans.  As of August 3, 2018, available borrowings under the Revolving Credit Facility totaled $3.3 billion.  The Senior Secured Credit Facilities provide that the borrowers have the right at any time, subject to customary conditions, to request incremental term loans or incremental revolving commitments.

[0001571996-18-000034:notes:97]
Borrowings under the Senior Secured Credit Facilities bear interest at a rate per annum equal to an applicable margin, plus, at the borrowers' option, either (a) a base rate, which, under the Term Loan B Facility, is subject to an interest rate floor of 1.75% per annum, and under all other borrowings is subject to an interest rate floor of 0% per annum, or (b) a London interbank offered rate ("LIBOR"), which, under the Term Loan B Facility, is subject to an interest rate floor of 0.75% per annum, and under all other borrowings is subject to an interest rate floor of 0% per annum.  Interest is payable, in the case of loans bearing interest based on LIBOR, at the end of each interest period (but at least every three months), in arrears and, in the case of loans bearing interest based on the base rate, quarterly in arrears.

[0001571996-18-000034:notes:98]
The Term Loan A-2 Facility amortizes in equal quarterly installments in aggregate annual amounts equal to 5% of the original principal amount in the first year after the closing date of the refinancing transaction on October 20, 2017, 10% of the original principal amount in each of the second and third years after October 20, 2017, and 70% of the original principal amount in the fourth year after October 20, 2017.  The Term Loan B Facility amortizes in equal quarterly installments in aggregate annual amounts equal to 1% of the original principal amount.  The Term Loan A-3 Facility and the Revolving Credit Facility have no amortization.  The Term Loan A-3 Facility requires the borrowers to prepay outstanding borrowings under these facilities with 100% of the net cash proceeds of certain non-ordinary course asset sales or dispositions.  The borrowers may voluntarily repay outstanding loans under the term loan facilities and the Revolving Credit Facility at any time without premium or penalty, other than customary "breakage" costs.

[0001571996-18-000034:notes:99]
All obligations of the borrowers under the Senior Secured Credit Facilities and certain swap agreements, cash management arrangements, and certain letters of credit provided by any lender or agent party to the Senior Secured Credit Facilities or any of its affiliates and certain other persons are secured by (a) a first-priority security interest in certain tangible and intangible assets of the borrowers and the guarantors and (b) a first-priority pledge of 100% of the capital stock of the borrowers, Dell Inc., a wholly‑owned subsidiary of the Company ("Dell"), and each wholly-owned material restricted subsidiary of the borrowers and the guarantors, in each case subject to certain thresholds, exceptions, and permitted liens.

[0001571996-18-000034:notes:100]
First Lien Notes — The senior secured notes (collectively, the "First Lien Notes") were issued on June 1, 2016 in an aggregate principal amount of $20.0 billion.  Interest on these borrowings is payable semiannually.  The First Lien Notes are secured, on a pari passu basis with the Senior Secured Credit Facilities, on a first-priority basis by substantially all of the tangible and intangible assets of the issuers and guarantors that secure obligations under the Senior Secured Credit Facilities, including pledges of all capital stock of the issuers, Dell, and certain wholly-owned material subsidiaries of the issuers and the guarantors, subject to certain exceptions.

[0001571996-18-000034:notes:101]
The Company has agreed to use commercially reasonable efforts to register with the SEC notes having terms substantially identical to the terms of the First Lien Notes as part of an offer to exchange such registered notes for the First Lien Notes.  The Company will be obligated to pay additional interest on the First Lien Notes if it fails to consummate such an exchange offer within five years after the closing date of the EMC merger transaction.

[0001571996-18-000034:notes:102]
China Revolving Credit Facility — On October 31, 2017, the Company entered into a credit agreement (the "China Revolving Credit Facility") with a bank lender for a secured revolving loan facility in an aggregate principal amount not to exceed $500 million.  Borrowings under the China Revolving Credit Facility bear interest at LIBOR plus 0.6% per annum.  The Company may voluntarily repay outstanding loans under the China Revolving Credit Facility at any time without premium or penalty, other than customary "breakage" costs.  The facility will expire on October 31, 2018.  As of August 3, 2018, there were no outstanding borrowings under the China Revolving Credit Facility.

[0001571996-18-000034:notes:103]
Unsecured Debt

[0001571996-18-000034:notes:104]
Unsecured Notes and Debentures — The Company has outstanding unsecured notes and debentures (collectively, the "Unsecured Notes and Debentures") that were issued prior to the acquisition of Dell by Dell Technologies Inc. in the going-private transaction that closed in October 2013.  Interest on these borrowings is payable semiannually.

[0001571996-18-000034:notes:105]
Senior Notes — The senior unsecured notes (collectively, the "Senior Notes") were issued on June 22, 2016 in an aggregate principal amount of $3.25 billion.  Interest on these borrowings is payable semiannually.

[0001571996-18-000034:notes:106]
EMC Notes — On September 7, 2016, EMC had outstanding $2.5 billion aggregate principal amount of its 1.875% Notes due June 2018, which the Company fully repaid during the three months ended August 3, 2018, $2.0 billion aggregate principal amount of its 2.650% Notes due June 2020, and $1.0 billion aggregate principal amount of its 3.375% Notes due June 2023 (collectively, the "EMC Notes").  Interest on these borrowings is payable semiannually.  The EMC Notes remain outstanding following the closing of the EMC merger transaction.

[0001571996-18-000034:notes:107]
VMware Notes — On August 21, 2017, VMware, Inc. completed a public offering of unsecured senior notes in the aggregate amount of $4.0 billion, consisting of outstanding principal due on the following dates: $1.25 billion due August 21, 2020, $1.50 billion due August 21, 2022, and $1.25 billion due August 21, 2027 (collectively, the "VMware Notes").  The VMware Notes bear interest, payable semiannually, at annual rates of 2.30%, 2.95%, and 3.90%, respectively.  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.

[0001571996-18-000034:notes:108]
VMware Revolving Credit Facility —  On September 12, 2017, VMware, Inc. entered into an unsecured credit agreement, establishing a revolving credit facility (the "VMware Revolving Credit Facility"), with a syndicate of lenders that provides the company with a borrowing capacity of up to $1.0 billion which may be used for VMware, Inc. general corporate purposes.  Commitments under the VMware Revolving Credit Facility are available for a period of five years, which may be extended, subject to the satisfaction of certain conditions, by up to two one year periods.  The credit agreement contains certain representations, warranties, and covenants.  Commitment fees, interest rates, and other terms of borrowing under the VMware Revolving Credit Facility may vary based on VMware, Inc.’s external credit ratings.  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.  As of August 3, 2018, there were no outstanding borrowings under the VMware Revolving Credit Facility.

[0001571996-18-000034:notes:109]
DFS Debt

[0001571996-18-000034:notes:110]
See Note 5 and Note 7 of the Notes to the Condensed Consolidated Financial Statements, respectively, for discussion of DFS debt and the interest rate swap agreements that hedge a portion of that debt.

[0001571996-18-000034:notes:111]
Other

[0001571996-18-000034:notes:112]
Margin Loan Facility — On April 12, 2017, the Company entered into the Margin Loan Facility in an aggregate principal amount of $2.0 billion.  VMW Holdco LLC, a wholly-owned subsidiary of EMC, is the borrower under the Margin Loan Facility, which is secured by 60 million shares of Class B common stock of VMware, Inc. and 20 million shares of Class A common stock of VMware, Inc.  Loans under the Margin Loan Facility bear interest at a rate per annum payable, at the borrower's option, either at (a) a base rate plus 1.25% per annum or (b) a LIBOR-based rate plus 2.25% per annum.  Interest under the Margin Loan Facility is payable quarterly.

[0001571996-18-000034:notes:113]
The Margin Loan Facility will mature in April 2022.  The borrower may voluntarily repay outstanding loans under the Margin Loan Facility at any time without premium or penalty, other than customary "breakage" costs, subject to certain minimum threshold amounts for prepayment.

[0001571996-18-000034:notes:114]
Pivotal Revolving Credit Facility — On September 7, 2017, Pivotal entered into a credit agreement (the "Pivotal Revolving Credit Facility") that provides for a senior secured revolving loan facility in an aggregate principal amount not to exceed $100 million.  The credit facility contains customary representations, warranties, and covenants, including financial covenants.  The credit agreement will expire on September 8, 2020, unless it is terminated earlier.  None of the net proceeds of borrowings under the facility will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of Pivotal and Pivotal's subsidiaries.  As of August 3, 2018, there were no outstanding borrowings under the Pivotal Revolving Credit Facility.

[0001571996-18-000034:notes:115]
Aggregate Future Maturities

[0001571996-18-000034:notes:116]
As of August 3, 2018, aggregate future maturities of the Company's debt were as follows:

[0001571996-18-000034:notes:117]
|  | Maturities by Fiscal Year |
|  | 2019 (remaining six months) |  | 2020 |  | 2021 |  | 2022 |  | 2023 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Secured Credit Facilities and First Lien Notes | $ | 1,405 |  |  | $ | 4,245 |  |  | $ | 371 |  |  | $ | 7,888 |  |  | $ | 63 |  |  | $ | 16,488 |  |  | $ | 30,460 |  |
| Unsecured Notes and Debentures | — |  |  | 600 |  |  | — |  |  | 400 |  |  | — |  |  | 952 |  |  | 1,952 |  |
| Senior Notes and EMC Notes | — |  |  | — |  |  | 2,000 |  |  | 1,625 |  |  | — |  |  | 2,625 |  |  | 6,250 |  |
| VMware Notes | — |  |  | — |  |  | 1,250 |  |  | — |  |  | 1,500 |  |  | 1,250 |  |  | 4,000 |  |
| DFS Debt | 1,931 |  |  | 1,998 |  |  | 1,459 |  |  | 165 |  |  | 31 |  |  | 1 |  |  | 5,585 |  |
| Margin Loan Facility | — |  |  | — |  |  | — |  |  | — |  |  | 2,000 |  |  | — |  |  | 2,000 |  |
| Other | 16 |  |  | 24 |  |  | 14 |  |  | — |  |  | — |  |  | 2 |  |  | 56 |  |
| Total maturities, principal amount | 3,352 |  |  | 6,867 |  |  | 5,094 |  |  | 10,078 |  |  | 3,594 |  |  | 21,318 |  |  | 50,303 |  |
| Associated carrying value adjustments | (4 | ) |  | (21 | ) |  | (7 | ) |  | (164 | ) |  | (27 | ) |  | (522 | ) |  | (745 | ) |
| Total maturities, carrying value amount | $ | 3,348 |  |  | $ | 6,846 |  |  | $ | 5,087 |  |  | $ | 9,914 |  |  | $ | 3,567 |  |  | $ | 20,796 |  |  | $ | 49,558 |  |

[0001571996-18-000034:notes:118]
Covenants and Unrestricted Net Assets — The credit agreement for the Senior Secured Credit Facilities contains customary negative covenants that generally limit the ability of Denali Intermediate Inc., a wholly-owned subsidiary of Dell Technologies ("Dell Intermediate"), Dell, and Dell's and Denali Intermediate's other restricted subsidiaries to incur debt, create liens, make fundamental changes, enter into asset sales, make certain investments, pay dividends or distribute or redeem certain equity interests, prepay or redeem certain debt, and enter into certain transactions with affiliates.  The indenture governing the Senior Notes contains customary negative covenants that generally limit the ability of Denali Intermediate, Dell, and Dell's and Denali Intermediate's other restricted subsidiaries to incur additional debt or issue certain preferred shares, pay dividends on or make other distributions in respect of capital stock or make other restricted payments, make certain investments, sell or transfer certain assets, create liens on certain assets to secure debt, consolidate, merge, sell, or otherwise dispose of all or substantially all assets, enter into certain transactions with affiliates, and designate subsidiaries as unrestricted subsidiaries.  The negative covenants under such credit agreements and indenture are subject to certain exceptions, qualifications, and "baskets."  The indentures governing the First Lien Notes, the Unsecured Notes and Debentures, and the EMC Notes variously impose limitations, subject to specified exceptions, on creating certain liens, entering into sale and lease-back transactions, and entering into certain asset sales.  The foregoing credit agreements and indentures contain customary events of default, including failure to make required payments, failure to comply with covenants, and the occurrence of certain events of bankruptcy and insolvency.

[0001571996-18-000034:notes:119]
As of August 3, 2018, the Company had certain consolidated subsidiaries that were designated as unrestricted subsidiaries for all purposes of the applicable credit agreements and the indentures governing the First Lien Notes and the Senior Notes.

[0001571996-18-000034:notes:120]
The Term Loan A-2 Facility, the Term Loan A-3 Facility, and the Revolving Credit Facility are subject to a first lien net leverage ratio covenant that is tested at the end of each fiscal quarter of Dell with respect to Dell's preceding four fiscal quarters.  The Company was in compliance with all financial covenants as of August 3, 2018.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001571996-18-000034:notes:121]
[same as prior period, unchanged from 0001571996-18-000022:notes:139]

[0001571996-18-000034:notes:122]
[same as prior period, unchanged from 0001571996-18-000022:notes:140]

[0001571996-18-000034:notes:123]
[same as prior period, unchanged from 0001571996-18-000022:notes:141]

[0001571996-18-000034:notes:124]
The Company's objective is to offset gains and losses resulting from these exposures with gains and losses on the derivative contracts used to hedge the exposures, thereby reducing volatility of earnings and protecting the fair values of assets and liabilities.  The earnings effects of the derivative instruments are presented in the same income statement line items as the earnings effects of the hedged items.  For derivatives designated as cash flow hedges, the Company assesses hedge effectiveness both at the onset of the hedge and at regular intervals throughout the life of the derivative.  The Company does not have any derivatives designated as fair value hedges.

[0001571996-18-000034:notes:125]
[same as prior period, unchanged from 0001571996-18-000022:notes:143]

[0001571996-18-000034:notes:126]
[same as prior period, unchanged from 0001571996-18-000022:notes:144]

[0001571996-18-000034:notes:127]
During the six months ended August 3, 2018 and August 4, 2017, the Company did not discontinue any cash flow hedges related to foreign exchange contracts that had a material impact on the Company's results of operations due to the probability that the forecasted cash flows would not occur.

[0001571996-18-000034:notes:128]
[same as prior period, unchanged from 0001571996-18-000022:notes:146]

[0001571996-18-000034:notes:129]
[same as prior period, unchanged from 0001571996-18-000022:notes:147]

[0001571996-18-000034:notes:130]
[same as prior period, unchanged from 0001571996-18-000022:notes:148]

[0001571996-18-000034:notes:131]
[same as prior period, unchanged from 0001571996-18-000022:notes:149]

[0001571996-18-000034:notes:132]
[same as prior period, unchanged from 0001571996-18-000022:notes:150]

[0001571996-18-000034:notes:133]
[same as prior period, unchanged from 0001571996-18-000022:notes:151]

[0001571996-18-000034:notes:134]
[same as prior period, unchanged from 0001571996-18-000022:notes:152]

[0001571996-18-000034:notes:135]
[same as prior period, unchanged from 0001571996-18-000022:notes:153]

[0001571996-18-000034:notes:136]
|  | August 3, 2018 |  | February 2, 2018 |
|  | (in millions) |
| Foreign exchange contracts: |  |  |  |  |  |
| Designated as cash flow hedging instruments | $ | 5,989 |  |  | $ | 4,392 |  |
| Non-designated as hedging instruments | 6,061 |  |  | 6,223 |  |
| Total | $ | 12,050 |  |  | $ | 10,615 |  |
| Interest rate contracts: |  |  |  |
| Non-designated as hedging instruments | $ | 2,356 |  |  | $ | 1,897 |  |

[0001571996-18-000034:notes:137]
[same as prior period, unchanged from 0001571996-18-000022:notes:155]

[0001571996-18-000034:notes:138]
| Derivatives in Cash FlowHedging Relationships |  | Gain (Loss)Recognizedin AccumulatedOCI, Netof Tax, onDerivatives |  | Location of Gain (Loss)Reclassified from Accumulated OCI into Income |  | Gain (Loss)Reclassifiedfrom AccumulatedOCI into Income |
|  |  | (in millions) |  |  |  | (in millions) |
| For the three months ended August 3, 2018 |  |  |  |
|  |  |  |  |  | Total net revenue |  | $ | 77 |  |
| Foreign exchange contracts |  | $ | 120 |  |  | Total cost of net revenue |  | — |  |
| Interest rate contracts |  | — |  |  | Interest and other, net |  | — |  |
| Total |  | $ | 120 |  |  |  |  | $ | 77 |  |
| For the three months ended August 4, 2017 |  |  |  |
|  |  |  |  |  | Total net revenue |  | $ | (49 | ) |
| Foreign exchange contracts |  | $ | (141 | ) |  | Total cost of net revenue |  | (21 | ) |
| Interest rate contracts |  | — |  |  | Interest and other, net |  | — |  |
| Total |  | $ | (141 | ) |  |  |  | $ | (70 | ) |
| For the six months ended August 3, 2018 |  |  |  |  |  |  |  |
|  |  |  |  |  | Total net revenue |  | $ | 46 |  |
| Foreign exchange contracts |  | $ | 241 |  |  | Total cost of net revenue |  | — |  |
| Interest rate contracts |  | — |  |  | Interest and other, net |  | — |  |
| Total |  | $ | 241 |  |  |  |  | $ | 46 |  |
| For the six months ended August 4, 2017 |  |  |  |  |  |  |  |
|  |  |  |  |  | Total net revenue |  | $ | (32 | ) |
| Foreign exchange contracts |  | $ | (157 | ) |  | Total cost of net revenue |  | (17 | ) |
| Interest rate contracts |  | — |  |  | Interest and other, net |  | — |  |
| Total |  | $ | (157 | ) |  |  |  | $ | (49 | ) |

[0001571996-18-000034:notes:139]
[same as prior period, unchanged from 0001571996-18-000022:notes:157]

[0001571996-18-000034:notes:140]
|  |  | Three Months Ended |  | Six Months Ended |  |  |
|  |  | August 3, 2018 |  | August 4, 2017 |  | August 3, 2018 |  | August 4, 2017 |  | Location of Gain (Loss) Recognized |
|  |  | (in millions) |  |  |
| Gain (Loss) Recognized: |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | 75 |  |  | $ | 51 |  |  | $ | 32 |  |  | $ | 4 |  |  | Interest and other, net |
| Interest rate contracts |  | (1 | ) |  | (1 | ) |  | 1 |  |  | (1 | ) |  | Interest and other, net |
| Total |  | $ | 74 |  |  | $ | 50 |  |  | $ | 33 |  |  | $ | 3 |  |  |  |

[0001571996-18-000034:notes:141]
[same as prior period, unchanged from 0001571996-18-000022:notes:160]

[0001571996-18-000034:notes:142]
[same as prior period, unchanged from 0001571996-18-000022:notes:161]

[0001571996-18-000034:notes:143]
|  | August 3, 2018 |
|  | Other CurrentAssets |  | Other Non-Current Assets |  | Other CurrentLiabilities |  | Other Non-CurrentLiabilities |  | TotalFair Value |
|  |  |  | (in millions) |  |  |
| Derivatives designated as hedging instruments: |
| Foreign exchange contracts in an asset position | $ | 206 |  |  | $ | — |  |  | $ | 17 |  |  | $ | — |  |  | $ | 223 |  |
| Foreign exchange contracts in a liability position | (72 | ) |  | — |  |  | (19 | ) |  | — |  |  | (91 | ) |
| Net asset (liability) | 134 |  |  | — |  |  | (2 | ) |  | — |  |  | 132 |  |
| Derivatives not designated as hedging instruments: |
| Foreign exchange contracts in an asset position | 289 |  |  | — |  |  | 15 |  |  | — |  |  | 304 |  |
| Foreign exchange contracts in a liability position | (121 | ) |  | — |  |  | (53 | ) |  | — |  |  | (174 | ) |
| Interest rate contracts in an asset position | — |  |  | 9 |  |  | — |  |  | — |  |  | 9 |  |
| Interest rate contracts in a liability position | — |  |  | — |  |  | — |  |  | (2 | ) |  | (2 | ) |
| Net asset (liability) | 168 |  |  | 9 |  |  | (38 | ) |  | (2 | ) |  | 137 |  |
| Total derivatives at fair value | $ | 302 |  |  | $ | 9 |  |  | $ | (40 | ) |  | $ | (2 | ) |  | $ | 269 |  |
|  | February 2, 2018 |
|  | Other CurrentAssets |  | Other Non-Current Assets |  | Other CurrentLiabilities |  | Other Non-CurrentLiabilities |  | TotalFair Value |
|  |  |  | (in millions) |  |  |
| Derivatives designated as hedging instruments: |
| Foreign exchange contracts in an asset position | $ | 9 |  |  | $ | — |  |  | $ | 11 |  |  | $ | — |  |  | $ | 20 |  |
| Foreign exchange contracts in a liability position | (7 | ) |  | — |  |  | (52 | ) |  | — |  |  | (59 | ) |
| Net asset (liability) | 2 |  |  | — |  |  | (41 | ) |  | — |  |  | (39 | ) |
| Derivatives not designated as hedging instruments: |
| Foreign exchange contracts in an asset position | 194 |  |  | 3 |  |  | 141 |  |  | — |  |  | 338 |  |
| Foreign exchange contracts in a liability position | (127 | ) |  | — |  |  | (283 | ) |  | — |  |  | (410 | ) |
| Interest rate contracts in an asset position | — |  |  | 11 |  |  | — |  |  | — |  |  | 11 |  |
| Interest rate contracts in a liability position | — |  |  | — |  |  | — |  |  | (1 | ) |  | (1 | ) |
| Net asset (liability) | 67 |  |  | 14 |  |  | (142 | ) |  | (1 | ) |  | (62 | ) |
| Total derivatives at fair value | $ | 69 |  |  | $ | 14 |  |  | $ | (183 | ) |  | $ | (1 | ) |  | $ | (101 | ) |

[0001571996-18-000034:notes:144]
The following tables present the gross amounts of the Company's derivative instruments, amounts offset due to master netting agreements with the Company's counterparties, and the net amounts recognized in the Condensed Consolidated Statements of Financial Position.

[0001571996-18-000034:notes:145]
|  | August 3, 2018 |
|  | Gross Amounts of Recognized Assets/ (Liabilities) |  | Gross Amounts Offset in the Statement of Financial Position |  | Net Amounts of Assets/ (Liabilities) Presented in the Statement of Financial Position |  | Gross Amounts not Offset in the Statement of Financial Position |  | Net Amount |
|  | Financial Instruments |  | Cash Collateral Received or Pledged |  |
|  | (in millions) |
| Derivative instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Financial assets | $ | 536 |  |  | $ | (225 | ) |  | $ | 311 |  |  | $ | — |  |  | $ | — |  |  | $ | 311 |  |
| Financial liabilities | (267 | ) |  | 225 |  |  | (42 | ) |  | — |  |  | 1 |  |  | (41 | ) |
| Total derivative instruments | $ | 269 |  |  | $ | — |  |  | $ | 269 |  |  | $ | — |  |  | $ | 1 |  |  | $ | 270 |  |
|  | February 2, 2018 |
|  | Gross Amounts of Recognized Assets/ (Liabilities) |  | Gross Amounts Offset in the Statement of Financial Position |  | Net Amounts of Assets/ (Liabilities) Presented in the Statement of Financial Position |  | Gross Amounts not Offset in the Statement of Financial Position |  | Net Amount |
|  | Financial Instruments |  | Cash Collateral Received or Pledged |  |
|  | (in millions) |
| Derivative instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Financial assets | $ | 369 |  |  | $ | (286 | ) |  | $ | 83 |  |  | $ | — |  |  | $ | — |  |  | $ | 83 |  |
| Financial liabilities | (470 | ) |  | 286 |  |  | (184 | ) |  | — |  |  | — |  |  | (184 | ) |
| Total derivative instruments | $ | (101 | ) |  | $ | — |  |  | $ | (101 | ) |  | $ | — |  |  | $ | — |  |  | $ | (101 | ) |


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0001571996-18-000034:notes:146]
[same as prior period, unchanged from 0001571996-18-000022:notes:165]

[0001571996-18-000034:notes:147]
|  | Three Months Ended |  | Six Months Ended |
|  | August 3, 2018 |  | August 4, 2017 |  | August 3, 2018 |  | August 4, 2017 |
|  | (in millions) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |
| Infrastructure Solutions Group: |  |  |  |  |  |  |  |
| Servers and networking | $ | 5,061 |  |  | $ | 3,777 |  |  | $ | 9,646 |  |  | $ | 7,033 |  |
| Storage | 4,166 |  |  | 3,690 |  |  | 8,248 |  |  | 7,395 |  |
| Total ISG net revenue | 9,227 |  |  | 7,467 |  |  | 17,894 |  |  | 14,428 |  |
| Client Solutions Group: |  |  |  |  |  |  |  |
| Commercial | 8,109 |  |  | 7,207 |  |  | 15,472 |  |  | 13,549 |  |
| Consumer | 3,019 |  |  | 2,659 |  |  | 5,927 |  |  | 5,365 |  |
| Total CSG net revenue | 11,128 |  |  | 9,866 |  |  | 21,399 |  |  | 18,914 |  |
| VMware: |  |  |  |  |  |  |  |
| Total VMware net revenue | 2,194 |  |  | 1,984 |  |  | 4,222 |  |  | 3,802 |  |
| Total segment net revenue | $ | 22,549 |  |  | $ | 19,317 |  |  | $ | 43,515 |  |  | $ | 37,144 |  |


## us-gaap:EarningsPerShareTextBlock

[0001571996-18-000034:notes:148]
[same as prior period, unchanged from 0001571996-18-000022:notes:167]

[0001571996-18-000034:notes:149]
[same as prior period, unchanged from 0001571996-18-000022:notes:168]

[0001571996-18-000034:notes:150]
The Company has two groups of common stock, denoted as the DHI Group Common Stock and the Class V Common Stock.  The DHI Group Common Stock consists of four classes of common stock, referred to as Class A Common Stock, Class B Common Stock, Class C Common Stock, and Class D Common Stock.  The DHI Group generally refers to the direct and indirect interest of Dell Technologies in all of Dell Technologies' business, assets, properties, liabilities, and preferred stock other than those attributable to the Class V Group, as well as the DHI Group's retained interest in the Class V Group equal to approximately 39% of the Company's economic interest in the Class V Group as of August 3, 2018.  The Class V Common Stock is intended to track the economic performance of approximately 61% of the Company's economic interest in the Class V Group as of such date.  The Class V Group consists solely of VMware, Inc. common stock held by the Company.  As of August 3, 2018, the Class V Group consisted of approximately 331 million shares of VMware, Inc. common stock.  See Note 16 of the Notes to the Condensed Consolidated Financial Statements and Exhibit 99.1 filed with the Company's quarterly report on Form 10-Q for the quarterly period ended August 3, 2018 for more information regarding the allocation of earnings from Dell Technologies' interest in VMware, Inc. between the DHI Group and the Class V Common Stock.

[0001571996-18-000034:notes:151]
[same as prior period, unchanged from 0001571996-18-000022:notes:170]

[0001571996-18-000034:notes:152]
[same as prior period, unchanged from 0001571996-18-000022:notes:171]

[0001571996-18-000034:notes:153]
|  | Three Months Ended |  | Six Months Ended |
|  | August 3, 2018 |  | August 4, 2017 |  | August 3, 2018 |  | August 4, 2017 |
| Earnings (loss) per share attributable to Dell Technologies Inc. - basic: |  |  |  |  |
| Class V Common Stock - basic | $ | 1.61 |  |  | $ | 1.00 |  |  | $ | 3.97 |  |  | $ | 1.60 |  |
| DHI Group - basic | $ | (1.44 | ) |  | $ | (1.65 | ) |  | $ | (3.39 | ) |  | $ | (3.94 | ) |
| Earnings (loss) per share attributable to Dell Technologies Inc. - diluted: |  |  |  |  |
| Class V Common Stock - diluted | $ | 1.58 |  |  | $ | 1.00 |  |  | $ | 3.91 |  |  | $ | 1.59 |  |
| DHI Group - diluted | $ | (1.45 | ) |  | $ | (1.66 | ) |  | $ | (3.40 | ) |  | $ | (3.95 | ) |

[0001571996-18-000034:notes:154]
[same as prior period, unchanged from 0001571996-18-000022:notes:173]

[0001571996-18-000034:notes:155]
|  | Three Months Ended |  | Six Months Ended |
|  | August 3, 2018 |  | August 4, 2017 |  | August 3, 2018 |  | August 4, 2017 |
|  | (in millions) |
| Numerator: Class V Common Stock |  |  |  |  |  |  |  |
| Net income attributable to Class V Common Stock - basic | $ | 320 |  |  | $ | 204 |  |  | $ | 790 |  |  | $ | 329 |  |
| Incremental dilution from VMware, Inc. attributable to Class V Common Stock (a) | (5 | ) |  | (2 | ) |  | (12 | ) |  | (4 | ) |
| Net income attributable to Class V Common Stock - diluted | $ | 315 |  |  | $ | 202 |  |  | $ | 778 |  |  | $ | 325 |  |
| Numerator: DHI Group |  |  |  |  |  |  |  |
| Net loss attributable to DHI Group - basic | $ | (819 | ) |  | $ | (936 | ) |  | $ | (1,925 | ) |  | $ | (2,232 | ) |
| Incremental dilution from VMware, Inc. attributable to DHI Group (a) | (4 | ) |  | (2 | ) |  | (8 | ) |  | (3 | ) |
| Net loss attributable to DHI Group - diluted | $ | (823 | ) |  | $ | (938 | ) |  | $ | (1,933 | ) |  | $ | (2,235 | ) |
| Denominator: Class V Common Stock weighted-average shares outstanding |  |  |  |  |  |  |  |  |  |  |  |
| Weighted-average shares outstanding - basic | 199 |  |  | 203 |  |  | 199 |  |  | 205 |  |
| Dilutive effect of options, restricted stock units, restricted stock, and other (b) | — |  |  | — |  |  | — |  |  | — |  |
| Weighted-average shares outstanding - diluted | 199 |  |  | 203 |  |  | 199 |  |  | 205 |  |
| Weighted-average shares outstanding - antidilutive (b) | — |  |  | — |  |  | — |  |  | — |  |
| Denominator: DHI Group weighted-average shares outstanding |  |  |  |  |  |  |  |
| Weighted-average shares outstanding - basic | 567 |  |  | 566 |  |  | 568 |  |  | 566 |  |
| Dilutive effect of options, restricted stock units, restricted stock, and other | — |  |  | — |  |  | — |  |  | — |  |
| Weighted-average shares outstanding - diluted | 567 |  |  | 566 |  |  | 568 |  |  | 566 |  |
| Weighted-average shares outstanding - antidilutive (c) | 47 |  |  | 36 |  |  | 48 |  |  | 37 |  |

[0001571996-18-000034:notes:156]
| (a) | The incremental dilution from VMware, Inc. represents the impact of VMware, Inc.'s dilutive securities on the diluted earnings (loss) per share of the DHI Group and the Class V Common Stock, respectively, and is calculated by multiplying the difference between VMware, Inc.'s basic and diluted earnings (loss) per share by the number of shares of VMware, Inc. common stock held by the Company. |

[0001571996-18-000034:notes:157]
[same as prior period, unchanged from 0001571996-18-000022:notes:176]

[0001571996-18-000034:notes:158]
[same as prior period, unchanged from 0001571996-18-000022:notes:177]


## us-gaap:FairValueDisclosuresTextBlock

[0001571996-18-000034:notes:159]
[same as prior period, unchanged from 0001571996-18-000022:notes:178]

[0001571996-18-000034:notes:160]
The following table presents the Company's hierarchy for its assets and liabilities measured at fair value on a recurring basis as of August 3, 2018 and February 2, 2018:

[0001571996-18-000034:notes:161]
|  | August 3, 2018 (a) |  | February 2, 2018 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | QuotedPricesin ActiveMarkets forIdenticalAssets |  | SignificantOtherObservableInputs |  | SignificantUnobservableInputs |  |  |  | QuotedPricesin ActiveMarkets forIdenticalAssets |  | SignificantOtherObservableInputs |  | SignificantUnobservableInputs |  |  |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 11,662 |  |  | $ | — |  |  | $ | — |  |  | $ | 11,662 |  |  | $ | 8,641 |  |  | $ | — |  |  | $ | — |  |  | $ | 8,641 |  |
| U.S. corporate debt securities | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 23 |  |  | — |  |  | 23 |  |
| U.S. government and agencies | — |  |  | 8 |  |  | — |  |  | 8 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Foreign corporate debt securities | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 65 |  |  | — |  |  | 65 |  |
| Debt securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government and agencies | 623 |  |  | 318 |  |  | — |  |  | 941 |  |  | 682 |  |  | 392 |  |  | — |  |  | 1,074 |  |
| U.S. corporate | — |  |  | 1,863 |  |  | — |  |  | 1,863 |  |  | — |  |  | 2,003 |  |  | — |  |  | 2,003 |  |
| Foreign | — |  |  | 2,323 |  |  | — |  |  | 2,323 |  |  | — |  |  | 2,547 |  |  | — |  |  | 2,547 |  |
| Equity and other securities | 430 |  |  | 14 |  |  | — |  |  | 444 |  |  | 236 |  |  | 5 |  |  | — |  |  | 241 |  |
| Derivative instruments | — |  |  | 311 |  |  | — |  |  | 311 |  |  | — |  |  | 83 |  |  | — |  |  | 83 |  |
| Total assets | $ | 12,715 |  |  | $ | 4,837 |  |  | $ | — |  |  | $ | 17,552 |  |  | $ | 9,559 |  |  | $ | 5,118 |  |  | $ | — |  |  | $ | 14,677 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative instruments | $ | — |  |  | $ | 42 |  |  | $ | — |  |  | $ | 42 |  |  | $ | — |  |  | $ | 184 |  |  | $ | — |  |  | $ | 184 |  |
| Total liabilities | $ | — |  |  | $ | 42 |  |  | $ | — |  |  | $ | 42 |  |  | $ | — |  |  | $ | 184 |  |  | $ | — |  |  | $ | 184 |  |

[0001571996-18-000034:notes:162]
(a)   The Company did not transfer any securities between levels during the six months ended August 3, 2018.

[0001571996-18-000034:notes:163]
[same as prior period, unchanged from 0001571996-18-000022:notes:182]

[0001571996-18-000034:notes:164]
Money Market Funds — The Company's investment in money market funds that are classified as cash equivalents hold underlying investments with a weighted average maturity of 90 days or less and are recognized at fair value.  The valuations of these securities are based on quoted prices in active markets for identical assets, when available, or pricing models whereby all significant inputs are observable or can be derived from or corroborated by observable market data.  The Company reviews security pricing and assesses liquidity on a quarterly basis.  As of August 3, 2018, the Company's U.S. portfolio had no material exposure to money market funds with a fluctuating net asset value.

[0001571996-18-000034:notes:165]
Equity and Other Securities — The majority of the Company's investments in equity and other securities that are measured at fair value on a recurring basis consist of strategic investments in publicly-traded companies.  The valuation of these securities is based on quoted prices in active markets.

[0001571996-18-000034:notes:166]
[same as prior period, unchanged from 0001571996-18-000022:notes:185]

[0001571996-18-000034:notes:167]
[same as prior period, unchanged from 0001571996-18-000022:notes:186]

[0001571996-18-000034:notes:168]
[same as prior period, unchanged from 0001571996-18-000022:notes:187]

[0001571996-18-000034:notes:169]
As of August 3, 2018 and February 2, 2018, the Company held strategic investments of $582 million and $485 million, respectively.  As these investments represent early-stage companies without readily determinable fair values, they are not included in the recurring fair value table above.

[0001571996-18-000034:notes:170]
[same as prior period, unchanged from 0001571996-18-000022:notes:189]

[0001571996-18-000034:notes:171]
[same as prior period, unchanged from 0001571996-18-000022:notes:190]

[0001571996-18-000034:notes:172]
|  | August 3, 2018 |  | February 2, 2018 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Secured Credit Facilities | $ | 10.3 |  |  | $ | 10.5 |  |  | $ | 10.4 |  |  | $ | 10.6 |  |
| First Lien Notes | $ | 19.7 |  |  | $ | 21.3 |  |  | $ | 19.7 |  |  | $ | 21.9 |  |
| Unsecured Notes and Debentures | $ | 1.8 |  |  | $ | 2.0 |  |  | $ | 2.3 |  |  | $ | 2.5 |  |
| Senior Notes | $ | 3.1 |  |  | $ | 3.4 |  |  | $ | 3.1 |  |  | $ | 3.4 |  |
| EMC Notes | $ | 3.0 |  |  | $ | 2.9 |  |  | $ | 5.5 |  |  | $ | 5.4 |  |
| VMware Notes | $ | 4.0 |  |  | $ | 3.9 |  |  | $ | 4.0 |  |  | $ | 3.9 |  |
| Margin Loan Facility | $ | 2.0 |  |  | $ | 2.0 |  |  | $ | 2.0 |  |  | $ | 2.0 |  |

[0001571996-18-000034:notes:173]
[same as prior period, unchanged from 0001571996-18-000022:notes:192]


## us-gaap:FinancingReceivableCreditQualityIndicatorsTableTextBlock

[0001571996-18-000034:notes:174]
The following table summarizes customer receivables, gross, including accrued interest, by credit quality indicator segregated by class, as of August 3, 2018 and February 2, 2018.  The categories shown in the table below segregate customer receivables based on the relative degrees of credit risk.  The credit quality indicators for DPA revolving accounts are measured primarily as of each quarter-end date, while all other indicators are generally updated on a periodic basis.

[0001571996-18-000034:notes:175]
[same as prior period, unchanged from 0001571996-18-000022:notes:194]

[0001571996-18-000034:notes:176]
|  | August 3, 2018 |  | February 2, 2018 |
|  | Higher |  | Mid |  | Lower |  | Total |  | Higher |  | Mid |  | Lower |  | Total |
|  | (in millions) |
| Revolving — DPA | $ | 133 |  |  | $ | 195 |  |  | $ | 324 |  |  | $ | 652 |  |  | $ | 131 |  |  | $ | 223 |  |  | $ | 361 |  |  | $ | 715 |  |
| Revolving — DBC | $ | 44 |  |  | $ | 54 |  |  | $ | 75 |  |  | $ | 173 |  |  | $ | 48 |  |  | $ | 58 |  |  | $ | 79 |  |  | $ | 185 |  |
| Fixed-term — Consumer and Commercial | $ | 3,665 |  |  | $ | 1,957 |  |  | $ | 1,203 |  |  | $ | 6,825 |  |  | $ | 3,334 |  |  | $ | 1,828 |  |  | $ | 1,120 |  |  | $ | 6,282 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001571996-18-000034:notes:177]
[same as prior period, unchanged from 0001571996-18-000022:notes:196]

[0001571996-18-000034:notes:178]
[same as prior period, unchanged from 0001571996-18-000022:notes:197]

[0001571996-18-000034:notes:179]
The following table presents goodwill allocated to the Company's business segments as of August 3, 2018 and February 2, 2018, and changes in the carrying amount of goodwill for the respective periods:

[0001571996-18-000034:notes:180]
|  | Infrastructure Solutions Group (a) |  | Client Solutions Group |  | VMware |  | Other Businesses (b) |  | Total |
|  | (in millions) |
| Balances as of February 2, 2018 | $ | 15,953 |  |  | $ | 4,237 |  |  | $ | 15,635 |  |  | $ | 4,095 |  |  | $ | 39,920 |  |
| Impact of foreign currency translation | (278 | ) |  | — |  |  | — |  |  | (68 | ) |  | (346 | ) |
| Goodwill divested | (69 | ) |  | — |  |  | — |  |  | — |  |  | (69 | ) |
| Other adjustments (c) | (396 | ) |  | — |  |  | (1 | ) |  | 396 |  |  | (1 | ) |
| Balances as of August 3, 2018 | $ | 15,210 |  |  | $ | 4,237 |  |  | $ | 15,634 |  |  | $ | 4,423 |  |  | $ | 39,504 |  |

[0001571996-18-000034:notes:181]
[same as prior period, unchanged from 0001571996-18-000022:notes:200]

[0001571996-18-000034:notes:182]
| (b) | Other Businesses consists of offerings by Pivotal, SecureWorks, RSA Security LLC ("RSA Security"), Virtustream Group Holdings, Inc. ("Virtustream"), and Boomi, Inc. ("Boomi"). |

[0001571996-18-000034:notes:183]
[same as prior period, unchanged from 0001571996-18-000022:notes:202]

[0001571996-18-000034:notes:184]
Goodwill and indefinite-lived intangible assets are tested for impairment annually during the third fiscal quarter and whenever events or circumstances may indicate that an impairment has occurred.  Based on the results of the annual impairment test, which was a quantitative test for certain goodwill reporting units and a qualitative test for others, no impairment of goodwill or indefinite-lived intangible assets existed for any reporting unit as of November 3, 2017.  As a result of this analysis, it was determined that the excess of fair value over carrying amount was greater than 20% for all of the Company's existing goodwill reporting units as of November 3, 2017, with the exception of the Core Storage, Servers, and Networking goodwill reporting unit within the Infrastructure Solutions Group segment, which had an excess of fair value over carrying amount of 18% as of such date.  Management will continue to monitor the Core Storage, Servers, and Networking goodwill reporting unit and consider potential impacts to the impairment assessment.  Goodwill and indefinite-lived intangible assets were assessed during the three months ended May 4, 2018 to consider the impact of segment reporting changes.  No indications of impairment were identified as a result of these changes.  The Company did not have any accumulated goodwill impairment charges as of August 3, 2018.

[0001571996-18-000034:notes:185]
[same as prior period, unchanged from 0001571996-18-000022:notes:204]

[0001571996-18-000034:notes:186]
[same as prior period, unchanged from 0001571996-18-000022:notes:205]

[0001571996-18-000034:notes:187]
The Company's intangible assets as of August 3, 2018 and February 2, 2018 were as follows:

[0001571996-18-000034:notes:188]
|  | August 3, 2018 |  | February 2, 2018 |
|  | Gross |  | AccumulatedAmortization |  | Net |  | Gross |  | AccumulatedAmortization |  | Net |
|  | (in millions) |
| Customer relationships | $ | 22,724 |  |  | $ | (10,164 | ) |  | $ | 12,560 |  |  | $ | 22,764 |  |  | $ | (8,637 | ) |  | $ | 14,127 |  |
| Developed technology | 15,589 |  |  | (7,596 | ) |  | 7,993 |  |  | 15,586 |  |  | (6,196 | ) |  | 9,390 |  |
| Trade names | 1,277 |  |  | (497 | ) |  | 780 |  |  | 1,277 |  |  | (407 | ) |  | 870 |  |
| Leasehold assets (liabilities) | 128 |  |  | (8 | ) |  | 120 |  |  | 128 |  |  | (6 | ) |  | 122 |  |
| Definite-lived intangible assets | 39,718 |  |  | (18,265 | ) |  | 21,453 |  |  | 39,755 |  |  | (15,246 | ) |  | 24,509 |  |
| Indefinite-lived trade names | 3,755 |  |  | — |  |  | 3,755 |  |  | 3,756 |  |  | — |  |  | 3,756 |  |
| Total intangible assets | $ | 43,473 |  |  | $ | (18,265 | ) |  | $ | 25,208 |  |  | $ | 43,511 |  |  | $ | (15,246 | ) |  | $ | 28,265 |  |

[0001571996-18-000034:notes:189]
Amortization expense related to definite-lived intangible assets was approximately $1.5 billion and $1.7 billion for the three months ended August 3, 2018 and August 4, 2017, respectively, and $3.0 billion and $3.5 billion during the six months ended August 3, 2018 and August 4, 2017, respectively.  The amortization expense for the fiscal year ended February 2, 2018 was primarily related to the intangible assets acquired in the EMC merger transaction.  There were no material impairment charges related to intangible assets during the three months ended August 3, 2018 and August 4, 2017.

[0001571996-18-000034:notes:190]
Estimated future annual pre-tax amortization expense of definite-lived intangible assets as of August 3, 2018 over the next five fiscal years and thereafter is as follows:

[0001571996-18-000034:notes:191]
| Fiscal Years | (in millions) |
| 2019 (remaining six months) | $ | 3,050 |  |
| 2020 | 4,308 |  |
| 2021 | 3,346 |  |
| 2022 | 2,636 |  |
| 2023 | 1,756 |  |
| Thereafter | 6,357 |  |
| Total | $ | 21,453 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001571996-18-000034:notes:192]
[same as prior period, unchanged from 0001571996-18-000022:notes:211]

[0001571996-18-000034:notes:193]
For the three months ended August 3, 2018 and August 4, 2017, the Company's effective income tax rates were 1.5% and 38.9%, respectively, on pre-tax losses of $0.5 billion and $1.2 billion, respectively.  For the six months ended August 3, 2018 and August 4, 2017, the Company's effective income tax rates were 8.4% and 36.4%, respectively, on pre-tax losses of $1.1 billion and $3.1 billion, respectively.  The changes in the Company's effective income tax rates for the three and six months ended August 3, 2018 compared to the prior periods were primarily attributable to impacts of U.S. Tax Reform.  The change in the Company's effective income tax rate for the six months ended August 3, 2018 was also impacted by discrete tax benefits resulting from the impact of adopting the new revenue standard.

[0001571996-18-000034:notes:194]
[same as prior period, unchanged from 0001571996-18-000022:notes:213]

[0001571996-18-000034:notes:195]
GAAP requires the effect of a change in tax laws to be recognized in the period that includes the enactment date.  Due to the complexities involved in accounting for the enactment of U.S. Tax Reform, the SEC staff issued Staff Accounting Bulletin No. 118 ("SAB 118"), which allows companies to record provisional amounts in earnings for the first year following the Act's enactment, with those provisional amounts required to be finalized by the end of that year.  In accordance with GAAP and SAB 118, for the fiscal year ended February 2, 2018, the Company recognized a provisional tax benefit of $0.5 billion, which was primarily driven by a $1.5 billion tax benefit related to the remeasurement of deferred tax assets and liabilities, offset by $1.0 billion of current and future income tax expenses related to the Transition Tax.  The Company’s provisional estimates for the Transition Tax are based on its initial analysis using available information and estimates.  In accordance with SAB 118, the Company’s provisional benefit will be adjusted once the analysis is complete, but no later than the fourth quarter of the fiscal year ending February 1, 2019.  The Company continues to collect and process the data necessary to complete the analysis.  In addition, the U.S. Treasury Department issued proposed regulations as guidance for the Transition Tax on August 1, 2018.  The Company is also evaluating the impact of this guidance on the calculation of its provisional benefit.  As a result, no adjustments have been made to the provisional amount recorded for the fiscal year ended February 2, 2018.  Revisions to the Company’s provisional estimates may be material to the Company.  Any final guidance to be issued by the U.S. Treasury Department also could further affect the provisional calculation.  Additionally, when the Company files its U.S. tax return for the fiscal year ended February 2, 2018, any changes to the tax positions for temporary differences compared to the estimates used for the provisional estimate will result in an adjustment of the estimated tax benefit recorded as of February 2, 2018.

[0001571996-18-000034:notes:196]
The differences between the estimated effective income tax rates and the U.S. federal statutory rate of 21% principally result from the Company's geographical distribution of income and differences between the book and tax treatment of certain items.  In certain jurisdictions, the Company's tax rate is significantly less than the applicable statutory rate as a result of tax holidays.  The majority of the Company's foreign income that is subject to these tax holidays and lower tax rates is attributable to Singapore, China, and Malaysia.  A significant portion of these income tax benefits is related to a tax holiday that will expire at the end of the fiscal year ending February 1, 2019.  The Company is currently seeking new terms for the affected subsidiary beyond the fiscal year ending February 1, 2019, and it is uncertain whether any terms will be agreed upon.  The Company's other tax holidays will expire in whole or in part during fiscal years 2019 through 2023.  Many of these tax holidays and reduced tax rates may be extended when certain conditions are met or may be terminated early if certain conditions are not met.

[0001571996-18-000034:notes:197]
The Company's U.S. federal income tax returns for fiscal years 2007 through 2009 are currently under consideration by the Office of Appeals of the Internal Revenue Service (the "IRS").  The IRS issued a Revenue Agent's Report ("RAR") related to those years during the fiscal year ended February 3, 2017.  The IRS has proposed adjustments primarily relating to transfer pricing matters with which the Company disagrees and is contesting through the IRS administrative appeals process.  In May 2017, the IRS commenced a federal income tax audit for fiscal years 2010 through 2014, which could take several years to complete.

[0001571996-18-000034:notes:198]
Prior to the EMC merger transaction, EMC received a RAR for its tax years 2009 and 2010.  On May 5, 2017, EMC received an RAR for its tax year 2011.  The Company has been contesting certain adjustments proposed in these RARs through the IRS administrative appeals process and, during the three months ended August 3, 2018, reached an agreement on the contested issues with the IRS.  The terms are not material to the Company’s results of operations, financial position, or cash flows.

[0001571996-18-000034:notes:199]
The Company is also currently under income tax audits in various state and foreign jurisdictions.  The Company is undergoing negotiations, and in some cases contested proceedings, relating to tax matters with the taxing authorities in these jurisdictions.  The Company believes that it has provided adequate reserves related to all matters contained in tax periods open to examination.  Although the Company believes it has made adequate provisions for the uncertainties surrounding these audits, should the Company experience unfavorable outcomes, such outcomes could have a material impact on its results of operations, financial position, and cash flows.  With respect to major U.S. state and foreign taxing jurisdictions, the Company is generally not subject to tax examinations for years prior to the fiscal year ended February 2, 2007.

[0001571996-18-000034:notes:200]
Judgment is required in evaluating the Company's uncertain tax positions and determining the Company's provision for income taxes.  The unrecognized tax benefits were $3.3 billion and $3.2 billion as of August 3, 2018 and February 2, 2018, respectively, and are included in other non-current liabilities in the Condensed Consolidated Statements of Financial Position.  The Company does not anticipate a significant change to the total amount of unrecognized tax benefits within the next twelve months.

[0001571996-18-000034:notes:201]
The Company takes certain non-income tax positions in the jurisdictions in which it operates and has received certain non-income tax assessments from various jurisdictions.  The Company believes that a material loss in these matters is not probable and that it is not reasonably possible that a material loss exceeding amounts already accrued has been incurred.  The Company believes its positions in these non-income tax litigation matters are supportable and that it ultimately will prevail in the matters.  In the normal course of business, the Company's positions and conclusions related to its non-income taxes could be challenged and assessments may be made.  To the extent new information is obtained and the Company's views on its positions, probable outcomes of assessments, or litigation change, changes in estimates to the Company's accrued liabilities would be recorded in the period in which such a determination is made.  In the resolution process for income tax and non-income tax audits, in certain situations the Company is required to provide collateral guarantees or indemnification to regulators and tax authorities until the matter is resolved.


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0001571996-18-000034:notes:202]
[same as prior period, unchanged from 0001571996-18-000022:notes:220]

[0001571996-18-000034:notes:203]
The Company offers or arranges various financing options and services for its customers in North America, Europe, Australia, and New Zealand through Dell Financial Services and its affiliates ("DFS").  The key activities of DFS include originating, collecting, and servicing customer receivables primarily related to the purchase of Dell Technologies products and services.  In some cases, DFS also offers financing on the purchase of third-party technology products that complement the Dell Technologies portfolio of products and services.  New financing originations were $1.9 billion and $1.6 billion for the three months ended August 3, 2018 and August 4, 2017, respectively, and were $3.6 billion and $2.7 billion for the six months ended August 3, 2018 and August 4, 2017, respectively.

[0001571996-18-000034:notes:204]
[same as prior period, unchanged from 0001571996-18-000022:notes:222]

[0001571996-18-000034:notes:205]
[same as prior period, unchanged from 0001571996-18-000022:notes:223]

[0001571996-18-000034:notes:206]
[same as prior period, unchanged from 0001571996-18-000022:notes:224]

[0001571996-18-000034:notes:207]
| • | Fixed-term sales-type leases and loans — The Company enters into sales-type lease arrangements with customers who seek lease financing. Leases with business customers have fixed terms of generally two to four years. Future maturities of minimum lease and associated financing payments as of August 3, 2018 were as follows: Fiscal 2019 - $1,335 million; Fiscal 2020 - $1,932 million; Fiscal 2021 - $1,203 million; Fiscal 2022 - $462 million; Fiscal 2023 and beyond - $153 million. Future maturities and associated financing payments referenced herein represent the aggregate payments under the customer lease contract. The Company also offers fixed-term loans to qualified small businesses, large commercial accounts, governmental organizations, educational entities, and certain individual consumer customers. These loans are repaid in equal payments including interest and have defined terms of generally three to five years. |

[0001571996-18-000034:notes:208]
The following table summarizes the components of the Company's financing receivables segregated by portfolio segment as of August 3, 2018 and February 2, 2018:

[0001571996-18-000034:notes:209]
|  | August 3, 2018 |  | February 2, 2018 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Financing receivables, net: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer receivables, gross (a) | $ | 825 |  |  | $ | 6,825 |  |  | $ | 7,650 |  |  | $ | 900 |  |  | $ | 6,282 |  |  | $ | 7,182 |  |
| Allowances for losses | (75 | ) |  | (51 | ) |  | (126 | ) |  | (81 | ) |  | (64 | ) |  | (145 | ) |
| Customer receivables, net | 750 |  |  | 6,774 |  |  | 7,524 |  |  | 819 |  |  | 6,218 |  |  | 7,037 |  |
| Residual interest | — |  |  | 646 |  |  | 646 |  |  | — |  |  | 606 |  |  | 606 |  |
| Financing receivables, net | $ | 750 |  |  | $ | 7,420 |  |  | $ | 8,170 |  |  | $ | 819 |  |  | $ | 6,824 |  |  | $ | 7,643 |  |
| Short-term | $ | 750 |  |  | $ | 3,390 |  |  | $ | 4,140 |  |  | $ | 819 |  |  | $ | 3,100 |  |  | $ | 3,919 |  |
| Long-term | $ | — |  |  | $ | 4,030 |  |  | $ | 4,030 |  |  | $ | — |  |  | $ | 3,724 |  |  | $ | 3,724 |  |

[0001571996-18-000034:notes:210]
(a) Customer financing receivables, gross, includes accrued interest.

[0001571996-18-000034:notes:211]
The following table summarizes the aging of the Company's customer financing receivables, gross, including accrued interest, as of August 3, 2018 and February 2, 2018, segregated by class:

[0001571996-18-000034:notes:212]
|  | August 3, 2018 |  | February 2, 2018 |
|  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |
|  | (in millions) |
| Revolving — DPA | $ | 572 |  |  | $ | 60 |  |  | $ | 20 |  |  | $ | 652 |  |  | $ | 633 |  |  | $ | 59 |  |  | $ | 23 |  |  | $ | 715 |  |
| Revolving — DBC | 151 |  |  | 18 |  |  | 4 |  |  | 173 |  |  | 162 |  |  | 19 |  |  | 4 |  |  | 185 |  |
| Fixed-term — Consumer and Commercial | 6,065 |  |  | 677 |  |  | 83 |  |  | 6,825 |  |  | 5,414 |  |  | 775 |  |  | 93 |  |  | 6,282 |  |
| Total customer receivables, gross | $ | 6,788 |  |  | $ | 755 |  |  | $ | 107 |  |  | $ | 7,650 |  |  | $ | 6,209 |  |  | $ | 853 |  |  | $ | 120 |  |  | $ | 7,182 |  |

[0001571996-18-000034:notes:213]
Aging is likely to fluctuate quarter to quarter as a result of the variability in volume of large transactions entered into over the period, and the administrative processes that accompany those larger transactions.  As such, fluctuations in aging do not necessarily indicate a material change in the credit quality of the portfolio.

[0001571996-18-000034:notes:214]
[same as prior period, unchanged from 0001571996-18-000022:notes:231]

[0001571996-18-000034:notes:215]
The Company maintains programs that facilitate the funding of financing receivables in the capital markets. The following table summarizes DFS debt as of the periods indicated.  The table excludes the allocated portion of the Company's other borrowings, which represents the additional amount considered to fund the DFS business.

[0001571996-18-000034:notes:216]
|  | August 3, 2018 |  | February 2, 2018 |
|  | (in millions) |
| DFS U.S. debt |  |  |  |
| Securitization facilities | $ | 1,782 |  |  | $ | 1,498 |  |
| Fixed-term securitization offerings | 2,305 |  |  | 2,034 |  |
| Other | 132 |  |  | 32 |  |
| Total DFS U.S. debt | 4,219 |  |  | 3,564 |  |
| DFS international debt |  |  |  |
| Securitization facility | 497 |  |  | 404 |  |
| Other structured facilities | 670 |  |  | 628 |  |
| Note payable | 200 |  |  | 200 |  |
| Total DFS international debt | 1,367 |  |  | 1,232 |  |
| Total DFS debt | $ | 5,586 |  |  | $ | 4,796 |  |
| Total short-term DFS debt | $ | 3,130 |  |  | $ | 3,327 |  |
| Total long-term DFS debt | $ | 2,456 |  |  | $ | 1,469 |  |

[0001571996-18-000034:notes:217]
[same as prior period, unchanged from 0001571996-18-000022:notes:234]

[0001571996-18-000034:notes:218]
Securitization Facilities — The Company maintains separate securitization facilities in the United States for fixed-term leases and loans and revolving loans.  This debt is collateralized solely by the U.S. financing receivables in the facilities.  The debt has a variable interest rate and the duration of this debt is based on the terms of the underlying financing receivables.  As of August 3, 2018, the total debt capacity related to the U.S. securitization facilities was $3.5 billion.  The Company enters into interest swap agreements to effectively convert a portion of its securitization debt from a floating rate to a fixed rate.  See Note 7 of the Notes to the Condensed Consolidated Financial Statements for additional information about interest rate swaps.

[0001571996-18-000034:notes:219]
The Company's U.S. securitization facility for revolving loans is effective through June 1, 2020.  The Company's two U.S. securitization facilities for fixed-term leases and loans are effective through February 10, 2020 and February 22, 2020.

[0001571996-18-000034:notes:220]
The securitization facilities contain standard structural features related to the performance of the securitized receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the facility, no further funding of receivables will be permitted and the timing of the Company's expected cash flows from over-collateralization will be delayed.  As of August 3, 2018, these criteria were met.

[0001571996-18-000034:notes:221]
Fixed-Term Securitization Offerings — The Company periodically issues asset-backed debt securities under fixed-term securitization programs to private investors.  The asset-backed debt securities are collateralized solely by the U.S. fixed-term financing receivables in the offerings, which are held by Special Purpose Entities ("SPEs"), as discussed below.  The interest rate on these securities is fixed and ranges from 0.85% to 3.85% per annum, and the duration of these securities is based on the terms of the underlying financing receivables.

[0001571996-18-000034:notes:222]
[same as prior period, unchanged from 0001571996-18-000022:notes:239]

[0001571996-18-000034:notes:223]
Securitization Facility — The Company maintains a securitization facility in Europe for fixed-term leases and loans.  This facility is effective through January 13, 2019.  As of August 3, 2018, the total debt capacity related to the international securitization facility was $695 million.

[0001571996-18-000034:notes:224]
The securitization facility contains standard structural features related to the performance of the securitized receivables which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the program, no further funding of receivables will be permitted and the timing of the Company's expected cash flows from over-collateralization will be delayed.  As of August 3, 2018, these criteria were met.

[0001571996-18-000034:notes:225]
Other Structured Facilities — In connection with the Company's international financing operations, the Company has entered into revolving structured financing debt programs related to its fixed-term lease and loan products sold in Canada, Europe, Australia, and New Zealand.  The Canadian facility, which is collateralized solely by Canadian financing receivables, had a total debt capacity of $192 million as of August 3, 2018, and is effective through January 16, 2023.  The European facility, which is collateralized solely by European financing receivables, had a total debt capacity of $463 million as of August 3, 2018, and is effective through December 14, 2020.  The Australia and New Zealand facility, which is collateralized solely by the Australia and New Zealand financing receivables, had a total debt capacity of $88 million as of August 3, 2018, and is effective through January 29, 2020.

[0001571996-18-000034:notes:226]
Note Payable — On November 27, 2017, the Company entered into an unsecured credit agreement to fund receivables in Mexico.  As of August 3, 2018, the aggregate principal amount of the note payable is $200 million.  The note bears interest at either the applicable London interbank offered rate ("LIBOR") plus 2.25%, for the borrowings denominated in U.S. dollars, or the Mexican Interbank Equilibrium Interest Rate ("TIIE") plus 2.00%, for the borrowings denominated in Mexican pesos.  The note will mature on December 1, 2020.  Although the note is unsecured, the Company intends to manage the note in the same manner as its structured financing programs, so that the collections from financing receivables in Mexico will be used to pay down principal and interest of the note.

[0001571996-18-000034:notes:227]
[same as prior period, unchanged from 0001571996-18-000022:notes:244]

[0001571996-18-000034:notes:228]
In connection with the securitization facilities and offerings discussed above, the Company transfers certain U.S. and European customer financing receivables to SPEs that meet the definition of a Variable Interest Entity ("VIE") and are consolidated, along with the associated debt, into the Consolidated Financial Statements, as the Company is the primary beneficiary of those VIEs.  The SPEs are bankruptcy-remote legal entities with separate assets and liabilities.  The purpose of the SPEs is to facilitate the funding of customer receivables in the capital markets.

[0001571996-18-000034:notes:229]
[same as prior period, unchanged from 0001571996-18-000022:notes:246]

[0001571996-18-000034:notes:230]
|  | August 3, 2018 |  | February 2, 2018 |
|  | (in millions) |
| Financing receivables held by consolidated VIEs, net: |  |  |  |  |  |
| Short-term, net | $ | 2,794 |  |  | $ | 2,572 |  |
| Long-term, net | 2,379 |  |  | 1,981 |  |
| Financing receivables held by consolidated VIEs, net | $ | 5,173 |  |  | $ | 4,553 |  |

[0001571996-18-000034:notes:231]
Financing receivables transferred via securitization through SPEs were $1.2 billion and $1.0 billion for the three months ended August 3, 2018 and August 4, 2017, respectively, and $2.5 billion and $1.9 billion for the six months ended August 3, 2018 and August 4, 2017, respectively.

[0001571996-18-000034:notes:232]
Some of the SPEs have entered into financing arrangements with multi-seller conduits that, in turn, issue asset-backed debt securities in the capital markets.  The DFS debt outstanding, which is collateralized by the financing receivables held by the consolidated VIEs, was $4.6 billion and $3.9 billion as of August 3, 2018 and February 2, 2018, respectively.  The Company's risk of loss related to securitized receivables is limited to the amount by which the Company's right to receive collections for assets securitized exceeds the amount required to pay interest, principal, and fees and expenses related to the asset-backed securities.  The Company provides credit enhancement to the securitization in the form of over-collateralization.

[0001571996-18-000034:notes:233]
[same as prior period, unchanged from 0001571996-18-000022:notes:250]

[0001571996-18-000034:notes:234]
To manage certain concentrations of customer credit exposure, the Company may sell selected fixed-term financing receivables to unrelated third parties on a periodic basis.  The amount of financing receivables sold was $271 million and $228 million for the six months ended August 3, 2018 and August 4, 2017, respectively.


## us-gaap:MinorityInterestDisclosureTextBlock

[0001571996-18-000034:notes:235]
[same as prior period, unchanged from 0001571996-18-000022:notes:252]

[0001571996-18-000034:notes:236]
VMware, Inc. — The non-controlling interests' share of equity in VMware, Inc. is reflected as a component of the non-controlling interests in the accompanying Condensed Consolidated Statements of Financial Position and was $5.6 billion and $5.2 billion as of August 3, 2018 and February 2, 2018, respectively.  As of August 3, 2018 and February 2, 2018, the Company held approximately 81.1% and 81.9%, respectively, of the outstanding equity interest in VMware, Inc.

[0001571996-18-000034:notes:237]
Pivotal — On April 24, 2018, Pivotal completed a registered underwritten IPO of its Class A common stock.  In conjunction with the IPO, all of Pivotal's preferred equity shares were converted into shares of its common stock on a one-to-one basis, such that upon completion of its IPO, Pivotal's outstanding capital stock consisted solely of common stock.  The non-controlling interests' share of equity in Pivotal is reflected as a component of the non-controlling interest in the accompanying Condensed Consolidated Statements of Financial Position and was $921 million and $489 million as of August 3, 2018 and February 2, 2018, respectively.  The increase in non-controlling interest for Pivotal is primarily due to the IPO completed during the three months ended May 4, 2018.  As of August 3, 2018 and February 2, 2018, the Company held approximately 64.9% and 77.1%, respectively, of the outstanding equity interest in Pivotal.

[0001571996-18-000034:notes:238]
SecureWorks — The non-controlling interests' share of equity in SecureWorks is reflected as a component of the non-controlling interests in the accompanying Condensed Consolidated Statements of Financial Position and was $96 million and $90 million as of August 3, 2018 and February 2, 2018, respectively.  As of August 3, 2018 and February 2, 2018, the Company held approximately 86.5% and 87.1%, respectively, of the outstanding equity interest in SecureWorks, excluding restricted stock awards ("RSAs").  As of August 3, 2018 and February 2, 2018, the Company held approximately 85.6% and 86.3%, respectively, of the outstanding equity interest in SecureWorks, including RSAs.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001571996-18-000034:notes:239]
[same as prior period, unchanged from 0001571996-18-000022:notes:256]

[0001571996-18-000034:notes:240]
[same as prior period, unchanged from 0001571996-18-000022:notes:257]

[0001571996-18-000034:notes:241]
[same as prior period, unchanged from 0001571996-18-000022:notes:258]

[0001571996-18-000034:notes:242]
|  | Three Months Ended |  | Six Months Ended |
|  | August 3, 2018 |  | August 4, 2017 |  | August 3, 2018 |  | August 4, 2017 |
|  | (in millions) |
| Warranty liability: |  |  |  |  |  |  |  |
| Warranty liability at beginning of period | $ | 527 |  |  | $ | 607 |  |  | $ | 539 |  |  | $ | 604 |  |
| Costs accrued for new warranty contracts and changes in estimates for pre-existing warranties (a) (b) | 236 |  |  | 223 |  |  | 430 |  |  | 463 |  |
| Service obligations honored | (221 | ) |  | (242 | ) |  | (427 | ) |  | (479 | ) |
| Warranty liability at end of period | $ | 542 |  |  | $ | 588 |  |  | $ | 542 |  |  | $ | 588 |  |
| Current portion | $ | 366 |  |  | $ | 412 |  |  | $ | 366 |  |  | $ | 412 |  |
| Non-current portion | $ | 176 |  |  | $ | 176 |  |  | $ | 176 |  |  | $ | 176 |  |

[0001571996-18-000034:notes:243]
[same as prior period, unchanged from 0001571996-18-000022:notes:260]

[0001571996-18-000034:notes:244]
[same as prior period, unchanged from 0001571996-18-000022:notes:261]


## us-gaap:ReconciliationOfRevenueFromSegmentsToConsolidatedTextBlock

[0001571996-18-000034:notes:245]
[same as prior period, unchanged from 0001571996-18-000022:notes:262]

[0001571996-18-000034:notes:246]
|  | Three Months Ended |  | Six Months Ended |
|  | August 3, 2018 |  | August 4, 2017 |  | August 3, 2018 |  | August 4, 2017 |
|  | (in millions) |
| Consolidated net revenue: |  |  |  |  |  |  |  |  |  |  |
| Infrastructure Solutions Group | $ | 9,227 |  |  | $ | 7,467 |  |  | $ | 17,894 |  |  | $ | 14,428 |  |
| Client Solutions Group | 11,128 |  |  | 9,866 |  |  | 21,399 |  |  | 18,914 |  |
| VMware | 2,194 |  |  | 1,984 |  |  | 4,222 |  |  | 3,802 |  |
| Reportable segment net revenue | 22,549 |  |  | 19,317 |  |  | 43,515 |  |  | 37,144 |  |
| Other businesses (a) | 574 |  |  | 543 |  |  | 1,153 |  |  | 1,072 |  |
| Unallocated transactions (b) | (1 | ) |  | (4 | ) |  | (3 | ) |  | (5 | ) |
| Impact of purchase accounting (c) | (180 | ) |  | (335 | ) |  | (367 | ) |  | (690 | ) |
| Total net revenue | $ | 22,942 |  |  | $ | 19,521 |  |  | $ | 44,298 |  |  | $ | 37,521 |  |
| Consolidated operating income (loss): |  |  |  |  |  |  |  |
| Infrastructure Solutions Group | $ | 1,012 |  |  | $ | 647 |  |  | $ | 1,951 |  |  | $ | 1,153 |  |
| Client Solutions Group | 425 |  |  | 528 |  |  | 958 |  |  | 853 |  |
| VMware | 736 |  |  | 728 |  |  | 1,349 |  |  | 1,339 |  |
| Reportable segment operating income | 2,173 |  |  | 1,903 |  |  | 4,258 |  |  | 3,345 |  |
| Other businesses (a) | (49 | ) |  | (29 | ) |  | (99 | ) |  | (52 | ) |
| Unallocated transactions (b) | (16 | ) |  | (8 | ) |  | (25 | ) |  | (2 | ) |
| Impact of purchase accounting (c) | (215 | ) |  | (406 | ) |  | (437 | ) |  | (829 | ) |
| Amortization of intangibles | (1,526 | ) |  | (1,740 | ) |  | (3,048 | ) |  | (3,516 | ) |
| Transaction-related expenses (d) | (104 | ) |  | (138 | ) |  | (270 | ) |  | (329 | ) |
| Other corporate expenses (e) | (276 | ) |  | (247 | ) |  | (545 | ) |  | (554 | ) |
| Total operating loss | $ | (13 | ) |  | $ | (665 | ) |  | $ | (166 | ) |  | $ | (1,937 | ) |

[0001571996-18-000034:notes:247]
[same as prior period, unchanged from 0001571996-18-000022:notes:264]

[0001571996-18-000034:notes:248]
| (a) | Pivotal, SecureWorks, RSA Security, Virtustream, and Boomi constitute "Other businesses" and do not meet the requirements for a reportable segment, either individually or collectively. The results of Other businesses are not material to the Company's overall results. |

[0001571996-18-000034:notes:249]
[same as prior period, unchanged from 0001571996-18-000022:notes:266]

[0001571996-18-000034:notes:250]
[same as prior period, unchanged from 0001571996-18-000022:notes:267]

[0001571996-18-000034:notes:251]
[same as prior period, unchanged from 0001571996-18-000022:notes:268]

[0001571996-18-000034:notes:252]
[same as prior period, unchanged from 0001571996-18-000022:notes:269]


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0001571996-18-000034:notes:253]
Revenue Recognition — The Company enters into a variety of agreements to provide a wide portfolio of products and services offerings to its customers.  These agreements have varying requirements depending on the goods and services being sold, the rights and obligations conveyed, and the legal jurisdiction of the arrangement.

[0001571996-18-000034:notes:254]
Revenue is recognized either over time or at a point in time, depending on when the underlying goods or services are transferred to the customer, in an amount that reflects the consideration to which the Company expects to be entitled in exchange for delivering those goods or services.  The following five steps are applied to recognize revenue:

[0001571996-18-000034:notes:255]
| (1) | Identify the contract with a customer. The term "contract" refers to the enforceable rights and obligations provided in an agreement between the Company and one or more other parties in exchange for payment. The Company evaluates facts and circumstances regarding sales transactions in order to identify contracts with its customers. An agreement must meet all of the following criteria to qualify as a contract eligible for revenue recognition under the model: (i) the contract must be approved by all parties; (ii) each party's rights regarding the goods and services to be transferred to the customer can be identified; (iii) the payment terms for the goods and services can be identified; (iv) the customer has the ability and intent to pay and it is probable that the Company will collect substantially all of the consideration to which it will be entitled; and (v) the contract must have commercial substance. Judgment is used in determining the customer's ability and intent to pay, which is based upon various factors including the customer's historical payment experience or customer credit and financial information. |

[0001571996-18-000034:notes:256]
| (2) | Identify the performance obligations in the contract. Distinct promises within a contract are referred to as "performance obligations" and are accounted for as separate units of account. The Company assesses whether each promised good or service is distinct for the purpose of identifying the performance obligations in the contract. This assessment involves subjective determinations and requires management to make judgments about the individual promised goods or services and whether such goods or services are separable from the other aspects of the contractual relationship. Promised goods and services are considered distinct provided that: (i) the customer can benefit from the good or service either on its own or together with other resources that are readily available to the customer (that is, the good or service is capable of being distinct); and (ii) the Company's promise to transfer the good or service to the customer is separately identifiable from other promises in the contract (that is, the promise to transfer the good or service is distinct within the context of the contract). The Company's performance obligations consist of a variety of products and services offerings which include: hardware, such as servers, storage, networking, personal computers, workstations, and peripherals; third-party software; proprietary software licenses; support and deployment services, which include hardware support that extends beyond the Company's standard warranties, software maintenance, and installation; professional services; training; software as a service ("SaaS"); and infrastructure as a service ("IaaS"). |

[0001571996-18-000034:notes:257]
| (3) | Determine the transaction price. Transaction price reflects the amount of consideration to which the Company expects to be entitled in exchange for transferring goods or services to the customer. If the consideration promised in a contract includes a variable amount, the Company estimates the amount to which it expects to be entitled using either the expected value or most likely amount method. The Company’s contracts may include terms that could cause variability in the transaction price, including, for example, rebates, sales returns, and volume discounts. In determining the transaction price, any variable consideration would be considered, to the extent applicable, if it is probable that a significant future reversal of cumulative revenue under the contract will not occur when the uncertainty associated with the variable consideration is resolved. |

[0001571996-18-000034:notes:258]
| (4) | Allocate the transaction price to performance obligations in the contract. Many of the Company’s contracts include promises to transfer multiple products and services to a customer, and the transaction price must be allocated to each performance obligation in an amount that depicts the consideration to which the Company expects to be entitled in exchange for transferring the promised goods or services. For these contracts with multiple performance obligations, the transaction price is allocated in proportion to the standalone selling price ("SSP") of each performance obligation. If the contract contains a single performance obligation, the entire transaction price is allocated to that performance obligation. |

[0001571996-18-000034:notes:259]
The best evidence of SSP is the observable price of a good or service when the Company sells that good or service separately in similar circumstances to similar customers.  If a directly observable price is available, it must be utilized for the SSP.  If a directly observable price is not available, the SSP must be estimated.  The Company estimates SSP by considering multiple factors including, but not limited to, pricing practices, internal costs, and profit objectives as well as overall market conditions which include geographic or regional specific factors, competitive positioning, and competitor actions.  SSP can include fixed and variable components.  Variable components are estimated based on the most likely outcome or expected value of the variable components.

[0001571996-18-000034:notes:260]
| (5) | Recognize revenue when (or as) the performance obligation is satisfied. Revenue is recognized when obligations under the terms of the contract with the Company's customer are satisfied. Revenue is recognized either over time or at a point in time, depending on when the underlying products or services are transferred to the customer. Revenue is recognized at a point in time for products upon transfer of control. Revenue is recognized over time for support and deployment services, professional services, training, software support, SaaS, and IaaS. |

[0001571996-18-000034:notes:261]
The Company reports revenue net of any revenue-based taxes assessed by governmental authorities that are imposed on and concurrently with specific revenue-producing transactions.

[0001571996-18-000034:notes:262]
The Company has elected the following practical expedients with the adoption of the new revenue standard:

[0001571996-18-000034:notes:263]
| • | The Company does not account for significant financing components if the period between revenue recognition and when the customer pays for the product or service will be one year or less. |

[0001571996-18-000034:notes:264]
| • | The Company recognizes revenue equal to the amount it has a right to invoice when the amount corresponds directly with the value to the customer of the Company's performance to date. |

[0001571996-18-000034:notes:265]
| • | The Company does not account for shipping and handling activities as a separate performance obligation, but rather as an activity performed to transfer the promised good. |

[0001571996-18-000034:notes:266]
The following summarizes the nature of revenue recognized and the manner in which the Company accounts for sales transactions.

[0001571996-18-000034:notes:267]
Products

[0001571996-18-000034:notes:268]
Product revenue consists of hardware and software license sales that are delivered, sold as a subscription or sold on a consumption basis.  Hardware includes notebooks and desktop PCs, servers, storage hardware, and other hardware-related devices.  Software license sales include non-essential, stand-alone software applications.  Software applications provide customers with resource management, backup and archiving, information security, information management and intelligence, data analytics, and server virtualization capabilities.

[0001571996-18-000034:notes:269]
Revenue from the sale of hardware products is recognized when control has transferred to the customer, which typically occurs when the hardware has been shipped to the customer, risk of loss has transferred to the customer, the Company has a present right to payment, and customer acceptance has been satisfied.  Customer acceptance is satisfied if acceptance is obtained from the customer, if all acceptance provisions lapse, or if the Company has evidence that all acceptance provisions will be, or have been, satisfied.  Revenue from software license sales is generally recognized when control has transferred to the customer, which is typically upon shipment, electronic delivery, or when the software is available for download by the customer.  For certain arrangements, including software subscriptions and certain software license agreements which provide customers control to certain product performance obligations over time, revenue is recognized based on usage or ratably over the term of the arrangement based on the pattern of delivery of the product to the customer.

[0001571996-18-000034:notes:270]
Invoices for products are generally issued as control transfers, which is typically upon shipment or electronic delivery.  There was no significant revenue in any period presented related to performance obligations satisfied or partially satisfied in prior periods.

[0001571996-18-000034:notes:271]
Services

[0001571996-18-000034:notes:272]
Services revenue consists of revenue from sales of support services, including hardware support that extends beyond the Company's standard warranties, software maintenance, and installation; professional services; training; SaaS; and IaaS.  Revenue associated with undelivered performance obligations is deferred and recorded as control is transferred to the customer over time.  Revenue from fixed-price support or maintenance contracts sold for both hardware and software is recognized on a straight-line basis over the period of performance because the Company is required to provide services at any given time.  Other services revenue is recognized when the Company performs the services and the customers receive and consume the benefits.

[0001571996-18-000034:notes:273]
Invoices for services may be issued at the start of a service term, which is typically the case for support and deployment services, or as services are rendered, which is typically the case for professional services, training, SaaS, and IaaS.

[0001571996-18-000034:notes:274]
Revenue from leasing arrangements is not subject to the revenue standard for contracts with customers, and remains separately accounted for under existing lease accounting guidance.  The Company records revenue from the sale of equipment under sales-type leases as product revenue in an amount equal to the present value of minimum lease payments at the inception of the lease.  Sales-type leases also produce financing income, which is included in products net revenue in the Consolidated Statements of Income (Loss) and is recognized at consistent rates of return over the lease term.  The Company also offers qualified customers fixed-term loans and revolving credit lines for the purchase of products and services offered by the Company.  Financing income attributable to these loans is recognized in products net revenue on an accrual basis.

[0001571996-18-000034:notes:275]
Disaggregation of Revenue — The Company's revenue is presented on a disaggregated basis on the Condensed Consolidated Statements of Income (Loss) and in Note 18 of the Notes to the Condensed Consolidated Financial Statements based on an evaluation of disclosures outside of the financial statements, information regularly reviewed by the chief operating decision maker for evaluating the financial performance of operating segments, and other information that is used to evaluate the Company's financial performance or make resource allocations.  This information includes revenue from products and services, revenue from reportable segments, and revenue by major product categories within the segments.

[0001571996-18-000034:notes:276]
Contract Assets — Contract assets are rights to consideration in exchange for goods or services that the Company has transferred to a customer when such a right is conditional on something other than the passage of time.  Such amounts have been insignificant to date.

[0001571996-18-000034:notes:277]
Contract Liabilities — Contract liabilities primarily consist of deferred revenue.  Deferred revenue is recorded when the Company has a right to invoice or payments have been received for undelivered products or services, or in situations where revenue recognition criteria have not been met.  Deferred revenue also represents amounts received in advance for extended warranty services and software maintenance.  Revenue is recognized on these items when the revenue recognition criteria are met, generally resulting in ratable recognition over the contract term.  The Company also has deferred revenue related to undelivered hardware and professional services, consisting of installations and consulting engagements, which are recognized as the Company's performance obligations under the contract are completed.  See Note 9 of the Notes to the Condensed Consolidated Financial Statements for additional information about deferred revenue.

[0001571996-18-000034:notes:278]
Costs to Obtain a Contract — The incremental direct costs of obtaining a contract primarily consist of sales commissions and employer taxes related to commission payments.  The Company has elected, as a practical expedient, to expense as incurred costs to obtain a contract equal to or less than one year in duration.  For contracts greater than one year in duration, the associated costs to obtain a contract are deferred and amortized over the period of contract performance or a longer period, generally the estimated life of the customer relationship, if renewals are expected and the renewal commission is not commensurate with the initial commission.  Deferred costs to obtain a contract are typically amortized over a period of three to seven years, depending on the contract term and expectation of the period of benefit for the costs, which may exceed the contract term.  Amortization expense is recognized on a straight-line basis and included in selling, general, and administrative expenses in the Condensed Consolidated Statements of Income (Loss).  The Company periodically reviews these deferred costs to determine whether events or changes in circumstances have occurred that could impact the carrying value or period of benefit of the deferred sales commissions.  There were no material impairment losses for deferred sales commissions during the six months ended August 3, 2018 and August 4, 2017.

[0001571996-18-000034:notes:279]
Deferred costs to obtain a contract as of August 3, 2018 and February 2, 2018 were $1.0 billion and $0.8 billion, respectively.  Deferred costs to obtain a contract are classified as current assets and other non-current assets on the Condensed Consolidated Statements of Financial Position, based on when the expense is expected to be recognized.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001571996-18-000034:notes:280]
[same as prior period, unchanged from 0001571996-18-000022:notes:270]

[0001571996-18-000034:notes:281]
Deferred Revenue — Deferred revenue is recorded for support and deployment services, software maintenance, professional services, training, and SaaS when the Company has a right to invoice or payments have been received for undelivered products or services where transfer of control has not occurred.  Revenue is recognized on these items when the revenue recognition criteria are met, generally resulting in ratable recognition over the contract term.  The Company also has deferred revenue related to undelivered hardware and professional services, consisting of installations and consulting engagements, which are recognized as the Company's performance obligations under the contract are completed.

[0001571996-18-000034:notes:282]
Remaining Performance Obligations — Remaining performance obligations represent the aggregate amount of the transaction price allocated to performance obligations not delivered, or partially undelivered, as of the end of the reporting period.

[0001571996-18-000034:notes:283]
Remaining performance obligations include deferred revenue plus unbilled amounts not yet recorded in deferred revenue.  The aggregate amount of the transaction price allocated to remaining performance obligations does not include amounts owed under cancelable contracts where there is no substantive termination penalty.

[0001571996-18-000034:notes:284]
[same as prior period, unchanged from 0001571996-18-000022:notes:273]

[0001571996-18-000034:notes:285]
[same as prior period, unchanged from 0001571996-18-000022:notes:274]

[0001571996-18-000034:notes:286]
The value of the transaction price allocated to remaining performance obligations as of August 3, 2018 was approximately $29 billion.  The Company expects to recognize approximately 62% of remaining performance obligations as revenue in the next 12 months, and the remainder thereafter.


## us-gaap:ScheduleOfDebtTableTextBlock

[0001571996-18-000034:notes:287]
The following table summarizes DFS debt as of the periods indicated.  The table excludes the allocated portion of the Company's other borrowings, which represents the additional amount considered to fund the DFS business.


## us-gaap:ScheduleOfStockByClassTextBlock

[0001571996-18-000034:notes:288]
[same as prior period, unchanged from 0001571996-18-000022:notes:277]

[0001571996-18-000034:notes:289]
|  | Authorized |  | Issued |  | Outstanding |
|  | (in millions of shares) |
| Common stock as of February 2, 2018 |
| Class A | 600 |  |  | 410 |  |  | 410 |  |
| Class B | 200 |  |  | 137 |  |  | 137 |  |
| Class C | 7,900 |  |  | 24 |  |  | 23 |  |
| Class D | 100 |  |  | — |  |  | — |  |
| Class V | 343 |  |  | 223 |  |  | 199 |  |
|  | 9,143 |  |  | 794 |  |  | 769 |  |
| Common stock as of August 3, 2018 |
| Class A | 600 |  |  | 410 |  |  | 410 |  |
| Class B | 200 |  |  | 137 |  |  | 137 |  |
| Class C | 7,900 |  |  | 24 |  |  | 22 |  |
| Class D | 100 |  |  | — |  |  | — |  |
| Class V | 343 |  |  | 223 |  |  | 199 |  |
|  | 9,143 |  |  | 794 |  |  | 768 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001571996-18-000034:notes:290]
[same as prior period, unchanged from 0001571996-18-000022:notes:279]

[0001571996-18-000034:notes:291]
[same as prior period, unchanged from 0001571996-18-000022:notes:280]

[0001571996-18-000034:notes:292]
ISG previously included Virtustream product and service offerings.  Virtustream's cloud software and infrastructure-as-a-service solutions enable customers to migrate, run, and manage mission-critical applications in cloud-based IT environments.  During the three months ended May 4, 2018, the Company made certain segment reporting changes, which included the movement of Virtustream's results from ISG to other businesses.  None of these changes impacted the Company's previously reported consolidated financial results, but the Company's prior period segment results have been recast to reflect this change.

[0001571996-18-000034:notes:293]
ISG includes servers, networking, and storage, as well as services and third-party software and peripherals that are closely tied to the sale of ISG hardware.  CSG includes sales to commercial and consumer customers of desktops, thin client products, and notebooks, as well as services and third-party software and peripherals that are closely tied to the sale of CSG hardware.  VMware offerings include compute, management, cloud, networking, and security storage, mobility, and other end-user computing infrastructure software to businesses that provides a flexible digital foundation for the applications that empower businesses to serve their customers globally.

[0001571996-18-000034:notes:294]
[same as prior period, unchanged from 0001571996-18-000022:notes:283]

[0001571996-18-000034:notes:295]
[same as prior period, unchanged from 0001571996-18-000022:notes:284]


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001571996-18-000034:notes:296]
[same as prior period, unchanged from 0001571996-18-000022:notes:285]

[0001571996-18-000034:notes:297]
Awards under the Company's stock incentive plans include certain rights that allow the holder to exercise a put feature for the underlying Class A or Class C Common Stock after a six month holding period following the issuance of such common stock.  The put feature requires the Company to purchase the stock at its fair market value.  Accordingly, these awards and such common stock are subject to reclassification from equity to temporary equity, and the Company determines the award amounts to be classified as temporary equity as follows:

[0001571996-18-000034:notes:298]
[same as prior period, unchanged from 0001571996-18-000022:notes:287]

[0001571996-18-000034:notes:299]
| • | For stock appreciation rights, restricted stock units ("RSUs"), or RSAs, any of which stock award types are subject to service requirements, the fair value of the share is multiplied by the portion of the share for which services have been rendered. |

[0001571996-18-000034:notes:300]
| • | For share-based arrangements that are subject to the occurrence of a contingent event, those amounts are not reclassified to temporary equity until the contingency has been satisfied. Contingent events include the achievement of performance-based metrics. |

[0001571996-18-000034:notes:301]
The amount of redeemable shares classified as temporary equity as of August 3, 2018 was $2.1 billion, which consisted of 2.2 million issued and outstanding unrestricted common shares, 1.3 million RSUs, 0.4 million RSAs, and 27.0 million outstanding stock options.  The amount of redeemable shares classified as temporary equity as of February 2, 2018 was $384 million, which consisted of 2.9 million issued and outstanding unrestricted common shares, 0.4 million RSUs, 0.1 million RSAs, and 15.3 million outstanding stock options.  The increase in the value of redeemable shares during the six months ended August 3, 2018 was primarily attributable to an increase in DHI Group Common Stock fair value, as well as the reassessment of vesting of performance-based awards.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001571996-18-000034:notes:302]
[same as prior period, unchanged from 0001571996-18-000022:notes:291]

[0001571996-18-000034:notes:303]
[same as prior period, unchanged from 0001571996-18-000022:notes:292]

[0001571996-18-000034:notes:304]
Deferred costs to obtain a contract as of August 3, 2018 and February 2, 2018 were $1.0 billion and $0.8 billion, respectively.  Deferred costs to obtain a contract are classified as current assets and other non-current assets on the Condensed Consolidated Statements of Financial Position, based on when the expense is expected to be recognized.  Amortization of costs to obtain a contract during the three months ended August 3, 2018 and August 4, 2017 was $113 million and $62 million, respectively.  Amortization of costs to obtain a contract during the six months ended August 3, 2018 and August 4, 2017 was $219 million and $115 million, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001571996-18-000034:notes:305]
[same as prior period, unchanged from 0001571996-18-000022:notes:294]

[0001571996-18-000034:notes:306]
Preferred Stock

[0001571996-18-000034:notes:307]
The Company is authorized to issue one million shares of preferred stock, par value $.01 per share.  As of August 3, 2018, no shares of preferred stock were issued or outstanding.

[0001571996-18-000034:notes:308]
[same as prior period, unchanged from 0001571996-18-000022:notes:296]

[0001571996-18-000034:notes:309]
[same as prior period, unchanged from 0001571996-18-000022:notes:297]

[0001571996-18-000034:notes:310]
Class V Common Stock and Class V Group — In connection with the EMC merger transaction, the Company authorized 343 million shares of Class V Common Stock.  The Class V Common Stock is a type of common stock commonly referred to as a tracking stock, which is a class of common stock that is intended to track the economic performance of a defined set of assets and liabilities.  As of August 3, 2018, the 199 million shares of outstanding Class V Common Stock were intended to track the economic performance of approximately 61% of Dell Technologies' economic interest in the Class V Group.  The Class V Group as of such date consisted solely of approximately 331 million shares of VMware, Inc. common stock held by the Company.  The remaining 39% economic interest in the Class V Group as of August 3, 2018 was represented by the approximately 127 million retained interest shares held by the DHI Group.

[0001571996-18-000034:notes:311]
[same as prior period, unchanged from 0001571996-18-000022:notes:299]

[0001571996-18-000034:notes:312]
[same as prior period, unchanged from 0001571996-18-000022:notes:300]

[0001571996-18-000034:notes:313]
Since the date of the EMC merger transaction, the Company has authorized several programs to repurchase shares of its Class V Common Stock.  Of the $2.1 billion total authorized for repurchases under the programs, $676 million remained available as of August 3, 2018, all of which is attributable to the DHI Group Repurchase Program, which the board of directors suspended on December 13, 2016 until such time as it authorizes the reinstatement of that program.

[0001571996-18-000034:notes:314]
During the three months ended August 3, 2018, the Company did not repurchase any Class V Common Stock.  During the three months ended August 4, 2017, the Company repurchased 0.4 million shares of Class V Common Stock for an aggregate purchase price of $23 million.  The repurchase of these shares was funded by proceeds received by the Class V Group from the sale by a subsidiary of the Company of shares of Class A common stock of VMware, Inc. owned by such subsidiary.  Share repurchases made by VMware, Inc. of its Class A common stock from a subsidiary of the Company do not affect the determination of the respective interests of the Class V Common Stock and the DHI Group in the Class V Group.  See Exhibit 99.1 filed with the quarterly report on Form 10-Q for the three months ended August 3, 2018 for more information regarding Unaudited Attributed Financial Information for the Class V Group.

[0001571996-18-000034:notes:315]
[same as prior period, unchanged from 0001571996-18-000022:notes:303]

[0001571996-18-000034:notes:316]
DHI Group Common Stock Repurchases

[0001571996-18-000034:notes:317]
During the three months ended August 3, 2018 the Company repurchased an immaterial number of shares of DHI Group Common Stock for approximately $10 million.  During the three months ended August 4, 2017, the Company did not repurchase any shares of DHI Group Common Stock.

[0001571996-18-000034:notes:318]
[same as prior period, unchanged from 0001571996-18-000022:notes:306]

[0001571996-18-000034:notes:319]
[same as prior period, unchanged from 0001571996-18-000022:notes:307]

[0001571996-18-000034:notes:320]
Since the date of the EMC merger transaction, VMware, Inc.'s board of directors has authorized the repurchase of a total of $2.2 billion of VMware, Inc.'s Class A common stock, of which $876 million remained available as of August 3, 2018.

[0001571996-18-000034:notes:321]
During the three months ended August 3, 2018 and August 4, 2017, VMware, Inc. did not repurchase any shares of its Class A common stock.

[0001571996-18-000034:notes:322]
[same as prior period, unchanged from 0001571996-18-000022:notes:310]

[0001571996-18-000034:notes:323]
Class V Transaction

[0001571996-18-000034:notes:324]
On July 2, 2018, the Company announced that it had completed its evaluation of potential strategic business opportunities.  As a result of such evaluation, the Company has determined to pursue a transaction, referred to as the "Class V transaction," pursuant to an Agreement and Plan of Merger (the "Merger Agreement"), dated as of July 1, 2018, between the Company and Teton Merger Sub Inc. ("Merger Sub"), a Delaware corporation and wholly-owned subsidiary of the Company.  The Merger Agreement provides, among other things and subject to the terms and conditions set forth therein, that Merger Sub will be merged with and into the Company (the "Merger"), with the Company continuing as the surviving corporation.

[0001571996-18-000034:notes:325]
The Merger Agreement provides that, subject to the terms and conditions thereof, at the effective time of the Merger (the "Effective Time"), each share of Class V Common Stock that is issued and outstanding immediately prior to the Effective Time will be canceled and converted into the right to receive, at the holder’s election, (i) 1.3665 shares (the "Share Consideration") of Class C Common Stock or (ii) $109.00 in cash, without interest (the "Cash Consideration"), subject to an aggregate amount of Cash Consideration that may be received by holders of Class V Common Stock in the Merger not exceeding $9 billion (the "Aggregate Cash Consideration Cap").  If the total amount of Cash Consideration elected by holders of Class V Common Stock would exceed the Aggregate Cash Consideration Cap, a portion of the shares with respect to which a holder elects to receive the Cash Consideration equal to a fraction, the numerator of which is the Aggregate Cash Consideration Cap and the denominator of which is the aggregate amount of Cash Consideration elected by holders, will be converted into the right to receive the Cash Consideration and the remaining portion of such shares held by such holders will be converted into the right to receive the Share Consideration.  Any share of Class V Common Stock for which a valid election to receive Cash Consideration is not in effect at the Effective Time will be converted into Share Consideration.  Upon consummation of the Merger, all shares of the Class V Common Stock would be delisted from the New York Stock Exchange and the Class C Common Stock would be listed on the New York Stock Exchange.

[0001571996-18-000034:notes:326]
In addition, pursuant to the Merger Agreement, as of the Effective Time and unless otherwise agreed by the Company and a holder of a Class V Common Stock-based equity award granted by the Company (a "Class V Award"), each Class V Award will be converted into a new equity award on the same terms and conditions (including applicable vesting requirements and deferral provisions) with respect to the number of shares of Class C Common Stock that is equal to the number of shares of Class V Common Stock that were subject to the Class V Award multiplied by 1.3665 (rounded down to the nearest whole share).  The exercise price for any Class V Award options so converted will equal the exercise price of such Class V Award options immediately prior to the Effective Time divided by 1.3665 (rounded up to the nearest whole penny).

[0001571996-18-000034:notes:327]
In connection with the Merger Agreement, the board of directors of VMware, Inc. declared a conditional $11 billion one‑time special cash dividend pro rata to holders of VMware, Inc. common stock.  Immediately prior to the completion of the Class V transaction, subject to the satisfaction of other conditions of the Class V transaction, as well as certain other conditions, VMware, Inc. will pay the special cash dividend to its stockholders.  Approximately $8.95 billion of the VMware, Inc. cash dividend will be received by the Company and used to fund all or substantially all of the Cash Consideration paid to holders of the Class V Common Stock in the Class V transaction.  The Company will fund any remaining cash consideration, which is not expected to be material, from cash on hand.

[0001571996-18-000034:notes:328]
The obligation of the Company to complete the Merger and the Class V transaction is subject to stockholder approval and

[0001571996-18-000034:notes:329]
certain other closing conditions as further described in a Current Report on Form 8-K filed by the Company with the SEC on July 2, 2018.


## us-gaap:SubsequentEventsTextBlock

[0001571996-18-000034:notes:330]
SUBSEQUENT EVENTS

[0001571996-18-000034:notes:331]
During August 2018, VMware, Inc. announced that it signed a definitive agreement to acquire CloudHealth Technologies, Inc. ("CloudHealth Technologies").  Total consideration for the acquisition, subject to purchase price adjustments, will consist of approximately $500 million in cash and assumed unvested equity awards of the acquiree.  CloudHealth Technologies delivers a cloud operations platform that enables customers to help analyze and manage cloud cost, usage, security, and performance centrally for native public clouds.  The transaction is expected to close during the three months ended November 2, 2018 and is subject to regulatory approvals and customary closing conditions.

[0001571996-18-000034:notes:332]
On September 4, 2018, the Company repaid $600 million of the Term Loan A-3 Facility that matures in December 2018.

[0001571996-18-000034:notes:333]
Other than the matters identified above, there were no known events occurring after the balance sheet date and up until the date of the issuance of this report that would materially affect the information presented herein.
