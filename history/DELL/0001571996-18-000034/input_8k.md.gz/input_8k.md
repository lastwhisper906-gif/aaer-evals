# DELL 8-K — 0001571996-18-000029 filed 2018-09-06

## item codes, every 8-K on or before 2018-09-11

- 2018-09-06 0001571996-18-000029 — 2.02, 9.01
- 2018-08-06 0001571996-18-000027 — 8.01, 9.01
- 2018-07-02 0001193125-18-210339 — 1.01, 7.01, 9.01
- 2018-06-28 0001571996-18-000024 — 5.07
- 2018-06-04 0001571996-18-000019 — 2.02, 9.01
- 2018-05-17 0001571996-18-000016 — 7.01
- 2018-04-26 0001571996-18-000009 — 7.01, 9.01
- 2018-03-08 0001193125-18-074168 — 2.02, 9.01
- 2018-02-02 0001193125-18-029947 — 7.01, 9.01
- 2017-12-07 0001571996-17-000042 — 2.02, 9.01
- 2017-10-24 0001571996-17-000037 — 1.01, 2.03, 9.01
- 2017-09-15 0001571996-17-000027 — 5.02
- 2017-09-07 0001571996-17-000017 — 2.02, 9.01
- 2017-08-24 0001571996-17-000014 — 8.01
- 2017-06-29 0001571996-17-000011 — 3.03, 5.07, 8.01, 9.01
- 2017-06-08 0001193125-17-197638 — 2.02, 9.01
- 2017-03-30 0001193125-17-102794 — 8.01
- 2017-03-30 0001193125-17-102777 — 2.02, 9.01
- 2017-03-09 0001193125-17-076981 — 1.01, 2.03, 9.01
- 2017-01-17 0001193125-17-011125 — 8.01
- 2016-12-15 0001193125-16-793722 — 8.01
- 2016-12-08 0001193125-16-787976 — 2.02, 9.01
- 2016-11-10 0001193125-16-765964 — 1.02, 8.01
- 2016-11-04 0001193125-16-760249 — 8.01
- 2016-09-13 0001193125-16-708600 — 3.02
- 2016-09-09 0001193125-16-706567 — 1.01, 1.02, 2.01, 2.03, 3.02, 3.03, 5.02, 9.01
- 2016-09-07 0001193125-16-703370 — 3.03, 5.07, 7.01, 8.01, 9.01
- 2016-09-06 0001193125-16-702057 — 2.02, 9.01
- 2016-08-31 0001193125-16-697268 — 8.01, 9.01
- 2016-08-26 0001193125-16-692921 — 8.01, 9.01
- 2016-07-11 0001193125-16-645610 — 8.01
- 2016-07-05 0001193125-16-641679 — 8.01
- 2016-06-22 0001193125-16-629055 — 1.01, 2.03, 8.01, 9.01
- 2016-06-21 0001193125-16-627071 — 8.01, 9.01
- 2016-06-10 0001193125-16-618483 — 2.02, 9.01
- 2016-06-09 0001193125-16-617893 — 8.01, 9.01

## late-filing notifications on or before 2018-09-11

- none on or before 2018-09-11

## item 2.02 — earnings release, exhibit 99.1

[0001571996-18-000029:8k_2_02:1]
EX-99.1
2
exhibit991earnings8k080318.htm
EXHIBIT 99.1

[0001571996-18-000029:8k_2_02:2]
Exhibit

[0001571996-18-000029:8k_2_02:3]
Exhibit 99.1

[0001571996-18-000029:8k_2_02:4]
News Release

[0001571996-18-000029:8k_2_02:5]
Dell Technologies Reports Fiscal Year 2019 Second Quarter

[0001571996-18-000029:8k_2_02:6]
Financial Results

[0001571996-18-000029:8k_2_02:7]
ROUND ROCK, Texas - Sept. 6, 2018

[0001571996-18-000029:8k_2_02:8]
News summary

[0001571996-18-000029:8k_2_02:9]
| • | GAAP revenue up 18 percent to $22.9 billion |

[0001571996-18-000029:8k_2_02:10]
| • | Double-digit growth across all reportable segments—Infrastructure Solutions Group, Client Solutions Group and VMware |

[0001571996-18-000029:8k_2_02:11]
| • | Strong operating cash flow and continued debt pay down |

[0001571996-18-000029:8k_2_02:12]
| • | Full-year guidance increased based on strong first half results |

[0001571996-18-000029:8k_2_02:13]
Full story

[0001571996-18-000029:8k_2_02:14]
Dell Technologies (NYSE: DVMT) announces its fiscal 2019 second quarter results. For the second quarter, revenue was $22.9 billion, up 18 percent, and non-GAAP revenue was $23.1 billion, up 16 percent from the prior period. During the quarter, the company generated a GAAP operating loss of $13 million1, with a non-GAAP operating income of $2.1 billion, up 13 percent. Cash flow from operations was $2.6 billion, and excluding the impact of financing receivables, cash flow from operations would have been $3.1 billion2.

[0001571996-18-000029:8k_2_02:15]
“We are in the early stages of a global, technology-led investment cycle in which every company is becoming a technology company,” said Michael Dell, chairman and CEO, Dell Technologies. “As our results indicate, Dell Technologies is perfectly positioned to grow, gain share, drive innovation and be our customers’ best, most trusted partner on the journey to their digital future.”

[0001571996-18-000029:8k_2_02:16]
“Dell Technologies delivered another strong quarter, with double-digit revenue growth across all three of our reportable segments and strong cash flow generation for the first half of the year,” said Tom Sweet, chief financial officer, Dell Technologies. “Looking toward the second half of fiscal 2019, we’ll balance this growth by executing across strategic areas of the business, including driving additional share gains, continuing to generate strong cash flow and addressing our customers’ needs with our full range of capabilities.

[0001571996-18-000029:8k_2_02:17]
“Given our momentum in the first half of the fiscal year, we increased the revenue, operating income and net income guidance ranges we provided on July 2, in conjunction with the Class V exchange transaction announcement.”

[0001571996-18-000029:8k_2_02:18]
The company ended the second quarter with a cash and investments balance of $21.5 billion. In the quarter, Dell Technologies paid down approximately $2.6 billion of core debt3, and subsequent to the end of the quarter, the company prepaid $600 million of additional debt. Over the past two years, Dell Technologies has paid down approximately $13.7 billion in gross debt, excluding Dell Financial Services related and subsidiary debt.

[0001571996-18-000029:8k_2_02:19]
Fiscal year 2019 second quarter results

[0001571996-18-000029:8k_2_02:20]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | August 3, 2018 |  | August 4, 2017 |  | Change |  | August 3, 2018 |  | August 4, 2017 |  | Change |
|  | (in millions, except percentages; unaudited) |
| Total net revenue | $ | 22,942 |  |  | $ | 19,521 |  |  | 18% |  | $ | 44,298 |  |  | $ | 37,521 |  |  | 18% |
| Operating loss | $ | (13 | ) |  | $ | (665 | ) |  | 98% |  | $ | (166 | ) |  | $ | (1,937 | ) |  | 91% |
| Net loss | $ | (461 | ) |  | $ | (739 | ) |  | 38% |  | $ | (999 | ) |  | $ | (1,942 | ) |  | 49% |
| Non-GAAP net revenue | $ | 23,122 |  |  | $ | 19,856 |  |  | 16% |  | $ | 44,665 |  |  | $ | 38,211 |  |  | 17% |
| Non-GAAP operating income | $ | 2,108 |  |  | $ | 1,866 |  |  | 13% |  | $ | 4,134 |  |  | $ | 3,291 |  |  | 26% |
| Non-GAAP net income | $ | 1,349 |  |  | $ | 1,112 |  |  | 21% |  | $ | 2,523 |  |  | $ | 1,873 |  |  | 35% |
| Adjusted EBITDA | $ | 2,459 |  |  | $ | 2,180 |  |  | 13% |  | $ | 4,842 |  |  | $ | 3,975 |  |  | 22% |

[0001571996-18-000029:8k_2_02:21]
Information about Dell Technologies’ use of non-GAAP financial information is provided under “Non-GAAP Financial Measures” below. All comparisons in this press release are year over year unless otherwise noted.

[0001571996-18-000029:8k_2_02:22]
“The second quarter completes a strong first half of fiscal 2019, where we continued to demonstrate our commitment to innovation across our entire portfolio—including new solutions that give our customers the ability to drive better business outcomes through the power of their data,” said Jeff Clarke, vice chairman, Products & Operations. “We are able to provide our customers with a differentiated experience, given Dell Technologies’ unique family of businesses. We continue to collaborate on new solutions and enhanced integrations to provide a unified, seamless experience across PC and mobile devices, software-defined data centers, hyper-converged infrastructures and multi-cloud platforms.”

[0001571996-18-000029:8k_2_02:23]
Operating segments summary

[0001571996-18-000029:8k_2_02:24]
Infrastructure Solutions Group revenue for the second quarter was a record $9.2 billion, a 24 percent increase. This was driven by revenue of $4.2 billion in storage, a 13 percent increase, and revenue of $5.1 billion in servers and networking, a 34 percent increase. Operating income for the second quarter was $1.0 billion, or 11 percent of revenue and a 230 basis-point increase from the previous year, driven primarily by improved storage performance and operating expense leverage.

[0001571996-18-000029:8k_2_02:25]
Key second quarter highlights:

[0001571996-18-000029:8k_2_02:26]
| • | Worldwide leader for x86 servers in calendar second quarter, both in units and revenue4 |

[0001571996-18-000029:8k_2_02:27]
| • | Triple-digit growth for VxRail and VxRack, including $1 billion of cumulative revenue for VxRail since launching |

[0001571996-18-000029:8k_2_02:28]
| • | Enhancements to the Storage and Data Protection portfolio, including the new Integrated Data Protection Appliance DP4400 for the cloud |

[0001571996-18-000029:8k_2_02:29]
| • | Storage share gain for the second consecutive quarter expected when IDC reports results later today |

[0001571996-18-000029:8k_2_02:30]
“IDC has forecasted second quarter server and external storage systems spending will grow 19.6 percent and 5.5 percent, respectively, and we fully expect Dell Technologies’ Infrastructure Solutions Group will gain share in both segments when IDC releases second quarter share data,” said Matt Eastwood, senior vice president of IDC’s enterprise, datacenter, cloud infrastructure and developer research groups.

[0001571996-18-000029:8k_2_02:31]
Client Solutions Group revenue for the second quarter was $11.1 billion, up 13 percent, with double-digit growth across both Commercial and Consumer. Commercial revenue grew 13 percent to $8.1 billion and Consumer revenue was up 14 percent to $3.0 billion. Operating income for the second quarter was $425 million, a 20 percent decrease and 3.8 percent of revenue.

[0001571996-18-000029:8k_2_02:32]
Key second quarter highlights:

[0001571996-18-000029:8k_2_02:33]
| • | Shipped a record number of client units in the second fiscal quarter, while also expanding average selling prices |

[0001571996-18-000029:8k_2_02:34]
| • | Outperformed the PC industry and hit highest share position to date for total worldwide units and for commercial units at 18.2 percent and 22.8 percent, respectively5 |

[0001571996-18-000029:8k_2_02:35]
| • | No. 1 share position worldwide for displays, gaining unit share year-over-year for the 20th consecutive quarter6 |

[0001571996-18-000029:8k_2_02:36]
| • | Maintained position as No. 1 provider of workstations worldwide7; launched world’s most powerful 1-unit rack workstation |

[0001571996-18-000029:8k_2_02:37]
VMware revenue for the second quarter was $2.2 billion, up 11 percent, with operating income of $736 million and 33.5 percent of revenue. The company continues to see revenue synergies through the collaboration across the Dell Technologies family of businesses. The second quarter showed continued strong demand for Dell Technologies’ market-leading VxRail and VxRack hyperconverged offerings, and the company completed one of the largest VxRail hyperconverged infrastructure deals in its history. Additionally, VMworld last week showcased several announcements illustrating leveraged innovation across Dell Technologies. These new solutions and enhanced integrations provide customers with a unified, seamless experience across PC and mobile devices, software-defined data centers, hyper-converged infrastructures and multi-cloud platforms.

[0001571996-18-000029:8k_2_02:38]
Second quarter revenue from other businesses, including Pivotal, Secureworks, RSA Security, Virtustream and Boomi was $574 million, up 6 percent.

[0001571996-18-000029:8k_2_02:39]
Company outlook

[0001571996-18-000029:8k_2_02:40]
For fiscal 2019, the company is adjusting upward the guidance ranges provided on July 2, given the momentum it has seen year-to-date. The company now expects non-GAAP revenue to be between $90.5 billion and $92.0 billion for the full fiscal year, non-GAAP operating income to be between $8.4 billion and $8.8 billion, and non-GAAP net income to be between $4.9 billion and $5.3 billion.

[0001571996-18-000029:8k_2_02:41]
Conference call information

[0001571996-18-000029:8k_2_02:42]
As previously announced, the company will hold a conference call to discuss its second quarter results today at 7:00 a.m. CDT. The conference call will be broadcast live over the internet and can be accessed at investors.delltechnologies.com. For those unable to listen to the live broadcast, an archived version will be available at the same location for one year.

[0001571996-18-000029:8k_2_02:43]
A slide presentation containing additional financial and operating information may be downloaded from Dell Technologies’ website at investors.delltechnologies.com.

[0001571996-18-000029:8k_2_02:44]
Dell Technologies analyst meeting

[0001571996-18-000029:8k_2_02:45]
Dell Technologies will host a live meeting for analysts Tues., Sept. 18, at 9:00 a.m. EDT/8:00 a.m. CDT. The invitation-only event will feature presentations and discussions from the company’s executive team with a focus on its transformation, strategy and financial overview. A live webcast and replay of the meeting will be available on the event page of Dell Technologies’ Investor Relations website at investors.delltechnologies.com.

[0001571996-18-000029:8k_2_02:46]
About Dell Technologies

[0001571996-18-000029:8k_2_02:47]
Dell Technologies is a unique family of businesses that provides the essential infrastructure for organizations to build their digital future, transform IT and protect their most important asset, information. The company services customers of all sizes across 180 countries - ranging from 99 percent of the Fortune 500 to individual consumers - with the industry’s most comprehensive and innovative portfolio from the edge to the core to the cloud.

[0001571996-18-000029:8k_2_02:48]
CONTACTS:

[0001571996-18-000029:8k_2_02:49]
Investor Relations: Investor_Relations@Dell.com

[0001571996-18-000029:8k_2_02:50]
Media Relations: Media.Relations@Dell.com

[0001571996-18-000029:8k_2_02:51]
# # #

[0001571996-18-000029:8k_2_02:52]
Copyright © 2018 Dell Inc. or its subsidiaries. All Rights Reserved. Dell Technologies, Dell, EMC and Dell EMC are trademarks of Dell Inc. or its subsidiaries. Other trademarks may be trademarks of their respective owners.

[0001571996-18-000029:8k_2_02:53]
| 1 | Due to the EMC transaction, significant non-cash bridging items will remain between GAAP and non-GAAP results for the next few years. |

[0001571996-18-000029:8k_2_02:54]
| 2 | Dell Technologies initially funds DFS financing receivables with cash on hand, thereby impacting its cash flow from operations; however, the impact is offset in cash flow from financing when subsequently funded through third-party financing. |

[0001571996-18-000029:8k_2_02:55]
| 3 | Core debt represents the total principal amount of the company’s debt, less unrestricted subsidiary debt, DFS related debt, and other debt. See slide presentation on the FY19Q2 Earnings Event page for full reconciliation of the core debt amount. |

[0001571996-18-000029:8k_2_02:56]
| 4 | IDC WW Quarterly Server Tracker CY18Q2 |

[0001571996-18-000029:8k_2_02:57]
| 5 | IDC WW Quarterly Personal Computing Device (PCD) Tracker CY18Q2 |

[0001571996-18-000029:8k_2_02:58]
| 6 | DisplaySearch Desktop Monitor Market Tracker CY18Q1 |

[0001571996-18-000029:8k_2_02:59]
| 7 | IDC WW Workstation Tracker CY18Q2 |

[0001571996-18-000029:8k_2_02:60]
Non-GAAP Financial Measures:

[0001571996-18-000029:8k_2_02:61]
This press release presents information about Dell Technologies’ non-GAAP net revenue, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, EBITDA and adjusted EBITDA, which are non-GAAP financial measures provided as a supplement to the results provided in accordance with generally accepted accounting principles in the United States of America (“GAAP”). A reconciliation of each historical non-GAAP financial measure to the most directly comparable historical GAAP financial measure is provided in the attached tables for each of the fiscal periods indicated.

[0001571996-18-000029:8k_2_02:62]
No reconciliation of Dell Technologies’ non-GAAP revenue, non-GAAP operating income or non-GAAP net income guidance for fiscal year 2019 to the most comparable GAAP financial measures is included in the attached tables. These non-GAAP financial measures exclude the impact of purchase accounting and in some instances amortization of intangibles, transaction-related expenses, other corporate expenses and adjustments for income taxes. Dell Technologies is not able, without unreasonable efforts, to accurately forecast the excluded items at the level of precision that would be required to be included in the reconciliations.

[0001571996-18-000029:8k_2_02:63]
Special Note on Forward-Looking Statements:

[0001571996-18-000029:8k_2_02:64]
Dell Technologies’ results or events in future periods could differ materially from those expressed or implied by these forward-looking statements because of risks, uncertainties, and other factors that include risks relating to the proposed exchange of shares of Dell Technologies Class V common stock for shares of Class C common stock or, at the holder’s election, cash (the “Class V transaction”), including the failure to consummate or delay in consummating the Class V transaction, including the failure to obtain the requisite stockholder approval or the failure of VMware, Inc. (“VMware”) to pay the special dividend or any inability of Dell Technologies to pay the cash consideration to Class V holders; the risk as to the trading price of Class C common stock to be issued by Dell Technologies in the Class V transaction relative to the trading price of shares of Class V common stock and VMware Class A common stock; the interests of directors and executive officers of Dell Technologies in the Class V transaction that may be different from, or in addition to, the interests of stockholders generally; and other risks discussed in the “Risk Factors” section of the proxy statement/prospectus filed with the Securities and Exchange Commission on August 6, 2018, forming part of Dell Technologies’ Registration Statement on Form S-4. Other risks, uncertainties and factors include competitive pressures; Dell Technologies’ reliance on third-party suppliers for products and components including reliance on single-source or limited-source suppliers; Dell Technologies’ ability to achieve favorable pricing from its vendors; adverse global economic conditions and instability in financial markets; Dell Technologies’ execution of its growth, business and acquisition strategies; the success of Dell Technologies’ cost efficiency measures; Dell Technologies’ ability to manage solutions and products and services transitions in an effective manner; Dell Technologies’ ability to deliver high-quality products and services; Dell Technologies’ foreign operations and ability to generate substantial non-U.S. net revenue; Dell Technologies’ product, customer, and geographic sales mix, and seasonal sales trends; the performance of Dell Technologies’ sales channel partners; access to the capital markets by Dell Technologies or its customers; weak economic conditions and additional regulation; counterparty default risks; the loss by Dell Technologies of any services contracts with its customers, including government contracts, and its ability to perform such contracts at its estimated costs; Dell Technologies’ ability to develop and protect its proprietary intellectual property or obtain licenses to intellectual property developed by others on commercially reasonable and competitive terms; infrastructure disruptions, cyberattacks, or other data security breaches; Dell Technologies’ ability to hedge effectively its exposure to fluctuations in foreign currency exchange rates and interest rates; expiration of tax holidays or favorable tax rate structures, or unfavorable outcomes in tax audits and other tax compliance matters; impairment of portfolio investments; unfavorable results of legal proceedings; increased costs and additional regulations and requirements as a result of Dell Technologies operation as a public company; Dell Technologies’ ability to develop and maintain effective internal control over financial reporting; compliance requirements of changing environmental and safety laws; the effect of armed hostilities, terrorism, natural disasters, and public health issues; Dell Technologies’ substantial level of indebtedness; the impact of the financial performance of VMware; and the market volatility of Dell Technologies’ pension plan assets.

[0001571996-18-000029:8k_2_02:65]
This list of risks, uncertainties, and other factors is not complete. Dell Technologies discusses some of these matters more fully, as well as certain risk factors that could affect Dell Technologies’ business, financial condition, results of operations, and prospects, in its reports filed with the Securities and Exchange Commission, including Dell Technologies’ Annual Report on Form 10-K for the fiscal year ended February 2, 2018, quarterly reports on Form 10-Q, and current reports on Form 8-K. These filings are available for review through the Securities and Exchange Commission’s website at www.sec.gov. Any or all forward-looking statements Dell Technologies makes may turn out to be wrong and can be affected by inaccurate assumptions Dell Technologies might make or by known or unknown risks, uncertainties and other factors, including those identified in this press release. Accordingly, you should not place undue reliance on the forward-looking statements made in this press release, which speak only as of its date. Dell Technologies does not undertake to update, and expressly disclaims any duty to update, its forward-looking statements, whether as a result of circumstances or events that arise after the date they are made, new information, or otherwise.

[0001571996-18-000029:8k_2_02:66]
No Offer or Solicitation:

[0001571996-18-000029:8k_2_02:67]
This communication does not constitute an offer to sell or a solicitation of an offer to sell or a solicitation of an offer to buy any securities or a solicitation of any vote or approval, nor shall there be any sale of securities in any jurisdiction in which such offer, solicitation or sale would be unlawful prior to registration or qualification under the securities laws of any such jurisdiction. No offering of securities shall be made except by means of a prospectus meeting the requirements of Section 10 of the Securities Act of 1933, as amended (the “Securities Act”), and otherwise in accordance with applicable law.

[0001571996-18-000029:8k_2_02:68]
Additional Information and Where to Find It:

[0001571996-18-000029:8k_2_02:69]
This communication is being made in respect of the proposed merger of a wholly-owned subsidiary of Dell Technologies Inc. (“Dell Technologies”) with and into Dell Technologies, with Dell Technologies as the surviving entity, pursuant to which each share of Class V common stock of Dell Technologies will, at the election of the holder, convert into the right to receive shares of Class C common stock of Dell Technologies or cash, without interest, and each existing share of Class A common stock, Class B common stock and Class C common stock of Dell Technologies will be unaffected by the merger and remain outstanding. The proposed transaction requires the approval of a majority of the aggregate voting power of the outstanding shares of Class A common stock, Class B common stock and Class V common stock other than those held by affiliates of Dell Technologies, in each case, voting as a separate class, and all outstanding shares of common stock of Dell Technologies, voting together as a single class, and will be submitted to stockholders for their consideration. Dell Technologies has filed a registration statement on Form S-4 (File No. 333-226618) containing a preliminary proxy statement/prospectus regarding the proposed transaction with the Securities and Exchange Commission (“SEC”). The information in the preliminary proxy statement/prospectus is not complete and may be changed. After the registration statement has been declared effective by the SEC, a definitive proxy statement/prospectus will be mailed to each holder of Class A common stock, Class B common stock, Class C common stock and Class V common stock entitled to vote at the special meeting in connection with the proposed transaction. INVESTORS ARE URGED TO READ THE PROXY STATEMENT/PROSPECTUS AND ANY OTHER DOCUMENTS RELATING TO THE TRANSACTION TO BE FILED WITH THE SEC CAREFULLY AND IN THEIR ENTIRETY IF AND WHEN THEY BECOME AVAILABLE BECAUSE THEY WILL CONTAIN IMPORTANT INFORMATION ABOUT THE PROPOSED TRANSACTION. You may get these documents, when available, for free by visiting EDGAR on the SEC Website at www.sec.gov or by visiting Dell Technologies’ website at http://investors.delltechnologies.com.

[0001571996-18-000029:8k_2_02:70]
Participants in the Solicitation:

[0001571996-18-000029:8k_2_02:71]
Dell Technologies and its directors, executive officers and other members of its management and employees may be deemed to be participants in the solicitation of proxies from its stockholders in favor of the proposed merger and the other transactions contemplated by the merger agreement, including the exchange of shares of Class V common stock of Dell Technologies for shares of Class C common stock of Dell Technologies or cash. Information concerning persons who may be considered participants in such solicitation under the rules of the SEC, including a description of their direct or indirect interests, by security holdings or otherwise, is set forth in the aforementioned preliminary proxy statement/prospectus that has been filed with the SEC.

[0001571996-18-000029:8k_2_02:72]
DELL TECHNOLOGIES INC.

[0001571996-18-000029:8k_2_02:73]
Condensed Consolidated Statements of Income (Loss) and Related Financial Highlights

[0001571996-18-000029:8k_2_02:74]
(in millions, except per share amounts and percentages; unaudited)

[0001571996-18-000029:8k_2_02:75]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | August 3, 2018 |  | August 4, 2017 |  | Change |  | August 3, 2018 |  | August 4, 2017 |  | Change |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Products | $ | 18,149 |  |  | $ | 15,102 |  |  | 20% |  | $ | 34,820 |  |  | $ | 28,736 |  |  | 21% |
| Services | 4,793 |  |  | 4,419 |  |  | 8% |  | 9,478 |  |  | 8,785 |  |  | 8% |
| Total net revenue | 22,942 |  |  | 19,521 |  |  | 18% |  | 44,298 |  |  | 37,521 |  |  | 18% |
| Cost of net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Products | 14,943 |  |  | 12,775 |  |  | 17% |  | 28,549 |  |  | 24,598 |  |  | 16% |
| Services | 1,876 |  |  | 1,778 |  |  | 6% |  | 3,748 |  |  | 3,498 |  |  | 7% |
| Total cost of net revenue | 16,819 |  |  | 14,553 |  |  | 16% |  | 32,297 |  |  | 28,096 |  |  | 15% |
| Gross margin | 6,123 |  |  | 4,968 |  |  | 23% |  | 12,001 |  |  | 9,425 |  |  | 27% |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative | 4,961 |  |  | 4,540 |  |  | 9% |  | 9,905 |  |  | 9,136 |  |  | 8% |
| Research and development | 1,175 |  |  | 1,093 |  |  | 8% |  | 2,262 |  |  | 2,226 |  |  | 2% |
| Total operating expenses | 6,136 |  |  | 5,633 |  |  | 9% |  | 12,167 |  |  | 11,362 |  |  | 7% |
| Operating loss | (13 | ) |  | (665 | ) |  | 98% |  | (166 | ) |  | (1,937 | ) |  | 91% |
| Interest and other, net | (455 | ) |  | (545 | ) |  | 17% |  | (925 | ) |  | (1,117 | ) |  | 17% |
| Loss before income taxes | (468 | ) |  | (1,210 | ) |  | 61% |  | (1,091 | ) |  | (3,054 | ) |  | 64% |
| Income tax benefit | (7 | ) |  | (471 | ) |  | 99% |  | (92 | ) |  | (1,112 | ) |  | 92% |
| Net loss | (461 | ) |  | (739 | ) |  | 38% |  | (999 | ) |  | (1,942 | ) |  | 49% |
| Less: Net income (loss) attributable to non-controlling interests | 38 |  |  | (7 | ) |  | (643)% |  | 136 |  |  | (39 | ) |  | (449)% |
| Net loss attributable to Dell Technologies Inc. | $ | (499 | ) |  | $ | (732 | ) |  | 32% |  | $ | (1,135 | ) |  | $ | (1,903 | ) |  | 40% |
| Earnings (loss) per share attributable to Dell Technologies Inc. - basic: |  |  |  |  |  |  |  |  |  |  |  |
| Class V Common Stock - basic | $ | 1.61 |  |  | $ | 1.00 |  |  |  |  | $ | 3.97 |  |  | $ | 1.60 |  |  |  |
| DHI Group - basic | $ | (1.44 | ) |  | $ | (1.65 | ) |  |  |  | $ | (3.39 | ) |  | $ | (3.94 | ) |  |  |
| Earnings (loss) per share attributable to Dell Technologies Inc. - diluted: |  |  |  |  |  |  |  |  |  |  |  |
| Class V Common Stock - diluted | $ | 1.58 |  |  | $ | 1.00 |  |  |  |  | $ | 3.91 |  |  | $ | 1.59 |  |  |  |
| DHI Group - diluted | $ | (1.45 | ) |  | $ | (1.66 | ) |  |  |  | $ | (3.40 | ) |  | $ | (3.95 | ) |  |  |
| Weighted-average shares outstanding: |  |  |  |  |  |  |  |  |  |  |  |
| Basic - Class V Common Stock | 199 |  |  | 203 |  |  |  |  | 199 |  |  | 205 |  |  |  |
| Diluted - Class V Common Stock | 199 |  |  | 203 |  |  |  |  | 199 |  |  | 205 |  |  |  |
| Basic - DHI Group | 567 |  |  | 566 |  |  |  |  | 568 |  |  | 566 |  |  |  |
| Diluted - DHI Group | 567 |  |  | 566 |  |  |  |  | 568 |  |  | 566 |  |  |  |
| Percentage of Total Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Gross margin | 27 | % |  | 25 | % |  |  |  | 27 | % |  | 25 | % |  |  |
| Selling, general, and administrative | 22 | % |  | 23 | % |  |  |  | 22 | % |  | 24 | % |  |  |
| Research and development | 5 | % |  | 6 | % |  |  |  | 5 | % |  | 6 | % |  |  |
| Operating expenses | 27 | % |  | 29 | % |  |  |  | 28 | % |  | 30 | % |  |  |
| Operating loss | — | % |  | (3 | )% |  |  |  | — | % |  | (5 | )% |  |  |
| Loss before income taxes | (2 | )% |  | (6 | )% |  |  |  | (3 | )% |  | (8 | )% |  |  |
| Net loss | (2 | )% |  | (4 | )% |  |  |  | (2 | )% |  | (5 | )% |  |  |
| Income tax rate | 1.5 | % |  | 38.9 | % |  |  |  | 8.4 | % |  | 36.4 | % |  |  |

[0001571996-18-000029:8k_2_02:76]
DELL TECHNOLOGIES INC.

[0001571996-18-000029:8k_2_02:77]
Condensed Consolidated Statements of Financial Position

[0001571996-18-000029:8k_2_02:78]
(in millions; unaudited)

[0001571996-18-000029:8k_2_02:79]
|  | August 3, 2018 |  | February 2, 2018 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 15,312 |  |  | $ | 13,942 |  |
| Short-term investments | 2,504 |  |  | 2,187 |  |
| Accounts receivable, net | 11,201 |  |  | 11,721 |  |
| Short-term financing receivables, net | 4,140 |  |  | 3,919 |  |
| Inventories, net | 3,642 |  |  | 2,678 |  |
| Other current assets | 6,326 |  |  | 5,881 |  |
| Total current assets | 43,125 |  |  | 40,328 |  |
| Property, plant, and equipment, net | 5,240 |  |  | 5,390 |  |
| Long-term investments | 3,649 |  |  | 4,163 |  |
| Long-term financing receivables, net | 4,030 |  |  | 3,724 |  |
| Goodwill | 39,504 |  |  | 39,920 |  |
| Intangible assets, net | 25,208 |  |  | 28,265 |  |
| Other non-current assets | 2,625 |  |  | 2,403 |  |
| Total assets | $ | 123,381 |  |  | $ | 124,193 |  |
| LIABILITIES, REDEEMABLE SHARES, AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Short-term debt | $ | 9,144 |  |  | $ | 7,873 |  |
| Accounts payable | 20,853 |  |  | 18,334 |  |
| Accrued and other | 7,216 |  |  | 8,026 |  |
| Short-term deferred revenue | 11,965 |  |  | 11,606 |  |
| Total current liabilities | 49,178 |  |  | 45,839 |  |
| Long-term debt | 40,414 |  |  | 43,998 |  |
| Long-term deferred revenue | 9,735 |  |  | 9,210 |  |
| Other non-current liabilities | 6,787 |  |  | 7,277 |  |
| Total liabilities | 106,114 |  |  | 106,324 |  |
| Redeemable shares | 2,056 |  |  | 384 |  |
| Stockholders' equity: |  |  |  |
| Total Dell Technologies Inc. stockholders’ equity | 8,563 |  |  | 11,719 |  |
| Non-controlling interests | 6,648 |  |  | 5,766 |  |
| Total stockholders' equity | 15,211 |  |  | 17,485 |  |
| Total liabilities, redeemable shares, and stockholders' equity | $ | 123,381 |  |  | $ | 124,193 |  |

[0001571996-18-000029:8k_2_02:80]
DELL TECHNOLOGIES INC.

[0001571996-18-000029:8k_2_02:81]
Condensed Consolidated Statements of Cash Flows

[0001571996-18-000029:8k_2_02:82]
(in millions; unaudited)

[0001571996-18-000029:8k_2_02:83]
|  | Three Months Ended |  | Six Months Ended |
|  | August 3, 2018 |  | August 4, 2017 |  | August 3, 2018 |  | August 4, 2017 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |
| Net loss | $ | (461 | ) |  | $ | (739 | ) |  | $ | (999 | ) |  | $ | (1,942 | ) |
| Adjustments to reconcile net loss to net cash provided by operating activities | 3,094 |  |  | 2,559 |  |  | 4,791 |  |  | 4,047 |  |
| Change in cash from operating activities | 2,633 |  |  | 1,820 |  |  | 3,792 |  |  | 2,105 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |
| Investments: |  |  |  |  |  |  |  |
| Purchases | (449 | ) |  | (1,701 | ) |  | (888 | ) |  | (2,260 | ) |
| Maturities and sales | 791 |  |  | 1,085 |  |  | 1,322 |  |  | 2,058 |  |
| Capital expenditures | (288 | ) |  | (316 | ) |  | (561 | ) |  | (561 | ) |
| Proceeds from sale of facilities, land, and other assets | — |  |  | — |  |  | 10 |  |  | — |  |
| Capitalized software development costs | (71 | ) |  | (98 | ) |  | (160 | ) |  | (187 | ) |
| Collections on purchased financing receivables | 7 |  |  | 7 |  |  | 17 |  |  | 10 |  |
| Acquisition of businesses, net | — |  |  | (211 | ) |  | — |  |  | (223 | ) |
| Divestitures of businesses, net | — |  |  | 20 |  |  | 142 |  |  | — |  |
| Asset acquisitions, net | — |  |  | (86 | ) |  | (38 | ) |  | (86 | ) |
| Asset dispositions, net | (3 | ) |  | (41 | ) |  | (6 | ) |  | (41 | ) |
| Change in cash from investing activities | (13 | ) |  | (1,341 | ) |  | (162 | ) |  | (1,290 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |
| Payment of dissenting shares obligation | (76 | ) |  | — |  |  | (76 | ) |  | — |  |
| Share repurchases for tax withholdings of equity awards | (99 | ) |  | (68 | ) |  | (199 | ) |  | (194 | ) |
| Proceeds from the issuance of common stock of subsidiaries | 11 |  |  | 72 |  |  | 653 |  |  | 80 |  |
| Repurchases of DHI Group Common Stock | (10 | ) |  | — |  |  | (47 | ) |  | (2 | ) |
| Repurchases of Class V Common Stock | — |  |  | (54 | ) |  | — |  |  | (422 | ) |
| Payments for debt issuance costs | (5 | ) |  | — |  |  | (8 | ) |  | (5 | ) |
| Proceeds from debt | 2,774 |  |  | 1,335 |  |  | 4,637 |  |  | 4,756 |  |
| Repayments of debt | (5,126 | ) |  | (2,175 | ) |  | (6,948 | ) |  | (5,291 | ) |
| Other | 1 |  |  | — |  |  | 1 |  |  | 1 |  |
| Change in cash from financing activities | (2,530 | ) |  | (890 | ) |  | (1,987 | ) |  | (1,077 | ) |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash | (130 | ) |  | 54 |  |  | (216 | ) |  | 48 |  |
| Change in cash, cash equivalents, and restricted cash | (40 | ) |  | (357 | ) |  | 1,427 |  |  | (214 | ) |
| Cash, cash equivalents, and restricted cash at beginning of the period | 15,845 |  |  | 9,975 |  |  | 14,378 |  |  | 9,832 |  |
| Cash, cash equivalents, and restricted cash at end of the period | $ | 15,805 |  |  | $ | 9,618 |  |  | $ | 15,805 |  |  | $ | 9,618 |  |

[0001571996-18-000029:8k_2_02:84]
DELL TECHNOLOGIES INC.

[0001571996-18-000029:8k_2_02:85]
Segment Information

[0001571996-18-000029:8k_2_02:86]
(in millions, except percentages; unaudited; continued on next page)

[0001571996-18-000029:8k_2_02:87]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | August 3, 2018 |  | August 4, 2017 |  | Change |  | August 3, 2018 |  | August 4, 2017 |  | Change |
| Infrastructure Solutions Group (ISG): |  |  |  |  |  |  |  |  |  |  |  |
| Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Servers and networking | $ | 5,061 |  |  | $ | 3,777 |  |  | 34% |  | $ | 9,646 |  |  | $ | 7,033 |  |  | 37% |
| Storage | 4,166 |  |  | 3,690 |  |  | 13% |  | 8,248 |  |  | 7,395 |  |  | 12% |
| Total ISG net revenue | $ | 9,227 |  |  | $ | 7,467 |  |  | 24% |  | $ | 17,894 |  |  | $ | 14,428 |  |  | 24% |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| ISG operating income | $ | 1,012 |  |  | $ | 647 |  |  | 56% |  | $ | 1,951 |  |  | $ | 1,153 |  |  | 69% |
| % of ISG net revenue | 11 | % |  | 9 | % |  |  |  | 11 | % |  | 8 | % |  |  |
| % of total segment operating income | 47 | % |  | 34 | % |  |  |  | 46 | % |  | 34 | % |  |  |
| Client Solutions Group (CSG): |  |  |  |  |  |  |  |  |  |  |  |
| Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 8,109 |  |  | $ | 7,207 |  |  | 13% |  | $ | 15,472 |  |  | $ | 13,549 |  |  | 14% |
| Consumer | 3,019 |  |  | 2,659 |  |  | 14% |  | 5,927 |  |  | 5,365 |  |  | 10% |
| Total CSG net revenue | $ | 11,128 |  |  | $ | 9,866 |  |  | 13% |  | $ | 21,399 |  |  | $ | 18,914 |  |  | 13% |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| CSG operating income | $ | 425 |  |  | $ | 528 |  |  | (20)% |  | $ | 958 |  |  | $ | 853 |  |  | 12% |
| % of CSG net revenue | 4 | % |  | 5 | % |  |  |  | 4 | % |  | 5 | % |  |  |
| % of total segment operating income | 20 | % |  | 28 | % |  |  |  | 22 | % |  | 26 | % |  |  |
| VMware: |  |  |  |  |  |  |  |  |  |  |  |
| Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Total VMware net revenue | $ | 2,194 |  |  | $ | 1,984 |  |  | 11% |  | $ | 4,222 |  |  | $ | 3,802 |  |  | 11% |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| VMware operating income | $ | 736 |  |  | $ | 728 |  |  | 1% |  | $ | 1,349 |  |  | $ | 1,339 |  |  | 1% |
| % of VMware net revenue | 34 | % |  | 37 | % |  |  |  | 32 | % |  | 35 | % |  |  |
| % of total segment operating income | 34 | % |  | 38 | % |  |  |  | 32 | % |  | 40 | % |  |  |

[0001571996-18-000029:8k_2_02:88]
DELL TECHNOLOGIES INC.

[0001571996-18-000029:8k_2_02:89]
Segment Information

[0001571996-18-000029:8k_2_02:90]
(in millions, except percentages; unaudited; continued)

[0001571996-18-000029:8k_2_02:91]
|  | Three Months Ended |  | Six Months Ended |
|  | August 3, 2018 |  | August 4, 2017 |  | August 3, 2018 |  | August 4, 2017 |
| Reconciliation to consolidated net revenue: |  |  |  |  |  |  |
| Reportable segment net revenue | $ | 22,549 |  |  | $ | 19,317 |  |  | $ | 43,515 |  |  | $ | 37,144 |  |
| Other businesses (a) | 574 |  |  | 543 |  |  | 1,153 |  |  | 1,072 |  |
| Unallocated transactions (b) | (1 | ) |  | (4 | ) |  | (3 | ) |  | (5 | ) |
| Impact of purchase accounting (c) | (180 | ) |  | (335 | ) |  | (367 | ) |  | (690 | ) |
| Total net revenue | $ | 22,942 |  |  | $ | 19,521 |  |  | $ | 44,298 |  |  | $ | 37,521 |  |
| Reconciliation to consolidated operating income (loss): |  |  |  |  |
| Reportable segment operating income | $ | 2,173 |  |  | $ | 1,903 |  |  | $ | 4,258 |  |  | $ | 3,345 |  |
| Other businesses (a) | (49 | ) |  | (29 | ) |  | (99 | ) |  | (52 | ) |
| Unallocated transactions (b) | (16 | ) |  | (8 | ) |  | (25 | ) |  | (2 | ) |
| Impact of purchase accounting (c) | (215 | ) |  | (406 | ) |  | (437 | ) |  | (829 | ) |
| Amortization of intangibles | (1,526 | ) |  | (1,740 | ) |  | (3,048 | ) |  | (3,516 | ) |
| Transaction-related expenses (d) | (104 | ) |  | (138 | ) |  | (270 | ) |  | (329 | ) |
| Other corporate expenses (e) | (276 | ) |  | (247 | ) |  | (545 | ) |  | (554 | ) |
| Total operating loss | $ | (13 | ) |  | $ | (665 | ) |  | $ | (166 | ) |  | $ | (1,937 | ) |

[0001571996-18-000029:8k_2_02:92]
_________________

[0001571996-18-000029:8k_2_02:93]
| (a) | Pivotal, SecureWorks, RSA Security, Virtustream, and Boomi constitute "Other businesses" and do not meet the requirements for a reportable segment, either individually or collectively. The results of Other businesses are not material to the Company's overall results. |

[0001571996-18-000029:8k_2_02:94]
| (b) | Unallocated transactions includes long-term incentives, certain short-term incentive compensation expenses, and other corporate items that are not allocated to Dell Technologies' reportable segments. |

[0001571996-18-000029:8k_2_02:95]
| (c) | Impact of purchase accounting includes non-cash purchase accounting adjustments that are primarily related to the EMC merger transaction. |

[0001571996-18-000029:8k_2_02:96]
| (d) | Transaction-related expenses includes acquisition, integration, and divestiture related costs. |

[0001571996-18-000029:8k_2_02:97]
| (e) | Other corporate expenses includes severance and facility action costs as well as stock-based compensation expense. |

[0001571996-18-000029:8k_2_02:98]
SUPPLEMENTAL SELECTED NON-GAAP FINANCIAL MEASURES

[0001571996-18-000029:8k_2_02:99]
These tables present information about the Company’s non-GAAP net revenue, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, EBITDA, and adjusted EBITDA, which are non-GAAP financial measures provided as a supplement to the results provided in accordance with generally accepted accounting principles in the United States of America (“GAAP”).  A detailed discussion of Dell Technologies’ reasons for including these non-GAAP financial measures, the limitations associated with these measures, the items excluded from these measures, and our reason for excluding those items are presented in “Management’s Discussion and Analysis of Financial Condition and Results of Operations - Non-GAAP Financial Measures” in our periodic reports filed with the SEC.  Dell Technologies encourages investors to review the non-GAAP discussion in conjunction with the presentation of non-GAAP financial measures.

[0001571996-18-000029:8k_2_02:100]
DELL TECHNOLOGIES INC.

[0001571996-18-000029:8k_2_02:101]
Selected Non-GAAP Financial Measures

[0001571996-18-000029:8k_2_02:102]
(in millions, except percentages; unaudited)

[0001571996-18-000029:8k_2_02:103]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | August 3, 2018 |  | August 4, 2017 |  | Change |  | August 3, 2018 |  | August 4, 2017 |  | Change |
| Non-GAAP net revenue | $ | 23,122 |  |  | $ | 19,856 |  |  | 16% |  | $ | 44,665 |  |  | $ | 38,211 |  |  | 17% |
| Non-GAAP gross margin | $ | 7,066 |  |  | $ | 6,259 |  |  | 13% |  | $ | 13,985 |  |  | $ | 12,060 |  |  | 16% |
| % of non-GAAP net revenue | 31 | % |  | 32 | % |  |  |  | 31 | % |  | 32 | % |  |  |
| Non-GAAP operating expenses | $ | 4,958 |  |  | $ | 4,393 |  |  | 13% |  | $ | 9,851 |  |  | $ | 8,769 |  |  | 12% |
| % of non-GAAP net revenue | 21 | % |  | 22 | % |  |  |  | 22 | % |  | 23 | % |  |  |
| Non-GAAP operating income | $ | 2,108 |  |  | $ | 1,866 |  |  | 13% |  | $ | 4,134 |  |  | $ | 3,291 |  |  | 26% |
| % of non-GAAP net revenue | 9 | % |  | 9 | % |  |  |  | 9 | % |  | 9 | % |  |  |
| Non-GAAP net income | $ | 1,349 |  |  | $ | 1,112 |  |  | 21% |  | $ | 2,523 |  |  | $ | 1,873 |  |  | 35% |
| % of non-GAAP net revenue | 6 | % |  | 6 | % |  |  |  | 6 | % |  | 5 | % |  |  |
| Adjusted EBITDA | $ | 2,459 |  |  | $ | 2,180 |  |  | 13% |  | $ | 4,842 |  |  | $ | 3,975 |  |  | 22% |
| % of non-GAAP net revenue | 11 | % |  | 11 | % |  |  |  | 11 | % |  | 10 | % |  |  |

[0001571996-18-000029:8k_2_02:104]
DELL TECHNOLOGIES INC.

[0001571996-18-000029:8k_2_02:105]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-18-000029:8k_2_02:106]
(in millions, except percentages; unaudited; continued on next page)

[0001571996-18-000029:8k_2_02:107]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | August 3, 2018 |  | August 4, 2017 |  | Change |  | August 3, 2018 |  | August 4, 2017 |  | Change |
| Net revenue | $ | 22,942 |  |  | $ | 19,521 |  |  | 18% |  | $ | 44,298 |  |  | $ | 37,521 |  |  | 18% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 180 |  |  | 335 |  |  |  |  | 367 |  |  | 690 |  |  |  |
| Non-GAAP net revenue | $ | 23,122 |  |  | $ | 19,856 |  |  | 16% |  | $ | 44,665 |  |  | $ | 38,211 |  |  | 17% |
| Gross margin | $ | 6,123 |  |  | $ | 4,968 |  |  | 23% |  | $ | 12,001 |  |  | $ | 9,425 |  |  | 27% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 718 |  |  | 920 |  |  |  |  | 1,428 |  |  | 1,870 |  |  |  |
| Impact of purchase accounting | 185 |  |  | 348 |  |  |  |  | 378 |  |  | 713 |  |  |  |
| Transaction-related expenses | 21 |  |  | 10 |  |  |  |  | 137 |  |  | 17 |  |  |  |
| Other corporate expenses | 19 |  |  | 13 |  |  |  |  | 41 |  |  | 35 |  |  |  |
| Non-GAAP gross margin | $ | 7,066 |  |  | $ | 6,259 |  |  | 13% |  | $ | 13,985 |  |  | $ | 12,060 |  |  | 16% |
| Operating expenses | $ | 6,136 |  |  | $ | 5,633 |  |  | 9% |  | $ | 12,167 |  |  | $ | 11,362 |  |  | 7% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | (808 | ) |  | (820 | ) |  |  |  | (1,620 | ) |  | (1,646 | ) |  |  |
| Impact of purchase accounting | (30 | ) |  | (58 | ) |  |  |  | (59 | ) |  | (116 | ) |  |  |
| Transaction-related expenses | (83 | ) |  | (128 | ) |  |  |  | (133 | ) |  | (312 | ) |  |  |
| Other corporate expenses | (257 | ) |  | (234 | ) |  |  |  | (504 | ) |  | (519 | ) |  |  |
| Non-GAAP operating expenses | $ | 4,958 |  |  | $ | 4,393 |  |  | 13% |  | $ | 9,851 |  |  | $ | 8,769 |  |  | 12% |
| Operating loss | $ | (13 | ) |  | $ | (665 | ) |  | 98% |  | $ | (166 | ) |  | $ | (1,937 | ) |  | 91% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 1,526 |  |  | 1,740 |  |  |  |  | 3,048 |  |  | 3,516 |  |  |  |
| Impact of purchase accounting | 215 |  |  | 406 |  |  |  |  | 437 |  |  | 829 |  |  |  |
| Transaction-related expenses | 104 |  |  | 138 |  |  |  |  | 270 |  |  | 329 |  |  |  |
| Other corporate expenses | 276 |  |  | 247 |  |  |  |  | 545 |  |  | 554 |  |  |  |
| Non-GAAP operating income | $ | 2,108 |  |  | $ | 1,866 |  |  | 13% |  | $ | 4,134 |  |  | $ | 3,291 |  |  | 26% |
| Net loss | $ | (461 | ) |  | $ | (739 | ) |  | 38% |  | $ | (999 | ) |  | $ | (1,942 | ) |  | 49% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 1,526 |  |  | 1,740 |  |  |  |  | 3,048 |  |  | 3,516 |  |  |  |
| Impact of purchase accounting | 215 |  |  | 406 |  |  |  |  | 437 |  |  | 829 |  |  |  |
| Transaction-related expenses | 104 |  |  | 138 |  |  |  |  | 270 |  |  | 329 |  |  |  |
| Other corporate expenses | 276 |  |  | 247 |  |  |  |  | 545 |  |  | 554 |  |  |  |
| Aggregate adjustment for income taxes | (311 | ) |  | (680 | ) |  |  |  | (778 | ) |  | (1,413 | ) |  |  |
| Non-GAAP net income | $ | 1,349 |  |  | $ | 1,112 |  |  | 21% |  | $ | 2,523 |  |  | $ | 1,873 |  |  | 35% |

[0001571996-18-000029:8k_2_02:108]
DELL TECHNOLOGIES INC.

[0001571996-18-000029:8k_2_02:109]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-18-000029:8k_2_02:110]
(in millions, except percentages; unaudited; continued)

[0001571996-18-000029:8k_2_02:111]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | August 3, 2018 |  | August 4, 2017 |  | Change |  | August 3, 2018 |  | August 4, 2017 |  | Change |
| Net loss | $ | (461 | ) |  | $ | (739 | ) |  | 38% |  | $ | (999 | ) |  | $ | (1,942 | ) |  | 49% |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Interest and other, net | 455 |  |  | 545 |  |  |  |  | 925 |  |  | 1,117 |  |  |  |
| Income tax benefit | (7 | ) |  | (471 | ) |  |  |  | (92 | ) |  | (1,112 | ) |  |  |
| Depreciation and amortization | 1,931 |  |  | 2,142 |  |  |  |  | 3,845 |  |  | 4,354 |  |  |  |
| EBITDA | $ | 1,918 |  |  | $ | 1,477 |  |  | 30% |  | $ | 3,679 |  |  | $ | 2,417 |  |  | 52% |
| EBITDA | $ | 1,918 |  |  | $ | 1,477 |  |  | 30% |  | $ | 3,679 |  |  | $ | 2,417 |  |  | 52% |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense | 216 |  |  | 208 |  |  |  |  | 415 |  |  | 409 |  |  |  |
| Impact of purchase accounting | 145 |  |  | 335 |  |  |  |  | 367 |  |  | 692 |  |  |  |
| Transaction-related expenses | 85 |  |  | 138 |  |  |  |  | 251 |  |  | 329 |  |  |  |
| Other corporate expenses | 95 |  |  | 22 |  |  |  |  | 130 |  |  | 128 |  |  |  |
| Adjusted EBITDA | $ | 2,459 |  |  | $ | 2,180 |  |  | 13% |  | $ | 4,842 |  |  | $ | 3,975 |  |  | 22% |
