# DELL 8-K — 0001571996-24-000081 filed 2024-08-29

## item codes, every 8-K on or before 2024-09-10

- 2024-08-29 0001571996-24-000081 — 2.02, 9.01
- 2024-07-12 0001193125-24-178608 — 3.02
- 2024-07-02 0001571996-24-000074 — 5.07
- 2024-06-10 0001571996-24-000059 — 3.02
- 2024-05-30 0001571996-24-000050 — 2.02, 9.01
- 2024-03-26 0001571996-24-000038 — 3.02
- 2024-03-18 0001193125-24-070193 — 1.01, 2.03, 9.01
- 2024-03-07 0001571996-24-000012 — 3.02
- 2024-03-06 0001193125-24-059631 — 8.01, 9.01
- 2024-02-29 0001571996-24-000008 — 2.02, 9.01
- 2024-01-30 0001571996-24-000004 — 1.02
- 2024-01-18 0001571996-24-000002 — 3.02
- 2023-12-18 0001193125-23-297664 — 8.01, 9.01
- 2023-12-05 0001571996-23-000042 — 3.02
- 2023-12-04 0001193125-23-288428 — 8.01, 9.01
- 2023-11-30 0001571996-23-000039 — 2.02, 9.01
- 2023-10-05 0001193125-23-251131 — 7.01, 8.01, 9.01
- 2023-10-02 0001571996-23-000036 — 5.02 — amendment of 0001571996-23-000034
- 2023-09-26 0001571996-23-000034 — 5.02
- 2023-08-31 0001571996-23-000029 — 2.02, 9.01
- 2023-08-09 0001571996-23-000026 — 5.02 — amendment of 0001571996-23-000002
- 2023-07-28 0001571996-23-000024 — 5.02
- 2023-07-13 0001193125-23-186639 — 3.02
- 2023-06-30 0001193125-23-180570 — 8.01, 9.01
- 2023-06-22 0001571996-23-000021 — 5.02, 5.07, 9.01
- 2023-06-15 0001193125-23-167472 — 8.01, 9.01
- 2023-06-01 0001571996-23-000014 — 2.02, 9.01
- 2023-03-02 0001571996-23-000002 — 2.02, 5.02, 9.01
- 2023-02-06 0001193125-23-024781 — 7.01, 9.01
- 2023-01-24 0001193125-23-014260 — 1.01, 2.03, 9.01
- 2023-01-11 0001193125-23-006528 — 8.01, 9.01
- 2022-11-21 0001571996-22-000041 — 2.02, 9.01
- 2022-11-16 0001571996-22-000038 — 8.01
- 2022-08-25 0001571996-22-000028 — 2.02, 9.01
- 2022-07-18 0001193125-22-196334 — 2.03, 8.01
- 2022-06-29 0001571996-22-000025 — 3.03, 5.03, 5.07, 8.01, 9.01
- 2022-05-26 0001571996-22-000013 — 2.02, 9.01
- 2022-02-24 0001571996-22-000004 — 2.02, 8.01, 9.01
- 2021-12-20 0001193125-21-362482 — 8.01, 9.01
- 2021-12-15 0001193125-21-357927 — 1.01, 2.03, 9.01
- 2021-12-07 0001193125-21-349218 — 8.01, 9.01
- 2021-11-23 0001571996-21-000060 — 2.02, 9.01
- 2021-11-05 0001571996-21-000057 — 1.02, 2.01, 7.01, 8.01, 9.01 — amendment, the index does not say of what
- 2021-11-01 0001571996-21-000052 — 8.01, 9.01
- 2021-11-01 0001193125-21-315488 — 1.01, 1.02, 2.01, 8.01, 9.01
- 2021-10-21 0001193125-21-304052 — 8.01, 9.01
- 2021-10-19 0001571996-21-000050 — 8.01, 9.01
- 2021-10-07 0001193125-21-294210 — 8.01, 9.01
- 2021-09-30 0001571996-21-000047 — 5.02
- 2021-09-27 0001571996-21-000045 — 8.01
- 2021-09-23 0001193125-21-280190 — 7.01, 8.01, 9.01
- 2021-09-20 0001193125-21-276810 — 7.01, 9.01
- 2021-08-26 0001571996-21-000037 — 2.02, 9.01
- 2021-07-01 0001571996-21-000034 — 3.02
- 2021-06-24 0001571996-21-000031 — 5.07
- 2021-06-24 0001193125-21-197644 — 7.01, 9.01
- 2021-06-16 0001571996-21-000029 — 5.02
- 2021-05-27 0001571996-21-000019 — 2.02, 9.01
- 2021-05-03 0001571996-21-000010 — 8.01, 9.01
- 2021-04-14 0001193125-21-116271 — 1.01, 7.01, 9.01
- 2021-02-25 0001571996-21-000003 — 2.02, 9.01
- 2021-02-18 0001193125-21-047844 — 1.01, 2.03, 9.01
- 2020-11-24 0001571996-20-000048 — 2.02, 9.01
- 2020-08-27 0001571996-20-000041 — 2.02, 9.01
- 2020-07-02 0001571996-20-000037 — 5.07
- 2020-05-28 0001571996-20-000028 — 2.02, 9.01
- 2020-04-09 0001193125-20-102602 — 1.01, 2.03, 9.01
- 2020-04-08 0001571996-20-000021 — 5.02
- 2020-04-03 0001571996-20-000019 — 8.01, 9.01
- 2020-03-26 0001571996-20-000015 — 7.01
- 2020-02-27 0001571996-20-000009 — 2.02, 8.01, 9.01
- 2020-02-18 0001571996-20-000005 — 8.01, 9.01
- 2020-01-09 0001571996-20-000002 — 3.02
- 2020-01-06 0001193125-20-002200 — 3.02
- 2019-12-13 0001193125-19-313947 — 3.02
- 2019-12-10 0001571996-19-000052 — 5.02
- 2019-12-02 0001571996-19-000044 — 5.02, 7.01, 9.01
- 2019-11-26 0001571996-19-000042 — 2.02, 9.01
- 2019-09-23 0001193125-19-252192 — 1.01, 2.03, 9.01
- 2019-08-29 0001571996-19-000036 — 2.02, 9.01
- 2019-08-22 0001193125-19-226939 — 7.01, 8.01, 9.01
- 2019-07-11 0001571996-19-000032 — 5.02, 5.07, 9.01
- 2019-07-03 0001571996-19-000030 — 3.02
- 2019-06-27 0001571996-19-000028 — 3.02
- 2019-05-30 0001571996-19-000021 — 2.02, 9.01
- 2019-04-02 0001571996-19-000010 — 5.02
- 2019-03-21 0001193125-19-082281 — 1.01, 1.02, 2.03, 9.01
- 2019-03-19 0001571996-19-000005 — 5.02, 9.01
- 2019-03-14 0001193125-19-074935 — 1.01, 2.03, 9.01
- 2019-03-07 0001193125-19-066045 — 8.01, 9.01
- 2019-02-28 0001571996-19-000002 — 2.02, 9.01
- 2018-12-28 0001193125-18-360943 — 1.01, 1.02, 3.01, 3.03, 5.02, 5.03, 7.01, 8.01, 9.01
- 2018-12-21 0001193125-18-356324 — 1.01, 2.03, 9.01
- 2018-12-14 0001193125-18-349469 — 8.01
- 2018-12-11 0001193125-18-346958 — 5.07, 8.01, 9.01
- 2018-11-29 0001571996-18-000041 — 2.02, 9.01
- 2018-11-28 0001571996-18-000037 — 7.01, 8.01, 9.01
- 2018-11-26 0001193125-18-333967 — 8.01, 9.01
- 2018-11-15 0001193125-18-328110 — 1.01, 9.01 — amendment of 0001193125-18-327222
- 2018-11-15 0001193125-18-327222 — 1.01, 7.01, 9.01
- 2018-10-03 0001193125-18-291390 — 8.01
- 2018-09-06 0001571996-18-000029 — 2.02, 9.01
- 2018-08-06 0001571996-18-000027 — 8.01, 9.01
- 2018-07-02 0001193125-18-210339 — 1.01, 7.01, 9.01
- 2018-06-28 0001571996-18-000024 — 5.07
- 2018-06-04 0001571996-18-000019 — 2.02, 9.01
- 2018-05-17 0001571996-18-000016 — 7.01
- 2018-04-26 0001571996-18-000009 — 7.01, 9.01
- 2018-03-08 0001193125-18-074168 — 2.02, 9.01
- 2018-02-02 0001193125-18-029947 — 7.01, 9.01
- 2017-12-07 0001571996-17-000042 — 2.02, 9.01
- 2017-10-24 0001571996-17-000037 — 1.01, 2.03, 9.01
- 2017-09-15 0001571996-17-000027 — 5.02
- 2017-09-07 0001571996-17-000017 — 2.02, 9.01
- 2017-08-24 0001571996-17-000014 — 8.01
- 2017-06-29 0001571996-17-000011 — 3.03, 5.07, 8.01, 9.01
- 2017-06-08 0001193125-17-197638 — 2.02, 9.01
- 2017-03-30 0001193125-17-102794 — 8.01
- 2017-03-30 0001193125-17-102777 — 2.02, 9.01
- 2017-03-09 0001193125-17-076981 — 1.01, 2.03, 9.01
- 2017-01-17 0001193125-17-011125 — 8.01
- 2016-12-15 0001193125-16-793722 — 8.01
- 2016-12-08 0001193125-16-787976 — 2.02, 9.01
- 2016-11-10 0001193125-16-765964 — 1.02, 8.01
- 2016-11-04 0001193125-16-760249 — 8.01
- 2016-09-13 0001193125-16-708600 — 3.02
- 2016-09-09 0001193125-16-706567 — 1.01, 1.02, 2.01, 2.03, 3.02, 3.03, 5.02, 9.01
- 2016-09-07 0001193125-16-703370 — 3.03, 5.07, 7.01, 8.01, 9.01
- 2016-09-06 0001193125-16-702057 — 2.02, 9.01
- 2016-08-31 0001193125-16-697268 — 8.01, 9.01
- 2016-08-26 0001193125-16-692921 — 8.01, 9.01
- 2016-07-11 0001193125-16-645610 — 8.01
- 2016-07-05 0001193125-16-641679 — 8.01
- 2016-06-22 0001193125-16-629055 — 1.01, 2.03, 8.01, 9.01
- 2016-06-21 0001193125-16-627071 — 8.01, 9.01
- 2016-06-10 0001193125-16-618483 — 2.02, 9.01
- 2016-06-09 0001193125-16-617893 — 8.01, 9.01

## late-filing notifications on or before 2024-09-10

- none on or before 2024-09-10

## item 2.02 — earnings release, exhibit 99.1

[0001571996-24-000081:8k_2_02:1]
EX-99.1
2
exhibit991earnings8kq2fy25.htm
EX-99.1

[0001571996-24-000081:8k_2_02:2]
Document

[0001571996-24-000081:8k_2_02:3]
Exhibit 99.1

[0001571996-24-000081:8k_2_02:4]
Dell Technologies Delivers Second Quarter Fiscal 2025 Financial Results

[0001571996-24-000081:8k_2_02:5]
News summary

[0001571996-24-000081:8k_2_02:6]
•Second quarter revenue of $25.0 billion, up 9% year over year

[0001571996-24-000081:8k_2_02:7]
•Record Infrastructure Solutions Group (ISG) revenue of $11.6 billion, up 38% year over year, with record servers and networking revenue of $7.7 billion, up 80%

[0001571996-24-000081:8k_2_02:8]
•Client Solutions Group (CSG) revenue of $12.4 billion, down 4% year over year, with commercial client revenue flat at $10.6 billion

[0001571996-24-000081:8k_2_02:9]
•Diluted earnings per share of $1.17, up 86% year over year, and non-GAAP diluted earnings per share of $1.89, up 9%

[0001571996-24-000081:8k_2_02:10]
ROUND ROCK, Texas — August 29, 2024

[0001571996-24-000081:8k_2_02:11]
Full story

[0001571996-24-000081:8k_2_02:12]
Dell Technologies (NYSE: DELL) announces financial results for its fiscal 2025 second quarter. Revenue was $25.0 billion, up 9% year over year. Operating income was $1.3 billion and non-GAAP operating income was $2.0 billion, up 15% and 3% year over year, respectively. Diluted earnings per share was $1.17, and non-GAAP diluted earnings per share was $1.89, up 86% and 9% year over year, respectively.

[0001571996-24-000081:8k_2_02:13]
“In Q2 our combined ISG and CSG revenue was $24.1 billion, up 12% year over year, positioning us well for the second half of the year and beyond,” said Yvonne McGill, chief financial officer, Dell Technologies. “Our momentum in ISG is a significant tailwind, with record ISG revenue of $11.6 billion, up 38% year over year.”

[0001571996-24-000081:8k_2_02:14]
Cash flow from operations was $1.3 billion. Dell returned $1 billion to shareholders through share repurchases and dividends and ended the quarter with $6.0 billion in cash and investments.

[0001571996-24-000081:8k_2_02:15]
1

[0001571996-24-000081:8k_2_02:16]
Second Quarter Fiscal 2025 Financial Results

[0001571996-24-000081:8k_2_02:17]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | August 2, 2024 |  | August 4, 2023 |  | Change |  | August 2, 2024 |  | August 4, 2023 |  | Change |
|  | (in millions, except per share amounts and percentages; unaudited) |
| Net revenue | $ | 25,026 |  |  | $ | 22,934 |  |  | 9% |  | $ | 47,270 |  |  | $ | 43,856 |  |  | 8% |
| Operating income | $ | 1,342 |  |  | $ | 1,165 |  |  | 15% |  | $ | 2,262 |  |  | $ | 2,234 |  |  | 1% |
| Net income | $ | 841 |  |  | $ | 455 |  |  | 85% |  | $ | 1,796 |  |  | $ | 1,033 |  |  | 74% |
| Change in cash from operating activities | $ | 1,340 |  |  | $ | 3,214 |  |  | (58)% |  | $ | 2,383 |  |  | $ | 4,991 |  |  | (52)% |
| Earnings per share - diluted | $ | 1.17 |  |  | $ | 0.63 |  |  | 86% |  | $ | 2.49 |  |  | $ | 1.42 |  |  | 75% |
| Non-GAAP operating income | $ | 2,034 |  |  | $ | 1,977 |  |  | 3% |  | $ | 3,508 |  |  | $ | 3,575 |  |  | (2)% |
| Non-GAAP net income | $ | 1,371 |  |  | $ | 1,283 |  |  | 7% |  | $ | 2,294 |  |  | $ | 2,246 |  |  | 2% |
| Adjusted free cash flow | $ | 1,284 |  |  | $ | 3,050 |  |  | (58)% |  | $ | 1,907 |  |  | $ | 3,737 |  |  | (49)% |
| Non-GAAP earnings per share - diluted | $ | 1.89 |  |  | $ | 1.74 |  |  | 9% |  | $ | 3.16 |  |  | $ | 3.05 |  |  | 4% |

[0001571996-24-000081:8k_2_02:18]
Information about Dell Technologies’ use of non-GAAP financial information is provided under “Non-GAAP Financial Measures” below. All comparisons in this press release are year-over-year unless otherwise noted.

[0001571996-24-000081:8k_2_02:19]
Infrastructure Solutions Group (ISG) delivered record second quarter revenue of $11.6 billion, up 38% year over year. Servers and networking revenue was a record $7.7 billion, up 80%, with demand growth across AI and traditional servers. Storage revenue was $4.0 billion, down 5%. Operating income was $1.3 billion.

[0001571996-24-000081:8k_2_02:20]
“Our AI momentum accelerated in Q2, and we’ve seen an increase in the number of enterprise customers buying AI solutions each quarter,” said Jeff Clarke, vice chairman and chief operating officer, Dell Technologies. “AI-optimized server demand was $3.2 billion, up 23% sequentially, and $5.8 billion year to date. Backlog was $3.8 billion, and our pipeline has grown to several multiples of our backlog.”

[0001571996-24-000081:8k_2_02:21]
Client Solutions Group (CSG) delivered second quarter revenue of $12.4 billion, down 4% year over year. Commercial client revenue was flat at $10.6 billion, and Consumer revenue was $1.9 billion, down 22%. Operating income was $767 million.

[0001571996-24-000081:8k_2_02:22]
2

[0001571996-24-000081:8k_2_02:23]
Operating Segments Results

[0001571996-24-000081:8k_2_02:24]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | August 2, 2024 |  | August 4, 2023 |  | Change |  | August 2, 2024 |  | August 4, 2023 |  | Change |
|  | (in millions, except percentages; unaudited) |
| Infrastructure Solutions Group (ISG): |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Servers and networking | $ | 7,672 |  | $ | 4,274 |  |  | 80% |  | $ | 13,138 |  |  | $ | 8,111 |  |  | 62% |
| Storage | 3,974 |  |  | 4,187 |  |  | (5)% |  | 7,735 |  |  | 7,943 |  |  | (3)% |
| Total ISG net revenue | $ | 11,646 |  |  | $ | 8,461 |  |  | 38% |  | $ | 20,873 |  |  | $ | 16,054 |  |  | 30% |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| ISG operating income | $ | 1,284 |  |  | $ | 1,049 |  |  | 22% |  | $ | 2,020 |  |  | $ | 1,789 |  |  | 13% |
| % of ISG net revenue | 11.0 | % |  | 12.4 | % |  |  |  | 9.7 | % |  | 11.1 | % |  |  |
| % of total reportable segment operating income | 63 | % |  | 52 | % |  |  |  | 57 | % |  | 49 | % |  |  |
| Client Solutions Group (CSG): |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 10,556 |  |  | $ | 10,554 |  |  | —% |  | $ | 20,710 |  |  | $ | 20,416 |  |  | 1% |
| Consumer | 1,858 |  |  | 2,388 |  |  | (22)% |  | 3,671 |  |  | 4,509 |  |  | (19)% |
| Total CSG net revenue | $ | 12,414 |  |  | $ | 12,942 |  |  | (4)% |  | $ | 24,381 |  |  | $ | 24,925 |  |  | (2)% |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| CSG operating income | $ | 767 |  |  | $ | 969 |  |  | (21)% |  | $ | 1,499 |  |  | $ | 1,861 |  |  | (19)% |
| % of CSG net revenue | 6.2 | % |  | 7.5 | % |  |  |  | 6.1 | % |  | 7.5 | % |  |  |
| % of total reportable segment operating income | 37 | % |  | 48 | % |  |  |  | 43 | % |  | 51 | % |  |  |

[0001571996-24-000081:8k_2_02:25]
Conference call information

[0001571996-24-000081:8k_2_02:26]
As previously announced, the company will hold a conference call to discuss its performance and financial guidance on August 29 at 3:30 p.m. CDT. Prior to the start of the conference call, prepared remarks and a presentation containing additional financial and operating information prior to financial guidance may be downloaded from investors.delltechnologies.com. The conference call will be broadcast live over the internet and can be accessed at https://investors.delltechnologies.com/news-events/upcoming-events.

[0001571996-24-000081:8k_2_02:27]
For those unable to listen to the live broadcast, the final remarks and presentation with financial guidance will be available following the broadcast, and an archived version will be available at the same location for one year.

[0001571996-24-000081:8k_2_02:28]
About Dell Technologies

[0001571996-24-000081:8k_2_02:29]
Dell Technologies (NYSE:DELL) helps organizations and individuals build their digital future and transform how they work, live and play. The company provides customers with the industry’s broadest and most innovative technology and services portfolio for the AI era.

[0001571996-24-000081:8k_2_02:30]
Contacts

[0001571996-24-000081:8k_2_02:31]
Investors: Investor_Relations@Dell.com

[0001571996-24-000081:8k_2_02:32]
Media: Media.Relations@Dell.com

[0001571996-24-000081:8k_2_02:33]
3

[0001571996-24-000081:8k_2_02:34]
# # #

[0001571996-24-000081:8k_2_02:35]
Copyright © 2024 Dell Inc. or its subsidiaries. All Rights Reserved. Dell Technologies, Dell, EMC and Dell EMC are trademarks of Dell Inc. or its subsidiaries. Other trademarks may be trademarks of their respective owners.

[0001571996-24-000081:8k_2_02:36]
Non-GAAP Financial Measures:

[0001571996-24-000081:8k_2_02:37]
This press release presents information about non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, non-GAAP net income attributable to Dell Technologies Inc., non-GAAP earnings per share attributable to Dell Technologies Inc. – diluted, free cash flow, and adjusted free cash flow, all of which are non-GAAP financial measures provided as a supplement to the results provided in accordance with generally accepted accounting principles in the United States of America (“GAAP”). A reconciliation of each non-GAAP financial measure to the most directly comparable GAAP financial measure is provided in the attached tables for each of the fiscal periods indicated.

[0001571996-24-000081:8k_2_02:38]
Special Note on Forward-Looking Statements:

[0001571996-24-000081:8k_2_02:39]
Dell Technologies’ results or events in future periods could differ materially from those expressed or implied by these forward-looking statements because of risks, uncertainties, and other factors that include, but are not limited to, the following: adverse global economic conditions and instability in financial markets; competitive pressures; Dell Technologies’ reliance on third-party suppliers for products and components, including reliance on single-source or limited-source suppliers; Dell Technologies’ ability to achieve favorable pricing from its vendors; Dell Technologies’ execution of its strategy; social and ethical issues relating to the use of new and evolving technologies; Dell Technologies’ ability to manage solutions and products and services transitions in an effective manner; Dell Technologies’ ability to deliver high-quality products, software, and services; cyber attacks or other data security incidents; Dell Technologies’ ability to successfully execute on strategic initiatives including acquisitions, divestitures or cost savings measures; Dell Technologies’ foreign operations and ability to generate substantial non-U.S. net revenue; Dell Technologies’ product, services, customer, and geographic sales mix, and seasonal sales trends; the performance of Dell Technologies’ sales channel partners; access to the capital markets by Dell Technologies or its customers; material impairment of the value of goodwill or intangible assets; adverse economic conditions and the effect of additional regulation on Dell Technologies’ financial services activities; counterparty default risks; the loss by Dell Technologies of any contracts for ISG services and solutions and its ability to perform such contracts at their estimated costs; loss by Dell Technologies of government contracts; Dell Technologies’ ability to develop and protect its proprietary intellectual property or obtain licenses to intellectual property developed by others on commercially reasonable and competitive terms; disruptions in Dell Technologies’ infrastructure; Dell Technologies’ ability to hedge effectively its exposure to fluctuations in foreign currency exchange rates and interest rates; expiration of tax holidays or favorable tax rate structures, or unfavorable outcomes in tax audits and other tax compliance matters; impairment of portfolio investments; unfavorable results of legal proceedings; expectations relating to environmental, social and governance (ESG) considerations; compliance requirements of changing environmental and safety laws, human rights laws, or other laws; the effect of armed hostilities, terrorism, natural disasters, or public health issues; the effect of global climate change and legal, regulatory, or market measures to address climate change; Dell Technologies’ dependence on the services of Michael Dell and key employees; Dell Technologies’ level of indebtedness; and business and financial factors and legal restrictions affecting continuation of Dell Technologies’ quarterly cash dividend policy and dividend rate.

[0001571996-24-000081:8k_2_02:40]
This list of risks, uncertainties, and other factors is not complete. Dell Technologies discusses some of these matters more fully, as well as certain risk factors that could affect Dell Technologies’ business, financial condition, results of operations, and prospects, in its reports filed with the SEC, including Dell Technologies’ annual report on Form 10-K for the fiscal year ended February 2, 2024, quarterly reports on Form 10-Q, and current reports on Form 8-K. These filings are available for review through the SEC’s website at www.sec.gov. Any or all forward-looking statements Dell Technologies makes may turn out to be wrong and can be affected by inaccurate assumptions Dell Technologies might make or by known or unknown risks, uncertainties, and other factors, including those identified in this press release. Accordingly, you should not place undue reliance on the forward-looking statements made in this press release, which speak only as of its date. Dell Technologies does not undertake to update, and expressly disclaims any duty to update, its forward-looking statements, whether as a result of circumstances or events that arise after the date they are made, new information, or otherwise.

[0001571996-24-000081:8k_2_02:41]
4

[0001571996-24-000081:8k_2_02:42]
DELL TECHNOLOGIES INC.

[0001571996-24-000081:8k_2_02:43]
Condensed Consolidated Statements of Income and Related Financial Highlights

[0001571996-24-000081:8k_2_02:44]
(in millions, except percentages; unaudited)

[0001571996-24-000081:8k_2_02:45]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | August 2, 2024 |  | August 4, 2023 |  | Change |  | August 2, 2024 |  | August 4, 2023 |  | Change |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Products | $ | 18,954 |  |  | $ | 16,935 |  |  | 12% |  | $ | 35,081 |  |  | $ | 31,971 |  |  | 10% |
| Services | 6,072 |  |  | 5,999 |  |  | 1% |  | 12,189 |  |  | 11,885 |  |  | 3% |
| Total net revenue | 25,026 |  |  | 22,934 |  |  | 9% |  | 47,270 |  |  | 43,856 |  |  | 8% |
| Cost of net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Products | 16,079 |  |  | 14,002 |  |  | 15% |  | 29,845 |  |  | 26,377 |  |  | 13% |
| Services | 3,636 |  |  | 3,545 |  |  | 3% |  | 7,308 |  |  | 7,074 |  |  | 3% |
| Total cost of net revenue | 19,715 |  |  | 17,547 |  |  | 12% |  | 37,153 |  |  | 33,451 |  |  | 11% |
| Gross margin | 5,311 |  |  | 5,387 |  |  | (1)% |  | 10,117 |  |  | 10,405 |  |  | (3)% |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative | 3,189 |  |  | 3,517 |  |  | (9)% |  | 6,312 |  |  | 6,778 |  |  | (7)% |
| Research and development | 780 |  |  | 705 |  |  | 11% |  | 1,543 |  |  | 1,393 |  |  | 11% |
| Total operating expenses | 3,969 |  |  | 4,222 |  |  | (6)% |  | 7,855 |  |  | 8,171 |  |  | (4)% |
| Operating income | 1,342 |  |  | 1,165 |  |  | 15% |  | 2,262 |  |  | 2,234 |  |  | 1% |
| Interest and other, net | (353) |  |  | (451) |  |  | 22% |  | (726) |  |  | (815) |  |  | 11% |
| Income before income taxes | 989 |  |  | 714 |  |  | 39% |  | 1,536 |  |  | 1,419 |  |  | 8% |
| Income tax expense (benefit) | 148 |  |  | 259 |  |  | (43)% |  | (260) |  |  | 386 |  |  | (167)% |
| Net income | 841 |  |  | 455 |  |  | 85% |  | 1,796 |  |  | 1,033 |  |  | 74% |
| Less: Net loss attributable to non-controlling interests | (5) |  |  | (7) |  |  | 29% |  | (10) |  |  | (12) |  |  | 17% |
| Net income attributable to Dell Technologies Inc. | $ | 846 |  |  | $ | 462 |  |  | 83% |  | $ | 1,806 |  |  | $ | 1,045 |  |  | 73% |
| Percentage of Total Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Gross margin | 21.2 | % |  | 23.5 | % |  |  |  | 21.4 | % |  | 23.7 | % |  |  |
| Selling, general, and administrative | 12.7 | % |  | 15.3 | % |  |  |  | 13.3 | % |  | 15.4 | % |  |  |
| Research and development | 3.1 | % |  | 3.1 | % |  |  |  | 3.3 | % |  | 3.2 | % |  |  |
| Operating expenses | 15.8 | % |  | 18.4 | % |  |  |  | 16.6 | % |  | 18.6 | % |  |  |
| Operating income | 5.4 | % |  | 5.1 | % |  |  |  | 4.8 | % |  | 5.1 | % |  |  |
| Income before income taxes | 4.0 | % |  | 3.1 | % |  |  |  | 3.2 | % |  | 3.2 | % |  |  |
| Net income | 3.4 | % |  | 2.0 | % |  |  |  | 3.8 | % |  | 2.4 | % |  |  |
| Income tax rate | 15.0 | % |  | 36.3 | % |  |  |  | (16.9) | % |  | 27.2 | % |  |  |

[0001571996-24-000081:8k_2_02:46]
Amounts are based on underlying data and may not visually foot due to rounding.

[0001571996-24-000081:8k_2_02:47]
5

[0001571996-24-000081:8k_2_02:48]
DELL TECHNOLOGIES INC.

[0001571996-24-000081:8k_2_02:49]
Condensed Consolidated Statements of Financial Position

[0001571996-24-000081:8k_2_02:50]
(in millions; unaudited)

[0001571996-24-000081:8k_2_02:51]
|  | August 2, 2024 |  | February 2, 2024 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 4,550 |  |  | $ | 7,366 |  |
| Accounts receivable, net of allowance of $78 and $71 | 11,391 |  |  | 9,343 |  |
| Short-term financing receivables, net of allowance of $79 and $79 | 4,968 |  |  | 4,643 |  |
| Inventories | 5,953 |  |  | 3,622 |  |
| Other current assets | 10,681 |  |  | 10,973 |  |
| Total current assets | 37,543 |  |  | 35,947 |  |
| Property, plant, and equipment, net | 6,300 |  |  | 6,432 |  |
| Long-term investments | 1,302 |  |  | 1,316 |  |
| Long-term financing receivables, net of allowance of $87 and $91 | 6,124 |  |  | 5,877 |  |
| Goodwill | 19,654 |  |  | 19,700 |  |
| Intangible assets, net | 5,374 |  |  | 5,701 |  |
| Other non-current assets | 6,390 |  |  | 7,116 |  |
| Total assets | $ | 82,687 |  |  | $ | 82,089 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Short-term debt | $ | 6,711 |  |  | $ | 6,982 |  |
| Accounts payable | 24,095 |  |  | 19,389 |  |
| Accrued and other | 6,374 |  |  | 6,805 |  |
| Short-term deferred revenue | 14,853 |  |  | 15,318 |  |
| Total current liabilities | 52,033 |  |  | 48,494 |  |
| Long-term debt | 17,811 |  |  | 19,012 |  |
| Long-term deferred revenue | 12,859 |  |  | 13,827 |  |
| Other non-current liabilities | 2,781 |  |  | 3,065 |  |
| Total liabilities | 85,484 |  |  | 84,398 |  |
| Stockholders’ equity (deficit): |  |  |  |
| Total Dell Technologies Inc. stockholders’ equity (deficit) | (2,894) |  |  | (2,404) |  |
| Non-controlling interests | 97 |  |  | 95 |  |
| Total stockholders’ equity (deficit) | (2,797) |  |  | (2,309) |  |
| Total liabilities and stockholders’ equity | $ | 82,687 |  |  | $ | 82,089 |  |

[0001571996-24-000081:8k_2_02:52]
6

[0001571996-24-000081:8k_2_02:53]
DELL TECHNOLOGIES INC.

[0001571996-24-000081:8k_2_02:54]
Condensed Consolidated Statements of Cash Flows

[0001571996-24-000081:8k_2_02:55]
(in millions; unaudited)

[0001571996-24-000081:8k_2_02:56]
|  | Three Months Ended |  | Six Months Ended |
|  | August 2, 2024 |  | August 4, 2023 |  | August 2, 2024 |  | August 4, 2023 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |
| Net income | $ | 841 |  |  | $ | 455 |  |  | $ | 1,796 |  |  | $ | 1,033 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: | 499 |  |  | 2,759 |  |  | 587 |  |  | 3,958 |  |
| Change in cash from operating activities | 1,340 |  |  | 3,214 |  |  | 2,383 |  |  | 4,991 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |
| Purchases of investments | (25) |  |  | (98) |  |  | (64) |  |  | (113) |  |
| Maturities and sales of investments | 97 |  |  | 108 |  |  | 216 |  |  | 127 |  |
| Capital expenditures and capitalized software development costs | (682) |  |  | (624) |  |  | (1,278) |  |  | (1,325) |  |
| Other | 53 |  |  | 9 |  |  | 113 |  |  | 22 |  |
| Change in cash from investing activities | (557) |  |  | (605) |  |  | (1,013) |  |  | (1,289) |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |
| Proceeds from the issuance of common stock | 1 |  |  | 2 |  |  | 1 |  |  | 4 |  |
| Repurchases of common stock | (725) |  |  | (260) |  |  | (1,425) |  |  | (500) |  |
| Repurchases of common stock for employee tax withholdings | (14) |  |  | (6) |  |  | (535) |  |  | (312) |  |
| Payments of dividends and dividend equivalents | (316) |  |  | (269) |  |  | (652) |  |  | (545) |  |
| Proceeds from debt | 1,941 |  |  | 2,134 |  |  | 4,933 |  |  | 4,655 |  |
| Repayments of debt | (2,917) |  |  | (3,384) |  |  | (6,394) |  |  | (7,082) |  |
| Debt-related costs and other, net | (2) |  |  | (44) |  |  | (37) |  |  | (49) |  |
| Change in cash from financing activities | (2,032) |  |  | (1,827) |  |  | (4,109) |  |  | (3,829) |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash | (42) |  |  | (59) |  |  | (97) |  |  | (117) |  |
| Change in cash, cash equivalents, and restricted cash | (1,291) |  |  | 723 |  |  | (2,836) |  |  | (244) |  |
| Cash, cash equivalents, and restricted cash at beginning of the period | 5,962 |  |  | 7,927 |  |  | 7,507 |  |  | 8,894 |  |
| Cash, cash equivalents, and restricted cash at end of the period | $ | 4,671 |  |  | $ | 8,650 |  |  | $ | 4,671 |  |  | $ | 8,650 |  |

[0001571996-24-000081:8k_2_02:57]
7

[0001571996-24-000081:8k_2_02:58]
DELL TECHNOLOGIES INC.

[0001571996-24-000081:8k_2_02:59]
Segment Information

[0001571996-24-000081:8k_2_02:60]
(in millions, except percentages; unaudited; continued on next page)

[0001571996-24-000081:8k_2_02:61]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | August 2, 2024 |  | August 4, 2023 |  | Change |  | August 2, 2024 |  | August 4, 2023 |  | Change |
| Infrastructure Solutions Group (ISG): |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Servers and networking | $ | 7,672 |  | $ | 4,274 |  |  | 80% |  | $ | 13,138 |  |  | $ | 8,111 |  |  | 62% |
| Storage | 3,974 |  |  | 4,187 |  |  | (5)% |  | 7,735 |  |  | 7,943 |  |  | (3)% |
| Total ISG net revenue | $ | 11,646 |  |  | $ | 8,461 |  |  | 38% |  | $ | 20,873 |  |  | $ | 16,054 |  |  | 30% |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| ISG operating income | $ | 1,284 |  |  | $ | 1,049 |  |  | 22% |  | $ | 2,020 |  |  | $ | 1,789 |  |  | 13% |
| % of ISG net revenue | 11.0 | % |  | 12.4 | % |  |  |  | 9.7 | % |  | 11.1 | % |  |  |
| % of total reportable segment operating income | 63 | % |  | 52 | % |  |  |  | 57 | % |  | 49 | % |  |  |
| Client Solutions Group (CSG): |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 10,556 |  |  | $ | 10,554 |  |  | —% |  | $ | 20,710 |  |  | $ | 20,416 |  |  | 1% |
| Consumer | 1,858 |  |  | 2,388 |  |  | (22)% |  | 3,671 |  |  | 4,509 |  |  | (19)% |
| Total CSG net revenue | $ | 12,414 |  |  | $ | 12,942 |  |  | (4)% |  | $ | 24,381 |  |  | $ | 24,925 |  |  | (2)% |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| CSG operating income | $ | 767 |  |  | $ | 969 |  |  | (21)% |  | $ | 1,499 |  |  | $ | 1,861 |  |  | (19)% |
| % of CSG net revenue | 6.2 | % |  | 7.5 | % |  |  |  | 6.1 | % |  | 7.5 | % |  |  |
| % of total reportable segment operating income | 37 | % |  | 48 | % |  |  |  | 43 | % |  | 51 | % |  |  |

[0001571996-24-000081:8k_2_02:62]
Amounts are based on underlying data and may not visually foot due to rounding.

[0001571996-24-000081:8k_2_02:63]
DELL TECHNOLOGIES INC.

[0001571996-24-000081:8k_2_02:64]
Segment Information

[0001571996-24-000081:8k_2_02:65]
(in millions, except percentages; unaudited; continued)

[0001571996-24-000081:8k_2_02:66]
|  | Three Months Ended |  | Six Months Ended |  |  |
|  | August 2, 2024 |  | August 4, 2023 |  | August 2, 2024 |  | August 4, 2023 |  |  |
| Reconciliation to consolidated net revenue: |  |  |  |  |  |  |  |  |  |
| Reportable segment net revenue | $ | 24,060 |  |  | $ | 21,403 |  |  | $ | 45,254 |  |  | $ | 40,979 |  |  |  |
| Other businesses (a) | 966 |  |  | 1,528 |  |  | 2,015 |  |  | 2,871 |  |  |  |
| Unallocated transactions (b) | — |  |  | 3 |  |  | 1 |  |  | 6 |  |  |  |
| Total consolidated net revenue | $ | 25,026 |  |  | $ | 22,934 |  |  | $ | 47,270 |  |  | $ | 43,856 |  |  |  |
| Reconciliation to consolidated operating income: |  |  |  |  |  |  |  |  |  |
| Reportable segment operating income | $ | 2,051 |  |  | $ | 2,018 |  |  | $ | 3,519 |  |  | $ | 3,650 |  |  |  |
| Other businesses (a) | (17) |  |  | (44) |  |  | (11) |  |  | (80) |  |  |  |
| Unallocated transactions (b) | — |  |  | 3 |  |  | — |  |  | 5 |  |  |  |
| Amortization of intangibles (c) | (168) |  |  | (213) |  |  | (336) |  |  | (416) |  |  |  |
| Stock-based compensation expense (d) | (191) |  |  | (223) |  |  | (401) |  |  | (448) |  |  |  |
| Other corporate expenses (e) | (333) |  |  | (376) |  |  | (509) |  |  | (477) |  |  |  |
| Total consolidated operating income | $ | 1,342 |  |  | $ | 1,165 |  |  | $ | 2,262 |  |  | $ | 2,234 |  |  |  |

[0001571996-24-000081:8k_2_02:67]
_________________

[0001571996-24-000081:8k_2_02:68]
(a)Other businesses consists of: 1) Dell’s resale of standalone VMware, Inc. products and services, “VMware Resale,” 2) Secureworks, and 3) Virtustream, and do not meet the requirements for a reportable segment, either individually or collectively.

[0001571996-24-000081:8k_2_02:69]
(b)Unallocated transactions includes other corporate items that are not allocated to Dell Technologies’ reportable segments.

[0001571996-24-000081:8k_2_02:70]
(c)Amortization of intangibles includes non-cash purchase accounting adjustments that are primarily related to the EMC merger transaction.

[0001571996-24-000081:8k_2_02:71]
(d)Stock-based compensation expense consists of equity awards granted based on the estimated fair value of those awards at grant date.

[0001571996-24-000081:8k_2_02:72]
(e)Other corporate expenses consist primarily of severance expenses, payroll taxes associated with stock-based compensation, facility action costs, transaction-related expenses, impairment charges, and incentive charges related to equity investments. Other corporate expenses included $328 million and $364 million of severance expense during the three months ended August 2, 2024 and August 4, 2023, respectively.

[0001571996-24-000081:8k_2_02:73]
9

[0001571996-24-000081:8k_2_02:74]
SUPPLEMENTAL SELECTED NON-GAAP FINANCIAL MEASURES

[0001571996-24-000081:8k_2_02:75]
These tables present information about the Company’s non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, non-GAAP net income attributable to Dell Technologies Inc., non-GAAP earnings per share attributable to Dell Technologies Inc. - diluted, free cash flow and adjusted free cash flow, all of which are non-GAAP financial measures provided as a supplement to the results provided in accordance with generally accepted accounting principles in the United States of America (“GAAP”). A detailed discussion of Dell Technologies’ reasons for including these non-GAAP financial measures, the limitations associated with these measures, the items excluded from these measures, and our reason for excluding those items are presented in “Management’s Discussion and Analysis of Financial Condition and Results of Operations — Non-GAAP Financial Measures” in our periodic reports filed with the SEC. Dell Technologies encourages investors to review the non-GAAP discussion in these reports in conjunction with the presentation of non-GAAP financial measures.

[0001571996-24-000081:8k_2_02:76]
10

[0001571996-24-000081:8k_2_02:77]
DELL TECHNOLOGIES INC.

[0001571996-24-000081:8k_2_02:78]
Selected Financial Measures

[0001571996-24-000081:8k_2_02:79]
(in millions, except per share amounts and percentages; unaudited)

[0001571996-24-000081:8k_2_02:80]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | August 2, 2024 |  | August 4, 2023 |  | Change |  | August 2, 2024 |  | August 4, 2023 |  | Change |
| Net revenue | $ | 25,026 |  |  | $ | 22,934 |  |  | 9% |  | $ | 47,270 |  |  | $ | 43,856 |  |  | 8% |
| Non-GAAP gross margin | $ | 5,464 |  |  | $ | 5,536 |  |  | (1)% |  | $ | 10,411 |  |  | $ | 10,700 |  |  | (3)% |
| % of net revenue | 21.8 | % |  | 24.1 | % |  |  |  | 22.0 | % |  | 24.4 | % |  |  |
| Non-GAAP operating expenses | $ | 3,430 |  |  | $ | 3,559 |  |  | (4)% |  | $ | 6,903 |  |  | $ | 7,125 |  |  | (3)% |
| % of net revenue | 13.7 | % |  | 15.5 | % |  |  |  | 14.6 | % |  | 16.2 | % |  |  |
| Non-GAAP operating income | $ | 2,034 |  |  | $ | 1,977 |  |  | 3% |  | $ | 3,508 |  | $ | 3,575 |  | (2)% |
| % of net revenue | 8.1 | % |  | 8.6 | % |  |  |  | 7.4 | % |  | 8.2 | % |  |  |
| Non-GAAP net income | $ | 1,371 |  |  | $ | 1,283 |  |  | 7% |  | $ | 2,294 |  |  | $ | 2,246 |  |  | 2% |
| % of net revenue | 5.5 | % |  | 5.6 | % |  |  |  | 4.9 | % |  | 5.1 | % |  |  |
| Non-GAAP earnings per share - diluted | $ | 1.89 |  |  | $ | 1.74 |  |  | 9% |  | $ | 3.16 |  |  | $ | 3.05 |  |  | 4% |

[0001571996-24-000081:8k_2_02:81]
Amounts are based on underlying data and may not visually foot due to rounding.

[0001571996-24-000081:8k_2_02:82]
DELL TECHNOLOGIES INC.

[0001571996-24-000081:8k_2_02:83]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-24-000081:8k_2_02:84]
(in millions, except percentages; unaudited; continued on next page)

[0001571996-24-000081:8k_2_02:85]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | August 2, 2024 |  | August 4, 2023 |  | Change |  | August 2, 2024 |  | August 4, 2023 |  | Change |
| Gross margin | $ | 5,311 |  |  | $ | 5,387 |  |  | (1)% |  | $ | 10,117 |  |  | $ | 10,405 |  |  | (3)% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 59 |  |  | 84 |  |  |  |  | 119 |  |  | 163 |  |  |  |
| Stock-based compensation expense | 38 |  |  | 37 |  |  |  |  | 76 |  |  | 75 |  |  |  |
| Other corporate expenses | 56 |  |  | 28 |  |  |  |  | 99 |  |  | 57 |  |  |  |
| Non-GAAP gross margin | $ | 5,464 |  |  | $ | 5,536 |  |  | (1)% |  | $ | 10,411 |  |  | $ | 10,700 |  |  | (3)% |
| Operating expenses | $ | 3,969 |  |  | $ | 4,222 |  |  | (6)% |  | $ | 7,855 |  |  | $ | 8,171 |  |  | (4)% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | (109) |  |  | (129) |  |  |  |  | (217) |  |  | (253) |  |  |  |
| Stock-based compensation expense | (153) |  |  | (186) |  |  |  |  | (325) |  |  | (373) |  |  |  |
| Other corporate expenses | (277) |  |  | (348) |  |  |  |  | (410) |  |  | (420) |  |  |  |
| Non-GAAP operating expenses | $ | 3,430 |  |  | $ | 3,559 |  |  | (4)% |  | $ | 6,903 |  |  | $ | 7,125 |  |  | (3)% |
| Operating income | $ | 1,342 |  |  | $ | 1,165 |  |  | 15% |  | $ | 2,262 |  |  | $ | 2,234 |  |  | 1% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 168 |  |  | 213 |  |  |  |  | 336 |  |  | 416 |  |  |  |
| Stock-based compensation expense | 191 |  |  | 223 |  |  |  |  | 401 |  |  | 448 |  |  |  |
| Other corporate expenses | 333 |  |  | 376 |  |  |  |  | 509 |  |  | 477 |  |  |  |
| Non-GAAP operating income | $ | 2,034 |  |  | $ | 1,977 |  |  | 3% |  | $ | 3,508 |  |  | $ | 3,575 |  |  | (2)% |
| Net income | $ | 841 |  |  | $ | 455 |  |  | 85% |  | $ | 1,796 |  |  | $ | 1,033 |  |  | 74% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 168 |  |  | 213 |  |  |  |  | 336 |  |  | 416 |  |  |  |
| Stock-based compensation expense | 191 |  |  | 223 |  |  |  |  | 401 |  |  | 448 |  |  |  |
| Other corporate expenses | 329 |  |  | 432 |  |  |  |  | 499 |  |  | 530 |  |  |  |
| Fair value adjustments on equity investments | (5) |  |  | 29 |  |  |  |  | 25 |  |  | 44 |  |  |  |
| Aggregate adjustment for income taxes (a) | (153) |  |  | (69) |  |  |  |  | (763) |  |  | (225) |  |  |  |
| Non-GAAP net income | $ | 1,371 |  |  | $ | 1,283 |  |  | 7% |  | $ | 2,294 |  |  | $ | 2,246 |  |  | 2% |

[0001571996-24-000081:8k_2_02:86]
____________________

[0001571996-24-000081:8k_2_02:87]
(a)    Beginning in Fiscal 2025, our non-GAAP income tax is calculated using a fixed estimated annual tax rate.

[0001571996-24-000081:8k_2_02:88]
12

[0001571996-24-000081:8k_2_02:89]
DELL TECHNOLOGIES INC.

[0001571996-24-000081:8k_2_02:90]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-24-000081:8k_2_02:91]
(unaudited; continued)

[0001571996-24-000081:8k_2_02:92]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |  |  |  |  |
|  | August 2, 2024 |  | August 4, 2023 |  | Change |  | August 2,2024 |  | August 4,2023 |  | Change |  |  |  |  |
| Earnings per share attributable to Dell Technologies Inc. — diluted | $ | 1.17 |  |  | $ | 0.63 |  |  | 86 | % |  | $ | 2.49 |  |  | $ | 1.42 |  |  | 75 | % |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 0.23 |  |  | 0.29 |  |  |  |  | 0.46 |  |  | 0.56 |  |  |  |  |  |  |  |
| Stock-based compensation expense | 0.26 |  |  | 0.30 |  |  |  |  | 0.55 |  |  | 0.61 |  |  |  |  |  |  |  |
| Other corporate expenses | 0.46 |  |  | 0.58 |  |  |  |  | 0.69 |  |  | 0.72 |  |  |  |  |  |  |  |
| Fair value adjustments on equity investments | (0.01) |  |  | 0.04 |  |  |  |  | 0.04 |  |  | 0.06 |  |  |  |  |  |  |  |
| Aggregate adjustment for income taxes (a) | (0.21) |  |  | (0.09) |  |  |  |  | (1.05) |  |  | (0.31) |  |  |  |  |  |  |  |
| Total non-GAAP adjustments attributable to non-controlling interests | (0.01) |  |  | (0.01) |  |  |  |  | (0.02) |  |  | (0.01) |  |  |  |  |  |  |  |
| Non-GAAP earnings per share attributable to Dell Technologies Inc. — diluted | $ | 1.89 |  |  | $ | 1.74 |  |  | 9 | % |  | $ | 3.16 |  |  | $ | 3.05 |  |  | 4 | % |  |  |  |  |

[0001571996-24-000081:8k_2_02:93]
____________________

[0001571996-24-000081:8k_2_02:94]
(a)    Beginning in Fiscal 2025, our non-GAAP income tax is calculated using a fixed estimated annual tax rate.

[0001571996-24-000081:8k_2_02:95]
DELL TECHNOLOGIES INC.

[0001571996-24-000081:8k_2_02:96]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-24-000081:8k_2_02:97]
(in millions, except percentages; unaudited; continued)

[0001571996-24-000081:8k_2_02:98]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |  |  |  |  |
|  | August 2, 2024 |  | August 4, 2023 |  | Change |  | August 2,2024 |  | August 4,2023 |  | Change |  |  |  |  |
| Cash flow from operations | $ | 1,340 |  |  | $ | 3,214 |  |  | (58) | % |  | $ | 2,383 |  |  | $ | 4,991 |  |  | (52) | % |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Capital expenditures and capitalized software development costs, net (a) | (636) |  |  | (624) |  |  |  |  | (1,222) |  |  | (1,322) |  |  |  |  |  |  |  |
| Free cash flow | $ | 704 |  |  | $ | 2,590 |  |  | (73) | % |  | $ | 1,161 |  |  | $ | 3,669 |  |  | (68) | % |  |  |  |  |
| Free cash flow | $ | 704 |  |  | $ | 2,590 |  |  | (73) | % |  | $ | 1,161 |  |  | $ | 3,669 |  |  | (68) | % |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Financing receivables (b) | 487 |  |  | 497 |  |  |  |  | 652 |  |  | 130 |  |  |  |  |  |  |  |
| Equipment under operating leases (c) | 93 |  |  | (37) |  |  |  |  | 94 |  |  | (62) |  |  |  |  |  |  |  |
| Adjusted free cash flow | $ | 1,284 |  |  | $ | 3,050 |  |  | (58) | % |  | $ | 1,907 |  |  | $ | 3,737 |  |  | (49) | % |  |  |  |  |

[0001571996-24-000081:8k_2_02:99]
____________________

[0001571996-24-000081:8k_2_02:100]
(a)    Capital expenditures and capitalized software development costs is net of proceeds from sales of facilities, land, and

[0001571996-24-000081:8k_2_02:101]
other assets.

[0001571996-24-000081:8k_2_02:102]
(b)    Financing receivables represent the operating cash flow impact from the change in DFS financing receivables.

[0001571996-24-000081:8k_2_02:103]
(c)    Equipment under operating leases represents the net change of capital expenditures and depreciation expense for DFS leases and contractually embedded leases identified within flexible consumption arrangements.
