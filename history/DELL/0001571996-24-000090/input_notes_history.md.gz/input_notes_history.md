# DELL note change history — 0001571996-24-000062 → 0001571996-24-000090


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-09-10):
[0001571996-24-000090:note_history:1]
COMMITMENTS AND CONTINGENCIES 
Purchase Obligations
  (was, 2024-06-11, similarity 0.7527):
[0001571996-24-000062:note_history:1]
COMMITMENTS AND CONTINGENCIES 
Legal Matters

- added (2024-09-10):
[0001571996-24-000090:note_history:2]
The Company has contractual obligations to purchase goods or services, which specify significant terms (including fixed or minimum quantities to be purchased), fixed, minimum, or variable price provisions, and the approximate timing of the transaction. As of August 2, 2024, such purchase obligations were $5.7 billion for Fiscal 2025; $0.5 billion for Fiscal 2026; and $1.0 billion for Fiscal 2027 and thereafter.

- added (2024-09-10):
[0001571996-24-000090:note_history:3]
Legal Matters

- changed (2024-09-10):
[0001571996-24-000090:note_history:4]
Class Actions Related to the Class V Transaction — On December 28, 2018, the Company completed a transaction (the “Class V transaction”) in which it paid $14.0 billion in cash and issued 149,387,617 shares of its Class C Common Stock to holders of its Class V Common Stock in exchange for all outstanding shares of Class V Common Stock. As a result of the Class V transaction, the tracking stock feature of the Company’s capital structure associated with the Class V Common Stock was terminated. Certain stockholders of the Company subsequently brought class action complaints arising out of the Class V transaction in which they named as defendants (collectively, the “defendants”) Michael S. Dell and certain other directors serving on the Company’s board of directors at the time of the Class V transaction (collectively, the “director defendants”), certain stockholders of the Company, consisting of Mr. Dell and Silver Lake Group, L.L.C. and certain of its affiliated funds (collectively, the “stockholder defendants”), and Goldman Sachs & Co. LLC, which served as financial advisor to the Company in connection with the transaction. The plaintiffs generally alleged that the director defendants and the stockholder defendants breached their fiduciary duties under Delaware law to the former holders of the Class V Common Stock in connection with the Class V transaction by offering a transaction value that was allegedly billions of dollars below fair value.
  (was, 2024-06-11, similarity 0.9935):
[0001571996-24-000062:note_history:4]
Class Actions Related to the Class V Transaction — On December 28, 2018, the Company completed a transaction (the “Class V transaction”) in which it paid $14.0 billion in cash and issued 149,387,617 shares of its Class C Common Stock to holders of its Class V Common Stock in exchange for all outstanding shares of Class V Common Stock.  As a result of the Class V transaction, the tracking stock feature of the Company’s capital structure associated with the Class V Common Stock was terminated.  Certain stockholders of the Company, subsequently brought class action complaints arising out of the Class V transaction in which they named as defendants (collectively, the “defendants”) Michael S. Dell and certain other directors serving on the Company’s board of directors at the time of the Class V transaction (collectively, the “director defendants”), certain stockholders of the Company, consisting of Mr. Dell and Silver Lake Group, L.L.C. and certain of its affiliated funds (collectively, the “stockholder defendants”), and Goldman Sachs & Co. LLC (“Goldman Sachs”), which served as financial advisor to the Company in connection with the transaction.  The plaintiffs generally alleged that the director defendants and the stockholder defendants breached their fiduciary duties under Delaware law to the former holders of the Class V Common Stock in connection with the Class V transaction by offering a transaction value that was allegedly billions of dollars below fair value.

- added (2024-09-10):
[0001571996-24-000090:note_history:5]
R2 Semiconductor Patent Litigation — In November 2022, R2 Semiconductor, Inc. (“R2”) filed a lawsuit in the Dusseldorf Regional Court in Germany against Intel Deutschland GmbH, Dell GmbH, and certain other customers of Intel Corporation. R2 asserted that one European patent is infringed by certain Intel processors and those of the Company’s products that incorporate those processors. R2 sought an injunction prohibiting the sale of the allegedly infringing products and damages for the alleged infringement. The court conducted a trial on December 7, 2023 and, on February 7, 2024, issued a decision in favor of R2 and imposed an injunction prohibiting the sale and use of such products in Germany by Dell GmbH, and requiring Dell GmbH to issue a communication to certain customers recalling the covered products sold since March 5, 2020. On February 8, 2024, the Company filed an appeal. In April and May 2024, R2 filed lawsuits in Paris, France and Milan, Italy, against affiliates of Intel Corporation (“Intel”) and of the Company, raising similar allegations. Intel agreed to defend the foregoing actions and indemnify the Company and its affiliates against certain losses incurred by the Company in connection with R2’s claims. On August 30, 2024, Intel and R2 publicly announced an agreement to dismiss all litigation between the two companies that would include dismissal of all litigation against all subsidiaries of Dell Technologies named in the foregoing actions. Pursuant to that agreement, the Italian lawsuit was dismissed on September 2, 2024, the German lawsuit was dismissed on September 4, 2024, and the French lawsuit was dismissed on September 6, 2024.

- added (2024-09-10):
[0001571996-24-000090:note_history:6]
In accordance with the relevant accounting guidance, the Company provides disclosures of matters where it is at least reasonably possible that the Company could experience a material loss exceeding the amounts already accrued for these or other proceedings or matters. In addition, the Company also discloses matters based on its consideration of other matters and qualitative factors, including the experience of other companies in the industry, and investor, customer, and employee relations considerations. As of August 2, 2024, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for these or other proceedings or matters has been incurred. However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company’s business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters. Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company’s business, financial condition, results of operations, or cash flows will depend on a number of factors, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.

- changed (2024-09-10):
[0001571996-24-000090:note_history:7]
Under the Separation and Distribution Agreement entered into with VMware, Inc. upon completion of the spin-off of VMware, Inc. on November 1, 2021 (the “VMware Spin-off”), Dell Technologies agreed to indemnify VMware, Inc., each of its subsidiaries and each of their respective directors, officers, employees, as well as any successors and assigns of the foregoing, from and against all liabilities relating to, arising out of or resulting from, among other matters, the liabilities allocated to Dell Technologies as part of the separation of Dell Technologies and VMware, Inc. (individually and together with its subsidiaries, “VMware”) and their respective businesses (the “Separation”). VMware similarly agreed to indemnify Dell Technologies Inc., each of its subsidiaries and each of their respective directors, officers, and employees from and against all liabilities relating to, arising out of or resulting from, among other matters, the liabilities allocated to VMware as part of the Separation. The amounts that VMware and Dell Technologies may be obligated to pay each other could vary depending on the outcome of certain unresolved tax matters, which may not be resolved for several years. Net income tax indemnification receivables from VMware were immaterial as of August 2, 2024 and February 2, 2024.
  (was, 2024-06-11, similarity 0.9771):
[0001571996-24-000062:note_history:7]
Under the Separation and Distribution Agreement entered into with VMware, Inc. upon completion of the spin-off of VMware, Inc. by means of a special stock dividend (the “VMware Spin-off”), Dell Technologies agreed to indemnify VMware, Inc., each of its subsidiaries and each of their respective directors, officers, employees, as well as any successors and assigns of the foregoing, from and against all liabilities relating to, arising out of or resulting from, among other matters, the liabilities allocated to Dell Technologies as part of the separation of Dell Technologies and VMware, Inc. (individually and together with its subsidiaries, “VMware”) and their respective businesses (the “Separation”).  VMware similarly agreed to indemnify Dell Technologies Inc., each of its subsidiaries and each of their respective directors, officers, and employees from and against all liabilities relating to, arising out of or resulting from, among other matters, the liabilities allocated to VMware as part of the Separation. The amounts that VMware and Dell Technologies may be obligated to pay each other could vary depending on the outcome of certain unresolved tax matters, which may not be resolved for several years.  Net income tax indemnification receivables from VMware were immaterial as of May 3, 2024 and February 2, 2024.

- removed (2024-09-10):
[0001571996-24-000062:note_history:8]
R2 Semiconductor Patent Litigation — In November 2022, R2 Semiconductor, Inc. (“R2”) filed a lawsuit in the Dusseldorf Regional Court in Germany against Intel Deutschland GmbH, Dell GmbH, and certain other customers of Intel Corporation.  R2 asserted that one European patent is infringed by certain Intel processors and those of the Company’s products that incorporate those processors (the “Accused Products”).  R2 sought an injunction prohibiting the sale of the allegedly infringing products and damages for the alleged infringement.  The Dusseldorf Regional Court (the “Court”) conducted a trial on December 7, 2023, and, on February 7, 2024, issued a decision in favor of R2.  The Court’s judgment imposes an injunction prohibiting (among other acts) the sale and use of the Accused Products in Germany by Dell GmbH, and requiring Dell GmbH to issue a communication to certain customers recalling the covered products sold since March 5, 2020.  These orders will not take effect until after notice of R2’s payment of the sureties required for enforcement and will remain in place unless stayed or overturned on appeal or until the parties reach an agreement.  On February 8, 2024, the Company filed an appeal which is in process with the appellate court.  The Court has not yet assessed damages arising out of R2’s claim.  In April 2024, R2 filed another action alleging infringement of the same patent in the Judicial Court of Paris, France and seeking an injunction prohibiting the sale of the allegedly infringing products and damages for the alleged infringement.  The defendants in the French case include, among others, Intel Corporation and Dell SAS.  Additionally, Dell SAS and its co-defendants filed a nullity action against the patent in France.  In May 2024, R2 filed a third-party action in the Court of Milan, Italy, against Dell S.p.A., Intel Corporation Italia S.p.A., and other Intel customers alleging infringement of the same patent and seeking similar relief.  Intel Corporation has agreed to defend the actions and indemnify the Company and its affiliates against certain losses incurred by the Company in connection with R2’s claims.  Given the status of these lawsuits, the nature of the dispute, and the Company’s agreements with Intel Corporation, the Company is unable to make a reasonable estimate of the potential loss or range of losses that might arise from the litigations.

- removed (2024-09-10):
[0001571996-24-000062:note_history:9]
In accordance with the relevant accounting guidance, the Company provides disclosures of matters where it is at least reasonably possible that the Company could experience a material loss exceeding the amounts already accrued for these or other proceedings or matters.  In addition, the Company also discloses matters based on its consideration of other matters and qualitative factors, including the experience of other companies in the industry, and investor, customer, and employee relations considerations.  As of May 3, 2024, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for these or other proceedings or matters has been incurred.  However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company’s business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters.  Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company’s business, financial condition, results of operations, or cash flows will depend on a number of factors, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.


## dell:CreditLossFinancialInstrumentLeasesDebtVariableInterestEntitiesAndCustomerReceivablesSalesTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-09-10):
[0001571996-24-000090:note_history:10]
Financing options are offered to the Company’s customers primarily through Dell Financial Services and its affiliates (“DFS”). The Company also arranges financing for some of its customers in various countries where DFS does not currently operate as a captive enterprise. The key activities of DFS include originating, collecting, and servicing customer financing arrangements primarily related to the purchase or use of Dell Technologies products and services. In some cases, DFS also offers financing for the purchase of third-party technology products that complement the Dell Technologies portfolio of products and services. New financing originations were $2.4 billion for both the three months ended August 2, 2024 and August 4, 2023, and $4.3 billion and $4.2 billion for the six months ended August 2, 2024 and August 4, 2023, respectively.
  (was, 2024-06-11, similarity 0.9013):
[0001571996-24-000062:note_history:10]
Financing options are offered to the Company’s customers primarily through Dell Financial Services and its affiliates (“DFS”).  The Company also arranges financing for some of its customers in various countries where DFS does not currently operate as a captive enterprise.  The key activities of DFS include originating, collecting, and servicing customer financing arrangements primarily related to the purchase or use of Dell Technologies products and services.  In some cases, DFS also offers financing for the purchase of third-party technology products that complement the Dell Technologies portfolio of products and services.  New financing originations were $1.9 billion and $1.8 billion for the three months ended May 3, 2024 and May 5, 2023, respectively.

- added (2024-09-10):
[0001571996-24-000090:note_history:11]
Prior to the sale of the U.S. consumer revolving customer receivables portfolio on October 4, 2023, described in Note 1 of the Notes to the Condensed Consolidated Financial Statements, the Company offered private label credit financing under the Dell Preferred Account (“DPA”) program. The DPA product was primarily offered to individual consumer customers.

- changed (2024-09-10):
[0001571996-24-000090:note_history:12]
|  | August 2, 2024 |  | February 2, 2024 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Financing receivables, net: |  |  |  |  |  |  |  |  |  |  |  |
| Customer receivables, gross (a) | $ | 154 |  |  | $ | 10,938 |  |  | $ | 11,092 |  |  | $ | 173 |  |  | $ | 10,360 |  |  | $ | 10,533 |  |
| Allowances for losses | (8) |  |  | (158) |  |  | (166) |  |  | (9) |  |  | (161) |  |  | (170) |  |
| Customer receivables, net | 146 |  |  | 10,780 |  |  | 10,926 |  |  | 164 |  |  | 10,199 |  |  | 10,363 |  |
| Residual interest | — |  |  | 166 |  |  | 166 |  |  | — |  |  | 157 |  |  | 157 |  |
| Financing receivables, net | $ | 146 |  |  | $ | 10,946 |  |  | $ | 11,092 |  |  | $ | 164 |  |  | $ | 10,356 |  |  | $ | 10,520 |  |
| Short-term | $ | 146 |  |  | $ | 4,822 |  |  | $ | 4,968 |  |  | $ | 164 |  |  | $ | 4,479 |  |  | $ | 4,643 |  |
| Long-term | $ | — |  |  | $ | 6,124 |  |  | $ | 6,124 |  |  | $ | — |  |  | $ | 5,877 |  |  | $ | 5,877 |  |
  (was, 2024-06-11, similarity 0.9943):
[0001571996-24-000062:note_history:12]
|  | May 3, 2024 |  | February 2, 2024 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Financing receivables, net: |  |  |  |  |  |  |  |  |  |  |  |
| Customer receivables, gross (a) | $ | 163 |  |  | $ | 10,470 |  |  | $ | 10,633 |  |  | $ | 173 |  |  | $ | 10,360 |  |  | $ | 10,533 |  |
| Allowances for losses | (8) |  |  | (187) |  |  | (195) |  |  | (9) |  |  | (161) |  |  | (170) |  |
| Customer receivables, net | 155 |  |  | 10,283 |  |  | 10,438 |  |  | 164 |  |  | 10,199 |  |  | 10,363 |  |
| Residual interest | — |  |  | 163 |  |  | 163 |  |  | — |  |  | 157 |  |  | 157 |  |
| Financing receivables, net | $ | 155 |  |  | $ | 10,446 |  |  | $ | 10,601 |  |  | $ | 164 |  |  | $ | 10,356 |  |  | $ | 10,520 |  |
| Short-term | $ | 155 |  |  | $ | 4,505 |  |  | $ | 4,660 |  |  | $ | 164 |  |  | $ | 4,479 |  |  | $ | 4,643 |  |
| Long-term | $ | — |  |  | $ | 5,941 |  |  | $ | 5,941 |  |  | $ | — |  |  | $ | 5,877 |  |  | $ | 5,877 |  |

- changed (2024-09-10):
[0001571996-24-000090:note_history:13]
The following tables present the changes in allowance for financing receivable losses for the periods indicated:
  (was, 2024-06-11, similarity 0.9867):
[0001571996-24-000062:note_history:13]
The following table presents the changes in allowance for financing receivables losses for the periods indicated:

- changed (2024-09-10):
[0001571996-24-000090:note_history:14]
|  | Three Months Ended |
|  | August 2, 2024 |  | August 4, 2023 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |  |  |  |  |  |  |  |
| Balances at beginning of period | $ | 8 |  |  | $ | 187 |  |  | $ | 195 |  |  | $ | 84 |  |  | $ | 135 |  |  | $ | 219 |  |
| Charge-offs, net of recoveries | (4) |  |  | (15) |  |  | (19) |  |  | (16) |  |  | (1) |  |  | (17) |  |
| Provision charged to income statement | 4 |  |  | (14) |  |  | (10) |  |  | 15 |  |  | 6 |  |  | 21 |  |
| Held for sale adjustment (a) | — |  |  | — |  |  | — |  |  | (74) |  |  | — |  |  | (74) |  |
| Balances at end of period | $ | 8 |  |  | $ | 158 |  |  | $ | 166 |  |  | $ | 9 |  |  | $ | 140 |  |  | $ | 149 |  |
  (was, 2024-06-11, similarity 0.8534):
[0001571996-24-000062:note_history:14]
|  | Three Months Ended |
|  | May 3, 2024 |  | May 5, 2023 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |  |  |  |  |  |  |  |
| Balances at beginning of period | $ | 9 |  |  | $ | 161 |  |  | $ | 170 |  |  | $ | 88 |  |  | $ | 113 |  |  | $ | 201 |  |
| Charge-offs, net of recoveries | (2) |  |  | (6) |  |  | (8) |  |  | (17) |  |  | (1) |  |  | (18) |  |
| Provision charged to income statement | 1 |  |  | 32 |  |  | 33 |  |  | 13 |  |  | 23 |  |  | 36 |  |
| Balances at end of period | $ | 8 |  |  | $ | 187 |  |  | $ | 195 |  |  | $ | 84 |  |  | $ | 135 |  |  | $ | 219 |  |

- added (2024-09-10):
[0001571996-24-000090:note_history:15]
|  | Six Months Ended |
|  | August 2, 2024 |  | August 4, 2023 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |  |  |  |  |  |  |  |
| Balances at beginning of period | $ | 9 |  |  | $ | 161 |  |  | $ | 170 |  |  | $ | 88 |  |  | $ | 113 |  |  | $ | 201 |  |
| Charge-offs, net of recoveries | (6) |  |  | (21) |  |  | (27) |  |  | (33) |  |  | (2) |  |  | (35) |  |
| Provision charged to income statement | 5 |  |  | 18 |  |  | 23 |  |  | 28 |  |  | 29 |  |  | 57 |  |
| Held for sale adjustment (a) | — |  |  | — |  |  | — |  |  | (74) |  |  | — |  |  | (74) |  |
| Balances at end of period | $ | 8 |  |  | $ | 158 |  |  | $ | 166 |  |  | $ | 9 |  |  | $ | 140 |  |  | $ | 149 |  |

- added (2024-09-10):
[0001571996-24-000090:note_history:16]
____________________

- added (2024-09-10):
[0001571996-24-000090:note_history:17]
(a)    The held for sale adjustment represents the reclassification of the U.S. consumer revolving customer receivables portfolio to current assets held for sale as of August 4, 2023. See Note 1 of the Notes to the Condensed Consolidated Financial Statements for more information about the sale of the U.S. consumer revolving customer receivables portfolio.

- changed (2024-09-10):
[0001571996-24-000090:note_history:18]
The Company recognizes an allowance for financing receivable losses, including both the lease receivable and unguaranteed residual, in an amount equal to the expected losses net of recoveries. The allowance for financing receivable losses on the lease receivable is determined based on various factors, including lifetime expected losses determined using macroeconomic forecast assumptions and management judgments applicable to and through the expected life of the portfolios as well as past due receivables, receivable type, and customer risk profile. The Company continues to monitor broader economic indicators and their potential impact on future credit loss performance.
  (was, 2024-06-11, similarity 0.9985):
[0001571996-24-000062:note_history:18]
The Company recognizes an allowance for financing receivables losses, including both the lease receivable and unguaranteed residual, in an amount equal to the expected losses net of recoveries.  The allowance for financing receivables losses on the lease receivable is determined based on various factors, including lifetime expected losses determined using macroeconomic forecast assumptions and management judgments applicable to and through the expected life of the portfolios as well as past due receivables, receivable type, and customer risk profile.  The Company continues to monitor broader economic indicators and their potential impact on future credit loss performance.

- added (2024-09-10):
[0001571996-24-000090:note_history:19]
|  | August 2, 2024 |  | February 2, 2024 |
|  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |
|  | (in millions) |
| Revolving | $ | 135 |  |  | $ | 15 |  |  | $ | 4 |  |  | $ | 154 |  |  | $ | 151 |  |  | $ | 17 |  |  | $ | 5 |  |  | $ | 173 |  |
| Fixed-term | 10,034 |  |  | 815 |  |  | 89 |  |  | 10,938 |  |  | 9,345 |  |  | 889 |  |  | 126 |  |  | 10,360 |  |
| Total customer receivables, gross | $ | 10,169 |  |  | $ | 830 |  |  | $ | 93 |  |  | $ | 11,092 |  |  | $ | 9,496 |  |  | $ | 906 |  |  | $ | 131 |  |  | $ | 10,533 |  |

- changed (2024-09-10):
[0001571996-24-000090:note_history:20]
Fixed-term customer receivables are placed on non-accrual status if principal or interest is past due and considered delinquent, or if there is concern about the collectibility of a specific customer receivable. The receivables identified as doubtful for collectibility may be classified as current for aging purposes. Aged revolving portfolio customer receivables identified as delinquent are charged off.
  (was, 2024-06-11, similarity 0.9713):
[0001571996-24-000062:note_history:20]
Fixed-term consumer and commercial customer receivables are placed on non-accrual status if principal or interest is past due and considered delinquent, or if there is concern about the collectibility of a specific customer receivable.  The receivables identified as doubtful for collectibility may be classified as current for aging purposes.  Aged revolving portfolio customer receivables identified as delinquent are charged off.

- changed (2024-09-10):
[0001571996-24-000090:note_history:21]
|  | August 2, 2024 |
|  | Fixed-term — Fiscal Year of Origination |  |  |  |  |
|  | 2025 |  | 2024 |  | 2023 |  | 2022 |  | 2021 |  | Years Prior |  | Revolving |  | Total |
|  | (in millions) |
| Higher | $ | 1,377 |  |  | $ | 2,626 |  |  | $ | 1,519 |  |  | $ | 563 |  |  | $ | 211 |  |  | $ | 14 |  |  | $ | 36 |  |  | $ | 6,346 |  |
| Mid | 476 |  |  | 940 |  |  | 695 |  |  | 152 |  |  | 35 |  |  | 8 |  |  | 46 |  |  | 2,352 |  |
| Lower | 1,262 |  |  | 530 |  |  | 353 |  |  | 118 |  |  | 48 |  |  | 11 |  |  | 72 |  |  | 2,394 |  |
| Total | $ | 3,115 |  |  | $ | 4,096 |  |  | $ | 2,567 |  |  | $ | 833 |  |  | $ | 294 |  |  | $ | 33 |  |  | $ | 154 |  |  | $ | 11,092 |  |
  (was, 2024-06-11, similarity 0.9557):
[0001571996-24-000062:note_history:21]
|  | May 3, 2024 |
|  | Fixed-term — Consumer and Commercial |  |  |  |  |
|  | Fiscal Year of Origination |  |  |  |  |
|  | 2025 |  | 2024 |  | 2023 |  | 2022 |  | 2021 |  | Years Prior |  | Revolving |  | Total |
|  | (in millions) |
| Higher | $ | 687 |  |  | $ | 2,827 |  |  | $ | 1,699 |  |  | $ | 683 |  |  | $ | 274 |  |  | $ | 46 |  |  | $ | 39 |  |  | $ | 6,255 |  |
| Mid | 237 |  |  | 1,030 |  |  | 783 |  |  | 202 |  |  | 55 |  |  | 13 |  |  | 49 |  |  | 2,369 |  |
| Lower | 764 |  |  | 578 |  |  | 374 |  |  | 143 |  |  | 61 |  |  | 14 |  |  | 75 |  |  | 2,009 |  |
| Total | $ | 1,688 |  |  | $ | 4,435 |  |  | $ | 2,856 |  |  | $ | 1,028 |  |  | $ | 390 |  |  | $ | 73 |  |  | $ | 163 |  |  | $ | 10,633 |  |

- changed (2024-09-10):
[0001571996-24-000090:note_history:22]
|  | February 2, 2024 |
|  | Fixed-term — Fiscal Year of Origination |  |  |  |  |  |  |
|  | 2024 |  | 2023 |  | 2022 |  | 2021 |  | 2020 |  | Years Prior |  |  |  | Revolving |  | Total |
|  | (in millions) |
| Higher | $ | 3,261 |  |  | $ | 1,979 |  |  | $ | 833 |  |  | $ | 345 |  |  | $ | 64 |  |  | $ | — |  |  |  |  | $ | 47 |  |  | $ | 6,529 |  |
| Mid | 1,111 |  |  | 911 |  |  | 290 |  |  | 86 |  |  | 19 |  |  | — |  |  |  |  | 50 |  |  | 2,467 |  |
| Lower | 703 |  |  | 469 |  |  | 187 |  |  | 80 |  |  | 21 |  |  | 1 |  |  |  |  | 76 |  |  | 1,537 |  |
| Total | $ | 5,075 |  |  | $ | 3,359 |  |  | $ | 1,310 |  |  | $ | 511 |  |  | $ | 104 |  |  | $ | 1 |  |  |  |  | $ | 173 |  |  | $ | 10,533 |  |
  (was, 2024-06-11, similarity 0.9625):
[0001571996-24-000062:note_history:22]
|  | February 2, 2024 |
|  | Fixed-term — Consumer and Commercial |  |  |  |  |  |  |
|  | Fiscal Year of Origination |  |  |  |  |  |  |
|  | 2024 |  | 2023 |  | 2022 |  | 2021 |  | 2020 |  | Years Prior |  |  |  | Revolving |  | Total |
|  | (in millions) |
| Higher | $ | 3,261 |  |  | $ | 1,979 |  |  | $ | 833 |  |  | $ | 345 |  |  | $ | 64 |  |  | $ | — |  |  |  |  | $ | 47 |  |  | $ | 6,529 |  |
| Mid | 1,111 |  |  | 911 |  |  | 290 |  |  | 86 |  |  | 19 |  |  | — |  |  |  |  | 50 |  |  | 2,467 |  |
| Lower | 703 |  |  | 469 |  |  | 187 |  |  | 80 |  |  | 21 |  |  | 1 |  |  |  |  | 76 |  |  | 1,537 |  |
| Total | $ | 5,075 |  |  | $ | 3,359 |  |  | $ | 1,310 |  |  | $ | 511 |  |  | $ | 104 |  |  | $ | 1 |  |  |  |  | $ | 173 |  |  | $ | 10,533 |  |

- changed (2024-09-10):
[0001571996-24-000090:note_history:23]
For the revolving receivables and fixed-term receivables shown in the tables above, an internal grading system is utilized that assigns a credit level score based on a number of considerations, including liquidity, operating performance, and industry outlook. The grading criteria and classifications for the fixed-term products differ from those for the revolving products as loss experience varies between these product and customer groups. The credit quality categories cannot be compared between the different classes as loss experience varies substantially between the classes.
  (was, 2024-06-11, similarity 0.9906):
[0001571996-24-000062:note_history:23]
For the revolving receivables and fixed-term commercial receivables shown in the tables above, an internal grading system is utilized that assigns a credit level score based on a number of considerations, including liquidity, operating performance, and industry outlook.  The grading criteria and classifications for the fixed-term products differ from those for the revolving products as loss experience varies between these product and customer groups.  The credit quality categories cannot be compared between the different classes as loss experience varies substantially between the classes.

- changed (2024-09-10):
[0001571996-24-000090:note_history:24]
|  | Three Months Ended |  | Six Months Ended |
|  | August 2, 2024 |  | August 4, 2023 |  | August 2, 2024 |  | August 4, 2023 |  |  |
|  | (in millions) |
| Net revenue — products | $ | 622 |  |  | $ | 292 |  |  | $ | 1,350 |  |  | $ | 539 |  |  |  |
| Cost of net revenue — products | 537 |  |  | 192 |  |  | 1,155 |  |  | 388 |  |  |  |
| Gross margin — products | $ | 85 |  |  | $ | 100 |  |  | $ | 195 |  |  | $ | 151 |  |  |  |
  (was, 2024-06-11, similarity 0.6445):
[0001571996-24-000062:note_history:24]
|  |  |  | Three Months Ended |
|  |  |  |  |  | May 3, 2024 |  | May 5, 2023 |  |  |
|  |  |  |  |  | (in millions) |
| Net revenue — products |  |  |  |  | $ | 728 |  |  | $ | 247 |  |  |  |
| Cost of net revenue — products |  |  |  |  | 618 |  |  | 196 |  |  |  |
| Gross margin — products |  |  |  |  | $ | 110 |  |  | $ | 51 |  |  |  |

- changed (2024-09-10):
[0001571996-24-000090:note_history:25]
|  | August 2, 2024 |
|  | (in millions) |
| Fiscal 2025 (remaining six months) | $ | 1,569 |  |
| Fiscal 2026 | 2,841 |  |
| Fiscal 2027 | 1,853 |  |
| Fiscal 2028 | 654 |  |
| Fiscal 2029 and beyond | 347 |  |
| Total undiscounted cash flows | 7,264 |  |
| Fixed-term loans | 4,810 |  |
| Revolving loans | 154 |  |
| Less: Unearned income | (1,136) |  |
| Total customer receivables, gross | $ | 11,092 |  |
  (was, 2024-06-11, similarity 0.6855):
[0001571996-24-000062:note_history:25]
|  | May 3, 2024 |
|  | (in millions) |
| Fiscal 2025 (remaining nine months) | $ | 852 |  |
| Fiscal 2026 | 819 |  |
| Fiscal 2027 | 443 |  |
| Fiscal 2028 | 169 |  |
| Fiscal 2029 and beyond | 60 |  |
| Total | $ | 2,343 |  |

- changed (2024-09-10):
[0001571996-24-000090:note_history:26]
|  | August 2, 2024 |  | February 2, 2024 |
|  | (in millions) |
| Equipment under operating lease, gross | $ | 4,064 |  |  | $ | 4,002 |  |
| Less: Accumulated depreciation | (1,871) |  |  | (1,800) |  |
| Equipment under operating lease, net | $ | 2,193 |  |  | $ | 2,202 |  |
  (was, 2024-06-11, similarity 0.9806):
[0001571996-24-000062:note_history:26]
|  | May 3, 2024 |  | February 2, 2024 |
|  | (in millions) |
| Equipment under operating lease, gross | $ | 3,951 |  |  | $ | 4,002 |  |
| Less: Accumulated depreciation | (1,827) |  |  | (1,800) |  |
| Equipment under operating lease, net | $ | 2,124 |  |  | $ | 2,202 |  |

- added (2024-09-10):
[0001571996-24-000090:note_history:27]
|  | Three Months Ended |  | Six Months Ended |
|  | August 2, 2024 |  | August 4, 2023 |  | August 2, 2024 |  | August 4, 2023 |  |  |
|  | (in millions) |
| Income related to lease payments | $ | 362 |  |  | $ | 330 |  |  | $ | 718 |  |  | $ | 651 |  |  |  |
| Depreciation expense | $ | 245 |  |  | $ | 236 |  |  | $ | 485 |  |  | $ | 469 |  |  |  |

- added (2024-09-10):
[0001571996-24-000090:note_history:28]
|  | August 2, 2024 |
|  | (in millions) |
| Fiscal 2025 (remaining six months) | $ | 582 |  |
| Fiscal 2026 | 897 |  |
| Fiscal 2027 | 517 |  |
| Fiscal 2028 | 208 |  |
| Fiscal 2029 and beyond | 77 |  |
| Total | $ | 2,281 |  |

- changed (2024-09-10):
[0001571996-24-000090:note_history:29]
The Company maintains programs that facilitate the funding of leases, loans, and other alternative payment structures in the capital markets. The majority of DFS debt is non-recourse to Dell Technologies and represents borrowings under securitization programs and structured financing programs for which the Company’s risk of loss is limited to transferred loan and lease payments and associated equipment.
  (was, 2024-06-11, similarity 0.9988):
[0001571996-24-000062:note_history:29]
The Company maintains programs that facilitate the funding of leases, loans, and other alternative payment structures in the capital markets.  The majority of DFS debt is non-recourse to Dell Technologies and represents borrowings under securitization programs and structured financing programs, for which the Company’s risk of loss is limited to transferred loan and lease payments and associated equipment.

- added (2024-09-10):
[0001571996-24-000090:note_history:30]
|  | August 2, 2024 |  | February 2, 2024 |
| DFS debt | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing facility | $ | 3,067 |  |  | $ | 2,730 |  |
| Fixed-term securitization offerings | 2,841 |  |  | 3,157 |  |
| Other | 25 |  |  | 28 |  |
| Total DFS U.S. debt, principal amount | 5,933 |  |  | 5,915 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 704 |  |  | 761 |  |
| Other borrowings | 877 |  |  | 935 |  |
| Note payable | — |  |  | 250 |  |
| Dell Bank senior unsecured eurobonds | 1,619 |  |  | 1,631 |  |
| Total DFS international debt, principal amount | 3,200 |  |  | 3,577 |  |
| Total DFS debt, principal amount | $ | 9,133 |  |  | $ | 9,492 |  |
| Total short-term DFS debt | $ | 5,682 |  |  | $ | 5,863 |  |
| Total long-term DFS debt | $ | 3,451 |  |  | $ | 3,629 |  |

- changed (2024-09-10):
[0001571996-24-000090:note_history:31]
Asset-Based Financing Facility — The Company maintains an asset-based financing facility in the United States, which is a revolving facility for fixed-term leases and loans. This debt is collateralized solely by the U.S. loan and lease payments and associated equipment in the facility. The asset-based financing facility consists of two tranches, with effective dates through July 7, 2025 and July 7, 2026. As of August 2, 2024, the total debt capacity related to the asset-based financing facility was $5.0 billion. The debt has a variable interest rate, and the duration of the debt is based on the terms of the underlying loan and lease payment streams. The Company enters into interest swap agreements to effectively convert a portion of this debt from a floating rate to a fixed rate. See Note 7 of the Notes to the Condensed Consolidated Financial Statements for additional information about the Company’s interest rate swaps.
  (was, 2024-06-11, similarity 0.9302):
[0001571996-24-000062:note_history:31]
Asset-Based Financing Facility — During the three months ended May 3, 2024, the Company consolidated its two separate asset-based financing facilities into a single asset-based financing facility in the United States, which is a revolving facility for fixed-term leases and loans.  This debt is collateralized solely by the U.S. loan and lease payments and associated equipment in the facility.   The asset-based financing facility consists of two tranches, with effective dates through July 7, 2025 and July 7, 2026.  As of May 3, 2024, the total debt capacity related to the asset-based financing facility was $5.0 billion.  The debt has a variable interest rate, and the duration of the debt is based on the terms of the underlying loan and lease payment streams.  The Company enters into interest swap agreements to effectively convert a portion of this debt from a floating rate to a fixed rate.  See Note 7 of the Notes to the Condensed Consolidated Financial Statements for additional information about the Company’s interest rate swaps.

- changed (2024-09-10):
[0001571996-24-000090:note_history:32]
The asset-based financing facility contains standard structural features related to the performance of the funded receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements. In the event one or more of these criteria are not met and the Company is unable to restructure the facility, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed. As of August 2, 2024, these criteria were met.
  (was, 2024-06-11, similarity 0.9916):
[0001571996-24-000062:note_history:32]
The asset-based financing facility contains standard structural features related to the performance of the funded receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the facility, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of May 3, 2024, these criteria were met.

- changed (2024-09-10):
[0001571996-24-000090:note_history:33]
Fixed-Term Securitization Offerings — The Company periodically issues asset-backed debt securities under fixed-term securitization programs to private investors. The asset-backed debt securities are collateralized solely by the U.S. fixed-term lease and loan payments and associated equipment, which are held by Special Purpose Entities (“SPEs”), as discussed below. The interest rate on these securities is fixed and ranges from 2.49% to 6.80% per annum as of August 2, 2024, and the duration of these securities is based on the terms of the underlying lease and loan payment streams.
  (was, 2024-06-11, similarity 0.8507):
[0001571996-24-000062:note_history:33]
Fixed-Term Securitization Offerings — The Company periodically issues asset-backed debt securities under fixed-term securitization programs to private investors.  The asset-backed debt securities are collateralized solely by the U.S. fixed-term lease and loan payments and associated equipment, which are held by Special Purpose Entities (“SPEs”), as discussed below.  The interest rate on these securities is fixed and ranged from 2.49% to 6.80% per annum as of May 3, 2024, and the duration of these securities is based on the terms of the underlying lease and loan payment streams.

- changed (2024-09-10):
[0001571996-24-000090:note_history:34]
Securitization Facility — The Company maintains a securitization facility in Europe for fixed-term leases and loans. The debt under this facility has a variable interest rate, and the duration of the debt is based on the terms of the underlying loan and lease payment streams. This facility is effective through December 23, 2024 and had a total debt capacity of $863 million as of August 2, 2024.
  (was, 2024-06-11, similarity 0.9778):
[0001571996-24-000062:note_history:34]
Securitization Facility — The Company maintains a securitization facility in Europe for fixed-term leases and loans.  The debt under this facility has a variable interest rate, and the duration of the debt is based on the terms of the underlying loan and lease payment streams.  This facility is effective through December 23, 2024 and had a total debt capacity of $858 million as of May 3, 2024.

- changed (2024-09-10):
[0001571996-24-000090:note_history:35]
The securitization facility contains standard structural features related to the performance of the securitized receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements. In the event one or more of these criteria are not met and the Company is unable to restructure the program, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed. As of August 2, 2024, these criteria were met.
  (was, 2024-06-11, similarity 0.9916):
[0001571996-24-000062:note_history:35]
The securitization facility contains standard structural features related to the performance of the securitized receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the program, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of May 3, 2024, these criteria were met.

- added (2024-09-10):
[0001571996-24-000090:note_history:36]
Other Borrowings — In connection with the Company’s international financing operations, the Company has entered into revolving structured financing debt programs related to its fixed-term lease and loan products sold in Canada, Europe, Australia, New Zealand, the Middle East, and Singapore. The debt under these programs has a variable interest rate.

- added (2024-09-10):
[0001571996-24-000090:note_history:37]
The duration of the debt in Canada, Europe, Australia, New Zealand, and the Middle East is based on the terms of the underlying loan and lease payment streams. These facilities are collateralized solely by the loan and lease payments and associated equipment in their respective region or country. The Canadian facility had a total debt capacity of $324 million as of August 2, 2024 and is effective through January 16, 2025. The European facility had a total debt capacity of $540 million as of August 2, 2024 and is effective through December 14, 2026. The Australia and New Zealand facility had a total debt capacity of $293 million as of August 2, 2024 and is effective through April 20, 2025. The Middle East facility had a total debt capacity of $150 million as of August 2, 2024 and is effective through March 24, 2025.

- added (2024-09-10):
[0001571996-24-000090:note_history:38]
On July 3, 2024, the Company entered into two unsecured revolving credit agreements to fund receivables in Singapore. The Singapore facilities have a total debt capacity of $247 million as of August 2, 2024 and are effective through July 3, 2026 and July 3, 2027, respectively.

- changed (2024-09-10):
[0001571996-24-000090:note_history:39]
Note Payable — On May 25, 2022, the Company entered into an unsecured credit agreement which had an aggregate principal amount of $250 million to fund receivables in Mexico. The note bore interest at an annual rate of 4.24% and was paid in full on May 31, 2024.
  (was, 2024-06-11, similarity 0.6565):
[0001571996-24-000062:note_history:39]
Note Payable — On May 25, 2022, the Company entered into an unsecured credit agreement to fund receivables in Mexico.  As of May 3, 2024, the aggregate principal amount of the note payable was $250 million.  The note bore interest at an annual rate of 4.24% and matured and was paid in full on May 31, 2024.

- changed (2024-09-10):
[0001571996-24-000090:note_history:40]
Dell Bank Senior Unsecured Eurobonds — On October 27, 2021, Dell Bank issued 500 million Euro of 0.5% senior unsecured five year eurobonds due October 2026. On October 18, 2022, Dell Bank issued 500 million Euro of 4.5% senior unsecured five year eurobonds due October 2027. On June 13, 2024, Dell Bank issued 500 million Euro of 3.6% senior unsecured five year eurobonds due June 2029. The issuances of the senior unsecured eurobonds support the expansion of the financing operations in Europe.
  (was, 2024-06-11, similarity 0.7682):
[0001571996-24-000062:note_history:40]
Dell Bank Senior Unsecured Eurobonds — On June 24, 2020, Dell Bank issued 500 million Euro of 1.625% senior unsecured four year eurobonds due June 2024.  On October 27, 2021, Dell Bank issued 500 million Euro of 0.5% senior unsecured five year eurobonds due October 2026.  On October 18, 2022, Dell Bank issued 500 million Euro of 4.5% senior unsecured five year eurobonds due October 2027.  The issuances of the senior unsecured eurobonds support the expansion of the financing operations in Europe.

- changed (2024-09-10):
[0001571996-24-000090:note_history:41]
|  | August 2, 2024 |  | February 2, 2024 |
|  | (in millions) |
| Assets held by consolidated VIEs |  |  |  |
| Other current assets | $ | 115 |  |  | $ | 136 |  |
| Financing receivables, net of allowance |  |  |  |
| Short-term | $ | 3,284 |  |  | $ | 3,314 |  |
| Long-term | $ | 2,935 |  |  | $ | 2,747 |  |
| Property, plant, and equipment, net | $ | 1,022 |  |  | $ | 1,081 |  |
| Liabilities held by consolidated VIEs |  |  |  |
| Debt, net of unamortized debt issuance costs |  |  |  |
| Short-term | $ | 4,942 |  |  | $ | 4,450 |  |
| Long-term | $ | 1,670 |  |  | $ | 2,184 |  |
  (was, 2024-06-11, similarity 0.991):
[0001571996-24-000062:note_history:41]
|  | May 3, 2024 |  | February 2, 2024 |
|  | (in millions) |
| Assets held by consolidated VIEs |  |  |  |
| Other current assets | $ | 124 |  |  | $ | 136 |  |
| Financing receivables, net of allowance |  |  |  |
| Short-term | $ | 3,140 |  |  | $ | 3,314 |  |
| Long-term | $ | 2,752 |  |  | $ | 2,747 |  |
| Property, plant, and equipment, net | $ | 1,031 |  |  | $ | 1,081 |  |
| Liabilities held by consolidated VIEs |  |  |  |
| Debt, net of unamortized debt issuance costs |  |  |  |
| Short-term | $ | 3,553 |  |  | $ | 4,450 |  |
| Long-term | $ | 2,804 |  |  | $ | 2,184 |  |

- changed (2024-09-10):
[0001571996-24-000090:note_history:42]
Lease and loan payments and associated equipment transferred via securitization through SPEs were $1.2 billion and $1.1 billion for the three months ended August 2, 2024 and August 4, 2023, respectively, and $2.0 billion and $2.6 billion for the six months ended August 2, 2024 and August 4, 2023, respectively.
  (was, 2024-06-11, similarity 0.7719):
[0001571996-24-000062:note_history:42]
Lease and loan payments and associated equipment transferred via securitization through SPEs were $0.8 billion and $1.5 billion for the three months ended May 3, 2024 and May 5, 2023, respectively.

- changed (2024-09-10):
[0001571996-24-000090:note_history:43]
To manage certain concentrations of customer credit exposure, the Company may sell selected fixed-term customer receivables to unrelated third parties on a periodic basis, without recourse. The amount of customer receivables sold for this purpose was $69 million and $187 million for the six months ended August 2, 2024 and August 4, 2023, respectively. The Company’s continuing involvement in these customer receivables is primarily limited to servicing arrangements.
  (was, 2024-06-11, similarity 0.6344):
[0001571996-24-000062:note_history:43]
To manage certain concentrations of customer credit exposure, the Company may sell selected fixed-term customer receivables to unrelated third parties on a periodic basis, without recourse.  The amount of customer receivables sold for this purpose was $67 million and $169 million for the three months ended May 3, 2024 and May 5, 2023, respectively.  The Company’s continuing involvement in these customer receivables is primarily limited to servicing arrangements.

- removed (2024-09-10):
[0001571996-24-000062:note_history:44]
|  | May 3, 2024 |  | February 2, 2024 |
|  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |
|  | (in millions) |
| Revolving | $ | 142 |  |  | $ | 17 |  |  | $ | 4 |  |  | $ | 163 |  |  | $ | 151 |  |  | $ | 17 |  |  | $ | 5 |  |  | $ | 173 |  |
| Fixed-term — Consumer and Commercial | 9,477 |  |  | 891 |  |  | 102 |  |  | 10,470 |  |  | 9,345 |  |  | 889 |  |  | 126 |  |  | 10,360 |  |
| Total customer receivables, gross | $ | 9,619 |  |  | $ | 908 |  |  | $ | 106 |  |  | $ | 10,633 |  |  | $ | 9,496 |  |  | $ | 906 |  |  | $ | 131 |  |  | $ | 10,533 |  |

- removed (2024-09-10):
[0001571996-24-000062:note_history:45]
|  | May 3, 2024 |
|  | (in millions) |
| Fiscal 2025 (remaining nine months) | $ | 2,109 |  |
| Fiscal 2026 | 2,416 |  |
| Fiscal 2027 | 1,529 |  |
| Fiscal 2028 | 522 |  |
| Fiscal 2029 and beyond | 226 |  |
| Total undiscounted cash flows | 6,802 |  |
| Fixed-term loans | 4,740 |  |
| Revolving loans | 163 |  |
| Less: Unearned income | (1,072) |  |
| Total customer receivables, gross | $ | 10,633 |  |

- removed (2024-09-10):
[0001571996-24-000062:note_history:46]
|  |  |  | Three Months Ended |
|  |  |  |  |  | May 3, 2024 |  | May 5, 2023 |  |  |
|  |  |  |  |  | (in millions) |
| Income related to lease payments |  |  |  |  | $ | 356 |  |  | $ | 321 |  |  |  |
| Depreciation expense |  |  |  |  | $ | 240 |  |  | $ | 233 |  |  |  |

- removed (2024-09-10):
[0001571996-24-000062:note_history:47]
|  | May 3, 2024 |  | February 2, 2024 |
| DFS debt | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing facility | $ | 2,331 |  |  | $ | 2,730 |  |
| Fixed-term securitization offerings | 3,305 |  |  | 3,157 |  |
| Other | 26 |  |  | 28 |  |
| Total DFS U.S. debt, principal amount | 5,662 |  |  | 5,915 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 720 |  |  | 761 |  |
| Other borrowings | 797 |  |  | 935 |  |
| Note payable | 250 |  |  | 250 |  |
| Dell Bank senior unsecured eurobonds | 1,609 |  |  | 1,631 |  |
| Total DFS international debt, principal amount | 3,376 |  |  | 3,577 |  |
| Total DFS debt, principal amount | $ | 9,038 |  |  | $ | 9,492 |  |
| Total short-term DFS debt | $ | 5,038 |  |  | $ | 5,863 |  |
| Total long-term DFS debt | $ | 4,000 |  |  | $ | 3,629 |  |

- removed (2024-09-10):
[0001571996-24-000062:note_history:48]
Other Borrowings — In connection with the Company’s international financing operations, the Company has entered into revolving structured financing debt programs related to its fixed-term lease and loan products sold in Canada, Europe, Australia, New Zealand, and the Middle East.  The debt under these programs has a variable interest rate, and the duration of the debt is based on the terms of the underlying loan and lease payment streams.  The Canadian facility, which is collateralized solely by Canadian loan and lease payments and associated equipment, had a total debt capacity of $329 million as of May 3, 2024 and is effective through January 16, 2025.  The European facility, which is collateralized solely by European loan and lease payments and associated equipment, had a total debt capacity of $536 million as of May 3, 2024 and is effective through June 14, 2025.  The Australia and New Zealand facility, which is collateralized solely by Australia and New Zealand loan and lease payments and associated equipment, had a total debt capacity of $295 million as of May 3, 2024 and is effective through April 20, 2025.  The Middle East facility, which is collateralized solely by Middle East loan and lease payments and associated equipment, had a total debt capacity of $150 million as of May 3, 2024 and is effective through March 24, 2025.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-09-10):
[0001571996-24-000090:note_history:49]
|  | August 2, 2024 |  | February 2, 2024 |
|  | (in millions) |
| Senior Notes | $ | 14,580 |  |  | $ | 15,607 |  |
| Legacy Notes | 952 |  |  | 952 |  |
| DFS Debt (Note 4) | 9,133 |  |  | 9,492 |  |
| Other | 79 |  |  | 171 |  |
| Total debt, principal amount | 24,744 |  |  | 26,222 |  |
| Unamortized discount, net of unamortized premium | (112) |  |  | (114) |  |
| Debt issuance costs | (110) |  |  | (114) |  |
| Total debt, carrying value | $ | 24,522 |  |  | $ | 25,994 |  |
| Total short-term debt, carrying value | $ | 6,711 |  |  | $ | 6,982 |  |
| Total long-term debt, carrying value | $ | 17,811 |  |  | $ | 19,012 |  |
  (was, 2024-06-11, similarity 0.9914):
[0001571996-24-000062:note_history:49]
|  | May 3, 2024 |  | February 2, 2024 |
|  | (in millions) |
| Senior Notes | $ | 15,607 |  |  | $ | 15,607 |  |
| Legacy Notes | 952 |  |  | 952 |  |
| DFS Debt (Note 4) | 9,038 |  |  | 9,492 |  |
| Other | 108 |  |  | 171 |  |
| Total debt, principal amount | 25,705 |  |  | 26,222 |  |
| Unamortized discount, net of unamortized premium | (111) |  |  | (114) |  |
| Debt issuance costs | (114) |  |  | (114) |  |
| Total debt, carrying value | $ | 25,480 |  |  | $ | 25,994 |  |
| Total short-term debt, carrying value | $ | 6,098 |  |  | $ | 6,982 |  |
| Total long-term debt, carrying value | $ | 19,382 |  |  | $ | 19,012 |  |

- added (2024-09-10):
[0001571996-24-000090:note_history:50]
The Company completed the following transactions during the six months ended August 2, 2024:

- changed (2024-09-10):
[0001571996-24-000090:note_history:51]
•the issuance of $1 billion principal amount of 5.40% Senior Notes due April 2034, the proceeds of which were utilized to prepay a portion of the outstanding 6.02% Senior Notes due June 2026; and
  (was, 2024-06-11, similarity 0.6068):
[0001571996-24-000062:note_history:51]
During the three months ended May 3, 2024, the Company issued $1.0 billion aggregate principal amount of 5.40% Senior Notes due 2034.  The Company used the net proceeds of the issuance to prepay a portion of the outstanding 6.02% Senior Notes due 2026.

- added (2024-09-10):
[0001571996-24-000090:note_history:52]
•the repayment of $1 billion principal amount of the 4.00% Senior Notes due July 2024.

- changed (2024-09-10):
[0001571996-24-000090:note_history:53]
Senior Notes — The Company completed offerings of multiple series of senior notes which were issued on June 1, 2016, June 22, 2016, March 20, 2019, April 9, 2020, December 13, 2021, January 24, 2023 and March 18, 2024 in aggregate principal amounts of $20.0 billion, $3.3 billion, $4.5 billion, $2.3 billion, $2.3 billion, $2.0 billion and $1.0 billion, respectively (collectively, the “Senior Notes”). The Senior Notes maturities range from 2025 through 2051. Interest rates on these borrowings are fixed, ranging from 3.38% to 8.35%, and interest is payable semiannually.
  (was, 2024-06-11, similarity 0.986):
[0001571996-24-000062:note_history:53]
Senior Notes — The Company completed offerings of multiple series of senior notes which were issued on June 1, 2016, June 22, 2016, March 20, 2019, April 9, 2020, December 13, 2021, January 24, 2023 and March 18, 2024 in aggregate principal amounts of $20.0 billion, $3.3 billion, $4.5 billion, $2.3 billion, $2.3 billion, $2.0 billion and $1.0 billion, respectively (the “Senior Notes”).  The Senior Notes maturities range from 2024 through 2051.  Interest rates on these borrowings are fixed, ranging from 3.38% to 8.35%, and interest is payable semiannually.

- changed (2024-09-10):
[0001571996-24-000090:note_history:54]
As of August 2, 2024, the Company had no outstanding borrowings under the revolving credit facility.
  (was, 2024-06-11, similarity 0.9626):
[0001571996-24-000062:note_history:54]
As of May 3, 2024, the Company had no outstanding borrowings under the revolving credit facility.

- changed (2024-09-10):
[0001571996-24-000090:note_history:55]
Commercial Paper Program — The Company maintains a commercial paper program under which the Company may issue unsecured notes in a maximum aggregate face amount of $5.0 billion outstanding at any time, with maturities up to 397 days from the date of issuance. The notes are sold on customary terms in the U.S. commercial paper market on a private placement basis. The proceeds of the notes are used for general corporate purposes. As of August 2, 2024, the Company had no outstanding issuances under the commercial paper program.
  (was, 2024-06-11, similarity 0.9913):
[0001571996-24-000062:note_history:55]
Commercial Paper Program — The Company maintains a commercial paper program under which the Company may issue unsecured notes in a maximum aggregate face amount of $5.0 billion outstanding at any time, with maturities up to 397 days from the date of issuance.  The notes are sold on customary terms in the U.S. commercial paper market on a private placement basis.  The proceeds of the notes are used for general corporate purposes.  As of May 3, 2024, the Company had no outstanding issuances under the commercial paper program.

- changed (2024-09-10):
[0001571996-24-000090:note_history:56]
Covenants — The credit agreement governing the revolving credit facility and the indentures governing the Senior Notes and the Legacy Notes impose various limitations, subject to exceptions, on creating certain liens and entering into sale and lease-back transactions. The foregoing credit agreement and indentures contain customary events of default, and the revolving credit facility is subject to an interest coverage ratio covenant that is tested at the end of each fiscal quarter with respect to the Company’s preceding four fiscal quarters. The Company was in compliance with this financial covenant as of August 2, 2024.
  (was, 2024-06-11, similarity 0.9927):
[0001571996-24-000062:note_history:56]
Covenants — The credit agreement governing the revolving credit facility and the indentures governing the Senior Notes and the Legacy Notes impose various limitations, subject to exceptions, on creating certain liens and entering into sale and lease-back transactions.  The foregoing credit agreement and indentures contain customary events of default, and the revolving credit facility is subject to an interest coverage ratio covenant that is tested at the end of each fiscal quarter with respect to the Company’s preceding four fiscal quarters.  The Company was in compliance with this financial covenant as of May 3, 2024.

- changed (2024-09-10):
[0001571996-24-000090:note_history:57]
The following table presents the aggregate future maturities of the Company’s debt as of August 2, 2024, excluding associated carrying value adjustments, for the periods indicated:
  (was, 2024-06-11, similarity 0.9798):
[0001571996-24-000062:note_history:57]
The following table presents the aggregate future maturities of the Company’s debt as of May 3, 2024, excluding associated carrying value adjustments, for the periods indicated:

- added (2024-09-10):
[0001571996-24-000090:note_history:58]
|  | August 2, 2024 |
|  | (in millions) |
| Fiscal 2025 (remaining six months) | $ | 2,796 |  |
| Fiscal 2026 | 4,567 |  |
| Fiscal 2027 | 5,838 |  |
| Fiscal 2028 | 1,195 |  |
| Fiscal 2029 | 1,326 |  |
| Thereafter | 9,022 |  |
| Total maturities, principal amount | $ | 24,744 |  |

- removed (2024-09-10):
[0001571996-24-000062:note_history:59]
|  | May 3, 2024 |
|  | (in millions) |
| Fiscal 2025 (remaining nine months) | $ | 5,248 |  |
| Fiscal 2026 | 3,867 |  |
| Fiscal 2027 | 5,560 |  |
| Fiscal 2028 | 1,194 |  |
| Fiscal 2029 | 1,327 |  |
| Thereafter | 8,509 |  |
| Total maturities, principal amount | $ | 25,705 |  |


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-09-10):
[0001571996-24-000090:note_history:60]
|  | August 2, 2024 |  | February 2, 2024 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Notes | $ | 14.5 |  |  | $ | 14.9 |  |  | $ | 15.5 |  |  | $ | 15.8 |  |
| Legacy Notes | $ | 0.9 |  |  | $ | 1.0 |  |  | $ | 0.9 |  |  | $ | 1.0 |  |
| DFS Debt | $ | 9.1 |  |  | $ | 8.8 |  |  | $ | 9.5 |  |  | $ | 9.1 |  |
  (was, 2024-06-11, similarity 0.9853):
[0001571996-24-000062:note_history:60]
|  | May 3, 2024 |  | February 2, 2024 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Notes | $ | 15.5 |  |  | $ | 15.5 |  |  | $ | 15.5 |  |  | $ | 15.8 |  |
| Legacy Notes | $ | 0.9 |  |  | $ | 1.0 |  |  | $ | 0.9 |  |  | $ | 1.0 |  |
| DFS Debt | $ | 9.0 |  |  | $ | 8.6 |  |  | $ | 9.5 |  |  | $ | 9.1 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2024-09-10):
[0001571996-24-000090:note_history:61]
|  | August 2, 2024 |  | February 2, 2024 |
| DFS debt | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing facility | $ | 3,067 |  |  | $ | 2,730 |  |
| Fixed-term securitization offerings | 2,841 |  |  | 3,157 |  |
| Other | 25 |  |  | 28 |  |
| Total DFS U.S. debt, principal amount | 5,933 |  |  | 5,915 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 704 |  |  | 761 |  |
| Other borrowings | 877 |  |  | 935 |  |
| Note payable | — |  |  | 250 |  |
| Dell Bank senior unsecured eurobonds | 1,619 |  |  | 1,631 |  |
| Total DFS international debt, principal amount | 3,200 |  |  | 3,577 |  |
| Total DFS debt, principal amount | $ | 9,133 |  |  | $ | 9,492 |  |
| Total short-term DFS debt | $ | 5,682 |  |  | $ | 5,863 |  |
| Total long-term DFS debt | $ | 3,451 |  |  | $ | 3,629 |  |

- changed (2024-09-10):
[0001571996-24-000090:note_history:62]
|  | August 2, 2024 |  | February 2, 2024 |
|  | (in millions) |
| Senior Notes | $ | 14,580 |  |  | $ | 15,607 |  |
| Legacy Notes | 952 |  |  | 952 |  |
| DFS Debt (Note 4) | 9,133 |  |  | 9,492 |  |
| Other | 79 |  |  | 171 |  |
| Total debt, principal amount | 24,744 |  |  | 26,222 |  |
| Unamortized discount, net of unamortized premium | (112) |  |  | (114) |  |
| Debt issuance costs | (110) |  |  | (114) |  |
| Total debt, carrying value | $ | 24,522 |  |  | $ | 25,994 |  |
| Total short-term debt, carrying value | $ | 6,711 |  |  | $ | 6,982 |  |
| Total long-term debt, carrying value | $ | 17,811 |  |  | $ | 19,012 |  |
  (was, 2024-06-11, similarity 0.9914):
[0001571996-24-000062:note_history:62]
|  | May 3, 2024 |  | February 2, 2024 |
|  | (in millions) |
| Senior Notes | $ | 15,607 |  |  | $ | 15,607 |  |
| Legacy Notes | 952 |  |  | 952 |  |
| DFS Debt (Note 4) | 9,038 |  |  | 9,492 |  |
| Other | 108 |  |  | 171 |  |
| Total debt, principal amount | 25,705 |  |  | 26,222 |  |
| Unamortized discount, net of unamortized premium | (111) |  |  | (114) |  |
| Debt issuance costs | (114) |  |  | (114) |  |
| Total debt, carrying value | $ | 25,480 |  |  | $ | 25,994 |  |
| Total short-term debt, carrying value | $ | 6,098 |  |  | $ | 6,982 |  |
| Total long-term debt, carrying value | $ | 19,382 |  |  | $ | 19,012 |  |

- removed (2024-09-10):
[0001571996-24-000062:note_history:63]
|  | May 3, 2024 |  | February 2, 2024 |
| DFS debt | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing facility | $ | 2,331 |  |  | $ | 2,730 |  |
| Fixed-term securitization offerings | 3,305 |  |  | 3,157 |  |
| Other | 26 |  |  | 28 |  |
| Total DFS U.S. debt, principal amount | 5,662 |  |  | 5,915 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 720 |  |  | 761 |  |
| Other borrowings | 797 |  |  | 935 |  |
| Note payable | 250 |  |  | 250 |  |
| Dell Bank senior unsecured eurobonds | 1,609 |  |  | 1,631 |  |
| Total DFS international debt, principal amount | 3,376 |  |  | 3,577 |  |
| Total DFS debt, principal amount | $ | 9,038 |  |  | $ | 9,492 |  |
| Total short-term DFS debt | $ | 5,038 |  |  | $ | 5,863 |  |
| Total long-term DFS debt | $ | 4,000 |  |  | $ | 3,629 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-09-10):
[0001571996-24-000090:note_history:64]
The following table presents the aggregate future maturities of the Company’s debt as of August 2, 2024, excluding associated carrying value adjustments, for the periods indicated:
  (was, 2024-06-11, similarity 0.9798):
[0001571996-24-000062:note_history:64]
The following table presents the aggregate future maturities of the Company’s debt as of May 3, 2024, excluding associated carrying value adjustments, for the periods indicated:

- added (2024-09-10):
[0001571996-24-000090:note_history:65]
|  | August 2, 2024 |
|  | (in millions) |
| Fiscal 2025 (remaining six months) | $ | 2,796 |  |
| Fiscal 2026 | 4,567 |  |
| Fiscal 2027 | 5,838 |  |
| Fiscal 2028 | 1,195 |  |
| Fiscal 2029 | 1,326 |  |
| Thereafter | 9,022 |  |
| Total maturities, principal amount | $ | 24,744 |  |

- removed (2024-09-10):
[0001571996-24-000062:note_history:66]
|  | May 3, 2024 |
|  | (in millions) |
| Fiscal 2025 (remaining nine months) | $ | 5,248 |  |
| Fiscal 2026 | 3,867 |  |
| Fiscal 2027 | 5,560 |  |
| Fiscal 2028 | 1,194 |  |
| Fiscal 2029 | 1,327 |  |
| Thereafter | 8,509 |  |
| Total maturities, principal amount | $ | 25,705 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2024-09-10):
[0001571996-24-000090:note_history:67]
RELATED PARTY TRANSACTIONS 
Prior to the acquisition on November 22, 2023 of VMware LLC (previously VMware, Inc. and individually and together with its consolidated subsidiaries, “VMware”) by Broadcom Inc. (“Broadcom”), VMware was considered a related party of the Company. Upon Broadcom’s acquisition of VMware, Mr. Dell’s ownership interest in VMware and his position as Chairman of the Board of VMware terminated, and the Company determined no related party relationship exists with Broadcom or VMware effective as of November 22, 2023. The information provided below includes a summary of related party transactions with VMware for the three and six months ended August 4, 2023. The Company continues to engage in select transactions with VMware following the completion of Broadcom’s acquisition and the termination of the related party relationship. See Note 16 of the Notes to the Condensed Consolidated Financial Statements for additional information.
  (was, 2024-06-11, similarity 0.9715):
[0001571996-24-000062:note_history:67]
RELATED PARTY TRANSACTIONS 
Prior to the acquisition on November 22, 2023 of VMware LLC (previously VMware, Inc. and individually and together with its consolidated subsidiaries, “VMware”) by Broadcom Inc. (“Broadcom”), VMware was considered a related party of the Company.  Upon Broadcom’s acquisition of VMware, Mr. Dell’s ownership interest in VMware and his position as Chairman of the Board of VMware terminated, and the Company determined no related party relationship exists with Broadcom or VMware effective as of November 22, 2023.  The information provided below includes a summary of related party transactions with VMware for the three months ended May 5, 2023.  The Company continues to engage in select transactions with VMware following the completion of Broadcom’s acquisition and the termination of the related party relationship.  See Note 16 of the Notes to the Consolidated Financial Statements for additional information.

- changed (2024-09-10):
[0001571996-24-000090:note_history:68]
•Dell Technologies procured products and services from VMware for its internal use. For the three and six months ended August 4, 2023, costs incurred associated with products and services purchased from VMware for internal use were immaterial.
  (was, 2024-06-11, similarity 0.9075):
[0001571996-24-000062:note_history:68]
•Dell Technologies procured products and services from VMware for its internal use.  For the three months ended  May 5, 2023, costs incurred associated with products and services purchased from VMware for internal use were immaterial.

- changed (2024-09-10):
[0001571996-24-000090:note_history:69]
•Dell Technologies sold and leased products and sold services to VMware. For the three and six months ended August 4, 2023, revenue recognized from sales of services to VMware was immaterial.
  (was, 2024-06-11, similarity 0.9584):
[0001571996-24-000062:note_history:69]
•Dell Technologies sold and leased products and sold services to VMware.  For the three months ended May 5, 2023,  revenue recognized from sales of services to VMware was immaterial.

- changed (2024-09-10):
[0001571996-24-000090:note_history:70]
•Dell Technologies and VMware entered into joint marketing, sales, and branding arrangements, for which both parties incurred costs. For the three and six months ended August 4, 2023, consideration received from VMware for joint marketing, sales, and branding arrangements was immaterial.
  (was, 2024-06-11, similarity 0.9225):
[0001571996-24-000062:note_history:70]
•Dell Technologies and VMware entered into joint marketing, sales, and branding arrangements, for which both parties incurred costs.  For the three months ended May 5, 2023, consideration received from VMware for joint marketing, sales, and branding arrangements was immaterial.

- changed (2024-09-10):
[0001571996-24-000090:note_history:71]
The following table presents information about the impact of Dell Technologies’ related party transactions with VMware on the Consolidated Statements of Income for the three and six months ended August 4, 2023:
  (was, 2024-06-11, similarity 0.9626):
[0001571996-24-000062:note_history:71]
The following table presents information about the impact of Dell Technologies’ related party transactions with VMware on the Consolidated Statements of Income for the three months ended May 5, 2023:

- added (2024-09-10):
[0001571996-24-000090:note_history:72]
|  |  |  |  |  | Three Months Ended |  |  |  | Six Months Ended |
|  | Classification |  |  |  | August 4, 2023 |  |  |  | August 4, 2023 |  |  |
|  |  |  |  |  | (in millions) |
| Sales and leases of products to VMware | Net revenue - products |  |  |  | $ | 38 |  |  |  |  | $ | 78 |  |  |  |
| Purchase of VMware products for resale | Cost of net revenue - products |  |  |  | $ | 384 |  |  |  |  | $ | 591 |  |  |  |
| Purchase of VMware services for resale | Cost of net revenue - services |  |  |  | $ | 880 |  |  |  |  | $ | 1,756 |  |  |  |

- changed (2024-09-10):
[0001571996-24-000090:note_history:73]
In connection with the completion of the VMware Spin-off, Dell Technologies and VMware entered into a Tax Matters Agreement effective as of April 14, 2021 (the “Tax Matters Agreement”), which governs the respective rights and obligations of Dell Technologies and VMware regarding income and other taxes as well as related matters, including tax liabilities and benefits, attributes, and returns for periods both preceding and following the VMware Spin-off. Pursuant to the Tax Matters Agreement, net receipts from VMware during the six months ended August 4, 2023 were immaterial.
  (was, 2024-06-11, similarity 0.9439):
[0001571996-24-000062:note_history:73]
In connection with the completion of the VMware Spin-off, Dell Technologies and VMware entered into a Tax Matters Agreement effective as of April 14, 2021 (the “Tax Matters Agreement”) which governs the respective rights and obligations of Dell Technologies and VMware regarding income and other taxes as well as related matters, including tax liabilities and benefits, attributes, and returns for periods both preceding and proceeding the VMware Spin-off.  Pursuant to the Tax Matters Agreement, net receipts for VMware during the three months ended May 5, 2023 were immaterial.

- removed (2024-09-10):
[0001571996-24-000062:note_history:74]
|  |  |  |  |  |  |  | Three Months Ended |
|  | Classification |  |  |  |  |  |  |  | May 5, 2023 |  |  |
|  |  |  |  |  |  |  |  |  | (in millions) |
| Sales and leases of products to VMware | Net revenue - products |  |  |  |  |  |  |  | $ | 40 |  |  |  |
| Purchase of VMware products for resale | Cost of net revenue - products |  |  |  |  |  |  |  | $ | 207 |  |  |  |
| Purchase of VMware services for resale | Cost of net revenue - services |  |  |  |  |  |  |  | $ | 876 |  |  |  |


## us-gaap:ScheduleOfRelatedPartyTransactionsTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2024-09-10):
[0001571996-24-000090:note_history:75]
The following table presents information about the impact of Dell Technologies’ related party transactions with VMware on the Consolidated Statements of Income for the three and six months ended August 4, 2023:
  (was, 2024-06-11, similarity 0.9626):
[0001571996-24-000062:note_history:75]
The following table presents information about the impact of Dell Technologies’ related party transactions with VMware on the Consolidated Statements of Income for the three months ended May 5, 2023:

- added (2024-09-10):
[0001571996-24-000090:note_history:76]
|  |  |  |  |  | Three Months Ended |  |  |  | Six Months Ended |
|  | Classification |  |  |  | August 4, 2023 |  |  |  | August 4, 2023 |  |  |
|  |  |  |  |  | (in millions) |
| Sales and leases of products to VMware | Net revenue - products |  |  |  | $ | 38 |  |  |  |  | $ | 78 |  |  |  |
| Purchase of VMware products for resale | Cost of net revenue - products |  |  |  | $ | 384 |  |  |  |  | $ | 591 |  |  |  |
| Purchase of VMware services for resale | Cost of net revenue - services |  |  |  | $ | 880 |  |  |  |  | $ | 1,756 |  |  |  |

- removed (2024-09-10):
[0001571996-24-000062:note_history:77]
|  |  |  |  |  |  |  | Three Months Ended |
|  | Classification |  |  |  |  |  |  |  | May 5, 2023 |  |  |
|  |  |  |  |  |  |  |  |  | (in millions) |
| Sales and leases of products to VMware | Net revenue - products |  |  |  |  |  |  |  | $ | 40 |  |  |  |
| Purchase of VMware products for resale | Cost of net revenue - products |  |  |  |  |  |  |  | $ | 207 |  |  |  |
| Purchase of VMware services for resale | Cost of net revenue - services |  |  |  |  |  |  |  | $ | 876 |  |  |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-09-10):
[0001571996-24-000090:note_history:78]
|  | Three Months Ended |  | Six Months Ended |
|  | August 2, 2024 |  | August 4, 2023 |  | August 2, 2024 |  | August 4, 2023 |  |  |
|  | (in millions) |
| Net revenue: |  |  |  |  |  |  |  |  |  |
| Infrastructure Solutions Group: |  |  |  |  |  |  |  |  |  |
| Servers and networking | $ | 7,672 |  |  | $ | 4,274 |  |  | $ | 13,138 |  |  | $ | 8,111 |  |  |  |
| Storage | 3,974 |  |  | 4,187 |  |  | 7,735 |  |  | 7,943 |  |  |  |
| Total ISG net revenue | $ | 11,646 |  |  | $ | 8,461 |  |  | $ | 20,873 |  |  | $ | 16,054 |  |  |  |
| Client Solutions Group: |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 10,556 |  |  | $ | 10,554 |  |  | $ | 20,710 |  |  | $ | 20,416 |  |  |  |
| Consumer | 1,858 |  |  | 2,388 |  |  | 3,671 |  |  | 4,509 |  |  |  |
| Total CSG net revenue | $ | 12,414 |  |  | $ | 12,942 |  |  | $ | 24,381 |  |  | $ | 24,925 |  |  |  |
  (was, 2024-06-11, similarity 0.8146):
[0001571996-24-000062:note_history:78]
|  | Three Months Ended |  |  |
|  | May 3, 2024 |  | May 5, 2023 |  |  |  |  |  |  |
|  | (in millions) |
| Net revenue: |  |  |  |  |  |  |  |  |  |
| Infrastructure Solutions Group: |  |  |  |  |  |  |  |  |  |
| Servers and networking | $ | 5,466 |  |  | $ | 3,837 |  |  |  |  |  |  |  |
| Storage | 3,761 |  |  | 3,756 |  |  |  |  |  |  |  |
| Total ISG net revenue | $ | 9,227 |  |  | $ | 7,593 |  |  |  |  |  |  |  |
| Client Solutions Group: |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 10,154 |  |  | $ | 9,862 |  |  |  |  |  |  |  |
| Consumer | 1,813 |  |  | 2,121 |  |  |  |  |  |  |  |
| Total CSG net revenue | $ | 11,967 |  |  | $ | 11,983 |  |  |  |  |  |  |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-09-10):
[0001571996-24-000090:note_history:79]
|  | Three Months Ended |  | Six Months Ended |
|  | August 2, 2024 |  | August 4, 2023 |  | August 2, 2024 |  | August 4, 2023 |
|  | (in millions) |
| Deferred revenue: |  |  |  |  |  |  |  |
| Deferred revenue at beginning of period | $ | 28,150 |  |  | $ | 29,695 |  |  | $ | 29,145 |  |  | $ | 30,286 |  |
| Revenue deferrals | 4,920 |  |  | 6,025 |  |  | 9,389 |  |  | 10,744 |  |
| Revenue recognized | (5,358) |  |  | (5,408) |  |  | (10,822) |  |  | (10,718) |  |
| Deferred revenue at end of period | $ | 27,712 |  |  | $ | 30,312 |  |  | $ | 27,712 |  |  | $ | 30,312 |  |
| Short-term deferred revenue | $ | 14,853 |  |  | $ | 16,174 |  |  | $ | 14,853 |  |  | $ | 16,174 |  |
| Long-term deferred revenue | $ | 12,859 |  |  | $ | 14,138 |  |  | $ | 12,859 |  |  | $ | 14,138 |  |
  (was, 2024-06-11, similarity 0.742):
[0001571996-24-000062:note_history:79]
|  |  |  | Three Months Ended |
|  |  |  |  |  | May 3, 2024 |  | May 5, 2023 |
|  |  |  |  |  | (in millions) |
| Deferred revenue: |  |  |  |  |  |  |  |
| Deferred revenue at beginning of period |  |  |  |  | $ | 29,145 |  |  | $ | 30,286 |  |
| Revenue deferrals |  |  |  |  | 4,469 |  |  | 4,719 |  |
| Revenue recognized |  |  |  |  | (5,464) |  |  | (5,310) |  |
| Deferred revenue at end of period |  |  |  |  | $ | 28,150 |  |  | $ | 29,695 |  |
| Short-term deferred revenue |  |  |  |  | $ | 15,034 |  |  | $ | 15,527 |  |
| Long-term deferred revenue |  |  |  |  | $ | 13,116 |  |  | $ | 14,168 |  |

- changed (2024-09-10):
[0001571996-24-000090:note_history:80]
Remaining Performance Obligations — Remaining performance obligations represent the aggregate amount of the transaction price allocated to performance obligations not delivered, or partially undelivered, as of the end of the reporting period. Remaining performance obligations include deferred revenue plus unbilled amounts not yet recorded in deferred revenue. The value of the transaction price allocated to remaining performance obligations as of August 2, 2024 was approximately $38 billion. The Company expects to recognize approximately 59% of remaining performance obligations as revenue in the next twelve months, and the remainder thereafter.
  (was, 2024-06-11, similarity 0.993):
[0001571996-24-000062:note_history:80]
Remaining Performance Obligations — Remaining performance obligations represent the aggregate amount of the transaction price allocated to performance obligations not delivered, or partially undelivered, as of the end of the reporting period.  Remaining performance obligations include deferred revenue plus unbilled amounts not yet recorded in deferred revenue.  The value of the transaction price allocated to remaining performance obligations as of May 3, 2024 was approximately $39 billion.  The Company expects to recognize approximately 59% of remaining performance obligations as revenue in the next twelve months, and the remainder thereafter.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2024-09-10):
[0001571996-24-000090:note_history:81]
SUBSEQUENT EVENTS 
There were no known events occurring after August 2, 2024 and up until the date of issuance of this report that would materially affect the information presented herein.
  (was, 2024-06-11, similarity 0.9807):
[0001571996-24-000062:note_history:81]
SUBSEQUENT EVENTS 
There were no known events occurring after May 3, 2024, and up until the date of issuance of this report that would materially affect the information presented herein.
