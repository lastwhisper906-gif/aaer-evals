# DELL MD&A — 0001571996-24-000090


## mdna

[0001571996-24-000090:mdna:1]
[same as prior period, unchanged from 0001571996-24-000062:mdna:1]

[0001571996-24-000090:mdna:2]
Unless otherwise indicated, all results presented are prepared in a manner that complies, in all material respects, with generally accepted accounting principles in the United States of America (“GAAP”). Unless otherwise indicated, all changes identified for the current-period results represent comparisons to results for the prior corresponding fiscal period.

[0001571996-24-000090:mdna:3]
[same as prior period, unchanged from 0001571996-24-000062:mdna:3]

[0001571996-24-000090:mdna:4]
Our fiscal year is the 52- or 53-week period ending on the Friday nearest January 31. We refer to our fiscal year ending January 31, 2025 as “Fiscal 2025” and our fiscal year ended February 2, 2024 as “Fiscal 2024.” Fiscal 2025 and Fiscal 2024 include 52 weeks.

[0001571996-24-000090:mdna:5]
[same as prior period, unchanged from 0001571996-24-000062:mdna:5]

[0001571996-24-000090:mdna:6]
[same as prior period, unchanged from 0001571996-24-000062:mdna:6]

[0001571996-24-000090:mdna:7]
Dell Technologies is a global technology company that provides customers with a broad and innovative solutions portfolio to help customers modernize their information technology (“IT”) infrastructure, address workforce transformation, and provide critical solutions that keep people and organizations connected. With our extensive portfolio and our commitment to innovation, we offer secure, integrated solutions that extend from the edge to the core to the cloud, and we are at the forefront of artificial intelligence (“AI”), software-defined, and cloud native infrastructure solutions. Our vision is to become the most essential technology partner. We intend to realize our vision as we execute our strategy to leverage our strengths to extend our leadership positions and capture new growth.

[0001571996-24-000090:mdna:8]
[same as prior period, unchanged from 0001571996-24-000062:mdna:8]

[0001571996-24-000090:mdna:9]
•Infrastructure Solutions Group (“ISG”) — ISG includes our storage, server, and networking offerings. Our comprehensive storage portfolio includes modern and traditional storage solutions, including all-flash arrays, scale-out file, object platforms, hyper-converged infrastructure, and software-defined storage. Our server portfolio includes high-performance general-purpose and AI-optimized servers. Our networking portfolio includes wide area network infrastructure, data center and edge networking switches, and cables and optics. ISG also offers software, peripherals, and services, including consulting and support and deployment.

[0001571996-24-000090:mdna:10]
•Client Solutions Group (“CSG”) — CSG includes offerings designed for commercial and consumer customers. Our CSG portfolio includes branded PCs, including notebooks, desktops, and workstations, branded peripherals, and third-party software and peripherals. CSG also includes services offerings, such as configuration, support and deployment, and extended warranties.

[0001571996-24-000090:mdna:11]
Our “other businesses” primarily consist of our resale of standalone offerings of VMware LLC (formerly “VMware, Inc.” and individually and together with its subsidiaries, “VMware”), referred to as “VMware Resale,” and offerings of SecureWorks Corp. (“Secureworks”). These businesses are not classified as reportable segments, either individually or collectively.

[0001571996-24-000090:mdna:12]
[same as prior period, unchanged from 0001571996-24-000062:mdna:12]

[0001571996-24-000090:mdna:13]
We offer customers choice in how they acquire our solutions, including traditional purchasing and financing offerings provided by Dell Financial Services and its affiliates (“DFS”). We also offer flexible consumption models that include utility, subscription, and as-a-Service models. These offerings allow our customers to pay over time and provide them with operational and financial flexibility. For additional information about our financing arrangements, see Note 4 of the Notes to the Condensed Consolidated Financial Statements included in this report.

[0001571996-24-000090:mdna:14]
[same as prior period, unchanged from 0001571996-24-000062:mdna:14]

[0001571996-24-000090:mdna:15]
During the second quarter and first six months of Fiscal 2025, the following trends and conditions continued to affect the environment in which we operate:

[0001571996-24-000090:mdna:16]
•Macroeconomic environment: The macroeconomic environment continued to show signs of stabilizing as the demand environment improved primarily in our servers and networking offerings, which resulted in overall net revenue growth. While overall net revenue grew, the pricing environment became increasingly competitive, which primarily affected our CSG gross margin performance.

[0001571996-24-000090:mdna:17]
•Advancements in artificial intelligence: Our ISG business continued to benefit from increased demand for AI-optimized solutions due to the impact of AI advancements on customer spending behavior, as organizations look to integrate AI into their operations. As a result of continued strong demand for our AI-optimized servers, we maintained elevated backlog levels for such offerings as we exited the quarter.

[0001571996-24-000090:mdna:18]
•Supply chain: Notwithstanding the elevated demand for AI-optimized solutions, our supply chain operated efficiently during the quarter. We experienced a decline in input costs driven by favorability in component costs. Input costs consist of both component and logistics costs.

[0001571996-24-000090:mdna:19]
•Broadcom’s acquisition of VMware: On November 22, 2023, Broadcom Inc. (“Broadcom”) completed its acquisition of VMware, leading to changes to our relationship with VMware as described below. The changes continued to affect our other businesses net revenue.

[0001571996-24-000090:mdna:20]
We expect the demand environment will continue to improve throughout the remainder of Fiscal 2025 as the macroeconomic environment continues to stabilize. While we anticipate the pricing environment will remain competitive throughout Fiscal 2025, we expect net revenue growth for the full fiscal year primarily driven by ISG net revenue attributable to our AI-optimized servers and continued demand improvement for our traditional servers. We expect modest CSG net revenue growth for the full fiscal year driven by the timing of the anticipated PC refresh cycle. Additionally, we expect a continued reduction of our other businesses’ net revenue as we no longer act as a distributor of VMware’s standalone products and services.

[0001571996-24-000090:mdna:21]
We expect input costs to increase during the second half of Fiscal 2025, principally driven by anticipated inflation for component costs. Input cost trends are dependent on the strength or weakness of actual end-user demand and supply dynamics, which will continue to fluctuate and ultimately impact our costs, pricing, and operating results.

[0001571996-24-000090:mdna:22]
We remain focused on executing our key strategic priorities, building long-term value creation for our stakeholders, and addressing our customers’ needs while continuing to make prudent decisions in response to the environment. We look to balance profitability and growth while maintaining disciplined pricing as we navigate through competitive pricing pressures.

[0001571996-24-000090:mdna:23]
We continue to advance our own capabilities to change the way we work and make decisions, improve business outcomes and the customer experience, and reduce costs by leveraging new technology and optimizing business processes. Throughout Fiscal 2025, we remain committed to disciplined cost management in coordination with our ongoing business transformation initiatives and will continue to take certain measures to reduce costs, including limitation of external hiring, employee reorganizations, and other actions to align our investments with our strategic priorities and customer needs. We anticipate these actions will result in a continued reduction in our overall headcount. We believe our unique operating advantages provide a foundation to foster growth, drive efficiencies, and continue to position us for long-term success.

[0001571996-24-000090:mdna:24]
Relationship with VMware — On November 22, 2023, VMware was acquired by Broadcom, and subsequently announced changes to its go-to-market approach for VMware offerings that impacted our commercial relationship with VMware. On March 25, 2024, we terminated our Commercial Framework Agreement with VMware, which provided the framework under which we and VMware continued our commercial relationship following our spin-off of VMware on November 1, 2021. We no longer act as a distributor of VMware’s standalone products and services, though we will continue to support customers that have purchased resale offerings sold in prior periods. We continue to integrate certain VMware products and services with select Dell Technologies’ offerings to end-users. The results of such offerings are reflected within CSG or ISG, depending upon the nature of the underlying offering sold.

[0001571996-24-000090:mdna:25]
VMware was a related party until the date of its acquisition by Broadcom. The acquisition terminated the preexisting related party relationship with VMware such that no related party relationship exists with either Broadcom or VMware effective as of November 22, 2023. For more information regarding the impact of the Broadcom acquisition of VMware and our prior related party transactions with VMware, see Note 15 of the Notes to the Condensed Consolidated Financial Statements included in this report.

[0001571996-24-000090:mdna:26]
ISG — We expect that ISG will continue to be impacted by the evolving nature of the IT infrastructure market and competitive environment. With our scale and strong solutions portfolio, we believe we are well-positioned to address the ongoing competitive dynamics and trends in technology and customer needs. Through our collaborative, customer-focused approach to innovation, we strive to deliver new and relevant solutions and software to our customers quickly and efficiently. We continue to focus on customer base expansion and the lifetime value of customer relationships. We anticipate that ISG will continue to benefit from technology advances and customer interest in AI and we are well-positioned to capture growth and support our customers’ needs.

[0001571996-24-000090:mdna:27]
We expect that growth in data will continue to generate long-term demand for our storage solutions and services. Cloud native applications are expected to continue to be a key trend in the infrastructure market. We continue to expand our offerings in external storage arrays, which incorporate flexible, cloud-based functionality. We benefit from offering solutions that address software-defined storage, hyper-converged infrastructure, and modular solutions based on server-centric architectures. Our storage business is subject to seasonal trends, which may continue to impact ISG results.

[0001571996-24-000090:mdna:28]
CSG — We participate in all segments of the PC market but focus on commercial and high-end consumer computing devices, as we believe they represent the most stable and profitable markets. We anticipate that CSG will benefit from advances in AI over the long-term as customers will require PCs with the ability to run their complex AI workloads.

[0001571996-24-000090:mdna:29]
Competitive dynamics remain an important factor in our CSG business and continue to impact pricing and operating results. We are committed to our long-term CSG strategy and will continue to make investments to innovate across the portfolio. We expect that the CSG demand environment will be subject to seasonal trends.

[0001571996-24-000090:mdna:30]
Recurring Revenue and Consumption Models — We expect that our flexible consumption models will further strengthen our customer relationships and provide a foundation for growth in recurring revenue. We define recurring revenue as revenue recognized that is primarily related to hardware and software maintenance, as well as operating leases, subscription, as-a-Service, and usage-based offerings.

[0001571996-24-000090:mdna:31]
Strategic Investments and Acquisitions — As part of our strategy, we will continue to evaluate opportunities for strategic investments through our venture capital investment arm, Dell Technologies Capital, with a focus on emerging technology areas that are relevant to our business and that will complement our existing portfolio of solutions. The technologies or products these companies have under development are typically in the early stages and may never have commercial value, which could result in a loss of a substantial part of our investment in the companies. In addition to these investments, we may also make disciplined acquisitions of businesses that advance our strategic objectives and accelerate our innovation agenda.

[0001571996-24-000090:mdna:32]
Foreign Currency Exposure — We manage our business on a U.S. dollar basis. However, we have a large global presence, generating approximately half of our net revenue from sales to customers outside of the United States during the second quarter and first six months of Fiscal 2025 and Fiscal 2024. As a result, our operating results can be, and particularly in recent periods have been, impacted by fluctuations in foreign currency exchange rates. We utilize a comprehensive hedging strategy intended to mitigate the impact of foreign currency volatility over time, and we adjust pricing when possible to further minimize foreign currency impacts.

[0001571996-24-000090:mdna:33]
Other Macroeconomic Risks and Uncertainties — The impacts of trade protection measures, including increases in tariffs and trade barriers, changes in government policies and international trade arrangements, geopolitical volatility, and global macroeconomic conditions (including those in China) may affect our ability to conduct business in some non-U.S. markets. We monitor and seek to mitigate these risks with adjustments to our manufacturing, supply chain, and distribution networks.

[0001571996-24-000090:mdna:34]
[same as prior period, unchanged from 0001571996-24-000062:mdna:35]

[0001571996-24-000090:mdna:35]
[same as prior period, unchanged from 0001571996-24-000062:mdna:36]

[0001571996-24-000090:mdna:36]
In this management’s discussion and analysis, we use supplemental measures of our performance which are derived from our consolidated financial information but which are not presented in our consolidated financial statements prepared in accordance with GAAP. These non-GAAP financial measures include non-GAAP product gross margin; non-GAAP services gross margin; non-GAAP gross margin; non-GAAP operating expenses; non-GAAP operating income; non-GAAP net income; non-GAAP earnings per share attributable to Dell Technologies Inc. - diluted; free cash flow; and adjusted free cash flow. These non-GAAP financial measures are not meant to be considered as indicators of performance or liquidity in isolation from or as a substitute for gross margin, operating expenses, operating income, net income, diluted earnings per share, or cash flows from operating activities prepared in accordance with GAAP, and should be read only in conjunction with financial information presented on a GAAP basis.

[0001571996-24-000090:mdna:37]
We use non-GAAP financial measures to supplement financial information presented on a GAAP basis. Management uses these non-GAAP measures in financial planning and forecasting and when evaluating our financial results and operating trends and performance. We believe, when used supplementally with GAAP financial measures, these non-GAAP financial measures provide our investors with useful and transparent information to help them evaluate our results by facilitating an enhanced understanding of our results of operations and enabling them to make period to period comparisons. There are limitations to the use of the non-GAAP financial measures presented in this report. Our non-GAAP financial measures may not be comparable to similarly titled measures of other companies. Other companies, including companies in our industry, may calculate non-GAAP financial measures differently than we do, limiting the usefulness of those measures for comparative purposes.

[0001571996-24-000090:mdna:38]
Non-GAAP product gross margin, non-GAAP services gross margin, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, and non-GAAP earnings per share attributable to Dell Technologies Inc. - diluted, as defined by us, exclude amortization of intangible assets, stock-based compensation expense, other corporate expenses and, for non-GAAP net income and non-GAAP earnings per share attributable to Dell Technologies Inc. - diluted, fair value adjustments on equity investments and an aggregate adjustment for income taxes. As the excluded items may have a material impact on our financial results, our management compensates for this limitation by relying primarily on our GAAP results and using non-GAAP financial measures supplementally or for projections when comparable GAAP financial measures are not available.

[0001571996-24-000090:mdna:39]
Reconciliations of each non-GAAP financial measure to its most directly comparable GAAP financial measure are presented below. We encourage you to review the reconciliations in conjunction with the presentation of the non-GAAP financial measures for each of the periods presented. The discussion below includes information on each of the excluded items as well as our reasons for excluding them from our non-GAAP results. In future fiscal periods, we may exclude such items and may incur income and expenses similar to these excluded items. Accordingly, the exclusion of these items and other similar items in our non-GAAP presentation should not be interpreted as implying that these items are non-recurring, infrequent, or unusual.

[0001571996-24-000090:mdna:40]
[same as prior period, unchanged from 0001571996-24-000062:mdna:41]

[0001571996-24-000090:mdna:41]
•Amortization of Intangible Assets — Amortization of intangible assets primarily consists of the amortization of customer relationships, developed technology, and trade names. In connection with our acquisition by merger of EMC, referred to as the “EMC merger transaction,” and the acquisition of Dell Inc. by Dell Technologies Inc., referred to as the “going-private transaction,” all of the tangible and intangible assets and liabilities of EMC and Dell Inc. and their consolidated subsidiaries, respectively, were accounted for and recognized at fair value on the transaction dates. We exclude amortization charges for the amortization of intangible assets as they do not reflect our current operating performance and charges are significantly impacted by the timing and magnitude of our acquisitions and, as a result, may vary in amount from period to period.

[0001571996-24-000090:mdna:42]
•Stock-based Compensation Expense — Stock-based compensation expense consists of equity awards granted based on the estimated fair value of those awards at grant date. To estimate the fair value of performance-based awards containing a market condition, we use the Monte Carlo valuation model. For other share-based awards, the fair value is generally based on the closing price of the Class C Common Stock as reported on the New York Stock Exchange on the date of grant. Although stock-based compensation is an important aspect of the compensation of our employees and executives, we exclude such expense because the fair value of the stock-based awards may fluctuate based on factors unrelated to the operating performance of the business and may bear little resemblance to the actual value realized upon the vesting or future exercise of the related stock-based awards.

[0001571996-24-000090:mdna:43]
•Other Corporate Expenses — Other corporate expenses consist primarily of severance expenses, payroll taxes associated with stock-based compensation, facility action costs, transaction-related expenses, impairment charges, and incentive charges related to equity investments. Severance costs are primarily related to severance and benefits for employees terminated pursuant to cost management initiatives. During both the first six months of Fiscal 2025 and Fiscal 2024, we recognized $0.4 billion of severance expense related to workforce reduction activities. Transaction-related expenses typically consist of acquisition, integration, and divestitures related costs, primarily representing costs for legal, banking, consulting, and advisory services, and are expensed as incurred. Although we may incur these types of expenses in the future, we exclude other corporate expenses as they can vary from period to period, are significantly impacted by the timing and nature of these events, and are not used by management in assessing operating performance of the business.

[0001571996-24-000090:mdna:44]
•Fair Value Adjustments on Equity Investments — Fair value adjustments on equity investments primarily consist of the gain (loss) on strategic investments, which includes recurring fair value adjustments of investments in publicly-traded companies, as well as those in privately-held companies, which are adjusted for observable price changes and any potential impairments. See Note 3 of the Notes to the Condensed Consolidated Financial Statements included in this report for additional information on our strategic investment activity. We exclude fair value adjustments on equity investments given the volatility in ongoing adjustments to the valuation of these strategic investments and because such adjustments are unrelated to the operating performance of our business.

[0001571996-24-000090:mdna:45]
•Aggregate Adjustment for Income Taxes — The aggregate adjustment for income taxes is the estimated combined income tax effect for the adjustments described above and determined based on the tax jurisdictions where those adjustments were incurred, as well as an adjustment for discrete tax items. During the first six months of Fiscal 2025, the aggregate adjustment for income taxes included discrete tax benefits of $0.4 billion related to changes in uncertain tax benefits resulting from the expiration of certain statutes of limitations and $0.2 billion related to stock-based compensation. We exclude these benefits or charges for purposes of calculating non-GAAP net income due to the variability in recognition of discrete tax items from period to period. The tax effects are determined based on the tax jurisdictions where the above items were incurred. See Note 11 of the Notes to the Condensed Consolidated Financial Statements included in this report for additional information about our income taxes. Beginning in Fiscal 2025, our non-GAAP income tax is calculated using a fixed estimated annual tax rate which is determined based on historical trends and projections for the current fiscal year. We may adjust our estimated annual tax rate during the fiscal year to take into account events that would significantly impact our income tax expense, including significant changes resulting from tax legislation, material changes in geographic mix of revenue and expenses, changes to our corporate structure, and other significant events.

[0001571996-24-000090:mdna:46]
[same as prior period, unchanged from 0001571996-24-000062:mdna:47]

[0001571996-24-000090:mdna:47]
[same as prior period, unchanged from 0001571996-24-000062:mdna:48]

[0001571996-24-000090:mdna:48]
|  | Three Months Ended |  | Six Months Ended |
|  | August 2, 2024 |  | % Change |  | August 4, 2023 |  | August 2, 2024 |  | % Change |  | August 4, 2023 |  |  |  |  |
|  | (in millions, except percentages) |  |  |  |  |
| Product gross margin | $ | 2,875 |  |  | (2) | % |  | $ | 2,933 |  |  | $ | 5,236 |  |  | (6) | % |  | $ | 5,594 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 59 |  |  |  |  | 84 |  |  | 119 |  |  |  |  | 163 |  |  |  |  |  |
| Stock-based compensation expense | 14 |  |  |  |  | 13 |  |  | 28 |  |  |  |  | 26 |  |  |  |  |  |
| Other corporate expenses | 6 |  |  |  |  | 7 |  |  | 10 |  |  |  |  | 15 |  |  |  |  |  |
| Non-GAAP product gross margin | $ | 2,954 |  |  | (3) | % |  | $ | 3,037 |  |  | $ | 5,393 |  |  | (7) | % |  | $ | 5,798 |  |  |  |  |  |
| Services gross margin | $ | 2,436 |  |  | (1) | % |  | $ | 2,454 |  |  | $ | 4,881 |  |  | 1 | % |  | $ | 4,811 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense | 24 |  |  |  |  | 24 |  |  | 48 |  |  |  |  | 49 |  |  |  |  |  |
| Other corporate expenses | 50 |  |  |  |  | 21 |  |  | 89 |  |  |  |  | 42 |  |  |  |  |  |
| Non-GAAP services gross margin | $ | 2,510 |  |  | — | % |  | $ | 2,499 |  |  | $ | 5,018 |  |  | 2 | % |  | $ | 4,902 |  |  |  |  |  |
| Gross margin | $ | 5,311 |  |  | (1) | % |  | $ | 5,387 |  |  | $ | 10,117 |  |  | (3) | % |  | $ | 10,405 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 59 |  |  |  |  | 84 |  |  | 119 |  |  |  |  | 163 |  |  |  |  |  |
| Stock-based compensation expense | 38 |  |  |  |  | 37 |  |  | 76 |  |  |  |  | 75 |  |  |  |  |  |
| Other corporate expenses | 56 |  |  |  |  | 28 |  |  | 99 |  |  |  |  | 57 |  |  |  |  |  |
| Non-GAAP gross margin | $ | 5,464 |  |  | (1) | % |  | $ | 5,536 |  |  | $ | 10,411 |  |  | (3) | % |  | $ | 10,700 |  |  |  |  |  |
| Operating expenses | $ | 3,969 |  |  | (6) | % |  | $ | 4,222 |  |  | $ | 7,855 |  |  | (4) | % |  | $ | 8,171 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | (109) |  |  |  |  | (129) |  |  | (217) |  |  |  |  | (253) |  |  |  |  |  |
| Stock-based compensation expense | (153) |  |  |  |  | (186) |  |  | (325) |  |  |  |  | (373) |  |  |  |  |  |
| Other corporate expenses | (277) |  |  |  |  | (348) |  |  | (410) |  |  |  |  | (420) |  |  |  |  |  |
| Non-GAAP operating expenses | $ | 3,430 |  |  | (4) | % |  | $ | 3,559 |  |  | $ | 6,903 |  |  | (3) | % |  | $ | 7,125 |  |  |  |  |  |

[0001571996-24-000090:mdna:49]
57

[0001571996-24-000090:mdna:50]
|  | Three Months Ended |  | Six Months Ended |
|  | August 2, 2024 |  | % Change |  | August 4, 2023 |  | August 2, 2024 |  | % Change |  | August 4, 2023 |  |  |  |  |
|  | (in millions, except percentages and per share amounts) |  |  |  |  |
| Operating income | $ | 1,342 |  |  | 15 | % |  | $ | 1,165 |  |  | $ | 2,262 |  |  | 1 | % |  | $ | 2,234 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 168 |  |  |  |  | 213 |  |  | 336 |  |  |  |  | 416 |  |  |  |  |  |
| Stock-based compensation expense | 191 |  |  |  |  | 223 |  |  | 401 |  |  |  |  | 448 |  |  |  |  |  |
| Other corporate expenses | 333 |  |  |  |  | 376 |  |  | 509 |  |  |  |  | 477 |  |  |  |  |  |
| Non-GAAP operating income | $ | 2,034 |  |  | 3 | % |  | $ | 1,977 |  |  | $ | 3,508 |  |  | (2) | % |  | $ | 3,575 |  |  |  |  |  |
| Net income | $ | 841 |  |  | 85 | % |  | $ | 455 |  |  | $ | 1,796 |  |  | 74 | % |  | $ | 1,033 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 168 |  |  |  |  | 213 |  |  | 336 |  |  |  |  | 416 |  |  |  |  |  |
| Stock-based compensation expense | 191 |  |  |  |  | 223 |  |  | 401 |  |  |  |  | 448 |  |  |  |  |  |
| Other corporate expenses | 329 |  |  |  |  | 432 |  |  | 499 |  |  |  |  | 530 |  |  |  |  |  |
| Fair value adjustments on equity investments | (5) |  |  |  |  | 29 |  |  | 25 |  |  |  |  | 44 |  |  |  |  |  |
| Aggregate adjustment for income taxes | (153) |  |  |  |  | (69) |  |  | (763) |  |  |  |  | (225) |  |  |  |  |  |
| Non-GAAP net income | $ | 1,371 |  |  | 7 | % |  | $ | 1,283 |  |  | $ | 2,294 |  |  | 2 | % |  | $ | 2,246 |  |  |  |  |  |
| Earnings per share attributable to Dell Technologies Inc. — diluted | $ | 1.17 |  |  | 86 | % |  | $ | 0.63 |  |  | $ | 2.49 |  |  | 75 | % |  | $ | 1.42 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 0.23 |  |  |  |  | 0.29 |  |  | 0.46 |  |  |  |  | 0.56 |  |  |  |  |  |
| Stock-based compensation expense | 0.26 |  |  |  |  | 0.30 |  |  | 0.55 |  |  |  |  | 0.61 |  |  |  |  |  |
| Other corporate expenses | 0.46 |  |  |  |  | 0.58 |  |  | 0.69 |  |  |  |  | 0.72 |  |  |  |  |  |
| Fair value adjustments on equity investments | (0.01) |  |  |  |  | 0.04 |  |  | 0.04 |  |  |  |  | 0.06 |  |  |  |  |  |
| Aggregate adjustment for income taxes | (0.21) |  |  |  |  | (0.09) |  |  | (1.05) |  |  |  |  | (0.31) |  |  |  |  |  |
| Total non-GAAP adjustments attributable to non-controlling interests | (0.01) |  |  |  |  | (0.01) |  |  | (0.02) |  |  |  |  | (0.01) |  |  |  |  |  |
| Non-GAAP earnings per share attributable to Dell Technologies Inc. — diluted | $ | 1.89 |  |  | 9 | % |  | $ | 1.74 |  |  | $ | 3.16 |  |  | 4 | % |  | $ | 3.05 |  |  |  |  |  |

[0001571996-24-000090:mdna:51]
[same as prior period, unchanged from 0001571996-24-000062:mdna:51]

[0001571996-24-000090:mdna:52]
In addition to the above measures, we use free cash flow and adjusted free cash flow as non-GAAP liquidity measures to evaluate our performance. As presented in the following table, we define free cash flow to consist of cash flow from operations after excluding capital expenditures and capitalized software costs, net. To measure adjusted free cash flow, we exclude the impact of financing receivables and equipment under operating leases from free cash flow, as the initial funding of these DFS offerings at the time of origination is largely subsequently replaced with cash inflows from our DFS debt, the majority of which is asset-backed.

[0001571996-24-000090:mdna:53]
Free cash flow and adjusted free cash flow provide useful information to management and investors in part because we use these metrics in our long-term capital allocation framework. Further, we believe free cash flow and adjusted free cash flow are useful measures to management and investors because they reflect cash that we can use, among other purposes, to repurchase common stock, pay dividends on our common stock, invest in our business, pay down debt, and make strategic acquisitions.

[0001571996-24-000090:mdna:54]
As is the case with the non-GAAP measures presented above, users should consider the limitations of using free cash flow and adjusted free cash flow, including the fact that those measures do not provide a complete measure of our cash flows for any period. Free cash flow and adjusted free cash flow do not purport to be alternatives to cash flows from operating activities as a measure of liquidity. In particular, free cash flow and adjusted free cash flow are not intended to be a measure of cash flow available for management’s discretionary use, as these measures do not reflect certain cash requirements, such as debt service requirements and other contractual commitments.

[0001571996-24-000090:mdna:55]
[same as prior period, unchanged from 0001571996-24-000062:mdna:55]

[0001571996-24-000090:mdna:56]
|  | Three Months Ended |  | Six Months Ended |
|  | August 2, 2024 |  | % Change |  | August 4, 2023 |  | August 2, 2024 |  | % Change |  | August 4, 2023 |  |  |  |  |
|  | (in millions, except percentages) |  |  |  |  |
| Cash flow from operations | $ | 1,340 |  |  | (58) | % |  | $ | 3,214 |  |  | $ | 2,383 |  |  | (52) | % |  | $ | 4,991 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Capital expenditures and capitalized software development costs, net (a) | (636) |  |  |  |  | (624) |  |  | (1,222) |  |  |  |  | (1,322) |  |  |  |  |  |
| Free cash flow | $ | 704 |  |  | (73) | % |  | $ | 2,590 |  |  | $ | 1,161 |  |  | (68) | % |  | $ | 3,669 |  |  |  |  |  |
| Free cash flow | $ | 704 |  |  | (73) | % |  | $ | 2,590 |  |  | $ | 1,161 |  |  | (68) | % |  | $ | 3,669 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Financing receivables (b) | 487 |  |  |  |  | 497 |  |  | 652 |  |  |  |  | 130 |  |  |  |  |  |
| Equipment under operating leases (c) | 93 |  |  |  |  | (37) |  |  | 94 |  |  |  |  | (62) |  |  |  |  |  |
| Adjusted free cash flow | $ | 1,284 |  |  | (58) | % |  | $ | 3,050 |  |  | $ | 1,907 |  |  | (49) | % |  | $ | 3,737 |  |  |  |  |  |

[0001571996-24-000090:mdna:57]
[same as prior period, unchanged from 0001571996-24-000062:mdna:57]

[0001571996-24-000090:mdna:58]
[same as prior period, unchanged from 0001571996-24-000062:mdna:58]

[0001571996-24-000090:mdna:59]
[same as prior period, unchanged from 0001571996-24-000062:mdna:59]

[0001571996-24-000090:mdna:60]
(c)    Equipment under operating leases represents the net impact of capital expenditures and depreciation expense for DFS leases and contractually embedded leases identified within flexible consumption arrangements.

[0001571996-24-000090:mdna:61]
[same as prior period, unchanged from 0001571996-24-000062:mdna:61]

[0001571996-24-000090:mdna:62]
[same as prior period, unchanged from 0001571996-24-000062:mdna:62]

[0001571996-24-000090:mdna:63]
[same as prior period, unchanged from 0001571996-24-000062:mdna:63]

[0001571996-24-000090:mdna:64]
The following table summarizes our consolidated results for the periods indicated. Unless otherwise indicated, all changes identified for the current-period results represent comparisons to results for the prior corresponding fiscal period.

[0001571996-24-000090:mdna:65]
|  | Three Months Ended |  | Six Months Ended |
|  | August 2, 2024 |  |  |  | August 4, 2023 |  | August 2, 2024 |  |  |  | August 4, 2023 |  |  |  |  |
|  | Dollars |  | % of Net Revenue |  | % Change |  | Dollars |  | % of Net Revenue |  | Dollars |  | % of Net Revenue |  | % Change |  | Dollars |  | % of Net Revenue |  |  |  |  |  |  |
|  | (in millions, except percentages and per share amounts) |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products | $ | 18,954 |  |  | 75.7 | % |  | 12 | % |  | $ | 16,935 |  |  | 73.8 | % |  | $ | 35,081 |  |  | 74.2 | % |  | 10 | % |  | $ | 31,971 |  |  | 72.9 | % |  |  |  |  |  |  |
| Services | 6,072 |  |  | 24.3 | % |  | 1 | % |  | 5,999 |  |  | 26.2 | % |  | 12,189 |  |  | 25.8 | % |  | 3 | % |  | 11,885 |  |  | 27.1 | % |  |  |  |  |  |  |
| Total net revenue | $ | 25,026 |  |  | 100.0 | % |  | 9 | % |  | $ | 22,934 |  |  | 100.0 | % |  | $ | 47,270 |  |  | 100.0 | % |  | 8 | % |  | $ | 43,856 |  |  | 100.0 | % |  |  |  |  |  |  |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products | $ | 2,875 |  |  | 15.2 | % |  | (2) | % |  | $ | 2,933 |  |  | 17.3 | % |  | $ | 5,236 |  |  | 14.9 | % |  | (6) | % |  | $ | 5,594 |  |  | 17.5 | % |  |  |  |  |  |  |
| Services | 2,436 |  |  | 40.1 | % |  | (1) | % |  | 2,454 |  |  | 40.9 | % |  | 4,881 |  |  | 40.0 | % |  | 1 | % |  | 4,811 |  |  | 40.5 | % |  |  |  |  |  |  |
| Total gross margin | $ | 5,311 |  |  | 21.2 | % |  | (1) | % |  | $ | 5,387 |  |  | 23.5 | % |  | $ | 10,117 |  |  | 21.4 | % |  | (3) | % |  | $ | 10,405 |  |  | 23.7 | % |  |  |  |  |  |  |
| Operating expenses | $ | 3,969 |  |  | 15.8 | % |  | (6) | % |  | $ | 4,222 |  |  | 18.4 | % |  | $ | 7,855 |  |  | 16.6 | % |  | (4) | % |  | $ | 8,171 |  |  | 18.6 | % |  |  |  |  |  |  |
| Operating income | $ | 1,342 |  |  | 5.4 | % |  | 15 | % |  | $ | 1,165 |  |  | 5.1 | % |  | $ | 2,262 |  |  | 4.8 | % |  | 1 | % |  | $ | 2,234 |  |  | 5.1 | % |  |  |  |  |  |  |
| Net income | $ | 841 |  |  | 3.4 | % |  | 85 | % |  | $ | 455 |  |  | 2.0 | % |  | $ | 1,796 |  |  | 3.8 | % |  | 74 | % |  | $ | 1,033 |  |  | 2.4 | % |  |  |  |  |  |  |
| Earnings per share attributable to Dell Technologies — diluted | $ | 1.17 |  |  |  |  | 86 | % |  | $ | 0.63 |  |  |  |  | $ | 2.49 |  |  |  |  | 75 | % |  | $ | 1.42 |  |  |  |  |  |  |  |  |  |
| Cash flow from operations | $ | 1,340 |  |  |  |  | (58) | % |  | $ | 3,214 |  |  |  |  | $ | 2,383 |  |  |  |  | (52) | % |  | $ | 4,991 |  |  |  |  |  |  |  |  |  |
| Non-GAAP Financial Information |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | Three Months Ended |  | Six Months Ended |
|  | August 2, 2024 |  |  |  | August 4, 2023 |  | August 2, 2024 |  |  |  | August 4, 2023 |  |  |  |  |
|  | Dollars |  | % of Net Revenue |  | % Change |  | Dollars |  | % of Net Revenue |  | Dollars |  | % of Net Revenue |  | % Change |  | Dollars |  | % of Net Revenue |  |  |  |  |  |  |
|  | (in millions, except percentages and per share amounts) |
| Non-GAAP gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products | $ | 2,954 |  |  | 15.6 | % |  | (3) | % |  | $ | 3,037 |  |  | 17.9 | % |  | $ | 5,393 |  |  | 15.4 | % |  | (7) | % |  | $ | 5,798 |  |  | 18.1 | % |  |  |  |  |  |  |
| Services | 2,510 |  |  | 41.3 | % |  | — | % |  | 2,499 |  |  | 41.7 | % |  | 5,018 |  |  | 41.2 | % |  | 2 | % |  | 4,902 |  |  | 41.2 | % |  |  |  |  |  |  |
| Total non-GAAP gross margin | $ | 5,464 |  |  | 21.8 | % |  | (1) | % |  | $ | 5,536 |  |  | 24.1 | % |  | $ | 10,411 |  |  | 22.0 | % |  | (3) | % |  | $ | 10,700 |  |  | 24.4 | % |  |  |  |  |  |  |
| Non-GAAP operating expenses | $ | 3,430 |  |  | 13.7 | % |  | (4) | % |  | $ | 3,559 |  |  | 15.5 | % |  | $ | 6,903 |  |  | 14.6 | % |  | (3) | % |  | $ | 7,125 |  |  | 16.2 | % |  |  |  |  |  |  |
| Non-GAAP operating income | $ | 2,034 |  |  | 8.1 | % |  | 3 | % |  | $ | 1,977 |  |  | 8.6 | % |  | $ | 3,508 |  |  | 7.4 | % |  | (2) | % |  | $ | 3,575 |  |  | 8.2 | % |  |  |  |  |  |  |
| Non-GAAP net income | $ | 1,371 |  |  | 5.5 | % |  | 7 | % |  | $ | 1,283 |  |  | 5.6 | % |  | $ | 2,294 |  |  | 4.9 | % |  | 2 | % |  | $ | 2,246 |  |  | 5.1 | % |  |  |  |  |  |  |
| Non-GAAP earnings per share attributable to Dell Technologies — diluted | $ | 1.89 |  |  |  |  | 9 | % |  | $ | 1.74 |  |  |  |  | $ | 3.16 |  |  |  |  | 4 | % |  | $ | 3.05 |  |  |  |  |  |  |  |  |  |
| Free cash flow | $ | 704 |  |  |  |  | (73) | % |  | $ | 2,590 |  |  |  |  | $ | 1,161 |  |  |  |  | (68) | % |  | $ | 3,669 |  |  |  |  |  |  |  |  |  |
| Adjusted free cash flow | $ | 1,284 |  |  |  |  | (58) | % |  | $ | 3,050 |  |  |  |  | $ | 1,907 |  |  |  |  | (49) | % |  | $ | 3,737 |  |  |  |  |  |  |  |  |  |

[0001571996-24-000090:mdna:66]
Non-GAAP product gross margin, non-GAAP services gross margin, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, non-GAAP earnings per share attributable to Dell Technologies - diluted, free cash flow, and adjusted free cash flow are not measurements of financial performance prepared in accordance with GAAP. See “Non‑GAAP Financial Measures” for additional information about these non-GAAP financial measures, including our reasons for including these measures, material limitations with respect to the usefulness of the measures, and a reconciliation of each non-GAAP financial measure to the most directly comparable GAAP financial measure.

[0001571996-24-000090:mdna:67]
[same as prior period, unchanged from 0001571996-24-000062:mdna:67]

[0001571996-24-000090:mdna:68]
[same as prior period, unchanged from 0001571996-24-000062:mdna:68]

[0001571996-24-000090:mdna:69]
During the second quarter and first six months of Fiscal 2025, net revenue increased by 9% and 8%, respectively, driven by an increase in ISG net revenue that was partially offset by a decrease in other businesses net revenue and CSG net revenue. The increase in ISG net revenue was driven by growth in our servers and networking offerings. Other businesses net revenue declined primarily due to a decrease in VMware Resale revenue as we no longer act as a distributor of standalone VMware offerings. The decline in CSG net revenue was primarily attributable to a decrease in sales of our consumer offerings.

[0001571996-24-000090:mdna:70]
During the second quarter of Fiscal 2025, operating income and non-GAAP operating income increased by 15% to $1.3 billion and 3% to $2.0 billion, respectively. During the first six months of Fiscal 2025, operating income and non-GAAP operating income increased by 1% to $2.3 billion and decreased by 2% to $3.5 billion, respectively. During both the second quarter and first six months of Fiscal 2025, operating income and non-GAAP operating income were impacted by an increase in ISG operating income driven by our servers and networking offerings and a decrease in CSG operating income primarily driven by our commercial offerings.

[0001571996-24-000090:mdna:71]
During the second quarter of Fiscal 2025, operating income and non-GAAP operating income as a percentage of net revenue increased 30 basis points to 5.4% and decreased 50 basis points to 8.1%, respectively. During the first six months of Fiscal 2025, operating income and non-GAAP operating income as a percentage of net revenue decreased 30 basis points to 4.8% and 80 basis points to 7.4%, respectively. Operating income and non-GAAP operating income as a percentage of net revenue during both the second quarter and first six months of Fiscal 2025 were impacted by a decline in gross margin as a percentage of net revenue as a result of a shift in mix towards AI-optimized server offerings and, to a lesser extent, a competitive CSG pricing environment. The decline in gross margin as a percentage of net revenue was offset by the favorable impact of a decrease in operating expense rate that was driven by strong ISG net revenue growth coupled with continued disciplined cost management.

[0001571996-24-000090:mdna:72]
Cash provided by operating activities was $2.4 billion during the first six months of Fiscal 2025, and was driven by profitability, partially offset by working capital dynamics primarily due to growth in our AI-optimized server offerings. During the first six months of Fiscal 2024, cash provided by operating activities was $5.0 billion, which was primarily driven by profitability and working capital management as we reduced inventory, demonstrated strong cash collections performance, and benefited from the timing of purchases and payments to vendors. See “Liquidity, Cash Requirements, and Market Conditions” for additional information about our cash flow metrics.

[0001571996-24-000090:mdna:73]
We continue to see opportunities to create value and grow as we respond to long-term demand for our IT solutions driven by a data- and AI-enabled world. We have demonstrated our ability to adjust to changing market conditions with complementary solutions and innovation across both segments of our business, an agile workforce, and the strength of our global supply chain. As we continue to innovate and modernize our offerings, we believe that Dell Technologies is well-positioned for long-term profitable growth.

[0001571996-24-000090:mdna:74]
[same as prior period, unchanged from 0001571996-24-000062:mdna:74]

[0001571996-24-000090:mdna:75]
During the second quarter and first six months of Fiscal 2025, net revenue increased 9% and 8%, respectively, primarily driven by an increase in ISG net revenue that was partially offset by a decrease in other businesses net revenue and CSG net revenue. See “Business Unit Results” for further information.

[0001571996-24-000090:mdna:76]
•Product Net Revenue — Product net revenue includes revenue from the sale of hardware products and software licenses. During the second quarter and first six months of Fiscal 2025, product net revenue increased 12% and 10%, respectively, due to an increase in ISG product net revenue, partially offset by a decline in CSG and other businesses product net revenue. ISG product net revenue increased due to growth in our servers and networking offerings. CSG product net revenue decreased primarily as a result of a decline in the average selling prices of our CSG offerings. During the second quarter of Fiscal 2025, CSG product net revenue was also impacted by a decline in units sold. Other businesses product net revenue declined as we no longer act as a distributor of standalone VMware offerings.

[0001571996-24-000090:mdna:77]
•Services Net Revenue — Services net revenue includes revenue from our services offerings and support services related to hardware products and software licenses. During the second quarter and first six months of Fiscal 2025, services net revenue increased 1% and 3%, respectively, driven primarily by growth within services net revenue attributable to CSG, partially offset by a decline in other businesses services net revenue. The increase in CSG services net revenue was primarily attributable to third-party software support and maintenance and support and maintenance associated with products sold in prior periods within our commercial offerings. Other businesses services net revenue declined as we no longer act as a distributor of standalone VMware offerings.

[0001571996-24-000090:mdna:78]
[same as prior period, unchanged from 0001571996-24-000062:mdna:78]

[0001571996-24-000090:mdna:79]
From a geographical perspective, net revenue increased in the Americas and, to a lesser extent, APJ, and decreased in EMEA during both the second quarter and first six months of Fiscal 2025.

[0001571996-24-000090:mdna:80]
[same as prior period, unchanged from 0001571996-24-000062:mdna:80]

[0001571996-24-000090:mdna:81]
During the second quarter of Fiscal 2025, both gross margin and non-GAAP gross margin decreased 1%, to $5.3 billion and $5.5 billion, respectively. During the first six months of Fiscal 2025, gross margin and non-GAAP gross margin both decreased 3%, to $10.1 billion and $10.4 billion, respectively. The declines in gross margin and non-GAAP gross margin during both the second quarter and first six months of Fiscal 2025 were driven by a decrease in CSG gross margin, partially offset by an increase in ISG gross margin. The decrease in CSG gross margin was primarily attributable to a competitive pricing environment which resulted in a decrease in the average selling prices of our CSG offerings. The increase in ISG gross margin was primarily attributable to growth in our AI-optimized server offerings.

[0001571996-24-000090:mdna:82]
During the second quarter of Fiscal 2025, both gross margin and non-GAAP gross margin percentage decreased 230 basis points, to 21.2% and 21.8%, respectively. During the first six months of Fiscal 2025, gross margin and non-GAAP gross margin percentage decreased 230 basis points to 21.4% and 240 basis points to 22.0%, respectively. The decreases in gross margin percentage and non-GAAP gross margin percentage during both the second quarter and first six months of Fiscal 2025 were driven by a shift in mix towards AI-optimized server offerings and, to a lesser extent, a competitive CSG pricing environment.

[0001571996-24-000090:mdna:83]
•Product Gross Margin — During the second quarter of Fiscal 2025, product gross margin and non-GAAP product gross margin decreased 2% to $2.9 billion and 3% to $3.0 billion, respectively. During the first six months of Fiscal 2025, product gross margin and non-GAAP product gross margin decreased 6% to $5.2 billion and 7% to $5.4 billion, respectively. The decreases during both the second quarter and first six months of Fiscal 2025 were primarily driven by a decline in CSG product gross margin, which was primarily attributable to the decline in the average selling prices of our CSG offerings as a result of a competitive pricing environment. The decline in CSG product gross margin was partially offset by an increase in ISG product gross margin that was primarily attributable to growth in our AI-optimized server offerings.

[0001571996-24-000090:mdna:84]
During the second quarter of Fiscal 2025, product gross margin percentage and non-GAAP product gross margin percentage decreased 210 basis points to 15.2% and 230 basis points to 15.6%, respectively. During the first six months of Fiscal 2025, product gross margin percentage and non-GAAP product gross margin percentage decreased 260 basis points to 14.9% and 270 basis points to 15.4%, respectively. The declines during both the second quarter and first six months of Fiscal 2025 were primarily attributable to a shift in mix towards our AI-optimized server offerings and, to a lesser extent, a competitive CSG pricing environment.

[0001571996-24-000090:mdna:85]
62

[0001571996-24-000090:mdna:86]
•Services Gross Margin — During the second quarter of Fiscal 2025, services gross margin and non-GAAP services gross margin decreased 1% to $2.4 billion and remained flat at $2.5 billion, respectively. During the first six months of Fiscal 2025, services gross margin and non-GAAP services gross margin increased 1% to $4.9 billion and 2% to $5.0 billion, respectively. During both the second quarter and first six months of Fiscal 2025, services gross margin and non-GAAP services gross margin benefited from an increase in CSG services gross margin driven by hardware and third-party software support and maintenance as well as support and maintenance associated with products sold in prior periods. Services gross margin and non-GAAP gross margin were also impacted by a decline in other businesses services net revenue as we no longer act as a distributor of standalone VMware offerings.

[0001571996-24-000090:mdna:87]
During the second quarter of Fiscal 2025, services gross margin percentage and non-GAAP services gross margin percentage decreased 80 basis points to 40.1% and 40 basis points to 41.3%, respectively. During the first six months of Fiscal 2025, services gross margin percentage decreased 50 basis points to 40.0% and non-GAAP services gross margin percentage remained flat at 41.2%. During both the second quarter and first six months of Fiscal 2025, services gross margin percentage and non-GAAP services gross margin percentage were impacted by a decrease in CSG services gross margin percentage and, to a lesser extent, ISG services gross margin percentage.

[0001571996-24-000090:mdna:88]
[same as prior period, unchanged from 0001571996-24-000062:mdna:87]

[0001571996-24-000090:mdna:89]
Our gross margin is affected by our ability to achieve competitive pricing with our vendors and contract manufacturers, including through our negotiation of a variety of vendor rebate programs to achieve lower net costs for the various components we include in our products. Under these programs, vendors provide us with rebates or other discounts from the list prices for the components, which are generally elements of their pricing strategy. We account for vendor rebates and other discounts as a reduction in cost of net revenue. We manage our costs on a total net cost basis, which includes supplier list prices reduced by vendor rebates and other discounts.

[0001571996-24-000090:mdna:90]
The terms and conditions of our vendor rebate programs are largely based on product volumes and are generally negotiated either at the beginning of the annual or quarterly period, depending on the program. The timing and amount of vendor rebates and other discounts we receive under the programs may vary from period to period, reflecting changes in the competitive environment. We monitor our component costs and seek to address the effects of any changes to terms that might arise under our vendor rebate programs. Our gross margins for the second quarter and first six months of Fiscal 2025 were not materially affected by any changes to the terms of our vendor rebate programs, as the amounts we received under these programs were generally stable relative to our total net cost. We are not aware of any significant changes to our vendor rebate programs that will materially impact our results in the near term.

[0001571996-24-000090:mdna:91]
63

[0001571996-24-000090:mdna:92]
[same as prior period, unchanged from 0001571996-24-000062:mdna:90]

[0001571996-24-000090:mdna:93]
[same as prior period, unchanged from 0001571996-24-000062:mdna:91]

[0001571996-24-000090:mdna:94]
|  | Three Months Ended |  | Six Months Ended |
|  | August 2, 2024 |  |  |  | August 4, 2023 |  | August 2, 2024 |  |  |  | August 4, 2023 |  |  |  |  |
|  | Dollars |  | % of Net Revenue |  | % Change |  | Dollars |  | % of Net Revenue |  | Dollars |  | % of Net Revenue |  | % Change |  | Dollars |  | % of Net Revenue |  |  |  |  |  |  |
|  | (in millions, except percentages) |  |  |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative | $ | 3,189 |  |  | 12.7 | % |  | (9) | % |  | $ | 3,517 |  |  | 15.3 | % |  | $ | 6,312 |  |  | 13.3 | % |  | (7) | % |  | $ | 6,778 |  |  | 15.4 | % |  |  |  |  |  |  |
| Research and development | 780 |  |  | 3.1 | % |  | 11 | % |  | 705 |  |  | 3.1 | % |  | 1,543 |  |  | 3.3 | % |  | 11 | % |  | 1,393 |  |  | 3.2 | % |  |  |  |  |  |  |
| Total operating expenses | $ | 3,969 |  |  | 15.8 | % |  | (6) | % |  | $ | 4,222 |  |  | 18.4 | % |  | $ | 7,855 |  |  | 16.6 | % |  | (4) | % |  | $ | 8,171 |  |  | 18.6 | % |  |  |  |  |  |  |
|  | Three Months Ended |  | Six Months Ended |
|  | August 2, 2024 |  |  |  | August 4, 2023 |  | August 2, 2024 |  |  |  | August 4, 2023 |  |  |  |  |
|  | Dollars |  | % of Net Revenue |  | % Change |  | Dollars |  | % of Net Revenue |  | Dollars |  | % of Net Revenue |  | % Change |  | Dollars |  | % of Net Revenue |  |  |  |  |  |  |
|  | (in millions, except percentages) |
| Non-GAAP operating expenses | $ | 3,430 |  |  | 13.7 | % |  | (4) | % |  | $ | 3,559 |  |  | 15.5 | % |  | $ | 6,903 |  |  | 14.6 | % |  | (3) | % |  | $ | 7,125 |  |  | 16.2 | % |  |  |  |  |  |  |

[0001571996-24-000090:mdna:95]
During the second quarter and first six months of Fiscal 2025, total operating expenses decreased 6% and 4%, respectively, due to a decline in selling, general, and administrative expenses.

[0001571996-24-000090:mdna:96]
•Selling, General, and Administrative — During the second quarter and first six months of Fiscal 2025, selling, general, and administrative expenses decreased 9% and 7%, respectively, driven by a decrease in employee compensation and benefits expense, principally due to a decline in overall headcount.

[0001571996-24-000090:mdna:97]
•Research and Development — Research and development (“R&D”) expenses are primarily composed of personnel-related expenses incurred in connection with product development. R&D expenses increased 11% during both the second quarter and first six months of Fiscal 2025, principally due to an increase in R&D-related employee compensation and benefits expense.

[0001571996-24-000090:mdna:98]
As a percentage of net revenue, R&D expenses for both the second quarter of Fiscal 2025 and Fiscal 2024 were 3.1% and for the first six months of Fiscal 2025 and Fiscal 2024 were 3.3% and 3.2%, respectively. During the first six months of Fiscal 2025, the increase in R&D expenses as a percentage of net revenue was attributable to continued support of R&D initiatives.

[0001571996-24-000090:mdna:99]
During the second quarter and first six months of Fiscal 2025, non-GAAP operating expenses decreased 4% and 3%, respectively, driven by a decline in employee compensation and benefits expense, primarily resulting from a decline in overall headcount. The decline in employee compensation and benefits expense was partially offset by continued support of R&D initiatives.

[0001571996-24-000090:mdna:100]
We continue to make strategic investments designed to enable growth and innovation, while balancing our efforts to drive cost efficiencies in the business. We also expect to continue making investments in support of our own digital transformation which aims to streamline and optimize our business processes.

[0001571996-24-000090:mdna:101]
[same as prior period, unchanged from 0001571996-24-000062:mdna:99]

[0001571996-24-000090:mdna:102]
During the second quarter of Fiscal 2025, operating income and non-GAAP operating income increased by 15% to $1.3 billion and 3% to $2.0 billion, respectively. During the first six months of Fiscal 2025, operating income and non-GAAP operating income increased by 1% to $2.3 billion and decreased by 2% to $3.5 billion, respectively. During both the second quarter and first six months of Fiscal 2025, operating income and non-GAAP operating income were impacted by an increase in ISG operating income driven by our servers and networking offerings and a decrease in CSG operating income primarily driven by our commercial offerings.

[0001571996-24-000090:mdna:103]
During the second quarter of Fiscal 2025, operating income and non-GAAP operating income as a percentage of net revenue increased 30 basis points to 5.4% and decreased 50 basis points to 8.1%, respectively. During the first six months of Fiscal 2025, operating income and non-GAAP operating income as a percentage of net revenue decreased 30 basis points to 4.8% and 80 basis points to 7.4%, respectively. Operating income and non-GAAP operating income as a percentage of net revenue during both the second quarter and first six months of Fiscal 2025 were impacted by a decline in gross margin as a percentage of net revenue as a result of a shift in mix towards AI-optimized server offerings and, to a lesser extent, a competitive CSG pricing environment. The decline in gross margin as a percentage of net revenue was offset by the favorable impact of a decrease in operating expense rate that was driven by strong ISG net revenue growth coupled with continued disciplined cost management.

[0001571996-24-000090:mdna:104]
[same as prior period, unchanged from 0001571996-24-000062:mdna:102]

[0001571996-24-000090:mdna:105]
[same as prior period, unchanged from 0001571996-24-000062:mdna:103]

[0001571996-24-000090:mdna:106]
|  | Three Months Ended |  | Six Months Ended |
|  | August 2, 2024 |  | August 4, 2023 |  | August 2, 2024 |  | August 4, 2023 |  |  |
|  | (in millions) |  |  |
| Interest and other, net: |  |  |  |  |  |  |  |  |  |
| Investment income, primarily interest | $ | 38 |  |  | $ | 66 |  |  | $ | 92 |  |  | $ | 125 |  |  |  |
| Gain (loss) on investments, net | 5 |  |  | (29) |  |  | (25) |  |  | (44) |  |  |  |
| Interest expense | (387) |  |  | (352) |  |  | (730) |  |  | (757) |  |  |  |
| Foreign exchange | (13) |  |  | (65) |  |  | (51) |  |  | (97) |  |  |  |
| Other | 4 |  |  | (71) |  |  | (12) |  |  | (42) |  |  |  |
| Total interest and other, net | $ | (353) |  |  | $ | (451) |  |  | $ | (726) |  |  | $ | (815) |  |  |  |

[0001571996-24-000090:mdna:107]
During the second quarter of Fiscal 2025, the change in interest and other, net was favorable, primarily as a result of the favorable impact in the Other category coupled with reduced foreign exchange impacts. During the first six months of Fiscal 2025, the change in interest and other, net was favorable, primarily due to reduced foreign exchange impacts and a reduction in interest expense.

[0001571996-24-000090:mdna:108]
[same as prior period, unchanged from 0001571996-24-000062:mdna:106]

[0001571996-24-000090:mdna:109]
[same as prior period, unchanged from 0001571996-24-000062:mdna:107]

[0001571996-24-000090:mdna:110]
|  | Three Months Ended |  | Six Months Ended |
|  | August 2, 2024 |  | August 4, 2023 |  | August 2, 2024 |  | August 4, 2023 |  |  |
|  | (in millions, except percentages) |  |  |
| Income before income taxes | $ | 989 |  |  | $ | 714 |  |  | $ | 1,536 |  |  | $ | 1,419 |  |  |  |
| Income tax expense (benefit) | $ | 148 |  |  | $ | 259 |  |  | $ | (260) |  |  | $ | 386 |  |  |  |
| Effective income tax rate | 15.0 | % |  | 36.3 | % |  | (16.9) | % |  | 27.2 | % |  |  |

[0001571996-24-000090:mdna:111]
For the second quarter of Fiscal 2025 and Fiscal 2024, our effective income tax rate was 15.0% and 36.3%, respectively. For the first six months of Fiscal 2025 and Fiscal 2024, our effective income tax rate was (16.9)% and 27.2%, respectively. The changes in our effective income tax rate were primarily driven by discrete tax items. For the first six months of Fiscal 2025, we recorded discrete tax benefits of $0.4 billion related to changes in uncertain tax benefits resulting from the expiration of certain statutes of limitations and $0.2 billion related to stock-based compensation.

[0001571996-24-000090:mdna:112]
Our effective income tax rate can fluctuate depending on the geographic distribution of our worldwide earnings, as our foreign earnings are generally taxed at lower rates than in the United States. The differences between our effective income tax rates and the U.S. federal statutory rate of 21% principally result from the geographical distribution of income, differences between the book and tax treatment of certain items, and discrete tax items. In certain jurisdictions, our tax rate is significantly less than the applicable statutory rate as a result of tax holidays. The majority of our foreign income subject to these tax holidays is attributable to Singapore and China. A significant portion of these income tax benefits relates to a tax holiday that will be effective until January 31, 2029. Most of our other tax holidays will expire in whole or in part during Fiscal 2030 and Fiscal 2031. Many of these tax holidays and reduced tax rates may be extended when certain conditions are met or may be terminated early if certain conditions are not met or as a result of changes in tax legislation. As of August 2, 2024, we were not aware of any matters of non-compliance or enacted tax legislative changes affecting these tax holidays.

[0001571996-24-000090:mdna:113]
Many countries have enacted or are in the process of enacting laws based on the Pillar Two proposal relating to a global minimum tax issued by the Organisation for Economic Co-operation and Development (“OECD”). While we expect our effective income tax rate and cash income tax payments could increase in future years as a result of the global minimum tax, we do not expect the tax will have a material impact to our Fiscal 2025 consolidated results of operations. Our assessment could be affected by legislative guidance and future enactment of additional provisions within the Pillar Two framework, particularly in countries in which we have tax holidays and incentives.

[0001571996-24-000090:mdna:114]
[same as prior period, unchanged from 0001571996-24-000062:mdna:112]

[0001571996-24-000090:mdna:115]
[same as prior period, unchanged from 0001571996-24-000062:mdna:113]

[0001571996-24-000090:mdna:116]
During the second quarter of Fiscal 2025, net income and non-GAAP net income increased 85% to $0.8 billion and 7% to $1.4 billion, respectively, due to an increase in operating income and, to a lesser extent, the favorable impact of a decline in income tax expense.

[0001571996-24-000090:mdna:117]
During the first six months of Fiscal 2025, net income and non-GAAP net income increased 74% to $1.8 billion and 2% to $2.3 billion, respectively. Net income increased primarily due to the impact of an income tax benefit. Non-GAAP net income increased primarily due to the impact of a decline in income tax expense.

[0001571996-24-000090:mdna:118]
66

[0001571996-24-000090:mdna:119]
[same as prior period, unchanged from 0001571996-24-000062:mdna:117]

[0001571996-24-000090:mdna:120]
Our reportable segments are based on the ISG and CSG business units. A description of our business units is provided under “Introduction.” See Note 16 of the Notes to the Condensed Consolidated Financial Statements included in this report for a reconciliation of net revenue and operating income by reportable segment to consolidated net revenue and consolidated operating income, respectively.

[0001571996-24-000090:mdna:121]
[same as prior period, unchanged from 0001571996-24-000062:mdna:119]

[0001571996-24-000090:mdna:122]
[same as prior period, unchanged from 0001571996-24-000062:mdna:120]

[0001571996-24-000090:mdna:123]
|  | Three Months Ended |  | Six Months Ended |
|  | August 2, 2024 |  | % Change |  | August 4, 2023 |  | August 2, 2024 |  | % Change |  | August 4, 2023 |  |  |  |  |
|  | (in millions, except percentages) |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Servers and networking | $ | 7,672 |  |  | 80 | % |  | $ | 4,274 |  | $ | 13,138 |  | 62 | % |  | $ | 8,111 |  |  |  |  |
| Storage | 3,974 |  |  | (5) | % |  | 4,187 |  | 7,735 |  | (3) | % |  | 7,943 |  |  |  |  |
| Total ISG net revenue | $ | 11,646 |  |  | 38 | % |  | $ | 8,461 |  | $ | 20,873 |  | 30 | % |  | $ | 16,054 |  |  |  |  |
| Operating income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| ISG operating income | $ | 1,284 |  |  | 22 | % |  | $ | 1,049 |  | $ | 2,020 |  | 13 | % |  | $ | 1,789 |  |  |  |  |
| % of segment net revenue | 11.0 | % |  |  |  | 12.4 | % |  | 9.7 | % |  |  |  | 11.1 | % |  |  |  |  |

[0001571996-24-000090:mdna:124]
Net Revenue — During the second quarter and first six months of Fiscal 2025, ISG net revenue increased 38% and 30%, respectively, driven by strength in our servers and networking offerings.

[0001571996-24-000090:mdna:125]
Revenue from sales of servers and networking increased 80% and 62%, respectively during the second quarter and first six months of Fiscal 2025. The increase in servers and networking revenue was driven by growth in our AI-optimized server offerings and, to a lesser extent, our traditional server and networking offerings.

[0001571996-24-000090:mdna:126]
Storage revenue decreased 5% and 3%, respectively, during the second quarter and first six months of Fiscal 2025, primarily due to a decline in net revenue of our converged and hyper-converged infrastructure offerings.

[0001571996-24-000090:mdna:127]
From a geographical perspective, net revenue attributable to ISG increased in the Americas and, to a lesser extent, in APJ and EMEA during the second quarter and first six months of Fiscal 2025.

[0001571996-24-000090:mdna:128]
Operating Income — During both the second quarter and first six months of Fiscal 2025, ISG operating income as a percentage of net revenue decreased 140 basis points to 11.0% and 9.7%, respectively, principally due to a decrease in gross margin rate as a percentage of net revenue. Gross margin rate decreased primarily as the result of a shift in mix towards AI-optimized server offerings, partially offset by a decline in input costs. The decrease in gross margin as a percentage of net revenue was partially offset by a decrease in operating expense as a percentage of net revenue primarily due to strong ISG net revenue growth coupled with continued disciplined cost management.

[0001571996-24-000090:mdna:129]
[same as prior period, unchanged from 0001571996-24-000062:mdna:126]

[0001571996-24-000090:mdna:130]
[same as prior period, unchanged from 0001571996-24-000062:mdna:127]

[0001571996-24-000090:mdna:131]
|  | Three Months Ended |  | Six Months Ended |
|  | August 2, 2024 |  | % Change |  | August 4, 2023 |  | August 2, 2024 |  | % Change |  | August 4, 2023 |  |  |  |  |
|  | (in millions, except percentages) |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 10,556 |  |  | — | % |  | $ | 10,554 |  | $ | 20,710 |  | 1 | % |  | $ | 20,416 |  |  |  |  |
| Consumer | 1,858 |  |  | (22) | % |  | 2,388 |  | 3,671 |  | (19) | % |  | 4,509 |  |  |  |  |
| Total CSG net revenue | $ | 12,414 |  |  | (4) | % |  | $ | 12,942 |  | $ | 24,381 |  | (2) | % |  | $ | 24,925 |  |  |  |  |
| Operating income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| CSG operating income | $ | 767 |  |  | (21) | % |  | $ | 969 |  | $ | 1,499 |  | (19) | % |  | $ | 1,861 |  |  |  |  |
| % of segment net revenue | 6.2 | % |  |  |  | 7.5 | % |  | 6.1 | % |  |  |  | 7.5 | % |  |  |  |  |

[0001571996-24-000090:mdna:132]
Net Revenue — During the second quarter of Fiscal 2025, CSG net revenue decreased 4% primarily due to a decrease in units sold. During the first six months of Fiscal 2025, CSG net revenue decreased 2% as the result of a decrease in the average selling prices of our offerings due to a competitive pricing environment.

[0001571996-24-000090:mdna:133]
Commercial net revenue remained flat and increased 1%, respectively, during the second quarter and first six months of Fiscal 2025. During both the second quarter and first six months of Fiscal 2025, commercial net revenue was impacted by an increase in units sold and a decrease in the average selling prices of our commercial offerings.

[0001571996-24-000090:mdna:134]
Consumer net revenue decreased 22% and 19%, respectively, during the second quarter and first six months of Fiscal 2025, principally due to a decline in units sold and, to a lesser extent, a decline in the average selling price of our consumer offerings.

[0001571996-24-000090:mdna:135]
From a geographical perspective, net revenue attributable to CSG decreased across all regions during the second quarter of Fiscal 2025. During the first six months of Fiscal 2025, net revenue attributable to CSG increased in EMEA and decreased in the Americas and APJ.

[0001571996-24-000090:mdna:136]
Operating Income — During the second quarter and first six months of Fiscal 2025, CSG operating income as a percentage of net revenue decreased 130 basis points to 6.2% and 140 basis points to 6.1%, respectively, primarily due to a decline in gross margin rate, partially offset by a decrease in operating expenses as a percentage of net revenue. The decline in gross margin rate was primarily due to a decrease in the average selling prices of our offerings as a result of a competitive pricing environment. The decline in operating expenses as a percentage of net revenue was due to continued disciplined cost management.

[0001571996-24-000090:mdna:137]
[same as prior period, unchanged from 0001571996-24-000062:mdna:135]

[0001571996-24-000090:mdna:138]
[same as prior period, unchanged from 0001571996-24-000062:mdna:136]

[0001571996-24-000090:mdna:139]
We sell products and services directly to customers and through a variety of sales channels, including retail distribution. Our accounts receivable, net, was $11.4 billion and $9.3 billion as of August 2, 2024 and February 2, 2024, respectively. The increase in accounts receivable, net, was driven primarily by an increase in revenue. We maintain an allowance for expected credit losses to cover receivables that may be deemed uncollectible. The allowance for expected credit losses is an estimate based on an analysis of historical loss experience, current receivables aging, and management’s assessment of current conditions and its reasonable and supportable expectation of future conditions, as well as specific identifiable customer accounts that are deemed at risk. As of August 2, 2024 and February 2, 2024, the allowance for expected credit losses was $78 million and $71 million, respectively. Based on our assessment, we believe that we are adequately reserved for expected credit losses.

[0001571996-24-000090:mdna:140]
[same as prior period, unchanged from 0001571996-24-000062:mdna:138]

[0001571996-24-000090:mdna:141]
We offer or arrange various financing options and services for our customers globally, including through captive financing operations. DFS originates, collects, and services customer receivables primarily related to the purchase of our product, software, and service solutions. We further strengthen customer relationships through flexible consumption models, including utility, subscription, and as-a-Service models, which enable our customers the option to pay over time to provide them with financial and operational flexibility. New financing originations were $2.4 billion for both the second quarter of Fiscal 2025 and Fiscal 2024, and $4.3 billion and $4.2 billion for first six months of Fiscal 2025 and Fiscal 2024, respectively.

[0001571996-24-000090:mdna:142]
Our leases are generally classified as sales-type leases or operating leases. On commencement of sales-type leases, we recognize profit up-front, and recognize amounts due from the customer under the lease contract as financing receivables. Interest income is recognized as net product revenue over the term of the lease. Upon origination of operating leases, we record equipment under operating leases, classified as property, plant, and equipment. We recognize product revenue and depreciation expense, classified as cost of net revenue, over the contract term.

[0001571996-24-000090:mdna:143]
As of August 2, 2024 and February 2, 2024, our financing receivables, net were $11.1 billion and $10.5 billion, respectively. We maintain an allowance to cover expected financing receivables credit losses and evaluate credit loss expectations based on our total portfolio. The principal charge-off rate for our financing receivables portfolio was 0.7% and 0.6% for the second quarter of Fiscal 2025 and Fiscal 2024, respectively, and 0.5% and 0.6% for the first six months of Fiscal 2025 and Fiscal 2024, respectively. The credit quality of our financing receivables remains strong due to the mix of high-quality commercial accounts in our portfolio. We continue to monitor broader economic indicators and their potential impact on future credit loss performance. We have an extensive process to manage our exposure to customer credit risk, including active management of credit lines and our collection activities. We also sell selected fixed-term financing receivables without recourse to unrelated third parties on a periodic basis, primarily to manage certain concentrations of customer credit exposure. Based on our assessment of the customer financing receivables, we believe that we are adequately reserved.

[0001571996-24-000090:mdna:144]
We retain a residual interest in equipment leased under our lease programs. As of August 2, 2024 and February 2, 2024, the residual interest recorded as part of financing receivables was $166 million and $157 million, respectively. The amount of the residual interest is established at the inception of the lease based upon estimates of the value of the equipment at the end of the lease term using historical studies, industry data, and future value-at-risk demand valuation methods. On a quarterly basis, we assess the carrying amount of our recorded residual values for expected losses. Generally, expected losses as a result of residual value risk on equipment under lease are not considered to be significant primarily because of the existence of a secondary market with respect to the equipment. Further, the lease agreement defines applicable return conditions and remedies for non-compliance to ensure that the leased equipment will be in good operating condition upon return. No expected losses were recorded related to residual assets during the second quarter and first six months of Fiscal 2025 and Fiscal 2024.

[0001571996-24-000090:mdna:145]
As of both August 2, 2024 and February 2, 2024, equipment under operating leases, net was $2.2 billion. We assess the carrying amount of the equipment under operating leases for impairment whenever events or circumstances may indicate that an impairment has occurred. No material impairment losses were recorded related to such equipment during the second quarter and first six months of Fiscal 2025 and Fiscal 2024.

[0001571996-24-000090:mdna:146]
DFS offerings are initially funded through cash on hand at the time of origination, most of which is subsequently replaced with asset-backed financing. For DFS offerings which qualify as sales-type leases, the initial funding of financing receivables is reflected as an impact to cash flows from operations and is largely subsequently offset by cash proceeds from financing. For DFS operating leases, the initial funding is classified as a capital expenditure and reflected as an impact to cash flows used in investing activities.

[0001571996-24-000090:mdna:147]
[same as prior period, unchanged from 0001571996-24-000062:mdna:145]

[0001571996-24-000090:mdna:148]
70

[0001571996-24-000090:mdna:149]
[same as prior period, unchanged from 0001571996-24-000062:mdna:147]

[0001571996-24-000090:mdna:150]
[same as prior period, unchanged from 0001571996-24-000062:mdna:148]

[0001571996-24-000090:mdna:151]
We rely on operating cash flows, which are impacted by trends in the demand environment, as our primary source of liquidity for our ongoing business operations. We monitor the efficiency of our balance sheet to ensure that we have adequate liquidity to support our business and strategic initiatives.

[0001571996-24-000090:mdna:152]
In addition to internally generated cash, we have access to other capital sources to finance our strategic initiatives and fund growth in our financing operations. Our strategy is to deploy capital from any potential source, whether internally generated cash or debt, depending on the adequacy and availability of that source of capital and whether it can be accessed in a cost-effective manner.

[0001571996-24-000090:mdna:153]
We believe that our current cash and cash equivalents, together with cash that will be provided by future operations and borrowings and issuances expected to be available under our revolving credit facility and commercial paper program, respectively, will be sufficient over the next twelve months and for the foreseeable future thereafter to meet our material cash requirements, including funding of our operations, debt-related payments, capital expenditures, and other corporate needs.

[0001571996-24-000090:mdna:154]
[same as prior period, unchanged from 0001571996-24-000062:mdna:152]

[0001571996-24-000090:mdna:155]
[same as prior period, unchanged from 0001571996-24-000062:mdna:153]

[0001571996-24-000090:mdna:156]
|  | August 2, 2024 |  | February 2, 2024 |
|  | (in millions) |
| Cash and cash equivalents, and available borrowings: |  |  |  |
| Cash and cash equivalents | $ | 4,550 |  |  | $ | 7,366 |  |
| Remaining available borrowings under the revolving credit facility | 5,999 |  |  | 5,999 |  |
| Total cash and cash equivalents, and available borrowings | $ | 10,549 |  |  | $ | 13,365 |  |

[0001571996-24-000090:mdna:157]
During the first six months of Fiscal 2025, cash and cash equivalents decreased by $2.8 billion primarily due to the return of capital to our stockholders, net repayment of Senior Notes and DFS debt, capital expenditures, and payments to settle employee tax withholdings on stock-based compensation, the effect of which was partially offset by cash flows from operations.

[0001571996-24-000090:mdna:158]
As of August 2, 2024, our revolving credit facility had a maximum capacity of $6.0 billion. Available borrowings under this facility are reduced by draws on the facility and outstanding letters of credit. As of August 2, 2024, there were no borrowings outstanding under the facility and remaining available borrowings totaled approximately $6.0 billion. The revolving credit facility also acts as a backstop to provide liquidity support for our commercial paper program.

[0001571996-24-000090:mdna:159]
We maintain a commercial paper program under which we may issue unsecured notes in a maximum aggregate face amount of $5.0 billion outstanding at any time, with maturities up to 397 days from the date of issue. As of August 2, 2024, we had no outstanding issuances under the program.

[0001571996-24-000090:mdna:160]
We may regularly use our available borrowings from the revolving credit facility and issuances under the commercial paper program, generally on a short-term basis, for general corporate purposes. See the following discussion for additional information about our debt.

[0001571996-24-000090:mdna:161]
[same as prior period, unchanged from 0001571996-24-000062:mdna:159]

[0001571996-24-000090:mdna:162]
[same as prior period, unchanged from 0001571996-24-000062:mdna:160]

[0001571996-24-000090:mdna:163]
|  | August 2, 2024 |  | Change |  | February 2, 2024 |
|  | (in millions) |
| Core debt |  |  |  |  |  |
| Senior Notes | $ | 14,580 |  |  | $ | (1,027) |  |  | $ | 15,607 |  |
| Legacy Notes | 952 |  |  | — |  |  | 952 |  |
| DFS allocated debt | (2,492) |  |  | (852) |  |  | (1,640) |  |
| Total core debt | 13,040 |  |  | (1,879) |  |  | 14,919 |  |
| DFS related debt |  |  |  |  |  |
| DFS debt | 9,133 |  |  | (359) |  |  | 9,492 |  |
| DFS allocated debt | 2,492 |  |  | 852 |  |  | 1,640 |  |
| Total DFS related debt | 11,625 |  |  | 493 |  |  | 11,132 |  |
| Other | 79 |  |  | (92) |  |  | 171 |  |
| Total debt, principal amount | 24,744 |  |  | (1,478) |  |  | 26,222 |  |
| Carrying value adjustments | (222) |  |  | 6 |  |  | (228) |  |
| Total debt, carrying value | $ | 24,522 |  |  | $ | (1,472) |  |  | $ | 25,994 |  |

[0001571996-24-000090:mdna:164]
The outstanding principal amount of our debt decreased $1.5 billion to $24.7 billion as of August 2, 2024, driven primarily by net repayments of our Senior Notes and DFS debt.

[0001571996-24-000090:mdna:165]
We define core debt as the total principal amount of our debt, less DFS related debt and other debt. Our core debt was $13.0 billion and $14.9 billion as of August 2, 2024 and February 2, 2024, respectively. See Note 6 of the Notes to the Condensed Consolidated Financial Statements included in this report for additional information about our debt.

[0001571996-24-000090:mdna:166]
DFS related debt primarily represents debt from our securitization and structured financing programs. Our risk of loss under these programs is limited to transferred lease and loan payments and associated equipment, as the credit holders have no recourse to Dell Technologies.

[0001571996-24-000090:mdna:167]
To fund expansion of the DFS business, we balance the use of the securitization and structured financing programs with other sources of liquidity. We approximate the amount of our core debt used to fund the DFS business by applying a 7:1 debt-to-equity ratio to the sum of our financing receivables balance and equipment under operating leases, net. The debt-to-equity ratio is based on the underlying credit quality of the assets. See Note 4 of the Notes to the Condensed Consolidated Financial Statements included in this report for additional information about our DFS debt.

[0001571996-24-000090:mdna:168]
We believe we will continue to be able to make our debt principal and interest payments, including payment of short-term maturities, from existing and expected sources of cash, primarily from operating cash flows. Cash used for debt principal and interest payments may include short-term borrowings under our commercial paper program, our revolving credit facility, or other borrowings. Under our variable-rate debt, we could experience variations in our future interest expense from potential fluctuations in applicable reference rates, or from possible fluctuations in the level of DFS debt required to meet future demand for customer financing.

[0001571996-24-000090:mdna:169]
[same as prior period, unchanged from 0001571996-24-000062:mdna:167]

[0001571996-24-000090:mdna:170]
[same as prior period, unchanged from 0001571996-24-000062:mdna:168]

[0001571996-24-000090:mdna:171]
[same as prior period, unchanged from 0001571996-24-000062:mdna:169]

[0001571996-24-000090:mdna:172]
|  | Six Months Ended |
|  | August 2, 2024 |  | August 4, 2023 |  |  |
|  | (in millions) |
| Net change in cash from: |  |  |  |  |  |
| Operating activities | $ | 2,383 |  |  | $ | 4,991 |  |  |  |
| Investing activities | (1,013) |  |  | (1,289) |  |  |  |
| Financing activities | (4,109) |  |  | (3,829) |  |  |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash | (97) |  |  | (117) |  |  |  |
| Change in cash, cash equivalents, and restricted cash | $ | (2,836) |  |  | $ | (244) |  |  |  |

[0001571996-24-000090:mdna:173]
Operating Activities — Cash provided by operating activities was $2.4 billion during the first six months of Fiscal 2025, and was driven by profitability, partially offset by working capital dynamics primarily due to growth in our AI-optimized server offerings. During the first six months of Fiscal 2024, cash provided by operating activities was $5.0 billion, which was primarily driven by profitability and working capital management as we reduced inventory, demonstrated strong cash collections performance, and benefited from the timing of purchases and payments to vendors. Cash provided by operating activities also reflected the impact of the $0.9 billion net payment to settle the Class V transaction litigation.

[0001571996-24-000090:mdna:174]
Investing Activities — Investing activities primarily consist of cash used to fund capital expenditures for property, plant, and equipment inclusive of equipment under DFS operating leases and equipment used to support our as-a-Service offerings, which we refer to collectively as assets in a customer contract. Additional activities may include capitalized software development costs, acquisitions and divestitures, and the maturities, sales, and purchases of investments. Cash used in investing activities was $1.0 billion and $1.3 billion during the first six months of Fiscal 2025 and Fiscal 2024, respectively, and was primarily applied to capital expenditures.

[0001571996-24-000090:mdna:175]
Financing Activities — Financing activities primarily consist of the proceeds and repayments of debt and return of capital to our stockholders. Cash used in financing activities was $4.1 billion during the first six months of Fiscal 2025 and primarily consisted of repurchases of common stock, inclusive of payments to settle employee tax withholdings on stock-based compensation, net repayments of our Senior Notes and DFS debt, and the payment of quarterly dividends. During the first six months of Fiscal 2024, cash used in financing activities was $3.8 billion and primarily consisted of principal repayments of our Senior Notes, repurchases of common stock, inclusive of payments to settle employee tax withholdings on stock-based compensation, and the payment of quarterly dividends.

[0001571996-24-000090:mdna:176]
DFS Cash Flow Impacts — DFS offerings are initially funded through cash on hand at the time of origination, most of which is subsequently replaced with asset-backed financing. For DFS offerings that qualify as sales-type leases, the initial funding of financing receivables is reflected as an impact to cash flows from operations and is largely subsequently offset by cash proceeds from financing. For operating leases, the initial funding is classified as a capital expenditure and reflected as cash flows used in investing activities. DFS new financing originations were $4.3 billion and $4.2 billion during the first six months of Fiscal 2025 and Fiscal 2024, respectively. As of August 2, 2024, we had $11.1 billion of total net financing receivables and $2.2 billion of equipment under operating leases, net.

[0001571996-24-000090:mdna:177]
Supply Chain Finance Program — We maintain a Supply Chain Finance Program (the “SCF Program”) that enables eligible suppliers to sell receivables due from us to a third-party financial institution at the suppliers’ sole discretion. The SCF Program does not impact our liquidity, as payments by us to participating suppliers are remitted to the financial institution on the original invoice due date. Further, we negotiate payment terms with our suppliers regardless of their decision to participate in the SCF Program. Payments made under the SCF Program are included in cash flows from operating activities on the Condensed Consolidated Statements of Cash Flows. See Note 17 of the Notes to the Condensed Consolidated Financial Statements included in this report for more information regarding the SCF Program.

[0001571996-24-000090:mdna:178]
[same as prior period, unchanged from 0001571996-24-000062:mdna:176]

[0001571996-24-000090:mdna:179]
Capital Expenditures — We spent $1.3 billion during both the first six months of Fiscal 2025 and Fiscal 2024, respectively, on property, plant, and equipment and capitalized software development costs. Of total expenditures incurred, funding of assets in a customer contract totaled $0.7 billion and $0.5 billion during the first six months of Fiscal 2025 and Fiscal 2024, respectively. Product demand, product mix, the use of contract manufacturers, and ongoing investments in operating and information technology infrastructure influence the level and prioritization of our capital expenditures.

[0001571996-24-000090:mdna:180]
Repurchases of Common Stock — Effective as of September 23, 2021, our Board of Directors approved a stock repurchase program with no fixed expiration date under which we are authorized to repurchase up to $5.0 billion of shares of our Class C Common Stock. Effective as of October 5, 2023, the Board of Directors approved the repurchase of an additional $5.0 billion of shares of the Class C Common Stock with no fixed expiration date. Following the additional approval, we had approximately $5.7 billion in cumulative authorized amount remaining under the stock repurchase program.

[0001571996-24-000090:mdna:181]
During the first six months of Fiscal 2025, we repurchased approximately 12 million shares of Class C Common Stock for a total purchase price of approximately $1.4 billion. During the first six months of Fiscal 2024, we repurchased approximately 11 million shares of Class C Common Stock for a total purchase price of approximately $0.5 billion.

[0001571996-24-000090:mdna:182]
Dividend Payments — On February 29, 2024, we announced that the Board of Directors approved a 20% increase in the dividend rate to $0.445 per share per fiscal quarter beginning in the first quarter of Fiscal 2025. During the first six months of Fiscal 2025 and Fiscal 2024, the Company paid $0.7 billion and $0.5 billion in dividends and dividend equivalents at a rate of $0.445 and $0.37 per share per fiscal quarter, respectively.

[0001571996-24-000090:mdna:183]
Purchase Obligations — Purchase obligations are defined as contractual obligations to purchase goods or services that are enforceable and legally binding on us. These obligations specify all significant terms, including fixed or minimum quantities to be purchased; fixed, minimum, or variable price provisions; and the approximate timing of the transaction. Purchase obligations do not include contracts that may be canceled without penalty.

[0001571996-24-000090:mdna:184]
We utilize several suppliers to manufacture sub-assemblies for our products. Our efficient supply chain management allows us to enter into flexible and mutually beneficial purchase arrangements with our suppliers in order to minimize inventory risk. Consistent with industry practice, we acquire raw materials or other goods and services, including product components, by issuing to suppliers authorizations to purchase based on our projected demand and manufacturing needs. These purchase orders are typically fulfilled within 30 days and are entered into during the ordinary course of business in order to establish best pricing and continuity of supply for our production. Purchase orders are not included in purchase obligations, as they typically represent our authorization to purchase rather than binding purchase obligations.

[0001571996-24-000090:mdna:185]
As of August 2, 2024, the Company had purchase obligations of $7.2 billion, of which $6.0 billion was payable within 12 months.

[0001571996-24-000090:mdna:186]
[same as prior period, unchanged from 0001571996-24-000062:mdna:188]

[0001571996-24-000090:mdna:187]
[same as prior period, unchanged from 0001571996-24-000062:mdna:183]

[0001571996-24-000090:mdna:188]
We regularly monitor economic conditions and associated impacts on the financial markets and our business. We consistently evaluate the financial health of our supplier base, carefully manage customer credit, diversify counterparty risk, and monitor the concentration risk of our cash and cash equivalents balances globally. We routinely monitor our financial exposure to borrowers and counterparties.

[0001571996-24-000090:mdna:189]
We monitor credit risk associated with our financial counterparties using various market credit risk indicators such as credit ratings issued by nationally recognized credit rating agencies and changes in market credit default swap levels. We perform periodic evaluations of our positions with these counterparties and may limit exposure to any one counterparty in accordance with our policies. We monitor and manage these activities depending on current and expected market developments.

[0001571996-24-000090:mdna:190]
We use derivative instruments to hedge certain foreign currency exposures. We use forward contracts and purchased options designated as cash flow hedges to protect against the foreign currency exchange rate risks inherent in our forecasted transactions denominated in currencies other than the U.S. dollar. In addition, we primarily use forward contracts and may use purchased options to hedge monetary assets and liabilities denominated in a foreign currency. See Note 7 of the Notes to the Condensed Consolidated Financial Statements included in this report for additional information about our use of derivative instruments.

[0001571996-24-000090:mdna:191]
We are exposed to interest rate risk related to our variable-rate debt portfolio. In the normal course of business we follow established policies and procedures to manage this risk, including monitoring of our asset and liability mix and the use of derivative instruments. As a result, we do not anticipate any material losses from interest rate risk.

[0001571996-24-000090:mdna:192]
75

[0001571996-24-000090:mdna:193]
[same as prior period, unchanged from 0001571996-24-000062:mdna:189]

[0001571996-24-000090:mdna:194]
The Company’s outstanding senior notes (“Senior Notes”) are registered, unsecured, and issued by Dell International L.L.C. and EMC Corporation (the “Issuers”), both of which are wholly-owned subsidiaries of Dell Technologies Inc. The Senior Notes are guaranteed on a joint and several unsecured basis by Dell Technologies Inc. and its wholly-owned subsidiaries, Denali Intermediate, Inc. and Dell Inc. (collectively, the “Guarantors”).

[0001571996-24-000090:mdna:195]
Basis of Preparation of the Summarized Financial Information — The tables below are summarized financial information provided in conformity with Rule 13-01 of the SEC’s Regulation S-X. The summarized financial information of the Issuers and Guarantors (collectively, the “Obligor Group”) is presented on a combined basis, excluding intercompany balances and transactions between entities in the Obligor Group. The Obligor Group’s investment balances in Non-Obligor Subsidiaries have been excluded. The Obligor Group’s amounts due from, amounts due to, and transactions with Non-Obligor Subsidiaries have been presented separately.

[0001571996-24-000090:mdna:196]
[same as prior period, unchanged from 0001571996-24-000062:mdna:192]

[0001571996-24-000090:mdna:197]
|  | Six Months Ended |
|  | August 2, 2024 |
|  | (in millions) |
| Net revenue (a) | $ | 3,906 |  |
| Gross margin (b) | 1,883 |  |
| Operating income (c) | 48 |  |
| Interest and other, net (d) | (2,085) |  |
| Loss before income taxes | $ | (2,037) |  |
| Net loss attributable to Obligor Group | $ | (1,447) |  |

[0001571996-24-000090:mdna:198]
[same as prior period, unchanged from 0001571996-24-000062:mdna:194]

[0001571996-24-000090:mdna:199]
(a)    Includes net revenue from Non-Obligor Subsidiaries of $37 million.

[0001571996-24-000090:mdna:200]
(b)    Includes cost of net revenue from the resale of solutions purchased from Non-Obligor Subsidiaries of $522 million.

[0001571996-24-000090:mdna:201]
(c)    Includes operating expenses from shared services provided by Non-Guarantor Subsidiaries of $246 million.

[0001571996-24-000090:mdna:202]
(d)    Includes interest expense on intercompany loan payables of $1,585 million.

[0001571996-24-000090:mdna:203]
[same as prior period, unchanged from 0001571996-24-000062:mdna:201]

[0001571996-24-000090:mdna:204]
[same as prior period, unchanged from 0001571996-24-000062:mdna:199]

[0001571996-24-000090:mdna:205]
|  | August 2, 2024 |  | February 2, 2024 |
|  | (in millions) |
| ASSETS |
| Current assets | $ | 2,880 |  |  | $ | 2,631 |  |
| Intercompany receivables | — |  |  | 281 |  |
| Short-term intercompany loan receivables | 188 |  |  | 92 |  |
| Total current assets | 3,068 |  |  | 3,004 |  |
| Goodwill and intangible assets | 14,260 |  |  | 14,447 |  |
| Other non-current assets | 3,273 |  |  | 3,437 |  |
| Total assets | $ | 20,601 |  |  | $ | 20,888 |  |
| LIABILITIES |
| Current liabilities | $ | 4,666 |  |  | $ | 5,255 |  |
| Intercompany payable | 1,199 |  |  | — |  |
| Total current liabilities | 5,865 |  |  | 5,255 |  |
| Long-term debt | 14,335 |  |  | 15,353 |  |
| Intercompany loan payables | 41,637 |  |  | 41,617 |  |
| Other non-current liabilities | 3,252 |  |  | 3,473 |  |
| Total liabilities | $ | 65,089 |  |  | $ | 65,698 |  |

[0001571996-24-000090:mdna:206]
77
