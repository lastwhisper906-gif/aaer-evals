# DELL notes — 0001571996-24-000090


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001571996-24-000090:notes:1]
Basis of Presentation — The accompanying unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes filed with the U.S. Securities and Exchange Commission (“SEC”) in the Company’s Annual Report on Form 10-K for the fiscal year ended February 2, 2024. These Condensed Consolidated Financial Statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“GAAP”). In the opinion of management, the accompanying Condensed Consolidated Financial Statements reflect all adjustments of a normal recurring nature considered necessary to fairly state the financial position of the Company as of August 2, 2024 and February 2, 2024 and the results of its operations, corresponding comprehensive income, changes in stockholders’ equity (deficit) for the three and six months ended August 2, 2024 and August 4, 2023, and its cash flows for the six months ended August 2, 2024 and August 4, 2023.

[0001571996-24-000090:notes:2]
The preparation of financial statements in accordance with GAAP requires management to make estimates and assumptions that affect the amounts reported in the Condensed Consolidated Financial Statements and the accompanying Notes. Actual results could differ materially from those estimates. The results of its operations, corresponding comprehensive income, and changes in stockholders’ equity (deficit) for the three and six months ended August 2, 2024 and August 4, 2023, and its cash flows for the six months ended August 2, 2024 and August 4, 2023 are not necessarily indicative of the results to be expected for the full fiscal year or for any other fiscal period.
The Company’s fiscal year is the 52- or 53-week period ending on the Friday nearest January 31. Both the fiscal year ended February 2, 2024 (“Fiscal 2024”) and the fiscal year ending January 31, 2025 (“Fiscal 2025”) are 52-week periods.


## us-gaap:ConsolidationPolicyTextBlock

[0001571996-24-000090:notes:3]
Principles of Consolidation — These Condensed Consolidated Financial Statements include the accounts of Dell Technologies Inc., its wholly-owned subsidiaries, and the accounts of SecureWorks Corp. (“Secureworks”), which is majority-owned by Dell Technologies. All intercompany transactions have been eliminated.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001571996-24-000090:notes:4]
Recently Issued Accounting Pronouncements

[0001571996-24-000090:notes:5]
Segment Reporting — In November 2023, the Financial Accounting Standards Board (“FASB”) issued guidance to improve disclosures about a public entity’s reportable segments by requiring disclosure of additional information about a reportable segment’s expenses on an annual and interim basis. Public entities must adopt the new guidance for fiscal years beginning after December 15, 2023, with early adoption permitted. Upon adoption, the guidance is required to be applied retrospectively to all prior periods presented in the financial statements. Adoption of this new guidance will result in increased disclosures in the Notes to the Consolidated Financial Statements.

[0001571996-24-000090:notes:6]
Income Taxes — In December 2023, the FASB issued guidance which requires companies to provide disaggregated income tax disclosures within the income tax rate reconciliation and income taxes paid. Public entities must adopt the new guidance for fiscal years beginning after December 15, 2024, with early adoption permitted. Upon adoption, the guidance can be applied prospectively or retrospectively. Adoption of this new guidance will result in increased disclosures in the Notes to the Consolidated Financial Statements.


## us-gaap:FairValueDisclosuresTextBlock

[0001571996-24-000090:notes:7]
[same as prior period, unchanged from 0001571996-24-000062:notes:7]

[0001571996-24-000090:notes:8]
|  | August 2, 2024 |  | February 2, 2024 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | Quoted Prices in Active Markets for Identical Assets |  | Significant Other Observable Inputs |  | Significant Unobservable Inputs |  |  |  | Quoted Prices in Active Markets for Identical Assets |  | Significant Other Observable Inputs |  | Significant Unobservable Inputs |  |  |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 1,432 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,432 |  |  | $ | 3,170 |  |  | $ | — |  |  | $ | — |  |  | $ | 3,170 |  |
| Marketable equity and other securities | 4 |  |  | — |  |  | — |  |  | 4 |  |  | 10 |  |  | — |  |  | — |  |  | 10 |  |
| Derivative instruments | — |  |  | 159 |  |  | — |  |  | 159 |  |  | — |  |  | 104 |  |  | — |  |  | 104 |  |
| Total assets | $ | 1,436 |  |  | $ | 159 |  |  | $ | — |  |  | $ | 1,595 |  |  | $ | 3,180 |  |  | $ | 104 |  |  | $ | — |  |  | $ | 3,284 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative instruments | $ | — |  |  | $ | 71 |  |  | $ | — |  |  | $ | 71 |  |  | $ | — |  |  | $ | 84 |  |  | $ | — |  |  | $ | 84 |  |
| Total liabilities | $ | — |  |  | $ | 71 |  |  | $ | — |  |  | $ | 71 |  |  | $ | — |  |  | $ | 84 |  |  | $ | — |  |  | $ | 84 |  |

[0001571996-24-000090:notes:9]
[same as prior period, unchanged from 0001571996-24-000062:notes:9]

[0001571996-24-000090:notes:10]
Money Market Funds — The Company’s investment in money market funds that are classified as cash equivalents hold underlying investments with a weighted average maturity of 90 days or less and are recognized at fair value. The valuations of these securities are based on quoted prices in active markets for identical assets, when available, or pricing models whereby all significant inputs are observable or can be derived from, or corroborated by, observable market data. The Company reviews security pricing and assesses money market fund liquidity on a quarterly basis. As of August 2, 2024, the Company’s portfolio had no material exposure to money market funds with a fluctuating net asset value.

[0001571996-24-000090:notes:11]
Marketable Equity and Other Securities — The Company’s investments in equity and other securities that are measured at fair value on a recurring basis consist of strategic investments in publicly-traded companies. The valuation of these securities is based on quoted prices in active markets.

[0001571996-24-000090:notes:12]
Derivative Instruments — The Company’s derivative financial instruments consist primarily of foreign currency forward and purchased option contracts and interest rate swaps. The fair value of the portfolio is determined using valuation models based on market observable inputs, including interest rate curves, forward and spot prices for currencies, and implied volatilities. Credit risk is also factored into the fair value calculation of the Company’s derivative financial instrument portfolio. See Note 7 of the Notes to the Condensed Consolidated Financial Statements for a description of the Company’s derivative financial instrument activities.

[0001571996-24-000090:notes:13]
Deferred Compensation Plans — The Company offers deferred compensation plans for eligible employees which allow participants to defer a portion of their compensation. Assets were the same as liabilities associated with the plans at approximately $232 million and $214 million as of August 2, 2024 and February 2, 2024, respectively, and are included in other assets and other liabilities on the Condensed Consolidated Statements of Financial Position. The net impact to the Condensed Consolidated Statements of Income is not material since changes in the fair value of the assets substantially offset changes in the fair value of the liabilities. As such, assets and liabilities associated with these plans have not been included in the recurring fair value table above.

[0001571996-24-000090:notes:14]
Assets and Liabilities Measured at Fair Value on a Nonrecurring Basis — Certain assets are measured at fair value on a nonrecurring basis and therefore are not included in the recurring fair value table above. These assets consist primarily of financial assets such as the Company’s fixed income debt securities and strategic investments in non-marketable equity and other securities and non-financial assets such as goodwill and intangible assets. See Note 3 and Note 8 of the Notes to the Condensed Consolidated Financial Statements for additional information about the Company’s investments and goodwill and intangible assets, respectively.

[0001571996-24-000090:notes:15]
[same as prior period, unchanged from 0001571996-24-000062:notes:16]

[0001571996-24-000090:notes:16]
|  | August 2, 2024 |  | February 2, 2024 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Notes | $ | 14.5 |  |  | $ | 14.9 |  |  | $ | 15.5 |  |  | $ | 15.8 |  |
| Legacy Notes | $ | 0.9 |  |  | $ | 1.0 |  |  | $ | 0.9 |  |  | $ | 1.0 |  |
| DFS Debt | $ | 9.1 |  |  | $ | 8.8 |  |  | $ | 9.5 |  |  | $ | 9.1 |  |

[0001571996-24-000090:notes:17]
[same as prior period, unchanged from 0001571996-24-000062:notes:18]


## us-gaap:InvestmentTextBlock

[0001571996-24-000090:notes:18]
INVESTMENTS
The Company has strategic investments in equity and other securities as well as investments in fixed income debt securities. All equity and other securities as well as long-term fixed income debt securities are recorded as long-term investments while short-term fixed income debt securities are recorded as other current assets in the Condensed Consolidated Statements of Financial Position.

[0001571996-24-000090:notes:19]
Total investments were $1.4 billion as of August 2, 2024 and $1.6 billion as of February 2, 2024.

[0001571996-24-000090:notes:20]
[same as prior period, unchanged from 0001571996-24-000062:notes:21]

[0001571996-24-000090:notes:21]
Equity and other securities include strategic investments in marketable and non-marketable securities. Investments in marketable securities are measured at fair value on a recurring basis. Investments in non-marketable equity and other securities represent early-stage companies without readily determinable fair values. The Company has elected to apply the measurement alternative for non-marketable securities. Under the alternative, the Company measures investments without readily determinable fair values at cost, less impairment, adjusted by observable price changes. The Company makes a separate election to use the alternative for each eligible investment and is required to reassess at each reporting period whether an investment qualifies for the alternative. In evaluating these investments for impairment or observable price changes, the Company uses inputs including pre- and post-money valuations of recent financing events and the impact of those events on its fully diluted ownership percentages, as well as other available information regarding the issuer’s historical and forecasted performance.

[0001571996-24-000090:notes:22]
[same as prior period, unchanged from 0001571996-24-000062:notes:23]

[0001571996-24-000090:notes:23]
[same as prior period, unchanged from 0001571996-24-000062:notes:24]

[0001571996-24-000090:notes:24]
|  | August 2, 2024 |  | February 2, 2024 |
|  | Cost |  | Unrealized Gain |  | Unrealized Loss |  | Carrying Value |  | Cost |  | Unrealized Gain |  | Unrealized Loss |  | Carrying Value |
|  | (in millions) |
| Marketable | $ | 12 |  |  | $ | 24 |  |  | $ | (32) |  |  | $ | 4 |  |  | $ | 12 |  |  | $ | 24 |  |  | $ | (26) |  |  | $ | 10 |  |
| Non-marketable | 704 |  |  | 855 |  |  | (263) |  |  | 1,296 |  |  | 732 |  |  | 1,015 |  |  | (454) |  |  | 1,293 |  |
| Total equity and other securities | $ | 716 |  |  | $ | 879 |  |  | $ | (295) |  |  | $ | 1,300 |  |  | $ | 744 |  |  | $ | 1,039 |  |  | $ | (480) |  |  | $ | 1,303 |  |

[0001571996-24-000090:notes:25]
[same as prior period, unchanged from 0001571996-24-000062:notes:26]

[0001571996-24-000090:notes:26]
[same as prior period, unchanged from 0001571996-24-000062:notes:27]

[0001571996-24-000090:notes:27]
|  | Three Months Ended |  | Six Months Ended |
|  | August 2, 2024 |  | August 4, 2023 |  | August 2, 2024 |  | August 4, 2023 |
|  | (in millions) |
| Marketable securities: |  |  |  |  |  |  |  |
| Unrealized gain | $ | — |  |  | $ | 1 |  |  | $ | — |  |  | $ | 1 |  |
| Unrealized loss | (1) |  |  | — |  |  | (6) |  |  | (23) |  |
| Net unrealized gain (loss) | (1) |  |  | 1 |  |  | (6) |  |  | (22) |  |
| Non-marketable securities: |  |  |  |  |  |  |  |
| Unrealized gain | — |  |  | — |  |  | — |  |  | 9 |  |
| Unrealized loss | — |  |  | (41) |  |  | (31) |  |  | (46) |  |
| Net unrealized loss (a) (b) | — |  |  | (41) |  |  | (31) |  |  | (37) |  |
| Net unrealized loss on equity and other securities | $ | (1) |  |  | $ | (40) |  |  | $ | (37) |  |  | $ | (59) |  |

[0001571996-24-000090:notes:28]
[same as prior period, unchanged from 0001571996-24-000062:notes:29]

[0001571996-24-000090:notes:29]
(a)    For the six months ended August 2, 2024, unrealized losses on non-marketable securities were attributable to downward adjustments for observable price changes.

[0001571996-24-000090:notes:30]
(b)    For the three and six months ended August 4, 2023, net unrealized losses on non-marketable securities were primarily attributable to impairments partially offset by upward adjustments for observable price changes.

[0001571996-24-000090:notes:31]
[same as prior period, unchanged from 0001571996-24-000062:notes:32]

[0001571996-24-000090:notes:32]
As of August 2, 2024 and February 2, 2024, the Company held fixed income debt securities of $125 million and $301 million, respectively, which it intends to hold to maturity. These investments are recorded at amortized cost and approximate fair value. As of August 2, 2024, the Company held $123 million in fixed income debt securities which will mature within one year and $2 million in fixed income debt securities which will mature within five years. The fair value of the fixed income debt securities was determined based on observable market prices in a less active market or based on valuation methodologies using observable inputs and was categorized as Level 2 in the fair value hierarchy.


## dell:CreditLossFinancialInstrumentLeasesDebtVariableInterestEntitiesAndCustomerReceivablesSalesTextBlock

[0001571996-24-000090:notes:33]
FINANCIAL SERVICES
The Company offers or arranges various financing options and alternative payment structures for its customers globally. Alternative payment structures consist of various flexible consumption models, including utility, subscription, and as-a-Service models.

[0001571996-24-000090:notes:34]
Financing options are offered to the Company’s customers primarily through Dell Financial Services and its affiliates (“DFS”). The Company also arranges financing for some of its customers in various countries where DFS does not currently operate as a captive enterprise. The key activities of DFS include originating, collecting, and servicing customer financing arrangements primarily related to the purchase or use of Dell Technologies products and services. In some cases, DFS also offers financing for the purchase of third-party technology products that complement the Dell Technologies portfolio of products and services. New financing originations were $2.4 billion for both the three months ended August 2, 2024 and August 4, 2023, and $4.3 billion and $4.2 billion for the six months ended August 2, 2024 and August 4, 2023, respectively.

[0001571996-24-000090:notes:35]
The Company’s lease and loan arrangements with customers are aggregated primarily into the following categories:

[0001571996-24-000090:notes:36]
Fixed-term leases and loans — The Company enters into financing arrangements with customers who seek lease financing for equipment. DFS leases are generally classified as sales-type leases or operating leases. Leases with business customers have fixed terms of generally two to four years.

[0001571996-24-000090:notes:37]
The Company also offers fixed-term loans to qualified small businesses, large commercial accounts, governmental organizations, educational entities, and certain individual consumer customers. These loans are repaid in equal payments including interest and have defined terms of generally three to five years. The fair value of the fixed-term loan portfolio is determined using market observable inputs. The carrying value of these loans approximates fair value.

[0001571996-24-000090:notes:38]
Revolving loans — Revolving loans provide qualified customers with a revolving credit line for the purchase of products and services offered by Dell Technologies. The Company primarily offers revolving loans to small and medium-sized commercial customers. Revolving loans in the United States bear interest at a variable annual percentage rate that is tied to the prime rate. Based on historical payment patterns, revolving loan transactions are typically repaid within twelve months on average. Due to the short-term nature of the revolving loan portfolio, the carrying value of the portfolio approximates fair value.

[0001571996-24-000090:notes:39]
Prior to the sale of the U.S. consumer revolving customer receivables portfolio on October 4, 2023, described in Note 1 of the Notes to the Condensed Consolidated Financial Statements, the Company offered private label credit financing under the Dell Preferred Account (“DPA”) program. The DPA product was primarily offered to individual consumer customers.

[0001571996-24-000090:notes:40]
Flexible consumption models, as defined above, further enable the Company to offer its customers the option to pay over time to provide them with financial and operational flexibility. Such models may result in identification of embedded lease arrangements that lead to the recognition of operating or sales-type leases.

[0001571996-24-000090:notes:41]
Financing Receivables

[0001571996-24-000090:notes:42]
The following table presents the components of the Company’s financing receivables segregated by portfolio segment as of the dates indicated:

[0001571996-24-000090:notes:43]
|  | August 2, 2024 |  | February 2, 2024 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Financing receivables, net: |  |  |  |  |  |  |  |  |  |  |  |
| Customer receivables, gross (a) | $ | 154 |  |  | $ | 10,938 |  |  | $ | 11,092 |  |  | $ | 173 |  |  | $ | 10,360 |  |  | $ | 10,533 |  |
| Allowances for losses | (8) |  |  | (158) |  |  | (166) |  |  | (9) |  |  | (161) |  |  | (170) |  |
| Customer receivables, net | 146 |  |  | 10,780 |  |  | 10,926 |  |  | 164 |  |  | 10,199 |  |  | 10,363 |  |
| Residual interest | — |  |  | 166 |  |  | 166 |  |  | — |  |  | 157 |  |  | 157 |  |
| Financing receivables, net | $ | 146 |  |  | $ | 10,946 |  |  | $ | 11,092 |  |  | $ | 164 |  |  | $ | 10,356 |  |  | $ | 10,520 |  |
| Short-term | $ | 146 |  |  | $ | 4,822 |  |  | $ | 4,968 |  |  | $ | 164 |  |  | $ | 4,479 |  |  | $ | 4,643 |  |
| Long-term | $ | — |  |  | $ | 6,124 |  |  | $ | 6,124 |  |  | $ | — |  |  | $ | 5,877 |  |  | $ | 5,877 |  |

[0001571996-24-000090:notes:44]
(a)    Customer receivables, gross include amounts due from customers under revolving loans, fixed-term loans, fixed-term leases, and accrued interest.

[0001571996-24-000090:notes:45]
The following tables present the changes in allowance for financing receivable losses for the periods indicated:

[0001571996-24-000090:notes:46]
|  | Three Months Ended |
|  | August 2, 2024 |  | August 4, 2023 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |  |  |  |  |  |  |  |
| Balances at beginning of period | $ | 8 |  |  | $ | 187 |  |  | $ | 195 |  |  | $ | 84 |  |  | $ | 135 |  |  | $ | 219 |  |
| Charge-offs, net of recoveries | (4) |  |  | (15) |  |  | (19) |  |  | (16) |  |  | (1) |  |  | (17) |  |
| Provision charged to income statement | 4 |  |  | (14) |  |  | (10) |  |  | 15 |  |  | 6 |  |  | 21 |  |
| Held for sale adjustment (a) | — |  |  | — |  |  | — |  |  | (74) |  |  | — |  |  | (74) |  |
| Balances at end of period | $ | 8 |  |  | $ | 158 |  |  | $ | 166 |  |  | $ | 9 |  |  | $ | 140 |  |  | $ | 149 |  |

[0001571996-24-000090:notes:47]
|  | Six Months Ended |
|  | August 2, 2024 |  | August 4, 2023 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |  |  |  |  |  |  |  |
| Balances at beginning of period | $ | 9 |  |  | $ | 161 |  |  | $ | 170 |  |  | $ | 88 |  |  | $ | 113 |  |  | $ | 201 |  |
| Charge-offs, net of recoveries | (6) |  |  | (21) |  |  | (27) |  |  | (33) |  |  | (2) |  |  | (35) |  |
| Provision charged to income statement | 5 |  |  | 18 |  |  | 23 |  |  | 28 |  |  | 29 |  |  | 57 |  |
| Held for sale adjustment (a) | — |  |  | — |  |  | — |  |  | (74) |  |  | — |  |  | (74) |  |
| Balances at end of period | $ | 8 |  |  | $ | 158 |  |  | $ | 166 |  |  | $ | 9 |  |  | $ | 140 |  |  | $ | 149 |  |

[0001571996-24-000090:notes:48]
(a)    The held for sale adjustment represents the reclassification of the U.S. consumer revolving customer receivables portfolio to current assets held for sale as of August 4, 2023. See Note 1 of the Notes to the Condensed Consolidated Financial Statements for more information about the sale of the U.S. consumer revolving customer receivables portfolio.

[0001571996-24-000090:notes:49]
The Company recognizes an allowance for financing receivable losses, including both the lease receivable and unguaranteed residual, in an amount equal to the expected losses net of recoveries. The allowance for financing receivable losses on the lease receivable is determined based on various factors, including lifetime expected losses determined using macroeconomic forecast assumptions and management judgments applicable to and through the expected life of the portfolios as well as past due receivables, receivable type, and customer risk profile. The Company continues to monitor broader economic indicators and their potential impact on future credit loss performance.

[0001571996-24-000090:notes:50]
Aging

[0001571996-24-000090:notes:51]
The following table presents the aging of the Company’s customer financing receivables, gross, including accrued interest, segregated by class, as of the dates indicated:

[0001571996-24-000090:notes:52]
|  | August 2, 2024 |  | February 2, 2024 |
|  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |
|  | (in millions) |
| Revolving | $ | 135 |  |  | $ | 15 |  |  | $ | 4 |  |  | $ | 154 |  |  | $ | 151 |  |  | $ | 17 |  |  | $ | 5 |  |  | $ | 173 |  |
| Fixed-term | 10,034 |  |  | 815 |  |  | 89 |  |  | 10,938 |  |  | 9,345 |  |  | 889 |  |  | 126 |  |  | 10,360 |  |
| Total customer receivables, gross | $ | 10,169 |  |  | $ | 830 |  |  | $ | 93 |  |  | $ | 11,092 |  |  | $ | 9,496 |  |  | $ | 906 |  |  | $ | 131 |  |  | $ | 10,533 |  |

[0001571996-24-000090:notes:53]
Aging is likely to fluctuate as a result of the variability in volume of large transactions entered into over the period, and the administrative processes that accompany those transactions. Aging is also impacted by the timing of the Company’s fiscal period end date relative to calendar month-end customer payment due dates. As a result of these factors, fluctuations in aging from period to period do not necessarily indicate a material change in the collectibility of the portfolio.

[0001571996-24-000090:notes:54]
Fixed-term customer receivables are placed on non-accrual status if principal or interest is past due and considered delinquent, or if there is concern about the collectibility of a specific customer receivable. The receivables identified as doubtful for collectibility may be classified as current for aging purposes. Aged revolving portfolio customer receivables identified as delinquent are charged off.

[0001571996-24-000090:notes:55]
Credit Quality

[0001571996-24-000090:notes:56]
The following tables present customer receivables, gross, including accrued interest, by credit quality indicator, segregated by class, as of the dates indicated:

[0001571996-24-000090:notes:57]
|  | August 2, 2024 |
|  | Fixed-term — Fiscal Year of Origination |  |  |  |  |
|  | 2025 |  | 2024 |  | 2023 |  | 2022 |  | 2021 |  | Years Prior |  | Revolving |  | Total |
|  | (in millions) |
| Higher | $ | 1,377 |  |  | $ | 2,626 |  |  | $ | 1,519 |  |  | $ | 563 |  |  | $ | 211 |  |  | $ | 14 |  |  | $ | 36 |  |  | $ | 6,346 |  |
| Mid | 476 |  |  | 940 |  |  | 695 |  |  | 152 |  |  | 35 |  |  | 8 |  |  | 46 |  |  | 2,352 |  |
| Lower | 1,262 |  |  | 530 |  |  | 353 |  |  | 118 |  |  | 48 |  |  | 11 |  |  | 72 |  |  | 2,394 |  |
| Total | $ | 3,115 |  |  | $ | 4,096 |  |  | $ | 2,567 |  |  | $ | 833 |  |  | $ | 294 |  |  | $ | 33 |  |  | $ | 154 |  |  | $ | 11,092 |  |

[0001571996-24-000090:notes:58]
|  | February 2, 2024 |
|  | Fixed-term — Fiscal Year of Origination |  |  |  |  |  |  |
|  | 2024 |  | 2023 |  | 2022 |  | 2021 |  | 2020 |  | Years Prior |  |  |  | Revolving |  | Total |
|  | (in millions) |
| Higher | $ | 3,261 |  |  | $ | 1,979 |  |  | $ | 833 |  |  | $ | 345 |  |  | $ | 64 |  |  | $ | — |  |  |  |  | $ | 47 |  |  | $ | 6,529 |  |
| Mid | 1,111 |  |  | 911 |  |  | 290 |  |  | 86 |  |  | 19 |  |  | — |  |  |  |  | 50 |  |  | 2,467 |  |
| Lower | 703 |  |  | 469 |  |  | 187 |  |  | 80 |  |  | 21 |  |  | 1 |  |  |  |  | 76 |  |  | 1,537 |  |
| Total | $ | 5,075 |  |  | $ | 3,359 |  |  | $ | 1,310 |  |  | $ | 511 |  |  | $ | 104 |  |  | $ | 1 |  |  |  |  | $ | 173 |  |  | $ | 10,533 |  |

[0001571996-24-000090:notes:59]
The categories shown in the tables above segregate customer receivables based on the relative degrees of credit risk. Credit quality indicators for revolving and fixed-term accounts are generally updated on a periodic basis.

[0001571996-24-000090:notes:60]
For the revolving receivables and fixed-term receivables shown in the tables above, an internal grading system is utilized that assigns a credit level score based on a number of considerations, including liquidity, operating performance, and industry outlook. The grading criteria and classifications for the fixed-term products differ from those for the revolving products as loss experience varies between these product and customer groups. The credit quality categories cannot be compared between the different classes as loss experience varies substantially between the classes.

[0001571996-24-000090:notes:61]
Leases

[0001571996-24-000090:notes:62]
The following table presents amounts included in the Condensed Consolidated Statements of Income related to sales-type lease activity for the periods indicated:

[0001571996-24-000090:notes:63]
|  | Three Months Ended |  | Six Months Ended |
|  | August 2, 2024 |  | August 4, 2023 |  | August 2, 2024 |  | August 4, 2023 |  |  |
|  | (in millions) |
| Net revenue — products | $ | 622 |  |  | $ | 292 |  |  | $ | 1,350 |  |  | $ | 539 |  |  |  |
| Cost of net revenue — products | 537 |  |  | 192 |  |  | 1,155 |  |  | 388 |  |  |  |
| Gross margin — products | $ | 85 |  |  | $ | 100 |  |  | $ | 195 |  |  | $ | 151 |  |  |  |

[0001571996-24-000090:notes:64]
The following table presents the future maturity of the Company’s fixed-term customer leases and associated financing payments, and reconciles the undiscounted cash flows to the customer receivables, gross recognized on the Condensed Consolidated Statements of Financial Position as of the date indicated:

[0001571996-24-000090:notes:65]
|  | August 2, 2024 |
|  | (in millions) |
| Fiscal 2025 (remaining six months) | $ | 1,569 |  |
| Fiscal 2026 | 2,841 |  |
| Fiscal 2027 | 1,853 |  |
| Fiscal 2028 | 654 |  |
| Fiscal 2029 and beyond | 347 |  |
| Total undiscounted cash flows | 7,264 |  |
| Fixed-term loans | 4,810 |  |
| Revolving loans | 154 |  |
| Less: Unearned income | (1,136) |  |
| Total customer receivables, gross | $ | 11,092 |  |

[0001571996-24-000090:notes:66]
Operating Leases

[0001571996-24-000090:notes:67]
The Company’s operating leases primarily consist of DFS captive fixed-term leases and contractually committed embedded leases identified within flexible consumption arrangements.

[0001571996-24-000090:notes:68]
The following table presents the components of the Company’s operating lease portfolio included in property, plant, and equipment, net as of the dates indicated:

[0001571996-24-000090:notes:69]
|  | August 2, 2024 |  | February 2, 2024 |
|  | (in millions) |
| Equipment under operating lease, gross | $ | 4,064 |  |  | $ | 4,002 |  |
| Less: Accumulated depreciation | (1,871) |  |  | (1,800) |  |
| Equipment under operating lease, net | $ | 2,193 |  |  | $ | 2,202 |  |

[0001571996-24-000090:notes:70]
The following table presents operating lease income related to lease payments and depreciation expense for the Company’s operating lease portfolio for the periods indicated:

[0001571996-24-000090:notes:71]
|  | Three Months Ended |  | Six Months Ended |
|  | August 2, 2024 |  | August 4, 2023 |  | August 2, 2024 |  | August 4, 2023 |  |  |
|  | (in millions) |
| Income related to lease payments | $ | 362 |  |  | $ | 330 |  |  | $ | 718 |  |  | $ | 651 |  |  |  |
| Depreciation expense | $ | 245 |  |  | $ | 236 |  |  | $ | 485 |  |  | $ | 469 |  |  |  |

[0001571996-24-000090:notes:72]
The following table presents the future payments to be received by the Company in operating lease contracts as of the date indicated:

[0001571996-24-000090:notes:73]
|  | August 2, 2024 |
|  | (in millions) |
| Fiscal 2025 (remaining six months) | $ | 582 |  |
| Fiscal 2026 | 897 |  |
| Fiscal 2027 | 517 |  |
| Fiscal 2028 | 208 |  |
| Fiscal 2029 and beyond | 77 |  |
| Total | $ | 2,281 |  |

[0001571996-24-000090:notes:74]
DFS Debt

[0001571996-24-000090:notes:75]
The Company maintains programs that facilitate the funding of leases, loans, and other alternative payment structures in the capital markets. The majority of DFS debt is non-recourse to Dell Technologies and represents borrowings under securitization programs and structured financing programs for which the Company’s risk of loss is limited to transferred loan and lease payments and associated equipment.

[0001571996-24-000090:notes:76]
The following table presents DFS debt as of the dates indicated and excludes the allocated portion of the Company’s other borrowings, which represents the additional amount considered to fund the DFS business:

[0001571996-24-000090:notes:77]
|  | August 2, 2024 |  | February 2, 2024 |
| DFS debt | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing facility | $ | 3,067 |  |  | $ | 2,730 |  |
| Fixed-term securitization offerings | 2,841 |  |  | 3,157 |  |
| Other | 25 |  |  | 28 |  |
| Total DFS U.S. debt, principal amount | 5,933 |  |  | 5,915 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 704 |  |  | 761 |  |
| Other borrowings | 877 |  |  | 935 |  |
| Note payable | — |  |  | 250 |  |
| Dell Bank senior unsecured eurobonds | 1,619 |  |  | 1,631 |  |
| Total DFS international debt, principal amount | 3,200 |  |  | 3,577 |  |
| Total DFS debt, principal amount | $ | 9,133 |  |  | $ | 9,492 |  |
| Total short-term DFS debt | $ | 5,682 |  |  | $ | 5,863 |  |
| Total long-term DFS debt | $ | 3,451 |  |  | $ | 3,629 |  |

[0001571996-24-000090:notes:78]
DFS U.S. Debt

[0001571996-24-000090:notes:79]
Asset-Based Financing Facility — The Company maintains an asset-based financing facility in the United States, which is a revolving facility for fixed-term leases and loans. This debt is collateralized solely by the U.S. loan and lease payments and associated equipment in the facility. The asset-based financing facility consists of two tranches, with effective dates through July 7, 2025 and July 7, 2026. As of August 2, 2024, the total debt capacity related to the asset-based financing facility was $5.0 billion. The debt has a variable interest rate, and the duration of the debt is based on the terms of the underlying loan and lease payment streams. The Company enters into interest swap agreements to effectively convert a portion of this debt from a floating rate to a fixed rate. See Note 7 of the Notes to the Condensed Consolidated Financial Statements for additional information about the Company’s interest rate swaps.

[0001571996-24-000090:notes:80]
The asset-based financing facility contains standard structural features related to the performance of the funded receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements. In the event one or more of these criteria are not met and the Company is unable to restructure the facility, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed. As of August 2, 2024, these criteria were met.

[0001571996-24-000090:notes:81]
Fixed-Term Securitization Offerings — The Company periodically issues asset-backed debt securities under fixed-term securitization programs to private investors. The asset-backed debt securities are collateralized solely by the U.S. fixed-term lease and loan payments and associated equipment, which are held by Special Purpose Entities (“SPEs”), as discussed below. The interest rate on these securities is fixed and ranges from 2.49% to 6.80% per annum as of August 2, 2024, and the duration of these securities is based on the terms of the underlying lease and loan payment streams.

[0001571996-24-000090:notes:82]
DFS International Debt

[0001571996-24-000090:notes:83]
Securitization Facility — The Company maintains a securitization facility in Europe for fixed-term leases and loans. The debt under this facility has a variable interest rate, and the duration of the debt is based on the terms of the underlying loan and lease payment streams. This facility is effective through December 23, 2024 and had a total debt capacity of $863 million as of August 2, 2024.

[0001571996-24-000090:notes:84]
The securitization facility contains standard structural features related to the performance of the securitized receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements. In the event one or more of these criteria are not met and the Company is unable to restructure the program, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed. As of August 2, 2024, these criteria were met.

[0001571996-24-000090:notes:85]
Other Borrowings — In connection with the Company’s international financing operations, the Company has entered into revolving structured financing debt programs related to its fixed-term lease and loan products sold in Canada, Europe, Australia, New Zealand, the Middle East, and Singapore. The debt under these programs has a variable interest rate.

[0001571996-24-000090:notes:86]
The duration of the debt in Canada, Europe, Australia, New Zealand, and the Middle East is based on the terms of the underlying loan and lease payment streams. These facilities are collateralized solely by the loan and lease payments and associated equipment in their respective region or country. The Canadian facility had a total debt capacity of $324 million as of August 2, 2024 and is effective through January 16, 2025. The European facility had a total debt capacity of $540 million as of August 2, 2024 and is effective through December 14, 2026. The Australia and New Zealand facility had a total debt capacity of $293 million as of August 2, 2024 and is effective through April 20, 2025. The Middle East facility had a total debt capacity of $150 million as of August 2, 2024 and is effective through March 24, 2025.

[0001571996-24-000090:notes:87]
On July 3, 2024, the Company entered into two unsecured revolving credit agreements to fund receivables in Singapore. The Singapore facilities have a total debt capacity of $247 million as of August 2, 2024 and are effective through July 3, 2026 and July 3, 2027, respectively.

[0001571996-24-000090:notes:88]
Note Payable — On May 25, 2022, the Company entered into an unsecured credit agreement which had an aggregate principal amount of $250 million to fund receivables in Mexico. The note bore interest at an annual rate of 4.24% and was paid in full on May 31, 2024.

[0001571996-24-000090:notes:89]
Dell Bank Senior Unsecured Eurobonds — On October 27, 2021, Dell Bank issued 500 million Euro of 0.5% senior unsecured five year eurobonds due October 2026. On October 18, 2022, Dell Bank issued 500 million Euro of 4.5% senior unsecured five year eurobonds due October 2027. On June 13, 2024, Dell Bank issued 500 million Euro of 3.6% senior unsecured five year eurobonds due June 2029. The issuances of the senior unsecured eurobonds support the expansion of the financing operations in Europe.

[0001571996-24-000090:notes:90]
Variable Interest Entities

[0001571996-24-000090:notes:91]
In connection with the asset-based financing facility, securitization facility, and fixed-term securitization offerings discussed above, the Company transfers certain U.S. and European lease and loan payments and associated equipment to SPEs that meet the definition of a VIE and are consolidated, along with the associated debt described above, into the Condensed Consolidated Financial Statements, as the Company is the primary beneficiary of the VIEs. The SPEs are bankruptcy-remote legal entities with separate assets and liabilities. The purpose of the SPEs is to facilitate the funding of customer loan and lease payments and associated equipment in the capital markets.

[0001571996-24-000090:notes:92]
Some of the SPEs have entered into financing arrangements with multi-seller conduits that, in turn, issue asset-backed debt securities in the capital markets. DFS debt outstanding held by the consolidated VIEs is collateralized by the lease and loan payments and associated equipment. The Company’s risk of loss related to securitized receivables is limited to the amount by which the Company’s right to receive collections for assets securitized exceeds the amount required to pay interest, principal, and fees and expenses related to the asset-backed securities. The Company provides credit enhancement to the securitization in the form of over-collateralization.

[0001571996-24-000090:notes:93]
The following table presents the assets and liabilities held by the consolidated VIEs as of the dates indicated, which are included in the Condensed Consolidated Statements of Financial Position:

[0001571996-24-000090:notes:94]
|  | August 2, 2024 |  | February 2, 2024 |
|  | (in millions) |
| Assets held by consolidated VIEs |  |  |  |
| Other current assets | $ | 115 |  |  | $ | 136 |  |
| Financing receivables, net of allowance |  |  |  |
| Short-term | $ | 3,284 |  |  | $ | 3,314 |  |
| Long-term | $ | 2,935 |  |  | $ | 2,747 |  |
| Property, plant, and equipment, net | $ | 1,022 |  |  | $ | 1,081 |  |
| Liabilities held by consolidated VIEs |  |  |  |
| Debt, net of unamortized debt issuance costs |  |  |  |
| Short-term | $ | 4,942 |  |  | $ | 4,450 |  |
| Long-term | $ | 1,670 |  |  | $ | 2,184 |  |

[0001571996-24-000090:notes:95]
Lease and loan payments and associated equipment transferred via securitization through SPEs were $1.2 billion and $1.1 billion for the three months ended August 2, 2024 and August 4, 2023, respectively, and $2.0 billion and $2.6 billion for the six months ended August 2, 2024 and August 4, 2023, respectively.

[0001571996-24-000090:notes:96]
Customer Receivables Sales

[0001571996-24-000090:notes:97]
To manage certain concentrations of customer credit exposure, the Company may sell selected fixed-term customer receivables to unrelated third parties on a periodic basis, without recourse. The amount of customer receivables sold for this purpose was $69 million and $187 million for the six months ended August 2, 2024 and August 4, 2023, respectively. The Company’s continuing involvement in these customer receivables is primarily limited to servicing arrangements.


## us-gaap:ScheduleOfDebtTableTextBlock

[0001571996-24-000090:notes:98]
The following table summarizes the Company’s outstanding debt as of the dates indicated:

[0001571996-24-000090:notes:99]
|  | August 2, 2024 |  | February 2, 2024 |
|  | (in millions) |
| Senior Notes | $ | 14,580 |  |  | $ | 15,607 |  |
| Legacy Notes | 952 |  |  | 952 |  |
| DFS Debt (Note 4) | 9,133 |  |  | 9,492 |  |
| Other | 79 |  |  | 171 |  |
| Total debt, principal amount | 24,744 |  |  | 26,222 |  |
| Unamortized discount, net of unamortized premium | (112) |  |  | (114) |  |
| Debt issuance costs | (110) |  |  | (114) |  |
| Total debt, carrying value | $ | 24,522 |  |  | $ | 25,994 |  |
| Total short-term debt, carrying value | $ | 6,711 |  |  | $ | 6,982 |  |
| Total long-term debt, carrying value | $ | 17,811 |  |  | $ | 19,012 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0001571996-24-000090:notes:100]
LEASES 
The Company enters into leasing transactions in which the Company is the lessee. These lease contracts are typically classified as operating leases. The Company’s lease contracts are generally for office buildings used to conduct its business, and the determination of whether such contracts contain leases generally does not require significant estimates or judgments. The Company also leases certain global logistics warehouses, employee vehicles, and equipment. As of August 2, 2024, the remaining terms of the Company’s leases range from one month to approximately twelve years. As of August 2, 2024 and February 2, 2024, there were no material finance leases in which the Company was a lessee.

[0001571996-24-000090:notes:101]
The Company also enters into leasing transactions in which the Company is the lessor, primarily through customer financing arrangements offered through DFS. DFS originates leases that are primarily classified as either sales-type leases or operating leases. See Note 4 of the Notes to the Condensed Consolidated Financial Statements for more information about the Company’s lessor arrangements.

[0001571996-24-000090:notes:102]
[same as prior period, unchanged from 0001571996-24-000062:notes:100]

[0001571996-24-000090:notes:103]
|  | Three Months Ended |  | Six Months Ended |
|  | August 2, 2024 |  | August 4, 2023 |  | August 2, 2024 |  | August 4, 2023 |
|  | (in millions) |
| Operating lease costs | $ | 75 |  |  | $ | 63 |  |  | $ | 146 |  |  | $ | 142 |  |
| Variable costs | 15 |  |  | 19 |  |  | 33 |  |  | 43 |  |
| Total lease costs | $ | 90 |  |  | $ | 82 |  |  | $ | 179 |  |  | $ | 185 |  |

[0001571996-24-000090:notes:104]
During the six months ended August 2, 2024 and August 4, 2023, sublease income, finance lease costs, and short-term lease costs were immaterial.

[0001571996-24-000090:notes:105]
[same as prior period, unchanged from 0001571996-24-000062:notes:103]

[0001571996-24-000090:notes:106]
|  | Classification |  | August 2, 2024 |  | February 2, 2024 |  |  |
|  |  |  | (in millions, except for term and discount rate) |
| Operating lease right-of-use assets | Other non-current assets |  | $ | 716 |  | $ | 707 |  |  |
| Current operating lease liabilities | Accrued and other current liabilities |  | $ | 246 |  | $ | 253 |  |  |
| Non-current operating lease liabilities | Other non-current liabilities |  | 581 |  | 576 |  |  |
| Total operating lease liabilities |  |  | $ | 827 |  | $ | 829 |  |  |
| Weighted-average remaining lease term (in years) |  |  | 4.47 |  | 4.56 |  |  |
| Weighted-average discount rate |  |  | 4.86 | % |  | 4.79 | % |  |  |

[0001571996-24-000090:notes:107]
[same as prior period, unchanged from 0001571996-24-000062:notes:105]

[0001571996-24-000090:notes:108]
|  | Six Months Ended |
|  | August 2, 2024 |  | August 4, 2023 |
|  | (in millions) |
| Cash paid for amounts included in the measurement of lease liabilities — operating cash outflows from operating leases | $ | 137 |  |  | $ | 153 |  |
| Right-of-use assets obtained in exchange for new operating lease liabilities | $ | 128 |  |  | $ | 131 |  |

[0001571996-24-000090:notes:109]
[same as prior period, unchanged from 0001571996-24-000062:notes:107]

[0001571996-24-000090:notes:110]
|  | August 2, 2024 |
|  | (in millions) |
| Fiscal 2025 (remaining six months) | $ | 126 |  |
| Fiscal 2026 | 233 |  |
| Fiscal 2027 | 195 |  |
| Fiscal 2028 | 145 |  |
| Fiscal 2029 | 98 |  |
| Thereafter | 119 |  |
| Total lease payments | 916 |  |
| Less: Imputed interest | 89 |  |
| Total | $ | 827 |  |
| Current operating lease liabilities | $ | 246 |  |
| Non-current operating lease liabilities | $ | 581 |  |

[0001571996-24-000090:notes:111]
As of August 2, 2024, the Company’s undiscounted operating leases that had not yet commenced were immaterial.


## us-gaap:DebtDisclosureTextBlock

[0001571996-24-000090:notes:112]
DEBT
The following table summarizes the Company’s outstanding debt as of the dates indicated:

[0001571996-24-000090:notes:113]
The Company completed the following transactions during the six months ended August 2, 2024:

[0001571996-24-000090:notes:114]
•the issuance of $1 billion principal amount of 5.40% Senior Notes due April 2034, the proceeds of which were utilized to prepay a portion of the outstanding 6.02% Senior Notes due June 2026; and

[0001571996-24-000090:notes:115]
•the repayment of $1 billion principal amount of the 4.00% Senior Notes due July 2024.

[0001571996-24-000090:notes:116]
Outstanding Debt

[0001571996-24-000090:notes:117]
Senior Notes — The Company completed offerings of multiple series of senior notes which were issued on June 1, 2016, June 22, 2016, March 20, 2019, April 9, 2020, December 13, 2021, January 24, 2023 and March 18, 2024 in aggregate principal amounts of $20.0 billion, $3.3 billion, $4.5 billion, $2.3 billion, $2.3 billion, $2.0 billion and $1.0 billion, respectively (collectively, the “Senior Notes”). The Senior Notes maturities range from 2025 through 2051. Interest rates on these borrowings are fixed, ranging from 3.38% to 8.35%, and interest is payable semiannually.

[0001571996-24-000090:notes:118]
Legacy Notes — The Company has outstanding unsecured notes and debentures (collectively, the “Legacy Notes”) that were issued by Dell Inc. (“Dell”), a wholly-owned subsidiary of Dell Technologies Inc., prior to the acquisition of Dell by Dell Technologies Inc. in the going-private transaction that closed in October 2013. The Legacy Notes’ maturities range from 2028 through 2040. Interest rates on these borrowings are fixed, ranging from 5.40% to 7.10%, and interest is payable semiannually.

[0001571996-24-000090:notes:119]
DFS Debt — See Note 4 and Note 7 of the Notes to the Condensed Consolidated Financial Statements, respectively, for discussion of DFS debt and the interest rate swap agreements that hedge a portion of that debt.

[0001571996-24-000090:notes:120]
Revolving Credit Facility — The Company’s revolving credit facility provides the Company with revolving commitments in an aggregate principal amount of $6.0 billion for general corporate purposes and includes a letter of credit sub-facility of up to $0.5 billion and a swing-line loan sub-facility of up to $0.5 billion. The revolving credit facility also allows the Company to obtain incremental additional commitments on one or more occasions in minimum amounts of $10 million.

[0001571996-24-000090:notes:121]
Borrowings under the revolving credit facility bear interest at a rate per annum equal to an applicable margin plus, at the borrowers’ option, either (a) the specified adjusted term Secured Overnight Financing Rate (“SOFR”) or (b) a base rate. The margin applicable to SOFR and base rate borrowings varies based upon the Company’s existing credit ratings. The base rate is calculated based upon the greatest of the specified prime rate, the specified federal reserve bank rate, or SOFR plus 1%. The borrowers may voluntarily repay outstanding loans at any time without premium or penalty, other than customary breakage costs. The facility matures on November 1, 2027.

[0001571996-24-000090:notes:122]
As of August 2, 2024, the Company had no outstanding borrowings under the revolving credit facility.

[0001571996-24-000090:notes:123]
Commercial Paper Program — The Company maintains a commercial paper program under which the Company may issue unsecured notes in a maximum aggregate face amount of $5.0 billion outstanding at any time, with maturities up to 397 days from the date of issuance. The notes are sold on customary terms in the U.S. commercial paper market on a private placement basis. The proceeds of the notes are used for general corporate purposes. As of August 2, 2024, the Company had no outstanding issuances under the commercial paper program.

[0001571996-24-000090:notes:124]
The Company may purchase, redeem, prepay, refinance, or otherwise retire any amount of outstanding indebtedness under the terms of such indebtedness at any time and from time to time, in open market or negotiated transactions with the holders of such indebtedness or otherwise, as considered appropriate in light of market conditions and other relevant factors.

[0001571996-24-000090:notes:125]
Covenants — The credit agreement governing the revolving credit facility and the indentures governing the Senior Notes and the Legacy Notes impose various limitations, subject to exceptions, on creating certain liens and entering into sale and lease-back transactions. The foregoing credit agreement and indentures contain customary events of default, and the revolving credit facility is subject to an interest coverage ratio covenant that is tested at the end of each fiscal quarter with respect to the Company’s preceding four fiscal quarters. The Company was in compliance with this financial covenant as of August 2, 2024.

[0001571996-24-000090:notes:126]
Aggregate Future Maturities

[0001571996-24-000090:notes:127]
The following table presents the aggregate future maturities of the Company’s debt as of August 2, 2024, excluding associated carrying value adjustments, for the periods indicated:

[0001571996-24-000090:notes:128]
|  | August 2, 2024 |
|  | (in millions) |
| Fiscal 2025 (remaining six months) | $ | 2,796 |  |
| Fiscal 2026 | 4,567 |  |
| Fiscal 2027 | 5,838 |  |
| Fiscal 2028 | 1,195 |  |
| Fiscal 2029 | 1,326 |  |
| Thereafter | 9,022 |  |
| Total maturities, principal amount | $ | 24,744 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001571996-24-000090:notes:129]
[same as prior period, unchanged from 0001571996-24-000062:notes:125]

[0001571996-24-000090:notes:130]
The Company’s objective is to offset gains and losses resulting from these exposures with gains and losses on the derivative contracts used to hedge the exposures, thereby reducing volatility of earnings and protecting the fair values of assets and liabilities. The earnings effects of the derivative instruments are presented in the same line items on the Condensed Consolidated Statements of Income as the earnings effects of the hedged items. For derivatives designated as cash flow hedges, the Company assesses hedge effectiveness both at the onset of the hedge and at regular intervals throughout the life of the instruments. For derivatives designated as fair value hedges, the Company assesses hedge effectiveness on qualifying instruments using the shortcut method whereby the hedges are considered perfectly effective at the onset of the hedge and over the life of the hedging relationship.

[0001571996-24-000090:notes:131]
[same as prior period, unchanged from 0001571996-24-000062:notes:127]

[0001571996-24-000090:notes:132]
The Company uses foreign currency forward and option contracts designated as cash flow hedges to protect against the foreign currency exchange rate risks inherent in its forecasted transactions denominated in currencies other than the U.S. Dollar. Hedge accounting is applied based upon the criteria established by accounting guidance for derivative instruments and hedging activities. The risk of loss associated with purchased options is limited to premium amounts paid for the option contracts. The risk of loss associated with forward contracts is equal to the exchange rate differential from the time the contract is entered into until the time it is settled. The majority of these contracts typically expire in twelve months or less.

[0001571996-24-000090:notes:133]
During the three and six months ended August 2, 2024 and August 4, 2023, the Company did not discontinue any cash flow hedges related to foreign exchange contracts that had a material impact on the Company’s results of operations due to the probability that the forecasted cash flows would not occur.

[0001571996-24-000090:notes:134]
The Company uses forward contracts to hedge monetary assets and liabilities denominated in a foreign currency. These contracts generally expire in three months or less, are considered economic hedges, and are not designated for hedge accounting. The change in the fair value of these instruments represents a natural hedge as their gains and losses offset the changes in the underlying fair value of the monetary assets and liabilities due to movements in currency exchange rates.

[0001571996-24-000090:notes:135]
In connection with DFS operations in Europe, forward contracts are used to hedge financing receivables denominated in foreign currencies other than Euro. These contracts are not designated for hedge accounting and most expire within three years or less.

[0001571996-24-000090:notes:136]
[same as prior period, unchanged from 0001571996-24-000062:notes:132]

[0001571996-24-000090:notes:137]
The Company uses interest rate swaps to hedge the variability in cash flows related to the interest rate payments on structured financing debt. The interest rate swaps economically convert the variable rate on the structured financing debt to a fixed interest rate to match the underlying fixed rate being received on fixed-term customer leases and loans. These contracts are not designated for hedge accounting and most expire within four years or less.

[0001571996-24-000090:notes:138]
Interest rate swaps are utilized to manage the interest rate risk, at a portfolio level, associated with DFS operations in Europe. The interest rate swaps economically convert the fixed rate on financing receivables to a three-month Euribor floating rate in order to match the floating rate nature of the banks’ funding pool. The Company also uses interest rate swaps to manage the cash flows related to interest payments on senior unsecured eurobonds. The interest rate swaps economically convert the fixed rate on the Company’s bonds to a floating rate to match the underlying lease repayments profile. These contracts are not designated for hedge accounting and most expire within five years or less. See Note 4 of the Notes to the Condensed Consolidated Financial Statements for more information about the Dell Bank senior unsecured eurobonds.

[0001571996-24-000090:notes:139]
The Company utilizes cross-currency amortizing swaps to hedge the currency and interest rate risk exposure associated with the European securitization program. The cross-currency swaps combine a Euro-based interest rate swap with a British Pound or U.S. Dollar foreign exchange forward contract in which the Company pays a fixed or floating British Pound or U.S. Dollar amount and receives a fixed or floating amount in Euros linked to the one-month Euribor rate. The notional value of the swaps amortizes in line with the expected cash flows and run-off of the securitized assets. The swaps are not designated for hedge accounting and expire within five years or less.

[0001571996-24-000090:notes:140]
[same as prior period, unchanged from 0001571996-24-000062:notes:136]

[0001571996-24-000090:notes:141]
[same as prior period, unchanged from 0001571996-24-000062:notes:137]

[0001571996-24-000090:notes:142]
|  | August 2, 2024 |  | February 2, 2024 |
|  | (in millions) |
| Foreign exchange contracts: |  |  |  |
| Designated as cash flow hedging instruments | $ | 7,345 |  |  | $ | 6,339 |  |
| Non-designated as hedging instruments | 5,982 |  |  | 5,844 |  |
| Total | $ | 13,327 |  |  | $ | 12,183 |  |
| Interest rate contracts: |  |  |  |
| Non-designated as hedging instruments | $ | 6,564 |  |  | $ | 6,551 |  |

[0001571996-24-000090:notes:143]
[same as prior period, unchanged from 0001571996-24-000062:notes:139]

[0001571996-24-000090:notes:144]
| Derivatives in Cash Flow Hedging Relationships |  | Gain (Loss) Recognized in Accumulated OCI, Net of Tax, on Derivatives |  | Location of Gain (Loss) Reclassified from Accumulated OCI into Income |  | Gain (Loss) Reclassified from Accumulated OCI into Income |
|  |  | (in millions) |  |  |  | (in millions) |
| For the three months ended August 2, 2024: |
|  |  |  |  | Total net revenue |  | $ | 14 |  |
| Foreign exchange contracts |  | $ | (20) |  |  | Total cost of net revenue |  | 4 |  |
| Total |  | $ | (20) |  |  | Total |  | $ | 18 |  |
| For the three months ended August 4, 2023: |
|  |  |  |  | Total net revenue |  | $ | (63) |  |
| Foreign exchange contracts |  | $ | 49 |  |  | Total cost of net revenue |  | (5) |  |
| Total |  | $ | 49 |  |  | Total |  | $ | (68) |  |
| For the six months ended August 2, 2024: |
|  |  |  |  | Total net revenue |  | $ | 32 |  |
| Foreign exchange contracts |  | $ | 67 |  |  | Total cost of net revenue |  | 5 |  |
| Total |  | $ | 67 |  |  | Total |  | $ | 37 |  |
| For the six months ended August 4, 2023: |
|  |  |  |  | Total net revenue |  | $ | (151) |  |
| Foreign exchange contracts |  | $ | 59 |  |  | Total cost of net revenue |  | (8) |  |
| Total |  | $ | 59 |  |  | Total |  | $ | (159) |  |

[0001571996-24-000090:notes:145]
[same as prior period, unchanged from 0001571996-24-000062:notes:141]

[0001571996-24-000090:notes:146]
|  | Three Months Ended |  | Six Months Ended |  |  |  |  |
|  | August 2, 2024 |  | August 4, 2023 |  | August 2, 2024 |  | August 4, 2023 |  |  |  | Location of Gain (Loss) Recognized |
|  | (in millions) |  |  |
| Foreign exchange contracts | $ | (26) |  |  | $ | (40) |  |  | $ | (45) |  |  | $ | 17 |  |  |  |  | Interest and other, net |
| Interest rate contracts | 28 |  |  | 24 |  |  | (11) |  |  | 3 |  |  |  |  | Interest and other, net |
| Total | $ | 2 |  |  | $ | (16) |  |  | $ | (56) |  |  | $ | 20 |  |  |  |  |  |

[0001571996-24-000090:notes:147]
The Company presents its derivative instruments on a net basis in the Condensed Consolidated Statements of Financial Position due to the right of offset by its counterparties under master netting arrangements. The following tables present the fair value of those derivative instruments presented on a gross basis as of the dates indicated:

[0001571996-24-000090:notes:148]
|  | August 2, 2024 |
|  | Other Current Assets |  | Other Non-Current Assets |  | Other Current Liabilities |  | Other Non-Current Liabilities |  | Total Fair Value |
|  | (in millions) |
| Derivatives designated as hedging instruments: |
| Foreign exchange contracts in an asset position | $ | 78 |  |  | $ | — |  |  | $ | 15 |  |  | $ | — |  |  | $ | 93 |  |
| Foreign exchange contracts in a liability position | (14) |  |  | — |  |  | (14) |  |  | — |  |  | (28) |  |
| Net asset (liability) | 64 |  |  | — |  |  | 1 |  |  | — |  |  | 65 |  |
| Derivatives not designated as hedging instruments: |
| Foreign exchange contracts in an asset position | 156 |  |  | — |  |  | 42 |  |  | — |  |  | 198 |  |
| Foreign exchange contracts in a liability position | (91) |  |  | — |  |  | (60) |  |  | — |  |  | (151) |  |
| Interest rate contracts in an asset position | 1 |  |  | 29 |  |  | — |  |  | — |  |  | 30 |  |
| Interest rate contracts in a liability position | — |  |  | — |  |  | (1) |  |  | (53) |  |  | (54) |  |
| Net asset (liability) | 66 |  |  | 29 |  |  | (19) |  |  | (53) |  |  | 23 |  |
| Total derivatives at fair value | $ | 130 |  |  | $ | 29 |  |  | $ | (18) |  |  | $ | (53) |  |  | $ | 88 |  |
|  | February 2, 2024 |
|  | Other Current Assets |  | Other Non-Current Assets |  | Other Current Liabilities |  | Other Non-Current Liabilities |  | Total Fair Value |
|  | (in millions) |
| Derivatives designated as hedging instruments: |
| Foreign exchange contracts in an asset position | $ | 44 |  |  | $ | — |  |  | $ | 19 |  |  | $ | — |  |  | $ | 63 |  |
| Foreign exchange contracts in a liability position | (5) |  |  | — |  |  | (15) |  |  | — |  |  | (20) |  |
| Net asset (liability) | 39 |  |  | — |  |  | 4 |  |  | — |  |  | 43 |  |
| Derivatives not designated as hedging instruments: |
| Foreign exchange contracts in an asset position | 90 |  |  | — |  |  | 71 |  |  | — |  |  | 161 |  |
| Foreign exchange contracts in a liability position | (68) |  |  | — |  |  | (121) |  |  | — |  |  | (189) |  |
| Interest rate contracts in an asset position | 3 |  |  | 40 |  |  | — |  |  | — |  |  | 43 |  |
| Interest rate contracts in a liability position | — |  |  | — |  |  | (10) |  |  | (28) |  |  | (38) |  |
| Net asset (liability) | 25 |  |  | 40 |  |  | (60) |  |  | (28) |  |  | (23) |  |
| Total derivatives at fair value | $ | 64 |  |  | $ | 40 |  |  | $ | (56) |  |  | $ | (28) |  |  | $ | 20 |  |

[0001571996-24-000090:notes:149]
[same as prior period, unchanged from 0001571996-24-000062:notes:145]

[0001571996-24-000090:notes:150]
|  | August 2, 2024 |
|  | Gross Amounts of Recognized Assets/ (Liabilities) |  | Gross Amounts Offset in the Statement of Financial Position |  | Net Amounts of Assets/(Liabilities) Presented in the Statement of Financial Position |  | Gross Amounts not Offset in the Statement of Financial Position |  | Net Amount of Assets/ (Liabilities) Recognized in the Statement of Financial Position |
|  | Financial Instruments |  | Cash Collateral Received or Pledged |  |
|  | (in millions) |
| Derivative instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Financial assets | $ | 321 |  |  | $ | (162) |  |  | $ | 159 |  |  | $ | — |  |  | $ | (45) |  |  | $ | 114 |  |
| Financial liabilities | (233) |  |  | 162 |  |  | (71) |  |  | — |  |  | 4 |  |  | (67) |  |
| Total derivative instruments | $ | 88 |  |  | $ | — |  |  | $ | 88 |  |  | $ | — |  |  | $ | (41) |  |  | $ | 47 |  |
|  | February 2, 2024 |
|  | Gross Amounts of Recognized Assets/ (Liabilities) |  | Gross Amounts Offset in the Statement of Financial Position |  | Net Amounts of Assets/(Liabilities) Presented in the Statement of Financial Position |  | Gross Amounts not Offset in the Statement of Financial Position |  | Net Amount of Assets/ (Liabilities) Recognized in the Statement of Financial Position |
|  | Financial Instruments |  | Cash Collateral Received or Pledged |  |
|  | (in millions) |
| Derivative instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Financial assets | $ | 267 |  |  | $ | (163) |  |  | $ | 104 |  |  | $ | — |  |  | $ | (24) |  |  | $ | 80 |  |
| Financial liabilities | (247) |  |  | 163 |  |  | (84) |  |  | — |  |  | 9 |  |  | (75) |  |
| Total derivative instruments | $ | 20 |  |  | $ | — |  |  | $ | 20 |  |  | $ | — |  |  | $ | (15) |  |  | $ | 5 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001571996-24-000090:notes:151]
[same as prior period, unchanged from 0001571996-24-000062:notes:147]

[0001571996-24-000090:notes:152]
The Infrastructure Solutions Group and Client Solutions Group reporting units are consistent with the reportable segments identified in Note 16 of the Notes to the Condensed Consolidated Financial Statements. Other businesses consists of Secureworks, VMware Resale, and Virtustream, each of which represents a separate reporting unit.

[0001571996-24-000090:notes:153]
[same as prior period, unchanged from 0001571996-24-000062:notes:149]

[0001571996-24-000090:notes:154]
|  | Infrastructure Solutions Group |  | Client Solutions Group |  | Other Businesses |  | Total |
|  | (in millions) |
| Balances as of February 2, 2024 | $ | 15,041 |  |  | $ | 4,232 |  |  | $ | 427 |  |  | $ | 19,700 |  |
| Impact of foreign currency translation and other | (46) |  |  | — |  |  | — |  |  | (46) |  |
| Balances as of August 2, 2024 | $ | 14,995 |  |  | $ | 4,232 |  |  | $ | 427 |  |  | $ | 19,654 |  |

[0001571996-24-000090:notes:155]
[same as prior period, unchanged from 0001571996-24-000062:notes:151]

[0001571996-24-000090:notes:156]
[same as prior period, unchanged from 0001571996-24-000062:notes:152]

[0001571996-24-000090:notes:157]
|  | August 2, 2024 |  | February 2, 2024 |
|  | Gross |  | AccumulatedAmortization |  | Net |  | Gross |  | AccumulatedAmortization |  | Net |
|  | (in millions) |
| Customer relationships | $ | 16,968 |  |  | $ | (15,120) |  |  | $ | 1,848 |  |  | $ | 16,968 |  |  | $ | (14,930) |  |  | $ | 2,038 |  |
| Developed technology | 9,506 |  |  | (9,098) |  |  | 408 |  |  | 9,506 |  |  | (8,980) |  |  | 526 |  |
| Trade names | 875 |  |  | (842) |  |  | 33 |  |  | 875 |  |  | (823) |  |  | 52 |  |
| Definite-lived intangible assets | 27,349 |  |  | (25,060) |  |  | 2,289 |  |  | 27,349 |  |  | (24,733) |  |  | 2,616 |  |
| Indefinite-lived trade names | 3,085 |  |  | — |  |  | 3,085 |  |  | 3,085 |  |  | — |  |  | 3,085 |  |
| Total intangible assets | $ | 30,434 |  |  | $ | (25,060) |  |  | $ | 5,374 |  |  | $ | 30,434 |  |  | $ | (24,733) |  |  | $ | 5,701 |  |

[0001571996-24-000090:notes:158]
Amortization expense related to definite-lived intangible assets was $164 million and $209 million for the three months ended August 2, 2024 and August 4, 2023, respectively, and $327 million and $408 million for the six months ended August 2, 2024 and August 4, 2023, respectively. There were no material impairment charges related to intangible assets during the three or six months ended August 2, 2024 and August 4, 2023.

[0001571996-24-000090:notes:159]
[same as prior period, unchanged from 0001571996-24-000062:notes:155]

[0001571996-24-000090:notes:160]
|  | August 2, 2024 |
|  | (in millions) |
| Fiscal 2025 (remaining six months) | $ | 327 |  |
| Fiscal 2026 | 495 |  |
| Fiscal 2027 | 386 |  |
| Fiscal 2028 | 230 |  |
| Fiscal 2029 | 190 |  |
| Thereafter | 661 |  |
| Total | $ | 2,289 |  |

[0001571996-24-000090:notes:161]
[same as prior period, unchanged from 0001571996-24-000062:notes:157]

[0001571996-24-000090:notes:162]
[same as prior period, unchanged from 0001571996-24-000062:notes:158]

[0001571996-24-000090:notes:163]
For the annual impairment review of the Infrastructure Solutions Group (“ISG”) and Client Solutions Group (“CSG”) reporting units during the third quarter of Fiscal 2024, the Company elected to bypass the assessment of qualitative factors to determine whether it was more likely than not that the fair value of a reporting unit was less than its carrying amount, including goodwill. In electing to bypass the qualitative assessment, the Company proceeded directly to perform a quantitative goodwill impairment test to measure the fair value of each goodwill reporting unit relative to its carrying amount, and to determine the amount of goodwill impairment loss to be recognized, if any. For the remaining reporting units, the Company performed a qualitative assessment of goodwill at the reporting unit level. The qualitative assessment included consideration of the relevant events and circumstances affecting the reporting unit, including macroeconomic, industry and market conditions, overall financial performance, and trends in the public company market valuation, where applicable.

[0001571996-24-000090:notes:164]
Management exercised significant judgment related to the above assessments, including the identification of goodwill reporting units, assignment of assets and liabilities to goodwill reporting units, assignment of goodwill to reporting units, and determination of the fair value of each goodwill reporting unit. For the quantitative goodwill impairment test, the fair value of each goodwill reporting unit is generally estimated using a combination of public company multiples and discounted cash flow methodologies. The discounted cash flow and public company multiples methodologies require significant judgment, including estimation of future revenues, gross margins, and operating expenses, which are dependent on internal forecasts, current and anticipated economic conditions and trends, selection of market multiples through assessment of the reporting unit’s performance relative to peer competitors, the estimation of the long-term revenue growth rate and discount rate of the Company’s business, and the determination of the Company’s weighted average cost of capital. Changes in these estimates and assumptions could materially affect the fair value of the goodwill reporting unit, potentially resulting in a non-cash impairment charge.

[0001571996-24-000090:notes:165]
The fair value of the indefinite-lived trade names is generally estimated using discounted cash flow methodologies. These methodologies require significant judgment, including the estimation of future revenue, the estimation of the long-term revenue growth rate of the Company’s business and the determination of the Company’s weighted average cost of capital and royalty rates. Changes in these estimates and assumptions could materially affect the fair value of the indefinite-lived intangible assets, potentially resulting in a non-cash impairment charge.

[0001571996-24-000090:notes:166]
Based on the results of the annual impairment test performed during Fiscal 2024, the fair values of each of the reporting units and indefinite-lived intangibles exceeded their carrying values. No goodwill or indefinite-lived assets impairment test was performed during the six months ended August 2, 2024.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001571996-24-000090:notes:167]
DEFERRED REVENUE 
Deferred revenue consists of support and deployment services, software maintenance, training, software-as-a-service, and undelivered hardware and professional services, consisting of installations and consulting engagements. Deferred revenue is recorded when the Company has invoiced or payments have been received for undelivered products or services where transfer of control has not occurred. Revenue is recognized as the Company’s performance obligations under the contract are completed.

[0001571996-24-000090:notes:168]
[same as prior period, unchanged from 0001571996-24-000062:notes:164]

[0001571996-24-000090:notes:169]
|  | Three Months Ended |  | Six Months Ended |
|  | August 2, 2024 |  | August 4, 2023 |  | August 2, 2024 |  | August 4, 2023 |
|  | (in millions) |
| Deferred revenue: |  |  |  |  |  |  |  |
| Deferred revenue at beginning of period | $ | 28,150 |  |  | $ | 29,695 |  |  | $ | 29,145 |  |  | $ | 30,286 |  |
| Revenue deferrals | 4,920 |  |  | 6,025 |  |  | 9,389 |  |  | 10,744 |  |
| Revenue recognized | (5,358) |  |  | (5,408) |  |  | (10,822) |  |  | (10,718) |  |
| Deferred revenue at end of period | $ | 27,712 |  |  | $ | 30,312 |  |  | $ | 27,712 |  |  | $ | 30,312 |  |
| Short-term deferred revenue | $ | 14,853 |  |  | $ | 16,174 |  |  | $ | 14,853 |  |  | $ | 16,174 |  |
| Long-term deferred revenue | $ | 12,859 |  |  | $ | 14,138 |  |  | $ | 12,859 |  |  | $ | 14,138 |  |

[0001571996-24-000090:notes:170]
Remaining Performance Obligations — Remaining performance obligations represent the aggregate amount of the transaction price allocated to performance obligations not delivered, or partially undelivered, as of the end of the reporting period. Remaining performance obligations include deferred revenue plus unbilled amounts not yet recorded in deferred revenue. The value of the transaction price allocated to remaining performance obligations as of August 2, 2024 was approximately $38 billion. The Company expects to recognize approximately 59% of remaining performance obligations as revenue in the next twelve months, and the remainder thereafter.

[0001571996-24-000090:notes:171]
The aggregate amount of the transaction price allocated to remaining performance obligations does not include amounts owed under cancelable contracts where there is no substantive termination penalty. The Company applied the practical expedient to exclude the value of remaining performance obligations for contracts for which revenue is recognized at the amount to which the Company has the right to invoice for services performed.

[0001571996-24-000090:notes:172]
[same as prior period, unchanged from 0001571996-24-000062:notes:168]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001571996-24-000090:notes:173]
COMMITMENTS AND CONTINGENCIES 
Purchase Obligations

[0001571996-24-000090:notes:174]
The Company has contractual obligations to purchase goods or services, which specify significant terms (including fixed or minimum quantities to be purchased), fixed, minimum, or variable price provisions, and the approximate timing of the transaction. As of August 2, 2024, such purchase obligations were $5.7 billion for Fiscal 2025; $0.5 billion for Fiscal 2026; and $1.0 billion for Fiscal 2027 and thereafter.

[0001571996-24-000090:notes:175]
Legal Matters

[0001571996-24-000090:notes:176]
The Company is involved in various claims, suits, assessments, investigations, and legal proceedings that arise from time to time in the ordinary course of its business, including those identified below, consisting of matters involving consumer, antitrust, tax, intellectual property, and other issues on a global basis.

[0001571996-24-000090:notes:177]
The Company accrues a liability when it believes that it is both probable that a liability has been incurred and that it can reasonably estimate the amount of the loss. The Company reviews these accruals at least quarterly and adjusts them to reflect ongoing negotiations, settlements, rulings, advice of legal counsel, and other relevant information. To the extent new information is obtained and the Company’s views on the probable outcomes of claims, suits, assessments, investigations, or legal proceedings change, changes in the Company’s accrued liabilities are recorded in the period in which such a determination is made. For some matters, the incurrence of a liability is not probable or the amount cannot be reasonably estimated and therefore accruals have not been made.

[0001571996-24-000090:notes:178]
The following is a discussion of the Company’s significant legal matters and other proceedings:

[0001571996-24-000090:notes:179]
Class Actions Related to the Class V Transaction — On December 28, 2018, the Company completed a transaction (the “Class V transaction”) in which it paid $14.0 billion in cash and issued 149,387,617 shares of its Class C Common Stock to holders of its Class V Common Stock in exchange for all outstanding shares of Class V Common Stock. As a result of the Class V transaction, the tracking stock feature of the Company’s capital structure associated with the Class V Common Stock was terminated. Certain stockholders of the Company subsequently brought class action complaints arising out of the Class V transaction in which they named as defendants (collectively, the “defendants”) Michael S. Dell and certain other directors serving on the Company’s board of directors at the time of the Class V transaction (collectively, the “director defendants”), certain stockholders of the Company, consisting of Mr. Dell and Silver Lake Group, L.L.C. and certain of its affiliated funds (collectively, the “stockholder defendants”), and Goldman Sachs & Co. LLC, which served as financial advisor to the Company in connection with the transaction. The plaintiffs generally alleged that the director defendants and the stockholder defendants breached their fiduciary duties under Delaware law to the former holders of the Class V Common Stock in connection with the Class V transaction by offering a transaction value that was allegedly billions of dollars below fair value.

[0001571996-24-000090:notes:180]
As previously reported, during the fourth quarter of the fiscal year ended February 3, 2023, the plaintiffs and the defendants entered into an agreement to settle the lawsuit. Under the terms of the settlement, the plaintiffs agreed to the dismissal of all claims upon payment of a total of $1.0 billion (the “settlement amount”), which includes all costs, expenses and fees of the plaintiff class relating to the action and its resolution. On May 16, 2023, during the fiscal year ended February 2, 2024, the Company paid the settlement amount following approval of the settlement by the Delaware Court of Chancery. This matter is no longer material to the Company.

[0001571996-24-000090:notes:181]
R2 Semiconductor Patent Litigation — In November 2022, R2 Semiconductor, Inc. (“R2”) filed a lawsuit in the Dusseldorf Regional Court in Germany against Intel Deutschland GmbH, Dell GmbH, and certain other customers of Intel Corporation. R2 asserted that one European patent is infringed by certain Intel processors and those of the Company’s products that incorporate those processors. R2 sought an injunction prohibiting the sale of the allegedly infringing products and damages for the alleged infringement. The court conducted a trial on December 7, 2023 and, on February 7, 2024, issued a decision in favor of R2 and imposed an injunction prohibiting the sale and use of such products in Germany by Dell GmbH, and requiring Dell GmbH to issue a communication to certain customers recalling the covered products sold since March 5, 2020. On February 8, 2024, the Company filed an appeal. In April and May 2024, R2 filed lawsuits in Paris, France and Milan, Italy, against affiliates of Intel Corporation (“Intel”) and of the Company, raising similar allegations. Intel agreed to defend the foregoing actions and indemnify the Company and its affiliates against certain losses incurred by the Company in connection with R2’s claims. On August 30, 2024, Intel and R2 publicly announced an agreement to dismiss all litigation between the two companies that would include dismissal of all litigation against all subsidiaries of Dell Technologies named in the foregoing actions. Pursuant to that agreement, the Italian lawsuit was dismissed on September 2, 2024, the German lawsuit was dismissed on September 4, 2024, and the French lawsuit was dismissed on September 6, 2024.

[0001571996-24-000090:notes:182]
Other Litigation — Dell does not currently anticipate that any of the other legal proceedings it is involved in will have a material adverse effect on its business, financial condition, results of operations, or cash flows.

[0001571996-24-000090:notes:183]
In accordance with the relevant accounting guidance, the Company provides disclosures of matters where it is at least reasonably possible that the Company could experience a material loss exceeding the amounts already accrued for these or other proceedings or matters. In addition, the Company also discloses matters based on its consideration of other matters and qualitative factors, including the experience of other companies in the industry, and investor, customer, and employee relations considerations. As of August 2, 2024, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for these or other proceedings or matters has been incurred. However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company’s business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters. Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company’s business, financial condition, results of operations, or cash flows will depend on a number of factors, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.

[0001571996-24-000090:notes:184]
Indemnifications Obligations

[0001571996-24-000090:notes:185]
In the ordinary course of business, the Company enters into various contracts under which it may agree to indemnify other parties for losses incurred from certain events as defined in the relevant contract, such as litigation, regulatory penalties, or claims relating to past performance. Such indemnification obligations may not be subject to maximum loss clauses. Historically, payments related to these indemnification obligations have not been material to the Company.

[0001571996-24-000090:notes:186]
Under the Separation and Distribution Agreement entered into with VMware, Inc. upon completion of the spin-off of VMware, Inc. on November 1, 2021 (the “VMware Spin-off”), Dell Technologies agreed to indemnify VMware, Inc., each of its subsidiaries and each of their respective directors, officers, employees, as well as any successors and assigns of the foregoing, from and against all liabilities relating to, arising out of or resulting from, among other matters, the liabilities allocated to Dell Technologies as part of the separation of Dell Technologies and VMware, Inc. (individually and together with its subsidiaries, “VMware”) and their respective businesses (the “Separation”). VMware similarly agreed to indemnify Dell Technologies Inc., each of its subsidiaries and each of their respective directors, officers, and employees from and against all liabilities relating to, arising out of or resulting from, among other matters, the liabilities allocated to VMware as part of the Separation. The amounts that VMware and Dell Technologies may be obligated to pay each other could vary depending on the outcome of certain unresolved tax matters, which may not be resolved for several years. Net income tax indemnification receivables from VMware were immaterial as of August 2, 2024 and February 2, 2024.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001571996-24-000090:notes:187]
INCOME AND OTHER TAXES
For the three months ended August 2, 2024, the Company’s effective income tax rate was 15.0% on pre-tax income of $1.0 billion compared to 36.3% on pre-tax income of $0.7 billion for the three months ended August 4, 2023. For the six months ended August 2, 2024, the Company’s effective income tax rate was (16.9)% on pre-tax income of $1.5 billion compared to 27.2% on pre-tax income of $1.4 billion for the six months ended August 4, 2023.The changes in the Company’s effective income tax rate were primarily driven by discrete tax items. For the six months ended August 2, 2024, the Company recorded discrete tax benefits of $0.4 billion related to changes in uncertain tax benefits resulting from the expiration of certain statutes of limitations and $0.2 billion related to stock-based compensation.

[0001571996-24-000090:notes:188]
The differences between the estimated effective income tax rates and the U.S. federal statutory rate of 21% principally result from the geographical distribution of income, differences between the book and tax treatment of certain items, and discrete tax items. In certain jurisdictions, the Company’s tax rate is significantly less than the applicable statutory rate as a result of tax holidays. The majority of the Company’s foreign income subject to these tax holidays and lower tax rates is attributable to Singapore and China. A significant portion of these income tax benefits relates to a tax holiday that will be effective until January 31, 2029. Most of the Company’s other tax holidays will expire in whole or in part during fiscal years 2030 and 2031. Many of these tax holidays and reduced tax rates may be extended when certain conditions are met or may be terminated early if certain conditions are not met or as a result of changes in tax legislation. As of August 2, 2024, the Company was not aware of any matters of non-compliance related to these tax holidays or enacted tax legislative changes affecting these tax holidays.

[0001571996-24-000090:notes:189]
In June 2023, the Company received a Revenue Agent’s Report for the federal income tax examination by the Internal Revenue Service (“IRS”) of fiscal years 2018 through 2019. The IRS proposed adjustments primarily relating to certain transactions the Company completed as part of its business integration efforts. In August 2023, the Company submitted a written protest to the IRS relating to certain assessments. The Company received a rebuttal from the IRS to its written protest in April 2024. The Company disagrees with the IRS proposed adjustments and will contest them through the IRS administrative appeals procedures. The Company anticipates that the appeals process for the resolution of these matters will extend beyond the next twelve months. In September 2023, the IRS commenced a federal income tax examination of fiscal years 2020 through 2022.

[0001571996-24-000090:notes:190]
The Company is also currently under income tax audits in various U.S. state and foreign taxing jurisdictions. The Company is undergoing negotiations, and in some cases contested proceedings, relating to tax matters with the taxing authorities in these jurisdictions. With respect to major U.S. state and foreign taxing jurisdictions, the Company is generally not subject to tax examinations for years prior to the fiscal year ended January 29, 2010. The Company believes that it has provided adequate reserves related to all matters contained in tax periods open to examination, including the IRS audits described above.

[0001571996-24-000090:notes:191]
[same as prior period, unchanged from 0001571996-24-000062:notes:185]

[0001571996-24-000090:notes:192]
Judgment is required in evaluating the Company’s uncertain tax positions and determining the Company’s provision for income taxes. Unrecognized tax benefits were $1.0 billion and $1.3 billion as of August 2, 2024 and February 2, 2024, respectively, and are included in other non-current liabilities in the Condensed Consolidated Statements of Financial Position. The Company does not anticipate a significant change to the total amount of unrecognized tax benefits within the next twelve months.

[0001571996-24-000090:notes:193]
The Company takes certain non-income tax positions in the jurisdictions in which it operates and has received certain non-income tax assessments from various jurisdictions. The Company believes that a material loss in these matters is not probable and that it is not reasonably possible that a material loss exceeding amounts already accrued has been incurred. The Company believes its positions in these non-income tax litigation matters are supportable and that it ultimately will prevail in the matters. In the normal course of business, the Company’s positions and conclusions related to its non-income taxes could be challenged and assessments may be made. To the extent new information is obtained and the Company’s views on its positions, probable outcomes of assessments, or litigation change, changes in estimates to the Company’s accrued liabilities would be recorded in the period in which such a determination is made. In the resolution process for income tax and non-income tax audits, the Company is required in certain situations to provide collateral guarantees or indemnification to regulators and tax authorities until the matter is resolved.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001571996-24-000090:notes:194]
[same as prior period, unchanged from 0001571996-24-000062:notes:188]

[0001571996-24-000090:notes:195]
[same as prior period, unchanged from 0001571996-24-000062:notes:189]

[0001571996-24-000090:notes:196]
|  | Foreign Currency Translation Adjustments |  |  |  | Cash Flow Hedges |  | Pension and Other Postretirement Plans |  | Accumulated Other Comprehensive Income (Loss) |
|  | (in millions) |
| Balances as of February 2, 2024 | $ | (755) |  |  |  |  | $ | (30) |  |  | $ | (15) |  |  | $ | (800) |  |
| Other comprehensive income (loss) before reclassifications | (94) |  |  |  |  | 67 |  |  | 1 |  |  | (26) |  |
| Amounts reclassified from accumulated other comprehensive income (loss) | — |  |  |  |  | (37) |  |  | (1) |  |  | (38) |  |
| Total change for the period | (94) |  |  |  |  | 30 |  |  | — |  |  | (64) |  |
| Balances as of August 2, 2024 | $ | (849) |  |  |  |  | $ | — |  |  | $ | (15) |  |  | $ | (864) |  |

[0001571996-24-000090:notes:197]
Amounts related to the Company’s cash flow hedges are reclassified to net income during the same period in which the items being hedged are recognized in earnings. See Note 7 of the Notes to the Condensed Consolidated Financial Statements for more information about the Company’s derivative instruments.

[0001571996-24-000090:notes:198]
[same as prior period, unchanged from 0001571996-24-000062:notes:192]

[0001571996-24-000090:notes:199]
|  |  |  | Three Months Ended |  |  |  |  |  |  |
|  |  |  | August 2, 2024 |  | August 4, 2023 |  |  |
|  |  |  | Cash Flow Hedges |  |  |  |  |  | Pensions |  |  |  | Total |  | Cash Flow Hedges |  | Pensions |  | Total |  |  |  |  |  |  |
|  |  |  | (in millions) |
| Total reclassifications, net of tax: |  |  |  |  |  |  |
| Net revenue |  |  | $ | 14 |  |  |  |  |  |  | $ | — |  |  |  |  | $ | 14 |  |  | $ | (63) |  |  | $ | — |  |  | $ | (63) |  |  |  |  |  |  |  |
| Cost of net revenue |  |  | 4 |  |  |  |  |  |  | — |  |  |  |  | 4 |  |  | (5) |  |  | — |  |  | (5) |  |  |  |  |  |  |  |
| Operating expenses |  |  | — |  |  |  |  |  |  | — |  |  |  |  | — |  |  | — |  |  | — |  |  | — |  |  |  |  |  |  |  |
| Total reclassifications, net of tax |  |  | $ | 18 |  |  |  |  |  |  | $ | — |  |  |  |  | $ | 18 |  |  | $ | (68) |  |  | $ | — |  |  | $ | (68) |  |  |  |  |  |  |  |

[0001571996-24-000090:notes:200]
|  |  |  | Six Months Ended |
|  |  |  | August 2, 2024 |  | August 4, 2023 |
|  |  |  | Cash Flow Hedges |  |  |  |  |  | Pensions |  |  |  | Total |  | Cash Flow Hedges |  | Pensions |  | Total |
|  |  |  | (in millions) |
| Total reclassifications, net of tax: |
| Net revenue |  |  | $ | 32 |  |  |  |  |  |  | $ | — |  |  |  |  | $ | 32 |  |  | $ | (151) |  |  | $ | — |  |  | $ | (151) |  |
| Cost of net revenue |  |  | 5 |  |  |  |  |  |  | — |  |  |  |  | 5 |  |  | (8) |  |  | — |  |  | (8) |  |
| Operating expenses |  |  | — |  |  |  |  |  |  | 1 |  |  |  |  | 1 |  |  | — |  |  | — |  |  | — |  |
| Total reclassifications, net of tax |  |  | $ | 37 |  |  |  |  |  |  | $ | 1 |  |  |  |  | $ | 38 |  |  | $ | (159) |  |  | $ | — |  |  | $ | (159) |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001571996-24-000090:notes:201]
[same as prior period, unchanged from 0001571996-24-000062:notes:194]

[0001571996-24-000090:notes:202]
|  | Authorized |  | Issued |  | Outstanding |
|  | (in millions) |
| Common stock as of August 2, 2024 |
| Class A | 600 |  |  | 328 |  |  | 328 |  |
| Class B | 200 |  |  | 66 |  |  | 66 |  |
| Class C | 7,900 |  |  | 439 |  |  | 311 |  |
| Class D | 100 |  |  | — |  |  | — |  |
|  | 8,800 |  |  | 833 |  |  | 705 |  |
| Common stock as of February 2, 2024 |
| Class A | 600 |  |  | 353 |  |  | 353 |  |
| Class B | 200 |  |  | 86 |  |  | 86 |  |
| Class C | 7,900 |  |  | 382 |  |  | 266 |  |
| Class D | 100 |  |  | — |  |  | — |  |
|  | 8,800 |  |  | 821 |  |  | 705 |  |

[0001571996-24-000090:notes:203]
[same as prior period, unchanged from 0001571996-24-000062:notes:196]

[0001571996-24-000090:notes:204]
The Company is authorized to issue one million shares of preferred stock, par value $0.01 per share. As of August 2, 2024 and February 2, 2024, no shares of preferred stock were issued or outstanding.

[0001571996-24-000090:notes:205]
[same as prior period, unchanged from 0001571996-24-000062:notes:198]

[0001571996-24-000090:notes:206]
Dell Technologies Common Stock — The Class A Common Stock, the Class B Common Stock, the Class C Common Stock, and the Class D Common Stock are collectively referred to as Dell Technologies Common Stock. The par value for all series of Dell Technologies Common Stock is $0.01 per share. The Class A Common Stock, the Class B Common Stock, the Class C Common Stock, and the Class D Common Stock share equally in dividends declared or accumulated and have equal participation rights in undistributed earnings.

[0001571996-24-000090:notes:207]
[same as prior period, unchanged from 0001571996-24-000062:notes:200]

[0001571996-24-000090:notes:208]
[same as prior period, unchanged from 0001571996-24-000062:notes:201]

[0001571996-24-000090:notes:209]
During the six months ended August 2, 2024, the Company issued 45 million shares of Class C Common Stock to stockholders upon the conversion of 25 million shares of Class A Common Stock and 20 million shares of Class B Common Stock in accordance with the Company’s certificate of incorporation. During the fiscal year ended February 2, 2024, the Company issued 34 million shares of Class C Common Stock to stockholders upon the conversion of 25 million shares of Class A Common Stock and 9 million shares of Class B Common Stock in accordance with the Company’s certificate of incorporation.

[0001571996-24-000090:notes:210]
[same as prior period, unchanged from 0001571996-24-000062:notes:203]

[0001571996-24-000090:notes:211]
[same as prior period, unchanged from 0001571996-24-000062:notes:204]

[0001571996-24-000090:notes:212]
[same as prior period, unchanged from 0001571996-24-000062:notes:205]

[0001571996-24-000090:notes:213]
| Three Months Ended |  | Declaration Date |  | Record Date |  | Payment Date |  | Dividend per Share |  | Amount (in millions) |
| Fiscal 2025 |
| May 3, 2024 |  | February 29, 2024 |  | April 23, 2024 |  | May 3, 2024 |  | $ | 0.445 |  |  | $ | 316 |  |
| August 2, 2024 |  | June 11, 2024 |  | July 23, 2024 |  | August 2, 2024 |  | $ | 0.445 |  |  | $ | 314 |  |
| Fiscal 2024 |
| May 5, 2023 |  | March 2, 2023 |  | April 25, 2023 |  | May 5, 2023 |  | $ | 0.37 |  |  | $ | 270 |  |
| August 4, 2023 |  | June 16, 2023 |  | July 25, 2023 |  | August 4, 2023 |  | $ | 0.37 |  |  | $ | 268 |  |

[0001571996-24-000090:notes:214]
During the three and six months ended August 2, 2024 and August 4, 2023, the Company also paid an immaterial amount of dividend equivalents on eligible vested equity awards which are not included above.

[0001571996-24-000090:notes:215]
[same as prior period, unchanged from 0001571996-24-000062:notes:208]

[0001571996-24-000090:notes:216]
[same as prior period, unchanged from 0001571996-24-000062:notes:209]

[0001571996-24-000090:notes:217]
Effective as of October 5, 2023, the Company’s Board of Directors approved the repurchase of an additional $5 billion of shares of the Company’s Class C Common Stock under the stock repurchase program. Following the approval, the Company had approximately $5.7 billion in authorized amount remaining under the program.

[0001571996-24-000090:notes:218]
During the six months ended August 2, 2024, the Company repurchased approximately 12 million shares of Class C Common Stock for a total purchase price of approximately $1.4 billion. During the six months ended August 4, 2023, the Company repurchased approximately 11 million shares of Class C Common Stock for a total purchase price of approximately $0.5 billion. As of August 2, 2024, the Company had approximately $3.0 billion in authorized amount remaining under the stock repurchase

[0001571996-24-000090:notes:219]
program.
The above repurchases of Class C Common Stock exclude shares withheld from stock awards to settle employee tax withholding obligations related to the vesting of such awards.


## us-gaap:EarningsPerShareTextBlock

[0001571996-24-000090:notes:220]
EARNINGS PER SHARE
Basic earnings per share is based on the weighted-average effect of all common shares issued and outstanding and is calculated by dividing net income by the weighted-average shares outstanding during the period. Diluted earnings per share is calculated by dividing net income by the weighted-average number of common shares used in the basic earnings per share calculation plus the number of common shares that would be issued assuming exercise or conversion of all potentially dilutive instruments. The Company excludes equity instruments from the calculation of diluted earnings per share if the effect of including such instruments is antidilutive.

[0001571996-24-000090:notes:221]
[same as prior period, unchanged from 0001571996-24-000062:notes:213]

[0001571996-24-000090:notes:222]
|  | Three Months Ended |  | Six Months Ended |
|  | August 2, 2024 |  | August 4, 2023 |  | August 2, 2024 |  | August 4, 2023 |  |  |
| Earnings per share attributable to Dell Technologies Inc. |  |  |
| Dell Technologies Common Stock — Basic | $ | 1.19 |  |  | $ | 0.64 |  |  | $ | 2.55 |  |  | $ | 1.44 |  |  |  |
| Dell Technologies Common Stock — Diluted | $ | 1.17 |  |  | $ | 0.63 |  |  | $ | 2.49 |  |  | $ | 1.42 |  |  |  |

[0001571996-24-000090:notes:223]
[same as prior period, unchanged from 0001571996-24-000062:notes:215]

[0001571996-24-000090:notes:224]
|  | Three Months Ended |  | Six Months Ended |
|  | August 2, 2024 |  | August 4, 2023 |  | August 2, 2024 |  | August 4, 2023 |  |  |
|  | (in millions) |
| Numerator: Dell Technologies Common Stock |  |  |  |  |  |  |  |  |  |
| Net income attributable to Dell Technologies Inc. — basic and diluted | $ | 846 |  |  | $ | 462 |  |  | $ | 1,806 |  |  | $ | 1,045 |  |  |  |
| Denominator: Dell Technologies Common Stock weighted-average shares outstanding |  |  |  |  |  |  |  |  |  |
| Weighted-average shares outstanding — basic | 708 |  |  | 726 |  |  | 708 |  |  | 725 |  |  |  |
| Dilutive effect of equity awards | 16 |  |  | 12 |  |  | 17 |  |  | 12 |  |  |  |
| Weighted-average shares outstanding — diluted | 724 |  |  | 738 |  |  | 725 |  |  | 737 |  |  |  |
| Weighted-average shares outstanding — antidilutive | — |  |  | — |  |  | — |  |  | 8 |  |  |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001571996-24-000090:notes:225]
RELATED PARTY TRANSACTIONS 
Prior to the acquisition on November 22, 2023 of VMware LLC (previously VMware, Inc. and individually and together with its consolidated subsidiaries, “VMware”) by Broadcom Inc. (“Broadcom”), VMware was considered a related party of the Company. Upon Broadcom’s acquisition of VMware, Mr. Dell’s ownership interest in VMware and his position as Chairman of the Board of VMware terminated, and the Company determined no related party relationship exists with Broadcom or VMware effective as of November 22, 2023. The information provided below includes a summary of related party transactions with VMware for the three and six months ended August 4, 2023. The Company continues to engage in select transactions with VMware following the completion of Broadcom’s acquisition and the termination of the related party relationship. See Note 16 of the Notes to the Condensed Consolidated Financial Statements for additional information.

[0001571996-24-000090:notes:226]
Related Party Transactions with VMware

[0001571996-24-000090:notes:227]
•Dell Technologies integrated or bundled select VMware products and services with Dell Technologies’ products and sold them to end-users. Dell Technologies also acted as a distributor, purchasing VMware’s standalone products and services for resale to end-user customers. Where applicable, costs under these arrangements were presented net of rebates received by Dell Technologies.

[0001571996-24-000090:notes:228]
•DFS provided financing to certain VMware end-users, which resulted in the recognition of amounts due to related parties on the Condensed Consolidated Statements of Financial Position. Associated financing fees were recorded to product net revenue on the Condensed Consolidated Statements of Income and were reflected within sales and leases of products to VMware in the table below.

[0001571996-24-000090:notes:229]
•Dell Technologies procured products and services from VMware for its internal use. For the three and six months ended August 4, 2023, costs incurred associated with products and services purchased from VMware for internal use were immaterial.

[0001571996-24-000090:notes:230]
•Dell Technologies sold and leased products and sold services to VMware. For the three and six months ended August 4, 2023, revenue recognized from sales of services to VMware was immaterial.

[0001571996-24-000090:notes:231]
•Dell Technologies and VMware entered into joint marketing, sales, and branding arrangements, for which both parties incurred costs. For the three and six months ended August 4, 2023, consideration received from VMware for joint marketing, sales, and branding arrangements was immaterial.

[0001571996-24-000090:notes:232]
The following table presents information about the impact of Dell Technologies’ related party transactions with VMware on the Consolidated Statements of Income for the three and six months ended August 4, 2023:

[0001571996-24-000090:notes:233]
|  |  |  |  |  | Three Months Ended |  |  |  | Six Months Ended |
|  | Classification |  |  |  | August 4, 2023 |  |  |  | August 4, 2023 |  |  |
|  |  |  |  |  | (in millions) |
| Sales and leases of products to VMware | Net revenue - products |  |  |  | $ | 38 |  |  |  |  | $ | 78 |  |  |  |
| Purchase of VMware products for resale | Cost of net revenue - products |  |  |  | $ | 384 |  |  |  |  | $ | 591 |  |  |  |
| Purchase of VMware services for resale | Cost of net revenue - services |  |  |  | $ | 880 |  |  |  |  | $ | 1,756 |  |  |  |

[0001571996-24-000090:notes:234]
In connection with the completion of the VMware Spin-off, Dell Technologies and VMware entered into a Tax Matters Agreement effective as of April 14, 2021 (the “Tax Matters Agreement”), which governs the respective rights and obligations of Dell Technologies and VMware regarding income and other taxes as well as related matters, including tax liabilities and benefits, attributes, and returns for periods both preceding and following the VMware Spin-off. Pursuant to the Tax Matters Agreement, net receipts from VMware during the six months ended August 4, 2023 were immaterial.

[0001571996-24-000090:notes:235]
Other Related Parties

[0001571996-24-000090:notes:236]
Transactions with other related parties during the periods presented were immaterial, individually and in aggregate.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001571996-24-000090:notes:237]
SEGMENT INFORMATION 
The Company has two reportable segments that are based on the following business units: Infrastructure Solutions Group (“ISG”) and Client Solutions Group (“CSG”).

[0001571996-24-000090:notes:238]
ISG includes the Company’s storage, server, and networking offerings. The Company’s comprehensive storage portfolio includes modern and traditional storage solutions, including all-flash arrays, scale-out file, object platforms, hyper-converged infrastructure, and software-defined storage. The Company’s server portfolio includes high-performance general-purpose and AI-optimized servers. The Company’s networking portfolio includes wide area network infrastructure, data center and edge networking switches, and cables and optics. ISG also offers software, peripherals, and services, including consulting and support and deployment.

[0001571996-24-000090:notes:239]
CSG includes offerings designed for commercial and consumer customers. The Company’s CSG portfolio includes branded PCs, including notebooks, desktops, and workstations, branded peripherals, and third-party software and peripherals. CSG also includes services offerings, such as configuration, support and deployment, and extended warranties.

[0001571996-24-000090:notes:240]
The reportable segments disclosed herein are based on information reviewed by the Company’s management to evaluate the business segment results. The Company’s measure of segment revenue and segment operating income for management reporting purposes excludes operating results of other businesses, unallocated corporate transactions, amortization of intangible assets, stock-based compensation expense, and other corporate expenses, as applicable. The Company does not allocate assets to the above reportable segments for internal reporting purposes.

[0001571996-24-000090:notes:241]
Following its acquisition by Broadcom on November 22, 2023, VMware announced changes to its go-to-market approach for VMware offerings that impacted the Company’s commercial relationship with VMware. On March 25, 2024, the Company terminated the Commercial Framework Agreement with VMware, which provided the framework pursuant to which the Company and VMware continued the commercial relationship following the VMware Spin-off and under which Dell Technologies acted as a distributor of VMware’s stand-alone products and services and purchased such products and services for resale to end-user customers (“VMware Resale”). Dell Technologies no longer acts as a distributor of VMware’s standalone products and services, though the Company will continue to support customers that have purchased resale offerings sold in prior periods. The results of VMware Resale transactions are reflected in other businesses. The Company continues to integrate certain VMware products and services with select Dell Technologies’ offerings to end-users. The results of such offerings are reflected within CSG or ISG, depending upon the nature of the underlying offering sold.

[0001571996-24-000090:notes:242]
[same as prior period, unchanged from 0001571996-24-000062:notes:234]

[0001571996-24-000090:notes:243]
|  | Three Months Ended |  | Six Months Ended |  |  |
|  | August 2, 2024 |  | August 4, 2023 |  | August 2, 2024 |  | August 4, 2023 |  |  |
|  | (in millions) |
| Consolidated net revenue: |  |  |  |  |  |  |  |  |  |
| Infrastructure Solutions Group | $ | 11,646 |  |  | $ | 8,461 |  |  | $ | 20,873 |  |  | $ | 16,054 |  |  |  |
| Client Solutions Group | 12,414 |  |  | 12,942 |  |  | 24,381 |  |  | 24,925 |  |  |  |
| Reportable segment net revenue | 24,060 |  |  | 21,403 |  |  | 45,254 |  |  | 40,979 |  |  |  |
| Other businesses (a) | 966 |  |  | 1,528 |  |  | 2,015 |  |  | 2,871 |  |  |  |
| Unallocated transactions (b) | — |  |  | 3 |  |  | 1 |  |  | 6 |  |  |  |
| Total consolidated net revenue | $ | 25,026 |  |  | $ | 22,934 |  |  | $ | 47,270 |  |  | $ | 43,856 |  |  |  |
| Consolidated operating income: |  |  |  |  |  |  |  |  |  |
| Infrastructure Solutions Group | $ | 1,284 |  |  | $ | 1,049 |  |  | $ | 2,020 |  |  | $ | 1,789 |  |  |  |
| Client Solutions Group | 767 |  |  | 969 |  |  | 1,499 |  |  | 1,861 |  |  |  |
| Reportable segment operating income | 2,051 |  |  | 2,018 |  |  | 3,519 |  |  | 3,650 |  |  |  |
| Other businesses (a) | (17) |  |  | (44) |  |  | (11) |  |  | (80) |  |  |  |
| Unallocated transactions (b) | — |  |  | 3 |  |  | — |  |  | 5 |  |  |  |
| Amortization of intangibles (c) | (168) |  |  | (213) |  |  | (336) |  |  | (416) |  |  |  |
| Stock-based compensation expense (d) | (191) |  |  | (223) |  |  | (401) |  |  | (448) |  |  |  |
| Other corporate expenses (e) | (333) |  |  | (376) |  |  | (509) |  |  | (477) |  |  |  |
| Total consolidated operating income | $ | 1,342 |  |  | $ | 1,165 |  |  | $ | 2,262 |  |  | $ | 2,234 |  |  |  |

[0001571996-24-000090:notes:244]
[same as prior period, unchanged from 0001571996-24-000062:notes:236]

[0001571996-24-000090:notes:245]
[same as prior period, unchanged from 0001571996-24-000062:notes:237]

[0001571996-24-000090:notes:246]
[same as prior period, unchanged from 0001571996-24-000062:notes:238]

[0001571996-24-000090:notes:247]
[same as prior period, unchanged from 0001571996-24-000062:notes:239]

[0001571996-24-000090:notes:248]
[same as prior period, unchanged from 0001571996-24-000062:notes:240]

[0001571996-24-000090:notes:249]
[same as prior period, unchanged from 0001571996-24-000062:notes:241]

[0001571996-24-000090:notes:250]
|  | Three Months Ended |  | Six Months Ended |
|  | August 2, 2024 |  | August 4, 2023 |  | August 2, 2024 |  | August 4, 2023 |  |  |
|  | (in millions) |
| Net revenue: |  |  |  |  |  |  |  |  |  |
| Infrastructure Solutions Group: |  |  |  |  |  |  |  |  |  |
| Servers and networking | $ | 7,672 |  |  | $ | 4,274 |  |  | $ | 13,138 |  |  | $ | 8,111 |  |  |  |
| Storage | 3,974 |  |  | 4,187 |  |  | 7,735 |  |  | 7,943 |  |  |  |
| Total ISG net revenue | $ | 11,646 |  |  | $ | 8,461 |  |  | $ | 20,873 |  |  | $ | 16,054 |  |  |  |
| Client Solutions Group: |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 10,556 |  |  | $ | 10,554 |  |  | $ | 20,710 |  |  | $ | 20,416 |  |  |  |
| Consumer | 1,858 |  |  | 2,388 |  |  | 3,671 |  |  | 4,509 |  |  |  |
| Total CSG net revenue | $ | 12,414 |  |  | $ | 12,942 |  |  | $ | 24,381 |  |  | $ | 24,925 |  |  |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001571996-24-000090:notes:251]
[same as prior period, unchanged from 0001571996-24-000062:notes:243]

[0001571996-24-000090:notes:252]
|  | August 2, 2024 |  | February 2, 2024 |
|  | (in millions) |
| Cash, cash equivalents, and restricted cash: |  |  |  |
| Cash and cash equivalents | $ | 4,550 |  |  | $ | 7,366 |  |
| Restricted cash - other current assets (a) | 118 |  |  | 136 |  |
| Restricted cash - other non-current assets (a) | 3 |  |  | 5 |  |
| Total cash, cash equivalents, and restricted cash | $ | 4,671 |  |  | $ | 7,507 |  |
| Inventories: |  |  |  |
| Production materials | $ | 4,290 |  |  | $ | 2,321 |  |
| Work-in-process | 730 |  |  | 607 |  |
| Finished goods | 933 |  |  | 694 |  |
| Total inventories | $ | 5,953 |  |  | $ | 3,622 |  |
| Prepaid expenses: |  |  |  |
| Total prepaid expenses (b) | $ | 762 |  |  | $ | 589 |  |
| Deferred costs: |  |  |  |
| Total deferred costs, current (b) | $ | 5,057 |  |  | $ | 5,548 |  |
| Property, plant, and equipment, net: |  |  |  |
| Assets in a customer contract | $ | 5,123 |  |  | $ | 5,022 |  |
| Computer and other equipment | 3,714 |  |  | 3,552 |  |
| Land and buildings | 2,813 |  |  | 2,877 |  |
| Internal use software | 2,360 |  |  | 2,166 |  |
| Total property, plant, and equipment | 14,010 |  |  | 13,617 |  |
| Accumulated depreciation and amortization | (7,710) |  |  | (7,185) |  |
| Total property, plant, and equipment, net | $ | 6,300 |  |  | $ | 6,432 |  |

[0001571996-24-000090:notes:253]
[same as prior period, unchanged from 0001571996-24-000062:notes:245]

[0001571996-24-000090:notes:254]
(b)    Deferred costs and prepaid expenses are included in other current assets in the Condensed Consolidated Statements of Financial Position. Amounts classified as long-term deferred costs and long-term prepaid expenses are included in other non-current assets and are not disclosed above.

[0001571996-24-000090:notes:255]
[same as prior period, unchanged from 0001571996-24-000062:notes:247]

[0001571996-24-000090:notes:256]
[same as prior period, unchanged from 0001571996-24-000062:notes:248]

[0001571996-24-000090:notes:257]
|  | Three Months Ended |  | Six Months Ended |
|  | August 2, 2024 |  | August 4, 2023 |  | August 2, 2024 |  | August 4, 2023 |  |  |
|  | (in millions) |
| Warranty liability: |  |  |  |  |  |  |  |  |  |
| Warranty liability at beginning of period | $ | 426 |  |  | $ | 438 |  |  | $ | 426 |  |  | $ | 467 |  |  |  |
| Costs accrued for new warranty contracts and changes in estimates for pre-existing warranties (a) | 216 |  |  | 202 |  |  | 445 |  |  | 398 |  |  |  |
| Service obligations honored | (203) |  |  | (201) |  |  | (432) |  |  | (426) |  |  |  |
| Warranty liability at end of period | $ | 439 |  |  | $ | 439 |  |  | $ | 439 |  |  | $ | 439 |  |  |  |

[0001571996-24-000090:notes:258]
(a)    Changes in cost estimates related to pre-existing warranties are aggregated with accruals for new standard warranty contracts. The Company’s warranty liability process does not differentiate between estimates made for pre-existing warranties and those made for new warranty obligations.

[0001571996-24-000090:notes:259]
[same as prior period, unchanged from 0001571996-24-000062:notes:251]

[0001571996-24-000090:notes:260]
The Company incurs costs related to employee severance and records a liability for these costs when it is probable that employees will be entitled to termination benefits and the amounts can be reasonably estimated. The liability related to these actions is included in accrued and other within current liabilities in the Condensed Consolidated Statements of Financial Position.

[0001571996-24-000090:notes:261]
[same as prior period, unchanged from 0001571996-24-000062:notes:253]

[0001571996-24-000090:notes:262]
|  | Three Months Ended |  | Six Months Ended |
|  | August 2, 2024 |  | August 4, 2023 |  | August 2, 2024 |  | August 4, 2023 |  |  |
|  | (in millions) |
| Severance liability: |  |  |  |  |  |  |  |  |  |
| Severance liability at beginning of period | $ | 194 |  |  | $ | 162 |  |  | $ | 352 |  |  | $ | 408 |  |  |  |
| Severance charges | 328 |  |  | 364 |  |  | 420 |  |  | 412 |  |  |  |
| Cash paid and other | (130) |  |  | (69) |  |  | (380) |  |  | (363) |  |  |  |
| Severance liability at end of period | $ | 392 |  |  | $ | 457 |  |  | $ | 392 |  |  | $ | 457 |  |  |  |

[0001571996-24-000090:notes:263]
[same as prior period, unchanged from 0001571996-24-000062:notes:255]

[0001571996-24-000090:notes:264]
|  | Three Months Ended |  | Six Months Ended |
|  | August 2, 2024 |  | August 4, 2023 |  | August 2, 2024 |  | August 4, 2023 |  |  |
|  | (in millions) |
| Severance charges: |  |  |  |  |  |  |  |  |  |
| Cost of net revenue | $ | 56 |  |  | $ | 27 |  |  | $ | 85 |  |  | $ | 48 |  |  |  |
| Selling, general, and administrative | 227 |  |  | 324 |  |  | 270 |  |  | 350 |  |  |  |
| Research and development | 45 |  |  | 13 |  |  | 65 |  |  | 14 |  |  |  |
| Total severance charges | $ | 328 |  |  | $ | 364 |  |  | $ | 420 |  |  | $ | 412 |  |  |  |

[0001571996-24-000090:notes:265]
[same as prior period, unchanged from 0001571996-24-000062:notes:257]

[0001571996-24-000090:notes:266]
The Company maintains a Supply Chain Finance Program (the “SCF Program”), which enables eligible suppliers, at the supplier's sole discretion, to sell receivables due from the Company to a third-party financial institution. The Company has no involvement in establishing the terms or conditions of the arrangement between its suppliers and the financial institution, no economic interest in a supplier's decision to sell a receivable, and does not provide legally secured assets or other forms of guarantees under the arrangement. The SCF Program does not impact the Company's liquidity as payments for participating supplier invoices are remitted by the Company to the financial institution on the original invoice due date, regardless of whether an individual invoice is sold by the supplier to the financial institution. As of August 2, 2024 and February 2, 2024, the Company had $1.2 billion and $1.1 billion, respectively, included within accounts payable on the Condensed Consolidated Statements of Financial Position representing invoices due to suppliers confirmed as valid under the SCF Program.

[0001571996-24-000090:notes:267]
[same as prior period, unchanged from 0001571996-24-000062:notes:259]

[0001571996-24-000090:notes:268]
The following table presents information regarding interest and other, net as included in the Condensed Consolidated Statements of Income for the periods indicated:

[0001571996-24-000090:notes:269]
|  | Three Months Ended |  | Six Months Ended |
|  | August 2, 2024 |  | August 4, 2023 |  | August 2, 2024 |  | August 4, 2023 |  |  |
|  | (in millions) |
| Interest and other, net: |  |  |  |  |  |  |  |  |  |
| Investment income, primarily interest | $ | 38 |  |  | $ | 66 |  |  | $ | 92 |  |  | $ | 125 |  |  |  |
| Gain (loss) on investments, net | 5 |  |  | (29) |  |  | (25) |  |  | (44) |  |  |  |
| Interest expense | (387) |  |  | (352) |  |  | (730) |  |  | (757) |  |  |  |
| Foreign exchange | (13) |  |  | (65) |  |  | (51) |  |  | (97) |  |  |  |
| Other | 4 |  |  | (71) |  |  | (12) |  |  | (42) |  |  |  |
| Total interest and other, net | $ | (353) |  |  | $ | (451) |  |  | $ | (726) |  |  | $ | (815) |  |  |  |


## us-gaap:SubsequentEventsTextBlock

[0001571996-24-000090:notes:270]
SUBSEQUENT EVENTS 
There were no known events occurring after August 2, 2024 and up until the date of issuance of this report that would materially affect the information presented herein.


## ecd:MtrlTermsOfTrdArrTextBlock

[0001571996-24-000090:notes:271]
On June 4, 2024, Yvonne McGill, our Chief Financial Officer, adopted a written plan for the sale of up to 32,000 shares of the Company’s Class C Common Stock that is intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) under the Exchange Act. The plan will expire on May 30, 2025, or on any earlier date on which all of the shares have been sold.

[0001571996-24-000090:notes:272]
On July 15, 2024, Lynn Vojvodich Radakovich, one of our Company directors, adopted a written plan for the sale of up to 17,400 shares of the Company’s Class C Common Stock that is intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) under the Exchange Act. The plan will expire on October 15, 2025, or on any earlier date on which all of the shares have been sold.
