# DELL MD&A — 0001571996-23-000019


## mdna

[0001571996-23-000019:mdna:1]
[same as prior period, unchanged from 0001571996-22-000044:mdna:1]

[0001571996-23-000019:mdna:2]
[same as prior period, unchanged from 0001571996-22-000044:mdna:2]

[0001571996-23-000019:mdna:3]
[same as prior period, unchanged from 0001571996-22-000044:mdna:3]

[0001571996-23-000019:mdna:4]
Our fiscal year is the 52- or 53-week period ending on the Friday nearest January 31.  We refer to our fiscal year ending February 2, 2024 as “Fiscal 2024” and our fiscal year ended February 3, 2023 as “Fiscal 2023.”  Fiscal 2024 will include 52 weeks and Fiscal 2023 included 53 weeks.

[0001571996-23-000019:mdna:5]
[same as prior period, unchanged from 0001571996-22-000044:mdna:6]

[0001571996-23-000019:mdna:6]
[same as prior period, unchanged from 0001571996-22-000044:mdna:7]

[0001571996-23-000019:mdna:7]
Dell Technologies helps organizations build their digital futures and individuals transform how they work, live, and play.  We provide customers with one of the industry’s broadest and most innovative solutions portfolio for the data era, including traditional infrastructure and extending to multi-cloud environments.  Our differentiated and holistic IT solutions benefit our results and enable us to capture growth as customer spending priorities evolve.

[0001571996-23-000019:mdna:8]
Dell Technologies’ integrated solutions help customers modernize their IT infrastructure, manage and operate in a multicloud world, address workforce transformation, and provide critical solutions that keep people and organizations connected.  We are helping customers accelerate their digital transformations to improve and strengthen business and workforce productivity.  With our extensive portfolio and our commitment to innovation, we offer secure, integrated solutions that extend from the edge to the core to the cloud, and we are at the forefront of software-defined and cloud native infrastructure solutions.

[0001571996-23-000019:mdna:9]
Dell Technologies operates globally in approximately 180 countries, supported by a world-class organization across key functional areas, including technology and product development, marketing, sales, financial services, and services.  We have a number of durable competitive advantages that provide a critical foundation for our success.  Our go-to-market model includes a 31,000-person direct sales force and a global network of approximately 240,000 channel partners.  We employ approximately 35,000 full-time service and support professionals and maintain approximately 2,200 vendor-managed service centers.  We also manage a world-class supply chain at significant scale with approximately $77 billion in annual procurement expenditures and over 725 parts distribution centers.

[0001571996-23-000019:mdna:10]
We further strengthen customer relationships through our financing offerings provided by Dell Financial Services and its affiliates (“DFS”) and our flexible consumption models, including utility, subscription, and as-a-Service models, which we continue to expand under Dell APEX.  These offerings enable our customers to pay over time and provide them with financial flexibility to meet their changing technological requirements.

[0001571996-23-000019:mdna:11]
[same as prior period, unchanged from 0001571996-22-000044:mdna:11]

[0001571996-23-000019:mdna:12]
Our vision is to become the most essential technology company for the data era.  We help customers address their evolving IT needs and their broader digital transformation objectives as they embrace today’s multicloud world.  We intend to execute our vision by focusing on two strategic priorities:

[0001571996-23-000019:mdna:13]
[same as prior period, unchanged from 0001571996-22-000044:mdna:13]

[0001571996-23-000019:mdna:14]
[same as prior period, unchanged from 0001571996-22-000044:mdna:14]

[0001571996-23-000019:mdna:15]
We believe we are uniquely positioned in the data and multicloud era and that our results will continue to benefit from our durable competitive advantages.  We intend to continue to execute our business model and position our company for long-term success while balancing liquidity, profitability, and growth and keeping our purpose at the forefront of our decision-making: to create technologies that drive human progress.

[0001571996-23-000019:mdna:16]
The IT industry is rapidly evolving with demand for simpler, more agile solutions as companies leverage multiple clouds across their increasingly complex IT environments.  To meet our customer needs, we continue to invest in research and development, sales, and other key areas of our business to deliver superior products and solutions capabilities and to drive long-term sustainable growth.

[0001571996-23-000019:mdna:17]
[same as prior period, unchanged from 0001571996-22-000044:mdna:17]

[0001571996-23-000019:mdna:18]
[same as prior period, unchanged from 0001571996-22-000044:mdna:18]

[0001571996-23-000019:mdna:19]
•Infrastructure Solutions Group (“ISG”) — ISG enables our customers’ digital transformation with solutions that address the fundamental shift to multicloud environments, machine learning, artificial intelligence (“AI”), and data analytics.  ISG helps customers simplify, streamline, and automate cloud operations.  ISG solutions are built for multicloud environments and are optimized to run cloud native workloads in both public and private clouds, as well as traditional on-premise workloads.

[0001571996-23-000019:mdna:20]
Our comprehensive storage portfolio includes traditional as well as next-generation storage solutions, including all-flash arrays, scale-out file, object platforms, hyper-converged infrastructure, and software-defined storage.  We have simplified our storage portfolio and continue to make enhancements to our storage offerings that we expect will drive long-term improvements in the business.

[0001571996-23-000019:mdna:21]
Our server portfolio includes high-performance rack, blade, and tower servers.  Our servers are designed with the capability to run high value workloads across customers’ IT environments, including AI, machine learning, and edge workloads.  Our networking portfolio helps our business customers transform and modernize their infrastructure, mobilize and enrich end-user experiences, and accelerate business applications and processes.

[0001571996-23-000019:mdna:22]
Our strengths in server, storage, and virtualization software solutions allow us to offer leading converged and hyper-converged solutions, enabling our customers to accelerate their IT transformation with scalable integrated solutions instead of building and assembling their own IT platforms.  ISG also offers software, peripherals, and services, including configuration, and support and deployment.

[0001571996-23-000019:mdna:23]
[same as prior period, unchanged from 0001571996-22-000044:mdna:23]

[0001571996-23-000019:mdna:24]
•Client Solutions Group (“CSG”) — CSG includes branded PCs including notebooks, desktops, and workstations and branded peripherals including displays and docking stations, as well as third-party software and peripherals.  CSG also includes services offerings, such as support and deployment, configuration, and extended warranties.

[0001571996-23-000019:mdna:25]
Our CSG offerings are designed with our customers’ needs in mind and we seek to optimize performance, reliability, manageability, design, and security.  Our commercial portfolio provides our customers with solutions centered around flexibility to address their complex needs such as IT modernization, hybrid work transformation, and other critical needs.  Within our high-end consumer and gaming offerings, we provide our customers with powerful performance, processing, and end-user experiences.

[0001571996-23-000019:mdna:26]
[same as prior period, unchanged from 0001571996-22-000044:mdna:26]

[0001571996-23-000019:mdna:27]
Our “other businesses,” described below, primarily consist of our resale of standalone offerings of VMware, Inc. (individually and together with its subsidiaries, “VMware”), referred to as “VMware Resale,” and offerings of SecureWorks Corp. (“Secureworks”).  These businesses are not classified as reportable segments, either individually or collectively.

[0001571996-23-000019:mdna:28]
•VMware Resale consists of our sale of standalone VMware offerings.  Under our Commercial Framework Agreement with VMware discussed in this report, Dell Technologies continues to act as a key channel partner for VMware, reselling VMware’s offerings to our customers.  This partnership is intended to facilitate mutually beneficial growth for both Dell Technologies and VMware.

[0001571996-23-000019:mdna:29]
VMware works with customers in the areas of hybrid and multicloud, modern applications, networking, security, and digital workspaces, helping customers manage their IT resources across private clouds and complex multicloud, multi-device environments.

[0001571996-23-000019:mdna:30]
•Secureworks (NASDAQ: SCWX) is a leading global cybersecurity provider of technology-driven security solutions singularly focused on protecting its customers by outpacing and outmaneuvering the adversary.  The solutions offered by Secureworks enable organizations of varying size and complexity to prevent security breaches, detect malicious activity, respond rapidly when a security breach occurs, and identify emerging threats.

[0001571996-23-000019:mdna:31]
Our offerings are continually evolving in response to customer needs.  As a result, reclassifications of certain products and services solutions in major product categories may be required.  For further discussion regarding our current reportable segments, see “Results of Operations — Business Unit Results” and Note 16 of the Notes to the Condensed Consolidated Financial Statements included in this report.

[0001571996-23-000019:mdna:32]
[same as prior period, unchanged from 0001571996-22-000044:mdna:34]

[0001571996-23-000019:mdna:33]
DFS supports our businesses by offering and arranging various financing options and services for our customers globally.  DFS originates, collects, and services customer receivables primarily related to the purchase or use of our product, software, and services solutions.  We also arrange financing for some of our customers in various countries where DFS does not currently operate as a captive enterprise.  We further strengthen customer relationships through flexible consumption models, including utility, subscription, and as-a-Service models, which enable us to offer our customers the option to pay over time to provide them with financial flexibility to meet their changing technological requirements.  The results of these operations are allocated to our segments based on the underlying product or service financed and may be impacted by, among other items, changes in the interest rate environment and the translation of those changes to pricing.  For additional information about our financing arrangements, see Note 4 of the Notes to the Condensed Consolidated Financial Statements included in this report.

[0001571996-23-000019:mdna:34]
Product Backlog

[0001571996-23-000019:mdna:35]
Product backlog represents the value of unfulfilled manufacturing orders and is included as a component of remaining performance obligations to the extent we determine that the manufacturing orders are non-cancelable. Our business model generally gives us the ability to optimize product backlog at any point in time, such as by expediting shipping or prioritizing customer orders for products that have shorter lead times.

[0001571996-23-000019:mdna:36]
[same as prior period, unchanged from 0001571996-22-000044:mdna:41]

[0001571996-23-000019:mdna:37]
On November 1, 2021, we completed our spin-off of VMware by means of a special stock dividend (the “VMware Spin-off”).  In connection with and upon completion of the VMware Spin-off, we entered into a Commercial Framework Agreement (the “CFA”) with VMware, which provides the framework under which we and VMware continue our commercial relationship.  Pursuant to the CFA, we continue to act as a distributor of VMware’s standalone products and services and purchase such products and services for resale to customers.  We also continue to integrate VMware’s products and services with Dell Technologies’ offerings and sell them to customers.

[0001571996-23-000019:mdna:38]
VMware is considered to be a related party of the Company as a result of Michael Dell’s ownership interests in both Dell Technologies and VMware and Mr. Dell’s service as Chairman and Chief Executive Officer of Dell Technologies and as Chairman of the Board of VMware, Inc.  For more information regarding related party transactions with VMware, see Note 15 of the Notes to the Condensed Consolidated Financial Statements included in this report.

[0001571996-23-000019:mdna:39]
[same as prior period, unchanged from 0001571996-22-000044:mdna:43]

[0001571996-23-000019:mdna:40]
As part of our strategy, we will continue to evaluate opportunities for strategic investments through our venture capital investment arm, Dell Technologies Capital, with a focus on emerging technology areas that are relevant to our business and that will complement our existing portfolio of solutions.  Our investment areas include storage, software-defined networking, management and orchestration, security, machine learning and AI, Big Data and analytics, cloud, edge computing, and software development operations.  The technologies or products these companies have under development are typically in the early stages and may never have commercial value, which could result in a loss of a substantial part of our investment in the companies.

[0001571996-23-000019:mdna:41]
As of both May 5, 2023 and February 3, 2023, we held strategic investments in non-marketable securities of $1.3 billion.  See Note 3 of the Notes to the Condensed Consolidated Financial Statements included in this report for additional information.

[0001571996-23-000019:mdna:42]
[same as prior period, unchanged from 0001571996-22-000044:mdna:46]

[0001571996-23-000019:mdna:43]
[same as prior period, unchanged from 0001571996-22-000044:mdna:47]

[0001571996-23-000019:mdna:44]
Throughout the first quarter of Fiscal 2024, challenging global macroeconomic conditions continued to impact the demand for our offerings.  Within CSG, our net revenue performance was impacted by industry-wide declines in demand which began in the first half of Fiscal 2023.  Within ISG, our net revenue performance was impacted as we experienced declines in demand for both our servers and networking and storage offerings as customers exercised caution in response to the macroeconomic environment.

[0001571996-23-000019:mdna:45]
We expect that the macroeconomic environment will continue to impact our consolidated financial results for the remainder of Fiscal 2024.  We currently anticipate a decline in net revenue for the full fiscal year, notably in the first half of the year, which may put pressure on operating margins.  While we anticipate that the macroeconomic environment will continue to be challenging, we expect that demand declines will moderate through the remainder of Fiscal 2024.

[0001571996-23-000019:mdna:46]
We will continue to actively monitor global events and make prudent decisions to navigate this environment. We believe our durable competitive advantages continue to position us for long-term success.

[0001571996-23-000019:mdna:47]
Supply Chain — Dell Technologies maintains single-source and limited-source supplier relationships for certain components because the relationships are advantageous in the areas of performance, quality, support, delivery, capacity, and price considerations.

[0001571996-23-000019:mdna:48]
During the first quarter of Fiscal 2024, our supply chain operated efficiently at standard lead times for our customers as we saw further improvement in the previously constrained supply of limited-source components.  We also benefited from declines in both logistics and component costs, which we refer to as input costs.

[0001571996-23-000019:mdna:49]
We expect that component cost deflation will continue at a more moderate rate during the second quarter of Fiscal 2024.  Component cost trends are dependent on the strength or weakness of actual end-user demand and supply dynamics, which will continue to evolve and ultimately impact the translation of the cost environment to pricing and operating results.  Logistics costs continued to decrease from previously elevated levels as a result of declines in both expedited shipments and overall rate costs in the freight network.

[0001571996-23-000019:mdna:50]
Foreign Currency Exposure — We manage our business on a U.S. dollar basis.  However, we have a large global presence, generating approximately half of our net revenue from sales to customers outside of the United States during the first quarter of Fiscal 2024 and Fiscal 2023.  As a result, our operating results can be, and particularly in recent periods have been, impacted by fluctuations in foreign currency exchange rates.  We utilize a comprehensive hedging strategy intended to mitigate the impact of foreign currency volatility over time, and we adjust pricing when possible to further minimize foreign currency impacts.

[0001571996-23-000019:mdna:51]
ISG — We expect that ISG will continue to be impacted by the changing nature of the IT infrastructure market and competitive environment.  With our scale and strong solutions portfolio, we believe we are well-positioned to respond to ongoing competitive dynamics.

[0001571996-23-000019:mdna:52]
Through our collaborative, customer-focused approach to innovation, we strive to deliver new and relevant solutions and software to our customers quickly and efficiently.  We continue to focus on customer base expansion and lifetime value of customer relationships.  Our customer base includes a growing number of service providers, such as cloud service providers, Software-as-a-Service companies, consumer webtech providers, and telecommunications companies.  These service providers turn to Dell Technologies for our advanced solutions that enable efficient infrastructure and service delivery at cloud scale.

[0001571996-23-000019:mdna:53]
While we are anticipating challenges in the demand environment as customers re-prioritize and exercise caution in response to macroeconomic conditions, we expect that data growth will continue to generate long-term demand for our storage solutions and services.    Cloud native applications are expected to continue to be a key trend in the infrastructure market.  We benefit from offering solutions that address the emerging trends of enterprises deploying software-defined storage, hyper-converged infrastructure, and modular solutions based on server-centric architectures.  These trends are changing the way customers are consuming our storage offerings.  We continue to expand our offerings in external storage arrays, which incorporate flexible, cloud-based functionality.  Our storage business is subject to seasonal trends which we expect to continue.

[0001571996-23-000019:mdna:54]
We anticipate that ISG will benefit from the continued expansion of, and advances in, AI. Through our server and storage offerings, as well as our AI validated design solutions, we are well positioned to capture growth and support our customers needs.  We continue to optimize and enhance our offerings to run high value and transformational workloads, such as AI.

[0001571996-23-000019:mdna:55]
CSG — Our CSG offerings are an important element of our strategy, generating strong cash flow and opportunities for cross-selling of complementary solutions.  Within CSG, while we participate in all segments of the PC market, we are focused on commercial and high-end consumer computing devices, as we believe they are the most stable and profitable.  Competitive dynamics continue to be a factor in our CSG business and continue to impact pricing and operating results.

[0001571996-23-000019:mdna:56]
We remain committed to our long-term CSG strategy and will continue to make investments to innovate across the portfolio.  We expect that the CSG demand environment will continue to be subject to seasonal trends.

[0001571996-23-000019:mdna:57]
Recurring Revenue and Consumption Models — Our customers are seeking new and innovative models that address how they consume our solutions.  In part, customers are looking for predictable cost models and to reduce complexity, align solution offerings to their business needs, and provide consistent operations throughout their IT enterprise.

[0001571996-23-000019:mdna:58]
We offer options including as-a-Service, subscription, utility, leases, loans, and immediate pay models designed to match customers' consumption and financing preferences.  We believe these options are particularly advantageous for our customers during times of economic uncertainty as they provide customers with financial flexibility to further enable them to procure our solutions.

[0001571996-23-000019:mdna:59]
These offerings typically result in multiyear agreements which generate recurring revenue streams over the term of the arrangement.  We expect that these offerings will further strengthen our customer relationships and provide a foundation for growth in recurring revenue.  We define recurring revenue as revenue recognized that is primarily related to hardware and software maintenance as well as subscription, as-a-Service, usage-based offerings, and operating leases.

[0001571996-23-000019:mdna:60]
Ukraine War — We are monitoring and responding to effects of the ongoing war in Ukraine.  When Russia invaded Ukraine, we made the decision to not sell, service, or support products in Russia, Belarus, and restricted regions of Ukraine.  We have resumed product sales to non-sanctioned areas in Ukraine.  We are focused on providing products and support to Ukrainian customers as they rebuild infrastructure and restore businesses and the financial sector.

[0001571996-23-000019:mdna:61]
The war and the related economic sanctions are impacting markets worldwide.  Our business may be adversely affected by  effects of the war and such sanctions, including supply chain disruptions, product shipping delays, macroeconomic impacts resulting from the exclusion of Russian financial institutions from the global banking system, volatility in foreign exchange rates and interest rates, inflationary pressures, and heightened cybersecurity and data theft threats.  The full impact of the war on our business operations and financial performance will depend on future developments.  We will continue to monitor and assess the related restrictions and other effects and pursue prudent decisions for our team members, customers, and business.

[0001571996-23-000019:mdna:62]
COVID-19 Pandemic and Response — We continue to monitor the COVID-19 pandemic and variants of the coronavirus, as well as the impact of the pandemic on our employees, customers, business partners, and communities.

[0001571996-23-000019:mdna:63]
[same as prior period, unchanged from 0001571996-22-000044:mdna:62]

[0001571996-23-000019:mdna:64]
[same as prior period, unchanged from 0001571996-22-000044:mdna:70]

[0001571996-23-000019:mdna:65]
[same as prior period, unchanged from 0001571996-22-000044:mdna:71]

[0001571996-23-000019:mdna:66]
[same as prior period, unchanged from 0001571996-22-000044:mdna:24]

[0001571996-23-000019:mdna:67]
[same as prior period, unchanged from 0001571996-22-000044:mdna:73]

[0001571996-23-000019:mdna:68]
In this management’s discussion and analysis, we use supplemental measures of our performance which are derived from our consolidated financial information but which are not presented in our consolidated financial statements prepared in accordance with GAAP.  These non-GAAP financial measures include non-GAAP product gross margin; non-GAAP services gross margin; non-GAAP gross margin; non-GAAP operating expenses; non-GAAP operating income; non-GAAP net income; earnings before interest and other, net, taxes, depreciation, and amortization (“EBITDA”); and adjusted EBITDA.  These non-GAAP financial measures are not meant to be considered as indicators of performance in isolation from or as a substitute for gross margin, operating expenses, operating income, or net income prepared in accordance with GAAP, and should be read only in conjunction with financial information presented on a GAAP basis.

[0001571996-23-000019:mdna:69]
[same as prior period, unchanged from 0001571996-22-000044:mdna:76]

[0001571996-23-000019:mdna:70]
Non-GAAP product gross margin, non-GAAP services gross margin, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, and non-GAAP net income, as defined by us, exclude amortization of intangible assets, the impact of purchase accounting, transaction-related expenses, stock-based compensation expense, other corporate expenses and, for non-GAAP net income, fair value adjustments on equity adjustments and an aggregate adjustment for income taxes.  As the excluded items have a material impact on our financial results, our management compensates for this limitation by relying primarily on our GAAP results and using non-GAAP financial measures supplementally or for projections when comparable GAAP financial measures are not available.

[0001571996-23-000019:mdna:71]
[same as prior period, unchanged from 0001571996-22-000044:mdna:78]

[0001571996-23-000019:mdna:72]
[same as prior period, unchanged from 0001571996-22-000044:mdna:79]

[0001571996-23-000019:mdna:73]
•Amortization of Intangible Assets — Amortization of intangible assets primarily consists of amortization of customer relationships, developed technology, and trade names.  In connection with our acquisition by merger of EMC, referred to as the “EMC merger transaction,” and the acquisition of Dell Inc. by Dell Technologies Inc., referred to as the “going-private transaction,” all of the tangible and intangible assets and liabilities of EMC and Dell Inc. and its consolidated subsidiaries, respectively, were accounted for and recognized at fair value on the transaction dates.  Accordingly, for the periods presented, amortization of intangible assets primarily represents amortization associated with intangible assets recognized in connection with the EMC merger transaction and the going-private transaction.  Amortization charges for purchased intangible assets are significantly impacted by the timing and magnitude of our acquisitions, and these charges may vary in amount from period to period.  We exclude these charges for purposes of calculating the non-GAAP financial measures presented below to facilitate an enhanced understanding of our current operating performance and provide more meaningful period to period comparisons.

[0001571996-23-000019:mdna:74]
•Impact of Purchase Accounting — The impact of purchase accounting includes purchase accounting adjustments primarily related to the EMC merger transaction recorded under the acquisition method of accounting in accordance with the accounting guidance for business combinations.  Accordingly, all of the assets and liabilities acquired in such transactions were accounted for and recognized at fair value as of the respective transaction dates, and the fair value adjustments continue to amortize over the estimated useful lives in the periods following the transactions.  The fair value adjustments that are still amortizing primarily relate to property, plant, and equipment.  We believe that excluding the impact of purchase accounting for purposes of calculating the non-GAAP financial measures presented below facilitates an enhanced understanding of our current operating performance and provides more meaningful period to period comparisons.

[0001571996-23-000019:mdna:75]
•Transaction-Related (Income) Expenses — Transaction-related expenses typically consist of acquisition, integration, and divestiture related costs and are expensed as incurred.  These expenses primarily represent costs for legal, banking, consulting, and advisory services.  From time to time, this category also may include transaction-related income related to divestitures of businesses or asset sales.  We exclude these items for purposes of calculating the non-GAAP financial measures presented below to facilitate an enhanced understanding of our current operating performance and provide more meaningful period to period comparisons.

[0001571996-23-000019:mdna:76]
•Stock-based Compensation Expense — Stock-based compensation expense consists of equity awards granted based on the estimated fair value of those awards at grant date.  To estimate the fair value of performance-based awards containing a market condition, we use the Monte Carlo valuation model.  For other share-based awards, the fair value is generally based on the closing price of the Class C Common Stock as reported on the NYSE on the date of grant.  Although stock-based compensation is an important aspect of the compensation of our employees and executives, the fair value of the stock-based awards may bear little resemblance to the actual value realized upon the vesting or future exercise of the related stock-based awards.  We believe that excluding stock-based compensation expense for purposes of calculating the non-GAAP financial measures presented below facilitates an enhanced understanding of our current operating performance and provides more meaningful period to period comparisons.

[0001571996-23-000019:mdna:77]
•Other Corporate Expenses — Other corporate expenses consist of impairment charges, incentive charges related to equity investments, severance, facility action, payroll taxes associated with stock-based compensation, and other costs.  Severance costs are primarily related to severance and benefits for employees terminated pursuant to cost savings initiatives.  Other corporate expenses vary from period to period and are significantly impacted by the timing and nature of these events.  Therefore, although we may incur these types of expenses in the future, we believe that eliminating these charges for purposes of calculating the non-GAAP financial measures presented below facilitates an enhanced understanding of our current operating performance and provides more meaningful period to period comparisons.

[0001571996-23-000019:mdna:78]
[same as prior period, unchanged from 0001571996-22-000044:mdna:85]

[0001571996-23-000019:mdna:79]
•Aggregate Adjustment for Income Taxes — The aggregate adjustment for income taxes is the estimated combined income tax effect for the adjustments described above, as well as an adjustment for discrete tax items.  Due to the variability in recognition of discrete tax items from period to period, we believe that excluding these benefits or charges for purposes of calculating non-GAAP net income facilitates an enhanced understanding of our current operating performance and provides more meaningful period to period comparisons.  The tax effects are determined based on the tax jurisdictions where the above items were incurred.  See Note 11 of the Notes to the Condensed Consolidated Financial Statements included in this report for additional information on our income taxes.

[0001571996-23-000019:mdna:80]
[same as prior period, unchanged from 0001571996-22-000044:mdna:88]

[0001571996-23-000019:mdna:81]
|  | Three Months Ended |  |  |
|  | May 5,2023 |  | % Change |  | April 29,2022 |  |  |  |  |  |  |  |  |  |  |
|  | (in millions, except percentages) |
| Product gross margin | $ | 2,661 |  |  | (23) | % |  | $ | 3,455 |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 79 |  |  |  |  | 104 |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | — |  |  |  |  | 2 |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense | 13 |  |  |  |  | 13 |  |  |  |  |  |  |  |  |  |  |  |
| Other corporate expenses | 8 |  |  |  |  | 3 |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP product gross margin | $ | 2,761 |  |  | (23) | % |  | $ | 3,577 |  |  |  |  |  |  |  |  |  |  |  |
| Services gross margin | $ | 2,357 |  |  | 1 | % |  | $ | 2,329 |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense | 25 |  |  |  |  | 25 |  |  |  |  |  |  |  |  |  |  |  |
| Other corporate expenses | 21 |  |  |  |  | 10 |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP services gross margin | $ | 2,403 |  |  | 2 | % |  | $ | 2,364 |  |  |  |  |  |  |  |  |  |  |  |
| Gross margin | $ | 5,018 |  |  | (13) | % |  | $ | 5,784 |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 79 |  |  |  |  | 104 |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | — |  |  |  |  | 2 |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense | 38 |  |  |  |  | 38 |  |  |  |  |  |  |  |  |  |  |  |
| Other corporate expenses | 29 |  |  |  |  | 13 |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP gross margin | $ | 5,164 |  |  | (13) | % |  | $ | 5,941 |  |  |  |  |  |  |  |  |  |  |  |
| Operating expenses | $ | 3,949 |  |  | (7) | % |  | $ | 4,234 |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | (120) |  |  |  |  | (139) |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | (4) |  |  |  |  | (7) |  |  |  |  |  |  |  |  |  |  |  |
| Transaction-related expenses | (3) |  |  |  |  | (5) |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense | (187) |  |  |  |  | (194) |  |  |  |  |  |  |  |  |  |  |  |
| Other corporate expenses | (69) |  |  |  |  | (83) |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP operating expenses | $ | 3,566 |  |  | (6) | % |  | $ | 3,806 |  |  |  |  |  |  |  |  |  |  |  |

[0001571996-23-000019:mdna:82]
[same as prior period, unchanged from 0001571996-22-000044:mdna:58]

[0001571996-23-000019:mdna:83]
|  | Three Months Ended |  |  |
|  | May 5,2023 |  | % Change |  | April 29,2022 |  |  |  |  |  |  |  |  |  |  |
|  | (in millions, except percentages) |
| Operating income | $ | 1,069 |  |  | (31) | % |  | $ | 1,550 |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 199 |  |  |  |  | 243 |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 4 |  |  |  |  | 9 |  |  |  |  |  |  |  |  |  |  |  |
| Transaction-related expenses | 3 |  |  |  |  | 5 |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense | 225 |  |  |  |  | 232 |  |  |  |  |  |  |  |  |  |  |  |
| Other corporate expenses | 98 |  |  |  |  | 96 |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP operating income | $ | 1,598 |  |  | (25) | % |  | $ | 2,135 |  |  |  |  |  |  |  |  |  |  |  |
| Net income | $ | 578 |  |  | (46) | % |  | $ | 1,069 |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 199 |  |  |  |  | 243 |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 4 |  |  |  |  | 9 |  |  |  |  |  |  |  |  |  |  |  |
| Transaction-related (income) expenses | (1) |  |  |  |  | (2) |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense | 225 |  |  |  |  | 232 |  |  |  |  |  |  |  |  |  |  |  |
| Other corporate expenses | 99 |  |  |  |  | 96 |  |  |  |  |  |  |  |  |  |  |  |
| Fair value adjustments on equity investments | 15 |  |  |  |  | (14) |  |  |  |  |  |  |  |  |  |  |  |
| Aggregate adjustment for income taxes | (156) |  |  |  |  | (199) |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP net income | $ | 963 |  |  | (33) | % |  | $ | 1,434 |  |  |  |  |  |  |  |  |  |  |  |

[0001571996-23-000019:mdna:84]
63

[0001571996-23-000019:mdna:85]
[same as prior period, unchanged from 0001571996-22-000044:mdna:92]

[0001571996-23-000019:mdna:86]
[same as prior period, unchanged from 0001571996-22-000044:mdna:94]

[0001571996-23-000019:mdna:87]
[same as prior period, unchanged from 0001571996-22-000044:mdna:95]

[0001571996-23-000019:mdna:88]
|  | Three Months Ended |  |  |
|  | May 5,2023 |  | % Change |  | April 29,2022 |  |  |  |  |  |  |  |  |  |  |
|  | (in millions, except percentages) |
| Net income | $ | 578 |  |  | (46) | % |  | $ | 1,069 |  |  |  |  |  |  |  |  |  |  |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest and other, net (a) | 364 |  |  |  |  | 337 |  |  |  |  |  |  |  |  |  |  |  |
| Income tax expense (benefit) | 127 |  |  |  |  | 144 |  |  |  |  |  |  |  |  |  |  |  |
| Depreciation and amortization | 809 |  |  |  |  | 726 |  |  |  |  |  |  |  |  |  |  |  |
| EBITDA | $ | 1,878 |  |  | (17) | % |  | $ | 2,276 |  |  |  |  |  |  |  |  |  |  |  |
| EBITDA | $ | 1,878 |  |  | (17) | % |  | $ | 2,276 |  |  |  |  |  |  |  |  |  |  |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense | 225 |  |  |  |  | 232 |  |  |  |  |  |  |  |  |  |  |  |
| Transaction-related expenses | 3 |  |  |  |  | 5 |  |  |  |  |  |  |  |  |  |  |  |
| Other corporate expenses | 98 |  |  |  |  | 96 |  |  |  |  |  |  |  |  |  |  |  |
| Adjusted EBITDA | $ | 2,204 |  |  | (16) | % |  | $ | 2,609 |  |  |  |  |  |  |  |  |  |  |  |

[0001571996-23-000019:mdna:89]
[same as prior period, unchanged from 0001571996-22-000044:mdna:97]

[0001571996-23-000019:mdna:90]
[same as prior period, unchanged from 0001571996-22-000044:mdna:98]

[0001571996-23-000019:mdna:91]
[same as prior period, unchanged from 0001571996-22-000044:mdna:102]

[0001571996-23-000019:mdna:92]
[same as prior period, unchanged from 0001571996-22-000044:mdna:103]

[0001571996-23-000019:mdna:93]
[same as prior period, unchanged from 0001571996-22-000044:mdna:104]

[0001571996-23-000019:mdna:94]
|  | Three Months Ended |  |  |
|  | May 5, 2023 |  |  |  | April 29, 2022 |  |  |  |  |  |  |  |  |  |  |
|  | Dollars |  | % of Net Revenue |  | %Change |  | Dollars |  | % of Net Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products | $ | 15,036 |  |  | 71.9 | % |  | (27) | % |  | $ | 20,464 |  |  | 78.4 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Services | 5,886 |  |  | 28.1 | % |  | 4 | % |  | 5,652 |  |  | 21.6 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total net revenue | $ | 20,922 |  |  | 100.0 | % |  | (20) | % |  | $ | 26,116 |  |  | 100.0 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products (a) | $ | 2,661 |  |  | 17.7 | % |  | (23) | % |  | $ | 3,455 |  |  | 16.9 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Services (b) | 2,357 |  |  | 40.0 | % |  | 1 | % |  | 2,329 |  |  | 41.2 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total gross margin | $ | 5,018 |  |  | 24.0 | % |  | (13) | % |  | $ | 5,784 |  |  | 22.1 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating expenses | $ | 3,949 |  |  | 18.9 | % |  | (7) | % |  | $ | 4,234 |  |  | 16.2 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating income | $ | 1,069 |  |  | 5.1 | % |  | (31) | % |  | $ | 1,550 |  |  | 5.9 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income | $ | 578 |  |  | 2.8 | % |  | (46) | % |  | $ | 1,069 |  |  | 4.1 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP Financial Information |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | Three Months Ended |  |  |
|  | May 5, 2023 |  |  |  | April 29, 2022 |  |  |  |  |  |  |  |  |  |  |
|  | Dollars |  | % of Net Revenue |  | %Change |  | Dollars |  | % of Net Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | (in millions, except percentages) |
| Non-GAAP gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products (a) | $ | 2,761 |  |  | 18.4 | % |  | (23) | % |  | $ | 3,577 |  |  | 17.5 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Services (b) | 2,403 |  |  | 40.8 | % |  | 2 | % |  | 2,364 |  |  | 41.8 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total non-GAAP gross margin | $ | 5,164 |  |  | 24.7 | % |  | (13) | % |  | $ | 5,941 |  |  | 22.7 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP operating expenses | $ | 3,566 |  |  | 17.1 | % |  | (6) | % |  | $ | 3,806 |  |  | 14.5 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP operating income | $ | 1,598 |  |  | 7.6 | % |  | (25) | % |  | $ | 2,135 |  |  | 8.2 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP net income | $ | 963 |  |  | 4.6 | % |  | (33) | % |  | $ | 1,434 |  |  | 5.5 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| EBITDA | $ | 1,878 |  |  | 9.0 | % |  | (17) | % |  | $ | 2,276 |  |  | 8.7 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Adjusted EBITDA | $ | 2,204 |  |  | 10.5 | % |  | (16) | % |  | $ | 2,609 |  |  | 10.0 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0001571996-23-000019:mdna:95]
[same as prior period, unchanged from 0001571996-22-000044:mdna:106]

[0001571996-23-000019:mdna:96]
(a)    Product gross margin and non-GAAP product gross margin percentages are calculated as a percentage of product net revenue.

[0001571996-23-000019:mdna:97]
(b)    Services gross margin and non-GAAP services gross margin percentages are calculated as a percentage of services net revenue.

[0001571996-23-000019:mdna:98]
Non-GAAP product gross margin, non-GAAP services gross margin, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, EBITDA, and adjusted EBITDA are not measurements of financial performance prepared in accordance with GAAP.  See “Non‑GAAP Financial Measures” for additional information about these non-GAAP financial measures, including our reasons for including these measures, material limitations with respect to the usefulness of the measures, and a reconciliation of each non-GAAP financial measure to the most directly comparable GAAP financial measure.

[0001571996-23-000019:mdna:99]
[same as prior period, unchanged from 0001571996-22-000044:mdna:110]

[0001571996-23-000019:mdna:100]
During the first quarter of Fiscal 2024, our net revenue decreased 20% driven by declines in both CSG and ISG net revenue which were impacted by challenging global macroeconomic conditions that continued to affect the demand for our offerings.  CSG net revenue declined primarily as a result of a decrease in units sold, partially offset by an increase in average selling prices.  ISG net revenue decreased primarily as a result of a decline in net revenue attributable to servers and networking and, to a lesser extent, a decline in storage net revenue.

[0001571996-23-000019:mdna:101]
During the first quarter of Fiscal 2024, our operating income and non-GAAP operating income decreased 31% to $1.1 billion and 25% to $1.6 billion, respectively.  The decreases were driven by both ISG and CSG operating income which declined as a result of a decrease in net revenue, partially offset by a reduction in operating expenses as a result of disciplined cost management.  The decline in ISG operating income was driven primarily by storage and the decline in CSG operating income was driven by both commercial and consumer.

[0001571996-23-000019:mdna:102]
During the first quarter of Fiscal 2024, operating income as a percentage of net revenue and non-GAAP operating income as a percentage of net revenue decreased 80 basis points to 5.1% and 60 basis points to 7.6%, respectively.  The decreases were primarily driven by an increase in operating expenses as a percentage of net revenue which was partially offset by an increase in gross margin as a percentage of net revenue.  The increase in operating expense as a percentage of net revenue was driven by a decline in net revenue that outpaced the impacts of cost management measures.  Gross margin as a percentage of net revenue increased primarily due to the impacts of an overall decrease in input costs coupled with an increase in average selling prices across our offerings as we maintained strong pricing discipline.

[0001571996-23-000019:mdna:103]
Cash provided by operating activities was $1.8 billion during the first quarter of Fiscal 2024 which primarily reflected strong working capital performance as we reduced inventory and accounts receivable.  The impact of strong working capital performance was partially offset by the effect of a decline in net revenue.  During the first quarter of Fiscal 2023, cash used by operating activities was $0.3 billion driven by seasonal sales trends affecting parts of our business and annual incentive-based personnel-related payments.  See “Liquidity, Cash Requirements, and Market Conditions” for additional information about our cash flow metrics.

[0001571996-23-000019:mdna:104]
Despite the near-term challenges driven by uncertainty in the macroeconomic environment, we continue to see opportunities to create value and grow as we respond to long-term demand for our IT solutions driven by a technology-enabled world.  We have demonstrated our ability to adjust to changing market conditions with complementary solutions and innovation across both segments of our business, an agile workforce, and the strength of our global supply chain.  As we continue to innovate and modernize our core offerings, we believe that Dell Technologies is well-positioned for long-term profitable growth.

[0001571996-23-000019:mdna:105]
[same as prior period, unchanged from 0001571996-22-000044:mdna:120]

[0001571996-23-000019:mdna:106]
During the first quarter of Fiscal 2024, our net revenue decreased 20%, primarily driven by declines within CSG and ISG net revenue.  See “Business Unit Results” for further information.

[0001571996-23-000019:mdna:107]
•Product Net Revenue — Product net revenue includes revenue from the sale of hardware products and software licenses.  During the first quarter of Fiscal 2024, our product net revenue decreased 27% due to declines in both CSG and ISG product net revenue.  CSG product net revenue decreased primarily as a result of a decrease in units sold, which impacted both our commercial and consumer offerings, partially offset by an increase in average selling prices.  ISG product net revenue decreased primarily due to a decline in product net revenue for servers and networking, driven by a decrease in units sold, and, to a lesser extent, a decline in our product net revenue for storage offerings.

[0001571996-23-000019:mdna:108]
•Services Net Revenue — Services net revenue includes revenue from our services offerings and support services related to hardware products and software licenses.  During the first quarter of Fiscal 2024, services net revenue increased 4% driven primarily by growth within other businesses that was principally attributable to VMware Resale software maintenance sold in prior periods.  A substantial portion of services net revenue is derived from offerings that have been deferred over a period of time, and, as a result, reported growth rates for services net revenue will be different than reported growth rates for product net revenue.

[0001571996-23-000019:mdna:109]
From a geographical perspective, net revenue decreased in the Americas, EMEA, and APJ regions during the first quarter of Fiscal 2024.

[0001571996-23-000019:mdna:110]
[same as prior period, unchanged from 0001571996-22-000044:mdna:125]

[0001571996-23-000019:mdna:111]
During the first quarter of Fiscal 2024, gross margin and non-GAAP gross margin both decreased 13% to $5.0 billion and $5.2 billion, respectively, driven by declines in CSG and ISG gross margin which were primarily attributable to decreases in net revenue.

[0001571996-23-000019:mdna:112]
During the first quarter of Fiscal 2024, our gross margin and non-GAAP gross margin percentages increased 190 basis points to 24.0% and 200 basis points to 24.7%, respectively, primarily due to the impacts of an overall decline in input costs coupled with an increase in average selling price across our offerings as we maintained strong pricing discipline.

[0001571996-23-000019:mdna:113]
•Product Gross Margin — During the first quarter of Fiscal 2024, product gross margin and non-GAAP product gross margin both decreased 23% to $2.7 billion and $2.8 billion, respectively.  The decreases were primarily driven by declines in both ISG and CSG product gross margin.  The decrease in ISG product gross margin was principally attributable to decline in product gross margin within our storage offerings.  CSG product gross margin declined due to a decrease in product net revenue for both our commercial and consumer offerings.

[0001571996-23-000019:mdna:114]
During the first quarter of Fiscal 2024, product gross margin percentage and non-GAAP product gross margin percentage increased 80 basis points to 17.7% and 90 basis points to 18.4%, respectively, primarily driven by the impacts of an overall decline in input costs coupled with an increase in average selling price across our offerings as we maintained strong pricing discipline.

[0001571996-23-000019:mdna:115]
•Services Gross Margin — During the first quarter of Fiscal 2024, services gross margin and non-GAAP services gross margin increased 1% to $2.4 billion and 2% to $2.4 billion, respectively.  The increases were primarily attributable to growth within ISG services gross margin driven by support and maintenance associated with products sold in prior periods.

[0001571996-23-000019:mdna:116]
During the first quarter of Fiscal 2024, services gross margin percentage and non-GAAP services gross margin percentage decreased 120 basis points to 40.0% and 100 basis points to 40.8%, respectively.  The decreases were driven by a decline in services gross margin percentage for CSG, due to a shift in mix of CSG services delivered, coupled with a shift in mix towards other businesses services net revenue.  These impacts were partially offset by an increase in ISG services gross margin percentage.

[0001571996-23-000019:mdna:117]
[same as prior period, unchanged from 0001571996-22-000044:mdna:134]

[0001571996-23-000019:mdna:118]
[same as prior period, unchanged from 0001571996-22-000044:mdna:135]

[0001571996-23-000019:mdna:119]
The terms and conditions of our vendor rebate programs are largely based on product volumes and are generally negotiated either at the beginning of the annual or quarterly period, depending on the program.  The timing and amount of vendor rebates and other discounts we receive under the programs may vary from period to period, reflecting changes in the competitive environment.  We monitor our component costs and seek to address the effects of any changes to terms that might arise under our vendor rebate programs.  Our gross margins for the first quarter of Fiscal 2024 were not materially affected by any changes to the terms of our vendor rebate programs, as the amounts we received under these programs were generally stable relative to our total net cost.  We are not aware of any significant changes to our vendor rebate programs that will materially impact our results in the near term.

[0001571996-23-000019:mdna:120]
[same as prior period, unchanged from 0001571996-22-000044:mdna:90]

[0001571996-23-000019:mdna:121]
[same as prior period, unchanged from 0001571996-22-000044:mdna:139]

[0001571996-23-000019:mdna:122]
[same as prior period, unchanged from 0001571996-22-000044:mdna:140]

[0001571996-23-000019:mdna:123]
|  | Three Months Ended |  |  |
|  | May 5, 2023 |  |  |  | April 29, 2022 |  |  |  |  |  |  |  |  |  |  |
|  | Dollars |  | % of Net Revenue |  | %Change |  | Dollars |  | % of Net Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | (in millions, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative | $ | 3,261 |  |  | 15.6 | % |  | (8) | % |  | $ | 3,553 |  |  | 13.6 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 688 |  |  | 3.3 | % |  | 1 | % |  | 681 |  |  | 2.6 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total operating expenses | $ | 3,949 |  |  | 18.9 | % |  | (7) | % |  | $ | 4,234 |  |  | 16.2 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | Three Months Ended |  |  |
|  | May 5, 2023 |  |  |  | April 29, 2022 |  |  |  |  |  |  |  |  |  |  |
|  | Dollars |  | % of Net Revenue |  | %Change |  | Dollars |  | % of Net Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | (in millions, except percentages) |
| Non-GAAP operating expenses | $ | 3,566 |  |  | 17.1 | % |  | (6) | % |  | $ | 3,806 |  |  | 14.5 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0001571996-23-000019:mdna:124]
During the first quarter of Fiscal 2024, total operating expenses decreased 7% due to a decrease in selling, general, and administrative expenses.

[0001571996-23-000019:mdna:125]
•Selling, General, and Administrative — Selling, general, and administrative (“SG&A”) expenses decreased 8% during the first quarter of Fiscal 2024, primarily due to decreases in employee compensation and benefits and advertising expenses as a result of disciplined cost management coupled with a reduction in our overall headcount.

[0001571996-23-000019:mdna:126]
•Research and Development — Research and development (“R&D”) expenses are primarily composed of personnel-related expenses incurred in connection with product development.  R&D expenses increased 1% during the first quarter of Fiscal 2024.  As a percentage of net revenue, R&D expenses for the first quarter of Fiscal 2024 and Fiscal 2023 were 3.3% and 2.6%, respectively.  We intend to continue supporting R&D initiatives to innovate and introduce new and enhanced solutions into the market.

[0001571996-23-000019:mdna:127]
During the first quarter of Fiscal 2024, non-GAAP operating expenses decreased 6% principally due to a decline in employee compensation and benefits as a result of a reduction in headcount coupled with continued disciplined cost management.

[0001571996-23-000019:mdna:128]
[same as prior period, unchanged from 0001571996-22-000044:mdna:147]

[0001571996-23-000019:mdna:129]
[same as prior period, unchanged from 0001571996-22-000044:mdna:148]

[0001571996-23-000019:mdna:130]
During the first quarter of Fiscal 2024, our operating income and non-GAAP operating income decreased 31% to $1.1 billion and 25% to $1.6 billion, respectively.  The decreases were driven by both ISG and CSG operating income which declined as a result of a decrease in net revenue, partially offset by a reduction in operating expenses as a result of disciplined cost management.  The decline in ISG operating income was driven primarily by storage and the decline in CSG operating income was driven by both commercial and consumer.

[0001571996-23-000019:mdna:131]
During the first quarter of Fiscal 2024, operating income as a percentage of net revenue and non-GAAP operating income as a percentage of net revenue decreased 80 basis points to 5.1% and 60 basis points to 7.6%, respectively.  The decreases were primarily driven by an increase in operating expenses as a percentage of net revenue which was partially offset by an increase in gross margin as a percentage of net revenue.  The increase in operating expense as a percentage of net revenue was driven by a decline in net revenue that outpaced the impacts of cost management measures.  Gross margin as a percentage of net revenue increased primarily due to the impacts of an overall decrease in input costs coupled with an increase in average selling prices across our offerings as we maintained strong pricing discipline.

[0001571996-23-000019:mdna:132]
[same as prior period, unchanged from 0001571996-22-000044:mdna:93]

[0001571996-23-000019:mdna:133]
[same as prior period, unchanged from 0001571996-22-000044:mdna:155]

[0001571996-23-000019:mdna:134]
[same as prior period, unchanged from 0001571996-22-000044:mdna:156]

[0001571996-23-000019:mdna:135]
|  | Three Months Ended |  |  |
|  | May 5, 2023 |  | April 29, 2022 |  |  |  |  |  |  |
|  | (in millions) |
| Interest and other, net: |  |  |  |  |  |  |  |  |  |
| Investment income, primarily interest | $ | 59 |  |  | $ | 15 |  |  |  |  |  |  |  |
| Gain (loss) on investments, net | (15) |  |  | 14 |  |  |  |  |  |  |  |
| Interest expense | (405) |  |  | (265) |  |  |  |  |  |  |  |
| Foreign exchange | (32) |  |  | (89) |  |  |  |  |  |  |  |
| Other | 29 |  |  | (12) |  |  |  |  |  |  |  |
| Total interest and other, net | $ | (364) |  |  | $ | (337) |  |  |  |  |  |  |  |

[0001571996-23-000019:mdna:136]
During the first quarter of Fiscal 2024, interest and other, net was unfavorable due to an increase in interest expense driven by the impact of rising interest rates on our DFS debt.  This increase was partially offset by reduced foreign exchange impacts and an increase in investment income.

[0001571996-23-000019:mdna:137]
[same as prior period, unchanged from 0001571996-22-000044:mdna:160]

[0001571996-23-000019:mdna:138]
[same as prior period, unchanged from 0001571996-22-000044:mdna:161]

[0001571996-23-000019:mdna:139]
|  | Three Months Ended |  |  |  |
|  | May 5, 2023 |  | April 29, 2022 |  |  |  |  |  |  |  |  |  |
|  | (in millions, except percentages) |  |
| Income before income taxes | $ | 705 |  |  | $ | 1,213 |  |  |  |  |  |  |  |  |  |  |
| Income tax expense | $ | 127 |  |  | $ | 144 |  |  |  |  |  |  |  |  |  |  |
| Effective income tax rate | 18.0 | % |  | 11.9 | % |  |  |  |  |  |  |  |  |  |

[0001571996-23-000019:mdna:140]
For the first quarter of Fiscal 2024 and Fiscal 2023, our effective income tax rate was 18.0% and 11.9%, respectively. The change in our effective tax rate was primarily attributable to a change in our jurisdictional mix of income as well as higher U.S. tax on foreign operations.

[0001571996-23-000019:mdna:141]
Our effective income tax rate can fluctuate depending on the geographic distribution of our worldwide earnings, as our foreign earnings are generally taxed at lower rates than in the United States.  The differences between our effective income tax rates and the U.S. federal statutory rate of 21% principally result from the geographical distribution of income, differences between the book and tax treatment of certain items, and the tax items discussed above.  In certain jurisdictions, our tax rate is significantly less than the applicable statutory rate as a result of tax holidays.  The majority of our foreign income that is subject to these tax holidays is attributable to Singapore and China.  A significant portion of these income tax benefits relates to a tax holiday that will be effective until January 31, 2029.  Most of our other tax holidays will expire in whole or in part during Fiscal 2030 through Fiscal 2033.  Many of these tax holidays and reduced tax rates may be extended when certain conditions are met or may be terminated early if certain conditions are not met or as a result of changes in tax legislation.  As of May 5, 2023, we were not aware of any matters of noncompliance or enacted tax legislative changes affecting these tax holidays.

[0001571996-23-000019:mdna:142]
For further discussion regarding tax matters, including the status of income tax audits, see Note 11 of the Notes to the Condensed Consolidated Financial Statements included in this report.

[0001571996-23-000019:mdna:143]
Net Income

[0001571996-23-000019:mdna:144]
Net income was $0.6 billion and $1.1 billion for the first quarter of Fiscal 2024 and Fiscal 2023, respectively.  Non-GAAP net income was $1.0 billion and $1.4 billion for the first quarter of Fiscal 2024 and Fiscal 2023, respectively.  The decreases in both net income and non-GAAP net income were principally attributable to a decline in operating income.

[0001571996-23-000019:mdna:145]
71

[0001571996-23-000019:mdna:146]
[same as prior period, unchanged from 0001571996-22-000044:mdna:172]

[0001571996-23-000019:mdna:147]
Our reportable segments are based on the ISG and CSG business units.  A description of our business units is provided under “Introduction.”  See Note 16 of the Notes to the Condensed Consolidated Financial Statements included in this report for a reconciliation of net revenue and operating income by reportable segment to consolidated net revenue and consolidated operating income (loss), respectively.

[0001571996-23-000019:mdna:148]
[same as prior period, unchanged from 0001571996-22-000044:mdna:174]

[0001571996-23-000019:mdna:149]
[same as prior period, unchanged from 0001571996-22-000044:mdna:175]

[0001571996-23-000019:mdna:150]
|  | Three Months Ended |  |  |
|  | May 5, 2023 |  | % Change |  | April 29, 2022 |  |  |  |  |  |  |  |  |  |  |
|  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Servers and networking | $ | 3,837 |  |  | (24) | % |  | $ | 5,048 |  |  |  |  |  |  |  |  |  |  |
| Storage | 3,756 |  |  | (11) | % |  | 4,237 |  |  |  |  |  |  |  |  |  |  |
| Total ISG net revenue | $ | 7,593 |  |  | (18) | % |  | $ | 9,285 |  |  |  |  |  |  |  |  |  |  |
| Operating income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| ISG operating income | $ | 740 |  |  | (32) | % |  | $ | 1,082 |  |  |  |  |  |  |  |  |  |  |
| % of segment net revenue | 9.7 | % |  |  |  | 11.7 | % |  |  |  |  |  |  |  |  |  |  |

[0001571996-23-000019:mdna:151]
Net Revenue — During the first quarter of Fiscal 2024, ISG net revenue decreased 18%, driven by a decline in servers and networking net revenue and, to a lesser extent, storage net revenue as customers continue to exercise caution and manage investment in IT infrastructure in response to the macroeconomic environment.

[0001571996-23-000019:mdna:152]
Revenue from sales of servers and networking decreased 24% during the first quarter of Fiscal 2024, primarily driven by a decrease in units sold, the effect of which was partially offset by an increase in average selling price of our server offerings.  The average selling price for our server offerings increased as a result of richer configurations, the impact of attached offerings, and continued pricing discipline in response to the macroeconomic environment.

[0001571996-23-000019:mdna:153]
During the first quarter of Fiscal 2024, storage revenue decreased 11% due to a decline in net revenue across the majority of our storage offerings.

[0001571996-23-000019:mdna:154]
ISG customers are interested in new and innovative models that address how they consume our solutions.  We offer options that include as-a-Service, subscription, utility, leases, and immediate pay models which are designed to match customers’ consumption and financing preferences.  Our multiyear agreements typically result in recurring revenue streams over the term of the arrangement.  We expect that our flexible consumption models and as-a-Service offerings through Dell APEX will further strengthen our customer relationships and provide a foundation for growth in recurring revenue.

[0001571996-23-000019:mdna:155]
From a geographical perspective, net revenue attributable to ISG decreased in the Americas, EMEA, and APJ regions during the first quarter of Fiscal 2024.

[0001571996-23-000019:mdna:156]
Operating Income — During the first quarter of Fiscal 2024, ISG operating income as a percentage of net revenue decreased 200 basis points to 9.7% principally due to an increase in operating expenses as a percentage of net revenue that resulted from a decline in revenue that outpaced the impact of cost management measures.  The decline in operating expense as a percentage of net revenue was partially offset by the impacts of an overall decrease in input costs coupled with an increase in average selling price across our offerings.

[0001571996-23-000019:mdna:157]
[same as prior period, unchanged from 0001571996-22-000044:mdna:183]

[0001571996-23-000019:mdna:158]
[same as prior period, unchanged from 0001571996-22-000044:mdna:184]

[0001571996-23-000019:mdna:159]
|  | Three Months Ended |  |  |
|  | May 5, 2023 |  | % Change |  | April 29, 2022 |  |  |  |  |  |  |  |  |  |  |
|  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 9,862 |  |  | (18) | % |  | $ | 11,971 |  |  |  |  |  |  |  |  |  |  |
| Consumer | 2,121 |  |  | (41) | % |  | 3,616 |  |  |  |  |  |  |  |  |  |  |
| Total CSG net revenue | $ | 11,983 |  |  | (23) | % |  | $ | 15,587 |  |  |  |  |  |  |  |  |  |  |
| Operating income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| CSG operating income | $ | 892 |  |  | (20) | % |  | $ | 1,115 |  |  |  |  |  |  |  |  |  |  |
| % of segment net revenue | 7.4 | % |  |  |  | 7.2 | % |  |  |  |  |  |  |  |  |  |  |

[0001571996-23-000019:mdna:160]
Net Revenue — During the first quarter of Fiscal 2024, CSG net revenue decreased 23%, driven by a decline in units sold as deteriorating macroeconomic conditions continue to impact industry-wide demand.

[0001571996-23-000019:mdna:161]
Commercial net revenue and consumer net revenue decreased 18% and 41%, respectively, during the first quarter of Fiscal 2024.  These decreases were primarily due to a decrease in units sold, which was only partially offset by the effect of an increase in the average selling price of our offerings.

[0001571996-23-000019:mdna:162]
Average selling prices for our CSG offerings increased during the first quarter of Fiscal 2024 primarily as a result of a shift in mix towards our commercial offerings coupled with richer configurations and the impact of attached offerings.

[0001571996-23-000019:mdna:163]
From a geographical perspective, net revenue attributable to CSG decreased in the Americas, EMEA, and APJ regions during the first quarter of Fiscal 2024.

[0001571996-23-000019:mdna:164]
Operating Income — During the first quarter of Fiscal 2024, CSG operating income as a percentage of net revenue increased 20 basis points to 7.4%, primarily due to the impacts of an overall decrease in input costs partially offset by an increase in operating expenses as a percentage of net revenue, which increased as a result of a decline in CSG net revenue that outpaced the impact of cost management measures.

[0001571996-23-000019:mdna:165]
[same as prior period, unchanged from 0001571996-22-000044:mdna:194]

[0001571996-23-000019:mdna:166]
[same as prior period, unchanged from 0001571996-22-000044:mdna:195]

[0001571996-23-000019:mdna:167]
We sell products and services directly to customers and through a variety of sales channels, including retail distribution.  Our accounts receivable, net, was $9.4 billion and $12.5 billion as of May 5, 2023 and February 3, 2023, respectively.  The reduction in accounts receivable, net primarily reflects the decline in net revenue coupled with strong collections during the quarter.  We maintain an allowance for expected credit losses to cover receivables that may be deemed uncollectible.  The allowance for expected credit losses is an estimate based on an analysis of historical loss experience, current receivables aging, and management’s assessment of current conditions and its reasonable and supportable expectation of future conditions, as well as specific identifiable customer accounts that are deemed at risk.  As of May 5, 2023 and February 3, 2023, the allowance for expected credit losses was $77 million and $78 million, respectively.  Based on our assessment, we believe that we are adequately reserved for expected credit losses.  We are monitoring the impact of current economic conditions and the aging of our accounts receivable on our expected losses and have not experienced deterioration in delinquency or loss rates.  We will continue to take actions, where necessary, to reduce our exposure to credit losses.

[0001571996-23-000019:mdna:168]
[same as prior period, unchanged from 0001571996-22-000044:mdna:197]

[0001571996-23-000019:mdna:169]
We offer or arrange various financing options and services for our customers globally, including through captive financing operations.  DFS originates, collects, and services customer receivables primarily related to the purchase of our product, software, and service solutions.  We further strengthen customer relationships through flexible consumption models, including utility, subscription, and as-a-Service models, which enable us to offer our customers the option to pay over time to provide them with financial flexibility to meet their changing technological requirements.  We have historically seen an increasing interest in our various financing options during times of macroeconomic uncertainty.  New financing originations were $1.8 billion and $2.1 billion for the first quarter of Fiscal 2024 and Fiscal 2023, respectively.

[0001571996-23-000019:mdna:170]
Our leases are generally classified as sales-type leases or operating leases.  On commencement of sales-type leases, the Company recognizes profit up-front, and amounts due from the customer under the lease contract are recognized as financing receivables.  Interest income is recognized as net product revenue over the term of the lease.  Upon origination of operating leases, we record equipment under operating leases, classified as property, plant, and equipment.  Over the contract term of an operating lease, we recognize rental revenue and depreciation expense, classified as cost of net revenue.

[0001571996-23-000019:mdna:171]
As of May 5, 2023 and February 3, 2023, our financing receivables, net were $10.5 billion and $10.9 billion, respectively.  We maintain an allowance to cover expected financing receivable credit losses and evaluate credit loss expectations based on our total portfolio.  For both the first quarter of Fiscal 2024 and Fiscal 2023, the principal charge-off rate for our financing receivables portfolio was 0.5%.  The credit quality of our financing receivables has improved in recent years as the mix of high-quality commercial accounts in our portfolio has continued to increase.  We continue to monitor broader economic indicators and their potential impact on future credit loss performance.  We have an extensive process to manage our exposure to customer credit risk, including active management of credit lines and our collection activities.  We also sell selected fixed-term financing receivables without recourse to unrelated third parties on a periodic basis, primarily to manage certain concentrations of customer credit exposure.  Based on our assessment of the customer financing receivables, we believe that we are adequately reserved.

[0001571996-23-000019:mdna:172]
We retain a residual interest in equipment leased under our lease programs.  As of May 5, 2023 and February 3, 2023, the residual interest recorded as part of financing receivables was $147 million and $142 million, respectively.  The amount of the residual interest is established at the inception of the lease based upon estimates of the value of the equipment at the end of the lease term using historical studies, industry data, and future value-at-risk demand valuation methods.  On a quarterly basis, we assess the carrying amount of our recorded residual values for expected losses.  Generally, expected losses as a result of residual value risk on equipment under lease are not considered to be significant primarily because of the existence of a secondary market with respect to the equipment.  Further, the lease agreement defines applicable return conditions and remedies for non-compliance to ensure that the leased equipment will be in good operating condition upon return.  No expected losses were recorded related to residual assets during the first quarter of Fiscal 2024 and Fiscal 2023.

[0001571996-23-000019:mdna:173]
As of May 5, 2023 and February 3, 2023, equipment under operating leases, net was $2.2 billion and $2.2 billion, respectively.  We assess the carrying amount of the equipment under operating leases for impairment whenever events or circumstances may indicate that an impairment has occurred.  No material impairment losses were recorded related to such equipment during the first quarter of Fiscal 2024 and Fiscal 2023.

[0001571996-23-000019:mdna:174]
DFS offerings are initially funded through cash on hand at the time of origination, most of which is subsequently replaced with asset-backed financing. For DFS offerings which qualify as sales-type leases, the initial funding of financing receivables is reflected as an impact to cash flows from operations, and is largely subsequently offset by cash proceeds from financing. For DFS operating leases, the initial funding is classified as a capital expenditure and reflected as an impact to cash flows used in investing activities.

[0001571996-23-000019:mdna:175]
See Note 4 of the Notes to the Condensed Consolidated Financial Statements included in this report for additional information about our financing receivables and the associated allowances, and equipment under operating leases.

[0001571996-23-000019:mdna:176]
75

[0001571996-23-000019:mdna:177]
[same as prior period, unchanged from 0001571996-22-000044:mdna:207]

[0001571996-23-000019:mdna:178]
[same as prior period, unchanged from 0001571996-22-000044:mdna:208]

[0001571996-23-000019:mdna:179]
We rely on operating cash flows, which are impacted by trends in the demand environment, as our primary source of liquidity for our ongoing business operations.  We monitor the efficiency of our balance sheet to ensure that we have adequate liquidity to support our business and strategic initiatives.

[0001571996-23-000019:mdna:180]
In addition to internally generated cash, we have access to other capital sources to finance our strategic initiatives and fund growth in our financing operations.  Our strategy is to deploy capital from any potential source, whether internally generated cash or debt, depending on the adequacy and availability of that source of capital and whether it can be accessed in a cost-effective manner.

[0001571996-23-000019:mdna:181]
We believe that our current cash and cash equivalents, together with cash that will be provided by future operations and borrowings expected to be available under our revolving credit facility and commercial paper program, will be sufficient over at least the next twelve months and for the foreseeable future thereafter to meet our material cash requirements, including funding of our operations, debt-related payments, capital expenditures, and other corporate needs.

[0001571996-23-000019:mdna:182]
[same as prior period, unchanged from 0001571996-22-000044:mdna:211]

[0001571996-23-000019:mdna:183]
[same as prior period, unchanged from 0001571996-22-000044:mdna:212]

[0001571996-23-000019:mdna:184]
|  | May 5, 2023 |  | February 3, 2023 |
|  | (in millions) |
| Cash and cash equivalents, and available borrowings: |  |  |  |
| Cash and cash equivalents | $ | 7,631 |  |  | $ | 8,607 |  |
| Remaining available borrowings under 2021 Revolving Credit Facility | 5,999 |  |  | 5,999 |  |
| Total cash, cash equivalents, and available borrowings | $ | 13,630 |  |  | $ | 14,606 |  |

[0001571996-23-000019:mdna:185]
During the first quarter of Fiscal 2024, cash and cash equivalents decreased by $1.0 billion primarily as a result of the repayment of senior notes, the return of capital to our stockholders, and capital expenditures, partially offset by cash flows from operations.

[0001571996-23-000019:mdna:186]
As of May 5, 2023, our 2021 Revolving Credit Facility had a maximum capacity of $6.0 billion.  Available borrowings under this facility are reduced by draws on the facility and outstanding letters of credit.  As of May 5, 2023, there were no borrowings outstanding under the facility and remaining available borrowings totaled approximately $6.0 billion.  The 2021 Revolving Credit Facility also acts as a backstop to provide liquidity support for our commercial paper program.

[0001571996-23-000019:mdna:187]
During Fiscal 2023, we established a commercial paper program under which we may issue unsecured notes in a maximum aggregate face amount of $5.0 billion outstanding at any time, with maturities up to 397 days from the date of issue.  As of May 5, 2023, we had no outstanding borrowings under the program.

[0001571996-23-000019:mdna:188]
We may regularly use our available borrowings from the 2021 Revolving Credit Facility and issuances under the commercial paper program on a short-term basis for general corporate purposes.  See Note 6 of the Notes to the Condensed Consolidated Financial Statements included in this report for additional information about our debt.

[0001571996-23-000019:mdna:189]
[same as prior period, unchanged from 0001571996-22-000044:mdna:219]

[0001571996-23-000019:mdna:190]
[same as prior period, unchanged from 0001571996-22-000044:mdna:220]

[0001571996-23-000019:mdna:191]
|  | May 5, 2023 |  | Change |  | February 3, 2023 |
|  | (in millions) |
| Core debt |  |  |  |  |  |
| Senior Notes | $ | 17,250 |  |  | $ | (1,050) |  |  | $ | 18,300 |  |
| Legacy Notes and Debentures | 952 |  |  | — |  |  | 952 |  |
| DFS allocated debt | (973) |  |  | 223 |  |  | (1,196) |  |
| Total core debt | 17,229 |  |  | (827) |  |  | 18,056 |  |
| DFS related debt |  |  |  |  |  |
| DFS debt | 10,157 |  |  | (133) |  |  | 10,290 |  |
| DFS allocated debt | 973 |  |  | (223) |  |  | 1,196 |  |
| Total DFS related debt | 11,130 |  |  | (356) |  |  | 11,486 |  |
| Other | 336 |  |  | 11 |  |  | 325 |  |
| Total debt, principal amount | 28,695 |  |  | (1,172) |  |  | 29,867 |  |
| Carrying value adjustments | (263) |  |  | 16 |  |  | (279) |  |
| Total debt, carrying value | $ | 28,432 |  |  | $ | (1,156) |  |  | $ | 29,588 |  |

[0001571996-23-000019:mdna:192]
The outstanding principal amount of our debt decreased $1.2 billion to $28.7 billion as of May 5, 2023, driven primarily by the prepayment of $1.0 billion principal amount of senior notes.

[0001571996-23-000019:mdna:193]
We define core debt as the total principal amount of our debt, less DFS related debt and other debt.  Our core debt was $17.2 billion and $18.1 billion as of May 5, 2023 and February 3, 2023, respectively.  See Note 6 of the Notes to the Condensed Consolidated Financial Statements included in this report for additional information about our debt.

[0001571996-23-000019:mdna:194]
[same as prior period, unchanged from 0001571996-22-000044:mdna:224]

[0001571996-23-000019:mdna:195]
To fund expansion of the DFS business, we balance the use of the securitization and structured financing programs with other sources of liquidity.  We approximate the amount of our core debt used to fund the DFS business by applying a 7:1 debt-to-equity ratio to the sum of our financing receivables balance and equipment under our DFS operating leases, net.  The debt-to-equity ratio is based on the underlying credit quality of the assets.  See Note 4 of the Notes to the Condensed Consolidated Financial Statements included in this report for additional information about our DFS debt.

[0001571996-23-000019:mdna:196]
We believe we will continue to be able to make our debt principal and interest payments, including short-term maturities, from existing and expected sources of cash, primarily from operating cash flows.  Cash used for debt principal and interest payments may include short-term borrowings under our commercial paper program, our revolving credit facility, or other borrowings.  Under our variable-rate debt, we could experience variations in our future interest expense from potential fluctuations in applicable reference rates, or from possible fluctuations in the level of DFS debt required to meet future demand for customer financing.

[0001571996-23-000019:mdna:197]
We have made steady progress in paying down debt and we will continue to pursue deleveraging over the long-term as an important component of our overall capital allocation strategy.  At our sole discretion, we may purchase, redeem, prepay, refinance, or otherwise retire any amount of our outstanding indebtedness under the terms of such indebtedness at any time and from time to time, in open market or negotiated transactions with the holders of such indebtedness or otherwise, as we consider appropriate in light of market conditions and other relevant factors.

[0001571996-23-000019:mdna:198]
[same as prior period, unchanged from 0001571996-22-000044:mdna:228]

[0001571996-23-000019:mdna:199]
[same as prior period, unchanged from 0001571996-22-000044:mdna:229]

[0001571996-23-000019:mdna:200]
|  | Three Months Ended |
|  | May 5, 2023 |  | April 29, 2022 |  |  |
|  | (in millions) |
| Net change in cash from: |  |  |  |  |  |
| Operating activities | $ | 1,777 |  |  | $ | (269) |  |  |  |
| Investing activities | (684) |  |  | (720) |  |  |  |
| Financing activities | (2,002) |  |  | (1,706) |  |  |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash | (58) |  |  | (111) |  |  |  |
| Change in cash, cash equivalents, and restricted cash | $ | (967) |  |  | $ | (2,806) |  |  |  |

[0001571996-23-000019:mdna:201]
Operating Activities — Cash provided by operating activities was $1.8 billion during the first quarter of Fiscal 2024, which primarily reflected strong working capital performance as we reduced inventory and accounts receivable.  The impact of strong working capital performance was partially offset by the effect of a decline in revenue and annual incentive-based personnel-related payments.  During the first quarter of Fiscal 2023, cash used by operating activities was $0.3 billion driven by seasonal sales trends affecting parts of our business and annual incentive-based personnel-related payments.

[0001571996-23-000019:mdna:202]
Investing Activities — Investing activities primarily consist of cash used to fund capital expenditures for property, plant, and equipment inclusive of equipment under DFS operating leases and equipment used to support our as-a-Service offerings, which we refer to collectively as revenue-generating assets.  Additional activities include capitalized software development costs, acquisitions and divestitures, and the maturities, sales, and purchases of investments.  Cash used in investing activities was $0.7 billion during both the first quarter of Fiscal 2024 and Fiscal 2023 and was primarily applied to capital expenditures.

[0001571996-23-000019:mdna:203]
Financing Activities — Financing activities primarily consist of the proceeds and repayments of debt and return of capital to our stockholders.  Cash used in financing activities was $2.0 billion during the first quarter of Fiscal 2024 and primarily consisted of principal repayments of our senior notes, repurchases of common stock, inclusive of payments to settle employee tax withholdings on stock-based compensation, and the payment of quarterly dividends.  During the first quarter of Fiscal 2023 cash used in financing activities was $1.7 billion and was primarily driven by repurchases of common stock.

[0001571996-23-000019:mdna:204]
DFS Cash Flow Impacts — DFS offerings are initially funded through cash on hand at the time of origination, most of which is subsequently replaced with asset-backed financing.  For DFS offerings that qualify as sales-type leases, the initial funding of financing receivables is reflected as an impact to cash flows from operations and is largely subsequently offset by cash proceeds from financing.  For operating leases, the initial funding is classified as a capital expenditure and reflected as cash flows used in investing activities.  DFS new financing originations were $1.8 billion and $2.1 billion during the first quarter of Fiscal 2024 and Fiscal 2023, respectively.  As of May 5, 2023, the Company had $10.5 billion of total net financing receivables and $2.2 billion of equipment under operating leases, net.

[0001571996-23-000019:mdna:205]
Supply Chain Finance Program — We maintain a Supply Chain Finance Program (the "SCF Program”) which enables eligible suppliers to sell receivables due from us to a third-party financial institution at the suppliers’ sole discretion.  The SCF Program does not impact the Company's liquidity.  Payments by us to participating suppliers are remitted to the financial institution on the original invoice due date.  Further, we negotiate payment terms with our suppliers regardless of their decision to participate in the SCF Program.  Payments made under the SCF Program are included in cash flows from operating activities on the Condensed Consolidated Statements of Cash Flows.  See Note 17 of the Notes to the Condensed Consolidated Financial Statements included in this report for more information regarding the SCF Program.

[0001571996-23-000019:mdna:206]
Capital Commitments

[0001571996-23-000019:mdna:207]
Capital Expenditures — We spent $0.7 billion during both the first quarter of Fiscal 2024 and Fiscal 2023 on property, plant, and equipment and capitalized software development costs.  Of total expenditures incurred during both the first quarter of Fiscal 2024 and Fiscal 2023, funding of revenue-generating assets totaled $0.3 billion.  Product demand, product mix, the use of contract manufacturers, and ongoing investments in operating and information technology infrastructure influence the level and prioritization of our capital expenditures.  Aggregate capital expenditures for Fiscal 2024 are currently expected to total between $3.2 billion and $3.4 billion, of which approximately $1.7 billion are expected to relate to revenue-generating assets.

[0001571996-23-000019:mdna:208]
Repurchases of Common Stock — Effective as of September 23, 2021, our Board of Directors approved a stock repurchase program with no fixed expiration date under which we are authorized to repurchase up to $5 billion of shares of our Class C Common Stock.  During the first quarter of Fiscal 2024, the Company repurchased approximately 6.1 million shares of Class C Common Stock for a total purchase price of approximately $0.25 billion.  During the first quarter of Fiscal 2023, the Company repurchased approximately 29 million shares of Class C Common Stock for a total purchase price of approximately $1.5 billion.

[0001571996-23-000019:mdna:209]
Dividend Payments — On February 24, 2022, we announced that our Board of Directors adopted a dividend policy providing for our payment of quarterly cash dividends on our common stock at a rate of $0.33 per share per fiscal quarter beginning in the first quarter of Fiscal 2023.  On March 2, 2023, the Company announced that the Board of Directors approved a 12% increase in the quarterly dividend rate from $0.33 per share per fiscal quarter to a rate of $0.37 per share per fiscal quarter beginning in the first quarter of Fiscal 2024.  During the first quarter of Fiscal 2024 and Fiscal 2023, the Company paid $276 million and $248 million, respectively, in dividends and dividend equivalents.

[0001571996-23-000019:mdna:210]
[same as prior period, unchanged from 0001571996-22-000044:mdna:243]

[0001571996-23-000019:mdna:211]
[same as prior period, unchanged from 0001571996-22-000044:mdna:244]

[0001571996-23-000019:mdna:212]
[same as prior period, unchanged from 0001571996-22-000044:mdna:246]

[0001571996-23-000019:mdna:213]
[same as prior period, unchanged from 0001571996-22-000044:mdna:247]

[0001571996-23-000019:mdna:214]
[same as prior period, unchanged from 0001571996-22-000044:mdna:248]

[0001571996-23-000019:mdna:215]
We use derivative instruments to hedge certain foreign currency exposures.  We use forward contracts and purchased options designated as cash flow hedges to protect against the foreign currency exchange rate risks inherent in our forecasted transactions denominated in currencies other than the U.S. dollar.  In addition, we primarily use forward contracts and may use purchased options to hedge monetary assets and liabilities denominated in a foreign currency.  See Note 7 of the Notes to the Condensed Consolidated Financial Statements included in this report for additional information about our use of derivative instruments.

[0001571996-23-000019:mdna:216]
We are exposed to interest rate risk related to our variable-rate debt portfolio.  In the normal course of business we follow established policies and procedures to manage this risk, including monitoring of our asset and liability mix and the use of derivative instruments.  As a result, we do not anticipate any material losses from interest rate risk.

[0001571996-23-000019:mdna:217]
79

[0001571996-23-000019:mdna:218]
[same as prior period, unchanged from 0001571996-22-000044:mdna:252]

[0001571996-23-000019:mdna:219]
Dell International L.L.C. and EMC Corporation (the “Issuers”), both of which are wholly-owned subsidiaries of Dell Technologies Inc., completed private offerings of multiple series of senior secured notes issued on June 1, 2016, March 20, 2019, and April 9, 2020 (the “Senior Notes”).  In June 2021, the Issuers completed an exchange offer and issued $18.4 billion aggregate principal amount of registered senior notes under the Securities Act of 1933 in exchange for the same principal amount and substantially identical terms of the Senior Notes.  The aggregate principal amount of unregistered Senior Notes remaining outstanding following the settlement of the exchange offer was approximately $0.1 billion.  During Fiscal 2022, the tangible and intangible assets of the Issuers and guarantors that secured obligations under the Senior Notes were released as collateral.  As a result, the Senior Notes became fully unsecured.  In addition, all guarantees of the Senior Notes by subsidiaries of Dell Inc. were released.

[0001571996-23-000019:mdna:220]
On January 24, 2023, the Issuers completed a public offering of unsecured senior notes (together with the Senior Notes, the “Registered Senior Notes”) in the aggregate principal amount of $2.0 billion.  The unsecured senior notes were sold pursuant to a shelf registration statement.

[0001571996-23-000019:mdna:221]
Guarantees — The Registered Senior Notes are guaranteed on a joint and several unsecured basis by Dell Technologies Inc. and its wholly-owned subsidiaries, Denali Intermediate, Inc. and Dell Inc. (collectively, the “Guarantors”).

[0001571996-23-000019:mdna:222]
Basis of Preparation of the Summarized Financial Information — The tables below are summarized financial information provided in conformity with Rule 13-01 of the SEC’s Regulation S-X.  The summarized financial information of the Issuers and Guarantors (collectively, the “Obligor Group”) is presented on a combined basis, excluding intercompany balances and transactions between entities in the Obligor Group.  The Obligor Group’s amounts due from, amounts due to, and transactions with Non-Obligor Subsidiaries and VMware, Inc. and its consolidated subsidiaries (the “Related Party”) have been presented separately.  The Obligor Group’s investment balances in Non-Obligor Subsidiaries have been excluded.

[0001571996-23-000019:mdna:223]
[same as prior period, unchanged from 0001571996-22-000044:mdna:256]

[0001571996-23-000019:mdna:224]
|  | Three Months Ended |
|  | May 5, 2023 |
|  | (in millions) |
| Net revenue (a) | $ | 2,134 |  |
| Gross margin (b) | 882 |  |
| Operating income | 104 |  |
| Interest and other, net (c) | (943) |  |
| Loss before income taxes | $ | (839) |  |
| Net loss attributable to Obligor Group | $ | (627) |  |

[0001571996-23-000019:mdna:225]
[same as prior period, unchanged from 0001571996-22-000044:mdna:258]

[0001571996-23-000019:mdna:226]
(a)  Includes net revenue from services provided and product sales to Non-Obligor Subsidiaries of $192 million and $27 million, respectively.

[0001571996-23-000019:mdna:227]
(b)  Includes cost of net revenue from the resale of solutions purchased from Non-Obligor Subsidiaries and the Related Party of $222 million and $95 million, respectively.  Includes cost of net revenue from shared services provided by Non-Obligor Subsidiaries of $145 million.

[0001571996-23-000019:mdna:228]
(c)   Includes interest expense on intercompany loan payables of $614 million and other expenses from services provided by Non-Obligor Subsidiaries of $42 million.

[0001571996-23-000019:mdna:229]
[same as prior period, unchanged from 0001571996-22-000044:mdna:262]

[0001571996-23-000019:mdna:230]
|  | May 5, 2023 |  | February 3, 2023 |
|  | (in millions) |
| ASSETS |
| Current assets | $ | 1,986 |  |  | $ | 2,972 |  |
| Intercompany receivables | 69 |  |  | 595 |  |
| Due from related party, net | 307 |  |  | 312 |  |
| Short-term intercompany loan receivables | 128 |  |  | 227 |  |
| Total current assets | 2,490 |  |  | 4,106 |  |
| Due from related party, net | 442 |  |  | 440 |  |
| Goodwill and intangible assets | 14,707 |  |  | 14,818 |  |
| Other non-current assets | 3,029 |  |  | 3,009 |  |
| Total assets | $ | 20,668 |  |  | $ | 22,373 |  |
| LIABILITIES |
| Current liabilities | $ | 5,244 |  |  | $ | 6,611 |  |
| Due to related party | 52 |  |  | 110 |  |
| Total current liabilities | 5,296 |  |  | 6,721 |  |
| Long-term debt | 17,960 |  |  | 17,996 |  |
| Intercompany loan payables | 38,907 |  |  | 38,896 |  |
| Other non-current liabilities | 3,717 |  |  | 3,891 |  |
| Total liabilities | $ | 65,880 |  |  | $ | 67,504 |  |

[0001571996-23-000019:mdna:231]
81
