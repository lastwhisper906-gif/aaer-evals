# DELL note change history — 0001571996-22-000044 → 0001571996-23-000019


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-06-12):
[0001571996-23-000019:note_history:1]
COMMITMENTS AND CONTINGENCIES 
Legal Matters
  (was, 2022-12-05, similarity 0.7527):
[0001571996-22-000044:note_history:1]
COMMITMENTS AND CONTINGENCIES 
Purchase Obligations

- changed (2023-06-12):
[0001571996-23-000019:note_history:2]
The Company is involved in various claims, suits, assessments, investigations, and legal proceedings that arise from time to time in the ordinary course of its business, including those identified below, consisting of matters involving consumer, antitrust, tax, intellectual property, and other issues on a global basis.
  (was, 2022-12-05, similarity 0.7018):
[0001571996-22-000044:note_history:2]
The Company is involved in various claims, suits, assessments, investigations, and legal proceedings that arise from time to time in the ordinary course of its business, including those identified below, consisting of matters involving consumer, antitrust, tax, intellectual property, and other issues on a global basis.  Pursuant to the Separation and Distribution Agreement referred to below, Dell Technologies shares responsibility with VMware for certain matters, as indicated below, and VMware has agreed to indemnify Dell Technologies in whole or in part with respect to certain matters.

- added (2023-06-12):
[0001571996-23-000019:note_history:3]
Class Actions Related to the Class V Transaction — On December 28, 2018, the Company completed a transaction (the “Class V transaction”) in which it paid $14.0 billion in cash and issued 149,387,617 shares of its Class C Common Stock to holders of its Class V Common Stock in exchange for all outstanding shares of Class V Common Stock.  As a result of the Class V transaction, the tracking stock feature of the Company’s capital structure associated with the Class V Common Stock was terminated.  Certain stockholders of the Company, subsequently brought class action complaints arising out of the Class V transaction in which they named as defendants (collectively, the “defendants”) Michael S. Dell and certain other directors serving on the Company’s board of directors at the time of the Class V transaction (collectively, the “director defendants”), certain stockholders of the Company, consisting of Mr. Dell and Silver Lake Group LLC and certain of its affiliated funds (collectively, the “stockholder defendants”), and Goldman Sachs & Co. LLC (“Goldman Sachs”), which served as financial advisor to the Company in connection with the transaction.  The plaintiffs generally alleged that the director defendants and the stockholder defendants breached their fiduciary duties under Delaware law to the former holders of the Class V common stock in connection with the Class V transaction by offering a transaction value that was allegedly billions of dollars below fair value.

- added (2023-06-12):
[0001571996-23-000019:note_history:4]
As previously reported, during the fourth quarter of Fiscal 2023, the plaintiffs and the defendants entered into an agreement to settle the lawsuit. Under the terms of the settlement, the plaintiffs agreed to the dismissal of all claims upon payment of a total of $1.0 billion (the “settlement amount”), which includes all costs, expenses and fees of the plaintiff class relating to the action and its resolution. The settlement terms required that the settlement amount be paid by the Company and/or the Company’s insurers pursuant to indemnification obligations of the Company to the defendants. The Company is subject to indemnification obligations, upon the satisfaction of specified conditions, to the director and stockholder defendants and their affiliates pursuant to provisions of the Delaware General Corporation Law, the Company’s certificate of incorporation and bylaws, and agreements with the defendants. A special committee of the Board consisting of directors who were not defendants in the action, advised by independent counsel, informed the Board of its determination that the defendants are entitled to indemnification under the foregoing obligations.

- added (2023-06-12):
[0001571996-23-000019:note_history:5]
During Fiscal 2023, the Company established a $1.0 billion liability on the Consolidated Statements of Financial Position and recognized $0.9 billion expense, net of $106 million in insurance proceeds, within interest and other, net within the Consolidated Statements of Income related to the settlement agreement.  The Company accounted for the expected insurance proceeds as a loss recovery and recognized a benefit within interest and other, net within the Condensed Consolidated Statements of Income and corresponding receivable on the Condensed Consolidated Statements of Financial Position.  On May 16, 2023, subsequent to the close of the three months ended May 5, 2023, the Company paid the settlement amount following approval of the settlement by the Delaware Court of Chancery.  The Company does not expect to incur additional expenses with respect to the settlement.

- changed (2023-06-12):
[0001571996-23-000019:note_history:6]
In accordance with the relevant accounting guidance, the Company provides disclosures of matters where it is at least reasonably possible that the Company could experience a material loss exceeding the amounts already accrued for these or other proceedings or matters.  In addition, the Company also discloses matters based on its consideration of other matters and qualitative factors, including the experience of other companies in the industry, and investor, customer, and employee relations considerations.  As of May 5, 2023, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for these or other proceedings or matters has been incurred.  However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company’s business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters.  Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company’s business, financial condition, results of operations, or cash flows will depend on a number of factors, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.
  (was, 2022-12-05, similarity 0.9965):
[0001571996-22-000044:note_history:6]
In accordance with the relevant accounting guidance, the Company provides disclosures of matters where it is at least reasonably possible that the Company could experience a material loss exceeding the amounts already accrued for these or other proceedings or matters.  In addition, the Company also discloses matters based on its consideration of other matters and qualitative factors, including the experience of other companies in the industry, and investor, customer, and employee relations considerations.  As of October 28, 2022, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for these or other proceedings or matters has been incurred.  However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company’s business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters.  Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company’s business, financial condition, results of operations, or cash flows will depend on a number of factors, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.

- changed (2023-06-12):
[0001571996-23-000019:note_history:7]
Under the Separation and Distribution Agreement entered into with VMware, Inc. upon the completion of the spin-off of VMware, Inc. by means of a special stock dividend (the “VMware Spin-off”), Dell Technologies has agreed to indemnify VMware, Inc., each of its subsidiaries and each of their respective directors, officers, and employees from and against all liabilities relating to, arising out of or resulting from, among other matters, the liabilities allocated to Dell Technologies as part of the separation of Dell Technologies and VMware, Inc. (individually and together with its subsidiaries, “VMware”) and their respective businesses (the “Separation”). VMware similarly has agreed to indemnify Dell Technologies Inc., each of its subsidiaries and each of their respective directors, officers, and employees from and against all liabilities relating to, arising out of or resulting from, among other matters, the liabilities allocated to VMware as part of the Separation.  Dell Technologies expects VMware to fully perform under the terms of the Separation and Distribution Agreement.
  (was, 2022-12-05, similarity 0.7291):
[0001571996-22-000044:note_history:7]
Under the Separation and Distribution Agreement described in Note 2 of the Notes to the Condensed Consolidated Financial Statements, Dell Technologies has agreed to indemnify VMware, Inc., each of its subsidiaries and each of their respective directors, officers, and employees from and against all liabilities relating to, arising out of or resulting from, among other matters, the liabilities allocated to Dell Technologies as part of the separation of  Dell Technologies and VMware and their respective businesses as a result of the VMware Spin-off (the “Separation”).  VMware similarly has agreed to indemnify Dell Technologies Inc., each of its subsidiaries and each of their respective directors, officers, and employees from and against all liabilities relating to, arising out of or resulting from, among other matters, the liabilities allocated to VMware as part of the Separation.  Dell Technologies expects VMware to fully perform under the terms of the Separation and Distribution Agreement.
For information on the cross-indemnifications related to the tax matters agreement between the Company and VMware described in Note 2 of the Notes to the Condensed Consolidated Financial Statements effective upon the Separation on November 1, 2021, see Note 2 and Note 16 of the Notes to the Condensed Consolidated Financial Statements.

- added (2023-06-12):
[0001571996-23-000019:note_history:8]
For information on the cross-indemnifications related to the tax matters agreement between the Company and VMware effective upon the Separation on November 1, 2021, see Note 15 of the Notes to the Condensed Consolidated Financial Statements.

- removed (2023-06-12):
[0001571996-22-000044:note_history:9]
The Company has contractual obligations to purchase goods or services, which specify significant terms (including fixed or minimum quantities to be purchased), fixed, minimum, or variable price provisions; and the approximate timing of the transaction.  As of October 28, 2022, such purchase obligations were $2.7 billion, $0.6 billion, and $0.8 billion for the remaining three months of Fiscal 2023, Fiscal 2024, and Fiscal 2025 and thereafter, respectively.

- removed (2023-06-12):
[0001571996-22-000044:note_history:10]
Legal Matters

- removed (2023-06-12):
[0001571996-22-000044:note_history:11]
Class Actions Related to the Class V Transaction — On December 28, 2018, the Company completed a transaction (the “Class V transaction”) in which it paid $14.0 billion in cash and issued 149,387,617 shares of its Class C Common Stock to holders of its Class V Common Stock in exchange for all outstanding shares of Class V Common Stock.  As a result of the Class V transaction, the tracking stock feature of the Company’s capital structure associated with the Class V Common Stock was terminated.  In November 2018, four purported stockholders brought putative class action complaints arising out of the Class V transaction.  The actions were captioned Hallandale Beach Police and Fire Retirement Plan v. Michael Dell et al. (Civil Action No. 2018-0816-JTL), Howard Karp v. Michael Dell et al. (Civil Action No. 2019-0032-JTL), Miramar Police Officers’ Retirement Plan v. Michael Dell et al. (Civil Action No. 2019-0049-JTL), and Steamfitters Local 449 Pension Plan v. Michael Dell et al. (Civil Action No. 2019-0115-JTL).  The four actions were consolidated in the Delaware Chancery Court into In Re Dell Class V Litigation (Consol. C.A. No. 2018-0816-JTL).  The suit currently names as defendants Michael S. Dell and certain of the other directors serving on the Board of Directors at the time of the Class V transaction, certain stockholders of the Company, consisting of Michael S. Dell and Silver Lake Group LLC and certain of its affiliated funds, and Goldman Sachs & Co. LLC (“Goldman Sachs”), which served as financial advisor to the Company in connection with the Class V transaction.  In an amended complaint filed in August 2019, the plaintiffs generally allege that the director and stockholder defendants breached their fiduciary duties under Delaware law to the former holders of Class V Common Stock in connection with the Class V transaction by offering a transaction value that was allegedly billions of dollars below the fair value.  The plaintiffs contend that the offer understated the value of shares surrendered by the former stockholders, which the plaintiffs allege should have reflected higher alternative valuations, including a valuation related to the value of the shares of VMware, Inc. common stock, and that the difference in values was wrongfully appropriated by the stockholder defendants.  On August 20, 2021, the plaintiffs added Goldman Sachs as a defendant and allege that it aided and abetted the alleged primary violations.  In the complaint, the plaintiffs seek, among other remedies, a judicial declaration that the director and stockholder defendants breached their fiduciary duties.  The plaintiffs also seek in the complaint disgorgement of all profits, benefits, and other compensation obtained by the defendants as a result of such alleged conduct and an award of unspecified damages, fees, and costs.  The defendants filed a motion to dismiss the action in September 2019.  The court denied the motion in June 2020.  Trial was scheduled to begin on December 5, 2022.  The Company is not a defendant in this action but is subject to director indemnification provisions under its certificate of incorporation and bylaws, and is a party to agreements with the defendants that contain indemnification

- removed (2023-06-12):
[0001571996-22-000044:note_history:12]
obligations of the Company, conditioned on the satisfaction of the requirements set forth in such agreements, relating to service as a director, ownership of the Company’s securities, and provision of services, as applicable.  As described in Note 19 of the Notes to the Condensed Consolidated Financial Statements, the plaintiffs and the defendants agreed to settle this action, subject to court approval, subsequent to October 28, 2022.

- removed (2023-06-12):
[0001571996-22-000044:note_history:13]
Class Actions Related to VMware, Inc.’s Acquisition of Pivotal Software, Inc. — Two purported stockholders brought putative class action complaints arising out of VMware, Inc.’s acquisition of Pivotal Software, Inc. (“Pivotal”) on December 30, 2019.  The two actions were consolidated in the Delaware Chancery Court into In re: Pivotal Software, Inc. Stockholders Litigation (Civil Action No. 2020-0440-KSJM).  The complaint names as defendants the Company, VMware, Inc., Michael S. Dell, and certain officers of Pivotal.  The plaintiffs generally allege that the defendants breached their fiduciary duties to the former holders of Pivotal Class A Common Stock in connection with VMware, Inc.’s acquisition of Pivotal by allegedly causing Pivotal to enter into a transaction that favored the interests of Pivotal’s controlling stockholders at the expense of such former stockholders.  The parties reached a settlement on June 2, 2022, subject to court approval.  On October 4, 2022, the court entered a final order and judgment approving the settlement.


## dell:CreditLossFinancialInstrumentLeasesDebtVariableInterestEntitiesAndCustomerReceivablesSalesTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2023-06-12):
[0001571996-23-000019:note_history:14]
FINANCIAL SERVICES
The Company offers or arranges various financing options and alternative payment structures for its customers globally.  Alternative payment structures consist of various flexible consumption models, including utility, subscription, and as-a-Service models.

- changed (2023-06-12):
[0001571996-23-000019:note_history:15]
Financing options are offered to our customers primarily through Dell Financial Services and its affiliates (“DFS”).  The Company also arranges financing for some of its customers in various countries where DFS does not currently operate as a captive enterprise.  The key activities of DFS include originating, collecting, and servicing customer financing arrangements primarily related to the purchase or use of Dell Technologies products and services.  In some cases, DFS also offers financing for the purchase of third-party technology products that complement the Dell Technologies portfolio of products and services.  New financing originations were $1.8 billion and $2.1 billion for the three months ended May 5, 2023 and April 29, 2022, respectively.
  (was, 2022-12-05, similarity 0.8102):
[0001571996-22-000044:note_history:15]
FINANCIAL SERVICES
The Company offers or arranges various financing options and services and alternative payment structures for its customers globally primarily through Dell Financial Services and its affiliates (“DFS”).  The Company also arranges financing for some of its customers in various countries where DFS does not currently operate as a captive enterprise.  The key activities of DFS include originating, collecting, and servicing customer financing arrangements primarily related to the purchase or use of Dell Technologies products and services.  In some cases, DFS also offers financing for the purchase of third-party technology products that complement the Dell Technologies portfolio of products and services.  New financing originations were $2.3 billion and $2.0 billion for the three months ended October 28, 2022 and October 29, 2021, respectively, and $6.7 billion and $5.8 billion for the nine months ended October 28, 2022 and October 29, 2021, respectively.

- added (2023-06-12):
[0001571996-23-000019:note_history:16]
Flexible consumption models, as defined above, enable the Company to offer its customers the option to pay over time to provide them with financial flexibility to meet their changing technological requirements.  Such models may result in identification of embedded lease arrangements that lead to the recognition of operating or sales-type leases.

- changed (2023-06-12):
[0001571996-23-000019:note_history:17]
|  | May 5, 2023 |  | February 3, 2023 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Financing receivables, net: |  |  |  |  |  |  |  |  |  |  |  |
| Customer receivables, gross (a) | $ | 658 |  |  | $ | 9,951 |  |  | $ | 10,609 |  |  | $ | 685 |  |  | $ | 10,293 |  |  | $ | 10,978 |  |
| Allowances for losses | (84) |  |  | (135) |  |  | (219) |  |  | (88) |  |  | (113) |  |  | (201) |  |
| Customer receivables, net | 574 |  |  | 9,816 |  |  | 10,390 |  |  | 597 |  |  | 10,180 |  |  | 10,777 |  |
| Residual interest | — |  |  | 147 |  |  | 147 |  |  | — |  |  | 142 |  |  | 142 |  |
| Financing receivables, net | $ | 574 |  |  | $ | 9,963 |  |  | $ | 10,537 |  |  | $ | 597 |  |  | $ | 10,322 |  |  | $ | 10,919 |  |
| Short-term | $ | 574 |  |  | $ | 4,439 |  |  | $ | 5,013 |  |  | $ | 597 |  |  | $ | 4,684 |  |  | $ | 5,281 |  |
| Long-term | $ | — |  |  | $ | 5,524 |  |  | $ | 5,524 |  |  | $ | — |  |  | $ | 5,638 |  |  | $ | 5,638 |  |
  (was, 2022-12-05, similarity 0.9791):
[0001571996-22-000044:note_history:17]
|  | October 28, 2022 |  | January 28, 2022 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Financing receivables, net: |  |  |  |  |  |  |  |  |  |  |  |
| Customer receivables, gross (a) | $ | 685 |  |  | $ | 9,938 |  |  | $ | 10,623 |  |  | $ | 750 |  |  | $ | 9,833 |  |  | $ | 10,583 |  |
| Allowances for losses | (87) |  |  | (99) |  |  | (186) |  |  | (102) |  |  | (87) |  |  | (189) |  |
| Customer receivables, net | 598 |  |  | 9,839 |  |  | 10,437 |  |  | 648 |  |  | 9,746 |  |  | 10,394 |  |
| Residual interest | — |  |  | 137 |  |  | 137 |  |  | — |  |  | 217 |  |  | 217 |  |
| Financing receivables, net | $ | 598 |  |  | $ | 9,976 |  |  | $ | 10,574 |  |  | $ | 648 |  |  | $ | 9,963 |  |  | $ | 10,611 |  |
| Short-term | $ | 598 |  |  | $ | 4,317 |  |  | $ | 4,915 |  |  | $ | 648 |  |  | $ | 4,441 |  |  | $ | 5,089 |  |
| Long-term | $ | — |  |  | $ | 5,659 |  |  | $ | 5,659 |  |  | $ | — |  |  | $ | 5,522 |  |  | $ | 5,522 |  |

- changed (2023-06-12):
[0001571996-23-000019:note_history:18]
(a)    Customer receivables, gross include amounts due from customers under revolving loans, fixed-term loans, fixed-term leases, and accrued interest.
  (was, 2022-12-05, similarity 0.9052):
[0001571996-22-000044:note_history:18]
(a)    Customer receivables, gross include amounts due from customers under revolving loans, fixed-term loans, fixed-term sales-type or direct financing leases, and accrued interest.

- added (2023-06-12):
[0001571996-23-000019:note_history:19]
|  | Three Months Ended |
|  | May 5, 2023 |  | April 29, 2022 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |  |  |  |  |  |  |  |  |  |  |  |
| Balances at beginning of period | $ | 88 |  |  | $ | 113 |  |  | $ | 201 |  |  | $ | 102 |  |  | $ | 87 |  |  | $ | 189 |  |
| Charge-offs, net of recoveries | (17) |  |  | (1) |  |  | (18) |  |  | (13) |  |  | (2) |  |  | (15) |  |
| Provision charged to income statement | 13 |  |  | 23 |  |  | 36 |  |  | 5 |  |  | 2 |  |  | 7 |  |
| Balances at end of period | $ | 84 |  |  | $ | 135 |  |  | $ | 219 |  |  | $ | 94 |  |  | $ | 87 |  |  | $ | 181 |  |

- added (2023-06-12):
[0001571996-23-000019:note_history:20]
The Company recognizes an allowance for financing receivable losses, including both the lease receivable and unguaranteed residual, in an amount equal to the expected losses net of recoveries.  The allowance for financing receivable losses on the lease receivable is determined based on various factors, including lifetime expected losses determined using macroeconomic forecast assumptions and management judgments applicable to and through the expected life of the portfolios as well as past due receivables, receivable type, and customer risk profile.  The Company continues to monitor broader economic indicators and their potential impact on future credit loss performance.

- changed (2023-06-12):
[0001571996-23-000019:note_history:21]
|  | May 5, 2023 |  | February 3, 2023 |
|  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |
|  | (in millions) |
| Revolving — DPA | $ | 433 |  |  | $ | 33 |  |  | $ | 16 |  |  | $ | 482 |  |  | $ | 457 |  |  | $ | 34 |  |  | $ | 17 |  |  | $ | 508 |  |
| Revolving — DBC | 153 |  |  | 19 |  |  | 4 |  |  | 176 |  |  | 154 |  |  | 19 |  |  | 4 |  |  | 177 |  |
| Fixed-term — Consumer and Commercial | 9,128 |  |  | 743 |  |  | 80 |  |  | 9,951 |  |  | 9,309 |  |  | 927 |  |  | 57 |  |  | 10,293 |  |
| Total customer receivables, gross | $ | 9,714 |  |  | $ | 795 |  |  | $ | 100 |  |  | $ | 10,609 |  |  | $ | 9,920 |  |  | $ | 980 |  |  | $ | 78 |  |  | $ | 10,978 |  |
  (was, 2022-12-05, similarity 0.9731):
[0001571996-22-000044:note_history:21]
|  | October 28, 2022 |  | January 28, 2022 |
|  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |
|  | (in millions) |
| Revolving — DPA | $ | 444 |  |  | $ | 42 |  |  | $ | 15 |  |  | $ | 501 |  |  | $ | 520 |  |  | $ | 40 |  |  | $ | 11 |  |  | $ | 571 |  |
| Revolving — DBC | 165 |  |  | 16 |  |  | 3 |  |  | 184 |  |  | 158 |  |  | 18 |  |  | 3 |  |  | 179 |  |
| Fixed-term — Consumer and Commercial | 9,524 |  |  | 391 |  |  | 23 |  |  | 9,938 |  |  | 9,444 |  |  | 345 |  |  | 44 |  |  | 9,833 |  |
| Total customer receivables, gross | $ | 10,133 |  |  | $ | 449 |  |  | $ | 41 |  |  | $ | 10,623 |  |  | $ | 10,122 |  |  | $ | 403 |  |  | $ | 58 |  |  | $ | 10,583 |  |

- added (2023-06-12):
[0001571996-23-000019:note_history:22]
Fixed-term consumer and commercial customer receivables are placed on non-accrual status if principal or interest is past due and considered delinquent, or if there is concern about the collectibility of a specific customer receivable.  The receivables identified as doubtful for collectibility may be classified as current for aging purposes.  Aged revolving portfolio customer receivables identified as delinquent are charged off.

- changed (2023-06-12):
[0001571996-23-000019:note_history:23]
The following tables present customer receivables, gross, including accrued interest, by credit quality indicator, segregated by class, as of the dates indicated:
  (was, 2022-12-05, similarity 0.9969):
[0001571996-22-000044:note_history:23]
The following tables present customer receivables, gross, including accrued interest, by credit quality indicator segregated by class, as of the dates indicated:

- changed (2023-06-12):
[0001571996-23-000019:note_history:24]
|  | May 5, 2023 |
|  | Fixed-term — Consumer and Commercial |  |  |  |  |  |  |
|  | Fiscal Year of Origination |  |  |  |  |  |  |
|  | 2024 |  | 2023 |  | 2022 |  | 2021 |  | 2020 |  | Years Prior |  | Revolving — DPA |  | Revolving — DBC |  | Total |
|  | (in millions) |
| Higher | $ | 931 |  |  | $ | 2,640 |  |  | $ | 1,484 |  |  | $ | 716 |  |  | $ | 259 |  |  | $ | 18 |  |  | $ | 113 |  |  | $ | 43 |  |  | $ | 6,204 |  |
| Mid | 410 |  |  | 1,274 |  |  | 536 |  |  | 270 |  |  | 84 |  |  | 9 |  |  | 130 |  |  | 53 |  |  | 2,766 |  |
| Lower | 198 |  |  | 660 |  |  | 296 |  |  | 117 |  |  | 42 |  |  | 7 |  |  | 239 |  |  | 80 |  |  | 1,639 |  |
| Total | $ | 1,539 |  |  | $ | 4,574 |  |  | $ | 2,316 |  |  | $ | 1,103 |  |  | $ | 385 |  |  | $ | 34 |  |  | $ | 482 |  |  | $ | 176 |  |  | $ | 10,609 |  |
  (was, 2022-12-05, similarity 0.992):
[0001571996-22-000044:note_history:24]
|  | October 28, 2022 |
|  | Fixed-term — Consumer and Commercial |  |  |  |  |  |  |
|  | Fiscal Year of Origination |  |  |  |  |  |  |
|  | 2023 |  | 2022 |  | 2021 |  | 2020 |  | 2019 |  | Years Prior |  | Revolving — DPA |  | Revolving — DBC |  | Total |
|  | (in millions) |
| Higher | $ | 2,504 |  |  | $ | 2,055 |  |  | $ | 1,086 |  |  | $ | 447 |  |  | $ | 70 |  |  | $ | 2 |  |  | $ | 124 |  |  | $ | 49 |  |  | $ | 6,337 |  |
| Mid | 946 |  |  | 691 |  |  | 450 |  |  | 154 |  |  | 30 |  |  | 2 |  |  | 144 |  |  | 54 |  |  | 2,471 |  |
| Lower | 791 |  |  | 416 |  |  | 199 |  |  | 81 |  |  | 12 |  |  | 2 |  |  | 233 |  |  | 81 |  |  | 1,815 |  |
| Total | $ | 4,241 |  |  | $ | 3,162 |  |  | $ | 1,735 |  |  | $ | 682 |  |  | $ | 112 |  |  | $ | 6 |  |  | $ | 501 |  |  | $ | 184 |  |  | $ | 10,623 |  |

- changed (2023-06-12):
[0001571996-23-000019:note_history:25]
|  | February 3, 2023 |
|  | Fixed-term — Consumer and Commercial |  |  |  |  |  |  |
|  | Fiscal Year of Origination |  |  |  |  |  |  |
|  | 2023 |  | 2022 |  | 2021 |  | 2020 |  | 2019 |  | Years Prior |  | Revolving — DPA |  | Revolving — DBC |  | Total |
|  | (in millions) |
| Higher | $ | 3,210 |  |  | $ | 1,805 |  |  | $ | 914 |  |  | $ | 343 |  |  | $ | 37 |  |  | $ | 1 |  |  | $ | 123 |  |  | $ | 44 |  |  | $ | 6,477 |  |
| Mid | 1,242 |  |  | 631 |  |  | 362 |  |  | 119 |  |  | 17 |  |  | 1 |  |  | 136 |  |  | 54 |  |  | 2,562 |  |
| Lower | 1,017 |  |  | 364 |  |  | 157 |  |  | 65 |  |  | 7 |  |  | 1 |  |  | 249 |  |  | 79 |  |  | 1,939 |  |
| Total | $ | 5,469 |  |  | $ | 2,800 |  |  | $ | 1,433 |  |  | $ | 527 |  |  | $ | 61 |  |  | $ | 3 |  |  | $ | 508 |  |  | $ | 177 |  |  | $ | 10,978 |  |
  (was, 2022-12-05, similarity 0.9912):
[0001571996-22-000044:note_history:25]
|  | January 28, 2022 |
|  | Fixed-term — Consumer and Commercial |  |  |  |  |  |  |
|  | Fiscal Year of Origination |  |  |  |  |  |  |
|  | 2022 |  | 2021 |  | 2020 |  | 2019 |  | 2018 |  | Years Prior |  | Revolving — DPA |  | Revolving — DBC |  | Total |
|  | (in millions) |
| Higher | $ | 3,279 |  |  | $ | 1,824 |  |  | $ | 914 |  |  | $ | 221 |  |  | $ | 25 |  |  | $ | 3 |  |  | $ | 150 |  |  | $ | 46 |  |  | $ | 6,462 |  |
| Mid | 1,071 |  |  | 751 |  |  | 329 |  |  | 94 |  |  | 17 |  |  | — |  |  | 166 |  |  | 57 |  |  | 2,485 |  |
| Lower | 599 |  |  | 450 |  |  | 208 |  |  | 42 |  |  | 6 |  |  | — |  |  | 255 |  |  | 76 |  |  | 1,636 |  |
| Total | $ | 4,949 |  |  | $ | 3,025 |  |  | $ | 1,451 |  |  | $ | 357 |  |  | $ | 48 |  |  | $ | 3 |  |  | $ | 571 |  |  | $ | 179 |  |  | $ | 10,583 |  |

- changed (2023-06-12):
[0001571996-23-000019:note_history:26]
For DPA revolving receivables shown in the table above, the Company makes credit decisions based on proprietary scorecards, which include the customer’s credit history, payment history, credit usage, and other credit agency-related elements.  The higher quality category includes prime accounts generally comparable to U.S. customer FICO scores of 720 or above.  The mid category represents the mid-tier accounts that are comparable to U.S. customer FICO scores from 660 to 719.  The lower category is generally sub-prime and represents accounts that are comparable to U.S. customer FICO scores below 660.  For the DBC revolving receivables and fixed-term commercial receivables shown in the table above, an internal grading system is utilized that assigns a credit level score based on a number of considerations, including liquidity, operating performance, and industry outlook.  The grading criteria and classifications for the fixed-term products differ from those for the revolving products as loss experience varies between these product and customer groups.  The credit quality categories cannot be compared between the different classes as loss experience varies substantially between the classes.
  (was, 2022-12-05, similarity 0.9766):
[0001571996-22-000044:note_history:26]
For DPA revolving receivables shown in the table above, the Company makes credit decisions based on proprietary scorecards, which include the customer’s credit history, payment history, credit usage, and other credit agency-related elements.  The higher quality category includes prime accounts generally of a higher credit quality that are comparable to U.S. customer FICO scores of 720 or above.  The mid category represents the mid-tier accounts that are comparable to U.S. customer FICO scores from 660 to 719.  The lower category is generally sub-prime and represents lower credit quality accounts that are comparable to U.S. customer FICO scores below 660.  For the DBC revolving receivables and fixed-term commercial receivables shown in the table above, an internal grading system is utilized that assigns a credit level score based on a number of considerations, including liquidity, operating performance, and industry outlook.  The grading criteria and classifications for the fixed-term products differ from those for the revolving products as loss experience varies between these product and customer groups.  The credit quality categories cannot be compared between the different classes as loss experience varies substantially between the classes.

- added (2023-06-12):
[0001571996-23-000019:note_history:27]
|  |  |  | Three Months Ended |
|  |  |  |  |  | May 5, 2023 |  | April 29, 2022 |
|  |  |  |  |  | (in millions) |
| Net revenue — products |  |  |  |  | $ | 247 |  |  | $ | 220 |  |
| Cost of net revenue — products |  |  |  |  | 196 |  |  | 204 |  |
| Gross margin — products |  |  |  |  | $ | 51 |  |  | $ | 16 |  |

- changed (2023-06-12):
[0001571996-23-000019:note_history:28]
The following table presents the future maturity of the Company’s fixed-term customer leases and associated financing payments, and reconciles the undiscounted cash flows to the customer receivables, gross recognized on the Condensed Consolidated Statement of Financial Position as of the date indicated:
  (was, 2022-12-05, similarity 0.9984):
[0001571996-22-000044:note_history:28]
The following table presents the future maturity of the Company’s fixed-term customer leases and associated financing payments, and reconciles the undiscounted cash flows to the customer receivables, gross recognized on the Condensed Consolidated Statements of Financial Position as of the date indicated:

- changed (2023-06-12):
[0001571996-23-000019:note_history:29]
|  | May 5, 2023 |
|  | (in millions) |
| Fiscal 2024 (remaining nine months) | $ | 1,997 |  |
| Fiscal 2025 | 1,894 |  |
| Fiscal 2026 | 1,361 |  |
| Fiscal 2027 | 659 |  |
| Fiscal 2028 and beyond | 178 |  |
| Total undiscounted cash flows | 6,089 |  |
| Fixed-term loans | 4,640 |  |
| Revolving loans | 658 |  |
| Less: Unearned income | (778) |  |
| Total customer receivables, gross | $ | 10,609 |  |
  (was, 2022-12-05, similarity 0.6779):
[0001571996-22-000044:note_history:29]
|  | October 28, 2022 |
|  | (in millions) |
| Fiscal 2023 (remaining three months) | $ | 287 |  |
| Fiscal 2024 | 865 |  |
| Fiscal 2025 | 604 |  |
| Fiscal 2026 | 256 |  |
| Fiscal 2027 and beyond | 65 |  |
| Total | $ | 2,077 |  |

- added (2023-06-12):
[0001571996-23-000019:note_history:30]
The Company’s operating leases primarily consist of DFS captive fixed-term leases and contractually committed embedded leases identified within flexible consumption arrangements.

- changed (2023-06-12):
[0001571996-23-000019:note_history:31]
|  | May 5, 2023 |  | February 3, 2023 |
|  | (in millions) |
| Equipment under operating lease, gross | $ | 3,817 |  |  | $ | 3,725 |  |
| Less: Accumulated depreciation | (1,634) |  |  | (1,517) |  |
| Equipment under operating lease, net | $ | 2,183 |  |  | $ | 2,208 |  |
  (was, 2022-12-05, similarity 0.9118):
[0001571996-22-000044:note_history:31]
|  | October 28, 2022 |  | January 28, 2022 |
|  | (in millions) |
| Equipment under operating lease, gross | $ | 3,417 |  |  | $ | 2,643 |  |
| Less: Accumulated depreciation | (1,336) |  |  | (935) |  |
| Equipment under operating lease, net | $ | 2,081 |  |  | $ | 1,708 |  |

- added (2023-06-12):
[0001571996-23-000019:note_history:32]
|  |  |  | Three Months Ended |
|  |  |  |  |  | May 5, 2023 |  | April 29, 2022 |
|  |  |  |  |  | (in millions) |
| Income related to lease payments |  |  |  |  | $ | 321 |  |  | $ | 232 |  |
| Depreciation expense |  |  |  |  | $ | 233 |  |  | $ | 165 |  |

- added (2023-06-12):
[0001571996-23-000019:note_history:33]
|  | May 5, 2023 |
|  | (in millions) |
| Fiscal 2024 (remaining nine months) | $ | 862 |  |
| Fiscal 2025 | 824 |  |
| Fiscal 2026 | 460 |  |
| Fiscal 2027 | 141 |  |
| Fiscal 2028 and beyond | 46 |  |
| Total | $ | 2,333 |  |

- changed (2023-06-12):
[0001571996-23-000019:note_history:34]
|  | May 5, 2023 |  | February 3, 2023 |
| DFS debt | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing and securitization facilities | $ | 3,326 |  |  | $ | 3,987 |  |
| Fixed-term securitization offerings | 3,192 |  |  | 2,679 |  |
| Other | 67 |  |  | 76 |  |
| Total DFS U.S. debt | 6,585 |  |  | 6,742 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 818 |  |  | 790 |  |
| Other borrowings | 852 |  |  | 871 |  |
| Note payable | 250 |  |  | 250 |  |
| Dell Bank senior unsecured eurobonds | 1,652 |  |  | 1,637 |  |
| Total DFS international debt | 3,572 |  |  | 3,548 |  |
| Total DFS debt | $ | 10,157 |  |  | $ | 10,290 |  |
| Total short-term DFS debt | $ | 5,232 |  |  | $ | 5,400 |  |
| Total long-term DFS debt | $ | 4,925 |  |  | $ | 4,890 |  |
  (was, 2022-12-05, similarity 0.9738):
[0001571996-22-000044:note_history:34]
|  | October 28, 2022 |  | January 28, 2022 |
| DFS debt | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing and securitization facilities | $ | 3,226 |  |  | $ | 3,054 |  |
| Fixed-term securitization offerings | 3,302 |  |  | 3,011 |  |
| Other | 87 |  |  | 135 |  |
| Total DFS U.S. debt | 6,615 |  |  | 6,200 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 688 |  |  | 739 |  |
| Other borrowings | 1,004 |  |  | 785 |  |
| Note payable | 250 |  |  | 250 |  |
| Dell Bank senior unsecured eurobonds | 1,494 |  |  | 1,672 |  |
| Total DFS international debt | 3,436 |  |  | 3,446 |  |
| Total DFS debt | $ | 10,051 |  |  | $ | 9,646 |  |
| Total short-term DFS debt | $ | 5,626 |  |  | $ | 5,803 |  |
| Total long-term DFS debt | $ | 4,425 |  |  | $ | 3,843 |  |

- changed (2023-06-12):
[0001571996-23-000019:note_history:35]
Asset-Based Financing and Securitization Facilities — The Company maintains separate asset-based financing facilities and a securitization facility in the United States, which are revolving facilities for fixed-term leases and loans and for revolving loans, respectively.  This debt is collateralized solely by the U.S. loan and lease payments and associated equipment in the facilities.  The debt has a variable interest rate and the duration of the debt is based on the terms of the underlying loan and lease payment streams.  As of May 5, 2023, the total debt capacity related to the U.S. asset-based financing and securitization facilities was $5.6 billion.  The Company enters into interest swap agreements to effectively convert a portion of this debt from a floating rate to a fixed rate.  See Note 7 of the Notes to the Condensed Consolidated Financial Statements for additional information about interest rate swaps.
  (was, 2022-12-05, similarity 0.994):
[0001571996-22-000044:note_history:35]
Asset-Based Financing and Securitization Facilities — The Company maintains separate asset-based financing facilities and a securitization facility in the United States, which are revolving facilities for fixed-term leases and loans and for revolving loans, respectively.  This debt is collateralized solely by the U.S. loan and lease payments and associated equipment in the facilities.  The debt has a variable interest rate, and the duration of the debt is based on the terms of the underlying loan and lease payment streams.  As of October 28, 2022, the total debt capacity related to the U.S. asset-based financing and securitization facilities was $5.0 billion.  The Company enters into interest swap agreements to effectively convert a portion of this debt from a floating rate to a fixed rate.  See Note 8 of the Notes to the Condensed Consolidated Financial Statements for additional information about interest rate swaps.

- changed (2023-06-12):
[0001571996-23-000019:note_history:36]
The Company’s U.S. securitization facility for revolving loans is effective through June 25, 2025.  The Company’s two U.S. asset-based financing facilities for fixed-term leases and loans are effective through July 10, 2023 and June 21, 2024, respectively.  The Company intends to extend the facility currently effective through July 10, 2023 during the second quarter of Fiscal 2024.
  (was, 2022-12-05, similarity 0.8013):
[0001571996-22-000044:note_history:36]
The Company’s U.S. securitization facility for revolving loans is effective through June 25, 2025.  The Company’s two U.S. asset-based financing facilities for fixed-term leases and loans are effective through July 10, 2023 and June 21, 2024, respectively.

- changed (2023-06-12):
[0001571996-23-000019:note_history:37]
The asset-based financing and securitization facilities contain standard structural features related to the performance of the funded receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the facility, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of May 5, 2023, these criteria were met.
  (was, 2022-12-05, similarity 0.991):
[0001571996-22-000044:note_history:37]
The asset-based financing and securitization facilities contain standard structural features related to the performance of the funded receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the facility, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of October 28, 2022, these criteria were met.

- changed (2023-06-12):
[0001571996-23-000019:note_history:38]
Fixed-Term Securitization Offerings — The Company periodically issues asset-backed debt securities under fixed-term securitization programs to private investors.  The asset-backed debt securities are collateralized solely by the U.S. fixed-term lease and loan payments and associated equipment, which are held by Special Purpose Entities (“SPEs”), as discussed below.  The interest rate on these securities is fixed and ranges from 0.33% to 6.80% per annum, and the duration of these securities is based on the terms of the underlying lease and loan payment streams.
  (was, 2022-12-05, similarity 0.9355):
[0001571996-22-000044:note_history:38]
Fixed-Term Securitization Offerings — The Company periodically issues asset-backed debt securities under fixed-term securitization programs to private investors.  The asset-backed debt securities are collateralized solely by the U.S. fixed-term leases and loans in the offerings, which are held by Special Purpose Entities (“SPEs”), as discussed below.  The interest rate on these securities is fixed and ranges from 0.33% to 5.92% per annum, and the duration of these securities is based on the terms of the underlying lease and loan payment streams.

- added (2023-06-12):
[0001571996-23-000019:note_history:39]
Securitization Facility — The Company maintains a securitization facility in Europe for fixed-term leases and loans. The debt under this facility has a variable interest rate, and the duration of the debt is based on the terms of the underlying loan and lease payment streams.  This facility is effective through December 23, 2024 and had a total debt capacity of $881 million as of May 5, 2023.

- changed (2023-06-12):
[0001571996-23-000019:note_history:40]
The securitization facility contains standard structural features related to the performance of the securitized receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the program, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of May 5, 2023, these criteria were met.
  (was, 2022-12-05, similarity 0.9907):
[0001571996-22-000044:note_history:40]
The securitization facility contains standard structural features related to the performance of the securitized receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the program, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of October 28, 2022, these criteria were met.

- added (2023-06-12):
[0001571996-23-000019:note_history:41]
Other Borrowings — In connection with the Company’s international financing operations, the Company has entered into revolving structured financing debt programs related to its fixed-term lease and loan products sold in Canada, Europe, Australia, and New Zealand.  The debt under these programs has a variable interest rate, and the duration of the debt is based on the terms of the underlying loan and lease payment streams.  The Canadian facility, which is collateralized solely by Canadian loan and lease payments and associated equipment, had a total debt capacity of $332 million as of May 5, 2023 and is effective through January 16, 2025.  The European facility, which is collateralized solely by European loan and lease payments and associated equipment, had a total debt capacity of $661 million as of May 5, 2023 and is effective through June 14, 2025.  The Australia and New Zealand facility, which is collateralized solely by Australia and New Zealand loan and lease payments and associated equipment, had a total debt capacity of $301 million as of May 5, 2023 and is effective through April 20, 2025. The Middle East facility, which is collateralized solely by Middle East loan and lease payments and associated equipment, had a total debt capacity of $150 million as of May 5, 2023 and is effective through March 24, 2025.

- changed (2023-06-12):
[0001571996-23-000019:note_history:42]
Note Payable — On May 25, 2022, the Company entered into an unsecured credit agreement to fund receivables in Mexico.  As of May 5, 2023, the aggregate principal amount of the note payable was $250 million.  The note bears interest at an annual rate of 4.24% and will mature on May 31, 2024.
  (was, 2022-12-05, similarity 0.9814):
[0001571996-22-000044:note_history:42]
Note Payable — On May 25, 2022, the Company entered into an unsecured credit agreement to fund receivables in Mexico.  As of October 28, 2022, the aggregate principal amount of the note payable was $250 million.  The note bears interest at an annual rate of 4.24% and will mature on May 31, 2024.

- changed (2023-06-12):
[0001571996-23-000019:note_history:43]
In connection with the asset-based financing facilities, securitization facilities, and fixed-term securitization offerings discussed above, the Company transfers certain U.S. and European lease and loan payments and associated equipment to SPEs that meet the definition of a VIE and are consolidated, along with the associated debt described above, into the Condensed Consolidated Financial Statements as the Company is the primary beneficiary of the VIEs.  The SPEs are bankruptcy-remote legal entities with separate assets and liabilities.  The purpose of the SPEs is to facilitate the funding of customer loan and lease payments and associated equipment in the capital markets.
  (was, 2022-12-05, similarity 0.9867):
[0001571996-22-000044:note_history:43]
In connection with the asset-based financing facilities, securitization facilities, and fixed-term securitization offerings discussed above, the Company transfers certain U.S. and European lease and loan payments and associated equipment to SPEs that meet the definition of a VIE and are consolidated, along with the associated debt detailed above, into the Condensed Consolidated Financial Statements, as the Company is the primary beneficiary of the VIEs.  The SPEs are bankruptcy-remote legal entities with separate assets and liabilities.  The purpose of the SPEs is to facilitate the funding of customer loan and lease payments and associated equipment in the capital markets.

- changed (2023-06-12):
[0001571996-23-000019:note_history:44]
|  | May 5, 2023 |  | February 3, 2023 |
|  | (in millions) |
| Assets held by consolidated VIEs |  |  |  |
| Other current assets | $ | 291 |  |  | $ | 274 |  |
| Financing receivables, net of allowance |  |  |  |
| Short-term | $ | 3,620 |  |  | $ | 3,702 |  |
| Long-term | $ | 3,361 |  |  | $ | 3,295 |  |
| Property, plant, and equipment, net | $ | 1,423 |  |  | $ | 1,164 |  |
| Liabilities held by consolidated VIEs |  |  |  |
| Debt, net of unamortized debt issuance costs |  |  |  |
| Short-term | $ | 4,277 |  |  | $ | 4,761 |  |
| Long-term | $ | 1,980 |  |  | $ | 2,685 |  |
  (was, 2022-12-05, similarity 0.9652):
[0001571996-22-000044:note_history:44]
|  | October 28, 2022 |  | January 28, 2022 |
|  | (in millions) |
| Assets held by consolidated VIEs |  |  |  |
| Other current assets | $ | 302 |  |  | $ | 535 |  |
| Financing receivables, net of allowance |  |  |  |
| Short-term | $ | 3,791 |  |  | $ | 3,368 |  |
| Long-term | $ | 3,022 |  |  | $ | 3,141 |  |
| Property, plant, and equipment, net | $ | 1,094 |  |  | $ | 945 |  |
| Liabilities held by consolidated VIEs |  |  |  |
| Debt, net of unamortized debt issuance costs |  |  |  |
| Short-term | $ | 4,996 |  |  | $ | 4,560 |  |
| Long-term | $ | 2,207 |  |  | $ | 2,235 |  |

- changed (2023-06-12):
[0001571996-23-000019:note_history:45]
Lease and loan payments and associated equipment transferred via securitization through SPEs were $1.5 billion and $1.7 billion for the three months ended May 5, 2023 and April 29, 2022, respectively.
  (was, 2022-12-05, similarity 0.7143):
[0001571996-22-000044:note_history:45]
Lease and loan payments and associated equipment transferred via securitization through SPEs were $1.6 billion and $1.4 billion for the three months ended October 28, 2022 and October 29, 2021, respectively, and $4.5 billion and $4.1 billion for the nine months ended October 28, 2022 and October 29, 2021, respectively.

- changed (2023-06-12):
[0001571996-23-000019:note_history:46]
To manage certain concentrations of customer credit exposure, the Company may sell selected fixed-term customer receivables to unrelated third parties on a periodic basis, without recourse.  The amount of customer receivables sold for this purpose was $169 million and $148 million for the three months ended May 5, 2023 and April 29, 2022, respectively.  The Company’s continuing involvement in these customer receivables is primarily limited to servicing arrangements.
  (was, 2022-12-05, similarity 0.9157):
[0001571996-22-000044:note_history:46]
To manage certain concentrations of customer credit exposure, the Company may sell selected fixed-term customer receivables to unrelated third parties on a periodic basis, without recourse.  The amount of customer receivables sold for this purpose was $431 million and $180 million for the nine months ended October 28, 2022 and October 29, 2021, respectively.  The Company’s continuing involvement in these customer receivables is primarily limited to servicing arrangements.

- removed (2023-06-12):
[0001571996-22-000044:note_history:47]
The Company further strengthens customer relationships through flexible consumption models, including utility, subscription, and as-a-Service models, which enable the Company to offer its customers the option to pay over time to provide them with financial flexibility to meet their changing technological requirements.

- removed (2023-06-12):
[0001571996-22-000044:note_history:48]
|  | Three Months Ended |
|  | October 28, 2022 |  | October 29, 2021 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |  |  |  |  |  |  |  |  |  |  |  |
| Balances at beginning of period | $ | 91 |  |  | $ | 92 |  |  | $ | 183 |  |  | $ | 126 |  |  | $ | 161 |  |  | $ | 287 |  |
| Charge-offs, net of recoveries | (12) |  |  | (1) |  |  | (13) |  |  | (9) |  |  | (20) |  |  | (29) |  |
| Provision charged to income statement | 8 |  |  | 8 |  |  | 16 |  |  | (5) |  |  | (28) |  |  | (33) |  |
| Balances at end of period | $ | 87 |  |  | $ | 99 |  |  | $ | 186 |  |  | $ | 112 |  |  | $ | 113 |  |  | $ | 225 |  |

- removed (2023-06-12):
[0001571996-22-000044:note_history:49]
|  | Nine Months Ended |
|  | October 28, 2022 |  | October 29, 2021 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |  |  |  |  |  |  |  |  |  |  |  |
| Balances at beginning of period | $ | 102 |  |  | $ | 87 |  |  | $ | 189 |  |  | $ | 148 |  |  | $ | 173 |  |  | $ | 321 |  |
| Charge-offs, net of recoveries | (37) |  |  | (5) |  |  | (42) |  |  | (32) |  |  | (25) |  |  | (57) |  |
| Provision charged to income statement | 22 |  |  | 17 |  |  | 39 |  |  | (4) |  |  | (35) |  |  | (39) |  |
| Balances at end of period | $ | 87 |  |  | $ | 99 |  |  | $ | 186 |  |  | $ | 112 |  |  | $ | 113 |  |  | $ | 225 |  |

- removed (2023-06-12):
[0001571996-22-000044:note_history:50]
Fixed-term consumer and commercial customer receivables are placed on non-accrual status if principal or interest is past due and considered delinquent, or if there is concern about collectibility of a specific customer receivable.  The receivables identified as doubtful for collectibility may be classified as current for aging purposes.  Aged revolving portfolio customer receivables identified as delinquent are charged off.

- removed (2023-06-12):
[0001571996-22-000044:note_history:51]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 28, 2022 |  | October 29, 2021 |  | October 28, 2022 |  | October 29, 2021 |
|  | (in millions) |
| Net revenue — products | $ | 207 |  |  | $ | 183 |  |  | $ | 646 |  |  | $ | 607 |  |
| Cost of net revenue — products | 164 |  |  | 162 |  |  | 532 |  |  | 467 |  |
| Gross margin — products | $ | 43 |  |  | $ | 21 |  |  | $ | 114 |  |  | $ | 140 |  |

- removed (2023-06-12):
[0001571996-22-000044:note_history:52]
|  | October 28, 2022 |
|  | (in millions) |
| Fiscal 2023 (remaining three months) | $ | 723 |  |
| Fiscal 2024 | 2,191 |  |
| Fiscal 2025 | 1,524 |  |
| Fiscal 2026 | 895 |  |
| Fiscal 2027 and beyond | 387 |  |
| Total undiscounted cash flows | 5,720 |  |
| Fixed-term loans | 4,864 |  |
| Revolving loans | 685 |  |
| Less: Unearned income | (646) |  |
| Total customer receivables, gross | $ | 10,623 |  |

- removed (2023-06-12):
[0001571996-22-000044:note_history:53]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 28, 2022 |  | October 29, 2021 |  | October 28, 2022 |  | October 29, 2021 |
|  | (in millions) |
| Income related to lease payments | $ | 297 |  |  | $ | 187 |  |  | $ | 782 |  |  | $ | 510 |  |
| Depreciation expense | $ | 212 |  |  | $ | 140 |  |  | $ | 571 |  |  | $ | 383 |  |

- removed (2023-06-12):
[0001571996-22-000044:note_history:54]
Securitization Facility — The Company maintains a securitization facility in Europe for fixed-term leases and loans.  This facility is effective through December 21, 2022 and had a total debt capacity of $797 million as of October 28, 2022.  Subsequent to October 28, 2022, the Company extended the term of this facility to be effective through December 21, 2024.

- removed (2023-06-12):
[0001571996-22-000044:note_history:55]
Other Borrowings — In connection with the Company’s international financing operations, the Company has entered into revolving structured financing debt programs related to its fixed-term lease and loan products sold in Canada, Europe, Australia, and New Zealand.  The Canadian facility, which is collateralized solely by Canadian loan and lease payments and associated equipment, had a total debt capacity of $332 million as of October 28, 2022 and is effective through January 16, 2025.  The European facility, which is collateralized solely by European loan and lease payments and associated equipment, had a total debt capacity of $598 million as of October 28, 2022 and is effective through December 14, 2023.  The Australia and New Zealand facility, which is collateralized solely by Australia and New Zealand loan and lease payments and associated equipment, had a total debt capacity of $290 million as of October 28, 2022 and is effective through April 20, 2023.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-06-12):
[0001571996-23-000019:note_history:56]
|  | May 5, 2023 |  | February 3, 2023 |
|  | (in millions) |
| Senior Notes: |  |  |  |
| 5.45% due June 2023 | $ | — |  |  | $ | 1,000 |  |
| 4.00% due July 2024 | 1,000 |  |  | 1,000 |  |
| 5.85% due July 2025 | 1,000 |  |  | 1,000 |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 4.90% due October 2026 | 1,750 |  |  | 1,750 |  |
| 6.10% due July 2027 | 500 |  |  | 500 |  |
| 5.25% due February 2028 | 1,000 |  |  | 1,000 |  |
| 5.30% due October 2029 | 1,750 |  |  | 1,750 |  |
| 6.20% due July 2030 | 750 |  |  | 750 |  |
| 5.75% due February 2033 | 1,000 |  |  | 1,000 |  |
| 8.10% due July 2036 | 1,000 |  |  | 1,000 |  |
| 3.38% due December 2041 | 1,000 |  |  | 1,000 |  |
| 8.35% due July 2046 | 800 |  |  | 800 |  |
| 3.45% due December 2051 | 1,200 |  |  | 1,250 |  |
| Legacy Notes and Debentures: |  |  |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| DFS Debt (Note 4) | 10,157 |  |  | 10,290 |  |
| Other | 336 |  |  | 325 |  |
| Total debt, principal amount | $ | 28,695 |  |  | $ | 29,867 |  |
| Unamortized discount, net of unamortized premium | (121) |  |  | (133) |  |
| Debt issuance costs | (142) |  |  | (146) |  |
| Total debt, carrying value | $ | 28,432 |  |  | $ | 29,588 |  |
| Total short-term debt, carrying value | $ | 5,470 |  |  | $ | 6,573 |  |
| Total long-term debt, carrying value | $ | 22,962 |  |  | $ | 23,015 |  |
  (was, 2022-12-05, similarity 0.7438):
[0001571996-22-000044:note_history:56]
|  | October 28, 2022 |  | January 28, 2022 |
|  | (in millions) |
| Senior Notes: |  |  |  |
| 5.45% due June 2023 | $ | 1,000 |  |  | $ | 1,000 |  |
| 4.00% due July 2024 | 1,000 |  |  | 1,000 |  |
| 5.85% due July 2025 | 1,000 |  |  | 1,000 |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 4.90% due October 2026 | 1,750 |  |  | 1,750 |  |
| 6.10% due July 2027 | 500 |  |  | 500 |  |
| 5.30% due October 2029 | 1,750 |  |  | 1,750 |  |
| 6.20% due July 2030 | 750 |  |  | 750 |  |
| 8.10% due July 2036 | 1,000 |  |  | 1,000 |  |
| 3.38% due December 2041 | 1,000 |  |  | 1,000 |  |
| 8.35% due July 2046 | 800 |  |  | 800 |  |
| 3.45% due December 2051 | 1,250 |  |  | 1,250 |  |
| Legacy Notes and Debentures: |  |  |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| DFS Debt (Note 5) | 10,051 |  |  | 9,646 |  |
| Other | 287 |  |  | 337 |  |
| Total debt, principal amount | $ | 27,590 |  |  | $ | 27,235 |  |
| Unamortized discount, net of unamortized premium | (126) |  |  | (134) |  |
| Debt issuance costs | (135) |  |  | (147) |  |
| Total debt, carrying value | $ | 27,329 |  |  | $ | 26,954 |  |
| Total short-term debt, carrying value | $ | 6,767 |  |  | $ | 5,823 |  |
| Total long-term debt, carrying value | $ | 20,562 |  |  | $ | 21,131 |  |

- added (2023-06-12):
[0001571996-23-000019:note_history:57]
During the three months ended May 5, 2023, the net decrease in the Company’s debt balance primarily reflected the repayment of $1 billion principal amount of the 5.45% Senior Notes due June 2023.

- added (2023-06-12):
[0001571996-23-000019:note_history:58]
Senior Notes — The Company completed offerings of multiple series of senior notes which were issued on June 1, 2016, June 22, 2016, March 20, 2019, April 9, 2020, December 13, 2021, and January 24, 2023 in aggregate principal amounts of $20.0 billion, $3.3 billion, $4.5 billion, $2.3 billion, $2.3 billion, and $2.0 billion, respectively (the “Senior Notes”).  Interest on these borrowings is payable semiannually.

- changed (2023-06-12):
[0001571996-23-000019:note_history:59]
2021 Revolving Credit Facility — The Company’s revolving credit facility, which was entered into on November 1, 2021 (the “2021 Revolving Credit Facility”), matures on November 1, 2027.  This facility provides the Company with revolving commitments in an aggregate principal amount of $6.0 billion for general corporate purposes, including liquidity support for the Company’s commercial paper program, and includes a letter of credit sub-facility of up to $0.5 billion and a swing-line loan sub-facility of up to $0.5 billion.  The 2021 Revolving Credit Facility also allows the Company to obtain incremental additional commitments on one or more occasions in minimum amounts of $10 million.
  (was, 2022-12-05, similarity 0.9736):
[0001571996-22-000044:note_history:59]
2021 Revolving Credit Facility — As of October 28, 2022, the Company’s revolving credit facility, which was entered into on November 1, 2021 (the “2021 Revolving Credit Facility”), matures on November 1, 2026.  This facility provides the Company with revolving commitments in an aggregate principal amount of $5.0 billion as of October 28, 2022 for general corporate purposes, including liquidity support for the Company’s commercial paper program, and includes a letter of credit sub-facility of up to $0.5 billion and a swing-line loan sub-facility of up to $0.5 billion.  The 2021 Revolving Credit Facility also allows the Company to obtain incremental additional commitments on one or more occasions in minimum amounts of $10 million.

- changed (2023-06-12):
[0001571996-23-000019:note_history:60]
Borrowings under the 2021 Revolving Credit Facility bear interest at a rate per annum equal to an applicable margin plus, at the borrowers’ option, either (a) the specified adjusted term Secured Overnight Financing Rate (“SOFR”) or (b) a base rate.  The margin applicable to SOFR and base rate borrowings varies based upon the Company’s existing credit ratings.  The base rate is calculated based upon the greatest of the specified prime rate, the specified federal reserve bank rate, or SOFR plus 1%.  The borrowers may voluntarily repay outstanding loans under the 2021 Revolving Credit Facility at any time without premium or penalty, other than customary breakage costs.
  (was, 2022-12-05, similarity 0.9269):
[0001571996-22-000044:note_history:60]
Borrowings under the 2021 Revolving Credit Facility bear interest at a rate per annum equal to an applicable margin plus, at the borrowers’ option, either (a) the specified London Interbank Offered Rate (“LIBOR”) or (b) a base rate.  The margin applicable to LIBOR and base rate borrowings varies based upon the Company’s existing date ratings.  The base rate is calculated based upon the greatest of the specified prime rate, the specified federal reserve bank rate, or LIBOR plus 1%.  The borrowers may voluntarily repay outstanding loans under the 2021 Revolving Credit Facility at any time without premium or penalty, other than customary breakage costs.

- changed (2023-06-12):
[0001571996-23-000019:note_history:61]
As of May 5, 2023, the Company had no oustanding borrowings under the 2021 Revolving Credit Facility.
  (was, 2022-12-05, similarity 0.6561):
[0001571996-22-000044:note_history:61]
As of October 28, 2022, available borrowings under the 2021 Revolving Credit Facility totaled $5.0 billion.

- changed (2023-06-12):
[0001571996-23-000019:note_history:62]
Commercial Paper Program — During Fiscal 2023, the Company established a commercial paper program under which the Company may issue unsecured notes in a maximum aggregate face amount of $5.0 billion outstanding at any time, with maturities up to 397 days from the date of issuance.  The notes are sold on customary terms in the U.S. commercial paper market on a private placement basis.  The proceeds of the notes are used for general corporate purposes.  As of May 5, 2023, the Company had no outstanding borrowings under the commercial paper program.  Commercial paper issuances and repayments with maturities of 90 days or less are presented on a net basis within cash flows from financing activities on the Condensed Consolidated Statements of Cash Flows.
  (was, 2022-12-05, similarity 0.9466):
[0001571996-22-000044:note_history:62]
On July 18, 2022, the Company established a commercial paper program under which the Company may issue unsecured notes in a maximum aggregate face amount of $5.0 billion outstanding at any time, with maturities up to 397 days from the date of issue.  The notes will be sold on customary terms in the U.S. commercial paper market on a private placement basis.  The proceeds of the notes will be used for general corporate purposes.  As of October 28, 2022, the Company had no outstanding borrowings under the commercial paper program.  Commercial paper issuances and repayments with maturities of 90 days or less are presented on a net basis within cash flows from financing activities on the Condensed Consolidated Statements of Cash Flows.

- added (2023-06-12):
[0001571996-23-000019:note_history:63]
The Company may purchase, redeem, prepay, refinance, or otherwise retire any amount of outstanding indebtedness under the terms of such indebtedness at any time and from time to time, in open market or negotiated transactions with the holders of such indebtedness or otherwise, as considered appropriate in light of market conditions and other relevant factors.

- changed (2023-06-12):
[0001571996-23-000019:note_history:64]
Covenants — The credit agreement governing the 2021 Revolving Credit Facility and the indentures governing the Senior Notes and the Legacy Notes and Debentures impose various limitations, subject to exceptions, on creating certain liens and entering into sale and lease-back transactions.  The foregoing credit agreement and indentures contain customary events of default, including failure to make required payments, failure to comply with covenants, and the occurrence of certain events of bankruptcy and insolvency.  The 2021 Revolving Credit Facility is also subject to an interest coverage ratio covenant that is tested at the end of each fiscal quarter with respect to the Company’s preceding four fiscal quarters.  The Company was in compliance with this financial covenant as of May 5, 2023.
  (was, 2022-12-05, similarity 0.9936):
[0001571996-22-000044:note_history:64]
Covenants — The credit agreement governing the 2021 Revolving Credit Facility and the indentures governing the Senior Notes and the Legacy Notes and Debentures impose various limitations, subject to exceptions, on creating certain liens and entering into sale and lease-back transactions.  The foregoing credit agreement and indentures contain customary events of default, including failure to make required payments, failure to comply with covenants, and the occurrence of certain events of bankruptcy and insolvency.  The 2021 Revolving Credit Facility is also subject to an interest coverage ratio covenant that is tested at the end of each fiscal quarter with respect to the Company’s preceding four fiscal quarters.  The Company was in compliance with this financial covenant as of October 28, 2022.

- changed (2023-06-12):
[0001571996-23-000019:note_history:65]
The following table presents the aggregate future maturities of the Company’s debt as of May 5, 2023 for the periods indicated:
  (was, 2022-12-05, similarity 0.96):
[0001571996-22-000044:note_history:65]
The following table presents the aggregate future maturities of the Company’s debt as of October 28, 2022 for the periods indicated:

- changed (2023-06-12):
[0001571996-23-000019:note_history:66]
|  | Maturities by Fiscal Year |
|  | 2024 (remaining nine months) |  | 2025 |  | 2026 |  | 2027 |  | 2028 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Notes | $ | — |  |  | $ | 1,000 |  |  | $ | 1,000 |  |  | $ | 6,250 |  |  | $ | 500 |  |  | $ | 8,500 |  |  | $ | 17,250 |  |
| Legacy Notes and Debentures | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 952 |  |  | 952 |  |
| DFS Debt | 4,442 |  |  | 3,829 |  |  | 643 |  |  | 681 |  |  | 562 |  |  | — |  |  | 10,157 |  |
| Other | 177 |  |  | 122 |  |  | 26 |  |  | 7 |  |  | 4 |  |  | — |  |  | 336 |  |
| Total maturities, principal amount | 4,619 |  |  | 4,951 |  |  | 1,669 |  |  | 6,938 |  |  | 1,066 |  |  | 9,452 |  |  | 28,695 |  |
| Associated carrying value adjustments | (3) |  |  | (8) |  |  | (8) |  |  | (43) |  |  | (8) |  |  | (193) |  |  | (263) |  |
| Total maturities, carrying value amount | $ | 4,616 |  |  | $ | 4,943 |  |  | $ | 1,661 |  |  | $ | 6,895 |  |  | $ | 1,058 |  |  | $ | 9,259 |  |  | $ | 28,432 |  |
  (was, 2022-12-05, similarity 0.9929):
[0001571996-22-000044:note_history:66]
|  | Maturities by Fiscal Year |
|  | 2023 (remaining three months) |  | 2024 |  | 2025 |  | 2026 |  | 2027 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Notes | $ | — |  |  | $ | 1,000 |  |  | $ | 1,000 |  |  | $ | 1,000 |  |  | $ | 6,250 |  |  | $ | 7,050 |  |  | $ | 16,300 |  |
| Legacy Notes and Debentures | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 952 |  |  | 952 |  |
| DFS Debt | 2,166 |  |  | 4,154 |  |  | 2,424 |  |  | 255 |  |  | 552 |  |  | 500 |  |  | 10,051 |  |
| Other | 2 |  |  | 157 |  |  | 105 |  |  | 20 |  |  | 1 |  |  | 2 |  |  | 287 |  |
| Total maturities, principal amount | 2,168 |  |  | 5,311 |  |  | 3,529 |  |  | 1,275 |  |  | 6,803 |  |  | 8,504 |  |  | 27,590 |  |
| Associated carrying value adjustments | (5) |  |  | (5) |  |  | (9) |  |  | (8) |  |  | (51) |  |  | (183) |  |  | (261) |  |
| Total maturities, carrying value amount | $ | 2,163 |  |  | $ | 5,306 |  |  | $ | 3,520 |  |  | $ | 1,267 |  |  | $ | 6,752 |  |  | $ | 8,321 |  |  | $ | 27,329 |  |

- removed (2023-06-12):
[0001571996-22-000044:note_history:67]
Commercial Paper Program

- removed (2023-06-12):
[0001571996-22-000044:note_history:68]
Senior Notes — The Company completed private offerings of multiple series of senior notes which were issued on June 1, 2016, June 22, 2016, March 20, 2019, April 9, 2020, and December 13, 2021 in aggregate principal amounts of $20.0 billion, $3.3 billion, $4.5 billion, $2.3 billion, and $2.3 billion, respectively (together with the registered senior notes subsequently issued in exchange, the “Senior Notes”).  Interest on these borrowings is payable semiannually.

- removed (2023-06-12):
[0001571996-22-000044:note_history:69]
In June 2021, Dell International L.L.C. and EMC Corporation, wholly-owned subsidiaries of Dell Technologies Inc. and issuers of the Senior Notes (the “Issuers”), completed an offer to exchange any and all outstanding Senior Notes issued on June 1, 2016, March 20, 2019, and April 9, 2020 for senior notes registered under the Securities Act of 1933 having terms substantially identical to the terms of the outstanding Senior Notes.  The Issuers issued $18.4 billion aggregate principal amount of registered Senior Notes in exchange for the same aggregate principal amount of unregistered Senior Notes.  The aggregate principal amount of unregistered Senior Notes remaining outstanding following the settlement of the exchange offer was approximately $0.1 billion.

- removed (2023-06-12):
[0001571996-22-000044:note_history:70]
Subsequent to October 28, 2022, the Company entered into an amendment to the 2021 Revolving Credit Facility to (i) transition from a LIBOR-based borrowing rate to a borrowing rate based on SOFR (Secured Overnight Financing Rate), (ii) extend the maturity date by one year to November 1, 2027, and (iii) increase the revolving commitments by $1.0 billion to an aggregate principal amount of $6.0 billion.  The other terms of the 2021 Revolving Credit Facility remain unchanged.


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2023-06-12):
[0001571996-23-000019:note_history:71]
|  | May 5, 2023 |  | February 3, 2023 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Notes | $ | 17.1 |  |  | $ | 17.1 |  |  | $ | 18.1 |  |  | $ | 18.2 |  |
| Legacy Notes and Debentures | $ | 0.9 |  |  | $ | 1.0 |  |  | $ | 0.9 |  |  | $ | 1.0 |  |
| DFS Debt | $ | 10.2 |  |  | $ | 9.8 |  |  | $ | 10.3 |  |  | $ | 9.9 |  |

- removed (2023-06-12):
[0001571996-22-000044:note_history:72]
|  | October 28, 2022 |  | January 28, 2022 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Notes | $ | 16.2 |  |  | $ | 15.3 |  |  | $ | 16.1 |  |  | $ | 18.5 |  |
| Legacy Notes and Debentures | $ | 0.9 |  |  | $ | 0.9 |  |  | $ | 0.8 |  |  | $ | 1.1 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-06-12):
[0001571996-23-000019:note_history:73]
|  | May 5, 2023 |  | February 3, 2023 |
| DFS debt | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing and securitization facilities | $ | 3,326 |  |  | $ | 3,987 |  |
| Fixed-term securitization offerings | 3,192 |  |  | 2,679 |  |
| Other | 67 |  |  | 76 |  |
| Total DFS U.S. debt | 6,585 |  |  | 6,742 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 818 |  |  | 790 |  |
| Other borrowings | 852 |  |  | 871 |  |
| Note payable | 250 |  |  | 250 |  |
| Dell Bank senior unsecured eurobonds | 1,652 |  |  | 1,637 |  |
| Total DFS international debt | 3,572 |  |  | 3,548 |  |
| Total DFS debt | $ | 10,157 |  |  | $ | 10,290 |  |
| Total short-term DFS debt | $ | 5,232 |  |  | $ | 5,400 |  |
| Total long-term DFS debt | $ | 4,925 |  |  | $ | 4,890 |  |
  (was, 2022-12-05, similarity 0.9738):
[0001571996-22-000044:note_history:73]
|  | October 28, 2022 |  | January 28, 2022 |
| DFS debt | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing and securitization facilities | $ | 3,226 |  |  | $ | 3,054 |  |
| Fixed-term securitization offerings | 3,302 |  |  | 3,011 |  |
| Other | 87 |  |  | 135 |  |
| Total DFS U.S. debt | 6,615 |  |  | 6,200 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 688 |  |  | 739 |  |
| Other borrowings | 1,004 |  |  | 785 |  |
| Note payable | 250 |  |  | 250 |  |
| Dell Bank senior unsecured eurobonds | 1,494 |  |  | 1,672 |  |
| Total DFS international debt | 3,436 |  |  | 3,446 |  |
| Total DFS debt | $ | 10,051 |  |  | $ | 9,646 |  |
| Total short-term DFS debt | $ | 5,626 |  |  | $ | 5,803 |  |
| Total long-term DFS debt | $ | 4,425 |  |  | $ | 3,843 |  |

- changed (2023-06-12):
[0001571996-23-000019:note_history:74]
|  | May 5, 2023 |  | February 3, 2023 |
|  | (in millions) |
| Senior Notes: |  |  |  |
| 5.45% due June 2023 | $ | — |  |  | $ | 1,000 |  |
| 4.00% due July 2024 | 1,000 |  |  | 1,000 |  |
| 5.85% due July 2025 | 1,000 |  |  | 1,000 |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 4.90% due October 2026 | 1,750 |  |  | 1,750 |  |
| 6.10% due July 2027 | 500 |  |  | 500 |  |
| 5.25% due February 2028 | 1,000 |  |  | 1,000 |  |
| 5.30% due October 2029 | 1,750 |  |  | 1,750 |  |
| 6.20% due July 2030 | 750 |  |  | 750 |  |
| 5.75% due February 2033 | 1,000 |  |  | 1,000 |  |
| 8.10% due July 2036 | 1,000 |  |  | 1,000 |  |
| 3.38% due December 2041 | 1,000 |  |  | 1,000 |  |
| 8.35% due July 2046 | 800 |  |  | 800 |  |
| 3.45% due December 2051 | 1,200 |  |  | 1,250 |  |
| Legacy Notes and Debentures: |  |  |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| DFS Debt (Note 4) | 10,157 |  |  | 10,290 |  |
| Other | 336 |  |  | 325 |  |
| Total debt, principal amount | $ | 28,695 |  |  | $ | 29,867 |  |
| Unamortized discount, net of unamortized premium | (121) |  |  | (133) |  |
| Debt issuance costs | (142) |  |  | (146) |  |
| Total debt, carrying value | $ | 28,432 |  |  | $ | 29,588 |  |
| Total short-term debt, carrying value | $ | 5,470 |  |  | $ | 6,573 |  |
| Total long-term debt, carrying value | $ | 22,962 |  |  | $ | 23,015 |  |
  (was, 2022-12-05, similarity 0.7438):
[0001571996-22-000044:note_history:74]
|  | October 28, 2022 |  | January 28, 2022 |
|  | (in millions) |
| Senior Notes: |  |  |  |
| 5.45% due June 2023 | $ | 1,000 |  |  | $ | 1,000 |  |
| 4.00% due July 2024 | 1,000 |  |  | 1,000 |  |
| 5.85% due July 2025 | 1,000 |  |  | 1,000 |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 4.90% due October 2026 | 1,750 |  |  | 1,750 |  |
| 6.10% due July 2027 | 500 |  |  | 500 |  |
| 5.30% due October 2029 | 1,750 |  |  | 1,750 |  |
| 6.20% due July 2030 | 750 |  |  | 750 |  |
| 8.10% due July 2036 | 1,000 |  |  | 1,000 |  |
| 3.38% due December 2041 | 1,000 |  |  | 1,000 |  |
| 8.35% due July 2046 | 800 |  |  | 800 |  |
| 3.45% due December 2051 | 1,250 |  |  | 1,250 |  |
| Legacy Notes and Debentures: |  |  |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| DFS Debt (Note 5) | 10,051 |  |  | 9,646 |  |
| Other | 287 |  |  | 337 |  |
| Total debt, principal amount | $ | 27,590 |  |  | $ | 27,235 |  |
| Unamortized discount, net of unamortized premium | (126) |  |  | (134) |  |
| Debt issuance costs | (135) |  |  | (147) |  |
| Total debt, carrying value | $ | 27,329 |  |  | $ | 26,954 |  |
| Total short-term debt, carrying value | $ | 6,767 |  |  | $ | 5,823 |  |
| Total long-term debt, carrying value | $ | 20,562 |  |  | $ | 21,131 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-06-12):
[0001571996-23-000019:note_history:75]
The following table presents the aggregate future maturities of the Company’s debt as of May 5, 2023 for the periods indicated:
  (was, 2022-12-05, similarity 0.96):
[0001571996-22-000044:note_history:75]
The following table presents the aggregate future maturities of the Company’s debt as of October 28, 2022 for the periods indicated:

- changed (2023-06-12):
[0001571996-23-000019:note_history:76]
|  | Maturities by Fiscal Year |
|  | 2024 (remaining nine months) |  | 2025 |  | 2026 |  | 2027 |  | 2028 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Notes | $ | — |  |  | $ | 1,000 |  |  | $ | 1,000 |  |  | $ | 6,250 |  |  | $ | 500 |  |  | $ | 8,500 |  |  | $ | 17,250 |  |
| Legacy Notes and Debentures | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 952 |  |  | 952 |  |
| DFS Debt | 4,442 |  |  | 3,829 |  |  | 643 |  |  | 681 |  |  | 562 |  |  | — |  |  | 10,157 |  |
| Other | 177 |  |  | 122 |  |  | 26 |  |  | 7 |  |  | 4 |  |  | — |  |  | 336 |  |
| Total maturities, principal amount | 4,619 |  |  | 4,951 |  |  | 1,669 |  |  | 6,938 |  |  | 1,066 |  |  | 9,452 |  |  | 28,695 |  |
| Associated carrying value adjustments | (3) |  |  | (8) |  |  | (8) |  |  | (43) |  |  | (8) |  |  | (193) |  |  | (263) |  |
| Total maturities, carrying value amount | $ | 4,616 |  |  | $ | 4,943 |  |  | $ | 1,661 |  |  | $ | 6,895 |  |  | $ | 1,058 |  |  | $ | 9,259 |  |  | $ | 28,432 |  |
  (was, 2022-12-05, similarity 0.9929):
[0001571996-22-000044:note_history:76]
|  | Maturities by Fiscal Year |
|  | 2023 (remaining three months) |  | 2024 |  | 2025 |  | 2026 |  | 2027 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Notes | $ | — |  |  | $ | 1,000 |  |  | $ | 1,000 |  |  | $ | 1,000 |  |  | $ | 6,250 |  |  | $ | 7,050 |  |  | $ | 16,300 |  |
| Legacy Notes and Debentures | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 952 |  |  | 952 |  |
| DFS Debt | 2,166 |  |  | 4,154 |  |  | 2,424 |  |  | 255 |  |  | 552 |  |  | 500 |  |  | 10,051 |  |
| Other | 2 |  |  | 157 |  |  | 105 |  |  | 20 |  |  | 1 |  |  | 2 |  |  | 287 |  |
| Total maturities, principal amount | 2,168 |  |  | 5,311 |  |  | 3,529 |  |  | 1,275 |  |  | 6,803 |  |  | 8,504 |  |  | 27,590 |  |
| Associated carrying value adjustments | (5) |  |  | (5) |  |  | (9) |  |  | (8) |  |  | (51) |  |  | (183) |  |  | (261) |  |
| Total maturities, carrying value amount | $ | 2,163 |  |  | $ | 5,306 |  |  | $ | 3,520 |  |  | $ | 1,267 |  |  | $ | 6,752 |  |  | $ | 8,321 |  |  | $ | 27,329 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2023-06-12):
[0001571996-23-000019:note_history:77]
RELATED PARTY TRANSACTIONS 
VMware is considered to be a related party of the Company as a result of Michael Dell’s ownership interests in both Dell Technologies and VMware as well as Mr. Dell’s service as Chairman and Chief Executive Officer of Dell Technologies and as Chairman of the Board of VMware, Inc.
  (was, 2022-12-05, similarity 0.81):
[0001571996-22-000044:note_history:77]
RELATED PARTY TRANSACTIONS 
VMware is considered to be a related party of the Company as a result of Michael Dell’s ownership interests in both Dell Technologies and VMware as well as Mr. Dell’s continued service as Chairman and Chief Executive Officer of Dell Technologies and as Chairman of the Board of VMware, Inc.  See Note 1 and Note 2 of the Notes to the Condensed Consolidated Financial Statements for more information about the VMware Spin-off.

- changed (2023-06-12):
[0001571996-23-000019:note_history:78]
•Dell Technologies procures products and services from VMware for its internal use.  For the three months ended May 5, 2023 and April 29, 2022, costs incurred associated with products and services purchased from VMware for internal use were immaterial.
  (was, 2022-12-05, similarity 0.8491):
[0001571996-22-000044:note_history:78]
•Dell Technologies procures products and services from VMware for its internal use.  For the three and nine months ended October 28, 2022 and October 29, 2021, costs incurred associated with products and services purchased from VMware for internal use were immaterial.

- changed (2023-06-12):
[0001571996-23-000019:note_history:79]
•Dell Technologies sells and leases products and sells services to VMware.  For the three months ended May 5, 2023 and April 29, 2022, revenue recognized from sales of services to VMware was immaterial.
  (was, 2022-12-05, similarity 0.8111):
[0001571996-22-000044:note_history:79]
•Dell Technologies sells and leases products and sells services to VMware.  For the three and nine months ended October 28, 2022 and October 29, 2021, revenue recognized from sales of services to VMware was immaterial.

- changed (2023-06-12):
[0001571996-23-000019:note_history:80]
•DFS provides financing to certain VMware end-users.  Upon acceptance of the financing arrangement by both VMware’s end-users and DFS, DFS recognizes amounts due to related parties on the Condensed Consolidated Statements of Financial Position.  Associated financing fees are recorded to product net revenue on the Condensed Consolidated Statements of Income and are reflected within sales and leases of products to VMware in the table below.
  (was, 2022-12-05, similarity 0.9955):
[0001571996-22-000044:note_history:80]
•DFS provides financing to certain VMware end users.  Upon acceptance of the financing arrangement by both VMware’s end users and DFS, DFS recognizes amounts due to related parties on the Condensed Consolidated Statements of Financial Position.  Associated financing fees are recorded to product net revenue on the Condensed Consolidated Statements of Income and are reflected within sales and leases of products to VMware in the table below.

- changed (2023-06-12):
[0001571996-23-000019:note_history:81]
•Dell Technologies and VMware also enter into joint marketing, sales, and branding arrangements, for which both parties may incur costs.  For the three months ended May 5, 2023 and April 29, 2022, consideration received from VMware for joint marketing, sales, and branding arrangements was immaterial.
  (was, 2022-12-05, similarity 0.9042):
[0001571996-22-000044:note_history:81]
•Dell Technologies and VMware also enter into joint marketing, sales, and branding arrangements, for which both parties may incur costs.  For the three and nine months ended October 28, 2022 and October 29, 2021, consideration received from VMware for joint marketing, sales, and branding arrangements was immaterial.

- changed (2023-06-12):
[0001571996-23-000019:note_history:82]
•Dell Technologies and VMware entered into a transition services agreement in connection with the VMware Spin-off to provide various support services, including investment advisory services, certain support services from Dell Technologies personnel, and other transitional services.  Costs associated with this agreement were immaterial for the three months ended April 29, 2022.  Activities under the agreement concluded during Fiscal 2023.
  (was, 2022-12-05, similarity 0.8719):
[0001571996-22-000044:note_history:82]
•Dell Technologies and VMware entered into a transition services agreement in connection with the VMware Spin-off to provide various support services, including investment advisory services, certain support services from Dell Technologies personnel, and other transitional services.  Costs associated with this agreement were immaterial for the three and nine months ended October 28, 2022.

- changed (2023-06-12):
[0001571996-23-000019:note_history:83]
|  |  |  |  |  | Three Months Ended |
|  | Classification |  |  |  |  |  | May 5, 2023 |  | April 29, 2022 |  |  |
|  |  |  |  |  |  |  | (in millions) |
| Sales and leases of products to VMware | Net revenue - products |  |  |  |  |  | $ | 40 |  |  | $ | 46 |  |  |  |
| Purchase of VMware products for resale | Cost of net revenue - products |  |  |  |  |  | $ | 207 |  |  | $ | 255 |  |  |  |
| Purchase of VMware services for resale | Cost of net revenue - services |  |  |  |  |  | $ | 876 |  |  | $ | 709 |  |  |  |
  (was, 2022-12-05, similarity 0.6078):
[0001571996-22-000044:note_history:83]
|  |  |  | Three Months Ended |  | Nine Months Ended |
|  | Classification |  | October 28, 2022 |  | October 29, 2021 |  | October 28, 2022 |  | October 29, 2021 |
|  |  |  | (in millions) |
| Sales and leases of products to VMware | Net revenue - products |  | $ | 49 |  |  | $ | 56 |  |  | $ | 130 |  |  | $ | 134 |  |
| Purchase of VMware products for resale | Cost of net revenue - products |  | $ | 281 |  |  | $ | 355 |  |  | $ | 962 |  |  | $ | 1,061 |  |
| Purchase of VMware services for resale | Cost of net revenue - services |  | $ | 733 |  |  | $ | 636 |  |  | $ | 2,204 |  |  | $ | 1,830 |  |

- changed (2023-06-12):
[0001571996-23-000019:note_history:84]
|  | Classification |  | May 5, 2023 |  | February 3, 2023 |
|  |  |  | (in millions) |
| Deferred costs related to VMware products and services for resale | Other current assets |  | $ | 2,863 |  |  | $ | 3,000 |  |
| Deferred costs related to VMware products and services for resale | Other non-current assets |  | $ | 2,234 |  |  | $ | 2,537 |  |
  (was, 2022-12-05, similarity 0.9472):
[0001571996-22-000044:note_history:84]
|  | Classification |  | October 28, 2022 |  | January 28, 2022 |
|  |  |  | (in millions) |
| Deferred costs related to VMware products and services for resale | Other current assets |  | $ | 2,560 |  |  | $ | 2,571 |  |
| Deferred costs related to VMware products and services for resale | Other non-current assets |  | $ | 1,984 |  |  | $ | 2,311 |  |

- changed (2023-06-12):
[0001571996-23-000019:note_history:85]
|  | May 5, 2023 |  | February 3, 2023 |
|  | (in millions) |
| Due from related party, net, current (a) | $ | 384 |  |  | $ | 378 |  |
| Due from related party, net, non-current (b) | $ | 442 |  |  | $ | 440 |  |
| Due to related party, current (c) | $ | 594 |  |  | $ | 2,067 |  |
  (was, 2022-12-05, similarity 0.9339):
[0001571996-22-000044:note_history:85]
|  | October 28, 2022 |  | January 28, 2022 |
|  | (in millions) |
| Due from related party, net, current (a) | $ | 203 |  |  | $ | 131 |  |
| Due from related party, net, non-current (b) | $ | 612 |  |  | $ | 710 |  |
| Due to related party, current (c) | $ | 712 |  |  | $ | 1,414 |  |

- changed (2023-06-12):
[0001571996-23-000019:note_history:86]
(b)  Amounts due from related party, net, non-current consists of the non-current portion of net receivables from VMware under the Tax Agreements.
  (was, 2022-12-05, similarity 0.986):
[0001571996-22-000044:note_history:86]
(b)  Amounts due from related party, net, non-current consists of non-current portion of net receivables from VMware under the Tax Agreements.

- changed (2023-06-12):
[0001571996-23-000019:note_history:87]
(c)  Amounts due to related party, current includes amounts due to VMware, which are generally settled in cash within 60 days of each quarter-end.
  (was, 2022-12-05, similarity 0.9965):
[0001571996-22-000044:note_history:87]
(c)  Amounts due to related party, current includes amounts due to VMware which are generally settled in cash within 60 days of each quarter-end.

- added (2023-06-12):
[0001571996-23-000019:note_history:88]
Pursuant to the Tax Agreements, net receipts from VMware during the three months ended May 5, 2023 and net payments to VMware during the three months ended April 29, 2022 were immaterial.

- changed (2023-06-12):
[0001571996-23-000019:note_history:89]
As a result of the activity under the Tax Agreements with VMware, amounts due from VMware were $596 million and $599 million as of May 5, 2023 and February 3, 2023, respectively, primarily related to VMware’s estimated tax obligation resulting from the Transition Tax.  The 2017 Tax Cuts and Jobs Act included a deferral election for an eight-year installment payment method on the Transition Tax.  Dell Technologies expects VMware to pay the remainder of its Transition Tax over a period of three years.
  (was, 2022-12-05, similarity 0.9662):
[0001571996-22-000044:note_history:89]
As a result of the activity under the Tax Agreements with VMware, amounts due from VMware were $569 million and $621 million as of October 28, 2022 and January 28, 2022, respectively, primarily related to VMware’s estimated tax obligation resulting from the Transition Tax.  The 2017 Tax Cuts and Jobs Act included a deferral election for an eight-year installment payment method on the Transition Tax.  Dell Technologies expects VMware to pay the remainder of its Transition Tax over a period of three years.

- changed (2023-06-12):
[0001571996-23-000019:note_history:90]
Indemnification — Upon consummation of the VMware Spin-off, Dell Technologies recorded net income tax indemnification receivables from VMware related to certain income tax liabilities for which Dell Technologies is jointly and severally liable, but for which it is indemnified by VMware under the Tax Matters Agreement.  The amounts that VMware may be obligated to pay Dell Technologies could vary depending on the outcome of certain unresolved tax matters, which may not be resolved for several years.  The net receivable as of May 5, 2023 and February 3, 2023 was $150 million and $146 million, respectively.
  (was, 2022-12-05, similarity 0.9849):
[0001571996-22-000044:note_history:90]
Indemnification — Upon consummation of the VMware Spin-off, Dell Technologies recorded net income tax indemnification receivables from VMware related to certain income tax liabilities for which Dell Technologies is jointly and severally liable, but for which it is indemnified by VMware under the Tax Matters Agreement.  The amounts that VMware may be obligated to pay Dell Technologies could vary depending on the outcome of certain unresolved tax matters, which may not be resolved for several years.  The net receivable as of October 28, 2022 and January 28, 2022 was $157 million and$144 million, respectively.

- removed (2023-06-12):
[0001571996-22-000044:note_history:91]
•Dell Technologies and VMware enter into agreements to collaborate on technology projects in which one party pays the corresponding party for services or the reimbursement of costs.  For the three and nine months ended October 28, 2022 and October 29, 2021, collaborative technology projects were immaterial.

- removed (2023-06-12):
[0001571996-22-000044:note_history:92]
•Prior to the completion of the VMware Spin-off, Dell Technologies provided support services and support from Dell Technologies personnel to VMware in certain geographic regions where VMware did not have an established legal entity.  These employees were managed by VMware but Dell Technologies incurred the costs for these such services.  The costs incurred by Dell Technologies on VMware’s behalf to these employees were charged to VMware.  For the three and nine months ended October 29, 2021, costs associated with such seconded employees were immaterial.  Remaining activity related to seconded employees occurring after the completion of the VMware Spin-off is governed by the transition services agreement discussed above.

- removed (2023-06-12):
[0001571996-22-000044:note_history:93]
Net receipts from VMware pursuant to the Tax Agreements were immaterial during the three and nine months ended October 28, 2022 and October 29, 2021, and primarily relate to VMware’s portion of the Transition Tax, federal income taxes on Dell Technologies’ consolidated tax return, and state tax payments for combined states.


## us-gaap:ScheduleOfRelatedPartyTransactionsTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2023-06-12):
[0001571996-23-000019:note_history:94]
|  |  |  |  |  | Three Months Ended |
|  | Classification |  |  |  |  |  | May 5, 2023 |  | April 29, 2022 |  |  |
|  |  |  |  |  |  |  | (in millions) |
| Sales and leases of products to VMware | Net revenue - products |  |  |  |  |  | $ | 40 |  |  | $ | 46 |  |  |  |
| Purchase of VMware products for resale | Cost of net revenue - products |  |  |  |  |  | $ | 207 |  |  | $ | 255 |  |  |  |
| Purchase of VMware services for resale | Cost of net revenue - services |  |  |  |  |  | $ | 876 |  |  | $ | 709 |  |  |  |
  (was, 2022-12-05, similarity 0.6078):
[0001571996-22-000044:note_history:94]
|  |  |  | Three Months Ended |  | Nine Months Ended |
|  | Classification |  | October 28, 2022 |  | October 29, 2021 |  | October 28, 2022 |  | October 29, 2021 |
|  |  |  | (in millions) |
| Sales and leases of products to VMware | Net revenue - products |  | $ | 49 |  |  | $ | 56 |  |  | $ | 130 |  |  | $ | 134 |  |
| Purchase of VMware products for resale | Cost of net revenue - products |  | $ | 281 |  |  | $ | 355 |  |  | $ | 962 |  |  | $ | 1,061 |  |
| Purchase of VMware services for resale | Cost of net revenue - services |  | $ | 733 |  |  | $ | 636 |  |  | $ | 2,204 |  |  | $ | 1,830 |  |

- changed (2023-06-12):
[0001571996-23-000019:note_history:95]
|  | Classification |  | May 5, 2023 |  | February 3, 2023 |
|  |  |  | (in millions) |
| Deferred costs related to VMware products and services for resale | Other current assets |  | $ | 2,863 |  |  | $ | 3,000 |  |
| Deferred costs related to VMware products and services for resale | Other non-current assets |  | $ | 2,234 |  |  | $ | 2,537 |  |
  (was, 2022-12-05, similarity 0.9472):
[0001571996-22-000044:note_history:95]
|  | Classification |  | October 28, 2022 |  | January 28, 2022 |
|  |  |  | (in millions) |
| Deferred costs related to VMware products and services for resale | Other current assets |  | $ | 2,560 |  |  | $ | 2,571 |  |
| Deferred costs related to VMware products and services for resale | Other non-current assets |  | $ | 1,984 |  |  | $ | 2,311 |  |

- changed (2023-06-12):
[0001571996-23-000019:note_history:96]
|  | May 5, 2023 |  | February 3, 2023 |
|  | (in millions) |
| Due from related party, net, current (a) | $ | 384 |  |  | $ | 378 |  |
| Due from related party, net, non-current (b) | $ | 442 |  |  | $ | 440 |  |
| Due to related party, current (c) | $ | 594 |  |  | $ | 2,067 |  |
  (was, 2022-12-05, similarity 0.9339):
[0001571996-22-000044:note_history:96]
|  | October 28, 2022 |  | January 28, 2022 |
|  | (in millions) |
| Due from related party, net, current (a) | $ | 203 |  |  | $ | 131 |  |
| Due from related party, net, non-current (b) | $ | 612 |  |  | $ | 710 |  |
| Due to related party, current (c) | $ | 712 |  |  | $ | 1,414 |  |

- changed (2023-06-12):
[0001571996-23-000019:note_history:97]
(b)  Amounts due from related party, net, non-current consists of the non-current portion of net receivables from VMware under the Tax Agreements.
  (was, 2022-12-05, similarity 0.986):
[0001571996-22-000044:note_history:97]
(b)  Amounts due from related party, net, non-current consists of non-current portion of net receivables from VMware under the Tax Agreements.

- changed (2023-06-12):
[0001571996-23-000019:note_history:98]
(c)  Amounts due to related party, current includes amounts due to VMware, which are generally settled in cash within 60 days of each quarter-end.
  (was, 2022-12-05, similarity 0.9965):
[0001571996-22-000044:note_history:98]
(c)  Amounts due to related party, current includes amounts due to VMware which are generally settled in cash within 60 days of each quarter-end.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2023-06-12):
[0001571996-23-000019:note_history:99]
|  |  |  | Three Months Ended |
|  |  |  |  |  | May 5, 2023 |  | April 29, 2022 |
|  |  |  |  |  | (in millions) |
| Net revenue: |  |  |  |  |  |  |  |
| Infrastructure Solutions Group: |  |  |  |  |  |  |  |
| Servers and networking |  |  |  |  | $ | 3,837 |  |  | $ | 5,048 |  |
| Storage |  |  |  |  | 3,756 |  |  | 4,237 |  |
| Total ISG net revenue |  |  |  |  | $ | 7,593 |  |  | $ | 9,285 |  |
| Client Solutions Group: |  |  |  |  |  |  |  |
| Commercial |  |  |  |  | $ | 9,862 |  |  | $ | 11,971 |  |
| Consumer |  |  |  |  | 2,121 |  |  | 3,616 |  |
| Total CSG net revenue |  |  |  |  | $ | 11,983 |  |  | $ | 15,587 |  |

- removed (2023-06-12):
[0001571996-22-000044:note_history:100]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 28, 2022 |  | October 29, 2021 |  | October 28, 2022 |  | October 29, 2021 |  |  |
|  | (in millions) |
| Net revenue: |  |  |  |  |  |  |  |  |  |
| Infrastructure Solutions Group: |  |  |  |  |  |  |  |  |  |
| Servers and networking | $ | 5,201 |  |  | $ | 4,561 |  |  | $ | 15,458 |  |  | $ | 13,181 |  |  |  |
| Storage | 4,429 |  |  | 4,003 |  |  | 12,993 |  |  | 11,966 |  |  |  |
| Total ISG net revenue | $ | 9,630 |  |  | $ | 8,564 |  |  | $ | 28,451 |  |  | $ | 25,147 |  |  |  |
| Client Solutions Group: |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 10,747 |  |  | $ | 12,300 |  |  | $ | 34,859 |  |  | $ | 32,685 |  |  |  |
| Consumer | 3,028 |  |  | 4,256 |  |  | 9,993 |  |  | 11,450 |  |  |  |
| Total CSG net revenue | $ | 13,775 |  |  | $ | 16,556 |  |  | $ | 44,852 |  |  | $ | 44,135 |  |  |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-06-12):
[0001571996-23-000019:note_history:101]
|  |  |  | Three Months Ended |
|  |  |  |  |  | May 5, 2023 |  | April 29, 2022 |
|  |  |  |  |  | (in millions) |
| Deferred revenue: |  |  |  |  |  |  |  |
| Deferred revenue at beginning of period |  |  |  |  | $ | 30,286 |  |  | $ | 27,573 |  |
| Revenue deferrals |  |  |  |  | 4,719 |  |  | 4,975 |  |
| Revenue recognized |  |  |  |  | (5,310) |  |  | (4,980) |  |
| Other (a) |  |  |  |  | — |  |  | (165) |  |
| Deferred revenue at end of period |  |  |  |  | $ | 29,695 |  |  | $ | 27,403 |  |
| Short-term deferred revenue |  |  |  |  | $ | 15,527 |  |  | $ | 14,329 |  |
| Long-term deferred revenue |  |  |  |  | $ | 14,168 |  |  | $ | 13,074 |  |
  (was, 2022-12-05, similarity 0.7462):
[0001571996-22-000044:note_history:101]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 28, 2022 |  | October 29, 2021 |  | October 28, 2022 |  | October 29, 2021 |
|  | (in millions) |
| Deferred revenue: |  |  |  |  |  |  |  |
| Deferred revenue at beginning of period | $ | 28,025 |  |  | $ | 26,668 |  |  | $ | 27,573 |  |  | $ | 25,592 |  |
| Revenue deferrals | 4,128 |  |  | 4,459 |  |  | 14,675 |  |  | 15,048 |  |
| Revenue recognized | (5,064) |  |  | (4,786) |  |  | (14,994) |  |  | (14,155) |  |
| Other (a) | — |  |  | — |  |  | (165) |  |  | (144) |  |
| Deferred revenue at end of period | $ | 27,089 |  |  | $ | 26,341 |  |  | $ | 27,089 |  |  | $ | 26,341 |  |
| Short-term deferred revenue | $ | 14,106 |  |  | $ | 13,426 |  |  | $ | 14,106 |  |  | $ | 13,426 |  |
| Long-term deferred revenue | $ | 12,983 |  |  | $ | 12,915 |  |  | $ | 12,983 |  |  | $ | 12,915 |  |

- added (2023-06-12):
[0001571996-23-000019:note_history:102]
(a)    Other represents the reclassification of deferred revenue to accrued and other liabilities.

- changed (2023-06-12):
[0001571996-23-000019:note_history:103]
Remaining Performance Obligations — Remaining performance obligations represent the aggregate amount of the transaction price allocated to performance obligations not delivered, or partially undelivered, as of the end of the reporting period.  Remaining performance obligations include deferred revenue plus unbilled amounts not yet recorded in deferred revenue.  The value of the transaction price allocated to remaining performance obligations as of May 5, 2023 was approximately $39 billion.  The Company expects to recognize approximately 57% of remaining performance obligations as revenue in the next twelve months, and the remainder thereafter.
  (was, 2022-12-05, similarity 0.9922):
[0001571996-22-000044:note_history:103]
Remaining Performance Obligations — Remaining performance obligations represent the aggregate amount of the transaction price allocated to performance obligations not delivered, or partially undelivered, as of the end of the reporting period.  Remaining performance obligations include deferred revenue plus unbilled amounts not yet recorded in deferred revenue.  The value of the transaction price allocated to remaining performance obligations as of October 28, 2022 was approximately $39 billion.  The Company expects to recognize approximately 60% of remaining performance obligations as revenue in the next twelve months, and the remainder thereafter.

- removed (2023-06-12):
[0001571996-22-000044:note_history:104]
(a)    For the nine months ended October 28, 2022, Other represents the reclassification of deferred revenue to accrued and other liabilities.  For the nine months ended October 29, 2021, Other consists of divested deferred revenue from the sale of Boomi.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2023-06-12):
[0001571996-23-000019:note_history:105]
SUBSEQUENT EVENTS There were no known events occurring after May 5, 2023 and up until the date of issuance of this report that would materially affect the information presented herein.

- removed (2023-06-12):
[0001571996-22-000044:note_history:106]
SUBSEQUENT EVENTS 
Settlement of Class Action Litigation Related to the Class V Transaction

- removed (2023-06-12):
[0001571996-22-000044:note_history:107]
Subsequent to October 28, 2022, the plaintiffs and the defendants in the class action litigation related to the Class V transaction described in Note 11 of the Notes to the Condensed Consolidated Financial Statements agreed to settle the action (the “settlement”), subject to approval of the settlement by the Delaware Chancery Court.

- removed (2023-06-12):
[0001571996-22-000044:note_history:108]
Under the terms of the settlement, the plaintiffs have agreed to dismissal of all claims upon payment of a total of $1.0 billion (the “settlement amount”), which amount will include all costs, expenses and fees of the plaintiff class relating to the action and its resolution.  The settlement terms provide that it is a condition of the settlement that the settlement amount will be paid by the Company and/or the Company’s insurers on behalf of the defendants pursuant to indemnification obligations of the Company to the defendants.

- removed (2023-06-12):
[0001571996-22-000044:note_history:109]
The settlement is further conditioned on the execution of a definitive settlement agreement containing the foregoing terms and customary terms for class action settlements, and final approval of the settlement by the court.

- removed (2023-06-12):
[0001571996-22-000044:note_history:110]
If the court does not grant final approval of the settlement and all of its material terms, or the settlement does not otherwise become final or effective, proceedings in the action will continue.

- removed (2023-06-12):
[0001571996-22-000044:note_history:111]
The settlement agreement provided additional information surrounding conditions that existed as of October 28, 2022 and, as such, was treated as a recognized subsequent event.  The Company accrues a liability when it believes that it is both probable that a liability has been incurred and that it can reasonably estimate the amount of the loss.  Accordingly, the Company established a $1.0 billion liability on the Condensed Consolidated Statements of Financial Position as of October 28, 2022 and recognized $1.0 billion expense within interest and other, net within the Condensed Consolidated Statements of Income for the three months ended October 28, 2022.

- removed (2023-06-12):
[0001571996-22-000044:note_history:112]
Other than the matter identified above, there were no known events occurring after October 28, 2022 and up until the date of issuance of this report that would materially affect the information presented herein.
