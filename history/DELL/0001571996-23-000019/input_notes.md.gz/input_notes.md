# DELL notes — 0001571996-23-000019


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001571996-23-000019:notes:1]
Basis of Presentation — The accompanying unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes filed with the U.S. Securities and Exchange Commission (“SEC”) in the Company’s Annual Report on Form 10-K for the fiscal year ended February 3, 2023. These Condensed Consolidated Financial Statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“GAAP”).  In the opinion of management, the accompanying Condensed Consolidated Financial Statements reflect all adjustments of a normal recurring nature considered necessary to fairly state the financial position of the Company as of May 5, 2023 and February 3, 2023 and the results of its operations, corresponding comprehensive income, changes in stockholders’ equity, and cash flows for the three months ended May 5, 2023 and April 29, 2022.

[0001571996-23-000019:notes:2]
The preparation of financial statements in accordance with GAAP requires management to make estimates and assumptions that affect the amounts reported in the Condensed Consolidated Financial Statements and the accompanying Notes.  Actual results could differ materially from those estimates.  The results of its operations, corresponding comprehensive income, changes in stockholders’ equity, and cash flows for the three months ended May 5, 2023 and April 29, 2022 are not necessarily indicative of the results to be expected for the full fiscal year or for any other fiscal period.

[0001571996-23-000019:notes:3]
The Company’s fiscal year is the 52- or 53-week period ending on the Friday nearest January 31.  The fiscal year ended February 3, 2023 (“Fiscal 2023”) was a 53-week period while the fiscal year ending February 2, 2024 (“Fiscal 2024”) will be a 52-week period.


## us-gaap:ConsolidationPolicyTextBlock

[0001571996-23-000019:notes:4]
[same as prior period, unchanged from 0001571996-22-000044:notes:2]


## us-gaap:FairValueDisclosuresTextBlock

[0001571996-23-000019:notes:5]
[same as prior period, unchanged from 0001571996-22-000044:notes:21]

[0001571996-23-000019:notes:6]
|  | May 5, 2023 |  | February 3, 2023 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | Quoted Prices in Active Markets for Identical Assets |  | Significant Other Observable Inputs |  | Significant Unobservable Inputs |  |  |  | Quoted Prices in Active Markets for Identical Assets |  | Significant Other Observable Inputs |  | Significant Unobservable Inputs |  |  |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 3,775 |  |  | $ | — |  |  | $ | — |  |  | $ | 3,775 |  |  | $ | 4,301 |  |  | $ | — |  |  | $ | — |  |  | $ | 4,301 |  |
| Marketable equity and other securities | 9 |  |  | — |  |  | — |  |  | 9 |  |  | 33 |  |  | — |  |  | — |  |  | 33 |  |
| Derivative instruments | — |  |  | 141 |  |  | — |  |  | 141 |  |  | — |  |  | 295 |  |  | — |  |  | 295 |  |
| Total assets | $ | 3,784 |  |  | $ | 141 |  |  | $ | — |  |  | $ | 3,925 |  |  | $ | 4,334 |  |  | $ | 295 |  |  | $ | — |  |  | $ | 4,629 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative instruments | $ | — |  |  | $ | 91 |  |  | $ | — |  |  | $ | 91 |  |  | $ | — |  |  | $ | 460 |  |  | $ | — |  |  | $ | 460 |  |
| Total liabilities | $ | — |  |  | $ | 91 |  |  | $ | — |  |  | $ | 91 |  |  | $ | — |  |  | $ | 460 |  |  | $ | — |  |  | $ | 460 |  |

[0001571996-23-000019:notes:7]
The following section describes the valuation methodologies the Company uses to measure financial instruments at fair value.

[0001571996-23-000019:notes:8]
Money Market Funds — The Company’s investment in money market funds that are classified as cash equivalents hold underlying investments with a weighted average maturity of 90 days or less and are recognized at fair value.  The valuations of these securities are based on quoted prices in active markets for identical assets, when available, or pricing models whereby all significant inputs are observable or can be derived from or corroborated by observable market data.  The Company reviews security pricing and assesses liquidity on a quarterly basis.  As of May 5, 2023, the Company’s portfolio had no material exposure to money market funds with a fluctuating net asset value.

[0001571996-23-000019:notes:9]
Marketable Equity and Other Securities — The Company’s investments in equity and other securities that are measured at fair value on a recurring basis consist of strategic investments in publicly-traded companies.  The valuation of these securities is based on quoted prices in active markets.

[0001571996-23-000019:notes:10]
Derivative Instruments — The Company’s derivative financial instruments consist primarily of foreign currency forward and purchased option contracts and interest rate swaps.  The fair value of the portfolio is determined using valuation models based on market observable inputs, including interest rate curves, forward and spot prices for currencies, and implied volatilities.  Credit risk is also factored into the fair value calculation of the Company’s derivative financial instrument portfolio.  See Note 7 of the Notes to the Condensed Consolidated Financial Statements for a description of the Company’s derivative financial instrument activities.

[0001571996-23-000019:notes:11]
Deferred Compensation Plans —The Company offers deferred compensation plans for eligible employees, which allow participants to defer a portion of their compensation.  Assets were the same as liabilities associated with the plans at approximately $190 million and $179 million as of May 5, 2023 and February 3, 2023, respectively, and are included in other assets and other liabilities on the Condensed Consolidated Statements of Financial Position.  The net impact to the Condensed Consolidated Statements of Income is not material since changes in the fair value of the assets substantially offset changes in the fair value of the liabilities.  As such, assets and liabilities associated with these plans have not been included in the recurring fair value table above.

[0001571996-23-000019:notes:12]
Assets and Liabilities Measured at Fair Value on a Nonrecurring Basis — Certain assets are measured at fair value on a nonrecurring basis and therefore are not included in the recurring fair value table above.  These assets consist primarily of non-financial assets such as goodwill and intangible assets.  See Note 8 of the Notes to the Condensed Consolidated Financial Statements for additional information about goodwill and intangible assets.

[0001571996-23-000019:notes:13]
As of both May 5, 2023 and February 3, 2023, the Company held strategic investments in non-marketable equity and other securities of $1.3 billion.  As these investments represent early-stage companies without readily determinable fair values, they are not included in the recurring fair value table above.  See Note 3 of the Notes to the Condensed Consolidated Financial Statements for additional information about the Company’s strategic investments.

[0001571996-23-000019:notes:14]
Carrying Value and Estimated Fair Value of Outstanding Debt — The following table presents the carrying value and estimated fair value of the Company’s outstanding debt as described in Note 6 of the Notes to the Condensed Consolidated Financial Statements, including the current portion, as of the dates indicated:

[0001571996-23-000019:notes:15]
|  | May 5, 2023 |  | February 3, 2023 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Notes | $ | 17.1 |  |  | $ | 17.1 |  |  | $ | 18.1 |  |  | $ | 18.2 |  |
| Legacy Notes and Debentures | $ | 0.9 |  |  | $ | 1.0 |  |  | $ | 0.9 |  |  | $ | 1.0 |  |
| DFS Debt | $ | 10.2 |  |  | $ | 9.8 |  |  | $ | 10.3 |  |  | $ | 9.9 |  |

[0001571996-23-000019:notes:16]
The fair values of the outstanding debt shown in the table above were determined based on observable market prices in a less active market or based on valuation methodologies using observable inputs and were categorized as Level 2 in the fair value hierarchy.


## us-gaap:InvestmentTextBlock

[0001571996-23-000019:notes:17]
[same as prior period, unchanged from 0001571996-22-000044:notes:33]

[0001571996-23-000019:notes:18]
As of both May 5, 2023 and February 3, 2023, total investments were $1.6 billion.

[0001571996-23-000019:notes:19]
[same as prior period, unchanged from 0001571996-22-000044:notes:35]

[0001571996-23-000019:notes:20]
[same as prior period, unchanged from 0001571996-22-000044:notes:36]

[0001571996-23-000019:notes:21]
[same as prior period, unchanged from 0001571996-22-000044:notes:37]

[0001571996-23-000019:notes:22]
[same as prior period, unchanged from 0001571996-22-000044:notes:38]

[0001571996-23-000019:notes:23]
|  | May 5, 2023 |  | February 3, 2023 |
|  | Cost |  | Unrealized Gain |  | Unrealized Loss |  | Carrying Value |  | Cost |  | Unrealized Gain |  | Unrealized Loss |  | Carrying Value |
|  | (in millions) |
| Marketable | $ | 55 |  |  | $ | 17 |  |  | $ | (63) |  |  | $ | 9 |  |  | $ | 56 |  |  | $ | 17 |  |  | $ | (40) |  |  | $ | 33 |  |
| Non-marketable | 712 |  |  | 660 |  |  | (105) |  |  | 1,267 |  |  | 714 |  |  | 651 |  |  | (100) |  |  | 1,265 |  |
| Total equity and other securities | $ | 767 |  |  | $ | 677 |  |  | $ | (168) |  |  | $ | 1,276 |  |  | $ | 770 |  |  | $ | 668 |  |  | $ | (140) |  |  | $ | 1,298 |  |

[0001571996-23-000019:notes:24]
[same as prior period, unchanged from 0001571996-22-000044:notes:40]

[0001571996-23-000019:notes:25]
[same as prior period, unchanged from 0001571996-22-000044:notes:41]

[0001571996-23-000019:notes:26]
|  | Three Months Ended |
|  | May 5, 2023 |  | April 29, 2022 |
|  | (in millions) |
| Marketable securities: |  |  |  |
| Unrealized loss | $ | (23) |  |  | $ | (18) |  |
| Net unrealized gain (loss) | (23) |  |  | (18) |  |
| Non-marketable securities: |  |  |  |
| Unrealized gain | 9 |  |  | 21 |  |
| Unrealized loss | (5) |  |  | — |  |
| Net unrealized gain (a) | 4 |  |  | 21 |  |
| Net unrealized gain (loss) on equity and other securities | $ | (19) |  |  | $ | 3 |  |

[0001571996-23-000019:notes:27]
____________________

[0001571996-23-000019:notes:28]
(a)   For all periods presented, net unrealized gains on non-marketable securities were primarily due to upward adjustments for observable price changes.

[0001571996-23-000019:notes:29]
[same as prior period, unchanged from 0001571996-22-000044:notes:45]

[0001571996-23-000019:notes:30]
The Company has fixed income debt securities carried at amortized cost which are held as collateral for borrowings.  The Company intends to hold the investments to maturity.  As of May 5, 2023, the Company held $200 million in fixed income debt securities which will mature within one year and $123 million in fixed income debt securities which will mature within two to five years.

[0001571996-23-000019:notes:31]
[same as prior period, unchanged from 0001571996-22-000044:notes:47]

[0001571996-23-000019:notes:32]
|  | May 5, 2023 |  | February 3, 2023 |
|  | Cost |  | Unrealized Gain |  | Unrealized Loss |  | Carrying Value |  | Cost |  | Unrealized Gain |  | Unrealized Loss |  | Carrying Value |
|  | (in millions) |
| Fixed income debt securities | $ | 350 |  |  | $ | 77 |  |  | $ | (104) |  |  | $ | 323 |  |  | $ | 348 |  |  | $ | 65 |  |  | $ | (95) |  |  | $ | 318 |  |


## dell:CreditLossFinancialInstrumentLeasesDebtVariableInterestEntitiesAndCustomerReceivablesSalesTextBlock

[0001571996-23-000019:notes:33]
FINANCIAL SERVICES
The Company offers or arranges various financing options and alternative payment structures for its customers globally.  Alternative payment structures consist of various flexible consumption models, including utility, subscription, and as-a-Service models.

[0001571996-23-000019:notes:34]
Financing options are offered to our customers primarily through Dell Financial Services and its affiliates (“DFS”).  The Company also arranges financing for some of its customers in various countries where DFS does not currently operate as a captive enterprise.  The key activities of DFS include originating, collecting, and servicing customer financing arrangements primarily related to the purchase or use of Dell Technologies products and services.  In some cases, DFS also offers financing for the purchase of third-party technology products that complement the Dell Technologies portfolio of products and services.  New financing originations were $1.8 billion and $2.1 billion for the three months ended May 5, 2023 and April 29, 2022, respectively.

[0001571996-23-000019:notes:35]
The Company’s lease and loan arrangements with customers are aggregated primarily into the following categories:

[0001571996-23-000019:notes:36]
Revolving loans — Revolving loans offered under private label credit financing programs provide qualified customers with a revolving credit line for the purchase of products and services offered by Dell Technologies.  These private label credit financing programs are referred to as Dell Preferred Account (“DPA”) and Dell Business Credit (“DBC”).  The DPA product is primarily offered to individual consumer customers, and the DBC product is primarily offered to small and medium-sized commercial customers.  Revolving loans in the United States bear interest at a variable annual percentage rate that is tied to the prime rate.  Based on historical payment patterns, revolving loan transactions are typically repaid within twelve months on average.  Due to the short-term nature of the revolving loan portfolio, the carrying value of the portfolio approximates fair value.

[0001571996-23-000019:notes:37]
Fixed-term leases and loans — The Company enters into financing arrangements with customers who seek lease financing for equipment.  DFS leases are generally classified as sales-type leases or operating leases.  Leases with business customers have fixed terms of generally two to four years.

[0001571996-23-000019:notes:38]
The Company also offers fixed-term loans to qualified small businesses, large commercial accounts, governmental organizations, educational entities, and certain individual consumer customers.  These loans are repaid in equal payments including interest and have defined terms of generally three to five years.  The fair value of the fixed-term loan portfolio is determined using market observable inputs.  The carrying value of these loans approximates fair value.

[0001571996-23-000019:notes:39]
Flexible consumption models, as defined above, enable the Company to offer its customers the option to pay over time to provide them with financial flexibility to meet their changing technological requirements.  Such models may result in identification of embedded lease arrangements that lead to the recognition of operating or sales-type leases.

[0001571996-23-000019:notes:40]
Financing Receivables

[0001571996-23-000019:notes:41]
The following table presents the components of the Company’s financing receivables segregated by portfolio segment as of the dates indicated:

[0001571996-23-000019:notes:42]
|  | May 5, 2023 |  | February 3, 2023 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Financing receivables, net: |  |  |  |  |  |  |  |  |  |  |  |
| Customer receivables, gross (a) | $ | 658 |  |  | $ | 9,951 |  |  | $ | 10,609 |  |  | $ | 685 |  |  | $ | 10,293 |  |  | $ | 10,978 |  |
| Allowances for losses | (84) |  |  | (135) |  |  | (219) |  |  | (88) |  |  | (113) |  |  | (201) |  |
| Customer receivables, net | 574 |  |  | 9,816 |  |  | 10,390 |  |  | 597 |  |  | 10,180 |  |  | 10,777 |  |
| Residual interest | — |  |  | 147 |  |  | 147 |  |  | — |  |  | 142 |  |  | 142 |  |
| Financing receivables, net | $ | 574 |  |  | $ | 9,963 |  |  | $ | 10,537 |  |  | $ | 597 |  |  | $ | 10,322 |  |  | $ | 10,919 |  |
| Short-term | $ | 574 |  |  | $ | 4,439 |  |  | $ | 5,013 |  |  | $ | 597 |  |  | $ | 4,684 |  |  | $ | 5,281 |  |
| Long-term | $ | — |  |  | $ | 5,524 |  |  | $ | 5,524 |  |  | $ | — |  |  | $ | 5,638 |  |  | $ | 5,638 |  |

[0001571996-23-000019:notes:43]
(a)    Customer receivables, gross include amounts due from customers under revolving loans, fixed-term loans, fixed-term leases, and accrued interest.

[0001571996-23-000019:notes:44]
The following table presents the changes in allowance for financing receivable losses for the periods indicated:

[0001571996-23-000019:notes:45]
|  | Three Months Ended |
|  | May 5, 2023 |  | April 29, 2022 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |  |  |  |  |  |  |  |  |  |  |  |
| Balances at beginning of period | $ | 88 |  |  | $ | 113 |  |  | $ | 201 |  |  | $ | 102 |  |  | $ | 87 |  |  | $ | 189 |  |
| Charge-offs, net of recoveries | (17) |  |  | (1) |  |  | (18) |  |  | (13) |  |  | (2) |  |  | (15) |  |
| Provision charged to income statement | 13 |  |  | 23 |  |  | 36 |  |  | 5 |  |  | 2 |  |  | 7 |  |
| Balances at end of period | $ | 84 |  |  | $ | 135 |  |  | $ | 219 |  |  | $ | 94 |  |  | $ | 87 |  |  | $ | 181 |  |

[0001571996-23-000019:notes:46]
The Company recognizes an allowance for financing receivable losses, including both the lease receivable and unguaranteed residual, in an amount equal to the expected losses net of recoveries.  The allowance for financing receivable losses on the lease receivable is determined based on various factors, including lifetime expected losses determined using macroeconomic forecast assumptions and management judgments applicable to and through the expected life of the portfolios as well as past due receivables, receivable type, and customer risk profile.  The Company continues to monitor broader economic indicators and their potential impact on future credit loss performance.

[0001571996-23-000019:notes:47]
Aging

[0001571996-23-000019:notes:48]
The following table presents the aging of the Company’s customer financing receivables, gross, including accrued interest, segregated by class, as of the dates indicated:

[0001571996-23-000019:notes:49]
|  | May 5, 2023 |  | February 3, 2023 |
|  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |
|  | (in millions) |
| Revolving — DPA | $ | 433 |  |  | $ | 33 |  |  | $ | 16 |  |  | $ | 482 |  |  | $ | 457 |  |  | $ | 34 |  |  | $ | 17 |  |  | $ | 508 |  |
| Revolving — DBC | 153 |  |  | 19 |  |  | 4 |  |  | 176 |  |  | 154 |  |  | 19 |  |  | 4 |  |  | 177 |  |
| Fixed-term — Consumer and Commercial | 9,128 |  |  | 743 |  |  | 80 |  |  | 9,951 |  |  | 9,309 |  |  | 927 |  |  | 57 |  |  | 10,293 |  |
| Total customer receivables, gross | $ | 9,714 |  |  | $ | 795 |  |  | $ | 100 |  |  | $ | 10,609 |  |  | $ | 9,920 |  |  | $ | 980 |  |  | $ | 78 |  |  | $ | 10,978 |  |

[0001571996-23-000019:notes:50]
Aging is likely to fluctuate as a result of the variability in volume of large transactions entered into over the period, and the administrative processes that accompany those transactions.  Aging is also impacted by the timing of the Company’s fiscal period end date relative to calendar month-end customer payment due dates.  As a result of these factors, fluctuations in aging from period to period do not necessarily indicate a material change in the collectibility of the portfolio.

[0001571996-23-000019:notes:51]
Fixed-term consumer and commercial customer receivables are placed on non-accrual status if principal or interest is past due and considered delinquent, or if there is concern about the collectibility of a specific customer receivable.  The receivables identified as doubtful for collectibility may be classified as current for aging purposes.  Aged revolving portfolio customer receivables identified as delinquent are charged off.

[0001571996-23-000019:notes:52]
Credit Quality

[0001571996-23-000019:notes:53]
The following tables present customer receivables, gross, including accrued interest, by credit quality indicator, segregated by class, as of the dates indicated:

[0001571996-23-000019:notes:54]
|  | May 5, 2023 |
|  | Fixed-term — Consumer and Commercial |  |  |  |  |  |  |
|  | Fiscal Year of Origination |  |  |  |  |  |  |
|  | 2024 |  | 2023 |  | 2022 |  | 2021 |  | 2020 |  | Years Prior |  | Revolving — DPA |  | Revolving — DBC |  | Total |
|  | (in millions) |
| Higher | $ | 931 |  |  | $ | 2,640 |  |  | $ | 1,484 |  |  | $ | 716 |  |  | $ | 259 |  |  | $ | 18 |  |  | $ | 113 |  |  | $ | 43 |  |  | $ | 6,204 |  |
| Mid | 410 |  |  | 1,274 |  |  | 536 |  |  | 270 |  |  | 84 |  |  | 9 |  |  | 130 |  |  | 53 |  |  | 2,766 |  |
| Lower | 198 |  |  | 660 |  |  | 296 |  |  | 117 |  |  | 42 |  |  | 7 |  |  | 239 |  |  | 80 |  |  | 1,639 |  |
| Total | $ | 1,539 |  |  | $ | 4,574 |  |  | $ | 2,316 |  |  | $ | 1,103 |  |  | $ | 385 |  |  | $ | 34 |  |  | $ | 482 |  |  | $ | 176 |  |  | $ | 10,609 |  |

[0001571996-23-000019:notes:55]
|  | February 3, 2023 |
|  | Fixed-term — Consumer and Commercial |  |  |  |  |  |  |
|  | Fiscal Year of Origination |  |  |  |  |  |  |
|  | 2023 |  | 2022 |  | 2021 |  | 2020 |  | 2019 |  | Years Prior |  | Revolving — DPA |  | Revolving — DBC |  | Total |
|  | (in millions) |
| Higher | $ | 3,210 |  |  | $ | 1,805 |  |  | $ | 914 |  |  | $ | 343 |  |  | $ | 37 |  |  | $ | 1 |  |  | $ | 123 |  |  | $ | 44 |  |  | $ | 6,477 |  |
| Mid | 1,242 |  |  | 631 |  |  | 362 |  |  | 119 |  |  | 17 |  |  | 1 |  |  | 136 |  |  | 54 |  |  | 2,562 |  |
| Lower | 1,017 |  |  | 364 |  |  | 157 |  |  | 65 |  |  | 7 |  |  | 1 |  |  | 249 |  |  | 79 |  |  | 1,939 |  |
| Total | $ | 5,469 |  |  | $ | 2,800 |  |  | $ | 1,433 |  |  | $ | 527 |  |  | $ | 61 |  |  | $ | 3 |  |  | $ | 508 |  |  | $ | 177 |  |  | $ | 10,978 |  |

[0001571996-23-000019:notes:56]
The categories shown in the tables above segregate customer receivables based on the relative degrees of credit risk.  The credit quality indicators for DPA revolving accounts are measured primarily as of each quarter-end date, while all other indicators are generally updated on a periodic basis.

[0001571996-23-000019:notes:57]
For DPA revolving receivables shown in the table above, the Company makes credit decisions based on proprietary scorecards, which include the customer’s credit history, payment history, credit usage, and other credit agency-related elements.  The higher quality category includes prime accounts generally comparable to U.S. customer FICO scores of 720 or above.  The mid category represents the mid-tier accounts that are comparable to U.S. customer FICO scores from 660 to 719.  The lower category is generally sub-prime and represents accounts that are comparable to U.S. customer FICO scores below 660.  For the DBC revolving receivables and fixed-term commercial receivables shown in the table above, an internal grading system is utilized that assigns a credit level score based on a number of considerations, including liquidity, operating performance, and industry outlook.  The grading criteria and classifications for the fixed-term products differ from those for the revolving products as loss experience varies between these product and customer groups.  The credit quality categories cannot be compared between the different classes as loss experience varies substantially between the classes.

[0001571996-23-000019:notes:58]
Leases

[0001571996-23-000019:notes:59]
The following table presents the net revenue, cost of net revenue, and gross margin recognized at the commencement date of sales-type leases for the periods indicated:

[0001571996-23-000019:notes:60]
|  |  |  | Three Months Ended |
|  |  |  |  |  | May 5, 2023 |  | April 29, 2022 |
|  |  |  |  |  | (in millions) |
| Net revenue — products |  |  |  |  | $ | 247 |  |  | $ | 220 |  |
| Cost of net revenue — products |  |  |  |  | 196 |  |  | 204 |  |
| Gross margin — products |  |  |  |  | $ | 51 |  |  | $ | 16 |  |

[0001571996-23-000019:notes:61]
The following table presents the future maturity of the Company’s fixed-term customer leases and associated financing payments, and reconciles the undiscounted cash flows to the customer receivables, gross recognized on the Condensed Consolidated Statement of Financial Position as of the date indicated:

[0001571996-23-000019:notes:62]
|  | May 5, 2023 |
|  | (in millions) |
| Fiscal 2024 (remaining nine months) | $ | 1,997 |  |
| Fiscal 2025 | 1,894 |  |
| Fiscal 2026 | 1,361 |  |
| Fiscal 2027 | 659 |  |
| Fiscal 2028 and beyond | 178 |  |
| Total undiscounted cash flows | 6,089 |  |
| Fixed-term loans | 4,640 |  |
| Revolving loans | 658 |  |
| Less: Unearned income | (778) |  |
| Total customer receivables, gross | $ | 10,609 |  |

[0001571996-23-000019:notes:63]
Operating Leases

[0001571996-23-000019:notes:64]
The Company’s operating leases primarily consist of DFS captive fixed-term leases and contractually committed embedded leases identified within flexible consumption arrangements.

[0001571996-23-000019:notes:65]
The following table presents the components of the Company’s operating lease portfolio included in property, plant, and equipment, net as of the dates indicated:

[0001571996-23-000019:notes:66]
|  | May 5, 2023 |  | February 3, 2023 |
|  | (in millions) |
| Equipment under operating lease, gross | $ | 3,817 |  |  | $ | 3,725 |  |
| Less: Accumulated depreciation | (1,634) |  |  | (1,517) |  |
| Equipment under operating lease, net | $ | 2,183 |  |  | $ | 2,208 |  |

[0001571996-23-000019:notes:67]
The following table presents operating lease income related to lease payments and depreciation expense for the Company’s operating lease portfolio for the periods indicated:

[0001571996-23-000019:notes:68]
|  |  |  | Three Months Ended |
|  |  |  |  |  | May 5, 2023 |  | April 29, 2022 |
|  |  |  |  |  | (in millions) |
| Income related to lease payments |  |  |  |  | $ | 321 |  |  | $ | 232 |  |
| Depreciation expense |  |  |  |  | $ | 233 |  |  | $ | 165 |  |

[0001571996-23-000019:notes:69]
The following table presents the future payments to be received by the Company as lessor in operating lease contracts as of the date indicated:

[0001571996-23-000019:notes:70]
|  | May 5, 2023 |
|  | (in millions) |
| Fiscal 2024 (remaining nine months) | $ | 862 |  |
| Fiscal 2025 | 824 |  |
| Fiscal 2026 | 460 |  |
| Fiscal 2027 | 141 |  |
| Fiscal 2028 and beyond | 46 |  |
| Total | $ | 2,333 |  |

[0001571996-23-000019:notes:71]
DFS Debt

[0001571996-23-000019:notes:72]
The Company maintains programs that facilitate the funding of leases, loans, and other alternative payment structures in the capital markets.  The majority of DFS debt is non-recourse to Dell Technologies and represents borrowings under securitization programs and structured financing programs, for which the Company’s risk of loss is limited to transferred loan and lease payments and associated equipment.

[0001571996-23-000019:notes:73]
The following table presents DFS debt as of the dates indicated and excludes the allocated portion of the Company’s other borrowings, which represents the additional amount considered to fund the DFS business:

[0001571996-23-000019:notes:74]
|  | May 5, 2023 |  | February 3, 2023 |
| DFS debt | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing and securitization facilities | $ | 3,326 |  |  | $ | 3,987 |  |
| Fixed-term securitization offerings | 3,192 |  |  | 2,679 |  |
| Other | 67 |  |  | 76 |  |
| Total DFS U.S. debt | 6,585 |  |  | 6,742 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 818 |  |  | 790 |  |
| Other borrowings | 852 |  |  | 871 |  |
| Note payable | 250 |  |  | 250 |  |
| Dell Bank senior unsecured eurobonds | 1,652 |  |  | 1,637 |  |
| Total DFS international debt | 3,572 |  |  | 3,548 |  |
| Total DFS debt | $ | 10,157 |  |  | $ | 10,290 |  |
| Total short-term DFS debt | $ | 5,232 |  |  | $ | 5,400 |  |
| Total long-term DFS debt | $ | 4,925 |  |  | $ | 4,890 |  |

[0001571996-23-000019:notes:75]
DFS U.S. Debt

[0001571996-23-000019:notes:76]
Asset-Based Financing and Securitization Facilities — The Company maintains separate asset-based financing facilities and a securitization facility in the United States, which are revolving facilities for fixed-term leases and loans and for revolving loans, respectively.  This debt is collateralized solely by the U.S. loan and lease payments and associated equipment in the facilities.  The debt has a variable interest rate and the duration of the debt is based on the terms of the underlying loan and lease payment streams.  As of May 5, 2023, the total debt capacity related to the U.S. asset-based financing and securitization facilities was $5.6 billion.  The Company enters into interest swap agreements to effectively convert a portion of this debt from a floating rate to a fixed rate.  See Note 7 of the Notes to the Condensed Consolidated Financial Statements for additional information about interest rate swaps.

[0001571996-23-000019:notes:77]
The Company’s U.S. securitization facility for revolving loans is effective through June 25, 2025.  The Company’s two U.S. asset-based financing facilities for fixed-term leases and loans are effective through July 10, 2023 and June 21, 2024, respectively.  The Company intends to extend the facility currently effective through July 10, 2023 during the second quarter of Fiscal 2024.

[0001571996-23-000019:notes:78]
The asset-based financing and securitization facilities contain standard structural features related to the performance of the funded receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the facility, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of May 5, 2023, these criteria were met.

[0001571996-23-000019:notes:79]
Fixed-Term Securitization Offerings — The Company periodically issues asset-backed debt securities under fixed-term securitization programs to private investors.  The asset-backed debt securities are collateralized solely by the U.S. fixed-term lease and loan payments and associated equipment, which are held by Special Purpose Entities (“SPEs”), as discussed below.  The interest rate on these securities is fixed and ranges from 0.33% to 6.80% per annum, and the duration of these securities is based on the terms of the underlying lease and loan payment streams.

[0001571996-23-000019:notes:80]
DFS International Debt

[0001571996-23-000019:notes:81]
Securitization Facility — The Company maintains a securitization facility in Europe for fixed-term leases and loans. The debt under this facility has a variable interest rate, and the duration of the debt is based on the terms of the underlying loan and lease payment streams.  This facility is effective through December 23, 2024 and had a total debt capacity of $881 million as of May 5, 2023.

[0001571996-23-000019:notes:82]
The securitization facility contains standard structural features related to the performance of the securitized receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the program, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of May 5, 2023, these criteria were met.

[0001571996-23-000019:notes:83]
Other Borrowings — In connection with the Company’s international financing operations, the Company has entered into revolving structured financing debt programs related to its fixed-term lease and loan products sold in Canada, Europe, Australia, and New Zealand.  The debt under these programs has a variable interest rate, and the duration of the debt is based on the terms of the underlying loan and lease payment streams.  The Canadian facility, which is collateralized solely by Canadian loan and lease payments and associated equipment, had a total debt capacity of $332 million as of May 5, 2023 and is effective through January 16, 2025.  The European facility, which is collateralized solely by European loan and lease payments and associated equipment, had a total debt capacity of $661 million as of May 5, 2023 and is effective through June 14, 2025.  The Australia and New Zealand facility, which is collateralized solely by Australia and New Zealand loan and lease payments and associated equipment, had a total debt capacity of $301 million as of May 5, 2023 and is effective through April 20, 2025. The Middle East facility, which is collateralized solely by Middle East loan and lease payments and associated equipment, had a total debt capacity of $150 million as of May 5, 2023 and is effective through March 24, 2025.

[0001571996-23-000019:notes:84]
Note Payable — On May 25, 2022, the Company entered into an unsecured credit agreement to fund receivables in Mexico.  As of May 5, 2023, the aggregate principal amount of the note payable was $250 million.  The note bears interest at an annual rate of 4.24% and will mature on May 31, 2024.

[0001571996-23-000019:notes:85]
Dell Bank Senior Unsecured Eurobonds — On June 24, 2020, Dell Bank issued 500 million Euro of 1.625% senior unsecured four year eurobonds due June 2024.  On October 27, 2021, Dell Bank issued 500 million Euro of 0.5% senior unsecured five year eurobonds due October 2026.  On October 18, 2022, Dell Bank issued 500 million Euro of 4.5% senior unsecured five year eurobonds due October 2027.  The issuances of the senior unsecured eurobonds support the expansion of the financing operations in Europe.

[0001571996-23-000019:notes:86]
Variable Interest Entities

[0001571996-23-000019:notes:87]
In connection with the asset-based financing facilities, securitization facilities, and fixed-term securitization offerings discussed above, the Company transfers certain U.S. and European lease and loan payments and associated equipment to SPEs that meet the definition of a VIE and are consolidated, along with the associated debt described above, into the Condensed Consolidated Financial Statements as the Company is the primary beneficiary of the VIEs.  The SPEs are bankruptcy-remote legal entities with separate assets and liabilities.  The purpose of the SPEs is to facilitate the funding of customer loan and lease payments and associated equipment in the capital markets.

[0001571996-23-000019:notes:88]
Some of the SPEs have entered into financing arrangements with multi-seller conduits that, in turn, issue asset-backed debt securities in the capital markets.  DFS debt outstanding held by the consolidated VIEs is collateralized by the lease and loan payments and associated equipment.  The Company’s risk of loss related to securitized receivables is limited to the amount by which the Company’s right to receive collections for assets securitized exceeds the amount required to pay interest, principal, and fees and expenses related to the asset-backed securities.  The Company provides credit enhancement to the securitization in the form of over-collateralization.

[0001571996-23-000019:notes:89]
The following table presents the assets and liabilities held by the consolidated VIEs as of the dates indicated, which are included in the Condensed Consolidated Statements of Financial Position:

[0001571996-23-000019:notes:90]
|  | May 5, 2023 |  | February 3, 2023 |
|  | (in millions) |
| Assets held by consolidated VIEs |  |  |  |
| Other current assets | $ | 291 |  |  | $ | 274 |  |
| Financing receivables, net of allowance |  |  |  |
| Short-term | $ | 3,620 |  |  | $ | 3,702 |  |
| Long-term | $ | 3,361 |  |  | $ | 3,295 |  |
| Property, plant, and equipment, net | $ | 1,423 |  |  | $ | 1,164 |  |
| Liabilities held by consolidated VIEs |  |  |  |
| Debt, net of unamortized debt issuance costs |  |  |  |
| Short-term | $ | 4,277 |  |  | $ | 4,761 |  |
| Long-term | $ | 1,980 |  |  | $ | 2,685 |  |

[0001571996-23-000019:notes:91]
Lease and loan payments and associated equipment transferred via securitization through SPEs were $1.5 billion and $1.7 billion for the three months ended May 5, 2023 and April 29, 2022, respectively.

[0001571996-23-000019:notes:92]
Customer Receivable Sales

[0001571996-23-000019:notes:93]
To manage certain concentrations of customer credit exposure, the Company may sell selected fixed-term customer receivables to unrelated third parties on a periodic basis, without recourse.  The amount of customer receivables sold for this purpose was $169 million and $148 million for the three months ended May 5, 2023 and April 29, 2022, respectively.  The Company’s continuing involvement in these customer receivables is primarily limited to servicing arrangements.


## us-gaap:ScheduleOfDebtTableTextBlock

[0001571996-23-000019:notes:94]
The majority of DFS debt is non-recourse to Dell Technologies and represents borrowings under securitization programs and structured financing programs, for which the Company’s risk of loss is limited to transferred loan and lease payments and associated equipment.  
The following table presents DFS debt as of the dates indicated and excludes the allocated portion of the Company’s other borrowings, which represents the additional amount considered to fund the DFS business:

[0001571996-23-000019:notes:95]
The following table summarizes the Company’s outstanding debt as of the dates indicated:

[0001571996-23-000019:notes:96]
|  | May 5, 2023 |  | February 3, 2023 |
|  | (in millions) |
| Senior Notes: |  |  |  |
| 5.45% due June 2023 | $ | — |  |  | $ | 1,000 |  |
| 4.00% due July 2024 | 1,000 |  |  | 1,000 |  |
| 5.85% due July 2025 | 1,000 |  |  | 1,000 |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 4.90% due October 2026 | 1,750 |  |  | 1,750 |  |
| 6.10% due July 2027 | 500 |  |  | 500 |  |
| 5.25% due February 2028 | 1,000 |  |  | 1,000 |  |
| 5.30% due October 2029 | 1,750 |  |  | 1,750 |  |
| 6.20% due July 2030 | 750 |  |  | 750 |  |
| 5.75% due February 2033 | 1,000 |  |  | 1,000 |  |
| 8.10% due July 2036 | 1,000 |  |  | 1,000 |  |
| 3.38% due December 2041 | 1,000 |  |  | 1,000 |  |
| 8.35% due July 2046 | 800 |  |  | 800 |  |
| 3.45% due December 2051 | 1,200 |  |  | 1,250 |  |
| Legacy Notes and Debentures: |  |  |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| DFS Debt (Note 4) | 10,157 |  |  | 10,290 |  |
| Other | 336 |  |  | 325 |  |
| Total debt, principal amount | $ | 28,695 |  |  | $ | 29,867 |  |
| Unamortized discount, net of unamortized premium | (121) |  |  | (133) |  |
| Debt issuance costs | (142) |  |  | (146) |  |
| Total debt, carrying value | $ | 28,432 |  |  | $ | 29,588 |  |
| Total short-term debt, carrying value | $ | 5,470 |  |  | $ | 6,573 |  |
| Total long-term debt, carrying value | $ | 22,962 |  |  | $ | 23,015 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0001571996-23-000019:notes:97]
LEASES 
The Company enters into leasing transactions in which the Company is the lessee.  These lease contracts are typically classified as operating leases.  The Company’s lease contracts are generally for office buildings used to conduct its business, and the determination of whether such contracts contain leases generally does not require significant estimates or judgments.  The Company also leases certain global logistics warehouses, employee vehicles, and equipment.  As of May 5, 2023, the remaining terms of the Company’s leases range from one month to approximately ten years.  As of May 5, 2023 and February 3, 2023, there were no material finance leases for which the Company was a lessee.

[0001571996-23-000019:notes:98]
The Company also enters into leasing transactions in which the Company is the lessor, primarily through customer financing arrangements offered through DFS.  DFS originates leases that are primarily classified as either sales-type leases or operating leases.  See Note 4 of the Notes to the Condensed Consolidated Financial Statements for more information on the Company’s lessor arrangements.

[0001571996-23-000019:notes:99]
[same as prior period, unchanged from 0001571996-22-000044:notes:113]

[0001571996-23-000019:notes:100]
|  | Three Months Ended |  |  |
|  | May 5, 2023 |  | April 29, 2022 |  |  |  |  |
|  | (in millions) |
| Operating lease costs | $ | 79 |  |  | $ | 72 |  |  |  |  |  |
| Variable costs | 24 |  |  | 25 |  |  |  |  |  |
| Total lease costs | $ | 103 |  |  | $ | 97 |  |  |  |  |  |

[0001571996-23-000019:notes:101]
During the three months ended May 5, 2023 and April 29, 2022, sublease income, finance lease costs, and short-term lease costs were immaterial.

[0001571996-23-000019:notes:102]
[same as prior period, unchanged from 0001571996-22-000044:notes:116]

[0001571996-23-000019:notes:103]
|  | Classification |  | May 5, 2023 |  | February 3, 2023 |  |  |
|  |  |  | (in millions, except for term and discount rate) |
| Operating lease right-of-use assets | Other non-current assets |  | $ | 734 |  | $ | 725 |  |  |
| Current operating lease liabilities | Accrued and other current liabilities |  | $ | 268 |  | $ | 260 |  |  |
| Non-current operating lease liabilities | Other non-current liabilities |  | 623 |  | 630 |  |  |
| Total operating lease liabilities |  |  | $ | 891 |  | $ | 890 |  |  |
| Weighted-average remaining lease term (in years) |  |  | 4.77 |  | 4.95 |  |  |
| Weighted-average discount rate |  |  | 4.05 | % |  | 3.48 | % |  |  |

[0001571996-23-000019:notes:104]
[same as prior period, unchanged from 0001571996-22-000044:notes:118]

[0001571996-23-000019:notes:105]
|  | Three Months Ended |
|  | May 5, 2023 |  | April 29, 2022 |
|  | (in millions) |
| Cash paid for amounts included in the measurement of lease liabilities — operating cash outflows from operating leases | $ | 77 |  |  | $ | 80 |  |
| Right-of-use assets obtained in exchange for new operating lease liabilities | $ | 81 |  |  | $ | 72 |  |

[0001571996-23-000019:notes:106]
[same as prior period, unchanged from 0001571996-22-000044:notes:121]

[0001571996-23-000019:notes:107]
|  | May 5, 2023 |
|  | (in millions) |
| Fiscal 2024 (remaining nine months) | $ | 205 |  |
| Fiscal 2025 | 224 |  |
| Fiscal 2026 | 177 |  |
| Fiscal 2027 | 134 |  |
| Fiscal 2028 | 95 |  |
| Thereafter | 136 |  |
| Total lease payments | 971 |  |
| Less: Imputed interest | (80) |  |
| Total | $ | 891 |  |
| Current operating lease liabilities | $ | 268 |  |
| Non-current operating lease liabilities | $ | 623 |  |

[0001571996-23-000019:notes:108]
As of May 5, 2023, the Company’s undiscounted operating leases that had not yet commenced were immaterial.


## us-gaap:DebtDisclosureTextBlock

[0001571996-23-000019:notes:109]
DEBT
The following table summarizes the Company’s outstanding debt as of the dates indicated:

[0001571996-23-000019:notes:110]
During the three months ended May 5, 2023, the net decrease in the Company’s debt balance primarily reflected the repayment of $1 billion principal amount of the 5.45% Senior Notes due June 2023.

[0001571996-23-000019:notes:111]
Outstanding Debt

[0001571996-23-000019:notes:112]
Senior Notes — The Company completed offerings of multiple series of senior notes which were issued on June 1, 2016, June 22, 2016, March 20, 2019, April 9, 2020, December 13, 2021, and January 24, 2023 in aggregate principal amounts of $20.0 billion, $3.3 billion, $4.5 billion, $2.3 billion, $2.3 billion, and $2.0 billion, respectively (the “Senior Notes”).  Interest on these borrowings is payable semiannually.

[0001571996-23-000019:notes:113]
Legacy Notes and Debentures — The Company has outstanding unsecured notes and debentures (collectively, the “Legacy Notes and Debentures”) that were issued by Dell Inc. (“Dell”), a wholly-owned subsidiary of Dell Technologies Inc., prior to the acquisition of Dell by Dell Technologies Inc. in the going-private transaction that closed in October 2013.  Interest on these borrowings is payable semiannually.

[0001571996-23-000019:notes:114]
DFS Debt — See Note 4 and Note 7 of the Notes to the Condensed Consolidated Financial Statements, respectively, for discussion of DFS debt and the interest rate swap agreements that hedge a portion of that debt.

[0001571996-23-000019:notes:115]
2021 Revolving Credit Facility — The Company’s revolving credit facility, which was entered into on November 1, 2021 (the “2021 Revolving Credit Facility”), matures on November 1, 2027.  This facility provides the Company with revolving commitments in an aggregate principal amount of $6.0 billion for general corporate purposes, including liquidity support for the Company’s commercial paper program, and includes a letter of credit sub-facility of up to $0.5 billion and a swing-line loan sub-facility of up to $0.5 billion.  The 2021 Revolving Credit Facility also allows the Company to obtain incremental additional commitments on one or more occasions in minimum amounts of $10 million.

[0001571996-23-000019:notes:116]
Borrowings under the 2021 Revolving Credit Facility bear interest at a rate per annum equal to an applicable margin plus, at the borrowers’ option, either (a) the specified adjusted term Secured Overnight Financing Rate (“SOFR”) or (b) a base rate.  The margin applicable to SOFR and base rate borrowings varies based upon the Company’s existing credit ratings.  The base rate is calculated based upon the greatest of the specified prime rate, the specified federal reserve bank rate, or SOFR plus 1%.  The borrowers may voluntarily repay outstanding loans under the 2021 Revolving Credit Facility at any time without premium or penalty, other than customary breakage costs.

[0001571996-23-000019:notes:117]
As of May 5, 2023, the Company had no oustanding borrowings under the 2021 Revolving Credit Facility.

[0001571996-23-000019:notes:118]
Commercial Paper Program — During Fiscal 2023, the Company established a commercial paper program under which the Company may issue unsecured notes in a maximum aggregate face amount of $5.0 billion outstanding at any time, with maturities up to 397 days from the date of issuance.  The notes are sold on customary terms in the U.S. commercial paper market on a private placement basis.  The proceeds of the notes are used for general corporate purposes.  As of May 5, 2023, the Company had no outstanding borrowings under the commercial paper program.  Commercial paper issuances and repayments with maturities of 90 days or less are presented on a net basis within cash flows from financing activities on the Condensed Consolidated Statements of Cash Flows.

[0001571996-23-000019:notes:119]
The Company may purchase, redeem, prepay, refinance, or otherwise retire any amount of outstanding indebtedness under the terms of such indebtedness at any time and from time to time, in open market or negotiated transactions with the holders of such indebtedness or otherwise, as considered appropriate in light of market conditions and other relevant factors.

[0001571996-23-000019:notes:120]
Covenants — The credit agreement governing the 2021 Revolving Credit Facility and the indentures governing the Senior Notes and the Legacy Notes and Debentures impose various limitations, subject to exceptions, on creating certain liens and entering into sale and lease-back transactions.  The foregoing credit agreement and indentures contain customary events of default, including failure to make required payments, failure to comply with covenants, and the occurrence of certain events of bankruptcy and insolvency.  The 2021 Revolving Credit Facility is also subject to an interest coverage ratio covenant that is tested at the end of each fiscal quarter with respect to the Company’s preceding four fiscal quarters.  The Company was in compliance with this financial covenant as of May 5, 2023.

[0001571996-23-000019:notes:121]
Aggregate Future Maturities

[0001571996-23-000019:notes:122]
The following table presents the aggregate future maturities of the Company’s debt as of May 5, 2023 for the periods indicated:

[0001571996-23-000019:notes:123]
|  | Maturities by Fiscal Year |
|  | 2024 (remaining nine months) |  | 2025 |  | 2026 |  | 2027 |  | 2028 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Notes | $ | — |  |  | $ | 1,000 |  |  | $ | 1,000 |  |  | $ | 6,250 |  |  | $ | 500 |  |  | $ | 8,500 |  |  | $ | 17,250 |  |
| Legacy Notes and Debentures | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 952 |  |  | 952 |  |
| DFS Debt | 4,442 |  |  | 3,829 |  |  | 643 |  |  | 681 |  |  | 562 |  |  | — |  |  | 10,157 |  |
| Other | 177 |  |  | 122 |  |  | 26 |  |  | 7 |  |  | 4 |  |  | — |  |  | 336 |  |
| Total maturities, principal amount | 4,619 |  |  | 4,951 |  |  | 1,669 |  |  | 6,938 |  |  | 1,066 |  |  | 9,452 |  |  | 28,695 |  |
| Associated carrying value adjustments | (3) |  |  | (8) |  |  | (8) |  |  | (43) |  |  | (8) |  |  | (193) |  |  | (263) |  |
| Total maturities, carrying value amount | $ | 4,616 |  |  | $ | 4,943 |  |  | $ | 1,661 |  |  | $ | 6,895 |  |  | $ | 1,058 |  |  | $ | 9,259 |  |  | $ | 28,432 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001571996-23-000019:notes:124]
[same as prior period, unchanged from 0001571996-22-000044:notes:140]

[0001571996-23-000019:notes:125]
The Company’s objective is to offset gains and losses resulting from these exposures with gains and losses on the derivative contracts used to hedge the exposures, thereby reducing volatility of earnings and protecting the fair values of assets and liabilities.  The earnings effects of the derivative instruments are presented in the same income statement line items as the earnings effects of the hedged items.  For derivatives designated as cash flow hedges, the Company assesses hedge effectiveness both at the onset of the hedge and at regular intervals throughout the life of the instruments.  For derivatives designated as fair value hedges, the Company assesses hedge effectiveness on qualifying instruments using the shortcut method whereby the hedges are considered perfectly effective at the onset of the hedge and over the life of the hedging relationship.

[0001571996-23-000019:notes:126]
[same as prior period, unchanged from 0001571996-22-000044:notes:142]

[0001571996-23-000019:notes:127]
[same as prior period, unchanged from 0001571996-22-000044:notes:143]

[0001571996-23-000019:notes:128]
During the three months ended May 5, 2023 and April 29, 2022, the Company did not discontinue any cash flow hedges related to foreign exchange contracts that had a material impact on the Company’s results of operations due to the probability that the forecasted cash flows would not occur.

[0001571996-23-000019:notes:129]
[same as prior period, unchanged from 0001571996-22-000044:notes:145]

[0001571996-23-000019:notes:130]
[same as prior period, unchanged from 0001571996-22-000044:notes:146]

[0001571996-23-000019:notes:131]
[same as prior period, unchanged from 0001571996-22-000044:notes:147]

[0001571996-23-000019:notes:132]
[same as prior period, unchanged from 0001571996-22-000044:notes:148]

[0001571996-23-000019:notes:133]
Interest rate swaps are utilized to manage the interest rate risk, at a portfolio level, associated with DFS operations in Europe.  The interest rate swaps economically convert the fixed rate on financing receivables to a three-month Euribor floating rate in order to match the floating rate nature of the banks’ funding pool.  The Company also uses interest rate swaps to manage the cash flows related to interest payments on Eurobonds.  The interest rate swaps economically convert the fixed rate on its bonds to a floating rate to match the underlying lease repayments profile.  None of these contracts are designated for hedge accounting and most expire within five years or less.

[0001571996-23-000019:notes:134]
The Company utilizes cross-currency amortizing swaps to hedge the currency and interest rate risk exposure associated with the European securitization program.  The cross-currency swaps combine a Euro-based interest rate swap with a British Pound or U.S. Dollar foreign exchange forward contract in which the Company pays a fixed or floating British Pound or U.S. Dollar amount and receives a fixed or floating amount in Euros linked to the one-month Euribor.  The notional value of the swaps amortizes in line with the expected cash flows and run-off of the securitized assets.  The swaps are not designated for hedge accounting and expire within five years or less.

[0001571996-23-000019:notes:135]
Periodically, the Company also uses interest rate swaps to modify the market risk exposures in connection with long-term debt.  During Fiscal 2023, the Company entered into interest rate swaps designated as fair value hedges intended to hedge a portion of its interest rate exposure by converting the fixed interest rate of a certain tranche of debt to a floating interest rate based on the benchmark SOFR Overnight Index Swap rate.  As of May 5, 2023, the carrying amount of the hedged debt was $1 billion.  The gains and losses related to changes in the fair value of the interest rate swaps perfectly offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in the underlying benchmark interest rate.  During the three months ended May 5, 2023, the cumulative amount of fair value hedge accounting adjustments was immaterial.  These contracts expire within four years.

[0001571996-23-000019:notes:136]
[same as prior period, unchanged from 0001571996-22-000044:notes:151]

[0001571996-23-000019:notes:137]
[same as prior period, unchanged from 0001571996-22-000044:notes:152]

[0001571996-23-000019:notes:138]
|  | May 5, 2023 |  | February 3, 2023 |
|  | (in millions) |
| Foreign exchange contracts: |  |  |  |
| Designated as cash flow hedging instruments | $ | 7,588 |  |  | $ | 7,746 |  |
| Non-designated as hedging instruments | 6,782 |  |  | 6,833 |  |
| Total | $ | 14,370 |  |  | $ | 14,579 |  |
| Interest rate contracts: |  |  |  |
| Designated as fair value hedging instruments | $ | 1,000 |  |  | $ | 1,000 |  |
| Non-designated as hedging instruments | 6,710 |  |  | 7,214 |  |
| Total | $ | 7,710 |  |  | $ | 8,214 |  |

[0001571996-23-000019:notes:139]
The following table presents the effect of derivative instruments designated as cash flow hedging instruments on the Condensed Consolidated Statements of Financial Position and the Condensed Consolidated Statements of Income for the periods indicated:

[0001571996-23-000019:notes:140]
| Derivatives in Cash Flow Hedging Relationships |  | Gain (Loss) Recognized in Accumulated OCI, Net of Tax, on Derivatives |  | Location of Gain (Loss) Reclassified from Accumulated OCI into Income |  | Gain (Loss) Reclassified from Accumulated OCI into Income |
|  |  | (in millions) |  |  |  | (in millions) |
| For the three months ended May 5, 2023: |
|  |  |  |  | Total net revenue |  | $ | (88) |  |
| Foreign exchange contracts |  | $ | 10 |  |  | Total cost of net revenue |  | (3) |  |
| Interest rate contracts |  | — |  |  | Interest and other, net |  | — |  |
| Total |  | $ | 10 |  |  | Total |  | $ | (91) |  |
| For the three months ended April 29, 2022: |
|  |  |  |  | Total net revenue |  | $ | 123 |  |
| Foreign exchange contracts |  | $ | 372 |  |  | Total cost of net revenue |  | (27) |  |
| Interest rate contracts |  | — |  |  | Interest and other, net |  | — |  |
| Total |  | $ | 372 |  |  | Total |  | $ | 96 |  |

[0001571996-23-000019:notes:141]
The following table presents the effect of derivative instruments not designated as hedging instruments on the Condensed Consolidated Statements of Income for the periods indicated:

[0001571996-23-000019:notes:142]
|  | Three Months Ended |  |  |  |  |
|  | May 5, 2023 |  | April 29, 2022 |  |  |  |  |  |  |  | Location of Gain (Loss) Recognized |
|  | (in millions) |  |  |
| Foreign exchange contracts | $ | 57 |  |  | $ | (231) |  |  |  |  |  |  |  |  | Interest and other, net |
| Interest rate contracts | (21) |  |  | 17 |  |  |  |  |  |  |  |  | Interest and other, net |
| Total | $ | 36 |  |  | $ | (214) |  |  |  |  |  |  |  |  |  |

[0001571996-23-000019:notes:143]
The Company presents its derivative instruments on a net basis in the Condensed Consolidated Statements of Financial Position due to the right of offset by its counterparties under master netting arrangements.  The following tables present the fair value of those derivative instruments presented on a gross basis as of the dates indicated:

[0001571996-23-000019:notes:144]
|  | May 5, 2023 |
|  | Other CurrentAssets |  | Other Non-Current Assets |  | Other Current Liabilities |  | Other Non-CurrentLiabilities |  | TotalFair Value |
|  | (in millions) |
| Derivatives designated as hedging instruments: |
| Foreign exchange contracts in an asset position | $ | 4 |  |  | $ | — |  |  | $ | 1 |  |  | $ | — |  |  | $ | 5 |  |
| Foreign exchange contracts in a liability position | (2) |  |  | — |  |  | (5) |  |  | — |  |  | (7) |  |
| Interest rate contracts in an asset position | — |  |  | 2 |  |  | — |  |  | — |  |  | 2 |  |
| Interest rate contracts in a liability position | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Net asset (liability) | 2 |  |  | 2 |  |  | (4) |  |  | — |  |  | — |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts in an asset position | 265 |  |  | 1 |  |  | 124 |  |  | — |  |  | 390 |  |
| Foreign exchange contracts in a liability position | (204) |  |  | — |  |  | (168) |  |  | — |  |  | (372) |  |
| Interest rate contracts in an asset position | 5 |  |  | 70 |  |  | — |  |  | — |  |  | 75 |  |
| Interest rate contracts in a liability position | — |  |  | — |  |  | — |  |  | (43) |  |  | (43) |  |
| Net asset (liability) | 66 |  |  | 71 |  |  | (44) |  |  | (43) |  |  | 50 |  |
| Total derivatives at fair value | $ | 68 |  |  | $ | 73 |  |  | $ | (48) |  |  | $ | (43) |  |  | $ | 50 |  |
|  | February 3, 2023 |
|  | Other CurrentAssets |  | Other Non-Current Assets |  | Other Current Liabilities |  | Other Non-CurrentLiabilities |  | TotalFair Value |
|  | (in millions) |
| Derivatives designated as hedging instruments: |
| Foreign exchange contracts in an asset position | $ | 7 |  |  | $ | — |  |  | $ | 30 |  |  | $ | — |  |  | $ | 37 |  |
| Foreign exchange contracts in a liability position | (21) |  |  | — |  |  | (142) |  |  | — |  |  | (163) |  |
| Interest rate contracts in an asset position | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Interest rate contracts in a liability position | — |  |  | — |  |  | — |  |  | (6) |  |  | (6) |  |
| Net asset | (14) |  |  | — |  |  | (112) |  |  | (6) |  |  | (132) |  |
| Derivatives not designated as hedging instruments: |
| Foreign exchange contracts in an asset position | 282 |  |  | 1 |  |  | 368 |  |  | — |  |  | 651 |  |
| Foreign exchange contracts in a liability position | (121) |  |  | — |  |  | (614) |  |  | (1) |  |  | (736) |  |
| Interest rate contracts in an asset position | 14 |  |  | 133 |  |  | — |  |  | — |  |  | 147 |  |
| Interest rate contracts in a liability position | — |  |  | — |  |  | — |  |  | (95) |  |  | (95) |  |
| Net asset (liability) | 175 |  |  | 134 |  |  | (246) |  |  | (96) |  |  | (33) |  |
| Total derivatives at fair value | $ | 161 |  |  | $ | 134 |  |  | $ | (358) |  |  | $ | (102) |  |  | $ | (165) |  |

[0001571996-23-000019:notes:145]
[same as prior period, unchanged from 0001571996-22-000044:notes:161]

[0001571996-23-000019:notes:146]
|  | May 5, 2023 |
|  | Gross Amounts of Recognized Assets/ (Liabilities) |  | Gross Amounts Offset in the Statement of Financial Position |  | Net Amounts of Assets/(Liabilities) Presented in the Statement of Financial Position |  | Gross Amounts not Offset in the Statement of Financial Position |  | Net Amount of Assets/ (Liabilities) Recognized in the Statement of Financial Position |
|  | Financial Instruments |  | Cash Collateral Received or Pledged |  |
|  | (in millions) |
| Derivative instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Financial assets | $ | 472 |  |  | $ | (331) |  |  | $ | 141 |  |  | $ | — |  |  | $ | (51) |  |  | $ | 90 |  |
| Financial liabilities | (422) |  |  | 331 |  |  | (91) |  |  | — |  |  | 12 |  |  | (79) |  |
| Total derivative instruments | $ | 50 |  |  | $ | — |  |  | $ | 50 |  |  | $ | — |  |  | $ | (39) |  |  | $ | 11 |  |
|  | February 3, 2023 |
|  | Gross Amounts of Recognized Assets/ (Liabilities) |  | Gross Amounts Offset in the Statement of Financial Position |  | Net Amounts of Assets/(Liabilities) Presented in the Statement of Financial Position |  | Gross Amounts not Offset in the Statement of Financial Position |  | Net Amount of Assets/ (Liabilities) Recognized in the Statement of Financial Position |
|  | Financial Instruments |  | Cash Collateral Received or Pledged |  |
|  | (in millions) |
| Derivative instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Financial assets | $ | 835 |  |  | $ | (540) |  |  | $ | 295 |  |  | $ | — |  |  | $ | — |  |  | $ | 295 |  |
| Financial liabilities | (1,000) |  |  | 540 |  |  | (460) |  |  | — |  |  | 25 |  |  | (435) |  |
| Total derivative instruments | $ | (165) |  |  | $ | — |  |  | $ | (165) |  |  | $ | — |  |  | $ | 25 |  |  | $ | (140) |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001571996-23-000019:notes:147]
[same as prior period, unchanged from 0001571996-22-000044:notes:163]

[0001571996-23-000019:notes:148]
The Infrastructure Solutions Group and Client Solutions Group reporting units are consistent with the reportable segments identified in Note 16 of the Notes to the Condensed Consolidated Financial Statements.  Other businesses consists of VMware Resale, Secureworks, and Virtustream, which each represent separate reporting units.

[0001571996-23-000019:notes:149]
[same as prior period, unchanged from 0001571996-22-000044:notes:165]

[0001571996-23-000019:notes:150]
|  | Infrastructure Solutions Group |  | Client Solutions Group |  | Other Businesses |  | Total |
|  | (in millions) |
| Balances as of February 3, 2023 | $ | 15,017 |  |  | $ | 4,232 |  |  | $ | 427 |  |  | $ | 19,676 |  |
| Impact of foreign currency translation and other | (15) |  |  | — |  |  | — |  |  | (15) |  |
| Balances as of May 5, 2023 | $ | 15,002 |  |  | $ | 4,232 |  |  | $ | 427 |  |  | $ | 19,661 |  |

[0001571996-23-000019:notes:151]
[same as prior period, unchanged from 0001571996-22-000044:notes:167]

[0001571996-23-000019:notes:152]
[same as prior period, unchanged from 0001571996-22-000044:notes:168]

[0001571996-23-000019:notes:153]
|  | May 5, 2023 |  | February 3, 2023 |
|  | Gross |  | AccumulatedAmortization |  | Net |  | Gross |  | AccumulatedAmortization |  | Net |
|  | (in millions) |
| Customer relationships | $ | 16,956 |  |  | $ | (14,589) |  |  | $ | 2,367 |  |  | $ | 16,956 |  |  | $ | (14,474) |  |  | $ | 2,482 |  |
| Developed technology | 9,466 |  |  | (8,736) |  |  | 730 |  |  | 9,466 |  |  | (8,660) |  |  | 806 |  |
| Trade names | 875 |  |  | (788) |  |  | 87 |  |  | 875 |  |  | (780) |  |  | 95 |  |
| Definite-lived intangible assets | 27,297 |  |  | (24,113) |  |  | 3,184 |  |  | 27,297 |  |  | (23,914) |  |  | 3,383 |  |
| Indefinite-lived trade names | 3,085 |  |  | — |  |  | 3,085 |  |  | 3,085 |  |  | — |  |  | 3,085 |  |
| Total intangible assets | $ | 30,382 |  |  | $ | (24,113) |  |  | $ | 6,269 |  |  | $ | 30,382 |  |  | $ | (23,914) |  |  | $ | 6,468 |  |

[0001571996-23-000019:notes:154]
Amortization expense related to definite-lived intangible assets was $199 million and $243 million for the three months ended May 5, 2023 and April 29, 2022, respectively.  There were no material impairment charges related to intangible assets during  the three months ended May 5, 2023 and April 29, 2022.

[0001571996-23-000019:notes:155]
[same as prior period, unchanged from 0001571996-22-000044:notes:171]

[0001571996-23-000019:notes:156]
|  | May 5, 2023 |
|  | (in millions) |
| Fiscal 2024 (remaining nine months) | $ | 591 |  |
| Fiscal 2025 | 619 |  |
| Fiscal 2026 | 488 |  |
| Fiscal 2027 | 376 |  |
| Fiscal 2028 | 236 |  |
| Thereafter | 874 |  |
| Total | $ | 3,184 |  |

[0001571996-23-000019:notes:157]
Goodwill and Indefinite-Lived Intangible Assets Impairment Testing

[0001571996-23-000019:notes:158]
[same as prior period, unchanged from 0001571996-22-000044:notes:174]

[0001571996-23-000019:notes:159]
For the annual impairment review during the third quarter of Fiscal 2023, the Company elected to bypass the assessment of qualitative factors to determine whether it was more likely than not that the fair value of a reporting unit was less than its carrying amount, including goodwill.  In electing to bypass the qualitative assessment, the Company proceeded directly to perform a quantitative goodwill impairment test to measure the fair value of each goodwill reporting unit relative to its carrying amount, and to determine the amount of goodwill impairment loss to be recognized, if any.

[0001571996-23-000019:notes:160]
[same as prior period, unchanged from 0001571996-22-000044:notes:176]

[0001571996-23-000019:notes:161]
[same as prior period, unchanged from 0001571996-22-000044:notes:177]

[0001571996-23-000019:notes:162]
Based on the results of the annual impairment test performed during Fiscal 2023, the fair values of each of the reporting units and indefinite-lived intangibles exceeded their carrying values.  No goodwill or indefinite-lived assets impairment test was performed during the three months ended May 5, 2023.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001571996-23-000019:notes:163]
[same as prior period, unchanged from 0001571996-22-000044:notes:179]

[0001571996-23-000019:notes:164]
[same as prior period, unchanged from 0001571996-22-000044:notes:180]

[0001571996-23-000019:notes:165]
|  |  |  | Three Months Ended |
|  |  |  |  |  | May 5, 2023 |  | April 29, 2022 |
|  |  |  |  |  | (in millions) |
| Deferred revenue: |  |  |  |  |  |  |  |
| Deferred revenue at beginning of period |  |  |  |  | $ | 30,286 |  |  | $ | 27,573 |  |
| Revenue deferrals |  |  |  |  | 4,719 |  |  | 4,975 |  |
| Revenue recognized |  |  |  |  | (5,310) |  |  | (4,980) |  |
| Other (a) |  |  |  |  | — |  |  | (165) |  |
| Deferred revenue at end of period |  |  |  |  | $ | 29,695 |  |  | $ | 27,403 |  |
| Short-term deferred revenue |  |  |  |  | $ | 15,527 |  |  | $ | 14,329 |  |
| Long-term deferred revenue |  |  |  |  | $ | 14,168 |  |  | $ | 13,074 |  |

[0001571996-23-000019:notes:166]
(a)    Other represents the reclassification of deferred revenue to accrued and other liabilities.

[0001571996-23-000019:notes:167]
Remaining Performance Obligations — Remaining performance obligations represent the aggregate amount of the transaction price allocated to performance obligations not delivered, or partially undelivered, as of the end of the reporting period.  Remaining performance obligations include deferred revenue plus unbilled amounts not yet recorded in deferred revenue.  The value of the transaction price allocated to remaining performance obligations as of May 5, 2023 was approximately $39 billion.  The Company expects to recognize approximately 57% of remaining performance obligations as revenue in the next twelve months, and the remainder thereafter.

[0001571996-23-000019:notes:168]
[same as prior period, unchanged from 0001571996-22-000044:notes:184]

[0001571996-23-000019:notes:169]
[same as prior period, unchanged from 0001571996-22-000044:notes:185]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001571996-23-000019:notes:170]
COMMITMENTS AND CONTINGENCIES 
Legal Matters

[0001571996-23-000019:notes:171]
The Company is involved in various claims, suits, assessments, investigations, and legal proceedings that arise from time to time in the ordinary course of its business, including those identified below, consisting of matters involving consumer, antitrust, tax, intellectual property, and other issues on a global basis.

[0001571996-23-000019:notes:172]
The Company accrues a liability when it believes that it is both probable that a liability has been incurred and that it can reasonably estimate the amount of the loss.  The Company reviews these accruals at least quarterly and adjusts them to reflect ongoing negotiations, settlements, rulings, advice of legal counsel, and other relevant information.  To the extent new information is obtained and the Company’s views on the probable outcomes of claims, suits, assessments, investigations, or legal proceedings change, changes in the Company’s accrued liabilities are recorded in the period in which such a determination is made.  For some matters, the incurrence of a liability is not probable or the amount cannot be reasonably estimated and therefore accruals have not been made.

[0001571996-23-000019:notes:173]
The following is a discussion of the Company’s significant legal matters and other proceedings:

[0001571996-23-000019:notes:174]
Class Actions Related to the Class V Transaction — On December 28, 2018, the Company completed a transaction (the “Class V transaction”) in which it paid $14.0 billion in cash and issued 149,387,617 shares of its Class C Common Stock to holders of its Class V Common Stock in exchange for all outstanding shares of Class V Common Stock.  As a result of the Class V transaction, the tracking stock feature of the Company’s capital structure associated with the Class V Common Stock was terminated.  Certain stockholders of the Company, subsequently brought class action complaints arising out of the Class V transaction in which they named as defendants (collectively, the “defendants”) Michael S. Dell and certain other directors serving on the Company’s board of directors at the time of the Class V transaction (collectively, the “director defendants”), certain stockholders of the Company, consisting of Mr. Dell and Silver Lake Group LLC and certain of its affiliated funds (collectively, the “stockholder defendants”), and Goldman Sachs & Co. LLC (“Goldman Sachs”), which served as financial advisor to the Company in connection with the transaction.  The plaintiffs generally alleged that the director defendants and the stockholder defendants breached their fiduciary duties under Delaware law to the former holders of the Class V common stock in connection with the Class V transaction by offering a transaction value that was allegedly billions of dollars below fair value.

[0001571996-23-000019:notes:175]
As previously reported, during the fourth quarter of Fiscal 2023, the plaintiffs and the defendants entered into an agreement to settle the lawsuit. Under the terms of the settlement, the plaintiffs agreed to the dismissal of all claims upon payment of a total of $1.0 billion (the “settlement amount”), which includes all costs, expenses and fees of the plaintiff class relating to the action and its resolution. The settlement terms required that the settlement amount be paid by the Company and/or the Company’s insurers pursuant to indemnification obligations of the Company to the defendants. The Company is subject to indemnification obligations, upon the satisfaction of specified conditions, to the director and stockholder defendants and their affiliates pursuant to provisions of the Delaware General Corporation Law, the Company’s certificate of incorporation and bylaws, and agreements with the defendants. A special committee of the Board consisting of directors who were not defendants in the action, advised by independent counsel, informed the Board of its determination that the defendants are entitled to indemnification under the foregoing obligations.

[0001571996-23-000019:notes:176]
During Fiscal 2023, the Company established a $1.0 billion liability on the Consolidated Statements of Financial Position and recognized $0.9 billion expense, net of $106 million in insurance proceeds, within interest and other, net within the Consolidated Statements of Income related to the settlement agreement.  The Company accounted for the expected insurance proceeds as a loss recovery and recognized a benefit within interest and other, net within the Condensed Consolidated Statements of Income and corresponding receivable on the Condensed Consolidated Statements of Financial Position.  On May 16, 2023, subsequent to the close of the three months ended May 5, 2023, the Company paid the settlement amount following approval of the settlement by the Delaware Court of Chancery.  The Company does not expect to incur additional expenses with respect to the settlement.

[0001571996-23-000019:notes:177]
Other Litigation — Dell does not currently anticipate that any of the other various legal proceedings it is involved in will have a material adverse effect on its business, financial condition, results of operations, or cash flows.

[0001571996-23-000019:notes:178]
In accordance with the relevant accounting guidance, the Company provides disclosures of matters where it is at least reasonably possible that the Company could experience a material loss exceeding the amounts already accrued for these or other proceedings or matters.  In addition, the Company also discloses matters based on its consideration of other matters and qualitative factors, including the experience of other companies in the industry, and investor, customer, and employee relations considerations.  As of May 5, 2023, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for these or other proceedings or matters has been incurred.  However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company’s business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters.  Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company’s business, financial condition, results of operations, or cash flows will depend on a number of factors, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.

[0001571996-23-000019:notes:179]
Indemnifications Obligations

[0001571996-23-000019:notes:180]
In the ordinary course of business, the Company enters into various contracts under which it may agree to indemnify other parties for losses incurred from certain events as defined in the relevant contract, such as litigation, regulatory penalties, or claims relating to past performance.  Such indemnification obligations may not be subject to maximum loss clauses.  Historically, payments related to these indemnification obligations have not been material to the Company.

[0001571996-23-000019:notes:181]
Under the Separation and Distribution Agreement entered into with VMware, Inc. upon the completion of the spin-off of VMware, Inc. by means of a special stock dividend (the “VMware Spin-off”), Dell Technologies has agreed to indemnify VMware, Inc., each of its subsidiaries and each of their respective directors, officers, and employees from and against all liabilities relating to, arising out of or resulting from, among other matters, the liabilities allocated to Dell Technologies as part of the separation of Dell Technologies and VMware, Inc. (individually and together with its subsidiaries, “VMware”) and their respective businesses (the “Separation”). VMware similarly has agreed to indemnify Dell Technologies Inc., each of its subsidiaries and each of their respective directors, officers, and employees from and against all liabilities relating to, arising out of or resulting from, among other matters, the liabilities allocated to VMware as part of the Separation.  Dell Technologies expects VMware to fully perform under the terms of the Separation and Distribution Agreement.

[0001571996-23-000019:notes:182]
For information on the cross-indemnifications related to the tax matters agreement between the Company and VMware effective upon the Separation on November 1, 2021, see Note 15 of the Notes to the Condensed Consolidated Financial Statements.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001571996-23-000019:notes:183]
INCOME AND OTHER TAXES
For the three months ended May 5, 2023, the Company’s effective income tax rate was 18.0% on pre-tax income of $0.7 billion compared to 11.9% on pre-tax income of $1.2 billion for the three months ended April 29, 2022.  The change in the Company’s effective income tax rate was attributable to a change in the Company’s jurisdictional mix of income as well as higher U.S. tax on foreign operations.

[0001571996-23-000019:notes:184]
The differences between the estimated effective income tax rates and the U.S. federal statutory rate of 21% principally result from the geographical distribution of income, differences between the book and tax treatment of certain items, and discrete tax items.  In certain jurisdictions, the Company’s tax rate is significantly less than the applicable statutory rate as a result of tax holidays.  The majority of the Company’s foreign income that is subject to these tax holidays and lower tax rates is attributable to Singapore and China.  A significant portion of these income tax benefits relates to a tax holiday that will be effective until January 31, 2029.  Most of the Company’s other tax holidays will expire in whole or in part during fiscal years 2030 through 2033.  Many of these tax holidays and reduced tax rates may be extended when certain conditions are met or may be terminated early if certain conditions are not met or as a result of changes in tax legislation.  As of May 5, 2023, the Company was not aware of any matters of noncompliance related to these tax holidays or enacted tax legislative changes affecting these tax holidays.

[0001571996-23-000019:notes:185]
The Internal Revenue Service is currently conducting tax examinations of the Company for fiscal years 2015 through 2019.  The Company is also currently under income tax audits in various U.S. state and foreign taxing jurisdictions.  The Company is undergoing negotiations, and in some cases contested proceedings, relating to tax matters with the taxing authorities in these jurisdictions.  The Company believes that it has provided adequate reserves related to all matters contained in tax periods open to examination.  Although the Company believes it has made adequate provisions for the uncertainties surrounding these audits, should the Company experience unfavorable outcomes, such outcomes could have a material impact on its results of operations, financial position, and cash flows.  With respect to major U.S. state and foreign taxing jurisdictions, the Company is generally not subject to tax examinations for years prior to the fiscal year ended January 29, 2010.

[0001571996-23-000019:notes:186]
Judgment is required in evaluating the Company’s uncertain tax positions and determining the Company’s provision for income taxes.  The unrecognized tax benefits were $1.3 billion as of both May 5, 2023 and February 3, 2023 and are included in accrued and other and other non-current liabilities in the Condensed Consolidated Statements of Financial Position.  The Company does not expect a significant change to the total amount of unrecognized tax benefits within the next twelve months.

[0001571996-23-000019:notes:187]
The Company takes certain non-income tax positions in the jurisdictions in which it operates and has received certain non-income tax assessments from various jurisdictions.  The Company believes that a material loss in these matters is not probable and that it is not reasonably possible that a material loss exceeding amounts already accrued has been incurred.  The Company believes its positions in these non-income tax litigation matters are supportable and that it ultimately will prevail in the matters.  In the normal course of business, the Company’s positions and conclusions related to its non-income taxes could be challenged and assessments may be made.  To the extent new information is obtained and the Company’s views on its positions, probable outcomes of assessments, or litigation change, changes in estimates to the Company’s accrued liabilities would be recorded in the period in which such a determination is made.  In the resolution process for income tax and non-income tax audits, the Company is required in certain situations to provide collateral guarantees or indemnification to regulators and tax authorities until the matter is resolved.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001571996-23-000019:notes:188]
[same as prior period, unchanged from 0001571996-22-000044:notes:207]

[0001571996-23-000019:notes:189]
[same as prior period, unchanged from 0001571996-22-000044:notes:208]

[0001571996-23-000019:notes:190]
|  | Foreign Currency Translation Adjustments |  |  |  | Cash Flow Hedges |  | Pension and Other Postretirement Plans |  | Accumulated Other Comprehensive Income (Loss) |
|  | (in millions) |
| Balances as of February 3, 2023 | $ | (747) |  |  |  |  | $ | (222) |  |  | $ | (32) |  |  | $ | (1,001) |  |
| Other comprehensive income before reclassifications | 31 |  |  |  |  | 10 |  |  | 1 |  |  | 42 |  |
| Amounts reclassified from accumulated other comprehensive income (loss) | — |  |  |  |  | 91 |  |  | — |  |  | 91 |  |
| Total change for the period | 31 |  |  |  |  | 101 |  |  | 1 |  |  | 133 |  |
| Balances as of May 5, 2023 | $ | (716) |  |  |  |  | $ | (121) |  |  | $ | (31) |  |  | $ | (868) |  |

[0001571996-23-000019:notes:191]
Amounts related to the Company’s cash flow hedges are reclassified to net income during the same period in which the items being hedged are recognized in earnings.  See Note 7 of the Notes to the Condensed Consolidated Financial Statements for more information on the Company’s derivative instruments.

[0001571996-23-000019:notes:192]
[same as prior period, unchanged from 0001571996-22-000044:notes:211]

[0001571996-23-000019:notes:193]
|  |  |  | Three Months Ended |
|  |  |  | May 5, 2023 |  |  |  | April 29, 2022 |
|  |  |  | Cash Flow Hedges |  |  |  |  |  |  |  | Cash Flow Hedges |  |  |  |  |
|  |  |  | (in millions) |
| Total reclassifications, net of tax: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue |  |  | $ | (88) |  |  |  |  |  |  |  |  | $ | 123 |  |  |  |  |  |
| Cost of net revenue |  |  | (3) |  |  |  |  |  |  |  |  | (27) |  |  |  |  |  |
| Operating expenses |  |  | — |  |  |  |  |  |  |  |  | — |  |  |  |  |  |
| Total reclassifications, net of tax |  |  | $ | (91) |  |  |  |  |  |  |  |  | $ | 96 |  |  |  |  |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001571996-23-000019:notes:194]
[same as prior period, unchanged from 0001571996-22-000044:notes:214]

[0001571996-23-000019:notes:195]
|  | Authorized |  | Issued |  | Outstanding |
|  | (in millions) |
| Common stock as of May 5, 2023 |
| Class A | 600 |  |  | 379 |  |  | 379 |  |
| Class B | 200 |  |  | 95 |  |  | 95 |  |
| Class C | 7,900 |  |  | 343 |  |  | 255 |  |
| Class D | 100 |  |  | — |  |  | — |  |
|  | 8,800 |  |  | 817 |  |  | 729 |  |
| Common stock as of February 3, 2023 |
| Class A | 600 |  |  | 379 |  |  | 379 |  |
| Class B | 200 |  |  | 95 |  |  | 95 |  |
| Class C | 7,900 |  |  | 324 |  |  | 242 |  |
| Class D | 100 |  |  | — |  |  | — |  |
|  | 8,800 |  |  | 798 |  |  | 716 |  |

[0001571996-23-000019:notes:196]
[same as prior period, unchanged from 0001571996-22-000044:notes:217]

[0001571996-23-000019:notes:197]
The Company is authorized to issue one million shares of preferred stock, par value $0.01 per share.  As of May 5, 2023 and February 3, 2023, no shares of preferred stock were issued or outstanding.

[0001571996-23-000019:notes:198]
[same as prior period, unchanged from 0001571996-22-000044:notes:219]

[0001571996-23-000019:notes:199]
[same as prior period, unchanged from 0001571996-22-000044:notes:220]

[0001571996-23-000019:notes:200]
[same as prior period, unchanged from 0001571996-22-000044:notes:221]

[0001571996-23-000019:notes:201]
[same as prior period, unchanged from 0001571996-22-000044:notes:222]

[0001571996-23-000019:notes:202]
During the three months ended May 5, 2023, there were no conversions of shares of Class A Common Stock or Class B Common Stock into shares of Class C Common Stock.

[0001571996-23-000019:notes:203]
[same as prior period, unchanged from 0001571996-22-000044:notes:224]

[0001571996-23-000019:notes:204]
On February 24, 2022, the Company announced that the Board of Directors adopted a dividend policy providing for our payment of quarterly cash dividends on the Dell Technologies Common Stock at a rate of $0.33 per share per fiscal quarter beginning in the first quarter of Fiscal 2023.  On March 2, 2023, the Company announced that the Board of Directors approved a 12% increase in the quarterly dividend rate from $0.33 per share per fiscal quarter to a rate of $0.37 per share per fiscal quarter beginning in the first quarter of Fiscal 2024.

[0001571996-23-000019:notes:205]
The Company paid the following dividends during the periods presented:

[0001571996-23-000019:notes:206]
| Three Months Ended |  | Declaration Date |  | Record Date |  | Payment Date |  | Dividend per Share |  | Amount (in millions) |
| May 5, 2023 |  | March 2, 2023 |  | April 25, 2023 |  | May 5, 2023 |  | $ | 0.37 |  |  | $ | 270 |  |
| April 29, 2022 |  | February 24, 2022 |  | April 20, 2022 |  | April 29, 2022 |  | $ | 0.33 |  |  | $ | 248 |  |

[0001571996-23-000019:notes:207]
During the three months ended May 5, 2023, the Company also paid an immaterial amount of dividend equivalents on eligible vested equity awards which are not reflected above.

[0001571996-23-000019:notes:208]
[same as prior period, unchanged from 0001571996-22-000044:notes:228]

[0001571996-23-000019:notes:209]
Effective as of September 23, 2021, the Company’s Board of Directors approved a stock repurchase program under which the Company is authorized to repurchase up to $5 billion of shares of Class C Common Stock with no fixed expiration date.  During the three months ended May 5, 2023, the Company repurchased approximately 6.1 million shares of Class C Common Stock for a total purchase price of approximately $0.25 billion.  During the three months ended April 29, 2022, the Company repurchased approximately 28.8 million shares of Class C Common Stock for a total purchase price of approximately $1.5 billion.
The above repurchases of Class C Common Stock exclude shares withheld from stock awards to settle employee tax withholding obligations related to the vesting of such awards.


## us-gaap:EarningsPerShareTextBlock

[0001571996-23-000019:notes:210]
[same as prior period, unchanged from 0001571996-22-000044:notes:231]

[0001571996-23-000019:notes:211]
[same as prior period, unchanged from 0001571996-22-000044:notes:232]

[0001571996-23-000019:notes:212]
|  |  |  | Three Months Ended |
|  |  |  |  |  | May 5, 2023 |  | April 29, 2022 |
| Earnings per share attributable to Dell Technologies Inc. |
| Dell Technologies Common Stock — Basic |  |  |  |  | $ | 0.81 |  |  | $ | 1.42 |  |
| Dell Technologies Common Stock — Diluted |  |  |  |  | $ | 0.79 |  |  | $ | 1.37 |  |

[0001571996-23-000019:notes:213]
[same as prior period, unchanged from 0001571996-22-000044:notes:234]

[0001571996-23-000019:notes:214]
|  |  |  | Three Months Ended |
|  |  |  |  |  | May 5, 2023 |  | April 29, 2022 |
|  |  |  |  |  | (in millions) |
| Numerator: Dell Technologies Common Stock |  |  |  |  |  |  |  |
| Net income attributable to Dell Technologies Inc. - basic and diluted |  |  |  |  | $ | 583 |  |  | $ | 1,072 |  |
| Denominator: Dell Technologies Common Stock weighted-average shares outstanding |  |  |  |  |  |  |  |
| Weighted-average shares outstanding — basic |  |  |  |  | 724 |  |  | 754 |  |
| Dilutive effect of options, restricted stock units, restricted stock, and other |  |  |  |  | 13 |  |  | 26 |  |
| Weighted-average shares outstanding — diluted |  |  |  |  | 737 |  |  | 780 |  |
| Weighted-average shares outstanding — antidilutive |  |  |  |  | 16 |  |  | 1 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001571996-23-000019:notes:215]
RELATED PARTY TRANSACTIONS 
VMware is considered to be a related party of the Company as a result of Michael Dell’s ownership interests in both Dell Technologies and VMware as well as Mr. Dell’s service as Chairman and Chief Executive Officer of Dell Technologies and as Chairman of the Board of VMware, Inc.

[0001571996-23-000019:notes:216]
The information provided below includes a summary of transactions with VMware.  Transactions with related parties other than VMware during the periods presented were immaterial, individually and in aggregate.

[0001571996-23-000019:notes:217]
Transactions with VMware

[0001571996-23-000019:notes:218]
Dell Technologies and VMware engage in the following ongoing related party transactions:

[0001571996-23-000019:notes:219]
•Pursuant to original equipment manufacturer and reseller arrangements, Dell Technologies integrates or bundles VMware’s products and services with Dell Technologies’ products and sells them to end-users.  Dell Technologies also acts as a distributor, purchasing VMware’s standalone products and services for resale to end-user customers.  Where applicable, costs under these arrangements are presented net of rebates received by Dell Technologies.

[0001571996-23-000019:notes:220]
•Dell Technologies procures products and services from VMware for its internal use.  For the three months ended May 5, 2023 and April 29, 2022, costs incurred associated with products and services purchased from VMware for internal use were immaterial.

[0001571996-23-000019:notes:221]
•Dell Technologies sells and leases products and sells services to VMware.  For the three months ended May 5, 2023 and April 29, 2022, revenue recognized from sales of services to VMware was immaterial.

[0001571996-23-000019:notes:222]
•DFS provides financing to certain VMware end-users.  Upon acceptance of the financing arrangement by both VMware’s end-users and DFS, DFS recognizes amounts due to related parties on the Condensed Consolidated Statements of Financial Position.  Associated financing fees are recorded to product net revenue on the Condensed Consolidated Statements of Income and are reflected within sales and leases of products to VMware in the table below.

[0001571996-23-000019:notes:223]
•Dell Technologies and VMware also enter into joint marketing, sales, and branding arrangements, for which both parties may incur costs.  For the three months ended May 5, 2023 and April 29, 2022, consideration received from VMware for joint marketing, sales, and branding arrangements was immaterial.

[0001571996-23-000019:notes:224]
•Dell Technologies and VMware entered into a transition services agreement in connection with the VMware Spin-off to provide various support services, including investment advisory services, certain support services from Dell Technologies personnel, and other transitional services.  Costs associated with this agreement were immaterial for the three months ended April 29, 2022.  Activities under the agreement concluded during Fiscal 2023.

[0001571996-23-000019:notes:225]
The following table presents information about the impact of Dell Technologies’ related party transactions with VMware on the Condensed Consolidated Statements of Income for the periods indicated:

[0001571996-23-000019:notes:226]
|  |  |  |  |  | Three Months Ended |
|  | Classification |  |  |  |  |  | May 5, 2023 |  | April 29, 2022 |  |  |
|  |  |  |  |  |  |  | (in millions) |
| Sales and leases of products to VMware | Net revenue - products |  |  |  |  |  | $ | 40 |  |  | $ | 46 |  |  |  |
| Purchase of VMware products for resale | Cost of net revenue - products |  |  |  |  |  | $ | 207 |  |  | $ | 255 |  |  |  |
| Purchase of VMware services for resale | Cost of net revenue - services |  |  |  |  |  | $ | 876 |  |  | $ | 709 |  |  |  |

[0001571996-23-000019:notes:227]
The following table presents information about the impact of Dell Technologies’ related party transactions with VMware on the Condensed Consolidated Statements of Financial Position as of the dates indicated:

[0001571996-23-000019:notes:228]
|  | Classification |  | May 5, 2023 |  | February 3, 2023 |
|  |  |  | (in millions) |
| Deferred costs related to VMware products and services for resale | Other current assets |  | $ | 2,863 |  |  | $ | 3,000 |  |
| Deferred costs related to VMware products and services for resale | Other non-current assets |  | $ | 2,234 |  |  | $ | 2,537 |  |

[0001571996-23-000019:notes:229]
Due To/From Related Party

[0001571996-23-000019:notes:230]
The following table presents amounts due to and from VMware as of the dates indicated:

[0001571996-23-000019:notes:231]
|  | May 5, 2023 |  | February 3, 2023 |
|  | (in millions) |
| Due from related party, net, current (a) | $ | 384 |  |  | $ | 378 |  |
| Due from related party, net, non-current (b) | $ | 442 |  |  | $ | 440 |  |
| Due to related party, current (c) | $ | 594 |  |  | $ | 2,067 |  |

[0001571996-23-000019:notes:232]
(a)  Amounts due from related party, net, current consists of amounts due from VMware, inclusive of current net tax receivables from VMware under the Tax Agreements described below.  Amounts, excluding tax, are generally settled in cash within 60 days of each quarter-end.

[0001571996-23-000019:notes:233]
(b)  Amounts due from related party, net, non-current consists of the non-current portion of net receivables from VMware under the Tax Agreements.

[0001571996-23-000019:notes:234]
(c)  Amounts due to related party, current includes amounts due to VMware, which are generally settled in cash within 60 days of each quarter-end.

[0001571996-23-000019:notes:235]
Related Party Tax Matters

[0001571996-23-000019:notes:236]
Tax Agreements — In connection with the VMware Spin-off and concurrently with the execution of the Separation and Distribution Agreement, effective as of April 14, 2021, Dell Technologies and VMware entered into a Tax Matters Agreement (the “Tax Matters Agreement”) and agreed to terminate the tax sharing agreement as amended on December 30, 2019 (together with the Tax Matters Agreement, the “Tax Agreements”).  The Tax Matters Agreement governs Dell Technologies’ and VMware’s respective rights and obligations, both for pre-spin-off periods and post-spin-off periods, regarding income and other taxes, and related matters, including tax liabilities and benefits, attributes, and returns.

[0001571996-23-000019:notes:237]
The timing of the tax payments due to and from related parties is governed by the Tax Agreements.  VMware’s portion of the mandatory one-time transition tax on accumulated earnings of foreign subsidiaries (the “Transition Tax”) is governed by a letter agreement between VMware and Dell Technologies entered into on April 1, 2019.

[0001571996-23-000019:notes:238]
Pursuant to the Tax Agreements, net receipts from VMware during the three months ended May 5, 2023 and net payments to VMware during the three months ended April 29, 2022 were immaterial.

[0001571996-23-000019:notes:239]
As a result of the activity under the Tax Agreements with VMware, amounts due from VMware were $596 million and $599 million as of May 5, 2023 and February 3, 2023, respectively, primarily related to VMware’s estimated tax obligation resulting from the Transition Tax.  The 2017 Tax Cuts and Jobs Act included a deferral election for an eight-year installment payment method on the Transition Tax.  Dell Technologies expects VMware to pay the remainder of its Transition Tax over a period of three years.

[0001571996-23-000019:notes:240]
Indemnification — Upon consummation of the VMware Spin-off, Dell Technologies recorded net income tax indemnification receivables from VMware related to certain income tax liabilities for which Dell Technologies is jointly and severally liable, but for which it is indemnified by VMware under the Tax Matters Agreement.  The amounts that VMware may be obligated to pay Dell Technologies could vary depending on the outcome of certain unresolved tax matters, which may not be resolved for several years.  The net receivable as of May 5, 2023 and February 3, 2023 was $150 million and $146 million, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001571996-23-000019:notes:241]
[same as prior period, unchanged from 0001571996-22-000044:notes:265]

[0001571996-23-000019:notes:242]
ISG enables the Company’s customers’ digital transformation with solutions that address the fundamental shift to multicloud environments, machine learning, artificial intelligence, and data analytics.  The Company’s comprehensive storage portfolio includes traditional as well as next-generation storage solutions, including all-flash arrays, scale-out file, object platforms, hyperconverged infrastructure, and software-defined storage.  The Company’s server portfolio includes high-performance rack, blade, and tower servers.  The ISG networking portfolio helps the Company’s business customers transform and modernize their infrastructure, mobilize and enrich end-user experiences, and accelerate business applications and processes.  ISG also offers attached software, peripherals, and services, including support and deployment, configuration, and extended warranty services.

[0001571996-23-000019:notes:243]
[same as prior period, unchanged from 0001571996-22-000044:notes:267]

[0001571996-23-000019:notes:244]
[same as prior period, unchanged from 0001571996-22-000044:notes:268]

[0001571996-23-000019:notes:245]
Pursuant to the Commercial Framework Agreement (the “CFA”) established between Dell Technologies and VMware in association with the VMware Spin-off, Dell Technologies continues to act as a distributor of VMware’s standalone products and services and purchase such products and services for resale to end-user customers (“VMware Resale”).  Dell Technologies also continues to integrate VMware’s products and services with Dell Technologies’ offerings and sell them to end users.  The results of standalone VMware Resale transactions are reflected in other businesses.  The results of integrated offering transactions are reflected within CSG or ISG, depending upon the nature of the underlying offering sold.

[0001571996-23-000019:notes:246]
[same as prior period, unchanged from 0001571996-22-000044:notes:272]

[0001571996-23-000019:notes:247]
|  |  |  | Three Months Ended |
|  |  |  |  |  | May 5, 2023 |  | April 29, 2022 |
|  |  |  |  |  | (in millions) |
| Consolidated net revenue: |  |  |  |  |  |  |  |
| Infrastructure Solutions Group |  |  |  |  | $ | 7,593 |  |  | $ | 9,285 |  |
| Client Solutions Group |  |  |  |  | 11,983 |  |  | 15,587 |  |
| Reportable segment net revenue |  |  |  |  | 19,576 |  |  | 24,872 |  |
| Other businesses (a) |  |  |  |  | 1,343 |  |  | 1,239 |  |
| Unallocated transactions (b) |  |  |  |  | 3 |  |  | 5 |  |
| Total consolidated net revenue |  |  |  |  | $ | 20,922 |  |  | $ | 26,116 |  |
| Consolidated operating income: |  |  |  |  |  |  |  |
| Infrastructure Solutions Group |  |  |  |  | $ | 740 |  |  | $ | 1,082 |  |
| Client Solutions Group |  |  |  |  | 892 |  |  | 1,115 |  |
| Reportable segment operating income |  |  |  |  | 1,632 |  |  | 2,197 |  |
| Other businesses (a) |  |  |  |  | (36) |  |  | (64) |  |
| Unallocated transactions (b) |  |  |  |  | 2 |  |  | 2 |  |
| Impact of purchase accounting (c) |  |  |  |  | (4) |  |  | (9) |  |
| Amortization of intangibles |  |  |  |  | (199) |  |  | (243) |  |
| Transaction-related expenses (d) |  |  |  |  | (3) |  |  | (5) |  |
| Stock-based compensation expense (e) |  |  |  |  | (225) |  |  | (232) |  |
| Other corporate expenses (f) |  |  |  |  | (98) |  |  | (96) |  |
| Total consolidated operating income |  |  |  |  | $ | 1,069 |  |  | $ | 1,550 |  |

[0001571996-23-000019:notes:248]
[same as prior period, unchanged from 0001571996-22-000044:notes:274]

[0001571996-23-000019:notes:249]
[same as prior period, unchanged from 0001571996-22-000044:notes:275]

[0001571996-23-000019:notes:250]
[same as prior period, unchanged from 0001571996-22-000044:notes:276]

[0001571996-23-000019:notes:251]
(d)Transaction-related expenses includes acquisition, integration, and divestiture related costs.

[0001571996-23-000019:notes:252]
[same as prior period, unchanged from 0001571996-22-000044:notes:278]

[0001571996-23-000019:notes:253]
(f)Other corporate expenses includes impairment charges, incentive charges related to equity investments, severance, facility action, payroll taxes associated with stock-based compensation, and other costs.

[0001571996-23-000019:notes:254]
[same as prior period, unchanged from 0001571996-22-000044:notes:280]

[0001571996-23-000019:notes:255]
|  |  |  | Three Months Ended |
|  |  |  |  |  | May 5, 2023 |  | April 29, 2022 |
|  |  |  |  |  | (in millions) |
| Net revenue: |  |  |  |  |  |  |  |
| Infrastructure Solutions Group: |  |  |  |  |  |  |  |
| Servers and networking |  |  |  |  | $ | 3,837 |  |  | $ | 5,048 |  |
| Storage |  |  |  |  | 3,756 |  |  | 4,237 |  |
| Total ISG net revenue |  |  |  |  | $ | 7,593 |  |  | $ | 9,285 |  |
| Client Solutions Group: |  |  |  |  |  |  |  |
| Commercial |  |  |  |  | $ | 9,862 |  |  | $ | 11,971 |  |
| Consumer |  |  |  |  | 2,121 |  |  | 3,616 |  |
| Total CSG net revenue |  |  |  |  | $ | 11,983 |  |  | $ | 15,587 |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001571996-23-000019:notes:256]
[same as prior period, unchanged from 0001571996-22-000044:notes:282]

[0001571996-23-000019:notes:257]
|  | May 5, 2023 |  | February 3, 2023 |
|  | (in millions) |
| Cash, cash equivalents, and restricted cash: |  |  |  |
| Cash and cash equivalents | $ | 7,631 |  |  | $ | 8,607 |  |
| Restricted cash - other current assets (a) | 291 |  |  | 272 |  |
| Restricted cash - other non-current assets (a) | 5 |  |  | 15 |  |
| Total cash, cash equivalents, and restricted cash | $ | 7,927 |  |  | $ | 8,894 |  |
| Inventories, net: |  |  |  |
| Production materials | $ | 2,541 |  |  | $ | 3,225 |  |
| Work-in-process | 613 |  |  | 708 |  |
| Finished goods | 862 |  |  | 843 |  |
| Total inventories, net | $ | 4,016 |  |  | $ | 4,776 |  |
| Deferred Costs: |  |  |  |
| Total deferred costs, current (b) | $ | 5,433 |  |  | $ | 5,459 |  |
| Property, plant, and equipment, net: |  |  |  |
| Computer equipment | $ | 7,191 |  |  | $ | 6,899 |  |
| Land and buildings | 3,049 |  |  | 3,059 |  |
| Machinery and other equipment | 3,153 |  |  | 3,134 |  |
| Total property, plant, and equipment | 13,393 |  |  | 13,092 |  |
| Accumulated depreciation and amortization | (7,132) |  |  | (6,883) |  |
| Total property, plant, and equipment, net | $ | 6,261 |  |  | $ | 6,209 |  |

[0001571996-23-000019:notes:258]
[same as prior period, unchanged from 0001571996-22-000044:notes:284]

[0001571996-23-000019:notes:259]
(b)    Deferred costs are included in other current assets in the Condensed Consolidated Statements of Financial Position.  Amounts classified as long-term deferred costs are included in other non-current assets and are not disclosed above.

[0001571996-23-000019:notes:260]
Supply Chain Finance Program

[0001571996-23-000019:notes:261]
The Company maintains a Supply Chain Finance Program (the “SCF Program”), which enables eligible suppliers of the Company, at the supplier's sole discretion, to sell receivables due from the Company to a third-party financial institution.  The Company has no involvement in establishing the terms or conditions of the arrangement between its suppliers and the financial institution and no economic interest in a supplier's decision to sell a receivable.  Suppliers may elect to sell varying amounts of their outstanding receivables as part of the SCF Program.  The Company does not provide secured legal assets or other forms of guarantees under the arrangement.

[0001571996-23-000019:notes:262]
The SCF Program does not impact the Company's liquidity as payments for participating supplier invoices are remitted by the Company to the financial institution on the original invoice due date.  Further, the Company negotiates payment terms with suppliers regardless of their decision to participate in the SCF Program.  Payment terms with such suppliers vary and do not exceed 120 days.

[0001571996-23-000019:notes:263]
Any amounts due to the financial institution for suppliers participating in the SCF Program are recorded within Accounts Payable on the Company's Condensed Consolidated Statements of Financial Position and associated payments are included in cash flows from operating activities on the Condensed Consolidated Statements of Cash Flows.

[0001571996-23-000019:notes:264]
As of both May 5, 2023 and February 3, 2023, the Company had $1 billion included within Accounts Payable representing invoices due to suppliers confirmed as valid under the SCF Program.

[0001571996-23-000019:notes:265]
[same as prior period, unchanged from 0001571996-22-000044:notes:286]

[0001571996-23-000019:notes:266]
[same as prior period, unchanged from 0001571996-22-000044:notes:287]

[0001571996-23-000019:notes:267]
|  |  |  | Three Months Ended |
|  |  |  |  |  | May 5, 2023 |  | April 29, 2022 |  |  |
|  |  |  |  |  | (in millions) |
| Warranty liability: |  |  |  |  |  |  |  |  |  |
| Warranty liability at beginning of period |  |  |  |  | $ | 467 |  |  | $ | 480 |  |  |  |
| Costs accrued for new warranty contracts and changes in estimates for pre-existing warranties (a) |  |  |  |  | 196 |  |  | 223 |  |  |  |
| Service obligations honored |  |  |  |  | (225) |  |  | (235) |  |  |  |
| Warranty liability at end of period |  |  |  |  | $ | 438 |  |  | $ | 468 |  |  |  |

[0001571996-23-000019:notes:268]
[same as prior period, unchanged from 0001571996-22-000044:notes:289]

[0001571996-23-000019:notes:269]
Severance Charges

[0001571996-23-000019:notes:270]
The Company incurs costs related to employee severance and records a liability for these costs when it is probable that employees will be entitled to termination benefits and the amounts can be reasonably estimated.  The liability related to these actions is included in accrued and other current liabilities in the Condensed Consolidated Statements of Financial Position.

[0001571996-23-000019:notes:271]
During the three months ended May 5, 2023, the Company announced to its employees reorganizations and actions to align its investments more closely with its previously discussed strategic and customer priorities as it continues to take prudent steps in light of a challenging global economic environment.  These actions impacted approximately 5% of the Company’s workforce.  The Company recognized $367 million of expense associated with these actions in the fourth quarter of Fiscal 2023 and $48 million in the first quarter of Fiscal 2024.

[0001571996-23-000019:notes:272]
The following table presents the activity related to the Company’s severance liability for the periods indicated:

[0001571996-23-000019:notes:273]
|  | Three Months Ended |  |  |  |  |
|  | May 5, 2023 |  | April 29, 2022 |  |  |  |  |  |  |
|  | (in millions) |  |  |  |  |
| Severance liability: |  |  |  |  |  |  |  |  |  |
| Severance liability at beginning of period | $ | 408 |  |  | $ | 74 |  |  |  |  |  |  |  |
| Severance charges | 48 |  |  | 17 |  |  |  |  |  |  |  |
| Cash paid and other | (294) |  |  | (28) |  |  |  |  |  |  |  |
| Severance liability at end of period | $ | 162 |  |  | $ | 63 |  |  |  |  |  |  |  |

[0001571996-23-000019:notes:274]
[same as prior period, unchanged from 0001571996-22-000044:notes:290]

[0001571996-23-000019:notes:275]
[same as prior period, unchanged from 0001571996-22-000044:notes:291]

[0001571996-23-000019:notes:276]
|  |  |  | Three Months Ended |
|  |  |  |  |  | May 5, 2023 |  | April 29, 2022 |  |  |
|  |  |  |  |  | (in millions) |
| Interest and other, net: |  |  |  |  |  |  |  |  |  |
| Investment income, primarily interest |  |  |  |  | $ | 59 |  |  | $ | 15 |  |  |  |
| Gain (loss) on investments, net |  |  |  |  | (15) |  |  | 14 |  |  |  |
| Interest expense |  |  |  |  | (405) |  |  | (265) |  |  |  |
| Foreign exchange |  |  |  |  | (32) |  |  | (89) |  |  |  |
| Other |  |  |  |  | 29 |  |  | (12) |  |  |  |
| Total interest and other, net |  |  |  |  | $ | (364) |  |  | $ | (337) |  |  |  |


## us-gaap:SubsequentEventsTextBlock

[0001571996-23-000019:notes:277]
SUBSEQUENT EVENTS There were no known events occurring after May 5, 2023 and up until the date of issuance of this report that would materially affect the information presented herein.
