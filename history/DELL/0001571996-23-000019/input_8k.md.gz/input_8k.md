# DELL 8-K — 0001571996-23-000014 filed 2023-06-01

## item codes, every 8-K on or before 2023-06-12

- 2023-06-01 0001571996-23-000014 — 2.02, 9.01
- 2023-03-02 0001571996-23-000002 — 2.02, 5.02, 9.01
- 2023-02-06 0001193125-23-024781 — 7.01, 9.01
- 2023-01-24 0001193125-23-014260 — 1.01, 2.03, 9.01
- 2023-01-11 0001193125-23-006528 — 8.01, 9.01
- 2022-11-21 0001571996-22-000041 — 2.02, 9.01
- 2022-11-16 0001571996-22-000038 — 8.01
- 2022-08-25 0001571996-22-000028 — 2.02, 9.01
- 2022-07-18 0001193125-22-196334 — 2.03, 8.01
- 2022-06-29 0001571996-22-000025 — 3.03, 5.03, 5.07, 8.01, 9.01
- 2022-05-26 0001571996-22-000013 — 2.02, 9.01
- 2022-02-24 0001571996-22-000004 — 2.02, 8.01, 9.01
- 2021-12-20 0001193125-21-362482 — 8.01, 9.01
- 2021-12-15 0001193125-21-357927 — 1.01, 2.03, 9.01
- 2021-12-07 0001193125-21-349218 — 8.01, 9.01
- 2021-11-23 0001571996-21-000060 — 2.02, 9.01
- 2021-11-05 0001571996-21-000057 — 1.02, 2.01, 7.01, 8.01, 9.01 — amendment, the index does not say of what
- 2021-11-01 0001571996-21-000052 — 8.01, 9.01
- 2021-11-01 0001193125-21-315488 — 1.01, 1.02, 2.01, 8.01, 9.01
- 2021-10-21 0001193125-21-304052 — 8.01, 9.01
- 2021-10-19 0001571996-21-000050 — 8.01, 9.01
- 2021-10-07 0001193125-21-294210 — 8.01, 9.01
- 2021-09-30 0001571996-21-000047 — 5.02
- 2021-09-27 0001571996-21-000045 — 8.01
- 2021-09-23 0001193125-21-280190 — 7.01, 8.01, 9.01
- 2021-09-20 0001193125-21-276810 — 7.01, 9.01
- 2021-08-26 0001571996-21-000037 — 2.02, 9.01
- 2021-07-01 0001571996-21-000034 — 3.02
- 2021-06-24 0001571996-21-000031 — 5.07
- 2021-06-24 0001193125-21-197644 — 7.01, 9.01
- 2021-06-16 0001571996-21-000029 — 5.02
- 2021-05-27 0001571996-21-000019 — 2.02, 9.01
- 2021-05-03 0001571996-21-000010 — 8.01, 9.01
- 2021-04-14 0001193125-21-116271 — 1.01, 7.01, 9.01
- 2021-02-25 0001571996-21-000003 — 2.02, 9.01
- 2021-02-18 0001193125-21-047844 — 1.01, 2.03, 9.01
- 2020-11-24 0001571996-20-000048 — 2.02, 9.01
- 2020-08-27 0001571996-20-000041 — 2.02, 9.01
- 2020-07-02 0001571996-20-000037 — 5.07
- 2020-05-28 0001571996-20-000028 — 2.02, 9.01
- 2020-04-09 0001193125-20-102602 — 1.01, 2.03, 9.01
- 2020-04-08 0001571996-20-000021 — 5.02
- 2020-04-03 0001571996-20-000019 — 8.01, 9.01
- 2020-03-26 0001571996-20-000015 — 7.01
- 2020-02-27 0001571996-20-000009 — 2.02, 8.01, 9.01
- 2020-02-18 0001571996-20-000005 — 8.01, 9.01
- 2020-01-09 0001571996-20-000002 — 3.02
- 2020-01-06 0001193125-20-002200 — 3.02
- 2019-12-13 0001193125-19-313947 — 3.02
- 2019-12-10 0001571996-19-000052 — 5.02
- 2019-12-02 0001571996-19-000044 — 5.02, 7.01, 9.01
- 2019-11-26 0001571996-19-000042 — 2.02, 9.01
- 2019-09-23 0001193125-19-252192 — 1.01, 2.03, 9.01
- 2019-08-29 0001571996-19-000036 — 2.02, 9.01
- 2019-08-22 0001193125-19-226939 — 7.01, 8.01, 9.01
- 2019-07-11 0001571996-19-000032 — 5.02, 5.07, 9.01
- 2019-07-03 0001571996-19-000030 — 3.02
- 2019-06-27 0001571996-19-000028 — 3.02
- 2019-05-30 0001571996-19-000021 — 2.02, 9.01
- 2019-04-02 0001571996-19-000010 — 5.02
- 2019-03-21 0001193125-19-082281 — 1.01, 1.02, 2.03, 9.01
- 2019-03-19 0001571996-19-000005 — 5.02, 9.01
- 2019-03-14 0001193125-19-074935 — 1.01, 2.03, 9.01
- 2019-03-07 0001193125-19-066045 — 8.01, 9.01
- 2019-02-28 0001571996-19-000002 — 2.02, 9.01
- 2018-12-28 0001193125-18-360943 — 1.01, 1.02, 3.01, 3.03, 5.02, 5.03, 7.01, 8.01, 9.01
- 2018-12-21 0001193125-18-356324 — 1.01, 2.03, 9.01
- 2018-12-14 0001193125-18-349469 — 8.01
- 2018-12-11 0001193125-18-346958 — 5.07, 8.01, 9.01
- 2018-11-29 0001571996-18-000041 — 2.02, 9.01
- 2018-11-28 0001571996-18-000037 — 7.01, 8.01, 9.01
- 2018-11-26 0001193125-18-333967 — 8.01, 9.01
- 2018-11-15 0001193125-18-328110 — 1.01, 9.01 — amendment of 0001193125-18-327222
- 2018-11-15 0001193125-18-327222 — 1.01, 7.01, 9.01
- 2018-10-03 0001193125-18-291390 — 8.01
- 2018-09-06 0001571996-18-000029 — 2.02, 9.01
- 2018-08-06 0001571996-18-000027 — 8.01, 9.01
- 2018-07-02 0001193125-18-210339 — 1.01, 7.01, 9.01
- 2018-06-28 0001571996-18-000024 — 5.07
- 2018-06-04 0001571996-18-000019 — 2.02, 9.01
- 2018-05-17 0001571996-18-000016 — 7.01
- 2018-04-26 0001571996-18-000009 — 7.01, 9.01
- 2018-03-08 0001193125-18-074168 — 2.02, 9.01
- 2018-02-02 0001193125-18-029947 — 7.01, 9.01
- 2017-12-07 0001571996-17-000042 — 2.02, 9.01
- 2017-10-24 0001571996-17-000037 — 1.01, 2.03, 9.01
- 2017-09-15 0001571996-17-000027 — 5.02
- 2017-09-07 0001571996-17-000017 — 2.02, 9.01
- 2017-08-24 0001571996-17-000014 — 8.01
- 2017-06-29 0001571996-17-000011 — 3.03, 5.07, 8.01, 9.01
- 2017-06-08 0001193125-17-197638 — 2.02, 9.01
- 2017-03-30 0001193125-17-102794 — 8.01
- 2017-03-30 0001193125-17-102777 — 2.02, 9.01
- 2017-03-09 0001193125-17-076981 — 1.01, 2.03, 9.01
- 2017-01-17 0001193125-17-011125 — 8.01
- 2016-12-15 0001193125-16-793722 — 8.01
- 2016-12-08 0001193125-16-787976 — 2.02, 9.01
- 2016-11-10 0001193125-16-765964 — 1.02, 8.01
- 2016-11-04 0001193125-16-760249 — 8.01
- 2016-09-13 0001193125-16-708600 — 3.02
- 2016-09-09 0001193125-16-706567 — 1.01, 1.02, 2.01, 2.03, 3.02, 3.03, 5.02, 9.01
- 2016-09-07 0001193125-16-703370 — 3.03, 5.07, 7.01, 8.01, 9.01
- 2016-09-06 0001193125-16-702057 — 2.02, 9.01
- 2016-08-31 0001193125-16-697268 — 8.01, 9.01
- 2016-08-26 0001193125-16-692921 — 8.01, 9.01
- 2016-07-11 0001193125-16-645610 — 8.01
- 2016-07-05 0001193125-16-641679 — 8.01
- 2016-06-22 0001193125-16-629055 — 1.01, 2.03, 8.01, 9.01
- 2016-06-21 0001193125-16-627071 — 8.01, 9.01
- 2016-06-10 0001193125-16-618483 — 2.02, 9.01
- 2016-06-09 0001193125-16-617893 — 8.01, 9.01

## late-filing notifications on or before 2023-06-12

- none on or before 2023-06-12

## item 2.02 — earnings release, exhibit 99.1

[0001571996-23-000014:8k_2_02:1]
EX-99.1
2
exhibit991earnings8kq1fy24.htm
EX-99.1

[0001571996-23-000014:8k_2_02:2]
Document

[0001571996-23-000014:8k_2_02:3]
Exhibit 99.1

[0001571996-23-000014:8k_2_02:4]
Dell Technologies Delivers First Quarter Fiscal 2024 Financial Results

[0001571996-23-000014:8k_2_02:5]
News summary

[0001571996-23-000014:8k_2_02:6]
•First quarter revenue of $20.9 billion

[0001571996-23-000014:8k_2_02:7]
•Operating income of $1.1 billion and non-GAAP operating income of $1.6 billion

[0001571996-23-000014:8k_2_02:8]
•Diluted earnings per share at $0.79, and non-GAAP diluted earnings per share at $1.31

[0001571996-23-000014:8k_2_02:9]
•Cash flow from operations of $1.8 billion

[0001571996-23-000014:8k_2_02:10]
ROUND ROCK, Texas — June 1, 2023

[0001571996-23-000014:8k_2_02:11]
Full story

[0001571996-23-000014:8k_2_02:12]
Dell Technologies (NYSE: DELL) announces financial results for its fiscal 2024 first quarter. Revenue was $20.9 billion, down 20%. The company generated operating income of $1.1 billion and non-GAAP operating income of $1.6 billion, down 31% and 25%, respectively. Diluted earnings per share was $0.79, and non-GAAP diluted earnings per share was $1.31, down 42% and 29%, respectively. Cash flow from operations was $1.8 billion.

[0001571996-23-000014:8k_2_02:13]
“We executed well against a challenging economic backdrop,” said Chuck Whitten, co-chief operating officer, Dell Technologies. “We maintained pricing discipline, reduced operating expenses, and our supply chain continued to perform well after normalizing ahead of competitors. We announced a record number of innovations, making good on our promise to extend Dell APEX as-a-Service capabilities across our full portfolio and simplifying multicloud and edge computing for our customers.”

[0001571996-23-000014:8k_2_02:14]
Dell ended the quarter with remaining performance obligations of $39 billion, recurring revenue of $5.6 billion, up 6%, and deferred revenue of $29.7 billion, up 8%, due to increases in service and software maintenance agreements. Cash and investments were $9.2 billion, and the company returned $527 million to shareholders in the first quarter through share repurchases and dividends.

[0001571996-23-000014:8k_2_02:15]
“We continue to create value for stakeholders, with strong first quarter cash flow from operations of $1.8 billion,” said Tom Sweet, chief financial officer, Dell Technologies. “We’ve returned $5 billion to shareholders over the last six quarters, well ahead of our free cash flow return target, and we continue to invest in innovation that will fuel our growth.”

[0001571996-23-000014:8k_2_02:16]
First Quarter Fiscal 2024 Financial Results

[0001571996-23-000014:8k_2_02:17]
|  | Three Months Ended |  |  |
|  | May 5, 2023 |  | April 29, 2022 |  | Change |
|  | (in millions, except per share amounts and percentages; unaudited) |
| Total net revenue | $ | 20,922 |  |  | $ | 26,116 |  |  | (20)% |
| Operating income | $ | 1,069 |  |  | $ | 1,550 |  |  | (31)% |
| Net income | $ | 578 |  |  | $ | 1,069 |  |  | (46)% |
| Earnings per share - diluted | $ | 0.79 |  |  | $ | 1.37 |  |  | (42)% |
| Non-GAAP operating income | $ | 1,598 |  |  | $ | 2,135 |  |  | (25)% |
| Non-GAAP net income | $ | 963 |  |  | $ | 1,434 |  |  | (33)% |
| Non-GAAP earnings per share - diluted | $ | 1.31 |  |  | $ | 1.84 |  |  | (29)% |

[0001571996-23-000014:8k_2_02:18]
Information about Dell Technologies’ use of non-GAAP financial information is provided under “Non-GAAP Financial Measures” below. All comparisons in this press release are year-over-year unless otherwise noted.

[0001571996-23-000014:8k_2_02:19]
Infrastructure Solutions Group delivered first quarter revenue of $7.6 billion, down 18%. Storage revenue was $3.8 billion, with demand growth in the company’s software-defined storage and leading midrange storage array. Servers and networking revenue was $3.8 billion, with demand growth in AI optimized high value workload servers. Operating income was $740 million, or approximately 10% of Infrastructure Solutions Group revenue.

[0001571996-23-000014:8k_2_02:20]
Client Solutions Group delivered first quarter revenue of $12 billion, down 23%. Commercial revenue was $9.9 billion, and Consumer revenue was $2.1 billion. Operating income was $892 million, or approximately 7% of Client Solutions Group revenue.

[0001571996-23-000014:8k_2_02:21]
Key areas of innovation:

[0001571996-23-000014:8k_2_02:22]
•Multicloud: Introduced new cloud platforms with Microsoft, Red Hat and VMware that bring cloud operating models on premises, and announced storage for public cloud with AWS and Microsoft that brings enterprise block and file storage capabilities to public cloud.

[0001571996-23-000014:8k_2_02:23]
•Artificial Intelligence: Announced Project Helix, making Dell the first to collaborate with NVIDIA on full-stack solutions that help customers quickly and securely deploy generative AI on-premises at scale using their own proprietary data.

[0001571996-23-000014:8k_2_02:24]
•As a Service: Added compute and PCaaS and managed device services for client to Dell APEX, making the breadth of Dell’s portfolio available as a service or subscription.

[0001571996-23-000014:8k_2_02:25]
•Edge: Introduced Dell NativeEdge, an edge software platform that helps customers manage, simplify and secure their entire edge estate with a single solution.

[0001571996-23-000014:8k_2_02:26]
•Cybersecurity: Announced Project Fort Zero, which will make Dell the first company to deliver end-to-end Zero Trust with a fully integrated Advanced Zero Trust private cloud solution to be validated by the U.S. Department of Defense.

[0001571996-23-000014:8k_2_02:27]
2

[0001571996-23-000014:8k_2_02:28]
Operating Segments Results

[0001571996-23-000014:8k_2_02:29]
|  | Three Months Ended |  |  |
|  | May 5, 2023 |  | April 29, 2022 |  | Change |
| Infrastructure Solutions Group (ISG): |
| Net revenue: |  |  |  |  |  |
| Servers and networking | $ | 3,837 |  | $ | 5,048 |  | (24)% |
| Storage | 3,756 |  | 4,237 |  | (11)% |
| Total ISG net revenue | $ | 7,593 |  | $ | 9,285 |  | (18)% |
| Operating Income: |  |  |  |  |  |
| ISG operating income | $ | 740 |  | $ | 1,082 |  | (32)% |
| % of ISG net revenue | 9.7 | % |  | 11.7 | % |  |  |
| Client Solutions Group (CSG): |
| Net revenue: |  |  |  |  |  |
| Commercial | $ | 9,862 |  | $ | 11,971 |  | (18)% |
| Consumer | 2,121 |  | 3,616 |  | (41)% |
| Total CSG net revenue | $ | 11,983 |  | $ | 15,587 |  | (23)% |
| Operating Income: |  |  |  |  |  |
| CSG operating income | $ | 892 |  | $ | 1,115 |  | (20)% |
| % of CSG net revenue | 7.4 | % |  | 7.2 | % |  |  |

[0001571996-23-000014:8k_2_02:30]
Conference call information

[0001571996-23-000014:8k_2_02:31]
As previously announced, the company will hold a conference call to discuss its performance and financial guidance on June 1, 2023, at 3:30 p.m. CDT. Prior to the start of the conference call, prepared remarks and a presentation containing additional financial and operating information prior to financial guidance may be downloaded from investors.delltechnologies.com. The conference call will be broadcast live over the internet and can be accessed at https://investors.delltechnologies.com/news-events/upcoming-events

[0001571996-23-000014:8k_2_02:32]
For those unable to listen to the live broadcast, the final remarks and presentation with financial guidance will be available following the broadcast, and an archived version will be available at the same location for one year.

[0001571996-23-000014:8k_2_02:33]
Environmental, Social and Governance (ESG)

[0001571996-23-000014:8k_2_02:34]
Our Environmental, Social and Governance (ESG) efforts focus on driving positive impact for people and our planet while delivering long-term value for our stakeholders. The FY23 ESG report will be published in June, and the company will hold its annual investor conference call to discuss its ESG strategy on July 27. ESG resources can be accessed at https://www.dell.com/en-us/dt/corporate/social-impact/reporting/esg-governance.htm

[0001571996-23-000014:8k_2_02:35]
About Dell Technologies

[0001571996-23-000014:8k_2_02:36]
Dell Technologies (NYSE:DELL) helps organizations and individuals build their digital future and transform how they work, live and play. The company provides customers with the industry’s broadest and most innovative technology and services portfolio for the data era.

[0001571996-23-000014:8k_2_02:37]
3

[0001571996-23-000014:8k_2_02:38]
Contacts

[0001571996-23-000014:8k_2_02:39]
Investors: Investor_Relations@Dell.com

[0001571996-23-000014:8k_2_02:40]
Media: Media.Relations@Dell.com

[0001571996-23-000014:8k_2_02:41]
# # #

[0001571996-23-000014:8k_2_02:42]
Copyright © 2023 Dell Inc. or its subsidiaries. All Rights Reserved. Dell Technologies, Dell, EMC and Dell EMC are trademarks of Dell Inc. or its subsidiaries. Other trademarks may be trademarks of their respective owners.

[0001571996-23-000014:8k_2_02:43]
Non-GAAP Financial Measures:

[0001571996-23-000014:8k_2_02:44]
This press release presents information about non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, non-GAAP net income attributable to non-controlling interests, non-GAAP net income attributable to Dell Technologies Inc. – basic, non-GAAP net income attributable to Dell Technologies Inc. – diluted, non-GAAP earnings per share attributable to Dell Technologies Inc. – basic, and non-GAAP earnings per share attributable to Dell Technologies Inc. – diluted, which are non-GAAP financial measures provided as a supplement to the results provided in accordance with generally accepted accounting principles in the United States of America (“GAAP”). A reconciliation of each non-GAAP financial measure to the most directly comparable GAAP financial measure is provided in the attached tables for each of the fiscal periods indicated.

[0001571996-23-000014:8k_2_02:45]
Special Note on Forward-Looking Statements:

[0001571996-23-000014:8k_2_02:46]
Dell Technologies’ results or events in future periods could differ materially from those expressed or implied by these forward-looking statements because of risks, uncertainties, and other factors that include, but are not limited to, the following: adverse global economic conditions and instability in financial markets; competitive pressures; Dell Technologies’ reliance on third-party suppliers for products and components, including reliance on single-source or limited-source suppliers; Dell Technologies’ ability to achieve favorable pricing from its vendors; Dell Technologies’ ability to achieve  the intended benefits of its continuing strategic relationship with VMware, Inc.; Dell Technologies’ execution of its strategy; Dell Technologies’ ability to manage solutions and products and services transitions in an effective manner; Dell Technologies’ ability to deliver high-quality products, software, and services; cyber attacks or other data security incidents; Dell Technologies’ ability to successfully execute on strategic initiatives including acquisitions, divestitures or cost savings measures; Dell Technologies’ foreign operations and ability to generate substantial non-U.S. net revenue; Dell Technologies’ product, services, customer, and geographic sales mix, and seasonal sales trends; the performance of Dell Technologies’ sales channel partners; access to the capital markets by Dell Technologies or its customers; material impairment of the value of goodwill or intangible assets; weak economic conditions and the effect of additional regulation on Dell Technologies’ financial services activities; counterparty default risks; the loss by Dell Technologies of any contracts for ISG services and solutions and its ability to perform such contracts at their estimated costs; loss by Dell Technologies of government contracts; Dell Technologies’ ability to develop and protect its proprietary intellectual property or obtain licenses to intellectual property developed by others on commercially reasonable and competitive terms; disruptions in Dell Technologies’ infrastructure; Dell Technologies’ ability to hedge effectively its exposure to fluctuations in foreign currency exchange rates and interest rates; expiration of tax holidays or favorable tax rate structures, or unfavorable outcomes in tax audits and other tax compliance matters; impairment of portfolio investments; unfavorable results of legal proceedings; expectations relating to environmental, social and governance (ESG) considerations; compliance requirements of changing environmental and safety laws, human rights laws, or other laws; the effect of armed hostilities, terrorism, natural disasters, or public health issues; the effect of global climate change and legal, regulatory, or market measures to address climate change; Dell Technologies’ dependence on the services of Michael Dell and key employees; Dell Technologies’ level of indebtedness; and business and financial factors and legal restrictions affecting continuation of Dell Technologies’ quarterly cash dividend policy and dividend rate.

[0001571996-23-000014:8k_2_02:47]
This list of risks, uncertainties, and other factors is not complete. Dell Technologies discusses some of these matters more fully, as well as certain risk factors that could affect Dell Technologies’ business, financial condition, results of operations, and prospects, in its reports filed with the SEC, including Dell Technologies’ annual report on Form 10-K for the fiscal year ended February 3, 2023, quarterly reports on Form 10-Q, and current reports on Form 8-K. These filings are available for review through the SEC’s website at www.sec.gov. Any or all forward-looking statements Dell Technologies makes may turn out to be wrong and can be affected by inaccurate assumptions Dell Technologies might make or by known or unknown risks, uncertainties, and other factors, including those identified in this press release. Accordingly, you should not place undue reliance on the forward-looking statements made in this press release, which speak only as of its date. Dell Technologies does not undertake to update, and expressly disclaims any duty to update, its forward-looking statements, whether as a result of circumstances or events that arise after the date they are made, new information, or otherwise.

[0001571996-23-000014:8k_2_02:48]
4

[0001571996-23-000014:8k_2_02:49]
DELL TECHNOLOGIES INC.

[0001571996-23-000014:8k_2_02:50]
Consolidated Statements of Income and Related Financial Highlights

[0001571996-23-000014:8k_2_02:51]
(in millions, except percentages; unaudited)

[0001571996-23-000014:8k_2_02:52]
|  | Three Months Ended |  |  |
|  | May 5, 2023 |  | April 29, 2022 |  | Change |
| Net revenue: |  |  |  |  |  |
| Products | $ | 15,036 |  | $ | 20,464 |  | (27)% |
| Services | 5,886 |  | 5,652 |  | 4% |
| Total net revenue | 20,922 |  | 26,116 |  | (20)% |
| Cost of net revenue: |  |  |  |  |  |
| Products | 12,375 |  | 17,009 |  | (27)% |
| Services | 3,529 |  | 3,323 |  | 6% |
| Total cost of net revenue | 15,904 |  | 20,332 |  | (22)% |
| Gross margin | 5,018 |  | 5,784 |  | (13)% |
| Operating expenses: |  |  |  |  |  |
| Selling, general, and administrative | 3,261 |  | 3,553 |  | (8)% |
| Research and development | 688 |  | 681 |  | 1% |
| Total operating expenses | 3,949 |  | 4,234 |  | (7)% |
| Operating income | 1,069 |  | 1,550 |  | (31)% |
| Interest and other, net | (364) |  | (337) |  | (8)% |
| Income before income taxes | 705 |  | 1,213 |  | (42)% |
| Income tax expense | 127 |  | 144 |  | (12)% |
| Net income | 578 |  | 1,069 |  | (46)% |
| Less: Net loss attributable to non-controlling interests | (5) |  | (3) |  | (67)% |
| Net income attributable to Dell Technologies Inc. | $ | 583 |  | $ | 1,072 |  | (46)% |
| Percentage of Total Net Revenue: |  |  |  |  |  |
| Gross margin | 24.0 | % |  | 22.1 | % |  |  |
| Selling, general, and administrative | 15.6 | % |  | 13.6 | % |  |  |
| Research and development | 3.3 | % |  | 2.6 | % |  |  |
| Operating expenses | 18.9 | % |  | 16.2 | % |  |  |
| Operating income | 5.1 | % |  | 5.9 | % |  |  |
| Income before income taxes | 3.4 | % |  | 4.6 | % |  |  |
| Net income | 2.8 | % |  | 4.1 | % |  |  |
| Income tax rate | 18.0 | % |  | 11.9 | % |  |  |

[0001571996-23-000014:8k_2_02:53]
Amounts are based on underlying data and may not visually foot due to rounding.

[0001571996-23-000014:8k_2_02:54]
5

[0001571996-23-000014:8k_2_02:55]
DELL TECHNOLOGIES INC.

[0001571996-23-000014:8k_2_02:56]
Consolidated Statements of Financial Position

[0001571996-23-000014:8k_2_02:57]
(in millions; unaudited)

[0001571996-23-000014:8k_2_02:58]
|  | May 5, 2023 |  | February 3, 2023 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 7,631 |  |  | $ | 8,607 |  |
| Accounts receivable, net | 9,399 |  |  | 12,482 |  |
| Due from related party, net | 384 |  |  | 378 |  |
| Short-term financing receivables, net | 5,013 |  |  | 5,281 |  |
| Inventories | 4,016 |  |  | 4,776 |  |
| Other current assets | 10,949 |  |  | 10,827 |  |
| Total current assets | 37,392 |  |  | 42,351 |  |
| Property, plant, and equipment, net | 6,261 |  |  | 6,209 |  |
| Long-term investments | 1,399 |  |  | 1,518 |  |
| Long-term financing receivables, net | 5,524 |  |  | 5,638 |  |
| Goodwill | 19,661 |  |  | 19,676 |  |
| Intangible assets, net | 6,269 |  |  | 6,468 |  |
| Due from related party, net | 442 |  |  | 440 |  |
| Other non-current assets | 7,146 |  |  | 7,311 |  |
| Total assets | $ | 84,094 |  |  | $ | 89,611 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Short-term debt | $ | 5,470 |  |  | $ | 6,573 |  |
| Accounts payable | 17,796 |  |  | 18,598 |  |
| Due to related party | 594 |  |  | 2,067 |  |
| Accrued and other | 7,438 |  |  | 8,874 |  |
| Short-term deferred revenue | 15,527 |  |  | 15,542 |  |
| Total current liabilities | 46,825 |  |  | 51,654 |  |
| Long-term debt | 22,962 |  |  | 23,015 |  |
| Long-term deferred revenue | 14,168 |  |  | 14,744 |  |
| Other non-current liabilities | 3,063 |  |  | 3,223 |  |
| Total liabilities | 87,018 |  |  | 92,636 |  |
| Stockholders’ equity (deficit): |  |  |  |
| Total Dell Technologies Inc. stockholders’ equity (deficit) | (3,023) |  |  | (3,122) |  |
| Non-controlling interests | 99 |  |  | 97 |  |
| Total stockholders’ equity (deficit) | (2,924) |  |  | (3,025) |  |
| Total liabilities and stockholders’ equity | $ | 84,094 |  |  | $ | 89,611 |  |

[0001571996-23-000014:8k_2_02:59]
DELL TECHNOLOGIES INC.

[0001571996-23-000014:8k_2_02:60]
Consolidated Statements of Cash Flows

[0001571996-23-000014:8k_2_02:61]
(in millions; unaudited)

[0001571996-23-000014:8k_2_02:62]
|  | Three Months Ended |
|  | May 5, 2023 |  | April 29, 2022 |
| Cash flows from operating activities: |  |  |  |
| Net income | $ | 578 |  |  | $ | 1,069 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: | 1,199 |  |  | (1,338) |  |
| Change in cash from operating activities | 1,777 |  |  | (269) |  |
| Cash flows from investing activities: |  |  |  |
| Purchases of investments | (15) |  |  | (52) |  |
| Maturities and sales of investments | 19 |  |  | 18 |  |
| Capital expenditures and capitalized software development costs | (701) |  |  | (690) |  |
| Other | 13 |  |  | 4 |  |
| Change in cash from investing activities | (684) |  |  | (720) |  |
| Cash flows from financing activities: |  |  |  |
| Proceeds from the issuance of common stock | 2 |  |  | 4 |  |
| Repurchases of common stock | (240) |  |  | (1,436) |  |
| Repurchases of common stock - withholdings on employee equity awards | (306) |  |  | (350) |  |
| Payments of dividends and dividend equivalents | (276) |  |  | (248) |  |
| Proceeds from debt | 2,521 |  |  | 3,034 |  |
| Repayments of debt | (3,698) |  |  | (2,703) |  |
| Debt-related costs and other, net | (5) |  |  | (7) |  |
| Change in cash from financing activities | (2,002) |  |  | (1,706) |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash | (58) |  |  | (111) |  |
| Change in cash, cash equivalents, and restricted cash | (967) |  |  | (2,806) |  |
| Cash, cash equivalents, and restricted cash at beginning of the period | 8,894 |  |  | 10,082 |  |
| Cash, cash equivalents, and restricted cash | $ | 7,927 |  |  | $ | 7,276 |  |

[0001571996-23-000014:8k_2_02:63]
7

[0001571996-23-000014:8k_2_02:64]
DELL TECHNOLOGIES INC.

[0001571996-23-000014:8k_2_02:65]
Segment Information

[0001571996-23-000014:8k_2_02:66]
(in millions, except percentages; unaudited; continued on next page)

[0001571996-23-000014:8k_2_02:67]
|  | Three Months Ended |  |  |
|  | May 5, 2023 |  | April 29, 2022 |  | Change |
| Infrastructure Solutions Group (ISG): |
| Net revenue: |  |  |  |  |  |
| Servers and networking | $ | 3,837 |  | $ | 5,048 |  | (24)% |
| Storage | 3,756 |  | 4,237 |  | (11)% |
| Total ISG net revenue | $ | 7,593 |  | $ | 9,285 |  | (18)% |
| Operating Income: |  |  |  |  |  |
| ISG operating income | $ | 740 |  | $ | 1,082 |  | (32)% |
| % of ISG net revenue | 9.7 | % |  | 11.7 | % |  |  |
| % of total reportable segment operating income | 45 | % |  | 49 | % |  |  |
| Client Solutions Group (CSG): |
| Net revenue: |  |  |  |  |  |
| Commercial | $ | 9,862 |  | $ | 11,971 |  | (18)% |
| Consumer | 2,121 |  | 3,616 |  | (41)% |
| Total CSG net revenue | $ | 11,983 |  | $ | 15,587 |  | (23)% |
| Operating Income: |  |  |  |  |  |
| CSG operating income | $ | 892 |  | $ | 1,115 |  | (20)% |
| % of CSG net revenue | 7.4 | % |  | 7.2 | % |  |  |
| % of total reportable segment operating income | 55 | % |  | 51 | % |  |  |

[0001571996-23-000014:8k_2_02:68]
Amounts are based on underlying data and may not visually foot due to rounding.

[0001571996-23-000014:8k_2_02:69]
DELL TECHNOLOGIES INC.

[0001571996-23-000014:8k_2_02:70]
Segment Information

[0001571996-23-000014:8k_2_02:71]
(in millions, except percentages; unaudited; continued)

[0001571996-23-000014:8k_2_02:72]
|  | Three Months Ended |
|  | May 5, 2023 |  | April 29, 2022 |
| Reconciliation to consolidated net revenue: |  |  |
| Reportable segment net revenue | $ | 19,576 |  |  | $ | 24,872 |  |
| Other businesses (a) | 1,343 |  |  | 1,239 |  |
| Unallocated transactions (b) | 3 |  |  | 5 |  |
| Total consolidated net revenue | $ | 20,922 |  |  | $ | 26,116 |  |
| Reconciliation to consolidated operating income: |  |  |  |
| Reportable segment operating income | $ | 1,632 |  |  | $ | 2,197 |  |
| Other businesses (a) | (36) |  |  | (64) |  |
| Unallocated transactions (b) | 2 |  |  | 2 |  |
| Impact of purchase accounting (c) | (4) |  |  | (9) |  |
| Amortization of intangibles | (199) |  |  | (243) |  |
| Transaction-related (income) expenses (d) | (3) |  |  | (5) |  |
| Stock-based compensation expense (e) | (225) |  |  | (232) |  |
| Other corporate expenses (f) | (98) |  |  | (96) |  |
| Total consolidated operating income | $ | 1,069 |  |  | $ | 1,550 |  |

[0001571996-23-000014:8k_2_02:73]
_________________

[0001571996-23-000014:8k_2_02:74]
(a)Other businesses consists of: 1) Dell’s resale of standalone VMware, Inc. products and services, “VMware Resale,” 2) Secureworks, and 3) Virtustream, and do not meet the requirements for a reportable segment, either individually or collectively.

[0001571996-23-000014:8k_2_02:75]
(b)Unallocated transactions includes other corporate items that are not allocated to Dell Technologies’ reportable segments.

[0001571996-23-000014:8k_2_02:76]
(c)Impact of purchase accounting includes non-cash purchase accounting adjustments that are primarily related to the EMC merger transaction.

[0001571996-23-000014:8k_2_02:77]
(d)Transaction-related (income) expenses includes acquisition, integration, and divestiture related costs. From time to time, this category also may include transaction-related income related to divestitures of businesses or asset sales.

[0001571996-23-000014:8k_2_02:78]
(e)Stock-based compensation expense consists of equity awards granted based on the estimated fair value of those awards at grant date.

[0001571996-23-000014:8k_2_02:79]
(f)Other corporate expenses includes impairment charges, incentive charges related to equity investments, severance, payroll taxes associated with stock-based compensation, facilities action, and other costs.

[0001571996-23-000014:8k_2_02:80]
9

[0001571996-23-000014:8k_2_02:81]
SUPPLEMENTAL SELECTED NON-GAAP FINANCIAL MEASURES

[0001571996-23-000014:8k_2_02:82]
These tables present information about the Company’s non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, non-GAAP net income attributable to Dell Technologies Inc. - basic and diluted, non-GAAP earnings per share attributable to Dell Technologies Inc. - basic, and non-GAAP earnings per share attributable to Dell Technologies Inc. - diluted, which are non-GAAP financial measures provided as a supplement to the results provided in accordance with generally accepted accounting principles in the United States of America (“GAAP”). A detailed discussion of Dell Technologies’ reasons for including these non-GAAP financial measures, the limitations associated with these measures, the items excluded from these measures, and our reason for excluding those items are presented in “Management’s Discussion and Analysis of Financial Condition and Results of Operations — Non-GAAP Financial Measures” in our periodic reports filed with the SEC. Dell Technologies encourages investors to review the non-GAAP discussion in these reports in conjunction with the presentation of non-GAAP financial measures.

[0001571996-23-000014:8k_2_02:83]
10

[0001571996-23-000014:8k_2_02:84]
DELL TECHNOLOGIES INC.

[0001571996-23-000014:8k_2_02:85]
Selected Financial Measures

[0001571996-23-000014:8k_2_02:86]
(in millions, except per share amounts and percentages; unaudited)

[0001571996-23-000014:8k_2_02:87]
|  | Three Months Ended |  |  |
|  | May 5, 2023 |  | April 29, 2022 |  | Change |
| Net revenue (a) | $ | 20,922 |  | $ | 26,116 |  | (20)% |
| Non-GAAP gross margin | $ | 5,164 |  | $ | 5,941 |  | (13)% |
| % of non-GAAP net revenue | 24.7 | % |  | 22.7 | % |  |  |
| Non-GAAP operating expenses | $ | 3,566 |  | $ | 3,806 |  | (6)% |
| % of non-GAAP net revenue | 17.1 | % |  | 14.5 | % |  |  |
| Non-GAAP operating income | $ | 1,598 |  | $ | 2,135 |  | (25)% |
| % of non-GAAP net revenue | 7.6 | % |  | 8.2 | % |  |  |
| Non-GAAP net income | $ | 963 |  | $ | 1,434 |  | (33)% |
| % of non-GAAP net revenue | 4.5 | % |  | 5.5 | % |  |  |
| Non-GAAP earnings per share - diluted | $ | 1.31 |  | $ | 1.84 |  | (29)% |

[0001571996-23-000014:8k_2_02:88]
____________________

[0001571996-23-000014:8k_2_02:89]
(a)    Effective in the first quarter of Fiscal 2023, non-GAAP net revenue no longer differs from net revenue, the most comparable GAAP financial measure.

[0001571996-23-000014:8k_2_02:90]
Amounts are based on underlying data and may not visually foot due to rounding.

[0001571996-23-000014:8k_2_02:91]
DELL TECHNOLOGIES INC.

[0001571996-23-000014:8k_2_02:92]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-23-000014:8k_2_02:93]
(in millions, except percentages; unaudited; continued on next page)

[0001571996-23-000014:8k_2_02:94]
|  | Three Months Ended |  |  |
|  | May 5, 2023 |  | April 29, 2022 |  | Change |
| Gross margin | $ | 5,018 |  |  | $ | 5,784 |  |  | (13)% |
| Non-GAAP adjustments: |  |  |  |  |  |
| Amortization of intangibles | 79 |  |  | 104 |  |  |  |
| Impact of purchase accounting | — |  |  | 2 |  |  |  |
| Stock-based compensation expense | 38 |  |  | 38 |  |  |  |
| Other corporate expenses | 29 |  |  | 13 |  |  |  |
| Non-GAAP gross margin | $ | 5,164 |  |  | $ | 5,941 |  |  | (13)% |
| Operating expenses | $ | 3,949 |  |  | $ | 4,234 |  |  | (7)% |
| Non-GAAP adjustments: |  |  |  |  |  |
| Amortization of intangibles | (120) |  |  | (139) |  |  |  |
| Impact of purchase accounting | (4) |  |  | (7) |  |  |  |
| Transaction-related (income) expenses | (3) |  |  | (5) |  |  |  |
| Stock-based compensation expense | (187) |  |  | (194) |  |  |  |
| Other corporate expenses | (69) |  |  | (83) |  |  |  |
| Non-GAAP operating expenses | $ | 3,566 |  |  | $ | 3,806 |  |  | (6)% |
| Operating income | $ | 1,069 |  |  | $ | 1,550 |  |  | (31)% |
| Non-GAAP adjustments: |  |  |  |  |  |
| Amortization of intangibles | 199 |  |  | 243 |  |  |  |
| Impact of purchase accounting | 4 |  |  | 9 |  |  |  |
| Transaction-related expenses | 3 |  |  | 5 |  |  |  |
| Stock-based compensation expense | 225 |  |  | 232 |  |  |  |
| Other corporate expenses | 98 |  |  | 96 |  |  |  |
| Non-GAAP operating income | $ | 1,598 |  |  | $ | 2,135 |  |  | (25)% |
| Net income | $ | 578 |  |  | $ | 1,069 |  |  | (46)% |
| Non-GAAP adjustments: |  |  |  |  |  |
| Amortization of intangibles | 199 |  |  | 243 |  |  |  |
| Impact of purchase accounting | 4 |  |  | 9 |  |  |  |
| Transaction-related (income) expenses | (1) |  |  | (2) |  |  |  |
| Stock-based compensation expense | 225 |  |  | 232 |  |  |  |
| Other corporate expenses | 99 |  |  | 96 |  |  |  |
| Fair value adjustments on equity investments | 15 |  |  | (14) |  |  |  |
| Aggregate adjustment for income taxes | (156) |  |  | (199) |  |  |  |
| Non-GAAP net income | $ | 963 |  |  | $ | 1,434 |  |  | (33)% |

[0001571996-23-000014:8k_2_02:95]
12

[0001571996-23-000014:8k_2_02:96]
DELL TECHNOLOGIES INC.

[0001571996-23-000014:8k_2_02:97]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-23-000014:8k_2_02:98]
(in millions, except percentages and per share amounts; unaudited; continued)

[0001571996-23-000014:8k_2_02:99]
|  | For the Three Months Ended May 5, 2023 |
|  | GAAP |  | Amortization of intangibles |  | Impact of purchase accounting |  | Transaction-related expenses |  | Stock-based compensation expense |  | Other corporate expenses |  | Fair value adjustments on equity investments |  | Aggregate adjustment for income taxes |  | Aggregate adjustment for non-controlling interests |  | Non-GAAP |
| Net income attributable to Dell Technologies Inc. - basic | $ | 583 |  |  | 199 |  |  | 4 |  |  | (1) |  |  | 225 |  |  | 99 |  |  | 15 |  |  | (156) |  |  | (2) |  |  | $ | 966 |  |
| Earnings per share - basic | $ | 0.81 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 1.33 |  |
| Earnings per share - diluted | $ | 0.79 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 1.31 |  |
| Weighted-average shares outstanding - basic | 724 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 724 |  |
| Weighted-average shares outstanding - diluted | 737 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 737 |  |

[0001571996-23-000014:8k_2_02:100]
|  | For the Three Months Ended April 29, 2022 |
|  | GAAP |  | Amortization of intangibles |  | Impact of purchase accounting |  | Transaction-related expenses |  | Stock-based compensation expense |  | Other corporate expenses |  | Fair value adjustments on equity investments |  | Aggregate adjustment for income taxes |  | Aggregate adjustment for non-controlling interests |  | Non-GAAP |
| Net income attributable to Dell Technologies Inc. - basic | $ | 1,072 |  |  | 243 |  |  | 9 |  |  | (2) |  |  | 232 |  |  | 96 |  |  | (14) |  |  | (199) |  |  | (2) |  |  | $ | 1,435 |  |
| Earnings per share - basic | $ | 1.42 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 1.90 |  |
| Earnings per share - diluted | $ | 1.37 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 1.84 |  |
| Weighted-average shares outstanding - basic | 754 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 754 |  |
| Weighted-average shares outstanding - diluted | 780 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 780 |  |

[0001571996-23-000014:8k_2_02:101]
13
