# DELL MD&A — 0001571996-25-000102


## mdna

[0001571996-25-000102:mdna:1]
[same as prior period, unchanged from 0001571996-25-000063:mdna:1]

[0001571996-25-000102:mdna:2]
[same as prior period, unchanged from 0001571996-25-000063:mdna:2]

[0001571996-25-000102:mdna:3]
[same as prior period, unchanged from 0001571996-25-000063:mdna:3]

[0001571996-25-000102:mdna:4]
[same as prior period, unchanged from 0001571996-25-000063:mdna:4]

[0001571996-25-000102:mdna:5]
[same as prior period, unchanged from 0001571996-25-000063:mdna:5]

[0001571996-25-000102:mdna:6]
[same as prior period, unchanged from 0001571996-25-000063:mdna:6]

[0001571996-25-000102:mdna:7]
[same as prior period, unchanged from 0001571996-25-000063:mdna:7]

[0001571996-25-000102:mdna:8]
[same as prior period, unchanged from 0001571996-25-000063:mdna:8]

[0001571996-25-000102:mdna:9]
[same as prior period, unchanged from 0001571996-25-000063:mdna:9]

[0001571996-25-000102:mdna:10]
[same as prior period, unchanged from 0001571996-25-000063:mdna:10]

[0001571996-25-000102:mdna:11]
Our other businesses primarily consist of our historical resale of standalone offerings of VMware LLC (formerly VMware, Inc. and individually and together with its subsidiaries, “VMware”), referred to as “VMware Resale,” and offerings of SecureWorks Corp. (“Secureworks”) through the date of the sale of Secureworks as discussed below. These businesses are divested businesses or their offerings are no longer actively sold, and are not classified as reportable segments, either individually or collectively. Their operating results are reported within Corporate and other. On February 3, 2025, the sale of Secureworks to Sophos Inc., an affiliate of Thoma Bravo, L.P., was completed in an all-cash transaction for a purchase price of approximately $0.9 billion. We received total cash consideration for the equity interest held in Secureworks of approximately $0.6 billion, resulting in a gain on sale recorded of $0.2 billion recognized in interest and other, net in the Condensed Consolidated Statements of Income during the six months ended August 1, 2025.

[0001571996-25-000102:mdna:12]
49

[0001571996-25-000102:mdna:13]
[same as prior period, unchanged from 0001571996-25-000063:mdna:12]

[0001571996-25-000102:mdna:14]
We offer customers choices in how they acquire our solutions, including traditional purchasing and offerings under the Dell Payment Solutions portfolio. These offerings provide both payment and consumption solutions, including utility, subscription, as-a-Service, leases, and loans, which allow our customers to pay over time and provide them with operational and financial flexibility. Dell Financial Services and its affiliates (“DFS”) support financing solutions and services as part of the portfolio. For additional information about our financing arrangements, see Note 4 of the Notes to the Condensed Consolidated Financial Statements included in this report.

[0001571996-25-000102:mdna:15]
[same as prior period, unchanged from 0001571996-25-000063:mdna:14]

[0001571996-25-000102:mdna:16]
During the second quarter and first six months of Fiscal 2026, we executed our strategy with strong operating results, generating overall net revenue and operating income growth. The following trends and conditions affected the environment in which we operated:

[0001571996-25-000102:mdna:17]
•Macroeconomic environment: Demand significantly increased for our AI-optimized server offerings, resulting in ISG net revenue growth and a shift in the mix of the business towards our ISG offerings. Additionally, we experienced moderate net revenue growth in our traditional servers and networking offerings and commercial offerings, although demand moderated in our domestic market as customers reevaluated spending in the current macroeconomic environment.

[0001571996-25-000102:mdna:18]
•Demand of AI-optimized solutions: Our ISG business continued to benefit from significant increased demand for AI-optimized solutions as customers continue to adopt and further integrate AI. While backlog levels remain elevated compared to the prior year, significant shipments in the current quarter resulted in a sequential backlog decline. Given the scale of the AI opportunities, the varying stages of customer readiness, and the frequency of component part updates or transitions, there is inherent non-linearity in the timing of demand and subsequent shipments for our AI-optimized server offerings, which continues to drive variability in our revenue.

[0001571996-25-000102:mdna:19]
•Technology refresh in core markets: Within our CSG business, the PC refresh cycle is underway as customers have begun upgrading their devices, which has contributed to increased demand for our commercial offerings and modest CSG net revenue growth. Additionally, within our ISG business, we continue to see customers modernize and consolidate their data centers as more customers transition to next-generation products, which has contributed to moderate net revenue growth within our traditional servers and networking offerings.

[0001571996-25-000102:mdna:20]
[same as prior period, unchanged from 0001571996-25-000063:mdna:19]

[0001571996-25-000102:mdna:21]
We expect net revenue growth for the full fiscal year driven by ISG and CSG net revenue, most notably within ISG. We expect ISG net revenue growth driven by demand growth across our servers and networking offerings, largely in our AI-optimized server offerings. While we expect overall ISG net revenue growth, we anticipate demand moderation to persist into the second half of the year within our traditional servers and networking offerings and storage offerings as customers within our domestic market continue to reevaluate IT spending behavior due to uncertainty in the macroeconomic environment. We expect modest CSG net revenue growth driven in part by the continuation of the PC refresh cycle. Additionally, we expect a continued reduction of our Corporate and other net revenue driven by offerings that are no longer actively sold and businesses that have been divested.

[0001571996-25-000102:mdna:22]
We expect input costs to remain flat for the remainder of Fiscal 2026. Input cost trends are dependent on the strength or weakness of actual end-user demand and supply dynamics, which will continue to fluctuate and ultimately impact our costs, pricing, and operating results.

[0001571996-25-000102:mdna:23]
50

[0001571996-25-000102:mdna:24]
[same as prior period, unchanged from 0001571996-25-000063:mdna:22]

[0001571996-25-000102:mdna:25]
We continue to advance our own capabilities to change the way we work and make decisions, improve business outcomes and the customer experience, and reduce costs by leveraging new technology and optimizing business processes. We remain committed to disciplined cost management in coordination with our ongoing business modernization initiatives and expect continued reductions in operating expenses as we take targeted measures to reduce costs, including employee reorganizations, limitation of external hiring, and other actions to align our investments with our strategic priorities and customer needs. We anticipate these actions will result in additional reductions in our overall headcount. We believe our unique operating advantages provide a foundation to foster business growth, enable innovation, drive efficiencies, and continue to position us for long-term success.

[0001571996-25-000102:mdna:26]
[same as prior period, unchanged from 0001571996-25-000063:mdna:24]

[0001571996-25-000102:mdna:27]
ISG — We expect that ISG will be influenced by the dynamic nature of the IT infrastructure market and the competitive landscape. With our extensive scale and market-leading solutions portfolio, we believe we are well positioned to navigate these competitive dynamics and evolving technology trends to meet customer needs. By leveraging our collaborative, customer-focused approach to innovation, we aim to deliver relevant new and next-generation solutions and software to our customers swiftly and efficiently. We remain focused on expanding our customer base and enhancing the lifetime value of our customer relationships.

[0001571996-25-000102:mdna:28]
We anticipate that ISG will continue to benefit from technology advancements and interest in AI as customers continue to adopt and integrate AI. The timing of customer purchases reflects the varying stages of adoption of AI by different customer segments and drives variability in our revenue. To meet the growing demand and increasing complexity of our AI-optimized offerings, we have increased our purchases of certain components with suppliers, which has resulted in increased inventory levels, higher purchase obligations, and new working capital dynamics. Additionally, frequent component part updates or transitions create additional challenges in managing demand and supply levels. While we have seen lead times shorten, we anticipate the next generation of these components, for which the demand remains high, will be subject to supply constraints.

[0001571996-25-000102:mdna:29]
[same as prior period, unchanged from 0001571996-25-000063:mdna:27]

[0001571996-25-000102:mdna:30]
CSG — We maintain a broad presence across all segments of the PC market, with a strategic emphasis on driving share gain in commercial and high-end consumer computing devices, which we believe represent the most stable and profitable segments of the industry. We anticipate that CSG will benefit from advances in AI over the long-term as customers will require PCs with the ability to run their complex AI workloads.

[0001571996-25-000102:mdna:31]
Competitive dynamics remain an important factor in our CSG business and continue to impact pricing and operating results. We are committed to our long-term CSG strategy and will continue to make investments to innovate across the portfolio. We expect that the CSG demand environment will be subject to seasonal trends and will continue to be influenced by the PC refresh cycle.

[0001571996-25-000102:mdna:32]
Recurring Revenue and Consumption Models — We expect that our flexible consumption models will further strengthen our customer relationships and provide a foundation for recurring revenue. We define recurring revenue as revenue recognized that is primarily related to hardware and software maintenance, as well as operating leases, subscription, as-a-Service, and usage-based offerings.

[0001571996-25-000102:mdna:33]
[same as prior period, unchanged from 0001571996-25-000063:mdna:31]

[0001571996-25-000102:mdna:34]
Foreign Currency Exposure — We manage our business on a U.S. Dollar basis. However, we have a large global presence, generating approximately 40% and 45% of our net revenue from sales to customers outside of the United States during the second quarter and first six months of Fiscal 2026, respectively, and 50% during both the second quarter and first six months of Fiscal 2025. As a result, our operating results can be, and particularly in recent periods have been, impacted by fluctuations in foreign currency exchange rates. We utilize a comprehensive hedging strategy intended to mitigate the impact of foreign currency volatility over time, and we adjust pricing when possible to further minimize foreign currency impacts.

[0001571996-25-000102:mdna:35]
Other Macroeconomic Risks and Uncertainties — During the first six months of Fiscal 2026, a number of countries, including the United States, imposed or proposed tariffs on imports, and may continue to do so. The impacts of trade protection measures, including increases or changes in tariffs and trade barriers, changes in government policies and international trade arrangements, geopolitical volatility, and global macroeconomic conditions, or uncertainty regarding the impact of proposed or future trade protection measures, may affect our results of operations in some markets. We continue to leverage the agility and scale of our world-class supply chain to mitigate impacts of tariffs and will continue to respond to changing market conditions as needed.

[0001571996-25-000102:mdna:36]
[same as prior period, unchanged from 0001571996-25-000063:mdna:34]

[0001571996-25-000102:mdna:37]
[same as prior period, unchanged from 0001571996-25-000063:mdna:35]

[0001571996-25-000102:mdna:38]
[same as prior period, unchanged from 0001571996-25-000063:mdna:36]

[0001571996-25-000102:mdna:39]
[same as prior period, unchanged from 0001571996-25-000063:mdna:37]

[0001571996-25-000102:mdna:40]
Non-GAAP product gross margin, non-GAAP services gross margin, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, and non-GAAP earnings per share attributable to Dell Technologies Inc. - diluted, as defined by us, exclude amortization of intangible assets, stock-based compensation expense, other corporate expenses and, for non-GAAP net income and non-GAAP earnings per share attributable to Dell Technologies Inc. - diluted, fair value adjustments on equity investments and an aggregate adjustment for income taxes. As the excluded items may have a material impact on our financial results, our management compensates for this limitation by relying primarily on our GAAP results and using non-GAAP financial measures supplementally or for projections when comparable GAAP financial measures are not available.

[0001571996-25-000102:mdna:41]
[same as prior period, unchanged from 0001571996-25-000063:mdna:39]

[0001571996-25-000102:mdna:42]
[same as prior period, unchanged from 0001571996-25-000063:mdna:40]

[0001571996-25-000102:mdna:43]
[same as prior period, unchanged from 0001571996-25-000063:mdna:41]

[0001571996-25-000102:mdna:44]
[same as prior period, unchanged from 0001571996-25-000063:mdna:42]

[0001571996-25-000102:mdna:45]
•Other Corporate Expenses — Other corporate expenses consist primarily of severance expenses, transaction-related impacts on the sales of businesses, payroll taxes associated with stock-based compensation, incentive charges related to equity investments, transaction-related expenses, facility action costs, and impairment charges. Severance costs are primarily related to severance and benefits for employees impacted by cost management initiatives. During the first six months of Fiscal 2026 and Fiscal 2025, we recognized $0.3 billion and $0.4 billion, respectively, of severance expense related to workforce reduction activities. During the first six months of Fiscal 2026, we recognized a $0.2 billion gain related to the sale of Secureworks. Although we may incur these types of items in the future, we exclude other corporate expenses as they can vary from period to period, are significantly impacted by the timing and nature of these events, and are not used by management in assessing operating performance of the business.

[0001571996-25-000102:mdna:46]
[same as prior period, unchanged from 0001571996-25-000063:mdna:44]

[0001571996-25-000102:mdna:47]
•Aggregate Adjustment for Income Taxes — The aggregate adjustment for income taxes is the estimated combined income tax effect for the adjustments described above and determined based on the tax jurisdictions where those adjustments were incurred, as well as an adjustment for discrete tax items. During the first six months of Fiscal 2025, the aggregate adjustment for income taxes included discrete tax benefits of $0.4 billion related to changes in uncertain tax benefits resulting from the expiration of certain U.S. statutes of limitations and $0.2 billion related to stock-based compensation. We exclude these benefits or charges for purposes of calculating non-GAAP net income due to the variability in recognition of discrete tax items from period to period. The tax effects are determined based on the tax jurisdictions where the above items were incurred. See Note 11 of the Notes to the Condensed Consolidated Financial Statements included in this report for additional information about our income taxes. Our non-GAAP income tax was calculated using a fixed estimated annual tax rate that is determined based on historical trends and projections for the current fiscal year. We may adjust our estimated annual tax rate during the fiscal year to take into account events that would significantly impact our income tax expense, including significant changes resulting from tax legislation, material changes in geographic mix of net revenue and expenses, changes to our corporate structure, and other significant events.

[0001571996-25-000102:mdna:48]
[same as prior period, unchanged from 0001571996-25-000063:mdna:46]

[0001571996-25-000102:mdna:49]
[same as prior period, unchanged from 0001571996-25-000063:mdna:47]

[0001571996-25-000102:mdna:50]
|  | Three Months Ended |  | Six Months Ended |
|  | August 1, 2025 |  | % Change |  | August 2, 2024 |  | August 1, 2025 |  | % Change |  | August 2, 2024 |  |  |  |  |
|  | (in millions, except percentages) |
| Product gross margin | $ | 2,891 |  |  | (1) | % |  | $ | 2,925 |  |  | $ | 5,374 |  |  | 1 | % |  | $ | 5,331 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 39 |  |  |  |  | 59 |  |  | 80 |  |  |  |  | 119 |  |  |  |  |  |
| Stock-based compensation expense | 15 |  |  |  |  | 14 |  |  | 30 |  |  |  |  | 28 |  |  |  |  |  |
| Other corporate expenses | 7 |  |  |  |  | 6 |  |  | 16 |  |  |  |  | 10 |  |  |  |  |  |
| Non-GAAP product gross margin | $ | 2,952 |  |  | (2) | % |  | $ | 3,004 |  |  | $ | 5,500 |  |  | — | % |  | $ | 5,488 |  |  |  |  |  |
| Services gross margin | $ | 2,556 |  |  | 5 | % |  | $ | 2,436 |  |  | $ | 5,010 |  |  | 3 | % |  | $ | 4,881 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense | 22 |  |  |  |  | 24 |  |  | 46 |  |  |  |  | 48 |  |  |  |  |  |
| Other corporate expenses | 42 |  |  |  |  | 50 |  |  | 73 |  |  |  |  | 89 |  |  |  |  |  |
| Non-GAAP services gross margin | $ | 2,620 |  |  | 4 | % |  | $ | 2,510 |  |  | $ | 5,129 |  |  | 2 | % |  | $ | 5,018 |  |  |  |  |  |
| Gross margin | $ | 5,447 |  |  | 2 | % |  | $ | 5,361 |  |  | $ | 10,384 |  |  | 2 | % |  | $ | 10,212 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 39 |  |  |  |  | 59 |  |  | 80 |  |  |  |  | 119 |  |  |  |  |  |
| Stock-based compensation expense | 37 |  |  |  |  | 38 |  |  | 76 |  |  |  |  | 76 |  |  |  |  |  |
| Other corporate expenses | 49 |  |  |  |  | 56 |  |  | 89 |  |  |  |  | 99 |  |  |  |  |  |
| Non-GAAP gross margin | $ | 5,572 |  |  | 1 | % |  | $ | 5,514 |  |  | $ | 10,629 |  |  | 1 | % |  | $ | 10,506 |  |  |  |  |  |
| Operating expenses | $ | 3,674 |  |  | (7) | % |  | $ | 3,969 |  |  | $ | 7,446 |  |  | (5) | % |  | $ | 7,855 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | (86) |  |  |  |  | (109) |  |  | (171) |  |  |  |  | (217) |  |  |  |  |  |
| Stock-based compensation expense | (142) |  |  |  |  | (153) |  |  | (293) |  |  |  |  | (325) |  |  |  |  |  |
| Other corporate expenses | (158) |  |  |  |  | (277) |  |  | (303) |  |  |  |  | (410) |  |  |  |  |  |
| Non-GAAP operating expenses | $ | 3,288 |  |  | (4) | % |  | $ | 3,430 |  |  | $ | 6,679 |  |  | (3) | % |  | $ | 6,903 |  |  |  |  |  |

[0001571996-25-000102:mdna:51]
|  | Three Months Ended |  | Six Months Ended |
|  | August 1, 2025 |  | % Change |  | August 2, 2024 |  | August 1, 2025 |  | % Change |  | August 2, 2024 |  |  |  |  |
|  | (in millions, except percentages and per share amounts) |
| Operating income | $ | 1,773 |  |  | 27 | % |  | $ | 1,392 |  |  | $ | 2,938 |  |  | 25 | % |  | $ | 2,357 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 125 |  |  |  |  | 168 |  |  | 251 |  |  |  |  | 336 |  |  |  |  |  |
| Stock-based compensation expense | 179 |  |  |  |  | 191 |  |  | 369 |  |  |  |  | 401 |  |  |  |  |  |
| Other corporate expenses | 207 |  |  |  |  | 333 |  |  | 392 |  |  |  |  | 509 |  |  |  |  |  |
| Non-GAAP operating income | $ | 2,284 |  |  | 10 | % |  | $ | 2,084 |  |  | $ | 3,950 |  |  | 10 | % |  | $ | 3,603 |  |  |  |  |  |
| Net income | $ | 1,164 |  |  | 32 | % |  | $ | 882 |  |  | $ | 2,129 |  |  | 14 | % |  | $ | 1,874 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 125 |  |  |  |  | 168 |  |  | 251 |  |  |  |  | 336 |  |  |  |  |  |
| Stock-based compensation expense | 179 |  |  |  |  | 191 |  |  | 369 |  |  |  |  | 401 |  |  |  |  |  |
| Other corporate expenses | 200 |  |  |  |  | 329 |  |  | 142 |  |  |  |  | 499 |  |  |  |  |  |
| Fair value adjustments on equity investments | (4) |  |  |  |  | (5) |  |  | (21) |  |  |  |  | 25 |  |  |  |  |  |
| Aggregate adjustment for income taxes | (73) |  |  |  |  | (153) |  |  | (193) |  |  |  |  | (764) |  |  |  |  |  |
| Non-GAAP net income | $ | 1,591 |  |  | 13 | % |  | $ | 1,412 |  |  | $ | 2,677 |  |  | 13 | % |  | $ | 2,371 |  |  |  |  |  |
| Earnings per share attributable to Dell Technologies Inc. — diluted | $ | 1.70 |  |  | 38 | % |  | $ | 1.23 |  |  | $ | 3.07 |  |  | 18 | % |  | $ | 2.60 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 0.19 |  |  |  |  | 0.23 |  |  | 0.36 |  |  |  |  | 0.46 |  |  |  |  |  |
| Stock-based compensation expense | 0.26 |  |  |  |  | 0.26 |  |  | 0.53 |  |  |  |  | 0.55 |  |  |  |  |  |
| Other corporate expenses | 0.29 |  |  |  |  | 0.46 |  |  | 0.21 |  |  |  |  | 0.69 |  |  |  |  |  |
| Fair value adjustments on equity investments | (0.01) |  |  |  |  | (0.01) |  |  | (0.03) |  |  |  |  | 0.04 |  |  |  |  |  |
| Aggregate adjustment for income taxes | (0.11) |  |  |  |  | (0.21) |  |  | (0.28) |  |  |  |  | (1.05) |  |  |  |  |  |
| Total non-GAAP adjustments attributable to non-controlling interests | — |  |  |  |  | (0.01) |  |  | — |  |  |  |  | (0.02) |  |  |  |  |  |
| Non-GAAP earnings per share attributable to Dell Technologies Inc. — diluted | $ | 2.32 |  |  | 19 | % |  | $ | 1.95 |  |  | $ | 3.86 |  |  | 18 | % |  | $ | 3.27 |  |  |  |  |  |

[0001571996-25-000102:mdna:52]
[same as prior period, unchanged from 0001571996-25-000063:mdna:50]

[0001571996-25-000102:mdna:53]
[same as prior period, unchanged from 0001571996-25-000063:mdna:51]

[0001571996-25-000102:mdna:54]
[same as prior period, unchanged from 0001571996-25-000063:mdna:52]

[0001571996-25-000102:mdna:55]
[same as prior period, unchanged from 0001571996-25-000063:mdna:53]

[0001571996-25-000102:mdna:56]
[same as prior period, unchanged from 0001571996-25-000063:mdna:54]

[0001571996-25-000102:mdna:57]
|  | Three Months Ended |  | Six Months Ended |
|  | August 1, 2025 |  | % Change |  | August 2, 2024 |  | August 1, 2025 |  | % Change |  | August 2, 2024 |  |  |  |  |
|  | (in millions, except percentages) |
| Cash flow from operations | $ | 2,543 |  |  | 90 | % |  | $ | 1,340 |  |  | $ | 5,339 |  |  | 124 | % |  | $ | 2,383 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Capital expenditures and capitalized software development costs, net (a) | (675) |  |  |  |  | (636) |  |  | (1,243) |  |  |  |  | (1,222) |  |  |  |  |  |
| Free cash flow | $ | 1,868 |  |  | 165 | % |  | $ | 704 |  |  | $ | 4,096 |  |  | 253 | % |  | $ | 1,161 |  |  |  |  |  |
| Free cash flow | $ | 1,868 |  |  | 165 | % |  | $ | 704 |  |  | $ | 4,096 |  |  | 253 | % |  | $ | 1,161 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Financing receivables (b) | 592 |  |  |  |  | 487 |  |  | 569 |  |  |  |  | 652 |  |  |  |  |  |
| Equipment under operating leases (c) | 58 |  |  |  |  | 93 |  |  | 85 |  |  |  |  | 94 |  |  |  |  |  |
| Adjusted free cash flow | $ | 2,518 |  |  | 96 | % |  | $ | 1,284 |  |  | $ | 4,750 |  |  | 149 | % |  | $ | 1,907 |  |  |  |  |  |

[0001571996-25-000102:mdna:58]
[same as prior period, unchanged from 0001571996-25-000063:mdna:56]

[0001571996-25-000102:mdna:59]
[same as prior period, unchanged from 0001571996-25-000063:mdna:57]

[0001571996-25-000102:mdna:60]
[same as prior period, unchanged from 0001571996-25-000063:mdna:58]

[0001571996-25-000102:mdna:61]
[same as prior period, unchanged from 0001571996-25-000063:mdna:59]

[0001571996-25-000102:mdna:62]
[same as prior period, unchanged from 0001571996-25-000063:mdna:60]

[0001571996-25-000102:mdna:63]
[same as prior period, unchanged from 0001571996-25-000063:mdna:61]

[0001571996-25-000102:mdna:64]
[same as prior period, unchanged from 0001571996-25-000063:mdna:62]

[0001571996-25-000102:mdna:65]
|  | Three Months Ended |  | Six Months Ended |
|  | August 1, 2025 |  |  |  | August 2, 2024 |  | August 1, 2025 |  |  |  | August 2, 2024 |  |  |  |  |
|  | Dollars |  | % of Net Revenue |  | % Change |  | Dollars |  | % of Net Revenue |  | Dollars |  | % of Net Revenue |  | % Change |  | Dollars |  | % of Net Revenue |  |  |  |  |  |  |
|  | (in millions, except percentages and per share amounts) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products | $ | 23,935 |  |  | 80.4 | % |  | 26 | % |  | $ | 18,954 |  |  | 75.7 | % |  | $ | 41,534 |  |  | 78.1 | % |  | 18 | % |  | $ | 35,081 |  |  | 74.2 | % |  |  |  |  |  |  |
| Services | 5,841 |  |  | 19.6 | % |  | (4) | % |  | 6,072 |  |  | 24.3 | % |  | 11,620 |  |  | 21.9 | % |  | (5) | % |  | 12,189 |  |  | 25.8 | % |  |  |  |  |  |  |
| Total net revenue | $ | 29,776 |  |  | 100.0 | % |  | 19 | % |  | $ | 25,026 |  |  | 100.0 | % |  | $ | 53,154 |  |  | 100.0 | % |  | 12 | % |  | $ | 47,270 |  |  | 100.0 | % |  |  |  |  |  |  |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products | $ | 2,891 |  |  | 12.1 | % |  | (1) | % |  | $ | 2,925 |  |  | 15.4 | % |  | $ | 5,374 |  |  | 12.9 | % |  | 1 | % |  | $ | 5,331 |  |  | 15.2 | % |  |  |  |  |  |  |
| Services | 2,556 |  |  | 43.8 | % |  | 5 | % |  | 2,436 |  |  | 40.1 | % |  | 5,010 |  |  | 43.1 | % |  | 3 | % |  | 4,881 |  |  | 40.0 | % |  |  |  |  |  |  |
| Total gross margin | $ | 5,447 |  |  | 18.3 | % |  | 2 | % |  | $ | 5,361 |  |  | 21.4 | % |  | $ | 10,384 |  |  | 19.5 | % |  | 2 | % |  | $ | 10,212 |  |  | 21.6 | % |  |  |  |  |  |  |
| Operating expenses | $ | 3,674 |  |  | 12.3 | % |  | (7) | % |  | $ | 3,969 |  |  | 15.8 | % |  | $ | 7,446 |  |  | 14.0 | % |  | (5) | % |  | $ | 7,855 |  |  | 16.6 | % |  |  |  |  |  |  |
| Operating income | $ | 1,773 |  |  | 6.0 | % |  | 27 | % |  | $ | 1,392 |  |  | 5.6 | % |  | $ | 2,938 |  |  | 5.5 | % |  | 25 | % |  | $ | 2,357 |  |  | 5.0 | % |  |  |  |  |  |  |
| Net income | $ | 1,164 |  |  | 3.9 | % |  | 32 | % |  | $ | 882 |  |  | 3.5 | % |  | $ | 2,129 |  |  | 4.0 | % |  | 14 | % |  | $ | 1,874 |  |  | 4.0 | % |  |  |  |  |  |  |
| Earnings per share attributable to Dell Technologies — diluted | $ | 1.70 |  |  |  |  | 38 | % |  | $ | 1.23 |  |  |  |  | $ | 3.07 |  |  |  |  | 18 | % |  | $ | 2.60 |  |  |  |  |  |  |  |  |  |
| Cash flow from operations | $ | 2,543 |  |  |  |  | 90 | % |  | $ | 1,340 |  |  |  |  | $ | 5,339 |  |  |  |  | 124 | % |  | $ | 2,383 |  |  |  |  |  |  |  |  |  |
| Non-GAAP Financial Information |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | Three Months Ended |  | Six Months Ended |
|  | August 1, 2025 |  |  |  | August 2, 2024 |  | August 1, 2025 |  |  |  | August 2, 2024 |  |  |  |  |
|  | Dollars |  | % of Net Revenue |  | % Change |  | Dollars |  | % of Net Revenue |  | Dollars |  | % of Net Revenue |  | % Change |  | Dollars |  | % of Net Revenue |  |  |  |  |  |  |
|  | (in millions, except percentages and per share amounts) |
| Non-GAAP gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products | $ | 2,952 |  |  | 12.3 | % |  | (2) | % |  | $ | 3,004 |  |  | 15.8 | % |  | $ | 5,500 |  |  | 13.2 | % |  | — | % |  | $ | 5,488 |  |  | 15.6 | % |  |  |  |  |  |  |
| Services | 2,620 |  |  | 44.9 | % |  | 4 | % |  | 2,510 |  |  | 41.3 | % |  | 5,129 |  |  | 44.1 | % |  | 2 | % |  | 5,018 |  |  | 41.2 | % |  |  |  |  |  |  |
| Total non-GAAP gross margin | $ | 5,572 |  |  | 18.7 | % |  | 1 | % |  | $ | 5,514 |  |  | 22.0 | % |  | $ | 10,629 |  |  | 20.0 | % |  | 1 | % |  | $ | 10,506 |  |  | 22.2 | % |  |  |  |  |  |  |
| Non-GAAP operating expenses | $ | 3,288 |  |  | 11.0 | % |  | (4) | % |  | $ | 3,430 |  |  | 13.7 | % |  | $ | 6,679 |  |  | 12.6 | % |  | (3) | % |  | $ | 6,903 |  |  | 14.6 | % |  |  |  |  |  |  |
| Non-GAAP operating income | $ | 2,284 |  |  | 7.7 | % |  | 10 | % |  | $ | 2,084 |  |  | 8.3 | % |  | $ | 3,950 |  |  | 7.4 | % |  | 10 | % |  | $ | 3,603 |  |  | 7.6 | % |  |  |  |  |  |  |
| Non-GAAP net income | $ | 1,591 |  |  | 5.3 | % |  | 13 | % |  | $ | 1,412 |  |  | 5.6 | % |  | $ | 2,677 |  |  | 5.0 | % |  | 13 | % |  | $ | 2,371 |  |  | 5.0 | % |  |  |  |  |  |  |
| Non-GAAP earnings per share attributable to Dell Technologies — diluted | $ | 2.32 |  |  |  |  | 19 | % |  | $ | 1.95 |  |  |  |  | $ | 3.86 |  |  |  |  | 18 | % |  | $ | 3.27 |  |  |  |  |  |  |  |  |  |
| Free cash flow | $ | 1,868 |  |  |  |  | 165 | % |  | $ | 704 |  |  |  |  | $ | 4,096 |  |  |  |  | 253 | % |  | $ | 1,161 |  |  |  |  |  |  |  |  |  |
| Adjusted free cash flow | $ | 2,518 |  |  |  |  | 96 | % |  | $ | 1,284 |  |  |  |  | $ | 4,750 |  |  |  |  | 149 | % |  | $ | 1,907 |  |  |  |  |  |  |  |  |  |

[0001571996-25-000102:mdna:66]
[same as prior period, unchanged from 0001571996-25-000063:mdna:64]

[0001571996-25-000102:mdna:67]
[same as prior period, unchanged from 0001571996-25-000063:mdna:65]

[0001571996-25-000102:mdna:68]
[same as prior period, unchanged from 0001571996-25-000063:mdna:66]

[0001571996-25-000102:mdna:69]
During the second quarter and first six months of Fiscal 2026, net revenue increased by 19% and 12%, respectively, driven by an increase in ISG net revenue that was partially offset by a decrease in Corporate and other net revenue. The increase in ISG net revenue was driven by growth in our servers and networking offerings. Corporate and other net revenue declined primarily due to a decrease in VMware Resale revenue as we no longer act as a distributor of standalone VMware offerings. During the first six months of Fiscal 2026, the increase in net revenue was also attributable to an increase in CSG net revenue driven by an increase in sales of our commercial offerings.

[0001571996-25-000102:mdna:70]
During the second quarter of Fiscal 2026, operating income and non-GAAP operating income increased by 27% to $1.8 billion and 10% to $2.3 billion, respectively. During the first six months of Fiscal 2026, operating income and non-GAAP operating income increased by 25% to $2.9 billion and 10% to $4.0 billion, respectively. The increases for both periods were primarily attributable to an increase in ISG operating income that was driven primarily by our storage offerings and, to a lesser extent, our servers and networking offerings.

[0001571996-25-000102:mdna:71]
During the second quarter and first six months of Fiscal 2026, operating income as a percentage of net revenue increased 40 basis points to 6.0% and 50 basis points to 5.5%, respectively. During the second quarter and first six months of Fiscal 2026, non-GAAP operating income as a percentage of net revenue decreased 60 basis points to 7.7% and 20 basis points to 7.4%, respectively. Operating income and non-GAAP operating income as a percentage of net revenue during both the second quarter and first six months of Fiscal 2026 were impacted by a decline in gross margin rate as a result of a shift in mix towards our AI-optimized server offerings. The decline in gross margin rate was largely offset by the favorable impact of a decline in operating expense rate as a result of strong net revenue growth coupled with continued disciplined cost management. During both periods, operating income as a percentage of net revenue was further impacted by lower other corporate expenses.

[0001571996-25-000102:mdna:72]
Cash provided by operating activities was $5.3 billion during the first six months of Fiscal 2026 and was driven by net revenue growth, profitability, and working capital dynamics. Working capital was primarily impacted by increased demand for our AI-optimized server offerings, which led to higher accounts payable, accounts receivable, and inventory levels. During the first six months of Fiscal 2025, cash provided by operating activities was $2.4 billion and was driven by profitability, partially offset by working capital dynamics primarily due to growth in our AI-optimized server offerings. See “Liquidity, Cash Requirements, and Market Conditions” for additional information about our cash flow metrics.

[0001571996-25-000102:mdna:73]
[same as prior period, unchanged from 0001571996-25-000063:mdna:71]

[0001571996-25-000102:mdna:74]
[same as prior period, unchanged from 0001571996-25-000063:mdna:72]

[0001571996-25-000102:mdna:75]
During the second quarter and first six months of Fiscal 2026, net revenue increased 19% and 12%, respectively, primarily driven by an increase in ISG net revenue that was partially offset by a decrease in Corporate and other net revenue. During the first six months of Fiscal 2026, the increase in net revenue was also attributable to an increase in CSG net revenue. See “Business Unit Results” for further information.

[0001571996-25-000102:mdna:76]
•Product Net Revenue — Product net revenue includes revenue from the sale of hardware products and software licenses. During the second quarter and first six months of Fiscal 2026, product net revenue increased 26% and 18%, respectively, due to an increase in ISG product net revenue driven by growth in our servers and networking offerings. During the first six months of Fiscal 2026, the increase in product net revenue was also driven to a lesser extent by an increase in CSG product revenue. The increase in CSG product net revenue reflected growth in our commercial offerings, partially offset by lower demand for our consumer offerings.

[0001571996-25-000102:mdna:77]
•Services Net Revenue — Services net revenue includes revenue from our services offerings and support services related to hardware products and software licenses. During the second quarter and first six months of Fiscal 2026, services net revenue decreased 4% and 5%, respectively, due to a decline in Corporate and other services net revenue, as we no longer act as a distributor of standalone VMware offerings.

[0001571996-25-000102:mdna:78]
59

[0001571996-25-000102:mdna:79]
A substantial portion of services net revenue is derived from offerings that have been deferred over a period of time. As a result, reported growth rates for services net revenue will be different than reported growth rates for product net revenue.

[0001571996-25-000102:mdna:80]
From a geographical perspective, net revenue increased in the Americas, driven by our AI-optimized server offerings, and, to a lesser extent, EMEA and APJ during the second quarter and first six months of Fiscal 2026.

[0001571996-25-000102:mdna:81]
[same as prior period, unchanged from 0001571996-25-000063:mdna:78]

[0001571996-25-000102:mdna:82]
During the second quarter of Fiscal 2026, gross margin and non-GAAP gross margin increased 2% to $5.4 billion and 1% to $5.6 billion, respectively, driven by an increase in ISG gross margin that was primarily attributable to growth in our servers and networking offerings. During the first six months of Fiscal 2026 gross margin and non-GAAP gross margin increased 2% to $10.4 billion and 1% to $10.6 billion, respectively, driven by an increase in ISG gross margin that was primarily attributable to growth in our storage offerings and servers and networking offerings.

[0001571996-25-000102:mdna:83]
During the second quarter of Fiscal 2026, gross margin and non-GAAP gross margin percentage decreased 310 basis points to 18.3% and 330 basis points to 18.7%, respectively. During the first six months of Fiscal 2026, gross margin and non-GAAP gross margin percentage decreased 210 basis points to 19.5% and 220 basis points to 20.0%, respectively. The decreases in gross margin percentage and non-GAAP gross margin percentage were primarily driven by a shift in mix towards our AI-optimized server offerings.

[0001571996-25-000102:mdna:84]
•Product Gross Margin — During the second quarter of Fiscal 2026, product gross margin and non-GAAP product gross margin decreased 1% to $2.9 billion and 2% to $3.0 billion, respectively. During the first six months of Fiscal 2026, product gross margin and non-GAAP product gross margin increased 1% to $5.4 billion and remained flat at $5.5 billion, respectively.

[0001571996-25-000102:mdna:85]
During the second quarter of Fiscal 2026, product gross margin percentage and non-GAAP product gross margin percentage decreased 330 basis points to 12.1% and 350 basis points to 12.3%, respectively. During the first six months of Fiscal 2026, product gross margin percentage and non-GAAP product gross margin percentage decreased 230 basis points to 12.9% and 240 basis points to 13.2%, respectively. The decreases for both periods were primarily attributable to a shift in mix towards our AI-optimized server offerings.

[0001571996-25-000102:mdna:86]
•Services Gross Margin — During the second quarter of Fiscal 2026, services gross margin and non-GAAP services gross margin increased 5% and 4%, respectively, to $2.6 billion. During the first six months of Fiscal 2026, services gross margin and non-GAAP services gross margin increased 3% to $5.0 billion and 2% to $5.1 billion, respectively. The increases for both periods were primarily attributable to an increase in ISG services gross margin primarily driven by higher AI-optimized server offerings and hardware support and maintenance associated with products sold in prior periods.

[0001571996-25-000102:mdna:87]
During the second quarter of Fiscal 2026, services gross margin percentage and non-GAAP services gross margin percentage increased 370 basis points to 43.8% and 360 basis points to 44.9%, respectively. During the first six months of Fiscal 2026, services gross margin percentage and non-GAAP services gross margin percentage increased 310 basis points to 43.1% and 290 basis points to 44.1%, respectively. The increases for both periods were primarily driven by a shift in mix, as we no longer act as a distributor of standalone VMware offerings.

[0001571996-25-000102:mdna:88]
[same as prior period, unchanged from 0001571996-25-000063:mdna:85]

[0001571996-25-000102:mdna:89]
[same as prior period, unchanged from 0001571996-25-000063:mdna:86]

[0001571996-25-000102:mdna:90]
The terms and conditions of our vendor rebate programs are largely based on product volumes and are generally negotiated either at the beginning of the annual or quarterly period, depending on the program. The timing and amount of vendor rebates and other discounts we receive under the programs may vary from period to period, reflecting changes in the competitive environment. We monitor our component costs and seek to address the effects of any changes to terms that might arise under our vendor rebate programs. Our gross margins for the second quarter and first six months of Fiscal 2026 were not materially affected by any changes to the terms of our vendor rebate programs, as the amounts we received under these programs were generally stable relative to our total net cost. We are not aware of any significant changes to our vendor rebate programs that will materially impact our results in the near term.

[0001571996-25-000102:mdna:91]
[same as prior period, unchanged from 0001571996-25-000063:mdna:89]

[0001571996-25-000102:mdna:92]
[same as prior period, unchanged from 0001571996-25-000063:mdna:90]

[0001571996-25-000102:mdna:93]
|  | Three Months Ended |  | Six Months Ended |
|  | August 1, 2025 |  |  |  | August 2, 2024 |  | August 1, 2025 |  |  |  | August 2, 2024 |  |  |  |  |
|  | Dollars |  | % of Net Revenue |  | % Change |  | Dollars |  | % of Net Revenue |  | Dollars |  | % of Net Revenue |  | % Change |  | Dollars |  | % of Net Revenue |  |  |  |  |  |  |
|  | (in millions, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative | $ | 2,889 |  |  | 9.7 | % |  | (9) | % |  | $ | 3,189 |  |  | 12.7 | % |  | $ | 5,853 |  |  | 11.0 | % |  | (7) | % |  | $ | 6,312 |  |  | 13.3 | % |  |  |  |  |  |  |
| Research and development | 785 |  |  | 2.6 | % |  | 1 | % |  | 780 |  |  | 3.1 | % |  | 1,593 |  |  | 3.0 | % |  | 3 | % |  | 1,543 |  |  | 3.3 | % |  |  |  |  |  |  |
| Total operating expenses | $ | 3,674 |  |  | 12.3 | % |  | (7) | % |  | $ | 3,969 |  |  | 15.8 | % |  | $ | 7,446 |  |  | 14.0 | % |  | (5) | % |  | $ | 7,855 |  |  | 16.6 | % |  |  |  |  |  |  |
|  | Three Months Ended |  | Six Months Ended |
|  | August 1, 2025 |  |  |  | August 2, 2024 |  | August 1, 2025 |  |  |  | August 2, 2024 |  |  |  |  |
|  | Dollars |  | % of Net Revenue |  | % Change |  | Dollars |  | % of Net Revenue |  | Dollars |  | % of Net Revenue |  | % Change |  | Dollars |  | % of Net Revenue |  |  |  |  |  |  |
|  | (in millions, except percentages) |
| Non-GAAP operating expenses | $ | 3,288 |  |  | 11.0 | % |  | (4) | % |  | $ | 3,430 |  |  | 13.7 | % |  | $ | 6,679 |  |  | 12.6 | % |  | (3) | % |  | $ | 6,903 |  |  | 14.6 | % |  |  |  |  |  |  |

[0001571996-25-000102:mdna:94]
During the second quarter and first six months of Fiscal 2026, total operating expenses decreased 7% and 5%, respectively, due to a decline in selling, general, and administrative (“SG&A”) expenses.

[0001571996-25-000102:mdna:95]
•Selling, General, and Administrative — During the second quarter and first six months of Fiscal 2026, SG&A expenses decreased 9% and 7%, respectively, driven by a decrease in employee compensation and benefits expense that primarily resulted from a decline in overall headcount.

[0001571996-25-000102:mdna:96]
•Research and Development — Research and development (“R&D”) expenses are primarily composed of personnel-related expenses incurred in connection with product development. R&D expenses increased 1% and 3% during the second quarter and first six months of Fiscal 2026, respectively, principally due to continued support of R&D initiatives.

[0001571996-25-000102:mdna:97]
As a percentage of net revenue, R&D expenses for the second quarter of Fiscal 2026 and Fiscal 2025 were 2.6% and 3.1%, respectively, and for the first six months of Fiscal 2026 and Fiscal 2025 were 3.0% and 3.3%, respectively. We continue to support R&D initiatives to innovate and introduce new and enhanced solutions into the market.

[0001571996-25-000102:mdna:98]
During the second quarter and first six months of Fiscal 2026, non-GAAP operating expenses decreased 4% and 3%, respectively, driven by a decline in employee compensation and benefits expense that primarily resulted from a decline in overall headcount. The decline in employee compensation and benefits expense was partially offset by continued support of R&D initiatives.

[0001571996-25-000102:mdna:99]
[same as prior period, unchanged from 0001571996-25-000063:mdna:97]

[0001571996-25-000102:mdna:100]
[same as prior period, unchanged from 0001571996-25-000063:mdna:98]

[0001571996-25-000102:mdna:101]
During the second quarter of Fiscal 2026, operating income and non-GAAP operating income increased by 27% to $1.8 billion and 10% to $2.3 billion, respectively. During the first six months of Fiscal 2026, operating income and non-GAAP operating income increased by 25% to $2.9 billion and 10% to $4.0 billion, respectively. The increases for both periods were primarily attributable to an increase in ISG operating income that was driven primarily by our storage offerings and, to a lesser extent, our servers and networking offerings.

[0001571996-25-000102:mdna:102]
During the second quarter and first six months of Fiscal 2026, operating income as a percentage of net revenue increased 40 basis points to 6.0% and 50 basis points to 5.5%, respectively. During the second quarter and first six months of Fiscal 2026, non-GAAP operating income as a percentage of net revenue decreased 60 basis points to 7.7% and 20 basis points to 7.4%, respectively. Operating income and non-GAAP operating income as a percentage of net revenue during both the second quarter and first six months of Fiscal 2026 were impacted by a decline in gross margin rate as a result of a shift in mix towards our AI-optimized server offerings. The decline in gross margin rate was largely offset by the favorable impact of a decline in operating expense rate as a result of strong net revenue growth coupled with continued disciplined cost management. During both periods, operating income as a percentage of net revenue was further impacted by lower other corporate expenses.

[0001571996-25-000102:mdna:103]
[same as prior period, unchanged from 0001571996-25-000063:mdna:101]

[0001571996-25-000102:mdna:104]
[same as prior period, unchanged from 0001571996-25-000063:mdna:102]

[0001571996-25-000102:mdna:105]
|  | Three Months Ended |  | Six Months Ended |
|  | August 1, 2025 |  | August 2, 2024 |  | August 1, 2025 |  | August 2, 2024 |  |  |
|  | (in millions) |
| Interest and other, net: |  |  |  |  |  |  |  |  |  |
| Investment income, primarily interest | $ | 64 |  |  | $ | 38 |  |  | $ | 95 |  |  | $ | 92 |  |  |  |
| Gain (loss) on investments, net | 4 |  |  | 5 |  |  | 21 |  |  | (25) |  |  |  |
| Interest expense | (399) |  |  | (387) |  |  | (753) |  |  | (730) |  |  |  |
| Foreign exchange | (15) |  |  | (13) |  |  | (20) |  |  | (51) |  |  |  |
| Gain on disposition of businesses and assets | — |  |  | — |  |  | 236 |  |  | — |  |  |  |
| Other | 13 |  |  | 4 |  |  | 6 |  |  | (12) |  |  |  |
| Total interest and other, net | $ | (333) |  |  | $ | (353) |  |  | $ | (415) |  |  | $ | (726) |  |  |  |

[0001571996-25-000102:mdna:106]
During the second quarter of Fiscal 2026, the change in interest and other, net was favorable primarily due to an increase in investment income. During the first six months of Fiscal 2026, the change in interest and other, net was favorable primarily due to the gain on the sale of Secureworks and, to a lesser extent, the gains recognized within our strategic investments portfolio.

[0001571996-25-000102:mdna:107]
[same as prior period, unchanged from 0001571996-25-000063:mdna:105]

[0001571996-25-000102:mdna:108]
[same as prior period, unchanged from 0001571996-25-000063:mdna:106]

[0001571996-25-000102:mdna:109]
|  | Three Months Ended |  | Six Months Ended |
|  | August 1, 2025 |  | August 2, 2024 |  | August 1, 2025 |  | August 2, 2024 |  |  |
|  | (in millions, except percentages) |
| Income before income taxes | $ | 1,440 |  |  | $ | 1,039 |  |  | $ | 2,523 |  |  | $ | 1,631 |  |  |  |
| Income tax expense (benefit) | $ | 276 |  |  | $ | 157 |  |  | $ | 394 |  |  | $ | (243) |  |  |  |
| Effective income tax rate | 19.2 | % |  | 15.1 | % |  | 15.6 | % |  | (14.9) | % |  |  |

[0001571996-25-000102:mdna:110]
For the second quarter of Fiscal 2026 and Fiscal 2025, our effective income tax rates were 19.2% and 15.1%, respectively. For the first six months of Fiscal 2026 and Fiscal 2025, our effective income tax rates were 15.6% and (14.9)%, respectively. The change in our effective tax rates for Fiscal 2026 as compared to Fiscal 2025 was primarily attributable to discrete tax items. For the first six months of Fiscal 2025, we recorded discrete tax benefits of $0.4 billion related to changes in uncertain tax benefits resulting from the expiration of certain U.S. statutes of limitations and $0.2 billion related to stock-based compensation.

[0001571996-25-000102:mdna:111]
On July 4, 2025, the One Big Beautiful Bill Act (“OBBBA”) was enacted into law in the United States. The new law contains a broad range of tax reform provisions, which include the extension and modification of certain provisions of the Tax Cuts and Jobs Act. Effective for Fiscal 2026, changes include, but are not limited to, immediate expensing of domestic research and development expenditures, the restoration of 100% bonus depreciation, and an EBITDA-based interest expense limitation. These provisions did not have a material impact on the Company’s Condensed Consolidated Financial Statements for the first six months of Fiscal 2026. Effective starting in Fiscal 2027, additional changes will include certain modifications to the international tax framework. We currently do not anticipate these changes to have a material impact to our results in future periods. The Company will continue to monitor any developments and guidance related to OBBBA.

[0001571996-25-000102:mdna:112]
Our effective income tax rate can fluctuate depending on the geographic distribution of our worldwide earnings, as our foreign earnings are generally taxed at lower rates than in the United States. The differences between our effective income tax rates and the U.S. federal statutory rate of 21% principally result from the geographical distribution of income, differences between the book and tax treatment of certain items, and discrete tax items. In certain jurisdictions, our tax rate is significantly less than the applicable statutory rate as a result of tax holidays. The majority of our foreign income subject to these tax holidays is attributable to Singapore and China. A significant portion of these income tax benefits relates to a tax holiday that will be effective until January 31, 2029. Most of our other tax holidays will expire in whole or in part during Fiscal 2030 and Fiscal 2031. Many of these tax holidays and reduced tax rates may be extended when certain conditions are met or may be terminated early if certain conditions are not met or as a result of changes in tax legislation. As of August 1, 2025, we were not aware of any matters of non-compliance.

[0001571996-25-000102:mdna:113]
Many countries, including Singapore, a country in which we have a tax holiday, have enacted or are in the process of enacting laws based on the Pillar Two proposal relating to a global minimum tax issued by the Organisation for Economic Co-operation and Development (“OECD”). While our effective income tax rate and cash income tax payments may increase in future years as a result of the global minimum tax, we do not expect it will have a material impact for Fiscal 2026. Our assessment could be affected by legislative guidance and future enactment of additional provisions within the OECD’s Pillar Two framework.

[0001571996-25-000102:mdna:114]
[same as prior period, unchanged from 0001571996-25-000063:mdna:111]

[0001571996-25-000102:mdna:115]
[same as prior period, unchanged from 0001571996-25-000063:mdna:112]

[0001571996-25-000102:mdna:116]
During the second quarter of Fiscal 2026, net income increased 32% to $1.2 billion primarily due to an increase in operating income. During the first six months of Fiscal 2026, net income increased 14% to $2.1 billion primarily due to an increase in operating income and a favorable change in interest and other, net, which were partially offset by higher income tax expense.

[0001571996-25-000102:mdna:117]
During both the second quarter and first six months of Fiscal 2026, non-GAAP net income increased 13% to $1.6 billion and $2.7 billion, respectively, primarily due to an increase in operating income.

[0001571996-25-000102:mdna:118]
[same as prior period, unchanged from 0001571996-25-000063:mdna:115]

[0001571996-25-000102:mdna:119]
[same as prior period, unchanged from 0001571996-25-000063:mdna:116]

[0001571996-25-000102:mdna:120]
[same as prior period, unchanged from 0001571996-25-000063:mdna:117]

[0001571996-25-000102:mdna:121]
[same as prior period, unchanged from 0001571996-25-000063:mdna:118]

[0001571996-25-000102:mdna:122]
|  | Three Months Ended |  | Six Months Ended |
|  | August 1, 2025 |  | % Change |  | August 2, 2024 |  | August 1, 2025 |  | % Change |  | August 2, 2024 |  |  |  |  |
|  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Servers and networking | $ | 12,944 |  |  | 69 | % |  | $ | 7,672 |  | $ | 19,265 |  | 47 | % |  | $ | 13,138 |  |  |  |  |
| Storage | 3,856 |  |  | (3) | % |  | 3,974 |  | 7,852 |  | 2 | % |  | 7,735 |  |  |  |  |
| Total ISG net revenue | $ | 16,800 |  |  | 44 | % |  | $ | 11,646 |  | $ | 27,117 |  | 30 | % |  | $ | 20,873 |  |  |  |  |
| Operating income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| ISG operating income | $ | 1,470 |  |  | 14 | % |  | $ | 1,284 |  | $ | 2,468 |  | 22 | % |  | $ | 2,020 |  |  |  |  |
| % of segment net revenue | 8.8 | % |  |  |  | 11.0 | % |  | 9.1 | % |  |  |  | 9.7 | % |  |  |  |  |

[0001571996-25-000102:mdna:123]
Net Revenue — During the second quarter and first six months of Fiscal 2026, ISG net revenue increased 44% and 30%, respectively, driven primarily by strength in our servers and networking offerings.

[0001571996-25-000102:mdna:124]
Servers and networking net revenue increased 69% and 47% during the second quarter and first six months of Fiscal 2026, respectively. The increase in servers and networking net revenue was driven by growth primarily in our AI-optimized server offerings and, to a lesser extent, our traditional servers and networking offerings.

[0001571996-25-000102:mdna:125]
During the second quarter of Fiscal 2026, storage net revenue decreased 3% due to a decline in net revenue from our core storage offerings. During the first six months of Fiscal 2026, storage net revenue increased 2% primarily due to an increase in our core storage offerings.

[0001571996-25-000102:mdna:126]
From a geographical perspective, net revenue attributable to ISG increased in the Americas, driven by our AI-optimized server offerings, and, to a lesser extent, EMEA and APJ during the second quarter and first six months of Fiscal 2026.

[0001571996-25-000102:mdna:127]
Operating Income — During the second quarter and first six months of Fiscal 2026, ISG operating income as a percentage of net revenue decreased 220 basis points to 8.8% and 60 basis points to 9.1%, respectively, due to a decline in gross margin rate that outpaced the decline in operating expense as a percentage of net revenue. Gross margin rate decreased primarily as the result of a shift in mix towards our AI-optimized server offerings. Operating expense as a percentage of net revenue declined primarily due to strong ISG net revenue growth coupled with continued disciplined cost management.

[0001571996-25-000102:mdna:128]
64

[0001571996-25-000102:mdna:129]
[same as prior period, unchanged from 0001571996-25-000063:mdna:125]

[0001571996-25-000102:mdna:130]
[same as prior period, unchanged from 0001571996-25-000063:mdna:126]

[0001571996-25-000102:mdna:131]
|  | Three Months Ended |  | Six Months Ended |
|  | August 1, 2025 |  | % Change |  | August 2, 2024 |  | August 1, 2025 |  | % Change |  | August 2, 2024 |  |  |  |  |
|  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 10,781 |  |  | 2 | % |  | $ | 10,556 |  | $ | 21,827 |  | 5 | % |  | $ | 20,710 |  |  |  |  |
| Consumer | 1,722 |  |  | (7) | % |  | 1,858 |  | 3,185 |  | (13) | % |  | 3,671 |  |  |  |  |
| Total CSG net revenue | $ | 12,503 |  |  | 1 | % |  | $ | 12,414 |  | $ | 25,012 |  | 3 | % |  | $ | 24,381 |  |  |  |  |
| Operating income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| CSG operating income | $ | 803 |  |  | (2) | % |  | $ | 817 |  | $ | 1,456 |  | (9) | % |  | $ | 1,594 |  |  |  |  |
| % of segment net revenue | 6.4 | % |  |  |  | 6.6 | % |  | 5.8 | % |  |  |  | 6.5 | % |  |  |  |  |

[0001571996-25-000102:mdna:132]
Net Revenue — During the second quarter and first six months of Fiscal 2026, CSG net revenue increased 1% and 3%, respectively, driven primarily by strength in our commercial offerings, partially offset by lower demand for our consumer offerings.

[0001571996-25-000102:mdna:133]
Commercial net revenue increased 2% during the second quarter of Fiscal 2026, primarily due to an increase in average selling prices. Commercial net revenue increased 5% during the first six months of Fiscal 2026, primarily as the result of an increase in units sold and, to a lesser extent, an increase in average selling prices. The increase in the average selling prices of our commercial offerings across both periods was primarily the result of richer configurations and change in mix within our offerings.

[0001571996-25-000102:mdna:134]
Consumer net revenue decreased 7% and 13% during the second quarter and first six months of Fiscal 2026, respectively, primarily due to a decline in units sold.

[0001571996-25-000102:mdna:135]
From a geographical perspective, net revenue attributable to CSG increased in EMEA and remained flat across the Americas and APJ during the second quarter of Fiscal 2026 and increased in the Americas and EMEA and remained flat in APJ during the first six months of Fiscal 2026.

[0001571996-25-000102:mdna:136]
Operating Income — During the second quarter and first six months of Fiscal 2026, CSG operating income as a percentage of net revenue decreased 20 basis points to 6.4% and 70 basis points to 5.8%, respectively. The decline in operating income rate during the second quarter of Fiscal 2026 was primarily attributable to an increase in operating expense as a percentage of net revenue driven by an increase in R&D expenses. The decline in operating income rate during the first six months of Fiscal 2026 was primarily due to a decline in gross margin rate driven by a competitive pricing environment and change in mix within our offerings.

[0001571996-25-000102:mdna:137]
[same as prior period, unchanged from 0001571996-25-000063:mdna:132]

[0001571996-25-000102:mdna:138]
[same as prior period, unchanged from 0001571996-25-000063:mdna:133]

[0001571996-25-000102:mdna:139]
We sell products and services directly to customers and through a variety of sales channels, including retail distribution. Our accounts receivable, net was $15.0 billion and $10.3 billion as of August 1, 2025 and January 31, 2025, respectively. The increase in accounts receivable, net was primarily driven by an increase in net revenue largely attributable to our AI-optimized offerings. We maintain an allowance for expected credit losses to cover receivables that may be deemed uncollectible. The allowance for expected credit losses is an estimate based on an analysis of historical loss experience, current receivables aging, and management’s assessment of current conditions and its reasonable and supportable expectation of future conditions, as well as specific identifiable customer accounts that are deemed at risk. As of August 1, 2025 and January 31, 2025, the allowance for expected credit losses was $83 million and $63 million, respectively. Based on our assessment, we believe that we are adequately reserved for expected credit losses.

[0001571996-25-000102:mdna:140]
[same as prior period, unchanged from 0001571996-25-000063:mdna:135]

[0001571996-25-000102:mdna:141]
We offer or arrange a portfolio of payment and consumption solutions and services for our customers globally, including as-a-Service, subscription, utility, leases, and loans designed to match customers' consumption and financing preferences. We believe these options provide operational and financial flexibility and strengthen our customer relationships. To support financing solutions and services as part of the portfolio, DFS originates, collects, and services customer receivables primarily related to the purchase of our product and services solutions. New financing originations were $2.4 billion for both the second quarter of Fiscal 2026 and Fiscal 2025, and $4.0 billion and $4.3 billion for the first six months of Fiscal 2026 and Fiscal 2025, respectively.

[0001571996-25-000102:mdna:142]
[same as prior period, unchanged from 0001571996-25-000063:mdna:137]

[0001571996-25-000102:mdna:143]
As of August 1, 2025 and January 31, 2025, our financing receivables, net were $12.0 billion and $11.2 billion, respectively. We maintain an allowance to cover expected financing receivables credit losses and evaluate credit loss expectations based on our total portfolio. The principal charge-off rate for our financing receivables portfolio was 0.1% and 0.7% for the second quarter of Fiscal 2026 and Fiscal 2025, respectively, and 0.2% and 0.5% for the first six months of Fiscal 2026 and Fiscal 2025, respectively. The credit quality of our financing receivables remains strong due to the mix of high-quality commercial accounts in our portfolio. We continue to monitor broader economic indicators and their potential impact on future credit loss performance. We have an extensive process to manage our exposure to customer credit risk that includes active management of credit lines and collection activities. We also sell select fixed-term financing receivables without recourse to unrelated third parties on a periodic basis, primarily to manage certain concentrations of customer credit exposure. Based on our assessment of the customer financing receivables, we believe that we are adequately reserved.

[0001571996-25-000102:mdna:144]
We retain a residual interest in equipment leased under our lease programs. As of August 1, 2025 and January 31, 2025, the residual interest recorded as part of financing receivables was $185 million and $168 million, respectively. The amount of the residual interest is established at the inception of the lease based upon estimates of the value of the equipment at the end of the lease term using historical studies, industry data, and future value-at-risk demand valuation methods. On a quarterly basis, we assess the carrying amount of our recorded residual values for expected losses. Generally, expected losses as a result of residual value risk on equipment under lease are not considered to be significant primarily because of the existence of a secondary market with respect to the equipment. Further, the lease agreement defines applicable return conditions and remedies for non-compliance to ensure that the leased equipment will be in good operating condition upon return. No expected losses were recorded related to residual assets during the second quarter and first six months of Fiscal 2026 and Fiscal 2025.

[0001571996-25-000102:mdna:145]
As of August 1, 2025 and January 31, 2025, equipment under operating leases, net was $2.3 billion and $2.2 billion, respectively. We assess the carrying amount of the equipment under operating leases for impairment whenever events or circumstances may indicate that an impairment has occurred. No material impairment losses were recorded related to such equipment during the second quarter and first six months of Fiscal 2026 and Fiscal 2025.

[0001571996-25-000102:mdna:146]
[same as prior period, unchanged from 0001571996-25-000063:mdna:141]

[0001571996-25-000102:mdna:147]
[same as prior period, unchanged from 0001571996-25-000063:mdna:142]

[0001571996-25-000102:mdna:148]
[same as prior period, unchanged from 0001571996-25-000063:mdna:143]

[0001571996-25-000102:mdna:149]
[same as prior period, unchanged from 0001571996-25-000063:mdna:144]

[0001571996-25-000102:mdna:150]
[same as prior period, unchanged from 0001571996-25-000063:mdna:145]

[0001571996-25-000102:mdna:151]
[same as prior period, unchanged from 0001571996-25-000063:mdna:146]

[0001571996-25-000102:mdna:152]
[same as prior period, unchanged from 0001571996-25-000063:mdna:147]

[0001571996-25-000102:mdna:153]
We believe that our current cash and cash equivalents, together with cash that will be provided by future operations and borrowings and issuances expected to be available under our revolving credit facility and commercial paper program, will be sufficient over the next twelve months and for the foreseeable future thereafter to meet our material cash requirements, including funding of our operations, debt-related payments, capital expenditures, and other corporate needs.

[0001571996-25-000102:mdna:154]
[same as prior period, unchanged from 0001571996-25-000063:mdna:149]

[0001571996-25-000102:mdna:155]
[same as prior period, unchanged from 0001571996-25-000063:mdna:150]

[0001571996-25-000102:mdna:156]
|  | August 1, 2025 |  | January 31, 2025 |
|  | (in millions) |
| Cash and cash equivalents, and available borrowings: |  |  |  |
| Cash and cash equivalents | $ | 8,145 |  |  | $ | 3,633 |  |
| Remaining available borrowings under the revolving credit facility | 5,886 |  |  | 5,999 |  |
| Total cash and cash equivalents, and available borrowings | $ | 14,031 |  |  | $ | 9,632 |  |

[0001571996-25-000102:mdna:157]
During the first six months of Fiscal 2026, cash and cash equivalents increased by $4.5 billion primarily due to an increase in cash flows from operations, net debt from the issuance of Senior Notes and DFS debt, and the proceeds from the sale of Secureworks, the effects of which were partially offset by the return of capital to our stockholders, capital expenditures, and payments to settle employee tax withholdings on stock-based compensation.

[0001571996-25-000102:mdna:158]
As of August 1, 2025, our revolving credit facility had a maximum capacity of $6.0 billion. Available borrowings under this facility are reduced by draws on the facility and outstanding letters of credit. As of August 1, 2025, there were no borrowings outstanding under the facility and remaining available borrowings totaled approximately $5.9 billion. The revolving credit facility also acts as a backstop to provide liquidity support for our commercial paper program.

[0001571996-25-000102:mdna:159]
We maintain a commercial paper program under which we may issue unsecured notes in a maximum aggregate face amount of $5.0 billion outstanding at any time, with maturities of up to 397 days from the date of issue. As of August 1, 2025, we had no outstanding issuances under the program.

[0001571996-25-000102:mdna:160]
We may regularly use our available borrowings from the revolving credit facility and issuances under the commercial paper program, generally on a short-term basis, for general corporate purposes. See the following discussion for additional information about our debt.

[0001571996-25-000102:mdna:161]
[same as prior period, unchanged from 0001571996-25-000063:mdna:156]

[0001571996-25-000102:mdna:162]
[same as prior period, unchanged from 0001571996-25-000063:mdna:157]

[0001571996-25-000102:mdna:163]
|  | August 1, 2025 |  | Change |  | January 31, 2025 |
|  | (in millions) |
| Core debt |  |  |  |  |  |
| Senior Notes | $ | 19,073 |  |  | $ | 4,000 |  |  | $ | 15,073 |  |
| Legacy Notes | 952 |  |  | — |  |  | 952 |  |
| DFS allocated debt | (3,730) |  |  | (702) |  |  | (3,028) |  |
| Total core debt | 16,295 |  |  | 3,298 |  |  | 12,997 |  |
| DFS related debt |  |  |  |  |  |
| DFS debt | 8,815 |  |  | 104 |  |  | 8,711 |  |
| DFS allocated debt | 3,730 |  |  | 702 |  |  | 3,028 |  |
| Total DFS related debt | 12,545 |  |  | 806 |  |  | 11,739 |  |
| Other | 89 |  |  | 37 |  |  | 52 |  |
| Total debt, principal amount | 28,929 |  |  | 4,141 |  |  | 24,788 |  |
| Carrying value adjustments | (240) |  |  | (19) |  |  | (221) |  |
| Total debt, carrying value | $ | 28,689 |  |  | $ | 4,122 |  |  | $ | 24,567 |  |

[0001571996-25-000102:mdna:164]
The outstanding principal amount of our debt increased $4.1 billion to $28.9 billion as of August 1, 2025, driven primarily by an increase in net debt from the issuance of Senior Notes.

[0001571996-25-000102:mdna:165]
We define core debt as the total principal amount of our debt, less DFS related debt and other debt. Our core debt was $16.3 billion and $13.0 billion as of August 1, 2025 and January 31, 2025, respectively. See Note 6 of the Notes to the Condensed Consolidated Financial Statements included in this report for additional information about our debt.

[0001571996-25-000102:mdna:166]
[same as prior period, unchanged from 0001571996-25-000063:mdna:161]

[0001571996-25-000102:mdna:167]
[same as prior period, unchanged from 0001571996-25-000063:mdna:162]

[0001571996-25-000102:mdna:168]
[same as prior period, unchanged from 0001571996-25-000063:mdna:163]

[0001571996-25-000102:mdna:169]
|  | August 1, 2025 |  | January 31, 2025 |
|  | (in millions) |
| Financing receivables, net | $ | 12,023 |  |  | $ | 11,231 |  |
| Equipment under operating leases, net | 2,314 |  |  | 2,185 |  |
| DFS owned assets | $ | 14,337 |  |  | $ | 13,416 |  |

[0001571996-25-000102:mdna:170]
We believe we will continue to be able to make our debt principal and interest payments, including payment of short-term maturities, from existing and expected sources of cash. Cash used for debt principal and interest payments may include operating cash flows, short-term borrowings under our commercial paper program or our revolving credit facility, or other borrowings. Under our variable-rate debt, we could experience variations in our future interest expense from potential fluctuations in applicable reference rates, or from possible fluctuations in the level of DFS debt required to meet future demand for customer financing.

[0001571996-25-000102:mdna:171]
69

[0001571996-25-000102:mdna:172]
[same as prior period, unchanged from 0001571996-25-000063:mdna:166]

[0001571996-25-000102:mdna:173]
[same as prior period, unchanged from 0001571996-25-000063:mdna:167]

[0001571996-25-000102:mdna:174]
[same as prior period, unchanged from 0001571996-25-000063:mdna:168]

[0001571996-25-000102:mdna:175]
|  | Six Months Ended |
|  | August 1, 2025 |  | August 2, 2024 |  |  |
|  | (in millions) |
| Net change in cash from: |  |  |  |  |  |
| Operating activities | $ | 5,339 |  |  | $ | 2,383 |  |  |  |
| Investing activities | (743) |  |  | (1,013) |  |  |  |
| Financing activities | (228) |  |  | (4,109) |  |  |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash | 104 |  |  | (97) |  |  |  |
| Change in cash, cash equivalents, and restricted cash | $ | 4,472 |  |  | $ | (2,836) |  |  |  |

[0001571996-25-000102:mdna:176]
Operating Activities — Cash provided by operating activities was $5.3 billion during the first six months of Fiscal 2026 and was driven by net revenue growth, profitability, and working capital dynamics. Working capital was primarily impacted by increased demand for our AI-optimized server offerings, which led to higher accounts payable, accounts receivable, and inventory levels. During the first six months of Fiscal 2025, cash provided by operating activities was $2.4 billion and was driven by profitability, partially offset by working capital dynamics primarily attributable to growth in our AI-optimized server offerings.

[0001571996-25-000102:mdna:177]
Investing Activities — Investing activities primarily consist of cash used to fund capital expenditures for property, plant, and equipment inclusive of equipment under operating leases and equipment used to support our as-a-Service offerings, which we refer to collectively as assets in a customer contract. Additional activities may include capitalized software development costs, the maturities, sales, and purchases of investments, and acquisitions and divestitures. Cash used in investing activities was $0.7 billion during the first six months of Fiscal 2026 and consisted of cash used for capital expenditures, partially offset by cash proceeds from the sale of Secureworks. Cash used in investing activities was $1.0 billion during the first six months of Fiscal 2025 and was primarily used for capital expenditures.

[0001571996-25-000102:mdna:178]
Financing Activities — Financing activities primarily consist of the proceeds and repayments of debt and return of capital to our stockholders. Cash used by financing activities was $0.2 billion during the first six months of Fiscal 2026 and primarily consisted of repurchases of common stock, inclusive of payments to settle employee tax withholdings on stock-based compensation, and the payment of quarterly dividends, the effects of which were partially offset by net proceeds from the issuance of Senior Notes and DFS debt. Cash used in financing activities was $4.1 billion during the first six months of Fiscal 2025 and primarily consisted of repurchases of common stock, inclusive of payments to settle employee tax withholdings on stock-based compensation, net repayments on our Senior Notes and DFS debt, and the payment of quarterly dividends.

[0001571996-25-000102:mdna:179]
DFS Cash Flow Impacts — DFS offerings are initially funded through cash on hand at the time of origination, most of which is subsequently replaced with asset-backed financing. For offerings that qualify as sales-type leases, the initial funding of financing receivables is reflected as an impact to cash flows from operations and is largely subsequently offset by cash proceeds from financing. For offerings that qualify as operating leases, the initial funding is classified as a capital expenditure and reflected as cash flows used in investing activities. DFS new financing originations were $4.0 billion and $4.3 billion during the first six months of Fiscal 2026 and Fiscal 2025, respectively. As of August 1, 2025, we had $12.0 billion of total net financing receivables and $2.3 billion of equipment under operating leases, net.

[0001571996-25-000102:mdna:180]
[same as prior period, unchanged from 0001571996-25-000063:mdna:174]

[0001571996-25-000102:mdna:181]
[same as prior period, unchanged from 0001571996-25-000063:mdna:175]

[0001571996-25-000102:mdna:182]
Capital Expenditures — We spent $1.2 billion and $1.3 billion during the first six months of Fiscal 2026 and Fiscal 2025, respectively, on property, plant, and equipment and capitalized software development costs. Of total expenditures incurred, funding of assets in a customer contract totaled $0.7 billion during both the first six months of Fiscal 2026 and Fiscal 2025. Product demand, product mix, the use of contract manufacturers, and ongoing investments in operating and information technology infrastructure influence the level and prioritization of our capital expenditures.

[0001571996-25-000102:mdna:183]
[same as prior period, unchanged from 0001571996-25-000063:mdna:177]

[0001571996-25-000102:mdna:184]
During the first six months of Fiscal 2026, we repurchased approximately 30 million shares of Class C Common Stock for a total purchase price of approximately $2.9 billion. During the first six months of Fiscal 2025, we repurchased approximately 12 million shares of Class C Common Stock for a total purchase price of approximately $1.4 billion.

[0001571996-25-000102:mdna:185]
Dividend Payments — During the first six months of Fiscal 2026 and Fiscal 2025, the Company paid $0.8 billion and $0.7 billion in dividends and dividend equivalents at a rate of $0.525 and $0.445 per share per fiscal quarter, respectively.

[0001571996-25-000102:mdna:186]
[same as prior period, unchanged from 0001571996-25-000063:mdna:180]

[0001571996-25-000102:mdna:187]
[same as prior period, unchanged from 0001571996-25-000063:mdna:181]

[0001571996-25-000102:mdna:188]
As of August 1, 2025, we had purchase obligations of $7.2 billion, of which $5.4 billion is payable within twelve months.

[0001571996-25-000102:mdna:189]
[same as prior period, unchanged from 0001571996-25-000063:mdna:183]

[0001571996-25-000102:mdna:190]
[same as prior period, unchanged from 0001571996-25-000063:mdna:184]

[0001571996-25-000102:mdna:191]
[same as prior period, unchanged from 0001571996-25-000063:mdna:185]

[0001571996-25-000102:mdna:192]
[same as prior period, unchanged from 0001571996-25-000063:mdna:186]

[0001571996-25-000102:mdna:193]
[same as prior period, unchanged from 0001571996-25-000063:mdna:187]

[0001571996-25-000102:mdna:194]
[same as prior period, unchanged from 0001571996-25-000063:mdna:188]

[0001571996-25-000102:mdna:195]
[same as prior period, unchanged from 0001571996-25-000063:mdna:189]

[0001571996-25-000102:mdna:196]
[same as prior period, unchanged from 0001571996-25-000063:mdna:190]

[0001571996-25-000102:mdna:197]
Basis of Preparation of the Summarized Financial Information — The tables below are summarized financial information provided in conformity with Rule 13-01 of the SEC’s Regulation S-X. The summarized financial information of the Issuers and Guarantors (collectively, the “Obligor Group”) is presented on a combined basis, excluding intercompany balances and transactions between entities in the Obligor Group. The Obligor Group’s investment balances in subsidiaries of Dell Technologies Inc. that are not part of the Obligor Group (the “Non-Obligor Subsidiaries”) have been excluded. The Obligor Group’s amounts due from, amounts due to, and transactions with Non-Obligor Subsidiaries have been presented separately.

[0001571996-25-000102:mdna:198]
[same as prior period, unchanged from 0001571996-25-000063:mdna:192]

[0001571996-25-000102:mdna:199]
|  | Six Months Ended |
|  | August 1, 2025 |
|  | (in millions) |
| Net revenue | $ | 4,014 |  |
| Gross margin | 2,072 |  |
| Operating income | 494 |  |
| Interest and other, net | (2,048) |  |
| Loss before income taxes | $ | (1,554) |  |
| Net loss attributable to Obligor Group (a) | $ | (1,126) |  |

[0001571996-25-000102:mdna:200]
[same as prior period, unchanged from 0001571996-25-000063:mdna:194]

[0001571996-25-000102:mdna:201]
(a)Includes net loss from intercompany transactions with Non-Obligor Subsidiaries of $2,110 million, which primarily consists of interest expense, shared services, and the resale of solutions.

[0001571996-25-000102:mdna:202]
73

[0001571996-25-000102:mdna:203]
[same as prior period, unchanged from 0001571996-25-000063:mdna:196]

[0001571996-25-000102:mdna:204]
|  | August 1, 2025 |  | January 31, 2025 |
|  | (in millions) |
| ASSETS |
| Current assets | $ | 2,909 |  |  | $ | 3,132 |  |
| Intercompany receivables | — |  |  | 175 |  |
| Total current assets | 2,909 |  |  | 3,307 |  |
| Goodwill and intangible assets | 13,928 |  |  | 14,073 |  |
| Other non-current assets | 3,285 |  |  | 3,412 |  |
| Total assets | $ | 20,122 |  |  | $ | 20,792 |  |
| LIABILITIES |
| Current liabilities | $ | 5,944 |  |  | $ | 4,097 |  |
| Intercompany payable | 7 |  |  | — |  |
| Total current liabilities | 5,951 |  |  | 4,097 |  |
| Long-term debt | 17,309 |  |  | 15,824 |  |
| Long-term intercompany loan payables | 44,525 |  |  | 44,516 |  |
| Other non-current liabilities | 3,159 |  |  | 3,339 |  |
| Total liabilities | $ | 70,944 |  |  | $ | 67,776 |  |

[0001571996-25-000102:mdna:205]
[same as prior period, unchanged from 0001571996-25-000063:mdna:198]
