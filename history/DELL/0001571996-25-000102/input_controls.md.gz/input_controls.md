# DELL 10-Q controls and the auditor's report


## item_4_controls

[0001571996-25-000102:item_4_controls:1]
ITEM 4 — CONTROLS AND PROCEDURES

[0001571996-25-000102:item_4_controls:2]
This report includes the certifications of our Chief Executive Officer and Chief Financial Officer required by Rule 13a-14 under the Securities Exchange Act of 1934 (the “Exchange Act”). See Exhibits 31.1 and 31.2 filed with this report. This Item 4 includes information concerning the controls and control evaluations referred to in those certifications.

[0001571996-25-000102:item_4_controls:3]
Evaluation of Disclosure Controls and Procedures

[0001571996-25-000102:item_4_controls:4]
Disclosure controls and procedures (as defined in Rules 13a-15(e) and 15d-15(e) under the Exchange Act) are designed to provide reasonable assurance that information required to be disclosed in reports filed or submitted under the Exchange Act is recorded, processed, summarized, and reported within the time periods specified in SEC rules and forms and that such information is accumulated and communicated to management, including the Chief Executive Officer and the Chief Financial Officer, as appropriate to allow timely decisions regarding required disclosures.

[0001571996-25-000102:item_4_controls:5]
In connection with the preparation of this report, our management, under the supervision and with the participation of our Chief Executive Officer and Chief Financial Officer, conducted an evaluation of the effectiveness of the design and operation of our disclosure controls and procedures as of August 1, 2025. Based on that evaluation, our Chief Executive Officer and Chief Financial Officer have concluded that as of August 1, 2025, the Company’s disclosure controls and procedures were effective to accomplish their objectives at the reasonable assurance level.

[0001571996-25-000102:item_4_controls:6]
Remediation of Previously Reported Material Weakness

[0001571996-25-000102:item_4_controls:7]
As previously disclosed in the Company’s Annual Report on Form 10-K for the fiscal year ended January 31, 2025, management identified a material weakness in its internal control over financial reporting during the preparation of the Company’s financial statements for the fiscal year ended January 31, 2025, as the Company did not design and maintain effective controls over non-recurring credits from certain suppliers that related to cost of net revenue.

[0001571996-25-000102:item_4_controls:8]
In response to the material weakness described above, the Company designed and implemented a control over non-recurring credits from certain suppliers. The Company has completed the testing of this control and has concluded the control is designed and operating effectively. As a result, management has concluded that the material weakness described above has been remediated as of August 1, 2025.

[0001571996-25-000102:item_4_controls:9]
Changes in Internal Control Over Financial Reporting

[0001571996-25-000102:item_4_controls:10]
We are in the process of an ongoing business modernization initiative to advance our capabilities, leverage new technology, and optimize business processes to change the way we work and make decisions, improve business outcomes, and reduce costs. As part of this initiative, we are modernizing accounting and finance systems. We have modified and will continue to modify the design and implementation of certain internal control processes to accommodate changes to our business processes and finance procedures, as our business modernization initiative continues.

[0001571996-25-000102:item_4_controls:11]
There were no other changes in our internal control over financial reporting during the fiscal quarter ended August 1, 2025 that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.

[0001571996-25-000102:item_4_controls:12]
75
