# DELL notes — 0001571996-25-000102


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001571996-25-000102:notes:1]
Basis of Presentation — The accompanying unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes filed with the U.S. Securities and Exchange Commission (“SEC”) in the Company’s Annual Report on Form 10-K for the fiscal year ended January 31, 2025. These Condensed Consolidated Financial Statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“GAAP”). In the opinion of management, the accompanying Condensed Consolidated Financial Statements reflect all adjustments of a normal recurring nature considered necessary to fairly state the financial position of the Company as of August 1, 2025 and January 31, 2025 and the results of its operations, corresponding comprehensive income, changes in stockholders’ equity (deficit) for the three and six months ended August 1, 2025 and August 2, 2024, and cash flows for the six months ended August 1, 2025 and August 2, 2024.

[0001571996-25-000102:notes:2]
The preparation of financial statements in accordance with GAAP requires management to make estimates and assumptions that affect the amounts reported in the Condensed Consolidated Financial Statements and the accompanying Notes. Actual results could differ materially from those estimates. The results of its operations, corresponding comprehensive income, and changes in stockholders’ equity (deficit) for the three and six months ended August 1, 2025 and August 2, 2024, and cash flows for the six months ended August 1, 2025 and August 2, 2024 are not necessarily indicative of the results to be expected for the full fiscal year or for any other fiscal period.
The Company’s fiscal year is the 52- or 53-week period ending on the Friday nearest January 31. Both the fiscal year ending January 30, 2026 (“Fiscal 2026”) and the fiscal year ended January 31, 2025 (“Fiscal 2025”) are 52-week periods.


## us-gaap:ConsolidationPolicyTextBlock

[0001571996-25-000102:notes:3]
[same as prior period, unchanged from 0001571996-25-000063:notes:3]


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001571996-25-000102:notes:4]
Recently Issued Accounting Pronouncements

[0001571996-25-000102:notes:5]
Expense Disaggregation Disclosures — In November 2024, the Financial Accounting Standards Board (the “FASB”) issued guidance to improve disclosures about a public entity’s expenses by requiring disclosure of additional information about the types of expenses commonly presented in the financial statements on an annual and interim basis. Public entities must adopt the new guidance for fiscal years beginning after December 15, 2026, with early adoption permitted. Upon adoption, the guidance can be applied prospectively or retrospectively. Adoption of this new guidance will result in increased disclosures in the Notes to the Consolidated Financial Statements.

[0001571996-25-000102:notes:6]
Income Taxes — In December 2023, the FASB issued guidance which requires companies to provide disaggregated income tax disclosures within the income tax rate reconciliation and income taxes paid. Public entities must adopt the new guidance for fiscal years beginning after December 15, 2024, with early adoption permitted. The Company will adopt the guidance prospectively. Adoption of this new guidance will result in increased disclosures in the Notes to the Consolidated Financial Statements.


## us-gaap:FairValueDisclosuresTextBlock

[0001571996-25-000102:notes:7]
[same as prior period, unchanged from 0001571996-25-000063:notes:7]

[0001571996-25-000102:notes:8]
|  | August 1, 2025 |  | January 31, 2025 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | Quoted Prices in Active Markets for Identical Assets |  | Significant Other Observable Inputs |  | Significant Unobservable Inputs |  |  |  | Quoted Prices in Active Markets for Identical Assets |  | Significant Other Observable Inputs |  | Significant Unobservable Inputs |  |  |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 4,667 |  |  | $ | — |  |  | $ | — |  |  | $ | 4,667 |  |  | $ | 571 |  |  | $ | — |  |  | $ | — |  |  | $ | 571 |  |
| Marketable equity and other securities | 7 |  |  | — |  |  | — |  |  | 7 |  |  | 8 |  |  | — |  |  | — |  |  | 8 |  |
| Derivative instruments | — |  |  | 150 |  |  | — |  |  | 150 |  |  | — |  |  | 302 |  |  | — |  |  | 302 |  |
| Total assets | $ | 4,674 |  |  | $ | 150 |  |  | $ | — |  |  | $ | 4,824 |  |  | $ | 579 |  |  | $ | 302 |  |  | $ | — |  |  | $ | 881 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative instruments | $ | — |  |  | $ | 158 |  |  | $ | — |  |  | $ | 158 |  |  | $ | — |  |  | $ | 75 |  |  | $ | — |  |  | $ | 75 |  |
| Total liabilities | $ | — |  |  | $ | 158 |  |  | $ | — |  |  | $ | 158 |  |  | $ | — |  |  | $ | 75 |  |  | $ | — |  |  | $ | 75 |  |

[0001571996-25-000102:notes:9]
[same as prior period, unchanged from 0001571996-25-000063:notes:9]

[0001571996-25-000102:notes:10]
Money Market Funds — The Company’s investment in money market funds that are classified as cash equivalents hold underlying investments with a weighted average maturity of 90 days or less and are recognized at fair value. The valuations of these securities are based on quoted prices for identical assets in active markets, when available, or pricing models whereby all significant inputs are observable, or can be derived from, or corroborated by, observable market data. The Company reviews security pricing and assesses money market fund liquidity on a quarterly basis. As of August 1, 2025, the Company’s portfolio had no exposure to money market funds with a fluctuating net asset value.

[0001571996-25-000102:notes:11]
[same as prior period, unchanged from 0001571996-25-000063:notes:11]

[0001571996-25-000102:notes:12]
[same as prior period, unchanged from 0001571996-25-000063:notes:12]

[0001571996-25-000102:notes:13]
Deferred Compensation Plans — The Company offers deferred compensation plans for eligible employees which allow participants to defer a portion of their compensation. Assets and liabilities associated with the plans are measured at fair value using Level 1 inputs. Assets were the same as liabilities associated with the plans at approximately $256 million and $244 million as of August 1, 2025 and January 31, 2025, respectively, and are included in other assets and other liabilities on the Condensed Consolidated Statements of Financial Position. The net impact on the Condensed Consolidated Statements of Income is not material since changes in the fair value of the assets substantially offset changes in the fair value of the liabilities. As such, assets and liabilities associated with these plans have not been included in the recurring fair value table above.

[0001571996-25-000102:notes:14]
[same as prior period, unchanged from 0001571996-25-000063:notes:14]

[0001571996-25-000102:notes:15]
[same as prior period, unchanged from 0001571996-25-000063:notes:15]

[0001571996-25-000102:notes:16]
[same as prior period, unchanged from 0001571996-25-000063:notes:16]

[0001571996-25-000102:notes:17]
|  | August 1, 2025 |  | January 31, 2025 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Notes | $ | 18.9 |  |  | $ | 19.3 |  |  | $ | 15.0 |  |  | $ | 15.0 |  |
| Legacy Notes | $ | 0.9 |  |  | $ | 1.0 |  |  | $ | 0.9 |  |  | $ | 1.0 |  |
| DFS Debt | $ | 8.8 |  |  | $ | 8.5 |  |  | $ | 8.7 |  |  | $ | 8.5 |  |

[0001571996-25-000102:notes:18]
[same as prior period, unchanged from 0001571996-25-000063:notes:18]


## us-gaap:InvestmentTextBlock

[0001571996-25-000102:notes:19]
INVESTMENTS
The Company has strategic investments in equity and other securities as well as immaterial investments in fixed income debt securities that are primarily recorded as long-term investments in the Condensed Consolidated Statements of Financial Position. As of August 1, 2025 and January 31, 2025, total investments were $1.6 billion and $1.5 billion, respectively.

[0001571996-25-000102:notes:20]
Equity and other securities include strategic investments in marketable and non-marketable securities. Investments in marketable securities are measured at fair value on a recurring basis. Investments in non-marketable equity and other securities primarily represent early-stage companies without readily determinable fair values. The Company has elected to apply the measurement alternative for non-marketable securities which allows investments without readily determinable fair values to be measured at cost, less impairment, adjusted for observable price changes. The Company makes a separate election to use the alternative for each eligible investment and is required to reassess at each reporting period whether an investment qualifies for the alternative. In evaluating these investments for impairment or observable price changes, the Company uses inputs including pre- and post-money valuations of recent financing events and the impact of those events on its fully diluted ownership percentages, as well as other available information regarding the issuer’s historical and forecasted performance.

[0001571996-25-000102:notes:21]
[same as prior period, unchanged from 0001571996-25-000063:notes:21]

[0001571996-25-000102:notes:22]
[same as prior period, unchanged from 0001571996-25-000063:notes:22]

[0001571996-25-000102:notes:23]
|  | August 1, 2025 |  | January 31, 2025 |
|  | Cost |  | Unrealized Gain |  | Unrealized Loss |  | Carrying Value |  | Cost |  | Unrealized Gain |  | Unrealized Loss |  | Carrying Value |
|  | (in millions) |
| Marketable | $ | 11 |  |  | $ | 24 |  |  | $ | (28) |  |  | $ | 7 |  |  | $ | 11 |  |  | $ | 24 |  |  | $ | (27) |  |  | $ | 8 |  |
| Non-marketable | 830 |  |  | 1,030 |  |  | (284) |  |  | 1,576 |  |  | 739 |  |  | 1,009 |  |  | (261) |  |  | 1,487 |  |
| Total equity and other securities | $ | 841 |  |  | $ | 1,054 |  |  | $ | (312) |  |  | $ | 1,583 |  |  | $ | 750 |  |  | $ | 1,033 |  |  | $ | (288) |  |  | $ | 1,495 |  |

[0001571996-25-000102:notes:24]
[same as prior period, unchanged from 0001571996-25-000063:notes:24]

[0001571996-25-000102:notes:25]
[same as prior period, unchanged from 0001571996-25-000063:notes:25]

[0001571996-25-000102:notes:26]
|  | Three Months Ended |  | Six Months Ended |
|  | August 1, 2025 |  | August 2, 2024 |  | August 1, 2025 |  | August 2, 2024 |  |  |
|  | (in millions) |
| Marketable securities: |  |  |  |  |  |  |  |  |  |
| Unrealized loss | $ | — |  |  | $ | (1) |  |  | $ | (1) |  |  | $ | (6) |  |  |  |
| Non-marketable securities: |  |  |  |  |  |  |  |  |  |
| Unrealized gain | — |  |  | — |  |  | 22 |  |  | — |  |  |  |
| Unrealized loss | (17) |  |  | — |  |  | (23) |  |  | (31) |  |  |  |
| Net unrealized loss (a) (b) | (17) |  |  | — |  |  | (1) |  |  | (31) |  |  |  |
| Net unrealized loss on equity and other securities | $ | (17) |  |  | $ | (1) |  |  | $ | (2) |  |  | $ | (37) |  |  |  |

[0001571996-25-000102:notes:27]
[same as prior period, unchanged from 0001571996-25-000063:notes:27]

[0001571996-25-000102:notes:28]
(a)For the three and six months ended August 1, 2025, net unrealized losses on non-marketable securities were primarily attributable to downward adjustments for observable price changes and impairments. For the six months ended August 1, 2025, net unrealized losses were also offset by unrealized gains primarily attributable to upward adjustments for observable price changes.
(b)For the six months ended August 2, 2024, unrealized losses on non-marketable securities were attributable to downward adjustments for observable price changes.


## dell:CreditLossFinancialInstrumentLeasesDebtVariableInterestEntitiesAndCustomerReceivablesSalesTextBlock

[0001571996-25-000102:notes:29]
FINANCIAL SERVICES 
The Company offers or arranges a portfolio of payment and consumption solutions and services for its customers globally, including utility, subscription, as-a-Service, leases, and loans designed to match customers' consumption and financing preferences, and provide operational and financial flexibility.

[0001571996-25-000102:notes:30]
To support financing solutions and services as part of the Dell Technologies portfolio, Dell Financial Services and its affiliates (“DFS”) originates, collects, and services customer financing arrangements primarily related to the purchase and use of Dell Technologies products and services. In some cases, the Company also offers financing for the purchase of third-party technology products that complement the portfolio of products and services. New financing originations were $2.4 billion for both the three months ended August 1, 2025 and August 2, 2024, and $4.0 billion and $4.3 billion for the six months ended August 1, 2025 and August 2, 2024, respectively.

[0001571996-25-000102:notes:31]
The Company’s financing arrangements with customers are aggregated primarily as fixed-term leases and loans as described below.

[0001571996-25-000102:notes:32]
Leases — The Company enters into fixed-term financing arrangements with customers who seek lease financing for equipment. Leases are generally classified as sales-type leases or operating leases. Additionally, utility, subscription, and as-a-Service flexible consumption models may result in identification of embedded lease arrangements that require the recognition of sales-type leases or operating leases. Leases with business customers have fixed terms of generally two to five years.

[0001571996-25-000102:notes:33]
Loans — The Company also offers fixed-term loans to qualified small businesses, large commercial accounts, governmental organizations, educational entities, and certain individual consumer customers. These loans are repaid in equal payments including interest and have defined terms of generally three to five years. The fair value of the fixed-term loan portfolio is determined using market observable inputs. The carrying value of these loans approximates fair value.

[0001571996-25-000102:notes:34]
The Company historically offered revolving loans primarily to small and medium-sized commercial customers. During Fiscal 2025, the Company discontinued remaining offerings under the revolving loan portfolio. The Company continues to support existing customer arrangements as well as to transition these customers to fixed-term offerings. Due to the short-term nature of the revolving loan portfolio, in which transactions are typically repaid within twelve months on average, the portfolio had substantially transitioned to such fixed-term offerings as of August 1, 2025.

[0001571996-25-000102:notes:35]
Financing Receivables

[0001571996-25-000102:notes:36]
The following table presents the components of the Company’s financing receivables as of the dates indicated:

[0001571996-25-000102:notes:37]
|  |  |  |  |  | August 1, 2025 |  |  |  |  |  | January 31, 2025 |
|  |  |  |  |  | (in millions) |
| Financing receivables, net: |  |  |  |  |  |  |  |  |  |  |  |
| Customer receivables, gross (a) |  |  |  |  | $ | 11,989 |  |  |  |  |  |  | $ | 11,216 |  |
| Allowance for losses |  |  |  |  | (151) |  |  |  |  |  |  | (153) |  |
| Customer receivables, net |  |  |  |  | 11,838 |  |  |  |  |  |  | 11,063 |  |
| Residual interest |  |  |  |  | 185 |  |  |  |  |  |  | 168 |  |
| Financing receivables, net |  |  |  |  | $ | 12,023 |  |  |  |  |  |  | $ | 11,231 |  |
| Short-term |  |  |  |  | $ | 5,952 |  |  |  |  |  |  | $ | 5,304 |  |
| Long-term |  |  |  |  | $ | 6,071 |  |  |  |  |  |  | $ | 5,927 |  |

[0001571996-25-000102:notes:38]
(a)Customer receivables, gross include amounts due from customers under fixed-term leases, fixed-term loans, and accrued interest, as well as the immaterial remaining amounts under the revolving loans.

[0001571996-25-000102:notes:39]
The following table presents the changes in allowance for financing receivable losses for the periods indicated:

[0001571996-25-000102:notes:40]
|  | Three Months Ended |  |  |  |  |  | Six Months Ended |
|  | August 1, 2025 |  | August 2, 2024 |  |  |  |  |  | August 1, 2025 |  |  |  |  |  | August 2, 2024 |  |  |
|  | (in millions) |  |  |  |  |  |  |
| Allowance for financing receivable losses: |
| Balances at beginning of period | $ | 144 |  |  | $ | 195 |  |  |  |  |  |  | $ | 153 |  |  |  |  |  |  | $ | 170 |  |  |  |  |  |  |  |
| Charge-offs, net of recoveries | (4) |  |  | (19) |  |  |  |  |  |  | (14) |  |  |  |  |  |  | (27) |  |  |  |  |  |  |  |
| Provision charged to income statement | 11 |  |  | (10) |  |  |  |  |  |  | 12 |  |  |  |  |  |  | 23 |  |  |  |  |  |  |  |
| Balances at end of period | $ | 151 |  |  | $ | 166 |  |  |  |  |  |  | $ | 151 |  |  |  |  |  |  | $ | 166 |  |  |  |  |  |  |  |

[0001571996-25-000102:notes:41]
The Company recognizes an allowance for financing receivable losses, including both the lease receivable and unguaranteed residual, in an amount equal to the expected losses, net of recoveries. The allowance for financing receivable losses on the lease receivable is determined based on various factors, including lifetime expected losses determined using macroeconomic forecast assumptions and management judgments applicable to and through the expected life of the portfolios as well as past due receivables, receivable type, and customer risk profile. The Company continues to monitor broader economic indicators and their potential impact on future credit loss performance.

[0001571996-25-000102:notes:42]
Aging

[0001571996-25-000102:notes:43]
The following table presents the aging of the Company’s customer financing receivables, gross, including accrued interest, as of the dates indicated:

[0001571996-25-000102:notes:44]
|  | August 1, 2025 |  | January 31, 2025 |
|  | (in millions) |
| Current 0 — 30 Days | $ | 11,355 |  |  | $ | 10,796 |  |
| Past Due 31 — 90 Days | 467 |  |  | 201 |  |
| Past Due > 90 Days | 167 |  |  | 219 |  |
| Total | $ | 11,989 |  |  | $ | 11,216 |  |

[0001571996-25-000102:notes:45]
Aging is likely to fluctuate as a result of the variability in volume of large transactions entered into over the period, and the administrative processes that accompany those transactions. Aging is also impacted by the timing of the Company’s fiscal period end date relative to calendar month-end customer payment due dates. As a result of these factors, fluctuations in aging from period to period do not necessarily indicate a material change in the collectibility of the portfolio.

[0001571996-25-000102:notes:46]
Customer receivables are placed on non-accrual status if principal or interest is past due and considered delinquent, or if there is concern about the collectibility of a specific customer receivable. The receivables identified as doubtful for collectibility may be classified as current for aging purposes.

[0001571996-25-000102:notes:47]
Credit Quality

[0001571996-25-000102:notes:48]
The following tables present customer receivables, gross, including accrued interest, by credit quality indicator, as of the dates indicated:

[0001571996-25-000102:notes:49]
|  | August 1, 2025 |
|  | Fiscal Year of Origination |  |  |
|  | 2026 |  | 2025 |  | 2024 |  | 2023 |  | 2022 |  | Years Prior |  | Total |
|  | (in millions) |
| Higher | $ | 1,852 |  |  | $ | 1,949 |  |  | $ | 1,786 |  |  | $ | 824 |  |  | $ | 186 |  |  | $ | 38 |  |  | $ | 6,635 |  |
| Mid | 1,227 |  |  | 1,771 |  |  | 529 |  |  | 303 |  |  | 52 |  |  | 5 |  |  | 3,887 |  |
| Lower | 534 |  |  | 416 |  |  | 294 |  |  | 171 |  |  | 33 |  |  | 19 |  |  | 1,467 |  |
| Total | $ | 3,613 |  |  | $ | 4,136 |  |  | $ | 2,609 |  |  | $ | 1,298 |  |  | $ | 271 |  |  | $ | 62 |  |  | $ | 11,989 |  |

[0001571996-25-000102:notes:50]
|  | January 31, 2025 |
|  | Fiscal Year of Origination |  |  |
|  | 2025 |  | 2024 |  | 2023 |  | 2022 |  | 2021 |  | Years Prior |  | Total |
|  | (in millions) |
| Higher | $ | 2,295 |  |  | $ | 2,160 |  |  | $ | 1,217 |  |  | $ | 357 |  |  | $ | 102 |  |  | $ | 4 |  |  | $ | 6,135 |  |
| Mid | 2,455 |  |  | 695 |  |  | 464 |  |  | 107 |  |  | 17 |  |  | 4 |  |  | 3,742 |  |
| Lower | 552 |  |  | 407 |  |  | 283 |  |  | 68 |  |  | 28 |  |  | 1 |  |  | 1,339 |  |
| Total | $ | 5,302 |  |  | $ | 3,262 |  |  | $ | 1,964 |  |  | $ | 532 |  |  | $ | 147 |  |  | $ | 9 |  |  | $ | 11,216 |  |

[0001571996-25-000102:notes:51]
The categories shown in the tables above segregate customer receivables based on the relative degrees of credit risk. Credit quality indicators are generally updated on a periodic basis. An internal grading system is utilized that assigns a credit level score based on a number of considerations, including liquidity, operating performance, and industry outlook.

[0001571996-25-000102:notes:52]
Leases

[0001571996-25-000102:notes:53]
The following table presents amounts included in the Condensed Consolidated Statements of Income related to sales-type lease activity for the periods indicated:

[0001571996-25-000102:notes:54]
|  | Three Months Ended |  | Six Months Ended |
|  | August 1, 2025 |  | August 2, 2024 |  | August 1, 2025 |  | August 2, 2024 |  |  |
|  | (in millions) |
| Interest income — products | $ | 92 |  |  | $ | 73 |  |  | $ | 185 |  |  | $ | 139 |  |  |  |
| Net revenue — products | $ | 181 |  |  | $ | 622 |  |  | $ | 300 |  |  | $ | 1,350 |  |  |  |
| Cost of net revenue — products | 178 |  |  | 537 |  |  | 309 |  |  | 1,155 |  |  |  |
| Gross margin — products | $ | 3 |  |  | $ | 85 |  |  | $ | (9) |  |  | $ | 195 |  |  |  |

[0001571996-25-000102:notes:55]
The following table presents the future maturity of the Company’s customer leases and associated financing payments, and reconciles the undiscounted cash flows to the customer receivables, gross recognized on the Condensed Consolidated Statements of Financial Position as of the date indicated:

[0001571996-25-000102:notes:56]
|  | August 1, 2025 |
|  | (in millions) |
| Fiscal 2026 (remaining six months) | $ | 1,702 |  |
| Fiscal 2027 | 2,665 |  |
| Fiscal 2028 | 1,308 |  |
| Fiscal 2029 | 700 |  |
| Fiscal 2030 and thereafter | 347 |  |
| Total undiscounted cash flows | 6,722 |  |
| Loans | 6,288 |  |
| Less: Unearned income | (1,021) |  |
| Total customer receivables, gross | $ | 11,989 |  |

[0001571996-25-000102:notes:57]
Operating Leases

[0001571996-25-000102:notes:58]
The Company’s operating leases primarily consist of fixed-term leases and contractually committed embedded leases identified within flexible consumption arrangements.

[0001571996-25-000102:notes:59]
The following table presents the components of the Company’s operating lease portfolio included in property, plant, and equipment, net as of the dates indicated:

[0001571996-25-000102:notes:60]
|  | August 1, 2025 |  | January 31, 2025 |
|  | (in millions) |
| Equipment under operating lease, gross | $ | 4,492 |  |  | $ | 4,180 |  |
| Less: Accumulated depreciation | (2,178) |  |  | (1,995) |  |
| Equipment under operating lease, net | $ | 2,314 |  |  | $ | 2,185 |  |

[0001571996-25-000102:notes:61]
The following table presents operating lease income related to lease payments and depreciation expense for the Company’s operating lease portfolio for the periods indicated:

[0001571996-25-000102:notes:62]
|  | Three Months Ended |  | Six Months Ended |
|  | August 1, 2025 |  | August 2, 2024 |  | August 1, 2025 |  | August 2, 2024 |  |  |
|  | (in millions) |
| Income related to lease payments | $ | 390 |  |  | $ | 362 |  |  | $ | 748 |  |  | $ | 718 |  |  |  |
| Depreciation expense | $ | 256 |  |  | $ | 245 |  |  | $ | 500 |  |  | $ | 485 |  |  |  |

[0001571996-25-000102:notes:63]
The following table presents the future payments to be received by the Company in operating lease contracts as of the date indicated:

[0001571996-25-000102:notes:64]
|  | August 1, 2025 |
|  | (in millions) |
| Fiscal 2026 (remaining six months) | $ | 672 |  |
| Fiscal 2027 | 1,048 |  |
| Fiscal 2028 | 622 |  |
| Fiscal 2029 | 278 |  |
| Fiscal 2030 and thereafter | 99 |  |
| Total | $ | 2,719 |  |

[0001571996-25-000102:notes:65]
DFS Debt

[0001571996-25-000102:notes:66]
The Company maintains programs that facilitate the funding of leases, loans, and other alternative payment structures in the capital markets. The majority of DFS debt is non-recourse to Dell Technologies and represents borrowings under securitization programs and structured financing programs for which the Company’s risk of loss is limited to transferred lease and loan payments and associated equipment.

[0001571996-25-000102:notes:67]
The following table presents DFS debt as of the dates indicated and excludes the allocated portion of the Company’s other borrowings, which represents the additional amount considered to fund the DFS business:

[0001571996-25-000102:notes:68]
|  | August 1, 2025 |  | January 31, 2025 |
| DFS debt | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing facility | $ | 3,001 |  |  | $ | 3,018 |  |
| Fixed-term securitization offerings | 2,685 |  |  | 2,756 |  |
| Total DFS U.S. debt, principal amount | 5,686 |  |  | 5,774 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 657 |  |  | 624 |  |
| Other borrowings | 760 |  |  | 754 |  |
| Dell Bank senior unsecured eurobonds | 1,712 |  |  | 1,559 |  |
| Total DFS international debt, principal amount | 3,129 |  |  | 2,937 |  |
| Total DFS debt, principal amount | $ | 8,815 |  |  | $ | 8,711 |  |
| Total short-term DFS debt | $ | 4,624 |  |  | $ | 5,175 |  |
| Total long-term DFS debt | $ | 4,191 |  |  | $ | 3,536 |  |

[0001571996-25-000102:notes:69]
DFS U.S. Debt

[0001571996-25-000102:notes:70]
Asset-Based Financing Facility — The Company maintains an asset-based financing facility in the United States, which is a revolving facility for fixed-term leases and loans. This debt is collateralized solely by the U.S. lease and loan payments and associated equipment in the facility. The asset-based financing facility consists of two tranches, with effective dates through July 7, 2026 and July 7, 2027, respectively. As of August 1, 2025, the total debt capacity related to the asset-based financing facility was $4.6 billion. The debt has a variable interest rate, and the duration of the debt is based on the terms of the underlying lease and loan payment streams. The Company enters into interest rate swap agreements to economically convert a portion of this debt from a floating rate to a fixed rate. See Note 7 of the Notes to the Condensed Consolidated Financial Statements for additional information about the Company’s interest rate swaps.

[0001571996-25-000102:notes:71]
The asset-based financing facility contains standard structural features related to the performance of the funded receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements. In the event one or more of these criteria are not met and the Company is unable to restructure the facility, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed. As of August 1, 2025, these criteria were met.

[0001571996-25-000102:notes:72]
Fixed-Term Securitization Offerings — The Company periodically issues asset-backed debt securities under fixed-term securitization programs to private investors. The asset-backed debt securities are collateralized solely by the U.S. fixed-term lease and loan payments and associated equipment, which are held by Special Purpose Entities (“SPEs”), as discussed below. The interest rate on these securities is fixed and ranges from 4.59% to 6.80% per annum as of August 1, 2025, and the duration of these securities is based on the terms of the underlying lease and loan payment streams.

[0001571996-25-000102:notes:73]
DFS International Debt

[0001571996-25-000102:notes:74]
Securitization Facility — The Company maintains a securitization facility in Europe for fixed-term leases and loans. The debt under this facility has a variable interest rate, and the duration of the debt is based on the terms of the underlying lease and loan payment streams. This facility is effective through December 22, 2026 and had a total debt capacity of $913 million as of August 1, 2025.

[0001571996-25-000102:notes:75]
The securitization facility contains standard structural features related to the performance of the securitized receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements. In the event one or more of these criteria are not met and the Company is unable to restructure the program, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed. As of August 1, 2025, these criteria were met.

[0001571996-25-000102:notes:76]
Other Borrowings — In connection with the Company’s international financing operations, the Company has entered into revolving structured financing debt programs related to its fixed-term lease and loan products sold in Canada, Europe, Australia and New Zealand, the Middle East, and Singapore. The debt under these programs has a variable interest rate.

[0001571996-25-000102:notes:77]
The duration of the debt in Canada, Europe, Australia and New Zealand, and the Middle East is based on the terms of the underlying lease and loan payment streams. These facilities are collateralized solely by the lease and loan payments and associated equipment in their respective region or country. The Canadian facility had a total debt capacity of $253 million as of August 1, 2025 and is effective through January 15, 2028. The European facility had a total debt capacity of $457 million as of August 1, 2025 and is effective through December 14, 2026. The Australia and New Zealand facility had a total debt capacity of $273 million as of August 1, 2025 and is effective through April 17, 2027. The Middle East facility had a total debt capacity of $150 million as of August 1, 2025 and is effective through March 14, 2027.

[0001571996-25-000102:notes:78]
The Company also has two unsecured Singapore facilities, which had a total debt capacity of $254 million as of August 1, 2025 and are effective through July 3, 2026 and July 3, 2027, respectively.

[0001571996-25-000102:notes:79]
Dell Bank Senior Unsecured Eurobonds — On October 27, 2021, Dell Bank issued 500 million Euro of 0.5% senior unsecured five year eurobonds due October 2026. On October 18, 2022, Dell Bank issued 500 million Euro of 4.5% senior unsecured five year eurobonds due October 2027. On June 13, 2024, Dell Bank issued 500 million Euro of 3.6% senior unsecured five year eurobonds due June 2029. The issuances of the senior unsecured eurobonds support the expansion of the financing operations in Europe.

[0001571996-25-000102:notes:80]
Variable Interest Entities

[0001571996-25-000102:notes:81]
In connection with the asset-based financing facility, fixed-term securitization offerings, and securitization facility discussed above, the Company transfers certain U.S. and European lease and loan payments and associated equipment to SPEs that meet the definition of a VIE and are consolidated, along with the associated debt described above, into the Condensed Consolidated Financial Statements, as the Company is the primary beneficiary of the VIEs. The SPEs are bankruptcy-remote legal entities with separate assets and liabilities. The purpose of the SPEs is to facilitate the funding of customer lease and loan payments and associated equipment in the capital markets.

[0001571996-25-000102:notes:82]
Some of the SPEs have entered into financing arrangements with multi-seller conduits that, in turn, issue asset-backed debt securities in the capital markets. DFS debt outstanding held by the consolidated VIEs is collateralized by the lease and loan payments and associated equipment. The Company’s risk of loss related to securitized receivables is limited to the amount by which the Company’s right to receive collections for assets securitized exceeds the amount required to pay interest, principal, and fees and expenses related to the asset-backed securities. The Company provides credit enhancement to the securitization offerings in the form of over-collateralization.

[0001571996-25-000102:notes:83]
The following table presents the assets and liabilities held by the consolidated VIEs as of the dates indicated, which are included in the Condensed Consolidated Statements of Financial Position:

[0001571996-25-000102:notes:84]
|  | August 1, 2025 |  | January 31, 2025 |
|  | (in millions) |
| Assets held by consolidated VIEs |  |  |  |
| Other current assets | $ | 147 |  |  | $ | 123 |  |
| Financing receivables, net of allowance |  |  |  |
| Short-term | $ | 3,194 |  |  | $ | 3,262 |  |
| Long-term | $ | 2,738 |  |  | $ | 2,725 |  |
| Property, plant, and equipment, net | $ | 971 |  |  | $ | 984 |  |
| Liabilities held by consolidated VIEs |  |  |  |
| Debt, net of unamortized debt issuance costs |  |  |  |
| Short-term | $ | 4,129 |  |  | $ | 4,598 |  |
| Long-term | $ | 2,201 |  |  | $ | 1,788 |  |

[0001571996-25-000102:notes:85]
Lease and loan payments and associated equipment transferred via securitization through SPEs were $0.8 billion and $1.2 billion for the three months ended August 1, 2025 and August 2, 2024, respectively, and $2.0 billion for both the six months ended August 1, 2025 and August 2, 2024.

[0001571996-25-000102:notes:86]
Customer Receivables Sales

[0001571996-25-000102:notes:87]
To manage certain concentrations of customer credit exposure, the Company may sell selected fixed-term customer receivables to unrelated third parties on a periodic basis, without recourse. The amounts of customer receivables sold for this purpose were immaterial for both the six months ended August 1, 2025 and August 2, 2024. The Company’s continuing involvement in these customer receivables is primarily limited to servicing arrangements.


## us-gaap:ScheduleOfDebtTableTextBlock

[0001571996-25-000102:notes:88]
The following table summarizes the Company’s outstanding debt as of the dates indicated:

[0001571996-25-000102:notes:89]
|  | August 1, 2025 |  | January 31, 2025 |
|  | (in millions) |
| Senior Notes | $ | 19,073 |  |  | $ | 15,073 |  |
| Legacy Notes | 952 |  |  | 952 |  |
| DFS Debt (Note 4) | 8,815 |  |  | 8,711 |  |
| Other | 89 |  |  | 52 |  |
| Total debt, principal amount | 28,929 |  |  | 24,788 |  |
| Unamortized discount, net of unamortized premium | (110) |  |  | (110) |  |
| Debt issuance costs | (130) |  |  | (111) |  |
| Total debt, carrying value | $ | 28,689 |  |  | $ | 24,567 |  |
| Total short-term debt, carrying value | $ | 7,154 |  |  | $ | 5,204 |  |
| Total long-term debt, carrying value | $ | 21,535 |  |  | $ | 19,363 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0001571996-25-000102:notes:90]
LEASES 
The Company enters into leasing transactions in which the Company is the lessee. These lease contracts are typically classified as operating leases. The Company’s lease contracts are generally for office buildings used to conduct its business, and the determination of whether such contracts contain leases generally does not require significant estimates or judgments. The Company also leases certain global logistics warehouses, employee vehicles, and equipment. As of August 1, 2025, the remaining terms of the Company’s leases generally range from one month to approximately eleven years. As of August 1, 2025 and January 31, 2025, there were no material finance leases in which the Company was a lessee.

[0001571996-25-000102:notes:91]
[same as prior period, unchanged from 0001571996-25-000063:notes:91]

[0001571996-25-000102:notes:92]
[same as prior period, unchanged from 0001571996-25-000063:notes:92]

[0001571996-25-000102:notes:93]
|  | Three Months Ended |  | Six Months Ended |
|  | August 1, 2025 |  | August 2, 2024 |  | August 1, 2025 |  | August 2, 2024 |  |  |
|  | (in millions) |
| Operating lease costs | $ | 61 |  |  | $ | 75 |  |  | $ | 119 |  |  | $ | 146 |  |  |  |
| Variable costs | 18 |  |  | 15 |  |  | 41 |  |  | 33 |  |  |  |
| Total lease costs | $ | 79 |  |  | $ | 90 |  |  | $ | 160 |  |  | $ | 179 |  |  |  |

[0001571996-25-000102:notes:94]
During the three and six months ended August 1, 2025 and August 2, 2024, sublease income, finance lease costs, and short-term lease costs were immaterial.

[0001571996-25-000102:notes:95]
[same as prior period, unchanged from 0001571996-25-000063:notes:95]

[0001571996-25-000102:notes:96]
|  | Classification |  | August 1, 2025 |  | January 31, 2025 |  |  |
|  |  |  | (in millions, except for term and discount rate) |
| Operating lease right-of-use assets | Other non-current assets |  | $ | 699 |  | $ | 660 |  |  |
| Current operating lease liabilities | Accrued and other current liabilities |  | $ | 241 |  | $ | 236 |  |  |
| Non-current operating lease liabilities | Other non-current liabilities |  | 549 |  | 522 |  |  |
| Total operating lease liabilities |  |  | $ | 790 |  | $ | 758 |  |  |
| Weighted-average remaining lease term (in years) |  |  | 4.36 |  | 4.36 |  |  |
| Weighted-average discount rate |  |  | 5.03 | % |  | 5.14 | % |  |  |

[0001571996-25-000102:notes:97]
[same as prior period, unchanged from 0001571996-25-000063:notes:97]

[0001571996-25-000102:notes:98]
|  | Six Months Ended |
|  | August 1, 2025 |  | August 2, 2024 |  |  |
|  | (in millions) |
| Cash paid for amounts included in the measurement of lease liabilities — operating cash outflows from operating leases | $ | 130 |  |  | $ | 137 |  |  |  |
| Right-of-use assets obtained in exchange for new operating lease liabilities | $ | 120 |  |  | $ | 128 |  |  |  |

[0001571996-25-000102:notes:99]
[same as prior period, unchanged from 0001571996-25-000063:notes:99]

[0001571996-25-000102:notes:100]
|  | August 1, 2025 |
|  | (in millions) |
| Fiscal 2026 (remaining six months) | $ | 120 |  |
| Fiscal 2027 | 237 |  |
| Fiscal 2028 | 190 |  |
| Fiscal 2029 | 135 |  |
| Fiscal 2030 | 95 |  |
| Thereafter | 99 |  |
| Total lease payments | 876 |  |
| Less: Imputed interest | 86 |  |
| Total | $ | 790 |  |
| Current operating lease liabilities | $ | 241 |  |
| Non-current operating lease liabilities | $ | 549 |  |

[0001571996-25-000102:notes:101]
As of August 1, 2025, the Company’s undiscounted operating leases that had not yet commenced were immaterial.


## us-gaap:DebtDisclosureTextBlock

[0001571996-25-000102:notes:102]
DEBT
The following table summarizes the Company’s outstanding debt as of the dates indicated:

[0001571996-25-000102:notes:103]
During the six months ended August 1, 2025, the Company issued $1.0 billion principal amount of 4.75% Senior Notes due April 2028, $1.0 billion principal amount of 5.00% Senior Notes due April 2030, $1.0 billion principal amount of 5.30% Senior Notes due April 2032, and $1.0 billion principal amount of 5.50% Senior Notes due April 2035. The Company utilized the net proceeds of the issuances for general corporate purposes.

[0001571996-25-000102:notes:104]
Outstanding Debt

[0001571996-25-000102:notes:105]
Senior Notes — The Company completed offerings of multiple series of senior notes which were issued on June 1, 2016, June 22, 2016, March 20, 2019, April 9, 2020, December 13, 2021, January 24, 2023, March 18, 2024, October 8, 2024, and April 1, 2025 in aggregate principal amounts of $20.0 billion, $3.3 billion, $4.5 billion, $2.3 billion, $2.3 billion, $2.0 billion, $1.0 billion, $1.5 billion, and $4.0 billion, respectively (collectively, the “Senior Notes”). The Senior Notes currently outstanding have maturity dates ranging from 2026 through 2051. Interest rates on these borrowings are fixed, ranging from 3.38% to 8.35% per annum, and interest is payable semiannually.

[0001571996-25-000102:notes:106]
Legacy Notes — The Company has outstanding unsecured notes and debentures (collectively, the “Legacy Notes”) that were issued by Dell Inc. (“Dell”), a wholly-owned subsidiary of Dell Technologies Inc., prior to the acquisition of Dell by Dell Technologies Inc. in the going-private transaction that closed in October 2013. The Legacy Notes’ maturities range from 2028 through 2040. Interest rates on these borrowings are fixed, ranging from 5.40% to 7.10% per annum, and interest is payable semiannually.

[0001571996-25-000102:notes:107]
DFS Debt — See Note 4 and Note 7 of the Notes to the Condensed Consolidated Financial Statements, respectively, for discussion of DFS debt and the interest rate swap agreements that hedge a portion of that debt.

[0001571996-25-000102:notes:108]
Revolving Credit Facility — The Company’s revolving credit facility provides the Company with revolving commitments in an aggregate principal amount of $6.0 billion for general corporate purposes and includes a letter of credit sub-facility of up to $0.5 billion and a swing-line loan sub-facility of up to $0.5 billion. The revolving credit facility also allows the Company to obtain incremental additional commitments on one or more occasions in minimum amounts of $10 million.

[0001571996-25-000102:notes:109]
Borrowings under the revolving credit facility bear interest at a rate per annum equal to an applicable margin plus, at the borrowers’ option, either (a) the specified adjusted term Secured Overnight Financing Rate (“SOFR”) or (b) a base rate. The margin applicable to SOFR and base rate borrowings varies based upon the Company’s existing credit ratings. The base rate is calculated based upon the greatest of the specified prime rate, the specified federal reserve bank rate, or SOFR plus 1%. The borrowers may voluntarily repay outstanding loans at any time without premium or penalty, other than customary breakage costs. The facility matures on November 1, 2027.

[0001571996-25-000102:notes:110]
As of August 1, 2025, the Company had no outstanding borrowings under the revolving credit facility.

[0001571996-25-000102:notes:111]
Commercial Paper Program — The Company maintains a commercial paper program under which the Company may issue unsecured notes in a maximum aggregate face amount of $5.0 billion outstanding at any time, with maturities of up to 397 days from the date of issuance. The notes are sold on customary terms in the U.S. commercial paper market on a private placement basis. The proceeds of the notes are used for general corporate purposes. As of August 1, 2025, the Company had no outstanding issuances under the commercial paper program.

[0001571996-25-000102:notes:112]
The Company may purchase, redeem, prepay, refinance, or otherwise retire any amount of outstanding indebtedness under the terms of such indebtedness at any time and from time to time, in open market or negotiated transactions with the holders of such indebtedness or otherwise, as considered appropriate in light of market conditions and other relevant factors.

[0001571996-25-000102:notes:113]
Covenants — The credit agreement governing the revolving credit facility and the indentures governing the Senior Notes and the Legacy Notes impose various limitations, subject to exceptions, on creating certain liens and entering into sale and lease-back transactions. The foregoing credit agreement and indentures contain customary events of default, and the revolving credit facility is subject to an interest coverage ratio covenant that is tested at the end of each fiscal quarter with respect to the Company’s preceding four fiscal quarters. The Company was in compliance with this financial covenant as of August 1, 2025.

[0001571996-25-000102:notes:114]
Aggregate Future Maturities

[0001571996-25-000102:notes:115]
The following table presents the aggregate future maturities of the Company’s debt as of August 1, 2025, excluding associated carrying value adjustments, for the periods indicated:

[0001571996-25-000102:notes:116]
|  | August 1, 2025 |
|  | (in millions) |
| Fiscal 2026 (remaining six months) | $ | 2,080 |  |
| Fiscal 2027 | 8,451 |  |
| Fiscal 2028 | 2,343 |  |
| Fiscal 2029 | 2,460 |  |
| Fiscal 2030 | 3,059 |  |
| Thereafter | 10,536 |  |
| Total maturities, principal amount | $ | 28,929 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001571996-25-000102:notes:117]
[same as prior period, unchanged from 0001571996-25-000063:notes:117]

[0001571996-25-000102:notes:118]
[same as prior period, unchanged from 0001571996-25-000063:notes:118]

[0001571996-25-000102:notes:119]
[same as prior period, unchanged from 0001571996-25-000063:notes:119]

[0001571996-25-000102:notes:120]
[same as prior period, unchanged from 0001571996-25-000063:notes:120]

[0001571996-25-000102:notes:121]
During the three and six months ended August 1, 2025 and August 2, 2024, the Company did not discontinue any cash flow hedges related to foreign exchange contracts that had a material impact on the Company’s results of operations due to the probability that the forecasted cash flows would not occur.

[0001571996-25-000102:notes:122]
[same as prior period, unchanged from 0001571996-25-000063:notes:122]

[0001571996-25-000102:notes:123]
[same as prior period, unchanged from 0001571996-25-000063:notes:123]

[0001571996-25-000102:notes:124]
[same as prior period, unchanged from 0001571996-25-000063:notes:124]

[0001571996-25-000102:notes:125]
[same as prior period, unchanged from 0001571996-25-000063:notes:125]

[0001571996-25-000102:notes:126]
Interest rate swaps are utilized to manage the interest rate risk, at a portfolio level, associated with DFS operations in Europe. The interest rate swaps economically convert the fixed rate on financing receivables to a one-month or three-month Euribor floating rate in order to match the floating rate nature of the banks’ funding pool. The Company also uses interest rate swaps to manage the cash flows related to interest payments on Dell Bank senior unsecured eurobonds. The interest rate swaps economically convert the fixed rate on the eurobonds to a floating rate to match the underlying lease repayments profile. These contracts are not designated for hedge accounting and most expire within five years or less. See Note 4 of the Notes to the Condensed Consolidated Financial Statements for more information about the senior unsecured eurobonds.

[0001571996-25-000102:notes:127]
The Company utilizes cross-currency amortizing swaps to hedge the currency and interest rate risk exposure associated with the European securitization program. The cross-currency swaps combine a Euro-based interest rate swap with a British Pound or U.S. Dollar foreign exchange forward contract in which the Company pays a fixed or floating British Pound or U.S. Dollar amount and receives a fixed or floating amount in Euros linked to the one-month Euribor rate. The notional value of the swaps amortizes in line with the expected cash flows and runoff of the securitized assets. The swaps are not designated for hedge accounting and expire within five years or less.

[0001571996-25-000102:notes:128]
[same as prior period, unchanged from 0001571996-25-000063:notes:128]

[0001571996-25-000102:notes:129]
[same as prior period, unchanged from 0001571996-25-000063:notes:129]

[0001571996-25-000102:notes:130]
|  | August 1, 2025 |  | January 31, 2025 |
|  | (in millions) |
| Foreign exchange contracts: |  |  |  |
| Designated as cash flow hedging instruments | $ | 7,540 |  |  | $ | 5,965 |  |
| Non-designated as hedging instruments | 6,092 |  |  | 5,683 |  |
| Total | $ | 13,632 |  |  | $ | 11,648 |  |
| Interest rate contracts: |  |  |  |
| Non-designated as hedging instruments | $ | 6,684 |  |  | $ | 6,353 |  |

[0001571996-25-000102:notes:131]
[same as prior period, unchanged from 0001571996-25-000063:notes:131]

[0001571996-25-000102:notes:132]
| Derivatives in Cash Flow Hedging Relationships |  | Gain (Loss) Recognized in Accumulated OCI, Net of Tax, on Derivatives |  | Location of Gain (Loss) Reclassified from Accumulated OCI into Income |  | Gain (Loss) Reclassified from Accumulated OCI into Income |
|  |  | (in millions) |  |  |  | (in millions) |
| For the three months ended August 1, 2025: |
|  |  |  |  | Total net revenue |  | $ | (159) |  |
| Foreign exchange contracts |  | $ | (4) |  |  | Total cost of net revenue |  | (3) |  |
| Total |  | $ | (4) |  |  | Total |  | $ | (162) |  |
| For the three months ended August 2, 2024: |
|  |  |  |  | Total net revenue |  | $ | 14 |  |
| Foreign exchange contracts |  | $ | (20) |  |  | Total cost of net revenue |  | 4 |  |
| Total |  | $ | (20) |  |  | Total |  | $ | 18 |  |
| For the six months ended August 1, 2025: |
|  |  |  |  | Total net revenue |  | $ | (167) |  |
| Foreign exchange contracts |  | $ | (261) |  |  | Total cost of net revenue |  | (6) |  |
| Total |  | $ | (261) |  |  | Total |  | $ | (173) |  |
| For the six months ended August 2, 2024: |
|  |  |  |  | Total net revenue |  | $ | 32 |  |
| Foreign exchange contracts |  | $ | 67 |  |  | Total cost of net revenue |  | 5 |  |
| Total |  | $ | 67 |  |  | Total |  | $ | 37 |  |

[0001571996-25-000102:notes:133]
[same as prior period, unchanged from 0001571996-25-000063:notes:133]

[0001571996-25-000102:notes:134]
|  | Three Months Ended |  | Six Months Ended |  |  |  |  |
|  | August 1, 2025 |  | August 2, 2024 |  | August 1, 2025 |  | August 2, 2024 |  |  |  | Location of Gain (Loss) Recognized |
|  | (in millions) |  |  |
| Foreign exchange contracts | $ | 31 |  |  | $ | (26) |  |  | $ | 329 |  |  | $ | (45) |  |  |  |  | Interest and other, net |
| Interest rate contracts | (14) |  |  | 28 |  |  | (28) |  |  | (11) |  |  |  |  | Interest and other, net |
| Total | $ | 17 |  |  | $ | 2 |  |  | $ | 301 |  |  | $ | (56) |  |  |  |  |  |

[0001571996-25-000102:notes:135]
[same as prior period, unchanged from 0001571996-25-000063:notes:135]

[0001571996-25-000102:notes:136]
|  | August 1, 2025 |
|  | Other Current Assets |  | Other Non-Current Assets |  | Other Current Liabilities |  | Other Non-Current Liabilities |  | Total Fair Value |
|  | (in millions) |
| Derivatives designated as hedging instruments: |
| Foreign exchange contracts in an asset position | $ | 98 |  |  | $ | — |  |  | $ | 49 |  |  | $ | — |  |  | $ | 147 |  |
| Foreign exchange contracts in a liability position | (2) |  |  | — |  |  | (5) |  |  | — |  |  | (7) |  |
| Net asset (liability) | 96 |  |  | — |  |  | 44 |  |  | — |  |  | 140 |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts in an asset position | 79 |  |  | — |  |  | 81 |  |  | — |  |  | 160 |  |
| Foreign exchange contracts in a liability position | (75) |  |  | — |  |  | (244) |  |  | — |  |  | (319) |  |
| Interest rate contracts in an asset position | — |  |  | 50 |  |  | — |  |  | — |  |  | 50 |  |
| Interest rate contracts in a liability position | — |  |  | — |  |  | — |  |  | (39) |  |  | (39) |  |
| Net asset (liability) | 4 |  |  | 50 |  |  | (163) |  |  | (39) |  |  | (148) |  |
| Total derivatives at fair value | $ | 100 |  |  | $ | 50 |  |  | $ | (119) |  |  | $ | (39) |  |  | $ | (8) |  |
|  | January 31, 2025 |
|  | Other Current Assets |  | Other Non-Current Assets |  | Other Current Liabilities |  | Other Non-Current Liabilities |  | Total Fair Value |
|  | (in millions) |
| Derivatives designated as hedging instruments: |
| Foreign exchange contracts in an asset position | $ | 136 |  |  | $ | — |  |  | $ | 9 |  |  | $ | — |  |  | $ | 145 |  |
| Foreign exchange contracts in a liability position | (7) |  |  | — |  |  | (3) |  |  | — |  |  | (10) |  |
| Net asset (liability) | 129 |  |  | — |  |  | 6 |  |  | — |  |  | 135 |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts in an asset position | 430 |  |  | — |  |  | 53 |  |  | — |  |  | 483 |  |
| Foreign exchange contracts in a liability position | (297) |  |  | — |  |  | (90) |  |  | — |  |  | (387) |  |
| Interest rate contracts in an asset position | — |  |  | 40 |  |  | — |  |  | — |  |  | 40 |  |
| Interest rate contracts in a liability position | — |  |  | — |  |  | (1) |  |  | (43) |  |  | (44) |  |
| Net asset (liability) | 133 |  |  | 40 |  |  | (38) |  |  | (43) |  |  | 92 |  |
| Total derivatives at fair value | $ | 262 |  |  | $ | 40 |  |  | $ | (32) |  |  | $ | (43) |  |  | $ | 227 |  |

[0001571996-25-000102:notes:137]
[same as prior period, unchanged from 0001571996-25-000063:notes:137]

[0001571996-25-000102:notes:138]
|  | August 1, 2025 |
|  | Gross Amounts of Recognized Assets/(Liabilities) |  | Gross Amounts Offset in the Statement of Financial Position |  | Net Amounts of Assets/(Liabilities) Presented in the Statement of Financial Position |  | Gross Amounts not Offset in the Statement of Financial Position |  | Net Amount of Assets/ (Liabilities) Recognized in the Statement of Financial Position |
|  | Financial Instruments |  | Cash Collateral Received or Pledged |  |
|  | (in millions) |
| Derivative instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Financial assets | $ | 357 |  |  | $ | (207) |  |  | $ | 150 |  |  | $ | — |  |  | $ | (68) |  |  | $ | 82 |  |
| Financial liabilities | (365) |  |  | 207 |  |  | (158) |  |  | — |  |  | 2 |  |  | (156) |  |
| Total derivative instruments | $ | (8) |  |  | $ | — |  |  | $ | (8) |  |  | $ | — |  |  | $ | (66) |  |  | $ | (74) |  |
|  | January 31, 2025 |
|  | Gross Amounts of Recognized Assets/(Liabilities) |  | Gross Amounts Offset in the Statement of Financial Position |  | Net Amounts of Assets/(Liabilities) Presented in the Statement of Financial Position |  | Gross Amounts not Offset in the Statement of Financial Position |  | Net Amount of Assets/ (Liabilities) Recognized in the Statement of Financial Position |
|  | Financial Instruments |  | Cash Collateral Received or Pledged |  |
|  | (in millions) |
| Derivative instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Financial assets | $ | 668 |  |  | $ | (366) |  |  | $ | 302 |  |  | $ | — |  |  | $ | (36) |  |  | $ | 266 |  |
| Financial liabilities | (441) |  |  | 366 |  |  | (75) |  |  | — |  |  | 8 |  |  | (67) |  |
| Total derivative instruments | $ | 227 |  |  | $ | — |  |  | $ | 227 |  |  | $ | — |  |  | $ | (28) |  |  | $ | 199 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001571996-25-000102:notes:139]
[same as prior period, unchanged from 0001571996-25-000063:notes:139]

[0001571996-25-000102:notes:140]
[same as prior period, unchanged from 0001571996-25-000063:notes:140]

[0001571996-25-000102:notes:141]
[same as prior period, unchanged from 0001571996-25-000063:notes:141]

[0001571996-25-000102:notes:142]
|  | Infrastructure Solutions Group |  | Client Solutions Group |  |  |  | Total |
|  | (in millions) |
| Balances as of January 31, 2025 | $ | 14,888 |  |  | $ | 4,232 |  |  |  |  | $ | 19,120 |  |
| Impact of foreign currency translation | 216 |  |  | — |  |  |  |  | 216 |  |
| Balances as of August 1, 2025 | $ | 15,104 |  |  | $ | 4,232 |  |  |  |  | $ | 19,336 |  |

[0001571996-25-000102:notes:143]
[same as prior period, unchanged from 0001571996-25-000063:notes:143]

[0001571996-25-000102:notes:144]
[same as prior period, unchanged from 0001571996-25-000063:notes:144]

[0001571996-25-000102:notes:145]
|  | August 1, 2025 |  | January 31, 2025 |
|  | Gross |  | Accumulated Amortization |  | Net |  | Gross |  | Accumulated Amortization |  | Net |
|  | (in millions) |
| Customer relationships | $ | 16,644 |  |  | $ | (15,167) |  |  | $ | 1,477 |  |  | $ | 16,642 |  |  | $ | (15,013) |  |  | $ | 1,629 |  |
| Developed technology | 9,500 |  |  | (9,294) |  |  | 206 |  |  | 9,500 |  |  | (9,211) |  |  | 289 |  |
| Trade names | 875 |  |  | (865) |  |  | 10 |  |  | 875 |  |  | (860) |  |  | 15 |  |
| Definite-lived intangible assets | 27,019 |  |  | (25,326) |  |  | 1,693 |  |  | 27,017 |  |  | (25,084) |  |  | 1,933 |  |
| Indefinite-lived trade names | 3,055 |  |  | — |  |  | 3,055 |  |  | 3,055 |  |  | — |  |  | 3,055 |  |
| Total intangible assets | $ | 30,074 |  |  | $ | (25,326) |  |  | $ | 4,748 |  |  | $ | 30,072 |  |  | $ | (25,084) |  |  | $ | 4,988 |  |

[0001571996-25-000102:notes:146]
Amortization expense related to definite-lived intangible assets was $0.1 billion and $0.2 billion for the three months ended August 1, 2025 and August 2, 2024, respectively, and $0.2 billion and $0.3 billion for the six months ended August 1, 2025 and August 2, 2024, respectively. There were no material impairment charges related to intangible assets during the three or six months ended August 1, 2025 and August 2, 2024.

[0001571996-25-000102:notes:147]
[same as prior period, unchanged from 0001571996-25-000063:notes:147]

[0001571996-25-000102:notes:148]
|  | August 1, 2025 |
|  | (in millions) |
| Fiscal 2026 (remaining six months) | $ | 240 |  |
| Fiscal 2027 | 372 |  |
| Fiscal 2028 | 230 |  |
| Fiscal 2029 | 190 |  |
| Fiscal 2030 | 153 |  |
| Thereafter | 508 |  |
| Total | $ | 1,693 |  |

[0001571996-25-000102:notes:149]
[same as prior period, unchanged from 0001571996-25-000063:notes:149]

[0001571996-25-000102:notes:150]
[same as prior period, unchanged from 0001571996-25-000063:notes:150]

[0001571996-25-000102:notes:151]
[same as prior period, unchanged from 0001571996-25-000063:notes:151]

[0001571996-25-000102:notes:152]
[same as prior period, unchanged from 0001571996-25-000063:notes:152]

[0001571996-25-000102:notes:153]
[same as prior period, unchanged from 0001571996-25-000063:notes:153]

[0001571996-25-000102:notes:154]
Based on the results of the annual impairment test performed during Fiscal 2025, the fair values of each of the reporting units and indefinite-lived intangibles exceeded their carrying values. No goodwill or indefinite-lived assets impairment test was performed during the six months ended August 1, 2025.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001571996-25-000102:notes:155]
[same as prior period, unchanged from 0001571996-25-000063:notes:155]

[0001571996-25-000102:notes:156]
[same as prior period, unchanged from 0001571996-25-000063:notes:156]

[0001571996-25-000102:notes:157]
|  | Three Months Ended |  | Six Months Ended |
|  | August 1, 2025 |  | August 2, 2024 |  | August 1, 2025 |  | August 2, 2024 |
|  | (in millions) |
| Deferred revenue: |  |  |  |  |  |  |  |
| Deferred revenue at beginning of period | $ | 26,320 |  |  | $ | 28,150 |  |  | $ | 25,965 |  |  | $ | 29,145 |  |
| Revenue deferrals | 4,972 |  |  | 4,920 |  |  | 10,427 |  |  | 9,389 |  |
| Revenue recognized | (5,111) |  |  | (5,358) |  |  | (10,211) |  |  | (10,822) |  |
| Deferred revenue at end of period | $ | 26,181 |  |  | $ | 27,712 |  |  | $ | 26,181 |  |  | $ | 27,712 |  |
| Short-term deferred revenue | $ | 13,759 |  |  | $ | 14,853 |  |  | $ | 13,759 |  |  | $ | 14,853 |  |
| Long-term deferred revenue | $ | 12,422 |  |  | $ | 12,859 |  |  | $ | 12,422 |  |  | $ | 12,859 |  |

[0001571996-25-000102:notes:158]
Remaining Performance Obligations — Remaining performance obligations represent the aggregate amount of the transaction price allocated to performance obligations not delivered, or partially undelivered, as of the end of the reporting period. Remaining performance obligations include deferred revenue plus unbilled amounts not yet recorded in deferred revenue. The value of the transaction price allocated to remaining performance obligations as of August 1, 2025 was approximately $44 billion. The Company expects to recognize approximately 65% of remaining performance obligations as revenue in the next twelve months, 17% in the following twelve months, and the remainder thereafter.

[0001571996-25-000102:notes:159]
[same as prior period, unchanged from 0001571996-25-000063:notes:159]

[0001571996-25-000102:notes:160]
[same as prior period, unchanged from 0001571996-25-000063:notes:160]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001571996-25-000102:notes:161]
COMMITMENTS AND CONTINGENCIES 
Purchase Obligations

[0001571996-25-000102:notes:162]
The Company has contractual obligations to purchase goods or services, which specify significant terms (including fixed or minimum quantities to be purchased), fixed, minimum, or variable price provisions, and the approximate timing of the transaction. Purchase obligations are primarily related to commitments with suppliers and software maintenance and support services. As of August 1, 2025, such purchase obligations were $5.1 billion for the remainder of Fiscal 2026, $0.7 billion for Fiscal 2027, $0.5 billion for Fiscal 2028, $0.4 billion for Fiscal 2029, and $0.5 billion for Fiscal 2030 and thereafter.

[0001571996-25-000102:notes:163]
Legal Matters

[0001571996-25-000102:notes:164]
The Company is involved in various claims, suits, assessments, investigations, and legal proceedings that arise from time to time in the ordinary course of its business, consisting of matters involving consumer, antitrust, tax, intellectual property, and other issues on a global basis.

[0001571996-25-000102:notes:165]
The Company accrues a liability when it believes that it is both probable that a liability has been incurred and that it can reasonably estimate the amount of the loss. The Company reviews these accruals at least quarterly and adjusts them to reflect ongoing negotiations, settlements, rulings, advice of legal counsel, and other relevant information. To the extent new information is obtained and the Company’s views on the probable outcomes of claims, suits, assessments, investigations, or legal proceedings change, changes in the Company’s accrued liabilities are recorded in the period in which such a determination is made. For some matters, the incurrence of a liability is not probable or the amount cannot be reasonably estimated and therefore accruals have not been made. As of August 1, 2025, the Company does not currently anticipate that any of the legal proceedings it is involved in will have a material adverse effect on its business, financial condition, results of operations, or cash flows.

[0001571996-25-000102:notes:166]
In accordance with the relevant accounting guidance, the Company provides disclosures of matters where it is at least reasonably possible that the Company could experience a material loss exceeding the amounts already accrued for across all proceedings or matters. In addition, the Company also discloses matters based on its consideration of other matters and qualitative factors, including the experience of other companies in the industry, and investor, customer, and employee relations considerations. As of August 1, 2025, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for across all proceedings or matters has been incurred. However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company’s business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters. Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company’s business, financial condition, results of operations, or cash flows will depend on a number of factors, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.

[0001571996-25-000102:notes:167]
Indemnifications Obligations

[0001571996-25-000102:notes:168]
In the ordinary course of business, the Company enters into various contracts under which it may agree to indemnify other parties for losses incurred from certain events as defined in the relevant contract, such as litigation, regulatory penalties, or claims relating to past performance. Such indemnification obligations may not be subject to maximum loss clauses. Historically, payments related to these indemnification obligations have not been material to the Company.

[0001571996-25-000102:notes:169]
Under the Separation and Distribution Agreement entered into with VMware, Inc. upon completion of its spin-off of VMware, Inc. on November 1, 2021, Dell Technologies agreed to indemnify VMware, Inc., each of its subsidiaries and each of their respective directors, officers, employees, as well as any successors and assigns of the foregoing, from and against all liabilities relating to, arising out of or resulting from, among other matters, the liabilities allocated to Dell Technologies as part of the separation of Dell Technologies and VMware, Inc. (currently operating under the name VMware LLC, and individually and together with its subsidiaries, “VMware”) and their respective businesses (the “Separation”). VMware similarly agreed to indemnify Dell Technologies Inc., each of its subsidiaries and each of their respective directors, officers, and employees from and against all liabilities relating to, arising out of or resulting from, among other matters, the liabilities allocated to VMware as part of the Separation. The amounts that VMware and Dell Technologies may be obligated to pay each other could vary depending on the outcome of certain unresolved tax matters, which may not be resolved for several years. Net income tax indemnification receivables from VMware were immaterial as of August 1, 2025 and January 31, 2025.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001571996-25-000102:notes:170]
INCOME AND OTHER TAXES
For the three months ended August 1, 2025, the Company’s effective income tax rate was 19.2% on pre-tax income of $1.4 billion compared to 15.1% on pre-tax income of $1.0 billion for the three months ended August 2, 2024. For the six months ended August 1, 2025, the Company’s effective income tax rate was 15.6% on pre-tax income of $2.5 billion compared to (14.9)% on pre-tax income of $1.6 billion for the six months ended August 2, 2024. The changes in the Company’s effective income tax rate were primarily driven by discrete tax items. For the six months ended August 2, 2024, the Company recorded discrete tax benefits of $0.4 billion related to changes in uncertain tax benefits resulting from the expiration of certain U.S. statutes of limitations and $0.2 billion related to stock-based compensation.

[0001571996-25-000102:notes:171]
On July 4, 2025, the One Big Beautiful Bill Act (“OBBBA”) was enacted into law in the United States. The new law contains a broad range of tax reform provisions, which include the extension and modification of certain provisions of the Tax Cuts and Jobs Act. Effective for Fiscal 2026, changes include, but are not limited to, immediate expensing of domestic research and development expenditures, the restoration of 100% bonus depreciation, and an EBITDA-based interest expense limitation. These provisions did not have a material impact on the Company’s Condensed Consolidated Financial Statements for the six months ended August 1, 2025.

[0001571996-25-000102:notes:172]
The differences between the estimated effective income tax rates and the U.S. federal statutory rate of 21% principally result from the geographical distribution of income, differences between the book and tax treatment of certain items, and discrete tax items. In certain jurisdictions, the Company’s tax rate is significantly less than the applicable statutory rate as a result of tax holidays. The majority of the Company’s foreign income subject to these tax holidays and lower tax rates is attributable to Singapore and China. As of August 1, 2025, the Company was not aware of any matters of non-compliance related to these tax holidays.

[0001571996-25-000102:notes:173]
[same as prior period, unchanged from 0001571996-25-000063:notes:172]

[0001571996-25-000102:notes:174]
[same as prior period, unchanged from 0001571996-25-000063:notes:173]

[0001571996-25-000102:notes:175]
[same as prior period, unchanged from 0001571996-25-000063:notes:174]

[0001571996-25-000102:notes:176]
Judgment is required in evaluating the Company’s uncertain tax positions and determining the Company’s provision for income taxes. Net unrecognized tax benefits were $1.0 billion and $0.9 billion as of August 1, 2025 and January 31, 2025, respectively, and are included in other non-current liabilities in the Condensed Consolidated Statements of Financial Position.

[0001571996-25-000102:notes:177]
The Company takes certain non-income tax positions in the jurisdictions in which it operates and has received certain non-income tax assessments from various jurisdictions. The Company believes that a material loss in these matters is not probable and that it is not reasonably possible that a material loss exceeding amounts already accrued has been incurred. The Company believes its positions in these non-income tax litigation matters are supportable and that it ultimately will prevail in the matters. In the normal course of business, the Company’s positions and conclusions related to its non-income taxes could be challenged and assessments may be made. To the extent new information is obtained and the Company’s views on its positions, probable outcomes of assessments, or litigation change, changes in estimates to the Company’s accrued liabilities would be recorded in the period in which such a determination is made. In the resolution process for income tax and non-income tax audits, the Company is required in certain situations to provide collateral guarantees or indemnification to regulators and tax authorities until the matter is resolved.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001571996-25-000102:notes:178]
[same as prior period, unchanged from 0001571996-25-000063:notes:177]

[0001571996-25-000102:notes:179]
[same as prior period, unchanged from 0001571996-25-000063:notes:178]

[0001571996-25-000102:notes:180]
|  | Foreign Currency Translation Adjustments |  |  |  | Cash Flow Hedges |  | Pension and Other Postretirement Plans |  | Accumulated Other Comprehensive Income (Loss) |
|  | (in millions) |
| Balances as of January 31, 2025 | $ | (1,023) |  |  |  |  | $ | 105 |  |  | $ | (21) |  |  | $ | (939) |  |
| Other comprehensive income (loss) before reclassifications | 310 |  |  |  |  | (261) |  |  | (1) |  |  | 48 |  |
| Amounts reclassified from accumulated other comprehensive income (loss) | — |  |  |  |  | 173 |  |  | — |  |  | 173 |  |
| Sale of Secureworks (a) | 8 |  |  |  |  | — |  |  | — |  |  | 8 |  |
| Total change for the period | 318 |  |  |  |  | (88) |  |  | (1) |  |  | 229 |  |
| Balances as of August 1, 2025 | $ | (705) |  |  |  |  | $ | 17 |  |  | $ | (22) |  |  | $ | (710) |  |

[0001571996-25-000102:notes:181]
[same as prior period, unchanged from 0001571996-25-000063:notes:180]

[0001571996-25-000102:notes:182]
[same as prior period, unchanged from 0001571996-25-000063:notes:181]

[0001571996-25-000102:notes:183]
The following tables present reclassifications out of accumulated other comprehensive income (loss), net of tax, to net income for the periods indicated:

[0001571996-25-000102:notes:184]
|  | Three Months Ended |  |  |  |  |  |  |  |  |
|  | August 1, 2025 |  | August 2, 2024 |  |  |  |  |  |  |  |  |
|  | Cash Flow Hedges |  | Pensions |  | Total |  | Cash Flow Hedges |  | Pensions |  | Total |  |  |  |  |  |  |  |  |
|  | (in millions) |  |  |  |  |  |  |  |  |
| Total reclassifications, net of tax: |  |  |  |  |  |  |  |  |
| Net revenue | $ | (159) |  |  | $ | — |  |  | $ | (159) |  |  | $ | 14 |  |  | $ | — |  |  | $ | 14 |  |  |  |  |  |  |  |  |  |
| Cost of net revenue | (3) |  |  | — |  |  | (3) |  |  | 4 |  |  | — |  |  | 4 |  |  |  |  |  |  |  |  |  |
| Total reclassifications, net of tax | $ | (162) |  |  | $ | — |  |  | $ | (162) |  |  | $ | 18 |  |  | $ | — |  |  | $ | 18 |  |  |  |  |  |  |  |  |  |

[0001571996-25-000102:notes:185]
|  |  |  | Six Months Ended |
|  |  |  | August 1, 2025 |  | August 2, 2024 |  |  |
|  |  |  | Cash Flow Hedges |  |  |  |  |  | Pensions |  |  |  | Total |  | Cash Flow Hedges |  | Pensions |  | Total |  |  |  |  |  |  |
|  |  |  | (in millions) |
| Total reclassifications, net of tax: |  |  |  |  |  |  |
| Net revenue |  |  | $ | (167) |  |  |  |  |  |  | $ | — |  |  |  |  | $ | (167) |  |  | $ | 32 |  |  | $ | — |  |  | $ | 32 |  |  |  |  |  |  |  |
| Cost of net revenue |  |  | (6) |  |  |  |  |  |  | — |  |  |  |  | (6) |  |  | 5 |  |  | — |  |  | 5 |  |  |  |  |  |  |  |
| Operating expenses |  |  | — |  |  |  |  |  |  | — |  |  |  |  | — |  |  | — |  |  | 1 |  |  | 1 |  |  |  |  |  |  |  |
| Total reclassifications, net of tax |  |  | $ | (173) |  |  |  |  |  |  | $ | — |  |  |  |  | $ | (173) |  |  | $ | 37 |  |  | $ | 1 |  |  | $ | 38 |  |  |  |  |  |  |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001571996-25-000102:notes:186]
[same as prior period, unchanged from 0001571996-25-000063:notes:184]

[0001571996-25-000102:notes:187]
|  | Authorized |  | Issued |  | Outstanding |
|  | (in millions) |
| Common stock as of August 1, 2025 |
| Class A | 600 |  |  | 277 |  |  | 277 |  |
| Class B | 200 |  |  | 59 |  |  | 59 |  |
| Class C | 7,900 |  |  | 507 |  |  | 339 |  |
| Class D | 100 |  |  | — |  |  | — |  |
|  | 8,800 |  |  | 843 |  |  | 675 |  |
| Common stock as of January 31, 2025 |
| Class A | 600 |  |  | 277 |  |  | 277 |  |
| Class B | 200 |  |  | 62 |  |  | 62 |  |
| Class C | 7,900 |  |  | 495 |  |  | 357 |  |
| Class D | 100 |  |  | — |  |  | — |  |
|  | 8,800 |  |  | 834 |  |  | 696 |  |

[0001571996-25-000102:notes:188]
[same as prior period, unchanged from 0001571996-25-000063:notes:186]

[0001571996-25-000102:notes:189]
The Company is authorized to issue one million shares of preferred stock, par value $0.01 per share. As of August 1, 2025 and January 31, 2025, no shares of preferred stock were issued or outstanding.

[0001571996-25-000102:notes:190]
[same as prior period, unchanged from 0001571996-25-000063:notes:188]

[0001571996-25-000102:notes:191]
[same as prior period, unchanged from 0001571996-25-000063:notes:189]

[0001571996-25-000102:notes:192]
[same as prior period, unchanged from 0001571996-25-000063:notes:190]

[0001571996-25-000102:notes:193]
[same as prior period, unchanged from 0001571996-25-000063:notes:191]

[0001571996-25-000102:notes:194]
During the six months ended August 1, 2025, the company issued 3 million shares of Class C Common Stock to stockholders upon the conversion of 3 million shares of Class B Common Stock in accordance with the Company’s certificate of incorporation. During the fiscal year ended January 31, 2025, the Company issued 100 million shares of Class C Common Stock to stockholders upon the conversion of 76 million shares of Class A Common Stock and 24 million shares of Class B Common Stock in accordance with the Company’s certificate of incorporation.

[0001571996-25-000102:notes:195]
[same as prior period, unchanged from 0001571996-25-000063:notes:193]

[0001571996-25-000102:notes:196]
[same as prior period, unchanged from 0001571996-25-000063:notes:194]

[0001571996-25-000102:notes:197]
[same as prior period, unchanged from 0001571996-25-000063:notes:195]

[0001571996-25-000102:notes:198]
|  |  | Declaration Date |  | Record Date |  | Payment Date |  | Dividend per Share |  | Amount (in millions) |
|  |  | Fiscal 2026 |
|  |  | February 27, 2025 |  | April 22, 2025 |  | May 2, 2025 |  | $ | 0.525 |  |  | $ | 360 |  |
|  |  | June 17, 2025 |  | July 22, 2025 |  | August 1, 2025 |  | $ | 0.525 |  |  | $ | 355 |  |
|  |  | Fiscal 2025 |
|  |  | February 29, 2024 |  | April 23, 2024 |  | May 3, 2024 |  | $ | 0.445 |  |  | $ | 316 |  |
|  |  | June 11, 2024 |  | July 23, 2024 |  | August 2, 2024 |  | $ | 0.445 |  |  | $ | 314 |  |

[0001571996-25-000102:notes:199]
During the three and six months ended August 1, 2025 and August 2, 2024, the Company also paid an immaterial amount of dividend equivalents on eligible vested equity awards which are not included above.

[0001571996-25-000102:notes:200]
[same as prior period, unchanged from 0001571996-25-000063:notes:198]

[0001571996-25-000102:notes:201]
[same as prior period, unchanged from 0001571996-25-000063:notes:199]

[0001571996-25-000102:notes:202]
During the six months ended August 1, 2025, the Company repurchased approximately 30 million shares of Class C Common Stock for a total purchase price of approximately $2.9 billion. During the six months ended August 2, 2024, the Company repurchased approximately 12 million shares of Class C Common Stock for a total purchase price of approximately $1.4 billion. 
The above repurchases of Class C Common Stock exclude U.S. federal excise taxes and shares withheld from stock awards to settle employee tax withholding obligations related to the vesting of such awards.


## us-gaap:EarningsPerShareTextBlock

[0001571996-25-000102:notes:203]
[same as prior period, unchanged from 0001571996-25-000063:notes:201]

[0001571996-25-000102:notes:204]
[same as prior period, unchanged from 0001571996-25-000063:notes:202]

[0001571996-25-000102:notes:205]
|  | Three Months Ended |  | Six Months Ended |
|  | August 1, 2025 |  | August 2, 2024 |  | August 1, 2025 |  | August 2, 2024 |  |  |
| Earnings per share attributable to Dell Technologies Inc. |  |  |
| Dell Technologies Common Stock — Basic | $ | 1.72 |  |  | $ | 1.25 |  |  | $ | 3.11 |  |  | $ | 2.66 |  |  |  |
| Dell Technologies Common Stock — Diluted | $ | 1.70 |  |  | $ | 1.23 |  |  | $ | 3.07 |  |  | $ | 2.60 |  |  |  |

[0001571996-25-000102:notes:206]
[same as prior period, unchanged from 0001571996-25-000063:notes:204]

[0001571996-25-000102:notes:207]
|  | Three Months Ended |  | Six Months Ended |
|  | August 1, 2025 |  | August 2, 2024 |  | August 1, 2025 |  | August 2, 2024 |  |  |
|  | (in millions) |
| Numerator: Dell Technologies Common Stock |  |  |  |  |  |  |  |  |  |
| Net income attributable to Dell Technologies Inc. — basic and diluted | $ | 1,164 |  |  | $ | 887 |  |  | $ | 2,129 |  |  | $ | 1,884 |  |  |  |
| Denominator: Dell Technologies Common Stock weighted-average shares outstanding |  |  |  |  |  |  |  |  |  |
| Weighted-average shares outstanding — basic | 678 |  |  | 708 |  |  | 685 |  |  | 708 |  |  |  |
| Dilutive effect of equity awards | 8 |  |  | 16 |  |  | 9 |  |  | 17 |  |  |  |
| Weighted-average shares outstanding — diluted | 686 |  |  | 724 |  |  | 694 |  |  | 725 |  |  |  |
| Weighted-average shares outstanding — antidilutive | — |  |  | — |  |  | 2 |  |  | — |  |  |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001571996-25-000102:notes:208]
[same as prior period, unchanged from 0001571996-25-000063:notes:206]

[0001571996-25-000102:notes:209]
[same as prior period, unchanged from 0001571996-25-000063:notes:207]

[0001571996-25-000102:notes:210]
[same as prior period, unchanged from 0001571996-25-000063:notes:208]

[0001571996-25-000102:notes:211]
[same as prior period, unchanged from 0001571996-25-000063:notes:209]

[0001571996-25-000102:notes:212]
[same as prior period, unchanged from 0001571996-25-000063:notes:210]

[0001571996-25-000102:notes:213]
[same as prior period, unchanged from 0001571996-25-000063:notes:211]

[0001571996-25-000102:notes:214]
|  | Three Months Ended |  | Six Months Ended |
|  | August 1, 2025 |  | August 2, 2024 |  | August 1, 2025 |  | August 2, 2024 |  |  |
|  | (in millions) |
| Consolidated net revenue: |  |  |  |  |  |  |  |  |  |
| Infrastructure Solutions Group | $ | 16,800 |  |  | $ | 11,646 |  |  | $ | 27,117 |  |  | $ | 20,873 |  |  |  |
| Client Solutions Group | 12,503 |  |  | 12,414 |  |  | 25,012 |  |  | 24,381 |  |  |  |
| Reportable segment net revenue | 29,303 |  |  | 24,060 |  |  | 52,129 |  |  | 45,254 |  |  |  |
| Corporate and other (a) | 473 |  |  | 966 |  |  | 1,025 |  |  | 2,016 |  |  |  |
| Total consolidated net revenue | $ | 29,776 |  |  | $ | 25,026 |  |  | $ | 53,154 |  |  | $ | 47,270 |  |  |  |
| Consolidated operating income: |  |  |  |  |  |  |  |  |  |
| Infrastructure Solutions Group | $ | 1,470 |  |  | $ | 1,284 |  |  | $ | 2,468 |  |  | $ | 2,020 |  |  |  |
| Client Solutions Group | 803 |  |  | 817 |  |  | 1,456 |  |  | 1,594 |  |  |  |
| Reportable segment operating income (b) | 2,273 |  |  | 2,101 |  |  | 3,924 |  |  | 3,614 |  |  |  |
| Corporate and other (a) | 11 |  |  | (17) |  |  | 26 |  |  | (11) |  |  |  |
| Amortization of intangibles (c) | (125) |  |  | (168) |  |  | (251) |  |  | (336) |  |  |  |
| Stock-based compensation expense (d) | (179) |  |  | (191) |  |  | (369) |  |  | (401) |  |  |  |
| Other corporate expenses (e) | (207) |  |  | (333) |  |  | (392) |  |  | (509) |  |  |  |
| Total consolidated operating income (f) | $ | 1,773 |  |  | $ | 1,392 |  |  | $ | 2,938 |  |  | $ | 2,357 |  |  |  |

[0001571996-25-000102:notes:215]
[same as prior period, unchanged from 0001571996-25-000063:notes:213]

[0001571996-25-000102:notes:216]
[same as prior period, unchanged from 0001571996-25-000063:notes:214]

[0001571996-25-000102:notes:217]
(c)Amortization of intangibles includes non-cash purchase accounting adjustments that are primarily related to the acquisition by merger of EMC Corporation in 2016.

[0001571996-25-000102:notes:218]
[same as prior period, unchanged from 0001571996-25-000063:notes:216]

[0001571996-25-000102:notes:219]
[same as prior period, unchanged from 0001571996-25-000063:notes:217]

[0001571996-25-000102:notes:220]
(f)Income and expenses within interest and other, net, is not allocated to the reportable segments. Therefore, the Company does not report below reportable segment operating income.

[0001571996-25-000102:notes:221]
[same as prior period, unchanged from 0001571996-25-000063:notes:219]

[0001571996-25-000102:notes:222]
|  | Three Months Ended |  | Six Months Ended |
|  | August 1, 2025 |  | August 2, 2024 |  | August 1, 2025 |  | August 2, 2024 |  |  |
|  | (in millions) |
| Infrastructure Solutions Group: |  |  |  |  |  |  |  |  |  |
| Cost of net revenue | $ | 13,164 |  |  | $ | 8,129 |  |  | $ | 20,214 |  |  | $ | 14,333 |  |  |  |
| Selling, general, and administrative | $ | 1,604 |  |  | $ | 1,698 |  |  | $ | 3,299 |  |  | $ | 3,457 |  |  |  |
| Research and development | $ | 562 |  |  | $ | 535 |  |  | $ | 1,136 |  |  | $ | 1,063 |  |  |  |
| Client Solutions Group: |  |  |  |  |  |  |  |  |  |
| Cost of net revenue | $ | 10,582 |  |  | $ | 10,511 |  |  | $ | 21,320 |  |  | $ | 20,626 |  |  |  |
| Selling, general, and administrative | $ | 972 |  |  | $ | 960 |  |  | $ | 1,954 |  |  | $ | 1,921 |  |  |  |
| Research and development | $ | 146 |  |  | $ | 126 |  |  | $ | 282 |  |  | $ | 240 |  |  |  |

[0001571996-25-000102:notes:223]
[same as prior period, unchanged from 0001571996-25-000063:notes:221]

[0001571996-25-000102:notes:224]
|  | Three Months Ended |  | Six Months Ended |
|  | August 1, 2025 |  | August 2, 2024 |  | August 1, 2025 |  | August 2, 2024 |  |  |
|  | (in millions) |
| Net revenue: |  |  |  |  |  |  |  |  |  |
| Infrastructure Solutions Group: |  |  |  |  |  |  |  |  |  |
| Servers and networking | $ | 12,944 |  |  | $ | 7,672 |  |  | $ | 19,265 |  |  | $ | 13,138 |  |  |  |
| Storage | 3,856 |  |  | 3,974 |  |  | 7,852 |  |  | 7,735 |  |  |  |
| Total ISG net revenue | $ | 16,800 |  |  | $ | 11,646 |  |  | $ | 27,117 |  |  | $ | 20,873 |  |  |  |
| Client Solutions Group: |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 10,781 |  |  | $ | 10,556 |  |  | $ | 21,827 |  |  | $ | 20,710 |  |  |  |
| Consumer | 1,722 |  |  | 1,858 |  |  | 3,185 |  |  | 3,671 |  |  |  |
| Total CSG net revenue | $ | 12,503 |  |  | $ | 12,414 |  |  | $ | 25,012 |  |  | $ | 24,381 |  |  |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001571996-25-000102:notes:225]
[same as prior period, unchanged from 0001571996-25-000063:notes:223]

[0001571996-25-000102:notes:226]
|  | August 1, 2025 |  | January 31, 2025 |
|  | (in millions) |
| Cash, cash equivalents, and restricted cash: |  |  |  |
| Cash and cash equivalents | $ | 8,145 |  |  | $ | 3,633 |  |
| Cash and cash equivalents — held for sale (a) | — |  |  | 62 |  |
| Restricted cash (b) | 146 |  |  | 124 |  |
| Total cash, cash equivalents, and restricted cash | $ | 8,291 |  |  | $ | 3,819 |  |
| Inventories: |  |  |  |
| Production materials | $ | 4,677 |  |  | $ | 4,432 |  |
| Work-in-process | 1,603 |  |  | 1,128 |  |
| Finished goods | 931 |  |  | 1,156 |  |
| Total inventories | $ | 7,211 |  |  | $ | 6,716 |  |
| Prepaid expenses: |  |  |  |
| Total prepaid expenses (c) | $ | 752 |  |  | $ | 564 |  |
| Deferred costs: |  |  |  |
| Total deferred costs, current (c) | $ | 3,695 |  |  | $ | 4,129 |  |
| Property, plant, and equipment, net: |  |  |  |
| Assets in a customer contract | $ | 5,673 |  |  | $ | 5,204 |  |
| Computer and other equipment | 3,896 |  |  | 3,651 |  |
| Land and buildings | 2,963 |  |  | 2,838 |  |
| Internal use software | 2,485 |  |  | 2,403 |  |
| Total property, plant, and equipment | 15,017 |  |  | 14,096 |  |
| Accumulated depreciation and amortization | (8,559) |  |  | (7,760) |  |
| Total property, plant, and equipment, net | $ | 6,458 |  |  | $ | 6,336 |  |

[0001571996-25-000102:notes:227]
[same as prior period, unchanged from 0001571996-25-000063:notes:225]

[0001571996-25-000102:notes:228]
[same as prior period, unchanged from 0001571996-25-000063:notes:226]

[0001571996-25-000102:notes:229]
(c)Deferred costs and prepaid expenses are included in other current assets in the Condensed Consolidated Statements of Financial Position. Amounts classified as long-term deferred costs and long-term prepaid expenses are included in other non-current assets and are not disclosed above.

[0001571996-25-000102:notes:230]
[same as prior period, unchanged from 0001571996-25-000063:notes:229]

[0001571996-25-000102:notes:231]
[same as prior period, unchanged from 0001571996-25-000063:notes:230]

[0001571996-25-000102:notes:232]
|  | Three Months Ended |  | Six Months Ended |
|  | August 1, 2025 |  | August 2, 2024 |  | August 1, 2025 |  | August 2, 2024 |  |  |
|  | (in millions) |
| Warranty liability: |  |  |  |  |  |  |  |  |  |
| Warranty liability at beginning of period | $ | 415 |  |  | $ | 426 |  |  | $ | 424 |  |  | $ | 426 |  |  |  |
| Costs accrued for new warranty contracts and changes in estimates for pre-existing warranties (a) | 249 |  |  | 216 |  |  | 460 |  |  | 445 |  |  |  |
| Service obligations honored | (225) |  |  | (203) |  |  | (445) |  |  | (432) |  |  |  |
| Warranty liability at end of period (b) | $ | 439 |  |  | $ | 439 |  |  | $ | 439 |  |  | $ | 439 |  |  |  |

[0001571996-25-000102:notes:233]
[same as prior period, unchanged from 0001571996-25-000063:notes:232]

[0001571996-25-000102:notes:234]
[same as prior period, unchanged from 0001571996-25-000063:notes:233]

[0001571996-25-000102:notes:235]
[same as prior period, unchanged from 0001571996-25-000063:notes:234]

[0001571996-25-000102:notes:236]
The Company incurs costs related to employee severance and records a liability for these costs when it is probable that employees will be entitled to termination benefits and the amounts can be reasonably estimated. The liability related to these actions is primarily included in accrued and other within current liabilities in the Condensed Consolidated Statements of Financial Position.

[0001571996-25-000102:notes:237]
[same as prior period, unchanged from 0001571996-25-000063:notes:236]

[0001571996-25-000102:notes:238]
|  | Three Months Ended |  | Six Months Ended |
|  | August 1, 2025 |  | August 2, 2024 |  | August 1, 2025 |  | August 2, 2024 |  |  |
|  | (in millions) |
| Severance liability: |  |  |  |  |  |  |  |  |  |
| Severance liability at beginning of period | $ | 151 |  |  | $ | 194 |  |  | $ | 238 |  |  | $ | 352 |  |  |  |
| Severance charges | 204 |  |  | 328 |  |  | 334 |  |  | 420 |  |  |  |
| Cash paid and other | (144) |  |  | (130) |  |  | (361) |  |  | (380) |  |  |  |
| Severance liability at end of period | $ | 211 |  |  | $ | 392 |  |  | $ | 211 |  |  | $ | 392 |  |  |  |

[0001571996-25-000102:notes:239]
[same as prior period, unchanged from 0001571996-25-000063:notes:238]

[0001571996-25-000102:notes:240]
|  | Three Months Ended |  | Six Months Ended |
|  | August 1, 2025 |  | August 2, 2024 |  | August 1, 2025 |  | August 2, 2024 |  |  |
|  | (in millions) |
| Severance charges: |  |  |  |  |  |  |  |  |  |
| Cost of net revenue | $ | 48 |  |  | $ | 56 |  |  | $ | 78 |  |  | $ | 85 |  |  |  |
| Selling, general, and administrative | 128 |  |  | 227 |  |  | 195 |  |  | 270 |  |  |  |
| Research and development | 28 |  |  | 45 |  |  | 61 |  |  | 65 |  |  |  |
| Total severance charges | $ | 204 |  |  | $ | 328 |  |  | $ | 334 |  |  | $ | 420 |  |  |  |

[0001571996-25-000102:notes:241]
[same as prior period, unchanged from 0001571996-25-000063:notes:240]

[0001571996-25-000102:notes:242]
The Company maintains a Supply Chain Finance Program (the “SCF Program”), which enables eligible suppliers, at the supplier's sole discretion, to sell receivables due from the Company to a third-party financial institution. The Company has no involvement in establishing the terms or conditions of the arrangement between its suppliers and the financial institution and no economic interest in a supplier's decision to sell a receivable, and does not provide legally secured assets or other forms of guarantees under the arrangement. The SCF Program does not impact the Company's liquidity, as payments for participating supplier invoices are remitted by the Company to the financial institution on the original invoice due date, regardless of whether an individual invoice is sold by the supplier to the financial institution. As of August 1, 2025 and January 31, 2025, the Company had $1.3 billion and $1.4 billion, respectively, included within accounts payable on the Condensed Consolidated Statements of Financial Position representing invoices due to suppliers confirmed as valid under the SCF Program.

[0001571996-25-000102:notes:243]
[same as prior period, unchanged from 0001571996-25-000063:notes:242]

[0001571996-25-000102:notes:244]
[same as prior period, unchanged from 0001571996-25-000063:notes:243]

[0001571996-25-000102:notes:245]
|  | Three Months Ended |  | Six Months Ended |
|  | August 1, 2025 |  | August 2, 2024 |  | August 1, 2025 |  | August 2, 2024 |  |  |
|  | (in millions) |
| Interest and other, net: |  |  |  |  |  |  |  |  |  |
| Investment income, primarily interest | $ | 64 |  |  | $ | 38 |  |  | $ | 95 |  |  | $ | 92 |  |  |  |
| Gain (loss) on investments, net | 4 |  |  | 5 |  |  | 21 |  |  | (25) |  |  |  |
| Interest expense | (399) |  |  | (387) |  |  | (753) |  |  | (730) |  |  |  |
| Foreign exchange | (15) |  |  | (13) |  |  | (20) |  |  | (51) |  |  |  |
| Gain on disposition of businesses and assets | — |  |  | — |  |  | 236 |  |  | — |  |  |  |
| Other | 13 |  |  | 4 |  |  | 6 |  |  | (12) |  |  |  |
| Total interest and other, net | $ | (333) |  |  | $ | (353) |  |  | $ | (415) |  |  | $ | (726) |  |  |  |


## us-gaap:ErrorCorrectionTextBlock

[0001571996-25-000102:notes:246]
REVISION OF PREVIOUSLY ISSUED FINANCIAL STATEMENTS
As discussed in Note 1 of the Notes to the Condensed Consolidated Financial Statements and as previously reported in the Company’s Annual Report on Form 10-K for the fiscal year ended January 31, 2025, the Company discovered accumulated credits from certain suppliers that were not recorded or not recorded in the correct period in its previously reported financial results. Accordingly, the Company has revised its previously reported quarterly financial information for the three and six months ended August 2, 2024 based on the summary presented below to correct for the overstatement of cost of net revenue to the Condensed Consolidated Statements of Income, net of the related income tax effect. The revision did not have an impact on the Company’s net revenue.

[0001571996-25-000102:notes:247]
A summary of the corrections to the affected financial statement line items in these Condensed Consolidated Financial Statements is presented below.

[0001571996-25-000102:notes:248]
Condensed Consolidated Statements of Income

[0001571996-25-000102:notes:249]
|  | Three Months Ended |  | Six Months Ended |
|  | August 2, 2024 |  | August 2, 2024 |
|  | As Reported |  | Adjustment |  | As Revised |  | As Reported |  | Adjustment |  | As Revised |
|  | (in millions, except per share amounts) |
| Cost of net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Products | $ | 16,079 |  |  | $ | (50) |  |  | $ | 16,029 |  |  | $ | 29,845 |  |  | $ | (95) |  |  | $ | 29,750 |  |
| Total cost of net revenue | $ | 19,715 |  |  | $ | (50) |  |  | $ | 19,665 |  |  | $ | 37,153 |  |  | $ | (95) |  |  | $ | 37,058 |  |
| Gross margin | $ | 5,311 |  |  | $ | 50 |  |  | $ | 5,361 |  |  | $ | 10,117 |  |  | $ | 95 |  |  | $ | 10,212 |  |
| Operating income | $ | 1,342 |  |  | $ | 50 |  |  | $ | 1,392 |  |  | $ | 2,262 |  |  | $ | 95 |  |  | $ | 2,357 |  |
| Income before income taxes | $ | 989 |  |  | $ | 50 |  |  | $ | 1,039 |  |  | $ | 1,536 |  |  | $ | 95 |  |  | $ | 1,631 |  |
| Income tax expense (benefit) | $ | 148 |  |  | $ | 9 |  |  | $ | 157 |  |  | $ | (260) |  |  | $ | 17 |  |  | $ | (243) |  |
| Net income | $ | 841 |  |  | $ | 41 |  |  | $ | 882 |  |  | $ | 1,796 |  |  | $ | 78 |  |  | $ | 1,874 |  |
| Net income attributable to Dell Technologies Inc. | $ | 846 |  |  | $ | 41 |  |  | $ | 887 |  |  | $ | 1,806 |  |  | $ | 78 |  |  | $ | 1,884 |  |
| Earnings per share attributable to Dell Technologies Inc. |  |  |  |  |  |  |
| Basic | $ | 1.19 |  |  | $ | 0.06 |  |  | $ | 1.25 |  |  | $ | 2.55 |  |  | $ | 0.11 |  |  | $ | 2.66 |  |
| Diluted | $ | 1.17 |  |  | $ | 0.06 |  |  | $ | 1.23 |  |  | $ | 2.49 |  |  | $ | 0.11 |  |  | $ | 2.60 |  |

[0001571996-25-000102:notes:250]
(a)The Company’s Condensed Consolidated Statements of Comprehensive Income were also affected by the revised net income amounts for the period presented above.

[0001571996-25-000102:notes:251]
Condensed Consolidated Statements of Cash Flows

[0001571996-25-000102:notes:252]
|  |  |  | Six Months Ended |  |  |
|  |  |  | August 2, 2024 |  |  |
|  |  |  |  |  |  |  | As Reported |  | Adjustment |  | As Revised |  |  |  |  |  |  |
|  |  |  |  |  |  |  | (in millions) |
| Cash flow from operations: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  |  |  |  |  |  | $ | 1,796 |  |  | $ | 78 |  |  | $ | 1,874 |  |  |  |  |  |  |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |
| Other assets and liabilities |  |  |  |  |  |  | $ | 250 |  |  | $ | (3) |  |  | $ | 247 |  |  |  |  |  |  |  |
| Accounts payable |  |  |  |  |  |  | $ | 4,801 |  |  | $ | (75) |  |  | $ | 4,726 |  |  |  |  |  |  |  |


## us-gaap:SubsequentEventsTextBlock

[0001571996-25-000102:notes:253]
SUBSEQUENT EVENTS 
There were no known events occurring after August 1, 2025 and up until the date of issuance of this report that would materially affect the information presented herein.
