# DELL 8-K — 0001571996-25-000096 filed 2025-08-28

## item codes, every 8-K on or before 2025-09-08

- 2025-09-08 0001571996-25-000104 — 5.02
- 2025-08-28 0001571996-25-000096 — 2.02, 9.01
- 2025-08-12 0001571996-25-000093 — 5.02
- 2025-07-16 0001571996-25-000081 — 3.02
- 2025-07-01 0001571996-25-000078 — 5.07
- 2025-05-29 0001571996-25-000046 — 2.02, 9.01
- 2025-04-01 0001193125-25-070461 — 1.01, 2.03, 9.01
- 2025-03-27 0001193125-25-065594 — 8.01, 9.01
- 2025-02-27 0001571996-25-000014 — 2.02, 8.01, 9.01
- 2025-01-14 0001571996-25-000004 — 3.02
- 2024-12-03 0001571996-24-000136 — 3.02
- 2024-11-26 0001571996-24-000130 — 2.02, 9.01
- 2024-10-08 0001193125-24-234446 — 1.01, 2.03, 9.01
- 2024-10-02 0001193125-24-231195 — 8.01, 9.01
- 2024-09-19 0001571996-24-000105 — 3.02
- 2024-08-29 0001571996-24-000081 — 2.02, 9.01
- 2024-07-12 0001193125-24-178608 — 3.02
- 2024-07-02 0001571996-24-000074 — 5.07
- 2024-06-10 0001571996-24-000059 — 3.02
- 2024-05-30 0001571996-24-000050 — 2.02, 9.01
- 2024-03-26 0001571996-24-000038 — 3.02
- 2024-03-18 0001193125-24-070193 — 1.01, 2.03, 9.01
- 2024-03-07 0001571996-24-000012 — 3.02
- 2024-03-06 0001193125-24-059631 — 8.01, 9.01
- 2024-02-29 0001571996-24-000008 — 2.02, 9.01
- 2024-01-30 0001571996-24-000004 — 1.02
- 2024-01-18 0001571996-24-000002 — 3.02
- 2023-12-18 0001193125-23-297664 — 8.01, 9.01
- 2023-12-05 0001571996-23-000042 — 3.02
- 2023-12-04 0001193125-23-288428 — 8.01, 9.01
- 2023-11-30 0001571996-23-000039 — 2.02, 9.01
- 2023-10-05 0001193125-23-251131 — 7.01, 8.01, 9.01
- 2023-10-02 0001571996-23-000036 — 5.02 — amendment of 0001571996-23-000034
- 2023-09-26 0001571996-23-000034 — 5.02
- 2023-08-31 0001571996-23-000029 — 2.02, 9.01
- 2023-08-09 0001571996-23-000026 — 5.02 — amendment of 0001571996-23-000002
- 2023-07-28 0001571996-23-000024 — 5.02
- 2023-07-13 0001193125-23-186639 — 3.02
- 2023-06-30 0001193125-23-180570 — 8.01, 9.01
- 2023-06-22 0001571996-23-000021 — 5.02, 5.07, 9.01
- 2023-06-15 0001193125-23-167472 — 8.01, 9.01
- 2023-06-01 0001571996-23-000014 — 2.02, 9.01
- 2023-03-02 0001571996-23-000002 — 2.02, 5.02, 9.01
- 2023-02-06 0001193125-23-024781 — 7.01, 9.01
- 2023-01-24 0001193125-23-014260 — 1.01, 2.03, 9.01
- 2023-01-11 0001193125-23-006528 — 8.01, 9.01
- 2022-11-21 0001571996-22-000041 — 2.02, 9.01
- 2022-11-16 0001571996-22-000038 — 8.01
- 2022-08-25 0001571996-22-000028 — 2.02, 9.01
- 2022-07-18 0001193125-22-196334 — 2.03, 8.01
- 2022-06-29 0001571996-22-000025 — 3.03, 5.03, 5.07, 8.01, 9.01
- 2022-05-26 0001571996-22-000013 — 2.02, 9.01
- 2022-02-24 0001571996-22-000004 — 2.02, 8.01, 9.01
- 2021-12-20 0001193125-21-362482 — 8.01, 9.01
- 2021-12-15 0001193125-21-357927 — 1.01, 2.03, 9.01
- 2021-12-07 0001193125-21-349218 — 8.01, 9.01
- 2021-11-23 0001571996-21-000060 — 2.02, 9.01
- 2021-11-05 0001571996-21-000057 — 1.02, 2.01, 7.01, 8.01, 9.01 — amendment, the index does not say of what
- 2021-11-01 0001571996-21-000052 — 8.01, 9.01
- 2021-11-01 0001193125-21-315488 — 1.01, 1.02, 2.01, 8.01, 9.01
- 2021-10-21 0001193125-21-304052 — 8.01, 9.01
- 2021-10-19 0001571996-21-000050 — 8.01, 9.01
- 2021-10-07 0001193125-21-294210 — 8.01, 9.01
- 2021-09-30 0001571996-21-000047 — 5.02
- 2021-09-27 0001571996-21-000045 — 8.01
- 2021-09-23 0001193125-21-280190 — 7.01, 8.01, 9.01
- 2021-09-20 0001193125-21-276810 — 7.01, 9.01
- 2021-08-26 0001571996-21-000037 — 2.02, 9.01
- 2021-07-01 0001571996-21-000034 — 3.02
- 2021-06-24 0001571996-21-000031 — 5.07
- 2021-06-24 0001193125-21-197644 — 7.01, 9.01
- 2021-06-16 0001571996-21-000029 — 5.02
- 2021-05-27 0001571996-21-000019 — 2.02, 9.01
- 2021-05-03 0001571996-21-000010 — 8.01, 9.01
- 2021-04-14 0001193125-21-116271 — 1.01, 7.01, 9.01
- 2021-02-25 0001571996-21-000003 — 2.02, 9.01
- 2021-02-18 0001193125-21-047844 — 1.01, 2.03, 9.01
- 2020-11-24 0001571996-20-000048 — 2.02, 9.01
- 2020-08-27 0001571996-20-000041 — 2.02, 9.01
- 2020-07-02 0001571996-20-000037 — 5.07
- 2020-05-28 0001571996-20-000028 — 2.02, 9.01
- 2020-04-09 0001193125-20-102602 — 1.01, 2.03, 9.01
- 2020-04-08 0001571996-20-000021 — 5.02
- 2020-04-03 0001571996-20-000019 — 8.01, 9.01
- 2020-03-26 0001571996-20-000015 — 7.01
- 2020-02-27 0001571996-20-000009 — 2.02, 8.01, 9.01
- 2020-02-18 0001571996-20-000005 — 8.01, 9.01
- 2020-01-09 0001571996-20-000002 — 3.02
- 2020-01-06 0001193125-20-002200 — 3.02
- 2019-12-13 0001193125-19-313947 — 3.02
- 2019-12-10 0001571996-19-000052 — 5.02
- 2019-12-02 0001571996-19-000044 — 5.02, 7.01, 9.01
- 2019-11-26 0001571996-19-000042 — 2.02, 9.01
- 2019-09-23 0001193125-19-252192 — 1.01, 2.03, 9.01
- 2019-08-29 0001571996-19-000036 — 2.02, 9.01
- 2019-08-22 0001193125-19-226939 — 7.01, 8.01, 9.01
- 2019-07-11 0001571996-19-000032 — 5.02, 5.07, 9.01
- 2019-07-03 0001571996-19-000030 — 3.02
- 2019-06-27 0001571996-19-000028 — 3.02
- 2019-05-30 0001571996-19-000021 — 2.02, 9.01
- 2019-04-02 0001571996-19-000010 — 5.02
- 2019-03-21 0001193125-19-082281 — 1.01, 1.02, 2.03, 9.01
- 2019-03-19 0001571996-19-000005 — 5.02, 9.01
- 2019-03-14 0001193125-19-074935 — 1.01, 2.03, 9.01
- 2019-03-07 0001193125-19-066045 — 8.01, 9.01
- 2019-02-28 0001571996-19-000002 — 2.02, 9.01
- 2018-12-28 0001193125-18-360943 — 1.01, 1.02, 3.01, 3.03, 5.02, 5.03, 7.01, 8.01, 9.01
- 2018-12-21 0001193125-18-356324 — 1.01, 2.03, 9.01
- 2018-12-14 0001193125-18-349469 — 8.01
- 2018-12-11 0001193125-18-346958 — 5.07, 8.01, 9.01
- 2018-11-29 0001571996-18-000041 — 2.02, 9.01
- 2018-11-28 0001571996-18-000037 — 7.01, 8.01, 9.01
- 2018-11-26 0001193125-18-333967 — 8.01, 9.01
- 2018-11-15 0001193125-18-328110 — 1.01, 9.01 — amendment of 0001193125-18-327222
- 2018-11-15 0001193125-18-327222 — 1.01, 7.01, 9.01
- 2018-10-03 0001193125-18-291390 — 8.01
- 2018-09-06 0001571996-18-000029 — 2.02, 9.01
- 2018-08-06 0001571996-18-000027 — 8.01, 9.01
- 2018-07-02 0001193125-18-210339 — 1.01, 7.01, 9.01
- 2018-06-28 0001571996-18-000024 — 5.07
- 2018-06-04 0001571996-18-000019 — 2.02, 9.01
- 2018-05-17 0001571996-18-000016 — 7.01
- 2018-04-26 0001571996-18-000009 — 7.01, 9.01
- 2018-03-08 0001193125-18-074168 — 2.02, 9.01
- 2018-02-02 0001193125-18-029947 — 7.01, 9.01
- 2017-12-07 0001571996-17-000042 — 2.02, 9.01
- 2017-10-24 0001571996-17-000037 — 1.01, 2.03, 9.01
- 2017-09-15 0001571996-17-000027 — 5.02
- 2017-09-07 0001571996-17-000017 — 2.02, 9.01
- 2017-08-24 0001571996-17-000014 — 8.01
- 2017-06-29 0001571996-17-000011 — 3.03, 5.07, 8.01, 9.01
- 2017-06-08 0001193125-17-197638 — 2.02, 9.01
- 2017-03-30 0001193125-17-102794 — 8.01
- 2017-03-30 0001193125-17-102777 — 2.02, 9.01
- 2017-03-09 0001193125-17-076981 — 1.01, 2.03, 9.01
- 2017-01-17 0001193125-17-011125 — 8.01
- 2016-12-15 0001193125-16-793722 — 8.01
- 2016-12-08 0001193125-16-787976 — 2.02, 9.01
- 2016-11-10 0001193125-16-765964 — 1.02, 8.01
- 2016-11-04 0001193125-16-760249 — 8.01
- 2016-09-13 0001193125-16-708600 — 3.02
- 2016-09-09 0001193125-16-706567 — 1.01, 1.02, 2.01, 2.03, 3.02, 3.03, 5.02, 9.01
- 2016-09-07 0001193125-16-703370 — 3.03, 5.07, 7.01, 8.01, 9.01
- 2016-09-06 0001193125-16-702057 — 2.02, 9.01
- 2016-08-31 0001193125-16-697268 — 8.01, 9.01
- 2016-08-26 0001193125-16-692921 — 8.01, 9.01
- 2016-07-11 0001193125-16-645610 — 8.01
- 2016-07-05 0001193125-16-641679 — 8.01
- 2016-06-22 0001193125-16-629055 — 1.01, 2.03, 8.01, 9.01
- 2016-06-21 0001193125-16-627071 — 8.01, 9.01
- 2016-06-10 0001193125-16-618483 — 2.02, 9.01
- 2016-06-09 0001193125-16-617893 — 8.01, 9.01

## late-filing notifications on or before 2025-09-08

- none on or before 2025-09-08

## item 2.02 — earnings release, exhibit 99.1

[0001571996-25-000096:8k_2_02:1]
EX-99.1
2
exhibit991earnings8kq2fy26.htm
EX-99.1

[0001571996-25-000096:8k_2_02:2]
Document

[0001571996-25-000096:8k_2_02:3]
Exhibit 99.1

[0001571996-25-000096:8k_2_02:4]
Dell Technologies Delivers Second Quarter Fiscal 2026 Financial Results

[0001571996-25-000096:8k_2_02:5]
ROUND ROCK, Texas — August 28, 2025 — Dell Technologies (NYSE: DELL) announces financial results for its fiscal 2026 second quarter. The company also provides guidance for its fiscal 2026 third quarter and full year.

[0001571996-25-000096:8k_2_02:6]
Second-Quarter Summary

[0001571996-25-000096:8k_2_02:7]
•Record revenue of $29.8 billion, up 19% year over year

[0001571996-25-000096:8k_2_02:8]
•Operating income of $1.8 billion, up 27% year over year, and non-GAAP operating income of $2.3 billion, up 10%

[0001571996-25-000096:8k_2_02:9]
•Diluted earnings per share (EPS) of $1.70, up 38% year over year, and record second-quarter non-GAAP diluted EPS of $2.32, up 19%

[0001571996-25-000096:8k_2_02:10]
•Cash flow from operations of $2.5 billion

[0001571996-25-000096:8k_2_02:11]
“In Q2, we achieved strong top-line results and profitability, reaching record revenue of $29.8 billion,” said Yvonne McGill, chief financial officer, Dell Technologies. “We delivered another quarter of robust cash generation, with $2.5 billion in cash flow from operations and $1.3 billion in shareholder returns.”

[0001571996-25-000096:8k_2_02:12]
“We’ve now shipped $10 billion of AI solutions in the first half of FY26, surpassing all shipments in FY25. This helped deliver another record revenue quarter in our Servers and Networking business, which grew 69%,” said Jeff Clarke, vice chairman and chief operating officer, Dell Technologies. “Demand for our AI solutions continues to be exceptional, and we’re raising our AI server shipment guidance for FY26 to $20 billion dollars.”

[0001571996-25-000096:8k_2_02:13]
Infrastructure Solutions Group (ISG)

[0001571996-25-000096:8k_2_02:14]
•Record revenue: $16.8 billion, up 44% year over year

[0001571996-25-000096:8k_2_02:15]
•Record Servers and Networking revenue: $12.9 billion, up 69%

[0001571996-25-000096:8k_2_02:16]
•Storage revenue: $3.9 billion, down 3%

[0001571996-25-000096:8k_2_02:17]
•Second-quarter record operating income: $1.5 billion, up 14% year over year

[0001571996-25-000096:8k_2_02:18]
Client Solutions Group (CSG)

[0001571996-25-000096:8k_2_02:19]
•Revenue: $12.5 billion, up 1% year over year

[0001571996-25-000096:8k_2_02:20]
•Commercial Client revenue: $10.8 billion, up 2%

[0001571996-25-000096:8k_2_02:21]
•Consumer revenue: $1.7 billion, down 7%

[0001571996-25-000096:8k_2_02:22]
•Operating income: $803 million, down 2% year over year

[0001571996-25-000096:8k_2_02:23]
Capital Return

[0001571996-25-000096:8k_2_02:24]
Dell Technologies returned $1.3 billion to shareholders in the second quarter through share repurchases and dividends.

[0001571996-25-000096:8k_2_02:25]
1

[0001571996-25-000096:8k_2_02:26]
Guidance Summary

[0001571996-25-000096:8k_2_02:27]
•Full-year FY26 revenue expected between $105.0 billion and $109.0 billion, up 12% year over year at the midpoint of $107.0 billion

[0001571996-25-000096:8k_2_02:28]
•Full-year FY26 GAAP diluted EPS expected to be $7.98 at the midpoint, up 25% year over year, and non-GAAP diluted EPS to be $9.55 at the midpoint, up 17%

[0001571996-25-000096:8k_2_02:29]
•Third-quarter FY26 revenue expected between $26.5 billion and $27.5 billion, up 11% year over year at the midpoint of $27.0 billion

[0001571996-25-000096:8k_2_02:30]
•Third-quarter FY26 GAAP diluted EPS expected to be $2.07 at the midpoint, up 26% year over year, and non-GAAP diluted EPS to be $2.45 at the midpoint, up 11%

[0001571996-25-000096:8k_2_02:31]
2

[0001571996-25-000096:8k_2_02:32]
Second Quarter Fiscal 2026 Financial Results

[0001571996-25-000096:8k_2_02:33]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | August 1, 2025 |  | August 2, 2024 |  | Change |  | August 1, 2025 |  | August 2, 2024 |  | Change |
|  | (in millions, except per share amounts and percentages; unaudited) |
| Net revenue | $ | 29,776 |  |  | $ | 25,026 |  |  | 19% |  | $ | 53,154 |  |  | $ | 47,270 |  |  | 12% |
| Operating income | $ | 1,773 |  |  | $ | 1,392 |  |  | 27% |  | $ | 2,938 |  |  | $ | 2,357 |  |  | 25% |
| Net income | $ | 1,164 |  |  | $ | 882 |  |  | 32% |  | $ | 2,129 |  |  | $ | 1,874 |  |  | 14% |
| Change in cash from operating activities | $ | 2,543 |  |  | $ | 1,340 |  |  | 90% |  | $ | 5,339 |  |  | $ | 2,383 |  |  | 124% |
| Earnings per share — diluted | $ | 1.70 |  |  | $ | 1.23 |  |  | 38% |  | $ | 3.07 |  |  | $ | 2.60 |  |  | 18% |
| Non-GAAP operating income | $ | 2,284 |  |  | $ | 2,084 |  |  | 10% |  | $ | 3,950 |  |  | $ | 3,603 |  |  | 10% |
| Non-GAAP net income | $ | 1,591 |  |  | $ | 1,412 |  |  | 13% |  | $ | 2,677 |  |  | $ | 2,371 |  |  | 13% |
| Adjusted free cash flow | $ | 2,518 |  |  | $ | 1,284 |  |  | 96% |  | $ | 4,750 |  |  | $ | 1,907 |  |  | 149% |
| Non-GAAP earnings per share — diluted | $ | 2.32 |  |  | $ | 1.95 |  |  | 19% |  | $ | 3.86 |  |  | $ | 3.27 |  |  | 18% |

[0001571996-25-000096:8k_2_02:34]
Information about Dell Technologies’ non-GAAP financial measures is provided under “Non-GAAP Financial Measures” below. All comparisons in this press release are year over year unless otherwise noted.

[0001571996-25-000096:8k_2_02:35]
Operating Segments Results

[0001571996-25-000096:8k_2_02:36]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | August 1, 2025 |  | August 2, 2024 |  | Change |  | August 1, 2025 |  | August 2, 2024 |  | Change |
|  | (in millions, except percentages; unaudited) |
| Infrastructure Solutions Group (ISG): |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Servers and networking | $ | 12,944 |  | $ | 7,672 |  |  | 69% |  | $ | 19,265 |  |  | $ | 13,138 |  |  | 47% |
| Storage | 3,856 |  |  | 3,974 |  |  | (3)% |  | 7,852 |  |  | 7,735 |  |  | 2% |
| Total ISG net revenue | $ | 16,800 |  |  | $ | 11,646 |  |  | 44% |  | $ | 27,117 |  |  | $ | 20,873 |  |  | 30% |
| Operating income: |  |  |  |  |  |  |  |  |  |  |  |
| ISG operating income | $ | 1,470 |  |  | $ | 1,284 |  |  | 14% |  | $ | 2,468 |  |  | $ | 2,020 |  |  | 22% |
| % of ISG net revenue | 8.8 | % |  | 11.0 | % |  |  |  | 9.1 | % |  | 9.7 | % |  |  |
| % of total reportable segment operating income | 65 | % |  | 61 | % |  |  |  | 63 | % |  | 56 | % |  |  |
| Client Solutions Group (CSG): |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 10,781 |  |  | $ | 10,556 |  |  | 2% |  | $ | 21,827 |  |  | $ | 20,710 |  |  | 5% |
| Consumer | 1,722 |  |  | 1,858 |  |  | (7)% |  | 3,185 |  |  | 3,671 |  |  | (13)% |
| Total CSG net revenue | $ | 12,503 |  |  | $ | 12,414 |  |  | 1% |  | $ | 25,012 |  |  | $ | 24,381 |  |  | 3% |
| Operating income: |  |  |  |  |  |  |  |  |  |  |  |
| CSG operating income | $ | 803 |  |  | $ | 817 |  |  | (2)% |  | $ | 1,456 |  |  | $ | 1,594 |  |  | (9)% |
| % of CSG net revenue | 6.4 | % |  | 6.6 | % |  |  |  | 5.8 | % |  | 6.5 | % |  |  |
| % of total reportable segment operating income | 35 | % |  | 39 | % |  |  |  | 37 | % |  | 44 | % |  |  |

[0001571996-25-000096:8k_2_02:37]
Conference call information

[0001571996-25-000096:8k_2_02:38]
As previously announced, the company will hold a conference call to discuss its performance and financial guidance on August 28 at 3:30 p.m. CST. Prior to the start of the conference call, prepared remarks and a presentation containing additional financial and operating information may be downloaded from investors.delltechnologies.com. The conference call will be broadcast live over the internet and can be accessed at https://investors.delltechnologies.com/news-events/upcoming-events.

[0001571996-25-000096:8k_2_02:39]
For those unable to listen to the live broadcast, the final remarks and presentation with additional financial and operating information will be available following the broadcast, and an archived version will be available at the same location for one year.

[0001571996-25-000096:8k_2_02:40]
About Dell Technologies

[0001571996-25-000096:8k_2_02:41]
Dell Technologies (NYSE:DELL) helps organizations and individuals build their digital future and transform how they work, live and play. The company provides customers with the industry’s broadest and most innovative technology and services portfolio for the AI era.

[0001571996-25-000096:8k_2_02:42]
Contacts

[0001571996-25-000096:8k_2_02:43]
Investors: Investor_Relations@Dell.com

[0001571996-25-000096:8k_2_02:44]
Media: Media.Relations@Dell.com

[0001571996-25-000096:8k_2_02:45]
# # #

[0001571996-25-000096:8k_2_02:46]
Copyright © 2025 Dell Inc. or its subsidiaries. All Rights Reserved. Dell Technologies, Dell, EMC and Dell EMC are trademarks of Dell Inc. or its subsidiaries. Other trademarks may be trademarks of their respective owners.

[0001571996-25-000096:8k_2_02:47]
Non-GAAP Financial Measures:

[0001571996-25-000096:8k_2_02:48]
This press release presents information about non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, non-GAAP earnings per share attributable to Dell Technologies Inc. – diluted, free cash flow, and adjusted free cash flow, all of which are non-GAAP financial measures provided as a supplement to the results provided in accordance with generally accepted accounting principles in the United States of America (“GAAP”). A reconciliation of each non-GAAP financial measure to the most directly comparable GAAP financial measure is provided in the attached tables for each of the fiscal periods indicated.

[0001571996-25-000096:8k_2_02:49]
Special Note on Forward-Looking Statements:

[0001571996-25-000096:8k_2_02:50]
Forward-looking statements include, among others, any statements regarding Dell Technologies’ expectations for third-quarter and full-year fiscal 2026 revenue, GAAP diluted earnings per share and non-GAAP diluted earnings per share, and any other statements regarding Dell Technologies’ prospects and its future operations, financial condition, volumes, cash flows, expenses or other financial items, including management’s plans or strategies and objectives for any of the foregoing and any assumptions, expectations or beliefs underlying any of the foregoing.

[0001571996-25-000096:8k_2_02:51]
Dell Technologies’ results or events in future periods could differ materially from those expressed or implied by these forward-looking statements because of risks, uncertainties, and other factors that include, but are not limited to, the following: adverse global economic conditions, trade disruptions, and instability in financial markets; competitive pressures; Dell Technologies’ ability to successfully execute its strategy; Dell Technologies’ relationships with third-party suppliers for products and components; Dell Technologies’ use of single-source or limited-source suppliers; effects on Dell Technologies’ operating performance related to demand for AI solutions; management of Dell Technologies’ AI solutions and use of AI in internal functions and operations; Dell Technologies’ ability to deliver high-quality products, software, and services and to manage solutions and products and services transitions in an effective manner; Dell Technologies’ ability to successfully implement its cost efficiency plans; Dell Technologies’ ability to successfully execute on strategic initiatives including acquisitions and divestitures; security incidents, including cyber-attacks; Dell Technologies’ foreign operations and ability to generate

[0001571996-25-000096:8k_2_02:52]
substantial non-U.S. net revenue; Dell Technologies’ product, services, customer, and geographic sales mix, and seasonal sales trends; the performance of Dell Technologies’ sales channel partners; access to the capital markets by Dell Technologies or its customers; adverse economic conditions, changing customer mix, and the effect of additional regulation on Dell Technologies’ financial services activities; counterparty default risks; material impairment of the value of goodwill or intangible assets; the loss by Dell Technologies of any contracts for ISG services and solutions and its ability to perform such contracts at their estimated costs; loss by Dell Technologies of government contracts; Dell Technologies’ ability to develop and protect its proprietary intellectual property or obtain licenses to intellectual property developed by others on commercially reasonable and competitive terms; disruptions in Dell Technologies’ infrastructure; Dell Technologies’ ability to hedge effectively its exposure to fluctuations in foreign currency exchange rates and interest rates; expiration of tax holidays or favorable tax rate structures, or unfavorable outcomes in tax audits and other tax compliance matters; impairment of portfolio investments; unfavorable results of legal proceedings; evolving and varied expectations and regulatory requirements relating to sustainability issues; the effect of global climate change and related legal, regulatory or market measures; compliance with environmental and safety laws; compliance requirements of anti-corruption laws, economic sanctions and other trade laws, human rights laws, or other laws; Dell Technologies’ dependence on the services of Michael Dell and key employees; Dell Technologies’ level of indebtedness; and business and financial factors and legal restrictions affecting continuation of Dell Technologies’ quarterly cash dividend policy and dividend rate.

[0001571996-25-000096:8k_2_02:53]
This list of risks, uncertainties, and other factors is not complete. Dell Technologies discusses some of these matters more fully, as well as certain risk factors that could affect Dell Technologies’ business, financial condition, results of operations, and prospects, in its reports filed with the SEC, including Dell Technologies’ annual report on Form 10-K for the fiscal year ended January 31, 2025, quarterly reports on Form 10-Q, and current reports on Form 8-K. These filings are available for review through the SEC’s website at www.sec.gov. Any or all forward-looking statements Dell Technologies makes may turn out to be wrong and can be affected by inaccurate assumptions Dell Technologies might make or by known or unknown risks, uncertainties, and other factors, including those identified in this press release. Accordingly, you should not place undue reliance on the forward-looking statements made in this press release, which speak only as of its date. Dell Technologies does not undertake to update, and expressly disclaims any duty to update, its forward-looking statements, whether as a result of circumstances or events that arise after the date they are made, new information, or otherwise.

[0001571996-25-000096:8k_2_02:54]
5

[0001571996-25-000096:8k_2_02:55]
DELL TECHNOLOGIES INC.

[0001571996-25-000096:8k_2_02:56]
Condensed Consolidated Statements of Income and Related Financial Highlights

[0001571996-25-000096:8k_2_02:57]
(in millions, except percentages; unaudited)

[0001571996-25-000096:8k_2_02:58]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | August 1, 2025 |  | August 2, 2024 |  | Change |  | August 1, 2025 |  | August 2, 2024 |  | Change |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Products | $ | 23,935 |  |  | $ | 18,954 |  |  | 26% |  | $ | 41,534 |  |  | $ | 35,081 |  |  | 18% |
| Services | 5,841 |  |  | 6,072 |  |  | (4)% |  | 11,620 |  |  | 12,189 |  |  | (5)% |
| Total net revenue | 29,776 |  |  | 25,026 |  |  | 19% |  | 53,154 |  |  | 47,270 |  |  | 12% |
| Cost of net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Products | 21,044 |  |  | 16,029 |  |  | 31% |  | 36,160 |  |  | 29,750 |  |  | 22% |
| Services | 3,285 |  |  | 3,636 |  |  | (10)% |  | 6,610 |  |  | 7,308 |  |  | (10)% |
| Total cost of net revenue | 24,329 |  |  | 19,665 |  |  | 24% |  | 42,770 |  |  | 37,058 |  |  | 15% |
| Gross margin | 5,447 |  |  | 5,361 |  |  | 2% |  | 10,384 |  |  | 10,212 |  |  | 2% |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative | 2,889 |  |  | 3,189 |  |  | (9)% |  | 5,853 |  |  | 6,312 |  |  | (7)% |
| Research and development | 785 |  |  | 780 |  |  | 1% |  | 1,593 |  |  | 1,543 |  |  | 3% |
| Total operating expenses | 3,674 |  |  | 3,969 |  |  | (7)% |  | 7,446 |  |  | 7,855 |  |  | (5)% |
| Operating income | 1,773 |  |  | 1,392 |  |  | 27% |  | 2,938 |  |  | 2,357 |  |  | 25% |
| Interest and other, net | (333) |  |  | (353) |  |  | 6% |  | (415) |  |  | (726) |  |  | 43% |
| Income before income taxes | 1,440 |  |  | 1,039 |  |  | 39% |  | 2,523 |  |  | 1,631 |  |  | 55% |
| Income tax expense (benefit) | 276 |  |  | 157 |  |  | 76% |  | 394 |  |  | (243) |  |  | 262% |
| Net income | 1,164 |  |  | 882 |  |  | 32% |  | 2,129 |  |  | 1,874 |  |  | 14% |
| Less: Net loss attributable to non-controlling interests | — |  |  | (5) |  |  | 100% |  | — |  |  | (10) |  |  | 100% |
| Net income attributable to Dell Technologies Inc. | $ | 1,164 |  |  | $ | 887 |  |  | 31% |  | $ | 2,129 |  |  | $ | 1,884 |  |  | 13% |
| Percentage of Total Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Gross margin | 18.3 | % |  | 21.4 | % |  |  |  | 19.5 | % |  | 21.6 | % |  |  |
| Selling, general, and administrative | 9.7 | % |  | 12.7 | % |  |  |  | 11.0 | % |  | 13.3 | % |  |  |
| Research and development | 2.6 | % |  | 3.1 | % |  |  |  | 3.0 | % |  | 3.3 | % |  |  |
| Operating expenses | 12.3 | % |  | 15.8 | % |  |  |  | 14.0 | % |  | 16.6 | % |  |  |
| Operating income | 6.0 | % |  | 5.6 | % |  |  |  | 5.5 | % |  | 5.0 | % |  |  |
| Income before income taxes | 4.8 | % |  | 4.2 | % |  |  |  | 4.7 | % |  | 3.5 | % |  |  |
| Net income | 3.9 | % |  | 3.5 | % |  |  |  | 4.0 | % |  | 4.0 | % |  |  |
| Income tax rate | 19.2 | % |  | 15.1 | % |  |  |  | 15.6 | % |  | (14.9) | % |  |  |

[0001571996-25-000096:8k_2_02:59]
Amounts are based on underlying data and may not visually foot due to rounding.

[0001571996-25-000096:8k_2_02:60]
DELL TECHNOLOGIES INC.

[0001571996-25-000096:8k_2_02:61]
Condensed Consolidated Statements of Financial Position

[0001571996-25-000096:8k_2_02:62]
(in millions; unaudited)

[0001571996-25-000096:8k_2_02:63]
|  | August 1, 2025 |  | January 31, 2025 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 8,145 |  |  | $ | 3,633 |  |
| Accounts receivable, net of allowance of $83 and $63 | 15,023 |  |  | 10,298 |  |
| Short-term financing receivables, net of allowance of $80 and $78 | 5,952 |  |  | 5,304 |  |
| Inventories | 7,211 |  |  | 6,716 |  |
| Other current assets | 9,181 |  |  | 9,610 |  |
| Current assets held for sale | — |  |  | 668 |  |
| Total current assets | 45,512 |  |  | 36,229 |  |
| Property, plant, and equipment, net | 6,458 |  |  | 6,336 |  |
| Long-term investments | 1,596 |  |  | 1,496 |  |
| Long-term financing receivables, net of allowance of $71 and $75 | 6,071 |  |  | 5,927 |  |
| Goodwill | 19,336 |  |  | 19,120 |  |
| Intangible assets, net | 4,748 |  |  | 4,988 |  |
| Other non-current assets | 5,455 |  |  | 5,650 |  |
| Total assets | $ | 89,176 |  |  | $ | 79,746 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Short-term debt | $ | 7,154 |  |  | $ | 5,204 |  |
| Accounts payable | 27,463 |  |  | 20,832 |  |
| Accrued and other | 6,486 |  |  | 6,597 |  |
| Short-term deferred revenue | 13,759 |  |  | 13,673 |  |
| Current liabilities held for sale | — |  |  | 221 |  |
| Total current liabilities | 54,862 |  |  | 46,527 |  |
| Long-term debt | 21,535 |  |  | 19,363 |  |
| Long-term deferred revenue | 12,422 |  |  | 12,292 |  |
| Other non-current liabilities | 3,123 |  |  | 2,951 |  |
| Total liabilities | 91,942 |  |  | 81,133 |  |
| Stockholders’ equity (deficit): |  |  |  |
| Common stock and capital in excess of $0.01 par value | 9,132 |  |  | 9,119 |  |
| Treasury stock at cost | (11,419) |  |  | (8,502) |  |
| Retained earnings (accumulated deficit) | 231 |  |  | (1,160) |  |
| Accumulated other comprehensive loss | (710) |  |  | (939) |  |
| Total Dell Technologies Inc. stockholders’ equity (deficit) | (2,766) |  |  | (1,482) |  |
| Non-controlling interests | — |  |  | 95 |  |
| Total stockholders’ equity (deficit) | (2,766) |  |  | (1,387) |  |
| Total liabilities and stockholders’ equity | $ | 89,176 |  |  | $ | 79,746 |  |

[0001571996-25-000096:8k_2_02:64]
7

[0001571996-25-000096:8k_2_02:65]
DELL TECHNOLOGIES INC.

[0001571996-25-000096:8k_2_02:66]
Condensed Consolidated Statements of Cash Flows

[0001571996-25-000096:8k_2_02:67]
(in millions; unaudited)

[0001571996-25-000096:8k_2_02:68]
|  | Three Months Ended |  | Six Months Ended |
|  | August 1, 2025 |  | August 2, 2024 |  | August 1, 2025 |  | August 2, 2024 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |
| Net income | $ | 1,164 |  |  | $ | 882 |  |  | $ | 2,129 |  |  | $ | 1,874 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: | 1,379 |  |  | 458 |  |  | 3,210 |  |  | 509 |  |
| Change in cash from operating activities | 2,543 |  |  | 1,340 |  |  | 5,339 |  |  | 2,383 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |
| Purchases of investments | (28) |  |  | (25) |  |  | (125) |  |  | (64) |  |
| Maturities and sales of investments | 28 |  |  | 97 |  |  | 59 |  |  | 216 |  |
| Capital expenditures and capitalized software development costs | (675) |  |  | (682) |  |  | (1,243) |  |  | (1,278) |  |
| Divestitures of businesses and assets, net | — |  |  | — |  |  | 533 |  |  | — |  |
| Other | 20 |  |  | 53 |  |  | 33 |  |  | 113 |  |
| Change in cash from investing activities | (655) |  |  | (557) |  |  | (743) |  |  | (1,013) |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |
| Proceeds from the issuance of common stock | 1 |  |  | 1 |  |  | 1 |  |  | 1 |  |
| Repurchases of common stock | (940) |  |  | (725) |  |  | (2,920) |  |  | (1,425) |  |
| Repurchases of common stock for employee tax withholdings | (5) |  |  | (14) |  |  | (357) |  |  | (535) |  |
| Payments of dividends and dividend equivalents | (366) |  |  | (316) |  |  | (762) |  |  | (652) |  |
| Proceeds from debt | 962 |  |  | 1,941 |  |  | 7,270 |  |  | 4,933 |  |
| Repayments of debt | (1,114) |  |  | (2,917) |  |  | (3,424) |  |  | (6,394) |  |
| Debt-related costs and other, net | (3) |  |  | (2) |  |  | (36) |  |  | (37) |  |
| Change in cash from financing activities | (1,465) |  |  | (2,032) |  |  | (228) |  |  | (4,109) |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash | 15 |  |  | (42) |  |  | 104 |  |  | (97) |  |
| Change in cash, cash equivalents, and restricted cash | 438 |  |  | (1,291) |  |  | 4,472 |  |  | (2,836) |  |
| Cash, cash equivalents, and restricted cash at beginning of the period | 7,853 |  |  | 5,962 |  |  | 3,819 |  |  | 7,507 |  |
| Cash, cash equivalents, and restricted cash at end of the period | $ | 8,291 |  |  | $ | 4,671 |  |  | $ | 8,291 |  |  | $ | 4,671 |  |

[0001571996-25-000096:8k_2_02:69]
DELL TECHNOLOGIES INC.

[0001571996-25-000096:8k_2_02:70]
Segment Information

[0001571996-25-000096:8k_2_02:71]
(in millions, except percentages; unaudited; continued on next page)

[0001571996-25-000096:8k_2_02:72]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | August 1, 2025 |  | August 2, 2024 |  | Change |  | August 1, 2025 |  | August 2, 2024 |  | Change |
| Infrastructure Solutions Group (ISG): |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Servers and networking | $ | 12,944 |  | $ | 7,672 |  |  | 69% |  | $ | 19,265 |  |  | $ | 13,138 |  |  | 47% |
| Storage | 3,856 |  |  | 3,974 |  |  | (3)% |  | 7,852 |  |  | 7,735 |  |  | 2% |
| Total ISG net revenue | $ | 16,800 |  |  | $ | 11,646 |  |  | 44% |  | $ | 27,117 |  |  | $ | 20,873 |  |  | 30% |
| Operating income: |  |  |  |  |  |  |  |  |  |  |  |
| ISG operating income | $ | 1,470 |  |  | $ | 1,284 |  |  | 14% |  | $ | 2,468 |  |  | $ | 2,020 |  |  | 22% |
| % of ISG net revenue | 8.8 | % |  | 11.0 | % |  |  |  | 9.1 | % |  | 9.7 | % |  |  |
| % of total reportable segment operating income | 65 | % |  | 61 | % |  |  |  | 63 | % |  | 56 | % |  |  |
| Client Solutions Group (CSG): |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 10,781 |  |  | $ | 10,556 |  |  | 2% |  | $ | 21,827 |  |  | $ | 20,710 |  |  | 5% |
| Consumer | 1,722 |  |  | 1,858 |  |  | (7)% |  | 3,185 |  |  | 3,671 |  |  | (13)% |
| Total CSG net revenue | $ | 12,503 |  |  | $ | 12,414 |  |  | 1% |  | $ | 25,012 |  |  | $ | 24,381 |  |  | 3% |
| Operating income: |  |  |  |  |  |  |  |  |  |  |  |
| CSG operating income | $ | 803 |  |  | $ | 817 |  |  | (2)% |  | $ | 1,456 |  |  | $ | 1,594 |  |  | (9)% |
| % of CSG net revenue | 6.4 | % |  | 6.6 | % |  |  |  | 5.8 | % |  | 6.5 | % |  |  |
| % of total reportable segment operating income | 35 | % |  | 39 | % |  |  |  | 37 | % |  | 44 | % |  |  |

[0001571996-25-000096:8k_2_02:73]
Amounts are based on underlying data and may not visually foot due to rounding.

[0001571996-25-000096:8k_2_02:74]
9

[0001571996-25-000096:8k_2_02:75]
DELL TECHNOLOGIES INC.

[0001571996-25-000096:8k_2_02:76]
Segment Information

[0001571996-25-000096:8k_2_02:77]
(in millions; unaudited; continued)

[0001571996-25-000096:8k_2_02:78]
|  | Three Months Ended |  | Six Months Ended |
|  | August 1, 2025 |  | August 2, 2024 |  | August 1, 2025 |  | August 2, 2024 |
| Reconciliation to consolidated net revenue: |  |  |  |  |  |  |  |
| Reportable segment net revenue | $ | 29,303 |  |  | $ | 24,060 |  |  | $ | 52,129 |  |  | $ | 45,254 |  |
| Corporate and other (a) | 473 |  |  | 966 |  |  | 1,025 |  |  | 2,016 |  |
| Total consolidated net revenue | $ | 29,776 |  |  | $ | 25,026 |  |  | $ | 53,154 |  |  | $ | 47,270 |  |
| Reconciliation to consolidated operating income: |  |  |  |  |  |  |
| Reportable segment operating income (b) | $ | 2,273 |  |  | $ | 2,101 |  |  | $ | 3,924 |  |  | $ | 3,614 |  |
| Corporate and other (a) | 11 |  |  | (17) |  |  | 26 |  |  | (11) |  |
| Amortization of intangibles (c) | (125) |  |  | (168) |  |  | (251) |  |  | (336) |  |
| Stock-based compensation expense (d) | (179) |  |  | (191) |  |  | (369) |  |  | (401) |  |
| Other corporate expenses (e) | (207) |  |  | (333) |  |  | (392) |  |  | (509) |  |
| Total consolidated operating income (f) | $ | 1,773 |  |  | $ | 1,392 |  |  | $ | 2,938 |  |  | $ | 2,357 |  |

[0001571996-25-000096:8k_2_02:79]
_________________

[0001571996-25-000096:8k_2_02:80]
(a)Corporate and other consists of results of divested businesses or non-reportable segments whose offerings are no longer actively sold, including (i) VMware Resale, (ii) Secureworks, and (iii) Virtustream, and do not meet the requirements for a reportable segment, either individually or collectively. Additionally, Corporate and other includes other items that are managed at the corporate level and are not allocated to reportable segments.

[0001571996-25-000096:8k_2_02:81]
(b)Depreciation expense directly attributable to each reportable segment is included in the operating results of each segment. However, the Chief Operating Decision Maker does not evaluate depreciation expense by operating segment, and therefore such expense is not separately presented.

[0001571996-25-000096:8k_2_02:82]
(c)Amortization of intangibles includes non-cash purchase accounting adjustments that are primarily related to the EMC merger transaction in 3QFY17.

[0001571996-25-000096:8k_2_02:83]
(d)Stock-based compensation expense consists of equity awards granted based on the estimated fair value of those awards at grant date.

[0001571996-25-000096:8k_2_02:84]
(e)Other corporate expenses includes severance expenses, payroll taxes associated with stock-based compensation, incentive charges related to equity investments, facility action costs, transaction-related expenses, and impairment charges.

[0001571996-25-000096:8k_2_02:85]
(f)Income and expenses within Interest and other, net, is not allocated to the reportable segments. Therefore, the company only reports reportable segment operating income.

[0001571996-25-000096:8k_2_02:86]
SUPPLEMENTAL SELECTED NON-GAAP FINANCIAL MEASURES

[0001571996-25-000096:8k_2_02:87]
These tables present information about the company’s non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, non-GAAP earnings per share attributable to Dell Technologies Inc. - diluted, free cash flow and adjusted free cash flow, all of which are non-GAAP financial measures provided as a supplement to the results provided in accordance with generally accepted accounting principles in the United States of America (“GAAP”). A detailed discussion of Dell Technologies’ reasons for including certain of these non-GAAP financial measures, the limitations associated with these measures, the items excluded from these measures, and the company’s reason for excluding those items are presented in “Management’s Discussion and Analysis of Financial Condition and Results of Operations — Non-GAAP Financial Measures” in the company’s periodic reports filed with the SEC. Dell Technologies encourages investors to review the non-GAAP discussion in these reports in conjunction with the presentation of non-GAAP financial measures.

[0001571996-25-000096:8k_2_02:88]
11

[0001571996-25-000096:8k_2_02:89]
DELL TECHNOLOGIES INC.

[0001571996-25-000096:8k_2_02:90]
Selected Financial Measures

[0001571996-25-000096:8k_2_02:91]
(in millions, except per share amounts and percentages; unaudited)

[0001571996-25-000096:8k_2_02:92]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | August 1, 2025 |  | August 2, 2024 |  | Change |  | August 1, 2025 |  | August 2, 2024 |  | Change |
| Net revenue | $ | 29,776 |  |  | $ | 25,026 |  |  | 19% |  | $ | 53,154 |  |  | $ | 47,270 |  |  | 12% |
| Non-GAAP gross margin | $ | 5,572 |  |  | $ | 5,514 |  |  | 1% |  | $ | 10,629 |  |  | $ | 10,506 |  |  | 1% |
| % of net revenue | 18.7 | % |  | 22.0 | % |  |  |  | 20.0 | % |  | 22.2 | % |  |  |
| Non-GAAP operating expenses | $ | 3,288 |  |  | $ | 3,430 |  |  | (4)% |  | $ | 6,679 |  |  | $ | 6,903 |  |  | (3)% |
| % of net revenue | 11.0 | % |  | 13.7 | % |  |  |  | 12.6 | % |  | 14.6 | % |  |  |
| Non-GAAP operating income | $ | 2,284 |  |  | $ | 2,084 |  |  | 10% |  | $ | 3,950 |  |  | $ | 3,603 |  |  | 10% |
| % of net revenue | 7.7 | % |  | 8.3 | % |  |  |  | 7.4 | % |  | 7.6 | % |  |  |
| Non-GAAP net income | $ | 1,591 |  |  | $ | 1,412 |  |  | 13% |  | $ | 2,677 |  |  | $ | 2,371 |  |  | 13% |
| % of net revenue | 5.3 | % |  | 5.6 | % |  |  |  | 5.0 | % |  | 5.0 | % |  |  |
| Non-GAAP earnings per share — diluted | $ | 2.32 |  |  | $ | 1.95 |  |  | 19% |  | $ | 3.86 |  |  | $ | 3.27 |  |  | 18% |

[0001571996-25-000096:8k_2_02:93]
Amounts are based on underlying data and may not visually foot due to rounding.

[0001571996-25-000096:8k_2_02:94]
DELL TECHNOLOGIES INC.

[0001571996-25-000096:8k_2_02:95]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-25-000096:8k_2_02:96]
(in millions, except percentages; unaudited; continued on next page)

[0001571996-25-000096:8k_2_02:97]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | August 1, 2025 |  | August 2, 2024 |  | Change |  | August 1, 2025 |  | August 2, 2024 |  | Change |
| Gross margin | $ | 5,447 |  |  | $ | 5,361 |  |  | 2% |  | $ | 10,384 |  |  | $ | 10,212 |  |  | 2% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 39 |  |  | 59 |  |  |  |  | 80 |  |  | 119 |  |  |  |
| Stock-based compensation expense | 37 |  |  | 38 |  |  |  |  | 76 |  |  | 76 |  |  |  |
| Other corporate expenses | 49 |  |  | 56 |  |  |  |  | 89 |  |  | 99 |  |  |  |
| Non-GAAP gross margin | $ | 5,572 |  |  | $ | 5,514 |  |  | 1% |  | $ | 10,629 |  |  | $ | 10,506 |  |  | 1% |
| Operating expenses | $ | 3,674 |  |  | $ | 3,969 |  |  | (7)% |  | $ | 7,446 |  |  | $ | 7,855 |  |  | (5)% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | (86) |  |  | (109) |  |  |  |  | (171) |  |  | (217) |  |  |  |
| Stock-based compensation expense | (142) |  |  | (153) |  |  |  |  | (293) |  |  | (325) |  |  |  |
| Other corporate expenses | (158) |  |  | (277) |  |  |  |  | (303) |  |  | (410) |  |  |  |
| Non-GAAP operating expenses | $ | 3,288 |  |  | $ | 3,430 |  |  | (4)% |  | $ | 6,679 |  |  | $ | 6,903 |  |  | (3)% |
| Operating income | $ | 1,773 |  |  | $ | 1,392 |  |  | 27% |  | $ | 2,938 |  |  | $ | 2,357 |  |  | 25% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 125 |  |  | 168 |  |  |  |  | 251 |  |  | 336 |  |  |  |
| Stock-based compensation expense | 179 |  |  | 191 |  |  |  |  | 369 |  |  | 401 |  |  |  |
| Other corporate expenses | 207 |  |  | 333 |  |  |  |  | 392 |  |  | 509 |  |  |  |
| Non-GAAP operating income | $ | 2,284 |  |  | $ | 2,084 |  |  | 10% |  | $ | 3,950 |  |  | $ | 3,603 |  |  | 10% |
| Net income | $ | 1,164 |  |  | $ | 882 |  |  | 32% |  | $ | 2,129 |  |  | $ | 1,874 |  |  | 14% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 125 |  |  | 168 |  |  |  |  | 251 |  |  | 336 |  |  |  |
| Stock-based compensation expense | 179 |  |  | 191 |  |  |  |  | 369 |  |  | 401 |  |  |  |
| Other corporate expenses | 200 |  |  | 329 |  |  |  |  | 142 |  |  | 499 |  |  |  |
| Fair value adjustments on equity investments | (4) |  |  | (5) |  |  |  |  | (21) |  |  | 25 |  |  |  |
| Aggregate adjustment for income taxes (a) | (73) |  |  | (153) |  |  |  |  | (193) |  |  | (764) |  |  |  |
| Non-GAAP net income | $ | 1,591 |  |  | $ | 1,412 |  |  | 13% |  | $ | 2,677 |  |  | $ | 2,371 |  |  | 13% |

[0001571996-25-000096:8k_2_02:98]
____________________

[0001571996-25-000096:8k_2_02:99]
(a)The company’s non-GAAP income tax is calculated using a fixed estimated annual tax rate.

[0001571996-25-000096:8k_2_02:100]
13

[0001571996-25-000096:8k_2_02:101]
DELL TECHNOLOGIES INC.

[0001571996-25-000096:8k_2_02:102]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-25-000096:8k_2_02:103]
(unaudited; continued)

[0001571996-25-000096:8k_2_02:104]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | August 1, 2025 |  | August 2, 2024 |  | Change |  | August 1, 2025 |  | August 2, 2024 |  | Change |
| Earnings per share attributable to Dell Technologies Inc. — diluted | $ | 1.70 |  |  | $ | 1.23 |  |  | 38 | % |  | $ | 3.07 |  |  | $ | 2.60 |  |  | 18 | % |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 0.19 |  |  | 0.23 |  |  |  |  | 0.36 |  |  | 0.46 |  |  |  |
| Stock-based compensation expense | 0.26 |  |  | 0.26 |  |  |  |  | 0.53 |  |  | 0.55 |  |  |  |
| Other corporate expenses | 0.29 |  |  | 0.46 |  |  |  |  | 0.21 |  |  | 0.69 |  |  |  |
| Fair value adjustments on equity investments | (0.01) |  |  | (0.01) |  |  |  |  | (0.03) |  |  | 0.04 |  |  |  |
| Aggregate adjustment for income taxes (a) | (0.11) |  |  | (0.21) |  |  |  |  | (0.28) |  |  | (1.05) |  |  |  |
| Total non-GAAP adjustments attributable to non-controlling interests | — |  |  | (0.01) |  |  |  |  | — |  |  | (0.02) |  |  |  |
| Non-GAAP earnings per share attributable to Dell Technologies Inc. — diluted | $ | 2.32 |  |  | $ | 1.95 |  |  | 19 | % |  | $ | 3.86 |  |  | $ | 3.27 |  |  | 18 | % |

[0001571996-25-000096:8k_2_02:105]
____________________

[0001571996-25-000096:8k_2_02:106]
(a)The company’s non-GAAP income tax is calculated using a fixed estimated annual tax rate.

[0001571996-25-000096:8k_2_02:107]
DELL TECHNOLOGIES INC.

[0001571996-25-000096:8k_2_02:108]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-25-000096:8k_2_02:109]
(in millions, except percentages; unaudited; continued)

[0001571996-25-000096:8k_2_02:110]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | August 1, 2025 |  | August 2, 2024 |  | Change |  | August 1, 2025 |  | August 2, 2024 |  | Change |
| Cash flow from operations | $ | 2,543 |  |  | $ | 1,340 |  |  | 90 | % |  | $ | 5,339 |  |  | $ | 2,383 |  |  | 124 | % |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Capital expenditures and capitalized software development costs, net (a) | (675) |  |  | (636) |  |  |  |  | (1,243) |  |  | (1,222) |  |  |  |
| Free cash flow | $ | 1,868 |  |  | $ | 704 |  |  | 165 | % |  | $ | 4,096 |  |  | $ | 1,161 |  |  | 253 | % |
| Free cash flow | $ | 1,868 |  |  | $ | 704 |  |  | 165 | % |  | $ | 4,096 |  |  | $ | 1,161 |  |  | 253 | % |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Financing receivables (b) | 592 |  |  | 487 |  |  |  |  | 569 |  |  | 652 |  |  |  |
| Equipment under operating leases (c) | 58 |  |  | 93 |  |  |  |  | 85 |  |  | 94 |  |  |  |
| Adjusted free cash flow | $ | 2,518 |  |  | $ | 1,284 |  |  | 96 | % |  | $ | 4,750 |  |  | $ | 1,907 |  |  | 149 | % |

[0001571996-25-000096:8k_2_02:111]
____________________

[0001571996-25-000096:8k_2_02:112]
(a)Capital expenditures and capitalized software development costs, net includes proceeds from sales of facilities, land, and other assets.

[0001571996-25-000096:8k_2_02:113]
(b)Financing receivables represent the operating cash flow impact from the change in financing receivables.

[0001571996-25-000096:8k_2_02:114]
(c)Equipment under operating leases represents the net impact of capital expenditures and depreciation expense for leases and contractually embedded leases identified within flexible consumption arrangements.

[0001571996-25-000096:8k_2_02:115]
15

[0001571996-25-000096:8k_2_02:116]
DELL TECHNOLOGIES INC.

[0001571996-25-000096:8k_2_02:117]
Reconciliation of Non-GAAP Financial Measures in Summary Guidance

[0001571996-25-000096:8k_2_02:118]
(unaudited)

[0001571996-25-000096:8k_2_02:119]
|  |  |  |  |  | Three Months Ending |  |  |  |  |  | Fiscal Year Ending |
|  |  |  |  |  | October 31, 2025 |  |  |  |  |  | January 30, 2026 |
| Earnings per share attributable to Dell Technologies Inc. — diluted |  |  |  |  | $ | 2.07 |  |  |  |  |  |  | $ | 7.98 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles (a) |  |  |  |  | 0.18 |  |  |  |  |  |  | 0.72 |  |
| Stock-based compensation |  |  |  |  | 0.26 |  |  |  |  |  |  | 1.05 |  |
| Other corporate expenses (b) |  |  |  |  | — |  |  |  |  |  |  | 0.22 |  |
| Fair value adjustments on equity investments (c) |  |  |  |  | — |  |  |  |  |  |  | (0.03) |  |
| Aggregate adjustment for income taxes (d) |  |  |  |  | (0.06) |  |  |  |  |  |  | (0.39) |  |
| Non-GAAP earnings per share attributable to Dell Technologies Inc. — diluted |  |  |  |  | $ | 2.45 |  |  |  |  |  |  | $ | 9.55 |  |

[0001571996-25-000096:8k_2_02:120]
____________________

[0001571996-25-000096:8k_2_02:121]
(a)Amortization of intangibles represents an estimate for acquisitions completed as of August 1, 2025 and does not include estimates for potential acquisitions, if any, during fiscal 2026.

[0001571996-25-000096:8k_2_02:122]
(b)Consists primarily of severance expenses, payroll taxes associated with stock-based compensation, facility action costs, transaction-related expenses, impairment charges, and incentive charges related to equity investments. Additionally, amount shown includes transaction-related gains on sales of businesses that have been completed as of August 1, 2025 and does not include estimates for potential transactions, if any, during fiscal 2026. No estimate is included for severance expense as such expense cannot be reasonably estimated at this time.

[0001571996-25-000096:8k_2_02:123]
(c)No estimates are included for potential fair value adjustments on strategic investments given the potential volatility of either gains or losses on those equity investments.

[0001571996-25-000096:8k_2_02:124]
(d)The fiscal 2026 aggregate adjustment to reconcile from GAAP to Non-GAAP income tax expense is approximately $0.3 billion. The aggregate adjustment for income taxes is the estimated combined income tax effect for the adjustments shown above as well as an adjustment for discrete tax items. The company’s non-GAAP income tax is calculated using a fixed estimated annual tax rate.
