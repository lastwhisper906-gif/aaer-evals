# DELL note change history — 0001571996-25-000063 → 0001571996-25-000102


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-09-08):
[0001571996-25-000102:note_history:1]
The Company has contractual obligations to purchase goods or services, which specify significant terms (including fixed or minimum quantities to be purchased), fixed, minimum, or variable price provisions, and the approximate timing of the transaction. Purchase obligations are primarily related to commitments with suppliers and software maintenance and support services. As of August 1, 2025, such purchase obligations were $5.1 billion for the remainder of Fiscal 2026, $0.7 billion for Fiscal 2027, $0.5 billion for Fiscal 2028, $0.4 billion for Fiscal 2029, and $0.5 billion for Fiscal 2030 and thereafter.
  (was, 2025-06-10, similarity 0.9411):
[0001571996-25-000063:note_history:1]
The Company has contractual obligations to purchase goods or services, which specify significant terms (including fixed or minimum quantities to be purchased), fixed, minimum, or variable price provisions, and the approximate timing of the transaction. Purchase obligations are primarily related to commitments with suppliers and software maintenance and support services. As of May 2, 2025, such purchase obligations were $5.6 billion for the remainder of Fiscal 2026, $0.6 billion for Fiscal 2027, and $1.2 billion for Fiscal 2028 and thereafter.

- changed (2025-09-08):
[0001571996-25-000102:note_history:2]
The Company accrues a liability when it believes that it is both probable that a liability has been incurred and that it can reasonably estimate the amount of the loss. The Company reviews these accruals at least quarterly and adjusts them to reflect ongoing negotiations, settlements, rulings, advice of legal counsel, and other relevant information. To the extent new information is obtained and the Company’s views on the probable outcomes of claims, suits, assessments, investigations, or legal proceedings change, changes in the Company’s accrued liabilities are recorded in the period in which such a determination is made. For some matters, the incurrence of a liability is not probable or the amount cannot be reasonably estimated and therefore accruals have not been made. As of August 1, 2025, the Company does not currently anticipate that any of the legal proceedings it is involved in will have a material adverse effect on its business, financial condition, results of operations, or cash flows.
  (was, 2025-06-10, similarity 0.9955):
[0001571996-25-000063:note_history:2]
The Company accrues a liability when it believes that it is both probable that a liability has been incurred and that it can reasonably estimate the amount of the loss. The Company reviews these accruals at least quarterly and adjusts them to reflect ongoing negotiations, settlements, rulings, advice of legal counsel, and other relevant information. To the extent new information is obtained and the Company’s views on the probable outcomes of claims, suits, assessments, investigations, or legal proceedings change, changes in the Company’s accrued liabilities are recorded in the period in which such a determination is made. For some matters, the incurrence of a liability is not probable or the amount cannot be reasonably estimated and therefore accruals have not been made. As of May 2, 2025, the Company does not currently anticipate that any of the legal proceedings it is involved in will have a material adverse effect on its business, financial condition, results of operations, or cash flows.

- added (2025-09-08):
[0001571996-25-000102:note_history:3]
In accordance with the relevant accounting guidance, the Company provides disclosures of matters where it is at least reasonably possible that the Company could experience a material loss exceeding the amounts already accrued for across all proceedings or matters. In addition, the Company also discloses matters based on its consideration of other matters and qualitative factors, including the experience of other companies in the industry, and investor, customer, and employee relations considerations. As of August 1, 2025, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for across all proceedings or matters has been incurred. However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company’s business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters. Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company’s business, financial condition, results of operations, or cash flows will depend on a number of factors, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.

- changed (2025-09-08):
[0001571996-25-000102:note_history:4]
Under the Separation and Distribution Agreement entered into with VMware, Inc. upon completion of its spin-off of VMware, Inc. on November 1, 2021, Dell Technologies agreed to indemnify VMware, Inc., each of its subsidiaries and each of their respective directors, officers, employees, as well as any successors and assigns of the foregoing, from and against all liabilities relating to, arising out of or resulting from, among other matters, the liabilities allocated to Dell Technologies as part of the separation of Dell Technologies and VMware, Inc. (currently operating under the name VMware LLC, and individually and together with its subsidiaries, “VMware”) and their respective businesses (the “Separation”). VMware similarly agreed to indemnify Dell Technologies Inc., each of its subsidiaries and each of their respective directors, officers, and employees from and against all liabilities relating to, arising out of or resulting from, among other matters, the liabilities allocated to VMware as part of the Separation. The amounts that VMware and Dell Technologies may be obligated to pay each other could vary depending on the outcome of certain unresolved tax matters, which may not be resolved for several years. Net income tax indemnification receivables from VMware were immaterial as of August 1, 2025 and January 31, 2025.
  (was, 2025-06-10, similarity 0.9966):
[0001571996-25-000063:note_history:4]
Under the Separation and Distribution Agreement entered into with VMware, Inc. upon completion of its spin-off of VMware, Inc. on November 1, 2021, Dell Technologies agreed to indemnify VMware, Inc., each of its subsidiaries and each of their respective directors, officers, employees, as well as any successors and assigns of the foregoing, from and against all liabilities relating to, arising out of or resulting from, among other matters, the liabilities allocated to Dell Technologies as part of the separation of Dell Technologies and VMware, Inc. (currently operating under the name VMware LLC, and individually and together with its subsidiaries, “VMware”) and their respective businesses (the “Separation”). VMware similarly agreed to indemnify Dell Technologies Inc., each of its subsidiaries and each of their respective directors, officers, and employees from and against all liabilities relating to, arising out of or resulting from, among other matters, the liabilities allocated to VMware as part of the Separation. The amounts that VMware and Dell Technologies may be obligated to pay each other could vary depending on the outcome of certain unresolved tax matters, which may not be resolved for several years. Net income tax indemnification receivables from VMware were immaterial as of May 2, 2025 and January 31, 2025.

- removed (2025-09-08):
[0001571996-25-000063:note_history:5]
In accordance with the relevant accounting guidance, the Company provides disclosures of matters where it is at least reasonably possible that the Company could experience a material loss exceeding the amounts already accrued for across all proceedings or matters. In addition, the Company also discloses matters based on its consideration of other matters and qualitative factors, including the experience of other companies in the industry, and investor, customer, and employee relations considerations. As of May 2, 2025, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for across all proceedings or matters has been incurred. However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company’s business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters. Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company’s business, financial condition, results of operations, or cash flows will depend on a number of factors, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.


## dell:CreditLossFinancialInstrumentLeasesDebtVariableInterestEntitiesAndCustomerReceivablesSalesTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-09-08):
[0001571996-25-000102:note_history:6]
To support financing solutions and services as part of the Dell Technologies portfolio, Dell Financial Services and its affiliates (“DFS”) originates, collects, and services customer financing arrangements primarily related to the purchase and use of Dell Technologies products and services. In some cases, the Company also offers financing for the purchase of third-party technology products that complement the portfolio of products and services. New financing originations were $2.4 billion for both the three months ended August 1, 2025 and August 2, 2024, and $4.0 billion and $4.3 billion for the six months ended August 1, 2025 and August 2, 2024, respectively.
  (was, 2025-06-10, similarity 0.8423):
[0001571996-25-000063:note_history:6]
To support financing solutions and services as part of the portfolio, Dell Financial Services and its affiliates (“DFS”) originates, collects, and services customer financing arrangements primarily related to the purchase and use of Dell Technologies products and services. In some cases, the Company also offers financing for the purchase of third-party technology products that complement the Dell Technologies portfolio of products and services. New financing originations were $1.6 billion and $1.9 billion for the three months ended May 2, 2025 and May 3, 2024, respectively.

- changed (2025-09-08):
[0001571996-25-000102:note_history:7]
Leases — The Company enters into fixed-term financing arrangements with customers who seek lease financing for equipment. Leases are generally classified as sales-type leases or operating leases. Additionally, utility, subscription, and as-a-Service flexible consumption models may result in identification of embedded lease arrangements that require the recognition of sales-type leases or operating leases. Leases with business customers have fixed terms of generally two to five years.
  (was, 2025-06-10, similarity 0.9939):
[0001571996-25-000063:note_history:7]
Leases — The Company enters into fixed-term financing arrangements with customers who seek lease financing for equipment. Leases are generally classified as sales-type leases or operating leases. Additionally, utility, subscription, and as-a-Service flexible consumption models may result in identification of embedded lease arrangements that require the recognition of sales-type leases or operating leases. Leases with business customers have fixed terms of generally two to four years.

- changed (2025-09-08):
[0001571996-25-000102:note_history:8]
The Company historically offered revolving loans primarily to small and medium-sized commercial customers. During Fiscal 2025, the Company discontinued remaining offerings under the revolving loan portfolio. The Company continues to support existing customer arrangements as well as to transition these customers to fixed-term offerings. Due to the short-term nature of the revolving loan portfolio, in which transactions are typically repaid within twelve months on average, the portfolio had substantially transitioned to such fixed-term offerings as of August 1, 2025.
  (was, 2025-06-10, similarity 0.8246):
[0001571996-25-000063:note_history:8]
The Company historically offered revolving loans primarily to small and medium-sized commercial customers. During Fiscal 2025, the Company discontinued remaining offerings under the revolving loan portfolio. The Company continues to support existing customer arrangements as well as to transition these customers to fixed-term offerings. Due to the short-term nature of the revolving loan portfolio, as transactions are typically repaid within twelve months on average, the portfolio has now substantially transitioned to such fixed-term offerings.

- changed (2025-09-08):
[0001571996-25-000102:note_history:9]
|  |  |  |  |  | August 1, 2025 |  |  |  |  |  | January 31, 2025 |
|  |  |  |  |  | (in millions) |
| Financing receivables, net: |  |  |  |  |  |  |  |  |  |  |  |
| Customer receivables, gross (a) |  |  |  |  | $ | 11,989 |  |  |  |  |  |  | $ | 11,216 |  |
| Allowance for losses |  |  |  |  | (151) |  |  |  |  |  |  | (153) |  |
| Customer receivables, net |  |  |  |  | 11,838 |  |  |  |  |  |  | 11,063 |  |
| Residual interest |  |  |  |  | 185 |  |  |  |  |  |  | 168 |  |
| Financing receivables, net |  |  |  |  | $ | 12,023 |  |  |  |  |  |  | $ | 11,231 |  |
| Short-term |  |  |  |  | $ | 5,952 |  |  |  |  |  |  | $ | 5,304 |  |
| Long-term |  |  |  |  | $ | 6,071 |  |  |  |  |  |  | $ | 5,927 |  |
  (was, 2025-06-10, similarity 0.9918):
[0001571996-25-000063:note_history:9]
|  |  |  |  |  | May 2, 2025 |  |  |  |  |  | January 31, 2025 |
|  |  |  |  |  | (in millions) |
| Financing receivables, net: |  |  |  |  |  |  |  |  |  |  |  |
| Customer receivables, gross (a) |  |  |  |  | $ | 11,389 |  |  |  |  |  |  | $ | 11,216 |  |
| Allowance for losses |  |  |  |  | (144) |  |  |  |  |  |  | (153) |  |
| Customer receivables, net |  |  |  |  | 11,245 |  |  |  |  |  |  | 11,063 |  |
| Residual interest |  |  |  |  | 178 |  |  |  |  |  |  | 168 |  |
| Financing receivables, net |  |  |  |  | $ | 11,423 |  |  |  |  |  |  | $ | 11,231 |  |
| Short-term |  |  |  |  | $ | 5,381 |  |  |  |  |  |  | $ | 5,304 |  |
| Long-term |  |  |  |  | $ | 6,042 |  |  |  |  |  |  | $ | 5,927 |  |

- added (2025-09-08):
[0001571996-25-000102:note_history:10]
|  | Three Months Ended |  |  |  |  |  | Six Months Ended |
|  | August 1, 2025 |  | August 2, 2024 |  |  |  |  |  | August 1, 2025 |  |  |  |  |  | August 2, 2024 |  |  |
|  | (in millions) |  |  |  |  |  |  |
| Allowance for financing receivable losses: |
| Balances at beginning of period | $ | 144 |  |  | $ | 195 |  |  |  |  |  |  | $ | 153 |  |  |  |  |  |  | $ | 170 |  |  |  |  |  |  |  |
| Charge-offs, net of recoveries | (4) |  |  | (19) |  |  |  |  |  |  | (14) |  |  |  |  |  |  | (27) |  |  |  |  |  |  |  |
| Provision charged to income statement | 11 |  |  | (10) |  |  |  |  |  |  | 12 |  |  |  |  |  |  | 23 |  |  |  |  |  |  |  |
| Balances at end of period | $ | 151 |  |  | $ | 166 |  |  |  |  |  |  | $ | 151 |  |  |  |  |  |  | $ | 166 |  |  |  |  |  |  |  |

- changed (2025-09-08):
[0001571996-25-000102:note_history:11]
|  | August 1, 2025 |  | January 31, 2025 |
|  | (in millions) |
| Current 0 — 30 Days | $ | 11,355 |  |  | $ | 10,796 |  |
| Past Due 31 — 90 Days | 467 |  |  | 201 |  |
| Past Due > 90 Days | 167 |  |  | 219 |  |
| Total | $ | 11,989 |  |  | $ | 11,216 |  |
  (was, 2025-06-10, similarity 0.9777):
[0001571996-25-000063:note_history:11]
|  | May 2, 2025 |  | January 31, 2025 |
|  | (in millions) |
| Current 0 — 30 Days | $ | 10,718 |  |  | $ | 10,796 |  |
| Past Due 31 — 90 Days | 536 |  |  | 201 |  |
| Past Due > 90 Days | 135 |  |  | 219 |  |
| Total | $ | 11,389 |  |  | $ | 11,216 |  |

- changed (2025-09-08):
[0001571996-25-000102:note_history:12]
|  | August 1, 2025 |
|  | Fiscal Year of Origination |  |  |
|  | 2026 |  | 2025 |  | 2024 |  | 2023 |  | 2022 |  | Years Prior |  | Total |
|  | (in millions) |
| Higher | $ | 1,852 |  |  | $ | 1,949 |  |  | $ | 1,786 |  |  | $ | 824 |  |  | $ | 186 |  |  | $ | 38 |  |  | $ | 6,635 |  |
| Mid | 1,227 |  |  | 1,771 |  |  | 529 |  |  | 303 |  |  | 52 |  |  | 5 |  |  | 3,887 |  |
| Lower | 534 |  |  | 416 |  |  | 294 |  |  | 171 |  |  | 33 |  |  | 19 |  |  | 1,467 |  |
| Total | $ | 3,613 |  |  | $ | 4,136 |  |  | $ | 2,609 |  |  | $ | 1,298 |  |  | $ | 271 |  |  | $ | 62 |  |  | $ | 11,989 |  |
  (was, 2025-06-10, similarity 0.9436):
[0001571996-25-000063:note_history:12]
|  | May 2, 2025 |
|  | Fiscal Year of Origination |  |  |  |  |
|  | 2026 |  | 2025 |  | 2024 |  | 2023 |  | 2022 |  | Years Prior |  |  |  | Total |
|  | (in millions) |
| Higher | $ | 839 |  |  | $ | 2,235 |  |  | $ | 1,896 |  |  | $ | 994 |  |  | $ | 237 |  |  | $ | 64 |  |  |  |  | $ | 6,265 |  |
| Mid | 612 |  |  | 2,069 |  |  | 621 |  |  | 385 |  |  | 79 |  |  | 10 |  |  |  |  | 3,776 |  |
| Lower | 261 |  |  | 472 |  |  | 329 |  |  | 216 |  |  | 48 |  |  | 22 |  |  |  |  | 1,348 |  |
| Total | $ | 1,712 |  |  | $ | 4,776 |  |  | $ | 2,846 |  |  | $ | 1,595 |  |  | $ | 364 |  |  | $ | 96 |  |  |  |  | $ | 11,389 |  |

- changed (2025-09-08):
[0001571996-25-000102:note_history:13]
|  | January 31, 2025 |
|  | Fiscal Year of Origination |  |  |
|  | 2025 |  | 2024 |  | 2023 |  | 2022 |  | 2021 |  | Years Prior |  | Total |
|  | (in millions) |
| Higher | $ | 2,295 |  |  | $ | 2,160 |  |  | $ | 1,217 |  |  | $ | 357 |  |  | $ | 102 |  |  | $ | 4 |  |  | $ | 6,135 |  |
| Mid | 2,455 |  |  | 695 |  |  | 464 |  |  | 107 |  |  | 17 |  |  | 4 |  |  | 3,742 |  |
| Lower | 552 |  |  | 407 |  |  | 283 |  |  | 68 |  |  | 28 |  |  | 1 |  |  | 1,339 |  |
| Total | $ | 5,302 |  |  | $ | 3,262 |  |  | $ | 1,964 |  |  | $ | 532 |  |  | $ | 147 |  |  | $ | 9 |  |  | $ | 11,216 |  |
  (was, 2025-06-10, similarity 0.9293):
[0001571996-25-000063:note_history:13]
|  | January 31, 2025 |
|  | Fiscal Year of Origination |  |  |  |  |  |  |
|  | 2025 |  | 2024 |  | 2023 |  | 2022 |  | 2021 |  | Years Prior |  |  |  |  |  | Total |
|  | (in millions) |
| Higher | $ | 2,295 |  |  | $ | 2,160 |  |  | $ | 1,217 |  |  | $ | 357 |  |  | $ | 102 |  |  | $ | 4 |  |  |  |  |  |  | $ | 6,135 |  |
| Mid | 2,455 |  |  | 695 |  |  | 464 |  |  | 107 |  |  | 17 |  |  | 4 |  |  |  |  |  |  | 3,742 |  |
| Lower | 552 |  |  | 407 |  |  | 283 |  |  | 68 |  |  | 28 |  |  | 1 |  |  |  |  |  |  | 1,339 |  |
| Total | $ | 5,302 |  |  | $ | 3,262 |  |  | $ | 1,964 |  |  | $ | 532 |  |  | $ | 147 |  |  | $ | 9 |  |  |  |  |  |  | $ | 11,216 |  |

- changed (2025-09-08):
[0001571996-25-000102:note_history:14]
|  | Three Months Ended |  | Six Months Ended |
|  | August 1, 2025 |  | August 2, 2024 |  | August 1, 2025 |  | August 2, 2024 |  |  |
|  | (in millions) |
| Interest income — products | $ | 92 |  |  | $ | 73 |  |  | $ | 185 |  |  | $ | 139 |  |  |  |
| Net revenue — products | $ | 181 |  |  | $ | 622 |  |  | $ | 300 |  |  | $ | 1,350 |  |  |  |
| Cost of net revenue — products | 178 |  |  | 537 |  |  | 309 |  |  | 1,155 |  |  |  |
| Gross margin — products | $ | 3 |  |  | $ | 85 |  |  | $ | (9) |  |  | $ | 195 |  |  |  |
  (was, 2025-06-10, similarity 0.7714):
[0001571996-25-000063:note_history:14]
|  |  |  | Three Months Ended |
|  |  |  |  |  | May 2, 2025 |  | May 3, 2024 |  |  |
|  |  |  |  |  | (in millions) |
| Interest income — products |  |  |  |  | $ | 93 |  |  | $ | 66 |  |  |  |
| Net revenue — products |  |  |  |  | $ | 119 |  |  | $ | 728 |  |  |  |
| Cost of net revenue — products |  |  |  |  | 131 |  |  | 618 |  |  |  |
| Gross margin — products |  |  |  |  | $ | (12) |  |  | $ | 110 |  |  |  |

- changed (2025-09-08):
[0001571996-25-000102:note_history:15]
|  | August 1, 2025 |
|  | (in millions) |
| Fiscal 2026 (remaining six months) | $ | 1,702 |  |
| Fiscal 2027 | 2,665 |  |
| Fiscal 2028 | 1,308 |  |
| Fiscal 2029 | 700 |  |
| Fiscal 2030 and thereafter | 347 |  |
| Total undiscounted cash flows | 6,722 |  |
| Loans | 6,288 |  |
| Less: Unearned income | (1,021) |  |
| Total customer receivables, gross | $ | 11,989 |  |
  (was, 2025-06-10, similarity 0.741):
[0001571996-25-000063:note_history:15]
|  | May 2, 2025 |
|  | (in millions) |
| Fiscal 2026 (remaining nine months) | $ | 967 |  |
| Fiscal 2027 | 908 |  |
| Fiscal 2028 | 515 |  |
| Fiscal 2029 | 204 |  |
| Fiscal 2030 and thereafter | 67 |  |
| Total | $ | 2,661 |  |

- changed (2025-09-08):
[0001571996-25-000102:note_history:16]
|  | August 1, 2025 |  | January 31, 2025 |
|  | (in millions) |
| Equipment under operating lease, gross | $ | 4,492 |  |  | $ | 4,180 |  |
| Less: Accumulated depreciation | (2,178) |  |  | (1,995) |  |
| Equipment under operating lease, net | $ | 2,314 |  |  | $ | 2,185 |  |
  (was, 2025-06-10, similarity 0.9806):
[0001571996-25-000063:note_history:16]
|  | May 2, 2025 |  | January 31, 2025 |
|  | (in millions) |
| Equipment under operating lease, gross | $ | 4,420 |  |  | $ | 4,180 |  |
| Less: Accumulated depreciation | (2,148) |  |  | (1,995) |  |
| Equipment under operating lease, net | $ | 2,272 |  |  | $ | 2,185 |  |

- added (2025-09-08):
[0001571996-25-000102:note_history:17]
|  | Three Months Ended |  | Six Months Ended |
|  | August 1, 2025 |  | August 2, 2024 |  | August 1, 2025 |  | August 2, 2024 |  |  |
|  | (in millions) |
| Income related to lease payments | $ | 390 |  |  | $ | 362 |  |  | $ | 748 |  |  | $ | 718 |  |  |  |
| Depreciation expense | $ | 256 |  |  | $ | 245 |  |  | $ | 500 |  |  | $ | 485 |  |  |  |

- added (2025-09-08):
[0001571996-25-000102:note_history:18]
|  | August 1, 2025 |
|  | (in millions) |
| Fiscal 2026 (remaining six months) | $ | 672 |  |
| Fiscal 2027 | 1,048 |  |
| Fiscal 2028 | 622 |  |
| Fiscal 2029 | 278 |  |
| Fiscal 2030 and thereafter | 99 |  |
| Total | $ | 2,719 |  |

- changed (2025-09-08):
[0001571996-25-000102:note_history:19]
|  | August 1, 2025 |  | January 31, 2025 |
| DFS debt | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing facility | $ | 3,001 |  |  | $ | 3,018 |  |
| Fixed-term securitization offerings | 2,685 |  |  | 2,756 |  |
| Total DFS U.S. debt, principal amount | 5,686 |  |  | 5,774 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 657 |  |  | 624 |  |
| Other borrowings | 760 |  |  | 754 |  |
| Dell Bank senior unsecured eurobonds | 1,712 |  |  | 1,559 |  |
| Total DFS international debt, principal amount | 3,129 |  |  | 2,937 |  |
| Total DFS debt, principal amount | $ | 8,815 |  |  | $ | 8,711 |  |
| Total short-term DFS debt | $ | 4,624 |  |  | $ | 5,175 |  |
| Total long-term DFS debt | $ | 4,191 |  |  | $ | 3,536 |  |
  (was, 2025-06-10, similarity 0.993):
[0001571996-25-000063:note_history:19]
|  | May 2, 2025 |  | January 31, 2025 |
| DFS debt | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing facility | $ | 2,606 |  |  | $ | 3,018 |  |
| Fixed-term securitization offerings | 3,154 |  |  | 2,756 |  |
| Total DFS U.S. debt, principal amount | 5,760 |  |  | 5,774 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 702 |  |  | 624 |  |
| Other borrowings | 772 |  |  | 754 |  |
| Dell Bank senior unsecured eurobonds | 1,693 |  |  | 1,559 |  |
| Total DFS international debt, principal amount | 3,167 |  |  | 2,937 |  |
| Total DFS debt, principal amount | $ | 8,927 |  |  | $ | 8,711 |  |
| Total short-term DFS debt | $ | 4,809 |  |  | $ | 5,175 |  |
| Total long-term DFS debt | $ | 4,118 |  |  | $ | 3,536 |  |

- changed (2025-09-08):
[0001571996-25-000102:note_history:20]
Asset-Based Financing Facility — The Company maintains an asset-based financing facility in the United States, which is a revolving facility for fixed-term leases and loans. This debt is collateralized solely by the U.S. lease and loan payments and associated equipment in the facility. The asset-based financing facility consists of two tranches, with effective dates through July 7, 2026 and July 7, 2027, respectively. As of August 1, 2025, the total debt capacity related to the asset-based financing facility was $4.6 billion. The debt has a variable interest rate, and the duration of the debt is based on the terms of the underlying lease and loan payment streams. The Company enters into interest rate swap agreements to economically convert a portion of this debt from a floating rate to a fixed rate. See Note 7 of the Notes to the Condensed Consolidated Financial Statements for additional information about the Company’s interest rate swaps.
  (was, 2025-06-10, similarity 0.9952):
[0001571996-25-000063:note_history:20]
Asset-Based Financing Facility — The Company maintains an asset-based financing facility in the United States, which is a revolving facility for fixed-term leases and loans. This debt is collateralized solely by the U.S. lease and loan payments and associated equipment in the facility. The asset-based financing facility consists of two tranches, with effective dates through July 7, 2025 and July 7, 2026, respectively. As of May 2, 2025, the total debt capacity related to the asset-based financing facility was $5.0 billion. The debt has a variable interest rate, and the duration of the debt is based on the terms of the underlying lease and loan payment streams. The Company enters into interest rate swap agreements to economically convert a portion of this debt from a floating rate to a fixed rate. See Note 7 of the Notes to the Condensed Consolidated Financial Statements for additional information about the Company’s interest rate swaps.

- changed (2025-09-08):
[0001571996-25-000102:note_history:21]
The asset-based financing facility contains standard structural features related to the performance of the funded receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements. In the event one or more of these criteria are not met and the Company is unable to restructure the facility, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed. As of August 1, 2025, these criteria were met.
  (was, 2025-06-10, similarity 0.9916):
[0001571996-25-000063:note_history:21]
The asset-based financing facility contains standard structural features related to the performance of the funded receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements. In the event one or more of these criteria are not met and the Company is unable to restructure the facility, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed. As of May 2, 2025, these criteria were met.

- changed (2025-09-08):
[0001571996-25-000102:note_history:22]
Fixed-Term Securitization Offerings — The Company periodically issues asset-backed debt securities under fixed-term securitization programs to private investors. The asset-backed debt securities are collateralized solely by the U.S. fixed-term lease and loan payments and associated equipment, which are held by Special Purpose Entities (“SPEs”), as discussed below. The interest rate on these securities is fixed and ranges from 4.59% to 6.80% per annum as of August 1, 2025, and the duration of these securities is based on the terms of the underlying lease and loan payment streams.
  (was, 2025-06-10, similarity 0.8524):
[0001571996-25-000063:note_history:22]
Fixed-Term Securitization Offerings — The Company periodically issues asset-backed debt securities under fixed-term securitization programs to private investors. The asset-backed debt securities are collateralized solely by the U.S. fixed-term lease and loan payments and associated equipment, which are held by Special Purpose Entities (“SPEs”), as discussed below. The interest rate on these securities is fixed and ranges from 4.59% to 6.80% per annum as of May 2, 2025, and the duration of these securities is based on the terms of the underlying lease and loan payment streams.

- changed (2025-09-08):
[0001571996-25-000102:note_history:23]
Securitization Facility — The Company maintains a securitization facility in Europe for fixed-term leases and loans. The debt under this facility has a variable interest rate, and the duration of the debt is based on the terms of the underlying lease and loan payment streams. This facility is effective through December 22, 2026 and had a total debt capacity of $913 million as of August 1, 2025.
  (was, 2025-06-10, similarity 0.9778):
[0001571996-25-000063:note_history:23]
Securitization Facility — The Company maintains a securitization facility in Europe for fixed-term leases and loans. The debt under this facility has a variable interest rate, and the duration of the debt is based on the terms of the underlying lease and loan payment streams. This facility is effective through December 22, 2026 and had a total debt capacity of $903 million as of May 2, 2025.

- changed (2025-09-08):
[0001571996-25-000102:note_history:24]
The securitization facility contains standard structural features related to the performance of the securitized receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements. In the event one or more of these criteria are not met and the Company is unable to restructure the program, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed. As of August 1, 2025, these criteria were met.
  (was, 2025-06-10, similarity 0.9916):
[0001571996-25-000063:note_history:24]
The securitization facility contains standard structural features related to the performance of the securitized receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements. In the event one or more of these criteria are not met and the Company is unable to restructure the program, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed. As of May 2, 2025, these criteria were met.

- changed (2025-09-08):
[0001571996-25-000102:note_history:25]
The duration of the debt in Canada, Europe, Australia and New Zealand, and the Middle East is based on the terms of the underlying lease and loan payment streams. These facilities are collateralized solely by the lease and loan payments and associated equipment in their respective region or country. The Canadian facility had a total debt capacity of $253 million as of August 1, 2025 and is effective through January 15, 2028. The European facility had a total debt capacity of $457 million as of August 1, 2025 and is effective through December 14, 2026. The Australia and New Zealand facility had a total debt capacity of $273 million as of August 1, 2025 and is effective through April 17, 2027. The Middle East facility had a total debt capacity of $150 million as of August 1, 2025 and is effective through March 14, 2027.
  (was, 2025-06-10, similarity 0.6):
[0001571996-25-000063:note_history:25]
The duration of the debt in Canada, Europe, Australia and New Zealand, and the Middle East is based on the terms of the underlying lease and loan payment streams. These facilities are collateralized solely by the lease and loan payments and associated equipment in their respective region or country. The Canadian facility had a total debt capacity of $253 million as of May 2, 2025 and is effective through January 15, 2028. The European facility had a total debt capacity of $565 million as of May 2, 2025 and is effective through December 14, 2026. The Australia and New Zealand facility had a total debt capacity of $271 million as of May 2, 2025 and is effective through April 17, 2027. The Middle East facility had a total debt capacity of $150 million as of May 2, 2025 and is effective through March 14, 2027.

- changed (2025-09-08):
[0001571996-25-000102:note_history:26]
The Company also has two unsecured Singapore facilities, which had a total debt capacity of $254 million as of August 1, 2025 and are effective through July 3, 2026 and July 3, 2027, respectively.
  (was, 2025-06-10, similarity 0.9722):
[0001571996-25-000063:note_history:26]
The Company also has two unsecured Singapore facilities, which have a total debt capacity of $251 million as of May 2, 2025 and are effective through July 3, 2026 and July 3, 2027, respectively.

- added (2025-09-08):
[0001571996-25-000102:note_history:27]
In connection with the asset-based financing facility, fixed-term securitization offerings, and securitization facility discussed above, the Company transfers certain U.S. and European lease and loan payments and associated equipment to SPEs that meet the definition of a VIE and are consolidated, along with the associated debt described above, into the Condensed Consolidated Financial Statements, as the Company is the primary beneficiary of the VIEs. The SPEs are bankruptcy-remote legal entities with separate assets and liabilities. The purpose of the SPEs is to facilitate the funding of customer lease and loan payments and associated equipment in the capital markets.

- changed (2025-09-08):
[0001571996-25-000102:note_history:28]
|  | August 1, 2025 |  | January 31, 2025 |
|  | (in millions) |
| Assets held by consolidated VIEs |  |  |  |
| Other current assets | $ | 147 |  |  | $ | 123 |  |
| Financing receivables, net of allowance |  |  |  |
| Short-term | $ | 3,194 |  |  | $ | 3,262 |  |
| Long-term | $ | 2,738 |  |  | $ | 2,725 |  |
| Property, plant, and equipment, net | $ | 971 |  |  | $ | 984 |  |
| Liabilities held by consolidated VIEs |  |  |  |
| Debt, net of unamortized debt issuance costs |  |  |  |
| Short-term | $ | 4,129 |  |  | $ | 4,598 |  |
| Long-term | $ | 2,201 |  |  | $ | 1,788 |  |
  (was, 2025-06-10, similarity 0.991):
[0001571996-25-000063:note_history:28]
|  | May 2, 2025 |  | January 31, 2025 |
|  | (in millions) |
| Assets held by consolidated VIEs |  |  |  |
| Other current assets | $ | 151 |  |  | $ | 123 |  |
| Financing receivables, net of allowance |  |  |  |
| Short-term | $ | 3,181 |  |  | $ | 3,262 |  |
| Long-term | $ | 2,834 |  |  | $ | 2,725 |  |
| Property, plant, and equipment, net | $ | 984 |  |  | $ | 984 |  |
| Liabilities held by consolidated VIEs |  |  |  |
| Debt, net of unamortized debt issuance costs |  |  |  |
| Short-term | $ | 4,387 |  |  | $ | 4,598 |  |
| Long-term | $ | 2,061 |  |  | $ | 1,788 |  |

- changed (2025-09-08):
[0001571996-25-000102:note_history:29]
Lease and loan payments and associated equipment transferred via securitization through SPEs were $0.8 billion and $1.2 billion for the three months ended August 1, 2025 and August 2, 2024, respectively, and $2.0 billion for both the six months ended August 1, 2025 and August 2, 2024.
  (was, 2025-06-10, similarity 0.8045):
[0001571996-25-000063:note_history:29]
Lease and loan payments and associated equipment transferred via securitization through SPEs were $1.2 billion and $0.8 billion for the three months ended May 2, 2025 and May 3, 2024, respectively.

- changed (2025-09-08):
[0001571996-25-000102:note_history:30]
To manage certain concentrations of customer credit exposure, the Company may sell selected fixed-term customer receivables to unrelated third parties on a periodic basis, without recourse. The amounts of customer receivables sold for this purpose were immaterial for both the six months ended August 1, 2025 and August 2, 2024. The Company’s continuing involvement in these customer receivables is primarily limited to servicing arrangements.
  (was, 2025-06-10, similarity 0.6667):
[0001571996-25-000063:note_history:30]
To manage certain concentrations of customer credit exposure, the Company may sell selected fixed-term customer receivables to unrelated third parties on a periodic basis, without recourse. The amounts of customer receivables sold for this purpose were immaterial for both the three months ended May 2, 2025 and May 3, 2024. The Company’s continuing involvement in these customer receivables is primarily limited to servicing arrangements.

- removed (2025-09-08):
[0001571996-25-000063:note_history:31]
|  |  |  |  |  | Three Months Ended |
|  |  |  |  |  | May 2, 2025 |  |  |  |  |  | May 3, 2024 |  |  |
|  |  |  |  |  | (in millions) |
| Allowance for financing receivable losses: |
| Balances at beginning of period |  |  |  |  | $ | 153 |  |  |  |  |  |  | $ | 170 |  |  |  |  |  |  |  |
| Charge-offs, net of recoveries |  |  |  |  | (10) |  |  |  |  |  |  | (8) |  |  |  |  |  |  |  |
| Provision charged to income statement |  |  |  |  | 1 |  |  |  |  |  |  | 33 |  |  |  |  |  |  |  |
| Balances at end of period |  |  |  |  | $ | 144 |  |  |  |  |  |  | $ | 195 |  |  |  |  |  |  |  |

- removed (2025-09-08):
[0001571996-25-000063:note_history:32]
|  | May 2, 2025 |
|  | (in millions) |
| Fiscal 2026 (remaining nine months) | $ | 2,655 |  |
| Fiscal 2027 | 2,631 |  |
| Fiscal 2028 | 1,307 |  |
| Fiscal 2029 | 628 |  |
| Fiscal 2030 and thereafter | 279 |  |
| Total undiscounted cash flows | 7,500 |  |
| Loans | 4,951 |  |
| Less: Unearned income | (1,062) |  |
| Total customer receivables, gross | $ | 11,389 |  |

- removed (2025-09-08):
[0001571996-25-000063:note_history:33]
|  |  |  | Three Months Ended |
|  |  |  |  |  | May 2, 2025 |  | May 3, 2024 |  |  |
|  |  |  |  |  | (in millions) |
| Income related to lease payments |  |  |  |  | $ | 358 |  |  | $ | 356 |  |  |  |
| Depreciation expense |  |  |  |  | $ | 244 |  |  | $ | 240 |  |  |  |

- removed (2025-09-08):
[0001571996-25-000063:note_history:34]
In connection with the asset-based financing facility, securitization facility, and fixed-term securitization offerings discussed above, the Company transfers certain U.S. and European lease and loan payments and associated equipment to SPEs that meet the definition of a VIE and are consolidated, along with the associated debt described above, into the Condensed Consolidated Financial Statements, as the Company is the primary beneficiary of the VIEs. The SPEs are bankruptcy-remote legal entities with separate assets and liabilities. The purpose of the SPEs is to facilitate the funding of customer lease and loan payments and associated equipment in the capital markets.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-09-08):
[0001571996-25-000102:note_history:35]
|  | August 1, 2025 |  | January 31, 2025 |
|  | (in millions) |
| Senior Notes | $ | 19,073 |  |  | $ | 15,073 |  |
| Legacy Notes | 952 |  |  | 952 |  |
| DFS Debt (Note 4) | 8,815 |  |  | 8,711 |  |
| Other | 89 |  |  | 52 |  |
| Total debt, principal amount | 28,929 |  |  | 24,788 |  |
| Unamortized discount, net of unamortized premium | (110) |  |  | (110) |  |
| Debt issuance costs | (130) |  |  | (111) |  |
| Total debt, carrying value | $ | 28,689 |  |  | $ | 24,567 |  |
| Total short-term debt, carrying value | $ | 7,154 |  |  | $ | 5,204 |  |
| Total long-term debt, carrying value | $ | 21,535 |  |  | $ | 19,363 |  |
  (was, 2025-06-10, similarity 0.9914):
[0001571996-25-000063:note_history:35]
|  | May 2, 2025 |  | January 31, 2025 |
|  | (in millions) |
| Senior Notes | $ | 19,073 |  |  | $ | 15,073 |  |
| Legacy Notes | 952 |  |  | 952 |  |
| DFS Debt (Note 4) | 8,927 |  |  | 8,711 |  |
| Other | 79 |  |  | 52 |  |
| Total debt, principal amount | 29,031 |  |  | 24,788 |  |
| Unamortized discount, net of unamortized premium | (113) |  |  | (110) |  |
| Debt issuance costs | (137) |  |  | (111) |  |
| Total debt, carrying value | $ | 28,781 |  |  | $ | 24,567 |  |
| Total short-term debt, carrying value | $ | 4,845 |  |  | $ | 5,204 |  |
| Total long-term debt, carrying value | $ | 23,936 |  |  | $ | 19,363 |  |

- added (2025-09-08):
[0001571996-25-000102:note_history:36]
During the six months ended August 1, 2025, the Company issued $1.0 billion principal amount of 4.75% Senior Notes due April 2028, $1.0 billion principal amount of 5.00% Senior Notes due April 2030, $1.0 billion principal amount of 5.30% Senior Notes due April 2032, and $1.0 billion principal amount of 5.50% Senior Notes due April 2035. The Company utilized the net proceeds of the issuances for general corporate purposes.

- changed (2025-09-08):
[0001571996-25-000102:note_history:37]
Senior Notes — The Company completed offerings of multiple series of senior notes which were issued on June 1, 2016, June 22, 2016, March 20, 2019, April 9, 2020, December 13, 2021, January 24, 2023, March 18, 2024, October 8, 2024, and April 1, 2025 in aggregate principal amounts of $20.0 billion, $3.3 billion, $4.5 billion, $2.3 billion, $2.3 billion, $2.0 billion, $1.0 billion, $1.5 billion, and $4.0 billion, respectively (collectively, the “Senior Notes”). The Senior Notes currently outstanding have maturity dates ranging from 2026 through 2051. Interest rates on these borrowings are fixed, ranging from 3.38% to 8.35% per annum, and interest is payable semiannually.
  (was, 2025-06-10, similarity 0.9992):
[0001571996-25-000063:note_history:37]
Senior Notes — The Company completed offerings of multiple series of senior notes which were issued on June 1, 2016, June 22, 2016, March 20, 2019, April 9, 2020, December 13, 2021, January 24, 2023, March 18, 2024, October 8, 2024, and April 1, 2025 in aggregate principal amounts of $20.0 billion, $3.3 billion, $4.5 billion, $2.3 billion, $2.3 billion, $2.0 billion, $1.0 billion, $1.5 billion, and $4.0 billion respectively (collectively, the “Senior Notes”). The Senior Notes currently outstanding have maturity dates ranging from 2026 through 2051. Interest rates on these borrowings are fixed, ranging from 3.38% to 8.35% per annum, and interest is payable semiannually.

- changed (2025-09-08):
[0001571996-25-000102:note_history:38]
As of August 1, 2025, the Company had no outstanding borrowings under the revolving credit facility.
  (was, 2025-06-10, similarity 0.9626):
[0001571996-25-000063:note_history:38]
As of May 2, 2025, the Company had no outstanding borrowings under the revolving credit facility.

- changed (2025-09-08):
[0001571996-25-000102:note_history:39]
Commercial Paper Program — The Company maintains a commercial paper program under which the Company may issue unsecured notes in a maximum aggregate face amount of $5.0 billion outstanding at any time, with maturities of up to 397 days from the date of issuance. The notes are sold on customary terms in the U.S. commercial paper market on a private placement basis. The proceeds of the notes are used for general corporate purposes. As of August 1, 2025, the Company had no outstanding issuances under the commercial paper program.
  (was, 2025-06-10, similarity 0.9914):
[0001571996-25-000063:note_history:39]
Commercial Paper Program — The Company maintains a commercial paper program under which the Company may issue unsecured notes in a maximum aggregate face amount of $5.0 billion outstanding at any time, with maturities of up to 397 days from the date of issuance. The notes are sold on customary terms in the U.S. commercial paper market on a private placement basis. The proceeds of the notes are used for general corporate purposes. As of May 2, 2025, the Company had no outstanding issuances under the commercial paper program.

- changed (2025-09-08):
[0001571996-25-000102:note_history:40]
Covenants — The credit agreement governing the revolving credit facility and the indentures governing the Senior Notes and the Legacy Notes impose various limitations, subject to exceptions, on creating certain liens and entering into sale and lease-back transactions. The foregoing credit agreement and indentures contain customary events of default, and the revolving credit facility is subject to an interest coverage ratio covenant that is tested at the end of each fiscal quarter with respect to the Company’s preceding four fiscal quarters. The Company was in compliance with this financial covenant as of August 1, 2025.
  (was, 2025-06-10, similarity 0.9927):
[0001571996-25-000063:note_history:40]
Covenants — The credit agreement governing the revolving credit facility and the indentures governing the Senior Notes and the Legacy Notes impose various limitations, subject to exceptions, on creating certain liens and entering into sale and lease-back transactions. The foregoing credit agreement and indentures contain customary events of default, and the revolving credit facility is subject to an interest coverage ratio covenant that is tested at the end of each fiscal quarter with respect to the Company’s preceding four fiscal quarters. The Company was in compliance with this financial covenant as of May 2, 2025.

- changed (2025-09-08):
[0001571996-25-000102:note_history:41]
The following table presents the aggregate future maturities of the Company’s debt as of August 1, 2025, excluding associated carrying value adjustments, for the periods indicated:
  (was, 2025-06-10, similarity 0.9798):
[0001571996-25-000063:note_history:41]
The following table presents the aggregate future maturities of the Company’s debt as of May 2, 2025, excluding associated carrying value adjustments, for the periods indicated:

- added (2025-09-08):
[0001571996-25-000102:note_history:42]
|  | August 1, 2025 |
|  | (in millions) |
| Fiscal 2026 (remaining six months) | $ | 2,080 |  |
| Fiscal 2027 | 8,451 |  |
| Fiscal 2028 | 2,343 |  |
| Fiscal 2029 | 2,460 |  |
| Fiscal 2030 | 3,059 |  |
| Thereafter | 10,536 |  |
| Total maturities, principal amount | $ | 28,929 |  |

- removed (2025-09-08):
[0001571996-25-000063:note_history:43]
During the three months ended May 2, 2025, the Company issued $1.0 billion principal amount of 4.75% Senior Notes due April 2028, $1.0 billion principal amount of 5.00% Senior Notes due April 2030, $1.0 billion principal amount of 5.30% Senior Notes due April 2032, and $1.0 billion principal amount of 5.50% Senior Notes due April 2035. The Company utilized the net proceeds of the issuance for general corporate purposes.

- removed (2025-09-08):
[0001571996-25-000063:note_history:44]
|  | May 2, 2025 |
|  | (in millions) |
| Fiscal 2026 (remaining nine months) | $ | 4,106 |  |
| Fiscal 2027 | 7,180 |  |
| Fiscal 2028 | 1,696 |  |
| Fiscal 2029 | 2,470 |  |
| Fiscal 2030 | 3,053 |  |
| Thereafter | 10,526 |  |
| Total maturities, principal amount | $ | 29,031 |  |


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-09-08):
[0001571996-25-000102:note_history:45]
|  | August 1, 2025 |  | January 31, 2025 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Notes | $ | 18.9 |  |  | $ | 19.3 |  |  | $ | 15.0 |  |  | $ | 15.0 |  |
| Legacy Notes | $ | 0.9 |  |  | $ | 1.0 |  |  | $ | 0.9 |  |  | $ | 1.0 |  |
| DFS Debt | $ | 8.8 |  |  | $ | 8.5 |  |  | $ | 8.7 |  |  | $ | 8.5 |  |
  (was, 2025-06-10, similarity 0.9853):
[0001571996-25-000063:note_history:45]
|  | May 2, 2025 |  | January 31, 2025 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Notes | $ | 18.9 |  |  | $ | 18.9 |  |  | $ | 15.0 |  |  | $ | 15.0 |  |
| Legacy Notes | $ | 0.9 |  |  | $ | 1.0 |  |  | $ | 0.9 |  |  | $ | 1.0 |  |
| DFS Debt | $ | 8.9 |  |  | $ | 8.7 |  |  | $ | 8.7 |  |  | $ | 8.5 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-09-08):
[0001571996-25-000102:note_history:46]
|  | August 1, 2025 |  | January 31, 2025 |
| DFS debt | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing facility | $ | 3,001 |  |  | $ | 3,018 |  |
| Fixed-term securitization offerings | 2,685 |  |  | 2,756 |  |
| Total DFS U.S. debt, principal amount | 5,686 |  |  | 5,774 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 657 |  |  | 624 |  |
| Other borrowings | 760 |  |  | 754 |  |
| Dell Bank senior unsecured eurobonds | 1,712 |  |  | 1,559 |  |
| Total DFS international debt, principal amount | 3,129 |  |  | 2,937 |  |
| Total DFS debt, principal amount | $ | 8,815 |  |  | $ | 8,711 |  |
| Total short-term DFS debt | $ | 4,624 |  |  | $ | 5,175 |  |
| Total long-term DFS debt | $ | 4,191 |  |  | $ | 3,536 |  |
  (was, 2025-06-10, similarity 0.993):
[0001571996-25-000063:note_history:46]
|  | May 2, 2025 |  | January 31, 2025 |
| DFS debt | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing facility | $ | 2,606 |  |  | $ | 3,018 |  |
| Fixed-term securitization offerings | 3,154 |  |  | 2,756 |  |
| Total DFS U.S. debt, principal amount | 5,760 |  |  | 5,774 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 702 |  |  | 624 |  |
| Other borrowings | 772 |  |  | 754 |  |
| Dell Bank senior unsecured eurobonds | 1,693 |  |  | 1,559 |  |
| Total DFS international debt, principal amount | 3,167 |  |  | 2,937 |  |
| Total DFS debt, principal amount | $ | 8,927 |  |  | $ | 8,711 |  |
| Total short-term DFS debt | $ | 4,809 |  |  | $ | 5,175 |  |
| Total long-term DFS debt | $ | 4,118 |  |  | $ | 3,536 |  |

- changed (2025-09-08):
[0001571996-25-000102:note_history:47]
|  | August 1, 2025 |  | January 31, 2025 |
|  | (in millions) |
| Senior Notes | $ | 19,073 |  |  | $ | 15,073 |  |
| Legacy Notes | 952 |  |  | 952 |  |
| DFS Debt (Note 4) | 8,815 |  |  | 8,711 |  |
| Other | 89 |  |  | 52 |  |
| Total debt, principal amount | 28,929 |  |  | 24,788 |  |
| Unamortized discount, net of unamortized premium | (110) |  |  | (110) |  |
| Debt issuance costs | (130) |  |  | (111) |  |
| Total debt, carrying value | $ | 28,689 |  |  | $ | 24,567 |  |
| Total short-term debt, carrying value | $ | 7,154 |  |  | $ | 5,204 |  |
| Total long-term debt, carrying value | $ | 21,535 |  |  | $ | 19,363 |  |
  (was, 2025-06-10, similarity 0.9914):
[0001571996-25-000063:note_history:47]
|  | May 2, 2025 |  | January 31, 2025 |
|  | (in millions) |
| Senior Notes | $ | 19,073 |  |  | $ | 15,073 |  |
| Legacy Notes | 952 |  |  | 952 |  |
| DFS Debt (Note 4) | 8,927 |  |  | 8,711 |  |
| Other | 79 |  |  | 52 |  |
| Total debt, principal amount | 29,031 |  |  | 24,788 |  |
| Unamortized discount, net of unamortized premium | (113) |  |  | (110) |  |
| Debt issuance costs | (137) |  |  | (111) |  |
| Total debt, carrying value | $ | 28,781 |  |  | $ | 24,567 |  |
| Total short-term debt, carrying value | $ | 4,845 |  |  | $ | 5,204 |  |
| Total long-term debt, carrying value | $ | 23,936 |  |  | $ | 19,363 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-09-08):
[0001571996-25-000102:note_history:48]
The following table presents the aggregate future maturities of the Company’s debt as of August 1, 2025, excluding associated carrying value adjustments, for the periods indicated:
  (was, 2025-06-10, similarity 0.9798):
[0001571996-25-000063:note_history:48]
The following table presents the aggregate future maturities of the Company’s debt as of May 2, 2025, excluding associated carrying value adjustments, for the periods indicated:

- added (2025-09-08):
[0001571996-25-000102:note_history:49]
|  | August 1, 2025 |
|  | (in millions) |
| Fiscal 2026 (remaining six months) | $ | 2,080 |  |
| Fiscal 2027 | 8,451 |  |
| Fiscal 2028 | 2,343 |  |
| Fiscal 2029 | 2,460 |  |
| Fiscal 2030 | 3,059 |  |
| Thereafter | 10,536 |  |
| Total maturities, principal amount | $ | 28,929 |  |

- removed (2025-09-08):
[0001571996-25-000063:note_history:50]
|  | May 2, 2025 |
|  | (in millions) |
| Fiscal 2026 (remaining nine months) | $ | 4,106 |  |
| Fiscal 2027 | 7,180 |  |
| Fiscal 2028 | 1,696 |  |
| Fiscal 2029 | 2,470 |  |
| Fiscal 2030 | 3,053 |  |
| Thereafter | 10,526 |  |
| Total maturities, principal amount | $ | 29,031 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-09-08):
[0001571996-25-000102:note_history:51]
|  | Three Months Ended |  | Six Months Ended |
|  | August 1, 2025 |  | August 2, 2024 |  | August 1, 2025 |  | August 2, 2024 |  |  |
|  | (in millions) |
| Net revenue: |  |  |  |  |  |  |  |  |  |
| Infrastructure Solutions Group: |  |  |  |  |  |  |  |  |  |
| Servers and networking | $ | 12,944 |  |  | $ | 7,672 |  |  | $ | 19,265 |  |  | $ | 13,138 |  |  |  |
| Storage | 3,856 |  |  | 3,974 |  |  | 7,852 |  |  | 7,735 |  |  |  |
| Total ISG net revenue | $ | 16,800 |  |  | $ | 11,646 |  |  | $ | 27,117 |  |  | $ | 20,873 |  |  |  |
| Client Solutions Group: |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 10,781 |  |  | $ | 10,556 |  |  | $ | 21,827 |  |  | $ | 20,710 |  |  |  |
| Consumer | 1,722 |  |  | 1,858 |  |  | 3,185 |  |  | 3,671 |  |  |  |
| Total CSG net revenue | $ | 12,503 |  |  | $ | 12,414 |  |  | $ | 25,012 |  |  | $ | 24,381 |  |  |  |
  (was, 2025-06-10, similarity 0.7687):
[0001571996-25-000063:note_history:51]
|  |  |  | Three Months Ended |
|  |  |  |  |  | May 2, 2025 |  | May 3, 2024 |  |  |
|  |  |  |  |  | (in millions) |
| Net revenue: |  |  |  |  |  |  |  |  |  |
| Infrastructure Solutions Group: |  |  |  |  |  |  |  |  |  |
| Servers and networking |  |  |  |  | $ | 6,321 |  |  | $ | 5,466 |  |  |  |
| Storage |  |  |  |  | 3,996 |  |  | 3,761 |  |  |  |
| Total ISG net revenue |  |  |  |  | $ | 10,317 |  |  | $ | 9,227 |  |  |  |
| Client Solutions Group: |  |  |  |  |  |  |  |  |  |
| Commercial |  |  |  |  | $ | 11,046 |  |  | $ | 10,154 |  |  |  |
| Consumer |  |  |  |  | 1,463 |  |  | 1,813 |  |  |  |
| Total CSG net revenue |  |  |  |  | $ | 12,509 |  |  | $ | 11,967 |  |  |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-09-08):
[0001571996-25-000102:note_history:52]
|  | Three Months Ended |  | Six Months Ended |
|  | August 1, 2025 |  | August 2, 2024 |  | August 1, 2025 |  | August 2, 2024 |
|  | (in millions) |
| Deferred revenue: |  |  |  |  |  |  |  |
| Deferred revenue at beginning of period | $ | 26,320 |  |  | $ | 28,150 |  |  | $ | 25,965 |  |  | $ | 29,145 |  |
| Revenue deferrals | 4,972 |  |  | 4,920 |  |  | 10,427 |  |  | 9,389 |  |
| Revenue recognized | (5,111) |  |  | (5,358) |  |  | (10,211) |  |  | (10,822) |  |
| Deferred revenue at end of period | $ | 26,181 |  |  | $ | 27,712 |  |  | $ | 26,181 |  |  | $ | 27,712 |  |
| Short-term deferred revenue | $ | 13,759 |  |  | $ | 14,853 |  |  | $ | 13,759 |  |  | $ | 14,853 |  |
| Long-term deferred revenue | $ | 12,422 |  |  | $ | 12,859 |  |  | $ | 12,422 |  |  | $ | 12,859 |  |
  (was, 2025-06-10, similarity 0.742):
[0001571996-25-000063:note_history:52]
|  |  |  | Three Months Ended |
|  |  |  |  |  | May 2, 2025 |  | May 3, 2024 |
|  |  |  |  |  | (in millions) |
| Deferred revenue: |  |  |  |  |  |  |  |
| Deferred revenue at beginning of period |  |  |  |  | $ | 25,965 |  |  | $ | 29,145 |  |
| Revenue deferrals |  |  |  |  | 5,455 |  |  | 4,469 |  |
| Revenue recognized |  |  |  |  | (5,100) |  |  | (5,464) |  |
| Deferred revenue at end of period |  |  |  |  | $ | 26,320 |  |  | $ | 28,150 |  |
| Short-term deferred revenue |  |  |  |  | $ | 13,907 |  |  | $ | 15,034 |  |
| Long-term deferred revenue |  |  |  |  | $ | 12,413 |  |  | $ | 13,116 |  |

- changed (2025-09-08):
[0001571996-25-000102:note_history:53]
Remaining Performance Obligations — Remaining performance obligations represent the aggregate amount of the transaction price allocated to performance obligations not delivered, or partially undelivered, as of the end of the reporting period. Remaining performance obligations include deferred revenue plus unbilled amounts not yet recorded in deferred revenue. The value of the transaction price allocated to remaining performance obligations as of August 1, 2025 was approximately $44 billion. The Company expects to recognize approximately 65% of remaining performance obligations as revenue in the next twelve months, 17% in the following twelve months, and the remainder thereafter.
  (was, 2025-06-10, similarity 0.9934):
[0001571996-25-000063:note_history:53]
Remaining Performance Obligations — Remaining performance obligations represent the aggregate amount of the transaction price allocated to performance obligations not delivered, or partially undelivered, as of the end of the reporting period. Remaining performance obligations include deferred revenue plus unbilled amounts not yet recorded in deferred revenue. The value of the transaction price allocated to remaining performance obligations as of May 2, 2025 was approximately $49 billion. The Company expects to recognize approximately 67% of remaining performance obligations as revenue in the next twelve months, 16% in the following twelve months, and the remainder thereafter.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2025-09-08):
[0001571996-25-000102:note_history:54]
SUBSEQUENT EVENTS 
There were no known events occurring after August 1, 2025 and up until the date of issuance of this report that would materially affect the information presented herein.
  (was, 2025-06-10, similarity 0.9807):
[0001571996-25-000063:note_history:54]
SUBSEQUENT EVENTS 
There were no known events occurring after May 2, 2025 and up until the date of issuance of this report that would materially affect the information presented herein.
