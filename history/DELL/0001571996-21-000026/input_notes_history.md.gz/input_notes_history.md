# DELL note change history — 0001571996-20-000051 → 0001571996-21-000026


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2021-06-07):
[0001571996-21-000026:note_history:1]
Class Actions Related to the Class V Transaction — Four purported stockholders brought putative class action complaints arising out of the Class V transaction described in Note 1 of the Notes to the Condensed Consolidated Financial Statements.  The actions were captioned Hallandale Beach Police and Fire Retirement Plan v. Michael Dell et al. (Civil Action No. 2018-0816-JTL), Howard Karp v. Michael Dell et al. (Civil Action No. 2019-0032-JTL), Miramar Police Officers’ Retirement Plan v. Michael Dell et al. (Civil Action No. 2019-0049-JTL), and Steamfitters Local 449 Pension Plan v. Michael Dell et al. (Civil Action No. 2019-0115-JTL).  The four actions were consolidated in the Delaware Chancery Court into In Re Dell Class V Litigation (Consol. C.A. No. 2018-0816-JTL), which names as defendants the Company’s board of directors and certain stockholders of the Company, including Michael S. Dell.  The plaintiffs generally allege that the defendants breached their fiduciary duties to the former holders of Class V Common Stock in connection with the Class V transaction by allegedly causing the Company to enter into a transaction that favored the interests of the controlling stockholders at the expense of such former stockholders.  The plaintiffs seek, among other remedies, a judicial declaration that the defendants breached their fiduciary duties and an award of damages, fees, and costs.  The plaintiffs filed an amended complaint in August 2019 making substantially similar allegations to those described above.  The defendants filed a motion to dismiss the action in September 2019.  The court denied the motion in June 2020 and the case is currently in the discovery phase.  Trial is currently scheduled to begin on May 3, 2022.
  (was, 2020-12-07, similarity 0.9666):
[0001571996-20-000051:note_history:1]
Class Actions Related to the Class V Transaction — Four purported stockholders brought putative class action complaints arising out of the Class V transaction described in Note 1of the Notes to the Condensed Consolidated Financial Statements.  The actions were captioned Hallandale Beach Police and Fire Retirement Plan v. Michael Dell et al. (Civil Action No. 2018-0816-JTL), Howard Karp v. Michael Dell et al. (Civil Action No. 2019-0032-JTL), Miramar Police Officers’ Retirement Plan v. Michael Dell et al. (Civil Action No. 2019-0049-JTL), and Steamfitters Local 449 Pension Plan v. Michael Dell et al. (Civil Action No. 2019-0115-JTL).  The four actions were consolidated in the Delaware Chancery Court into In Re Dell Class V Litigation (Consol. C.A. No. 2018-0816-JTL), which names as defendants the Company’s board of directors and certain stockholders of the Company, including Michael S. Dell.  The plaintiffs generally allege that the defendants breached their fiduciary duties to the former holders of Class V Common Stock in connection with the Class V transaction by allegedly causing the Company to enter into a transaction that favored the interests of the controlling stockholders at the expense of such former stockholders.  The plaintiffs seek, among other remedies, a judicial declaration that the defendants breached their fiduciary duties and an award of damages, fees, and costs.  The plaintiffs filed an amended complaint in August 2019 making substantially similar allegations to those described above.  The defendants filed a motion to dismiss the action in September 2019.  The court denied the motion in June 2020 and the case has now moved to discovery.

- added (2021-06-07):
[0001571996-21-000026:note_history:2]
Patent Litigation — On April 25, 2019, Cirba Inc. and Cirba IP, Inc. (collectively, “Cirba”) filed a lawsuit against VMware, Inc. in the United States District Court for the District of Delaware (the “Delaware Court”), alleging two patent infringement claims and three trademark infringement-related claims (the “First Action”).  Following a hearing on August 6, 2019, the Delaware Court denied Cirba’s preliminary injunction motion.  On August 20, 2019, VMware, Inc. filed counterclaims against Cirba, asserting among other claims that Cirba is infringing four VMware, Inc. patents.  The Delaware Court severed those claims from the January 2020 trial on Cirba’s claims.  On January 24, 2020, a jury returned a verdict that VMware, Inc. had willfully infringed Cirba’s two patents and awarded approximately $237 million in damages.  As to Cirba’s trademark-related claims, the jury found that VMware, Inc. was not liable.  A total of $237 million was accrued for the First Action as of January 31, 2020, which reflected the estimated losses that were considered both probable and reasonably estimable at that time.  The amount accrued for this matter was included in Accrued and other in the Consolidated Statements of Financial Position as of January 31, 2020, and the charge was classified in Selling, general and administrative in the Consolidated Statements of Income (Loss) for the fiscal year ended January 31, 2020.  On March 9, 2020, the parties filed post-trial motions in the First Action.  On December 21, 2020, the Delaware Court granted VMware, Inc.’s request for a new trial based, in part, on Cirba’s Inc.’s lack of standing, set aside the verdict and damages award, and denied Cirba’s post-trial motions (the “Post-Trial Order”).

- added (2021-06-07):
[0001571996-21-000026:note_history:3]
On October 22, 2019, VMware, Inc. filed a separate lawsuit against Cirba in the United States District Court for the Eastern District of Virginia for infringing four additional VMware, Inc. patents (The “Second Action”).  The Virginia court transferred the Second Action to the Delaware Court on February 25, 2020.  On March 23, 2020, Cirba filed a counterclaim asserting one additional patent against VMware, Inc.  The Delaware Court consolidated the First and Second Actions and ordered a consolidated trial on all of the parties’ patent infringement claims and counterclaims.  On May 3, 2021, the Court denied Cirba’s motion to certify the Post-Trial Order to enable an interlocutory appeal to the United States Court of Appeals for the Federal Circuit.  Also, on May 3, 2021, the Court granted Cirba’s motion for leave to assert an additional patent against VMware, Inc. Separately, in February 2021, the U.S. Patent and Trademark Office (“PTO”) granted VMware, Inc.’s ex parte reexamination request as to the ‘687 patent (which was at issue in the January 2020 trial and subject to the Court’s new trial order).  In addition, in May 2021, the PTO’s Patent Trial and Appeal Board instituted Inter Partes Review (“IPR”) of the ‘492 patent in response to VMware, Inc.’s IPR petition.  As of January 29, 2021, VMware, Inc. reassessed its estimated loss accrual for the First Action based on the Post-Trial Order and determined that a loss was no longer probable and reasonably estimable with respect to the consolidated First and Second Actions.  Accordingly, the estimated loss accrual recognized during the fiscal year ended January 31, 2020 totaling $237 million was adjusted to $0 with the credit included in Selling, general, and administrative in the Consolidated Statements of Income (Loss) for the fiscal year ended January 29, 2021.  VMware, Inc. has reported that is unable at this time to assess whether, or to what extent, it may be found liable and, if found liable, what the damages may be. VMware, Inc. intends to vigorously defend itself in this matter.

- changed (2021-06-07):
[0001571996-21-000026:note_history:4]
Other Litigation — Dell does not currently anticipate that any of these matters will have a material adverse effect on its business, financial condition, results of operations, or cash flows.
  (was, 2020-12-07, similarity 0.6101):
[0001571996-20-000051:note_history:4]
Other Litigation — The various legal proceedings in which Dell is involved include commercial and intellectual property litigation.  Dell does not currently anticipate that any of these matters will have a material adverse effect on its business, financial condition, results of operations, or cash flows.

- added (2021-06-07):
[0001571996-21-000026:note_history:5]
In accordance with the relevant accounting guidance, the Company provides disclosures of matters where it is at least reasonably possible that the Company could experience a material loss exceeding the amounts already accrued for these or other proceedings or matters.  In addition, the Company also discloses matters based on its consideration of other matters and qualitative factors, including the experience of other companies in the industry, and investor, customer, and employee relations considerations.  As of April 30, 2021, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for these or other proceedings or matters has been incurred.  However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company’s business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters.  Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company’s business, financial condition, results of operations, or cash flows will depend on a number of variables, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.

- changed (2021-06-07):
[0001571996-21-000026:note_history:6]
In the ordinary course of business, the Company enters into contractual arrangements under which it may agree to indemnify other parties for losses incurred from certain events as defined in the relevant contract, such as litigation, regulatory penalties, or claims relating to past performance.  Such indemnification obligations may not be subject to maximum loss clauses.  Historically, payments related to these indemnifications have not been material to the Company.
  (was, 2020-12-07, similarity 0.7167):
[0001571996-20-000051:note_history:6]
In the ordinary course of business, the Company enters into contractual arrangements under which it may agree to indemnify the third party to such arrangements from any losses incurred relating to the services it performs on behalf of the Company or for losses arising from certain events as defined in the particular contract, such as litigation or claims relating to past performance.  Such indemnification obligations may not be subject to maximum loss clauses.  Historically, payments related to these indemnifications have not been material to the Company.

- removed (2021-06-07):
[0001571996-20-000051:note_history:7]
Patent Litigation — On April 25, 2019, Cirba Inc. (“Cirba”) filed a lawsuit against VMware, Inc. in the United States District Court for the District of Delaware, alleging two patent infringement claims and three trademark infringement-related claims.  On May 6, 2019, Cirba filed a motion seeking a preliminary injunction tied to one of the two patents it alleges VMware, Inc. infringes.  Following a hearing on August 6, 2019, the Court denied Cirba’s preliminary injunction motion and set the case for trial in mid-January 2020.  On August 20, 2019, VMware, Inc. filed counterclaims against Cirba, asserting among other claims that Cirba is infringing four VMware, Inc. patents.  The Delaware Court severed those claims from the January 2020 trial on Cirba’s claims, and the trial on VMware, Inc.’s patent claims is currently set for September 2021.  The trial on Cirba’s claims in the Delaware court was completed on January 23, 2020, and on January 24, 2020, the jury returned a verdict finding that VMware, Inc. willfully infringed the two asserted patents and awarding approximately $237 million in damages.  The jury further found that VMware, Inc. was not liable on Cirba’s trademark infringement-related claims.  A total of $237 million was accrued for the Delaware action, which reflects the estimated losses that are considered both probable and reasonably estimable at this time.  The parties filed the post-trial motions in which VMware, Inc. moved to set aside the verdict and reduce the damages award, and Cirba moved for a permanent injunction, enhanced damages, setting of an ongoing royalty rate, and an award of pre-judgment and post-judgment interest and supplemental damages.  A hearing was held in the Delaware court on those motions on May 15, 2020, and the Delaware court has taken those motions under advisement.  VMware, Inc. intends to vigorously defend itself in this matter, including, if necessary, via an appeal.  Final resolution of this matter could be materially different from the amount accrued.  The amount accrued for this matter is included in Accrued and other in the Condensed Consolidated Statements of Financial Position as of October 30, 2020 and January 31, 2020, and the charge was classified in Selling, general and administrative in the Consolidated Statements of Income (Loss) during the fiscal year ended January 31, 2020.

- removed (2021-06-07):
[0001571996-20-000051:note_history:8]
On October 22, 2019, VMware, Inc. filed a separate patent infringement lawsuit against Cirba in the United States District Court for the Eastern District of Virginia, asserting that Cirba infringes four additional VMware, Inc. patents.  The Virginia court transferred these patent claims to Delaware.  On March 23, 2020, Cirba filed a counterclaim asserting one additional patent against VMware, Inc.  VMware, Inc. intends to vigorously defend itself in this matter.

- removed (2021-06-07):
[0001571996-20-000051:note_history:9]
As of October 30, 2020, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for these or other proceedings or matters has been incurred.  However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company’s business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters.  Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company’s business, financial condition, results of operations, or cash flows will depend on a number of variables, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: no_current_note, score: 0.0

- removed (2021-06-07):
[0001571996-20-000051:note_history:10]
NOTE 2 — INTERIM UPDATE TO SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES

- removed (2021-06-07):
[0001571996-20-000051:note_history:11]
As discussed in Note 1 of the Notes to the Condensed Consolidated Financial Statements, the Company adopted the new CECL standard as of February 1, 2020 using the modified retrospective method.  The new impairment methodology for measurement of credit losses on financial instruments reflects expected credit losses and requires consideration of a broader range of reasonable and supportable information to inform credit loss estimates.  Additionally, the Company adopted the new cloud computing standard during the three months ended May 1, 2020 using the prospective method.  In a cloud-computing hosting arrangement hosted by a vendor that is a service contract, certain implementation costs should be capitalized and amortized over the term of the arrangement.  The following accounting policies have been updated as part of the adoption of the new standards.

- removed (2021-06-07):
[0001571996-20-000051:note_history:12]
Allowance for Expected Credit Losses — The Company recognizes an allowance for losses on accounts receivable in an amount equal to the current expected credit losses.  The estimation of the allowance is based on an analysis of historical loss experience, current receivables aging, and management’s assessment of current conditions and reasonable and supportable expectation of future conditions, as well as an assessment of specific identifiable customer accounts considered at risk or uncollectible.  The Company assesses collectibility by pooling receivables where similar characteristics exist and evaluates receivables individually when specific customer balances no longer share those risk characteristics and are considered at risk or uncollectible.  The expense associated with the allowance for expected credit losses is recognized in selling, general, and administrative expenses.

- removed (2021-06-07):
[0001571996-20-000051:note_history:13]
Allowance for Financing Receivables Losses — The Company recognizes an allowance for losses on financing receivables in an amount equal to the probable losses net of recoveries.  The allowance for losses is determined based on various factors, including lifetime expected losses determined using macroeconomic forecast assumptions and management judgments applicable to and through the expected life of the portfolios as well as past due receivables, receivable type, and customer risk profile.  Both fixed and revolving receivable loss rates are affected by macroeconomic conditions, including the level of gross domestic product (“GDP”) growth, the level of commercial capital equipment investment, unemployment rates, and the credit quality of the borrower.

- removed (2021-06-07):
[0001571996-20-000051:note_history:14]
Customer account principal and interest are charged to the allowance for losses when an account is deemed to be uncollectible or generally when the account is 180 days delinquent.  While the Company does not generally place financing receivables on non-accrual status during the delinquency period, accrued interest is included in the allowance for loss calculation and, therefore, the Company is adequately reserved in the event of charge off.  Recoveries on receivables previously charged off as uncollectible are recorded to the allowance for financing receivables losses.  The expense associated with the allowance for financing receivables losses is recognized as cost of net revenue.

- removed (2021-06-07):
[0001571996-20-000051:note_history:15]
Capitalized Software Development Costs — The Company capitalizes certain internal and external costs to acquire or create internal use software which are incurred subsequent to the completion of the preliminary project stage.  Development costs are generally amortized on a straight-line basis over five years.  Costs associated with maintenance and minor enhancements to the features and functionality of the Company’s website are expensed as incurred.


## dell:CreditLossFinancialInstrumentLeasesDebtVariableInterestEntitiesAndCustomerReceivablesSalesTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-06-07):
[0001571996-21-000026:note_history:16]
The Company offers or arranges various financing options, services, and alternative payment structures for its customers in North America, Europe, Australia, and New Zealand through Dell Financial Services and its affiliates (“DFS”).  The Company also arranges financing for some of its customers in various countries where DFS does not currently operate as a captive enterprise.  The key activities of DFS include originating, collecting, and servicing customer financing arrangements primarily related to the purchase or use of Dell Technologies products and services.  In some cases, DFS also offers financing on the purchase of third-party technology products that complement the Dell Technologies portfolio of products and services.  New financing originations were $1.9 billion and $1.8 billion for the three months ended April 30, 2021 and May 1, 2020, respectively.
  (was, 2020-12-07, similarity 0.924):
[0001571996-20-000051:note_history:16]
The Company offers or arranges various financing options, services, and alternative payment structures for its customers in North America, Europe, Australia, and New Zealand through Dell Financial Services and its affiliates (“DFS”).  The Company also arranges financing for some of its customers in various countries where DFS does not currently operate as a captive enterprise.  The key activities of DFS include originating, collecting, and servicing customer financing arrangements primarily related to the purchase or use of Dell Technologies products and services.  In some cases, DFS also offers financing on the purchase of third-party technology products that complement the Dell Technologies portfolio of products and services.  New financing originations were $2.1 billion and $2.0 billion for the three months ended October 30, 2020 and November 1, 2019, respectively, and $6.5 billion and $5.7 billion for the nine months ended October 30, 2020 and November 1, 2019, respectively.

- changed (2021-06-07):
[0001571996-21-000026:note_history:17]
Fixed-term leases and loans — The Company enters into financing arrangements with customers who seek lease financing for equipment.  Pursuant to the current lease accounting standard effective February 2, 2019, new DFS leases are classified as sales-type leases, direct financing leases, or operating leases.  Direct financing leases are immaterial.  Leases that commenced prior to the effective date of the current lease accounting standard continue to be accounted for under previous lease accounting guidance.  Leases with business customers have fixed terms of generally two to four years.
  (was, 2020-12-07, similarity 0.793):
[0001571996-20-000051:note_history:17]
Fixed-term leases and loans — The Company enters into financing arrangements with customers who seek lease financing for equipment.  Pursuant to the current lease accounting standard effective February 2, 2019, new DFS leases are classified as sales-type leases, direct financing leases, or operating leases.  When the terms of the DFS lease transfer control of the underlying asset to the lessee, the contract is typically classified as a sales-type lease.  Direct financing leases are immaterial.  All other new DFS leases are classified as operating leases.  Leases that commenced prior to the effective date of the current lease accounting standard continue to be accounted for under previous lease accounting guidance.  Leases with business customers have fixed terms of generally two to four years.

- changed (2021-06-07):
[0001571996-21-000026:note_history:18]
|  | April 30, 2021 |  | January 29, 2021 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Financing receivables, net: |  |  |  |  |  |  |  |  |  |  |  |
| Customer receivables, gross (a) | $ | 752 |  |  | $ | 9,438 |  |  | $ | 10,190 |  |  | $ | 796 |  |  | $ | 9,595 |  |  | $ | 10,391 |  |
| Allowances for losses | (139) |  |  | (177) |  |  | (316) |  |  | (148) |  |  | (173) |  |  | (321) |  |
| Customer receivables, net | 613 |  |  | 9,261 |  |  | 9,874 |  |  | 648 |  |  | 9,422 |  |  | 10,070 |  |
| Residual interest | — |  |  | 367 |  |  | 367 |  |  | — |  |  | 424 |  |  | 424 |  |
| Financing receivables, net | $ | 613 |  |  | $ | 9,628 |  |  | $ | 10,241 |  |  | $ | 648 |  |  | $ | 9,846 |  |  | $ | 10,494 |  |
| Short-term | $ | 613 |  |  | $ | 4,367 |  |  | $ | 4,980 |  |  | $ | 648 |  |  | $ | 4,507 |  |  | $ | 5,155 |  |
| Long-term | $ | — |  |  | $ | 5,261 |  |  | $ | 5,261 |  |  | $ | — |  |  | $ | 5,339 |  |  | $ | 5,339 |  |
  (was, 2020-12-07, similarity 0.9924):
[0001571996-20-000051:note_history:18]
|  | October 30, 2020 |  | January 31, 2020 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Financing receivables, net: |  |  |  |  |  |  |  |  |  |  |  |
| Customer receivables, gross (a) | $ | 768 |  |  | $ | 9,313 |  |  | $ | 10,081 |  |  | $ | 824 |  |  | $ | 8,486 |  |  | $ | 9,310 |  |
| Allowances for losses | (142) |  |  | (165) |  |  | (307) |  |  | (70) |  |  | (79) |  |  | (149) |  |
| Customer receivables, net | 626 |  |  | 9,148 |  |  | 9,774 |  |  | 754 |  |  | 8,407 |  |  | 9,161 |  |
| Residual interest | — |  |  | 472 |  |  | 472 |  |  | — |  |  | 582 |  |  | 582 |  |
| Financing receivables, net | $ | 626 |  |  | $ | 9,620 |  |  | $ | 10,246 |  |  | $ | 754 |  |  | $ | 8,989 |  |  | $ | 9,743 |  |
| Short-term | $ | 626 |  |  | $ | 4,246 |  |  | $ | 4,872 |  |  | $ | 754 |  |  | $ | 4,141 |  |  | $ | 4,895 |  |
| Long-term | $ | — |  |  | $ | 5,374 |  |  | $ | 5,374 |  |  | $ | — |  |  | $ | 4,848 |  |  | $ | 4,848 |  |

- changed (2021-06-07):
[0001571996-21-000026:note_history:19]
|  | Three Months Ended |
|  | April 30, 2021 |  | May 1, 2020 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |  |  |  |  |  |  |  |  |  |  |  |
| Balances at beginning of period | $ | 148 |  |  | $ | 173 |  |  | $ | 321 |  |  | $ | 70 |  |  | $ | 79 |  |  | $ | 149 |  |
| Adjustment for adoption of accounting standard (a) | — |  |  | — |  |  | — |  |  | 40 |  |  | 71 |  |  | 111 |  |
| Charge-offs, net of recoveries | (13) |  |  | (2) |  |  | (15) |  |  | (20) |  |  | (9) |  |  | (29) |  |
| Provision charged to income statement | 4 |  |  | 6 |  |  | 10 |  |  | 54 |  |  | 36 |  |  | 90 |  |
| Balances at end of period | $ | 139 |  |  | $ | 177 |  |  | $ | 316 |  |  | $ | 144 |  |  | $ | 177 |  |  | $ | 321 |  |
  (was, 2020-12-07, similarity 0.9027):
[0001571996-20-000051:note_history:19]
|  | Nine Months Ended |
|  | October 30, 2020 |  | November 1, 2019 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |  |  |  |  |  |  |  |  |  |  |  |
| Balances at beginning of period | $ | 70 |  |  | $ | 79 |  |  | $ | 149 |  |  | $ | 75 |  |  | $ | 61 |  |  | $ | 136 |  |
| Adjustment for adoption of accounting standard (Note 1) | 40 |  |  | 71 |  |  | 111 |  |  | — |  |  | — |  |  | — |  |
| Charge-offs, net of recoveries | (51) |  |  | (22) |  |  | (73) |  |  | (53) |  |  | (18) |  |  | (71) |  |
| Provision charged to income statement | 83 |  |  | 37 |  |  | 120 |  |  | 44 |  |  | 35 |  |  | 79 |  |
| Balances at end of period | $ | 142 |  |  | $ | 165 |  |  | $ | 307 |  |  | $ | 66 |  |  | $ | 78 |  |  | $ | 144 |  |

- added (2021-06-07):
[0001571996-21-000026:note_history:20]
(a)    The Company adopted the current expected credit losses standard as of February 1, 2020 using the modified retrospective method, with the cumulative-effect adjustment to the opening balance of stockholders’ equity (deficit) as of the adoption date.

- changed (2021-06-07):
[0001571996-21-000026:note_history:21]
|  | April 30, 2021 |  | January 29, 2021 |
|  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |
|  | (in millions) |
| Revolving — DPA | $ | 549 |  |  | $ | 21 |  |  | $ | 10 |  |  | $ | 580 |  |  | $ | 578 |  |  | $ | 30 |  |  | $ | 13 |  |  | $ | 621 |  |
| Revolving — DBC | 158 |  |  | 11 |  |  | 3 |  |  | 172 |  |  | 157 |  |  | 14 |  |  | 4 |  |  | 175 |  |
| Fixed-term — Consumer and Commercial | 9,035 |  |  | 346 |  |  | 57 |  |  | 9,438 |  |  | 9,192 |  |  | 316 |  |  | 87 |  |  | 9,595 |  |
| Total customer receivables, gross | $ | 9,742 |  |  | $ | 378 |  |  | $ | 70 |  |  | $ | 10,190 |  |  | $ | 9,927 |  |  | $ | 360 |  |  | $ | 104 |  |  | $ | 10,391 |  |
  (was, 2020-12-07, similarity 0.9902):
[0001571996-20-000051:note_history:21]
|  | October 30, 2020 |  | January 31, 2020 |
|  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |
|  | (in millions) |
| Revolving — DPA | $ | 548 |  |  | $ | 34 |  |  | $ | 10 |  |  | $ | 592 |  |  | $ | 550 |  |  | $ | 51 |  |  | $ | 20 |  |  | $ | 621 |  |
| Revolving — DBC | 159 |  |  | 14 |  |  | 3 |  |  | 176 |  |  | 184 |  |  | 15 |  |  | 4 |  |  | 203 |  |
| Fixed-term — Consumer and Commercial | 8,947 |  |  | 299 |  |  | 67 |  |  | 9,313 |  |  | 8,005 |  |  | 373 |  |  | 108 |  |  | 8,486 |  |
| Total customer receivables, gross | $ | 9,654 |  |  | $ | 347 |  |  | $ | 80 |  |  | $ | 10,081 |  |  | $ | 8,739 |  |  | $ | 439 |  |  | $ | 132 |  |  | $ | 9,310 |  |

- changed (2021-06-07):
[0001571996-21-000026:note_history:22]
Fixed-term consumer and commercial customer receivables are placed on non-accrual status if principal or interest is past due and considered delinquent, or if there is concern about collectibility of a specific customer receivable.  These receivables identified as doubtful for collectibility may be classified as current for aging purposes.  Aged revolving portfolio customer receivables identified as delinquent are charged off.  Receivables are moved back to accrual status when the collection of  interest is probable, or the collection of the net investment is no longer doubtful.
  (was, 2020-12-07, similarity 0.8484):
[0001571996-20-000051:note_history:22]
Fixed-term consumer and commercial customer receivables are placed on non-accrual status if principal or interest is past due and considered delinquent, or if there is concern about collectibility of a specific customer receivable.  These receivables identified as doubtful for collectibility may be classified as current for aging purposes.  Aged revolving portfolio customer receivables identified as delinquent are charged off.

- changed (2021-06-07):
[0001571996-21-000026:note_history:23]
The following tables presents customer receivables, gross, including accrued interest, by credit quality indicator segregated by class and year of origination, as of the dates indicated:
  (was, 2020-12-07, similarity 0.9946):
[0001571996-20-000051:note_history:23]
The following table presents customer receivables, gross, including accrued interest, by credit quality indicator segregated by class and year of origination, as of the date indicated:

- changed (2021-06-07):
[0001571996-21-000026:note_history:24]
|  | April 30, 2021 |
|  | Fixed-term — Consumer and Commercial |  |  |  |  |  |  |
|  | Fiscal Year of Origination |  |  |  |  |  |  |
|  | 2022 |  | 2021 |  | 2020 |  | 2019 |  | 2018 |  | Years Prior |  | Revolving — DPA (a) |  | Revolving — DBC (a) |  | Total |
|  | (in millions) |
| Higher | $ | 1,057 |  |  | $ | 2,597 |  |  | $ | 1,520 |  |  | $ | 486 |  |  | $ | 107 |  |  | $ | 13 |  |  | $ | 153 |  |  | $ | 45 |  |  | $ | 5,978 |  |
| Mid | 286 |  |  | 1,000 |  |  | 553 |  |  | 190 |  |  | 45 |  |  | 4 |  |  | 176 |  |  | 51 |  |  | 2,305 |  |
| Lower | 238 |  |  | 728 |  |  | 419 |  |  | 163 |  |  | 27 |  |  | 5 |  |  | 251 |  |  | 76 |  |  | 1,907 |  |
| Total | $ | 1,581 |  |  | $ | 4,325 |  |  | $ | 2,492 |  |  | $ | 839 |  |  | $ | 179 |  |  | $ | 22 |  |  | $ | 580 |  |  | $ | 172 |  |  | $ | 10,190 |  |
  (was, 2020-12-07, similarity 0.9874):
[0001571996-20-000051:note_history:24]
|  | October 30, 2020 |
|  | Fixed-term — Consumer and Commercial |  |  |  |  |  |  |
|  | Fiscal Year of Origination |  |  |  |  |  |  |
|  | 2021 |  | 2020 |  | 2019 |  | 2018 |  | 2017 |  | Years Prior |  | Revolving — DPA (a) |  | Revolving — DBC (a) |  | Total |
|  | (in millions) |
| Higher | $ | 2,591 |  |  | $ | 1,961 |  |  | $ | 780 |  |  | $ | 191 |  |  | $ | 32 |  |  | $ | — |  |  | $ | 158 |  |  | $ | 48 |  |  | $ | 5,761 |  |
| Mid | 900 |  |  | 736 |  |  | 351 |  |  | 92 |  |  | 13 |  |  | — |  |  | 177 |  |  | 52 |  |  | 2,321 |  |
| Lower | 723 |  |  | 572 |  |  | 303 |  |  | 53 |  |  | 14 |  |  | 1 |  |  | 257 |  |  | 76 |  |  | 1,999 |  |
| Total | $ | 4,214 |  |  | $ | 3,269 |  |  | $ | 1,434 |  |  | $ | 336 |  |  | $ | 59 |  |  | $ | 1 |  |  | $ | 592 |  |  | $ | 176 |  |  | $ | 10,081 |  |

- added (2021-06-07):
[0001571996-21-000026:note_history:25]
|  | January 29, 2021 |
|  | Fixed-term — Consumer and Commercial |  |  |  |  |  |  |
|  | Fiscal Year of Origination |  |  |  |  |  |  |
|  | 2021 |  | 2020 |  | 2019 |  | 2018 |  | 2017 |  | Years Prior |  | Revolving — DPA (a) |  | Revolving — DBC (a) |  | Total |
|  | (in millions) |
| Higher | $ | 3,125 |  |  | $ | 1,802 |  |  | $ | 661 |  |  | $ | 166 |  |  | $ | 26 |  |  | $ | — |  |  | $ | 172 |  |  | $ | 47 |  |  | $ | 5,999 |  |
| Mid | 1,121 |  |  | 671 |  |  | 287 |  |  | 73 |  |  | 9 |  |  | — |  |  | 188 |  |  | 52 |  |  | 2,401 |  |
| Lower | 865 |  |  | 499 |  |  | 243 |  |  | 38 |  |  | 9 |  |  | — |  |  | 261 |  |  | 76 |  |  | 1,991 |  |
| Total | $ | 5,111 |  |  | $ | 2,972 |  |  | $ | 1,191 |  |  | $ | 277 |  |  | $ | 44 |  |  | $ | — |  |  | $ | 621 |  |  | $ | 175 |  |  | $ | 10,391 |  |

- added (2021-06-07):
[0001571996-21-000026:note_history:26]
____________________

- changed (2021-06-07):
[0001571996-21-000026:note_history:27]
Interest income on sales-type lease receivables was $64 million and $65 million for the three months ended April 30, 2021 and May 1, 2020, respectively.
  (was, 2020-12-07, similarity 0.6477):
[0001571996-20-000051:note_history:27]
Interest income on sales-type lease receivables was $69 million and $66 million for the three months ended October 30, 2020 and November 1, 2019, respectively, and $200 million and $196 million for the nine months ended October 30, 2020 and November 1, 2019, respectively.

- changed (2021-06-07):
[0001571996-21-000026:note_history:28]
|  | Three Months Ended |  |  |
|  | April 30, 2021 |  | May 1, 2020 |  |  |  |  |
|  | (in millions) |
| Net revenue — products | $ | 230 |  |  | $ | 215 |  |  |  |  |  |
| Cost of net revenue — products | 163 |  |  | 159 |  |  |  |  |  |
| Gross margin — products | $ | 67 |  |  | $ | 56 |  |  |  |  |  |
  (was, 2020-12-07, similarity 0.711):
[0001571996-20-000051:note_history:28]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 30, 2020 |  | November 1, 2019 |  | October 30, 2020 |  | November 1, 2019 |
|  | (in millions) |
| Net revenue — products | $ | 184 |  |  | $ | 251 |  |  | $ | 648 |  |  | $ | 604 |  |
| Cost of net revenue — products | 102 |  |  | 215 |  |  | 435 |  |  | 475 |  |
| Gross margin — products | $ | 82 |  |  | $ | 36 |  |  | $ | 213 |  |  | $ | 129 |  |

- changed (2021-06-07):
[0001571996-21-000026:note_history:29]
|  | April 30, 2021 |
|  | (in millions) |
| Fiscal 2022 (remaining nine months) | $ | 2,232 |  |
| Fiscal 2023 | 1,819 |  |
| Fiscal 2024 | 1,086 |  |
| Fiscal 2025 | 429 |  |
| Fiscal 2026 and beyond | 141 |  |
| Total undiscounted cash flows | 5,707 |  |
| Fixed-term loans | 4,399 |  |
| Revolving loans | 752 |  |
| Less: unearned income | (668) |  |
| Total customer receivables, gross | $ | 10,190 |  |
  (was, 2020-12-07, similarity 0.9176):
[0001571996-20-000051:note_history:29]
|  | October 30, 2020 |
| Fiscal Years | (in millions) |
| Fiscal 2021 (remaining three months) | $ | 794 |  |
| Fiscal 2022 | 2,378 |  |
| Fiscal 2023 | 1,533 |  |
| Fiscal 2024 | 783 |  |
| Fiscal 2025 and beyond | 360 |  |
| Total undiscounted cash flows | 5,848 |  |
| Fixed-term loans | 4,125 |  |
| Revolving loans | 768 |  |
| Less: unearned income | (660) |  |
| Total customer receivables, gross | $ | 10,081 |  |

- changed (2021-06-07):
[0001571996-21-000026:note_history:30]
|  | April 30, 2021 |  | January 29, 2021 |
|  | (in millions) |
| Equipment under operating lease, gross | $ | 1,921 |  |  | $ | 1,746 |  |
| Less: accumulated depreciation | (541) |  |  | (432) |  |
| Equipment under operating lease, net | $ | 1,380 |  |  | $ | 1,314 |  |
  (was, 2020-12-07, similarity 0.9742):
[0001571996-20-000051:note_history:30]
|  | October 30, 2020 |  | January 31, 2020 |
|  | (in millions) |
| Equipment under operating lease, gross | $ | 1,592 |  |  | $ | 956 |  |
| Less: accumulated depreciation | (328) |  |  | (116) |  |
| Equipment under operating lease, net | $ | 1,264 |  |  | $ | 840 |  |

- changed (2021-06-07):
[0001571996-21-000026:note_history:31]
Operating lease income relating to lease payments was $156 million and $87 million for the three months ended April 30, 2021 and May 1, 2020, respectively.  Depreciation expense was $116 million and $62 million for the three months ended April 30, 2021 and May 1, 2020, respectively.
  (was, 2020-12-07, similarity 0.6188):
[0001571996-20-000051:note_history:31]
Operating lease income relating to lease payments was $120 million and $63 million for the three months ended October 30, 2020 and November 1, 2019, respectively, and $310 million and $94 million for the nine months ended October 30, 2020 and November 1, 2019, respectively.  Depreciation expense was $92 million and $40 million for the three months ended October 30, 2020 and November 1, 2019, respectively, and $228 million and $64 million for the nine months ended October 30, 2020 and November 1, 2019, respectively.

- changed (2021-06-07):
[0001571996-21-000026:note_history:32]
|  | April 30, 2021 |
|  | (in millions) |
| Fiscal 2022 (remaining nine months) | $ | 525 |  |
| Fiscal 2023 | 516 |  |
| Fiscal 2024 | 261 |  |
| Fiscal 2025 | 59 |  |
| Fiscal 2026 and beyond | 9 |  |
| Total | $ | 1,370 |  |
  (was, 2020-12-07, similarity 0.8782):
[0001571996-20-000051:note_history:32]
|  | October 30, 2020 |
| Fiscal Years | (in millions) |
| Fiscal 2021 (remaining three months) | $ | 142 |  |
| Fiscal 2022 | 526 |  |
| Fiscal 2023 | 404 |  |
| Fiscal 2024 | 146 |  |
| Fiscal 2025 and beyond | 24 |  |
| Total | $ | 1,242 |  |

- changed (2021-06-07):
[0001571996-21-000026:note_history:33]
|  | April 30, 2021 |  | January 29, 2021 |
|  | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing and securitization facilities | $ | 2,674 |  |  | $ | 3,311 |  |
| Fixed-term securitization offerings | 3,548 |  |  | 2,961 |  |
| Other | 198 |  |  | 140 |  |
| Total DFS U.S. debt | 6,420 |  |  | 6,412 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 784 |  |  | 786 |  |
| Other borrowings | 1,087 |  |  | 1,006 |  |
| Note payable | 250 |  |  | 250 |  |
| Dell Bank Senior Unsecured Eurobonds | 1,212 |  |  | 1,212 |  |
| Total DFS international debt | 3,333 |  |  | 3,254 |  |
| Total DFS debt | $ | 9,753 |  |  | $ | 9,666 |  |
| Total short-term DFS debt | $ | 4,673 |  |  | $ | 4,888 |  |
| Total long-term DFS debt | $ | 5,080 |  |  | $ | 4,778 |  |
  (was, 2020-12-07, similarity 0.9909):
[0001571996-20-000051:note_history:33]
|  | October 30, 2020 |  | January 31, 2020 |
|  | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing and securitization facilities | $ | 2,574 |  |  | $ | 2,606 |  |
| Fixed-term securitization offerings | 3,465 |  |  | 2,593 |  |
| Other | 94 |  |  | 141 |  |
| Total DFS U.S. debt | 6,133 |  |  | 5,340 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 860 |  |  | 743 |  |
| Other borrowings | 791 |  |  | 931 |  |
| Note payable | 250 |  |  | 200 |  |
| Dell Bank Senior Unsecured Eurobonds | 1,167 |  |  | 551 |  |
| Total DFS international debt | 3,068 |  |  | 2,425 |  |
| Total DFS debt | $ | 9,201 |  |  | $ | 7,765 |  |
| Total short-term DFS debt | $ | 4,884 |  |  | $ | 4,152 |  |
| Total long-term DFS debt | $ | 4,317 |  |  | $ | 3,613 |  |

- changed (2021-06-07):
[0001571996-21-000026:note_history:34]
Asset-Based Financing and Securitization Facilities — The Company maintains separate asset-based financing facilities and a securitization facility in the United States, which are revolving facilities for fixed-term leases and loans and for revolving loans, respectively.  This debt is collateralized solely by the U.S. loan and lease payments and associated equipment in the facilities.  The debt has a variable interest rate and the duration of the debt is based on the terms of the underlying loan and lease payment streams.  As of April 30, 2021, the total debt capacity related to the U.S. asset-based financing and securitization facilities was $4.1 billion.  The Company enters into interest swap agreements to effectively convert a portion of this debt from a floating rate to a fixed rate.  See Note 6 of the Notes to the Condensed Consolidated Financial Statements for additional information about interest rate swaps.
  (was, 2020-12-07, similarity 0.9934):
[0001571996-20-000051:note_history:34]
Asset-Based Financing and Securitization Facilities — The Company maintains separate asset-based financing facilities and a securitization facility in the United States, which are revolving facilities for fixed-term leases and loans and for revolving loans, respectively.  This debt is collateralized solely by the U.S. loan and lease payments and associated equipment in the facilities.  The debt has a variable interest rate and the duration of the debt is based on the terms of the underlying loan and lease payment streams.  As of October 30, 2020, the total debt capacity related to the U.S. asset-based financing and securitization facilities was $4.1 billion.  The Company enters into interest swap agreements to effectively convert a portion of this debt from a floating rate to a fixed rate.  See Note 7 of the Notes to the Condensed Consolidated Financial Statements for additional information about interest rate swaps.

- changed (2021-06-07):
[0001571996-21-000026:note_history:35]
The asset-based financing and securitization facilities contain standard structural features related to the performance of the funded receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the facility, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of April 30, 2021, these criteria were met.
  (was, 2020-12-07, similarity 0.9893):
[0001571996-20-000051:note_history:35]
The asset-based financing and securitization facilities contain standard structural features related to the performance of the funded receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the facility, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of October 30, 2020, these criteria were met.

- changed (2021-06-07):
[0001571996-21-000026:note_history:36]
Securitization Facility — The Company maintains a securitization facility in Europe for fixed-term leases and loans.  This facility is effective through December 21, 2022 and has a total debt capacity of $970 million as of April 30, 2021.
  (was, 2020-12-07, similarity 0.9556):
[0001571996-20-000051:note_history:36]
Securitization Facility — The Company maintains a securitization facility in Europe for fixed-term leases and loans.  This facility is effective through December 21, 2020 and has a total debt capacity of $934 million as of October 30, 2020.

- changed (2021-06-07):
[0001571996-21-000026:note_history:37]
The securitization facility contains standard structural features related to the performance of the securitized receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the program, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of April 30, 2021, these criteria were met.
  (was, 2020-12-07, similarity 0.9888):
[0001571996-20-000051:note_history:37]
The securitization facility contains standard structural features related to the performance of the securitized receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the program, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of October 30, 2020, these criteria were met.

- changed (2021-06-07):
[0001571996-21-000026:note_history:38]
Other Borrowings — In connection with the Company’s international financing operations, the Company has entered into revolving structured financing debt programs related to its fixed-term lease and loan products sold in Canada, Europe, Australia, and New Zealand.  The Canadian facility, which is collateralized solely by Canadian loan and lease payments and associated equipment, had a total debt capacity of $366 million as of April 30, 2021, and is effective through January 16, 2025.  The European facility, which is collateralized solely by European loan and lease payments and associated equipment, had a total debt capacity of $727 million as of April 30, 2021, and is effective through June 14, 2022.  The Australia and New Zealand facility, which is collateralized solely by Australia and New Zealand loan and lease payments and associated equipment, had a total debt capacity of $349 million as of April 30, 2021, and is effective through April 20, 2023.
  (was, 2020-12-07, similarity 0.9691):
[0001571996-20-000051:note_history:38]
Other Borrowings — In connection with the Company’s international financing operations, the Company has entered into revolving structured financing debt programs related to its fixed-term lease and loan products sold in Canada, Europe, Australia, and New Zealand.  The Canadian facility, which is collateralized solely by Canadian loan and lease payments and associated equipment, had a total debt capacity of $281 million as of October 30, 2020, and is effective through January 16, 2023.  The European facility, which is collateralized solely by European loan and lease payments and associated equipment, had a total debt capacity of $700 million as of October 30, 2020, and is effective through June 14, 2022.  The Australia and New Zealand facility, which is collateralized solely by Australia and New Zealand loan and lease payments and associated equipment, had a total debt capacity of $246 million as of October 30, 2020, and is effective through December 20, 2021.

- added (2021-06-07):
[0001571996-21-000026:note_history:39]
Note Payable — On August 7, 2020, the Company entered into two new unsecured credit agreements to fund receivables in Mexico.  As of April 30, 2021, the aggregate principal amount of the notes payable was $250 million.  The notes bear interest at an annual rate of 3.37% and will mature on June 1, 2022.

- changed (2021-06-07):
[0001571996-21-000026:note_history:40]
In connection with the asset-based financing facilities, securitization facilities, and fixed-term securitization offerings discussed above, the Company transfers certain U.S. and European loan and lease payments and associated equipment to SPEs that meet the definition of a Variable Interest Entity (“VIE”) and are consolidated, along with the associated debt detailed above, into the Condensed Consolidated Financial Statements, as the Company is the primary beneficiary of those VIEs.  The SPEs are bankruptcy-remote legal entities with separate assets and liabilities.  The purpose of the SPEs is to facilitate the funding of customer loan and lease payments and associated equipment in the capital markets.
  (was, 2020-12-07, similarity 0.9929):
[0001571996-20-000051:note_history:40]
In connection with the asset-based financing facilities, securitization facilities, and fixed-term securitization offerings discussed above, the Company transfers certain U.S. and European loan and lease payments and associated equipment to SPEs that meet the definition of a Variable Interest Entity (“VIE”) and are consolidated, along with the associated debt detailed above, into the Consolidated Financial Statements, as the Company is the primary beneficiary of those VIEs.  The SPEs are bankruptcy-remote legal entities with separate assets and liabilities.  The purpose of the SPEs is to facilitate the funding of customer loan and lease payments and associated equipment in the capital markets.

- added (2021-06-07):
[0001571996-21-000026:note_history:41]
Some of the SPEs have entered into financing arrangements with multi-seller conduits that, in turn, issue asset-backed debt securities in the capital markets. DFS debt outstanding held by the consolidated VIEs is collateralized by the loan and lease payments and associated equipment. The Company’s risk of loss related to securitized receivables is limited to the amount by which the Company’s right to receive collections for assets securitized exceeds the amount required to pay interest, principal, and fees and expenses related to the asset-backed securities. The Company provides credit enhancement to the securitization in the form of over-collateralization.

- added (2021-06-07):
[0001571996-21-000026:note_history:42]
|  | April 30, 2021 |  | January 29, 2021 |
|  | (in millions) |
| Assets held by consolidated VIEs |  |  |  |
| Other current assets | $ | 874 |  |  | $ | 838 |  |
| Financing receivables, net of allowance |  |  |  |
| Short-term | $ | 3,478 |  |  | $ | 3,534 |  |
| Long-term | $ | 3,267 |  |  | $ | 3,314 |  |
| Property, plant, and equipment, net | $ | 827 |  |  | $ | 792 |  |
| Liabilities held by consolidated VIEs |  |  |  |
| Debt, net of unamortized debt issuance costs |  |  |  |
| Short-term | $ | 4,055 |  |  | $ | 4,208 |  |
| Long-term | $ | 2,938 |  |  | $ | 2,841 |  |

- changed (2021-06-07):
[0001571996-21-000026:note_history:43]
Loan and lease payments and associated equipment transferred via securitization through SPEs were $1.4 billion and $1.8 billion for the three months ended April 30, 2021 and May 1, 2020, respectively.
  (was, 2020-12-07, similarity 0.7113):
[0001571996-20-000051:note_history:43]
Loan and lease payments and associated equipment transferred via securitization through SPEs were $1.6 billion and $1.3 billion for the three months ended October 30, 2020 and November 1, 2019, respectively, and $4.6 billion and $4.1 billion for the nine months ended October 30, 2020 and November 1, 2019, respectively.

- changed (2021-06-07):
[0001571996-21-000026:note_history:44]
To manage certain concentrations of customer credit exposure, the Company may sell selected fixed-term customer receivables to unrelated third parties on a periodic basis, without recourse.  The amount of customer receivables sold for this purpose was $101 million and $21 million for the three months ended April 30, 2021 and May 1, 2020, respectively.  The Company’s continuing involvement in such customer receivables is primarily limited to servicing arrangements.
  (was, 2020-12-07, similarity 0.891):
[0001571996-20-000051:note_history:44]
To manage certain concentrations of customer credit exposure, the Company may sell selected fixed-term customer receivables to unrelated third parties on a periodic basis, without recourse.  The amount of customer receivables sold for this purpose was $414 million and $406 million for the nine months ended October 30, 2020 and November 1, 2019, respectively.  The Company’s continuing involvement in the above mentioned customer receivables is primarily limited to servicing arrangements.

- removed (2021-06-07):
[0001571996-20-000051:note_history:45]
The allowance for losses as of October 30, 2020 includes the adoption of the new CECL standard, which was adopted as of February 1, 2020 using the modified retrospective method.  Prior period amounts have not been recast.  The provision recognized on the Condensed Consolidated Statements of Income (Loss) for the three and nine months ended October 30, 2020 is based on an assessment of the impact of current and expected future economic conditions, inclusive of the effect of the COVID-19 pandemic on credit losses.  The duration and severity of COVID-19 and continued market volatility is highly uncertain and, as such, the impact on expected losses is subject to significant judgment and may cause variability in the Company’s allowance for credit losses in future periods.  See Note 1 and Note 2 of the Notes to the Condensed Consolidated Financial Statements for additional information about the new CECL standard.

- removed (2021-06-07):
[0001571996-20-000051:note_history:46]
|  | Three Months Ended |
|  | October 30, 2020 |  | November 1, 2019 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |  |  |  |  |  |  |  |  |  |  |  |
| Balances at beginning of period | $ | 143 |  |  | $ | 180 |  |  | $ | 323 |  |  | $ | 67 |  |  | $ | 71 |  |  | $ | 138 |  |
| Charge-offs, net of recoveries | (13) |  |  | (6) |  |  | (19) |  |  | (18) |  |  | (6) |  |  | (24) |  |
| Provision charged to income statement | 12 |  |  | (9) |  |  | 3 |  |  | 17 |  |  | 13 |  |  | 30 |  |
| Balances at end of period | $ | 142 |  |  | $ | 165 |  |  | $ | 307 |  |  | $ | 66 |  |  | $ | 78 |  |  | $ | 144 |  |

- removed (2021-06-07):
[0001571996-20-000051:note_history:47]
The following table presents customer receivables, gross, including accrued interest, by credit quality indicator segregated by class, as of the date indicated, and was not recast to reflect the impact of adoption of the new CECL standard:

- removed (2021-06-07):
[0001571996-20-000051:note_history:48]
|  | January 31, 2020 |
|  | Fixed-term — Consumer and Commercial |  | Revolving — DPA |  | Revolving — DBC |  | Total |
|  | (in millions) |
| Higher | $ | 5,042 |  |  | $ | 137 |  |  | $ | 55 |  |  | $ | 5,234 |  |
| Mid | 2,036 |  |  | 175 |  |  | 63 |  |  | 2,274 |  |
| Lower | 1,408 |  |  | 309 |  |  | 85 |  |  | 1,802 |  |
| Total | $ | 8,486 |  |  | $ | 621 |  |  | $ | 203 |  |  | $ | 9,310 |  |

- removed (2021-06-07):
[0001571996-20-000051:note_history:49]
Note Payable — On November 27, 2017 the Company entered into an unsecured credit agreement to fund receivables in Mexico.  As of July 31, 2020, the aggregate principal amount of the note payable was $187 million.  This note was repaid in full during the three months ended October 30, 2020.

- removed (2021-06-07):
[0001571996-20-000051:note_history:50]
On August 7, 2020, the Company entered into two new unsecured credit agreements to fund receivables in Mexico.  As of October 30, 2020, the aggregate principal amount of the notes payable was $250 million.  The notes bear interest at 3.37% and will mature on June 1, 2022.

- removed (2021-06-07):
[0001571996-20-000051:note_history:51]
|  | October 30, 2020 |  | January 31, 2020 |
|  | (in millions) |
| Assets held by consolidated VIEs, net: |  |  |  |
| Short-term, net | $ | 3,430 |  |  | $ | 3,316 |  |
| Long-term, net | 4,070 |  |  | 3,348 |  |
| Assets held by consolidated VIEs, net | $ | 7,500 |  |  | $ | 6,664 |  |

- removed (2021-06-07):
[0001571996-20-000051:note_history:52]
Some of the SPEs have entered into financing arrangements with multi-seller conduits that, in turn, issue asset-backed debt securities in the capital markets.  The DFS debt outstanding, which is collateralized by the loan and lease payments and associated equipment held by the consolidated VIEs, was $6.9 billion and $5.9 billion as of October 30, 2020 and January 31, 2020, respectively.  The Company’s risk of loss related to securitized receivables is limited to the amount by which the Company’s right to receive collections for assets securitized exceeds the amount required to pay interest, principal, and fees and expenses related to the asset-backed securities.  The Company provides credit enhancement to the securitizations in the form of over-collateralization.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2021-06-07):
[0001571996-21-000026:note_history:53]
|  | April 30, 2021 |  | January 29, 2021 |
|  | (in millions) |
| Secured Debt |  |  |  |
| Senior Secured Credit Facilities: |  |  |  |
| 2.00% Term Loan B-2 Facility due September 2025 | $ | 3,135 |  |  | $ | 3,143 |  |
| 1.90% Term Loan A-6 Facility due March 2024 | 3,134 |  |  | 3,134 |  |
| First Lien Notes: |  |  |  |
| 5.45% due June 2023 | 3,750 |  |  | 3,750 |  |
| 4.00% due July 2024 | 1,000 |  |  | 1,000 |  |
| 5.85% due July 2025 | 1,000 |  |  | 1,000 |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 4.90% due October 2026 | 1,750 |  |  | 1,750 |  |
| 6.10% due July 2027 | 500 |  |  | 500 |  |
| 5.30% due October 2029 | 1,750 |  |  | 1,750 |  |
| 6.20% due July 2030 | 750 |  |  | 750 |  |
| 8.10% due July 2036 | 1,500 |  |  | 1,500 |  |
| 8.35% due July 2046 | 2,000 |  |  | 2,000 |  |
| Unsecured Debt |  |  |  |
| Unsecured Notes and Debentures: |  |  |  |
| 4.625% due April 2021 | — |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| Senior Notes: |  |  |  |
| 5.875% due June 2021 | — |  |  | 1,075 |  |
| 7.125% due June 2024 | 1,625 |  |  | 1,625 |  |
| EMC Notes: |  |  |  |
| 3.375% due June 2023 | 1,000 |  |  | 1,000 |  |
| Debt of Public Subsidiary |  |  |  |
| VMware Notes: |  |  |  |
| 2.95% due August 2022 | 1,500 |  |  | 1,500 |  |
| 4.50% due May 2025 | 750 |  |  | 750 |  |
| 4.65% due May 2027 | 500 |  |  | 500 |  |
| 3.90% due August 2027 | 1,250 |  |  | 1,250 |  |
| 4.70% due May 2030 | 750 |  |  | 750 |  |
| DFS Debt (Note 3) | 9,753 |  |  | 9,666 |  |
| Other |  |  |  |
| 2.46% Margin Loan Facility due April 2022 | 4,000 |  |  | 4,000 |  |
| Other | 304 |  |  | 235 |  |
| Total debt, principal amount | $ | 47,153 |  |  | $ | 48,480 |  |

- changed (2021-06-07):
[0001571996-21-000026:note_history:54]
|  | April 30, 2021 |  | January 29, 2021 |
|  | (in millions) |
| Total debt, principal amount | $ | 47,153 |  |  | $ | 48,480 |  |
| Unamortized discount, net of unamortized premium | (185) |  |  | (194) |  |
| Debt issuance costs | (285) |  |  | (302) |  |
| Total debt, carrying value | $ | 46,683 |  |  | $ | 47,984 |  |
| Total short-term debt, carrying value | $ | 8,748 |  |  | $ | 6,362 |  |
| Total long-term debt, carrying value | $ | 37,935 |  |  | $ | 41,622 |  |
  (was, 2020-12-07, similarity 0.985):
[0001571996-20-000051:note_history:54]
|  | October 30, 2020 |  | January 31, 2020 |
|  | (in millions) |
| Total debt, principal amount | $ | 50,411 |  |  | $ | 52,665 |  |
| Unamortized discount, net of unamortized premium | (217) |  |  | (241) |  |
| Debt issuance costs | (333) |  |  | (368) |  |
| Total debt, carrying value | $ | 49,861 |  |  | $ | 52,056 |  |
| Total short-term debt, carrying value | $ | 6,536 |  |  | $ | 7,737 |  |
| Total long-term debt, carrying value | $ | 43,325 |  |  | $ | 44,319 |  |

- changed (2021-06-07):
[0001571996-21-000026:note_history:55]
During the three months ended April 30, 2021, the net decrease in the Company’s debt balance was primarily due to:
  (was, 2020-12-07, similarity 0.9217):
[0001571996-20-000051:note_history:55]
During the nine months ended October 30, 2020, the net decrease in the Company’s debt balance was primarily due to:

- changed (2021-06-07):
[0001571996-21-000026:note_history:56]
•repayment of $1,075 million principal amount of the 5.875% Senior Notes due June 2021; and
  (was, 2020-12-07, similarity 0.8503):
[0001571996-20-000051:note_history:56]
•repayment of $600 million principal amount of 2.650% EMC Notes due June 2020 upon maturity; and

- changed (2021-06-07):
[0001571996-21-000026:note_history:57]
•repayment of $400 million principal amount of the 4.625% Unsecured Notes due April 2021.
  (was, 2020-12-07, similarity 0.8235):
[0001571996-20-000051:note_history:57]
•repayment of $1.25 billion principal amount of 2.30% VMware Notes due August 2020;

- changed (2021-06-07):
[0001571996-21-000026:note_history:58]
As of April 30, 2021, available borrowings under the Revolving Credit Facility totaled $4.5 billion.  The Senior Secured Credit Facilities provide that the borrowers have the right at any time, subject to customary conditions, to request incremental term loans or incremental revolving commitments.
  (was, 2020-12-07, similarity 0.9793):
[0001571996-20-000051:note_history:58]
As of October 30, 2020, available borrowings under the Revolving Credit Facility totaled $4.5 billion.  The Senior Secured Credit Facilities provide that the borrowers have the right at any time, subject to customary conditions, to request incremental term loans or incremental revolving commitments.

- added (2021-06-07):
[0001571996-21-000026:note_history:59]
On February 18, 2021, the Company entered into an eighth refinancing amendment to the credit agreement for the Senior Secured Credit Facilities to refinance the existing term B loans (the “Original Term B Loans”) with a new term loan B facility consisting of an aggregate principal amount of $3,143 million refinancing term B-2 loans (the “Refinancing Term B-2 Loans”) maturing on September 19, 2025.  Proceeds from the Refinancing Term B-2 Loans, together with other funds available to the borrowers, were used to repay in full the Original Term B Loans and all accrued and unpaid fees in respect thereof.

- added (2021-06-07):
[0001571996-21-000026:note_history:60]
Except for a change in the interest rate, the Refinancing Term B-2 Loans have substantially the same terms as the Original Term B Loans under the sixth refinancing amendment to the Senior Secured Credit Agreement.  Amortization payments on the Refinancing Term B-2 Loans are equal to 0.25% of the aggregate principal amount of Refinancing Term B-2 Loans outstanding on the effective date of the eighth refinancing amendment, payable at the end of each fiscal quarter, commencing with the fiscal quarter ended April 30, 2021.

- changed (2021-06-07):
[0001571996-21-000026:note_history:61]
Borrowings under the Senior Secured Credit Facilities bear interest at a rate per annum equal to an applicable margin, plus, at the borrowers’ option, either (a) a base rate, or (b) the London Interbank Offered Rate (“LIBOR”).  The Term Loan A-6 Facility bears interest at LIBOR plus an applicable margin ranging from 1.25% to 2.00% or a base rate plus an applicable margin ranging from 0.25% to 1.00%.  The Refinancing Term B-2 Loans bear interest at LIBOR plus an applicable margin of 1.75% or a base rate plus an applicable margin of 0.75%.  Interest is payable, in the case of loans bearing interest based on LIBOR, at the end of each interest period (but at least every three months), in arrears and, in the case of loans bearing interest based on the base rate, quarterly in arrears.
  (was, 2020-12-07, similarity 0.7319):
[0001571996-20-000051:note_history:61]
Borrowings under the Senior Secured Credit Facilities bear interest at a rate per annum equal to an applicable margin, plus, at the borrowers’ option, either (a) a base rate, or (b) the London Interbank Offered Rate (“LIBOR”).  The Term Loan B-1 Facility bears interest at LIBOR plus an applicable margin of 2.00% or a base rate plus an applicable margin of 1.00%.  The Term Loan A-4 Facility and the Term Loan A-6 Facility bear interest at LIBOR plus an applicable margin ranging from 1.25% to 2.00% or a base rate plus an applicable margin ranging from 0.25% to 1.00%.  Interest is payable, in the case of loans bearing interest based on LIBOR, at the end of each interest period (but at least every three months), in arrears and, in the case of loans bearing interest based on the base rate, quarterly in arrears.

- added (2021-06-07):
[0001571996-21-000026:note_history:62]
The Term Loan A-6 Facility amortizes in equal quarterly installments in aggregate annual amounts equal to 5% of the original principal amount in each of the first four years after the facility closing date of March 13, 2019, and 80% of the original principal amount in the fifth year after March 13, 2019.  The Revolving Credit Facility has no amortization.

- changed (2021-06-07):
[0001571996-21-000026:note_history:63]
The Company agreed to use commercially reasonable efforts to register with the SEC notes having terms substantially identical to the terms of the First Lien Notes as part of an offer to exchange such registered notes for the First Lien Notes.  The Company will be obligated to pay additional interest on the First Lien Notes if it fails to consummate such an exchange offer within five years after the closing date of the EMC merger transaction, in the case of the First Lien Notes issued on June 1, 2016, and within five years after their respective issue dates, in the case of the First Lien Notes issued on March 20, 2019 and April 9, 2020.  On April 15, 2021, Dell International L.L.C., EMC Corporation and the guarantors of the First Lien Notes (collectively, the “Registrants”)  filed a registration statement with the SEC relating to the proposed exchange offer of such registered notes.
  (was, 2020-12-07, similarity 0.8354):
[0001571996-20-000051:note_history:63]
The Company has agreed to use commercially reasonable efforts to register with the SEC notes having terms substantially identical to the terms of the First Lien Notes as part of an offer to exchange such registered notes for the First Lien Notes.  The Company will be obligated to pay additional interest on the First Lien Notes if it fails to consummate such an exchange offer within five years after the closing date of the EMC merger transaction, in the case of the First Lien Notes issued on June 1, 2016, and within five years after their respective issue dates, in the case of the First Lien Notes issued on March 20, 2019 and April 9, 2020.

- added (2021-06-07):
[0001571996-21-000026:note_history:64]
Subsequent to the three months ended April 30, 2021, on May 13, 2021, the Registrants filed an amendment to the registration statement, which was declared effective on May 17, 2021.  In addition, on May 17, 2021, the Registrants filed a prospectus with the SEC and launched the exchange offer.  The exchange offer expires at 5:00 p.m., New York City time, on June 15, 2021, unless extended by Dell International L.L.C. and EMC Corporation. During this period holders of the First Lien Notes may elect to tender their unregistered outstanding notes for freely tradable exchange notes that have been registered under the Securities Act.  The Company does not currently intend to extend the expiration date.

- changed (2021-06-07):
[0001571996-21-000026:note_history:65]
Unsecured Notes and Debentures — The Company has outstanding unsecured notes and debentures (collectively, the “Unsecured Notes and Debentures”) that were issued by Dell prior to the acquisition of Dell by Dell Technologies Inc. in the going-private transaction that closed in October 2013.  Interest on outstanding borrowings is payable semiannually.
  (was, 2020-12-07, similarity 0.9767):
[0001571996-20-000051:note_history:65]
Unsecured Notes and Debentures — The Company has outstanding unsecured notes and debentures (collectively, the “Unsecured Notes and Debentures”) that were issued by Dell prior to the acquisition of Dell by Dell Technologies Inc. in the going-private transaction that closed in October 2013.  Interest on these borrowings is payable semiannually.

- changed (2021-06-07):
[0001571996-21-000026:note_history:66]
Senior Notes — The senior unsecured notes (collectively, the “Senior Notes”) were issued on June 22, 2016 in an aggregate principal amount of $3.25 billion.  Interest on outstanding borrowings is payable semiannually.
  (was, 2020-12-07, similarity 0.961):
[0001571996-20-000051:note_history:66]
Senior Notes — The senior unsecured notes (collectively, the “Senior Notes”) were issued on June 22, 2016 in an aggregate principal amount of $3.25 billion.  Interest on these borrowings is payable semiannually.

- changed (2021-06-07):
[0001571996-21-000026:note_history:67]
EMC Notes — On September 7, 2016, EMC had outstanding $2.5 billion aggregate principal amount of its 1.875% Notes due June 2018, $2.0 billion aggregate principal amount of its 2.650% Notes due June 2020, and $1.0 billion aggregate principal amount of its 3.375% Notes due June 2023 (collectively, the “EMC Notes”).  Interest on outstanding borrowings is payable semiannually.
  (was, 2020-12-07, similarity 0.882):
[0001571996-20-000051:note_history:67]
EMC Notes — On September 7, 2016, EMC had outstanding $2.5 billion aggregate principal amount of its 1.875% Notes due June 2018, which the Company fully repaid during the three months ended August 3, 2018, $2.0 billion aggregate principal amount of its 2.650% Notes due June 2020, and $1.0 billion aggregate principal amount of its 3.375% Notes due June 2023 (collectively, the “EMC Notes”).  Interest on these borrowings is payable semiannually.

- changed (2021-06-07):
[0001571996-21-000026:note_history:68]
VMware Notes — VMware, Inc. completed public offerings of unsecured senior notes in the aggregate amounts of $4.0 billion and $2.0 billion on August 21, 2017 and April 7, 2020, respectively (the “VMware Notes”).  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.  Interest on outstanding borrowings is payable semiannually.
  (was, 2020-12-07, similarity 0.984):
[0001571996-20-000051:note_history:68]
VMware Notes — VMware, Inc. completed public offerings of unsecured senior notes in the aggregate amounts of $4.0 billion and $2.0 billion on August 21, 2017 and April 7, 2020, respectively (the “VMware Notes”).  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.  Interest on these borrowings is payable semiannually.

- changed (2021-06-07):
[0001571996-21-000026:note_history:69]
VMware Revolving Credit Facility — On September 12, 2017, VMware, Inc. entered into an unsecured credit agreement, establishing a revolving credit facility (the “VMware Revolving Credit Facility”) with a syndicate of lenders that provides the company with a borrowing capacity of up to $1.0 billion for VMware, Inc. general corporate purposes.  Commitments under the VMware Revolving Credit Facility are available for a period of five years, which may be extended, subject to the satisfaction of certain conditions, by up to two one year periods.  The credit agreement contains certain representations, warranties, and covenants.  Commitment fees, interest rates, and other terms of borrowing under the VMware Revolving Credit Facility may vary based on VMware, Inc.’s external credit ratings.  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.  As of April 30, 2021, there were no outstanding borrowings under the VMware Revolving Credit Facility.
  (was, 2020-12-07, similarity 0.9947):
[0001571996-20-000051:note_history:69]
VMware Revolving Credit Facility — On September 12, 2017, VMware, Inc. entered into an unsecured credit agreement, establishing a revolving credit facility (the “VMware Revolving Credit Facility”) with a syndicate of lenders that provides the company with a borrowing capacity of up to $1.0 billion for VMware, Inc. general corporate purposes.  Commitments under the VMware Revolving Credit Facility are available for a period of five years, which may be extended, subject to the satisfaction of certain conditions, by up to two one year periods.  The credit agreement contains certain representations, warranties, and covenants.  Commitment fees, interest rates, and other terms of borrowing under the VMware Revolving Credit Facility may vary based on VMware, Inc.’s external credit ratings.  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.  As of October 30, 2020, there were no outstanding borrowings under the VMware Revolving Credit Facility.

- changed (2021-06-07):
[0001571996-21-000026:note_history:70]
Margin Loan Facility — On April 12, 2017, the Company entered into the Margin Loan Facility in an aggregate principal amount of $2.0 billion.  In connection with the Class V transaction described in Note 1 of the Notes to the Condensed Consolidated Financial Statements, on December 20, 2018, the Company amended the Margin Loan Facility to increase the aggregate principal amount to $3.35 billion.  In connection with obtaining the Term Loan A-6 Facility during the fiscal year ended January 31, 2020, the Company increased the aggregate principal amount of the Margin Loan Facility to $4.0 billion. VMware Holdco LLC, a wholly-owned subsidiary of EMC, is the borrower under the Margin Loan Facility, which is secured by approximately 76 million shares of Class B common stock of VMware, Inc. and approximately 24 million shares of Class A common stock of VMware, Inc.
  (was, 2020-12-07, similarity 0.7681):
[0001571996-20-000051:note_history:70]
Margin Loan Facility — On April 12, 2017, the Company entered into the Margin Loan Facility in an aggregate principal amount of $2.0 billion, under which VMW Holdco LLC, a wholly-owned subsidiary of EMC, is the borrower.  In connection with the Class V transaction described in Note 1 of the Notes to the Condensed Consolidated Financial Statements, on December 20, 2018, the Company amended the Margin Loan Facility to increase the aggregate principal amount to $3.35 billion.  In connection with obtaining the Term Loan A-6 Facility during the fiscal year ended January 31, 2020, the Company increased the aggregate principal amount of the Margin Loan Facility to $4.0 billion.

- changed (2021-06-07):
[0001571996-21-000026:note_history:71]
The following table presents the aggregate future maturities of the Company’s debt as of April 30, 2021 for the periods indicated:
  (was, 2020-12-07, similarity 0.9603):
[0001571996-20-000051:note_history:71]
The following table presents the aggregate future maturities of the Company’s debt as of October 30, 2020 for the periods indicated:

- changed (2021-06-07):
[0001571996-21-000026:note_history:72]
|  | Maturities by Fiscal Year |
|  | 2022(remaining nine months) |  | 2023 |  | 2024 |  | 2025 |  | 2026 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Secured Credit Facilities and First Lien Notes | $ | 31 |  |  | $ | 213 |  |  | $ | 6,007 |  |  | $ | 1,758 |  |  | $ | 4,017 |  |  | $ | 12,743 |  |  | $ | 24,769 |  |
| Unsecured Notes and Debentures | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 952 |  |  | 952 |  |
| Senior Notes and EMC Notes | — |  |  | — |  |  | 1,000 |  |  | 1,625 |  |  | — |  |  | — |  |  | 2,625 |  |
| VMware Notes | — |  |  | 1,500 |  |  | — |  |  | — |  |  | 750 |  |  | 2,500 |  |  | 4,750 |  |
| DFS Debt | 3,844 |  |  | 4,249 |  |  | 774 |  |  | 850 |  |  | 36 |  |  | — |  |  | 9,753 |  |
| Margin Loan Facility | — |  |  | 4,000 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 4,000 |  |
| Other | 11 |  |  | 11 |  |  | 171 |  |  | 78 |  |  | 8 |  |  | 25 |  |  | 304 |  |
| Total maturities, principal amount | 3,886 |  |  | 9,973 |  |  | 7,952 |  |  | 4,311 |  |  | 4,811 |  |  | 16,220 |  |  | 47,153 |  |
| Associated carrying value adjustments | (6) |  |  | (15) |  |  | (32) |  |  | (71) |  |  | (47) |  |  | (299) |  |  | (470) |  |
| Total maturities, carrying value amount | $ | 3,880 |  |  | $ | 9,958 |  |  | $ | 7,920 |  |  | $ | 4,240 |  |  | $ | 4,764 |  |  | $ | 15,921 |  |  | $ | 46,683 |  |
  (was, 2020-12-07, similarity 0.9328):
[0001571996-20-000051:note_history:72]
|  | Maturities by Fiscal Year |
|  | 2021 (remaining three months) |  | 2022 |  | 2023 |  | 2024 |  | 2025 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Secured Credit Facilities and First Lien Notes | $ | — |  |  | $ | 172 |  |  | $ | 286 |  |  | $ | 7,384 |  |  | $ | 1,047 |  |  | $ | 18,297 |  |  | $ | 27,186 |  |
| Unsecured Notes and Debentures | — |  |  | 400 |  |  | — |  |  | — |  |  | — |  |  | 952 |  |  | 1,352 |  |
| Senior Notes and EMC Notes | — |  |  | 1,075 |  |  | — |  |  | 1,000 |  |  | 1,625 |  |  | — |  |  | 3,700 |  |
| VMware Notes | — |  |  | — |  |  | 1,500 |  |  | — |  |  | — |  |  | 3,250 |  |  | 4,750 |  |
| DFS Debt | 2,012 |  |  | 3,481 |  |  | 2,654 |  |  | 356 |  |  | 692 |  |  | 6 |  |  | 9,201 |  |
| Margin Loan Facility | — |  |  | — |  |  | 4,000 |  |  | — |  |  | — |  |  | — |  |  | 4,000 |  |
| Other | 3 |  |  | 12 |  |  | 12 |  |  | 156 |  |  | 8 |  |  | 31 |  |  | 222 |  |
| Total maturities, principal amount | 2,015 |  |  | 5,140 |  |  | 8,452 |  |  | 8,896 |  |  | 3,372 |  |  | 22,536 |  |  | 50,411 |  |
| Associated carrying value adjustments | (1) |  |  | (10) |  |  | (14) |  |  | (38) |  |  | (83) |  |  | (404) |  |  | (550) |  |
| Total maturities, carrying value amount | $ | 2,014 |  |  | $ | 5,130 |  |  | $ | 8,438 |  |  | $ | 8,858 |  |  | $ | 3,289 |  |  | $ | 22,132 |  |  | $ | 49,861 |  |

- changed (2021-06-07):
[0001571996-21-000026:note_history:73]
Covenants and Unrestricted Net Assets — The credit agreement for the Senior Secured Credit Facilities contains customary negative covenants that generally limit the ability of Denali Intermediate Inc., a wholly-owned subsidiary of Dell Technologies (“Denali Intermediate”), Dell, and Dell’s and Denali Intermediate’s other restricted subsidiaries to incur debt, create liens, make fundamental changes, enter into asset sales, make certain investments, pay dividends or distribute or redeem certain equity interests, prepay or redeem certain debt, and enter into certain transactions with affiliates.  The indenture governing the Senior Notes contains customary negative covenants that generally limit the ability of Denali Intermediate, Dell, and Dell’s and Denali Intermediate’s other restricted subsidiaries to incur additional debt or issue certain preferred shares, pay dividends on or make other distributions in respect of capital stock or make other restricted payments, make certain investments, sell or transfer certain assets, create liens on certain assets to secure debt, consolidate, merge, sell, or otherwise dispose of all or substantially all assets, enter into certain transactions with affiliates, and designate subsidiaries as unrestricted subsidiaries.  The negative covenants under such credit agreements and indenture are subject to certain exceptions, qualifications, and “baskets.”  The indentures governing the First Lien Notes, the Unsecured Notes and Debentures, and the EMC Notes variously impose limitations, subject to specified exceptions, on creating certain liens, entering into sale and lease-back transactions, and entering into certain asset sales.  The foregoing credit agreements and indentures contain customary events of default, including failure to make required payments, failure to comply with covenants, and the occurrence of certain events of bankruptcy and insolvency.
  (was, 2020-12-07, similarity 0.9937):
[0001571996-20-000051:note_history:73]
Covenants and Unrestricted Net Assets — The credit agreement for the Senior Secured Credit Facilities contains customary negative covenants that generally limit the ability of Denali Intermediate Inc., a wholly-owned subsidiary of Dell Technologies, Dell, and Dell’s and Denali Intermediate’s other restricted subsidiaries to incur debt, create liens, make fundamental changes, enter into asset sales, make certain investments, pay dividends or distribute or redeem certain equity interests, prepay or redeem certain debt, and enter into certain transactions with affiliates.  The indenture governing the Senior Notes contains customary negative covenants that generally limit the ability of Denali Intermediate, Dell, and Dell’s and Denali Intermediate’s other restricted subsidiaries to incur additional debt or issue certain preferred shares, pay dividends on or make other distributions in respect of capital stock or make other restricted payments, make certain investments, sell or transfer certain assets, create liens on certain assets to secure debt, consolidate, merge, sell, or otherwise dispose of all or substantially all assets, enter into certain transactions with affiliates, and designate subsidiaries as unrestricted subsidiaries.  The negative covenants under such credit agreements and indenture are subject to certain exceptions, qualifications, and “baskets.”  The indentures governing the First Lien Notes, the Unsecured Notes and Debentures, and the EMC Notes variously impose limitations, subject to specified exceptions, on creating certain liens, entering into sale and lease-back transactions, and entering into certain asset sales.  The foregoing credit agreements and indentures contain customary events of default, including failure to make required payments, failure to comply with covenants, and the occurrence of certain events of bankruptcy and insolvency.

- changed (2021-06-07):
[0001571996-21-000026:note_history:74]
As of April 30, 2021, the Company had certain consolidated subsidiaries that were designated as unrestricted subsidiaries for all purposes of the applicable credit agreements and the indentures governing the First Lien Notes and the Senior Notes.  Substantially all of the net assets of the Company’s consolidated subsidiaries were restricted, with the exception of the Company’s unrestricted subsidiaries, primarily VMware, Inc., Secureworks, and their respective subsidiaries, as of April 30, 2021.
  (was, 2020-12-07, similarity 0.9755):
[0001571996-20-000051:note_history:74]
As of October 30, 2020, the Company had certain consolidated subsidiaries that were designated as unrestricted subsidiaries for all purposes of the applicable credit agreements and the indentures governing the First Lien Notes and the Senior Notes.  Substantially all of the net assets of the Company’s consolidated subsidiaries were restricted, with the exception of the Company’s unrestricted subsidiaries, primarily VMware, Inc., Secureworks, and their respective subsidiaries, as of October 30, 2020.

- changed (2021-06-07):
[0001571996-21-000026:note_history:75]
The Term Loan A-6 Facility and the Revolving Credit Facility are subject to a first lien leverage ratio covenant that is tested at the end of each fiscal quarter of Dell with respect to Dell’s preceding four fiscal quarters.  The Company was in compliance with all financial covenants as of April 30, 2021.
  (was, 2020-12-07, similarity 0.9348):
[0001571996-20-000051:note_history:75]
The Term Loan A-4 Facility, the Term Loan A-6 Facility, and the Revolving Credit Facility are subject to a first lien leverage ratio covenant that is tested at the end of each fiscal quarter of Dell with respect to Dell’s preceding four fiscal quarters.  The Company was in compliance with all financial covenants as of October 30, 2020.

- removed (2021-06-07):
[0001571996-20-000051:note_history:76]
|  | October 30, 2020 |  | January 31, 2020 |
|  | (in millions) |
| Secured Debt |  |  |  |
| Senior Secured Credit Facilities: |  |  |  |
| 2.75% Term Loan B-1 Facility due September 2025 | $ | 4,691 |  |  | $ | 4,738 |  |
| 1.90% Term Loan A-4 Facility due December 2023 | 679 |  |  | 679 |  |
| 1.90% Term Loan A-6 Facility due March 2024 | 3,316 |  |  | 3,497 |  |
| First Lien Notes: |  |  |  |
| 4.42% due June 2021 | — |  |  | 4,500 |  |
| 5.45% due June 2023 | 3,750 |  |  | 3,750 |  |
| 4.00% due July 2024 | 1,000 |  |  | 1,000 |  |
| 5.85% due July 2025 | 1,000 |  |  | — |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 4.90% due October 2026 | 1,750 |  |  | 1,750 |  |
| 6.10% due July 2027 | 500 |  |  | — |  |
| 5.30% due October 2029 | 1,750 |  |  | 1,750 |  |
| 6.20% due July 2030 | 750 |  |  | — |  |
| 8.10% due July 2036 | 1,500 |  |  | 1,500 |  |
| 8.35% due July 2046 | 2,000 |  |  | 2,000 |  |
| Unsecured Debt |  |  |  |
| Unsecured Notes and Debentures: |  |  |  |
| 4.625% due April 2021 | 400 |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| Senior Notes: |  |  |  |
| 5.875% due June 2021 | 1,075 |  |  | 1,075 |  |
| 7.125% due June 2024 | 1,625 |  |  | 1,625 |  |
| EMC Notes: |  |  |  |
| 2.650% due June 2020 | — |  |  | 600 |  |
| 3.375% due June 2023 | 1,000 |  |  | 1,000 |  |
| Debt of Public Subsidiary |  |  |  |
| VMware Notes: |  |  |  |
| 2.30% due August 2020 | — |  |  | 1,250 |  |
| 2.95% due August 2022 | 1,500 |  |  | 1,500 |  |
| 4.50% due May 2025 | 750 |  |  | — |  |
| 4.65% due May 2027 | 500 |  |  | — |  |
| 3.90% due August 2027 | 1,250 |  |  | 1,250 |  |
| 4.70% due May 2030 | 750 |  |  | — |  |
| VMware Term Loan Facility | — |  |  | 1,500 |  |
| DFS Debt (Note 4) | 9,201 |  |  | 7,765 |  |
| Other |  |  |  |
| 2.46% Margin Loan Facility due April 2022 | 4,000 |  |  | 4,000 |  |
| Other | 222 |  |  | 84 |  |
| Total debt, principal amount | $ | 50,411 |  |  | $ | 52,665 |  |

- removed (2021-06-07):
[0001571996-20-000051:note_history:77]
•retirement of $4.5 billion principal amount of 4.42% First Lien Notes due June 2021 via repayment of $4,265 million and open market repurchases of $235 million;

- removed (2021-06-07):
[0001571996-20-000051:note_history:78]
•repayment of $1.5 billion principal amount of VMware Term Loan Facility upon maturity;

- removed (2021-06-07):
[0001571996-20-000051:note_history:79]
•amortization of approximately $229 million of principal under the Company’s term loan facilities.

- removed (2021-06-07):
[0001571996-20-000051:note_history:80]
These decreases in the Company’s debt balance were partially offset by:

- removed (2021-06-07):
[0001571996-20-000051:note_history:81]
•issuance of $2.25 billion principal amount of First Lien Notes on April 9, 2020, described below;

- removed (2021-06-07):
[0001571996-20-000051:note_history:82]
•issuance of $2.0 billion principal amount of VMware Notes on April 7, 2020, described below; and

- removed (2021-06-07):
[0001571996-20-000051:note_history:83]
•incurrence of an additional $1.4 billion, net, in DFS debt to support the expansion of its financing receivables portfolio.

- removed (2021-06-07):
[0001571996-20-000051:note_history:84]
The Term Loan B-1 Facility amortizes in equal quarterly installments in aggregate annual amounts equal to 1% of the original principal amount.  The Term Loan A-4 Facility amortizes in equal quarterly installments in aggregate annual amounts equal to 5% of the original principal amount in each of the first four years after the facility closing date of December 20, 2018, and 80% of the original principal amount in the fifth year after December 20, 2018.  The Term Loan A-6 Facility amortizes in equal quarterly installments in aggregate annual amounts equal to 5% of the original principal amount in each of the first four years after the facility closing date of March 13, 2019, and 80% of the original principal amount in the fifth year after March 13, 2019.  The Revolving Credit Facility has no amortization.

- removed (2021-06-07):
[0001571996-20-000051:note_history:85]
China Revolving Credit Facility — The Company entered into a new revolving credit facility for China (the “China Revolving Credit Facility”) effective May 25, 2020.  The new terms provide for collateralized and non-collateralized principal amounts not to exceed $1.0 billion Chinese renminbi and $1.8 billion Chinese renminbi, respectively, or equivalent amounts in U.S. dollars.  Outstanding borrowings under the collateralized portion of the China Revolving Credit Facility bear interest at the loan prime rate (“LPR”) less 0.2%, for borrowings denominated in Chinese renminbi, or LIBOR plus 1.0%, for borrowings denominated in U.S. dollars, and outstanding borrowings under the non-collateralized portion bear interest at LPR less 0.2%, for borrowings denominated in Chinese renminbi, or LIBOR plus 1.4%, for borrowings denominated in U.S. dollars.  The new facility expired on August 30, 2020.

- removed (2021-06-07):
[0001571996-20-000051:note_history:86]
During the fiscal year ended January 31, 2020, the Company renewed the credit agreement for its legacy China revolving credit facility with a bank lender, which provided an uncommitted line with an aggregate principal amount not to exceed $500 million at an interest rate of LIBOR plus 0.6% per annum.  The facility was terminated upon expiration on February 26, 2020.

- removed (2021-06-07):
[0001571996-20-000051:note_history:87]
VMware Term Loan Facility — On September 26, 2019, VMware, Inc. entered into a senior unsecured term loan facility (the “VMware Term Loan Facility”) with a syndicate of lenders that provided VMware, Inc. with a borrowing capacity of up to $2.0 billion through February 7, 2020, for VMware, Inc. general corporate purposes.  During the three months ended October 30, 2020, VMware, Inc. repaid the outstanding borrowings of $1.5 billion under the VMware Term Loan Facility.

- removed (2021-06-07):
[0001571996-20-000051:note_history:88]
As of January 31, 2020, the outstanding borrowings under the VMware Term Loan Facility were $1.5 billion.  None of the net proceeds of such borrowings were made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.

- removed (2021-06-07):
[0001571996-20-000051:note_history:89]
During the three months ended May 1, 2020, due to volatility in the U.S. stock market resulting from the outbreak of COVID-19, VMware Holdco LLC proactively pledged additional shares of VMware, Inc. common stock to secure its obligations under the Margin Loan Facility agreement.  This resulted in an aggregate number of shares pledged of approximately 76 million shares of Class B common stock of VMware, Inc. and approximately 24 million shares of Class A common stock of VMware, Inc.


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-06-07):
[0001571996-21-000026:note_history:90]
|  | April 30, 2021 |  | January 29, 2021 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Secured Credit Facilities | $ | 6.2 |  |  | $ | 6.3 |  |  | $ | 6.2 |  |  | $ | 6.3 |  |
| First Lien Notes | $ | 18.3 |  |  | $ | 22.7 |  |  | $ | 18.3 |  |  | $ | 22.8 |  |
| Unsecured Notes and Debentures | $ | 0.8 |  |  | $ | 1.2 |  |  | $ | 1.2 |  |  | $ | 1.6 |  |
| Senior Notes | $ | 1.6 |  |  | $ | 1.7 |  |  | $ | 2.7 |  |  | $ | 2.8 |  |
| EMC Notes | $ | 1.0 |  |  | $ | 1.0 |  |  | $ | 1.0 |  |  | $ | 1.0 |  |
| VMware Notes | $ | 4.7 |  |  | $ | 5.2 |  |  | $ | 4.7 |  |  | $ | 5.3 |  |
| Margin Loan Facility | $ | 4.0 |  |  | $ | 3.9 |  |  | $ | 4.0 |  |  | $ | 3.9 |  |
  (was, 2020-12-07, similarity 0.8864):
[0001571996-20-000051:note_history:90]
|  | October 30, 2020 |  | January 31, 2020 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Secured Credit Facilities | $ | 8.6 |  |  | $ | 8.6 |  |  | $ | 8.8 |  |  | $ | 9.0 |  |
| First Lien Notes | $ | 18.3 |  |  | $ | 22.0 |  |  | $ | 20.5 |  |  | $ | 23.9 |  |
| Unsecured Notes and Debentures | $ | 1.2 |  |  | $ | 1.5 |  |  | $ | 1.2 |  |  | $ | 1.5 |  |
| Senior Notes | $ | 2.6 |  |  | $ | 2.8 |  |  | $ | 2.6 |  |  | $ | 2.8 |  |
| EMC Notes | $ | 1.0 |  |  | $ | 1.0 |  |  | $ | 1.6 |  |  | $ | 1.6 |  |
| VMware Notes and VMware Term Loan Facility | $ | 4.7 |  |  | $ | 5.3 |  |  | $ | 5.5 |  |  | $ | 5.6 |  |
| Margin Loan Facility | $ | 4.0 |  |  | $ | 3.9 |  |  | $ | 4.0 |  |  | $ | 3.9 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-06-07):
[0001571996-21-000026:note_history:91]
|  | April 30, 2021 |  | January 29, 2021 |
|  | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing and securitization facilities | $ | 2,674 |  |  | $ | 3,311 |  |
| Fixed-term securitization offerings | 3,548 |  |  | 2,961 |  |
| Other | 198 |  |  | 140 |  |
| Total DFS U.S. debt | 6,420 |  |  | 6,412 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 784 |  |  | 786 |  |
| Other borrowings | 1,087 |  |  | 1,006 |  |
| Note payable | 250 |  |  | 250 |  |
| Dell Bank Senior Unsecured Eurobonds | 1,212 |  |  | 1,212 |  |
| Total DFS international debt | 3,333 |  |  | 3,254 |  |
| Total DFS debt | $ | 9,753 |  |  | $ | 9,666 |  |
| Total short-term DFS debt | $ | 4,673 |  |  | $ | 4,888 |  |
| Total long-term DFS debt | $ | 5,080 |  |  | $ | 4,778 |  |
  (was, 2020-12-07, similarity 0.9909):
[0001571996-20-000051:note_history:91]
|  | October 30, 2020 |  | January 31, 2020 |
|  | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing and securitization facilities | $ | 2,574 |  |  | $ | 2,606 |  |
| Fixed-term securitization offerings | 3,465 |  |  | 2,593 |  |
| Other | 94 |  |  | 141 |  |
| Total DFS U.S. debt | 6,133 |  |  | 5,340 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 860 |  |  | 743 |  |
| Other borrowings | 791 |  |  | 931 |  |
| Note payable | 250 |  |  | 200 |  |
| Dell Bank Senior Unsecured Eurobonds | 1,167 |  |  | 551 |  |
| Total DFS international debt | 3,068 |  |  | 2,425 |  |
| Total DFS debt | $ | 9,201 |  |  | $ | 7,765 |  |
| Total short-term DFS debt | $ | 4,884 |  |  | $ | 4,152 |  |
| Total long-term DFS debt | $ | 4,317 |  |  | $ | 3,613 |  |

- added (2021-06-07):
[0001571996-21-000026:note_history:92]
|  | April 30, 2021 |  | January 29, 2021 |
|  | (in millions) |
| Secured Debt |  |  |  |
| Senior Secured Credit Facilities: |  |  |  |
| 2.00% Term Loan B-2 Facility due September 2025 | $ | 3,135 |  |  | $ | 3,143 |  |
| 1.90% Term Loan A-6 Facility due March 2024 | 3,134 |  |  | 3,134 |  |
| First Lien Notes: |  |  |  |
| 5.45% due June 2023 | 3,750 |  |  | 3,750 |  |
| 4.00% due July 2024 | 1,000 |  |  | 1,000 |  |
| 5.85% due July 2025 | 1,000 |  |  | 1,000 |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 4.90% due October 2026 | 1,750 |  |  | 1,750 |  |
| 6.10% due July 2027 | 500 |  |  | 500 |  |
| 5.30% due October 2029 | 1,750 |  |  | 1,750 |  |
| 6.20% due July 2030 | 750 |  |  | 750 |  |
| 8.10% due July 2036 | 1,500 |  |  | 1,500 |  |
| 8.35% due July 2046 | 2,000 |  |  | 2,000 |  |
| Unsecured Debt |  |  |  |
| Unsecured Notes and Debentures: |  |  |  |
| 4.625% due April 2021 | — |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| Senior Notes: |  |  |  |
| 5.875% due June 2021 | — |  |  | 1,075 |  |
| 7.125% due June 2024 | 1,625 |  |  | 1,625 |  |
| EMC Notes: |  |  |  |
| 3.375% due June 2023 | 1,000 |  |  | 1,000 |  |
| Debt of Public Subsidiary |  |  |  |
| VMware Notes: |  |  |  |
| 2.95% due August 2022 | 1,500 |  |  | 1,500 |  |
| 4.50% due May 2025 | 750 |  |  | 750 |  |
| 4.65% due May 2027 | 500 |  |  | 500 |  |
| 3.90% due August 2027 | 1,250 |  |  | 1,250 |  |
| 4.70% due May 2030 | 750 |  |  | 750 |  |
| DFS Debt (Note 3) | 9,753 |  |  | 9,666 |  |
| Other |  |  |  |
| 2.46% Margin Loan Facility due April 2022 | 4,000 |  |  | 4,000 |  |
| Other | 304 |  |  | 235 |  |
| Total debt, principal amount | $ | 47,153 |  |  | $ | 48,480 |  |

- changed (2021-06-07):
[0001571996-21-000026:note_history:93]
|  | April 30, 2021 |  | January 29, 2021 |
|  | (in millions) |
| Total debt, principal amount | $ | 47,153 |  |  | $ | 48,480 |  |
| Unamortized discount, net of unamortized premium | (185) |  |  | (194) |  |
| Debt issuance costs | (285) |  |  | (302) |  |
| Total debt, carrying value | $ | 46,683 |  |  | $ | 47,984 |  |
| Total short-term debt, carrying value | $ | 8,748 |  |  | $ | 6,362 |  |
| Total long-term debt, carrying value | $ | 37,935 |  |  | $ | 41,622 |  |
  (was, 2020-12-07, similarity 0.985):
[0001571996-20-000051:note_history:93]
|  | October 30, 2020 |  | January 31, 2020 |
|  | (in millions) |
| Total debt, principal amount | $ | 50,411 |  |  | $ | 52,665 |  |
| Unamortized discount, net of unamortized premium | (217) |  |  | (241) |  |
| Debt issuance costs | (333) |  |  | (368) |  |
| Total debt, carrying value | $ | 49,861 |  |  | $ | 52,056 |  |
| Total short-term debt, carrying value | $ | 6,536 |  |  | $ | 7,737 |  |
| Total long-term debt, carrying value | $ | 43,325 |  |  | $ | 44,319 |  |

- removed (2021-06-07):
[0001571996-20-000051:note_history:94]
|  | October 30, 2020 |  | January 31, 2020 |
|  | (in millions) |
| Secured Debt |  |  |  |
| Senior Secured Credit Facilities: |  |  |  |
| 2.75% Term Loan B-1 Facility due September 2025 | $ | 4,691 |  |  | $ | 4,738 |  |
| 1.90% Term Loan A-4 Facility due December 2023 | 679 |  |  | 679 |  |
| 1.90% Term Loan A-6 Facility due March 2024 | 3,316 |  |  | 3,497 |  |
| First Lien Notes: |  |  |  |
| 4.42% due June 2021 | — |  |  | 4,500 |  |
| 5.45% due June 2023 | 3,750 |  |  | 3,750 |  |
| 4.00% due July 2024 | 1,000 |  |  | 1,000 |  |
| 5.85% due July 2025 | 1,000 |  |  | — |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 4.90% due October 2026 | 1,750 |  |  | 1,750 |  |
| 6.10% due July 2027 | 500 |  |  | — |  |
| 5.30% due October 2029 | 1,750 |  |  | 1,750 |  |
| 6.20% due July 2030 | 750 |  |  | — |  |
| 8.10% due July 2036 | 1,500 |  |  | 1,500 |  |
| 8.35% due July 2046 | 2,000 |  |  | 2,000 |  |
| Unsecured Debt |  |  |  |
| Unsecured Notes and Debentures: |  |  |  |
| 4.625% due April 2021 | 400 |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| Senior Notes: |  |  |  |
| 5.875% due June 2021 | 1,075 |  |  | 1,075 |  |
| 7.125% due June 2024 | 1,625 |  |  | 1,625 |  |
| EMC Notes: |  |  |  |
| 2.650% due June 2020 | — |  |  | 600 |  |
| 3.375% due June 2023 | 1,000 |  |  | 1,000 |  |
| Debt of Public Subsidiary |  |  |  |
| VMware Notes: |  |  |  |
| 2.30% due August 2020 | — |  |  | 1,250 |  |
| 2.95% due August 2022 | 1,500 |  |  | 1,500 |  |
| 4.50% due May 2025 | 750 |  |  | — |  |
| 4.65% due May 2027 | 500 |  |  | — |  |
| 3.90% due August 2027 | 1,250 |  |  | 1,250 |  |
| 4.70% due May 2030 | 750 |  |  | — |  |
| VMware Term Loan Facility | — |  |  | 1,500 |  |
| DFS Debt (Note 4) | 9,201 |  |  | 7,765 |  |
| Other |  |  |  |
| 2.46% Margin Loan Facility due April 2022 | 4,000 |  |  | 4,000 |  |
| Other | 222 |  |  | 84 |  |
| Total debt, principal amount | $ | 50,411 |  |  | $ | 52,665 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-06-07):
[0001571996-21-000026:note_history:95]
The following table presents the aggregate future maturities of the Company’s debt as of April 30, 2021 for the periods indicated:
  (was, 2020-12-07, similarity 0.9603):
[0001571996-20-000051:note_history:95]
The following table presents the aggregate future maturities of the Company’s debt as of October 30, 2020 for the periods indicated:

- changed (2021-06-07):
[0001571996-21-000026:note_history:96]
|  | Maturities by Fiscal Year |
|  | 2022(remaining nine months) |  | 2023 |  | 2024 |  | 2025 |  | 2026 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Secured Credit Facilities and First Lien Notes | $ | 31 |  |  | $ | 213 |  |  | $ | 6,007 |  |  | $ | 1,758 |  |  | $ | 4,017 |  |  | $ | 12,743 |  |  | $ | 24,769 |  |
| Unsecured Notes and Debentures | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 952 |  |  | 952 |  |
| Senior Notes and EMC Notes | — |  |  | — |  |  | 1,000 |  |  | 1,625 |  |  | — |  |  | — |  |  | 2,625 |  |
| VMware Notes | — |  |  | 1,500 |  |  | — |  |  | — |  |  | 750 |  |  | 2,500 |  |  | 4,750 |  |
| DFS Debt | 3,844 |  |  | 4,249 |  |  | 774 |  |  | 850 |  |  | 36 |  |  | — |  |  | 9,753 |  |
| Margin Loan Facility | — |  |  | 4,000 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 4,000 |  |
| Other | 11 |  |  | 11 |  |  | 171 |  |  | 78 |  |  | 8 |  |  | 25 |  |  | 304 |  |
| Total maturities, principal amount | 3,886 |  |  | 9,973 |  |  | 7,952 |  |  | 4,311 |  |  | 4,811 |  |  | 16,220 |  |  | 47,153 |  |
| Associated carrying value adjustments | (6) |  |  | (15) |  |  | (32) |  |  | (71) |  |  | (47) |  |  | (299) |  |  | (470) |  |
| Total maturities, carrying value amount | $ | 3,880 |  |  | $ | 9,958 |  |  | $ | 7,920 |  |  | $ | 4,240 |  |  | $ | 4,764 |  |  | $ | 15,921 |  |  | $ | 46,683 |  |
  (was, 2020-12-07, similarity 0.9328):
[0001571996-20-000051:note_history:96]
|  | Maturities by Fiscal Year |
|  | 2021 (remaining three months) |  | 2022 |  | 2023 |  | 2024 |  | 2025 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Secured Credit Facilities and First Lien Notes | $ | — |  |  | $ | 172 |  |  | $ | 286 |  |  | $ | 7,384 |  |  | $ | 1,047 |  |  | $ | 18,297 |  |  | $ | 27,186 |  |
| Unsecured Notes and Debentures | — |  |  | 400 |  |  | — |  |  | — |  |  | — |  |  | 952 |  |  | 1,352 |  |
| Senior Notes and EMC Notes | — |  |  | 1,075 |  |  | — |  |  | 1,000 |  |  | 1,625 |  |  | — |  |  | 3,700 |  |
| VMware Notes | — |  |  | — |  |  | 1,500 |  |  | — |  |  | — |  |  | 3,250 |  |  | 4,750 |  |
| DFS Debt | 2,012 |  |  | 3,481 |  |  | 2,654 |  |  | 356 |  |  | 692 |  |  | 6 |  |  | 9,201 |  |
| Margin Loan Facility | — |  |  | — |  |  | 4,000 |  |  | — |  |  | — |  |  | — |  |  | 4,000 |  |
| Other | 3 |  |  | 12 |  |  | 12 |  |  | 156 |  |  | 8 |  |  | 31 |  |  | 222 |  |
| Total maturities, principal amount | 2,015 |  |  | 5,140 |  |  | 8,452 |  |  | 8,896 |  |  | 3,372 |  |  | 22,536 |  |  | 50,411 |  |
| Associated carrying value adjustments | (1) |  |  | (10) |  |  | (14) |  |  | (38) |  |  | (83) |  |  | (404) |  |  | (550) |  |
| Total maturities, carrying value amount | $ | 2,014 |  |  | $ | 5,130 |  |  | $ | 8,438 |  |  | $ | 8,858 |  |  | $ | 3,289 |  |  | $ | 22,132 |  |  | $ | 49,861 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-06-07):
[0001571996-21-000026:note_history:97]
|  | Three Months Ended |  |  |
|  | April 30, 2021 |  | May 1, 2020 |  |  |  |  |
|  | (in millions) |
| Net revenue: |  |  |  |  |  |  |  |
| Infrastructure Solutions Group: |  |  |  |  |  |  |  |
| Servers and networking | $ | 4,109 |  |  | $ | 3,758 |  |  |  |  |  |
| Storage | 3,802 |  |  | 3,811 |  |  |  |  |  |
| Total ISG net revenue | 7,911 |  |  | 7,569 |  |  |  |  |  |
| Client Solutions Group: |  |  |  |  |  |  |  |
| Commercial | 9,803 |  |  | 8,634 |  |  |  |  |  |
| Consumer | 3,502 |  |  | 2,470 |  |  |  |  |  |
| Total CSG net revenue | 13,305 |  |  | 11,104 |  |  |  |  |  |
| VMware: |  |  |  |  |  |  |  |
| Total VMware net revenue | 2,991 |  |  | 2,755 |  |  |  |  |  |
| Total segment net revenue | $ | 24,207 |  |  | $ | 21,428 |  |  |  |  |  |
  (was, 2020-12-07, similarity 0.8323):
[0001571996-20-000051:note_history:97]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 30, 2020 |  | November 1, 2019 |  | October 30, 2020 |  | November 1, 2019 |
|  | (in millions) |
| Net revenue: |  |  |  |  |  |  |  |
| Infrastructure Solutions Group: |  |  |  |  |  |  |  |
| Servers and networking | $ | 4,164 |  |  | $ | 4,241 |  |  | $ | 12,118 |  |  | $ | 12,858 |  |
| Storage | 3,860 |  |  | 4,149 |  |  | 11,682 |  |  | 12,355 |  |
| Total ISG net revenue | 8,024 |  |  | 8,390 |  |  | 23,800 |  |  | 25,213 |  |
| Client Solutions Group: |  |  |  |  |  |  |  |
| Commercial | 8,783 |  |  | 8,330 |  |  | 25,456 |  |  | 25,714 |  |
| Consumer | 3,503 |  |  | 3,080 |  |  | 9,137 |  |  | 8,354 |  |
| Total CSG net revenue | 12,286 |  |  | 11,410 |  |  | 34,593 |  |  | 34,068 |  |
| VMware: |  |  |  |  |  |  |  |
| Total VMware net revenue | 2,893 |  |  | 2,671 |  |  | 8,556 |  |  | 7,779 |  |
| Total segment net revenue | $ | 23,203 |  |  | $ | 22,471 |  |  | $ | 66,949 |  |  | $ | 67,060 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-06-07):
[0001571996-21-000026:note_history:98]
|  | Three Months Ended |  |  |
|  | April 30, 2021 |  | May 1, 2020 |  |  |  |  |
|  | (in millions) |
| Deferred revenue: |  |  |  |  |  |  |  |
| Deferred revenue at beginning of period | $ | 30,801 |  |  | $ | 27,800 |  |  |  |  |  |
| Revenue deferrals | 6,480 |  |  | 5,423 |  |  |  |  |  |
| Revenue recognized | (5,905) |  |  | (5,356) |  |  |  |  |  |
| Other (a) | — |  |  | (250) |  |  |  |  |  |
| Deferred revenue at end of period | $ | 31,376 |  |  | $ | 27,617 |  |  |  |  |  |
| Short-term deferred revenue | $ | 16,835 |  |  | $ | 14,766 |  |  |  |  |  |
| Long-term deferred revenue | $ | 14,541 |  |  | $ | 12,851 |  |  |  |  |  |
  (was, 2020-12-07, similarity 0.7844):
[0001571996-20-000051:note_history:98]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 30, 2020 |  | November 1, 2019 |  | October 30, 2020 |  | November 1, 2019 |
|  | (in millions) |
| Deferred revenue: |  |  |  |  |  |  |  |
| Deferred revenue at beginning of period | $ | 28,791 |  |  | $ | 25,348 |  |  | $ | 27,800 |  |  | $ | 24,010 |  |
| Revenue deferrals | 5,432 |  |  | 5,326 |  |  | 17,560 |  |  | 16,201 |  |
| Revenue recognized | (5,542) |  |  | (4,922) |  |  | (16,418) |  |  | (14,459) |  |
| Other (a) (b) | — |  |  | 151 |  |  | (261) |  |  | 151 |  |
| Deferred revenue at end of period | $ | 28,681 |  |  | $ | 25,903 |  |  | $ | 28,681 |  |  | $ | 25,903 |  |
| Short-term deferred revenue | $ | 15,259 |  |  | $ | 13,787 |  |  | $ | 15,259 |  |  | $ | 13,787 |  |
| Long-term deferred revenue | $ | 13,422 |  |  | $ | 12,116 |  |  | $ | 13,422 |  |  | $ | 12,116 |  |

- added (2021-06-07):
[0001571996-21-000026:note_history:99]
(a) For the three months ended May 1, 2020, Other represents the reclassification of RSA Security deferred revenue to liabilities held for sale. See Note 1 of the Notes to the Condensed Consolidated Financial Statements for more information about the divestiture of RSA Security.

- changed (2021-06-07):
[0001571996-21-000026:note_history:100]
Remaining Performance Obligations — Remaining performance obligations represent the aggregate amount of the transaction price allocated to performance obligations not delivered, or partially undelivered, as of the end of the reporting period.  Remaining performance obligations include deferred revenue plus unbilled amounts not yet recorded in deferred revenue.  The value of the transaction price allocated to remaining performance obligations as of April 30, 2021 was approximately $42 billion.  The Company expects to recognize approximately 61% of remaining performance obligations as revenue in the next twelve months, and the remainder thereafter.
  (was, 2020-12-07, similarity 0.9907):
[0001571996-20-000051:note_history:100]
Remaining Performance Obligations — Remaining performance obligations represent the aggregate amount of the transaction price allocated to performance obligations not delivered, or partially undelivered, as of the end of the reporting period.  Remaining performance obligations include deferred revenue plus unbilled amounts not yet recorded in deferred revenue.  The value of the transaction price allocated to remaining performance obligations as of October 30, 2020 was approximately $38 billion.  The Company expects to recognize approximately 63% of remaining performance obligations as revenue in the next twelve months, and the remainder thereafter.

- changed (2021-06-07):
[0001571996-21-000026:note_history:101]
The aggregate amount of the transaction price allocated to remaining performance obligations does not include amounts owed under cancellable contracts where there is no substantive termination penalty.  The Company applied the practical expedient to exclude the value of remaining performance obligations for contracts for which revenue is recognized at the amount to which the Company has the right to invoice for services performed.
  (was, 2020-12-07, similarity 0.9988):
[0001571996-20-000051:note_history:101]
The aggregate amount of the transaction price allocated to remaining performance obligations does not include amounts owed under cancelable contracts where there is no substantive termination penalty.  The Company applied the practical expedient to exclude the value of remaining performance obligations for contracts for which revenue is recognized at the amount to which the Company has the right to invoice for services performed.

- removed (2021-06-07):
[0001571996-20-000051:note_history:102]
(a) For the nine months ended October 30, 2020, Other consists of divested deferred revenue from the sale of RSA Security.  See Note 1 of the Notes to the Condensed Consolidated Financial Statements for more information about the divestiture of RSA Security.  For the three months ended October 30, 2020, there was no impact to deferred revenue because RSA Security was previously classified as held for sale.

- removed (2021-06-07):
[0001571996-20-000051:note_history:103]
(b) For the three and nine months ended November 1, 2019, Other consists of acquired deferred revenue from Carbon Black, Inc. by VMware, Inc.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2021-06-07):
[0001571996-21-000026:note_history:104]
NOTE 18 — SUBSEQUENT EVENTS

- added (2021-06-07):
[0001571996-21-000026:note_history:105]
Debt Repayment — Subsequent to April 30, 2021, the Company repaid $1 billion principal amount of the Margin Loan Facility due April 2022.

- added (2021-06-07):
[0001571996-21-000026:note_history:106]
Boomi Divestiture — On May 1, 2021, Dell Technologies announced its entry into a definitive agreement with Francisco Partners and TPG Capital to sell Boomi and certain related assets from the Company in a cash transaction valued at $4 billion, subject to certain closing adjustments.  The transaction is expected to close by the end of calendar 2021, subject to customary closing conditions.  The transaction is intended to support the Company’s focus on fueling growth by continuing to modernize Dell Technologies’ core infrastructure and PC businesses and by expanding in high-priority areas, including hybrid and private cloud, edge, telecom and Apex.

- added (2021-06-07):
[0001571996-21-000026:note_history:107]
Boomi is included within Other Businesses and does not meet the requirements for a reportable segment.

- added (2021-06-07):
[0001571996-21-000026:note_history:108]
Other than the matters identified above, there were no known events occurring after April 30, 2021 and up until the date of the issuance of this report that would materially affect the information presented herein.
