# DELL notes — 0001571996-21-000026


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001571996-21-000026:notes:1]
Basis of Presentation — The accompanying unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes filed with the U.S. Securities and Exchange Commission (“SEC”) in the Company’s Annual Report on Form 10-K for the fiscal year ended January 29, 2021.  These Condensed Consolidated Financial Statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“GAAP”).  In the opinion of management, the accompanying Condensed Consolidated Financial Statements reflect all adjustments of a normal recurring nature considered necessary to fairly state the financial position of Dell Technologies Inc. as of April 30, 2021 and January 29, 2021 and the results of its operations, corresponding comprehensive income (loss) and its cash flows for the three months ended April 30, 2021 and May 1, 2020.


## us-gaap:ConsolidationPolicyTextBlock

[0001571996-21-000026:notes:2]
[same as prior period, unchanged from 0001571996-20-000051:notes:2]


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001571996-21-000026:notes:3]
Recently Issued Accounting Pronouncements

[0001571996-21-000026:notes:4]
Reference Rate Reform — In March 2020, the Financial Accounting Standards Board (“FASB”) issued guidance which provides temporary optional expedients and exceptions to GAAP guidance on contract modifications and certain hedging relationships to ease the financial reporting burdens related to the expected market transition from the London Interbank Offered Rate to alternative reference rates.  The Company may elect to apply the amendments prospectively through December 31, 2022.  Adoption of the new guidance is not expected to have a material impact on the Company’s financial results.

[0001571996-21-000026:notes:5]
Recently Adopted Accounting Pronouncements

[0001571996-21-000026:notes:6]
Accounting for Convertible Instruments and Contracts in an Entity’s Own Equity — In August 2020, the Financial Accounting Standards Board (“FASB”) issued guidance to simplify the accounting for convertible debt instruments and convertible preferred stock, and the derivatives scope exception for contracts in an entity's own equity.  In addition, the guidance on calculating diluted earnings per share has been simplified and made more internally consistent.  The Company early adopted this standard as of January 30, 2021.  There was no impact on the Condensed Consolidated Financial Statements or to diluted earnings per share as of the adoption date.

[0001571996-21-000026:notes:7]
Simplifying Accounting for Income Taxes — In December 2019, the FASB issued guidance to simplify the accounting for income taxes by removing certain exceptions to the general principles in Topic 740, Income Taxes, and by clarifying and amending existing guidance in order to improve consistent application of GAAP for other areas of Topic 740.  The Company adopted the standard during the three months ended April 30, 2021.  The impact of the adoption of this standard was immaterial to the Condensed Consolidated Financial Statements.


## us-gaap:FairValueDisclosuresTextBlock

[0001571996-21-000026:notes:8]
NOTE 2 — FAIR VALUE MEASUREMENTS AND INVESTMENTS

[0001571996-21-000026:notes:9]
[same as prior period, unchanged from 0001571996-20-000051:notes:17]

[0001571996-21-000026:notes:10]
|  | April 30, 2021 |  | January 29, 2021 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | Quoted Prices in Active Markets for Identical Assets |  | Significant Other Observable Inputs |  | Significant Unobservable Inputs |  |  |  | Quoted Prices in Active Markets for Identical Assets |  | Significant Other Observable Inputs |  | Significant Unobservable Inputs |  |  |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 8,936 |  |  | $ | — |  |  | $ | — |  |  | $ | 8,936 |  |  | $ | 8,846 |  |  | $ | — |  |  | $ | — |  |  | $ | 8,846 |  |
| Equity and other securities | 327 |  |  | — |  |  | — |  |  | 327 |  |  | 449 |  |  | — |  |  | — |  |  | 449 |  |
| Derivative instruments | — |  |  | 69 |  |  | — |  |  | 69 |  |  | — |  |  | 104 |  |  | — |  |  | 104 |  |
| Total assets | $ | 9,263 |  |  | $ | 69 |  |  | $ | — |  |  | $ | 9,332 |  |  | $ | 9,295 |  |  | $ | 104 |  |  | $ | — |  |  | $ | 9,399 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative instruments | $ | — |  |  | $ | 103 |  |  | $ | — |  |  | $ | 103 |  |  | $ | — |  |  | $ | 133 |  |  | $ | — |  |  | $ | 133 |  |
| Total liabilities | $ | — |  |  | $ | 103 |  |  | $ | — |  |  | $ | 103 |  |  | $ | — |  |  | $ | 133 |  |  | $ | — |  |  | $ | 133 |  |

[0001571996-21-000026:notes:11]
[same as prior period, unchanged from 0001571996-20-000051:notes:19]

[0001571996-21-000026:notes:12]
Money Market Funds — The Company’s investments in money market funds that are classified as cash equivalents hold underlying investments with a weighted average maturity of 90 days or less and are recognized at fair value.  The valuations of these securities are based on quoted prices in active markets for identical assets, when available, or pricing models whereby all significant inputs are observable or can be derived from or corroborated by observable market data.  The Company reviews security pricing and assesses liquidity on a quarterly basis.  As of April 30, 2021, the Company’s U.S. portfolio had no material exposure to money market funds with a fluctuating net asset value.

[0001571996-21-000026:notes:13]
[same as prior period, unchanged from 0001571996-20-000051:notes:21]

[0001571996-21-000026:notes:14]
Derivative Instruments — The Company’s derivative financial instruments consist primarily of foreign currency forward and purchased option contracts and interest rate swaps.  The fair value of the portfolio is determined using valuation models based on market observable inputs, including interest rate curves, forward and spot prices for currencies, and implied volatilities.  Credit risk is also factored into the fair value calculation of the Company’s derivative financial instrument portfolio.  See Note 6 of the Notes to the Condensed Consolidated Financial Statements for a description of the Company’s derivative financial instrument activities.

[0001571996-21-000026:notes:15]
Deferred Compensation Plans — The Company offers deferred compensation plans for eligible employees, which allow participants to defer payment for a portion of their compensation.  Assets were the same as liabilities associated with the plans at approximately $340 million and $308 million as of April 30, 2021 and January 29, 2021, respectively, and are included in other assets and other liabilities on the Condensed Consolidated Statements of Financial Position.  The net impact to the Condensed Consolidated Statements of Income is not material since changes in the fair value of the assets substantially offset changes in the fair value of the liabilities.  As such, assets and liabilities associated with these plans have not been included in the recurring fair value table above.

[0001571996-21-000026:notes:16]
Assets and Liabilities Measured at Fair Value on a Nonrecurring Basis — Certain assets are measured at fair value on a nonrecurring basis and therefore are not included in the recurring fair value table above.  These assets consist primarily of non-financial assets such as goodwill and intangible assets.  See Note 7 of the Notes to the Condensed Consolidated Financial Statements for additional information about goodwill and intangible assets.

[0001571996-21-000026:notes:17]
As of April 30, 2021 and January 29, 2021, the Company held private strategic investments of $1.1 billion and $1.0 billion, respectively.  As these investments represent early-stage companies without readily determinable fair values, they are not included in the recurring fair value table above.

[0001571996-21-000026:notes:18]
[same as prior period, unchanged from 0001571996-20-000051:notes:26]

[0001571996-21-000026:notes:19]
Carrying Value and Estimated Fair Value of Outstanding Debt — The following table presents the carrying value and estimated fair value of the Company’s outstanding debt as described in Note 5 of the Notes to the Condensed Consolidated Financial Statements, including the current portion, as of the dates indicated:

[0001571996-21-000026:notes:20]
|  | April 30, 2021 |  | January 29, 2021 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Secured Credit Facilities | $ | 6.2 |  |  | $ | 6.3 |  |  | $ | 6.2 |  |  | $ | 6.3 |  |
| First Lien Notes | $ | 18.3 |  |  | $ | 22.7 |  |  | $ | 18.3 |  |  | $ | 22.8 |  |
| Unsecured Notes and Debentures | $ | 0.8 |  |  | $ | 1.2 |  |  | $ | 1.2 |  |  | $ | 1.6 |  |
| Senior Notes | $ | 1.6 |  |  | $ | 1.7 |  |  | $ | 2.7 |  |  | $ | 2.8 |  |
| EMC Notes | $ | 1.0 |  |  | $ | 1.0 |  |  | $ | 1.0 |  |  | $ | 1.0 |  |
| VMware Notes | $ | 4.7 |  |  | $ | 5.2 |  |  | $ | 4.7 |  |  | $ | 5.3 |  |
| Margin Loan Facility | $ | 4.0 |  |  | $ | 3.9 |  |  | $ | 4.0 |  |  | $ | 3.9 |  |

[0001571996-21-000026:notes:21]
The fair values of the outstanding debt shown in the table above, as well as the debt of Dell Financial Services (“DFS”) and its affiliates described in Note 3 of the Notes to the Condensed Consolidated Financial Statements, were determined based on observable market prices in a less active market or based on valuation methodologies using observable inputs and were categorized as Level 2 in the fair value hierarchy.  The carrying value of DFS debt approximates fair value.

[0001571996-21-000026:notes:22]
[same as prior period, unchanged from 0001571996-20-000051:notes:30]

[0001571996-21-000026:notes:23]
[same as prior period, unchanged from 0001571996-20-000051:notes:31]

[0001571996-21-000026:notes:24]
|  | April 30, 2021 |  | January 29, 2021 |
|  | Cost |  | Unrealized Gain |  | Unrealized (Loss) |  | Carrying Value |  | Cost |  | Unrealized Gain |  | Unrealized (Loss) |  | Carrying Value |
|  | (in millions) |
| Equity and other securities | $ | 1,328 |  |  | $ | 198 |  |  | $ | (121) |  |  | $ | 1,405 |  |  | $ | 907 |  |  | $ | 677 |  |  | $ | (145) |  |  | $ | 1,439 |  |
| Fixed income debt securities | 256 |  |  | 9 |  |  | — |  |  | 265 |  |  | 176 |  |  | 9 |  |  | — |  |  | 185 |  |
| Total securities |  |  |  |  |  |  | $ | 1,670 |  |  |  |  |  |  |  |  | $ | 1,624 |  |

[0001571996-21-000026:notes:25]
Equity and other securities — The Company has strategic investments in publicly-traded and privately-held companies.  For the three months ended April 30, 2021, the equity and other securities without readily determinable fair values of $1.1 billion increased by $198 million, primarily due to upward adjustments for observable price changes, offset by $26 million of downward adjustments primarily attributable to observable price changes.  The remainder of equity and other securities consists of publicly-traded investments that are measured at fair value on a recurring basis.

[0001571996-21-000026:notes:26]
[same as prior period, unchanged from 0001571996-20-000051:notes:35]


## dell:CreditLossFinancialInstrumentLeasesDebtVariableInterestEntitiesAndCustomerReceivablesSalesTextBlock

[0001571996-21-000026:notes:27]
NOTE 3 — FINANCIAL SERVICES

[0001571996-21-000026:notes:28]
The Company offers or arranges various financing options, services, and alternative payment structures for its customers in North America, Europe, Australia, and New Zealand through Dell Financial Services and its affiliates (“DFS”).  The Company also arranges financing for some of its customers in various countries where DFS does not currently operate as a captive enterprise.  The key activities of DFS include originating, collecting, and servicing customer financing arrangements primarily related to the purchase or use of Dell Technologies products and services.  In some cases, DFS also offers financing on the purchase of third-party technology products that complement the Dell Technologies portfolio of products and services.  New financing originations were $1.9 billion and $1.8 billion for the three months ended April 30, 2021 and May 1, 2020, respectively.

[0001571996-21-000026:notes:29]
The Company’s loan and lease arrangements with customers are aggregated into the following categories:

[0001571996-21-000026:notes:30]
Revolving loans — Revolving loans offered under private label credit financing programs provide qualified customers with a revolving credit line for the purchase of products and services offered by Dell Technologies.  These private label credit financing programs are referred to as Dell Preferred Account (“DPA”) and Dell Business Credit (“DBC”).  The DPA product is primarily offered to individual consumer customers, and the DBC product is primarily offered to small and medium-sized commercial customers.  Revolving loans in the United States bear interest at a variable annual percentage rate that is tied to the prime rate.  Based on historical payment patterns, revolving loan transactions are typically repaid within twelve months on average.  Due to the short-term nature of the revolving loan portfolio, the carrying value of the portfolio approximates fair value.

[0001571996-21-000026:notes:31]
Fixed-term leases and loans — The Company enters into financing arrangements with customers who seek lease financing for equipment.  Pursuant to the current lease accounting standard effective February 2, 2019, new DFS leases are classified as sales-type leases, direct financing leases, or operating leases.  Direct financing leases are immaterial.  Leases that commenced prior to the effective date of the current lease accounting standard continue to be accounted for under previous lease accounting guidance.  Leases with business customers have fixed terms of generally two to four years.

[0001571996-21-000026:notes:32]
The Company also offers fixed-term loans to qualified small businesses, large commercial accounts, governmental organizations, educational entities, and certain individual consumer customers.  These loans are repaid in equal payments including interest and have defined terms of generally three to five years.  The fair value of the fixed-term loan portfolio is determined using market observable inputs.  The carrying value of these loans approximates fair value.

[0001571996-21-000026:notes:33]
Financing Receivables

[0001571996-21-000026:notes:34]
The following table presents the components of the Company’s financing receivables segregated by portfolio segment as of the dates indicated:

[0001571996-21-000026:notes:35]
|  | April 30, 2021 |  | January 29, 2021 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Financing receivables, net: |  |  |  |  |  |  |  |  |  |  |  |
| Customer receivables, gross (a) | $ | 752 |  |  | $ | 9,438 |  |  | $ | 10,190 |  |  | $ | 796 |  |  | $ | 9,595 |  |  | $ | 10,391 |  |
| Allowances for losses | (139) |  |  | (177) |  |  | (316) |  |  | (148) |  |  | (173) |  |  | (321) |  |
| Customer receivables, net | 613 |  |  | 9,261 |  |  | 9,874 |  |  | 648 |  |  | 9,422 |  |  | 10,070 |  |
| Residual interest | — |  |  | 367 |  |  | 367 |  |  | — |  |  | 424 |  |  | 424 |  |
| Financing receivables, net | $ | 613 |  |  | $ | 9,628 |  |  | $ | 10,241 |  |  | $ | 648 |  |  | $ | 9,846 |  |  | $ | 10,494 |  |
| Short-term | $ | 613 |  |  | $ | 4,367 |  |  | $ | 4,980 |  |  | $ | 648 |  |  | $ | 4,507 |  |  | $ | 5,155 |  |
| Long-term | $ | — |  |  | $ | 5,261 |  |  | $ | 5,261 |  |  | $ | — |  |  | $ | 5,339 |  |  | $ | 5,339 |  |

[0001571996-21-000026:notes:36]
____________________

[0001571996-21-000026:notes:37]
(a)    Customer receivables, gross includes amounts due from customers under revolving loans, fixed-term loans, fixed-term sales-type or direct financing leases, and accrued interest.

[0001571996-21-000026:notes:38]
The following tables present the changes in allowance for financing receivable losses for the periods indicated:

[0001571996-21-000026:notes:39]
|  | Three Months Ended |
|  | April 30, 2021 |  | May 1, 2020 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |  |  |  |  |  |  |  |  |  |  |  |
| Balances at beginning of period | $ | 148 |  |  | $ | 173 |  |  | $ | 321 |  |  | $ | 70 |  |  | $ | 79 |  |  | $ | 149 |  |
| Adjustment for adoption of accounting standard (a) | — |  |  | — |  |  | — |  |  | 40 |  |  | 71 |  |  | 111 |  |
| Charge-offs, net of recoveries | (13) |  |  | (2) |  |  | (15) |  |  | (20) |  |  | (9) |  |  | (29) |  |
| Provision charged to income statement | 4 |  |  | 6 |  |  | 10 |  |  | 54 |  |  | 36 |  |  | 90 |  |
| Balances at end of period | $ | 139 |  |  | $ | 177 |  |  | $ | 316 |  |  | $ | 144 |  |  | $ | 177 |  |  | $ | 321 |  |

[0001571996-21-000026:notes:40]
(a)    The Company adopted the current expected credit losses standard as of February 1, 2020 using the modified retrospective method, with the cumulative-effect adjustment to the opening balance of stockholders’ equity (deficit) as of the adoption date.

[0001571996-21-000026:notes:41]
Aging

[0001571996-21-000026:notes:42]
The following table presents the aging of the Company’s customer financing receivables, gross, including accrued interest, segregated by class, as of the dates indicated:

[0001571996-21-000026:notes:43]
|  | April 30, 2021 |  | January 29, 2021 |
|  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |
|  | (in millions) |
| Revolving — DPA | $ | 549 |  |  | $ | 21 |  |  | $ | 10 |  |  | $ | 580 |  |  | $ | 578 |  |  | $ | 30 |  |  | $ | 13 |  |  | $ | 621 |  |
| Revolving — DBC | 158 |  |  | 11 |  |  | 3 |  |  | 172 |  |  | 157 |  |  | 14 |  |  | 4 |  |  | 175 |  |
| Fixed-term — Consumer and Commercial | 9,035 |  |  | 346 |  |  | 57 |  |  | 9,438 |  |  | 9,192 |  |  | 316 |  |  | 87 |  |  | 9,595 |  |
| Total customer receivables, gross | $ | 9,742 |  |  | $ | 378 |  |  | $ | 70 |  |  | $ | 10,190 |  |  | $ | 9,927 |  |  | $ | 360 |  |  | $ | 104 |  |  | $ | 10,391 |  |

[0001571996-21-000026:notes:44]
Aging is likely to fluctuate as a result of the variability in volume of large transactions entered into over the period, and the administrative processes that accompany those larger transactions.  Aging is also impacted by the timing of the Dell Technologies fiscal period end date, relative to calendar month-end customer payment due dates.  As a result of these factors, fluctuations in aging from period to period do not necessarily indicate a material change in the collectibility of the portfolio.

[0001571996-21-000026:notes:45]
Fixed-term consumer and commercial customer receivables are placed on non-accrual status if principal or interest is past due and considered delinquent, or if there is concern about collectibility of a specific customer receivable.  These receivables identified as doubtful for collectibility may be classified as current for aging purposes.  Aged revolving portfolio customer receivables identified as delinquent are charged off.  Receivables are moved back to accrual status when the collection of  interest is probable, or the collection of the net investment is no longer doubtful.

[0001571996-21-000026:notes:46]
Credit Quality

[0001571996-21-000026:notes:47]
The following tables presents customer receivables, gross, including accrued interest, by credit quality indicator segregated by class and year of origination, as of the dates indicated:

[0001571996-21-000026:notes:48]
|  | April 30, 2021 |
|  | Fixed-term — Consumer and Commercial |  |  |  |  |  |  |
|  | Fiscal Year of Origination |  |  |  |  |  |  |
|  | 2022 |  | 2021 |  | 2020 |  | 2019 |  | 2018 |  | Years Prior |  | Revolving — DPA (a) |  | Revolving — DBC (a) |  | Total |
|  | (in millions) |
| Higher | $ | 1,057 |  |  | $ | 2,597 |  |  | $ | 1,520 |  |  | $ | 486 |  |  | $ | 107 |  |  | $ | 13 |  |  | $ | 153 |  |  | $ | 45 |  |  | $ | 5,978 |  |
| Mid | 286 |  |  | 1,000 |  |  | 553 |  |  | 190 |  |  | 45 |  |  | 4 |  |  | 176 |  |  | 51 |  |  | 2,305 |  |
| Lower | 238 |  |  | 728 |  |  | 419 |  |  | 163 |  |  | 27 |  |  | 5 |  |  | 251 |  |  | 76 |  |  | 1,907 |  |
| Total | $ | 1,581 |  |  | $ | 4,325 |  |  | $ | 2,492 |  |  | $ | 839 |  |  | $ | 179 |  |  | $ | 22 |  |  | $ | 580 |  |  | $ | 172 |  |  | $ | 10,190 |  |

[0001571996-21-000026:notes:49]
|  | January 29, 2021 |
|  | Fixed-term — Consumer and Commercial |  |  |  |  |  |  |
|  | Fiscal Year of Origination |  |  |  |  |  |  |
|  | 2021 |  | 2020 |  | 2019 |  | 2018 |  | 2017 |  | Years Prior |  | Revolving — DPA (a) |  | Revolving — DBC (a) |  | Total |
|  | (in millions) |
| Higher | $ | 3,125 |  |  | $ | 1,802 |  |  | $ | 661 |  |  | $ | 166 |  |  | $ | 26 |  |  | $ | — |  |  | $ | 172 |  |  | $ | 47 |  |  | $ | 5,999 |  |
| Mid | 1,121 |  |  | 671 |  |  | 287 |  |  | 73 |  |  | 9 |  |  | — |  |  | 188 |  |  | 52 |  |  | 2,401 |  |
| Lower | 865 |  |  | 499 |  |  | 243 |  |  | 38 |  |  | 9 |  |  | — |  |  | 261 |  |  | 76 |  |  | 1,991 |  |
| Total | $ | 5,111 |  |  | $ | 2,972 |  |  | $ | 1,191 |  |  | $ | 277 |  |  | $ | 44 |  |  | $ | — |  |  | $ | 621 |  |  | $ | 175 |  |  | $ | 10,391 |  |

[0001571996-21-000026:notes:50]
(a)    The revolving portfolio is exempt from the requirement to disclose the amortized cost basis by year of origination since determining the appropriate origination year can be complex due to the nature of the revolving portfolio.

[0001571996-21-000026:notes:51]
The categories shown in the tables above segregate customer receivables based on the relative degrees of credit risk.  The credit quality indicators for DPA revolving accounts are measured primarily as of each quarter-end date, while all other indicators are generally updated on a periodic basis.

[0001571996-21-000026:notes:52]
For DPA revolving receivables shown in the table above, the Company makes credit decisions based on proprietary scorecards, which include the customer’s credit history, payment history, credit usage, and other credit agency-related elements.  The higher quality category includes prime accounts generally of a higher credit quality that are comparable to U.S. customer FICO scores of 720 or above.  The mid-category represents the mid-tier accounts that are comparable to U.S. customer FICO scores from 660 to 719.  The lower category is generally sub-prime and represents lower credit quality accounts that are comparable to U.S. customer FICO scores below 660.  For the DBC revolving receivables and fixed-term commercial receivables shown in the table above, an internal grading system is utilized that assigns a credit level score based on a number of considerations, including liquidity, operating performance, and industry outlook.  The grading criteria and classifications for the fixed-term products differ from those for the revolving products as loss experience varies between these product and customer groups.  The credit quality categories cannot be compared between the different classes as loss experience varies substantially between the classes.

[0001571996-21-000026:notes:53]
Leases

[0001571996-21-000026:notes:54]
Interest income on sales-type lease receivables was $64 million and $65 million for the three months ended April 30, 2021 and May 1, 2020, respectively.

[0001571996-21-000026:notes:55]
The following table presents the net revenue, cost of net revenue, and gross margin recognized at the commencement date of sales-type leases for the periods indicated:

[0001571996-21-000026:notes:56]
|  | Three Months Ended |  |  |
|  | April 30, 2021 |  | May 1, 2020 |  |  |  |  |
|  | (in millions) |
| Net revenue — products | $ | 230 |  |  | $ | 215 |  |  |  |  |  |
| Cost of net revenue — products | 163 |  |  | 159 |  |  |  |  |  |
| Gross margin — products | $ | 67 |  |  | $ | 56 |  |  |  |  |  |

[0001571996-21-000026:notes:57]
The following table presents the future maturity of the Company’s fixed-term customer leases and associated financing payments, and reconciles the undiscounted cash flows to the customer receivables, gross recognized on the Condensed Consolidated Statements of Financial Position as of the date indicated:

[0001571996-21-000026:notes:58]
|  | April 30, 2021 |
|  | (in millions) |
| Fiscal 2022 (remaining nine months) | $ | 2,232 |  |
| Fiscal 2023 | 1,819 |  |
| Fiscal 2024 | 1,086 |  |
| Fiscal 2025 | 429 |  |
| Fiscal 2026 and beyond | 141 |  |
| Total undiscounted cash flows | 5,707 |  |
| Fixed-term loans | 4,399 |  |
| Revolving loans | 752 |  |
| Less: unearned income | (668) |  |
| Total customer receivables, gross | $ | 10,190 |  |

[0001571996-21-000026:notes:59]
Operating Leases

[0001571996-21-000026:notes:60]
The following table presents the components of the Company’s operating lease portfolio included in Property, plant, and equipment, net as of the dates indicated:

[0001571996-21-000026:notes:61]
|  | April 30, 2021 |  | January 29, 2021 |
|  | (in millions) |
| Equipment under operating lease, gross | $ | 1,921 |  |  | $ | 1,746 |  |
| Less: accumulated depreciation | (541) |  |  | (432) |  |
| Equipment under operating lease, net | $ | 1,380 |  |  | $ | 1,314 |  |

[0001571996-21-000026:notes:62]
Operating lease income relating to lease payments was $156 million and $87 million for the three months ended April 30, 2021 and May 1, 2020, respectively.  Depreciation expense was $116 million and $62 million for the three months ended April 30, 2021 and May 1, 2020, respectively.

[0001571996-21-000026:notes:63]
The following table presents the future payments to be received by the Company as lessor in operating lease contracts as of the date indicated:

[0001571996-21-000026:notes:64]
|  | April 30, 2021 |
|  | (in millions) |
| Fiscal 2022 (remaining nine months) | $ | 525 |  |
| Fiscal 2023 | 516 |  |
| Fiscal 2024 | 261 |  |
| Fiscal 2025 | 59 |  |
| Fiscal 2026 and beyond | 9 |  |
| Total | $ | 1,370 |  |

[0001571996-21-000026:notes:65]
DFS Debt

[0001571996-21-000026:notes:66]
The Company maintains programs that facilitate the funding of leases, loans, and other alternative payment structures in the capital markets.  The majority of DFS debt is non-recourse to Dell Technologies and represents borrowings under securitization programs and structured financing programs, for which the Company’s risk of loss is limited to transferred loan and lease payments and associated equipment.  The following table presents DFS debt as of the dates indicated.  The table excludes the allocated portion of the Company’s other borrowings, which represents the additional amount considered to fund the DFS business.

[0001571996-21-000026:notes:67]
|  | April 30, 2021 |  | January 29, 2021 |
|  | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing and securitization facilities | $ | 2,674 |  |  | $ | 3,311 |  |
| Fixed-term securitization offerings | 3,548 |  |  | 2,961 |  |
| Other | 198 |  |  | 140 |  |
| Total DFS U.S. debt | 6,420 |  |  | 6,412 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 784 |  |  | 786 |  |
| Other borrowings | 1,087 |  |  | 1,006 |  |
| Note payable | 250 |  |  | 250 |  |
| Dell Bank Senior Unsecured Eurobonds | 1,212 |  |  | 1,212 |  |
| Total DFS international debt | 3,333 |  |  | 3,254 |  |
| Total DFS debt | $ | 9,753 |  |  | $ | 9,666 |  |
| Total short-term DFS debt | $ | 4,673 |  |  | $ | 4,888 |  |
| Total long-term DFS debt | $ | 5,080 |  |  | $ | 4,778 |  |

[0001571996-21-000026:notes:68]
DFS U.S. Debt

[0001571996-21-000026:notes:69]
Asset-Based Financing and Securitization Facilities — The Company maintains separate asset-based financing facilities and a securitization facility in the United States, which are revolving facilities for fixed-term leases and loans and for revolving loans, respectively.  This debt is collateralized solely by the U.S. loan and lease payments and associated equipment in the facilities.  The debt has a variable interest rate and the duration of the debt is based on the terms of the underlying loan and lease payment streams.  As of April 30, 2021, the total debt capacity related to the U.S. asset-based financing and securitization facilities was $4.1 billion.  The Company enters into interest swap agreements to effectively convert a portion of this debt from a floating rate to a fixed rate.  See Note 6 of the Notes to the Condensed Consolidated Financial Statements for additional information about interest rate swaps.

[0001571996-21-000026:notes:70]
The Company’s U.S. securitization facility for revolving loans is effective through June 25, 2022.  The Company’s two U.S. asset-based financing facilities for fixed-term leases and loans are effective through August 22, 2021 and July 26, 2022, respectively.

[0001571996-21-000026:notes:71]
The asset-based financing and securitization facilities contain standard structural features related to the performance of the funded receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the facility, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of April 30, 2021, these criteria were met.

[0001571996-21-000026:notes:72]
Fixed-Term Securitization Offerings — The Company periodically issues asset-backed debt securities under fixed-term securitization programs to private investors.  The asset-backed debt securities are collateralized solely by the U.S. fixed-term leases and loans in the offerings, which are held by Special Purpose Entities (“SPEs”), as discussed below.  The interest rate on these securities is fixed and ranges from 0.21% to 5.92% per annum, and the duration of these securities is based on the terms of the underlying loan and lease payment streams.

[0001571996-21-000026:notes:73]
DFS International Debt

[0001571996-21-000026:notes:74]
Securitization Facility — The Company maintains a securitization facility in Europe for fixed-term leases and loans.  This facility is effective through December 21, 2022 and has a total debt capacity of $970 million as of April 30, 2021.

[0001571996-21-000026:notes:75]
The securitization facility contains standard structural features related to the performance of the securitized receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the program, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of April 30, 2021, these criteria were met.

[0001571996-21-000026:notes:76]
Other Borrowings — In connection with the Company’s international financing operations, the Company has entered into revolving structured financing debt programs related to its fixed-term lease and loan products sold in Canada, Europe, Australia, and New Zealand.  The Canadian facility, which is collateralized solely by Canadian loan and lease payments and associated equipment, had a total debt capacity of $366 million as of April 30, 2021, and is effective through January 16, 2025.  The European facility, which is collateralized solely by European loan and lease payments and associated equipment, had a total debt capacity of $727 million as of April 30, 2021, and is effective through June 14, 2022.  The Australia and New Zealand facility, which is collateralized solely by Australia and New Zealand loan and lease payments and associated equipment, had a total debt capacity of $349 million as of April 30, 2021, and is effective through April 20, 2023.

[0001571996-21-000026:notes:77]
Note Payable — On August 7, 2020, the Company entered into two new unsecured credit agreements to fund receivables in Mexico.  As of April 30, 2021, the aggregate principal amount of the notes payable was $250 million.  The notes bear interest at an annual rate of 3.37% and will mature on June 1, 2022.

[0001571996-21-000026:notes:78]
Dell Bank Senior Unsecured Eurobonds — On October 17, 2019, Dell Bank International D.A.C. issued 500 million Euro of 0.625% senior unsecured three year eurobonds due October 2022.  On June 24, 2020, Dell Bank International D.A.C. issued an additional 500 million Euro of 1.625% senior unsecured four year eurobonds due June 2024.  The issuances of the senior unsecured eurobonds support the expansion of the financing operations in Europe.

[0001571996-21-000026:notes:79]
Variable Interest Entities

[0001571996-21-000026:notes:80]
In connection with the asset-based financing facilities, securitization facilities, and fixed-term securitization offerings discussed above, the Company transfers certain U.S. and European loan and lease payments and associated equipment to SPEs that meet the definition of a Variable Interest Entity (“VIE”) and are consolidated, along with the associated debt detailed above, into the Condensed Consolidated Financial Statements, as the Company is the primary beneficiary of those VIEs.  The SPEs are bankruptcy-remote legal entities with separate assets and liabilities.  The purpose of the SPEs is to facilitate the funding of customer loan and lease payments and associated equipment in the capital markets.

[0001571996-21-000026:notes:81]
Some of the SPEs have entered into financing arrangements with multi-seller conduits that, in turn, issue asset-backed debt securities in the capital markets. DFS debt outstanding held by the consolidated VIEs is collateralized by the loan and lease payments and associated equipment. The Company’s risk of loss related to securitized receivables is limited to the amount by which the Company’s right to receive collections for assets securitized exceeds the amount required to pay interest, principal, and fees and expenses related to the asset-backed securities. The Company provides credit enhancement to the securitization in the form of over-collateralization.

[0001571996-21-000026:notes:82]
The following table presents financing receivables and equipment under operating leases, net held by the consolidated VIEs as of the dates indicated:

[0001571996-21-000026:notes:83]
|  | April 30, 2021 |  | January 29, 2021 |
|  | (in millions) |
| Assets held by consolidated VIEs |  |  |  |
| Other current assets | $ | 874 |  |  | $ | 838 |  |
| Financing receivables, net of allowance |  |  |  |
| Short-term | $ | 3,478 |  |  | $ | 3,534 |  |
| Long-term | $ | 3,267 |  |  | $ | 3,314 |  |
| Property, plant, and equipment, net | $ | 827 |  |  | $ | 792 |  |
| Liabilities held by consolidated VIEs |  |  |  |
| Debt, net of unamortized debt issuance costs |  |  |  |
| Short-term | $ | 4,055 |  |  | $ | 4,208 |  |
| Long-term | $ | 2,938 |  |  | $ | 2,841 |  |

[0001571996-21-000026:notes:84]
Loan and lease payments and associated equipment transferred via securitization through SPEs were $1.4 billion and $1.8 billion for the three months ended April 30, 2021 and May 1, 2020, respectively.

[0001571996-21-000026:notes:85]
Customer Receivables Sales

[0001571996-21-000026:notes:86]
To manage certain concentrations of customer credit exposure, the Company may sell selected fixed-term customer receivables to unrelated third parties on a periodic basis, without recourse.  The amount of customer receivables sold for this purpose was $101 million and $21 million for the three months ended April 30, 2021 and May 1, 2020, respectively.  The Company’s continuing involvement in such customer receivables is primarily limited to servicing arrangements.


## us-gaap:ScheduleOfDebtTableTextBlock

[0001571996-21-000026:notes:87]
The following table presents DFS debt as of the dates indicated.  The table excludes the allocated portion of the Company’s other borrowings, which represents the additional amount considered to fund the DFS business.

[0001571996-21-000026:notes:88]
The following table presents the Company’s outstanding debt as of the dates indicated:

[0001571996-21-000026:notes:89]
|  | April 30, 2021 |  | January 29, 2021 |
|  | (in millions) |
| Secured Debt |  |  |  |
| Senior Secured Credit Facilities: |  |  |  |
| 2.00% Term Loan B-2 Facility due September 2025 | $ | 3,135 |  |  | $ | 3,143 |  |
| 1.90% Term Loan A-6 Facility due March 2024 | 3,134 |  |  | 3,134 |  |
| First Lien Notes: |  |  |  |
| 5.45% due June 2023 | 3,750 |  |  | 3,750 |  |
| 4.00% due July 2024 | 1,000 |  |  | 1,000 |  |
| 5.85% due July 2025 | 1,000 |  |  | 1,000 |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 4.90% due October 2026 | 1,750 |  |  | 1,750 |  |
| 6.10% due July 2027 | 500 |  |  | 500 |  |
| 5.30% due October 2029 | 1,750 |  |  | 1,750 |  |
| 6.20% due July 2030 | 750 |  |  | 750 |  |
| 8.10% due July 2036 | 1,500 |  |  | 1,500 |  |
| 8.35% due July 2046 | 2,000 |  |  | 2,000 |  |
| Unsecured Debt |  |  |  |
| Unsecured Notes and Debentures: |  |  |  |
| 4.625% due April 2021 | — |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| Senior Notes: |  |  |  |
| 5.875% due June 2021 | — |  |  | 1,075 |  |
| 7.125% due June 2024 | 1,625 |  |  | 1,625 |  |
| EMC Notes: |  |  |  |
| 3.375% due June 2023 | 1,000 |  |  | 1,000 |  |
| Debt of Public Subsidiary |  |  |  |
| VMware Notes: |  |  |  |
| 2.95% due August 2022 | 1,500 |  |  | 1,500 |  |
| 4.50% due May 2025 | 750 |  |  | 750 |  |
| 4.65% due May 2027 | 500 |  |  | 500 |  |
| 3.90% due August 2027 | 1,250 |  |  | 1,250 |  |
| 4.70% due May 2030 | 750 |  |  | 750 |  |
| DFS Debt (Note 3) | 9,753 |  |  | 9,666 |  |
| Other |  |  |  |
| 2.46% Margin Loan Facility due April 2022 | 4,000 |  |  | 4,000 |  |
| Other | 304 |  |  | 235 |  |
| Total debt, principal amount | $ | 47,153 |  |  | $ | 48,480 |  |

[0001571996-21-000026:notes:90]
|  | April 30, 2021 |  | January 29, 2021 |
|  | (in millions) |
| Total debt, principal amount | $ | 47,153 |  |  | $ | 48,480 |  |
| Unamortized discount, net of unamortized premium | (185) |  |  | (194) |  |
| Debt issuance costs | (285) |  |  | (302) |  |
| Total debt, carrying value | $ | 46,683 |  |  | $ | 47,984 |  |
| Total short-term debt, carrying value | $ | 8,748 |  |  | $ | 6,362 |  |
| Total long-term debt, carrying value | $ | 37,935 |  |  | $ | 41,622 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0001571996-21-000026:notes:91]
NOTE 4 — LEASES

[0001571996-21-000026:notes:92]
The Company enters into leasing transactions in which the Company is the lessee.  These lease contracts are typically classified as operating leases.  The Company’s lease contracts are generally for office buildings used to conduct its business, and the determination of whether such contracts contain leases generally does not require significant estimates or judgments.  The Company also leases certain global logistics warehouses, employee vehicles, and equipment.  As of April 30, 2021, the remaining terms of the Company’s leases range from less than one month to approximately 25 years.

[0001571996-21-000026:notes:93]
The Company also enters into leasing transactions in which the Company is the lessor, primarily through customer financing arrangements offered through DFS.  DFS originates leases that are primarily classified as either sales-type leases or operating leases.  See Note 3 of the Notes to the Condensed Consolidated Financial Statements for more information on the DFS lease portfolio and related lease disclosures.

[0001571996-21-000026:notes:94]
Financial information associated with the Company’s leases in which the Company is the lessee is contained in this Note.  As of both April 30, 2021 and January 29, 2021, there were no material finance leases for which the Company was a lessee.

[0001571996-21-000026:notes:95]
The following table presents components of lease costs included in the Condensed Consolidated Statements of Income for the periods indicated:

[0001571996-21-000026:notes:96]
|  | Three Months Ended |  |  |
|  | April 30, 2021 |  | May 1, 2020 |  |  |  |  |
|  | (in millions) |
| Operating lease costs | $ | 142 |  |  | $ | 131 |  |  |  |  |  |
| Variable costs | 33 |  |  | 44 |  |  |  |  |  |
| Total lease costs | $ | 175 |  |  | $ | 175 |  |  |  |  |  |

[0001571996-21-000026:notes:97]
During both the three months ended April 30, 2021 and May 1, 2020, sublease income, finance lease costs, and short-term lease costs were immaterial.

[0001571996-21-000026:notes:98]
[same as prior period, unchanged from 0001571996-20-000051:notes:110]

[0001571996-21-000026:notes:99]
|  | Classification | April 30, 2021 |  | January 29, 2021 |  |  |
|  |  | (in millions, except for term and discount rate) |
| Operating lease ROU assets | Other non-current assets | $ | 2,088 |  | $ | 2,117 |  |  |
| Current operating lease liabilities | Accrued and other current liabilities | $ | 440 |  | $ | 436 |  |  |
| Non-current operating lease liabilities | Other non-current liabilities | 1,791 |  | 1,787 |  |  |
| Total operating lease liabilities |  | $ | 2,231 |  | $ | 2,223 |  |  |
| Weighted-average remaining lease term (in years) |  | 8.76 |  | 8.85 |  |  |
| Weighted-average discount rate |  | 3.40 | % |  | 3.47 | % |  |  |

[0001571996-21-000026:notes:100]
[same as prior period, unchanged from 0001571996-20-000051:notes:112]

[0001571996-21-000026:notes:101]
|  | Three Months Ended |
|  | April 30, 2021 |  | May 1, 2020 |
|  | (in millions) |
| Cash paid for amounts included in the measurement of lease liabilities — operating cash outflows from operating leases | $ | 134 |  |  | $ | 131 |  |
| ROU assets obtained in exchange for new operating lease liabilities | $ | 117 |  |  | $ | 120 |  |

[0001571996-21-000026:notes:102]
The following table presents the future maturities of the Company’s operating lease liabilities under non-cancelable leases and reconciles the undiscounted cash flows for these leases to the lease liability recognized on the Condensed Consolidated Statements of Financial Position as of the date indicated:

[0001571996-21-000026:notes:103]
|  | April 30, 2021 |  |  |
|  | (in millions) |
| Fiscal 2022 (remaining nine months) | $ | 351 |  |  |  |
| Fiscal 2023 | 469 |  |  |  |
| Fiscal 2024 | 347 |  |  |  |
| Fiscal 2025 | 260 |  |  |  |
| Fiscal 2026 | 211 |  |  |  |
| Thereafter | 1,010 |  |  |  |
| Total lease payments | 2,648 |  |  |  |
| Less: Imputed interest | (417) |  |  |  |
| Total | $ | 2,231 |  |  |  |
| Current operating lease liabilities | $ | 440 |  |  |  |
| Non-current operating lease liabilities | $ | 1,791 |  |  |  |

[0001571996-21-000026:notes:104]
Future lease commitments after Fiscal 2026 include the ground lease on VMware, Inc.’s Palo Alto, California headquarters facilities, which expires in Fiscal 2047.

[0001571996-21-000026:notes:105]
As of April 30, 2021, the Company has additional operating leases that have not yet commenced of $97 million.  These operating leases will commence during Fiscal 2022 with lease terms of one year to 10 years.


## us-gaap:DebtDisclosureTextBlock

[0001571996-21-000026:notes:106]
NOTE 5 — DEBT

[0001571996-21-000026:notes:107]
During the three months ended April 30, 2021, the net decrease in the Company’s debt balance was primarily due to:

[0001571996-21-000026:notes:108]
•repayment of $1,075 million principal amount of the 5.875% Senior Notes due June 2021; and

[0001571996-21-000026:notes:109]
•repayment of $400 million principal amount of the 4.625% Unsecured Notes due April 2021.

[0001571996-21-000026:notes:110]
Secured Debt

[0001571996-21-000026:notes:111]
Senior Secured Credit Facilities — The Company has entered into a credit agreement that provides for senior secured credit facilities (the “Senior Secured Credit Facilities”) comprising (a) term loan facilities and (b) a senior secured Revolving Credit Facility, which provides for a borrowing capacity of up to $4.5 billion for general corporate purposes, including capacity for up to $0.5 billion of letters of credit and for borrowings of up to $0.4 billion under swing-line loans.

[0001571996-21-000026:notes:112]
As of April 30, 2021, available borrowings under the Revolving Credit Facility totaled $4.5 billion.  The Senior Secured Credit Facilities provide that the borrowers have the right at any time, subject to customary conditions, to request incremental term loans or incremental revolving commitments.

[0001571996-21-000026:notes:113]
On February 18, 2021, the Company entered into an eighth refinancing amendment to the credit agreement for the Senior Secured Credit Facilities to refinance the existing term B loans (the “Original Term B Loans”) with a new term loan B facility consisting of an aggregate principal amount of $3,143 million refinancing term B-2 loans (the “Refinancing Term B-2 Loans”) maturing on September 19, 2025.  Proceeds from the Refinancing Term B-2 Loans, together with other funds available to the borrowers, were used to repay in full the Original Term B Loans and all accrued and unpaid fees in respect thereof.

[0001571996-21-000026:notes:114]
Except for a change in the interest rate, the Refinancing Term B-2 Loans have substantially the same terms as the Original Term B Loans under the sixth refinancing amendment to the Senior Secured Credit Agreement.  Amortization payments on the Refinancing Term B-2 Loans are equal to 0.25% of the aggregate principal amount of Refinancing Term B-2 Loans outstanding on the effective date of the eighth refinancing amendment, payable at the end of each fiscal quarter, commencing with the fiscal quarter ended April 30, 2021.

[0001571996-21-000026:notes:115]
Borrowings under the Senior Secured Credit Facilities bear interest at a rate per annum equal to an applicable margin, plus, at the borrowers’ option, either (a) a base rate, or (b) the London Interbank Offered Rate (“LIBOR”).  The Term Loan A-6 Facility bears interest at LIBOR plus an applicable margin ranging from 1.25% to 2.00% or a base rate plus an applicable margin ranging from 0.25% to 1.00%.  The Refinancing Term B-2 Loans bear interest at LIBOR plus an applicable margin of 1.75% or a base rate plus an applicable margin of 0.75%.  Interest is payable, in the case of loans bearing interest based on LIBOR, at the end of each interest period (but at least every three months), in arrears and, in the case of loans bearing interest based on the base rate, quarterly in arrears.

[0001571996-21-000026:notes:116]
The Term Loan A-6 Facility amortizes in equal quarterly installments in aggregate annual amounts equal to 5% of the original principal amount in each of the first four years after the facility closing date of March 13, 2019, and 80% of the original principal amount in the fifth year after March 13, 2019.  The Revolving Credit Facility has no amortization.

[0001571996-21-000026:notes:117]
The borrowers may voluntarily repay outstanding loans under the term loan facilities and the Revolving Credit Facility at any time without premium or penalty, other than customary “breakage” costs.

[0001571996-21-000026:notes:118]
All obligations of the borrowers under the Senior Secured Credit Facilities and certain swap agreements, cash management arrangements, and certain letters of credit provided by any lender or agent party to the Senior Secured Credit Facilities or any of its affiliates and certain other persons are secured by (a) a first-priority security interest in certain tangible and intangible assets of the borrowers and the guarantors and (b) a first-priority pledge of 100% of the capital stock of the borrowers, Dell Inc., a wholly-owned subsidiary of the Company (“Dell”), and each wholly-owned material restricted subsidiary of the borrowers and the guarantors, in each case subject to certain thresholds, exceptions, and permitted liens.

[0001571996-21-000026:notes:119]
First Lien Notes — Dell International L.L.C. and EMC Corporation, both of which are wholly-owned subsidiaries of Dell Technologies Inc., completed private offerings of multiple series of senior secured notes (collectively, the “First Lien Notes”) which were issued on June 1, 2016, March 20, 2019, and April 9, 2020 in aggregate principal amounts of $20.0 billion, $4.5 billion, and $2.25 billion, respectively.  Interest on the First Lien Notes is payable semiannually.  The First Lien Notes are secured on a pari passu basis with the Senior Secured Credit Facilities, on a first-priority basis by substantially all of the tangible and intangible assets of the issuers and guarantors that secure obligations under the Senior Secured Credit Facilities, including pledges of all capital stock of the issuers, Dell, and certain wholly-owned material subsidiaries of the issuers and the guarantors, subject to certain exceptions.

[0001571996-21-000026:notes:120]
The Company agreed to use commercially reasonable efforts to register with the SEC notes having terms substantially identical to the terms of the First Lien Notes as part of an offer to exchange such registered notes for the First Lien Notes.  The Company will be obligated to pay additional interest on the First Lien Notes if it fails to consummate such an exchange offer within five years after the closing date of the EMC merger transaction, in the case of the First Lien Notes issued on June 1, 2016, and within five years after their respective issue dates, in the case of the First Lien Notes issued on March 20, 2019 and April 9, 2020.  On April 15, 2021, Dell International L.L.C., EMC Corporation and the guarantors of the First Lien Notes (collectively, the “Registrants”)  filed a registration statement with the SEC relating to the proposed exchange offer of such registered notes.

[0001571996-21-000026:notes:121]
Subsequent to the three months ended April 30, 2021, on May 13, 2021, the Registrants filed an amendment to the registration statement, which was declared effective on May 17, 2021.  In addition, on May 17, 2021, the Registrants filed a prospectus with the SEC and launched the exchange offer.  The exchange offer expires at 5:00 p.m., New York City time, on June 15, 2021, unless extended by Dell International L.L.C. and EMC Corporation. During this period holders of the First Lien Notes may elect to tender their unregistered outstanding notes for freely tradable exchange notes that have been registered under the Securities Act.  The Company does not currently intend to extend the expiration date.

[0001571996-21-000026:notes:122]
Unsecured Debt

[0001571996-21-000026:notes:123]
Unsecured Notes and Debentures — The Company has outstanding unsecured notes and debentures (collectively, the “Unsecured Notes and Debentures”) that were issued by Dell prior to the acquisition of Dell by Dell Technologies Inc. in the going-private transaction that closed in October 2013.  Interest on outstanding borrowings is payable semiannually.

[0001571996-21-000026:notes:124]
Senior Notes — The senior unsecured notes (collectively, the “Senior Notes”) were issued on June 22, 2016 in an aggregate principal amount of $3.25 billion.  Interest on outstanding borrowings is payable semiannually.

[0001571996-21-000026:notes:125]
EMC Notes — On September 7, 2016, EMC had outstanding $2.5 billion aggregate principal amount of its 1.875% Notes due June 2018, $2.0 billion aggregate principal amount of its 2.650% Notes due June 2020, and $1.0 billion aggregate principal amount of its 3.375% Notes due June 2023 (collectively, the “EMC Notes”).  Interest on outstanding borrowings is payable semiannually.

[0001571996-21-000026:notes:126]
VMware Notes — VMware, Inc. completed public offerings of unsecured senior notes in the aggregate amounts of $4.0 billion and $2.0 billion on August 21, 2017 and April 7, 2020, respectively (the “VMware Notes”).  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.  Interest on outstanding borrowings is payable semiannually.

[0001571996-21-000026:notes:127]
VMware Revolving Credit Facility — On September 12, 2017, VMware, Inc. entered into an unsecured credit agreement, establishing a revolving credit facility (the “VMware Revolving Credit Facility”) with a syndicate of lenders that provides the company with a borrowing capacity of up to $1.0 billion for VMware, Inc. general corporate purposes.  Commitments under the VMware Revolving Credit Facility are available for a period of five years, which may be extended, subject to the satisfaction of certain conditions, by up to two one year periods.  The credit agreement contains certain representations, warranties, and covenants.  Commitment fees, interest rates, and other terms of borrowing under the VMware Revolving Credit Facility may vary based on VMware, Inc.’s external credit ratings.  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.  As of April 30, 2021, there were no outstanding borrowings under the VMware Revolving Credit Facility.

[0001571996-21-000026:notes:128]
See Note 3 and Note 6 of the Notes to the Condensed Consolidated Financial Statements, respectively, for discussion of DFS debt and the interest rate swap agreements that hedge a portion of that debt.

[0001571996-21-000026:notes:129]
Other

[0001571996-21-000026:notes:130]
Margin Loan Facility — On April 12, 2017, the Company entered into the Margin Loan Facility in an aggregate principal amount of $2.0 billion.  In connection with the Class V transaction described in Note 1 of the Notes to the Condensed Consolidated Financial Statements, on December 20, 2018, the Company amended the Margin Loan Facility to increase the aggregate principal amount to $3.35 billion.  In connection with obtaining the Term Loan A-6 Facility during the fiscal year ended January 31, 2020, the Company increased the aggregate principal amount of the Margin Loan Facility to $4.0 billion. VMware Holdco LLC, a wholly-owned subsidiary of EMC, is the borrower under the Margin Loan Facility, which is secured by approximately 76 million shares of Class B common stock of VMware, Inc. and approximately 24 million shares of Class A common stock of VMware, Inc.

[0001571996-21-000026:notes:131]
Loans under the Margin Loan Facility bear interest at a rate per annum payable, at the borrower’s option, either at (a) a base rate plus 1.25% per annum or (b) a LIBOR-based rate plus 2.25% per annum.  Interest under the Margin Loan Facility is payable quarterly.  The Margin Loan Facility will mature in April 2022.  The borrower may voluntarily repay outstanding loans under the Margin Loan Facility at any time without premium or penalty, other than customary “breakage” costs, subject to certain minimum threshold amounts for prepayment.

[0001571996-21-000026:notes:132]
Aggregate Future Maturities

[0001571996-21-000026:notes:133]
The following table presents the aggregate future maturities of the Company’s debt as of April 30, 2021 for the periods indicated:

[0001571996-21-000026:notes:134]
|  | Maturities by Fiscal Year |
|  | 2022(remaining nine months) |  | 2023 |  | 2024 |  | 2025 |  | 2026 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Secured Credit Facilities and First Lien Notes | $ | 31 |  |  | $ | 213 |  |  | $ | 6,007 |  |  | $ | 1,758 |  |  | $ | 4,017 |  |  | $ | 12,743 |  |  | $ | 24,769 |  |
| Unsecured Notes and Debentures | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 952 |  |  | 952 |  |
| Senior Notes and EMC Notes | — |  |  | — |  |  | 1,000 |  |  | 1,625 |  |  | — |  |  | — |  |  | 2,625 |  |
| VMware Notes | — |  |  | 1,500 |  |  | — |  |  | — |  |  | 750 |  |  | 2,500 |  |  | 4,750 |  |
| DFS Debt | 3,844 |  |  | 4,249 |  |  | 774 |  |  | 850 |  |  | 36 |  |  | — |  |  | 9,753 |  |
| Margin Loan Facility | — |  |  | 4,000 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 4,000 |  |
| Other | 11 |  |  | 11 |  |  | 171 |  |  | 78 |  |  | 8 |  |  | 25 |  |  | 304 |  |
| Total maturities, principal amount | 3,886 |  |  | 9,973 |  |  | 7,952 |  |  | 4,311 |  |  | 4,811 |  |  | 16,220 |  |  | 47,153 |  |
| Associated carrying value adjustments | (6) |  |  | (15) |  |  | (32) |  |  | (71) |  |  | (47) |  |  | (299) |  |  | (470) |  |
| Total maturities, carrying value amount | $ | 3,880 |  |  | $ | 9,958 |  |  | $ | 7,920 |  |  | $ | 4,240 |  |  | $ | 4,764 |  |  | $ | 15,921 |  |  | $ | 46,683 |  |

[0001571996-21-000026:notes:135]
Covenants and Unrestricted Net Assets — The credit agreement for the Senior Secured Credit Facilities contains customary negative covenants that generally limit the ability of Denali Intermediate Inc., a wholly-owned subsidiary of Dell Technologies (“Denali Intermediate”), Dell, and Dell’s and Denali Intermediate’s other restricted subsidiaries to incur debt, create liens, make fundamental changes, enter into asset sales, make certain investments, pay dividends or distribute or redeem certain equity interests, prepay or redeem certain debt, and enter into certain transactions with affiliates.  The indenture governing the Senior Notes contains customary negative covenants that generally limit the ability of Denali Intermediate, Dell, and Dell’s and Denali Intermediate’s other restricted subsidiaries to incur additional debt or issue certain preferred shares, pay dividends on or make other distributions in respect of capital stock or make other restricted payments, make certain investments, sell or transfer certain assets, create liens on certain assets to secure debt, consolidate, merge, sell, or otherwise dispose of all or substantially all assets, enter into certain transactions with affiliates, and designate subsidiaries as unrestricted subsidiaries.  The negative covenants under such credit agreements and indenture are subject to certain exceptions, qualifications, and “baskets.”  The indentures governing the First Lien Notes, the Unsecured Notes and Debentures, and the EMC Notes variously impose limitations, subject to specified exceptions, on creating certain liens, entering into sale and lease-back transactions, and entering into certain asset sales.  The foregoing credit agreements and indentures contain customary events of default, including failure to make required payments, failure to comply with covenants, and the occurrence of certain events of bankruptcy and insolvency.

[0001571996-21-000026:notes:136]
As of April 30, 2021, the Company had certain consolidated subsidiaries that were designated as unrestricted subsidiaries for all purposes of the applicable credit agreements and the indentures governing the First Lien Notes and the Senior Notes.  Substantially all of the net assets of the Company’s consolidated subsidiaries were restricted, with the exception of the Company’s unrestricted subsidiaries, primarily VMware, Inc., Secureworks, and their respective subsidiaries, as of April 30, 2021.

[0001571996-21-000026:notes:137]
The Term Loan A-6 Facility and the Revolving Credit Facility are subject to a first lien leverage ratio covenant that is tested at the end of each fiscal quarter of Dell with respect to Dell’s preceding four fiscal quarters.  The Company was in compliance with all financial covenants as of April 30, 2021.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001571996-21-000026:notes:138]
NOTE 6 — DERIVATIVE INSTRUMENTS AND HEDGING ACTIVITIES

[0001571996-21-000026:notes:139]
[same as prior period, unchanged from 0001571996-20-000051:notes:160]

[0001571996-21-000026:notes:140]
[same as prior period, unchanged from 0001571996-20-000051:notes:161]

[0001571996-21-000026:notes:141]
[same as prior period, unchanged from 0001571996-20-000051:notes:162]

[0001571996-21-000026:notes:142]
[same as prior period, unchanged from 0001571996-20-000051:notes:163]

[0001571996-21-000026:notes:143]
During the three months ended April 30, 2021 and May 1, 2020, the Company did not discontinue any cash flow hedges related to foreign exchange contracts that had a material impact on the Company’s results of operations due to the probability that the forecasted cash flows would not occur.

[0001571996-21-000026:notes:144]
[same as prior period, unchanged from 0001571996-20-000051:notes:165]

[0001571996-21-000026:notes:145]
[same as prior period, unchanged from 0001571996-20-000051:notes:166]

[0001571996-21-000026:notes:146]
[same as prior period, unchanged from 0001571996-20-000051:notes:167]

[0001571996-21-000026:notes:147]
[same as prior period, unchanged from 0001571996-20-000051:notes:168]

[0001571996-21-000026:notes:148]
[same as prior period, unchanged from 0001571996-20-000051:notes:169]

[0001571996-21-000026:notes:149]
[same as prior period, unchanged from 0001571996-20-000051:notes:170]

[0001571996-21-000026:notes:150]
[same as prior period, unchanged from 0001571996-20-000051:notes:171]

[0001571996-21-000026:notes:151]
[same as prior period, unchanged from 0001571996-20-000051:notes:172]

[0001571996-21-000026:notes:152]
|  | April 30, 2021 |  | January 29, 2021 |
|  | (in millions) |
| Foreign exchange contracts: |  |  |  |
| Designated as cash flow hedging instruments | $ | 6,967 |  |  | $ | 6,840 |  |
| Non-designated as hedging instruments | 9,449 |  |  | 9,890 |  |
| Total | $ | 16,416 |  |  | $ | 16,730 |  |
| Interest rate contracts: |  |  |  |
| Non-designated as hedging instruments | $ | 6,011 |  |  | $ | 5,859 |  |

[0001571996-21-000026:notes:153]
Effect of Derivative Instruments Designated as Hedging Instruments on the Condensed Consolidated Statements of Financial Position and the Condensed Consolidated Statements of Income

[0001571996-21-000026:notes:154]
| Derivatives in Cash Flow Hedging Relationships |  | Gain (Loss) Recognized in Accumulated OCI, Net of Tax, on Derivatives |  | Location of Gain (Loss) Reclassified from Accumulated OCI into Income |  | Gain (Loss) Reclassified from Accumulated OCI into Income |  |  |  |  |
|  |  | (in millions) |  |  |  | (in millions) |  |  |  |  |
| For the three months ended April 30, 2021 |  |  |  |  |
|  |  |  |  | Total net revenue |  | $ | (29) |  |  |  |  |  |
| Foreign exchange contracts |  | $ | (1) |  |  | Total cost of net revenue |  | 2 |  |  |  |  |  |
| Interest rate contracts |  | — |  |  | Interest and other, net |  | — |  |  |  |  |  |
| Total |  | $ | (1) |  |  |  |  | $ | (27) |  |  |  |  |  |
| For the three months ended May 1, 2020 |  |  |  |  |
|  |  |  |  | Total net revenue |  | $ | 96 |  |  |  |  |  |
| Foreign exchange contracts |  | $ | 167 |  |  | Total cost of net revenue |  | 4 |  |  |  |  |  |
| Interest rate contracts |  | — |  |  | Interest and other, net |  | — |  |  |  |  |  |
| Total |  | $ | 167 |  |  |  |  | $ | 100 |  |  |  |  |  |

[0001571996-21-000026:notes:155]
Effect of Derivative Instruments Not Designated as Hedging Instruments on the Condensed Consolidated Statements of Income

[0001571996-21-000026:notes:156]
|  |  | Three Months Ended |  |  |  |  |  |
|  |  | April 30, 2021 |  | May 1, 2020 |  |  |  |  |  |  | Location of Gain (Loss) Recognized |
|  |  | (in millions) |  |  |  |  |  |  |  |
| Gain (Loss) Recognized: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | (24) |  |  | $ | 52 |  |  |  |  |  |  |  | Interest and other, net |
| Interest rate contracts |  | 1 |  |  | (39) |  |  |  |  |  |  |  | Interest and other, net |
| Total |  | $ | (23) |  |  | $ | 13 |  |  |  |  |  |  |  |  |

[0001571996-21-000026:notes:157]
[same as prior period, unchanged from 0001571996-20-000051:notes:178]

[0001571996-21-000026:notes:158]
[same as prior period, unchanged from 0001571996-20-000051:notes:179]

[0001571996-21-000026:notes:159]
|  | April 30, 2021 |
|  | Other CurrentAssets |  | Other Non-Current Assets |  | Other CurrentLiabilities |  | Other Non-CurrentLiabilities |  | TotalFair Value |
|  | (in millions) |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts in an asset position | $ | 45 |  |  | $ | — |  |  | $ | 19 |  |  | $ | — |  |  | $ | 64 |  |
| Foreign exchange contracts in a liability position | (20) |  |  | — |  |  | (19) |  |  | — |  |  | (39) |  |
| Net asset (liability) | 25 |  |  | — |  |  | — |  |  | — |  |  | 25 |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts in an asset position | 111 |  |  | — |  |  | 57 |  |  | — |  |  | 168 |  |
| Foreign exchange contracts in a liability position | (76) |  |  | — |  |  | (127) |  |  | (7) |  |  | (210) |  |
| Interest rate contracts in an asset position | — |  |  | 9 |  |  | — |  |  | — |  |  | 9 |  |
| Interest rate contracts in a liability position | — |  |  | — |  |  | — |  |  | (26) |  |  | (26) |  |
| Net asset (liability) | 35 |  |  | 9 |  |  | (70) |  |  | (33) |  |  | (59) |  |
| Total derivatives at fair value | $ | 60 |  |  | $ | 9 |  |  | $ | (70) |  |  | $ | (33) |  |  | $ | (34) |  |
|  | January 29, 2021 |
|  | Other CurrentAssets |  | Other Non-Current Assets |  | Other CurrentLiabilities |  | Other Non-CurrentLiabilities |  | TotalFair Value |
|  | (in millions) |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts in an asset position | $ | 28 |  |  | $ | — |  |  | $ | 18 |  |  | $ | — |  |  | $ | 46 |  |
| Foreign exchange contracts in a liability position | (10) |  |  | — |  |  | (15) |  |  | — |  |  | (25) |  |
| Net asset (liability) | 18 |  |  | — |  |  | 3 |  |  | — |  |  | 21 |  |
| Derivatives not designated as hedging instruments: |
| Foreign exchange contracts in an asset position | 184 |  |  | — |  |  | 58 |  |  | — |  |  | 242 |  |
| Foreign exchange contracts in a liability position | (108) |  |  | — |  |  | (159) |  |  | (4) |  |  | (271) |  |
| Interest rate contracts in an asset position | — |  |  | 10 |  |  | — |  |  | — |  |  | 10 |  |
| Interest rate contracts in a liability position | — |  |  | — |  |  | — |  |  | (31) |  |  | (31) |  |
| Net asset (liability) | 76 |  |  | 10 |  |  | (101) |  |  | (35) |  |  | (50) |  |
| Total derivatives at fair value | $ | 94 |  |  | $ | 10 |  |  | $ | (98) |  |  | $ | (35) |  |  | $ | (29) |  |

[0001571996-21-000026:notes:160]
[same as prior period, unchanged from 0001571996-20-000051:notes:181]

[0001571996-21-000026:notes:161]
|  | April 30, 2021 |
|  | Gross Amounts of Recognized Assets/ (Liabilities) |  | Gross Amounts Offset in the Statement of Financial Position |  | Net Amounts of Assets/ (Liabilities) Presented in the Statement of Financial Position |  | Gross Amounts not Offset in the Statement of Financial Position |  | Net Amount of Assets/ (Liabilities) Recognized in the Statement of Financial Position |
|  | Financial Instruments |  | Cash Collateral Received or Pledged |  |
|  | (in millions) |
| Derivative instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Financial assets | $ | 242 |  |  | $ | (173) |  |  | $ | 69 |  |  | $ | — |  |  | $ | — |  |  | $ | 69 |  |
| Financial liabilities | (276) |  |  | 173 |  |  | (103) |  |  | — |  |  | 6 |  |  | (97) |  |
| Total derivative instruments | $ | (34) |  |  | $ | — |  |  | $ | (34) |  |  | $ | — |  |  | $ | 6 |  |  | $ | (28) |  |
|  | January 29, 2021 |
|  | Gross Amounts of Recognized Assets/ (Liabilities) |  | Gross Amounts Offset in the Statement of Financial Position |  | Net Amounts of Assets/ (Liabilities) Presented in the Statement of Financial Position |  | Gross Amounts not Offset in the Statement of Financial Position |  | Net Amount of Assets/ (Liabilities) Recognized in the Statement of Financial Position |
|  | Financial Instruments |  | Cash Collateral Received or Pledged |  |
|  | (in millions) |
| Derivative instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Financial assets | $ | 298 |  |  | $ | (194) |  |  | $ | 104 |  |  | $ | — |  |  | $ | — |  |  | $ | 104 |  |
| Financial liabilities | (327) |  |  | 194 |  |  | (133) |  |  | — |  |  | 2 |  |  | (131) |  |
| Total derivative instruments | $ | (29) |  |  | $ | — |  |  | $ | (29) |  |  | $ | — |  |  | $ | 2 |  |  | $ | (27) |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001571996-21-000026:notes:162]
NOTE 7 — GOODWILL AND INTANGIBLE ASSETS

[0001571996-21-000026:notes:163]
[same as prior period, unchanged from 0001571996-20-000051:notes:193]

[0001571996-21-000026:notes:164]
The Infrastructure Solutions Group, Client Solutions Group, and VMware reporting units are consistent with the reportable segments identified in Note 16 of the Notes to the Condensed Consolidated Financial Statements.  Offerings within Other businesses as defined below represent separate reporting units.

[0001571996-21-000026:notes:165]
[same as prior period, unchanged from 0001571996-20-000051:notes:195]

[0001571996-21-000026:notes:166]
|  | Infrastructure Solutions Group |  | Client Solutions Group |  | VMware |  | Other Businesses (a) |  | Total |
|  | (in millions) |
| Balance as of January 29, 2021 | $ | 15,324 |  |  | $ | 4,237 |  |  | $ | 20,802 |  |  | $ | 466 |  |  | $ | 40,829 |  |
| Impact of foreign currency translation | 10 |  |  | — |  |  | — |  |  | — |  |  | 10 |  |
| Balance as of April 30, 2021 | $ | 15,334 |  |  | $ | 4,237 |  |  | $ | 20,802 |  |  | $ | 466 |  |  | $ | 40,839 |  |

[0001571996-21-000026:notes:167]
(a)    Goodwill allocated to Other businesses consists of Secureworks, Virtustream, and Boomi.

[0001571996-21-000026:notes:168]
Goodwill Impairment Tests — Goodwill and indefinite-lived intangible assets are tested for impairment annually during the third fiscal quarter and whenever events or circumstances may indicate that an impairment has occurred.  No impairment test was performed other than the Company’s annual impairment review in the third quarter of Fiscal 2021.

[0001571996-21-000026:notes:169]
[same as prior period, unchanged from 0001571996-20-000051:notes:201]

[0001571996-21-000026:notes:170]
Management exercised significant judgment related to the above assessment, including the identification of goodwill reporting units, assignment of assets and liabilities to goodwill reporting units, assignment of goodwill to reporting units, and determination of the fair value of each goodwill reporting unit.  The fair value of each goodwill reporting unit is generally estimated using a combination of public company multiples and discounted cash flow methodologies, unless the reporting unit relates to a publicly-traded entity (VMware, Inc. or Secureworks), in which case the fair value is determined based primarily on the public company market valuation.  The discounted cash flow and public company multiples methodologies require significant judgment, including estimation of future revenues, gross margins, and operating expenses, which is dependent on internal forecasts, current and anticipated economic conditions and trends, selection of market multiples through assessment of the reporting unit’s performance relative to peer competitors, the estimation of the long-term revenue growth rate and discount rate of the Company’s business, and the determination of the Company’s weighted average cost of capital.  Changes in these estimates and assumptions could materially affect the fair value of the goodwill reporting unit, potentially resulting in a non-cash impairment charge.

[0001571996-21-000026:notes:171]
The fair value of the indefinite-lived trade names is generally estimated using discounted cash flow methodologies.  The discounted cash flow methodology requires significant judgment, including estimation of future revenue, the estimation of the long-term revenue growth rate of the Company’s business and the determination of the Company’s weighted average cost of capital and royalty rates.  Changes in these estimates and assumptions could materially affect the fair value of the indefinite-lived intangible assets, potentially resulting in a non-cash impairment charge.

[0001571996-21-000026:notes:172]
Based on the results of the annual impairment test performed during the fiscal year ended January 29, 2021, the fair values of each of the reporting units exceeded their carrying values.

[0001571996-21-000026:notes:173]
[same as prior period, unchanged from 0001571996-20-000051:notes:206]

[0001571996-21-000026:notes:174]
[same as prior period, unchanged from 0001571996-20-000051:notes:207]

[0001571996-21-000026:notes:175]
|  | April 30, 2021 |  | January 29, 2021 |
|  | Gross |  | AccumulatedAmortization |  | Net |  | Gross |  | AccumulatedAmortization |  | Net |
|  | (in millions) |
| Customer relationships | $ | 22,394 |  |  | $ | (15,864) |  |  | $ | 6,530 |  |  | $ | 22,394 |  |  | $ | (15,448) |  |  | $ | 6,946 |  |
| Developed technology | 15,499 |  |  | (12,409) |  |  | 3,090 |  |  | 15,488 |  |  | (12,136) |  |  | 3,352 |  |
| Trade names | 1,285 |  |  | (931) |  |  | 354 |  |  | 1,285 |  |  | (909) |  |  | 376 |  |
| Definite-lived intangible assets | 39,178 |  |  | (29,204) |  |  | 9,974 |  |  | 39,167 |  |  | (28,493) |  |  | 10,674 |  |
| Indefinite-lived trade names | 3,755 |  |  | — |  |  | 3,755 |  |  | 3,755 |  |  | — |  |  | 3,755 |  |
| Total intangible assets | $ | 42,933 |  |  | $ | (29,204) |  |  | $ | 13,729 |  |  | $ | 42,922 |  |  | $ | (28,493) |  |  | $ | 14,429 |  |

[0001571996-21-000026:notes:176]
Amortization expense related to definite-lived intangible assets was approximately $0.7 billion and $0.9 billion for the three months ended April 30, 2021 and May 1, 2020, respectively.  There were no material impairment charges related to intangible assets during the three months ended April 30, 2021 or May 1, 2020.

[0001571996-21-000026:notes:177]
[same as prior period, unchanged from 0001571996-20-000051:notes:210]

[0001571996-21-000026:notes:178]
[same as prior period, unchanged from 0001571996-20-000051:notes:211]

[0001571996-21-000026:notes:179]
|  | April 30, 2021 |
|  | (in millions) |
| Fiscal 2022 (remaining nine months) | $ | 1,993 |  |
| Fiscal 2023 | 1,826 |  |
| Fiscal 2024 | 1,457 |  |
| Fiscal 2025 | 1,107 |  |
| Fiscal 2026 | 861 |  |
| Thereafter | 2,730 |  |
| Total | $ | 9,974 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001571996-21-000026:notes:180]
NOTE 8 — DEFERRED REVENUE

[0001571996-21-000026:notes:181]
[same as prior period, unchanged from 0001571996-20-000051:notes:214]

[0001571996-21-000026:notes:182]
[same as prior period, unchanged from 0001571996-20-000051:notes:215]

[0001571996-21-000026:notes:183]
|  | Three Months Ended |  |  |
|  | April 30, 2021 |  | May 1, 2020 |  |  |  |  |
|  | (in millions) |
| Deferred revenue: |  |  |  |  |  |  |  |
| Deferred revenue at beginning of period | $ | 30,801 |  |  | $ | 27,800 |  |  |  |  |  |
| Revenue deferrals | 6,480 |  |  | 5,423 |  |  |  |  |  |
| Revenue recognized | (5,905) |  |  | (5,356) |  |  |  |  |  |
| Other (a) | — |  |  | (250) |  |  |  |  |  |
| Deferred revenue at end of period | $ | 31,376 |  |  | $ | 27,617 |  |  |  |  |  |
| Short-term deferred revenue | $ | 16,835 |  |  | $ | 14,766 |  |  |  |  |  |
| Long-term deferred revenue | $ | 14,541 |  |  | $ | 12,851 |  |  |  |  |  |

[0001571996-21-000026:notes:184]
(a) For the three months ended May 1, 2020, Other represents the reclassification of RSA Security deferred revenue to liabilities held for sale. See Note 1 of the Notes to the Condensed Consolidated Financial Statements for more information about the divestiture of RSA Security.

[0001571996-21-000026:notes:185]
Remaining Performance Obligations — Remaining performance obligations represent the aggregate amount of the transaction price allocated to performance obligations not delivered, or partially undelivered, as of the end of the reporting period.  Remaining performance obligations include deferred revenue plus unbilled amounts not yet recorded in deferred revenue.  The value of the transaction price allocated to remaining performance obligations as of April 30, 2021 was approximately $42 billion.  The Company expects to recognize approximately 61% of remaining performance obligations as revenue in the next twelve months, and the remainder thereafter.

[0001571996-21-000026:notes:186]
The aggregate amount of the transaction price allocated to remaining performance obligations does not include amounts owed under cancellable contracts where there is no substantive termination penalty.  The Company applied the practical expedient to exclude the value of remaining performance obligations for contracts for which revenue is recognized at the amount to which the Company has the right to invoice for services performed.

[0001571996-21-000026:notes:187]
[same as prior period, unchanged from 0001571996-20-000051:notes:221]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001571996-21-000026:notes:188]
NOTE 9 — COMMITMENTS AND CONTINGENCIES

[0001571996-21-000026:notes:189]
Legal Matters

[0001571996-21-000026:notes:190]
The Company is involved in various claims, suits, assessments, investigations, and legal proceedings that arise from time to time in the ordinary course of its business, including those identified below, consisting of matters involving consumer, antitrust, tax, intellectual property, and other issues on a global basis.

[0001571996-21-000026:notes:191]
The Company accrues a liability when it believes that it is both probable that a liability has been incurred and that it can reasonably estimate the amount of the loss.  The Company reviews these accruals at least quarterly and adjusts them to reflect ongoing negotiations, settlements, rulings, advice of legal counsel, and other relevant information.  To the extent new information is obtained and the Company’s views on the probable outcomes of claims, suits, assessments, investigations, or legal proceedings change, changes in the Company’s accrued liabilities would be recorded in the period in which such a determination is made.  For some matters, the amount of liability is not probable or the amount cannot be reasonably estimated and therefore accruals have not been made.

[0001571996-21-000026:notes:192]
The following is a discussion of the Company’s significant legal matters and other proceedings:

[0001571996-21-000026:notes:193]
Class Actions Related to the Class V Transaction — Four purported stockholders brought putative class action complaints arising out of the Class V transaction described in Note 1 of the Notes to the Condensed Consolidated Financial Statements.  The actions were captioned Hallandale Beach Police and Fire Retirement Plan v. Michael Dell et al. (Civil Action No. 2018-0816-JTL), Howard Karp v. Michael Dell et al. (Civil Action No. 2019-0032-JTL), Miramar Police Officers’ Retirement Plan v. Michael Dell et al. (Civil Action No. 2019-0049-JTL), and Steamfitters Local 449 Pension Plan v. Michael Dell et al. (Civil Action No. 2019-0115-JTL).  The four actions were consolidated in the Delaware Chancery Court into In Re Dell Class V Litigation (Consol. C.A. No. 2018-0816-JTL), which names as defendants the Company’s board of directors and certain stockholders of the Company, including Michael S. Dell.  The plaintiffs generally allege that the defendants breached their fiduciary duties to the former holders of Class V Common Stock in connection with the Class V transaction by allegedly causing the Company to enter into a transaction that favored the interests of the controlling stockholders at the expense of such former stockholders.  The plaintiffs seek, among other remedies, a judicial declaration that the defendants breached their fiduciary duties and an award of damages, fees, and costs.  The plaintiffs filed an amended complaint in August 2019 making substantially similar allegations to those described above.  The defendants filed a motion to dismiss the action in September 2019.  The court denied the motion in June 2020 and the case is currently in the discovery phase.  Trial is currently scheduled to begin on May 3, 2022.

[0001571996-21-000026:notes:194]
Patent Litigation — On April 25, 2019, Cirba Inc. and Cirba IP, Inc. (collectively, “Cirba”) filed a lawsuit against VMware, Inc. in the United States District Court for the District of Delaware (the “Delaware Court”), alleging two patent infringement claims and three trademark infringement-related claims (the “First Action”).  Following a hearing on August 6, 2019, the Delaware Court denied Cirba’s preliminary injunction motion.  On August 20, 2019, VMware, Inc. filed counterclaims against Cirba, asserting among other claims that Cirba is infringing four VMware, Inc. patents.  The Delaware Court severed those claims from the January 2020 trial on Cirba’s claims.  On January 24, 2020, a jury returned a verdict that VMware, Inc. had willfully infringed Cirba’s two patents and awarded approximately $237 million in damages.  As to Cirba’s trademark-related claims, the jury found that VMware, Inc. was not liable.  A total of $237 million was accrued for the First Action as of January 31, 2020, which reflected the estimated losses that were considered both probable and reasonably estimable at that time.  The amount accrued for this matter was included in Accrued and other in the Consolidated Statements of Financial Position as of January 31, 2020, and the charge was classified in Selling, general and administrative in the Consolidated Statements of Income (Loss) for the fiscal year ended January 31, 2020.  On March 9, 2020, the parties filed post-trial motions in the First Action.  On December 21, 2020, the Delaware Court granted VMware, Inc.’s request for a new trial based, in part, on Cirba’s Inc.’s lack of standing, set aside the verdict and damages award, and denied Cirba’s post-trial motions (the “Post-Trial Order”).

[0001571996-21-000026:notes:195]
On October 22, 2019, VMware, Inc. filed a separate lawsuit against Cirba in the United States District Court for the Eastern District of Virginia for infringing four additional VMware, Inc. patents (The “Second Action”).  The Virginia court transferred the Second Action to the Delaware Court on February 25, 2020.  On March 23, 2020, Cirba filed a counterclaim asserting one additional patent against VMware, Inc.  The Delaware Court consolidated the First and Second Actions and ordered a consolidated trial on all of the parties’ patent infringement claims and counterclaims.  On May 3, 2021, the Court denied Cirba’s motion to certify the Post-Trial Order to enable an interlocutory appeal to the United States Court of Appeals for the Federal Circuit.  Also, on May 3, 2021, the Court granted Cirba’s motion for leave to assert an additional patent against VMware, Inc. Separately, in February 2021, the U.S. Patent and Trademark Office (“PTO”) granted VMware, Inc.’s ex parte reexamination request as to the ‘687 patent (which was at issue in the January 2020 trial and subject to the Court’s new trial order).  In addition, in May 2021, the PTO’s Patent Trial and Appeal Board instituted Inter Partes Review (“IPR”) of the ‘492 patent in response to VMware, Inc.’s IPR petition.  As of January 29, 2021, VMware, Inc. reassessed its estimated loss accrual for the First Action based on the Post-Trial Order and determined that a loss was no longer probable and reasonably estimable with respect to the consolidated First and Second Actions.  Accordingly, the estimated loss accrual recognized during the fiscal year ended January 31, 2020 totaling $237 million was adjusted to $0 with the credit included in Selling, general, and administrative in the Consolidated Statements of Income (Loss) for the fiscal year ended January 29, 2021.  VMware, Inc. has reported that is unable at this time to assess whether, or to what extent, it may be found liable and, if found liable, what the damages may be. VMware, Inc. intends to vigorously defend itself in this matter.

[0001571996-21-000026:notes:196]
Class Actions Related to VMware, Inc.’s Acquisition of Pivotal — Two purported stockholders brought putative class action complaints arising out of VMware, Inc.’s acquisition of Pivotal Software, Inc. on December 30, 2019 as described in Note 1 of the Notes to the Condensed Consolidated Financial Statements.  The two actions were consolidated in the Delaware Chancery Court into In re: Pivotal Software, Inc. Stockholders Litigation (Civil Action No. 2020-0440-KSJM).  The complaint names as defendants the Company, VMware, Inc., Michael S. Dell, and certain officers of Pivotal.  The plaintiffs generally allege that the defendants breached their fiduciary duties to the former holders of Pivotal Class A Common Stock in connection with VMware, Inc.’s acquisition of Pivotal by allegedly causing Pivotal to enter into a transaction that favored the interests of Pivotal’s controlling stockholders at the expense of such former stockholders.  The plaintiffs seek, among other remedies, a judicial declaration that the defendants breached their fiduciary duties and an award of damages, fees, and costs.

[0001571996-21-000026:notes:197]
Other Litigation — Dell does not currently anticipate that any of these matters will have a material adverse effect on its business, financial condition, results of operations, or cash flows.

[0001571996-21-000026:notes:198]
In accordance with the relevant accounting guidance, the Company provides disclosures of matters where it is at least reasonably possible that the Company could experience a material loss exceeding the amounts already accrued for these or other proceedings or matters.  In addition, the Company also discloses matters based on its consideration of other matters and qualitative factors, including the experience of other companies in the industry, and investor, customer, and employee relations considerations.  As of April 30, 2021, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for these or other proceedings or matters has been incurred.  However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company’s business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters.  Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company’s business, financial condition, results of operations, or cash flows will depend on a number of variables, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.

[0001571996-21-000026:notes:199]
Indemnifications

[0001571996-21-000026:notes:200]
In the ordinary course of business, the Company enters into contractual arrangements under which it may agree to indemnify other parties for losses incurred from certain events as defined in the relevant contract, such as litigation, regulatory penalties, or claims relating to past performance.  Such indemnification obligations may not be subject to maximum loss clauses.  Historically, payments related to these indemnifications have not been material to the Company.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001571996-21-000026:notes:201]
NOTE 10 — INCOME AND OTHER TAXES

[0001571996-21-000026:notes:202]
For the three months ended April 30, 2021, the Company’s effective income tax rate was 5.0% on pre-tax income of $987 million.  For the three months ended May 1, 2020, the Company’s effective income tax rate was -33.8% on pre-tax income of $136 million. The changes in the Company’s effective income tax rate is primarily driven by higher discrete tax benefits on higher pre-tax income and a change in the Company’s jurisdictional mix of income.  For the three months ended April 30, 2021, the Company’s effective income tax rate includes discrete tax benefits of $103 million related to stock-based compensation.  In comparison, for the three months ended May 1, 2020, the Company’s effective income tax rate includes a discrete tax benefit of $59 million from an intra-entity asset transfer of certain of Pivotal’s intellectual property to an Irish subsidiary that was completed by VMware, Inc. during the quarter.  The effective income tax rate for future quarters of Fiscal 2022 may be impacted by the actual mix of jurisdictions in which income is generated, as well as the impact of any discrete tax items.

[0001571996-21-000026:notes:203]
The differences between the estimated effective income tax rates and the U.S. federal statutory rate of 21% principally result from the Company’s geographical distribution of income, differences between the book and tax treatment of certain items, and the discrete tax items discussed above.  In certain jurisdictions, the Company’s tax rate is significantly less than the applicable statutory rate as a result of tax holidays.  The majority of the Company’s foreign income that is subject to these tax holidays and lower tax rates is attributable to Singapore and China.  A significant portion of these income tax benefits relate to a tax holiday that will be effective until January 31, 2029.  The Company’s other tax holidays will expire in whole or in part during fiscal years 2022 through 2030.  Many of these tax holidays and reduced tax rates may be extended when certain conditions are met or may be terminated early if certain conditions are not met.  As of April 30, 2021, the Company was not aware of any matters of non-compliance related to these tax holidays.

[0001571996-21-000026:notes:204]
The Internal Revenue Service (“IRS”) is currently examining fiscal years 2015 through 2019.  The Company believes it has valid positions supporting its tax returns and that it is adequately reserved. The Company is also currently under income tax audits in various state and foreign jurisdictions.  The Company is undergoing negotiations, and in some cases contested proceedings, relating to tax matters with the taxing authorities in these jurisdictions.  The Company believes that it has valid positions supporting its tax returns and that it has provided adequate reserves related to all matters contained in tax periods open to examination.  Although the Company believes it has made adequate provisions for the uncertainties surrounding these audits, should the Company experience unfavorable outcomes, such outcomes could have a material impact on its results of operations, financial position, and cash flows.  With respect to major U.S., state and foreign taxing jurisdictions, the Company is generally not subject to tax examinations for years prior to the fiscal year ended January 29, 2010.

[0001571996-21-000026:notes:205]
Judgment is required in evaluating the Company’s uncertain tax positions and determining the Company’s provision for income taxes.  The unrecognized tax benefits were $1.4 billion as of both April 30, 2021 and January 29, 2021, and are included in other non-current liabilities in the Condensed Consolidated Statements of Financial Position.  The Company does not anticipate a significant change to the total amount of unrecognized tax benefits within the next twelve months.

[0001571996-21-000026:notes:206]
The Company takes certain non-income tax positions in the jurisdictions in which it operates and has received certain non-income tax assessments from various jurisdictions.  The Company believes that a material loss in these matters is not probable and that it is not reasonably possible that a material loss exceeding amounts already accrued has been incurred.  The Company believes its positions in these non-income tax litigation matters are supportable and that it ultimately will prevail in the matters.  In the normal course of business, the Company’s positions and conclusions related to its non-income taxes could be challenged and assessments may be made.  To the extent new information is obtained and the Company’s views on its positions, probable outcomes of assessments, or litigation change, changes in estimates to the Company’s accrued liabilities would be recorded in the period in which such a determination is made.  In the resolution process for income tax and non-income tax audits, the Company is required in certain situations to provide collateral guarantees or indemnification to regulators and tax authorities until the matter is resolved.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001571996-21-000026:notes:207]
NOTE 11 — ACCUMULATED OTHER COMPREHENSIVE INCOME (LOSS)

[0001571996-21-000026:notes:208]
[same as prior period, unchanged from 0001571996-20-000051:notes:243]

[0001571996-21-000026:notes:209]
[same as prior period, unchanged from 0001571996-20-000051:notes:244]

[0001571996-21-000026:notes:210]
|  | Foreign Currency Translation Adjustments |  |  |  | Cash Flow Hedges |  | Pension and Other Postretirement Plans |  | Accumulated Other Comprehensive Income (Loss) |
|  | (in millions) |
| Balances as of January 29, 2021 | $ | (150) |  |  |  |  | $ | (86) |  |  | $ | (78) |  |  | $ | (314) |  |
| Other comprehensive income (loss) before reclassifications | (7) |  |  |  |  | (1) |  |  | 1 |  |  | (7) |  |
| Amounts reclassified from accumulated other comprehensive income (loss) | — |  |  |  |  | 27 |  |  | — |  |  | 27 |  |
| Total change for the period | (7) |  |  |  |  | 26 |  |  | 1 |  |  | 20 |  |
| Less: Change in comprehensive income (loss) attributable to non-controlling interests | — |  |  |  |  | — |  |  | — |  |  | — |  |
| Balances as of April 30, 2021 | $ | (157) |  |  |  |  | $ | (60) |  |  | $ | (77) |  |  | $ | (294) |  |

[0001571996-21-000026:notes:211]
Amounts related to the Company’s cash flow hedges are reclassified to net income during the same period in which the items being hedged are recognized in earnings.  See Note 6 of the Notes to the Condensed Consolidated Financial Statements for more information on the Company’s derivative instruments.

[0001571996-21-000026:notes:212]
[same as prior period, unchanged from 0001571996-20-000051:notes:247]

[0001571996-21-000026:notes:213]
|  |  |  | Three Months Ended |
|  |  |  | April 30, 2021 |  |  |  | May 1, 2020 |
|  |  |  | Cash Flow Hedges |  | Pensions |  | Total |  |  |  | Cash Flow Hedges |  | Pensions |  | Total |
|  |  |  | (in millions) |
| Total reclassifications, net of tax: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue |  |  | $ | (29) |  |  | $ | — |  |  | $ | (29) |  |  |  |  | $ | 96 |  |  | $ | — |  |  | $ | 96 |  |
| Cost of net revenue |  |  | 2 |  |  | — |  |  | 2 |  |  |  |  | 4 |  |  | — |  |  | 4 |  |
| Operating expenses |  |  | — |  |  | — |  |  | — |  |  |  |  | — |  |  | (2) |  |  | (2) |  |
| Total reclassifications, net of tax |  |  | $ | (27) |  |  | $ | — |  |  | $ | (27) |  |  |  |  | $ | 100 |  |  | $ | (2) |  |  | $ | 98 |  |


## us-gaap:MinorityInterestDisclosureTextBlock

[0001571996-21-000026:notes:214]
NOTE 12 — NON-CONTROLLING INTERESTS

[0001571996-21-000026:notes:215]
VMware, Inc. — The non-controlling interests’ share of equity in VMware, Inc. is reflected as a component of the non-controlling interests in the Condensed Consolidated Statements of Financial Position and was $5.0 billion as of both April 30, 2021 and January 29, 2021.  As of April 30, 2021 and January 29, 2021, the Company held approximately 80.7% and 80.6%, respectively, of the outstanding equity interest in VMware, Inc.

[0001571996-21-000026:notes:216]
Secureworks — The non-controlling interests’ share of equity in Secureworks is reflected as a component of the non-controlling interests in the Condensed Consolidated Statements of Financial Position and was $101 million and $96 million as of April 30, 2021 and January 29, 2021, respectively.  As of April 30, 2021 and January 29, 2021, the Company held approximately 84.6% and 85.7%, respectively, of the outstanding equity interest in Secureworks, excluding restricted stock awards (“RSAs”) and 83.8% and 84.9%, respectively, including RSAs.

[0001571996-21-000026:notes:217]
[same as prior period, unchanged from 0001571996-20-000051:notes:253]

[0001571996-21-000026:notes:218]
|  | Three Months Ended |
|  | April 30, 2021 |  |  |
|  | (in millions) |
| Net income attributable to Dell Technologies Inc. | $ | 887 |  |  |  |
| Transfers (to)/from the non-controlling interests: |  |  |  |
| Increase in Dell Technologies Inc. additional paid-in-capital for equity issuances and other equity activity | 251 |  |  |  |
| Decrease in Dell Technologies Inc. additional paid-in-capital for equity issuances and other equity activity | (249) |  |  |  |
| Net transfers to non-controlling interests | 2 |  |  |  |
| Change from net income attributable to Dell Technologies Inc. and transfers to the non-controlling interests | $ | 889 |  |  |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001571996-21-000026:notes:219]
NOTE 13 — CAPITALIZATION

[0001571996-21-000026:notes:220]
[same as prior period, unchanged from 0001571996-20-000051:notes:256]

[0001571996-21-000026:notes:221]
|  | Authorized |  | Issued |  | Outstanding |
|  | (in millions) |
| Common stock as of April 30, 2021 |
| Class A | 600 |  |  | 385 |  |  | 385 |  |
| Class B | 200 |  |  | 102 |  |  | 102 |  |
| Class C | 7,900 |  |  | 285 |  |  | 277 |  |
| Class D | 100 |  |  | — |  |  | — |  |
| Class V | 343 |  |  | — |  |  | — |  |
|  | 9,143 |  |  | 772 |  |  | 764 |  |
| Common stock as of January 29, 2021 |
| Class A | 600 |  |  | 385 |  |  | 385 |  |
| Class B | 200 |  |  | 102 |  |  | 102 |  |
| Class C | 7,900 |  |  | 274 |  |  | 266 |  |
| Class D | 100 |  |  | — |  |  | — |  |
| Class V | 343 |  |  | — |  |  | — |  |
|  | 9,143 |  |  | 761 |  |  | 753 |  |

[0001571996-21-000026:notes:222]
[same as prior period, unchanged from 0001571996-20-000051:notes:258]

[0001571996-21-000026:notes:223]
[same as prior period, unchanged from 0001571996-20-000051:notes:259]

[0001571996-21-000026:notes:224]
The Company is authorized to issue one million shares of preferred stock, par value $0.01 per share.  As of April 30, 2021 and January 29, 2021, no shares of preferred stock were issued or outstanding.

[0001571996-21-000026:notes:225]
[same as prior period, unchanged from 0001571996-20-000051:notes:261]

[0001571996-21-000026:notes:226]
[same as prior period, unchanged from 0001571996-20-000051:notes:262]

[0001571996-21-000026:notes:227]
[same as prior period, unchanged from 0001571996-20-000051:notes:263]

[0001571996-21-000026:notes:228]
Conversion Rights — Under the Company’s certificate of incorporation, at any time and from time to time, any holder of Class A Common Stock or Class B Common Stock has the right to convert all or any of the shares of Class A Common Stock or Class B Common Stock, as applicable, held by such holder into shares of Class C Common Stock on a one-to-one basis.  During the three months ended April 30, 2021, the Company issued 49,209 shares of Class C Common Stock to stockholders upon the conversion of the same number of shares of Class A Common Stock into Class C Common Stock in accordance with the Company’s certificate of incorporation.

[0001571996-21-000026:notes:229]
[same as prior period, unchanged from 0001571996-20-000051:notes:265]

[0001571996-21-000026:notes:230]
[same as prior period, unchanged from 0001571996-20-000051:notes:266]

[0001571996-21-000026:notes:231]
On February 24, 2020, the Company’s board of directors approved a stock repurchase program under which the Company is authorized to repurchase up to $1.0 billion of shares of the Class C Common Stock over a 24-month period expiring on February 28, 2022, of which approximately $760 million remained available as of April 30, 2021.   During the three months ended May 1, 2020, the Company repurchased approximately 6 million shares of Class C Common Stock for approximately $240 million and subsequently suspended activity under its stock repurchase program.

[0001571996-21-000026:notes:232]
[same as prior period, unchanged from 0001571996-20-000051:notes:268]

[0001571996-21-000026:notes:233]
[same as prior period, unchanged from 0001571996-20-000051:notes:269]

[0001571996-21-000026:notes:234]
On May 29, 2019, VMware, Inc.’s board of directors authorized the repurchase of up to $1.5 billion of VMware, Inc.’s Class A common stock through January 29, 2021.  On July 15, 2020, VMware, Inc.’s board of directors extended authorization of VMware, Inc.’s existing repurchase program and authorized the repurchase of up to an additional $1.0 billion of VMware, Inc.’s Class A common stock through January 28, 2022.  As of April 30, 2021, the cumulative authorized amount remaining for stock repurchases was $684 million.

[0001571996-21-000026:notes:235]
During the three months ended April 30, 2021, VMware, Inc. repurchased 2.5 million shares of its Class A common stock in the open market for approximately $371 million.  During the three months ended May 1, 2020, VMware, Inc. repurchased approximately 1.5 million shares of its Class A common stock in the open market for approximately $181 million.

[0001571996-21-000026:notes:236]
[same as prior period, unchanged from 0001571996-20-000051:notes:272]

[0001571996-21-000026:notes:237]
The above VMware, Inc. Class A common stock repurchases for the three months ended April 30, 2021 and May 1, 2020 exclude shares repurchased to settle employee tax withholding related to the vesting of VMware, Inc. stock awards of $52 million and $154 million, respectively.


## us-gaap:EarningsPerShareTextBlock

[0001571996-21-000026:notes:238]
NOTE 14 — EARNINGS PER SHARE

[0001571996-21-000026:notes:239]
[same as prior period, unchanged from 0001571996-20-000051:notes:275]

[0001571996-21-000026:notes:240]
[same as prior period, unchanged from 0001571996-20-000051:notes:276]

[0001571996-21-000026:notes:241]
[same as prior period, unchanged from 0001571996-20-000051:notes:277]

[0001571996-21-000026:notes:242]
[same as prior period, unchanged from 0001571996-20-000051:notes:278]

[0001571996-21-000026:notes:243]
|  | Three Months Ended |  |  |
|  | April 30, 2021 |  | May 1, 2020 |  |  |  |  |
| Earnings per share attributable to Dell Technologies Inc. |  |  |  |  |
| Dell Technologies Common Stock — Basic | $ | 1.17 |  |  | $ | 0.19 |  |  |  |  |  |
| Dell Technologies Common Stock — Diluted | $ | 1.13 |  |  | $ | 0.19 |  |  |  |  |  |

[0001571996-21-000026:notes:244]
[same as prior period, unchanged from 0001571996-20-000051:notes:280]

[0001571996-21-000026:notes:245]
|  | Three Months Ended |  |  |
|  | April 30, 2021 |  | May 1, 2020 |  |  |  |  |
|  | (in millions) |
| Numerator: Dell Technologies Common Stock |  |  |  |  |  |  |  |
| Net income attributable to Dell Technologies — basic | $ | 887 |  |  | $ | 143 |  |  |  |  |  |
| Incremental dilution from VMware, Inc. attributable to Dell Technologies (a) | (2) |  |  | (2) |  |  |  |  |  |
| Net income attributable to Dell Technologies — diluted | $ | 885 |  |  | $ | 141 |  |  |  |  |  |
| Denominator: Dell Technologies Common Stock weighted-average shares outstanding |  |  |  |  |
| Weighted-average shares outstanding — basic | 757 |  |  | 740 |  |  |  |  |  |
| Dilutive effect of options, restricted stock units, restricted stock, and other | 25 |  |  | 15 |  |  |  |  |  |
| Weighted-average shares outstanding — diluted | 782 |  |  | 755 |  |  |  |  |  |
| Weighted-average shares outstanding — antidilutive | — |  |  | 8 |  |  |  |  |  |

[0001571996-21-000026:notes:246]
(a)The incremental dilution from VMware, Inc. represents the impact of VMware, Inc.’s dilutive securities on diluted earnings per share of Dell Technologies Common Stock, and is calculated by multiplying the difference between VMware, Inc.’s basic and diluted earnings per share by the number of shares of VMware, Inc. common stock held by the Company.  For both periods presented, there was no incremental dilution from Secureworks due to its net loss position.


## dell:TemporaryEquityTextBlock

[0001571996-21-000026:notes:247]
NOTE 15 — REDEEMABLE SHARES

[0001571996-21-000026:notes:248]
[same as prior period, unchanged from 0001571996-20-000051:notes:284]

[0001571996-21-000026:notes:249]
[same as prior period, unchanged from 0001571996-20-000051:notes:285]

[0001571996-21-000026:notes:250]
[same as prior period, unchanged from 0001571996-20-000051:notes:286]

[0001571996-21-000026:notes:251]
[same as prior period, unchanged from 0001571996-20-000051:notes:287]

[0001571996-21-000026:notes:252]
In connection with the Class V transaction described in Note 1 of the Notes to the Condensed Consolidated Financial Statements, the put feature provisions were amended to provide that the put feature will terminate upon the earlier of June 27, 2021 or the consummation of any underwritten public offering of shares of Class C Common Stock.

[0001571996-21-000026:notes:253]
[same as prior period, unchanged from 0001571996-20-000051:notes:289]

[0001571996-21-000026:notes:254]
|  | April 30, 2021 |  | January 29, 2021 |
|  | (in millions) |
| Redeemable shares classified as temporary equity | $ | 558 |  |  | $ | 472 |  |
| Issued and outstanding unrestricted common shares | 1 |  |  | 2 |  |
| Restricted stock units | 1 |  |  | — |  |
| Outstanding stock options | 3 |  |  | 6 |  |

[0001571996-21-000026:notes:255]
The increase in the value of redeemable shares during the three months ended April 30, 2021 was primarily attributable to an increase in Class C Common stock fair value, offset by a reduction in the number of shares eligible for put rights.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001571996-21-000026:notes:256]
NOTE 16 — SEGMENT INFORMATION

[0001571996-21-000026:notes:257]
[same as prior period, unchanged from 0001571996-20-000051:notes:293]

[0001571996-21-000026:notes:258]
[same as prior period, unchanged from 0001571996-20-000051:notes:295]

[0001571996-21-000026:notes:259]
[same as prior period, unchanged from 0001571996-20-000051:notes:296]

[0001571996-21-000026:notes:260]
[same as prior period, unchanged from 0001571996-20-000051:notes:297]

[0001571996-21-000026:notes:261]
[same as prior period, unchanged from 0001571996-20-000051:notes:298]

[0001571996-21-000026:notes:262]
[same as prior period, unchanged from 0001571996-20-000051:notes:299]

[0001571996-21-000026:notes:263]
|  | Three Months Ended |  |  |
|  | April 30, 2021 |  | May 1, 2020 |  |  |  |  |
|  | (in millions) |
| Consolidated net revenue: |  |  |  |  |  |  |  |
| Infrastructure Solutions Group | $ | 7,911 |  |  | $ | 7,569 |  |  |  |  |  |
| Client Solutions Group | 13,305 |  |  | 11,104 |  |  |  |  |  |
| VMware | 2,991 |  |  | 2,755 |  |  |  |  |  |
| Reportable segment net revenue | 24,207 |  |  | 21,428 |  |  |  |  |  |
| Other businesses (a) | 290 |  |  | 517 |  |  |  |  |  |
| Unallocated transactions (b) | 2 |  |  | — |  |  |  |  |  |
| Impact of purchase accounting (c) | (12) |  |  | (48) |  |  |  |  |  |
| Total consolidated net revenue | $ | 24,487 |  |  | $ | 21,897 |  |  |  |  |  |
| Consolidated operating income: |  |  |  |  |  |  |  |
| Infrastructure Solutions Group | $ | 788 |  |  | $ | 732 |  |  |  |  |  |
| Client Solutions Group | 1,090 |  |  | 592 |  |  |  |  |  |
| VMware | 841 |  |  | 773 |  |  |  |  |  |
| Reportable segment operating income | 2,719 |  |  | 2,097 |  |  |  |  |  |
| Other businesses (a) | (5) |  |  | 65 |  |  |  |  |  |
| Unallocated transactions (b) | — |  |  | (1) |  |  |  |  |  |
| Impact of purchase accounting (c) | (25) |  |  | (63) |  |  |  |  |  |
| Amortization of intangibles | (709) |  |  | (855) |  |  |  |  |  |
| Transaction-related expenses (d) | (51) |  |  | (76) |  |  |  |  |  |
| Stock-based compensation expense (e) | (435) |  |  | (370) |  |  |  |  |  |
| Other corporate expenses (f) | (119) |  |  | (95) |  |  |  |  |  |
| Total consolidated operating income | $ | 1,375 |  |  | $ | 702 |  |  |  |  |  |

[0001571996-21-000026:notes:264]
(a)Secureworks, Virtustream, and Boomi constitute Other businesses and do not meet the requirements for a reportable segment, either individually or collectively.  The results of Other businesses are not material to the Company’s overall results.  On September 1, 2020, the Company completed the sale of RSA Security.  Prior to the divestiture, RSA Security’s results were included within Other businesses.  See Note 1 of the Notes to the Condensed Consolidated Financial Statements for more information about the divestiture of RSA Security.

[0001571996-21-000026:notes:265]
[same as prior period, unchanged from 0001571996-20-000051:notes:302]

[0001571996-21-000026:notes:266]
[same as prior period, unchanged from 0001571996-20-000051:notes:303]

[0001571996-21-000026:notes:267]
[same as prior period, unchanged from 0001571996-20-000051:notes:304]

[0001571996-21-000026:notes:268]
[same as prior period, unchanged from 0001571996-20-000051:notes:305]

[0001571996-21-000026:notes:269]
(f)Other corporate expenses includes impairment charges, severance, facility action, and other costs.

[0001571996-21-000026:notes:270]
[same as prior period, unchanged from 0001571996-20-000051:notes:307]

[0001571996-21-000026:notes:271]
|  | Three Months Ended |  |  |
|  | April 30, 2021 |  | May 1, 2020 |  |  |  |  |
|  | (in millions) |
| Net revenue: |  |  |  |  |  |  |  |
| Infrastructure Solutions Group: |  |  |  |  |  |  |  |
| Servers and networking | $ | 4,109 |  |  | $ | 3,758 |  |  |  |  |  |
| Storage | 3,802 |  |  | 3,811 |  |  |  |  |  |
| Total ISG net revenue | 7,911 |  |  | 7,569 |  |  |  |  |  |
| Client Solutions Group: |  |  |  |  |  |  |  |
| Commercial | 9,803 |  |  | 8,634 |  |  |  |  |  |
| Consumer | 3,502 |  |  | 2,470 |  |  |  |  |  |
| Total CSG net revenue | 13,305 |  |  | 11,104 |  |  |  |  |  |
| VMware: |  |  |  |  |  |  |  |
| Total VMware net revenue | 2,991 |  |  | 2,755 |  |  |  |  |  |
| Total segment net revenue | $ | 24,207 |  |  | $ | 21,428 |  |  |  |  |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001571996-21-000026:notes:272]
NOTE 17 — SUPPLEMENTAL CONSOLIDATED FINANCIAL INFORMATION

[0001571996-21-000026:notes:273]
[same as prior period, unchanged from 0001571996-20-000051:notes:310]

[0001571996-21-000026:notes:274]
|  | April 30, 2021 |  | January 29, 2021 |
|  | (in millions) |
| Cash, cash equivalents, and restricted cash: |  |  |  |
| Cash and cash equivalents | $ | 14,244 |  |  | $ | 14,201 |  |
| Restricted cash - other current assets (a) | 930 |  |  | 891 |  |
| Restricted cash - other non-current assets (a) | 86 |  |  | 92 |  |
| Total cash, cash equivalents, and restricted cash | $ | 15,260 |  |  | $ | 15,184 |  |
| Inventories, net: |  |  |  |
| Production materials | $ | 2,023 |  |  | $ | 1,717 |  |
| Work-in-process | 739 |  |  | 677 |  |
| Finished goods | 1,066 |  |  | 1,008 |  |
| Total inventories, net | $ | 3,828 |  |  | $ | 3,402 |  |
| Property, plant, and equipment, net: |  |  |  |
| Computer equipment | 6,839 |  |  | 6,506 |  |
| Land and buildings | 4,670 |  |  | 4,745 |  |
| Machinery and other equipment | 3,960 |  |  | 3,933 |  |
| Total property, plant, and equipment | 15,469 |  |  | 15,184 |  |
| Accumulated depreciation and amortization | (8,912) |  |  | (8,753) |  |
| Total property, plant, and equipment, net | 6,557 |  |  | 6,431 |  |
| Other non-current assets: |  |  |  |
| Deferred and other tax assets | $ | 6,351 |  |  | $ | 6,230 |  |
| Operating lease ROU assets | 2,088 |  |  | 2,117 |  |
| Deferred commissions | 1,111 |  |  | 1,094 |  |
| Other | 1,807 |  |  | 1,755 |  |
| Total other non-current assets | $ | 11,357 |  |  | $ | 11,196 |  |

[0001571996-21-000026:notes:275]
(a)    Restricted cash primarily includes cash required to be held in escrow pursuant to DFS securitization arrangements.

[0001571996-21-000026:notes:276]
[same as prior period, unchanged from 0001571996-20-000051:notes:313]

[0001571996-21-000026:notes:277]
[same as prior period, unchanged from 0001571996-20-000051:notes:315]

[0001571996-21-000026:notes:278]
|  | Three Months Ended |
|  | April 30, 2021 |  | May 1, 2020 |
|  | (in millions) |
| Trade Receivables — Allowance for expected credit losses: |  |  |  |
| Balance at beginning of period | $ | 104 |  |  | $ | 94 |  |
| Adjustment for adoption of accounting standard (a) | — |  |  | 27 |  |
| Provision charged to income statement | 10 |  |  | 36 |  |
| Bad debt write-offs | (10) |  |  | (13) |  |
| Balance at end of period | $ | 104 |  |  | $ | 144 |  |

[0001571996-21-000026:notes:279]
(a)The Company adopted the current expected credit losses standard as of February 1, 2020 using the modified retrospective method, with the cumulative-effect adjustment to the opening balance of stockholders’ equity (deficit) as of the adoption date.

[0001571996-21-000026:notes:280]
[same as prior period, unchanged from 0001571996-20-000051:notes:317]

[0001571996-21-000026:notes:281]
[same as prior period, unchanged from 0001571996-20-000051:notes:318]

[0001571996-21-000026:notes:282]
|  | Three Months Ended |  |  |
|  | April 30, 2021 |  | May 1, 2020 |  |  |  |  |
|  | (in millions) |
| Warranty liability: |  |  |  |  |  |  |  |
| Warranty liability at beginning of period | $ | 473 |  |  | $ | 496 |  |  |  |  |  |
| Costs accrued for new warranty contracts and changes in estimates for pre-existing warranties (a) (b) | 202 |  |  | 148 |  |  |  |  |  |
| Service obligations honored | (217) |  |  | (168) |  |  |  |  |  |
| Warranty liability at end of period | $ | 458 |  |  | $ | 476 |  |  |  |  |  |
| Current portion | $ | 345 |  |  | $ | 333 |  |  |  |  |  |
| Non-current portion | $ | 113 |  |  | $ | 143 |  |  |  |  |  |

[0001571996-21-000026:notes:283]
[same as prior period, unchanged from 0001571996-20-000051:notes:320]

[0001571996-21-000026:notes:284]
[same as prior period, unchanged from 0001571996-20-000051:notes:321]

[0001571996-21-000026:notes:285]
[same as prior period, unchanged from 0001571996-20-000051:notes:322]

[0001571996-21-000026:notes:286]
[same as prior period, unchanged from 0001571996-20-000051:notes:323]

[0001571996-21-000026:notes:287]
|  | Three Months Ended |  |  |
|  | April 30, 2021 |  | May 1, 2020 |  |  |  |  |
|  | (in millions) |
| Severance liability: |  |  |  |  |  |  |  |
| Severance liability at beginning of period | $ | 138 |  |  | $ | 196 |  |  |  |  |  |
| Severance charges to provision | 30 |  |  | 98 |  |  |  |  |  |
| Cash paid and other (a) | (74) |  |  | (168) |  |  |  |  |  |
| Severance liability at end of period | $ | 94 |  |  | $ | 126 |  |  |  |  |  |

[0001571996-21-000026:notes:288]
[same as prior period, unchanged from 0001571996-20-000051:notes:325]

[0001571996-21-000026:notes:289]
The following table presents severance charges as included in the Condensed Consolidated Statements of Income for the periods indicated:

[0001571996-21-000026:notes:290]
|  | Three Months Ended |  |  |
|  | April 30, 2021 |  | May 1, 2020 |  |  |  |  |
|  | (in millions) |
| Severance charges: |  |  |  |  |  |  |  |
| Cost of net revenue | $ | 13 |  |  | $ | 10 |  |  |  |  |  |
| Selling, general, and administrative | 14 |  |  | 81 |  |  |  |  |  |
| Research and development | 3 |  |  | 7 |  |  |  |  |  |
| Total severance charges | $ | 30 |  |  | $ | 98 |  |  |  |  |  |

[0001571996-21-000026:notes:291]
[same as prior period, unchanged from 0001571996-20-000051:notes:328]

[0001571996-21-000026:notes:292]
[same as prior period, unchanged from 0001571996-20-000051:notes:329]

[0001571996-21-000026:notes:293]
|  | Three Months Ended |  |  |
|  | April 30, 2021 |  | May 1, 2020 |  |  |  |  |
|  | (in millions) |
| Interest and other, net: |  |  |  |  |  |  |  |
| Investment income, primarily interest | $ | 11 |  |  | $ | 24 |  |  |  |  |  |
| Gain on investments, net | 157 |  |  | 94 |  |  |  |  |  |
| Interest expense | (510) |  |  | (672) |  |  |  |  |  |
| Foreign exchange | (49) |  |  | (99) |  |  |  |  |  |
| Other | 3 |  |  | 87 |  |  |  |  |  |
| Total interest and other, net | $ | (388) |  |  | $ | (566) |  |  |  |  |  |


## us-gaap:SubsequentEventsTextBlock

[0001571996-21-000026:notes:294]
NOTE 18 — SUBSEQUENT EVENTS

[0001571996-21-000026:notes:295]
Debt Repayment — Subsequent to April 30, 2021, the Company repaid $1 billion principal amount of the Margin Loan Facility due April 2022.

[0001571996-21-000026:notes:296]
Boomi Divestiture — On May 1, 2021, Dell Technologies announced its entry into a definitive agreement with Francisco Partners and TPG Capital to sell Boomi and certain related assets from the Company in a cash transaction valued at $4 billion, subject to certain closing adjustments.  The transaction is expected to close by the end of calendar 2021, subject to customary closing conditions.  The transaction is intended to support the Company’s focus on fueling growth by continuing to modernize Dell Technologies’ core infrastructure and PC businesses and by expanding in high-priority areas, including hybrid and private cloud, edge, telecom and Apex.

[0001571996-21-000026:notes:297]
Boomi is included within Other Businesses and does not meet the requirements for a reportable segment.

[0001571996-21-000026:notes:298]
Other than the matters identified above, there were no known events occurring after April 30, 2021 and up until the date of the issuance of this report that would materially affect the information presented herein.
