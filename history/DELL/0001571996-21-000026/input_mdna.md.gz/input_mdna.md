# DELL MD&A — 0001571996-21-000026


## mdna

[0001571996-21-000026:mdna:1]
[same as prior period, unchanged from 0001571996-20-000051:mdna:1]

[0001571996-21-000026:mdna:2]
[same as prior period, unchanged from 0001571996-20-000051:mdna:2]

[0001571996-21-000026:mdna:3]
[same as prior period, unchanged from 0001571996-20-000051:mdna:3]

[0001571996-21-000026:mdna:4]
Our fiscal year is the 52- or 53-week period ending on the Friday nearest January 31.  We refer to our fiscal year ending January 28, 2022 and our fiscal year ended January 29, 2021 as “Fiscal 2022” and “Fiscal 2021,” respectively.  Fiscal 2022 and Fiscal 2021 include 52 weeks.

[0001571996-21-000026:mdna:5]
[same as prior period, unchanged from 0001571996-20-000051:mdna:5]

[0001571996-21-000026:mdna:6]
Dell Technologies helps organizations build their digital future and transform how they work, live, and play.  We provide customers with the industry’s broadest and most innovative technology and services portfolio for the data era, spanning both traditional infrastructure and emerging multi-cloud technologies.  We continue to seamlessly deliver differentiated and holistic IT solutions to our customers, which has driven significant revenue growth and share gains.

[0001571996-21-000026:mdna:7]
Dell Technologies’ integrated solutions help customers modernize their IT infrastructure, manage and operate in a multi-cloud world, address workforce transformation, and provide critical solutions that keep people and organizations connected, which has proven even more important in this current time of disruption caused by the coronavirus pandemic.  We are helping customers accelerate their digital transformations to improve and strengthen business and workforce productivity.  With our extensive portfolio and our commitment to innovation, we offer secure, integrated solutions that extend from the edge to the core to the cloud, and we are at the forefront of the software-defined and cloud native infrastructure era.  As further evidence of our commitment to innovation, we are evolving and expanding our IT as-a-Service and cloud offerings through Apex, and in May of Fiscal 2022, we announced new offers within our Apex portfolio.  Apex will provide our customers with greater flexibility to scale IT to meet their evolving business needs and budgets.

[0001571996-21-000026:mdna:8]
Dell Technologies’ end-to-end portfolio is supported by a world-class organization with unmatched size and scale. We operate globally in 180 countries across key functional areas, including technology and product development, marketing, sales, financial services, and global services.  Our go-to-market engine includes a 39,000-person sales force and a global network of over 200,000 channel partners.  Dell Financial Services and its affiliates (“DFS”) offer customer payment flexibility and enable synergies across the business.  We employ 34,000 full-time service and support professionals and maintain more than 2,400 vendor-managed service centers.  We manage a world-class supply chain that drives long-term growth and operating efficiencies, with approximately $70 billion in annual procurement expenditures and over 750 parts distribution centers.  Together, these elements provide a critical foundation for our success, enabling us to offer unparalleled capability to our customers and making us the integrator of choice.

[0001571996-21-000026:mdna:9]
Spin-off of VMware, Inc.

[0001571996-21-000026:mdna:10]
On April 14, 2021, Dell Technologies entered into a Separation and Distribution Agreement with VMware, Inc, in which Dell Technologies owns a majority equity stake.  Subject to the terms and conditions set forth in the Separation and Distribution Agreement, the businesses of VMware, Inc. will be separated from the remaining businesses of Dell Technologies through a series of transactions that will result in the pre-transaction stockholders of Dell Technologies owning shares in two, separate public companies: (1) VMware, Inc., which will own the businesses of VMware, Inc. and its subsidiaries, and (2) Dell Technologies, which will own Dell Technologies’ other businesses and subsidiaries (the “VMware Spin-off”).

[0001571996-21-000026:mdna:11]
VMware, Inc. will pay a cash dividend, pro rata, to each of the holders of VMware, Inc. common stock in an aggregate amount equal to an amount to be mutually agreed by the Company and VMware, Inc. between $11.5 billion and $12.0 billion, subject to the satisfaction of certain conditions of payment.  Immediately following such payment, the separation of VMware, Inc. from the Company will occur, including through the termination or settlement of certain intercompany accounts and intercompany contracts and the other transactions.  Upon the closing of the transaction, Dell Technologies intends to use net proceeds from its pro rata share of the cash dividend to repay debt.

[0001571996-21-000026:mdna:12]
The transaction is expected to close during the fourth quarter of calendar 2021, subject to certain closing conditions, including receipt of a favorable private letter ruling from the Internal Revenue Service that the transaction will qualify as tax-free for Dell Technologies stockholders for U.S. federal income tax purposes.  Either Dell Technologies or VMware, Inc. may terminate the Separation and Distribution Agreement if the VMware Spin-off is not completed on or before January 28, 2022, among other termination rights.

[0001571996-21-000026:mdna:13]
In connection with and upon consummation of the VMware Spin-off, Dell Technologies and VMware, Inc. will enter into a Commercial Framework Agreement (the “CFA”).  The CFA will provide a framework under which Dell Technologies and VMware, Inc. can continue their strategic commercial relationship after the transaction.  The CFA will have an initial term of five years, with automatic one-year renewals occurring annually thereafter, subject to certain terms and conditions.

[0001571996-21-000026:mdna:14]
The transaction announcement did not have any impact on our Condensed Consolidated Financial Statements or segment reporting.  We will report VMware results as discontinued operations upon the closing of the transaction.

[0001571996-21-000026:mdna:15]
[same as prior period, unchanged from 0001571996-20-000051:mdna:9]

[0001571996-21-000026:mdna:16]
[same as prior period, unchanged from 0001571996-20-000051:mdna:10]

[0001571996-21-000026:mdna:17]
•Infrastructure Solutions Group (“ISG”) — ISG enables the digital transformation of our customers through our trusted multi-cloud and big data solutions, which are built upon a modern data center infrastructure.  ISG works with customers in the area of hybrid cloud deployment with the goal of simplifying, streamlining, and automating cloud operations.  ISG solutions are built for multi-cloud environments and are optimized to run cloud native workloads in both public and private clouds, as well as traditional on-premise workloads.

[0001571996-21-000026:mdna:18]
Our comprehensive portfolio of advanced storage solutions includes traditional as well as next-generation storage solutions (such as all-flash arrays, scale-out file, object platforms, and software-defined solutions).  We have simplified our storage portfolio to ensure that we deliver the technology needed for our customers’ digital transformation.  We continue to make enhancements to our portfolio of storage solutions and expect that these enhancements will drive long-term improvements in the business.  In May 2020, we released our new PowerStore offering, a differentiated midrange storage solution that enables seamless updates using microservices and container-based software architecture.

[0001571996-21-000026:mdna:19]
Our server portfolio includes high-performance rack, blade, tower, and hyperscale servers, optimized for artificial intelligence and machine learning workloads.  Our networking portfolio helps our business customers transform and modernize their infrastructure, mobilize and enrich end-user experiences, and accelerate business applications and processes.

[0001571996-21-000026:mdna:20]
Our strengths in server, storage, and virtualization software solutions enable us to offer leading converged and hyper-converged solutions, allowing our customers to accelerate their IT transformation by acquiring scalable integrated IT solutions instead of building and assembling their own IT platforms.  ISG also offers attached software, peripherals, and services, including support and deployment, configuration, and extended warranty services.

[0001571996-21-000026:mdna:21]
[same as prior period, unchanged from 0001571996-20-000051:mdna:13]

[0001571996-21-000026:mdna:22]
•Client Solutions Group (“CSG”) — CSG includes branded hardware (such as desktops, workstations, and notebooks) and branded peripherals (such as displays and projectors), as well as third-party software and peripherals.  Our computing devices are designed with our commercial and consumer customers’ needs in mind, and we seek to optimize performance, reliability, manageability, design, and security.  In addition to our traditional hardware business, we have a portfolio of thin client offerings that we believe will allow us to benefit from the growth trends in cloud computing.  For our customers that are seeking to simplify client lifecycle management, our PC as a Service offering combines hardware, software, lifecycle services, and financing into one all-encompassing solution that provides predictable pricing per seat per month through Dell Financial Services.  CSG also offers attached software, peripherals, and services, including support and deployment, configuration, and extended warranty services.

[0001571996-21-000026:mdna:23]
[same as prior period, unchanged from 0001571996-20-000051:mdna:15]

[0001571996-21-000026:mdna:24]
[same as prior period, unchanged from 0001571996-20-000051:mdna:16]

[0001571996-21-000026:mdna:25]
[same as prior period, unchanged from 0001571996-20-000051:mdna:21]

[0001571996-21-000026:mdna:26]
[same as prior period, unchanged from 0001571996-20-000051:mdna:22]

[0001571996-21-000026:mdna:27]
[same as prior period, unchanged from 0001571996-20-000051:mdna:23]

[0001571996-21-000026:mdna:28]
[same as prior period, unchanged from 0001571996-20-000051:mdna:24]

[0001571996-21-000026:mdna:29]
•Boomi specializes in cloud-based integration, connecting information between existing on-premise and cloud-based applications to ensure that business processes are optimized, data is accurate and workflow is reliable.  In May, 2021, we announced our entry into a definitive agreement with Francisco Partners and TPG Capital to sell Boomi and certain related assets from the Company in a cash transaction valued at $4 billion, subject to certain closing adjustments.  The transaction is expected to close by the end of calendar 2021, subject to customary closing conditions.

[0001571996-21-000026:mdna:30]
On September 1, 2020, we completed the sale of RSA Security to a consortium of investors for total cash consideration of approximately $2.082 billion, resulting in a pre-tax gain on sale of $338 million.  The Company ultimately recorded a $21 million loss net of taxes.  The transaction was intended to further simplify our product portfolio and corporate structure.  Prior to the divestiture, RSA Security’s operating results were included within Other businesses.  See Note 1 of the Notes to the Condensed Consolidated Financial Statements included in this report for more information about this transaction.

[0001571996-21-000026:mdna:31]
58

[0001571996-21-000026:mdna:32]
Our products and services offerings are continually evolving in response to industry dynamics.  As a result, reclassifications of certain products and services solutions in major product categories may be required.  For further discussion regarding our current reportable segments, see “Results of Operations — Business Unit Results” and Note 16 of the Notes to the Condensed Consolidated Financial Statements included in this report.

[0001571996-21-000026:mdna:33]
[same as prior period, unchanged from 0001571996-20-000051:mdna:29]

[0001571996-21-000026:mdna:34]
DFS supports our businesses by offering and arranging various financing options and services for our customers primarily in North America, Europe, Australia, and New Zealand.  DFS originates, collects, and services customer receivables primarily related to the purchase or use of our product, software, and service solutions.  We also arrange financing for some of our customers in various countries where DFS does not currently operate as a captive.  DFS further strengthens our customer relationships through its flexible consumption models, which enable us to offer our customers the option to pay over time and, in certain cases, based on utilization, providing them with financial flexibility to meet their changing technological requirements.  The results of these operations are allocated to our segments based on the underlying product or service financed.  For additional information about our financing arrangements, see Note 3 of the Notes to the Condensed Consolidated Financial Statements included in this report.

[0001571996-21-000026:mdna:35]
[same as prior period, unchanged from 0001571996-20-000051:mdna:32]

[0001571996-21-000026:mdna:36]
As part of our strategy, we will continue to evaluate opportunities for strategic investments through our venture capital investment arm, Dell Technologies Capital, with a focus on emerging technology areas that are relevant to all segments of our business and that will complement our existing portfolio of solutions.  Our investment areas include storage, software-defined networking, management and orchestration, security, machine learning and artificial intelligence, Big Data and analytics, cloud, Internet of Things (“IoT”), and software development operations.  As of both April 30, 2021 and January 29, 2021, Dell Technologies held strategic investments of $1.4 billion.  In addition to these investments, we also may make disciplined acquisitions targeting businesses that advance our strategic objectives.

[0001571996-21-000026:mdna:37]
[same as prior period, unchanged from 0001571996-20-000051:mdna:34]

[0001571996-21-000026:mdna:38]
COVID-19 Pandemic and Response — In March 2020, the World Health Organization (“WHO”) declared the outbreak of  COVID-19 a pandemic.  This declaration was followed by significant governmental measures implemented in the United States and globally, including travel bans and restrictions, shelter-in-place orders, limitations and closures of non-essential businesses, and social distancing requirements in efforts to slow down and control the spread of the virus.

[0001571996-21-000026:mdna:39]
The health of our employees, customers, business partners, and communities remains our primary focus.  During Fiscal 2021, we took numerous actions in response to COVID-19, including a swift implementation of our business continuity plans.  Our crisis management team remains actively engaged to respond to changes in our environment quickly and effectively, and to ensure that our ongoing response activities are aligned with recommendations of the WHO and the U.S. Centers for Disease Control and Prevention, and with governmental regulations.  We are adjusting restrictions previously implemented as new information becomes available, governmental regulations are updated, and vaccines become more widely distributed.  Most of our employees were previously equipped with remote work capabilities over the past several years, which enabled us to quickly establish a work-from-home posture for the majority of our employees.  Further, we implemented pandemic-specific protocols for our essential employees whose jobs require them to be on-site or with customers.  We are deploying return-to-site processes in certain regions based on ongoing assessments of local conditions by our management team.   We will continue to monitor regional conditions and utilize remote work practices to ensure the health and safety of our employees, customers, and business partners.

[0001571996-21-000026:mdna:40]
We continue to work closely with our customers and business partners to support them as they expand their own remote work solutions and contingency plans and to help them access our products and services remotely.  Our agility, our breadth, and our scale will continue to benefit us in serving our customers and business partners during this period of accelerated digital transformation and uncertainty relating to the effects of COVID-19.  Notable actions we have taken include the following:

[0001571996-21-000026:mdna:41]
•Our global sales teams continue to successfully support our customers and partners remotely.

[0001571996-21-000026:mdna:42]
[same as prior period, unchanged from 0001571996-20-000051:mdna:39]

[0001571996-21-000026:mdna:43]
59

[0001571996-21-000026:mdna:44]
[same as prior period, unchanged from 0001571996-20-000051:mdna:40]

[0001571996-21-000026:mdna:45]
•The strength, scale, and resiliency of our global supply chain have afforded us flexibility to manage through the significant disruption that has occurred in the supply chain environment.  We adapted in real time to events as they unfolded by applying predictive analytics to model a variety of outcomes to respond quickly to the changing environment.  We optimized our global supply chain footprint to maximize factory uptime, for both Dell Technologies and our suppliers, by working through various local governmental regulations and mandates.  During this period, we established robust safety measures to protect the health and safety of our essential team members.

[0001571996-21-000026:mdna:46]
•We continue to drive innovation and excellence in engineering with a largely remote workforce.  Engineers and product teams continued to deliver several critical solutions, including cloud updates, key client product refreshes,  PowerStore midrange storage and software, and recently announced IT as-a-service and cloud offerings within the Apex portfolio.

[0001571996-21-000026:mdna:47]
During Fiscal 2021, we took precautionary measures to increase our cash position and preserve financial flexibility.  We also took a series of prudent steps to manage expenses and preserve liquidity that included, among others, global hiring limitations, a reduction in consulting, contractor and facilities-related costs, global travel restrictions, and a temporary suspension of the Dell 401(k) match program for U.S. employees.  Effective January 1, 2021, we resumed the Dell 401(k) match program, and in the fourth quarter of Fiscal 2021, we began to reinstate selected employee-related compensation benefits.  We will continue to invest in long-term projects to support our growth and innovation initiatives, while focusing on operating expense controls in certain areas of the business.  All of these actions are aligned with our strategy, which remains unchanged, of focusing on gaining share, integrating and innovating across the Dell Technologies portfolio, and strengthening our capital structure.

[0001571996-21-000026:mdna:48]
The impact of COVID-19 accelerated digital transformation, and we continue to see opportunities to create value and grow through the remainder of Fiscal 2022 in response to resilient demand for our IT solutions driven by a technology-enabled world.  We will continue to actively monitor global events and pursue prudent decisions to navigate in this uncertain and ever-changing environment.

[0001571996-21-000026:mdna:49]
[same as prior period, unchanged from 0001571996-20-000051:mdna:47]

[0001571996-21-000026:mdna:50]
We are seeing an accelerated rate of change in the IT industry.  We seek to address our customers’ evolving needs and their broader digital transformation objectives as they embrace the hybrid multi-cloud environment of today.  For many customers, a top digital priority is to build stable and resilient remote operational capabilities.  We are seeing demand for simpler, more agile IT across multiple clouds.  The pandemic accelerated the introduction and adoption of new technologies to ensure productivity and collaboration from anywhere.  In light of this rapid pace of innovation, we continue to invest in research and development, sales, and other key areas of our business to deliver superior products and solutions capabilities and to drive long-term sustainable growth.

[0001571996-21-000026:mdna:51]
Supply Chain — During the first quarter of Fiscal 2022, component costs declined in the aggregate, but we expect the overall component cost environment to shift to inflationary for the remainder of Fiscal 2022.  Component cost trends are dependent on the strength or weakness of actual end-user demand and supply dynamics, which will continue to evolve and ultimately impact the translation of the cost environment to pricing and operating results.

[0001571996-21-000026:mdna:52]
Dell Technologies maintains limited-source supplier relationships for certain components, because the relationships are advantageous in the areas of performance, quality, support, delivery, capacity, and price considerations.  In recent periods, we have been impacted by industry-wide component supply constraints in certain product offerings, due to increasing demand as a result of the shift to the “do-anything-from-anywhere” environment coupled with overall macroeconomic recovery.  Delays in the supply of limited-source components across multiple industry segments are affecting the timing of shipments of certain products in desired quantities or configurations.  We expect to continue navigating supply chain constraints through the remainder of Fiscal 2022.  Additionally, we have experienced increased freight costs for expedited shipments of components

[0001571996-21-000026:mdna:53]
and rate increases in the freight network as capacity remains constrained, which we expect will continue through the remainder of Fiscal 2022.

[0001571996-21-000026:mdna:54]
ISG — We expect that ISG will continue to be impacted by the changing nature of the IT infrastructure market and competitive environment.  During the first quarter of Fiscal 2022,  ISG benefited from improvements in the macroeconomic environment which are forecasted to continue through the remaining nine months of Fiscal 2022.  The cost environment will continue to fluctuate depending on supplier capacity and demand for certain components and, for the remainder of Fiscal 2022, we expect overall component costs to shift to inflationary, specifically for servers.  With our scale and strong solutions portfolio, we believe we are well-positioned to respond to ongoing competitive dynamics.  Within servers and networking, we will continue to be selective in determining whether to pursue certain large hyperscale and other server transactions as we drive for balanced growth and profitability.  We continue to focus on customer base expansion and lifetime value of customer relationships.

[0001571996-21-000026:mdna:55]
Cloud-native applications are expected to continue as a primary growth driver in the infrastructure market.  We believe the complementary cloud solutions across our business position us to meet these demands for our customers.  The unprecedented data growth throughout all industries is generating continued demand for our storage solutions and services.  We benefit by offering solutions that address the emerging trends of enterprises deploying software-defined storage, hyper-converged infrastructure, and modular solutions based on server-centric architectures.  These trends are changing the way customers are consuming our traditional storage offerings.  We continue to expand our offerings in external storage arrays, which incorporate flexible, cloud-based functionality.

[0001571996-21-000026:mdna:56]
Through our research and development efforts, we are developing new solutions in this rapidly changing industry that we believe will enable us to continue to provide superior solutions to our customers.  Our customer base includes a growing number of service providers, such as cloud service providers, software-as-a-service companies, consumer webtech providers, and telecommunications companies. These service providers turn to Dell Technologies for our advanced solutions that enable efficient service delivery at cloud scale. Through our collaborative, customer-focused approach to innovation, we strive to deliver new and relevant solutions and software to the market quickly and efficiently.

[0001571996-21-000026:mdna:57]
CSG — Our CSG offerings are an important element of our strategy, generating strong cash flow and opportunities for cross-selling of complementary solutions.  During the first quarter of Fiscal 2022, CSG net revenue continued to be strong across product lines, driven by ongoing high demand for remote work and learning solutions, along with gaming systems.

[0001571996-21-000026:mdna:58]
While we expect that the CSG demand environment will continue to be subject to seasonal trends, we anticipate continued strong CSG demand through the remaining nine months of Fiscal 2022, in line with industry demand forecasts.  The cost environment will continue to fluctuate depending on supplier capacity and demand for certain components and, for the remainder of Fiscal 2022, we expect overall component costs to shift to inflationary.  The cost environment coupled with competitive dynamics continue to be a factor in our CSG business and will impact pricing and operating results as we seek to balance profitability and growth.  We remain committed to our long-term strategy for CSG and will continue to make investments to innovate across the portfolio, while benefiting from consolidation trends that are occurring in the markets in which we compete.

[0001571996-21-000026:mdna:59]
Recurring Revenue and Consumption Models — Our customers are interested in new and innovative models that address how they consume our solutions.  We offer options including as-a-service, utility, leases, and immediate pay models, all designed to match customers’ consumption and financing preferences.  Our multiyear agreements typically result in recurring revenue streams over the term of the arrangement.  In May of Fiscal 2022, we announced new offers within our Apex portfolio to evolve and expand our IT as-a-Service and cloud offerings.  We expect that our flexible consumption models and as-a-service offerings through Apex will further strengthen our customer relationships and provide a foundation for growth in recurring revenue.

[0001571996-21-000026:mdna:60]
Macroeconomic Risks and Uncertainties — The impacts of trade protection measures, including increases in tariffs and trade barriers, and changes in government policies and international trade arrangements may affect our ability to conduct business in some non-U.S. markets.  We monitor and seek to mitigate these risks with adjustments to our manufacturing, supply chain, and distribution networks.

[0001571996-21-000026:mdna:61]
We manage our business on a U.S. dollar basis.  However, we have a large global presence, generating approximately half of our revenue by sales to customers outside of the United States during both the first three months of Fiscal 2022 and Fiscal 2021.  As a result, our revenue can be impacted by fluctuations in foreign currency exchange rates.  We utilize a comprehensive

[0001571996-21-000026:mdna:62]
hedging strategy intended to mitigate the impact of foreign currency volatility over time, and we adjust pricing when possible to further minimize foreign currency impacts.

[0001571996-21-000026:mdna:63]
[same as prior period, unchanged from 0001571996-20-000051:mdna:60]

[0001571996-21-000026:mdna:64]
Our key performance metrics are net revenue, operating income, adjusted EBITDA, and cash flows from operations, which are discussed elsewhere in this management’s discussion and analysis.

[0001571996-21-000026:mdna:65]
62

[0001571996-21-000026:mdna:66]
[same as prior period, unchanged from 0001571996-20-000051:mdna:67]

[0001571996-21-000026:mdna:67]
[same as prior period, unchanged from 0001571996-20-000051:mdna:68]

[0001571996-21-000026:mdna:68]
[same as prior period, unchanged from 0001571996-20-000051:mdna:69]

[0001571996-21-000026:mdna:69]
Non-GAAP product net revenue, non-GAAP services net revenue, non-GAAP net revenue, non-GAAP product gross margin, non-GAAP services gross margin, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, and non-GAAP net income, as defined by us, exclude amortization of intangible assets, the impact of purchase accounting, transaction-related expenses, stock-based compensation expense, other corporate expenses and, for non-GAAP net income, fair value adjustments on equity investments and an aggregate adjustment for income taxes.  As the excluded items have a material impact on our financial results, our management compensates for this limitation by relying primarily on our GAAP results and using non-GAAP financial measures supplementally or for projections when comparable GAAP financial measures are not available.  The non-GAAP financial measures are not meant to be considered as indicators of performance in isolation from or as a substitute for net revenue, gross margin, operating expenses, operating income, or net income prepared in accordance with GAAP, and should be read only in conjunction with financial information presented on a GAAP basis.

[0001571996-21-000026:mdna:70]
[same as prior period, unchanged from 0001571996-20-000051:mdna:71]

[0001571996-21-000026:mdna:71]
[same as prior period, unchanged from 0001571996-20-000051:mdna:73]

[0001571996-21-000026:mdna:72]
•Amortization of Intangible Assets — Amortization of intangible assets primarily consists of amortization of customer relationships, developed technology, and trade names.  In connection with our acquisition by merger of EMC on September 7, 2016, referred to as the EMC merger transaction, and the acquisition of Dell Inc. by Dell Technologies Inc. on October 29, 2013, referred to as the going-private transaction, all of the tangible and intangible assets and liabilities of EMC and Dell, respectively, were accounted for and recognized at fair value on the transaction dates.  Accordingly, for the periods presented, amortization of intangible assets primarily represents amortization associated with intangible assets recognized in connection with the EMC merger transaction and the going-private transaction.  Amortization charges for purchased intangible assets are significantly impacted by the timing and magnitude of our acquisitions, and these charges may vary in amount from period to period.  We exclude these charges for purposes of calculating the non-GAAP financial measures presented below to facilitate a more meaningful evaluation of our current operating performance and comparisons to our past operating performance.

[0001571996-21-000026:mdna:73]
•Impact of Purchase Accounting — The impact of purchase accounting includes purchase accounting adjustments related to the EMC merger transaction and, to a lesser extent, the going-private transaction, recorded under the acquisition method of accounting in accordance with the accounting guidance for business combinations.  This guidance prescribes that the purchase price be allocated to assets acquired and liabilities assumed based on the estimated fair value of such assets and liabilities on the date of the transaction.  Accordingly, all of the assets and liabilities acquired in the EMC merger transaction and the going-private transaction were accounted for and recognized at fair value as of the respective

[0001571996-21-000026:mdna:74]
63

[0001571996-21-000026:mdna:75]
transaction dates, and the fair value adjustments are being amortized over the estimated useful lives in the periods following the transactions.  The fair value adjustments primarily relate to deferred revenue and property, plant, and equipment.  Although the purchase accounting adjustments and related amortization of those adjustments are reflected in our GAAP results, we evaluate the operating results of the underlying businesses on a non-GAAP basis, after removing such adjustments.  We believe that excluding the impact of purchase accounting provides results that are useful in understanding our current operating performance and provides more meaningful comparisons to our past operating performance.

[0001571996-21-000026:mdna:76]
•Transaction-related Expenses — Transaction-related expenses typically consist of acquisition, integration, and divestiture related costs and are expensed as incurred.  These expenses primarily represent costs for legal, banking, consulting, and advisory services.  From time to time, this category also may include transaction-related gains on divestitures of businesses or asset sales.  During the first quarter of Fiscal 2021, we recognized a gain of $120 million on the sale of certain intellectual property assets.  We exclude these items for purposes of calculating the non-GAAP financial measures presented below to facilitate a more meaningful evaluation of our current operating performance and comparisons to our past operating performance.

[0001571996-21-000026:mdna:77]
[same as prior period, unchanged from 0001571996-20-000051:mdna:77]

[0001571996-21-000026:mdna:78]
•Other Corporate Expenses — Other corporate expenses consist primarily of impairment charges, severance, facility action, and other costs.  Severance costs are primarily related to severance and benefits for employees terminated pursuant to cost savings initiatives.  We continue to optimize our facilities footprint and may incur additional costs as we seek opportunities for operational efficiencies.  Other corporate expenses vary from period to period and are significantly impacted by the timing and nature of these events.  Therefore, although we may incur these types of expenses in the future, we believe that eliminating these charges for purposes of calculating the non-GAAP financial measures presented below facilitates a more meaningful evaluation of our current operating performance and comparisons to our past operating performance.

[0001571996-21-000026:mdna:79]
•Fair Value Adjustments on Equity Investments — Fair value adjustments on equity investments primarily consists of the gain (loss) on strategic investments, which includes the recurring fair value adjustments of investments in publicly-traded companies, as well as those in privately-held companies, which are adjusted for observable price changes and, to a lesser extent, any potential impairments.  Given the volatility in the ongoing adjustments to the valuation of these strategic investments, we believe that excluding these gains and losses for purposes of calculating non-GAAP net income presented below facilitates a more meaningful evaluation of our current operating performance and comparisons to our past operating performance.

[0001571996-21-000026:mdna:80]
•Aggregate Adjustment for Income Taxes — The aggregate adjustment for income taxes is the estimated combined income tax effect for the adjustments described above, as well as an adjustment for discrete tax items.  Due to the variability in recognition of discrete tax items from period to period, we believe that excluding these benefits or charges for purposes of calculating non-GAAP net income facilitates a more meaningful evaluation of our current operating performance and comparisons to our past operating performance.  The tax effects for the adjustments described above are determined based on the tax jurisdictions in which the items were incurred.  See Note 10 of the Notes to the Condensed Consolidated Financial Statements included in this report for additional information about our income taxes.

[0001571996-21-000026:mdna:81]
[same as prior period, unchanged from 0001571996-20-000051:mdna:83]

[0001571996-21-000026:mdna:82]
|  | Three Months Ended |  |  |
|  | April 30, 2021 |  | % Change |  | May 1, 2020 |  |  |  |  |  |  |
|  | (in millions, except percentages) |
| Product net revenue | $ | 18,034 |  |  | 12 | % |  | $ | 16,038 |  |  |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | — |  |  |  |  | 4 |  |  |  |  |  |  |  |
| Non-GAAP product net revenue | $ | 18,034 |  |  | 12 | % |  | $ | 16,042 |  |  |  |  |  |  |  |
| Services net revenue | $ | 6,453 |  |  | 10 | % |  | $ | 5,859 |  |  |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 12 |  |  |  |  | 44 |  |  |  |  |  |  |  |
| Non-GAAP services net revenue | $ | 6,465 |  |  | 10 | % |  | $ | 5,903 |  |  |  |  |  |  |  |
| Net revenue | $ | 24,487 |  |  | 12 | % |  | $ | 21,897 |  |  |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 12 |  |  |  |  | 48 |  |  |  |  |  |  |  |
| Non-GAAP net revenue | $ | 24,499 |  |  | 12 | % |  | $ | 21,945 |  |  |  |  |  |  |  |
| Product gross margin | $ | 3,820 |  |  | 18 | % |  | $ | 3,234 |  |  |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 276 |  |  |  |  | 372 |  |  |  |  |  |  |  |
| Impact of purchase accounting | 1 |  |  |  |  | 7 |  |  |  |  |  |  |  |
| Stock-based compensation expense | 9 |  |  |  |  | 4 |  |  |  |  |  |  |  |
| Other corporate expenses | 3 |  |  |  |  | 2 |  |  |  |  |  |  |  |
| Non-GAAP product gross margin | $ | 4,109 |  |  | 14 | % |  | $ | 3,619 |  |  |  |  |  |  |  |
| Services gross margin | $ | 3,838 |  |  | 6 | % |  | $ | 3,619 |  |  |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 12 |  |  |  |  | 44 |  |  |  |  |  |  |  |
| Stock-based compensation expense | 49 |  |  |  |  | 36 |  |  |  |  |  |  |  |
| Other corporate expenses | 10 |  |  |  |  | 7 |  |  |  |  |  |  |  |
| Non-GAAP services gross margin | $ | 3,909 |  |  | 5 | % |  | $ | 3,706 |  |  |  |  |  |  |  |

[0001571996-21-000026:mdna:83]
65

[0001571996-21-000026:mdna:84]
|  | Three Months Ended |  |  |
|  | April 30, 2021 |  | % Change |  | May 1, 2020 |  |  |  |  |  |  |
|  | (in millions, except percentages) |
| Gross margin | $ | 7,658 |  |  | 12 | % |  | $ | 6,853 |  |  |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 276 |  |  |  |  | 372 |  |  |  |  |  |  |  |
| Impact of purchase accounting | 13 |  |  |  |  | 51 |  |  |  |  |  |  |  |
| Stock-based compensation expense | 58 |  |  |  |  | 40 |  |  |  |  |  |  |  |
| Other corporate expenses | 13 |  |  |  |  | 9 |  |  |  |  |  |  |  |
| Non-GAAP gross margin | $ | 8,018 |  |  | 9 | % |  | $ | 7,325 |  |  |  |  |  |  |  |
| Operating expenses | $ | 6,283 |  |  | 2 | % |  | $ | 6,151 |  |  |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | (433) |  |  |  |  | (483) |  |  |  |  |  |  |  |
| Impact of purchase accounting | (12) |  |  |  |  | (12) |  |  |  |  |  |  |  |
| Transaction-related expenses | (51) |  |  |  |  | (76) |  |  |  |  |  |  |  |
| Stock-based compensation expense | (377) |  |  |  |  | (330) |  |  |  |  |  |  |  |
| Other corporate expenses | (106) |  |  |  |  | (86) |  |  |  |  |  |  |  |
| Non-GAAP operating expenses | $ | 5,304 |  |  | 3 | % |  | $ | 5,164 |  |  |  |  |  |  |  |
| Operating income | $ | 1,375 |  |  | 96 | % |  | $ | 702 |  |  |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 709 |  |  |  |  | 855 |  |  |  |  |  |  |  |
| Impact of purchase accounting | 25 |  |  |  |  | 63 |  |  |  |  |  |  |  |
| Transaction-related expenses | 51 |  |  |  |  | 76 |  |  |  |  |  |  |  |
| Stock-based compensation expense | 435 |  |  |  |  | 370 |  |  |  |  |  |  |  |
| Other corporate expenses | 119 |  |  |  |  | 95 |  |  |  |  |  |  |  |
| Non-GAAP operating income | $ | 2,714 |  |  | 26 | % |  | $ | 2,161 |  |  |  |  |  |  |  |
| Net income | $ | 938 |  |  | 415 | % |  | $ | 182 |  |  |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 709 |  |  |  |  | 855 |  |  |  |  |  |  |  |
| Impact of purchase accounting | 25 |  |  |  |  | 63 |  |  |  |  |  |  |  |
| Transaction-related expenses | 51 |  |  |  |  | (44) |  |  |  |  |  |  |  |
| Stock-based compensation expense | 435 |  |  |  |  | 370 |  |  |  |  |  |  |  |
| Other corporate expenses | 119 |  |  |  |  | 95 |  |  |  |  |  |  |  |
| Fair value adjustments on equity investments | (157) |  |  |  |  | (94) |  |  |  |  |  |  |  |
| Aggregate adjustment for income taxes | (301) |  |  |  |  | (284) |  |  |  |  |  |  |  |
| Non-GAAP net income | $ | 1,819 |  |  | 59 | % |  | $ | 1,143 |  |  |  |  |  |  |  |

[0001571996-21-000026:mdna:85]
66

[0001571996-21-000026:mdna:86]
In addition to the above measures, we also use EBITDA and adjusted EBITDA to provide additional information for evaluation of our operating performance.  Adjusted EBITDA excludes purchase accounting adjustments, stock-based compensation expense, transaction-related expenses, and other corporate expenses.  We believe that, due to the non-operational nature of the purchase accounting entries, it is appropriate to exclude these adjustments.

[0001571996-21-000026:mdna:87]
[same as prior period, unchanged from 0001571996-20-000051:mdna:88]

[0001571996-21-000026:mdna:88]
[same as prior period, unchanged from 0001571996-20-000051:mdna:89]

[0001571996-21-000026:mdna:89]
|  | Three Months Ended |  |  |
|  | April 30, 2021 |  | % Change |  | May 1, 2020 |  |  |  |  |  |  |
|  | (in millions, except percentages) |
| Net income | $ | 938 |  |  | 415 | % |  | $ | 182 |  |  |  |  |  |  |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Interest and other, net (a) | 388 |  |  |  |  | 566 |  |  |  |  |  |  |  |
| Income tax expense (benefit) (b) | 49 |  |  |  |  | (46) |  |  |  |  |  |  |  |
| Depreciation and amortization | 1,239 |  |  |  |  | 1,316 |  |  |  |  |  |  |  |
| EBITDA | $ | 2,614 |  |  | 30 | % |  | $ | 2,018 |  |  |  |  |  |  |  |
| EBITDA | $ | 2,614 |  |  | 30 | % |  | $ | 2,018 |  |  |  |  |  |  |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense | 435 |  |  |  |  | 370 |  |  |  |  |  |  |  |
| Impact of purchase accounting (c) | 16 |  |  |  |  | 48 |  |  |  |  |  |  |  |
| Transaction-related expenses (d) | 51 |  |  |  |  | 76 |  |  |  |  |  |  |  |
| Other corporate expenses (e) | 119 |  |  |  |  | 95 |  |  |  |  |  |  |  |
| Adjusted EBITDA | $ | 3,235 |  |  | 24 | % |  | $ | 2,607 |  |  |  |  |  |  |  |

[0001571996-21-000026:mdna:90]
[same as prior period, unchanged from 0001571996-20-000051:mdna:91]

[0001571996-21-000026:mdna:91]
[same as prior period, unchanged from 0001571996-20-000051:mdna:92]

[0001571996-21-000026:mdna:92]
(b)See Note 10 of the Notes to the Condensed Consolidated Financial Statements included in this report for additional information on discrete tax items recorded during the first quarter of Fiscal 2022 and Fiscal 2021.

[0001571996-21-000026:mdna:93]
(c)This amount includes the non-cash purchase accounting adjustments related to the EMC merger transaction and the going-private transaction, excluding depreciation.

[0001571996-21-000026:mdna:94]
[same as prior period, unchanged from 0001571996-20-000051:mdna:95]

[0001571996-21-000026:mdna:95]
(e)Other corporate expenses include impairment charges, severance, facility action, and other costs.

[0001571996-21-000026:mdna:96]
[same as prior period, unchanged from 0001571996-20-000051:mdna:97]

[0001571996-21-000026:mdna:97]
[same as prior period, unchanged from 0001571996-20-000051:mdna:98]

[0001571996-21-000026:mdna:98]
[same as prior period, unchanged from 0001571996-20-000051:mdna:99]

[0001571996-21-000026:mdna:99]
|  | Three Months Ended |  |  |
|  | April 30, 2021 |  |  |  | May 1, 2020 |  |  |  |  |  |  |
|  | Dollars |  | % ofNet Revenue |  | %Change |  | Dollars |  | % ofNet Revenue |  |  |  |  |  |  |  |  |  |  |
|  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products | $ | 18,034 |  |  | 73.6 | % |  | 12 | % |  | $ | 16,038 |  |  | 73.2 | % |  |  |  |  |  |  |  |  |  |  |
| Services | 6,453 |  |  | 26.4 | % |  | 10 | % |  | 5,859 |  |  | 26.8 | % |  |  |  |  |  |  |  |  |  |  |
| Total net revenue | $ | 24,487 |  |  | 100.0 | % |  | 12 | % |  | $ | 21,897 |  |  | 100.0 | % |  |  |  |  |  |  |  |  |  |  |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products (a) | $ | 3,820 |  |  | 21.2 | % |  | 18 | % |  | $ | 3,234 |  |  | 20.2 | % |  |  |  |  |  |  |  |  |  |  |
| Services (b) | 3,838 |  |  | 59.5 | % |  | 6 | % |  | 3,619 |  |  | 61.8 | % |  |  |  |  |  |  |  |  |  |  |
| Total gross margin | $ | 7,658 |  |  | 31.3 | % |  | 12 | % |  | $ | 6,853 |  |  | 31.3 | % |  |  |  |  |  |  |  |  |  |  |
| Operating expenses | $ | 6,283 |  |  | 25.7 | % |  | 2 | % |  | $ | 6,151 |  |  | 28.1 | % |  |  |  |  |  |  |  |  |  |  |
| Operating income | $ | 1,375 |  |  | 5.6 | % |  | 96 | % |  | $ | 702 |  |  | 3.2 | % |  |  |  |  |  |  |  |  |  |  |
| Net income | $ | 938 |  |  | 3.8 | % |  | 415 | % |  | $ | 182 |  |  | 0.8 | % |  |  |  |  |  |  |  |  |  |  |
| Net income attributable to Dell Technologies Inc. | $ | 887 |  |  | 3.6 | % |  | 520 | % |  | $ | 143 |  |  | 0.7 | % |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP Financial Information |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | Three Months Ended |  |  |  |  |  |  |  |  |  |  |
|  | April 30, 2021 |  |  |  | May 1, 2020 |  |  |  |  |  |  |  |  |  |  |
|  | Dollars |  | % of Non-GAAPNet Revenue |  | %Change |  | Dollars |  | % of Non-GAAPNet Revenue |  |  |  |  |  |  |  |  |  |  |
|  | (in millions, except percentages) |
| Non-GAAP net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products | $ | 18,034 |  |  | 73.6 | % |  | 12 | % |  | $ | 16,042 |  |  | 73.1 | % |  |  |  |  |  |  |  |  |  |  |
| Services | 6,465 |  |  | 26.4 | % |  | 10 | % |  | 5,903 |  |  | 26.9 | % |  |  |  |  |  |  |  |  |  |  |
| Total non-GAAP net revenue | $ | 24,499 |  |  | 100.0 | % |  | 12 | % |  | $ | 21,945 |  |  | 100.0 | % |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products (a) | $ | 4,109 |  |  | 22.8 | % |  | 14 | % |  | $ | 3,619 |  |  | 22.6 | % |  |  |  |  |  |  |  |  |  |  |
| Services (b) | 3,909 |  |  | 60.5 | % |  | 5 | % |  | 3,706 |  |  | 62.8 | % |  |  |  |  |  |  |  |  |  |  |
| Total non-GAAP gross margin | $ | 8,018 |  |  | 32.7 | % |  | 9 | % |  | $ | 7,325 |  |  | 33.4 | % |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP operating expenses | $ | 5,304 |  |  | 21.6 | % |  | 3 | % |  | $ | 5,164 |  |  | 23.6 | % |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP operating income | $ | 2,714 |  |  | 11.1 | % |  | 26 | % |  | $ | 2,161 |  |  | 9.8 | % |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP net income | $ | 1,819 |  |  | 7.4 | % |  | 59 | % |  | $ | 1,143 |  |  | 5.2 | % |  |  |  |  |  |  |  |  |  |  |
| EBITDA | $ | 2,614 |  |  | 10.7 | % |  | 30 | % |  | $ | 2,018 |  |  | 9.2 | % |  |  |  |  |  |  |  |  |  |  |
| Adjusted EBITDA | $ | 3,235 |  |  | 13.2 | % |  | 24 | % |  | $ | 2,607 |  |  | 11.9 | % |  |  |  |  |  |  |  |  |  |  |

[0001571996-21-000026:mdna:100]
[same as prior period, unchanged from 0001571996-20-000051:mdna:101]

[0001571996-21-000026:mdna:101]
(a)    Product gross margin percentages represent product gross margin as a percentage of product net revenue, and non-GAAP product gross margin percentages represent non-GAAP product gross margin as a percentage of non-GAAP product net revenue.

[0001571996-21-000026:mdna:102]
(b)    Services gross margin percentages represent services gross margin as a percentage of services net revenue, and non-GAAP services gross margin percentages represent non-GAAP services gross margin as a percentage of non-GAAP services net revenue.

[0001571996-21-000026:mdna:103]
[same as prior period, unchanged from 0001571996-20-000051:mdna:106]

[0001571996-21-000026:mdna:104]
[same as prior period, unchanged from 0001571996-20-000051:mdna:107]

[0001571996-21-000026:mdna:105]
During the first quarter of Fiscal 2022, our net revenue and our non-GAAP net revenue both increased 12% due to an increase in net revenue for CSG, and to a lesser extent, increases in net revenue for ISG and VMware, driven by the "do-anything-from-anywhere" economy where technology enables connectivity and outcomes for everyone.  CSG net revenue benefited from ongoing high demand for remote work and learning solutions, along with gaming systems, and ISG net revenue benefited from improvements in the macroeconomic environment during the first quarter of Fiscal 2022.  VMware net revenue increased due to growth in sales of subscriptions and software-as-a-service (“SaaS”) offerings and software maintenance.

[0001571996-21-000026:mdna:106]
During the first quarter of Fiscal 2022, our operating income and non-GAAP operating income increased 96% and 26%, respectively, primarily due to an increase in operating income for CSG, and to a lesser extent, increases in operating income for ISG and VMware.  Operating income during the first quarter of Fiscal 2022 also benefited from a decrease in amortization of intangible assets.

[0001571996-21-000026:mdna:107]
Operating cash flows during the first quarter of the fiscal year are typically lower due to seasonal sales trends affecting parts of our business as well as the timing of annual personnel-related payments.  Cash provided by operating activities was $2.2 billion for the first quarter of Fiscal 2022 compared to cash used in operating activities of $0.8 billion for the first quarter of Fiscal 2021.  The increase in operating cash flows was driven by strong profitability coupled with favorable working capital dynamics during the first quarter of Fiscal 2022, compared to unfavorable working capital impacts related to the COVID-19 pandemic during the first quarter of Fiscal 2021.  See “Market Conditions, Liquidity, and Capital Commitments” for further information on our cash flow metrics.

[0001571996-21-000026:mdna:108]
We continue to see opportunities to create value and grow in Fiscal 2022 in response to resilient demand for our IT solutions driven by a technology-enabled world.  We have demonstrated our ability to adjust as needed to changing market conditions with complementary solutions across all segments of our business, an agile workforce, and the strength of our global supply chain.  As we continue to innovate and modernize our core offerings, we believe Dell Technologies is well-positioned for long-term profitable growth.

[0001571996-21-000026:mdna:109]
[same as prior period, unchanged from 0001571996-20-000051:mdna:113]

[0001571996-21-000026:mdna:110]
During the first quarter of Fiscal 2022, our net revenue and non-GAAP net revenue both increased 12%.  The increases in net revenue and non-GAAP net revenue during the first quarter of Fiscal 2022 were due to an increase in net revenue for CSG, and to a lesser extent, increases in net revenue for ISG and VMware.  See “Business Unit Results” for further information.

[0001571996-21-000026:mdna:111]
•Product Net Revenue — Product net revenue includes revenue from the sale of hardware products and software licenses.  During the first quarter of Fiscal 2022, product net revenue and non-GAAP product net revenue both increased 12% due to an increase in product net revenue for CSG and, to a lesser extent, an increase in product net revenue for ISG.

[0001571996-21-000026:mdna:112]
•Services Net Revenue — Services net revenue includes revenue from our services offerings and support services related to hardware products and software licenses.  During the first quarter of Fiscal 2022, services net revenue and non-GAAP services net revenue both increased 10%.  These increases were primarily attributable to increases in services net revenue for CSG support and maintenance as well as VMware SaaS and software maintenance services.  A substantial portion of services net revenue is derived from offerings that have been deferred over a period of time, and, as a result, reported services net revenue growth rates will be different than reported product net revenue growth rates.

[0001571996-21-000026:mdna:113]
From a geographical perspective, net revenue generated by sales to customers in all regions increased during the first quarter of Fiscal 2022 driven by strong CSG performance.

[0001571996-21-000026:mdna:114]
[same as prior period, unchanged from 0001571996-20-000051:mdna:66]

[0001571996-21-000026:mdna:115]
[same as prior period, unchanged from 0001571996-20-000051:mdna:118]

[0001571996-21-000026:mdna:116]
During the first quarter of Fiscal 2022, our gross margin increased 12% to $7.7 billion. Excluding the impact of amortization of intangibles, purchase accounting adjustments, transaction-related expenses, stock-based compensation expense, and other corporate expenses, our non-GAAP gross margin increased 9% to $8.0 billion.  Both gross margin and non-GAAP gross margin benefited from an increase in gross margin for CSG and, to a lesser extent, an increase in gross margin for VMware.  These benefits were partially offset by the impact of the divestiture of RSA Security during the third quarter of Fiscal 2021, which resulted in a decrease in gross margin for other businesses during the first quarter of Fiscal 2022 compared to the first quarter of Fiscal 2021.

[0001571996-21-000026:mdna:117]
During the first quarter of Fiscal 2022, our gross margin percentage remained flat at 31.3% due to favorable impacts of an increase in gross margin percentage for CSG and a decrease in amortization of intangible assets.  These favorable impacts were offset by a shift in overall gross margin mix to CSG and a decrease in gross margin percentage for ISG.  Non-GAAP gross margin percentage decreased 70 basis points to 32.7% during the first quarter of Fiscal 2022 driven by the same CSG and ISG dynamics discussed above.

[0001571996-21-000026:mdna:118]
•Products — During the first quarter of Fiscal 2022, product gross margin increased 18% to $3.8 billion and non-GAAP product gross margin increased 14% to $4.1 billion.  The increases in product gross margin and non-GAAP product gross margin were primarily driven by the favorable impact of an increase in CSG product gross margin.

[0001571996-21-000026:mdna:119]
During the first quarter of Fiscal 2022, product gross margin percentage increased 100 basis points to 21.2% and non-GAAP product gross margin percentage increased 20 basis points to 22.8% The increases in product gross margin percentage and non-GAAP product gross margin percentage were due to favorable impacts of an increase in product gross margin percentage for CSG and a decrease in amortization of intangible assets.  These favorable impacts were partially offset by a shift in overall product gross margin mix to CSG and a decrease in product gross margin percentage for ISG.

[0001571996-21-000026:mdna:120]
•Services — During the first quarter of Fiscal 2022, services gross margin increased 6% to $3.8 billion primarily due to growth in VMware SaaS and software maintenance services as well as growth in CSG support and maintenance.  Excluding purchase accounting adjustments, transaction-related expenses, stock-based compensation expense, and other corporate expenses, non-GAAP services gross margin increased 5% to $3.9 billion during the first quarter of Fiscal 2022 as a result of the same CSG and VMware growth drivers discussed above.

[0001571996-21-000026:mdna:121]
During the first quarter of Fiscal 2022, services gross margin percentage decreased 230 basis points to 59.5% and non-GAAP services gross margin percentage decreased 230 basis points to 60.5%.  These decreases were primarily due to a decrease in services gross margin percentages across all reportable segments driven by an increase in employee-related costs and, for ISG, a shift in services mix.

[0001571996-21-000026:mdna:122]
[same as prior period, unchanged from 0001571996-20-000051:mdna:130]

[0001571996-21-000026:mdna:123]
[same as prior period, unchanged from 0001571996-20-000051:mdna:131]

[0001571996-21-000026:mdna:124]
The terms and conditions of our vendor rebate programs are largely based on product volumes and are generally negotiated either at the beginning of the annual or quarterly period, depending on the program.  The timing and amount of vendor rebates and other discounts we receive under the programs may vary from period to period, reflecting changes in the competitive environment.  We monitor our component costs and seek to address the effects of any changes to terms that might arise under our vendor rebate programs.  Our gross margins for the first quarter of Fiscal 2022 and Fiscal 2021 were not materially affected by any changes to the terms of our vendor rebate programs, as the amounts we received under these programs were generally stable relative to our total net cost.  We are not aware of any significant changes to vendor pricing or rebate programs that may impact our results in the near term.

[0001571996-21-000026:mdna:125]
[same as prior period, unchanged from 0001571996-20-000051:mdna:134]

[0001571996-21-000026:mdna:126]
[same as prior period, unchanged from 0001571996-20-000051:mdna:135]

[0001571996-21-000026:mdna:127]
|  | Three Months Ended |  |  |
|  | April 30, 2021 |  |  |  | May 1, 2020 |  |  |  |  |  |  |
|  | Dollars |  | % ofNet Revenue |  | %Change |  | Dollars |  | % ofNet Revenue |  |  |  |  |  |  |  |  |  |  |
|  | (in millions, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative | $ | 4,960 |  |  | 20.3 | % |  | 2 | % |  | $ | 4,886 |  |  | 22.3 | % |  |  |  |  |  |  |  |  |  |  |
| Research and development | 1,323 |  |  | 5.4 | % |  | 5 | % |  | 1,265 |  |  | 5.8 | % |  |  |  |  |  |  |  |  |  |  |
| Total operating expenses | $ | 6,283 |  |  | 25.7 | % |  | 2 | % |  | $ | 6,151 |  |  | 28.1 | % |  |  |  |  |  |  |  |  |  |  |
|  | Three Months Ended |  |  |
|  | April 30, 2021 |  |  |  | May 1, 2020 |  |  |  |  |  |  |
|  | Dollars |  | % of Non-GAAPNet Revenue |  | %Change |  | Dollars |  | % of Non-GAAPNet Revenue |  |  |  |  |  |  |  |  |  |  |
|  | (in millions, except percentages) |
| Non-GAAP operating expenses | $ | 5,304 |  |  | 21.6 | % |  | 3 | % |  | $ | 5,164 |  |  | 23.5 | % |  |  |  |  |  |  |  |  |  |  |

[0001571996-21-000026:mdna:128]
During the first quarter of Fiscal 2022, total operating expenses increased 2% primarily due to an increase in employee-related compensation and benefits.  Our operating expenses include amortization of intangible assets, the impact of purchase accounting, transaction-related expenses, stock-based compensation expense, and other corporate expenses.  In aggregate, these items totaled $1.0 billion for both the first quarter of Fiscal 2022 and Fiscal 2021.  Excluding these costs, total non-GAAP operating expenses increased 3% for the first quarter of Fiscal 2022.  We expect that operating expenses will increase for the remaining nine months of Fiscal 2022, relative to the same period in Fiscal 2021, as a result of the reintroduction of expenses that were temporarily reduced during Fiscal 2021 in response to COVID-19 pandemic.

[0001571996-21-000026:mdna:129]
•Selling, General, and Administrative — Selling, general, and administrative (“SG&A”) expenses increased 2% during the first quarter of Fiscal 2022 primarily due to an increase in employee-related compensation and benefits, partially offset by a decrease in travel-related expenses and amortization of intangible assets.

[0001571996-21-000026:mdna:130]
•Research and Development — Research and development (“R&D”) expenses are primarily composed of personnel-related expenses incurred to develop the software that powers our solutions.   R&D expenses as a percentage of net revenue were approximately 5.4% and 5.8% for the first quarter of Fiscal 2022 and Fiscal 2021, respectively. We intend to continue to support R&D initiatives to innovate and introduce new and enhanced solutions into the market.

[0001571996-21-000026:mdna:131]
We continue to make targeted investments designed to enable growth, marketing, and R&D, while balancing these investments with our efforts to drive cost efficiencies in the business.  We also expect to continue to make investments in support of our own digital transformation to modernize and streamline our IT operations.

[0001571996-21-000026:mdna:132]
[same as prior period, unchanged from 0001571996-20-000051:mdna:141]

[0001571996-21-000026:mdna:133]
During the first quarter of Fiscal 2022, our operating income increased 96% primarily due to an increase in operating income for CSG, and to a lesser extent, increases in operating income for ISG and VMware.  Operating income during the first quarter of Fiscal 2022 also benefited from a decrease in amortization of intangible assets.  Amortization of intangible assets and stock-based compensation expense totaled $1.1 billion and $1.2 billion for the first quarter of Fiscal 2022 and Fiscal 2021, respectively.  Excluding these costs, and the impact of purchase accounting, transaction-related expenses, and other corporate expenses, our non-GAAP operating income increased 26% to $2.7 billion during the first quarter of Fiscal 2022.  The increase in non-GAAP operating income for the first quarter of Fiscal 2022 was due to an increase in operating income for CSG, and to a lesser extent, increases in operating income for ISG and VMware.

[0001571996-21-000026:mdna:134]
[same as prior period, unchanged from 0001571996-20-000051:mdna:144]

[0001571996-21-000026:mdna:135]
The following table presents information regarding interest and other, net for the periods indicated:

[0001571996-21-000026:mdna:136]
|  | Three Months Ended |  |  |
|  | April 30, 2021 |  | May 1, 2020 |  |  |  |  |
|  | (in millions) |
| Interest and other, net: |  |  |  |  |  |  |  |
| Investment income, primarily interest | $ | 11 |  |  | $ | 24 |  |  |  |  |  |
| Gain on investments, net | 157 |  |  | 94 |  |  |  |  |  |
| Interest expense | (510) |  |  | (672) |  |  |  |  |  |
| Foreign exchange | (49) |  |  | (99) |  |  |  |  |  |
| Other | 3 |  |  | 87 |  |  |  |  |  |
| Total interest and other, net | $ | (388) |  |  | $ | (566) |  |  |  |  |  |

[0001571996-21-000026:mdna:137]
During the first quarter of Fiscal 2022, the change in interest and other, net was favorable by $178 million primarily due to a decrease in interest expense resulting from debt paydowns over the period.

[0001571996-21-000026:mdna:138]
[same as prior period, unchanged from 0001571996-20-000051:mdna:148]

[0001571996-21-000026:mdna:139]
The following table presents information regarding our income and other taxes for the periods indicated:

[0001571996-21-000026:mdna:140]
|  | Three Months Ended |
|  | April 30, 2021 |  | May 1, 2020 |
|  | (in millions, except percentages) |
| Income before income taxes | $ | 987 |  |  | $ | 136 |  |
| Income tax expense (benefit) | $ | 49 |  |  | $ | (46) |  |
| Effective income tax rate | 5.0 | % |  | -33.8 | % |

[0001571996-21-000026:mdna:141]
For the first quarter of Fiscal 2022 and Fiscal 2021, our effective income tax rate was 5.0% on pre-tax income of $987 million and -33.8% on pre-tax income of $136 million, respectively.  The change in our effective income tax rate was primarily driven by higher discrete tax items on higher pre-tax income and a change in our jurisdictional mix of income.  For the first quarter of Fiscal 2022, our effective income tax rate includes discrete tax benefits of $103 million related to stock-based compensation. In comparison, for the first quarter of Fiscal 2021, our effective income tax rate includes a discrete tax benefit of $59 million from an intra-entity asset transfer of certain of Pivotal’s intellectual property to an Irish subsidiary that was completed by VMware, Inc.  The effective income tax rate for future quarters of Fiscal 2022 may be impacted by the actual mix of jurisdictions in which income is generated, as well as the impact of any discrete tax items.

[0001571996-21-000026:mdna:142]
Our effective income tax rate can fluctuate depending on the geographic distribution of our worldwide earnings, as our foreign earnings are generally taxed at lower rates than in the United States.  The differences between our effective income tax rate and the U.S. federal statutory rate of 21% principally result from the geographical distribution of income, differences between the book and tax treatment of certain items, and the discrete tax items discussed above.  In certain jurisdictions, our tax rate is significantly less than the applicable statutory rate as a result of tax holidays.  The majority of our foreign income that is subject to these tax holidays and lower tax rates is attributable to Singapore and China.  A significant portion of these income tax benefits relates to a tax holiday that will be effective until January 31, 2029.  Our other tax holidays will expire in whole or in part during Fiscal 2022 through Fiscal 2030.  Many of these tax holidays and reduced tax rates may be extended when certain conditions are met or may be terminated early if certain conditions are not met.  As of April 30, 2021, we were not aware of any matters of non-compliance related to these tax holidays.

[0001571996-21-000026:mdna:143]
For further discussion regarding tax matters, including the status of income tax audits, see Note 10 of the Notes to the Condensed Consolidated Financial Statements included in this report.

[0001571996-21-000026:mdna:144]
[same as prior period, unchanged from 0001571996-20-000051:mdna:153]

[0001571996-21-000026:mdna:145]
During the first quarter of Fiscal 2022, net income increased 415% to $938 million primarily due to an increase in operating income coupled with a decrease in interest expense.  Net income includes amortization of intangible assets, the impact of purchase accounting, transaction-related expenses, stock-based compensation expense, other corporate expenses, fair value adjustments on equity investments, and discrete tax items.  Excluding these costs and the related tax impacts, non-GAAP net income increased 59% to $1.8 billion during the first quarter of Fiscal 2022.  The increase in non-GAAP net income during the first quarter of Fiscal 2022 was primarily attributable to an increase in non-GAAP operating income coupled with a decrease in interest expense.

[0001571996-21-000026:mdna:146]
[same as prior period, unchanged from 0001571996-20-000051:mdna:157]

[0001571996-21-000026:mdna:147]
Net income attributable to non-controlling interests consists of net income or loss attributable to our non-controlling interests in VMware, Inc. and Secureworks.  During the first quarter of Fiscal 2022 and Fiscal 2021, net income attributable to non-controlling interests was $51 million and $39 million, respectively.  The increase in net income attributable to non-controlling interests during the first quarter of Fiscal 2022 was primarily due to an increase in net income attributable to our non-controlling interest in VMware, Inc.  For more information about our non-controlling interests, see Note 12 of the Notes to the Condensed Consolidated Financial Statements included in this report.

[0001571996-21-000026:mdna:148]
[same as prior period, unchanged from 0001571996-20-000051:mdna:159]

[0001571996-21-000026:mdna:149]
Net income attributable to Dell Technologies Inc. represents net income and an adjustment for non-controlling interests.  During the first quarter of Fiscal 2022 and Fiscal 2021, net income attributable to Dell Technologies Inc. was $887 million and $143 million, respectively.  The increase in net income attributable to Dell Technologies Inc. during the first quarter of Fiscal 2022 was primarily attributable to an increase in net income for the period.

[0001571996-21-000026:mdna:150]
[same as prior period, unchanged from 0001571996-20-000051:mdna:162]

[0001571996-21-000026:mdna:151]
Our reportable segments are based on the following business units: ISG, CSG, and VMware.  A description of our three business units is provided under “Introduction.”  See Note 16 of the Notes to the Condensed Consolidated Financial Statements included in this report for a reconciliation of net revenue and operating income by reportable segment to consolidated net revenue and consolidated operating income, respectively.

[0001571996-21-000026:mdna:152]
[same as prior period, unchanged from 0001571996-20-000051:mdna:164]

[0001571996-21-000026:mdna:153]
[same as prior period, unchanged from 0001571996-20-000051:mdna:165]

[0001571996-21-000026:mdna:154]
|  | Three Months Ended |  |  |
|  | April 30, 2021 |  | % Change |  | May 1, 2020 |  |  |  |  |  |  |
|  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Servers and networking | $ | 4,109 |  |  | 9 | % |  | $ | 3,758 |  |  |  |  |  |  |
| Storage | 3,802 |  |  | — | % |  | 3,811 |  |  |  |  |  |  |
| Total ISG net revenue | $ | 7,911 |  |  | 5 | % |  | $ | 7,569 |  |  |  |  |  |  |
| Operating income: |  |  |  |  |  |  |  |  |  |  |  |
| ISG operating income | $ | 788 |  |  | 8 | % |  | $ | 732 |  |  |  |  |  |  |
| % of segment net revenue | 10.0 | % |  |  |  | 9.7 | % |  |  |  |  |  |  |

[0001571996-21-000026:mdna:155]
Net Revenue — During the first quarter of Fiscal 2022, ISG net revenue increased 5%, benefiting from improvements to the  macroeconomic environment and in particular, improving server demand, compared to a weaker demand environment during the first quarter of Fiscal 2021 as a result of COVID-19, when customers shifted their investments toward remote work and business continuity solutions.

[0001571996-21-000026:mdna:156]
Net revenue from the sales of servers and networking increased 9% during the first quarter of Fiscal 2022 primarily driven by an increase in demand for our PowerEdge servers.  Net revenue from the sales of storage was flat during the first quarter of Fiscal 2022 compared to the first quarter of Fiscal 2021.  However, we are seeing improvements in the storage business,  particularly in our midrange storage offerings, driven by demand growth for our new PowerStore storage array, as well as hyperconverged infrastructure.  We continue to make enhancements to our storage solutions offerings and expect that these offerings, including PowerStore, will drive long-term improvements in the business.

[0001571996-21-000026:mdna:157]
ISG customers are interested in new and innovative models that address how they consume our solutions.  We offer options including as-a-service, utility, leases, and immediate pay models, all designed to match customers’ consumption and financing preferences.  Our multiyear agreements typically result in recurring revenue streams over the term of the arrangement.  We expect our flexible consumption models and as-a-service offerings through Apex will further strengthen our customer relationships and provide a foundation for growth in recurring revenue.

[0001571996-21-000026:mdna:158]
From a geographical perspective, net revenue attributable to ISG increased in the EMEA and APJ regions during the first quarter of Fiscal 2022.  Net revenue attributable to ISG in the Americas decreased slightly during the first quarter of Fiscal 2022.

[0001571996-21-000026:mdna:159]
Operating Income — During the first quarter of Fiscal 2022, ISG operating income as a percentage of net revenue increased 30 basis points to 10.0%.  The increase in operating income percentage during the first quarter of Fiscal 2022 was driven by a decrease in ISG operating expenses as a percentage of net revenue resulting from continued operating expense discipline.  The decrease in ISG operating expenses percentage was partially offset by a decrease in ISG gross margin percentage due to a shift in ISG gross margin mix to servers and networking, coupled with a shift within the gross margin mix of storage solutions.

[0001571996-21-000026:mdna:160]
[same as prior period, unchanged from 0001571996-20-000051:mdna:174]

[0001571996-21-000026:mdna:161]
[same as prior period, unchanged from 0001571996-20-000051:mdna:175]

[0001571996-21-000026:mdna:162]
|  | Three Months Ended |  |  |
|  | April 30, 2021 |  | % Change |  | May 1, 2020 |  |  |  |  |  |  |
|  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 9,803 |  | 14 | % |  | $ | 8,634 |  |  |  |  |  |  |
| Consumer | 3,502 |  | 42 | % |  | 2,470 |  |  |  |  |  |  |
| Total CSG net revenue | $ | 13,305 |  | 20 | % |  | $ | 11,104 |  |  |  |  |  |  |
| Operating income: |  |  |  |  |  |  |  |  |  |  |  |
| CSG operating income | $ | 1,090 |  | 84 | % |  | $ | 592 |  |  |  |  |  |  |
| % of segment net revenue | 8.2 | % |  |  |  | 5.3 | % |  |  |  |  |  |  |

[0001571996-21-000026:mdna:163]
Net Revenue — During the first quarter of Fiscal 2022, CSG net revenue increased 20% driven by ongoing strong demand for remote work and remote learning solutions, along with gaming systems.

[0001571996-21-000026:mdna:164]
Commercial revenue increased 14% during the first quarter of Fiscal 2022 primarily due to an increase in sales of commercial notebooks driven by continued strong demand for remote work and remote learning solutions, partially offset by lower demand for commercial desktops and an overall decline in commercial average selling prices, in part due to a product mix shift within commercial toward entry-level commercial notebooks.

[0001571996-21-000026:mdna:165]
Consumer revenue increased 42% during the first quarter of Fiscal 2022 due to an increase in demand across all consumer product offerings, particularly for consumer notebooks and high-end gaming systems, compared to the unique demand environment for consumer products during the first quarter of Fiscal 2021, particularly in retail, as a result of disruption introduced by the COVID-19 pandemic.   This increased demand was coupled with an increase in average selling prices of certain consumer product lines during the first quarter of Fiscal 2022.

[0001571996-21-000026:mdna:166]
From a geographical perspective, net revenue attributable to CSG increased across all regions during the first quarter of Fiscal 2022.

[0001571996-21-000026:mdna:167]
Operating Income — During the first quarter of Fiscal 2022, CSG operating income as a percentage of net revenue increased 290 basis points to 8.2% driven by an increase in both consumer and commercial gross margin percentage, which benefited from deflation in the overall component cost environment.  CSG operating income as a percentage of net revenue also benefited from a decrease in CSG operating expenses as a percentage of net revenue during the first quarter of Fiscal 2022 as a result of continued operating expense discipline.

[0001571996-21-000026:mdna:168]
[same as prior period, unchanged from 0001571996-20-000051:mdna:182]

[0001571996-21-000026:mdna:169]
The following table presents net revenue and operating income attributable to VMware for the periods indicated:

[0001571996-21-000026:mdna:170]
|  | Three Months Ended |  |  |
|  | April 30, 2021 |  | % Change |  | May 1, 2020 |  |  |  |  |  |  |
|  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| VMware net revenue | $ | 2,991 |  | 9 | % |  | $ | 2,755 |  |  |  |  |  |  |
| Operating income: |  |  |  |  |  |  |  |  |  |  |  |
| VMware operating income | $ | 841 |  | 9 | % |  | $ | 773 |  |  |  |  |  |  |
| % of segment net revenue | 28.1 | % |  |  |  | 28.1 | % |  |  |  |  |  |  |

[0001571996-21-000026:mdna:171]
Net Revenue — VMware net revenue primarily consists of revenue from the sale of software licenses under perpetual licenses and subscription and SaaS offerings, as well as related software maintenance services, support, training, consulting services, and hosted services.  VMware net revenue for the first quarter of Fiscal 2022 increased 9% primarily due to growth in sales of subscription and SaaS offerings, driven by increased demand for cloud offerings, coupled with continued benefits to software maintenance revenue from maintenance contracts sold in prior periods.

[0001571996-21-000026:mdna:172]
From a geographical perspective, approximately half of VMware net revenue during the first quarter of Fiscal 2022 was generated by sales to customers in the United States.  VMware net revenue for the first quarter of Fiscal 2022 increased in both the United States and internationally.

[0001571996-21-000026:mdna:173]
Operating Income — During the first quarter of Fiscal 2022, VMware operating income as a percentage of net revenue remained flat at 28.1% due to a decrease in VMware gross margin percentage driven by headcount growth, offset by a decrease in VMware operating expenses as a percentage of net revenue driven by lower marketing and travel-related costs.  The decrease in travel-related costs during the first quarter of Fiscal 2022 resulted from travel restrictions imposed in response to the COVID-19 pandemic.

[0001571996-21-000026:mdna:174]
[same as prior period, unchanged from 0001571996-20-000051:mdna:103]

[0001571996-21-000026:mdna:175]
[same as prior period, unchanged from 0001571996-20-000051:mdna:189]

[0001571996-21-000026:mdna:176]
[same as prior period, unchanged from 0001571996-20-000051:mdna:190]

[0001571996-21-000026:mdna:177]
We sell products and services directly to customers and through a variety of sales channels, including retail distribution.  Our accounts receivable, net, was $10.9 billion and $12.8 billion as of April 30, 2021 and January 29, 2021, respectively.  We maintain an allowance for expected credit losses to cover receivables that may be deemed uncollectible.  The allowance for expected credit losses is an estimate based on an analysis of historical loss experience, current receivables aging, and management’s assessment of current conditions and reasonable and supportable expectation of future conditions, as well as specific identifiable customer accounts that are deemed at risk.  Given this uncertainty, our allowance for expected credit losses in future periods may vary from our current estimates.  As of both April 30, 2021 and January 29, 2021, the allowance for expected credit losses was $104 million.  Based on our assessment, we believe that we are adequately reserved for expected credit losses.  We will continue to monitor the aging of our accounts receivable and take actions, where necessary, to reduce our exposure to credit losses.

[0001571996-21-000026:mdna:178]
[same as prior period, unchanged from 0001571996-20-000051:mdna:192]

[0001571996-21-000026:mdna:179]
Dell Financial Services and its affiliates (“DFS”) support Dell Technologies by offering and arranging various financing options and services for our customers globally, including through captive financing operations in North America, Europe, Australia, and New Zealand.  DFS originates, collects, and services customer receivables primarily related to the purchase of our product, software, and service solutions.  DFS further strengthens our customer relationships through its flexible consumption models, which enable us to offer our customers the option to pay over time and, in certain cases, based on utilization, to provide them with financial flexibility to meet their changing technological requirements.  New financing originations were $1.9 billion and $1.8 billion for the first quarter of Fiscal 2022 and Fiscal 2021, respectively.

[0001571996-21-000026:mdna:180]
[same as prior period, unchanged from 0001571996-20-000051:mdna:194]

[0001571996-21-000026:mdna:181]
As of April 30, 2021 and January 29, 2021, our financing receivables, net were $10.2 billion and $10.5 billion, respectively.  We maintain an allowance to cover expected financing receivable credit losses and evaluate credit loss expectations based on our total portfolio.  Our allowance for expected credit losses in future periods may vary from our current estimates.  For the first quarter of Fiscal 2022 and Fiscal 2021, the principal charge-off rate for our financing receivables portfolio was 0.5% and 1.0%, respectively.  The credit quality of our financing receivables has improved in recent years due to an overall improvement in the credit environment and as the mix of high-quality commercial accounts in our portfolio has continued to increase.  We continue to monitor broader economic indicators and their potential impact on future loss performance.  We have an extensive process to manage our exposure to customer credit risk, including active management of credit lines and our collection activities.  We also sell selected fixed-term financing receivables without recourse to unrelated third parties on a periodic basis, primarily to manage certain concentrations of customer credit exposure.  Based on our assessment of the customer financing receivables, we believe that we are adequately reserved.

[0001571996-21-000026:mdna:182]
We retain a residual interest in equipment leased under our fixed-term lease programs.  As of April 30, 2021 and January 29, 2021, the residual interest recorded as part of financing receivables was $367 million and $424 million, respectively.  The amount of the residual interest is established at the inception of the lease based upon estimates of the value of the equipment at the end of the lease term using historical studies, industry data, and future value-at-risk demand valuation methods.  We assess the carrying amount of our recorded residual values for expected losses.  Generally, expected losses as a result of residual value risk on equipment under lease are not considered to be significant primarily because of the existence of a secondary market with respect to the equipment.  The lease agreement also clearly defines applicable return conditions and remedies for non-compliance, to ensure that the leased equipment will be in good operating condition upon return.  Model changes and updates, as well as market strength and product acceptance, are monitored and adjustments are made to residual values in accordance with the significance of any such changes.  To mitigate our exposure, we work closely with customers and dealers to manage the sale of returned assets.  No material expected losses were recorded related to residual assets during the first quarter of Fiscal 2022 and Fiscal 2021.

[0001571996-21-000026:mdna:183]
As of April 30, 2021 and January 29, 2021, equipment under operating leases, net was $1.4 billion and $1.3 billion, respectively.  Based on triggering events, we assess the carrying amount of the equipment under operating leases recorded for impairment.  No material impairment losses were recorded related to such equipment during the first quarter of Fiscal 2022 and Fiscal 2021.

[0001571996-21-000026:mdna:184]
[same as prior period, unchanged from 0001571996-20-000051:mdna:198]

[0001571996-21-000026:mdna:185]
See Note 3 of the Notes to the Condensed Consolidated Financial Statements included in this report for additional information about our financing receivables and the associated allowances, and the equipment under operating leases.

[0001571996-21-000026:mdna:186]
[same as prior period, unchanged from 0001571996-20-000051:mdna:200]

[0001571996-21-000026:mdna:187]
As of April 30, 2021, we had no off-balance sheet arrangements that have or are reasonably likely to have a current or future material effect on our financial condition or results of operations.

[0001571996-21-000026:mdna:188]
[same as prior period, unchanged from 0001571996-20-000051:mdna:202]

[0001571996-21-000026:mdna:189]
[same as prior period, unchanged from 0001571996-20-000051:mdna:203]

[0001571996-21-000026:mdna:190]
[same as prior period, unchanged from 0001571996-20-000051:mdna:204]

[0001571996-21-000026:mdna:191]
[same as prior period, unchanged from 0001571996-20-000051:mdna:205]

[0001571996-21-000026:mdna:192]
We use derivative instruments to hedge certain foreign currency exposures.  We use forward contracts and purchased options designated as cash flow hedges to protect against the foreign currency exchange rate risks inherent in our forecasted transactions denominated in currencies other than the U.S. dollar.  In addition, we primarily use forward contracts and may use purchased options to hedge monetary assets and liabilities denominated in a foreign currency.  See Note 6 of the Notes to the Condensed Consolidated Financial Statements included in this report for more information about our use of derivative instruments.

[0001571996-21-000026:mdna:193]
[same as prior period, unchanged from 0001571996-20-000051:mdna:207]

[0001571996-21-000026:mdna:194]
[same as prior period, unchanged from 0001571996-20-000051:mdna:208]

[0001571996-21-000026:mdna:195]
[same as prior period, unchanged from 0001571996-20-000051:mdna:209]

[0001571996-21-000026:mdna:196]
To support our ongoing business operations, we rely on operating cash flows as our primary source of liquidity.  We monitor the efficiency of our balance sheet to ensure that we have adequate liquidity to support our business and strategic initiatives.  In addition to internally generated cash, we have access to other capital sources to finance our strategic initiatives and fund growth in our financing operations.  Our strategy is to deploy capital from any potential source, whether internally generated cash or debt, depending on the adequacy and availability of that source of capital and whether it can be accessed in a cost-effective manner.

[0001571996-21-000026:mdna:197]
[same as prior period, unchanged from 0001571996-20-000051:mdna:212]

[0001571996-21-000026:mdna:198]
|  | April 30, 2021 |  | January 29, 2021 |
|  | (in millions) |
| Cash and cash equivalents, and available borrowings: |  |  |  |
| Cash and cash equivalents (a) | $ | 14,244 |  |  | $ | 14,201 |  |
| Remaining available borrowings under revolving credit facilities (b) | 5,467 |  |  | 5,467 |  |
| Total cash, cash equivalents, and available borrowings | $ | 19,711 |  |  | $ | 19,668 |  |

[0001571996-21-000026:mdna:199]
[same as prior period, unchanged from 0001571996-20-000051:mdna:214]

[0001571996-21-000026:mdna:200]
(a)    Of the $14.2 billion of cash and cash equivalents as of April 30, 2021, $5.6 billion was held by VMware, Inc.

[0001571996-21-000026:mdna:201]
(b)    Of the $5.5 billion of remaining available borrowings under revolving credit facilities, $1.0 billion was attributable to the VMware Revolving Credit Facility.

[0001571996-21-000026:mdna:202]
Our revolving credit facilities as of April 30, 2021 consist of the Revolving Credit Facility and the VMware Revolving Credit Facility.  The Revolving Credit Facility has a maximum aggregate borrowing capacity of $4.5 billion, and available borrowings under this facility are reduced by draws on the facility and outstanding letters of credit.  As of April 30, 2021, there were no borrowings outstanding under the facility and remaining available borrowings totaled approximately $4.5 billion.  We may regularly use our available borrowings from our Revolving Credit Facility on a short-term basis for general corporate purposes.

[0001571996-21-000026:mdna:203]
The VMware Revolving Credit Facility has a maximum capacity of $1.0 billion.  As of April 30, 2021, there were no outstanding borrowings under the facility and remaining available borrowings totaled $1.0 billion.  None of the net proceeds of borrowings under the VMware Revolving Credit Facility will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.

[0001571996-21-000026:mdna:204]
See Note 5 of the Notes to the Condensed Consolidated Financial Statements included in this report for additional information about each of the foregoing revolving credit facilities.

[0001571996-21-000026:mdna:205]
We believe that our current cash and cash equivalents, together with cash that will be provided by future operations and borrowings expected to be available under our revolving credit facilities, will be sufficient over at least the next twelve months and for the foreseeable future thereafter to fund our operations, debt service requirements and maturities, capital expenditures, share repurchases, and other corporate needs.

[0001571996-21-000026:mdna:206]
[same as prior period, unchanged from 0001571996-20-000051:mdna:222]

[0001571996-21-000026:mdna:207]
[same as prior period, unchanged from 0001571996-20-000051:mdna:223]

[0001571996-21-000026:mdna:208]
|  | April 30, 2021 |  | Increase (decrease) |  | January 29, 2021 |
|  | (in millions) |
| Core debt |  |  |  |  |  |
| Senior Secured Credit Facilities and First Lien Notes | $ | 24,769 |  |  | $ | (8) |  |  | $ | 24,777 |  |
| Unsecured Notes and Debentures | 952 |  |  | (400) |  |  | 1,352 |  |
| Senior Notes | 1,625 |  |  | (1,075) |  |  | 2,700 |  |
| EMC Notes | 1,000 |  |  | — |  |  | 1,000 |  |
| DFS allocated debt | (415) |  |  | 251 |  |  | (666) |  |
| Total core debt | 27,931 |  |  | (1,232) |  |  | 29,163 |  |
| DFS related debt |  |  |  |  |  |
| DFS debt | 9,753 |  |  | 87 |  |  | 9,666 |  |
| DFS allocated debt | 415 |  |  | (251) |  |  | 666 |  |
| Total DFS related debt | 10,168 |  |  | (164) |  |  | 10,332 |  |
| Margin Loan Facility and other | 4,304 |  |  | 69 |  |  | 4,235 |  |
| Debt of public subsidiary |  |  |  |  |  |
| VMware Notes | 4,750 |  |  | — |  |  | 4,750 |  |
| Total public subsidiary debt | 4,750 |  |  | — |  |  | 4,750 |  |
| Total debt, principal amount | 47,153 |  |  | (1,327) |  |  | 48,480 |  |
| Carrying value adjustments | (470) |  |  | 26 |  |  | (496) |  |
| Total debt, carrying value | $ | 46,683 |  |  | $ | (1,301) |  |  | $ | 47,984 |  |

[0001571996-21-000026:mdna:209]
During the first quarter of Fiscal 2022, the outstanding principal amount of our debt decreased by $1.3 billion to $47.2 billion as of April 30, 2021, primarily as a result of principal repayments.

[0001571996-21-000026:mdna:210]
We define core debt as the total principal amount of our debt, less DFS related debt, our Margin Loan Facility and other debt, and public subsidiary debt.  Our core debt was $27.9 billion as of April 30, 2021.  During the first quarter of Fiscal 2022, the decrease in our core debt was driven by principal repayments, including $1,075 million principal amount of our 5.875% Senior Notes due June 2021 and $400 million principal amount of our 4.625% Unsecured Notes due April 2021.  There are no scheduled maturities of core debt for the remainder Fiscal 2022.  See Note 5 of the Notes to the Condensed Consolidated Financial Statements included in this report for more information about our debt.

[0001571996-21-000026:mdna:211]
DFS related debt primarily represents debt from our securitization and structured financing programs.  The majority of DFS debt is non-recourse to Dell Technologies and represents borrowings under securitization programs and structured financing programs, for which our risk of loss is limited to transferred lease and loan payments and associated equipment, and under which the credit holders have no recourse to Dell Technologies.

[0001571996-21-000026:mdna:212]
To fund expansion of the DFS business, we balance the use of the securitization and structured financing programs with other sources of liquidity.  We approximate the amount of our debt used to fund the DFS business by applying a 7:1 debt to equity ratio to the sum of our financing receivables balance and equipment under our DFS operating leases, net.  The debt to equity ratio used is based on the underlying credit quality of the assets.  See Note 3 of the Notes to the Condensed Consolidated Financial Statements included in this report for more information about our DFS debt.

[0001571996-21-000026:mdna:213]
As of April 30, 2021, margin loan and other debt primarily consisted of the $4.0 billion Margin Loan Facility.  Subsequent to April 30, 2021, we repaid $1 billion principal amount of the Margin Loan Facility.

[0001571996-21-000026:mdna:214]
Public subsidiary debt represents VMware, Inc. indebtedness.  VMware, Inc. and its respective subsidiaries are unrestricted subsidiaries for purposes of the core debt of Dell Technologies.  Neither Dell Technologies nor any of its subsidiaries, other than VMware, Inc., is obligated to make payment on the VMware Notes.  None of the net proceeds of the VMware Notes will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and its subsidiaries.  See Note 5 of the Notes to the Condensed Consolidated Financial Statements included in this report for more information about VMware, Inc. debt.

[0001571996-21-000026:mdna:215]
In connection with the planned VMware Spin-off announced on April 14, 2021, VMware, Inc. intends to pay a cash dividend, pro rata, to each of the holders of VMware, Inc. common stock in an aggregate amount equal to an amount to be mutually agreed by Dell Technologies and VMware, Inc. between $11.5 billion and $12.0 billion.  VMware, Inc. expects to fund the cash dividend, in part, through the incurrence of new indebtedness.  The transaction is expected to close during the fourth quarter of calendar 2021, subject to certain closing conditions.  Upon the closing of the transaction, we intend to use the net proceeds from our pro rata share of the cash dividend to repay debt, as part of our capital strategy to position Dell Technologies for investment grade ratings.  See Note 1 of the Notes to the Condensed Consolidated Financial Statements included in this report for more information about the planned VMware Spin-off.

[0001571996-21-000026:mdna:216]
We have made steady progress in paying down debt.  We believe we will continue to be able to make our debt principal and interest payments, including the short-term maturities, from existing and expected sources of cash, primarily from operating cash flows.  Cash used for debt principal and interest payments may also include short-term borrowings under our revolving credit facilities.  We will continue to focus on deleveraging.  Under our variable-rate debt, we could experience variations in our future interest expense from potential fluctuations in applicable reference rates, or from possible fluctuations in the level of DFS debt required to meet future demand for customer financing.  We or our affiliates or their related persons, at our or their sole discretion and without public announcement, may purchase, redeem, prepay, refinance, or otherwise retire any amount of our outstanding indebtedness under the terms of such indebtedness at any time and from time to time, in open market or negotiated transactions with the holders of such indebtedness or otherwise, as appropriate market conditions exist.

[0001571996-21-000026:mdna:217]
[same as prior period, unchanged from 0001571996-20-000051:mdna:237]

[0001571996-21-000026:mdna:218]
[same as prior period, unchanged from 0001571996-20-000051:mdna:238]

[0001571996-21-000026:mdna:219]
|  | Three Months Ended |
|  | April 30, 2021 |  | May 1, 2020 |
|  | (in millions) |
| Net change in cash from: |  |  |  |
| Operating activities | $ | 2,238 |  |  | $ | (796) |  |
| Investing activities | (519) |  |  | (485) |  |
| Financing activities | (1,638) |  |  | 4,264 |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash | (5) |  |  | (136) |  |
| Change in cash, cash equivalents, and restricted cash | $ | 76 |  |  | $ | 2,847 |  |

[0001571996-21-000026:mdna:220]
Operating Activities — Operating cash flows during the first quarter of the fiscal year are typically lower due to seasonal sales trends affecting parts of our business as well as the timing of annual personnel-related payments.  Cash provided by operating activities was $2.2 billion for the first quarter of Fiscal 2022 compared to cash used in operating activities of $0.8 billion for the first quarter of Fiscal 2021.  The increase in operating cash flows during the first quarter of Fiscal 2022 was driven by strong profitability coupled with favorable working capital dynamics, compared to unfavorable working capital impacts in the first quarter of Fiscal 2021 related to the COVID-19 pandemic on timing of collections and maintenance of higher inventory levels for continuity of supply.  COVID-19 impacts to working capital normalized by the end of Fiscal 2021.

[0001571996-21-000026:mdna:221]
DFS offerings are initially funded through cash on hand at the time of origination, most of which is subsequently replaced with third-party financing.  For DFS offerings which qualify as sales-type leases, the initial funding of financing receivables is reflected as an impact to cash flows from operations, and is largely subsequently offset by cash proceeds from financing.  For DFS operating leases, which have increased under the current leasing standard, the initial funding is classified as a capital expenditure and reflected as cash flows used in investing activities.  DFS new financing originations were $1.9 billion and $1.8 billion during the first quarter of Fiscal 2022 and Fiscal 2021, respectively.  As of April 30, 2021, DFS had $10.2 billion of total net financing receivables and $1.4 billion of equipment under DFS operating leases, net.

[0001571996-21-000026:mdna:222]
Investing Activities — Investing activities primarily consist of cash used to fund capital expenditures for property, plant, and equipment, which includes equipment under DFS operating leases, capitalized software development costs, strategic investments, and the maturities, sales, and purchases of investments.  During the first quarter of Fiscal 2022, cash used in investing activities was $519 million and was primarily driven by capital expenditures.  In comparison, cash used in investing activities was $485 million during the first quarter of Fiscal 2021 and was primarily driven by capital expenditures partially offset by net cash proceeds from the sale of certain intellectual property assets.

[0001571996-21-000026:mdna:223]
Financing Activities — Financing activities primarily consist of the proceeds and repayments of debt, cash used to repurchase common stock, and proceeds from the issuance of common stock.  Cash used in financing activities was $1.6 billion during the first quarter of Fiscal 2022 and primarily consisted of debt repayments and repurchases of common stock by our public subsidiaries.  In comparison, cash provided by financing activities of $4.3 billion during the first three months of Fiscal 2021 primarily consisted of cash proceeds from the issuances of multiple series of First Lien Notes and VMware Notes.

[0001571996-21-000026:mdna:224]
[same as prior period, unchanged from 0001571996-20-000051:mdna:244]

[0001571996-21-000026:mdna:225]
Capital Expenditures — During both the first quarter of Fiscal 2022 and Fiscal 2021, we spent $0.6 billion on property, plant, and equipment and capitalized software development costs.  Product demand, product mix, and the use of contract manufacturers, as well as ongoing investments in operating and IT infrastructure and software development, influence the level and prioritization of our capital expenditures.  Aggregate capital expenditures for Fiscal 2022 are currently expected to total between $2.7 billion and $2.9 billion, of which approximately $0.8 billion is expected to be expended for equipment under DFS operating leases and approximately $0.3 billion for capitalized software development costs.

[0001571996-21-000026:mdna:226]
[same as prior period, unchanged from 0001571996-20-000051:mdna:246]

[0001571996-21-000026:mdna:227]
[same as prior period, unchanged from 0001571996-20-000051:mdna:247]

[0001571996-21-000026:mdna:228]
[same as prior period, unchanged from 0001571996-20-000051:mdna:161]

[0001571996-21-000026:mdna:229]
Summarized Guarantor Financial Information

[0001571996-21-000026:mdna:230]
As discussed in Note 5 of the Notes to the Condensed Consolidated Financial Statements included in this report, Dell International L.L.C. and EMC Corporation (the “Issuers”), both of which are wholly-owned subsidiaries of Dell Technologies, completed private offerings of multiple series of senior secured notes issued on June 1, 2016, March 20, 2019, and April 9, 2020 (collectively, the “First Lien Notes”).  On May 17, 2021, subsequent to the first quarter of Fiscal 2022, the Issuers launched an exchange offer of the outstanding First Lien Notes for registered senior secured notes with substantially similar terms (the “Exchange Notes”).  The exchange offer is expected to expire at 5:00 p.m., New York City time, on June 15, 2021, unless extended by the Issuers.

[0001571996-21-000026:mdna:231]
Guarantees — The Exchange Notes are guaranteed on a joint and several unsecured basis by Dell Technologies and on a joint and several secured basis by Denali Intermediate, Inc. (“Denali Intermediate”), Dell and each of Denali Intermediate’s wholly-owned domestic subsidiaries that guarantees the Issuers’ Senior Credit Facility obligations (collectively, the “Guarantors”).  Not all of Denali Intermediate’s subsidiaries guarantee the Exchange Notes, including none of Denali Intermediate’s non-wholly-owned subsidiaries, foreign subsidiaries, receivables subsidiaries and subsidiaries designated as unrestricted subsidiaries under the  Senior Credit Facility (such non-guarantor subsidiaries, collectively, the “Non-Guarantor Subsidiaries”).  SecureWorks Corp., Boomi, Inc., Virtustream, Inc., VMware, Inc., EMC Equity Assets LLC and VMW Holdco L.L.C. (collectively, the “Unrestricted Subsidiaries”) have been designated as unrestricted subsidiaries under the Senior Credit Facility and therefore do not guarantee the Exchange Notes or the Senior Credit Facility obligations.  See Exhibit 22.1 filed with this report for a list of subsidiary guarantors and issuers of guaranteed securities.

[0001571996-21-000026:mdna:232]
The guarantees are full and unconditional, subject to certain customary release provisions.  The indentures that govern the Exchange Notes provide that guarantees by subsidiaries of Denali Intermediate may be released in the event, among other things, (i) such Guarantor is sold or sells all of its assets in compliance with the applicable provisions of the indentures; (ii) such Guarantor is released from its guaranty under the Senior Credit Facility, including the declaration of such subsidiary as “unrestricted” under the Senior Credit Facility; (iii) the merger, amalgamation or consolidation, or liquidation, of such Guarantor; or (iv) the achievement of investment grade ratings with respect to the Issuers and the Exchange Notes.  In addition, all Guarantors will be released from their guarantees if the requirements for legal defeasance or covenant defeasance or to discharge the indentures have been satisfied.

[0001571996-21-000026:mdna:233]
Basis of Preparation of the Summarized Financial Information — The tables below are summarized financial information provided in conformity with Rule 13-01 of the SEC’s Regulation S-X.  The summarized financial information of the Issuers and Guarantors (collectively, the “Obligor Group”) is presented on a combined basis, excluding intercompany balances and transactions between entities in the Obligor Group.  To the extent material, the Obligor Group’s amounts due from, amounts due to and transactions with Non-Guarantor Subsidiaries have been presented separately.  The Obligor Group’s investment balances in Non-Guarantor Subsidiaries have been excluded.

[0001571996-21-000026:mdna:234]
The following table presents summarized results of operations information for the Obligor Group for the period indicated:

[0001571996-21-000026:mdna:235]
|  | Three Months Ended |
|  | April 30, 2021 |
|  | (in millions) |
| Net revenue (a) | $ | 5,216 |  |
| Gross margin (b) | $ | 1,955 |  |
| Operating loss (c) | $ | (358) |  |
| Interest and other, net | (323) |  |
| Loss before income taxes | $ | (681) |  |
| Net loss attributable to Obligor Group | $ | (572) |  |

[0001571996-21-000026:mdna:236]
____________________

[0001571996-21-000026:mdna:237]
(a)  Includes net revenue from services provided and product sales to Non-Guarantor Subsidiaries of $632 million and $39 million, respectively.

[0001571996-21-000026:mdna:238]
(b)  Includes cost of net revenue from resale of solutions purchased from Non-Guarantor Subsidiaries of $587 million.

[0001571996-21-000026:mdna:239]
(c)  Includes operating expenses from shared services provided by Non-Guarantor Subsidiaries of $20 million.

[0001571996-21-000026:mdna:240]
[same as prior period, unchanged from 0001571996-20-000051:mdna:172]

[0001571996-21-000026:mdna:241]
The following table presents summarized balance sheet information for the Obligor Group as of the dates indicated:

[0001571996-21-000026:mdna:242]
|  | April 30, 2021 |  | January 29, 2021 |
|  | (in millions) |
| ASSETS |
| Current assets | $ | 11,272 |  |  | $ | 12,096 |  |
| Goodwill and intangible assets | 16,000 |  |  | 16,213 |  |
| Other non-current assets | 6,278 |  |  | 6,178 |  |
| Intercompany loan receivables | 3,215 |  |  | 4,714 |  |
| Total assets | $ | 36,765 |  |  | $ | 39,201 |  |
| LIABILITIES |
| Current liabilities | $ | 14,483 |  |  | $ | 15,736 |  |
| Intercompany payables | 4,694 |  |  | 5,527 |  |
| Total current liabilities | 19,177 |  |  | 21,263 |  |
| Long-term debt | 27,881 |  |  | 27,951 |  |
| Other non-current liabilities | 7,611 |  |  | 7,549 |  |
| Total liabilities | $ | 54,669 |  |  | $ | 56,763 |  |

[0001571996-21-000026:mdna:243]
Summarized Affiliate Financial Information

[0001571996-21-000026:mdna:244]
The equity interests of various affiliates within Dell Technologies’ consolidated group have been pledged as collateral for the Exchange Notes.  Dell Technologies is therefore subject to Rule 13-02 of the SEC’s Regulation S-X, which requires that summarized financial information for the affiliates whose securities are pledged as collateral (collectively, the “Affiliate Group”) be provided on a combined basis to the extent such information is material and materially different than the corresponding amounts presented in the Consolidated Financial Statements of Dell Technologies.  The summarized financial information for the Affiliate Group would produce results materially consistent with information presented in Dell Technologies’ Consolidated Financial Statements and we have therefore not included such information in this report.  In particular, the assets, liabilities, and results of operations of the Affiliate Group are not materially different than the corresponding amounts presented in the Consolidated Financial Statements of Dell Technologies, except with respect to the redeemable shares.  As of April 30, 2021 and January 29, 2021, the redeemable shares balance was $558 million and $472 million, respectively, as reflected on the Condensed Consolidated Statements of Financial Position included in this report, as compared to no redeemable shares reflected on the Affiliate Group balance sheet as of the respective dates.

[0001571996-21-000026:mdna:245]
Collateral Arrangement — The collateral (“Collateral”) securing the Exchange Notes generally consists of the following, whether now owned or hereafter acquired:

[0001571996-21-000026:mdna:246]
•100% of the equity interests of the Issuers, Dell and each Material Subsidiary (as defined in the applicable indenture) that is a wholly-owned subsidiary of the Issuers and the Guarantors (which pledge, in the case of capital stock of any Foreign Subsidiary or FSHCO (each as defined in the applicable indenture), is limited to 65% of the voting capital stock and 100% of the non-voting capital stock of such Foreign Subsidiary or FSHCO); and

[0001571996-21-000026:mdna:247]
•substantially all tangible and intangible personal property and material fee-owned real property of the Issuers and Guarantors (other than Dell Technologies) including but not limited to, accounts receivable, inventory, equipment, general intangibles (including contract rights), investment property, intellectual property, real property, intercompany notes, instruments, chattel paper and documents, letter of credit rights, commercial tort claims, and proceeds of the foregoing.

[0001571996-21-000026:mdna:248]
See Exhibit 22.1 filed with this report for a list of each affiliate of Dell Technologies whose security is pledged as collateral to secure the Exchange Notes.  There is no trading market for the applicable affiliates’ securities pledged as collateral.

[0001571996-21-000026:mdna:249]
Delivery of the Collateral securing the Exchange Notes would be required in certain customary events of default, including failure to make required payments, failure to comply with covenants, and the occurrence of certain events of bankruptcy and insolvency.

[0001571996-21-000026:mdna:250]
The Collateral may be released in certain circumstances, including, (i) to enable the sale, transfer or other disposition of such property or assets, (ii) upon the release of the guarantee of a Guarantor, (iii) upon such property or asset becoming an “excluded asset” as defined in the indentures governing the Exchange Notes, (iv) upon the achievement of investment grade ratings with respect to the Issuers and the Exchange Notes and (v) to the extent the liens on the Collateral securing the Senior Credit Facility obligations are released (other than in connection with the payment in full of the Senior Credit Facility).

[0001571996-21-000026:mdna:251]
The Collateral does not include, and will not include, among other things, (i) a pledge of the assets or equity interests of certain subsidiaries, including the Unrestricted Subsidiaries and their respective subsidiaries, (ii) any fee-owned real property with a book value of less than $150 million, (iii) any commercial tort claims or letter of credit rights with an individual value of less than $50 million, (iv) any “principal property” as defined in the indentures governing the Unsecured Notes and Debentures of Dell and the EMC Notes, and capital stock of any subsidiary holding “principal property” as defined in the indenture governing the Unsecured Notes and Debentures of Dell, or (v) certain excluded assets.

[0001571996-21-000026:mdna:252]
[same as prior period, unchanged from 0001571996-20-000051:mdna:188]
