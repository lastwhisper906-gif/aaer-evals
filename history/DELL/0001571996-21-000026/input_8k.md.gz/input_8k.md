# DELL 8-K — 0001571996-21-000019 filed 2021-05-27

## item codes, every 8-K on or before 2021-06-07

- 2021-05-27 0001571996-21-000019 — 2.02, 9.01
- 2021-05-03 0001571996-21-000010 — 8.01, 9.01
- 2021-04-14 0001193125-21-116271 — 1.01, 7.01, 9.01
- 2021-02-25 0001571996-21-000003 — 2.02, 9.01
- 2021-02-18 0001193125-21-047844 — 1.01, 2.03, 9.01
- 2020-11-24 0001571996-20-000048 — 2.02, 9.01
- 2020-08-27 0001571996-20-000041 — 2.02, 9.01
- 2020-07-02 0001571996-20-000037 — 5.07
- 2020-05-28 0001571996-20-000028 — 2.02, 9.01
- 2020-04-09 0001193125-20-102602 — 1.01, 2.03, 9.01
- 2020-04-08 0001571996-20-000021 — 5.02
- 2020-04-03 0001571996-20-000019 — 8.01, 9.01
- 2020-03-26 0001571996-20-000015 — 7.01
- 2020-02-27 0001571996-20-000009 — 2.02, 8.01, 9.01
- 2020-02-18 0001571996-20-000005 — 8.01, 9.01
- 2020-01-09 0001571996-20-000002 — 3.02
- 2020-01-06 0001193125-20-002200 — 3.02
- 2019-12-13 0001193125-19-313947 — 3.02
- 2019-12-10 0001571996-19-000052 — 5.02
- 2019-12-02 0001571996-19-000044 — 5.02, 7.01, 9.01
- 2019-11-26 0001571996-19-000042 — 2.02, 9.01
- 2019-09-23 0001193125-19-252192 — 1.01, 2.03, 9.01
- 2019-08-29 0001571996-19-000036 — 2.02, 9.01
- 2019-08-22 0001193125-19-226939 — 7.01, 8.01, 9.01
- 2019-07-11 0001571996-19-000032 — 5.02, 5.07, 9.01
- 2019-07-03 0001571996-19-000030 — 3.02
- 2019-06-27 0001571996-19-000028 — 3.02
- 2019-05-30 0001571996-19-000021 — 2.02, 9.01
- 2019-04-02 0001571996-19-000010 — 5.02
- 2019-03-21 0001193125-19-082281 — 1.01, 1.02, 2.03, 9.01
- 2019-03-19 0001571996-19-000005 — 5.02, 9.01
- 2019-03-14 0001193125-19-074935 — 1.01, 2.03, 9.01
- 2019-03-07 0001193125-19-066045 — 8.01, 9.01
- 2019-02-28 0001571996-19-000002 — 2.02, 9.01
- 2018-12-28 0001193125-18-360943 — 1.01, 1.02, 3.01, 3.03, 5.02, 5.03, 7.01, 8.01, 9.01
- 2018-12-21 0001193125-18-356324 — 1.01, 2.03, 9.01
- 2018-12-14 0001193125-18-349469 — 8.01
- 2018-12-11 0001193125-18-346958 — 5.07, 8.01, 9.01
- 2018-11-29 0001571996-18-000041 — 2.02, 9.01
- 2018-11-28 0001571996-18-000037 — 7.01, 8.01, 9.01
- 2018-11-26 0001193125-18-333967 — 8.01, 9.01
- 2018-11-15 0001193125-18-328110 — 1.01, 9.01 — amendment of 0001193125-18-327222
- 2018-11-15 0001193125-18-327222 — 1.01, 7.01, 9.01
- 2018-10-03 0001193125-18-291390 — 8.01
- 2018-09-06 0001571996-18-000029 — 2.02, 9.01
- 2018-08-06 0001571996-18-000027 — 8.01, 9.01
- 2018-07-02 0001193125-18-210339 — 1.01, 7.01, 9.01
- 2018-06-28 0001571996-18-000024 — 5.07
- 2018-06-04 0001571996-18-000019 — 2.02, 9.01
- 2018-05-17 0001571996-18-000016 — 7.01
- 2018-04-26 0001571996-18-000009 — 7.01, 9.01
- 2018-03-08 0001193125-18-074168 — 2.02, 9.01
- 2018-02-02 0001193125-18-029947 — 7.01, 9.01
- 2017-12-07 0001571996-17-000042 — 2.02, 9.01
- 2017-10-24 0001571996-17-000037 — 1.01, 2.03, 9.01
- 2017-09-15 0001571996-17-000027 — 5.02
- 2017-09-07 0001571996-17-000017 — 2.02, 9.01
- 2017-08-24 0001571996-17-000014 — 8.01
- 2017-06-29 0001571996-17-000011 — 3.03, 5.07, 8.01, 9.01
- 2017-06-08 0001193125-17-197638 — 2.02, 9.01
- 2017-03-30 0001193125-17-102794 — 8.01
- 2017-03-30 0001193125-17-102777 — 2.02, 9.01
- 2017-03-09 0001193125-17-076981 — 1.01, 2.03, 9.01
- 2017-01-17 0001193125-17-011125 — 8.01
- 2016-12-15 0001193125-16-793722 — 8.01
- 2016-12-08 0001193125-16-787976 — 2.02, 9.01
- 2016-11-10 0001193125-16-765964 — 1.02, 8.01
- 2016-11-04 0001193125-16-760249 — 8.01
- 2016-09-13 0001193125-16-708600 — 3.02
- 2016-09-09 0001193125-16-706567 — 1.01, 1.02, 2.01, 2.03, 3.02, 3.03, 5.02, 9.01
- 2016-09-07 0001193125-16-703370 — 3.03, 5.07, 7.01, 8.01, 9.01
- 2016-09-06 0001193125-16-702057 — 2.02, 9.01
- 2016-08-31 0001193125-16-697268 — 8.01, 9.01
- 2016-08-26 0001193125-16-692921 — 8.01, 9.01
- 2016-07-11 0001193125-16-645610 — 8.01
- 2016-07-05 0001193125-16-641679 — 8.01
- 2016-06-22 0001193125-16-629055 — 1.01, 2.03, 8.01, 9.01
- 2016-06-21 0001193125-16-627071 — 8.01, 9.01
- 2016-06-10 0001193125-16-618483 — 2.02, 9.01
- 2016-06-09 0001193125-16-617893 — 8.01, 9.01

## late-filing notifications on or before 2021-06-07

- none on or before 2021-06-07

## item 2.02 — earnings release, exhibit 99.1

[0001571996-21-000019:8k_2_02:1]
EX-99.1
2
exhibit991earnings8kq1fy22.htm
EX-99.1

[0001571996-21-000019:8k_2_02:2]
Document

[0001571996-21-000019:8k_2_02:3]
Exhibit 99.1

[0001571996-21-000019:8k_2_02:4]
News Release

[0001571996-21-000019:8k_2_02:5]
Future-of-Work Solutions Power Dell Technologies’

[0001571996-21-000019:8k_2_02:6]
Record First Quarter Fiscal 2022 Financial Results

[0001571996-21-000019:8k_2_02:7]
ROUND ROCK, Texas — May 27, 2021

[0001571996-21-000019:8k_2_02:8]
News summary

[0001571996-21-000019:8k_2_02:9]
•Record first quarter revenue of $24.5 billion, up 12%, driven by growth across Infrastructure Solutions, Client Solutions and VMware business units

[0001571996-21-000019:8k_2_02:10]
•Record first quarter operating income of $1.4 billion, up 96%, and record first quarter non-GAAP operating income of $2.7 billion, up 26%

[0001571996-21-000019:8k_2_02:11]
•Diluted earnings per share up 495% to $1.13, non-GAAP diluted earnings per share up 59% to $2.13

[0001571996-21-000019:8k_2_02:12]
Full story

[0001571996-21-000019:8k_2_02:13]
Dell Technologies (NYSE: DELL) announces record financial results for its fiscal 2022 first quarter. Revenue was up 12% to $24.5 billion. The company generated operating income of $1.4 billion, a 96% increase over the same period in the prior year, and non-GAAP operating income of $2.7 billion, up 26%. Net income was $938 million, non-GAAP net income was $1.8 billion and adjusted EBITDA was $3.2 billion. Net cash from operating activities was $2.2 billion. Diluted earnings per share was $1.13, up 495% and non-GAAP diluted earnings per share was $2.13, up 59%.

[0001571996-21-000019:8k_2_02:14]
“There has been a substantial acceleration in digital transformation across the globe and you can see it in our results with record first quarter revenue of $24.5 billion. Now more than ever, customers are turning to Dell Technologies to help build their digital future,” said Jeff Clarke, chief operating officer and vice chairman, Dell Technologies. “Looking ahead, we see technology becoming increasingly central to the global economy and society. We’re excited for the opportunities ahead and for the data-fueled future we’re creating.”

[0001571996-21-000019:8k_2_02:15]
1

[0001571996-21-000019:8k_2_02:16]
First Quarter Fiscal 2022 Financial Results

[0001571996-21-000019:8k_2_02:17]
|  | Three Months Ended |  |  |  |  |  |  |
|  | April 30, 2021 |  | May 1, 2020 |  | Change |  |  |  |  |  |  |
|  | (in millions, except per share amounts and percentages; unaudited) |
| Total net revenue | $ | 24,487 |  |  | $ | 21,897 |  |  | 12% |  |  |  |  |  |  |
| Operating income | $ | 1,375 |  |  | $ | 702 |  |  | 96% |  |  |  |  |  |  |
| Net income | $ | 938 |  |  | $ | 182 |  |  | 415% |  |  |  |  |  |  |
| Earnings per share - diluted | $ | 1.13 |  |  | $ | 0.19 |  |  | 495% |  |  |  |  |  |  |
| Non-GAAP net revenue | $ | 24,499 |  |  | $ | 21,945 |  |  | 12% |  |  |  |  |  |  |
| Non-GAAP operating income | $ | 2,714 |  |  | $ | 2,161 |  |  | 26% |  |  |  |  |  |  |
| Non-GAAP net income | $ | 1,819 |  |  | $ | 1,143 |  |  | 59% |  |  |  |  |  |  |
| Adjusted EBITDA | $ | 3,235 |  |  | $ | 2,607 |  |  | 24% |  |  |  |  |  |  |
| Non-GAAP earnings per share - diluted | $ | 2.13 |  |  | $ | 1.34 |  |  | 59% |  |  |  |  |  |  |

[0001571996-21-000019:8k_2_02:18]
Information about Dell Technologies’ use of non-GAAP financial information is provided under “Non-GAAP Financial Measures” below.  All comparisons in this press release are year-over-year unless otherwise noted.

[0001571996-21-000019:8k_2_02:19]
Dell Technologies ended the quarter with remaining performance obligations of $42 billion and cash and investments of $15.9 billion. The company has paid down $2.5 billion in debt year-to-date and revised its debt paydown target for its fiscal year 2022 to at least $16.0 billion upon completion of its announced spin-off of VMware.

[0001571996-21-000019:8k_2_02:20]
“We had record first quarter revenue and operating income, and record trailing 12 month cash flow from operations of $14.4 billion – all driven by strength and execution across all three of our business units,” said Tom Sweet, chief financial officer, Dell Technologies. “Our focus continues to be on strengthening our capital structure, modernizing our core infrastructure and PC businesses, and continuing to grow in hybrid and private cloud, edge, telecom and as-a-Service.”

[0001571996-21-000019:8k_2_02:21]
Operating segments summary

[0001571996-21-000019:8k_2_02:22]
Earlier in May, at Dell Technologies World, the company announced new offers for its APEX portfolio of as-a-Service offerings, and a new set of solutions and partnerships designed to extract more value from data at the edge, including smart manufacturing solutions. The APEX portfolio of services allows customers to scale IT as needed to launch new applications, kickstart new projects and address the changing needs of their organizations – all managed by Dell and accessed through a single console.

[0001571996-21-000019:8k_2_02:23]
Client Solutions Group had record revenue for the first quarter of $13.3 billion, up 20%. Operating income was a record $1.1 billion, up 84%, and 8.2% of Client Solutions Group revenue, as the company innovates across the ecosystem to deliver an enhanced experience for customers looking to work and play effectively from anywhere. Consumer revenue was $3.5 billion, up 42%, while commercial client revenue was $9.8 billion, up 14%.

[0001571996-21-000019:8k_2_02:24]
2

[0001571996-21-000019:8k_2_02:25]
Key highlights:

[0001571996-21-000019:8k_2_02:26]
•Consumer online business orders up 58%, with XPS notebook orders up 21% and Alienware notebooks orders up 76%

[0001571996-21-000019:8k_2_02:27]
•Double-digit orders growth in Latitude, Precision systems, and Commercial Chromebooks

[0001571996-21-000019:8k_2_02:28]
•Announced a sweeping new portfolio of commercial, consumer and gaming devices to help people create, play and work from anywhere

[0001571996-21-000019:8k_2_02:29]
Infrastructure Solutions Group revenue for the first quarter was $7.9 billion, up 5% as customers accelerate their IT investments with focus on hybrid cloud solutions. Servers and networking revenue was $4.1 billion, up 9%, and storage revenue was $3.8 billion. Operating income was $788 million for the first quarter, up 8%, or approximately 10% of Infrastructure Solutions Group revenue.

[0001571996-21-000019:8k_2_02:30]
Key highlights:

[0001571996-21-000019:8k_2_02:31]
•Expanded the Dell EMC PowerProtect Cyber Recovery solution with multi-cloud options to help customers build a cyber resilient strategy as ransomware threats continue

[0001571996-21-000019:8k_2_02:32]
•Launch of Dell EMC PowerStore software advancements that improve workload performance by up to 25%, building on its novel container-based architecture and supporting the new PowerStore 500, a lower-cost model suitable for a broad range of businesses and use cases with enterprise performance and features

[0001571996-21-000019:8k_2_02:33]
•Launch of the next generation of Dell EMC PowerEdge servers, the most powerful and secure systems to date, embracing AI and addressing customer need to keep pace with IT demands in data centers and at the edge

[0001571996-21-000019:8k_2_02:34]
•Launch of Dell EMC Streaming Data Platform advancements that offer powerful, real-time analytics at the edge and the Dell Technologies Manufacturing Edge Solution enabling critical applications in smart manufacturing

[0001571996-21-000019:8k_2_02:35]
VMware revenue was $3.0 billion for the first quarter, up 9% driven by broad-based strength across a diverse product portfolio. Operating income for the quarter was $841 million, or 28.1% of VMware revenue.

[0001571996-21-000019:8k_2_02:36]
Conference call information

[0001571996-21-000019:8k_2_02:37]
As previously announced, the Company will hold a conference call to discuss its first quarter performance today, May 27, 2021 at 4:30 p.m. CDT. The conference call will be broadcast live over the internet and can be accessed at https://investors.delltechnologies.com/events-and-presentations/upcoming-events

[0001571996-21-000019:8k_2_02:38]
For those unable to listen to the live broadcast, an archived version will be available at the same location for one year.

[0001571996-21-000019:8k_2_02:39]
Additional financial and operating information may be downloaded from https://investors.delltechnologies.com/financial-information/quarterly-results

[0001571996-21-000019:8k_2_02:40]
About Dell Technologies

[0001571996-21-000019:8k_2_02:41]
Dell Technologies (NYSE:DELL) helps organizations and individuals build their digital future and transform how they work, live and play.  The company provides customers with the industry’s broadest and most innovative technology and services portfolio for the data era.

[0001571996-21-000019:8k_2_02:42]
3

[0001571996-21-000019:8k_2_02:43]
Contacts

[0001571996-21-000019:8k_2_02:44]
Investors: Investor_Relations@Dell.com

[0001571996-21-000019:8k_2_02:45]
Media: Media.Relations@Dell.com

[0001571996-21-000019:8k_2_02:46]
# # #

[0001571996-21-000019:8k_2_02:47]
Copyright © 2021 Dell Inc. or its subsidiaries. All Rights Reserved. Dell Technologies, Dell, EMC and Dell EMC are trademarks of Dell Inc. or its subsidiaries. Other trademarks may be trademarks of their respective owners.

[0001571996-21-000019:8k_2_02:48]
Non-GAAP Financial Measures:

[0001571996-21-000019:8k_2_02:49]
This press release presents information about Dell Technologies’ non-GAAP net revenue, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, non-GAAP net income attributable to non-controlling interests, non-GAAP net income attributable to Dell Technologies Inc. - basic, non-GAAP net income attributable to Dell Technologies Inc. - diluted, non-GAAP earnings per share attributable to Dell Technologies Inc. - basic, non-GAAP earnings per share attributable to Dell Technologies Inc. - diluted, EBITDA, and adjusted EBITDA, which are non-GAAP financial measures provided as a supplement to the results provided in accordance with generally accepted accounting principles in the United States of America (“GAAP”). A reconciliation of each non-GAAP financial measure to the most directly comparable GAAP financial measure is provided in the attached tables for each of the fiscal periods indicated.

[0001571996-21-000019:8k_2_02:50]
Special Note on Forward-Looking Statements:

[0001571996-21-000019:8k_2_02:51]
Dell Technologies’ results or events in future periods could differ materially from those expressed or implied by these forward-looking statements because of risks, uncertainties, and other factors that include, but are not limited to, the following: risks and uncertainties relating to our agreement to spin off VMware, Inc., including risks that could affect our ability to complete the transaction on the terms announced or at all and the potential effects on our business of the announcement and consummation of the transaction; the effects of the COVID-19 pandemic; competitive pressures; Dell Technologies’ reliance on third-party suppliers for products and components, including reliance on single-source or limited-source suppliers; Dell Technologies’ ability to achieve favorable pricing from its vendors; adverse global economic conditions and instability in financial markets; Dell Technologies’ execution of its growth, business and acquisition strategies; the success of Dell Technologies’ cost efficiency measures; Dell Technologies’ ability to manage solutions and products and services transitions in an effective manner; Dell Technologies’ ability to deliver high-quality products, software, and services; cyber attacks or other data security incidents; Dell Technologies’ foreign operations and ability to generate substantial non-U.S. net revenue; Dell Technologies’ product, services, customer, and geographic sales mix, and seasonal sales trends; the performance of Dell Technologies’ sales channel partners; access to the capital markets by Dell Technologies or its customers; material impairment of the value of goodwill or intangible assets; weak economic conditions and the effect of additional regulation on Dell Technologies’ financial services activities; counterparty default risks; the loss by Dell Technologies of any contracts for ISG services and solutions and its ability to perform such contracts at their estimated costs; loss by Dell Technologies of government contracts; Dell Technologies’ ability to develop and protect its proprietary intellectual property or obtain licenses to intellectual property developed by others on commercially reasonable and competitive terms; disruptions in Dell Technologies’ infrastructure; Dell Technologies’ ability to hedge effectively its exposure to fluctuations in foreign currency exchange rates and interest rates; expiration of tax holidays or favorable tax rate structures, or unfavorable outcomes in tax audits and other tax compliance matters; impairment of portfolio investments; unfavorable results of legal proceedings; compliance requirements of changing environmental and safety laws or other laws; the effect of armed hostilities, terrorism, natural disasters, and public health issues; Dell Technologies’ dependence on the services of Michael Dell and key employees; Dell Technologies’ level of indebtedness; and the impact of the financial performance of VMware, Inc.

[0001571996-21-000019:8k_2_02:52]
This list of risks, uncertainties, and other factors is not complete. Dell Technologies discusses some of these matters more fully, as well as certain risk factors that could affect Dell Technologies’ business, financial condition, results of operations, and prospects, in its reports filed with the SEC, including Dell Technologies’ annual report on Form 10-K for the fiscal year ended January 29, 2021, quarterly reports on Form 10-Q, and current reports on Form 8-K. These filings are available for review through the SEC’s website at www.sec.gov. Any or all forward-looking statements Dell Technologies makes may turn out to be wrong and can be affected by inaccurate assumptions Dell Technologies might make or by known or unknown risks, uncertainties and other factors, including those identified in this press release. Accordingly, you should not place undue reliance on the forward-looking statements made in this press release, which speak only as of its date. Dell Technologies does not undertake to update, and expressly disclaims any duty to update, its forward-looking statements, whether as a result of circumstances or events that arise after the date they are made, new information, or otherwise.

[0001571996-21-000019:8k_2_02:53]
4

[0001571996-21-000019:8k_2_02:54]
DELL TECHNOLOGIES INC.

[0001571996-21-000019:8k_2_02:55]
Condensed Consolidated Statements of Income and Related Financial Highlights

[0001571996-21-000019:8k_2_02:56]
(in millions, except percentages; unaudited)

[0001571996-21-000019:8k_2_02:57]
|  | Three Months Ended |  |  |  |  |  |  |
|  | April 30, 2021 |  | May 1, 2020 |  | Change |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Products | $ | 18,034 |  | $ | 16,038 |  | 12% |  |  |  |  |  |  |
| Services | 6,453 |  | 5,859 |  | 10% |  |  |  |  |  |  |
| Total net revenue | 24,487 |  | 21,897 |  | 12% |  |  |  |  |  |  |
| Cost of net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Products | 14,214 |  | 12,804 |  | 11% |  |  |  |  |  |  |
| Services | 2,615 |  | 2,240 |  | 17% |  |  |  |  |  |  |
| Total cost of net revenue | 16,829 |  | 15,044 |  | 12% |  |  |  |  |  |  |
| Gross margin | 7,658 |  | 6,853 |  | 12% |  |  |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative | 4,960 |  | 4,886 |  | 2% |  |  |  |  |  |  |
| Research and development | 1,323 |  | 1,265 |  | 5% |  |  |  |  |  |  |
| Total operating expenses | 6,283 |  | 6,151 |  | 2% |  |  |  |  |  |  |
| Operating income | 1,375 |  | 702 |  | 96% |  |  |  |  |  |  |
| Interest and other, net | (388) |  | (566) |  | 31% |  |  |  |  |  |  |
| Income before income taxes | 987 |  | 136 |  | 626% |  |  |  |  |  |  |
| Income tax expense (benefit) | 49 |  | (46) |  | 207% |  |  |  |  |  |  |
| Net income | 938 |  | 182 |  | 415% |  |  |  |  |  |  |
| Less: Net income attributable to non-controlling interests | 51 |  | 39 |  | 31% |  |  |  |  |  |  |
| Net income attributable to Dell Technologies Inc. | $ | 887 |  | $ | 143 |  | 520% |  |  |  |  |  |  |
| Percentage of Total Net Revenue: |  |  |  |  |  |  |  |  |  |  |
| Gross margin | 31 | % |  | 31 | % |  |  |  |  |  |  |  |  |
| Selling, general, and administrative | 20 | % |  | 22 | % |  |  |  |  |  |  |  |  |
| Research and development | 5 | % |  | 6 | % |  |  |  |  |  |  |  |  |
| Operating expenses | 26 | % |  | 28 | % |  |  |  |  |  |  |  |  |
| Operating income | 6 | % |  | 3 | % |  |  |  |  |  |  |  |  |
| Income before income taxes | 4 | % |  | 1 | % |  |  |  |  |  |  |  |  |
| Net income | 4 | % |  | 1 | % |  |  |  |  |  |  |  |  |
| Income tax rate | 5.0 | % |  | -33.8 | % |  |  |  |  |  |  |  |  |

[0001571996-21-000019:8k_2_02:58]
5

[0001571996-21-000019:8k_2_02:59]
DELL TECHNOLOGIES INC.

[0001571996-21-000019:8k_2_02:60]
Consolidated Statements of Financial Position

[0001571996-21-000019:8k_2_02:61]
(in millions; unaudited)

[0001571996-21-000019:8k_2_02:62]
|  | April 30, 2021 |  | January 29, 2021 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 14,244 |  |  | $ | 14,201 |  |
| Accounts receivable, net | 10,909 |  |  | 12,788 |  |
| Short-term financing receivables, net | 4,980 |  |  | 5,155 |  |
| Inventories, net | 3,828 |  |  | 3,402 |  |
| Other current assets | 8,378 |  |  | 8,021 |  |
| Total current assets | 42,339 |  |  | 43,567 |  |
| Property, plant, and equipment, net | 6,557 |  |  | 6,431 |  |
| Long-term investments | 1,670 |  |  | 1,624 |  |
| Long-term financing receivables, net | 5,261 |  |  | 5,339 |  |
| Goodwill | 40,839 |  |  | 40,829 |  |
| Intangible assets, net | 13,729 |  |  | 14,429 |  |
| Other non-current assets | 11,357 |  |  | 11,196 |  |
| Total assets | $ | 121,752 |  |  | $ | 123,415 |  |
| LIABILITIES, REDEEMABLE SHARES, AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Short-term debt | $ | 8,748 |  |  | $ | 6,362 |  |
| Accounts payable | 21,545 |  |  | 21,696 |  |
| Accrued and other | 7,728 |  |  | 9,549 |  |
| Short-term deferred revenue | 16,835 |  |  | 16,525 |  |
| Total current liabilities | 54,856 |  |  | 54,132 |  |
| Long-term debt | 37,935 |  |  | 41,622 |  |
| Long-term deferred revenue | 14,541 |  |  | 14,276 |  |
| Other non-current liabilities | 5,276 |  |  | 5,360 |  |
| Total liabilities | 112,608 |  |  | 115,390 |  |
| Redeemable shares | 558 |  |  | 472 |  |
| Stockholders’ equity: |  |  |  |
| Total Dell Technologies Inc. stockholders’ equity | 3,487 |  |  | 2,479 |  |
| Non-controlling interests | 5,099 |  |  | 5,074 |  |
| Total stockholders’ equity | 8,586 |  |  | 7,553 |  |
| Total liabilities, redeemable shares, and stockholders’ equity | $ | 121,752 |  |  | $ | 123,415 |  |

[0001571996-21-000019:8k_2_02:63]
6

[0001571996-21-000019:8k_2_02:64]
DELL TECHNOLOGIES INC.

[0001571996-21-000019:8k_2_02:65]
Condensed Consolidated Statements of Cash Flows

[0001571996-21-000019:8k_2_02:66]
(in millions; unaudited)

[0001571996-21-000019:8k_2_02:67]
|  | Three Months Ended |  |  |
|  | April 30, 2021 |  | May 1, 2020 |  |  |  |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |
| Net income | $ | 938 |  |  | $ | 182 |  |  |  |  |  |
| Adjustments to reconcile net income to net cash provided by (used in) operating activities | 1,300 |  |  | (978) |  |  |  |  |  |
| Change in cash from operating activities | 2,238 |  |  | (796) |  |  |  |  |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |
| Purchases of investments | (146) |  |  | (56) |  |  |  |  |  |
| Maturities and sales of investments | 256 |  |  | 39 |  |  |  |  |  |
| Capital expenditures and capitalized software development costs | (625) |  |  | (559) |  |  |  |  |  |
| Acquisition of businesses and assets, net | (10) |  |  | (38) |  |  |  |  |  |
| Divestitures of businesses and assets, net | — |  |  | 120 |  |  |  |  |  |
| Other | 6 |  |  | 9 |  |  |  |  |  |
| Change in cash from investing activities | (519) |  |  | (485) |  |  |  |  |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |
| Proceeds from the issuance of common stock | 160 |  |  | 116 |  |  |  |  |  |
| Repurchases of parent common stock | (9) |  |  | (240) |  |  |  |  |  |
| Repurchases of subsidiary common stock (a) | (434) |  |  | (300) |  |  |  |  |  |
| Proceeds from debt | 2,726 |  |  | 10,135 |  |  |  |  |  |
| Repayments of debt | (4,070) |  |  | (5,405) |  |  |  |  |  |
| Other | (11) |  |  | (42) |  |  |  |  |  |
| Change in cash from financing activities | (1,638) |  |  | 4,264 |  |  |  |  |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash | (5) |  |  | (136) |  |  |  |  |  |
| Change in cash, cash equivalents, and restricted cash | 76 |  |  | 2,847 |  |  |  |  |  |
| Cash, cash equivalents, and restricted cash at beginning of the period | 15,184 |  |  | 10,151 |  |  |  |  |  |
| Cash, cash equivalents, and restricted cash at end of the period | $ | 15,260 |  |  | $ | 12,998 |  |  |  |  |  |

[0001571996-21-000019:8k_2_02:68]
_________________

[0001571996-21-000019:8k_2_02:69]
(a)     Subsidiary common stock repurchases are inclusive of employee tax withholding on stock-based compensation.

[0001571996-21-000019:8k_2_02:70]
7

[0001571996-21-000019:8k_2_02:71]
DELL TECHNOLOGIES INC.

[0001571996-21-000019:8k_2_02:72]
Segment Information

[0001571996-21-000019:8k_2_02:73]
(in millions, except percentages; unaudited; continued on next page)

[0001571996-21-000019:8k_2_02:74]
|  | Three Months Ended |  |  |  |  |  |  |
|  | April 30, 2021 |  | May 1, 2020 |  | Change |  |  |  |  |  |  |
| Infrastructure Solutions Group (ISG): |
| Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Servers and networking | $ | 4,109 |  |  | $ | 3,758 |  |  | 9% |  |  |  |  |  |  |
| Storage | 3,802 |  |  | 3,811 |  |  | —% |  |  |  |  |  |  |
| Total ISG net revenue | $ | 7,911 |  |  | $ | 7,569 |  |  | 5% |  |  |  |  |  |  |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| ISG operating income | $ | 788 |  |  | $ | 732 |  |  | 8% |  |  |  |  |  |  |
| % of ISG net revenue | 10 | % |  | 10 | % |  |  |  |  |  |  |  |  |
| % of total reportable segment operating income | 29 | % |  | 35 | % |  |  |  |  |  |  |  |  |
| Client Solutions Group (CSG): |
| Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 9,803 |  |  | $ | 8,634 |  |  | 14% |  |  |  |  |  |  |
| Consumer | 3,502 |  |  | 2,470 |  |  | 42% |  |  |  |  |  |  |
| Total CSG net revenue | $ | 13,305 |  |  | $ | 11,104 |  |  | 20% |  |  |  |  |  |  |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| CSG operating income | $ | 1,090 |  |  | $ | 592 |  |  | 84% |  |  |  |  |  |  |
| % of CSG net revenue | 8 | % |  | 5 | % |  |  |  |  |  |  |  |  |
| % of total reportable segment operating income | 40 | % |  | 28 | % |  |  |  |  |  |  |  |  |
| VMware: |
| Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Total VMware net revenue | $ | 2,991 |  |  | $ | 2,755 |  |  | 9% |  |  |  |  |  |  |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| VMware operating income | $ | 841 |  |  | $ | 773 |  |  | 9% |  |  |  |  |  |  |
| % of VMware net revenue | 28 | % |  | 28 | % |  |  |  |  |  |  |  |  |
| % of total reportable segment operating income | 31 | % |  | 37 | % |  |  |  |  |  |  |  |  |

[0001571996-21-000019:8k_2_02:75]
8

[0001571996-21-000019:8k_2_02:76]
DELL TECHNOLOGIES INC.

[0001571996-21-000019:8k_2_02:77]
Segment Information

[0001571996-21-000019:8k_2_02:78]
(in millions, except percentages; unaudited; continued)

[0001571996-21-000019:8k_2_02:79]
|  | Three Months Ended |  |  |
|  | April 30, 2021 |  | May 1, 2020 |  |  |  |  |
| Reconciliation to consolidated net revenue: |  |  |  |  |  |  |
| Reportable segment net revenue | $ | 24,207 |  |  | $ | 21,428 |  |  |  |  |  |
| Other businesses (a) | 290 |  |  | 517 |  |  |  |  |  |
| Unallocated transactions (b) | 2 |  |  | — |  |  |  |  |  |
| Impact of purchase accounting (c) | (12) |  |  | (48) |  |  |  |  |  |
| Total consolidated net revenue | $ | 24,487 |  |  | $ | 21,897 |  |  |  |  |  |
| Reconciliation to consolidated operating income: |  |  |  |  |
| Reportable segment operating income | $ | 2,719 |  |  | $ | 2,097 |  |  |  |  |  |
| Other businesses (a) | (5) |  |  | 65 |  |  |  |  |  |
| Unallocated transactions (b) | — |  |  | (1) |  |  |  |  |  |
| Impact of purchase accounting (c) | (25) |  |  | (63) |  |  |  |  |  |
| Amortization of intangibles | (709) |  |  | (855) |  |  |  |  |  |
| Transaction-related expenses (d) | (51) |  |  | (76) |  |  |  |  |  |
| Stock-based compensation expense (e) | (435) |  |  | (370) |  |  |  |  |  |
| Other corporate expenses (f) | (119) |  |  | (95) |  |  |  |  |  |
| Total consolidated operating income | $ | 1,375 |  |  | $ | 702 |  |  |  |  |  |

[0001571996-21-000019:8k_2_02:80]
_________________

[0001571996-21-000019:8k_2_02:81]
(a)Secureworks, Virtustream, and Boomi constitute “Other businesses” and do not meet the requirements for a reportable segment, either individually or collectively. The results of Other businesses are not material to the Company’s overall results. On September 1, 2020, the Company completed the sale of RSA Security. Prior to divestiture, RSA Security’s results were included within Other businesses.

[0001571996-21-000019:8k_2_02:82]
(b)Unallocated transactions includes other corporate items that are not allocated to Dell Technologies’ reportable segments.

[0001571996-21-000019:8k_2_02:83]
(c)Impact of purchase accounting includes non-cash purchase accounting adjustments that are primarily related to the EMC merger transaction.

[0001571996-21-000019:8k_2_02:84]
(d)Transaction-related expenses includes acquisition, integration, and divestiture related costs.

[0001571996-21-000019:8k_2_02:85]
(e)Stock-based compensation expense consists of equity awards granted based on the estimated fair value of those awards at grant date.

[0001571996-21-000019:8k_2_02:86]
(f)Other corporate expenses includes impairment charges, severance, facility action, and other costs.

[0001571996-21-000019:8k_2_02:87]
9

[0001571996-21-000019:8k_2_02:88]
SUPPLEMENTAL SELECTED NON-GAAP FINANCIAL MEASURES

[0001571996-21-000019:8k_2_02:89]
These tables present information about the Company’s non-GAAP net revenue, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, non-GAAP net income attributable to non-controlling interests, non-GAAP net income attributable to Dell Technologies Inc. - basic, non-GAAP net income attributable to Dell Technologies Inc. - diluted, non-GAAP earnings per share attributable to Dell Technologies Inc. - basic, non-GAAP earnings per share attributable to Dell Technologies Inc. - diluted, EBITDA, and adjusted EBITDA, which are non-GAAP financial measures provided as a supplement to the results provided in accordance with generally accepted accounting principles in the United States of America (“GAAP”). A detailed discussion of Dell Technologies’ reasons for including these non-GAAP financial measures, the limitations associated with these measures, the items excluded from these measures, and our reason for excluding those items are presented in “Management’s Discussion and Analysis of Financial Condition and Results of Operations — Non-GAAP Financial Measures” in our periodic reports filed with the SEC. Dell Technologies encourages investors to review the non-GAAP discussion in these reports in conjunction with the presentation of non-GAAP financial measures.

[0001571996-21-000019:8k_2_02:90]
10

[0001571996-21-000019:8k_2_02:91]
DELL TECHNOLOGIES INC.

[0001571996-21-000019:8k_2_02:92]
Selected Non-GAAP Financial Measures

[0001571996-21-000019:8k_2_02:93]
(in millions, except per share amounts and percentages; unaudited)

[0001571996-21-000019:8k_2_02:94]
|  | Three Months Ended |  |  |  |  |  |  |
|  | April 30, 2021 |  | May 1, 2020 |  | Change |  |  |  |  |  |  |
| Non-GAAP net revenue | $ | 24,499 |  | $ | 21,945 |  | 12% |  |  |  |  |  |  |
| Non-GAAP gross margin | $ | 8,018 |  | $ | 7,325 |  | 9% |  |  |  |  |  |  |
| % of non-GAAP net revenue | 33 | % |  | 33 | % |  |  |  |  |  |  |  |  |
| Non-GAAP operating expenses | $ | 5,304 |  | $ | 5,164 |  | 3% |  |  |  |  |  |  |
| % of non-GAAP net revenue | 22 | % |  | 24 | % |  |  |  |  |  |  |  |  |
| Non-GAAP operating income | $ | 2,714 |  | $ | 2,161 |  | 26% |  |  |  |  |  |  |
| % of non-GAAP net revenue | 11 | % |  | 10 | % |  |  |  |  |  |  |  |  |
| Non-GAAP net income | $ | 1,819 |  | $ | 1,143 |  | 59% |  |  |  |  |  |  |
| % of non-GAAP net revenue | 7 | % |  | 5 | % |  |  |  |  |  |  |  |  |
| Adjusted EBITDA | $ | 3,235 |  | $ | 2,607 |  | 24% |  |  |  |  |  |  |
| % of non-GAAP net revenue | 13 | % |  | 12 | % |  |  |  |  |  |  |  |  |
| Non-GAAP earnings per share - diluted | $ | 2.13 |  | $ | 1.34 |  | 59% |  |  |  |  |  |  |

[0001571996-21-000019:8k_2_02:95]
11

[0001571996-21-000019:8k_2_02:96]
DELL TECHNOLOGIES INC.

[0001571996-21-000019:8k_2_02:97]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-21-000019:8k_2_02:98]
(in millions, except percentages; unaudited; continued on next page)

[0001571996-21-000019:8k_2_02:99]
|  | Three Months Ended |  |  |  |  |  |  |
|  | April 30, 2021 |  | May 1, 2020 |  | Change |  |  |  |  |  |  |
| Net revenue | $ | 24,487 |  |  | $ | 21,897 |  |  | 12% |  |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 12 |  |  | 48 |  |  |  |  |  |  |  |  |  |
| Non-GAAP net revenue | $ | 24,499 |  |  | $ | 21,945 |  |  | 12% |  |  |  |  |  |  |
| Gross margin | $ | 7,658 |  |  | $ | 6,853 |  |  | 12% |  |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 276 |  |  | 372 |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 13 |  |  | 51 |  |  |  |  |  |  |  |  |  |
| Transaction-related expenses | — |  |  | — |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense | 58 |  |  | 40 |  |  |  |  |  |  |  |  |  |
| Other corporate expenses | 13 |  |  | 9 |  |  |  |  |  |  |  |  |  |
| Non-GAAP gross margin | $ | 8,018 |  |  | $ | 7,325 |  |  | 9% |  |  |  |  |  |  |
| Operating expenses | $ | 6,283 |  |  | $ | 6,151 |  |  | 2% |  |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | (433) |  |  | (483) |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | (12) |  |  | (12) |  |  |  |  |  |  |  |  |  |
| Transaction-related expenses | (51) |  |  | (76) |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense | (377) |  |  | (330) |  |  |  |  |  |  |  |  |  |
| Other corporate expenses | (106) |  |  | (86) |  |  |  |  |  |  |  |  |  |
| Non-GAAP operating expenses | $ | 5,304 |  |  | $ | 5,164 |  |  | 3% |  |  |  |  |  |  |
| Operating income | $ | 1,375 |  |  | $ | 702 |  |  | 96% |  |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 709 |  |  | 855 |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 25 |  |  | 63 |  |  |  |  |  |  |  |  |  |
| Transaction-related expenses | 51 |  |  | 76 |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense | 435 |  |  | 370 |  |  |  |  |  |  |  |  |  |
| Other corporate expenses | 119 |  |  | 95 |  |  |  |  |  |  |  |  |  |
| Non-GAAP operating income | $ | 2,714 |  |  | $ | 2,161 |  |  | 26% |  |  |  |  |  |  |

[0001571996-21-000019:8k_2_02:100]
12

[0001571996-21-000019:8k_2_02:101]
DELL TECHNOLOGIES INC.

[0001571996-21-000019:8k_2_02:102]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-21-000019:8k_2_02:103]
(in millions, except percentages; unaudited; continued)

[0001571996-21-000019:8k_2_02:104]
|  | Three Months Ended |  |  |  |  |  |  |
|  | April 30, 2021 |  | May 1, 2020 |  | Change |  |  |  |  |  |  |
| Net income | $ | 938 |  |  | $ | 182 |  |  | 415% |  |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 709 |  |  | 855 |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 25 |  |  | 63 |  |  |  |  |  |  |  |  |  |
| Transaction-related expenses | 51 |  |  | (44) |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense | 435 |  |  | 370 |  |  |  |  |  |  |  |  |  |
| Other corporate expenses | 119 |  |  | 95 |  |  |  |  |  |  |  |  |  |
| Fair value adjustments on equity investments | (157) |  |  | (94) |  |  |  |  |  |  |  |  |  |
| Aggregate adjustment for income taxes | (301) |  |  | (284) |  |  |  |  |  |  |  |  |  |
| Non-GAAP net income | $ | 1,819 |  |  | $ | 1,143 |  |  | 59% |  |  |  |  |  |  |
| Net income | $ | 938 |  |  | $ | 182 |  |  | 415% |  |  |  |  |  |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Interest and other, net | 388 |  |  | 566 |  |  |  |  |  |  |  |  |  |
| Income tax expense (benefit) | 49 |  |  | (46) |  |  |  |  |  |  |  |  |  |
| Depreciation and amortization | 1,239 |  |  | 1,316 |  |  |  |  |  |  |  |  |  |
| EBITDA | $ | 2,614 |  |  | $ | 2,018 |  |  | 30% |  |  |  |  |  |  |
| EBITDA | $ | 2,614 |  |  | $ | 2,018 |  |  | 30% |  |  |  |  |  |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense | 435 |  |  | 370 |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 16 |  |  | 48 |  |  |  |  |  |  |  |  |  |
| Transaction-related expenses | 51 |  |  | 76 |  |  |  |  |  |  |  |  |  |
| Other corporate expenses | 119 |  |  | 95 |  |  |  |  |  |  |  |  |  |
| Adjusted EBITDA | $ | 3,235 |  |  | $ | 2,607 |  |  | 24% |  |  |  |  |  |  |

[0001571996-21-000019:8k_2_02:105]
13

[0001571996-21-000019:8k_2_02:106]
DELL TECHNOLOGIES INC.

[0001571996-21-000019:8k_2_02:107]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-21-000019:8k_2_02:108]
For the Three Months Ended April 30, 2021

[0001571996-21-000019:8k_2_02:109]
(in millions, except per share amounts; unaudited)

[0001571996-21-000019:8k_2_02:110]
|  | GAAP |  | Amortization of intangibles |  | Impact of purchase accounting |  | Transaction-related expenses |  | Stock-based compensation expense |  | Other corporate expenses |  | Fair value adjustments on equity investments |  | Aggregate adjustment for income taxes |  | Non-GAAP |
| Net income | $ | 938 |  |  | 709 |  |  | 25 |  |  | 51 |  |  | 435 |  |  | 119 |  |  | (157) |  |  | (301) |  |  | $ | 1,819 |  |
| Less: Net income attributable to non-controlling interests (a) | 51 |  |  | 53 |  |  | 1 |  |  | 4 |  |  | 52 |  |  | 1 |  |  | 7 |  |  | (23) |  |  | 146 |  |
| Net income attributable to Dell Technologies Inc. - basic | 887 |  |  | 656 |  |  | 24 |  |  | 47 |  |  | 383 |  |  | 118 |  |  | (164) |  |  | (278) |  |  | 1,673 |  |
| Incremental dilution from VMware, Inc. attributable to Dell Technologies Inc. (b) | (2) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (4) |  |
| Net income attributable to Dell Technologies Inc. - diluted | $ | 885 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 1,669 |  |
| Earnings per share - basic | $ | 1.17 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 2.21 |  |
| Earnings per share - diluted | $ | 1.13 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 2.13 |  |
| Weighted-average shares outstanding - basic | 757 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 757 |  |
| Weighted-average shares outstanding - diluted | 782 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 782 |  |

[0001571996-21-000019:8k_2_02:111]
_________________

[0001571996-21-000019:8k_2_02:112]
(a)     Net income attributable to non-controlling interests is calculated by multiplying the minority interest percentage of VMware, Inc. and SecureWorks Corp. by their respective non-GAAP net income adjustments for the period presented.

[0001571996-21-000019:8k_2_02:113]
(b)     Incremental dilution from VMware, Inc. attributable to Dell Technologies Inc. represents the impact of VMware, Inc.’s dilutive securities on the diluted earnings per share of Dell Technologies Inc. and is calculated by multiplying the difference between VMware, Inc.’s basic and diluted earnings per share by the number of shares of VMware, Inc. common stock held by Dell Technologies Inc.

[0001571996-21-000019:8k_2_02:114]
DELL TECHNOLOGIES INC.

[0001571996-21-000019:8k_2_02:115]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-21-000019:8k_2_02:116]
For the Three Months Ended May 1, 2020

[0001571996-21-000019:8k_2_02:117]
(in millions, except per share amounts; unaudited)

[0001571996-21-000019:8k_2_02:118]
|  | GAAP |  | Amortization of intangibles |  | Impact of purchase accounting |  | Transaction-related expenses |  | Stock-based compensation expense |  | Other corporate expenses |  | Fair value adjustments on equity investments |  | Aggregate adjustment for income taxes |  | Non-GAAP |
| Net income | $ | 182 |  |  | 855 |  |  | 63 |  |  | (44) |  |  | 370 |  |  | 95 |  |  | (94) |  |  | (284) |  |  | $ | 1,143 |  |
| Less: Net income attributable to non-controlling interests (a) | 39 |  |  | 60 |  |  | 3 |  |  | 7 |  |  | 54 |  |  | — |  |  | (1) |  |  | (35) |  |  | 127 |  |
| Net income attributable to Dell Technologies Inc. - basic | 143 |  |  | 795 |  |  | 60 |  |  | (51) |  |  | 316 |  |  | 95 |  |  | (93) |  |  | (249) |  |  | 1,016 |  |
| Incremental dilution from VMware, Inc. attributable to Dell Technologies Inc. (b) | (2) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (4) |  |
| Net income attributable to Dell Technologies Inc. - diluted | $ | 141 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 1,012 |  |
| Earnings per share - basic | $ | 0.19 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 1.37 |  |
| Earnings per share - diluted | $ | 0.19 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 1.34 |  |
| Weighted-average shares outstanding - basic | 740 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 740 |  |
| Weighted-average shares outstanding - diluted | 755 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 755 |  |

[0001571996-21-000019:8k_2_02:119]
_________________

[0001571996-21-000019:8k_2_02:120]
(a)     Net income attributable to non-controlling interests is calculated by multiplying the minority interest percentage of VMware, Inc. and SecureWorks Corp. by their respective non-GAAP net income adjustments for the period presented.

[0001571996-21-000019:8k_2_02:121]
(b)     Incremental dilution from VMware, Inc. attributable to Dell Technologies Inc. represents the impact of VMware, Inc.’s dilutive securities on the diluted earnings per share of Dell Technologies Inc. and is calculated by multiplying the difference between VMware, Inc.’s basic and diluted earnings per share by the number of shares of VMware, Inc. common stock held by Dell Technologies Inc.
