# DELL notes — 0001571996-24-000143


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001571996-24-000143:notes:1]
Basis of Presentation — The accompanying unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes filed with the U.S. Securities and Exchange Commission (“SEC”) in the Company’s Annual Report on Form 10-K for the fiscal year ended February 2, 2024. These Condensed Consolidated Financial Statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“GAAP”). In the opinion of management, the accompanying Condensed Consolidated Financial Statements reflect all adjustments of a normal recurring nature considered necessary to fairly state the financial position of the Company as of November 1, 2024 and February 2, 2024 and the results of its operations, corresponding comprehensive income, changes in stockholders’ equity (deficit) for the three and nine months ended November 1, 2024 and November 3, 2023, and its cash flows for the nine months ended November 1, 2024 and November 3, 2023.

[0001571996-24-000143:notes:2]
The preparation of financial statements in accordance with GAAP requires management to make estimates and assumptions that affect the amounts reported in the Condensed Consolidated Financial Statements and the accompanying Notes. Actual results could differ materially from those estimates. The results of its operations, corresponding comprehensive income, and changes in stockholders’ equity (deficit) for the three and nine months ended November 1, 2024 and November 3, 2023, and its cash flows for the nine months ended November 1, 2024 and November 3, 2023 are not necessarily indicative of the results to be expected for the full fiscal year or for any other fiscal period.
The Company’s fiscal year is the 52- or 53-week period ending on the Friday nearest January 31. Both the fiscal year ended February 2, 2024 (“Fiscal 2024”) and the fiscal year ending January 31, 2025 (“Fiscal 2025”) are 52-week periods.


## us-gaap:ConsolidationPolicyTextBlock

[0001571996-24-000143:notes:3]
[same as prior period, unchanged from 0001571996-24-000090:notes:3]


## us-gaap:ScheduleOfDisposalGroupsIncludingDiscontinuedOperationsIncomeStatementBalanceSheetAndAdditionalDisclosuresTextBlock

[0001571996-24-000143:notes:4]
The following table presents the major classes of assets and liabilities as of November 1, 2024 related to Secureworks, which were classified as held for sale as of the date indicated:

[0001571996-24-000143:notes:5]
|  | November 1, 2024 |
|  | (in millions) |
| ASSETS |
| Current assets: |  |
| Cash and cash equivalents | $ | 53 |  |
| Accounts receivable, net | 47 |  |
| Other current assets | 15 |  |
| Total current assets | 115 |  |
| Goodwill | 427 |  |
| Intangible assets, net | 63 |  |
| Other non-current assets | 57 |  |
| Total assets | $ | 662 |  |
| LIABILITIES |
| Current liabilities: |  |
| Accrued and other | $ | 58 |  |
| Short-term deferred revenue | 125 |  |
| Total current liabilities | 183 |  |
| Other non-current liabilities | 28 |  |
| Total liabilities | $ | 211 |  |


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001571996-24-000143:notes:6]
Recently Issued Accounting Pronouncements

[0001571996-24-000143:notes:7]
Expense Disaggregation Disclosures — In November 2024, the Financial Accounting Standards Board (“FASB”) issued guidance to improve disclosures about a public entity’s expenses by requiring disclosure of additional information about the types of expenses commonly presented in the financial statements on an annual and interim basis. Public entities must adopt the new guidance for fiscal years beginning after December 15, 2026, with early adoption permitted. Upon adoption, the guidance can be applied prospectively or retrospectively. Adoption of this new guidance will result in increased disclosures in the Notes to the Consolidated Financial Statements.

[0001571996-24-000143:notes:8]
Income Taxes — In December 2023, the FASB issued guidance which requires companies to provide disaggregated income tax disclosures within the income tax rate reconciliation and income taxes paid. Public entities must adopt the new guidance for fiscal years beginning after December 15, 2024, with early adoption permitted. Upon adoption, the guidance can be applied prospectively or retrospectively. Adoption of this new guidance will result in increased disclosures in the Notes to the Consolidated Financial Statements.

[0001571996-24-000143:notes:9]
Segment Reporting — In November 2023, the FASB issued guidance to improve disclosures about a public entity’s reportable segments by requiring disclosure of additional information about a reportable segment’s expenses on an annual and interim basis. Public entities must adopt the new guidance for fiscal years beginning after December 15, 2023, with early adoption permitted. Upon adoption, the guidance is required to be applied retrospectively to all prior periods presented in the financial statements. Adoption of this new guidance will result in increased disclosures in the Notes to the Consolidated Financial Statements.


## us-gaap:FairValueDisclosuresTextBlock

[0001571996-24-000143:notes:10]
[same as prior period, unchanged from 0001571996-24-000090:notes:7]

[0001571996-24-000143:notes:11]
|  | November 1, 2024 |  | February 2, 2024 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | Quoted Prices in Active Markets for Identical Assets |  | Significant Other Observable Inputs |  | Significant Unobservable Inputs |  |  |  | Quoted Prices in Active Markets for Identical Assets |  | Significant Other Observable Inputs |  | Significant Unobservable Inputs |  |  |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 2,011 |  |  | $ | — |  |  | $ | — |  |  | $ | 2,011 |  |  | $ | 3,170 |  |  | $ | — |  |  | $ | — |  |  | $ | 3,170 |  |
| Marketable equity and other securities | 6 |  |  | — |  |  | — |  |  | 6 |  |  | 10 |  |  | — |  |  | — |  |  | 10 |  |
| Derivative instruments | — |  |  | 124 |  |  | — |  |  | 124 |  |  | — |  |  | 104 |  |  | — |  |  | 104 |  |
| Total assets | $ | 2,017 |  |  | $ | 124 |  |  | $ | — |  |  | $ | 2,141 |  |  | $ | 3,180 |  |  | $ | 104 |  |  | $ | — |  |  | $ | 3,284 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative instruments | $ | — |  |  | $ | 101 |  |  | $ | — |  |  | $ | 101 |  |  | $ | — |  |  | $ | 84 |  |  | $ | — |  |  | $ | 84 |  |
| Total liabilities | $ | — |  |  | $ | 101 |  |  | $ | — |  |  | $ | 101 |  |  | $ | — |  |  | $ | 84 |  |  | $ | — |  |  | $ | 84 |  |

[0001571996-24-000143:notes:12]
[same as prior period, unchanged from 0001571996-24-000090:notes:9]

[0001571996-24-000143:notes:13]
Money Market Funds — The Company’s investment in money market funds that are classified as cash equivalents hold underlying investments with a weighted average maturity of 90 days or less and are recognized at fair value. The valuations of these securities are based on quoted prices in active markets for identical assets, when available, or pricing models whereby all significant inputs are observable or can be derived from, or corroborated by, observable market data. The Company reviews security pricing and assesses money market fund liquidity on a quarterly basis. As of November 1, 2024, the Company’s portfolio had no material exposure to money market funds with a fluctuating net asset value.

[0001571996-24-000143:notes:14]
[same as prior period, unchanged from 0001571996-24-000090:notes:11]

[0001571996-24-000143:notes:15]
[same as prior period, unchanged from 0001571996-24-000090:notes:12]

[0001571996-24-000143:notes:16]
Deferred Compensation Plans — The Company offers deferred compensation plans for eligible employees which allow participants to defer a portion of their compensation. Assets and liabilities associated with the plans are measured at fair value using Level 1 inputs. Assets were the same as liabilities associated with the plans at approximately $243 million and $214 million as of November 1, 2024 and February 2, 2024, respectively, and are included in other assets and other liabilities on the Condensed Consolidated Statements of Financial Position. The net impact on the Condensed Consolidated Statements of Income is not material since changes in the fair value of the assets substantially offset changes in the fair value of the liabilities. As such, assets and liabilities associated with these plans have not been included in the recurring fair value table above.

[0001571996-24-000143:notes:17]
Assets and Liabilities Measured at Fair Value on a Nonrecurring Basis — Certain assets are measured at fair value on a nonrecurring basis and therefore are not included in the recurring fair value table above. These assets consist primarily of financial assets such as the Company’s fixed income debt securities and strategic investments in non-marketable equity and other securities and non-financial assets such as goodwill and intangible assets.

[0001571996-24-000143:notes:18]
Fixed income debt securities are recorded at amortized cost and approximate fair value. The fair value of fixed income debt securities is determined based on observable market prices in a less active market or based on valuation methodologies using observable inputs. If measured at fair value in the Condensed Consolidated Statements of Financial Position, these securities would generally be classified as Level 2 in the fair value hierarchy. See Note 3 of the Notes to the Condensed Consolidated Financial Statements for additional information about the Company’s fixed income debt securities.

[0001571996-24-000143:notes:19]
Strategic investments in non-marketable equity and other securities and certain non-financial assets such as goodwill and intangibles are measured at fair value only if they are deemed to be impaired or when there is an adjustment from observable price changes in the current period. If measured at fair value in the Condensed Consolidated Statements of Financial Position, these securities would generally be classified as Level 3 in the fair value hierarchy. See Note 3 and Note 8 of the Notes to the Condensed Consolidated Financial Statements for additional information about the Company’s investments and goodwill and intangible assets, respectively.

[0001571996-24-000143:notes:20]
[same as prior period, unchanged from 0001571996-24-000090:notes:15]

[0001571996-24-000143:notes:21]
|  | November 1, 2024 |  | February 2, 2024 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Notes | $ | 15.0 |  |  | $ | 15.1 |  |  | $ | 15.5 |  |  | $ | 15.8 |  |
| Legacy Notes | $ | 0.9 |  |  | $ | 1.0 |  |  | $ | 0.9 |  |  | $ | 1.0 |  |
| DFS Debt | $ | 9.2 |  |  | $ | 8.9 |  |  | $ | 9.5 |  |  | $ | 9.1 |  |

[0001571996-24-000143:notes:22]
[same as prior period, unchanged from 0001571996-24-000090:notes:17]


## us-gaap:InvestmentTextBlock

[0001571996-24-000143:notes:23]
[same as prior period, unchanged from 0001571996-24-000090:notes:18]

[0001571996-24-000143:notes:24]
Total investments were $1.4 billion as of November 1, 2024 and $1.6 billion as of February 2, 2024.

[0001571996-24-000143:notes:25]
[same as prior period, unchanged from 0001571996-24-000090:notes:20]

[0001571996-24-000143:notes:26]
Equity and other securities include strategic investments in marketable and non-marketable securities. Investments in marketable securities are measured at fair value on a recurring basis. Investments in non-marketable equity and other securities represent early-stage companies without readily determinable fair values. The Company has elected to apply the measurement alternative for non-marketable securities. Under the alternative, the Company measures investments without readily determinable fair values at cost, less impairment, adjusted for observable price changes. The Company makes a separate election to use the alternative for each eligible investment and is required to reassess at each reporting period whether an investment qualifies for the alternative. In evaluating these investments for impairment or observable price changes, the Company uses inputs including pre- and post-money valuations of recent financing events and the impact of those events on its fully diluted ownership percentages, as well as other available information regarding the issuer’s historical and forecasted performance.

[0001571996-24-000143:notes:27]
[same as prior period, unchanged from 0001571996-24-000090:notes:22]

[0001571996-24-000143:notes:28]
[same as prior period, unchanged from 0001571996-24-000090:notes:23]

[0001571996-24-000143:notes:29]
|  | November 1, 2024 |  | February 2, 2024 |
|  | Cost |  | Unrealized Gain |  | Unrealized Loss |  | Carrying Value |  | Cost |  | Unrealized Gain |  | Unrealized Loss |  | Carrying Value |
|  | (in millions) |
| Marketable | $ | 12 |  |  | $ | 26 |  |  | $ | (32) |  |  | $ | 6 |  |  | $ | 12 |  |  | $ | 24 |  |  | $ | (26) |  |  | $ | 10 |  |
| Non-marketable | 702 |  |  | 863 |  |  | (260) |  |  | 1,305 |  |  | 732 |  |  | 1,015 |  |  | (454) |  |  | 1,293 |  |
| Total equity and other securities | $ | 714 |  |  | $ | 889 |  |  | $ | (292) |  |  | $ | 1,311 |  |  | $ | 744 |  |  | $ | 1,039 |  |  | $ | (480) |  |  | $ | 1,303 |  |

[0001571996-24-000143:notes:30]
[same as prior period, unchanged from 0001571996-24-000090:notes:25]

[0001571996-24-000143:notes:31]
[same as prior period, unchanged from 0001571996-24-000090:notes:26]

[0001571996-24-000143:notes:32]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 1, 2024 |  | November 3, 2023 |  | November 1, 2024 |  | November 3, 2023 |
|  | (in millions) |
| Marketable securities: |  |  |  |  |  |  |  |
| Unrealized gain | $ | 3 |  |  | $ | — |  |  | $ | 3 |  |  | $ | 1 |  |
| Unrealized loss | — |  |  | — |  |  | (6) |  |  | (23) |  |
| Net unrealized gain (loss) | 3 |  |  | — |  |  | (3) |  |  | (22) |  |
| Non-marketable securities: |  |  |  |  |  |  |  |
| Unrealized gain | 7 |  |  | 6 |  |  | 7 |  |  | 15 |  |
| Unrealized loss | — |  |  | (3) |  |  | (31) |  |  | (49) |  |
| Net unrealized gain (loss) (a) (b) | 7 |  |  | 3 |  |  | (24) |  |  | (34) |  |
| Net unrealized gain (loss) on equity and other securities | $ | 10 |  |  | $ | 3 |  |  | $ | (27) |  |  | $ | (56) |  |

[0001571996-24-000143:notes:33]
[same as prior period, unchanged from 0001571996-24-000090:notes:28]

[0001571996-24-000143:notes:34]
(a)    For the three months ended November 1, 2024 and November 3, 2023, net gains on non-marketable securities are primarily due to upward adjustments for observable price changes. For the three months ended November 3, 2023, these were partially offset by losses due to impairments.

[0001571996-24-000143:notes:35]
(b)    For the nine months ended November 1, 2024, net unrealized losses on non-marketable securities are primarily attributable to downward adjustments for observable price changes. For the nine months ended November 3, 2023, net unrealized losses on non-marketable securities were primarily attributable to impairments.

[0001571996-24-000143:notes:36]
[same as prior period, unchanged from 0001571996-24-000090:notes:31]

[0001571996-24-000143:notes:37]
As of November 1, 2024 and February 2, 2024, the Company held fixed income debt securities of $61 million and $301 million, respectively, which it intends to hold to maturity. These investments are recorded at amortized cost and approximate fair value. As of November 1, 2024, the Company held $60 million in fixed income debt securities which will mature within one year and $1 million in fixed income debt securities which will mature within five years.


## dell:CreditLossFinancialInstrumentLeasesDebtVariableInterestEntitiesAndCustomerReceivablesSalesTextBlock

[0001571996-24-000143:notes:38]
FINANCIAL SERVICES
The Company offers or arranges various financing options and alternative payment structures for its customers globally. Alternative payment structures consist of various flexible consumption models, including utility, subscription, and as-a-Service models.

[0001571996-24-000143:notes:39]
Financing options are offered to the Company’s customers primarily through Dell Financial Services and its affiliates (“DFS”). The Company also arranges financing for some of its customers in various countries where DFS does not currently operate as a captive enterprise. The key activities of DFS include originating, collecting, and servicing customer financing arrangements primarily related to the purchase or use of Dell Technologies products and services. In some cases, DFS also offers financing for the purchase of third-party technology products that complement the Dell Technologies portfolio of products and services. New financing originations were $1.6 billion and $1.8 billion for the three months ended November 1, 2024 and November 3, 2023, respectively, and $5.9 billion and $6.0 billion for the nine months ended November 1, 2024 and November 3, 2023, respectively.

[0001571996-24-000143:notes:40]
The Company’s lease and loan arrangements with customers are aggregated primarily into the following categories:

[0001571996-24-000143:notes:41]
Fixed-term leases and loans — The Company enters into financing arrangements with customers who seek lease financing for equipment. DFS leases are generally classified as sales-type leases or operating leases. Leases with business customers have fixed terms of generally two to four years.

[0001571996-24-000143:notes:42]
The Company also offers fixed-term loans to qualified small businesses, large commercial accounts, governmental organizations, educational entities, and certain individual consumer customers. These loans are repaid in equal payments including interest and have defined terms of generally three to five years. The fair value of the fixed-term loan portfolio is determined using market observable inputs. The carrying value of these loans approximates fair value.

[0001571996-24-000143:notes:43]
Revolving loans — The Company primarily offers revolving loans to small and medium-sized commercial customers. Revolving loans provide qualified customers with a revolving credit line for the purchase of products and services offered by Dell Technologies. Revolving loans in the United States bear interest at a variable annual percentage rate that is tied to the prime rate. Based on historical payment patterns, revolving loan transactions are typically repaid within twelve months on average. Due to the short-term nature of the revolving loan portfolio, the carrying value of the portfolio approximates fair value.

[0001571996-24-000143:notes:44]
Prior to the sale of the U.S. consumer revolving customer receivables portfolio on October 4, 2023, described in Note 1 of the Notes to the Condensed Consolidated Financial Statements, the Company offered private label credit financing under the Dell Preferred Account (“DPA”) program. The DPA product was primarily offered to individual consumer customers. During the three months ended November 1, 2024, the Company discontinued remaining offerings under the revolving loan portfolio. The Company will support existing customer arrangements as well as transition these customers to fixed-term offerings.

[0001571996-24-000143:notes:45]
Flexible consumption models, as defined above, further enable the Company to offer its customers the option to pay over time to provide them with financial and operational flexibility. Such models may result in identification of embedded lease arrangements that lead to the recognition of operating or sales-type leases.

[0001571996-24-000143:notes:46]
Financing Receivables

[0001571996-24-000143:notes:47]
The following table presents the components of the Company’s financing receivables segregated by portfolio segment as of the dates indicated:

[0001571996-24-000143:notes:48]
|  | November 1, 2024 |  | February 2, 2024 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Financing receivables, net: |  |  |  |  |  |  |  |  |  |  |  |
| Customer receivables, gross (a) | $ | 126 |  |  | $ | 10,699 |  |  | $ | 10,825 |  |  | $ | 173 |  |  | $ | 10,360 |  |  | $ | 10,533 |  |
| Allowances for losses | (7) |  |  | (137) |  |  | (144) |  |  | (9) |  |  | (161) |  |  | (170) |  |
| Customer receivables, net | 119 |  |  | 10,562 |  |  | 10,681 |  |  | 164 |  |  | 10,199 |  |  | 10,363 |  |
| Residual interest | — |  |  | 169 |  |  | 169 |  |  | — |  |  | 157 |  |  | 157 |  |
| Financing receivables, net | $ | 119 |  |  | $ | 10,731 |  |  | $ | 10,850 |  |  | $ | 164 |  |  | $ | 10,356 |  |  | $ | 10,520 |  |
| Short-term | $ | 119 |  |  | $ | 4,882 |  |  | $ | 5,001 |  |  | $ | 164 |  |  | $ | 4,479 |  |  | $ | 4,643 |  |
| Long-term | $ | — |  |  | $ | 5,849 |  |  | $ | 5,849 |  |  | $ | — |  |  | $ | 5,877 |  |  | $ | 5,877 |  |

[0001571996-24-000143:notes:49]
(a)    Customer receivables, gross include amounts due from customers under revolving loans, fixed-term loans, fixed-term leases, and accrued interest.

[0001571996-24-000143:notes:50]
The following tables present the changes in allowance for financing receivable losses for the periods indicated:

[0001571996-24-000143:notes:51]
|  | Three Months Ended |
|  | November 1, 2024 |  | November 3, 2023 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |  |  |  |  |  |  |  |
| Balances at beginning of period | $ | 8 |  |  | $ | 158 |  |  | $ | 166 |  |  | $ | 9 |  |  | $ | 140 |  |  | $ | 149 |  |
| Charge-offs, net of recoveries | (3) |  |  | (35) |  |  | (38) |  |  | (4) |  |  | (3) |  |  | (7) |  |
| Provision charged to income statement | 2 |  |  | 14 |  |  | 16 |  |  | 4 |  |  | 7 |  |  | 11 |  |
| Balances at end of period | $ | 7 |  |  | $ | 137 |  |  | $ | 144 |  |  | $ | 9 |  |  | $ | 144 |  |  | $ | 153 |  |

[0001571996-24-000143:notes:52]
|  | Nine Months Ended |
|  | November 1, 2024 |  | November 3, 2023 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |  |  |  |  |  |  |  |
| Balances at beginning of period | $ | 9 |  |  | $ | 161 |  |  | $ | 170 |  |  | $ | 88 |  |  | $ | 113 |  |  | $ | 201 |  |
| Charge-offs, net of recoveries | (9) |  |  | (56) |  |  | (65) |  |  | (37) |  |  | (5) |  |  | (42) |  |
| Provision charged to income statement | 7 |  |  | 32 |  |  | 39 |  |  | 32 |  |  | 36 |  |  | 68 |  |
| Other (a) | — |  |  | — |  |  | — |  |  | (74) |  |  | — |  |  | (74) |  |
| Balances at end of period | $ | 7 |  |  | $ | 137 |  |  | $ | 144 |  |  | $ | 9 |  |  | $ | 144 |  |  | $ | 153 |  |

[0001571996-24-000143:notes:53]
(a)    Other represents the derecognition of the allowance for financing receivable losses related to the sale of the U.S. consumer revolving customer receivables portfolio described in Note 1 of the Notes to the Condensed Consolidated Financial Statements.

[0001571996-24-000143:notes:54]
The Company recognizes an allowance for financing receivable losses, including both the lease receivable and unguaranteed residual, in an amount equal to the expected losses net of recoveries. The allowance for financing receivable losses on the lease receivable is determined based on various factors, including lifetime expected losses determined using macroeconomic forecast assumptions and management judgments applicable to and through the expected life of the portfolios as well as past due receivables, receivable type, and customer risk profile. The Company continues to monitor broader economic indicators and their potential impact on future credit loss performance.

[0001571996-24-000143:notes:55]
Aging

[0001571996-24-000143:notes:56]
The following table presents the aging of the Company’s customer financing receivables, gross, including accrued interest, segregated by class, as of the dates indicated:

[0001571996-24-000143:notes:57]
|  | November 1, 2024 |  | February 2, 2024 |
|  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |
|  | (in millions) |
| Revolving | $ | 107 |  |  | $ | 15 |  |  | $ | 4 |  |  | $ | 126 |  |  | $ | 151 |  |  | $ | 17 |  |  | $ | 5 |  |  | $ | 173 |  |
| Fixed-term | 10,053 |  |  | 488 |  |  | 158 |  |  | 10,699 |  |  | 9,345 |  |  | 889 |  |  | 126 |  |  | 10,360 |  |
| Total customer receivables, gross | $ | 10,160 |  |  | $ | 503 |  |  | $ | 162 |  |  | $ | 10,825 |  |  | $ | 9,496 |  |  | $ | 906 |  |  | $ | 131 |  |  | $ | 10,533 |  |

[0001571996-24-000143:notes:58]
Aging is likely to fluctuate as a result of the variability in volume of large transactions entered into over the period, and the administrative processes that accompany those transactions. Aging is also impacted by the timing of the Company’s fiscal period end date relative to calendar month-end customer payment due dates. As a result of these factors, fluctuations in aging from period to period do not necessarily indicate a material change in the collectibility of the portfolio.

[0001571996-24-000143:notes:59]
Fixed-term customer receivables are placed on non-accrual status if principal or interest is past due and considered delinquent, or if there is concern about the collectibility of a specific customer receivable. The receivables identified as doubtful for collectibility may be classified as current for aging purposes. Aged revolving portfolio customer receivables identified as delinquent are charged off.

[0001571996-24-000143:notes:60]
Credit Quality

[0001571996-24-000143:notes:61]
The following tables present customer receivables, gross, including accrued interest, by credit quality indicator, segregated by class, as of the dates indicated:

[0001571996-24-000143:notes:62]
|  | November 1, 2024 |
|  | Fixed-term — Fiscal Year of Origination |  |  |  |  |
|  | 2025 |  | 2024 |  | 2023 |  | 2022 |  | 2021 |  | Years Prior |  | Revolving |  | Total |
|  | (in millions) |
| Higher | $ | 1,555 |  |  | $ | 2,440 |  |  | $ | 1,560 |  |  | $ | 515 |  |  | $ | 158 |  |  | $ | 14 |  |  | $ | 25 |  |  | $ | 6,267 |  |
| Mid | 733 |  |  | 710 |  |  | 432 |  |  | 122 |  |  | 22 |  |  | 5 |  |  | 37 |  |  | 2,061 |  |
| Lower | 1,505 |  |  | 465 |  |  | 314 |  |  | 88 |  |  | 58 |  |  | 3 |  |  | 64 |  |  | 2,497 |  |
| Total | $ | 3,793 |  |  | $ | 3,615 |  |  | $ | 2,306 |  |  | $ | 725 |  |  | $ | 238 |  |  | $ | 22 |  |  | $ | 126 |  |  | $ | 10,825 |  |

[0001571996-24-000143:notes:63]
|  | February 2, 2024 |
|  | Fixed-term — Fiscal Year of Origination |  |  |  |  |  |  |
|  | 2024 |  | 2023 |  | 2022 |  | 2021 |  | 2020 |  | Years Prior |  |  |  | Revolving |  | Total |
|  | (in millions) |
| Higher | $ | 3,261 |  |  | $ | 1,979 |  |  | $ | 833 |  |  | $ | 345 |  |  | $ | 64 |  |  | $ | — |  |  |  |  | $ | 47 |  |  | $ | 6,529 |  |
| Mid | 1,111 |  |  | 911 |  |  | 290 |  |  | 86 |  |  | 19 |  |  | — |  |  |  |  | 50 |  |  | 2,467 |  |
| Lower | 703 |  |  | 469 |  |  | 187 |  |  | 80 |  |  | 21 |  |  | 1 |  |  |  |  | 76 |  |  | 1,537 |  |
| Total | $ | 5,075 |  |  | $ | 3,359 |  |  | $ | 1,310 |  |  | $ | 511 |  |  | $ | 104 |  |  | $ | 1 |  |  |  |  | $ | 173 |  |  | $ | 10,533 |  |

[0001571996-24-000143:notes:64]
The categories shown in the tables above segregate customer receivables based on the relative degrees of credit risk. Credit quality indicators for revolving and fixed-term accounts are generally updated on a periodic basis.

[0001571996-24-000143:notes:65]
An internal grading system is utilized that assigns a credit level score based on a number of considerations, including liquidity, operating performance, and industry outlook. The grading criteria and classifications for the fixed-term products differ from those for the revolving products as loss experience varies between these product and customer groups. The credit quality categories cannot be compared between the different classes as loss experience varies substantially between the classes.

[0001571996-24-000143:notes:66]
Leases

[0001571996-24-000143:notes:67]
The following table presents amounts included in the Condensed Consolidated Statements of Income related to sales-type lease activity for the periods indicated:

[0001571996-24-000143:notes:68]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 1, 2024 |  | November 3, 2023 |  | November 1, 2024 |  | November 3, 2023 |  |  |
|  | (in millions) |
| Net revenue — products | $ | 401 |  |  | $ | 227 |  |  | $ | 1,751 |  |  | $ | 766 |  |  |  |
| Cost of net revenue — products | 333 |  |  | 176 |  |  | 1,488 |  |  | 564 |  |  |  |
| Gross margin — products | $ | 68 |  |  | $ | 51 |  |  | $ | 263 |  |  | $ | 202 |  |  |  |

[0001571996-24-000143:notes:69]
The following table presents the future maturity of the Company’s fixed-term customer leases and associated financing payments, and reconciles the undiscounted cash flows to the customer receivables, gross recognized on the Condensed Consolidated Statements of Financial Position as of the date indicated:

[0001571996-24-000143:notes:70]
|  | November 1, 2024 |
|  | (in millions) |
| Fiscal 2025 (remaining three months) | $ | 871 |  |
| Fiscal 2026 | 3,114 |  |
| Fiscal 2027 | 2,085 |  |
| Fiscal 2028 | 793 |  |
| Fiscal 2029 and beyond | 454 |  |
| Total undiscounted cash flows | 7,317 |  |
| Fixed-term loans | 4,466 |  |
| Revolving loans | 126 |  |
| Less: Unearned income | (1,084) |  |
| Total customer receivables, gross | $ | 10,825 |  |

[0001571996-24-000143:notes:71]
Operating Leases

[0001571996-24-000143:notes:72]
The Company’s operating leases primarily consist of DFS captive fixed-term leases and contractually committed embedded leases identified within flexible consumption arrangements.

[0001571996-24-000143:notes:73]
The following table presents the components of the Company’s operating lease portfolio included in property, plant, and equipment, net as of the dates indicated:

[0001571996-24-000143:notes:74]
|  | November 1, 2024 |  | February 2, 2024 |
|  | (in millions) |
| Equipment under operating lease, gross | $ | 4,188 |  |  | $ | 4,002 |  |
| Less: Accumulated depreciation | (1,971) |  |  | (1,800) |  |
| Equipment under operating lease, net | $ | 2,217 |  |  | $ | 2,202 |  |

[0001571996-24-000143:notes:75]
The following table presents operating lease income related to lease payments and depreciation expense for the Company’s operating lease portfolio for the periods indicated:

[0001571996-24-000143:notes:76]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 1, 2024 |  | November 3, 2023 |  | November 1, 2024 |  | November 3, 2023 |  |  |
|  | (in millions) |
| Income related to lease payments | $ | 372 |  |  | $ | 341 |  |  | $ | 1,090 |  |  | $ | 992 |  |  |  |
| Depreciation expense | $ | 247 |  |  | $ | 234 |  |  | $ | 732 |  |  | $ | 703 |  |  |  |

[0001571996-24-000143:notes:77]
The following table presents the future payments to be received by the Company in operating lease contracts as of the date indicated:

[0001571996-24-000143:notes:78]
|  | November 1, 2024 |
|  | (in millions) |
| Fiscal 2025 (remaining three months) | $ | 347 |  |
| Fiscal 2026 | 1,079 |  |
| Fiscal 2027 | 665 |  |
| Fiscal 2028 | 316 |  |
| Fiscal 2029 and beyond | 121 |  |
| Total | $ | 2,528 |  |

[0001571996-24-000143:notes:79]
DFS Debt

[0001571996-24-000143:notes:80]
The Company maintains programs that facilitate the funding of leases, loans, and other alternative payment structures in the capital markets. The majority of DFS debt is non-recourse to Dell Technologies and represents borrowings under securitization programs and structured financing programs for which the Company’s risk of loss is limited to transferred lease and loan payments and associated equipment.

[0001571996-24-000143:notes:81]
The following table presents DFS debt as of the dates indicated and excludes the allocated portion of the Company’s other borrowings, which represents the additional amount considered to fund the DFS business:

[0001571996-24-000143:notes:82]
|  | November 1, 2024 |  | February 2, 2024 |
| DFS debt | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing facility | $ | 2,753 |  |  | $ | 2,730 |  |
| Fixed-term securitization offerings | 3,264 |  |  | 3,157 |  |
| Other | — |  |  | 28 |  |
| Total DFS U.S. debt, principal amount | 6,017 |  |  | 5,915 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 723 |  |  | 761 |  |
| Other borrowings | 798 |  |  | 935 |  |
| Note payable | — |  |  | 250 |  |
| Dell Bank senior unsecured eurobonds | 1,633 |  |  | 1,631 |  |
| Total DFS international debt, principal amount | 3,154 |  |  | 3,577 |  |
| Total DFS debt, principal amount | $ | 9,171 |  |  | $ | 9,492 |  |
| Total short-term DFS debt | $ | 5,582 |  |  | $ | 5,863 |  |
| Total long-term DFS debt | $ | 3,589 |  |  | $ | 3,629 |  |

[0001571996-24-000143:notes:83]
DFS U.S. Debt

[0001571996-24-000143:notes:84]
Asset-Based Financing Facility — The Company maintains an asset-based financing facility in the United States, which is a revolving facility for fixed-term leases and loans. This debt is collateralized solely by the U.S. lease and loan payments and associated equipment in the facility. The asset-based financing facility consists of two tranches, with effective dates through July 7, 2025 and July 7, 2026, respectively. As of November 1, 2024, the total debt capacity related to the asset-based financing facility was $5.0 billion. The debt has a variable interest rate, and the duration of the debt is based on the terms of the underlying lease and loan payment streams. The Company enters into interest rate swap agreements to economically convert a portion of this debt from a floating rate to a fixed rate. See Note 7 of the Notes to the Condensed Consolidated Financial Statements for additional information about the Company’s interest rate swaps.

[0001571996-24-000143:notes:85]
The asset-based financing facility contains standard structural features related to the performance of the funded receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements. In the event one or more of these criteria are not met and the Company is unable to restructure the facility, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed. As of November 1, 2024, these criteria were met.

[0001571996-24-000143:notes:86]
Fixed-Term Securitization Offerings — The Company periodically issues asset-backed debt securities under fixed-term securitization programs to private investors. The asset-backed debt securities are collateralized solely by the U.S. fixed-term lease and loan payments and associated equipment, which are held by Special Purpose Entities (“SPEs”), as discussed below. The interest rate on these securities is fixed and ranges from 4.14% to 6.80% per annum as of November 1, 2024, and the duration of these securities is based on the terms of the underlying lease and loan payment streams.

[0001571996-24-000143:notes:87]
DFS International Debt

[0001571996-24-000143:notes:88]
Securitization Facility — The Company maintains a securitization facility in Europe for fixed-term leases and loans. The debt under this facility has a variable interest rate, and the duration of the debt is based on the terms of the underlying lease and loan payment streams. This facility is effective through December 23, 2024 and had a total debt capacity of $871 million as of November 1, 2024.

[0001571996-24-000143:notes:89]
The securitization facility contains standard structural features related to the performance of the securitized receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements. In the event one or more of these criteria are not met and the Company is unable to restructure the program, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed. As of November 1, 2024, these criteria were met.

[0001571996-24-000143:notes:90]
Other Borrowings — In connection with the Company’s international financing operations, the Company has entered into revolving structured financing debt programs related to its fixed-term lease and loan products sold in Canada, Europe, Australia, New Zealand, the Middle East, and Singapore. The debt under these programs has a variable interest rate.

[0001571996-24-000143:notes:91]
The duration of the debt in Canada, Europe, Australia, New Zealand, and the Middle East is based on the terms of the underlying lease and loan payment streams. These facilities are collateralized solely by the lease and loan payments and associated equipment in their respective region or country. The Canadian facility had a total debt capacity of $323 million as of November 1, 2024 and is effective through January 16, 2025. The European facility had a total debt capacity of $544 million as of November 1, 2024 and is effective through December 14, 2026. The Australia and New Zealand facility had a total debt capacity of $296 million as of November 1, 2024 and is effective through April 20, 2025. The Middle East facility had a total debt capacity of $150 million as of November 1, 2024 and is effective through March 24, 2025.

[0001571996-24-000143:notes:92]
The Company also has two unsecured Singapore facilities with a total debt capacity of $250 million as of November 1, 2024 that are effective through July 3, 2026 and July 3, 2027, respectively.

[0001571996-24-000143:notes:93]
Note Payable — On May 25, 2022, the Company entered into an unsecured credit agreement which had an aggregate principal amount of $250 million to fund receivables in Mexico. The note bore interest at an annual rate of 4.24% and was paid in full on May 31, 2024.

[0001571996-24-000143:notes:94]
Dell Bank Senior Unsecured Eurobonds — On October 27, 2021, Dell Bank issued 500 million Euro of 0.5% senior unsecured five year eurobonds due October 2026. On October 18, 2022, Dell Bank issued 500 million Euro of 4.5% senior unsecured five year eurobonds due October 2027. On June 13, 2024, Dell Bank issued 500 million Euro of 3.6% senior unsecured five year eurobonds due June 2029. The issuances of the senior unsecured eurobonds support the expansion of the financing operations in Europe.

[0001571996-24-000143:notes:95]
Variable Interest Entities

[0001571996-24-000143:notes:96]
In connection with the asset-based financing facility, securitization facility, and fixed-term securitization offerings discussed above, the Company transfers certain U.S. and European lease and loan payments and associated equipment to SPEs that meet the definition of a VIE and are consolidated, along with the associated debt described above, into the Condensed Consolidated Financial Statements, as the Company is the primary beneficiary of the VIEs. The SPEs are bankruptcy-remote legal entities with separate assets and liabilities. The purpose of the SPEs is to facilitate the funding of customer lease and loan payments and associated equipment in the capital markets.

[0001571996-24-000143:notes:97]
Some of the SPEs have entered into financing arrangements with multi-seller conduits that, in turn, issue asset-backed debt securities in the capital markets. DFS debt outstanding held by the consolidated VIEs is collateralized by the lease and loan payments and associated equipment. The Company’s risk of loss related to securitized receivables is limited to the amount by which the Company’s right to receive collections for assets securitized exceeds the amount required to pay interest, principal, and fees and expenses related to the asset-backed securities. The Company provides credit enhancement to the securitization in the form of over-collateralization.

[0001571996-24-000143:notes:98]
The following table presents the assets and liabilities held by the consolidated VIEs as of the dates indicated, which are included in the Condensed Consolidated Statements of Financial Position:

[0001571996-24-000143:notes:99]
|  | November 1, 2024 |  | February 2, 2024 |
|  | (in millions) |
| Assets held by consolidated VIEs |  |  |  |
| Other current assets | $ | 123 |  |  | $ | 136 |  |
| Financing receivables, net of allowance |  |  |  |
| Short-term | $ | 3,354 |  |  | $ | 3,314 |  |
| Long-term | $ | 2,989 |  |  | $ | 2,747 |  |
| Property, plant, and equipment, net | $ | 1,022 |  |  | $ | 1,081 |  |
| Liabilities held by consolidated VIEs |  |  |  |
| Debt, net of unamortized debt issuance costs |  |  |  |
| Short-term | $ | 4,888 |  |  | $ | 4,450 |  |
| Long-term | $ | 1,838 |  |  | $ | 2,184 |  |

[0001571996-24-000143:notes:100]
Lease and loan payments and associated equipment transferred via securitization through SPEs were $1.0 billion and $1.1 billion for the three months ended November 1, 2024 and November 3, 2023, respectively, and $3.0 billion and $3.7 billion for the nine months ended November 1, 2024 and November 3, 2023, respectively.

[0001571996-24-000143:notes:101]
Customer Receivables Sales

[0001571996-24-000143:notes:102]
To manage certain concentrations of customer credit exposure, the Company may sell selected fixed-term customer receivables to unrelated third parties on a periodic basis, without recourse. The amount of customer receivables sold for this purpose was $75 million and $205 million for the nine months ended November 1, 2024 and November 3, 2023, respectively. The Company’s continuing involvement in these customer receivables is primarily limited to servicing arrangements.


## us-gaap:ScheduleOfDebtTableTextBlock

[0001571996-24-000143:notes:103]
The following table summarizes the Company’s outstanding debt as of the dates indicated:

[0001571996-24-000143:notes:104]
|  | November 1, 2024 |  | February 2, 2024 |
|  | (in millions) |
| Senior Notes | $ | 15,073 |  |  | $ | 15,607 |  |
| Legacy Notes | 952 |  |  | 952 |  |
| DFS Debt (Note 4) | 9,171 |  |  | 9,492 |  |
| Other | 56 |  |  | 171 |  |
| Total debt, principal amount | 25,252 |  |  | 26,222 |  |
| Unamortized discount, net of unamortized premium | (113) |  |  | (114) |  |
| Debt issuance costs | (117) |  |  | (114) |  |
| Total debt, carrying value | $ | 25,022 |  |  | $ | 25,994 |  |
| Total short-term debt, carrying value | $ | 5,612 |  |  | $ | 6,982 |  |
| Total long-term debt, carrying value | $ | 19,410 |  |  | $ | 19,012 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0001571996-24-000143:notes:105]
LEASES 
The Company enters into leasing transactions in which the Company is the lessee. These lease contracts are typically classified as operating leases. The Company’s lease contracts are generally for office buildings used to conduct its business, and the determination of whether such contracts contain leases generally does not require significant estimates or judgments. The Company also leases certain global logistics warehouses, employee vehicles, and equipment. As of November 1, 2024, the remaining terms of the Company’s leases range from one month to approximately eleven years. As of November 1, 2024 and February 2, 2024, there were no material finance leases in which the Company was a lessee.

[0001571996-24-000143:notes:106]
[same as prior period, unchanged from 0001571996-24-000090:notes:101]

[0001571996-24-000143:notes:107]
[same as prior period, unchanged from 0001571996-24-000090:notes:102]

[0001571996-24-000143:notes:108]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 1, 2024 |  | November 3, 2023 |  | November 1, 2024 |  | November 3, 2023 |
|  | (in millions) |
| Operating lease costs | $ | 75 |  |  | $ | 79 |  |  | $ | 221 |  |  | $ | 221 |  |
| Variable costs | 15 |  |  | 19 |  |  | 48 |  |  | 62 |  |
| Total lease costs | $ | 90 |  |  | $ | 98 |  |  | $ | 269 |  |  | $ | 283 |  |

[0001571996-24-000143:notes:109]
During the nine months ended November 1, 2024 and November 3, 2023, sublease income, finance lease costs, and short-term lease costs were immaterial.

[0001571996-24-000143:notes:110]
[same as prior period, unchanged from 0001571996-24-000090:notes:105]

[0001571996-24-000143:notes:111]
|  | Classification |  | November 1, 2024 |  | February 2, 2024 |  |  |
|  |  |  | (in millions, except for term and discount rate) |
| Operating lease right-of-use assets | Other non-current assets |  | $ | 700 |  | $ | 707 |  |  |
| Current operating lease liabilities | Accrued and other current liabilities |  | $ | 242 |  | $ | 253 |  |  |
| Non-current operating lease liabilities | Other non-current liabilities |  | 563 |  | 576 |  |  |
| Total operating lease liabilities |  |  | $ | 805 |  | $ | 829 |  |  |
| Weighted-average remaining lease term (in years) |  |  | 4.47 |  | 4.56 |  |  |
| Weighted-average discount rate |  |  | 5.04 | % |  | 4.79 | % |  |  |

[0001571996-24-000143:notes:112]
[same as prior period, unchanged from 0001571996-24-000090:notes:107]

[0001571996-24-000143:notes:113]
|  | Nine Months Ended |
|  | November 1, 2024 |  | November 3, 2023 |
|  | (in millions) |
| Cash paid for amounts included in the measurement of lease liabilities — operating cash outflows from operating leases | $ | 201 |  |  | $ | 220 |  |
| Right-of-use assets obtained in exchange for new operating lease liabilities | $ | 165 |  |  | $ | 205 |  |

[0001571996-24-000143:notes:114]
[same as prior period, unchanged from 0001571996-24-000090:notes:109]

[0001571996-24-000143:notes:115]
|  | November 1, 2024 |
|  | (in millions) |
| Fiscal 2025 (remaining three months) | $ | 65 |  |
| Fiscal 2026 | 235 |  |
| Fiscal 2027 | 201 |  |
| Fiscal 2028 | 154 |  |
| Fiscal 2029 | 104 |  |
| Thereafter | 133 |  |
| Total lease payments | 892 |  |
| Less: Imputed interest | 87 |  |
| Total | $ | 805 |  |
| Current operating lease liabilities | $ | 242 |  |
| Non-current operating lease liabilities | $ | 563 |  |

[0001571996-24-000143:notes:116]
As of November 1, 2024, the Company’s undiscounted operating leases that had not yet commenced were immaterial.


## us-gaap:DebtDisclosureTextBlock

[0001571996-24-000143:notes:117]
DEBT
The following table summarizes the Company’s outstanding debt as of the dates indicated:

[0001571996-24-000143:notes:118]
The Company completed the following transactions during the nine months ended November 1, 2024:

[0001571996-24-000143:notes:119]
•the issuance of $1 billion principal amount of 5.40% Senior Notes due April 2034, the proceeds of which were utilized to prepay a portion of the outstanding 6.02% Senior Notes due June 2026;

[0001571996-24-000143:notes:120]
•the repayment of $1 billion principal amount of the 4.00% Senior Notes due July 2024; and

[0001571996-24-000143:notes:121]
•the issuance of $0.7 billion principal amount of 4.35% Senior Notes due February 2030 and $0.8 billion principal amount of 4.85% Senior Notes due February 2035, the proceeds of which were utilized to redeem the 5.85% Senior Notes due July 2025.

[0001571996-24-000143:notes:122]
Outstanding Debt

[0001571996-24-000143:notes:123]
Senior Notes — The Company completed offerings of multiple series of senior notes which were issued on June 1, 2016, June 22, 2016, March 20, 2019, April 9, 2020, December 13, 2021, January 24, 2023, March 18, 2024, and October 8, 2024 in aggregate principal amounts of $20.0 billion, $3.3 billion, $4.5 billion, $2.3 billion, $2.3 billion, $2.0 billion, $1.0 billion, and $1.5 billion, respectively (collectively, the “Senior Notes”). The Senior Notes maturities range from 2026 through 2051. Interest rates on these borrowings are fixed, ranging from 3.38% to 8.35%, and interest is payable semiannually.

[0001571996-24-000143:notes:124]
Legacy Notes — The Company has outstanding unsecured notes and debentures (collectively, the “Legacy Notes”) that were issued by Dell Inc. (“Dell”), a wholly-owned subsidiary of Dell Technologies Inc., prior to the acquisition of Dell by Dell Technologies Inc. in the going-private transaction that closed in October 2013. The Legacy Notes’ maturities range from 2028 through 2040. Interest rates on these borrowings are fixed, ranging from 5.40% to 7.10%, and interest is payable semiannually.

[0001571996-24-000143:notes:125]
DFS Debt — See Note 4 and Note 7 of the Notes to the Condensed Consolidated Financial Statements, respectively, for discussion of DFS debt and the interest rate swap agreements that hedge a portion of that debt.

[0001571996-24-000143:notes:126]
Revolving Credit Facility — The Company’s revolving credit facility provides the Company with revolving commitments in an aggregate principal amount of $6.0 billion for general corporate purposes and includes a letter of credit sub-facility of up to $0.5 billion and a swing-line loan sub-facility of up to $0.5 billion. The revolving credit facility also allows the Company to obtain incremental additional commitments on one or more occasions in minimum amounts of $10 million.

[0001571996-24-000143:notes:127]
Borrowings under the revolving credit facility bear interest at a rate per annum equal to an applicable margin plus, at the borrowers’ option, either (a) the specified adjusted term Secured Overnight Financing Rate (“SOFR”) or (b) a base rate. The margin applicable to SOFR and base rate borrowings varies based upon the Company’s existing credit ratings. The base rate is calculated based upon the greatest of the specified prime rate, the specified federal reserve bank rate, or SOFR plus 1%. The borrowers may voluntarily repay outstanding loans at any time without premium or penalty, other than customary breakage costs. The facility matures on November 1, 2027.

[0001571996-24-000143:notes:128]
As of November 1, 2024, the Company had no outstanding borrowings under the revolving credit facility.

[0001571996-24-000143:notes:129]
Commercial Paper Program — The Company maintains a commercial paper program under which the Company may issue unsecured notes in a maximum aggregate face amount of $5.0 billion outstanding at any time, with maturities up to 397 days from the date of issuance. The notes are sold on customary terms in the U.S. commercial paper market on a private placement basis. The proceeds of the notes are used for general corporate purposes. As of November 1, 2024, the Company had no outstanding issuances under the commercial paper program.

[0001571996-24-000143:notes:130]
The Company may purchase, redeem, prepay, refinance, or otherwise retire any amount of outstanding indebtedness under the terms of such indebtedness at any time and from time to time, in open market or negotiated transactions with the holders of such indebtedness or otherwise, as considered appropriate in light of market conditions and other relevant factors.

[0001571996-24-000143:notes:131]
Covenants — The credit agreement governing the revolving credit facility and the indentures governing the Senior Notes and the Legacy Notes impose various limitations, subject to exceptions, on creating certain liens and entering into sale and lease-back transactions. The foregoing credit agreement and indentures contain customary events of default, and the revolving credit facility is subject to an interest coverage ratio covenant that is tested at the end of each fiscal quarter with respect to the Company’s preceding four fiscal quarters. The Company was in compliance with this financial covenant as of November 1, 2024.

[0001571996-24-000143:notes:132]
Aggregate Future Maturities

[0001571996-24-000143:notes:133]
The following table presents the aggregate future maturities of the Company’s debt as of November 1, 2024, excluding associated carrying value adjustments, for the periods indicated:

[0001571996-24-000143:notes:134]
|  | November 1, 2024 |
|  | (in millions) |
| Fiscal 2025 (remaining three months) | $ | 2,023 |  |
| Fiscal 2026 | 3,996 |  |
| Fiscal 2027 | 6,020 |  |
| Fiscal 2028 | 1,308 |  |
| Fiscal 2029 | 1,372 |  |
| Thereafter | 10,533 |  |
| Total maturities, principal amount | $ | 25,252 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001571996-24-000143:notes:135]
[same as prior period, unchanged from 0001571996-24-000090:notes:129]

[0001571996-24-000143:notes:136]
[same as prior period, unchanged from 0001571996-24-000090:notes:130]

[0001571996-24-000143:notes:137]
[same as prior period, unchanged from 0001571996-24-000090:notes:131]

[0001571996-24-000143:notes:138]
[same as prior period, unchanged from 0001571996-24-000090:notes:132]

[0001571996-24-000143:notes:139]
During the three and nine months ended November 1, 2024 and November 3, 2023, the Company did not discontinue any cash flow hedges related to foreign exchange contracts that had a material impact on the Company’s results of operations due to the probability that the forecasted cash flows would not occur.

[0001571996-24-000143:notes:140]
[same as prior period, unchanged from 0001571996-24-000090:notes:134]

[0001571996-24-000143:notes:141]
[same as prior period, unchanged from 0001571996-24-000090:notes:135]

[0001571996-24-000143:notes:142]
[same as prior period, unchanged from 0001571996-24-000090:notes:136]

[0001571996-24-000143:notes:143]
[same as prior period, unchanged from 0001571996-24-000090:notes:137]

[0001571996-24-000143:notes:144]
[same as prior period, unchanged from 0001571996-24-000090:notes:138]

[0001571996-24-000143:notes:145]
[same as prior period, unchanged from 0001571996-24-000090:notes:139]

[0001571996-24-000143:notes:146]
[same as prior period, unchanged from 0001571996-24-000090:notes:140]

[0001571996-24-000143:notes:147]
[same as prior period, unchanged from 0001571996-24-000090:notes:141]

[0001571996-24-000143:notes:148]
|  | November 1, 2024 |  | February 2, 2024 |
|  | (in millions) |
| Foreign exchange contracts: |  |  |  |
| Designated as cash flow hedging instruments | $ | 6,773 |  |  | $ | 6,339 |  |
| Non-designated as hedging instruments | 6,157 |  |  | 5,844 |  |
| Total | $ | 12,930 |  |  | $ | 12,183 |  |
| Interest rate contracts: |  |  |  |
| Non-designated as hedging instruments | $ | 6,357 |  |  | $ | 6,551 |  |

[0001571996-24-000143:notes:149]
[same as prior period, unchanged from 0001571996-24-000090:notes:143]

[0001571996-24-000143:notes:150]
| Derivatives in Cash Flow Hedging Relationships |  | Gain (Loss) Recognized in Accumulated OCI, Net of Tax, on Derivatives |  | Location of Gain (Loss) Reclassified from Accumulated OCI into Income |  | Gain (Loss) Reclassified from Accumulated OCI into Income |
|  |  | (in millions) |  |  |  | (in millions) |
| For the three months ended November 1, 2024: |
|  |  |  |  | Total net revenue |  | $ | (57) |  |
| Foreign exchange contracts |  | $ | (9) |  |  | Total cost of net revenue |  | 3 |  |
| Total |  | $ | (9) |  |  | Total |  | $ | (54) |  |
| For the three months ended November 3, 2023: |
|  |  |  |  | Total net revenue |  | $ | 83 |  |
| Foreign exchange contracts |  | $ | 171 |  |  | Total cost of net revenue |  | 1 |  |
| Total |  | $ | 171 |  |  | Total |  | $ | 84 |  |
| For the nine months ended November 1, 2024: |
|  |  |  |  | Total net revenue |  | $ | (25) |  |
| Foreign exchange contracts |  | $ | 58 |  |  | Total cost of net revenue |  | 8 |  |
| Total |  | $ | 58 |  |  | Total |  | $ | (17) |  |
| For the nine months ended November 3, 2023: |
|  |  |  |  | Total net revenue |  | $ | (68) |  |
| Foreign exchange contracts |  | $ | 230 |  |  | Total cost of net revenue |  | (7) |  |
| Total |  | $ | 230 |  |  | Total |  | $ | (75) |  |

[0001571996-24-000143:notes:151]
[same as prior period, unchanged from 0001571996-24-000090:notes:145]

[0001571996-24-000143:notes:152]
|  | Three Months Ended |  | Nine Months Ended |  |  |  |  |
|  | November 1, 2024 |  | November 3, 2023 |  | November 1, 2024 |  | November 3, 2023 |  |  |  | Location of Gain (Loss) Recognized |
|  | (in millions) |  |  |
| Foreign exchange contracts | $ | (13) |  |  | $ | (114) |  |  | $ | (58) |  |  | $ | (97) |  |  |  |  | Interest and other, net |
| Interest rate contracts | 32 |  |  | 2 |  |  | 21 |  |  | 5 |  |  |  |  | Interest and other, net |
| Total | $ | 19 |  |  | $ | (112) |  |  | $ | (37) |  |  | $ | (92) |  |  |  |  |  |

[0001571996-24-000143:notes:153]
[same as prior period, unchanged from 0001571996-24-000090:notes:147]

[0001571996-24-000143:notes:154]
|  | November 1, 2024 |
|  | Other Current Assets |  | Other Non-Current Assets |  | Other Current Liabilities |  | Other Non-Current Liabilities |  | Total Fair Value |
|  | (in millions) |
| Derivatives designated as hedging instruments: |
| Foreign exchange contracts in an asset position | $ | 124 |  |  | $ | — |  |  | $ | 18 |  |  | $ | — |  |  | $ | 142 |  |
| Foreign exchange contracts in a liability position | (3) |  |  | — |  |  | (3) |  |  | — |  |  | (6) |  |
| Net asset (liability) | 121 |  |  | — |  |  | 15 |  |  | — |  |  | 136 |  |
| Derivatives not designated as hedging instruments: |
| Foreign exchange contracts in an asset position | 102 |  |  | — |  |  | 47 |  |  | — |  |  | 149 |  |
| Foreign exchange contracts in a liability position | (139) |  |  | — |  |  | (128) |  |  | — |  |  | (267) |  |
| Interest rate contracts in an asset position | — |  |  | 40 |  |  | — |  |  | — |  |  | 40 |  |
| Interest rate contracts in a liability position | — |  |  | — |  |  | — |  |  | (35) |  |  | (35) |  |
| Net asset (liability) | (37) |  |  | 40 |  |  | (81) |  |  | (35) |  |  | (113) |  |
| Total derivatives at fair value | $ | 84 |  |  | $ | 40 |  |  | $ | (66) |  |  | $ | (35) |  |  | $ | 23 |  |
|  | February 2, 2024 |
|  | Other Current Assets |  | Other Non-Current Assets |  | Other Current Liabilities |  | Other Non-Current Liabilities |  | Total Fair Value |
|  | (in millions) |
| Derivatives designated as hedging instruments: |
| Foreign exchange contracts in an asset position | $ | 44 |  |  | $ | — |  |  | $ | 19 |  |  | $ | — |  |  | $ | 63 |  |
| Foreign exchange contracts in a liability position | (5) |  |  | — |  |  | (15) |  |  | — |  |  | (20) |  |
| Net asset (liability) | 39 |  |  | — |  |  | 4 |  |  | — |  |  | 43 |  |
| Derivatives not designated as hedging instruments: |
| Foreign exchange contracts in an asset position | 90 |  |  | — |  |  | 71 |  |  | — |  |  | 161 |  |
| Foreign exchange contracts in a liability position | (68) |  |  | — |  |  | (121) |  |  | — |  |  | (189) |  |
| Interest rate contracts in an asset position | 3 |  |  | 40 |  |  | — |  |  | — |  |  | 43 |  |
| Interest rate contracts in a liability position | — |  |  | — |  |  | (10) |  |  | (28) |  |  | (38) |  |
| Net asset (liability) | 25 |  |  | 40 |  |  | (60) |  |  | (28) |  |  | (23) |  |
| Total derivatives at fair value | $ | 64 |  |  | $ | 40 |  |  | $ | (56) |  |  | $ | (28) |  |  | $ | 20 |  |

[0001571996-24-000143:notes:155]
[same as prior period, unchanged from 0001571996-24-000090:notes:149]

[0001571996-24-000143:notes:156]
|  | November 1, 2024 |
|  | Gross Amounts of Recognized Assets/(Liabilities) |  | Gross Amounts Offset in the Statement of Financial Position |  | Net Amounts of Assets/(Liabilities) Presented in the Statement of Financial Position |  | Gross Amounts not Offset in the Statement of Financial Position |  | Net Amount of Assets/ (Liabilities) Recognized in the Statement of Financial Position |
|  | Financial Instruments |  | Cash Collateral Received or Pledged |  |
|  | (in millions) |
| Derivative instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Financial assets | $ | 331 |  |  | $ | (207) |  |  | $ | 124 |  |  | $ | — |  |  | $ | (28) |  |  | $ | 96 |  |
| Financial liabilities | (308) |  |  | 207 |  |  | (101) |  |  | — |  |  | 3 |  |  | (98) |  |
| Total derivative instruments | $ | 23 |  |  | $ | — |  |  | $ | 23 |  |  | $ | — |  |  | $ | (25) |  |  | $ | (2) |  |
|  | February 2, 2024 |
|  | Gross Amounts of Recognized Assets/(Liabilities) |  | Gross Amounts Offset in the Statement of Financial Position |  | Net Amounts of Assets/(Liabilities) Presented in the Statement of Financial Position |  | Gross Amounts not Offset in the Statement of Financial Position |  | Net Amount of Assets/ (Liabilities) Recognized in the Statement of Financial Position |
|  | Financial Instruments |  | Cash Collateral Received or Pledged |  |
|  | (in millions) |
| Derivative instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Financial assets | $ | 267 |  |  | $ | (163) |  |  | $ | 104 |  |  | $ | — |  |  | $ | (24) |  |  | $ | 80 |  |
| Financial liabilities | (247) |  |  | 163 |  |  | (84) |  |  | — |  |  | 9 |  |  | (75) |  |
| Total derivative instruments | $ | 20 |  |  | $ | — |  |  | $ | 20 |  |  | $ | — |  |  | $ | (15) |  |  | $ | 5 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001571996-24-000143:notes:157]
[same as prior period, unchanged from 0001571996-24-000090:notes:151]

[0001571996-24-000143:notes:158]
[same as prior period, unchanged from 0001571996-24-000090:notes:152]

[0001571996-24-000143:notes:159]
[same as prior period, unchanged from 0001571996-24-000090:notes:153]

[0001571996-24-000143:notes:160]
|  | Infrastructure Solutions Group |  | Client Solutions Group |  | Other Businesses |  | Total |
|  | (in millions) |
| Balances as of February 2, 2024 | $ | 15,041 |  |  | $ | 4,232 |  |  | $ | 427 |  |  | $ | 19,700 |  |
| Impact of foreign currency translation and other | (30) |  |  | — |  |  | — |  |  | (30) |  |
| Reclassification to assets held for sale (a) | — |  |  | — |  |  | (427) |  |  | (427) |  |
| Balances as of November 1, 2024 | $ | 15,011 |  |  | $ | 4,232 |  |  | $ | — |  |  | $ | 19,243 |  |

[0001571996-24-000143:notes:161]
(a)    During the three months ended November 1, 2024, Secureworks goodwill was reclassified to current assets held for sale on the Condensed Consolidated Statements of Financial Position. See Note 1 of the Notes to the Condensed Consolidated Financial Statements for additional information about the pending sale of Secureworks.

[0001571996-24-000143:notes:162]
[same as prior period, unchanged from 0001571996-24-000090:notes:155]

[0001571996-24-000143:notes:163]
[same as prior period, unchanged from 0001571996-24-000090:notes:156]

[0001571996-24-000143:notes:164]
|  | November 1, 2024 |  | February 2, 2024 |
|  | Gross |  | AccumulatedAmortization |  | Net |  | Gross |  | AccumulatedAmortization |  | Net |
|  | (in millions) |
| Customer relationships | $ | 16,642 |  |  | $ | (14,921) |  |  | $ | 1,721 |  |  | $ | 16,968 |  |  | $ | (14,930) |  |  | $ | 2,038 |  |
| Developed technology | 9,501 |  |  | (9,154) |  |  | 347 |  |  | 9,506 |  |  | (8,980) |  |  | 526 |  |
| Trade names | 875 |  |  | (851) |  |  | 24 |  |  | 875 |  |  | (823) |  |  | 52 |  |
| Definite-lived intangible assets | 27,018 |  |  | (24,926) |  |  | 2,092 |  |  | 27,349 |  |  | (24,733) |  |  | 2,616 |  |
| Indefinite-lived trade names | 3,055 |  |  | — |  |  | 3,055 |  |  | 3,085 |  |  | — |  |  | 3,085 |  |
| Total intangible assets | $ | 30,073 |  |  | $ | (24,926) |  |  | $ | 5,147 |  |  | $ | 30,434 |  |  | $ | (24,733) |  |  | $ | 5,701 |  |

[0001571996-24-000143:notes:165]
Amortization expense related to definite-lived intangible assets was $163 million and $205 million for the three months ended November 1, 2024 and November 3, 2023, respectively, and $491 million and $613 million for the nine months ended November 1, 2024 and November 3, 2023, respectively. There were no material impairment charges related to intangible assets during the three or nine months ended November 1, 2024 and November 3, 2023.

[0001571996-24-000143:notes:166]
[same as prior period, unchanged from 0001571996-24-000090:notes:159]

[0001571996-24-000143:notes:167]
|  | November 1, 2024 |
|  | (in millions) |
| Fiscal 2025 (remaining three months) | $ | 160 |  |
| Fiscal 2026 | 480 |  |
| Fiscal 2027 | 372 |  |
| Fiscal 2028 | 230 |  |
| Fiscal 2029 | 190 |  |
| Thereafter | 660 |  |
| Total | $ | 2,092 |  |

[0001571996-24-000143:notes:168]
[same as prior period, unchanged from 0001571996-24-000090:notes:161]

[0001571996-24-000143:notes:169]
[same as prior period, unchanged from 0001571996-24-000090:notes:162]

[0001571996-24-000143:notes:170]
For the annual impairment review of the Infrastructure Solutions Group (“ISG”) and Client Solutions Group (“CSG”) reporting units during the third quarter of Fiscal 2025, the Company elected to bypass the assessment of qualitative factors to determine whether it was more likely than not that the fair value of a reporting unit was less than its carrying amount, including goodwill. In electing to bypass the qualitative assessment, the Company proceeded directly to perform a quantitative goodwill impairment test to measure the fair value of each goodwill reporting unit relative to its carrying amount, and to determine the amount of goodwill impairment loss to be recognized, if any. For the remaining reporting units, the Company performed a qualitative assessment of goodwill at the reporting unit level. The qualitative assessment included consideration of the relevant events and circumstances affecting the reporting unit, including macroeconomic, industry and market conditions, overall financial performance, and trends in the public company market valuation, where applicable. Additionally, Secureworks’ entry into a definitive agreement, pursuant to which Secureworks will be acquired in an all-cash transaction for approximately $0.9 billion, as discussed in Note 1 of the Notes to the Condensed Consolidated Financial Statements, provided a fair value indication that the Secureworks reporting unit exceeded its carrying value.

[0001571996-24-000143:notes:171]
[same as prior period, unchanged from 0001571996-24-000090:notes:164]

[0001571996-24-000143:notes:172]
[same as prior period, unchanged from 0001571996-24-000090:notes:165]

[0001571996-24-000143:notes:173]
Based on the results of the annual impairment test performed during the three months ended November 1, 2024, the fair values of each of the reporting units and indefinite-lived intangibles exceeded their carrying values. No goodwill or indefinite-lived assets impairment test was performed during the nine months ended November 1, 2024 other than the Company’s annual impairment review and the assessment of Secureworks.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001571996-24-000143:notes:174]
[same as prior period, unchanged from 0001571996-24-000090:notes:167]

[0001571996-24-000143:notes:175]
[same as prior period, unchanged from 0001571996-24-000090:notes:168]

[0001571996-24-000143:notes:176]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 1, 2024 |  | November 3, 2023 |  | November 1, 2024 |  | November 3, 2023 |
|  | (in millions) |
| Deferred revenue: |  |  |  |  |  |  |  |
| Deferred revenue at beginning of period | $ | 27,712 |  |  | $ | 30,312 |  |  | $ | 29,145 |  |  | $ | 30,286 |  |
| Revenue deferrals | 3,897 |  |  | 4,492 |  |  | 13,286 |  |  | 15,236 |  |
| Revenue recognized | (5,262) |  |  | (5,766) |  |  | (16,084) |  |  | (16,484) |  |
| Other (a) | (136) |  |  | 15 |  |  | (136) |  |  | 15 |  |
| Deferred revenue at end of period | $ | 26,211 |  |  | $ | 29,053 |  |  | $ | 26,211 |  |  | $ | 29,053 |  |
| Short-term deferred revenue | $ | 13,787 |  |  | $ | 15,206 |  |  | $ | 13,787 |  |  | $ | 15,206 |  |
| Long-term deferred revenue | $ | 12,424 |  |  | $ | 13,847 |  |  | $ | 12,424 |  |  | $ | 13,847 |  |

[0001571996-24-000143:notes:177]
(a) For the three and nine months ended November 1, 2024, Other represents the reclassification of Secureworks deferred revenue to liabilities held for sale. See Note 1 of the Notes to the Condensed Consolidated Financial Statements for more information about the pending sale of Secureworks.

[0001571996-24-000143:notes:178]
Remaining Performance Obligations — Remaining performance obligations represent the aggregate amount of the transaction price allocated to performance obligations not delivered, or partially undelivered, as of the end of the reporting period. Remaining performance obligations include deferred revenue plus unbilled amounts not yet recorded in deferred revenue. The value of the transaction price allocated to remaining performance obligations as of November 1, 2024 was approximately $37 billion. The Company expects to recognize approximately 60% of remaining performance obligations as revenue in the next twelve months, and the remainder thereafter.

[0001571996-24-000143:notes:179]
[same as prior period, unchanged from 0001571996-24-000090:notes:171]

[0001571996-24-000143:notes:180]
[same as prior period, unchanged from 0001571996-24-000090:notes:172]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001571996-24-000143:notes:181]
COMMITMENTS AND CONTINGENCIES 
Purchase Obligations

[0001571996-24-000143:notes:182]
The Company has contractual obligations to purchase goods or services, which specify significant terms (including fixed or minimum quantities to be purchased), fixed, minimum, or variable price provisions, and the approximate timing of the transaction. As of November 1, 2024, such purchase obligations were $6.4 billion for the remaining three months of Fiscal 2025; $0.5 billion for Fiscal 2026; and $1.2 billion for Fiscal 2027 and thereafter.

[0001571996-24-000143:notes:183]
Legal Matters

[0001571996-24-000143:notes:184]
The Company is involved in various claims, suits, assessments, investigations, and legal proceedings that arise from time to time in the ordinary course of its business, including those identified below, consisting of matters involving consumer, antitrust, tax, intellectual property, and other issues on a global basis.

[0001571996-24-000143:notes:185]
The Company accrues a liability when it believes that it is both probable that a liability has been incurred and that it can reasonably estimate the amount of the loss. The Company reviews these accruals at least quarterly and adjusts them to reflect ongoing negotiations, settlements, rulings, advice of legal counsel, and other relevant information. To the extent new information is obtained and the Company’s views on the probable outcomes of claims, suits, assessments, investigations, or legal proceedings change, changes in the Company’s accrued liabilities are recorded in the period in which such a determination is made. For some matters, the incurrence of a liability is not probable or the amount cannot be reasonably estimated and therefore accruals have not been made.

[0001571996-24-000143:notes:186]
The following is a discussion of the Company’s significant legal matters and other proceedings:

[0001571996-24-000143:notes:187]
Class Actions Related to the Class V Transaction — On December 28, 2018, the Company completed a transaction (the “Class V transaction”) in which it paid $14.0 billion in cash and issued 149,387,617 shares of its Class C Common Stock to holders of its Class V Common Stock in exchange for all outstanding shares of Class V Common Stock. As a result of the Class V transaction, the tracking stock feature of the Company’s capital structure associated with the Class V Common Stock was terminated. Certain stockholders of the Company subsequently brought class action complaints arising out of the Class V transaction in which they named as defendants (collectively, the “defendants”) Michael S. Dell and certain other directors serving on the Company’s board of directors at the time of the Class V transaction (collectively, the “director defendants”), certain stockholders of the Company, consisting of Mr. Dell and Silver Lake Group, L.L.C. and certain of its affiliated funds (collectively, the “stockholder defendants”), and Goldman Sachs & Co. LLC, which served as financial advisor to the Company in connection with the transaction. The plaintiffs generally alleged that the director defendants and the stockholder defendants breached their fiduciary duties under Delaware law to the former holders of the Class V Common Stock in connection with the Class V transaction by offering a transaction value that was allegedly billions of dollars below fair value.

[0001571996-24-000143:notes:188]
As previously reported, during the fourth quarter of the fiscal year ended February 3, 2023, the plaintiffs and the defendants entered into an agreement to settle the lawsuit. Under the terms of the settlement, the plaintiffs agreed to the dismissal of all claims upon payment of a total of $1.0 billion (the “settlement amount”), which includes all costs, expenses and fees of the plaintiff class relating to the action and its resolution. On May 16, 2023, during the fiscal year ended February 2, 2024, the Company paid the settlement amount following approval of the settlement by the Delaware Court of Chancery. This matter is no longer material to the Company.

[0001571996-24-000143:notes:189]
R2 Semiconductor Patent Litigation — In November 2022, R2 Semiconductor, Inc. (“R2”) filed a lawsuit in the Dusseldorf Regional Court in Germany against Intel Deutschland GmbH, Dell GmbH, and certain other customers of Intel Corporation. R2 asserted that one European patent is infringed by certain Intel processors and those of the Company’s products that incorporate those processors. R2 sought an injunction prohibiting the sale of the allegedly infringing products and damages for the alleged infringement. The court conducted a trial on December 7, 2023 and, on February 7, 2024, issued a decision in favor of R2 and imposed an injunction prohibiting the sale and use of such products in Germany by Dell GmbH, and requiring Dell GmbH to issue a communication to certain customers recalling the covered products sold since March 5, 2020. On February 8, 2024, the Company filed an appeal. In April and May 2024, R2 filed lawsuits in Paris, France and Milan, Italy, against affiliates of Intel Corporation (“Intel”) and of the Company, raising similar allegations. Intel agreed to defend the foregoing actions and indemnify the Company and its affiliates against certain losses incurred by the Company in connection with R2’s claims. On August 30, 2024, Intel and R2 publicly announced an agreement to dismiss all litigation between the two companies that would include dismissal of all litigation against all subsidiaries of Dell Technologies named in the foregoing actions. Pursuant to that agreement, the Italian lawsuit was dismissed on September 2, 2024, the German lawsuit was dismissed on September 4, 2024, and the French lawsuit was dismissed on September 6, 2024.

[0001571996-24-000143:notes:190]
Other Litigation — Dell does not currently anticipate that any of the other legal proceedings it is involved in will have a material adverse effect on its business, financial condition, results of operations, or cash flows.

[0001571996-24-000143:notes:191]
In accordance with the relevant accounting guidance, the Company provides disclosures of matters where it is at least reasonably possible that the Company could experience a material loss exceeding the amounts already accrued for these or other proceedings or matters. In addition, the Company also discloses matters based on its consideration of other matters and qualitative factors, including the experience of other companies in the industry, and investor, customer, and employee relations considerations. As of November 1, 2024, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for these or other proceedings or matters has been incurred. However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company’s business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters. Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company’s business, financial condition, results of operations, or cash flows will depend on a number of factors, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.

[0001571996-24-000143:notes:192]
Indemnifications Obligations

[0001571996-24-000143:notes:193]
In the ordinary course of business, the Company enters into various contracts under which it may agree to indemnify other parties for losses incurred from certain events as defined in the relevant contract, such as litigation, regulatory penalties, or claims relating to past performance. Such indemnification obligations may not be subject to maximum loss clauses. Historically, payments related to these indemnification obligations have not been material to the Company.

[0001571996-24-000143:notes:194]
Under the Separation and Distribution Agreement entered into with VMware, Inc. upon completion of the spin-off of VMware, Inc. on November 1, 2021 (the “VMware Spin-off”), Dell Technologies agreed to indemnify VMware, Inc., each of its subsidiaries and each of their respective directors, officers, employees, as well as any successors and assigns of the foregoing, from and against all liabilities relating to, arising out of or resulting from, among other matters, the liabilities allocated to Dell Technologies as part of the separation of Dell Technologies and VMware, Inc. (currently operating under the name “VMware LLC,” and individually and together with its subsidiaries, “VMware”) and their respective businesses (the “Separation”). VMware similarly agreed to indemnify Dell Technologies Inc., each of its subsidiaries and each of their respective directors, officers, and employees from and against all liabilities relating to, arising out of or resulting from, among other matters, the liabilities allocated to VMware as part of the Separation. The amounts that VMware and Dell Technologies may be obligated to pay each other could vary depending on the outcome of certain unresolved tax matters, which may not be resolved for several years. Net income tax indemnification receivables from VMware were immaterial as of November 1, 2024 and February 2, 2024.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001571996-24-000143:notes:195]
INCOME AND OTHER TAXES
For the three months ended November 1, 2024, the Company’s effective income tax rate was 19.0% on pre-tax income of $1.4 billion compared to 14.9% on pre-tax income of $1.2 billion for the three months ended November 3, 2023. For the nine months ended November 1, 2024, the Company’s effective income tax rate was 0.2% on pre-tax income of $2.9 billion compared to 21.6% on pre-tax income of $2.6 billion for the nine months ended November 3, 2023. The changes in the Company’s effective income tax rate were primarily driven by discrete tax items. For the nine months ended November 1, 2024, the Company recorded discrete tax benefits of $0.4 billion related to changes in uncertain tax benefits resulting from the expiration of certain statutes of limitations and $0.2 billion related to stock-based compensation.

[0001571996-24-000143:notes:196]
The differences between the estimated effective income tax rates and the U.S. federal statutory rate of 21% principally result from the geographical distribution of income, differences between the book and tax treatment of certain items, and discrete tax items. In certain jurisdictions, the Company’s tax rate is significantly less than the applicable statutory rate as a result of tax holidays. The majority of the Company’s foreign income subject to these tax holidays and lower tax rates is attributable to Singapore and China. A significant portion of these income tax benefits relates to a tax holiday that will be effective until January 31, 2029. Most of the Company’s other tax holidays will expire in whole or in part during fiscal years 2030 and 2031. Many of these tax holidays and reduced tax rates may be extended when certain conditions are met or may be terminated early if certain conditions are not met or as a result of changes in tax legislation. As of November 1, 2024, the Company was not aware of any matters of non-compliance related to these tax holidays.

[0001571996-24-000143:notes:197]
In June 2023, the Company received a Revenue Agent’s Report for the federal income tax examination by the Internal Revenue Service (“IRS”) of fiscal years 2018 through 2019. The IRS proposed adjustments primarily relating to certain transactions the Company completed as part of its business integration efforts. In August 2023, the Company submitted a written protest to the IRS relating to certain assessments. The Company received a rebuttal from the IRS to its written protest in April 2024. The Company disagrees with the IRS’s proposed adjustments and will contest them through the IRS administrative appeals procedures. The Company anticipates that the appeals process for the resolution of these matters will extend beyond the next twelve months. In September 2023, the IRS commenced a federal income tax examination of fiscal years 2020 through 2022.

[0001571996-24-000143:notes:198]
[same as prior period, unchanged from 0001571996-24-000090:notes:190]

[0001571996-24-000143:notes:199]
[same as prior period, unchanged from 0001571996-24-000090:notes:191]

[0001571996-24-000143:notes:200]
Judgment is required in evaluating the Company’s uncertain tax positions and determining the Company’s provision for income taxes. Unrecognized tax benefits were $1.0 billion and $1.3 billion as of November 1, 2024 and February 2, 2024, respectively, and are included in other non-current liabilities in the Condensed Consolidated Statements of Financial Position. The Company does not anticipate a significant change to the total amount of unrecognized tax benefits within the next twelve months.

[0001571996-24-000143:notes:201]
The Company takes certain non-income tax positions in the jurisdictions in which it operates and has received certain non-income tax assessments from various jurisdictions. The Company believes that a material loss in these non-income tax litigation matters is not probable and that it is not reasonably possible that a material loss exceeding amounts already accrued has been incurred. The Company believes its positions in these matters are supportable and that it ultimately will prevail in the matters. In the normal course of business, the Company’s positions and conclusions related to its non-income taxes could be challenged and assessments may be made. To the extent new information is obtained and the Company’s views on its positions, probable outcomes of assessments, or litigation change, changes in estimates to the Company’s accrued liabilities would be recorded in the period in which such a determination is made. In the resolution process for income tax and non-income tax audits, the Company is required in certain situations to provide collateral guarantees or indemnification to regulators and tax authorities until the matter is resolved.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001571996-24-000143:notes:202]
[same as prior period, unchanged from 0001571996-24-000090:notes:194]

[0001571996-24-000143:notes:203]
[same as prior period, unchanged from 0001571996-24-000090:notes:195]

[0001571996-24-000143:notes:204]
|  | Foreign Currency Translation Adjustments |  |  |  | Cash Flow Hedges |  | Pension and Other Postretirement Plans |  | Accumulated Other Comprehensive Income (Loss) |
|  | (in millions) |
| Balances as of February 2, 2024 | $ | (755) |  |  |  |  | $ | (30) |  |  | $ | (15) |  |  | $ | (800) |  |
| Other comprehensive income (loss) before reclassifications | (95) |  |  |  |  | 58 |  |  | 1 |  |  | (36) |  |
| Amounts reclassified from accumulated other comprehensive income (loss) | — |  |  |  |  | 17 |  |  | (1) |  |  | 16 |  |
| Total change for the period | (95) |  |  |  |  | 75 |  |  | — |  |  | (20) |  |
| Balances as of November 1, 2024 | $ | (850) |  |  |  |  | $ | 45 |  |  | $ | (15) |  |  | $ | (820) |  |

[0001571996-24-000143:notes:205]
[same as prior period, unchanged from 0001571996-24-000090:notes:197]

[0001571996-24-000143:notes:206]
[same as prior period, unchanged from 0001571996-24-000090:notes:198]

[0001571996-24-000143:notes:207]
|  |  |  | Three Months Ended |  |  |  |  |  |  |
|  |  |  | November 1, 2024 |  | November 3, 2023 |  |  |
|  |  |  | Cash Flow Hedges |  |  |  |  |  | Pensions |  |  |  | Total |  | Cash Flow Hedges |  | Pensions |  | Total |  |  |  |  |  |  |
|  |  |  | (in millions) |
| Total reclassifications, net of tax: |  |  |  |  |  |  |
| Net revenue |  |  | $ | (57) |  |  |  |  |  |  | $ | — |  |  |  |  | $ | (57) |  |  | $ | 83 |  |  | $ | — |  |  | $ | 83 |  |  |  |  |  |  |  |
| Cost of net revenue |  |  | 3 |  |  |  |  |  |  | — |  |  |  |  | 3 |  |  | 1 |  |  | — |  |  | 1 |  |  |  |  |  |  |  |
| Operating expenses |  |  | — |  |  |  |  |  |  | — |  |  |  |  | — |  |  | — |  |  | — |  |  | — |  |  |  |  |  |  |  |
| Total reclassifications, net of tax |  |  | $ | (54) |  |  |  |  |  |  | $ | — |  |  |  |  | $ | (54) |  |  | $ | 84 |  |  | $ | — |  |  | $ | 84 |  |  |  |  |  |  |  |

[0001571996-24-000143:notes:208]
|  |  |  | Nine Months Ended |
|  |  |  | November 1, 2024 |  | November 3, 2023 |
|  |  |  | Cash Flow Hedges |  |  |  |  |  | Pensions |  |  |  | Total |  | Cash Flow Hedges |  | Pensions |  | Total |
|  |  |  | (in millions) |
| Total reclassifications, net of tax: |
| Net revenue |  |  | $ | (25) |  |  |  |  |  |  | $ | — |  |  |  |  | $ | (25) |  |  | $ | (68) |  |  | $ | — |  |  | $ | (68) |  |
| Cost of net revenue |  |  | 8 |  |  |  |  |  |  | — |  |  |  |  | 8 |  |  | (7) |  |  | — |  |  | (7) |  |
| Operating expenses |  |  | — |  |  |  |  |  |  | 1 |  |  |  |  | 1 |  |  | — |  |  | — |  |  | — |  |
| Total reclassifications, net of tax |  |  | $ | (17) |  |  |  |  |  |  | $ | 1 |  |  |  |  | $ | (16) |  |  | $ | (75) |  |  | $ | — |  |  | $ | (75) |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001571996-24-000143:notes:209]
[same as prior period, unchanged from 0001571996-24-000090:notes:201]

[0001571996-24-000143:notes:210]
|  | Authorized |  | Issued |  | Outstanding |
|  | (in millions) |
| Common stock as of November 1, 2024 |
| Class A | 600 |  |  | 302 |  |  | 302 |  |
| Class B | 200 |  |  | 66 |  |  | 66 |  |
| Class C | 7,900 |  |  | 466 |  |  | 334 |  |
| Class D | 100 |  |  | — |  |  | — |  |
|  | 8,800 |  |  | 834 |  |  | 702 |  |
| Common stock as of February 2, 2024 |
| Class A | 600 |  |  | 353 |  |  | 353 |  |
| Class B | 200 |  |  | 86 |  |  | 86 |  |
| Class C | 7,900 |  |  | 382 |  |  | 266 |  |
| Class D | 100 |  |  | — |  |  | — |  |
|  | 8,800 |  |  | 821 |  |  | 705 |  |

[0001571996-24-000143:notes:211]
[same as prior period, unchanged from 0001571996-24-000090:notes:203]

[0001571996-24-000143:notes:212]
The Company is authorized to issue one million shares of preferred stock, par value $0.01 per share. As of November 1, 2024 and February 2, 2024, no shares of preferred stock were issued or outstanding.

[0001571996-24-000143:notes:213]
[same as prior period, unchanged from 0001571996-24-000090:notes:205]

[0001571996-24-000143:notes:214]
[same as prior period, unchanged from 0001571996-24-000090:notes:206]

[0001571996-24-000143:notes:215]
[same as prior period, unchanged from 0001571996-24-000090:notes:207]

[0001571996-24-000143:notes:216]
[same as prior period, unchanged from 0001571996-24-000090:notes:208]

[0001571996-24-000143:notes:217]
During the nine months ended November 1, 2024, the Company issued 71 million shares of Class C Common Stock to stockholders upon the conversion of 51 million shares of Class A Common Stock and 20 million shares of Class B Common Stock in accordance with the Company’s certificate of incorporation. During the fiscal year ended February 2, 2024, the Company issued 34 million shares of Class C Common Stock to stockholders upon the conversion of 25 million shares of Class A Common Stock and 9 million shares of Class B Common Stock in accordance with the Company’s certificate of incorporation.

[0001571996-24-000143:notes:218]
[same as prior period, unchanged from 0001571996-24-000090:notes:210]

[0001571996-24-000143:notes:219]
[same as prior period, unchanged from 0001571996-24-000090:notes:211]

[0001571996-24-000143:notes:220]
[same as prior period, unchanged from 0001571996-24-000090:notes:212]

[0001571996-24-000143:notes:221]
| Three Months Ended |  | Declaration Date |  | Record Date |  | Payment Date |  | Dividend per Share |  | Amount (in millions) |
| Fiscal 2025 |
| May 3, 2024 |  | February 29, 2024 |  | April 23, 2024 |  | May 3, 2024 |  | $ | 0.445 |  |  | $ | 316 |  |
| August 2, 2024 |  | June 11, 2024 |  | July 23, 2024 |  | August 2, 2024 |  | $ | 0.445 |  |  | $ | 314 |  |
| November 1, 2024 |  | September 18, 2024 |  | October 22, 2024 |  | November 1, 2024 |  | $ | 0.445 |  |  | $ | 312 |  |
| Fiscal 2024 |
| May 5, 2023 |  | March 2, 2023 |  | April 25, 2023 |  | May 5, 2023 |  | $ | 0.37 |  |  | $ | 270 |  |
| August 4, 2023 |  | June 16, 2023 |  | July 25, 2023 |  | August 4, 2023 |  | $ | 0.37 |  |  | $ | 268 |  |
| November 3, 2023 |  | September 28, 2023 |  | October 24, 2023 |  | November 3, 2023 |  | $ | 0.37 |  |  | $ | 266 |  |

[0001571996-24-000143:notes:222]
During the three and nine months ended November 1, 2024 and November 3, 2023, the Company also paid an immaterial amount of dividend equivalents on eligible vested equity awards which are not included above.

[0001571996-24-000143:notes:223]
[same as prior period, unchanged from 0001571996-24-000090:notes:215]

[0001571996-24-000143:notes:224]
Effective as of September 23, 2021, the Company’s Board of Directors approved a stock repurchase program under which the Company is authorized to repurchase up to $5 billion of shares of Class C Common Stock with no fixed expiration date, exclusive of any fees, commissions, or other expenses related to such repurchases.

[0001571996-24-000143:notes:225]
[same as prior period, unchanged from 0001571996-24-000090:notes:217]

[0001571996-24-000143:notes:226]
During the nine months ended November 1, 2024, the Company repurchased approximately 16 million shares of Class C Common Stock for a total purchase price of approximately $1.8 billion. During the nine months ended November 3, 2023, the Company repurchased approximately 22 million shares of Class C Common Stock for a total purchase price of approximately $1.3 billion. As of November 1, 2024, the Company had approximately $2.6 billion in authorized amount remaining under the stock repurchase program.
The above repurchases of Class C Common Stock exclude U.S. federal excise taxes and shares withheld from stock awards to settle employee tax withholding obligations related to the vesting of such awards.


## us-gaap:EarningsPerShareTextBlock

[0001571996-24-000143:notes:227]
[same as prior period, unchanged from 0001571996-24-000090:notes:220]

[0001571996-24-000143:notes:228]
[same as prior period, unchanged from 0001571996-24-000090:notes:221]

[0001571996-24-000143:notes:229]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 1, 2024 |  | November 3, 2023 |  | November 1, 2024 |  | November 3, 2023 |  |  |
| Earnings per share attributable to Dell Technologies Inc. |  |  |
| Dell Technologies Common Stock — Basic | $ | 1.61 |  |  | $ | 1.39 |  |  | $ | 4.16 |  |  | $ | 2.83 |  |  |  |
| Dell Technologies Common Stock — Diluted | $ | 1.58 |  |  | $ | 1.36 |  |  | $ | 4.07 |  |  | $ | 2.78 |  |  |  |

[0001571996-24-000143:notes:230]
[same as prior period, unchanged from 0001571996-24-000090:notes:223]

[0001571996-24-000143:notes:231]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 1, 2024 |  | November 3, 2023 |  | November 1, 2024 |  | November 3, 2023 |  |  |
|  | (in millions) |
| Numerator: Dell Technologies Common Stock |  |  |  |  |  |  |  |  |  |
| Net income attributable to Dell Technologies Inc. — basic and diluted | $ | 1,132 |  |  | $ | 1,006 |  |  | $ | 2,938 |  |  | $ | 2,051 |  |  |  |
| Denominator: Dell Technologies Common Stock weighted-average shares outstanding |  |  |  |  |  |  |  |  |  |
| Weighted-average shares outstanding — basic | 703 |  |  | 722 |  |  | 706 |  |  | 724 |  |  |  |
| Dilutive effect of equity awards | 14 |  |  | 18 |  |  | 16 |  |  | 14 |  |  |  |
| Weighted-average shares outstanding — diluted | 717 |  |  | 740 |  |  | 722 |  |  | 738 |  |  |  |
| Weighted-average shares outstanding — antidilutive | — |  |  | — |  |  | — |  |  | 5 |  |  |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001571996-24-000143:notes:232]
RELATED PARTY TRANSACTIONS 
Prior to the acquisition on November 22, 2023 of VMware LLC (previously VMware, Inc. and individually and together with its consolidated subsidiaries, “VMware”) by Broadcom Inc. (“Broadcom”), VMware was considered a related party of the Company. Upon Broadcom’s acquisition of VMware, Michael Dell’s ownership interest in VMware and his position as Chairman of the Board of VMware terminated, and the Company determined no related party relationship exists with Broadcom or VMware effective as of November 22, 2023. The Company continues to engage in select transactions with VMware following the completion of Broadcom’s acquisition and the termination of the related party relationship. See Note 16 of the Notes to the Condensed Consolidated Financial Statements for additional information.

[0001571996-24-000143:notes:233]
Related Party Transactions with VMware

[0001571996-24-000143:notes:234]
The information provided below includes a summary of related party transactions with VMware for the three and nine months ended November 3, 2023.

[0001571996-24-000143:notes:235]
•Dell Technologies integrated or bundled select VMware products and services with Dell Technologies’ products and sold them to end-users. Dell Technologies also acted as a distributor, purchasing VMware’s standalone products and services for resale to end-user customers. Where applicable, costs under these arrangements were presented net of rebates received by Dell Technologies.

[0001571996-24-000143:notes:236]
•DFS provided financing to certain VMware end-users, which resulted in the recognition of amounts due to related parties on the Condensed Consolidated Statements of Financial Position. Associated financing fees were recorded to product net revenue on the Condensed Consolidated Statements of Income and were reflected within sales and leases of products to VMware in the table below.

[0001571996-24-000143:notes:237]
•Dell Technologies procured products and services from VMware for its internal use. For the three and nine months ended November 3, 2023, costs incurred associated with products and services purchased from VMware for internal use were immaterial.

[0001571996-24-000143:notes:238]
•Dell Technologies sold and leased products and sold services to VMware. For the three and nine months ended November 3, 2023, revenue recognized from sales of services to VMware was immaterial.

[0001571996-24-000143:notes:239]
•Dell Technologies and VMware entered into joint marketing, sales, and branding arrangements, for which both parties incurred costs. For the three and nine months ended November 3, 2023, consideration received from VMware for joint marketing, sales, and branding arrangements was immaterial.

[0001571996-24-000143:notes:240]
The following table presents information about the impact of Dell Technologies’ related party transactions with VMware on the Consolidated Statements of Income for the three and nine months ended November 3, 2023:

[0001571996-24-000143:notes:241]
|  |  |  |  |  | Three Months Ended |  |  |  | Nine Months Ended |
|  | Classification |  |  |  | November 3, 2023 |  |  |  | November 3, 2023 |  |  |
|  |  |  |  |  | (in millions) |
| Sales and leases of products to VMware | Net revenue — products |  |  |  | $ | 16 |  |  |  |  | $ | 94 |  |  |  |
| Purchase of VMware products for resale | Cost of net revenue — products |  |  |  | $ | 379 |  |  |  |  | $ | 970 |  |  |  |
| Purchase of VMware services for resale | Cost of net revenue — services |  |  |  | $ | 884 |  |  |  |  | $ | 2,640 |  |  |  |

[0001571996-24-000143:notes:242]
In connection with the completion of the VMware Spin-off described in Note 10 of the Notes to the Condensed Consolidated Financial Statements, Dell Technologies and VMware entered into a Tax Matters Agreement effective as of April 14, 2021 (the “Tax Matters Agreement”), which governs the respective rights and obligations of Dell Technologies and VMware regarding income and other taxes as well as related matters, including tax liabilities and benefits, attributes, and returns for periods both preceding and following the VMware Spin-off. Pursuant to the Tax Matters Agreement, net receipts from VMware during the nine months ended November 3, 2023 were immaterial.

[0001571996-24-000143:notes:243]
Other Related Parties

[0001571996-24-000143:notes:244]
Transactions with other related parties during the periods presented were immaterial, individually and in aggregate.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001571996-24-000143:notes:245]
[same as prior period, unchanged from 0001571996-24-000090:notes:237]

[0001571996-24-000143:notes:246]
[same as prior period, unchanged from 0001571996-24-000090:notes:238]

[0001571996-24-000143:notes:247]
[same as prior period, unchanged from 0001571996-24-000090:notes:239]

[0001571996-24-000143:notes:248]
[same as prior period, unchanged from 0001571996-24-000090:notes:240]

[0001571996-24-000143:notes:249]
Following its acquisition by Broadcom on November 22, 2023, VMware announced changes to its go-to-market approach for VMware offerings that impacted the Company’s commercial relationship with VMware. On March 25, 2024, the Company terminated the Commercial Framework Agreement with VMware, which provided the framework pursuant to which the Company and VMware continued the commercial relationship following the VMware Spin-off and under which Dell Technologies acted as a distributor of Broadcom’s VMware stand-alone products and services and purchased such products and services for resale to end-user customers (“VMware Resale”). Dell Technologies no longer acts as a distributor of VMware’s standalone products and services, though the Company will continue to support customers that have purchased resale offerings sold in prior periods. The results of VMware Resale transactions are reflected in other businesses. The Company continues to integrate and embed certain VMware products and services with select Dell Technologies’ offerings to end-users. The results of such offerings are reflected within CSG or ISG, depending upon the nature of the underlying offering sold.

[0001571996-24-000143:notes:250]
[same as prior period, unchanged from 0001571996-24-000090:notes:242]

[0001571996-24-000143:notes:251]
|  | Three Months Ended |  | Nine Months Ended |  |  |
|  | November 1, 2024 |  | November 3, 2023 |  | November 1, 2024 |  | November 3, 2023 |  |  |
|  | (in millions) |
| Consolidated net revenue: |  |  |  |  |  |  |  |  |  |
| Infrastructure Solutions Group | $ | 11,368 |  |  | $ | 8,499 |  |  | $ | 32,241 |  |  | $ | 24,553 |  |  |  |
| Client Solutions Group | 12,131 |  |  | 12,276 |  |  | 36,512 |  |  | 37,201 |  |  |  |
| Reportable segment net revenue | 23,499 |  |  | 20,775 |  |  | 68,753 |  |  | 61,754 |  |  |  |
| Other businesses (a) | 867 |  |  | 1,474 |  |  | 2,882 |  |  | 4,345 |  |  |  |
| Unallocated transactions (b) | — |  |  | 2 |  |  | 1 |  |  | 8 |  |  |  |
| Total consolidated net revenue | $ | 24,366 |  |  | $ | 22,251 |  |  | $ | 71,636 |  |  | $ | 66,107 |  |  |  |
| Consolidated operating income: |  |  |  |  |  |  |  |  |  |
| Infrastructure Solutions Group | $ | 1,508 |  |  | $ | 1,069 |  |  | $ | 3,528 |  |  | $ | 2,858 |  |  |  |
| Client Solutions Group | 694 |  |  | 925 |  |  | 2,193 |  |  | 2,786 |  |  |  |
| Reportable segment operating income | 2,202 |  |  | 1,994 |  |  | 5,721 |  |  | 5,644 |  |  |  |
| Other businesses (a) | (3) |  |  | (32) |  |  | (14) |  |  | (112) |  |  |  |
| Unallocated transactions (b) | — |  |  | 2 |  |  | — |  |  | 7 |  |  |  |
| Amortization of intangibles (c) | (168) |  |  | (207) |  |  | (504) |  |  | (623) |  |  |  |
| Stock-based compensation expense (d) | (198) |  |  | (227) |  |  | (599) |  |  | (675) |  |  |  |
| Other corporate expenses (e) | (165) |  |  | (44) |  |  | (674) |  |  | (521) |  |  |  |
| Total consolidated operating income | $ | 1,668 |  |  | $ | 1,486 |  |  | $ | 3,930 |  |  | $ | 3,720 |  |  |  |

[0001571996-24-000143:notes:252]
[same as prior period, unchanged from 0001571996-24-000090:notes:244]

[0001571996-24-000143:notes:253]
[same as prior period, unchanged from 0001571996-24-000090:notes:245]

[0001571996-24-000143:notes:254]
[same as prior period, unchanged from 0001571996-24-000090:notes:246]

[0001571996-24-000143:notes:255]
[same as prior period, unchanged from 0001571996-24-000090:notes:247]

[0001571996-24-000143:notes:256]
[same as prior period, unchanged from 0001571996-24-000090:notes:248]

[0001571996-24-000143:notes:257]
[same as prior period, unchanged from 0001571996-24-000090:notes:249]

[0001571996-24-000143:notes:258]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 1, 2024 |  | November 3, 2023 |  | November 1, 2024 |  | November 3, 2023 |  |  |
|  | (in millions) |
| Net revenue: |  |  |  |  |  |  |  |  |  |
| Infrastructure Solutions Group: |  |  |  |  |  |  |  |  |  |
| Servers and networking | $ | 7,364 |  |  | $ | 4,656 |  |  | $ | 20,502 |  |  | $ | 12,767 |  |  |  |
| Storage | 4,004 |  |  | 3,843 |  |  | 11,739 |  |  | 11,786 |  |  |  |
| Total ISG net revenue | $ | 11,368 |  |  | $ | 8,499 |  |  | $ | 32,241 |  |  | $ | 24,553 |  |  |  |
| Client Solutions Group: |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 10,138 |  |  | $ | 9,835 |  |  | $ | 30,848 |  |  | $ | 30,251 |  |  |  |
| Consumer | 1,993 |  |  | 2,441 |  |  | 5,664 |  |  | 6,950 |  |  |  |
| Total CSG net revenue | $ | 12,131 |  |  | $ | 12,276 |  |  | $ | 36,512 |  |  | $ | 37,201 |  |  |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001571996-24-000143:notes:259]
[same as prior period, unchanged from 0001571996-24-000090:notes:251]

[0001571996-24-000143:notes:260]
|  | November 1, 2024 |  | February 2, 2024 |
|  | (in millions) |
| Cash, cash equivalents, and restricted cash: |  |  |  |
| Cash and cash equivalents | $ | 5,225 |  |  | $ | 7,366 |  |
| Cash and cash equivalents — held for sale (a) | 53 |  |  | — |  |
| Restricted cash — other current assets (b) | 122 |  |  | 136 |  |
| Restricted cash — other non-current assets (b) | 4 |  |  | 5 |  |
| Total cash, cash equivalents, and restricted cash | $ | 5,404 |  |  | $ | 7,507 |  |
| Inventories: |  |  |  |
| Production materials | $ | 4,538 |  |  | $ | 2,321 |  |
| Work-in-process | 1,013 |  |  | 607 |  |
| Finished goods | 1,101 |  |  | 694 |  |
| Total inventories | $ | 6,652 |  |  | $ | 3,622 |  |
| Deferred costs: |  |  |  |
| Total deferred costs, current (c) | $ | 4,282 |  |  | $ | 5,548 |  |
| Property, plant, and equipment, net: |  |  |  |
| Assets in a customer contract | $ | 5,270 |  |  | $ | 5,022 |  |
| Computer and other equipment | 3,383 |  |  | 3,552 |  |
| Land and buildings | 2,816 |  |  | 2,877 |  |
| Internal use software | 2,336 |  |  | 2,166 |  |
| Total property, plant, and equipment | 13,805 |  |  | 13,617 |  |
| Accumulated depreciation and amortization | (7,478) |  |  | (7,185) |  |
| Total property, plant, and equipment, net | $ | 6,327 |  |  | $ | 6,432 |  |

[0001571996-24-000143:notes:261]
(a)    Held for sale represents the reclassification of Secureworks cash and cash equivalents to assets held for sale. See Note 1 of the Notes to the Condensed Consolidated Financial Statements for more information about the pending sale of Secureworks.

[0001571996-24-000143:notes:262]
(b)    Restricted cash primarily includes cash required to be held in escrow pursuant to DFS securitization arrangements.

[0001571996-24-000143:notes:263]
(c)    Deferred costs are included in other current assets in the Condensed Consolidated Statements of Financial Position. Amounts classified as long-term deferred costs are included in other non-current assets and are not disclosed above.

[0001571996-24-000143:notes:264]
[same as prior period, unchanged from 0001571996-24-000090:notes:255]

[0001571996-24-000143:notes:265]
[same as prior period, unchanged from 0001571996-24-000090:notes:256]

[0001571996-24-000143:notes:266]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 1, 2024 |  | November 3, 2023 |  | November 1, 2024 |  | November 3, 2023 |  |  |
|  | (in millions) |
| Warranty liability: |  |  |  |  |  |  |  |  |  |
| Warranty liability at beginning of period | $ | 439 |  |  | $ | 439 |  |  | $ | 426 |  |  | $ | 467 |  |  |  |
| Costs accrued for new warranty contracts and changes in estimates for pre-existing warranties (a) | 228 |  |  | 208 |  |  | 673 |  |  | 605 |  |  |  |
| Service obligations honored | (239) |  |  | (203) |  |  | (671) |  |  | (628) |  |  |  |
| Warranty liability at end of period | $ | 428 |  |  | $ | 444 |  |  | $ | 428 |  |  | $ | 444 |  |  |  |

[0001571996-24-000143:notes:267]
[same as prior period, unchanged from 0001571996-24-000090:notes:258]

[0001571996-24-000143:notes:268]
[same as prior period, unchanged from 0001571996-24-000090:notes:259]

[0001571996-24-000143:notes:269]
[same as prior period, unchanged from 0001571996-24-000090:notes:260]

[0001571996-24-000143:notes:270]
[same as prior period, unchanged from 0001571996-24-000090:notes:261]

[0001571996-24-000143:notes:271]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 1, 2024 |  | November 3, 2023 |  | November 1, 2024 |  | November 3, 2023 |  |  |
|  | (in millions) |
| Severance liability: |  |  |  |  |  |  |  |  |  |
| Severance liability at beginning of period | $ | 392 |  |  | $ | 457 |  |  | $ | 352 |  |  | $ | 408 |  |  |  |
| Severance charges | 145 |  |  | 22 |  |  | 565 |  |  | 434 |  |  |  |
| Cash paid and other | (296) |  |  | (277) |  |  | (676) |  |  | (640) |  |  |  |
| Severance liability at end of period | $ | 241 |  |  | $ | 202 |  |  | $ | 241 |  |  | $ | 202 |  |  |  |

[0001571996-24-000143:notes:272]
[same as prior period, unchanged from 0001571996-24-000090:notes:263]

[0001571996-24-000143:notes:273]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 1, 2024 |  | November 3, 2023 |  | November 1, 2024 |  | November 3, 2023 |  |  |
|  | (in millions) |
| Severance charges: |  |  |  |  |  |  |  |  |  |
| Cost of net revenue | $ | 31 |  |  | $ | 7 |  |  | $ | 116 |  |  | $ | 54 |  |  |  |
| Selling, general, and administrative | 71 |  |  | 14 |  |  | 341 |  |  | 365 |  |  |  |
| Research and development | 43 |  |  | 1 |  |  | 108 |  |  | 15 |  |  |  |
| Total severance charges | $ | 145 |  |  | $ | 22 |  |  | $ | 565 |  |  | $ | 434 |  |  |  |

[0001571996-24-000143:notes:274]
[same as prior period, unchanged from 0001571996-24-000090:notes:265]

[0001571996-24-000143:notes:275]
The Company maintains a Supply Chain Finance Program (the “SCF Program”), which enables eligible suppliers, at the supplier's sole discretion, to sell receivables due from the Company to a third-party financial institution. The Company has no involvement in establishing the terms or conditions of the arrangement between its suppliers and the financial institution, no economic interest in a supplier's decision to sell a receivable, and does not provide legally secured assets or other forms of guarantees under the arrangement. The SCF Program does not impact the Company's liquidity as payments for participating supplier invoices are remitted by the Company to the financial institution on the original invoice due date, regardless of whether an individual invoice is sold by the supplier to the financial institution. As of November 1, 2024 and February 2, 2024, the Company had $1.4 billion and $1.1 billion, respectively, included within accounts payable on the Condensed Consolidated Statements of Financial Position representing invoices due to suppliers confirmed as valid under the SCF Program.

[0001571996-24-000143:notes:276]
[same as prior period, unchanged from 0001571996-24-000090:notes:267]

[0001571996-24-000143:notes:277]
[same as prior period, unchanged from 0001571996-24-000090:notes:268]

[0001571996-24-000143:notes:278]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 1, 2024 |  | November 3, 2023 |  | November 1, 2024 |  | November 3, 2023 |  |  |
|  | (in millions) |
| Interest and other, net: |  |  |  |  |  |  |  |  |  |
| Investment income, primarily interest | $ | 35 |  |  | $ | 88 |  |  | $ | 127 |  |  | $ | 213 |  |  |  |
| Gain (loss) on investments, net | 46 |  |  | 8 |  |  | 21 |  |  | (36) |  |  |  |
| Interest expense | (321) |  |  | (371) |  |  | (1,051) |  |  | (1,128) |  |  |  |
| Foreign exchange | (29) |  |  | (30) |  |  | (80) |  |  | (127) |  |  |  |
| Other | (7) |  |  | (1) |  |  | (19) |  |  | (43) |  |  |  |
| Total interest and other, net | $ | (276) |  |  | $ | (306) |  |  | $ | (1,002) |  |  | $ | (1,121) |  |  |  |


## us-gaap:SubsequentEventsTextBlock

[0001571996-24-000143:notes:279]
SUBSEQUENT EVENTS 
There were no known events occurring after November 1, 2024, and up until the date of issuance of this report that would materially affect the information presented herein.
