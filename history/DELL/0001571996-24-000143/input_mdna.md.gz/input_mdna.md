# DELL MD&A — 0001571996-24-000143


## mdna

[0001571996-24-000143:mdna:1]
[same as prior period, unchanged from 0001571996-24-000090:mdna:1]

[0001571996-24-000143:mdna:2]
[same as prior period, unchanged from 0001571996-24-000090:mdna:2]

[0001571996-24-000143:mdna:3]
[same as prior period, unchanged from 0001571996-24-000090:mdna:3]

[0001571996-24-000143:mdna:4]
[same as prior period, unchanged from 0001571996-24-000090:mdna:4]

[0001571996-24-000143:mdna:5]
[same as prior period, unchanged from 0001571996-24-000090:mdna:5]

[0001571996-24-000143:mdna:6]
[same as prior period, unchanged from 0001571996-24-000090:mdna:6]

[0001571996-24-000143:mdna:7]
[same as prior period, unchanged from 0001571996-24-000090:mdna:7]

[0001571996-24-000143:mdna:8]
[same as prior period, unchanged from 0001571996-24-000090:mdna:8]

[0001571996-24-000143:mdna:9]
[same as prior period, unchanged from 0001571996-24-000090:mdna:9]

[0001571996-24-000143:mdna:10]
[same as prior period, unchanged from 0001571996-24-000090:mdna:10]

[0001571996-24-000143:mdna:11]
Our “other businesses” primarily consist of our resale of standalone offerings of VMware LLC (formerly “VMware, Inc.” and individually and together with its subsidiaries, “VMware”), referred to as “VMware Resale,” and offerings of SecureWorks Corp. (“Secureworks”). In October 2024, Secureworks announced that it has entered into a definitive agreement pursuant to which Sophos Inc., an affiliate of Thoma Bravo, L.P., a private equity and growth capital firm, will acquire Secureworks in an all-cash transaction for approximately $0.9 billion, subject to certain closing adjustments. The transaction is expected to close in early 2025, subject to customary closing conditions. Our other businesses are not classified as reportable segments, either individually or collectively.

[0001571996-24-000143:mdna:12]
[same as prior period, unchanged from 0001571996-24-000090:mdna:12]

[0001571996-24-000143:mdna:13]
[same as prior period, unchanged from 0001571996-24-000090:mdna:13]

[0001571996-24-000143:mdna:14]
[same as prior period, unchanged from 0001571996-24-000090:mdna:14]

[0001571996-24-000143:mdna:15]
During the third quarter and first nine months of Fiscal 2025, the following trends and conditions continued to affect the environment in which we operate:

[0001571996-24-000143:mdna:16]
•Macroeconomic environment: The demand environment continued to remain strong for our servers and networking offerings, which resulted in overall net revenue growth. Additionally, we began to see modest demand improvement for our commercial offerings.

[0001571996-24-000143:mdna:17]
•Demand for AI-optimized solutions: Our ISG business continued to benefit from increased demand for AI-optimized solutions as customers continue to adopt and further integrate AI into their operations. As a result of the continued strong demand for our AI-optimized servers, backlog levels for such offerings remained elevated as we exited the quarter.

[0001571996-24-000143:mdna:18]
•Supply chain: Notwithstanding the increased demand for AI-optimized solutions, our supply chain continued to operate efficiently. We experienced an increase in input costs primarily driven by higher logistics costs, the effect of which was partially offset by favorability in component costs. Compared to the prior quarter, we began to observe an inflationary environment. Input costs primarily consist of both component and logistics costs.

[0001571996-24-000143:mdna:19]
•Broadcom’s acquisition of VMware: On November 22, 2023, Broadcom Inc. (“Broadcom”) completed its acquisition of VMware, leading to changes to our relationship with VMware as described below.

[0001571996-24-000143:mdna:20]
We expect the demand environment will continue to remain strong in our servers and networking offerings, which we expect will result in ISG net revenue growth across our AI-optimized and traditional servers for the fourth quarter of Fiscal 2025. We expect modest CSG net revenue growth for the fourth quarter of Fiscal 2025 depending on the timing of the anticipated PC refresh cycle and a competitive pricing environment. Additionally, we expect a continued reduction of our other businesses’ net revenue as we no longer act as a distributor of VMware’s standalone products and services.

[0001571996-24-000143:mdna:21]
We expect input costs to increase during the fourth quarter of Fiscal 2025, principally driven by anticipated inflation for component costs. Input cost trends are dependent on the strength or weakness of actual end-user demand and supply dynamics, which will continue to fluctuate and ultimately impact our costs, pricing, and operating results.

[0001571996-24-000143:mdna:22]
[same as prior period, unchanged from 0001571996-24-000090:mdna:22]

[0001571996-24-000143:mdna:23]
We continue to advance our own capabilities to change the way we work and make decisions, improve business outcomes and the customer experience, and reduce costs by leveraging new technology and optimizing business processes. We remain committed to disciplined cost management in coordination with our ongoing business transformation initiatives and will continue to take certain measures to reduce costs, including limitation of external hiring, employee reorganizations, and other actions to align our investments with our strategic priorities and customer needs. We anticipate these actions will result in a continued reduction in our overall headcount. We believe our unique operating advantages provide a foundation to foster growth, drive efficiencies, and continue to position us for long-term success.

[0001571996-24-000143:mdna:24]
Relationship with VMware — On November 22, 2023, VMware was acquired by Broadcom, and subsequently announced changes to its go-to-market approach for VMware offerings that impacted our commercial relationship with VMware. On March 25, 2024, we terminated our Commercial Framework Agreement with VMware, which provided the framework under which we and VMware continued our commercial relationship following our spin-off of VMware on November 1, 2021. We no longer act as a distributor of Broadcom’s VMware standalone products and services, though we will continue to support customers that have purchased resale offerings sold in prior periods. We continue to integrate and embed certain VMware products and services with select Dell Technologies’ offerings to end-users, such as through our VxRail solution. The results of such offerings are reflected within CSG or ISG, depending upon the nature of the underlying offering sold.

[0001571996-24-000143:mdna:25]
VMware was a related party until the date of its acquisition by Broadcom. The acquisition terminated the preexisting related party relationship with VMware such that no related party relationship exists with either Broadcom or VMware effective as of November 22, 2023. For more information regarding the impact of the Broadcom acquisition of VMware and our prior related party transactions with VMware, see Note 15 of the Notes to the Condensed Consolidated Financial Statements included in this report.

[0001571996-24-000143:mdna:26]
ISG — We expect that ISG will continue to be impacted by the evolving nature of the IT infrastructure market and competitive environment. With our scale and strong solutions portfolio, we believe we are well-positioned to address the ongoing competitive dynamics and trends in technology and customer needs. Through our collaborative, customer-focused approach to innovation, we strive to deliver new and relevant solutions and software to our customers quickly and efficiently. We continue to focus on customer base expansion and the lifetime value of customer relationships. We anticipate that ISG will continue to benefit from technology advancements and customer interest in AI and we are well-positioned to capture growth and support our customers’ needs.

[0001571996-24-000143:mdna:27]
[same as prior period, unchanged from 0001571996-24-000090:mdna:27]

[0001571996-24-000143:mdna:28]
CSG — We participate in all segments of the PC market with a focus on commercial and high-end consumer computing devices, as we believe they represent the most stable and profitable markets. We anticipate that CSG will benefit from advances in AI over the long-term as customers will require PCs with the ability to run their complex AI workloads.

[0001571996-24-000143:mdna:29]
Competitive dynamics remain an important factor in our CSG business and continue to impact pricing and operating results. We are committed to our long-term CSG strategy and will continue to make investments to innovate across the portfolio. We expect that the CSG demand environment will be subject to seasonal trends as well as the timing of the anticipated PC refresh cycle.

[0001571996-24-000143:mdna:30]
[same as prior period, unchanged from 0001571996-24-000090:mdna:30]

[0001571996-24-000143:mdna:31]
[same as prior period, unchanged from 0001571996-24-000090:mdna:31]

[0001571996-24-000143:mdna:32]
Foreign Currency Exposure — We manage our business on a U.S. Dollar basis. However, we have a large global presence, generating approximately half of our net revenue from sales to customers outside of the United States during the third quarter and first nine months of Fiscal 2025 and Fiscal 2024. As a result, our operating results can be, and particularly in recent periods have been, impacted by fluctuations in foreign currency exchange rates. We utilize a comprehensive hedging strategy intended to mitigate the impact of foreign currency volatility over time, and we adjust pricing when possible to further minimize foreign currency impacts.

[0001571996-24-000143:mdna:33]
[same as prior period, unchanged from 0001571996-24-000090:mdna:33]

[0001571996-24-000143:mdna:34]
[same as prior period, unchanged from 0001571996-24-000090:mdna:46]

[0001571996-24-000143:mdna:35]
[same as prior period, unchanged from 0001571996-24-000090:mdna:35]

[0001571996-24-000143:mdna:36]
[same as prior period, unchanged from 0001571996-24-000090:mdna:36]

[0001571996-24-000143:mdna:37]
[same as prior period, unchanged from 0001571996-24-000090:mdna:37]

[0001571996-24-000143:mdna:38]
[same as prior period, unchanged from 0001571996-24-000090:mdna:38]

[0001571996-24-000143:mdna:39]
[same as prior period, unchanged from 0001571996-24-000090:mdna:39]

[0001571996-24-000143:mdna:40]
[same as prior period, unchanged from 0001571996-24-000090:mdna:40]

[0001571996-24-000143:mdna:41]
[same as prior period, unchanged from 0001571996-24-000090:mdna:41]

[0001571996-24-000143:mdna:42]
[same as prior period, unchanged from 0001571996-24-000090:mdna:42]

[0001571996-24-000143:mdna:43]
•Other Corporate Expenses — Other corporate expenses consist primarily of severance expenses, payroll taxes associated with stock-based compensation, transaction-related expenses, facility action costs, impairment charges, and incentive charges related to equity investments. Severance costs are primarily related to severance and benefits for employees terminated pursuant to cost management initiatives. During the first nine months of Fiscal 2025 and Fiscal 2024, we recognized $0.6 billion and $0.4 billion of severance expense related to workforce reduction activities. Transaction-related expenses typically consist of acquisition, integration, and divestitures related costs, primarily representing costs for legal, banking, consulting, and advisory services, and are expensed as incurred. Although we may incur these types of expenses in the future, we exclude other corporate expenses as they can vary from period to period, are significantly impacted by the timing and nature of these events, and are not used by management in assessing operating performance of the business.

[0001571996-24-000143:mdna:44]
[same as prior period, unchanged from 0001571996-24-000090:mdna:44]

[0001571996-24-000143:mdna:45]
•Aggregate Adjustment for Income Taxes — The aggregate adjustment for income taxes is the estimated combined income tax effect for the adjustments described above and determined based on the tax jurisdictions where those adjustments were incurred, as well as an adjustment for discrete tax items. During the first nine months of Fiscal 2025, the aggregate adjustment for income taxes included discrete tax benefits of $0.4 billion related to changes in uncertain tax benefits resulting from the expiration of certain statutes of limitations and $0.2 billion related to stock-based compensation. We exclude these benefits or charges for purposes of calculating non-GAAP net income due to the variability in recognition of discrete tax items from period to period. The tax effects are determined based on the tax jurisdictions where the above items were incurred. See Note 11 of the Notes to the Condensed Consolidated Financial Statements included in this report for additional information about our income taxes. Beginning in Fiscal 2025, our non-GAAP income tax is calculated using a fixed estimated annual tax rate which is determined based on historical trends and projections for the current fiscal year. We may adjust our estimated annual tax rate during the fiscal year to take into account events that would significantly impact our income tax expense, including significant changes resulting from tax legislation, material changes in geographic mix of revenue and expenses, changes to our corporate structure, and other significant events.

[0001571996-24-000143:mdna:46]
[same as prior period, unchanged from 0001571996-24-000090:mdna:51]

[0001571996-24-000143:mdna:47]
[same as prior period, unchanged from 0001571996-24-000090:mdna:47]

[0001571996-24-000143:mdna:48]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 1, 2024 |  | % Change |  | November 3, 2023 |  | November 1, 2024 |  | % Change |  | November 3, 2023 |  |  |  |  |
|  | (in millions, except percentages) |  |  |  |  |
| Product gross margin | $ | 2,749 |  |  | 2 | % |  | $ | 2,687 |  |  | $ | 7,985 |  |  | (4) | % |  | $ | 8,281 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 60 |  |  |  |  | 84 |  |  | 179 |  |  |  |  | 247 |  |  |  |  |  |
| Stock-based compensation expense | 14 |  |  |  |  | 12 |  |  | 42 |  |  |  |  | 38 |  |  |  |  |  |
| Other corporate expenses | 4 |  |  |  |  | — |  |  | 14 |  |  |  |  | 15 |  |  |  |  |  |
| Non-GAAP product gross margin | $ | 2,827 |  |  | 2 | % |  | $ | 2,783 |  |  | $ | 8,220 |  |  | (4) | % |  | $ | 8,581 |  |  |  |  |  |
| Services gross margin | $ | 2,558 |  |  | 4 | % |  | $ | 2,461 |  |  | $ | 7,439 |  |  | 2 | % |  | $ | 7,272 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense | 25 |  |  |  |  | 25 |  |  | 73 |  |  |  |  | 74 |  |  |  |  |  |
| Other corporate expenses | 27 |  |  |  |  | 7 |  |  | 116 |  |  |  |  | 49 |  |  |  |  |  |
| Non-GAAP services gross margin | $ | 2,610 |  |  | 5 | % |  | $ | 2,493 |  |  | $ | 7,628 |  |  | 3 | % |  | $ | 7,395 |  |  |  |  |  |
| Gross margin | $ | 5,307 |  |  | 3 | % |  | $ | 5,148 |  |  | $ | 15,424 |  |  | (1) | % |  | $ | 15,553 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 60 |  |  |  |  | 84 |  |  | 179 |  |  |  |  | 247 |  |  |  |  |  |
| Stock-based compensation expense | 39 |  |  |  |  | 37 |  |  | 115 |  |  |  |  | 112 |  |  |  |  |  |
| Other corporate expenses | 31 |  |  |  |  | 7 |  |  | 130 |  |  |  |  | 64 |  |  |  |  |  |
| Non-GAAP gross margin | $ | 5,437 |  |  | 3 | % |  | $ | 5,276 |  |  | $ | 15,848 |  |  | (1) | % |  | $ | 15,976 |  |  |  |  |  |
| Operating expenses | $ | 3,639 |  |  | (1) | % |  | $ | 3,662 |  |  | $ | 11,494 |  |  | (3) | % |  | $ | 11,833 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | (108) |  |  |  |  | (123) |  |  | (325) |  |  |  |  | (376) |  |  |  |  |  |
| Stock-based compensation expense | (159) |  |  |  |  | (190) |  |  | (484) |  |  |  |  | (563) |  |  |  |  |  |
| Other corporate expenses | (134) |  |  |  |  | (37) |  |  | (544) |  |  |  |  | (457) |  |  |  |  |  |
| Non-GAAP operating expenses | $ | 3,238 |  |  | (2) | % |  | $ | 3,312 |  |  | $ | 10,141 |  |  | (3) | % |  | $ | 10,437 |  |  |  |  |  |

[0001571996-24-000143:mdna:49]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 1, 2024 |  | % Change |  | November 3, 2023 |  | November 1, 2024 |  | % Change |  | November 3, 2023 |  |  |  |  |
|  | (in millions, except percentages and per share amounts) |  |  |  |  |
| Operating income | $ | 1,668 |  |  | 12 | % |  | $ | 1,486 |  |  | $ | 3,930 |  |  | 6 | % |  | $ | 3,720 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 168 |  |  |  |  | 207 |  |  | 504 |  |  |  |  | 623 |  |  |  |  |  |
| Stock-based compensation expense | 198 |  |  |  |  | 227 |  |  | 599 |  |  |  |  | 675 |  |  |  |  |  |
| Other corporate expenses | 165 |  |  |  |  | 44 |  |  | 674 |  |  |  |  | 521 |  |  |  |  |  |
| Non-GAAP operating income | $ | 2,199 |  |  | 12 | % |  | $ | 1,964 |  |  | $ | 5,707 |  |  | 3 | % |  | $ | 5,539 |  |  |  |  |  |
| Net income | $ | 1,127 |  |  | 12 | % |  | $ | 1,004 |  |  | $ | 2,923 |  |  | 43 | % |  | $ | 2,037 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 168 |  |  |  |  | 207 |  |  | 504 |  |  |  |  | 623 |  |  |  |  |  |
| Stock-based compensation expense | 198 |  |  |  |  | 227 |  |  | 599 |  |  |  |  | 675 |  |  |  |  |  |
| Other corporate expenses | 166 |  |  |  |  | 36 |  |  | 665 |  |  |  |  | 566 |  |  |  |  |  |
| Fair value adjustments on equity investments | (46) |  |  |  |  | (8) |  |  | (21) |  |  |  |  | 36 |  |  |  |  |  |
| Aggregate adjustment for income taxes | (73) |  |  |  |  | (77) |  |  | (836) |  |  |  |  | (302) |  |  |  |  |  |
| Non-GAAP net income | $ | 1,540 |  |  | 11 | % |  | $ | 1,389 |  |  | $ | 3,834 |  |  | 5 | % |  | $ | 3,635 |  |  |  |  |  |
| Earnings per share attributable to Dell Technologies Inc. — diluted | $ | 1.58 |  |  | 16 | % |  | $ | 1.36 |  |  | $ | 4.07 |  |  | 46 | % |  | $ | 2.78 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 0.23 |  |  |  |  | 0.28 |  |  | 0.70 |  |  |  |  | 0.84 |  |  |  |  |  |
| Stock-based compensation expense | 0.28 |  |  |  |  | 0.31 |  |  | 0.83 |  |  |  |  | 0.91 |  |  |  |  |  |
| Other corporate expenses | 0.23 |  |  |  |  | 0.04 |  |  | 0.92 |  |  |  |  | 0.77 |  |  |  |  |  |
| Fair value adjustments on equity investments | (0.06) |  |  |  |  | (0.01) |  |  | (0.03) |  |  |  |  | 0.05 |  |  |  |  |  |
| Aggregate adjustment for income taxes | (0.10) |  |  |  |  | (0.10) |  |  | (1.16) |  |  |  |  | (0.41) |  |  |  |  |  |
| Total non-GAAP adjustments attributable to non-controlling interests | (0.01) |  |  |  |  | — |  |  | (0.02) |  |  |  |  | (0.01) |  |  |  |  |  |
| Non-GAAP earnings per share attributable to Dell Technologies Inc. — diluted | $ | 2.15 |  |  | 14 | % |  | $ | 1.88 |  |  | $ | 5.31 |  |  | 8 | % |  | $ | 4.93 |  |  |  |  |  |

[0001571996-24-000143:mdna:50]
[same as prior period, unchanged from 0001571996-24-000090:mdna:67]

[0001571996-24-000143:mdna:51]
In addition to the above measures, we use free cash flow and adjusted free cash flow as non-GAAP liquidity measures to evaluate our performance. As presented in the following table, we define free cash flow as cash flow from operations after excluding capital expenditures and capitalized software costs, net. To measure adjusted free cash flow, we exclude the impact of financing receivables and equipment under operating leases from free cash flow, as the initial funding of these DFS offerings at the time of origination is largely subsequently replaced with cash inflows from our DFS debt, the majority of which is asset-backed.

[0001571996-24-000143:mdna:52]
[same as prior period, unchanged from 0001571996-24-000090:mdna:53]

[0001571996-24-000143:mdna:53]
As is the case with the other non-GAAP measures presented above, users should consider the limitations of using free cash flow and adjusted free cash flow, including the fact that those measures do not provide a complete measure of our cash flows for any period. Free cash flow and adjusted free cash flow do not purport to be alternatives to cash flows from operating activities as a measure of liquidity. In particular, free cash flow and adjusted free cash flow are not intended to be a measure of cash flow available for management’s discretionary use, as these measures do not reflect certain cash requirements, such as debt service requirements and other contractual commitments.

[0001571996-24-000143:mdna:54]
The following table presents a reconciliation of free cash flow and adjusted free cash flow to cash flow from operations for the periods indicated:

[0001571996-24-000143:mdna:55]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 1, 2024 |  | % Change |  | November 3, 2023 |  | November 1, 2024 |  | % Change |  | November 3, 2023 |  |  |  |  |
|  | (in millions, except percentages) |  |  |  |  |
| Cash flow from operations | $ | 1,553 |  |  | (28) | % |  | $ | 2,152 |  |  | $ | 3,936 |  |  | (45) | % |  | $ | 7,143 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Capital expenditures and capitalized software development costs, net (a) | (639) |  |  |  |  | (704) |  |  | (1,861) |  |  |  |  | (2,026) |  |  |  |  |  |
| Free cash flow | $ | 914 |  |  | (37) | % |  | $ | 1,448 |  |  | $ | 2,075 |  |  | (59) | % |  | $ | 5,117 |  |  |  |  |  |
| Free cash flow | $ | 914 |  |  | (37) | % |  | $ | 1,448 |  |  | $ | 2,075 |  |  | (59) | % |  | $ | 5,117 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Financing receivables (b) | (233) |  |  |  |  | (575) |  |  | 419 |  |  |  |  | (445) |  |  |  |  |  |
| Equipment under operating leases (c) | 35 |  |  |  |  | (13) |  |  | 129 |  |  |  |  | (75) |  |  |  |  |  |
| Adjusted free cash flow | $ | 716 |  |  | (17) | % |  | $ | 860 |  |  | $ | 2,623 |  |  | (43) | % |  | $ | 4,597 |  |  |  |  |  |

[0001571996-24-000143:mdna:56]
[same as prior period, unchanged from 0001571996-24-000090:mdna:57]

[0001571996-24-000143:mdna:57]
(a)    Capital expenditures and capitalized software development costs, net includes proceeds from sales of facilities, land, and other assets.

[0001571996-24-000143:mdna:58]
[same as prior period, unchanged from 0001571996-24-000090:mdna:59]

[0001571996-24-000143:mdna:59]
[same as prior period, unchanged from 0001571996-24-000090:mdna:60]

[0001571996-24-000143:mdna:60]
61

[0001571996-24-000143:mdna:61]
[same as prior period, unchanged from 0001571996-24-000090:mdna:62]

[0001571996-24-000143:mdna:62]
[same as prior period, unchanged from 0001571996-24-000090:mdna:63]

[0001571996-24-000143:mdna:63]
[same as prior period, unchanged from 0001571996-24-000090:mdna:64]

[0001571996-24-000143:mdna:64]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 1, 2024 |  |  |  | November 3, 2023 |  | November 1, 2024 |  |  |  | November 3, 2023 |  |  |  |  |
|  | Dollars |  | % of Net Revenue |  | % Change |  | Dollars |  | % of Net Revenue |  | Dollars |  | % of Net Revenue |  | % Change |  | Dollars |  | % of Net Revenue |  |  |  |  |  |  |
|  | (in millions, except percentages and per share amounts) |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products | $ | 18,290 |  |  | 75.1 | % |  | 13 | % |  | $ | 16,233 |  |  | 73.0 | % |  | $ | 53,371 |  |  | 74.5 | % |  | 11 | % |  | $ | 48,204 |  |  | 72.9 | % |  |  |  |  |  |  |
| Services | 6,076 |  |  | 24.9 | % |  | 1 | % |  | 6,018 |  |  | 27.0 | % |  | 18,265 |  |  | 25.5 | % |  | 2 | % |  | 17,903 |  |  | 27.1 | % |  |  |  |  |  |  |
| Total net revenue | $ | 24,366 |  |  | 100.0 | % |  | 10 | % |  | $ | 22,251 |  |  | 100.0 | % |  | $ | 71,636 |  |  | 100.0 | % |  | 8 | % |  | $ | 66,107 |  |  | 100.0 | % |  |  |  |  |  |  |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products | $ | 2,749 |  |  | 15.0 | % |  | 2 | % |  | $ | 2,687 |  |  | 16.6 | % |  | $ | 7,985 |  |  | 15.0 | % |  | (4) | % |  | $ | 8,281 |  |  | 17.2 | % |  |  |  |  |  |  |
| Services | 2,558 |  |  | 42.1 | % |  | 4 | % |  | 2,461 |  |  | 40.9 | % |  | 7,439 |  |  | 40.7 | % |  | 2 | % |  | 7,272 |  |  | 40.6 | % |  |  |  |  |  |  |
| Total gross margin | $ | 5,307 |  |  | 21.8 | % |  | 3 | % |  | $ | 5,148 |  |  | 23.1 | % |  | $ | 15,424 |  |  | 21.5 | % |  | (1) | % |  | $ | 15,553 |  |  | 23.5 | % |  |  |  |  |  |  |
| Operating expenses | $ | 3,639 |  |  | 15.0 | % |  | (1) | % |  | $ | 3,662 |  |  | 16.4 | % |  | $ | 11,494 |  |  | 16.0 | % |  | (3) | % |  | $ | 11,833 |  |  | 17.9 | % |  |  |  |  |  |  |
| Operating income | $ | 1,668 |  |  | 6.8 | % |  | 12 | % |  | $ | 1,486 |  |  | 6.7 | % |  | $ | 3,930 |  |  | 5.5 | % |  | 6 | % |  | $ | 3,720 |  |  | 5.6 | % |  |  |  |  |  |  |
| Net income | $ | 1,127 |  |  | 4.6 | % |  | 12 | % |  | $ | 1,004 |  |  | 4.5 | % |  | $ | 2,923 |  |  | 4.1 | % |  | 43 | % |  | $ | 2,037 |  |  | 3.1 | % |  |  |  |  |  |  |
| Earnings per share attributable to Dell Technologies — diluted | $ | 1.58 |  |  |  |  | 16 | % |  | $ | 1.36 |  |  |  |  | $ | 4.07 |  |  |  |  | 46 | % |  | $ | 2.78 |  |  |  |  |  |  |  |  |  |
| Cash flow from operations | $ | 1,553 |  |  |  |  | (28) | % |  | $ | 2,152 |  |  |  |  | $ | 3,936 |  |  |  |  | (45) | % |  | $ | 7,143 |  |  |  |  |  |  |  |  |  |
| Non-GAAP Financial Information |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | Three Months Ended |  | Nine Months Ended |
|  | November 1, 2024 |  |  |  | November 3, 2023 |  | November 1, 2024 |  |  |  | November 3, 2023 |  |  |  |  |
|  | Dollars |  | % of Net Revenue |  | % Change |  | Dollars |  | % of Net Revenue |  | Dollars |  | % of Net Revenue |  | % Change |  | Dollars |  | % of Net Revenue |  |  |  |  |  |  |
|  | (in millions, except percentages and per share amounts) |
| Non-GAAP gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products | $ | 2,827 |  |  | 15.5 | % |  | 2 | % |  | $ | 2,783 |  |  | 17.1 | % |  | $ | 8,220 |  |  | 15.4 | % |  | (4) | % |  | $ | 8,581 |  |  | 17.8 | % |  |  |  |  |  |  |
| Services | 2,610 |  |  | 43.0 | % |  | 5 | % |  | 2,493 |  |  | 41.4 | % |  | 7,628 |  |  | 41.8 | % |  | 3 | % |  | 7,395 |  |  | 41.3 | % |  |  |  |  |  |  |
| Total non-GAAP gross margin | $ | 5,437 |  |  | 22.3 | % |  | 3 | % |  | $ | 5,276 |  |  | 23.7 | % |  | $ | 15,848 |  |  | 22.1 | % |  | (1) | % |  | $ | 15,976 |  |  | 24.2 | % |  |  |  |  |  |  |
| Non-GAAP operating expenses | $ | 3,238 |  |  | 13.3 | % |  | (2) | % |  | $ | 3,312 |  |  | 14.9 | % |  | $ | 10,141 |  |  | 14.1 | % |  | (3) | % |  | $ | 10,437 |  |  | 15.8 | % |  |  |  |  |  |  |
| Non-GAAP operating income | $ | 2,199 |  |  | 9.0 | % |  | 12 | % |  | $ | 1,964 |  |  | 8.8 | % |  | $ | 5,707 |  |  | 8.0 | % |  | 3 | % |  | $ | 5,539 |  |  | 8.4 | % |  |  |  |  |  |  |
| Non-GAAP net income | $ | 1,540 |  |  | 6.3 | % |  | 11 | % |  | $ | 1,389 |  |  | 6.2 | % |  | $ | 3,834 |  |  | 5.4 | % |  | 5 | % |  | $ | 3,635 |  |  | 5.5 | % |  |  |  |  |  |  |
| Non-GAAP earnings per share attributable to Dell Technologies — diluted | $ | 2.15 |  |  |  |  | 14 | % |  | $ | 1.88 |  |  |  |  | $ | 5.31 |  |  |  |  | 8 | % |  | $ | 4.93 |  |  |  |  |  |  |  |  |  |
| Free cash flow | $ | 914 |  |  |  |  | (37) | % |  | $ | 1,448 |  |  |  |  | $ | 2,075 |  |  |  |  | (59) | % |  | $ | 5,117 |  |  |  |  |  |  |  |  |  |
| Adjusted free cash flow | $ | 716 |  |  |  |  | (17) | % |  | $ | 860 |  |  |  |  | $ | 2,623 |  |  |  |  | (43) | % |  | $ | 4,597 |  |  |  |  |  |  |  |  |  |

[0001571996-24-000143:mdna:65]
[same as prior period, unchanged from 0001571996-24-000090:mdna:66]

[0001571996-24-000143:mdna:66]
[same as prior period, unchanged from 0001571996-24-000090:mdna:85]

[0001571996-24-000143:mdna:67]
[same as prior period, unchanged from 0001571996-24-000090:mdna:68]

[0001571996-24-000143:mdna:68]
During the third quarter and first nine months of Fiscal 2025, net revenue increased by 10% and 8%, respectively, driven by an increase in ISG net revenue that was partially offset by a decrease in other businesses net revenue and, to a lesser extent, CSG net revenue. The increase in ISG net revenue was driven by growth in our servers and networking offerings. Other businesses net revenue declined primarily due to a decrease in VMware Resale revenue as we no longer act as a distributor of standalone VMware offerings. The decline in CSG net revenue was attributable to a decrease in sales of our consumer offerings.

[0001571996-24-000143:mdna:69]
During the third quarter of Fiscal 2025, both operating income and non-GAAP operating income increased by 12%, to $1.7 billion and $2.2 billion, respectively. During the first nine months of Fiscal 2025, operating income and non-GAAP operating income increased by 6% to $3.9 billion and 3% to $5.7 billion, respectively. During both the third quarter and first nine months of Fiscal 2025, the increases in operating income and non-GAAP operating income were primarily attributable to an increase in ISG operating income driven by our servers and networking offerings, which was largely offset by a decrease in CSG operating income.

[0001571996-24-000143:mdna:70]
During the third quarter of Fiscal 2025, operating income and non-GAAP operating income as a percentage of net revenue increased 10 basis points to 6.8% and increased 20 basis points to 9.0%, respectively. During the first nine months of Fiscal 2025, operating income and non-GAAP operating income as a percentage of net revenue decreased 10 basis points to 5.5% and 40 basis points to 8.0%, respectively. Operating income and non-GAAP operating income as a percentage of net revenue during both the third quarter and first nine months of Fiscal 2025 were impacted by a decline in gross margin as a percentage of net revenue due to a shift in mix towards AI-optimized server offerings and a competitive CSG pricing environment. The decline in gross margin as a percentage of net revenue was offset by the favorable impact of a decrease in operating expense rate that was driven by strong ISG net revenue growth coupled with continued disciplined cost management.

[0001571996-24-000143:mdna:71]
Cash provided by operating activities was $3.9 billion during the first nine months of Fiscal 2025, and was driven by profitability, partially offset by working capital dynamics. Working capital was primarily impacted by AI dynamics, which led to higher inventory, accounts receivable, and accounts payable levels. During the first nine months of Fiscal 2024, cash provided by operating activities was $7.1 billion, which was primarily driven by profitability and working capital management as we reduced inventory, demonstrated strong cash collections performance, and benefited from the timing of purchases and payments to vendors. Cash provided by operating activities also reflected the impact of the $0.9 billion net payment to settle the Class V transaction litigation and $0.4 billion in proceeds from the sale of our U.S. consumer revolving customer receivables portfolio. See “Liquidity, Cash Requirements, and Market Conditions” for additional information about our cash flow metrics.

[0001571996-24-000143:mdna:72]
[same as prior period, unchanged from 0001571996-24-000090:mdna:73]

[0001571996-24-000143:mdna:73]
[same as prior period, unchanged from 0001571996-24-000090:mdna:74]

[0001571996-24-000143:mdna:74]
During the third quarter and first nine months of Fiscal 2025, net revenue increased 10% and 8%, respectively, primarily driven by an increase in ISG net revenue that was partially offset by a decrease in other businesses net revenue and, to a lesser extent, CSG net revenue. See “Business Unit Results” for further information.

[0001571996-24-000143:mdna:75]
•Product Net Revenue — Product net revenue includes revenue from the sale of hardware products and software licenses. During the third quarter of Fiscal 2025, product net revenue increased 13% due to an increase in ISG product net revenue driven by growth in our servers and networking offerings. The increase was partially offset by a decline in CSG product net revenue as a result of a decrease in units sold within our consumer offerings, as well as a decline in other businesses product net revenue as we no longer act as a distributor of standalone VMware offerings.

[0001571996-24-000143:mdna:76]
During the first nine months of Fiscal 2025, product net revenue increased 11% due to an increase in ISG product net revenue driven by growth in our servers and networking offerings. The increase was partially offset by a decrease in CSG product net revenue as a result of a decrease in the average selling prices of our CSG offerings and, to a lesser extent, a decline in units sold within our consumer offerings, as well as a decline in other businesses product net revenue as we no longer act as a distributor of standalone VMware offerings.

[0001571996-24-000143:mdna:77]
•Services Net Revenue — Services net revenue includes revenue from our services offerings and support services related to hardware products and software licenses. During the third quarter and first nine months of Fiscal 2025, services net revenue increased 1% and 2%, respectively, driven primarily by growth within services net revenue attributable to CSG and, to a lesser extent, services net revenue attributable to ISG, partially offset by a decline in other businesses services net revenue. The increase in services net revenue was primarily attributable to CSG third-party software support and maintenance and, to a lesser extent, support and maintenance associated with products sold in prior periods within both ISG and CSG. Other businesses services net revenue declined as we no longer act as a distributor of standalone VMware offerings.

[0001571996-24-000143:mdna:78]
[same as prior period, unchanged from 0001571996-24-000090:mdna:78]

[0001571996-24-000143:mdna:79]
From a geographical perspective, net revenue increased in the Americas and, to a lesser extent, the Asia Pacific and Japan (“APJ”) and Europe, the Middle East and Africa (“EMEA”) regions during the third quarter of Fiscal 2025. Net revenue increased in both the Americas and APJ and decreased in EMEA during the first nine months of Fiscal 2025.

[0001571996-24-000143:mdna:80]
[same as prior period, unchanged from 0001571996-24-000090:mdna:80]

[0001571996-24-000143:mdna:81]
During the third quarter of Fiscal 2025, both gross margin and non-GAAP gross margin increased 3%, to $5.3 billion and $5.4 billion, respectively, driven by an increase in ISG gross margin that was largely offset by a decrease in CSG gross margin. During the first nine months of Fiscal 2025, both gross margin and non-GAAP gross margin decreased 1%, to $15.4 billion and $15.8 billion, respectively, driven by a decrease in CSG gross margin that was largely offset by an increase in ISG gross margin. The increase in ISG gross margin during both the third quarter and first nine months of Fiscal 2025 was primarily attributable to growth in our AI-optimized server offerings. The decrease in CSG gross margin during both the third quarter and first nine months of Fiscal 2025 was primarily attributable to a competitive pricing environment.

[0001571996-24-000143:mdna:82]
During the third quarter of Fiscal 2025, gross margin and non-GAAP gross margin percentage decreased 130 basis points to 21.8% and 140 basis points to 22.3%, respectively. During the first nine months of Fiscal 2025, gross margin and non-GAAP gross margin percentage decreased 200 basis points to 21.5% and 210 basis points to 22.1%, respectively. The decreases in gross margin percentage and non-GAAP gross margin percentage during both the third quarter and first nine months of Fiscal 2025 were primarily driven by a shift in mix towards AI-optimized server offerings and a competitive CSG pricing environment.

[0001571996-24-000143:mdna:83]
•Product Gross Margin — During the third quarter of Fiscal 2025, both product gross margin and non-GAAP product gross margin increased 2%, to $2.7 billion and $2.8 billion, respectively, primarily driven by an increase in ISG product gross margin that was largely offset by a decrease in CSG product gross margin. During the first nine months of Fiscal 2025, both product gross margin and non-GAAP product gross margin decreased 4% to $8.0 billion and $8.2 billion, respectively, primarily driven by a decrease in CSG product gross margin that was partially offset by an increase in ISG product gross margin. The increase in ISG product gross margin during both the third quarter and first nine months of Fiscal 2025 was primarily attributable to growth in our AI-optimized server offerings. The decline in CSG product gross margin during both the third quarter and first nine months of Fiscal 2025 was primarily attributable to a competitive pricing environment.

[0001571996-24-000143:mdna:84]
During the third quarter of Fiscal 2025, both product gross margin percentage and non-GAAP product gross margin percentage decreased 160 basis points, to 15.0% and 15.5%, respectively. During the first nine months of Fiscal 2025, product gross margin percentage and non-GAAP product gross margin percentage decreased 220 basis points to 15.0% and 240 basis points to 15.4%, respectively. The declines during both the third quarter and first nine months of Fiscal 2025 were primarily attributable to a shift in mix towards our AI-optimized server offerings and a competitive CSG pricing environment.

[0001571996-24-000143:mdna:85]
64

[0001571996-24-000143:mdna:86]
•Services Gross Margin — During the third quarter of Fiscal 2025, services gross margin and non-GAAP services gross margin increased 4% to $2.6 billion and 5% to $2.6 billion, respectively. During the first nine months of Fiscal 2025, services gross margin and non-GAAP services gross margin increased 2% to $7.4 billion and 3% to $7.6 billion, respectively. During both the third quarter and first nine months of Fiscal 2025, services gross margin and non-GAAP services gross margin benefited from an increase in support and maintenance associated with products sold in prior periods within both ISG and CSG and, to a lesser extent, an increase CSG third-party software support and maintenance.

[0001571996-24-000143:mdna:87]
During the third quarter of Fiscal 2025, services gross margin percentage and non-GAAP services gross margin percentage increased 120 basis points to 42.1% and 160 basis points to 43.0%, respectively. During the first nine months of Fiscal 2025, services gross margin percentage and non-GAAP services gross margin percentage increased 10 basis points to 40.7% and 50 basis points to 41.8%, respectively. The increases in services gross margin percentage and non-GAAP services gross margin percentage were primarily driven by a shift in mix as we no longer act as a distributor of standalone VMware offerings.

[0001571996-24-000143:mdna:88]
[same as prior period, unchanged from 0001571996-24-000090:mdna:88]

[0001571996-24-000143:mdna:89]
[same as prior period, unchanged from 0001571996-24-000090:mdna:89]

[0001571996-24-000143:mdna:90]
The terms and conditions of our vendor rebate programs are largely based on product volumes and are generally negotiated either at the beginning of the annual or quarterly period, depending on the program. The timing and amount of vendor rebates and other discounts we receive under the programs may vary from period to period, reflecting changes in the competitive environment. We monitor our component costs and seek to address the effects of any changes to terms that might arise under our vendor rebate programs. Our gross margins for the third quarter and first nine months of Fiscal 2025 were not materially affected by any changes to the terms of our vendor rebate programs, as the amounts we received under these programs were generally stable relative to our total net cost. We are not aware of any significant changes to our vendor rebate programs that will materially impact our results in the near term.

[0001571996-24-000143:mdna:91]
65

[0001571996-24-000143:mdna:92]
[same as prior period, unchanged from 0001571996-24-000090:mdna:92]

[0001571996-24-000143:mdna:93]
[same as prior period, unchanged from 0001571996-24-000090:mdna:93]

[0001571996-24-000143:mdna:94]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 1, 2024 |  |  |  | November 3, 2023 |  | November 1, 2024 |  |  |  | November 3, 2023 |  |  |  |  |
|  | Dollars |  | % of Net Revenue |  | % Change |  | Dollars |  | % of Net Revenue |  | Dollars |  | % of Net Revenue |  | % Change |  | Dollars |  | % of Net Revenue |  |  |  |  |  |  |
|  | (in millions, except percentages) |  |  |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative | $ | 2,894 |  |  | 11.9 | % |  | (3) | % |  | $ | 2,970 |  |  | 13.3 | % |  | $ | 9,206 |  |  | 12.8 | % |  | (6) | % |  | $ | 9,748 |  |  | 14.7 | % |  |  |  |  |  |  |
| Research and development | 745 |  |  | 3.1 | % |  | 8 | % |  | 692 |  |  | 3.1 | % |  | 2,288 |  |  | 3.2 | % |  | 10 | % |  | 2,085 |  |  | 3.2 | % |  |  |  |  |  |  |
| Total operating expenses | $ | 3,639 |  |  | 15.0 | % |  | (1) | % |  | $ | 3,662 |  |  | 16.4 | % |  | $ | 11,494 |  |  | 16.0 | % |  | (3) | % |  | $ | 11,833 |  |  | 17.9 | % |  |  |  |  |  |  |
|  | Three Months Ended |  | Nine Months Ended |
|  | November 1, 2024 |  |  |  | November 3, 2023 |  | November 1, 2024 |  |  |  | November 3, 2023 |  |  |  |  |
|  | Dollars |  | % of Net Revenue |  | % Change |  | Dollars |  | % of Net Revenue |  | Dollars |  | % of Net Revenue |  | % Change |  | Dollars |  | % of Net Revenue |  |  |  |  |  |  |
|  | (in millions, except percentages) |
| Non-GAAP operating expenses | $ | 3,238 |  |  | 13.3 | % |  | (2) | % |  | $ | 3,312 |  |  | 14.9 | % |  | $ | 10,141 |  |  | 14.1 | % |  | (3) | % |  | $ | 10,437 |  |  | 15.8 | % |  |  |  |  |  |  |

[0001571996-24-000143:mdna:95]
During the third quarter and first nine months of Fiscal 2025, total operating expenses decreased 1% and 3%, respectively, due to a decline in selling, general, and administrative expenses.

[0001571996-24-000143:mdna:96]
•Selling, General, and Administrative — During the third quarter and first nine months of Fiscal 2025, selling, general, and administrative expenses decreased 3% and 6%, respectively, driven by a decrease in employee compensation and benefits expense, principally due to a decline in overall headcount.

[0001571996-24-000143:mdna:97]
•Research and Development — Research and development (“R&D”) expenses are primarily composed of personnel-related expenses incurred in connection with product development. R&D expenses increased 8% and 10%, respectively, during the third quarter and first nine months of Fiscal 2025, principally due to an increase in R&D-related employee compensation and benefits expense.

[0001571996-24-000143:mdna:98]
As a percentage of net revenue, R&D expenses for both the third quarter of Fiscal 2025 and Fiscal 2024 were 3.1% and for both the first nine months of Fiscal 2025 and Fiscal 2024 were 3.2%. We continue to support R&D initiatives to innovate and introduce new and enhanced solutions into the market.

[0001571996-24-000143:mdna:99]
During the third quarter and first nine months of Fiscal 2025, non-GAAP operating expenses decreased 2% and 3%, respectively, driven by a decline in employee compensation and benefits expense, primarily resulting from a decline in overall headcount. The decline in employee compensation and benefits expense was partially offset by continued support of R&D initiatives.

[0001571996-24-000143:mdna:100]
We continue to make strategic investments designed to enable growth and innovation, while balancing our efforts to drive cost efficiencies in the business. We also expect to continue making investments in support of our own digital transformation, which aims to streamline and optimize our business processes.

[0001571996-24-000143:mdna:101]
[same as prior period, unchanged from 0001571996-24-000090:mdna:101]

[0001571996-24-000143:mdna:102]
During the third quarter of Fiscal 2025, both operating income and non-GAAP operating income increased by 12%, to $1.7 billion and $2.2 billion, respectively. During the first nine months of Fiscal 2025, operating income and non-GAAP operating income increased by 6% to $3.9 billion and 3% to $5.7 billion, respectively. During both the third quarter and first nine months of Fiscal 2025, the increases in operating income and non-GAAP operating income were primarily attributable to an increase in ISG operating income driven by our servers and networking offerings, which was largely offset by a decrease in CSG operating income.

[0001571996-24-000143:mdna:103]
During the third quarter of Fiscal 2025, operating income and non-GAAP operating income as a percentage of net revenue increased 10 basis points to 6.8% and increased 20 basis points to 9.0%, respectively. During the first nine months of Fiscal 2025, operating income and non-GAAP operating income as a percentage of net revenue decreased 10 basis points to 5.5% and 40 basis points to 8.0%, respectively. Operating income and non-GAAP operating income as a percentage of net revenue during both the third quarter and first nine months of Fiscal 2025 were impacted by a decline in gross margin as a percentage of net revenue due to a shift in mix towards AI-optimized server offerings and a competitive CSG pricing environment. The decline in gross margin as a percentage of net revenue was offset by the favorable impact of a decrease in operating expense rate that was driven by strong ISG net revenue growth coupled with continued disciplined cost management.

[0001571996-24-000143:mdna:104]
[same as prior period, unchanged from 0001571996-24-000090:mdna:104]

[0001571996-24-000143:mdna:105]
[same as prior period, unchanged from 0001571996-24-000090:mdna:105]

[0001571996-24-000143:mdna:106]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 1, 2024 |  | November 3, 2023 |  | November 1, 2024 |  | November 3, 2023 |  |  |
|  | (in millions) |  |  |
| Interest and other, net: |  |  |  |  |  |  |  |  |  |
| Investment income, primarily interest | $ | 35 |  |  | $ | 88 |  |  | $ | 127 |  |  | $ | 213 |  |  |  |
| Gain (loss) on investments, net | 46 |  |  | 8 |  |  | 21 |  |  | (36) |  |  |  |
| Interest expense | (321) |  |  | (371) |  |  | (1,051) |  |  | (1,128) |  |  |  |
| Foreign exchange | (29) |  |  | (30) |  |  | (80) |  |  | (127) |  |  |  |
| Other | (7) |  |  | (1) |  |  | (19) |  |  | (43) |  |  |  |
| Total interest and other, net | $ | (276) |  |  | $ | (306) |  |  | $ | (1,002) |  |  | $ | (1,121) |  |  |  |

[0001571996-24-000143:mdna:107]
During both the third quarter and first nine months of Fiscal 2025, the change in interest and other, net was favorable, primarily due to a reduction in interest expense and gains recognized within our strategic investments portfolio, partially offset by a decline in interest income on investments.

[0001571996-24-000143:mdna:108]
[same as prior period, unchanged from 0001571996-24-000090:mdna:108]

[0001571996-24-000143:mdna:109]
[same as prior period, unchanged from 0001571996-24-000090:mdna:109]

[0001571996-24-000143:mdna:110]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 1, 2024 |  | November 3, 2023 |  | November 1, 2024 |  | November 3, 2023 |  |  |
|  | (in millions, except percentages) |  |  |
| Income before income taxes | $ | 1,392 |  |  | $ | 1,180 |  |  | $ | 2,928 |  |  | $ | 2,599 |  |  |  |
| Income tax expense | $ | 265 |  |  | $ | 176 |  |  | $ | 5 |  |  | $ | 562 |  |  |  |
| Effective income tax rate | 19.0 | % |  | 14.9 | % |  | 0.2 | % |  | 21.6 | % |  |  |

[0001571996-24-000143:mdna:111]
For the third quarter of Fiscal 2025 and Fiscal 2024, our effective income tax rate was 19.0% and 14.9%, respectively. For the first nine months of Fiscal 2025 and Fiscal 2024, our effective income tax rate was 0.2% and 21.6%, respectively. The changes in our effective income tax rate were primarily driven by discrete tax items. For the first nine months of Fiscal 2025, we recorded discrete tax benefits of $0.4 billion related to changes in uncertain tax benefits resulting from the expiration of certain statutes of limitations and $0.2 billion related to stock-based compensation.

[0001571996-24-000143:mdna:112]
Our effective income tax rate can fluctuate depending on the geographic distribution of our worldwide earnings, as our foreign earnings are generally taxed at lower rates than in the United States. The differences between our effective income tax rates and the U.S. federal statutory rate of 21% principally result from the geographical distribution of income, differences between the book and tax treatment of certain items, and discrete tax items. In certain jurisdictions, our tax rate is significantly less than the applicable statutory rate as a result of tax holidays. The majority of our foreign income subject to these tax holidays is attributable to Singapore and China. A significant portion of these income tax benefits relates to a tax holiday that will be effective until January 31, 2029. Most of our other tax holidays will expire in whole or in part during Fiscal 2030 and Fiscal 2031. Many of these tax holidays and reduced tax rates may be extended when certain conditions are met or may be terminated early if certain conditions are not met or as a result of changes in tax legislation. As of November 1, 2024, we were not aware of any matters of non-compliance.

[0001571996-24-000143:mdna:113]
Many countries, including Singapore, a country in which we have a tax holiday, have enacted or are in the process of enacting laws based on the Pillar Two proposal relating to a global minimum tax issued by the Organisation for Economic Co-operation and Development (“OECD”). While we expect our effective income tax rate and cash income tax payments will increase in future years as a result of the global minimum tax, we do not expect the tax will have a material impact on our Fiscal 2025 consolidated results of operations. Our assessment could be affected by legislative guidance and future enactment of additional provisions within the Pillar Two framework.

[0001571996-24-000143:mdna:114]
[same as prior period, unchanged from 0001571996-24-000090:mdna:114]

[0001571996-24-000143:mdna:115]
[same as prior period, unchanged from 0001571996-24-000090:mdna:115]

[0001571996-24-000143:mdna:116]
During the third quarter of Fiscal 2025, net income and non-GAAP net income increased 12% to $1.1 billion and 11% to $1.5 billion, respectively, due to an increase in operating income.

[0001571996-24-000143:mdna:117]
During the first nine months of Fiscal 2025, net income and non-GAAP net income increased 43% to $2.9 billion and 5% to $3.8 billion, respectively. Net income increased primarily due to a reduction in income tax expense and, to a lesser extent, an increase in operating income. Non-GAAP net income increased primarily due to an increase in operating income.

[0001571996-24-000143:mdna:118]
[same as prior period, unchanged from 0001571996-24-000090:mdna:119]

[0001571996-24-000143:mdna:119]
[same as prior period, unchanged from 0001571996-24-000090:mdna:120]

[0001571996-24-000143:mdna:120]
[same as prior period, unchanged from 0001571996-24-000090:mdna:121]

[0001571996-24-000143:mdna:121]
[same as prior period, unchanged from 0001571996-24-000090:mdna:122]

[0001571996-24-000143:mdna:122]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 1, 2024 |  | % Change |  | November 3, 2023 |  | November 1, 2024 |  | % Change |  | November 3, 2023 |  |  |  |  |
|  | (in millions, except percentages) |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Servers and networking | $ | 7,364 |  |  | 58 | % |  | $ | 4,656 |  | $ | 20,502 |  | 61 | % |  | $ | 12,767 |  |  |  |  |
| Storage | 4,004 |  |  | 4 | % |  | 3,843 |  | 11,739 |  | — | % |  | 11,786 |  |  |  |  |
| Total ISG net revenue | $ | 11,368 |  |  | 34 | % |  | $ | 8,499 |  | $ | 32,241 |  | 31 | % |  | $ | 24,553 |  |  |  |  |
| Operating income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| ISG operating income | $ | 1,508 |  |  | 41 | % |  | $ | 1,069 |  | $ | 3,528 |  | 23 | % |  | $ | 2,858 |  |  |  |  |
| % of segment net revenue | 13.3 | % |  |  |  | 12.6 | % |  | 10.9 | % |  |  |  | 11.6 | % |  |  |  |  |

[0001571996-24-000143:mdna:123]
Net Revenue — During the third quarter and first nine months of Fiscal 2025, ISG net revenue increased 34% and 31%, respectively, driven by strength in our servers and networking offerings.

[0001571996-24-000143:mdna:124]
Net revenue from sales of servers and networking increased 58% and 61%, respectively, during the third quarter and first nine months of Fiscal 2025. The increase in servers and networking net revenue was driven by growth in our AI-optimized server offerings and, to a lesser extent, our traditional server and networking offerings.

[0001571996-24-000143:mdna:125]
Storage net revenue increased 4% and remained flat, respectively, during the third quarter and first nine months of Fiscal 2025. During the third quarter of Fiscal 2025, storage net revenue increased primarily due to an increase in net revenue of our hyper-converged infrastructure offerings.

[0001571996-24-000143:mdna:126]
From a geographical perspective, net revenue attributable to ISG increased in the Americas and, to a lesser extent, in APJ and EMEA during the third quarter and first nine months of Fiscal 2025.

[0001571996-24-000143:mdna:127]
Operating Income — During the third quarter of Fiscal 2025, ISG operating income as a percentage of net revenue increased 70 basis points to 13.3%, due to a decline in operating expense as a percentage of net revenue that outpaced the decline in gross margin rate. Operating expense as a percentage of net revenue declined due to strong ISG net revenue growth coupled with continued disciplined cost management. Gross margin rate decreased primarily as the result of a shift in mix towards AI-optimized server offerings.

[0001571996-24-000143:mdna:128]
During the first nine months of Fiscal 2025, ISG operating income as a percentage of net revenue decreased 70 basis points to 10.9%, due to a decline in gross margin rate that outpaced the decline in operating expense as a percentage of net revenue. Gross margin rate decreased primarily as the result of a shift in mix towards AI-optimized server offerings. Operating expense as a percentage of net revenue declined primarily due to strong ISG net revenue growth coupled with continued disciplined cost management.

[0001571996-24-000143:mdna:129]
[same as prior period, unchanged from 0001571996-24-000090:mdna:129]

[0001571996-24-000143:mdna:130]
[same as prior period, unchanged from 0001571996-24-000090:mdna:130]

[0001571996-24-000143:mdna:131]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 1, 2024 |  | % Change |  | November 3, 2023 |  | November 1, 2024 |  | % Change |  | November 3, 2023 |  |  |  |  |
|  | (in millions, except percentages) |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 10,138 |  |  | 3 | % |  | $ | 9,835 |  | $ | 30,848 |  | 2 | % |  | $ | 30,251 |  |  |  |  |
| Consumer | 1,993 |  |  | (18) | % |  | 2,441 |  | 5,664 |  | (19) | % |  | 6,950 |  |  |  |  |
| Total CSG net revenue | $ | 12,131 |  |  | (1) | % |  | $ | 12,276 |  | $ | 36,512 |  | (2) | % |  | $ | 37,201 |  |  |  |  |
| Operating income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| CSG operating income | $ | 694 |  |  | (25) | % |  | $ | 925 |  | $ | 2,193 |  | (21) | % |  | $ | 2,786 |  |  |  |  |
| % of segment net revenue | 5.7 | % |  |  |  | 7.5 | % |  | 6.0 | % |  |  |  | 7.5 | % |  |  |  |  |

[0001571996-24-000143:mdna:132]
Net Revenue — During the third quarter of Fiscal 2025, CSG net revenue declined 1% primarily due to a decrease in units sold, partially offset by an increase in the average selling prices of our offerings. During the first nine months of Fiscal 2025, CSG net revenue declined 2% principally due to a decrease in units sold and, to a lesser extent, a decline in the average selling prices of our offerings.

[0001571996-24-000143:mdna:133]
Commercial net revenue increased 3% and 2%, respectively, during the third quarter and first nine months of Fiscal 2025, principally due to an increase in units sold.

[0001571996-24-000143:mdna:134]
Consumer net revenue decreased 18% and 19%, respectively, during the third quarter and first nine months of Fiscal 2025, principally due to a decline in units sold. During the first nine months of Fiscal 2025, consumer net revenue also declined as a result of a decline in the average selling prices of our consumer offerings.

[0001571996-24-000143:mdna:135]
From a geographical perspective, net revenue attributable to CSG decreased in APJ and EMEA and increased in the Americas during the third quarter of Fiscal 2025. During the first nine months of Fiscal 2025, net revenue attributable to CSG decreased in APJ and the Americas and increased in EMEA.

[0001571996-24-000143:mdna:136]
Operating Income — During the third quarter and first nine months of Fiscal 2025, CSG operating income as a percentage of net revenue decreased 180 basis points to 5.7% and 150 basis points to 6.0%, respectively, primarily due to a decline in gross margin rate, partially offset by a decrease in operating expenses as a percentage of net revenue. The decline in gross margin rate was primarily the result of a competitive pricing environment. The decline in operating expenses as a percentage of net revenue was due to continued disciplined cost management.

[0001571996-24-000143:mdna:137]
[same as prior period, unchanged from 0001571996-24-000090:mdna:137]

[0001571996-24-000143:mdna:138]
[same as prior period, unchanged from 0001571996-24-000090:mdna:138]

[0001571996-24-000143:mdna:139]
We sell products and services directly to customers and through a variety of sales channels, including retail distribution. Our accounts receivable, net, was $11.2 billion and $9.3 billion as of November 1, 2024 and February 2, 2024, respectively. Accounts receivable, net, was elevated due to growth in our AI-optimized server offerings and the timing of cash receipts. We maintain an allowance for expected credit losses to cover receivables that may be deemed uncollectible. The allowance for expected credit losses is an estimate based on an analysis of historical loss experience, current receivables aging, and management’s assessment of current conditions and its reasonable and supportable expectation of future conditions, as well as specific identifiable customer accounts that are deemed at risk. As of November 1, 2024 and February 2, 2024, the allowance for expected credit losses was $62 million and $71 million, respectively. Based on our assessment, we believe that we are adequately reserved for expected credit losses.

[0001571996-24-000143:mdna:140]
[same as prior period, unchanged from 0001571996-24-000090:mdna:140]

[0001571996-24-000143:mdna:141]
We offer or arrange various financing options and services for our customers globally, including through captive financing operations. DFS originates, collects, and services customer receivables primarily related to the purchase of our product, software, and services solutions. We further strengthen customer relationships through flexible consumption models, including utility, subscription, and as-a-Service models, which enable our customers the option to pay over time to provide them with financial and operational flexibility. New financing originations were $1.6 billion and $1.8 billion for the third quarter of Fiscal 2025 and Fiscal 2024, respectively, and $5.9 billion and $6.0 billion for first nine months of Fiscal 2025 and Fiscal 2024, respectively.

[0001571996-24-000143:mdna:142]
Our leases are generally classified as sales-type leases or operating leases. On commencement of sales-type leases, we recognize profit up-front, and recognize amounts due from the customer under the lease contract as financing receivables. Interest income is recognized as net product revenue over the term of the lease. Upon origination of operating leases, we record equipment under operating leases, classified as property, plant, and equipment, net. We recognize product revenue and depreciation expense, classified as cost of net revenue, over the contract term.

[0001571996-24-000143:mdna:143]
As of November 1, 2024 and February 2, 2024, our financing receivables, net were $10.9 billion and $10.5 billion, respectively. We maintain an allowance to cover expected financing receivables credit losses and evaluate credit loss expectations based on our total portfolio. The principal charge-off rate for our financing receivables portfolio was 1.4% and 0.6% for the third quarter of Fiscal 2025 and Fiscal 2024, respectively, and 0.8% and 0.6% for the first nine months of Fiscal 2025 and Fiscal 2024, respectively. The credit quality of our financing receivables remains strong due to the mix of high-quality commercial accounts in our portfolio. We continue to monitor broader economic indicators and their potential impact on future credit loss performance. We have an extensive process to manage our exposure to customer credit risk, including active management of credit lines and our collection activities. We also sell selected fixed-term financing receivables without recourse to unrelated third parties on a periodic basis, primarily to manage certain concentrations of customer credit exposure. Based on our assessment of the customer financing receivables, we believe that we are adequately reserved.

[0001571996-24-000143:mdna:144]
We retain a residual interest in equipment leased under our lease programs. As of November 1, 2024 and February 2, 2024, the residual interest recorded as part of financing receivables was $169 million and $157 million, respectively. The amount of the residual interest is established at the inception of the lease based upon estimates of the value of the equipment at the end of the lease term using historical studies, industry data, and future value-at-risk demand valuation methods. On a quarterly basis, we assess the carrying amount of our recorded residual values for expected losses. Generally, expected losses as a result of residual value risk on equipment under lease are not considered to be significant primarily because of the existence of a secondary market with respect to the equipment. Further, the lease agreement defines applicable return conditions and remedies for non-compliance to ensure that the leased equipment will be in good operating condition upon return. No expected losses were recorded related to residual assets during the third quarter and first nine months of Fiscal 2025 and Fiscal 2024.

[0001571996-24-000143:mdna:145]
As of both November 1, 2024 and February 2, 2024, equipment under operating leases, net was $2.2 billion. We assess the carrying amount of the equipment under operating leases for impairment whenever events or circumstances may indicate that an impairment has occurred. No material impairment losses were recorded related to such equipment during the third quarter and first nine months of Fiscal 2025 and Fiscal 2024.

[0001571996-24-000143:mdna:146]
[same as prior period, unchanged from 0001571996-24-000090:mdna:146]

[0001571996-24-000143:mdna:147]
[same as prior period, unchanged from 0001571996-24-000090:mdna:147]

[0001571996-24-000143:mdna:148]
72

[0001571996-24-000143:mdna:149]
[same as prior period, unchanged from 0001571996-24-000090:mdna:149]

[0001571996-24-000143:mdna:150]
[same as prior period, unchanged from 0001571996-24-000090:mdna:150]

[0001571996-24-000143:mdna:151]
[same as prior period, unchanged from 0001571996-24-000090:mdna:151]

[0001571996-24-000143:mdna:152]
[same as prior period, unchanged from 0001571996-24-000090:mdna:152]

[0001571996-24-000143:mdna:153]
We believe that our current cash and cash equivalents, together with cash that will be provided by future operations and borrowings and issuances expected to be available under our revolving credit facility and commercial paper program, respectively, will be sufficient over the next twelve months and for the foreseeable future thereafter to meet our material cash requirements, including funding of our operations, debt-related payments, capital expenditures, and other corporate needs.

[0001571996-24-000143:mdna:154]
[same as prior period, unchanged from 0001571996-24-000090:mdna:154]

[0001571996-24-000143:mdna:155]
[same as prior period, unchanged from 0001571996-24-000090:mdna:155]

[0001571996-24-000143:mdna:156]
|  | November 1, 2024 |  | February 2, 2024 |
|  | (in millions) |
| Cash and cash equivalents, and available borrowings: |  |  |  |
| Cash and cash equivalents | $ | 5,225 |  |  | $ | 7,366 |  |
| Remaining available borrowings under the revolving credit facility | 5,999 |  |  | 5,999 |  |
| Total cash and cash equivalents, and available borrowings | $ | 11,224 |  |  | $ | 13,365 |  |

[0001571996-24-000143:mdna:157]
During the first nine months of Fiscal 2025, cash and cash equivalents decreased by $2.1 billion primarily due to the return of capital to our stockholders, capital expenditures, net repayment of Senior Notes and DFS debt, and payments to settle employee tax withholdings on stock-based compensation, the effect of which was partially offset by cash flows from operations.

[0001571996-24-000143:mdna:158]
As of November 1, 2024, our revolving credit facility had a maximum capacity of $6.0 billion. Available borrowings under this facility are reduced by draws on the facility and outstanding letters of credit. As of November 1, 2024, there were no borrowings outstanding under the facility and remaining available borrowings totaled approximately $6.0 billion. The revolving credit facility also acts as a backstop to provide liquidity support for our commercial paper program.

[0001571996-24-000143:mdna:159]
We maintain a commercial paper program under which we may issue unsecured notes in a maximum aggregate face amount of $5.0 billion outstanding at any time, with maturities up to 397 days from the date of issue. As of November 1, 2024, we had no outstanding issuances under the program.

[0001571996-24-000143:mdna:160]
We may regularly use our available borrowings from the revolving credit facility and issuances under the commercial paper program, generally on a short-term basis, for general corporate purposes. See the following discussion for additional information about our debt.

[0001571996-24-000143:mdna:161]
73

[0001571996-24-000143:mdna:162]
[same as prior period, unchanged from 0001571996-24-000090:mdna:161]

[0001571996-24-000143:mdna:163]
[same as prior period, unchanged from 0001571996-24-000090:mdna:162]

[0001571996-24-000143:mdna:164]
|  | November 1, 2024 |  | Change |  | February 2, 2024 |
|  | (in millions) |
| Core debt |  |  |  |  |  |
| Senior Notes | $ | 15,073 |  |  | $ | (534) |  |  | $ | 15,607 |  |
| Legacy Notes | 952 |  |  | — |  |  | 952 |  |
| DFS allocated debt | (2,263) |  |  | (623) |  |  | (1,640) |  |
| Total core debt | 13,762 |  |  | (1,157) |  |  | 14,919 |  |
| DFS related debt |  |  |  |  |  |
| DFS debt | 9,171 |  |  | (321) |  |  | 9,492 |  |
| DFS allocated debt | 2,263 |  |  | 623 |  |  | 1,640 |  |
| Total DFS related debt | 11,434 |  |  | 302 |  |  | 11,132 |  |
| Other | 56 |  |  | (115) |  |  | 171 |  |
| Total debt, principal amount | 25,252 |  |  | (970) |  |  | 26,222 |  |
| Carrying value adjustments | (230) |  |  | (2) |  |  | (228) |  |
| Total debt, carrying value | $ | 25,022 |  |  | $ | (972) |  |  | $ | 25,994 |  |

[0001571996-24-000143:mdna:165]
The outstanding principal amount of our debt decreased $1.0 billion to $25.3 billion as of November 1, 2024, driven primarily by net repayments of our Senior Notes and DFS debt.

[0001571996-24-000143:mdna:166]
We define core debt as the total principal amount of our debt, less DFS related debt and other debt. Our core debt was $13.8 billion and $14.9 billion as of November 1, 2024 and February 2, 2024, respectively. See Note 6 of the Notes to the Condensed Consolidated Financial Statements included in this report for additional information about our debt.

[0001571996-24-000143:mdna:167]
[same as prior period, unchanged from 0001571996-24-000090:mdna:166]

[0001571996-24-000143:mdna:168]
[same as prior period, unchanged from 0001571996-24-000090:mdna:167]

[0001571996-24-000143:mdna:169]
We believe we will continue to be able to make our debt principal and interest payments, including payment of short-term maturities, from existing and expected sources of cash, primarily from operating cash flows. Cash used for debt principal and interest payments may include short-term borrowings under our commercial paper program, our revolving credit facility, or other borrowings. Under our variable-rate debt, we could experience variations in our future interest expense from potential fluctuations in applicable reference rates, or from possible fluctuations in the level of DFS debt required to meet future demand for customer financing.

[0001571996-24-000143:mdna:170]
[same as prior period, unchanged from 0001571996-24-000090:mdna:169]

[0001571996-24-000143:mdna:171]
[same as prior period, unchanged from 0001571996-24-000090:mdna:186]

[0001571996-24-000143:mdna:172]
[same as prior period, unchanged from 0001571996-24-000090:mdna:170]

[0001571996-24-000143:mdna:173]
[same as prior period, unchanged from 0001571996-24-000090:mdna:171]

[0001571996-24-000143:mdna:174]
|  | Nine Months Ended |
|  | November 1, 2024 |  | November 3, 2023 |  |  |
|  | (in millions) |
| Net change in cash from: |  |  |  |  |  |
| Operating activities | $ | 3,936 |  |  | $ | 7,143 |  |  |  |
| Investing activities | (1,537) |  |  | (2,114) |  |  |  |
| Financing activities | (4,424) |  |  | (5,275) |  |  |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash | (78) |  |  | (200) |  |  |  |
| Change in cash, cash equivalents, and restricted cash | $ | (2,103) |  |  | $ | (446) |  |  |  |

[0001571996-24-000143:mdna:175]
Operating Activities — Cash provided by operating activities was $3.9 billion during the first nine months of Fiscal 2025, and was driven by profitability, partially offset by working capital dynamics. Working capital was primarily impacted by AI dynamics, which led to higher inventory, accounts receivable, and accounts payable levels. During the first nine months of Fiscal 2024, cash provided by operating activities was $7.1 billion, which was primarily driven by profitability and working capital management as we reduced inventory, demonstrated strong cash collections performance, and benefited from the timing of purchases and payments to vendors. Cash provided by operating activities also reflected the impact of the $0.9 billion net payment to settle the Class V transaction litigation and $0.4 billion in proceeds from the sale of our U.S. consumer revolving customer receivables portfolio.

[0001571996-24-000143:mdna:176]
Investing Activities — Investing activities primarily consist of cash used to fund capital expenditures for property, plant, and equipment inclusive of equipment under DFS operating leases and equipment used to support our as-a-Service offerings, which we refer to collectively as assets in a customer contract. Additional activities may include capitalized software development costs, acquisitions and divestitures, and the maturities, sales, and purchases of investments. Cash used in investing activities was $1.5 billion and $2.1 billion during the first nine months of Fiscal 2025 and Fiscal 2024, respectively, and was primarily applied to capital expenditures.

[0001571996-24-000143:mdna:177]
Financing Activities — Financing activities primarily consist of the proceeds and repayments of debt and return of capital to our stockholders. Cash used in financing activities was $4.4 billion during the first nine months of Fiscal 2025 and primarily consisted of repurchases of common stock, inclusive of payments to settle employee tax withholdings on stock-based compensation, net repayments of our Senior Notes and DFS debt, and the payment of quarterly dividends. During the first nine months of Fiscal 2024, cash used in financing activities was $5.3 billion and primarily consisted of principal repayments of our Senior Notes, repurchases of common stock, inclusive of payments to settle employee tax withholdings on stock-based compensation, and the payment of quarterly dividends.

[0001571996-24-000143:mdna:178]
DFS Cash Flow Impacts — DFS offerings are initially funded through cash on hand at the time of origination, most of which is subsequently replaced with asset-backed financing. For DFS offerings that qualify as sales-type leases, the initial funding of financing receivables is reflected as an impact to cash flows from operations and is largely subsequently offset by cash proceeds from financing. For operating leases, the initial funding is classified as a capital expenditure and reflected as cash flows used in investing activities. DFS new financing originations were $5.9 billion and $6.0 billion during the first nine months of Fiscal 2025 and Fiscal 2024, respectively. As of November 1, 2024, we had $10.9 billion of total net financing receivables and $2.2 billion of equipment under operating leases, net.

[0001571996-24-000143:mdna:179]
[same as prior period, unchanged from 0001571996-24-000090:mdna:177]

[0001571996-24-000143:mdna:180]
[same as prior period, unchanged from 0001571996-24-000090:mdna:178]

[0001571996-24-000143:mdna:181]
Capital Expenditures — We spent $1.9 billion and $2.0 billion during the first nine months of Fiscal 2025 and Fiscal 2024, respectively, on property, plant, and equipment and capitalized software development costs. Of total expenditures incurred, funding of assets in a customer contract totaled $1.0 billion and $0.9 billion during the first nine months of Fiscal 2025 and Fiscal 2024, respectively. Product demand, product mix, the use of contract manufacturers, and ongoing investments in operating and information technology infrastructure influence the level and prioritization of our capital expenditures.

[0001571996-24-000143:mdna:182]
Repurchases of Common Stock — Effective as of September 23, 2021, our Board of Directors approved a stock repurchase program with no fixed expiration date under which we are authorized to repurchase up to $5.0 billion of shares of our Class C Common Stock, exclusive of any fees, commissions, or other expenses related to such repurchases. Effective as of October 5, 2023, the Board of Directors approved the repurchase of an additional $5.0 billion of shares of the Class C Common Stock with no fixed expiration date. Following the additional approval, we had approximately $5.7 billion in cumulative authorized amount remaining under the stock repurchase program.

[0001571996-24-000143:mdna:183]
During the first nine months of Fiscal 2025, we repurchased approximately 16 million shares of Class C Common Stock for a total purchase price of approximately $1.8 billion. During the first nine months of Fiscal 2024, we repurchased approximately 22 million shares of Class C Common Stock for a total purchase price of approximately $1.3 billion.

[0001571996-24-000143:mdna:184]
Dividend Payments — On February 29, 2024, we announced that the Board of Directors approved a 20% increase in the dividend rate to $0.445 per share per fiscal quarter beginning in the first quarter of Fiscal 2025. During the first nine months of Fiscal 2025 and Fiscal 2024, the Company paid $1.0 billion and $0.8 billion in dividends and dividend equivalents at a rate of $0.445 and $0.37 per share per fiscal quarter, respectively.

[0001571996-24-000143:mdna:185]
[same as prior period, unchanged from 0001571996-24-000090:mdna:183]

[0001571996-24-000143:mdna:186]
[same as prior period, unchanged from 0001571996-24-000090:mdna:184]

[0001571996-24-000143:mdna:187]
As of November 1, 2024, the Company had purchase obligations of $8.1 billion, of which $6.9 billion was payable within 12 months.

[0001571996-24-000143:mdna:188]
[same as prior period, unchanged from 0001571996-24-000090:mdna:187]

[0001571996-24-000143:mdna:189]
[same as prior period, unchanged from 0001571996-24-000090:mdna:188]

[0001571996-24-000143:mdna:190]
[same as prior period, unchanged from 0001571996-24-000090:mdna:189]

[0001571996-24-000143:mdna:191]
[same as prior period, unchanged from 0001571996-24-000090:mdna:190]

[0001571996-24-000143:mdna:192]
[same as prior period, unchanged from 0001571996-24-000090:mdna:191]

[0001571996-24-000143:mdna:193]
[same as prior period, unchanged from 0001571996-24-000090:mdna:206]

[0001571996-24-000143:mdna:194]
[same as prior period, unchanged from 0001571996-24-000090:mdna:193]

[0001571996-24-000143:mdna:195]
[same as prior period, unchanged from 0001571996-24-000090:mdna:194]

[0001571996-24-000143:mdna:196]
[same as prior period, unchanged from 0001571996-24-000090:mdna:195]

[0001571996-24-000143:mdna:197]
[same as prior period, unchanged from 0001571996-24-000090:mdna:196]

[0001571996-24-000143:mdna:198]
|  | Nine Months Ended |
|  | November 1, 2024 |
|  | (in millions) |
| Net revenue (a) | $ | 6,171 |  |
| Gross margin (b) | 2,995 |  |
| Operating income (c) | 360 |  |
| Interest and other, net (d) | (3,044) |  |
| Loss before income taxes | $ | (2,684) |  |
| Net loss attributable to Obligor Group | $ | (1,916) |  |

[0001571996-24-000143:mdna:199]
[same as prior period, unchanged from 0001571996-24-000090:mdna:198]

[0001571996-24-000143:mdna:200]
(a)    Includes net revenue from Non-Obligor Subsidiaries of $247 million.

[0001571996-24-000143:mdna:201]
(b)    Includes cost of net revenue from the resale of solutions purchased from Non-Obligor Subsidiaries of $808 million.

[0001571996-24-000143:mdna:202]
(c)    Includes operating expenses from shared services provided by Non-Guarantor Subsidiaries of $382 million.

[0001571996-24-000143:mdna:203]
(d)    Includes interest expense on intercompany loan payables of $2,370 million.

[0001571996-24-000143:mdna:204]
[same as prior period, unchanged from 0001571996-24-000090:mdna:204]

[0001571996-24-000143:mdna:205]
|  | November 1, 2024 |  | February 2, 2024 |
|  | (in millions) |
| ASSETS |
| Current assets | $ | 2,840 |  |  | $ | 2,631 |  |
| Intercompany receivables | — |  |  | 281 |  |
| Short-term intercompany loan receivables | 230 |  |  | 92 |  |
| Total current assets | 3,070 |  |  | 3,004 |  |
| Goodwill and intangible assets | 14,166 |  |  | 14,447 |  |
| Other non-current assets | 3,334 |  |  | 3,437 |  |
| Total assets | $ | 20,570 |  |  | $ | 20,888 |  |
| LIABILITIES |
| Current liabilities | $ | 3,520 |  |  | $ | 5,255 |  |
| Intercompany payable | 2,114 |  |  | — |  |
| Total current liabilities | 5,634 |  |  | 5,255 |  |
| Long-term debt | 15,818 |  |  | 15,353 |  |
| Intercompany loan payables | 41,645 |  |  | 41,617 |  |
| Other non-current liabilities | 3,155 |  |  | 3,473 |  |
| Total liabilities | $ | 66,252 |  |  | $ | 65,698 |  |

[0001571996-24-000143:mdna:206]
79
