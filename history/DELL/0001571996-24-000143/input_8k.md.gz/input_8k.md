# DELL 8-K — 0001571996-24-000130 filed 2024-11-26

## item codes, every 8-K on or before 2024-12-10

- 2024-12-03 0001571996-24-000136 — 3.02
- 2024-11-26 0001571996-24-000130 — 2.02, 9.01
- 2024-10-08 0001193125-24-234446 — 1.01, 2.03, 9.01
- 2024-10-02 0001193125-24-231195 — 8.01, 9.01
- 2024-09-19 0001571996-24-000105 — 3.02
- 2024-08-29 0001571996-24-000081 — 2.02, 9.01
- 2024-07-12 0001193125-24-178608 — 3.02
- 2024-07-02 0001571996-24-000074 — 5.07
- 2024-06-10 0001571996-24-000059 — 3.02
- 2024-05-30 0001571996-24-000050 — 2.02, 9.01
- 2024-03-26 0001571996-24-000038 — 3.02
- 2024-03-18 0001193125-24-070193 — 1.01, 2.03, 9.01
- 2024-03-07 0001571996-24-000012 — 3.02
- 2024-03-06 0001193125-24-059631 — 8.01, 9.01
- 2024-02-29 0001571996-24-000008 — 2.02, 9.01
- 2024-01-30 0001571996-24-000004 — 1.02
- 2024-01-18 0001571996-24-000002 — 3.02
- 2023-12-18 0001193125-23-297664 — 8.01, 9.01
- 2023-12-05 0001571996-23-000042 — 3.02
- 2023-12-04 0001193125-23-288428 — 8.01, 9.01
- 2023-11-30 0001571996-23-000039 — 2.02, 9.01
- 2023-10-05 0001193125-23-251131 — 7.01, 8.01, 9.01
- 2023-10-02 0001571996-23-000036 — 5.02 — amendment of 0001571996-23-000034
- 2023-09-26 0001571996-23-000034 — 5.02
- 2023-08-31 0001571996-23-000029 — 2.02, 9.01
- 2023-08-09 0001571996-23-000026 — 5.02 — amendment of 0001571996-23-000002
- 2023-07-28 0001571996-23-000024 — 5.02
- 2023-07-13 0001193125-23-186639 — 3.02
- 2023-06-30 0001193125-23-180570 — 8.01, 9.01
- 2023-06-22 0001571996-23-000021 — 5.02, 5.07, 9.01
- 2023-06-15 0001193125-23-167472 — 8.01, 9.01
- 2023-06-01 0001571996-23-000014 — 2.02, 9.01
- 2023-03-02 0001571996-23-000002 — 2.02, 5.02, 9.01
- 2023-02-06 0001193125-23-024781 — 7.01, 9.01
- 2023-01-24 0001193125-23-014260 — 1.01, 2.03, 9.01
- 2023-01-11 0001193125-23-006528 — 8.01, 9.01
- 2022-11-21 0001571996-22-000041 — 2.02, 9.01
- 2022-11-16 0001571996-22-000038 — 8.01
- 2022-08-25 0001571996-22-000028 — 2.02, 9.01
- 2022-07-18 0001193125-22-196334 — 2.03, 8.01
- 2022-06-29 0001571996-22-000025 — 3.03, 5.03, 5.07, 8.01, 9.01
- 2022-05-26 0001571996-22-000013 — 2.02, 9.01
- 2022-02-24 0001571996-22-000004 — 2.02, 8.01, 9.01
- 2021-12-20 0001193125-21-362482 — 8.01, 9.01
- 2021-12-15 0001193125-21-357927 — 1.01, 2.03, 9.01
- 2021-12-07 0001193125-21-349218 — 8.01, 9.01
- 2021-11-23 0001571996-21-000060 — 2.02, 9.01
- 2021-11-05 0001571996-21-000057 — 1.02, 2.01, 7.01, 8.01, 9.01 — amendment, the index does not say of what
- 2021-11-01 0001571996-21-000052 — 8.01, 9.01
- 2021-11-01 0001193125-21-315488 — 1.01, 1.02, 2.01, 8.01, 9.01
- 2021-10-21 0001193125-21-304052 — 8.01, 9.01
- 2021-10-19 0001571996-21-000050 — 8.01, 9.01
- 2021-10-07 0001193125-21-294210 — 8.01, 9.01
- 2021-09-30 0001571996-21-000047 — 5.02
- 2021-09-27 0001571996-21-000045 — 8.01
- 2021-09-23 0001193125-21-280190 — 7.01, 8.01, 9.01
- 2021-09-20 0001193125-21-276810 — 7.01, 9.01
- 2021-08-26 0001571996-21-000037 — 2.02, 9.01
- 2021-07-01 0001571996-21-000034 — 3.02
- 2021-06-24 0001571996-21-000031 — 5.07
- 2021-06-24 0001193125-21-197644 — 7.01, 9.01
- 2021-06-16 0001571996-21-000029 — 5.02
- 2021-05-27 0001571996-21-000019 — 2.02, 9.01
- 2021-05-03 0001571996-21-000010 — 8.01, 9.01
- 2021-04-14 0001193125-21-116271 — 1.01, 7.01, 9.01
- 2021-02-25 0001571996-21-000003 — 2.02, 9.01
- 2021-02-18 0001193125-21-047844 — 1.01, 2.03, 9.01
- 2020-11-24 0001571996-20-000048 — 2.02, 9.01
- 2020-08-27 0001571996-20-000041 — 2.02, 9.01
- 2020-07-02 0001571996-20-000037 — 5.07
- 2020-05-28 0001571996-20-000028 — 2.02, 9.01
- 2020-04-09 0001193125-20-102602 — 1.01, 2.03, 9.01
- 2020-04-08 0001571996-20-000021 — 5.02
- 2020-04-03 0001571996-20-000019 — 8.01, 9.01
- 2020-03-26 0001571996-20-000015 — 7.01
- 2020-02-27 0001571996-20-000009 — 2.02, 8.01, 9.01
- 2020-02-18 0001571996-20-000005 — 8.01, 9.01
- 2020-01-09 0001571996-20-000002 — 3.02
- 2020-01-06 0001193125-20-002200 — 3.02
- 2019-12-13 0001193125-19-313947 — 3.02
- 2019-12-10 0001571996-19-000052 — 5.02
- 2019-12-02 0001571996-19-000044 — 5.02, 7.01, 9.01
- 2019-11-26 0001571996-19-000042 — 2.02, 9.01
- 2019-09-23 0001193125-19-252192 — 1.01, 2.03, 9.01
- 2019-08-29 0001571996-19-000036 — 2.02, 9.01
- 2019-08-22 0001193125-19-226939 — 7.01, 8.01, 9.01
- 2019-07-11 0001571996-19-000032 — 5.02, 5.07, 9.01
- 2019-07-03 0001571996-19-000030 — 3.02
- 2019-06-27 0001571996-19-000028 — 3.02
- 2019-05-30 0001571996-19-000021 — 2.02, 9.01
- 2019-04-02 0001571996-19-000010 — 5.02
- 2019-03-21 0001193125-19-082281 — 1.01, 1.02, 2.03, 9.01
- 2019-03-19 0001571996-19-000005 — 5.02, 9.01
- 2019-03-14 0001193125-19-074935 — 1.01, 2.03, 9.01
- 2019-03-07 0001193125-19-066045 — 8.01, 9.01
- 2019-02-28 0001571996-19-000002 — 2.02, 9.01
- 2018-12-28 0001193125-18-360943 — 1.01, 1.02, 3.01, 3.03, 5.02, 5.03, 7.01, 8.01, 9.01
- 2018-12-21 0001193125-18-356324 — 1.01, 2.03, 9.01
- 2018-12-14 0001193125-18-349469 — 8.01
- 2018-12-11 0001193125-18-346958 — 5.07, 8.01, 9.01
- 2018-11-29 0001571996-18-000041 — 2.02, 9.01
- 2018-11-28 0001571996-18-000037 — 7.01, 8.01, 9.01
- 2018-11-26 0001193125-18-333967 — 8.01, 9.01
- 2018-11-15 0001193125-18-328110 — 1.01, 9.01 — amendment of 0001193125-18-327222
- 2018-11-15 0001193125-18-327222 — 1.01, 7.01, 9.01
- 2018-10-03 0001193125-18-291390 — 8.01
- 2018-09-06 0001571996-18-000029 — 2.02, 9.01
- 2018-08-06 0001571996-18-000027 — 8.01, 9.01
- 2018-07-02 0001193125-18-210339 — 1.01, 7.01, 9.01
- 2018-06-28 0001571996-18-000024 — 5.07
- 2018-06-04 0001571996-18-000019 — 2.02, 9.01
- 2018-05-17 0001571996-18-000016 — 7.01
- 2018-04-26 0001571996-18-000009 — 7.01, 9.01
- 2018-03-08 0001193125-18-074168 — 2.02, 9.01
- 2018-02-02 0001193125-18-029947 — 7.01, 9.01
- 2017-12-07 0001571996-17-000042 — 2.02, 9.01
- 2017-10-24 0001571996-17-000037 — 1.01, 2.03, 9.01
- 2017-09-15 0001571996-17-000027 — 5.02
- 2017-09-07 0001571996-17-000017 — 2.02, 9.01
- 2017-08-24 0001571996-17-000014 — 8.01
- 2017-06-29 0001571996-17-000011 — 3.03, 5.07, 8.01, 9.01
- 2017-06-08 0001193125-17-197638 — 2.02, 9.01
- 2017-03-30 0001193125-17-102794 — 8.01
- 2017-03-30 0001193125-17-102777 — 2.02, 9.01
- 2017-03-09 0001193125-17-076981 — 1.01, 2.03, 9.01
- 2017-01-17 0001193125-17-011125 — 8.01
- 2016-12-15 0001193125-16-793722 — 8.01
- 2016-12-08 0001193125-16-787976 — 2.02, 9.01
- 2016-11-10 0001193125-16-765964 — 1.02, 8.01
- 2016-11-04 0001193125-16-760249 — 8.01
- 2016-09-13 0001193125-16-708600 — 3.02
- 2016-09-09 0001193125-16-706567 — 1.01, 1.02, 2.01, 2.03, 3.02, 3.03, 5.02, 9.01
- 2016-09-07 0001193125-16-703370 — 3.03, 5.07, 7.01, 8.01, 9.01
- 2016-09-06 0001193125-16-702057 — 2.02, 9.01
- 2016-08-31 0001193125-16-697268 — 8.01, 9.01
- 2016-08-26 0001193125-16-692921 — 8.01, 9.01
- 2016-07-11 0001193125-16-645610 — 8.01
- 2016-07-05 0001193125-16-641679 — 8.01
- 2016-06-22 0001193125-16-629055 — 1.01, 2.03, 8.01, 9.01
- 2016-06-21 0001193125-16-627071 — 8.01, 9.01
- 2016-06-10 0001193125-16-618483 — 2.02, 9.01
- 2016-06-09 0001193125-16-617893 — 8.01, 9.01

## late-filing notifications on or before 2024-12-10

- none on or before 2024-12-10

## item 2.02 — earnings release, exhibit 99.1

[0001571996-24-000130:8k_2_02:1]
EX-99.1
2
exhibit991earnings8kq3fy25.htm
EX-99.1

[0001571996-24-000130:8k_2_02:2]
Document

[0001571996-24-000130:8k_2_02:3]
Exhibit 99.1

[0001571996-24-000130:8k_2_02:4]
Dell Technologies Delivers Third Quarter Fiscal 2025 Financial Results

[0001571996-24-000130:8k_2_02:5]
News summary

[0001571996-24-000130:8k_2_02:6]
•Third quarter revenue of $24.4 billion, up 10% year over year

[0001571996-24-000130:8k_2_02:7]
•Infrastructure Solutions Group (ISG) revenue of $11.4 billion, up 34% year over year, with servers and networking revenue of $7.4 billion, up 58%

[0001571996-24-000130:8k_2_02:8]
•Client Solutions Group (CSG) revenue of $12.1 billion, down 1% year over year, with commercial client revenue up 3% at $10.1 billion

[0001571996-24-000130:8k_2_02:9]
•Diluted earnings per share of $1.58, up 16% year over year, and non-GAAP diluted earnings per share of $2.15, up 14%

[0001571996-24-000130:8k_2_02:10]
ROUND ROCK, Texas — Nov. 26, 2024

[0001571996-24-000130:8k_2_02:11]
Full story

[0001571996-24-000130:8k_2_02:12]
Dell Technologies (NYSE: DELL) announces financial results for its fiscal 2025 third quarter. Revenue was $24.4 billion, up 10% year over year. Operating income was $1.7 billion and non-GAAP operating income was $2.2 billion, both up 12% year over year. Diluted earnings per share was $1.58, and non-GAAP diluted earnings per share was $2.15, up 16% and 14% year over year, respectively.

[0001571996-24-000130:8k_2_02:13]
“We continued to build on our AI leadership and momentum, delivering combined ISG and CSG revenue of $23.5 billion, up 13% year over year,” said Yvonne McGill, chief financial officer, Dell Technologies. “Our continued focus on profitability resulted in EPS growth that outpaced revenue growth, and we again delivered strong cash performance.”

[0001571996-24-000130:8k_2_02:14]
Cash flow from operations was $1.6 billion, and Dell ended the quarter with $6.6 billion in cash and investments.

[0001571996-24-000130:8k_2_02:15]
1

[0001571996-24-000130:8k_2_02:16]
Third Quarter Fiscal 2025 Financial Results

[0001571996-24-000130:8k_2_02:17]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | November 1, 2024 |  | November 3, 2023 |  | Change |  | November 1, 2024 |  | November 3, 2023 |  | Change |
|  | (in millions, except per share amounts and percentages; unaudited) |
| Net revenue | $ | 24,366 |  |  | $ | 22,251 |  |  | 10% |  | $ | 71,636 |  |  | $ | 66,107 |  |  | 8% |
| Operating income | $ | 1,668 |  |  | $ | 1,486 |  |  | 12% |  | $ | 3,930 |  |  | $ | 3,720 |  |  | 6% |
| Net income | $ | 1,127 |  |  | $ | 1,004 |  |  | 12% |  | $ | 2,923 |  |  | $ | 2,037 |  |  | 43% |
| Change in cash from operating activities | $ | 1,553 |  |  | $ | 2,152 |  |  | (28)% |  | $ | 3,936 |  |  | $ | 7,143 |  |  | (45)% |
| Earnings per share - diluted | $ | 1.58 |  |  | $ | 1.36 |  |  | 16% |  | $ | 4.07 |  |  | $ | 2.78 |  |  | 46% |
| Non-GAAP operating income | $ | 2,199 |  |  | $ | 1,964 |  |  | 12% |  | $ | 5,707 |  |  | $ | 5,539 |  |  | 3% |
| Non-GAAP net income | $ | 1,540 |  |  | $ | 1,389 |  |  | 11% |  | $ | 3,834 |  |  | $ | 3,635 |  |  | 5% |
| Adjusted free cash flow | $ | 716 |  |  | $ | 860 |  |  | (17)% |  | $ | 2,623 |  |  | $ | 4,597 |  |  | (43)% |
| Non-GAAP earnings per share - diluted | $ | 2.15 |  |  | $ | 1.88 |  |  | 14% |  | $ | 5.31 |  |  | $ | 4.93 |  |  | 8% |

[0001571996-24-000130:8k_2_02:18]
Information about Dell Technologies’ use of non-GAAP financial information is provided under “Non-GAAP Financial Measures” below. All comparisons in this press release are year over year unless otherwise noted.

[0001571996-24-000130:8k_2_02:19]
Infrastructure Solutions Group (ISG) delivered record third-quarter revenue of $11.4 billion, up 34% year over year. Servers and networking revenue was $7.4 billion, up 58%, with demand growth across AI and traditional servers. Storage revenue was $4.0 billion, up 4%. Operating income was $1.5 billion.

[0001571996-24-000130:8k_2_02:20]
“AI is a robust opportunity for us with no signs of slowing down,” said Jeff Clarke, vice chairman and chief operating officer, Dell Technologies. “Interest in our portfolio is at an all-time high, driving record AI server orders demand of $3.6 billion in Q3 and a pipeline that grew more than 50%, with growth across all customer types.”

[0001571996-24-000130:8k_2_02:21]
Client Solutions Group (CSG) delivered third quarter revenue of $12.1 billion, down 1% year over year. Commercial client revenue was up 3% at $10.1 billion, and Consumer revenue was $2.0 billion, down 18%. Operating income was $694 million.

[0001571996-24-000130:8k_2_02:22]
2

[0001571996-24-000130:8k_2_02:23]
Operating Segments Results

[0001571996-24-000130:8k_2_02:24]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | November 1, 2024 |  | November 3, 2023 |  | Change |  | November 1, 2024 |  | November 3, 2023 |  | Change |
|  | (in millions, except percentages; unaudited) |
| Infrastructure Solutions Group (ISG): |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Servers and networking | $ | 7,364 |  | $ | 4,656 |  |  | 58% |  | $ | 20,502 |  |  | $ | 12,767 |  |  | 61% |
| Storage | 4,004 |  |  | 3,843 |  |  | 4% |  | 11,739 |  |  | 11,786 |  |  | —% |
| Total ISG net revenue | $ | 11,368 |  |  | $ | 8,499 |  |  | 34% |  | $ | 32,241 |  |  | $ | 24,553 |  |  | 31% |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| ISG operating income | $ | 1,508 |  |  | $ | 1,069 |  |  | 41% |  | $ | 3,528 |  |  | $ | 2,858 |  |  | 23% |
| % of ISG net revenue | 13.3 | % |  | 12.6 | % |  |  |  | 10.9 | % |  | 11.6 | % |  |  |
| % of total reportable segment operating income | 68 | % |  | 54 | % |  |  |  | 62 | % |  | 51 | % |  |  |
| Client Solutions Group (CSG): |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 10,138 |  |  | $ | 9,835 |  |  | 3% |  | $ | 30,848 |  |  | $ | 30,251 |  |  | 2% |
| Consumer | 1,993 |  |  | 2,441 |  |  | (18)% |  | 5,664 |  |  | 6,950 |  |  | (19)% |
| Total CSG net revenue | $ | 12,131 |  |  | $ | 12,276 |  |  | (1)% |  | $ | 36,512 |  |  | $ | 37,201 |  |  | (2)% |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| CSG operating income | $ | 694 |  |  | $ | 925 |  |  | (25)% |  | $ | 2,193 |  |  | $ | 2,786 |  |  | (21)% |
| % of CSG net revenue | 5.7 | % |  | 7.5 | % |  |  |  | 6.0 | % |  | 7.5 | % |  |  |
| % of total reportable segment operating income | 32 | % |  | 46 | % |  |  |  | 38 | % |  | 49 | % |  |  |

[0001571996-24-000130:8k_2_02:25]
Conference call information

[0001571996-24-000130:8k_2_02:26]
As previously announced, the company will hold a conference call to discuss its performance and financial guidance on Nov. 26 at 3:30 p.m. CST. Prior to the start of the conference call, prepared remarks and a presentation containing additional financial and operating information prior to financial guidance may be downloaded from investors.delltechnologies.com. The conference call will be broadcast live over the internet and can be accessed at https://investors.delltechnologies.com/news-events/upcoming-events.

[0001571996-24-000130:8k_2_02:27]
For those unable to listen to the live broadcast, the final remarks and presentation with financial guidance will be available following the broadcast, and an archived version will be available at the same location for one year.

[0001571996-24-000130:8k_2_02:28]
About Dell Technologies

[0001571996-24-000130:8k_2_02:29]
Dell Technologies (NYSE:DELL) helps organizations and individuals build their digital future and transform how they work, live and play. The company provides customers with the industry’s broadest and most innovative technology and services portfolio for the AI era.

[0001571996-24-000130:8k_2_02:30]
Contacts

[0001571996-24-000130:8k_2_02:31]
Investors: Investor_Relations@Dell.com

[0001571996-24-000130:8k_2_02:32]
Media: Media.Relations@Dell.com

[0001571996-24-000130:8k_2_02:33]
# # #

[0001571996-24-000130:8k_2_02:34]
Copyright © 2024 Dell Inc. or its subsidiaries. All Rights Reserved. Dell Technologies, Dell, EMC and Dell EMC are trademarks of Dell Inc. or its subsidiaries. Other trademarks may be trademarks of their respective owners.

[0001571996-24-000130:8k_2_02:35]
Non-GAAP Financial Measures:

[0001571996-24-000130:8k_2_02:36]
This press release presents information about non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, non-GAAP net income attributable to Dell Technologies Inc., non-GAAP earnings per share attributable to Dell Technologies Inc. – diluted, free cash flow, and adjusted free cash flow, all of which are non-GAAP financial measures provided as a supplement to the results provided in accordance with generally accepted accounting principles in the United States of America (“GAAP”). A reconciliation of each non-GAAP financial measure to the most directly comparable GAAP financial measure is provided in the attached tables for each of the fiscal periods indicated.

[0001571996-24-000130:8k_2_02:37]
Special Note on Forward-Looking Statements:

[0001571996-24-000130:8k_2_02:38]
Dell Technologies’ results or events in future periods could differ materially from those expressed or implied by these forward-looking statements because of risks, uncertainties, and other factors that include, but are not limited to, the following: adverse global economic conditions and instability in financial markets; competitive pressures; Dell Technologies’ reliance on third-party suppliers for products and components, including reliance on single-source or limited-source suppliers; Dell Technologies’ ability to achieve favorable pricing from its vendors; Dell Technologies’ execution of its strategy; social and ethical issues relating to the use of new and evolving technologies; Dell Technologies’ ability to manage solutions and products and services transitions in an effective manner; Dell Technologies’ ability to deliver high-quality products, software, and services; cyber attacks or other data security incidents; Dell Technologies’ ability to successfully execute on strategic initiatives including acquisitions, divestitures or cost savings measures; Dell Technologies’ foreign operations and ability to generate substantial non-U.S. net revenue; Dell Technologies’ product, services, customer, and geographic sales mix, and seasonal sales trends; the performance of Dell Technologies’ sales channel partners; access to the capital markets by Dell Technologies or its customers; material impairment of the value of goodwill or intangible assets; adverse economic conditions and the effect of additional regulation on Dell Technologies’ financial services activities; counterparty default risks; the loss by Dell Technologies of any contracts for ISG services and solutions and its ability to perform such contracts at their estimated costs; loss by Dell Technologies of government contracts; Dell Technologies’ ability to develop and protect its proprietary intellectual property or obtain licenses to intellectual property developed by others on commercially reasonable and competitive terms; disruptions in Dell Technologies’ infrastructure; Dell Technologies’ ability to hedge effectively its exposure to fluctuations in foreign currency exchange rates and interest rates; expiration of tax holidays or favorable tax rate structures, or unfavorable outcomes in tax audits and other tax compliance matters; impairment of portfolio investments; unfavorable results of legal proceedings; expectations relating to environmental, social and governance (ESG) considerations; compliance requirements of changing environmental and safety laws, human rights laws, or other laws; the effect of armed hostilities, terrorism, natural disasters, or public health issues; the effect of global climate change and legal, regulatory, or market measures to address climate change; Dell Technologies’ dependence on the services of Michael Dell and key employees; Dell Technologies’ level of indebtedness; and business and financial factors and legal restrictions affecting continuation of Dell Technologies’ quarterly cash dividend policy and dividend rate.

[0001571996-24-000130:8k_2_02:39]
This list of risks, uncertainties, and other factors is not complete. Dell Technologies discusses some of these matters more fully, as well as certain risk factors that could affect Dell Technologies’ business, financial condition, results of operations, and prospects, in its reports filed with the SEC, including Dell Technologies’ annual report on Form 10-K for the fiscal year ended February 2, 2024, quarterly reports on Form 10-Q, and current reports on Form 8-K. These filings are available for review through the SEC’s website at www.sec.gov. Any or all forward-looking statements Dell Technologies makes may turn out to be wrong and can be affected by inaccurate assumptions Dell Technologies might make or by known or unknown risks, uncertainties, and other factors, including those identified in this press release. Accordingly, you should not place undue reliance on the forward-looking statements made in this press release, which speak only as of its date. Dell Technologies does not undertake to update, and expressly disclaims any duty to update, its forward-looking statements, whether as a result of circumstances or events that arise after the date they are made, new information, or otherwise.

[0001571996-24-000130:8k_2_02:40]
4

[0001571996-24-000130:8k_2_02:41]
DELL TECHNOLOGIES INC.

[0001571996-24-000130:8k_2_02:42]
Condensed Consolidated Statements of Income and Related Financial Highlights

[0001571996-24-000130:8k_2_02:43]
(in millions, except percentages; unaudited)

[0001571996-24-000130:8k_2_02:44]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | November 1, 2024 |  | November 3, 2023 |  | Change |  | November 1, 2024 |  | November 3, 2023 |  | Change |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Products | 18,290 |  |  | 16,233 |  |  | 13% |  | 53,371 |  |  | 48,204 |  |  | 11% |
| Services | 6,076 |  |  | 6,018 |  |  | 1% |  | 18,265 |  |  | 17,903 |  |  | 2% |
| Total net revenue | 24,366 |  |  | 22,251 |  |  | 10% |  | 71,636 |  |  | 66,107 |  |  | 8% |
| Cost of net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Products | 15,541 |  |  | 13,546 |  |  | 15% |  | 45,386 |  |  | 39,923 |  |  | 14% |
| Services | 3,518 |  |  | 3,557 |  |  | (1)% |  | 10,826 |  |  | 10,631 |  |  | 2% |
| Total cost of net revenue | 19,059 |  |  | 17,103 |  |  | 11% |  | 56,212 |  |  | 50,554 |  |  | 11% |
| Gross margin | 5,307 |  |  | 5,148 |  |  | 3% |  | 15,424 |  |  | 15,553 |  |  | (1)% |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative | 2,894 |  |  | 2,970 |  |  | (3)% |  | 9,206 |  |  | 9,748 |  |  | (6)% |
| Research and development | 745 |  |  | 692 |  |  | 8% |  | 2,288 |  |  | 2,085 |  |  | 10% |
| Total operating expenses | 3,639 |  |  | 3,662 |  |  | (1)% |  | 11,494 |  |  | 11,833 |  |  | (3)% |
| Operating income | 1,668 |  |  | 1,486 |  |  | 12% |  | 3,930 |  |  | 3,720 |  |  | 6% |
| Interest and other, net | (276) |  |  | (306) |  |  | 10% |  | (1,002) |  |  | (1,121) |  |  | 11% |
| Income before income taxes | 1,392 |  |  | 1,180 |  |  | 18% |  | 2,928 |  |  | 2,599 |  |  | 13% |
| Income tax expense | 265 |  |  | 176 |  |  | 51% |  | 5 |  |  | 562 |  |  | (99)% |
| Net income | 1,127 |  |  | 1,004 |  |  | 12% |  | 2,923 |  |  | 2,037 |  |  | 43% |
| Less: Net loss attributable to non-controlling interests | (5) |  |  | (2) |  |  | (150)% |  | (15) |  |  | (14) |  |  | (7)% |
| Net income attributable to Dell Technologies Inc. | $ | 1,132 |  |  | $ | 1,006 |  |  | 13% |  | $ | 2,938 |  |  | $ | 2,051 |  |  | 43% |
| Percentage of Total Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Gross margin | 21.8 | % |  | 23.1 | % |  |  |  | 21.5 | % |  | 23.5 | % |  |  |
| Selling, general, and administrative | 11.9 | % |  | 13.3 | % |  |  |  | 12.8 | % |  | 14.7 | % |  |  |
| Research and development | 3.1 | % |  | 3.1 | % |  |  |  | 3.2 | % |  | 3.2 | % |  |  |
| Operating expenses | 15.0 | % |  | 16.4 | % |  |  |  | 16.0 | % |  | 17.9 | % |  |  |
| Operating income | 6.8 | % |  | 6.7 | % |  |  |  | 5.5 | % |  | 5.6 | % |  |  |
| Income before income taxes | 5.7 | % |  | 5.3 | % |  |  |  | 4.1 | % |  | 3.9 | % |  |  |
| Net income | 4.6 | % |  | 4.5 | % |  |  |  | 4.1 | % |  | 3.1 | % |  |  |
| Income tax rate | 19.0 | % |  | 14.9 | % |  |  |  | 0.2 | % |  | 21.6 | % |  |  |

[0001571996-24-000130:8k_2_02:45]
Amounts are based on underlying data and may not visually foot due to rounding.

[0001571996-24-000130:8k_2_02:46]
5

[0001571996-24-000130:8k_2_02:47]
DELL TECHNOLOGIES INC.

[0001571996-24-000130:8k_2_02:48]
Condensed Consolidated Statements of Financial Position

[0001571996-24-000130:8k_2_02:49]
(in millions; unaudited)

[0001571996-24-000130:8k_2_02:50]
|  | November 1, 2024 |  | February 2, 2024 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 5,225 |  |  | $ | 7,366 |  |
| Accounts receivable, net of allowance of $62 and $71 | 11,189 |  |  | 9,343 |  |
| Short-term financing receivables, net of allowance of $74 and $79 | 5,001 |  |  | 4,643 |  |
| Inventories | 6,652 |  |  | 3,622 |  |
| Other current assets | 9,306 |  |  | 10,973 |  |
| Current assets held for sale | 662 |  |  | — |  |
| Total current assets | 38,035 |  |  | 35,947 |  |
| Property, plant, and equipment, net | 6,327 |  |  | 6,432 |  |
| Long-term investments | 1,312 |  |  | 1,316 |  |
| Long-term financing receivables, net of allowance of $70 and $91 | 5,849 |  |  | 5,877 |  |
| Goodwill | 19,243 |  |  | 19,700 |  |
| Intangible assets, net | 5,147 |  |  | 5,701 |  |
| Other non-current assets | 6,038 |  |  | 7,116 |  |
| Total assets | $ | 81,951 |  |  | $ | 82,089 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Short-term debt | $ | 5,612 |  |  | $ | 6,982 |  |
| Accounts payable | 23,400 |  |  | 19,389 |  |
| Accrued and other | 6,490 |  |  | 6,805 |  |
| Short-term deferred revenue | 13,787 |  |  | 15,318 |  |
| Current liabilities held for sale | 211 |  |  | — |  |
| Total current liabilities | 49,500 |  |  | 48,494 |  |
| Long-term debt | 19,410 |  |  | 19,012 |  |
| Long-term deferred revenue | 12,424 |  |  | 13,827 |  |
| Other non-current liabilities | 2,807 |  |  | 3,065 |  |
| Total liabilities | 84,141 |  |  | 84,398 |  |
| Stockholders’ equity (deficit): |  |  |  |
| Common stock and capital in excess of $0.01 par value | 8,951 |  |  | 8,926 |  |
| Treasury stock at cost | (7,747) |  |  | (5,900) |  |
| Accumulated deficit | (2,669) |  |  | (4,630) |  |
| Accumulated other comprehensive loss | (820) |  |  | (800) |  |
| Total Dell Technologies Inc. stockholders’ equity (deficit) | (2,285) |  |  | (2,404) |  |
| Non-controlling interests | 95 |  |  | 95 |  |
| Total stockholders’ equity (deficit) | (2,190) |  |  | (2,309) |  |
| Total liabilities and stockholders’ equity | $ | 81,951 |  |  | $ | 82,089 |  |

[0001571996-24-000130:8k_2_02:51]
DELL TECHNOLOGIES INC.

[0001571996-24-000130:8k_2_02:52]
Condensed Consolidated Statements of Cash Flows

[0001571996-24-000130:8k_2_02:53]
(in millions; unaudited)

[0001571996-24-000130:8k_2_02:54]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 1, 2024 |  | November 3, 2023 |  | November 1, 2024 |  | November 3, 2023 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |
| Net income | $ | 1,127 |  |  | $ | 1,004 |  |  | $ | 2,923 |  |  | $ | 2,037 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: | 426 |  |  | 1,148 |  |  | 1,013 |  |  | 5,106 |  |
| Change in cash from operating activities | 1,553 |  |  | 2,152 |  |  | 3,936 |  |  | 7,143 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |
| Purchases of investments | (19) |  |  | (30) |  |  | (83) |  |  | (143) |  |
| Maturities and sales of investments | 121 |  |  | 23 |  |  | 337 |  |  | 150 |  |
| Capital expenditures and capitalized software development costs | (639) |  |  | (704) |  |  | (1,917) |  |  | (2,029) |  |
| Acquisition of businesses and assets, net | — |  |  | (127) |  |  | — |  |  | (127) |  |
| Other | 13 |  |  | 13 |  |  | 126 |  |  | 35 |  |
| Change in cash from investing activities | (524) |  |  | (825) |  |  | (1,537) |  |  | (2,114) |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |
| Proceeds from the issuance of common stock | — |  |  | 4 |  |  | 1 |  |  | 8 |  |
| Repurchases of common stock | (429) |  |  | (702) |  |  | (1,854) |  |  | (1,202) |  |
| Repurchases of common stock for employee tax withholdings | (25) |  |  | (42) |  |  | (560) |  |  | (354) |  |
| Payments of dividends and dividend equivalents | (312) |  |  | (266) |  |  | (964) |  |  | (811) |  |
| Proceeds from debt | 3,680 |  |  | 2,249 |  |  | 8,613 |  |  | 6,904 |  |
| Repayments of debt | (3,200) |  |  | (2,684) |  |  | (9,594) |  |  | (9,766) |  |
| Debt-related costs and other, net | (29) |  |  | (5) |  |  | (66) |  |  | (54) |  |
| Change in cash from financing activities | (315) |  |  | (1,446) |  |  | (4,424) |  |  | (5,275) |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash | 19 |  |  | (83) |  |  | (78) |  |  | (200) |  |
| Change in cash, cash equivalents, and restricted cash | 733 |  |  | (202) |  |  | (2,103) |  |  | (446) |  |
| Cash, cash equivalents, and restricted cash at beginning of the period | 4,671 |  |  | 8,650 |  |  | 7,507 |  |  | 8,894 |  |
| Cash, cash equivalents, and restricted cash at end of the period | $ | 5,404 |  |  | $ | 8,448 |  |  | $ | 5,404 |  |  | $ | 8,448 |  |

[0001571996-24-000130:8k_2_02:55]
7

[0001571996-24-000130:8k_2_02:56]
DELL TECHNOLOGIES INC.

[0001571996-24-000130:8k_2_02:57]
Segment Information

[0001571996-24-000130:8k_2_02:58]
(in millions, except percentages; unaudited; continued on next page)

[0001571996-24-000130:8k_2_02:59]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | November 1, 2024 |  | November 3, 2023 |  | Change |  | November 1, 2024 |  | November 3, 2023 |  | Change |
| Infrastructure Solutions Group (ISG): |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Servers and networking | $ | 7,364 |  | $ | 4,656 |  |  | 58% |  | $ | 20,502 |  |  | $ | 12,767 |  |  | 61% |
| Storage | 4,004 |  |  | 3,843 |  |  | 4% |  | 11,739 |  |  | 11,786 |  |  | —% |
| Total ISG net revenue | $ | 11,368 |  |  | $ | 8,499 |  |  | 34% |  | $ | 32,241 |  |  | $ | 24,553 |  |  | 31% |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| ISG operating income | $ | 1,508 |  |  | $ | 1,069 |  |  | 41% |  | $ | 3,528 |  |  | $ | 2,858 |  |  | 23% |
| % of ISG net revenue | 13.3 | % |  | 12.6 | % |  |  |  | 10.9 | % |  | 11.6 | % |  |  |
| % of total reportable segment operating income | 68 | % |  | 54 | % |  |  |  | 62 | % |  | 51 | % |  |  |
| Client Solutions Group (CSG): |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 10,138 |  |  | $ | 9,835 |  |  | 3% |  | $ | 30,848 |  |  | $ | 30,251 |  |  | 2% |
| Consumer | 1,993 |  |  | 2,441 |  |  | (18)% |  | 5,664 |  |  | 6,950 |  |  | (19)% |
| Total CSG net revenue | $ | 12,131 |  |  | $ | 12,276 |  |  | (1)% |  | $ | 36,512 |  |  | $ | 37,201 |  |  | (2)% |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| CSG operating income | $ | 694 |  |  | $ | 925 |  |  | (25)% |  | $ | 2,193 |  |  | $ | 2,786 |  |  | (21)% |
| % of CSG net revenue | 5.7 | % |  | 7.5 | % |  |  |  | 6.0 | % |  | 7.5 | % |  |  |
| % of total reportable segment operating income | 32 | % |  | 46 | % |  |  |  | 38 | % |  | 49 | % |  |  |

[0001571996-24-000130:8k_2_02:60]
Amounts are based on underlying data and may not visually foot due to rounding.

[0001571996-24-000130:8k_2_02:61]
8

[0001571996-24-000130:8k_2_02:62]
DELL TECHNOLOGIES INC.

[0001571996-24-000130:8k_2_02:63]
Segment Information

[0001571996-24-000130:8k_2_02:64]
(in millions, except percentages; unaudited; continued)

[0001571996-24-000130:8k_2_02:65]
|  | Three Months Ended |  | Nine Months Ended |  |  |
|  | November 1, 2024 |  | November 3, 2023 |  | November 1, 2024 |  | November 3, 2023 |  |  |
| Reconciliation to consolidated net revenue: |  |  |  |  |  |  |  |  |  |
| Reportable segment net revenue | $ | 23,499 |  |  | $ | 20,775 |  |  | $ | 68,753 |  |  | $ | 61,754 |  |  |  |
| Other businesses (a) | 867 |  |  | 1,474 |  |  | 2,882 |  |  | 4,345 |  |  |  |
| Unallocated transactions (b) | — |  |  | 2 |  |  | 1 |  |  | 8 |  |  |  |
| Total consolidated net revenue | $ | 24,366 |  |  | $ | 22,251 |  |  | $ | 71,636 |  |  | $ | 66,107 |  |  |  |
| Reconciliation to consolidated operating income: |  |  |  |  |  |  |  |  |  |
| Reportable segment operating income | $ | 2,202 |  |  | $ | 1,994 |  |  | $ | 5,721 |  |  | $ | 5,644 |  |  |  |
| Other businesses (a) | (3) |  |  | (32) |  |  | (14) |  |  | (112) |  |  |  |
| Unallocated transactions (b) | — |  |  | 2 |  |  | — |  |  | 7 |  |  |  |
| Amortization of intangibles (c) | (168) |  |  | (207) |  |  | (504) |  |  | (623) |  |  |  |
| Stock-based compensation expense (d) | (198) |  |  | (227) |  |  | (599) |  |  | (675) |  |  |  |
| Other corporate expenses (e) | (165) |  |  | (44) |  |  | (674) |  |  | (521) |  |  |  |
| Total consolidated operating income | $ | 1,668 |  |  | $ | 1,486 |  |  | $ | 3,930 |  |  | $ | 3,720 |  |  |  |

[0001571996-24-000130:8k_2_02:66]
_________________

[0001571996-24-000130:8k_2_02:67]
(a)Other businesses consists of: 1) Dell’s resale of standalone VMware LLC, formerly VMware, Inc. products and services, “VMware Resale,” 2) Secureworks, and 3) Virtustream, and do not meet the requirements for a reportable segment, either individually or collectively.

[0001571996-24-000130:8k_2_02:68]
(b)Unallocated transactions includes other corporate items that are not allocated to Dell Technologies’ reportable segments.

[0001571996-24-000130:8k_2_02:69]
(c)Amortization of intangibles includes non-cash purchase accounting adjustments that are primarily related to the EMC merger transaction.

[0001571996-24-000130:8k_2_02:70]
(d)Stock-based compensation expense consists of equity awards granted based on the estimated fair value of those awards at grant date.

[0001571996-24-000130:8k_2_02:71]
(e)Other corporate expenses consist primarily of severance expenses, payroll taxes associated with stock-based compensation, facility action costs, transaction-related expenses, impairment charges, and incentive charges related to equity investments.

[0001571996-24-000130:8k_2_02:72]
SUPPLEMENTAL SELECTED NON-GAAP FINANCIAL MEASURES

[0001571996-24-000130:8k_2_02:73]
These tables present information about the Company’s non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, non-GAAP net income attributable to Dell Technologies Inc., non-GAAP earnings per share attributable to Dell Technologies Inc. - diluted, free cash flow and adjusted free cash flow, all of which are non-GAAP financial measures provided as a supplement to the results provided in accordance with generally accepted accounting principles in the United States of America (“GAAP”). A detailed discussion of Dell Technologies’ reasons for including these non-GAAP financial measures, the limitations associated with these measures, the items excluded from these measures, and our reason for excluding those items are presented in “Management’s Discussion and Analysis of Financial Condition and Results of Operations — Non-GAAP Financial Measures” in our periodic reports filed with the SEC. Dell Technologies encourages investors to review the non-GAAP discussion in these reports in conjunction with the presentation of non-GAAP financial measures.

[0001571996-24-000130:8k_2_02:74]
10

[0001571996-24-000130:8k_2_02:75]
DELL TECHNOLOGIES INC.

[0001571996-24-000130:8k_2_02:76]
Selected Financial Measures

[0001571996-24-000130:8k_2_02:77]
(in millions, except per share amounts and percentages; unaudited)

[0001571996-24-000130:8k_2_02:78]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | November 1, 2024 |  | November 3, 2023 |  | Change |  | November 1, 2024 |  | November 3, 2023 |  | Change |
| Net revenue | $ | 24,366 |  |  | $ | 22,251 |  |  | 10% |  | $ | 71,636 |  |  | $ | 66,107 |  |  | 8% |
| Non-GAAP gross margin | $ | 5,437 |  |  | $ | 5,276 |  |  | 3% |  | $ | 15,848 |  |  | $ | 15,976 |  |  | (1)% |
| % of net revenue | 22.3 | % |  | 23.7 | % |  |  |  | 22.1 | % |  | 24.2 | % |  |  |
| Non-GAAP operating expenses | $ | 3,238 |  |  | $ | 3,312 |  |  | (2)% |  | $ | 10,141 |  |  | $ | 10,437 |  |  | (3)% |
| % of net revenue | 13.3 | % |  | 14.9 | % |  |  |  | 14.1 | % |  | 15.8 | % |  |  |
| Non-GAAP operating income | $ | 2,199 |  |  | $ | 1,964 |  |  | 12% |  | $ | 5,707 |  | $ | 5,539 |  | 3% |
| % of net revenue | 9.0 | % |  | 8.8 | % |  |  |  | 8.0 | % |  | 8.4 | % |  |  |
| Non-GAAP net income | $ | 1,540 |  |  | $ | 1,389 |  |  | 11% |  | $ | 3,834 |  |  | $ | 3,635 |  |  | 5% |
| % of net revenue | 6.3 | % |  | 6.2 | % |  |  |  | 5.4 | % |  | 5.5 | % |  |  |
| Non-GAAP earnings per share - diluted | $ | 2.15 |  |  | $ | 1.88 |  |  | 14% |  | $ | 5.31 |  |  | $ | 4.93 |  |  | 8% |

[0001571996-24-000130:8k_2_02:79]
Amounts are based on underlying data and may not visually foot due to rounding.

[0001571996-24-000130:8k_2_02:80]
DELL TECHNOLOGIES INC.

[0001571996-24-000130:8k_2_02:81]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-24-000130:8k_2_02:82]
(in millions, except percentages; unaudited; continued on next page)

[0001571996-24-000130:8k_2_02:83]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | November 1, 2024 |  | November 3, 2023 |  | Change |  | November 1, 2024 |  | November 3, 2023 |  | Change |
| Gross margin | $ | 5,307 |  |  | $ | 5,148 |  |  | 3% |  | $ | 15,424 |  |  | $ | 15,553 |  |  | (1)% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 60 |  |  | 84 |  |  |  |  | 179 |  |  | 247 |  |  |  |
| Stock-based compensation expense | 39 |  |  | 37 |  |  |  |  | 115 |  |  | 112 |  |  |  |
| Other corporate expenses | 31 |  |  | 7 |  |  |  |  | 130 |  |  | 64 |  |  |  |
| Non-GAAP gross margin | $ | 5,437 |  |  | $ | 5,276 |  |  | 3% |  | $ | 15,848 |  |  | $ | 15,976 |  |  | (1)% |
| Operating expenses | $ | 3,639 |  |  | $ | 3,662 |  |  | (1)% |  | $ | 11,494 |  |  | $ | 11,833 |  |  | (3)% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | (108) |  |  | (123) |  |  |  |  | (325) |  |  | (376) |  |  |  |
| Stock-based compensation expense | (159) |  |  | (190) |  |  |  |  | (484) |  |  | (563) |  |  |  |
| Other corporate expenses | (134) |  |  | (37) |  |  |  |  | (544) |  |  | (457) |  |  |  |
| Non-GAAP operating expenses | $ | 3,238 |  |  | $ | 3,312 |  |  | (2)% |  | $ | 10,141 |  |  | $ | 10,437 |  |  | (3)% |
| Operating income | $ | 1,668 |  |  | $ | 1,486 |  |  | 12% |  | $ | 3,930 |  |  | $ | 3,720 |  |  | 6% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 168 |  |  | 207 |  |  |  |  | 504 |  |  | 623 |  |  |  |
| Stock-based compensation expense | 198 |  |  | 227 |  |  |  |  | 599 |  |  | 675 |  |  |  |
| Other corporate expenses | 165 |  |  | 44 |  |  |  |  | 674 |  |  | 521 |  |  |  |
| Non-GAAP operating income | $ | 2,199 |  |  | $ | 1,964 |  |  | 12% |  | $ | 5,707 |  |  | $ | 5,539 |  |  | 3% |
| Net income | $ | 1,127 |  |  | $ | 1,004 |  |  | 12% |  | $ | 2,923 |  |  | $ | 2,037 |  |  | 43% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 168 |  |  | 207 |  |  |  |  | 504 |  |  | 623 |  |  |  |
| Stock-based compensation expense | 198 |  |  | 227 |  |  |  |  | 599 |  |  | 675 |  |  |  |
| Other corporate expenses | 166 |  |  | 36 |  |  |  |  | 665 |  |  | 566 |  |  |  |
| Fair value adjustments on equity investments | (46) |  |  | (8) |  |  |  |  | (21) |  |  | 36 |  |  |  |
| Aggregate adjustment for income taxes (a) | (73) |  |  | (77) |  |  |  |  | (836) |  |  | (302) |  |  |  |
| Non-GAAP net income | $ | 1,540 |  |  | $ | 1,389 |  |  | 11% |  | $ | 3,834 |  |  | $ | 3,635 |  |  | 5% |

[0001571996-24-000130:8k_2_02:84]
____________________

[0001571996-24-000130:8k_2_02:85]
(a)    Beginning in Fiscal 2025, our non-GAAP income tax is calculated using a fixed estimated annual tax rate.

[0001571996-24-000130:8k_2_02:86]
12

[0001571996-24-000130:8k_2_02:87]
DELL TECHNOLOGIES INC.

[0001571996-24-000130:8k_2_02:88]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-24-000130:8k_2_02:89]
(unaudited; continued)

[0001571996-24-000130:8k_2_02:90]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |  |  |  |  |
|  | November 1, 2024 |  | November 3, 2023 |  | Change |  | November 1,2024 |  | November 3,2023 |  | Change |  |  |  |  |
| Earnings per share attributable to Dell Technologies Inc. — diluted | $ | 1.58 |  |  | $ | 1.36 |  |  | 16 | % |  | $ | 4.07 |  |  | $ | 2.78 |  |  | 46 | % |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 0.23 |  |  | 0.28 |  |  |  |  | 0.70 |  |  | 0.84 |  |  |  |  |  |  |  |
| Stock-based compensation expense | 0.28 |  |  | 0.31 |  |  |  |  | 0.83 |  |  | 0.91 |  |  |  |  |  |  |  |
| Other corporate expenses | 0.23 |  |  | 0.04 |  |  |  |  | 0.92 |  |  | 0.77 |  |  |  |  |  |  |  |
| Fair value adjustments on equity investments | (0.06) |  |  | (0.01) |  |  |  |  | (0.03) |  |  | 0.05 |  |  |  |  |  |  |  |
| Aggregate adjustment for income taxes (a) | (0.10) |  |  | (0.10) |  |  |  |  | (1.16) |  |  | (0.41) |  |  |  |  |  |  |  |
| Total non-GAAP adjustments attributable to non-controlling interests | (0.01) |  |  | — |  |  |  |  | (0.02) |  |  | (0.01) |  |  |  |  |  |  |  |
| Non-GAAP earnings per share attributable to Dell Technologies Inc. — diluted | $ | 2.15 |  |  | $ | 1.88 |  |  | 14 | % |  | $ | 5.31 |  |  | $ | 4.93 |  |  | 8 | % |  |  |  |  |

[0001571996-24-000130:8k_2_02:91]
____________________

[0001571996-24-000130:8k_2_02:92]
(a)    Beginning in Fiscal 2025, our non-GAAP income tax is calculated using a fixed estimated annual tax rate.

[0001571996-24-000130:8k_2_02:93]
13

[0001571996-24-000130:8k_2_02:94]
DELL TECHNOLOGIES INC.

[0001571996-24-000130:8k_2_02:95]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-24-000130:8k_2_02:96]
(in millions, except percentages; unaudited; continued)

[0001571996-24-000130:8k_2_02:97]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |  |  |  |  |
|  | November 1, 2024 |  | November 3, 2023 |  | Change |  | November 1,2024 |  | November 3,2023 |  | Change |  |  |  |  |
| Cash flow from operations | $ | 1,553 |  |  | $ | 2,152 |  |  | (28) | % |  | $ | 3,936 |  |  | $ | 7,143 |  |  | (45) | % |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Capital expenditures and capitalized software development costs, net (a) | (639) |  |  | (704) |  |  |  |  | (1,861) |  |  | (2,026) |  |  |  |  |  |  |  |
| Free cash flow | $ | 914 |  |  | $ | 1,448 |  |  | (37) | % |  | $ | 2,075 |  |  | $ | 5,117 |  |  | (59) | % |  |  |  |  |
| Free cash flow | $ | 914 |  |  | $ | 1,448 |  |  | (37) | % |  | $ | 2,075 |  |  | $ | 5,117 |  |  | (59) | % |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Financing receivables (b) | (233) |  |  | (575) |  |  |  |  | 419 |  |  | (445) |  |  |  |  |  |  |  |
| Equipment under operating leases (c) | 35 |  |  | (13) |  |  |  |  | 129 |  |  | (75) |  |  |  |  |  |  |  |
| Adjusted free cash flow | $ | 716 |  |  | $ | 860 |  |  | (17) | % |  | $ | 2,623 |  |  | $ | 4,597 |  |  | (43) | % |  |  |  |  |

[0001571996-24-000130:8k_2_02:98]
____________________

[0001571996-24-000130:8k_2_02:99]
(a)    Capital expenditures and capitalized software development costs is net of proceeds from sales of facilities, land, and other assets.

[0001571996-24-000130:8k_2_02:100]
(b)    Financing receivables represent the operating cash flow impact from the change in DFS financing receivables.

[0001571996-24-000130:8k_2_02:101]
(c)    Equipment under operating leases represents the net change of capital expenditures and depreciation expense for DFS leases and contractually embedded leases identified within flexible consumption arrangements.

[0001571996-24-000130:8k_2_02:102]
14
