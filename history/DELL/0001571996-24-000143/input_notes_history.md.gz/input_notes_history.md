# DELL note change history — 0001571996-24-000090 → 0001571996-24-000143


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2024-12-10):
[0001571996-24-000143:note_history:1]
The Company has contractual obligations to purchase goods or services, which specify significant terms (including fixed or minimum quantities to be purchased), fixed, minimum, or variable price provisions, and the approximate timing of the transaction. As of November 1, 2024, such purchase obligations were $6.4 billion for the remaining three months of Fiscal 2025; $0.5 billion for Fiscal 2026; and $1.2 billion for Fiscal 2027 and thereafter.
  (was, 2024-09-10, similarity 0.9463):
[0001571996-24-000090:note_history:1]
The Company has contractual obligations to purchase goods or services, which specify significant terms (including fixed or minimum quantities to be purchased), fixed, minimum, or variable price provisions, and the approximate timing of the transaction. As of August 2, 2024, such purchase obligations were $5.7 billion for Fiscal 2025; $0.5 billion for Fiscal 2026; and $1.0 billion for Fiscal 2027 and thereafter.

- added (2024-12-10):
[0001571996-24-000143:note_history:2]
In accordance with the relevant accounting guidance, the Company provides disclosures of matters where it is at least reasonably possible that the Company could experience a material loss exceeding the amounts already accrued for these or other proceedings or matters. In addition, the Company also discloses matters based on its consideration of other matters and qualitative factors, including the experience of other companies in the industry, and investor, customer, and employee relations considerations. As of November 1, 2024, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for these or other proceedings or matters has been incurred. However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company’s business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters. Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company’s business, financial condition, results of operations, or cash flows will depend on a number of factors, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.

- changed (2024-12-10):
[0001571996-24-000143:note_history:3]
Under the Separation and Distribution Agreement entered into with VMware, Inc. upon completion of the spin-off of VMware, Inc. on November 1, 2021 (the “VMware Spin-off”), Dell Technologies agreed to indemnify VMware, Inc., each of its subsidiaries and each of their respective directors, officers, employees, as well as any successors and assigns of the foregoing, from and against all liabilities relating to, arising out of or resulting from, among other matters, the liabilities allocated to Dell Technologies as part of the separation of Dell Technologies and VMware, Inc. (currently operating under the name “VMware LLC,” and individually and together with its subsidiaries, “VMware”) and their respective businesses (the “Separation”). VMware similarly agreed to indemnify Dell Technologies Inc., each of its subsidiaries and each of their respective directors, officers, and employees from and against all liabilities relating to, arising out of or resulting from, among other matters, the liabilities allocated to VMware as part of the Separation. The amounts that VMware and Dell Technologies may be obligated to pay each other could vary depending on the outcome of certain unresolved tax matters, which may not be resolved for several years. Net income tax indemnification receivables from VMware were immaterial as of November 1, 2024 and February 2, 2024.
  (was, 2024-09-10, similarity 0.9748):
[0001571996-24-000090:note_history:3]
Under the Separation and Distribution Agreement entered into with VMware, Inc. upon completion of the spin-off of VMware, Inc. on November 1, 2021 (the “VMware Spin-off”), Dell Technologies agreed to indemnify VMware, Inc., each of its subsidiaries and each of their respective directors, officers, employees, as well as any successors and assigns of the foregoing, from and against all liabilities relating to, arising out of or resulting from, among other matters, the liabilities allocated to Dell Technologies as part of the separation of Dell Technologies and VMware, Inc. (individually and together with its subsidiaries, “VMware”) and their respective businesses (the “Separation”). VMware similarly agreed to indemnify Dell Technologies Inc., each of its subsidiaries and each of their respective directors, officers, and employees from and against all liabilities relating to, arising out of or resulting from, among other matters, the liabilities allocated to VMware as part of the Separation. The amounts that VMware and Dell Technologies may be obligated to pay each other could vary depending on the outcome of certain unresolved tax matters, which may not be resolved for several years. Net income tax indemnification receivables from VMware were immaterial as of August 2, 2024 and February 2, 2024.

- removed (2024-12-10):
[0001571996-24-000090:note_history:4]
In accordance with the relevant accounting guidance, the Company provides disclosures of matters where it is at least reasonably possible that the Company could experience a material loss exceeding the amounts already accrued for these or other proceedings or matters. In addition, the Company also discloses matters based on its consideration of other matters and qualitative factors, including the experience of other companies in the industry, and investor, customer, and employee relations considerations. As of August 2, 2024, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for these or other proceedings or matters has been incurred. However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company’s business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters. Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company’s business, financial condition, results of operations, or cash flows will depend on a number of factors, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.


## dell:CreditLossFinancialInstrumentLeasesDebtVariableInterestEntitiesAndCustomerReceivablesSalesTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-12-10):
[0001571996-24-000143:note_history:5]
Financing options are offered to the Company’s customers primarily through Dell Financial Services and its affiliates (“DFS”). The Company also arranges financing for some of its customers in various countries where DFS does not currently operate as a captive enterprise. The key activities of DFS include originating, collecting, and servicing customer financing arrangements primarily related to the purchase or use of Dell Technologies products and services. In some cases, DFS also offers financing for the purchase of third-party technology products that complement the Dell Technologies portfolio of products and services. New financing originations were $1.6 billion and $1.8 billion for the three months ended November 1, 2024 and November 3, 2023, respectively, and $5.9 billion and $6.0 billion for the nine months ended November 1, 2024 and November 3, 2023, respectively.
  (was, 2024-09-10, similarity 0.84):
[0001571996-24-000090:note_history:5]
Financing options are offered to the Company’s customers primarily through Dell Financial Services and its affiliates (“DFS”). The Company also arranges financing for some of its customers in various countries where DFS does not currently operate as a captive enterprise. The key activities of DFS include originating, collecting, and servicing customer financing arrangements primarily related to the purchase or use of Dell Technologies products and services. In some cases, DFS also offers financing for the purchase of third-party technology products that complement the Dell Technologies portfolio of products and services. New financing originations were $2.4 billion for both the three months ended August 2, 2024 and August 4, 2023, and $4.3 billion and $4.2 billion for the six months ended August 2, 2024 and August 4, 2023, respectively.

- changed (2024-12-10):
[0001571996-24-000143:note_history:6]
Revolving loans — The Company primarily offers revolving loans to small and medium-sized commercial customers. Revolving loans provide qualified customers with a revolving credit line for the purchase of products and services offered by Dell Technologies. Revolving loans in the United States bear interest at a variable annual percentage rate that is tied to the prime rate. Based on historical payment patterns, revolving loan transactions are typically repaid within twelve months on average. Due to the short-term nature of the revolving loan portfolio, the carrying value of the portfolio approximates fair value.
  (was, 2024-09-10, similarity 0.8495):
[0001571996-24-000090:note_history:6]
Revolving loans — Revolving loans provide qualified customers with a revolving credit line for the purchase of products and services offered by Dell Technologies. The Company primarily offers revolving loans to small and medium-sized commercial customers. Revolving loans in the United States bear interest at a variable annual percentage rate that is tied to the prime rate. Based on historical payment patterns, revolving loan transactions are typically repaid within twelve months on average. Due to the short-term nature of the revolving loan portfolio, the carrying value of the portfolio approximates fair value.

- changed (2024-12-10):
[0001571996-24-000143:note_history:7]
Prior to the sale of the U.S. consumer revolving customer receivables portfolio on October 4, 2023, described in Note 1 of the Notes to the Condensed Consolidated Financial Statements, the Company offered private label credit financing under the Dell Preferred Account (“DPA”) program. The DPA product was primarily offered to individual consumer customers. During the three months ended November 1, 2024, the Company discontinued remaining offerings under the revolving loan portfolio. The Company will support existing customer arrangements as well as transition these customers to fixed-term offerings.
  (was, 2024-09-10, similarity 0.7434):
[0001571996-24-000090:note_history:7]
Prior to the sale of the U.S. consumer revolving customer receivables portfolio on October 4, 2023, described in Note 1 of the Notes to the Condensed Consolidated Financial Statements, the Company offered private label credit financing under the Dell Preferred Account (“DPA”) program. The DPA product was primarily offered to individual consumer customers.

- changed (2024-12-10):
[0001571996-24-000143:note_history:8]
|  | November 1, 2024 |  | February 2, 2024 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Financing receivables, net: |  |  |  |  |  |  |  |  |  |  |  |
| Customer receivables, gross (a) | $ | 126 |  |  | $ | 10,699 |  |  | $ | 10,825 |  |  | $ | 173 |  |  | $ | 10,360 |  |  | $ | 10,533 |  |
| Allowances for losses | (7) |  |  | (137) |  |  | (144) |  |  | (9) |  |  | (161) |  |  | (170) |  |
| Customer receivables, net | 119 |  |  | 10,562 |  |  | 10,681 |  |  | 164 |  |  | 10,199 |  |  | 10,363 |  |
| Residual interest | — |  |  | 169 |  |  | 169 |  |  | — |  |  | 157 |  |  | 157 |  |
| Financing receivables, net | $ | 119 |  |  | $ | 10,731 |  |  | $ | 10,850 |  |  | $ | 164 |  |  | $ | 10,356 |  |  | $ | 10,520 |  |
| Short-term | $ | 119 |  |  | $ | 4,882 |  |  | $ | 5,001 |  |  | $ | 164 |  |  | $ | 4,479 |  |  | $ | 4,643 |  |
| Long-term | $ | — |  |  | $ | 5,849 |  |  | $ | 5,849 |  |  | $ | — |  |  | $ | 5,877 |  |  | $ | 5,877 |  |
  (was, 2024-09-10, similarity 0.9912):
[0001571996-24-000090:note_history:8]
|  | August 2, 2024 |  | February 2, 2024 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Financing receivables, net: |  |  |  |  |  |  |  |  |  |  |  |
| Customer receivables, gross (a) | $ | 154 |  |  | $ | 10,938 |  |  | $ | 11,092 |  |  | $ | 173 |  |  | $ | 10,360 |  |  | $ | 10,533 |  |
| Allowances for losses | (8) |  |  | (158) |  |  | (166) |  |  | (9) |  |  | (161) |  |  | (170) |  |
| Customer receivables, net | 146 |  |  | 10,780 |  |  | 10,926 |  |  | 164 |  |  | 10,199 |  |  | 10,363 |  |
| Residual interest | — |  |  | 166 |  |  | 166 |  |  | — |  |  | 157 |  |  | 157 |  |
| Financing receivables, net | $ | 146 |  |  | $ | 10,946 |  |  | $ | 11,092 |  |  | $ | 164 |  |  | $ | 10,356 |  |  | $ | 10,520 |  |
| Short-term | $ | 146 |  |  | $ | 4,822 |  |  | $ | 4,968 |  |  | $ | 164 |  |  | $ | 4,479 |  |  | $ | 4,643 |  |
| Long-term | $ | — |  |  | $ | 6,124 |  |  | $ | 6,124 |  |  | $ | — |  |  | $ | 5,877 |  |  | $ | 5,877 |  |

- added (2024-12-10):
[0001571996-24-000143:note_history:9]
|  | Three Months Ended |
|  | November 1, 2024 |  | November 3, 2023 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |  |  |  |  |  |  |  |
| Balances at beginning of period | $ | 8 |  |  | $ | 158 |  |  | $ | 166 |  |  | $ | 9 |  |  | $ | 140 |  |  | $ | 149 |  |
| Charge-offs, net of recoveries | (3) |  |  | (35) |  |  | (38) |  |  | (4) |  |  | (3) |  |  | (7) |  |
| Provision charged to income statement | 2 |  |  | 14 |  |  | 16 |  |  | 4 |  |  | 7 |  |  | 11 |  |
| Balances at end of period | $ | 7 |  |  | $ | 137 |  |  | $ | 144 |  |  | $ | 9 |  |  | $ | 144 |  |  | $ | 153 |  |

- added (2024-12-10):
[0001571996-24-000143:note_history:10]
|  | Nine Months Ended |
|  | November 1, 2024 |  | November 3, 2023 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |  |  |  |  |  |  |  |
| Balances at beginning of period | $ | 9 |  |  | $ | 161 |  |  | $ | 170 |  |  | $ | 88 |  |  | $ | 113 |  |  | $ | 201 |  |
| Charge-offs, net of recoveries | (9) |  |  | (56) |  |  | (65) |  |  | (37) |  |  | (5) |  |  | (42) |  |
| Provision charged to income statement | 7 |  |  | 32 |  |  | 39 |  |  | 32 |  |  | 36 |  |  | 68 |  |
| Other (a) | — |  |  | — |  |  | — |  |  | (74) |  |  | — |  |  | (74) |  |
| Balances at end of period | $ | 7 |  |  | $ | 137 |  |  | $ | 144 |  |  | $ | 9 |  |  | $ | 144 |  |  | $ | 153 |  |

- added (2024-12-10):
[0001571996-24-000143:note_history:11]
(a)    Other represents the derecognition of the allowance for financing receivable losses related to the sale of the U.S. consumer revolving customer receivables portfolio described in Note 1 of the Notes to the Condensed Consolidated Financial Statements.

- changed (2024-12-10):
[0001571996-24-000143:note_history:12]
|  | November 1, 2024 |  | February 2, 2024 |
|  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |
|  | (in millions) |
| Revolving | $ | 107 |  |  | $ | 15 |  |  | $ | 4 |  |  | $ | 126 |  |  | $ | 151 |  |  | $ | 17 |  |  | $ | 5 |  |  | $ | 173 |  |
| Fixed-term | 10,053 |  |  | 488 |  |  | 158 |  |  | 10,699 |  |  | 9,345 |  |  | 889 |  |  | 126 |  |  | 10,360 |  |
| Total customer receivables, gross | $ | 10,160 |  |  | $ | 503 |  |  | $ | 162 |  |  | $ | 10,825 |  |  | $ | 9,496 |  |  | $ | 906 |  |  | $ | 131 |  |  | $ | 10,533 |  |
  (was, 2024-09-10, similarity 0.9861):
[0001571996-24-000090:note_history:12]
|  | August 2, 2024 |  | February 2, 2024 |
|  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |
|  | (in millions) |
| Revolving | $ | 135 |  |  | $ | 15 |  |  | $ | 4 |  |  | $ | 154 |  |  | $ | 151 |  |  | $ | 17 |  |  | $ | 5 |  |  | $ | 173 |  |
| Fixed-term | 10,034 |  |  | 815 |  |  | 89 |  |  | 10,938 |  |  | 9,345 |  |  | 889 |  |  | 126 |  |  | 10,360 |  |
| Total customer receivables, gross | $ | 10,169 |  |  | $ | 830 |  |  | $ | 93 |  |  | $ | 11,092 |  |  | $ | 9,496 |  |  | $ | 906 |  |  | $ | 131 |  |  | $ | 10,533 |  |

- changed (2024-12-10):
[0001571996-24-000143:note_history:13]
|  | November 1, 2024 |
|  | Fixed-term — Fiscal Year of Origination |  |  |  |  |
|  | 2025 |  | 2024 |  | 2023 |  | 2022 |  | 2021 |  | Years Prior |  | Revolving |  | Total |
|  | (in millions) |
| Higher | $ | 1,555 |  |  | $ | 2,440 |  |  | $ | 1,560 |  |  | $ | 515 |  |  | $ | 158 |  |  | $ | 14 |  |  | $ | 25 |  |  | $ | 6,267 |  |
| Mid | 733 |  |  | 710 |  |  | 432 |  |  | 122 |  |  | 22 |  |  | 5 |  |  | 37 |  |  | 2,061 |  |
| Lower | 1,505 |  |  | 465 |  |  | 314 |  |  | 88 |  |  | 58 |  |  | 3 |  |  | 64 |  |  | 2,497 |  |
| Total | $ | 3,793 |  |  | $ | 3,615 |  |  | $ | 2,306 |  |  | $ | 725 |  |  | $ | 238 |  |  | $ | 22 |  |  | $ | 126 |  |  | $ | 10,825 |  |
  (was, 2024-09-10, similarity 0.9864):
[0001571996-24-000090:note_history:13]
|  | August 2, 2024 |
|  | Fixed-term — Fiscal Year of Origination |  |  |  |  |
|  | 2025 |  | 2024 |  | 2023 |  | 2022 |  | 2021 |  | Years Prior |  | Revolving |  | Total |
|  | (in millions) |
| Higher | $ | 1,377 |  |  | $ | 2,626 |  |  | $ | 1,519 |  |  | $ | 563 |  |  | $ | 211 |  |  | $ | 14 |  |  | $ | 36 |  |  | $ | 6,346 |  |
| Mid | 476 |  |  | 940 |  |  | 695 |  |  | 152 |  |  | 35 |  |  | 8 |  |  | 46 |  |  | 2,352 |  |
| Lower | 1,262 |  |  | 530 |  |  | 353 |  |  | 118 |  |  | 48 |  |  | 11 |  |  | 72 |  |  | 2,394 |  |
| Total | $ | 3,115 |  |  | $ | 4,096 |  |  | $ | 2,567 |  |  | $ | 833 |  |  | $ | 294 |  |  | $ | 33 |  |  | $ | 154 |  |  | $ | 11,092 |  |

- changed (2024-12-10):
[0001571996-24-000143:note_history:14]
An internal grading system is utilized that assigns a credit level score based on a number of considerations, including liquidity, operating performance, and industry outlook. The grading criteria and classifications for the fixed-term products differ from those for the revolving products as loss experience varies between these product and customer groups. The credit quality categories cannot be compared between the different classes as loss experience varies substantially between the classes.
  (was, 2024-09-10, similarity 0.9222):
[0001571996-24-000090:note_history:14]
For the revolving receivables and fixed-term receivables shown in the tables above, an internal grading system is utilized that assigns a credit level score based on a number of considerations, including liquidity, operating performance, and industry outlook. The grading criteria and classifications for the fixed-term products differ from those for the revolving products as loss experience varies between these product and customer groups. The credit quality categories cannot be compared between the different classes as loss experience varies substantially between the classes.

- changed (2024-12-10):
[0001571996-24-000143:note_history:15]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 1, 2024 |  | November 3, 2023 |  | November 1, 2024 |  | November 3, 2023 |  |  |
|  | (in millions) |
| Net revenue — products | $ | 401 |  |  | $ | 227 |  |  | $ | 1,751 |  |  | $ | 766 |  |  |  |
| Cost of net revenue — products | 333 |  |  | 176 |  |  | 1,488 |  |  | 564 |  |  |  |
| Gross margin — products | $ | 68 |  |  | $ | 51 |  |  | $ | 263 |  |  | $ | 202 |  |  |  |
  (was, 2024-09-10, similarity 0.8373):
[0001571996-24-000090:note_history:15]
|  | Three Months Ended |  | Six Months Ended |
|  | August 2, 2024 |  | August 4, 2023 |  | August 2, 2024 |  | August 4, 2023 |  |  |
|  | (in millions) |
| Net revenue — products | $ | 622 |  |  | $ | 292 |  |  | $ | 1,350 |  |  | $ | 539 |  |  |  |
| Cost of net revenue — products | 537 |  |  | 192 |  |  | 1,155 |  |  | 388 |  |  |  |
| Gross margin — products | $ | 85 |  |  | $ | 100 |  |  | $ | 195 |  |  | $ | 151 |  |  |  |

- changed (2024-12-10):
[0001571996-24-000143:note_history:16]
|  | November 1, 2024 |
|  | (in millions) |
| Fiscal 2025 (remaining three months) | $ | 871 |  |
| Fiscal 2026 | 3,114 |  |
| Fiscal 2027 | 2,085 |  |
| Fiscal 2028 | 793 |  |
| Fiscal 2029 and beyond | 454 |  |
| Total undiscounted cash flows | 7,317 |  |
| Fixed-term loans | 4,466 |  |
| Revolving loans | 126 |  |
| Less: Unearned income | (1,084) |  |
| Total customer receivables, gross | $ | 10,825 |  |
  (was, 2024-09-10, similarity 0.6704):
[0001571996-24-000090:note_history:16]
|  | August 2, 2024 |
|  | (in millions) |
| Fiscal 2025 (remaining six months) | $ | 582 |  |
| Fiscal 2026 | 897 |  |
| Fiscal 2027 | 517 |  |
| Fiscal 2028 | 208 |  |
| Fiscal 2029 and beyond | 77 |  |
| Total | $ | 2,281 |  |

- changed (2024-12-10):
[0001571996-24-000143:note_history:17]
|  | November 1, 2024 |  | February 2, 2024 |
|  | (in millions) |
| Equipment under operating lease, gross | $ | 4,188 |  |  | $ | 4,002 |  |
| Less: Accumulated depreciation | (1,971) |  |  | (1,800) |  |
| Equipment under operating lease, net | $ | 2,217 |  |  | $ | 2,202 |  |
  (was, 2024-09-10, similarity 0.9702):
[0001571996-24-000090:note_history:17]
|  | August 2, 2024 |  | February 2, 2024 |
|  | (in millions) |
| Equipment under operating lease, gross | $ | 4,064 |  |  | $ | 4,002 |  |
| Less: Accumulated depreciation | (1,871) |  |  | (1,800) |  |
| Equipment under operating lease, net | $ | 2,193 |  |  | $ | 2,202 |  |

- changed (2024-12-10):
[0001571996-24-000143:note_history:18]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 1, 2024 |  | November 3, 2023 |  | November 1, 2024 |  | November 3, 2023 |  |  |
|  | (in millions) |
| Income related to lease payments | $ | 372 |  |  | $ | 341 |  |  | $ | 1,090 |  |  | $ | 992 |  |  |  |
| Depreciation expense | $ | 247 |  |  | $ | 234 |  |  | $ | 732 |  |  | $ | 703 |  |  |  |
  (was, 2024-09-10, similarity 0.8034):
[0001571996-24-000090:note_history:18]
|  | Three Months Ended |  | Six Months Ended |
|  | August 2, 2024 |  | August 4, 2023 |  | August 2, 2024 |  | August 4, 2023 |  |  |
|  | (in millions) |
| Income related to lease payments | $ | 362 |  |  | $ | 330 |  |  | $ | 718 |  |  | $ | 651 |  |  |  |
| Depreciation expense | $ | 245 |  |  | $ | 236 |  |  | $ | 485 |  |  | $ | 469 |  |  |  |

- added (2024-12-10):
[0001571996-24-000143:note_history:19]
|  | November 1, 2024 |
|  | (in millions) |
| Fiscal 2025 (remaining three months) | $ | 347 |  |
| Fiscal 2026 | 1,079 |  |
| Fiscal 2027 | 665 |  |
| Fiscal 2028 | 316 |  |
| Fiscal 2029 and beyond | 121 |  |
| Total | $ | 2,528 |  |

- changed (2024-12-10):
[0001571996-24-000143:note_history:20]
The Company maintains programs that facilitate the funding of leases, loans, and other alternative payment structures in the capital markets. The majority of DFS debt is non-recourse to Dell Technologies and represents borrowings under securitization programs and structured financing programs for which the Company’s risk of loss is limited to transferred lease and loan payments and associated equipment.
  (was, 2024-09-10, similarity 0.968):
[0001571996-24-000090:note_history:20]
The Company maintains programs that facilitate the funding of leases, loans, and other alternative payment structures in the capital markets. The majority of DFS debt is non-recourse to Dell Technologies and represents borrowings under securitization programs and structured financing programs for which the Company’s risk of loss is limited to transferred loan and lease payments and associated equipment.

- changed (2024-12-10):
[0001571996-24-000143:note_history:21]
|  | November 1, 2024 |  | February 2, 2024 |
| DFS debt | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing facility | $ | 2,753 |  |  | $ | 2,730 |  |
| Fixed-term securitization offerings | 3,264 |  |  | 3,157 |  |
| Other | — |  |  | 28 |  |
| Total DFS U.S. debt, principal amount | 6,017 |  |  | 5,915 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 723 |  |  | 761 |  |
| Other borrowings | 798 |  |  | 935 |  |
| Note payable | — |  |  | 250 |  |
| Dell Bank senior unsecured eurobonds | 1,633 |  |  | 1,631 |  |
| Total DFS international debt, principal amount | 3,154 |  |  | 3,577 |  |
| Total DFS debt, principal amount | $ | 9,171 |  |  | $ | 9,492 |  |
| Total short-term DFS debt | $ | 5,582 |  |  | $ | 5,863 |  |
| Total long-term DFS debt | $ | 3,589 |  |  | $ | 3,629 |  |
  (was, 2024-09-10, similarity 0.7553):
[0001571996-24-000090:note_history:21]
|  | August 2, 2024 |  | February 2, 2024 |
| DFS debt | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing facility | $ | 3,067 |  |  | $ | 2,730 |  |
| Fixed-term securitization offerings | 2,841 |  |  | 3,157 |  |
| Other | 25 |  |  | 28 |  |
| Total DFS U.S. debt, principal amount | 5,933 |  |  | 5,915 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 704 |  |  | 761 |  |
| Other borrowings | 877 |  |  | 935 |  |
| Note payable | — |  |  | 250 |  |
| Dell Bank senior unsecured eurobonds | 1,619 |  |  | 1,631 |  |
| Total DFS international debt, principal amount | 3,200 |  |  | 3,577 |  |
| Total DFS debt, principal amount | $ | 9,133 |  |  | $ | 9,492 |  |
| Total short-term DFS debt | $ | 5,682 |  |  | $ | 5,863 |  |
| Total long-term DFS debt | $ | 3,451 |  |  | $ | 3,629 |  |

- changed (2024-12-10):
[0001571996-24-000143:note_history:22]
Asset-Based Financing Facility — The Company maintains an asset-based financing facility in the United States, which is a revolving facility for fixed-term leases and loans. This debt is collateralized solely by the U.S. lease and loan payments and associated equipment in the facility. The asset-based financing facility consists of two tranches, with effective dates through July 7, 2025 and July 7, 2026, respectively. As of November 1, 2024, the total debt capacity related to the asset-based financing facility was $5.0 billion. The debt has a variable interest rate, and the duration of the debt is based on the terms of the underlying lease and loan payment streams. The Company enters into interest rate swap agreements to economically convert a portion of this debt from a floating rate to a fixed rate. See Note 7 of the Notes to the Condensed Consolidated Financial Statements for additional information about the Company’s interest rate swaps.
  (was, 2024-09-10, similarity 0.9321):
[0001571996-24-000090:note_history:22]
Asset-Based Financing Facility — The Company maintains an asset-based financing facility in the United States, which is a revolving facility for fixed-term leases and loans. This debt is collateralized solely by the U.S. loan and lease payments and associated equipment in the facility. The asset-based financing facility consists of two tranches, with effective dates through July 7, 2025 and July 7, 2026. As of August 2, 2024, the total debt capacity related to the asset-based financing facility was $5.0 billion. The debt has a variable interest rate, and the duration of the debt is based on the terms of the underlying loan and lease payment streams. The Company enters into interest swap agreements to effectively convert a portion of this debt from a floating rate to a fixed rate. See Note 7 of the Notes to the Condensed Consolidated Financial Statements for additional information about the Company’s interest rate swaps.

- changed (2024-12-10):
[0001571996-24-000143:note_history:23]
The asset-based financing facility contains standard structural features related to the performance of the funded receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements. In the event one or more of these criteria are not met and the Company is unable to restructure the facility, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed. As of November 1, 2024, these criteria were met.
  (was, 2024-09-10, similarity 0.987):
[0001571996-24-000090:note_history:23]
The asset-based financing facility contains standard structural features related to the performance of the funded receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements. In the event one or more of these criteria are not met and the Company is unable to restructure the facility, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed. As of August 2, 2024, these criteria were met.

- changed (2024-12-10):
[0001571996-24-000143:note_history:24]
Fixed-Term Securitization Offerings — The Company periodically issues asset-backed debt securities under fixed-term securitization programs to private investors. The asset-backed debt securities are collateralized solely by the U.S. fixed-term lease and loan payments and associated equipment, which are held by Special Purpose Entities (“SPEs”), as discussed below. The interest rate on these securities is fixed and ranges from 4.14% to 6.80% per annum as of November 1, 2024, and the duration of these securities is based on the terms of the underlying lease and loan payment streams.
  (was, 2024-09-10, similarity 0.9878):
[0001571996-24-000090:note_history:24]
Fixed-Term Securitization Offerings — The Company periodically issues asset-backed debt securities under fixed-term securitization programs to private investors. The asset-backed debt securities are collateralized solely by the U.S. fixed-term lease and loan payments and associated equipment, which are held by Special Purpose Entities (“SPEs”), as discussed below. The interest rate on these securities is fixed and ranges from 2.49% to 6.80% per annum as of August 2, 2024, and the duration of these securities is based on the terms of the underlying lease and loan payment streams.

- changed (2024-12-10):
[0001571996-24-000143:note_history:25]
Securitization Facility — The Company maintains a securitization facility in Europe for fixed-term leases and loans. The debt under this facility has a variable interest rate, and the duration of the debt is based on the terms of the underlying lease and loan payment streams. This facility is effective through December 23, 2024 and had a total debt capacity of $871 million as of November 1, 2024.
  (was, 2024-09-10, similarity 0.9378):
[0001571996-24-000090:note_history:25]
Securitization Facility — The Company maintains a securitization facility in Europe for fixed-term leases and loans. The debt under this facility has a variable interest rate, and the duration of the debt is based on the terms of the underlying loan and lease payment streams. This facility is effective through December 23, 2024 and had a total debt capacity of $863 million as of August 2, 2024.

- changed (2024-12-10):
[0001571996-24-000143:note_history:26]
The securitization facility contains standard structural features related to the performance of the securitized receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements. In the event one or more of these criteria are not met and the Company is unable to restructure the program, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed. As of November 1, 2024, these criteria were met.
  (was, 2024-09-10, similarity 0.987):
[0001571996-24-000090:note_history:26]
The securitization facility contains standard structural features related to the performance of the securitized receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements. In the event one or more of these criteria are not met and the Company is unable to restructure the program, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed. As of August 2, 2024, these criteria were met.

- added (2024-12-10):
[0001571996-24-000143:note_history:27]
The duration of the debt in Canada, Europe, Australia, New Zealand, and the Middle East is based on the terms of the underlying lease and loan payment streams. These facilities are collateralized solely by the lease and loan payments and associated equipment in their respective region or country. The Canadian facility had a total debt capacity of $323 million as of November 1, 2024 and is effective through January 16, 2025. The European facility had a total debt capacity of $544 million as of November 1, 2024 and is effective through December 14, 2026. The Australia and New Zealand facility had a total debt capacity of $296 million as of November 1, 2024 and is effective through April 20, 2025. The Middle East facility had a total debt capacity of $150 million as of November 1, 2024 and is effective through March 24, 2025.

- added (2024-12-10):
[0001571996-24-000143:note_history:28]
The Company also has two unsecured Singapore facilities with a total debt capacity of $250 million as of November 1, 2024 that are effective through July 3, 2026 and July 3, 2027, respectively.

- changed (2024-12-10):
[0001571996-24-000143:note_history:29]
In connection with the asset-based financing facility, securitization facility, and fixed-term securitization offerings discussed above, the Company transfers certain U.S. and European lease and loan payments and associated equipment to SPEs that meet the definition of a VIE and are consolidated, along with the associated debt described above, into the Condensed Consolidated Financial Statements, as the Company is the primary beneficiary of the VIEs. The SPEs are bankruptcy-remote legal entities with separate assets and liabilities. The purpose of the SPEs is to facilitate the funding of customer lease and loan payments and associated equipment in the capital markets.
  (was, 2024-09-10, similarity 0.9808):
[0001571996-24-000090:note_history:29]
In connection with the asset-based financing facility, securitization facility, and fixed-term securitization offerings discussed above, the Company transfers certain U.S. and European lease and loan payments and associated equipment to SPEs that meet the definition of a VIE and are consolidated, along with the associated debt described above, into the Condensed Consolidated Financial Statements, as the Company is the primary beneficiary of the VIEs. The SPEs are bankruptcy-remote legal entities with separate assets and liabilities. The purpose of the SPEs is to facilitate the funding of customer loan and lease payments and associated equipment in the capital markets.

- changed (2024-12-10):
[0001571996-24-000143:note_history:30]
|  | November 1, 2024 |  | February 2, 2024 |
|  | (in millions) |
| Assets held by consolidated VIEs |  |  |  |
| Other current assets | $ | 123 |  |  | $ | 136 |  |
| Financing receivables, net of allowance |  |  |  |
| Short-term | $ | 3,354 |  |  | $ | 3,314 |  |
| Long-term | $ | 2,989 |  |  | $ | 2,747 |  |
| Property, plant, and equipment, net | $ | 1,022 |  |  | $ | 1,081 |  |
| Liabilities held by consolidated VIEs |  |  |  |
| Debt, net of unamortized debt issuance costs |  |  |  |
| Short-term | $ | 4,888 |  |  | $ | 4,450 |  |
| Long-term | $ | 1,838 |  |  | $ | 2,184 |  |
  (was, 2024-09-10, similarity 0.9861):
[0001571996-24-000090:note_history:30]
|  | August 2, 2024 |  | February 2, 2024 |
|  | (in millions) |
| Assets held by consolidated VIEs |  |  |  |
| Other current assets | $ | 115 |  |  | $ | 136 |  |
| Financing receivables, net of allowance |  |  |  |
| Short-term | $ | 3,284 |  |  | $ | 3,314 |  |
| Long-term | $ | 2,935 |  |  | $ | 2,747 |  |
| Property, plant, and equipment, net | $ | 1,022 |  |  | $ | 1,081 |  |
| Liabilities held by consolidated VIEs |  |  |  |
| Debt, net of unamortized debt issuance costs |  |  |  |
| Short-term | $ | 4,942 |  |  | $ | 4,450 |  |
| Long-term | $ | 1,670 |  |  | $ | 2,184 |  |

- changed (2024-12-10):
[0001571996-24-000143:note_history:31]
Lease and loan payments and associated equipment transferred via securitization through SPEs were $1.0 billion and $1.1 billion for the three months ended November 1, 2024 and November 3, 2023, respectively, and $3.0 billion and $3.7 billion for the nine months ended November 1, 2024 and November 3, 2023, respectively.
  (was, 2024-09-10, similarity 0.7807):
[0001571996-24-000090:note_history:31]
Lease and loan payments and associated equipment transferred via securitization through SPEs were $1.2 billion and $1.1 billion for the three months ended August 2, 2024 and August 4, 2023, respectively, and $2.0 billion and $2.6 billion for the six months ended August 2, 2024 and August 4, 2023, respectively.

- changed (2024-12-10):
[0001571996-24-000143:note_history:32]
To manage certain concentrations of customer credit exposure, the Company may sell selected fixed-term customer receivables to unrelated third parties on a periodic basis, without recourse. The amount of customer receivables sold for this purpose was $75 million and $205 million for the nine months ended November 1, 2024 and November 3, 2023, respectively. The Company’s continuing involvement in these customer receivables is primarily limited to servicing arrangements.
  (was, 2024-09-10, similarity 0.9117):
[0001571996-24-000090:note_history:32]
To manage certain concentrations of customer credit exposure, the Company may sell selected fixed-term customer receivables to unrelated third parties on a periodic basis, without recourse. The amount of customer receivables sold for this purpose was $69 million and $187 million for the six months ended August 2, 2024 and August 4, 2023, respectively. The Company’s continuing involvement in these customer receivables is primarily limited to servicing arrangements.

- removed (2024-12-10):
[0001571996-24-000090:note_history:33]
|  | Three Months Ended |
|  | August 2, 2024 |  | August 4, 2023 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |  |  |  |  |  |  |  |
| Balances at beginning of period | $ | 8 |  |  | $ | 187 |  |  | $ | 195 |  |  | $ | 84 |  |  | $ | 135 |  |  | $ | 219 |  |
| Charge-offs, net of recoveries | (4) |  |  | (15) |  |  | (19) |  |  | (16) |  |  | (1) |  |  | (17) |  |
| Provision charged to income statement | 4 |  |  | (14) |  |  | (10) |  |  | 15 |  |  | 6 |  |  | 21 |  |
| Held for sale adjustment (a) | — |  |  | — |  |  | — |  |  | (74) |  |  | — |  |  | (74) |  |
| Balances at end of period | $ | 8 |  |  | $ | 158 |  |  | $ | 166 |  |  | $ | 9 |  |  | $ | 140 |  |  | $ | 149 |  |

- removed (2024-12-10):
[0001571996-24-000090:note_history:34]
|  | Six Months Ended |
|  | August 2, 2024 |  | August 4, 2023 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |  |  |  |  |  |  |  |
| Balances at beginning of period | $ | 9 |  |  | $ | 161 |  |  | $ | 170 |  |  | $ | 88 |  |  | $ | 113 |  |  | $ | 201 |  |
| Charge-offs, net of recoveries | (6) |  |  | (21) |  |  | (27) |  |  | (33) |  |  | (2) |  |  | (35) |  |
| Provision charged to income statement | 5 |  |  | 18 |  |  | 23 |  |  | 28 |  |  | 29 |  |  | 57 |  |
| Held for sale adjustment (a) | — |  |  | — |  |  | — |  |  | (74) |  |  | — |  |  | (74) |  |
| Balances at end of period | $ | 8 |  |  | $ | 158 |  |  | $ | 166 |  |  | $ | 9 |  |  | $ | 140 |  |  | $ | 149 |  |

- removed (2024-12-10):
[0001571996-24-000090:note_history:35]
(a)    The held for sale adjustment represents the reclassification of the U.S. consumer revolving customer receivables portfolio to current assets held for sale as of August 4, 2023. See Note 1 of the Notes to the Condensed Consolidated Financial Statements for more information about the sale of the U.S. consumer revolving customer receivables portfolio.

- removed (2024-12-10):
[0001571996-24-000090:note_history:36]
|  | August 2, 2024 |
|  | (in millions) |
| Fiscal 2025 (remaining six months) | $ | 1,569 |  |
| Fiscal 2026 | 2,841 |  |
| Fiscal 2027 | 1,853 |  |
| Fiscal 2028 | 654 |  |
| Fiscal 2029 and beyond | 347 |  |
| Total undiscounted cash flows | 7,264 |  |
| Fixed-term loans | 4,810 |  |
| Revolving loans | 154 |  |
| Less: Unearned income | (1,136) |  |
| Total customer receivables, gross | $ | 11,092 |  |

- removed (2024-12-10):
[0001571996-24-000090:note_history:37]
The duration of the debt in Canada, Europe, Australia, New Zealand, and the Middle East is based on the terms of the underlying loan and lease payment streams. These facilities are collateralized solely by the loan and lease payments and associated equipment in their respective region or country. The Canadian facility had a total debt capacity of $324 million as of August 2, 2024 and is effective through January 16, 2025. The European facility had a total debt capacity of $540 million as of August 2, 2024 and is effective through December 14, 2026. The Australia and New Zealand facility had a total debt capacity of $293 million as of August 2, 2024 and is effective through April 20, 2025. The Middle East facility had a total debt capacity of $150 million as of August 2, 2024 and is effective through March 24, 2025.

- removed (2024-12-10):
[0001571996-24-000090:note_history:38]
On July 3, 2024, the Company entered into two unsecured revolving credit agreements to fund receivables in Singapore. The Singapore facilities have a total debt capacity of $247 million as of August 2, 2024 and are effective through July 3, 2026 and July 3, 2027, respectively.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-12-10):
[0001571996-24-000143:note_history:39]
|  | November 1, 2024 |  | February 2, 2024 |
|  | (in millions) |
| Senior Notes | $ | 15,073 |  |  | $ | 15,607 |  |
| Legacy Notes | 952 |  |  | 952 |  |
| DFS Debt (Note 4) | 9,171 |  |  | 9,492 |  |
| Other | 56 |  |  | 171 |  |
| Total debt, principal amount | 25,252 |  |  | 26,222 |  |
| Unamortized discount, net of unamortized premium | (113) |  |  | (114) |  |
| Debt issuance costs | (117) |  |  | (114) |  |
| Total debt, carrying value | $ | 25,022 |  |  | $ | 25,994 |  |
| Total short-term debt, carrying value | $ | 5,612 |  |  | $ | 6,982 |  |
| Total long-term debt, carrying value | $ | 19,410 |  |  | $ | 19,012 |  |
  (was, 2024-09-10, similarity 0.9866):
[0001571996-24-000090:note_history:39]
|  | August 2, 2024 |  | February 2, 2024 |
|  | (in millions) |
| Senior Notes | $ | 14,580 |  |  | $ | 15,607 |  |
| Legacy Notes | 952 |  |  | 952 |  |
| DFS Debt (Note 4) | 9,133 |  |  | 9,492 |  |
| Other | 79 |  |  | 171 |  |
| Total debt, principal amount | 24,744 |  |  | 26,222 |  |
| Unamortized discount, net of unamortized premium | (112) |  |  | (114) |  |
| Debt issuance costs | (110) |  |  | (114) |  |
| Total debt, carrying value | $ | 24,522 |  |  | $ | 25,994 |  |
| Total short-term debt, carrying value | $ | 6,711 |  |  | $ | 6,982 |  |
| Total long-term debt, carrying value | $ | 17,811 |  |  | $ | 19,012 |  |

- changed (2024-12-10):
[0001571996-24-000143:note_history:40]
The Company completed the following transactions during the nine months ended November 1, 2024:
  (was, 2024-09-10, similarity 0.8939):
[0001571996-24-000090:note_history:40]
The Company completed the following transactions during the six months ended August 2, 2024:

- changed (2024-12-10):
[0001571996-24-000143:note_history:41]
•the issuance of $1 billion principal amount of 5.40% Senior Notes due April 2034, the proceeds of which were utilized to prepay a portion of the outstanding 6.02% Senior Notes due June 2026;
  (was, 2024-09-10, similarity 0.9889):
[0001571996-24-000090:note_history:41]
•the issuance of $1 billion principal amount of 5.40% Senior Notes due April 2034, the proceeds of which were utilized to prepay a portion of the outstanding 6.02% Senior Notes due June 2026; and

- changed (2024-12-10):
[0001571996-24-000143:note_history:42]
•the repayment of $1 billion principal amount of the 4.00% Senior Notes due July 2024; and
  (was, 2024-09-10, similarity 0.9693):
[0001571996-24-000090:note_history:42]
•the repayment of $1 billion principal amount of the 4.00% Senior Notes due July 2024.

- added (2024-12-10):
[0001571996-24-000143:note_history:43]
•the issuance of $0.7 billion principal amount of 4.35% Senior Notes due February 2030 and $0.8 billion principal amount of 4.85% Senior Notes due February 2035, the proceeds of which were utilized to redeem the 5.85% Senior Notes due July 2025.

- changed (2024-12-10):
[0001571996-24-000143:note_history:44]
Senior Notes — The Company completed offerings of multiple series of senior notes which were issued on June 1, 2016, June 22, 2016, March 20, 2019, April 9, 2020, December 13, 2021, January 24, 2023, March 18, 2024, and October 8, 2024 in aggregate principal amounts of $20.0 billion, $3.3 billion, $4.5 billion, $2.3 billion, $2.3 billion, $2.0 billion, $1.0 billion, and $1.5 billion, respectively (collectively, the “Senior Notes”). The Senior Notes maturities range from 2026 through 2051. Interest rates on these borrowings are fixed, ranging from 3.38% to 8.35%, and interest is payable semiannually.
  (was, 2024-09-10, similarity 0.7488):
[0001571996-24-000090:note_history:44]
Senior Notes — The Company completed offerings of multiple series of senior notes which were issued on June 1, 2016, June 22, 2016, March 20, 2019, April 9, 2020, December 13, 2021, January 24, 2023 and March 18, 2024 in aggregate principal amounts of $20.0 billion, $3.3 billion, $4.5 billion, $2.3 billion, $2.3 billion, $2.0 billion and $1.0 billion, respectively (collectively, the “Senior Notes”). The Senior Notes maturities range from 2025 through 2051. Interest rates on these borrowings are fixed, ranging from 3.38% to 8.35%, and interest is payable semiannually.

- changed (2024-12-10):
[0001571996-24-000143:note_history:45]
As of November 1, 2024, the Company had no outstanding borrowings under the revolving credit facility.
  (was, 2024-09-10, similarity 0.9271):
[0001571996-24-000090:note_history:45]
As of August 2, 2024, the Company had no outstanding borrowings under the revolving credit facility.

- changed (2024-12-10):
[0001571996-24-000143:note_history:46]
Commercial Paper Program — The Company maintains a commercial paper program under which the Company may issue unsecured notes in a maximum aggregate face amount of $5.0 billion outstanding at any time, with maturities up to 397 days from the date of issuance. The notes are sold on customary terms in the U.S. commercial paper market on a private placement basis. The proceeds of the notes are used for general corporate purposes. As of November 1, 2024, the Company had no outstanding issuances under the commercial paper program.
  (was, 2024-09-10, similarity 0.9866):
[0001571996-24-000090:note_history:46]
Commercial Paper Program — The Company maintains a commercial paper program under which the Company may issue unsecured notes in a maximum aggregate face amount of $5.0 billion outstanding at any time, with maturities up to 397 days from the date of issuance. The notes are sold on customary terms in the U.S. commercial paper market on a private placement basis. The proceeds of the notes are used for general corporate purposes. As of August 2, 2024, the Company had no outstanding issuances under the commercial paper program.

- changed (2024-12-10):
[0001571996-24-000143:note_history:47]
Covenants — The credit agreement governing the revolving credit facility and the indentures governing the Senior Notes and the Legacy Notes impose various limitations, subject to exceptions, on creating certain liens and entering into sale and lease-back transactions. The foregoing credit agreement and indentures contain customary events of default, and the revolving credit facility is subject to an interest coverage ratio covenant that is tested at the end of each fiscal quarter with respect to the Company’s preceding four fiscal quarters. The Company was in compliance with this financial covenant as of November 1, 2024.
  (was, 2024-09-10, similarity 0.9888):
[0001571996-24-000090:note_history:47]
Covenants — The credit agreement governing the revolving credit facility and the indentures governing the Senior Notes and the Legacy Notes impose various limitations, subject to exceptions, on creating certain liens and entering into sale and lease-back transactions. The foregoing credit agreement and indentures contain customary events of default, and the revolving credit facility is subject to an interest coverage ratio covenant that is tested at the end of each fiscal quarter with respect to the Company’s preceding four fiscal quarters. The Company was in compliance with this financial covenant as of August 2, 2024.

- changed (2024-12-10):
[0001571996-24-000143:note_history:48]
The following table presents the aggregate future maturities of the Company’s debt as of November 1, 2024, excluding associated carrying value adjustments, for the periods indicated:
  (was, 2024-09-10, similarity 0.9602):
[0001571996-24-000090:note_history:48]
The following table presents the aggregate future maturities of the Company’s debt as of August 2, 2024, excluding associated carrying value adjustments, for the periods indicated:

- added (2024-12-10):
[0001571996-24-000143:note_history:49]
|  | November 1, 2024 |
|  | (in millions) |
| Fiscal 2025 (remaining three months) | $ | 2,023 |  |
| Fiscal 2026 | 3,996 |  |
| Fiscal 2027 | 6,020 |  |
| Fiscal 2028 | 1,308 |  |
| Fiscal 2029 | 1,372 |  |
| Thereafter | 10,533 |  |
| Total maturities, principal amount | $ | 25,252 |  |

- removed (2024-12-10):
[0001571996-24-000090:note_history:50]
|  | August 2, 2024 |
|  | (in millions) |
| Fiscal 2025 (remaining six months) | $ | 2,796 |  |
| Fiscal 2026 | 4,567 |  |
| Fiscal 2027 | 5,838 |  |
| Fiscal 2028 | 1,195 |  |
| Fiscal 2029 | 1,326 |  |
| Thereafter | 9,022 |  |
| Total maturities, principal amount | $ | 24,744 |  |


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-12-10):
[0001571996-24-000143:note_history:51]
|  | November 1, 2024 |  | February 2, 2024 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Notes | $ | 15.0 |  |  | $ | 15.1 |  |  | $ | 15.5 |  |  | $ | 15.8 |  |
| Legacy Notes | $ | 0.9 |  |  | $ | 1.0 |  |  | $ | 0.9 |  |  | $ | 1.0 |  |
| DFS Debt | $ | 9.2 |  |  | $ | 8.9 |  |  | $ | 9.5 |  |  | $ | 9.1 |  |
  (was, 2024-09-10, similarity 0.9773):
[0001571996-24-000090:note_history:51]
|  | August 2, 2024 |  | February 2, 2024 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Notes | $ | 14.5 |  |  | $ | 14.9 |  |  | $ | 15.5 |  |  | $ | 15.8 |  |
| Legacy Notes | $ | 0.9 |  |  | $ | 1.0 |  |  | $ | 0.9 |  |  | $ | 1.0 |  |
| DFS Debt | $ | 9.1 |  |  | $ | 8.8 |  |  | $ | 9.5 |  |  | $ | 9.1 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-12-10):
[0001571996-24-000143:note_history:52]
|  | November 1, 2024 |  | February 2, 2024 |
| DFS debt | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing facility | $ | 2,753 |  |  | $ | 2,730 |  |
| Fixed-term securitization offerings | 3,264 |  |  | 3,157 |  |
| Other | — |  |  | 28 |  |
| Total DFS U.S. debt, principal amount | 6,017 |  |  | 5,915 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 723 |  |  | 761 |  |
| Other borrowings | 798 |  |  | 935 |  |
| Note payable | — |  |  | 250 |  |
| Dell Bank senior unsecured eurobonds | 1,633 |  |  | 1,631 |  |
| Total DFS international debt, principal amount | 3,154 |  |  | 3,577 |  |
| Total DFS debt, principal amount | $ | 9,171 |  |  | $ | 9,492 |  |
| Total short-term DFS debt | $ | 5,582 |  |  | $ | 5,863 |  |
| Total long-term DFS debt | $ | 3,589 |  |  | $ | 3,629 |  |
  (was, 2024-09-10, similarity 0.7553):
[0001571996-24-000090:note_history:52]
|  | August 2, 2024 |  | February 2, 2024 |
| DFS debt | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing facility | $ | 3,067 |  |  | $ | 2,730 |  |
| Fixed-term securitization offerings | 2,841 |  |  | 3,157 |  |
| Other | 25 |  |  | 28 |  |
| Total DFS U.S. debt, principal amount | 5,933 |  |  | 5,915 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 704 |  |  | 761 |  |
| Other borrowings | 877 |  |  | 935 |  |
| Note payable | — |  |  | 250 |  |
| Dell Bank senior unsecured eurobonds | 1,619 |  |  | 1,631 |  |
| Total DFS international debt, principal amount | 3,200 |  |  | 3,577 |  |
| Total DFS debt, principal amount | $ | 9,133 |  |  | $ | 9,492 |  |
| Total short-term DFS debt | $ | 5,682 |  |  | $ | 5,863 |  |
| Total long-term DFS debt | $ | 3,451 |  |  | $ | 3,629 |  |

- changed (2024-12-10):
[0001571996-24-000143:note_history:53]
|  | November 1, 2024 |  | February 2, 2024 |
|  | (in millions) |
| Senior Notes | $ | 15,073 |  |  | $ | 15,607 |  |
| Legacy Notes | 952 |  |  | 952 |  |
| DFS Debt (Note 4) | 9,171 |  |  | 9,492 |  |
| Other | 56 |  |  | 171 |  |
| Total debt, principal amount | 25,252 |  |  | 26,222 |  |
| Unamortized discount, net of unamortized premium | (113) |  |  | (114) |  |
| Debt issuance costs | (117) |  |  | (114) |  |
| Total debt, carrying value | $ | 25,022 |  |  | $ | 25,994 |  |
| Total short-term debt, carrying value | $ | 5,612 |  |  | $ | 6,982 |  |
| Total long-term debt, carrying value | $ | 19,410 |  |  | $ | 19,012 |  |
  (was, 2024-09-10, similarity 0.9866):
[0001571996-24-000090:note_history:53]
|  | August 2, 2024 |  | February 2, 2024 |
|  | (in millions) |
| Senior Notes | $ | 14,580 |  |  | $ | 15,607 |  |
| Legacy Notes | 952 |  |  | 952 |  |
| DFS Debt (Note 4) | 9,133 |  |  | 9,492 |  |
| Other | 79 |  |  | 171 |  |
| Total debt, principal amount | 24,744 |  |  | 26,222 |  |
| Unamortized discount, net of unamortized premium | (112) |  |  | (114) |  |
| Debt issuance costs | (110) |  |  | (114) |  |
| Total debt, carrying value | $ | 24,522 |  |  | $ | 25,994 |  |
| Total short-term debt, carrying value | $ | 6,711 |  |  | $ | 6,982 |  |
| Total long-term debt, carrying value | $ | 17,811 |  |  | $ | 19,012 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-12-10):
[0001571996-24-000143:note_history:54]
The following table presents the aggregate future maturities of the Company’s debt as of November 1, 2024, excluding associated carrying value adjustments, for the periods indicated:
  (was, 2024-09-10, similarity 0.9602):
[0001571996-24-000090:note_history:54]
The following table presents the aggregate future maturities of the Company’s debt as of August 2, 2024, excluding associated carrying value adjustments, for the periods indicated:

- added (2024-12-10):
[0001571996-24-000143:note_history:55]
|  | November 1, 2024 |
|  | (in millions) |
| Fiscal 2025 (remaining three months) | $ | 2,023 |  |
| Fiscal 2026 | 3,996 |  |
| Fiscal 2027 | 6,020 |  |
| Fiscal 2028 | 1,308 |  |
| Fiscal 2029 | 1,372 |  |
| Thereafter | 10,533 |  |
| Total maturities, principal amount | $ | 25,252 |  |

- removed (2024-12-10):
[0001571996-24-000090:note_history:56]
|  | August 2, 2024 |
|  | (in millions) |
| Fiscal 2025 (remaining six months) | $ | 2,796 |  |
| Fiscal 2026 | 4,567 |  |
| Fiscal 2027 | 5,838 |  |
| Fiscal 2028 | 1,195 |  |
| Fiscal 2029 | 1,326 |  |
| Thereafter | 9,022 |  |
| Total maturities, principal amount | $ | 24,744 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2024-12-10):
[0001571996-24-000143:note_history:57]
RELATED PARTY TRANSACTIONS 
Prior to the acquisition on November 22, 2023 of VMware LLC (previously VMware, Inc. and individually and together with its consolidated subsidiaries, “VMware”) by Broadcom Inc. (“Broadcom”), VMware was considered a related party of the Company. Upon Broadcom’s acquisition of VMware, Michael Dell’s ownership interest in VMware and his position as Chairman of the Board of VMware terminated, and the Company determined no related party relationship exists with Broadcom or VMware effective as of November 22, 2023. The Company continues to engage in select transactions with VMware following the completion of Broadcom’s acquisition and the termination of the related party relationship. See Note 16 of the Notes to the Condensed Consolidated Financial Statements for additional information.
  (was, 2024-09-10, similarity 0.8375):
[0001571996-24-000090:note_history:57]
RELATED PARTY TRANSACTIONS 
Prior to the acquisition on November 22, 2023 of VMware LLC (previously VMware, Inc. and individually and together with its consolidated subsidiaries, “VMware”) by Broadcom Inc. (“Broadcom”), VMware was considered a related party of the Company. Upon Broadcom’s acquisition of VMware, Mr. Dell’s ownership interest in VMware and his position as Chairman of the Board of VMware terminated, and the Company determined no related party relationship exists with Broadcom or VMware effective as of November 22, 2023. The information provided below includes a summary of related party transactions with VMware for the three and six months ended August 4, 2023. The Company continues to engage in select transactions with VMware following the completion of Broadcom’s acquisition and the termination of the related party relationship. See Note 16 of the Notes to the Condensed Consolidated Financial Statements for additional information.

- added (2024-12-10):
[0001571996-24-000143:note_history:58]
The information provided below includes a summary of related party transactions with VMware for the three and nine months ended November 3, 2023.

- changed (2024-12-10):
[0001571996-24-000143:note_history:59]
•Dell Technologies procured products and services from VMware for its internal use. For the three and nine months ended November 3, 2023, costs incurred associated with products and services purchased from VMware for internal use were immaterial.
  (was, 2024-09-10, similarity 0.8977):
[0001571996-24-000090:note_history:59]
•Dell Technologies procured products and services from VMware for its internal use. For the three and six months ended August 4, 2023, costs incurred associated with products and services purchased from VMware for internal use were immaterial.

- changed (2024-12-10):
[0001571996-24-000143:note_history:60]
•Dell Technologies sold and leased products and sold services to VMware. For the three and nine months ended November 3, 2023, revenue recognized from sales of services to VMware was immaterial.
  (was, 2024-09-10, similarity 0.9493):
[0001571996-24-000090:note_history:60]
•Dell Technologies sold and leased products and sold services to VMware. For the three and six months ended August 4, 2023, revenue recognized from sales of services to VMware was immaterial.

- changed (2024-12-10):
[0001571996-24-000143:note_history:61]
•Dell Technologies and VMware entered into joint marketing, sales, and branding arrangements, for which both parties incurred costs. For the three and nine months ended November 3, 2023, consideration received from VMware for joint marketing, sales, and branding arrangements was immaterial.
  (was, 2024-09-10, similarity 0.6678):
[0001571996-24-000090:note_history:61]
•Dell Technologies and VMware entered into joint marketing, sales, and branding arrangements, for which both parties incurred costs. For the three and six months ended August 4, 2023, consideration received from VMware for joint marketing, sales, and branding arrangements was immaterial.

- changed (2024-12-10):
[0001571996-24-000143:note_history:62]
The following table presents information about the impact of Dell Technologies’ related party transactions with VMware on the Consolidated Statements of Income for the three and nine months ended November 3, 2023:
  (was, 2024-09-10, similarity 0.8819):
[0001571996-24-000090:note_history:62]
The following table presents information about the impact of Dell Technologies’ related party transactions with VMware on the Consolidated Statements of Income for the three and six months ended August 4, 2023:

- changed (2024-12-10):
[0001571996-24-000143:note_history:63]
|  |  |  |  |  | Three Months Ended |  |  |  | Nine Months Ended |
|  | Classification |  |  |  | November 3, 2023 |  |  |  | November 3, 2023 |  |  |
|  |  |  |  |  | (in millions) |
| Sales and leases of products to VMware | Net revenue — products |  |  |  | $ | 16 |  |  |  |  | $ | 94 |  |  |  |
| Purchase of VMware products for resale | Cost of net revenue — products |  |  |  | $ | 379 |  |  |  |  | $ | 970 |  |  |  |
| Purchase of VMware services for resale | Cost of net revenue — services |  |  |  | $ | 884 |  |  |  |  | $ | 2,640 |  |  |  |
  (was, 2024-09-10, similarity 0.8318):
[0001571996-24-000090:note_history:63]
|  |  |  |  |  | Three Months Ended |  |  |  | Six Months Ended |
|  | Classification |  |  |  | August 4, 2023 |  |  |  | August 4, 2023 |  |  |
|  |  |  |  |  | (in millions) |
| Sales and leases of products to VMware | Net revenue - products |  |  |  | $ | 38 |  |  |  |  | $ | 78 |  |  |  |
| Purchase of VMware products for resale | Cost of net revenue - products |  |  |  | $ | 384 |  |  |  |  | $ | 591 |  |  |  |
| Purchase of VMware services for resale | Cost of net revenue - services |  |  |  | $ | 880 |  |  |  |  | $ | 1,756 |  |  |  |

- changed (2024-12-10):
[0001571996-24-000143:note_history:64]
In connection with the completion of the VMware Spin-off described in Note 10 of the Notes to the Condensed Consolidated Financial Statements, Dell Technologies and VMware entered into a Tax Matters Agreement effective as of April 14, 2021 (the “Tax Matters Agreement”), which governs the respective rights and obligations of Dell Technologies and VMware regarding income and other taxes as well as related matters, including tax liabilities and benefits, attributes, and returns for periods both preceding and following the VMware Spin-off. Pursuant to the Tax Matters Agreement, net receipts from VMware during the nine months ended November 3, 2023 were immaterial.
  (was, 2024-09-10, similarity 0.8918):
[0001571996-24-000090:note_history:64]
In connection with the completion of the VMware Spin-off, Dell Technologies and VMware entered into a Tax Matters Agreement effective as of April 14, 2021 (the “Tax Matters Agreement”), which governs the respective rights and obligations of Dell Technologies and VMware regarding income and other taxes as well as related matters, including tax liabilities and benefits, attributes, and returns for periods both preceding and following the VMware Spin-off. Pursuant to the Tax Matters Agreement, net receipts from VMware during the six months ended August 4, 2023 were immaterial.


## us-gaap:ScheduleOfRelatedPartyTransactionsTableTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2024-12-10):
[0001571996-24-000143:note_history:65]
The following table presents information about the impact of Dell Technologies’ related party transactions with VMware on the Consolidated Statements of Income for the three and nine months ended November 3, 2023:
  (was, 2024-09-10, similarity 0.8819):
[0001571996-24-000090:note_history:65]
The following table presents information about the impact of Dell Technologies’ related party transactions with VMware on the Consolidated Statements of Income for the three and six months ended August 4, 2023:

- changed (2024-12-10):
[0001571996-24-000143:note_history:66]
|  |  |  |  |  | Three Months Ended |  |  |  | Nine Months Ended |
|  | Classification |  |  |  | November 3, 2023 |  |  |  | November 3, 2023 |  |  |
|  |  |  |  |  | (in millions) |
| Sales and leases of products to VMware | Net revenue — products |  |  |  | $ | 16 |  |  |  |  | $ | 94 |  |  |  |
| Purchase of VMware products for resale | Cost of net revenue — products |  |  |  | $ | 379 |  |  |  |  | $ | 970 |  |  |  |
| Purchase of VMware services for resale | Cost of net revenue — services |  |  |  | $ | 884 |  |  |  |  | $ | 2,640 |  |  |  |
  (was, 2024-09-10, similarity 0.8318):
[0001571996-24-000090:note_history:66]
|  |  |  |  |  | Three Months Ended |  |  |  | Six Months Ended |
|  | Classification |  |  |  | August 4, 2023 |  |  |  | August 4, 2023 |  |  |
|  |  |  |  |  | (in millions) |
| Sales and leases of products to VMware | Net revenue - products |  |  |  | $ | 38 |  |  |  |  | $ | 78 |  |  |  |
| Purchase of VMware products for resale | Cost of net revenue - products |  |  |  | $ | 384 |  |  |  |  | $ | 591 |  |  |  |
| Purchase of VMware services for resale | Cost of net revenue - services |  |  |  | $ | 880 |  |  |  |  | $ | 1,756 |  |  |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-12-10):
[0001571996-24-000143:note_history:67]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 1, 2024 |  | November 3, 2023 |  | November 1, 2024 |  | November 3, 2023 |  |  |
|  | (in millions) |
| Net revenue: |  |  |  |  |  |  |  |  |  |
| Infrastructure Solutions Group: |  |  |  |  |  |  |  |  |  |
| Servers and networking | $ | 7,364 |  |  | $ | 4,656 |  |  | $ | 20,502 |  |  | $ | 12,767 |  |  |  |
| Storage | 4,004 |  |  | 3,843 |  |  | 11,739 |  |  | 11,786 |  |  |  |
| Total ISG net revenue | $ | 11,368 |  |  | $ | 8,499 |  |  | $ | 32,241 |  |  | $ | 24,553 |  |  |  |
| Client Solutions Group: |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 10,138 |  |  | $ | 9,835 |  |  | $ | 30,848 |  |  | $ | 30,251 |  |  |  |
| Consumer | 1,993 |  |  | 2,441 |  |  | 5,664 |  |  | 6,950 |  |  |  |
| Total CSG net revenue | $ | 12,131 |  |  | $ | 12,276 |  |  | $ | 36,512 |  |  | $ | 37,201 |  |  |  |
  (was, 2024-09-10, similarity 0.911):
[0001571996-24-000090:note_history:67]
|  | Three Months Ended |  | Six Months Ended |
|  | August 2, 2024 |  | August 4, 2023 |  | August 2, 2024 |  | August 4, 2023 |  |  |
|  | (in millions) |
| Net revenue: |  |  |  |  |  |  |  |  |  |
| Infrastructure Solutions Group: |  |  |  |  |  |  |  |  |  |
| Servers and networking | $ | 7,672 |  |  | $ | 4,274 |  |  | $ | 13,138 |  |  | $ | 8,111 |  |  |  |
| Storage | 3,974 |  |  | 4,187 |  |  | 7,735 |  |  | 7,943 |  |  |  |
| Total ISG net revenue | $ | 11,646 |  |  | $ | 8,461 |  |  | $ | 20,873 |  |  | $ | 16,054 |  |  |  |
| Client Solutions Group: |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 10,556 |  |  | $ | 10,554 |  |  | $ | 20,710 |  |  | $ | 20,416 |  |  |  |
| Consumer | 1,858 |  |  | 2,388 |  |  | 3,671 |  |  | 4,509 |  |  |  |
| Total CSG net revenue | $ | 12,414 |  |  | $ | 12,942 |  |  | $ | 24,381 |  |  | $ | 24,925 |  |  |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-12-10):
[0001571996-24-000143:note_history:68]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 1, 2024 |  | November 3, 2023 |  | November 1, 2024 |  | November 3, 2023 |
|  | (in millions) |
| Deferred revenue: |  |  |  |  |  |  |  |
| Deferred revenue at beginning of period | $ | 27,712 |  |  | $ | 30,312 |  |  | $ | 29,145 |  |  | $ | 30,286 |  |
| Revenue deferrals | 3,897 |  |  | 4,492 |  |  | 13,286 |  |  | 15,236 |  |
| Revenue recognized | (5,262) |  |  | (5,766) |  |  | (16,084) |  |  | (16,484) |  |
| Other (a) | (136) |  |  | 15 |  |  | (136) |  |  | 15 |  |
| Deferred revenue at end of period | $ | 26,211 |  |  | $ | 29,053 |  |  | $ | 26,211 |  |  | $ | 29,053 |  |
| Short-term deferred revenue | $ | 13,787 |  |  | $ | 15,206 |  |  | $ | 13,787 |  |  | $ | 15,206 |  |
| Long-term deferred revenue | $ | 12,424 |  |  | $ | 13,847 |  |  | $ | 12,424 |  |  | $ | 13,847 |  |
  (was, 2024-09-10, similarity 0.6377):
[0001571996-24-000090:note_history:68]
|  | Three Months Ended |  | Six Months Ended |
|  | August 2, 2024 |  | August 4, 2023 |  | August 2, 2024 |  | August 4, 2023 |
|  | (in millions) |
| Deferred revenue: |  |  |  |  |  |  |  |
| Deferred revenue at beginning of period | $ | 28,150 |  |  | $ | 29,695 |  |  | $ | 29,145 |  |  | $ | 30,286 |  |
| Revenue deferrals | 4,920 |  |  | 6,025 |  |  | 9,389 |  |  | 10,744 |  |
| Revenue recognized | (5,358) |  |  | (5,408) |  |  | (10,822) |  |  | (10,718) |  |
| Deferred revenue at end of period | $ | 27,712 |  |  | $ | 30,312 |  |  | $ | 27,712 |  |  | $ | 30,312 |  |
| Short-term deferred revenue | $ | 14,853 |  |  | $ | 16,174 |  |  | $ | 14,853 |  |  | $ | 16,174 |  |
| Long-term deferred revenue | $ | 12,859 |  |  | $ | 14,138 |  |  | $ | 12,859 |  |  | $ | 14,138 |  |

- added (2024-12-10):
[0001571996-24-000143:note_history:69]
____________________

- added (2024-12-10):
[0001571996-24-000143:note_history:70]
(a) For the three and nine months ended November 1, 2024, Other represents the reclassification of Secureworks deferred revenue to liabilities held for sale. See Note 1 of the Notes to the Condensed Consolidated Financial Statements for more information about the pending sale of Secureworks.

- changed (2024-12-10):
[0001571996-24-000143:note_history:71]
Remaining Performance Obligations — Remaining performance obligations represent the aggregate amount of the transaction price allocated to performance obligations not delivered, or partially undelivered, as of the end of the reporting period. Remaining performance obligations include deferred revenue plus unbilled amounts not yet recorded in deferred revenue. The value of the transaction price allocated to remaining performance obligations as of November 1, 2024 was approximately $37 billion. The Company expects to recognize approximately 60% of remaining performance obligations as revenue in the next twelve months, and the remainder thereafter.
  (was, 2024-09-10, similarity 0.9892):
[0001571996-24-000090:note_history:71]
Remaining Performance Obligations — Remaining performance obligations represent the aggregate amount of the transaction price allocated to performance obligations not delivered, or partially undelivered, as of the end of the reporting period. Remaining performance obligations include deferred revenue plus unbilled amounts not yet recorded in deferred revenue. The value of the transaction price allocated to remaining performance obligations as of August 2, 2024 was approximately $38 billion. The Company expects to recognize approximately 59% of remaining performance obligations as revenue in the next twelve months, and the remainder thereafter.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2024-12-10):
[0001571996-24-000143:note_history:72]
SUBSEQUENT EVENTS 
There were no known events occurring after November 1, 2024, and up until the date of issuance of this report that would materially affect the information presented herein.
  (was, 2024-09-10, similarity 0.962):
[0001571996-24-000090:note_history:72]
SUBSEQUENT EVENTS 
There were no known events occurring after August 2, 2024 and up until the date of issuance of this report that would materially affect the information presented herein.
