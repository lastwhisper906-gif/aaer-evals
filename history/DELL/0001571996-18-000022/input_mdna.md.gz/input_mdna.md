# DELL MD&A — 0001571996-18-000022


## mdna

[0001571996-18-000022:mdna:1]
[same as prior period, unchanged from 0001571996-17-000045:mdna:1]

[0001571996-18-000022:mdna:2]
This management's discussion and analysis should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in the Company's annual report on Form 10-K for the fiscal year ended February 2, 2018.  Multiple accounting standards were adopted during the three months ended May 4, 2018, which resulted in adjustment or reclassification of amounts previously reported.  See Note 1 of the Notes to the Condensed Consolidated Financial Statements included in this report for further information regarding our recently adopted accounting standards.

[0001571996-18-000022:mdna:3]
[same as prior period, unchanged from 0001571996-17-000045:mdna:2]

[0001571996-18-000022:mdna:4]
Unless the context indicates otherwise, references in this report to "we," "us," "our," the "Company," and "Dell Technologies" mean Dell Technologies Inc. and its consolidated subsidiaries, references to "Dell" mean Dell Inc. and Dell Inc.'s consolidated subsidiaries, and references to "EMC" mean EMC Corporation and EMC Corporation's consolidated subsidiaries.

[0001571996-18-000022:mdna:5]
Our fiscal year is the 52- or 53-week period ending on the Friday nearest January 31.  We refer to our fiscal years ending February 1, 2019 and our fiscal year ended February 2, 2018 as "Fiscal 2019" and "Fiscal 2018," respectively.  Fiscal 2019 and Fiscal 2018 include 52 weeks.

[0001571996-18-000022:mdna:6]
[same as prior period, unchanged from 0001571996-17-000045:mdna:6]

[0001571996-18-000022:mdna:7]
Dell Technologies is a strategically aligned family of businesses, poised to become the essential infrastructure company, from the edge to the core to the cloud, as we continue our mission to advance human progress through technology.  We seek to accomplish this by executing two related, high-level strategic initiatives:  helping our customers transform their businesses through digital, IT, workforce, and security transformation, while extending our many leading market positions in IT infrastructure solutions and client solutions.

[0001571996-18-000022:mdna:8]
Dell Technologies brings together the entire infrastructure from hardware to software to services.  The core of IT is evolving in our hyper-connected world, containing both centralized data centers and geographically distributed hyper-converged infrastructure.  Dell Technologies is a leader in the traditional technology of today and a leader in the cloud-native infrastructure of tomorrow.  Dell Technologies offers next-generation solutions through our Infrastructure Solutions Group, Client Solutions Group, VMware, Inc., RSA Information Security ("RSA"), Pivotal Software, Inc. ("Pivotal"), SecureWorks Corp. ("SecureWorks"),  Virtustream, Inc. ("Virtustream"), and Boomi, Inc. ("Boomi").  Our next-generation solutions enable digital transformation and encompass software-defined data centers, all-flash arrays, hybrid cloud, converged and hyper-converged infrastructure, cloud-native application development tools, mobile, and security solutions.  In addition, we provide important value differentiators through our extended warranty and delivery offerings, and software and peripherals, which are closely tied to the sale of our hardware products.

[0001571996-18-000022:mdna:9]
Dell Technologies is committed to our customers.  As we innovate to make our customers' existing IT increasingly productive, we help them reinvest their savings into the next generation of technologies that they need to succeed in the digital economy.  We are positioned to help customers of any size and are differentiated by our practical innovation and efficient, integrated solutions.

[0001571996-18-000022:mdna:10]
A key milestone for Dell Technologies was the EMC merger transaction which was completed in September 2016.  Since then, our many accomplishments have included the broad expansion of our product portfolio, integration of our supply chain, and achievement of revenue synergies across the business.  With these accomplishments, we believe we are well-positioned for long-term sustainable growth and innovation.  As we continue our integration of the EMC acquired businesses, we remain committed to our customers, supporting them with outstanding solutions, products, and services.  We will continue our focus on building superior customer relationships through our direct model and our network of channel partners, which includes value-

[0001571996-18-000022:mdna:11]
added resellers, system integrators, distributors, and retailers.  We also will continue to balance our efforts to drive cost efficiencies in the business with strategic investments in areas that will enable growth, such as our sales force, marketing, and research and development, as we seek to strengthen our position as a leading global technology company poised for long-term sustainable growth and innovation.

[0001571996-18-000022:mdna:12]
[same as prior period, unchanged from 0001571996-17-000045:mdna:18]

[0001571996-18-000022:mdna:13]
We design, develop, manufacture, market, sell, and support a wide range of products and services.  We are organized into the following business units, which are our reportable segments: Infrastructure Solutions Group; Client Solutions Group; and VMware.

[0001571996-18-000022:mdna:14]
| • | Infrastructure Solutions Group ("ISG") — ISG contains storage, server, and networking offerings. The comprehensive portfolio of advanced storage solutions includes traditional storage solutions as well as next-generation storage solutions (including all-flash arrays and scale-out file, and object platforms). The server portfolio includes high-performance rack, blade, tower, and hyperscale servers. The networking portfolio enables our business customers to transform and modernize their infrastructure, mobilize and enrich end-user experiences, and accelerate business applications and processes. ISG also offers attached software, peripherals, and services, including support and deployment, configuration, and extended warranty services. |

[0001571996-18-000022:mdna:15]
We are currently working to simplify our storage portfolio, with the goal of ensuring that we deliver the technology needed for our customers' digital transformation.  We anticipate that these changes will take two to three years to execute.  As our storage portfolio evolves, we will continue to support our current portfolio of storage solutions.

[0001571996-18-000022:mdna:16]
Approximately half of ISG revenue is generated by sales to customers in the Americas, with the remaining portion derived from sales to customers in the Europe, Middle East, and Africa region ("EMEA") and the Asia-Pacific and Japan region ("APJ").

[0001571996-18-000022:mdna:17]
| • | Client Solutions Group ("CSG") — Offerings by CSG include branded hardware, such as desktop PCs, notebooks, and workstations, and branded peripherals, such as monitors, and projectors. CSG also offers attached software, peripherals, and services, including support and deployment, configuration, and extended warranty services. |

[0001571996-18-000022:mdna:18]
Approximately half of CSG revenue is generated by sales to customers in the Americas, with the remaining portion derived from sales to customers in EMEA and APJ.

[0001571996-18-000022:mdna:19]
[same as prior period, unchanged from 0001571996-17-000045:mdna:24]

[0001571996-18-000022:mdna:20]
VMware provides compute, cloud, mobility, networking, and security infrastructure software to businesses that provides a flexible digital foundation for the applications that empower businesses to serve their customers globally.  VMware offers a broad portfolio of virtualization technologies across three main product groups: software-defined data center; hybrid cloud computing; and end-user computing.

[0001571996-18-000022:mdna:21]
[same as prior period, unchanged from 0001571996-17-000045:mdna:28]

[0001571996-18-000022:mdna:22]
Our other businesses, described below, consist of product and service offerings of RSA, Pivotal, SecureWorks, Virtustream, and Boomi.  These businesses are not classified as reportable segments, either individually or collectively, as the results of the businesses are not material to our overall results and the businesses do not meet the criteria for reportable segments.

[0001571996-18-000022:mdna:23]
| • | RSA provides essential cybersecurity solutions engineered to enable organizations to detect, investigate, and respond to advanced attacks, confirm and manage identities, and, ultimately, help reduce IP theft, fraud, and cybercrime. |

[0001571996-18-000022:mdna:24]
| • | Pivotal (NYSE: PVTL) provides a leading cloud-native platform that makes software development and IT operations a strategic advantage for customers. Pivotal's cloud-native platform, Pivotal Cloud Foundry, accelerates and streamlines software development by reducing the complexity of building, deploying and operating new cloud-native applications and modernizing legacy applications. On April 24, 2018, Pivotal completed a registered underwritten initial public offering of its Class A common stock. |

[0001571996-18-000022:mdna:25]
[same as prior period, unchanged from 0001571996-17-000045:mdna:31]

[0001571996-18-000022:mdna:26]
| • | Virtustream offers cloud software and infrastructure-as-a-service solutions that enable customers to migrate, run, and manage mission-critical applications in cloud-based IT environments, and that represent a key element of our strategy to help customers support their applications in a variety of cloud-native environments. Beginning in the first quarter of Fiscal 2019, Virtustream results are being reported within other businesses, rather than within ISG. This change in reporting structure did not impact our previously reported consolidated financial results, but our prior period segment results have been recast to reflect the change. |

[0001571996-18-000022:mdna:27]
[same as prior period, unchanged from 0001571996-17-000045:mdna:33]

[0001571996-18-000022:mdna:28]
See Note 18 of the Notes to the Condensed Consolidated Financial Statements included in this report for more information about our other businesses.

[0001571996-18-000022:mdna:29]
[same as prior period, unchanged from 0001571996-17-000045:mdna:35]

[0001571996-18-000022:mdna:30]
[same as prior period, unchanged from 0001571996-17-000045:mdna:36]

[0001571996-18-000022:mdna:31]
We also offer or arrange various financing options and services for our customers in North America, Europe, Australia, and New Zealand through Dell Financial Services and its affiliates ("DFS").  DFS services include originating, collecting, and servicing customer receivables primarily related to the purchase of Dell Technologies products.  The results of these operations are allocated to our segments based on the underlying product or service financed.  For additional information about our financing arrangements, see Note 5 of the Notes to the Condensed Consolidated Financial Statements included in this report.

[0001571996-18-000022:mdna:32]
Strategic Investments and Acquisitions

[0001571996-18-000022:mdna:33]
As part of our strategy, we will continue to evaluate opportunities for strategic investments through our venture capital investment arm, Dell Technologies Capital, with a focus on emerging technology areas that are relevant to the Dell Technologies unique family of businesses and that will complement our existing portfolio of solutions.  Our investment areas include storage, software-defined networking, management and orchestration, security, machine learning and artificial intelligence, Big Data and analytics, cloud, Internet of Things, and software development operations.  In addition to these investments, we also may make disciplined acquisitions targeting businesses that advance our strategic objectives.

[0001571996-18-000022:mdna:34]
[same as prior period, unchanged from 0001571996-17-000045:mdna:38]

[0001571996-18-000022:mdna:35]
We are seeing an unprecedented rate of change in the IT industry.  Organizations of all kinds are embracing digital technology to achieve their business objectives.  Our vision is to be an essential infrastructure company and leader in end-user computing, data center infrastructure solutions, virtualization, Internet of Things ("IoT"), and cloud software that our customers continue to trust and rely on for their IT solutions and transformations as they embrace the multi-cloud environment of today.  To further advance this vision, we recently unveiled a new IoT strategy, division, and an array of solutions to support IoT adoption for our customers.  We accelerate results for our customers by enabling them to be more efficient, mobile, informed, and secure.  We continue to invest in research and development, sales, and other key areas of our business to deliver superior products and solutions capabilities and to drive execution of long-term sustainable growth.  We believe that our results will benefit from an integrated go-to-market strategy, including enhanced coordination among the family of Dell Technologies companies, and from our differentiated products and solutions capabilities.  We intend to continue to execute on our business model and seek to balance liquidity, profitability, and growth to position our company for long-term success.

[0001571996-18-000022:mdna:36]
We expect that ISG will continue to be impacted by the changing nature of the IT infrastructure market and competitive environment.  Cloud-native applications are expected to continue as a primary growth driver in the infrastructure market as IT organizations increasingly become multi-cloud environments.  We believe the complementary cloud solutions across our business, created through our combination with EMC, strongly position us to meet these demands for our customers who are increasingly looking to leverage cloud-based computing.  We also continue to be impacted by the emerging trends of enterprises deploying software-defined storage, hyper-converged infrastructure, and modular solutions based on server-centric architectures.  These trends have put pressure on our traditional storage offerings, and we are focused on strategically repositioning our storage portfolio.  We have leading solutions through our ISG and VMware data center offerings.  In addition, through our research and development efforts, we expect to develop new solutions in this rapidly changing industry that we believe will enable us to continue to provide superior solutions to our customers.

[0001571996-18-000022:mdna:37]
In ISG, we are also seeing increased interest in flexible consumption models by our customers as they seek to build greater flexibility into their cost structures.  These solutions are generally multi-year contracts that typically result in recognition of revenue over the term of the arrangement.  We expect these flexible consumption models will further strengthen our customer relationships, and will provide more predictable revenue streams over time.

[0001571996-18-000022:mdna:38]
We are able to leverage our traditional strength in the PC market to offer solutions and services that provide higher-value, recurring revenue streams.  Given current market trends, we expect that the demand environment will continue to be cyclical and that competitive dynamics will continue to pressure our CSG business.  However, we are committed to a long-term growth strategy that we believe will benefit from the consolidation trends that are occurring in our markets.  Our CSG offerings remain an important element of our strategy, generating strong cash flow and opportunities for cross-selling of complementary solutions.  CSG net revenue represented approximately half of our net revenue during both the first quarter of Fiscal 2019 and the first quarter of Fiscal 2018.

[0001571996-18-000022:mdna:39]
We manage our business on a U.S. dollar basis.  However, we have a large global presence, generating approximately half of our revenue by sales to customers outside of the United States during the first three months of Fiscal 2019 and the first three months of Fiscal 2018.  Our revenues, therefore, can be impacted by fluctuations in foreign currency exchange rates.  We utilize a comprehensive hedging strategy intended to mitigate the impact of foreign currency volatility over time, and we adjust pricing when possible to further minimize foreign currency impacts.

[0001571996-18-000022:mdna:40]
[same as prior period, unchanged from 0001571996-17-000045:mdna:222]

[0001571996-18-000022:mdna:41]
Our key performance metrics are net revenue, operating income, adjusted EBITDA, and cash flows from operations, and are discussed elsewhere in this report.

[0001571996-18-000022:mdna:42]
[same as prior period, unchanged from 0001571996-17-000045:mdna:52]

[0001571996-18-000022:mdna:43]
In this management's discussion and analysis, we use supplemental measures of our performance which are derived from our consolidated financial information but which are not presented in our consolidated financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("GAAP").  These non-GAAP financial measures include non-GAAP product net revenue; non-GAAP services net revenue; non-GAAP net revenue; non-GAAP product gross margin; non-GAAP services gross margin; non-GAAP gross margin; non-GAAP operating expenses; non-GAAP operating income; non-GAAP net income; earnings before interest and other, net, taxes, depreciation, and amortization ("EBITDA"); and adjusted EBITDA.

[0001571996-18-000022:mdna:44]
[same as prior period, unchanged from 0001571996-17-000045:mdna:54]

[0001571996-18-000022:mdna:45]
[same as prior period, unchanged from 0001571996-17-000045:mdna:55]

[0001571996-18-000022:mdna:46]
Non-GAAP product net revenue, non-GAAP services net revenue, non-GAAP net revenue, non-GAAP product gross margin, non-GAAP services gross margin, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, and non-GAAP net income, as defined by us, exclude the impact of purchase accounting, amortization of intangible assets, transaction-related expenses, other corporate expenses and, for non-GAAP net income from continuing operations, an aggregate adjustment for income taxes.  As the excluded items have a material impact on our financial results, our management compensates for this limitation by relying primarily on our GAAP results and using non-GAAP financial measures supplementally or for projections when comparable GAAP financial measures are not available.  The non-GAAP financial measures are not meant to be considered as indicators of performance in isolation from or as a substitute for net revenue, gross margin, operating expenses, operating income, or net income prepared in accordance with GAAP, and should be read only in conjunction with financial information presented on a GAAP basis.

[0001571996-18-000022:mdna:47]
[same as prior period, unchanged from 0001571996-17-000045:mdna:57]

[0001571996-18-000022:mdna:48]
[same as prior period, unchanged from 0001571996-17-000045:mdna:58]

[0001571996-18-000022:mdna:49]
| • | Amortization of Intangible Assets — Amortization of intangible assets primarily consists of amortization of customer relationships, developed technology, and trade names. In connection with the EMC merger transaction and the acquisition of Dell Inc. by Dell Technologies Inc. on October 29, 2013, referred to as the going-private transaction, all of the tangible and intangible assets and liabilities of EMC and Dell, respectively, were accounted for and recognized at fair value on the transaction dates. Accordingly, for the periods presented, amortization of intangible assets represents amortization associated with intangible assets recognized in connection with the EMC merger transaction and the going-private transaction. Amortization charges for purchased intangible assets are significantly impacted by the timing and magnitude of our acquisitions, and these charges may vary in amount from period to period. We exclude these charges for purposes of calculating the non-GAAP financial measures presented below to facilitate a more meaningful evaluation of our current operating performance and comparisons to our past operating performance. |

[0001571996-18-000022:mdna:50]
| • | Impact of Purchase Accounting — The impact of purchase accounting includes purchase accounting adjustments, related to the EMC merger transaction and, to a lesser extent, the going-private transaction, recorded under the acquisition method of |

[0001571996-18-000022:mdna:51]
accounting in accordance with the accounting guidance for business combinations.  This guidance prescribes that the purchase price be allocated to assets acquired and liabilities assumed based on the estimated fair value of such assets and liabilities on the date of the transaction.  Accordingly, all of the assets and liabilities acquired in the EMC merger transaction and the going-private transaction were accounted for and recognized at fair value as of the respective transaction dates, and the fair value adjustments are being amortized over the estimated useful lives in the periods following the transactions.  The fair value adjustments primarily relate to deferred revenue, inventory, and property, plant, and equipment.  The purchase accounting adjustments and related amortization of those adjustments are reflected in our GAAP results; however, we evaluate the operating results of the underlying businesses on a non-GAAP basis, after removing such adjustments.  We believe that excluding the impact of purchase accounting provides results that are useful in understanding our current operating performance and provides more meaningful comparisons to our past operating performance.

[0001571996-18-000022:mdna:52]
| • | Transaction-related Expenses — Transaction-related expenses consist of acquisition, integration, and divestiture related costs, and are expensed as incurred. These expenses primarily represent costs for legal, banking, consulting, and advisory services, as well as certain compensatory retention awards directly related to the EMC merger transaction. During the first quarter of Fiscal 2019, this category also includes approximately $116 million of expenses related to integration of our inventory policies and management process related to customer evaluation units. |

[0001571996-18-000022:mdna:53]
| • | Other Corporate Expenses — Other corporate expenses consists of severance, facility action costs, and stock-based compensation expense associated with equity awards. Severance costs are primarily related to severance and benefits for employees terminated pursuant to cost savings initiatives. Facility action costs were $9 million and $79 million during the first quarter of Fiscal 2019 and the first quarter of Fiscal 2018, respectively. We expect to incur additional costs during the next nine months of Fiscal 2019 as we continue to integrate owned and leased facilities and as we seek opportunities for operational efficiencies and cost savings. Other corporate expenses vary from period to period and are significantly impacted by the timing and nature of these events. Therefore, although we may incur these types of expenses in the future, we believe that eliminating these charges for purposes of calculating the non-GAAP financial measures presented below facilitates a more meaningful evaluation of our current operating performance and comparisons to our past operating performance. |

[0001571996-18-000022:mdna:54]
| • | Aggregate Adjustment for Income Taxes — The aggregate adjustment for income taxes is the estimated combined income tax effect for the adjustments described above. During the first quarter of Fiscal 2019, this category also includes approximately $154 million of tax benefits resulting from the impact of adopting the new revenue recognition standard. The tax effects are determined based on the tax jurisdictions where the above items were incurred. |

[0001571996-18-000022:mdna:55]
[same as prior period, unchanged from 0001571996-17-000045:mdna:26]

[0001571996-18-000022:mdna:56]
[same as prior period, unchanged from 0001571996-17-000045:mdna:65]

[0001571996-18-000022:mdna:57]
|  | Three Months Ended |
|  | May 4, 2018 |  | % Change |  | May 5, 2017 |
|  | (in millions, except percentages) |
| Product net revenue | $ | 16,671 |  |  | 22 | % |  | $ | 13,634 |  |
| Non-GAAP adjustments: |  |  |  |  |  |
| Impact of purchase accounting | 17 |  |  |  |  | 55 |  |
| Non-GAAP product net revenue | $ | 16,688 |  |  | 22 | % |  | $ | 13,689 |  |
| Services net revenue | $ | 4,685 |  |  | 7 | % |  | 4,366 |  |
| Non-GAAP adjustments: |  |  |  |  |  |
| Impact of purchase accounting | 170 |  |  |  |  | 300 |  |
| Non-GAAP services net revenue | $ | 4,855 |  |  | 4 | % |  | $ | 4,666 |  |
| Net revenue | $ | 21,356 |  |  | 19 | % |  | 18,000 |  |
| Non-GAAP adjustments: |  |  |  |  |  |
| Impact of purchase accounting | 187 |  |  |  |  | 355 |  |
| Non-GAAP net revenue | $ | 21,543 |  |  | 17 | % |  | $ | 18,355 |  |
| Product gross margin | $ | 3,065 |  |  | 69 | % |  | 1,811 |  |
| Non-GAAP adjustments: |  |  |  |  |  |
| Amortization of intangibles | 710 |  |  |  |  | 950 |  |
| Impact of purchase accounting | 23 |  |  |  |  | 65 |  |
| Transaction related | 116 |  |  |  |  | 2 |  |
| Other corporate expenses | 4 |  |  |  |  | 3 |  |
| Non-GAAP product gross margin | $ | 3,918 |  |  | 38 | % |  | $ | 2,831 |  |
| Services gross margin | $ | 2,813 |  |  | 6 | % |  | 2,646 |  |
| Non-GAAP adjustments: |  |  |  |  |  |
| Impact of purchase accounting | 170 |  |  |  |  | 300 |  |
| Transaction related | — |  |  |  |  | 5 |  |
| Other corporate expenses | 18 |  |  |  |  | 19 |  |
| Non-GAAP services gross margin | $ | 3,001 |  |  | 1 | % |  | $ | 2,970 |  |
| Gross margin | $ | 5,878 |  |  | 32 | % |  | 4,457 |  |
| Non-GAAP adjustments: |  |  |  |  |  |
| Amortization of intangibles | 710 |  |  |  |  | 950 |  |
| Impact of purchase accounting | 193 |  |  |  |  | 365 |  |
| Transaction related | 116 |  |  |  |  | 7 |  |
| Other corporate expenses | 22 |  |  |  |  | 22 |  |
| Non-GAAP gross margin | $ | 6,919 |  |  | 19 | % |  | $ | 5,801 |  |

[0001571996-18-000022:mdna:58]
[same as prior period, unchanged from 0001571996-17-000045:mdna:41]

[0001571996-18-000022:mdna:59]
|  | Three Months Ended |
|  | May 4, 2018 |  | % Change |  | May 5, 2017 |
|  | (in millions, except percentages) |
| Operating expenses | $ | 6,031 |  |  | 5 | % |  | $ | 5,729 |  |
| Non-GAAP adjustments: |  |  |  |  |  |
| Amortization of intangibles | (812 | ) |  |  |  | (826 | ) |
| Impact of purchase accounting | (29 | ) |  |  |  | (58 | ) |
| Transaction related | (50 | ) |  |  |  | (184 | ) |
| Other corporate expenses | (247 | ) |  |  |  | (285 | ) |
| Non-GAAP operating expenses | $ | 4,893 |  |  | 12 | % |  | $ | 4,376 |  |
| Operating loss | $ | (153 | ) |  | 88 | % |  | $ | (1,272 | ) |
| Non-GAAP adjustments: |  |  |  |  |  |
| Amortization of intangibles | 1,522 |  |  |  |  | 1,776 |  |
| Impact of purchase accounting | 222 |  |  |  |  | 423 |  |
| Transaction related | 166 |  |  |  |  | 191 |  |
| Other corporate expenses | 269 |  |  |  |  | 307 |  |
| Non-GAAP operating income | $ | 2,026 |  |  | 42 | % |  | $ | 1,425 |  |
| Net loss | $ | (538 | ) |  | 55 | % |  | $ | (1,203 | ) |
| Non-GAAP adjustments: |  |  |  |  |  |
| Amortization of intangibles | 1,522 |  |  |  |  | 1,776 |  |
| Impact of purchase accounting | 222 |  |  |  |  | 423 |  |
| Transaction related | 166 |  |  |  |  | 191 |  |
| Other corporate expenses | 269 |  |  |  |  | 307 |  |
| Aggregate adjustment for income taxes | (467 | ) |  |  |  | (733 | ) |
| Non-GAAP net income | $ | 1,174 |  |  | 54 | % |  | $ | 761 |  |

[0001571996-18-000022:mdna:60]
In addition to the above measures, we also use EBITDA and adjusted EBITDA to provide additional information for evaluation of our operating performance.  Adjusted EBITDA excludes purchase accounting adjustments related to the EMC merger transaction and the going-private transaction, acquisition, integration, and divestiture related costs, severance and facility action costs, and stock-based compensation expense.  We believe that, due to the non-operational nature of the purchase accounting entries, it is appropriate to exclude these adjustments.

[0001571996-18-000022:mdna:61]
[same as prior period, unchanged from 0001571996-17-000045:mdna:70]

[0001571996-18-000022:mdna:62]
[same as prior period, unchanged from 0001571996-17-000045:mdna:71]

[0001571996-18-000022:mdna:63]
|  | Three Months Ended |
|  | May 4, 2018 |  | % Change |  | May 5, 2017 |
|  | (in millions, except percentages) |
| Net loss | $ | (538 | ) |  | 55 | % |  | $ | (1,203 | ) |
| Adjustments: |  |  |  |  |  |
| Interest and other, net (a) | 470 |  |  |  |  | 572 |  |
| Income tax benefit | (85 | ) |  |  |  | (641 | ) |
| Depreciation and amortization | 1,914 |  |  |  |  | 2,212 |  |
| EBITDA | $ | 1,761 |  |  | 87 | % |  | $ | 940 |  |
| EBITDA | $ | 1,761 |  |  | 87 | % |  | $ | 940 |  |
| Adjustments: |  |  |  |  |  |
| Stock-based compensation expense | 199 |  |  |  |  | 201 |  |
| Impact of purchase accounting (b) | 222 |  |  |  |  | 357 |  |
| Transaction-related expenses (c) | 166 |  |  |  |  | 191 |  |
| Other corporate expenses (d) | 35 |  |  |  |  | 106 |  |
| Adjusted EBITDA | $ | 2,383 |  |  | 33 | % |  | $ | 1,795 |  |

[0001571996-18-000022:mdna:64]
[same as prior period, unchanged from 0001571996-17-000045:mdna:73]

[0001571996-18-000022:mdna:65]
[same as prior period, unchanged from 0001571996-17-000045:mdna:74]

[0001571996-18-000022:mdna:66]
[same as prior period, unchanged from 0001571996-17-000045:mdna:75]

[0001571996-18-000022:mdna:67]
[same as prior period, unchanged from 0001571996-17-000045:mdna:76]

[0001571996-18-000022:mdna:68]
[same as prior period, unchanged from 0001571996-17-000045:mdna:77]

[0001571996-18-000022:mdna:69]
67

[0001571996-18-000022:mdna:70]
[same as prior period, unchanged from 0001571996-17-000045:mdna:80]

[0001571996-18-000022:mdna:71]
[same as prior period, unchanged from 0001571996-17-000045:mdna:81]

[0001571996-18-000022:mdna:72]
The following table summarizes our consolidated results from continuing operations for each of the periods presented.  Unless otherwise indicated, all changes identified for the current-period results represent comparisons to results for the prior corresponding fiscal period.  Multiple accounting standards were adopted during the three months ended May 4, 2018, which resulted in adjustment or reclassification of amounts previously reported.  See Note 1 of the Notes to the Condensed Consolidated Financial Statements included in this report for further information regarding our recently adopted accounting standards.

[0001571996-18-000022:mdna:73]
|  | Three Months Ended |
|  | May 4, 2018 |  |  |  | May 5, 2017 |
|  | Dollars |  | % ofNet Revenue |  | %Change |  | Dollars |  | % ofNet Revenue |
|  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |  |  |  |  |
| Product | $ | 16,671 |  |  | 78.1 | % |  | 22 | % |  | $ | 13,634 |  |  | 75.7 | % |
| Services | 4,685 |  |  | 21.9 | % |  | 7 | % |  | 4,366 |  |  | 24.3 | % |
| Total net revenue | $ | 21,356 |  |  | 100.0 | % |  | 19 | % |  | $ | 18,000 |  |  | 100.0 | % |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |
| Product (a) | $ | 3,065 |  |  | 18.4 | % |  | 69 | % |  | $ | 1,811 |  |  | 13.3 | % |
| Services (b) | 2,813 |  |  | 60.0 | % |  | 6 | % |  | 2,646 |  |  | 60.6 | % |
| Total gross margin | $ | 5,878 |  |  | 27.5 | % |  | 32 | % |  | $ | 4,457 |  |  | 24.8 | % |
| Operating expenses | $ | 6,031 |  |  | 28.2 | % |  | 5 | % |  | $ | 5,729 |  |  | 31.9 | % |
| Operating loss | $ | (153 | ) |  | (0.7 | )% |  | 88 | % |  | $ | (1,272 | ) |  | (7.1 | )% |
| Net loss | $ | (538 | ) |  | (2.5 | )% |  | 55 | % |  | $ | (1,203 | ) |  | (6.7 | )% |
| Net loss attributable to Dell Technologies Inc. | $ | (636 | ) |  | (3.0 | )% |  | 46 | % |  | $ | (1,171 | ) |  | (6.5 | )% |
| Non-GAAP Financial Information |  |  |  |  |  |  |  |  |  |
| Non-GAAP net revenue: |  |  |  |  |  |  |  |  |  |
| Product | $ | 16,688 |  |  | 77.5 | % |  | 22 | % |  | $ | 13,689 |  |  | 74.6 | % |
| Services | 4,855 |  |  | 22.5 | % |  | 4 | % |  | 4,666 |  |  | 25.4 | % |
| Total non-GAAP net revenue | $ | 21,543 |  |  | 100.0 | % |  | 17 | % |  | $ | 18,355 |  |  | 100.0 | % |
| Non-GAAP gross margin: |  |  |  |  |  |  |  |  |  |  |  |
| Product (a) | $ | 3,918 |  |  | 23.5 | % |  | 38 | % |  | $ | 2,831 |  |  | 20.7 | % |
| Services (b) | 3,001 |  |  | 61.8 | % |  | 1 | % |  | 2,970 |  |  | 63.7 | % |
| Total non-GAAP gross margin | $ | 6,919 |  |  | 32.1 | % |  | 19 | % |  | $ | 5,801 |  |  | 31.6 | % |
| Non-GAAP operating expenses | $ | 4,893 |  |  | 22.7 | % |  | 12 | % |  | $ | 4,376 |  |  | 23.8 | % |
| Non-GAAP operating income | $ | 2,026 |  |  | 9.4 | % |  | 42 | % |  | $ | 1,425 |  |  | 7.8 | % |
| Non-GAAP net income | $ | 1,174 |  |  | 5.4 | % |  | 54 | % |  | $ | 761 |  |  | 4.1 | % |
| EBITDA | $ | 1,761 |  |  | 8.2 | % |  | 87 | % |  | $ | 940 |  |  | 5.1 | % |
| Adjusted EBITDA | $ | 2,383 |  |  | 11.1 | % |  | 33 | % |  | $ | 1,795 |  |  | 9.8 | % |

[0001571996-18-000022:mdna:74]
[same as prior period, unchanged from 0001571996-17-000045:mdna:84]

[0001571996-18-000022:mdna:75]
| (a) | Product gross margin percentages represent product gross margin as a percentage of product net revenue, and non-GAAP product gross margin percentages represent non-GAAP product gross margin as a percentage of non-GAAP product net revenue. |

[0001571996-18-000022:mdna:76]
| (b) | Services gross margin percentages represent services gross margin as a percentage of services net revenue, and non-GAAP services gross margin percentages represent non-GAAP services gross margin as a percentage of non-GAAP services net revenue. |

[0001571996-18-000022:mdna:77]
[same as prior period, unchanged from 0001571996-17-000045:mdna:88]

[0001571996-18-000022:mdna:78]
[same as prior period, unchanged from 0001571996-17-000045:mdna:90]

[0001571996-18-000022:mdna:79]
During the first quarter of Fiscal 2019, our net revenue and non-GAAP net revenue increased 19% and 17%, respectively.  The increase in net revenue and non-GAAP net revenue was attributable to an increase in net revenue across all three business units.

[0001571996-18-000022:mdna:80]
Our operating loss decreased 88% to $0.2 billion during the first quarter of Fiscal 2019, primarily due to an increase in operating income for ISG and CSG.  Also benefiting operating loss during the year was a reduction in the impact of amortization of intangible assets and purchase accounting adjustments, which totaled $1.7 billion and $2.2 billion for the first quarters of Fiscal 2019 and Fiscal 2018, respectively.  Excluding these costs, transaction-related expenses, and other corporate expenses, non-GAAP operating income during the first quarter of Fiscal 2019 increased 42% to $2.0 billion, primarily as a result of an increase in operating income for ISG and CSG.

[0001571996-18-000022:mdna:81]
Cash provided by operating activities was $1.2 billion during the first quarter of Fiscal 2019 compared to $0.3 billion for the first quarter of Fiscal 2018.  The increase in operating cash flows during the first quarter of Fiscal 2019 was driven by improved profitability and ongoing working capital management.  See "Market Conditions, Liquidity, and Capital Commitments" for further information on our cash flow metrics.

[0001571996-18-000022:mdna:82]
[same as prior period, unchanged from 0001571996-17-000045:mdna:95]

[0001571996-18-000022:mdna:83]
During the first quarter of Fiscal 2019, our net revenue and non-GAAP net revenue increased 19% and 17%, respectively, due to an increase in net revenue across all three business units.  See "Business Unit Results" for further information.

[0001571996-18-000022:mdna:84]
| • | Product Net Revenue — Product net revenue includes revenue from the sale of hardware products and software licenses. During the first quarter of Fiscal 2019, product net revenue and non-GAAP product net revenue both increased 22%, primarily due an increase in product revenue for ISG and CSG, driven by strength in sales of servers, storage, and notebooks. |

[0001571996-18-000022:mdna:85]
| • | Services Net Revenue — Services net revenue includes revenue from our services offerings and support services related to hardware products and software licenses. During the first quarter of Fiscal 2019, services net revenue and non-GAAP services net revenue increased 7% and 4%, respectively, primarily due to an increase in services revenue for CSG and VMware software maintenance. |

[0001571996-18-000022:mdna:86]
From a geographical perspective, net revenue generated by sales to customers in all regions increased in the first quarter of Fiscal 2019 due to strong performance globally in all three business units.

[0001571996-18-000022:mdna:87]
See "Business Unit Results" for further information regarding revenue from our product and services offerings.

[0001571996-18-000022:mdna:88]
[same as prior period, unchanged from 0001571996-17-000045:mdna:102]

[0001571996-18-000022:mdna:89]
During the first quarter of Fiscal 2019, our gross margin increased 32% to $5.9 billion, and our gross margin percentage increased 270 basis points to 27.5%.  The increase in our gross margin was primarily attributable to higher gross margin across all three business units and, to a lesser extent, a decrease in the combined impact of amortization of intangibles and purchase accounting adjustments.  The increase in our gross margin percentage was primarily attributable to an increase in gross margin percentage in CSG and VMware.

[0001571996-18-000022:mdna:90]
Our gross margin for the first quarters of Fiscal 2019 and Fiscal 2018 included the effect of amortization of intangibles and purchase accounting adjustments of $0.9 billion and $1.3 billion, respectively.  Excluding these costs, transaction-related expenses, and other corporate expenses, total non-GAAP gross margin for the first quarter of Fiscal 2019 increased 19% to $6.9 billion and non-GAAP gross margin percentage increased 50 basis points to 32.1%.  The increase in non-GAAP gross margin

[0001571996-18-000022:mdna:91]
[same as prior period, unchanged from 0001571996-17-000045:mdna:67]

[0001571996-18-000022:mdna:92]
was attributable to increases in gross margin across all three business units.  The increase in our non-GAAP gross margin percentage was primarily due to an increase in gross margin percentage in CSG and VMware.

[0001571996-18-000022:mdna:93]
| • | Products — During the first quarter of Fiscal 2019, product gross margin increased 69% to $3.1 billion, and product gross margin percentage increased 510 basis points to 18.4%. During the first quarter of Fiscal 2019, non-GAAP product gross margin increased 38% to $3.9 billion, and non-GAAP product gross margin percentage increased 280 basis points to 23.5%. These increases in product gross margin and non-GAAP product gross margin were driven primarily by increases in product gross margin in all three business units due to strength in ISG servers and storage, CSG commercial products, and VMware software licenses. Product gross margin percentage and non-GAAP product gross margin percentage increased as a result of increases in product gross margin percentages for ISG and CSG commercial products. |

[0001571996-18-000022:mdna:94]
| • | Services — During the first quarter of Fiscal 2019, services gross margin increased 6% to $2.8 billion, and services gross margin percentage decreased 60 basis points to 60.0%. Services gross margin increased primarily due to a decrease in purchase accounting adjustments, while the combined services gross margin contributed by our business units remained relatively unchanged. Purchase accounting adjustments totaled $0.2 billion during the first quarter of Fiscal 2019, compared to $0.3 billion during the first quarter of Fiscal 2018. Excluding these costs, transaction-related expenses, and other corporate expenses, non-GAAP services gross margin increased 1% to $3.0 billion, and non-GAAP services gross margin percentage decreased 190 basis points to 61.8%. Services gross margin percentage and non-GAAP services gross margin percentage decreased due to decreases in ISG and CSG services gross margin percentages. |

[0001571996-18-000022:mdna:95]
[same as prior period, unchanged from 0001571996-17-000045:mdna:112]

[0001571996-18-000022:mdna:96]
[same as prior period, unchanged from 0001571996-17-000045:mdna:113]

[0001571996-18-000022:mdna:97]
The terms and conditions of our vendor rebate programs are largely based on product volumes and are generally negotiated either at the beginning of the annual or quarterly period, depending on the program.  The timing and amount of vendor rebates and other discounts we receive under the programs may vary from period to period, reflecting changes in the competitive environment.  We monitor our component costs and seek to address the effects of any changes to terms that might arise under our vendor rebate programs.  Our gross margins for the first quarters of Fiscal 2019 and Fiscal 2018 were not materially affected by any changes to the terms of our vendor rebate programs, as the amounts we received under these programs were generally stable relative to our total net cost.  We are not aware of any significant changes to vendor pricing or rebate programs that may impact our results in the near term.

[0001571996-18-000022:mdna:98]
In addition, we have pursued legal action against certain vendors and are currently involved in negotiations with other vendors regarding their past pricing practices.  We have negotiated settlements with some of these vendors and may have additional settlements in future periods.  These settlements are allocated to our segments based on the relative amount of affected vendor products sold by each segment.  No such settlements were recorded in the first quarter of Fiscal 2019 that would have a material impact on product gross margins in the current quarter or affect comparability with product gross margin in the first quarter of Fiscal 2018.

[0001571996-18-000022:mdna:99]
70

[0001571996-18-000022:mdna:100]
[same as prior period, unchanged from 0001571996-17-000045:mdna:116]

[0001571996-18-000022:mdna:101]
[same as prior period, unchanged from 0001571996-17-000045:mdna:117]

[0001571996-18-000022:mdna:102]
|  | Three Months Ended |
|  | May 4, 2018 |  |  |  | May 5, 2017 |
|  | Dollars |  | % ofNet Revenue |  | %Change |  | Dollars |  | % ofNet Revenue |
|  | (in millions, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative | $ | 4,944 |  |  | 23.1 | % |  | 8 | % |  | $ | 4,596 |  |  | 25.6 | % |
| Research and development | 1,087 |  |  | 5.1 | % |  | (4 | )% |  | 1,133 |  |  | 6.3 | % |
| Total operating expenses | $ | 6,031 |  |  | 28.2 | % |  | 5 | % |  | $ | 5,729 |  |  | 31.9 | % |
| Other Financial Information |  |  |  |  |  |  |  |  |  |
| Non-GAAP operating expenses | $ | 4,893 |  |  | 22.7 | % |  | 12 | % |  | $ | 4,376 |  |  | 23.8 | % |

[0001571996-18-000022:mdna:103]
During the first quarter of Fiscal 2019, total operating expenses increased 5%.  Our operating expenses include the impact of purchase accounting, amortization of intangible assets, transaction-related expenses, and other corporate expenses.  In aggregate, these items totaled $1.1 billion and $1.4 billion for the first quarters of Fiscal 2019 and Fiscal 2018, respectively.  Excluding these costs, total non-GAAP operating expenses increased 12%.  The increase in operating expenses and non-GAAP operating expenses was primarily due to an increase in selling, general, and administrative expenses, offset partially by a reduction in research and development expenses.

[0001571996-18-000022:mdna:104]
| • | Selling, General, and Administrative — Selling, general, and administrative ("SG&A") expenses increased 8% during the first quarter of Fiscal 2019. The increases in SG&A expenses were primarily driven by investments in our go-to-market capabilities and higher performance-driven commission costs. |

[0001571996-18-000022:mdna:105]
| • | Research and Development — Research and development ("R&D") expenses are primarily composed of personnel-related expenses related to product development. R&D expenses as a percentage of net revenue for the first quarters of Fiscal 2019 and Fiscal 2018 were approximately 5.1% and 6.3%, respectively. The decrease in R&D expenses as a percentage of net revenue was attributable to revenue growth that outpaced the scale of R&D investments. |

[0001571996-18-000022:mdna:106]
We are starting to see benefits of investments we have made to enable growth, particularly in sales force, marketing, and R&D, while balancing our efforts to drive cost efficiencies in the business.

[0001571996-18-000022:mdna:107]
[same as prior period, unchanged from 0001571996-17-000045:mdna:123]

[0001571996-18-000022:mdna:108]
Our operating loss decreased 88% during the first quarter of Fiscal 2019, primarily due to increases in operating income in ISG and CSG, as well as a decrease in the impact of purchase accounting, amortization of intangible assets, transaction-related expenses, and other corporate expenses.  In aggregate, these items totaled $2.2 billion and $2.7 billion for the first quarters of Fiscal 2019 and Fiscal 2018, respectively.  Excluding these costs, non-GAAP operating income for the first quarter of Fiscal 2019 increased 42% to $2.0 billion, primarily as a result of an increase in operating income for ISG and CSG.

[0001571996-18-000022:mdna:109]
[same as prior period, unchanged from 0001571996-17-000045:mdna:126]

[0001571996-18-000022:mdna:110]
[same as prior period, unchanged from 0001571996-17-000045:mdna:127]

[0001571996-18-000022:mdna:111]
|  | Three Months Ended |
|  | May 4, 2018 |  | May 5, 2017 |
|  | (in millions) |
| Interest and other, net: |  |  |  |  |  |
| Investment income, primarily interest | $ | 78 |  |  | $ | 38 |  |
| Gain (loss) on investments, net | 107 |  |  | (1 | ) |
| Interest expense | (596 | ) |  | (597 | ) |
| Foreign exchange | (77 | ) |  | (27 | ) |
| Other | 18 |  |  | 15 |  |
| Total interest and other, net | $ | (470 | ) |  | $ | (572 | ) |

[0001571996-18-000022:mdna:112]
Effective in the first quarter of Fiscal 2019, in accordance with our recent adoption of the new accounting guidance for "Recognition and Measurement of Financial Assets and Financial Liabilities," changes in the fair value of our publicly-traded strategic investments are recorded in interest and other, net.  During the first quarter of Fiscal 2019, changes in interest and other, net were favorable by $102 million primarily due to an increase in gain (loss) on investments, net due to gains on strategic investments.  See Note 1 and Note 4 of the Notes to the Condensed Consolidated Financial Statements included in this report for further information regarding our recently adopted accounting standards and our investments, respectively.

[0001571996-18-000022:mdna:113]
[same as prior period, unchanged from 0001571996-17-000045:mdna:130]

[0001571996-18-000022:mdna:114]
For the first quarters of Fiscal 2019 and Fiscal 2018, our effective income tax rates were 13.6% and 34.8%, respectively, on pre-tax losses of $0.6 billion and $1.8 billion, respectively.  The change in our effective income tax rates was primarily attributable to impacts of U.S. Tax Reform, partially offset by discrete tax benefits resulting from the impact of adopting the new revenue recognition standard.

[0001571996-18-000022:mdna:115]
The Tax Cuts and Jobs Act of 2017 ("U.S. Tax Reform" or the "Act") was signed into law on December 22, 2017.  U.S. Tax Reform lowers the U.S. corporate income tax rate to 21% from 35%, establishes a modified territorial system requiring a mandatory deemed repatriation tax on undistributed earnings of foreign subsidiaries (the "Transition Tax"), requires a minimum tax on certain future earnings generated by foreign subsidiaries while providing for future tax-free repatriation of earnings through a 100% dividends-received deduction, and places limitations on the deductibility of net interest expense.

[0001571996-18-000022:mdna:116]
GAAP requires the effect of a change in tax laws to be recognized in the period that includes the enactment date.  Accordingly, we recognized a provisional tax benefit in the fourth quarter of Fiscal 2018 of $0.3 billion related to U.S. Tax Reform, primarily driven by a $1.3 billion tax benefit related to the remeasurement of deferred tax assets and liabilities, offset by $1.0 billion of current and future income tax expenses related to the Transition Tax.  Our provisional benefit will be adjusted once the analysis is complete, but no later than the fourth quarter of Fiscal 2019.  We are still collecting and processing the necessary data to complete the analysis.  As a result, no adjustments have been made to the provisional amount recorded in the fourth quarter of Fiscal 2018.  In addition, we expect further guidance to be issued by the U.S Treasury Department that may affect the provisional calculation.  Revisions to our provisional estimates may be material.

[0001571996-18-000022:mdna:117]
Our effective income tax rate can fluctuate depending on the geographic distribution of our world-wide earnings, as our foreign earnings are generally taxed at lower rates than in the United States.  The differences between our effective income tax rate and the U.S. federal statutory rate of 21% principally result from the geographical distribution of income and differences between the book and tax treatment of certain items.  In certain jurisdictions, our tax rate is significantly less than the applicable statutory rate as a result of tax holidays.  The majority of our foreign income that is subject to these tax holidays and lower tax rates is attributable to Singapore, China, and Malaysia.  A significant portion of these income tax benefits is related to a tax holiday that will expire at the end of Fiscal 2019.  We are currently seeking new terms for the affected subsidiary beyond Fiscal 2019 and it is uncertain whether any terms will be agreed upon.  Our other tax holidays will expire in whole or in part during Fiscal 2019 through Fiscal 2023.  Many of these tax holidays and reduced tax rates may be extended when certain conditions are met or may be terminated early if certain conditions are not met.

[0001571996-18-000022:mdna:118]
For further discussion regarding tax matters, see Note 12 of the Notes to the Condensed Consolidated Financial Statements included in this report.

[0001571996-18-000022:mdna:119]
Net Income/Loss

[0001571996-18-000022:mdna:120]
During the first quarter of Fiscal 2019, net loss decreased 55% to $0.5 billion.  The decrease in net loss during the first quarter of Fiscal 2019 was primarily attributable to a decrease in operating loss and, to a lesser extent, a decrease in interest and other, net expense, which was partially offset by a decrease in tax benefit.  Net loss for the first quarter of Fiscal 2019 included amortization of intangible assets, the impact of purchase accounting, transaction-related expenses, and other corporate expenses.  Excluding these costs and the related tax impacts, non-GAAP net income increased 54% to $1.2 billion.  The increase in non-GAAP net income during the first quarter of Fiscal 2019 was primarily attributable to an increase in operating income and a decrease in interest and other, net expense, which was partially offset by an increase in income tax expense.

[0001571996-18-000022:mdna:121]
[same as prior period, unchanged from 0001571996-17-000045:mdna:139]

[0001571996-18-000022:mdna:122]
During the first quarter of Fiscal 2019, net income attributable to non-controlling interests was $98 million compared to a net loss attributable to non-controlling interests of $32 million during the first quarter of Fiscal 2018.  Net income or loss attributable to non-controlling interests consisted of net income or loss attributable to our non-controlling interests in VMware, Inc., Pivotal, and SecureWorks.  For more information about our non-controlling interests, see Note 14 of the Notes to the Condensed Consolidated Financial Statements included in this report.

[0001571996-18-000022:mdna:123]
Net Loss Attributable to Dell Technologies Inc.

[0001571996-18-000022:mdna:124]
Net loss attributable to Dell Technologies Inc. represents net loss and an adjustment for non-controlling interests.  During the first quarters of Fiscal 2019 and Fiscal 2018, net loss attributable to Dell Technologies Inc. was $0.6 billion and $1.2 billion, respectively.  The decrease in net loss attributable to Dell Technologies Inc. during the first quarter of Fiscal 2019 was primarily attributable to a decrease in net loss.

[0001571996-18-000022:mdna:125]
[same as prior period, unchanged from 0001571996-17-000045:mdna:144]

[0001571996-18-000022:mdna:126]
Our reportable segments are based on the following business units: ISG, CSG, and VMware.  A description of our three business units is provided under "Introduction."  See Note 18 of the Notes to the Condensed Consolidated Financial Statements included in this report for a reconciliation of net revenue and operating income by reportable segment to consolidated net revenue and consolidated operating loss, respectively.

[0001571996-18-000022:mdna:127]
During the three months ended May 4, 2018, we made certain segment reporting changes, which included the movement of Virtustream results from ISG to other businesses.  None of these changes impacted our previously reported consolidated financial results, but our prior period segment results have been recast to reflect this change.

[0001571996-18-000022:mdna:128]
[same as prior period, unchanged from 0001571996-17-000045:mdna:153]

[0001571996-18-000022:mdna:129]
[same as prior period, unchanged from 0001571996-17-000045:mdna:154]

[0001571996-18-000022:mdna:130]
|  | Three Months Ended |
|  | May 4, 2018 |  | % Change |  | May 5, 2017 |
|  | (in millions, except percentages) |
| Net Revenue: |  |  |  |  |  |
| Servers and networking | $ | 4,585 |  |  | 41% |  | $ | 3,256 |  |
| Storage | 4,082 |  |  | 10% |  | 3,705 |  |
| Total ISG net revenue | $ | 8,667 |  |  | 25% |  | $ | 6,961 |  |
| Operating Income: |  |  |  |  |  |
| ISG operating income | $ | 939 |  |  | 86% |  | $ | 506 |  |
| % of segment net revenue | 10.8 | % |  |  |  | 7.3 | % |

[0001571996-18-000022:mdna:131]
Net Revenue — During the first quarter of Fiscal 2019, ISG net revenue increased 25% primarily due to an increase in servers and networking and to a lesser extent, an increase in storage.  Revenue from servers and networking increased 41% during the first quarter of Fiscal 2019, driven by an increase in both average selling price and units sold of our PowerEdge servers.  Average selling prices increased due to sale of servers with higher memory and storage content, which is driven by customer demand for servers that enable big data analytics and software-defined solutions.  Storage revenue increased 10% during the first quarter of Fiscal 2019 due to accumulated demand from the fourth quarter of Fiscal 2018 that was realized in the current quarter, as well as strong growth in hyper-converged infrastructure products.  We were encouraged by the improved demand in commercial mid-range storage, where we have been making go-to-market investments and enhancements to our solutions offerings.  While component costs were slightly deflationary in the aggregate for ISG, we continue to monitor our pricing in response to the current component cost environment.  We expect dynamic random access memory ("DRAM") component costs for servers to remain a headwind through the remainder of Fiscal 2019.

[0001571996-18-000022:mdna:132]
In ISG, we continue to see interest in flexible consumption models by our customers as they seek to build greater flexibility into their cost structures.  We generally provide these solutions under multi-year contracts that typically result in recognition of revenue over the term of the arrangement.  We expect these flexible consumption models will further strengthen our customer relationships, and will build more predictable revenue streams over time.

[0001571996-18-000022:mdna:133]
From a geographical perspective, net revenue attributable to ISG increased across all regions during the first quarter of Fiscal 2019.

[0001571996-18-000022:mdna:134]
Operating Income — During the first quarter of Fiscal 2019, ISG operating income increased 350 basis points to 10.8% primarily due to a decrease in operating expenses as a percentage of revenue.  Despite the investments we have been making in our go-to-market capabilities and solutions offerings, operating expenses decreased as a percentage of revenue as a result of revenue growth that outpaced the scale of these investments.

[0001571996-18-000022:mdna:135]
[same as prior period, unchanged from 0001571996-17-000045:mdna:146]

[0001571996-18-000022:mdna:136]
[same as prior period, unchanged from 0001571996-17-000045:mdna:147]

[0001571996-18-000022:mdna:137]
|  | Three Months Ended |
|  | May 4, 2018 |  | % Change |  | May 5, 2017 |
|  | (in millions, except percentages) |
| Net Revenue: |  |  |  |  |  |
| Commercial | $ | 7,363 |  |  | 16% |  | $ | 6,342 |  |
| Consumer | 2,908 |  |  | 7% |  | 2,706 |  |
| Total CSG net revenue | $ | 10,271 |  |  | 14% |  | $ | 9,048 |  |
| Operating Income: |  |  |  |  |  |
| CSG operating income | $ | 533 |  |  | 64% |  | $ | 325 |  |
| % of segment net revenue | 5.2 | % |  |  |  | 3.6 | % |

[0001571996-18-000022:mdna:138]
Net Revenue — During the first quarter of Fiscal 2019, CSG net revenue increased 14%, primarily driven by an increase in the volume of commercial notebooks, workstations, and desktops sold as we were able to deliver strong performance in a better than expected demand environment.  Consumer demand was relatively unchanged over the period as we navigated through a declining demand environment.  The overall average selling price increased in both the commercial and consumer product categories, as we managed our pricing in response to the inflationary cost environment over the past year.  We expect the cost environment for CSG to be deflationary for the remainder of Fiscal 2019.

[0001571996-18-000022:mdna:139]
From a geographical perspective, net revenue attributable to CSG increased across all regions during Fiscal 2019.

[0001571996-18-000022:mdna:140]
Operating Income — During the first quarter of Fiscal 2019, CSG operating income as a percentage of net revenue increased 160 basis points to 5.2% primarily due to an increase in CSG gross margin as a percentage of net revenue.  CSG gross margin as a percentage of net revenue benefited from a higher mix of commercial units sold as well as strong attach rates on higher-margin services, software, and peripherals.  These benefits were partially offset by increased operating expenses as a percentage of net revenue as a result of higher performance-driven commission costs and marketing expense.

[0001571996-18-000022:mdna:141]
75

[0001571996-18-000022:mdna:142]
[same as prior period, unchanged from 0001571996-17-000045:mdna:162]

[0001571996-18-000022:mdna:143]
[same as prior period, unchanged from 0001571996-17-000045:mdna:163]

[0001571996-18-000022:mdna:144]
|  | Three Months Ended |
|  | May 4, 2018 |  | % Change |  | May 5, 2017 |
|  | (in millions, except percentages) |
| Net Revenue: |  |  |  |  |  |
| VMware net revenue | $ | 2,028 |  |  | 12% |  | $ | 1,818 |  |
| Operating Income: |  |  |  |  |  |
| VMware operating income | $ | 613 |  |  | —% |  | $ | 611 |  |
| % of segment net revenue | 30.2 | % |  |  |  | 33.6 | % |

[0001571996-18-000022:mdna:145]
Net Revenue — VMware net revenue primarily consisted of revenue from the sale of software licenses under perpetual licenses, related software maintenance and support, training, consulting services, and hosted services.  VMware net revenue during the first quarter of Fiscal 2019 increased 12% due to growth in software license revenue, maintenance services, and professional services.  Software license revenue benefited from broad-based growth across the product portfolio.  Software maintenance revenue benefited from strong renewals, revenue recognized from maintenance contracts sold in prior periods, and new maintenance contracts sold during the period.

[0001571996-18-000022:mdna:146]
From a geographical perspective, approximately half of VMware net revenue during the first quarter of Fiscal 2019 was generated by sales to customers in the United States.  VMware net revenue for the first quarter of Fiscal 2019 benefited from growth in all major geographies.

[0001571996-18-000022:mdna:147]
Operating Income — During the first quarter of Fiscal 2019, VMware operating income as a percentage of net revenue decreased 340 basis points to 30.2%, primarily driven by an increase in operating expenses as a percentage of revenue due to an increase in compensation-related expense associated with sales and sales support, resulting from increased performance-driven commission costs and headcount.

[0001571996-18-000022:mdna:148]
See Exhibit 99.1 filed with this report for information on the differences between VMware reportable segment results and VMware, Inc. results.

[0001571996-18-000022:mdna:149]
[same as prior period, unchanged from 0001571996-17-000045:mdna:169]

[0001571996-18-000022:mdna:150]
[same as prior period, unchanged from 0001571996-17-000045:mdna:170]

[0001571996-18-000022:mdna:151]
We sell products and services directly to customers and through a variety of sales channels, including retail distribution.  Our accounts receivable, net, was $10.6 billion and $11.7 billion as of May 4, 2018 and February 2, 2018, respectively.  We maintain an allowance for doubtful accounts to cover receivables that may be deemed uncollectible.  The allowance for losses is based on a provision for accounts that are collectively evaluated based on historical bad debt experience as well as specific identifiable customer accounts that are deemed at risk.  As of May 4, 2018 and February 2, 2018, the allowance for doubtful accounts was $109 million and $103 million, respectively.  Based on our assessment, we believe that we are adequately reserved for expected credit losses.  We monitor the aging of our accounts receivable and continue to take actions to reduce our exposure to credit losses.

[0001571996-18-000022:mdna:152]
[same as prior period, unchanged from 0001571996-17-000045:mdna:172]

[0001571996-18-000022:mdna:153]
Dell Financial Services and its affiliates ("DFS") offers a wide range of financial services, including originating, collecting, and servicing customer receivables primarily related to the purchase of Dell Technologies' products and services.  In some cases, we also offer financing on the purchase of third-party technology products that complement our portfolio of products and services.  New financing originations were $1.7 billion and $1.1 billion for the first quarters of Fiscal 2019 and Fiscal 2018, respectively.  As of May 4, 2018 and February 2, 2018, our financing receivables, net were $7.8 billion and $7.6 billion, respectively.  The increases in new financing originations and financing receivables during the first quarter of Fiscal 2019 were attributable to growth in DFS offerings related to customer purchases of products and services from the EMC acquired businesses.

[0001571996-18-000022:mdna:154]
We have securitization facilities to fund revolving loans and fixed-term leases and loans through consolidated special purpose entities, referred to as SPEs, which we account for as secured borrowings.  We transfer certain U.S. and European customer financing receivables to these SPEs, whose purpose is to facilitate the funding of customer receivables through financing arrangements with multi-seller conduits that issue asset-backed debt securities in the capital markets and to private investors.  During the first quarters of Fiscal 2019 and Fiscal 2018, we transferred $1.3 billion and $0.9 billion, respectively, to these SPEs.  The DFS debt related to all of our securitization facilities included as secured borrowings was $4.4 billion and $3.9 billion as of May 4, 2018 and February 2, 2018, respectively.  In addition, the carrying amount of the corresponding financing receivables was $5.0 billion and $4.6 billion as of May 4, 2018 and February 2, 2018, respectively.  As a result of the EMC merger transaction, we are expanding our existing securitization facilities to allow for additional funding of customer receivables in the capital markets.

[0001571996-18-000022:mdna:155]
We maintain an allowance to cover expected financing receivable credit losses and evaluate credit loss expectations based on our total portfolio.  For the first quarters of Fiscal 2019 and Fiscal 2018, the principal charge-off rate for our total portfolio was 1.2% and 1.8%, respectively.  The credit quality of our financing receivables has improved in recent years due to an overall improvement in the credit environment and as the mix of high-quality commercial accounts in our portfolio has increased.  The allowance for losses is determined based on various factors, including historical and anticipated experience, past due receivables, receivable type, and customer risk profile.  As of May 4, 2018 and February 2, 2018, the allowance for financing receivable losses was $139 million and $145 million, respectively.  In general, the loss rates on our financing receivables have improved over the periods presented.  We expect relatively stable loss rates in future periods, with movements in these rates being primarily driven by seasonality and a continued shift in portfolio composition to lower risk commercial assets.  We continue to monitor broader economic indicators and their potential impact on future loss performance.  We have an extensive process to manage our exposure to customer credit risk, including active management of credit lines and our collection activities.  We also sell selected fixed-term financing receivables to unrelated third parties on a periodic basis, primarily to manage certain concentrations of customer credit exposure.  Based on our assessment of the customer financing receivables, we believe that we are adequately reserved.

[0001571996-18-000022:mdna:156]
See Note 5 of the Notes to the Condensed Consolidated Financial Statements included in this report for additional information about our financing receivables and the associated allowances.

[0001571996-18-000022:mdna:157]
[same as prior period, unchanged from 0001571996-17-000045:mdna:180]

[0001571996-18-000022:mdna:158]
As of May 4, 2018, we had no off-balance sheet arrangements that have or are reasonably likely to have a current or future material effect on our financial condition or results of operations.

[0001571996-18-000022:mdna:159]
[same as prior period, unchanged from 0001571996-17-000045:mdna:183]

[0001571996-18-000022:mdna:160]
[same as prior period, unchanged from 0001571996-17-000045:mdna:184]

[0001571996-18-000022:mdna:161]
[same as prior period, unchanged from 0001571996-17-000045:mdna:185]

[0001571996-18-000022:mdna:162]
[same as prior period, unchanged from 0001571996-17-000045:mdna:186]

[0001571996-18-000022:mdna:163]
We use derivative instruments to hedge certain foreign currency exposures.  We use forward contracts and purchased options designated as cash flow hedges to protect against the foreign currency exchange rate risks inherent in our forecasted transactions denominated in currencies other than the U.S. dollar.  In addition, we primarily use forward contracts and may use purchased options to hedge monetary assets and liabilities denominated in a foreign currency.  See Note 7 of the Notes to the Condensed Consolidated Financial Statements included in this report for more information about our use of derivative instruments.

[0001571996-18-000022:mdna:164]
[same as prior period, unchanged from 0001571996-17-000045:mdna:188]

[0001571996-18-000022:mdna:165]
[same as prior period, unchanged from 0001571996-17-000045:mdna:189]

[0001571996-18-000022:mdna:166]
[same as prior period, unchanged from 0001571996-17-000045:mdna:190]

[0001571996-18-000022:mdna:167]
To support our ongoing business operations, we rely on operating cash flows as our primary source of liquidity.  We monitor the efficiency of our balance sheet to ensure that we have adequate liquidity to support our strategic initiatives.  In addition to internally generated cash, we have access to other capital sources to finance our strategic initiatives and fund growth in our financing operations.  As of May 4, 2018, we had $15.3 billion of total cash and cash equivalents, approximately half of which was held outside of the United States.  Our strategy is to deploy capital from any potential source, whether internally generated cash or debt, depending on the adequacy and availability of that source of capital and whether it can be accessed in a cost-effective manner.

[0001571996-18-000022:mdna:168]
A significant portion of our income is earned in non-U.S. jurisdictions.  Prior to the enactment of U.S. Tax Reform as discussed above, earnings available to be repatriated to the United States would be subject to U.S. federal income tax, less applicable foreign tax credits.  U.S. Tax Reform fundamentally changes the U.S. approach to taxation of foreign earnings to a modified territorial tax system, which generally allows companies to make distributions of non-U.S. earnings to the United States without incurring additional U.S. federal tax.  However, local and U.S. state taxes may still apply.  We have provided for future tax liabilities on income earned in non-U.S. jurisdictions, except for foreign earnings that are considered indefinitely reinvested outside of the United States.

[0001571996-18-000022:mdna:169]
[same as prior period, unchanged from 0001571996-17-000045:mdna:143]

[0001571996-18-000022:mdna:170]
The following table summarizes our cash and cash equivalents as well as our available borrowings as of May 4, 2018 and February 2, 2018:

[0001571996-18-000022:mdna:171]
|  | May 4, 2018 |  | February 2, 2018 |
|  | (in millions) |
| Cash and cash equivalents, and available borrowings: |  |  |  |
| Cash and cash equivalents (a) | $ | 15,324 |  |  | $ | 13,942 |  |
| Remaining available borrowings under revolving credit facilities | 4,909 |  |  | 4,875 |  |
| Total cash, cash equivalents, and available borrowings | $ | 20,233 |  |  | $ | 18,817 |  |

[0001571996-18-000022:mdna:172]
[same as prior period, unchanged from 0001571996-17-000045:mdna:196]

[0001571996-18-000022:mdna:173]
(a)  Of the $15.3 billion of cash and cash equivalents as of May 4, 2018, $7.1 billion was held by VMware, Inc.

[0001571996-18-000022:mdna:174]
Our revolving credit facilities include the Revolving Credit Facility and the China Revolving Credit Facility.  Available borrowings under these facilities are reduced by draws on the facility and, under the Revolving Credit Facility, outstanding letters of credit.  As of May 4, 2018, there were no borrowings outstanding under either facility and remaining available borrowings totaled approximately $3.8 billion.  After the end of the current quarter, on May 24, 2018, we drew down $500 million under the China Revolving Credit Facility.  Available borrowings may be used periodically for general corporate purposes.

[0001571996-18-000022:mdna:175]
The VMware Revolving Credit Facility and the Pivotal Revolving Credit Facility have maximum aggregate borrowings of $1.0 billion and $100 million, respectively.  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and general corporate purposes of VMware, Inc., Pivotal, and their respective subsidiaries.  As of May 4, 2018, $1.0 billion was available under the VMware Revolving Credit Facility and $100 million was available under the Pivotal Revolving Credit Facility.

[0001571996-18-000022:mdna:176]
See Note 6 of the Notes to the Condensed Consolidated Financial Statements included in this report for additional information about each of the foregoing revolving credit facilities.

[0001571996-18-000022:mdna:177]
We believe that our current cash and cash equivalents, along with cash that will be provided by future operations and borrowings expected to be available under the Revolving Credit Facility and China Revolving Credit Facility, will be sufficient over at least the next twelve months to fund our operations, capital expenditures, share repurchases, debt service requirements, and other corporate needs.

[0001571996-18-000022:mdna:178]
[same as prior period, unchanged from 0001571996-17-000045:mdna:202]

[0001571996-18-000022:mdna:179]
The following table summarizes our outstanding debt as of May 4, 2018 and February 2, 2018:

[0001571996-18-000022:mdna:180]
|  | May 4, 2018 |  | February 2, 2018 |
|  | (in millions) |
| Restricted Subsidiary Debt |  |  |  |
| Core debt: |  |  |  |
| Senior Secured Credit Facilities and First Lien Notes | $ | 30,527 |  |  | $ | 30,595 |  |
| Unsecured Notes and Debentures | 1,952 |  |  | 2,452 |  |
| Senior Notes | 3,250 |  |  | 3,250 |  |
| EMC Notes | 5,500 |  |  | 5,500 |  |
| DFS allocated debt | (1,432 | ) |  | (1,892 | ) |
| Total core debt | 39,797 |  |  | 39,905 |  |
| DFS related debt: |  |  |  |
| DFS debt | 5,359 |  |  | 4,796 |  |
| DFS allocated debt | 1,432 |  |  | 1,892 |  |
| Total DFS related debt | 6,791 |  |  | 6,688 |  |
| Other | 2,072 |  |  | 2,054 |  |
| Unrestricted Subsidiary Debt |  |  |  |
| VMware Notes | 4,000 |  |  | 4,000 |  |
| Other | 27 |  |  | 47 |  |
| Total unrestricted subsidiary debt | 4,027 |  |  | 4,047 |  |
| Total debt, principal amount | 52,687 |  |  | 52,694 |  |
| Carrying value adjustments | (784 | ) |  | (823 | ) |
| Total debt, carrying value | $ | 51,903 |  |  | $ | 51,871 |  |

[0001571996-18-000022:mdna:181]
The outstanding principal amount of our debt was $52.7 billion as of May 4, 2018, which included core debt of $39.8 billion.  We define core debt as the total principal amount of our debt, less DFS related debt, other debt, and unrestricted subsidiary debt.

[0001571996-18-000022:mdna:182]
DFS related debt primarily represents debt from securitization and structured financing programs.  To fund expansion of the DFS business, we balance the use of our securitization and structure financing programs with other sources of liquidity.  We approximate the amount of our debt used to fund the DFS business by applying a 7:1 debt to equity ratio to our financing receivables balance, based on the underlying credit quality of the assets.  See Note 5 of the Notes to the Condensed Consolidated Financial Statements included in this report for more information about our DFS debt.

[0001571996-18-000022:mdna:183]
As of May 4, 2018 and February 2, 2018, other debt primarily consisted of the $2.0 billion Margin Loan Facility.

[0001571996-18-000022:mdna:184]
VMware, Inc., Pivotal, and their respective subsidiaries are unrestricted subsidiaries for purposes of the existing debt of Dell Technologies.  Neither Dell Technologies nor any of its subsidiaries, other than VMware, Inc., is obligated to make payment on the VMware Notes.  None of the net proceeds of the VMware Notes will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and its subsidiaries.

[0001571996-18-000022:mdna:185]
Our requirements for cash to pay principal and interest have increased significantly due to the borrowings that were required to finance the EMC merger transaction.  We or our affiliates, at our or their sole discretion, may purchase, redeem, prepay, refinance, or otherwise retire any amount of our outstanding indebtedness under the terms of such indebtedness at any time and from time to time, in open market or negotiated transactions with the holders of such indebtedness, as appropriate market conditions exist.

[0001571996-18-000022:mdna:186]
During the first quarter of Fiscal 2019, we repaid approximately $500 million principal amount of our 5.65% unsecured notes due April 2018 and $68 million principal amount of our term loan facilities.  Further, we issued an additional $611 million, net, in DFS debt to support the expansion of our financing receivables portfolio.  After the end of the current quarter, on June 1, 2018, we fully repaid the 1.875% EMC Note in the amount of $2.5 billion in accordance with the contractual maturity date.

[0001571996-18-000022:mdna:187]
See Note 6 of the Notes to the Condensed Consolidated Financial Statements included in this report for more information about our debt and our unrestricted subsidiaries.

[0001571996-18-000022:mdna:188]
[same as prior period, unchanged from 0001571996-17-000045:mdna:215]

[0001571996-18-000022:mdna:189]
The following table contains a summary of our Consolidated Statements of Cash Flows for the respective periods:

[0001571996-18-000022:mdna:190]
|  | Three Months Ended |
|  | May 4, 2018 |  | May 5, 2017 |
|  | (in millions) |
| Net change in cash from: |  |  |  |
| Operating activities | $ | 1,159 |  |  | $ | 285 |  |
| Investing activities | (149 | ) |  | 51 |  |
| Financing activities | 543 |  |  | (187 | ) |
| Effect of exchange rate changes on cash and cash equivalents | (86 | ) |  | (6 | ) |
| Change in cash and cash equivalents | $ | 1,467 |  |  | $ | 143 |  |

[0001571996-18-000022:mdna:191]
Operating Activities — Cash provided by operating activities was $1,159 million for the first quarter of Fiscal 2019 compared to $285 million for the first quarter of Fiscal 2018.  The increase in operating cash flows during the first quarter of Fiscal 2019 was driven by improved profitability and strong working capital management, partially offset by our annual incentive bonus payouts.

[0001571996-18-000022:mdna:192]
Investing Activities — Investing activities primarily consist of cash used to fund strategic investments, the maturities, sales, and purchases of investments, capital expenditures for property, plant, and equipment, and capitalized software development costs.  During the first quarter of Fiscal 2019, cash used by investing activities was $149 million and was primarily driven by capital expenditures partially offset by net cash proceeds from the divestitures of businesses and by the net sales of investments.  In comparison, cash provided by investing activities was $51 million during the first quarter of Fiscal 2018 and was primarily driven by the net sales of investments.

[0001571996-18-000022:mdna:193]
Financing Activities — Financing activities primarily consist of the proceeds and repayments of debt, cash used to repurchase common stock, and proceeds from the issuance of common stock of subsidiaries.  Cash provided by financing activities of $543 million during the first quarter of Fiscal 2019 was primarily driven by proceeds from the issuance of Pivotal common stock in connection with Pivotal's IPO.  In comparison, cash used by financing activities of $187 million during the first quarter of Fiscal 2018 and was primarily driven by cash used for share repurchases.

[0001571996-18-000022:mdna:194]
[same as prior period, unchanged from 0001571996-17-000045:mdna:238]

[0001571996-18-000022:mdna:195]
Capital Expenditures — During the first quarters of Fiscal 2019 and Fiscal 2018, we spent $0.3 billion and $0.2 billion, respectively, on property, plant, and equipment.  These expenditures were primarily incurred in connection with our global expansion efforts and infrastructure investments made to support future growth.  Product demand, product mix, and the use of contract manufacturers, as well as ongoing investments in operating and information technology infrastructure, influence the level and prioritization of our capital expenditures.  Aggregate capital expenditures for Fiscal 2019, which will be primarily related to infrastructure investments and strategic initiatives, are currently expected to total between $1.1 billion and $1.3 billion.

[0001571996-18-000022:mdna:196]
[same as prior period, unchanged from 0001571996-17-000045:mdna:248]

[0001571996-18-000022:mdna:197]
We utilize several suppliers to manufacture sub-assemblies for our products.  Our efficient supply chain management allows us to enter into flexible and mutually beneficial purchase arrangements with our suppliers in order to minimize inventory risk.  Consistent with industry practice, we acquire raw materials or other goods and services, including product components, by issuing to suppliers authorizations to purchase based on our projected demand and manufacturing needs.  These purchase orders are typically fulfilled within 30 days and are entered into during the ordinary course of business in order to establish best pricing and continuity of supply for our production.

[0001571996-18-000022:mdna:198]
[same as prior period, unchanged from 0001571996-17-000045:mdna:240]

[0001571996-18-000022:mdna:199]
Class V Common Stock Repurchases by Dell Technologies Inc.

[0001571996-18-000022:mdna:200]
Since the date of the EMC merger transaction, the board of directors authorized several programs to repurchase shares of our Class V Common Stock.  Of the $2.1 billion total authorized, $676 million remains as of May 4, 2018, all of which is attributable to the DHI Group Repurchase Program, which our board of directors suspended on December 13, 2016 until such time as the board of directors authorizes the reinstatement of that program.

[0001571996-18-000022:mdna:201]
During the first quarter of Fiscal 2019, we did not repurchase any shares of Class V Common Stock.  During the first quarter of Fiscal 2018, we repurchased 5.5 million shares for an aggregate purchase price of $359 million.  The repurchase of these shares was funded by proceeds received by the Class V Group from the sale by a subsidiary of the Company of shares of Class A common stock of VMware, Inc. owned by such subsidiary, as discussed below.

[0001571996-18-000022:mdna:202]
DHI Group Common Stock Repurchases by Dell Technologies Inc.

[0001571996-18-000022:mdna:203]
During the first quarters of Fiscal 2019 and Fiscal 2018, we repurchased an immaterial number of shares of DHI Group Common Stock for approximately $37 million and $2 million, respectively.

[0001571996-18-000022:mdna:204]
VMware, Inc. Class A Common Stock Repurchases by VMware, Inc.

[0001571996-18-000022:mdna:205]
Since the date of the EMC merger transaction, VMware Inc.'s board of directors has authorized the repurchase of a total of $2.2 billion of VMware Inc.'s Class A Common Stock, of which $876 million remains as of May 4, 2018.

[0001571996-18-000022:mdna:206]
During the first quarter of Fiscal 2019, VMware, Inc. did not repurchase any shares of its Class A Common Stock.  During the first quarter of Fiscal 2018, pursuant to stock repurchase agreements between Dell Technologies Inc. and VMware, Inc., VMware, Inc. repurchased 4.8 million shares of its Class A Common Stock from us for an aggregate purchase price of $425 million.  VMware, Inc. received 4.1 million shares of its Class A common stock during the first quarter of Fiscal 2018 and the remaining 0.7 million shares thereafter.  The proceeds from the sales were used to repurchase shares of our Class V Common Stock as described above.  VMware Inc. made no repurchases of its Class A Common Stock in the open market during the first quarter of Fiscal 2018.
