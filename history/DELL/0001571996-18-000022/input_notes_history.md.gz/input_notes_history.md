# DELL note change history — 0001571996-17-000045 → 0001571996-18-000022


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2018-06-12):
[0001571996-18-000022:note_history:1]
Appraisal Proceedings — On October 29, 2013, Dell Technologies acquired Dell in a transaction referred to as the going-private transaction.  Holders of shares of Dell common stock who did not vote on September 12, 2013 in favor of the proposal to adopt the amended going-private transaction agreement and who properly demanded appraisal of their shares and who otherwise comply with the requirements of Section 262 of the Delaware General Corporate Law ("DGCL") are entitled to seek appraisal for, and obtain payment in cash for the judicially determined "fair value" (as defined pursuant to Section 262 of the DGCL) of, their shares in lieu of receiving the going-private transaction consideration.  Dell initially recorded a liability of $13.75 for each share with respect to which appraisal has been demanded and as to which the demand has not been withdrawn, together with interest at the statutory rate discussed below.  The Court of Chancery ruled that the fair value of the appraisal shares as of October 29, 2013, the date on which the going-private transaction became effective, was $17.62 per share.  This ruling would entitle the holders of the remaining 5,505,630 shares subject to the appraisal proceedings to $17.62 per share, plus interest at a statutory rate, compounded quarterly.  On November 21, 2016, the Court of Chancery entered final judgment in the appraisal action.  On November 22, 2016, Dell filed a notice of appeal to the Delaware Supreme Court, which issued a decision on December 14, 2017.  In its decision, the Delaware Supreme Court reversed, in part, and affirmed, in part, the decision of the Delaware Court of Chancery.  On January 2, 2018, the Delaware Supreme Court issued its formal mandate remanding the matter to the Court of Chancery for further proceedings consistent with its opinion.  In accordance with direction by the Court of Chancery, the parties have submitted proposals to the Court of Chancery outlining the remaining issues to be adjudicated.  The liability for the appraisal proceedings was approximately $108 million and $129 million as of May 4, 2018 and February 2, 2018, respectively.  The Company believes it was adequately reserved for the appraisal proceedings as of May 4, 2018.  On May 8, 2018, the Company entered into an agreement to settle a portion of the liability related to the appraisal proceedings in the amount of approximately $70 million, and on May 18, 2018 this portion of the liability was fully paid.
  (was, 2017-12-12, similarity 0.7011):
[0001571996-17-000045:note_history:1]
Appraisal Proceedings — On October 29, 2013, Dell Technologies acquired Dell in a transaction referred to as the going-private transaction.  Holders of shares of Dell common stock who did not vote on September 12, 2013 in favor of the proposal to adopt the amended going-private transaction agreement and who properly demanded appraisal of their shares and who otherwise comply with the requirements of Section 262 of the Delaware General Corporate Law ("DGCL") are entitled to seek appraisal for, and obtain payment in cash for the judicially determined "fair value" (as defined pursuant to Section 262 of the DGCL) of, their shares in lieu of receiving the going-private transaction consideration.  Dell initially recorded a liability of $13.75 for each share with respect to which appraisal has been demanded and as to which the demand has not been withdrawn, together with interest at the statutory rate discussed below.  This liability was approximately $129 million as of both November 3, 2017 and February 3, 2017.  The Court of Chancery ruled that the fair value of the appraisal shares as of October 29, 2013, the date on which the going-private transaction became effective, was $17.62 per share.  This ruling would entitle the holders of the remaining 5,505,730 shares subject to the appraisal proceedings to $17.62 per share, plus interest at a statutory rate, compounded quarterly.  On November 21, 2016, the Court of Chancery entered final judgment in the appraisal action.  On November 22, 2016, Dell filed a notice of appeal to the Delaware Supreme Court, and a hearing was held on that appeal on September 27, 2017.  A ruling on the appeal is pending.  The Company believes it was adequately reserved for the appraisal proceedings as of November 3, 2017.

- changed (2018-06-12):
[0001571996-18-000022:note_history:2]
As of May 4, 2018, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for these or other proceedings or matters has been incurred.  However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company's business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters.  Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company's business, financial condition, results of operations, or cash flows will depend on a number of variables, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.
  (was, 2017-12-12, similarity 0.9941):
[0001571996-17-000045:note_history:2]
As of November 3, 2017, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for these or other proceedings or matters has been incurred.  However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company's business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters.  Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company's business, financial condition, results of operations, or cash flows will depend on a number of variables, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.

- removed (2018-06-12):
[0001571996-17-000045:note_history:3]
EMC Merger Litigation — The Company, Dell, and Universal Acquisition Co. ("Universal") were named as defendants in fifteen putative class-action lawsuits brought by purported EMC shareholders and VMware, Inc. stockholders challenging the proposed merger between the Company, Dell, and Universal on the one hand, and EMC on the other (the "EMC merger").  Those suits are captioned as follows:

- removed (2018-06-12):
[0001571996-17-000045:note_history:4]
| Case | Court | Filing Date |
| 1. | IBEW Local No. 129 Benefit Fund v. Tucci,Civ. No. 1584-3130-BLS1 | Mass. Superior Court, Suffolk County | 10/15/2015 |
| 2. | Barrett v. Tucci,Civ. No. 15-6023-A | Mass. Superior Court, Middlesex County | 10/16/2015 |
| 3. | Graulich v. Tucci,Civ. No. 1584-3169-BLS1 | Mass. Superior Court, Suffolk County | 10/19/2015 |
| 4. | Vassallo v. EMC Corp.,Civ. No. 1584-3173-BLS1 | Mass. Superior Court, Suffolk County | 10/19/2015 |
| 5. | City of Miami Police Relief & Pension Fund v. Tucci,Civ. No. 1584-3174-BLS1 | Mass. Superior Court, Suffolk County | 10/19/2015 |
| 6. | Lasker v. EMC Corp.,Civ. No. 1584-3214-BLS1 | Mass. Superior Court, Suffolk County | 10/23/2015 |
| 7. | Walsh v. EMC Corp.,Civ. No. 15-13654 | U.S. District Court,District of Massachusetts | 10/27/2015 |
| 8. | Local Union No. 373 U.A. Pension Plan v. EMC Corp.,Civ. No. 1584-3253-BLS1 | Mass. Superior Court, Suffolk County | 10/28/2015 |
| 9. | City of Lakeland Emps.' Pension & Ret. Fund v. Tucci,Civ. No. 1584-3269-BLS1 | Mass. Superior Court, Suffolk County | 10/28/2015 |
| 10. | Ma v. Tucci,Civ. No. 1584-3281-BLS1 | Mass. Superior Court, Suffolk County | 10/29/2015 |
| 11. | Stull v. EMC Corp.,Civ. No. 15-13692 | U.S. District Court,District of Massachusetts | 10/30/2015 |
| 12. | Jacobs v. EMC Corp.,Civ. No. 15-6318-H | Mass. Superior Court, Middlesex County | 11/12/2015 |
| 13. | Ford v. VMware, Inc.,C.A. No. 11714-VCL | Delaware Chancery Court | 11/17/2015 |
| 14. | Pancake v. EMC Corp.,Civ. No. 16-10040 | U.S. District Court,District of Massachusetts | 1/11/2016 |
| 15. | Booth Family Trust v. EMC Corp.,Civ. No. 16-10114 | U.S. District Court,District of Massachusetts | 1/26/2016 |

- removed (2018-06-12):
[0001571996-17-000045:note_history:5]
The fifteen lawsuits sought, among other things, injunctive relief enjoining the EMC merger, rescission of the EMC merger if consummated, an award of fees and costs, and/or an award of damages.

- removed (2018-06-12):
[0001571996-17-000045:note_history:6]
The complaints in the IBEW, Barrett, Graulich, Vassallo, City of Miami, Lasker, Local Union No. 373, City of Lakeland, and Ma actions generally allege that the EMC directors breached their fiduciary duties to EMC shareholders in connection with the EMC merger by, among other things, failing to maximize shareholder value and agreeing to provisions in the EMC merger agreement that discouraged competing bids.  After consolidating the fifteen complaints, by decision dated December 7, 2015, the Business Litigation Session of the Suffolk County Superior Court in Massachusetts dismissed all nine complaints for failure to make a demand on the EMC board of directors.  Three of the nine plaintiffs in the consolidated actions appealed the judgment dismissing their complaints.  The Massachusetts Supreme Judicial Court granted an application for direct appellate review, and heard oral argument on the appeal on November 7, 2016.  On March 6, 2017, the Supreme Judicial Court issued a decision affirming the dismissal.  This decision terminated the consolidated actions.

- removed (2018-06-12):
[0001571996-17-000045:note_history:7]
The complaints in the Walsh, Stull, Pancake, and Booth actions allege that the EMC directors breached their fiduciary duties to EMC shareholders in connection with the EMC merger by, among other things, failing to maximize shareholder value and agreeing to provisions in the EMC merger agreement that discouraged competing bids.  The complaints generally further allege that the preliminary registration statement on Form S-4 filed by the Company on December 14, 2015, in connection with the transaction contained material misstatements and omissions, in violation of Section 14(a) of the Securities Exchange Act of 1934 (the "Exchange Act") and SEC Rule 14a-9 promulgated thereunder and that the Company, Dell, and Universal acted as controlling persons of EMC under Section 20(a) of the Exchange Act.  On June 6, 2016, the Securities and Exchange Commission declared effective the Company's registration statement on Form S-4 relating to the EMC merger (the "SEC Form S-4"), including the amendments thereto.  On June 17, 2016, the parties to the Walsh, Stull, Pancake, and Booth actions submitted to the Court a Stipulation and Proposed Order Dismissing Action and Retaining Jurisdiction to Determine Plaintiffs' Counsel's Application for an Award of Attorneys' Fees and Reimbursement of Expenses.  In the stipulation, the plaintiffs represented to the Court that they believe sufficient information had been disclosed to warrant dismissal of the actions as moot in light of the disclosures in the SEC Form S-4, including the amendments thereto.  On October 25, 2016, following an agreement between the parties with respect to payment of attorneys' fees and expenses, the Court entered an order terminating the four actions for all purposes.

- removed (2018-06-12):
[0001571996-17-000045:note_history:8]
The amended complaints in the Jacobs and Ford actions allege that EMC, as the majority stockholder of VMware, Inc., and the individual defendants, who were directors of EMC, VMware, Inc., or both, breached their fiduciary duties to minority stockholders of VMware, Inc. in connection with the proposed EMC merger by allegedly entering into or approving a merger that favors the interests of EMC and Dell at the expense of the minority stockholders.  The plaintiffs in the Jacobs action also brought suit against the Company, Dell, and Universal as alleged aiders and abettors.  Effective December 2, 2016, the parties entered into an agreement to resolve the Jacobs action, pursuant to which the plaintiff voluntarily dismissed the action with prejudice.  Under the operative amended complaint in the Ford action, the plaintiffs also brought suit against the Company and Dell for alleged breach of fiduciary duties to VMware, Inc. and its stockholders, and against the Company, Dell, and Universal for aiding and abetting the alleged breach of fiduciary duties by EMC's and VMware, Inc.'s directors.  Certain defendants filed motions to dismiss the amended complaint on June 21, 2016.  A hearing on those motions was held on February 3, 2017.  On May 2, 2017, the Court dismissed the amended complaint for failure to state a claim upon which relief could be granted and no appeal was taken.  All fifteen EMC merger-related lawsuits are now fully and finally resolved.

- removed (2018-06-12):
[0001571996-17-000045:note_history:9]
In connection with the divestitures discussed in Note 3 of the Notes to the Condensed Consolidated Financial Statements, the Company has indemnified the purchasers of businesses for the occurrence of specified events.  The Company does not currently believe that contingent obligations to provide indemnification in connection with these divestitures will have a material adverse effect on the Company.

- removed (2018-06-12):
[0001571996-17-000045:note_history:10]
Purchase Obligations

- removed (2018-06-12):
[0001571996-17-000045:note_history:11]
The Company has contractual obligations to purchase goods or services, which specify significant terms, including fixed or minimum quantities to be purchased; fixed, minimum, or variable price provisions; and the approximate timing of the transaction.  As of November 3, 2017, the Company had $3,055 million, $278 million, and $458 million in purchase obligations for Fiscal 2018 (remaining three months), Fiscal 2019, and Fiscal 2020 and thereafter, respectively.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2018-06-12):
[0001571996-18-000022:note_history:12]
Basis of Presentation — The accompanying unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes filed with the U.S. Securities and Exchange Commission ("SEC") in the Company's Annual Report on Form 10-K for the fiscal year ended February 2, 2018.  These Condensed Consolidated Financial Statements have been prepared in accordance with accounting principles generally accepted in the United States of America ("GAAP").  In the opinion of management, the accompanying Condensed  Consolidated Financial Statements reflect all adjustments of a normal recurring nature considered necessary to fairly state the financial position of Dell Technologies Inc. as of May 4, 2018 and February 2, 2018, the results of its operations and corresponding comprehensive income (loss) for the three months ended May 4, 2018 and May 5, 2017, and its cash flows for the three months ended May 4, 2018 and May 5, 2017.  References in these Notes to the Condensed Consolidated Financial Statements to the "Company" or "Dell Technologies" means Dell Technologies Inc. individually and together with its consolidated subsidiaries.
  (was, 2017-12-12, similarity 0.6954):
[0001571996-17-000045:note_history:12]
Basis of Presentation — The accompanying unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes filed with the U.S. Securities and Exchange Commission ("SEC") in the Company's Annual Report on Form 10-K for the fiscal year ended February 3, 2017.  These Condensed Consolidated Financial Statements have been prepared in accordance with accounting principles generally accepted in the United States of America ("GAAP").  In the opinion of management, the accompanying Condensed Consolidated Financial Statements reflect all adjustments of a normal recurring nature considered necessary to fairly state the financial position of Dell Technologies Inc. (individually and together with its consolidated subsidiaries, the "Company" or "Dell Technologies") as of November 3, 2017 and February 3, 2017, the results of its operations and corresponding comprehensive income (loss) for the three and nine months ended November 3, 2017 and October 28, 2016, as well as its cash flows for the nine months ended November 3, 2017 and October 28, 2016.

- changed (2018-06-12):
[0001571996-18-000022:note_history:13]
The preparation of financial statements in accordance with GAAP requires management to make estimates and assumptions that affect the amounts reported in the Condensed Consolidated Financial Statements and the accompanying Notes.  Actual results could differ materially from those estimates.  The results of operations, comprehensive income (loss), and cash flows for the three months ended May 4, 2018 and May 5, 2017 are not necessarily indicative of the results to be expected for the full fiscal year or for any other fiscal period.
  (was, 2017-12-12, similarity 0.6974):
[0001571996-17-000045:note_history:13]
The preparation of financial statements in accordance with GAAP requires management to make estimates and assumptions that affect the amounts reported in the Condensed Consolidated Financial Statements and the accompanying Notes.  Actual results could differ materially from those estimates.  The results of operations and comprehensive income (loss) for the three and nine months ended November 3, 2017 and October 28, 2016 and cash flows for the nine months ended November 3, 2017 and October 28, 2016 are not necessarily indicative of the results to be expected for the full fiscal year or for any other fiscal period.

- changed (2018-06-12):
[0001571996-18-000022:note_history:14]
The Company's fiscal year is the 52- or 53-week period ending on the Friday nearest January 31.  The fiscal year ended February 2, 2018 ("Fiscal 2018") was a 52-week period, and the fiscal year ending February 1, 2019 ("Fiscal 2019") will be a 52-week period.
  (was, 2017-12-12, similarity 0.9769):
[0001571996-17-000045:note_history:14]
The Company's fiscal year is the 52- or 53-week period ending on the Friday nearest January 31.  The fiscal year ended February 3, 2017 ("Fiscal 2017") was a 53-week period while the fiscal year ending February 2, 2018 ("Fiscal 2018") will be a 52-week period.

- added (2018-06-12):
[0001571996-18-000022:note_history:15]
Principles of Consolidation — These Condensed Consolidated Financial Statements include the accounts of Dell Technologies and its wholly-owned subsidiaries, as well as the accounts of SecureWorks Corp. (“SecureWorks"), VMware, Inc., and Pivotal Software, Inc. ("Pivotal"), each of which is majority-owned by Dell Technologies.  All intercompany transactions have been eliminated.

- changed (2018-06-12):
[0001571996-18-000022:note_history:16]
Unless the context indicates otherwise, references in these Notes to the Condensed Consolidated Financial Statements to "VMware" mean the VMware reportable segment, which reflects the operations of VMware, Inc. (NYSE: VMW) within Dell Technologies.  See Exhibit 99.1 filed with the quarterly report on Form 10-Q for the quarterly period ended May 4, 2018 for information on the differences between VMware reportable segment results and VMware, Inc. results.
  (was, 2017-12-12, similarity 0.9769):
[0001571996-17-000045:note_history:16]
Unless the context indicates otherwise, references in these Notes to the Condensed Consolidated Financial Statements to "VMware" mean the VMware reportable segment, which reflects the operations of VMware, Inc. (NYSE: VMW) within Dell Technologies.  See Exhibit 99.1 filed with the Company's quarterly report on Form 10-Q for the quarterly period ended November 3, 2017 for information on the differences between VMware reportable segment results and VMware, Inc. results.

- added (2018-06-12):
[0001571996-18-000022:note_history:17]
EMC Merger Transaction — On September 7, 2016, the Company completed its acquisition by merger of EMC Corporation ("EMC"), referred to as the EMC merger transaction.  The consolidated results of EMC are included in Dell Technologies' consolidated results presented in these financial statements.

- added (2018-06-12):
[0001571996-18-000022:note_history:18]
Pivotal Initial Public Offering — On April 24, 2018, Pivotal completed a registered underwritten initial public offering ("IPO") of its Class A common stock.  The results of Pivotal's operations are included in other businesses.  For more information regarding the Company's ownership of Pivotal, see Note 14 of the Notes to the Condensed Consolidated Financial Statements.

- added (2018-06-12):
[0001571996-18-000022:note_history:19]
Leases — In February 2016, the Financial Accounting Standards Board ("FASB")  issued amended guidance on the accounting for leasing transactions.  The primary objective of this update is to increase transparency and comparability among organizations by requiring lessees to recognize a lease liability for the obligation to make lease payments and a right-of-use asset for the right to use the underlying asset for the lease term.  The guidance also makes some changes to lessor accounting and requires additional disclosures about all leasing arrangements.  The Company will adopt this standard for the fiscal year beginning February 2, 2019, using a modified retrospective approach.  The Company is currently evaluating the impact that the standard will have on the Consolidated Financial Statements.  In the area of lessee accounting, the Company anticipates that the most significant change will be recognition of right-of-use assets and lease liabilities on the Consolidated Statements of Financial Position.  In the area of lessor accounting, the Company anticipates that the most significant change will be an increase in originations of operating leases due to elimination of the third-party residual value guarantee insurance in the sales-type lease test.

- changed (2018-06-12):
[0001571996-18-000022:note_history:20]
Simplifying the Test for Goodwill Impairment — In January 2017, the FASB issued amended guidance to simplify the subsequent measurement of goodwill by removing Step 2 of the goodwill impairment test.  Instead, under the amendments in the new guidance, an entity should perform its annual, or interim, goodwill impairment test by comparing the fair value of a reporting unit with its carrying amount.  The entity should recognize an impairment charge for the amount by which the carrying amount exceeds the reporting unit's fair value.  Public entities must adopt the new guidance in fiscal years beginning after December 15, 2019, with early adoption permitted.  The Company is currently evaluating the impact of the new guidance, but does not expect that the standard will have an impact on its Consolidated Financial Statements.
  (was, 2017-12-12, similarity 0.9969):
[0001571996-17-000045:note_history:20]
Simplifying the Test for Goodwill Impairment — In January 2017, the FASB issued amended guidance to simplify the subsequent measurement of goodwill by removing Step 2 of the goodwill impairment test.  Instead, under the amendments in the new guidance, an entity should perform its annual, or interim, goodwill impairment test by comparing the fair value of a reporting unit with its carrying amount.  An entity should recognize an impairment charge for the amount by which the carrying amount exceeds the reporting unit's fair value.  Public entities must adopt the new guidance in fiscal years beginning after December 15, 2019, with early adoption permitted.  The Company is currently evaluating the impact of the new guidance, but does not expect that the standard will have an impact on its Consolidated Financial Statements.

- changed (2018-06-12):
[0001571996-18-000022:note_history:21]
Revenue from Contracts with Customers — In May 2014, the FASB issued amended guidance on the recognition of revenue from contracts with customers.  The objective of the new standard is to establish a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and will supersede substantially all of the existing revenue recognition guidance, including industry-specific guidance.  The new standard requires entities to recognize revenue when it transfers promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services.  Further, the new standard requires additional disclosures to help enable users of the financial statements to better understand the nature, amount, timing, risks, and judgments related to revenue recognition and related cash flows from contracts with customers.  Concurrently, the FASB issued guidance on the accounting for costs to fulfill or obtain a customer contract.  The Company adopted this standard during the three months ended May 4, 2018 using the full retrospective method, which requires the Company to recast each prior period presented consistent with the new guidance.  See tables provided below which present the impact of the new accounting standards to the Company's previously reported financial results.  See also Note 2 of the Notes to the Condensed Consolidated Financial Statements for a summary of significant policies related to the new accounting standards.
  (was, 2017-12-12, similarity 0.7059):
[0001571996-17-000045:note_history:21]
Revenue from Contracts with Customers — In May 2014, the Financial Accounting Standards Board (the "FASB") issued amended guidance on the recognition of revenue from contracts with customers.  The objective of the new standard is to establish a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and will supersede substantially all of the existing revenue recognition guidance, including industry-specific guidance.  The new standard requires entities to recognize revenue when it transfers promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services.  The new standard also provides guidance on the accounting for costs to fulfill or obtain a customer contract.  Further, the new standard requires additional disclosures to help enable users of the financial statements to better understand the nature, amount, timing, risks, and judgments related to revenue recognition and related cash flows from contracts with customers.

- added (2018-06-12):
[0001571996-18-000022:note_history:22]
Recognition and Measurement of Financial Assets and Financial Liabilities — In January 2016, the FASB issued amended guidance that generally requires changes in the fair value of equity investments, other than those accounted for under the equity method, to be recognized through net income, rather than other comprehensive income.  For equity investments without readily determinable fair values, the Company is no longer permitted to use the cost method of accounting.  The Company has elected to apply the measurement alternative for those investments.  Under the alternative, the Company measures investments without readily determinable fair values at cost, less impairment, adjusted by observable price changes on a prospective basis.  The Company must make a separate election to use the alternative for each eligible investment, and is required to reassess at each reporting period whether an investment qualifies for the alternative.  The Company adopted this standard during the three months ended May 4, 2018.  Adoption of the standard was applied through a cumulative one-time adjustment to accumulated deficit of $56 million for the accumulated unrealized gain previously recorded in other comprehensive income.  The impact of the standard on the Condensed Consolidated Statements of Income (Loss) during the three months ended May 4, 2018 was a gain of approximately $100 million, recognized in interest and other, net, and the impact in future periods will depend on the relative changes in market price of the equity investments.

- added (2018-06-12):
[0001571996-18-000022:note_history:23]
Classification of Certain Cash Receipts and Cash Payments — In August 2016, the FASB issued amended guidance on the presentation and classification of eight specific cash flow issues with the objective of reducing existing diversity in practice.  Companies should reflect any adjustments on a retrospective basis, if practicable; otherwise, adoption is required to be applied as of the earliest date practicable.  The Company adopted this standard during the three months ended May 4, 2018.  Prior period amounts on the Condensed Consolidated Statements of Cash Flows have been recast to conform with current period presentation as shown in the reconciliation provided below.

- changed (2018-06-12):
[0001571996-18-000022:note_history:24]
Intra-Entity Transfers of Assets Other Than Inventory — In October 2016, the FASB issued amended guidance on the accounting for income taxes.  The new guidance requires companies to recognize the income tax effects of intra-entity asset transfers, other than transfers of inventory, when the transfer occurs instead of when the asset is sold to a third party.  The new guidance was applied on a modified-retrospective basis with the cumulative-effect adjustment to accumulated deficit as of the beginning of the period of adoption.  The Company early adopted this guidance during the three months ended May 5, 2017.  At adoption, approximately $84 million was reclassified from other non-current liabilities to accumulated deficit, resulting in a net credit to accumulated deficit.
  (was, 2017-12-12, similarity 0.6859):
[0001571996-17-000045:note_history:24]
Intra-Entity Transfers of Assets Other Than Inventory — In October 2016, the FASB issued amended guidance on the accounting for income taxes.  The new guidance requires companies to recognize the income tax effects of intra-entity asset transfers, other than transfers of inventory, when the transfer occurs instead of when the asset is sold to a third party.  The new guidance should be applied on a modified-retrospective basis with the cumulative-effect adjustment to retained earnings as of the beginning of the period of adoption.  The Company early adopted this guidance at the beginning of Fiscal 2018.  At adoption, approximately $84 million was reclassified from other non-current liabilities to retained earnings, resulting in a net credit to retained earnings.

- added (2018-06-12):
[0001571996-18-000022:note_history:25]
Statement of Cash Flows, Restricted Cash — In November 2016, the FASB issued amended guidance requiring entities to include restricted cash and restricted cash equivalents in cash balances on the cash flow statement, and also to provide a supplemental reconciliation of cash, cash equivalents and restricted cash.  Public entities must adopt the new guidance for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017, with early adoption permitted.  The Company adopted this standard during the three months ended May 4, 2018.  See Note 19 of the Notes to the Condensed Consolidated Financial Statements for supplemental cash flow information.  Prior period amounts on the Condensed Consolidated Statements of Cash Flows have been recast to conform with current period presentation as shown in the reconciliation provided below.

- added (2018-06-12):
[0001571996-18-000022:note_history:26]
Clarifying the Definition of a Business — In January 2017, the FASB issued amended guidance to clarify the definition of a business with the objective of adding guidance to assist entities with evaluating whether transactions should be accounted for as acquisitions (or disposals) of assets or businesses.  Public entities must adopt the new guidance for fiscal years beginning after December 15, 2017, and interim periods within those fiscal years.  The new guidance did not have a material impact on the Company's conclusions regarding transactions that were assessed in the current period.

- changed (2018-06-12):
[0001571996-18-000022:note_history:27]
Derivatives and Hedging — In August 2017, the FASB issued amended guidance that will make more financial and non-financial hedging strategies eligible for hedge accounting.  The amended guidance changes how companies assess effectiveness, and also amends the presentation and disclosure requirements.  The guidance is intended to simplify the application of hedge accounting and increase transparency as to the scope and results of hedging programs.  Immediate early adoption is permitted in any interim or annual period.  The Company elected to early adopt this standard during the three months ended May 4, 2018.  The impact of the adoption of the standard was immaterial to the Condensed Consolidated Financial Statements.
  (was, 2017-12-12, similarity 0.7666):
[0001571996-17-000045:note_history:27]
Derivatives and Hedging — In August 2017, the FASB issued amended guidance that will make more financial and non-financial hedging strategies eligible for hedge accounting.  The amended guidance changes how companies assess effectiveness, and also amends the presentation and disclosure requirements.  The guidance is intended to simplify the application of hedge accounting and increase transparency as to the scope and results of hedging programs.  Immediate early adoption is permitted in any interim or annual period.  The Company will early adopt this guidance at the beginning of the fiscal year ending February 1, 2019.  The Company is currently evaluating the application of the new guidance, but does not expect that it will have a material impact on the Consolidated Financial Statements.

- added (2018-06-12):
[0001571996-18-000022:note_history:28]
Income Statement - Reporting Comprehensive Income — In February 2018, the FASB issued guidance that will permit entities to reclassify the tax effects stranded in accumulated other comprehensive income to accumulated deficit as a result of U.S. Tax Reform, discussed in Note 12 of the Notes to the Condensed Consolidated Financial Statements.  The guidance gives entities the option to reclassify these amounts, but requires new disclosures regardless of whether they elect to do so.  The guidance is effective for fiscal years beginning after December 15, 2018, and interim periods within those fiscal years.  Early adoption is permitted.  The Company elected to early adopt this standard during the three months ended May 4, 2018, and recorded the impact of the adoption as a cumulative adjustment to accumulated deficit.  The impact of the adoption was immaterial to the Condensed Consolidated Financial Statements.

- added (2018-06-12):
[0001571996-18-000022:note_history:29]
Impacts to Previously Reported Periods

- added (2018-06-12):
[0001571996-18-000022:note_history:30]
The following tables present the impact of the new accounting standards to the Company's previously reported financial results.

- added (2018-06-12):
[0001571996-18-000022:note_history:31]
Selected Captions from the Condensed Consolidated Statement of Financial Position

- added (2018-06-12):
[0001571996-18-000022:note_history:32]
|  | February 2, 2018 |
|  | As Reported |  | Revenue from Contracts with Customers |  | As Recast |
|  | (in millions) |
| Assets |  |  |  |  |  |
| Accounts receivable, net | $ | 11,177 |  |  | $ | 544 |  |  | $ | 11,721 |  |
| Other current assets | $ | 5,054 |  |  | $ | 827 |  |  | $ | 5,881 |  |
| Other non-current assets | $ | 1,862 |  |  | $ | 541 |  |  | $ | 2,403 |  |
| Liabilities and Stockholders' Equity |  |  |  |  |  |
| Accrued and other | $ | 7,661 |  |  | $ | 365 |  |  | $ | 8,026 |  |
| Short-term deferred revenue | $ | 12,024 |  |  | $ | (418 | ) |  | $ | 11,606 |  |
| Long-term deferred revenue | $ | 10,223 |  |  | $ | (1,013 | ) |  | $ | 9,210 |  |
| Other non-current liabilities | $ | 6,797 |  |  | $ | 480 |  |  | $ | 7,277 |  |
| Accumulated deficit | $ | (9,253 | ) |  | $ | 2,393 |  |  | $ | (6,860 | ) |
| Non-controlling interests | $ | 5,661 |  |  | $ | 105 |  |  | $ | 5,766 |  |

- added (2018-06-12):
[0001571996-18-000022:note_history:33]
The above impacts are summarized as follows:

- added (2018-06-12):
[0001571996-18-000022:note_history:34]
Accounts receivable, net.  The adoption of the new revenue standard resulted in an increase to accounts receivable, net primarily due to the following two factors:

- added (2018-06-12):
[0001571996-18-000022:note_history:35]
| • | First, the return rights provision, which represents an estimate of expected customer returns, which was previously presented as a reduction of accounts receivable, net, is now being presented outside of accounts receivable, net in two separate balance sheet line items. A liability is recorded in accrued and other for the estimated value of the sales amounts to be returned to the customer, and an asset is recorded in other current assets representing the cost of the inventory estimated to be returned. |

- added (2018-06-12):
[0001571996-18-000022:note_history:36]
| • | Second, the standard provides new guidance regarding transfer of control of goods to the customer. Under these new guidelines, the Company has determined that for certain hardware contracts in the United States, transfer of control and recognition of revenue can occur earlier. This resulted in an increase in accounts receivable, net and a decrease in the in-transit deferral recorded in other current assets. |

- added (2018-06-12):
[0001571996-18-000022:note_history:37]
Other assets.  The adoption of the new revenue standard resulted in an increase in other assets due to capitalization of the costs to obtain a contract, as well as the accounts receivable, net of impacts discussed above.

- added (2018-06-12):
[0001571996-18-000022:note_history:38]
Deferred revenue.  The adoption of the new revenue standard resulted in a decline in deferred revenue due to earlier recognition of revenue for software licenses, and less of the aggregate transaction price being allocated to extended warranty.  Deferred revenue was also reduced by the impact of variable consideration, i.e., price concessions, rebates, and refunds.  The reduction in deferred revenue was partially offset by an increase resulting from the change in presentation of deferred costs on third-party software offerings, which are either sold on a standalone basis or as an attached component of the Company's hardware offering.  The Company previously reported deferred costs net of revenue in deferred revenue.

- added (2018-06-12):
[0001571996-18-000022:note_history:39]
Condensed Consolidated Statement of Income (Loss)

- added (2018-06-12):
[0001571996-18-000022:note_history:40]
|  | Three Months Ended |
|  | May 5, 2017 |
|  | As Reported |  | Revenue from Contracts with Customers |  | As Recast |
|  | (in millions, except per share amounts) |
| Net revenue: |  |  |  |  |  |
| Products | $ | 12,968 |  |  | $ | 666 |  |  | $ | 13,634 |  |
| Services | 4,848 |  |  | (482 | ) |  | 4,366 |  |
| Total net revenue | 17,816 |  |  | 184 |  |  | 18,000 |  |
| Cost of net revenue: |  |  |  |  |  |
| Products | 11,459 |  |  | 364 |  |  | 11,823 |  |
| Services | 2,055 |  |  | (335 | ) |  | 1,720 |  |
| Total cost of net revenue | 13,514 |  |  | 29 |  |  | 13,543 |  |
| Gross margin | 4,302 |  |  | 155 |  |  | 4,457 |  |
| Operating expenses: |  |  |  |  |  |
| Selling, general, and administrative | 4,669 |  |  | (73 | ) |  | 4,596 |  |
| Research and development | 1,133 |  |  | — |  |  | 1,133 |  |
| Total operating expenses | 5,802 |  |  | (73 | ) |  | 5,729 |  |
| Operating loss | (1,500 | ) |  | 228 |  |  | (1,272 | ) |
| Interest and other, net | (573 | ) |  | 1 |  |  | (572 | ) |
| Income (loss) before income taxes | (2,073 | ) |  | 229 |  |  | (1,844 | ) |
| Income tax provision (benefit) | (690 | ) |  | 49 |  |  | (641 | ) |
| Net income (loss) | (1,383 | ) |  | 180 |  |  | (1,203 | ) |
| Less: Net income (loss) attributable to non-controlling interests | (49 | ) |  | 17 |  |  | (32 | ) |
| Net income (loss) attributable to Dell Technologies Inc. | $ | (1,334 | ) |  | $ | 163 |  |  | $ | (1,171 | ) |
| Earnings (loss) per share attributable to Dell Technologies Inc. - basic: |  |  |  |  |
| Class V Common Stock - basic | $ | 0.57 |  |  | 0.03 |  |  | $ | 0.60 |  |
| DHI Group - basic | $ | (2.57 | ) |  | 0.28 |  |  | $ | (2.29 | ) |
| Earnings (loss) per share attributable to Dell Technologies Inc. - diluted: |  |  |  |  |
| Class V Common Stock - diluted | $ | 0.56 |  |  | 0.03 |  |  | $ | 0.59 |  |
| DHI Group - diluted | $ | (2.57 | ) |  | 0.28 |  |  | $ | (2.29 | ) |

- added (2018-06-12):
[0001571996-18-000022:note_history:41]
The above impacts are summarized as follows:

- added (2018-06-12):
[0001571996-18-000022:note_history:42]
Net revenue.  The adoption of the new revenue standard resulted in an increase to net revenue due to earlier revenue recognition than permitted under the previous standard.

- added (2018-06-12):
[0001571996-18-000022:note_history:43]
Products revenue vs. services revenue.  The adoption of the new revenue standard resulted in a change to the classification of products revenue vs. services revenue, due to the following factors:

- added (2018-06-12):
[0001571996-18-000022:note_history:44]
| • | Under the new revenue standard, amounts within a contract are now allocated to the product and services performance obligations based on their respective standalone selling prices, which generally increases product revenue and decreases services revenue. |

- added (2018-06-12):
[0001571996-18-000022:note_history:45]
| • | Further, third-party software licenses were previously recognized in services revenue as the Company could not separate the value of the software license from the associated maintenance agreement. Under the new revenue standard, the license value requires separation and will be recognized in product revenue and the value of the software maintenance will continue to be recognized in services revenue. |

- added (2018-06-12):
[0001571996-18-000022:note_history:46]
Operating expenses.   The adoption of the new revenue standard resulted in a decrease to operating expenses due to the deferral of commissions.

- added (2018-06-12):
[0001571996-18-000022:note_history:47]
Selected Captions from the Condensed Consolidated Statement of Cash Flows

- added (2018-06-12):
[0001571996-18-000022:note_history:48]
|  | Three Months Ended |
|  | May 5, 2017 |
|  | As Reported |  | Classification of Certain Cash Receipts and Cash Payments |  | Statement of Cash Flows, Restricted Cash |  | As Recast |
|  | (in millions) |
| Change in cash from operating activities | $ | 240 |  |  | $ | 29 |  |  | $ | 16 |  |  | $ | 285 |  |
| Change in cash from investing activities | $ | 51 |  |  | $ | — |  |  | $ | — |  |  | $ | 51 |  |
| Change in cash from financing activities | $ | (205 | ) |  | $ | (29 | ) |  | $ | 47 |  |  | $ | (187 | ) |
| Change in cash, cash equivalents, and restricted cash | $ | 80 |  |  | $ | — |  |  | $ | 63 |  |  | $ | 143 |  |
| Cash, cash equivalents, and restricted cash at beginning of the period | 9,474 |  |  | — |  |  | 358 |  |  | 9,832 |  |
| Cash, cash equivalents, and restricted cash at end of the period | $ | 9,554 |  |  | $ | — |  |  | $ | 421 |  |  | $ | 9,975 |  |

- removed (2018-06-12):
[0001571996-17-000045:note_history:49]
EMC Merger Transaction — On September 7, 2016, EMC Corporation, a Massachusetts corporation ("EMC"), became a wholly-owned subsidiary of Dell Technologies Inc. (the "Company") as a result of the merger of Universal Acquisition Co., a Delaware corporation and wholly-owned subsidiary of the Company ("Merger Sub"), with and into EMC, with EMC surviving as a wholly-owned subsidiary of the Company (the "EMC merger transaction").  See Note 2 of the Notes to the Condensed Consolidated Financial Statements for additional information on the EMC merger transaction.

- removed (2018-06-12):
[0001571996-17-000045:note_history:50]
Divestitures — On November 2, 2016, the Company completed substantially all of the divestiture of Dell Services.  On October 31, 2016, the Company completed the divestiture of Dell Software Group ("DSG").  On January 23, 2017, the Company completed the divestiture of the Dell EMC Enterprise Content Division ("ECD").  In accordance with applicable accounting guidance, the results of Dell Services, DSG, and ECD are presented as discontinued operations in the Condensed Consolidated Statements of Income (Loss) and, as such, have been excluded from both continuing operations and segment results for the relevant periods.  See Note 3 of the Notes to the Condensed Consolidated Financial Statements for additional information.

- removed (2018-06-12):
[0001571996-17-000045:note_history:51]
SecureWorks Initial Public Offering — On April 27, 2016, SecureWorks Corp. ("SecureWorks") completed a registered underwritten initial public offering ("IPO") of its Class A common stock.  The results of the SecureWorks operations are included in other businesses.  See Note 15 of the Notes to the Condensed Consolidated Financial Statements for more information.

- removed (2018-06-12):
[0001571996-17-000045:note_history:52]
As a result of the EMC merger transaction completed on September 7, 2016, the Company's results of operations, comprehensive income (loss), and cash flows for the fiscal periods reflected in these Condensed Consolidated Financial Statements are not directly comparable as the results of the acquired businesses are only included in the consolidated results from September 7, 2016.

- removed (2018-06-12):
[0001571996-17-000045:note_history:53]
In August 2015, the FASB approved a one-year deferral of the effective date of this standard.  Public entities are required to adopt the new standard for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017.  The new revenue standard may be applied retrospectively to each prior period presented (full retrospective method) or retrospectively with the cumulative effect of initially applying the standard recognized at the date of initial application in retained earnings (modified retrospective method).  The Company currently expects to adopt this standard retrospectively to each prior period presented for the fiscal year beginning February 3, 2018.

- removed (2018-06-12):
[0001571996-17-000045:note_history:54]
While the Company is currently evaluating the financial and system impacts that the new standard will have on the Consolidated Financial Statements, the Company expects that unearned license revenue related to the sale of software licenses and related deliverables will decline upon adoption.  Currently, the Company defers revenue for certain software arrangements due to the absence of vendor specific objective evidence ("VSOE") of fair value for all or a portion of the deliverables.  Under the new standard, the Company will no longer be required to establish VSOE of fair value in order to account for elements in an arrangement as separate units of accounting, and will be able to record revenue upon satisfaction of each performance obligation.  Additionally, the Company expects the new standard to have an impact on the way the transaction price is allocated for certain non-standard warranties.  The new standard is expected to result in more of the aggregate transaction price related to the non-standard warranty being recorded as revenue upon delivery of the underlying product, because the Company will no longer defer revenue based on the separately stated price of the non-standard warranty provided under the contract.  The Company continues to make progress in assessing the impacts of the standard on the Consolidated Financial Statements and will continue to evaluate the impact of any changes to the standard or interpretations should they become available.

- removed (2018-06-12):
[0001571996-17-000045:note_history:55]
Recognition and Measurement of Financial Assets and Financial Liabilities — In January 2016, the FASB issued amended guidance that addresses certain aspects of recognition, measurement, presentation, and disclosure of financial instruments.  Public entities must adopt the new guidance for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017.  The amended guidance requires changes in the fair value of equity investments to be recognized through net income, rather than other comprehensive income.  Adoption of the standard will be applied through a cumulative one-time adjustment to retained earnings.  For the Company’s equity investments without readily determinable fair values, the Company expects to elect the measurement alternative to record those investments at cost, less impairment, and adjusted by observable price changes on a prospective basis.  The impact of the standard on the Consolidated Statements of Income (Loss) will depend on the relative changes in market price of the equity investments.

- removed (2018-06-12):
[0001571996-17-000045:note_history:56]
Leases — In February 2016, the FASB issued amended guidance on the accounting for leasing transactions.  The primary objective of this update is to increase transparency and comparability among organizations by requiring lessees to recognize lease assets and lease liabilities on the balance sheet and disclosing key information about leasing arrangements.  The guidance makes some changes to lessor accounting, including the elimination of the use of third-party residual value guarantee insurance in the sales-type lease test.  Public entities must adopt the new guidance for reporting periods beginning after December 15, 2018, with early adoption permitted.  Companies are required to use a modified retrospective approach for leases that exist or are entered into after the beginning of the earliest comparative period in the financial statements.  The Company is currently evaluating the impact that the standard will have on the Consolidated Financial Statements.

- removed (2018-06-12):
[0001571996-17-000045:note_history:57]
Classification of Certain Cash Receipts and Cash Payments — In August 2016, the FASB issued amended guidance on the presentation and classification of eight specific cash flow issues with the objective of reducing existing diversity in practice.  Public entities must adopt the new guidance for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017, with early adoption permitted.  Companies should reflect any adjustments on a retrospective basis, if practicable; otherwise, adoption is required to be applied as of the earliest date practicable.  The Company will adopt this standard as of May 4, 2018, and will apply adjustments retrospectively to each prior period presented on the Condensed Consolidated Statements of Cash Flows for that period.  The Company is currently evaluating the impact of the standard, and other than certain reclassifications on the Consolidated Statements of Cash Flows, it is not expected to have a material impact on the Consolidated Financial Statements.

- removed (2018-06-12):
[0001571996-17-000045:note_history:58]
Statement of Cash Flows, Restricted Cash — In November 2016, the FASB issued amended guidance requiring entities to include explanations of changes in restricted cash and restricted cash equivalents on the cash flow statement, and also to provide a supplemental reconciliation of cash, cash equivalents and restricted cash.  Public entities must adopt the new guidance for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017, with early adoption permitted. The Company will adopt this standard as of May 4, 2018, and will apply adjustments retrospectively to each prior period presented on the Condensed Consolidated Statements of Cash Flows for that period and provide the supplemental reconciliation.  The Company does not expect that the standard will have a material impact on its Consolidated Financial Statements as its restricted cash balance does not change significantly from period to period.

- removed (2018-06-12):
[0001571996-17-000045:note_history:59]
Improvements to Employee Share-Based Payment Accounting — In March 2016, the FASB issued amended guidance on the accounting for employee share-based payments, including the accounting for income taxes and forfeitures, classification of awards as either equity or liabilities, and classification of cash flows.  The Company adopted this guidance at the beginning of Fiscal 2018.  In accordance with the new guidance, excess tax benefits or deficiencies for stock-based compensation are now reflected as a component of the provision for income taxes on the Consolidated Statements of Income (Loss), whereas they were previously recorded as additional paid-in capital.  The Company has elected to continue to estimate expected forfeitures.  Additionally, the Company now presents excess tax benefits as an operating activity rather than a financing activity on the Consolidated Statements of Cash Flows, while the cash flows related to employee taxes paid for withheld shares are presented as a financing activity with prior periods adjusted accordingly.  The adoption of the amended guidance did not have a material impact on the Consolidated Financial Statements.  The prospective impact of the new standard will depend on the Company's stock price at the vesting or exercise dates of the awards and the number of awards that vest or are exercised in each period, but the Company does not expect the impact to be material in future periods.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: no_prior_note, score: 0.0

- added (2018-06-12):
[0001571996-18-000022:note_history:60]
INTERIM UPDATE TO SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES

- added (2018-06-12):
[0001571996-18-000022:note_history:61]
As mentioned previously in Note 1 of the Notes to the Condensed Consolidated Financial Statements, the Company adopted amended guidance on the recognition of revenue from contracts with customers during the three months ended May 4, 2018, using the full retrospective method.  The following accounting policies have been updated as part of the adoption of the new standard.

- added (2018-06-12):
[0001571996-18-000022:note_history:62]
Revenue Recognition — The Company enters into a variety of agreements to provide a wide portfolio of products and services offerings to its customers.  These agreements have varying requirements depending on the goods and services being sold, the rights and obligations conveyed, and the legal jurisdiction of the arrangement.

- added (2018-06-12):
[0001571996-18-000022:note_history:63]
Revenue is recognized either over time or at a point in time, depending on when the underlying goods or services are transferred to the customer, in an amount that reflects the consideration to which the Company expects to be entitled in exchange for delivering those goods or services.  The following five steps are applied to recognize revenue:

- added (2018-06-12):
[0001571996-18-000022:note_history:64]
| (1) | Identify the contract with a customer. The term “contract” refers to the enforceable rights and obligations provided in an agreement between the Company and one or more other parties in exchange for payment. The Company evaluates facts and circumstances regarding sales transactions in order to identify contracts with its customers. An agreement must meet all of the following criteria to qualify as a contract eligible for revenue recognition under the model: (i) the contract must be approved by all parties; (ii) each party's rights regarding the goods and services to be transferred to the customer can be identified; (iii) the payment terms for the good and services can be identified; (iv) the customer has the ability and intent to pay and it is probable that the Company will collect substantially all of the consideration to which it will be entitled; and (v) the contract must have commercial substance. Judgment is used in determining the customer's ability and intent to pay, which is based upon factors including the customer's historical payment experience or customer credit and financial information. |

- added (2018-06-12):
[0001571996-18-000022:note_history:65]
| (2) | Identify the performance obligations in the contract. Distinct promises within a contract are referred to as "performance obligations" and are accounted for as separate units of account. The Company assesses whether each promised good or service is distinct for the purpose of identifying the performance obligations in the contract. This assessment involves subjective determinations and requires management to make judgments about the individual promised goods or services and whether such goods or services are separable from the other aspects of the contractual relationship. Promised goods and services are considered distinct provided that: (i) the customer can benefit from the good or service either on its own or together with other resources that are readily available to the customer (that is, the good or service is capable of being distinct); and (ii) the Company's promise to transfer the good or service to the customer is separately identifiable from other promises in the contract (that is, the promise to transfer the good or service is distinct within the context of the contract). The Company's performance obligations consist of a variety of products and services offerings which include: computer and enterprise hardware, such as servers, storage, networking products, personal computers, workstations and peripherals; third-party software; proprietary software licenses; support and deployment services, including hardware support that extends beyond the Company's standard warranties, software maintenance, and installation; professional services; training; software as a service ("SaaS"); and infrastructure as a service ("IaaS"). |

- added (2018-06-12):
[0001571996-18-000022:note_history:66]
| (3) | Determine the transaction price. Transaction price reflects the amount of consideration to which the Company expects to be entitled in exchange for transferring goods or services to the customer. If the consideration promised in a contract includes a variable amount, the Company estimates the amount to which it expects to be entitled using either the expected value or most likely amount method. The Company’s contracts may include terms that could cause variability in the transaction price, including, for example, rebates, sales returns, and volume discounts. In determining the transaction price, any variable consideration would be considered, to the extent applicable, if it is probable that a significant future reversal of cumulative revenue under the contract will not occur when the uncertainty associated with the variable consideration is resolved. |

- added (2018-06-12):
[0001571996-18-000022:note_history:67]
| (4) | Allocate the transaction price to performance obligations in the contract. Many of the Company’s contracts include promises to transfer multiple products and services to a customer, and the transaction price must be allocated to each performance obligation in an amount that depicts the consideration to which the Company expects to be entitled in exchange for transferring the promised goods or services. For these contracts with multiple performance obligations, the transaction price is allocated in proportion to the standalone selling price ("SSP") of each performance obligation. If the contract contains a single performance obligation, the entire transaction price is allocated to that performance obligation. |

- added (2018-06-12):
[0001571996-18-000022:note_history:68]
The best evidence of SSP is the observable price of a good or service when the Company sells that good or service separately in similar circumstances to similar customers.  If a directly observable price is available, it must be utilized for the SSP.  If a directly observable price is not available, the SSP must be estimated.  The Company estimates SSP by considering multiple factors including, but not limited to, pricing practices, internal costs, and profit objectives  as well as overall market conditions which include geographic or regional specific factors, competitive positioning, and competitor actions.  SSP can include fixed and variable components.  Variable components are estimated based on the most likely outcome or expected value of the variable components.

- added (2018-06-12):
[0001571996-18-000022:note_history:69]
| (5) | Recognize revenue when (or as) the performance obligation is satisfied. Revenue is recognized when obligations under the terms of the contract with our customer are satisfied. Revenue is recognized either over time or at a point in time, depending on when the underlying products or services are transferred to the customer. Revenue is recorded at a point in time for products upon transfer of control. Revenue is recognized over time for support services, professional services, training, SaaS, and IaaS. |

- added (2018-06-12):
[0001571996-18-000022:note_history:70]
The Company reports revenue net of any revenue-based taxes assessed by governmental authorities that are imposed on and concurrently with specific revenue-producing transactions.

- added (2018-06-12):
[0001571996-18-000022:note_history:71]
The Company has elected the following practical expedients with the adoption of the new revenue standard:

- added (2018-06-12):
[0001571996-18-000022:note_history:72]
| • | The Company does not account for significant financing components if the period between revenue recognition and when the customer pays for the product or service will be one year or less. |

- added (2018-06-12):
[0001571996-18-000022:note_history:73]
| • | The Company recognizes revenue equal to the amount it has a right to invoice when the amount corresponds directly with the value to the customer of the Company's performance to date. |

- added (2018-06-12):
[0001571996-18-000022:note_history:74]
| • | The Company does not account for shipping and handling activities as a separate performance obligation, but rather as an activity performed to transfer the promised good. |

- added (2018-06-12):
[0001571996-18-000022:note_history:75]
The following summarizes the nature of revenue recognized and the manner in which the Company accounts for sales transactions.

- added (2018-06-12):
[0001571996-18-000022:note_history:76]
Products

- added (2018-06-12):
[0001571996-18-000022:note_history:77]
Product revenue consists of hardware and software license sales that are delivered, sold as a subscription or sold on a consumption basis.  Hardware includes notebooks and desktop PCs, servers, storage hardware, and other hardware-related devices.  Software license sales include non-essential, stand-alone software applications.  Software applications provide customers with resource management, backup and archiving, information security, information management and intelligence, data analytics, and server virtualization capabilities.

- added (2018-06-12):
[0001571996-18-000022:note_history:78]
Revenue from the sale of hardware products is recognized when control has transferred to the customer, which typically occurs when the hardware has been shipped to the customer, risk of loss has transferred to the customer, the Company has a present right to payment, and customer acceptance has been satisfied.  Customer acceptance is satisfied if acceptance is obtained from the customer, if all acceptance provisions lapse, or if the Company has evidence that all acceptance provisions will be, or have been, satisfied.  Revenue from software license sales is generally recognized when control has transferred to the customer, which is typically upon shipment, electronic delivery, or when the software is available for download by the customer.  For certain arrangements, including software subscriptions and certain software license agreements which provide customers control to certain product performance obligations over time, revenue is recognized based on usage or ratably over the term of the arrangement based on the pattern of delivery of the product to the customer.

- added (2018-06-12):
[0001571996-18-000022:note_history:79]
Invoices for products are generally issued as control transfers, which is typically upon shipment or electronic delivery.  There was no significant revenue in any period presented related to performance obligations satisfied or partially satisfied in prior periods.

- added (2018-06-12):
[0001571996-18-000022:note_history:80]
Services

- added (2018-06-12):
[0001571996-18-000022:note_history:81]
Services revenue consists of revenue from sales of support services, including hardware support that extends beyond the Company's standard warranties, software maintenance, and installation; professional services; training; SaaS; and IaaS.  Revenue associated with undelivered performance obligations is deferred and recorded as control is transferred to the customer over time.  Revenue from fixed-price support or maintenance contracts sold for both hardware and software is recognized on a straight-line basis over the period of performance because the Company is required to provide services at any given time.  Other services revenue is recognized when the Company performs the services and the customers receive and consume the benefits.

- added (2018-06-12):
[0001571996-18-000022:note_history:82]
Invoices for services may be issued at the start of a service term, which is typically the case for support and deployment services, or as services are rendered, which is typically the case for professional services, training, SaaS, and IaaS.

- added (2018-06-12):
[0001571996-18-000022:note_history:83]
Other

- added (2018-06-12):
[0001571996-18-000022:note_history:84]
Revenue from leasing arrangements is not subject to the new revenue standard from contracts with customers, and remains separately accounted for under existing lease accounting guidance.  The Company records revenue from the sale of equipment under sales-type leases as product revenue in an amount equal to the present value of minimum lease payments at the inception of the lease.  Sales-type leases also produce financing income, which is included in net products revenue in the Consolidated Statements of Income (Loss) and is recognized at consistent rates of return over the lease term.  The Company also offers qualified customers fixed-term loans and revolving credit lines for the purchase of products and services offered by the Company.  Financing income attributable to these loans is recognized in product revenue on an accrual basis.

- added (2018-06-12):
[0001571996-18-000022:note_history:85]
Disaggregation of Revenue — The Company's revenue is presented on a disaggregated basis on the Condensed Consolidated Statements of Income (Loss) and in Note 18 of the Notes to the Condensed Consolidated Financial Statements based on an evaluation of disclosures outside of the financial statements, information regularly reviewed by the chief operating decision maker for evaluating the financial performance of operating segments, and other information that is used to evaluate the Company's financial performance or make resource allocations.  This information includes revenue from product and services, revenue from reportable segments, and revenue by major product lines within the segments.

- added (2018-06-12):
[0001571996-18-000022:note_history:86]
Contract Assets — Contract assets are rights to consideration in exchange for goods or services that the Company has transferred to a customer when such a right is conditional on something other than the passage of time.  Such amounts have been insignificant to date.

- added (2018-06-12):
[0001571996-18-000022:note_history:87]
Contract Liabilities — Contract liabilities primarily consist of deferred revenue.  Deferred revenue is recorded when the Company has a right to invoice or payments have been received for undelivered products or services, or in situations where revenue recognition criteria have not been met.  Deferred revenue also represents amounts received in advance for extended warranty services and software maintenance.  Revenue is recognized on these items when the revenue recognition criteria are met, generally resulting in ratable recognition over the contract term.  The Company also has deferred revenue related to undelivered hardware and professional services, consisting of installations and consulting engagements, which are recognized as the Company's performance obligations under the contract are completed.  See Note 9 of the Notes to the Condensed Consolidated Financial Statements for additional information about deferred revenue.

- added (2018-06-12):
[0001571996-18-000022:note_history:88]
Costs to Obtain a Contract — The incremental direct costs of obtaining a contract primarily consist of sales commissions and employer taxes related to commission payments.  The Company has elected, as a practical expedient, to expense as incurred costs to obtain a contract equal to or less than one year in duration.  For contracts greater than one year in duration, the associated costs to obtain a contract are deferred and amortized over the period of contract performance or a longer period, generally the estimated life of the customer relationship, if renewals are expected and the renewal commission is not commensurate with the initial commission.  Deferred costs to obtain a contract are typically amortized over a period of 3 to 7 years, depending on the contract term and expectation of the period of benefit for the costs, which may exceed the contract term.  Amortization expense is recognized on a straight-line basis and included in selling, general, and administrative expenses in the Condensed Consolidated Statements of Income (Loss).  The Company periodically reviews these deferred costs to determine whether events or changes in circumstances have occurred that could impact the carrying value or period of benefit of the deferred sales commissions.  There were no material impairment losses for deferred sales commissions during the three months ended May 4, 2018 and May 5, 2017.

- added (2018-06-12):
[0001571996-18-000022:note_history:89]
Deferred costs to obtain a contract as of May 4, 2018 and February 2, 2018 were $909 million and $834 million, respectively.  Deferred costs to obtain a contract are classified as current assets and other non-current assets on the Condensed Consolidated Statements of Financial Position, based on when the expense is expected to be recognized.  Amortization of costs to obtain a contract during the three months ended May 4, 2018 and May 5, 2017 was $108 million and $54 million, respectively.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2018-06-12):
[0001571996-18-000022:note_history:90]
|  | May 4, 2018 |  | February 2, 2018 |
|  | (in millions) |
| Secured Debt |  |  |  |
| Senior Secured Credit Facilities: |  |  |  |
| 3.91% Term Loan B Facility due September 2023 | $ | 4,975 |  |  | $ | 4,988 |  |
| 3.66% Term Loan A-2 Facility due September 2021 | 4,339 |  |  | 4,394 |  |
| 3.41% Term Loan A-3 Facility due December 2018 | 1,213 |  |  | 1,213 |  |
| First Lien Notes: |  |  |  |
| 3.48% due June 2019 | 3,750 |  |  | 3,750 |  |
| 4.42% due June 2021 | 4,500 |  |  | 4,500 |  |
| 5.45% due June 2023 | 3,750 |  |  | 3,750 |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 8.10% due July 2036 | 1,500 |  |  | 1,500 |  |
| 8.35% due July 2046 | 2,000 |  |  | 2,000 |  |
| Unsecured Debt |  |  |  |
| Unsecured Notes and Debentures: |  |  |  |
| 5.65% due April 2018 | — |  |  | 500 |  |
| 5.875% due June 2019 | 600 |  |  | 600 |  |
| 4.625% due April 2021 | 400 |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| Senior Notes: |  |  |  |
| 5.875% due June 2021 | 1,625 |  |  | 1,625 |  |
| 7.125% due June 2024 | 1,625 |  |  | 1,625 |  |
| EMC Notes: |  |  |  |
| 1.875% due June 2018 | 2,500 |  |  | 2,500 |  |
| 2.650% due June 2020 | 2,000 |  |  | 2,000 |  |
| 3.375% due June 2023 | 1,000 |  |  | 1,000 |  |
| VMware Notes: |  |  |  |
| 2.30% due August 2020 | 1,250 |  |  | 1,250 |  |
| 2.95% due August 2022 | 1,500 |  |  | 1,500 |  |
| 3.90% due August 2027 | 1,250 |  |  | 1,250 |  |
| DFS Debt (Note 5) | 5,359 |  |  | 4,796 |  |
| Other |  |  |  |
| 4.61% Margin Loan Facility due April 2022 | 2,000 |  |  | 2,000 |  |
| Other | 99 |  |  | 101 |  |
| Total debt, principal amount | $ | 52,687 |  |  | $ | 52,694 |  |

- added (2018-06-12):
[0001571996-18-000022:note_history:91]
|  | May 4, 2018 |  | February 2, 2018 |
|  | (in millions) |
| Total debt, principal amount | $ | 52,687 |  |  | $ | 52,694 |  |
| Unamortized discount, net of unamortized premium | (256 | ) |  | (266 | ) |
| Debt issuance costs | (528 | ) |  | (557 | ) |
| Total debt, carrying value | $ | 51,903 |  |  | $ | 51,871 |  |
| Total short-term debt, carrying value | $ | 7,133 |  |  | $ | 7,873 |  |
| Total long-term debt, carrying value | $ | 44,770 |  |  | $ | 43,998 |  |

- added (2018-06-12):
[0001571996-18-000022:note_history:92]
During the three months ended May 4, 2018, the Company repaid $500 million principal amount of its 5.65% unsecured notes due April 2018 and $68 million principal amount of its term loan facilities.  Further, the Company issued an additional $611 million, net, in DFS debt to support the expansion of its financing receivables portfolio.

- added (2018-06-12):
[0001571996-18-000022:note_history:93]
Secured Debt

- changed (2018-06-12):
[0001571996-18-000022:note_history:94]
Senior Secured Credit Facilities — The Company has entered into a credit agreement that provides for senior secured credit facilities (the "Senior Secured Credit Facilities") in the aggregate principal amount of $17.6 billion comprising (a) term loan facilities and (b) a senior secured Revolving Credit Facility, which includes capacity for up to $0.5 billion of letters of credit and for borrowings of up to $0.4 billion under swing-line loans.  As of May 4, 2018, available borrowings under the Revolving Credit Facility totaled $3.3 billion.  The Senior Secured Credit Facilities provide that the borrowers have the right at any time, subject to customary conditions, to request incremental term loans or incremental revolving commitments.
  (was, 2017-12-12, similarity 0.9492):
[0001571996-17-000045:note_history:94]
Senior Secured Credit Facilities — At the closing of the EMC merger transaction on September 7, 2016, the Company entered into a credit agreement that provides for senior secured credit facilities (the "Senior Secured Credit Facilities") in the aggregate principal amount of $17.8 billion comprising (a) term loan facilities and (b) a senior secured Revolving Credit Facility, which includes capacity for up to $0.5 billion of letters of credit and for borrowings of up to $0.4 billion under swing-line loans.  As of November 3, 2017, available borrowings under the Revolving Credit Facility totaled $3.3 billion.  The Senior Secured Credit Facilities provide that the borrowers have the right at any time, subject to customary conditions, to request incremental term loans or incremental revolving commitments.

- changed (2018-06-12):
[0001571996-18-000022:note_history:95]
First Lien Notes — The senior secured notes (collectively, the "First Lien Notes") were issued on June 1, 2016 in an aggregate principal amount of $20.0 billion.  Interest on these borrowings is payable semiannually.  The First Lien Notes are secured, on a pari passu basis with the Senior Secured Credit Facilities, on a first-priority basis by substantially all of the tangible and intangible assets of the issuers and guarantors that secure obligations under the Senior Secured Credit Facilities, including pledges of all capital stock of the issuers, of Dell Inc., a wholly‑owned subsidiary of Dell Technologies ("Dell"), and of certain wholly-owned material subsidiaries of the issuers and the guarantors, subject to certain exceptions.
  (was, 2017-12-12, similarity 0.9558):
[0001571996-17-000045:note_history:95]
First Lien Notes — The senior secured notes (collectively, the "First Lien Notes") were issued on June 1, 2016 in an aggregate principal amount of $20.0 billion.  Interest on these borrowings is payable semiannually.  The First Lien Notes are secured, on a pari passu basis with the Senior Secured Credit Facilities, on a first-priority basis by substantially all of the tangible and intangible assets of the issuers and guarantors that secure obligations under the Senior Secured Credit Facilities, including pledges of all capital stock of the issuers, of Dell, and of certain wholly-owned material subsidiaries of the issuers and the guarantors, subject to certain exceptions.

- changed (2018-06-12):
[0001571996-18-000022:note_history:96]
China Revolving Credit Facility — On October 31, 2017, the Company entered into a credit agreement (the "China Revolving Credit Facility") with a bank lender for a secured revolving loan facility in an aggregate principal amount not to exceed $500 million.  Borrowings under the China Revolving Credit Facility bear interest at LIBOR plus 0.6% per annum .  The Company may voluntarily repay outstanding loans under the China Revolving Credit Facility at any time without premium or penalty, other than customary "breakage" costs.  The facility will expire on October 31, 2018.  As of May 4, 2018, there were no outstanding borrowings under the China Revolving Credit Facility.
  (was, 2017-12-12, similarity 0.9284):
[0001571996-17-000045:note_history:96]
China Revolving Credit Facility — On October 31, 2017, the Company entered into a credit agreement (the "China Revolving Credit Facility") with the Bank of China (Hong Kong) Limited for a secured revolving loan facility in an aggregate principal amount not to exceed $500 million.  Borrowings under the China Revolving Credit Facility bear interest at a rate per annum of 0.6% plus LIBOR.  The Company may voluntarily repay outstanding loans under the China Revolving Credit Facility at any time without premium or penalty, other than customary "breakage" costs.  The facility will expire on October 31, 2018.  As of November 3, 2017, there were no outstanding borrowings under the China Revolving Credit Facility.

- added (2018-06-12):
[0001571996-18-000022:note_history:97]
Unsecured Debt

- changed (2018-06-12):
[0001571996-18-000022:note_history:98]
Unsecured Notes and Debentures — The Company has outstanding unsecured notes and debentures (collectively, the "Unsecured Notes and Debentures") that were issued prior to the acquisition of Dell by Dell Technologies Inc. in the going-private transaction that closed in October 2013.  Interest on these borrowings is payable semiannually.
  (was, 2017-12-12, similarity 0.8086):
[0001571996-17-000045:note_history:98]
Unsecured Notes and Debentures — The Company has outstanding unsecured notes and debentures (collectively, the "Unsecured Notes and Debentures") that were issued prior to the acquisition of Dell by Dell Technologies Inc.  Interest on these borrowings is payable semiannually.

- changed (2018-06-12):
[0001571996-18-000022:note_history:99]
VMware Notes — On August 21, 2017, VMware, Inc. completed a public offering of unsecured senior notes in the aggregate amount of $4.0 billion, consisting of outstanding principal due on the following dates: $1.25 billion due August 21, 2020, $1.50 billion due August 21, 2022, and $1.25 billion due August 21, 2027 (collectively, the "VMware Notes").  The VMware Notes bear interest, payable semiannually, at annual rates of 2.30%, 2.95%, and 3.90%, respectively.  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.
  (was, 2017-12-12, similarity 0.9924):
[0001571996-17-000045:note_history:99]
VMware Notes — On August 21, 2017, VMware, Inc. completed a public offering of senior notes in the aggregate amount of $4.0 billion, consisting of outstanding principal due on the following dates: $1.25 billion due August 21, 2020, $1.50 billion due August 21, 2022, and $1.25 billion due August 21, 2027 (collectively, the "VMware Notes"). The VMware Notes bear interest, payable semiannually, at annual rates of 2.30%, 2.95%, and 3.90%, respectively.  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.

- changed (2018-06-12):
[0001571996-18-000022:note_history:100]
VMware Revolving Credit Facility —  On September 12, 2017, VMware, Inc. entered into an unsecured credit agreement, establishing a revolving credit facility (the “VMware Revolving Credit Facility”), with a syndicate of lenders that provides the company with a borrowing capacity of up to $1.0 billion which may be used for VMware, Inc. general corporate purposes.  Commitments under the VMware Revolving Credit Facility are available for a period of five years, which may be extended, subject to the satisfaction of certain conditions, by up to two one year periods.  The credit agreement contains certain representations, warranties, and covenants.  Commitment fees, interest rates, and other terms of borrowing under the VMware Revolving Credit Facility may vary based on VMware, Inc.’s external credit ratings.  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.  As of May 4, 2018, there were no outstanding borrowings under the VMware Revolving Credit Facility.
  (was, 2017-12-12, similarity 0.9111):
[0001571996-17-000045:note_history:100]
VMware Revolving Credit Facility —  On September 12, 2017, VMware, Inc. entered into an unsecured credit agreement, establishing a revolving credit facility (the “VMware Revolving Credit Facility”), with a syndicate of lenders that provides the company with a borrowing capacity of up to $1.0 billion which may be used for VMware, Inc. corporate purposes.  Commitments under the VMware Revolving Credit Facility are available for a period of five years, which may be extended, subject to the satisfaction of certain conditions, by up to two one year periods.  As of November 3, 2017, there were no outstanding borrowings under the VMware Revolving Credit Facility.  The credit agreement contains certain representations, warranties, and covenants. Commitment fees, interest rates, and other terms of borrowing under the VMware Revolving Credit Facility may vary based on VMware, Inc.’s external credit ratings.  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.

- added (2018-06-12):
[0001571996-18-000022:note_history:101]
DFS Debt

- added (2018-06-12):
[0001571996-18-000022:note_history:102]
See Note 5 and Note 7 of the Notes to the Condensed Consolidated Financial Statements, respectively, for discussion of DFS debt and the interest rate swap agreements that hedge a portion of that debt.

- added (2018-06-12):
[0001571996-18-000022:note_history:103]
Other

- changed (2018-06-12):
[0001571996-18-000022:note_history:104]
Margin Loan Facility — On April 12, 2017, the Company entered into the Margin Loan Facility in an aggregate principal amount of $2.0 billion.  VMW Holdco LLC, a wholly-owned subsidiary of EMC, is the borrower under the Margin Loan Facility, which is secured by 60 million shares of Class B common stock of VMware, Inc. and 20 million shares of Class A common stock of VMware, Inc.  Loans under the Margin Loan Facility bear interest at a rate per annum payable, at the borrower's option, either at (a) a base rate plus 1.25% per annum or (b) a LIBOR-based rate plus 2.25% per annum.  Interest under the Margin Loan Facility is payable quarterly.
  (was, 2017-12-12, similarity 0.9679):
[0001571996-17-000045:note_history:104]
Margin Loan Facility — During the three months ended May 5, 2017, the Company entered into the Margin Loan Facility in an aggregate principal amount of $2.0 billion.  VMW Holdco LLC, a wholly-owned subsidiary of EMC, is the borrower under the Margin Loan Facility, which is secured by 60 million shares of Class B common stock of VMware, Inc. and 20 million shares of Class A common stock of VMware, Inc.  Loans under the Margin Loan Facility bear interest at a rate per annum payable, at the borrower's option, either at (a) a base rate plus 1.25% per annum or (b) a LIBOR-based rate plus 2.25% per annum.  Interest under the Margin Loan Facility is payable quarterly.

- changed (2018-06-12):
[0001571996-18-000022:note_history:105]
Pivotal Revolving Credit Facility — On September 7, 2017, Pivotal entered into a credit agreement (the "Pivotal Revolving Credit Facility") that provides for a senior secured revolving loan facility in an aggregate principal amount not to exceed $100 million.  The credit facility contains customary representations, warranties, and covenants, including financial covenants.  The credit agreement will expire on September 8, 2020, unless it is terminated earlier.  None of the net proceeds of borrowings under the facility will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of Pivotal and Pivotal's subsidiaries.  As of May 4, 2018, there were no outstanding borrowings under the Pivotal Revolving Credit Facility.
  (was, 2017-12-12, similarity 0.7031):
[0001571996-17-000045:note_history:105]
Pivotal Revolving Credit Facility — On September 7, 2017, Pivotal entered into a credit agreement (the "Pivotal Revolving Credit Facility") with Silicon Valley Bank and certain other banks for a senior secured revolving loan facility in an aggregate principal amount not to exceed $100 million.  The credit facility contains customary representations, warranties, and covenants, including financial covenants that require compliance with minimum earnings attainment and liquidity ratios as well as covenants by Pivotal limiting additional indebtedness, liens, guaranties, mergers and consolidations, asset sales, investments and loans, sale and leasebacks, transactions with affiliates and fundamental changes. The credit agreement will expire on September 8, 2020, unless it is terminated by Pivotal or an event of default has occurred prior to such date.  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of Pivotal and Pivotal's subsidiaries.  As of November 3, 2017, there were no outstanding borrowings under the Pivotal Revolving Credit Facility.

- added (2018-06-12):
[0001571996-18-000022:note_history:106]
Aggregate Future Maturities

- changed (2018-06-12):
[0001571996-18-000022:note_history:107]
As of May 4, 2018, aggregate future maturities of the Company's debt were as follows:
  (was, 2017-12-12, similarity 0.8):
[0001571996-17-000045:note_history:107]
Aggregate Future Maturities — As of November 3, 2017, aggregate future maturities of the Company's debt were as follows:

- changed (2018-06-12):
[0001571996-18-000022:note_history:108]
|  | Maturities by Fiscal Year |
|  | 2019 (remaining nine months) |  | 2020 |  | 2021 |  | 2022 |  | 2023 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Secured Credit Facilities and First Lien Notes | $ | 1,473 |  |  | $ | 4,245 |  |  | $ | 371 |  |  | $ | 7,888 |  |  | $ | 63 |  |  | $ | 16,487 |  |  | $ | 30,527 |  |
| Unsecured Notes and Debentures | — |  |  | 600 |  |  | — |  |  | 400 |  |  | — |  |  | 952 |  |  | 1,952 |  |
| Senior Notes and EMC Notes | 2,500 |  |  | — |  |  | 2,000 |  |  | 1,625 |  |  | — |  |  | 2,625 |  |  | 8,750 |  |
| VMware Notes | — |  |  | — |  |  | 1,250 |  |  | — |  |  | 1,500 |  |  | 1,250 |  |  | 4,000 |  |
| DFS Debt | 2,565 |  |  | 1,538 |  |  | 1,158 |  |  | 84 |  |  | 13 |  |  | 1 |  |  | 5,359 |  |
| Margin Loan Facility | — |  |  | — |  |  | — |  |  | — |  |  | 2,000 |  |  | — |  |  | 2,000 |  |
| Other | 11 |  |  | 10 |  |  | 46 |  |  | — |  |  | — |  |  | 32 |  |  | 99 |  |
| Total maturities, principal amount | 6,549 |  |  | 6,393 |  |  | 4,825 |  |  | 9,997 |  |  | 3,576 |  |  | 21,347 |  |  | 52,687 |  |
| Associated carrying value adjustments | (8 | ) |  | (27 | ) |  | (8 | ) |  | (178 | ) |  | (30 | ) |  | (533 | ) |  | (784 | ) |
| Total maturities, carrying value amount | $ | 6,541 |  |  | $ | 6,366 |  |  | $ | 4,817 |  |  | $ | 9,819 |  |  | $ | 3,546 |  |  | $ | 20,814 |  |  | $ | 51,903 |  |
  (was, 2017-12-12, similarity 0.7379):
[0001571996-17-000045:note_history:108]
|  | Maturities by Fiscal Year |
|  | 2018 (remaining three months) |  | 2019 |  | 2020 |  | 2021 |  | 2022 |  | Thereafter |  | Total |
|  | (in millions) |
| Structured Financing Debt | $ | 909 |  |  | $ | 2,470 |  |  | $ | 649 |  |  | $ | 254 |  |  | $ | 62 |  |  | $ | 4 |  |  | $ | 4,348 |  |
| Senior Secured Credit Facilities and First Lien Notes | 81 |  |  | 1,765 |  |  | 4,245 |  |  | 371 |  |  | 7,888 |  |  | 16,538 |  |  | 30,888 |  |
| Unsecured Notes and Debentures | — |  |  | 500 |  |  | 600 |  |  | — |  |  | 400 |  |  | 953 |  |  | 2,453 |  |
| Senior Notes and EMC Notes | — |  |  | 2,500 |  |  | — |  |  | 2,000 |  |  | 1,625 |  |  | 2,625 |  |  | 8,750 |  |
| VMware Notes | — |  |  | — |  |  | — |  |  | 1,250 |  |  | — |  |  | 2,750 |  |  | 4,000 |  |
| Margin Loan Facility | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 2,000 |  |  | 2,000 |  |
| Other | 13 |  |  | 10 |  |  | 8 |  |  | 26 |  |  | — |  |  | 26 |  |  | 83 |  |
| Total maturities, principal amount | 1,003 |  |  | 7,245 |  |  | 5,502 |  |  | 3,901 |  |  | 9,975 |  |  | 24,896 |  |  | 52,522 |  |
| Associated carrying value adjustments | (1 | ) |  | (24 | ) |  | (40 | ) |  | (10 | ) |  | (206 | ) |  | (590 | ) |  | (871 | ) |
| Total maturities, carrying value amount | $ | 1,002 |  |  | $ | 7,221 |  |  | $ | 5,462 |  |  | $ | 3,891 |  |  | $ | 9,769 |  |  | $ | 24,306 |  |  | $ | 51,651 |  |

- changed (2018-06-12):
[0001571996-18-000022:note_history:109]
Covenants and Unrestricted Net Assets — The credit agreement for the Senior Secured Credit Facilities contain customary negative covenants that generally limit the ability of Denali Intermediate Inc., a wholly-owned subsidiary of Dell Technologies ("Dell Intermediate"), Dell, and Dell's and Denali Intermediate's other restricted subsidiaries to incur debt, create liens, make fundamental changes, enter into asset sales, make certain investments, pay dividends or distribute or redeem certain equity interests, prepay or redeem certain debt, and enter into certain transactions with affiliates.  The indenture governing the Senior Notes contains customary negative covenants that generally limit the ability of Denali Intermediate, Dell, and Dell's and Denali Intermediate's other restricted subsidiaries to incur additional debt or issue certain preferred shares, pay dividends on or make other distributions in respect of capital stock or make other restricted payments, make certain investments, sell or transfer certain assets, create liens on certain assets to secure debt, consolidate, merge, sell, or otherwise dispose of all or substantially all assets, enter into certain transactions with affiliates, and designate subsidiaries as unrestricted subsidiaries.  The negative covenants under such credit agreements and indenture are subject to certain exceptions, qualifications, and "baskets."  The indentures governing the First Lien Notes, the Unsecured Notes and Debentures, and the EMC Notes variously impose limitations, subject to specified exceptions, on creating certain liens, entering into sale and lease-back transactions, and entering into certain asset sales.  The foregoing credit agreements and indentures contain customary events of default, including failure to make required payments, failure to comply with covenants, and the occurrence of certain events of bankruptcy and insolvency.
  (was, 2017-12-12, similarity 0.9399):
[0001571996-17-000045:note_history:109]
Covenants and Unrestricted Net Assets — The credit agreement for the Senior Secured Credit Facilities contain customary negative covenants that generally limit the ability of Denali Intermediate Inc., a wholly-owned subsidiary of Dell Technologies ("Dell Intermediate"), Dell, and Dell's and Denali Intermediate's other restricted subsidiaries to incur debt, create liens, make fundamental changes, enter into asset sales, make certain investments, pay dividends or distribute or redeem certain equity interests, prepay or redeem certain debt, and enter into certain transactions with affiliates.  The indenture governing the Senior Notes contains customary negative covenants that generally limit the ability of Denali Intermediate, Dell, and Dell's and Denali Intermediate's other restricted subsidiaries to incur additional debt or issue certain preferred shares, pay dividends on or make other distributions in respect of capital stock or make other restricted payments, make certain investments, sell or transfer certain assets, create liens on certain assets to secure debt, consolidate, merge, sell, or otherwise dispose of all or substantially all assets, enter into certain transactions with affiliates, and designate subsidiaries as unrestricted subsidiaries.  The negative covenants under such credit agreements and indenture are subject to certain exceptions, qualifications, and "baskets."  The indentures governing the First Lien Notes, the Unsecured Notes and Debentures, and the EMC Notes variously impose limitations, subject to specified exceptions, on creating certain liens, entering into sale and lease-back transactions, and entering into certain asset sales.  As of November 3, 2017, the Company had certain consolidated subsidiaries that were designated as unrestricted subsidiaries for all purposes of the applicable credit agreements and the indentures governing the First Lien Notes and the Senior Notes.  The foregoing credit agreements and indentures contain customary events of default, including failure to make required payments, failure to comply with covenants, and the occurrence of certain events of bankruptcy and insolvency.

- added (2018-06-12):
[0001571996-18-000022:note_history:110]
As of May 4, 2018, the Company had certain consolidated subsidiaries that were designated as unrestricted subsidiaries for all purposes of the applicable credit agreements and the indentures governing the First Lien Notes and the Senior Notes.

- changed (2018-06-12):
[0001571996-18-000022:note_history:111]
The Term Loan A-2 Facility, the Term Loan A-3 Facility, and the Revolving Credit Facility are subject to a first lien net leverage ratio covenant that is tested at the end of each fiscal quarter of Dell with respect to Dell's preceding four fiscal quarters.  The Company was in compliance with all financial covenants as of May 4, 2018.
  (was, 2017-12-12, similarity 0.9835):
[0001571996-17-000045:note_history:111]
The Term Loan A-2 Facility, the Term Loan A-3 Facility, and the Revolving Credit Facility are subject to a first lien net leverage ratio covenant that is tested at the end of each fiscal quarter of Dell with respect to Dell's preceding four fiscal quarters.  The Company was in compliance with all financial covenants as of November 3, 2017.

- removed (2018-06-12):
[0001571996-17-000045:note_history:112]
|  | November 3, 2017 |  | February 3, 2017 |
|  | (in millions) |
| Secured Debt |  |  |  |
| Structured financing debt | $ | 4,348 |  |  | $ | 3,464 |  |
| Senior Secured Credit Facilities: |  |  |  |
| 3.25% Term Loan B Facility due September 2023 | 5,000 |  |  | 4,987 |  |
| Term Loan A-1 Facility due December 2018 | — |  |  | 600 |  |
| 3.00% Term Loan A-2 Facility due September 2021 | 4,450 |  |  | 3,876 |  |
| 2.75% Term Loan A-3 Facility due December 2018 | 1,438 |  |  | 1,800 |  |
| 2.75% Revolving Credit Facility due September 2021 | — |  |  | 375 |  |
| First Lien Notes: |  |  |  |
| 3.48% due June 2019 | 3,750 |  |  | 3,750 |  |
| 4.42% due June 2021 | 4,500 |  |  | 4,500 |  |
| 5.45% due June 2023 | 3,750 |  |  | 3,750 |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 8.10% due June 2036 | 1,500 |  |  | 1,500 |  |
| 8.35% due June 2046 | 2,000 |  |  | 2,000 |  |
| Unsecured Debt |  |  |  |
| Unsecured Notes and Debentures: |  |  |  |
| 5.65% due April 2018 | 500 |  |  | 500 |  |
| 5.875% due June 2019 | 600 |  |  | 600 |  |
| 4.625% due April 2021 | 400 |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 265 |  |  | 265 |  |
| Senior Notes: |  |  |  |
| 5.875% due June 2021 | 1,625 |  |  | 1,625 |  |
| 7.125% due June 2024 | 1,625 |  |  | 1,625 |  |
| EMC Notes: |  |  |  |
| 1.875% due June 2018 | 2,500 |  |  | 2,500 |  |
| 2.650% due June 2020 | 2,000 |  |  | 2,000 |  |
| 3.375% due June 2023 | 1,000 |  |  | 1,000 |  |
| VMware Notes: |  |  |  |
| 2.30% due August 2020 | 1,250 |  |  | — |  |
| 2.95% due August 2022 | 1,500 |  |  | — |  |
| 3.90% due August 2027 | 1,250 |  |  | — |  |
| Other |  |  |  |
| 3.63% Margin Loan Facility due April 2022 | 2,000 |  |  | — |  |
| Margin Bridge Facility due September 2017 | — |  |  | 2,500 |  |
| VMware Note Bridge Facility due September 2017 | — |  |  | 1,500 |  |
| Other | 83 |  |  | 51 |  |
| Total debt, principal amount | $ | 52,522 |  |  | $ | 50,356 |  |
| Unamortized discount, net of unamortized premium | (268 | ) |  | (284 | ) |
| Debt issuance costs | (603 | ) |  | (682 | ) |
| Total debt, carrying value | $ | 51,651 |  |  | $ | 49,390 |  |
| Total short-term debt, carrying value | $ | 6,235 |  |  | $ | 6,329 |  |
| Total long-term debt, carrying value | $ | 45,416 |  |  | $ | 43,061 |  |

- removed (2018-06-12):
[0001571996-17-000045:note_history:113]
During the nine months ended November 3, 2017 the Company completed two refinancing transactions of the Senior Secured Credit Facilities described below.  In the first refinancing transaction, which occurred during the three months ended May 5, 2017, the Company refinanced the Term Loan B Facility to reduce the interest rate margin by 0.75% and to increase the outstanding principal amount by $500 million.  The Company applied the proceeds from the Term Loan B Facility refinancing to repay $500 million principal amount of the Margin Bridge Facility, without premium or penalty, and accrued and unpaid interest thereon.  Additionally, during the three months ended May 5, 2017, the Company entered into the Margin Loan Facility in the principal amount of $2.0 billion, and used the proceeds of the new facility to repay the Margin Bridge Facility, without premium or penalty.

- removed (2018-06-12):
[0001571996-17-000045:note_history:114]
In the second refinancing transaction, which occurred during the three months ended November 3, 2017, the Company refinanced the Term Loan A-2 Facility, Term Loan A-3 Facility, Term Loan B Facility, and the Revolving Credit Facility.  As a result, the interest rate margin decreased 0.50% for each of the Term Loan A-2 Facility, Term Loan A-3 Facility, Term Loan B Facility, and the Revolving Credit Facility.  Additionally, the outstanding principal amount of the Term Loan A-2 Facility increased by $672 million which was used to pay $212 million of principal outstanding of the Term Loan A-3 Facility and $460 million of principal outstanding of the Term Loan B Facility.  Further, the Revolving Credit Facility's borrowing capacity increased $180 million to $3.3 billion.

- removed (2018-06-12):
[0001571996-17-000045:note_history:115]
During the nine months ended November 3, 2017, the Company repaid approximately $0.9 billion principal amount of its term loan facilities and $0.4 billion under the Revolving Credit Facility and issued an additional $0.9 billion, net, in structured financing debt to support the expansion of its financing receivables portfolio.

- removed (2018-06-12):
[0001571996-17-000045:note_history:116]
Further, during the three months ended November 3, 2017, VMware, Inc. completed a public offering of senior notes in the aggregate amount of $4.0 billion.  VMware, Inc. used a portion of the net proceeds from the offering to repay certain intercompany promissory notes previously issued by it to EMC in the aggregate principal amount of $1.2 billion.  The Company applied the proceeds of this repayment, and other cash, to repay $1.5 billion principal amount of the VMware Note Bridge Facility, without premium or penalty.

- removed (2018-06-12):
[0001571996-17-000045:note_history:117]
Margin Bridge Facility — On September 7, 2016, Merger Sub and EMC entered into a credit agreement providing for a senior secured margin bridge facility in an aggregate principal amount of $2.5 billion (the "Margin Bridge Facility").

- removed (2018-06-12):
[0001571996-17-000045:note_history:118]
During the three months ended May 5, 2017, the Company separately applied the proceeds from the Term Loan B Facility refinancing and the issuance of the Margin Loan Facility to repay the Margin Bridge Facility, without premium or penalty.

- removed (2018-06-12):
[0001571996-17-000045:note_history:119]
VMware Note Bridge Facility — On September 7, 2016, Merger Sub and EMC entered into a credit agreement providing for a senior secured note bridge facility in an aggregate principal amount of $1.5 billion (the "VMware Note Bridge Facility").  As described above, the Company repaid the VMware Note Bridge Facility during the three months ended November 3, 2017.

- removed (2018-06-12):
[0001571996-17-000045:note_history:120]
Structured Financing Debt — As of November 3, 2017 and February 3, 2017, the Company had $4.3 billion and $3.5 billion, respectively, in outstanding structured financing debt, which was primarily related to the fixed-term lease and loan securitization programs and the revolving loan securitization programs.  See Note 6 and Note 8 of the Notes to the Condensed Consolidated Financial Statements for further discussion of the structured financing debt and the interest rate swap agreements that hedge a portion of that debt.


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-06-12):
[0001571996-18-000022:note_history:121]
|  | May 4, 2018 |  | February 2, 2018 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Secured Credit Facilities | $ | 10.4 |  |  | $ | 10.6 |  |  | $ | 10.4 |  |  | $ | 10.6 |  |
| First Lien Notes | $ | 19.7 |  |  | $ | 21.2 |  |  | $ | 19.7 |  |  | $ | 21.9 |  |
| Unsecured Notes and Debentures | $ | 1.8 |  |  | $ | 2.0 |  |  | $ | 2.3 |  |  | $ | 2.5 |  |
| Senior Notes | $ | 3.1 |  |  | $ | 3.4 |  |  | $ | 3.1 |  |  | $ | 3.4 |  |
| EMC Notes | $ | 5.5 |  |  | $ | 5.4 |  |  | $ | 5.5 |  |  | $ | 5.4 |  |
| VMware Notes | $ | 4.0 |  |  | $ | 3.8 |  |  | $ | 4.0 |  |  | $ | 3.9 |  |
| Margin Loan Facility | $ | 2.0 |  |  | $ | 2.0 |  |  | $ | 2.0 |  |  | $ | 2.0 |  |
  (was, 2017-12-12, similarity 0.8937):
[0001571996-17-000045:note_history:121]
|  | November 3, 2017 |  | February 3, 2017 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Secured Credit Facilities | $ | 10.7 |  |  | $ | 10.9 |  |  | $ | 11.4 |  |  | $ | 11.7 |  |
| First Lien Notes | $ | 19.7 |  |  | $ | 22.2 |  |  | $ | 19.7 |  |  | $ | 21.8 |  |
| Unsecured Notes and Debentures | $ | 2.3 |  |  | $ | 2.5 |  |  | $ | 2.3 |  |  | $ | 2.5 |  |
| Senior Notes | $ | 3.1 |  |  | $ | 3.5 |  |  | $ | 3.1 |  |  | $ | 3.5 |  |
| EMC Notes | $ | 5.5 |  |  | $ | 5.4 |  |  | $ | 5.5 |  |  | $ | 5.4 |  |
| VMware Notes | $ | 4.0 |  |  | $ | 4.0 |  |  | $ | — |  |  | $ | — |  |
| Margin Loan Facility | $ | 2.0 |  |  | $ | 2.0 |  |  | $ | — |  |  | $ | — |  |
| Bridge Facilities | $ | — |  |  | $ | — |  |  | $ | 4.0 |  |  | $ | 4.0 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2018-06-12):
[0001571996-18-000022:note_history:122]
The following table summarizes DFS debt as of the periods indicated.  The table excludes the allocated portion of the Company's other borrowings, which represents the additional amount considered to fund the DFS business.

- added (2018-06-12):
[0001571996-18-000022:note_history:123]
|  | May 4, 2018 |  | February 2, 2018 |
|  | (in millions) |
| DFS U.S. debt |  |  |  |
| Securitization facilities | $ | 2,256 |  |  | $ | 1,498 |  |
| Fixed-term securitization offerings | 1,666 |  |  | 2,034 |  |
| Other | 150 |  |  | 32 |  |
| Total DFS U.S. debt | 4,072 |  |  | 3,564 |  |
| DFS international debt |  |  |  |
| Securitization facility | 471 |  |  | 404 |  |
| Other structured facilities | 618 |  |  | 628 |  |
| Note payable | 198 |  |  | 200 |  |
| Total DFS international debt | 1,287 |  |  | 1,232 |  |
| Total DFS debt | $ | 5,359 |  |  | $ | 4,796 |  |
| Total short-term DFS debt | $ | 3,019 |  |  | $ | 3,327 |  |
| Total long-term DFS debt | $ | 2,340 |  |  | $ | 1,469 |  |

- added (2018-06-12):
[0001571996-18-000022:note_history:124]
|  | May 4, 2018 |  | February 2, 2018 |
|  | (in millions) |
| Secured Debt |  |  |  |
| Senior Secured Credit Facilities: |  |  |  |
| 3.91% Term Loan B Facility due September 2023 | $ | 4,975 |  |  | $ | 4,988 |  |
| 3.66% Term Loan A-2 Facility due September 2021 | 4,339 |  |  | 4,394 |  |
| 3.41% Term Loan A-3 Facility due December 2018 | 1,213 |  |  | 1,213 |  |
| First Lien Notes: |  |  |  |
| 3.48% due June 2019 | 3,750 |  |  | 3,750 |  |
| 4.42% due June 2021 | 4,500 |  |  | 4,500 |  |
| 5.45% due June 2023 | 3,750 |  |  | 3,750 |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 8.10% due July 2036 | 1,500 |  |  | 1,500 |  |
| 8.35% due July 2046 | 2,000 |  |  | 2,000 |  |
| Unsecured Debt |  |  |  |
| Unsecured Notes and Debentures: |  |  |  |
| 5.65% due April 2018 | — |  |  | 500 |  |
| 5.875% due June 2019 | 600 |  |  | 600 |  |
| 4.625% due April 2021 | 400 |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| Senior Notes: |  |  |  |
| 5.875% due June 2021 | 1,625 |  |  | 1,625 |  |
| 7.125% due June 2024 | 1,625 |  |  | 1,625 |  |
| EMC Notes: |  |  |  |
| 1.875% due June 2018 | 2,500 |  |  | 2,500 |  |
| 2.650% due June 2020 | 2,000 |  |  | 2,000 |  |
| 3.375% due June 2023 | 1,000 |  |  | 1,000 |  |
| VMware Notes: |  |  |  |
| 2.30% due August 2020 | 1,250 |  |  | 1,250 |  |
| 2.95% due August 2022 | 1,500 |  |  | 1,500 |  |
| 3.90% due August 2027 | 1,250 |  |  | 1,250 |  |
| DFS Debt (Note 5) | 5,359 |  |  | 4,796 |  |
| Other |  |  |  |
| 4.61% Margin Loan Facility due April 2022 | 2,000 |  |  | 2,000 |  |
| Other | 99 |  |  | 101 |  |
| Total debt, principal amount | $ | 52,687 |  |  | $ | 52,694 |  |

- added (2018-06-12):
[0001571996-18-000022:note_history:125]
|  | May 4, 2018 |  | February 2, 2018 |
|  | (in millions) |
| Total debt, principal amount | $ | 52,687 |  |  | $ | 52,694 |  |
| Unamortized discount, net of unamortized premium | (256 | ) |  | (266 | ) |
| Debt issuance costs | (528 | ) |  | (557 | ) |
| Total debt, carrying value | $ | 51,903 |  |  | $ | 51,871 |  |
| Total short-term debt, carrying value | $ | 7,133 |  |  | $ | 7,873 |  |
| Total long-term debt, carrying value | $ | 44,770 |  |  | $ | 43,998 |  |

- removed (2018-06-12):
[0001571996-17-000045:note_history:126]
|  | November 3, 2017 |  | February 3, 2017 |
|  | (in millions) |
| Secured Debt |  |  |  |
| Structured financing debt | $ | 4,348 |  |  | $ | 3,464 |  |
| Senior Secured Credit Facilities: |  |  |  |
| 3.25% Term Loan B Facility due September 2023 | 5,000 |  |  | 4,987 |  |
| Term Loan A-1 Facility due December 2018 | — |  |  | 600 |  |
| 3.00% Term Loan A-2 Facility due September 2021 | 4,450 |  |  | 3,876 |  |
| 2.75% Term Loan A-3 Facility due December 2018 | 1,438 |  |  | 1,800 |  |
| 2.75% Revolving Credit Facility due September 2021 | — |  |  | 375 |  |
| First Lien Notes: |  |  |  |
| 3.48% due June 2019 | 3,750 |  |  | 3,750 |  |
| 4.42% due June 2021 | 4,500 |  |  | 4,500 |  |
| 5.45% due June 2023 | 3,750 |  |  | 3,750 |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 8.10% due June 2036 | 1,500 |  |  | 1,500 |  |
| 8.35% due June 2046 | 2,000 |  |  | 2,000 |  |
| Unsecured Debt |  |  |  |
| Unsecured Notes and Debentures: |  |  |  |
| 5.65% due April 2018 | 500 |  |  | 500 |  |
| 5.875% due June 2019 | 600 |  |  | 600 |  |
| 4.625% due April 2021 | 400 |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 265 |  |  | 265 |  |
| Senior Notes: |  |  |  |
| 5.875% due June 2021 | 1,625 |  |  | 1,625 |  |
| 7.125% due June 2024 | 1,625 |  |  | 1,625 |  |
| EMC Notes: |  |  |  |
| 1.875% due June 2018 | 2,500 |  |  | 2,500 |  |
| 2.650% due June 2020 | 2,000 |  |  | 2,000 |  |
| 3.375% due June 2023 | 1,000 |  |  | 1,000 |  |
| VMware Notes: |  |  |  |
| 2.30% due August 2020 | 1,250 |  |  | — |  |
| 2.95% due August 2022 | 1,500 |  |  | — |  |
| 3.90% due August 2027 | 1,250 |  |  | — |  |
| Other |  |  |  |
| 3.63% Margin Loan Facility due April 2022 | 2,000 |  |  | — |  |
| Margin Bridge Facility due September 2017 | — |  |  | 2,500 |  |
| VMware Note Bridge Facility due September 2017 | — |  |  | 1,500 |  |
| Other | 83 |  |  | 51 |  |
| Total debt, principal amount | $ | 52,522 |  |  | $ | 50,356 |  |
| Unamortized discount, net of unamortized premium | (268 | ) |  | (284 | ) |
| Debt issuance costs | (603 | ) |  | (682 | ) |
| Total debt, carrying value | $ | 51,651 |  |  | $ | 49,390 |  |
| Total short-term debt, carrying value | $ | 6,235 |  |  | $ | 6,329 |  |
| Total long-term debt, carrying value | $ | 45,416 |  |  | $ | 43,061 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-06-12):
[0001571996-18-000022:note_history:127]
As of May 4, 2018, aggregate future maturities of the Company's debt were as follows:
  (was, 2017-12-12, similarity 0.9455):
[0001571996-17-000045:note_history:127]
As of November 3, 2017, aggregate future maturities of the Company's debt were as follows:

- changed (2018-06-12):
[0001571996-18-000022:note_history:128]
|  | Maturities by Fiscal Year |
|  | 2019 (remaining nine months) |  | 2020 |  | 2021 |  | 2022 |  | 2023 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Secured Credit Facilities and First Lien Notes | $ | 1,473 |  |  | $ | 4,245 |  |  | $ | 371 |  |  | $ | 7,888 |  |  | $ | 63 |  |  | $ | 16,487 |  |  | $ | 30,527 |  |
| Unsecured Notes and Debentures | — |  |  | 600 |  |  | — |  |  | 400 |  |  | — |  |  | 952 |  |  | 1,952 |  |
| Senior Notes and EMC Notes | 2,500 |  |  | — |  |  | 2,000 |  |  | 1,625 |  |  | — |  |  | 2,625 |  |  | 8,750 |  |
| VMware Notes | — |  |  | — |  |  | 1,250 |  |  | — |  |  | 1,500 |  |  | 1,250 |  |  | 4,000 |  |
| DFS Debt | 2,565 |  |  | 1,538 |  |  | 1,158 |  |  | 84 |  |  | 13 |  |  | 1 |  |  | 5,359 |  |
| Margin Loan Facility | — |  |  | — |  |  | — |  |  | — |  |  | 2,000 |  |  | — |  |  | 2,000 |  |
| Other | 11 |  |  | 10 |  |  | 46 |  |  | — |  |  | — |  |  | 32 |  |  | 99 |  |
| Total maturities, principal amount | 6,549 |  |  | 6,393 |  |  | 4,825 |  |  | 9,997 |  |  | 3,576 |  |  | 21,347 |  |  | 52,687 |  |
| Associated carrying value adjustments | (8 | ) |  | (27 | ) |  | (8 | ) |  | (178 | ) |  | (30 | ) |  | (533 | ) |  | (784 | ) |
| Total maturities, carrying value amount | $ | 6,541 |  |  | $ | 6,366 |  |  | $ | 4,817 |  |  | $ | 9,819 |  |  | $ | 3,546 |  |  | $ | 20,814 |  |  | $ | 51,903 |  |
  (was, 2017-12-12, similarity 0.7379):
[0001571996-17-000045:note_history:128]
|  | Maturities by Fiscal Year |
|  | 2018 (remaining three months) |  | 2019 |  | 2020 |  | 2021 |  | 2022 |  | Thereafter |  | Total |
|  | (in millions) |
| Structured Financing Debt | $ | 909 |  |  | $ | 2,470 |  |  | $ | 649 |  |  | $ | 254 |  |  | $ | 62 |  |  | $ | 4 |  |  | $ | 4,348 |  |
| Senior Secured Credit Facilities and First Lien Notes | 81 |  |  | 1,765 |  |  | 4,245 |  |  | 371 |  |  | 7,888 |  |  | 16,538 |  |  | 30,888 |  |
| Unsecured Notes and Debentures | — |  |  | 500 |  |  | 600 |  |  | — |  |  | 400 |  |  | 953 |  |  | 2,453 |  |
| Senior Notes and EMC Notes | — |  |  | 2,500 |  |  | — |  |  | 2,000 |  |  | 1,625 |  |  | 2,625 |  |  | 8,750 |  |
| VMware Notes | — |  |  | — |  |  | — |  |  | 1,250 |  |  | — |  |  | 2,750 |  |  | 4,000 |  |
| Margin Loan Facility | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 2,000 |  |  | 2,000 |  |
| Other | 13 |  |  | 10 |  |  | 8 |  |  | 26 |  |  | — |  |  | 26 |  |  | 83 |  |
| Total maturities, principal amount | 1,003 |  |  | 7,245 |  |  | 5,502 |  |  | 3,901 |  |  | 9,975 |  |  | 24,896 |  |  | 52,522 |  |
| Associated carrying value adjustments | (1 | ) |  | (24 | ) |  | (40 | ) |  | (10 | ) |  | (206 | ) |  | (590 | ) |  | (871 | ) |
| Total maturities, carrying value amount | $ | 1,002 |  |  | $ | 7,221 |  |  | $ | 5,462 |  |  | $ | 3,891 |  |  | $ | 9,769 |  |  | $ | 24,306 |  |  | $ | 51,651 |  |


## dvmt:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2018-06-12):
[0001571996-18-000022:note_history:129]
Revenue Recognition — The Company enters into a variety of agreements to provide a wide portfolio of products and services offerings to its customers.  These agreements have varying requirements depending on the goods and services being sold, the rights and obligations conveyed, and the legal jurisdiction of the arrangement.

- added (2018-06-12):
[0001571996-18-000022:note_history:130]
Revenue is recognized either over time or at a point in time, depending on when the underlying goods or services are transferred to the customer, in an amount that reflects the consideration to which the Company expects to be entitled in exchange for delivering those goods or services.  The following five steps are applied to recognize revenue:

- added (2018-06-12):
[0001571996-18-000022:note_history:131]
| (1) | Identify the contract with a customer. The term “contract” refers to the enforceable rights and obligations provided in an agreement between the Company and one or more other parties in exchange for payment. The Company evaluates facts and circumstances regarding sales transactions in order to identify contracts with its customers. An agreement must meet all of the following criteria to qualify as a contract eligible for revenue recognition under the model: (i) the contract must be approved by all parties; (ii) each party's rights regarding the goods and services to be transferred to the customer can be identified; (iii) the payment terms for the good and services can be identified; (iv) the customer has the ability and intent to pay and it is probable that the Company will collect substantially all of the consideration to which it will be entitled; and (v) the contract must have commercial substance. Judgment is used in determining the customer's ability and intent to pay, which is based upon factors including the customer's historical payment experience or customer credit and financial information. |

- added (2018-06-12):
[0001571996-18-000022:note_history:132]
| (2) | Identify the performance obligations in the contract. Distinct promises within a contract are referred to as "performance obligations" and are accounted for as separate units of account. The Company assesses whether each promised good or service is distinct for the purpose of identifying the performance obligations in the contract. This assessment involves subjective determinations and requires management to make judgments about the individual promised goods or services and whether such goods or services are separable from the other aspects of the contractual relationship. Promised goods and services are considered distinct provided that: (i) the customer can benefit from the good or service either on its own or together with other resources that are readily available to the customer (that is, the good or service is capable of being distinct); and (ii) the Company's promise to transfer the good or service to the customer is separately identifiable from other promises in the contract (that is, the promise to transfer the good or service is distinct within the context of the contract). The Company's performance obligations consist of a variety of products and services offerings which include: computer and enterprise hardware, such as servers, storage, networking products, personal computers, workstations and peripherals; third-party software; proprietary software licenses; support and deployment services, including hardware support that extends beyond the Company's standard warranties, software maintenance, and installation; professional services; training; software as a service ("SaaS"); and infrastructure as a service ("IaaS"). |

- added (2018-06-12):
[0001571996-18-000022:note_history:133]
| (3) | Determine the transaction price. Transaction price reflects the amount of consideration to which the Company expects to be entitled in exchange for transferring goods or services to the customer. If the consideration promised in a contract includes a variable amount, the Company estimates the amount to which it expects to be entitled using either the expected value or most likely amount method. The Company’s contracts may include terms that could cause variability in the transaction price, including, for example, rebates, sales returns, and volume discounts. In determining the transaction price, any variable consideration would be considered, to the extent applicable, if it is probable that a significant future reversal of cumulative revenue under the contract will not occur when the uncertainty associated with the variable consideration is resolved. |

- added (2018-06-12):
[0001571996-18-000022:note_history:134]
| (4) | Allocate the transaction price to performance obligations in the contract. Many of the Company’s contracts include promises to transfer multiple products and services to a customer, and the transaction price must be allocated to each performance obligation in an amount that depicts the consideration to which the Company expects to be entitled in exchange for transferring the promised goods or services. For these contracts with multiple performance obligations, the transaction price is allocated in proportion to the standalone selling price ("SSP") of each performance obligation. If the contract contains a single performance obligation, the entire transaction price is allocated to that performance obligation. |

- added (2018-06-12):
[0001571996-18-000022:note_history:135]
The best evidence of SSP is the observable price of a good or service when the Company sells that good or service separately in similar circumstances to similar customers.  If a directly observable price is available, it must be utilized for the SSP.  If a directly observable price is not available, the SSP must be estimated.  The Company estimates SSP by considering multiple factors including, but not limited to, pricing practices, internal costs, and profit objectives  as well as overall market conditions which include geographic or regional specific factors, competitive positioning, and competitor actions.  SSP can include fixed and variable components.  Variable components are estimated based on the most likely outcome or expected value of the variable components.

- added (2018-06-12):
[0001571996-18-000022:note_history:136]
| (5) | Recognize revenue when (or as) the performance obligation is satisfied. Revenue is recognized when obligations under the terms of the contract with our customer are satisfied. Revenue is recognized either over time or at a point in time, depending on when the underlying products or services are transferred to the customer. Revenue is recorded at a point in time for products upon transfer of control. Revenue is recognized over time for support services, professional services, training, SaaS, and IaaS. |

- added (2018-06-12):
[0001571996-18-000022:note_history:137]
The Company reports revenue net of any revenue-based taxes assessed by governmental authorities that are imposed on and concurrently with specific revenue-producing transactions.

- added (2018-06-12):
[0001571996-18-000022:note_history:138]
The Company has elected the following practical expedients with the adoption of the new revenue standard:

- added (2018-06-12):
[0001571996-18-000022:note_history:139]
| • | The Company does not account for significant financing components if the period between revenue recognition and when the customer pays for the product or service will be one year or less. |

- added (2018-06-12):
[0001571996-18-000022:note_history:140]
| • | The Company recognizes revenue equal to the amount it has a right to invoice when the amount corresponds directly with the value to the customer of the Company's performance to date. |

- added (2018-06-12):
[0001571996-18-000022:note_history:141]
| • | The Company does not account for shipping and handling activities as a separate performance obligation, but rather as an activity performed to transfer the promised good. |

- added (2018-06-12):
[0001571996-18-000022:note_history:142]
The following summarizes the nature of revenue recognized and the manner in which the Company accounts for sales transactions.

- added (2018-06-12):
[0001571996-18-000022:note_history:143]
Products

- added (2018-06-12):
[0001571996-18-000022:note_history:144]
Product revenue consists of hardware and software license sales that are delivered, sold as a subscription or sold on a consumption basis.  Hardware includes notebooks and desktop PCs, servers, storage hardware, and other hardware-related devices.  Software license sales include non-essential, stand-alone software applications.  Software applications provide customers with resource management, backup and archiving, information security, information management and intelligence, data analytics, and server virtualization capabilities.

- added (2018-06-12):
[0001571996-18-000022:note_history:145]
Revenue from the sale of hardware products is recognized when control has transferred to the customer, which typically occurs when the hardware has been shipped to the customer, risk of loss has transferred to the customer, the Company has a present right to payment, and customer acceptance has been satisfied.  Customer acceptance is satisfied if acceptance is obtained from the customer, if all acceptance provisions lapse, or if the Company has evidence that all acceptance provisions will be, or have been, satisfied.  Revenue from software license sales is generally recognized when control has transferred to the customer, which is typically upon shipment, electronic delivery, or when the software is available for download by the customer.  For certain arrangements, including software subscriptions and certain software license agreements which provide customers control to certain product performance obligations over time, revenue is recognized based on usage or ratably over the term of the arrangement based on the pattern of delivery of the product to the customer.

- added (2018-06-12):
[0001571996-18-000022:note_history:146]
Invoices for products are generally issued as control transfers, which is typically upon shipment or electronic delivery.  There was no significant revenue in any period presented related to performance obligations satisfied or partially satisfied in prior periods.

- added (2018-06-12):
[0001571996-18-000022:note_history:147]
Services

- added (2018-06-12):
[0001571996-18-000022:note_history:148]
Services revenue consists of revenue from sales of support services, including hardware support that extends beyond the Company's standard warranties, software maintenance, and installation; professional services; training; SaaS; and IaaS.  Revenue associated with undelivered performance obligations is deferred and recorded as control is transferred to the customer over time.  Revenue from fixed-price support or maintenance contracts sold for both hardware and software is recognized on a straight-line basis over the period of performance because the Company is required to provide services at any given time.  Other services revenue is recognized when the Company performs the services and the customers receive and consume the benefits.

- added (2018-06-12):
[0001571996-18-000022:note_history:149]
Invoices for services may be issued at the start of a service term, which is typically the case for support and deployment services, or as services are rendered, which is typically the case for professional services, training, SaaS, and IaaS.

- added (2018-06-12):
[0001571996-18-000022:note_history:150]
Other

- added (2018-06-12):
[0001571996-18-000022:note_history:151]
Revenue from leasing arrangements is not subject to the new revenue standard from contracts with customers, and remains separately accounted for under existing lease accounting guidance.  The Company records revenue from the sale of equipment under sales-type leases as product revenue in an amount equal to the present value of minimum lease payments at the inception of the lease.  Sales-type leases also produce financing income, which is included in net products revenue in the Consolidated Statements of Income (Loss) and is recognized at consistent rates of return over the lease term.  The Company also offers qualified customers fixed-term loans and revolving credit lines for the purchase of products and services offered by the Company.  Financing income attributable to these loans is recognized in product revenue on an accrual basis.

- added (2018-06-12):
[0001571996-18-000022:note_history:152]
Disaggregation of Revenue — The Company's revenue is presented on a disaggregated basis on the Condensed Consolidated Statements of Income (Loss) and in Note 18 of the Notes to the Condensed Consolidated Financial Statements based on an evaluation of disclosures outside of the financial statements, information regularly reviewed by the chief operating decision maker for evaluating the financial performance of operating segments, and other information that is used to evaluate the Company's financial performance or make resource allocations.  This information includes revenue from product and services, revenue from reportable segments, and revenue by major product lines within the segments.

- added (2018-06-12):
[0001571996-18-000022:note_history:153]
Contract Assets — Contract assets are rights to consideration in exchange for goods or services that the Company has transferred to a customer when such a right is conditional on something other than the passage of time.  Such amounts have been insignificant to date.

- added (2018-06-12):
[0001571996-18-000022:note_history:154]
Contract Liabilities — Contract liabilities primarily consist of deferred revenue.  Deferred revenue is recorded when the Company has a right to invoice or payments have been received for undelivered products or services, or in situations where revenue recognition criteria have not been met.  Deferred revenue also represents amounts received in advance for extended warranty services and software maintenance.  Revenue is recognized on these items when the revenue recognition criteria are met, generally resulting in ratable recognition over the contract term.  The Company also has deferred revenue related to undelivered hardware and professional services, consisting of installations and consulting engagements, which are recognized as the Company's performance obligations under the contract are completed.  See Note 9 of the Notes to the Condensed Consolidated Financial Statements for additional information about deferred revenue.

- added (2018-06-12):
[0001571996-18-000022:note_history:155]
Costs to Obtain a Contract — The incremental direct costs of obtaining a contract primarily consist of sales commissions and employer taxes related to commission payments.  The Company has elected, as a practical expedient, to expense as incurred costs to obtain a contract equal to or less than one year in duration.  For contracts greater than one year in duration, the associated costs to obtain a contract are deferred and amortized over the period of contract performance or a longer period, generally the estimated life of the customer relationship, if renewals are expected and the renewal commission is not commensurate with the initial commission.  Deferred costs to obtain a contract are typically amortized over a period of 3 to 7 years, depending on the contract term and expectation of the period of benefit for the costs, which may exceed the contract term.  Amortization expense is recognized on a straight-line basis and included in selling, general, and administrative expenses in the Condensed Consolidated Statements of Income (Loss).  The Company periodically reviews these deferred costs to determine whether events or changes in circumstances have occurred that could impact the carrying value or period of benefit of the deferred sales commissions.  There were no material impairment losses for deferred sales commissions during the three months ended May 4, 2018 and May 5, 2017.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2018-06-12):
[0001571996-18-000022:note_history:156]
The following table presents the disaggregation of net revenue by reportable segment, and by major product categories within the segments:

- added (2018-06-12):
[0001571996-18-000022:note_history:157]
|  | Three Months Ended |
|  | May 4, 2018 |  | May 5, 2017 |
|  | (in millions) |
| Net revenue: |  |  |  |  |  |
| Infrastructure Solutions Group: |  |  |  |
| Servers and networking | $ | 4,585 |  |  | $ | 3,256 |  |
| Storage | 4,082 |  |  | 3,705 |  |
| Total ISG net revenue | 8,667 |  |  | 6,961 |  |
| Client Solutions Group: |  |  |  |
| Commercial | 7,363 |  |  | 6,342 |  |
| Consumer | 2,908 |  |  | 2,706 |  |
| Total CSG net revenue | 10,271 |  |  | 9,048 |  |
| VMware: |  |  |  |
| Total VMware net revenue | 2,028 |  |  | 1,818 |  |
| Total segment net revenue | $ | 20,966 |  |  | $ | 17,827 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2018-06-12):
[0001571996-18-000022:note_history:158]
DEFERRED REVENUE

- added (2018-06-12):
[0001571996-18-000022:note_history:159]
Deferred Revenue — Deferred revenue is recorded when the Company has a right to invoice or payments have been received for undelivered products or services in contracts where transfer of control has not occurred.  Deferred revenue represents amounts received in advance for support and deployment services, software maintenance, professional services, training, and SaaS.  Revenue is recognized on these items when the revenue recognition criteria are met, generally resulting in ratable recognition over the contract term.  The Company also has deferred revenue related to undelivered hardware and professional services, consisting of installations and consulting engagements, which are recognized as the Company's performance obligations under the contract are completed.

- added (2018-06-12):
[0001571996-18-000022:note_history:160]
Changes in the Company's deferred revenue are presented in the following table for the period indicated:

- added (2018-06-12):
[0001571996-18-000022:note_history:161]
|  | Three Months Ended |
|  | May 4, 2018 |
|  | (in millions) |
| Deferred revenue: |  |
| Deferred revenue at beginning of period | $ | 20,816 |  |
| Revenue deferrals for new contracts and changes in estimates for pre-existing contracts (a) | 5,337 |  |
| Revenue recognized | (5,194 | ) |
| Deferred revenue at end of period | $ | 20,959 |  |
| Short-term deferred revenue | $ | 11,495 |  |
| Long-term deferred revenue | $ | 9,464 |  |

- added (2018-06-12):
[0001571996-18-000022:note_history:162]
____________________

- added (2018-06-12):
[0001571996-18-000022:note_history:163]
| (a) | Includes the impact of foreign currency exchange rate fluctuations. |

- added (2018-06-12):
[0001571996-18-000022:note_history:164]
Remaining Performance Obligations — Remaining performance obligations represent the aggregate amount of the transaction price in contracts allocated to performance obligations not delivered, or partially undelivered, as of the end of the reporting period.  Remaining performance obligations include deferred revenue plus unbilled amounts not yet recorded in deferred revenue.  The aggregate amount of transaction price allocated to remaining performance obligations does not include amounts owed under cancelable contracts where there is no substantive termination penalty.

- added (2018-06-12):
[0001571996-18-000022:note_history:165]
The Company applied the practical expedient to exclude the value of remaining performance obligations for contracts for which revenue is recognized at the amount to which the Company has the right to invoice for services performed.  The Company also applied the practical expedient to not disclose the amount of transaction price allocated to remaining performance obligations for the periods prior to adoption of the new revenue standard.

- added (2018-06-12):
[0001571996-18-000022:note_history:166]
Remaining performance obligation estimates are subject to change and are affected by several factors, including terminations, changes in the scope of contracts, periodic revalidation, adjustments for revenue that has not materialized, and adjustments for currency.

- added (2018-06-12):
[0001571996-18-000022:note_history:167]
The value of the transaction price allocated to remaining performance obligations as of May 4, 2018 was approximately $29 billion.  The Company expects to recognize approximately 65% of remaining performance obligations as revenue in the next 12 months, and the remainder thereafter.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2018-06-12):
[0001571996-18-000022:note_history:168]
On May 24, 2018, the Company drew down $500 million under the China Revolving Credit Facility.

- added (2018-06-12):
[0001571996-18-000022:note_history:169]
On June 1, 2018, the Company fully repaid the 1.875% EMC Note in the amount of $2.5 billion in accordance with the contractual maturity date.

- removed (2018-06-12):
[0001571996-17-000045:note_history:170]
On November 27, 2017, DFS entered into a credit agreement that provided for borrowings in an aggregate principal amount of $200 million.  The borrowings will accrue interest at a rate per annum of either 3.67%, if denominated in U.S. dollars, or 9.43%, if denominated in Mexican pesos.  The note will mature on December 1, 2020.

- removed (2018-06-12):
[0001571996-17-000045:note_history:171]
During November 2017, VMware, Inc. entered into a definitive agreement to acquire VeloCloud Networks, Inc. (“VeloCloud”), a provider of cloud-delivered software-defined wide-area network (SD-WAN) technology for enterprises and service providers.  The acquisition of VeloCloud will enable VMware to build on its network virtualization platform, VMware NSX, and expand its networking portfolio.  The cash payment upon closing of the transaction is estimated to be approximately $470 million; however, the determination of the purchase price is dependent upon several factors at the date of closing and cannot be reasonably estimated until such time.  The transaction is expected to close during the fourth quarter of Fiscal 2018 and is subject to regulatory approvals and customary closing conditions.
