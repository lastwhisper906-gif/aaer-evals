# DELL 8-K — 0001571996-18-000019 filed 2018-06-04

## item codes, every 8-K on or before 2018-06-12

- 2018-06-04 0001571996-18-000019 — 2.02, 9.01
- 2018-05-17 0001571996-18-000016 — 7.01
- 2018-04-26 0001571996-18-000009 — 7.01, 9.01
- 2018-03-08 0001193125-18-074168 — 2.02, 9.01
- 2018-02-02 0001193125-18-029947 — 7.01, 9.01
- 2017-12-07 0001571996-17-000042 — 2.02, 9.01
- 2017-10-24 0001571996-17-000037 — 1.01, 2.03, 9.01
- 2017-09-15 0001571996-17-000027 — 5.02
- 2017-09-07 0001571996-17-000017 — 2.02, 9.01
- 2017-08-24 0001571996-17-000014 — 8.01
- 2017-06-29 0001571996-17-000011 — 3.03, 5.07, 8.01, 9.01
- 2017-06-08 0001193125-17-197638 — 2.02, 9.01
- 2017-03-30 0001193125-17-102794 — 8.01
- 2017-03-30 0001193125-17-102777 — 2.02, 9.01
- 2017-03-09 0001193125-17-076981 — 1.01, 2.03, 9.01
- 2017-01-17 0001193125-17-011125 — 8.01
- 2016-12-15 0001193125-16-793722 — 8.01
- 2016-12-08 0001193125-16-787976 — 2.02, 9.01
- 2016-11-10 0001193125-16-765964 — 1.02, 8.01
- 2016-11-04 0001193125-16-760249 — 8.01
- 2016-09-13 0001193125-16-708600 — 3.02
- 2016-09-09 0001193125-16-706567 — 1.01, 1.02, 2.01, 2.03, 3.02, 3.03, 5.02, 9.01
- 2016-09-07 0001193125-16-703370 — 3.03, 5.07, 7.01, 8.01, 9.01
- 2016-09-06 0001193125-16-702057 — 2.02, 9.01
- 2016-08-31 0001193125-16-697268 — 8.01, 9.01
- 2016-08-26 0001193125-16-692921 — 8.01, 9.01
- 2016-07-11 0001193125-16-645610 — 8.01
- 2016-07-05 0001193125-16-641679 — 8.01
- 2016-06-22 0001193125-16-629055 — 1.01, 2.03, 8.01, 9.01
- 2016-06-21 0001193125-16-627071 — 8.01, 9.01
- 2016-06-10 0001193125-16-618483 — 2.02, 9.01
- 2016-06-09 0001193125-16-617893 — 8.01, 9.01

## late-filing notifications on or before 2018-06-12

- none on or before 2018-06-12

## item 2.02 — earnings release, exhibit 99.1

[0001571996-18-000019:8k_2_02:1]
EX-99.1
2
exhibit991earnings8k050418.htm
EXHIBIT 99.1

[0001571996-18-000019:8k_2_02:2]
Exhibit

[0001571996-18-000019:8k_2_02:3]
Exhibit 99.1

[0001571996-18-000019:8k_2_02:4]
News Release

[0001571996-18-000019:8k_2_02:5]
Dell Technologies Reports Fiscal Year 2019 First Quarter

[0001571996-18-000019:8k_2_02:6]
Financial Results

[0001571996-18-000019:8k_2_02:7]
ROUND ROCK, Texas - June 4, 2018

[0001571996-18-000019:8k_2_02:8]
News summary

[0001571996-18-000019:8k_2_02:9]
| • | Strong quarter with revenue of $21.4 billion, up 19 percent |

[0001571996-18-000019:8k_2_02:10]
| • | Double-digit growth in commercial client, servers, storage and VMware |

[0001571996-18-000019:8k_2_02:11]
| • | First quarter of storage share gain since closing the EMC transaction |

[0001571996-18-000019:8k_2_02:12]
| • | Delivered cash flow from operations of $1.2 billion |

[0001571996-18-000019:8k_2_02:13]
Full story

[0001571996-18-000019:8k_2_02:14]
Dell Technologies (NYSE: DVMT) announces its fiscal 2019 first quarter results. For the first quarter, revenue was $21.4 billion, up 19 percent, and non-GAAP revenue was $21.5 billion, up 17 percent from the prior period. During the quarter, the company generated a GAAP operating loss of $153 million1, with a non-GAAP operating income of $2.0 billion, up 42 percent.

[0001571996-18-000019:8k_2_02:15]
“We had a strong first quarter with balanced growth across all business units, regions, and customer segments,” said Tom Sweet, chief financial officer, Dell Technologies. “Our broad set of capabilities, enhanced by our targeted investments over the last year, drove strong top-line momentum and improved profitability, allowing us to generate good operating cash flow and make progress paying down our core debt2.”

[0001571996-18-000019:8k_2_02:16]
The company ended the quarter with a cash and investments balance of $21.7 billion, an increase of $1.4 billion from the prior quarter and an increase of $6.7 billion from last year. Cash generation in the first quarter was seasonally strong given the overall velocity in the business. During the first quarter, Dell Technologies paid down approximately $600 million of core debt, ending the quarter with a core debt balance of $39.8 billion. Subsequent to the end of the quarter, the company paid down another $2.5 billion of core debt bringing the gross debt paid down to $13 billion since the close of the EMC transaction.

[0001571996-18-000019:8k_2_02:17]
Fiscal first quarter 2019 results

[0001571996-18-000019:8k_2_02:18]
|  | Three Months Ended |  |  |
|  | May 4, 2018 |  | May 5, 2017 |  | Change |
|  | (in millions, except percentages; unaudited) |
| Total net revenue | $ | 21,356 |  |  | $ | 18,000 |  |  | 19% |
| Operating loss | $ | (153 | ) |  | $ | (1,272 | ) |  | 88% |
| Net loss | $ | (538 | ) |  | $ | (1,203 | ) |  | 55% |
| Non-GAAP net revenue | $ | 21,543 |  |  | $ | 18,355 |  |  | 17% |
| Non-GAAP operating income | $ | 2,026 |  |  | $ | 1,425 |  |  | 42% |
| Non-GAAP net income | $ | 1,174 |  |  | $ | 761 |  |  | 54% |
| Adjusted EBITDA | $ | 2,383 |  |  | $ | 1,795 |  |  | 33% |

[0001571996-18-000019:8k_2_02:19]
Dell Technologies’ first quarter fiscal 2019 non-GAAP operating income excludes approximately $2.2 billion of adjustments, primarily related to purchase accounting and amortization of intangible assets.

[0001571996-18-000019:8k_2_02:20]
Information about Dell Technologies’ use of non-GAAP financial information is provided under “Non-GAAP Financial Measures” below. All comparisons in this press release are year over year unless otherwise noted.

[0001571996-18-000019:8k_2_02:21]
“The great momentum we saw exiting last year for servers and commercial client continued through the first quarter. We gained share in PCs and servers during the first calendar quarter and, when the numbers are revealed, expect to gain share in storage, as well,” said Jeff Clarke, vice-chairman, Products & Operations, Dell Technologies. “We’re pleased but not satisfied and will continue focusing our energy and resources on what matters most to our customers.”

[0001571996-18-000019:8k_2_02:22]
Operating segments summary

[0001571996-18-000019:8k_2_02:23]
Infrastructure Solutions Group revenue for the first quarter was $8.7 billion, a 25 percent increase. This was driven by 41 percent year-over-year growth in servers and networking to $4.6 billion and 10 percent growth in storage to $4.1 billion. Operating income was $939 million or 10.8 percent of revenue for the first quarter.

[0001571996-18-000019:8k_2_02:24]
Key highlights:

[0001571996-18-000019:8k_2_02:25]
| • | Sixth consecutive quarter of server revenue growth, driven by double-digit growth for both PowerEdge and Cloud servers |

[0001571996-18-000019:8k_2_02:26]
| • | Remained the worldwide share leader in x86 servers, for both units and revenue3 |

[0001571996-18-000019:8k_2_02:27]
| • | Strong demand for Dell EMC’s market-leading hyper-converged portfolio, including triple-digit growth in its VxRail and VxRack offerings |

[0001571996-18-000019:8k_2_02:28]
| • | Following positive demand growth in its fiscal fourth quarter, Dell expects to gain share year-over-year in storage when the first calendar quarter 2018 storage industry share numbers are final. This will be its first quarter of storage share gain since closing the EMC transaction. |

[0001571996-18-000019:8k_2_02:29]
“Storage systems spending is forecasted to grow 9.8 percent year-over-year in the first quarter of 2018 and we expect, when IDC releases first quarter market share, Dell EMC’s storage business will outperform the market and gain share,” said Matt Eastwood, Senior Vice President of IDC’s enterprise, datacenter, cloud infrastructure and developer research groups.

[0001571996-18-000019:8k_2_02:30]
Client Solutions Group revenue for the first quarter was $10.3 billion, up 14 percent versus the first quarter of last year. Commercial revenue grew 16 percent to $7.4 billion and Consumer revenue was up 7 percent to $2.9 billion. Operating income for the first quarter was $533 million, a 64 percent increase and was 5.2 percent of revenue.

[0001571996-18-000019:8k_2_02:31]
Key highlights:

[0001571996-18-000019:8k_2_02:32]
| • | Increased PC shipments by 6.4 percent year-over-year, with 21 consecutive quarters of year-over-year PC unit share growth4 |

[0001571996-18-000019:8k_2_02:33]
| • | Maintained No. 1 share position worldwide for displays, marking the 19th consecutive quarter5 |

[0001571996-18-000019:8k_2_02:34]
| • | No. 1 provider of workstations worldwide, outgrowing the industry4 |

[0001571996-18-000019:8k_2_02:35]
VMware segment revenue for the first quarter was $2.0 billion, up 12 percent, with operating income of $613 million or 30.2 percent of revenue.

[0001571996-18-000019:8k_2_02:36]
First quarter revenue from other businesses, including RSA, Pivotal, Secureworks, Virtustream and Boomi was $579 million, up 9 percent.

[0001571996-18-000019:8k_2_02:37]
Additional highlights

[0001571996-18-000019:8k_2_02:38]
Dell Technologies hosted its annual Dell Technologies World conference in May, its largest ever with more than 14,000 attendees from 131 countries and more than 70,000 joining online through an online virtual video experience. Digital transformation is fundamentally changing how every business in every industry is built and operated, and Dell Technologies provides IT practitioners with a one-stop shop for the essential infrastructure they need to build their digital future, transform IT and protect their most important digital assets from the edge, to the core to the cloud.

[0001571996-18-000019:8k_2_02:39]
Dell Technologies demonstrated the power of its broad and innovative portfolio of IT infrastructure, applications, devices and security that enable real transformation. The company announced breakthrough modern data center solutions including the new Dell EMC PowerMax storage array, with end-to-end NVMe and a built-in, real-time machine learning engine. It also previewed Dell EMC PowerEdge MX (coming in the second half of this year), a new modular infrastructure solution designed to enable customers to flexibly configure and optimize their IT infrastructure for new and emerging workloads. In addition, Dell and Dell EMC are uniquely delivering artificial intelligence, machine learning and deep learning capabilities from the desktop to the data center, unveiling two new 14th generation Dell EMC PowerEdge four-socket servers and the new Dell Precision Optimizer 5.0, which uses AI to automatically adjust applications running on Dell Precision workstations to customize and optimize performance.

[0001571996-18-000019:8k_2_02:40]
Conference call information

[0001571996-18-000019:8k_2_02:41]
As previously announced, the company will hold a conference call to discuss its first quarter performance today at 7 a.m. CDT. The conference call will be broadcast live over the internet and can be accessed at investors.delltechnologies.com. For those unable to listen to the live broadcast, an archived version will be available at the same location for one year.

[0001571996-18-000019:8k_2_02:42]
A slide presentation containing additional financial and operating information may be downloaded from Dell Technologies’ website at investors.delltechnologies.com.

[0001571996-18-000019:8k_2_02:43]
About Dell Technologies

[0001571996-18-000019:8k_2_02:44]
Dell Technologies is a unique family of businesses that provides the essential infrastructure for organizations to build their digital future, transform IT and protect their most important asset, information. The company services customers of all sizes across 180 countries - ranging from 99 percent of the Fortune 500 to individual consumers - with the industry's most comprehensive and innovative portfolio from the edge to the core to the cloud.

[0001571996-18-000019:8k_2_02:45]
CONTACTS

[0001571996-18-000019:8k_2_02:46]
Investors: Investor_Relations@Dell.com

[0001571996-18-000019:8k_2_02:47]
Media: Media.Relations@Dell.com

[0001571996-18-000019:8k_2_02:48]
# # #

[0001571996-18-000019:8k_2_02:49]
Copyright © 2018. All Rights Reserved. Dell, Dell EMC, Pivotal, RSA, Secureworks, Virtustream, VMware and the Dell Technologies logo are trademarks of Dell Technologies in the United States and/or other jurisdictions. All other marks and names mentioned herein may be trademarks of their respective companies.

[0001571996-18-000019:8k_2_02:50]
1 Due to the EMC transaction, significant non-cash bridging items will remain between GAAP and non-GAAP results for the next few years.

[0001571996-18-000019:8k_2_02:51]
2 Core Debt represents the total principal amount of the company’s debt, less unrestricted subsidiary debt, DFS related debt, and other debt.

[0001571996-18-000019:8k_2_02:52]
3 IDC WW Quarterly Server Tracker CY18Q1

[0001571996-18-000019:8k_2_02:53]
4 IDC WW Quarterly Personal Computing Device (PCD) Tracker CY18Q1

[0001571996-18-000019:8k_2_02:54]
5 DisplaySearch Desktop Monitor Market Tracker CY17Q4

[0001571996-18-000019:8k_2_02:55]
Non-GAAP Financial Measures:

[0001571996-18-000019:8k_2_02:56]
This press release presents information about Dell Technologies’ non-GAAP net revenue, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, EBITDA and adjusted EBITDA, which are non-GAAP financial measures provided as a supplement to the results provided in accordance with generally accepted accounting principles in the United States of America ("GAAP"). A reconciliation of each of the foregoing historical non-GAAP financial measures to the most directly comparable historical GAAP financial measures is provided in the attached tables for each of the fiscal periods indicated.

[0001571996-18-000019:8k_2_02:57]
Special Note on Forward-Looking Statements:

[0001571996-18-000019:8k_2_02:58]
Dell Technologies' results or events in future periods could differ materially from those expressed or implied by these forward-looking statements because of risks, uncertainties, and other factors that include, but are not limited to, the following: competitive pressures; Dell Technologies' reliance on third-party suppliers for products and components including reliance on single-source or limited-source suppliers; Dell Technologies' ability to achieve favorable pricing from its vendors; adverse global economic conditions and instability in financial markets; Dell Technologies' execution of its growth, business and acquisition strategies; the success of Dell Technologies' cost efficiency measures; Dell Technologies' ability to manage solutions and products and services transitions in an effective manner; Dell Technologies' ability to deliver high-quality products and services; Dell Technologies' foreign operations and ability to generate substantial non-U.S. net revenue; Dell Technologies' product, customer, and geographic sales mix, and seasonal sales trends; the performance of Dell Technologies' sales channel partners; access to the capital markets by Dell Technologies or its customers; weak economic conditions and additional regulation; counterparty default risks; the loss by Dell Technologies of any services contracts with its customers, including government contracts, and its ability to perform such contracts at its estimated costs; Dell Technologies' ability to develop and protect its proprietary intellectual property or obtain licenses to intellectual property developed by others on commercially reasonable and competitive terms; infrastructure disruptions, cyberattacks, or other data security breaches; Dell Technologies' ability to hedge effectively its exposure to fluctuations in foreign currency exchange rates and interest rates; expiration of tax holidays or favorable tax rate structures, or unfavorable outcomes in tax audits and other tax compliance matters; impairment of portfolio investments; unfavorable results of legal proceedings; increased costs and additional regulations and requirements as a result of Dell Technologies operation as a public company; Dell Technologies' ability to develop and maintain effective internal control over financial reporting; compliance requirements of changing environmental and safety laws; the effect of armed hostilities, terrorism, natural disasters, and public health issues; Dell Technologies’ substantial level of indebtedness; the impact of the financial performance of VMware; and the market volatility of Dell Technologies' pension plan assets.

[0001571996-18-000019:8k_2_02:59]
This list of risks, uncertainties, and other factors is not complete. Dell Technologies discusses some of these matters more fully, as well as certain risk factors that could affect the Dell Technologies' business, financial condition, results of operations, and prospects, in its reports filed with the Securities and Exchange Commission, including Dell Technologies' Annual Report on Form 10-K for the fiscal year ended February 2, 2018, quarterly reports on Form 10-Q, and current reports on Form 8-K. These filings are available for review through the Securities and Exchange Commission's website at www.sec.gov. Any or all forward-looking statements Dell Technologies makes may turn out to be wrong and can be affected by inaccurate assumptions Dell Technologies might make or by known or unknown risks, uncertainties and other factors, including those identified in this press release. Accordingly, you should not place undue reliance on the forward-looking statements made in this press release, which speak only as of its date. Dell Technologies does not undertake to update, and expressly disclaims any duty to update, its forward-looking statements, whether as a result of circumstances or events that arise after the date they are made, new information, or otherwise.

[0001571996-18-000019:8k_2_02:60]
DELL TECHNOLOGIES INC.

[0001571996-18-000019:8k_2_02:61]
Condensed Consolidated Statements of Income (Loss) and Related Financial Highlights

[0001571996-18-000019:8k_2_02:62]
(in millions, except per share amounts and percentages; unaudited)

[0001571996-18-000019:8k_2_02:63]
|  | Three Months Ended |  |  |
|  | May 4, 2018 |  | May 5, 2017 |  | Change |
| Net revenue: |  |  |  |  |  |
| Products | $ | 16,671 |  |  | $ | 13,634 |  |  | 22% |
| Services | 4,685 |  |  | 4,366 |  |  | 7% |
| Total net revenue | 21,356 |  |  | 18,000 |  |  | 19% |
| Cost of net revenue: |  |  |  |  |  |
| Products | 13,606 |  |  | 11,823 |  |  | 15% |
| Services | 1,872 |  |  | 1,720 |  |  | 9% |
| Total cost of net revenue | 15,478 |  |  | 13,543 |  |  | 14% |
| Gross margin | 5,878 |  |  | 4,457 |  |  | 32% |
| Operating expenses: |  |  |  |  |  |
| Selling, general, and administrative | 4,944 |  |  | 4,596 |  |  | 8% |
| Research and development | 1,087 |  |  | 1,133 |  |  | (4)% |
| Total operating expenses | 6,031 |  |  | 5,729 |  |  | 5% |
| Operating loss | (153 | ) |  | (1,272 | ) |  | 88% |
| Interest and other, net | (470 | ) |  | (572 | ) |  | 18% |
| Loss before income taxes | (623 | ) |  | (1,844 | ) |  | 66% |
| Income tax benefit | (85 | ) |  | (641 | ) |  | 87% |
| Net loss | (538 | ) |  | (1,203 | ) |  | 55% |
| Less: Net income (loss) attributable to non-controlling interests | 98 |  |  | (32 | ) |  | 406% |
| Net loss attributable to Dell Technologies Inc. | $ | (636 | ) |  | $ | (1,171 | ) |  | 46% |
| Earnings (loss) per share attributable to Dell Technologies Inc. - basic: |  |  |  |  |  |
| Class V Common Stock - basic | $ | 2.36 |  |  | $ | 0.60 |  |  |  |
| DHI Group - basic | $ | (1.95 | ) |  | $ | (2.29 | ) |  |  |
| Earnings (loss) per share attributable to Dell Technologies Inc. - diluted: |  |  |  |  |  |
| Class V Common Stock - diluted | $ | 2.33 |  |  | $ | 0.59 |  |  |  |
| DHI Group - diluted | $ | (1.95 | ) |  | $ | (2.29 | ) |  |  |
| Weighted-average shares outstanding: |  |  |  |  |  |
| Basic - Class V Common Stock | 199 |  |  | 207 |  |  |  |
| Diluted - Class V Common Stock | 199 |  |  | 207 |  |  |  |
| Basic - DHI Group | 568 |  |  | 566 |  |  |  |
| Diluted - DHI Group | 568 |  |  | 566 |  |  |  |
| Percentage of Total Net Revenue: |  |  |  |  |  |
| Gross margin | 28 | % |  | 25 | % |  |  |
| Selling, general, and administrative | 23 | % |  | 26 | % |  |  |
| Research and development | 5 | % |  | 6 | % |  |  |
| Operating expenses | 28 | % |  | 32 | % |  |  |
| Operating loss | (1 | )% |  | (7 | )% |  |  |
| Loss before income taxes | (3 | )% |  | (10 | )% |  |  |
| Net loss | (3 | )% |  | (7 | )% |  |  |
| Income tax rate | 14 | % |  | 35 | % |  |  |

[0001571996-18-000019:8k_2_02:64]
DELL TECHNOLOGIES INC.

[0001571996-18-000019:8k_2_02:65]
Condensed Consolidated Statements of Financial Position

[0001571996-18-000019:8k_2_02:66]
(in millions; unaudited)

[0001571996-18-000019:8k_2_02:67]
|  | May 4, 2018 |  | February 2, 2018 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 15,324 |  |  | $ | 13,942 |  |
| Short-term investments | 2,402 |  |  | 2,187 |  |
| Accounts receivable, net | 10,561 |  |  | 11,721 |  |
| Short-term financing receivables, net | 3,962 |  |  | 3,919 |  |
| Inventories, net | 2,933 |  |  | 2,678 |  |
| Other current assets | 6,049 |  |  | 5,881 |  |
| Total current assets | 41,231 |  |  | 40,328 |  |
| Property, plant, and equipment, net | 5,303 |  |  | 5,390 |  |
| Long-term investments | 3,943 |  |  | 4,163 |  |
| Long-term financing receivables, net | 3,799 |  |  | 3,724 |  |
| Goodwill | 39,656 |  |  | 39,920 |  |
| Intangible assets, net | 26,737 |  |  | 28,265 |  |
| Other non-current assets | 2,548 |  |  | 2,403 |  |
| Total assets | $ | 123,217 |  |  | $ | 124,193 |  |
| LIABILITIES, REDEEMABLE SHARES, AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Short-term debt | $ | 7,133 |  |  | $ | 7,873 |  |
| Accounts payable | 18,534 |  |  | 18,334 |  |
| Accrued and other | 6,952 |  |  | 8,026 |  |
| Short-term deferred revenue | 11,495 |  |  | 11,606 |  |
| Total current liabilities | 44,114 |  |  | 45,839 |  |
| Long-term debt | 44,770 |  |  | 43,998 |  |
| Long-term deferred revenue | 9,464 |  |  | 9,210 |  |
| Other non-current liabilities | 7,045 |  |  | 7,277 |  |
| Total liabilities | 105,393 |  |  | 106,324 |  |
| Redeemable shares | 844 |  |  | 384 |  |
| Stockholders' equity: |  |  |  |
| Total Dell Technologies Inc. stockholders’ equity | 10,485 |  |  | 11,719 |  |
| Non-controlling interests | 6,495 |  |  | 5,766 |  |
| Total stockholders' equity | 16,980 |  |  | 17,485 |  |
| Total liabilities, redeemable shares, and stockholders' equity | $ | 123,217 |  |  | $ | 124,193 |  |

[0001571996-18-000019:8k_2_02:68]
DELL TECHNOLOGIES INC.

[0001571996-18-000019:8k_2_02:69]
Condensed Consolidated Statements of Cash Flows

[0001571996-18-000019:8k_2_02:70]
(in millions; unaudited)

[0001571996-18-000019:8k_2_02:71]
|  | Three Months Ended |
|  | May 4, 2018 |  | May 5, 2017 |
| Cash flows from operating activities: |  |  |  |
| Net loss | $ | (538 | ) |  | $ | (1,203 | ) |
| Adjustments to reconcile net loss to net cash provided by operating activities | 1,697 |  |  | 1,488 |  |
| Change in cash from operating activities | 1,159 |  |  | 285 |  |
| Cash flows from investing activities: |  |  |  |
| Investments: |  |  |  |
| Purchases | (439 | ) |  | (559 | ) |
| Maturities and sales | 531 |  |  | 973 |  |
| Capital expenditures | (273 | ) |  | (245 | ) |
| Proceeds from sale of facilities, land, and other assets | 10 |  |  | — |  |
| Capitalized software development costs | (89 | ) |  | (89 | ) |
| Collections on purchased financing receivables | 10 |  |  | 3 |  |
| Acquisition of businesses, net | — |  |  | (12 | ) |
| Divestitures of businesses, net | 142 |  |  | (20 | ) |
| Asset acquisitions, net | (38 | ) |  | — |  |
| Asset dispositions, net | (3 | ) |  | — |  |
| Change in cash from investing activities | (149 | ) |  | 51 |  |
| Cash flows from financing activities: |  |  |  |
| Share repurchases for tax withholdings of equity awards | (100 | ) |  | (126 | ) |
| Proceeds from the issuance of common stock of subsidiaries | 642 |  |  | 8 |  |
| Repurchases of DHI Group Common Stock | (37 | ) |  | (2 | ) |
| Repurchases of Class V Common Stock | — |  |  | (368 | ) |
| Payments for debt issuance costs | (3 | ) |  | (5 | ) |
| Proceeds from debt | 1,863 |  |  | 3,421 |  |
| Repayments of debt | (1,822 | ) |  | (3,116 | ) |
| Other | — |  |  | 1 |  |
| Change in cash from financing activities | 543 |  |  | (187 | ) |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash | (86 | ) |  | (6 | ) |
| Change in cash, cash equivalents, and restricted cash | 1,467 |  |  | 143 |  |
| Cash, cash equivalents, and restricted cash at beginning of the period | 14,378 |  |  | 9,832 |  |
| Cash, cash equivalents, and restricted cash at end of the period | $ | 15,845 |  |  | $ | 9,975 |  |

[0001571996-18-000019:8k_2_02:72]
DELL TECHNOLOGIES INC.

[0001571996-18-000019:8k_2_02:73]
Segment Information

[0001571996-18-000019:8k_2_02:74]
(in millions, except percentages; unaudited; continued on next page)

[0001571996-18-000019:8k_2_02:75]
|  | Three Months Ended |  |  |
|  | May 4, 2018 |  | May 5, 2017 |  | Change |
| Infrastructure Solutions Group (ISG): |  |  |  |  |  |
| Net Revenue: |  |  |  |  |  |
| Servers and networking | $ | 4,585 |  |  | $ | 3,256 |  |  | 41% |
| Storage | 4,082 |  |  | 3,705 |  |  | 10% |
| Total ISG net revenue | $ | 8,667 |  |  | $ | 6,961 |  |  | 25% |
| Operating Income: |  |  |  |  |  |
| ISG operating income | $ | 939 |  |  | $ | 506 |  |  | 86% |
| % of ISG net revenue | 11 | % |  | 7 | % |  |  |
| % of total segment operating income | 45 | % |  | 35 | % |  |  |
| Client Solutions Group (CSG): |  |  |  |  |  |
| Net Revenue: |  |  |  |  |  |
| Commercial | $ | 7,363 |  |  | $ | 6,342 |  |  | 16% |
| Consumer | 2,908 |  |  | 2,706 |  |  | 7% |
| Total CSG net revenue | $ | 10,271 |  |  | $ | 9,048 |  |  | 14% |
| Operating Income: |  |  |  |  |  |
| CSG operating income | $ | 533 |  |  | $ | 325 |  |  | 64% |
| % of CSG net revenue | 5 | % |  | 4 | % |  |  |
| % of total segment operating income | 26 | % |  | 23 | % |  |  |
| VMware: |  |  |  |  |  |
| Net Revenue: |  |  |  |  |  |
| Total VMware net revenue | $ | 2,028 |  |  | $ | 1,818 |  |  | 12% |
| Operating Income: |  |  |  |  |  |
| VMware operating income | $ | 613 |  |  | $ | 611 |  |  | —% |
| % of VMware net revenue | 30 | % |  | 34 | % |  |  |
| % of total segment operating income | 29 | % |  | 42 | % |  |  |

[0001571996-18-000019:8k_2_02:76]
DELL TECHNOLOGIES INC.

[0001571996-18-000019:8k_2_02:77]
Segment Information

[0001571996-18-000019:8k_2_02:78]
(in millions, except percentages; unaudited; continued)

[0001571996-18-000019:8k_2_02:79]
|  | Three Months Ended |
|  | May 4, 2018 |  | May 5, 2017 |
| Reconciliation to consolidated net revenue: |  |  |
| Reportable segment net revenue | $ | 20,966 |  |  | $ | 17,827 |  |
| Other businesses (a) | 579 |  |  | 529 |  |
| Unallocated transactions (b) | (2 | ) |  | (1 | ) |
| Impact of purchase accounting (c) | (187 | ) |  | (355 | ) |
| Total net revenue | $ | 21,356 |  |  | $ | 18,000 |  |
| Reconciliation to consolidated operating income (loss): |
| Reportable segment operating income | $ | 2,085 |  |  | $ | 1,442 |  |
| Other businesses (a) | (50 | ) |  | (23 | ) |
| Unallocated transactions (b) | (9 | ) |  | 6 |  |
| Impact of purchase accounting (c) | (222 | ) |  | (423 | ) |
| Amortization of intangibles | (1,522 | ) |  | (1,776 | ) |
| Transaction-related expenses (d) | (166 | ) |  | (191 | ) |
| Other corporate expenses (e) | (269 | ) |  | (307 | ) |
| Total operating loss | $ | (153 | ) |  | $ | (1,272 | ) |

[0001571996-18-000019:8k_2_02:80]
_________________

[0001571996-18-000019:8k_2_02:81]
| (a) | Other businesses consist of RSA Information Security, Pivotal, SecureWorks, Virtustream, and Boomi and do not constitute a reportable segment, either individually or collectively, as the results of the businesses are not material to the Company's overall results and the businesses do not meet the criteria for reportable segments. |

[0001571996-18-000019:8k_2_02:82]
| (b) | Unallocated transactions includes long-term incentives, certain short-term incentive compensation expenses, and other corporate items that are not allocated to Dell Technologies' reportable segments. |

[0001571996-18-000019:8k_2_02:83]
| (c) | Impact of purchase accounting includes non-cash purchase accounting adjustments that are primarily related to the EMC merger transaction. |

[0001571996-18-000019:8k_2_02:84]
| (d) | Transaction-related expenses includes acquisition, integration, and divestiture related costs. |

[0001571996-18-000019:8k_2_02:85]
| (e) | Other corporate expenses includes severance and facility action costs as well as stock-based compensation expense. |

[0001571996-18-000019:8k_2_02:86]
SUPPLEMENTAL SELECTED NON-GAAP FINANCIAL MEASURES

[0001571996-18-000019:8k_2_02:87]
These tables present information about the Company’s non-GAAP net revenue, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, EBITDA, and adjusted EBITDA, which are non-GAAP financial measures provided as a supplement to the results provided in accordance with generally accepted accounting principles in the United States of America (“GAAP”).  A detailed discussion of Dell Technologies’ reasons for including these non-GAAP financial measures, the limitations associated with these measures, the items excluded from these measures, and our reason for excluding those items are presented in “Management’s Discussion and Analysis of Financial Condition and Results of Operations - Non-GAAP Financial Measures” in our periodic reports filed with the SEC.  Dell Technologies encourages investors to review the non-GAAP discussion in conjunction with the presentation of non-GAAP financial measures.

[0001571996-18-000019:8k_2_02:88]
DELL TECHNOLOGIES INC.

[0001571996-18-000019:8k_2_02:89]
Selected Non-GAAP Financial Measures

[0001571996-18-000019:8k_2_02:90]
(in millions, except percentages; unaudited)

[0001571996-18-000019:8k_2_02:91]
|  | Three Months Ended |  |  |
|  | May 4, 2018 |  | May 5, 2017 |  | Change |
| Non-GAAP net revenue | $ | 21,543 |  |  | $ | 18,355 |  |  | 17% |
| Non-GAAP gross margin | $ | 6,919 |  |  | $ | 5,801 |  |  | 19% |
| % of non-GAAP net revenue | 32 | % |  | 32 | % |  |  |
| Non-GAAP operating expenses | $ | 4,893 |  |  | $ | 4,376 |  |  | 12% |
| % of non-GAAP net revenue | 23 | % |  | 24 | % |  |  |
| Non-GAAP operating income | $ | 2,026 |  |  | $ | 1,425 |  |  | 42% |
| % of non-GAAP net revenue | 9 | % |  | 8 | % |  |  |
| Non-GAAP net income | $ | 1,174 |  |  | $ | 761 |  |  | 54% |
| % of non-GAAP net revenue | 5 | % |  | 4 | % |  |  |
| Adjusted EBITDA | $ | 2,383 |  |  | $ | 1,795 |  |  | 33% |
| % of non-GAAP net revenue | 11 | % |  | 10 | % |  |  |

[0001571996-18-000019:8k_2_02:92]
DELL TECHNOLOGIES INC.

[0001571996-18-000019:8k_2_02:93]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-18-000019:8k_2_02:94]
(in millions, except percentages; unaudited; continued on next page)

[0001571996-18-000019:8k_2_02:95]
|  | Three Months Ended |  |  |
|  | May 4, 2018 |  | May 5, 2017 |  | Change |
| Net revenue | $ | 21,356 |  |  | $ | 18,000 |  |  | 19% |
| Non-GAAP adjustments: |  |  |  |  |  |
| Impact of purchase accounting | 187 |  |  | 355 |  |  |  |
| Non-GAAP net revenue | $ | 21,543 |  |  | $ | 18,355 |  |  | 17% |
| Gross margin | $ | 5,878 |  |  | $ | 4,457 |  |  | 32% |
| Non-GAAP adjustments: |  |  |  |  |  |
| Amortization of intangibles | 710 |  |  | 950 |  |  |  |
| Impact of purchase accounting | 193 |  |  | 365 |  |  |  |
| Transaction related | 116 |  |  | 7 |  |  |  |
| Other corporate expenses | 22 |  |  | 22 |  |  |  |
| Non-GAAP gross margin | $ | 6,919 |  |  | $ | 5,801 |  |  | 19% |
| Operating expenses | $ | 6,031 |  |  | $ | 5,729 |  |  | 5% |
| Non-GAAP adjustments: |  |  |  |  |  |
| Amortization of intangibles | (812 | ) |  | (826 | ) |  |  |
| Impact of purchase accounting | (29 | ) |  | (58 | ) |  |  |
| Transaction related | (50 | ) |  | (184 | ) |  |  |
| Other corporate expenses | (247 | ) |  | (285 | ) |  |  |
| Non-GAAP operating expenses | $ | 4,893 |  |  | $ | 4,376 |  |  | 12% |
| Operating loss | $ | (153 | ) |  | $ | (1,272 | ) |  | 88% |
| Non-GAAP adjustments: |  |  |  |  |  |
| Amortization of intangibles | 1,522 |  |  | 1,776 |  |  |  |
| Impact of purchase accounting | 222 |  |  | 423 |  |  |  |
| Transaction related | 166 |  |  | 191 |  |  |  |
| Other corporate expenses | 269 |  |  | 307 |  |  |  |
| Non-GAAP operating income | $ | 2,026 |  |  | $ | 1,425 |  |  | 42% |
| Net loss | $ | (538 | ) |  | $ | (1,203 | ) |  | 55% |
| Non-GAAP adjustments: |  |  |  |  |  |
| Amortization of intangibles | 1,522 |  |  | 1,776 |  |  |  |
| Impact of purchase accounting | 222 |  |  | 423 |  |  |  |
| Transaction related | 166 |  |  | 191 |  |  |  |
| Other corporate expenses | 269 |  |  | 307 |  |  |  |
| Aggregate adjustment for income taxes | (467 | ) |  | (733 | ) |  |  |
| Non-GAAP net income | $ | 1,174 |  |  | $ | 761 |  |  | 54% |

[0001571996-18-000019:8k_2_02:96]
DELL TECHNOLOGIES INC.

[0001571996-18-000019:8k_2_02:97]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-18-000019:8k_2_02:98]
(in millions, except percentages; unaudited; continued)

[0001571996-18-000019:8k_2_02:99]
|  | Three Months Ended |  |  |
|  | May 4, 2018 |  | May 5, 2017 |  | Change |
| Net loss | $ | (538 | ) |  | $ | (1,203 | ) |  | 55% |
| Adjustments: |  |  |  |  |  |
| Interest and other, net (a) | 470 |  |  | 572 |  |  |  |
| Income tax benefit | (85 | ) |  | (641 | ) |  |  |
| Depreciation and amortization | 1,914 |  |  | 2,212 |  |  |  |
| EBITDA | $ | 1,761 |  |  | $ | 940 |  |  | 87% |
| EBITDA | $ | 1,761 |  |  | $ | 940 |  |  | 87% |
| Adjustments: |  |  |  |  |  |
| Stock-based compensation expense | 199 |  |  | 201 |  |  |  |
| Impact of purchase accounting | 222 |  |  | 357 |  |  |  |
| Transaction-related expenses | 166 |  |  | 191 |  |  |  |
| Other corporate expenses | 35 |  |  | 106 |  |  |  |
| Adjusted EBITDA | $ | 2,383 |  |  | $ | 1,795 |  |  | 33% |
