# DELL 10-Q controls and the auditor's report


## item_4_controls

[0001571996-25-000063:item_4_controls:1]
ITEM 4 — CONTROLS AND PROCEDURES

[0001571996-25-000063:item_4_controls:2]
This report includes the certifications of our Chief Executive Officer and Chief Financial Officer required by Rule 13a-14 under the Securities Exchange Act of 1934 (the “Exchange Act”). See Exhibits 31.1 and 31.2 filed with this report. This Item 4 includes information concerning the controls and control evaluations referred to in those certifications.

[0001571996-25-000063:item_4_controls:3]
Evaluation of Disclosure Controls and Procedures

[0001571996-25-000063:item_4_controls:4]
Disclosure controls and procedures (as defined in Rules 13a-15(e) and 15d-15(e) under the Exchange Act) are designed to provide reasonable assurance that information required to be disclosed in reports filed or submitted under the Exchange Act is recorded, processed, summarized, and reported within the time periods specified in SEC rules and forms and that such information is accumulated and communicated to management, including the Chief Executive Officer and the Chief Financial Officer, as appropriate to allow timely decisions regarding required disclosures.

[0001571996-25-000063:item_4_controls:5]
In connection with the preparation of this report, our management, under the supervision and with the participation of our Chief Executive Officer and Chief Financial Officer, conducted an evaluation of the effectiveness of the design and operation of our disclosure controls and procedures as of May 2, 2025. Based on that evaluation, our Chief Executive Officer and Chief Financial Officer have concluded that as of May 2, 2025, the Company’s disclosure controls and procedures were not effective to accomplish their objectives at the reasonable assurance level due to the material weakness in internal control over financial reporting as described below.

[0001571996-25-000063:item_4_controls:6]
Material Weakness in Internal Control Over Financial Reporting

[0001571996-25-000063:item_4_controls:7]
As previously disclosed in the Company’s Annual Report on Form 10-K for the fiscal year ended January 31, 2025, management identified a material weakness in its internal control over financial reporting during the preparation of the Company’s financial statements for the fiscal year ended January 31, 2025 as the Company did not design and maintain effective controls over non-recurring credits from certain suppliers that related to cost of net revenue. This material weakness resulted in the revision of the Company’s annual Consolidated Financial Statements previously issued for the fiscal year ended February 2, 2024 and the unaudited interim Condensed Consolidated Financial Statements previously issued for Fiscal 2025 and Fiscal 2024 interim periods. While the impacts were not material, individually or in the aggregate, to the Company’s previously issued Consolidated Financial Statements, the material weakness related to non-recurring credits from certain suppliers could result in a material misstatement to the annual or interim Condensed Consolidated Financial Statements that would not be prevented or detected until such material weakness is remediated.

[0001571996-25-000063:item_4_controls:8]
Remediation of Material Weakness

[0001571996-25-000063:item_4_controls:9]
The Company is committed to addressing the material weakness described above and has implemented changes in processes designed to improve its internal control over financial reporting. To remediate the material weakness, the Company has designed and implemented a new control over non-recurring credits from certain suppliers.

[0001571996-25-000063:item_4_controls:10]
Until remediation occurs, the Company continues to evaluate and enhance its internal control over financial reporting, and may take additional measures to modify, or add to, the remediation measures. Remediation will not occur until there has been sufficient time to conclude through testing that the controls operate effectively.

[0001571996-25-000063:item_4_controls:11]
75

[0001571996-25-000063:item_4_controls:12]
Changes in Internal Control Over Financial Reporting

[0001571996-25-000063:item_4_controls:13]
We are in the process of an ongoing business modernization initiative to advance our capabilities, leverage new technology, and optimize business processes to change the way we work and make decisions, improve business outcomes, and reduce costs. As part of this initiative, we are modernizing accounting and finance systems. We have modified and will continue to modify the design and implementation of certain internal control processes to accommodate changes to our business processes and finance procedures, as our business modernization initiative continues.

[0001571996-25-000063:item_4_controls:14]
Additionally, a new control was designed and implemented over non-recurring credits from certain suppliers as part of the remediation of the material weakness in our internal control over financial reporting discussed above.

[0001571996-25-000063:item_4_controls:15]
There were no other changes in our internal control over financial reporting during the fiscal quarter ended May 2, 2025 that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.

[0001571996-25-000063:item_4_controls:16]
76
