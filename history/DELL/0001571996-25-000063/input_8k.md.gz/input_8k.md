# DELL 8-K — 0001571996-25-000046 filed 2025-05-29

## item codes, every 8-K on or before 2025-06-10

- 2025-05-29 0001571996-25-000046 — 2.02, 9.01
- 2025-04-01 0001193125-25-070461 — 1.01, 2.03, 9.01
- 2025-03-27 0001193125-25-065594 — 8.01, 9.01
- 2025-02-27 0001571996-25-000014 — 2.02, 8.01, 9.01
- 2025-01-14 0001571996-25-000004 — 3.02
- 2024-12-03 0001571996-24-000136 — 3.02
- 2024-11-26 0001571996-24-000130 — 2.02, 9.01
- 2024-10-08 0001193125-24-234446 — 1.01, 2.03, 9.01
- 2024-10-02 0001193125-24-231195 — 8.01, 9.01
- 2024-09-19 0001571996-24-000105 — 3.02
- 2024-08-29 0001571996-24-000081 — 2.02, 9.01
- 2024-07-12 0001193125-24-178608 — 3.02
- 2024-07-02 0001571996-24-000074 — 5.07
- 2024-06-10 0001571996-24-000059 — 3.02
- 2024-05-30 0001571996-24-000050 — 2.02, 9.01
- 2024-03-26 0001571996-24-000038 — 3.02
- 2024-03-18 0001193125-24-070193 — 1.01, 2.03, 9.01
- 2024-03-07 0001571996-24-000012 — 3.02
- 2024-03-06 0001193125-24-059631 — 8.01, 9.01
- 2024-02-29 0001571996-24-000008 — 2.02, 9.01
- 2024-01-30 0001571996-24-000004 — 1.02
- 2024-01-18 0001571996-24-000002 — 3.02
- 2023-12-18 0001193125-23-297664 — 8.01, 9.01
- 2023-12-05 0001571996-23-000042 — 3.02
- 2023-12-04 0001193125-23-288428 — 8.01, 9.01
- 2023-11-30 0001571996-23-000039 — 2.02, 9.01
- 2023-10-05 0001193125-23-251131 — 7.01, 8.01, 9.01
- 2023-10-02 0001571996-23-000036 — 5.02 — amendment of 0001571996-23-000034
- 2023-09-26 0001571996-23-000034 — 5.02
- 2023-08-31 0001571996-23-000029 — 2.02, 9.01
- 2023-08-09 0001571996-23-000026 — 5.02 — amendment of 0001571996-23-000002
- 2023-07-28 0001571996-23-000024 — 5.02
- 2023-07-13 0001193125-23-186639 — 3.02
- 2023-06-30 0001193125-23-180570 — 8.01, 9.01
- 2023-06-22 0001571996-23-000021 — 5.02, 5.07, 9.01
- 2023-06-15 0001193125-23-167472 — 8.01, 9.01
- 2023-06-01 0001571996-23-000014 — 2.02, 9.01
- 2023-03-02 0001571996-23-000002 — 2.02, 5.02, 9.01
- 2023-02-06 0001193125-23-024781 — 7.01, 9.01
- 2023-01-24 0001193125-23-014260 — 1.01, 2.03, 9.01
- 2023-01-11 0001193125-23-006528 — 8.01, 9.01
- 2022-11-21 0001571996-22-000041 — 2.02, 9.01
- 2022-11-16 0001571996-22-000038 — 8.01
- 2022-08-25 0001571996-22-000028 — 2.02, 9.01
- 2022-07-18 0001193125-22-196334 — 2.03, 8.01
- 2022-06-29 0001571996-22-000025 — 3.03, 5.03, 5.07, 8.01, 9.01
- 2022-05-26 0001571996-22-000013 — 2.02, 9.01
- 2022-02-24 0001571996-22-000004 — 2.02, 8.01, 9.01
- 2021-12-20 0001193125-21-362482 — 8.01, 9.01
- 2021-12-15 0001193125-21-357927 — 1.01, 2.03, 9.01
- 2021-12-07 0001193125-21-349218 — 8.01, 9.01
- 2021-11-23 0001571996-21-000060 — 2.02, 9.01
- 2021-11-05 0001571996-21-000057 — 1.02, 2.01, 7.01, 8.01, 9.01 — amendment, the index does not say of what
- 2021-11-01 0001571996-21-000052 — 8.01, 9.01
- 2021-11-01 0001193125-21-315488 — 1.01, 1.02, 2.01, 8.01, 9.01
- 2021-10-21 0001193125-21-304052 — 8.01, 9.01
- 2021-10-19 0001571996-21-000050 — 8.01, 9.01
- 2021-10-07 0001193125-21-294210 — 8.01, 9.01
- 2021-09-30 0001571996-21-000047 — 5.02
- 2021-09-27 0001571996-21-000045 — 8.01
- 2021-09-23 0001193125-21-280190 — 7.01, 8.01, 9.01
- 2021-09-20 0001193125-21-276810 — 7.01, 9.01
- 2021-08-26 0001571996-21-000037 — 2.02, 9.01
- 2021-07-01 0001571996-21-000034 — 3.02
- 2021-06-24 0001571996-21-000031 — 5.07
- 2021-06-24 0001193125-21-197644 — 7.01, 9.01
- 2021-06-16 0001571996-21-000029 — 5.02
- 2021-05-27 0001571996-21-000019 — 2.02, 9.01
- 2021-05-03 0001571996-21-000010 — 8.01, 9.01
- 2021-04-14 0001193125-21-116271 — 1.01, 7.01, 9.01
- 2021-02-25 0001571996-21-000003 — 2.02, 9.01
- 2021-02-18 0001193125-21-047844 — 1.01, 2.03, 9.01
- 2020-11-24 0001571996-20-000048 — 2.02, 9.01
- 2020-08-27 0001571996-20-000041 — 2.02, 9.01
- 2020-07-02 0001571996-20-000037 — 5.07
- 2020-05-28 0001571996-20-000028 — 2.02, 9.01
- 2020-04-09 0001193125-20-102602 — 1.01, 2.03, 9.01
- 2020-04-08 0001571996-20-000021 — 5.02
- 2020-04-03 0001571996-20-000019 — 8.01, 9.01
- 2020-03-26 0001571996-20-000015 — 7.01
- 2020-02-27 0001571996-20-000009 — 2.02, 8.01, 9.01
- 2020-02-18 0001571996-20-000005 — 8.01, 9.01
- 2020-01-09 0001571996-20-000002 — 3.02
- 2020-01-06 0001193125-20-002200 — 3.02
- 2019-12-13 0001193125-19-313947 — 3.02
- 2019-12-10 0001571996-19-000052 — 5.02
- 2019-12-02 0001571996-19-000044 — 5.02, 7.01, 9.01
- 2019-11-26 0001571996-19-000042 — 2.02, 9.01
- 2019-09-23 0001193125-19-252192 — 1.01, 2.03, 9.01
- 2019-08-29 0001571996-19-000036 — 2.02, 9.01
- 2019-08-22 0001193125-19-226939 — 7.01, 8.01, 9.01
- 2019-07-11 0001571996-19-000032 — 5.02, 5.07, 9.01
- 2019-07-03 0001571996-19-000030 — 3.02
- 2019-06-27 0001571996-19-000028 — 3.02
- 2019-05-30 0001571996-19-000021 — 2.02, 9.01
- 2019-04-02 0001571996-19-000010 — 5.02
- 2019-03-21 0001193125-19-082281 — 1.01, 1.02, 2.03, 9.01
- 2019-03-19 0001571996-19-000005 — 5.02, 9.01
- 2019-03-14 0001193125-19-074935 — 1.01, 2.03, 9.01
- 2019-03-07 0001193125-19-066045 — 8.01, 9.01
- 2019-02-28 0001571996-19-000002 — 2.02, 9.01
- 2018-12-28 0001193125-18-360943 — 1.01, 1.02, 3.01, 3.03, 5.02, 5.03, 7.01, 8.01, 9.01
- 2018-12-21 0001193125-18-356324 — 1.01, 2.03, 9.01
- 2018-12-14 0001193125-18-349469 — 8.01
- 2018-12-11 0001193125-18-346958 — 5.07, 8.01, 9.01
- 2018-11-29 0001571996-18-000041 — 2.02, 9.01
- 2018-11-28 0001571996-18-000037 — 7.01, 8.01, 9.01
- 2018-11-26 0001193125-18-333967 — 8.01, 9.01
- 2018-11-15 0001193125-18-328110 — 1.01, 9.01 — amendment of 0001193125-18-327222
- 2018-11-15 0001193125-18-327222 — 1.01, 7.01, 9.01
- 2018-10-03 0001193125-18-291390 — 8.01
- 2018-09-06 0001571996-18-000029 — 2.02, 9.01
- 2018-08-06 0001571996-18-000027 — 8.01, 9.01
- 2018-07-02 0001193125-18-210339 — 1.01, 7.01, 9.01
- 2018-06-28 0001571996-18-000024 — 5.07
- 2018-06-04 0001571996-18-000019 — 2.02, 9.01
- 2018-05-17 0001571996-18-000016 — 7.01
- 2018-04-26 0001571996-18-000009 — 7.01, 9.01
- 2018-03-08 0001193125-18-074168 — 2.02, 9.01
- 2018-02-02 0001193125-18-029947 — 7.01, 9.01
- 2017-12-07 0001571996-17-000042 — 2.02, 9.01
- 2017-10-24 0001571996-17-000037 — 1.01, 2.03, 9.01
- 2017-09-15 0001571996-17-000027 — 5.02
- 2017-09-07 0001571996-17-000017 — 2.02, 9.01
- 2017-08-24 0001571996-17-000014 — 8.01
- 2017-06-29 0001571996-17-000011 — 3.03, 5.07, 8.01, 9.01
- 2017-06-08 0001193125-17-197638 — 2.02, 9.01
- 2017-03-30 0001193125-17-102794 — 8.01
- 2017-03-30 0001193125-17-102777 — 2.02, 9.01
- 2017-03-09 0001193125-17-076981 — 1.01, 2.03, 9.01
- 2017-01-17 0001193125-17-011125 — 8.01
- 2016-12-15 0001193125-16-793722 — 8.01
- 2016-12-08 0001193125-16-787976 — 2.02, 9.01
- 2016-11-10 0001193125-16-765964 — 1.02, 8.01
- 2016-11-04 0001193125-16-760249 — 8.01
- 2016-09-13 0001193125-16-708600 — 3.02
- 2016-09-09 0001193125-16-706567 — 1.01, 1.02, 2.01, 2.03, 3.02, 3.03, 5.02, 9.01
- 2016-09-07 0001193125-16-703370 — 3.03, 5.07, 7.01, 8.01, 9.01
- 2016-09-06 0001193125-16-702057 — 2.02, 9.01
- 2016-08-31 0001193125-16-697268 — 8.01, 9.01
- 2016-08-26 0001193125-16-692921 — 8.01, 9.01
- 2016-07-11 0001193125-16-645610 — 8.01
- 2016-07-05 0001193125-16-641679 — 8.01
- 2016-06-22 0001193125-16-629055 — 1.01, 2.03, 8.01, 9.01
- 2016-06-21 0001193125-16-627071 — 8.01, 9.01
- 2016-06-10 0001193125-16-618483 — 2.02, 9.01
- 2016-06-09 0001193125-16-617893 — 8.01, 9.01

## late-filing notifications on or before 2025-06-10

- none on or before 2025-06-10

## item 2.02 — earnings release, exhibit 99.1

[0001571996-25-000046:8k_2_02:1]
EX-99.1
2
exhibit991earnings8kq1fy26.htm
EX-99.1

[0001571996-25-000046:8k_2_02:2]
Document

[0001571996-25-000046:8k_2_02:3]
Exhibit 99.1

[0001571996-25-000046:8k_2_02:4]
Dell Technologies Delivers First Quarter Fiscal 2026 Financial Results

[0001571996-25-000046:8k_2_02:5]
ROUND ROCK, Texas — May 29, 2025 — Dell Technologies (NYSE: DELL) announces financial results for its fiscal 2026 first quarter. The company also provides guidance for its fiscal 2026 second quarter and full year.

[0001571996-25-000046:8k_2_02:6]
First-Quarter Summary

[0001571996-25-000046:8k_2_02:7]
•First-quarter revenue of $23.4 billion, up 5% year over year

[0001571996-25-000046:8k_2_02:8]
•First-quarter operating income of $1.2 billion, up 21% year over year, and non-GAAP operating income of $1.7 billion, up 10%

[0001571996-25-000046:8k_2_02:9]
•First-quarter diluted EPS of $1.37, flat year over year, and non-GAAP diluted EPS of $1.55, up 17%

[0001571996-25-000046:8k_2_02:10]
“All of our core businesses grew as we reached $23.4 billion in revenue in our first quarter, and non-GAAP EPS grew three times faster than revenue,” said Yvonne McGill, chief financial officer, Dell Technologies. “We generated record first-quarter cash flow from operations of $2.8 billion and returned $2.4 billion to shareholders, more than double our quarterly average since we started our capital allocation program in FY23.”

[0001571996-25-000046:8k_2_02:11]
“We achieved first-quarter record servers and networking revenue of $6.3 billion, and we’re experiencing unprecedented demand for our AI-optimized servers,” said Jeff Clarke, vice chairman and chief operating officer, Dell Technologies. “We generated $12.1 billion in AI orders this quarter alone, surpassing the entirety of shipments in all of FY25 and leaving us with $14.4 billion in backlog.”

[0001571996-25-000046:8k_2_02:12]
Infrastructure Solutions Group (ISG)

[0001571996-25-000046:8k_2_02:13]
•Revenue: $10.3 billion, up 12% year over year

[0001571996-25-000046:8k_2_02:14]
•Servers and Networking revenue: First-quarter record $6.3 billion, up 16%

[0001571996-25-000046:8k_2_02:15]
•Storage revenue: $4.0 billion, up 6%

[0001571996-25-000046:8k_2_02:16]
•Operating income: $1.0 billion, up 36% year over year

[0001571996-25-000046:8k_2_02:17]
Client Solutions Group (CSG)

[0001571996-25-000046:8k_2_02:18]
•Revenue: $12.5 billion, up 5% year over year

[0001571996-25-000046:8k_2_02:19]
•Commercial Client revenue: $11.0 billion, up 9%

[0001571996-25-000046:8k_2_02:20]
•Consumer revenue: $1.5 billion, down 19%

[0001571996-25-000046:8k_2_02:21]
•Operating income: $653 million, down 16% year over year

[0001571996-25-000046:8k_2_02:22]
Capital Return

[0001571996-25-000046:8k_2_02:23]
Dell Technologies returned a record $2.4 billion to shareholders in the first quarter through share repurchases and dividends.

[0001571996-25-000046:8k_2_02:24]
1

[0001571996-25-000046:8k_2_02:25]
Guidance Summary

[0001571996-25-000046:8k_2_02:26]
•Full-year FY26 revenue expected between $101.0 billion and $105.0 billion, up 8% year over year at the midpoint of $103.0 billion

[0001571996-25-000046:8k_2_02:27]
•Full-year FY26 GAAP diluted EPS expected to be $7.99 at the midpoint, up 25% year over year, and non-GAAP diluted EPS to be $9.40 at the midpoint, up 15%

[0001571996-25-000046:8k_2_02:28]
•Second-quarter FY26 revenue expected between $28.5 billion and $29.5 billion, up 16% year over year at the midpoint of $29.0 billion

[0001571996-25-000046:8k_2_02:29]
•Second-quarter FY26 GAAP diluted EPS expected to be $1.85 at the midpoint, up 50% year over year, and non-GAAP diluted EPS to be $2.25 at the midpoint, up 15%

[0001571996-25-000046:8k_2_02:30]
2

[0001571996-25-000046:8k_2_02:31]
First Quarter Fiscal 2026 Financial Results

[0001571996-25-000046:8k_2_02:32]
|  | Three Months Ended |  |  |  |  |  |  |
|  | May 2, 2025 |  | May 3, 2024 |  | Change |  |  |  |  |  |  |
|  | (in millions, except per share amounts and percentages; unaudited) |
| Net revenue | $ | 23,378 |  |  | $ | 22,244 |  |  | 5% |  |  |  |  |  |  |
| Operating income | $ | 1,165 |  |  | $ | 965 |  |  | 21% |  |  |  |  |  |  |
| Net income | $ | 965 |  |  | $ | 992 |  |  | (3)% |  |  |  |  |  |  |
| Change in cash from operating activities | $ | 2,796 |  |  | $ | 1,043 |  |  | 168% |  |  |  |  |  |  |
| Earnings per share — diluted | $ | 1.37 |  |  | $ | 1.37 |  |  | —% |  |  |  |  |  |  |
| Non-GAAP operating income | $ | 1,666 |  |  | $ | 1,519 |  |  | 10% |  |  |  |  |  |  |
| Non-GAAP net income | $ | 1,086 |  |  | $ | 959 |  |  | 13% |  |  |  |  |  |  |
| Adjusted free cash flow | $ | 2,232 |  |  | $ | 623 |  |  | 258% |  |  |  |  |  |  |
| Non-GAAP earnings per share — diluted | $ | 1.55 |  |  | $ | 1.32 |  |  | 17% |  |  |  |  |  |  |

[0001571996-25-000046:8k_2_02:33]
Information about Dell Technologies’ non-GAAP financial measures is provided under “Non-GAAP Financial Measures” below. All comparisons in this press release are year over year unless otherwise noted.

[0001571996-25-000046:8k_2_02:34]
Operating Segments Results

[0001571996-25-000046:8k_2_02:35]
|  | Three Months Ended |  |  |  |  |  |  |
|  | May 2, 2025 |  | May 3, 2024 |  | Change |  |  |  |  |  |  |
|  | (in millions, except percentages; unaudited) |
| Infrastructure Solutions Group (ISG): |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Servers and networking | $ | 6,321 |  | $ | 5,466 |  |  | 16% |  |  |  |  |  |  |
| Storage | 3,996 |  |  | 3,761 |  |  | 6% |  |  |  |  |  |  |
| Total ISG net revenue | $ | 10,317 |  |  | $ | 9,227 |  |  | 12% |  |  |  |  |  |  |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| ISG operating income | $ | 998 |  |  | $ | 736 |  |  | 36% |  |  |  |  |  |  |
| % of ISG net revenue | 9.7 | % |  | 8.0 | % |  |  |  |  |  |  |  |  |
| % of total reportable segment operating income | 60 | % |  | 49 | % |  |  |  |  |  |  |  |  |
| Client Solutions Group (CSG): |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 11,046 |  |  | $ | 10,154 |  |  | 9% |  |  |  |  |  |  |
| Consumer | 1,463 |  |  | 1,813 |  |  | (19)% |  |  |  |  |  |  |
| Total CSG net revenue | $ | 12,509 |  |  | $ | 11,967 |  |  | 5% |  |  |  |  |  |  |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| CSG operating income | $ | 653 |  |  | $ | 777 |  |  | (16)% |  |  |  |  |  |  |
| % of CSG net revenue | 5.2 | % |  | 6.5 | % |  |  |  |  |  |  |  |  |
| % of total reportable segment operating income | 40 | % |  | 51 | % |  |  |  |  |  |  |  |  |

[0001571996-25-000046:8k_2_02:36]
Conference call information

[0001571996-25-000046:8k_2_02:37]
As previously announced, the company will hold a conference call to discuss its performance and financial guidance on May 29 at 3:30 p.m. CST. Prior to the start of the conference call, prepared remarks and a presentation containing additional financial and operating information may be downloaded from investors.delltechnologies.com. The conference call will be broadcast live over the internet and can be accessed at https://investors.delltechnologies.com/news-events/upcoming-events.

[0001571996-25-000046:8k_2_02:38]
For those unable to listen to the live broadcast, the final remarks and presentation with additional financial and operating information will be available following the broadcast, and an archived version will be available at the same location for one year.

[0001571996-25-000046:8k_2_02:39]
About Dell Technologies

[0001571996-25-000046:8k_2_02:40]
Dell Technologies (NYSE:DELL) helps organizations and individuals build their digital future and transform how they work, live and play. The company provides customers with the industry’s broadest and most innovative technology and services portfolio for the AI era.

[0001571996-25-000046:8k_2_02:41]
Contacts

[0001571996-25-000046:8k_2_02:42]
Investors: Investor_Relations@Dell.com

[0001571996-25-000046:8k_2_02:43]
Media: Media.Relations@Dell.com

[0001571996-25-000046:8k_2_02:44]
# # #

[0001571996-25-000046:8k_2_02:45]
Copyright © 2025 Dell Inc. or its subsidiaries. All Rights Reserved. Dell Technologies, Dell, EMC and Dell EMC are trademarks of Dell Inc. or its subsidiaries. Other trademarks may be trademarks of their respective owners.

[0001571996-25-000046:8k_2_02:46]
Non-GAAP Financial Measures:

[0001571996-25-000046:8k_2_02:47]
This press release presents information about non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, non-GAAP earnings per share attributable to Dell Technologies Inc. – diluted, free cash flow, and adjusted free cash flow, all of which are non-GAAP financial measures provided as a supplement to the results provided in accordance with generally accepted accounting principles in the United States of America (“GAAP”). A reconciliation of each non-GAAP financial measure to the most directly comparable GAAP financial measure is provided in the attached tables for each of the fiscal periods indicated.

[0001571996-25-000046:8k_2_02:48]
Special Note on Forward-Looking Statements:

[0001571996-25-000046:8k_2_02:49]
Forward-looking statements include, among others, any statements regarding Dell Technologies’ expectations for second-quarter and full-year fiscal 2026 revenue, GAAP diluted earnings per share and non-GAAP diluted earnings per share, and any other statements regarding Dell Technologies’ prospects and its future operations, financial condition, volumes, cash flows, expenses or other financial items, including management’s plans or strategies and objectives for any of the foregoing and any assumptions, expectations or beliefs underlying any of the foregoing.

[0001571996-25-000046:8k_2_02:50]
Dell Technologies’ results or events in future periods could differ materially from those expressed or implied by these forward-looking statements because of risks, uncertainties, and other factors that include, but are not limited to, the following: adverse global economic conditions, trade disruptions, and instability in financial markets; competitive pressures; Dell Technologies’ ability to successfully execute its strategy; Dell Technologies’ relationships with third-party suppliers for products and components; Dell Technologies’ use of single-source or limited-source suppliers; effects on Dell Technologies’ operating performance related to demand for AI solutions; management of Dell Technologies’ AI solutions and use of AI in internal functions and operations; Dell Technologies’ ability to deliver high-quality products, software, and services and to manage solutions and products and services transitions in an effective manner; Dell Technologies’ ability to successfully implement its cost efficiency plans; Dell Technologies’ ability to successfully execute on strategic initiatives including acquisitions and divestitures; security incidents, including cyber-attacks; Dell Technologies’ foreign operations and ability to generate substantial non-U.S. net revenue; Dell Technologies’ product, services, customer, and geographic sales mix, and seasonal sales trends; the performance of Dell Technologies’ sales channel partners; access to the capital markets by Dell Technologies or its customers; adverse economic conditions, changing customer mix, and the effect of additional regulation on Dell Technologies’ financial services activities;

[0001571996-25-000046:8k_2_02:51]
counterparty default risks; material impairment of the value of goodwill or intangible assets; the loss by Dell Technologies of any contracts for ISG services and solutions and its ability to perform such contracts at their estimated costs; loss by Dell Technologies of government contracts; Dell Technologies’ ability to develop and protect its proprietary intellectual property or obtain licenses to intellectual property developed by others on commercially reasonable and competitive terms; disruptions in Dell Technologies’ infrastructure; Dell Technologies’ ability to hedge effectively its exposure to fluctuations in foreign currency exchange rates and interest rates; expiration of tax holidays or favorable tax rate structures, or unfavorable outcomes in tax audits and other tax compliance matters; impairment of portfolio investments; unfavorable results of legal proceedings; evolving and varied expectations and regulatory requirements relating to sustainability issues; the effect of global climate change and related legal, regulatory or market measures; compliance with environmental and safety laws; compliance requirements of anti-corruption laws, economic sanctions and other trade laws, human rights laws, or other laws; Dell Technologies’ dependence on the services of Michael Dell and key employees; Dell Technologies’ level of indebtedness; and business and financial factors and legal restrictions affecting continuation of Dell Technologies’ quarterly cash dividend policy and dividend rate.

[0001571996-25-000046:8k_2_02:52]
This list of risks, uncertainties, and other factors is not complete. Dell Technologies discusses some of these matters more fully, as well as certain risk factors that could affect Dell Technologies’ business, financial condition, results of operations, and prospects, in its reports filed with the SEC, including Dell Technologies’ annual report on Form 10-K for the fiscal year ended January 31, 2025, quarterly reports on Form 10-Q, and current reports on Form 8-K. These filings are available for review through the SEC’s website at www.sec.gov. Any or all forward-looking statements Dell Technologies makes may turn out to be wrong and can be affected by inaccurate assumptions Dell Technologies might make or by known or unknown risks, uncertainties, and other factors, including those identified in this press release. Accordingly, you should not place undue reliance on the forward-looking statements made in this press release, which speak only as of its date. Dell Technologies does not undertake to update, and expressly disclaims any duty to update, its forward-looking statements, whether as a result of circumstances or events that arise after the date they are made, new information, or otherwise.

[0001571996-25-000046:8k_2_02:53]
5

[0001571996-25-000046:8k_2_02:54]
DELL TECHNOLOGIES INC.

[0001571996-25-000046:8k_2_02:55]
Condensed Consolidated Statements of Income and Related Financial Highlights

[0001571996-25-000046:8k_2_02:56]
(in millions, except percentages; unaudited)

[0001571996-25-000046:8k_2_02:57]
|  | Three Months Ended |  |  |  |  |  |  |
|  | May 2, 2025 |  | May 3, 2024 |  | Change |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Products | $ | 17,599 |  |  | $ | 16,127 |  |  | 9% |  |  |  |  |  |  |
| Services | 5,779 |  |  | 6,117 |  |  | (6)% |  |  |  |  |  |  |
| Total net revenue | 23,378 |  |  | 22,244 |  |  | 5% |  |  |  |  |  |  |
| Cost of net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Products | 15,116 |  |  | 13,721 |  |  | 10% |  |  |  |  |  |  |
| Services | 3,325 |  |  | 3,672 |  |  | (9)% |  |  |  |  |  |  |
| Total cost of net revenue | 18,441 |  |  | 17,393 |  |  | 6% |  |  |  |  |  |  |
| Gross margin | 4,937 |  |  | 4,851 |  |  | 2% |  |  |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative | 2,964 |  |  | 3,123 |  |  | (5)% |  |  |  |  |  |  |
| Research and development | 808 |  |  | 763 |  |  | 6% |  |  |  |  |  |  |
| Total operating expenses | 3,772 |  |  | 3,886 |  |  | (3)% |  |  |  |  |  |  |
| Operating income | 1,165 |  |  | 965 |  |  | 21% |  |  |  |  |  |  |
| Interest and other, net | (82) |  |  | (373) |  |  | 78% |  |  |  |  |  |  |
| Income before income taxes | 1,083 |  |  | 592 |  |  | 83% |  |  |  |  |  |  |
| Income tax expense | 118 |  |  | (400) |  |  | 130% |  |  |  |  |  |  |
| Net income | 965 |  |  | 992 |  |  | (3)% |  |  |  |  |  |  |
| Less: Net loss attributable to non-controlling interests | — |  |  | (5) |  |  | 100% |  |  |  |  |  |  |
| Net income attributable to Dell Technologies Inc. | $ | 965 |  |  | $ | 997 |  |  | (3)% |  |  |  |  |  |  |
| Percentage of Total Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Gross margin | 21.1 | % |  | 21.8 | % |  |  |  |  |  |  |  |  |
| Selling, general, and administrative | 12.6 | % |  | 14.1 | % |  |  |  |  |  |  |  |  |
| Research and development | 3.5 | % |  | 3.4 | % |  |  |  |  |  |  |  |  |
| Operating expenses | 16.1 | % |  | 17.5 | % |  |  |  |  |  |  |  |  |
| Operating income | 5.0 | % |  | 4.3 | % |  |  |  |  |  |  |  |  |
| Income before income taxes | 4.6 | % |  | 2.7 | % |  |  |  |  |  |  |  |  |
| Net income | 4.1 | % |  | 4.5 | % |  |  |  |  |  |  |  |  |
| Income tax rate | 10.9 | % |  | (67.6) | % |  |  |  |  |  |  |  |  |

[0001571996-25-000046:8k_2_02:58]
Amounts are based on underlying data and may not visually foot due to rounding.

[0001571996-25-000046:8k_2_02:59]
6

[0001571996-25-000046:8k_2_02:60]
DELL TECHNOLOGIES INC.

[0001571996-25-000046:8k_2_02:61]
Condensed Consolidated Statements of Financial Position

[0001571996-25-000046:8k_2_02:62]
(in millions; unaudited)

[0001571996-25-000046:8k_2_02:63]
|  | May 2, 2025 |  | January 31, 2025 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 7,700 |  |  | $ | 3,633 |  |
| Accounts receivable, net of allowance of $82 and $63 | 9,785 |  |  | 10,298 |  |
| Short-term financing receivables, net of allowance of $74 and $78 | 5,381 |  |  | 5,304 |  |
| Inventories | 7,415 |  |  | 6,716 |  |
| Other current assets | 12,644 |  |  | 9,610 |  |
| Current assets held for sale | — |  |  | 668 |  |
| Total current assets | 42,925 |  |  | 36,229 |  |
| Property, plant, and equipment, net | 6,383 |  |  | 6,336 |  |
| Long-term investments | 1,591 |  |  | 1,496 |  |
| Long-term financing receivables, net of allowance of $70 and $75 | 6,042 |  |  | 5,927 |  |
| Goodwill | 19,315 |  |  | 19,120 |  |
| Intangible assets, net | 4,868 |  |  | 4,988 |  |
| Other non-current assets | 5,745 |  |  | 5,650 |  |
| Total assets | $ | 86,869 |  |  | $ | 79,746 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Short-term debt | $ | 4,845 |  |  | $ | 5,204 |  |
| Accounts payable | 25,349 |  |  | 20,832 |  |
| Accrued and other | 6,321 |  |  | 6,597 |  |
| Short-term deferred revenue | 13,907 |  |  | 13,673 |  |
| Current liabilities held for sale | — |  |  | 221 |  |
| Total current liabilities | 50,422 |  |  | 46,527 |  |
| Long-term debt | 23,936 |  |  | 19,363 |  |
| Long-term deferred revenue | 12,413 |  |  | 12,292 |  |
| Other non-current liabilities | 3,122 |  |  | 2,951 |  |
| Total liabilities | 89,893 |  |  | 81,133 |  |
| Stockholders’ equity (deficit): |  |  |  |
| Common stock and capital in excess of $0.01 par value | 8,957 |  |  | 9,119 |  |
| Treasury stock at cost | (10,488) |  |  | (8,502) |  |
| Accumulated deficit | (567) |  |  | (1,160) |  |
| Accumulated other comprehensive loss | (926) |  |  | (939) |  |
| Total Dell Technologies Inc. stockholders’ equity (deficit) | (3,024) |  |  | (1,482) |  |
| Non-controlling interests | — |  |  | 95 |  |
| Total stockholders’ equity (deficit) | (3,024) |  |  | (1,387) |  |
| Total liabilities and stockholders’ equity | $ | 86,869 |  |  | $ | 79,746 |  |

[0001571996-25-000046:8k_2_02:64]
7

[0001571996-25-000046:8k_2_02:65]
DELL TECHNOLOGIES INC.

[0001571996-25-000046:8k_2_02:66]
Condensed Consolidated Statements of Cash Flows

[0001571996-25-000046:8k_2_02:67]
(in millions; unaudited)

[0001571996-25-000046:8k_2_02:68]
|  | Three Months Ended |  |  |
|  | May 2, 2025 |  | May 3, 2024 |  |  |  |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |
| Net income | $ | 965 |  |  | $ | 992 |  |  |  |  |  |
| Adjustments to reconcile net income to net cash provided by operating activities: | 1,831 |  |  | 51 |  |  |  |  |  |
| Change in cash from operating activities | 2,796 |  |  | 1,043 |  |  |  |  |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |
| Purchases of investments | (97) |  |  | (39) |  |  |  |  |  |
| Maturities and sales of investments | 31 |  |  | 119 |  |  |  |  |  |
| Capital expenditures and capitalized software development costs | (568) |  |  | (596) |  |  |  |  |  |
| Divestitures of businesses and assets, net | 533 |  |  | — |  |  |  |  |  |
| Other | 13 |  |  | 60 |  |  |  |  |  |
| Change in cash from investing activities | (88) |  |  | (456) |  |  |  |  |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |
| Repurchases of common stock | (1,980) |  |  | (700) |  |  |  |  |  |
| Repurchases of common stock for employee tax withholdings | (352) |  |  | (521) |  |  |  |  |  |
| Payments of dividends and dividend equivalents | (396) |  |  | (336) |  |  |  |  |  |
| Proceeds from debt | 6,308 |  |  | 2,992 |  |  |  |  |  |
| Repayments of debt | (2,310) |  |  | (3,477) |  |  |  |  |  |
| Debt-related costs and other, net | (33) |  |  | (35) |  |  |  |  |  |
| Change in cash from financing activities | 1,237 |  |  | (2,077) |  |  |  |  |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash | 89 |  |  | (55) |  |  |  |  |  |
| Change in cash, cash equivalents, and restricted cash | 4,034 |  |  | (1,545) |  |  |  |  |  |
| Cash, cash equivalents, and restricted cash at beginning of the period | 3,819 |  |  | 7,507 |  |  |  |  |  |
| Cash, cash equivalents, and restricted cash at end of the period | $ | 7,853 |  |  | $ | 5,962 |  |  |  |  |  |

[0001571996-25-000046:8k_2_02:69]
DELL TECHNOLOGIES INC.

[0001571996-25-000046:8k_2_02:70]
Segment Information

[0001571996-25-000046:8k_2_02:71]
(in millions, except percentages; unaudited; continued on next page)

[0001571996-25-000046:8k_2_02:72]
|  | Three Months Ended |  |  |  |  |  |  |
|  | May 2, 2025 |  | May 3, 2024 |  | Change |  |  |  |  |  |  |
| Infrastructure Solutions Group (ISG): |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Servers and networking | $ | 6,321 |  | $ | 5,466 |  |  | 16% |  |  |  |  |  |  |
| Storage | 3,996 |  |  | 3,761 |  |  | 6% |  |  |  |  |  |  |
| Total ISG net revenue | $ | 10,317 |  |  | $ | 9,227 |  |  | 12% |  |  |  |  |  |  |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| ISG operating income | $ | 998 |  |  | $ | 736 |  |  | 36% |  |  |  |  |  |  |
| % of ISG net revenue | 9.7 | % |  | 8.0 | % |  |  |  |  |  |  |  |  |
| % of total reportable segment operating income | 60 | % |  | 49 | % |  |  |  |  |  |  |  |  |
| Client Solutions Group (CSG): |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 11,046 |  |  | $ | 10,154 |  |  | 9% |  |  |  |  |  |  |
| Consumer | 1,463 |  |  | 1,813 |  |  | (19)% |  |  |  |  |  |  |
| Total CSG net revenue | $ | 12,509 |  |  | $ | 11,967 |  |  | 5% |  |  |  |  |  |  |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| CSG operating income | $ | 653 |  |  | $ | 777 |  |  | (16)% |  |  |  |  |  |  |
| % of CSG net revenue | 5.2 | % |  | 6.5 | % |  |  |  |  |  |  |  |  |
| % of total reportable segment operating income | 40 | % |  | 51 | % |  |  |  |  |  |  |  |  |

[0001571996-25-000046:8k_2_02:73]
Amounts are based on underlying data and may not visually foot due to rounding.

[0001571996-25-000046:8k_2_02:74]
9

[0001571996-25-000046:8k_2_02:75]
DELL TECHNOLOGIES INC.

[0001571996-25-000046:8k_2_02:76]
Segment Information

[0001571996-25-000046:8k_2_02:77]
(in millions; unaudited; continued)

[0001571996-25-000046:8k_2_02:78]
|  | Three Months Ended |  |  |  |  |
|  | May 2, 2025 |  | May 3, 2024 |  |  |  |  |  |  |
| Reconciliation to consolidated net revenue: |  |  |  |  |  |  |  |  |  |
| Reportable segment net revenue | $ | 22,826 |  |  | $ | 21,194 |  |  |  |  |  |  |  |
| Corporate and other (a) | 552 |  |  | 1,050 |  |  |  |  |  |  |  |
| Total consolidated net revenue | $ | 23,378 |  |  | $ | 22,244 |  |  |  |  |  |  |  |
| Reconciliation to consolidated operating income: |  |  |  |  |  |  |  |  |  |
| Reportable segment operating income (b) | $ | 1,651 |  |  | $ | 1,513 |  |  |  |  |  |  |  |
| Corporate and other (a) | 15 |  |  | 6 |  |  |  |  |  |  |  |
| Amortization of intangibles (c) | (126) |  |  | (168) |  |  |  |  |  |  |  |
| Stock-based compensation expense (d) | (190) |  |  | (210) |  |  |  |  |  |  |  |
| Other corporate expenses (e) | (185) |  |  | (176) |  |  |  |  |  |  |  |
| Total consolidated operating income (f) | $ | 1,165 |  |  | $ | 965 |  |  |  |  |  |  |  |

[0001571996-25-000046:8k_2_02:79]
_________________

[0001571996-25-000046:8k_2_02:80]
(a)Corporate and other consists of results of divested businesses or non-reportable segments whose offerings are no longer actively sold, including (i) VMware Resale, (ii) Secureworks, and (iii) Virtustream, and do not meet the requirements for a reportable segment, either individually or collectively. Additionally, Corporate and other includes other items that are managed at the corporate level and are not allocated to reportable segments.

[0001571996-25-000046:8k_2_02:81]
(b)Depreciation expense directly attributable to each reportable segment is included in the operating results of each segment. However, the Chief Operating Decision Maker does not evaluate depreciation expense by operating segment, and therefore such expense is not separately presented.

[0001571996-25-000046:8k_2_02:82]
(c)Amortization of intangibles includes non-cash purchase accounting adjustments that are primarily related to the EMC merger transaction.

[0001571996-25-000046:8k_2_02:83]
(d)Stock-based compensation expense consists of equity awards granted based on the estimated fair value of those awards at grant date.

[0001571996-25-000046:8k_2_02:84]
(e)Other corporate expenses includes severance expenses, payroll taxes associated with stock-based compensation, incentive charges related to equity investments, facility action costs, transaction-related expenses, and impairment charges.

[0001571996-25-000046:8k_2_02:85]
(f)Income and expenses within Interest and other, net, is not allocated to the reportable segments. Therefore, the Company only reports reportable segment operating income.

[0001571996-25-000046:8k_2_02:86]
SUPPLEMENTAL SELECTED NON-GAAP FINANCIAL MEASURES

[0001571996-25-000046:8k_2_02:87]
These tables present information about the company’s non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, non-GAAP earnings per share attributable to Dell Technologies Inc. - diluted, free cash flow and adjusted free cash flow, all of which are non-GAAP financial measures provided as a supplement to the results provided in accordance with generally accepted accounting principles in the United States of America (“GAAP”). A detailed discussion of Dell Technologies’ reasons for including certain of these non-GAAP financial measures, the limitations associated with these measures, the items excluded from these measures, and the company’s reason for excluding those items are presented in “Management’s Discussion and Analysis of Financial Condition and Results of Operations — Non-GAAP Financial Measures” in the company’s periodic reports filed with the SEC. Dell Technologies encourages investors to review the non-GAAP discussion in these reports in conjunction with the presentation of non-GAAP financial measures.

[0001571996-25-000046:8k_2_02:88]
11

[0001571996-25-000046:8k_2_02:89]
DELL TECHNOLOGIES INC.

[0001571996-25-000046:8k_2_02:90]
Selected Financial Measures

[0001571996-25-000046:8k_2_02:91]
(in millions, except per share amounts and percentages; unaudited)

[0001571996-25-000046:8k_2_02:92]
|  | Three Months Ended |  |  |  |  |  |  |
|  | May 2, 2025 |  | May 3, 2024 |  | Change |  |  |  |  |  |  |
| Net revenue | $ | 23,378 |  |  | $ | 22,244 |  |  | 5% |  |  |  |  |  |  |
| Non-GAAP gross margin | $ | 5,057 |  |  | $ | 4,992 |  |  | 1% |  |  |  |  |  |  |
| % of net revenue | 21.6 | % |  | 22.4 | % |  |  |  |  |  |  |  |  |
| Non-GAAP operating expenses | $ | 3,391 |  |  | $ | 3,473 |  |  | (2)% |  |  |  |  |  |  |
| % of net revenue | 14.5 | % |  | 15.6 | % |  |  |  |  |  |  |  |  |
| Non-GAAP operating income | $ | 1,666 |  |  | $ | 1,519 |  |  | 10% |  |  |  |  |  |  |
| % of net revenue | 7.1 | % |  | 6.8 | % |  |  |  |  |  |  |  |  |
| Non-GAAP net income | $ | 1,086 |  |  | $ | 959 |  |  | 13% |  |  |  |  |  |  |
| % of net revenue | 4.6 | % |  | 4.3 | % |  |  |  |  |  |  |  |  |
| Non-GAAP earnings per share — diluted | $ | 1.55 |  |  | $ | 1.32 |  |  | 17% |  |  |  |  |  |  |

[0001571996-25-000046:8k_2_02:93]
Amounts are based on underlying data and may not visually foot due to rounding.

[0001571996-25-000046:8k_2_02:94]
DELL TECHNOLOGIES INC.

[0001571996-25-000046:8k_2_02:95]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-25-000046:8k_2_02:96]
(in millions, except percentages; unaudited; continued on next page)

[0001571996-25-000046:8k_2_02:97]
|  | Three Months Ended |  |  |  |  |  |  |
|  | May 2, 2025 |  | May 3, 2024 |  | Change |  |  |  |  |  |  |
| Gross margin | $ | 4,937 |  |  | $ | 4,851 |  |  | 2% |  |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 41 |  |  | 60 |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense | 39 |  |  | 38 |  |  |  |  |  |  |  |  |  |
| Other corporate expenses | 40 |  |  | 43 |  |  |  |  |  |  |  |  |  |
| Non-GAAP gross margin | $ | 5,057 |  |  | $ | 4,992 |  |  | 1% |  |  |  |  |  |  |
| Operating expenses | $ | 3,772 |  |  | $ | 3,886 |  |  | (3)% |  |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | (85) |  |  | (108) |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense | (151) |  |  | (172) |  |  |  |  |  |  |  |  |  |
| Other corporate expenses | (145) |  |  | (133) |  |  |  |  |  |  |  |  |  |
| Non-GAAP operating expenses | $ | 3,391 |  |  | $ | 3,473 |  |  | (2)% |  |  |  |  |  |  |
| Operating income | $ | 1,165 |  |  | $ | 965 |  |  | 21% |  |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 126 |  |  | 168 |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense | 190 |  |  | 210 |  |  |  |  |  |  |  |  |  |
| Other corporate expenses | 185 |  |  | 176 |  |  |  |  |  |  |  |  |  |
| Non-GAAP operating income | $ | 1,666 |  |  | $ | 1,519 |  |  | 10% |  |  |  |  |  |  |
| Net income | $ | 965 |  |  | $ | 992 |  |  | (3)% |  |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 126 |  |  | 168 |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense | 190 |  |  | 210 |  |  |  |  |  |  |  |  |  |
| Other corporate (income) expenses | (58) |  |  | 170 |  |  |  |  |  |  |  |  |  |
| Fair value adjustments on equity investments | (17) |  |  | 30 |  |  |  |  |  |  |  |  |  |
| Aggregate adjustment for income taxes (a) | (120) |  |  | (611) |  |  |  |  |  |  |  |  |  |
| Non-GAAP net income | $ | 1,086 |  |  | $ | 959 |  |  | 13% |  |  |  |  |  |  |

[0001571996-25-000046:8k_2_02:98]
____________________

[0001571996-25-000046:8k_2_02:99]
(a)The company’s non-GAAP income tax is calculated using a fixed estimated annual tax rate.

[0001571996-25-000046:8k_2_02:100]
13

[0001571996-25-000046:8k_2_02:101]
DELL TECHNOLOGIES INC.

[0001571996-25-000046:8k_2_02:102]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-25-000046:8k_2_02:103]
(unaudited; continued)

[0001571996-25-000046:8k_2_02:104]
|  | Three Months Ended |  |  |  |  |  |  |  |  |  |  |
|  | May 2, 2025 |  | May 3, 2024 |  | Change |  |  |  |  |  |  |  |  |  |  |
| Earnings per share attributable to Dell Technologies Inc. — diluted | $ | 1.37 |  |  | $ | 1.37 |  |  | — | % |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 0.18 |  |  | 0.23 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense | 0.27 |  |  | 0.29 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other corporate (income) expenses | (0.08) |  |  | 0.24 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Fair value adjustments on equity investments | (0.02) |  |  | 0.04 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Aggregate adjustment for income taxes (a) | (0.17) |  |  | (0.84) |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total non-GAAP adjustments attributable to non-controlling interests | — |  |  | (0.01) |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP earnings per share attributable to Dell Technologies Inc. — diluted | $ | 1.55 |  |  | $ | 1.32 |  |  | 17 | % |  |  |  |  |  |  |  |  |  |  |

[0001571996-25-000046:8k_2_02:105]
____________________

[0001571996-25-000046:8k_2_02:106]
(a)The company’s non-GAAP income tax is calculated using a fixed estimated annual tax rate.

[0001571996-25-000046:8k_2_02:107]
DELL TECHNOLOGIES INC.

[0001571996-25-000046:8k_2_02:108]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-25-000046:8k_2_02:109]
(in millions, except percentages; unaudited; continued)

[0001571996-25-000046:8k_2_02:110]
|  | Three Months Ended |  |  |  |  |  |  |  |  |  |  |
|  | May 2, 2025 |  | May 3, 2024 |  | Change |  |  |  |  |  |  |  |  |  |  |
| Cash flow from operations | $ | 2,796 |  |  | $ | 1,043 |  |  | 168 | % |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Capital expenditures and capitalized software development costs, net (a) | (568) |  |  | (586) |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Free cash flow | $ | 2,228 |  |  | $ | 457 |  |  | 388 | % |  |  |  |  |  |  |  |  |  |  |
| Free cash flow | $ | 2,228 |  |  | $ | 457 |  |  | 388 | % |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Financing receivables (b) | (23) |  |  | 165 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equipment under operating leases (c) | 27 |  |  | 1 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Adjusted free cash flow | $ | 2,232 |  |  | $ | 623 |  |  | 258 | % |  |  |  |  |  |  |  |  |  |  |

[0001571996-25-000046:8k_2_02:111]
____________________

[0001571996-25-000046:8k_2_02:112]
(a)Capital expenditures and capitalized software development costs, net includes proceeds from sales of facilities, land, and other assets.

[0001571996-25-000046:8k_2_02:113]
(b)Financing receivables represent the operating cash flow impact from the change in financing receivables.

[0001571996-25-000046:8k_2_02:114]
(c)Equipment under operating leases represents the net impact of capital expenditures and depreciation expense for leases and contractually embedded leases identified within flexible consumption arrangements.

[0001571996-25-000046:8k_2_02:115]
15

[0001571996-25-000046:8k_2_02:116]
DELL TECHNOLOGIES INC.

[0001571996-25-000046:8k_2_02:117]
Reconciliation of Non-GAAP Financial Measures in Summary Guidance

[0001571996-25-000046:8k_2_02:118]
(unaudited)

[0001571996-25-000046:8k_2_02:119]
|  |  |  |  |  | Three Months Ending |  |  |  |  |  | Fiscal Year Ending |
|  |  |  |  |  | August 1, 2025 |  |  |  |  |  | January 30, 2026 |
| Earnings per share attributable to Dell Technologies Inc. — diluted |  |  |  |  | $ | 1.85 |  |  |  |  |  |  | $ | 7.99 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles (a) |  |  |  |  | 0.18 |  |  |  |  |  |  | 0.73 |  |
| Stock-based compensation |  |  |  |  | 0.26 |  |  |  |  |  |  | 1.07 |  |
| Other corporate (income) expenses (b) |  |  |  |  | — |  |  |  |  |  |  | (0.08) |  |
| Fair value adjustments on equity investments (c) |  |  |  |  | — |  |  |  |  |  |  | (0.02) |  |
| Aggregate adjustment for income taxes (d) |  |  |  |  | (0.04) |  |  |  |  |  |  | (0.29) |  |
| Non-GAAP earnings per share attributable to Dell Technologies Inc. — diluted |  |  |  |  | $ | 2.25 |  |  |  |  |  |  | $ | 9.40 |  |

[0001571996-25-000046:8k_2_02:120]
____________________

[0001571996-25-000046:8k_2_02:121]
(a)Amortization of intangibles represents an estimate for acquisitions completed as of May 2, 2025 and does not include estimates for potential acquisitions, if any, during fiscal 2026.

[0001571996-25-000046:8k_2_02:122]
(b)Consists primarily of severance expenses, payroll taxes associated with stock-based compensation, facility action costs, transaction-related expenses, impairment charges, and incentive charges related to equity investments. Additionally, this consists of transaction related gains on sales of businesses that have been completed as of May 2, 2025 and does not include estimates for potential transactions, if any, during fiscal 2026. No estimate is included for severance expense as such expense cannot be reasonably estimated at this time.

[0001571996-25-000046:8k_2_02:123]
(c)No estimates are included for potential fair value adjustments on strategic investments given the potential volatility of either gains or losses on those equity investments.

[0001571996-25-000046:8k_2_02:124]
(d)The aggregate adjustment for income taxes is the estimated combined income tax effect for the adjustments shown above as well as an adjustment for discrete tax items. The company’s non-GAAP income tax is calculated using a fixed estimated annual tax rate.
