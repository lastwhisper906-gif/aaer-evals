# DELL note change history — 0001571996-24-000143 → 0001571996-25-000063


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2025-06-10):
[0001571996-25-000063:note_history:1]
The Company has contractual obligations to purchase goods or services, which specify significant terms (including fixed or minimum quantities to be purchased), fixed, minimum, or variable price provisions, and the approximate timing of the transaction. Purchase obligations are primarily related to commitments with suppliers and software maintenance and support services. As of May 2, 2025, such purchase obligations were $5.6 billion for the remainder of Fiscal 2026, $0.6 billion for Fiscal 2027, and $1.2 billion for Fiscal 2028 and thereafter.

- changed (2025-06-10):
[0001571996-25-000063:note_history:2]
The Company is involved in various claims, suits, assessments, investigations, and legal proceedings that arise from time to time in the ordinary course of its business, consisting of matters involving consumer, antitrust, tax, intellectual property, and other issues on a global basis.
  (was, 2024-12-10, similarity 0.9043):
[0001571996-24-000143:note_history:2]
The Company is involved in various claims, suits, assessments, investigations, and legal proceedings that arise from time to time in the ordinary course of its business, including those identified below, consisting of matters involving consumer, antitrust, tax, intellectual property, and other issues on a global basis.

- changed (2025-06-10):
[0001571996-25-000063:note_history:3]
The Company accrues a liability when it believes that it is both probable that a liability has been incurred and that it can reasonably estimate the amount of the loss. The Company reviews these accruals at least quarterly and adjusts them to reflect ongoing negotiations, settlements, rulings, advice of legal counsel, and other relevant information. To the extent new information is obtained and the Company’s views on the probable outcomes of claims, suits, assessments, investigations, or legal proceedings change, changes in the Company’s accrued liabilities are recorded in the period in which such a determination is made. For some matters, the incurrence of a liability is not probable or the amount cannot be reasonably estimated and therefore accruals have not been made. As of May 2, 2025, the Company does not currently anticipate that any of the legal proceedings it is involved in will have a material adverse effect on its business, financial condition, results of operations, or cash flows.
  (was, 2024-12-10, similarity 0.8765):
[0001571996-24-000143:note_history:3]
The Company accrues a liability when it believes that it is both probable that a liability has been incurred and that it can reasonably estimate the amount of the loss. The Company reviews these accruals at least quarterly and adjusts them to reflect ongoing negotiations, settlements, rulings, advice of legal counsel, and other relevant information. To the extent new information is obtained and the Company’s views on the probable outcomes of claims, suits, assessments, investigations, or legal proceedings change, changes in the Company’s accrued liabilities are recorded in the period in which such a determination is made. For some matters, the incurrence of a liability is not probable or the amount cannot be reasonably estimated and therefore accruals have not been made.

- changed (2025-06-10):
[0001571996-25-000063:note_history:4]
In accordance with the relevant accounting guidance, the Company provides disclosures of matters where it is at least reasonably possible that the Company could experience a material loss exceeding the amounts already accrued for across all proceedings or matters. In addition, the Company also discloses matters based on its consideration of other matters and qualitative factors, including the experience of other companies in the industry, and investor, customer, and employee relations considerations. As of May 2, 2025, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for across all proceedings or matters has been incurred. However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company’s business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters. Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company’s business, financial condition, results of operations, or cash flows will depend on a number of factors, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.
  (was, 2024-12-10, similarity 0.9794):
[0001571996-24-000143:note_history:4]
In accordance with the relevant accounting guidance, the Company provides disclosures of matters where it is at least reasonably possible that the Company could experience a material loss exceeding the amounts already accrued for these or other proceedings or matters. In addition, the Company also discloses matters based on its consideration of other matters and qualitative factors, including the experience of other companies in the industry, and investor, customer, and employee relations considerations. As of November 1, 2024, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for these or other proceedings or matters has been incurred. However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company’s business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters. Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company’s business, financial condition, results of operations, or cash flows will depend on a number of factors, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.

- changed (2025-06-10):
[0001571996-25-000063:note_history:5]
Under the Separation and Distribution Agreement entered into with VMware, Inc. upon completion of its spin-off of VMware, Inc. on November 1, 2021, Dell Technologies agreed to indemnify VMware, Inc., each of its subsidiaries and each of their respective directors, officers, employees, as well as any successors and assigns of the foregoing, from and against all liabilities relating to, arising out of or resulting from, among other matters, the liabilities allocated to Dell Technologies as part of the separation of Dell Technologies and VMware, Inc. (currently operating under the name VMware LLC, and individually and together with its subsidiaries, “VMware”) and their respective businesses (the “Separation”). VMware similarly agreed to indemnify Dell Technologies Inc., each of its subsidiaries and each of their respective directors, officers, and employees from and against all liabilities relating to, arising out of or resulting from, among other matters, the liabilities allocated to VMware as part of the Separation. The amounts that VMware and Dell Technologies may be obligated to pay each other could vary depending on the outcome of certain unresolved tax matters, which may not be resolved for several years. Net income tax indemnification receivables from VMware were immaterial as of May 2, 2025 and January 31, 2025.
  (was, 2024-12-10, similarity 0.9638):
[0001571996-24-000143:note_history:5]
Under the Separation and Distribution Agreement entered into with VMware, Inc. upon completion of the spin-off of VMware, Inc. on November 1, 2021 (the “VMware Spin-off”), Dell Technologies agreed to indemnify VMware, Inc., each of its subsidiaries and each of their respective directors, officers, employees, as well as any successors and assigns of the foregoing, from and against all liabilities relating to, arising out of or resulting from, among other matters, the liabilities allocated to Dell Technologies as part of the separation of Dell Technologies and VMware, Inc. (currently operating under the name “VMware LLC,” and individually and together with its subsidiaries, “VMware”) and their respective businesses (the “Separation”). VMware similarly agreed to indemnify Dell Technologies Inc., each of its subsidiaries and each of their respective directors, officers, and employees from and against all liabilities relating to, arising out of or resulting from, among other matters, the liabilities allocated to VMware as part of the Separation. The amounts that VMware and Dell Technologies may be obligated to pay each other could vary depending on the outcome of certain unresolved tax matters, which may not be resolved for several years. Net income tax indemnification receivables from VMware were immaterial as of November 1, 2024 and February 2, 2024.

- removed (2025-06-10):
[0001571996-24-000143:note_history:6]
The Company has contractual obligations to purchase goods or services, which specify significant terms (including fixed or minimum quantities to be purchased), fixed, minimum, or variable price provisions, and the approximate timing of the transaction. As of November 1, 2024, such purchase obligations were $6.4 billion for the remaining three months of Fiscal 2025; $0.5 billion for Fiscal 2026; and $1.2 billion for Fiscal 2027 and thereafter.

- removed (2025-06-10):
[0001571996-24-000143:note_history:7]
The following is a discussion of the Company’s significant legal matters and other proceedings:

- removed (2025-06-10):
[0001571996-24-000143:note_history:8]
Class Actions Related to the Class V Transaction — On December 28, 2018, the Company completed a transaction (the “Class V transaction”) in which it paid $14.0 billion in cash and issued 149,387,617 shares of its Class C Common Stock to holders of its Class V Common Stock in exchange for all outstanding shares of Class V Common Stock. As a result of the Class V transaction, the tracking stock feature of the Company’s capital structure associated with the Class V Common Stock was terminated. Certain stockholders of the Company subsequently brought class action complaints arising out of the Class V transaction in which they named as defendants (collectively, the “defendants”) Michael S. Dell and certain other directors serving on the Company’s board of directors at the time of the Class V transaction (collectively, the “director defendants”), certain stockholders of the Company, consisting of Mr. Dell and Silver Lake Group, L.L.C. and certain of its affiliated funds (collectively, the “stockholder defendants”), and Goldman Sachs & Co. LLC, which served as financial advisor to the Company in connection with the transaction. The plaintiffs generally alleged that the director defendants and the stockholder defendants breached their fiduciary duties under Delaware law to the former holders of the Class V Common Stock in connection with the Class V transaction by offering a transaction value that was allegedly billions of dollars below fair value.

- removed (2025-06-10):
[0001571996-24-000143:note_history:9]
As previously reported, during the fourth quarter of the fiscal year ended February 3, 2023, the plaintiffs and the defendants entered into an agreement to settle the lawsuit. Under the terms of the settlement, the plaintiffs agreed to the dismissal of all claims upon payment of a total of $1.0 billion (the “settlement amount”), which includes all costs, expenses and fees of the plaintiff class relating to the action and its resolution. On May 16, 2023, during the fiscal year ended February 2, 2024, the Company paid the settlement amount following approval of the settlement by the Delaware Court of Chancery. This matter is no longer material to the Company.

- removed (2025-06-10):
[0001571996-24-000143:note_history:10]
R2 Semiconductor Patent Litigation — In November 2022, R2 Semiconductor, Inc. (“R2”) filed a lawsuit in the Dusseldorf Regional Court in Germany against Intel Deutschland GmbH, Dell GmbH, and certain other customers of Intel Corporation. R2 asserted that one European patent is infringed by certain Intel processors and those of the Company’s products that incorporate those processors. R2 sought an injunction prohibiting the sale of the allegedly infringing products and damages for the alleged infringement. The court conducted a trial on December 7, 2023 and, on February 7, 2024, issued a decision in favor of R2 and imposed an injunction prohibiting the sale and use of such products in Germany by Dell GmbH, and requiring Dell GmbH to issue a communication to certain customers recalling the covered products sold since March 5, 2020. On February 8, 2024, the Company filed an appeal. In April and May 2024, R2 filed lawsuits in Paris, France and Milan, Italy, against affiliates of Intel Corporation (“Intel”) and of the Company, raising similar allegations. Intel agreed to defend the foregoing actions and indemnify the Company and its affiliates against certain losses incurred by the Company in connection with R2’s claims. On August 30, 2024, Intel and R2 publicly announced an agreement to dismiss all litigation between the two companies that would include dismissal of all litigation against all subsidiaries of Dell Technologies named in the foregoing actions. Pursuant to that agreement, the Italian lawsuit was dismissed on September 2, 2024, the German lawsuit was dismissed on September 4, 2024, and the French lawsuit was dismissed on September 6, 2024.

- removed (2025-06-10):
[0001571996-24-000143:note_history:11]
Other Litigation — Dell does not currently anticipate that any of the other legal proceedings it is involved in will have a material adverse effect on its business, financial condition, results of operations, or cash flows.


## dell:CreditLossFinancialInstrumentLeasesDebtVariableInterestEntitiesAndCustomerReceivablesSalesTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2025-06-10):
[0001571996-25-000063:note_history:12]
FINANCIAL SERVICES 
The Company offers or arranges a portfolio of payment and consumption solutions and services for its customers globally, including utility, subscription, as-a-Service, leases, and loans designed to match customers' consumption and financing preferences, and provide operational and financial flexibility.

- added (2025-06-10):
[0001571996-25-000063:note_history:13]
To support financing solutions and services as part of the portfolio, Dell Financial Services and its affiliates (“DFS”) originates, collects, and services customer financing arrangements primarily related to the purchase and use of Dell Technologies products and services. In some cases, the Company also offers financing for the purchase of third-party technology products that complement the Dell Technologies portfolio of products and services. New financing originations were $1.6 billion and $1.9 billion for the three months ended May 2, 2025 and May 3, 2024, respectively.

- changed (2025-06-10):
[0001571996-25-000063:note_history:14]
The Company’s financing arrangements with customers are aggregated primarily as fixed-term leases and loans as described below.
  (was, 2024-12-10, similarity 0.6444):
[0001571996-24-000143:note_history:14]
The Company’s lease and loan arrangements with customers are aggregated primarily into the following categories:

- added (2025-06-10):
[0001571996-25-000063:note_history:15]
Leases — The Company enters into fixed-term financing arrangements with customers who seek lease financing for equipment. Leases are generally classified as sales-type leases or operating leases. Additionally, utility, subscription, and as-a-Service flexible consumption models may result in identification of embedded lease arrangements that require the recognition of sales-type leases or operating leases. Leases with business customers have fixed terms of generally two to four years.

- changed (2025-06-10):
[0001571996-25-000063:note_history:16]
Loans — The Company also offers fixed-term loans to qualified small businesses, large commercial accounts, governmental organizations, educational entities, and certain individual consumer customers. These loans are repaid in equal payments including interest and have defined terms of generally three to five years. The fair value of the fixed-term loan portfolio is determined using market observable inputs. The carrying value of these loans approximates fair value.
  (was, 2024-12-10, similarity 0.9914):
[0001571996-24-000143:note_history:16]
The Company also offers fixed-term loans to qualified small businesses, large commercial accounts, governmental organizations, educational entities, and certain individual consumer customers. These loans are repaid in equal payments including interest and have defined terms of generally three to five years. The fair value of the fixed-term loan portfolio is determined using market observable inputs. The carrying value of these loans approximates fair value.

- added (2025-06-10):
[0001571996-25-000063:note_history:17]
The Company historically offered revolving loans primarily to small and medium-sized commercial customers. During Fiscal 2025, the Company discontinued remaining offerings under the revolving loan portfolio. The Company continues to support existing customer arrangements as well as to transition these customers to fixed-term offerings. Due to the short-term nature of the revolving loan portfolio, as transactions are typically repaid within twelve months on average, the portfolio has now substantially transitioned to such fixed-term offerings.

- changed (2025-06-10):
[0001571996-25-000063:note_history:18]
The following table presents the components of the Company’s financing receivables as of the dates indicated:
  (was, 2024-12-10, similarity 0.872):
[0001571996-24-000143:note_history:18]
The following table presents the components of the Company’s financing receivables segregated by portfolio segment as of the dates indicated:

- added (2025-06-10):
[0001571996-25-000063:note_history:19]
|  |  |  |  |  | May 2, 2025 |  |  |  |  |  | January 31, 2025 |
|  |  |  |  |  | (in millions) |
| Financing receivables, net: |  |  |  |  |  |  |  |  |  |  |  |
| Customer receivables, gross (a) |  |  |  |  | $ | 11,389 |  |  |  |  |  |  | $ | 11,216 |  |
| Allowance for losses |  |  |  |  | (144) |  |  |  |  |  |  | (153) |  |
| Customer receivables, net |  |  |  |  | 11,245 |  |  |  |  |  |  | 11,063 |  |
| Residual interest |  |  |  |  | 178 |  |  |  |  |  |  | 168 |  |
| Financing receivables, net |  |  |  |  | $ | 11,423 |  |  |  |  |  |  | $ | 11,231 |  |
| Short-term |  |  |  |  | $ | 5,381 |  |  |  |  |  |  | $ | 5,304 |  |
| Long-term |  |  |  |  | $ | 6,042 |  |  |  |  |  |  | $ | 5,927 |  |

- changed (2025-06-10):
[0001571996-25-000063:note_history:20]
(a)Customer receivables, gross include amounts due from customers under fixed-term leases, fixed-term loans, and accrued interest, as well as the immaterial remaining amounts under the revolving loans.
  (was, 2024-12-10, similarity 0.6762):
[0001571996-24-000143:note_history:20]
(a)    Customer receivables, gross include amounts due from customers under revolving loans, fixed-term loans, fixed-term leases, and accrued interest.

- changed (2025-06-10):
[0001571996-25-000063:note_history:21]
The following table presents the changes in allowance for financing receivable losses for the periods indicated:
  (was, 2024-12-10, similarity 0.9911):
[0001571996-24-000143:note_history:21]
The following tables present the changes in allowance for financing receivable losses for the periods indicated:

- added (2025-06-10):
[0001571996-25-000063:note_history:22]
|  |  |  |  |  | Three Months Ended |
|  |  |  |  |  | May 2, 2025 |  |  |  |  |  | May 3, 2024 |  |  |
|  |  |  |  |  | (in millions) |
| Allowance for financing receivable losses: |
| Balances at beginning of period |  |  |  |  | $ | 153 |  |  |  |  |  |  | $ | 170 |  |  |  |  |  |  |  |
| Charge-offs, net of recoveries |  |  |  |  | (10) |  |  |  |  |  |  | (8) |  |  |  |  |  |  |  |
| Provision charged to income statement |  |  |  |  | 1 |  |  |  |  |  |  | 33 |  |  |  |  |  |  |  |
| Balances at end of period |  |  |  |  | $ | 144 |  |  |  |  |  |  | $ | 195 |  |  |  |  |  |  |  |

- added (2025-06-10):
[0001571996-25-000063:note_history:23]
The Company recognizes an allowance for financing receivable losses, including both the lease receivable and unguaranteed residual, in an amount equal to the expected losses, net of recoveries. The allowance for financing receivable losses on the lease receivable is determined based on various factors, including lifetime expected losses determined using macroeconomic forecast assumptions and management judgments applicable to and through the expected life of the portfolios as well as past due receivables, receivable type, and customer risk profile. The Company continues to monitor broader economic indicators and their potential impact on future credit loss performance.

- changed (2025-06-10):
[0001571996-25-000063:note_history:24]
The following table presents the aging of the Company’s customer financing receivables, gross, including accrued interest, as of the dates indicated:
  (was, 2024-12-10, similarity 0.9342):
[0001571996-24-000143:note_history:24]
The following table presents the aging of the Company’s customer financing receivables, gross, including accrued interest, segregated by class, as of the dates indicated:

- changed (2025-06-10):
[0001571996-25-000063:note_history:25]
|  | May 2, 2025 |  | January 31, 2025 |
|  | (in millions) |
| Current 0 — 30 Days | $ | 10,718 |  |  | $ | 10,796 |  |
| Past Due 31 — 90 Days | 536 |  |  | 201 |  |
| Past Due > 90 Days | 135 |  |  | 219 |  |
| Total | $ | 11,389 |  |  | $ | 11,216 |  |
  (was, 2024-12-10, similarity 0.631):
[0001571996-24-000143:note_history:25]
|  | November 1, 2024 |
|  | (in millions) |
| Fiscal 2025 (remaining three months) | $ | 347 |  |
| Fiscal 2026 | 1,079 |  |
| Fiscal 2027 | 665 |  |
| Fiscal 2028 | 316 |  |
| Fiscal 2029 and beyond | 121 |  |
| Total | $ | 2,528 |  |

- changed (2025-06-10):
[0001571996-25-000063:note_history:26]
Customer receivables are placed on non-accrual status if principal or interest is past due and considered delinquent, or if there is concern about the collectibility of a specific customer receivable. The receivables identified as doubtful for collectibility may be classified as current for aging purposes.
  (was, 2024-12-10, similarity 0.8471):
[0001571996-24-000143:note_history:26]
Fixed-term customer receivables are placed on non-accrual status if principal or interest is past due and considered delinquent, or if there is concern about the collectibility of a specific customer receivable. The receivables identified as doubtful for collectibility may be classified as current for aging purposes. Aged revolving portfolio customer receivables identified as delinquent are charged off.

- changed (2025-06-10):
[0001571996-25-000063:note_history:27]
The following tables present customer receivables, gross, including accrued interest, by credit quality indicator, as of the dates indicated:
  (was, 2024-12-10, similarity 0.9307):
[0001571996-24-000143:note_history:27]
The following tables present customer receivables, gross, including accrued interest, by credit quality indicator, segregated by class, as of the dates indicated:

- changed (2025-06-10):
[0001571996-25-000063:note_history:28]
|  | May 2, 2025 |
|  | Fiscal Year of Origination |  |  |  |  |
|  | 2026 |  | 2025 |  | 2024 |  | 2023 |  | 2022 |  | Years Prior |  |  |  | Total |
|  | (in millions) |
| Higher | $ | 839 |  |  | $ | 2,235 |  |  | $ | 1,896 |  |  | $ | 994 |  |  | $ | 237 |  |  | $ | 64 |  |  |  |  | $ | 6,265 |  |
| Mid | 612 |  |  | 2,069 |  |  | 621 |  |  | 385 |  |  | 79 |  |  | 10 |  |  |  |  | 3,776 |  |
| Lower | 261 |  |  | 472 |  |  | 329 |  |  | 216 |  |  | 48 |  |  | 22 |  |  |  |  | 1,348 |  |
| Total | $ | 1,712 |  |  | $ | 4,776 |  |  | $ | 2,846 |  |  | $ | 1,595 |  |  | $ | 364 |  |  | $ | 96 |  |  |  |  | $ | 11,389 |  |
  (was, 2024-12-10, similarity 0.8957):
[0001571996-24-000143:note_history:28]
|  | November 1, 2024 |
|  | Fixed-term — Fiscal Year of Origination |  |  |  |  |
|  | 2025 |  | 2024 |  | 2023 |  | 2022 |  | 2021 |  | Years Prior |  | Revolving |  | Total |
|  | (in millions) |
| Higher | $ | 1,555 |  |  | $ | 2,440 |  |  | $ | 1,560 |  |  | $ | 515 |  |  | $ | 158 |  |  | $ | 14 |  |  | $ | 25 |  |  | $ | 6,267 |  |
| Mid | 733 |  |  | 710 |  |  | 432 |  |  | 122 |  |  | 22 |  |  | 5 |  |  | 37 |  |  | 2,061 |  |
| Lower | 1,505 |  |  | 465 |  |  | 314 |  |  | 88 |  |  | 58 |  |  | 3 |  |  | 64 |  |  | 2,497 |  |
| Total | $ | 3,793 |  |  | $ | 3,615 |  |  | $ | 2,306 |  |  | $ | 725 |  |  | $ | 238 |  |  | $ | 22 |  |  | $ | 126 |  |  | $ | 10,825 |  |

- changed (2025-06-10):
[0001571996-25-000063:note_history:29]
|  | January 31, 2025 |
|  | Fiscal Year of Origination |  |  |  |  |  |  |
|  | 2025 |  | 2024 |  | 2023 |  | 2022 |  | 2021 |  | Years Prior |  |  |  |  |  | Total |
|  | (in millions) |
| Higher | $ | 2,295 |  |  | $ | 2,160 |  |  | $ | 1,217 |  |  | $ | 357 |  |  | $ | 102 |  |  | $ | 4 |  |  |  |  |  |  | $ | 6,135 |  |
| Mid | 2,455 |  |  | 695 |  |  | 464 |  |  | 107 |  |  | 17 |  |  | 4 |  |  |  |  |  |  | 3,742 |  |
| Lower | 552 |  |  | 407 |  |  | 283 |  |  | 68 |  |  | 28 |  |  | 1 |  |  |  |  |  |  | 1,339 |  |
| Total | $ | 5,302 |  |  | $ | 3,262 |  |  | $ | 1,964 |  |  | $ | 532 |  |  | $ | 147 |  |  | $ | 9 |  |  |  |  |  |  | $ | 11,216 |  |
  (was, 2024-12-10, similarity 0.8874):
[0001571996-24-000143:note_history:29]
|  | February 2, 2024 |
|  | Fixed-term — Fiscal Year of Origination |  |  |  |  |  |  |
|  | 2024 |  | 2023 |  | 2022 |  | 2021 |  | 2020 |  | Years Prior |  |  |  | Revolving |  | Total |
|  | (in millions) |
| Higher | $ | 3,261 |  |  | $ | 1,979 |  |  | $ | 833 |  |  | $ | 345 |  |  | $ | 64 |  |  | $ | — |  |  |  |  | $ | 47 |  |  | $ | 6,529 |  |
| Mid | 1,111 |  |  | 911 |  |  | 290 |  |  | 86 |  |  | 19 |  |  | — |  |  |  |  | 50 |  |  | 2,467 |  |
| Lower | 703 |  |  | 469 |  |  | 187 |  |  | 80 |  |  | 21 |  |  | 1 |  |  |  |  | 76 |  |  | 1,537 |  |
| Total | $ | 5,075 |  |  | $ | 3,359 |  |  | $ | 1,310 |  |  | $ | 511 |  |  | $ | 104 |  |  | $ | 1 |  |  |  |  | $ | 173 |  |  | $ | 10,533 |  |

- changed (2025-06-10):
[0001571996-25-000063:note_history:30]
The categories shown in the tables above segregate customer receivables based on the relative degrees of credit risk. Credit quality indicators are generally updated on a periodic basis. An internal grading system is utilized that assigns a credit level score based on a number of considerations, including liquidity, operating performance, and industry outlook.
  (was, 2024-12-10, similarity 0.6348):
[0001571996-24-000143:note_history:30]
The categories shown in the tables above segregate customer receivables based on the relative degrees of credit risk. Credit quality indicators for revolving and fixed-term accounts are generally updated on a periodic basis.

- added (2025-06-10):
[0001571996-25-000063:note_history:31]
|  |  |  | Three Months Ended |
|  |  |  |  |  | May 2, 2025 |  | May 3, 2024 |  |  |
|  |  |  |  |  | (in millions) |
| Interest income — products |  |  |  |  | $ | 93 |  |  | $ | 66 |  |  |  |
| Net revenue — products |  |  |  |  | $ | 119 |  |  | $ | 728 |  |  |  |
| Cost of net revenue — products |  |  |  |  | 131 |  |  | 618 |  |  |  |
| Gross margin — products |  |  |  |  | $ | (12) |  |  | $ | 110 |  |  |  |

- changed (2025-06-10):
[0001571996-25-000063:note_history:32]
The following table presents the future maturity of the Company’s customer leases and associated financing payments, and reconciles the undiscounted cash flows to the customer receivables, gross recognized on the Condensed Consolidated Statements of Financial Position as of the date indicated:
  (was, 2024-12-10, similarity 0.9816):
[0001571996-24-000143:note_history:32]
The following table presents the future maturity of the Company’s fixed-term customer leases and associated financing payments, and reconciles the undiscounted cash flows to the customer receivables, gross recognized on the Condensed Consolidated Statements of Financial Position as of the date indicated:

- added (2025-06-10):
[0001571996-25-000063:note_history:33]
|  | May 2, 2025 |
|  | (in millions) |
| Fiscal 2026 (remaining nine months) | $ | 2,655 |  |
| Fiscal 2027 | 2,631 |  |
| Fiscal 2028 | 1,307 |  |
| Fiscal 2029 | 628 |  |
| Fiscal 2030 and thereafter | 279 |  |
| Total undiscounted cash flows | 7,500 |  |
| Loans | 4,951 |  |
| Less: Unearned income | (1,062) |  |
| Total customer receivables, gross | $ | 11,389 |  |

- changed (2025-06-10):
[0001571996-25-000063:note_history:34]
The Company’s operating leases primarily consist of fixed-term leases and contractually committed embedded leases identified within flexible consumption arrangements.
  (was, 2024-12-10, similarity 0.9651):
[0001571996-24-000143:note_history:34]
The Company’s operating leases primarily consist of DFS captive fixed-term leases and contractually committed embedded leases identified within flexible consumption arrangements.

- changed (2025-06-10):
[0001571996-25-000063:note_history:35]
|  | May 2, 2025 |  | January 31, 2025 |
|  | (in millions) |
| Equipment under operating lease, gross | $ | 4,420 |  |  | $ | 4,180 |  |
| Less: Accumulated depreciation | (2,148) |  |  | (1,995) |  |
| Equipment under operating lease, net | $ | 2,272 |  |  | $ | 2,185 |  |
  (was, 2024-12-10, similarity 0.9227):
[0001571996-24-000143:note_history:35]
|  | November 1, 2024 |  | February 2, 2024 |
|  | (in millions) |
| Equipment under operating lease, gross | $ | 4,188 |  |  | $ | 4,002 |  |
| Less: Accumulated depreciation | (1,971) |  |  | (1,800) |  |
| Equipment under operating lease, net | $ | 2,217 |  |  | $ | 2,202 |  |

- added (2025-06-10):
[0001571996-25-000063:note_history:36]
|  |  |  | Three Months Ended |
|  |  |  |  |  | May 2, 2025 |  | May 3, 2024 |  |  |
|  |  |  |  |  | (in millions) |
| Income related to lease payments |  |  |  |  | $ | 358 |  |  | $ | 356 |  |  |  |
| Depreciation expense |  |  |  |  | $ | 244 |  |  | $ | 240 |  |  |  |

- added (2025-06-10):
[0001571996-25-000063:note_history:37]
|  | May 2, 2025 |
|  | (in millions) |
| Fiscal 2026 (remaining nine months) | $ | 967 |  |
| Fiscal 2027 | 908 |  |
| Fiscal 2028 | 515 |  |
| Fiscal 2029 | 204 |  |
| Fiscal 2030 and thereafter | 67 |  |
| Total | $ | 2,661 |  |

- added (2025-06-10):
[0001571996-25-000063:note_history:38]
|  | May 2, 2025 |  | January 31, 2025 |
| DFS debt | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing facility | $ | 2,606 |  |  | $ | 3,018 |  |
| Fixed-term securitization offerings | 3,154 |  |  | 2,756 |  |
| Total DFS U.S. debt, principal amount | 5,760 |  |  | 5,774 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 702 |  |  | 624 |  |
| Other borrowings | 772 |  |  | 754 |  |
| Dell Bank senior unsecured eurobonds | 1,693 |  |  | 1,559 |  |
| Total DFS international debt, principal amount | 3,167 |  |  | 2,937 |  |
| Total DFS debt, principal amount | $ | 8,927 |  |  | $ | 8,711 |  |
| Total short-term DFS debt | $ | 4,809 |  |  | $ | 5,175 |  |
| Total long-term DFS debt | $ | 4,118 |  |  | $ | 3,536 |  |

- changed (2025-06-10):
[0001571996-25-000063:note_history:39]
Asset-Based Financing Facility — The Company maintains an asset-based financing facility in the United States, which is a revolving facility for fixed-term leases and loans. This debt is collateralized solely by the U.S. lease and loan payments and associated equipment in the facility. The asset-based financing facility consists of two tranches, with effective dates through July 7, 2025 and July 7, 2026, respectively. As of May 2, 2025, the total debt capacity related to the asset-based financing facility was $5.0 billion. The debt has a variable interest rate, and the duration of the debt is based on the terms of the underlying lease and loan payment streams. The Company enters into interest rate swap agreements to economically convert a portion of this debt from a floating rate to a fixed rate. See Note 7 of the Notes to the Condensed Consolidated Financial Statements for additional information about the Company’s interest rate swaps.
  (was, 2024-12-10, similarity 0.9941):
[0001571996-24-000143:note_history:39]
Asset-Based Financing Facility — The Company maintains an asset-based financing facility in the United States, which is a revolving facility for fixed-term leases and loans. This debt is collateralized solely by the U.S. lease and loan payments and associated equipment in the facility. The asset-based financing facility consists of two tranches, with effective dates through July 7, 2025 and July 7, 2026, respectively. As of November 1, 2024, the total debt capacity related to the asset-based financing facility was $5.0 billion. The debt has a variable interest rate, and the duration of the debt is based on the terms of the underlying lease and loan payment streams. The Company enters into interest rate swap agreements to economically convert a portion of this debt from a floating rate to a fixed rate. See Note 7 of the Notes to the Condensed Consolidated Financial Statements for additional information about the Company’s interest rate swaps.

- changed (2025-06-10):
[0001571996-25-000063:note_history:40]
The asset-based financing facility contains standard structural features related to the performance of the funded receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements. In the event one or more of these criteria are not met and the Company is unable to restructure the facility, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed. As of May 2, 2025, these criteria were met.
  (was, 2024-12-10, similarity 0.9898):
[0001571996-24-000143:note_history:40]
The asset-based financing facility contains standard structural features related to the performance of the funded receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements. In the event one or more of these criteria are not met and the Company is unable to restructure the facility, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed. As of November 1, 2024, these criteria were met.

- changed (2025-06-10):
[0001571996-25-000063:note_history:41]
Fixed-Term Securitization Offerings — The Company periodically issues asset-backed debt securities under fixed-term securitization programs to private investors. The asset-backed debt securities are collateralized solely by the U.S. fixed-term lease and loan payments and associated equipment, which are held by Special Purpose Entities (“SPEs”), as discussed below. The interest rate on these securities is fixed and ranges from 4.59% to 6.80% per annum as of May 2, 2025, and the duration of these securities is based on the terms of the underlying lease and loan payment streams.
  (was, 2024-12-10, similarity 0.9904):
[0001571996-24-000143:note_history:41]
Fixed-Term Securitization Offerings — The Company periodically issues asset-backed debt securities under fixed-term securitization programs to private investors. The asset-backed debt securities are collateralized solely by the U.S. fixed-term lease and loan payments and associated equipment, which are held by Special Purpose Entities (“SPEs”), as discussed below. The interest rate on these securities is fixed and ranges from 4.14% to 6.80% per annum as of November 1, 2024, and the duration of these securities is based on the terms of the underlying lease and loan payment streams.

- changed (2025-06-10):
[0001571996-25-000063:note_history:42]
Securitization Facility — The Company maintains a securitization facility in Europe for fixed-term leases and loans. The debt under this facility has a variable interest rate, and the duration of the debt is based on the terms of the underlying lease and loan payment streams. This facility is effective through December 22, 2026 and had a total debt capacity of $903 million as of May 2, 2025.
  (was, 2024-12-10, similarity 0.9753):
[0001571996-24-000143:note_history:42]
Securitization Facility — The Company maintains a securitization facility in Europe for fixed-term leases and loans. The debt under this facility has a variable interest rate, and the duration of the debt is based on the terms of the underlying lease and loan payment streams. This facility is effective through December 23, 2024 and had a total debt capacity of $871 million as of November 1, 2024.

- changed (2025-06-10):
[0001571996-25-000063:note_history:43]
The securitization facility contains standard structural features related to the performance of the securitized receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements. In the event one or more of these criteria are not met and the Company is unable to restructure the program, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed. As of May 2, 2025, these criteria were met.
  (was, 2024-12-10, similarity 0.9897):
[0001571996-24-000143:note_history:43]
The securitization facility contains standard structural features related to the performance of the securitized receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements. In the event one or more of these criteria are not met and the Company is unable to restructure the program, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed. As of November 1, 2024, these criteria were met.

- changed (2025-06-10):
[0001571996-25-000063:note_history:44]
Other Borrowings — In connection with the Company’s international financing operations, the Company has entered into revolving structured financing debt programs related to its fixed-term lease and loan products sold in Canada, Europe, Australia and New Zealand, the Middle East, and Singapore. The debt under these programs has a variable interest rate.
  (was, 2024-12-10, similarity 0.9929):
[0001571996-24-000143:note_history:44]
Other Borrowings — In connection with the Company’s international financing operations, the Company has entered into revolving structured financing debt programs related to its fixed-term lease and loan products sold in Canada, Europe, Australia, New Zealand, the Middle East, and Singapore. The debt under these programs has a variable interest rate.

- changed (2025-06-10):
[0001571996-25-000063:note_history:45]
The duration of the debt in Canada, Europe, Australia and New Zealand, and the Middle East is based on the terms of the underlying lease and loan payment streams. These facilities are collateralized solely by the lease and loan payments and associated equipment in their respective region or country. The Canadian facility had a total debt capacity of $253 million as of May 2, 2025 and is effective through January 15, 2028. The European facility had a total debt capacity of $565 million as of May 2, 2025 and is effective through December 14, 2026. The Australia and New Zealand facility had a total debt capacity of $271 million as of May 2, 2025 and is effective through April 17, 2027. The Middle East facility had a total debt capacity of $150 million as of May 2, 2025 and is effective through March 14, 2027.
  (was, 2024-12-10, similarity 0.9685):
[0001571996-24-000143:note_history:45]
The duration of the debt in Canada, Europe, Australia, New Zealand, and the Middle East is based on the terms of the underlying lease and loan payment streams. These facilities are collateralized solely by the lease and loan payments and associated equipment in their respective region or country. The Canadian facility had a total debt capacity of $323 million as of November 1, 2024 and is effective through January 16, 2025. The European facility had a total debt capacity of $544 million as of November 1, 2024 and is effective through December 14, 2026. The Australia and New Zealand facility had a total debt capacity of $296 million as of November 1, 2024 and is effective through April 20, 2025. The Middle East facility had a total debt capacity of $150 million as of November 1, 2024 and is effective through March 24, 2025.

- changed (2025-06-10):
[0001571996-25-000063:note_history:46]
The Company also has two unsecured Singapore facilities, which have a total debt capacity of $251 million as of May 2, 2025 and are effective through July 3, 2026 and July 3, 2027, respectively.
  (was, 2024-12-10, similarity 0.93):
[0001571996-24-000143:note_history:46]
The Company also has two unsecured Singapore facilities with a total debt capacity of $250 million as of November 1, 2024 that are effective through July 3, 2026 and July 3, 2027, respectively.

- changed (2025-06-10):
[0001571996-25-000063:note_history:47]
Some of the SPEs have entered into financing arrangements with multi-seller conduits that, in turn, issue asset-backed debt securities in the capital markets. DFS debt outstanding held by the consolidated VIEs is collateralized by the lease and loan payments and associated equipment. The Company’s risk of loss related to securitized receivables is limited to the amount by which the Company’s right to receive collections for assets securitized exceeds the amount required to pay interest, principal, and fees and expenses related to the asset-backed securities. The Company provides credit enhancement to the securitization offerings in the form of over-collateralization.
  (was, 2024-12-10, similarity 0.9925):
[0001571996-24-000143:note_history:47]
Some of the SPEs have entered into financing arrangements with multi-seller conduits that, in turn, issue asset-backed debt securities in the capital markets. DFS debt outstanding held by the consolidated VIEs is collateralized by the lease and loan payments and associated equipment. The Company’s risk of loss related to securitized receivables is limited to the amount by which the Company’s right to receive collections for assets securitized exceeds the amount required to pay interest, principal, and fees and expenses related to the asset-backed securities. The Company provides credit enhancement to the securitization in the form of over-collateralization.

- changed (2025-06-10):
[0001571996-25-000063:note_history:48]
|  | May 2, 2025 |  | January 31, 2025 |
|  | (in millions) |
| Assets held by consolidated VIEs |  |  |  |
| Other current assets | $ | 151 |  |  | $ | 123 |  |
| Financing receivables, net of allowance |  |  |  |
| Short-term | $ | 3,181 |  |  | $ | 3,262 |  |
| Long-term | $ | 2,834 |  |  | $ | 2,725 |  |
| Property, plant, and equipment, net | $ | 984 |  |  | $ | 984 |  |
| Liabilities held by consolidated VIEs |  |  |  |
| Debt, net of unamortized debt issuance costs |  |  |  |
| Short-term | $ | 4,387 |  |  | $ | 4,598 |  |
| Long-term | $ | 2,061 |  |  | $ | 1,788 |  |
  (was, 2024-12-10, similarity 0.9642):
[0001571996-24-000143:note_history:48]
|  | November 1, 2024 |  | February 2, 2024 |
|  | (in millions) |
| Assets held by consolidated VIEs |  |  |  |
| Other current assets | $ | 123 |  |  | $ | 136 |  |
| Financing receivables, net of allowance |  |  |  |
| Short-term | $ | 3,354 |  |  | $ | 3,314 |  |
| Long-term | $ | 2,989 |  |  | $ | 2,747 |  |
| Property, plant, and equipment, net | $ | 1,022 |  |  | $ | 1,081 |  |
| Liabilities held by consolidated VIEs |  |  |  |
| Debt, net of unamortized debt issuance costs |  |  |  |
| Short-term | $ | 4,888 |  |  | $ | 4,450 |  |
| Long-term | $ | 1,838 |  |  | $ | 2,184 |  |

- changed (2025-06-10):
[0001571996-25-000063:note_history:49]
Lease and loan payments and associated equipment transferred via securitization through SPEs were $1.2 billion and $0.8 billion for the three months ended May 2, 2025 and May 3, 2024, respectively.
  (was, 2024-12-10, similarity 0.7113):
[0001571996-24-000143:note_history:49]
Lease and loan payments and associated equipment transferred via securitization through SPEs were $1.0 billion and $1.1 billion for the three months ended November 1, 2024 and November 3, 2023, respectively, and $3.0 billion and $3.7 billion for the nine months ended November 1, 2024 and November 3, 2023, respectively.

- changed (2025-06-10):
[0001571996-25-000063:note_history:50]
To manage certain concentrations of customer credit exposure, the Company may sell selected fixed-term customer receivables to unrelated third parties on a periodic basis, without recourse. The amounts of customer receivables sold for this purpose were immaterial for both the three months ended May 2, 2025 and May 3, 2024. The Company’s continuing involvement in these customer receivables is primarily limited to servicing arrangements.
  (was, 2024-12-10, similarity 0.8283):
[0001571996-24-000143:note_history:50]
To manage certain concentrations of customer credit exposure, the Company may sell selected fixed-term customer receivables to unrelated third parties on a periodic basis, without recourse. The amount of customer receivables sold for this purpose was $75 million and $205 million for the nine months ended November 1, 2024 and November 3, 2023, respectively. The Company’s continuing involvement in these customer receivables is primarily limited to servicing arrangements.

- removed (2025-06-10):
[0001571996-24-000143:note_history:51]
FINANCIAL SERVICES
The Company offers or arranges various financing options and alternative payment structures for its customers globally. Alternative payment structures consist of various flexible consumption models, including utility, subscription, and as-a-Service models.

- removed (2025-06-10):
[0001571996-24-000143:note_history:52]
Financing options are offered to the Company’s customers primarily through Dell Financial Services and its affiliates (“DFS”). The Company also arranges financing for some of its customers in various countries where DFS does not currently operate as a captive enterprise. The key activities of DFS include originating, collecting, and servicing customer financing arrangements primarily related to the purchase or use of Dell Technologies products and services. In some cases, DFS also offers financing for the purchase of third-party technology products that complement the Dell Technologies portfolio of products and services. New financing originations were $1.6 billion and $1.8 billion for the three months ended November 1, 2024 and November 3, 2023, respectively, and $5.9 billion and $6.0 billion for the nine months ended November 1, 2024 and November 3, 2023, respectively.

- removed (2025-06-10):
[0001571996-24-000143:note_history:53]
Fixed-term leases and loans — The Company enters into financing arrangements with customers who seek lease financing for equipment. DFS leases are generally classified as sales-type leases or operating leases. Leases with business customers have fixed terms of generally two to four years.

- removed (2025-06-10):
[0001571996-24-000143:note_history:54]
Revolving loans — The Company primarily offers revolving loans to small and medium-sized commercial customers. Revolving loans provide qualified customers with a revolving credit line for the purchase of products and services offered by Dell Technologies. Revolving loans in the United States bear interest at a variable annual percentage rate that is tied to the prime rate. Based on historical payment patterns, revolving loan transactions are typically repaid within twelve months on average. Due to the short-term nature of the revolving loan portfolio, the carrying value of the portfolio approximates fair value.

- removed (2025-06-10):
[0001571996-24-000143:note_history:55]
Prior to the sale of the U.S. consumer revolving customer receivables portfolio on October 4, 2023, described in Note 1 of the Notes to the Condensed Consolidated Financial Statements, the Company offered private label credit financing under the Dell Preferred Account (“DPA”) program. The DPA product was primarily offered to individual consumer customers. During the three months ended November 1, 2024, the Company discontinued remaining offerings under the revolving loan portfolio. The Company will support existing customer arrangements as well as transition these customers to fixed-term offerings.

- removed (2025-06-10):
[0001571996-24-000143:note_history:56]
Flexible consumption models, as defined above, further enable the Company to offer its customers the option to pay over time to provide them with financial and operational flexibility. Such models may result in identification of embedded lease arrangements that lead to the recognition of operating or sales-type leases.

- removed (2025-06-10):
[0001571996-24-000143:note_history:57]
|  | November 1, 2024 |  | February 2, 2024 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Financing receivables, net: |  |  |  |  |  |  |  |  |  |  |  |
| Customer receivables, gross (a) | $ | 126 |  |  | $ | 10,699 |  |  | $ | 10,825 |  |  | $ | 173 |  |  | $ | 10,360 |  |  | $ | 10,533 |  |
| Allowances for losses | (7) |  |  | (137) |  |  | (144) |  |  | (9) |  |  | (161) |  |  | (170) |  |
| Customer receivables, net | 119 |  |  | 10,562 |  |  | 10,681 |  |  | 164 |  |  | 10,199 |  |  | 10,363 |  |
| Residual interest | — |  |  | 169 |  |  | 169 |  |  | — |  |  | 157 |  |  | 157 |  |
| Financing receivables, net | $ | 119 |  |  | $ | 10,731 |  |  | $ | 10,850 |  |  | $ | 164 |  |  | $ | 10,356 |  |  | $ | 10,520 |  |
| Short-term | $ | 119 |  |  | $ | 4,882 |  |  | $ | 5,001 |  |  | $ | 164 |  |  | $ | 4,479 |  |  | $ | 4,643 |  |
| Long-term | $ | — |  |  | $ | 5,849 |  |  | $ | 5,849 |  |  | $ | — |  |  | $ | 5,877 |  |  | $ | 5,877 |  |

- removed (2025-06-10):
[0001571996-24-000143:note_history:58]
|  | Three Months Ended |
|  | November 1, 2024 |  | November 3, 2023 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |  |  |  |  |  |  |  |
| Balances at beginning of period | $ | 8 |  |  | $ | 158 |  |  | $ | 166 |  |  | $ | 9 |  |  | $ | 140 |  |  | $ | 149 |  |
| Charge-offs, net of recoveries | (3) |  |  | (35) |  |  | (38) |  |  | (4) |  |  | (3) |  |  | (7) |  |
| Provision charged to income statement | 2 |  |  | 14 |  |  | 16 |  |  | 4 |  |  | 7 |  |  | 11 |  |
| Balances at end of period | $ | 7 |  |  | $ | 137 |  |  | $ | 144 |  |  | $ | 9 |  |  | $ | 144 |  |  | $ | 153 |  |

- removed (2025-06-10):
[0001571996-24-000143:note_history:59]
|  | Nine Months Ended |
|  | November 1, 2024 |  | November 3, 2023 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |  |  |  |  |  |  |  |
| Balances at beginning of period | $ | 9 |  |  | $ | 161 |  |  | $ | 170 |  |  | $ | 88 |  |  | $ | 113 |  |  | $ | 201 |  |
| Charge-offs, net of recoveries | (9) |  |  | (56) |  |  | (65) |  |  | (37) |  |  | (5) |  |  | (42) |  |
| Provision charged to income statement | 7 |  |  | 32 |  |  | 39 |  |  | 32 |  |  | 36 |  |  | 68 |  |
| Other (a) | — |  |  | — |  |  | — |  |  | (74) |  |  | — |  |  | (74) |  |
| Balances at end of period | $ | 7 |  |  | $ | 137 |  |  | $ | 144 |  |  | $ | 9 |  |  | $ | 144 |  |  | $ | 153 |  |

- removed (2025-06-10):
[0001571996-24-000143:note_history:60]
____________________

- removed (2025-06-10):
[0001571996-24-000143:note_history:61]
(a)    Other represents the derecognition of the allowance for financing receivable losses related to the sale of the U.S. consumer revolving customer receivables portfolio described in Note 1 of the Notes to the Condensed Consolidated Financial Statements.

- removed (2025-06-10):
[0001571996-24-000143:note_history:62]
The Company recognizes an allowance for financing receivable losses, including both the lease receivable and unguaranteed residual, in an amount equal to the expected losses net of recoveries. The allowance for financing receivable losses on the lease receivable is determined based on various factors, including lifetime expected losses determined using macroeconomic forecast assumptions and management judgments applicable to and through the expected life of the portfolios as well as past due receivables, receivable type, and customer risk profile. The Company continues to monitor broader economic indicators and their potential impact on future credit loss performance.

- removed (2025-06-10):
[0001571996-24-000143:note_history:63]
|  | November 1, 2024 |  | February 2, 2024 |
|  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |
|  | (in millions) |
| Revolving | $ | 107 |  |  | $ | 15 |  |  | $ | 4 |  |  | $ | 126 |  |  | $ | 151 |  |  | $ | 17 |  |  | $ | 5 |  |  | $ | 173 |  |
| Fixed-term | 10,053 |  |  | 488 |  |  | 158 |  |  | 10,699 |  |  | 9,345 |  |  | 889 |  |  | 126 |  |  | 10,360 |  |
| Total customer receivables, gross | $ | 10,160 |  |  | $ | 503 |  |  | $ | 162 |  |  | $ | 10,825 |  |  | $ | 9,496 |  |  | $ | 906 |  |  | $ | 131 |  |  | $ | 10,533 |  |

- removed (2025-06-10):
[0001571996-24-000143:note_history:64]
An internal grading system is utilized that assigns a credit level score based on a number of considerations, including liquidity, operating performance, and industry outlook. The grading criteria and classifications for the fixed-term products differ from those for the revolving products as loss experience varies between these product and customer groups. The credit quality categories cannot be compared between the different classes as loss experience varies substantially between the classes.

- removed (2025-06-10):
[0001571996-24-000143:note_history:65]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 1, 2024 |  | November 3, 2023 |  | November 1, 2024 |  | November 3, 2023 |  |  |
|  | (in millions) |
| Net revenue — products | $ | 401 |  |  | $ | 227 |  |  | $ | 1,751 |  |  | $ | 766 |  |  |  |
| Cost of net revenue — products | 333 |  |  | 176 |  |  | 1,488 |  |  | 564 |  |  |  |
| Gross margin — products | $ | 68 |  |  | $ | 51 |  |  | $ | 263 |  |  | $ | 202 |  |  |  |

- removed (2025-06-10):
[0001571996-24-000143:note_history:66]
|  | November 1, 2024 |
|  | (in millions) |
| Fiscal 2025 (remaining three months) | $ | 871 |  |
| Fiscal 2026 | 3,114 |  |
| Fiscal 2027 | 2,085 |  |
| Fiscal 2028 | 793 |  |
| Fiscal 2029 and beyond | 454 |  |
| Total undiscounted cash flows | 7,317 |  |
| Fixed-term loans | 4,466 |  |
| Revolving loans | 126 |  |
| Less: Unearned income | (1,084) |  |
| Total customer receivables, gross | $ | 10,825 |  |

- removed (2025-06-10):
[0001571996-24-000143:note_history:67]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 1, 2024 |  | November 3, 2023 |  | November 1, 2024 |  | November 3, 2023 |  |  |
|  | (in millions) |
| Income related to lease payments | $ | 372 |  |  | $ | 341 |  |  | $ | 1,090 |  |  | $ | 992 |  |  |  |
| Depreciation expense | $ | 247 |  |  | $ | 234 |  |  | $ | 732 |  |  | $ | 703 |  |  |  |

- removed (2025-06-10):
[0001571996-24-000143:note_history:68]
|  | November 1, 2024 |  | February 2, 2024 |
| DFS debt | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing facility | $ | 2,753 |  |  | $ | 2,730 |  |
| Fixed-term securitization offerings | 3,264 |  |  | 3,157 |  |
| Other | — |  |  | 28 |  |
| Total DFS U.S. debt, principal amount | 6,017 |  |  | 5,915 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 723 |  |  | 761 |  |
| Other borrowings | 798 |  |  | 935 |  |
| Note payable | — |  |  | 250 |  |
| Dell Bank senior unsecured eurobonds | 1,633 |  |  | 1,631 |  |
| Total DFS international debt, principal amount | 3,154 |  |  | 3,577 |  |
| Total DFS debt, principal amount | $ | 9,171 |  |  | $ | 9,492 |  |
| Total short-term DFS debt | $ | 5,582 |  |  | $ | 5,863 |  |
| Total long-term DFS debt | $ | 3,589 |  |  | $ | 3,629 |  |

- removed (2025-06-10):
[0001571996-24-000143:note_history:69]
Note Payable — On May 25, 2022, the Company entered into an unsecured credit agreement which had an aggregate principal amount of $250 million to fund receivables in Mexico. The note bore interest at an annual rate of 4.24% and was paid in full on May 31, 2024.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-06-10):
[0001571996-25-000063:note_history:70]
|  | May 2, 2025 |  | January 31, 2025 |
|  | (in millions) |
| Senior Notes | $ | 19,073 |  |  | $ | 15,073 |  |
| Legacy Notes | 952 |  |  | 952 |  |
| DFS Debt (Note 4) | 8,927 |  |  | 8,711 |  |
| Other | 79 |  |  | 52 |  |
| Total debt, principal amount | 29,031 |  |  | 24,788 |  |
| Unamortized discount, net of unamortized premium | (113) |  |  | (110) |  |
| Debt issuance costs | (137) |  |  | (111) |  |
| Total debt, carrying value | $ | 28,781 |  |  | $ | 24,567 |  |
| Total short-term debt, carrying value | $ | 4,845 |  |  | $ | 5,204 |  |
| Total long-term debt, carrying value | $ | 23,936 |  |  | $ | 19,363 |  |
  (was, 2024-12-10, similarity 0.9655):
[0001571996-24-000143:note_history:70]
|  | November 1, 2024 |  | February 2, 2024 |
|  | (in millions) |
| Senior Notes | $ | 15,073 |  |  | $ | 15,607 |  |
| Legacy Notes | 952 |  |  | 952 |  |
| DFS Debt (Note 4) | 9,171 |  |  | 9,492 |  |
| Other | 56 |  |  | 171 |  |
| Total debt, principal amount | 25,252 |  |  | 26,222 |  |
| Unamortized discount, net of unamortized premium | (113) |  |  | (114) |  |
| Debt issuance costs | (117) |  |  | (114) |  |
| Total debt, carrying value | $ | 25,022 |  |  | $ | 25,994 |  |
| Total short-term debt, carrying value | $ | 5,612 |  |  | $ | 6,982 |  |
| Total long-term debt, carrying value | $ | 19,410 |  |  | $ | 19,012 |  |

- added (2025-06-10):
[0001571996-25-000063:note_history:71]
During the three months ended May 2, 2025, the Company issued $1.0 billion principal amount of 4.75% Senior Notes due April 2028, $1.0 billion principal amount of 5.00% Senior Notes due April 2030, $1.0 billion principal amount of 5.30% Senior Notes due April 2032, and $1.0 billion principal amount of 5.50% Senior Notes due April 2035. The Company utilized the net proceeds of the issuance for general corporate purposes.

- changed (2025-06-10):
[0001571996-25-000063:note_history:72]
Senior Notes — The Company completed offerings of multiple series of senior notes which were issued on June 1, 2016, June 22, 2016, March 20, 2019, April 9, 2020, December 13, 2021, January 24, 2023, March 18, 2024, October 8, 2024, and April 1, 2025 in aggregate principal amounts of $20.0 billion, $3.3 billion, $4.5 billion, $2.3 billion, $2.3 billion, $2.0 billion, $1.0 billion, $1.5 billion, and $4.0 billion respectively (collectively, the “Senior Notes”). The Senior Notes currently outstanding have maturity dates ranging from 2026 through 2051. Interest rates on these borrowings are fixed, ranging from 3.38% to 8.35% per annum, and interest is payable semiannually.
  (was, 2024-12-10, similarity 0.6507):
[0001571996-24-000143:note_history:72]
Senior Notes — The Company completed offerings of multiple series of senior notes which were issued on June 1, 2016, June 22, 2016, March 20, 2019, April 9, 2020, December 13, 2021, January 24, 2023, March 18, 2024, and October 8, 2024 in aggregate principal amounts of $20.0 billion, $3.3 billion, $4.5 billion, $2.3 billion, $2.3 billion, $2.0 billion, $1.0 billion, and $1.5 billion, respectively (collectively, the “Senior Notes”). The Senior Notes maturities range from 2026 through 2051. Interest rates on these borrowings are fixed, ranging from 3.38% to 8.35%, and interest is payable semiannually.

- changed (2025-06-10):
[0001571996-25-000063:note_history:73]
Legacy Notes — The Company has outstanding unsecured notes and debentures (collectively, the “Legacy Notes”) that were issued by Dell Inc. (“Dell”), a wholly-owned subsidiary of Dell Technologies Inc., prior to the acquisition of Dell by Dell Technologies Inc. in the going-private transaction that closed in October 2013. The Legacy Notes’ maturities range from 2028 through 2040. Interest rates on these borrowings are fixed, ranging from 5.40% to 7.10% per annum, and interest is payable semiannually.
  (was, 2024-12-10, similarity 0.9357):
[0001571996-24-000143:note_history:73]
Legacy Notes — The Company has outstanding unsecured notes and debentures (collectively, the “Legacy Notes”) that were issued by Dell Inc. (“Dell”), a wholly-owned subsidiary of Dell Technologies Inc., prior to the acquisition of Dell by Dell Technologies Inc. in the going-private transaction that closed in October 2013. The Legacy Notes’ maturities range from 2028 through 2040. Interest rates on these borrowings are fixed, ranging from 5.40% to 7.10%, and interest is payable semiannually.

- changed (2025-06-10):
[0001571996-25-000063:note_history:74]
As of May 2, 2025, the Company had no outstanding borrowings under the revolving credit facility.
  (was, 2024-12-10, similarity 0.9524):
[0001571996-24-000143:note_history:74]
As of November 1, 2024, the Company had no outstanding borrowings under the revolving credit facility.

- changed (2025-06-10):
[0001571996-25-000063:note_history:75]
Commercial Paper Program — The Company maintains a commercial paper program under which the Company may issue unsecured notes in a maximum aggregate face amount of $5.0 billion outstanding at any time, with maturities of up to 397 days from the date of issuance. The notes are sold on customary terms in the U.S. commercial paper market on a private placement basis. The proceeds of the notes are used for general corporate purposes. As of May 2, 2025, the Company had no outstanding issuances under the commercial paper program.
  (was, 2024-12-10, similarity 0.9866):
[0001571996-24-000143:note_history:75]
Commercial Paper Program — The Company maintains a commercial paper program under which the Company may issue unsecured notes in a maximum aggregate face amount of $5.0 billion outstanding at any time, with maturities up to 397 days from the date of issuance. The notes are sold on customary terms in the U.S. commercial paper market on a private placement basis. The proceeds of the notes are used for general corporate purposes. As of November 1, 2024, the Company had no outstanding issuances under the commercial paper program.

- changed (2025-06-10):
[0001571996-25-000063:note_history:76]
Covenants — The credit agreement governing the revolving credit facility and the indentures governing the Senior Notes and the Legacy Notes impose various limitations, subject to exceptions, on creating certain liens and entering into sale and lease-back transactions. The foregoing credit agreement and indentures contain customary events of default, and the revolving credit facility is subject to an interest coverage ratio covenant that is tested at the end of each fiscal quarter with respect to the Company’s preceding four fiscal quarters. The Company was in compliance with this financial covenant as of May 2, 2025.
  (was, 2024-12-10, similarity 0.9912):
[0001571996-24-000143:note_history:76]
Covenants — The credit agreement governing the revolving credit facility and the indentures governing the Senior Notes and the Legacy Notes impose various limitations, subject to exceptions, on creating certain liens and entering into sale and lease-back transactions. The foregoing credit agreement and indentures contain customary events of default, and the revolving credit facility is subject to an interest coverage ratio covenant that is tested at the end of each fiscal quarter with respect to the Company’s preceding four fiscal quarters. The Company was in compliance with this financial covenant as of November 1, 2024.

- changed (2025-06-10):
[0001571996-25-000063:note_history:77]
The following table presents the aggregate future maturities of the Company’s debt as of May 2, 2025, excluding associated carrying value adjustments, for the periods indicated:
  (was, 2024-12-10, similarity 0.9742):
[0001571996-24-000143:note_history:77]
The following table presents the aggregate future maturities of the Company’s debt as of November 1, 2024, excluding associated carrying value adjustments, for the periods indicated:

- changed (2025-06-10):
[0001571996-25-000063:note_history:78]
|  | May 2, 2025 |
|  | (in millions) |
| Fiscal 2026 (remaining nine months) | $ | 4,106 |  |
| Fiscal 2027 | 7,180 |  |
| Fiscal 2028 | 1,696 |  |
| Fiscal 2029 | 2,470 |  |
| Fiscal 2030 | 3,053 |  |
| Thereafter | 10,526 |  |
| Total maturities, principal amount | $ | 29,031 |  |
  (was, 2024-12-10, similarity 0.9389):
[0001571996-24-000143:note_history:78]
|  | November 1, 2024 |
|  | (in millions) |
| Fiscal 2025 (remaining three months) | $ | 2,023 |  |
| Fiscal 2026 | 3,996 |  |
| Fiscal 2027 | 6,020 |  |
| Fiscal 2028 | 1,308 |  |
| Fiscal 2029 | 1,372 |  |
| Thereafter | 10,533 |  |
| Total maturities, principal amount | $ | 25,252 |  |

- removed (2025-06-10):
[0001571996-24-000143:note_history:79]
The Company completed the following transactions during the nine months ended November 1, 2024:

- removed (2025-06-10):
[0001571996-24-000143:note_history:80]
•the issuance of $1 billion principal amount of 5.40% Senior Notes due April 2034, the proceeds of which were utilized to prepay a portion of the outstanding 6.02% Senior Notes due June 2026;

- removed (2025-06-10):
[0001571996-24-000143:note_history:81]
•the repayment of $1 billion principal amount of the 4.00% Senior Notes due July 2024; and

- removed (2025-06-10):
[0001571996-24-000143:note_history:82]
•the issuance of $0.7 billion principal amount of 4.35% Senior Notes due February 2030 and $0.8 billion principal amount of 4.85% Senior Notes due February 2035, the proceeds of which were utilized to redeem the 5.85% Senior Notes due July 2025.


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-06-10):
[0001571996-25-000063:note_history:83]
|  | May 2, 2025 |  | January 31, 2025 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Notes | $ | 18.9 |  |  | $ | 18.9 |  |  | $ | 15.0 |  |  | $ | 15.0 |  |
| Legacy Notes | $ | 0.9 |  |  | $ | 1.0 |  |  | $ | 0.9 |  |  | $ | 1.0 |  |
| DFS Debt | $ | 8.9 |  |  | $ | 8.7 |  |  | $ | 8.7 |  |  | $ | 8.5 |  |
  (was, 2024-12-10, similarity 0.9446):
[0001571996-24-000143:note_history:83]
|  | November 1, 2024 |  | February 2, 2024 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Notes | $ | 15.0 |  |  | $ | 15.1 |  |  | $ | 15.5 |  |  | $ | 15.8 |  |
| Legacy Notes | $ | 0.9 |  |  | $ | 1.0 |  |  | $ | 0.9 |  |  | $ | 1.0 |  |
| DFS Debt | $ | 9.2 |  |  | $ | 8.9 |  |  | $ | 9.5 |  |  | $ | 9.1 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2025-06-10):
[0001571996-25-000063:note_history:84]
|  | May 2, 2025 |  | January 31, 2025 |
| DFS debt | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing facility | $ | 2,606 |  |  | $ | 3,018 |  |
| Fixed-term securitization offerings | 3,154 |  |  | 2,756 |  |
| Total DFS U.S. debt, principal amount | 5,760 |  |  | 5,774 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 702 |  |  | 624 |  |
| Other borrowings | 772 |  |  | 754 |  |
| Dell Bank senior unsecured eurobonds | 1,693 |  |  | 1,559 |  |
| Total DFS international debt, principal amount | 3,167 |  |  | 2,937 |  |
| Total DFS debt, principal amount | $ | 8,927 |  |  | $ | 8,711 |  |
| Total short-term DFS debt | $ | 4,809 |  |  | $ | 5,175 |  |
| Total long-term DFS debt | $ | 4,118 |  |  | $ | 3,536 |  |

- changed (2025-06-10):
[0001571996-25-000063:note_history:85]
|  | May 2, 2025 |  | January 31, 2025 |
|  | (in millions) |
| Senior Notes | $ | 19,073 |  |  | $ | 15,073 |  |
| Legacy Notes | 952 |  |  | 952 |  |
| DFS Debt (Note 4) | 8,927 |  |  | 8,711 |  |
| Other | 79 |  |  | 52 |  |
| Total debt, principal amount | 29,031 |  |  | 24,788 |  |
| Unamortized discount, net of unamortized premium | (113) |  |  | (110) |  |
| Debt issuance costs | (137) |  |  | (111) |  |
| Total debt, carrying value | $ | 28,781 |  |  | $ | 24,567 |  |
| Total short-term debt, carrying value | $ | 4,845 |  |  | $ | 5,204 |  |
| Total long-term debt, carrying value | $ | 23,936 |  |  | $ | 19,363 |  |
  (was, 2024-12-10, similarity 0.9655):
[0001571996-24-000143:note_history:85]
|  | November 1, 2024 |  | February 2, 2024 |
|  | (in millions) |
| Senior Notes | $ | 15,073 |  |  | $ | 15,607 |  |
| Legacy Notes | 952 |  |  | 952 |  |
| DFS Debt (Note 4) | 9,171 |  |  | 9,492 |  |
| Other | 56 |  |  | 171 |  |
| Total debt, principal amount | 25,252 |  |  | 26,222 |  |
| Unamortized discount, net of unamortized premium | (113) |  |  | (114) |  |
| Debt issuance costs | (117) |  |  | (114) |  |
| Total debt, carrying value | $ | 25,022 |  |  | $ | 25,994 |  |
| Total short-term debt, carrying value | $ | 5,612 |  |  | $ | 6,982 |  |
| Total long-term debt, carrying value | $ | 19,410 |  |  | $ | 19,012 |  |

- removed (2025-06-10):
[0001571996-24-000143:note_history:86]
|  | November 1, 2024 |  | February 2, 2024 |
| DFS debt | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing facility | $ | 2,753 |  |  | $ | 2,730 |  |
| Fixed-term securitization offerings | 3,264 |  |  | 3,157 |  |
| Other | — |  |  | 28 |  |
| Total DFS U.S. debt, principal amount | 6,017 |  |  | 5,915 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 723 |  |  | 761 |  |
| Other borrowings | 798 |  |  | 935 |  |
| Note payable | — |  |  | 250 |  |
| Dell Bank senior unsecured eurobonds | 1,633 |  |  | 1,631 |  |
| Total DFS international debt, principal amount | 3,154 |  |  | 3,577 |  |
| Total DFS debt, principal amount | $ | 9,171 |  |  | $ | 9,492 |  |
| Total short-term DFS debt | $ | 5,582 |  |  | $ | 5,863 |  |
| Total long-term DFS debt | $ | 3,589 |  |  | $ | 3,629 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-06-10):
[0001571996-25-000063:note_history:87]
The following table presents the aggregate future maturities of the Company’s debt as of May 2, 2025, excluding associated carrying value adjustments, for the periods indicated:
  (was, 2024-12-10, similarity 0.9742):
[0001571996-24-000143:note_history:87]
The following table presents the aggregate future maturities of the Company’s debt as of November 1, 2024, excluding associated carrying value adjustments, for the periods indicated:

- changed (2025-06-10):
[0001571996-25-000063:note_history:88]
|  | May 2, 2025 |
|  | (in millions) |
| Fiscal 2026 (remaining nine months) | $ | 4,106 |  |
| Fiscal 2027 | 7,180 |  |
| Fiscal 2028 | 1,696 |  |
| Fiscal 2029 | 2,470 |  |
| Fiscal 2030 | 3,053 |  |
| Thereafter | 10,526 |  |
| Total maturities, principal amount | $ | 29,031 |  |
  (was, 2024-12-10, similarity 0.9389):
[0001571996-24-000143:note_history:88]
|  | November 1, 2024 |
|  | (in millions) |
| Fiscal 2025 (remaining three months) | $ | 2,023 |  |
| Fiscal 2026 | 3,996 |  |
| Fiscal 2027 | 6,020 |  |
| Fiscal 2028 | 1,308 |  |
| Fiscal 2029 | 1,372 |  |
| Thereafter | 10,533 |  |
| Total maturities, principal amount | $ | 25,252 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: no_current_note, score: 0.0

- removed (2025-06-10):
[0001571996-24-000143:note_history:89]
RELATED PARTY TRANSACTIONS 
Prior to the acquisition on November 22, 2023 of VMware LLC (previously VMware, Inc. and individually and together with its consolidated subsidiaries, “VMware”) by Broadcom Inc. (“Broadcom”), VMware was considered a related party of the Company. Upon Broadcom’s acquisition of VMware, Michael Dell’s ownership interest in VMware and his position as Chairman of the Board of VMware terminated, and the Company determined no related party relationship exists with Broadcom or VMware effective as of November 22, 2023. The Company continues to engage in select transactions with VMware following the completion of Broadcom’s acquisition and the termination of the related party relationship. See Note 16 of the Notes to the Condensed Consolidated Financial Statements for additional information.

- removed (2025-06-10):
[0001571996-24-000143:note_history:90]
Related Party Transactions with VMware

- removed (2025-06-10):
[0001571996-24-000143:note_history:91]
The information provided below includes a summary of related party transactions with VMware for the three and nine months ended November 3, 2023.

- removed (2025-06-10):
[0001571996-24-000143:note_history:92]
•Dell Technologies integrated or bundled select VMware products and services with Dell Technologies’ products and sold them to end-users. Dell Technologies also acted as a distributor, purchasing VMware’s standalone products and services for resale to end-user customers. Where applicable, costs under these arrangements were presented net of rebates received by Dell Technologies.

- removed (2025-06-10):
[0001571996-24-000143:note_history:93]
•DFS provided financing to certain VMware end-users, which resulted in the recognition of amounts due to related parties on the Condensed Consolidated Statements of Financial Position. Associated financing fees were recorded to product net revenue on the Condensed Consolidated Statements of Income and were reflected within sales and leases of products to VMware in the table below.

- removed (2025-06-10):
[0001571996-24-000143:note_history:94]
•Dell Technologies procured products and services from VMware for its internal use. For the three and nine months ended November 3, 2023, costs incurred associated with products and services purchased from VMware for internal use were immaterial.

- removed (2025-06-10):
[0001571996-24-000143:note_history:95]
•Dell Technologies sold and leased products and sold services to VMware. For the three and nine months ended November 3, 2023, revenue recognized from sales of services to VMware was immaterial.

- removed (2025-06-10):
[0001571996-24-000143:note_history:96]
•Dell Technologies and VMware entered into joint marketing, sales, and branding arrangements, for which both parties incurred costs. For the three and nine months ended November 3, 2023, consideration received from VMware for joint marketing, sales, and branding arrangements was immaterial.

- removed (2025-06-10):
[0001571996-24-000143:note_history:97]
The following table presents information about the impact of Dell Technologies’ related party transactions with VMware on the Consolidated Statements of Income for the three and nine months ended November 3, 2023:

- removed (2025-06-10):
[0001571996-24-000143:note_history:98]
|  |  |  |  |  | Three Months Ended |  |  |  | Nine Months Ended |
|  | Classification |  |  |  | November 3, 2023 |  |  |  | November 3, 2023 |  |  |
|  |  |  |  |  | (in millions) |
| Sales and leases of products to VMware | Net revenue — products |  |  |  | $ | 16 |  |  |  |  | $ | 94 |  |  |  |
| Purchase of VMware products for resale | Cost of net revenue — products |  |  |  | $ | 379 |  |  |  |  | $ | 970 |  |  |  |
| Purchase of VMware services for resale | Cost of net revenue — services |  |  |  | $ | 884 |  |  |  |  | $ | 2,640 |  |  |  |

- removed (2025-06-10):
[0001571996-24-000143:note_history:99]
In connection with the completion of the VMware Spin-off described in Note 10 of the Notes to the Condensed Consolidated Financial Statements, Dell Technologies and VMware entered into a Tax Matters Agreement effective as of April 14, 2021 (the “Tax Matters Agreement”), which governs the respective rights and obligations of Dell Technologies and VMware regarding income and other taxes as well as related matters, including tax liabilities and benefits, attributes, and returns for periods both preceding and following the VMware Spin-off. Pursuant to the Tax Matters Agreement, net receipts from VMware during the nine months ended November 3, 2023 were immaterial.

- removed (2025-06-10):
[0001571996-24-000143:note_history:100]
Other Related Parties

- removed (2025-06-10):
[0001571996-24-000143:note_history:101]
Transactions with other related parties during the periods presented were immaterial, individually and in aggregate.


## us-gaap:ScheduleOfRelatedPartyTransactionsTableTextBlock (related_parties) — matched_by: no_current_note, score: 0.0

- removed (2025-06-10):
[0001571996-24-000143:note_history:102]
The following table presents information about the impact of Dell Technologies’ related party transactions with VMware on the Consolidated Statements of Income for the three and nine months ended November 3, 2023:

- removed (2025-06-10):
[0001571996-24-000143:note_history:103]
|  |  |  |  |  | Three Months Ended |  |  |  | Nine Months Ended |
|  | Classification |  |  |  | November 3, 2023 |  |  |  | November 3, 2023 |  |  |
|  |  |  |  |  | (in millions) |
| Sales and leases of products to VMware | Net revenue — products |  |  |  | $ | 16 |  |  |  |  | $ | 94 |  |  |  |
| Purchase of VMware products for resale | Cost of net revenue — products |  |  |  | $ | 379 |  |  |  |  | $ | 970 |  |  |  |
| Purchase of VMware services for resale | Cost of net revenue — services |  |  |  | $ | 884 |  |  |  |  | $ | 2,640 |  |  |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-06-10):
[0001571996-25-000063:note_history:104]
|  |  |  | Three Months Ended |
|  |  |  |  |  | May 2, 2025 |  | May 3, 2024 |  |  |
|  |  |  |  |  | (in millions) |
| Net revenue: |  |  |  |  |  |  |  |  |  |
| Infrastructure Solutions Group: |  |  |  |  |  |  |  |  |  |
| Servers and networking |  |  |  |  | $ | 6,321 |  |  | $ | 5,466 |  |  |  |
| Storage |  |  |  |  | 3,996 |  |  | 3,761 |  |  |  |
| Total ISG net revenue |  |  |  |  | $ | 10,317 |  |  | $ | 9,227 |  |  |  |
| Client Solutions Group: |  |  |  |  |  |  |  |  |  |
| Commercial |  |  |  |  | $ | 11,046 |  |  | $ | 10,154 |  |  |  |
| Consumer |  |  |  |  | 1,463 |  |  | 1,813 |  |  |  |
| Total CSG net revenue |  |  |  |  | $ | 12,509 |  |  | $ | 11,967 |  |  |  |
  (was, 2024-12-10, similarity 0.7629):
[0001571996-24-000143:note_history:104]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 1, 2024 |  | November 3, 2023 |  | November 1, 2024 |  | November 3, 2023 |  |  |
|  | (in millions) |
| Net revenue: |  |  |  |  |  |  |  |  |  |
| Infrastructure Solutions Group: |  |  |  |  |  |  |  |  |  |
| Servers and networking | $ | 7,364 |  |  | $ | 4,656 |  |  | $ | 20,502 |  |  | $ | 12,767 |  |  |  |
| Storage | 4,004 |  |  | 3,843 |  |  | 11,739 |  |  | 11,786 |  |  |  |
| Total ISG net revenue | $ | 11,368 |  |  | $ | 8,499 |  |  | $ | 32,241 |  |  | $ | 24,553 |  |  |  |
| Client Solutions Group: |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 10,138 |  |  | $ | 9,835 |  |  | $ | 30,848 |  |  | $ | 30,251 |  |  |  |
| Consumer | 1,993 |  |  | 2,441 |  |  | 5,664 |  |  | 6,950 |  |  |  |
| Total CSG net revenue | $ | 12,131 |  |  | $ | 12,276 |  |  | $ | 36,512 |  |  | $ | 37,201 |  |  |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-06-10):
[0001571996-25-000063:note_history:105]
|  |  |  | Three Months Ended |
|  |  |  |  |  | May 2, 2025 |  | May 3, 2024 |
|  |  |  |  |  | (in millions) |
| Deferred revenue: |  |  |  |  |  |  |  |
| Deferred revenue at beginning of period |  |  |  |  | $ | 25,965 |  |  | $ | 29,145 |  |
| Revenue deferrals |  |  |  |  | 5,455 |  |  | 4,469 |  |
| Revenue recognized |  |  |  |  | (5,100) |  |  | (5,464) |  |
| Deferred revenue at end of period |  |  |  |  | $ | 26,320 |  |  | $ | 28,150 |  |
| Short-term deferred revenue |  |  |  |  | $ | 13,907 |  |  | $ | 15,034 |  |
| Long-term deferred revenue |  |  |  |  | $ | 12,413 |  |  | $ | 13,116 |  |
  (was, 2024-12-10, similarity 0.6789):
[0001571996-24-000143:note_history:105]
|  | Three Months Ended |  | Nine Months Ended |
|  | November 1, 2024 |  | November 3, 2023 |  | November 1, 2024 |  | November 3, 2023 |
|  | (in millions) |
| Deferred revenue: |  |  |  |  |  |  |  |
| Deferred revenue at beginning of period | $ | 27,712 |  |  | $ | 30,312 |  |  | $ | 29,145 |  |  | $ | 30,286 |  |
| Revenue deferrals | 3,897 |  |  | 4,492 |  |  | 13,286 |  |  | 15,236 |  |
| Revenue recognized | (5,262) |  |  | (5,766) |  |  | (16,084) |  |  | (16,484) |  |
| Other (a) | (136) |  |  | 15 |  |  | (136) |  |  | 15 |  |
| Deferred revenue at end of period | $ | 26,211 |  |  | $ | 29,053 |  |  | $ | 26,211 |  |  | $ | 29,053 |  |
| Short-term deferred revenue | $ | 13,787 |  |  | $ | 15,206 |  |  | $ | 13,787 |  |  | $ | 15,206 |  |
| Long-term deferred revenue | $ | 12,424 |  |  | $ | 13,847 |  |  | $ | 12,424 |  |  | $ | 13,847 |  |

- changed (2025-06-10):
[0001571996-25-000063:note_history:106]
Remaining Performance Obligations — Remaining performance obligations represent the aggregate amount of the transaction price allocated to performance obligations not delivered, or partially undelivered, as of the end of the reporting period. Remaining performance obligations include deferred revenue plus unbilled amounts not yet recorded in deferred revenue. The value of the transaction price allocated to remaining performance obligations as of May 2, 2025 was approximately $49 billion. The Company expects to recognize approximately 67% of remaining performance obligations as revenue in the next twelve months, 16% in the following twelve months, and the remainder thereafter.
  (was, 2024-12-10, similarity 0.9653):
[0001571996-24-000143:note_history:106]
Remaining Performance Obligations — Remaining performance obligations represent the aggregate amount of the transaction price allocated to performance obligations not delivered, or partially undelivered, as of the end of the reporting period. Remaining performance obligations include deferred revenue plus unbilled amounts not yet recorded in deferred revenue. The value of the transaction price allocated to remaining performance obligations as of November 1, 2024 was approximately $37 billion. The Company expects to recognize approximately 60% of remaining performance obligations as revenue in the next twelve months, and the remainder thereafter.

- removed (2025-06-10):
[0001571996-24-000143:note_history:107]
____________________

- removed (2025-06-10):
[0001571996-24-000143:note_history:108]
(a) For the three and nine months ended November 1, 2024, Other represents the reclassification of Secureworks deferred revenue to liabilities held for sale. See Note 1 of the Notes to the Condensed Consolidated Financial Statements for more information about the pending sale of Secureworks.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2025-06-10):
[0001571996-25-000063:note_history:109]
SUBSEQUENT EVENTS 
There were no known events occurring after May 2, 2025 and up until the date of issuance of this report that would materially affect the information presented herein.
  (was, 2024-12-10, similarity 0.9753):
[0001571996-24-000143:note_history:109]
SUBSEQUENT EVENTS 
There were no known events occurring after November 1, 2024, and up until the date of issuance of this report that would materially affect the information presented herein.
