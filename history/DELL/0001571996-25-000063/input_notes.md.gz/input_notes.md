# DELL notes — 0001571996-25-000063


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001571996-25-000063:notes:1]
Basis of Presentation — The accompanying unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes filed with the U.S. Securities and Exchange Commission (“SEC”) in the Company’s Annual Report on Form 10-K for the fiscal year ended January 31, 2025. These Condensed Consolidated Financial Statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“GAAP”). In the opinion of management, the accompanying Condensed Consolidated Financial Statements reflect all adjustments of a normal recurring nature considered necessary to fairly state the financial position of the Company as of May 2, 2025 and January 31, 2025 and the results of its operations, corresponding comprehensive income, changes in stockholders’ equity (deficit), and cash flows for the three months ended May 2, 2025 and May 3, 2024.

[0001571996-25-000063:notes:2]
The preparation of financial statements in accordance with GAAP requires management to make estimates and assumptions that affect the amounts reported in the Condensed Consolidated Financial Statements and the accompanying Notes. Actual results could differ materially from those estimates. The results of its operations, corresponding comprehensive income, and changes in stockholders’ equity (deficit) and cash flows for the three months ended May 2, 2025 and May 3, 2024 are not necessarily indicative of the results to be expected for the full fiscal year or for any other fiscal period.
The Company’s fiscal year is the 52- or 53-week period ending on the Friday nearest January 31. Both the fiscal year ending January 30, 2026 (“Fiscal 2026”) and the fiscal year ended January 31, 2025 (“Fiscal 2025”) are 52-week periods.


## us-gaap:ConsolidationPolicyTextBlock

[0001571996-25-000063:notes:3]
Principles of Consolidation — These Condensed Consolidated Financial Statements include the accounts of Dell Technologies Inc. and its wholly-owned subsidiaries, as well as the accounts of SecureWorks Corp. (“Secureworks”), which was majority-owned by Dell Technologies, through the date of the sale of Secureworks as discussed below. All intercompany transactions have been eliminated.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001571996-25-000063:notes:4]
Recently Issued Accounting Pronouncements

[0001571996-25-000063:notes:5]
Expense Disaggregation Disclosures — In November 2024, the Financial Accounting Standards Board (“FASB”) issued guidance to improve disclosures about a public entity’s expenses by requiring disclosure of additional information about the types of expenses commonly presented in the financial statements on an annual and interim basis. Public entities must adopt the new guidance for fiscal years beginning after December 15, 2026, with early adoption permitted. Upon adoption, the guidance can be applied prospectively or retrospectively. Adoption of this new guidance will result in increased disclosures in the Notes to the Consolidated Financial Statements.

[0001571996-25-000063:notes:6]
Income Taxes — In December 2023, the FASB issued guidance which requires companies to provide disaggregated income tax disclosures within the income tax rate reconciliation and income taxes paid. Public entities must adopt the new guidance for fiscal years beginning after December 15, 2024, with early adoption permitted. The Company will adopt the guidance prospectively. Adoption of this new guidance will result in increased disclosures in the Notes to the Consolidated Financial Statements.


## us-gaap:FairValueDisclosuresTextBlock

[0001571996-25-000063:notes:7]
[same as prior period, unchanged from 0001571996-24-000143:notes:10]

[0001571996-25-000063:notes:8]
|  | May 2, 2025 |  | January 31, 2025 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | Quoted Prices in Active Markets for Identical Assets |  | Significant Other Observable Inputs |  | Significant Unobservable Inputs |  |  |  | Quoted Prices in Active Markets for Identical Assets |  | Significant Other Observable Inputs |  | Significant Unobservable Inputs |  |  |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 4,610 |  |  | $ | — |  |  | $ | — |  |  | $ | 4,610 |  |  | $ | 571 |  |  | $ | — |  |  | $ | — |  |  | $ | 571 |  |
| Marketable equity and other securities | 7 |  |  | — |  |  | — |  |  | 7 |  |  | 8 |  |  | — |  |  | — |  |  | 8 |  |
| Derivative instruments | — |  |  | 357 |  |  | — |  |  | 357 |  |  | — |  |  | 302 |  |  | — |  |  | 302 |  |
| Total assets | $ | 4,617 |  |  | $ | 357 |  |  | $ | — |  |  | $ | 4,974 |  |  | $ | 579 |  |  | $ | 302 |  |  | $ | — |  |  | $ | 881 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative instruments | $ | — |  |  | $ | 235 |  |  | $ | — |  |  | $ | 235 |  |  | $ | — |  |  | $ | 75 |  |  | $ | — |  |  | $ | 75 |  |
| Total liabilities | $ | — |  |  | $ | 235 |  |  | $ | — |  |  | $ | 235 |  |  | $ | — |  |  | $ | 75 |  |  | $ | — |  |  | $ | 75 |  |

[0001571996-25-000063:notes:9]
[same as prior period, unchanged from 0001571996-24-000143:notes:12]

[0001571996-25-000063:notes:10]
Money Market Funds — The Company’s investment in money market funds that are classified as cash equivalents hold underlying investments with a weighted average maturity of 90 days or less and are recognized at fair value. The valuations of these securities are based on quoted prices for identical assets in active markets, when available, or pricing models whereby all significant inputs are observable, can be derived from, or can be corroborated by, observable market data. The Company reviews security pricing and assesses money market fund liquidity on a quarterly basis. As of May 2, 2025, the Company’s portfolio had no material exposure to money market funds with a fluctuating net asset value.

[0001571996-25-000063:notes:11]
[same as prior period, unchanged from 0001571996-24-000143:notes:14]

[0001571996-25-000063:notes:12]
[same as prior period, unchanged from 0001571996-24-000143:notes:15]

[0001571996-25-000063:notes:13]
Deferred Compensation Plans — The Company offers deferred compensation plans for eligible employees which allow participants to defer a portion of their compensation. Assets and liabilities associated with the plans are measured at fair value using Level 1 inputs. Assets were the same as liabilities associated with the plans at approximately $238 million and $244 million as of May 2, 2025 and January 31, 2025, respectively, and are included in other assets and other liabilities on the Condensed Consolidated Statements of Financial Position. The net impact on the Condensed Consolidated Statements of Income is not material since changes in the fair value of the assets substantially offset changes in the fair value of the liabilities. As such, assets and liabilities associated with these plans have not been included in the recurring fair value table above.

[0001571996-25-000063:notes:14]
Assets and Liabilities Measured at Fair Value on a Nonrecurring Basis — Certain assets are measured at fair value on a nonrecurring basis and therefore are not included in the recurring fair value table above. These assets consist primarily of financial assets such as the Company’s strategic investments in non-marketable equity and other securities and non-financial assets such as goodwill and intangible assets.

[0001571996-25-000063:notes:15]
Strategic investments in non-marketable equity and other securities and certain non-financial assets such as goodwill and intangible assets are measured at fair value only if they are deemed to be impaired or when there is an adjustment from observable price changes in the current period. If measured at fair value in the Condensed Consolidated Statements of Financial Position, these securities would generally be classified as Level 3 in the fair value hierarchy. See Note 3 and Note 8 of the Notes to the Condensed Consolidated Financial Statements for additional information about the Company’s investments and goodwill and intangible assets, respectively.

[0001571996-25-000063:notes:16]
[same as prior period, unchanged from 0001571996-24-000143:notes:20]

[0001571996-25-000063:notes:17]
|  | May 2, 2025 |  | January 31, 2025 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Notes | $ | 18.9 |  |  | $ | 18.9 |  |  | $ | 15.0 |  |  | $ | 15.0 |  |
| Legacy Notes | $ | 0.9 |  |  | $ | 1.0 |  |  | $ | 0.9 |  |  | $ | 1.0 |  |
| DFS Debt | $ | 8.9 |  |  | $ | 8.7 |  |  | $ | 8.7 |  |  | $ | 8.5 |  |

[0001571996-25-000063:notes:18]
[same as prior period, unchanged from 0001571996-24-000143:notes:22]


## us-gaap:InvestmentTextBlock

[0001571996-25-000063:notes:19]
INVESTMENTS
The Company has strategic investments in equity and other securities as well as immaterial investments in fixed income debt securities that are primarily recorded as long-term investments in the Condensed Consolidated Statements of Financial Position. As of May 2, 2025 and January 31, 2025, total investments were $1.6 billion and $1.5 billion, respectively.

[0001571996-25-000063:notes:20]
Equity and other securities include strategic investments in marketable and non-marketable securities. Investments in marketable securities are measured at fair value on a recurring basis. Investments in non-marketable equity and other securities primarily represent early-stage companies without readily determinable fair values. The Company has elected to apply the measurement alternative for non-marketable securities. Under the alternative, the Company measures investments without readily determinable fair values at cost, less impairment, adjusted for observable price changes. The Company makes a separate election to use the alternative for each eligible investment and is required to reassess at each reporting period whether an investment qualifies for the alternative. In evaluating these investments for impairment or observable price changes, the Company uses inputs including pre- and post-money valuations of recent financing events and the impact of those events on its fully diluted ownership percentages, as well as other available information regarding the issuer’s historical and forecasted performance.

[0001571996-25-000063:notes:21]
[same as prior period, unchanged from 0001571996-24-000143:notes:27]

[0001571996-25-000063:notes:22]
The following table presents the cost, cumulative unrealized gain, cumulative unrealized loss, and carrying value of the Company's strategic investments in marketable and non-marketable equity and other securities as of the dates indicated:

[0001571996-25-000063:notes:23]
|  | May 2, 2025 |  | January 31, 2025 |
|  | Cost |  | Unrealized Gain |  | Unrealized Loss |  | Carrying Value |  | Cost |  | Unrealized Gain |  | Unrealized Loss |  | Carrying Value |
|  | (in millions) |
| Marketable | $ | 11 |  |  | $ | 24 |  |  | $ | (28) |  |  | $ | 7 |  |  | $ | 11 |  |  | $ | 24 |  |  | $ | (27) |  |  | $ | 8 |  |
| Non-marketable | 809 |  |  | 1,030 |  |  | (267) |  |  | 1,572 |  |  | 739 |  |  | 1,009 |  |  | (261) |  |  | 1,487 |  |
| Total equity and other securities | $ | 820 |  |  | $ | 1,054 |  |  | $ | (295) |  |  | $ | 1,579 |  |  | $ | 750 |  |  | $ | 1,033 |  |  | $ | (288) |  |  | $ | 1,495 |  |

[0001571996-25-000063:notes:24]
[same as prior period, unchanged from 0001571996-24-000143:notes:30]

[0001571996-25-000063:notes:25]
[same as prior period, unchanged from 0001571996-24-000143:notes:31]

[0001571996-25-000063:notes:26]
|  |  |  | Three Months Ended |
|  |  |  |  |  | May 2, 2025 |  | May 3, 2024 |  |  |
|  |  |  |  |  | (in millions) |
| Marketable securities: |  |  |  |  |  |  |  |  |  |
| Unrealized loss |  |  |  |  | $ | (1) |  |  | $ | (5) |  |  |  |
| Non-marketable securities: |  |  |  |  |  |  |  |  |  |
| Unrealized gain |  |  |  |  | 22 |  |  | — |  |  |  |
| Unrealized loss |  |  |  |  | (6) |  |  | (30) |  |  |  |
| Net unrealized gain (loss) on equity and other securities (a) (b) |  |  |  |  | $ | 15 |  |  | $ | (35) |  |  |  |

[0001571996-25-000063:notes:27]
[same as prior period, unchanged from 0001571996-24-000143:notes:33]

[0001571996-25-000063:notes:28]
(a)For the three months ended May 2, 2025, net unrealized gains on non-marketable securities were primarily attributable to upward adjustments for observable price changes offset by losses attributable to impairments. 
(b)For the three months ended May 3, 2024, net unrealized losses on non-marketable securities were primarily attributable to downward adjustments for observable price changes.


## dell:CreditLossFinancialInstrumentLeasesDebtVariableInterestEntitiesAndCustomerReceivablesSalesTextBlock

[0001571996-25-000063:notes:29]
FINANCIAL SERVICES 
The Company offers or arranges a portfolio of payment and consumption solutions and services for its customers globally, including utility, subscription, as-a-Service, leases, and loans designed to match customers' consumption and financing preferences, and provide operational and financial flexibility.

[0001571996-25-000063:notes:30]
To support financing solutions and services as part of the portfolio, Dell Financial Services and its affiliates (“DFS”) originates, collects, and services customer financing arrangements primarily related to the purchase and use of Dell Technologies products and services. In some cases, the Company also offers financing for the purchase of third-party technology products that complement the Dell Technologies portfolio of products and services. New financing originations were $1.6 billion and $1.9 billion for the three months ended May 2, 2025 and May 3, 2024, respectively.

[0001571996-25-000063:notes:31]
The Company’s financing arrangements with customers are aggregated primarily as fixed-term leases and loans as described below.

[0001571996-25-000063:notes:32]
Leases — The Company enters into fixed-term financing arrangements with customers who seek lease financing for equipment. Leases are generally classified as sales-type leases or operating leases. Additionally, utility, subscription, and as-a-Service flexible consumption models may result in identification of embedded lease arrangements that require the recognition of sales-type leases or operating leases. Leases with business customers have fixed terms of generally two to four years.

[0001571996-25-000063:notes:33]
Loans — The Company also offers fixed-term loans to qualified small businesses, large commercial accounts, governmental organizations, educational entities, and certain individual consumer customers. These loans are repaid in equal payments including interest and have defined terms of generally three to five years. The fair value of the fixed-term loan portfolio is determined using market observable inputs. The carrying value of these loans approximates fair value.

[0001571996-25-000063:notes:34]
The Company historically offered revolving loans primarily to small and medium-sized commercial customers. During Fiscal 2025, the Company discontinued remaining offerings under the revolving loan portfolio. The Company continues to support existing customer arrangements as well as to transition these customers to fixed-term offerings. Due to the short-term nature of the revolving loan portfolio, as transactions are typically repaid within twelve months on average, the portfolio has now substantially transitioned to such fixed-term offerings.

[0001571996-25-000063:notes:35]
Financing Receivables

[0001571996-25-000063:notes:36]
The following table presents the components of the Company’s financing receivables as of the dates indicated:

[0001571996-25-000063:notes:37]
|  |  |  |  |  | May 2, 2025 |  |  |  |  |  | January 31, 2025 |
|  |  |  |  |  | (in millions) |
| Financing receivables, net: |  |  |  |  |  |  |  |  |  |  |  |
| Customer receivables, gross (a) |  |  |  |  | $ | 11,389 |  |  |  |  |  |  | $ | 11,216 |  |
| Allowance for losses |  |  |  |  | (144) |  |  |  |  |  |  | (153) |  |
| Customer receivables, net |  |  |  |  | 11,245 |  |  |  |  |  |  | 11,063 |  |
| Residual interest |  |  |  |  | 178 |  |  |  |  |  |  | 168 |  |
| Financing receivables, net |  |  |  |  | $ | 11,423 |  |  |  |  |  |  | $ | 11,231 |  |
| Short-term |  |  |  |  | $ | 5,381 |  |  |  |  |  |  | $ | 5,304 |  |
| Long-term |  |  |  |  | $ | 6,042 |  |  |  |  |  |  | $ | 5,927 |  |

[0001571996-25-000063:notes:38]
(a)Customer receivables, gross include amounts due from customers under fixed-term leases, fixed-term loans, and accrued interest, as well as the immaterial remaining amounts under the revolving loans.

[0001571996-25-000063:notes:39]
The following table presents the changes in allowance for financing receivable losses for the periods indicated:

[0001571996-25-000063:notes:40]
|  |  |  |  |  | Three Months Ended |
|  |  |  |  |  | May 2, 2025 |  |  |  |  |  | May 3, 2024 |  |  |
|  |  |  |  |  | (in millions) |
| Allowance for financing receivable losses: |
| Balances at beginning of period |  |  |  |  | $ | 153 |  |  |  |  |  |  | $ | 170 |  |  |  |  |  |  |  |
| Charge-offs, net of recoveries |  |  |  |  | (10) |  |  |  |  |  |  | (8) |  |  |  |  |  |  |  |
| Provision charged to income statement |  |  |  |  | 1 |  |  |  |  |  |  | 33 |  |  |  |  |  |  |  |
| Balances at end of period |  |  |  |  | $ | 144 |  |  |  |  |  |  | $ | 195 |  |  |  |  |  |  |  |

[0001571996-25-000063:notes:41]
The Company recognizes an allowance for financing receivable losses, including both the lease receivable and unguaranteed residual, in an amount equal to the expected losses, net of recoveries. The allowance for financing receivable losses on the lease receivable is determined based on various factors, including lifetime expected losses determined using macroeconomic forecast assumptions and management judgments applicable to and through the expected life of the portfolios as well as past due receivables, receivable type, and customer risk profile. The Company continues to monitor broader economic indicators and their potential impact on future credit loss performance.

[0001571996-25-000063:notes:42]
Aging

[0001571996-25-000063:notes:43]
The following table presents the aging of the Company’s customer financing receivables, gross, including accrued interest, as of the dates indicated:

[0001571996-25-000063:notes:44]
|  | May 2, 2025 |  | January 31, 2025 |
|  | (in millions) |
| Current 0 — 30 Days | $ | 10,718 |  |  | $ | 10,796 |  |
| Past Due 31 — 90 Days | 536 |  |  | 201 |  |
| Past Due > 90 Days | 135 |  |  | 219 |  |
| Total | $ | 11,389 |  |  | $ | 11,216 |  |

[0001571996-25-000063:notes:45]
Aging is likely to fluctuate as a result of the variability in volume of large transactions entered into over the period, and the administrative processes that accompany those transactions. Aging is also impacted by the timing of the Company’s fiscal period end date relative to calendar month-end customer payment due dates. As a result of these factors, fluctuations in aging from period to period do not necessarily indicate a material change in the collectibility of the portfolio.

[0001571996-25-000063:notes:46]
Customer receivables are placed on non-accrual status if principal or interest is past due and considered delinquent, or if there is concern about the collectibility of a specific customer receivable. The receivables identified as doubtful for collectibility may be classified as current for aging purposes.

[0001571996-25-000063:notes:47]
Credit Quality

[0001571996-25-000063:notes:48]
The following tables present customer receivables, gross, including accrued interest, by credit quality indicator, as of the dates indicated:

[0001571996-25-000063:notes:49]
|  | May 2, 2025 |
|  | Fiscal Year of Origination |  |  |  |  |
|  | 2026 |  | 2025 |  | 2024 |  | 2023 |  | 2022 |  | Years Prior |  |  |  | Total |
|  | (in millions) |
| Higher | $ | 839 |  |  | $ | 2,235 |  |  | $ | 1,896 |  |  | $ | 994 |  |  | $ | 237 |  |  | $ | 64 |  |  |  |  | $ | 6,265 |  |
| Mid | 612 |  |  | 2,069 |  |  | 621 |  |  | 385 |  |  | 79 |  |  | 10 |  |  |  |  | 3,776 |  |
| Lower | 261 |  |  | 472 |  |  | 329 |  |  | 216 |  |  | 48 |  |  | 22 |  |  |  |  | 1,348 |  |
| Total | $ | 1,712 |  |  | $ | 4,776 |  |  | $ | 2,846 |  |  | $ | 1,595 |  |  | $ | 364 |  |  | $ | 96 |  |  |  |  | $ | 11,389 |  |

[0001571996-25-000063:notes:50]
|  | January 31, 2025 |
|  | Fiscal Year of Origination |  |  |  |  |  |  |
|  | 2025 |  | 2024 |  | 2023 |  | 2022 |  | 2021 |  | Years Prior |  |  |  |  |  | Total |
|  | (in millions) |
| Higher | $ | 2,295 |  |  | $ | 2,160 |  |  | $ | 1,217 |  |  | $ | 357 |  |  | $ | 102 |  |  | $ | 4 |  |  |  |  |  |  | $ | 6,135 |  |
| Mid | 2,455 |  |  | 695 |  |  | 464 |  |  | 107 |  |  | 17 |  |  | 4 |  |  |  |  |  |  | 3,742 |  |
| Lower | 552 |  |  | 407 |  |  | 283 |  |  | 68 |  |  | 28 |  |  | 1 |  |  |  |  |  |  | 1,339 |  |
| Total | $ | 5,302 |  |  | $ | 3,262 |  |  | $ | 1,964 |  |  | $ | 532 |  |  | $ | 147 |  |  | $ | 9 |  |  |  |  |  |  | $ | 11,216 |  |

[0001571996-25-000063:notes:51]
The categories shown in the tables above segregate customer receivables based on the relative degrees of credit risk. Credit quality indicators are generally updated on a periodic basis. An internal grading system is utilized that assigns a credit level score based on a number of considerations, including liquidity, operating performance, and industry outlook.

[0001571996-25-000063:notes:52]
Leases

[0001571996-25-000063:notes:53]
The following table presents amounts included in the Condensed Consolidated Statements of Income related to sales-type lease activity for the periods indicated:

[0001571996-25-000063:notes:54]
|  |  |  | Three Months Ended |
|  |  |  |  |  | May 2, 2025 |  | May 3, 2024 |  |  |
|  |  |  |  |  | (in millions) |
| Interest income — products |  |  |  |  | $ | 93 |  |  | $ | 66 |  |  |  |
| Net revenue — products |  |  |  |  | $ | 119 |  |  | $ | 728 |  |  |  |
| Cost of net revenue — products |  |  |  |  | 131 |  |  | 618 |  |  |  |
| Gross margin — products |  |  |  |  | $ | (12) |  |  | $ | 110 |  |  |  |

[0001571996-25-000063:notes:55]
The following table presents the future maturity of the Company’s customer leases and associated financing payments, and reconciles the undiscounted cash flows to the customer receivables, gross recognized on the Condensed Consolidated Statements of Financial Position as of the date indicated:

[0001571996-25-000063:notes:56]
|  | May 2, 2025 |
|  | (in millions) |
| Fiscal 2026 (remaining nine months) | $ | 2,655 |  |
| Fiscal 2027 | 2,631 |  |
| Fiscal 2028 | 1,307 |  |
| Fiscal 2029 | 628 |  |
| Fiscal 2030 and thereafter | 279 |  |
| Total undiscounted cash flows | 7,500 |  |
| Loans | 4,951 |  |
| Less: Unearned income | (1,062) |  |
| Total customer receivables, gross | $ | 11,389 |  |

[0001571996-25-000063:notes:57]
Operating Leases

[0001571996-25-000063:notes:58]
The Company’s operating leases primarily consist of fixed-term leases and contractually committed embedded leases identified within flexible consumption arrangements.

[0001571996-25-000063:notes:59]
The following table presents the components of the Company’s operating lease portfolio included in property, plant, and equipment, net as of the dates indicated:

[0001571996-25-000063:notes:60]
|  | May 2, 2025 |  | January 31, 2025 |
|  | (in millions) |
| Equipment under operating lease, gross | $ | 4,420 |  |  | $ | 4,180 |  |
| Less: Accumulated depreciation | (2,148) |  |  | (1,995) |  |
| Equipment under operating lease, net | $ | 2,272 |  |  | $ | 2,185 |  |

[0001571996-25-000063:notes:61]
The following table presents operating lease income related to lease payments and depreciation expense for the Company’s operating lease portfolio for the periods indicated:

[0001571996-25-000063:notes:62]
|  |  |  | Three Months Ended |
|  |  |  |  |  | May 2, 2025 |  | May 3, 2024 |  |  |
|  |  |  |  |  | (in millions) |
| Income related to lease payments |  |  |  |  | $ | 358 |  |  | $ | 356 |  |  |  |
| Depreciation expense |  |  |  |  | $ | 244 |  |  | $ | 240 |  |  |  |

[0001571996-25-000063:notes:63]
The following table presents the future payments to be received by the Company in operating lease contracts as of the date indicated:

[0001571996-25-000063:notes:64]
|  | May 2, 2025 |
|  | (in millions) |
| Fiscal 2026 (remaining nine months) | $ | 967 |  |
| Fiscal 2027 | 908 |  |
| Fiscal 2028 | 515 |  |
| Fiscal 2029 | 204 |  |
| Fiscal 2030 and thereafter | 67 |  |
| Total | $ | 2,661 |  |

[0001571996-25-000063:notes:65]
DFS Debt

[0001571996-25-000063:notes:66]
The Company maintains programs that facilitate the funding of leases, loans, and other alternative payment structures in the capital markets. The majority of DFS debt is non-recourse to Dell Technologies and represents borrowings under securitization programs and structured financing programs for which the Company’s risk of loss is limited to transferred lease and loan payments and associated equipment.

[0001571996-25-000063:notes:67]
The following table presents DFS debt as of the dates indicated and excludes the allocated portion of the Company’s other borrowings, which represents the additional amount considered to fund the DFS business:

[0001571996-25-000063:notes:68]
|  | May 2, 2025 |  | January 31, 2025 |
| DFS debt | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing facility | $ | 2,606 |  |  | $ | 3,018 |  |
| Fixed-term securitization offerings | 3,154 |  |  | 2,756 |  |
| Total DFS U.S. debt, principal amount | 5,760 |  |  | 5,774 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 702 |  |  | 624 |  |
| Other borrowings | 772 |  |  | 754 |  |
| Dell Bank senior unsecured eurobonds | 1,693 |  |  | 1,559 |  |
| Total DFS international debt, principal amount | 3,167 |  |  | 2,937 |  |
| Total DFS debt, principal amount | $ | 8,927 |  |  | $ | 8,711 |  |
| Total short-term DFS debt | $ | 4,809 |  |  | $ | 5,175 |  |
| Total long-term DFS debt | $ | 4,118 |  |  | $ | 3,536 |  |

[0001571996-25-000063:notes:69]
DFS U.S. Debt

[0001571996-25-000063:notes:70]
Asset-Based Financing Facility — The Company maintains an asset-based financing facility in the United States, which is a revolving facility for fixed-term leases and loans. This debt is collateralized solely by the U.S. lease and loan payments and associated equipment in the facility. The asset-based financing facility consists of two tranches, with effective dates through July 7, 2025 and July 7, 2026, respectively. As of May 2, 2025, the total debt capacity related to the asset-based financing facility was $5.0 billion. The debt has a variable interest rate, and the duration of the debt is based on the terms of the underlying lease and loan payment streams. The Company enters into interest rate swap agreements to economically convert a portion of this debt from a floating rate to a fixed rate. See Note 7 of the Notes to the Condensed Consolidated Financial Statements for additional information about the Company’s interest rate swaps.

[0001571996-25-000063:notes:71]
The asset-based financing facility contains standard structural features related to the performance of the funded receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements. In the event one or more of these criteria are not met and the Company is unable to restructure the facility, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed. As of May 2, 2025, these criteria were met.

[0001571996-25-000063:notes:72]
Fixed-Term Securitization Offerings — The Company periodically issues asset-backed debt securities under fixed-term securitization programs to private investors. The asset-backed debt securities are collateralized solely by the U.S. fixed-term lease and loan payments and associated equipment, which are held by Special Purpose Entities (“SPEs”), as discussed below. The interest rate on these securities is fixed and ranges from 4.59% to 6.80% per annum as of May 2, 2025, and the duration of these securities is based on the terms of the underlying lease and loan payment streams.

[0001571996-25-000063:notes:73]
DFS International Debt

[0001571996-25-000063:notes:74]
Securitization Facility — The Company maintains a securitization facility in Europe for fixed-term leases and loans. The debt under this facility has a variable interest rate, and the duration of the debt is based on the terms of the underlying lease and loan payment streams. This facility is effective through December 22, 2026 and had a total debt capacity of $903 million as of May 2, 2025.

[0001571996-25-000063:notes:75]
The securitization facility contains standard structural features related to the performance of the securitized receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements. In the event one or more of these criteria are not met and the Company is unable to restructure the program, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed. As of May 2, 2025, these criteria were met.

[0001571996-25-000063:notes:76]
Other Borrowings — In connection with the Company’s international financing operations, the Company has entered into revolving structured financing debt programs related to its fixed-term lease and loan products sold in Canada, Europe, Australia and New Zealand, the Middle East, and Singapore. The debt under these programs has a variable interest rate.

[0001571996-25-000063:notes:77]
The duration of the debt in Canada, Europe, Australia and New Zealand, and the Middle East is based on the terms of the underlying lease and loan payment streams. These facilities are collateralized solely by the lease and loan payments and associated equipment in their respective region or country. The Canadian facility had a total debt capacity of $253 million as of May 2, 2025 and is effective through January 15, 2028. The European facility had a total debt capacity of $565 million as of May 2, 2025 and is effective through December 14, 2026. The Australia and New Zealand facility had a total debt capacity of $271 million as of May 2, 2025 and is effective through April 17, 2027. The Middle East facility had a total debt capacity of $150 million as of May 2, 2025 and is effective through March 14, 2027.

[0001571996-25-000063:notes:78]
The Company also has two unsecured Singapore facilities, which have a total debt capacity of $251 million as of May 2, 2025 and are effective through July 3, 2026 and July 3, 2027, respectively.

[0001571996-25-000063:notes:79]
Dell Bank Senior Unsecured Eurobonds — On October 27, 2021, Dell Bank issued 500 million Euro of 0.5% senior unsecured five year eurobonds due October 2026. On October 18, 2022, Dell Bank issued 500 million Euro of 4.5% senior unsecured five year eurobonds due October 2027. On June 13, 2024, Dell Bank issued 500 million Euro of 3.6% senior unsecured five year eurobonds due June 2029. The issuances of the senior unsecured eurobonds support the expansion of the financing operations in Europe.

[0001571996-25-000063:notes:80]
Variable Interest Entities

[0001571996-25-000063:notes:81]
In connection with the asset-based financing facility, securitization facility, and fixed-term securitization offerings discussed above, the Company transfers certain U.S. and European lease and loan payments and associated equipment to SPEs that meet the definition of a VIE and are consolidated, along with the associated debt described above, into the Condensed Consolidated Financial Statements, as the Company is the primary beneficiary of the VIEs. The SPEs are bankruptcy-remote legal entities with separate assets and liabilities. The purpose of the SPEs is to facilitate the funding of customer lease and loan payments and associated equipment in the capital markets.

[0001571996-25-000063:notes:82]
Some of the SPEs have entered into financing arrangements with multi-seller conduits that, in turn, issue asset-backed debt securities in the capital markets. DFS debt outstanding held by the consolidated VIEs is collateralized by the lease and loan payments and associated equipment. The Company’s risk of loss related to securitized receivables is limited to the amount by which the Company’s right to receive collections for assets securitized exceeds the amount required to pay interest, principal, and fees and expenses related to the asset-backed securities. The Company provides credit enhancement to the securitization offerings in the form of over-collateralization.

[0001571996-25-000063:notes:83]
The following table presents the assets and liabilities held by the consolidated VIEs as of the dates indicated, which are included in the Condensed Consolidated Statements of Financial Position:

[0001571996-25-000063:notes:84]
|  | May 2, 2025 |  | January 31, 2025 |
|  | (in millions) |
| Assets held by consolidated VIEs |  |  |  |
| Other current assets | $ | 151 |  |  | $ | 123 |  |
| Financing receivables, net of allowance |  |  |  |
| Short-term | $ | 3,181 |  |  | $ | 3,262 |  |
| Long-term | $ | 2,834 |  |  | $ | 2,725 |  |
| Property, plant, and equipment, net | $ | 984 |  |  | $ | 984 |  |
| Liabilities held by consolidated VIEs |  |  |  |
| Debt, net of unamortized debt issuance costs |  |  |  |
| Short-term | $ | 4,387 |  |  | $ | 4,598 |  |
| Long-term | $ | 2,061 |  |  | $ | 1,788 |  |

[0001571996-25-000063:notes:85]
Lease and loan payments and associated equipment transferred via securitization through SPEs were $1.2 billion and $0.8 billion for the three months ended May 2, 2025 and May 3, 2024, respectively.

[0001571996-25-000063:notes:86]
Customer Receivables Sales

[0001571996-25-000063:notes:87]
To manage certain concentrations of customer credit exposure, the Company may sell selected fixed-term customer receivables to unrelated third parties on a periodic basis, without recourse. The amounts of customer receivables sold for this purpose were immaterial for both the three months ended May 2, 2025 and May 3, 2024. The Company’s continuing involvement in these customer receivables is primarily limited to servicing arrangements.


## us-gaap:ScheduleOfDebtTableTextBlock

[0001571996-25-000063:notes:88]
The following table summarizes the Company’s outstanding debt as of the dates indicated:

[0001571996-25-000063:notes:89]
|  | May 2, 2025 |  | January 31, 2025 |
|  | (in millions) |
| Senior Notes | $ | 19,073 |  |  | $ | 15,073 |  |
| Legacy Notes | 952 |  |  | 952 |  |
| DFS Debt (Note 4) | 8,927 |  |  | 8,711 |  |
| Other | 79 |  |  | 52 |  |
| Total debt, principal amount | 29,031 |  |  | 24,788 |  |
| Unamortized discount, net of unamortized premium | (113) |  |  | (110) |  |
| Debt issuance costs | (137) |  |  | (111) |  |
| Total debt, carrying value | $ | 28,781 |  |  | $ | 24,567 |  |
| Total short-term debt, carrying value | $ | 4,845 |  |  | $ | 5,204 |  |
| Total long-term debt, carrying value | $ | 23,936 |  |  | $ | 19,363 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0001571996-25-000063:notes:90]
LEASES 
The Company enters into leasing transactions in which the Company is the lessee. These lease contracts are typically classified as operating leases. The Company’s lease contracts are generally for office buildings used to conduct its business, and the determination of whether such contracts contain leases generally does not require significant estimates or judgments. The Company also leases certain global logistics warehouses, employee vehicles, and equipment. As of May 2, 2025, the remaining terms of the Company’s leases generally range from one month to approximately eleven years. As of May 2, 2025 and January 31, 2025, there were no material finance leases in which the Company was a lessee.

[0001571996-25-000063:notes:91]
The Company also enters into leasing transactions in which the Company is the lessor, primarily through customer financing arrangements offered under DFS. DFS originates leases that are primarily classified as either sales-type leases or operating leases. See Note 4 of the Notes to the Condensed Consolidated Financial Statements for more information about the Company’s lessor arrangements.

[0001571996-25-000063:notes:92]
[same as prior period, unchanged from 0001571996-24-000143:notes:107]

[0001571996-25-000063:notes:93]
|  |  |  | Three Months Ended |
|  |  |  |  |  | May 2, 2025 |  | May 3, 2024 |  |  |
|  |  |  |  |  | (in millions) |
| Operating lease costs |  |  |  |  | $ | 58 |  |  | $ | 71 |  |  |  |
| Variable costs |  |  |  |  | 23 |  |  | 18 |  |  |  |
| Total lease costs |  |  |  |  | $ | 81 |  |  | $ | 89 |  |  |  |

[0001571996-25-000063:notes:94]
During the three months ended May 2, 2025 and May 3, 2024, sublease income, finance lease costs, and short-term lease costs were immaterial.

[0001571996-25-000063:notes:95]
[same as prior period, unchanged from 0001571996-24-000143:notes:110]

[0001571996-25-000063:notes:96]
|  | Classification |  | May 2, 2025 |  | January 31, 2025 |  |  |
|  |  |  | (in millions, except for term and discount rate) |
| Operating lease right-of-use assets | Other non-current assets |  | $ | 695 |  | $ | 660 |  |  |
| Current operating lease liabilities | Accrued and other current liabilities |  | $ | 239 |  | $ | 236 |  |  |
| Non-current operating lease liabilities | Other non-current liabilities |  | 555 |  | 522 |  |  |
| Total operating lease liabilities |  |  | $ | 794 |  | $ | 758 |  |  |
| Weighted-average remaining lease term (in years) |  |  | 4.33 |  | 4.36 |  |  |
| Weighted-average discount rate |  |  | 4.91 | % |  | 5.14 | % |  |  |

[0001571996-25-000063:notes:97]
[same as prior period, unchanged from 0001571996-24-000143:notes:112]

[0001571996-25-000063:notes:98]
|  | Three Months Ended |
|  | May 2, 2025 |  | May 3, 2024 |  |  |
|  | (in millions) |
| Cash paid for amounts included in the measurement of lease liabilities — operating cash outflows from operating leases | $ | 63 |  |  | $ | 69 |  |  |  |
| Right-of-use assets obtained in exchange for new operating lease liabilities | $ | 65 |  |  | $ | 10 |  |  |  |

[0001571996-25-000063:notes:99]
[same as prior period, unchanged from 0001571996-24-000143:notes:114]

[0001571996-25-000063:notes:100]
|  | May 2, 2025 |
|  | (in millions) |
| Fiscal 2026 (remaining nine months) | $ | 186 |  |
| Fiscal 2027 | 225 |  |
| Fiscal 2028 | 177 |  |
| Fiscal 2029 | 123 |  |
| Fiscal 2030 | 91 |  |
| Thereafter | 77 |  |
| Total lease payments | 879 |  |
| Less: Imputed interest | 85 |  |
| Total | $ | 794 |  |
| Current operating lease liabilities | $ | 239 |  |
| Non-current operating lease liabilities | $ | 555 |  |

[0001571996-25-000063:notes:101]
As of May 2, 2025, the Company’s undiscounted operating leases that had not yet commenced were immaterial.


## us-gaap:DebtDisclosureTextBlock

[0001571996-25-000063:notes:102]
DEBT
The following table summarizes the Company’s outstanding debt as of the dates indicated:

[0001571996-25-000063:notes:103]
During the three months ended May 2, 2025, the Company issued $1.0 billion principal amount of 4.75% Senior Notes due April 2028, $1.0 billion principal amount of 5.00% Senior Notes due April 2030, $1.0 billion principal amount of 5.30% Senior Notes due April 2032, and $1.0 billion principal amount of 5.50% Senior Notes due April 2035. The Company utilized the net proceeds of the issuance for general corporate purposes.

[0001571996-25-000063:notes:104]
Outstanding Debt

[0001571996-25-000063:notes:105]
Senior Notes — The Company completed offerings of multiple series of senior notes which were issued on June 1, 2016, June 22, 2016, March 20, 2019, April 9, 2020, December 13, 2021, January 24, 2023, March 18, 2024, October 8, 2024, and April 1, 2025 in aggregate principal amounts of $20.0 billion, $3.3 billion, $4.5 billion, $2.3 billion, $2.3 billion, $2.0 billion, $1.0 billion, $1.5 billion, and $4.0 billion respectively (collectively, the “Senior Notes”). The Senior Notes currently outstanding have maturity dates ranging from 2026 through 2051. Interest rates on these borrowings are fixed, ranging from 3.38% to 8.35% per annum, and interest is payable semiannually.

[0001571996-25-000063:notes:106]
Legacy Notes — The Company has outstanding unsecured notes and debentures (collectively, the “Legacy Notes”) that were issued by Dell Inc. (“Dell”), a wholly-owned subsidiary of Dell Technologies Inc., prior to the acquisition of Dell by Dell Technologies Inc. in the going-private transaction that closed in October 2013. The Legacy Notes’ maturities range from 2028 through 2040. Interest rates on these borrowings are fixed, ranging from 5.40% to 7.10% per annum, and interest is payable semiannually.

[0001571996-25-000063:notes:107]
DFS Debt — See Note 4 and Note 7 of the Notes to the Condensed Consolidated Financial Statements, respectively, for discussion of DFS debt and the interest rate swap agreements that hedge a portion of that debt.

[0001571996-25-000063:notes:108]
Revolving Credit Facility — The Company’s revolving credit facility provides the Company with revolving commitments in an aggregate principal amount of $6.0 billion for general corporate purposes and includes a letter of credit sub-facility of up to $0.5 billion and a swing-line loan sub-facility of up to $0.5 billion. The revolving credit facility also allows the Company to obtain incremental additional commitments on one or more occasions in minimum amounts of $10 million.

[0001571996-25-000063:notes:109]
Borrowings under the revolving credit facility bear interest at a rate per annum equal to an applicable margin plus, at the borrowers’ option, either (a) the specified adjusted term Secured Overnight Financing Rate (“SOFR”) or (b) a base rate. The margin applicable to SOFR and base rate borrowings varies based upon the Company’s existing credit ratings. The base rate is calculated based upon the greatest of the specified prime rate, the specified federal reserve bank rate, or SOFR plus 1%. The borrowers may voluntarily repay outstanding loans at any time without premium or penalty, other than customary breakage costs. The facility matures on November 1, 2027.

[0001571996-25-000063:notes:110]
As of May 2, 2025, the Company had no outstanding borrowings under the revolving credit facility.

[0001571996-25-000063:notes:111]
Commercial Paper Program — The Company maintains a commercial paper program under which the Company may issue unsecured notes in a maximum aggregate face amount of $5.0 billion outstanding at any time, with maturities of up to 397 days from the date of issuance. The notes are sold on customary terms in the U.S. commercial paper market on a private placement basis. The proceeds of the notes are used for general corporate purposes. As of May 2, 2025, the Company had no outstanding issuances under the commercial paper program.

[0001571996-25-000063:notes:112]
The Company may purchase, redeem, prepay, refinance, or otherwise retire any amount of outstanding indebtedness under the terms of such indebtedness at any time and from time to time, in open market or negotiated transactions with the holders of such indebtedness or otherwise, as considered appropriate in light of market conditions and other relevant factors.

[0001571996-25-000063:notes:113]
Covenants — The credit agreement governing the revolving credit facility and the indentures governing the Senior Notes and the Legacy Notes impose various limitations, subject to exceptions, on creating certain liens and entering into sale and lease-back transactions. The foregoing credit agreement and indentures contain customary events of default, and the revolving credit facility is subject to an interest coverage ratio covenant that is tested at the end of each fiscal quarter with respect to the Company’s preceding four fiscal quarters. The Company was in compliance with this financial covenant as of May 2, 2025.

[0001571996-25-000063:notes:114]
Aggregate Future Maturities

[0001571996-25-000063:notes:115]
The following table presents the aggregate future maturities of the Company’s debt as of May 2, 2025, excluding associated carrying value adjustments, for the periods indicated:

[0001571996-25-000063:notes:116]
|  | May 2, 2025 |
|  | (in millions) |
| Fiscal 2026 (remaining nine months) | $ | 4,106 |  |
| Fiscal 2027 | 7,180 |  |
| Fiscal 2028 | 1,696 |  |
| Fiscal 2029 | 2,470 |  |
| Fiscal 2030 | 3,053 |  |
| Thereafter | 10,526 |  |
| Total maturities, principal amount | $ | 29,031 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001571996-25-000063:notes:117]
[same as prior period, unchanged from 0001571996-24-000143:notes:135]

[0001571996-25-000063:notes:118]
[same as prior period, unchanged from 0001571996-24-000143:notes:136]

[0001571996-25-000063:notes:119]
[same as prior period, unchanged from 0001571996-24-000143:notes:137]

[0001571996-25-000063:notes:120]
[same as prior period, unchanged from 0001571996-24-000143:notes:138]

[0001571996-25-000063:notes:121]
During the three months ended May 2, 2025 and May 3, 2024, the Company did not discontinue any cash flow hedges related to foreign exchange contracts that had a material impact on the Company’s results of operations due to the probability that the forecasted cash flows would not occur.

[0001571996-25-000063:notes:122]
[same as prior period, unchanged from 0001571996-24-000143:notes:140]

[0001571996-25-000063:notes:123]
[same as prior period, unchanged from 0001571996-24-000143:notes:141]

[0001571996-25-000063:notes:124]
[same as prior period, unchanged from 0001571996-24-000143:notes:142]

[0001571996-25-000063:notes:125]
[same as prior period, unchanged from 0001571996-24-000143:notes:143]

[0001571996-25-000063:notes:126]
Interest rate swaps are utilized to manage the interest rate risk, at a portfolio level, associated with DFS operations in Europe. The interest rate swaps economically convert the fixed rate on financing receivables to a one-month or three-month Euribor floating rate in order to match the floating rate nature of the banks’ funding pool. The Company also uses interest rate swaps to manage the cash flows related to interest payments on Dell Bank senior unsecured eurobonds. The interest rate swaps economically convert the fixed rate on the Company’s bonds to a floating rate to match the underlying lease repayments profile. These contracts are not designated for hedge accounting and most expire within five years or less. See Note 4 of the Notes to the Condensed Consolidated Financial Statements for more information about the senior unsecured eurobonds.

[0001571996-25-000063:notes:127]
[same as prior period, unchanged from 0001571996-24-000143:notes:145]

[0001571996-25-000063:notes:128]
[same as prior period, unchanged from 0001571996-24-000143:notes:146]

[0001571996-25-000063:notes:129]
[same as prior period, unchanged from 0001571996-24-000143:notes:147]

[0001571996-25-000063:notes:130]
|  | May 2, 2025 |  | January 31, 2025 |
|  | (in millions) |
| Foreign exchange contracts: |  |  |  |
| Designated as cash flow hedging instruments | $ | 7,724 |  |  | $ | 5,965 |  |
| Non-designated as hedging instruments | 5,689 |  |  | 5,683 |  |
| Total | $ | 13,413 |  |  | $ | 11,648 |  |
| Interest rate contracts: |  |  |  |
| Non-designated as hedging instruments | $ | 6,437 |  |  | $ | 6,353 |  |

[0001571996-25-000063:notes:131]
[same as prior period, unchanged from 0001571996-24-000143:notes:149]

[0001571996-25-000063:notes:132]
| Derivatives in Cash Flow Hedging Relationships |  | Gain (Loss) Recognized in Accumulated OCI, Net of Tax, on Derivatives |  | Location of Gain (Loss) Reclassified from Accumulated OCI into Income |  | Gain (Loss) Reclassified from Accumulated OCI into Income |
|  |  | (in millions) |  |  |  | (in millions) |
| For the three months ended May 2, 2025: |
|  |  |  |  | Total net revenue |  | $ | (8) |  |
| Foreign exchange contracts |  | $ | (257) |  |  | Total cost of net revenue |  | (3) |  |
| Total |  | $ | (257) |  |  | Total |  | $ | (11) |  |
| For the three months ended May 3, 2024: |
|  |  |  |  | Total net revenue |  | $ | 18 |  |
| Foreign exchange contracts |  | $ | 87 |  |  | Total cost of net revenue |  | 1 |  |
| Total |  | $ | 87 |  |  | Total |  | $ | 19 |  |

[0001571996-25-000063:notes:133]
[same as prior period, unchanged from 0001571996-24-000143:notes:151]

[0001571996-25-000063:notes:134]
|  |  |  | Three Months Ended |  |  |
|  |  |  |  |  | May 2, 2025 |  | May 3, 2024 |  |  |  | Location of Gain (Loss) Recognized |
|  |  |  |  |  | (in millions) |  |  |
| Foreign exchange contracts |  |  |  |  | $ | 298 |  |  | $ | (71) |  |  |  |  | Interest and other, net |
| Interest rate contracts |  |  |  |  | (14) |  |  | 17 |  |  |  |  | Interest and other, net |
| Total |  |  |  |  | $ | 284 |  |  | $ | (54) |  |  |  |  |  |

[0001571996-25-000063:notes:135]
[same as prior period, unchanged from 0001571996-24-000143:notes:153]

[0001571996-25-000063:notes:136]
|  | May 2, 2025 |
|  | Other Current Assets |  | Other Non-Current Assets |  | Other Current Liabilities |  | Other Non-Current Liabilities |  | Total Fair Value |
|  | (in millions) |
| Derivatives designated as hedging instruments: |
| Foreign exchange contracts in an asset position | $ | 36 |  |  | $ | — |  |  | $ | 16 |  |  | $ | — |  |  | $ | 52 |  |
| Foreign exchange contracts in a liability position | (61) |  |  | — |  |  | (76) |  |  | — |  |  | (137) |  |
| Net asset (liability) | (25) |  |  | — |  |  | (60) |  |  | — |  |  | (85) |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts in an asset position | 516 |  |  | — |  |  | 48 |  |  | — |  |  | 564 |  |
| Foreign exchange contracts in a liability position | (193) |  |  | — |  |  | (172) |  |  | — |  |  | (365) |  |
| Interest rate contracts in an asset position | 1 |  |  | 58 |  |  | — |  |  | — |  |  | 59 |  |
| Interest rate contracts in a liability position | — |  |  | — |  |  | — |  |  | (51) |  |  | (51) |  |
| Net asset (liability) | 324 |  |  | 58 |  |  | (124) |  |  | (51) |  |  | 207 |  |
| Total derivatives at fair value | $ | 299 |  |  | $ | 58 |  |  | $ | (184) |  |  | $ | (51) |  |  | $ | 122 |  |
|  | January 31, 2025 |
|  | Other Current Assets |  | Other Non-Current Assets |  | Other Current Liabilities |  | Other Non-Current Liabilities |  | Total Fair Value |
|  | (in millions) |
| Derivatives designated as hedging instruments: |
| Foreign exchange contracts in an asset position | $ | 136 |  |  | $ | — |  |  | $ | 9 |  |  | $ | — |  |  | $ | 145 |  |
| Foreign exchange contracts in a liability position | (7) |  |  | — |  |  | (3) |  |  | — |  |  | (10) |  |
| Net asset (liability) | 129 |  |  | — |  |  | 6 |  |  | — |  |  | 135 |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts in an asset position | 430 |  |  | — |  |  | 53 |  |  | — |  |  | 483 |  |
| Foreign exchange contracts in a liability position | (297) |  |  | — |  |  | (90) |  |  | — |  |  | (387) |  |
| Interest rate contracts in an asset position | — |  |  | 40 |  |  | — |  |  | — |  |  | 40 |  |
| Interest rate contracts in a liability position | — |  |  | — |  |  | (1) |  |  | (43) |  |  | (44) |  |
| Net asset (liability) | 133 |  |  | 40 |  |  | (38) |  |  | (43) |  |  | 92 |  |
| Total derivatives at fair value | $ | 262 |  |  | $ | 40 |  |  | $ | (32) |  |  | $ | (43) |  |  | $ | 227 |  |

[0001571996-25-000063:notes:137]
[same as prior period, unchanged from 0001571996-24-000143:notes:155]

[0001571996-25-000063:notes:138]
|  | May 2, 2025 |
|  | Gross Amounts of Recognized Assets/(Liabilities) |  | Gross Amounts Offset in the Statement of Financial Position |  | Net Amounts of Assets/(Liabilities) Presented in the Statement of Financial Position |  | Gross Amounts not Offset in the Statement of Financial Position |  | Net Amount of Assets/ (Liabilities) Recognized in the Statement of Financial Position |
|  | Financial Instruments |  | Cash Collateral Received or Pledged |  |
|  | (in millions) |
| Derivative instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Financial assets | $ | 675 |  |  | $ | (318) |  |  | $ | 357 |  |  | $ | — |  |  | $ | (74) |  |  | $ | 283 |  |
| Financial liabilities | (553) |  |  | 318 |  |  | (235) |  |  | — |  |  | 3 |  |  | (232) |  |
| Total derivative instruments | $ | 122 |  |  | $ | — |  |  | $ | 122 |  |  | $ | — |  |  | $ | (71) |  |  | $ | 51 |  |
|  | January 31, 2025 |
|  | Gross Amounts of Recognized Assets/(Liabilities) |  | Gross Amounts Offset in the Statement of Financial Position |  | Net Amounts of Assets/(Liabilities) Presented in the Statement of Financial Position |  | Gross Amounts not Offset in the Statement of Financial Position |  | Net Amount of Assets/ (Liabilities) Recognized in the Statement of Financial Position |
|  | Financial Instruments |  | Cash Collateral Received or Pledged |  |
|  | (in millions) |
| Derivative instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Financial assets | $ | 668 |  |  | $ | (366) |  |  | $ | 302 |  |  | $ | — |  |  | $ | (36) |  |  | $ | 266 |  |
| Financial liabilities | (441) |  |  | 366 |  |  | (75) |  |  | — |  |  | 8 |  |  | (67) |  |
| Total derivative instruments | $ | 227 |  |  | $ | — |  |  | $ | 227 |  |  | $ | — |  |  | $ | (28) |  |  | $ | 199 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001571996-25-000063:notes:139]
[same as prior period, unchanged from 0001571996-24-000143:notes:157]

[0001571996-25-000063:notes:140]
The Infrastructure Solutions Group (“ISG”) and Client Solutions Group (“CSG”) reporting units are consistent with the reportable segments identified in Note 15 of the Notes to the Condensed Consolidated Financial Statements. The Company also has VMware Resale and Virtustream reporting units which are classified within Corporate and other, each of which is not classified as a reportable segment, and is not presented in the table below. Prior to the sale of Secureworks as discussed in Note 1 of the Notes to the Condensed Consolidated Financial Statements, Secureworks was also classified within Corporate and other. The sale of Secureworks was completed during the three months ended May 2, 2025 and was previously held for sale on the Condensed Consolidated Statements of Financial Position for the fiscal year ended January 31, 2025.

[0001571996-25-000063:notes:141]
[same as prior period, unchanged from 0001571996-24-000143:notes:159]

[0001571996-25-000063:notes:142]
|  | Infrastructure Solutions Group |  | Client Solutions Group |  |  |  | Total |
|  | (in millions) |
| Balances as of January 31, 2025 | $ | 14,888 |  |  | $ | 4,232 |  |  |  |  | $ | 19,120 |  |
| Impact of foreign currency translation | 195 |  |  | — |  |  |  |  | 195 |  |
| Balances as of May 2, 2025 | $ | 15,083 |  |  | $ | 4,232 |  |  |  |  | $ | 19,315 |  |

[0001571996-25-000063:notes:143]
[same as prior period, unchanged from 0001571996-24-000143:notes:162]

[0001571996-25-000063:notes:144]
[same as prior period, unchanged from 0001571996-24-000143:notes:163]

[0001571996-25-000063:notes:145]
|  | May 2, 2025 |  | January 31, 2025 |
|  | Gross |  | AccumulatedAmortization |  | Net |  | Gross |  | AccumulatedAmortization |  | Net |
|  | (in millions) |
| Customer relationships | $ | 16,643 |  |  | $ | (15,090) |  |  | $ | 1,553 |  |  | $ | 16,642 |  |  | $ | (15,013) |  |  | $ | 1,629 |  |
| Developed technology | 9,500 |  |  | (9,252) |  |  | 248 |  |  | 9,500 |  |  | (9,211) |  |  | 289 |  |
| Trade names | 875 |  |  | (863) |  |  | 12 |  |  | 875 |  |  | (860) |  |  | 15 |  |
| Definite-lived intangible assets | 27,018 |  |  | (25,205) |  |  | 1,813 |  |  | 27,017 |  |  | (25,084) |  |  | 1,933 |  |
| Indefinite-lived trade names | 3,055 |  |  | — |  |  | 3,055 |  |  | 3,055 |  |  | — |  |  | 3,055 |  |
| Total intangible assets | $ | 30,073 |  |  | $ | (25,205) |  |  | $ | 4,868 |  |  | $ | 30,072 |  |  | $ | (25,084) |  |  | $ | 4,988 |  |

[0001571996-25-000063:notes:146]
Amortization expense related to definite-lived intangible assets was $0.1 billion and $0.2 billion for the three months ended May 2, 2025 and May 3, 2024, respectively. There were no material impairment charges related to intangible assets during the three months ended May 2, 2025 and May 3, 2024.

[0001571996-25-000063:notes:147]
[same as prior period, unchanged from 0001571996-24-000143:notes:166]

[0001571996-25-000063:notes:148]
|  | May 2, 2025 |
|  | (in millions) |
| Fiscal 2026 (remaining nine months) | $ | 360 |  |
| Fiscal 2027 | 372 |  |
| Fiscal 2028 | 230 |  |
| Fiscal 2029 | 190 |  |
| Fiscal 2030 | 153 |  |
| Thereafter | 508 |  |
| Total | $ | 1,813 |  |

[0001571996-25-000063:notes:149]
[same as prior period, unchanged from 0001571996-24-000143:notes:168]

[0001571996-25-000063:notes:150]
[same as prior period, unchanged from 0001571996-24-000143:notes:169]

[0001571996-25-000063:notes:151]
For the annual impairment review of the ISG and CSG reporting units during the third quarter of Fiscal 2025, the Company elected to bypass the assessment of qualitative factors to determine whether it was more likely than not that the fair value of a reporting unit was less than its carrying amount, including goodwill. In electing to bypass the qualitative assessment, the Company proceeded directly to perform a quantitative goodwill impairment test to measure the fair value of each goodwill reporting unit relative to its carrying amount, and to determine the amount of goodwill impairment loss to be recognized, if any. For the remaining reporting units, the Company performed a qualitative assessment of goodwill at the reporting unit level. The qualitative assessment included consideration of the relevant events and circumstances affecting the reporting unit, including macroeconomic, industry and market conditions, overall financial performance, and trends in the public company market valuation, where applicable. Additionally, Secureworks’ entry into an agreement pursuant to which it was acquired in an all-cash transaction for approximately $0.9 billion, as discussed in Note 1 of the Notes to the Condensed Consolidated Financial Statements, provided an indication that the fair value of the Secureworks reporting unit exceeded its carrying value.

[0001571996-25-000063:notes:152]
[same as prior period, unchanged from 0001571996-24-000143:notes:171]

[0001571996-25-000063:notes:153]
[same as prior period, unchanged from 0001571996-24-000143:notes:172]

[0001571996-25-000063:notes:154]
Based on the results of the annual impairment test performed during Fiscal 2025, the fair values of each of the reporting units and indefinite-lived intangibles exceeded their carrying values. No goodwill or indefinite-lived assets impairment test was performed during the three months ended May 2, 2025.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001571996-25-000063:notes:155]
[same as prior period, unchanged from 0001571996-24-000143:notes:174]

[0001571996-25-000063:notes:156]
[same as prior period, unchanged from 0001571996-24-000143:notes:175]

[0001571996-25-000063:notes:157]
|  |  |  | Three Months Ended |
|  |  |  |  |  | May 2, 2025 |  | May 3, 2024 |
|  |  |  |  |  | (in millions) |
| Deferred revenue: |  |  |  |  |  |  |  |
| Deferred revenue at beginning of period |  |  |  |  | $ | 25,965 |  |  | $ | 29,145 |  |
| Revenue deferrals |  |  |  |  | 5,455 |  |  | 4,469 |  |
| Revenue recognized |  |  |  |  | (5,100) |  |  | (5,464) |  |
| Deferred revenue at end of period |  |  |  |  | $ | 26,320 |  |  | $ | 28,150 |  |
| Short-term deferred revenue |  |  |  |  | $ | 13,907 |  |  | $ | 15,034 |  |
| Long-term deferred revenue |  |  |  |  | $ | 12,413 |  |  | $ | 13,116 |  |

[0001571996-25-000063:notes:158]
Remaining Performance Obligations — Remaining performance obligations represent the aggregate amount of the transaction price allocated to performance obligations not delivered, or partially undelivered, as of the end of the reporting period. Remaining performance obligations include deferred revenue plus unbilled amounts not yet recorded in deferred revenue. The value of the transaction price allocated to remaining performance obligations as of May 2, 2025 was approximately $49 billion. The Company expects to recognize approximately 67% of remaining performance obligations as revenue in the next twelve months, 16% in the following twelve months, and the remainder thereafter.

[0001571996-25-000063:notes:159]
[same as prior period, unchanged from 0001571996-24-000143:notes:179]

[0001571996-25-000063:notes:160]
[same as prior period, unchanged from 0001571996-24-000143:notes:180]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001571996-25-000063:notes:161]
COMMITMENTS AND CONTINGENCIES 
Purchase Obligations

[0001571996-25-000063:notes:162]
The Company has contractual obligations to purchase goods or services, which specify significant terms (including fixed or minimum quantities to be purchased), fixed, minimum, or variable price provisions, and the approximate timing of the transaction. Purchase obligations are primarily related to commitments with suppliers and software maintenance and support services. As of May 2, 2025, such purchase obligations were $5.6 billion for the remainder of Fiscal 2026, $0.6 billion for Fiscal 2027, and $1.2 billion for Fiscal 2028 and thereafter.

[0001571996-25-000063:notes:163]
Legal Matters

[0001571996-25-000063:notes:164]
The Company is involved in various claims, suits, assessments, investigations, and legal proceedings that arise from time to time in the ordinary course of its business, consisting of matters involving consumer, antitrust, tax, intellectual property, and other issues on a global basis.

[0001571996-25-000063:notes:165]
The Company accrues a liability when it believes that it is both probable that a liability has been incurred and that it can reasonably estimate the amount of the loss. The Company reviews these accruals at least quarterly and adjusts them to reflect ongoing negotiations, settlements, rulings, advice of legal counsel, and other relevant information. To the extent new information is obtained and the Company’s views on the probable outcomes of claims, suits, assessments, investigations, or legal proceedings change, changes in the Company’s accrued liabilities are recorded in the period in which such a determination is made. For some matters, the incurrence of a liability is not probable or the amount cannot be reasonably estimated and therefore accruals have not been made. As of May 2, 2025, the Company does not currently anticipate that any of the legal proceedings it is involved in will have a material adverse effect on its business, financial condition, results of operations, or cash flows.

[0001571996-25-000063:notes:166]
In accordance with the relevant accounting guidance, the Company provides disclosures of matters where it is at least reasonably possible that the Company could experience a material loss exceeding the amounts already accrued for across all proceedings or matters. In addition, the Company also discloses matters based on its consideration of other matters and qualitative factors, including the experience of other companies in the industry, and investor, customer, and employee relations considerations. As of May 2, 2025, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for across all proceedings or matters has been incurred. However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company’s business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters. Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company’s business, financial condition, results of operations, or cash flows will depend on a number of factors, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.

[0001571996-25-000063:notes:167]
Indemnifications Obligations

[0001571996-25-000063:notes:168]
In the ordinary course of business, the Company enters into various contracts under which it may agree to indemnify other parties for losses incurred from certain events as defined in the relevant contract, such as litigation, regulatory penalties, or claims relating to past performance. Such indemnification obligations may not be subject to maximum loss clauses. Historically, payments related to these indemnification obligations have not been material to the Company.

[0001571996-25-000063:notes:169]
Under the Separation and Distribution Agreement entered into with VMware, Inc. upon completion of its spin-off of VMware, Inc. on November 1, 2021, Dell Technologies agreed to indemnify VMware, Inc., each of its subsidiaries and each of their respective directors, officers, employees, as well as any successors and assigns of the foregoing, from and against all liabilities relating to, arising out of or resulting from, among other matters, the liabilities allocated to Dell Technologies as part of the separation of Dell Technologies and VMware, Inc. (currently operating under the name VMware LLC, and individually and together with its subsidiaries, “VMware”) and their respective businesses (the “Separation”). VMware similarly agreed to indemnify Dell Technologies Inc., each of its subsidiaries and each of their respective directors, officers, and employees from and against all liabilities relating to, arising out of or resulting from, among other matters, the liabilities allocated to VMware as part of the Separation. The amounts that VMware and Dell Technologies may be obligated to pay each other could vary depending on the outcome of certain unresolved tax matters, which may not be resolved for several years. Net income tax indemnification receivables from VMware were immaterial as of May 2, 2025 and January 31, 2025.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001571996-25-000063:notes:170]
INCOME AND OTHER TAXES
For the three months ended May 2, 2025, the Company’s effective income tax rate was 10.9% on pre-tax income of $1.1 billion compared to (67.6)% on pre-tax income of $0.6 billion for the three months ended May 3, 2024. The changes in the Company’s effective income tax rate were primarily driven by discrete tax items. For the three months ended May 2, 2025, the Company recorded discrete tax benefits of $0.1 billion related to stock-based compensation. For the three months ended May 3, 2024, the Company recorded discrete tax benefits of $0.4 billion related to changes in uncertain tax benefits resulting from the expiration of certain U.S. statutes of limitations and $0.2 billion related to stock-based compensation.

[0001571996-25-000063:notes:171]
The differences between the estimated effective income tax rates and the U.S. federal statutory rate of 21% principally result from the geographical distribution of income, differences between the book and tax treatment of certain items, and discrete tax items. In certain jurisdictions, the Company’s tax rate is significantly less than the applicable statutory rate as a result of tax holidays. The majority of the Company’s foreign income subject to these tax holidays and lower tax rates is attributable to Singapore and China. As of May 2, 2025, the Company was not aware of any matters of non-compliance related to these tax holidays.

[0001571996-25-000063:notes:172]
In June 2023, the Company received a Revenue Agent’s Report for the federal income tax examination by the Internal Revenue Service (“IRS”) of fiscal years 2018 through 2019. The IRS proposed adjustments primarily relating to certain transactions the Company completed as part of its business integration efforts. In August 2023, the Company submitted a written protest to the IRS relating to certain assessments. The Company received a rebuttal from the IRS to its written protest in April 2024. The Company disagrees with the IRS’s proposed adjustments and will contest them through the IRS administrative appeals procedures. The Company anticipates that the appeals process for the resolution of these matters will extend beyond the next twelve months. The IRS is also currently conducting a federal income tax examination of fiscal years 2020 through 2022.

[0001571996-25-000063:notes:173]
The Company is also currently under income tax audits in various U.S. state and foreign taxing jurisdictions. The Company is undergoing negotiations, and in some cases contested proceedings, relating to tax matters with the taxing authorities in these jurisdictions. With respect to major U.S. state and foreign taxing jurisdictions, the Company is generally not subject to tax examinations for years prior to the fiscal year ended February 2, 2018.

[0001571996-25-000063:notes:174]
The Company believes that it has provided adequate reserves related to all income tax matters contained in tax periods open to examination, including the IRS audits described above. Although the Company believes it has made adequate provisions for the uncertainties with respect to these audits, should the Company experience unfavorable outcomes, such outcomes could have a material impact on its results of operations, financial position, and cash flows.

[0001571996-25-000063:notes:175]
Judgment is required in evaluating the Company’s uncertain tax positions and determining the Company’s provision for income taxes. Net unrecognized tax benefits were $1.0 billion and $0.9 billion as of May 2, 2025 and January 31, 2025, respectively, and are included in other non-current liabilities in the Condensed Consolidated Statements of Financial Position. The Company does not anticipate a significant change to the total amount of unrecognized tax benefits within the next twelve months.

[0001571996-25-000063:notes:176]
The Company takes certain non-income tax positions in the jurisdictions in which it operates and has received certain non-income tax assessments from various jurisdictions. The Company believes that a material loss in these matters is not probable and that it is not reasonably possible that a material loss exceeding amounts already accrued has been incurred. The Company believes its positions in these non-income tax litigation matters are supportable and that it ultimately will prevail in the matters. In the normal course of business, the Company’s positions and conclusions related to its non-income taxes could be challenged and assessments may be made. To the extent new information is obtained and the Company’s views on its positions, probable outcomes of assessments, or litigation change, changes in estimates to the Company’s accrued liabilities would be recorded in the period in which such a determination is made. In the resolution process for income tax and non-income tax audits, the Company is required in certain situations to provide collateral guarantees or indemnification to regulators and tax authorities until the matter is resolved.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001571996-25-000063:notes:177]
[same as prior period, unchanged from 0001571996-24-000143:notes:202]

[0001571996-25-000063:notes:178]
[same as prior period, unchanged from 0001571996-24-000143:notes:203]

[0001571996-25-000063:notes:179]
|  | Foreign Currency Translation Adjustments |  |  |  | Cash Flow Hedges |  | Pension and Other Postretirement Plans |  | Accumulated Other Comprehensive Income (Loss) |
|  | (in millions) |
| Balances as of January 31, 2025 | $ | (1,023) |  |  |  |  | $ | 105 |  |  | $ | (21) |  |  | $ | (939) |  |
| Other comprehensive income (loss) before reclassifications | 252 |  |  |  |  | (257) |  |  | (1) |  |  | (6) |  |
| Amounts reclassified from accumulated other comprehensive income (loss) | — |  |  |  |  | 11 |  |  | — |  |  | 11 |  |
| Sale of Secureworks (a) | 8 |  |  |  |  | — |  |  | — |  |  | 8 |  |
| Total change for the period | 260 |  |  |  |  | (246) |  |  | (1) |  |  | 13 |  |
| Balances as of May 2, 2025 | $ | (763) |  |  |  |  | $ | (141) |  |  | $ | (22) |  |  | $ | (926) |  |

[0001571996-25-000063:notes:180]
(a)See Note 1 of the Notes to the Condensed Consolidated Financial Statements for more information about the sale of Secureworks.

[0001571996-25-000063:notes:181]
[same as prior period, unchanged from 0001571996-24-000143:notes:205]

[0001571996-25-000063:notes:182]
[same as prior period, unchanged from 0001571996-24-000143:notes:206]

[0001571996-25-000063:notes:183]
|  |  |  | Three Months Ended |
|  |  |  | May 2, 2025 |  | May 3, 2024 |  |  |
|  |  |  | Cash Flow Hedges |  |  |  |  |  | Pensions |  |  |  | Total |  | Cash Flow Hedges |  | Pensions |  | Total |  |  |  |  |  |  |
|  |  |  | (in millions) |
| Total reclassifications, net of tax: |  |  |  |  |  |  |
| Net revenue |  |  | $ | (8) |  |  |  |  |  |  | $ | — |  |  |  |  | $ | (8) |  |  | $ | 18 |  |  | $ | — |  |  | $ | 18 |  |  |  |  |  |  |  |
| Cost of net revenue |  |  | (3) |  |  |  |  |  |  | — |  |  |  |  | (3) |  |  | 1 |  |  | — |  |  | 1 |  |  |  |  |  |  |  |
| Operating expenses |  |  | — |  |  |  |  |  |  | — |  |  |  |  | — |  |  | — |  |  | 1 |  |  | 1 |  |  |  |  |  |  |  |
| Total reclassifications, net of tax |  |  | $ | (11) |  |  |  |  |  |  | $ | — |  |  |  |  | $ | (11) |  |  | $ | 19 |  |  | $ | 1 |  |  | $ | 20 |  |  |  |  |  |  |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001571996-25-000063:notes:184]
[same as prior period, unchanged from 0001571996-24-000143:notes:209]

[0001571996-25-000063:notes:185]
|  | Authorized |  | Issued |  | Outstanding |
|  | (in millions) |
| Common stock as of May 2, 2025 |
| Class A | 600 |  |  | 277 |  |  | 277 |  |
| Class B | 200 |  |  | 62 |  |  | 62 |  |
| Class C | 7,900 |  |  | 504 |  |  | 344 |  |
| Class D | 100 |  |  | — |  |  | — |  |
|  | 8,800 |  |  | 843 |  |  | 683 |  |
| Common stock as of January 31, 2025 |
| Class A | 600 |  |  | 277 |  |  | 277 |  |
| Class B | 200 |  |  | 62 |  |  | 62 |  |
| Class C | 7,900 |  |  | 495 |  |  | 357 |  |
| Class D | 100 |  |  | — |  |  | — |  |
|  | 8,800 |  |  | 834 |  |  | 696 |  |

[0001571996-25-000063:notes:186]
[same as prior period, unchanged from 0001571996-24-000143:notes:211]

[0001571996-25-000063:notes:187]
The Company is authorized to issue one million shares of preferred stock, par value $0.01 per share. As of May 2, 2025 and January 31, 2025, no shares of preferred stock were issued or outstanding.

[0001571996-25-000063:notes:188]
[same as prior period, unchanged from 0001571996-24-000143:notes:213]

[0001571996-25-000063:notes:189]
[same as prior period, unchanged from 0001571996-24-000143:notes:214]

[0001571996-25-000063:notes:190]
[same as prior period, unchanged from 0001571996-24-000143:notes:215]

[0001571996-25-000063:notes:191]
[same as prior period, unchanged from 0001571996-24-000143:notes:216]

[0001571996-25-000063:notes:192]
During the three months ended May 2, 2025, there were no conversions of shares of Class A Common Stock or Class B Common Stock into shares of Class C Common Stock. During the fiscal year ended January 31, 2025, the Company issued 100 million shares of Class C Common Stock to stockholders upon the conversion of 76 million shares of Class A Common Stock and 24 million shares of Class B Common Stock in accordance with the Company’s certificate of incorporation.

[0001571996-25-000063:notes:193]
[same as prior period, unchanged from 0001571996-24-000143:notes:218]

[0001571996-25-000063:notes:194]
On February 27, 2025, the Company announced that the Board of Directors approved an 18% increase in the quarterly dividend rate to $0.525 per share per fiscal quarter beginning in the first quarter of Fiscal 2026.

[0001571996-25-000063:notes:195]
[same as prior period, unchanged from 0001571996-24-000143:notes:220]

[0001571996-25-000063:notes:196]
|  |  | Declaration Date |  | Record Date |  | Payment Date |  | Dividend per Share |  | Amount (in millions) |
|  |  | Fiscal 2026 |
|  |  | February 27, 2025 |  | April 22, 2025 |  | May 2, 2025 |  | $ | 0.525 |  |  | $ | 360 |  |
|  |  | Fiscal 2025 |
|  |  | February 29, 2024 |  | April 23, 2024 |  | May 3, 2024 |  | $ | 0.445 |  |  | $ | 316 |  |

[0001571996-25-000063:notes:197]
During the three months ended May 2, 2025 and May 3, 2024, the Company also paid an immaterial amount of dividend equivalents on eligible vested equity awards which are not included above.

[0001571996-25-000063:notes:198]
[same as prior period, unchanged from 0001571996-24-000143:notes:223]

[0001571996-25-000063:notes:199]
On September 23, 2021, the Company’s Board of Directors approved the Company’s current stock repurchase program with no fixed expiration date under which the Company was authorized to repurchase up to $5 billion of shares of Class C Common Stock, exclusive of any fees, commissions, or other expenses related to such repurchases. On October 5, 2023 and February 27, 2025, the Company’s Board of Directors authorized additional shares for repurchase under the program of $5 billion and $10 billion, respectively. Following the February 27, 2025 approval, the Company had approximately $11.5 billion of authorized shares remaining under the program.

[0001571996-25-000063:notes:200]
During the three months ended May 2, 2025, the Company repurchased approximately 22 million shares of Class C Common Stock for a total purchase price of approximately $2.0 billion. During the three months ended May 3, 2024, the Company repurchased approximately 7 million shares of Class C Common Stock for a total purchase price of approximately $0.7 billion. 
The above repurchases of Class C Common Stock exclude U.S. federal excise taxes and shares withheld from stock awards to settle employee tax withholding obligations related to the vesting of such awards.


## us-gaap:EarningsPerShareTextBlock

[0001571996-25-000063:notes:201]
[same as prior period, unchanged from 0001571996-24-000143:notes:227]

[0001571996-25-000063:notes:202]
[same as prior period, unchanged from 0001571996-24-000143:notes:228]

[0001571996-25-000063:notes:203]
|  | Three Months Ended |  |  |
|  | May 2, 2025 |  | May 3, 2024 |  |  |  |  |  |  |
| Earnings per share attributable to Dell Technologies Inc. |  |  |
| Dell Technologies Common Stock — Basic | $ | 1.39 |  |  | $ | 1.41 |  |  |  |  |  |  |  |
| Dell Technologies Common Stock — Diluted | $ | 1.37 |  |  | $ | 1.37 |  |  |  |  |  |  |  |

[0001571996-25-000063:notes:204]
[same as prior period, unchanged from 0001571996-24-000143:notes:230]

[0001571996-25-000063:notes:205]
|  | Three Months Ended |  |  |
|  | May 2, 2025 |  | May 3, 2024 |  |  |  |  |  |  |
|  | (in millions) |
| Numerator: Dell Technologies Common Stock |  |  |  |  |  |  |  |  |  |
| Net income attributable to Dell Technologies Inc. — basic and diluted | $ | 965 |  |  | $ | 997 |  |  |  |  |  |  |  |
| Denominator: Dell Technologies Common Stock weighted-average shares outstanding |  |  |  |  |  |  |  |  |  |
| Weighted-average shares outstanding — basic | 692 |  |  | 708 |  |  |  |  |  |  |  |
| Dilutive effect of equity awards | 10 |  |  | 19 |  |  |  |  |  |  |  |
| Weighted-average shares outstanding — diluted | 702 |  |  | 727 |  |  |  |  |  |  |  |
| Weighted-average shares outstanding — antidilutive | 4 |  |  | — |  |  |  |  |  |  |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001571996-25-000063:notes:206]
SEGMENT INFORMATION 
The Company reports its financial results through two reportable segments which are based on the following business units: Infrastructure Solutions Group (“ISG”) and Client Solutions Group (“CSG”). The Company organizes its reportable segments based on the manner in which management evaluates the performance of the Company.

[0001571996-25-000063:notes:207]
The Company’s Chief Executive Officer is the Chief Operating Decision Maker (“CODM”). The CODM is regularly provided and reviews segment revenue and segment operating income to assess the performance of each segment and allocate resources to the segments in the annual planning process. The Company’s measure of segment revenue and segment operating income for management reporting purposes excludes Corporate and other, amortization of intangible assets, stock-based compensation expense, and other corporate expenses, as applicable, which are not used in evaluating the results of, or in allocating resources to, the segments. The Company does not allocate assets to the above reportable segments for internal reporting purposes. Additionally, the accounting policies of the segments are the same as those described in Note 2 to the Company’s Annual Report on Form 10-K for the fiscal year ended January 31, 2025.

[0001571996-25-000063:notes:208]
ISG includes the Company’s servers and networking offerings and storage offerings. The Company’s server portfolio includes high-performance general-purpose and AI-optimized servers. The Company’s networking portfolio includes wide area network infrastructure, data center and edge networking switches, and cables and optics. The Company’s comprehensive storage portfolio includes modern and traditional storage solutions, including all-flash arrays, scale-out file, object platforms, hyper-converged infrastructure, and software-defined storage. ISG also offers software, peripherals, and services, including consulting and support and deployment.

[0001571996-25-000063:notes:209]
CSG includes the Company’s commercial offerings and consumer offerings. The Company’s CSG portfolio includes branded PCs, including notebooks, desktops, and workstations and branded peripherals that include displays, docking stations, keyboards, mice, and webcam and audio devices, as well as third-party software and peripherals. CSG also includes services offerings, such as configuration, support and deployment, and extended warranties.

[0001571996-25-000063:notes:210]
On March 25, 2024, the Company terminated the Commercial Framework Agreement with VMware, whereby Dell Technologies acted as a distributor of Broadcom Inc.’s VMware stand-alone products and services and purchased such products and services for resale to end-user customers (“VMware Resale”). Dell Technologies no longer acts as a distributor of such products and services, although it continues to support customers that have purchased resale offerings sold in prior periods. The results of VMware Resale transactions are reflected in Corporate and other. The Company continues to integrate and embed certain VMware products and services with the Company’s VxRail solution to end-user customers. The results for this integrated offering are reflected within ISG.

[0001571996-25-000063:notes:211]
[same as prior period, unchanged from 0001571996-24-000143:notes:250]

[0001571996-25-000063:notes:212]
|  |  |  | Three Months Ended |
|  |  |  |  |  | May 2, 2025 |  | May 3, 2024 |  |  |
|  |  |  |  |  | (in millions) |
| Consolidated net revenue: |  |  |  |  |  |  |  |  |  |
| Infrastructure Solutions Group |  |  |  |  | $ | 10,317 |  |  | $ | 9,227 |  |  |  |
| Client Solutions Group |  |  |  |  | 12,509 |  |  | 11,967 |  |  |  |
| Reportable segment net revenue |  |  |  |  | 22,826 |  |  | 21,194 |  |  |  |
| Corporate and other (a) |  |  |  |  | 552 |  |  | 1,050 |  |  |  |
| Total consolidated net revenue |  |  |  |  | $ | 23,378 |  |  | $ | 22,244 |  |  |  |
| Consolidated operating income: |  |  |  |  |  |  |  |  |  |
| Infrastructure Solutions Group |  |  |  |  | $ | 998 |  |  | $ | 736 |  |  |  |
| Client Solutions Group |  |  |  |  | 653 |  |  | 777 |  |  |  |
| Reportable segment operating income (b) |  |  |  |  | 1,651 |  |  | 1,513 |  |  |  |
| Corporate and other (a) |  |  |  |  | 15 |  |  | 6 |  |  |  |
| Amortization of intangibles (c) |  |  |  |  | (126) |  |  | (168) |  |  |  |
| Stock-based compensation expense (d) |  |  |  |  | (190) |  |  | (210) |  |  |  |
| Other corporate expenses (e) |  |  |  |  | (185) |  |  | (176) |  |  |  |
| Total consolidated operating income (f) |  |  |  |  | $ | 1,165 |  |  | $ | 965 |  |  |  |

[0001571996-25-000063:notes:213]
(a)Corporate and other consists of results of divested businesses or non-reportable segments whose offerings are no longer actively sold, including (i) VMware Resale, (ii) Secureworks, and (iii) Virtustream, and do not meet the requirements for a reportable segment, either individually or collectively. Additionally, Corporate and other includes other items that are managed at the corporate level and are not allocated to reportable segments.

[0001571996-25-000063:notes:214]
(b)Depreciation expense directly attributable to each reportable segment is included in the operating results of each segment. However, the CODM does not evaluate depreciation expense by operating segment, and therefore such expense is not separately presented.

[0001571996-25-000063:notes:215]
(c)Amortization of intangibles includes non-cash purchase accounting adjustments that are primarily related to the acquisition by merger of EMC Corporation.

[0001571996-25-000063:notes:216]
[same as prior period, unchanged from 0001571996-24-000143:notes:255]

[0001571996-25-000063:notes:217]
(e)Other corporate expenses includes severance expenses, payroll taxes associated with stock-based compensation, incentive charges related to equity investments, facility action costs, transaction-related expenses, and impairment charges.

[0001571996-25-000063:notes:218]
(f)Income and expenses within interest and other, net, is not allocated to the reportable segments. Therefore, the Company only reports to reportable segment operating income.

[0001571996-25-000063:notes:219]
The following table presents the significant expense categories by reportable segment for the periods indicated:

[0001571996-25-000063:notes:220]
|  |  |  | Three Months Ended |
|  |  |  |  |  | May 2, 2025 |  | May 3, 2024 |  |  |
|  |  |  |  |  | (in millions) |
| Infrastructure Solutions Group: |  |  |  |  |  |  |  |  |  |
| Cost of net revenue |  |  |  |  | $ | 7,050 |  |  | $ | 6,204 |  |  |  |
| Selling, general, and administrative |  |  |  |  | $ | 1,695 |  |  | $ | 1,759 |  |  |  |
| Research and development |  |  |  |  | $ | 574 |  |  | $ | 528 |  |  |  |
| Client Solutions Group: |  |  |  |  |  |  |  |  |  |
| Cost of net revenue |  |  |  |  | $ | 10,738 |  |  | $ | 10,115 |  |  |  |
| Selling, general, and administrative |  |  |  |  | $ | 982 |  |  | $ | 961 |  |  |  |
| Research and development |  |  |  |  | $ | 136 |  |  | $ | 114 |  |  |  |

[0001571996-25-000063:notes:221]
[same as prior period, unchanged from 0001571996-24-000143:notes:257]

[0001571996-25-000063:notes:222]
|  |  |  | Three Months Ended |
|  |  |  |  |  | May 2, 2025 |  | May 3, 2024 |  |  |
|  |  |  |  |  | (in millions) |
| Net revenue: |  |  |  |  |  |  |  |  |  |
| Infrastructure Solutions Group: |  |  |  |  |  |  |  |  |  |
| Servers and networking |  |  |  |  | $ | 6,321 |  |  | $ | 5,466 |  |  |  |
| Storage |  |  |  |  | 3,996 |  |  | 3,761 |  |  |  |
| Total ISG net revenue |  |  |  |  | $ | 10,317 |  |  | $ | 9,227 |  |  |  |
| Client Solutions Group: |  |  |  |  |  |  |  |  |  |
| Commercial |  |  |  |  | $ | 11,046 |  |  | $ | 10,154 |  |  |  |
| Consumer |  |  |  |  | 1,463 |  |  | 1,813 |  |  |  |
| Total CSG net revenue |  |  |  |  | $ | 12,509 |  |  | $ | 11,967 |  |  |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001571996-25-000063:notes:223]
[same as prior period, unchanged from 0001571996-24-000143:notes:259]

[0001571996-25-000063:notes:224]
|  | May 2, 2025 |  | January 31, 2025 |
|  | (in millions) |
| Cash, cash equivalents, and restricted cash: |  |  |  |
| Cash and cash equivalents | $ | 7,700 |  |  | $ | 3,633 |  |
| Cash and cash equivalents — held for sale (a) | — |  |  | 62 |  |
| Restricted cash (b) | 153 |  |  | 124 |  |
| Total cash, cash equivalents, and restricted cash | $ | 7,853 |  |  | $ | 3,819 |  |
| Inventories: |  |  |  |
| Production materials | $ | 5,245 |  |  | $ | 4,432 |  |
| Work-in-process | 1,229 |  |  | 1,128 |  |
| Finished goods | 941 |  |  | 1,156 |  |
| Total inventories | $ | 7,415 |  |  | $ | 6,716 |  |
| Deferred costs: |  |  |  |
| Total deferred costs, current (c) | $ | 3,854 |  |  | $ | 4,129 |  |
| Contract manufacturers' receivables: |  |  |  |
| Total contract manufacturers' receivables (d) | $ | 3,850 |  |  | $ | 731 |  |
| Property, plant, and equipment, net: |  |  |  |
| Assets in a customer contract | $ | 5,559 |  |  | $ | 5,204 |  |
| Computer and other equipment | 3,744 |  |  | 3,651 |  |
| Land and buildings | 2,894 |  |  | 2,838 |  |
| Internal use software | 2,451 |  |  | 2,403 |  |
| Total property, plant, and equipment | 14,648 |  |  | 14,096 |  |
| Accumulated depreciation and amortization | (8,265) |  |  | (7,760) |  |
| Total property, plant, and equipment, net | $ | 6,383 |  |  | $ | 6,336 |  |

[0001571996-25-000063:notes:225]
(a)Held for sale represents the reclassification of Secureworks cash and cash equivalents to assets held for sale as of January 31, 2025. See Note 1 of the Notes to the Condensed Consolidated Financial Statements for more information about the sale of Secureworks.

[0001571996-25-000063:notes:226]
(b)Restricted cash is primarily classified as other current assets in the Condensed Consolidated Statements of Financial Position and consists predominantly of cash required to be held in escrow pursuant to DFS securitization arrangements.

[0001571996-25-000063:notes:227]
(c)Deferred costs are included in other current assets in the Condensed Consolidated Statements of Financial Position. Amounts classified as long-term deferred costs are included in other non-current assets and are not disclosed above.

[0001571996-25-000063:notes:228]
(d)Contract manufacturers’ receivables are classified as other current assets in the Condensed Consolidated Statements of Financial Position and consist of sales of components to contract manufacturers to manufacture or assemble the Company’s products. The Company has agreements with the majority of contract manufacturers that permit net settlement mitigating the credit risk wholly or in part. During the three months ended May 2, 2025, the portion of receivables not offset increased primarily due to the timing of the sale of components to one contract manufacturer and the corresponding purchase of assembled products.

[0001571996-25-000063:notes:229]
[same as prior period, unchanged from 0001571996-24-000143:notes:264]

[0001571996-25-000063:notes:230]
[same as prior period, unchanged from 0001571996-24-000143:notes:265]

[0001571996-25-000063:notes:231]
|  |  |  | Three Months Ended |
|  |  |  |  |  | May 2, 2025 |  | May 3, 2024 |  |  |
|  |  |  |  |  | (in millions) |
| Warranty liability: |  |  |  |  |  |  |  |  |  |
| Warranty liability at beginning of period |  |  |  |  | $ | 424 |  |  | $ | 426 |  |  |  |
| Costs accrued for new warranty contracts and changes in estimates for pre-existing warranties (a) |  |  |  |  | 211 |  |  | 229 |  |  |  |
| Service obligations honored |  |  |  |  | (220) |  |  | (229) |  |  |  |
| Warranty liability at end of period (b) |  |  |  |  | $ | 415 |  |  | $ | 426 |  |  |  |

[0001571996-25-000063:notes:232]
(a)Changes in cost estimates related to pre-existing warranties are aggregated with accruals for new standard warranty contracts. The Company’s warranty liability process does not differentiate between estimates made for pre-existing warranties and those made for new warranty obligations.

[0001571996-25-000063:notes:233]
(b)The liabilities for standard warranties are included in accrued and other and in non-current liabilities in the Condensed Consolidated Statements of Financial Position.

[0001571996-25-000063:notes:234]
[same as prior period, unchanged from 0001571996-24-000143:notes:268]

[0001571996-25-000063:notes:235]
[same as prior period, unchanged from 0001571996-24-000143:notes:269]

[0001571996-25-000063:notes:236]
[same as prior period, unchanged from 0001571996-24-000143:notes:270]

[0001571996-25-000063:notes:237]
|  |  |  | Three Months Ended |
|  |  |  |  |  | May 2, 2025 |  | May 3, 2024 |  |  |
|  |  |  |  |  | (in millions) |
| Severance liability: |  |  |  |  |  |  |  |  |  |
| Severance liability at beginning of period |  |  |  |  | $ | 238 |  |  | $ | 352 |  |  |  |
| Severance charges |  |  |  |  | 130 |  |  | 92 |  |  |  |
| Cash paid and other |  |  |  |  | (217) |  |  | (250) |  |  |  |
| Severance liability at end of period |  |  |  |  | $ | 151 |  |  | $ | 194 |  |  |  |

[0001571996-25-000063:notes:238]
[same as prior period, unchanged from 0001571996-24-000143:notes:272]

[0001571996-25-000063:notes:239]
|  |  |  | Three Months Ended |
|  |  |  |  |  | May 2, 2025 |  | May 3, 2024 |  |  |
|  |  |  |  |  | (in millions) |
| Severance charges: |  |  |  |  |  |  |  |  |  |
| Cost of net revenue |  |  |  |  | $ | 30 |  |  | $ | 29 |  |  |  |
| Selling, general, and administrative |  |  |  |  | 67 |  |  | 43 |  |  |  |
| Research and development |  |  |  |  | 33 |  |  | 20 |  |  |  |
| Total severance charges |  |  |  |  | $ | 130 |  |  | $ | 92 |  |  |  |

[0001571996-25-000063:notes:240]
[same as prior period, unchanged from 0001571996-24-000143:notes:274]

[0001571996-25-000063:notes:241]
The Company maintains a Supply Chain Finance Program (the “SCF Program”), which enables eligible suppliers, at the supplier's sole discretion, to sell receivables due from the Company to a third-party financial institution. The Company has no involvement in establishing the terms or conditions of the arrangement between its suppliers and the financial institution, no economic interest in a supplier's decision to sell a receivable, and does not provide legally secured assets or other forms of guarantees under the arrangement. The SCF Program does not impact the Company's liquidity, as payments for participating supplier invoices are remitted by the Company to the financial institution on the original invoice due date, regardless of whether an individual invoice is sold by the supplier to the financial institution. As of May 2, 2025 and January 31, 2025, the Company had $1.3 billion and $1.4 billion, respectively, included within accounts payable on the Condensed Consolidated Statements of Financial Position representing invoices due to suppliers confirmed as valid under the SCF Program.

[0001571996-25-000063:notes:242]
[same as prior period, unchanged from 0001571996-24-000143:notes:276]

[0001571996-25-000063:notes:243]
[same as prior period, unchanged from 0001571996-24-000143:notes:277]

[0001571996-25-000063:notes:244]
|  |  |  | Three Months Ended |
|  |  |  |  |  | May 2, 2025 |  | May 3, 2024 |  |  |
|  |  |  |  |  | (in millions) |
| Interest and other, net: |  |  |  |  |  |  |  |  |  |
| Investment income, primarily interest |  |  |  |  | $ | 31 |  |  | $ | 54 |  |  |  |
| Gain (loss) on investments, net |  |  |  |  | 17 |  |  | (30) |  |  |  |
| Interest expense |  |  |  |  | (354) |  |  | (343) |  |  |  |
| Foreign exchange |  |  |  |  | (5) |  |  | (38) |  |  |  |
| Gain on disposition of businesses and assets |  |  |  |  | 236 |  |  | — |  |  |  |
| Other |  |  |  |  | (7) |  |  | (16) |  |  |  |
| Total interest and other, net |  |  |  |  | $ | (82) |  |  | $ | (373) |  |  |  |


## us-gaap:ErrorCorrectionTextBlock

[0001571996-25-000063:notes:245]
REVISION OF PREVIOUSLY ISSUED FINANCIAL STATEMENTS
As discussed in Note 1 of the Notes to the Condensed Consolidated Financial Statements and as previously reported in the Company’s Annual Report on Form 10-K for the fiscal year ended January 31, 2025, the Company discovered accumulated credits from certain suppliers that were not recorded or not recorded in the correct period in its previously reported financial results. Accordingly, the Company has revised its previously reported quarterly financial information for the three months ended May 3, 2024 based on the summary presented below to correct for the overstatement of cost of net revenue to the Condensed Consolidated Statements of Income, net of the related income tax effect. The revision did not have an impact on the Company’s net revenue.

[0001571996-25-000063:notes:246]
A summary of the corrections to the affected financial statement line items in these Condensed Consolidated Financial Statements is presented below.

[0001571996-25-000063:notes:247]
Condensed Consolidated Statements of Income

[0001571996-25-000063:notes:248]
|  | Three Months Ended |  |  |
|  | May 3, 2024 |  |  |
|  | As Reported |  | Adjustment |  | As Revised |  |  |  |  |  |  |
|  | (in millions, except per share amounts) |
| Cost of net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Products | $ | 13,766 |  |  | $ | (45) |  |  | $ | 13,721 |  |  |  |  |  |  |  |
| Total cost of net revenue | $ | 17,438 |  |  | $ | (45) |  |  | $ | 17,393 |  |  |  |  |  |  |  |
| Gross margin | $ | 4,806 |  |  | $ | 45 |  |  | $ | 4,851 |  |  |  |  |  |  |  |
| Operating income | $ | 920 |  |  | $ | 45 |  |  | $ | 965 |  |  |  |  |  |  |  |
| Income before income taxes | $ | 547 |  |  | $ | 45 |  |  | $ | 592 |  |  |  |  |  |  |  |
| Income tax expense (benefit) | $ | (408) |  |  | $ | 8 |  |  | $ | (400) |  |  |  |  |  |  |  |
| Net income | $ | 955 |  |  | $ | 37 |  |  | $ | 992 |  |  |  |  |  |  |  |
| Net income attributable to Dell Technologies Inc. | $ | 960 |  |  | $ | 37 |  |  | $ | 997 |  |  |  |  |  |  |  |
| Earnings per share attributable to Dell Technologies Inc. |  |  |  |  |  |  |  |  |  |  |  |
| Basic | $ | 1.36 |  |  | $ | 0.05 |  |  | $ | 1.41 |  |  |  |  |  |  |  |
| Diluted | $ | 1.32 |  |  | $ | 0.05 |  |  | $ | 1.37 |  |  |  |  |  |  |  |

[0001571996-25-000063:notes:249]
(a)The Company’s Condensed Consolidated Statements of Comprehensive Income were also affected by the revised net income amounts for the period presented above.

[0001571996-25-000063:notes:250]
Condensed Consolidated Statements of Cash Flows

[0001571996-25-000063:notes:251]
|  | Three Months Ended |  |  |  |  |
|  | May 3, 2024 |  |  |  |  |
|  | As Reported |  | Adjustment |  | As Revised |  |  |  |  |  |  |  |  |  |  |  |  |
|  | (in millions) |
| Cash flow from operations: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income | $ | 955 |  |  | $ | 37 |  |  | $ | 992 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |
| Other assets and liabilities | $ | (592) |  |  | $ | (1) |  |  | $ | (593) |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Accounts payable | $ | 1,241 |  |  | $ | (36) |  |  | $ | 1,205 |  |  |  |  |  |  |  |  |  |  |  |  |  |


## us-gaap:SubsequentEventsTextBlock

[0001571996-25-000063:notes:252]
SUBSEQUENT EVENTS 
There were no known events occurring after May 2, 2025 and up until the date of issuance of this report that would materially affect the information presented herein.


## ecd:MtrlTermsOfTrdArrTextBlock

[0001571996-25-000063:notes:253]
On March 4, 2025, Richard Rothberg, one of the company’s officers as defined in Rule 16a-1(f) under the Exchange Act, adopted a written plan for the sale of up to 70,165 shares of the Company’s Class C Common Stock that is intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) under the Exchange Act. The plan will expire on July 11, 2025, or on any earlier date on which all of the shares have been sold.
