# DELL MD&A — 0001571996-25-000063


## mdna

[0001571996-25-000063:mdna:1]
[same as prior period, unchanged from 0001571996-24-000143:mdna:1]

[0001571996-25-000063:mdna:2]
[same as prior period, unchanged from 0001571996-24-000143:mdna:2]

[0001571996-25-000063:mdna:3]
Unless the context indicates otherwise, references in this report to “we,” “us,” “our,” the “Company,” and “Dell Technologies” mean Dell Technologies Inc. and its consolidated subsidiaries.

[0001571996-25-000063:mdna:4]
Our fiscal year is the 52- or 53-week period ending on the Friday nearest January 31. We refer to our fiscal year ending January 30, 2026 as “Fiscal 2026,” and our fiscal year ended January 31, 2025 as “Fiscal 2025.” Fiscal 2026 and Fiscal 2025 include 52 weeks.

[0001571996-25-000063:mdna:5]
[same as prior period, unchanged from 0001571996-24-000143:mdna:5]

[0001571996-25-000063:mdna:6]
[same as prior period, unchanged from 0001571996-24-000143:mdna:6]

[0001571996-25-000063:mdna:7]
Dell Technologies is a leader in the global technology industry focused on providing broad and innovative technology solutions for the data and artificial intelligence (“AI”) era. We build and offer solutions ranging from client devices and peripherals to infrastructure solutions across servers, networking, and storage to meet the evolving needs of our customers and drive better business outcomes. With our extensive portfolio and our commitment to innovation, we offer secure, integrated solutions that extend from the edge to the core to the cloud, and we are at the forefront of AI, software-defined, and cloud native infrastructure solutions. Our vision is to become the most essential technology partner. We intend to realize our vision by executing our strategy of leveraging our strengths to extend our leadership positions and capture new growth.

[0001571996-25-000063:mdna:8]
[same as prior period, unchanged from 0001571996-24-000143:mdna:8]

[0001571996-25-000063:mdna:9]
•Infrastructure Solutions Group (“ISG”) — ISG includes our servers and networking offerings and our storage offerings. Our server portfolio includes high-performance general-purpose and AI-optimized servers. Our networking portfolio includes wide area network infrastructure, data center and edge networking switches, and cables and optics. Our comprehensive storage portfolio includes modern and traditional storage solutions, including all-flash arrays, scale-out file, object platforms, hyper-converged infrastructure, and software-defined storage. ISG also offers software, peripherals, and services, including consulting and support and deployment.

[0001571996-25-000063:mdna:10]
[same as prior period, unchanged from 0001571996-24-000143:mdna:10]

[0001571996-25-000063:mdna:11]
Our other businesses primarily consist of our historical resale of standalone offerings of VMware LLC (formerly VMware, Inc. and individually and together with its subsidiaries, “VMware”), referred to as “VMware Resale,” and offerings of SecureWorks Corp. (“Secureworks”) through the date of the sale of Secureworks as discussed below. These businesses are divested businesses or their offerings are no longer actively sold, and are not classified as reportable segments, either individually or collectively. Their operating results are reported within Corporate and other. On February 3, 2025, the sale of Secureworks to Sophos Inc., an affiliate of Thoma Bravo, L.P., was completed in an all-cash transaction for a purchase price of approximately $0.9 billion. We received total cash consideration for the equity interest held in Secureworks of approximately $0.6 billion, resulting in a gain on sale recorded of $0.2 billion recognized in interest and other, net in the Condensed Consolidated Statements of Income during the three months ended May 2, 2025.

[0001571996-25-000063:mdna:12]
For further discussion regarding our current reportable segments, see “Results of Operations — Business Unit Results” and Note 15 of the Notes to the Condensed Consolidated Financial Statements included in this report.

[0001571996-25-000063:mdna:13]
We offer customers choices in how they acquire our solutions, including traditional purchasing and offerings under the Dell Payment Solutions portfolio. These offerings provide both payment and consumption solutions, including as-a-Service, subscription, utility, leases, and loans, which allow our customers to pay over time and provide them with operational and financial flexibility. Dell Financial Services and its affiliates (“DFS”) support financing solutions and services as part of the portfolio. For additional information about our financing arrangements, see Note 4 of the Notes to the Condensed Consolidated Financial Statements included in this report.

[0001571996-25-000063:mdna:14]
[same as prior period, unchanged from 0001571996-24-000143:mdna:14]

[0001571996-25-000063:mdna:15]
During the first quarter of Fiscal 2026, we executed our strategy with strong operating results, generating overall net revenue and operating income growth. The following trends and conditions affected the environment in which we operated:

[0001571996-25-000063:mdna:16]
•Macroeconomic environment: The demand environment significantly increased for our AI-optimized server offerings and remained strong for our commercial offerings. While the demand environment was strong, the pricing environment remained competitive, primarily impacting our CSG gross margin performance.

[0001571996-25-000063:mdna:17]
•Demand of AI-optimized solutions: Our ISG business continued to benefit from increased demand for AI-optimized solutions as customers continue to adopt and further integrate AI. As a result of the substantial demand for our AI-optimized servers during the quarter, backlog levels significantly increased when compared to the prior quarter. Given the scale of the AI opportunities, the varying stages of customer readiness, and the frequency of component part updates or transitions, there is inherent non-linearity in the timing of demand and subsequent shipments for our AI-optimized server offerings, which continues to drive variability in our revenue.

[0001571996-25-000063:mdna:18]
•Technology refresh in core markets: Within our CSG business, the PC refresh cycle is underway as customers have begun upgrading their devices, which has contributed to increased demand for our commercial offerings and CSG net revenue growth. Additionally, within our ISG business, we continue to see customers modernize and consolidate their data centers as more customers transition to next-generation products, which drove modest demand within our traditional servers and networking offerings.

[0001571996-25-000063:mdna:19]
•Business modernization initiatives: We continue to prioritize ongoing modernization initiatives to achieve greater efficiencies and streamline our processes, while also continuing to make strategic investments designed to enable growth and innovation. These initiatives have resulted in a continued net reduction in our operating expenses.

[0001571996-25-000063:mdna:20]
We expect net revenue growth for the full fiscal year primarily driven by ISG net revenue, and to a lesser extent, CSG net revenue. We expect demand growth across our servers and networking offerings throughout the remainder of Fiscal 2026, which will result in ISG net revenue growth. While we expect overall ISG net revenue growth, we anticipate potential near-term demand moderation as customers reevaluate IT spending behavior due to uncertainty in the macroeconomic environment. We expect CSG net revenue growth driven in part by the PC refresh cycle. Additionally, we expect a continued reduction of our Corporate and other net revenue driven by offerings that are no longer actively sold and businesses that have been divested.

[0001571996-25-000063:mdna:21]
We expect a modest decline in input costs during Fiscal 2026, primarily driven by anticipated deflation for component costs. Input cost trends are dependent on the strength or weakness of actual end-user demand and supply dynamics, which will continue to fluctuate and ultimately impact our costs, pricing, and operating results.

[0001571996-25-000063:mdna:22]
We remain focused on executing our key strategic priorities, creating long-term value for our stakeholders, and addressing our customers’ needs while continuing to make prudent decisions in response to the environment. We expect margin growth for the full fiscal year, while balancing anticipated margin rate pressure resulting from a continuing shift in mix towards our AI-optimized servers and a competitive environment. We look to balance profitability and growth while maintaining disciplined pricing as we navigate through competitive pricing pressures.

[0001571996-25-000063:mdna:23]
We continue to advance our own capabilities to change the way we work and make decisions, improve business outcomes and the customer experience, and reduce costs by leveraging new technology and optimizing business processes. We remain committed to disciplined cost management in coordination with our ongoing business modernization initiatives and expect continued reductions in operating expenses as we take certain measures to reduce costs, including limitation of external hiring, employee reorganizations, and other actions to align our investments with our strategic priorities and customer needs. We anticipate these actions will result in additional reductions in our overall headcount. We believe our unique operating advantages provide a foundation to foster business growth, enable innovation, drive efficiencies, and continue to position us for long-term success.

[0001571996-25-000063:mdna:24]
Relationship with VMware — On March 25, 2024, we terminated our Commercial Framework Agreement with VMware, whereby we acted as a distributor of Broadcom Inc.’s VMware standalone products and services. We no longer act as a distributor of such products and services, although we continue to support customers that have purchased resale offerings sold in prior periods. We continue to integrate and embed certain VMware products and services with our VxRail solution to end-user customers. The results for this integrated offering are reflected within ISG.

[0001571996-25-000063:mdna:25]
ISG — We expect ISG will continue to be impacted by the evolving nature of the IT infrastructure market and competitive environment. With our scale and market-leading solutions portfolio, we believe we are well-positioned to address the ongoing competitive dynamics and trends in technology and customer needs. Through our collaborative, customer-focused approach to innovation, we strive to deliver relevant new and next-generation solutions and software to our customers quickly and efficiently. We continue to focus on customer base expansion and the lifetime value of customer relationships.

[0001571996-25-000063:mdna:26]
We anticipate ISG will continue to benefit from technology advancements and interest in AI as customers continue to adopt and integrate AI. The timing of customer purchases reflects the varying stages of adoption of AI by different customer segments and drives variability in our revenue. To meet the growing demand and increasing complexity of our AI-optimized offerings, we have increased our purchases of certain components with suppliers, which has resulted in increased inventory levels, higher purchase obligations, and new working capital dynamics. Additionally, frequent component part updates or transitions create additional challenges in managing demand and supply levels. While we have seen lead times shorten, we anticipate the next generation of these components, for which the demand remains high, will be subject to supply constraints.

[0001571996-25-000063:mdna:27]
[same as prior period, unchanged from 0001571996-24-000143:mdna:27]

[0001571996-25-000063:mdna:28]
CSG — We participate in all segments of the PC market with a focus on commercial and high-end consumer computing devices, which we believe represent the most stable and profitable markets. We anticipate that CSG will benefit from advances in AI over the long-term as customers will require PCs with the ability to run their complex AI workloads.

[0001571996-25-000063:mdna:29]
Competitive dynamics remain an important factor in our CSG business and continue to impact pricing and operating results. We are committed to our long-term CSG strategy and will continue to make investments to innovate across the portfolio. We expect that the CSG demand environment will be subject to seasonal trends and influenced by the timing and scale of the PC refresh cycle.

[0001571996-25-000063:mdna:30]
[same as prior period, unchanged from 0001571996-24-000143:mdna:30]

[0001571996-25-000063:mdna:31]
Strategic Investments and Acquisitions — As part of our strategy, we will continue to evaluate opportunities for strategic investments through our venture capital investment arm, Dell Technologies Capital, with a focus on emerging technology areas that are relevant to our business and that will complement our existing portfolio of solutions. The technologies or products these companies have under development are typically in the early stages and may never have commercial value, which could result in a loss of a substantial part of our investment in the companies. In addition to these investments, we may also make targeted acquisitions of businesses that advance our strategic objectives and accelerate our innovation agenda.

[0001571996-25-000063:mdna:32]
Foreign Currency Exposure — We manage our business on a U.S. Dollar basis. However, we have a large global presence, generating approximately half of our net revenue from sales to customers outside of the United States during the first quarter of Fiscal 2026 and Fiscal 2025. As a result, our operating results can be, and particularly in recent periods have been, impacted by fluctuations in foreign currency exchange rates. We utilize a comprehensive hedging strategy intended to mitigate the impact of foreign currency volatility over time, and we adjust pricing when possible to further minimize foreign currency impacts.

[0001571996-25-000063:mdna:33]
Other Macroeconomic Risks and Uncertainties — During the first quarter of Fiscal 2026, a number of countries, including the United States, imposed or proposed tariffs on imports, and may continue to do so. The impacts of trade protection measures, including increases or changes in tariffs and trade barriers, changes in government policies and international trade arrangements, geopolitical volatility, and global macroeconomic conditions, or uncertainty regarding the impact of proposed or future trade protection measures, may affect our results of operations in some markets. We leveraged the agility and scale of our world-class supply chain to mitigate impacts of tariffs during the quarter, and will continue to respond to changing market conditions as needed.

[0001571996-25-000063:mdna:34]
52

[0001571996-25-000063:mdna:35]
[same as prior period, unchanged from 0001571996-24-000143:mdna:35]

[0001571996-25-000063:mdna:36]
[same as prior period, unchanged from 0001571996-24-000143:mdna:36]

[0001571996-25-000063:mdna:37]
[same as prior period, unchanged from 0001571996-24-000143:mdna:37]

[0001571996-25-000063:mdna:38]
Non-GAAP product gross margin, non-GAAP services gross margin, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, and non-GAAP earnings per share attributable to Dell Technologies Inc. - diluted, as defined by us, exclude amortization of intangible assets, stock-based compensation expense, other corporate (income) expenses and, for non-GAAP net income and non-GAAP earnings per share attributable to Dell Technologies Inc. - diluted, fair value adjustments on equity investments and an aggregate adjustment for income taxes. As the excluded items may have a material impact on our financial results, our management compensates for this limitation by relying primarily on our GAAP results and using non-GAAP financial measures supplementally or for projections when comparable GAAP financial measures are not available.

[0001571996-25-000063:mdna:39]
[same as prior period, unchanged from 0001571996-24-000143:mdna:39]

[0001571996-25-000063:mdna:40]
[same as prior period, unchanged from 0001571996-24-000143:mdna:40]

[0001571996-25-000063:mdna:41]
•Amortization of Intangible Assets — Amortization of intangible assets primarily consists of the amortization of customer relationships, developed technology, and trade names. In connection with our acquisition by merger of EMC Corporation in 2016, all of the tangible and intangible assets and liabilities were accounted for and recognized at fair value on the transaction date. We exclude amortization charges for the amortization of intangible assets as they do not reflect our current operating performance and charges are significantly impacted by the timing and magnitude of our acquisitions and, as a result, may vary in amount from period to period.

[0001571996-25-000063:mdna:42]
[same as prior period, unchanged from 0001571996-24-000143:mdna:42]

[0001571996-25-000063:mdna:43]
•Other Corporate (Income) Expenses — Other corporate (income) expenses consist primarily of transaction-related gains on the sales of businesses, severance expenses, payroll taxes associated with stock-based compensation, incentive charges related to equity investments, transaction-related expenses, facility action costs, and impairment charges. During the first quarter of Fiscal 2026, we recognized a $0.2 billion gain related to the sale of Secureworks. Although we may incur these types of expenses in the future, we exclude other corporate (income) expenses as they can vary from period to period, are significantly impacted by the timing and nature of these events, and are not used by management in assessing operating performance of the business.

[0001571996-25-000063:mdna:44]
[same as prior period, unchanged from 0001571996-24-000143:mdna:44]

[0001571996-25-000063:mdna:45]
•Aggregate Adjustment for Income Taxes — The aggregate adjustment for income taxes is the estimated combined income tax effect for the adjustments described above and determined based on the tax jurisdictions where those adjustments were incurred, as well as an adjustment for discrete tax items. During the first quarter of Fiscal 2025, the aggregate adjustment for income taxes included discrete tax benefits of $0.4 billion related to changes in uncertain tax benefits resulting from the expiration of certain U.S. statutes of limitations and $0.2 billion related to stock-based compensation. We exclude these benefits or charges for purposes of calculating non-GAAP net income due to the variability in recognition of discrete tax items from period to period. The tax effects are determined based on the tax jurisdictions where the above items were incurred. See Note 11 of the Notes to the Condensed Consolidated Financial Statements included in this report for additional information about our income taxes. Our non-GAAP income tax was calculated using a fixed estimated annual tax rate that is determined based on historical trends and projections for the current fiscal year. We may adjust our estimated annual tax rate during the fiscal year to take into account events that would significantly impact our income tax expense, including significant changes resulting from tax legislation, material changes in geographic mix of revenue and expenses, changes to our corporate structure, and other significant events.

[0001571996-25-000063:mdna:46]
54

[0001571996-25-000063:mdna:47]
[same as prior period, unchanged from 0001571996-24-000143:mdna:47]

[0001571996-25-000063:mdna:48]
|  | Three Months Ended |  |  |
|  | May 2, 2025 |  | % Change |  | May 3, 2024 |  |  |  |  |  |  |  |  |  |  |
|  | (in millions, except percentages) |
| Product gross margin | $ | 2,483 |  |  | 3 | % |  | $ | 2,406 |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 41 |  |  |  |  | 60 |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense | 15 |  |  |  |  | 14 |  |  |  |  |  |  |  |  |  |  |  |
| Other corporate expenses | 9 |  |  |  |  | 4 |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP product gross margin | $ | 2,548 |  |  | 3 | % |  | $ | 2,484 |  |  |  |  |  |  |  |  |  |  |  |
| Services gross margin | $ | 2,454 |  |  | — | % |  | $ | 2,445 |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense | 24 |  |  |  |  | 24 |  |  |  |  |  |  |  |  |  |  |  |
| Other corporate expenses | 31 |  |  |  |  | 39 |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP services gross margin | $ | 2,509 |  |  | — | % |  | $ | 2,508 |  |  |  |  |  |  |  |  |  |  |  |
| Gross margin | $ | 4,937 |  |  | 2 | % |  | $ | 4,851 |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 41 |  |  |  |  | 60 |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense | 39 |  |  |  |  | 38 |  |  |  |  |  |  |  |  |  |  |  |
| Other corporate expenses | 40 |  |  |  |  | 43 |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP gross margin | $ | 5,057 |  |  | 1 | % |  | $ | 4,992 |  |  |  |  |  |  |  |  |  |  |  |
| Operating expenses | $ | 3,772 |  |  | (3) | % |  | $ | 3,886 |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | (85) |  |  |  |  | (108) |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense | (151) |  |  |  |  | (172) |  |  |  |  |  |  |  |  |  |  |  |
| Other corporate expenses | (145) |  |  |  |  | (133) |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP operating expenses | $ | 3,391 |  |  | (2) | % |  | $ | 3,473 |  |  |  |  |  |  |  |  |  |  |  |

[0001571996-25-000063:mdna:49]
|  | Three Months Ended |  |  |
|  | May 2, 2025 |  | % Change |  | May 3, 2024 |  |  |  |  |  |  |  |  |  |  |
|  | (in millions, except percentages and per share amounts) |
| Operating income | $ | 1,165 |  |  | 21 | % |  | $ | 965 |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 126 |  |  |  |  | 168 |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense | 190 |  |  |  |  | 210 |  |  |  |  |  |  |  |  |  |  |  |
| Other corporate expenses | 185 |  |  |  |  | 176 |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP operating income | $ | 1,666 |  |  | 10 | % |  | $ | 1,519 |  |  |  |  |  |  |  |  |  |  |  |
| Net income | $ | 965 |  |  | (3) | % |  | $ | 992 |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 126 |  |  |  |  | 168 |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense | 190 |  |  |  |  | 210 |  |  |  |  |  |  |  |  |  |  |  |
| Other corporate (income) expenses | (58) |  |  |  |  | 170 |  |  |  |  |  |  |  |  |  |  |  |
| Fair value adjustments on equity investments | (17) |  |  |  |  | 30 |  |  |  |  |  |  |  |  |  |  |  |
| Aggregate adjustment for income taxes | (120) |  |  |  |  | (611) |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP net income | $ | 1,086 |  |  | 13 | % |  | $ | 959 |  |  |  |  |  |  |  |  |  |  |  |
| Earnings per share attributable to Dell Technologies Inc. — diluted | $ | 1.37 |  |  | — | % |  | $ | 1.37 |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 0.18 |  |  |  |  | 0.23 |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense | 0.27 |  |  |  |  | 0.29 |  |  |  |  |  |  |  |  |  |  |  |
| Other corporate (income) expenses | (0.08) |  |  |  |  | 0.24 |  |  |  |  |  |  |  |  |  |  |  |
| Fair value adjustments on equity investments | (0.02) |  |  |  |  | 0.04 |  |  |  |  |  |  |  |  |  |  |  |
| Aggregate adjustment for income taxes | (0.17) |  |  |  |  | (0.84) |  |  |  |  |  |  |  |  |  |  |  |
| Total non-GAAP adjustments attributable to non-controlling interests | — |  |  |  |  | (0.01) |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP earnings per share attributable to Dell Technologies Inc. — diluted | $ | 1.55 |  |  | 17 | % |  | $ | 1.32 |  |  |  |  |  |  |  |  |  |  |  |

[0001571996-25-000063:mdna:50]
[same as prior period, unchanged from 0001571996-24-000143:mdna:34]

[0001571996-25-000063:mdna:51]
[same as prior period, unchanged from 0001571996-24-000143:mdna:51]

[0001571996-25-000063:mdna:52]
[same as prior period, unchanged from 0001571996-24-000143:mdna:52]

[0001571996-25-000063:mdna:53]
[same as prior period, unchanged from 0001571996-24-000143:mdna:53]

[0001571996-25-000063:mdna:54]
[same as prior period, unchanged from 0001571996-24-000143:mdna:54]

[0001571996-25-000063:mdna:55]
|  | Three Months Ended |  |  |
|  | May 2, 2025 |  | % Change |  | May 3, 2024 |  |  |  |  |  |  |  |  |  |  |
|  | (in millions, except percentages) |
| Cash flow from operations | $ | 2,796 |  |  | 168 | % |  | $ | 1,043 |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Capital expenditures and capitalized software development costs, net (a) | (568) |  |  |  |  | (586) |  |  |  |  |  |  |  |  |  |  |  |
| Free cash flow | $ | 2,228 |  |  | 388 | % |  | $ | 457 |  |  |  |  |  |  |  |  |  |  |  |
| Free cash flow | $ | 2,228 |  |  | 388 | % |  | $ | 457 |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Financing receivables (b) | (23) |  |  |  |  | 165 |  |  |  |  |  |  |  |  |  |  |  |
| Equipment under operating leases (c) | 27 |  |  |  |  | 1 |  |  |  |  |  |  |  |  |  |  |  |
| Adjusted free cash flow | $ | 2,232 |  |  | 258 | % |  | $ | 623 |  |  |  |  |  |  |  |  |  |  |  |

[0001571996-25-000063:mdna:56]
[same as prior period, unchanged from 0001571996-24-000143:mdna:56]

[0001571996-25-000063:mdna:57]
(a)Capital expenditures and capitalized software development costs, net includes proceeds from sales of facilities, land, and other assets.

[0001571996-25-000063:mdna:58]
(b)Financing receivables represent the operating cash flow impact from the change in financing receivables.

[0001571996-25-000063:mdna:59]
(c)Equipment under operating leases represents the net impact of capital expenditures and depreciation expense for leases and contractually embedded leases identified within flexible consumption arrangements.

[0001571996-25-000063:mdna:60]
[same as prior period, unchanged from 0001571996-24-000143:mdna:61]

[0001571996-25-000063:mdna:61]
[same as prior period, unchanged from 0001571996-24-000143:mdna:62]

[0001571996-25-000063:mdna:62]
[same as prior period, unchanged from 0001571996-24-000143:mdna:63]

[0001571996-25-000063:mdna:63]
|  | Three Months Ended |  |  |
|  | May 2, 2025 |  |  |  | May 3, 2024 |  |  |  |  |  |  |  |  |  |  |
|  | Dollars |  | % of Net Revenue |  | % Change |  | Dollars |  | % of Net Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | (in millions, except percentages and per share amounts) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products | $ | 17,599 |  |  | 75.3 | % |  | 9 | % |  | $ | 16,127 |  |  | 72.5 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Services | 5,779 |  |  | 24.7 | % |  | (6) | % |  | 6,117 |  |  | 27.5 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total net revenue | $ | 23,378 |  |  | 100.0 | % |  | 5 | % |  | $ | 22,244 |  |  | 100.0 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products | $ | 2,483 |  |  | 14.1 | % |  | 3 | % |  | $ | 2,406 |  |  | 14.9 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Services | 2,454 |  |  | 42.5 | % |  | — | % |  | 2,445 |  |  | 40.0 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total gross margin | $ | 4,937 |  |  | 21.1 | % |  | 2 | % |  | $ | 4,851 |  |  | 21.8 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating expenses | $ | 3,772 |  |  | 16.1 | % |  | (3) | % |  | $ | 3,886 |  |  | 17.5 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating income | $ | 1,165 |  |  | 5.0 | % |  | 21 | % |  | $ | 965 |  |  | 4.3 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income | $ | 965 |  |  | 4.1 | % |  | (3) | % |  | $ | 992 |  |  | 4.5 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Earnings per share attributable to Dell Technologies — diluted | $ | 1.37 |  |  |  |  | — | % |  | $ | 1.37 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash flow from operations | $ | 2,796 |  |  |  |  | 168 | % |  | $ | 1,043 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP Financial Information |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | Three Months Ended |  |  |
|  | May 2, 2025 |  |  |  | May 3, 2024 |  |  |  |  |  |  |  |  |  |  |
|  | Dollars |  | % of Net Revenue |  | % Change |  | Dollars |  | % of Net Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | (in millions, except percentages and per share amounts) |
| Non-GAAP gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products | $ | 2,548 |  |  | 14.5 | % |  | 3 | % |  | $ | 2,484 |  |  | 15.4 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Services | 2,509 |  |  | 43.4 | % |  | — | % |  | 2,508 |  |  | 41.0 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total non-GAAP gross margin | $ | 5,057 |  |  | 21.6 | % |  | 1 | % |  | $ | 4,992 |  |  | 22.4 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP operating expenses | $ | 3,391 |  |  | 14.5 | % |  | (2) | % |  | $ | 3,473 |  |  | 15.6 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP operating income | $ | 1,666 |  |  | 7.1 | % |  | 10 | % |  | $ | 1,519 |  |  | 6.8 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP net income | $ | 1,086 |  |  | 4.6 | % |  | 13 | % |  | $ | 959 |  |  | 4.3 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP earnings per share attributable to Dell Technologies — diluted | $ | 1.55 |  |  |  |  | 17 | % |  | $ | 1.32 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Free cash flow | $ | 2,228 |  |  |  |  | 388 | % |  | $ | 457 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Adjusted free cash flow | $ | 2,232 |  |  |  |  | 258 | % |  | $ | 623 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0001571996-25-000063:mdna:64]
[same as prior period, unchanged from 0001571996-24-000143:mdna:65]

[0001571996-25-000063:mdna:65]
[same as prior period, unchanged from 0001571996-24-000143:mdna:46]

[0001571996-25-000063:mdna:66]
[same as prior period, unchanged from 0001571996-24-000143:mdna:67]

[0001571996-25-000063:mdna:67]
During the first quarter of Fiscal 2026, net revenue increased by 5%, driven by an increase in ISG net revenue and, to a lesser extent, CSG net revenue that was partially offset by a decrease in Corporate and other net revenue. The increase in ISG net revenue was driven by growth in our servers and networking offerings. The increase in CSG net revenue was attributable to an increase in sales of our commercial offerings. Corporate and other net revenue declined primarily due to a decrease in VMware Resale revenue as we no longer act as a distributor of standalone VMware offerings.

[0001571996-25-000063:mdna:68]
During the first quarter of Fiscal 2026, operating income and non-GAAP operating income increased by 21% to $1.2 billion and 10% to $1.7 billion, respectively. The increases in operating income and non-GAAP operating income were primarily attributable to an increase in ISG operating income that was driven by our storage offerings.

[0001571996-25-000063:mdna:69]
During the first quarter of Fiscal 2026, operating income and non-GAAP operating income as a percentage of net revenue increased 70 basis points to 5.0% and 30 basis points to 7.1%, respectively. The increases were driven by the favorable impact of a decrease in operating expense rate as a result of strong net revenue growth coupled with continued disciplined cost management. The favorable impact of a decrease in operating expense rate was partially offset by a decline in gross margin as a percentage of net revenue due to a competitive CSG pricing environment and a shift in geographical mix within our servers and networking offerings coupled with a shift in mix between our ISG offerings.

[0001571996-25-000063:mdna:70]
Cash provided by operating activities was $2.8 billion during the first quarter of Fiscal 2026 and was driven by profitability and working capital dynamics. Working capital was primarily impacted by increased demand for our AI-optimized server offerings, which led to higher accounts payable, other current assets, and inventory levels, as well as other business impacts, including annual incentive-based personnel-related payments and strong cash collections performance. During the first quarter of Fiscal 2025, cash provided by operating activities was $1.0 billion, and was primarily driven by profitability and working capital dynamics, including a shift in mix of the business, the timing of purchases and payments to vendors, annual incentive-based personnel-related payments, and strong cash collections performance. See “Liquidity, Cash Requirements, and Market Conditions” for additional information about our cash flow metrics.

[0001571996-25-000063:mdna:71]
[same as prior period, unchanged from 0001571996-24-000143:mdna:72]

[0001571996-25-000063:mdna:72]
[same as prior period, unchanged from 0001571996-24-000143:mdna:73]

[0001571996-25-000063:mdna:73]
During the first quarter of Fiscal 2026, net revenue increased 5%, primarily driven by an increase in ISG net revenue and, to a lesser extent, CSG net revenue that was partially offset by a decrease in Corporate and other net revenue. See “Business Unit Results” for further information.

[0001571996-25-000063:mdna:74]
•Product Net Revenue — Product net revenue includes revenue from the sale of hardware products and software licenses. During the first quarter of Fiscal 2026, product net revenue increased 9% due to an increase in ISG product net revenue and, to a lesser extent, an increase in CSG product net revenue. The increase in ISG product net revenue was driven by growth in our servers and networking offerings and, to a lesser extent, our storage offerings. The increase in CSG product net revenue was driven by growth in our commercial offerings, partially offset by lower demand for our consumer offerings.

[0001571996-25-000063:mdna:75]
•Services Net Revenue — Services net revenue includes revenue from our services offerings and support services related to hardware products and software licenses. During the first quarter of Fiscal 2026, services net revenue decreased 6% due to a decline in Corporate and other services net revenue, as we no longer act as a distributor of standalone VMware offerings.

[0001571996-25-000063:mdna:76]
[same as prior period, unchanged from 0001571996-24-000143:mdna:78]

[0001571996-25-000063:mdna:77]
From a geographical perspective, net revenue increased in EMEA and APJ and decreased in the Americas during the first quarter of Fiscal 2026.

[0001571996-25-000063:mdna:78]
[same as prior period, unchanged from 0001571996-24-000143:mdna:80]

[0001571996-25-000063:mdna:79]
During the first quarter of Fiscal 2026, gross margin and non-GAAP gross margin increased 2% to $4.9 billion and 1% to $5.1 billion, respectively, driven by an increase in ISG gross margin. The increase in ISG gross margin was primarily attributable to growth in our storage offerings.

[0001571996-25-000063:mdna:80]
During the first quarter of Fiscal 2026, gross margin and non-GAAP gross margin percentage decreased 70 basis points to 21.1% and 80 basis points to 21.6%, respectively. The decreases in gross margin percentage and non-GAAP gross margin percentage were primarily driven by a competitive CSG pricing environment and a shift in geographical mix within our servers and networking offerings coupled with a shift in mix between our ISG offerings.

[0001571996-25-000063:mdna:81]
•Product Gross Margin — During the first quarter of Fiscal 2026, both product gross margin and non-GAAP product gross margin increased 3% to $2.5 billion. The increases were primarily attributable to an increase in ISG product gross margin due to growth in our storage offerings.

[0001571996-25-000063:mdna:82]
During the first quarter of Fiscal 2026, product gross margin percentage and non-GAAP product gross margin percentage decreased 80 basis points to 14.1% and 90 basis points to 14.5%, respectively. The declines were primarily attributable to a competitive CSG pricing environment and a shift in geographical mix within our servers and networking offerings coupled with a shift in mix between our ISG offerings.

[0001571996-25-000063:mdna:83]
•Services Gross Margin — During the first quarter of Fiscal 2026, both services gross margin and non-GAAP services gross margin remained flat at $2.5 billion.

[0001571996-25-000063:mdna:84]
During the first quarter of Fiscal 2026, services gross margin percentage and non-GAAP services gross margin percentage increased 250 basis points to 42.5% and 240 basis points to 43.4%, respectively. The increases in services gross margin percentage and non-GAAP services gross margin percentage were primarily driven by a shift in mix, as we no longer act as a distributor of standalone VMware offerings.

[0001571996-25-000063:mdna:85]
[same as prior period, unchanged from 0001571996-24-000143:mdna:88]

[0001571996-25-000063:mdna:86]
[same as prior period, unchanged from 0001571996-24-000143:mdna:89]

[0001571996-25-000063:mdna:87]
The terms and conditions of our vendor rebate programs are largely based on product volumes and are generally negotiated either at the beginning of the annual or quarterly period, depending on the program. The timing and amount of vendor rebates and other discounts we receive under the programs may vary from period to period, reflecting changes in the competitive environment. We monitor our component costs and seek to address the effects of any changes to terms that might arise under our vendor rebate programs. Our gross margins for the first quarter of Fiscal 2026 were not materially affected by any changes to the terms of our vendor rebate programs, as the amounts we received under these programs were generally stable relative to our total net cost. We are not aware of any significant changes to our vendor rebate programs that will materially impact our results in the near term.

[0001571996-25-000063:mdna:88]
[same as prior period, unchanged from 0001571996-24-000143:mdna:50]

[0001571996-25-000063:mdna:89]
[same as prior period, unchanged from 0001571996-24-000143:mdna:92]

[0001571996-25-000063:mdna:90]
[same as prior period, unchanged from 0001571996-24-000143:mdna:93]

[0001571996-25-000063:mdna:91]
|  | Three Months Ended |  |  |
|  | May 2, 2025 |  |  |  | May 3, 2024 |  |  |  |  |  |  |  |  |  |  |
|  | Dollars |  | % of Net Revenue |  | % Change |  | Dollars |  | % of Net Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | (in millions, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative | $ | 2,964 |  |  | 12.6 | % |  | (5) | % |  | $ | 3,123 |  |  | 14.1 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 808 |  |  | 3.5 | % |  | 6 | % |  | 763 |  |  | 3.4 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total operating expenses | $ | 3,772 |  |  | 16.1 | % |  | (3) | % |  | $ | 3,886 |  |  | 17.5 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | Three Months Ended |  |  |
|  | May 2, 2025 |  |  |  | May 3, 2024 |  |  |  |  |  |  |  |  |  |  |
|  | Dollars |  | % of Net Revenue |  | % Change |  | Dollars |  | % of Net Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | (in millions, except percentages) |
| Non-GAAP operating expenses | $ | 3,391 |  |  | 14.5 | % |  | (2) | % |  | $ | 3,473 |  |  | 15.6 | % |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |

[0001571996-25-000063:mdna:92]
During the first quarter of Fiscal 2026, total operating expenses decreased 3% due to a decline in selling, general, and administrative (“SG&A”) expenses.

[0001571996-25-000063:mdna:93]
•Selling, General, and Administrative — During the first quarter of Fiscal 2026, SG&A expenses decreased 5%, driven by a decrease in employee compensation and benefits expense, principally due to a decline in overall headcount.

[0001571996-25-000063:mdna:94]
•Research and Development — Research and development (“R&D”) expenses are primarily composed of personnel-related expenses incurred in connection with product development. R&D expenses increased 6% during the first quarter of Fiscal 2026, principally due to continued support of R&D initiatives.

[0001571996-25-000063:mdna:95]
As a percentage of net revenue, R&D expenses for the first quarter of Fiscal 2026 and Fiscal 2025 were 3.5% and 3.4%, respectively. We continue to support R&D initiatives to innovate and introduce new and enhanced solutions into the market.

[0001571996-25-000063:mdna:96]
During the first quarter of Fiscal 2026, non-GAAP operating expenses decreased 2%, driven by a decline in employee compensation and benefits expense, primarily resulting from a decline in overall headcount. The decline in employee compensation and benefits expense was partially offset by continued support of R&D initiatives.

[0001571996-25-000063:mdna:97]
[same as prior period, unchanged from 0001571996-24-000143:mdna:100]

[0001571996-25-000063:mdna:98]
[same as prior period, unchanged from 0001571996-24-000143:mdna:101]

[0001571996-25-000063:mdna:99]
During the first quarter of Fiscal 2026, operating income and non-GAAP operating income increased by 21% to $1.2 billion and 10% to $1.7 billion, respectively. The increases in operating income and non-GAAP operating income were primarily attributable to an increase in ISG operating income that was driven by our storage offerings.

[0001571996-25-000063:mdna:100]
During the first quarter of Fiscal 2026, operating income and non-GAAP operating income as a percentage of net revenue increased 70 basis points to 5.0% and 30 basis points to 7.1%, respectively. The increases were driven by the favorable impact of a decrease in operating expense rate as a result of strong net revenue growth coupled with continued disciplined cost management. The favorable impact of a decrease in operating expense rate was partially offset by a decline in gross margin as a percentage of net revenue due to a competitive CSG pricing environment and a shift in geographical mix within our servers and networking offerings coupled with a shift in mix between our ISG offerings.

[0001571996-25-000063:mdna:101]
[same as prior period, unchanged from 0001571996-24-000143:mdna:104]

[0001571996-25-000063:mdna:102]
[same as prior period, unchanged from 0001571996-24-000143:mdna:105]

[0001571996-25-000063:mdna:103]
|  | Three Months Ended |  |  |
|  | May 2, 2025 |  | May 3, 2024 |  |  |  |  |  |  |
|  | (in millions) |
| Interest and other, net: |  |  |  |  |  |  |  |  |  |
| Investment income, primarily interest | $ | 31 |  |  | $ | 54 |  |  |  |  |  |  |  |
| Gain (loss) on investments, net | 17 |  |  | (30) |  |  |  |  |  |  |  |
| Interest expense | (354) |  |  | (343) |  |  |  |  |  |  |  |
| Foreign exchange | (5) |  |  | (38) |  |  |  |  |  |  |  |
| Gain on disposition of businesses and assets | 236 |  |  | — |  |  |  |  |  |  |  |
| Other | (7) |  |  | (16) |  |  |  |  |  |  |  |
| Total interest and other, net | $ | (82) |  |  | $ | (373) |  |  |  |  |  |  |  |

[0001571996-25-000063:mdna:104]
During the first quarter of Fiscal 2026, the change in interest and other, net was favorable primarily attributable to the gain on the sale of Secureworks and, to a lesser extent, the gains recognized within our strategic investments portfolio.

[0001571996-25-000063:mdna:105]
[same as prior period, unchanged from 0001571996-24-000143:mdna:108]

[0001571996-25-000063:mdna:106]
[same as prior period, unchanged from 0001571996-24-000143:mdna:109]

[0001571996-25-000063:mdna:107]
|  | Three Months Ended |  |  |
|  | May 2, 2025 |  | May 3, 2024 |  |  |  |  |  |  |
|  | (in millions, except percentages) |
| Income before income taxes | $ | 1,083 |  |  | $ | 592 |  |  |  |  |  |  |  |
| Income tax expense (benefit) | $ | 118 |  |  | $ | (400) |  |  |  |  |  |  |  |
| Effective income tax rate | 10.9 | % |  | (67.6) | % |  |  |  |  |  |  |

[0001571996-25-000063:mdna:108]
For the first quarter of Fiscal 2026 and Fiscal 2025, our effective income tax rates were 10.9% and (67.6)%, respectively. The change in our effective tax rates for Fiscal 2026 as compared to Fiscal 2025 was primarily attributable to discrete tax items. For the first quarter of Fiscal 2026, we recorded discrete tax benefits of $0.1 billion related to stock-based compensation. For the first quarter of Fiscal 2025, we recorded discrete tax benefits of $0.4 billion related to changes in uncertain tax benefits resulting from the expiration of certain U.S. statutes of limitations and $0.2 billion related to stock-based compensation.

[0001571996-25-000063:mdna:109]
Our effective income tax rate can fluctuate depending on the geographic distribution of our worldwide earnings, as our foreign earnings are generally taxed at lower rates than in the United States. The differences between our effective income tax rates and the U.S. federal statutory rate of 21% principally result from the geographical distribution of income, differences between the book and tax treatment of certain items, and discrete tax items. In certain jurisdictions, our tax rate is significantly less than the applicable statutory rate as a result of tax holidays. The majority of our foreign income subject to these tax holidays is attributable to Singapore and China. A significant portion of these income tax benefits relates to a tax holiday that will be effective until January 31, 2029. Most of our other tax holidays will expire in whole or in part during Fiscal 2030 and Fiscal 2031. Many of these tax holidays and reduced tax rates may be extended when certain conditions are met or may be terminated early if certain conditions are not met or as a result of changes in tax legislation. As of May 2, 2025, we were not aware of any matters of non-compliance.

[0001571996-25-000063:mdna:110]
Many countries, including Singapore, a country in which we have a tax holiday, have enacted or are in the process of enacting laws based on the Pillar Two proposal relating to a global minimum tax issued by the Organisation for Economic Co-operation and Development (“OECD”). While our effective income tax rate and cash income tax payments may increase in future years as a result of the global minimum tax, we do not expect it will have a material impact for Fiscal 2026. Our assessment could be affected by legislative guidance and future enactment of additional provisions within the Pillar Two framework.

[0001571996-25-000063:mdna:111]
[same as prior period, unchanged from 0001571996-24-000143:mdna:114]

[0001571996-25-000063:mdna:112]
[same as prior period, unchanged from 0001571996-24-000143:mdna:115]

[0001571996-25-000063:mdna:113]
During the first quarter of Fiscal 2026, net income decreased 3% to $1.0 billion primarily due to higher income tax expense, largely offset by a favorable change in interest and other, net and an increase in operating income.

[0001571996-25-000063:mdna:114]
During the first quarter of Fiscal 2026, non-GAAP net income increased 13% to $1.1 billion primarily due to an increase in operating income.

[0001571996-25-000063:mdna:115]
[same as prior period, unchanged from 0001571996-24-000143:mdna:118]

[0001571996-25-000063:mdna:116]
Our reportable segments are based on the ISG and CSG business units. A description of our business units is provided under “Introduction.” See Note 15 of the Notes to the Condensed Consolidated Financial Statements included in this report for a reconciliation of net revenue and operating income by reportable segment to consolidated net revenue and consolidated operating income, respectively.

[0001571996-25-000063:mdna:117]
[same as prior period, unchanged from 0001571996-24-000143:mdna:120]

[0001571996-25-000063:mdna:118]
[same as prior period, unchanged from 0001571996-24-000143:mdna:121]

[0001571996-25-000063:mdna:119]
|  | Three Months Ended |  |  |
|  | May 2, 2025 |  | % Change |  | May 3, 2024 |  |  |  |  |  |  |  |  |  |  |
|  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Servers and networking | $ | 6,321 |  |  | 16 | % |  | $ | 5,466 |  |  |  |  |  |  |  |  |  |  |
| Storage | 3,996 |  |  | 6 | % |  | 3,761 |  |  |  |  |  |  |  |  |  |  |
| Total ISG net revenue | $ | 10,317 |  |  | 12 | % |  | $ | 9,227 |  |  |  |  |  |  |  |  |  |  |
| Operating income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| ISG operating income | $ | 998 |  |  | 36 | % |  | $ | 736 |  |  |  |  |  |  |  |  |  |  |
| % of segment net revenue | 9.7 | % |  |  |  | 8.0 | % |  |  |  |  |  |  |  |  |  |  |

[0001571996-25-000063:mdna:120]
Net Revenue — During the first quarter of Fiscal 2026, ISG net revenue increased 12%, driven primarily by strength in our servers and networking offerings and, to a lesser extent, our storage offerings.

[0001571996-25-000063:mdna:121]
Net revenue from sales of servers and networking increased 16% during the first quarter of Fiscal 2026. The increase in servers and networking net revenue was driven by growth in both our traditional server and networking offerings and our AI-optimized server offerings.

[0001571996-25-000063:mdna:122]
Storage net revenue increased 6% during the first quarter of Fiscal 2026 primarily due to an increase in our core storage offerings.

[0001571996-25-000063:mdna:123]
From a geographical perspective, net revenue attributable to ISG increased in EMEA and APJ and decreased in the Americas during the first quarter of Fiscal 2026.

[0001571996-25-000063:mdna:124]
Operating Income — During the first quarter of Fiscal 2026, ISG operating income as a percentage of net revenue increased 170 basis points to 9.7% due to a decline in operating expense as a percentage of revenue that outpaced the decline in gross margin rate. Operating expense as a percentage of net revenue declined primarily due to strong ISG net revenue growth coupled with continued disciplined cost management. Gross margin rate decreased primarily as the result of a shift in geographical mix within our servers and networking offerings coupled with a shift in mix between our ISG offerings.

[0001571996-25-000063:mdna:125]
[same as prior period, unchanged from 0001571996-24-000143:mdna:129]

[0001571996-25-000063:mdna:126]
[same as prior period, unchanged from 0001571996-24-000143:mdna:130]

[0001571996-25-000063:mdna:127]
|  | Three Months Ended |  |  |
|  | May 2, 2025 |  | % Change |  | May 3, 2024 |  |  |  |  |  |  |  |  |  |  |
|  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 11,046 |  |  | 9 | % |  | $ | 10,154 |  |  |  |  |  |  |  |  |  |  |
| Consumer | 1,463 |  |  | (19) | % |  | 1,813 |  |  |  |  |  |  |  |  |  |  |
| Total CSG net revenue | $ | 12,509 |  |  | 5 | % |  | $ | 11,967 |  |  |  |  |  |  |  |  |  |  |
| Operating income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| CSG operating income | $ | 653 |  |  | (16) | % |  | $ | 777 |  |  |  |  |  |  |  |  |  |  |
| % of segment net revenue | 5.2 | % |  |  |  | 6.5 | % |  |  |  |  |  |  |  |  |  |  |

[0001571996-25-000063:mdna:128]
Net Revenue — During the first quarter of Fiscal 2026, CSG net revenue increased 5%, driven primarily by strength in our commercial offerings, partially offset by lower demand for our consumer offerings.

[0001571996-25-000063:mdna:129]
Commercial net revenue increased 9% during the first quarter of Fiscal 2026, primarily as the result of an increase in units sold. Consumer net revenue decreased 19% during the first quarter of Fiscal 2026, primarily due to a decline in units sold.

[0001571996-25-000063:mdna:130]
From a geographical perspective, net revenue attributable to CSG increased across all regions during the first quarter of Fiscal 2026, most notably in the Americas.

[0001571996-25-000063:mdna:131]
Operating Income — During the first quarter of Fiscal 2026, CSG operating income as a percentage of net revenue decreased 130 basis points to 5.2%, primarily due to a decline in gross margin rate. The decline in gross margin rate was primarily the result of a competitive pricing environment.

[0001571996-25-000063:mdna:132]
[same as prior period, unchanged from 0001571996-24-000143:mdna:137]

[0001571996-25-000063:mdna:133]
[same as prior period, unchanged from 0001571996-24-000143:mdna:138]

[0001571996-25-000063:mdna:134]
We sell products and services directly to customers and through a variety of sales channels, including retail distribution. Our accounts receivable, net was $9.8 billion and $10.3 billion as of May 2, 2025 and January 31, 2025, respectively. Accounts receivable, net declined due to strong cash collections performance. We maintain an allowance for expected credit losses to cover receivables that may be deemed uncollectible. The allowance for expected credit losses is an estimate based on an analysis of historical loss experience, current receivables aging, and management’s assessment of current conditions and its reasonable and supportable expectation of future conditions, as well as specific identifiable customer accounts that are deemed at risk. As of May 2, 2025 and January 31, 2025, the allowance for expected credit losses was $82 million and $63 million, respectively. Based on our assessment, we believe that we are adequately reserved for expected credit losses.

[0001571996-25-000063:mdna:135]
[same as prior period, unchanged from 0001571996-24-000143:mdna:140]

[0001571996-25-000063:mdna:136]
We offer or arrange a portfolio of payment and consumption solutions and services for our customers globally, including as-a-Service, subscription, utility, leases, and loans designed to match customers' consumption and financing preferences. We believe these options provide operational and financial flexibility and strengthen our customer relationships. To support financing solutions and services as part of the portfolio, DFS originates, collects, and services customer receivables primarily related to the purchase of our product and services solutions. New financing originations were $1.6 billion and $1.9 billion for the first quarter of Fiscal 2026 and Fiscal 2025, respectively.

[0001571996-25-000063:mdna:137]
Our leases are generally classified as sales-type leases or operating leases. On commencement of sales-type leases, we recognize profit up-front and recognize amounts due from the customer under the lease contract as financing receivables. Interest income is recognized as net product revenue over the term of the lease. Upon origination of operating leases, we record equipment under operating leases, classified as property, plant, and equipment, net. We recognize product revenue and depreciation expense, classified as cost of net revenue, over the contract term.

[0001571996-25-000063:mdna:138]
As of May 2, 2025 and January 31, 2025, our financing receivables, net were $11.4 billion and $11.2 billion, respectively. We maintain an allowance to cover expected financing receivables credit losses and evaluate credit loss expectations based on our total portfolio. For both the first quarter of Fiscal 2026 and Fiscal 2025, the principal charge-off rate for our financing receivables portfolio was 0.3%. The credit quality of our financing receivables remains strong due to the mix of high-quality commercial accounts in our portfolio. We continue to monitor broader economic indicators and their potential impact on future credit loss performance. We have an extensive process to manage our exposure to customer credit risk that includes active management of credit lines and collection activities. We also sell selected fixed-term financing receivables without recourse to unrelated third parties on a periodic basis, primarily to manage certain concentrations of customer credit exposure. Based on our assessment of the customer financing receivables, we believe that we are adequately reserved.

[0001571996-25-000063:mdna:139]
We retain a residual interest in equipment leased under our lease programs. As of May 2, 2025 and January 31, 2025, the residual interest recorded as part of financing receivables was $178 million and $168 million, respectively. The amount of the residual interest is established at the inception of the lease based upon estimates of the value of the equipment at the end of the lease term using historical studies, industry data, and future value-at-risk demand valuation methods. On a quarterly basis, we assess the carrying amount of our recorded residual values for expected losses. Generally, expected losses as a result of residual value risk on equipment under lease are not considered to be significant primarily because of the existence of a secondary market with respect to the equipment. Further, the lease agreement defines applicable return conditions and remedies for non-compliance to ensure that the leased equipment will be in good operating condition upon return. No expected losses were recorded related to residual assets during the first quarter of Fiscal 2026 and Fiscal 2025.

[0001571996-25-000063:mdna:140]
As of May 2, 2025 and January 31, 2025, equipment under operating leases, net was $2.3 billion and $2.2 billion, respectively. We assess the carrying amount of the equipment under operating leases for impairment whenever events or circumstances may indicate that an impairment has occurred. No material impairment losses were recorded related to such equipment during the first quarter of Fiscal 2026 and Fiscal 2025.

[0001571996-25-000063:mdna:141]
DFS offerings are initially funded through cash on hand at the time of origination, most of which is subsequently replaced with asset-backed financing. For offerings that qualify as sales-type leases, the initial funding of financing receivables is reflected as an impact to cash flows from operations and is largely subsequently offset by cash proceeds from financing. For offerings that qualify as operating leases, the initial funding is classified as a capital expenditure and reflected as an impact to cash flows used in investing activities.

[0001571996-25-000063:mdna:142]
[same as prior period, unchanged from 0001571996-24-000143:mdna:147]

[0001571996-25-000063:mdna:143]
67

[0001571996-25-000063:mdna:144]
[same as prior period, unchanged from 0001571996-24-000143:mdna:149]

[0001571996-25-000063:mdna:145]
[same as prior period, unchanged from 0001571996-24-000143:mdna:150]

[0001571996-25-000063:mdna:146]
[same as prior period, unchanged from 0001571996-24-000143:mdna:151]

[0001571996-25-000063:mdna:147]
[same as prior period, unchanged from 0001571996-24-000143:mdna:152]

[0001571996-25-000063:mdna:148]
We believe that our current cash and cash equivalents, together with cash that will be provided by future operations and borrowings and issuances expected to be available under our revolving credit facility and commercial paper program, will be sufficient over the next twelve months and for the foreseeable future thereafter to meet our material cash requirements, including funding of our operations, debt-related payments, capital expenditures, and other corporate needs.

[0001571996-25-000063:mdna:149]
As part of our overall capital allocation strategy, we intend to continue returning capital to our stockholders through both share repurchase programs and dividend payments and to use the remaining available cash to drive growth and maintain our investment grade credit rating.

[0001571996-25-000063:mdna:150]
[same as prior period, unchanged from 0001571996-24-000143:mdna:155]

[0001571996-25-000063:mdna:151]
|  | May 2, 2025 |  | January 31, 2025 |
|  | (in millions) |
| Cash and cash equivalents, and available borrowings: |  |  |  |
| Cash and cash equivalents | $ | 7,700 |  |  | $ | 3,633 |  |
| Remaining available borrowings under the revolving credit facility | 5,998 |  |  | 5,999 |  |
| Total cash and cash equivalents, and available borrowings | $ | 13,698 |  |  | $ | 9,632 |  |

[0001571996-25-000063:mdna:152]
During the first quarter of Fiscal 2026, cash and cash equivalents increased by $4.1 billion primarily due to an increase in net debt from the issuance of Senior Notes and DFS debt, cash flows from operations, and the proceeds from the sale of Secureworks, the effects of which were partially offset by the return of capital to our stockholders, capital expenditures, and payments to settle employee tax withholdings on stock-based compensation.

[0001571996-25-000063:mdna:153]
As of May 2, 2025, our revolving credit facility had a maximum capacity of $6.0 billion. Available borrowings under this facility are reduced by draws on the facility and outstanding letters of credit. As of May 2, 2025, there were no borrowings outstanding under the facility and remaining available borrowings totaled approximately $6.0 billion. The revolving credit facility also acts as a backstop to provide liquidity support for our commercial paper program.

[0001571996-25-000063:mdna:154]
We maintain a commercial paper program under which we may issue unsecured notes in a maximum aggregate face amount of $5.0 billion outstanding at any time, with maturities of up to 397 days from the date of issue. As of May 2, 2025, we had no outstanding issuances under the program.

[0001571996-25-000063:mdna:155]
We may regularly use our available borrowings from the revolving credit facility and issuances under the commercial paper program, generally on a short-term basis, for general corporate purposes. See the following discussion for additional information about our debt.

[0001571996-25-000063:mdna:156]
[same as prior period, unchanged from 0001571996-24-000143:mdna:162]

[0001571996-25-000063:mdna:157]
[same as prior period, unchanged from 0001571996-24-000143:mdna:163]

[0001571996-25-000063:mdna:158]
|  | May 2, 2025 |  | Change |  | January 31, 2025 |
|  | (in millions) |
| Core debt |  |  |  |  |  |
| Senior Notes | $ | 19,073 |  |  | $ | 4,000 |  |  | $ | 15,073 |  |
| Legacy Notes | 952 |  |  | — |  |  | 952 |  |
| DFS allocated debt | (3,056) |  |  | (28) |  |  | (3,028) |  |
| Total core debt | 16,969 |  |  | 3,972 |  |  | 12,997 |  |
| DFS related debt |  |  |  |  |  |
| DFS debt | 8,927 |  |  | 216 |  |  | 8,711 |  |
| DFS allocated debt | 3,056 |  |  | 28 |  |  | 3,028 |  |
| Total DFS related debt | 11,983 |  |  | 244 |  |  | 11,739 |  |
| Other | 79 |  |  | 27 |  |  | 52 |  |
| Total debt, principal amount | 29,031 |  |  | 4,243 |  |  | 24,788 |  |
| Carrying value adjustments | (250) |  |  | (29) |  |  | (221) |  |
| Total debt, carrying value | $ | 28,781 |  |  | $ | 4,214 |  |  | $ | 24,567 |  |

[0001571996-25-000063:mdna:159]
The outstanding principal amount of our debt increased $4.2 billion to $29.0 billion as of May 2, 2025, driven primarily by an increase in net debt from the issuance of Senior Notes.

[0001571996-25-000063:mdna:160]
We define core debt as the total principal amount of our debt, less DFS related debt and other debt. Our core debt was $17.0 billion and $13.0 billion as of May 2, 2025 and January 31, 2025, respectively. See Note 6 of the Notes to the Condensed Consolidated Financial Statements included in this report for additional information about our debt.

[0001571996-25-000063:mdna:161]
[same as prior period, unchanged from 0001571996-24-000143:mdna:167]

[0001571996-25-000063:mdna:162]
To fund the expansion of our DFS business, we balance the use of the securitization and structured financing programs with other sources of liquidity. We approximate the amount of our core debt used to fund the DFS business by applying a 7:1 debt-to-equity ratio to the sum of our financing receivables balance and equipment under operating leases, net, also referred to as DFS owned assets. The debt-to-equity ratio is based on the underlying credit quality of the assets. See Note 4 of the Notes to the Condensed Consolidated Financial Statements included in this report for additional information about our DFS debt.

[0001571996-25-000063:mdna:163]
The following table presents DFS owned assets as of the dates indicated:

[0001571996-25-000063:mdna:164]
|  | May 2, 2025 |  | January 31, 2025 |
|  | (in millions) |
| Financing receivables, net | $ | 11,423 |  |  | $ | 11,231 |  |
| Equipment under operating leases, net | 2,272 |  |  | 2,185 |  |
| DFS owned assets | $ | 13,695 |  |  | $ | 13,416 |  |

[0001571996-25-000063:mdna:165]
We believe we will continue to be able to make our debt principal and interest payments, including payment of short-term maturities, from existing and expected sources of cash, primarily from operating cash flows. Cash used for debt principal and interest payments also may include short-term borrowings under our commercial paper program, our revolving credit facility, or other borrowings. Under our variable-rate debt, we could experience variations in our future interest expense from potential fluctuations in applicable reference rates, or from possible fluctuations in the level of DFS debt required to meet future demand for customer financing.

[0001571996-25-000063:mdna:166]
[same as prior period, unchanged from 0001571996-24-000143:mdna:170]

[0001571996-25-000063:mdna:167]
[same as prior period, unchanged from 0001571996-24-000143:mdna:172]

[0001571996-25-000063:mdna:168]
[same as prior period, unchanged from 0001571996-24-000143:mdna:173]

[0001571996-25-000063:mdna:169]
|  | Three Months Ended |
|  | May 2, 2025 |  | May 3, 2024 |  |  |
|  | (in millions) |
| Net change in cash from: |  |  |  |  |  |
| Operating activities | $ | 2,796 |  |  | $ | 1,043 |  |  |  |
| Investing activities | (88) |  |  | (456) |  |  |  |
| Financing activities | 1,237 |  |  | (2,077) |  |  |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash | 89 |  |  | (55) |  |  |  |
| Change in cash, cash equivalents, and restricted cash | $ | 4,034 |  |  | $ | (1,545) |  |  |  |

[0001571996-25-000063:mdna:170]
Operating Activities — Cash provided by operating activities was $2.8 billion during the first quarter of Fiscal 2026 and was driven by profitability and working capital dynamics. Working capital was primarily impacted by increased demand for our AI-optimized server offerings, which led to higher accounts payable, other current assets, and inventory levels, as well as other business impacts, including annual incentive-based personnel-related payments and strong cash collections performance. During the first quarter of Fiscal 2025, cash provided by operating activities was $1.0 billion, and was primarily driven by profitability and working capital dynamics, including a shift in mix of the business, the timing of purchases and payments to vendors, annual incentive-based personnel-related payments, and strong cash collections performance.

[0001571996-25-000063:mdna:171]
Investing Activities — Investing activities primarily consist of cash used to fund capital expenditures for property, plant, and equipment inclusive of equipment under operating leases and equipment used to support our as-a-Service offerings, which we refer to collectively as assets in a customer contract. Additional activities may include capitalized software development costs, the maturities, sales, and purchases of investments, and acquisitions and divestitures. Cash used in investing activities was $0.1 billion during the first quarter of Fiscal 2026 and consisted of cash used for capital expenditures, largely offset by cash proceeds from the sale of Secureworks. Cash used in investing activities was $0.5 billion during the first quarter of Fiscal 2025 and was primarily applied to capital expenditures.

[0001571996-25-000063:mdna:172]
Financing Activities — Financing activities primarily consist of the proceeds and repayments of debt and return of capital to our stockholders. Cash provided by financing activities was $1.2 billion during the first quarter of Fiscal 2026 and primarily consisted of net proceeds from the issuance of Senior Notes and DFS debt, partially offset by repurchases of common stock, inclusive of payments to settle employee tax withholdings on stock-based compensation, and the payment of quarterly dividends. Cash used in financing activities was $2.1 billion during the first quarter of Fiscal 2025 and primarily consisted of repurchases of common stock, inclusive of payments to settle employee tax withholdings on stock-based compensation, net repayments on DFS debt, and the payment of quarterly dividends.

[0001571996-25-000063:mdna:173]
DFS Cash Flow Impacts — DFS offerings are initially funded through cash on hand at the time of origination, most of which is subsequently replaced with asset-backed financing. For offerings that qualify as sales-type leases, the initial funding of financing receivables is reflected as an impact to cash flows from operations and is largely subsequently offset by cash proceeds from financing. For offerings that qualify as operating leases, the initial funding is classified as a capital expenditure and reflected as cash flows used in investing activities. DFS new financing originations were $1.6 billion and $1.9 billion during the first quarter of Fiscal 2026 and Fiscal 2025, respectively. As of May 2, 2025, we had $11.4 billion of total net financing receivables and $2.3 billion of equipment under operating leases, net.

[0001571996-25-000063:mdna:174]
Supply Chain Finance Program — We maintain a Supply Chain Finance Program (the “SCF Program”) that enables eligible suppliers to sell receivables due from us to a third-party financial institution at the suppliers’ sole discretion. The SCF Program does not impact our liquidity, as payments by us to participating suppliers are remitted to the financial institution on the original invoice due date. Further, we negotiate payment terms with our suppliers regardless of their decision to participate in the SCF Program. Payments made under the SCF Program are included in cash flows from operating activities on the Condensed Consolidated Statements of Cash Flows. See Note 16 of the Notes to the Condensed Consolidated Financial Statements included in this report for more information regarding the SCF Program.

[0001571996-25-000063:mdna:175]
[same as prior period, unchanged from 0001571996-24-000143:mdna:180]

[0001571996-25-000063:mdna:176]
Capital Expenditures — We spent $0.6 billion during both the first quarter of Fiscal 2026 and Fiscal 2025 on property, plant, and equipment and capitalized software development costs. Of total expenditures incurred, funding of assets in a customer contract totaled $0.3 billion during both the first quarter of Fiscal 2026 and Fiscal 2025. Product demand, product mix, the use of contract manufacturers, and ongoing investments in operating and information technology infrastructure influence the level and prioritization of our capital expenditures.

[0001571996-25-000063:mdna:177]
Repurchases of Common Stock — On September 23, 2021, our Board of Directors approved a stock repurchase program with no fixed expiration date under which we were authorized to repurchase up to $5 billion of shares of Class C Common Stock, exclusive of any fees, commissions, or other expenses related to such repurchases. On October 5, 2023 and February 27, 2025, our Board of Directors authorized additional shares for repurchase under the stock repurchase program of $5 billion and $10 billion, respectively. Following the February 27, 2025 approval, we had approximately $11.5 billion of authorized shares remaining under the program.

[0001571996-25-000063:mdna:178]
During the first quarter of Fiscal 2026, we repurchased approximately 22 million shares of Class C Common Stock for a total purchase price of approximately $2.0 billion. During the first quarter of Fiscal 2025, we repurchased approximately 7 million shares of Class C Common Stock for a total purchase price of approximately $0.7 billion.

[0001571996-25-000063:mdna:179]
Dividend Payments — During the first quarter of Fiscal 2026 and Fiscal 2025, the Company paid $0.4 billion and $0.3 billion in dividends and dividend equivalents at a rate of $0.525 and $0.445 per share per fiscal quarter, respectively.

[0001571996-25-000063:mdna:180]
[same as prior period, unchanged from 0001571996-24-000143:mdna:185]

[0001571996-25-000063:mdna:181]
We utilize several suppliers to manufacture sub-assemblies for our products. Our efficient supply chain management allows us to enter into flexible and mutually beneficial purchase arrangements with our suppliers in order to minimize inventory risk. Consistent with industry practice, we acquire raw materials or other goods and services, including product components, by issuing to suppliers authorizations to purchase based on our projected demand and manufacturing needs. Additionally, to meet the growing demand and increasing complexity of our AI-optimized offerings, we have increased our purchases of certain components with suppliers, which has resulted in increased purchase obligations. These purchase orders are typically fulfilled within 30 days and are entered into during the ordinary course of business in order to establish best pricing and continuity of supply for our production. Purchase orders are not included in purchase obligations, as they typically represent our authorization to purchase rather than binding purchase obligations.

[0001571996-25-000063:mdna:182]
As of May 2, 2025, we had purchase obligations of $7.4 billion, of which $5.8 billion was payable within twelve months.

[0001571996-25-000063:mdna:183]
[same as prior period, unchanged from 0001571996-24-000143:mdna:188]

[0001571996-25-000063:mdna:184]
[same as prior period, unchanged from 0001571996-24-000143:mdna:189]

[0001571996-25-000063:mdna:185]
We monitor credit risk associated with our financial counterparties using various market credit risk indicators such as credit ratings issued by nationally recognized credit rating agencies and changes in market credit default swap levels. Our AI-optimized solutions to date have been purchased primarily by a small number of larger customers and cloud service providers. Such purchases generally involve larger amounts of credit, and could impact overall credit risk in trade and financing receivables. We perform periodic evaluations of our positions with counterparties and may limit exposure to any one counterparty in accordance with our policies. We monitor and manage our positions based on current and expected market developments.

[0001571996-25-000063:mdna:186]
We use derivative instruments to hedge certain foreign currency exposures. We use forward contracts and purchased options designated as cash flow hedges to protect against the foreign currency exchange rate risks inherent in our forecasted transactions denominated in currencies other than the U.S. Dollar. In addition, we primarily use forward contracts and may use purchased options to hedge monetary assets and liabilities denominated in a foreign currency. See Note 7 of the Notes to the Condensed Consolidated Financial Statements included in this report for additional information about our use of derivative instruments.

[0001571996-25-000063:mdna:187]
We are exposed to interest rate risk related to our investment and variable-rate debt portfolios. In the normal course of business, we follow established policies and procedures to manage this risk, including monitoring of our asset and liability mix and the use of derivative instruments. As a result, we do not anticipate any material losses from interest rate risk.

[0001571996-25-000063:mdna:188]
[same as prior period, unchanged from 0001571996-24-000143:mdna:148]

[0001571996-25-000063:mdna:189]
[same as prior period, unchanged from 0001571996-24-000143:mdna:194]

[0001571996-25-000063:mdna:190]
[same as prior period, unchanged from 0001571996-24-000143:mdna:195]

[0001571996-25-000063:mdna:191]
[same as prior period, unchanged from 0001571996-24-000143:mdna:196]

[0001571996-25-000063:mdna:192]
[same as prior period, unchanged from 0001571996-24-000143:mdna:197]

[0001571996-25-000063:mdna:193]
|  | Three Months Ended |
|  | May 2, 2025 |
|  | (in millions) |
| Net revenue | $ | 2,049 |  |
| Gross margin | 940 |  |
| Operating income | 126 |  |
| Interest and other, net | (1,006) |  |
| Loss before income taxes | $ | (880) |  |
| Net loss attributable to Obligor Group (a) | $ | (627) |  |

[0001571996-25-000063:mdna:194]
[same as prior period, unchanged from 0001571996-24-000143:mdna:199]

[0001571996-25-000063:mdna:195]
(a)Includes net loss from intercompany transactions with Non-Obligor Subsidiaries of $1,218 million, which primarily consists of interest expense, shared services, and the resale of solutions.

[0001571996-25-000063:mdna:196]
[same as prior period, unchanged from 0001571996-24-000143:mdna:204]

[0001571996-25-000063:mdna:197]
|  | May 2, 2025 |  | January 31, 2025 |
|  | (in millions) |
| ASSETS |
| Current assets | $ | 3,042 |  |  | $ | 3,132 |  |
| Intercompany receivables | — |  |  | 175 |  |
| Total current assets | 3,042 |  |  | 3,307 |  |
| Goodwill and intangible assets | 13,998 |  |  | 14,073 |  |
| Other non-current assets | 3,427 |  |  | 3,412 |  |
| Total assets | $ | 20,467 |  |  | $ | 20,792 |  |
| LIABILITIES |
| Current liabilities | $ | 3,824 |  |  | $ | 4,097 |  |
| Intercompany payable | 359 |  |  | — |  |
| Total current liabilities | 4,183 |  |  | 4,097 |  |
| Long-term debt | 19,796 |  |  | 15,824 |  |
| Long-term intercompany loan payables | 44,524 |  |  | 44,516 |  |
| Other non-current liabilities | 3,233 |  |  | 3,339 |  |
| Total liabilities | $ | 71,736 |  |  | $ | 67,776 |  |

[0001571996-25-000063:mdna:198]
[same as prior period, unchanged from 0001571996-24-000143:mdna:171]
