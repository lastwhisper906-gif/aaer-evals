# DELL notes — 0001571996-21-000063


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001571996-21-000063:notes:1]
Basis of Presentation — The accompanying unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes filed with the U.S. Securities and Exchange Commission (“SEC”) in the Company’s Annual Report on Form 10-K for the fiscal year ended January 29, 2021.  These Condensed Consolidated Financial Statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“GAAP”).  In the opinion of management, the accompanying Condensed Consolidated Financial Statements reflect all adjustments of a normal recurring nature considered necessary to fairly state the financial position of Dell Technologies Inc. as of October 29, 2021 and January 29, 2021, the results of its operations and corresponding comprehensive income (loss) for the three and nine months ended October 29, 2021 and October 30, 2020, its cash flows for the nine months ended October 29, 2021 and October 30, 2020, and its statements of stockholders’ equity for the three and nine months ended October 29, 2021 and October 30, 2020.


## us-gaap:ConsolidationPolicyTextBlock

[0001571996-21-000063:notes:2]
[same as prior period, unchanged from 0001571996-21-000040:notes:2]


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001571996-21-000063:notes:3]
Recently Issued Accounting Pronouncements

[0001571996-21-000063:notes:4]
Accounting for Contract Assets and Contract Liabilities from Contracts with Customers — In October 2021, the Financial Accounting Standards Board (“FASB”) issued guidance which requires companies to apply Topic 606, Revenue from Contracts with Customers, to recognize and measure contract assets and contract liabilities from contracts with customers acquired in a business combination.  Public entities must adopt the new guidance for fiscal years beginning after December 15, 2022 and interim periods within those fiscal years, with early adoption permitted.  The Company is currently evaluating the impact and timing of adoption of this guidance.

[0001571996-21-000063:notes:5]
Reference Rate Reform — In March 2020, the FASB issued guidance which provides temporary optional expedients and exceptions to GAAP guidance on contract modifications and certain hedging relationships to ease the financial reporting burdens related to the expected market transition from the London Interbank Offered Rate to alternative reference rates.  The Company may elect to apply the amendments prospectively through December 31, 2022.  Adoption of the new guidance is not expected to have a material impact on the Company’s financial results.

[0001571996-21-000063:notes:6]
Recently Adopted Accounting Pronouncements

[0001571996-21-000063:notes:7]
Accounting for Convertible Instruments and Contracts in an Entity’s Own Equity — In August 2020, the FASB issued guidance to simplify the accounting for convertible debt instruments and convertible preferred stock, and the derivatives scope exception for contracts in an entity's own equity.  In addition, the guidance on calculating diluted earnings per share has been simplified and made more internally consistent.  The Company early adopted this standard as of January 30, 2021.  There was no impact on the Condensed Consolidated Financial Statements or to diluted earnings per share as of the adoption date.

[0001571996-21-000063:notes:8]
Simplifying Accounting for Income Taxes — In December 2019, the FASB issued guidance to simplify the accounting for income taxes by removing certain exceptions to the general principles in Topic 740, Income Taxes, and by clarifying and amending existing guidance in order to improve consistent application of GAAP for other areas of Topic 740.  The Company adopted the standard during the three months ended April 30, 2021.  The impact of the adoption of this standard was immaterial to the Condensed Consolidated Financial Statements.


## us-gaap:FairValueDisclosuresTextBlock

[0001571996-21-000063:notes:9]
[same as prior period, unchanged from 0001571996-21-000040:notes:10]

[0001571996-21-000063:notes:10]
[same as prior period, unchanged from 0001571996-21-000040:notes:11]

[0001571996-21-000063:notes:11]
|  | October 29, 2021 |  | January 29, 2021 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | Quoted Prices in Active Markets for Identical Assets |  | Significant Other Observable Inputs |  | Significant Unobservable Inputs |  |  |  | Quoted Prices in Active Markets for Identical Assets |  | Significant Other Observable Inputs |  | Significant Unobservable Inputs |  |  |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 16,757 |  |  | $ | — |  |  | $ | — |  |  | $ | 16,757 |  |  | $ | 8,846 |  |  | $ | — |  |  | $ | — |  |  | $ | 8,846 |  |
| Equity and other securities | 155 |  |  | — |  |  | — |  |  | 155 |  |  | 449 |  |  | — |  |  | — |  |  | 449 |  |
| Derivative instruments | — |  |  | 195 |  |  | — |  |  | 195 |  |  | — |  |  | 104 |  |  | — |  |  | 104 |  |
| Total assets | $ | 16,912 |  |  | $ | 195 |  |  | $ | — |  |  | $ | 17,107 |  |  | $ | 9,295 |  |  | $ | 104 |  |  | $ | — |  |  | $ | 9,399 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative instruments | $ | — |  |  | $ | 100 |  |  | $ | — |  |  | $ | 100 |  |  | $ | — |  |  | $ | 133 |  |  | $ | — |  |  | $ | 133 |  |
| Total liabilities | $ | — |  |  | $ | 100 |  |  | $ | — |  |  | $ | 100 |  |  | $ | — |  |  | $ | 133 |  |  | $ | — |  |  | $ | 133 |  |

[0001571996-21-000063:notes:12]
[same as prior period, unchanged from 0001571996-21-000040:notes:13]

[0001571996-21-000063:notes:13]
Money Market Funds — The Company’s investments in money market funds that are classified as cash equivalents hold underlying investments with a weighted average maturity of 90 days or less and are recognized at fair value.  The valuations of these securities are based on quoted prices in active markets for identical assets, when available, or pricing models whereby all significant inputs are observable or can be derived from or corroborated by observable market data.  The Company reviews security pricing and assesses liquidity on a quarterly basis.  As of October 29, 2021, the Company’s U.S. portfolio had no material exposure to money market funds with a fluctuating net asset value.

[0001571996-21-000063:notes:14]
[same as prior period, unchanged from 0001571996-21-000040:notes:15]

[0001571996-21-000063:notes:15]
[same as prior period, unchanged from 0001571996-21-000040:notes:16]

[0001571996-21-000063:notes:16]
Deferred Compensation Plans — The Company offers deferred compensation plans for eligible employees, which allow participants to defer payment for a portion of their compensation.  Assets were the same as liabilities associated with the plans at approximately $361 million and $308 million as of October 29, 2021 and January 29, 2021, respectively, and are included in other assets and other liabilities on the Condensed Consolidated Statements of Financial Position.  The net impact to the Condensed Consolidated Statements of Income is not material since changes in the fair value of the assets substantially offset changes in the fair value of the liabilities.  As such, assets and liabilities associated with these plans have not been included in the recurring fair value table above.

[0001571996-21-000063:notes:17]
[same as prior period, unchanged from 0001571996-21-000040:notes:18]

[0001571996-21-000063:notes:18]
As of October 29, 2021 and January 29, 2021, the Company held private strategic investments of $1.3 billion and $1.0 billion, respectively.  As these investments represent early-stage companies without readily determinable fair values, they are not included in the recurring fair value table above.

[0001571996-21-000063:notes:19]
[same as prior period, unchanged from 0001571996-21-000040:notes:20]

[0001571996-21-000063:notes:20]
[same as prior period, unchanged from 0001571996-21-000040:notes:21]

[0001571996-21-000063:notes:21]
|  | October 29, 2021 |  | January 29, 2021 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Secured Credit Facilities | $ | 6.2 |  |  | $ | 6.3 |  |  | $ | 6.2 |  |  | $ | 6.3 |  |
| First Lien Notes | $ | 18.3 |  |  | $ | 22.8 |  |  | $ | 18.3 |  |  | $ | 22.8 |  |
| Unsecured Notes and Debentures | $ | 0.8 |  |  | $ | 1.2 |  |  | $ | 1.2 |  |  | $ | 1.6 |  |
| Senior Notes | $ | 1.6 |  |  | $ | 1.7 |  |  | $ | 2.7 |  |  | $ | 2.8 |  |
| EMC Notes | $ | — |  |  | $ | — |  |  | $ | 1.0 |  |  | $ | 1.0 |  |
| VMware Notes | $ | 10.7 |  |  | $ | 11.1 |  |  | $ | 4.7 |  |  | $ | 5.3 |  |
| Margin Loan Facility | $ | — |  |  | $ | — |  |  | $ | 4.0 |  |  | $ | 3.9 |  |

[0001571996-21-000063:notes:22]
[same as prior period, unchanged from 0001571996-21-000040:notes:23]

[0001571996-21-000063:notes:23]
[same as prior period, unchanged from 0001571996-21-000040:notes:24]

[0001571996-21-000063:notes:24]
[same as prior period, unchanged from 0001571996-21-000040:notes:25]

[0001571996-21-000063:notes:25]
|  | October 29, 2021 |  | January 29, 2021 |
|  | Cost |  | Unrealized Gain |  | Unrealized (Loss) |  | Carrying Value |  | Cost |  | Unrealized Gain |  | Unrealized (Loss) |  | Carrying Value |
|  | (in millions) |
| Equity and other securities | $ | 1,236 |  |  | $ | 488 |  |  | $ | (224) |  |  | $ | 1,500 |  |  | $ | 907 |  |  | $ | 677 |  |  | $ | (145) |  |  | $ | 1,439 |  |
| Fixed income debt securities | 333 |  |  | — |  |  | (6) |  |  | 327 |  |  | 176 |  |  | 9 |  |  | — |  |  | 185 |  |
| Total securities |  |  |  |  |  |  | $ | 1,827 |  |  |  |  |  |  |  |  | $ | 1,624 |  |

[0001571996-21-000063:notes:26]
Equity and other securities — The Company has strategic investments in publicly-traded and privately-held companies.  For the nine months ended October 29, 2021, the equity and other securities without readily determinable fair values of $1.3 billion increased by $411 million, primarily due to upward adjustments for observable price changes of $448 million, partially offset by $37 million of downward adjustments that were primarily attributable to observable price changes.  The remainder of equity and other securities consists of publicly-traded investments that are measured at fair value on a recurring basis.

[0001571996-21-000063:notes:27]
[same as prior period, unchanged from 0001571996-21-000040:notes:28]


## dell:CreditLossFinancialInstrumentLeasesDebtVariableInterestEntitiesAndCustomerReceivablesSalesTextBlock

[0001571996-21-000063:notes:28]
NOTE 3 — FINANCIAL SERVICES

[0001571996-21-000063:notes:29]
The Company offers or arranges various financing options, services, and alternative payment structures for its customers in North America, Europe, Australia, and New Zealand through Dell Financial Services and its affiliates (“DFS”).  The Company also arranges financing for some of its customers in various countries where DFS does not currently operate as a captive enterprise.  The Company further strengthens customer relationships through flexible consumption models, which enable the Company to offer its customers the option to pay over time and, in certain cases, based on utilization, to provide them with financial flexibility to meet their changing technological requirements.  The key activities of DFS include originating, collecting, and servicing customer financing arrangements primarily related to the purchase or use of Dell Technologies products and services.  In some cases, DFS also offers financing on the purchase of third-party technology products that complement the Dell Technologies portfolio of products and services.  New financing originations were $2.0 billion and $2.1 billion for the three months ended October 29, 2021 and October 30, 2020, respectively, and $5.8 billion and $6.5 billion for the nine months ended October 29, 2021 and October 30, 2020, respectively.

[0001571996-21-000063:notes:30]
The Company’s loan and lease arrangements with customers are aggregated into the following categories:

[0001571996-21-000063:notes:31]
Revolving loans — Revolving loans offered under private label credit financing programs provide qualified customers with a revolving credit line for the purchase of products and services offered by Dell Technologies.  These private label credit financing programs are referred to as Dell Preferred Account (“DPA”) and Dell Business Credit (“DBC”).  The DPA product is primarily offered to individual consumer customers, and the DBC product is primarily offered to small and medium-sized commercial customers.  Revolving loans in the United States bear interest at a variable annual percentage rate that is tied to the prime rate.  Based on historical payment patterns, revolving loan transactions are typically repaid within twelve months on average.  Due to the short-term nature of the revolving loan portfolio, the carrying value of the portfolio approximates fair value.

[0001571996-21-000063:notes:32]
Fixed-term leases and loans — The Company enters into financing arrangements with customers who seek lease financing for equipment.  DFS leases are classified as sales-type leases, direct financing leases, or operating leases.  Direct financing leases are immaterial.  Leases that commenced prior to the effective date of the current lease accounting standard continue to be accounted for under previous lease accounting guidance.  Leases with business customers have fixed terms of generally two to four years.

[0001571996-21-000063:notes:33]
The Company also offers fixed-term loans to qualified small businesses, large commercial accounts, governmental organizations, educational entities, and certain individual consumer customers.  These loans are repaid in equal payments including interest and have defined terms of generally three to five years.  The fair value of the fixed-term loan portfolio is determined using market observable inputs.  The carrying value of these loans approximates fair value.

[0001571996-21-000063:notes:34]
Financing Receivables

[0001571996-21-000063:notes:35]
The following table presents the components of the Company’s financing receivables segregated by portfolio segment as of the dates indicated:

[0001571996-21-000063:notes:36]
|  | October 29, 2021 |  | January 29, 2021 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Financing receivables, net: |  |  |  |  |  |  |  |  |  |  |  |
| Customer receivables, gross (a) | $ | 705 |  |  | $ | 9,495 |  |  | $ | 10,200 |  |  | $ | 796 |  |  | $ | 9,595 |  |  | $ | 10,391 |  |
| Allowances for losses | (112) |  |  | (113) |  |  | (225) |  |  | (148) |  |  | (173) |  |  | (321) |  |
| Customer receivables, net | 593 |  |  | 9,382 |  |  | 9,975 |  |  | 648 |  |  | 9,422 |  |  | 10,070 |  |
| Residual interest | — |  |  | 265 |  |  | 265 |  |  | — |  |  | 424 |  |  | 424 |  |
| Financing receivables, net | $ | 593 |  |  | $ | 9,647 |  |  | $ | 10,240 |  |  | $ | 648 |  |  | $ | 9,846 |  |  | $ | 10,494 |  |
| Short-term | $ | 593 |  |  | $ | 4,377 |  |  | $ | 4,970 |  |  | $ | 648 |  |  | $ | 4,507 |  |  | $ | 5,155 |  |
| Long-term | $ | — |  |  | $ | 5,270 |  |  | $ | 5,270 |  |  | $ | — |  |  | $ | 5,339 |  |  | $ | 5,339 |  |

[0001571996-21-000063:notes:37]
____________________

[0001571996-21-000063:notes:38]
(a)    Customer receivables, gross includes amounts due from customers under revolving loans, fixed-term loans, fixed-term sales-type or direct financing leases, and accrued interest.

[0001571996-21-000063:notes:39]
The following tables present the changes in allowance for financing receivable losses for the periods indicated:

[0001571996-21-000063:notes:40]
|  | Three Months Ended |
|  | October 29, 2021 |  | October 30, 2020 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |  |  |  |  |  |  |  |  |  |  |  |
| Balances at beginning of period | $ | 126 |  |  | $ | 161 |  |  | $ | 287 |  |  | $ | 143 |  |  | $ | 180 |  |  | $ | 323 |  |
| Charge-offs, net of recoveries | (9) |  |  | (20) |  |  | (29) |  |  | (13) |  |  | (6) |  |  | (19) |  |
| Provision charged to income statement | (5) |  |  | (28) |  |  | (33) |  |  | 12 |  |  | (9) |  |  | 3 |  |
| Balances at end of period | $ | 112 |  |  | $ | 113 |  |  | $ | 225 |  |  | $ | 142 |  |  | $ | 165 |  |  | $ | 307 |  |

[0001571996-21-000063:notes:41]
|  | Nine Months Ended |
|  | October 29, 2021 |  | October 30, 2020 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |  |  |  |  |  |  |  |  |  |  |  |
| Balances at beginning of period | $ | 148 |  |  | $ | 173 |  |  | $ | 321 |  |  | $ | 70 |  |  | $ | 79 |  |  | $ | 149 |  |
| Adjustment for adoption of accounting standard | — |  |  | — |  |  | — |  |  | 40 |  |  | 71 |  |  | 111 |  |
| Charge-offs, net of recoveries | (32) |  |  | (25) |  |  | (57) |  |  | (51) |  |  | (22) |  |  | (73) |  |
| Provision charged to income statement | (4) |  |  | (35) |  |  | (39) |  |  | 83 |  |  | 37 |  |  | 120 |  |
| Balances at end of period | $ | 112 |  |  | $ | 113 |  |  | $ | 225 |  |  | $ | 142 |  |  | $ | 165 |  |  | $ | 307 |  |

[0001571996-21-000063:notes:42]
Aging

[0001571996-21-000063:notes:43]
The following table presents the aging of the Company’s customer financing receivables, gross, including accrued interest, segregated by class, as of the dates indicated:

[0001571996-21-000063:notes:44]
|  | October 29, 2021 |  | January 29, 2021 |
|  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |
|  | (in millions) |
| Revolving — DPA | $ | 485 |  |  | $ | 34 |  |  | $ | 10 |  |  | $ | 529 |  |  | $ | 578 |  |  | $ | 30 |  |  | $ | 13 |  |  | $ | 621 |  |
| Revolving — DBC | 157 |  |  | 16 |  |  | 3 |  |  | 176 |  |  | 157 |  |  | 14 |  |  | 4 |  |  | 175 |  |
| Fixed-term — Consumer and Commercial | 9,063 |  |  | 411 |  |  | 21 |  |  | 9,495 |  |  | 9,192 |  |  | 316 |  |  | 87 |  |  | 9,595 |  |
| Total customer receivables, gross | $ | 9,705 |  |  | $ | 461 |  |  | $ | 34 |  |  | $ | 10,200 |  |  | $ | 9,927 |  |  | $ | 360 |  |  | $ | 104 |  |  | $ | 10,391 |  |

[0001571996-21-000063:notes:45]
Aging is likely to fluctuate as a result of the variability in volume of large transactions entered into over the period, and the administrative processes that accompany those larger transactions.  Aging is also impacted by the timing of the Dell Technologies fiscal period end date, relative to calendar month-end customer payment due dates.  As a result of these factors, fluctuations in aging from period to period do not necessarily indicate a material change in the collectibility of the portfolio.

[0001571996-21-000063:notes:46]
Fixed-term consumer and commercial customer receivables are placed on non-accrual status if principal or interest is past due and considered delinquent, or if there is concern about collectibility of a specific customer receivable.  These receivables identified as doubtful for collectibility may be classified as current for aging purposes.  Aged revolving portfolio customer receivables identified as delinquent are charged-off.  Receivables are moved back to accrual status when the collection of  interest is probable, or the collection of the net investment is no longer doubtful.

[0001571996-21-000063:notes:47]
Credit Quality

[0001571996-21-000063:notes:48]
The following tables present customer receivables, gross, including accrued interest, by credit quality indicator segregated by class and year of origination, as of the dates indicated:

[0001571996-21-000063:notes:49]
|  | October 29, 2021 |
|  | Fixed-term — Consumer and Commercial |  |  |  |  |  |  |
|  | Fiscal Year of Origination |
|  | 2022 |  | 2021 |  | 2020 |  | 2019 |  | 2018 |  | Years Prior |  | Revolving — DPA |  | Revolving — DBC |  | Total |
|  | (in millions) |
| Higher | $ | 2,441 |  |  | $ | 2,055 |  |  | $ | 1,108 |  |  | $ | 297 |  |  | $ | 45 |  |  | $ | 5 |  |  | $ | 135 |  |  | $ | 45 |  |  | $ | 6,131 |  |
| Mid | 765 |  |  | 863 |  |  | 426 |  |  | 126 |  |  | 24 |  |  | 1 |  |  | 163 |  |  | 55 |  |  | 2,423 |  |
| Lower | 486 |  |  | 515 |  |  | 267 |  |  | 60 |  |  | 10 |  |  | 1 |  |  | 231 |  |  | 76 |  |  | 1,646 |  |
| Total | $ | 3,692 |  |  | $ | 3,433 |  |  | $ | 1,801 |  |  | $ | 483 |  |  | $ | 79 |  |  | $ | 7 |  |  | $ | 529 |  |  | $ | 176 |  |  | $ | 10,200 |  |

[0001571996-21-000063:notes:50]
|  | January 29, 2021 |
|  | Fixed-term — Consumer and Commercial |  |  |  |  |  |  |
|  | Fiscal Year of Origination |
|  | 2021 |  | 2020 |  | 2019 |  | 2018 |  | 2017 |  | Years Prior |  | Revolving — DPA |  | Revolving — DBC |  | Total |
|  | (in millions) |
| Higher | $ | 3,125 |  |  | $ | 1,802 |  |  | $ | 661 |  |  | $ | 166 |  |  | $ | 26 |  |  | $ | — |  |  | $ | 172 |  |  | $ | 47 |  |  | $ | 5,999 |  |
| Mid | 1,121 |  |  | 671 |  |  | 287 |  |  | 73 |  |  | 9 |  |  | — |  |  | 188 |  |  | 52 |  |  | 2,401 |  |
| Lower | 865 |  |  | 499 |  |  | 243 |  |  | 38 |  |  | 9 |  |  | — |  |  | 261 |  |  | 76 |  |  | 1,991 |  |
| Total | $ | 5,111 |  |  | $ | 2,972 |  |  | $ | 1,191 |  |  | $ | 277 |  |  | $ | 44 |  |  | $ | — |  |  | $ | 621 |  |  | $ | 175 |  |  | $ | 10,391 |  |

[0001571996-21-000063:notes:51]
The categories shown in the tables above segregate customer receivables based on the relative degrees of credit risk.  The credit quality indicators for DPA revolving accounts are measured primarily as of each quarter-end date, while all other indicators are generally updated on a periodic basis.

[0001571996-21-000063:notes:52]
For DPA revolving receivables shown in the table above, the Company makes credit decisions based on proprietary scorecards, which include the customer’s credit history, payment history, credit usage, and other credit agency-related elements.  The higher quality category includes prime accounts generally of a higher credit quality that are comparable to U.S. customer FICO scores of 720 or above.  The mid-category represents the mid-tier accounts that are comparable to U.S. customer FICO scores from 660 to 719.  The lower category is generally sub-prime and represents lower credit quality accounts that are comparable to U.S. customer FICO scores below 660.  For the DBC revolving receivables and fixed-term commercial receivables shown in the table above, an internal grading system is utilized that assigns a credit level score based on a number of considerations, including liquidity, operating performance, and industry outlook.  The grading criteria and classifications for the fixed-term products differ from those for the revolving products as loss experience varies between these product and customer groups.  The credit quality categories cannot be compared between the different classes as loss experience varies substantially between the classes.

[0001571996-21-000063:notes:53]
Leases

[0001571996-21-000063:notes:54]
Interest income on sales-type lease receivables was $59 million and $69 million for the three months ended October 29, 2021 and October 30, 2020, respectively, and $186 million and $200 million for the nine months ended October 29, 2021, and October 30, 2020, respectively.

[0001571996-21-000063:notes:55]
The following table presents the net revenue, cost of net revenue, and gross margin recognized at the commencement date of sales-type leases for the periods indicated:

[0001571996-21-000063:notes:56]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 29, 2021 |  | October 30, 2020 |  | October 29, 2021 |  | October 30, 2020 |
|  | (in millions) |
| Net revenue — products | $ | 183 |  |  | $ | 184 |  |  | $ | 607 |  |  | $ | 648 |  |
| Cost of net revenue — products | 162 |  |  | 102 |  |  | 467 |  |  | 435 |  |
| Gross margin — products | $ | 21 |  |  | $ | 82 |  |  | $ | 140 |  |  | $ | 213 |  |

[0001571996-21-000063:notes:57]
The following table presents the future maturity of the Company’s fixed-term customer leases and associated financing payments, and reconciles the undiscounted cash flows to the customer receivables, gross recognized on the Condensed Consolidated Statements of Financial Position as of the date indicated:

[0001571996-21-000063:notes:58]
|  | October 29, 2021 |
|  | (in millions) |
| Fiscal 2022 (remaining three months) | $ | 775 |  |
| Fiscal 2023 | 2,207 |  |
| Fiscal 2024 | 1,445 |  |
| Fiscal 2025 | 735 |  |
| Fiscal 2026 and beyond | 335 |  |
| Total undiscounted cash flows | 5,497 |  |
| Fixed-term loans | 4,620 |  |
| Revolving loans | 705 |  |
| Less: unearned income | (622) |  |
| Total customer receivables, gross | $ | 10,200 |  |

[0001571996-21-000063:notes:59]
Operating Leases

[0001571996-21-000063:notes:60]
The following table presents the components of the Company’s operating lease portfolio included in property, plant, and equipment, net as of the dates indicated:

[0001571996-21-000063:notes:61]
|  | October 29, 2021 |  | January 29, 2021 |
|  | (in millions) |
| Equipment under operating lease, gross | $ | 2,367 |  |  | $ | 1,746 |  |
| Less: accumulated depreciation | (787) |  |  | (432) |  |
| Equipment under operating lease, net | $ | 1,580 |  |  | $ | 1,314 |  |

[0001571996-21-000063:notes:62]
The following table presents operating lease income related to lease payments and depreciation expense for the Company’s operating lease portfolio for the periods indicated:

[0001571996-21-000063:notes:63]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 29, 2021 |  | October 30, 2020 |  | October 29, 2021 |  | October 30, 2020 |
|  | (in millions) |
| Income related to lease payments | $187 |  | $120 |  | $510 |  | $310 |
| Depreciation expense | $140 |  | $92 |  | $383 |  | $228 |

[0001571996-21-000063:notes:64]
The following table presents the future payments to be received by the Company as lessor in operating lease contracts as of the date indicated:

[0001571996-21-000063:notes:65]
|  | October 29, 2021 |
|  | (in millions) |
| Fiscal 2022 (remaining three months) | $ | 220 |  |
| Fiscal 2023 | 702 |  |
| Fiscal 2024 | 437 |  |
| Fiscal 2025 | 189 |  |
| Fiscal 2026 and beyond | 21 |  |
| Total | $ | 1,569 |  |

[0001571996-21-000063:notes:66]
DFS Debt

[0001571996-21-000063:notes:67]
The Company maintains programs that facilitate the funding of leases, loans, and other alternative payment structures in the capital markets.  The majority of DFS debt is non-recourse to Dell Technologies and represents borrowings under securitization programs and structured financing programs, for which the Company’s risk of loss is limited to transferred loan and lease payments and associated equipment.  The following table presents DFS debt as of the dates indicated.  The table excludes the allocated portion of the Company’s other borrowings, which represents the additional amount considered to fund the DFS business.

[0001571996-21-000063:notes:68]
|  | October 29, 2021 |  | January 29, 2021 |
|  | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing and securitization facilities | $ | 2,650 |  |  | $ | 3,311 |  |
| Fixed-term securitization offerings | 3,618 |  |  | 2,961 |  |
| Other | 147 |  |  | 140 |  |
| Total DFS U.S. debt | 6,415 |  |  | 6,412 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 751 |  |  | 786 |  |
| Other borrowings | 809 |  |  | 1,006 |  |
| Note payable | 250 |  |  | 250 |  |
| Dell Bank Senior Unsecured Eurobonds | 1,752 |  |  | 1,212 |  |
| Total DFS international debt | 3,562 |  |  | 3,254 |  |
| Total DFS debt | $ | 9,977 |  |  | $ | 9,666 |  |
| Total short-term DFS debt | $ | 5,475 |  |  | $ | 4,888 |  |
| Total long-term DFS debt | $ | 4,502 |  |  | $ | 4,778 |  |

[0001571996-21-000063:notes:69]
DFS U.S. Debt

[0001571996-21-000063:notes:70]
Asset-Based Financing and Securitization Facilities — The Company maintains separate asset-based financing facilities and a securitization facility in the United States, which are revolving facilities for fixed-term leases and loans and for revolving loans, respectively.  This debt is collateralized solely by the U.S. lease and loan payments and associated equipment in the facilities.  The debt has a variable interest rate and the duration of the debt is based on the terms of the underlying loan and lease payment streams.  As of October 29, 2021, the total debt capacity related to the U.S. asset-based financing and securitization facilities was $4.5 billion.  The Company enters into interest swap agreements to effectively convert a portion of this debt from a floating rate to a fixed rate.  See Note 6 of the Notes to the Condensed Consolidated Financial Statements for additional information about interest rate swaps.

[0001571996-21-000063:notes:71]
The Company’s U.S. securitization facility for revolving loans is effective through June 25, 2022.  The Company’s two U.S. asset-based financing facilities for fixed-term leases and loans are effective through July 10, 2023 and July 26, 2022, respectively.

[0001571996-21-000063:notes:72]
The asset-based financing and securitization facilities contain standard structural features related to the performance of the funded receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the facility, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of October 29, 2021, these criteria were met.

[0001571996-21-000063:notes:73]
Fixed-Term Securitization Offerings — The Company periodically issues asset-backed debt securities under fixed-term securitization programs to private investors.  The asset-backed debt securities are collateralized solely by the U.S. fixed-term leases and loans in the offerings, which are held by Special Purpose Entities (“SPEs”), as discussed below.  The interest rate on these securities is fixed and ranges from 0.18% to 5.92% per annum, and the duration of these securities is based on the terms of the underlying loan and lease payment streams.

[0001571996-21-000063:notes:74]
DFS International Debt

[0001571996-21-000063:notes:75]
Securitization Facility — The Company maintains a securitization facility in Europe for fixed-term leases and loans.  This facility is effective through December 21, 2022 and had a total debt capacity of $934 million as of October 29, 2021.

[0001571996-21-000063:notes:76]
The securitization facility contains standard structural features related to the performance of the securitized receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the program, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of October 29, 2021, these criteria were met.

[0001571996-21-000063:notes:77]
Other Borrowings — In connection with the Company’s international financing operations, the Company enters into revolving structured financing debt programs related to its fixed-term lease and loan products sold in Canada, Europe, Australia, and New Zealand.  The Canadian facility, which is collateralized solely by Canadian lease and loan payments and associated equipment, had a total debt capacity of $364 million as of October 29, 2021, and is effective through January 16, 2025.  The European facility, which is collateralized solely by European loan and lease payments and associated equipment, had a total debt capacity of $701 million as of October 29, 2021, and is effective through December 14, 2023.  The Australia and New Zealand facility, which is collateralized solely by Australia and New Zealand loan and lease payments and associated equipment, had a total debt capacity of $339 million as of October 29, 2021, and is effective through April 20, 2023.

[0001571996-21-000063:notes:78]
Note Payable — On August 7, 2020, the Company entered into two new unsecured credit agreements to fund receivables in Mexico.  As of October 29, 2021, the aggregate principal amount of the notes payable was $250 million.  The notes bear interest at an annual rate of 3.37% and will mature on June 1, 2022.

[0001571996-21-000063:notes:79]
Dell Bank Senior Unsecured Eurobonds — On October 17, 2019, Dell Bank International D.A.C., a wholly-owned subsidiary of Dell Technologies Inc., issued 500 million Euro of 0.625% senior unsecured three year eurobonds due October 2022.  On June 24, 2020, Dell Bank International D.A.C. issued 500 million Euro of 1.625% senior unsecured four year eurobonds due June 2024.  On October 27, 2021, Dell Bank International D.A.C. issued 500 million Euro of 0.5% senior unsecured five year eurobonds due October 2026.  The issuances of the senior unsecured eurobonds support the expansion of the financing operations in Europe.

[0001571996-21-000063:notes:80]
Variable Interest Entities

[0001571996-21-000063:notes:81]
In connection with the asset-based financing facilities, securitization facilities, and fixed-term securitization offerings discussed above, the Company transfers certain U.S. and European loan and lease payments and associated equipment to SPEs that meet the definition of a Variable Interest Entity (“VIE”) and are consolidated, along with the associated debt detailed above, into the Condensed Consolidated Financial Statements, as the Company is the primary beneficiary of those VIEs.  The SPEs are bankruptcy-remote legal entities with separate assets and liabilities.  The purpose of the SPEs is to facilitate the funding of customer loan and lease payments and associated equipment in the capital markets.

[0001571996-21-000063:notes:82]
Some of the SPEs have entered into financing arrangements with multi-seller conduits that, in turn, issue asset-backed debt securities in the capital markets.  DFS debt outstanding held by the consolidated VIEs is collateralized by the loan and lease payments and associated equipment.  The Company’s risk of loss related to securitized receivables is limited to the amount by which the Company’s right to receive collections for assets securitized exceeds the amount required to pay interest, principal, and fees and expenses related to the asset-backed securities.  The Company provides credit enhancement to the securitization in the form of over-collateralization.

[0001571996-21-000063:notes:83]
The following table presents financing receivables and equipment under operating leases, net held by the consolidated VIEs as of the dates indicated:

[0001571996-21-000063:notes:84]
|  | October 29, 2021 |  | January 29, 2021 |
|  | (in millions) |
| Assets held by consolidated VIEs |  |  |  |
| Other current assets | $ | 843 |  |  | $ | 838 |  |
| Financing receivables, net of allowance |  |  |  |
| Short-term | $ | 3,467 |  |  | $ | 3,534 |  |
| Long-term | $ | 3,294 |  |  | $ | 3,314 |  |
| Property, plant, and equipment, net | $ | 874 |  |  | $ | 792 |  |
| Liabilities held by consolidated VIEs |  |  |  |
| Debt, net of unamortized debt issuance costs |  |  |  |
| Short-term | $ | 4,180 |  |  | $ | 4,208 |  |
| Long-term | $ | 2,826 |  |  | $ | 2,841 |  |

[0001571996-21-000063:notes:85]
Loan and lease payments and associated equipment transferred via securitization through SPEs were $1.4 billion and $1.6 billion for the three months ended October 29, 2021 and October 30, 2020, respectively, and $4.1 billion and $4.6 billion for the nine months ended October 29, 2021 and October 30, 2020, respectively.

[0001571996-21-000063:notes:86]
Customer Receivables Sales
To manage certain concentrations of customer credit exposure, the Company may sell selected fixed-term customer receivables to unrelated third parties on a periodic basis, without recourse.  The amount of customer receivables sold for this purpose was $180 million and $414 million for the nine months ended October 29, 2021 and October 30, 2020, respectively.  The Company’s continuing involvement in such customer receivables is primarily limited to servicing arrangements.  The transactions are accounted for as sales and, accordingly, the customer receivables are derecognized from the Condensed Consolidated Statements of Financial Position at the time of sale.


## us-gaap:ScheduleOfDebtTableTextBlock

[0001571996-21-000063:notes:87]
The following table presents DFS debt as of the dates indicated.  The table excludes the allocated portion of the Company’s other borrowings, which represents the additional amount considered to fund the DFS business.

[0001571996-21-000063:notes:88]
The following table presents the Company’s outstanding debt as of the dates indicated:

[0001571996-21-000063:notes:89]
|  | October 29, 2021 |  | January 29, 2021 |
|  | (in millions) |
| Secured Debt |  |  |  |
| Senior Secured Credit Facilities: |  |  |  |
| 2.00% Term Loan B-2 Facility due September 2025 (a) | $ | 3,120 |  |  | $ | 3,143 |  |
| 1.84% Term Loan A-6 Facility due March 2024 (a) | 3,134 |  |  | 3,134 |  |
| First Lien Notes: |  |  |  |
| 5.45% due June 2023 (a) | 3,750 |  |  | 3,750 |  |
| 4.00% due July 2024 | 1,000 |  |  | 1,000 |  |
| 5.85% due July 2025 | 1,000 |  |  | 1,000 |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 4.90% due October 2026 | 1,750 |  |  | 1,750 |  |
| 6.10% due July 2027 | 500 |  |  | 500 |  |
| 5.30% due October 2029 | 1,750 |  |  | 1,750 |  |
| 6.20% due July 2030 | 750 |  |  | 750 |  |
| 8.10% due July 2036 | 1,500 |  |  | 1,500 |  |
| 8.35% due July 2046 | 2,000 |  |  | 2,000 |  |
| Unsecured Debt |  |  |  |
| Unsecured Notes and Debentures: |  |  |  |
| 4.625% due April 2021 | — |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| Senior Notes: |  |  |  |
| 5.875% due June 2021 | — |  |  | 1,075 |  |
| 7.125% due June 2024 (a) | 1,625 |  |  | 1,625 |  |
| EMC Notes: |  |  |  |
| 3.375% due June 2023 | — |  |  | 1,000 |  |
| VMware Notes: |  |  |  |
| 2.95% due August 2022 | 1,500 |  |  | 1,500 |  |
| 0.60% due August 2023 | 1,000 |  |  | — |  |
| 1.00% due August 2024 | 1,250 |  |  | — |  |
| 4.50% due May 2025 | 750 |  |  | 750 |  |
| 1.40% due August 2026 | 1,500 |  |  | — |  |
| 4.65% due May 2027 | 500 |  |  | 500 |  |
| 3.90% due August 2027 | 1,250 |  |  | 1,250 |  |
| 1.80% due August 2028 | 750 |  |  | — |  |
| 4.70% due May 2030 | 750 |  |  | 750 |  |
| 2.20% due August 2031 | 1,500 |  |  | — |  |
| DFS Debt (Note 3) | 9,977 |  |  | 9,666 |  |
| Other |  |  |  |
| 2.44% Margin Loan Facility due April 2022 | — |  |  | 4,000 |  |
| Other | 400 |  |  | 235 |  |
| Total debt, principal amount | $ | 48,458 |  |  | $ | 48,480 |  |

[0001571996-21-000063:notes:90]
|  | October 29, 2021 |  | January 29, 2021 |
|  | (in millions) |
| Total debt, principal amount | $ | 48,458 |  |  | $ | 48,480 |  |
| Unamortized discount, net of unamortized premium | (175) |  |  | (194) |  |
| Debt issuance costs | (304) |  |  | (302) |  |
| Total debt, carrying value | $ | 47,979 |  |  | $ | 47,984 |  |
| Total short-term debt, carrying value (b) | $ | 16,280 |  |  | $ | 6,362 |  |
| Total long-term debt, carrying value | $ | 31,699 |  |  | $ | 41,622 |  |

[0001571996-21-000063:notes:91]
(a)    Subsequent to October 29, 2021, the Company used the net proceeds from its $9.3 billion pro rata share of the cash dividend received in connection with the VMware Spin-off, as well as cash on hand, to repay $3.12 billion principal amount of the 2.00% Term Loan B-2 Facility due September 2025, $3.13 billion principal amount of the 1.84% Term Loan A-6 Facility due March 2024, $1.63 billion principal amount of the 7.125% Senior Notes due June 2024, and $1.50 billion principal amount of the 5.45% First Lien Notes due June 2023.

[0001571996-21-000063:notes:92]
(b)    Given the probability of the close of the VMware Spin-off and the Company’s intent and ability to repay, the Company classified $9.4 billion principal amount of debt as short-term liabilities on the Condensed Consolidated Statements of Financial Position as of October 29, 2021.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001571996-21-000063:notes:93]
[same as prior period, unchanged from 0001571996-21-000040:notes:91]

[0001571996-21-000063:notes:94]
The Company enters into leasing transactions in which the Company is the lessee.  These lease contracts are typically classified as operating leases.  The Company’s lease contracts are generally for office buildings used to conduct its business, and the determination of whether such contracts contain leases generally does not require significant estimates or judgments.  The Company also leases certain global logistics warehouses, employee vehicles, and equipment.  As of October 29, 2021, the remaining terms of the Company’s leases range from less than one month to approximately 25 years.

[0001571996-21-000063:notes:95]
[same as prior period, unchanged from 0001571996-21-000040:notes:93]

[0001571996-21-000063:notes:96]
Financial information associated with the Company’s leases in which the Company is the lessee is contained in this Note.  As of both October 29, 2021 and January 29, 2021, there were no material finance leases for which the Company was a lessee.

[0001571996-21-000063:notes:97]
[same as prior period, unchanged from 0001571996-21-000040:notes:95]

[0001571996-21-000063:notes:98]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 29, 2021 |  | October 30, 2020 |  | October 29, 2021 |  | October 30, 2020 |
|  | (in millions) |
| Operating lease costs | $ | 129 |  |  | $ | 129 |  |  | $ | 404 |  |  | $ | 384 |  |
| Variable costs | 35 |  |  | 37 |  |  | 97 |  |  | 113 |  |
| Total lease costs | $ | 164 |  |  | $ | 166 |  |  | $ | 501 |  |  | $ | 497 |  |

[0001571996-21-000063:notes:99]
During both the nine months ended October 29, 2021 and October 30, 2020, sublease income, finance lease costs, and short-term lease costs were immaterial.

[0001571996-21-000063:notes:100]
[same as prior period, unchanged from 0001571996-21-000040:notes:98]

[0001571996-21-000063:notes:101]
|  | Classification | October 29, 2021 |  | January 29, 2021 |  |  |
|  |  | (in millions, except for term and discount rate) |
| Operating lease right of use assets | Other non-current assets | $ | 1,953 |  | $ | 2,117 |  |  |
| Current operating lease liabilities | Accrued and other current liabilities | $ | 439 |  | $ | 436 |  |  |
| Non-current operating lease liabilities | Other non-current liabilities | 1,657 |  | 1,787 |  |  |
| Total operating lease liabilities |  | $ | 2,096 |  | $ | 2,223 |  |  |
| Weighted-average remaining lease term (in years) |  | 8.75 |  | 8.85 |  |  |
| Weighted-average discount rate |  | 3.18 | % |  | 3.47 | % |  |  |

[0001571996-21-000063:notes:102]
[same as prior period, unchanged from 0001571996-21-000040:notes:100]

[0001571996-21-000063:notes:103]
|  | Nine Months Ended |
|  | October 29, 2021 |  | October 30, 2020 |
|  | (in millions) |
| Cash paid for amounts included in the measurement of lease liabilities — operating cash outflows from operating leases | $ | 379 |  |  | $ | 384 |  |
| Right-of-Use assets obtained in exchange for new operating lease liabilities | $ | 232 |  |  | $ | 763 |  |

[0001571996-21-000063:notes:104]
[same as prior period, unchanged from 0001571996-21-000040:notes:102]

[0001571996-21-000063:notes:105]
|  | October 29, 2021 |  |  |
|  | (in millions) |
| Fiscal 2022 (remaining three months) | $ | 111 |  |  |  |
| Fiscal 2023 | 475 |  |  |  |
| Fiscal 2024 | 374 |  |  |  |
| Fiscal 2025 | 276 |  |  |  |
| Fiscal 2026 | 228 |  |  |  |
| Thereafter | 995 |  |  |  |
| Total lease payments | 2,459 |  |  |  |
| Less: Imputed interest | (363) |  |  |  |
| Total | $ | 2,096 |  |  |  |
| Current operating lease liabilities | $ | 439 |  |  |  |
| Non-current operating lease liabilities | $ | 1,657 |  |  |  |

[0001571996-21-000063:notes:106]
[same as prior period, unchanged from 0001571996-21-000040:notes:104]

[0001571996-21-000063:notes:107]
As of October 29, 2021, the Company has additional operating leases that have not yet commenced representing $64 million of undiscounted lease liabilities.  These operating leases will commence in the remaining three months of Fiscal 2022 or Fiscal 2023 with lease terms of one year to 10 years.


## us-gaap:DebtDisclosureTextBlock

[0001571996-21-000063:notes:108]
NOTE 5 — DEBT

[0001571996-21-000063:notes:109]
During the nine months ended October 29, 2021, the net decrease in the Company’s debt balance was primarily due to:

[0001571996-21-000063:notes:110]
•repayment of $1.0 billion principal amount of the 3.375% EMC Notes due June 2023;

[0001571996-21-000063:notes:111]
•repayment of $4.0 billion principal amount of the 2.44% Margin Loan Facility due April 2022;

[0001571996-21-000063:notes:112]
•repayment of $1.1 billion principal amount of the 5.875% Senior Notes due June 2021; and

[0001571996-21-000063:notes:113]
•repayment of $0.4 billion principal amount of the 4.625% Unsecured Notes due April 2021.

[0001571996-21-000063:notes:114]
See Note 18 of the Notes to the Condensed Consolidated Financial Statements for more information about debt repayments that occurred subsequent to October 29, 2021.

[0001571996-21-000063:notes:115]
Secured Debt

[0001571996-21-000063:notes:116]
Senior Secured Credit Facilities — The Company has entered into a credit agreement (the “Existing Credit Agreement”) that provides for senior secured credit facilities (the “Senior Secured Credit Facilities”) comprising (a) term loan facilities and (b) a senior secured Revolving Credit Facility, which provides for a borrowing capacity of up to $4.5 billion for general corporate purposes, including capacity for up to $0.5 billion of letters of credit and for borrowings of up to $0.4 billion under swing-line loans.  The Revolving Credit Facility expires December 20, 2023.

[0001571996-21-000063:notes:117]
As of October 29, 2021, available borrowings under the Revolving Credit Facility totaled $4.5 billion.  The Senior Secured Credit Facilities provide that the borrowers have the right at any time, subject to customary conditions, to request incremental term loans or incremental revolving commitments.

[0001571996-21-000063:notes:118]
On February 18, 2021, the Company entered into an eighth refinancing amendment to the credit agreement for the Senior Secured Credit Facilities to refinance the existing term B loans (the “Original Term B Loans”) with a new term loan B facility consisting of an aggregate principal amount of $3.1 billion refinancing term B-2 loans (the “Refinancing Term B-2 Loans”) maturing on September 19, 2025.  Proceeds from the Refinancing Term B-2 Loans, together with other funds available to the borrowers, were used to repay in full the Original Term B Loans and all accrued and unpaid fees in respect thereof.

[0001571996-21-000063:notes:119]
Except for a change in the interest rate, the Refinancing Term B-2 Loans have substantially the same terms as the Original Term B Loans under the sixth refinancing amendment to the Senior Secured Credit Agreement.  Amortization payments on the Refinancing Term B-2 Loans are equal to 0.25% of the aggregate principal amount of Refinancing Term B-2 Loans outstanding on the effective date of the eighth refinancing amendment, payable at the end of each fiscal quarter, commencing with the fiscal quarter ended April 30, 2021.

[0001571996-21-000063:notes:120]
Borrowings under the Senior Secured Credit Facilities bear interest at a rate per annum equal to an applicable margin, plus, at the borrowers’ option, either (a) a base rate, or (b) the London Interbank Offered Rate (“LIBOR”).  The Term Loan A-6 Facility

[0001571996-21-000063:notes:121]
bears interest at LIBOR plus an applicable margin ranging from 1.25% to 2.00% or a base rate plus an applicable margin ranging from 0.25% to 1.00%.  The Refinancing Term B-2 Loans bear interest at LIBOR plus an applicable margin of 1.75% or a base rate plus an applicable margin of 0.75%.  Interest is payable, in the case of loans bearing interest based on LIBOR, at the end of each interest period (but at least every three months), in arrears and, in the case of loans bearing interest based on the base rate, quarterly in arrears.

[0001571996-21-000063:notes:122]
The Term Loan A-6 Facility amortizes in equal quarterly installments in aggregate annual amounts equal to 5% of the original principal amount in each of the first four years after the facility closing date of March 13, 2019, and 80% of the original principal amount in the fifth year after March 13, 2019.  The Revolving Credit Facility has no amortization.

[0001571996-21-000063:notes:123]
The borrowers may voluntarily repay outstanding loans under the term loan facilities and the Revolving Credit Facility at any time without premium or penalty, other than customary “breakage” costs.

[0001571996-21-000063:notes:124]
All obligations of the borrowers under the Senior Secured Credit Facilities and certain swap agreements, cash management arrangements, and certain letters of credit provided by any lender or agent party to the Senior Secured Credit Facilities or any of its affiliates and certain other persons are secured by (a) a first-priority security interest in certain tangible and intangible assets of the borrowers and the guarantors and (b) a first-priority pledge of 100% of the capital stock of the borrowers, Dell Inc., a wholly-owned subsidiary of the Company (“Dell”), and each wholly-owned material restricted subsidiary of the borrowers and the guarantors, in each case subject to certain thresholds, exceptions, and permitted liens.

[0001571996-21-000063:notes:125]
Subsequent to October 29, 2021, the Company repaid the remaining $3.12 billion principal amount of the Term B-2 Loans and the remaining $3.13 billion principal amount of the Term Loan A-6 Facility.  On November 1, 2021, the Company entered into a new senior secured Revolving Credit Facility (the “2021 Revolving Credit Facility”) to replace the old senior secured Revolving Credit Facility under the Existing Credit Agreement.  Following the full redemption of the outstanding term loan facilities and placement of the Revolving Credit Facility, the Existing Credit Agreement was terminated.  See Note 18 of the Notes to the Condensed Consolidated Financial Statements for more information.

[0001571996-21-000063:notes:126]
First Lien Notes — Dell International L.L.C. and EMC Corporation (collectively, the “Issuers”), both of which are wholly-owned subsidiaries of Dell Technologies Inc., completed offerings of multiple series of senior secured notes (collectively, the “First Lien Notes”) pursuant to Rule 144A and Regulation S. Various series of the First Lien Notes were issued on June 1, 2016, March 20, 2019, and April 9, 2020 in aggregate principal amounts of $20.0 billion, $4.5 billion, and $2.25 billion, respectively.  Interest on the First Lien Notes is payable semiannually.  The First Lien Notes are secured on an equal and ratable basis with the Senior Secured Credit Facilities by substantially all of the tangible and intangible assets of the issuers and guarantors that secure obligations under the Senior Secured Credit Facilities, including pledges of all capital stock of the issuers, Dell, and certain wholly-owned material subsidiaries of the issuers and the guarantors, subject to certain exceptions.

[0001571996-21-000063:notes:127]
In June 2021, Dell International L.L.C and EMC Corporation completed the previously announced offers to exchange any and all outstanding First Lien Notes for registered first lien notes having terms substantially identical to the terms of the First Lien Notes.  The Issuers issued an aggregate $18.4 billion principal amount of registered first lien notes in exchange for the same principal amount of First Lien Notes.  The aggregate principal amount of unregistered First Lien Notes remaining outstanding following the settlement of the exchange offers was approximately $0.1 billion.  Following the exchange offer, such registered first lien notes, together with the remaining unregistered First Lien Notes, are collectively referred to as “First Lien Notes” in these Notes to the Condensed Consolidated Financial Statements.

[0001571996-21-000063:notes:128]
Subsequent to October 29, 2021, the Company repaid $1.5 billion principal amount of First Lien Notes.  Further, in conjunction with the termination of the Existing Credit Agreement, the tangible and intangible assets of the issuers and guarantors that secure obligations under the Senior Secured Credit Facilities were released as collateral and the First Lien Notes became fully unsecured.  See Note 18 of the Notes to the Condensed Consolidated Financial Statements for more information about the First Lien Notes principal repayment subsequent to October 29, 2021.

[0001571996-21-000063:notes:129]
Unsecured Debt

[0001571996-21-000063:notes:130]
Unsecured Notes and Debentures — The Company has outstanding unsecured notes and debentures (collectively, the “Unsecured Notes and Debentures”) that were issued by Dell prior to the acquisition of Dell by Dell Technologies Inc. in the going-private transaction that closed in October 2013.  Interest on outstanding borrowings is payable semiannually.

[0001571996-21-000063:notes:131]
Senior Notes — The senior unsecured notes (collectively, the “Senior Notes”) were issued on June 22, 2016 in an aggregate principal amount of $3.3 billion.  Interest on outstanding borrowings is payable semiannually.  Subsequent to October 29, 2021, the Company repaid the remaining $1.63 billion principal amount of Senior Notes.  Following the full redemption of the Senior Note, the indenture governing the Senior Notes was terminated.  See Note 18 of the Notes to the Condensed Consolidated Financial Statements for more information about the Senior Notes principal repayment subsequent to October 29, 2021.

[0001571996-21-000063:notes:132]
EMC Notes — On September 7, 2016, as result of the merger with EMC, Dell acquired multiple outstanding Notes (collectively, the “EMC Notes”).  During the three months ended October 29, 2021, the Company repaid the remaining  $1.0 billion principal amount of the EMC Notes.

[0001571996-21-000063:notes:133]
VMware Notes — VMware, Inc. completed public offerings of unsecured senior notes in the aggregate amounts of $4.0 billion, $2.0 billion, and $6.0 billion on August 21, 2017, April 7, 2020, and August 2, 2021, respectively (the “VMware Notes”).   None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.  Interest on outstanding borrowings is payable semiannually.

[0001571996-21-000063:notes:134]
VMware Revolving Credit Facility and Term Loan Facilities — On September 12, 2017, VMware, Inc. entered into an unsecured credit agreement, that established a revolving credit facility (the “VMware Revolving Credit Facility”) with a syndicate of lenders that provided the company with a borrowing capacity of up to $1.0 billion for VMware, Inc. general corporate purposes.  On September 2, 2021, VMware, Inc. entered into an unsecured credit agreement establishing a revolving credit facility with a syndicate of lenders that provides VMware, Inc. with a borrowing capacity of up to $1.5 billion for general corporate purposes (the “2021 VMware Revolving Credit Facility”).  The 2021 VMware Revolving Credit Facility replaced VMware, Inc.’s existing $1.0 billion revolving credit facility that was undrawn.  Commitments under the 2021 Revolving Credit Facility are available for a period of five years, which may be extended, subject to the satisfaction of certain conditions, by up to two one-year periods.  The credit agreement contains certain representations, warranties and covenants.  Commitment fees, interest rates and other terms of borrowing under the 2021 Revolving Credit Facility may vary based on VMware’s external credit ratings.  As of October 29, 2021, there were no outstanding borrowings under the 2021 VMware Revolving Credit Facility.

[0001571996-21-000063:notes:135]
In addition, VMware, Inc. received commitments from financial institutions for a 3-year senior unsecured term loan facility and a 5-year senior unsecured term loan facility that would provide VMware, Inc. with a borrowing capacity of up to $4.0 billion (the “VMware Term Loan Facilities”).  VMware, Inc. may borrow against the term loan once up to its borrowing capacity of $4.0 billion.  Subsequent to October 29, 2021, and in advance of the close of the VMware Spin-off on November 1, 2021, VMware, Inc. borrowed $4.0 billion against the VMware Term Loan Facilities with the proceeds utilized to fund a portion of the special cash dividend paid by VMware, Inc. in connection with the VMware Spin-off transaction.  See Note 18 of the Notes to the Condensed Consolidated Financial Statements for more information about the VMware Spin-off transaction.

[0001571996-21-000063:notes:136]
None of the net proceeds of the 2021 VMware Revolving Credit Facility or the VMware Term Loan Facilities will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.

[0001571996-21-000063:notes:137]
See Note 3 and Note 6 of the Notes to the Condensed Consolidated Financial Statements, respectively, for discussion of DFS debt and the interest rate swap agreements that hedge a portion of that debt.

[0001571996-21-000063:notes:138]
Other

[0001571996-21-000063:notes:139]
Margin Loan Facility — On April 12, 2017, the Company entered into the Margin Loan Facility in an aggregate principal amount of $2.0 billion.  In connection with the Class V transaction described in Note 1 of the Notes to the Condensed Consolidated Financial Statements, on December 20, 2018, the Company amended the Margin Loan Facility to increase the aggregate principal amount to $3.4 billion.  In connection with obtaining the Term Loan A-6 Facility during the fiscal year ended January 31, 2020, the Company increased the aggregate principal amount of the Margin Loan Facility to $4.0 billion.  VMware Holdco LLC, a wholly-owned subsidiary of EMC, was the borrower under the Margin Loan Facility, which was secured by approximately 76 million shares of Class B common stock of VMware, Inc. and approximately 24 million shares of Class A common stock of VMware, Inc.

[0001571996-21-000063:notes:140]
Loans under the Margin Loan Facility bore interest at a rate per annum payable, at the borrower’s option, either at (a) a base rate plus 1.25% per annum or (b) a LIBOR-based rate plus 2.25% per annum.  Interest under the Margin Loan Facility was payable quarterly.  The Margin Loan Facility was scheduled to mature in April 2022.  The borrower had the option to  voluntarily repay outstanding loans under the Margin Loan Facility at any time without premium or penalty, other than customary “breakage” costs, subject to certain minimum threshold amounts for prepayment.  During the nine months ended October 29, 2021, the Company repaid the $4.0 billion principal amount of the Margin Loan Facility.  Upon repayment, the VMware, Inc. common stock pledged to secure the Margin Loan Facility was released as collateral in accordance with the associated Margin Loan Facility agreement.

[0001571996-21-000063:notes:141]
Aggregate Future Maturities

[0001571996-21-000063:notes:142]
The following table presents the aggregate future maturities of the Company’s debt as of October 29, 2021 for the periods indicated:

[0001571996-21-000063:notes:143]
|  | Maturities by Fiscal Year (a) |
|  | 2022(remaining three months) |  | 2023 |  | 2024 |  | 2025 |  | 2026 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Secured Credit Facilities and First Lien Notes | $ | 7,754 |  |  | $ | — |  |  | $ | 2,250 |  |  | $ | 1,000 |  |  | $ | 1,000 |  |  | $ | 12,750 |  |  | $ | 24,754 |  |
| Unsecured Notes and Debentures | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 952 |  |  | 952 |  |
| Senior Notes and EMC Notes | 1,625 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 1,625 |  |
| VMware Notes | — |  |  | 1,500 |  |  | 1,000 |  |  | 1,250 |  |  | 750 |  |  | 6,250 |  |  | 10,750 |  |
| DFS Debt | 1,378 |  |  | 5,019 |  |  | 1,888 |  |  | 1,016 |  |  | 86 |  |  | 590 |  |  | 9,977 |  |
| Other | 9 |  |  | 33 |  |  | 187 |  |  | 124 |  |  | 23 |  |  | 24 |  |  | 400 |  |
| Total maturities, principal amount | 10,766 |  |  | 6,552 |  |  | 5,325 |  |  | 3,390 |  |  | 1,859 |  |  | 20,566 |  |  | 48,458 |  |
| Associated carrying value adjustments | (94) |  |  | (7) |  |  | (20) |  |  | (20) |  |  | (6) |  |  | (332) |  |  | (479) |  |
| Total maturities, carrying value amount | $ | 10,672 |  |  | $ | 6,545 |  |  | $ | 5,305 |  |  | $ | 3,370 |  |  | $ | 1,853 |  |  | $ | 20,234 |  |  | $ | 47,979 |  |

[0001571996-21-000063:notes:144]
(a) Maturities by Fiscal Year reflects $9.4 billion principal amount of debt within the remaining three months of Fiscal 2022 to align to the classification of this debt as short-term on the Condensed Consolidated Statements of Financial Position and reflect the Company’s intent to repay during the fourth quarter of Fiscal 2022.

[0001571996-21-000063:notes:145]
Covenants and Unrestricted Net Assets — The credit agreement for the Senior Secured Credit Facilities contains customary negative covenants that generally limit the ability of Denali Intermediate Inc., a wholly-owned subsidiary of Dell Technologies (“Denali Intermediate”), Dell, and Dell’s and Denali Intermediate’s other restricted subsidiaries to incur debt, create liens, make fundamental changes, enter into asset sales, make certain investments, pay dividends or distribute or redeem certain equity interests, prepay or redeem certain debt, and enter into certain transactions with affiliates.  The indenture governing the Senior Notes contains customary negative covenants that generally limit the ability of Denali Intermediate, Dell, and Dell’s and Denali Intermediate’s other restricted subsidiaries to incur additional debt or issue certain preferred shares, pay dividends on or make other distributions in respect of capital stock or make other restricted payments, make certain investments, sell or transfer certain assets, create liens on certain assets to secure debt, consolidate, merge, sell, or otherwise dispose of all or substantially all assets, enter into certain transactions with affiliates, and designate subsidiaries as unrestricted subsidiaries.  The negative covenants under such credit agreements and indenture are subject to certain exceptions, qualifications, and “baskets.”  The indentures governing the First Lien Notes, the Unsecured Notes and Debentures, and the EMC Notes variously impose limitations, subject to specified exceptions, on creating certain liens, entering into sale and lease-back transactions, and entering into certain asset sales.  The foregoing credit agreements and indentures contain customary events of default, including failure to make required payments, failure to comply with covenants, and the occurrence of certain events of bankruptcy and insolvency.

[0001571996-21-000063:notes:146]
As of October 29, 2021, the Company had certain consolidated subsidiaries that were designated as unrestricted subsidiaries for all purposes of the applicable credit agreements and the indentures governing the First Lien Notes and the Senior Notes.  Substantially all of the net assets of the Company’s consolidated subsidiaries were restricted, with the exception of the Company’s unrestricted subsidiaries, primarily VMware, Inc., Secureworks, and their respective subsidiaries, as of October 29, 2021.

[0001571996-21-000063:notes:147]
The Senior Secured Credit Facilities and the Revolving Credit Facility are subject to a first lien leverage ratio covenant that is tested at the end of each fiscal quarter of Dell with respect to Dell’s preceding four fiscal quarters.  The Company was in compliance with all financial covenants as of October 29, 2021.

[0001571996-21-000063:notes:148]
Subsequent to October 29, 2021 and following the full redemption of the outstanding term loan facilities and Senior Notes, the Existing Credit Agreement and the indenture governing the Senior Notes were terminated.  The 2021 Revolving Credit Facility contains customary negative covenants that generally limit the ability of Dell, Dell International L.L.C, and EMC to create liens and make fundamental changes.  The 2021 Revolving Credit Facility is subject to an interest coverage ratio covenant that is tested at the end of each fiscal quarter of Dell with respect to Dell’s preceding four fiscal quarters.  See Note 18 of the Notes to the Condensed Consolidated Financial Statements for more information about debt repayments that occurred subsequent to October 29, 2021.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001571996-21-000063:notes:149]
[same as prior period, unchanged from 0001571996-21-000040:notes:139]

[0001571996-21-000063:notes:150]
[same as prior period, unchanged from 0001571996-21-000040:notes:140]

[0001571996-21-000063:notes:151]
[same as prior period, unchanged from 0001571996-21-000040:notes:141]

[0001571996-21-000063:notes:152]
[same as prior period, unchanged from 0001571996-21-000040:notes:142]

[0001571996-21-000063:notes:153]
[same as prior period, unchanged from 0001571996-21-000040:notes:143]

[0001571996-21-000063:notes:154]
During the three and nine months ended October 29, 2021 and October 30, 2020, the Company did not discontinue any cash flow hedges related to foreign exchange contracts that had a material impact on the Company’s results of operations due to the probability that the forecasted cash flows would not occur.

[0001571996-21-000063:notes:155]
[same as prior period, unchanged from 0001571996-21-000040:notes:145]

[0001571996-21-000063:notes:156]
[same as prior period, unchanged from 0001571996-21-000040:notes:146]

[0001571996-21-000063:notes:157]
[same as prior period, unchanged from 0001571996-21-000040:notes:147]

[0001571996-21-000063:notes:158]
The Company uses interest rate swaps to hedge the variability in cash flows related to the interest rate payments on structured financing debt.  The interest rate swaps economically convert the variable rate on the structured financing debt to a fixed interest rate to match the underlying fixed rate being received on fixed-term customer leases and loans.  These contracts are not designated for hedge accounting and most expire within four years or less.

[0001571996-21-000063:notes:159]
[same as prior period, unchanged from 0001571996-21-000040:notes:149]

[0001571996-21-000063:notes:160]
The Company utilizes cross currency amortizing swaps to hedge the currency and interest rate risk exposure associated with the European securitization program.  The cross currency swaps combine a Euro-based interest rate swap with a British Pound or U.S. Dollar foreign exchange forward contract in which the Company pays a fixed British Pound or U.S. Dollar amount and receives a floating amount in Euros linked to the one-month Euribor.  The notional value of the swaps amortizes in line with the expected cash flows and run-off of the securitized assets.  The swaps are not designated for hedge accounting and expire within five years or less.

[0001571996-21-000063:notes:161]
[same as prior period, unchanged from 0001571996-21-000040:notes:151]

[0001571996-21-000063:notes:162]
[same as prior period, unchanged from 0001571996-21-000040:notes:152]

[0001571996-21-000063:notes:163]
|  | October 29, 2021 |  | January 29, 2021 |
|  | (in millions) |
| Foreign exchange contracts: |  |  |  |
| Designated as cash flow hedging instruments | $ | 8,354 |  |  | $ | 6,840 |  |
| Non-designated as hedging instruments | 9,570 |  |  | 9,890 |  |
| Total | $ | 17,924 |  |  | $ | 16,730 |  |
| Interest rate contracts: |  |  |  |
| Non-designated as hedging instruments | $ | 6,393 |  |  | $ | 5,859 |  |

[0001571996-21-000063:notes:164]
[same as prior period, unchanged from 0001571996-21-000040:notes:154]

[0001571996-21-000063:notes:165]
| Derivatives in Cash Flow Hedging Relationships |  | Gain (Loss) Recognized in Accumulated OCI, Net of Tax, on Derivatives |  | Location of Gain (Loss) Reclassified from Accumulated OCI into Income |  | Gain (Loss) Reclassified from Accumulated OCI into Income |  |  |  |  |
|  |  | (in millions) |  |  |  | (in millions) |  |  |  |  |
| For the three months ended October 29, 2021 |  |  |  |  |
|  |  |  |  | Total net revenue |  | $ | 66 |  |  |  |  |  |
| Foreign exchange contracts |  | $ | 86 |  |  | Total cost of net revenue |  | 8 |  |  |  |  |  |
| Interest rate contracts |  | — |  |  | Interest and other, net |  | — |  |  |  |  |  |
| Total |  | $ | 86 |  |  |  |  | $ | 74 |  |  |  |  |  |
| For the three months ended October 30, 2020 |  |  |  |  |
|  |  |  |  | Total net revenue |  | $ | (88) |  |  |  |  |  |
| Foreign exchange contracts |  | $ | 45 |  |  | Total cost of net revenue |  | 4 |  |  |  |  |  |
| Interest rate contracts |  | — |  |  | Interest and other, net |  | — |  |  |  |  |  |
| Total |  | $ | 45 |  |  |  |  | $ | (84) |  |  |  |  |  |
| For the nine months ended October 29, 2021 |  |  |  |  |
|  |  |  |  | Total net revenue |  | $ | 31 |  |  |  |  |  |
| Foreign exchange contracts |  | $ | 150 |  |  | Total cost of net revenue |  | 3 |  |  |  |  |  |
| Interest rate contracts |  | — |  |  | Interest and other, net |  | — |  |  |  |  |  |
| Total |  | $ | 150 |  |  |  |  | $ | 34 |  |  |  |  |  |
| For the nine months ended October 30, 2020 |  |  |  |  |
|  |  |  |  | Total net revenue |  | $ | 17 |  |  |  |  |  |
| Foreign exchange contracts |  | $ | (45) |  |  | Total cost of net revenue |  | 7 |  |  |  |  |  |
| Interest rate contracts |  | — |  |  | Interest and other, net |  | — |  |  |  |  |  |
| Total |  | $ | (45) |  |  |  |  | $ | 24 |  |  |  |  |  |

[0001571996-21-000063:notes:166]
[same as prior period, unchanged from 0001571996-21-000040:notes:156]

[0001571996-21-000063:notes:167]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |  |
|  |  | October 29, 2021 |  | October 30, 2020 |  |  | October 29, 2021 |  | October 30, 2020 |  | Location of Gain (Loss) Recognized |
|  |  | (in millions) |  |  |
| Gain (Loss) Recognized: |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | (85) |  |  | $ | (127) |  |  |  | $ | (242) |  |  | $ | 87 |  |  | Interest and other, net |
| Interest rate contracts |  | 4 |  |  | 1 |  |  |  | 1 |  |  | (43) |  |  | Interest and other, net |
| Total |  | $ | (81) |  |  | $ | (126) |  |  |  | $ | (241) |  |  | $ | 44 |  |  |  |

[0001571996-21-000063:notes:168]
[same as prior period, unchanged from 0001571996-21-000040:notes:158]

[0001571996-21-000063:notes:169]
[same as prior period, unchanged from 0001571996-21-000040:notes:159]

[0001571996-21-000063:notes:170]
|  | October 29, 2021 |
|  | Other CurrentAssets |  | Other Non-Current Assets |  | Other CurrentLiabilities |  | Other Non-CurrentLiabilities |  | TotalFair Value |
|  | (in millions) |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts in an asset position | $ | 112 |  |  | $ | — |  |  | $ | 8 |  |  | $ | — |  |  | $ | 120 |  |
| Foreign exchange contracts in a liability position | (19) |  |  | — |  |  | (12) |  |  | — |  |  | (31) |  |
| Net asset (liability) | 93 |  |  | — |  |  | (4) |  |  | — |  |  | 89 |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts in an asset position | 244 |  |  | — |  |  | 25 |  |  | — |  |  | 269 |  |
| Foreign exchange contracts in a liability position | (159) |  |  | — |  |  | (82) |  |  | (7) |  |  | (248) |  |
| Interest rate contracts in an asset position | — |  |  | 17 |  |  | — |  |  | — |  |  | 17 |  |
| Interest rate contracts in a liability position | — |  |  | — |  |  | — |  |  | (32) |  |  | (32) |  |
| Net asset (liability) | 85 |  |  | 17 |  |  | (57) |  |  | (39) |  |  | 6 |  |
| Total derivatives at fair value | $ | 178 |  |  | $ | 17 |  |  | $ | (61) |  |  | $ | (39) |  |  | $ | 95 |  |
|  | January 29, 2021 |
|  | Other CurrentAssets |  | Other Non-Current Assets |  | Other CurrentLiabilities |  | Other Non-CurrentLiabilities |  | TotalFair Value |
|  | (in millions) |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts in an asset position | $ | 28 |  |  | $ | — |  |  | $ | 18 |  |  | $ | — |  |  | $ | 46 |  |
| Foreign exchange contracts in a liability position | (10) |  |  | — |  |  | (15) |  |  | — |  |  | (25) |  |
| Net asset (liability) | 18 |  |  | — |  |  | 3 |  |  | — |  |  | 21 |  |
| Derivatives not designated as hedging instruments: |
| Foreign exchange contracts in an asset position | 184 |  |  | — |  |  | 58 |  |  | — |  |  | 242 |  |
| Foreign exchange contracts in a liability position | (108) |  |  | — |  |  | (159) |  |  | (4) |  |  | (271) |  |
| Interest rate contracts in an asset position | — |  |  | 10 |  |  | — |  |  | — |  |  | 10 |  |
| Interest rate contracts in a liability position | — |  |  | — |  |  | — |  |  | (31) |  |  | (31) |  |
| Net asset (liability) | 76 |  |  | 10 |  |  | (101) |  |  | (35) |  |  | (50) |  |
| Total derivatives at fair value | $ | 94 |  |  | $ | 10 |  |  | $ | (98) |  |  | $ | (35) |  |  | $ | (29) |  |

[0001571996-21-000063:notes:171]
[same as prior period, unchanged from 0001571996-21-000040:notes:161]

[0001571996-21-000063:notes:172]
|  | October 29, 2021 |
|  | Gross Amounts of Recognized Assets/ (Liabilities) |  | Gross Amounts Offset in the Statement of Financial Position |  | Net Amounts of Assets/ (Liabilities) Presented in the Statement of Financial Position |  | Gross Amounts not Offset in the Statement of Financial Position |  | Net Amount of Assets/ (Liabilities) Recognized in the Statement of Financial Position |
|  | Financial Instruments |  | Cash Collateral Received or Pledged |  |
|  | (in millions) |
| Derivative instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Financial assets | $ | 406 |  |  | $ | (211) |  |  | $ | 195 |  |  | $ | — |  |  | $ | — |  |  | $ | 195 |  |
| Financial liabilities | (311) |  |  | 211 |  |  | (100) |  |  | — |  |  | 21 |  |  | (79) |  |
| Total derivative instruments | $ | 95 |  |  | $ | — |  |  | $ | 95 |  |  | $ | — |  |  | $ | 21 |  |  | $ | 116 |  |
|  | January 29, 2021 |
|  | Gross Amounts of Recognized Assets/ (Liabilities) |  | Gross Amounts Offset in the Statement of Financial Position |  | Net Amounts of Assets/ (Liabilities) Presented in the Statement of Financial Position |  | Gross Amounts not Offset in the Statement of Financial Position |  | Net Amount of Assets/ (Liabilities) Recognized in the Statement of Financial Position |
|  | Financial Instruments |  | Cash Collateral Received or Pledged |  |
|  | (in millions) |
| Derivative instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Financial assets | $ | 298 |  |  | $ | (194) |  |  | $ | 104 |  |  | $ | — |  |  | $ | — |  |  | $ | 104 |  |
| Financial liabilities | (327) |  |  | 194 |  |  | (133) |  |  | — |  |  | 2 |  |  | (131) |  |
| Total derivative instruments | $ | (29) |  |  | $ | — |  |  | $ | (29) |  |  | $ | — |  |  | $ | 2 |  |  | $ | (27) |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001571996-21-000063:notes:173]
[same as prior period, unchanged from 0001571996-21-000040:notes:163]

[0001571996-21-000063:notes:174]
[same as prior period, unchanged from 0001571996-21-000040:notes:164]

[0001571996-21-000063:notes:175]
The Infrastructure Solutions Group, Client Solutions Group, and VMware reporting units are consistent with the reportable segments identified in Note 16 of the Notes to the Condensed Consolidated Financial Statements.  Other businesses consists of Secureworks and Virtustream which each represent separate reporting units.

[0001571996-21-000063:notes:176]
[same as prior period, unchanged from 0001571996-21-000040:notes:166]

[0001571996-21-000063:notes:177]
|  | Infrastructure Solutions Group |  | Client Solutions Group |  | VMware |  | Other Businesses |  | Total |
|  | (in millions) |
| Balance as of January 29, 2021 | $ | 15,324 |  |  | $ | 4,237 |  |  | $ | 20,802 |  |  | $ | 466 |  |  | $ | 40,829 |  |
| Goodwill acquired | — |  |  | — |  |  | (1) |  |  | — |  |  | (1) |  |
| Impact of foreign currency translation | (88) |  |  | — |  |  | — |  |  | — |  |  | (88) |  |
| Goodwill divested (a) | — |  |  | — |  |  | — |  |  | (39) |  |  | (39) |  |
| Balance as of October 29, 2021 | $ | 15,236 |  |  | $ | 4,237 |  |  | $ | 20,801 |  |  | $ | 427 |  |  | $ | 40,701 |  |

[0001571996-21-000063:notes:178]
(a)    During the three months ended October 29, 2021, Dell Technologies completed its sale of Boomi.  Prior to the divestiture, Boomi was included within Other businesses.  See Note 1 of the Notes to the Condensed Consolidated Financial Statements for additional information about the divestiture of Boomi.

[0001571996-21-000063:notes:179]
[same as prior period, unchanged from 0001571996-21-000040:notes:174]

[0001571996-21-000063:notes:180]
[same as prior period, unchanged from 0001571996-21-000040:notes:175]

[0001571996-21-000063:notes:181]
|  | October 29, 2021 |  | January 29, 2021 |
|  | Gross |  | AccumulatedAmortization |  | Net |  | Gross |  | AccumulatedAmortization |  | Net |
|  | (in millions) |
| Customer relationships | $ | 22,387 |  |  | $ | (16,672) |  |  | $ | 5,715 |  |  | $ | 22,394 |  |  | $ | (15,448) |  |  | $ | 6,946 |  |
| Developed technology | 15,479 |  |  | (12,939) |  |  | 2,540 |  |  | 15,488 |  |  | (12,136) |  |  | 3,352 |  |
| Trade names | 1,286 |  |  | (977) |  |  | 309 |  |  | 1,285 |  |  | (909) |  |  | 376 |  |
| Definite-lived intangible assets | 39,152 |  |  | (30,588) |  |  | 8,564 |  |  | 39,167 |  |  | (28,493) |  |  | 10,674 |  |
| Indefinite-lived trade names | 3,755 |  |  | — |  |  | 3,755 |  |  | 3,755 |  |  | — |  |  | 3,755 |  |
| Total intangible assets | $ | 42,907 |  |  | $ | (30,588) |  |  | $ | 12,319 |  |  | $ | 42,922 |  |  | $ | (28,493) |  |  | $ | 14,429 |  |

[0001571996-21-000063:notes:182]
Amortization expense related to definite-lived intangible assets was approximately $0.7 billion and $0.8 billion for the three months ended October 29, 2021 and October 30, 2020, respectively, and $2.1 billion and $2.5 billion for the nine months ended October 29, 2021 and October 30, 2020, respectively.  There were no material impairment charges related to intangible assets during the three and nine months ended October 29, 2021 or October 30, 2020.

[0001571996-21-000063:notes:183]
[same as prior period, unchanged from 0001571996-21-000040:notes:178]

[0001571996-21-000063:notes:184]
[same as prior period, unchanged from 0001571996-21-000040:notes:179]

[0001571996-21-000063:notes:185]
|  | October 29, 2021 |
|  | (in millions) |
| Fiscal 2022 (remaining three months) | $ | 589 |  |
| Fiscal 2023 | 1,826 |  |
| Fiscal 2024 | 1,458 |  |
| Fiscal 2025 | 1,107 |  |
| Fiscal 2026 | 858 |  |
| Thereafter | 2,726 |  |
| Total | $ | 8,564 |  |

[0001571996-21-000063:notes:186]
Goodwill and Intangible Assets Impairment Testing

[0001571996-21-000063:notes:187]
Goodwill and indefinite-lived intangible assets are tested for impairment annually during the third fiscal quarter and whenever events or circumstances may indicate that an impairment has occurred.

[0001571996-21-000063:notes:188]
For the annual impairment review in the third quarter of Fiscal 2022, the Company elected to bypass the assessment of qualitative factors to determine whether it was more likely than not that the fair value of a reporting unit was less than its carrying amount, including goodwill.  In electing to bypass the qualitative assessment, the Company proceeded directly to performing a quantitative goodwill impairment test to measure the fair value of each goodwill reporting unit relative to its carrying amount, and to determine the amount of goodwill impairment loss to be recognized, if any.

[0001571996-21-000063:notes:189]
Management exercised significant judgment related to the above assessment, including the identification of goodwill reporting units, assignment of assets and liabilities to goodwill reporting units, assignment of goodwill to reporting units, and determination of the fair value of each goodwill reporting unit.  The fair value of each goodwill reporting unit is generally estimated using a combination of public company multiples and discounted cash flow methodologies, unless the reporting unit relates to a publicly-traded entity (VMware, Inc. or Secureworks), in which case the fair value is determined based primarily on the public company market valuation.  The discounted cash flow and public company multiples methodologies require significant judgment, including estimation of future revenues, gross margins, and operating expenses, which are dependent on internal forecasts, current and anticipated economic conditions and trends, selection of market multiples through assessment of the reporting unit’s performance relative to peer competitors, the estimation of the long-term revenue growth rate and discount rate of the Company’s business, and the determination of the Company’s weighted average cost of capital.  Changes in these estimates and assumptions could materially affect the fair value of the goodwill reporting unit, potentially resulting in a non-cash impairment charge.

[0001571996-21-000063:notes:190]
[same as prior period, unchanged from 0001571996-21-000040:notes:173]

[0001571996-21-000063:notes:191]
Based on the results of the annual impairment test performed during the three months ended October 29, 2021, the fair values of each of the reporting units exceeded their carrying values.  No impairment test was performed during the nine months ended October 29, 2021 other than the Company’s annual impairment review.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001571996-21-000063:notes:192]
[same as prior period, unchanged from 0001571996-21-000040:notes:181]

[0001571996-21-000063:notes:193]
[same as prior period, unchanged from 0001571996-21-000040:notes:182]

[0001571996-21-000063:notes:194]
[same as prior period, unchanged from 0001571996-21-000040:notes:183]

[0001571996-21-000063:notes:195]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 29, 2021 |  | October 30, 2020 |  | October 29, 2021 |  | October 30, 2020 |
|  | (in millions) |
| Deferred revenue: |  |  |  |  |  |  |  |
| Deferred revenue at beginning of period | $ | 31,843 |  |  | $ | 28,791 |  |  | $ | 30,801 |  |  | $ | 27,800 |  |
| Revenue deferrals | 5,706 |  |  | 5,432 |  |  | 18,889 |  |  | 17,560 |  |
| Revenue recognized | (6,095) |  |  | (5,542) |  |  | (18,092) |  |  | (16,418) |  |
| Other (a) | — |  |  | — |  |  | (144) |  |  | (261) |  |
| Deferred revenue at end of period | $ | 31,454 |  |  | $ | 28,681 |  |  | $ | 31,454 |  |  | $ | 28,681 |  |
| Short-term deferred revenue | $ | 16,569 |  |  | $ | 15,259 |  |  | $ | 16,569 |  |  | $ | 15,259 |  |
| Long-term deferred revenue | $ | 14,885 |  |  | $ | 13,422 |  |  | $ | 14,885 |  |  | $ | 13,422 |  |

[0001571996-21-000063:notes:196]
(a) For the nine months ended October 29, 2021, Other consists of divested deferred revenue from the sale of Boomi.  For the nine months ended October 30, 2020, Other consists of divested deferred revenue from the sale of RSA Security.  See Note 1 of the Notes to the Condensed Consolidated Financial Statements for more information about the divestitures of Boomi and of RSA Security.  There was no impact to deferred revenue for the three months ended October 29, 2021 or October 30, 2020 as liabilities in both instances were previously classified as held for sale.

[0001571996-21-000063:notes:197]
Remaining Performance Obligations — Remaining performance obligations represent the aggregate amount of the transaction price allocated to performance obligations not delivered, or partially undelivered, as of the end of the reporting period.  Remaining performance obligations include deferred revenue plus unbilled amounts not yet recorded in deferred revenue.  The value of the transaction price allocated to remaining performance obligations as of October 29, 2021 was approximately $47 billion.  The Company expects to recognize approximately 62% of remaining performance obligations as revenue in the next twelve months, and the remainder thereafter.

[0001571996-21-000063:notes:198]
[same as prior period, unchanged from 0001571996-21-000040:notes:187]

[0001571996-21-000063:notes:199]
[same as prior period, unchanged from 0001571996-21-000040:notes:188]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001571996-21-000063:notes:200]
NOTE 9 — COMMITMENTS AND CONTINGENCIES

[0001571996-21-000063:notes:201]
Purchase Obligations

[0001571996-21-000063:notes:202]
The Company has contractual obligations to purchase goods or services, which specify significant terms, including fixed or minimum quantities to be purchased; fixed, minimum, or variable price provisions; and the approximate timing of the transaction.  As of October 29, 2021, purchase obligations were $5.2 billion, $0.7 billion, and $0.8 billion for the remaining three months of Fiscal 2022, for Fiscal 2023, and for Fiscal 2024 and thereafter, respectively.

[0001571996-21-000063:notes:203]
Legal Matters

[0001571996-21-000063:notes:204]
The Company is involved in various claims, suits, assessments, investigations, and legal proceedings that arise from time to time in the ordinary course of its business, including those identified below, consisting of matters involving consumer, antitrust, tax, intellectual property, and other issues on a global basis.

[0001571996-21-000063:notes:205]
The Company accrues a liability when it believes that it is both probable that a liability has been incurred and that it can reasonably estimate the amount of the loss.  The Company reviews these accruals at least quarterly and adjusts them to reflect ongoing negotiations, settlements, rulings, advice of legal counsel, and other relevant information.  As additional information is obtained and the Company’s views on the probable outcomes of claims, suits, assessments, investigations, or legal proceedings change, the Company would record related impacts to accrued liabilities in the period in which a determination is made.  For some matters, the incurrence of a liability is not probable or the amount cannot be reasonably estimated and therefore accruals have not been made.

[0001571996-21-000063:notes:206]
The following is a discussion of the Company’s significant legal matters and other proceedings:

[0001571996-21-000063:notes:207]
Class Actions Related to the Class V Transaction — Four purported stockholders brought putative class action complaints arising out of the Class V transaction described in Note 1 of the Notes to the Condensed Consolidated Financial Statements.  The actions were captioned Hallandale Beach Police and Fire Retirement Plan v. Michael Dell et al. (Civil Action No. 2018-0816-JTL), Howard Karp v. Michael Dell et al. (Civil Action No. 2019-0032-JTL), Miramar Police Officers’ Retirement Plan v. Michael Dell et al. (Civil Action No. 2019-0049-JTL), and Steamfitters Local 449 Pension Plan v. Michael Dell et al. (Civil Action No. 2019-0115-JTL).  The four actions were consolidated in the Delaware Chancery Court into In Re Dell Class V Litigation (Consol. C.A. No. 2018-0816-JTL), which names as defendants the Company’s board of directors, Goldman Sachs & Co. LLC,  and certain stockholders of the Company, including Michael S. Dell.  The plaintiffs generally allege that the defendants breached their fiduciary duties to the former holders of Class V Common Stock in connection with the Class V transaction by allegedly causing the Company to enter into a transaction that favored the interests of the controlling stockholders at the expense of such former stockholders.  The plaintiffs seek, among other remedies, a judicial declaration that the defendants breached their fiduciary duties and an award of damages, fees, and costs.  The plaintiffs filed an amended complaint in August 2019 making substantially similar allegations to those described above.  The defendants filed a motion to dismiss the action in September 2019.  The court denied the motion in June 2020 and the case is currently in the discovery phase.  Trial is currently scheduled to begin on December 5, 2022.

[0001571996-21-000063:notes:208]
Patent Litigation — On April 25, 2019, Cirba Inc. and Cirba IP, Inc. (collectively, “Cirba”) filed a lawsuit against VMware, Inc. in the United States District Court for the District of Delaware (the “Delaware Court”), alleging two patent infringement claims and three trademark infringement-related claims (the “First Action”).  Following a hearing on August 6, 2019, the Delaware Court denied Cirba’s preliminary injunction motion.  On August 20, 2019, VMware, Inc. filed counterclaims against Cirba, asserting among other claims that Cirba is infringing four VMware, Inc. patents.  The Delaware Court severed those claims from the January 2020 trial on Cirba’s claims.  On January 24, 2020, a jury returned a verdict that VMware, Inc. had willfully infringed Cirba’s two patents and awarded approximately $237 million in damages.  As to Cirba’s trademark-related claims, the jury found that VMware, Inc. was not liable.  A total of $237 million was accrued for the First Action as of January 31, 2020, which reflected the estimated losses that were considered both probable and reasonably estimable at that time.  The amount accrued for this matter was included in Accrued and other in the Consolidated Statements of Financial Position as of January 31, 2020, and the charge was classified in Selling, general and administrative in the Consolidated Statements of Income (Loss) for the fiscal year ended January 31, 2020.  On March 9, 2020, the parties filed post-trial motions in the First Action.  On December 21, 2020, the Delaware Court granted VMware, Inc.’s request for a new trial based, in part, on Cirba’s Inc.’s lack of standing, set aside the verdict and damages award, and denied Cirba’s post-trial motions (the “Post-Trial Order”).

[0001571996-21-000063:notes:209]
On October 22, 2019, VMware, Inc. filed a separate lawsuit against Cirba in the United States District Court for the Eastern District of Virginia alleging infringement of four additional VMware, Inc. patents (The “Second Action”).  The Virginia court transferred the Second Action to the Delaware Court on February 25, 2020.  On March 23, 2020, Cirba filed a counterclaim asserting one additional patent against VMware, Inc.  The Delaware Court consolidated the First and Second Actions and ordered a consolidated trial on all of the parties’ patent infringement claims and counterclaims.  On May 3, 2021, the Court denied Cirba’s motion to certify the Post-Trial Order to enable an interlocutory appeal to the United States Court of Appeals for the Federal Circuit.  Also, on May 3, 2021, the Court granted Cirba’s motion for leave to assert an additional patent against VMware, Inc.  Separately, VMware has filed challenges with the United States Patent and Trademark Office against each of the four patents that are subject of Cirba’s allegation.  To date, of the four challenges, two ex parte reexams have been granted and one Inter Partes Review has been instituted.  As of January 29, 2021, VMware, Inc. reassessed its estimated loss accrual for the First Action based on the Post-Trial Order and determined that a loss was no longer probable and reasonably estimable with respect to the consolidated First and Second Actions.  Accordingly, the estimated loss accrual recognized during the fiscal year ended January 31, 2020 totaling $237 million was adjusted to $0 with the credit included in Selling, general, and administrative in the Consolidated Statements of Income (Loss) for the fiscal year ended January 29, 2021.  VMware, Inc. has reported that it is unable at this time to assess whether, or to what extent, it may be found liable and, if found liable, the amount any damages that may be awarded.  VMware, Inc. intends to vigorously defend itself in this matter.

[0001571996-21-000063:notes:210]
Class Actions Related to VMware, Inc.’s Acquisition of Pivotal — Two purported stockholders brought putative class action complaints arising out of VMware, Inc.’s acquisition of Pivotal Software, Inc. on December 30, 2019 as described in Note 1 of the Notes to the Condensed Consolidated Financial Statements.  The two actions were consolidated in the Delaware Chancery Court into In re: Pivotal Software, Inc. Stockholders Litigation (Civil Action No. 2020-0440-KSJM).  The complaint names as defendants the Company, VMware, Inc., Michael S. Dell, and certain officers of Pivotal.  The plaintiffs generally allege that the defendants breached their fiduciary duties to the former holders of Pivotal Class A common stock in connection with VMware, Inc.’s acquisition of Pivotal by allegedly causing Pivotal to enter into a transaction that favored the interests of Pivotal’s controlling stockholders at the expense of such former stockholders.  The plaintiffs seek, among other remedies, a judicial declaration that the defendants breached their fiduciary duties and an award of damages, fees, and costs.  Trial is currently scheduled to begin on July 6, 2022.

[0001571996-21-000063:notes:211]
Other Litigation — Dell does not currently expect that any other proceedings or matters will have a material adverse effect on its business, financial condition, results of operations, or cash flows.

[0001571996-21-000063:notes:212]
In accordance with the relevant accounting guidance, the Company provides disclosures of matters where it is at least reasonably possible that the Company could experience a material loss exceeding the amounts already accrued for these or other proceedings or matters.  In addition, the Company also discloses matters based on its consideration of other matters and qualitative factors, including the experience of other companies in the industry, and investor, customer, and employee relations considerations.  As of October 29, 2021, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for these or other proceedings or matters has been incurred.  However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company’s business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters.  Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company’s business, financial condition, results of operations, or cash flows will depend on a number of factors, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.

[0001571996-21-000063:notes:213]
Indemnifications

[0001571996-21-000063:notes:214]
In the ordinary course of business, the Company enters into contractual arrangements under which it may agree to indemnify other parties for losses incurred from certain events as defined in the relevant contract, such as litigation, regulatory penalties, or claims relating to past performance.  Such indemnification obligations may not be subject to maximum loss clauses.  Historically, payments related to these indemnifications have not been material to the Company.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001571996-21-000063:notes:215]
[same as prior period, unchanged from 0001571996-21-000040:notes:204]

[0001571996-21-000063:notes:216]
For the three months ended October 29, 2021 and October 30, 2020, the Company’s effective income tax rate was 18.7% and 37.2%, respectively, on pre-tax income of $4.8 billion and $1.4 billion, respectively.  For the nine months ended October 29, 2021 and October 30, 2020, the Company’s effective income tax rate was 15.9% and -6.1%, respectively, on pre-tax income of $6.8 billion and $2.0 billion, respectively.

[0001571996-21-000063:notes:217]
For the three and nine months ended October 29, 2021, the Company’s effective income tax rate includes tax expense of $1.0 billion related to the divestiture of Boomi during the period.  In comparison, for the nine months ended October 30, 2020, the Company’s effective income tax rate includes discrete tax benefits of $746 million related to an audit settlement that was recorded in the second quarter of Fiscal 2021 and tax expenses of $359 million relating to the divestiture of RSA Security during the third quarter of Fiscal 2021.  The Company’s effective income tax rates were also impacted by changes in the Company’s jurisdictional mix of income and lower overall taxes on foreign operations.

[0001571996-21-000063:notes:218]
The differences between the estimated effective income tax rates and the U.S. federal statutory rate of 21% principally result from the Company’s geographical distribution of income, differences between the book and tax treatment of certain items, and the discrete tax items discussed above.  In certain jurisdictions, the Company’s tax rate is significantly less than the applicable statutory rate as a result of tax holidays.  The majority of the Company’s foreign income that is subject to these tax holidays and lower tax rates is attributable to Singapore and China.  A significant portion of these income tax benefits relate to a tax holiday that will be effective until January 31, 2029.  The Company’s other tax holidays will expire in whole or in part during fiscal years 2022 through 2030.  Many of these tax holidays and reduced tax rates may be extended when certain conditions are met or may be terminated early if certain conditions are not met.  As of October 29, 2021, the Company was not aware of any matters of non-compliance related to these tax holidays.

[0001571996-21-000063:notes:219]
[same as prior period, unchanged from 0001571996-21-000040:notes:207]

[0001571996-21-000063:notes:220]
Judgment is required in evaluating the Company’s uncertain tax positions and determining the Company’s provision for income taxes.  The unrecognized tax benefits were $1.5 billion and $1.4 billion as of October 29, 2021 and January 29, 2021, respectively, and are included in Other non-current liabilities in the Condensed Consolidated Statements of Financial Position.  The Company does not anticipate a significant change to the total amount of unrecognized tax benefits within the next twelve months.

[0001571996-21-000063:notes:221]
The Company takes certain non-income tax positions in the jurisdictions in which it operates and has received certain non-income tax assessments from various jurisdictions.  The Company believes that a material loss in these matters is not probable and that it is not reasonably possible that a material loss exceeding amounts already accrued has been incurred.  The Company believes its positions in these non-income tax litigation matters are supportable and that it ultimately will prevail in the matters.  In the normal course of business, the Company’s positions and conclusions related to its non-income taxes could be challenged and assessments may be made.  To the extent new information is obtained and the Company’s views on its positions, probable outcomes of assessments, or litigation change, changes in estimates to the Company’s accrued liabilities would be recorded in the period in which such a determination is made.  In the resolution process for income tax and non-income tax audits, the Company is required in certain situations to provide collateral guarantees or indemnification to regulators and tax authorities until the matter is resolved.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001571996-21-000063:notes:222]
[same as prior period, unchanged from 0001571996-21-000040:notes:210]

[0001571996-21-000063:notes:223]
[same as prior period, unchanged from 0001571996-21-000040:notes:211]

[0001571996-21-000063:notes:224]
[same as prior period, unchanged from 0001571996-21-000040:notes:212]

[0001571996-21-000063:notes:225]
|  | Foreign Currency Translation Adjustments |  |  |  | Cash Flow Hedges |  | Pension and Other Postretirement Plans |  | Accumulated Other Comprehensive Income (Loss) |
|  | (in millions) |
| Balances as of January 29, 2021 | $ | (150) |  |  |  |  | $ | (86) |  |  | $ | (78) |  |  | $ | (314) |  |
| Other comprehensive income (loss) before reclassifications | (201) |  |  |  |  | 150 |  |  | 2 |  |  | (49) |  |
| Amounts reclassified from accumulated other comprehensive income (loss) | — |  |  |  |  | (34) |  |  | 3 |  |  | (31) |  |
| Total change for the period | (201) |  |  |  |  | 116 |  |  | 5 |  |  | (80) |  |
| Less: Change in comprehensive income (loss) attributable to non-controlling interests | — |  |  |  |  | — |  |  | — |  |  | — |  |
| Balances as of October 29, 2021 | $ | (351) |  |  |  |  | $ | 30 |  |  | $ | (73) |  |  | $ | (394) |  |

[0001571996-21-000063:notes:226]
[same as prior period, unchanged from 0001571996-21-000040:notes:214]

[0001571996-21-000063:notes:227]
[same as prior period, unchanged from 0001571996-21-000040:notes:215]

[0001571996-21-000063:notes:228]
|  |  |  | Three Months Ended |
|  |  |  | October 29, 2021 |  |  |  | October 30, 2020 |
|  |  |  | Cash Flow Hedges |  | Pensions |  | Total |  |  |  | Cash Flow Hedges |  | Pensions |  | Total |
|  |  |  | (in millions) |
| Total reclassifications, net of tax: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue |  |  | $ | 66 |  |  | $ | — |  |  | $ | 66 |  |  |  |  | $ | (88) |  |  | $ | — |  |  | $ | (88) |  |
| Cost of net revenue |  |  | 8 |  |  | — |  |  | 8 |  |  |  |  | 4 |  |  | — |  |  | 4 |  |
| Operating expenses |  |  | — |  |  | (1) |  |  | (1) |  |  |  |  | — |  |  | 1 |  |  | 1 |  |
| Total reclassifications, net of tax |  |  | $ | 74 |  |  | $ | (1) |  |  | $ | 73 |  |  |  |  | $ | (84) |  |  | $ | 1 |  |  | $ | (83) |  |
|  |  |  | Nine Months Ended |
|  |  |  | October 29, 2021 |  |  |  | October 30, 2020 |
|  |  |  | Cash Flow Hedges |  | Pensions |  | Total |  |  |  | Cash Flow Hedges |  | Pensions |  | Total |
|  |  |  | (in millions) |
| Total reclassifications, net of tax: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue |  |  | $ | 31 |  |  | $ | — |  |  | $ | 31 |  |  |  |  | $ | 17 |  |  | $ | — |  |  | $ | 17 |  |
| Cost of net revenue |  |  | 3 |  |  | — |  |  | 3 |  |  |  |  | 7 |  |  | — |  |  | 7 |  |
| Operating expenses |  |  | — |  |  | (3) |  |  | (3) |  |  |  |  | — |  |  | (3) |  |  | (3) |  |
| Total reclassifications, net of tax |  |  | $ | 34 |  |  | $ | (3) |  |  | $ | 31 |  |  |  |  | $ | 24 |  |  | $ | (3) |  |  | $ | 21 |  |


## us-gaap:MinorityInterestDisclosureTextBlock

[0001571996-21-000063:notes:229]
[same as prior period, unchanged from 0001571996-21-000040:notes:217]

[0001571996-21-000063:notes:230]
VMware, Inc. — The non-controlling interests’ share of equity in VMware, Inc. is reflected as a component of the non-controlling interests in the Condensed Consolidated Statements of Financial Position and was $5.1 billion and $5.0 billion as of October 29, 2021 and January 29, 2021, respectively.  As of October 29, 2021 and January 29, 2021, the Company held approximately 80.5% and 80.6%, respectively, of the outstanding equity interest in VMware, Inc.  On November 1, 2021, subsequent to the close of the third quarter of Fiscal 2022, the Company completed the VMware Spin-off.  See Note 1 and Note 18 of the Notes to the Condensed Consolidated Financial Statements for more information regarding the completion of the VMware Spin-off.

[0001571996-21-000063:notes:231]
Secureworks — The non-controlling interests’ share of equity in Secureworks is reflected as a component of the non-controlling interests in the Condensed Consolidated Statements of Financial Position and was $105 million and $96 million as of October 29, 2021 and January 29, 2021, respectively.  As of October 29, 2021 and January 29, 2021, the Company held approximately 84.0% and 85.7%, respectively, of the outstanding equity interest in Secureworks, excluding restricted stock awards (“RSAs”) and 83.1% and 84.9%, respectively, including RSAs.

[0001571996-21-000063:notes:232]
[same as prior period, unchanged from 0001571996-21-000040:notes:220]

[0001571996-21-000063:notes:233]
|  | Nine Months Ended |
|  | October 29, 2021 |  |  |
|  | (in millions) |
| Net income attributable to Dell Technologies Inc. | $ | 5,561 |  |  |  |
| Transfers (to)/from the non-controlling interests: |  |  |  |
| Increase in Dell Technologies Inc. additional paid-in-capital for equity issuances and other equity activity | 762 |  |  |  |
| Decrease in Dell Technologies Inc. additional paid-in-capital for equity issuances and other equity activity | (828) |  |  |  |
| Net transfers to non-controlling interests | (66) |  |  |  |
| Change from net income attributable to Dell Technologies Inc. and transfers to the non-controlling interests | $ | 5,495 |  |  |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001571996-21-000063:notes:234]
[same as prior period, unchanged from 0001571996-21-000040:notes:222]

[0001571996-21-000063:notes:235]
[same as prior period, unchanged from 0001571996-21-000040:notes:223]

[0001571996-21-000063:notes:236]
|  | Authorized |  | Issued |  | Outstanding |
|  | (in millions) |
| Common stock as of October 29, 2021 |
| Class A | 600 |  |  | 379 |  |  | 379 |  |
| Class B | 200 |  |  | 95 |  |  | 95 |  |
| Class C | 7,900 |  |  | 301 |  |  | 293 |  |
| Class D | 100 |  |  | — |  |  | — |  |
| Class V | 343 |  |  | — |  |  | — |  |
|  | 9,143 |  |  | 775 |  |  | 767 |  |
| Common stock as of January 29, 2021 |
| Class A | 600 |  |  | 385 |  |  | 385 |  |
| Class B | 200 |  |  | 102 |  |  | 102 |  |
| Class C | 7,900 |  |  | 274 |  |  | 266 |  |
| Class D | 100 |  |  | — |  |  | — |  |
| Class V | 343 |  |  | — |  |  | — |  |
|  | 9,143 |  |  | 761 |  |  | 753 |  |

[0001571996-21-000063:notes:237]
[same as prior period, unchanged from 0001571996-21-000040:notes:225]

[0001571996-21-000063:notes:238]
[same as prior period, unchanged from 0001571996-21-000040:notes:226]

[0001571996-21-000063:notes:239]
The Company is authorized to issue one million shares of preferred stock, par value $0.01 per share.  As of October 29, 2021 and January 29, 2021, no shares of preferred stock were issued or outstanding.

[0001571996-21-000063:notes:240]
[same as prior period, unchanged from 0001571996-21-000040:notes:228]

[0001571996-21-000063:notes:241]
[same as prior period, unchanged from 0001571996-21-000040:notes:229]

[0001571996-21-000063:notes:242]
[same as prior period, unchanged from 0001571996-21-000040:notes:230]

[0001571996-21-000063:notes:243]
Conversion Rights — Under the Company’s certificate of incorporation, at any time and from time to time, any holder of Class A Common Stock or Class B Common Stock has the right to convert all or any of the shares of Class A Common Stock or Class B Common Stock, as applicable, held by such holder into shares of Class C Common Stock on a one-to-one basis.  During the nine months ended October 29, 2021, the Company issued 5,912,845 shares of Class C Common Stock to stockholders upon the conversion of the same number of shares of Class A Common Stock into Class C Common Stock in accordance with the Company’s certificate of incorporation.  During the nine months ended October 29, 2021, the Company issued 6,334,990 shares of Class C Common Stock to stockholders upon their conversion of the same number of shares of Class B Common Stock into Class C Common Stock in accordance with the Company’s certificate of incorporation.

[0001571996-21-000063:notes:244]
[same as prior period, unchanged from 0001571996-21-000040:notes:232]

[0001571996-21-000063:notes:245]
[same as prior period, unchanged from 0001571996-21-000040:notes:233]

[0001571996-21-000063:notes:246]
On February 24, 2020, the Company’s board of directors approved a stock repurchase program under which the Company was authorized to repurchase up to $1.0 billion of shares of the Class C Common Stock over a 24-month period expiring on February 28, 2022.  During the nine months ended October 30, 2020, the Company repurchased approximately 6 million shares of Class C Common Stock for approximately $240 million and subsequently suspended activity under its stock repurchase program.

[0001571996-21-000063:notes:247]
Effective as of September 23, 2021, the Company’s board of directors terminated the Company’s previous stock repurchase program and approved a new stock repurchase program (the “2021 Stock Repurchase Program”) under which the Company is authorized to use assets to repurchase up to $5 billion of shares of the Company’s Class C Common Stock with no established expiration date.  The repurchase of shares commenced in the fourth quarter of Fiscal 2022 and, accordingly, as of October 29, 2021 the cumulative authorized amount remaining for stock repurchases was $5 billion.

[0001571996-21-000063:notes:248]
[same as prior period, unchanged from 0001571996-21-000040:notes:235]

[0001571996-21-000063:notes:249]
[same as prior period, unchanged from 0001571996-21-000040:notes:236]

[0001571996-21-000063:notes:250]
On May 29, 2019, VMware, Inc.’s board of directors authorized the repurchase of up to $1.5 billion of VMware, Inc.’s Class A common stock through January 29, 2021.  On July 15, 2020, VMware, Inc.’s board of directors extended authorization of VMware, Inc.’s existing repurchase program and authorized the repurchase of up to an additional $1.0 billion of VMware, Inc.’s Class A common stock through January 28, 2022.  On October 7, 2021, VMware authorized the termination of the existing stock repurchase program, under which $183 million remained authorized and unpurchased as of October 29, 2021, and authorized a new repurchase program of up to $2.0 billion of Class A common stock through the end of fiscal 2024, in each case, effective upon the close of the VMware Spin-off.

[0001571996-21-000063:notes:251]
During the nine months ended October 29, 2021, VMware, Inc. repurchased 5.7 million shares of its Class A common stock in the open market for approximately $872 million.  During the nine months ended October 30, 2020, VMware, Inc. repurchased approximately 4.2 million shares of its Class A common stock in the open market for approximately $566 million.

[0001571996-21-000063:notes:252]
[same as prior period, unchanged from 0001571996-21-000040:notes:239]

[0001571996-21-000063:notes:253]
The above VMware, Inc. Class A common stock repurchases for the nine months ended October 29, 2021 and October 30, 2020 exclude shares repurchased to settle employee tax withholding related to the vesting of VMware, Inc. stock awards of $284 million and $315 million, respectively.


## us-gaap:EarningsPerShareTextBlock

[0001571996-21-000063:notes:254]
[same as prior period, unchanged from 0001571996-21-000040:notes:241]

[0001571996-21-000063:notes:255]
[same as prior period, unchanged from 0001571996-21-000040:notes:242]

[0001571996-21-000063:notes:256]
[same as prior period, unchanged from 0001571996-21-000040:notes:243]

[0001571996-21-000063:notes:257]
[same as prior period, unchanged from 0001571996-21-000040:notes:244]

[0001571996-21-000063:notes:258]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 29, 2021 |  | October 30, 2020 |  | October 29, 2021 |  | October 30, 2020 |
| Earnings per share attributable to Dell Technologies Inc. |  |  |  |  |
| Dell Technologies Common Stock — Basic | $ | 5.02 |  |  | $ | 1.11 |  |  | $ | 7.30 |  |  | $ | 2.73 |  |
| Dell Technologies Common Stock — Diluted | $ | 4.87 |  |  | $ | 1.08 |  |  | $ | 7.08 |  |  | $ | 2.64 |  |

[0001571996-21-000063:notes:259]
[same as prior period, unchanged from 0001571996-21-000040:notes:246]

[0001571996-21-000063:notes:260]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 29, 2021 |  | October 30, 2020 |  | October 29, 2021 |  | October 30, 2020 |
|  | (in millions) |
| Numerator: Dell Technologies Common Stock |  |  |  |  |  |  |  |
| Net income attributable to Dell Technologies — basic | $ | 3,843 |  |  | $ | 832 |  |  | $ | 5,561 |  |  | $ | 2,023 |  |
| Incremental dilution from VMware, Inc. attributable to Dell Technologies (a) | (2) |  |  | (3) |  |  | (7) |  |  | (8) |  |
| Net income attributable to Dell Technologies — diluted | $ | 3,841 |  |  | $ | 829 |  |  | $ | 5,554 |  |  | $ | 2,015 |  |
| Denominator: Dell Technologies Common Stock weighted-average shares outstanding |  |  |  |  |
| Weighted-average shares outstanding — basic | 766 |  |  | 747 |  |  | 762 |  |  | 742 |  |
| Dilutive effect of options, restricted stock units, restricted stock, and other | 22 |  |  | 24 |  |  | 23 |  |  | 22 |  |
| Weighted-average shares outstanding — diluted | 788 |  |  | 771 |  |  | 785 |  |  | 764 |  |
| Weighted-average shares outstanding — antidilutive | — |  |  | — |  |  | — |  |  | 1 |  |

[0001571996-21-000063:notes:261]
[same as prior period, unchanged from 0001571996-21-000040:notes:248]


## dell:TemporaryEquityTextBlock

[0001571996-21-000063:notes:262]
[same as prior period, unchanged from 0001571996-21-000040:notes:249]

[0001571996-21-000063:notes:263]
Through June 27, 2021, awards under the Company’s stock incentive plans included certain rights that allowed the holder to exercise a put feature for the underlying Class A or Class C Common Stock after a six month holding period following the issuance of such common stock.  The put feature required the Company to purchase the stock at its fair market value.  Accordingly, these awards and such common stock were subject to reclassification from equity to temporary equity.  The put feature expired on June 27, 2021, and as a result there were no issued and outstanding awards that were reclassified as temporary equity as of October 29, 2021.

[0001571996-21-000063:notes:264]
[same as prior period, unchanged from 0001571996-21-000040:notes:251]

[0001571996-21-000063:notes:265]
[same as prior period, unchanged from 0001571996-21-000040:notes:252]

[0001571996-21-000063:notes:266]
[same as prior period, unchanged from 0001571996-21-000040:notes:253]

[0001571996-21-000063:notes:267]
[same as prior period, unchanged from 0001571996-21-000040:notes:254]

[0001571996-21-000063:notes:268]
[same as prior period, unchanged from 0001571996-21-000040:notes:255]

[0001571996-21-000063:notes:269]
[same as prior period, unchanged from 0001571996-21-000040:notes:256]


## us-gaap:SegmentReportingDisclosureTextBlock

[0001571996-21-000063:notes:270]
[same as prior period, unchanged from 0001571996-21-000040:notes:257]

[0001571996-21-000063:notes:271]
[same as prior period, unchanged from 0001571996-21-000040:notes:258]

[0001571996-21-000063:notes:272]
[same as prior period, unchanged from 0001571996-21-000040:notes:259]

[0001571996-21-000063:notes:273]
[same as prior period, unchanged from 0001571996-21-000040:notes:260]

[0001571996-21-000063:notes:274]
[same as prior period, unchanged from 0001571996-21-000040:notes:261]

[0001571996-21-000063:notes:275]
As described in Note 1 and Note 18 of the Notes to the Condensed Consolidated Financial Statements, the Company completed the VMware Spin-off on November 1, 2021, subsequent to the close of the third quarter of Fiscal 2022.  Beginning in the fourth quarter of Fiscal 2022, the Company’s Consolidated Statements of Income will be recast to reflect VMware results as discontinued operations.  As such, VMware will no longer be identified as a reportable segment.  Pursuant to the CFA, Dell Technologies will continue to integrate VMware, Inc.’s products and services with Dell Technologies’ offerings and sell them to end users.  The results of those transactions will be reflected within CSG and ISG, based on the nature of the underlying offering sold.  Dell Technologies will also continue to act as a distributor, purchasing VMware, Inc.’s standalone products and services for resale to end-user customers.  The results of this business will be reflected in Other businesses.  The Company's prior period segment results will be recast to reflect the change.

[0001571996-21-000063:notes:276]
[same as prior period, unchanged from 0001571996-21-000040:notes:262]

[0001571996-21-000063:notes:277]
[same as prior period, unchanged from 0001571996-21-000040:notes:263]

[0001571996-21-000063:notes:278]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 29, 2021 |  | October 30, 2020 |  | October 29, 2021 |  | October 30, 2020 |
|  | (in millions) |
| Consolidated net revenue: |  |  |  |  |  |  |  |
| Infrastructure Solutions Group | $ | 8,428 |  |  | $ | 8,024 |  |  | $ | 24,771 |  |  | $ | 23,800 |  |
| Client Solutions Group | 16,546 |  |  | 12,286 |  |  | 44,114 |  |  | 34,593 |  |
| VMware | 3,178 |  |  | 2,893 |  |  | 9,317 |  |  | 8,556 |  |
| Reportable segment net revenue | 28,152 |  |  | 23,203 |  |  | 78,202 |  |  | 66,949 |  |
| Other businesses (a) | 251 |  |  | 314 |  |  | 829 |  |  | 1,288 |  |
| Unallocated transactions (b) | 2 |  |  | 4 |  |  | 6 |  |  | 4 |  |
| Impact of purchase accounting (c) | (11) |  |  | (39) |  |  | (34) |  |  | (129) |  |
| Total consolidated net revenue | $ | 28,394 |  |  | $ | 23,482 |  |  | $ | 79,003 |  |  | $ | 68,112 |  |
| Consolidated operating income: |  |  |  |  |  |  |  |
| Infrastructure Solutions Group | $ | 892 |  |  | $ | 882 |  |  | $ | 2,650 |  |  | $ | 2,587 |  |
| Client Solutions Group | 1,147 |  |  | 1,002 |  |  | 3,232 |  |  | 2,309 |  |
| VMware | 837 |  |  | 837 |  |  | 2,527 |  |  | 2,504 |  |
| Reportable segment operating income | 2,876 |  |  | 2,721 |  |  | 8,409 |  |  | 7,400 |  |
| Other businesses (a) | (9) |  |  | 3 |  |  | (17) |  |  | 105 |  |
| Unallocated transactions (b) | 1 |  |  | 1 |  |  | 1 |  |  | (1) |  |
| Impact of purchase accounting (c) | (17) |  |  | (49) |  |  | (62) |  |  | (165) |  |
| Amortization of intangibles | (694) |  |  | (845) |  |  | (2,114) |  |  | (2,547) |  |
| Transaction-related expenses (d) | (311) |  |  | (52) |  |  | (422) |  |  | (211) |  |
| Stock-based compensation expense (e) | (472) |  |  | (436) |  |  | (1,406) |  |  | (1,219) |  |
| Other corporate expenses (f) | (25) |  |  | (214) |  |  | (293) |  |  | (395) |  |
| Total consolidated operating income | $ | 1,349 |  |  | $ | 1,129 |  |  | $ | 4,096 |  |  | $ | 2,967 |  |

[0001571996-21-000063:notes:279]
(a)Secureworks and Virtustream constitute Other businesses and do not meet the requirements for a reportable segment, either individually or collectively.  The results of Other businesses are not material to the Company’s overall results.  On September 1, 2020, the Company completed the sale of RSA Security.  On October 1, 2021, the Company completed the sale of Boomi.  Prior to the divestitures, Boomi and RSA Security’s results were included within Other businesses.  See Note 1 of the Notes to the Condensed Consolidated Financial Statements for more information about the divestitures of Boomi and RSA Security.

[0001571996-21-000063:notes:280]
[same as prior period, unchanged from 0001571996-21-000040:notes:266]

[0001571996-21-000063:notes:281]
[same as prior period, unchanged from 0001571996-21-000040:notes:267]

[0001571996-21-000063:notes:282]
[same as prior period, unchanged from 0001571996-21-000040:notes:268]

[0001571996-21-000063:notes:283]
[same as prior period, unchanged from 0001571996-21-000040:notes:269]

[0001571996-21-000063:notes:284]
[same as prior period, unchanged from 0001571996-21-000040:notes:270]

[0001571996-21-000063:notes:285]
[same as prior period, unchanged from 0001571996-21-000040:notes:271]

[0001571996-21-000063:notes:286]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 29, 2021 |  | October 30, 2020 |  | October 29, 2021 |  | October 30, 2020 |
|  | (in millions) |
| Net revenue: |  |  |  |  |  |  |  |
| Infrastructure Solutions Group: |  |  |  |  |  |  |  |
| Servers and networking | $ | 4,533 |  |  | $ | 4,164 |  |  | $ | 13,104 |  |  | $ | 12,118 |  |
| Storage | 3,895 |  |  | 3,860 |  |  | 11,667 |  |  | 11,682 |  |
| Total ISG net revenue | 8,428 |  |  | 8,024 |  |  | 24,771 |  |  | 23,800 |  |
| Client Solutions Group: |  |  |  |  |  |  |  |
| Commercial | 12,292 |  |  | 8,783 |  |  | 32,668 |  |  | 25,456 |  |
| Consumer | 4,254 |  |  | 3,503 |  |  | 11,446 |  |  | 9,137 |  |
| Total CSG net revenue | 16,546 |  |  | 12,286 |  |  | 44,114 |  |  | 34,593 |  |
| VMware: |  |  |  |  |  |  |  |
| Total VMware net revenue | 3,178 |  |  | 2,893 |  |  | 9,317 |  |  | 8,556 |  |
| Total segment net revenue | $ | 28,152 |  |  | $ | 23,203 |  |  | $ | 78,202 |  |  | $ | 66,949 |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001571996-21-000063:notes:287]
[same as prior period, unchanged from 0001571996-21-000040:notes:273]

[0001571996-21-000063:notes:288]
[same as prior period, unchanged from 0001571996-21-000040:notes:274]

[0001571996-21-000063:notes:289]
|  | October 29, 2021 |  | January 29, 2021 |
|  | (in millions) |
| Cash, cash equivalents, and restricted cash: |  |  |  |
| Cash and cash equivalents | $ | 22,406 |  |  | $ | 14,201 |  |
| Restricted cash - other current assets (a) | 889 |  |  | 891 |  |
| Restricted cash - other non-current assets (a) | 74 |  |  | 92 |  |
| Total cash, cash equivalents, and restricted cash | $ | 23,369 |  |  | $ | 15,184 |  |
| Inventories, net: |  |  |  |
| Production materials | $ | 3,209 |  |  | $ | 1,717 |  |
| Work-in-process | 812 |  |  | 677 |  |
| Finished goods | 1,421 |  |  | 1,008 |  |
| Total inventories, net | $ | 5,442 |  |  | $ | 3,402 |  |
| Property, plant, and equipment, net: |  |  |  |
| Computer equipment | $ | 7,628 |  |  | $ | 6,506 |  |
| Land and buildings | 4,775 |  |  | 4,745 |  |
| Machinery and other equipment | 4,173 |  |  | 3,933 |  |
| Total property, plant, and equipment | 16,576 |  |  | 15,184 |  |
| Accumulated depreciation and amortization | (9,651) |  |  | (8,753) |  |
| Total property, plant, and equipment, net | $ | 6,925 |  |  | $ | 6,431 |  |
| Other non-current assets: |  |  |  |
| Deferred and other tax assets | $ | 6,450 |  |  | $ | 6,230 |  |
| Operating lease right of use assets | 1,953 |  |  | 2,117 |  |
| Deferred commissions | 1,158 |  |  | 1,094 |  |
| Other | 1,895 |  |  | 1,755 |  |
| Total other non-current assets | $ | 11,456 |  |  | $ | 11,196 |  |

[0001571996-21-000063:notes:290]
[same as prior period, unchanged from 0001571996-21-000040:notes:276]

[0001571996-21-000063:notes:291]
[same as prior period, unchanged from 0001571996-21-000040:notes:277]

[0001571996-21-000063:notes:292]
[same as prior period, unchanged from 0001571996-21-000040:notes:278]

[0001571996-21-000063:notes:293]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 29, 2021 |  | October 30, 2020 |  | October 29, 2021 |  | October 30, 2020 |
|  | (in millions) |
| Trade Receivables — Allowance for expected credit losses: |  |  |  |  |  |  |
| Balance at beginning of period | $ | 98 |  |  | $ | 146 |  |  | $ | 104 |  |  | $ | 94 |  |
| Adjustment for adoption of accounting standard (a) | — |  |  | — |  |  | — |  |  | 27 |  |
| Allowance charged to provision | 12 |  |  | (4) |  |  | 25 |  |  | 43 |  |
| Bad debt write-offs | (10) |  |  | (27) |  |  | (29) |  |  | (49) |  |
| Balance at end of period | $ | 100 |  |  | $ | 115 |  |  | $ | 100 |  |  | $ | 115 |  |

[0001571996-21-000063:notes:294]
[same as prior period, unchanged from 0001571996-21-000040:notes:280]

[0001571996-21-000063:notes:295]
[same as prior period, unchanged from 0001571996-21-000040:notes:281]

[0001571996-21-000063:notes:296]
[same as prior period, unchanged from 0001571996-21-000040:notes:282]

[0001571996-21-000063:notes:297]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 29, 2021 |  | October 30, 2020 |  | October 29, 2021 |  | October 30, 2020 |
|  | (in millions) |
| Warranty liability: |  |  |  |  |  |  |  |
| Warranty liability at beginning of period | $ | 471 |  |  | $ | 479 |  |  | $ | 473 |  |  | $ | 496 |  |
| Costs accrued for new warranty contracts and changes in estimates for pre-existing warranties (a) (b) | 281 |  |  | 219 |  |  | 724 |  |  | 573 |  |
| Service obligations honored | (248) |  |  | (206) |  |  | (693) |  |  | (577) |  |
| Warranty liability at end of period | $ | 504 |  |  | $ | 492 |  |  | $ | 504 |  |  | $ | 492 |  |
| Current portion | $ | 377 |  |  | $ | 362 |  |  | $ | 377 |  |  | $ | 362 |  |
| Non-current portion | $ | 127 |  |  | $ | 130 |  |  | $ | 127 |  |  | $ | 130 |  |

[0001571996-21-000063:notes:298]
[same as prior period, unchanged from 0001571996-21-000040:notes:284]

[0001571996-21-000063:notes:299]
[same as prior period, unchanged from 0001571996-21-000040:notes:285]

[0001571996-21-000063:notes:300]
[same as prior period, unchanged from 0001571996-21-000040:notes:286]

[0001571996-21-000063:notes:301]
[same as prior period, unchanged from 0001571996-21-000040:notes:287]

[0001571996-21-000063:notes:302]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 29, 2021 |  | October 30, 2020 |  | October 29, 2021 |  | October 30, 2020 |
|  | (in millions) |
| Severance liability: |  |  |  |  |  |  |  |
| Severance liability at beginning of period | $ | 126 |  |  | $ | 168 |  |  | $ | 138 |  |  | $ | 196 |  |
| Severance charges to provision | 10 |  |  | 226 |  |  | 120 |  |  | 417 |  |
| Cash paid and other (a) | (50) |  |  | (181) |  |  | (172) |  |  | (400) |  |
| Severance liability at end of period | $ | 86 |  |  | $ | 213 |  |  | $ | 86 |  |  | $ | 213 |  |

[0001571996-21-000063:notes:303]
[same as prior period, unchanged from 0001571996-21-000040:notes:289]

[0001571996-21-000063:notes:304]
[same as prior period, unchanged from 0001571996-21-000040:notes:290]

[0001571996-21-000063:notes:305]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 29, 2021 |  | October 30, 2020 |  | October 29, 2021 |  | October 30, 2020 |
|  | (in millions) |
| Severance charges: |  |  |  |  |  |  |  |
| Cost of net revenue | $ | 2 |  |  | $ | 46 |  |  | $ | 24 |  |  | $ | 58 |  |
| Selling, general, and administrative | 7 |  |  | 139 |  |  | 90 |  |  | 308 |  |
| Research and development | 1 |  |  | 41 |  |  | 6 |  |  | 51 |  |
| Total severance charges | $ | 10 |  |  | $ | 226 |  |  | $ | 120 |  |  | $ | 417 |  |

[0001571996-21-000063:notes:306]
[same as prior period, unchanged from 0001571996-21-000040:notes:292]

[0001571996-21-000063:notes:307]
[same as prior period, unchanged from 0001571996-21-000040:notes:293]

[0001571996-21-000063:notes:308]
|  | Three Months Ended |  | Nine Months Ended |  |  |
|  | October 29, 2021 |  | October 30, 2020 |  | October 29, 2021 |  | October 30, 2020 |  |  |
|  | (in millions) |  |  |
| Interest and other, net: |  |  |  |  |  |  |  |  |  |
| Investment income, primarily interest | $ | 11 |  |  | $ | 11 |  |  | $ | 32 |  |  | $ | 47 |  |  |  |
| Gain on investments, net | 27 |  |  | 489 |  |  | 352 |  |  | 591 |  |  |  |
| Interest expense | (482) |  |  | (566) |  |  | (1,475) |  |  | (1,855) |  |  |  |
| Foreign exchange | (33) |  |  | (31) |  |  | (146) |  |  | (130) |  |  |  |
| Gain on disposition of businesses and assets | 3,968 |  |  | 338 |  |  | 3,968 |  |  | 458 |  |  |  |
| Other | (55) |  |  | 32 |  |  | (42) |  |  | (40) |  |  |  |
| Total interest and other, net | $ | 3,436 |  |  | $ | 273 |  |  | $ | 2,689 |  |  | $ | (929) |  |  |  |


## us-gaap:SubsequentEventsTextBlock

[0001571996-21-000063:notes:309]
SUBSEQUENT EVENTS 
Spin-off of VMware, Inc.

[0001571996-21-000063:notes:310]
On November 1, 2021, the Company completed its previously announced spin-off of VMware, Inc. as described in Note 1 of the Notes to the Condensed Consolidated Financial Statements.  Dell Technologies effectuated the VMware Spin-off by means of a special stock dividend of 30,678,605 shares of Class A common stock and 307,221,836 shares of Class B common stock of VMware, Inc. to Dell Technologies stockholders of record as of 5:00 p.m., New York City time, on October 29, 2021.

[0001571996-21-000063:notes:311]
Prior to receipt of the VMware, Inc. common stock by the Company’s stockholders, each share of VMware, Inc. Class B common stock automatically converted into one share of VMware, Inc. Class A common stock.  As result of these transactions, each holder of record of shares of Dell Technologies common stock as of the distribution record date received approximately 0.440626 of a share of VMware Class A common stock for each share of Dell Technologies common stock held as of such date, based on shares outstanding as of the completion of the VMware Spin-off.

[0001571996-21-000063:notes:312]
Immediately following the payment by VMware, Inc. to its stockholders of a special cash dividend of $11.5 billion, of which Dell Technologies received approximately $9.3 billion, the separation of VMware, Inc. from Dell Technologies occurred, including through the termination or settlement of certain intercompany accounts and intercompany contracts.

[0001571996-21-000063:notes:313]
Repayment of Indebtedness and Termination of the Existing Credit Agreement

[0001571996-21-000063:notes:314]
The Company used the net proceeds from its $9.3 billion pro rata portion of the cash dividend received in connection with the VMware Spin-off, as well as cash on hand, to repay outstanding debt as described below.

[0001571996-21-000063:notes:315]
On November 1, 2021, the Company repaid the remaining $3,134 million and $3,120 million principal amounts related to the 1.84% Term Loan A-6 Facility due March 2024 and the 2.00% Term Loan B-2 Facility due September 2025, respectively, and terminated all obligations and commitments under the Existing Credit Agreement.

[0001571996-21-000063:notes:316]
On November 2, 2021, the Company repaid $1,500 million principal amount of the 5.45% First Lien Notes due June 2023 and the remaining $1,625 million principal amount of the 7.125% Senior Notes due June 2024.  Further, in conjunction with the termination of the Existing Credit Agreement, the tangible and intangible assets of the issuers and guarantors that secure obligations under the Senior Secured Credit Facilities were released as collateral and the First Lien Notes became fully unsecured.

[0001571996-21-000063:notes:317]
In connection with the above debt repayments, the Company incurred $181 million of debt breakage fees and recognized $110 million in unamortized debt discounts associated with the early extinguishment of the debt.

[0001571996-21-000063:notes:318]
2021 Revolving Credit Facility

[0001571996-21-000063:notes:319]
On November 1, 2021, the Company entered into the 2021 Revolving Credit Facility, a senior unsecured revolving credit facility with JPMorgan Chase Bank, N.A., as administrative agent, and each of the lenders and other parties from time to time party thereto.

[0001571996-21-000063:notes:320]
The 2021 Revolving Credit Facility, which matures on November 1, 2026, provides the Company with revolving commitments in an aggregate principal amount of $5.0 billion for general corporate purposes and includes a letter of credit sub-facility of up to $500 million and a swing-line loan sub-facility of up to $500 million.  The 2021 Revolving Credit Facility also allows the Company to request incremental commitments on one or more occasions in a minimum amount of $10 million.

[0001571996-21-000063:notes:321]
2023 First Lien Notes Notice of Prepayment

[0001571996-21-000063:notes:322]
On November 19, 2021, the Company issued a partial redemption notice of $1.25 billion principal amount of the 5.45% First Lien Notes due June 2023 with the repayment expected to occur on December 6, 2021.

[0001571996-21-000063:notes:323]
Common Stock Repurchases

[0001571996-21-000063:notes:324]
Subsequent to October 29, 2021, the Company began repurchases under the 2021 Stock Repurchase Program described in Note 13 of the Notes to the Condensed Consolidated Financial Statements.  Through November 30, 2021, the Company repurchased  approximately 3.1 million shares of Class C Common Stock for approximately $173 million.

[0001571996-21-000063:notes:325]
Other than the matters identified above, there were no known events occurring after October 29, 2021 and up until the date of issuance of this report that would materially affect the information presented herein.
