# DELL MD&A — 0001571996-21-000063


## mdna

[0001571996-21-000063:mdna:1]
[same as prior period, unchanged from 0001571996-21-000040:mdna:1]

[0001571996-21-000063:mdna:2]
Unless otherwise indicated, all results presented are prepared in a manner that complies, in all material respects, with generally accepted accounting principles in the United States of America (“GAAP”).  Unless otherwise indicated, all changes identified for the current-period results represent comparisons to results for the prior corresponding fiscal period.

[0001571996-21-000063:mdna:3]
[same as prior period, unchanged from 0001571996-21-000040:mdna:3]

[0001571996-21-000063:mdna:4]
[same as prior period, unchanged from 0001571996-21-000040:mdna:4]

[0001571996-21-000063:mdna:5]
[same as prior period, unchanged from 0001571996-21-000040:mdna:5]

[0001571996-21-000063:mdna:6]
Dell Technologies helps organizations and individuals build their digital future and transform how they work, live, and play.  We provide customers with the industry’s broadest and most innovative technology and services portfolio for the data era, spanning traditional infrastructure, emerging multi-cloud technologies, and essential technology needed in the “do anything from anywhere” economy.  We continue to seamlessly deliver differentiated and holistic information technology (“IT”) solutions to our customers, which has driven significant revenue growth and share gains.

[0001571996-21-000063:mdna:7]
Dell Technologies’ integrated solutions help customers modernize their IT infrastructure, manage and operate in a multi-cloud world, address workforce transformation, and provide critical solutions that keep people and organizations connected, which has proven even more important in this current time of disruption caused by the COVID-19 pandemic.  We are helping customers accelerate their digital transformations to improve and strengthen business and workforce productivity.  With our extensive portfolio and our commitment to innovation, we offer secure, integrated solutions that extend from the edge to the core to the cloud, and we are at the forefront of the software-defined and cloud native infrastructure era.  As further evidence of our commitment to innovation, we are evolving and expanding our IT as-a-Service and cloud offerings through APEX, which will provide our customers with greater flexibility to scale IT to meet their evolving business needs and budgets.

[0001571996-21-000063:mdna:8]
Dell Technologies’ end-to-end portfolio is supported by a world-class organization with unmatched size and scale.  We operate globally in 180 countries across key functional areas, including technology and product development, marketing, sales, financial services, and global services.  Our go-to-market engine includes a 39,000-person sales force and a global network of over 200,000 channel partners.  Dell Financial Services and its affiliates (“DFS”) offer customer payment flexibility and enable synergies across the business.  We employ 34,000 full-time service and support professionals and maintain more than 2,400 vendor-managed service centers.  We manage a world-class supply chain that drives long-term growth and operating efficiencies, with approximately $70 billion in annual procurement expenditures and over 750 parts distribution centers.  Together, these elements provide a critical foundation for our success, enabling us to offer unparalleled capability to our customers and making us the integrator of choice.

[0001571996-21-000063:mdna:9]
[same as prior period, unchanged from 0001571996-21-000040:mdna:9]

[0001571996-21-000063:mdna:10]
[same as prior period, unchanged from 0001571996-21-000040:mdna:10]

[0001571996-21-000063:mdna:11]
[same as prior period, unchanged from 0001571996-21-000040:mdna:11]

[0001571996-21-000063:mdna:12]
As described in Note 1 of the Notes to the Condensed Consolidated Financial Statements included in this report, on November 1, 2021, subsequent to the close of the Company’s third quarter of Fiscal 2022, the Company completed its previously announced spin-off of VMware, Inc. by means of a special stock dividend (the “VMware Spin-off”).  The VMware Spin-off was effectuated pursuant to a Separation and Distribution Agreement, dated as of April 14, 2021 (the “Separation and Distribution Agreement”).

[0001571996-21-000063:mdna:13]
Dell Technologies effectuated the VMware Spin-off by means of a special stock dividend of 30,678,605 shares of Class A common stock and 307,221,836 of Class B common stock of VMware, Inc. to Dell Technologies stockholders of record as of 5:00 p.m., New York City time, on October 29, 2021.  Prior to receipt of the VMware, Inc. common stock by the Company’s stockholders, each share of VMware, Inc. Class B common stock automatically converted into one share of VMware, Inc. Class A common stock.  As a result of these transactions, each holder of record of shares of Dell Technologies common stock as of the distribution record date received approximately 0.440626 of a share of VMware, Inc. Class A common stock for each outstanding share of Dell Technologies common stock owned by such holder as of such date.  VMware, Inc. paid a special cash dividend, pro rata, to each holder of VMware, Inc. common stock in an aggregate amount equal to $11.5 billion, of which Dell Technologies received $9.3 billion.

[0001571996-21-000063:mdna:14]
Immediately following VMware, Inc.’s payment of the special cash dividend, pursuant to the Separation and Distribution Agreement, the businesses of VMware, Inc. were separated from the remaining businesses of Dell Technologies through a series of transactions that resulted in the pre-transaction stockholders of Dell Technologies owning shares in two separate public companies, consisting of (1) VMware, Inc., which continues to own the businesses of VMware, Inc. and its subsidiaries, and (2) Dell Technologies, which continues to own Dell Technologies’ other businesses and subsidiaries.  In connection with and upon completion of the VMware Spin-off, Dell Technologies and VMware, Inc. entered into a Commercial Framework Agreement (the “CFA”).  The CFA provides a framework under which Dell Technologies and VMware, Inc. will continue their strategic commercial relationship after the transaction.  The CFA has an initial term of five years, with automatic one-year renewals occurring annually thereafter, subject to certain terms and conditions.  Dell Technologies and VMware, Inc. also entered into other agreements that will govern other aspects of their relationship, including, among others, a tax matters agreement and a transition services agreement.

[0001571996-21-000063:mdna:15]
Dell Technologies used the net proceeds from its pro rata share of the special cash dividend received from VMware, Inc., as well as cash on hand, to repay a total of $9.4 billion principal amount of debt.  For information about the debt repayments, see Note 18 of the Notes to the Condensed Consolidated Financial Statements included in this report.

[0001571996-21-000063:mdna:16]
The Company will report VMware results as discontinued operations beginning in the fourth quarter of Fiscal 2022.  See Note 1 and Note 18 of the Notes to the Condensed Consolidated Financial Statements included in this report for more information regarding the VMware Spin-off.

[0001571996-21-000063:mdna:17]
[same as prior period, unchanged from 0001571996-21-000040:mdna:17]

[0001571996-21-000063:mdna:18]
[same as prior period, unchanged from 0001571996-21-000040:mdna:18]

[0001571996-21-000063:mdna:19]
[same as prior period, unchanged from 0001571996-21-000040:mdna:19]

[0001571996-21-000063:mdna:20]
Our comprehensive portfolio of advanced storage solutions includes traditional as well as next-generation storage solutions (such as all-flash arrays, scale-out file, object platforms, and software-defined solutions).  We have simplified our storage portfolio to ensure that we deliver the technology needed for our customers’ digital transformation.  We continue to make enhancements to our portfolio of storage solutions and expect that these enhancements will drive long-term improvements in the business.  In May 2020, we released our new PowerStore offering, a differentiated midrange storage solution that enables seamless updates using microservices and container-based software architecture.  This offering allows us to compete more effectively within midrange storage and, as a result, we are seeing early signs of improving revenue velocity.

[0001571996-21-000063:mdna:21]
[same as prior period, unchanged from 0001571996-21-000040:mdna:22]

[0001571996-21-000063:mdna:22]
[same as prior period, unchanged from 0001571996-21-000040:mdna:23]

[0001571996-21-000063:mdna:23]
[same as prior period, unchanged from 0001571996-21-000040:mdna:24]

[0001571996-21-000063:mdna:24]
•Client Solutions Group (“CSG”) — CSG includes branded hardware (such as desktops, workstations, and notebooks) and branded peripherals (such as displays and projectors), as well as third-party software and peripherals.  Our computing devices are designed with our commercial and consumer customers’ needs in mind, and we seek to optimize performance, reliability, manageability, design, and security.  In addition to our traditional hardware business, we have a portfolio of thin client offerings that we believe will allow us to benefit from the growth trends in cloud computing.  For our customers that are seeking to simplify client lifecycle management, our PC as-a-Service offering combines hardware, software, lifecycle services, and financing into one all-encompassing solution that provides predictable pricing per seat per month through DFS.  CSG also offers attached software, peripherals, and services, including support and deployment, configuration, and extended warranty services.

[0001571996-21-000063:mdna:25]
[same as prior period, unchanged from 0001571996-21-000040:mdna:26]

[0001571996-21-000063:mdna:26]
[same as prior period, unchanged from 0001571996-21-000040:mdna:27]

[0001571996-21-000063:mdna:27]
[same as prior period, unchanged from 0001571996-21-000040:mdna:28]

[0001571996-21-000063:mdna:28]
62

[0001571996-21-000063:mdna:29]
Effective upon the completion of the VMware Spin-off in the fourth quarter of Fiscal 2022, as described under “Spin-off of VMware, Inc.,” our Consolidated Statements of Income will be recast to reflect VMware results as discontinued operations and as such, VMware will no longer be identified as a reportable segment.  Pursuant to the CFA, Dell Technologies will continue to integrate VMware, Inc.’s products and services with Dell Technologies’ offerings and sell them to end users.  The results of those transactions will be reflected within CSG and ISG, based on the nature of the underlying offering sold.  Dell Technologies will also continue to act as a distributor for VMware, Inc., purchasing VMware, Inc.’s standalone products and services for resale to end-user customers.  The results of this business will be reflected in Other businesses.  The Company's prior period segment results will be recast to reflect the change.  See Note 1 and Note 18 of the Notes to the Condensed Consolidated Financial Statements included in this report for more information regarding the VMware Spin-off.

[0001571996-21-000063:mdna:30]
Our Other businesses, described below, consist of products and services offerings of Secureworks and Virtustream, which are both majority-owned by Dell Technologies.  These businesses are not classified as reportable segments, either individually or collectively, as the results of the businesses are not material to our overall results and the businesses do not meet the criteria for reportable segments.

[0001571996-21-000063:mdna:31]
[same as prior period, unchanged from 0001571996-21-000040:mdna:30]

[0001571996-21-000063:mdna:32]
[same as prior period, unchanged from 0001571996-21-000040:mdna:31]

[0001571996-21-000063:mdna:33]
On October 1, 2021, we completed the sale of Boomi and certain related assets to Francisco Partners and TPG Capital for a total cash consideration of approximately $4.0 billion, resulting in a pre-tax gain on sale of $4.0 billion.  The Company ultimately recorded a $3.0 billion gain, net of $1.0 billion in tax expense.  The transaction was intended to support the Company’s focus on fueling growth initiatives through targeted investments to modernize Dell Technologies’ core infrastructure and by expanding in high-priority areas, including hybrid and private cloud, edge, telecommunications solutions, and the Company’s APEX offerings.

[0001571996-21-000063:mdna:34]
On September 1, 2020, we completed the sale of RSA Security to a consortium of investors for total cash consideration of approximately $2.082 billion, resulting in a pre-tax gain on sale of $338 million.  The Company ultimately recorded a $21 million loss net of taxes.  The transaction was intended to further simplify our product portfolio and corporate structure.

[0001571996-21-000063:mdna:35]
Prior to the divestitures, the operating results of Boomi and RSA Security were included within Other businesses and did not qualify for presentation as a discontinued operation.  See Note 1 of the Notes to the Condensed Consolidated Financial Statements included in this report for more information about these transactions.

[0001571996-21-000063:mdna:36]
[same as prior period, unchanged from 0001571996-21-000040:mdna:34]

[0001571996-21-000063:mdna:37]
[same as prior period, unchanged from 0001571996-21-000040:mdna:35]

[0001571996-21-000063:mdna:38]
[same as prior period, unchanged from 0001571996-21-000040:mdna:36]

[0001571996-21-000063:mdna:39]
[same as prior period, unchanged from 0001571996-21-000040:mdna:37]

[0001571996-21-000063:mdna:40]
As part of our strategy, we will continue to evaluate opportunities for strategic investments through our venture capital investment arm, Dell Technologies Capital, with a focus on emerging technology areas that are relevant to all segments of our business and that will complement our existing portfolio of solutions.  Our investment areas include storage, software-defined networking, management and orchestration, security, machine learning and artificial intelligence, Big Data and analytics, cloud, edge computing, and software development operations.  As of October 29, 2021 and January 29, 2021, Dell Technologies held strategic investments of $1.5 billion and $1.4 billion, respectively.

[0001571996-21-000063:mdna:41]
In addition to these investments, we also may make disciplined acquisitions targeting businesses that advance our strategic objectives and accelerate our innovation agenda.

[0001571996-21-000063:mdna:42]
[same as prior period, unchanged from 0001571996-21-000040:mdna:39]

[0001571996-21-000063:mdna:43]
[same as prior period, unchanged from 0001571996-21-000040:mdna:40]

[0001571996-21-000063:mdna:44]
The health of our employees, customers, business partners, and communities remains our primary focus.  During Fiscal 2021, we took numerous actions in response to COVID-19, including a swift implementation of our business continuity plans.  Our crisis management team remains actively engaged to respond to changes in our environment quickly and effectively, and to ensure that our ongoing response activities are aligned with recommendations of the WHO and the U.S. Centers for Disease Control and Prevention, and with governmental regulations.  We are adjusting restrictions previously implemented as new information becomes available, governmental regulations are updated, and vaccines become more widely distributed.

[0001571996-21-000063:mdna:45]
In September 2021, the President of the United States signed an executive order that requires employers with U.S. Government contracts to ensure that their U.S.-based employees, contractors, and subcontractors that work on or in support of such contracts are fully vaccinated against COVID-19 (subject to medical and religious exemptions). We are a covered federal contractor due to a number of our agreements.  We are taking steps to comply with the executive order for federal contractors.  It is currently not possible to predict the impact the executive order may have on our workforce.

[0001571996-21-000063:mdna:46]
Most of our employees were previously equipped with remote work capabilities over the past several years, which enabled us to quickly establish a work-from-home posture for the majority of our employees.  Further, we implemented pandemic-specific protocols for our essential employees whose jobs require them to be on-site or with customers.  We are deploying return-to-site processes based on ongoing assessments of local conditions by our management team, including a global policy requiring vaccination or a negative COVID-19 test for persons entering a Dell site.  We will continue to monitor conditions and utilize remote work practices to ensure the health and safety of our employees, customers, and business partners.

[0001571996-21-000063:mdna:47]
We continue to work closely with our customers and business partners to support them as they expand their own remote work solutions and contingency plans and to help them access our products and services remotely.  Our agility, our breadth, and our scale has and will continue to benefit us in serving our customers and business partners during this period of accelerated digital transformation, evolution of the “do anything from anywhere” economy, and uncertainty relating to the effects of COVID-19.

[0001571996-21-000063:mdna:48]
Notable actions include the following:

[0001571996-21-000063:mdna:49]
[same as prior period, unchanged from 0001571996-21-000040:mdna:43]

[0001571996-21-000063:mdna:50]
[same as prior period, unchanged from 0001571996-21-000040:mdna:44]

[0001571996-21-000063:mdna:51]
•Our close relationships and ability to connect directly with our customers through our e-commerce business have enabled us to quickly meet the immediate demands of the work- and learn-from-home environments as well as the long-term demands of in-office, remote, and hybrid workforce environments.

[0001571996-21-000063:mdna:52]
[same as prior period, unchanged from 0001571996-21-000040:mdna:46]

[0001571996-21-000063:mdna:53]
•We continue to drive innovation and excellence in engineering with a largely remote workforce.  Engineers and product teams have delivered several critical solutions, including cloud updates, key client product refreshes,  PowerStore midrange storage and software, and recently announced IT as-a-Service and cloud offerings within the APEX portfolio.

[0001571996-21-000063:mdna:54]
[same as prior period, unchanged from 0001571996-21-000040:mdna:48]

[0001571996-21-000063:mdna:55]
The impact of COVID-19 is accelerating digital transformation, and we continue to see opportunities to create value and grow in response to resilient demand for our IT solutions driven by a technology-enabled world.  We will continue to actively monitor global events and pursue prudent decisions to navigate in this uncertain and ever-changing environment.

[0001571996-21-000063:mdna:56]
[same as prior period, unchanged from 0001571996-21-000040:mdna:51]

[0001571996-21-000063:mdna:57]
We continue to be impacted by industry-wide constraints in the supply of limited-source components in certain product offerings as a result of the impacts of COVID-19.  Further, global economic recovery has led to growth in demand that has outpaced supply, resulting in an increase in orders pending fulfillment and extended lead times for our customers for certain products.

[0001571996-21-000063:mdna:58]
These supply constraints coupled with increasing demand are leading to increases in component costs, which, during the third quarter of Fiscal 2022, increased in the aggregate.  Component cost trends are dependent on the strength or weakness of actual end-user demand and supply dynamics, which will continue to evolve and ultimately impact the translation of the cost environment to pricing and operating results.  For both ISG and CSG, we expect the overall component cost environment to remain inflationary but begin to stabilize for the remainder of Fiscal 2022.  Further, we continue to experience increased freight costs for expedited shipments of components and rate increases in the freight network as capacity remains constrained.  In response to these pressures, we continue to assess and take proactive steps to address our customers’ demands while balancing both profitability and growth.  We expect to continue navigating supply chain dynamics in to Fiscal 2023.

[0001571996-21-000063:mdna:59]
ISG — We expect that ISG will continue to be impacted by the changing nature of the IT infrastructure market and competitive environment.  During the first nine months of Fiscal 2022, ISG benefited from improvements in the macroeconomic environment that we expect will continue through the remaining three months of Fiscal 2022.  With our scale and strong solutions portfolio, we believe we are well-positioned to respond to ongoing competitive dynamics.  Within servers and networking, we will continue to be selective in determining whether to pursue certain large hyperscale and other server transactions.  We continue to focus on customer base expansion and lifetime value of customer relationships.

[0001571996-21-000063:mdna:60]
The unprecedented data growth throughout all industries is generating continued demand for our storage solutions and services.  Cloud native applications are expected to continue as a primary growth driver in the infrastructure market.  We believe the complementary cloud solutions across our business position us to meet these demands for our customers.  We benefit from offering solutions that address the emerging trends of enterprises deploying software-defined storage, hyper-converged infrastructure, and modular solutions based on server-centric architectures.  These trends are changing the way customers are consuming our traditional storage offerings.  We continue to expand our offerings in external storage arrays, which incorporate flexible, cloud-based functionality.

[0001571996-21-000063:mdna:61]
Through our research and development efforts, we are developing new solutions in this rapidly changing industry that we believe will enable us to continue to provide superior solutions to our customers.  Our customer base includes a growing number of service providers, such as cloud service providers, software-as-a-service companies, consumer webtech providers, and telecommunications companies.  These service providers turn to Dell Technologies for our advanced solutions that enable efficient service delivery at cloud scale.  Through our collaborative, customer-focused approach to innovation, we strive to deliver new and relevant solutions and software to the market quickly and efficiently.

[0001571996-21-000063:mdna:62]
CSG — Our CSG offerings are an important element of our strategy, generating strong cash flow and opportunities for cross-selling of complementary solutions.  During the first nine months of Fiscal 2022, CSG net revenue continued to be strong across product offerings, driven primarily by the global economic recovery coupled with customers seeking improved connectivity and productivity in both personal and professional environments.

[0001571996-21-000063:mdna:63]
While we expect that the CSG demand environment will continue to be subject to seasonal trends, we anticipate continued strong CSG demand through the remaining three months of Fiscal 2022, in line with industry demand forecasts.  Competitive dynamics continue to be a factor in our CSG business and will impact pricing and operating results.  We remain committed to our long-term strategy for CSG and will continue to make investments to innovate across the portfolio, while benefiting from consolidation trends that are occurring in the markets in which we compete.

[0001571996-21-000063:mdna:64]
Recurring Revenue and Consumption Models — Our customers are seeking new and innovative models that address how they consume our solutions.  We offer options including as-a-service, utility, leases, and immediate pay models, all designed to match customers’ consumption and financing preferences.  Our multiyear agreements typically result in recurring revenue streams over the term of the arrangement.  We continue to evolve and build momentum across our family of as-a-Service offerings as we pursue our strategy of modernizing our core business solutions, with APEX at the forefront.  We expect that our flexible consumption models and as-a-service offerings through APEX will further strengthen our customer relationships and provide a foundation for growth in recurring revenue.

[0001571996-21-000063:mdna:65]
[same as prior period, unchanged from 0001571996-21-000040:mdna:60]

[0001571996-21-000063:mdna:66]
We manage our business on a U.S. dollar basis.  However, we have a large global presence, generating approximately half of our revenue by sales to customers outside of the United States during both the third quarter and first nine months of Fiscal 2022 and Fiscal 2021.  As a result, our revenue can be, and in such periods has been, impacted by fluctuations in foreign currency exchange rates.  We utilize a comprehensive hedging strategy intended to mitigate the impact of foreign currency volatility over time, and we adjust pricing when possible to further minimize foreign currency impacts.

[0001571996-21-000063:mdna:67]
[same as prior period, unchanged from 0001571996-21-000040:mdna:62]

[0001571996-21-000063:mdna:68]
[same as prior period, unchanged from 0001571996-21-000040:mdna:63]

[0001571996-21-000063:mdna:69]
[same as prior period, unchanged from 0001571996-21-000040:mdna:65]

[0001571996-21-000063:mdna:70]
[same as prior period, unchanged from 0001571996-21-000040:mdna:66]

[0001571996-21-000063:mdna:71]
[same as prior period, unchanged from 0001571996-21-000040:mdna:67]

[0001571996-21-000063:mdna:72]
Non-GAAP product net revenue, non-GAAP services net revenue, non-GAAP net revenue, non-GAAP product gross margin, non-GAAP services gross margin, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, and non-GAAP net income, as defined by us, exclude amortization of intangible assets, the impact of purchase accounting, transaction-related expenses and gains, stock-based compensation expense, other corporate expenses and, for non-GAAP net income, fair value adjustments on equity investments and an aggregate adjustment for income taxes.  As the excluded items have a material impact on our financial results, our management compensates for this limitation by relying primarily on our GAAP results and using non-GAAP financial measures supplementally or for projections when comparable GAAP financial measures are not available.

[0001571996-21-000063:mdna:73]
[same as prior period, unchanged from 0001571996-21-000040:mdna:69]

[0001571996-21-000063:mdna:74]
[same as prior period, unchanged from 0001571996-21-000040:mdna:70]

[0001571996-21-000063:mdna:75]
•Amortization of Intangible Assets — Amortization of intangible assets primarily consists of amortization of customer relationships, developed technology, and trade names.  In connection with our acquisition by merger of EMC on September 7, 2016, referred to as the EMC merger transaction, and the acquisition of Dell Inc. by Dell Technologies Inc. on October 29, 2013, referred to as the going-private transaction, all of the tangible and intangible assets and liabilities of EMC and Dell, respectively, were accounted for and recognized at fair value on the transaction dates.  Accordingly, for the periods presented, amortization of intangible assets primarily represents amortization associated with intangible assets recognized in connection with the EMC merger transaction and the going-private transaction.  Amortization charges for purchased intangible assets are significantly impacted by the timing and magnitude of our acquisitions, and these charges may vary in amount from period to period.  We exclude these charges for purposes of calculating the non-GAAP financial measures presented below to facilitate an enhanced understanding of our current operating performance and provide more meaningful period to period comparisons.

[0001571996-21-000063:mdna:76]
[same as prior period, unchanged from 0001571996-21-000040:mdna:72]

[0001571996-21-000063:mdna:77]
[same as prior period, unchanged from 0001571996-21-000040:mdna:73]

[0001571996-21-000063:mdna:78]
•Transaction-related Expenses and Gains — Transaction-related expenses typically consist of acquisition, integration, and divestiture-related costs and are expensed as incurred.  These expenses primarily represent costs for legal, banking, consulting, and advisory services.  From time to time, this category also may include transaction-related gains on divestitures of businesses or asset sales.  During the third quarter of Fiscal 2022, we recognized a gain of $4.0 billion on the sale of Boomi, while during the third quarter of Fiscal 2021, we recognized a gain of $338 million on the sale of RSA Security.  We exclude these items for purposes of calculating the non-GAAP financial measures presented below to facilitate an enhanced understanding of our current operating performance and provide more meaningful period to period comparisons.

[0001571996-21-000063:mdna:79]
[same as prior period, unchanged from 0001571996-21-000040:mdna:75]

[0001571996-21-000063:mdna:80]
[same as prior period, unchanged from 0001571996-21-000040:mdna:76]

[0001571996-21-000063:mdna:81]
[same as prior period, unchanged from 0001571996-21-000040:mdna:77]

[0001571996-21-000063:mdna:82]
[same as prior period, unchanged from 0001571996-21-000040:mdna:78]

[0001571996-21-000063:mdna:83]
[same as prior period, unchanged from 0001571996-21-000040:mdna:79]

[0001571996-21-000063:mdna:84]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 29, 2021 |  | % Change |  | October 30, 2020 |  | October 29, 2021 |  | % Change |  | October 30, 2020 |
|  | (in millions, except percentages) |
| Product net revenue | $ | 21,540 |  |  | 24 | % |  | $ | 17,352 |  |  | $ | 58,968 |  |  | 18 | % |  | $ | 50,127 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | — |  |  |  |  | 2 |  |  | — |  |  |  |  | 8 |  |
| Non-GAAP product net revenue | $ | 21,540 |  |  | 24 | % |  | $ | 17,354 |  |  | $ | 58,968 |  |  | 18 | % |  | $ | 50,135 |  |
| Services net revenue | $ | 6,854 |  |  | 12 | % |  | $ | 6,130 |  |  | $ | 20,035 |  |  | 11 | % |  | $ | 17,985 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 11 |  |  |  |  | 37 |  |  | 34 |  |  |  |  | 121 |  |
| Non-GAAP services net revenue | $ | 6,865 |  |  | 11 | % |  | $ | 6,167 |  |  | $ | 20,069 |  |  | 11 | % |  | $ | 18,106 |  |
| Net revenue | $ | 28,394 |  |  | 21 | % |  | $ | 23,482 |  |  | $ | 79,003 |  |  | 16 | % |  | $ | 68,112 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 11 |  |  |  |  | 39 |  |  | 34 |  |  |  |  | 129 |  |
| Non-GAAP net revenue | $ | 28,405 |  |  | 21 | % |  | $ | 23,521 |  |  | $ | 79,037 |  |  | 16 | % |  | $ | 68,241 |  |
| Product gross margin | $ | 3,988 |  |  | 12 | % |  | $ | 3,563 |  |  | $ | 11,831 |  |  | 16 | % |  | $ | 10,204 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 277 |  |  |  |  | 376 |  |  | 828 |  |  |  |  | 1,122 |  |
| Impact of purchase accounting | 1 |  |  |  |  | 3 |  |  | 3 |  |  |  |  | 13 |  |
| Stock-based compensation expense | 14 |  |  |  |  | 7 |  |  | 35 |  |  |  |  | 17 |  |
| Other corporate expenses | 1 |  |  |  |  | 12 |  |  | 5 |  |  |  |  | 15 |  |
| Non-GAAP product gross margin | $ | 4,281 |  |  | 8 | % |  | $ | 3,961 |  |  | $ | 12,702 |  |  | 12 | % |  | $ | 11,371 |  |
| Services gross margin | $ | 4,071 |  |  | 10 | % |  | $ | 3,698 |  |  | $ | 11,871 |  |  | 7 | % |  | $ | 11,066 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | (2) |  |  |  |  | (1) |  |  | (2) |  |  |  |  | — |  |
| Impact of purchase accounting | 11 |  |  |  |  | 37 |  |  | 34 |  |  |  |  | 121 |  |
| Stock-based compensation expense | 48 |  |  |  |  | 44 |  |  | 148 |  |  |  |  | 124 |  |
| Other corporate expenses | 1 |  |  |  |  | 32 |  |  | 17 |  |  |  |  | 40 |  |
| Non-GAAP services gross margin | $ | 4,129 |  |  | 8 | % |  | $ | 3,810 |  |  | $ | 12,068 |  |  | 6 | % |  | $ | 11,351 |  |

[0001571996-21-000063:mdna:85]
[same as prior period, unchanged from 0001571996-21-000040:mdna:83]

[0001571996-21-000063:mdna:86]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 29, 2021 |  | % Change |  | October 30, 2020 |  | October 29, 2021 |  | % Change |  | October 30, 2020 |
|  | (in millions, except percentages) |
| Gross margin | $ | 8,059 |  |  | 11 | % |  | $ | 7,261 |  |  | $ | 23,702 |  |  | 11 | % |  | $ | 21,270 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 275 |  |  |  |  | 375 |  |  | 826 |  |  |  |  | 1,122 |  |
| Impact of purchase accounting | 12 |  |  |  |  | 40 |  |  | 37 |  |  |  |  | 134 |  |
| Stock-based compensation expense | 62 |  |  |  |  | 51 |  |  | 183 |  |  |  |  | 141 |  |
| Other corporate expenses | 2 |  |  |  |  | 44 |  |  | 22 |  |  |  |  | 55 |  |
| Non-GAAP gross margin | $ | 8,410 |  |  | 8 | % |  | $ | 7,771 |  |  | $ | 24,770 |  |  | 9 | % |  | $ | 22,722 |  |
| Operating expenses | $ | 6,710 |  |  | 9 | % |  | $ | 6,132 |  |  | $ | 19,606 |  |  | 7 | % |  | $ | 18,303 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | (419) |  |  |  |  | (470) |  |  | (1,288) |  |  |  |  | (1,425) |  |
| Impact of purchase accounting | (5) |  |  |  |  | (9) |  |  | (25) |  |  |  |  | (31) |  |
| Transaction-related expenses | (311) |  |  |  |  | (52) |  |  | (422) |  |  |  |  | (211) |  |
| Stock-based compensation expense | (410) |  |  |  |  | (385) |  |  | (1,223) |  |  |  |  | (1,078) |  |
| Other corporate expenses | (23) |  |  |  |  | (170) |  |  | (271) |  |  |  |  | (340) |  |
| Non-GAAP operating expenses | $ | 5,542 |  |  | 10 | % |  | $ | 5,046 |  |  | $ | 16,377 |  |  | 8 | % |  | $ | 15,218 |  |
| Operating income | $ | 1,349 |  |  | 19 | % |  | $ | 1,129 |  |  | $ | 4,096 |  |  | 38 | % |  | $ | 2,967 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 694 |  |  |  |  | 845 |  |  | 2,114 |  |  |  |  | 2,547 |  |
| Impact of purchase accounting | 17 |  |  |  |  | 49 |  |  | 62 |  |  |  |  | 165 |  |
| Transaction-related expenses | 311 |  |  |  |  | 52 |  |  | 422 |  |  |  |  | 211 |  |
| Stock-based compensation expense | 472 |  |  |  |  | 436 |  |  | 1,406 |  |  |  |  | 1,219 |  |
| Other corporate expenses | 25 |  |  |  |  | 214 |  |  | 293 |  |  |  |  | 395 |  |
| Non-GAAP operating income | $ | 2,868 |  |  | 5 | % |  | $ | 2,725 |  |  | $ | 8,393 |  |  | 12 | % |  | $ | 7,504 |  |
| Net income | $ | 3,888 |  |  | 341 | % |  | $ | 881 |  |  | $ | 5,706 |  |  | 164 | % |  | $ | 2,162 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 694 |  |  |  |  | 845 |  |  | 2,114 |  |  |  |  | 2,547 |  |
| Impact of purchase accounting | 17 |  |  |  |  | 49 |  |  | 62 |  |  |  |  | 165 |  |
| Transaction-related (income) and expenses | (3,607) |  |  |  |  | (286) |  |  | (3,508) |  |  |  |  | (247) |  |
| Stock-based compensation expense | 472 |  |  |  |  | 436 |  |  | 1,406 |  |  |  |  | 1,219 |  |
| Other corporate expenses | 25 |  |  |  |  | 106 |  |  | 293 |  |  |  |  | 287 |  |
| Fair value adjustments on equity investments | (27) |  |  |  |  | (489) |  |  | (352) |  |  |  |  | (591) |  |
| Aggregate adjustment for income taxes | 553 |  |  |  |  | 169 |  |  | 24 |  |  |  |  | (1,067) |  |
| Non-GAAP net income | $ | 2,015 |  |  | 18 | % |  | $ | 1,711 |  |  | $ | 5,745 |  |  | 28 | % |  | $ | 4,475 |  |

[0001571996-21-000063:mdna:87]
70

[0001571996-21-000063:mdna:88]
[same as prior period, unchanged from 0001571996-21-000040:mdna:84]

[0001571996-21-000063:mdna:89]
[same as prior period, unchanged from 0001571996-21-000040:mdna:85]

[0001571996-21-000063:mdna:90]
[same as prior period, unchanged from 0001571996-21-000040:mdna:86]

[0001571996-21-000063:mdna:91]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 29, 2021 |  | % Change |  | October 30, 2020 |  | October 29, 2021 |  | % Change |  | October 30, 2020 |
|  | (in millions, except percentages) |
| Net income | $ | 3,888 |  |  | 341 | % |  | $ | 881 |  |  | $ | 5,706 |  |  | 164 | % |  | $ | 2,162 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Interest and other, net (a) | (3,436) |  |  |  |  | (273) |  |  | (2,689) |  |  |  |  | 929 |  |
| Income tax expense (benefit) (b) | 897 |  |  |  |  | 521 |  |  | 1,079 |  |  |  |  | (124) |  |
| Depreciation and amortization | 1,242 |  |  |  |  | 1,361 |  |  | 3,721 |  |  |  |  | 4,017 |  |
| EBITDA | $ | 2,591 |  |  | 4 | % |  | $ | 2,490 |  |  | $ | 7,817 |  |  | 12 | % |  | $ | 6,984 |  |
| EBITDA | $ | 2,591 |  |  | 4 | % |  | $ | 2,490 |  |  | $ | 7,817 |  |  | 12 | % |  | $ | 6,984 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense | 472 |  |  |  |  | 436 |  |  | 1,406 |  |  |  |  | 1,219 |  |
| Impact of purchase accounting (c) | 11 |  |  |  |  | 39 |  |  | 38 |  |  |  |  | 129 |  |
| Transaction-related expenses (d) | 311 |  |  |  |  | 52 |  |  | 422 |  |  |  |  | 211 |  |
| Other corporate expenses (e) | 25 |  |  |  |  | 214 |  |  | 293 |  |  |  |  | 395 |  |
| Adjusted EBITDA | $ | 3,410 |  |  | 6 | % |  | $ | 3,231 |  |  | $ | 9,976 |  |  | 12 | % |  | $ | 8,938 |  |

[0001571996-21-000063:mdna:92]
[same as prior period, unchanged from 0001571996-21-000040:mdna:88]

[0001571996-21-000063:mdna:93]
[same as prior period, unchanged from 0001571996-21-000040:mdna:89]

[0001571996-21-000063:mdna:94]
(b)See Note 10 of the Notes to the Condensed Consolidated Financial Statements included in this report for additional information on discrete tax items recorded during the third quarter and first nine months of Fiscal 2022 and Fiscal 2021.

[0001571996-21-000063:mdna:95]
[same as prior period, unchanged from 0001571996-21-000040:mdna:91]

[0001571996-21-000063:mdna:96]
(d)Transaction-related expenses consist of acquisition, integration, and divestiture-related costs.

[0001571996-21-000063:mdna:97]
[same as prior period, unchanged from 0001571996-21-000040:mdna:93]

[0001571996-21-000063:mdna:98]
[same as prior period, unchanged from 0001571996-21-000040:mdna:94]

[0001571996-21-000063:mdna:99]
[same as prior period, unchanged from 0001571996-21-000040:mdna:95]

[0001571996-21-000063:mdna:100]
[same as prior period, unchanged from 0001571996-21-000040:mdna:96]

[0001571996-21-000063:mdna:101]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 29, 2021 |  |  |  | October 30, 2020 |  | October 29, 2021 |  |  |  | October 30, 2020 |
|  | Dollars |  | % ofNet Revenue |  | %Change |  | Dollars |  | % ofNet Revenue |  | Dollars |  | % ofNet Revenue |  | %Change |  | Dollars |  | % ofNet Revenue |
|  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products | $ | 21,540 |  |  | 75.9 | % |  | 24 | % |  | $ | 17,352 |  |  | 73.9 | % |  | $ | 58,968 |  |  | 74.6 | % |  | 18 | % |  | $ | 50,127 |  |  | 73.6 | % |
| Services | 6,854 |  |  | 24.1 | % |  | 12 | % |  | 6,130 |  |  | 26.1 | % |  | 20,035 |  |  | 25.4 | % |  | 11 | % |  | 17,985 |  |  | 26.4 | % |
| Total net revenue | $ | 28,394 |  |  | 100.0 | % |  | 21 | % |  | $ | 23,482 |  |  | 100.0 | % |  | $ | 79,003 |  |  | 100.0 | % |  | 16 | % |  | $ | 68,112 |  |  | 100.0 | % |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products (a) | $ | 3,988 |  |  | 18.5 | % |  | 12 | % |  | $ | 3,563 |  |  | 20.5 | % |  | $ | 11,831 |  |  | 20.1 | % |  | 16 | % |  | $ | 10,204 |  |  | 20.4 | % |
| Services (b) | 4,071 |  |  | 59.4 | % |  | 10 | % |  | 3,698 |  |  | 60.3 | % |  | 11,871 |  |  | 59.3 | % |  | 7 | % |  | 11,066 |  |  | 61.5 | % |
| Total gross margin | $ | 8,059 |  |  | 28.4 | % |  | 11 | % |  | $ | 7,261 |  |  | 30.9 | % |  | $ | 23,702 |  |  | 30.0 | % |  | 11 | % |  | $ | 21,270 |  |  | 31.2 | % |
| Operating expenses | $ | 6,710 |  |  | 23.6 | % |  | 9 | % |  | $ | 6,132 |  |  | 26.1 | % |  | $ | 19,606 |  |  | 24.8 | % |  | 7 | % |  | $ | 18,303 |  |  | 26.9 | % |
| Operating income | $ | 1,349 |  |  | 4.8 | % |  | 19 | % |  | $ | 1,129 |  |  | 4.8 | % |  | $ | 4,096 |  |  | 5.2 | % |  | 38 | % |  | $ | 2,967 |  |  | 4.4 | % |
| Net income | $ | 3,888 |  |  | 13.7 | % |  | 341 | % |  | $ | 881 |  |  | 3.8 | % |  | $ | 5,706 |  |  | 7.2 | % |  | 164 | % |  | $ | 2,162 |  |  | 3.2 | % |
| Net income attributable to Dell Technologies Inc. | $ | 3,843 |  |  | 13.5 | % |  | 362 | % |  | $ | 832 |  |  | 3.5 | % |  | $ | 5,561 |  |  | 7.0 | % |  | 175 | % |  | $ | 2,023 |  |  | 3.0 | % |
| Non-GAAP Financial Information |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products | $ | 21,540 |  |  | 75.8 | % |  | 24 | % |  | $ | 17,354 |  |  | 73.8 | % |  | $ | 58,968 |  |  | 74.6 | % |  | 18 | % |  | $ | 50,135 |  |  | 73.5 | % |
| Services | 6,865 |  |  | 24.2 | % |  | 11 | % |  | 6,167 |  |  | 26.2 | % |  | 20,069 |  |  | 25.4 | % |  | 11 | % |  | 18,106 |  |  | 26.5 | % |
| Total non-GAAP net revenue | $ | 28,405 |  |  | 100.0 | % |  | 21 | % |  | $ | 23,521 |  |  | 100.0 | % |  | $ | 79,037 |  |  | 100.0 | % |  | 16 | % |  | $ | 68,241 |  |  | 100.0 | % |
| Non-GAAP gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products (a) | $ | 4,281 |  |  | 19.9 | % |  | 8 | % |  | $ | 3,961 |  |  | 22.8 | % |  | $ | 12,702 |  |  | 21.5 | % |  | 12 | % |  | $ | 11,371 |  |  | 22.7 | % |
| Services (b) | 4,129 |  |  | 60.1 | % |  | 8 | % |  | 3,810 |  |  | 61.8 | % |  | 12,068 |  |  | 60.1 | % |  | 6 | % |  | 11,351 |  |  | 62.7 | % |
| Total non-GAAP gross margin | $ | 8,410 |  |  | 29.6 | % |  | 8 | % |  | $ | 7,771 |  |  | 33.0 | % |  | $ | 24,770 |  |  | 31.3 | % |  | 9 | % |  | $ | 22,722 |  |  | 33.3 | % |
| Non-GAAP operating expenses | $ | 5,542 |  |  | 19.5 | % |  | 10 | % |  | $ | 5,046 |  |  | 21.5 | % |  | $ | 16,377 |  |  | 20.7 | % |  | 8 | % |  | $ | 15,218 |  |  | 22.3 | % |
| Non-GAAP operating income | $ | 2,868 |  |  | 10.1 | % |  | 5 | % |  | $ | 2,725 |  |  | 11.6 | % |  | $ | 8,393 |  |  | 10.6 | % |  | 12 | % |  | $ | 7,504 |  |  | 11.0 | % |
| Non-GAAP net income | $ | 2,015 |  |  | 7.1 | % |  | 18 | % |  | $ | 1,711 |  |  | 7.3 | % |  | $ | 5,745 |  |  | 7.3 | % |  | 28 | % |  | $ | 4,475 |  |  | 6.6 | % |
| EBITDA | $ | 2,591 |  |  | 9.1 | % |  | 4 | % |  | $ | 2,490 |  |  | 10.6 | % |  | $ | 7,817 |  |  | 9.9 | % |  | 12 | % |  | $ | 6,984 |  |  | 10.2 | % |
| Adjusted EBITDA | $ | 3,410 |  |  | 12.0 | % |  | 6 | % |  | $ | 3,231 |  |  | 13.7 | % |  | $ | 9,976 |  |  | 12.6 | % |  | 12 | % |  | $ | 8,938 |  |  | 13.1 | % |

[0001571996-21-000063:mdna:102]
[same as prior period, unchanged from 0001571996-21-000040:mdna:98]

[0001571996-21-000063:mdna:103]
[same as prior period, unchanged from 0001571996-21-000040:mdna:99]

[0001571996-21-000063:mdna:104]
[same as prior period, unchanged from 0001571996-21-000040:mdna:100]

[0001571996-21-000063:mdna:105]
[same as prior period, unchanged from 0001571996-21-000040:mdna:101]

[0001571996-21-000063:mdna:106]
[same as prior period, unchanged from 0001571996-21-000040:mdna:102]

[0001571996-21-000063:mdna:107]
During the third quarter and first nine months of Fiscal 2022, both net revenue and non-GAAP net revenue increased 21% and 16%, respectively.  These increases were due primarily to growth in net revenue for CSG and, to a lesser extent, increases in net revenue for ISG and VMware.  CSG net revenue benefited primarily from increased sales of commercial and consumer offerings, driven by strong demand as a result of the global economic recovery coupled with customers seeking improved connectivity and productivity.  ISG net revenue continued to benefit from overall improvements in the macroeconomic environment and a shift towards investment in IT infrastructure.  VMware net revenue increased primarily due to continued growth in sales of subscriptions and software-as-a-service (“SaaS”) offerings.

[0001571996-21-000063:mdna:108]
During the third quarter and first nine months of Fiscal 2022, our operating income increased 19% and 38%, respectively, and our non-GAAP operating income increased 5% and 12%, respectively.  The increases were primarily due to increases in operating income for CSG, driven primarily by our commercial offerings and, to a lesser extent, our consumer offerings.  Operating income also benefited from decreases in amortization of intangible assets during both Fiscal 2022 periods presented.

[0001571996-21-000063:mdna:109]
Our operating income as a percentage of net revenue remained flat at 4.8% and increased 80 basis points to 5.2% for the third quarter and first nine months of Fiscal 2022, respectively.  The increase in our operating income as a percentage of net revenue for the first nine months of Fiscal 2022 was driven primarily by a decrease in amortization of intangible assets.  Our non-GAAP operating income as a percentage of net revenue decreased 150 basis points to 10.1% and 40 basis points to 10.6% during the third quarter and first nine months of Fiscal 2022, respectively.  The decreases in our non-GAAP operating income as a percentage of net revenue were driven primarily by declines in gross margin as a percentage of net revenue, principally due to supply chain challenges and the inflationary cost environment coupled with a shift in mix towards CSG offerings.

[0001571996-21-000063:mdna:110]
Cash provided by operating activities was $7.2 billion and $5.5 billion for the first nine months of Fiscal 2022 and Fiscal 2021, respectively.  The increase in operating cash flows during the first nine months of Fiscal 2022 was driven by strong growth coupled with favorable working capital dynamics, compared to unfavorable working capital impacts during the first nine months of Fiscal 2021.  See “Market Conditions, Liquidity, and Capital Commitments” for further information on our cash flow metrics.

[0001571996-21-000063:mdna:111]
We continue to see opportunities to create value and grow in response to resilient demand for our IT solutions driven by a technology-enabled world.  We have demonstrated our ability to adjust as needed to changing market conditions with complementary solutions across all segments of our business, an agile workforce, and the strength of our global supply chain.  As we continue to innovate and modernize our core offerings, we believe that Dell Technologies is well-positioned for long-term profitable growth.

[0001571996-21-000063:mdna:112]
[same as prior period, unchanged from 0001571996-21-000040:mdna:107]

[0001571996-21-000063:mdna:113]
During the third quarter and first nine months of Fiscal 2022, both net revenue and non-GAAP net revenue increased 21% and 16%, respectively, driven primarily by increases in net revenue for CSG and, to a lesser extent, increases in net revenue for ISG and VMware.  See “Business Unit Results” for further information.

[0001571996-21-000063:mdna:114]
•Product Net Revenue — Product net revenue includes revenue from the sale of hardware products and software licenses.  During the third quarter and first nine months of Fiscal 2022, both product net revenue and non-GAAP product net revenue increased 24% and 18%, respectively, driven primarily by growth in CSG product net revenue and, to a lesser extent, ISG product net revenue.  CSG product net revenue increased during the third quarter and first nine months of Fiscal 2022 primarily due to increases in units sold of both commercial and consumer product offerings as a result of continued strength in the demand environment and, to a lesser extent, an increase in average selling price of our commercial offerings.  During the third quarter and first nine months of Fiscal 2022, ISG product net revenue increased due to increased sales volumes of our server offerings.  Additionally, we experienced an increase in average selling price of our server offerings during the third quarter only.

[0001571996-21-000063:mdna:115]
•Services Net Revenue — Services net revenue includes revenue from our services offerings and support services related to hardware products and software licenses.  During the third quarter and first nine months of Fiscal 2022, services net revenue increased 12% and 11%, respectively.  Non-GAAP services net revenue increased 11% during both Fiscal 2022 periods presented.  These increases were driven primarily by growth in CSG services net revenue and, to a lesser extent, growth in both VMware and ISG services net revenue.  CSG services net revenue increases were primarily attributable to growth within CSG hardware and software support and maintenance, while ISG services net revenue increased primarily as a result of growth within hardware support services.  VMware services net revenue increases were primarily driven by growth within VMware subscriptions and SaaS offerings.  A substantial portion of services net revenue is derived from offerings that have been deferred over a period of time, and, as a result, reported services net revenue growth rates will be different than reported product net revenue growth rates.

[0001571996-21-000063:mdna:116]
From a geographical perspective, net revenue generated by sales to customers in all regions increased during the third quarter and first nine months of Fiscal 2022, driven by strong CSG performance.

[0001571996-21-000063:mdna:117]
[same as prior period, unchanged from 0001571996-21-000040:mdna:112]

[0001571996-21-000063:mdna:118]
During the third quarter and first nine months of Fiscal 2022, our gross margin increased 11% to $8.1 billion and 11% to $23.7 billion, respectively.  Our non-GAAP gross margin increased 8% to $8.4 billion and 9% to $24.8 billion during the third quarter and first nine months of Fiscal 2022, respectively.  Both gross margin and non-GAAP gross margin benefited from an increase in gross margin for CSG and, to a lesser extent, increases for both VMware and ISG.  Gross margin and non-GAAP gross margin increases during the first nine months of Fiscal 2022 were partially offset by a decrease in gross margin for other businesses as a result of the impact of the divestiture of RSA Security during the third quarter of Fiscal 2021.

[0001571996-21-000063:mdna:119]
During the third quarter and first nine months of Fiscal 2022, our gross margin percentage decreased 250 basis points to 28.4% and 120 basis points to 30.0%, respectively.  The decrease in gross margin percentage during the third quarter of Fiscal 2022 was primarily due to unfavorable impacts in gross margin percentage across CSG, VMware, and ISG, driven in part by supply chain challenges and the inflationary cost environment, coupled with a shift in mix towards CSG.  These decreases were  partially offset by a decrease in amortization of intangible assets.  For the first nine months of Fiscal 2022, the decrease in gross margin percentage was driven by the same unfavorable impacts within VMware and ISG as well as a shift in mix towards CSG, partially offset by an increase in gross margin percentage for CSG and a decrease in amortization of intangible assets.  Non-GAAP gross margin percentage decreased 340 basis points to 29.6% and 200 basis points to 31.3% during the third quarter and first nine months of Fiscal 2022, respectively, driven by the same ISG, CSG, and VMware dynamics discussed above.

[0001571996-21-000063:mdna:120]
•Products — During the third quarter and first nine months of Fiscal 2022, product gross margin increased 12% to $4.0 billion and 16% to $11.8 billion, respectively.  The increases in product gross margin were primarily driven by growth in CSG product gross margin coupled with a decrease in amortization of intangible assets.  During the same Fiscal 2022 periods, non-GAAP product gross margin increased 8% to $4.3 billion and 12% to $12.7 billion, respectively.  The increases in non-GAAP product gross margin were primarily driven by an increase in CSG product gross margin.

[0001571996-21-000063:mdna:121]
During the third quarter and first nine months of Fiscal 2022, product gross margin percentage decreased 200 basis points to 18.5% and 30 basis points to 20.1%, respectively.  For the third quarter of Fiscal 2022, the decrease in product gross margin percentage was driven primarily by a decrease in CSG product gross margin percentage coupled with a shift in mix towards CSG, the effects of which were partially offset by a decrease in amortization of intangible assets.  The decrease in product gross margin percentage during the first nine months of Fiscal 2022 was driven primarily by a shift in product mix towards CSG.  During the same Fiscal 2022 periods, non-GAAP product gross margin percentage decreased 290 basis points to 19.9% and 120 basis points to 21.5%, respectively.  The decreases in non-GAAP product gross margin percentage for the third quarter and first nine months of Fiscal 2022 were driven by the same CSG dynamics discussed above.

[0001571996-21-000063:mdna:122]
•Services — During the third quarter and first nine months of Fiscal 2022, services gross margin increased 10% to $4.1 billion and 7% to $11.9 billion, respectively.  The increases in services gross margin were primarily driven by VMware and CSG and, to a lesser extent, ISG.  VMware services gross margin increased as a result of growth within subscription and SaaS offerings while CSG services gross margin increased due to growth in hardware support and maintenance.  During the same Fiscal 2022 periods, non-GAAP services gross margin increased 8% to $4.1 billion and 6% to $12.1 billion, respectively.  The changes were driven by the same dynamics discussed above.

[0001571996-21-000063:mdna:123]
During the third quarter and first nine months of Fiscal 2022, services gross margin percentage decreased 90 basis points to 59.4% and 220 basis points to 59.3%, respectively.  During the same Fiscal 2022 periods, non-GAAP services gross margin percentage decreased 170 basis points to 60.1% and 260 basis points to 60.1%, respectively.  For the third quarter of Fiscal 2022, the decreases were as a result of declines in services gross margin percentage for VMware and ISG coupled with a shift in mix towards CSG, partially offset by an increase in services gross margin percentage for CSG.  The declines for the first nine months of Fiscal 2022 were driven by a shift in mix towards CSG coupled with decreases in services gross margin percentage for CSG, VMware, and ISG.

[0001571996-21-000063:mdna:124]
[same as prior period, unchanged from 0001571996-21-000040:mdna:119]

[0001571996-21-000063:mdna:125]
[same as prior period, unchanged from 0001571996-21-000040:mdna:120]

[0001571996-21-000063:mdna:126]
The terms and conditions of our vendor rebate programs are largely based on product volumes and are generally negotiated either at the beginning of the annual or quarterly period, depending on the program.  The timing and amount of vendor rebates and other discounts we receive under the programs may vary from period to period, reflecting changes in the competitive environment.  We monitor our component costs and seek to address the effects of any changes to terms that might arise under our vendor rebate programs.  Our gross margins for the third quarter and first nine months of Fiscal 2022 and Fiscal 2021 were not materially affected by any changes to the terms of our vendor rebate programs, as the amounts we received under these programs were generally stable relative to our total net cost.  We are not aware of any significant changes to vendor pricing or rebate programs that may impact our results in the near term.

[0001571996-21-000063:mdna:127]
[same as prior period, unchanged from 0001571996-21-000040:mdna:122]

[0001571996-21-000063:mdna:128]
[same as prior period, unchanged from 0001571996-21-000040:mdna:123]

[0001571996-21-000063:mdna:129]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 29, 2021 |  |  |  | October 30, 2020 |  | October 29, 2021 |  |  |  | October 30, 2020 |
|  | Dollars |  | % ofNet Revenue |  | %Change |  | Dollars |  | % ofNet Revenue |  | Dollars |  | % ofNet Revenue |  | %Change |  | Dollars |  | % ofNet Revenue |
|  | (in millions, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative | $ | 5,293 |  |  | 18.6 | % |  | 11 | % |  | $ | 4,772 |  |  | 20.3 | % |  | $ | 15,398 |  |  | 19.5 | % |  | 7 | % |  | $ | 14,419 |  |  | 21.1 | % |
| Research and development | 1,417 |  |  | 5.0 | % |  | 4 | % |  | 1,360 |  |  | 5.8 | % |  | 4,208 |  |  | 5.3 | % |  | 8 | % |  | 3,884 |  |  | 5.7 | % |
| Total operating expenses | $ | 6,710 |  |  | 23.6 | % |  | 9 | % |  | $ | 6,132 |  |  | 26.1 | % |  | $ | 19,606 |  |  | 24.8 | % |  | 7 | % |  | $ | 18,303 |  |  | 26.8 | % |
|  | Three Months Ended |  | Nine Months Ended |
|  | October 29, 2021 |  |  |  | October 30, 2020 |  | October 29, 2021 |  |  |  | October 30, 2020 |
|  | Dollars |  | % of Non-GAAPNet Revenue |  | %Change |  | Dollars |  | % of Non-GAAPNet Revenue |  | Dollars |  | % ofNet Revenue |  | %Change |  | Dollars |  | % ofNet Revenue |
|  | (in millions, except percentages) |
| Non-GAAP operating expenses | $ | 5,542 |  |  | 19.5 | % |  | 10 | % |  | $ | 5,046 |  |  | 21.4 | % |  | $ | 16,377 |  |  | 20.7 | % |  | 8 | % |  | $ | 15,218 |  |  | 22.3 | % |

[0001571996-21-000063:mdna:130]
During the third quarter and first nine months of Fiscal 2022, operating expenses increased 9% and 7%, respectively.  Non-GAAP operating expenses increased 10% and 8% for the third quarter and first nine months of Fiscal 2022, respectively.  These increases were primarily driven by employee-related expenses as a result of performance-based compensation associated with strong operating results, coupled with the reintroduction of expenses that were temporarily reduced during Fiscal 2021 in response to the COVID-19 pandemic.

[0001571996-21-000063:mdna:131]
•Selling, General, and Administrative — Selling, general, and administrative (“SG&A”) expenses increased 11% and 7%, respectively, during the third quarter and first nine months of Fiscal 2022.  The increases were primarily due to an increase in employee-related compensation and benefits expense as well as an increase in outside services expense incurred in connection with our transformational initiatives, primarily the VMware Spin-off.

[0001571996-21-000063:mdna:132]
•Research and Development — Research and development (“R&D”) expenses are primarily composed of personnel-related expenses incurred to develop the software that powers our solutions.  R&D expenses grew 4% and 8% during the third quarter and first nine months of Fiscal 2022, respectively.  As a percentage of net revenue, R&D expenses were approximately 5.0% and 5.8% for the third quarter of Fiscal 2022 and Fiscal 2021, respectively, and 5.3% and 5.7% for the first nine months of Fiscal 2022 and Fiscal 2021, respectively.  The decreases in R&D expenses as a percentage of net revenue were attributable to revenue growth that outpaced the scale of R&D investments.  We intend to continue to support R&D initiatives to innovate and introduce new and enhanced solutions into the market.

[0001571996-21-000063:mdna:133]
[same as prior period, unchanged from 0001571996-21-000040:mdna:128]

[0001571996-21-000063:mdna:134]
[same as prior period, unchanged from 0001571996-21-000040:mdna:129]

[0001571996-21-000063:mdna:135]
During the third quarter and first nine months of Fiscal 2022, our operating income increased 19% and 38% to $1.3 billion and $4.1 billion, respectively, and our non-GAAP operating income increased 5% and 12% to $2.9 billion and $8.4 billion, respectively. The increases were primarily due to growth in operating income for CSG, driven primarily by our commercial offerings and, to a lesser extent, our consumer offerings.  Operating income during the third quarter and first nine months of Fiscal 2022 also benefited from a decrease in amortization of intangible assets.

[0001571996-21-000063:mdna:136]
Our operating income as a percentage of net revenue remained flat at 4.8% and increased 80 basis points to 5.2% for the third quarter and first nine months of Fiscal 2022.  The increase in our operating income as a percentage of net revenue for the first nine months of Fiscal 2022 was driven primarily by a decrease in amortization of intangible assets.  Our non-GAAP operating income as a percentage of net revenue decreased 150 basis points to 10.1% and 40 basis points to 10.6% during the third quarter and first nine months of Fiscal 2022, respectively.  The decreases in our non-GAAP operating income as a percentage of net revenue were driven primarily by declines in gross margin as a percentage of net revenue, principally due to supply chain challenges and the inflationary cost environment coupled with a shift in mix towards CSG offerings.

[0001571996-21-000063:mdna:137]
[same as prior period, unchanged from 0001571996-21-000040:mdna:131]

[0001571996-21-000063:mdna:138]
[same as prior period, unchanged from 0001571996-21-000040:mdna:132]

[0001571996-21-000063:mdna:139]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 29, 2021 |  | October 30, 2020 |  | October 29, 2021 |  | October 30, 2020 |
|  | (in millions) |
| Interest and other, net: |  |  |  |  |  |  |  |
| Investment income, primarily interest | $ | 11 |  |  | $ | 11 |  |  | $ | 32 |  |  | $ | 47 |  |
| Gain on investments, net | 27 |  |  | 489 |  |  | 352 |  |  | 591 |  |
| Interest expense | (482) |  |  | (566) |  |  | (1,475) |  |  | (1,855) |  |
| Foreign exchange | (33) |  |  | (31) |  |  | (146) |  |  | (130) |  |
| Gain on disposition of businesses and assets | 3,968 |  |  | 338 |  |  | 3,968 |  |  | 458 |  |
| Other | (55) |  |  | 32 |  |  | (42) |  |  | (40) |  |
| Total interest and other, net | $ | 3,436 |  |  | $ | 273 |  |  | $ | 2,689 |  |  | $ | (929) |  |

[0001571996-21-000063:mdna:140]
During the third quarter and first nine months of Fiscal 2022, the change in interest and other, net was favorable by $3.2 billion and $3.6 billion, respectively.  The favorability in both periods was primarily driven by the pre-tax gain of $4.0 billion on the sale of Boomi and, to a lesser extent, a decrease in interest expense due to debt paydowns.  The favorability was partially offset by a decrease in net gains on our strategic investments portfolio.  For further details on the Boomi divestiture, see Note 1 of the Notes to the Condensed Consolidated Financial Statements included in this report.

[0001571996-21-000063:mdna:141]
[same as prior period, unchanged from 0001571996-21-000040:mdna:135]

[0001571996-21-000063:mdna:142]
[same as prior period, unchanged from 0001571996-21-000040:mdna:136]

[0001571996-21-000063:mdna:143]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 29, 2021 |  | October 30, 2020 |  | October 29, 2021 |  | October 30, 2020 |
|  | (in millions, except percentages) |  | (in millions, except percentages) |
| Income before income taxes | $ | 4,785 |  |  | $ | 1,402 |  |  | $ | 6,785 |  |  | $ | 2,038 |  |
| Income tax expense (benefit) | $ | 897 |  |  | $ | 521 |  |  | $ | 1,079 |  |  | $ | (124) |  |
| Effective income tax rate | 18.7 | % |  | 37.2 | % |  | 15.9 | % |  | -6.1 | % |

[0001571996-21-000063:mdna:144]
For the third quarter of Fiscal 2022 and Fiscal 2021, our effective income tax rate was 18.7%  and 37.2%, respectively.   For the first nine months of Fiscal 2022 and Fiscal 2021, our effective income tax rate was 15.9% and -6.1%, respectively.  For the third quarter and first nine months of Fiscal 2022, our effective income tax rate includes tax expense of $1.0 billion related to the divestiture of Boomi during the third quarter of Fiscal 2022.  In comparison, for the first nine months of Fiscal 2021, our effective income tax rate included discrete tax benefits of $746 million related to an audit settlement that was recorded in the second quarter of Fiscal 2021 and tax expense of $359 million related to the divestiture of RSA Security during the third quarter  of Fiscal 2021.  Our effective income tax rates are also impacted by a change in our jurisdictional mix of income and lower overall taxes on foreign operations.

[0001571996-21-000063:mdna:145]
Our effective income tax rate can fluctuate depending on the geographic distribution of our worldwide earnings, as our foreign earnings are generally taxed at lower rates than in the United States.  The differences between our effective income tax rate and the U.S. federal statutory rate of 21% principally result from the geographical distribution of income, differences between the book and tax treatment of certain items, and the discrete tax items discussed above.  In certain jurisdictions, our tax rate is significantly less than the applicable statutory rate as a result of tax holidays.  The majority of our foreign income that is subject to these tax holidays and lower tax rates is attributable to Singapore and China.  A significant portion of these income tax benefits relates to a tax holiday that will be effective until January 31, 2029.  Our other tax holidays will expire in whole or in part during Fiscal 2022 through Fiscal 2030.  Many of these tax holidays and reduced tax rates may be extended when certain conditions are met or may be terminated early if certain conditions are not met.  As of October 29, 2021, we were not aware of any matters of non-compliance related to these tax holidays.

[0001571996-21-000063:mdna:146]
[same as prior period, unchanged from 0001571996-21-000040:mdna:140]

[0001571996-21-000063:mdna:147]
[same as prior period, unchanged from 0001571996-21-000040:mdna:141]

[0001571996-21-000063:mdna:148]
During the third quarter and first nine months of Fiscal 2022, net income increased 341% to $3.9 billion and 164% to $5.7 billion, respectively.  The increases for the third quarter and first nine months of Fiscal 2022 were primarily attributable to a favorable change in interest and other, net, as result of the gain on sale of Boomi and, to a lesser extent, an increase in operating income.  Non-GAAP net income increased 18% to $2.0 billion and 28% to $5.7 billion during the third quarter and first nine months of Fiscal 2022, respectively.  The increases in non-GAAP net income during both the third quarter and first nine months of Fiscal 2022 were primarily attributable to an increase in non-GAAP operating income and a reduction in interest expense during the first nine months of Fiscal 2022, partially offset by an increase in tax expense.

[0001571996-21-000063:mdna:149]
[same as prior period, unchanged from 0001571996-21-000040:mdna:143]

[0001571996-21-000063:mdna:150]
Net income attributable to non-controlling interests consists of net income or loss attributable to our non-controlling interests in VMware, Inc. and Secureworks.  During the third quarter of Fiscal 2022 and Fiscal 2021, net income attributable to non-controlling interests was $45 million and $49 million, respectively.  The decrease in net income attributable to non-controlling interests during the third quarter of Fiscal 2022 was primarily due to a decrease in net income attributable to our non-controlling interest in VMware, Inc.

[0001571996-21-000063:mdna:151]
During the first nine months of Fiscal 2022 and Fiscal 2021, net income attributable to non-controlling interests was $145 million and $139 million, respectively.  The increase in net income attributable to non-controlling interests during the first nine months of Fiscal 2022 was primarily due to an increase in net income attributable to our non-controlling interest in VMware, Inc.  For more information about our non-controlling interests, see Note 12 of the Notes to the Condensed Consolidated Financial Statements included in this report.

[0001571996-21-000063:mdna:152]
[same as prior period, unchanged from 0001571996-21-000040:mdna:146]

[0001571996-21-000063:mdna:153]
Net income attributable to Dell Technologies Inc. represents net income and an adjustment for non-controlling interests.  During the third quarter of Fiscal 2022 and Fiscal 2021, net income attributable to Dell Technologies Inc. was $3.8 billion and $0.8 billion, respectively.  During the first nine months of Fiscal 2022 and Fiscal 2021, net income attributable to Dell Technologies Inc. was $5.6 billion and $2.0 billion, respectively.  The increase in net income attributable to Dell Technologies Inc. during the third quarter and first nine months of Fiscal 2022 was primarily attributable to increases in net income for both periods.

[0001571996-21-000063:mdna:154]
79

[0001571996-21-000063:mdna:155]
[same as prior period, unchanged from 0001571996-21-000040:mdna:148]

[0001571996-21-000063:mdna:156]
[same as prior period, unchanged from 0001571996-21-000040:mdna:149]

[0001571996-21-000063:mdna:157]
[same as prior period, unchanged from 0001571996-21-000040:mdna:150]

[0001571996-21-000063:mdna:158]
[same as prior period, unchanged from 0001571996-21-000040:mdna:151]

[0001571996-21-000063:mdna:159]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 29, 2021 |  | % Change |  | October 30, 2020 |  | October 29, 2021 |  | % Change |  | October 30, 2020 |
|  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Servers and networking | $ | 4,533 |  |  | 9 | % |  | $ | 4,164 |  | $ | 13,104 |  | 8 | % |  | $ | 12,118 |
| Storage | 3,895 |  |  | 1 | % |  | 3,860 |  | 11,667 |  | — | % |  | 11,682 |
| Total ISG net revenue | $ | 8,428 |  |  | 5 | % |  | $ | 8,024 |  | $ | 24,771 |  | 4 | % |  | $ | 23,800 |
| Operating income: |  |  |  |  |  |  |  |  |  |  |  |
| ISG operating income | $ | 892 |  |  | 1 | % |  | $ | 882 |  | $ | 2,650 |  | 2 | % |  | $ | 2,587 |
| % of segment net revenue | 10.6 | % |  |  |  | 11.0 | % |  | 10.7 | % |  |  |  | 10.9 | % |

[0001571996-21-000063:mdna:160]
Net Revenue — During the third quarter and first nine months of Fiscal 2022, ISG net revenue increased 5% and 4%, respectively.  These increases were primarily driven by sales of servers and networking attributable to improvements in the macroeconomic environment and a shift towards investment in IT infrastructure.  In comparison, net revenue during the third quarter and first nine months of Fiscal 2021 was affected by a weaker demand environment as a result of COVID-19, when customers shifted their investments toward remote work and business continuity solutions.

[0001571996-21-000063:mdna:161]
Net revenue from sales of servers and networking increased 9% and 8% during the third quarter and first nine months of Fiscal 2022, respectively, as a result of an increase in units sold due to continued demand for our PowerEdge servers.  During the third quarter of Fiscal 2022, the increase in net revenue was further driven by an increase in average selling price for our PowerEdge servers as we managed pricing in response to the cost environment.

[0001571996-21-000063:mdna:162]
Storage revenue increased 1% and remained flat during the third quarter and first nine months of Fiscal 2022, respectively.  We benefited from growth within hyper-converged infrastructure which was offset by a decline in other storage offerings.  To a lesser extent, during the third quarter of Fiscal 2022, we also benefited from growth within our data protection offerings.  Overall, we have experienced growth in demand for the majority of our storage offerings, most notably within midrange storage, that we expect will benefit net revenue in future periods.

[0001571996-21-000063:mdna:163]
ISG customers are seeking new and innovative models that address how they consume our solutions.  We offer options including as-a-service, utility, leases, and immediate pay models, all designed to match customers’ consumption and financing preferences.  Our multiyear agreements typically result in recurring revenue streams over the term of the arrangement.  We expect that our flexible consumption models and as-a-service offerings through APEX will further strengthen our customer relationships and provide a foundation for growth in recurring revenue.

[0001571996-21-000063:mdna:164]
From a geographical perspective, net revenue attributable to ISG increased in all regions during the third quarter and first nine months of Fiscal 2022.

[0001571996-21-000063:mdna:165]
Operating Income — During the third quarter and first nine months of Fiscal 2022, ISG operating income as a percentage of net revenue decreased 40 basis points to 10.6% and 20 basis points to 10.7%, respectively.  The declines in operating income as a percentage of net revenue during both Fiscal 2022 periods were driven by declines in ISG gross margin percentage.  ISG gross margin percentage decreased as a result of a shift in mix within ISG towards servers and networking coupled with a decline in gross margin percentage for storage, in part due to a shift in mix of storage offerings sold.  The decrease in gross margin percentage was partially offset by a decrease in operating expense as a percentage of net revenue.

[0001571996-21-000063:mdna:166]
81

[0001571996-21-000063:mdna:167]
[same as prior period, unchanged from 0001571996-21-000040:mdna:161]

[0001571996-21-000063:mdna:168]
[same as prior period, unchanged from 0001571996-21-000040:mdna:162]

[0001571996-21-000063:mdna:169]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 29, 2021 |  | % Change |  | October 30, 2020 |  | October 29, 2021 |  | % Change |  | October 30, 2020 |
|  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 12,292 |  | 40 | % |  | $ | 8,783 |  | $ | 32,668 |  |  | 28 | % |  | $ | 25,456 |  |
| Consumer | 4,254 |  | 21 | % |  | 3,503 |  | 11,446 |  |  | 25 | % |  | 9,137 |  |
| Total CSG net revenue | $ | 16,546 |  | 35 | % |  | $ | 12,286 |  | $ | 44,114 |  |  | 28 | % |  | $ | 34,593 |  |
| Operating income: |  |  |  |  |  |  |  |  |  |  |  |
| CSG operating income | $ | 1,147 |  | 14 | % |  | $ | 1,002 |  | $ | 3,232 |  |  | 40 | % |  | $ | 2,309 |  |
| % of segment net revenue | 6.9 | % |  |  |  | 8.2 | % |  | 7.3 | % |  |  |  | 6.7 | % |

[0001571996-21-000063:mdna:170]
Net Revenue — During the third quarter and first nine months of Fiscal 2022, CSG net revenue increased 35% and 28%, respectively, driven primarily by increases in units sold across the majority of product offerings as a result of continued strong demand.  Increases in average selling price, principally within our commercial offerings, also contributed to revenue growth.

[0001571996-21-000063:mdna:171]
Commercial revenue increased 40% and 28% during the third quarter and first nine months of Fiscal 2022, respectively, primarily due to an increase in sales of commercial desktops and notebooks driven by continued strong demand as customers invest in in-office, remote, and hybrid workforce environments.  Increases in average selling price also contributed to revenue growth, most notably in the third quarter of Fiscal 2022, as we continue to navigate through supply chain shortages and managed pricing in response to the current inflationary cost environment.

[0001571996-21-000063:mdna:172]
Consumer revenue increased 21% and 25% during the third quarter and first nine months of Fiscal 2022, respectively, primarily due to an increase in units sold as a result of strong demand across the majority of consumer product offerings.

[0001571996-21-000063:mdna:173]
From a geographical perspective, net revenue attributable to CSG increased across all regions during the third quarter and first nine months of Fiscal 2022.

[0001571996-21-000063:mdna:174]
Operating Income — During the third quarter of Fiscal 2022, CSG operating income as a percentage of net revenue decreased 130 basis points to 6.9%.  The decrease was primarily attributable to declines in both commercial and consumer gross margin percentages which were impacted by heightened supply chain challenges, logistics costs, and the inflationary component cost environment.  The gross margin percentage decreases were partially offset by a shift in mix towards commercial product offerings and a decrease in operating expenses as a percentage of net revenue.

[0001571996-21-000063:mdna:175]
During the first nine months of Fiscal 2022, CSG operating income as a percentage of net revenue increased 60 basis points to 7.3%.  The increase was primarily driven by an increase in gross margin percentage, principally within our consumer offerings, coupled with a decrease in operating expenses as a percentage of net revenue.  The increase in gross margin percentage was primarily driven by disciplined pricing as we managed through both cost and supply chain challenges discussed above.  These challenges were more unfavorable to the third quarter of Fiscal 2022 as compared to the first half of Fiscal 2022.

[0001571996-21-000063:mdna:176]
[same as prior period, unchanged from 0001571996-21-000040:mdna:170]

[0001571996-21-000063:mdna:177]
[same as prior period, unchanged from 0001571996-21-000040:mdna:171]

[0001571996-21-000063:mdna:178]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 29, 2021 |  | % Change |  | October 30, 2020 |  | October 29, 2021 |  | % Change |  | October 30, 2020 |
|  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| VMware net revenue | $ | 3,178 |  | 10 | % |  | $ | 2,893 |  | $ | 9,317 |  |  | 9 | % |  | $ | 8,556 |  |
| Operating income: |  |  |  |  |  |  |  |  |  |  |  |
| VMware operating income | $ | 837 |  | — | % |  | $ | 837 |  | $ | 2,527 |  |  | 1 | % |  | $ | 2,504 |  |
| % of segment net revenue | 26.3 | % |  |  |  | 28.9 | % |  | 27.1 | % |  |  |  | 29.3 | % |

[0001571996-21-000063:mdna:179]
Net Revenue — VMware net revenue primarily consists of revenue from the sale of software licenses under perpetual licenses and subscription and SaaS offerings, as well as related software maintenance services, support, training, consulting services, and hosted services.  VMware net revenue for the third quarter and first nine months of Fiscal 2022 increased 10% and 9%, respectively, primarily due to growth in sales of subscription and SaaS offerings, driven by increased demand for cloud offerings.  Both license revenue and software maintenance revenue also increased to a lesser extent, with the latter continuing to benefit from maintenance contracts sold in previous periods.

[0001571996-21-000063:mdna:180]
VMware net revenue for the third quarter and first nine months of Fiscal 2022 increased in both the United States and internationally.

[0001571996-21-000063:mdna:181]
Operating Income — During the third quarter and first nine months of Fiscal 2022, VMware operating income as a percentage of net revenue decreased 260 basis points to 26.3% and 220 basis points to 27.1%, respectively.  These decreases were due to a decline in VMware gross margin percentage and an increase in operating expense as a percentage of net revenue.  VMware gross margin percentage declined in part due to a transition towards subscription and SaaS offerings.  Operating expenses increased as a result of higher employee compensation expense primarily attributable to investments in key R&D initiatives, coupled with the reintroduction of expenses that were temporarily reduced in Fiscal 2021.

[0001571996-21-000063:mdna:182]
[same as prior period, unchanged from 0001571996-21-000040:mdna:205]

[0001571996-21-000063:mdna:183]
[same as prior period, unchanged from 0001571996-21-000040:mdna:177]

[0001571996-21-000063:mdna:184]
[same as prior period, unchanged from 0001571996-21-000040:mdna:178]

[0001571996-21-000063:mdna:185]
We sell products and services directly to customers and through a variety of sales channels, including retail distribution.  Our accounts receivable, net, was $14.2 billion and $12.8 billion as of October 29, 2021 and January 29, 2021, respectively.  We maintain an allowance for expected credit losses to cover receivables that may be deemed uncollectible.  The allowance for expected credit losses is an estimate based on an analysis of historical loss experience, current receivables aging, management’s assessment of current conditions and reasonable and supportable expectation of future conditions, and specific identifiable customer accounts that are deemed at risk.  Given this uncertainty, our allowance for expected credit losses in future periods may vary from our current estimates.  As of October 29, 2021 and January 29, 2021, the allowance for expected credit losses was $100 million and $104 million, respectively.  Based on our assessment, we believe that we are adequately reserved for expected credit losses.  We will continue to monitor the aging of our accounts receivable and take actions, where necessary, to reduce our exposure to credit losses.

[0001571996-21-000063:mdna:186]
[same as prior period, unchanged from 0001571996-21-000040:mdna:180]

[0001571996-21-000063:mdna:187]
DFS supports Dell Technologies by offering and arranging various financing options and services for our customers globally, including through captive financing operations in North America, Europe, Australia, and New Zealand.  DFS originates, collects, and services customer receivables primarily related to the purchase of our product, software, and service solutions.  DFS further strengthens our customer relationships through its flexible consumption models, provided through APEX, which enable us to offer our customers the option to pay over time and, in certain cases, based on utilization, to provide them with financial flexibility to meet their changing technological requirements.  New financing originations were $2.0 billion and $2.1 billion for the third quarter of Fiscal 2022 and Fiscal 2021, respectively, and $5.8 billion and $6.5 billion for the first nine months of Fiscal 2022 and Fiscal 2021, respectively.  We experienced a decline in new financing originations during Fiscal 2022 as more customers leveraged financing during Fiscal 2021 in the early stages of the COVID-19 pandemic.

[0001571996-21-000063:mdna:188]
[same as prior period, unchanged from 0001571996-21-000040:mdna:182]

[0001571996-21-000063:mdna:189]
As of October 29, 2021 and January 29, 2021, our financing receivables, net were $10.2 billion and $10.5 billion, respectively.  We maintain an allowance to cover expected financing receivable credit losses and evaluate credit loss expectations based on our total portfolio.  Our allowance for expected credit losses in future periods may vary from our current estimates.  For the third quarter of Fiscal 2022 and Fiscal 2021, the principal charge-off rate for our financing receivables portfolio was 1.1% and 0.7%, respectively.  For the first nine months of Fiscal 2022 and Fiscal 2021, the principal charge-off rate for our total portfolio was 0.7% and 0.9%, respectively.  The credit quality of our financing receivables has improved in recent years due to an overall improvement in the credit environment and as the mix of high-quality commercial accounts in our portfolio has continued to increase.  We continue to monitor broader economic indicators and their potential impact on future loss performance.  We have an extensive process to manage our exposure to customer credit risk, including active management of credit lines and our collection activities.  We also sell selected fixed-term financing receivables without recourse to unrelated third parties on a periodic basis, primarily to manage certain concentrations of customer credit exposure.  Based on our assessment of the customer financing receivables, we believe that we are adequately reserved.

[0001571996-21-000063:mdna:190]
We retain a residual interest in equipment leased under our fixed-term lease programs.  As of October 29, 2021 and January 29, 2021, the residual interest recorded as part of financing receivables was $265 million and $424 million, respectively.  The amount of the residual interest is established at the inception of the lease based upon estimates of the value of the equipment at the end of the lease term using historical studies, industry data, and future value-at-risk demand valuation methods.  We assess the carrying amount of our recorded residual values for expected losses.  Generally, expected losses as a result of residual value risk on equipment under lease are not considered to be significant primarily because of the existence of a secondary market with respect to the equipment.  The lease agreement also clearly defines applicable return conditions and remedies for non-compliance to ensure that the leased equipment will be in good operating condition upon return.  Model changes and updates, as well as market strength and product acceptance, are monitored, and adjustments are made to residual values in accordance with the significance of any such changes.  To mitigate our exposure, we work closely with customers and dealers to manage the sale of returned assets.  No material expected losses were recorded related to residual assets during the third quarter and first nine months of Fiscal 2022 and Fiscal 2021.

[0001571996-21-000063:mdna:191]
As of October 29, 2021 and January 29, 2021, equipment under operating leases, net was $1.6 billion and $1.3 billion, respectively.  Based on triggering events, we assess the carrying amount of the equipment under operating leases recorded for impairment.  No material impairment losses were recorded related to such equipment during the third quarter and first nine months of Fiscal 2022 and Fiscal 2021.

[0001571996-21-000063:mdna:192]
[same as prior period, unchanged from 0001571996-21-000040:mdna:186]

[0001571996-21-000063:mdna:193]
[same as prior period, unchanged from 0001571996-21-000040:mdna:187]

[0001571996-21-000063:mdna:194]
[same as prior period, unchanged from 0001571996-21-000040:mdna:188]

[0001571996-21-000063:mdna:195]
As of October 29, 2021, we had no off-balance sheet arrangements that have or are reasonably likely to have a current or future material effect on our financial condition or results of operations.

[0001571996-21-000063:mdna:196]
[same as prior period, unchanged from 0001571996-21-000040:mdna:190]

[0001571996-21-000063:mdna:197]
[same as prior period, unchanged from 0001571996-21-000040:mdna:191]

[0001571996-21-000063:mdna:198]
[same as prior period, unchanged from 0001571996-21-000040:mdna:192]

[0001571996-21-000063:mdna:199]
[same as prior period, unchanged from 0001571996-21-000040:mdna:193]

[0001571996-21-000063:mdna:200]
[same as prior period, unchanged from 0001571996-21-000040:mdna:194]

[0001571996-21-000063:mdna:201]
[same as prior period, unchanged from 0001571996-21-000040:mdna:195]

[0001571996-21-000063:mdna:202]
[same as prior period, unchanged from 0001571996-21-000040:mdna:196]

[0001571996-21-000063:mdna:203]
[same as prior period, unchanged from 0001571996-21-000040:mdna:197]

[0001571996-21-000063:mdna:204]
[same as prior period, unchanged from 0001571996-21-000040:mdna:198]

[0001571996-21-000063:mdna:205]
[same as prior period, unchanged from 0001571996-21-000040:mdna:199]

[0001571996-21-000063:mdna:206]
|  | October 29, 2021 |  | January 29, 2021 |
|  | (in millions) |
| Cash and cash equivalents, and available borrowings: |  |  |  |
| Cash and cash equivalents (a) | $ | 22,406 |  |  | $ | 14,201 |  |
| Remaining available borrowings under revolving credit facilities (b) | 5,969 |  |  | 5,467 |  |
| Total cash, cash equivalents, and available borrowings | $ | 28,375 |  |  | $ | 19,668 |  |

[0001571996-21-000063:mdna:207]
[same as prior period, unchanged from 0001571996-21-000040:mdna:201]

[0001571996-21-000063:mdna:208]
(a)    Of the $22.4 billion of cash and cash equivalents as of October 29, 2021, $12.5 billion was held by VMware, Inc.

[0001571996-21-000063:mdna:209]
(b)    Of the $6.0 billion of remaining available borrowings under revolving credit facilities, $1.5 billion was attributable to the VMware Revolving Credit Facility.

[0001571996-21-000063:mdna:210]
Our revolving credit facilities as of October 29, 2021 consist of the Revolving Credit Facility and the VMware Revolving Credit Facility.  The Revolving Credit Facility has a maximum aggregate borrowing capacity of $4.5 billion, and available borrowings under this facility are reduced by draws on the facility and outstanding letters of credit.  As of October 29, 2021, there were no borrowings outstanding under the facility.  Borrowings under the Revolving Credit Facility are used for general corporate purposes on a short-term basis.

[0001571996-21-000063:mdna:211]
On November 1, 2021, we entered into a new senior secured Revolving Credit Facility (the “2021 Revolving Credit Facility”) to replace the old senior secured Revolving Credit Facility under the Existing Credit Agreement.  The 2021 Revolving Credit Facility, which matures on November 1, 2026, provides us with revolving commitments in an aggregate principal amount of $5.0 billion for general corporate purposes and includes a letter of credit sub-facility of up to $500 million and a swing-line loan sub-facility of up to $500 million.  See Note 18 of the Notes to the Condensed Consolidated Financial Statements included in this report for more information.

[0001571996-21-000063:mdna:212]
The VMware Revolving Credit Facility has a maximum capacity of $1.5 billion.  As of October 29, 2021, there were no outstanding borrowings under the facility.  None of the net proceeds of borrowings under the VMware Revolving Credit Facility will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.

[0001571996-21-000063:mdna:213]
[same as prior period, unchanged from 0001571996-21-000040:mdna:207]

[0001571996-21-000063:mdna:214]
We believe that our current cash and cash equivalents, together with cash that will be provided by future operations and borrowings expected to be available under our revolving credit facilities, will be sufficient over at least the next twelve months and for the foreseeable future thereafter to fund our operations, debt service requirements and maturities, capital expenditures, share repurchases, dividend payments, and other corporate needs.

[0001571996-21-000063:mdna:215]
[same as prior period, unchanged from 0001571996-21-000040:mdna:209]

[0001571996-21-000063:mdna:216]
[same as prior period, unchanged from 0001571996-21-000040:mdna:210]

[0001571996-21-000063:mdna:217]
|  | October 29, 2021 |  | Increase (decrease) |  | January 29, 2021 |
|  | (in millions) |
| Core debt |  |  |  |  |  |
| Senior Secured Credit Facilities and First Lien Notes | $ | 24,754 |  |  | $ | (23) |  |  | $ | 24,777 |  |
| Unsecured Notes and Debentures | 952 |  |  | (400) |  |  | 1,352 |  |
| Senior Notes | 1,625 |  |  | (1,075) |  |  | 2,700 |  |
| EMC Notes | — |  |  | (1,000) |  |  | 1,000 |  |
| DFS allocated debt | (366) |  |  | 300 |  |  | (666) |  |
| Total core debt | 26,965 |  |  | (2,198) |  |  | 29,163 |  |
| DFS related debt |  |  |  |  |  |
| DFS debt | 9,977 |  |  | 311 |  |  | 9,666 |  |
| DFS allocated debt | 366 |  |  | (300) |  |  | 666 |  |
| Total DFS related debt | 10,343 |  |  | 11 |  |  | 10,332 |  |
| Margin Loan Facility and other | 400 |  |  | (3,835) |  |  | 4,235 |  |
| Debt of public subsidiary |  |  |  |  |  |
| VMware Notes | 10,750 |  |  | 6,000 |  |  | 4,750 |  |
| Total public subsidiary debt | 10,750 |  |  | 6,000 |  |  | 4,750 |  |
| Total debt, principal amount | 48,458 |  |  | (22) |  |  | 48,480 |  |
| Carrying value adjustments | (479) |  |  | 17 |  |  | (496) |  |
| Total debt, carrying value | $ | 47,979 |  |  | $ | (5) |  |  | $ | 47,984 |  |

[0001571996-21-000063:mdna:218]
During the first nine months of Fiscal 2022, the outstanding principal amount of our debt remained relatively flat, primarily as a result of principal repayments of $6.5 billion offset by the issuance of $6.0 billion of VMware Notes and $0.4 billion of net DFS debt activity.

[0001571996-21-000063:mdna:219]
We define core debt as the total principal amount of our debt, less DFS related debt, our Margin Loan Facility and other debt, and public subsidiary debt.  Our core debt was $27.0 billion as of October 29, 2021.  During the first nine months of Fiscal 2022, the decrease in our core debt was driven by principal repayments, including $1.1 billion principal amount of our 5.875% Senior Notes due June 2021, $1.0 billion principal amount of our 3.375% EMC Notes due June 2023, and $0.4 billion principal amount of our 4.625% Unsecured Notes due April 2021.

[0001571996-21-000063:mdna:220]
In connection with the VMware Spin-off executed on November 1, 2021, VMware, Inc. paid a cash dividend, pro rata, to each of the holders of VMware, Inc. common stock in an aggregate amount equal to $11.5 billion, of which Dell Technologies received $9.3 billion.  Subsequent to October 29, 2021 and the completion of the transaction, the Company utilized the net proceeds from its pro rata share, as well as cash on hand, to repay $9.4 billion in outstanding principal amount of core debt.  Further, in connection with the termination of the Existing Credit Agreement, which governed the Senior Secured Credit Facilities, the tangible and intangible assets that secured the First Lien Notes were released as collateral and, as such, our remaining core debt became unsecured.  Additionally, on November 19, 2021, the Company issued a partial redemption notice of $1.25 billion principal amount of the 5.45% First Lien Notes due June 2023 with the repayment expected to occur on December 6, 2021.

[0001571996-21-000063:mdna:221]
See Note 18 of the Notes to the Condensed Consolidated Financial Statements included in this report for more information about VMware Spin-off and debt-related activity subsequent to October 29, 2021.

[0001571996-21-000063:mdna:222]
As of October 29, 2021, our Margin Loan Facility and other debt was $0.4 billion and consisted only of other debt.  During the first nine months of Fiscal 2022, we fully repaid the Margin Loan Facility in the principal amount of $4.0 billion.

[0001571996-21-000063:mdna:223]
[same as prior period, unchanged from 0001571996-21-000040:mdna:216]

[0001571996-21-000063:mdna:224]
[same as prior period, unchanged from 0001571996-21-000040:mdna:217]

[0001571996-21-000063:mdna:225]
Public subsidiary debt represents VMware, Inc. indebtedness.  VMware, Inc. and its respective subsidiaries are unrestricted subsidiaries for purposes of the core debt of Dell Technologies.  Neither Dell Technologies nor any of its subsidiaries, other than VMware, Inc., is obligated to make payment on the VMware Notes.  None of the net proceeds of the VMware Notes will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and its subsidiaries.

[0001571996-21-000063:mdna:226]
See Note 5 of the Notes to the Condensed Consolidated Financial Statements included in this report for more information about our debt and VMware, Inc. debt.

[0001571996-21-000063:mdna:227]
We have made steady progress in paying down debt and we will continue to include deleveraging as an important component of our overall strategy.  We have achieved an investment grade corporate family rating from three major credit rating agencies, with the final upgrade occurring subsequent to October 29, 2021.

[0001571996-21-000063:mdna:228]
We believe we will continue to be able to make our debt principal and interest payments, including the short-term maturities, from existing and expected sources of cash, primarily from operating cash flows.  Cash used for debt principal and interest payments may also include short-term borrowings under our revolving credit facilities.  Under our variable-rate debt, we could experience variations in our future interest expense from potential fluctuations in applicable reference rates, or from possible fluctuations in the level of DFS debt required to meet future demand for customer financing.  We or our affiliates or their related persons, at our or their sole discretion and without public announcement, may purchase, redeem, prepay, refinance, or otherwise retire any amount of our outstanding indebtedness under the terms of such indebtedness at any time and from time to time, in open market or negotiated transactions with the holders of such indebtedness or otherwise, as appropriate market conditions exist.

[0001571996-21-000063:mdna:229]
[same as prior period, unchanged from 0001571996-21-000040:mdna:221]

[0001571996-21-000063:mdna:230]
[same as prior period, unchanged from 0001571996-21-000040:mdna:222]

[0001571996-21-000063:mdna:231]
|  | Nine Months Ended |
|  | October 29, 2021 |  | October 30, 2020 |
|  | (in millions) |
| Net change in cash from: |  |  |  |
| Operating activities | $ | 7,214 |  |  | $ | 5,530 |  |
| Investing activities | 2,053 |  |  | 26 |  |
| Financing activities | (1,028) |  |  | (3,483) |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash | (54) |  |  | (67) |  |
| Change in cash, cash equivalents, and restricted cash | $ | 8,185 |  |  | $ | 2,006 |  |

[0001571996-21-000063:mdna:232]
Operating Activities — Cash provided by operating activities was $7.2 billion for the first nine months of Fiscal 2022 compared to cash provided by operating activities of $5.5 billion for the first nine months of Fiscal 2021.  The increase in operating cash flows during the first nine months of Fiscal 2022 was primarily driven by strong growth.  Additionally, working capital dynamics were favorable for the period primarily due to timing of purchases and payments to vendors, partially offset by higher end of quarter shipments and increased inventory as we continue to navigate the current supply chain environment.  In comparison, during the first nine months of Fiscal 2021 we experienced unfavorable working capital impacts.

[0001571996-21-000063:mdna:233]
DFS offerings are initially funded through cash on hand at the time of origination, most of which is subsequently replaced with third-party financing.  For DFS offerings which qualify as sales-type leases, the initial funding of financing receivables is reflected as an impact to cash flows from operations, and is largely subsequently offset by cash proceeds from financing activities.  For DFS operating leases, which have increased under the current leasing standard, the initial funding is classified as a capital expenditure and reflected as cash flows used in investing activities.  DFS new financing originations were $5.8 billion  and $6.5 billion during the first nine months of Fiscal 2022 and Fiscal 2021, respectively.  As of October 29, 2021, DFS had $10.2 billion of financing receivables, net and $1.6 billion of equipment under operating leases, net.

[0001571996-21-000063:mdna:234]
Investing Activities — Investing activities primarily consist of cash used to fund capital expenditures for property, plant, and equipment, which includes equipment under operating leases, as well as capitalized software development costs, acquisitions and divestitures, strategic investments, and the maturities, sales, and purchases of investments.  During the first nine months of Fiscal 2022, cash provided by investing activities was $2.1 billion and was primarily driven by net cash proceeds related to the divestiture of Boomi, partially offset by capital expenditures and capitalized software development costs.  In comparison, cash provided by investing activities was $26 million during the first nine months of Fiscal 2021, which was primarily attributable to net cash proceeds from the divestiture of RSA Security during the the third quarter of Fiscal 2021, largely offset by capital expenditures and acquisitions of businesses.

[0001571996-21-000063:mdna:235]
Financing Activities — Financing activities primarily consist of the proceeds and repayments of debt, cash used to repurchase common stock, and proceeds from the issuance of common stock.  Cash used in financing activities was $1.0 billion during the first nine months of Fiscal 2022 and primarily consisted of debt repayments and repurchases of common stock by our public subsidiaries, partially offset by net cash proceeds from the issuance of VMware Notes and DFS debt.  In comparison, cash used in financing activities of $3.5 billion during the first nine months of Fiscal 2021 primarily consisted of debt repayments and repurchases of common stock by our public subsidiaries, partially offset by cash proceeds from the issuances of multiple series of First Lien Notes and VMware Notes.

[0001571996-21-000063:mdna:236]
[same as prior period, unchanged from 0001571996-21-000040:mdna:228]

[0001571996-21-000063:mdna:237]
Capital Expenditures — During the first nine months of Fiscal 2022 and Fiscal 2021, we spent $2.1 billion and $1.6 billion, respectively, on property, plant, and equipment and capitalized software development costs.  Product demand, product mix, and the use of contract manufacturers, as well as ongoing investments in operating and IT infrastructure and software development, influence the level and prioritization of our capital expenditures.  Aggregate capital expenditures for Fiscal 2022 are currently expected to total $2.9 billion, of which approximately $1.0 billion is expected to be expended for equipment under operating leases and approximately $0.3 billion for capitalized software development costs.

[0001571996-21-000063:mdna:238]
Repurchases of Common Stock —Effective as of September 23, 2021, our board of directors approved a stock repurchase program (the “2021 Stock Repurchase Program”) under which we are authorized to use assets to repurchase up to $5 billion of shares of our Class C Common Stock with no established expiration date.  As of October 29, 2021, the cumulative authorized amount remaining for stock repurchases was $5 billion.  Subsequent to the third quarter of Fiscal 2022 through November 30, 2021, we repurchased approximately 3.1 million shares for approximately $173 million.

[0001571996-21-000063:mdna:239]
[same as prior period, unchanged from 0001571996-21-000040:mdna:231]

[0001571996-21-000063:mdna:240]
[same as prior period, unchanged from 0001571996-21-000040:mdna:232]

[0001571996-21-000063:mdna:241]
As of October 29, 2021, purchase obligations were $5.2 billion, $0.7 billion, and $0.8 billion for the remaining three months of Fiscal 2022, and for Fiscal 2023 and Fiscal 2024 and thereafter, respectively.

[0001571996-21-000063:mdna:242]
[same as prior period, unchanged from 0001571996-21-000040:mdna:257]

[0001571996-21-000063:mdna:243]
[same as prior period, unchanged from 0001571996-21-000040:mdna:235]

[0001571996-21-000063:mdna:244]
As discussed in Note 5 of the Notes to the Condensed Consolidated Financial Statements included in this report, Dell International L.L.C. and EMC Corporation (the “Issuers”), both of which are wholly-owned subsidiaries of Dell Technologies, completed private offerings of multiple series of senior secured notes issued on June 1, 2016, March 20, 2019, and April 9, 2020 (collectively, the “First Lien Notes”).  On May 17, 2021, the Issuers launched an exchange offer of the outstanding First Lien Notes for registered senior secured notes with substantially similar terms (the “Exchange Notes”).  In June 2021, the Issuers completed the exchange offer and issued an aggregate of $18.4 billion principal amount of Exchange Notes in exchange for the same principal amount of First Lien Notes.  As of October 29, 2021, the aggregate principal amount of unregistered First Lien Notes remaining outstanding following the settlement of the exchange offer was approximately $0.1 billion.

[0001571996-21-000063:mdna:245]
Guarantees — The Exchange Notes are guaranteed on a joint and several unsecured basis by Dell Technologies and on a joint and several secured basis by Denali Intermediate, Inc. (“Denali Intermediate”), Dell and each of Denali Intermediate’s wholly-owned domestic subsidiaries that guarantees the Issuers’ Senior Credit Facility obligations (collectively, the “Guarantors”).  Not all of Denali Intermediate’s subsidiaries guarantee the Exchange Notes, including none of Denali Intermediate’s non-wholly-owned subsidiaries, foreign subsidiaries, receivables subsidiaries and subsidiaries designated as unrestricted subsidiaries under the  Senior Credit Facility (such non-guarantor subsidiaries, collectively, the “Non-Guarantor Subsidiaries”).  SecureWorks Corp., Virtustream, Inc., VMware, Inc., EMC Equity Assets LLC and VMW Holdco L.L.C. (collectively, the “Unrestricted Subsidiaries”) have been designated as unrestricted subsidiaries under the Senior Credit Facility and therefore do not guarantee the Exchange Notes or the Senior Credit Facility obligations.  See Exhibit 22.1 filed with this report for a list of subsidiary guarantors and issuers of guaranteed securities.

[0001571996-21-000063:mdna:246]
The guarantees are full and unconditional, subject to certain customary release provisions.  The indentures that govern the Exchange Notes provide that guarantees by subsidiaries of Denali Intermediate may be released in the event, among other things, (1) such Guarantor is sold or sells all of its assets in compliance with the applicable provisions of the indentures; (2) such Guarantor is released from its guaranty under the Senior Credit Facility, including the declaration of such subsidiary as “unrestricted” under the Senior Credit Facility; (3) the merger, amalgamation or consolidation, or liquidation, of such Guarantor; or (4) the achievement of investment grade ratings with respect to the Issuers and the Exchange Notes.  In addition, all Guarantors will be released from their guarantees if the requirements for legal defeasance or covenant defeasance or to discharge the indentures have been satisfied.

[0001571996-21-000063:mdna:247]
[same as prior period, unchanged from 0001571996-21-000040:mdna:239]

[0001571996-21-000063:mdna:248]
[same as prior period, unchanged from 0001571996-21-000040:mdna:240]

[0001571996-21-000063:mdna:249]
|  | Nine Months Ended |
|  | October 29, 2021 |
|  | (in millions) |
| Net revenue (a) | $ | 18,608 |  |
| Gross margin (b) | $ | 6,492 |  |
| Operating loss (c) | $ | (687) |  |
| Interest and other, net | 2,936 |  |
| Income before income taxes | $ | 2,249 |  |
| Net income attributable to Obligor Group | $ | 1,801 |  |

[0001571996-21-000063:mdna:250]
[same as prior period, unchanged from 0001571996-21-000040:mdna:242]

[0001571996-21-000063:mdna:251]
(a)  Includes net revenue from services provided and product sales to Non-Guarantor Subsidiaries of $2,069 million and $122 million, respectively.

[0001571996-21-000063:mdna:252]
(b)  Includes cost of net revenue from resale of solutions purchased from Non-Guarantor Subsidiaries of $1,837 million.

[0001571996-21-000063:mdna:253]
(c)  Includes operating expenses from shared services provided by Non-Guarantor Subsidiaries of $59 million.

[0001571996-21-000063:mdna:254]
[same as prior period, unchanged from 0001571996-21-000040:mdna:246]

[0001571996-21-000063:mdna:255]
|  | October 29, 2021 |  | January 29, 2021 (a) |
|  | (in millions) |
| ASSETS |
| Current assets | $ | 16,429 |  |  | $ | 12,160 |  |
| Short-term intercompany loan receivables | 2,379 |  |  | — |
| Total current assets | 18,808 |  |  | 12,160 |
| Goodwill and intangible assets | 15,592 |  |  | 16,229 |  |
| Other non-current assets | 6,910 |  |  | 6,185 |  |
| Long-term intercompany loan receivables | 2,236 |  |  | 4,714 |  |
| Total assets | $ | 43,546 |  |  | $ | 39,288 |  |
| LIABILITIES |
| Current liabilities | $ | 26,552 |  |  | $ | 15,761 |  |
| Intercompany payables | 5,574 |  |  | 5,527 |  |
| Total current liabilities | 32,126 |  |  | 21,288 |  |
| Long-term debt | 17,749 |  |  | 27,951 |  |
| Other non-current liabilities | 9,248 |  |  | 7,549 |  |
| Total liabilities | $ | 59,123 |  |  | $ | 56,788 |  |

[0001571996-21-000063:mdna:256]
____________________

[0001571996-21-000063:mdna:257]
(a) During the three months ended October 29, 2021, two Non-Guarantor Subsidiaries transferred their respective businesses to the Guarantors.  Prior period balances have been reclassified to conform to current period presentation.

[0001571996-21-000063:mdna:258]
[same as prior period, unchanged from 0001571996-21-000040:mdna:248]

[0001571996-21-000063:mdna:259]
[same as prior period, unchanged from 0001571996-21-000040:mdna:249]

[0001571996-21-000063:mdna:260]
[same as prior period, unchanged from 0001571996-21-000040:mdna:250]

[0001571996-21-000063:mdna:261]
•100% of the equity interests of the Issuers, Dell and each Material Subsidiary (as defined in the applicable indenture) that is a wholly-owned subsidiary of the Issuers and the Guarantors (which pledge, in the case of capital stock of any Foreign Subsidiary or FSHCO (each as defined in the applicable indenture), is limited to 65% of the voting capital stock and 100% of the non-voting capital stock of such Foreign Subsidiary or FSHCO); and

[0001571996-21-000063:mdna:262]
[same as prior period, unchanged from 0001571996-21-000040:mdna:252]

[0001571996-21-000063:mdna:263]
See Exhibit 22.1 filed with this report for a list of each affiliate of Dell Technologies whose security is pledged as collateral to secure the Exchange Notes.  There is no trading market for the applicable affiliates’ securities pledged as collateral.

[0001571996-21-000063:mdna:264]
Delivery of the Collateral securing the Exchange Notes would be required in certain customary events of default, including failure to make required payments, failure to comply with covenants, and the occurrence of certain events of bankruptcy and insolvency.

[0001571996-21-000063:mdna:265]
The Collateral may be released in certain circumstances, including, (1) to enable the sale, transfer or other disposition of such property or assets, (2) upon the release of the guarantee of a Guarantor, (3) upon such property or asset becoming an “excluded asset” as defined in the indentures governing the Exchange Notes, (4) upon the achievement of investment grade ratings with respect to the Issuers and the Exchange Notes, and (5) to the extent the liens on the Collateral securing the Senior Credit Facility obligations are released (other than in connection with the payment in full of the Senior Credit Facility).

[0001571996-21-000063:mdna:266]
The Collateral does not include, and will not include, among other things, (1) a pledge of the assets or equity interests of certain subsidiaries, including the Unrestricted Subsidiaries and their respective subsidiaries, (2) any fee-owned real property with a book value of less than $150 million, (3) any commercial tort claims or letter of credit rights with an individual value of less than $50 million, (4) any “principal property” as defined in the indentures governing the Unsecured Notes and Debentures of Dell and the EMC Notes, and capital stock of any subsidiary holding “principal property” as defined in the indenture governing the Unsecured Notes and Debentures of Dell, or (5) certain excluded assets.

[0001571996-21-000063:mdna:267]
93
