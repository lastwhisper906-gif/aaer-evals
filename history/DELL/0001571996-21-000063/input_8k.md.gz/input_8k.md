# DELL 8-K — 0001571996-21-000060 filed 2021-11-23

## item codes, every 8-K on or before 2021-12-03

- 2021-11-23 0001571996-21-000060 — 2.02, 9.01
- 2021-11-05 0001571996-21-000057 — 1.02, 2.01, 7.01, 8.01, 9.01 — amendment, the index does not say of what
- 2021-11-01 0001571996-21-000052 — 8.01, 9.01
- 2021-11-01 0001193125-21-315488 — 1.01, 1.02, 2.01, 8.01, 9.01
- 2021-10-21 0001193125-21-304052 — 8.01, 9.01
- 2021-10-19 0001571996-21-000050 — 8.01, 9.01
- 2021-10-07 0001193125-21-294210 — 8.01, 9.01
- 2021-09-30 0001571996-21-000047 — 5.02
- 2021-09-27 0001571996-21-000045 — 8.01
- 2021-09-23 0001193125-21-280190 — 7.01, 8.01, 9.01
- 2021-09-20 0001193125-21-276810 — 7.01, 9.01
- 2021-08-26 0001571996-21-000037 — 2.02, 9.01
- 2021-07-01 0001571996-21-000034 — 3.02
- 2021-06-24 0001571996-21-000031 — 5.07
- 2021-06-24 0001193125-21-197644 — 7.01, 9.01
- 2021-06-16 0001571996-21-000029 — 5.02
- 2021-05-27 0001571996-21-000019 — 2.02, 9.01
- 2021-05-03 0001571996-21-000010 — 8.01, 9.01
- 2021-04-14 0001193125-21-116271 — 1.01, 7.01, 9.01
- 2021-02-25 0001571996-21-000003 — 2.02, 9.01
- 2021-02-18 0001193125-21-047844 — 1.01, 2.03, 9.01
- 2020-11-24 0001571996-20-000048 — 2.02, 9.01
- 2020-08-27 0001571996-20-000041 — 2.02, 9.01
- 2020-07-02 0001571996-20-000037 — 5.07
- 2020-05-28 0001571996-20-000028 — 2.02, 9.01
- 2020-04-09 0001193125-20-102602 — 1.01, 2.03, 9.01
- 2020-04-08 0001571996-20-000021 — 5.02
- 2020-04-03 0001571996-20-000019 — 8.01, 9.01
- 2020-03-26 0001571996-20-000015 — 7.01
- 2020-02-27 0001571996-20-000009 — 2.02, 8.01, 9.01
- 2020-02-18 0001571996-20-000005 — 8.01, 9.01
- 2020-01-09 0001571996-20-000002 — 3.02
- 2020-01-06 0001193125-20-002200 — 3.02
- 2019-12-13 0001193125-19-313947 — 3.02
- 2019-12-10 0001571996-19-000052 — 5.02
- 2019-12-02 0001571996-19-000044 — 5.02, 7.01, 9.01
- 2019-11-26 0001571996-19-000042 — 2.02, 9.01
- 2019-09-23 0001193125-19-252192 — 1.01, 2.03, 9.01
- 2019-08-29 0001571996-19-000036 — 2.02, 9.01
- 2019-08-22 0001193125-19-226939 — 7.01, 8.01, 9.01
- 2019-07-11 0001571996-19-000032 — 5.02, 5.07, 9.01
- 2019-07-03 0001571996-19-000030 — 3.02
- 2019-06-27 0001571996-19-000028 — 3.02
- 2019-05-30 0001571996-19-000021 — 2.02, 9.01
- 2019-04-02 0001571996-19-000010 — 5.02
- 2019-03-21 0001193125-19-082281 — 1.01, 1.02, 2.03, 9.01
- 2019-03-19 0001571996-19-000005 — 5.02, 9.01
- 2019-03-14 0001193125-19-074935 — 1.01, 2.03, 9.01
- 2019-03-07 0001193125-19-066045 — 8.01, 9.01
- 2019-02-28 0001571996-19-000002 — 2.02, 9.01
- 2018-12-28 0001193125-18-360943 — 1.01, 1.02, 3.01, 3.03, 5.02, 5.03, 7.01, 8.01, 9.01
- 2018-12-21 0001193125-18-356324 — 1.01, 2.03, 9.01
- 2018-12-14 0001193125-18-349469 — 8.01
- 2018-12-11 0001193125-18-346958 — 5.07, 8.01, 9.01
- 2018-11-29 0001571996-18-000041 — 2.02, 9.01
- 2018-11-28 0001571996-18-000037 — 7.01, 8.01, 9.01
- 2018-11-26 0001193125-18-333967 — 8.01, 9.01
- 2018-11-15 0001193125-18-328110 — 1.01, 9.01 — amendment of 0001193125-18-327222
- 2018-11-15 0001193125-18-327222 — 1.01, 7.01, 9.01
- 2018-10-03 0001193125-18-291390 — 8.01
- 2018-09-06 0001571996-18-000029 — 2.02, 9.01
- 2018-08-06 0001571996-18-000027 — 8.01, 9.01
- 2018-07-02 0001193125-18-210339 — 1.01, 7.01, 9.01
- 2018-06-28 0001571996-18-000024 — 5.07
- 2018-06-04 0001571996-18-000019 — 2.02, 9.01
- 2018-05-17 0001571996-18-000016 — 7.01
- 2018-04-26 0001571996-18-000009 — 7.01, 9.01
- 2018-03-08 0001193125-18-074168 — 2.02, 9.01
- 2018-02-02 0001193125-18-029947 — 7.01, 9.01
- 2017-12-07 0001571996-17-000042 — 2.02, 9.01
- 2017-10-24 0001571996-17-000037 — 1.01, 2.03, 9.01
- 2017-09-15 0001571996-17-000027 — 5.02
- 2017-09-07 0001571996-17-000017 — 2.02, 9.01
- 2017-08-24 0001571996-17-000014 — 8.01
- 2017-06-29 0001571996-17-000011 — 3.03, 5.07, 8.01, 9.01
- 2017-06-08 0001193125-17-197638 — 2.02, 9.01
- 2017-03-30 0001193125-17-102794 — 8.01
- 2017-03-30 0001193125-17-102777 — 2.02, 9.01
- 2017-03-09 0001193125-17-076981 — 1.01, 2.03, 9.01
- 2017-01-17 0001193125-17-011125 — 8.01
- 2016-12-15 0001193125-16-793722 — 8.01
- 2016-12-08 0001193125-16-787976 — 2.02, 9.01
- 2016-11-10 0001193125-16-765964 — 1.02, 8.01
- 2016-11-04 0001193125-16-760249 — 8.01
- 2016-09-13 0001193125-16-708600 — 3.02
- 2016-09-09 0001193125-16-706567 — 1.01, 1.02, 2.01, 2.03, 3.02, 3.03, 5.02, 9.01
- 2016-09-07 0001193125-16-703370 — 3.03, 5.07, 7.01, 8.01, 9.01
- 2016-09-06 0001193125-16-702057 — 2.02, 9.01
- 2016-08-31 0001193125-16-697268 — 8.01, 9.01
- 2016-08-26 0001193125-16-692921 — 8.01, 9.01
- 2016-07-11 0001193125-16-645610 — 8.01
- 2016-07-05 0001193125-16-641679 — 8.01
- 2016-06-22 0001193125-16-629055 — 1.01, 2.03, 8.01, 9.01
- 2016-06-21 0001193125-16-627071 — 8.01, 9.01
- 2016-06-10 0001193125-16-618483 — 2.02, 9.01
- 2016-06-09 0001193125-16-617893 — 8.01, 9.01

## late-filing notifications on or before 2021-12-03

- none on or before 2021-12-03

## item 2.02 — earnings release, exhibit 99.1

[0001571996-21-000060:8k_2_02:1]
EX-99.1
2
exhibit991earnings8kq3fy22.htm
EX-99.1

[0001571996-21-000060:8k_2_02:2]
Document

[0001571996-21-000060:8k_2_02:3]
Exhibit 99.1

[0001571996-21-000060:8k_2_02:4]
Dell Technologies Delivers Record Third Quarter Fiscal 2022 Results

[0001571996-21-000060:8k_2_02:5]
News summary

[0001571996-21-000060:8k_2_02:6]
•Best third quarter in Dell Technologies history, driven by robust demand, durable competitive advantages and strong execution

[0001571996-21-000060:8k_2_02:7]
•Record third quarter revenue of $28.4 billion, up 21%

[0001571996-21-000060:8k_2_02:8]
•Third quarter diluted earnings per share of $4.87, non-GAAP diluted earnings per share of $2.37

[0001571996-21-000060:8k_2_02:9]
ROUND ROCK, Texas — November 23, 2021

[0001571996-21-000060:8k_2_02:10]
Full story

[0001571996-21-000060:8k_2_02:11]
Dell Technologies (NYSE: DELL) announces record financial results for its fiscal 2022 third quarter.  The company generated record revenue of $28.4 billion, up 21%, driven by growth in all business units, customer segments and geographies, as well as broad strength across commercial PCs, servers and storage. Operating income was a third quarter record of $1.3 billion, a 19% increase over the same period the prior year, and non-GAAP operating income was a third quarter record of $2.9 billion, up 5%. Net income was $3.9 billion, non-GAAP net income was $2.0 billion and adjusted EBITDA was $3.4 billion. Net cash from operating activities was $3.3 billion. Diluted earnings per share was $4.87, up 351% and non-GAAP diluted earnings per share was $2.37, up 17%.

[0001571996-21-000060:8k_2_02:12]
1

[0001571996-21-000060:8k_2_02:13]
Third Quarter Fiscal 2022 Financial Results

[0001571996-21-000060:8k_2_02:14]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | October 29, 2021 |  | October 30, 2020 |  | Change |  | October 29, 2021 |  | October 30, 2020 |  | Change |
|  | (in millions, except per share amounts and percentages; unaudited) |
| Total net revenue | $ | 28,394 |  |  | $ | 23,482 |  |  | 21% |  | $ | 79,003 |  |  | $ | 68,112 |  |  | 16% |
| Operating income | $ | 1,349 |  |  | $ | 1,129 |  |  | 19% |  | $ | 4,096 |  |  | $ | 2,967 |  |  | 38% |
| Net income | $ | 3,888 |  |  | $ | 881 |  |  | 341% |  | $ | 5,706 |  |  | $ | 2,162 |  |  | 164% |
| Earnings per share - diluted | $ | 4.87 |  |  | $ | 1.08 |  |  | 351% |  | $ | 7.08 |  |  | $ | 2.64 |  |  | 168% |
| Non-GAAP net revenue | $ | 28,405 |  |  | $ | 23,521 |  |  | 21% |  | $ | 79,037 |  |  | $ | 68,241 |  |  | 16% |
| Non-GAAP operating income | $ | 2,868 |  |  | $ | 2,725 |  |  | 5% |  | $ | 8,393 |  |  | $ | 7,504 |  |  | 12% |
| Non-GAAP net income | $ | 2,015 |  |  | $ | 1,711 |  |  | 18% |  | $ | 5,745 |  |  | $ | 4,475 |  |  | 28% |
| Adjusted EBITDA | $ | 3,410 |  |  | $ | 3,231 |  |  | 6% |  | $ | 9,976 |  |  | $ | 8,938 |  |  | 12% |
| Non-GAAP earnings per share - diluted | $ | 2.37 |  |  | $ | 2.03 |  |  | 17% |  | $ | 6.75 |  |  | $ | 5.28 |  |  | 28% |

[0001571996-21-000060:8k_2_02:15]
Information about Dell Technologies’ use of non-GAAP financial information is provided under “Non-GAAP Financial Measures” below.  All comparisons in this press release are year-over-year unless otherwise noted.

[0001571996-21-000060:8k_2_02:16]
Dell Technologies ended the quarter with remaining performance obligations of $47 billion, up 26%, deferred revenue of $31 billion, and cash and investments of $24.2 billion. The company has paid down a total of $15.9 billion of debt year-to-date and received an Investment Grade corporate family rating from all three of the major credit rating agencies.

[0001571996-21-000060:8k_2_02:17]
Operating Segments Summary

[0001571996-21-000060:8k_2_02:18]
Client Solutions Group revenue for the third quarter was up 35% to a record $16.5 billion. Operating income was a third quarter record of $1.1 billion, up 14%, and 6.9% of Client Solutions Group revenue.  Commercial revenue was a record $12.3 billion, up an unprecedented 40%, and consumer revenue was also a record $4.3 billion, up 21%.

[0001571996-21-000060:8k_2_02:19]
Key highlights:

[0001571996-21-000060:8k_2_02:20]
•Continued growth in high-value segments, including commercial PCs, high-end consumer and gaming – which will drive long-term profitable share gains.

[0001571996-21-000060:8k_2_02:21]
•Achieved highest year-over-year PC share gain in Dell’s history for calendar third quarter, with shipments up 26.6% and global PC share up 3.0 points to 17.4%.1

[0001571996-21-000060:8k_2_02:22]
•Announced new Latitude Rugged notebooks – including the industry’s smallest 5G-capable 13” fully-rugged laptop.

[0001571996-21-000060:8k_2_02:23]
•Timed to the 25th anniversary of Alienware – released the redesigned Alienware Aurora, the pinnacle of gaming desktop experiences. With a special focus on airflow and thermals, the open-air design provides better accessibility and improved performance – enriching the gaming experience in every possible way.

[0001571996-21-000060:8k_2_02:24]
2

[0001571996-21-000060:8k_2_02:25]
Infrastructure Solutions Group revenue for the third quarter was $8.4 billion, up 5% and the third consecutive quarter of positive year-over-year revenue growth, as customers accelerate IT investments. Storage revenue was $3.9 billion, up 1%.  Servers and networking revenue was $4.5 billion, up 9% for a fourth consecutive quarter of year-over-year growth.  Operating income was $892 million  or approximately 10.6% of Infrastructure Solutions Group revenue.  Customer investments in IT infrastructure and digital transformation will continue to drive strong demand for compute and storage and create future growth opportunities for new innovations in multi-cloud, telecom and 5G.

[0001571996-21-000060:8k_2_02:26]
Key highlights:

[0001571996-21-000060:8k_2_02:27]
•Introduced updates to the network-attached storage (NAS) portfolio, including new Dell EMC PowerScale systems and software enhancements, all focused on providing customers with the flexible and secure consumption and management of unstructured data.

[0001571996-21-000060:8k_2_02:28]
•Launched the industry’s first end-to-end NVMe/TCP solution, featuring SmartFabric Storage Software, which provides the intelligence for automated storage connectivity at scale.

[0001571996-21-000060:8k_2_02:29]
•Announced edge innovations across the portfolio to help organizations simplify deployments and capture more value from data generated and processed outside the traditional data center and public cloud.

[0001571996-21-000060:8k_2_02:30]
•Introduced new telecom software, solutions and services to help communications service providers (CSPs) accelerate their open, cloud-native network deployments and create new revenue opportunities at the edge.

[0001571996-21-000060:8k_2_02:31]
•Announced APEX Cloud Services with VMware Cloud, which gives organizations the ability to move workloads across multiple cloud environments and scale resources quickly with predictable pricing and transparent costs.

[0001571996-21-000060:8k_2_02:32]
VMware revenue was $3.2 billion for the third quarter, up 10% driven by broad-based strength across a diverse product portfolio. Operating income for the quarter was $837 million, or 26.3% of VMware revenue.

[0001571996-21-000060:8k_2_02:33]
Executive Quotes:

[0001571996-21-000060:8k_2_02:34]
•“We continue to deliver strong results, with more than $13 billion in cash flow from operations on a trailing-twelve-month basis,” said Tom Sweet, chief financial officer, Dell Technologies. “The digital trends are tailwinds for our business, and along with our strategy and financial flexibility, lead us to be optimistic about our long-term growth prospects.”

[0001571996-21-000060:8k_2_02:35]
•“Technology is more essential today than ever before and we are clearly winning in our core, keeping us at the center of customers' IT and digital agendas,” said Jeff Clarke, vice chairman and co-chief operating officer, Dell Technologies. “Our product, global operations and sales teams did an outstanding job this quarter as we shipped a record number of products and delivered record revenue of $28.4 billion.”

[0001571996-21-000060:8k_2_02:36]
•“We’re three quarters into what will prove to be a historic year for Dell, and we are just beginning to write the next chapter of the Dell Technologies story,” said Chuck Whitten, co-chief operating officer, Dell Technologies. “We are uniquely positioned in the data era, with durable advantages and market-leading positions. Our strategy is focused on growing our core business and in adjacent multi-billion-dollar markets including multi-cloud, edge, telecom and as-a-Service.”

[0001571996-21-000060:8k_2_02:37]
3

[0001571996-21-000060:8k_2_02:38]
Conference call information

[0001571996-21-000060:8k_2_02:39]
As previously announced, the Company will hold a conference call to discuss its third quarter performance today, Nov. 23, 2021 at 4:30 p.m. CST. The conference call will be broadcast live over the internet and can be accessed at

[0001571996-21-000060:8k_2_02:40]
https://investors.delltechnologies.com/events-and-presentations/upcoming-events

[0001571996-21-000060:8k_2_02:41]
For those unable to listen to the live broadcast, an archived version will be available at the same location for one year.

[0001571996-21-000060:8k_2_02:42]
Additional financial and operating information may be downloaded from

[0001571996-21-000060:8k_2_02:43]
https://investors.delltechnologies.com/financial-information/quarterly-results

[0001571996-21-000060:8k_2_02:44]
Read our quarterly blog from Bill Scannell, Dell Technologies president of Global Sales & Customer Operations, to learn more about how we are helping customers with their digital transformations:

[0001571996-21-000060:8k_2_02:45]
https://www.delltechnologies.com/en-us/blog/accelerating-customers-digital-journeys-every-step-of-the-way/

[0001571996-21-000060:8k_2_02:46]
About Dell Technologies

[0001571996-21-000060:8k_2_02:47]
Dell Technologies (NYSE:DELL) helps organizations and individuals build their digital future and transform how they work, live and play. The company provides customers with the industry’s broadest and most innovative technology and services portfolio for the data era.

[0001571996-21-000060:8k_2_02:48]
Contacts

[0001571996-21-000060:8k_2_02:49]
Investors: Investor_Relations@Dell.com

[0001571996-21-000060:8k_2_02:50]
Media: Media.Relations@Dell.com

[0001571996-21-000060:8k_2_02:51]
# # #

[0001571996-21-000060:8k_2_02:52]
Copyright © 2021 Dell Inc. or its subsidiaries. All Rights Reserved. Dell Technologies, Dell, EMC and Dell EMC are trademarks of Dell Inc. or its subsidiaries. Other trademarks may be trademarks of their respective owners.

[0001571996-21-000060:8k_2_02:53]
1. IDC WW Quarterly Personal Computing Device (PCD) Tracker CY21Q3.

[0001571996-21-000060:8k_2_02:54]
Non-GAAP Financial Measures:

[0001571996-21-000060:8k_2_02:55]
This press release presents information about Dell Technologies’ non-GAAP net revenue, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, non-GAAP net income attributable to non-controlling interests, non-GAAP net income attributable to Dell Technologies Inc. - basic, non-GAAP net income attributable to Dell Technologies Inc. - diluted, non-GAAP earnings per share attributable to Dell Technologies Inc. - basic, non-GAAP earnings per share attributable to Dell Technologies Inc. - diluted, EBITDA, and adjusted EBITDA, which are non-GAAP financial measures provided as a supplement to the results provided in accordance with generally accepted accounting principles in the United States of America (“GAAP”). A reconciliation of each non-GAAP financial measure to the most directly comparable GAAP financial measure is provided in the attached tables for each of the fiscal periods indicated.

[0001571996-21-000060:8k_2_02:56]
Special Note on Forward-Looking Statements:

[0001571996-21-000060:8k_2_02:57]
Dell Technologies’ results or events in future periods could differ materially from those expressed or implied by these forward-looking statements because of risks, uncertainties, and other factors that include, but are not limited to, the following: risks and uncertainties relating to our spin-off of VMware, Inc., including the potential effects on our business of the transaction; the effects of the COVID-19 pandemic; competitive pressures; Dell Technologies’ reliance on third-party suppliers for products and components, including reliance on single-source or limited-source suppliers; Dell Technologies’ ability to achieve favorable pricing from its vendors; adverse global economic conditions and instability in financial markets; Dell Technologies’ execution of its growth, business and acquisition strategies; the success of Dell Technologies’ cost efficiency measures; Dell Technologies’ ability to manage solutions and products and services transitions in an effective manner; Dell Technologies’ ability to deliver high-quality products, software, and services; cyber attacks or other data security incidents;

[0001571996-21-000060:8k_2_02:58]
4

[0001571996-21-000060:8k_2_02:59]
Dell Technologies’ foreign operations and ability to generate substantial non-U.S. net revenue; Dell Technologies’ product, services, customer, and geographic sales mix, and seasonal sales trends; the performance of Dell Technologies’ sales channel partners; access to the capital markets by Dell Technologies or its customers; material impairment of the value of goodwill or intangible assets; weak economic conditions and the effect of additional regulation on Dell Technologies’ financial services activities; counterparty default risks; the loss by Dell Technologies of any contracts for ISG services and solutions and its ability to perform such contracts at their estimated costs; loss by Dell Technologies of government contracts; Dell Technologies’ ability to develop and protect its proprietary intellectual property or obtain licenses to intellectual property developed by others on commercially reasonable and competitive terms; disruptions in Dell Technologies’ infrastructure; Dell Technologies’ ability to hedge effectively its exposure to fluctuations in foreign currency exchange rates and interest rates; expiration of tax holidays or favorable tax rate structures, or unfavorable outcomes in tax audits and other tax compliance matters; impairment of portfolio investments; unfavorable results of legal proceedings; compliance requirements of changing environmental and safety laws or other laws; the effect of armed hostilities, terrorism, natural disasters, and public health issues; Dell Technologies’ dependence on the services of Michael Dell and key employees; and Dell Technologies’ level of indebtedness.

[0001571996-21-000060:8k_2_02:60]
This list of risks, uncertainties, and other factors is not complete. Dell Technologies discusses some of these matters more fully, as well as certain risk factors that could affect Dell Technologies’ business, financial condition, results of operations, and prospects, in its reports filed with the SEC, including Dell Technologies’ annual report on Form 10-K for the fiscal year ended January 29, 2021, quarterly reports on Form 10-Q, and current reports on Form 8-K. These filings are available for review through the SEC’s website at www.sec.gov. Any or all forward-looking statements Dell Technologies makes may turn out to be wrong and can be affected by inaccurate assumptions Dell Technologies might make or by known or unknown risks, uncertainties and other factors, including those identified in this press release. Accordingly, you should not place undue reliance on the forward-looking statements made in this press release, which speak only as of its date. Dell Technologies does not undertake to update, and expressly disclaims any duty to update, its forward-looking statements, whether as a result of circumstances or events that arise after the date they are made, new information, or otherwise.

[0001571996-21-000060:8k_2_02:61]
5

[0001571996-21-000060:8k_2_02:62]
DELL TECHNOLOGIES INC.

[0001571996-21-000060:8k_2_02:63]
Condensed Consolidated Statements of Income and Related Financial Highlights

[0001571996-21-000060:8k_2_02:64]
(in millions, except percentages; unaudited)

[0001571996-21-000060:8k_2_02:65]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | October 29, 2021 |  | October 30, 2020 |  | Change |  | October 29, 2021 |  | October 30, 2020 |  | Change |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Products | $ | 21,540 |  | $ | 17,352 |  | 24% |  | $ | 58,968 |  |  | $ | 50,127 |  |  | 18% |
| Services | 6,854 |  | 6,130 |  | 12% |  | 20,035 |  |  | 17,985 |  |  | 11% |
| Total net revenue | 28,394 |  | 23,482 |  | 21% |  | 79,003 |  |  | 68,112 |  |  | 16% |
| Cost of net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Products | 17,552 |  | 13,789 |  | 27% |  | 47,137 |  |  | 39,923 |  |  | 18% |
| Services | 2,783 |  | 2,432 |  | 14% |  | 8,164 |  |  | 6,919 |  |  | 18% |
| Total cost of net revenue | 20,335 |  | 16,221 |  | 25% |  | 55,301 |  |  | 46,842 |  |  | 18% |
| Gross margin | 8,059 |  | 7,261 |  | 11% |  | 23,702 |  |  | 21,270 |  |  | 11% |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative | 5,293 |  | 4,772 |  | 11% |  | 15,398 |  |  | 14,419 |  |  | 7% |
| Research and development | 1,417 |  | 1,360 |  | 4% |  | 4,208 |  |  | 3,884 |  |  | 8% |
| Total operating expenses | 6,710 |  | 6,132 |  | 9% |  | 19,606 |  |  | 18,303 |  |  | 7% |
| Operating income | 1,349 |  | 1,129 |  | 19% |  | 4,096 |  |  | 2,967 |  |  | 38% |
| Interest and other, net | 3,436 |  | 273 |  | NM |  | 2,689 |  |  | (929) |  |  | 389% |
| Income before income taxes | 4,785 |  | 1,402 |  | 241% |  | 6,785 |  |  | 2,038 |  |  | 233% |
| Income tax expense (benefit) | 897 |  | 521 |  | 72% |  | 1,079 |  |  | (124) |  |  | 970% |
| Net income | 3,888 |  | 881 |  | 341% |  | 5,706 |  |  | 2,162 |  |  | 164% |
| Less: Net income attributable to non-controlling interests | 45 |  | 49 |  | (8)% |  | 145 |  |  | 139 |  |  | 4% |
| Net income attributable to Dell Technologies Inc. | $ | 3,843 |  | $ | 832 |  | 362% |  | $ | 5,561 |  |  | $ | 2,023 |  |  | 175% |
| Percentage of Total Net Revenue: |  |  |  |  |  |  |  |  |  |  |
| Gross margin | 28 | % |  | 31 | % |  |  |  | 30 | % |  | 31 | % |  |  |
| Selling, general, and administrative | 19 | % |  | 20 | % |  |  |  | 19 | % |  | 21 | % |  |  |
| Research and development | 5 | % |  | 6 | % |  |  |  | 5 | % |  | 6 | % |  |  |
| Operating expenses | 24 | % |  | 26 | % |  |  |  | 25 | % |  | 27 | % |  |  |
| Operating income | 5 | % |  | 5 | % |  |  |  | 5 | % |  | 4 | % |  |  |
| Income before income taxes | 17 | % |  | 6 | % |  |  |  | 9 | % |  | 3 | % |  |  |
| Net income | 14 | % |  | 4 | % |  |  |  | 7 | % |  | 3 | % |  |  |
| Income tax rate | 18.7 | % |  | 37.2 | % |  |  |  | 15.9 | % |  | -6.1 | % |  |  |

[0001571996-21-000060:8k_2_02:66]
Amounts are based on underlying data and may not visually foot due to rounding.

[0001571996-21-000060:8k_2_02:67]
6

[0001571996-21-000060:8k_2_02:68]
DELL TECHNOLOGIES INC.

[0001571996-21-000060:8k_2_02:69]
Consolidated Statements of Financial Position

[0001571996-21-000060:8k_2_02:70]
(in millions; unaudited)

[0001571996-21-000060:8k_2_02:71]
|  | October 29, 2021 |  | January 29, 2021 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 22,406 |  |  | $ | 14,201 |  |
| Accounts receivable, net | 14,177 |  |  | 12,788 |  |
| Short-term financing receivables, net | 4,970 |  |  | 5,155 |  |
| Inventories, net | 5,442 |  |  | 3,402 |  |
| Other current assets | 10,184 |  |  | 8,021 |  |
| Total current assets | 57,179 |  |  | 43,567 |  |
| Property, plant, and equipment, net | 6,925 |  |  | 6,431 |  |
| Long-term investments | 1,827 |  |  | 1,624 |  |
| Long-term financing receivables, net | 5,270 |  |  | 5,339 |  |
| Goodwill | 40,701 |  |  | 40,829 |  |
| Intangible assets, net | 12,319 |  |  | 14,429 |  |
| Other non-current assets | 11,456 |  |  | 11,196 |  |
| Total assets | $ | 135,677 |  |  | $ | 123,415 |  |
| LIABILITIES, REDEEMABLE SHARES, AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Short-term debt | $ | 16,280 |  |  | $ | 6,362 |  |
| Accounts payable | 26,772 |  |  | 21,696 |  |
| Accrued and other | 10,081 |  |  | 9,549 |  |
| Short-term deferred revenue | 16,569 |  |  | 16,525 |  |
| Total current liabilities | 69,702 |  |  | 54,132 |  |
| Long-term debt | 31,699 |  |  | 41,622 |  |
| Long-term deferred revenue | 14,885 |  |  | 14,276 |  |
| Other non-current liabilities | 5,197 |  |  | 5,360 |  |
| Total liabilities | 121,483 |  |  | 115,390 |  |
| Redeemable shares | — |  |  | 472 |  |
| Stockholders’ equity: |  |  |  |
| Total Dell Technologies Inc. stockholders’ equity | 8,954 |  |  | 2,479 |  |
| Non-controlling interests | 5,240 |  |  | 5,074 |  |
| Total stockholders’ equity | 14,194 |  |  | 7,553 |  |
| Total liabilities, redeemable shares, and stockholders’ equity | $ | 135,677 |  |  | $ | 123,415 |  |

[0001571996-21-000060:8k_2_02:72]
7

[0001571996-21-000060:8k_2_02:73]
DELL TECHNOLOGIES INC.

[0001571996-21-000060:8k_2_02:74]
Condensed Consolidated Statements of Cash Flows

[0001571996-21-000060:8k_2_02:75]
(in millions; unaudited)

[0001571996-21-000060:8k_2_02:76]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 29, 2021 |  | October 30, 2020 |  | October 29, 2021 |  | October 30, 2020 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |
| Net income | $ | 3,888 |  |  | $ | 881 |  |  | $ | 5,706 |  |  | $ | 2,162 |  |
| Adjustments to reconcile net income to net cash provided by (used in) operating activities | (637) |  |  | 2,113 |  |  | 1,508 |  |  | 3,368 |  |
| Change in cash from operating activities | 3,251 |  |  | 2,994 |  |  | 7,214 |  |  | 5,530 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |
| Purchases of investments | (50) |  |  | (122) |  |  | (320) |  |  | (296) |  |
| Maturities and sales of investments | 119 |  |  | 27 |  |  | 454 |  |  | 98 |  |
| Capital expenditures and capitalized software development costs | (799) |  |  | (480) |  |  | (2,056) |  |  | (1,584) |  |
| Acquisition of businesses and assets, net | — |  |  | (71) |  |  | (16) |  |  | (405) |  |
| Divestitures of businesses and assets, net | 3,957 |  |  | 2,067 |  |  | 3,957 |  |  | 2,187 |  |
| Other | 14 |  |  | 14 |  |  | 34 |  |  | 26 |  |
| Change in cash from investing activities | 3,241 |  |  | 1,435 |  |  | 2,053 |  |  | 26 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |
| Proceeds from the issuance of common stock | 140 |  |  | 168 |  |  | 326 |  |  | 389 |  |
| Repurchases of parent common stock (a) | (18) |  |  | — |  |  | (35) |  |  | (240) |  |
| Repurchases of subsidiary common stock (a) | (196) |  |  | (299) |  |  | (1,174) |  |  | (890) |  |
| Proceeds from debt | 9,102 |  |  | 2,925 |  |  | 13,037 |  |  | 14,772 |  |
| Repayments of debt | (4,646) |  |  | (7,024) |  |  | (13,069) |  |  | (17,244) |  |
| Other | (99) |  |  | (80) |  |  | (113) |  |  | (270) |  |
| Change in cash from financing activities | 4,283 |  |  | (4,310) |  |  | (1,028) |  |  | (3,483) |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash | (33) |  |  | (15) |  |  | (54) |  |  | (67) |  |
| Change in cash, cash equivalents, and restricted cash | 10,742 |  |  | 104 |  |  | 8,185 |  |  | 2,006 |  |
| Cash, cash equivalents, and restricted cash at beginning of the period | 12,627 |  |  | 12,053 |  |  | 15,184 |  |  | 10,151 |  |
| Cash, cash equivalents, and restricted cash at end of the period | $ | 23,369 |  |  | $ | 12,157 |  |  | $ | 23,369 |  |  | $ | 12,157 |  |

[0001571996-21-000060:8k_2_02:77]
_________________

[0001571996-21-000060:8k_2_02:78]
(a) Common stock repurchases are inclusive of employee tax withholding on stock-based compensation.

[0001571996-21-000060:8k_2_02:79]
8

[0001571996-21-000060:8k_2_02:80]
DELL TECHNOLOGIES INC.

[0001571996-21-000060:8k_2_02:81]
Segment Information

[0001571996-21-000060:8k_2_02:82]
(in millions, except percentages; unaudited; continued on next page)

[0001571996-21-000060:8k_2_02:83]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | October 29, 2021 |  | October 30, 2020 |  | Change |  | October 29, 2021 |  | October 30, 2020 |  | Change |
| Infrastructure Solutions Group (ISG): |
| Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Servers and networking | $ | 4,533 |  |  | $ | 4,164 |  |  | 9% |  | $ | 13,104 |  |  | $ | 12,118 |  |  | 8% |
| Storage | 3,895 |  |  | 3,860 |  |  | 1% |  | 11,667 |  |  | 11,682 |  |  | —% |
| Total ISG net revenue | $ | 8,428 |  |  | $ | 8,024 |  |  | 5% |  | $ | 24,771 |  |  | $ | 23,800 |  |  | 4% |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| ISG operating income | $ | 892 |  |  | $ | 882 |  |  | 1% |  | $ | 2,650 |  |  | $ | 2,587 |  |  | 2% |
| % of ISG net revenue | 11 | % |  | 11 | % |  |  |  | 11 | % |  | 11 | % |  |  |
| % of total reportable segment operating income | 31 | % |  | 32 | % |  |  |  | 32 | % |  | 35 | % |  |  |
| Client Solutions Group (CSG): |
| Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 12,292 |  |  | $ | 8,783 |  |  | 40% |  | $ | 32,668 |  |  | $ | 25,456 |  |  | 28% |
| Consumer | 4,254 |  |  | 3,503 |  |  | 21% |  | 11,446 |  |  | 9,137 |  |  | 25% |
| Total CSG net revenue | $ | 16,546 |  |  | $ | 12,286 |  |  | 35% |  | $ | 44,114 |  |  | $ | 34,593 |  |  | 28% |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| CSG operating income | $ | 1,147 |  |  | $ | 1,002 |  |  | 14% |  | $ | 3,232 |  |  | $ | 2,309 |  |  | 40% |
| % of CSG net revenue | 7 | % |  | 8 | % |  |  |  | 7 | % |  | 7 | % |  |  |
| % of total reportable segment operating income | 40 | % |  | 37 | % |  |  |  | 38 | % |  | 31 | % |  |  |
| VMware: |
| Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Total VMware net revenue | $ | 3,178 |  |  | $ | 2,893 |  |  | 10% |  | $ | 9,317 |  |  | $ | 8,556 |  |  | 9% |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| VMware operating income | $ | 837 |  |  | $ | 837 |  |  | —% |  | $ | 2,527 |  |  | $ | 2,504 |  |  | 1% |
| % of VMware net revenue | 26 | % |  | 29 | % |  |  |  | 27 | % |  | 29 | % |  |  |
| % of total reportable segment operating income | 29 | % |  | 31 | % |  |  |  | 30 | % |  | 34 | % |  |  |

[0001571996-21-000060:8k_2_02:84]
Amounts are based on underlying data and may not visually foot due to rounding.

[0001571996-21-000060:8k_2_02:85]
9

[0001571996-21-000060:8k_2_02:86]
DELL TECHNOLOGIES INC.

[0001571996-21-000060:8k_2_02:87]
Segment Information

[0001571996-21-000060:8k_2_02:88]
(in millions, except percentages; unaudited; continued)

[0001571996-21-000060:8k_2_02:89]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 29, 2021 |  | October 30, 2020 |  | October 29, 2021 |  | October 30, 2020 |
| Reconciliation to consolidated net revenue: |  |  |  |  |  |  |
| Reportable segment net revenue | $ | 28,152 |  |  | $ | 23,203 |  |  | $ | 78,202 |  |  | $ | 66,949 |  |
| Other businesses (a) | 251 |  |  | 314 |  |  | 829 |  |  | 1,288 |  |
| Unallocated transactions (b) | 2 |  |  | 4 |  |  | 6 |  |  | 4 |  |
| Impact of purchase accounting (c) | (11) |  |  | (39) |  |  | (34) |  |  | (129) |  |
| Total consolidated net revenue | $ | 28,394 |  |  | $ | 23,482 |  |  | $ | 79,003 |  |  | $ | 68,112 |  |
| Reconciliation to consolidated operating income: |  |  |  |  |  |  |  |
| Reportable segment operating income | $ | 2,876 |  |  | $ | 2,721 |  |  | $ | 8,409 |  |  | $ | 7,400 |  |
| Other businesses (a) | (9) |  |  | 3 |  |  | (17) |  |  | 105 |  |
| Unallocated transactions (b) | 1 |  |  | 1 |  |  | 1 |  |  | (1) |  |
| Impact of purchase accounting (c) | (17) |  |  | (49) |  |  | (62) |  |  | (165) |  |
| Amortization of intangibles | (694) |  |  | (845) |  |  | (2,114) |  |  | (2,547) |  |
| Transaction-related expenses (d) | (311) |  |  | (52) |  |  | (422) |  |  | (211) |  |
| Stock-based compensation expense (e) | (472) |  |  | (436) |  |  | (1,406) |  |  | (1,219) |  |
| Other corporate expenses (f) | (25) |  |  | (214) |  |  | (293) |  |  | (395) |  |
| Total consolidated operating income | $ | 1,349 |  |  | $ | 1,129 |  |  | $ | 4,096 |  |  | $ | 2,967 |  |

[0001571996-21-000060:8k_2_02:90]
_________________

[0001571996-21-000060:8k_2_02:91]
(a)Secureworks and Virtustream constitute Other businesses and do not meet the requirements for a reportable segment, either individually or collectively. The results of Other businesses are not material to the Company’s overall results. On September 1, 2020, the Company completed the sale of RSA Security. On October 1, 2021, the Company completed the sale of Boomi. Prior to the divestitures, the results of Boomi and RSA Security were included within Other businesses.

[0001571996-21-000060:8k_2_02:92]
(b)Unallocated transactions includes other corporate items that are not allocated to Dell Technologies’ reportable segments.

[0001571996-21-000060:8k_2_02:93]
(c)Impact of purchase accounting includes non-cash purchase accounting adjustments that are primarily related to the EMC merger transaction.

[0001571996-21-000060:8k_2_02:94]
(d)Transaction-related expenses includes acquisition, integration, and divestiture related costs.

[0001571996-21-000060:8k_2_02:95]
(e)Stock-based compensation expense consists of equity awards granted based on the estimated fair value of those awards at grant date.

[0001571996-21-000060:8k_2_02:96]
(f)Other corporate expenses includes impairment charges, severance, facilities action, and other costs.

[0001571996-21-000060:8k_2_02:97]
10

[0001571996-21-000060:8k_2_02:98]
SUPPLEMENTAL SELECTED NON-GAAP FINANCIAL MEASURES

[0001571996-21-000060:8k_2_02:99]
These tables present information about the Company’s non-GAAP net revenue, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, non-GAAP net income attributable to non-controlling interests, non-GAAP net income attributable to Dell Technologies Inc. - basic, non-GAAP net income attributable to Dell Technologies Inc. - diluted, non-GAAP earnings per share attributable to Dell Technologies Inc. - basic, non-GAAP earnings per share attributable to Dell Technologies Inc. - diluted, EBITDA, and adjusted EBITDA, which are non-GAAP financial measures provided as a supplement to the results provided in accordance with generally accepted accounting principles in the United States of America (“GAAP”). A detailed discussion of Dell Technologies’ reasons for including these non-GAAP financial measures, the limitations associated with these measures, the items excluded from these measures, and our reason for excluding those items are presented in “Management’s Discussion and Analysis of Financial Condition and Results of Operations — Non-GAAP Financial Measures” in our periodic reports filed with the SEC. Dell Technologies encourages investors to review the non-GAAP discussion in these reports in conjunction with the presentation of non-GAAP financial measures.

[0001571996-21-000060:8k_2_02:100]
11

[0001571996-21-000060:8k_2_02:101]
DELL TECHNOLOGIES INC.

[0001571996-21-000060:8k_2_02:102]
Selected Non-GAAP Financial Measures

[0001571996-21-000060:8k_2_02:103]
(in millions, except per share amounts and percentages; unaudited)

[0001571996-21-000060:8k_2_02:104]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | October 29, 2021 |  | October 30, 2020 |  | Change |  | October 29, 2021 |  | October 30, 2020 |  | Change |
| Non-GAAP net revenue | $ | 28,405 |  | $ | 23,521 |  | 21% |  | $ | 79,037 |  |  | $ | 68,241 |  |  | 16% |
| Non-GAAP gross margin | $ | 8,410 |  | $ | 7,771 |  | 8% |  | $ | 24,770 |  |  | $ | 22,722 |  |  | 9% |
| % of non-GAAP net revenue | 30 | % |  | 33 | % |  |  |  | 31 | % |  | 33 | % |  |  |
| Non-GAAP operating expenses | $ | 5,542 |  | $ | 5,046 |  | 10% |  | $ | 16,377 |  |  | $ | 15,218 |  |  | 8% |
| % of non-GAAP net revenue | 20 | % |  | 21 | % |  |  |  | 21 | % |  | 22 | % |  |  |
| Non-GAAP operating income | $ | 2,868 |  | $ | 2,725 |  | 5% |  | $ | 8,393 |  |  | $ | 7,504 |  |  | 12% |
| % of non-GAAP net revenue | 10 | % |  | 12 | % |  |  |  | 11 | % |  | 11 | % |  |  |
| Non-GAAP net income | $ | 2,015 |  | $ | 1,711 |  | 18% |  | $ | 5,745 |  |  | $ | 4,475 |  |  | 28% |
| % of non-GAAP net revenue | 7 | % |  | 7 | % |  |  |  | 7 | % |  | 7 | % |  |  |
| Adjusted EBITDA | $ | 3,410 |  | $ | 3,231 |  | 6% |  | $ | 9,976 |  |  | $ | 8,938 |  |  | 12% |
| % of non-GAAP net revenue | 12 | % |  | 14 | % |  |  |  | 13 | % |  | 13 | % |  |  |
| Non-GAAP earnings per share - diluted | $ | 2.37 |  | $ | 2.03 |  | 17% |  | $ | 6.75 |  |  | $ | 5.28 |  |  | 28% |

[0001571996-21-000060:8k_2_02:105]
Amounts are based on underlying data and may not visually foot due to rounding.

[0001571996-21-000060:8k_2_02:106]
12

[0001571996-21-000060:8k_2_02:107]
DELL TECHNOLOGIES INC.

[0001571996-21-000060:8k_2_02:108]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-21-000060:8k_2_02:109]
(in millions, except percentages; unaudited; continued on next page)

[0001571996-21-000060:8k_2_02:110]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | October 29, 2021 |  | October 30, 2020 |  | Change |  | October 29, 2021 |  | October 30, 2020 |  | Change |
| Net revenue | $ | 28,394 |  |  | $ | 23,482 |  |  | 21% |  | $ | 79,003 |  |  | $ | 68,112 |  |  | 16% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 11 |  |  | 39 |  |  |  |  | 34 |  |  | 129 |  |  |  |
| Non-GAAP net revenue | $ | 28,405 |  |  | $ | 23,521 |  |  | 21% |  | $ | 79,037 |  |  | $ | 68,241 |  |  | 16% |
| Gross margin | $ | 8,059 |  |  | $ | 7,261 |  |  | 11% |  | $ | 23,702 |  |  | $ | 21,270 |  |  | 11% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 275 |  |  | 375 |  |  |  |  | 826 |  |  | 1,122 |  |  |  |
| Impact of purchase accounting | 12 |  |  | 40 |  |  |  |  | 37 |  |  | 134 |  |  |  |
| Transaction-related expenses | — |  |  | — |  |  |  |  | — |  |  | — |  |  |  |
| Stock-based compensation expense | 62 |  |  | 51 |  |  |  |  | 183 |  |  | 141 |  |  |  |
| Other corporate expenses | 2 |  |  | 44 |  |  |  |  | 22 |  |  | 55 |  |  |  |
| Non-GAAP gross margin | $ | 8,410 |  |  | $ | 7,771 |  |  | 8% |  | $ | 24,770 |  |  | $ | 22,722 |  |  | 9% |
| Operating expenses | $ | 6,710 |  |  | $ | 6,132 |  |  | 9% |  | $ | 19,606 |  |  | $ | 18,303 |  |  | 7% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | (419) |  |  | (470) |  |  |  |  | (1,288) |  |  | (1,425) |  |  |  |
| Impact of purchase accounting | (5) |  |  | (9) |  |  |  |  | (25) |  |  | (31) |  |  |  |
| Transaction-related expenses | (311) |  |  | (52) |  |  |  |  | (422) |  |  | (211) |  |  |  |
| Stock-based compensation expense | (410) |  |  | (385) |  |  |  |  | (1,223) |  |  | (1,078) |  |  |  |
| Other corporate expenses | (23) |  |  | (170) |  |  |  |  | (271) |  |  | (340) |  |  |  |
| Non-GAAP operating expenses | $ | 5,542 |  |  | $ | 5,046 |  |  | 10% |  | $ | 16,377 |  |  | $ | 15,218 |  |  | 8% |
| Operating income | $ | 1,349 |  |  | $ | 1,129 |  |  | 19% |  | $ | 4,096 |  |  | $ | 2,967 |  |  | 38% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 694 |  |  | 845 |  |  |  |  | 2,114 |  |  | 2,547 |  |  |  |
| Impact of purchase accounting | 17 |  |  | 49 |  |  |  |  | 62 |  |  | 165 |  |  |  |
| Transaction-related expenses | 311 |  |  | 52 |  |  |  |  | 422 |  |  | 211 |  |  |  |
| Stock-based compensation expense | 472 |  |  | 436 |  |  |  |  | 1,406 |  |  | 1,219 |  |  |  |
| Other corporate expenses | 25 |  |  | 214 |  |  |  |  | 293 |  |  | 395 |  |  |  |
| Non-GAAP operating income | $ | 2,868 |  |  | $ | 2,725 |  |  | 5% |  | $ | 8,393 |  |  | $ | 7,504 |  |  | 12% |

[0001571996-21-000060:8k_2_02:111]
13

[0001571996-21-000060:8k_2_02:112]
DELL TECHNOLOGIES INC.

[0001571996-21-000060:8k_2_02:113]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-21-000060:8k_2_02:114]
(in millions, except percentages; unaudited; continued)

[0001571996-21-000060:8k_2_02:115]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | October 29, 2021 |  | October 30, 2020 |  | Change |  | October 29, 2021 |  | October 30, 2020 |  | Change |
| Net income | $ | 3,888 |  |  | $ | 881 |  |  | 341% |  | $ | 5,706 |  |  | $ | 2,162 |  |  | 164% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 694 |  |  | 845 |  |  |  |  | 2,114 |  |  | 2,547 |  |  |  |
| Impact of purchase accounting | 17 |  |  | 49 |  |  |  |  | 62 |  |  | 165 |  |  |  |
| Transaction-related expenses | (3,607) |  |  | (286) |  |  |  |  | (3,508) |  |  | (247) |  |  |  |
| Stock-based compensation expense | 472 |  |  | 436 |  |  |  |  | 1,406 |  |  | 1,219 |  |  |  |
| Other corporate expenses | 25 |  |  | 106 |  |  |  |  | 293 |  |  | 287 |  |  |  |
| Fair value adjustments on equity investments | (27) |  |  | (489) |  |  |  |  | (352) |  |  | (591) |  |  |  |
| Aggregate adjustment for income taxes | 553 |  |  | 169 |  |  |  |  | 24 |  |  | (1,067) |  |  |  |
| Non-GAAP net income | $ | 2,015 |  |  | $ | 1,711 |  |  | 18% |  | $ | 5,745 |  |  | $ | 4,475 |  |  | 28% |
| Net income | $ | 3,888 |  |  | $ | 881 |  |  | 341% |  | $ | 5,706 |  |  | $ | 2,162 |  |  | 164% |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Interest and other, net | (3,436) |  |  | (273) |  |  |  |  | (2,689) |  |  | 929 |  |  |  |
| Income tax expense (benefit) | 897 |  |  | 521 |  |  |  |  | 1,079 |  |  | (124) |  |  |  |
| Depreciation and amortization | 1,242 |  |  | 1,361 |  |  |  |  | 3,721 |  |  | 4,017 |  |  |  |
| EBITDA | $ | 2,591 |  |  | $ | 2,490 |  |  | 4% |  | $ | 7,817 |  |  | $ | 6,984 |  |  | 12% |
| EBITDA | $ | 2,591 |  |  | $ | 2,490 |  |  | 4% |  | $ | 7,817 |  |  | $ | 6,984 |  |  | 12% |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense | 472 |  |  | 436 |  |  |  |  | 1,406 |  |  | 1,219 |  |  |  |
| Impact of purchase accounting | 11 |  |  | 39 |  |  |  |  | 38 |  |  | 129 |  |  |  |
| Transaction-related expenses | 311 |  |  | 52 |  |  |  |  | 422 |  |  | 211 |  |  |  |
| Other corporate expenses | 25 |  |  | 214 |  |  |  |  | 293 |  |  | 395 |  |  |  |
| Adjusted EBITDA | $ | 3,410 |  |  | $ | 3,231 |  |  | 6% |  | $ | 9,976 |  |  | $ | 8,938 |  |  | 12% |

[0001571996-21-000060:8k_2_02:116]
14

[0001571996-21-000060:8k_2_02:117]
DELL TECHNOLOGIES INC.

[0001571996-21-000060:8k_2_02:118]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-21-000060:8k_2_02:119]
For the Three Months Ended October 29, 2021

[0001571996-21-000060:8k_2_02:120]
(in millions, except per share amounts; unaudited)

[0001571996-21-000060:8k_2_02:121]
|  | GAAP |  | Amortization of intangibles |  | Impact of purchase accounting |  | Transaction-related expenses |  | Stock-based compensation expense |  | Other corporate expenses |  | Fair value adjustments on equity investments |  | Aggregate adjustment for income taxes |  | Non-GAAP |
| Net income | $ | 3,888 |  |  | 694 |  |  | 17 |  |  | (3,607) |  |  | 472 |  |  | 25 |  |  | (27) |  |  | 553 |  |  | $ | 2,015 |  |
| Less: Net income attributable to non-controlling interests (a) | 45 |  |  | 54 |  |  | 1 |  |  | 15 |  |  | 52 |  |  | — |  |  | (2) |  |  | (22) |  |  | 143 |  |
| Net income attributable to Dell Technologies Inc. - basic | 3,843 |  |  | 640 |  |  | 16 |  |  | (3,622) |  |  | 420 |  |  | 25 |  |  | (25) |  |  | 575 |  |  | 1,872 |  |
| Incremental dilution from VMware, Inc. attributable to Dell Technologies Inc. (b) | (2) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (3) |  |
| Net income attributable to Dell Technologies Inc. - diluted | $ | 3,841 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 1,869 |  |
| Earnings per share - basic | $ | 5.02 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 2.44 |  |
| Earnings per share - diluted | $ | 4.87 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 2.37 |  |
| Weighted-average shares outstanding - basic | 766 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 766 |  |
| Weighted-average shares outstanding - diluted | 788 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 788 |  |

[0001571996-21-000060:8k_2_02:122]
_________________

[0001571996-21-000060:8k_2_02:123]
(a)     Net income attributable to non-controlling interests is calculated by multiplying the minority interest percentage of VMware, Inc. and SecureWorks Corp. by their respective non-GAAP net income adjustments for the period presented.

[0001571996-21-000060:8k_2_02:124]
(b)     Incremental dilution from VMware, Inc. attributable to Dell Technologies Inc. represents the impact of VMware, Inc.’s dilutive securities on the diluted earnings per share of Dell Technologies Inc. and is calculated by multiplying the difference between VMware, Inc.’s basic and diluted earnings per share by the number of shares of VMware, Inc. common stock held by Dell Technologies Inc.

[0001571996-21-000060:8k_2_02:125]
15

[0001571996-21-000060:8k_2_02:126]
DELL TECHNOLOGIES INC.

[0001571996-21-000060:8k_2_02:127]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-21-000060:8k_2_02:128]
For the Nine Months Ended October 29, 2021

[0001571996-21-000060:8k_2_02:129]
(in millions, except per share amounts; unaudited)

[0001571996-21-000060:8k_2_02:130]
|  | GAAP |  | Amortization of intangibles |  | Impact of purchase accounting |  | Transaction-related expenses |  | Stock-based compensation expense |  | Other corporate expenses |  | Fair value adjustments on equity investments |  | Aggregate adjustment for income taxes |  | Non-GAAP |
| Net income | $ | 5,706 |  |  | 2,114 |  |  | 62 |  |  | (3,508) |  |  | 1,406 |  |  | 293 |  |  | (352) |  |  | 24 |  |  | $ | 5,745 |  |
| Less: Net income attributable to non-controlling interests (a) | 145 |  |  | 162 |  |  | 3 |  |  | 24 |  |  | 162 |  |  | — |  |  | 5 |  |  | (67) |  |  | 434 |  |
| Net income attributable to Dell Technologies Inc. - basic | 5,561 |  |  | 1,952 |  |  | 59 |  |  | (3,532) |  |  | 1,244 |  |  | 293 |  |  | (357) |  |  | 91 |  |  | 5,311 |  |
| Incremental dilution from VMware, Inc. attributable to Dell Technologies Inc. (b) | (7) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (12) |  |
| Net income attributable to Dell Technologies Inc. - diluted | $ | 5,554 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 5,299 |  |
| Earnings per share - basic | $ | 7.30 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 6.97 |  |
| Earnings per share - diluted | $ | 7.08 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 6.75 |  |
| Weighted-average shares outstanding - basic | 762 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 762 |  |
| Weighted-average shares outstanding - diluted | 785 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 785 |  |

[0001571996-21-000060:8k_2_02:131]
_________________

[0001571996-21-000060:8k_2_02:132]
(a)     Net income attributable to non-controlling interests is calculated by multiplying the minority interest percentage of VMware, Inc. and SecureWorks Corp. by their respective non-GAAP net income adjustments for the period presented.

[0001571996-21-000060:8k_2_02:133]
(b)     Incremental dilution from VMware, Inc. attributable to Dell Technologies Inc. represents the impact of VMware, Inc.’s dilutive securities on the diluted earnings per share of Dell Technologies Inc. and is calculated by multiplying the difference between VMware, Inc.’s basic and diluted earnings per share by the number of shares of VMware, Inc. common stock held by Dell Technologies Inc.

[0001571996-21-000060:8k_2_02:134]
16

[0001571996-21-000060:8k_2_02:135]
DELL TECHNOLOGIES INC.

[0001571996-21-000060:8k_2_02:136]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-21-000060:8k_2_02:137]
For the Three Months Ended October 30, 2020

[0001571996-21-000060:8k_2_02:138]
(in millions, except per share amounts; unaudited)

[0001571996-21-000060:8k_2_02:139]
|  | GAAP |  | Amortization of intangibles |  | Impact of purchase accounting |  | Transaction-related expenses |  | Stock-based compensation expense |  | Other corporate expenses |  | Fair value adjustments on equity investments |  | Aggregate adjustment for income taxes |  | Non-GAAP |
| Net income | $ | 881 |  |  | 845 |  |  | 49 |  |  | (286) |  |  | 436 |  |  | 106 |  |  | (489) |  |  | 169 |  |  | $ | 1,711 |  |
| Less: Net income attributable to non-controlling interests (a) | 49 |  |  | 63 |  |  | 3 |  |  | 5 |  |  | 61 |  |  | 9 |  |  | (34) |  |  | (13) |  |  | 143 |  |
| Net income attributable to Dell Technologies Inc. - basic | 832 |  |  | 782 |  |  | 46 |  |  | (291) |  |  | 375 |  |  | 97 |  |  | (455) |  |  | 182 |  |  | 1,568 |  |
| Incremental dilution from VMware, Inc. attributable to Dell Technologies Inc. (b) | (3) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (4) |  |
| Net income attributable to Dell Technologies Inc. - diluted | $ | 829 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 1,564 |  |
| Earnings per share - basic | $ | 1.11 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 2.10 |  |
| Earnings per share - diluted | $ | 1.08 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 2.03 |  |
| Weighted-average shares outstanding - basic | 747 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 747 |  |
| Weighted-average shares outstanding - diluted | 771 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 771 |  |

[0001571996-21-000060:8k_2_02:140]
_________________

[0001571996-21-000060:8k_2_02:141]
(a)     Net income attributable to non-controlling interests is calculated by multiplying the minority interest percentage of VMware, Inc. and SecureWorks Corp. by their respective non-GAAP net income adjustments for the period presented.

[0001571996-21-000060:8k_2_02:142]
(b)     Incremental dilution from VMware, Inc. attributable to Dell Technologies Inc. represents the impact of VMware, Inc.’s dilutive securities on the diluted earnings per share of Dell Technologies Inc. and is calculated by multiplying the difference between VMware, Inc.’s basic and diluted earnings per share by the number of shares of VMware, Inc. common stock held by Dell Technologies Inc.

[0001571996-21-000060:8k_2_02:143]
17

[0001571996-21-000060:8k_2_02:144]
DELL TECHNOLOGIES INC.

[0001571996-21-000060:8k_2_02:145]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-21-000060:8k_2_02:146]
For the Nine Months Ended October 30, 2020

[0001571996-21-000060:8k_2_02:147]
(in millions, except per share amounts; unaudited)

[0001571996-21-000060:8k_2_02:148]
|  | GAAP |  | Amortization of intangibles |  | Impact of purchase accounting |  | Transaction-related expenses |  | Stock-based compensation expense |  | Other corporate expenses |  | Fair value adjustments on equity investments |  | Aggregate adjustment for income taxes |  | Non-GAAP |
| Net income | $ | 2,162 |  |  | 2,547 |  |  | 165 |  |  | (247) |  |  | 1,219 |  |  | 287 |  |  | (591) |  |  | (1,067) |  |  | $ | 4,475 |  |
| Less: Net income attributable to non-controlling interests (a) | 139 |  |  | 187 |  |  | 10 |  |  | 20 |  |  | 172 |  |  | 9 |  |  | (35) |  |  | (77) |  |  | 425 |  |
| Net income attributable to Dell Technologies Inc. - basic | 2,023 |  |  | $ | 2,360 |  |  | $ | 155 |  |  | $ | (267) |  |  | $ | 1,047 |  |  | $ | 278 |  |  | $ | (556) |  |  | $ | (990) |  |  | 4,050 |  |
| Incremental dilution from VMware, Inc. attributable to Dell Technologies Inc. (b) | (8) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (13) |  |
| Net income attributable to Dell Technologies Inc. - diluted | $ | 2,015 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 4,037 |  |
| Earnings per share - basic | $ | 2.73 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 5.46 |  |
| Earnings per share - diluted | $ | 2.64 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 5.28 |  |
| Weighted-average shares outstanding - basic | 742 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 742 |  |
| Weighted-average shares outstanding - diluted | 764 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 764 |  |

[0001571996-21-000060:8k_2_02:149]
_________________

[0001571996-21-000060:8k_2_02:150]
(a)     Net income attributable to non-controlling interests is calculated by multiplying the minority interest percentage of VMware, Inc. and SecureWorks Corp. by their respective non-GAAP net income adjustments for the period presented.

[0001571996-21-000060:8k_2_02:151]
(b)     Incremental dilution from VMware, Inc. attributable to Dell Technologies Inc. represents the impact of VMware, Inc.’s dilutive securities on the diluted earnings per share of Dell Technologies Inc. and is calculated by multiplying the difference between VMware, Inc.’s basic and diluted earnings per share by the number of shares of VMware, Inc. common stock held by Dell Technologies Inc.
