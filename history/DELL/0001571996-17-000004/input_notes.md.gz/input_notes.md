# DELL notes — 0001571996-17-000004


## dvmt:ReconciliationofConsolidatedNetIncomeLossTableTextBlock

[0001571996-17-000004:notes:1]
The following table presents a reconciliation to the consolidated net income (loss) attributable to Dell Technologies Inc.:

[0001571996-17-000004:notes:2]
|  | Fiscal Year Ended |
|  | February 3, 2017 |  | January 29, 2016 |  | January 30, 2015 |
|  | (in millions) |
| Net income from continuing operations attributable to Class V Common Stock | $ | 313 |  |  | $ | — |  |  | $ | — |  |
| Net loss from continuing operations attributable to DHI Group | (4,004 | ) |  | (1,168 | ) |  | (1,108 | ) |
| Net loss from continuing operations attributable to Dell Technologies Inc. | (3,691 | ) |  | (1,168 | ) |  | (1,108 | ) |
| Income (loss) from discontinued operations, net of income taxes | 2,019 |  |  | 64 |  |  | (113 | ) |
| Net loss attributable to Dell Technologies Inc. | $ | (1,672 | ) |  | $ | (1,104 | ) |  | $ | (1,221 | ) |


## dvmt:SummaryofValuationandQualifyingAccountsTableTextBlock

[0001571996-17-000004:notes:3]
Valuation and Qualifying Accounts

[0001571996-17-000004:notes:4]
|  | Fiscal Year Ended |
|  | February 3, 2017 |  | January 29, 2016 |  | January 30, 2015 |
|  | (in millions) |
| Trade Receivables - Allowance for doubtful accounts |  |  |  |  |  |
| Balance at beginning of period | $ | 36 |  |  | $ | 38 |  |  | $ | 12 |  |
| Provision charged to income statement | 43 |  |  | 64 |  |  | 62 |  |
| Bad debt write-offs | (33 | ) |  | (66 | ) |  | (36 | ) |
| Balance at end of period | $ | 46 |  |  | $ | 36 |  |  | $ | 38 |  |
| Trade Receivables - Allowance for customer returns |  |  |  |  |  |
| Balance at beginning of period | $ | 123 |  |  | $ | 130 |  |  | $ | 107 |  |
| Provision charged to income statement | 470 |  |  | 410 |  |  | 454 |  |
| Sales returns | (300 | ) |  | (417 | ) |  | (431 | ) |
| Balance at end of period | $ | 293 |  |  | $ | 123 |  |  | $ | 130 |  |
| Customer Financing Receivables - Allowance for financing receivable losses |
| Balance at beginning of period | $ | 176 |  |  | $ | 194 |  |  | $ | 215 |  |
| Provision charged to income statement | 75 |  |  | 104 |  |  | 147 |  |
| Charge-offs, net of recoveries (a) | (108 | ) |  | (122 | ) |  | (168 | ) |
| Balance at end of period | $ | 143 |  |  | $ | 176 |  |  | $ | 194 |  |
| Tax Valuation Allowance |  |  |  |  |  |
| Balance at beginning of period | $ | 816 |  |  | $ | 432 |  |  | $ | 399 |  |
| Charged to income tax provision | (488 | ) |  | 384 |  |  | 33 |  |
| Allowance acquired | 409 |  |  | — |  |  | — |  |
| Balance at end of period | $ | 737 |  |  | $ | 816 |  |  | $ | 432 |  |

[0001571996-17-000004:notes:5]
| (a) | Charge-offs to the allowance for financing receivable losses for customer financing receivables includes principal and interest. |


## invest:InvestmentTableTextBlock

[0001571996-17-000004:notes:6]
The following table summarizes, by major security type, the carrying value and amortized cost of the Company's investments.  All debt security investments with remaining effective maturities in excess of one year and substantially all equity and other securities are recorded as long-term investments in the Consolidated Statements of Financial Position.

[0001571996-17-000004:notes:7]
|  | February 3, 2017 |  | January 29, 2016 |
|  | Carrying Value |  | Cost |  | Unrealized Gain |  | Unrealized (Loss) |  | Carrying Value |  | Cost |  | Unrealized Gain |  | Unrealized (Loss) |
|  | (in millions) |
| Investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government and agencies | $ | 231 |  |  | $ | 231 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| U.S. corporate debt securities | 650 |  |  | 651 |  |  | — |  |  | (1 | ) |  | — |  |  | — |  |  | — |  |  | — |  |
| Foreign debt securities | 742 |  |  | 743 |  |  | — |  |  | (1 | ) |  | — |  |  | — |  |  | — |  |  | — |  |
| Municipal obligations | 348 |  |  | 348 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Asset-backed securities | 4 |  |  | 4 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total short-term investments | 1,975 |  |  | 1,977 |  |  | — |  |  | (2 | ) |  | — |  |  | — |  |  | — |  |  | — |  |
| U.S. government and agencies | 683 |  |  | 689 |  |  | — |  |  | (6 | ) |  | — |  |  | — |  |  | — |  |  | — |  |
| U.S. corporate debt securities | 1,150 |  |  | 1,164 |  |  | — |  |  | (14 | ) |  | — |  |  | — |  |  | — |  |  | — |  |
| Foreign debt securities | 1,341 |  |  | 1,356 |  |  | — |  |  | (15 | ) |  | — |  |  | — |  |  | — |  |  | — |  |
| Municipal obligations | 4 |  |  | 4 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Equity and other securities (a) | 624 |  |  | 604 |  |  | 22 |  |  | (2 | ) |  | 114 |  |  | 114 |  |  | — |  |  | — |  |
| Total long-term investments | 3,802 |  |  | 3,817 |  |  | 22 |  |  | (37 | ) |  | 114 |  |  | 114 |  |  | — |  |  | — |  |
| Total investments | $ | 5,777 |  |  | $ | 5,794 |  |  | $ | 22 |  |  | $ | (39 | ) |  | $ | 114 |  |  | $ | 114 |  |  | $ | — |  |  | $ | — |  |

[0001571996-17-000004:notes:8]
____________________

[0001571996-17-000004:notes:9]
| (a) | The majority of equity and other securities are investments accounted for under the cost method, while the remainder are investments that are measured at fair value on a recurring basis. See Note 5 of the Notes to the Consolidated Financial Statements for additional information on investments measured at fair value on a recurring basis. |


## invest:InvestmentTextBlock

[0001571996-17-000004:notes:10]
INVESTMENTS

[0001571996-17-000004:notes:11]
The Company's investments in debt securities are classified as available-for-sale securities, which are carried at fair value.  As of February 3, 2017, all investments in an unrealized loss position have been in a continuous unrealized loss position for less than 12 months.

[0001571996-17-000004:notes:12]
The contractual maturities of debt securities held at February 3, 2017 are as follows:

[0001571996-17-000004:notes:13]
|  | Carrying Value |  | Amortized Cost |
|  | (in millions) |
| Due within one year | $ | 1,975 |  |  | $ | 1,977 |  |
| Due after 1 year through 5 years | 3,120 |  |  | 3,152 |  |
| Due after 5 years through 10 years | 58 |  |  | 61 |  |
| Total | $ | 5,153 |  |  | $ | 5,190 |  |


## us-gaap:AllowanceForCreditLossesOnFinancingReceivablesTableTextBlock

[0001571996-17-000004:notes:14]
The following table summarizes the changes in the allowance for financing receivable losses for the respective periods:

[0001571996-17-000004:notes:15]
|  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |  |  |  |  |  |
| Balances as of January 31, 2014 | $ | 171 |  |  | $ | 44 |  |  | $ | 215 |  |
| Charge-offs, net of recoveries | (151 | ) |  | (17 | ) |  | (168 | ) |
| Provision charged to income statement | 125 |  |  | 22 |  |  | 147 |  |
| Balances as of January 30, 2015 | 145 |  |  | 49 |  |  | 194 |  |
| Charge-offs, net of recoveries | (105 | ) |  | (17 | ) |  | (122 | ) |
| Provision charged to income statement | 78 |  |  | 26 |  |  | 104 |  |
| Balances as of January 29, 2016 | 118 |  |  | 58 |  |  | 176 |  |
| Charge-offs, net of recoveries | (91 | ) |  | (17 | ) |  | (108 | ) |
| Provision charged to income statement | 64 |  |  | 11 |  |  | 75 |  |
| Balances as of February 3, 2017 | $ | 91 |  |  | $ | 52 |  |  | $ | 143 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001571996-17-000004:notes:16]
These Consolidated Financial Statements have been prepared in accordance with accounting principles generally accepted in the United States of America ("GAAP").


## us-gaap:BusinessAcquisitionProFormaInformationTextBlock

[0001571996-17-000004:notes:17]
The following table provides unaudited pro forma results of operations for the periods presented as if the transaction date had occurred on January 31, 2015, the first day of Fiscal 2016.

[0001571996-17-000004:notes:18]
|  | Fiscal Year Ended |
|  | February 3, 2017 |  | January 29, 2016 |
|  | (in millions) |
| Total net revenue | $ | 74,225 |  |  | $ | 73,138 |  |
| Net loss attributable to Dell Technologies Inc. | $ | (3,200 | ) |  | $ | (6,013 | ) |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001571996-17-000004:notes:19]
BUSINESS COMBINATIONS

[0001571996-17-000004:notes:20]
EMC Merger Transaction

[0001571996-17-000004:notes:21]
On September 7, 2016, EMC became a wholly-owned subsidiary of the Company as a result of the merger of Merger Sub with and into EMC, with EMC surviving as a wholly-owned subsidiary of the Company.  The EMC merger transaction was effected pursuant to the Agreement and Plan of Merger, dated as of October 12, 2015, by and among the Company, Dell, Merger Sub, and EMC, as amended by the First Amendment to Agreement and Plan of Merger, dated as of May 16, 2016, by and among the Company, Dell, Merger Sub, and EMC.

[0001571996-17-000004:notes:22]
Pursuant to the terms of the merger agreement, upon the completion of the EMC merger transaction, each issued and outstanding share of common stock, par value $0.01 per share, of EMC (approximately 2.0 billion as of September 7, 2016) was converted into the right to receive (1) $24.05 in cash, without interest, and (2) 0.11146 validly issued, fully paid and non-assessable shares of common stock of the Company designated as Class V Common Stock, par value $0.01 per share (the "Class V Common Stock"), plus cash in lieu of any fractional shares.  Shares of the Class V Common Stock were approved for listing on the New York Stock Exchange (the "NYSE") under the ticker symbol "DVMT" and began trading on September 7, 2016.

[0001571996-17-000004:notes:23]
The Class V Common Stock is a type of common stock commonly referred to as a tracking stock, which is a class of common stock that is intended to track the economic performance of a defined set of assets and liabilities.  The approximately 223 million shares of Class V Common Stock issued by Dell Technologies on September 7, 2016 are intended to track the economic performance of approximately 65% of the Company's economic interest in the Class V Group as of the closing date of the EMC merger transaction.  As of the closing date of the EMC merger transaction, the Class V Group, which consists of the Company's economic interest in the VMware business, consisted of approximately 343 million shares of Class A common stock, par value $0.01 per share, of VMware held by the Company.  As of such date, the DHI Group retained approximately 35% of the Company's economic interest in the Class V Group.  The DHI Group generally refers, in addition to such retained interest, to the direct and indirect interest of Dell Technologies in all of Dell Technologies' business, assets, properties, liabilities, and preferred stock other than those attributable to the Class V Group.

[0001571996-17-000004:notes:24]
Although the Class V Common Stock is intended to track the performance of approximately 65% of the Company's economic interest in the VMware business as of the closing date of the EMC merger transaction, there can be no assurance that the market price of the Class V Common Stock will, in fact, reflect the performance of such economic interest.  Holders of the Class V Common Stock are subject to all risks associated with an investment in Dell Technologies and all of its businesses, assets, and liabilities.  The holders of the Class V Common Stock do not have any special rights related to, direct ownership interest in, or recourse against the assets and liabilities attributed to the Class V Group.  While the Class V Group initially consists of the Company's economic interest in the shares of VMware Class A common stock attributed to it, the Class V Group in the future may have different assets and liabilities attributed to it.

[0001571996-17-000004:notes:25]
EMC, including its subsidiaries and affiliates, enables customers to build cloud-based infrastructures for existing applications while at the same time helping customers build and run new applications.  EMC's businesses include Information Storage, VMware, Pivotal, RSA Information Security, and Virtustream.  The EMC merger transaction represents a key element of the Company's strategy to provide the essential infrastructure for organizations to build their digital future, transform IT, and protect their most important asset, information.  Revenues of approximately $9.2 billion and net loss of approximately $2.1 billion attributable to EMC are included in the Consolidated Statements of Income (Loss) from the transaction date to February 3, 2017.  Both revenues and net loss attributable to EMC include the impact of purchase accounting as a result of the EMC merger transaction.

[0001571996-17-000004:notes:26]
Fair Value of Consideration Transferred

[0001571996-17-000004:notes:27]
The following table summarizes the consideration transferred to effect the EMC merger transaction:

[0001571996-17-000004:notes:28]
|  | Purchase Price |
|  | (in millions) |
| Consideration transferred: |  |
| Cash | $ | 47,694 |  |
| Expense and other (a) | 968 |  |
| Class V Common Stock (b) | 10,041 |  |
| Total consideration transferred | 58,703 |  |
| Non-controlling interests (c) | 6,048 |  |
| Less: Post-merger stock compensation expense (d) | (800 | ) |
| Total purchase price to allocate | $ | 63,951 |  |

[0001571996-17-000004:notes:29]
(a)   Expense and other primarily consists of cash payment for post-merger stock compensation expense, as described in footnote (d), and the value related to pre-merger services of EMC equity awards converted to deferred cash awards.

[0001571996-17-000004:notes:30]
| (b) | The fair value of the Class V Common Stock is based on the issuance of approximately 223 million shares with a per-share fair value of $45.07 (the opening share price of the Class V Common Stock on the NYSE on September 7, 2016, the first day of trading), which shares are intended to track the economic performance of approximately 65% of the Company's economic interest in the VMware business, as of the closing date of the EMC merger transaction. |

[0001571996-17-000004:notes:31]
| (c) | Non-controlling interests in VMware and Pivotal was $6.0 billion as of September 7, 2016. The fair value of the non-controlling interest related to VMware was calculated by multiplying outstanding shares of VMware common stock that were not owned by EMC by $73.28 (the opening share price of VMware Class A common stock on the NYSE on September 7, 2016). The fair value of the non-controlling interest relating to Pivotal was calculated based on the fair value of Pivotal, the ownership percentage of the non-controlling interests, and a discount for lack of control related to the non-controlling interest. |

[0001571996-17-000004:notes:32]
| (d) | Pursuant to the guidelines of ASC 805, a portion of the consideration related to accelerated EMC equity awards was recorded as post-merger day one stock compensation expense. This expense is attributable to post-merger services not rendered due to the acceleration. |

[0001571996-17-000004:notes:33]
Subsequent to the EMC merger transaction date, the Company recorded adjustments that increased goodwill by a net amount of approximately $264 million, decreased the fair value of VMware non-controlling interests by approximately $49 million, and increased the deferred tax liability associated with fair value adjustments primarily related to purchased intangibles and inventories by approximately $313 million.  These adjustments primarily resulted from new information about facts and circumstances that existed at the time of the acquisition.

[0001571996-17-000004:notes:34]
Assets Acquired and Liabilities Assumed

[0001571996-17-000004:notes:35]
The EMC merger transaction has been accounted for as a business combination under the acquisition method of accounting.  The following table summarizes the estimated fair values of the assets acquired and the liabilities assumed by major class as of the transaction date.  The Company's purchase accounting is substantially complete.  The cumulative impact of any subsequent changes resulting from the facts and circumstances that existed as of the transaction date will be adjusted in the reporting period in which the adjustment amount is determined.

[0001571996-17-000004:notes:36]
|  | Preliminary Allocation |
|  | (in millions) |
| Preliminary purchase price allocation (a): |  |
| Current assets: |  |
| Cash and cash equivalents | $ | 10,080 |  |
| Short-term investments | 1,765 |  |
| Accounts receivable (b) | 2,810 |  |
| Short-term financing receivables | 64 |  |
| Inventories, net | 1,993 |  |
| Other current assets | 903 |  |
| Total current assets | 17,615 |  |
| Property, plant, and equipment | 4,490 |  |
| Long-term investments | 4,317 |  |
| Long-term financing receivables, net | 65 |  |
| Goodwill (c) | 31,539 |  |
| Purchased intangibles (d) | 31,218 |  |
| Other non-current assets | 445 |  |
| Total assets | $ | 89,689 |  |
| Current liabilities: |  |
| Short-term debt | $ | 905 |  |
| Accounts payable | 728 |  |
| Accrued and other | 3,259 |  |
| Short-term deferred revenue (e) | 4,954 |  |
| Total current liabilities | 9,846 |  |
| Long-term debt | 5,474 |  |
| Long-term deferred revenue (e) | 3,469 |  |
| Deferred tax liabilities | 6,625 |  |
| Other non-current liabilities | 324 |  |
| Total liabilities | $ | 25,738 |  |
| Total net assets | $ | 63,951 |  |

[0001571996-17-000004:notes:37]
| (a) | Includes amounts allocated to ECD, which were classified as held for sale as of February 3, 2017. See Note 4 of the Notes to the Consolidated Financial Statements for more information on discontinued operations. |

[0001571996-17-000004:notes:38]
| (b) | Accounts receivable is comprised primarily of customer trade receivables. As such, the fair value of accounts receivable approximates the net carrying value of $2,810 million. The gross amount due is $2,919 million, of which $109 million is not expected to be collected. |

[0001571996-17-000004:notes:39]
| (c) | The Company recorded $31.5 billion in goodwill related to this transaction, which is primarily related to expected synergies from the transaction. This amount represents the excess of the purchase price over the fair value of the assets acquired and liabilities assumed associated with this transaction. This goodwill is not deductible for tax purposes. See Note 10 of the Notes to the Consolidated Financial Statements for preliminary goodwill allocation by reportable segment. |

[0001571996-17-000004:notes:40]
| (d) | Identifiable intangible assets are required to be measured at fair value. The fair value of identifiable intangible assets is determined primarily using variations of the income approach, which is based on the present value of the future after-tax cash flows attributable to each identifiable intangible asset. Some of the more significant assumptions inherent in the development of intangible asset values, from the perspective of a market participant, include, but are not limited to, the amount and timing of projected future cash flows (including revenue and profitability); the discount rate selected to measure the risks inherent in the future cash flows; the assessment of the asset's life cycle; the competitive trends impacting the asset; technology migration factors; and customer turnover. |

[0001571996-17-000004:notes:41]
(e)   Deferred revenue represents the fair value of remaining performance obligations and was determined based on estimates of costs incurred to-date by the acquiree or costs to be incurred by the Company and a reasonable profit margin.  Profit margins were determined based on comparable service provider margins, and the resulting profits were discounted using market participant discount rates to determine fair value.

[0001571996-17-000004:notes:42]
The preliminary fair values of EMC's identifiable intangible assets and their weighted-average useful lives have been estimated as follows:

[0001571996-17-000004:notes:43]
|  | Estimated Fair Value |  | Weighted Average Useful Life |
|  | (in millions) |  | (in years) |
| Developed technology | $ | 13,460 |  |  | 6 |
| Customer relationships | 13,440 |  |  | 11 |
| Trade names (Indefinite lived) | 2,320 |  |  | Indefinite |
| Trade names (Definite lived) | 980 |  |  | 8 |
| In-process research and development (a) | 890 |  |  | Indefinite |
| Leasehold assets | 128 |  |  | 25 |
| Total identifiable intangible assets | $ | 31,218 |  |  |  |

[0001571996-17-000004:notes:44]
(a)   In-process research and development is expected to be placed in to service during the first quarter of the fiscal year ending February 2, 2018.

[0001571996-17-000004:notes:45]
The total weighted-average amortization period for the intangible assets subject to amortization is 8 years.

[0001571996-17-000004:notes:46]
Acquisition-related Costs

[0001571996-17-000004:notes:47]
From inception through February 3, 2017, the Company incurred $1.2 billion of acquisition-related costs in connection with the EMC merger transaction.  Of this amount, as of February 3, 2017, $0.7 billion are capitalized debt issuance costs which were primarily presented as a direct reduction of the carrying amount of the related debt liability in the Consolidated Statements of Financial Position.  The remaining $0.5 billion of costs were recognized in the Consolidated Statements of Income (Loss) for the periods presented as follows:

[0001571996-17-000004:notes:48]
|  | Fiscal Year Ended |
|  | February 3, 2017 |  | January 29, 2016 |
|  | (in millions) |
| Acquisition-related costs: |  |  |  |
| Selling, general, and administrative expenses (a) | $ | 261 |  |  | $ | 40 |  |
| Interest and other, net (b) | 271 |  |  | — |  |
| Total | $ | 532 |  |  | $ | 40 |  |

[0001571996-17-000004:notes:49]
(a)   Acquisition-related costs recognized in selling, general, and administrative expenses primarily consist of outside services.

[0001571996-17-000004:notes:50]
(b)   Acquisition-related costs recognized in interest and other, net consist of both initially expensed debt issuance costs and the subsequent amortization of amounts capitalized as of the transaction date.

[0001571996-17-000004:notes:51]
In addition to the acquisition-related costs disclosed above, the Company incurred $0.8 billion in stock-based compensation charges related to the acceleration of vesting on EMC stock awards, and $0.1 billion in special retention cash awards issued to certain key employees.  These expenses were primarily recognized in selling, general, and administrative expenses during the fiscal year ended February 3, 2017.

[0001571996-17-000004:notes:52]
Pro Forma Revenue and Earnings

[0001571996-17-000004:notes:53]
The pro forma information for the fiscal year ended February 3, 2017 combines the Company's historical results for the fiscal year ended February 3, 2017 with EMC's historical results for the period from February 1, 2016 to September 6, 2016.  The pro forma information for the fiscal year ended January 29, 2016 combines the Company's historical results for the fiscal year ended January 29, 2016 with EMC's historical results for the fiscal year ended December 31, 2015.  The historical results have been adjusted in the pro forma information to give effect to items that are (a) directly attributable to the EMC merger transaction, (b) factually supportable, and (c) expected to have a continuing impact on the combined company's results.  The unaudited pro forma results include the recognition of non-recurring purchase accounting adjustments related to the step-up of inventory of $0.7 billion as well as the recognition of non-recurring transaction and integration costs, including accelerated stock-based compensation expense, of $1.5 billion in the fiscal year ended January 29, 2016.

[0001571996-17-000004:notes:54]
The pro forma information is presented for informational purposes only.  The pro forma information does not purport to represent what the combined company's results of operations or financial condition would have been had the EMC merger transaction actually occurred on the date indicated, and does not purport to project the combined company's results of operations for any future period or as of any future date.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock

[0001571996-17-000004:notes:55]
EMC MERGER TRANSACTION, OTHER TRANSACTIONS, AND BASIS OF PRESENTATION

[0001571996-17-000004:notes:56]
EMC Merger Transaction — On September 7, 2016, EMC Corporation, a Massachusetts corporation ("EMC"), became a wholly-owned subsidiary of Dell Technologies Inc. ("the Company") as a result of the merger of Universal Acquisition Co., a Delaware corporation and wholly-owned subsidiary of the Company ("Merger Sub"), with and into EMC, with EMC surviving as a wholly-owned subsidiary of the Company (the "EMC merger transaction").  The EMC merger transaction was effected pursuant to the Agreement and Plan of Merger, dated as of October 12, 2015, by and among the Company, Dell Inc., a Delaware corporation ("Dell"), Merger Sub, and EMC, as amended by the First Amendment to Agreement and Plan of Merger, dated as of May 16, 2016, by and among the Company, Dell, Merger Sub, and EMC.  See Note 3 of the Notes to the Consolidated Financial Statements for additional information on the EMC merger transaction.

[0001571996-17-000004:notes:57]
Divestitures — On March 27, 2016, Dell entered into a definitive agreement with NTT Data International L.L.C. to divest substantially all of Dell Services for cash consideration of approximately $3.0 billion, resulting in a gain on sale, net of tax, of $1.7 billion.  On November 2, 2016, the parties closed substantially all of the transaction.  On June 19, 2016, Dell entered into a definitive agreement with Francisco Partners and Elliot Management Corporation to divest substantially all of Dell Software Group ("DSG") for cash consideration of approximately $2.4 billion, resulting in a gain on sale, net of tax, of $0.6 billion.  On October 31, 2016, the parties closed the transaction.  On September 12, 2016, EMC entered into a definitive agreement with OpenText Corporation to divest the Dell EMC Enterprise Content Division ("ECD") for cash consideration of approximately $1.6 billion, resulting in a loss on sale, net of tax, of $0.4 billion.  On January 23, 2017, the parties closed the transaction.  In accordance with applicable accounting guidance, the results of Dell Services, DSG, and ECD, as well as the related gains or losses on sale, are presented as discontinued operations in the Consolidated Statements of Income (Loss) and, as such, have been excluded from both continuing operations and segment results for all periods presented.  Further, the Company has reclassified the related assets and liabilities as held for sale in the Consolidated Statements of Financial Position.  See Note 4 of the Notes to the Consolidated Financial Statements for additional information.

[0001571996-17-000004:notes:58]
SecureWorks Initial Public Offering — On April 27, 2016, SecureWorks Corp. ("SecureWorks") completed a registered underwritten initial public offering ("IPO") of its Class A common stock.  As of February 3, 2017, the Company held approximately 87.5% of the outstanding equity interest in SecureWorks.  The results of the SecureWorks operations are included in other businesses.  See Note 16 and Note 22 of the Notes to the Consolidated Financial Statements for more information.

[0001571996-17-000004:notes:59]
Going-Private Transaction — On October 29, 2013, Dell was acquired by Denali Holding Inc. (which changed its name to Dell Technologies Inc. on August 25, 2016) in a merger transaction pursuant to an agreement and plan of merger, dated as of February 5, 2013, as amended.  Dell Technologies is a Delaware corporation owned by Michael S. Dell and a separate property trust for the benefit of Mr. Dell's wife (the "MD Stockholders"), investment funds affiliated with Silver Lake Partners (the "SLP Stockholders"), investment funds affiliated with MSD Partners, L.P. (the "MSDC Stockholders"), members of Dell Technologies' management, and other investors.  Mr. Dell serves as Chairman and Chief Executive Officer of Dell Technologies.

[0001571996-17-000004:notes:60]
Basis of Presentation — These Consolidated Financial Statements have been prepared in accordance with accounting principles generally accepted in the United States of America ("GAAP").

[0001571996-17-000004:notes:61]
As a result of the EMC merger transaction completed on September 7, 2016, the Company's results for the fiscal periods reflected in these Consolidated Financial Statements are not directly comparable.  The results of the businesses acquired in the EMC merger transaction (the "acquired businesses") are included in the consolidated results of Dell Technologies for the fiscal year ended February 3, 2017, and represent the results of the acquired businesses from September 7, 2016, the date of the EMC merger transaction, through February 3, 2017, the end of the fiscal year of Dell Technologies.  The results of the acquired businesses are reported on the basis of Dell Technologies' fiscal year end to align with the fiscal periods for which Dell Technologies reports its results.

[0001571996-17-000004:notes:62]
The Dell Technologies balance sheet reflects the full consolidation of EMC's assets and liabilities as a result of the close of the EMC merger transaction on September 7, 2016.  The Company's purchase accounting is substantially complete.


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0001571996-17-000004:notes:63]
All highly liquid investments, including credit card receivables due from banks, with original maturities of 90 days or less at date of purchase, are reported at fair value and are considered to be cash equivalents.  All other investments not considered to be cash equivalents are separately categorized as investments.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001571996-17-000004:notes:64]
COMMITMENTS AND CONTINGENCIES

[0001571996-17-000004:notes:65]
Lease Commitments — The Company leases property and equipment, manufacturing facilities, and office space under non-cancelable leases.  Certain of these leases obligate the Company to pay taxes, maintenance, and repair costs.  At February 3, 2017, future minimum lease payments under these non-cancelable leases were as follows: $443 million in Fiscal 2018; $352 million in Fiscal 2019; $267 million in Fiscal 2020; $207 million in Fiscal 2021; $148 million in Fiscal 2022; and $739 million thereafter.

[0001571996-17-000004:notes:66]
The amount of the future lease commitments after Fiscal 2022 is primarily for the ground leases on VMware's Palo Alto, California headquarter facilities, which expire in Fiscal 2047.

[0001571996-17-000004:notes:67]
For the fiscal years ended February 3, 2017, January 29, 2016, and January 30, 2015, rent expense under all leases totaled $279 million, $91 million, and $110 million, respectively.

[0001571996-17-000004:notes:68]
Purchase Obligations — The Company has contractual obligations to purchase goods or services, which specify significant terms, including fixed or minimum quantities to be purchased; fixed, minimum, or variable price provisions; and the approximate timing of the transaction.  As of February 3, 2017, the Company had $2,279 million, $133 million, and $86 million in purchase obligations for Fiscal 2018, Fiscal 2019, and Fiscal 2020 and thereafter, respectively.

[0001571996-17-000004:notes:69]
Legal Matters — The Company is involved in various claims, suits, assessments, investigations, and legal proceedings that arise from time to time in the ordinary course of its business, including those identified below, consisting of matters involving consumer, antitrust, tax, intellectual property, and other issues on a global basis.  The Company accrues a liability when it believes that it is both probable that a liability has been incurred and that it can reasonably estimate the amount of the loss.  The Company reviews these accruals at least quarterly and adjusts them to reflect ongoing negotiations, settlements, rulings, advice of legal counsel, and other relevant information.  To the extent new information is obtained and the Company's views on the probable outcomes of claims, suits, assessments, investigations, or legal proceedings change, changes in the Company's accrued liabilities would be recorded in the period in which such determination is made.  For some matters, the amount of liability is not probable or the amount cannot be reasonably estimated and therefore accruals have not been made.  The following is a discussion of the Company's significant legal matters and other proceedings:

[0001571996-17-000004:notes:70]
EMC Merger Litigation — The Company, Dell, and Universal Acquisition Co. ("Universal") were named as defendants in fifteen putative class-action lawsuits brought by purported EMC shareholders and VMware stockholders challenging the proposed merger between the Company, Dell, and Universal on the one hand, and EMC on the other (the "EMC merger").  Those suits are captioned as follows:

[0001571996-17-000004:notes:71]
| Case | Court | Filing Date |
| 1. | IBEW Local No. 129 Benefit Fund v. Tucci,Civ. No. 1584-3130-BLS1 | Mass. Superior Court, Suffolk County | 10/15/2015 |
| 2. | Barrett v. Tucci,Civ. No. 15-6023-A | Mass. Superior Court, Middlesex County | 10/16/2015 |
| 3. | Graulich v. Tucci,Civ. No. 1584-3169-BLS1 | Mass. Superior Court, Suffolk County | 10/19/2015 |
| 4. | Vassallo v. EMC Corp.,Civ. No. 1584-3173-BLS1 | Mass. Superior Court, Suffolk County | 10/19/2015 |
| 5. | City of Miami Police Relief & Pension Fund v. Tucci,Civ. No. 1584-3174-BLS1 | Mass. Superior Court, Suffolk County | 10/19/2015 |
| 6. | Lasker v. EMC Corp.,Civ. No. 1584-3214-BLS1 | Mass. Superior Court, Suffolk County | 10/23/2015 |
| 7. | Walsh v. EMC Corp.,Civ. No. 15-13654 | U.S. District Court,District of Massachusetts | 10/27/2015 |
| 8. | Local Union No. 373 U.A. Pension Plan v. EMC Corp.,Civ. No. 1584-3253-BLS1 | Mass. Superior Court, Suffolk County | 10/28/2015 |
| 9. | City of Lakeland Emps.' Pension & Ret. Fund v. Tucci,Civ. No. 1584-3269-BLS1 | Mass. Superior Court, Suffolk County | 10/28/2015 |
| 10. | Ma v. Tucci,Civ. No. 1584-3281-BLS1 | Mass. Superior Court, Suffolk County | 10/29/2015 |
| 11. | Stull v. EMC Corp.,Civ. No. 15-13692 | U.S. District Court,District of Massachusetts | 10/30/2015 |
| 12. | Jacobs v. EMC Corp.,Civ. No. 15-6318-H | Mass. Superior Court, Middlesex County | 11/12/2015 |
| 13. | Ford v. VMware, Inc.,C.A. No. 11714-VCL | Delaware Chancery Court | 11/17/2015 |
| 14. | Pancake v. EMC Corp.,Civ. No. 16-10040 | U.S. District Court,District of Massachusetts | 1/11/2016 |
| 15. | Booth Family Trust v. EMC Corp.,Civ. No. 16-10114 | U.S. District Court,District of Massachusetts | 1/26/2016 |

[0001571996-17-000004:notes:72]
The fifteen lawsuits sought, among other things, injunctive relief enjoining the EMC merger, rescission of the EMC merger if consummated, an award of fees and costs, and/or an award of damages.

[0001571996-17-000004:notes:73]
The complaints in the IBEW, Barrett, Graulich, Vassallo, City of Miami, Lasker, Local Union No. 373, City of Lakeland, and Ma actions generally allege that the EMC directors breached their fiduciary duties to EMC shareholders in connection with the EMC merger by, among other things, failing to maximize shareholder value and agreeing to provisions in the EMC merger agreement that discouraged competing bids.  After consolidating the nine complaints, by decision dated December 7, 2015, the Business Litigation Session of the Suffolk County Superior Court in Massachusetts dismissed all nine complaints for failure to make a demand on the EMC board of directors.  Three of the nine plaintiffs in the consolidated actions appealed the judgment dismissing their complaints.  The Massachusetts Supreme Judicial Court granted an application for direct appellate review, and heard oral argument on the appeal on November 7, 2016.  On March 6, 2017, the Supreme Judicial Court issued a decision affirming the dismissal.  This decision terminates the consolidated actions.

[0001571996-17-000004:notes:74]
The complaints in the Walsh, Stull, Pancake, and Booth actions allege that the EMC directors breached their fiduciary duties to EMC shareholders in connection with the EMC merger by, among other things, failing to maximize shareholder value and agreeing to provisions in the EMC merger agreement that discouraged competing bids.  The complaints generally further allege that the preliminary SEC Form S-4 filed by the Company on December 14, 2015 in connection with the transaction contained material misstatements and omissions, in violation of Section 14(a) of the Securities Exchange Act of 1934 (the "Exchange Act") and SEC Rule 14a-9 promulgated thereunder and/or that the Company, Dell, and Universal acted as controlling persons of EMC under Section 20(a) of the Exchange Act.  On June 6, 2016, the Securities and Exchange Commission declared effective the Company's registration statement on Form S-4 relating to the EMC merger (the "SEC Form S-4"), including the amendments thereto.  On June 17, 2016, the parties to the Walsh, Stull, Pancake, and Booth actions submitted to the Court a Stipulation and Proposed Order Dismissing Action and Retaining Jurisdiction to Determine Plaintiffs' Counsel's Application for an Award of Attorneys' Fees and Reimbursement of Expenses.  In the stipulation, the plaintiffs represented to the Court that they believe sufficient information had been disclosed to warrant dismissal of the actions as moot in light of the disclosures in the SEC Form S-4, including the amendments thereto.  On October 25, 2016, following an agreement between the parties with respect to attorneys' fees and expenses, the Court entered an order terminating the four actions for all purposes.

[0001571996-17-000004:notes:75]
The amended complaints in the Jacobs and Ford actions allege that EMC, as the majority stockholder of VMware, Inc. ("VMware"), and the individual defendants, who are directors of EMC, VMware, or both, breached their fiduciary duties to minority stockholders of VMware in connection with the proposed EMC merger by allegedly entering into or approving a merger that favors the interests of EMC and Dell at the expense of the minority stockholders.  The plaintiffs in the Jacobs action also brought suit against the Company, Dell, and Universal as alleged aiders and abettors.  Effective December 2, 2016, the parties entered into an agreement to resolve the Jacobs action, pursuant to which the plaintiff voluntarily dismissed the action with prejudice.  Under the operative amended complaint in the Ford action, the plaintiffs also brought suit against the Company and Dell for alleged breach of fiduciary duties to VMware and its stockholders, and against the Company, Dell, and Universal for aiding and abetting the alleged breach of fiduciary duties by EMC and VMware's directors.  Certain defendants filed motions to dismiss the amended complaint on June 21, 2016.  A hearing on those motions was held on February 3, 2017.  No trial date has been set in the Ford action, and the outcome is uncertain.  An adverse judgment for monetary damages in the Ford matter could have an adverse effect on the Company's operations.

[0001571996-17-000004:notes:76]
Appraisal Proceedings — Holders of shares of Dell common stock who did not vote on September 12, 2013 in favor of the proposal to adopt the amended going-private transaction agreement and who properly demanded appraisal of their shares and who otherwise comply with the requirements of Section 262 of the Delaware General Corporate Law ("DGCL") are entitled to seek appraisal for, and obtain payment in cash for the judicially determined "fair value" (as defined pursuant to Section 262 of the DGCL) of, their shares in lieu of receiving the going-private transaction consideration.  Dell initially recorded a liability of $13.75 for each share with respect to which appraisal has been demanded and as to which the demand has not been withdrawn, together with interest at the statutory rate discussed below.  As of February 3, 2017, this liability was approximately $129 million, compared to approximately $593 million as of January 29, 2016, as the Company settled, during the fiscal year ended February 3, 2017, with certain funds affiliated with T. Rowe Price on the approximately 31,653,905 shares held by the funds.  Also during the fiscal year ended February 3, 2017, the Court of Chancery ruled that the fair value of the appraisal shares as of October 29, 2013, the date on which the going-private transaction became effective, was $17.62 per share.  This ruling would entitle the holders of the remaining 5,505,730 shares subject to the appraisal proceedings to $17.62 per share, plus interest at a statutory rate, compounded quarterly.  On November 21, 2016, the Court of Chancery entered final judgment in the appraisal action.  On November 22, 2016, Dell filed a notice of appeal to the Delaware Supreme Court.  That appeal is pending.  The Company believes it was adequately reserved for the appraisal proceedings as of February 3, 2017.

[0001571996-17-000004:notes:77]
Securities Litigation — On May 22, 2014, a securities class action seeking compensatory damages was filed in the United States District Court for the Southern District of New York, captioned the City of Pontiac Employee Retirement System vs. Dell Inc. et. al. (Case No. 1:14-cv-03644).  The action names as defendants Dell Inc. and certain current and former executive officers, and alleges that Dell made false and misleading statements about Dell's business operations and products between February 22, 2012 and May 22, 2012, which resulted in artificially inflated stock prices.  The case was transferred to the United States District Court for the Western District of Texas, where the defendants filed a motion to dismiss.  On September 16, 2016, the Court denied the motion to dismiss and the case is proceeding with discovery.  The defendants believe the claims asserted are without merit and the risk of material loss is remote.

[0001571996-17-000004:notes:78]
Copyright Levies — The Company's obligation to collect and remit copyright levies in certain European Union ("EU") countries may be affected by the resolution of legal proceedings pending in Germany against various companies, including Dell's German subsidiary, and elsewhere in the EU against other companies in Dell's industry.  The plaintiffs in those proceedings, some of which are described below, generally seek to impose or modify the levies with respect to sales of such equipment as multifunction devices, phones, personal computers, and printers, alleging that such products enable the copying of copyrighted materials.  Some of the proceedings also challenge whether the levy schemes in those countries comply with EU law.  Certain EU member countries that do not yet impose levies on digital devices are expected to implement legislation to enable them to extend existing levy schemes, while some other EU member countries are expected to limit the scope of levy schemes and their applicability in the digital hardware environment.  Dell, other companies, and various industry associations have opposed the extension of levies to the digital environment and have advocated alternative models of compensation to rights holders.  The Company continues to collect levies in certain EU countries where it has determined that based on local laws it is probable that it has a payment obligation.  The amount of levies is generally based on the number of products sold and the per-product amounts of the levies, which vary.  The Company accrues a liability when it believes that it is both probable that a loss has been incurred and when it can reasonably estimate the amount of the loss.

[0001571996-17-000004:notes:79]
On December 29, 2005, Zentralstelle für private Überspielungsrechte ("ZPÜ"), a joint association of various German collecting societies, instituted arbitration proceedings against Dell's German subsidiary before the Board of Arbitration at the German Patent and Trademark Office in Munich, and subsequently filed a lawsuit in the German Regional Court in Munich on February 21, 2008, seeking levies to be paid on each personal computer sold by Dell in Germany through the end of calendar year 2007.  On December 23, 2009, ZPÜ and the German industry association, BCH, reached a settlement regarding audio-video copyright levy litigation (with levies ranging from €3.15 to €13.65 per unit).  Dell joined this settlement on February 23, 2010, and has paid the amounts due under the settlement.  On March 25, 2014, ZPÜ and Dell reached a settlement for levies to be paid on each personal computer sold for the period of January 2, 2011 through December 31, 2016.  The amount of the settlement is not material to the Company.  The amount of any levies payable after calendar year 2016, as well as the Company's ability to recover such amounts through increased prices, remains uncertain.

[0001571996-17-000004:notes:80]
German courts are also considering a lawsuit originally filed in July 2004 by VG Wort, a German collecting society representing certain copyright holders, against Hewlett-Packard Company in the Stuttgart Civil Court seeking levies on printers, and a lawsuit originally filed in September 2003 by the same plaintiff against Fujitsu Siemens Computer GmbH in Munich Civil Court in Munich, Germany seeking levies on personal computers.  In each case, the civil and appellate courts held that the subject classes of equipment were subject to levies.  In July 2011, the German Federal Supreme Court, to which the lower court holdings have been appealed, referred each case to the Court of Justice of the European Union, submitting a number of legal questions on the interpretation of the European Copyright Directive which the German Federal Supreme Court deems necessary for its decision.  In August 2014, the German Supreme Court delivered an opinion ruling that printers and personal computers are subject to levies, and referred the case back to the Court of Appeals.  Dell joined the industry settlement in the Fujitsu Siemens case, and Dell believes it has no remaining material obligations in either case.

[0001571996-17-000004:notes:81]
Proceedings seeking to impose or modify copyright levies for sales of digital devices also have been instituted in courts in other EU member states.  Even in countries where Dell is not a party to such proceedings, decisions in those cases could impact Dell's business and the amount of copyright levies Dell may be required to collect.

[0001571996-17-000004:notes:82]
The ultimate resolution of these proceedings and the associated financial impact to the Company, if any, including the number of units potentially affected, the amount of levies imposed, and the ability of the Company to recover such amounts, remain uncertain at this time.  Should the courts determine there is liability for previous units shipped beyond the amount of levies the Company has collected or accrued, the Company would be liable for such incremental amounts.  Recovery of any such amounts from others by the Company would be possible only on future collections related to future shipments.

[0001571996-17-000004:notes:83]
Other Litigation — The various legal proceedings in which Dell is involved include commercial litigation and a variety of patent suits.  In some of these cases, Dell is the sole defendant.  More often, particularly in the patent suits, Dell is one of a number of defendants in the electronics and technology industries.  Dell is actively defending a number of patent infringement suits, and several pending claims are in various stages of evaluation.  While the number of patent cases varies over time, Dell does not currently anticipate that any of these matters will have a material adverse effect on its business, financial condition, results of operations, or cash flows.

[0001571996-17-000004:notes:84]
As of February 3, 2017, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for these or other proceedings or matters has been incurred.  However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company's business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters.  Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company's business, financial condition, results of operations, or cash flows will depend on a number of variables, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.

[0001571996-17-000004:notes:85]
Indemnifications — In the ordinary course of business, the Company enters into contractual arrangements under which it may agree to indemnify the third party to such arrangements from any losses incurred relating to the services it performs on behalf of the Company or for losses arising from certain events as defined in the particular contract, such as litigation or claims relating to past performance.  Such indemnification obligations may not be subject to maximum loss clauses.  Historically, payments related to these indemnifications have not been material to the Company.

[0001571996-17-000004:notes:86]
In connection with the divestitures discussed in Note 4 of the Notes to the Consolidated Financial Statements, the Company has indemnified the purchasers of businesses for the occurrence of specified events.  The Company does not currently believe that contingent obligations to provide indemnification in connection with these divestitures will have a material adverse effect on the Company.

[0001571996-17-000004:notes:87]
Certain Concentrations — The Company maintains cash and cash equivalents, derivatives, and certain other financial instruments with various financial institutions that potentially subject it to concentration of credit risk.  As part of its risk management processes, the Company performs periodic evaluations of the relative credit standing of these financial institutions.  The Company has not sustained material credit losses from instruments held at these financial institutions.  Further, the Company does not anticipate nonperformance by any of the counterparties.

[0001571996-17-000004:notes:88]
The Company markets and sells its products and services to large corporate clients, governments, and health care and education accounts, as well as to small and medium-sized businesses and individuals.  No single customer accounted for more than 10% of the Company's consolidated net revenue during the fiscal year ended February 3, 2017, January 29, 2016, or January 30, 2015.

[0001571996-17-000004:notes:89]
The Company utilizes a limited number of contract manufacturers who assemble a portion of its products.  The Company may purchase components from suppliers and sell those components to the contract manufacturers, thereby creating receivable balances from the contract manufacturers.  The agreements with the majority of the contract manufacturers allow the Company a legal right to offset its payables against these receivables, thus mitigating the credit risk wholly or in part.  Receivables from four contract manufacturers represented the majority of the gross non-trade receivables of $2.7 billion and $2.6 billion as of February 3, 2017 and January 29, 2016, respectively, of which $2.2 billion and $2.3 billion as of February 3, 2017 and January 29, 2016, respectively, have been offset against the corresponding payables.  The portion of receivables not offset against payables is included in other current assets in the Consolidated Statement of Financial Position.  The Company does not reflect the sale of the components in revenue and does not recognize any profit on the component sales until the related products are sold.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock

[0001571996-17-000004:notes:90]
The Company is subject to the possibility of various losses arising in the ordinary course of business.  The Company considers the likelihood of loss or impairment of an asset or the incurrence of a liability, as well as the Company's ability to reasonably estimate the amount of loss, in determining loss contingencies.  An estimated loss contingency is accrued when it is probable that an asset has been impaired or a liability has been incurred and the amount of loss can be reasonably estimated.  The Company regularly evaluates current information available to determine whether such accruals should be adjusted and whether new accruals are required.

[0001571996-17-000004:notes:91]
The Company accrues a liability when it believes that it is both probable that a liability has been incurred and that it can reasonably estimate the amount of the loss.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001571996-17-000004:notes:92]
ACCUMULATED OTHER COMPREHENSIVE LOSS

[0001571996-17-000004:notes:93]
Accumulated other comprehensive loss is presented in stockholders' equity in the Consolidated Statements of Financial Position and consists of amounts related to foreign currency translation adjustments, unrealized net gains (losses) on investments, unrealized net gains (losses) on cash flow hedges, and actuarial net gains (losses) from pension and other postretirement plans.

[0001571996-17-000004:notes:94]
The following table presents changes in accumulated other comprehensive loss, net of tax, by the following components for the periods indicated:

[0001571996-17-000004:notes:95]
|  | Foreign Currency Translation Adjustments |  | Investments |  | Cash Flow Hedges |  | Pension and Other Postretirement Plans |  | Accumulated Other Comprehensive Loss |
|  | (in millions) |
| Balances as of January 30, 2015 | $ | (220 | ) |  | $ | — |  |  | $ | 249 |  |  | $ | — |  |  | $ | 29 |  |
| Other comprehensive income (loss) before reclassifications | (138 | ) |  | — |  |  | 152 |  |  | — |  |  | 14 |  |
| Amounts reclassified from accumulated other comprehensive loss | — |  |  | — |  |  | (367 | ) |  | — |  |  | (367 | ) |
| Total change for the period | (138 | ) |  | — |  |  | (215 | ) |  | — |  |  | (353 | ) |
| Balances as of January 29, 2016 | (358 | ) |  | — |  |  | 34 |  |  | — |  |  | (324 | ) |
| Other comprehensive income (loss) before reclassifications | (254 | ) |  | (17 | ) |  | 20 |  |  | 19 |  |  | (232 | ) |
| Amounts reclassified from accumulated other comprehensive loss | — |  |  | 1 |  |  | (43 | ) |  | — |  |  | (42 | ) |
| Total change for the period | (254 | ) |  | (16 | ) |  | (23 | ) |  | 19 |  |  | (274 | ) |
| Less: Change in comprehensive loss attributable to non-controlling interests | — |  |  | (3 | ) |  | — |  |  | — |  |  | (3 | ) |
| Balances as of February 3, 2017 | $ | (612 | ) |  | $ | (13 | ) |  | $ | 11 |  |  | $ | 19 |  |  | $ | (595 | ) |

[0001571996-17-000004:notes:96]
Amounts related to investments are reclassified to net income when gains and losses are realized.  See Note 5 and Note 6 of the Notes to the Consolidated Financial Statements for more information on the Company's investments.  Amounts related to the Company's cash flow hedges are reclassified to net income during the same period in which the items being hedged are recognized in earnings.  In addition, any hedge ineffectiveness related to cash flow hedges is recognized currently in net income.  See Note 9 of the Notes to the Consolidated Financial Statements for more information on the Company's derivative instruments.

[0001571996-17-000004:notes:97]
The following table presents reclassifications out of accumulated other comprehensive loss, net of tax, to net income (loss) for the periods presented:

[0001571996-17-000004:notes:98]
|  | Fiscal Year Ended |  | Fiscal Year Ended |
|  | February 3, 2017 |  | January 29, 2016 |
|  | Investments |  | Cash Flow Hedges |  | Total |  | Investments |  | Cash Flow Hedges |  | Total |
|  | (in millions) |
| Total reclassifications, net of tax: |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue | $ | — |  |  | $ | 57 |  |  | $ | 57 |  |  | $ | — |  |  | $ | 328 |  |  | $ | 328 |  |
| Cost of net revenue | — |  |  | (13 | ) |  | (13 | ) |  | — |  |  | 40 |  |  | 40 |  |
| Interest and other, net | (1 | ) |  | (1 | ) |  | (2 | ) |  | — |  |  | (1 | ) |  | (1 | ) |
| Total reclassifications, net of tax | $ | (1 | ) |  | $ | 43 |  |  | $ | 42 |  |  | $ | — |  |  | $ | 367 |  |  | $ | 367 |  |


## us-gaap:ConsolidationLessThanWhollyOwnedSubsidiaryParentOwnershipInterestEffectsOfChangesNetTextBlock

[0001571996-17-000004:notes:99]
The effect of changes in the Company's ownership interest in SecureWorks, VMware, and Pivotal on the Company's equity was as follows:

[0001571996-17-000004:notes:100]
|  | Fiscal Year Ended |
|  | February 3, 2017 |
|  | (in millions) |
| Net loss attributable to Dell Technologies Inc. | $ | (1,672 | ) |
| Transfers (to) from the non-controlling interests: |  |
| Increase in Dell Technologies' additional paid-in-capital for equity issuances | 269 |  |
| Decrease in Dell Technologies' additional paid-in-capital for equity issuances and other equity activity | (251 | ) |
| Net transfers from non-controlling interests | 18 |  |
| Change from net loss attributable to Dell Technologies Inc. and transfers to/from the non-controlling interests | $ | (1,654 | ) |


## us-gaap:ConsolidationPolicyTextBlock

[0001571996-17-000004:notes:101]
These consolidated financial statements include the accounts of Dell Technologies and its wholly-owned subsidiaries, as well as the accounts of SecureWorks, VMware, Inc., and Pivotal Software, Inc. ("Pivotal"), companies which are majority-owned by Dell Technologies.  All intercompany transactions have been eliminated.


## us-gaap:DebtDisclosureTextBlock

[0001571996-17-000004:notes:102]
DEBT

[0001571996-17-000004:notes:103]
The following table summarizes the Company's outstanding debt as of the dates indicated:

[0001571996-17-000004:notes:104]
|  | February 3, 2017 |  | January 29, 2016 |
|  | (in millions) |
| Secured Debt |  |  |  |
| Structured financing debt | $ | 3,464 |  |  | $ | 3,411 |  |
| 3.75% Floating rate due October 2018 ("Term Loan C Facility") | — |  |  | 1,003 |  |
| 4.00% Floating rate due April 2020 ("Term Loan B Facility") | — |  |  | 4,329 |  |
| 4.00% Floating rate due April 2020 ("Term Loan Euro Facility") | — |  |  | 891 |  |
| 5.625% due October 2020 ("Senior First Lien Notes") | — |  |  | 1,400 |  |
| EMC merger transaction financing issued on September 7, 2016 ("Senior Secured Credit Facilities"): |  |  |  |
| 4.03% Term Loan B Facility due September 2023 | 4,987 |  |  | — |  |
| 2.78% Term Loan A-1 Facility due December 2018 | 600 |  |  | — |  |
| 3.03% Term Loan A-2 Facility due September 2021 | 3,876 |  |  | — |  |
| 2.78% Term Loan A-3 Facility due December 2018 | 1,800 |  |  | — |  |
| 2.78% Revolving Credit Facility due September 2021 | 375 |  |  | — |  |
| EMC merger transaction financing issued on June 1, 2016 ("First Lien Notes"): |  |  |  |
| 3.48% due June 2019 | 3,750 |  |  | — |  |
| 4.42% due June 2021 | 4,500 |  |  | — |  |
| 5.45% due June 2023 | 3,750 |  |  | — |  |
| 6.02% due June 2026 | 4,500 |  |  | — |  |
| 8.10% due June 2036 | 1,500 |  |  | — |  |
| 8.35% due June 2046 | 2,000 |  |  | — |  |
| Unsecured Notes and Debentures |  |  |  |
| Notes and debentures issued prior to going-private transaction: |  |  |  |
| 3.10% due April 2016 | — |  |  | 400 |  |
| 5.65% due April 2018 | 500 |  |  | 500 |  |
| 5.875% due June 2019 | 600 |  |  | 600 |  |
| 4.625% due April 2021 | 400 |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 265 |  |  | 265 |  |
| EMC merger transaction financing issued on June 22, 2016 ("Senior Notes"): |  |  |  |
| 5.875% due June 2021 | 1,625 |  |  | — |  |
| 7.125% due June 2024 | 1,625 |  |  | — |  |
| Existing EMC notes assumed as part of the EMC merger transaction ("EMC Notes"): |  |  |  |
| 1.875% due June 2018 | 2,500 |  |  | — |  |
| 2.650% due June 2020 | 2,000 |  |  | — |  |
| 3.375% due June 2023 | 1,000 |  |  | — |  |
| Bridge Facilities |  |  |  |
| 2.53% Margin Bridge Facility due September 2017 | 2,500 |  |  | — |  |
| 2.53% VMware Note Bridge Facility due September 2017 | 1,500 |  |  | — |  |
| Other | 51 |  |  | 93 |  |
| Total debt, principal amount | $ | 50,356 |  |  | $ | 13,980 |  |

[0001571996-17-000004:notes:105]
|  | February 3, 2017 |  | January 29, 2016 |
|  | (in millions) |
| Total debt, principal amount | $ | 50,356 |  |  | $ | 13,980 |  |
| Unamortized discount, net of unamortized premium | (284 | ) |  | (221 | ) |
| Debt issuance costs | (682 | ) |  | (128 | ) |
| Total debt, carrying value | $ | 49,390 |  |  | $ | 13,631 |  |
| Total short-term debt, carrying value | $ | 6,329 |  |  | $ | 2,981 |  |
| Total long-term debt, carrying value | $ | 43,061 |  |  | $ | 10,650 |  |

[0001571996-17-000004:notes:106]
To finance the EMC merger transaction, the Company issued $45.9 billion in new debt, which included proceeds from the sale of the First Lien Notes and the Senior Unsecured Notes in June 2016, as well as borrowings under the Senior Secured Credit Facilities (including the Revolving Credit Facility), the Asset Sale Bridge Facility, the Margin Bridge Facility, and the VMware Note Bridge Facility at the closing of the transaction.

[0001571996-17-000004:notes:107]
Upon the closing of the EMC merger transaction, the Company repaid and terminated the ABL Credit Facility and the Term Loan Facilities obtained in connection with the going-private transaction, and redeemed the Senior First Lien Notes issued in connection with the going-private transaction.

[0001571996-17-000004:notes:108]
Additionally, during the fiscal year ended February 3, 2017, the Company repaid $1.6 billion of the Revolving Credit Facility, $2.2 billion of the Asset Sale Bridge Facility, and $3.1 billion of the Term Loan A-1 Facility, all of which were obtained in connection with the EMC merger transaction.  During the fiscal year ended February 3, 2017, the Company also repaid $0.4 billion of maturing Unsecured Notes and Debentures.  The Company incurred approximately $337 million of other expenses related to debt extinguishments and new borrowings during the fiscal year ended February 3, 2017.

[0001571996-17-000004:notes:109]
Senior Secured Credit Facilities — At the closing of the EMC merger transaction on September 7, 2016, the Company entered into a credit agreement (the "Senior Secured Credit Agreement") that provides for senior secured credit facilities (the "Senior Secured Credit Facilities") in the aggregate principal amount of $17.6 billion comprising (a) term loan facilities and (b) a senior secured Revolving Credit Facility, which includes capacity for up to $0.5 billion of letters of credit and for borrowings of up to $0.4 billion under swing-line loans.  Dell International L.L.C. ("Dell International") and EMC are the borrowers under the Senior Secured Credit Facilities.  As of February 3, 2017, available borrowings under the Revolving Credit Facility totaled $2.7 billion.  The Senior Secured Credit Facilities provide that the borrowers have the right at any time, subject to customary conditions, to request incremental term loans or incremental revolving commitments in an aggregate principal amount of up to (a) the greater of (i) $10.0 billion and (ii) 100% of Consolidated EBITDA (as defined in the Senior Secured Credit Agreement) plus (b) an amount equal to voluntary prepayments of the term loan facilities and the Revolving Credit Facility, subject to certain requirements, plus (c) an additional unlimited amount subject to a pro forma net first lien leverage ratio of 3.25:1.0.

[0001571996-17-000004:notes:110]
Borrowings under the Senior Secured Credit Facilities bear interest at a rate per annum equal to an applicable margin, plus, at the borrowers' option, either (a) a base rate, which, under the Term Loan B Facility, is subject to an interest rate floor of 1.75% per annum, and under all other borrowings is subject to an interest rate floor of 0% per annum, or (b) a London interbank offered rate ("LIBOR"), which, under the Term Loan B Facility, is subject to an interest rate floor of 0.75% per annum, and under all other borrowings is subject to an interest rate floor of 0% per annum.  The applicable margin under the Term Loan B Facility is subject to reduction based on a first lien leverage ratio test.  The applicable margins under the Term Loan A-1 Facility, the Term Loan A-2 Facility, the Term Loan A-3 Facility, and the Revolving Credit Facility vary based upon a corporate ratings-based pricing schedule.  Interest is payable, in the case of loans bearing interest based on LIBOR, at the end of each interest period (but at least every three months), in arrears and, in the case of loans bearing interest based on the base rate, quarterly in arrears.

[0001571996-17-000004:notes:111]
The Term Loan A-1 Facility will mature on December 31, 2018 and has no amortization.  The Term Loan A-2 Facility will mature on September 7, 2021 and amortizes in equal quarterly installments in aggregate annual amounts equal to 5% of the original principal amount in each of the first two years after the date of the closing of the EMC merger transaction, 10% of the original principal amount in each of the third and fourth years after the date of the closing of the EMC merger transaction, and 70% of the original principal amount in the fifth year after the date of the closing of the EMC merger transaction.  The Term Loan A-3 Facility will mature on December 31, 2018 and has no amortization.  The Term Loan B Facility will mature on September 7, 2023 and amortizes in equal quarterly installments in aggregate annual amounts equal to 1% of the original principal amount.  The Revolving Credit Facility will mature on September 7, 2021 and has no amortization.  The Term Loan A-1 and A-3 Facilities require the borrowers to prepay outstanding borrowings under these facilities with 100% of the net cash proceeds of certain non-ordinary course asset sales or dispositions after fully prepaying the Asset Sale Bridge Facility.  The borrowers may voluntarily repay outstanding loans under the term loan facilities and the Revolving Credit Facility at any time without premium or penalty, other than customary "breakage" costs.

[0001571996-17-000004:notes:112]
All obligations of the borrowers under the Senior Secured Credit Facilities and certain swap agreements, cash management arrangements, and certain letters of credit provided by any lender or agent party to the Senior Secured Credit Facilities or any of their affiliates and certain other persons are guaranteed by Denali Intermediate Inc. ("Denali Intermediate"), Dell, certain subsidiaries of Denali Intermediate, and each existing and subsequently acquired or organized direct or indirect material wholly-owned domestic restricted subsidiary of Dell, with customary exceptions.  All such obligations under the Senior Secured Credit Facilities (and the guarantees thereof) and certain swap agreements, cash management arrangements, and certain letters of credit provided by any lender or agent party to the Senior Secured Credit Facilities or any of its affiliates and certain other persons are secured by (a) a first-priority security interest in certain tangible and intangible assets of the borrowers and the guarantors and (b) a first-priority pledge of 100% of the capital stock of the borrowers, Dell and each wholly-owned material restricted subsidiary of the borrowers and the guarantors, in each case subject to certain thresholds, exceptions and permitted liens.

[0001571996-17-000004:notes:113]
On November 8, 2016, the Company applied cash proceeds from the Dell Services and the DSG divestitures and other cash to repay $2.1 billion principal amount of the Term Loan A-1 Facility, without premium or penalty, and accrued and unpaid interest thereon.  On January 31, 2017, the Company applied cash proceeds from the ECD divestiture to repay $1.0 billion principal amount of the Term Loan A-1 Facility, without premium or penalty, and accrued and unpaid interest thereon.  During the fiscal year ended February 3, 2017, the Company also repaid approximately $1.6 billion principal amount of the Revolving Credit Facility and accrued and unpaid interest thereon.

[0001571996-17-000004:notes:114]
First Lien Notes — The senior secured notes (collectively, the "First Lien Notes") were issued on June 1, 2016 in an aggregate principal amount of $20.0 billion.  Interest on these borrowings is payable semiannually.  As of the closing of the EMC merger transaction, Dell International and EMC are the co-issuers of the First Lien Notes.  The First Lien Notes are guaranteed, subject to certain exceptions, on a joint and several basis by Dell Technologies, Denali Intermediate Inc. ("Denali Intermediate"), which is Dell's direct parent company, Dell, and Denali Intermediate's direct and indirect wholly-owned material domestic subsidiaries that guarantee the Senior Secured Credit Facilities (the "Guarantors").  The First Lien Notes are secured, on a pari passu basis with the Senior Secured Credit Facilities, on a first-priority basis by substantially all of the tangible and intangible assets of the issuers and guarantors that secure obligations under the Senior Secured Credit Facilities, including pledges of all capital stock of the issuers, of Dell, and of certain wholly-owned material subsidiaries of the issuers and the guarantors, subject to certain exceptions.

[0001571996-17-000004:notes:115]
Dell International, EMC, and the Guarantors have agreed to use commercially reasonable efforts to register with the SEC notes having terms substantially identical to the terms of the First Lien Notes as part of an offer to exchange such registered notes for the First Lien Notes.  Dell International and EMC will be obligated to pay additional interest on the First Lien Notes if they fail to consummate such an exchange offer within five years after the closing date of the EMC merger transaction.

[0001571996-17-000004:notes:116]
Senior Notes — The senior unsecured notes (collectively, the "Senior Notes") were issued on June 22, 2016 in an aggregate principal amount of $3.25 billion.  Interest on these borrowings is payable semiannually.  As of the closing of the EMC merger transaction, Dell International and EMC are the co-issuers of the Senior Notes.  The Senior Notes are guaranteed, subject to certain exceptions, on a joint and several basis, by Dell Technologies, Denali Intermediate, Dell, and Denali Intermediate's direct and indirect wholly-owned material domestic subsidiaries that guarantee the Senior Secured Credit Facilities.

[0001571996-17-000004:notes:117]
EMC Notes — On September 7, 2016, EMC had outstanding $2.5 billion aggregate principal amount of its 1.875% Notes due June 2018, $2.0 billion aggregate principal amount of its 2.650% Notes due June 2020 and $1.0 billion aggregate principal amount of its 3.375% Notes due June 2023 (collectively, the "EMC Notes"), all of which were issued pursuant to an Indenture dated as of June 6, 2013.  Interest on these borrowings is payable semiannually.  The EMC Notes remain outstanding following the closing of the EMC merger transaction.  The EMC Notes are senior unsecured obligations of EMC and are not guaranteed by any subsidiaries of EMC or by the Company or any other subsidiaries of the Company.

[0001571996-17-000004:notes:118]
Asset Sale Bridge Facility — On September 7, 2016, certain subsidiaries of the Company entered into a credit agreement providing for a senior unsecured asset sale bridge facility in an aggregate principal amount of $2.2 billion (the "Asset Sale Bridge Facility").  Borrowings under the Asset Sale Bridge Facility bore interest at a fixed rate of 4.875%.

[0001571996-17-000004:notes:119]
The Asset Sale Bridge Facility required the borrowers to prepay outstanding borrowings under the facility with 100% of the net cash proceeds of certain non-ordinary course asset sales or dispositions.  On November 8, 2016, the Company applied cash proceeds from the Dell Services and DSG divestitures to repay the outstanding $2.2 billion principal amount of the Asset Sale Bridge Facility, without premium or penalty, and accrued and unpaid interest thereon, and terminated the Asset Sale Bridge Facility and the Asset Sale Bridge Credit Agreement and related documents.

[0001571996-17-000004:notes:120]
Margin Bridge Facility — On September 7, 2016, Merger Sub and EMC entered into a credit agreement providing for a senior secured margin bridge facility in an aggregate principal amount of $2.5 billion (the "Margin Bridge Facility").  EMC is the borrower under the Margin Bridge Facility, which is secured solely by 77,033,442 shares of Class B common stock of VMware and any proceeds thereof.

[0001571996-17-000004:notes:121]
Interest under the Margin Bridge Facility is payable, at the borrower's option, either at (a) a base rate plus 0.75% per annum or (b) a LIBOR-based rate plus 1.75% per annum.  Interest is payable, in the case of loans bearing interest based on LIBOR, at the end of each interest period (but at least every three months), in arrears and, in the case of loans bearing interest based on the base rate, quarterly in arrears.

[0001571996-17-000004:notes:122]
The Margin Bridge Facility will mature on September 6, 2017 and has no amortization.  The Margin Bridge Facility requires the borrower to prepay outstanding borrowings under the Margin Bridge Facility with 100% of the net cash proceeds of any asset sale or other disposition of the pledged VMware shares.  The borrower may voluntarily repay outstanding loans under the Margin Bridge Facility at any time without premium or penalty, other than customary "breakage" costs, subject to certain minimum threshold amounts for prepayment.

[0001571996-17-000004:notes:123]
VMware Note Bridge Facility — On September 7, 2016, Merger Sub and EMC entered into a credit agreement providing for a senior secured note bridge facility in an aggregate principal amount of $1.5 billion (the "VMware Note Bridge Facility").  EMC is the borrower under the VMware Note Bridge Facility, which is secured solely by certain intercompany notes in an aggregate principal amount of $1.5 billion issued by VMware that are payable to EMC, and the proceeds thereof.

[0001571996-17-000004:notes:124]
Interest under the VMware Note Bridge Facility is payable, at the borrower's option, either at (a) a base rate plus 0.75% per annum or (b) a LIBOR-based rate plus 1.75% per annum.  Interest is payable, in the case of loans bearing interest based on LIBOR, at the end of each interest period (but at least every three months), in arrears and, in the case of loans bearing interest based on the base rate, quarterly in arrears.

[0001571996-17-000004:notes:125]
The VMware Note Bridge Facility will mature on September 6, 2017 and has no amortization.  The VMware Note Bridge Facility requires the borrower to prepay outstanding borrowings under the VMware Note Bridge Facility with 100% of the net cash proceeds of any asset sale or other disposition of the pledged VMware promissory notes.  The borrower may voluntarily repay outstanding loans under the VMware Note Bridge Facility at any time without premium or penalty, other than customary "breakage" costs, subject to certain minimum threshold amounts for prepayment.

[0001571996-17-000004:notes:126]
Structured Financing Debt — As of February 3, 2017 and January 29, 2016, the Company had $3.5 billion and $3.4 billion, respectively, in outstanding structured financing debt, which was primarily related to the fixed-term lease and loan securitization programs and the revolving loan securitization programs.  See Note 7 and Note 9 of the Notes to the Consolidated Financial Statements for further discussion of the structured financing debt and the interest rate swap agreements that hedge a portion of that debt.

[0001571996-17-000004:notes:127]
Unsecured Notes and Debentures — The Company has Unsecured Notes and Debentures that were issued prior to the going-private transaction.  Interest on these borrowings is payable semiannually.  See "Senior Notes" above for a discussion of the senior unsecured notes issued in connection with the EMC merger transaction.

[0001571996-17-000004:notes:128]
Repayment and Termination of Credit Facilities — At the closing of the EMC merger transaction on September 7, 2016, the Company repaid approximately $6.1 billion of borrowings (including accrued and unpaid interest thereon) under the Company's ABL Credit Facility and Term Loan Facilities obtained in connection with the going-private transaction and terminated such credit facilities and related credit agreements and documents.

[0001571996-17-000004:notes:129]
The ABL Credit Facility provided for an asset-based senior secured revolving credit facility in an initial aggregate principal amount of approximately $2.0 billion, subject to a borrowing base consisting of certain receivables and inventory.  The Term Loan Facilities originally provided for senior secured term loan facilities consisting of a $4.7 billion Term Loan B Facility, a $1.5 billion Term Loan C Facility and a €0.7 billion Term Loan Euro Facility.

[0001571996-17-000004:notes:130]
Redemption of Senior First Lien Notes — In connection with the EMC merger transaction, the Company issued and delivered notices of conditional redemption to holders of the outstanding 5.625% Senior First Lien Notes due 2020 issued in an aggregate original principal amount of $1.5 billion in October 2013 in connection with Dell's going private transaction (the "Senior First Lien Notes") to redeem (a) $0.15 billion in aggregate principal amount of the Senior First Lien Notes at a redemption price of 103% of the principal amount thereof and (b) $1.25 billion in aggregate principal amount of the Senior First Lien Notes at a redemption price equal to 100% of the principal amount thereof plus a "make-whole" premium calculated in accordance with the indenture governing the Senior First Lien Notes, in each case, plus accrued and unpaid interest thereon to but excluding the redemption date.  Such redemption notices were conditioned upon, among other matters, the closing of the EMC merger transaction.  On September 7, 2016, substantially concurrently with the consummation of the EMC merger transaction, the Company deposited with the trustee of the Senior First Lien Notes the applicable redemption payments to fund such redemptions and thereby redeemed all of the outstanding Senior First Lien Notes.

[0001571996-17-000004:notes:131]
Aggregate Future Maturities — As of February 3, 2017, aggregate future maturities of the Company's debt were as follows:

[0001571996-17-000004:notes:132]
|  | Maturities by Fiscal Year |
|  | 2018 |  | 2019 |  | 2020 |  | 2021 |  | 2022 |  | Thereafter |  | Total |
|  | (in millions) |
| Structured Financing Debt | $ | 2,088 |  |  | $ | 1,216 |  |  | $ | 136 |  |  | $ | 22 |  |  | $ | 2 |  |  | $ | — |  |  | $ | 3,464 |  |
| Senior Secured Credit Facilities and First Lien Notes | 246 |  |  | 2,695 |  |  | 4,193 |  |  | 332 |  |  | 7,672 |  |  | 16,500 |  |  | 31,638 |  |
| Unsecured Notes and Debentures | — |  |  | 500 |  |  | 600 |  |  | — |  |  | 400 |  |  | 953 |  |  | 2,453 |  |
| Senior Notes and EMC Notes | — |  |  | 2,500 |  |  | — |  |  | 2,000 |  |  | 1,625 |  |  | 2,625 |  |  | 8,750 |  |
| Bridge Facilities | 4,000 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 4,000 |  |
| Other | 23 |  |  | 2 |  |  | — |  |  | — |  |  | — |  |  | 26 |  |  | 51 |  |
| Total maturities, principal amount | 6,357 |  |  | 6,913 |  |  | 4,929 |  |  | 2,354 |  |  | 9,699 |  |  | 20,104 |  |  | 50,356 |  |
| Associated carrying value adjustments | (28 | ) |  | (48 | ) |  | (57 | ) |  | — |  |  | (243 | ) |  | (590 | ) |  | (966 | ) |
| Total maturities, carrying value amount | $ | 6,329 |  |  | $ | 6,865 |  |  | $ | 4,872 |  |  | $ | 2,354 |  |  | $ | 9,456 |  |  | $ | 19,514 |  |  | $ | 49,390 |  |

[0001571996-17-000004:notes:133]
Covenants and Unrestricted Net Assets — The credit agreement for the Senior Secured Credit Facilities contain customary negative covenants that generally limit the ability of Denali Intermediate, Dell, and Dell's and Denali Intermediate's other restricted subsidiaries to incur debt, create liens, make fundamental changes, enter into asset sales, make certain investments, pay dividends or distribute or redeem certain equity interests, prepay or redeem certain debt, and enter into certain transactions with affiliates.  The indenture governing the Senior Notes contains customary negative covenants that generally limit the ability of Denali Intermediate, Dell, and Dell's and Denali Intermediate's other restricted subsidiaries to incur additional debt or issue certain preferred shares, pay dividends on or make other distributions in respect of capital stock or make other restricted payments, make certain investments, sell or transfer certain assets, create liens on certain assets to secure debt, consolidate, merge, sell, or otherwise dispose of all or substantially all assets, enter into certain transactions with affiliates, and designate subsidiaries as unrestricted subsidiaries.  The negative covenants under such credit agreements and indenture are subject to certain exceptions, qualifications and "baskets."  The indentures governing the First Lien Notes, the Unsecured Notes and Debentures, and the EMC Notes variously impose limitations, subject to specified exceptions, on creating certain liens, entering into sale and lease-back transactions, and entering into certain asset sales.  As of February 3, 2017, the Company had certain consolidated subsidiaries that were designated as unrestricted subsidiaries for all purposes of the applicable credit agreements and the indentures governing the First Lien Notes and the Senior Notes.  As of February 3, 2017, substantially all of the net assets of the Company's consolidated subsidiaries were restricted, with the exception of the Company's unrestricted subsidiaries, primarily VMware and SecureWorks.  The foregoing credit agreements and indentures contain customary events of default, including failure to make required payments, failure to comply with covenants, and the occurrence of certain events of bankruptcy and insolvency.

[0001571996-17-000004:notes:134]
The Term Loan A-1 Facility, the Term Loan A-2 Facility, the Term Loan A-3 Facility, and the Revolving Credit Facility are subject to a first lien net leverage ratio covenant that will be tested at the end of each fiscal quarter of Dell with respect to Dell's preceding four fiscal quarters.  The Company was in compliance with all financial covenants as of February 3, 2017.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001571996-17-000004:notes:135]
DERIVATIVE INSTRUMENTS AND HEDGING ACTIVITIES

[0001571996-17-000004:notes:136]
Derivative Instruments

[0001571996-17-000004:notes:137]
As part of its risk management strategy, the Company uses derivative instruments, primarily foreign currency forward and option contracts and interest rate swaps, to hedge certain foreign currency and interest rate exposures, respectively.

[0001571996-17-000004:notes:138]
The Company's objective is to offset gains and losses resulting from these exposures with gains and losses on the derivative contracts used to hedge the exposures, thereby reducing volatility of earnings and protecting the fair values of assets and liabilities.  For derivatives designated as cash flow hedges, the Company assesses hedge effectiveness both at the onset of the hedge and at regular intervals throughout the life of the derivative and recognizes any ineffective portion of the hedge in earnings as a component of interest and other, net.  Hedge ineffectiveness recognized in earnings was not material during the fiscal years ended February 3, 2017, January 29, 2016, and January 30, 2015.

[0001571996-17-000004:notes:139]
In connection with the EMC merger transaction, the Company acquired foreign exchange derivative instruments with a fair value of approximately $7.0 million as of the closing date of the transaction.  The portfolio of instruments is comprised of foreign currency forward and option contracts that mature at various times within 12 months.  The Company elected to leave the acquired instruments undesignated from a hedge accounting perspective.

[0001571996-17-000004:notes:140]
Foreign Exchange Risk

[0001571996-17-000004:notes:141]
The Company uses foreign currency forward and option contracts designated as cash flow hedges to protect against the foreign currency exchange rate risks inherent in its forecasted transactions denominated in currencies other than the U.S. dollar.  Hedge accounting is applied based upon the criteria established by accounting guidance for derivative instruments and hedging activities.  The risk of loss associated with purchased options is limited to premium amounts paid for the option contracts.  The risk of loss associated with forward contracts is equal to the exchange rate differential from the time the contract is entered into until the time it is settled.  The majority of these contracts typically expire in twelve months or less.

[0001571996-17-000004:notes:142]
During the fiscal years ended February 3, 2017, January 29, 2016, and January 30, 2015, the Company did not discontinue any cash flow hedges related to foreign exchange contracts that had a material impact on the Company's results of operations due to the probability that the forecasted cash flows would not occur.

[0001571996-17-000004:notes:143]
The Company uses forward contracts to hedge monetary assets and liabilities denominated in a foreign currency.  These contracts generally expire in three months or less, are considered economic hedges, and are not designated for hedge accounting.  The change in the fair value of these instruments represents a natural hedge as their gains and losses offset the changes in the underlying fair value of the monetary assets and liabilities due to movements in currency exchange rates.

[0001571996-17-000004:notes:144]
In connection with the expanded offerings of DFS in Europe, forward contracts are used to hedge financing receivables denominated in foreign currencies.  These contracts are not designated for hedge accounting and most expire within three years or less.

[0001571996-17-000004:notes:145]
Interest Rate Risk

[0001571996-17-000004:notes:146]
The Company uses interest rate swaps to hedge the variability in cash flows related to the interest rate payments on structured financing debt.  The interest rate swaps economically convert the variable rate on the structured financing debt to a fixed interest rate to match the underlying fixed rate being received on fixed-term customer leases and loans.  These contracts are not designated for hedge accounting and most expire within three years or less.

[0001571996-17-000004:notes:147]
Interest rate swaps are utilized to manage the interest rate risk, at a portfolio level, associated with DFS operations in Europe.  The interest rate swaps economically convert the fixed rate on financing receivables to a three-month Euribor floating rate basis in order to match the floating rate nature of the banks' funding pool.  These contracts are not designated for hedge accounting and most expire within three years or less.

[0001571996-17-000004:notes:148]
The Company utilizes cross currency amortizing swaps to hedge the currency and interest rate risk exposure associated with the securitization program that was established in Europe in January 2017.  The cross currency swaps combine a Euro-based interest rate swap with a British Pound or US Dollar foreign exchange forward contract in which the Company pays a fixed British Pound or US Dollar amount and receives a floating amount in Euro linked to the one-month Euribor.  The notional value of the swaps amortize in line with the expected cash flows and run off of the securitized assets.  The swaps mature within 5 years or less and are not designated for hedge accounting.

[0001571996-17-000004:notes:149]
Notional Amounts of Outstanding Derivative Instruments

[0001571996-17-000004:notes:150]
The notional amounts of the Company's outstanding derivative instruments were as follows as of the dates indicated:

[0001571996-17-000004:notes:151]
|  | February 3, 2017 |  | January 29, 2016 |
|  | (in millions) |
| Foreign Exchange Contracts |  |  |  |  |  |
| Designated as cash flow hedging instruments | $ | 3,781 |  |  | $ | 3,947 |  |
| Non-designated as hedging instruments | 2,992 |  |  | 985 |  |
| Total | $ | 6,773 |  |  | $ | 4,932 |  |
| Interest Rate Contracts |  |  |  |
| Non-designated as hedging instruments | $ | 1,251 |  |  | $ | 1,017 |  |

[0001571996-17-000004:notes:152]
Effect of Derivative Instruments on the Consolidated Statements of Financial Position and the Consolidated Statements of Income (Loss)

[0001571996-17-000004:notes:153]
| Derivatives inCash FlowHedging Relationships |  | Gain (Loss)Recognizedin AccumulatedOCI, Netof Tax, onDerivatives(Effective Portion) |  | Location of Gain (Loss)Reclassifiedfrom AccumulatedOCI into Income(Effective Portion) |  | Gain (Loss)Reclassifiedfrom AccumulatedOCI into Income(Effective Portion) |  | Location of Gain (Loss) Recognized in Income on Derivative (Ineffective Portion) |  | Gain (Loss) Recognized in Income on Derivative (Ineffective Portion) |
| (in millions) |
| For the fiscal year ended February 3, 2017 |  |  |  |  |  |  |
|  |  |  |  |  | Total net revenue |  | $ | 57 |  |  |  |  |  |
| Foreign exchange contracts |  | $ | 20 |  |  | Total cost of net revenue |  | (13 | ) |  |  |  |  |
| Interest rate contracts |  | — |  |  | Interest and other, net |  | — |  |  | Interest and other, net |  | $ | (1 | ) |
| Total |  | $ | 20 |  |  |  |  | $ | 44 |  |  |  |  | $ | (1 | ) |
| For the fiscal year ended January 29, 2016 |  |  |  |  |  |  |
|  |  |  |  |  | Total net revenue |  | $ | 328 |  |  |  |  |  |
| Foreign exchange contracts |  | $ | 152 |  |  | Total cost of net revenue |  | 40 |  |  |  |  |  |
| Interest rate contracts |  | — |  |  | Interest and other, net |  | — |  |  | Interest and other, net |  | $ | (1 | ) |
| Total |  | $ | 152 |  |  |  |  | $ | 368 |  |  |  |  | $ | (1 | ) |
| For the fiscal year ended January 30, 2015 |  |  |  |  |  |  |
|  |  |  |  |  | Total net revenue |  | $ | 163 |  |  |  |  |  |
| Foreign exchange contracts |  | $ | 427 |  |  | Total cost of net revenue |  | 15 |  |  |  |  |  |
| Interest rate contracts |  | — |  |  | Interest and other, net |  | — |  |  | Interest and other, net |  | $ | 1 |  |
| Total |  | $ | 427 |  |  |  |  | $ | 178 |  |  |  |  | $ | 1 |  |

[0001571996-17-000004:notes:154]
Fair Value of Derivative Instruments in the Consolidated Statements of Financial Position

[0001571996-17-000004:notes:155]
The Company presents its foreign exchange derivative instruments on a net basis in the Consolidated Statements of Financial Position due to the right of offset by its counterparties under master netting arrangements.  The fair value of those derivative instruments presented on a gross basis as of each date indicated below was as follows:

[0001571996-17-000004:notes:156]
|  | February 3, 2017 |
|  | Other CurrentAssets |  | Other Non-Current Assets |  | Other CurrentLiabilities |  | Other Non-CurrentLiabilities |  | TotalFair Value |
|  |  |  | (in millions) |  |  |
| Derivatives Designated as Hedging Instruments |
| Foreign exchange contracts in an asset position | $ | 41 |  |  | $ | — |  |  | $ | 17 |  |  | $ | — |  |  | $ | 58 |  |
| Foreign exchange contracts in a liability position | (19 | ) |  | — |  |  | (6 | ) |  | — |  |  | (25 | ) |
| Net asset (liability) | 22 |  |  | — |  |  | 11 |  |  | — |  |  | 33 |  |
| Derivatives not Designated as Hedging Instruments |
| Foreign exchange contracts in an asset position | 309 |  |  | 2 |  |  | 31 |  |  | — |  |  | 342 |  |
| Foreign exchange contracts in a liability position | (131 | ) |  | — |  |  | (103 | ) |  | — |  |  | (234 | ) |
| Interest rate contracts in an asset position | — |  |  | 3 |  |  | — |  |  | — |  |  | 3 |  |
| Interest rate contracts in a liability position | — |  |  | — |  |  | — |  |  | (3 | ) |  | (3 | ) |
| Net asset (liability) | 178 |  |  | 5 |  |  | (72 | ) |  | (3 | ) |  | 108 |  |
| Total derivatives at fair value | $ | 200 |  |  | $ | 5 |  |  | $ | (61 | ) |  | $ | (3 | ) |  | $ | 141 |  |
|  | January 29, 2016 |
|  | Other CurrentAssets |  | Other Non-Current Assets |  | Other CurrentLiabilities |  | Other Non-CurrentLiabilities |  | TotalFair Value |
|  |  |  | (in millions) |  |  |
| Derivatives Designated as Hedging Instruments |
| Foreign exchange contracts in an asset position | $ | 100 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 100 |  |
| Foreign exchange contracts in a liability position | (11 | ) |  | — |  |  | — |  |  | — |  |  | (11 | ) |
| Net asset (liability) | 89 |  |  | — |  |  | — |  |  | — |  |  | 89 |  |
| Derivatives not Designated as Hedging Instruments |
| Foreign exchange contracts in an asset position | 301 |  |  | 1 |  |  | — |  |  | — |  |  | 302 |  |
| Foreign exchange contracts in a liability position | (198 | ) |  | — |  |  | (5 | ) |  | (3 | ) |  | (206 | ) |
| Interest rate contracts in an asset position | — |  |  | 2 |  |  | — |  |  | — |  |  | 2 |  |
| Interest rate contracts in a liability position | — |  |  | — |  |  | — |  |  | (4 | ) |  | (4 | ) |
| Net asset (liability) | 103 |  |  | 3 |  |  | (5 | ) |  | (7 | ) |  | 94 |  |
| Total derivatives at fair value | $ | 192 |  |  | $ | 3 |  |  | $ | (5 | ) |  | $ | (7 | ) |  | $ | 183 |  |

[0001571996-17-000004:notes:157]
The following table presents the gross amounts of the Company's derivative instruments, amounts offset due to master netting agreements with the Company's various counterparties, and the net amounts recognized in the Consolidated Statements of Financial Position.

[0001571996-17-000004:notes:158]
|  | February 3, 2017 |
|  | Gross Amounts of Recognized Assets/ (Liabilities) |  | Gross Amounts Offset in the Statement of Financial Position |  | Net Amounts of Assets/ (Liabilities) Presented in the Statement of Financial Position |  | Gross Amounts not Offset in the Statement of Financial Position |  | Net Amount |
|  | Financial Instruments |  | Cash Collateral Received or Pledged |  |
|  | (in millions) |
| Derivative instruments |  |  |  |  |  |  |  |  |  |  |  |
| Financial assets | $ | 403 |  |  | $ | (198 | ) |  | $ | 205 |  |  | $ | — |  |  | $ | — |  |  | $ | 205 |  |
| Financial liabilities | (262 | ) |  | 198 |  |  | (64 | ) |  | — |  |  | — |  |  | (64 | ) |
| Total derivative instruments | $ | 141 |  |  | $ | — |  |  | $ | 141 |  |  | $ | — |  |  | $ | — |  |  | $ | 141 |  |
|  | January 29, 2016 |
|  | Gross Amounts of Recognized Assets/ (Liabilities) |  | Gross Amounts Offset in the Statement of Financial Position |  | Net Amounts of Assets/ (Liabilities) Presented in the Statement of Financial Position |  | Gross Amounts not Offset in the Statement of Financial Position |  | Net Amount |
|  | Financial Instruments |  | Cash Collateral Received or Pledged |  |
|  | (in millions) |
| Derivative instruments |  |  |  |  |  |  |  |  |  |  |  |
| Financial assets | $ | 404 |  |  | $ | (209 | ) |  | $ | 195 |  |  | $ | — |  |  | $ | — |  |  | $ | 195 |  |
| Financial liabilities | (221 | ) |  | 209 |  |  | (12 | ) |  | — |  |  | — |  |  | (12 | ) |
| Total derivative instruments | $ | 183 |  |  | $ | — |  |  | $ | 183 |  |  | $ | — |  |  | $ | — |  |  | $ | 183 |  |


## us-gaap:DerivativesPolicyTextBlock

[0001571996-17-000004:notes:159]
The Company uses derivative financial instruments, primarily forwards, options, and swaps, to hedge certain foreign currency and interest rate exposures.  The relationships between hedging instruments and hedged items, as well as the risk management objectives and strategies for undertaking hedge transactions, are formally documented.  The Company does not use derivatives for speculative purposes.

[0001571996-17-000004:notes:160]
All derivative instruments are recognized as either assets or liabilities in the Consolidated Statements of Financial Position and are measured at fair value.  Hedge accounting is applied based upon the criteria established by accounting guidance for derivative instruments and hedging activities.  Derivatives are assessed for hedge effectiveness both at the onset of the hedge and at regular intervals throughout the life of the derivative.  Any hedge ineffectiveness is recognized currently in earnings as a component of interest and other, net.  For derivatives that are not designated as hedges or do not qualify for hedge accounting treatment, the Company recognizes the change in the instrument's fair value currently in earnings as a component of interest and other, net.  The Company's hedge portfolio includes non-designated derivatives and derivatives designated as cash flow hedges.

[0001571996-17-000004:notes:161]
For derivative instruments that are designated as cash flow hedges, hedge ineffectiveness is measured by comparing the cumulative change in the fair value of the hedge contract with the cumulative change in the fair value of the hedged item, both of which are based on forward rates.  The Company records the effective portion of the gain or loss on the derivative instrument in accumulated other comprehensive income (loss), as a separate component of stockholders' equity, and reclassifies the gain or loss into earnings in the period during which the hedged transaction is recognized in earnings.

[0001571996-17-000004:notes:162]
Cash flows from derivative instruments are presented in the same category on the Consolidated Statements of Cash Flows as the cash flows from the underlying hedged items.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001571996-17-000004:notes:163]
STOCK-BASED COMPENSATION

[0001571996-17-000004:notes:164]
Stock-based Compensation Expense

[0001571996-17-000004:notes:165]
Stock-based compensation expense for the Company was recognized in the Consolidated Statements of Income (Loss) as follows for the respective periods:

[0001571996-17-000004:notes:166]
|  | Fiscal Year Ended |
|  | February 3, 2017 |  | January 29, 2016 |  | January 30, 2015 |
|  | (in millions) |
| Stock-based compensation expense (a) (b): |  |  |  |  |  |  |
| Cost of net revenue | $ | 35 |  |  | $ | 10 |  |  | $ | 13 |  |
| Operating expenses | 363 |  |  | 62 |  |  | 59 |  |
| Stock-based compensation expense before taxes | 398 |  |  | 72 |  |  | 72 |  |
| Income tax benefit | (122 | ) |  | (26 | ) |  | (26 | ) |
| Stock-based compensation expense, net of income taxes | $ | 276 |  |  | $ | 46 |  |  | $ | 46 |  |

[0001571996-17-000004:notes:167]
| (a) | As a result of the EMC merger transaction, stock-based compensation expense before taxes for the fiscal year ended February 3, 2017 includes $279 million related to VMware plans discussed below for the period from September 7, 2016 through February 3, 2017. |

[0001571996-17-000004:notes:168]
| (b) | Stock-based compensation expense before taxes for the fiscal year ended February 3, 2017 does not include $807 million of post-merger stock-based compensation expense and related taxes resulting from the EMC merger transaction. See Note 3 of the Notes to the Consolidated Financial Statements for more information on the EMC merger transaction. |

[0001571996-17-000004:notes:169]
Stock-based Compensation Plans

[0001571996-17-000004:notes:170]
Dell Technologies Inc. 2013 Stock Incentive Plan — On September 7, 2016, at the effective time of the EMC merger transaction, the Denali Holding Inc. 2013 Stock Incentive Plan (the "2013 Plan") was amended and restated as the Dell Technologies Inc. 2013 Stock Incentive Plan (the "Restated Plan").  Employees, consultants, non-employee directors, and other service providers of the Company or its affiliates are eligible to participate in the Restated Plan.  The Restated Plan authorizes the issuance of an aggregate of 75 million shares of the Company's Class C Common Stock and 500,000 shares of the Company's Class V Common Stock, of which 61 million shares of Class C Common Stock were previously reserved for issuance under the 2013 Plan.  The Restated Plan authorizes the Company to grant stock options, restricted stock units ("RSUs"), stock appreciation rights ("SARs"), restricted stock awards ("RSAs"), and dividend equivalents.

[0001571996-17-000004:notes:171]
As of February 3, 2017 and January 29, 2016, there were 26 million and 17 million shares, respectively, of common stock of Dell Technologies available for future grants under the Restated Plan and the 2013 Plan, respectively.

[0001571996-17-000004:notes:172]
Stock Option Agreements — Stock options granted under the Restated Plan include service-based awards and performance-based awards.  A majority of the service-based stock options vest pro-rata at each option anniversary date over a five-year period.  Performance-based stock options, with a market condition, become exercisable upon achievement of return on equity ("ROE") metrics up to the seven-year anniversary of the going-private transaction date, depending upon the achievement of the market condition.  Both service-based and performance-based stock options are granted with option exercise prices equal to the fair market value of the Company's common stock, as determined by the Company's board of directors or authorized committee.  Generally, common stock issued under both service-based and performance-based awards are subject to liquidity events, such as an initial public offering, change in control, sales of common stock under a semi-annual company liquidity program, and calls and puts resulting upon the occurrence of specified events.  A majority of the stock options expire ten years after the date of grant.

[0001571996-17-000004:notes:173]
Stock Option Activity — The following table summarizes stock option activity settled in DHI Group Common Stock during the fiscal years ended February 3, 2017, January 29, 2016, and January 30, 2015:

[0001571996-17-000004:notes:174]
|  | Number of Options |  | Weighted-Average Exercise Price |  | Weighted Average Remaining Contractual Term |  | Aggregate Intrinsic Value |
|  | (in millions) |  | (per share) |  | (in years) |  | (in millions) |
| Options outstanding as of January 31, 2014 | 60 |  |  | $ | 14.32 |  |  |  |  |  |
| Granted | 2 |  |  | 17.08 |  |  |  |  |  |
| Exercised | — |  |  | — |  |  |  |  |  |
| Forfeited | (6 | ) |  | 13.75 |  |  |  |  |  |
| Canceled/expired | (1 | ) |  | 32.22 |  |  |  |  |  |
| Options outstanding as of January 30, 2015 | 55 |  |  | 14.11 |  |  |  |  |  |
| Granted | 2 |  |  | 24.05 |  |  |  |  |  |
| Exercised | — |  |  | — |  |  |  |  |  |
| Forfeited | (3 | ) |  | 19.07 |  |  |  |  |  |
| Canceled/expired | — |  |  | — |  |  |  |  |  |
| Options outstanding as of January 29, 2016 | 54 |  |  | 14.30 |  |  |  |  |  |
| Granted | 2 |  |  | 27.09 |  |  |  |  |  |
| Exercised | (1 | ) |  | 14.12 |  |  |  |  |  |
| Forfeited | (7 | ) |  | 15.51 |  |  |  |  |  |
| Canceled/expired | — |  |  | — |  |  |  |  |  |
| Options outstanding as of February 3, 2017 (a) | 48 |  |  | 14.75 |  |  | 6.5 |  | $ | 676 |  |
| Vested and expected to vest (net of estimated forfeitures), February 3, 2017 | 44 |  |  | $ | 14.75 |  |  | 6.4 |  | $ | 621 |  |
| Exercisable as of February 3, 2017 | 16 |  |  | $ | 14.63 |  |  | 5.8 |  | $ | 233 |  |

[0001571996-17-000004:notes:175]
| (a) | Of the 48 million stock options outstanding on February 3, 2017, 20 million related to performance-based awards and 28 million related to service-based awards. |

[0001571996-17-000004:notes:176]
The total fair value of options vested was $50 million, $42 million, and $41 million for the fiscal years ended February 3, 2017, January 29, 2016, and January 30, 2015, respectively.  The intrinsic value of the options exercised was $18 million, $4 million, and $1 million for the fiscal years ended February 3, 2017, January 29, 2016, and January 30, 2015, respectively.  As of February 3, 2017, there was $94 million of total unrecognized stock-based compensation expense, net of estimated forfeitures, related to unvested stock options expected to be recognized over a weighted-average period of 2.4 years.

[0001571996-17-000004:notes:177]
The tax benefit realized from the exercise of stock options was $6 million, $1 million, and immaterial for the fiscal years ended February 3, 2017, January 29, 2016, and January 30, 2015, respectively.

[0001571996-17-000004:notes:178]
In connection with the EMC merger transaction and in accordance with the merger agreement, certain executives holding unvested restricted stock units of EMC ("EMC RSUs") were given the opportunity to elect to exchange each unvested EMC RSU held by such executives that would otherwise have vested in the ordinary course on or after January 1, 2017 for (a) a deferred cash award having a cash value equal to the closing price of a share of EMC common stock on the last trading day before the closing date of the EMC merger transaction, or $29.05, and (b) an option ("rollover option") to purchase a share of Class C Common Stock of Dell Technologies ("the rollover opportunity").  The rollover options have a three-year term and a per share exercise price equal to the fair market value of a share of Class C Common Stock on the date of grant, or $27.50, and, to the extent vested, may be exercised using a cashless exercise method for both the exercise price and the applicable minimum required tax withholding (subject to certain limitations).  Each deferred cash award will vest, and each rollover option will vest and thereby become exercisable, on the same schedule as the EMC RSU for which they were exchanged (with any performance-vesting condition deemed satisfied at the target level of performance upon the closing of the EMC merger transaction).  Pursuant to the rollover opportunity, options to purchase 1.8 million shares of Class C Common Stock were issued and have been included within the stock option activity table above as granted options.

[0001571996-17-000004:notes:179]
Valuation of Service-Based Stock Option Awards — For service-based stock options granted under the 2013 Plan and the Restated Plan, the Company utilized the Black-Scholes option pricing model to estimate the fair value of stock options at the grant date.  The Black-Scholes option pricing model incorporates various assumptions, including leveraged adjusted volatility of a public peer group, expected term, risk-free interest rates, and dividend yields.  The weighted assumptions utilized for valuation of options under this model as well as the weighted-average grant date fair value of stock options granted during the respective periods are presented below.

[0001571996-17-000004:notes:180]
The expected term is based on historical experience and on the terms and conditions of the stock awards granted to employees.  For the periods presented, option valuations used leverage-adjusted volatility of a peer group, and the expected term was based on analysis of the Company's historical option settlement experience and on the terms and conditions of the stock awards granted.

[0001571996-17-000004:notes:181]
The assumptions utilized in this model as well as the weighted-average grant date fair value of stock options granted in DHI Group Common Stock are presented below:

[0001571996-17-000004:notes:182]
|  | Fiscal Year Ended |
|  | February 3, 2017 |  | January 29, 2016 |  | January 30, 2015 |
| Weighted-average grant date fair value of stock options granted per option | $ | 10.36 |  |  | $ | 10.05 |  |  | $ | 8.75 |  |
| Expected term (in years) | 3.4 |  |  | 5.1 |  |  | 5.2 |  |
| Risk-free rate (U.S. Government Treasury Note) | 0.9 | % |  | 1.5 | % |  | 1.6 | % |
| Expected volatility | 51 | % |  | 46 | % |  | 62 | % |
| Expected dividend yield | — | % |  | — | % |  | — | % |

[0001571996-17-000004:notes:183]
Valuation of Performance-Based Stock Option Awards — For performance-based stock options granted under the 2013 Plan and the Restated Plan, the Company utilized the Monte Carlo valuation model to simulate probabilities of achievement of the market condition and the grant date fair value.  The valuation model for performance-based option grants during the fiscal years ended February 3, 2017, January 29, 2016, and January 30, 2015 used a weighted-average leverage adjusted five years peer volatility and corresponding risk free interest rate.  Upon fulfillment of a ROE condition, a specific portion of the performance options become exercisable.  An embedded binomial lattice option pricing model was used to determine the value of these exercisable options using the assumption that each option will be exercised at the midpoint between the date of satisfaction of a ROE condition and the expiration date of such option.

[0001571996-17-000004:notes:184]
The assumptions utilized in this model as well as the weighted-average grant date fair value of stock options granted are presented below:

[0001571996-17-000004:notes:185]
|  | Fiscal Year Ended |
|  | February 3, 2017 |  | January 29, 2016 |  | January 30, 2015 |
| Weighted-average grant date fair value of stock options granted per option | $ | 8.83 |  |  | $ | 10.85 |  |  | $ | 9.01 |  |
| Expected term (in years) | — |  |  | — |  |  | — |  |
| Risk-free rate (U.S. Government Treasury Note) | 1.7 | % |  | 2.0 | % |  | 2.4 | % |
| Expected volatility | 44 | % |  | 50 | % |  | 55 | % |
| Expected dividend yield | — | % |  | — | % |  | — | % |

[0001571996-17-000004:notes:186]
Restricted Stock — The Company's restricted stock primarily consists of RSU awards granted to employees.  RSUs are valued based on the Company's Class C Common Stock price on the date of grant.  The shares underlying the RSU awards are not issued until the RSU vests.  Upon vesting, each RSU converts into one share of DHI Group Common Stock.

[0001571996-17-000004:notes:187]
The Company's restricted stock also includes performance stock unit ("PSU") awards, which have been granted to certain members of the Company's senior leadership team.  The PSU awards include performance conditions and, in certain cases, a time-based vesting component.  For PSU awards granted under the Restated Plan, the Company utilized the Monte Carlo valuation model to simulate the probabilities of achievement of the market condition to determine the grant date fair value.  The vesting and payout of the PSU awards depends upon the return on equity achieved on various measurement dates or liquidity events.

[0001571996-17-000004:notes:188]
The following table summarizes non-vested restricted stock and restricted stock units activity settled in DHI Group Common Stock during the fiscal year ended February 3, 2017.  For the fiscal years ended January 29, 2016 and January 30, 2015, the total estimated vest date fair value of restricted stock unit awards was not material.

[0001571996-17-000004:notes:189]
|  | NumberofShares |  | Weighted-AverageGrant DateFair Value |
|  | (in millions) |  | (per share) |
| Non-vested restricted stock unit balance as of January 29, 2016 | — |  |  | $ | — |  |
| Granted | 11 |  |  | 19.66 |  |
| Vested | — |  |  | — |  |
| Forfeited | (1 | ) |  | 19.63 |  |
| Non-vested restricted stock unit balance as of February 3, 2017 (a) | 10 |  |  | $ | 19.63 |  |

[0001571996-17-000004:notes:190]
_________________

[0001571996-17-000004:notes:191]
| (a) | Of the 10 million non-vested restricted stock units, 6 million related to performance-based awards and 4 million related to service-based awards. |

[0001571996-17-000004:notes:192]
As of February 3, 2017, there was $144 million of unrecognized stock-based compensation expense, net of estimated forfeitures, related to these awards expected to be recognized over a weighted-average period of approximately 2.6 years.

[0001571996-17-000004:notes:193]
Dell Technologies Shares Withheld for Taxes — Under certain situations, shares are sold to cover employee taxes for both the vesting of restricted stock units and the exercise of stock options.  For the fiscal year ended February 3, 2017, 0.2 million shares were withheld to cover $6 million of employees' tax obligations.  Shares withheld for taxes for the fiscal years ended January 29, 2016 and January 30, 2015 were immaterial.

[0001571996-17-000004:notes:194]
VMware

[0001571996-17-000004:notes:195]
VMware Equity Plans — In June 2007, VMware adopted its 2007 Equity and Incentive Plan (the "2007 Plan").  As of February 3, 2017, the number of authorized shares of VMware Class A common stock under the 2007 Plan was 122 million.  The number of shares underlying outstanding equity awards that VMware assumes in the course of business acquisitions are also added to the 2007 Plan reserve on an as-converted basis.  VMware has assumed 4 million shares, which accordingly have been added to the authorized shares under the 2007 Plan reserve.

[0001571996-17-000004:notes:196]
Awards under the 2007 Plan may be in the form of stock-based awards such as RSUs or stock options.  Generally, restricted stock grants made under the 2007 Plan have a three-year to four-year period over which they vest and vest 25% the first year and semi-annually thereafter.  VMware's Compensation and Corporate Governance Committee determines the vesting schedule for all equity awards.  The value of RSU grants is based on VMware's stock price on the date of grant.  The shares underlying the RSU awards are not issued until the RSUs vest.  Upon vesting, each RSU converts into one share of VMware Class A common stock.  VMware's restricted stock also include PSU awards, which have been granted to certain VMware executives and employees.  The PSU awards include performance conditions and a time-based vesting component.  Upon vesting, each PSU award will convert into VMware's Class A common stock at various ratios ranging from 0.5 to 2.0 shares per PSU, depending upon the degree of achievement of the performance target designated by each individual award.  If minimum performance thresholds are not achieved, then no shares will be issued.

[0001571996-17-000004:notes:197]
The exercise price for a stock option awarded under the 2007 Plan may not be less than 100% of the fair market value of VMware Class A common stock on the date of grant.  Most options granted under the 2007 Plan vest 25% after the first year and monthly thereafter over the following three years and expire between six and seven years from the date of grant.  VMware utilizes both authorized and unissued shares to satisfy all shares issued under the 2007 Plan.  As of February 3, 2017, there were an aggregate of 13 million shares of common stock available for issuance pursuant to future grants under the 2007 Plan.

[0001571996-17-000004:notes:198]
VMware Employee Stock Purchase Plan — In June 2007, VMware adopted its 2007 Employee Stock Purchase Plan (the "ESPP"), which is intended to be qualified under Section 423 of the Internal Revenue Code.  As of February 3, 2017, the number of authorized shares of VMware Class A common stock under the ESPP was a total of 14 million shares.  Under the ESPP, eligible VMware employees are granted options to purchase shares at the lower of 85% of the fair market value of the stock at the time of grant or 85% of the fair market value at the time of exercise.

[0001571996-17-000004:notes:199]
The option period is generally twelve months and includes two embedded six-month option periods.  Options are exercised at the end of each embedded option period.  If the fair market value of the stock is lower on the first day of the second embedded option period than it was at the time of grant, then the twelve-month option period expires and each enrolled participant is granted a new twelve-month option.  As of February 3, 2017, 1 million shares of VMware Class A common stock were available for issuance under the ESPP.

[0001571996-17-000004:notes:200]
The following table summarizes ESPP activity during the period from September 7, 2016 through February 3, 2017:

[0001571996-17-000004:notes:201]
|  | September 7, 2016 through February 3, 2017 |
|  | (in millions, except per share amounts) |
| Cash proceeds | $ | 60 |  |
| Class A common shares purchased | 1.5 |  |
| Weighted-average price per share | $ | 40.65 |  |

[0001571996-17-000004:notes:202]
VMware Stock Options — The following table summarizes stock option activity for VMware employees in VMware stock options:

[0001571996-17-000004:notes:203]
|  | Number of Options |  | Weighted-Average Exercise Price |  | Weighted Average Remaining Contractual Term |  | Aggregate Intrinsic Value |
|  | (in millions) |  | (per share) |  | (in years) |  | (in millions) |
| Options outstanding as of September 7, 2016 | 2 |  |  | $ | 65.01 |  |  |  |  |  |
| Granted | — |  |  | — |  |  |  |  |  |
| Exercised | — |  |  | — |  |  |  |  |  |
| Forfeited | — |  |  | — |  |  |  |  |  |
| Canceled/Expired | — |  |  | — |  |  |  |  |  |
| Options outstanding as of February 3, 2017 (a) | 2 |  |  | $ | 69.38 |  |  | 4.4 |  | $ | 43 |  |
| Vested and expected to vest (net of estimated forfeitures) as of February 3, 2017 | 2 |  |  | $ | 69.15 |  |  | 4.4 |  | $ | 43 |  |
| Exercisable as of February 3, 2017 | 1 |  |  | $ | 68.81 |  |  | 4.3 |  | $ | 32 |  |

[0001571996-17-000004:notes:204]
(a)   Stock option activity during the period was immaterial.  The ending weighted-average exercise price was calculated based on underlying options outstanding as of February 3, 2017.

[0001571996-17-000004:notes:205]
The above table includes stock options granted in conjunction with unvested stock options assumed in business combinations.  As a result, the weighted-average exercise price per share may vary from the VMware stock price at time of grant.  Aggregate intrinsic values represent the total pretax intrinsic values based on VMware's closing stock price of $88.95 as of February 3, 2017 as reported on the NYSE, which would have been received by the option holders had all in-the-money options been exercised as of that date.  The total fair value of VMware stock options that vested during the period from September 7, 2016 through February 3, 2017 was $13 million.  The intrinsic value of the options exercised during the period from September 7, 2016 through February 3, 2017 was $13 million.  During the period from September 7, 2016 through February 3, 2017, $4 million in cash was received from the stock option exercises.

[0001571996-17-000004:notes:206]
The tax benefit realized from the exercise of stock options was $4 million from the period from September 7, 2016 through February 3, 2017.  As of February 3, 2017, there was $15 million of total unrecognized stock-based compensation expense, net of estimated forfeitures, related to unvested stock options expected to be recognized over a weighted-average period of less than one year.

[0001571996-17-000004:notes:207]
Fair Value of VMware Options — The fair value of each option to acquire VMware Class A common stock granted is estimated on the date of grant using the Black-Scholes option-pricing model with the following weighted-average assumptions:

[0001571996-17-000004:notes:208]
|  | Fiscal Year Ended February 3, 2017 |
| VMware Employee Stock Purchase Plan |  |
| Weighted-average grant date fair value of stock options granted per option | $ | 13.57 |  |
| Expected term (in years) | 0.8 |  |
| Risk-free rate (U.S. Government Treasury Note) | 0.5 | % |
| Expected volatility | 38 | % |
| Expected dividend yield | — | % |

[0001571996-17-000004:notes:209]
The weighted-average grant date fair value of VMware stock options can fluctuate from period to period primarily due to higher valued options assumed through business combinations with exercise prices lower than the fair market value of VMware's stock on the date of grant.

[0001571996-17-000004:notes:210]
For equity awards granted, volatility is based on an analysis of historical stock prices and implied volatilities of VMware's Class A common stock.  The expected term is based on historical exercise patterns and post-vesting termination behavior, the term of the option period for grants made under VMware's ESPP, or the weighted-average remaining term for options assumed in acquisitions.  VMware's expected dividend yield input was zero as it has not historically paid, nor expects in the future to pay, cash dividends on its common stock.  The risk-free interest rate is based on a U.S. Treasury instrument whose term is consistent with the expected term of the stock options.

[0001571996-17-000004:notes:211]
There were no stock options granted during the period from September 7, 2016 through February 3, 2017.

[0001571996-17-000004:notes:212]
VMware Restricted Stock — The following table summarizes VMware's restricted stock activity since September 7, 2016:

[0001571996-17-000004:notes:213]
|  | NumberofShares |  | Weighted-AverageGrant DateFair Value |
|  | (in millions) |  | (per share) |
| Non-vested restricted stock unit balance as of September 7, 2016 | 22 |  |  | $ | 67.01 |  |
| Granted | 2 |  |  | 79.81 |  |
| Vested | (3 | ) |  | 72.94 |  |
| Forfeited | (1 | ) |  | 69.19 |  |
| Non-vested restricted stock unit balance as of February 3, 2017 | 20 |  |  | $ | 67.41 |  |

[0001571996-17-000004:notes:214]
As of February 3, 2017, restricted stock representing 20 million shares of VMware's Class A common stock was outstanding, with an aggregate intrinsic value of $1,819 million based on VMware's closing stock price as of February 3, 2017 as reported on the NYSE.  The total fair value of VMware restricted stock awards that vested during the period from September 7, 2016 through February 3, 2017 was $203 million and the intrinsic value was $218 million.  As of February 3, 2017, there was $973 million of unrecognized stock-based compensation expense, net of estimated forfeitures, related to these awards expected to be recognized over a weighted-average period of approximately 1.4 years.

[0001571996-17-000004:notes:215]
VMware Shares Withheld for Taxes — For the fiscal year ended February 3, 2017, VMware repurchased and retired or withheld 1 million shares of Class A common stock for $77 million to cover tax withholding obligations.  These amounts may differ from the amounts of cash remitted for tax withholding obligations on the consolidated statements of cash flows due to the timing of payments.  Pursuant to the respective award agreements, these shares were withheld in conjunction with the net share settlement upon the vesting of restricted stock and restricted stock units during the period.  The value of the withheld shares, including restricted stock units, was classified as a reduction to additional paid-in capital.

[0001571996-17-000004:notes:216]
Other Plans

[0001571996-17-000004:notes:217]
In addition to the plans disclosed above, the Company has issued equity grants settling in its Class V Common Stock as well as classes of stock of its subsidiaries, including SecureWorks.  The stock option and restricted stock unit activity under these plans was not material during the fiscal years ended February 3, 2017, January 29, 2016, and January 30, 2015.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001571996-17-000004:notes:218]
DISCONTINUED OPERATIONS

[0001571996-17-000004:notes:219]
Dell Services Divestiture — On March 27, 2016, Dell entered into a definitive agreement with NTT Data International L.L.C. to divest substantially all of Dell Services.  On November 2, 2016, the parties closed substantially all of the transaction.  Total cash consideration received by the Company as of February 3, 2017 was approximately $3.0 billion, resulting in a gain on sale, net of tax, of $1.7 billion.  The remainder of the transaction closed subsequent to the fiscal year ended February 3, 2017.

[0001571996-17-000004:notes:220]
Dell Software Group Divestiture — On June 19, 2016, Dell entered into a definitive agreement with Francisco Partners and Elliot Management Corporation to divest substantially all of DSG.  On October 31, 2016, the parties closed the transaction.  At the completion of the sale, total cash consideration received by the Company was approximately $2.4 billion, resulting in a gain on sale, net of tax, of $0.6 billion.

[0001571996-17-000004:notes:221]
Enterprise Content Division Divestiture — On September 12, 2016, EMC, a subsidiary of the Company, entered into a definitive agreement with OpenText Corporation to divest the Dell EMC Enterprise Content Division.  On January 23, 2017, the parties closed the transaction.  At the completion of the sale, total cash consideration received by the Company was approximately $1.6 billion, resulting in a loss on sale, net of tax, of $0.4 billion.

[0001571996-17-000004:notes:222]
Discontinued Operations Presentation — In accordance with applicable accounting guidance, the Company concluded that Dell Services, DSG, and ECD have met the criteria for discontinued operations reporting as of March 27, 2016, June 19, 2016, and September 7, 2016, respectively.  Accordingly, the Company reclassified the financial results of Dell Services and DSG as discontinued operations in the Consolidated Statements of Income (Loss) for all periods presented.  The Company classified the results of ECD as discontinued operations for the period from September 7, 2016 through February 3, 2017 due to the ECD business only being included in the Company's consolidated results since the closing of the EMC merger transaction.  These financial results and the related gains or losses on sale are presented as "Income (loss) from discontinued operations, net of income taxes" in the accompanying Consolidated Statements of Income (Loss) for the fiscal years ended February 3, 2017, January 29, 2016, and January 30, 2015.  The Company reclassified the related assets and liabilities as "Current assets held for sale" and "Current liabilities held for sale" in the accompanying Consolidated Statements of Financial Position as of January 29, 2016.  Cash flows from the Company's discontinued operations are included in the accompanying Consolidated Statements of Cash Flows.

[0001571996-17-000004:notes:223]
Upon closing of the respective transactions, the Company entered into transition services agreements with NTT Data International L.L.C., Francisco Partners and Elliot Management, and OpenText Corporation pursuant to which the Company provides various administrative services on an interim transitional basis.  Transition services may be provided for up to one year, with an option to renew after that period.  The Company also entered into various commercial agreements with NTT Data International, Francisco Partners and Elliot Management, and OpenText Corporation that includes reseller agreements for certain offerings.

[0001571996-17-000004:notes:224]
The following tables present key financial results of ECD, Dell Services, and DSG included in "Income (loss) from discontinued operations, net of income taxes" for the fiscal years ended February 3, 2017, January 29, 2016, and January 30, 2015:

[0001571996-17-000004:notes:225]
|  | Fiscal Year Ended February 3, 2017 |
|  | ECD (a) |  | Dell Services |  | DSG |  | Total |
|  | (in millions) |
| Net revenue | $ | 209 |  |  | $ | 1,980 |  |  | $ | 975 |  |  | $ | 3,164 |  |
| Cost of net revenue | 56 |  |  | 1,563 |  |  | 252 |  |  | 1,871 |  |
| Operating expenses | 137 |  |  | 347 |  |  | 726 |  |  | 1,210 |  |
| Interest and other, net | (1 | ) |  | (8 | ) |  | (2 | ) |  | (11 | ) |
| Income (loss) from discontinued operations before income taxes and gain (loss) on disposal | 15 |  |  | 62 |  |  | (5 | ) |  | 72 |  |
| Income tax provision (benefit) | 3 |  |  | (40 | ) |  | (23 | ) |  | (60 | ) |
| Income from discontinued operations, net of income taxes, before gain (loss) on disposal | 12 |  |  | 102 |  |  | 18 |  |  | 132 |  |
| Gain (loss) on disposal, net of tax expense (benefit) of $182, $(256), and $506, respectively | (356 | ) |  | 1,680 |  |  | 563 |  |  | 1,887 |  |
| Income (loss) from discontinued operations, net of income taxes | $ | (344 | ) |  | $ | 1,782 |  |  | $ | 581 |  |  | $ | 2,019 |  |

[0001571996-17-000004:notes:226]
| (a) | The Company classified the results of ECD as discontinued operations for the period from September 7, 2016 through February 3, 2017 due to the ECD business only being included in the Company's consolidated results since the closing of the EMC merger transaction. |

[0001571996-17-000004:notes:227]
|  | Fiscal Year Ended January 29, 2016 |
|  | Dell Services |  | DSG |  | Total |
|  | (in millions) |
| Net revenue | $ | 2,686 |  |  | $ | 1,289 |  |  | $ | 3,975 |  |
| Cost of net revenue | 2,157 |  |  | 373 |  |  | 2,530 |  |
| Operating expenses | 399 |  |  | 915 |  |  | 1,314 |  |
| Interest and other, net | — |  |  | (20 | ) |  | (20 | ) |
| Income (loss) from discontinued operations before income taxes | 130 |  |  | (19 | ) |  | 111 |  |
| Income tax provision | 42 |  |  | 5 |  |  | 47 |  |
| Income (loss) from discontinued operations, net of income taxes | $ | 88 |  |  | $ | (24 | ) |  | $ | 64 |  |

[0001571996-17-000004:notes:228]
|  | Fiscal Year Ended January 30, 2015 |
|  | Dell Services |  | DSG |  | Total |
|  | (in millions) |
| Net revenue | $ | 2,691 |  |  | $ | 1,286 |  |  | $ | 3,977 |  |
| Cost of net revenue | 2,318 |  |  | 347 |  |  | 2,665 |  |
| Operating expenses | 391 |  |  | 1,027 |  |  | 1,418 |  |
| Interest and other, net | — |  |  | (25 | ) |  | (25 | ) |
| Loss from discontinued operations before income taxes | (18 | ) |  | (113 | ) |  | (131 | ) |
| Income tax benefit | (15 | ) |  | (3 | ) |  | (18 | ) |
| Loss from discontinued operations, net of income taxes | $ | (3 | ) |  | $ | (110 | ) |  | $ | (113 | ) |

[0001571996-17-000004:notes:229]
The following table presents the major classes of assets and liabilities related to Dell Services and DSG as of January 29, 2016, which were classified as held for sale:

[0001571996-17-000004:notes:230]
|  | January 29, 2016 |
|  | Dell Services |  | DSG |  | Total |
|  | (in millions) |
| ASSETS |  |  |
| Current assets: |  |  |  |  |  |
| Cash and cash equivalents | $ | — |  |  | $ | 254 |  |  | $ | 254 |  |
| Accounts receivable, net | 404 |  |  | 244 |  |  | 648 |  |
| Inventories, net | — |  |  | 24 |  |  | 24 |  |
| Other current assets | 73 |  |  | 11 |  |  | 84 |  |
| Total current assets | 477 |  |  | 533 |  |  | 1,010 |  |
| Property, plant, and equipment, net | 515 |  |  | 106 |  |  | 621 |  |
| Goodwill | 252 |  |  | 1,391 |  |  | 1,643 |  |
| Intangible assets, net | 388 |  |  | 613 |  |  | 1,001 |  |
| Other non-current assets | 50 |  |  | 8 |  |  | 58 |  |
| Total assets | $ | 1,682 |  |  | $ | 2,651 |  |  | $ | 4,333 |  |
| LIABILITIES |  |  |
| Current liabilities: |  |  |  |  |  |  |  |
| Accounts payable | $ | 38 |  |  | $ | 15 |  |  | $ | 53 |  |
| Accrued and other | 180 |  |  | 160 |  |  | 340 |  |
| Short-term deferred revenue | 82 |  |  | 625 |  |  | 707 |  |
| Total current liabilities | 300 |  |  | 800 |  |  | 1,100 |  |
| Long-term deferred revenue | 53 |  |  | 333 |  |  | 386 |  |
| Other non-current liabilities | 31 |  |  | 82 |  |  | 113 |  |
| Total liabilities | $ | 384 |  |  | $ | 1,215 |  |  | $ | 1,599 |  |

[0001571996-17-000004:notes:231]
The significant cash flow items from ECD, Dell Services, and DSG for the fiscal years ended February 3, 2017, January 29, 2016, and January 30, 2015 were as follows:

[0001571996-17-000004:notes:232]
|  | Fiscal Year Ended |
|  | February 3, 2017 |  | January 29, 2016 |  | January 30, 2015 |
|  | (in millions) |
| Depreciation and amortization (a) |  |  |  |  |  |
| Dell Services | $ | 32 |  |  | $ | 211 |  |  | $ | 221 |  |
| DSG | 66 |  |  | 167 |  |  | 157 |  |
| Total depreciation and amortization | $ | 98 |  |  | $ | 378 |  |  | $ | 378 |  |
| Capital expenditures |  |  |  |  |  |
| Dell Services | $ | 82 |  |  | $ | 91 |  |  | $ | 123 |  |
| DSG | 20 |  |  | 25 |  |  | 26 |  |
| ECD | 2 |  |  | — |  |  | — |  |
| Total capital expenditures | $ | 104 |  |  | $ | 116 |  |  | $ | 149 |  |

[0001571996-17-000004:notes:233]
| (a) | Depreciation and amortization ceased upon determination that Dell Services and DSG had met the criteria for discontinued operations reporting as of March 27, 2016 and June 19, 2016, respectively. Depreciation and amortization for ECD ceased upon determination that the held for sale criteria were met as of September 7, 2016, concurrently with the closing of the EMC merger transaction. |


## us-gaap:EarningsPerShareTextBlock

[0001571996-17-000004:notes:234]
EARNINGS (LOSS) PER SHARE

[0001571996-17-000004:notes:235]
Basic earnings (loss) per share is based on the weighted-average effect of all common shares issued and outstanding and is calculated by dividing net income (loss) by the weighted-average shares outstanding during the period.  Diluted earnings (loss) per share is calculated by dividing net income (loss) by the weighted-average number of common shares used in the basic earnings (loss) per share calculation plus the number of common shares that would be issued assuming exercise or conversion of all potentially dilutive instruments.  The Company excludes equity instruments from the calculation of diluted earnings (loss) per share if the effect of including such instruments is antidilutive.

[0001571996-17-000004:notes:236]
The Company has two groups of common stock, denoted as the DHI Group Common Stock and the Class V Common Stock.  The DHI Group Common Stock consists of four classes of common stock, referred to as Class A Common Stock, Class B Common Stock, Class C Common Stock, and Class D Common Stock.  The DHI Group generally refers to the direct and indirect interest of Dell Technologies in all of Dell Technologies' business, assets, properties, liabilities, and preferred stock other than those attributable to the Class V Group, as well as its retained interest in the Class V Group equal to approximately 38% of the Company's economic interest in the Class V Group as of February 3, 2017.  The Class V Common Stock is intended to track the economic performance of approximately 62% of the Company's economic interest in the Class V Group as of such date.  As of February 3, 2017, the Class V Group consisted of approximately 338 million shares of Class A common stock of VMware held by the Company.  See Note 18 of the Notes to the Consolidated Financial Statements and Exhibit 99.1 filed with the annual report on Form 10-K for the fiscal year ended February 3, 2017 for more information regarding the allocation of earnings from Dell Technologies' interest in VMware between the DHI Group and the Class V Common Stock.

[0001571996-17-000004:notes:237]
For purposes of calculating earnings (loss) per share, the Company used the two-class method.  As all classes of DHI Group Common Stock share the same rights in dividends, basic and diluted earnings (loss) per share are the same for each class of DHI Group Common Stock.

[0001571996-17-000004:notes:238]
The following table sets forth basic and diluted earnings (loss) per share for each of the periods presented:

[0001571996-17-000004:notes:239]
|  | Fiscal Year Ended |
|  | February 3, 2017 |  | January 29, 2016 |  | January 30, 2015 |
|  | (in millions, except per share amounts) |
| Earnings (loss) per share attributable to Dell Technologies Inc. - basic: |
| Continuing operations - Class V Common Stock - basic | $ | 1.44 |  |  | $ | — |  |  | $ | — |  |
| Continuing operations - DHI Group - basic | $ | (8.52 | ) |  | $ | (2.88 | ) |  | $ | (2.74 | ) |
| Discontinued operations - DHI Group - basic | $ | 4.30 |  |  | $ | 0.16 |  |  | $ | (0.28 | ) |
| Earnings (loss) per share attributable to Dell Technologies Inc. - diluted: |
| Continuing operations - Class V Common Stock - diluted | $ | 1.43 |  |  | $ | — |  |  | $ | — |  |
| Continuing operations - DHI Group - diluted | $ | (8.52 | ) |  | $ | (2.88 | ) |  | $ | (2.74 | ) |
| Discontinued operations - DHI Group - diluted | $ | 4.30 |  |  | $ | 0.16 |  |  | $ | (0.28 | ) |

[0001571996-17-000004:notes:240]
The following table sets forth the computation of basic and diluted earnings (loss) per share for each of the periods presented:

[0001571996-17-000004:notes:241]
|  | Fiscal Year Ended |
|  | February 3, 2017 |  | January 29, 2016 |  | January 30, 2015 |
|  | (in millions, except per share amounts) |
| Numerator: Continuing operations - Class V Common Stock |  |  |  |  |  |
| Net income from continuing operations attributable to Class V Common Stock - basic | $ | 313 |  |  | $ | — |  |  | $ | — |  |
| Incremental dilution from VMware attributable to Class V Common Stock (a) | (3 | ) |  | — |  |  | — |  |
| Net income from continuing operations attributable to Class V Common Stock - diluted | $ | 310 |  |  | $ | — |  |  | $ | — |  |
| Numerator: Continuing operations - DHI Group |  |  |  |  |  |
| Net loss from continuing operations attributable to DHI Group - basic | $ | (4,004 | ) |  | $ | (1,168 | ) |  | $ | (1,108 | ) |
| Incremental dilution from VMware attributable to DHI Group (a) | (2 | ) |  | — |  |  | — |  |
| Net loss from continuing operations attributable to DHI Group - diluted | $ | (4,006 | ) |  | $ | (1,168 | ) |  | $ | (1,108 | ) |
| Numerator: Discontinued operations - DHI Group |  |  |  |  |  |
| Income (loss) from discontinued operations, net of income taxes - basic and diluted | $ | 2,019 |  |  | $ | 64 |  |  | $ | (113 | ) |
| Denominator: Class V Common Stock weighted-average shares outstanding |  |  |  |  |  |  |  |  |
| Weighted-average shares outstanding - basic | 217 |  |  | — |  |  | — |  |
| Dilutive effect of options, restricted stock units, restricted stock, and other (b) | — |  |  | — |  |  | — |  |
| Weighted-average shares outstanding - diluted | 217 |  |  | — |  |  | — |  |
| Weighted-average shares outstanding - antidilutive (b) | — |  |  | — |  |  | — |  |
| Denominator: DHI Group weighted-average shares outstanding |  |  |  |  |  |
| Weighted-average shares outstanding - basic | 470 |  |  | 405 |  |  | 404 |  |
| Dilutive effect of options, restricted stock units, restricted stock, and other | — |  |  | — |  |  | — |  |
| Weighted-average shares outstanding - diluted | 470 |  |  | 405 |  |  | 404 |  |
| Weighted-average shares outstanding - antidilutive (c) | 31 |  |  | 53 |  |  | 55 |  |

[0001571996-17-000004:notes:242]
| (a) | The incremental dilution from VMware represents the impact of VMware's dilutive securities on the DHI Group and Class V Common Stock's respective diluted earnings (loss) per share and is calculated by multiplying the difference between VMware's basic and diluted earnings (loss) per share by the number of shares of VMware Class A common stock owned by the Company. |

[0001571996-17-000004:notes:243]
| (b) | The dilutive effect of Class V Common Stock-based incentive awards was not material to the calculation of the weighted-average Class V Common Stock outstanding. The antidilutive effect of these awards was also not material. |

[0001571996-17-000004:notes:244]
| (c) | Stock-based incentive awards have been excluded from the calculation of the DHI Group's diluted earnings (loss) per share because their effect would have been antidilutive, as the Company had a net loss from continuing operations attributable to the DHI Group for the periods presented. |


## us-gaap:FairValueDisclosuresTextBlock

[0001571996-17-000004:notes:245]
FAIR VALUE MEASUREMENTS

[0001571996-17-000004:notes:246]
The following table presents the Company's hierarchy for its assets and liabilities measured at fair value on a recurring basis as of February 3, 2017 and January 29, 2016:

[0001571996-17-000004:notes:247]
|  | February 3, 2017 (a) |  | January 29, 2016 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | QuotedPricesin ActiveMarkets forIdenticalAssets |  | SignificantOtherObservableInputs |  | SignificantUnobservableInputs |  |  |  | QuotedPricesin ActiveMarkets forIdenticalAssets |  | SignificantOtherObservableInputs |  | SignificantUnobservableInputs |  |  |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 4,866 |  |  | $ | — |  |  | $ | — |  |  | $ | 4,866 |  |  | $ | 3,832 |  |  | $ | — |  |  | $ | — |  |  | $ | 3,832 |  |
| Municipal obligations | — |  |  | 3 |  |  | — |  |  | 3 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Debt securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government and agencies | 444 |  |  | 470 |  |  | — |  |  | 914 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| U.S. corporate | — |  |  | 1,800 |  |  | — |  |  | 1,800 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Foreign | — |  |  | 2,083 |  |  | — |  |  | 2,083 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Municipal obligations | — |  |  | 352 |  |  | — |  |  | 352 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Asset-backed securities | — |  |  | 4 |  |  | — |  |  | 4 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Equity and other securities | 169 |  |  | — |  |  | — |  |  | 169 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Derivative instruments | — |  |  | 205 |  |  | — |  |  | 205 |  |  | — |  |  | 195 |  |  | — |  |  | 195 |  |
| Common stock purchase agreement | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 10 |  |  | 10 |  |
| Total assets | $ | 5,479 |  |  | $ | 4,917 |  |  | $ | — |  |  | $ | 10,396 |  |  | $ | 3,832 |  |  | $ | 195 |  |  | $ | 10 |  |  | $ | 4,037 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative instruments | $ | — |  |  | $ | 64 |  |  | $ | — |  |  | $ | 64 |  |  | $ | — |  |  | $ | 12 |  |  | $ | — |  |  | $ | 12 |  |
| Debt - Other | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 28 |  |  | 28 |  |
| Total liabilities | $ | — |  |  | $ | 64 |  |  | $ | — |  |  | $ | 64 |  |  | $ | — |  |  | $ | 12 |  |  | $ | 28 |  |  | $ | 40 |  |

[0001571996-17-000004:notes:248]
(a)   The Company did not transfer any securities between levels during the fiscal year ended February 3, 2017.

[0001571996-17-000004:notes:249]
The following section describes the valuation methodologies the Company uses to measure financial instruments at fair value:

[0001571996-17-000004:notes:250]
Money Market Funds — The Company's investment in money market funds that are classified as cash equivalents hold underlying investments with a weighted average maturity of 90 days or less and are recognized at fair value.  The valuations of these securities are based on quoted prices in active markets for identical assets, when available, or pricing models whereby all significant inputs are observable or can be derived from or corroborated by observable market data.  The Company reviews security pricing and assesses liquidity on a quarterly basis.  As of February 3, 2017, the Company's U.S. portfolio had no material exposure to money market funds with a fluctuating net asset value.

[0001571996-17-000004:notes:251]
Cash Equivalent Municipal Obligations — The Company's municipal obligations that are classified as cash equivalents have original maturities of 90 days or less and are recognized at fair value.  The valuation methodology for these securities is the same as the methodology for non-cash equivalent municipal obligations as described in the Debt Securities section below.

[0001571996-17-000004:notes:252]
Debt Securities — The majority of the Company's debt securities consist of various fixed income securities such as U.S. government and agencies, U.S. corporate, and foreign.  Valuation is based on pricing models whereby all significant inputs, including benchmark yields, reported trades, broker-dealer quotes, issue spreads, benchmark securities, bids, offers, and other market related data, are observable or can be derived from or corroborated by observable market data for substantially the full term of the asset.  Inputs are documented in accordance with the fair value measurements hierarchy.  The Company reviews security pricing and assesses liquidity on a quarterly basis.  See Note 6 of the Notes to the Consolidated Financial Statements for additional information about investments.

[0001571996-17-000004:notes:253]
Equity Securities — The majority of the Company's investments in equity and other securities that are measured at fair value on a recurring basis consist of strategic investments in publicly traded companies.  The valuation of these securities is based on quoted prices in active markets.

[0001571996-17-000004:notes:254]
Derivative Instruments — The Company's derivative financial instruments consist primarily of foreign currency forward and purchased option contracts and interest rate swaps.  The fair value of the portfolio is determined using valuation models based on market observable inputs, including interest rate curves, forward and spot prices for currencies, and implied volatilities.  Credit risk is also factored into the fair value calculation of the Company's derivative instrument portfolio.  See Note 9 of the Notes to the Consolidated Financial Statements for a description of the Company's derivative financial instrument activities.

[0001571996-17-000004:notes:255]
Debt - Other — As of January 29, 2016, the Company recognized a portion of its short-term debt at fair value.  This debt was represented by promissory notes issued on August 3, 2015 and September 14, 2015, which were extinguished during the fiscal year ended February 3, 2017.  The Company determined fair value using a discounted cash flow model which included significant unobservable inputs and assumptions.  The unobservable inputs used include projected cash outflows over varying possible maturity dates, weighted by the probability of those possible outcomes, along with assumed discount rates.

[0001571996-17-000004:notes:256]
Common Stock Purchase Agreements — On September 7, 2016, in connection with the EMC merger transaction, the Company issued and sold the following shares of the Company's common stock at a purchase price of $27.50 per share to the persons identified below for an aggregate purchase price of $4.4 billion, pursuant to four separate common stock purchase agreements:

[0001571996-17-000004:notes:257]
| • | 86,909,091 shares of Class A Common Stock to the MD Stockholders |

[0001571996-17-000004:notes:258]
| • | 16,104,050 shares of Class A Common Stock to the MSDC Stockholders |

[0001571996-17-000004:notes:259]
| • | 38,805,040 shares of Class B Common Stock to the SLP Stockholders |

[0001571996-17-000004:notes:260]
| • | 18,181,818 shares of Class C Common Stock to Temasek Holdings Private Limited ("Temasek") |

[0001571996-17-000004:notes:261]
The Company applied the proceeds from the sale of the shares to finance a portion of the consideration for the EMC merger transaction.  Each agreement provided for price protection in the event additional equity investors purchased common stock of the Company at a lower price.  The agreements with Michael S. Dell, the MSDC Stockholders, and the SLP Stockholders were not required to be remeasured to fair value through settlement and were effectively capital commitments, because of the degree of control and influence such persons could exercise over the Company.  The provision relating to price protection was considered substantive to Temasek as an unrelated party.  Consequently, the Company recognized the contract as an asset or liability, initially recorded at fair value of zero, with subsequent changes in fair value recorded in earnings through settlement.  The Company determined the fair value of this forward contract using a Black-Scholes valuation model, which included significant unobservable inputs and assumptions.

[0001571996-17-000004:notes:262]
Assets and Liabilities Measured at Fair Value on a Nonrecurring Basis — Certain assets are measured at fair value on a nonrecurring basis and therefore are not included in the recurring fair value table above.  These assets consist primarily of non-financial assets such as goodwill and intangible assets.  See Note 10 of the Notes to the Consolidated Financial Statements for additional information about goodwill and intangible assets.

[0001571996-17-000004:notes:263]
As of February 3, 2017 and January 29, 2016, the Company held strategic investments of $455 million and $114 million, respectively.  These investments are accounted for under the cost method and are not included in the recurring fair value table above.  Investments accounted for under the cost method are recorded at cost initially, which approximates fair value.  Subsequently, if there is an indicator of impairment, the impairment is recognized.  In evaluating these investments for impairment, the Company uses inputs including pre- and post-money valuations of recent financing events and the impact of those on its fully diluted ownership percentages, as well as other available information regarding the issuer's historical and forecasted performance.  As these investments are early-stage companies which are not publicly traded, it is not practicable for the Company to reliably estimate the fair value of these investments.

[0001571996-17-000004:notes:264]
Carrying Value and Estimated Fair Value of Outstanding Debt — The following table summarizes the carrying value and estimated fair value of the Company's outstanding debt as described in Note 8 of the Notes to the Consolidated Financial Statements, including the current portion, as of the dates indicated:

[0001571996-17-000004:notes:265]
|  | February 3, 2017 |  | January 29, 2016 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Term Loan Facilities | $ | — |  |  | $ | — |  |  | $ | 6.1 |  |  | $ | 6.2 |  |
| Senior Secured Credit Facilities | $ | 11.4 |  |  | $ | 11.7 |  |  | $ | — |  |  | $ | — |  |
| Senior First Lien Notes | $ | — |  |  | $ | — |  |  | $ | 1.4 |  |  | $ | 1.5 |  |
| First Lien Notes | $ | 19.7 |  |  | $ | 21.8 |  |  | $ | — |  |  | $ | — |  |
| Unsecured Notes and Debentures | $ | 2.3 |  |  | $ | 2.5 |  |  | $ | 2.7 |  |  | $ | 2.7 |  |
| Senior Notes | $ | 3.1 |  |  | $ | 3.5 |  |  | $ | — |  |  | $ | — |  |
| EMC Notes | $ | 5.5 |  |  | $ | 5.4 |  |  | $ | — |  |  | $ | — |  |
| Bridge Facilities | $ | 4.0 |  |  | $ | 4.0 |  |  | $ | — |  |  | $ | — |  |

[0001571996-17-000004:notes:266]
The fair values of the outstanding Term Loan Facilities and Senior First Lien Notes obtained in connection with the going-private transaction, the outstanding Unsecured Notes and Debentures issued prior to the going-private transaction, the outstanding EMC Notes that remained outstanding after the EMC merger transaction, and the outstanding First Lien Notes, Senior Notes, Senior Secured Credit Facilities, and Bridge Facilities issued in connection with the EMC merger transaction were determined based on observable market prices in a less active market and were categorized as Level 2 in the fair value hierarchy.  The fair values of the other short-term debt and the structured financing debt approximate their carrying values due to their short-term maturities.


## us-gaap:FinancingReceivableCreditQualityIndicatorsTableTextBlock

[0001571996-17-000004:notes:267]
The following table summarizes customer receivables, gross, including accrued interest, by credit quality indicator segregated by class, as of February 3, 2017 and January 29, 2016.  The categories shown in the table below segregate customer receivables based on the relative degrees of credit risk.  The credit quality indicators for DPA revolving accounts are measured primarily as of each quarter-end date, while all other indicators are generally updated on a periodic basis.

[0001571996-17-000004:notes:268]
For DPA revolving receivables shown in the table below, the Company makes credit decisions based on proprietary scorecards, which include the customer's credit history, payment history, credit usage, and other credit agency-related elements.  The higher quality category includes prime accounts generally of a higher credit quality that are comparable to U.S. customer FICO scores of 720 or above.  The mid-category represents the mid-tier accounts that are comparable to U.S. customer FICO scores from 660 to 719.  The lower category is generally sub-prime and represents lower credit quality accounts that are comparable to U.S. customer FICO scores below 660.  For the DBC revolving receivables and fixed-term commercial receivables shown in the table below, an internal grading system is utilized that assigns a credit level score based on a number of considerations, including liquidity, operating performance, and industry outlook.  The grading criteria and classifications for the fixed-term products differ from those for the revolving products as loss experience varies between these product and customer groups.  The credit quality categories cannot be compared between the different classes as loss experience varies substantially between the classes.

[0001571996-17-000004:notes:269]
|  | February 3, 2017 |  | January 29, 2016 |
|  | Higher |  | Mid |  | Lower |  | Total |  | Higher |  | Mid |  | Lower |  | Total |
|  | (in millions) |
| Revolving — DPA | $ | 136 |  |  | $ | 244 |  |  | $ | 428 |  |  | $ | 808 |  |  | $ | 148 |  |  | $ | 270 |  |  | $ | 529 |  |  | $ | 947 |  |
| Revolving — DBC | $ | 61 |  |  | $ | 60 |  |  | $ | 80 |  |  | $ | 201 |  |  | $ | 68 |  |  | $ | 65 |  |  | $ | 93 |  |  | $ | 226 |  |
| Fixed-term — Consumer and Small Commercial | $ | 114 |  |  | $ | 155 |  |  | $ | 107 |  |  | $ | 376 |  |  | $ | 93 |  |  | $ | 136 |  |  | $ | 100 |  |  | $ | 329 |  |
| Fixed-term — Medium and Large Commercial | $ | 2,165 |  |  | $ | 1,242 |  |  | $ | 747 |  |  | $ | 4,154 |  |  | $ | 1,597 |  |  | $ | 1,075 |  |  | $ | 636 |  |  | $ | 3,308 |  |


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0001571996-17-000004:notes:270]
The majority of the Company's international sales are made by international subsidiaries, most of which have the U.S. dollar as their functional currency.  The Company's subsidiaries that do not have the U.S. dollar as their functional currency translate assets and liabilities at current rates of exchange in effect at the balance sheet date.  Revenue and expenses from these international subsidiaries are translated using the monthly average exchange rates in effect for the period in which the transactions occur.  Foreign currency translation adjustments are included as a component of accumulated other comprehensive income (loss) ("OCI") in stockholders' equity.

[0001571996-17-000004:notes:271]
Local currency transactions of international subsidiaries that have the U.S. dollar as the functional currency are remeasured into U.S. dollars using the current rates of exchange for monetary assets and liabilities and historical rates of exchange for non-monetary assets and liabilities.  Gains and losses from remeasurement of monetary assets and liabilities are included in interest and other, net.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001571996-17-000004:notes:272]
GOODWILL AND INTANGIBLE ASSETS

[0001571996-17-000004:notes:273]
Goodwill

[0001571996-17-000004:notes:274]
The following table presents goodwill allocated to the Company's business segments as of February 3, 2017, January 29, 2016, and January 30, 2015, and changes in the carrying amount of goodwill for the respective periods:

[0001571996-17-000004:notes:275]
|  | Client Solutions Group |  | Infrastructure Solutions Group |  | VMware |  | Other Businesses (a) |  | Total |
|  | (in millions) |
| Balances as of January 30, 2015 | $ | 4,428 |  |  | $ | 3,907 |  |  | $ | — |  |  | $ | 71 |  |  | $ | 8,406 |  |
| Goodwill recognized during the period | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Adjustments | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Balances as of January 29, 2016 | 4,428 |  |  | 3,907 |  |  | — |  |  | 71 |  |  | 8,406 |  |
| Goodwill acquired (b) | — |  |  | 12,872 |  |  | 15,070 |  |  | 3,597 |  |  | 31,539 |  |
| Impact of foreign currency translation | — |  |  | (169 | ) |  | — |  |  | (32 | ) |  | (201 | ) |
| Goodwill divested (c) | — |  |  | (834 | ) |  | — |  |  | — |  |  | (834 | ) |
| Other adjustments (d) | (191 | ) |  | (169 | ) |  | — |  |  | 360 |  |  | — |  |
| Balances as of February 3, 2017 | $ | 4,237 |  |  | $ | 15,607 |  |  | $ | 15,070 |  |  | $ | 3,996 |  |  | $ | 38,910 |  |

[0001571996-17-000004:notes:276]
| (a) | Other Businesses, previously referred to as Corporate, consists of offerings by RSA Information Security, SecureWorks, Pivotal, and Boomi, Inc. ("Boomi"). |

[0001571996-17-000004:notes:277]
| (b) | In connection with the EMC merger transaction on September 7, 2016, the Company recorded approximately $31.5 billion in goodwill, which has been preliminarily allocated to ISG, VMware, and Other Businesses. This amount represents the excess of the purchase price over the fair value of the tangible and intangible assets acquired and liabilities assumed with this transaction. See Note 3 of the Notes to the Consolidated Financial Statements for additional information on the EMC merger transaction as well as adjustments that impacted goodwill. |

[0001571996-17-000004:notes:278]
| (c) | Goodwill divested represents goodwill attributable to ECD, which was acquired as a part of the EMC merger transaction and subsequently divested. See Note 4 of the Notes to the Consolidated Financial Statements for additional information on the ECD divestiture. |

[0001571996-17-000004:notes:279]
| (d) | Following the completion of the SecureWorks IPO during the fiscal year ended February 3, 2017, goodwill attributable to the SecureWorks business was re-allocated in a manner consistent with goodwill recognized by SecureWorks on a stand-alone basis. |

[0001571996-17-000004:notes:280]
Goodwill and indefinite-lived intangible assets are tested for impairment annually during the third fiscal quarter and whenever events or circumstances may indicate that an impairment has occurred.  Based on the results of the annual impairment test, which was a qualitative test, no impairment of goodwill or indefinite-lived intangible assets existed for any reporting unit as of October 28, 2016.  No events or circumstances transpired subsequent to the annual impairment test that would indicate a potential impairment of goodwill as of February 3, 2017.  Further, the Company did not have any accumulated goodwill impairment charges as of February 3, 2017.

[0001571996-17-000004:notes:281]
Management exercised significant judgment related to the above assessment, including the identification of goodwill reporting units, assignment of assets and liabilities to goodwill reporting units, assignment of goodwill to reporting units, and determination of the fair value of each goodwill reporting unit.  The fair value of each goodwill reporting unit is generally estimated using a discounted cash flow methodology.  This analysis requires significant judgments, including estimation of future cash flows, which is dependent on internal forecasts, the estimation of the long-term growth rate of the Company's business, and the determination of the Company's weighted average cost of capital.  Changes in these estimates and assumptions could materially affect the fair value of the goodwill reporting unit, potentially resulting in a non-cash impairment charge.

[0001571996-17-000004:notes:282]
Intangible Assets

[0001571996-17-000004:notes:283]
The Company's intangible assets as of February 3, 2017 and January 29, 2016 were as follows:

[0001571996-17-000004:notes:284]
|  | February 3, 2017 |  | January 29, 2016 |
|  | Gross |  | AccumulatedAmortization |  | Net |  | Gross |  | AccumulatedAmortization |  | Net |
|  | (in millions) |
| Customer relationships | $ | 22,708 |  |  | $ | (5,552 | ) |  | $ | 17,156 |  |  | $ | 9,869 |  |  | $ | (3,600 | ) |  | $ | 6,269 |  |
| Developed technology | 14,569 |  |  | (2,510 | ) |  | 12,059 |  |  | 1,536 |  |  | (871 | ) |  | 665 |  |
| Trade names | 1,268 |  |  | (201 | ) |  | 1,067 |  |  | 318 |  |  | (110 | ) |  | 208 |  |
| Leasehold assets (liabilities) | 128 |  |  | (1 | ) |  | 127 |  |  | — |  |  | — |  |  | — |  |
| Definite-lived intangible assets | 38,673 |  |  | (8,264 | ) |  | 30,409 |  |  | 11,723 |  |  | (4,581 | ) |  | 7,142 |  |
| In-process research and development | 890 |  |  | — |  |  | 890 |  |  | — |  |  | — |  |  | — |  |
| Indefinite-lived trade names | 3,754 |  |  | — |  |  | 3,754 |  |  | 1,435 |  |  | — |  |  | 1,435 |  |
| Total intangible assets | $ | 43,317 |  |  | $ | (8,264 | ) |  | $ | 35,053 |  |  | $ | 13,158 |  |  | $ | (4,581 | ) |  | $ | 8,577 |  |

[0001571996-17-000004:notes:285]
In connection with the EMC merger transaction on September 7, 2016, the Company recorded approximately $31.2 billion of identifiable intangible assets, which represents the respective fair values as of the transaction date.  Of that amount, approximately $1.1 billion related to the ECD was subsequently divested and is therefore excluded from the above table.  See Note 3 and Note 4 of the Notes to the Consolidated Financial Statements for additional information on the EMC merger transaction and the ECD divestiture, respectively.

[0001571996-17-000004:notes:286]
Amortization expense related to definite-lived intangible assets was approximately $3.7 billion, $2.0 billion, and $2.1 billion during the fiscal years ended February 3, 2017, January 29, 2016, and January 30, 2015, respectively.  There were no material impairment charges related to intangible assets during the fiscal years ended February 3, 2017, January 29, 2016, and January 30, 2015.

[0001571996-17-000004:notes:287]
Estimated future annual pre-tax amortization expense of definite-lived intangible assets as of February 3, 2017 over the next five fiscal years and thereafter is as follows:

[0001571996-17-000004:notes:288]
| Fiscal Years |  | (in millions) |
| 2018 |  | $ | 6,826 |  |
| 2019 |  | 5,895 |  |
| 2020 |  | 4,100 |  |
| 2021 |  | 3,204 |  |
| 2022 |  | 2,529 |  |
| Thereafter |  | 7,855 |  |
| Total |  | $ | 30,409 |  |


## us-gaap:GoodwillAndIntangibleAssetsPolicyTextBlock

[0001571996-17-000004:notes:289]
Identifiable intangible assets with finite lives are amortized over their estimated useful lives.  In addition, intangible assets are reviewed for impairment if indicators of potential impairment exist.  Goodwill and indefinite-lived intangible assets are tested for impairment on an annual basis in the third fiscal quarter, or sooner if an indicator of impairment occurs.


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsPolicyTextBlock

[0001571996-17-000004:notes:290]
The Company reviews long-lived assets for impairment when circumstances indicate the carrying amount of an asset may not be recoverable based on the undiscounted future cash flows of the assets.  If the carrying amount of the asset is determined not to be recoverable, a write-down to fair value is recorded.  Fair values are determined based on quoted market values, discounted cash flows, or external appraisals, as applicable.  The Company reviews long-lived assets for impairment at the individual asset or the asset group level for which the lowest level of independent cash flows can be identified.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001571996-17-000004:notes:291]
INCOME AND OTHER TAXES

[0001571996-17-000004:notes:292]
The Company's provision for income taxes for the fiscal periods reflected in the Consolidated Financial Statements are not directly comparable primarily due to purchase accounting adjustments, interest charges, and stock-based compensation charges incurred as a result of the EMC merger transaction.  For more information regarding the EMC merger transaction, see Note 3 of the Notes to the Consolidated Financial Statements.

[0001571996-17-000004:notes:293]
The provision (benefit) for income taxes from continuing operations consisted of the following for the respective periods:

[0001571996-17-000004:notes:294]
|  | Fiscal Year Ended |
|  | February 3, 2017 |  | January 29, 2016 |  | January 30, 2015 |
|  | (in millions) |
| Current: |  |  |  |  |  |
| Federal | $ | (139 | ) |  | $ | (174 | ) |  | $ | 56 |  |
| State/local | 46 |  |  | (2 | ) |  | (4 | ) |
| Foreign | 322 |  |  | 228 |  |  | 184 |  |
| Current | 229 |  |  | 52 |  |  | 236 |  |
| Deferred: |  |  |  |  |  |
| Federal | (1,676 | ) |  | (119 | ) |  | (298 | ) |
| State/local | (120 | ) |  | (15 | ) |  | (19 | ) |
| Foreign | (52 | ) |  | (36 | ) |  | (26 | ) |
| Deferred | (1,848 | ) |  | (170 | ) |  | (343 | ) |
| Provision (benefit) for income taxes | $ | (1,619 | ) |  | $ | (118 | ) |  | $ | (107 | ) |

[0001571996-17-000004:notes:295]
The Company's income (loss) from continuing operations before income taxes consisted of the following for the respective periods:

[0001571996-17-000004:notes:296]
|  | Fiscal Year Ended |
|  | February 3, 2017 |  | January 29, 2016 |  | January 30, 2015 |
|  | (in millions) |
| Domestic | $ | (7,173 | ) |  | $ | (3,498 | ) |  | $ | (3,135 | ) |
| Foreign | 1,817 |  |  | 2,212 |  |  | 1,920 |  |
| Loss from continuing operations before income taxes | $ | (5,356 | ) |  | $ | (1,286 | ) |  | $ | (1,215 | ) |

[0001571996-17-000004:notes:297]
The components of the Company's net deferred tax assets (liabilities) were as follows as of February 3, 2017 and January 29, 2016:

[0001571996-17-000004:notes:298]
|  | February 3, 2017 |  | January 29, 2016 |
|  | (in millions) |
| Deferred tax assets: |  |  |  |
| Deferred revenue and warranty provisions | $ | 1,955 |  |  | $ | 814 |  |
| Provisions for product returns and doubtful accounts | 131 |  |  | 130 |  |
| Credit carryforwards | 511 |  |  | 176 |  |
| Loss carryforwards | 372 |  |  | 744 |  |
| Operating and compensation related accruals | 765 |  |  | 269 |  |
| Other | 262 |  |  | 149 |  |
| Deferred tax assets | 3,996 |  |  | 2,282 |  |
| Valuation allowance | (737 | ) |  | (816 | ) |
| Deferred tax assets, net of valuation allowance | 3,259 |  |  | 1,466 |  |
| Deferred tax liabilities: |  |  |  |
| Leasing and financing | (109 | ) |  | (125 | ) |
| Property and equipment | (743 | ) |  | (169 | ) |
| Acquired intangibles | (7,281 | ) |  | (1,568 | ) |
| Other | (38 | ) |  | (237 | ) |
| Deferred tax liabilities | (8,171 | ) |  | (2,099 | ) |
| Net deferred tax assets (liabilities) | $ | (4,912 | ) |  | $ | (633 | ) |

[0001571996-17-000004:notes:299]
The tables below summarize the net operating loss carryforwards, tax credit carryforwards, and other deferred tax assets with related valuation allowances recognized as of February 3, 2017 and January 29, 2016.

[0001571996-17-000004:notes:300]
|  | February 3, 2017 |
|  | Deferred Tax Assets |  | Valuation Allowance |  | Net Deferred Tax Assets |  | First Year Expiring |
|  | (in millions) |
| Credit carryforwards | $ | 511 |  |  | $ | (406 | ) |  | $ | 105 |  |  | Fiscal 2018 |
| Loss carryforwards | 372 |  |  | (205 | ) |  | 167 |  |  | Fiscal 2018 |
| Other deferred tax assets | 3,113 |  |  | (126 | ) |  | 2,987 |  |  | NA |
| Total | $ | 3,996 |  |  | $ | (737 | ) |  | $ | 3,259 |  |  |  |
|  | January 29, 2016 |
|  | Deferred Tax Assets |  | Valuation Allowance |  | Net Deferred Tax Assets |  | First Year Expiring |
|  | (in millions) |
| Credit carryforwards | $ | 176 |  |  | $ | (59 | ) |  | $ | 117 |  |  | Fiscal 2017 |
| Loss carryforwards | 744 |  |  | (614 | ) |  | 130 |  |  | Fiscal 2017 |
| Other deferred tax assets | 1,362 |  |  | (143 | ) |  | 1,219 |  |  | NA |
| Total | $ | 2,282 |  |  | $ | (816 | ) |  | $ | 1,466 |  |  |  |

[0001571996-17-000004:notes:301]
The Company had deferred tax assets related to federal, state, and foreign net operating loss carryforwards of $132 million, $62 million, and $178 million, respectively, as of February 3, 2017, and $97 million, $49 million, and $598 million, respectively, as of January 29, 2016.  The decrease in foreign net operating loss carryforwards is due to the reversal of a foreign exchange loss for tax purposes only, recorded for the year ended January 29, 2016 in a jurisdiction subject to a full valuation allowance, and as a result it is not reflected in the U.S. GAAP rate reconciliation below.  The Company's credit carryforwards as of February 3, 2017 and January 29, 2016 relate primarily to U.S. tax credits.  The valuation allowances for other deferred tax assets as of February 3, 2017 and January 29, 2016 are primarily related to foreign jurisdictions.  The Company has determined that it will be able to realize the remainder of its deferred tax assets, based on the future reversal of deferred tax liabilities.

[0001571996-17-000004:notes:302]
In connection with the EMC merger transaction, the Company acquired $6.5 billion of net deferred tax liabilities, which are included in other non-current assets and other non-current liabilities in the Consolidated Statements of Financial Position.  The Company has not provided deferred taxes on undistributed earnings and other basis differences of its foreign subsidiaries as it is the Company's intention for these to remain permanently reinvested.  Determination of the amount of unrecognized deferred income tax liability related to these earnings is not practicable.  The basis differences in the amount of approximately $79.2 billion as of February 3, 2017 arose primarily from undistributed book earnings, which the Company intends to reinvest indefinitely, and purchase accounting adjustments.  The basis differences could be reversed through a sale of the subsidiaries or the receipt of dividends from the subsidiaries, as well as various other events.

[0001571996-17-000004:notes:303]
A portion of the Company's operations is subject to a reduced tax rate or is free of tax under various tax holidays.  For the fiscal years ended February 3, 2017, January 29, 2016, and January 30, 2015, the income tax benefits attributable to the tax status of these subsidiaries were estimated to be approximately $369 million ($0.79 per share of DHI Group Common Stock), $205 million ($0.51 per share), and $218 million ($0.54 per share), respectively.  These income tax benefits are included in tax impact of foreign operations in the table below.  Although a significant portion of these income tax benefits relate to a tax holiday that expired during the fiscal year ended February 3, 2017, the Company has negotiated new terms for the affected subsidiary.  These new terms provide for a reduced income tax rate and will be effective for a two-year bridge period expiring in January 2019.  The Company's other tax holidays will expire in whole or in part during Fiscal 2019 through Fiscal 2023.  Many of these tax holidays and reduced tax rates may be extended when certain conditions are met or may be terminated early if certain conditions are not met.

[0001571996-17-000004:notes:304]
A reconciliation of the Company's income tax benefit from continuing operations to the statutory U.S. federal tax rate is as follows:

[0001571996-17-000004:notes:305]
|  | Fiscal Year Ended |
|  | February 3, 2017 |  | January 29, 2016 |  | January 30, 2015 |
| U.S. federal statutory rate | 35.0 | % |  | 35.0 | % |  | 35.0 | % |
| State income taxes, net of federal tax benefit | 2.7 |  |  | 1.9 |  |  | 2.5 |  |
| Tax impact of foreign operations | (4.9 | ) |  | (33.4 | ) |  | (25.5 | ) |
| Change in valuation allowance impacting tax rate and non-deductible operating losses | (1.1 | ) |  | 4.2 |  |  | (7.9 | ) |
| IRS tax audit settlement | 5.5 |  |  | — |  |  | — |  |
| Vendor and other settlements | 0.5 |  |  | 2.5 |  |  | 3.1 |  |
| Non-deductible transaction-related costs | (2.1 | ) |  | (0.6 | ) |  | — |  |
| Other | (5.4 | ) |  | (0.4 | ) |  | 1.6 |  |
| Total | 30.2 | % |  | 9.2 | % |  | 8.8 | % |

[0001571996-17-000004:notes:306]
A reconciliation of the Company's beginning and ending amount of unrecognized tax benefits is as follows:

[0001571996-17-000004:notes:307]
|  | Total |
|  | (in millions) |
| Balance as of January 31, 2014 | $ | 2,463 |  |
| Increases related to tax positions of the current year | 142 |  |
| Increases related to tax position of prior years | 14 |  |
| Reductions for tax positions of prior years | (80 | ) |
| Lapse of statute of limitations | (34 | ) |
| Audit settlements | (50 | ) |
| Balance as of January 30, 2015 | 2,455 |  |
| Increases related to tax positions of the current year | 70 |  |
| Increases related to tax position of prior years | 52 |  |
| Reductions for tax positions of prior years | (61 | ) |
| Lapse of statute of limitations | (24 | ) |
| Audit settlements | (13 | ) |
| Balance as of January 29, 2016 | 2,479 |  |
| Unrecognized tax benefits assumed through EMC merger transaction | 558 |  |
| Increases related to tax positions of the current year | 116 |  |
| Increases related to tax position of prior years | 227 |  |
| Reductions for tax positions of prior years | (379 | ) |
| Lapse of statute of limitations | (30 | ) |
| Audit settlements | (219 | ) |
| Balance as of February 3, 2017 | $ | 2,752 |  |

[0001571996-17-000004:notes:308]
During the fiscal year ended February 3, 2017, the Company acquired $558 million of unrecognized tax benefits as a part of the EMC merger transaction.  The Company's net unrecognized tax benefits were $3.1 billion as of February 3, 2017 and January 29, 2016, and are included in other non-current liabilities in the Consolidated Statements of Financial Position.

[0001571996-17-000004:notes:309]
The unrecognized tax benefits in the table above include $2.3 billion and $2.1 billion as of February 3, 2017 and January 29, 2016, respectively, that if recognized, would have impacted income tax expense, and do not include accrued interest and penalties of $737 million and $950 million as of February 3, 2017 and January 29, 2016, respectively.  These interest and penalties are offset by tax benefits primarily from interest deductions which are not included in the table above.  As of February 3, 2017 and January 29, 2016, respectively, these benefits were $286 million and $372 million, respectively.  Interest and penalties related to income tax liabilities are included in income tax expense.  The Company recorded interest and penalties of $94 million, $63 million, and $35 million for the fiscal years ended February 3, 2017, January 29, 2016, and January 30, 2015, respectively.

[0001571996-17-000004:notes:310]
Judgment is required in evaluating the Company's uncertain tax positions and determining the Company's provision for income taxes.  The Company does not anticipate a significant change to the total amount of unrecognized tax benefits within the next twelve months.

[0001571996-17-000004:notes:311]
During the fiscal year ended February 3, 2017, the Company effectively settled the Internal Revenue Service ("IRS") audit for fiscal years 2004 through 2006.  As a result, during Fiscal 2017, the Company made a cash payment of $537 million and recorded a net income tax benefit of $297 million.  The net income tax benefit had an impact of 5.5% on the effective tax rate.

[0001571996-17-000004:notes:312]
The Company's U.S. federal income tax returns for fiscal years 2007 through 2009 are currently under examination by the IRS, which issued a Revenue Agent's Report ("RAR") related to those years during the fiscal year ended February 3, 2017.  The IRS has proposed adjustments primarily relating to transfer pricing matters with which the Company disagrees and will contest through the IRS administrative appeals procedures.  Prior to the EMC merger transaction, EMC received an RAR for its tax years 2009 and 2010.  The Company also disagrees with certain proposed adjustments in this RAR and is currently contesting the proposed adjustments through the IRS administrative appeals process.

[0001571996-17-000004:notes:313]
The Company is also currently under income tax audits in various state and foreign jurisdictions.  The Company is undergoing negotiations, and in some cases contested proceedings, relating to tax matters with the taxing authorities in these jurisdictions.  The Company believes that it has provided adequate reserves related to all matters contained in tax periods open to examination.  Although the Company believes it has made adequate provisions for the uncertainties surrounding these audits, should the Company experience unfavorable outcomes, such outcomes could have a material impact on its results of operations, financial position, and cash flows.  With respect to major U.S. state and foreign taxing jurisdictions, the Company is generally not subject to tax examinations for years prior to fiscal year 2000.

[0001571996-17-000004:notes:314]
The Company takes certain non-income tax positions in the jurisdictions in which it operates and has received certain non-income tax assessments from various jurisdictions.  The Company believes that a material loss in these matters is not probable and that it is not reasonably possible that a material loss exceeding amounts already accrued has been incurred.  The Company believes its positions in these non-income tax litigation matters are supportable and that it ultimately will prevail.  In the normal course of business, the Company's positions and conclusions related to its non-income taxes could be challenged and assessments may be made.  To the extent new information is obtained and the Company's views on its positions, probable outcomes of assessments, or litigation change, changes in estimates to the Company's accrued liabilities would be recorded in the period in which such a determination is made.  In the resolution process for income tax and non-income tax audits, the Company may be required to provide collateral guarantees or indemnification to regulators and tax authorities until the matter is resolved.


## us-gaap:IncomeTaxPolicyTextBlock

[0001571996-17-000004:notes:315]
Deferred tax assets and liabilities are recorded based on the difference between the financial statement and tax basis of assets and liabilities using enacted tax rates in effect for the year in which the differences are expected to reverse.  The Company calculates a provision for income taxes using the asset and liability method, under which deferred tax assets and liabilities are recognized by identifying the temporary differences arising from the different treatment of items for tax and accounting purposes.  The Company provides valuation allowances for deferred tax assets, where appropriate.  In assessing the need for a valuation allowance, the Company considers all available evidence for each jurisdiction, including past operating results, estimates of future taxable income, and the feasibility of ongoing tax planning strategies.  In the event the Company determines that all or part of the net deferred tax assets are not realizable in the future, the Company will make an adjustment to the valuation allowance that would be charged to earnings in the period in which such determination is made.


## us-gaap:InventoryPolicyTextBlock

[0001571996-17-000004:notes:316]
Inventories are stated at the lower of cost or market with cost being determined on a first-in, first-out basis.  Adjustments to reduce the cost of inventory to its net realizable value are made, if required, for estimated excess, obsolescence, or impaired balances.


## us-gaap:InvestmentPolicyTextBlock

[0001571996-17-000004:notes:317]
All debt security investments with effective maturities in excess of one year and substantially all equity and other securities are recorded as long-term investments in the Consolidated Statements of Financial Position.  In comparison, debt security instruments with a remaining maturity shorter than one year are classified as short-term investments in the Consolidated Statements of Financial Position.

[0001571996-17-000004:notes:318]
Unrealized gain and loss positions on investments classified as available-for-sale are included within accumulated other comprehensive income (loss), net of any related tax effect.  Realized gains and losses and other-than-temporary impairments are reclassified from accumulated other comprehensive income (loss) to interest and other, net.  Investments accounted for under the cost method are recorded at cost initially, which approximates fair value.  Subsequently, if there is an indicator of impairment, the impairment is recognized in interest and other, net in the Consolidated Statements of Income (Loss).


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0001571996-17-000004:notes:319]
FINANCIAL SERVICES

[0001571996-17-000004:notes:320]
Dell Financial Services

[0001571996-17-000004:notes:321]
The Company offers or arranges various financing options and services for its business and consumer customers in the United States, Canada, Europe, and Mexico through Dell Financial Services and its affiliates (collectively, "DFS").  The key activities of DFS include the origination, collection, and servicing of customer receivables primarily related to the purchase of Dell Technologies' products and services.  New financing originations, which represent the amounts of financing provided by DFS to customers for equipment and related software and services, including third-party originations, were $4.5 billion for the fiscal year ended February 3, 2017, and $3.7 billion for both the fiscal years ended January 29, 2016 and January 30, 2015.

[0001571996-17-000004:notes:322]
In connection with the EMC merger transaction, the Company acquired an existing financing receivable portfolio, which is included in the fixed-term customer receivables balance in the table below.  See Note 3 of the Notes to the Consolidated Financial Statements for more information about the financing receivables acquired.

[0001571996-17-000004:notes:323]
The Company's financing receivables are aggregated into the following categories:

[0001571996-17-000004:notes:324]
| • | Revolving loans — Revolving loans offered under private label credit financing programs provide qualified customers with a revolving credit line for the purchase of products and services offered by Dell. These private label credit financing programs are referred to as Dell Preferred Account ("DPA") and Dell Business Credit ("DBC"). The DPA product is primarily offered to individual consumer customers, and the DBC product is primarily offered to small and medium-sized commercial customers. Revolving loans in the United States bear interest at a variable annual percentage rate that is tied to the prime rate. Based on historical payment patterns, revolving loan transactions are typically repaid within twelve months on average. |

[0001571996-17-000004:notes:325]
| • | Fixed-term sales-type leases and loans — The Company enters into sales-type lease arrangements with customers who desire lease financing. Leases with business customers have fixed terms of generally two to four years. Future maturities of minimum lease payments as of February 3, 2017 were as follows: Fiscal 2018 - $1,737 million; Fiscal 2019 - $1,080 million; Fiscal 2020 - $514 million; Fiscal 2021 - $130 million; Fiscal 2022 and beyond - $26 million. The Company also offers fixed-term loans to qualified small businesses, large commercial accounts, governmental organizations, educational entities, and certain individual consumer customers. These loans are repaid in equal payments including interest and have defined terms of generally three to five years. |

[0001571996-17-000004:notes:326]
The following table summarizes the components of the Company's financing receivables segregated by portfolio segment as of February 3, 2017 and January 29, 2016:

[0001571996-17-000004:notes:327]
|  | February 3, 2017 |  | January 29, 2016 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Financing Receivables, net: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer receivables, gross | $ | 1,009 |  |  | $ | 4,530 |  |  | $ | 5,539 |  |  | $ | 1,173 |  |  | $ | 3,637 |  |  | $ | 4,810 |  |
| Allowances for losses | (91 | ) |  | (52 | ) |  | (143 | ) |  | (118 | ) |  | (58 | ) |  | (176 | ) |
| Customer receivables, net | 918 |  |  | 4,478 |  |  | 5,396 |  |  | 1,055 |  |  | 3,579 |  |  | 4,634 |  |
| Residual interest | — |  |  | 477 |  |  | 477 |  |  | — |  |  | 458 |  |  | 458 |  |
| Financing receivables, net | $ | 918 |  |  | $ | 4,955 |  |  | $ | 5,873 |  |  | $ | 1,055 |  |  | $ | 4,037 |  |  | $ | 5,092 |  |
| Short-term | $ | 918 |  |  | $ | 2,304 |  |  | $ | 3,222 |  |  | $ | 1,055 |  |  | $ | 1,860 |  |  | $ | 2,915 |  |
| Long-term | $ | — |  |  | $ | 2,651 |  |  | $ | 2,651 |  |  | $ | — |  |  | $ | 2,177 |  |  | $ | 2,177 |  |

[0001571996-17-000004:notes:328]
The following table summarizes the aging of the Company's customer financing receivables, gross, including accrued interest, as of February 3, 2017 and January 29, 2016, segregated by class:

[0001571996-17-000004:notes:329]
|  | February 3, 2017 |  | January 29, 2016 |
|  | Current |  | Past Due 1 — 90 Days |  | Past Due > 90 Days |  | Total |  | Current |  | Past Due 1 — 90 Days |  | Past Due > 90 Days |  | Total |
|  | (in millions) |
| Revolving — DPA | $ | 715 |  |  | $ | 66 |  |  | $ | 27 |  |  | $ | 808 |  |  | $ | 812 |  |  | $ | 99 |  |  | $ | 36 |  |  | $ | 947 |  |
| Revolving — DBC | 175 |  |  | 22 |  |  | 4 |  |  | 201 |  |  | 202 |  |  | 20 |  |  | 4 |  |  | 226 |  |
| Fixed-term — Consumer and Small Commercial | 340 |  |  | 34 |  |  | 2 |  |  | 376 |  |  | 315 |  |  | 13 |  |  | 1 |  |  | 329 |  |
| Fixed-term — Medium and Large Commercial | 3,654 |  |  | 472 |  |  | 28 |  |  | 4,154 |  |  | 3,131 |  |  | 171 |  |  | 6 |  |  | 3,308 |  |
| Total customer receivables, gross | $ | 4,884 |  |  | $ | 594 |  |  | $ | 61 |  |  | $ | 5,539 |  |  | $ | 4,460 |  |  | $ | 303 |  |  | $ | 47 |  |  | $ | 4,810 |  |

[0001571996-17-000004:notes:330]
Credit Quality

[0001571996-17-000004:notes:331]
Structured Financing Debt

[0001571996-17-000004:notes:332]
The Company maintains programs which facilitate the funding of financing receivables in the capital markets in the United States, Canada, and Europe.  The Company's total structured financing debt, which is collateralized by financing receivables, was $3.5 billion and $3.4 billion as of February 3, 2017 and January 29, 2016, respectively, under the following programs.

[0001571996-17-000004:notes:333]
| • | Securitization Programs — The Company maintains securitization programs in the United States and Europe. The securitization programs in the United States include the fixed-term lease and loan securitization program and the revolving loan securitization program. The outstanding balance of debt under these U.S. programs was $1.5 billion and $1.3 billion as of February 3, 2017 and January 29, 2016, respectively. This debt is collateralized solely by the U.S. financing receivables in the programs. The debt has a variable interest rate and the duration of this debt is based on the terms of the underlying financing receivables. As of February 3, 2017, the total debt capacity related to the U.S. securitization programs was $2.1 billion. The Company enters into interest swap agreements to effectively convert the portion of its structured financing debt from a floating rate to a fixed rate. See Note 9 of the Notes to the Consolidated Financial Statements for additional information about interest rate swaps. |

[0001571996-17-000004:notes:334]
The Company's U.S. securitization programs became effective on October 29, 2013.  The revolving program, which was extended during the third quarter of Fiscal 2017, is effective for four and one-half years beginning October 29, 2013.  The fixed term program, which was extended during the first quarter of Fiscal 2016, is effective for four and one-half years beginning October 29, 2013.

[0001571996-17-000004:notes:335]
The Company established a securitization program in Europe for fixed-term leases and loans.  This program became effective on January 13, 2017, and is effective for two years.  The outstanding balance of debt under this program was $233 million as of February 3, 2017, and the total debt capacity related to the securitization program was $646 million.

[0001571996-17-000004:notes:336]
The securitization programs contain standard structural features related to the performance of the securitized receivables which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the program, no further funding of receivables will be permitted and the timing of the Company's expected cash flows from over-collateralization will be delayed.  As of February 3, 2017, these criteria were met.

[0001571996-17-000004:notes:337]
| • | Fixed Term Securitization Programs — The Company may periodically issue asset-backed debt securities under fixed term securitization programs to private investors. As of February 3, 2017 and January 29, 2016, the associated debt balance of these securities was $1.4 billion and $1.6 billion, respectively. The asset-backed debt securities are collateralized solely by the U.S. fixed-term financing receivables in the offerings, which are held by SPEs. The interest rate on these securities is fixed and ranges from 0.42% to 3.61% and the duration of these securities is based on the terms of the underlying financing receivables. |

[0001571996-17-000004:notes:338]
| • | Other Structured Financing Programs — In connection with the Company's international financing operations, the Company has entered into revolving structured financing debt programs related to its fixed-term lease and loan products sold in Canada and Europe. The aggregate outstanding balances of the Canadian and European revolving structured loans as of February 3, 2017 and January 29, 2016 were $382 million and $559 million, respectively. As of February 3, 2017, the Canadian program, which was extended during the fiscal year ended February 3, 2017, had a total debt capacity of $169 million. This program is effective for two years, beginning on April 15, 2016, and is collateralized solely by the Canadian financing receivables. The European program, which was extended during the first quarter of Fiscal 2016, is now effective for four years, beginning on December 23, 2013. The program is collateralized solely by the European financing receivables and had a total debt capacity of $323 million as of February 3, 2017. |

[0001571996-17-000004:notes:339]
Variable Interest Entities

[0001571996-17-000004:notes:340]
In connection with the securitization programs discussed above, the Company transfers certain U.S. and European customer financing receivables to Special Purpose Entities ("SPEs") that meet the definition of a Variable Interest Entity ("VIE") and are consolidated, along with the associated debt, into the Consolidated Financial Statements, as the Company is the primary beneficiary of those VIEs.  These SPEs are bankruptcy-remote legal entities with separate assets and liabilities.  The purpose of these SPEs is to facilitate the funding of customer receivables in the capital markets.

[0001571996-17-000004:notes:341]
The following table shows financing receivables held by the consolidated VIEs as of the respective dates:

[0001571996-17-000004:notes:342]
|  | February 3, 2017 |  | January 29, 2016 |
|  | (in millions) |
| Financing receivables held by consolidated VIEs, net: |  |  |  |  |  |
| Short-term, net | $ | 2,227 |  |  | $ | 2,125 |  |
| Long-term, net | 1,381 |  |  | 1,215 |  |
| Financing receivables held by consolidated VIEs, net | $ | 3,608 |  |  | $ | 3,340 |  |

[0001571996-17-000004:notes:343]
Financing receivables transferred via securitization through SPEs were $3.3 billion and $3.2 billion for the fiscal years ended February 3, 2017 and January 29, 2016, respectively.

[0001571996-17-000004:notes:344]
Some of the SPEs have entered into financing arrangements with multi-seller conduits that, in turn, issue asset-backed debt securities in the capital markets.  The structured financing debt outstanding, which is collateralized by the financing receivables held by the consolidated VIEs, was $3.1 billion and $2.8 billion as of February 3, 2017 and January 29, 2016, respectively.  The Company's risk of loss related to securitized receivables is limited to the amount by which the Company's right to receive collections for assets securitized exceeds the amount required to pay interest, principal, and fees and expenses related to the asset-backed securities.  The Company provides credit enhancement to the securitization in the form of over-collateralization.

[0001571996-17-000004:notes:345]
Financing Receivable Sales

[0001571996-17-000004:notes:346]
To manage certain concentrations of customer credit exposure, the Company may sell selected fixed-term financing receivables to unrelated third parties on a periodic basis.  The amount of financing receivables sold was $321 million, $91 million, and $61 million for the fiscal years ended February 3, 2017, January 29, 2016, and January 30, 2015, respectively.


## us-gaap:MinorityInterestDisclosureTextBlock

[0001571996-17-000004:notes:347]
NON-CONTROLLING INTERESTS

[0001571996-17-000004:notes:348]
SecureWorks — On April 27, 2016, SecureWorks completed a registered underwritten IPO of its Class A common stock.  The non-controlling interests' share of equity in SecureWorks is reflected as a component of the non-controlling interests in the accompanying Consolidated Statements of Financial Position and was $86 million as of February 3, 2017.  As of February 3, 2017, Dell Technologies held approximately 87.5% of the outstanding equity interest in SecureWorks.

[0001571996-17-000004:notes:349]
The following non-controlling interests were assumed on September 7, 2016 in connection with the EMC merger transaction:

[0001571996-17-000004:notes:350]
VMware — The non-controlling interests' share of equity in VMware is reflected as a component of the non-controlling interests in the accompanying Consolidated Statements of Financial Position and was $5.2 billion as of February 3, 2017.  As of February 3, 2017, the Company held approximately 82.5% of the outstanding equity interest in VMware.

[0001571996-17-000004:notes:351]
Pivotal — A portion of the non-controlling interest in Pivotal is held by third parties in the form of a preferred equity instrument.  Consequently, there is no net income attributable to such interest in Pivotal in the Consolidated Statements of Income (Loss).  Additionally, due to the terms of the preferred equity instrument, the non-controlling interests in the Consolidated Statements of Financial Position are generally not impacted by Pivotal's equity-related activity.  The preferred equity instrument is convertible into common shares at the non-controlling owner's election at any time.

[0001571996-17-000004:notes:352]
The portion of the results of operations of Pivotal allocable to its other owners, whose interest is held in the form of common stock, is reflected as an adjustment to net income (loss) attributable to Dell Technologies in the accompanying Consolidated Statements of Income.  The non-controlling interests' share of equity in Pivotal is reflected as a component of the non-controlling interests in the accompanying Consolidated Statements of Financial Position and was $472 million as of February 3, 2017.  As of February 3, 2017, the Company held approximately 77.8% of the outstanding equity interest in Pivotal.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001571996-17-000004:notes:353]
Revenue from Contracts with Customers — In May 2014, the Financial Accounting Standards Board (the "FASB") issued amended guidance on the recognition of revenue from contracts with customers.  The objective of the new standard is to establish a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and will supersede substantially all of the existing revenue recognition guidance, including industry-specific guidance.  The new standard requires entities to recognize revenue when it transfers promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services.  The new standard also provides guidance on the accounting for costs to fulfill or obtain a customer contract.  Further, the new standard requires additional disclosures to help enable users of the financial statements to better understand the nature, amount, timing, risks, and judgments related to revenue recognition and related cash flows from contracts with customers.

[0001571996-17-000004:notes:354]
In August 2015, the FASB approved a one-year deferral of the effective date of this standard.  Public entities are required to adopt the new standard for fiscal years, and interim periods within those years, beginning after December 15, 2017.  The new revenue standard may be applied retrospectively to each prior period presented (full retrospective method) or retrospectively with the cumulative effect of initially applying the standard recognized at the date of initial application in retained earnings (modified retrospective method).  The Company currently anticipates adopting this standard retrospectively to each prior period presented for the fiscal year beginning February 3, 2018.

[0001571996-17-000004:notes:355]
While the Company is currently evaluating the financial and system impacts that the new standard will have on the Consolidated Financial Statements, the Company expects that unearned license revenue related to the sale of software licenses and related deliverables will decline upon adoption.  Currently, the Company defers revenue for certain software arrangements due to the absence of vendor specific objective evidence ("VSOE") of fair value for all or a portion of the deliverables.  Under the new standard, the Company will no longer be required to establish VSOE of fair value in order to account for elements in an arrangement as separate units of accounting, and will be able to record revenue upon satisfaction of each performance obligation.  Additionally, the Company expects the new standard to have an impact in the way the transaction price is allocated for certain non-standard warranties.  The new standard is expected to result in more of the aggregate transaction price related to the non-standard warranty being recorded as revenue upon delivery of the underlying product, because the Company will no longer defer revenue based on the separately stated price of the non-standard warranty provided under the contract.  The Company continues to make progress in assessing the impacts of the standard on the Consolidated Financial Statements and will continue to evaluate the impact of any changes to the standard or interpretations should they become available.

[0001571996-17-000004:notes:356]
Presentation of Debt Issuance Costs — In April 2015, the FASB issued amended guidance which changes the classification of debt issuance costs in the Consolidated Statements of Financial Position.  The new guidance requires debt issuance costs to be presented as a direct deduction from the carrying amount of the related debt liability consistent with the presentation of debt discounts, rather than as an asset.  The guidance related to recognition and measurement of debt issuance costs remains unchanged.  The Company implemented the new presentation in the fiscal year ended February 3, 2017 on a retrospective basis, and except for the reclassification of debt issuance costs of $128 million as of January 29, 2016 in the accompanying Consolidated Statements of Financial Position, there was no other impact on the Consolidated Financial Statements.

[0001571996-17-000004:notes:357]
Recognition and Measurement of Financial Assets and Financial Liabilities — In January 2016, the FASB issued amended guidance on Recognition and Measurement of Financial Assets and Financial Liabilities.  The standard addresses certain aspects of recognition, measurement, presentation, and disclosure of financial instruments.  Public entities must adopt the new guidance for fiscal years, and interim periods within those years, beginning after December 15, 2017.  The Company does not expect that the standard will have a material impact on the Consolidated Financial Statements.

[0001571996-17-000004:notes:358]
Leases — In February 2016, the FASB issued amended guidance on the accounting for leasing transactions.  The primary objective of this update is to increase transparency and comparability among organizations by recognizing lease assets and lease liabilities on the balance sheet and disclosing key information about leasing arrangements.  Public entities must adopt the new guidance for reporting periods beginning after December 15, 2018, with early adoption permitted.  Companies are required to use a modified retrospective approach for leases that exist or are entered into after the beginning of the earliest comparative period in the financial statements.  The Company is currently evaluating the impact that the standard will have on the Consolidated Financial Statements.

[0001571996-17-000004:notes:359]
Improvements to Employee Share-Based Payment Accounting — In March 2016, the FASB issued amended guidance on the accounting for employee share-based payments.  The topics that were amended in the update involve several aspects of the accounting for share-based payment transactions, including the income tax consequences, classification of awards as either equity or liabilities, and classification on the statement of cash flows.  The impact to the Consolidated Financial Statements will depend on the Company's stock price at the awards' vest dates or exercise dates and the number of awards that vest or exercise in each period.  Public entities must adopt the new guidance for fiscal years, and interim periods within those years, beginning after December 15, 2016.  The Company adopted the updated standard effective February 4, 2017.  The updated standard is not expected to have a material impact on the Consolidated Financial Statements.

[0001571996-17-000004:notes:360]
Measurement of Credit Losses on Financial Instruments — In June 2016, the FASB issued amended guidance which replaces the current incurred loss impairment methodology with a methodology that reflects expected credit losses and requires consideration of a broader range of reasonable and supportable information to inform credit loss estimates.  Public entities must adopt the new guidance for fiscal years beginning after December 15, 2019, including interim periods within those fiscal years.  All entities may adopt the amendments in the new standard as of fiscal years beginning after December 15, 2018, including interim periods within those fiscal years.  However, earlier adoption is not permitted.  The Company is currently evaluating the impact that the standard will have on the Consolidated Financial Statements.

[0001571996-17-000004:notes:361]
Classification of Certain Cash Receipts and Cash Payments — In August 2016, the FASB issued amended guidance on the presentation and classification of eight specific cash flow issues with the objective of reducing existing diversity in practice.  Public entities must adopt the new guidance for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017, with early adoption permitted.  Companies should reflect any adjustments on a retrospective basis, if practicable, otherwise adoption is required to be applied as of the earliest date practicable.  The Company is currently evaluating the timing of adoption as well as the impact that the standard will have on the Consolidated Financial Statements.

[0001571996-17-000004:notes:362]
Intra-Entity Transfers of Assets Other Than Inventory — In October 2016, the FASB issued amended guidance on the accounting for income taxes.  The new guidance requires companies to recognize the income tax effects of intra-entity asset transfers, other than transfers of inventory, when the transfer occurs instead of when the asset is sold to a third party, as current GAAP requires.  Public entities must adopt the new guidance for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017, with early adoption permitted at the beginning of an annual period.  The new guidance is required to be applied retrospectively with the cumulative effect recognized as of the beginning of the period of adoption.  The Company plans to adopt the guidance in the first quarter of Fiscal 2018.  At adoption, approximately $83 million will be reclassified from other non-current liabilities to retained earnings, resulting in a net credit to retained earnings.

[0001571996-17-000004:notes:363]
Simplifying the Test for Goodwill Impairment — In January 2017, the FASB issued amended guidance to simplify the subsequent measurement of goodwill by removing Step 2 of the goodwill impairment test.  Instead, under the amendments in the new guidance, an entity should perform its annual, or interim, goodwill impairment test by comparing the fair value of a reporting unit with its carrying amount.  An entity should recognize an impairment charge for the amount by which the carrying amount exceeds the reporting unit's fair value.  Public entities must adopt the new guidance in fiscal years beginning after December 15, 2019, with early adoption permitted.  The Company is currently evaluating the impact of the new guidance and timing of adoption, but does not expect that the standard will have an impact on its Consolidated Financial Statements.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001571996-17-000004:notes:364]
RETIREMENT PLAN BENEFITS

[0001571996-17-000004:notes:365]
Defined Benefit Pension Plan

[0001571996-17-000004:notes:366]
In connection with the EMC merger transaction completed on September 7, 2016, the Company assumed all of EMC's defined benefit obligations and related plan assets, including a noncontributory defined benefit pension plan (the "Pension Plan") which was assumed as a result of EMC's prior acquisition of Data General.  Certain of the Company's foreign subsidiaries also have defined benefit pension plans which were assumed as part of the EMC merger transaction and do not have a material impact on the results of operations or financial position of the Company.

[0001571996-17-000004:notes:367]
Benefits under the Pension Plan are generally based on either career average or final average salaries and creditable years of service as defined in the plan.  The annual cost for the Pension Plan is determined using the projected unit credit actuarial cost method that includes actuarial assumptions and estimates which are subject to change.  As of December 1999, this plan was frozen, so employees no longer accrue pension benefits for future services.  The measurement date for the Pension Plan is the end of the Company's fiscal year.

[0001571996-17-000004:notes:368]
The following table presents a reconciliation of the Pension Plan benefit obligation:

[0001571996-17-000004:notes:369]
|  | Benefit Obligation |
|  | (in millions) |
| Benefit obligation as of September 7, 2016 | $ | 590 |  |
| Interest cost | 8 |  |
| Benefits paid | (11 | ) |
| Actuarial loss (gain) | (52 | ) |
| Benefit obligation as of February 3, 2017 | $ | 535 |  |

[0001571996-17-000004:notes:370]
On a weighted-average basis, the assumed discount rate used to determine the benefit obligations at February 3, 2017 and September 7, 2016 was 4.1% and 3.4%, respectively.

[0001571996-17-000004:notes:371]
The following table presents a reconciliation of the fair value of plan assets:

[0001571996-17-000004:notes:372]
|  | Plan Assets |
|  | (in millions) |
| Fair value of plan assets as of September 7, 2016 | $ | 493 |  |
| Actual return on plan assets | (12 | ) |
| Benefits paid | (11 | ) |
| Fair value of plan assets as of February 3, 2017 | $ | 470 |  |

[0001571996-17-000004:notes:373]
The under-funded status of the Pension Plan at February 3, 2017 was $65 million and is classified as a component of other long-term liabilities in the Consolidated Statements of Financial Position.  The Company does not expect to make any significant contributions to the Pension Plan in Fiscal 2018.

[0001571996-17-000004:notes:374]
The following table presents the components of net periodic benefit cost recognized in the period presented:

[0001571996-17-000004:notes:375]
|  | September 7, 2016 through February 3, 2017 |
|  | (in millions) |
| Interest cost | $ | 8 |  |
| Expected return on plan assets | (16 | ) |
| Recognized actuarial loss | — |  |
| Net periodic benefit cost | $ | (8 | ) |

[0001571996-17-000004:notes:376]
The discount rate and expected long-term rate of return on plan assets used in the accounting for the Pension Plan to determine the net periodic benefit cost for the period from September 7, 2016 through February 3, 2017 was 3.4% and 6.5%, respectively.  During the period from September 7, 2016 through February 3, 2017, the Pension Plan had net gains of $24 million that were primarily the result of an increase in the discount rate and the rate of return on plan assets.  The net gains were recognized in accumulated other comprehensive loss.

[0001571996-17-000004:notes:377]
There were no reclassifications from accumulated other comprehensive loss to a component of net periodic benefit cost during the period from September 7, 2016 through February 3, 2017.  Additionally, the Company expects that none of the total balance included in accumulated other comprehensive loss at February 3, 2017 will be recognized as a component of net periodic benefit cost in Fiscal 2018.

[0001571996-17-000004:notes:378]
At February 3, 2017, future benefit payments are expected to be paid as follows: $26 million in Fiscal 2018; $27 million in Fiscal 2019; $29 million in Fiscal 2020; $31 million in Fiscal 2021; $32 million in Fiscal 2022; and $174 million thereafter.

[0001571996-17-000004:notes:379]
Fair Value of Plan Assets — The following table presents the fair value of each class of plan assets by level within the fair value hierarchy as of February 3, 2017:

[0001571996-17-000004:notes:380]
|  | February 3, 2017 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (in millions) |
| Common collective trusts (a) | $ | — |  |  | $ | 331 |  |  | $ | — |  |  | $ | 331 |  |
| U.S. Treasury securities | 1 |  |  | — |  |  | — |  |  | 1 |  |
| Corporate debt securities (b) | — |  |  | 137 |  |  | — |  |  | 137 |  |
| Total | $ | 1 |  |  | $ | 468 |  |  | $ | — |  |  | 469 |  |
| Plan payables, net of accrued interest and dividends (c) |  |  |  |  |  |  | 1 |  |
| Total, net |  |  |  |  |  |  | $ | 470 |  |

[0001571996-17-000004:notes:381]
| (a) | Common collective trusts are valued at the net asset value calculated by the fund manager based on the underlying investments and are classified within Level 2 of the fair value hierarchy. |

[0001571996-17-000004:notes:382]
| (b) | Corporate debt securities are valued daily at the closing price reported in active U.S. financial markets and are classified within Level 2 of the fair value hierarchy. |

[0001571996-17-000004:notes:383]
| (c) | Dividends, accrued interest and net plan payables are not material to the plan assets and therefore have not been classified into the fair value hierarchy. |

[0001571996-17-000004:notes:384]
Investment Strategy — The Pension Plan's assets are managed by outside investment managers.  The Company's investment strategy with respect to plan assets is to achieve a long-term growth of capital, consistent with an appropriate level of risk.  The expected long-term rate of return on the plan assets considers the current level of expected returns on risk-free investments (primarily government bonds), the historical level of the risk premium associated with the other asset classes in which the portfolio is invested and the expectations for future returns of each asset class.  The expected return for each asset class was weighted based on the target asset allocation to develop the expected long-term rate of return on assets.  As market conditions permit, the Company expects to shift the asset allocation to lower the percentage of investments in equities and increase the percentage of investments in long-duration fixed-income securities.  The changes could result in a reduction in the long-term rate of return on the plan assets and increase future pension expense.

[0001571996-17-000004:notes:385]
At February 3, 2017, the long-term weighted-average target asset allocations are as follows: 17% U.S. large capitalization equity securities; 4% U.S. small capitalization equity securities; 4% foreign equity securities; and 75% U.S. long-duration fixed income securities.

[0001571996-17-000004:notes:386]
At February 3, 2017, the actual allocation of plan assets is as follows: 27% U.S. large capitalization equity securities; 5% U.S. small capitalization equity securities; 7% foreign equity securities; 57% U.S. long-duration fixed income securities; and 4% below investment grade corporate fixed income securities.

[0001571996-17-000004:notes:387]
Employee Benefit Plans

[0001571996-17-000004:notes:388]
Dell 401(k) Plan — The Company has a defined contribution retirement plan (the "401(k) Plan") that complies with Section 401(k) of the Internal Revenue Code.  Substantially all Dell employees in the United States before the completion of the EMC merger transaction are eligible to participate in the 401(k) Plan.  Effective January 1, 2008, the Company matches 100% of each participant's voluntary contributions, subject to a maximum contribution of 5% of the participant's eligible compensation, and participants vest immediately in all contributions to the 401(k) Plan.  The Company's contributions during the fiscal years ended February 3, 2017, January 29, 2016, and January 30, 2015 were $158 million, $169 million, and $162 million, respectively.  The Company's matching contributions as well as participants' voluntary contributions are invested according to each participant's elections in the investment options provided under the 401(k) Plan.

[0001571996-17-000004:notes:389]
The following EMC employee benefit plan was assumed on September 7, 2016 in connection with the EMC merger transaction:

[0001571996-17-000004:notes:390]
EMC 401(k) Plan — The Company has a defined contribution program that complies with Section 401(k) of the Internal Revenue Code for certain employees who were EMC employees before the completion of the EMC merger transaction.  EMC matches pre-tax employee contributions up to 6% of eligible compensation during each pay period (subject to a $750 maximum match each quarter).  EMC also provides a supplemental matching contribution up to an additional $3,000 at the end of the calendar year.  All participants vest in the Company's matching contributions based on the number of years of continuous service over a three-year vesting period.  The Company's matching contributions and participants voluntary contributions are invested according to each participant's elections in the investment options provided under the 401(k) Plan.  VMware also has a defined contribution program for certain employees that complies with Section 401(k) of the Internal Revenue Code.  The Company's contributions during the period from September 7, 2016 through February 3, 2017 to the EMC program were $31 million.  On February 15, 2017, subsequent to the fiscal year ended February 3, 2017, the Company contributed an additional $47 million to such program as part of its supplemental matching program.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001571996-17-000004:notes:391]
WARRANTY LIABILITY

[0001571996-17-000004:notes:392]
The Company records a liability for its standard limited warranties at the time of sale for the estimated costs that may be incurred.  The liability for standard warranties is included in accrued and other current liabilities and other non-current liabilities in the Consolidated Statements of Financial Position.

[0001571996-17-000004:notes:393]
Changes in the Company's liabilities for standard limited warranties are presented in the following table for the periods indicated.

[0001571996-17-000004:notes:394]
|  | Fiscal Year Ended |
|  | February 3, 2017 |  | January 29, 2016 |  | January 30, 2015 |
|  | (in millions) |
| Warranty liability: |  |  |  |  |  |
| Warranty liability at beginning of period | $ | 574 |  |  | $ | 679 |  |  | $ | 774 |  |
| Warranty liability assumed through EMC merger transaction | 125 |  |  | — |  |  | — |  |
| Costs accrued for new warranty contracts and changes in estimates for pre-existing warranties (a) (b) | 852 |  |  | 754 |  |  | 860 |  |
| Service obligations honored | (947 | ) |  | (859 | ) |  | (955 | ) |
| Warranty liability at end of period | $ | 604 |  |  | $ | 574 |  |  | $ | 679 |  |
| Current portion | $ | 405 |  |  | $ | 381 |  |  | $ | 453 |  |
| Non-current portion | $ | 199 |  |  | $ | 193 |  |  | $ | 226 |  |

[0001571996-17-000004:notes:395]
| (a) | Changes in cost estimates related to pre-existing warranties are aggregated with accruals for new standard warranty contracts. The Company's warranty liability process does not differentiate between estimates made for pre-existing warranties and new warranty obligations. |

[0001571996-17-000004:notes:396]
| (b) | Includes the impact of foreign currency exchange rate fluctuations. |


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0001571996-17-000004:notes:397]
Property, plant, and equipment are carried at depreciated cost.  Depreciation is determined using the straight-line method over the estimated economic lives of the assets, which range from ten to thirty years for buildings and two to ten years for all other assets.  Leasehold improvements are amortized over the shorter of five years or the lease term.  Gains or losses related to retirements or disposition of fixed assets are recognized in the period during which the retirement or disposition occurs.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001571996-17-000004:notes:398]
UNAUDITED QUARTERLY RESULTS

[0001571996-17-000004:notes:399]
The following tables present selected unaudited consolidated statements of income (loss) for each quarter of Fiscal 2017 and Fiscal 2016:

[0001571996-17-000004:notes:400]
|  | Fiscal 2017 |
|  | Q1 (a) |  | Q2 (b) |  | Q3 |  | Q4 (c) |
|  | (in millions, except per share data) |
| Net revenue | $ | 12,241 |  |  | $ | 13,080 |  |  | $ | 16,247 |  |  | $ | 20,074 |  |
| Gross margin | $ | 2,193 |  |  | $ | 2,336 |  |  | $ | 3,899 |  |  | $ | 4,531 |  |
| Net income from continuing operations attributable to Class V Common Stock | $ | — |  |  | $ | — |  |  | $ | 175 |  |  | $ | 138 |  |
| Net loss from continuing operations attributable to DHI Group | (424 | ) |  | (261 | ) |  | (1,801 | ) |  | (1,518 | ) |
| Net loss from continuing operations attributable to Dell Technologies Inc. | (424 | ) |  | (261 | ) |  | (1,626 | ) |  | (1,380 | ) |
| Income (loss) from discontinued operations, net of income taxes | 479 |  |  | 834 |  |  | (438 | ) |  | 1,144 |  |
| Net income (loss) attributable to Dell Technologies Inc. | $ | 55 |  |  | $ | 573 |  |  | $ | (2,064 | ) |  | $ | (236 | ) |
| Earnings (loss) per share attributable to Dell Technologies Inc. - basic: |  |  |  |  |  |  |  |
| Continuing operations - Class V Common Stock - basic | $ | — |  |  | $ | — |  |  | $ | 0.79 |  |  | $ | 0.64 |  |
| Continuing operations - DHI Group - basic | $ | (1.05 | ) |  | $ | (0.65 | ) |  | $ | (3.62 | ) |  | $ | (2.68 | ) |
| Discontinued operations - DHI Group - basic | $ | 1.18 |  |  | $ | 2.06 |  |  | $ | (0.88 | ) |  | $ | 2.02 |  |
| Earnings (loss) per share attributable to Dell Technologies Inc. - diluted: |  |  |  |  |  |  |  |
| Continuing operations - Class V Common Stock - diluted | $ | — |  |  | $ | — |  |  | $ | 0.78 |  |  | $ | 0.64 |  |
| Continuing operations - DHI Group - diluted | $ | (1.05 | ) |  | $ | (0.65 | ) |  | $ | (3.63 | ) |  | $ | (2.68 | ) |
| Discontinued operations - DHI Group - diluted | $ | 1.18 |  |  | $ | 2.06 |  |  | $ | (0.88 | ) |  | $ | 2.02 |  |

[0001571996-17-000004:notes:401]
| (a) | The amounts presented for the three months ended April 29, 2016 are different from those previously reported on Form 10-Q primarily because DSG met the criteria for discontinued operations reporting as of June 29, 2016, and therefore the Company recast the associated financial results as discontinued operations in the Consolidated Statements of Income (Loss). |

[0001571996-17-000004:notes:402]
| (b) | The amounts presented for the three months ended July 29, 2016 are different from those previously reported on Form 10-Q because the Company reclassified an immaterial amount of financial results from discontinued operations to continuing operations to reflect the updated terms as the result of continued negotiations and finalization of terms of the sale. |

[0001571996-17-000004:notes:403]
| (c) | Income (loss) from discontinued operations for the three months ended February 3, 2017 includes the impact of the net gain on sale of the divested businesses of $1.9 billion, net of tax expense of $0.4 billion. |

[0001571996-17-000004:notes:404]
|  | Fiscal 2016 |
|  | Q1 |  | Q2 |  | Q3 |  | Q4 |
|  | (in millions, except per share data) |
| Net revenue | $ | 12,552 |  |  | $ | 13,006 |  |  | $ | 12,674 |  |  | $ | 12,679 |  |
| Gross margin | $ | 1,915 |  |  | $ | 2,086 |  |  | $ | 2,132 |  |  | $ | 2,254 |  |
| Net loss from continuing operations attributable to Dell Technologies Inc. | $ | (446 | ) |  | $ | (290 | ) |  | $ | (264 | ) |  | $ | (168 | ) |
| Income (loss) from discontinued operations, net of income taxes | (58 | ) |  | 25 |  |  | 84 |  |  | 13 |  |
| Net loss attributable to Dell Technologies Inc. | $ | (504 | ) |  | $ | (265 | ) |  | $ | (180 | ) |  | $ | (155 | ) |
| Earnings (loss) per share attributable to Dell Technologies Inc. - basic: |  |  |  |  |  |  |  |
| Continuing operations - DHI Group - basic | $ | (1.10 | ) |  | $ | (0.72 | ) |  | $ | (0.65 | ) |  | $ | (0.41 | ) |
| Discontinued operations - DHI Group - basic | $ | (0.14 | ) |  | $ | 0.06 |  |  | $ | 0.21 |  |  | $ | 0.03 |  |
| Earnings (loss) per share attributable to Dell Technologies Inc. - diluted: |  |  |  |  |  |  |  |
| Continuing operations - DHI Group - diluted | $ | (1.10 | ) |  | $ | (0.72 | ) |  | $ | (0.65 | ) |  | $ | (0.41 | ) |
| Discontinued operations - DHI Group - diluted | $ | (0.14 | ) |  | $ | 0.06 |  |  | $ | 0.21 |  |  | $ | 0.03 |  |


## us-gaap:ReconciliationOfRevenueFromSegmentsToConsolidatedTextBlock

[0001571996-17-000004:notes:405]
The following table presents a reconciliation of net revenue by the Company's reportable segments to the Company's consolidated net revenue as well as a reconciliation of consolidated segment operating income (loss) to the Company's consolidated operating income (loss):

[0001571996-17-000004:notes:406]
|  | Fiscal Year Ended |
|  | February 3, 2017 |  | January 29, 2016 |  | January 30, 2015 |
|  | (in millions) |
| Consolidated net revenue: |  |  |  |  |  |  |  |
| Client Solutions Group | $ | 36,754 |  |  | $ | 35,877 |  |  | $ | 39,634 |  |
| Infrastructure Solutions Group | 21,776 |  |  | 14,978 |  |  | 14,714 |  |
| VMware | 3,225 |  |  | — |  |  | — |  |
| Reportable segment net revenue | 61,755 |  |  | 50,855 |  |  | 54,348 |  |
| Other businesses (a) | 1,026 |  |  | 382 |  |  | 342 |  |
| Unallocated transactions (b) | 41 |  |  | 133 |  |  | 188 |  |
| Impact of purchase accounting (c) | (1,180 | ) |  | (459 | ) |  | (736 | ) |
| Total net revenue | $ | 61,642 |  |  | $ | 50,911 |  |  | $ | 54,142 |  |
| Consolidated operating income (loss): |  |  |  |  |  |
| Client Solutions Group | $ | 1,845 |  |  | $ | 1,410 |  |  | $ | 2,051 |  |
| Infrastructure Solutions Group | 2,393 |  |  | 1,052 |  |  | 1,230 |  |
| VMware | 1,113 |  |  | — |  |  | — |  |
| Reportable segment operating income | 5,351 |  |  | 2,462 |  |  | 3,281 |  |
| Other businesses (a) | (39 | ) |  | (78 | ) |  | (30 | ) |
| Unallocated transactions (b) | (199 | ) |  | (159 | ) |  | (434 | ) |
| Impact of purchase accounting (c) | (2,294 | ) |  | (604 | ) |  | (888 | ) |
| Amortization of intangibles | (3,681 | ) |  | (1,969 | ) |  | (2,084 | ) |
| Transaction-related expenses (d) | (1,488 | ) |  | (109 | ) |  | (76 | ) |
| Other corporate expenses (e) | (902 | ) |  | (57 | ) |  | (85 | ) |
| Total operating loss | $ | (3,252 | ) |  | $ | (514 | ) |  | $ | (316 | ) |

[0001571996-17-000004:notes:407]
| (a) | Other businesses consist of RSA Information Security, SecureWorks, Pivotal, and Boomi offerings, and do not constitute a reportable segment, either individually or collectively, as the results of the businesses are not material to the Company's overall results and the businesses do not meet the criteria for reportable segments. |

[0001571996-17-000004:notes:408]
| (b) | Unallocated transactions includes long-term incentives, certain short-term incentive compensation expenses, and other corporate items that are not allocated to Dell Technologies' reportable segments. |

[0001571996-17-000004:notes:409]
| (c) | Impact of purchase accounting includes non-cash purchase accounting adjustments that are primarily related to the EMC merger transaction, as well as the going-private transaction. |

[0001571996-17-000004:notes:410]
| (d) | Transaction-related expenses includes acquisition and integration-related costs. |

[0001571996-17-000004:notes:411]
| (e) | Other corporate expenses includes severance and facility action costs as well as stock-based compensation expense. |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001571996-17-000004:notes:412]
RELATED PARTY TRANSACTIONS

[0001571996-17-000004:notes:413]
Dell Technologies is a large global organization which engages in millions of purchase, sales, and other transactions during the fiscal year.  The Company enters into purchase and sales transactions with other publicly-traded and privately-held companies, universities, hospitals, and not-for-profit organizations with which members of the Company's board of directors or executive officers are affiliated.  The Company enters into these arrangements in the ordinary course of its business.  Transactions with related parties were immaterial for the fiscal years ended February 3, 2017, January 29, 2016, and January 30, 2015.

[0001571996-17-000004:notes:414]
From time to time, the Company makes strategic investments in publicly-traded and privately-held companies that develop software, hardware and other technologies or provide services supporting the Company's technologies.  The Company may purchase from or make sales to these organizations in the ordinary course of business.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001571996-17-000004:notes:415]
SEVERANCE CHARGES

[0001571996-17-000004:notes:416]
In connection with the transformation of the Company's business model, the Company incurs costs related to employee severance.  The Company records a liability for these costs when it is probable that employees will be entitled to termination benefits and the amounts can be reasonably estimated.  The liability related to these actions is included in accrued and other current liabilities in the Consolidated Statements of Financial Position and was $416 million and $26 million as of February 3, 2017 and January 29, 2016, respectively.  In connection with the EMC merger transaction, the Company assumed a liability of $70 million, which represents the fair value of the outstanding obligation of EMC's legacy severance programs.  The Company has determined that it will manage the remainder of these programs as part of its ongoing severance actions.  Accordingly, the Company has included the liability related to these programs in the table below.

[0001571996-17-000004:notes:417]
The following table sets forth the activity related to the Company's severance liability for the respective periods:

[0001571996-17-000004:notes:418]
|  | Severance Costs |
|  | (in millions) |
| Balance as of January 31, 2014 | $ | 433 |  |
| Severance charges to provision | 46 |  |
| Cash paid and other | (384 | ) |
| Balance as of January 30, 2015 | 95 |  |
| Severance charges to provision | 20 |  |
| Cash paid and other | (89 | ) |
| Balance as of January 29, 2016 | 26 |  |
| Severance liability assumed through EMC merger transaction | 70 |  |
| Severance charges to provision | 541 |  |
| Cash paid and other | (221 | ) |
| Balance as of February 3, 2017 | $ | 416 |  |

[0001571996-17-000004:notes:419]
Severance costs are included in cost of net revenue, selling, general, and administrative expenses, and research and development expense in the Consolidated Statements of Income (Loss) as follows:

[0001571996-17-000004:notes:420]
|  | Fiscal Year Ended |
|  | February 3, 2017 |  | January 29, 2016 |  | January 30, 2015 |
|  | (in millions) |
| Severance charges: |  |  |  |  |  |
| Cost of net revenue | $ | 122 |  |  | $ | 1 |  |  | $ | 21 |  |
| Selling, general, and administrative | 355 |  |  | (1 | ) |  | 20 |  |
| Research and development | 64 |  |  | 20 |  |  | 5 |  |
| Total | $ | 541 |  |  | $ | 20 |  |  | $ | 46 |  |


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001571996-17-000004:notes:421]
Net revenue primarily includes sales of hardware, services, software licenses, and peripherals.  The Company recognizes revenue for these products and services when it is realized or realizable and earned.  Revenue is recognized when persuasive evidence of an arrangement exists; delivery has occurred or services have been rendered; the Company's fee to its customer is fixed or determinable; and collection of the resulting receivable is reasonably assured.  This policy is applicable to all sales, including sales to resellers and end-users.

[0001571996-17-000004:notes:422]
Revenue from certain third-party software sales and extended warranties for third-party products, for which the Company does not meet the criteria for gross revenue recognition, is recognized on a net basis.  All other revenue is recognized on a gross basis.

[0001571996-17-000004:notes:423]
The following summarizes the major terms of contractual relationships with customers and the manner in which the Company accounts for sales transactions.

[0001571996-17-000004:notes:424]
Products

[0001571996-17-000004:notes:425]
Product revenue consists of computer hardware, enterprise hardware, and software licenses sales that are delivered, sold as a subscription or sold on a consumption basis.  Computer hardware and enterprise hardware include notebooks and desktop PCs, servers, storage hardware, and other hardware-related devices.  Software license sales include optional, stand-alone software applications.  Software applications provide customers with resource management, backup and archiving, information security, information management and intelligence, data analytics and server virtualization capabilities.  Revenue from the sale of hardware products and systems is recognized when title and risk of loss pass to the customer.  Delivery is considered complete when products have been shipped to the Company's customer, title and risk of loss have transferred to the customer, and customer acceptance has been satisfied.  Customer acceptance is satisfied if acceptance is obtained from the customer, if all acceptance provisions lapse, or if the Company has evidence that all acceptance provisions have been satisfied.  Depending on the nature of the arrangement, revenue from software license sales is generally recognized upon shipment or electronic delivery.  For certain arrangements, revenue is recognized based on usage or ratably over the term of the arrangement.  License revenue from royalty arrangements is recognized upon either receipt of royalty reports or payments from third parties.

[0001571996-17-000004:notes:426]
The Company records reductions to revenue for estimated customer sales returns, rebates, and certain other customer incentive programs.  These reductions to revenue are made based upon reasonable and reliable estimates that are determined by historical experience, contractual terms, and current conditions.  The primary factors affecting the Company's accrual for estimated customer returns include estimated return rates as well as the number of units shipped that have a right of return that has not expired as of the balance sheet date.  If returns cannot be reliably estimated, revenue is not recognized until a reliable estimate can be made or the return right lapses.

[0001571996-17-000004:notes:427]
The Company sells its products directly to customers as well as through other distribution channels, such as retailers, distributors, and resellers.  The Company recognizes revenue on these sales when the reseller has economic substance apart from the Company; any credit risk has been identified and quantified; title and risk of loss have passed to the sales channel; the fee paid to the Company is not contingent upon resale or payment by the end user; and the Company has no further obligations related to bringing about resale or delivery.

[0001571996-17-000004:notes:428]
Sales through the Company's distribution channels are primarily made under agreements allowing for limited rights of return, price protection, rebates, and marketing development funds.  The Company has generally limited return rights through contractual caps or has an established selling history for these arrangements.  Therefore, there is sufficient data to establish reasonable and reliable estimates of returns for the majority of these sales.  To the extent price protection or return rights are not limited and a reliable estimate cannot be made, all of the revenue and related costs are deferred until the product has been sold to the end-user or the rights expire.  The Company records estimated reductions to revenue or an expense for distribution channel programs at the later of the offer or the time revenue is recognized.

[0001571996-17-000004:notes:429]
The Company defers the cost of shipped products awaiting revenue recognition until revenue is recognized.

[0001571996-17-000004:notes:430]
Services

[0001571996-17-000004:notes:431]
Services revenue consists of hardware and software maintenance, installation services, professional services, training revenue, third-party software revenue, and software sold as a service.  The Company recognizes revenue from fixed-price support or maintenance contracts sold for both hardware and software ratably over the contract period and recognizes the costs associated with these contracts as incurred.  For sales of extended warranties with a separate contract price, the Company defers revenue equal to the separately stated price.  Revenue associated with undelivered elements is deferred and recorded when delivery occurs or services are provided.  Revenue from extended warranty and service contracts, for which the Company is obligated to perform, is recorded as deferred revenue and subsequently recognized over the term of the contract on a straight-line basis or when the service is completed and the costs associated with these contracts are recognized as incurred.

[0001571996-17-000004:notes:432]
Multiple Deliverables

[0001571996-17-000004:notes:433]
When an arrangement has more than one element, such as hardware, software, and services contained in a single arrangement, the Company first allocates revenue based upon the relative selling price into two categories: (1) non-software components, such as hardware and any hardware-related items, such as required system software that functions with the hardware to deliver the essential functionality of the hardware and related post-contract customer support, software as a service subscriptions and other services; and (2) software components, such as optional software applications and related items, such as post-contract customer support and other services.  The Company then allocates revenue within the non-software category to each element based upon its relative selling price using a hierarchy of vendor-specific objective evidence ("VSOE"), third-party evidence of selling price ("TPE"), or estimated selling prices ("ESP"), if VSOE or TPE does not exist.  The Company allocates revenue within the software category to the undelivered elements based upon their fair value using VSOE, with the residual revenue allocated to the delivered elements.  If the Company cannot objectively determine the VSOE of the fair value of any undelivered software element, it defers revenue for all software components until all elements are delivered and services have been performed, until fair value can objectively be determined for any remaining undelivered elements, or until software maintenance is the only undelivered element, in which case revenue is recognized over the maintenance term for all software elements.

[0001571996-17-000004:notes:434]
The Company allocates the amount of revenue recognized for delivered elements to the amount that is not subject to forfeiture or refund or contingent on the future delivery of products or services.

[0001571996-17-000004:notes:435]
Customers under software maintenance agreements are entitled to receive updates and upgrades on a when-and-if-available basis, and various types of technical support based on the level of support purchased.  In the event specific features, functionality, entitlements, or the release version of an upgrade or new product have been announced but not delivered, and customers will receive that upgrade or new product as part of a current software maintenance contract, a specified upgrade is deemed created and product revenues are deferred on purchases made after the announcement date until delivery of the upgrade or new product.  The amount and elements to be deferred are dependent on whether the Company has established VSOE of fair value for the upgrade or new product.

[0001571996-17-000004:notes:436]
Other

[0001571996-17-000004:notes:437]
The Company records revenue from the sale of equipment under sales-type leases as product revenue in an amount equal to the present value of minimum lease payments at the inception of the lease.  Sales-type leases also produce financing income, which is included in net products revenue in the Consolidated Statements of Income (Loss) and is recognized at consistent rates of return over the lease term.  Revenue from operating leases is recognized over the lease period.  The Company also offers qualified customers revolving credit lines for the purchase of products and services offered by the Company.  Financing income attributable to these revolving loans is recognized in net products revenue on an accrual basis.

[0001571996-17-000004:notes:438]
The Company reports revenue net of any revenue-based taxes assessed by governmental authorities that are imposed on and concurrent with specific revenue-producing transactions.


## us-gaap:ScheduleOfBusinessAcquisitionsByAcquisitionTextBlock

[0001571996-17-000004:notes:439]
The remaining $0.5 billion of costs were recognized in the Consolidated Statements of Income (Loss) for the periods presented as follows:


## us-gaap:ScheduleOfCondensedBalanceSheetTableTextBlock

[0001571996-17-000004:notes:440]
The following table presents the financial position of Dell Technologies Inc. (Parent) as of February 3, 2017 and January 29, 2016:

[0001571996-17-000004:notes:441]
| Dell Technologies Inc. (Parent) | February 3, 2017 |  | January 29, 2016 |
|  | (in millions) |
| Assets: |  |  |  |
| Cash and cash equivalents | $ | 123 |  |  | $ | — |  |
| Investments in subsidiaries | 13,412 |  |  | 1,587 |  |
| Other non-current assets | 4 |  |  | 11 |  |
| Total assets | $ | 13,539 |  |  | $ | 1,598 |  |
| Long-term debt (a) | $ | 26 |  |  | $ | 26 |  |
| Accrued and other | 39 |  |  | — |  |
| Redeemable shares | 231 |  |  | 106 |  |
| Stockholders' equity: |  |  |  |
| Common stock and capital in excess of $.01 par value | 19,447 |  |  | 5,727 |  |
| Retained earnings (deficit) | (5,609 | ) |  | (3,937 | ) |
| Accumulated other comprehensive income (loss) | (595 | ) |  | (324 | ) |
| Total stockholders' equity | 13,243 |  |  | 1,466 |  |
| Total liabilities, redeemable shares, and stockholders' equity | $ | 13,539 |  |  | $ | 1,598 |  |

[0001571996-17-000004:notes:442]
| (a) | In connection with the acquisition of Dell by Dell Technologies, Dell Technologies issued a $2.0 billion subordinated note to Microsoft Global Finance, a subsidiary of Microsoft Corporation. As of February 3, 2017 and January 29, 2016, the outstanding principal amount of the Microsoft Note was $26 million, payable at maturity in October 2023. |

[0001571996-17-000004:notes:443]
The following table provides additional information on selected accounts included in the Consolidated Statements of Financial Position as of February 3, 2017 and January 29, 2016:

[0001571996-17-000004:notes:444]
|  | February 3, 2017 |  | January 29, 2016 |
|  | (in millions) |
| Accounts receivable, net: |  |  |  |
| Gross accounts receivable | $ | 9,759 |  |  | $ | 5,046 |  |
| Allowance for doubtful accounts | (46 | ) |  | (36 | ) |
| Allowance for customer returns | (293 | ) |  | (123 | ) |
| Total accounts receivable, net | 9,420 |  |  | 4,887 |  |
| Inventories, net: |  |  |  |
| Production materials | 925 |  |  | 657 |  |
| Work-in-process | 503 |  |  | 189 |  |
| Finished goods | 1,110 |  |  | 773 |  |
| Total inventories, net | 2,538 |  |  | 1,619 |  |
| Prepaid expenses (a) |  |  |  |
| Total prepaid expenses | 850 |  |  | 514 |  |
| Property, plant, and equipment, net: |  |  |  |
| Computer equipment | 5,045 |  |  | 762 |  |
| Land and buildings | 4,299 |  |  | 919 |  |
| Machinery and other equipment | 3,770 |  |  | 226 |  |
| Total property, plant, and equipment | 13,114 |  |  | 1,907 |  |
| Accumulated depreciation and amortization | (7,461 | ) |  | (258 | ) |
| Total property, plant, and equipment, net | 5,653 |  |  | 1,649 |  |
| Accrued and other current liabilities: |  |  |  |
| Compensation | 2,641 |  |  | 941 |  |
| Warranty liability | 405 |  |  | 381 |  |
| Income and other taxes | 943 |  |  | 1,210 |  |
| Other | 3,130 |  |  | 1,685 |  |
| Total accrued and other current liabilities | 7,119 |  |  | 4,217 |  |
| Other non-current liabilities: |  |  |  |
| Warranty liability | 199 |  |  | 193 |  |
| Unrecognized tax benefits, net | 3,124 |  |  | 2,271 |  |
| Other deferred tax liabilities | 5,483 |  |  | 939 |  |
| Other | 533 |  |  | 98 |  |
| Total other non-current liabilities | $ | 9,339 |  |  | $ | 3,501 |  |

[0001571996-17-000004:notes:445]
| (a) | Prepaid expenses are included in other current assets in the Consolidated Statements of Financial Position. |


## us-gaap:ScheduleOfCondensedCashFlowStatementTableTextBlock

[0001571996-17-000004:notes:446]
The following table presents the cash flows of Dell Technologies Inc. (Parent) for the fiscal years ended February 3, 2017, January 29, 2016, and January 30, 2015.

[0001571996-17-000004:notes:447]
|  | Fiscal Year Ended |
| Dell Technologies Inc. (Parent) | February 3, 2017 |  | January 29, 2016 |  | January 30, 2015 |
|  | (in millions) |
| Change in cash from operating activities | $ | (2 | ) |  | $ | (2 | ) |  | $ | (64 | ) |
| Cash flow from investing activities: |  |  |  |  |  |
| Transfer to/from subsidiary | 35,935 |  |  | — |  |  | — |  |
| Acquisition of business, net of cash acquired | (39,521 | ) |  | — |  |  | — |  |
| Change in cash from investing activities | (3,586 | ) |  | — |  |  | — |  |
| Cash flow from financing activities: |  |  |  |  |  |
| Proceeds from the issuance of DHI Group Common Stock | 4,422 |  |  | — |  |  | 28 |  |
| Repurchases of DHI Group Common Stock | (10 | ) |  | — |  |  | — |  |
| Repurchases of Class V Common Stock | (701 | ) |  | — |  |  | — |  |
| Issuance of common stock under employee plans | — |  |  | 2 |  |  | — |  |
| Proceeds from debt | — |  |  | — |  |  | — |  |
| Repayments of debt | — |  |  | — |  |  | (1,974 | ) |
| Receipt of capital from subsidiaries | — |  |  | 2 |  |  | 2,001 |  |
| Capital investment in subsidiaries | — |  |  | (2 | ) |  | — |  |
| Change in cash from financing activities | 3,711 |  |  | 2 |  |  | 55 |  |
| Change in cash and cash equivalents | 123 |  |  | — |  |  | (9 | ) |
| Cash and cash equivalents at beginning of the period | — |  |  | — |  |  | 9 |  |
| Cash and cash equivalents at end of the period | $ | 123 |  |  | $ | — |  |  | $ | — |  |


## us-gaap:ScheduleOfCondensedIncomeStatementTableTextBlock

[0001571996-17-000004:notes:448]
The table below provides details of interest and other, net for the fiscal years ended February 3, 2017, January 29, 2016, and January 30, 2015:

[0001571996-17-000004:notes:449]
|  | Fiscal Year Ended |
|  | February 3, 2017 |  | January 29, 2016 |  | January 30, 2015 |
|  | (in millions) |
| Interest and other, net: |  |  |  |  |  |
| Investment income, primarily interest | $ | 102 |  |  | $ | 39 |  |  | $ | 47 |  |
| Gain (loss) on investments, net | 4 |  |  | (2 | ) |  | (29 | ) |
| Interest expense | (1,751 | ) |  | (680 | ) |  | (807 | ) |
| Foreign exchange | (77 | ) |  | (107 | ) |  | (76 | ) |
| Debt extinguishment | (337 | ) |  | — |  |  | — |  |
| Other | (45 | ) |  | (22 | ) |  | (34 | ) |
| Total interest and other, net | $ | (2,104 | ) |  | $ | (772 | ) |  | $ | (899 | ) |

[0001571996-17-000004:notes:450]
The following table presents a reconciliation of (1) the equity in net loss of subsidiaries to the net loss attributable to Dell Technologies Inc. and (2) consolidated net loss to comprehensive net loss attributable to Dell Technologies Inc. for the fiscal years ended February 3, 2017, January 29, 2016, and January 30, 2015.

[0001571996-17-000004:notes:451]
|  | Fiscal Year Ended |
|  | February 3, 2017 |  | January 29, 2016 |  | January 30, 2015 |
|  | (in millions) |
| Equity in net loss from continuing operations of subsidiaries attributable to Dell Technologies Inc. | $ | (3,684 | ) |  | $ | (1,177 | ) |  | $ | (1,049 | ) |
| Equity in net income (loss) from discontinued operations of subsidiaries | 2,019 |  |  | 64 |  |  | (113 | ) |
| Equity in net loss of subsidiaries attributable to Dell Technologies Inc. | (1,665 | ) |  | (1,113 | ) |  | (1,162 | ) |
| Parent - Interest and other, net | (11 | ) |  | 8 |  |  | (89 | ) |
| Parent - Income tax benefit | 4 |  |  | 1 |  |  | 30 |  |
| Consolidated net loss attributable to Dell Technologies Inc. | $ | (1,672 | ) |  | $ | (1,104 | ) |  | $ | (1,221 | ) |
| Consolidated net loss attributable to Dell Technologies Inc. | $ | (1,672 | ) |  | $ | (1,104 | ) |  | $ | (1,221 | ) |
| Other comprehensive income (loss) of subsidiaries attributable to Dell Technologies Inc. | (271 | ) |  | (353 | ) |  | 56 |  |
| Comprehensive loss attributable to Dell Technologies Inc. | $ | (1,943 | ) |  | $ | (1,457 | ) |  | $ | (1,165 | ) |


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0001571996-17-000004:notes:452]
The following table presents net revenue by business unit categories:

[0001571996-17-000004:notes:453]
|  | Fiscal Year Ended |
|  | February 3, 2017 |  | January 29, 2016 |  | January 30, 2015 |
|  | (in millions) |
| Net revenue: |  |  |  |  |  |  |  |  |
| Client Solutions Group (a): |  |  |  |  |  |
| Commercial | $ | 26,006 |  |  | $ | 25,747 |  |  | $ | 28,754 |  |
| Consumer | 10,748 |  |  | 10,130 |  |  | 10,880 |  |
| Total CSG net revenue | 36,754 |  |  | 35,877 |  |  | 39,634 |  |
| Infrastructure Solutions Group: |  |  |  |  |  |
| Servers and networking | 12,834 |  |  | 12,761 |  |  | 12,368 |  |
| Storage | 8,942 |  |  | 2,217 |  |  | 2,346 |  |
| Total ISG net revenue | 21,776 |  |  | 14,978 |  |  | 14,714 |  |
| VMware |  |  |  |  |  |
| Total VMware net revenue | 3,225 |  |  | — |  |  | — |  |
| Total segment net revenue | $ | 61,755 |  |  | $ | 50,855 |  |  | $ | 54,348 |  |

[0001571996-17-000004:notes:454]
| (a) | During the fiscal year ended February 3, 2017, the Company redefined the categories within the Client Solutions Group business unit. None of these changes impacted the Company's consolidated or total business unit results. |

[0001571996-17-000004:notes:455]
The following tables present net revenue and property, plant, and equipment, net allocated between the United States and foreign countries:

[0001571996-17-000004:notes:456]
|  | Fiscal Year Ended |
|  | February 3, 2017 |  | January 29, 2016 |  | January 30, 2015 |
|  | (in millions) |
| Net revenue: |  |  |  |  |  |  |  |  |
| United States | $ | 30,699 |  |  | $ | 24,309 |  |  | $ | 25,099 |  |
| Foreign countries | 30,943 |  |  | 26,602 |  |  | 29,043 |  |
| Total net revenue | $ | 61,642 |  |  | $ | 50,911 |  |  | $ | 54,142 |  |

[0001571996-17-000004:notes:457]
|  | February 3, 2017 |  | January 29, 2016 |
|  | (in millions) |
| Property, plant, and equipment, net: |  |  |  |
| United States | $ | 4,320 |  |  | $ | 1,172 |  |
| Foreign countries | 1,333 |  |  | 477 |  |
| Total property, plant, and equipment, net | $ | 5,653 |  |  | $ | 1,649 |  |

[0001571996-17-000004:notes:458]
The allocation between domestic and foreign net revenue is based on the location of the customers.  Net revenue from any single foreign country did not constitute more than 10% of the Company's consolidated net revenue for the fiscal year ended February 3, 2017, January 29, 2016, or January 30, 2015.  Property, plant, and equipment, net from any single foreign country did not constitute more than 10% of the Company's consolidated property, plant, and equipment, net as of February 3, 2017 or January 29, 2016.


## us-gaap:ScheduleOfShareBasedCompensationStockOptionsActivityTableTextBlock

[0001571996-17-000004:notes:459]
The following table summarizes stock option activity settled in DHI Group Common Stock during the fiscal years ended February 3, 2017, January 29, 2016, and January 30, 2015:

[0001571996-17-000004:notes:460]
The following table summarizes stock option activity for VMware employees in VMware stock options:


## us-gaap:ScheduleOfShareBasedPaymentAwardStockOptionsValuationAssumptionsTableTextBlock

[0001571996-17-000004:notes:461]
The fair value of each option to acquire VMware Class A common stock granted is estimated on the date of grant using the Black-Scholes option-pricing model with the following weighted-average assumptions:


## us-gaap:ScheduleOfStockByClassTextBlock

[0001571996-17-000004:notes:462]
The following table summarizes the Company's common stock for the periods indicated:

[0001571996-17-000004:notes:463]
|  | Authorized |  | Issued |  | Outstanding |
|  | (in millions) |
| Common stock as of January 29, 2016 |
| Series A | 350 |  |  | 307 |  |  | 307 |  |
| Series B | 150 |  |  | 98 |  |  | 98 |  |
| Series C | 200 |  |  | — |  |  | — |  |
|  | 700 |  |  | 405 |  |  | 405 |  |
| Common stock as of February 3, 2017 |
| Class A | 600 |  |  | 410 |  |  | 410 |  |
| Class B | 200 |  |  | 137 |  |  | 137 |  |
| Class C | 900 |  |  | 22 |  |  | 22 |  |
| Class D | 100 |  |  | — |  |  | — |  |
| Class V | 343 |  |  | 223 |  |  | 209 |  |
|  | 2,143 |  |  | 792 |  |  | 778 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001571996-17-000004:notes:464]
SEGMENT INFORMATION

[0001571996-17-000004:notes:465]
With the closing of the EMC merger transaction on September 7, 2016 and the classification of Dell Services and DSG as discontinued operations during the fiscal year ended February 3, 2017, the Company now has three reportable segments that are based on the following business units: Client Solutions Group ("CSG"); Infrastructure Solutions Group ("ISG"); and VMware.  The ISG segment represents the Company's previous Enterprise Solutions Group ("ESG") segment and EMC's Information Storage segment.  There was no change in the way Dell's legacy business results are allocated between the CSG and ESG (now referred to as ISG) segments as a result of the EMC merger transaction.

[0001571996-17-000004:notes:466]
CSG includes sales to commercial and consumer customers of desktops, thin client products, and notebooks, as well as services and third-party software and peripherals closely tied to the sale of CSG hardware.  ISG includes servers, networking, and storage, as well as services and third-party software and peripherals that are closely tied to the sale of ISG hardware.  VMware includes a broad portfolio of virtualization technologies across three main product groups: software-defined data center; hybrid cloud computing; and end-user computing.

[0001571996-17-000004:notes:467]
The reportable segments disclosed herein are based on information reviewed by the Company's management to evaluate the business segment results.  The Company's measure of segment operating income for management reporting purposes excludes the impact of other businesses, purchase accounting, amortization of intangible assets, unallocated corporate transactions, severance and facility action costs, and transaction-related expenses.  The Company does not allocate assets to the above reportable segments for internal reporting purposes.


## us-gaap:SellingGeneralAndAdministrativeExpensesPolicyTextBlock

[0001571996-17-000004:notes:468]
Selling expenses include items such as sales salaries and commissions, marketing and advertising costs, and contractor services.  Advertising costs are expensed as incurred in selling, general, and administrative expenses in the Consolidated Statements of Income (Loss).  For the fiscal years ended February 3, 2017, January 29, 2016, and January 30, 2015, advertising expenses were $772 million, $594 million, and $582 million, respectively.  General and administrative expenses include items for the Company's administrative functions, such as finance, legal, human resources, and information technology support.  These functions include costs for items such as salaries, maintenance and supplies, insurance, depreciation expense, and allowance for doubtful accounts.


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001571996-17-000004:notes:469]
REDEEMABLE SHARES

[0001571996-17-000004:notes:470]
Awards under the Company's stock incentive plans include certain rights that allow the holder to exercise a put feature for the underlying Classes of A and C Common Stock after a six-month holding period following the issuance of such common stock, requiring the Company to purchase the stock at its fair market value.  Accordingly, these awards and common stock are subject to reclassification from equity to temporary equity, and the Company determines the award amounts to be classified as temporary equity as follows:

[0001571996-17-000004:notes:471]
| • | For stock options subject to service requirements, the intrinsic value of the option is multiplied by the portion of the options for which services have been rendered. Upon exercise of the option(s), the amount in temporary equity represents the fair value of the Class C Common Stock. |

[0001571996-17-000004:notes:472]
| • | For SARs, RSUs, and RSAs, any of which stock award types are subject to service requirements, the fair value of the share is multiplied by the portion of the shares for which services have been rendered. |

[0001571996-17-000004:notes:473]
| • | For share-based arrangements that are subject to the occurrence of a contingent event, those amounts are not reclassified to temporary equity until the contingency has been satisfied. |

[0001571996-17-000004:notes:474]
The amount of redeemable shares classified as temporary equity as of February 3, 2017 and January 29, 2016 was $231 million and $106 million, respectively.  As of February 3, 2017, the redeemable shares consisted of 1.1 million issued and outstanding common shares, 0.4 million RSUs, 0.1 million RSAs, and 13.7 million outstanding stock options.  As of January 29, 2016, the redeemable shares consisted of 0.9 million issued and outstanding common shares, 0.1 million unvested restricted stock units, and 18.6 million outstanding stock options.


## us-gaap:ShippingAndHandlingCostPolicyTextBlock

[0001571996-17-000004:notes:475]
The Company's shipping and handling costs are included in cost of net revenue in the Consolidated Statements of Income (Loss).


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001571996-17-000004:notes:476]
DESCRIPTION OF BUSINESS AND SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES

[0001571996-17-000004:notes:477]
Description of Business — The Company is a strategically aligned family of businesses that offers a broad range of technology solutions, including desktops, notebooks, tablets, servers and networking products, storage products, cloud solutions products, services, software, and third-party software and peripherals.

[0001571996-17-000004:notes:478]
Fiscal Year — The Company's fiscal year is the 52- or 53-week period ending on the Friday nearest January 31.  The fiscal year ended February 3, 2017 ("Fiscal 2017") was a 53-week period.

[0001571996-17-000004:notes:479]
Principles of Consolidation — These consolidated financial statements include the accounts of Dell Technologies and its wholly-owned subsidiaries, as well as the accounts of SecureWorks, VMware, Inc., and Pivotal Software, Inc. ("Pivotal"), companies which are majority-owned by Dell Technologies.  All intercompany transactions have been eliminated.

[0001571996-17-000004:notes:480]
On April 27, 2016, SecureWorks completed a registered underwritten IPO of its Class A common stock.  As of February 3, 2017, Dell Technologies held approximately 87.5% of the outstanding equity interest in SecureWorks.  Since the date of the IPO, the financial results of SecureWorks remain consolidated with those of Dell Technologies as Dell Technologies is the controlling stockholder of SecureWorks.  The portion of the results of operations of SecureWorks allocable to its other owners is shown as net income (loss) attributable to the non-controlling interests in the Consolidated Statements of Income (Loss), as an adjustment to net income (loss) attributable to Dell Technologies stockholders.  Additionally, the cumulative portion of the results of operations of SecureWorks allocable to those other owners, along with the interest in the net assets of SecureWorks attributable to those other owners, is shown as a component of non-controlling interests in the Consolidated Statements of Financial Position as of February 3, 2017.

[0001571996-17-000004:notes:481]
As of February 3, 2017, Dell Technologies held approximately 82.5% of the outstanding equity interest in VMware.  VMware's financial results have been consolidated with those of Dell Technologies as Dell Technologies is VMware's controlling stockholder.  The results of VMware presented in the accompanying Consolidated Financial Statements represent the results of the acquired businesses from September 7, 2016, the date of the EMC merger transaction, through February 3, 2017, the end of the fiscal year of Dell Technologies.  The portion of the results of operations of VMware allocable to its other owners is shown as net income (loss) attributable to the non-controlling interests in the Consolidated Statements of Income (Loss) as an adjustment to net income (loss) attributable to Dell Technologies stockholders.  Additionally, the cumulative portion of the results of operations of VMware allocable to those other owners, along with the interest in the net assets of VMware attributable to those other owners, is shown as a component of non-controlling interests in the Consolidated Statements of Financial Position as of February 3, 2017.

[0001571996-17-000004:notes:482]
As of February 3, 2017, Dell Technologies held approximately 77.8% of the outstanding equity interest in Pivotal.  Pivotal's financial results have been consolidated with those of Dell Technologies as Dell Technologies is Pivotal's controlling stockholder.  The results of Pivotal presented in the accompanying Consolidated Financial Statements represent the results of the acquired businesses from September 7, 2016, the date of the EMC merger transaction, through February 3, 2017, the end of the fiscal year of Dell Technologies.  A portion of the non-controlling interest in Pivotal is held by third parties in the form of preferred equity instruments.  Accordingly, there is no net income attributable to this portion of non-controlling interest in the Consolidated Statements of Income (Loss).  The other portion of the non-controlling interest in Pivotal is held by third parties in the form of common stock.  As such, there is net income (loss) attributable to this portion of non-controlling interest in the Consolidated Statements of Income (Loss) as an adjustment to net income (loss) attributable to Dell Technologies stockholders.  Additionally, the interest in the net assets of Pivotal attributable to those other owners is shown as a component of non-controlling interests in the Consolidated Statements of Financial Position as of February 3, 2017.

[0001571996-17-000004:notes:483]
Use of Estimates — The preparation of financial statements in accordance with GAAP requires management to make estimates and assumptions that affect the amounts reported in the Consolidated Financial Statements and the accompanying Notes.  Actual results could differ materially from those estimates.

[0001571996-17-000004:notes:484]
Cash and Cash Equivalents — All highly liquid investments, including credit card receivables due from banks, with original maturities of 90 days or less at date of purchase, are reported at fair value and are considered to be cash equivalents.  All other investments not considered to be cash equivalents are separately categorized as investments.

[0001571996-17-000004:notes:485]
Investments — All debt security investments with effective maturities in excess of one year and substantially all equity and other securities are recorded as long-term investments in the Consolidated Statements of Financial Position.  In comparison, debt security instruments with a remaining maturity shorter than one year are classified as short-term investments in the Consolidated Statements of Financial Position.

[0001571996-17-000004:notes:486]
Allowance for Doubtful Accounts — The Company recognizes an allowance for losses on accounts receivable in an amount equal to the estimated probable losses, net of recoveries.  The allowance is based on an analysis of historical bad debt experience, current receivables aging, and expected future write-offs, as well as an assessment of specific identifiable customer accounts considered at risk or uncollectible.  The expense associated with the allowance for doubtful accounts is recognized in selling, general, and administrative expenses.

[0001571996-17-000004:notes:487]
Financing Receivables — Financing receivables are presented net of allowance for losses and consist of customer receivables and residual interest.  Customer receivables include revolving loans and fixed-term leases and loans resulting primarily from the sale of the Company's products and services.  The Company has two portfolios: (1) fixed-term leases and loans and (2) revolving loans, and assesses risk at the portfolio level to determine the appropriate allowance levels.  The portfolio segments are further segregated into classes based on products, customer type, and credit risk evaluation: (1) Revolving - Dell Preferred Account ("DPA"); (2) Revolving - Dell Business Credit ("DBC"); (3) Fixed-term - Consumer and Small Commercial; and (4) Fixed-term - Medium and Large Commercial.  Fixed-term leases and loans are offered to qualified small and medium-sized businesses, large commercial accounts, governmental organizations, and educational entities.  Additionally, fixed-term loans are also offered to certain individual consumer customers.  Revolving loans are offered under private label credit financing programs.  The DPA revolving loan programs are offered to individual consumers and the DBC revolving loan programs are offered to small and medium-sized business customers.

[0001571996-17-000004:notes:488]
The Company retains a residual interest in equipment leased under its fixed-term lease programs.  The amount of the residual interest is established at the inception of the lease based upon estimates of the value of the equipment at the end of the lease term using historical studies, industry data, and future value-at-risk demand valuation methods.  On a quarterly basis, the Company assesses the carrying amount of its recorded residual values for impairment.  Anticipated declines in specific future residual values that are considered to be other-than-temporary are recorded currently in earnings.

[0001571996-17-000004:notes:489]
Allowance for Financing Receivable Losses

[0001571996-17-000004:notes:490]
The Company recognizes an allowance for losses on financing receivables in an amount equal to the probable losses net of recoveries.  The allowance for losses is generally determined at the aggregate portfolio level based on a variety of factors, including historical and anticipated experience, past due receivables, receivable type, and customer risk profile.  Customer account principal and interest are charged to the allowance for losses when an account is deemed to be uncollectible or generally when the account is 180 days delinquent.  While the Company does not generally place financing receivables on non-accrual status during the delinquency period, accrued interest is included in the allowance for loss calculation and, therefore, the Company is adequately reserved in the event of charge off.  Recoveries on receivables previously charged off as uncollectible are recorded to the allowance for financing receivables losses.  The expense associated with the allowance for financing receivables losses is recognized as cost of net revenue.  Both fixed and revolving receivable loss rates are affected by macro-economic conditions, including the level of gross domestic product ("GDP") growth, unemployment rates, the level of commercial capital equipment investment, and the credit quality of the borrower.

[0001571996-17-000004:notes:491]
Asset Securitization

[0001571996-17-000004:notes:492]
The Company transfers certain U.S. customer financing receivables to Special Purpose Entities ("SPEs") that meet the definition of a Variable Interest Entity ("VIE") and are consolidated into the Consolidated Financial Statements.  These SPEs are bankruptcy-remote legal entities with separate assets and liabilities.  The purpose of the SPEs is to facilitate the funding of customer receivables in the capital markets.  These SPEs have entered into financing arrangements with multi-seller conduits that, in turn, issue asset-backed debt securities in the capital markets.  The asset securitizations in the SPEs are accounted for as secured borrowings.  See Note 7 of the Notes to the Consolidated Financial Statements for additional information on the impact of the consolidation.

[0001571996-17-000004:notes:493]
Inventories — Inventories are stated at the lower of cost or market with cost being determined on a first-in, first-out basis.  Adjustments to reduce the cost of inventory to its net realizable value are made, if required, for estimated excess, obsolescence, or impaired balances.

[0001571996-17-000004:notes:494]
Property, Plant, and Equipment — Property, plant, and equipment are carried at depreciated cost.  Depreciation is determined using the straight-line method over the estimated economic lives of the assets, which range from ten to thirty years for buildings and two to ten years for all other assets.  Leasehold improvements are amortized over the shorter of five years or the lease term.  Gains or losses related to retirements or disposition of fixed assets are recognized in the period during which the retirement or disposition occurs.

[0001571996-17-000004:notes:495]
Capitalized Software Development Costs — In accordance with the applicable accounting standards, software development costs related to the development of new product offerings are capitalized subsequent to the establishment of technological feasibility, which is demonstrated by the completion of a detailed program design or working model, if no program design is completed.  GAAP requires that annual amortization expense of the capitalized software development costs be the greater of the amounts computed using the ratio of gross revenue to a product's total current and anticipated revenues, or the straight-line method over the product's remaining estimated economic life.  Capitalized costs are amortized over periods ranging from eighteen months to two years which represents the product's estimated economic life.

[0001571996-17-000004:notes:496]
As of February 3, 2017, capitalized software development costs were $202 million and are included in other non-current assets, net in the accompanying Consolidated Statements of Financial Position.  Amortization expense for the period from September 7, 2016 through February 3, 2017 was immaterial.  Prior to the EMC merger transaction, there were no significant capitalized software development costs specific to the remaining legacy businesses of Dell Technologies Inc. due to the timing in the research and development process of establishing technological feasibility.

[0001571996-17-000004:notes:497]
The Company capitalizes eligible internal-use software development costs incurred subsequent to the completion of the preliminary project stage.  Development costs are amortized over the shorter of the expected useful life of the software or five years.  Costs associated with maintenance and minor enhancements to the features and functionality of the Company's website are expensed as incurred.

[0001571996-17-000004:notes:498]
Impairment of Long-Lived Assets — The Company reviews long-lived assets for impairment when circumstances indicate the carrying amount of an asset may not be recoverable based on the undiscounted future cash flows of the assets.  If the carrying amount of the asset is determined not to be recoverable, a write-down to fair value is recorded.  Fair values are determined based on quoted market values, discounted cash flows, or external appraisals, as applicable.  The Company reviews long-lived assets for impairment at the individual asset or the asset group level for which the lowest level of independent cash flows can be identified.

[0001571996-17-000004:notes:499]
Business Combinations — The Company accounts for business combinations, including the EMC merger transaction and the going-private transaction described in Note 1 of the Notes to the Consolidated Financial Statements, using the acquisition method of accounting.  See Note 3 of the Notes to the Consolidated Financial Statements for more information on the EMC merger transaction.  Accordingly, the assets and liabilities of the acquired business are recorded at their fair values at the date of acquisition.  The excess of the purchase price over the fair value of the tangible and intangible assets acquired and the liabilities assumed is recorded as goodwill.  During the measurement period, if new information is obtained about facts and circumstances that existed as of the acquisition date, cumulative changes in the estimated fair values of the net assets recorded may change the amount of the purchase price allocable to goodwill.  During the measurement period, which expires one year from the acquisition date, changes to any purchase price allocations that are material to the Company's consolidated financial results will be adjusted in the reporting period in which the adjustment amount is determined.

[0001571996-17-000004:notes:500]
In-process research and development costs are recorded at fair value as an indefinite-lived intangible asset and assessed for impairment thereafter until completion, at which point the asset is amortized over its expected useful life.  All acquisition costs are expensed as incurred, and the results of operations of acquired businesses are included in the Consolidated Financial Statements from the acquisition date.

[0001571996-17-000004:notes:501]
Intangible Assets Including Goodwill — Identifiable intangible assets with finite lives are amortized over their estimated useful lives.  In addition, intangible assets are reviewed for impairment if indicators of potential impairment exist.  Goodwill and indefinite-lived intangible assets are tested for impairment on an annual basis in the third fiscal quarter, or sooner if an indicator of impairment occurs.

[0001571996-17-000004:notes:502]
Foreign Currency Translation — The majority of the Company's international sales are made by international subsidiaries, most of which have the U.S. dollar as their functional currency.  The Company's subsidiaries that do not have the U.S. dollar as their functional currency translate assets and liabilities at current rates of exchange in effect at the balance sheet date.  Revenue and expenses from these international subsidiaries are translated using the monthly average exchange rates in effect for the period in which the transactions occur.  Foreign currency translation adjustments are included as a component of accumulated other comprehensive income (loss) ("OCI") in stockholders' equity.

[0001571996-17-000004:notes:503]
Hedging Instruments — The Company uses derivative financial instruments, primarily forwards, options, and swaps, to hedge certain foreign currency and interest rate exposures.  The relationships between hedging instruments and hedged items, as well as the risk management objectives and strategies for undertaking hedge transactions, are formally documented.  The Company does not use derivatives for speculative purposes.

[0001571996-17-000004:notes:504]
Cash flows from derivative instruments are presented in the same category on the Consolidated Statements of Cash Flows as the cash flows from the underlying hedged items.  See Note 9 of the Notes to the Consolidated Financial Statements for a description of the Company's derivative financial instrument activities.

[0001571996-17-000004:notes:505]
Revenue Recognition — Net revenue primarily includes sales of hardware, services, software licenses, and peripherals.  The Company recognizes revenue for these products and services when it is realized or realizable and earned.  Revenue is recognized when persuasive evidence of an arrangement exists; delivery has occurred or services have been rendered; the Company's fee to its customer is fixed or determinable; and collection of the resulting receivable is reasonably assured.  This policy is applicable to all sales, including sales to resellers and end-users.

[0001571996-17-000004:notes:506]
Standard Warranty Liabilities — The Company records warranty liabilities for its standard limited warranty at the time of sale for the estimated costs that may be incurred under its limited warranty.  The liability for standard warranties is included in accrued and other current and other non-current liabilities in the Consolidated Statements of Financial Position.  The specific warranty terms and conditions vary depending upon the product sold and the country in which the Company does business, but generally includes technical support, parts, and labor over a period ranging from one to three years.  Factors that affect the Company's warranty liability include the number of installed units currently under warranty, historical and anticipated rates of warranty claims on those units, and cost per claim to satisfy the Company's warranty obligation.  The anticipated rate of warranty claims is the primary factor impacting the estimated warranty obligation.  The other factors are less significant due to the fact that the average remaining aggregate warranty period of the covered installed base is approximately 17 months, repair parts are generally already in stock or available at pre-determined prices, and labor rates are generally arranged at pre-established amounts with service providers.  Warranty claims are relatively predictable based on historical experience of failure rates.  If actual results differ from the estimates, the Company revises its estimated warranty liability.  Each quarter, the Company reevaluates its estimates to assess the adequacy of its recorded warranty liabilities and adjusts the amounts as necessary.

[0001571996-17-000004:notes:507]
Deferred Revenue — Deferred revenue is recorded when billings have been generated or payments have been received for undelivered products or services, or in the situation where revenue recognition criteria have not been met.  Deferred revenue represents amounts received in advance for extended warranty services, software maintenance, unearned license fees, and deferred profit on third-party software offerings.  Deferred revenue is recognized on these items when the revenue recognition criteria are met, generally resulting in ratable recognition over the contract term.  We also have deferred revenue related to undelivered hardware and professional services, consisting of installations and consulting engagements, which are recognized as our obligations under the contract are completed.

[0001571996-17-000004:notes:508]
Vendor Rebates and Settlements — The Company may receive consideration from vendors in the normal course of business.  Certain of these funds are rebates of purchase price paid and others are related to reimbursement of costs incurred by the Company to sell the vendor's products.  The Company recognizes a reduction of cost of goods sold and inventory if the funds are determined to be a reduction of the price of the vendor's products.  If the consideration is a reimbursement of costs incurred by the Company to sell or develop the vendor's products, then the consideration is classified as a reduction of that cost, most often operating expenses, in the Consolidated Statements of Income (Loss).  In order to be recognized as a reduction of operating expenses, the reimbursement must be for a specific, incremental, and identifiable cost incurred by the Company in selling the vendor's products or services.

[0001571996-17-000004:notes:509]
In addition, the Company may settle commercial disputes with vendors from time to time.  Claims for loss recoveries are recognized when a loss event has occurred, recovery is considered probable, the agreement is finalized, and collectibility is assured.  Amounts received by the Company from vendors for loss recoveries are generally recorded as a reduction of cost of goods sold.

[0001571996-17-000004:notes:510]
Loss Contingencies — The Company is subject to the possibility of various losses arising in the ordinary course of business.  The Company considers the likelihood of loss or impairment of an asset or the incurrence of a liability, as well as the Company's ability to reasonably estimate the amount of loss, in determining loss contingencies.  An estimated loss contingency is accrued when it is probable that an asset has been impaired or a liability has been incurred and the amount of loss can be reasonably estimated.  The Company regularly evaluates current information available to determine whether such accruals should be adjusted and whether new accruals are required.

[0001571996-17-000004:notes:511]
Shipping Costs — The Company's shipping and handling costs are included in cost of net revenue in the Consolidated Statements of Income (Loss).

[0001571996-17-000004:notes:512]
Selling, General, and Administrative — Selling expenses include items such as sales salaries and commissions, marketing and advertising costs, and contractor services.  Advertising costs are expensed as incurred in selling, general, and administrative expenses in the Consolidated Statements of Income (Loss).  For the fiscal years ended February 3, 2017, January 29, 2016, and January 30, 2015, advertising expenses were $772 million, $594 million, and $582 million, respectively.  General and administrative expenses include items for the Company's administrative functions, such as finance, legal, human resources, and information technology support.  These functions include costs for items such as salaries, maintenance and supplies, insurance, depreciation expense, and allowance for doubtful accounts.

[0001571996-17-000004:notes:513]
Research and Development — Research and development ("R&D") costs are expensed as incurred.  R&D costs include salaries and benefits and other personnel-related costs associated with product development.  Also included in R&D expenses are infrastructure costs, which consist of equipment and material costs, facilities-related costs, depreciation expense, and intangible asset amortization.

[0001571996-17-000004:notes:514]
Income Taxes — Deferred tax assets and liabilities are recorded based on the difference between the financial statement and tax basis of assets and liabilities using enacted tax rates in effect for the year in which the differences are expected to reverse.  The Company calculates a provision for income taxes using the asset and liability method, under which deferred tax assets and liabilities are recognized by identifying the temporary differences arising from the different treatment of items for tax and accounting purposes.  The Company provides valuation allowances for deferred tax assets, where appropriate.  In assessing the need for a valuation allowance, the Company considers all available evidence for each jurisdiction, including past operating results, estimates of future taxable income, and the feasibility of ongoing tax planning strategies.  In the event the Company determines that all or part of the net deferred tax assets are not realizable in the future, the Company will make an adjustment to the valuation allowance that would be charged to earnings in the period in which such determination is made.

[0001571996-17-000004:notes:515]
The accounting guidance for uncertainties in income tax prescribes a comprehensive model for the financial statement recognition, measurement, presentation, and disclosure of uncertain tax positions taken or expected to be taken in income tax returns.  The Company recognizes a tax benefit from an uncertain tax position in the financial statements only when it is more likely than not that the position will be sustained upon examination, including resolution of any related appeals or litigation processes, based on the technical merits and a consideration of the relevant taxing authority's administrative practices and precedents.

[0001571996-17-000004:notes:516]
Stock-Based Compensation — The Company measures stock-based compensation expense for all share-based awards granted based on the estimated fair value of those awards at grant date.  For service-based stock options, the Company typically estimates the fair value of these awards using the Black-Scholes valuation model and for performance-based stock options, the Company estimates the fair value of these awards using the Monte Carlo valuation model.

[0001571996-17-000004:notes:517]
The compensation cost of service-based stock options, restricted stock, and restricted stock units is recognized net of any estimated forfeitures on a straight-line basis over the employee requisite service period.  Compensation cost for performance-based options, containing a market condition, is recognized on a graded accelerated basis net of estimated forfeitures over the requisite service period.  Forfeiture rates are estimated at grant date based on historical experience and adjusted in subsequent periods for differences in actual forfeitures from those estimates.  See Note 19 of the Notes to the Consolidated Financial Statements for further discussion of stock-based compensation.

[0001571996-17-000004:notes:518]
Recently Issued Accounting Pronouncements


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001571996-17-000004:notes:519]
CAPITALIZATION

[0001571996-17-000004:notes:520]
Reclassification — On September 5, 2016, before the registration of the Class V Common Stock of Dell Technologies under Section 12 of the Securities Exchange Act of 1934 in connection with the EMC merger transaction, holders of a majority of the outstanding shares of the Company's Series A Common Stock, Series B Common Stock, and Series C Common Stock approved the Fourth Amended and Restated Certificate of Incorporation of the Company (the "Amended and Restated Certificate of Incorporation") and the Amended and Restated Bylaws of the Company (the "Amended and Restated Bylaws").  The Amended and Restated Certificate of Incorporation and the Amended and Restated Bylaws became effective on September 7, 2016 before the closing of the EMC merger transaction.  Upon the effectiveness of the Amended and Restated Certificate of Incorporation, the outstanding shares of the Company's Series A Common Stock, Series B Common Stock, and Series C Common Stock were automatically reclassified on a one-for-one basis into newly authorized shares of the Company's Class A Common Stock, Class B Common Stock, and Class C Common Stock, respectively (the "Reclassification").  The Amended and Restated Certificate of Incorporation also amended the Company's prior certificate of incorporation to authorize the Class D Common Stock and the Class V Common Stock.  The Reclassification did not affect the Company's consolidated financial position or results of operations.  Share information in the Consolidated Financial Statements has been restated to reflect the Reclassification.

[0001571996-17-000004:notes:521]
Preferred Stock — Dell Technologies is authorized to issue one million shares of preferred stock, par value $.01 per share.  As of February 3, 2017, no shares of preferred stock were issued or outstanding.

[0001571996-17-000004:notes:522]
Common Stock

[0001571996-17-000004:notes:523]
DHI Group Common Stock — The Class A Common Stock, the Class B Common Stock, the Class C Common Stock, and the Class D Common Stock are collectively referred to as the DHI Group Common Stock.  The par value for all classes of DHI Group Common Stock is $.01 per share.  The Class A Common Stock, the Class B Common Stock, the Class C Common Stock, and the Class D Common Stock share equally in dividends declared or accumulated and have equal participation rights in undistributed earnings.

[0001571996-17-000004:notes:524]
Of the 164 million shares of DHI Group Common Stock issued during the fiscal year ended February 3, 2017, 160 million shares were issued in connection with the EMC merger transaction.  The Company issued and sold the following shares of DHI Group Common Stock at a purchase price of $27.50 per share to the persons identified below for an aggregate purchase price of $4.4 billion, pursuant to four separate common stock purchase agreements:

[0001571996-17-000004:notes:525]
| • | 18,181,818 shares of Class C Common Stock to Temasek |

[0001571996-17-000004:notes:526]
The Company applied the proceeds from the sale of the shares to finance a portion of the consideration for the EMC merger transaction.

[0001571996-17-000004:notes:527]
Class V Common Stock — In connection with the EMC merger transaction, Dell Technologies authorized the issuance of 343 million shares of $.01 par value Class V Common Stock.  Dell Technologies issued 223 million shares of Class V Common Stock to EMC shareholders on September 7, 2016 at a purchase price of $45.07 per share for an aggregate purchase price of approximately $10.0 billion.  These 223 million shares are intended to track the economic performance of approximately 65% of Dell Technologies' economic interest in the Class V Group as of the closing date of the EMC merger transaction, while the remaining 120 million authorized and unissued shares represent the DHI Group's retained interest in approximately 35% of Dell Technologies' economic interest in the Class V Group as of such date.  As of the closing date of the EMC merger transaction, the assets of the Class V Group consisted solely of 343 million shares of VMware Class A common stock held by the Company.  Each share of Class V Common Stock is identical in all respects with, and has rights, powers, and privileges equal to those of, each other share of Class V Common Stock.

[0001571996-17-000004:notes:528]
Dell Technologies' board of directors may, with the approval of the independent capital stock committee of the board of directors, reallocate assets or liabilities between the Class V Group and the DHI Group, which could result in a change to the DHI Group's retained interest in the Class V Group.  The relative economic interests of the two Groups, including the DHI Group's retained interest in the Class V Group, could also change if the Company issues or repurchases shares of Class V Common Stock.

[0001571996-17-000004:notes:529]
As of February 3, 2017, as described further below under "Repurchases of Common Stock; Treasury Stock," the Class V Common Stock had an approximately 62% interest in the Class V Group, while the DHI Group had an approximately 38% retained interest.  See Exhibit 99.1 to the Company's annual report on Form 10-K for the fiscal year ended February 3, 2017 for more information regarding Unaudited Attributed Financial Information for the Class V Group.

[0001571996-17-000004:notes:530]
The Company has the authority and discretion to declare and pay (or to refrain from declaring and paying) dividends on outstanding shares of DHI Group Common Stock and dividends on outstanding shares of Class V Common Stock, in equal or unequal amounts, or only on the DHI Group Common Stock or the Class V Common Stock.  In the event of a liquidation, dissolution, distribution of assets, or winding up of the Company, the holders of shares of DHI Group Common Stock and the holders of shares of Class V Common Stock will be entitled to receive their proportionate interests in the assets of the Company remaining for distribution to holders of stock in proportion to the respective number of liquidation units per share of DHI Group Common Stock and Class V Common Stock, respectively.

[0001571996-17-000004:notes:531]
Repurchases of Common Stock; Treasury Stock

[0001571996-17-000004:notes:532]
Class V Common Stock Repurchases — On September 7, 2016, the board of directors of the Company approved a stock repurchase program (the "DHI Group Repurchase Program") under which the Company is authorized to use assets of the DHI Group to repurchase up to $1.0 billion of shares of Class V Common Stock over a period of two years.  On December 13, 2016, the board of directors approved the suspension of the DHI Group Repurchase Program until such time as the board of directors authorizes the reinstatement of that program.  During the fiscal year ended February 3, 2017, the Company repurchased 7 million shares of Class V Common Stock for $324 million using cash of the DHI Group.  Shares repurchased under the DHI Group Repurchase Program are being held as treasury stock at cost.  As of February 3, 2017, the Company's remaining authorized amount for share repurchases under the DHI Group Repurchase Program was $676 million.  As cash of the DHI Group was used for Class V Common Stock repurchases under the DHI Group Repurchase Program, these repurchased shares were attributed to the DHI Group for the purposes of determining the DHI Group's retained interest in the Class V Group.  As a result, the number of retained interest shares of the DHI Group, which, together with the number of shares of Class V Common Stock outstanding, are used to calculate such retained interest, increased on a one-for-one basis for each share of Class V Common Stock repurchased under the program.

[0001571996-17-000004:notes:533]
On December 13, 2016, the board of directors approved a new stock repurchase program (the "Class V Group Repurchase Program") under which the Company is authorized to use assets of the Class V Group to repurchase up to $500 million of shares of Class V Common Stock over a period of six months.  To the extent not retired, shares repurchased under the Class V Group Repurchase Program will be held as treasury stock at cost.  The repurchase of shares pursuant to the Class V Group Repurchase Program was funded from proceeds received by the Company from the sale by a subsidiary of the Company to VMware of shares of Class A common stock of VMware owned by such subsidiary, as described below under "VMware Class A Common Stock Repurchases."  During the fiscal year ended February 3, 2017, the Company repurchased 7 million shares of Class V Common Stock for $418 million under the Class V Group Repurchase Program, of which $41 million of repurchases were settled subsequent to the close of the Company's fiscal year.  These repurchased shares of Class V Common Stock are being held as treasury stock at cost.  As of February 3, 2017, the Company's remaining authorized amount for share repurchases under the Class V Group Repurchase Program was $82 million.  Subsequent to the close of the Company's fiscal year, the Company repurchased an additional 1 million shares of its Class V Common Stock to complete the transactions contemplated by the program.

[0001571996-17-000004:notes:534]
As cash of the Class V Group is used for repurchases of Class V Common Stock made under the Class V Group Repurchase Program, these repurchased shares are not attributed to the DHI Group for the purposes of determining the DHI Group's retained interest in the Class V Group.  As a result, although the number of outstanding shares of Class V Common Stock is reduced by the number of shares of Class V Common Stock repurchased under the program, the number of retained interest shares of the DHI Group is not affected.  However, the DHI Group's retained interest in the Class V Group is increased relative to the interest of the Class V Common Stock due to the reduction in the number of outstanding shares of Class V Common Stock resulting from repurchases under the program.  Share repurchases made by VMware of its Class A common stock from a subsidiary of the Company do not affect the determination of the respective interests of the Class V Common Stock and the DHI Group in the Class V Group.

[0001571996-17-000004:notes:535]
As of February 3, 2017, as a result of repurchases under the DHI Group Repurchase Program and the Class V Group Repurchase Program, the holders of the Class V Common Stock owned approximately 209 million shares which in the aggregate track the economic performance of approximately 62% of Dell Technologies' economic interest in the Class V Group, and the number of retained interest shares of the DHI Group was approximately 127 million shares, representing the remaining 38% economic interest in the Class V Group.

[0001571996-17-000004:notes:536]
VMware Class A Common Stock Repurchases — In April 2016, VMware's board of directors authorized the repurchase of up to $1.2 billion of shares of VMware's Class A common stock through the end of 2016.  All shares repurchased under VMware's stock repurchase programs are retired.  During the period from September 7, 2016 through February 3, 2017, VMware repurchased $611 million of its Class A common stock under the April 2016 program, and the authorized amount for repurchases of VMware common stock was fully utilized as of February 3, 2017.  These shares were purchased from public stockholders in open market transactions and were unrelated to the Class V Group Repurchase Program.

[0001571996-17-000004:notes:537]
On December 15, 2016, the Company entered into a stock purchase agreement with VMware pursuant to which VMware agreed to repurchase for cash $500 million of shares of VMware Class A common stock from a subsidiary of the Company.  The Company will apply the proceeds from the sale to the repurchase of shares of its Class V Common Stock under the Class V Group Repurchase Program described above.  During the period from September 7, 2016 through February 3, 2017, VMware repurchased approximately 4.8 million shares of its Class A common stock under the December 2016 program.  On February 15, 2017, subsequent to the close of the Company's fiscal year, VMware repurchased an additional 1.4 million shares of its Class A common stock to complete the transactions contemplated by the stock purchase agreement.

[0001571996-17-000004:notes:538]
In January 2017, VMware's board of directors authorized the repurchase of up to $1.2 billion of shares of VMware's Class A common stock through the end of Fiscal 2018.

[0001571996-17-000004:notes:539]
DHI Group Common Stock Repurchases — During the fiscal year ended February 3, 2017, the Company repurchased an immaterial number of shares of DHI Group Common Stock for approximately $10 million.


## us-gaap:SubsequentEventsTextBlock

[0001571996-17-000004:notes:540]
SUBSEQUENT EVENTS

[0001571996-17-000004:notes:541]
Refinancing of Term Loan B Facility — On March 8, 2017, the Company refinanced the Term Loan B Facility to reduce the interest rate margin by 0.75% and to increase outstanding principal by $500 million.

[0001571996-17-000004:notes:542]
Repayment of Margin Bridge Facility — On March 8, 2017, the Company applied cash proceeds from the Term Loan B Facility refinancing to repay $500 million principal amount of the Margin Bridge Facility, without premium or penalty, and accrued and unpaid interest thereon.

[0001571996-17-000004:notes:543]
Amendment of Class V Common Stock Repurchase Program — On March 27, 2017, the Company's board of directors approved an amendment to the Class V Group Repurchase Program authorizing the Company to use assets of the Company's Class V Group to repurchase up to an additional $300 million of shares of the Company's Class V Common Stock from time to time over a period of six months from the date of the approval.

[0001571996-17-000004:notes:544]
Stock Purchase Agreement for Sale of VMware Class A Common Stock — On March 29, 2017, the Company entered into a stock purchase agreement with VMware pursuant to which VMware agreed to purchase for cash $300 million of shares of VMware Class A common stock from a subsidiary of the Company.  The Company expects to apply the proceeds from the sale to the repurchase of shares of the Company's Class V Common Stock under the amended Class V Group Repurchase Program described above.

[0001571996-17-000004:notes:545]
Other than the matters identified above, there were no known events occurring after the balance sheet date and up until the date of the issuance of this report that would materially affect the information presented herein.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001571996-17-000004:notes:546]
ADDITIONAL CONSOLIDATED FINANCIAL INFORMATION

[0001571996-17-000004:notes:547]
Additional Consolidated Statements of Financial Position Information

[0001571996-17-000004:notes:548]
During the fiscal years ended February 3, 2017, January 29, 2016, and January 30, 2015 the Company recognized $1,158 million, $523 million, and $516 million, respectively, in depreciation expense.

[0001571996-17-000004:notes:549]
Additional Consolidated Statements of Income (Loss) Information

[0001571996-17-000004:notes:550]
Condensed Financial Information of Parent Company

[0001571996-17-000004:notes:551]
Dell Technologies Inc. has no material assets or standalone operations other than its ownership in its consolidated subsidiaries.  There are restrictions under credit agreements and indentures governing the First Lien Notes and the Senior Notes on the Company's ability to obtain funds from any of its subsidiaries through dividends, loans, or advances.  As of February 3, 2017, the Company had certain consolidated subsidiaries that were designated as unrestricted subsidiaries for all purposes of the applicable credit agreements and such indentures.  As of February 3, 2017, substantially all of the net assets of the Company's consolidated subsidiaries were restricted, with the exception of the Company's unrestricted subsidiaries, primarily VMware and SecureWorks.  Accordingly, this condensed financial information is presented on a "Parent-only" basis.  Under a Parent-only presentation, Dell Technologies Inc.'s investments in its consolidated subsidiaries are presented under the equity method of accounting.
