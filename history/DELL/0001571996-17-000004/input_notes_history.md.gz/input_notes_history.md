# DELL note change history — 0001571996-16-000015 → 0001571996-16-000021


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2016-12-09):
[0001571996-16-000021:note_history:1]
Lease Commitments — The Company leases property and equipment, manufacturing facilities, and office space under non-cancelable leases. Certain of these leases obligate the Company to pay taxes, maintenance, and repair costs. At October 28, 2016, future minimum lease payments under these non-cancelable leases were as follows: $63 million in Fiscal 2017; $473 million in Fiscal 2018; $373 million in Fiscal 2019; $285 million in Fiscal 2020; $221 million in Fiscal 2021; and $963 million thereafter.

- added (2016-12-09):
[0001571996-16-000021:note_history:2]
For the three and nine months ended October 28, 2016, rent expense under all leases totaled $110 million and $179 million, respectively. For the three and nine months ended October 30, 2015, rent expense under all leases totaled $33 million and $99 million, respectively.

- added (2016-12-09):
[0001571996-16-000021:note_history:3]
Purchase Obligations — The Company has contractual obligations to purchase goods or services, which specify significant

- added (2016-12-09):
[0001571996-16-000021:note_history:4]
terms, including fixed or minimum quantities to be purchased; fixed, minimum, or variable price provisions; and the

- added (2016-12-09):
[0001571996-16-000021:note_history:5]
approximate timing of the transaction. As of October 28, 2016, the Company had $2,510 million, $137 million, and $112 million in purchase obligations for Fiscal 2017, Fiscal 2018, and Fiscal 2019 and thereafter, respectively.

- added (2016-12-09):
[0001571996-16-000021:note_history:6]
EMC Merger Litigation — The Company, Dell, and Universal Acquisition Co. (“Universal”) have been named as defendants in fifteen putative class-action lawsuits brought by purported EMC shareholders and VMware stockholders challenging the proposed merger between the Company, Dell, and Universal on the one hand, and EMC on the other (the “EMC merger”).  Those suits are captioned as follows:

- added (2016-12-09):
[0001571996-16-000021:note_history:7]
| Case | Court | Filing Date |
| 1. | IBEW Local No. 129 Benefit Fund v. Tucci,Civ. No. 1584-3130-BLS1 | Mass. Superior Court, Suffolk County | 10/15/2015 |
| 2. | Barrett v. Tucci,Civ. No. 15-6023-A | Mass. Superior Court, Middlesex County | 10/16/2015 |
| 3. | Graulich v. Tucci,Civ. No. 1584-3169-BLS1 | Mass. Superior Court, Suffolk County | 10/19/2015 |
| 4. | Vassallo v. EMC Corp.,Civ. No. 1584-3173-BLS1 | Mass. Superior Court, Suffolk County | 10/19/2015 |
| 5. | City of Miami Police Relief & Pension Fund v. Tucci,Civ. No. 1584-3174-BLS1 | Mass. Superior Court, Suffolk County | 10/19/2015 |
| 6. | Lasker v. EMC Corp.,Civ. No. 1584-3214-BLS1 | Mass. Superior Court, Suffolk County | 10/23/2015 |
| 7. | Walsh v. EMC Corp.,Civ. No. 15-13654 | U.S. District Court,District of Massachusetts | 10/27/2015 |
| 8. | Local Union No. 373 U.A. Pension Plan v. EMC Corp.,Civ. No. 1584-3253-BLS1 | Mass. Superior Court, Suffolk County | 10/28/2015 |
| 9. | City of Lakeland Emps.’ Pension & Ret. Fund v. Tucci,Civ. No. 1584-3269-BLS1 | Mass. Superior Court, Suffolk County | 10/28/2015 |
| 10. | Ma v. Tucci,Civ. No. 1584-3281-BLS1 | Mass. Superior Court, Suffolk County | 10/29/2015 |
| 11. | Stull v. EMC Corp.,Civ. No. 15-13692 | U.S. District Court,District of Massachusetts | 10/30/2015 |
| 12. | Jacobs v. EMC Corp.,Civ. No. 15-6318-H | Mass. Superior Court, Middlesex County | 11/12/2015 |
| 13. | Ford v. VMware, Inc.,C.A. No. 11714-VCL | Delaware Chancery Court | 11/17/2015 |
| 14. | Pancake v. EMC Corp.,Civ. No. 16-10040 | U.S. District Court,District of Massachusetts | 1/11/2016 |
| 15. | Booth Family Trust v. EMC Corp.,Civ. No. 16-10114 | U.S. District Court,District of Massachusetts | 1/26/2016 |

- changed (2016-12-09):
[0001571996-16-000021:note_history:8]
The fifteen lawsuits seek, among other things, injunctive relief enjoining the EMC merger, rescission of the EMC merger if consummated, an award of fees and costs, and/or an award of damages.
  (was, 2016-09-06, similarity 0.9894):
[0001571996-16-000015:note_history:8]
The fifteen lawsuits seek, among other things, injunctive relief enjoining the EMC merger, rescission of the EMC merger if consummated, an award of fees and costs, or an award of damages.

- changed (2016-12-09):
[0001571996-16-000021:note_history:9]
The complaints in the IBEW, Barrett, Graulich, Vassallo, City of Miami, Lasker, Local Union No. 373, City of Lakeland, and Ma actions generally allege that the EMC directors breached their fiduciary duties to EMC shareholders in connection with the EMC merger by, among other things, failing to maximize shareholder value and agreeing to provisions in the EMC merger agreement that discourage competing bids. The complaints generally further allege that there were various conflicts of interest in the proposed transaction. The IBEW, Graulich, City of Miami, and Ma plaintiffs brought suit against the Company, Dell, and Universal for injunctive relief.  The Barrett, Vassallo, Lasker, Lakeland, and Local Union No. 373 plaintiffs brought suit against the Company, Dell, and Universal as alleged aiders and abettors.   After consolidating the nine complaints, by decision dated December 7, 2015, the Business Litigation Session of the Suffolk County Superior Court in Massachusetts, dismissed all nine complaints for failure to make a demand on the EMC board of directors.  Three of the nine plaintiffs in the consolidated actions appealed the judgment dismissing their complaints.  The Massachusetts Supreme Judicial Court granted an application for direct appellate review, and heard oral argument on the appeal on November 7, 2016.  The outcome of the appeal is uncertain.
  (was, 2016-09-06, similarity 0.7886):
[0001571996-16-000015:note_history:9]
The complaints in the IBEW, Barrett, Graulich, Vassallo, City of Miami, Lasker, Local Union No. 373, City of Lakeland, and Ma actions generally allege that the EMC directors breached their fiduciary duties to EMC shareholders in connection with the EMC merger by, among other things, failing to maximize shareholder value and agreeing to provisions in the EMC merger agreement that discourage competing bids. The complaints generally further allege that there were various conflicts of interest in the proposed transaction. The IBEW, Graulich, City of Miami, and Ma plaintiffs brought suit against the Company, Dell, and Universal for injunctive relief.  The Barrett, Vassallo, Lasker, Lakeland, and Local Union No. 373 plaintiffs brought suit against the Company, Dell, and Universal as alleged aiders and abettors.   After consolidating the nine complaints, by decision dated December 7, 2015, the Suffolk County, Massachusetts Superior Court, Business Litigation Session, dismissed all nine complaints for failure to make a demand on the EMC board of directors.  On January 21, 2016, the plaintiffs in the consolidated actions appealed.  That appeal is pending before the Massachusetts Supreme Court.

- changed (2016-12-09):
[0001571996-16-000021:note_history:10]
The complaints in the Walsh, Stull, Pancake, and Booth actions allege that the EMC directors breached their fiduciary duties to EMC shareholders in connection with the EMC merger by, among other things, failing to maximize shareholder value and agreeing to provisions in the EMC merger agreement that discourage competing bids. The complaints generally further allege that there were various conflicts of interest in the proposed transaction and that the preliminary SEC Form S-4 filed by the Company on December 14, 2015 in connection with the transaction contained material misstatements and omissions, in violation of Section 14(a) of the Securities Exchange Act of 1934 (the "Exchange Act”) and SEC Rule 14a-9 promulgated thereunder (“Rule 14a-9”).  Under the amended complaints, the plaintiffs in the Walsh, Stull, and Pancake actions have brought suit against the Company, Dell, and Universal under Section 20(a) of the Exchange Act as alleged controlling persons of EMC.  The plaintiffs in the Booth action have brought suit against the Company, Dell, and Universal under Section 14(a) of the Exchange Act and Rule 14a-9.  On April 26, 2016, the Court consolidated the actions and entered an order appointing Plaintiff Stull as lead plaintiff and his choice of counsel as lead and liaison counsel.  On June 6, 2016, the Securities and Exchange Commission declared effective the Company’s registration statement on Form S-4 relating to the EMC merger (the “SEC Form S-4”), including the amendments thereto.  On June 17, 2016, the parties to the Walsh, Stull, Pancake, and Booth actions submitted to the Court a Stipulation and Proposed Order Dismissing Action and Retaining Jurisdiction to Determine Plaintiffs’ Counsel’s Application for an Award of Attorneys’ Fees and Reimbursement of Expenses.  In the stipulation, the plaintiffs represented to the Court that they believe sufficient information had been disclosed to warrant dismissal of the actions as moot in light of the disclosures in the SEC Form S-4, including the amendments thereto.  The Court has entered the proposed order and the cases are now dismissed.
  (was, 2016-09-06, similarity 0.9778):
[0001571996-16-000015:note_history:10]
The complaints in the Walsh, Stull, Pancake, and Booth actions allege that the EMC directors breached their fiduciary duties to EMC shareholders in connection with the EMC merger by, among other things, failing to maximize shareholder value and agreeing to provisions in the EMC merger agreement that discourage competing bids. The complaints generally further allege that there were various conflicts of interest in the proposed transaction and that the preliminary SEC Form S-4 filed by the Company on December 14, 2015 in connection with the transaction contained material misstatements and omissions, in violation of Section 14(a) of the Securities Exchange Act of 1934 (the "Exchange Act”) and SEC Rule 14a-9 promulgated thereunder (“Rule 14a-9”).  Under the amended complaints, the plaintiffs in the Walsh, Stull, and Pancake actions have brought suit against the Company, Dell, and Universal under Section 20(a) of the Exchange Act as alleged controlling persons of EMC.  The plaintiffs in the Booth action have brought suit against the Company, Dell, and Universal under Section 14(a) of the Exchange Act and Rule 14a-9.  On April 26, 2016, the Court consolidated the actions and entered an order appointing Plaintiff Stull as lead plaintiff and his choice of counsel as lead and liaison counsel.  On June 6, 2016, the Securities and Exchange Commission declared effective the Company’s registration statement on Form S-4 relating to the EMC merger (the “SEC Form S-4”), including the amendments thereto.   On June 17, 2016, the parties to the Walsh, Stull, Pancake, and Booth actions submitted to the Court a Stipulation and Proposed Order Dismissing Action and Retaining Jurisdiction to Determine Plaintiffs’ Counsel’s Application for an Award of Attorneys’ Fees and Reimbursement of Expenses.  In the stipulation, the plaintiffs represented to the Court that they believe sufficient information had been disclosed to warrant dismissal of the actions as moot in light of the disclosures in the SEC Form S-4, including the amendments thereto.  The Court has not yet entered the proposed order.

- added (2016-12-09):
[0001571996-16-000021:note_history:11]
The amended complaints in the Jacobs and Ford actions allege that EMC, as the majority stockholder of VMware, Inc. ("VMware"), and the individual defendants, who are directors of EMC, VMware, or both, breached their fiduciary duties to minority stockholders of VMware in connection with the proposed EMC merger by allegedly entering into or approving a merger that favors the interests of EMC and Dell at the expense of the minority stockholders. Under the amended complaint, the plaintiffs in the Jacobs action also brought suit against the Company, Dell, and Universal as alleged aiders and abettors.  Effective December 2, 2016, the parties entered into an agreement to resolve the Jacobs action, pursuant to which the plaintiff has voluntarily dismissed the action with prejudice.  Under the amended complaint, the plaintiffs in the Ford action have also brought suit against the Company and Dell for alleged breach of fiduciary duties to VMware and its stockholders, and against the Company, Dell, and Universal for aiding and abetting the alleged breach of fiduciary duties by EMC and VMware’s directors.  On November 17, 2015, the plaintiffs in the Ford action moved for a preliminary injunction and for expedited discovery.  Certain defendants filed motions to dismiss the amended complaint in the Ford action on February 26, 2016 and February 29, 2016.  On June 7, 2016, the plaintiffs in the Ford action filed a second amended complaint.  Certain defendants filed motions to dismiss the second amended complaint on June 21, 2016.  A hearing on the motions is scheduled for February 3, 2017.No trial date has been set in the Ford action, and the outcome is uncertain.

- added (2016-12-09):
[0001571996-16-000021:note_history:12]
An adverse judgment for monetary damages on any of the EMC merger litigations could have an adverse effect on the Company’s operations.

- added (2016-12-09):
[0001571996-16-000021:note_history:13]
Appraisal Proceedings — Holders of shares of Dell common stock who did not vote on September 12, 2013 in favor of the proposal to adopt the amended going-private transaction agreement and who properly demanded appraisal of their shares and who otherwise comply with the requirements of Section 262 of the Delaware General Corporate Law ("DGCL") are entitled to seek appraisal for, and obtain payment in cash for the judicially determined "fair value" (as defined pursuant to Section 262 of the DGCL) of, their shares in lieu of receiving the going-private transaction consideration.  Dell initially recorded a liability of $13.75 for each share with respect to which appraisal has been demanded and as to which the demand has not been withdrawn, together with interest at the statutory rate discussed below.  As of October 28, 2016, this liability was approximately $129 million, compared to approximately $593 million as of January 29, 2016, as the Company settled a substantial portion of the liability during the nine months ended October 28, 2016.  Also during the nine months ended October 28, 2016, as discussed further below, the Court of Chancery ruled that that the fair value of the appraisal shares as of October 29, 2013, the date on which the going-private transaction became effective, was $17.62 per share.  On November 21, 2016, the Chancery Court entered final judgment in the appraisal action.  On November 22, 2016, Dell filed a notice of appeal to the Delaware Supreme Court.  That appeal is pending.  The Company believes it was adequately reserved for the appraisal proceedings as of October 28, 2016.

- changed (2016-12-09):
[0001571996-16-000021:note_history:14]
The Court of Chancery ruled on May 31, 2016, that the fair value of shares as of October 29, 2013, the date on which the going-private transaction became effective, was $17.62 per share.  This ruling would entitle the holders of the remaining 5,505,730 shares to $17.62 per share, plus interest at a statutory rate, compounded quarterly.  On June 6, 2016, the petitioners filed a motion to amend the Court’s memorandum opinion, which was denied by the Court on June 16, 2016.  On November 21, 2016, the Chancery Court entered final judgment in the appraisal action.  On November 22, 2016, Dell filed a notice of appeal to the Delaware Supreme Court.  That appeal is pending.
  (was, 2016-09-06, similarity 0.7896):
[0001571996-16-000015:note_history:14]
The Court of Chancery ruled on May 31, 2016, that the fair value of shares as of October 29, 2013, the date on which the going-private transaction became effective, was $17.62 per share.  This ruling would entitle the holders of the remaining 5,505,730 shares to $17.62 per share, plus interest at a statutory rate, compounded quarterly.  On June 6, 2016, the petitioners filed a motion to amend the Court’s memorandum opinion, which was denied by the Court on June 16, 2016.  The Court of Chancery’s decisions are subject to review on appeal when final judgment is entered.

- changed (2016-12-09):
[0001571996-16-000021:note_history:15]
On June 29, 2016, the Company, Dell, and certain funds affiliated with T. Rowe entered into a settlement agreement to resolve a dispute regarding the fair value and interest due on approximately 31,653,905 shares held by the funds, representing the 30,730,930 shares subject to claims that were dismissed on May 11, 2016 plus an additional 922,975 shares that had been previously disqualified on other grounds.  The terms of the T. Rowe settlement, among other matters, provide that, in exchange for a release and dismissal of all asserted claims, the Company pay $13.75 per share for a total sum of approximately $463 million, including interest.  On June 29, 2016, the Court entered an order approving the settlement, which was subsequently consummated.  The remaining 5,505,730 shares not subject to the settlement agreement remain subject to the appraisal proceedings.  On November 21, 2016, the Chancery Court entered final judgment in the appraisal action.  On November 22, 2016, Dell filed a notice of appeal to the Delaware Supreme Court.  That appeal is pending.
  (was, 2016-09-06, similarity 0.8978):
[0001571996-16-000015:note_history:15]
On June 29, 2016, the Company, Dell and certain funds affiliated with T. Rowe entered into a settlement agreement to resolve a dispute regarding the fair value and interest due on approximately 31,653,905 shares held by the funds, representing the 30,730,930 shares subject to claims that were dismissed on May 11, 2016 plus an additional 922,975 shares that had been previously disqualified on other grounds.  The terms of the T. Rowe settlement, among other matters, provide that, in exchange for a release and dismissal of all asserted claims, the Company pay $13.75 per share for a total sum of approximately $463 million, including interest.  On June 29, 2016, the Court entered an order approving the settlement, which was subsequently consummated.  The remaining 5,505,730 shares not subject to the settlement agreement remain subject to the appraisal proceedings.

- changed (2016-12-09):
[0001571996-16-000021:note_history:16]
Securities Litigation — On May 22, 2014, a securities class action seeking compensatory damages was filed in the United States District Court for the Southern District of New York, captioned the City of Pontiac Employee Retirement System vs. Dell Inc. et. al. (Case No. 1:14-cv-03644).  The action names as defendants Dell Inc. and certain current and former executive officers, and alleges that Dell made false and misleading statements about Dell’s business operations and products between February 22, 2012 and May 22, 2012, which resulted in artificially inflated stock prices.  The case was transferred to the United States District Court for the Western District of Texas, where the defendants filed a motion to dismiss.  On September 16, 2016, the Court denied the motion to dismiss and the case is proceeding with discovery.  The defendants believe the claims asserted are without merit and the risk of material loss is remote.
  (was, 2016-09-06, similarity 0.8623):
[0001571996-16-000015:note_history:16]
Securities Litigation — On May 22, 2014, a securities class action seeking compensatory damages was filed in the United States District Court for the Southern District of New York, captioned the City of Pontiac Employee Retirement System vs. Dell Inc. et. al. (Case No. 1:14-cv-03644).  The action names as defendants Dell Inc. and certain current and former executive officers, and alleges that Dell made false and misleading statements about Dell’s business operations and products between February 22, 2012 and May 22, 2012, which resulted in artificially inflated stock prices.  The case was transferred to the United States District Court for the Western District of Texas, where the defendants filed a motion to dismiss.  The motion is fully briefed and a ruling is expected in 2016. The defendants believe the claims asserted are without merit and the risk of material loss is remote.

- changed (2016-12-09):
[0001571996-16-000021:note_history:17]
Other Litigation — The various legal proceedings in which Dell is involved include commercial litigation and a variety of patent suits.  In some of these cases, Dell is the sole defendant.  More often, particularly in the patent suits, Dell is one of a number of defendants in the electronics and technology industries.  Dell is actively defending a number of patent infringement suits, and several pending claims are in various stages of evaluation.  While the number of patent cases varies over time, Dell does not currently anticipate that any of these matters will have a material adverse effect on its business, financial condition, results of operations, or cash flows.
  (was, 2016-09-06, similarity 0.9874):
[0001571996-16-000015:note_history:17]
Other Litigation - The various legal proceedings in which Dell is involved include commercial litigation and a variety of patent suits.  In some of these cases, Dell is the sole defendant.  More often, particularly in the patent suits, Dell is one of a number of defendants in the electronics and technology industries.  Dell is actively defending a number of patent infringement suits, and several pending claims are in various stages of evaluation.  While the number of patent cases has grown over time, Dell does not currently anticipate that any of these matters will have a material adverse effect on its business, financial condition, results of operations, or cash flows.

- changed (2016-12-09):
[0001571996-16-000021:note_history:18]
As of October 28, 2016, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for these or other proceedings or matters has been incurred.  However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company's business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters.  Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company's business, financial condition, results of operations, or cash flows will depend on a number of variables, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.
  (was, 2016-09-06, similarity 0.9941):
[0001571996-16-000015:note_history:18]
As of July 29, 2016, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for these or other proceedings or matters has been incurred.  However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company's business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters.  Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company's business, financial condition, results of operations, or cash flows will depend on a number of variables, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.

- removed (2016-12-09):
[0001571996-16-000015:note_history:19]
EMC Merger Litigation — The Company, Dell, and Universal Acquisition Co. (“Universal”) have been named as defendants in fifteen putative class-action lawsuits brought by purported EMC shareholders and VMware stockholders challenging the proposed merger between the Company, Dell, and Universal on the one hand, and EMC on the other.  Those suits are captioned as follows: (1) IBEW Local No. 129 Benefit Fund v. Tucci, Civ. No. 1584-3130-BLS1 (Mass. Super. Ct., Suffolk Cnty. filed Oct. 15, 2015); (2) Barrett v. Tucci, Civ. No. 15-6023-A (Mass. Super. Ct, Middlesex Cnty. filed Oct. 16, 2015); (3) Graulich v. Tucci, Civ. No. 1584-3169-BLS1 (Mass. Super. Ct, Suffolk Cnty. filed Oct. 19, 2015; (4) Vassallo v. EMC Corp., Civ. No. 1584-3173-BLS1 (Mass. Super. Ct, Suffolk Cnty. filed Oct. 19, 2015); (5) City of Miami Police Relief & Pension Fund v. Tucci, Civ. No. 1584-3174-BLS1 (Mass. Super. Ct. Suffolk Cnty. filed Oct. 19, 2015); (6) Lasker v. EMC Corp., Civ. No. 1584-3214-BLS1 (Mass. Super. Ct. Suffolk Cnty. filed Oct. 23, 2015); (7) Walsh v. EMC Corp., Civ. No. 15-13654 (D. Mass. filed Oct. 27, 2015); (8) Local Union No. 373 U.A. Pension Plan v. EMC Corp., Civ. No. 1584-3253-BLS1 (Mass. Super. Ct. Suffolk Cnty. filed Oct. 28, 2015); (9) City of Lakeland Emps.’ Pension & Ret. Fund v. Tucci, Civ. No. 1584-3269-BLS1 (Mass. Super. Ct. Suffolk Cnty. filed Oct. 28, 2015); (10) Ma v. Tucci, Civ. No. 1584-3281-BLS1 (Mass. Super. Ct. Suffolk Cnty. filed Oct. 29, 2015); (11) Stull v. EMC Corp., Civ. No. 15-13692 (D. Mass. filed Oct. 30, 2015); (12)  Jacobs v. EMC Corp., Civ. No. 15-6318-H (Mass. Super. Ct. Middlesex Cnty. filed Nov. 12, 2015); (13) Ford v. VMware, Inc., C.A. No. 11714-VCL (Del. Ch. filed Oct. 17, 2015); (14) Pancake v. EMC Corp., Civ. No. 16-10040 (D. Mass. filed Jan. 11, 2016); and (15) Booth Family Trust v. EMC Corp. Civ. No. 16-10114 (D. Mass. filed Jan. 26, 2016).

- removed (2016-12-09):
[0001571996-16-000015:note_history:20]
The amended complaints in the Jacobs and Ford actions allege that EMC, as the majority stockholder of VMware, and the individual defendants, who are directors of EMC, VMware, or both, breached their fiduciary duties to minority stockholders of VMware, Inc. ("VMware"), in connection with the proposed EMC merger by allegedly entering into or approving a merger that favors the interests of EMC and Dell at the expense of the minority stockholders. Under the amended complaint, the plaintiffs in the Jacobs action have brought suit against the Company, Dell, and Universal as alleged aiders and abettors.  No oral argument date has been set for the motions to dismiss/motions to stay the Jacobs action.  Under the amended complaint, the plaintiffs in the Ford action have brought suit against the Company and individual defendants for alleged breach of fiduciary duties to VMware and its stockholders, or, alternatively, against the Company, Dell, and Universal for aiding and abetting the alleged breach of fiduciary duties by EMC and VMware’s directors.  On November 17, 2015, the plaintiffs in the Ford action moved for a preliminary injunction and for expedited discovery.  Certain defendants filed motions to dismiss the amended complaint in the Ford action on February 26, 2016 and February 29, 2016.  On March 7, 2016, the defendants moved to stay or dismiss the Jacobs action in favor of the Ford action.  On April 19, 2016, EMC, the Company, Dell, Universal, and certain of the individual defendants filed briefs in support of the previously filed motions to dismiss.  The parties are still in the process of briefing the motion to dismiss.

- removed (2016-12-09):
[0001571996-16-000015:note_history:21]
No trial dates have been set in any of these actions. The outcome of these lawsuits is uncertain, and additional lawsuits may be brought or additional claims advanced concerning the EMC merger. An adverse judgment for monetary damages could have an adverse effect on the Company’s operations. A preliminary injunction could delay or jeopardize the completion of the EMC merger, and an adverse judgment granting permanent injunctive relief could indefinitely enjoin the completion of the EMC merger.

- removed (2016-12-09):
[0001571996-16-000015:note_history:22]
Appraisal Proceedings — Holders of shares of Dell common stock who did not vote on September 12, 2013 in favor of the proposal to adopt the amended going-private transaction agreement and who properly demanded appraisal of their shares and who otherwise comply with the requirements of Section 262 of the Delaware General Corporate Law ("DGCL") are entitled to seek appraisal for, and obtain payment in cash for the judicially determined "fair value" (as defined pursuant to Section 262 of the DGCL) of, their shares in lieu of receiving the going-private transaction consideration.  This appraised value could be more than, the same as, or less than the $13.75 per share going-private transaction consideration.  Dell initially recorded a liability of $13.75 for each share with respect to which appraisal has been demanded and as to which the demand has not been withdrawn, together with interest at the statutory rate discussed below.  As of July 29, 2016, this liability was approximately $129 million, compared to approximately $593 million as of January 29, 2016, as the Company settled a substantial portion of the liability during the three months ended July 29, 2016.  Also during the three months ended July 29, 2016, as discussed further below, the Court of Chancery ruled that that the fair value of the appraisal shares as of October 29, 2013, the date on which the going-private transaction became effective, was $17.62 per share.  The Company expects to appeal this ruling.  The Company believes it was adequately reserved for the appraisal proceedings as of July 29, 2016.


## dvmt:BasisOfPresentationMergersAcquisitionsAndDispositionsDisclosuresAndNewAccountingPronouncementsTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2016-12-09):
[0001571996-16-000021:note_history:23]
EMC MERGER TRANSACTION, OTHER TRANSACTIONS AND BASIS OF PRESENTATION
  (was, 2016-09-06, similarity 0.8462):
[0001571996-16-000015:note_history:23]
EMC MERGER TRANSACTION, DIVESTITURES AND BASIS OF PRESENTATION

- added (2016-12-09):
[0001571996-16-000021:note_history:24]
EMC Merger Transaction — On September 7, 2016, EMC Corporation, a Massachusetts corporation (“EMC”), became a wholly-owned subsidiary of Dell Technologies Inc. ("the Company") as a result of the merger of Universal Acquisition Co., a Delaware corporation and wholly-owned subsidiary of the Company (“Merger Sub”), with and into EMC, with EMC surviving as a wholly-owned subsidiary of the Company (the “EMC merger transaction”). The EMC merger transaction was effected pursuant to the Agreement and Plan of Merger, dated as of October 12, 2015, by and among the Company, Dell Inc., a Delaware corporation (“Dell”), Merger Sub, and EMC, as amended by the First Amendment to Agreement and Plan of Merger, dated as of May 16, 2016, by and among the Company, Dell, Merger Sub, and EMC.  See Note 3 of the Notes to the Unaudited Condensed Consolidated Financial Statements for additional information on the EMC merger transaction.

- added (2016-12-09):
[0001571996-16-000021:note_history:25]
Divestitures — On March 27, 2016, Dell entered into a definitive agreement with NTT Data International L.L.C. to divest substantially all of Dell Services for cash consideration of approximately $3.0 billion.  On June 19, 2016, Dell entered into a definitive agreement with Francisco Partners and Elliot Management Corporation to divest substantially all of Dell Software Group ("DSG") for cash consideration of approximately $2.4 billion.  On September 12, 2016, EMC entered into a definitive agreement with OpenText Corporation to divest the Dell EMC Enterprise Content Division ("ECD") for cash consideration of approximately $1.6 billion.  In accordance with applicable accounting guidance, the results of Dell Services, DSG, and ECD are presented as discontinued operations in the Condensed Consolidated Statements of Income (Loss) and, as such, have been excluded from both continuing operations and segment results for all periods presented.  Further, the Company has reclassified the related assets and liabilities as held for sale in the accompanying Condensed Consolidated Statements of Financial Position.  See Note 4 of the Notes to the Unaudited Condensed Consolidated Financial Statements for additional information.

- changed (2016-12-09):
[0001571996-16-000021:note_history:26]
SecureWorks Initial Public Offering — On April 27, 2016, SecureWorks Corp. (“SecureWorks”) completed a registered underwritten initial public offering ("IPO") of its Class A common stock.  As of October 28, 2016, the Company held approximately 87.5% of the outstanding equity interest in SecureWorks.  The results of the SecureWorks operations are included in other businesses.  See Note 15 and Note 20 of the Notes to the Unaudited Condensed Consolidated Financial Statements for more information.
  (was, 2016-09-06, similarity 0.6917):
[0001571996-16-000015:note_history:26]
SecureWorks Initial Public Offering — On April 27, 2016, SecureWorks Corp. (“SecureWorks”) completed a registered underwritten initial public offering ("IPO") of its Class A common stock.  Prior to the IPO, Dell Technologies owned indirectly, through Dell and Dell's subsidiaries, 100% of the outstanding equity interest in SecureWorks.  As of July 29, 2016, Dell Technologies held approximately 86.8% of the outstanding equity interest in SecureWorks, which represented approximately 98.5% of the combined voting power of both classes of the SecureWorks common stock outstanding.  The results of the SecureWorks operations are recorded in Corporate.  See Note 12 and Note 15 of the Notes to the Unaudited Condensed Consolidated Financial Statements for more information.

- added (2016-12-09):
[0001571996-16-000021:note_history:27]
Going-Private Transaction — On October 29, 2013, Dell was acquired by Denali Holding Inc. (which changed its name to Dell Technologies Inc. on August 25, 2016) in a merger transaction pursuant to an agreement and plan of merger, dated as of February 5, 2013, as amended. Dell Technologies is a Delaware corporation owned by Michael S. Dell and a separate property trust for the benefit of Mr. Dell’s wife (the "MD Stockholders"), investment funds affiliated with Silver Lake Partners (the "SLP Stockholders"), investment funds affiliated with MSD Partners, L.P. (the "MSDC Stockholders"), members of Dell’s management, and other investors. Mr. Dell serves as Chairman and Chief Executive Officer of Dell Technologies and Dell.

- added (2016-12-09):
[0001571996-16-000021:note_history:28]
Basis of Presentation — The accompanying Condensed Consolidated Financial Statements have been prepared in accordance with accounting principles generally accepted in the United States of America ("GAAP").  In the opinion of management, the accompanying Condensed Consolidated Financial Statements reflect all adjustments of a normal recurring nature considered necessary to fairly state the financial position of Dell Technologies Inc. (individually and together with its consolidated subsidiaries, "the Company" or "Dell Technologies") as of October 28, 2016 and January 29, 2016, the results of its operations and corresponding comprehensive income (loss) for the three and nine months ended October 28, 2016 and October 30, 2015, and its cash flows for the nine months ended October 28, 2016 and October 30, 2015.  The accompanying Unaudited Condensed Consolidated Financial Statements should be read in conjunction with the Audited Consolidated Financial Statements and accompanying Notes for the fiscal year ended January 29, 2016 ("Fiscal 2016") included in the proxy statement/prospectus dated June 6, 2016 forming part of the Company’s registration statement on Form S-4 (Registration No. 333 208524).

- added (2016-12-09):
[0001571996-16-000021:note_history:29]
As a result of the EMC merger transaction completed on September 7, 2016, the Company's results for the fiscal periods reflected in the accompanying Unaudited Condensed Consolidated Financial Statements are not directly comparable.  The results of the businesses acquired in the EMC merger transaction (the "acquired businesses") are included in the consolidated results of Dell Technologies for the three and nine months ended October 28, 2016, and represent the results of the acquired businesses from September 7, 2016, the date of the EMC merger transaction, through October 28, 2016, the end of the third fiscal quarter of Dell Technologies. The results of the acquired businesses will be reported on the basis of Dell Technologies' fiscal year end to align with the fiscal periods for which Dell Technologies reports its results.

- added (2016-12-09):
[0001571996-16-000021:note_history:30]
The standalone results of VMware, Inc. ("VMware") will continue to be publicly reported on a calendar year end basis through the end of December 31, 2016, after which VMware will effect a change in its year end, and will be publicly reported on the basis of Dell Technologies' fiscal year end beginning February 4, 2017, to align with the fiscal periods for which Dell Technologies reports its results.

- added (2016-12-09):
[0001571996-16-000021:note_history:31]
The Dell Technologies balance sheet reflects the full consolidation of EMC's assets and liabilities as a result of the close of the EMC merger transaction on September 7, 2016.  The Company’s purchase accounting remains preliminary as contemplated by GAAP and, as a result, there may be upon further review future changes to the value and allocation of the acquired assets, liabilities assumed, associated amortization expense, and goodwill.  These changes may be material.

- changed (2016-12-09):
[0001571996-16-000021:note_history:32]
affect the amounts reported in the Company's Condensed Consolidated Financial Statements and the accompanying Notes.  Actual results could differ materially from those estimates.  The results of operations, comprehensive income (loss), and cash flows for the three and nine months ended October 28, 2016 and October 30, 2015 are not necessarily indicative of the results to be expected for the full fiscal year or for any other fiscal period.
  (was, 2016-09-06, similarity 0.7855):
[0001571996-16-000015:note_history:32]
affect the amounts reported in the Company's Condensed Consolidated Financial Statements and the accompanying Notes.  Actual results could differ materially from those estimates.  The results of operations, comprehensive income (loss), and cash flows for the three and six months ended July 29, 2016 and July 31, 2015 are not necessarily indicative of the results to be expected for the full fiscal year or for any other fiscal period.

- removed (2016-12-09):
[0001571996-16-000015:note_history:33]
EMC Merger Transaction — On October 12, 2015, Dell Technologies Inc. (formerly Denali Holding Inc., referred to as Parent or Dell Technologies) entered into an agreement and plan of merger (the “EMC merger agreement”) with EMC Corporation (“EMC”), Dell Inc. (“Dell”) and Universal Acquisition Co., a direct wholly-owned subsidiary of Parent (“EMC Merger Sub”).  Pursuant to the EMC merger agreement, EMC Merger Sub will merge with and into EMC (“the EMC merger”), with EMC continuing as the surviving corporation and a wholly-owned subsidiary of Parent.

- removed (2016-12-09):
[0001571996-16-000015:note_history:34]
Upon the closing of the EMC merger, each share of EMC common stock, par value $0.01 per share (“EMC common stock”) owned immediately prior to the effective time of the EMC merger (other than shares owned by Parent, EMC Merger Sub, EMC or any of its wholly-owned subsidiaries, and other than shares with respect to which EMC’s shareholders are entitled to and properly exercise appraisal rights) automatically will be converted into the right to receive the merger consideration, consisting of (1) $24.05 in cash, without interest, and (2) a number of shares of validly issued, fully paid and non-assessable Class V common stock of Parent (the “Class V Common Stock”) equal to the quotient (rounded to the nearest five decimal points) obtained by dividing (A) 222,966,450 by (B) the aggregate number of shares of EMC common stock issued and outstanding immediately prior to the effective time of the EMC merger, plus cash in lieu of any fractional shares. No fractional shares of Class V Common Stock will be issued in the EMC merger. The approximately 223 million shares of Class V Common Stock issuable in the EMC merger (assuming EMC shareholders are not entitled to or do not properly exercise appraisal rights) are intended to track and reflect the economic performance of approximately 65% of EMC’s current economic interest in the business of VMware, Inc. (“VMware”), which currently consists of approximately 343 million shares of VMware common stock. Based on the number of shares of EMC common stock Parent currently expects will be issued and outstanding immediately prior to the completion of the EMC merger, it is estimated that EMC shareholders will receive in the EMC merger approximately 0.111 shares of Class V Common Stock for each share of EMC common stock.

- removed (2016-12-09):
[0001571996-16-000015:note_history:35]
The EMC merger will be financed with a combination of equity and debt financing and cash on hand.  As of September 6, 2016, Parent has obtained committed equity financing for up to $4.4 billion in the aggregate from Michael S. Dell, Chairman, Chief Executive Officer and founder of Dell, a separate property trust for the benefit of Mr. Dell's wife, MSDC Denali Investors, L.P. and MSDC Denali EIV, LLC (the “MSD Partners Funds”), funds affiliated with Silver Lake Partners, and an affiliate of Temasek Holdings (Private) Limited.  Parent also has obtained debt financing commitments for up to $26.3 billion in the aggregate from financial institutions for the purpose of financing the EMC merger and refinancing certain existing indebtedness of Parent and EMC. The obligations of the lenders under Parent’s debt financing commitments are subject to a number of customary conditions.  During the three months ended July 29, 2016, subsidiaries of Parent issued a total of $20.0 billion of First Lien Notes and $3.25 billion of Senior Unsecured Notes, the proceeds of which will be applied to finance the EMC merger upon closing.  Parent’s debt financing commitments will terminate upon the earlier of the termination of the EMC merger agreement in accordance with its terms or December 16, 2016.  In addition, each of Parent and EMC has agreed to make available a certain amount of cash on hand (at least $2.95 billion, in the case of Parent, and $4.75 billion, in the case of EMC) at the completion of the EMC merger for the purpose of financing the transactions contemplated by the EMC merger agreement.

- removed (2016-12-09):
[0001571996-16-000015:note_history:36]
The completion of the EMC merger is subject to specified conditions, including (a) approval by EMC’s shareholders, which was obtained at a special meeting held on July 19, 2016, (b) the absence of an order or law prohibiting consummation of the transactions contemplated by the EMC merger agreement, (c) the effectiveness of the registration statement of Parent registering the shares of Class V Common Stock issuable in connection with the EMC merger and (d) the expiration or termination of the waiting period under the Hart-Scott-Rodino Antitrust Improvements Act of 1976, as amended, and the receipt of certain foreign antitrust approvals.  In addition, each party’s obligation to consummate the EMC merger is subject to other conditions, including (1) the accuracy of the other party’s representations and warranties (including the absence of a material adverse effect), (2) the other party’s compliance with its obligations, (3) receipt by each party of an opinion of counsel, dated as of the date of the EMC merger, as to certain tax matters and (4) the listing of the Class V Common Stock on the New York Stock Exchange or the Nasdaq Stock Market.  Parent has applied to list the Class V Common Stock on the New York Stock Exchange.

- removed (2016-12-09):
[0001571996-16-000015:note_history:37]
The EMC merger agreement contains specified termination rights for both Parent and EMC, including that either party may terminate the EMC merger agreement if the EMC merger is not consummated by December 16, 2016, if any governmental authority has adopted any law or regulation prohibiting or rendering the consummation of the EMC merger permanently illegal, or if any governmental authority has issued an order, decree or ruling or taken any other action permanently restraining, enjoining or otherwise prohibiting the EMC merger, and such order, decree or ruling has become final and nonappealable. If the EMC merger agreement is terminated under certain specified circumstances, including in connection with EMC’s entry into a definitive agreement for a superior proposal, EMC must pay Parent a termination fee of $2.5 billion. Further, if the EMC merger agreement is terminated under specified circumstances and, within 12 months after the termination, EMC enters into a definitive agreement providing for, or consummates, an acquisition proposal, EMC will be obligated to pay Parent a termination fee of $2.5 billion. The EMC merger agreement also provides that Parent and Dell will be obligated to pay EMC a reverse termination fee of $4 billion under specified circumstances and, in certain instances, an alternative reverse termination fee of $6 billion.

- removed (2016-12-09):
[0001571996-16-000015:note_history:38]
Other than the recognition of certain expenses related to the EMC merger and interest expense associated with the issuance of the First Lien Notes and the Senior Unsecured Notes referred to above, the proceeds of which are held in escrow, there was no impact of the EMC merger on the accompanying Unaudited Condensed Consolidated Financial Statements.  See Note 5 of the Notes to the Unaudited Condensed Consolidated Financial Statements for additional information.

- removed (2016-12-09):
[0001571996-16-000015:note_history:39]
Divestitures — On March 27, 2016, Dell entered into a definitive agreement with NTT Data International L.L.C. to divest substantially all of Dell Services for cash consideration of approximately $3.1 billion.  On June 19, 2016, Dell entered into a definitive agreement with Francisco Partners and Elliot Management Corporation to divest substantially all of Dell Software Group ("DSG") for cash consideration of approximately $2.4 billion.  In accordance with applicable accounting guidance, the results of Dell Services and DSG are presented as discontinued operations in the Condensed Consolidated Statements of Income (Loss) and, as such, have been excluded from both continuing operations and segment results for all periods presented.  Further, the Company has reclassified the related assets and liabilities as held for sale in the accompanying Condensed Consolidated Statements of Financial Position.  See Note 2 of the Notes to the Unaudited Condensed Consolidated Financial Statements for additional information.

- removed (2016-12-09):
[0001571996-16-000015:note_history:40]
Going-Private Transaction — On October 29, 2013, Dell was acquired by Dell Technologies in a merger transaction pursuant to an agreement and plan of merger, dated as of February 5, 2013, as amended. Dell Technologies is a Delaware corporation owned by Michael S. Dell and a separate property trust for the benefit of Mr. Dell’s wife, investment funds affiliated with Silver Lake Partners, the MSD Partners Funds, and certain members of Dell’s management and other investors. Mr. Dell serves as Chairman and Chief Executive Officer of Dell Technologies and Dell.

- removed (2016-12-09):
[0001571996-16-000015:note_history:41]
Basis of Presentation — The accompanying Condensed Consolidated Financial Statements have been prepared in accordance with accounting principles generally accepted in the United States of America ("GAAP").  In the opinion of management, the accompanying Condensed Consolidated Financial Statements reflect all adjustments of a normal recurring nature considered necessary to fairly state the financial position of Dell Technologies Inc. (individually and together with its consolidated subsidiaries, "the Company") as of July 29, 2016 and January 29, 2016, the results of its operations and corresponding comprehensive income (loss) for the three and six months ended July 29, 2016 and July 31, 2015, and its cash flows for the six months ended July 29, 2016 and July 31, 2015.  The accompanying Unaudited Condensed Consolidated Financial Statements should be read in conjunction with the Audited Consolidated Financial Statements and accompanying Notes for the fiscal year ended January 29, 2016 ("Fiscal 2016") included in the proxy statement/prospectus dated June 6, 2016 forming part of the Company’s registration statement on Form S-4 (Registration No. 333 208524).

- removed (2016-12-09):
[0001571996-16-000015:note_history:42]
Recently Issued Accounting Pronouncements

- removed (2016-12-09):
[0001571996-16-000015:note_history:43]
Revenue from Contracts with Customers — In May 2014, the Financial Accounting Standards Board ("FASB") issued amended guidance on the recognition of revenue from contracts with customers.  The objective of the new standard is to establish a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and will supersede most of the existing revenue recognition guidance, including industry-specific guidance.  The new standard requires entities to recognize revenue when it transfers promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. In August 2015, the FASB approved a one-year deferral of the effective date of this standard.  Public entities are required to adopt the new standard for fiscal years, and interim periods within those years, beginning after December 15, 2017, with the option of applying the standard as early as the original effective date for public entities.  The new revenue standard may be applied retrospectively to each prior period presented or retrospectively with the cumulative effect recognized as of the date of adoption.  The Company is currently evaluating the impact of the new guidance, the effective date, and the method of adoption.

- removed (2016-12-09):
[0001571996-16-000015:note_history:44]
Presentation of Debt Issuance Costs — In April 2015, the FASB issued amended guidance which changes the classification of debt issuance costs in the Consolidated Statements of Financial Position.  The new guidance requires debt issuance costs to be presented as a direct deduction from the carrying amount of the related debt liability consistent with the presentation of debt discounts, rather than as an asset as currently presented.  The guidance related to recognition and measurement of debt issuance costs remains unchanged.  The Company implemented the new presentation in the six months ended July 29, 2016 on a retrospective basis, and except for the reclassification of debt issuance costs of $128 million as of January 29, 2016 in the accompanying Condensed Consolidated Statements of Financial Position, there was no other impact to the Consolidated Financial Statements.

- removed (2016-12-09):
[0001571996-16-000015:note_history:45]
Recognition and Measurement of Financial Assets and Financial Liabilities — In January 2016, the FASB issued amended guidance on Recognition and Measurement of Financial Assets and Financial Liabilities.  The standard addresses certain aspects of recognition, measurement, presentation, and disclosure of financial instruments.  Public entities must adopt the new guidance for fiscal years, and interim periods within those years, beginning after December 15, 2017.  The Company is currently evaluating the impact that the standard will have on the Consolidated Financial Statements.

- removed (2016-12-09):
[0001571996-16-000015:note_history:46]
Leases — In February 2016, the FASB issued amended guidance on the accounting for leasing transactions.  The primary objective of this update is to increase transparency and comparability among organizations by recognizing lease assets and lease liabilities on the balance sheet and disclosing key information about leasing arrangements.  Public entities must adopt the new guidance for reporting periods beginning after December 15, 2018, with early adoption permitted.  Companies are required to use a modified retrospective approach for leases that exist or are entered into after the beginning of the earliest comparative period in the financial statements.  The Company is currently evaluating the impact that the standard will have on the Consolidated Financial Statements.

- removed (2016-12-09):
[0001571996-16-000015:note_history:47]
Improvements to Employee Share-Based Payment Accounting — In March 2016, the FASB issued amended guidance on the accounting for employee share-based payments.  The topics that were amended in the update involve several aspects of the accounting for share-based payment transactions, including the income tax consequences, classification of awards as either equity or liabilities, and classification on the statement of cash flows.  Public entities must adopt the new guidance for fiscal years, and interim periods within those years, beginning after December 2016.  The Company is currently evaluating the impact that the standard will have on the Consolidated Financial Statements.

- removed (2016-12-09):
[0001571996-16-000015:note_history:48]
Measurement of Credit Losses on Financial Instruments — In June 2016, the FASB issued amended guidance which replaces the current incurred loss impairment methodology with a methodology that reflects expected credit losses and requires consideration of a broader range of reasonable and supportable information to inform credit loss estimates.  Public entities must adopt the new guidance for fiscal years beginning after December 15, 2019, including interim periods within those fiscal years. All entities may adopt the amendments in the new standard as of fiscal years beginning after December 15, 2018, including interim periods within those fiscal years.  However, earlier adoption is not permitted.  The Company is currently evaluating the impact that the standard will have on the Consolidated Financial Statements.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: no_prior_note, score: 0.0

- added (2016-12-09):
[0001571996-16-000021:note_history:49]
— INTERIM UPDATE TO SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES

- added (2016-12-09):
[0001571996-16-000021:note_history:50]
The following interim update to the Company's significant accounting policies reflects the changes as a result of the EMC merger transaction.

- added (2016-12-09):
[0001571996-16-000021:note_history:51]
Principles of Consolidation — These consolidated financial statements include the accounts of Dell Technologies and its wholly-owned subsidiaries, as well as the accounts of SecureWorks, VMware, and Pivotal Software Inc. ("Pivotal"), companies which are majority-owned by Dell Technologies.  All intercompany transactions have been eliminated.

- added (2016-12-09):
[0001571996-16-000021:note_history:52]
On April 27, 2016, SecureWorks completed a registered underwritten IPO of its Class A common stock.  As of October 28, 2016, Dell Technologies held approximately 87.5% of the outstanding equity interest in SecureWorks.  Since the date of the IPO, the financial results of SecureWorks remain consolidated with those of Dell Technologies as Dell Technologies is the controlling stockholder of SecureWorks.  The portion of the results of operations of SecureWorks allocable to its other owners is shown as net income attributable to the non-controlling interests in the Condensed Consolidated Statements of Income (Loss), as an adjustment to net income attributable to Dell Technologies stockholders.  Additionally, the cumulative portion of the results of operations of SecureWorks allocable to its other owners, along with the interest in the net assets of SecureWorks attributable to those other owners, is shown as a component of non-controlling interests in the Condensed Consolidated Statements of Financial Position.

- added (2016-12-09):
[0001571996-16-000021:note_history:53]
As of October 28, 2016, Dell Technologies held approximately 83.3% of the outstanding equity interest in VMware. VMware’s financial results have been consolidated with those of Dell Technologies as Dell Technologies is VMware’s controlling stockholder.  The results of VMware presented in the accompanying Condensed Consolidated Financial Statements represent the results of the acquired businesses from September 7, 2016, the date of the EMC merger transaction, through October 28, 2016, the end of the third fiscal quarter of Dell Technologies.  The portion of the results of operations of VMware allocable to its other owners is shown as net income attributable to the non-controlling interests in the Condensed Consolidated Statements of Income (Loss) as an adjustment to net income attributable to Dell Technologies stockholders.  Additionally, the cumulative portion of the results of operations of VMware allocable to its other owners, along with the interest in the net assets of VMware attributable to those other owners, is shown as a component of non-controlling interests in the Condensed Consolidated Statements of Financial Position as of October 28, 2016.

- added (2016-12-09):
[0001571996-16-000021:note_history:54]
As of October 28, 2016, Dell Technologies held approximately 77.4% of the outstanding equity interest in Pivotal.  Pivotal’s financial results have been consolidated with those of Dell Technologies as Dell Technologies is Pivotal’s controlling stockholder.  The results of Pivotal presented in the accompanying Condensed Consolidated Financial Statements represent the results of the acquired businesses from September 7, 2016, the date of the EMC merger transaction, through October 28, 2016, the end of the third fiscal quarter of Dell Technologies.  A portion of the non-controlling interest in Pivotal is held by third parties in the form of a preferred equity instrument.  Accordingly, there is no net income attributable to this non-controlling interest in the Condensed Consolidated Statements of Income (Loss). The portion of the results of operations of Pivotal allocable to its other owners, whose interests are held in the form of common stock, and the interest in the net assets of Pivotal attributable to those other owners are shown as net income attributable to the non-controlling interest in the Condensed Consolidated Statements of Income (Loss) as an adjustment to net income attributable to Dell Technologies stockholders, and as component of non-controlling interests in the Condensed Consolidated Statements of Financial Position as of October 28, 2016, respectively.

- added (2016-12-09):
[0001571996-16-000021:note_history:55]
Investments — All debt security investments with remaining maturities in excess of one year and substantially all equity and other securities are recorded as long-term investments in the Condensed Consolidated Statements of Financial Position. In comparison, debt security instruments with a remaining maturity shorter than one year are classified as short-term investments in the Condensed Consolidated Statements of Financial Position.

- added (2016-12-09):
[0001571996-16-000021:note_history:56]
Unrealized gains and temporary loss positions on investments classified as available-for-sale are included within accumulated other comprehensive income (loss), net of any related tax effect.  Upon realization, those amounts are reclassified from accumulated other comprehensive income (loss) to interest and other, net.  Realized gains and losses and other-than-temporary impairments are reflected in the consolidated income statement in interest and other, net.  Investments accounted for under the cost method are measured at fair value initially.  Subsequently, when there is an indicator of impairment, the impairment is recognized.

- added (2016-12-09):
[0001571996-16-000021:note_history:57]
Revenue Recognition — Net revenue primarily includes sales of hardware, services, software licenses, and peripherals.  The Company recognizes revenue for these products and services when it is realized or realizable and earned.  Revenue is recognized when persuasive evidence of an arrangement exists; delivery has occurred or services have been rendered; the Company's fee to its customer is fixed or determinable; and collection of the resulting receivable is reasonably assured.  This policy is applicable to all sales, including sales to resellers and end-users.

- added (2016-12-09):
[0001571996-16-000021:note_history:58]
Revenue from third-party software sales and extended warranties for third-party products, for which the Company does not meet the criteria for gross revenue recognition, is recognized on a net basis.  All other revenue is recognized on a gross basis.

- added (2016-12-09):
[0001571996-16-000021:note_history:59]
Services revenue and cost of services revenue captions in the Consolidated Statements of Income (Loss) include the Company's services, third-party software revenue, and support services related to the Company-owned software offerings.

- added (2016-12-09):
[0001571996-16-000021:note_history:60]
The following summarizes the major terms of contractual relationships with customers and the manner in which the Company accounts for sales transactions.

- added (2016-12-09):
[0001571996-16-000021:note_history:61]
Products

- added (2016-12-09):
[0001571996-16-000021:note_history:62]
Product revenue consists of computer hardware, enterprise hardware, and software licenses sales that are delivered, sold as a subscription or sold on a consumption basis. Computer hardware and enterprise hardware include notebooks and desktop PCs, servers, storage hardware, and other hardware-related devices.  Software license sales include optional, stand-alone software applications. Software applications provide customers with resource management, backup and archiving, information security, information management and intelligence, data analytics and server virtualization capabilities.  Revenue from the sale of hardware products and systems is recognized when title and risk of loss pass to the customer.  Delivery is considered complete when products have been shipped to the Company's customer, title and risk of loss have transferred to the customer, and customer acceptance has been satisfied.  Customer acceptance is satisfied if acceptance is obtained from the customer, if all acceptance provisions lapse, or if the Company has evidence that all acceptance provisions have been satisfied.  Depending on the nature of the arrangement, software license sales is generally recognized upon shipment or electronic delivery.  For certain arrangements, revenue is recognized based on usage or ratably over the term of the arrangement.  License revenue from royalty arrangements is recognized upon either receipt of royalty reports or payments from third parties.

- added (2016-12-09):
[0001571996-16-000021:note_history:63]
The Company records reductions to revenue for estimated customer sales returns, rebates, and certain other customer incentive programs.  These reductions to revenue are made based upon reasonable and reliable estimates that are determined by historical experience, contractual terms, and current conditions.  The primary factors affecting the Company's accrual for estimated customer returns include estimated return rates as well as the number of units shipped that have a right of return that has not expired as of the balance sheet date.  If returns cannot be reliably estimated, revenue is not recognized until a reliable estimate can be made or the return right lapses.

- added (2016-12-09):
[0001571996-16-000021:note_history:64]
The Company sells its products directly to customers as well as through other distribution channels, such as retailers, distributors, and resellers.  The Company recognizes revenue on these sales when the reseller has economic substance apart from the Company; any credit risk has been identified and quantified; title and risk of loss have passed to the sales channel; the fee paid to the Company is not contingent upon resale or payment by the end user; and the Company has no further obligations related to bringing about resale or delivery.

- added (2016-12-09):
[0001571996-16-000021:note_history:65]
Sales through the Company's distribution channels are primarily made under agreements allowing for limited rights of return, price protection, rebates, and marketing development funds.  The Company has generally limited return rights through contractual caps or has an established selling history for these arrangements.  Therefore, there is sufficient data to establish reasonable and reliable estimates of returns for the majority of these sales.  To the extent price protection or return rights are not limited and a reliable estimate cannot be made, all of the revenue and related costs are deferred until the product has been sold to the end-user or the rights expire.  The Company records estimated reductions to revenue or an expense for distribution channel programs at the later of the offer or the time revenue is recognized.

- added (2016-12-09):
[0001571996-16-000021:note_history:66]
The Company defers the cost of shipped products awaiting revenue recognition until revenue is recognized.

- added (2016-12-09):
[0001571996-16-000021:note_history:67]
Services

- added (2016-12-09):
[0001571996-16-000021:note_history:68]
Services revenue consists of hardware and software maintenance, installation services, professional services, training revenue, third-party software revenue, and software sold as a service.  The Company recognizes revenue from fixed-price support or maintenance contracts sold for both hardware and software ratably over the contract period and recognizes the costs associated with these contracts as incurred.  For sales of extended warranties with a separate contract price, the Company defers revenue equal to the separately stated price.  Revenue associated with undelivered elements is deferred and recorded when delivery occurs or services are provided. Revenue from extended warranty and service contracts, for which the Company is obligated to perform, is recorded as deferred revenue and subsequently recognized over the term of the contract on a straight-line basis or when the service is completed and the costs associated with these contracts are recognized as incurred.

- added (2016-12-09):
[0001571996-16-000021:note_history:69]
Multiple Deliverables

- added (2016-12-09):
[0001571996-16-000021:note_history:70]
When an arrangement has more than one element, such as hardware, software, and services contained in a single arrangement, the Company first allocates revenue based upon the relative selling price into two categories: (1) non-software components, such as hardware and any hardware-related items, such as required system software that functions with the hardware to deliver the essential functionality of the hardware and related post-contract customer support, software as a service subscriptions and other services; and (2) software components, such as optional software applications and related items, such as post-contract customer support and other services. The Company then allocates revenue within the non-software category to each element based upon its relative selling price using a hierarchy of vendor-specific objective evidence (“VSOE”), third-party evidence of selling price (“TPE”), or estimated selling prices (“ESP”), if VSOE or TPE does not exist. The Company allocates revenue within the software category to the undelivered elements based upon their fair value using VSOE, with the residual revenue allocated to the delivered elements. If the Company cannot objectively determine the VSOE of the fair value of any undelivered software element, it defers revenue for all software components until all elements are delivered and services have been performed, until fair value can objectively be determined for any remaining undelivered elements, or until software maintenance is the only undelivered element, in which case revenue is recognized over the maintenance term for all software elements.

- added (2016-12-09):
[0001571996-16-000021:note_history:71]
The Company allocates the amount of revenue recognized for delivered elements to the amount that is not subject to forfeiture or refund or contingent on the future delivery of products or services.

- added (2016-12-09):
[0001571996-16-000021:note_history:72]
Customers under software maintenance agreements are entitled to receive updates and upgrades on a when-and-if-available basis, and various types of technical support based on the level of support purchased. In the event specific features, functionality, entitlements, or the release version of an upgrade or new product have been announced but not delivered, and customers will receive that upgrade or new product as part of a current software maintenance contract, a specified upgrade is deemed created and product revenues are deferred on purchases made after the announcement date until delivery of the upgrade or new product. The amount and elements to be deferred are dependent on whether the Company has established VSOE of fair value for the upgrade or new product.

- added (2016-12-09):
[0001571996-16-000021:note_history:73]
Other

- added (2016-12-09):
[0001571996-16-000021:note_history:74]
The Company records revenue from the sale of equipment under sales-type leases as product revenue in an amount equal to the present value of minimum lease payments at the inception of the lease.  Sales-type leases also produce financing income, which is included in net revenue in the Condensed Consolidated Statements of Income (Loss) and is recognized at consistent rates of return over the lease term.  Revenue from operating leases is recognized over the lease period. The Company also offers qualified customers revolving credit lines for the purchase of products and services offered by the Company.  Financing income attributable to these revolving loans is recognized in net revenue on an accrual basis.

- added (2016-12-09):
[0001571996-16-000021:note_history:75]
The Company accrues for the estimated costs of systems’ warranty at the time of sale.  Systems’ warranty costs are estimated based upon historical experience and specific identification of systems’ requirements.

- added (2016-12-09):
[0001571996-16-000021:note_history:76]
The Company reports revenue net of any revenue-based taxes assessed by governmental authorities that are imposed on and concurrent with specific revenue-producing transactions.

- added (2016-12-09):
[0001571996-16-000021:note_history:77]
Deferred Revenue — Deferred revenue represents amounts received in advance for extended warranty services, deferred hardware, software maintenance, prepaid professional services, and unearned license fees, which are recognized ratably over the contract term as either product or services revenue depending on the nature of the item.  The Company also has deferred revenue related to internally-developed software offerings, and deferred profit on third-party software offerings, which are generally recognized ratably over the contract term as either product or services revenue depending on the nature of the item.

- added (2016-12-09):
[0001571996-16-000021:note_history:78]
Research and Development — Research and development (“R&D”) costs are expensed as incurred. R&D costs include salaries and benefits and other personnel-related costs associated with product development.  Also included in R&D expenses are infrastructure costs, which consist of equipment and material costs, facilities-related costs, depreciation expense, and intangible asset amortization.

- added (2016-12-09):
[0001571996-16-000021:note_history:79]
Capitalized Software Development Costs — In accordance with the applicable accounting standards, software development costs related to the development of new product offerings are capitalized subsequent to the establishment of technological feasibility, which is demonstrated by the completion of a detailed program design or working model, if no program design is completed. GAAP requires that annual amortization expense of the capitalized software development costs be the greater of the amounts computed using the ratio of gross revenue to a product's total current and anticipated revenues, or the straight-line method over the product's remaining estimated economic life. Capitalized costs are amortized over periods ranging from eighteen months to two years which represents the product's estimated economic life.

- added (2016-12-09):
[0001571996-16-000021:note_history:80]
Amounts capitalized for the period from September 7, 2016 through October 28, 2016 were $85 million, and are included in other non-current assets, net in the accompanying Condensed Consolidated Statements of Financial Position.  Amortization expense for the period from September 7, 2016 through October 28, 2016 was $0.4 million.  Prior to the EMC merger transaction, there were no significant capitalized software development costs specific to the legacy businesses of Dell Technologies Inc.

- added (2016-12-09):
[0001571996-16-000021:note_history:81]
Recently Issued Accounting Pronouncements

- added (2016-12-09):
[0001571996-16-000021:note_history:82]
Revenue from Contracts with Customers — In May 2014, the Financial Accounting Standards Board ("FASB") issued amended guidance on the recognition of revenue from contracts with customers.  The objective of the new standard is to establish a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and will supersede most of the existing revenue recognition guidance, including industry-specific guidance.  The new standard requires entities to recognize revenue when it transfers promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services. In August 2015, the FASB approved a one-year deferral of the effective date of this standard.  Public entities are required to adopt the new standard for fiscal years, and interim periods within those years, beginning after December 15, 2017.  The new revenue standard may be applied retrospectively to each prior period presented or retrospectively with the cumulative effect recognized as of the date of adoption.  The Company is currently evaluating the method of adoption and the impact that the new standard will have on the Consolidated Financial Statements.

- added (2016-12-09):
[0001571996-16-000021:note_history:83]
Presentation of Debt Issuance Costs — In April 2015, the FASB issued amended guidance which changes the classification of debt issuance costs in the Consolidated Statements of Financial Position.  The new guidance requires debt issuance costs to be presented as a direct deduction from the carrying amount of the related debt liability consistent with the presentation of debt discounts, rather than as an asset.  The guidance related to recognition and measurement of debt issuance costs remains unchanged.  The Company implemented the new presentation in the nine months ended October 28, 2016 on a retrospective basis, and except for the reclassification of debt issuance costs of $128 million as of January 29, 2016 in the accompanying Condensed Consolidated Statements of Financial Position, there was no other impact on the Consolidated Financial Statements.

- added (2016-12-09):
[0001571996-16-000021:note_history:84]
Recognition and Measurement of Financial Assets and Financial Liabilities — In January 2016, the FASB issued amended guidance on Recognition and Measurement of Financial Assets and Financial Liabilities.  The standard addresses certain aspects of recognition, measurement, presentation, and disclosure of financial instruments.  Public entities must adopt the new guidance for fiscal years, and interim periods within those years, beginning after December 15, 2017.  The Company is currently evaluating the impact that the standard will have on the Consolidated Financial Statements.

- added (2016-12-09):
[0001571996-16-000021:note_history:85]
Leases — In February 2016, the FASB issued amended guidance on the accounting for leasing transactions.  The primary objective of this update is to increase transparency and comparability among organizations by recognizing lease assets and lease liabilities on the balance sheet and disclosing key information about leasing arrangements.  Public entities must adopt the new guidance for reporting periods beginning after December 15, 2018, with early adoption permitted.  Companies are required to use a modified retrospective approach for leases that exist or are entered into after the beginning of the earliest comparative period in the financial statements.  The Company is currently evaluating the impact that the standard will have on the Consolidated Financial Statements.

- added (2016-12-09):
[0001571996-16-000021:note_history:86]
Improvements to Employee Share-Based Payment Accounting — In March 2016, the FASB issued amended guidance on the accounting for employee share-based payments.  The topics that were amended in the update involve several aspects of the accounting for share-based payment transactions, including the income tax consequences, classification of awards as either equity or liabilities, and classification on the statement of cash flows.  Public entities must adopt the new guidance for fiscal years, and interim periods within those years, beginning after December 2016.  The Company is currently evaluating the impact that the standard will have on the Consolidated Financial Statements.

- added (2016-12-09):
[0001571996-16-000021:note_history:87]
Measurement of Credit Losses on Financial Instruments — In June 2016, the FASB issued amended guidance which replaces the current incurred loss impairment methodology with a methodology that reflects expected credit losses and requires consideration of a broader range of reasonable and supportable information to inform credit loss estimates.  Public entities must adopt the new guidance for fiscal years beginning after December 15, 2019, including interim periods within those fiscal years. All entities may adopt the amendments in the new standard as of fiscal years beginning after December 15, 2018, including interim periods within those fiscal years.  However, earlier adoption is not permitted.  The Company is currently evaluating the impact that the standard will have on the Consolidated Financial Statements.

- added (2016-12-09):
[0001571996-16-000021:note_history:88]
Classification of Certain Cash Receipts and Cash Payments — In August 2016, the FASB issued amended guidance on the presentation and classification of eight specific cash flow issues with the objective of reducing existing diversity in practice.  Public entities must adopt the new guidance for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017, with early adoption permitted.  Companies should reflect any adjustments on a retrospective basis, if practicable, otherwise adoption is required to be applied as of the earliest date practicable.  The Company is currently evaluating the timing of adoption as well as the impact that the standard will have on the Consolidated Financial Statements.

- added (2016-12-09):
[0001571996-16-000021:note_history:89]
Intra-Entity Transfers of Assets Other Than Inventory — In October 2016, the FASB issued amended guidance on the accounting for income taxes.  The new guidance requires companies to recognize the income tax effects of intra-entity asset transfers, other than transfers of inventory, when the transfer occurs instead of when the asset is sold to a third party, as current GAAP requires.  Public entities must adopt the new guidance for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017, with early adoption permitted at the beginning of an annual period.  The new guidance is required to be applied retrospectively with the cumulative effect recognized as of the beginning of the period of adoption. The Company is currently evaluating the timing of adoption as well as the impact that the standard will have on the Consolidated Financial Statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2016-12-09):
[0001571996-16-000021:note_history:90]
|  | October 28, 2016 |  | January 29, 2016 |
|  | (in millions) |
| Secured Debt |  |  |  |
| Structured financing debt | $ | 3,426 |  |  | $ | 3,411 |  |
| 3.75% Floating rate due October 2018 ("Term Loan C Facility") | — |  |  | 1,003 |  |
| 4.00% Floating rate due April 2020 ("Term Loan B Facility") | — |  |  | 4,329 |  |
| 4.00% Floating rate due April 2020 ("Term Loan Euro Facility") | — |  |  | 891 |  |
| 5.625% due October 2020 ("Senior First Lien Notes") | — |  |  | 1,400 |  |
| EMC merger transaction financing issued on September 7, 2016 ("Senior Secured Credit Facilities"): |  |  |  |
| 4.00% Term Loan B Facility due September 2023 | 5,000 |  |  | — |  |
| 2.53% Term Loan A-1 Facility due December 2018 | 3,700 |  |  | — |  |
| 2.78% Term Loan A-2 Facility due September 2021 | 3,925 |  |  | — |  |
| 2.53% Term Loan A-3 Facility due December 2018 | 1,800 |  |  | — |  |
| 2.53% Revolving Credit Facility due September 2021 | 1,475 |  |  | — |  |
| EMC merger transaction financing issued on June 1, 2016 ("First Lien Notes"): |  |  |  |
| 3.48% due June 2019 | 3,750 |  |  | — |  |
| 4.42% due June 2021 | 4,500 |  |  | — |  |
| 5.45% due June 2023 | 3,750 |  |  | — |  |
| 6.02% due June 2026 | 4,500 |  |  | — |  |
| 8.10% due June 2036 | 1,500 |  |  | — |  |
| 8.35% due June 2046 | 2,000 |  |  | — |  |
| Unsecured Notes and Debentures |  |  |  |
| Notes and debentures issued prior to going-private transaction: |  |  |  |
| 3.10% due April 2016 | — |  |  | 400 |  |
| 5.65% due April 2018 | 500 |  |  | 500 |  |
| 5.875% due June 2019 | 600 |  |  | 600 |  |
| 4.625% due April 2021 | 400 |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 265 |  |  | 265 |  |
| EMC merger transaction financing issued on June 22, 2016 ("Senior Notes"): |  |  |  |
| 5.875% due June 2021 | 1,625 |  |  | — |  |
| 7.125% due June 2024 | 1,625 |  |  | — |  |
| Existing EMC notes assumed as part of the EMC merger transaction ("EMC Notes"): |  |  |  |
| 1.875% due June 2018 | 2,500 |  |  | — |  |
| 2.650% due June 2020 | 2,000 |  |  | — |  |
| 3.375% due June 2023 | 1,000 |  |  | — |  |
| Bridge Facilities |  |  |  |
| 4.875% Asset Sale Bridge Facility due September 2017 | 2,200 |  |  | — |  |
| 2.28% Margin Bridge Facility due September 2017 | 2,500 |  |  | — |  |
| 2.28% VMware Note Bridge Facility due September 2017 | 1,500 |  |  | — |  |
| Other | 58 |  |  | 93 |  |
| Total debt, principal amount | 56,787 |  |  | 13,980 |  |

- added (2016-12-09):
[0001571996-16-000021:note_history:91]
|  | October 28, 2016 |  | January 29, 2016 |
|  | (in millions) |
| Total debt, principal amount | 56,787 |  |  | 13,980 |  |
| Unamortized discount, net of unamortized premium | (310 | ) |  | (221 | ) |
| Debt issuance costs | (805 | ) |  | (128 | ) |
| Total debt, carrying value | $ | 55,672 |  |  | $ | 13,631 |  |
| Total short-term debt | $ | 8,388 |  |  | $ | 2,981 |  |
| Total long-term debt | $ | 47,284 |  |  | $ | 10,650 |  |

- added (2016-12-09):
[0001571996-16-000021:note_history:92]
Upon the closing of the EMC merger transaction, the Company repaid and terminated the ABL Credit Facility and the Term Loan Facilities obtained in connection with the going-private transaction, and redeemed the Senior First Lien Notes issued in connection with the going-private transaction.  During the nine months ended October 28, 2016, the Company repaid $0.5 billion of the Revolving Credit Facility obtained in connection with the EMC merger transaction and $0.4 billion of maturing Unsecured Notes and Debentures.

- added (2016-12-09):
[0001571996-16-000021:note_history:93]
To finance the EMC merger transaction, the Company issued $45.9 billion in new debt, which included proceeds from the sale of the First Lien Notes and Senior Unsecured Notes in June 2016, as well as borrowings under the Senior Secured Credit Facilities (including the Revolving Credit Facility), the Asset Sale Bridge Facility, the Margin Bridge Facility, and the VMware Note Bridge Facility at the closing of the transaction.  The Company incurred approximately $245 million of other expenses related to these debt extinguishments and new borrowings.  Under the terms of the agreements relating to the issuance of the First Lien Notes and Senior Unsecured Notes, the proceeds of the offerings were deposited into escrow and included in restricted cash in the Condensed Consolidated Statements of Financial Position until the closing of the EMC merger transaction, at which time such proceeds were released to finance the transaction.  Upon the closing of the EMC merger transaction, the Company received pre-funded interest in the amount of $58 million that the Company had previously paid into escrow and which will be paid to the holders of the First Lien Notes and Senior Unsecured Notes on the scheduled interest payment dates, as well as investment income earned of approximately $14 million on that pre-funded interest.

- added (2016-12-09):
[0001571996-16-000021:note_history:94]
Senior Secured Credit Facilities — At the closing of the EMC merger transaction on September 7, 2016, the Company entered into a credit agreement (the "Senior Secured Credit Agreement") that provides for senior secured credit facilities (the “Senior Secured Credit Facilities”) in the aggregate principal amount of $17.575 billion comprising (a) term loan facilities and (b) a senior secured Revolving Credit Facility, which includes capacity for up to $0.5 billion of letters of credit and for borrowings of up to $0.4 billion under swing-line loans. Dell International L.L.C. ("Dell International") and EMC are the borrowers under the Senior Secured Credit Facilities.  As of October 28, 2016, available borrowings under the Revolving Credit Facility totaled $1.6 billion.  The Senior Secured Credit Facilities provide that the borrowers have the right at any time, subject to customary conditions, to request incremental term loans or incremental revolving commitments in an aggregate principal amount of up to (a) the greater of (i) $10.0 billion and (ii) 100% of Consolidated EBITDA (as defined in the Senior Secured Credit Agreement) plus (b) an amount equal to voluntary prepayments of the term loan facilities and the revolving credit facility, subject to certain requirements, plus (c) an additional unlimited amount subject to a pro forma net first lien leverage ratio of 3.25:1.0.

- added (2016-12-09):
[0001571996-16-000021:note_history:95]
Borrowings under the Senior Secured Credit Facilities bear interest at a rate per annum equal to an applicable margin, plus, at the borrowers’ option, either (a) a base rate, which, under the Term Loan B Facility, is subject to an interest rate floor of 1.75% per annum, and under all other borrowings is subject to an interest rate floor of 0% per annum, or (b) a London interbank offered rate ("LIBOR"), which, under the Term Loan B Facility, is subject to an interest rate floor of 0.75% per annum, and under all other borrowings is subject to an interest rate floor of 0% per annum. The applicable margin under the Term Loan B Facility is subject to reduction based on a first lien leverage ratio test. The applicable margins under the Term Loan A-1 Facility, the Term Loan A-2 Facility, the Term Loan A-3 Facility and the Revolving Credit Facility vary based upon a corporate ratings-based pricing schedule.

- added (2016-12-09):
[0001571996-16-000021:note_history:96]
The Term Loan A-1 Facility will mature on December 31, 2018 and has no amortization.  The Term Loan A-2 Facility will mature on September 7, 2021 and amortizes in equal quarterly installments in aggregate annual amounts equal to 5% of the original principal amount in each of the first two years after the date of the closing of the EMC merger transaction, 10% of the original principal amount in each of the third and fourth years after the date of the closing of the EMC merger transaction, and 70% of the original principal amount in the fifth year after the date of the closing of the EMC merger transaction.  The Term Loan A-3 Facility will mature on December 31, 2018 and has no amortization.  The Term Loan B Facility will mature on September 7, 2023 and amortizes in equal quarterly installments in aggregate annual amounts equal to 1% of the original principal amount.  The Revolving Credit Facility will mature on September 7, 2021 and has no amortization.  The Term Loan A-1 and A-3 Facilities require the borrowers to prepay outstanding borrowings under these facilities with 100% of the net cash proceeds of certain non-ordinary course asset sales or dispositions after fully prepaying the Asset Sale Bridge Facility.  The borrowers may voluntarily repay outstanding loans under the Term Loan and Revolving Credit Facilities at any time without premium or penalty, other than customary “breakage” costs.

- added (2016-12-09):
[0001571996-16-000021:note_history:97]
All obligations of the borrowers under the Senior Secured Credit Facilities and certain swap agreements, cash management arrangements, and certain letters of credit provided by any lender or agent party to the Senior Secured Credit Facilities or any of their affiliates and certain other persons are guaranteed by Denali Intermediate Inc. (“Denali Intermediate”), Dell, certain subsidiaries of Denali Intermediate, and each existing and subsequently acquired or organized direct or indirect material wholly-owned domestic restricted subsidiary of Dell, with customary exceptions.  All such obligations under the Senior Secured Credit Facilities (and the guarantees thereof) and certain swap agreements, cash management arrangements, and certain letters of credit provided by any lender or agent party to the Senior Secured Credit Facilities or any of its affiliates and certain other persons are secured by (a) a first-priority security interest in certain tangible and intangible assets of the borrowers and the guarantors and (b) a first-priority pledge of 100% of the capital stock of the borrowers, Dell and each wholly-owned material restricted subsidiary of the borrowers and the guarantors, in each case subject to certain thresholds, exceptions and permitted liens.

- added (2016-12-09):
[0001571996-16-000021:note_history:98]
First Lien Notes — The senior secured notes (collectively, the “First Lien Notes”) were issued on June 1, 2016 in an aggregate principal amount of $20.0 billion.  As of the closing of the EMC merger transaction, Dell International and EMC are the co-issuers of the First Lien Notes.  The First Lien Notes are guaranteed, subject to certain exceptions, on a joint and several basis by Dell Technologies, Denali Intermediate, Dell, and Denali Intermediate’s direct and indirect wholly-owned material domestic subsidiaries that guarantee the Senior Secured Credit Facilities.  The First Lien Notes are secured, on a pari passu basis with the Senior Secured Credit Facilities, on a first-priority basis by substantially all of the tangible and intangible assets of the issuers and guarantors that secure obligations under the Senior Secured Credit Facilities, including pledges of all capital stock of the issuers, of Dell, and of certain wholly-owned material subsidiaries of the issuers and the guarantors, subject to certain exceptions.

- added (2016-12-09):
[0001571996-16-000021:note_history:99]
Senior Notes — The senior unsecured notes (collectively, the "Senior Notes") were issued on June 22, 2016 in an aggregate principal amount of $3.25 billion.  As of the closing of the EMC merger transaction, Dell International and EMC are the co-issuers of the Senior Notes.  The Senior Notes are guaranteed, subject to certain exceptions, on a joint and several basis, by Dell Technologies, Denali Intermediate, Dell, and Denali Intermediate’s direct and indirect wholly-owned material domestic subsidiaries that guarantee the Senior Secured Credit Facilities.

- added (2016-12-09):
[0001571996-16-000021:note_history:100]
Repayment and Termination of Credit Facilities — At the closing of the EMC merger transaction on September 7, 2016, the Company repaid approximately $6.1 billion of borrowings (including accrued and unpaid interest thereon) under the Company’s ABL Credit Facility and Term Loan Facilities obtained in connection with the going-private transaction and terminated such credit facilities and related credit agreements and documents.

- added (2016-12-09):
[0001571996-16-000021:note_history:101]
The ABL Credit Facility provided for an asset-based senior secured revolving credit facility in an initial aggregate principal amount of approximately $2.0 billion, subject to a borrowing base consisting of certain receivables and inventory.  The Term Loan Facilities originally provided for senior secured term loan facilities consisting of a $4.7 billion Term Loan B Facility, a $1.5 billion Term Loan C Facility and a €0.7 billion Term Loan Euro Facility.

- added (2016-12-09):
[0001571996-16-000021:note_history:102]
Redemption of Senior First Lien Notes — In connection with the EMC merger transaction, the Company issued and delivered notices of conditional redemption to holders of the outstanding 5.625% Senior First Lien Notes due 2020 issued by them in October 2013 in connection with Dell’s going private transaction (the “Senior First Lien Notes”) to redeem (a) $0.15 billion in aggregate principal amount of the Senior First Lien Notes at a redemption price of 103% of the principal amount thereof and (b) $1.25 billion in aggregate principal amount of the Senior First Lien Notes at a redemption price equal to 100% of the principal amount thereof plus a “make-whole” premium calculated in accordance with the indenture governing the Senior First Lien Notes, in each case, plus accrued and unpaid interest thereon to but excluding the redemption date. Such redemption notices were conditioned upon, among other matters, the closing of the EMC merger transaction. On September 7, 2016, substantially concurrently with the consummation of the EMC merger transaction, the Company deposited with the trustee of the Senior First Lien Notes the applicable redemption payments to fund such redemptions and thereby redeemed all of the outstanding Senior First Lien Notes.  The Senior First Lien Notes were issued in an aggregate original principal amount of $1.5 billion.

- added (2016-12-09):
[0001571996-16-000021:note_history:103]
EMC Notes — As of September 7, 2016, EMC had outstanding approximately $2.5 billion aggregate principal amount of its 1.875% Notes due June 2018, approximately $2.0 billion aggregate principal amount of its 2.650% Notes due June 2020 and approximately $1.0 billion aggregate principal amount of its 3.375% Notes due June 2023 (collectively, the “EMC Notes”), all of which were issued pursuant to an Indenture dated as of June 6, 2013. The EMC Notes remain outstanding following the closing of the EMC merger transaction. The EMC Notes are senior unsecured obligations of EMC and are not guaranteed by any subsidiaries of EMC or by the Company or any other subsidiaries of the Company.

- changed (2016-12-09):
[0001571996-16-000021:note_history:104]
Structured Financing Debt — As of October 28, 2016 and January 29, 2016, the Company had $3.4 billion and $3.4 billion, respectively, in outstanding structured financing debt, which was primarily related to the fixed-term lease and loan securitization programs and the revolving loan securitization programs.  See Note 7 and Note 9 of the Notes to the Unaudited Condensed Consolidated Financial Statements for further discussion of the structured financing debt and the interest rate swap agreements that hedge a portion of that debt.
  (was, 2016-09-06, similarity 0.9894):
[0001571996-16-000015:note_history:104]
Structured Financing Debt — As of July 29, 2016 and January 29, 2016, the Company had $3.5 billion and $3.4 billion, respectively, in outstanding structured financing debt, which was primarily related to the fixed-term lease and loan securitization programs and the revolving loan securitization programs.  See Note 4 and Note 6 of the Notes to the Unaudited Condensed Consolidated Financial Statements for further discussion of the structured financing debt and the interest rate swap agreements that hedge a portion of that debt.

- changed (2016-12-09):
[0001571996-16-000021:note_history:105]
Unsecured Notes and Debentures — The Company has Unsecured Notes and Debentures that were issued prior to the going-private transaction. Interest on these borrowings is payable semiannually. See "Senior Notes" above for a discussion of the Senior Unsecured Notes issued in connection with the EMC merger transaction.
  (was, 2016-09-06, similarity 0.9299):
[0001571996-16-000015:note_history:105]
Unsecured Notes and Debentures — The Company has Unsecured Notes and Debentures that were issued prior to the going-private transaction. Interest on these borrowings is payable semiannually. See "EMC Merger Financing" above for a discussion of the Senior Unsecured Notes issued in connection with the EMC merger.

- added (2016-12-09):
[0001571996-16-000021:note_history:106]
Asset Sale Bridge Facility — On September 7, 2016, certain subsidiaries of the Company entered into a credit agreement providing for a senior unsecured asset sale bridge facility in an aggregate principal amount of $2.2 billion (the “Asset Sale Bridge Facility”). Dell International and EMC are the borrowers under the Asset Sale Bridge Facility, which is guaranteed by Denali Intermediate, certain subsidiaries of Denali Intermediate, Dell, and each existing and subsequently acquired or organized direct or indirect material wholly-owned domestic restricted subsidiary of Dell that guarantees the Senior Secured Credit Facilities.

- added (2016-12-09):
[0001571996-16-000021:note_history:107]
Borrowings under the Asset Sale Bridge Facility bear interest (a) at a fixed rate of 4.875% per annum until the date that is the three-month anniversary of the closing date of the facility, (b) at a LIBOR-based rate plus a marginal rate of 7.50% per annum from the date that is the three-month anniversary of the closing date of the facility until the date that is the six-month anniversary of the closing date of the facility, and (c) thereafter, at a LIBOR-based rate, subject to increases of 50 basis points on the applicable margin rate every three months thereafter. Interest is payable, at the end of each interest period (but at least every three months), in arrears.

- added (2016-12-09):
[0001571996-16-000021:note_history:108]
The Asset Sale Bridge Facility will mature on September 6, 2017 and has no amortization. The Asset Sale Bridge Facility requires the borrowers to prepay outstanding borrowings under the facility with 100% of the net cash proceeds of certain non-ordinary course asset sales or dispositions. The borrowers may voluntarily repay outstanding loans under the Asset Sale Bridge Facility at any time without premium or penalty, other than customary "breakage" costs.

- added (2016-12-09):
[0001571996-16-000021:note_history:109]
See Note 22 of the Notes to the Unaudited Condensed Consolidated Financial Statements for information regarding the repayment and termination of the Asset Sale Bridge Facility that occurred subsequent to October 28, 2016.

- added (2016-12-09):
[0001571996-16-000021:note_history:110]
Margin Bridge Facility — On September 7, 2016, Merger Sub and EMC entered into a credit agreement providing for a senior secured margin bridge facility in an aggregate principal amount of $2.5 billion (the “Margin Bridge Facility”).  EMC is the borrower under the Margin Bridge Facility, which is secured solely by 77,033,442 shares of Class B common stock of VMware and any proceeds thereof.

- added (2016-12-09):
[0001571996-16-000021:note_history:111]
Interest under the Margin Bridge Facility is payable, at the borrower's option, either at (a) a base rate plus 0.75% per annum or (b) a LIBOR-based rate plus 1.75% per annum. Interest is payable, in the case of loans bearing interest based on LIBOR, at the end of each interest period (but at least every three months), in arrears and, in the case of loans bearing interest based on the base rate, quarterly in arrears.

- added (2016-12-09):
[0001571996-16-000021:note_history:112]
The Margin Bridge Facility will mature on September 6, 2017 and has no amortization. The Margin Bridge Facility requires the borrower to prepay outstanding borrowings under the Margin Bridge Facility with 100% of the net cash proceeds of any asset sale or other disposition of the pledged VMware shares.  The borrower may voluntarily repay outstanding loans under the Margin Bridge Facility at any time without premium or penalty, other than customary “breakage” costs, subject to certain minimum threshold amounts for prepayment.

- added (2016-12-09):
[0001571996-16-000021:note_history:113]
VMware Note Bridge Facility — On September 7, 2016, Merger Sub and EMC entered into a credit agreement providing for a senior secured note bridge facility in an aggregate principal amount of $1.5 billion (the “VMware Note Bridge Facility”).  EMC is the borrower under the VMware Note Bridge Facility, which is secured solely by certain intercompany notes in an aggregate principal amount of $1.5 billion issued by VMware that are payable to EMC, and the proceeds thereof.

- added (2016-12-09):
[0001571996-16-000021:note_history:114]
Interest under the VMware Note Bridge Facility is payable, at the borrower's option, either at (a) a base rate plus 0.75% per annum or (b) a LIBOR-based rate plus 1.75% per annum. Interest is payable, in the case of loans bearing interest based on LIBOR, at the end of each interest period (but at least every three months), in arrears and, in the case of loans bearing interest based on the base rate, quarterly in arrears.

- added (2016-12-09):
[0001571996-16-000021:note_history:115]
The VMware Note Bridge Facility will mature on September 6, 2017 and has no amortization.  The VMware Note Bridge Facility requires the borrower to prepay outstanding borrowings under the VMware Note Bridge Facility with 100% of the net cash proceeds of any asset sale or other disposition of the pledged VMware promissory notes. The borrower may voluntarily repay outstanding loans under the VMware Note Bridge Facility at any time without premium or penalty, other than customary “breakage” costs, subject to certain minimum threshold amounts for prepayment.

- changed (2016-12-09):
[0001571996-16-000021:note_history:116]
Aggregate Future Maturities — As of October 28, 2016, aggregate future maturities of the Company's debt were as follows:
  (was, 2016-09-06, similarity 0.7897):
[0001571996-16-000015:note_history:116]
As of July 29, 2016, aggregate future maturities of the Company's debt were as follows:

- added (2016-12-09):
[0001571996-16-000021:note_history:117]
|  | Maturities by Fiscal Year |
|  | 2017 (remaining three months) |  | 2018 |  | 2019 |  | 2020 |  | 2021 |  | Thereafter |  | Total |
|  | (in millions) |
| Structured Financing Debt | $ | 581 |  |  | $ | 1,754 |  |  | $ | 911 |  |  | $ | 150 |  |  | $ | 27 |  |  | $ | 3 |  |  | $ | 3,426 |  |
| Senior Secured Credit Facilities and First Lien Notes | 62 |  |  | 246 |  |  | 5,795 |  |  | 4,193 |  |  | 332 |  |  | 25,272 |  |  | 35,900 |  |
| Unsecured Notes and Debentures | — |  |  | — |  |  | 500 |  |  | 600 |  |  | — |  |  | 1,353 |  |  | 2,453 |  |
| Senior Notes and EMC Notes | — |  |  | — |  |  | 2,500 |  |  | — |  |  | 2,000 |  |  | 4,250 |  |  | 8,750 |  |
| Bridge Facilities | — |  |  | 6,200 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 6,200 |  |
| Other | 17 |  |  | 13 |  |  | 2 |  |  | — |  |  | — |  |  | 26 |  |  | 58 |  |
| Total maturities, principal amount | 660 |  |  | 8,213 |  |  | 9,708 |  |  | 4,943 |  |  | 2,359 |  |  | 30,904 |  |  | 56,787 |  |
| Associated carrying value adjustments | (1 | ) |  | (76 | ) |  | (113 | ) |  | (63 | ) |  | — |  |  | (862 | ) |  | (1,115 | ) |
| Total maturities, carrying value amount | $ | 659 |  |  | $ | 8,137 |  |  | $ | 9,595 |  |  | $ | 4,880 |  |  | $ | 2,359 |  |  | $ | 30,042 |  |  | $ | 55,672 |  |

- added (2016-12-09):
[0001571996-16-000021:note_history:118]
Covenants and Unrestricted Net Assets — The credit agreements for the Senior Secured Credit Facilities and the Asset Sale Bridge Facility contain customary negative covenants that generally limit the ability of Denali Intermediate, Dell, and Dell’s and Denali Intermediate’s other restricted subsidiaries to incur debt, create liens, make fundamental changes, enter into asset sales, make certain investments, pay dividends or distribute or redeem certain equity interests, prepay or redeem certain debt, and enter into certain transactions with affiliates.  The indenture governing the Senior Notes contains customary negative covenants that generally limit the ability of Denali Intermediate, Dell, and Dell’s and Denali’s other restricted subsidiaries to incur additional debt or issue certain preferred shares, pay dividends on or make other distributions in respect of capital stock or make other restricted payments, make certain investments, sell or transfer certain assets, create liens on certain assets to secure debt, consolidate, merge, sell, or otherwise dispose of all or substantially all assets, enter into certain transactions with affiliates, and designate subsidiaries as unrestricted subsidiaries.  The negative covenants under such credit agreements and indenture are subject to certain exceptions, qualifications and “baskets.”  The indentures governing the First Lien Notes, the Unsecured Notes and Debentures, and the EMC Notes variously impose limitations, subject to specified exceptions, on creating certain liens, entering into sale and lease-back transactions, and entering into certain asset sales.  As of October 28, 2016, the Company had certain consolidated subsidiaries that were designated as unrestricted subsidiaries for all purposes of the applicable credit agreements and the indentures governing the First Lien Notes and the Senior Notes.  As of October 28, 2016, unrestricted net assets of the consolidated subsidiaries were approximately $32.8 billion.  The foregoing credit agreements and indentures contain customary events of default, including failure to make required payments, failure to comply with covenants, and the occurrence of certain events of bankruptcy and insolvency.

- added (2016-12-09):
[0001571996-16-000021:note_history:119]
The Term Loan A-1 Facility, the Term Loan A-2 Facility, the Term Loan A-3 Facility, and the Revolving Credit Facility are subject to a first lien net leverage ratio covenant that will be tested at the end of each fiscal quarter of Dell with respect to Dell’s preceding four fiscal quarters.  The Company was in compliance with this financial covenant as of October 28, 2016.

- removed (2016-12-09):
[0001571996-16-000015:note_history:120]
|  | July 29, 2016 |  | January 29, 2016 |
|  | (in millions) |
| Secured Debt |  |  |  |  |  |
| Structured financing debt | $ | 3,488 |  |  | $ | 3,411 |  |
| 3.75% Floating rate due October 2018 ("Term Loan C Facility") | 834 |  |  | 1,003 |  |
| 4.00% Floating rate due April 2020 ("Term Loan B Facility") | 4,307 |  |  | 4,329 |  |
| 4.00% Floating rate due April 2020 ("Term Loan Euro Facility") | 903 |  |  | 891 |  |
| 5.625% due October 2020 ("Senior First Lien Notes") | 1,400 |  |  | 1,400 |  |
| EMC merger financing issued on June 1, 2016 ("First Lien Notes"): |  |  |  |
| 3.48% due June 2019 | 3,750 |  |  | — |  |
| 4.42% due June 2021 | 4,500 |  |  | — |  |
| 5.45% due June 2023 | 3,750 |  |  | — |  |
| 6.02% due June 2026 | 4,500 |  |  | — |  |
| 8.10% due June 2036 | 1,500 |  |  | — |  |
| 8.35% due June 2046 | 2,000 |  |  | — |  |
| Unsecured Notes and Debentures |  |  |  |
| Notes and debentures issued prior to going-private transaction: |  |  |  |
| 3.10% due April 2016 | — |  |  | 400 |  |
| 5.65% due April 2018 | 500 |  |  | 500 |  |
| 5.875% due June 2019 | 600 |  |  | 600 |  |
| 4.625% due April 2021 | 400 |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 265 |  |  | 265 |  |
| EMC merger financing issued on June 22, 2016 ("Senior Unsecured Notes"): |  |  |  |
| 5.875% due June 2021 | 1,625 |  |  | — |  |
| 7.125% due June 2024 | 1,625 |  |  | — |  |
| Other | 58 |  |  | 93 |  |
| Total debt, principal amount | 36,693 |  |  | 13,980 |  |
| Unamortized discount, net of unamortized premium | (218 | ) |  | (221 | ) |
| Debt issuance costs | (139 | ) |  | (128 | ) |
| Total debt, carrying value | $ | 36,336 |  |  | $ | 13,631 |  |
| Total short-term debt | $ | 2,500 |  |  | $ | 2,981 |  |
| Total long-term debt | $ | 33,836 |  |  | $ | 10,650 |  |

- removed (2016-12-09):
[0001571996-16-000015:note_history:121]
To finance the going-private transaction, the Company issued $13.9 billion in debt, which included borrowings under the Term Loan facilities and the ABL Credit Facility, proceeds from the sale of the Senior First Lien Notes and other notes, as well as borrowings under the structured financing debt programs.  During June 2016, the Company issued $23.25 billion of debt securities in connection with the pending EMC merger transaction, which included proceeds from the sale of the First Lien Notes and Senior Unsecured Notes.  During the six months ended July 29, 2016, the Company repaid $0.4 billion of maturing Unsecured Notes and Debentures as well as $0.2 billion of Term Loan facilities, net.

- removed (2016-12-09):
[0001571996-16-000015:note_history:122]
EMC Merger Financing — On June 1, 2016, two subsidiaries of the Company completed a private offering of the First Lien Notes with an aggregate principal amount of $20.0 billion, and on June 22, 2016, two subsidiaries of the Company completed a private offering of the Senior Unsecured Notes with an aggregate principal amount of $3.25 billion.

- removed (2016-12-09):
[0001571996-16-000015:note_history:123]
Under the terms of the agreements relating to the issuance of the First Lien Notes and Senior Unsecured Notes, the proceeds of the offerings were deposited into escrow, with such proceeds to be released to finance the consummation of the EMC merger subject to the satisfaction of customary conditions.  Upon the completion of the EMC merger, Dell International L.L.C. (a wholly-owned indirect subsidiary of Dell Technologies) and EMC will assume all of the co-issuers' obligations under the First Lien Notes and Senior Unsecured Notes, and the First Lien Notes and Senior Unsecured Notes will be guaranteed on a joint and several basis by Dell Technologies, Denali Intermediate Inc. (a wholly-owned direct subsidiary of Dell Technologies), Dell Inc. and each of Denali Intermediate Inc.'s wholly-owned domestic subsidiaries (including EMC's wholly-owned domestic subsidiaries following the completion of the EMC merger) that guarantees obligations under the new senior secured credit facilities that will be entered into in connection with the EMC merger.

- removed (2016-12-09):
[0001571996-16-000015:note_history:124]
The net proceeds held in escrow from the private offerings of multiple series of the First Lien Notes and Senior Unsecured Notes were included in restricted cash in the Condensed Consolidated Statements of Financial Position as of July 29, 2016, and such proceeds will be held as restricted cash until the completion of the EMC merger.  The receipt of the net proceeds is not reflected in the Condensed Consolidated Statements of Cash Flows, given that the proceeds were required to be deposited directly into escrow rather than into the Company's unrestricted cash accounts.  During the three months ended July 29, 2016, as required under the escrow agreement, the Company prepaid interest into escrow in the amount of $40 million, which is reflected as a cash outflow from investing activities in the Condensed Consolidated Statements of Cash Flows.  This amount will be returned to the Company upon the closing of the EMC merger transaction and paid to the holders of the First Lien Notes and Senior Unsecured Notes on the scheduled interest payment dates.

- removed (2016-12-09):
[0001571996-16-000015:note_history:125]
The Company expects to incur costs of approximately $0.5 billion upon the closing of the EMC merger transaction relating to the issuance of the First Lien Notes and Senior Unsecured Notes, which will be capitalized as debt issuance costs in the Condensed Consolidated Statements of Financial Position.  If the EMC merger agreement is terminated, the Company expects to incur a First Lien Note redemption fee of $0.2 billion.  Upon the closing of the EMC merger transaction, the Company will be party to new credit agreements containing covenants that are not expected to materially differ from the covenants contained in the Company's existing credit agreements.

- removed (2016-12-09):
[0001571996-16-000015:note_history:126]
Term Loan Facilities — The $1.5 billion Term Loan C Facility was issued on October 29, 2013, and provides for equal quarterly principal amortization in an annual amount equal to 10% of the original principal amount in the first year of the agreement and increasing annual percentage amounts in subsequent years with the payment of the outstanding balance due at maturity, in October 2018.  The annual principal amortization percentage is currently 22.5%.  The $4.7 billion Term Loan B Facility and the €0.7 billion Term Loan Euro Facility were issued on October 29, 2013, and provide for quarterly principal amortization in an annual amount equal to 1% of the original principal amount and payment of the outstanding balances due at maturity in April 2020.  On June 10, 2015, the Company refinanced and amended the Term Loan facilities to reduce interest rate floors and margins and to modify certain covenant requirements.  The refinancing increased the outstanding Term Loan Euro Facility to €0.8 billion, which was offset by a decrease in the Term Loan B Facility to $4.4 billion.  Borrowings under the Term Loan facilities bear interest, payable quarterly, at a rate per annum equal to an applicable margin, plus, at the borrowers’ option, either (a) a base rate or (b) a LIBOR rate for the applicable currency, in each case, subject to interest rate floors.  Under the Term Loan facilities, if the Company has excess cash flows that are not reinvested in working capital, strategic investments, or finance activities on an annual basis and if the Company’s secured leverage ratio falls within certain thresholds, a percentage of the excess cash flows is required to be applied to prepay secured debt.

- removed (2016-12-09):
[0001571996-16-000015:note_history:127]
Senior First Lien Notes — The Senior First Lien Notes were issued on October 7, 2013 in an aggregate principal amount of

- removed (2016-12-09):
[0001571996-16-000015:note_history:128]
$1.5 billion and are payable in full at maturity, in October 2020.  As of July 29, 2016, the outstanding balance of these notes was $1.4 billion.  Interest on the Senior First Lien Notes is payable semiannually.

- removed (2016-12-09):
[0001571996-16-000015:note_history:129]
ABL Credit Facility — On October 29, 2013, the Company entered into a secured ABL Credit Facility to support its working capital needs.  The maximum aggregate borrowings under this revolving credit facility are approximately $2.0 billion.  Borrowings under the ABL Credit Facility are subject to a borrowing base, which consists of certain receivables and inventory.  Available borrowings under the ABL Credit Facility are reduced by draws on the facility as well as letters of credit.  As of July 29, 2016, there were no draws on the facility and, after taking into account outstanding letters of credit, available borrowings totaled $1.4 billion.  Borrowings under the facility bear interest at a rate per annum equal to an applicable margin, plus, at the borrowers’ option, either (a) a base rate, (b) a LIBOR rate or (c) certain other applicable rates.  The applicable margin under the facility is determined based on excess liquidity as a percentage of the maximum borrowing amount under the facility.  The ABL Credit Facility will expire in October 2018.

- removed (2016-12-09):
[0001571996-16-000015:note_history:130]
The borrowers under the Term Loan facilities and the ABL Credit Facility and the co-issuers of the Senior First Lien Notes are subsidiaries of Dell Inc.  Dell Inc. and substantially all of its domestic subsidiaries guarantee the borrowings under the Term

- removed (2016-12-09):
[0001571996-16-000015:note_history:131]
Loan facilities and the obligations under the Senior First Lien Notes.  Dell Inc. and certain of its domestic subsidiaries guarantee the borrowings under the ABL Credit Facility.  All borrowings and other obligations under the Term Loan facilities and the ABL Credit Facility generally are secured by first-priority or second-priority security interests in substantially all of the assets of Dell Inc., the borrowers under the facilities and the guarantors of the facilities, as well as by pledges of the equity interests of Dell Inc. and certain of its subsidiaries, and a portion of the equity interests of certain first-tier foreign subsidiaries of Dell Inc.  All obligations under the Senior First Lien Notes are secured by a first-priority security interest in certain cash flow collateral and a second-priority security interest in other collateral securing the ABL Credit Facility.

- removed (2016-12-09):
[0001571996-16-000015:note_history:132]
Aggregate Future Maturities

- removed (2016-12-09):
[0001571996-16-000015:note_history:133]
|  | Maturities by Fiscal Year |
|  | 2017 (remaining six months) |  | 2018 |  | 2019 |  | 2020 |  | 2021 |  | Thereafter |  | Total |
|  | (in millions) |
| Structured Financing Debt | $ | 1,121 |  |  | $ | 1,516 |  |  | $ | 691 |  |  | $ | 136 |  |  | $ | 23 |  |  | $ | 1 |  |  | $ | 3,488 |  |
| Term Loan Facilities, Senior First Lien Notes, and First Lien Notes | 205 |  |  | 427 |  |  | 334 |  |  | 3,802 |  |  | 6,426 |  |  | 16,250 |  |  | 27,444 |  |
| Unsecured Notes and Debentures | — |  |  | — |  |  | 500 |  |  | 600 |  |  | — |  |  | 4,603 |  |  | 5,703 |  |
| Other | 21 |  |  | 9 |  |  | 2 |  |  | — |  |  | — |  |  | 26 |  |  | 58 |  |
| Total maturities, principal amount | 1,347 |  |  | 1,952 |  |  | 1,527 |  |  | 4,538 |  |  | 6,449 |  |  | 20,880 |  |  | 36,693 |  |
| Associated carrying value adjustments | (2 | ) |  | (2 | ) |  | (16 | ) |  | (7 | ) |  | (130 | ) |  | (200 | ) |  | (357 | ) |
| Total maturities, carrying value amount | $ | 1,345 |  |  | $ | 1,950 |  |  | $ | 1,511 |  |  | $ | 4,531 |  |  | $ | 6,319 |  |  | $ | 20,680 |  |  | $ | 36,336 |  |

- removed (2016-12-09):
[0001571996-16-000015:note_history:134]
Covenants and Restricted Net Assets — The credit agreements for the Term Loan facilities and the ABL Credit Facility and the indenture governing the Senior First Lien Notes contain covenants restricting the ability of the Company and its restricted subsidiaries, subject to specified exceptions, to incur additional debt, create liens on certain assets to secure debt, pay dividends and make other restricted payments, make certain investments, sell or transfer certain assets, consolidate, merge, sell or otherwise dispose of all or substantially all of their assets, and enter into certain transactions with affiliates.  The Company designated certain subsidiaries as unrestricted subsidiaries for all purposes of the credit agreements and the indenture as of August 1, 2015, the impact of which was not material to its financial position as of July 29, 2016 or results of operations for the three and six months then ended.  The indentures governing the Unsecured Notes and Debentures contain covenants limiting the Company's ability to create certain liens, enter into sale-and-lease back transactions, and consolidate or merge with, or convey, transfer, or lease all or substantially all of its assets to, another person.  The credit agreements and all such indentures contain customary events of default, including failure to make required payments, failure to comply with covenants, and the occurrence of certain events of bankruptcy and insolvency.  The ABL Credit Facility requires compliance with conditions that must be satisfied prior to any borrowing and maintenance of a minimum fixed charge coverage ratio.  The Company was in compliance with all financial covenants as of July 29, 2016.

- removed (2016-12-09):
[0001571996-16-000015:note_history:135]
The issuers and holders of the proceeds of the First Lien Notes and Senior Unsecured Notes issued in connection with the pending EMC merger transaction are unrestricted subsidiaries for purposes of the Company’s indebtedness.  At the closing of the EMC merger transaction, Dell International and EMC, which are restricted subsidiaries for purposes of the Company’s indebtedness, will succeed to the obligations of such unrestricted subsidiaries as the issuers of the First Lien Notes and Senior Unsecured Notes.


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2016-12-09):
[0001571996-16-000021:note_history:136]
|  | October 28, 2016 |  | January 29, 2016 |
|  | (in millions) |
| Secured Debt |  |  |  |
| Structured financing debt | $ | 3,426 |  |  | $ | 3,411 |  |
| 3.75% Floating rate due October 2018 ("Term Loan C Facility") | — |  |  | 1,003 |  |
| 4.00% Floating rate due April 2020 ("Term Loan B Facility") | — |  |  | 4,329 |  |
| 4.00% Floating rate due April 2020 ("Term Loan Euro Facility") | — |  |  | 891 |  |
| 5.625% due October 2020 ("Senior First Lien Notes") | — |  |  | 1,400 |  |
| EMC merger transaction financing issued on September 7, 2016 ("Senior Secured Credit Facilities"): |  |  |  |
| 4.00% Term Loan B Facility due September 2023 | 5,000 |  |  | — |  |
| 2.53% Term Loan A-1 Facility due December 2018 | 3,700 |  |  | — |  |
| 2.78% Term Loan A-2 Facility due September 2021 | 3,925 |  |  | — |  |
| 2.53% Term Loan A-3 Facility due December 2018 | 1,800 |  |  | — |  |
| 2.53% Revolving Credit Facility due September 2021 | 1,475 |  |  | — |  |
| EMC merger transaction financing issued on June 1, 2016 ("First Lien Notes"): |  |  |  |
| 3.48% due June 2019 | 3,750 |  |  | — |  |
| 4.42% due June 2021 | 4,500 |  |  | — |  |
| 5.45% due June 2023 | 3,750 |  |  | — |  |
| 6.02% due June 2026 | 4,500 |  |  | — |  |
| 8.10% due June 2036 | 1,500 |  |  | — |  |
| 8.35% due June 2046 | 2,000 |  |  | — |  |
| Unsecured Notes and Debentures |  |  |  |
| Notes and debentures issued prior to going-private transaction: |  |  |  |
| 3.10% due April 2016 | — |  |  | 400 |  |
| 5.65% due April 2018 | 500 |  |  | 500 |  |
| 5.875% due June 2019 | 600 |  |  | 600 |  |
| 4.625% due April 2021 | 400 |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 265 |  |  | 265 |  |
| EMC merger transaction financing issued on June 22, 2016 ("Senior Notes"): |  |  |  |
| 5.875% due June 2021 | 1,625 |  |  | — |  |
| 7.125% due June 2024 | 1,625 |  |  | — |  |
| Existing EMC notes assumed as part of the EMC merger transaction ("EMC Notes"): |  |  |  |
| 1.875% due June 2018 | 2,500 |  |  | — |  |
| 2.650% due June 2020 | 2,000 |  |  | — |  |
| 3.375% due June 2023 | 1,000 |  |  | — |  |
| Bridge Facilities |  |  |  |
| 4.875% Asset Sale Bridge Facility due September 2017 | 2,200 |  |  | — |  |
| 2.28% Margin Bridge Facility due September 2017 | 2,500 |  |  | — |  |
| 2.28% VMware Note Bridge Facility due September 2017 | 1,500 |  |  | — |  |
| Other | 58 |  |  | 93 |  |
| Total debt, principal amount | 56,787 |  |  | 13,980 |  |

- added (2016-12-09):
[0001571996-16-000021:note_history:137]
|  | October 28, 2016 |  | January 29, 2016 |
|  | (in millions) |
| Total debt, principal amount | 56,787 |  |  | 13,980 |  |
| Unamortized discount, net of unamortized premium | (310 | ) |  | (221 | ) |
| Debt issuance costs | (805 | ) |  | (128 | ) |
| Total debt, carrying value | $ | 55,672 |  |  | $ | 13,631 |  |
| Total short-term debt | $ | 8,388 |  |  | $ | 2,981 |  |
| Total long-term debt | $ | 47,284 |  |  | $ | 10,650 |  |

- removed (2016-12-09):
[0001571996-16-000015:note_history:138]
|  | July 29, 2016 |  | January 29, 2016 |
|  | (in millions) |
| Secured Debt |  |  |  |  |  |
| Structured financing debt | $ | 3,488 |  |  | $ | 3,411 |  |
| 3.75% Floating rate due October 2018 ("Term Loan C Facility") | 834 |  |  | 1,003 |  |
| 4.00% Floating rate due April 2020 ("Term Loan B Facility") | 4,307 |  |  | 4,329 |  |
| 4.00% Floating rate due April 2020 ("Term Loan Euro Facility") | 903 |  |  | 891 |  |
| 5.625% due October 2020 ("Senior First Lien Notes") | 1,400 |  |  | 1,400 |  |
| EMC merger financing issued on June 1, 2016 ("First Lien Notes"): |  |  |  |
| 3.48% due June 2019 | 3,750 |  |  | — |  |
| 4.42% due June 2021 | 4,500 |  |  | — |  |
| 5.45% due June 2023 | 3,750 |  |  | — |  |
| 6.02% due June 2026 | 4,500 |  |  | — |  |
| 8.10% due June 2036 | 1,500 |  |  | — |  |
| 8.35% due June 2046 | 2,000 |  |  | — |  |
| Unsecured Notes and Debentures |  |  |  |
| Notes and debentures issued prior to going-private transaction: |  |  |  |
| 3.10% due April 2016 | — |  |  | 400 |  |
| 5.65% due April 2018 | 500 |  |  | 500 |  |
| 5.875% due June 2019 | 600 |  |  | 600 |  |
| 4.625% due April 2021 | 400 |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 265 |  |  | 265 |  |
| EMC merger financing issued on June 22, 2016 ("Senior Unsecured Notes"): |  |  |  |
| 5.875% due June 2021 | 1,625 |  |  | — |  |
| 7.125% due June 2024 | 1,625 |  |  | — |  |
| Other | 58 |  |  | 93 |  |
| Total debt, principal amount | 36,693 |  |  | 13,980 |  |
| Unamortized discount, net of unamortized premium | (218 | ) |  | (221 | ) |
| Debt issuance costs | (139 | ) |  | (128 | ) |
| Total debt, carrying value | $ | 36,336 |  |  | $ | 13,631 |  |
| Total short-term debt | $ | 2,500 |  |  | $ | 2,981 |  |
| Total long-term debt | $ | 33,836 |  |  | $ | 10,650 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-12-09):
[0001571996-16-000021:note_history:139]
As of October 28, 2016, aggregate future maturities of the Company's debt were as follows:
  (was, 2016-09-06, similarity 0.9333):
[0001571996-16-000015:note_history:139]
As of July 29, 2016, aggregate future maturities of the Company's debt were as follows:

- added (2016-12-09):
[0001571996-16-000021:note_history:140]
|  | Maturities by Fiscal Year |
|  | 2017 (remaining three months) |  | 2018 |  | 2019 |  | 2020 |  | 2021 |  | Thereafter |  | Total |
|  | (in millions) |
| Structured Financing Debt | $ | 581 |  |  | $ | 1,754 |  |  | $ | 911 |  |  | $ | 150 |  |  | $ | 27 |  |  | $ | 3 |  |  | $ | 3,426 |  |
| Senior Secured Credit Facilities and First Lien Notes | 62 |  |  | 246 |  |  | 5,795 |  |  | 4,193 |  |  | 332 |  |  | 25,272 |  |  | 35,900 |  |
| Unsecured Notes and Debentures | — |  |  | — |  |  | 500 |  |  | 600 |  |  | — |  |  | 1,353 |  |  | 2,453 |  |
| Senior Notes and EMC Notes | — |  |  | — |  |  | 2,500 |  |  | — |  |  | 2,000 |  |  | 4,250 |  |  | 8,750 |  |
| Bridge Facilities | — |  |  | 6,200 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 6,200 |  |
| Other | 17 |  |  | 13 |  |  | 2 |  |  | — |  |  | — |  |  | 26 |  |  | 58 |  |
| Total maturities, principal amount | 660 |  |  | 8,213 |  |  | 9,708 |  |  | 4,943 |  |  | 2,359 |  |  | 30,904 |  |  | 56,787 |  |
| Associated carrying value adjustments | (1 | ) |  | (76 | ) |  | (113 | ) |  | (63 | ) |  | — |  |  | (862 | ) |  | (1,115 | ) |
| Total maturities, carrying value amount | $ | 659 |  |  | $ | 8,137 |  |  | $ | 9,595 |  |  | $ | 4,880 |  |  | $ | 2,359 |  |  | $ | 30,042 |  |  | $ | 55,672 |  |

- removed (2016-12-09):
[0001571996-16-000015:note_history:141]
|  | Maturities by Fiscal Year |
|  | 2017 (remaining six months) |  | 2018 |  | 2019 |  | 2020 |  | 2021 |  | Thereafter |  | Total |
|  | (in millions) |
| Structured Financing Debt | $ | 1,121 |  |  | $ | 1,516 |  |  | $ | 691 |  |  | $ | 136 |  |  | $ | 23 |  |  | $ | 1 |  |  | $ | 3,488 |  |
| Term Loan Facilities, Senior First Lien Notes, and First Lien Notes | 205 |  |  | 427 |  |  | 334 |  |  | 3,802 |  |  | 6,426 |  |  | 16,250 |  |  | 27,444 |  |
| Unsecured Notes and Debentures | — |  |  | — |  |  | 500 |  |  | 600 |  |  | — |  |  | 4,603 |  |  | 5,703 |  |
| Other | 21 |  |  | 9 |  |  | 2 |  |  | — |  |  | — |  |  | 26 |  |  | 58 |  |
| Total maturities, principal amount | 1,347 |  |  | 1,952 |  |  | 1,527 |  |  | 4,538 |  |  | 6,449 |  |  | 20,880 |  |  | 36,693 |  |
| Associated carrying value adjustments | (2 | ) |  | (2 | ) |  | (16 | ) |  | (7 | ) |  | (130 | ) |  | (200 | ) |  | (357 | ) |
| Total maturities, carrying value amount | $ | 1,345 |  |  | $ | 1,950 |  |  | $ | 1,511 |  |  | $ | 4,531 |  |  | $ | 6,319 |  |  | $ | 20,680 |  |  | $ | 36,336 |  |


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2016-12-09):
[0001571996-16-000021:note_history:142]
Revenue Recognition — Net revenue primarily includes sales of hardware, services, software licenses, and peripherals.  The Company recognizes revenue for these products and services when it is realized or realizable and earned.  Revenue is recognized when persuasive evidence of an arrangement exists; delivery has occurred or services have been rendered; the Company's fee to its customer is fixed or determinable; and collection of the resulting receivable is reasonably assured.  This policy is applicable to all sales, including sales to resellers and end-users.

- added (2016-12-09):
[0001571996-16-000021:note_history:143]
Revenue from third-party software sales and extended warranties for third-party products, for which the Company does not meet the criteria for gross revenue recognition, is recognized on a net basis.  All other revenue is recognized on a gross basis.

- added (2016-12-09):
[0001571996-16-000021:note_history:144]
Services revenue and cost of services revenue captions in the Consolidated Statements of Income (Loss) include the Company's services, third-party software revenue, and support services related to the Company-owned software offerings.

- added (2016-12-09):
[0001571996-16-000021:note_history:145]
The following summarizes the major terms of contractual relationships with customers and the manner in which the Company accounts for sales transactions.

- added (2016-12-09):
[0001571996-16-000021:note_history:146]
Products

- added (2016-12-09):
[0001571996-16-000021:note_history:147]
Product revenue consists of computer hardware, enterprise hardware, and software licenses sales that are delivered, sold as a subscription or sold on a consumption basis. Computer hardware and enterprise hardware include notebooks and desktop PCs, servers, storage hardware, and other hardware-related devices.  Software license sales include optional, stand-alone software applications. Software applications provide customers with resource management, backup and archiving, information security, information management and intelligence, data analytics and server virtualization capabilities.  Revenue from the sale of hardware products and systems is recognized when title and risk of loss pass to the customer.  Delivery is considered complete when products have been shipped to the Company's customer, title and risk of loss have transferred to the customer, and customer acceptance has been satisfied.  Customer acceptance is satisfied if acceptance is obtained from the customer, if all acceptance provisions lapse, or if the Company has evidence that all acceptance provisions have been satisfied.  Depending on the nature of the arrangement, software license sales is generally recognized upon shipment or electronic delivery.  For certain arrangements, revenue is recognized based on usage or ratably over the term of the arrangement.  License revenue from royalty arrangements is recognized upon either receipt of royalty reports or payments from third parties.

- added (2016-12-09):
[0001571996-16-000021:note_history:148]
The Company records reductions to revenue for estimated customer sales returns, rebates, and certain other customer incentive programs.  These reductions to revenue are made based upon reasonable and reliable estimates that are determined by historical experience, contractual terms, and current conditions.  The primary factors affecting the Company's accrual for estimated customer returns include estimated return rates as well as the number of units shipped that have a right of return that has not expired as of the balance sheet date.  If returns cannot be reliably estimated, revenue is not recognized until a reliable estimate can be made or the return right lapses.

- added (2016-12-09):
[0001571996-16-000021:note_history:149]
The Company sells its products directly to customers as well as through other distribution channels, such as retailers, distributors, and resellers.  The Company recognizes revenue on these sales when the reseller has economic substance apart from the Company; any credit risk has been identified and quantified; title and risk of loss have passed to the sales channel; the fee paid to the Company is not contingent upon resale or payment by the end user; and the Company has no further obligations related to bringing about resale or delivery.

- added (2016-12-09):
[0001571996-16-000021:note_history:150]
Sales through the Company's distribution channels are primarily made under agreements allowing for limited rights of return, price protection, rebates, and marketing development funds.  The Company has generally limited return rights through contractual caps or has an established selling history for these arrangements.  Therefore, there is sufficient data to establish reasonable and reliable estimates of returns for the majority of these sales.  To the extent price protection or return rights are not limited and a reliable estimate cannot be made, all of the revenue and related costs are deferred until the product has been sold to the end-user or the rights expire.  The Company records estimated reductions to revenue or an expense for distribution channel programs at the later of the offer or the time revenue is recognized.

- added (2016-12-09):
[0001571996-16-000021:note_history:151]
The Company defers the cost of shipped products awaiting revenue recognition until revenue is recognized.

- added (2016-12-09):
[0001571996-16-000021:note_history:152]
Services

- added (2016-12-09):
[0001571996-16-000021:note_history:153]
Services revenue consists of hardware and software maintenance, installation services, professional services, training revenue, third-party software revenue, and software sold as a service.  The Company recognizes revenue from fixed-price support or maintenance contracts sold for both hardware and software ratably over the contract period and recognizes the costs associated with these contracts as incurred.  For sales of extended warranties with a separate contract price, the Company defers revenue equal to the separately stated price.  Revenue associated with undelivered elements is deferred and recorded when delivery occurs or services are provided. Revenue from extended warranty and service contracts, for which the Company is obligated to perform, is recorded as deferred revenue and subsequently recognized over the term of the contract on a straight-line basis or when the service is completed and the costs associated with these contracts are recognized as incurred.

- added (2016-12-09):
[0001571996-16-000021:note_history:154]
Multiple Deliverables

- added (2016-12-09):
[0001571996-16-000021:note_history:155]
When an arrangement has more than one element, such as hardware, software, and services contained in a single arrangement, the Company first allocates revenue based upon the relative selling price into two categories: (1) non-software components, such as hardware and any hardware-related items, such as required system software that functions with the hardware to deliver the essential functionality of the hardware and related post-contract customer support, software as a service subscriptions and other services; and (2) software components, such as optional software applications and related items, such as post-contract customer support and other services. The Company then allocates revenue within the non-software category to each element based upon its relative selling price using a hierarchy of vendor-specific objective evidence (“VSOE”), third-party evidence of selling price (“TPE”), or estimated selling prices (“ESP”), if VSOE or TPE does not exist. The Company allocates revenue within the software category to the undelivered elements based upon their fair value using VSOE, with the residual revenue allocated to the delivered elements. If the Company cannot objectively determine the VSOE of the fair value of any undelivered software element, it defers revenue for all software components until all elements are delivered and services have been performed, until fair value can objectively be determined for any remaining undelivered elements, or until software maintenance is the only undelivered element, in which case revenue is recognized over the maintenance term for all software elements.

- added (2016-12-09):
[0001571996-16-000021:note_history:156]
The Company allocates the amount of revenue recognized for delivered elements to the amount that is not subject to forfeiture or refund or contingent on the future delivery of products or services.

- added (2016-12-09):
[0001571996-16-000021:note_history:157]
Customers under software maintenance agreements are entitled to receive updates and upgrades on a when-and-if-available basis, and various types of technical support based on the level of support purchased. In the event specific features, functionality, entitlements, or the release version of an upgrade or new product have been announced but not delivered, and customers will receive that upgrade or new product as part of a current software maintenance contract, a specified upgrade is deemed created and product revenues are deferred on purchases made after the announcement date until delivery of the upgrade or new product. The amount and elements to be deferred are dependent on whether the Company has established VSOE of fair value for the upgrade or new product.

- added (2016-12-09):
[0001571996-16-000021:note_history:158]
Other

- added (2016-12-09):
[0001571996-16-000021:note_history:159]
The Company records revenue from the sale of equipment under sales-type leases as product revenue in an amount equal to the present value of minimum lease payments at the inception of the lease.  Sales-type leases also produce financing income, which is included in net revenue in the Condensed Consolidated Statements of Income (Loss) and is recognized at consistent rates of return over the lease term.  Revenue from operating leases is recognized over the lease period. The Company also offers qualified customers revolving credit lines for the purchase of products and services offered by the Company.  Financing income attributable to these revolving loans is recognized in net revenue on an accrual basis.

- added (2016-12-09):
[0001571996-16-000021:note_history:160]
The Company accrues for the estimated costs of systems’ warranty at the time of sale.  Systems’ warranty costs are estimated based upon historical experience and specific identification of systems’ requirements.

- added (2016-12-09):
[0001571996-16-000021:note_history:161]
The Company reports revenue net of any revenue-based taxes assessed by governmental authorities that are imposed on and concurrent with specific revenue-producing transactions.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2016-12-09):
[0001571996-16-000021:note_history:162]
Dell Software Group Divestiture — On October 31, 2016, the parties closed the DSG divestiture transaction.  Dell received total cash consideration for the sale of approximately $2.4 billion.  The Company expects to realize an estimated pre-tax gain on sale of $1.2 billion.

- added (2016-12-09):
[0001571996-16-000021:note_history:163]
Dell Services Divestiture — On November 2, 2016, the parties closed the Dell Services divestiture transaction.  Dell received total cash consideration for the sale of approximately $3.0 billion. The Company expects to realize an estimated pre-tax gain on sale of $1.5 billion.

- added (2016-12-09):
[0001571996-16-000021:note_history:164]
Repayment and Termination of Asset Sale Bridge Facility — On November 8, 2016, the Company applied cash proceeds from the sale of substantially all of the Company’s Dell Services business unit and the sale of substantially all of the Company’s Dell Software Group business unit to repay the outstanding $2.2 billion principal amount of the Asset Sale Bridge Facility without premium or penalty and accrued and unpaid interest thereon, and terminated the Asset Sale Bridge Facility and the Asset Sale Bridge Credit Agreement and related documents.

- added (2016-12-09):
[0001571996-16-000021:note_history:165]
Repayment of Term Loan A-1 Facility — On November 8, 2016, the Company applied cash proceeds from the sale of substantially all of the Company’s Dell Services business unit and the sale of substantially all of the Company’s Dell Software Group business unit and other cash to repay approximately $2.1 billion principal amount of the Term Loan A-1 Facility without premium or penalty and accrued and unpaid interest thereon.

- added (2016-12-09):
[0001571996-16-000021:note_history:166]
IRS Audit Settlement — On November 9, 2016, the Company effectively settled the IRS audit for fiscal years 2004 through 2006.  The settlement amount payable to the IRS in early 2017 is approximately $545 million and the Company expects to record an income tax benefit of approximately $300 million in the fourth quarter of Fiscal 2017.  However, the Company is currently evaluating the impact of the settlement on its uncertain tax positions; therefore, the actual amount of any tax impact to be recorded in future quarters is still uncertain.

- added (2016-12-09):
[0001571996-16-000021:note_history:167]
Repayment of Revolving Credit Facility — On November 17, 2016, the Company repaid approximately $1 billion principal amount of the Revolving Credit Facility and accrued and unpaid interest thereon.

- changed (2016-12-09):
[0001571996-16-000021:note_history:168]
Other than the items noted above, there were no known events occurring after the balance sheet date and up until the date of the issuance of this report that would materially affect the information presented herein.
  (was, 2016-09-06, similarity 0.7847):
[0001571996-16-000015:note_history:168]
Other than the items noted above, there were no known events occurring after the balance sheet date and up until the date of the issuance of this report that would materially affect the information presented herein.  The Company evaluated subsequent events through September 6, 2016, the date of the issuance of these financial statements.

- removed (2016-12-09):
[0001571996-16-000015:note_history:169]
Effective August 25, 2016, Denali Holding Inc. changed its name to Dell Technologies Inc. by an amendment (the “Amendment”) to its Third Amended and Restated Certificate of Incorporation. The Amendment was approved by the board of directors of the Company, and was filed with the Secretary of State of the State of Delaware on August 25, 2016.

- removed (2016-12-09):
[0001571996-16-000015:note_history:170]
Final regulatory approval from the Chinese Ministry of Commerce was received for the EMC merger transaction.  The condition to closing the transaction in respect of clearances under antitrust and competition laws has been satisfied.  The transaction is expected to close on September 7, 2016.  The EMC merger will be financed with a combination of equity and debt financing and cash on hand.  As of September 6, 2016, the Company obtained an incremental equity financing commitment of $0.15 billion from Silver Lake Partners.
