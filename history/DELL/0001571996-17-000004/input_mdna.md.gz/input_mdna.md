# DELL MD&A — 0001571996-17-000004


## mdna

[0001571996-17-000004:mdna:1]
ITEM 7 — MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF

[0001571996-17-000004:mdna:2]
OPERATIONS

[0001571996-17-000004:mdna:3]
Unless otherwise indicated, all results presented are prepared in a manner that complies, in all material respects, with accounting principles generally accepted in the United States of America ("GAAP").  Additionally, unless otherwise indicated, all changes identified for the current-period results represent comparisons to results for the prior corresponding fiscal period.

[0001571996-17-000004:mdna:4]
Our fiscal year is the 52- or 53-week period ending on the Friday nearest January 31.  We refer to our fiscal years ended February 3, 2017, January 29, 2016, and January 30, 2015 as "Fiscal 2017," "Fiscal 2016," and "Fiscal 2015," respectively.  Fiscal 2016 and Fiscal 2015 included 52 weeks.  Fiscal 2017 included 53 weeks, with the extra week included in the fourth quarter of Fiscal 2017.

[0001571996-17-000004:mdna:5]
On September 7, 2016, we completed our acquisition by merger of EMC Corporation.  The consolidated results of EMC are included in Dell Technologies' consolidated results for the Fiscal 2017 periods presented.  Revenues of approximately $9.2 billion and net loss of approximately $2.1 billion attributable to EMC were included in the Consolidated Statements of Income (Loss) for the period from September 7, 2016 through February 3, 2017.

[0001571996-17-000004:mdna:6]
During Fiscal 2017, we closed the Dell Services, DSG, and ECD divestiture transactions.  We received total cash consideration of approximately $7.0 billion from the divestitures and recorded a gain on sale, net of tax, of approximately $1.9 billion.  Accordingly, the results of operations of Dell Services, DSG, and ECD, as well as the related gains or losses on sale, have been excluded from the results of continuing operations in the periods presented in this management's discussion and analysis, except as otherwise indicated.

[0001571996-17-000004:mdna:7]
INTRODUCTION

[0001571996-17-000004:mdna:8]
Dell Technologies is a strategically aligned family of businesses that brings together the entire infrastructure from hardware to software to services — from the edge to the data center to the cloud.  Dell Technologies is a leader in the traditional technology of today and a leader in the cloud-native infrastructure of tomorrow.  We are a leading provider of scalable IT solutions enabling customers to be more efficient, mobile, informed, and secure.  Through our recent combination with EMC, Dell Technologies now encompasses the businesses of Dell, which includes our Client Solutions Group, Dell EMC, which includes our Infrastructure Solutions Group, VMware, Pivotal, RSA, and SecureWorks.  We are focused on providing technology solutions and services that accelerate digital transformation.  We believe technology exists to drive human progress on a global scale — to create new markets, reshape industries, and improve lives.  We are positioned to help customers of any size build the essential infrastructure to modernize IT and enable digital business, and are differentiated by our practical innovation and efficient, simple, and affordable solutions.

[0001571996-17-000004:mdna:9]
Dell Technologies is committed to our customers.  We believe our products, solutions, and services will help power digital transformation.  As we innovate to make our customers' existing IT increasingly productive, we help them reinvest their savings into the next generation of technologies that they need to succeed in the digital economy.  Our next-generation solutions which enable digital transformation include software-defined data centers, all flash arrays, hybrid cloud, converged and hyper-converged infrastructure, mobile, and security solutions.  In addition, our extended warranty and delivery offerings, and software and peripherals, which are closely tied to the sale of our hardware products, are important value differentiators that we are able to offer our customers.

[0001571996-17-000004:mdna:10]
We believe the combined strength of Dell and EMC will benefit our customers through complementary product portfolios, sales teams, and research and development strategies.  We are actively working on the integration of EMC acquired businesses, including developing a combined go-to-market strategy.  During this period of transition and integration, we remain focused on supporting our customers with outstanding solutions, products, and services.  We will continue our focus on building superior customer relationships through our direct model and our network of channel partners, which includes value-added resellers,

[0001571996-17-000004:mdna:11]
system integrators, distributors, and retailers.  We also will continue investing in strategic solutions and enhancing our go-to-market sales and marketing capabilities as we seek to create a leading global technology company poised for long-term sustainable growth and innovation.

[0001571996-17-000004:mdna:12]
As we stay focused on our customers, we will pursue the following strategic initiatives:

[0001571996-17-000004:mdna:13]
| • | To extend our market leading position through our Client and Infrastructure Solutions Groups offerings |

[0001571996-17-000004:mdna:14]
| • | To grow our strong position in IT infrastructure for cloud-native workloads, both on- and off-premises |

[0001571996-17-000004:mdna:15]
| • | To innovate with winning technology that spans and unites on- and off-premises applications and infrastructure and that enables workforce transformation required by our customers |

[0001571996-17-000004:mdna:16]
As part of this strategy, we may supplement organic growth with strategic investments and disciplined acquisitions targeting businesses that will complement our existing portfolio of solutions.

[0001571996-17-000004:mdna:17]
We operate a diversified business model with the majority of our net revenue and operating income derived from commercial clients that consist of large enterprises, small and medium-sized businesses, and public sector customers.

[0001571996-17-000004:mdna:18]
Products and Services

[0001571996-17-000004:mdna:19]
We design, develop, manufacture, market, sell and support a wide range of products and services.  We are organized into the following business units, which are our reportable segments: Client Solutions Group; Infrastructure Solutions Group; and VMware.  Due to our divestitures of Dell Services, Dell Software Group, and Dell EMC Enterprise Content Division, the results of these businesses, as well as the related gains or losses on sale, have been excluded from this management's discussion and analysis for all periods presented, except as otherwise indicated.  See "Divestitures" below for more information regarding the sale of Dell Services, Dell Software Group, and ECD.

[0001571996-17-000004:mdna:20]
| • | Client Solutions Group (CSG) — Offerings by CSG (formerly referred to as Client Solutions) include branded hardware, such as desktop PCs, notebooks, and tablets, and branded peripherals, such as monitors, printers, and projectors. CSG also offers attached software, peripherals and services, including support and deployment, configuration, and extended warranty services. |

[0001571996-17-000004:mdna:21]
Approximately 50% of CSG revenue is generated by sales to customers in the Americas, with the remaining portion derived from sales to customers in EMEA and APJ.

[0001571996-17-000004:mdna:22]
| • | Infrastructure Solutions Group (ISG) — EMC's Information Storage segment and our existing Enterprise Solutions Group were merged to create the Infrastructure Solutions Group, or ISG. The comprehensive portfolio of advanced storage solutions includes traditional storage solutions as well as next-generation storage solutions (including all flash arrays, scale-out file and object platforms). The server portfolio includes high-performance rack, blade, tower, and hyperscale servers. The networking portfolio will help our business customers transform and modernize their infrastructure, mobilize and enrich end-user experiences, and accelerate business applications and processes. Similar to CSG, ISG also offers attached software, peripherals, and services, including support and deployment, configuration, and extended warranty services. |

[0001571996-17-000004:mdna:23]
Approximately 50% of ISG revenue is generated by sales to customers in the Americas, with the remaining portion derived from sales to customers in EMEA and APJ.

[0001571996-17-000004:mdna:24]
| • | VMware — The VMware reportable segment ("VMware") reflects the operations of VMware, Inc. (NYSE: VMW) within Dell Technologies. See Exhibit 99.1 filed with this report for further details on the differences between VMware reportable segment results and VMware, Inc. results. |

[0001571996-17-000004:mdna:25]
VMware is a leader in virtualization and cloud infrastructure solutions, which enable organizations to manage IT resources across complex multi-cloud, multi-device environments.  VMware offers a broad portfolio of virtualization technologies across three main product groups: software-defined data center; hybrid cloud computing; and end-user computing.

[0001571996-17-000004:mdna:26]
Approximately half of VMware revenue is generated by sales to customers in the United States.

[0001571996-17-000004:mdna:27]
45

[0001571996-17-000004:mdna:28]
Our other businesses, described below, consist of product and service offerings of RSA Information Security, SecureWorks, Pivotal, and Boomi.  These businesses are not classified as reportable segments, either individually or collectively, as the results of the businesses are not material to our overall results and the businesses do not meet the criteria for reportable segments.

[0001571996-17-000004:mdna:29]
| • | RSA Information Security provides essential cybersecurity solutions engineered to enable organizations to detect, investigate, and respond to advanced attacks, confirm and manage identities, and, ultimately, help reduce IP theft, fraud, and cybercrime. |

[0001571996-17-000004:mdna:30]
| • | SecureWorks (NASDAQ: SCWX) is a leading global provider of intelligence-driven information security solutions singularly focused on protecting its clients from cyber attacks. |

[0001571996-17-000004:mdna:31]
| • | Pivotal is a leading provider of application and data infrastructure software, agile development services, and data science consulting. Pivotal's cloud-native platform enables leading companies to transform their operations with an approach that is focused on building software, rather than buying it. |

[0001571996-17-000004:mdna:32]
| • | Boomi specializes in cloud-based integration, connecting information between existing on-premise and cloud-based applications to ensure business processes are optimized, data is accurate and workflow is reliable. |

[0001571996-17-000004:mdna:33]
See Note 22 of the Notes to the Consolidated Financial Statements included in this report for more information about our other businesses.

[0001571996-17-000004:mdna:34]
For further discussion regarding our current reportable segments, see "Results of Operations — Business Unit Results."

[0001571996-17-000004:mdna:35]
Dell Financial Services

[0001571996-17-000004:mdna:36]
We also offer or arrange various financing options and services for our commercial and consumer customers in the United States, Canada, Europe, and Mexico through Dell Financial Services ("DFS") and its affiliates.  DFS services include originating, collecting, and servicing customer receivables primarily related to the purchase of Dell Technologies products.  The results of these operations are allocated to our segments based on the underlying product or service financed.  For additional information about our financing arrangements, see Note 7 of the Notes to the Consolidated Financial Statements included in this report

[0001571996-17-000004:mdna:37]
Business Trends and Challenges

[0001571996-17-000004:mdna:38]
We are seeing an unprecedented rate of change in the IT industry.  Organizations of all kinds are embracing digital technology to achieve their business objectives.  Our vision is to be the essential infrastructure company and leader in end-user computing, data center infrastructure solutions, virtualization, and cloud software that our customers continue to trust and rely on for their IT solutions.  We accelerate results for our customers by enabling them to be more efficient, mobile, informed, and secure.  We continue to invest in R&D, sales, and other key areas of our business to deliver superior products and solutions capabilities and to drive execution of long-term profitable growth.  We believe that our results will benefit from an integrated go-to-market strategy and the result of our differentiated products and solutions capabilities.  We intend to continue to execute on our business model and seek to balance liquidity, profitability, and growth to position our company for long-term success.

[0001571996-17-000004:mdna:39]
We are able to leverage our traditional strength in the PC market to offer solutions and services that provide higher value recurring revenue streams.  Given the macroeconomic environment and computing trends, we expect that the demand environment will continue to be uneven and cyclical and that market competition in our Client Solutions Group business will intensify.  However, we are committed to a long-term growth strategy that we believe will benefit from the consolidation trends that are occurring in our markets.  Our Client Solutions Group offerings remain an important element of our strategy, generating strong cash flow and opportunities for cross-selling of complementary solutions.

[0001571996-17-000004:mdna:40]
We expect that our Infrastructure Solutions Group will continue to be adversely affected by declines in the traditional storage and server markets.  Cloud-native applications are expected to continue as a primary growth driver in the infrastructure market as IT organizations increasingly become multi-cloud environments.  We believe the complementary cloud solutions across our business, created through our combination with EMC, strongly position us to meet these demands for our customers who are increasingly looking to leverage cloud-based computing.  Further, we will be able to provide new and more robust storage and data center solutions to meet the evolving needs of our customers.  We also continue to be impacted by the emerging trends of enterprises deploying software-defined storage, hyper-converged, and modular solutions based on server-centric architectures.

[0001571996-17-000004:mdna:41]
We have leading solutions in these categories through our Dell EMC and VMware data center offerings.  In addition, through our research and development efforts, we expect to develop new solutions in this rapidly changing industry that we believe will enable us to continue to provide superior solutions to our customers.

[0001571996-17-000004:mdna:42]
We manage our business on a U.S. dollar basis.  However, we have a large global presence, generating approximately 50% of our revenue by sales to customers outside of the United States during Fiscal 2017 and Fiscal 2016.  Our revenues, therefore, can be impacted by fluctuations in foreign currency exchange rates.  We utilize a comprehensive hedging strategy intended to mitigate the impact of foreign currency volatility over time, and we adjust pricing when possible to further minimize foreign currency impacts.  The percentage of our revenues generated in regions outside of the United States did not change substantially as a result of the EMC merger transaction.

[0001571996-17-000004:mdna:43]
EMC Merger Transaction

[0001571996-17-000004:mdna:44]
As described in Note 1 and Note 3 of the Notes to the Consolidated Financial Statements included in this report, on September 7, 2016, a merger subsidiary of Dell Technologies merged with and into EMC Corporation, with EMC Corporation surviving the merger as a wholly-owned subsidiary of Dell Technologies.

[0001571996-17-000004:mdna:45]
At the effective time of the EMC merger transaction, each share of EMC common stock issued and outstanding immediately prior to the effective time of the EMC merger transaction (other than shares owned by Dell Technologies, our merger subsidiary, EMC, or any of EMC's wholly-owned subsidiaries, and other than shares with respect to which EMC's shareholders are entitled to and properly exercise appraisal rights) was converted into the right to receive the merger consideration, consisting of (1) $24.05 in cash, without interest, and (2) 0.11146 validly issued, fully paid and non-assessable shares of common stock of Dell Technologies designated as Class V Common Stock equal to the quotient (rounded to the nearest five decimal points) obtained by dividing (A) 222,966.450 by (B) the aggregate number of shares of EMC common stock issued and outstanding immediately prior to the effective time of the EMC merger transaction, plus cash in lieu of any fractional shares.

[0001571996-17-000004:mdna:46]
Each currently outstanding EMC stock option vested and became fully exercisable prior to 11:59 p.m., New York City time, on the last trading day prior to the effective time of the EMC merger transaction, referred to as the vesting effective time of the merger.  Each EMC stock option that remained outstanding immediately prior to the vesting effective time of the merger was automatically exercised immediately prior to the vesting effective time of the merger on a net exercise basis, such that shares of EMC common stock with a value equal to the aggregate exercise price and applicable tax withholding reduced the number of shares of EMC common stock otherwise issuable.  Except for any restricted stock units that were granted following the date of the merger agreement and that continued in effect as cash awards following the effective time of the EMC merger transaction, each EMC restricted stock unit outstanding immediately prior to the vesting effective time of the merger became fully vested immediately prior to the vesting effective time of the merger (with performance vesting units vesting at the target level of performance) and the holder hereof became entitled to receive the merger consideration with respect to the shares of EMC common stock subject to the award (which was calculated net of the number of shares withheld in respect of taxes upon the vesting of the award).

[0001571996-17-000004:mdna:47]
In connection with the EMC merger transaction and in accordance with the merger agreement, certain executives holding unvested restricted stock units of EMC, or EMC RSUs, were given the opportunity to elect to exchange each unvested EMC RSU held by such executives that would otherwise have vested in the ordinary course on or after January 1, 2017 for (a) a deferred cash award having a cash value equal to the closing price of a share of EMC common stock on the last trading day before the closing date of the EMC merger transaction, or $29.05, and (b) an option, referred to as a rollover option, to purchase a share of Class C Common Stock of Dell Technologies, referred to as the rollover opportunity.  The rollover options have a three-year term and a per share exercise price equal to the fair market value of a share of Class C Common Stock on the date of grant, or $27.50, and, to the extent vested, may be exercised using a cashless exercise method for both the exercise price and the applicable minimum required tax withholding (subject to certain limitations).  Each deferred cash award will vest, and each rollover option will vest and thereby become exercisable, on the same schedule as the EMC RSU for which they were exchanged (with any performance-vesting condition deemed satisfied at the target level of performance upon the closing of the EMC merger transaction).  We issued, pursuant to the rollover opportunity, options to purchase 1,779,072 shares of Class C Common Stock.

[0001571996-17-000004:mdna:48]
In addition, in connection with the EMC merger transaction and in accordance with the merger agreement, certain EMC executives were given the opportunity to purchase, for cash and at fair market value, shares of Class C Common Stock.  We issued, pursuant to this cash investment opportunity, 152,724 shares of Class C Common Stock, for a purchase price equal to $27.50 per share, resulting in aggregate cash consideration to us of approximately $4.2 million.

[0001571996-17-000004:mdna:49]
47

[0001571996-17-000004:mdna:50]
In connection with the EMC merger transaction, all principal, accrued but unpaid interest, fees, and other amounts (other than certain contingent obligations) outstanding at the effective time of the EMC merger transaction under EMC's unsecured revolving credit facility, Dell's asset-based revolving credit facility, and Dell's term facilities were repaid in full substantially concurrently with the closing, and all commitments to lend and guarantees and security interests, as applicable, in connection therewith were terminated or released.  The aggregate amounts of principal, interest, and premium necessary to redeem in full the outstanding $1.4 billion in aggregate principal amount of 5.625% Senior First Lien Notes due 2020 co-issued by Dell International and Denali Finance Corp. were deposited with the trustee for such notes, and such notes were thereby satisfied and discharged, substantially concurrently with the effective time of the EMC merger transaction.  All of Dell's other outstanding senior notes and all of EMC's outstanding senior notes remained outstanding after the effective time of the EMC merger transaction in accordance with their respective terms.

[0001571996-17-000004:mdna:51]
Dell Technologies financed the EMC merger transaction, repayment of the foregoing indebtedness of EMC and Dell outstanding as of the closing of the EMC merger transaction, and the payment of related fees and expenses with debt financing arrangements in an aggregate principal amount of approximately $45.9 billion, equity financing arrangements of approximately $4.4 billion, and cash on hand of approximately $7.8 billion.

[0001571996-17-000004:mdna:52]
See Note 3, Note 5, and Note 8 to the Consolidated Financial Statements included in this report for additional information regarding the EMC merger transaction and the related financing transactions.

[0001571996-17-000004:mdna:53]
Divestitures

[0001571996-17-000004:mdna:54]
Dell Services Divestiture — On March 27, 2016, Dell Inc. entered into a definitive agreement with NTT Data International L.L.C. to divest substantially all of Dell Services.  On November 2, 2016, the parties closed substantially all of the transaction.  At the completion of the sale, we received total cash consideration of approximately $3.0 billion, resulting in a gain on sale, net of tax, of approximately $1.7 billion.

[0001571996-17-000004:mdna:55]
Dell Software Group Divestiture — On June 19, 2016, Dell Inc. entered into a definitive agreement with Francisco Partners and Elliot Management Corporation to divest substantially all of DSG.  On October 31, 2016, the parties closed the transaction.  At the completion of the sale, we received total cash consideration of approximately $2.4 billion, resulting in a gain on sale, net of tax, of approximately $0.6 billion.

[0001571996-17-000004:mdna:56]
ECD Divestiture — On September 12, 2016, EMC Corporation entered into a definitive agreement with OpenText Corporation to divest the Dell EMC Enterprise Content Division.  On January 23, 2017, the parties closed the transaction.  At the completion of the sale, we received total cash consideration of approximately $1.6 billion, resulting in a loss on sale, net of tax, of approximately $0.4 billion.

[0001571996-17-000004:mdna:57]
Discontinued Operations Presentation — The results of Dell Services, DSG, and ECD, as well as the related gains or losses on sale, are presented as discontinued operations in our Consolidated Statements of Income (Loss), and as such, have been excluded from both continuing operations and segment results for all periods presented, except as otherwise indicated.  Further, we have reclassified the related assets and liabilities as held for sale in our Consolidated Statements of Financial Position as of January 29, 2016.  See Note 4 of the Notes to the Consolidated Financial Statements included in this report for additional information regarding these discontinued operations.

[0001571996-17-000004:mdna:58]
Going-Private Transaction

[0001571996-17-000004:mdna:59]
On October 29, 2013, Dell was acquired by Dell Technologies in a merger transaction pursuant to an agreement and plan of merger, dated as of February 5, 2013, as amended.  Dell Technologies is a Delaware corporation owned by Michael S. Dell, a separate property trust for the benefit of Mr. Dell's wife, investment funds affiliated with Silver Lake Partners (a global private equity firm), investment funds affiliated with MSD Partners, L.P., members of Dell's management, and other investors.  Mr. Dell serves as Chairman and Chief Executive Officer of Dell Technologies and Dell.

[0001571996-17-000004:mdna:60]
48

[0001571996-17-000004:mdna:61]
NON-GAAP FINANCIAL MEASURES

[0001571996-17-000004:mdna:62]
In this management's discussion and analysis we use supplemental measures of our performance which are derived from our consolidated financial information but which are not presented in our consolidated financial statements prepared in accordance with accounting principles generally accepted in the United States of America, or GAAP.  These non-GAAP financial measures include non-GAAP product net revenue; non-GAAP services net revenue; non-GAAP net revenue; non-GAAP product gross margin; non-GAAP services gross margin; non-GAAP gross margin; non-GAAP operating expenses; non-GAAP operating income; non-GAAP net income from continuing operations; earnings before interest and other, net, taxes, depreciation and amortization, referred to as EBITDA; and adjusted EBITDA.

[0001571996-17-000004:mdna:63]
We use non-GAAP financial measures to supplement financial information presented on a GAAP basis.  We believe that excluding certain items from our GAAP results allows management to better understand our consolidated financial performance from period to period and better project our future consolidated financial performance as forecasts are developed at a level of detail different from that used to prepare GAAP-based financial measures.  Moreover, we believe these non-GAAP financial measures provide our stakeholders with useful information to help them evaluate our operating results by facilitating an enhanced understanding of our operating performance and enabling them to make more meaningful period to period comparisons.

[0001571996-17-000004:mdna:64]
There are limitations to the use of the non-GAAP financial measures presented in this report.  Our non-GAAP financial measures may not be comparable to similarly titled measures of other companies.  Other companies, including companies in our industry, may calculate non-GAAP financial measures differently than we do, limiting the usefulness of those measures for comparative purposes.

[0001571996-17-000004:mdna:65]
Non-GAAP product net revenue, non-GAAP services net revenue, non-GAAP net revenue, non-GAAP product gross margin, non-GAAP services gross margin, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, and non-GAAP net income from continuing operations, as defined by us, exclude the impact of purchase accounting, amortization of intangible assets, transaction-related expenses, other corporate expenses, and for non-GAAP net income, an aggregate adjustment for income taxes.  As the excluded items have a material impact on our financial results, our management compensates for this limitation by relying primarily on our GAAP results and using non-GAAP financial measures supplementally or for projections when comparable GAAP financial measures are not available.  The non-GAAP financial measures are not meant to be considered as indicators of performance in isolation from or as a substitute for net revenue, gross margin, operating expenses, operating income, or net income prepared in accordance with GAAP, and should be read only in conjunction with financial information presented on a GAAP basis.

[0001571996-17-000004:mdna:66]
Reconciliations of each non-GAAP financial measure to its most directly comparable GAAP financial measure are presented below.  We encourage you to review the reconciliations in conjunction with the presentation of the non-GAAP financial measures for each of the periods presented.  See the discussion below for more information on each of the excluded items as well as our reasons for excluding them from our non-GAAP results.  In future fiscal periods, we may exclude such items and may incur income and expenses similar to these excluded items.  Accordingly, the exclusion of these items and other similar items in our non-GAAP presentation should not be interpreted as implying that these items are non-recurring, infrequent, or unusual.

[0001571996-17-000004:mdna:67]
The following is a summary of the items excluded from the most comparable GAAP financial measures to calculate our non-GAAP financial measures:

[0001571996-17-000004:mdna:68]
| • | Impact of Purchase Accounting — The impact of purchase accounting includes purchase accounting adjustments, related to the EMC merger transaction and the going-private transaction, recorded under the acquisition method of accounting in accordance with the accounting guidance for business combinations. This guidance prescribes that the purchase price be allocated to assets acquired and liabilities assumed based on the estimated fair value of such assets and liabilities on the date of the transaction. Accordingly, all of the assets and liabilities acquired in the EMC merger transaction and the going-private transaction were accounted for and recognized at fair value as of the respective transaction dates, and the fair value adjustments are being amortized over the estimated useful lives in the periods following the transactions. The fair value adjustments primarily relate to deferred revenue, inventory, and property, plant, and equipment. The purchase accounting adjustments and related amortization of those adjustments are reflected in our GAAP results; however, we evaluate the operating results of the underlying businesses on a non-GAAP basis, after removing such adjustments. We believe that excluding the impact of purchase accounting provides results that are useful in understanding our current operating performance and provides more meaningful comparisons to our past operating performance. |

[0001571996-17-000004:mdna:69]
| • | Amortization of Intangible Assets — Amortization of intangible assets primarily consists of amortization of customer relationships, developed technology, and trade names. In connection with the EMC merger transaction and the going-private transaction, all of the tangible and intangible assets and liabilities of EMC and Dell, respectively, were accounted for and recognized at fair value on the transaction dates. Accordingly, for the periods presented, amortization of intangible assets represents amortization associated with intangible assets recognized in connection with the EMC merger transaction and the going-private transaction. Amortization charges for purchased intangible assets are significantly impacted by the timing and magnitude of our acquisitions, and these charges may vary in amount from period to period. We exclude these charges for purposes of calculating the non-GAAP financial measures presented below to facilitate a more meaningful evaluation of our current operating performance and comparisons to our past operating performance. |

[0001571996-17-000004:mdna:70]
| • | Transaction-related Expenses — Transaction-related expenses, which primarily consist of legal, banking, consulting, and advisory services as well as certain compensatory retention awards directly related to the EMC merger transaction and related integration, are expensed as incurred. During Fiscal 2017, transaction-related expenses included $807 million in day one stock-based compensation charges primarily related to the acceleration of vesting of EMC stock options and related taxes incurred in connection with the EMC merger transaction. During Fiscal 2017, substantially all transaction-related expenses related to the EMC merger transaction. Although not material in the periods presented, we anticipate that integration costs will increase in the next twelve months, primarily as the result of the integration of processes and systems of the EMC acquired businesses. |

[0001571996-17-000004:mdna:71]
| • | Other Corporate Expenses — Other corporate expenses consists of severance and facility action costs, primarily related to severance and benefits for employees terminated pursuant to cost savings initiatives, and stock-based compensation expense associated with equity awards. Although not material in the periods presented, we expect facility action costs to increase in the next twelve months due to our plan to integrate owned and leased facilities, as we seek opportunities for operational efficiencies and cost savings. Other corporate expenses vary from period to period and are significantly impacted by the timing and nature of these events. Therefore, although we may incur these types of expenses in the future, we believe that eliminating these charges for purposes of calculating the non-GAAP financial measures presented below facilitates a more meaningful evaluation of our current operating performance and comparisons to our past operating performance. |

[0001571996-17-000004:mdna:72]
| • | Aggregate Adjustment for Income Taxes — The aggregate adjustment for income taxes is the estimated combined income tax effect for the adjustments described above. During Fiscal 2017, this category also includes tax charges of approximately $201 million on previously untaxed earnings of a foreign subsidiary that will no longer be permanently reinvested as a result of the Dell Services and DSG divestitures. The tax effects are determined based on the tax jurisdictions where the above items were incurred. |

[0001571996-17-000004:mdna:73]
50

[0001571996-17-000004:mdna:74]
The table below presents a reconciliation of each non-GAAP financial measure to the most directly comparable GAAP measure for each of the periods presented:

[0001571996-17-000004:mdna:75]
|  | Fiscal Year Ended |
|  | February 3, 2017 |  | % Change |  | January 29, 2016 |  | % Change |  | January 30, 2015 |
|  | (in millions, except percentages) |
| Product net revenue | $ | 48,706 |  |  | 14 | % |  | $ | 42,742 |  |  | (7 | )% |  | $ | 46,130 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 300 |  |  |  |  |  | (27 | ) |  |  |  |  | (107 | ) |
| Non-GAAP product net revenue | $ | 49,006 |  |  | 15 | % |  | $ | 42,715 |  |  | (7 | )% |  | $ | 46,023 |  |
| Services net revenue | $ | 12,936 |  |  | 58 | % |  | $ | 8,169 |  |  | 2 | % |  | $ | 8,012 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 880 |  |  |  |  |  | 486 |  |  |  |  |  | 843 |  |
| Non-GAAP services net revenue | $ | 13,816 |  |  | 60 | % |  | $ | 8,655 |  |  | (2 | )% |  | $ | 8,855 |  |
| Net revenue | $ | 61,642 |  |  | 21 | % |  | $ | 50,911 |  |  | (6 | )% |  | $ | 54,142 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 1,180 |  |  |  |  |  | 459 |  |  |  |  |  | 736 |  |
| Non-GAAP net revenue | $ | 62,822 |  |  | 22 | % |  | $ | 51,370 |  |  | (6 | )% |  | $ | 54,878 |  |
| Product gross margin | $ | 6,537 |  |  | 26 | % |  | $ | 5,179 |  |  | (14 | )% |  | $ | 6,046 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 1,104 |  |  |  |  |  | 30 |  |  |  |  |  | (11 | ) |
| Amortization of intangibles | 1,652 |  |  |  |  |  | 392 |  |  |  |  |  | 386 |  |
| Transaction-related expenses | 24 |  |  |  |  |  | 1 |  |  |  |  |  | 3 |  |
| Other corporate expenses | 29 |  |  |  |  |  | 9 |  |  |  |  |  | 21 |  |
| Non-GAAP product gross margin | $ | 9,346 |  |  | 67 | % |  | $ | 5,611 |  |  | (13 | )% |  | $ | 6,445 |  |
| Services gross margin | $ | 6,422 |  |  | 100 | % |  | $ | 3,208 |  |  | 13 | % |  | $ | 2,850 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 903 |  |  |  |  |  | 482 |  |  |  |  |  | 822 |  |
| Amortization of intangibles | 1 |  |  |  |  |  | — |  |  |  |  |  | — |  |
| Transaction-related expenses | 19 |  |  |  |  |  | 5 |  |  |  |  |  | 1 |  |
| Other corporate expenses | 128 |  |  |  |  |  | 1 |  |  |  |  |  | 8 |  |
| Non-GAAP services gross margin | $ | 7,473 |  |  | 102 | % |  | $ | 3,696 |  |  | — | % |  | $ | 3,681 |  |
| Gross margin | $ | 12,959 |  |  | 55 | % |  | $ | 8,387 |  |  | (6 | )% |  | $ | 8,896 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 2,007 |  |  |  |  |  | 512 |  |  |  |  |  | 811 |  |
| Amortization of intangibles | 1,653 |  |  |  |  |  | 392 |  |  |  |  |  | 386 |  |
| Transaction-related expenses | 43 |  |  |  |  |  | 6 |  |  |  |  |  | 4 |  |
| Other corporate expenses | 157 |  |  |  |  |  | 10 |  |  |  |  |  | 29 |  |
| Non-GAAP gross margin | $ | 16,819 |  |  | 81 | % |  | $ | 9,307 |  |  | (8 | )% |  | $ | 10,126 |  |

[0001571996-17-000004:mdna:76]
51

[0001571996-17-000004:mdna:77]
|  | Fiscal Year Ended |
|  | February 3, 2017 |  | % Change |  | January 29, 2016 |  | % Change |  | January 30, 2015 |
|  | (in millions, except percentages) |
| Operating expenses | $ | 16,211 |  |  | 82 | % |  | $ | 8,901 |  |  | (3 | )% |  | $ | 9,212 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | (287 | ) |  |  |  |  | (92 | ) |  |  |  |  | (77 | ) |
| Amortization of intangibles | (2,028 | ) |  |  |  |  | (1,577 | ) |  |  |  |  | (1,698 | ) |
| Transaction-related expenses | (1,445 | ) |  |  |  |  | (103 | ) |  |  |  |  | (72 | ) |
| Other corporate expenses | (745 | ) |  |  |  |  | (47 | ) |  |  |  |  | (56 | ) |
| Non-GAAP operating expenses | $ | 11,706 |  |  | 65 | % |  | $ | 7,082 |  |  | (3 | )% |  | $ | 7,309 |  |
| Operating loss | $ | (3,252 | ) |  | (533 | )% |  | $ | (514 | ) |  | (63 | )% |  | $ | (316 | ) |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 2,294 |  |  |  |  |  | 604 |  |  |  |  |  | 888 |  |
| Amortization of intangibles | 3,681 |  |  |  |  |  | 1,969 |  |  |  |  |  | 2,084 |  |
| Transaction-related expenses | 1,488 |  |  |  |  |  | 109 |  |  |  |  |  | 76 |  |
| Other corporate expenses | 902 |  |  |  |  |  | 57 |  |  |  |  |  | 85 |  |
| Non-GAAP operating income | $ | 5,113 |  |  | 130 | % |  | $ | 2,225 |  |  | (21 | )% |  | $ | 2,817 |  |
| Net loss from continuing operations | $ | (3,737 | ) |  | (220 | )% |  | $ | (1,168 | ) |  | (5 | )% |  | $ | (1,108 | ) |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 2,294 |  |  |  |  |  | 604 |  |  |  |  |  | 894 |  |
| Amortization of intangibles | 3,681 |  |  |  |  |  | 1,969 |  |  |  |  |  | 2,084 |  |
| Transaction-related expenses | 1,485 |  |  |  |  |  | 83 |  |  |  |  |  | 69 |  |
| Other corporate expenses | 902 |  |  |  |  |  | 77 |  |  |  |  |  | 85 |  |
| Aggregate adjustment for income taxes | (1,938 | ) |  |  |  |  | (512 | ) |  |  |  |  | (620 | ) |
| Non-GAAP net income from continuing operations | $ | 2,687 |  |  | 155 | % |  | $ | 1,053 |  |  | (25 | )% |  | $ | 1,404 |  |

[0001571996-17-000004:mdna:78]
In addition to the above measures, we also use EBITDA and adjusted EBITDA to provide additional information for evaluation of our operating performance.  Adjusted EBITDA excludes purchase accounting adjustments related to the EMC merger transaction and the going-private transaction, acquisition, integration, and divestiture-related costs, severance and facility actions, and stock-based compensation expense.  We believe that, due to the non-operational nature of the purchase accounting entries, it is appropriate to exclude these adjustments.

[0001571996-17-000004:mdna:79]
As is the case with the non-GAAP measures presented above, users should consider the limitations of using EBITDA and adjusted EBITDA, including the fact that those measures do not provide a complete measure of our operating performance.  EBITDA and adjusted EBITDA do not purport to be alternatives to net income (loss) as measures of operating performance or to cash flows from operating activities as a measure of liquidity.  In particular, EBITDA and adjusted EBITDA are not intended to be a measure of free cash flow available for management's discretionary use, as these measures do not consider certain cash requirements, such as working capital needs, capital expenditures, contractual commitments, interest payments, tax payments, and other debt service requirements.

[0001571996-17-000004:mdna:80]
The table below presents a reconciliation of EBITDA and adjusted EBITDA to net loss from continuing operations for the periods presented:

[0001571996-17-000004:mdna:81]
|  | Fiscal Year Ended |
|  | February 3, 2017 |  | % Change |  | January 29, 2016 |  | % Change |  | January 30, 2015 |
|  | (in millions, except percentages) |
| Net loss from continuing operations | $ | (3,737 | ) |  | (220 | )% |  | $ | (1,168 | ) |  | (5 | )% |  | $ | (1,108 | ) |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Interest and other, net (a) | 2,104 |  |  |  |  | 772 |  |  |  |  | 899 |  |
| Income tax benefit | (1,619 | ) |  |  |  | (118 | ) |  |  |  | (107 | ) |
| Depreciation and amortization | 4,840 |  |  |  |  | 2,494 |  |  |  |  | 2,599 |  |
| EBITDA | $ | 1,588 |  |  | (20 | )% |  | $ | 1,980 |  |  | (13 | )% |  | $ | 2,283 |  |
| EBITDA | $ | 1,588 |  |  | (20 | )% |  | $ | 1,980 |  |  | (13 | )% |  | $ | 2,283 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense | 392 |  |  |  |  | 63 |  |  |  |  | 58 |  |
| Impact of purchase accounting (b) | 1,926 |  |  |  |  | 487 |  |  |  |  | 788 |  |
| Transaction-related expenses (c) | 1,525 |  |  |  |  | 83 |  |  |  |  |  | 78 |  |
| Other corporate expenses (d) | 510 |  |  |  |  | 20 |  |  |  |  | 20 |  |
| Adjusted EBITDA | $ | 5,941 |  |  | 126 | % |  | $ | 2,633 |  |  | (18 | )% |  | $ | 3,227 |  |

[0001571996-17-000004:mdna:82]
________________

[0001571996-17-000004:mdna:83]
| (a) | See "Results of Operations — Interest and Other, Net" for more information on the components of interest and other, net. |

[0001571996-17-000004:mdna:84]
| (b) | This amount includes the non-cash purchase accounting adjustments related to the EMC merger transaction and the going-private transaction. |

[0001571996-17-000004:mdna:85]
| (c) | Transaction-related expenses consist of acquisition and integration-related costs. |

[0001571996-17-000004:mdna:86]
| (d) | Consists of severance and facility action costs. |

[0001571996-17-000004:mdna:87]
53

[0001571996-17-000004:mdna:88]
RESULTS OF OPERATIONS

[0001571996-17-000004:mdna:89]
Consolidated Results

[0001571996-17-000004:mdna:90]
The following table summarizes our consolidated results from continuing operations for each of the periods presented.  Unless otherwise indicated, all changes identified for the current-period results represent comparisons to results for the prior corresponding fiscal period.

[0001571996-17-000004:mdna:91]
|  |  | Fiscal Year Ended |
|  |  | February 3, 2017 |  |  |  | January 29, 2016 |  |  |  | January 30, 2015 |
|  |  | Dollars |  | % ofNet Revenue |  | %Change |  | Dollars |  | % ofNet Revenue |  | %Change |  | Dollars |  | % ofNet Revenue |
|  |  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 48,706 |  |  | 79.0 | % |  | 14 | % |  | $ | 42,742 |  |  | 84.0 | % |  | (7 | )% |  | $ | 46,130 |  |  | 85.2 | % |
| Services |  | 12,936 |  |  | 21.0 | % |  | 58 | % |  | 8,169 |  |  | 16.0 | % |  | 2 | % |  | 8,012 |  |  | 14.8 | % |
| Total net revenue |  | $ | 61,642 |  |  | 100.0 | % |  | 21 | % |  | $ | 50,911 |  |  | 100.0 | % |  | (6 | )% |  | $ | 54,142 |  |  | 100.0 | % |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 6,537 |  |  | 13.4 | % |  | 26 | % |  | $ | 5,179 |  |  | 12.1 | % |  | (14 | )% |  | $ | 6,046 |  |  | 13.1 | % |
| Services |  | 6,422 |  |  | 49.6 | % |  | 100 | % |  | 3,208 |  |  | 39.3 | % |  | 13 | % |  | 2,850 |  |  | 35.6 | % |
| Total gross margin |  | $ | 12,959 |  |  | 21.0 | % |  | 55 | % |  | $ | 8,387 |  |  | 16.5 | % |  | (6 | )% |  | $ | 8,896 |  |  | 16.4 | % |
| Operating expenses |  | $ | 16,211 |  |  | 26.3 | % |  | 82 | % |  | $ | 8,901 |  |  | 17.5 | % |  | (3 | )% |  | $ | 9,212 |  |  | 17.0 | % |
| Operating loss |  | $ | (3,252 | ) |  | (5.3 | )% |  | (533 | )% |  | $ | (514 | ) |  | (1.0 | )% |  | (63 | )% |  | $ | (316 | ) |  | (0.6 | )% |
| Net loss from continuing operations |  | $ | (3,737 | ) |  | (6.1 | )% |  | (220 | )% |  | $ | (1,168 | ) |  | (2.3 | )% |  | (5 | )% |  | $ | (1,108 | ) |  | (2.0 | )% |
| Net loss attributable to Dell Technologies Inc. |  | $ | (1,672 | ) |  | (2.7 | )% |  | (51 | )% |  | $ | (1,104 | ) |  | (2.2 | )% |  | 10 | % |  | $ | (1,221 | ) |  | (2.3 | )% |
| Other Financial Information |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 49,006 |  |  | 78.0 | % |  | 15 | % |  | $ | 42,715 |  |  | 83.2 | % |  | (7 | )% |  | $ | 46,023 |  |  | 83.9 | % |
| Services |  | 13,816 |  |  | 22.0 | % |  | 60 | % |  | 8,655 |  |  | 16.8 | % |  | (2 | )% |  | 8,855 |  |  | 16.1 | % |
| Total non-GAAP net revenue |  | $ | 62,822 |  |  | 100.0 | % |  | 22 | % |  | $ | 51,370 |  |  | 100.0 | % |  | (6 | )% |  | $ | 54,878 |  |  | 100.0 | % |
| Non-GAAP gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 9,346 |  |  | 19.1 | % |  | 67 | % |  | $ | 5,611 |  |  | 13.1 | % |  | (13 | )% |  | $ | 6,445 |  |  | 14.0 | % |
| Services |  | 7,473 |  |  | 54.1 | % |  | 102 | % |  | 3,696 |  |  | 42.7 | % |  | — | % |  | 3,681 |  |  | 41.6 | % |
| Total non-GAAP gross margin |  | $ | 16,819 |  |  | 26.8 | % |  | 81 | % |  | $ | 9,307 |  |  | 18.1 | % |  | (8 | )% |  | $ | 10,126 |  |  | 18.5 | % |
| Non-GAAP operating expenses |  | $ | 11,706 |  |  | 18.6 | % |  | 65 | % |  | $ | 7,082 |  |  | 13.8 | % |  | (3 | )% |  | $ | 7,309 |  |  | 13.3 | % |
| Non-GAAP operating income |  | $ | 5,113 |  |  | 8.1 | % |  | 130 | % |  | $ | 2,225 |  |  | 4.3 | % |  | (21 | )% |  | $ | 2,817 |  |  | 5.1 | % |
| Non-GAAP net income from continuing operations |  | $ | 2,687 |  |  | 4.3 | % |  | 155 | % |  | $ | 1,053 |  |  | 2.0 | % |  | (25 | )% |  | $ | 1,404 |  |  | 2.6 | % |
| EBITDA |  | $ | 1,588 |  |  | 2.5 | % |  | (20 | )% |  | $ | 1,980 |  |  | 3.9 | % |  | (13 | )% |  | $ | 2,283 |  |  | 4.2 | % |
| Adjusted EBITDA |  | $ | 5,941 |  |  | 9.5 | % |  | 126 | % |  | $ | 2,633 |  |  | 5.1 | % |  | (18 | )% |  | $ | 3,227 |  |  | 5.9 | % |

[0001571996-17-000004:mdna:92]
Non-GAAP product net revenue, non-GAAP services net revenue, non-GAAP net revenue, non-GAAP product gross margin, non-GAAP services gross margin, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income from continuing operations, EBITDA, and adjusted EBITDA are not measurements of financial performance prepared in accordance with GAAP.  Non-GAAP financial measures as a percentage of revenue are calculated based on non-GAAP net revenue.  See "Non-GAAP Financial Measures" for information about these non-GAAP financial measures, including our reasons for including these measures, material limitations with respect to the usefulness of the measures, and a reconciliation of each non-GAAP financial measure to the most directly comparable GAAP financial measure.

[0001571996-17-000004:mdna:93]
As a result of the EMC merger transaction completed on September 7, 2016 and its impact on Fiscal 2017 results, our results for the fiscal periods discussed below are not directly comparable.

[0001571996-17-000004:mdna:94]
Overview

[0001571996-17-000004:mdna:95]
During Fiscal 2017, our net revenue and non-GAAP net revenue increased 21% and 22%, respectively.  The increase in net revenue and non-GAAP net revenue was attributable to revenue from the EMC acquired businesses, while revenue from our legacy businesses remained relatively unchanged.  The EMC merger transaction had an impact on the mix of revenue contributed by our business units.  CSG net revenue represented approximately 60% of our total net revenue during Fiscal 2017.  In comparison, CSG net revenue represented a higher proportion of our revenue prior to the EMC merger transaction, accounting for approximately 70% of our total net revenue for Fiscal 2016.

[0001571996-17-000004:mdna:96]
During Fiscal 2017 and Fiscal 2016, our operating loss was $3.3 billion and $0.5 billion, respectively.  The increase in our operating loss for Fiscal 2017 was primarily attributable to an increase in purchase accounting adjustments and amortization of intangible assets and an increase in compensation and benefits expense, both related to the EMC merger transaction.  The increases in operating expenses were partially offset by the favorable impact of gross margin from the EMC acquired businesses.

[0001571996-17-000004:mdna:97]
Our operating loss was impacted by purchase accounting adjustments associated with the EMC merger transaction and the going-private transaction, amortization of intangible assets, transaction-related expenses, and other corporate expenses.  In aggregate, these items totaled $8.4 billion and $2.7 billion for Fiscal 2017 and Fiscal 2016, respectively.  Excluding these adjustments, non-GAAP operating income increased 130% to $5.1 billion during Fiscal 2017.  The increase in non-GAAP operating income in Fiscal 2017 was primarily attributable to the favorable impact of non-GAAP operating income from the EMC acquired businesses of $1.5 billion and, to a lesser degree, to higher gross margin from our legacy businesses.

[0001571996-17-000004:mdna:98]
Cash provided by operating activities was $2.2 billion during Fiscal 2017.  Positive operating cash flows were attributable to profitable operations, particularly in the EMC acquired businesses.  During Fiscal 2017, the favorable effects of these factors were offset partially by cash used for transaction-related expenses.  See "Market Conditions, Liquidity, and Capital Commitments" for further information on our cash flow metrics.

[0001571996-17-000004:mdna:99]
Net Revenue

[0001571996-17-000004:mdna:100]
Fiscal 2017 compared to Fiscal 2016

[0001571996-17-000004:mdna:101]
During Fiscal 2017, our net revenue increased 21% due to the favorable impact of net revenue from the EMC acquired businesses of approximately $9.2 billion, partially offset by purchase accounting adjustments of approximately $1.0 billion.  An increase of 2% in CSG net revenue also contributed to higher net revenue during Fiscal 2017.  Our non-GAAP net revenue increased 22% during Fiscal 2017, primarily due to the impact from the EMC acquired businesses.

[0001571996-17-000004:mdna:102]
| • | Product Net Revenue — Product net revenue includes revenue from the sale of hardware products and Dell Technologies-owned software licenses. During Fiscal 2017, product net revenue increased 14% and non-GAAP product net revenue increased 15% primarily due to the impact from the EMC acquired businesses. |

[0001571996-17-000004:mdna:103]
| • | Services Net Revenue — Services net revenue includes revenue from our services offerings, third-party software license sales, and support services related to Dell Technologies-owned software and hardware. During Fiscal 2017, net revenue attributable to these services increased 58% due to the impact from the EMC acquired businesses. Non-GAAP net revenue attributable to services increased 60% during Fiscal 2017. |

[0001571996-17-000004:mdna:104]
See "Business Unit Results" for further information regarding revenue from our products, services, and software offerings.

[0001571996-17-000004:mdna:105]
From a geographical perspective, net revenue generated by sales to customers in all regions increased during Fiscal 2017 primarily as a result of the impact from the EMC acquired businesses.  Our mix of revenues generated in the Americas, EMEA, and APJ did not change substantially as a result of the EMC merger transaction.

[0001571996-17-000004:mdna:106]
55

[0001571996-17-000004:mdna:107]
Fiscal 2016 compared to Fiscal 2015

[0001571996-17-000004:mdna:108]
| • | Product Net Revenue — Product net revenue includes revenue from the sale of hardware products and Dell Technologies-owned software licenses. During Fiscal 2016, product net revenue and non-GAAP product net revenue both decreased 7% due to decreases in revenue from CSG as we experienced an overall decline in demand for desktops and notebooks. Product net revenue for Fiscal 2016 did not benefit from the positive effects of the Windows XP refresh that contributed to product revenue in Fiscal 2015. |

[0001571996-17-000004:mdna:109]
| • | Services Net Revenue — Services net revenue includes revenue from our services offerings, third-party software license sales, and support services related to Dell Technologies-owned software and hardware. During Fiscal 2016, services net revenue increased 2%, which was primarily attributable to the diminishing negative impact of purchase accounting adjustments related to the going-private transaction, which were $0.5 billion in Fiscal 2016, compared to $0.8 billion in Fiscal 2015. During Fiscal 2016, non-GAAP services net revenue decreased 2%, which was attributable to a decrease in sales of our third-party software offerings and post-contract customer support associated with those software offerings. |

[0001571996-17-000004:mdna:110]
See "Business Unit Results" for further information regarding revenue from our products, services, and software offerings.

[0001571996-17-000004:mdna:111]
From a geographical perspective, net revenue decreased in all regions during Fiscal 2016, partially offset by growth in certain emerging markets, including China and India.

[0001571996-17-000004:mdna:112]
Gross Margin

[0001571996-17-000004:mdna:113]
Fiscal 2017 compared to Fiscal 2016

[0001571996-17-000004:mdna:114]
During Fiscal 2017, our total gross margin increased 55% to $13.0 billion, and our gross margin percentage increased 450 basis points to 21.0%.  The increase in our total gross margin was primarily attributable to incremental gross margin of approximately $3.7 billion from the EMC acquired businesses, which had higher gross margin percentages.  Cost favorability in CSG also contributed to the improvement in total gross margin, but to a lesser extent.  The effects of these factors on total gross margin were partially offset by the impact of purchase accounting adjustments and amortization of intangibles related to the EMC merger transaction and the going-private transaction.

[0001571996-17-000004:mdna:115]
Our gross margin for Fiscal 2017 included the effect of $3.7 billion of purchase accounting adjustments and amortization of intangibles related to the EMC merger transaction and the going-private transaction.  In comparison, the impacts of purchase accounting adjustments and amortization of intangibles were $0.9 billion in Fiscal 2016, and in this period related only to the going-private transaction.  During Fiscal 2017, our total non-GAAP gross margin increased 81% to $16.8 billion and our non-GAAP gross margin percentage increased 870 basis points to 26.8%.  The increase in our total non-GAAP gross margin was primarily due to the impact from the EMC acquired businesses.

[0001571996-17-000004:mdna:116]
| • | Products — During Fiscal 2017, product gross margin increased 26% to $6.5 billion, and product gross margin percentage increased 130 basis points to 13.4%. The increases in product gross margin were driven primarily by an increase in CSG gross margin due to a favorable cost position and a richer product mix and, to a lesser extent, by the incremental product gross margin attributable to the EMC acquired businesses. |

[0001571996-17-000004:mdna:117]
During Fiscal 2017, non-GAAP product gross margin increased 67% to $9.3 billion, and non-GAAP product gross margin percentage increased 600 basis points to 19.1%.  The increase in non-GAAP product gross margin were primarily attributable to the incremental product gross margin from the EMC acquired businesses and an increase in CSG gross margin.

[0001571996-17-000004:mdna:118]
| • | Services — During Fiscal 2017, our gross margin for services increased 100% to $6.4 billion, and our services gross margin percentage increased 1,030 basis points to 49.6%. The increase in services gross margin was primarily attributable to gross margin from the EMC acquired businesses. Purchase accounting adjustments totaled $0.9 billion during Fiscal 2017, compared to $0.5 billion during Fiscal 2016. Excluding these costs, transaction-related expenses and other corporate expenses, non-GAAP gross margin dollars for services increased 102% to $7.5 billion and services gross margin percentage increased 1,140 basis points to 54.1%. |

[0001571996-17-000004:mdna:119]
Fiscal 2016 compared to Fiscal 2015

[0001571996-17-000004:mdna:120]
During Fiscal 2016, our total gross margin decreased 6% to $8.4 billion, and our gross margin percentage increased 10 basis points to 16.5%.  Gross margin for Fiscal 2016 included the effects of $0.9 billion in purchase accounting adjustments and amortization of intangibles related to the going-private transaction.  During Fiscal 2016, our non-GAAP gross margin decreased 8% to $9.3 billion, and our non-GAAP gross margin percentage decreased 40 basis points to 18.1%.

[0001571996-17-000004:mdna:121]
| • | Products — During Fiscal 2016, product gross margin and non-GAAP product gross margin dollars decreased 14% and 13%, respectively. Product gross margin percentage and non-GAAP product gross margin percentage decreased 100 and 90 basis points during Fiscal 2016 to 12.1% and 13.1%, respectively. The decreases in product gross margin and non-GAAP product gross margin were primarily attributable to the adverse impact on CSG of an overall decline in demand that resulted in a decrease in desktop and notebook units sold, as well as to challenging pricing dynamics. These pricing dynamics included the impacts of competitive pressure and foreign currency volatility. Our gross margins include benefits relating primarily to settlements from certain vendors regarding their past pricing practices. These benefits were $97 million and $109 million for Fiscal 2016 and Fiscal 2015, respectively. Vendor settlements are allocated to our segments based on the relative amount of affected vendor products sold by each segment. |

[0001571996-17-000004:mdna:122]
| • | Services — During Fiscal 2016, our services gross margin increased 13%, and our non-GAAP services gross margin was relatively unchanged. The increase in services gross margin was primarily attributable to the diminishing negative impact of purchase accounting adjustments, which were $0.5 billion in Fiscal 2016, compared to $0.8 billion in Fiscal 2015. Services gross margin percentage and non-GAAP services gross margin percentage increased 370 and 110 basis points during Fiscal 2016 to 39.3% and 42.7%, respectively. The increase in non-GAAP services gross margin was attributable to a shift away from lower margin product offerings. |

[0001571996-17-000004:mdna:123]
Vendor Programs and Settlements

[0001571996-17-000004:mdna:124]
Our gross margin is affected by our ability to achieve competitive pricing with our vendors and contract manufacturers, including through our negotiation of a variety of vendor rebate programs to achieve lower net costs for the various components we include in our products.  Under these programs, vendors provide us with rebates or other discounts from the list prices for the components, which are generally elements of their pricing strategy.  We account for vendor rebates and other discounts as a reduction in cost of net revenue.  We manage our costs on a total net cost basis, which includes supplier list prices reduced by vendor rebates and other discounts.

[0001571996-17-000004:mdna:125]
The terms and conditions of our vendor rebate programs are largely based on product volumes and are generally negotiated either at the beginning of the annual or quarterly period, depending on the program.  The timing and amount of vendor rebates and other discounts we receive under the programs may vary from period to period, reflecting changes in the competitive environment.  We monitor our component costs and seek to address the effects of any changes to terms that might arise under our vendor rebate programs.  Our gross margins for Fiscal 2017, Fiscal 2016, and Fiscal 2015 were not materially affected by any changes to the terms of our vendor rebate programs, as the amounts we received under these programs were generally stable relative to our total net cost.  We are not aware of any significant changes to vendor pricing or rebate programs that may impact our results in the near term.

[0001571996-17-000004:mdna:126]
In addition, we have pursued legal action against certain vendors and are currently involved in negotiations with other vendors regarding their past pricing practices.  We have negotiated settlements with some of these vendors and may have additional settlements in future periods.  These settlements are allocated to our segments based on the relative amount of affected vendor products sold by each segment.  Pricing settlements benefited product gross margins in Fiscal 2017, Fiscal 2016, and Fiscal 2015 by $80 million, $97 million, and $109 million, respectively.

[0001571996-17-000004:mdna:127]
57

[0001571996-17-000004:mdna:128]
Operating Expenses

[0001571996-17-000004:mdna:129]
The following table presents information regarding our operating expenses during each of the periods presented:

[0001571996-17-000004:mdna:130]
|  |  | Fiscal Year Ended |
|  |  | February 3, 2017 |  |  |  | January 29, 2016 |  |  |  | January 30, 2015 |
|  |  | Dollars |  | % ofNet Revenue |  | %Change |  | Dollars |  | % ofNet Revenue |  | %Change |  | Dollars |  | % ofNet Revenue |
|  |  | (in millions, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative |  | $ | 13,575 |  |  | 22.0 | % |  | 73 | % |  | $ | 7,850 |  |  | 15.4 | % |  | (5 | )% |  | $ | 8,292 |  |  | 15.3 | % |
| Research, development, and engineering |  | 2,636 |  |  | 4.3 | % |  | 151 | % |  | 1,051 |  |  | 2.1 | % |  | 14 | % |  | 920 |  |  | 1.7 | % |
| Total operating expenses |  | $ | 16,211 |  |  | 26.3 | % |  | 82 | % |  | $ | 8,901 |  |  | 17.5 | % |  | (3 | )% |  | $ | 9,212 |  |  | 17.0 | % |
| Other Financial Information |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP operating expenses |  | $ | 11,706 |  |  | 18.6 | % |  | 65 | % |  | $ | 7,082 |  |  | 13.8 | % |  | (3 | )% |  | $ | 7,309 |  |  | 13.3 | % |

[0001571996-17-000004:mdna:131]
Fiscal 2017 compared to Fiscal 2016

[0001571996-17-000004:mdna:132]
During Fiscal 2017, our total operating expenses increased 82%.  The increase in total operating expenses was primarily due to approximately $6.0 billion of incremental costs associated with the EMC acquired businesses, including transaction-related expenses.  These transaction-related expenses include consulting and advisory services and retention payments.  Our operating expenses include purchase accounting adjustments associated with the EMC merger transaction and the going-private transaction, amortization of intangible assets, transaction-related expenses, and other corporate expenses.  In aggregate, these items totaled $4.5 billion and $1.8 billion for Fiscal 2017 and Fiscal 2016, respectively.  Excluding these costs, total non-GAAP operating expenses increased 65% primarily due to the impact from the EMC acquired businesses.

[0001571996-17-000004:mdna:133]
| • | Selling, General, and Administrative — Selling, general, and administrative ("SG&A") expenses increased 73% during Fiscal 2017. The increases in SG&A expenses were primarily driven by incremental costs associated with the EMC acquired businesses and also reflected the impact of our increased investment in sales capabilities and marketing costs. |

[0001571996-17-000004:mdna:134]
| • | Research and Development — Research and development ("R&D") expenses are primarily composed of personnel-related expenses related to product development. R&D expenses were approximately 4.3% and 2.1% of net revenue for Fiscal 2017 and Fiscal 2016, respectively. The increases in R&D expenses were attributable to the expansion of our R&D capability through the EMC merger transaction. As our industry continues to change and as the needs of our customers evolve, we intend to support R&D initiatives to innovate and introduce new and enhanced solutions into the market. |

[0001571996-17-000004:mdna:135]
We will continue to maintain cost discipline and focus on optimizing cost synergies resulting from the EMC merger transaction while investing in strategic areas such as our sales force, marketing, and R&D.

[0001571996-17-000004:mdna:136]
Fiscal 2016 compared to Fiscal 2015

[0001571996-17-000004:mdna:137]
During Fiscal 2016, our total operating expenses and non-GAAP operating expenses both decreased 3%.  During Fiscal 2016 and Fiscal 2015, we recognized $1.7 billion and $1.8 billion, respectively, in amortization of intangible assets and purchase accounting adjustments related to the going-private transaction.

[0001571996-17-000004:mdna:138]
| • | Selling, General, and Administrative — SG&A expenses decreased 5% during Fiscal 2016. The decreases were driven by a reduction in compensation expense, primarily due to a decrease in performance-based compensation. |

[0001571996-17-000004:mdna:139]
| • | Research and Development — R&D expenses were 2.1% of net revenue for Fiscal 2016, compared to 1.7% for Fiscal 2015. The increase in R&D expenses was primarily related to personnel-related expenses as we continue to invest in product development. |

[0001571996-17-000004:mdna:140]
58

[0001571996-17-000004:mdna:141]
Operating Income/Loss

[0001571996-17-000004:mdna:142]
Fiscal 2017 compared to Fiscal 2016

[0001571996-17-000004:mdna:143]
Our operating loss was $3.3 billion and $0.5 billion during Fiscal 2017 and Fiscal 2016, respectively.  The increase in operating loss was primarily attributable to higher operating expenses, partially offset by increases in gross margin.  Our operating loss includes purchase accounting adjustments associated with the EMC merger transaction and the going-private transaction, amortization of intangible assets, transaction-related expenses, and other corporate expenses.  In aggregate, these items totaled $8.4 billion and $2.7 billion for Fiscal 2017 and Fiscal 2016, respectively.  Excluding these costs, non-GAAP operating income increased 130% to $5.1 billion during Fiscal 2017.  The increase in non-GAAP operating income was primarily attributable to an increase in gross margin, which was partially offset by higher operating expenses from the EMC acquired businesses.

[0001571996-17-000004:mdna:144]
Fiscal 2016 compared to Fiscal 2015

[0001571996-17-000004:mdna:145]
During Fiscal 2016, operating loss was $0.5 billion, compared to $0.3 billion during Fiscal 2015.  The increase in operating loss over the period was primarily attributable to the decrease in gross margin.  Operating loss includes amortization of intangible assets, purchase accounting adjustments associated with the going-private transaction, transaction-related expenses, and other corporate expenses of $2.7 billion and $3.1 billion for Fiscal 2016 and Fiscal 2015, respectively.  Excluding these costs, during Fiscal 2016, non-GAAP operating income decreased 21% to an operating income of $2.2 billion.  This decrease was primarily attributable to lower gross margin primarily driven by CSG, the effect of which was partially offset by a reduction in operating expenses.

[0001571996-17-000004:mdna:146]
Interest and Other, Net

[0001571996-17-000004:mdna:147]
The following table provides information regarding interest and other, net for each of the periods presented:

[0001571996-17-000004:mdna:148]
|  | Fiscal Year Ended |
|  | February 3, 2017 |  | January 29, 2016 |  | January 30, 2015 |
|  | (in millions) |
| Interest and other, net: |  |  |  |  |  |  |  |  |
| Investment income, primarily interest | $ | 102 |  |  | $ | 39 |  |  | $ | 47 |  |
| Gain (loss) on investments, net | 4 |  |  | (2 | ) |  | (29 | ) |
| Interest expense | (1,751 | ) |  | (680 | ) |  | (807 | ) |
| Foreign exchange | (77 | ) |  | (107 | ) |  | (76 | ) |
| Debt extinguishment | (337 | ) |  | — |  |  | — |  |
| Other | (45 | ) |  | (22 | ) |  | (34 | ) |
| Total interest and other, net | $ | (2,104 | ) |  | $ | (772 | ) |  | $ | (899 | ) |

[0001571996-17-000004:mdna:149]
Fiscal 2017 compared to Fiscal 2016

[0001571996-17-000004:mdna:150]
During Fiscal 2017, changes in interest and other, net were unfavorable by $1.3 billion, primarily due to an increase in interest expense from higher average debt balances from debt issued in connection with the EMC merger transaction, and to costs related to debt extinguishment associated with that transaction.  See Note 8 of the Notes to the Consolidated Financial Statements included in this report for further information regarding our debt.

[0001571996-17-000004:mdna:151]
Fiscal 2016 compared to Fiscal 2015

[0001571996-17-000004:mdna:152]
During Fiscal 2016, changes in interest and other, net were favorable by $127 million, primarily due to a decrease in interest expense from lower average debt balances over the period.

[0001571996-17-000004:mdna:153]
Income and Other Taxes

[0001571996-17-000004:mdna:154]
Our effective income tax rates for continuing operations were 30.2% and 9.2% on pre-tax losses from continuing operations of $5.4 billion and $1.3 billion for Fiscal 2017 and Fiscal 2016, respectively.  The change in our effective income tax rate was primarily attributable to tax benefits from charges associated with the EMC merger transaction, including purchase accounting adjustments, interest charges, and stock-based compensation expense, which were primarily incurred in higher tax jurisdictions.  See Note 1 and Note 3 of the Notes to the Consolidated Financial Statements included in this report for more information on the EMC merger transaction.  The effective tax rate for Fiscal 2017 also includes an income tax benefit impact of 5.5% relating to the settlement of an Internal Revenue Service audit for fiscal years 2004 through 2006.

[0001571996-17-000004:mdna:155]
Our effective tax rate can fluctuate depending on the geographic distribution of our world-wide earnings, as our foreign earnings are generally taxed at lower rates than in the United States.  In certain jurisdictions, our tax rate is significantly less than the applicable statutory rate as a result of tax holidays.  The majority of our foreign income that is subject to these tax holidays and lower tax rates is attributable to Singapore, China, and Malaysia.  Although a significant portion of these income tax benefits relate to a tax holiday that expired on December 31, 2016, we have negotiated new terms for the affected subsidiary.  These new terms provide for a reduced income tax rate that will be effective for a 25-month bridge period expiring in January 2019.  Our other tax holidays will expire in whole or in part during Fiscal 2019 through Fiscal 2023.  Many of these tax holidays and reduced tax rates may be extended when certain conditions are met or may be terminated early if certain conditions are not met.  The differences between our effective tax rate and the U.S. federal statutory rate of 35% principally resulted from the geographical distribution of taxable income discussed above and permanent differences between the book and tax treatment of certain items.  We continue to assess our business model and its impact in various taxing jurisdictions.

[0001571996-17-000004:mdna:156]
For further discussion regarding tax matters, including the status of income tax audits, see Note 14 of the Notes to the Consolidated Financial Statements included in this report.

[0001571996-17-000004:mdna:157]
Net Income/Loss from Continuing Operations

[0001571996-17-000004:mdna:158]
Fiscal 2017 compared to Fiscal 2016

[0001571996-17-000004:mdna:159]
During Fiscal 2017, net loss from continuing operations increased 220% to a net loss of $3.7 billion.  The increase in net loss from continuing operations for Fiscal 2017 was primarily attributable to an increase in operating loss and to an increase in interest and other, net expense.  The effect of these factors was partially offset by an increase in tax benefit during the period.  See Note 14 of the Notes to the Consolidated Financial Statements included in this report for more information regarding our effective tax rate.

[0001571996-17-000004:mdna:160]
Net loss from continuing operations for Fiscal 2017 included amortization of intangible assets, purchase accounting adjustments, transaction-related expenses, and other corporate expenses.  Excluding these costs, non-GAAP net income from continuing operations increased 155% to $2.7 billion during Fiscal 2017.  The increase in non-GAAP net income from continuing operations during Fiscal 2017 was primarily attributable to an increase in operating income, the effect of which was primarily offset by an increase in interest and other, net expense.

[0001571996-17-000004:mdna:161]
Fiscal 2016 compared to Fiscal 2015

[0001571996-17-000004:mdna:162]
During Fiscal 2016, net loss from continuing operations increased 5% to a net loss of $1.2 billion.  Net loss from continuing operations for Fiscal 2016 and Fiscal 2015 included amortization of intangible assets and purchase accounting adjustments associated with the going-private transaction of $2.6 billion and $3.0 billion, respectively.  Excluding these costs, as well as transaction-related expenses and other corporate expenses, during Fiscal 2016, non-GAAP net income from continuing operations decreased 25% to a net income of $1.1 billion.  The decrease in non-GAAP net income from continuing operations for Fiscal 2016 was primarily attributable to a decrease in non-GAAP operating income.  The decrease in non-GAAP operating income from continuing operations was partially mitigated by the favorable impact of a decrease in interest and other, net expense, and a decrease in tax expense.  See Note 14 of the Notes to the Consolidated Financial Statements included in this report for more information regarding our effective tax rate.

[0001571996-17-000004:mdna:163]
60

[0001571996-17-000004:mdna:164]
Non-controlling Interests

[0001571996-17-000004:mdna:165]
Fiscal 2017 compared to Fiscal 2016

[0001571996-17-000004:mdna:166]
During Fiscal 2017, net loss attributable to the non-controlling interests was $46 million.  Net loss attributable to the non-controlling interest was primarily attributable to the net loss attributable to the non-controlling interest in VMware of $41 million.  During Fiscal 2016, Dell Technologies did not have any non-controlling interests.  For more information about our non-controlling interests, see Note 16 of the Notes to the Consolidated Financial Statements included in this report.

[0001571996-17-000004:mdna:167]
Net Loss Attributable to Dell Technologies Inc.

[0001571996-17-000004:mdna:168]
Fiscal 2017 compared to Fiscal 2016

[0001571996-17-000004:mdna:169]
Net loss attributable to Dell Technologies Inc. represents net income/loss from continuing and discontinued operations, and the adjustment for non-controlling interests.  During Fiscal 2017 and Fiscal 2016, net loss attributable to Dell Technologies Inc. was $1.7 billion and $1.1 billion, respectively, which was due to an increase in net loss from continuing operations, offset partially by an increase in income from discontinued operations.  For more information regarding our discontinued operations, see Note 4 of the Notes to the Consolidated Financial Statements included in this report.

[0001571996-17-000004:mdna:170]
Business Unit Results

[0001571996-17-000004:mdna:171]
Our reportable segments are based on the following business units:  Client Solutions Group, or CSG; Infrastructure Solutions Group, or ISG; and VMware.  A description of our three business units is provided under "Introduction."  See Note 22 of the Notes to the Consolidated Financial Statements included in this report for a reconciliation of net revenue and operating income by reportable segment to consolidated net revenue and consolidated operating income, respectively.

[0001571996-17-000004:mdna:172]
Client Solutions Group:

[0001571996-17-000004:mdna:173]
The following table presents net revenue and operating income attributable to CSG for the respective periods:

[0001571996-17-000004:mdna:174]
|  | Fiscal Year Ended |
|  | February 3, 2017 |  | % Change |  | January 29, 2016 |  | % Change |  | January 30, 2015 |
|  | (in millions, except percentages) |
| Net Revenue (a): |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 26,006 |  |  | 1 | % |  | $ | 25,747 |  |  | (10 | )% |  | $ | 28,754 |  |
| Consumer | 10,748 |  |  | 6 | % |  | 10,130 |  |  | (7 | )% |  | 10,880 |  |
| Total CSG net revenue | $ | 36,754 |  |  | 2 | % |  | $ | 35,877 |  |  | (9 | )% |  | $ | 39,634 |  |
| Operating Income: |  |  |  |  |  |  |  |  |  |
| CSG operating income | $ | 1,845 |  |  | 31 | % |  | $ | 1,410 |  |  | (31 | )% |  | $ | 2,051 |  |
| % of segment net revenue | 5.0 | % |  |  |  | 3.9 | % |  |  |  | 5.2 | % |

[0001571996-17-000004:mdna:175]
____________________

[0001571996-17-000004:mdna:176]
| (a) | In the first quarter of Fiscal 2017, we redefined the categories within the CSG business unit. None of these changes impacted our consolidated or total business unit results. Prior period amounts have been recast to provide comparability. |

[0001571996-17-000004:mdna:177]
Fiscal 2017 compared to Fiscal 2016

[0001571996-17-000004:mdna:178]
Net Revenue — During Fiscal 2017, CSG net revenue increased 2% driven by an increase in both commercial and consumer net revenue.  Commercial net revenue benefited from an increase in volume of premium notebook and workstation units sold, partially offset by a decrease in overall average selling prices.  The increase in consumer net revenue was driven by an increase in the volume of notebook units sold, which also was partially offset by a decrease in overall average selling prices.  The increase in volume of commercial and consumer notebooks sold was attributable to an overall improvement in customer demand.  Both commercial and consumer businesses experienced a decrease in overall average selling prices as we strategically managed our pricing position given competitive conditions and the favorable cost environment.

[0001571996-17-000004:mdna:179]
From a geographical perspective, net revenue attributable to CSG increased in the Americas and APJ during Fiscal 2017, while net revenue in EMEA was unchanged.

[0001571996-17-000004:mdna:180]
Operating Income — During Fiscal 2017, CSG operating income as a percentage of net revenue increased 110 basis points to 5.0%.  This increase was driven by improvement in our gross margin percentage, which was principally the result of a favorable cost position and a richer product mix of premium notebooks and workstations.

[0001571996-17-000004:mdna:181]
Fiscal 2016 compared to Fiscal 2015

[0001571996-17-000004:mdna:182]
Net Revenue — During Fiscal 2016, CSG experienced a 9% decrease in net revenue due to lower demand across all CSG product categories coupled with competitive pricing pressure.  The decline in commercial and consumer revenue reflected decreased demand for desktops and notebooks, which was magnified by our product mix.  Product revenue for Fiscal 2016 did not benefit from the positive effects of the Windows XP refresh that contributed to product revenue in Fiscal 2015.  From a geographical perspective, revenue attributable to CSG decreased across all regions during Fiscal 2016, with revenue from the Americas and EMEA accounting for most of the decline.

[0001571996-17-000004:mdna:183]
Operating Income — During Fiscal 2016, operating income as a percentage of revenue attributable to CSG decreased 130 basis points to 3.9%.  This decline was driven by both a decrease in our gross margin percentage and an increase in our operating

[0001571996-17-000004:mdna:184]
expense percentage.  The decline in our gross margin percentage was a result of challenging economic conditions, competitive pressures, and a strong U.S. dollar that all impacted our ability to adjust pricing accordingly.  Despite this challenging environment, we made investments in our sales force to enhance efficiency and drive growth in future periods.  As a result of this investment and strategic R&D investments, operating expenses as a percentage of revenue increased over the period.

[0001571996-17-000004:mdna:185]
Infrastructure Solutions Group:

[0001571996-17-000004:mdna:186]
The following table presents net revenue and operating income attributable to ISG for the respective periods:

[0001571996-17-000004:mdna:187]
|  | Fiscal Year Ended |
|  | February 3, 2017 |  | % Change |  | January 29, 2016 |  | % Change |  | January 30, 2015 |
|  | (in millions, except percentages) |
| Net Revenue: |  |  |  |  |  |  |  |  |  |
| Servers and networking | $ | 12,834 |  |  | 1 | % |  | $ | 12,761 |  |  | 3 | % |  | $ | 12,368 |  |
| Storage | 8,942 |  |  | 303 | % |  | 2,217 |  |  | (5 | )% |  | 2,346 |  |
| Total ISG net revenue | $ | 21,776 |  |  | 45 | % |  | $ | 14,978 |  |  | 2 | % |  | $ | 14,714 |  |
| Operating Income: |  |  |  |  |  |  |  |  |  |
| ISG operating income | $ | 2,393 |  |  | 127 | % |  | $ | 1,052 |  |  | (14 | )% |  | $ | 1,230 |  |
| % of segment net revenue | 11.0 | % |  |  |  | 7.0 | % |  |  |  | 8.4 | % |

[0001571996-17-000004:mdna:188]
Fiscal 2017 compared to Fiscal 2016

[0001571996-17-000004:mdna:189]
Net Revenue — During Fiscal 2017, ISG net revenue increased 45% due to incremental net revenue associated with the EMC acquired storage business, which caused storage revenue to increase 303%.  Revenue from servers and networking was relatively unchanged over the period, resulting from the offsetting dynamics of an increase in average selling prices due to a shift to PowerEdge servers with richer configurations, as well as to a decline in volume of PowerEdge units, as customer demand has shifted to cloud and hyperscale servers, which generally have a lower average selling price.

[0001571996-17-000004:mdna:190]
From a geographical perspective, during Fiscal 2017, ISG net revenue increased in all regions due to the incremental revenue from the EMC acquired storage business.  The EMC acquired storage business operates on a world-wide basis with a geographic mix similar to that of the legacy Dell ISG business.

[0001571996-17-000004:mdna:191]
Operating Income — During Fiscal 2017, ISG operating income as a percentage of net revenue increased 400 basis points to 11.0%.  The increase in ISG operating income percentage was primarily driven by the favorable impact of higher gross margin percentages and operating income percentages from the EMC acquired businesses.  The gross margin percentage for the legacy Dell ISG business was relatively flat over the period.

[0001571996-17-000004:mdna:192]
Fiscal 2016 compared to Fiscal 2015

[0001571996-17-000004:mdna:193]
Net Revenue — During Fiscal 2016, ISG net revenue increased 2% primarily due to a 3% increase in net revenue from servers and networking.  PowerEdge server average selling prices increased due to a shift to products with richer configurations, while overall units remained relatively flat.  The increase in net revenue from servers and networking was partially offset by a 5% decrease in storage revenue.  From a geographical perspective, during Fiscal 2016, the overall increase in ISG net revenue was primarily due to increased revenue in APJ.

[0001571996-17-000004:mdna:194]
Operating Income — During Fiscal 2016, ISG operating income as a percentage of revenue decreased 140 basis points to 7.0%.  The decrease in our operating income percentage was driven by lower gross margin percentages.  These declines were primarily driven by challenging pricing dynamics, including competitive pressures and the strong U.S. dollar.  These challenging economic conditions affected our ability to raise prices sufficiently to offset the higher costs associated with the shift to products with richer configurations.

[0001571996-17-000004:mdna:195]
63

[0001571996-17-000004:mdna:196]
VMware:

[0001571996-17-000004:mdna:197]
The following table presents net revenue and operating income attributable to VMware for the respective periods:

[0001571996-17-000004:mdna:198]
|  | Fiscal Year Ended |
|  | February 3, 2017 |  | % Change |  | January 29, 2016 |  | % Change |  | January 30, 2015 |
|  | (in millions, except percentages) |
| Net Revenue: |  |  |  |  |  |  |  |  |  |
| VMware net revenue | $ | 3,225 |  |  | NA |  | $ | — |  |  | NA |  | $ | — |  |
| Operating Income: |  |  |  |  |  |  |  |  |  |
| VMware operating income | $ | 1,113 |  |  | NA |  | $ | — |  |  | NA |  | $ | — |  |
| % of segment net revenue | 34.5 | % |  |  |  | NA |  |  |  | NA |

[0001571996-17-000004:mdna:199]
Net Revenue — VMware net revenue during Fiscal 2017 represents revenue from the EMC merger transaction date of September 7, 2016 through February 3, 2017.  VMware net revenue for Fiscal 2017 primarily consists of revenue from the sale of software licenses under perpetual licenses, related software maintenance and support, training, consulting services, and hosted services.

[0001571996-17-000004:mdna:200]
From a geographical perspective, approximately half of VMware net revenue during Fiscal 2017 was generated from sales to customers in the United States.

[0001571996-17-000004:mdna:201]
Operating Income — During Fiscal 2017, VMware operating income as a percentage of net revenue was 34.5% during Fiscal 2017.  The VMware operating income percentage during Fiscal 2017 was impacted by the timing of the completion of the EMC merger transaction.

[0001571996-17-000004:mdna:202]
64

[0001571996-17-000004:mdna:203]
Accounts Receivable

[0001571996-17-000004:mdna:204]
We sell products and services directly to customers and through a variety of sales channels, including retail distribution.  Our accounts receivable, net, was $9.4 billion and $4.9 billion as of February 3, 2017 and January 29, 2016, respectively.  We maintain an allowance for doubtful accounts to cover receivables that may be deemed uncollectible.  The allowance for losses is based on a provision for accounts that are collectively evaluated based on historical bad debt experience as well as specific identifiable customer accounts that are deemed at risk.  As of February 3, 2017 and January 29, 2016, the allowance for doubtful accounts was $46 million and $36 million, respectively.  Based on our assessment, we believe that we are adequately reserved for expected credit losses.  We monitor the aging of our accounts receivable and continue to take actions to reduce our exposure to credit losses.

[0001571996-17-000004:mdna:205]
Dell Financial Services and Financing Receivables

[0001571996-17-000004:mdna:206]
Dell Financial Services, referred to as DFS, offers a wide range of financial services, including originating, collecting, and servicing customer receivables primarily related to the purchase of Dell products.  Following the closing of the EMC merger transaction, DFS began offering similar financial services related to the purchase of Dell EMC and VMware products.  In some cases, we originate financing activities for our commercial customers related to the purchase of third-party technology products that complement our portfolio of products and services.  New financing originations, which represent the amounts of financing provided by DFS to customers for equipment and related software and services, including third-party originations, were $4.5 billion for the fiscal year ended February 3, 2017 and $3.7 billion for both fiscal years ended  January 29, 2016 and January 30, 2015.  As of February 3, 2017 and January 29, 2016, our financing receivables, net were $5.9 billion and $5.1 billion, respectively.

[0001571996-17-000004:mdna:207]
We have securitization programs to fund revolving loans and fixed-term leases and loans through consolidated special purpose entities, referred to as SPEs, which we account for as secured borrowings.  We transfer certain U.S. and European customer financing receivables to these SPEs, whose purpose is to facilitate the funding of customer receivables through financing arrangements with multi-seller conduits that issue asset-backed debt securities in the capital markets and to private investors.  During Fiscal 2017 and Fiscal 2016, we transferred $3.3 billion and $3.2 billion to these SPEs, respectively.  The structured financing debt related to all of our securitization programs included as secured borrowing was $3.1 billion and $2.8 billion as of February 3, 2017 and January 29, 2016, respectively.  In addition, the carrying amount of the corresponding financing receivables was $3.6 billion and $3.3 billion as of February 3, 2017 and January 29, 2016, respectively.  As a result of the EMC merger transaction, we plan to expand our existing securitization programs to allow for additional funding of customer receivables in the capital markets.

[0001571996-17-000004:mdna:208]
We maintain an allowance to cover expected financing receivable credit losses and evaluate credit loss expectations based on our total portfolio.  For the fiscal years ended February 3, 2017, January 29, 2016, and January 30, 2015, the principal charge-off rate for our total portfolio was 2.0%, 2.5%, and 2.9%, respectively.  The credit quality of our financing receivables has improved in recent years due to an overall improvement in the credit environment and as the mix of high-quality commercial accounts in our portfolio has increased.  The allowance for losses is determined based on various factors, including historical and anticipated experience, past due receivables, receivable type, and customer risk profile.  At February 3, 2017 and January 29, 2016, the allowance for financing receivable losses was $143 million and $176 million, respectively.  In general, the loss rates on our financing receivables have improved over the periods presented.  We expect relatively stable loss rates in future periods, with movements in these rates being primarily driven by seasonality and a continued shift in portfolio composition to lower risk commercial assets.  We continue to monitor broader economic indicators and their potential impact on future loss performance.  We have an extensive process to manage our exposure to customer credit risk, including active management of credit lines and our collection activities.  We also sell selected fixed-term financing receivables to unrelated third parties on a periodic basis, primarily to manage certain concentrations of customer credit exposure.  Based on our assessment of the customer financing receivables, we believe that we are adequately reserved.

[0001571996-17-000004:mdna:209]
See Note 7 of the Notes to the Consolidated Financial Statements included in this report for additional information about our financing receivables and the associated allowance.

[0001571996-17-000004:mdna:210]
65

[0001571996-17-000004:mdna:211]
Deferred Revenue

[0001571996-17-000004:mdna:212]
Deferred revenue is recorded when billings have been generated or payments have been received for undelivered products or services, or in situations where revenue recognition criteria have not been met.  Deferred revenue represents amounts received in advance for extended warranty services, software maintenance, unearned license fees, and deferred profit on third-party software offerings.  Deferred revenue is recognized on these items when the revenue recognition criteria are met, generally resulting in ratable recognition over the contract term.  We also have deferred revenue related to undelivered hardware and professional services, consisting of installations and consulting engagements, which are recognized as our obligations under the contract are completed.

[0001571996-17-000004:mdna:213]
Our total deferred revenue was $18.7 billion and $7.7 billion as of February 3, 2017 and January 29, 2016, respectively, and increased $11.0 billion, or 143%, over that period.  This increase was primarily attributable to the deferred revenue assumed in the EMC merger transaction, which was recorded at its fair value of $8.4 billion.  The increase was also attributable to the overall revenue growth driven by the expansion of our business as a result of the EMC merger transaction.  A majority of deferred revenue as of February 3, 2017 is expected to be recognized over the next two years.  See Note 1 and Note 3 of the Notes to the Consolidated Financial Statements included in this report for additional information on the EMC merger transaction.

[0001571996-17-000004:mdna:214]
Off-Balance Sheet Arrangements

[0001571996-17-000004:mdna:215]
As of February 3, 2017, we had no off-balance sheet arrangements that have or are reasonably likely to have a current or future material effect on our financial condition or results of operations.

[0001571996-17-000004:mdna:216]
66

[0001571996-17-000004:mdna:217]
MARKET CONDITIONS, LIQUIDITY, AND CAPITAL COMMITMENTS

[0001571996-17-000004:mdna:218]
Market Conditions

[0001571996-17-000004:mdna:219]
We regularly monitor economic conditions and associated impacts on the financial markets and our business.  We consistently evaluate the financial health of our supplier base, carefully manage customer credit, diversify counterparty risk, and monitor the concentration risk of our cash and cash equivalents balances globally.  We routinely monitor our financial exposure to borrowers and counterparties.

[0001571996-17-000004:mdna:220]
We monitor credit risk associated with our financial counterparties using various market credit risk indicators such as credit ratings issued by nationally recognized rating agencies and changes in market credit default swap levels.  We perform periodic evaluations of our positions with these counterparties and may limit exposure to any one counterparty in accordance with our policies.  We monitor and manage these activities depending on current and expected market developments.

[0001571996-17-000004:mdna:221]
We use derivative instruments to hedge certain foreign currency exposures.  We use forward contracts and purchased options designated as cash flow hedges to protect against the foreign currency exchange rate risks inherent in our forecasted transactions denominated in currencies other than the U.S. dollar.  In addition, we primarily use forward contracts and may use purchased options to hedge monetary assets and liabilities denominated in a foreign currency.  See Note 9 of the Notes to the Consolidated Financial Statements included in this report for more information about our use of derivative instruments.

[0001571996-17-000004:mdna:222]
The impact on our Consolidated Financial Statements included in this report of any credit adjustments related to our use of counterparties has been immaterial.

[0001571996-17-000004:mdna:223]
Liquidity and Capital Resources

[0001571996-17-000004:mdna:224]
To support our ongoing business operations, we rely on operating cash flows as our primary source of liquidity.  We monitor the efficiency of our balance sheet to ensure that we have adequate liquidity to support our strategic initiatives.  In addition to internally generated cash, we have access to other capital sources to finance our strategic initiatives and fund growth in our financing operations, as evidenced by our actions to raise capital for the EMC merger transaction.  Further, we completed three strategic divestitures during Fiscal 2017.  We used the net proceeds from those divestitures to pay down a portion of the EMC merger transaction financing.  For more information on repayment of this debt, see Note 8 of the Notes to the Consolidated Financial Statements included in this report.  As of February 3, 2017, we had $9.5 billion of total cash and cash equivalents, the majority of which was held outside of the United States.  Our strategy is to deploy capital from any potential source, whether internally generated cash or debt, depending on the adequacy and availability of that source of capital and whether it can be accessed in a cost-effective manner.  We made available $3.0 billion of cash on hand from legacy Dell entities and $4.8 billion of cash on hand from legacy EMC entities to consummate the EMC merger transaction, some of which was repatriated from foreign jurisdictions.  We did not incur material tax or other material costs as a result of the repatriation.

[0001571996-17-000004:mdna:225]
A significant portion of our income is earned in non-U.S. jurisdictions.  Under current law, earnings available to be repatriated to the United States would be subject to U.S. federal income tax, less applicable foreign tax credits.  We have provided for the U.S. federal tax liability on these amounts for financial statement purposes, except for foreign earnings that are considered permanently reinvested outside of the United States.  We utilize a variety of tax planning and financing strategies with the objective of having our worldwide cash available in the locations where it is needed.

[0001571996-17-000004:mdna:226]
67

[0001571996-17-000004:mdna:227]
The following table summarizes our cash and cash equivalents as well as our available borrowings as of February 3, 2017 and January 29, 2016:

[0001571996-17-000004:mdna:228]
|  | February 3, 2017 |  | January 29, 2016 |
|  | (in millions) |
| Cash and cash equivalents, and available borrowings: |  |  |  |
| Cash and cash equivalents (a) | $ | 9,474 |  |  | $ | 6,322 |  |
| Remaining available borrowings under the Revolving Credit Facility | 2,678 |  |  | — |  |
| Remaining available borrowings under the asset-backed credit line ("ABL Credit Facility") | — |  |  | 1,676 |  |
| Total cash, cash equivalents, and available borrowings | $ | 12,152 |  |  | $ | 7,998 |  |

[0001571996-17-000004:mdna:229]
__________________

[0001571996-17-000004:mdna:230]
(a)  Of the $9.5 billion of cash and cash equivalents as of February 3, 2017, $3.2 billion was held by VMware.

[0001571996-17-000004:mdna:231]
At the closing of the EMC merger transaction on September 7, 2016, we entered into the Revolving Credit Facility and terminated the ABL Credit Facility.  The Revolving Credit Facility has maximum aggregate borrowings of approximately $3.2 billion.  Available borrowings under the Revolving Credit Facility are reduced by draws on the facility as well as by outstanding letters of credit.  As of February 3, 2017, remaining available borrowings under this facility totaled approximately $2.7 billion.

[0001571996-17-000004:mdna:232]
We believe that our current cash and cash equivalents, along with cash that will be provided by future operations and borrowings expected to be available under the Revolving Credit Facility, will be sufficient over at least the next twelve months to fund our operations, capital expenditures, share repurchases, and debt service requirements.

[0001571996-17-000004:mdna:233]
Debt

[0001571996-17-000004:mdna:234]
The following table summarizes our outstanding debt as of February 3, 2017 and January 29, 2016:

[0001571996-17-000004:mdna:235]
|  | February 3, 2017 |  | January 29, 2016 |
|  | (in millions) |
| Outstanding Debt: |  |  |  |
| Term loan facilities and Senior First Lien Notes issued in connection with going-private transaction | $ | — |  |  | $ | 7,623 |  |
| Unsecured notes and debentures issued prior to going-private transaction | 2,453 |  |  | 2,853 |  |
| Structured financing debt | 3,464 |  |  | 3,411 |  |
| Senior Secured Credit Facilities and First Lien Notes issued in connection with EMC merger transaction | 31,638 |  |  | — |  |
| Senior Notes issued in connection with EMC merger transaction | 3,250 |  |  | — |  |
| Existing EMC notes outstanding after the EMC merger transaction ("EMC Notes") | 5,500 |  |  | — |  |
| Bridge facilities issued in connection with EMC merger transaction | 4,000 |  |  | — |  |
| Other | 51 |  |  | 93 |  |
| Total debt, principal amount | 50,356 |  |  | 13,980 |  |
| Carrying value adjustments | (966 | ) |  | (349 | ) |
| Total debt, carrying value | $ | 49,390 |  |  | $ | 13,631 |  |

[0001571996-17-000004:mdna:236]
To finance the EMC merger transaction, we issued an aggregate principal amount of $45.9 billion in new debt, which included proceeds from the sale of the First Lien Notes and Senior Notes, as well as borrowings under the Senior Secured Credit Facilities (including the Revolving Credit Facility), the Asset Sale Bridge Facility, the Margin Bridge Facility, and the VMware Bridge Facility at the closing of the transaction.  Additionally, on September 7, 2016, EMC had outstanding senior notes (the "EMC Notes") consisting of $2.5 billion aggregate principal amount of its 1.875% Notes due June 2018, $2.0 billion aggregate principal amount of its 2.650% Notes due June 2020 and $1.0 billion aggregate principal amount of its 3.375% Notes due June 2023.  The EMC Notes remain outstanding following the closing of the EMC merger transaction.

[0001571996-17-000004:mdna:237]
Upon the closing of the EMC merger transaction, we repaid and terminated the ABL Credit Facility and the Term Loan Facilities obtained in connection with the going-private transaction and redeemed the Senior First Lien Notes issued in connection with the going-private transaction.  During Fiscal 2017, subsequent to the closing of the EMC merger transaction, we repaid $2.2 billion principal amount of the Asset Sale Bridge Facility, $3.1 billion principal amount of the Term Loan A-1 Facility, and $1.6 billion of the Revolving Credit Facility.  Further, during Fiscal 2017, we repaid $0.4 billion of maturing unsecured notes and debentures issued prior to the going-private transaction.

[0001571996-17-000004:mdna:238]
Our requirements for cash to pay principal and interest have increased significantly due to the borrowings that were required to finance the EMC merger transaction.  We expect the increased cash flows from the combined businesses will be sufficient to meet these requirements.  We or our affiliates, at our or their sole discretion, may purchase, redeem, prepay, refinance, or otherwise retire our outstanding indebtedness under the terms of such indebtedness, in open market or negotiated transactions with the holders of such indebtedness, or otherwise.

[0001571996-17-000004:mdna:239]
We balance the use of our securitization programs with working capital and other sources of liquidity to fund growth in our global financial services business.  Of the $50.4 billion in outstanding principal debt as of February 3, 2017, $5.1 billion, which includes $3.5 billion in structured financing debt, is used to fund this business.

[0001571996-17-000004:mdna:240]
See Note 8 of the Notes to the Consolidated Financial Statements included in this report for more information about our debt.

[0001571996-17-000004:mdna:241]
Cash Flows

[0001571996-17-000004:mdna:242]
The following table contains a summary of our Consolidated Statements of Cash Flows for the respective periods:

[0001571996-17-000004:mdna:243]
|  | Fiscal Year Ended |
|  | February 3, 2017 |  | January 29, 2016 |  | January 30, 2015 |
|  | (in millions) |
| Net change in cash from: |  |  |  |  |  |  |  |
| Operating activities | $ | 2,222 |  |  | $ | 2,162 |  |  | $ | 2,551 |  |
| Investing activities | (31,256 | ) |  | (321 | ) |  | (355 | ) |
| Financing activities | 31,908 |  |  | (496 | ) |  | (3,094 | ) |
| Effect of exchange rate changes on cash and cash equivalents | 24 |  |  | (167 | ) |  | (153 | ) |
| Change in cash and cash equivalents | $ | 2,898 |  |  | $ | 1,178 |  |  | $ | (1,051 | ) |

[0001571996-17-000004:mdna:244]
Operating Activities — Cash provided by operating activities was $2.2 billion for Fiscal 2017.  Strong operating cash flows were primarily attributable to profitable operations, particularly in the EMC acquired businesses.  The favorable impact of this profitability was partially offset by the cash used for transaction-related expenses.

[0001571996-17-000004:mdna:245]
Cash provided by operating activities was $2.2 billion for Fiscal 2016 and $2.6 billion for Fiscal 2015.  The decline in operating cash flows during Fiscal 2016 was due to a decline in profitability and lower working capital benefits.  Despite this decline, our operating cash flow performance remained strong.

[0001571996-17-000004:mdna:246]
Investing Activities — Investing activities consist of cash used to fund strategic acquisitions, capital expenditures for property, plant, and equipment, collections on purchased financing receivables, and proceeds from sale of facilities, land, and other assets.  Cash used in investing activities was $31.3 billion and $0.3 billion during Fiscal 2017 and Fiscal 2016, respectively.  The increase in cash used by investing activities was driven by $37.6 billion, net cash used to fund our acquisition of EMC.

[0001571996-17-000004:mdna:247]
Cash used in investing activities during Fiscal 2015, which primarily consisted of capital expenditures, was $0.4 billion.

[0001571996-17-000004:mdna:248]
Financing Activities — Financing activities primarily consist of the proceeds and repayments of debt.  During Fiscal 2017, cash provided by financing activities was $31.9 billion.  Cash provided by financing activities consisted primarily of $46.9 billion in cash proceeds from debt, $43.2 billion of which was issued in connection with the EMC merger transaction, and $4.4 billion in proceeds from the sale and issuance of our Class A, Class B, and Class C Common Stock for financing of that transaction.  These issuances were partially offset by $17.0 billion in repayments of debt, $0.9 billion in payments of debt issuance costs, $1.3 billion in payments to repurchase common stock, and $0.4 billion in payments related to the appraisal litigation from the

[0001571996-17-000004:mdna:249]
69

[0001571996-17-000004:mdna:250]
going-private transaction.  See Note 8 of the Notes to the Consolidated Financial Statements included in this report for more information about our debt.

[0001571996-17-000004:mdna:251]
In comparison, during Fiscal 2016, cash used in financing activities was $0.5 billion as we issued $0.7 billion, net, in additional structured financing debt, repaid $0.7 billion in maturing Unsecured Notes and Debentures, and repaid $0.4 billion, net, in Term Loan Facilities issued in connection with the going-private transaction and related foreign currency derivative settlements.

[0001571996-17-000004:mdna:252]
During Fiscal 2015, cash used in financing activities primarily consisted of repayments of $2.0 billion principal amount of other debt issued in the going-private transaction and $0.8 billion in borrowings outstanding under the ABL Credit Facility.

[0001571996-17-000004:mdna:253]
Key Performance Metrics

[0001571996-17-000004:mdna:254]
Our key performance metrics are net revenue, adjusted EBITDA, cash flows from operations, and cash conversion cycle.  Net revenue, adjusted EBITDA, and cash flows from operations are discussed elsewhere in this report.  Our cash conversion cycle is presented below.

[0001571996-17-000004:mdna:255]
Cash Conversion Cycle

[0001571996-17-000004:mdna:256]
We have calculated our cash conversion cycle excluding our discontinued operations as we believe it provides a better indication of our cash conversion cycle and is a better basis for evaluating our potential future cash operations.

[0001571996-17-000004:mdna:257]
The following table presents the components of our cash conversion cycle for the fourth quarter of each of the past three fiscal years:

[0001571996-17-000004:mdna:258]
|  | Three Months Ended |
|  | February 3, 2017 |  | January 29, 2016 |  | January 30, 2015 |
| Days of sales outstanding (a) | 48 |  |  | 39 |  |  | 41 |  |
| Days of supply in inventory (b) | 18 |  |  | 14 |  |  | 13 |  |
| Days in accounts payable (c) | (100 | ) |  | (112 | ) |  | (107 | ) |
| Cash conversion cycle (d) | (34 | ) |  | (59 | ) |  | (53 | ) |

[0001571996-17-000004:mdna:259]
__________________

[0001571996-17-000004:mdna:260]
| (a) | Days of sales outstanding, referred to as DSO, calculates the average collection period of our receivables. DSO is based on the ending net trade receivables and the most recent quarterly non-GAAP net revenue for each period. DSO also includes the effect of product costs related to customer shipments not yet recognized as revenue that are classified in other current assets. DSO is calculated by adding accounts receivable, net of allowance for doubtful accounts, and customer shipments in transit and dividing that sum by average non-GAAP net revenue per day for the current quarter (97 days for the three months ended February 3, 2017, and 90 days for the three months ended January 29, 2016 and January 30, 2015). As of February 3, 2017, DSO and days of customer shipments not yet recognized were 44 and 3 days, respectively. As of January 29, 2016, DSO and days of customer shipments not yet recognized were 34 and 5 days, respectively. As of January 30, 2015, DSO and days of customer shipments not yet recognized were 36 and 5 days, respectively. |

[0001571996-17-000004:mdna:261]
| (b) | Days of supply in inventory, referred to as DSI, measures the average number of days from procurement to sale of our products. DSI is based on ending inventory adjusted to exclude purchase accounting adjustments and non-GAAP cost of goods sold for each period. DSI is calculated by dividing ending inventory by average non-GAAP cost of goods sold per day for the current quarter (97 days for the three months ended February 3, 2017, and 90 days for the three months ended January 29, 2016 and January 30, 2015). |

[0001571996-17-000004:mdna:262]
| (c) | Days in accounts payable, referred to as DPO, calculates the average number of days our payables remain outstanding before payment. DPO is based on ending accounts payable and non-GAAP cost of goods sold for each period. DPO is calculated by dividing accounts payable by average non-GAAP cost of goods sold per day for the current quarter (97 days for the three months ended February 3, 2017, and 90 days for the three months ended January 29, 2016 and January 30, 2015). |

[0001571996-17-000004:mdna:263]
| (d) | We calculate our cash conversion cycle using non-GAAP net revenue and non-GAAP cost of goods sold because we believe that excluding certain items from the GAAP results facilitates management's understanding of this key performance metric. |

[0001571996-17-000004:mdna:264]
The table below provides reconciliations of each non-GAAP financial measure to its most directly comparable GAAP financial measure used in calculating the DSO, DSI and DPO metrics:

[0001571996-17-000004:mdna:265]
|  | Three Months Ended |
|  | February 3, 2017 |  | January 29, 2016 |  | January 30, 2015 |
|  | (in millions) |
| Net revenue | $ | 20,074 |  |  | $ | 12,679 |  |  | $ | 13,251 |  |
| Non-GAAP adjustments: |  |  |  |  |  |
| Impact of purchase accounting | 507 |  |  | 89 |  |  | 151 |  |
| Non-GAAP net revenue | $ | 20,581 |  |  | $ | 12,768 |  |  | $ | 13,402 |  |
| Cost of goods sold | $ | 15,543 |  |  | $ | 10,425 |  |  | $ | 11,258 |  |
| Non-GAAP adjustments: |  |  |  |  |  |
| Impact of purchase accounting | (603 | ) |  | (15 | ) |  | (17 | ) |
| Amortization of intangibles | (847 | ) |  | (97 | ) |  | (98 | ) |
| Transaction-related expenses | (18 | ) |  | — |  |  | — |  |
| Other corporate expenses | (89 | ) |  | (3 | ) |  | (5 | ) |
| Non-GAAP cost of goods sold | $ | 13,986 |  |  | $ | 10,310 |  |  | $ | 11,138 |  |

[0001571996-17-000004:mdna:266]
For the three months ended February 3, 2017, changes in our cash conversion cycle were unfavorable by twenty five days when compared to the three months ended January 29, 2016.  This was primarily driven by the acquisition of EMC, which had a negative impact across all three components.  We experienced a twelve day decrease in DPO, primarily driven by supplier payments terms of the EMC acquired businesses.  A nine day increase in DSO was primarily driven by differences in collections management from the EMC acquired businesses.  A four day increase in DSI was primarily the result of the longer inventory cycle associated with the EMC acquired product lines.  We are continuing the integration of the EMC acquired businesses and, as a result, our supplier arrangements, collection activities, and operating cycles will continue to evolve.  We believe our business model allows us to maintain an efficient cash conversion cycle, which compares favorably with that of others in our industry.

[0001571996-17-000004:mdna:267]
Our cash conversion cycle for the fiscal quarter ended January 29, 2016 improved six days when compared to the fiscal quarter ended January 30, 2015 driven by a five day improvement in DPO.  The increase in DPO was primarily due to the timing of supplier purchases and payments.  We also experienced a two day decrease in DSO, which was primarily driven by improved collections performance.

[0001571996-17-000004:mdna:268]
71

[0001571996-17-000004:mdna:269]
Capital Commitments

[0001571996-17-000004:mdna:270]
Capital Expenditures — During Fiscal 2017 and Fiscal 2016, we spent $699 million and $482 million, respectively, on property, plant, and equipment, which included $104 million and $116 million, respectively, attributable to discontinued operations. These expenditures were primarily incurred in connection with our global expansion efforts and infrastructure investments made to support future growth.  Product demand, product mix, and the increased use of contract manufacturers, as well as ongoing investments in operating and information technology infrastructure, influence the level and prioritization of our capital expenditures.  Aggregate capital expenditures for Fiscal 2018, which will be primarily related to infrastructure investments and strategic initiatives, are currently expected to total approximately $1.7 billion.

[0001571996-17-000004:mdna:271]
Share Repurchase Programs

[0001571996-17-000004:mdna:272]
Class V Common Stock Repurchases — On September 7, 2016, our board of directors approved a stock repurchase program (the "DHI Group Repurchase Program") under which we are authorized to use assets of the DHI Group to repurchase up to $1.0 billion of shares of our Class V Common Stock over a period of two years.  On December 13, 2016, the board of directors approved the suspension of the DHI Group Repurchase Program until such time as the board of directors authorizes the reinstatement of that program.  During the fiscal year ended February 3, 2017, we repurchased 7 million shares of Class V Common Stock for $324 million using cash of the DHI Group.  As of February 3, 2017, our remaining authorized amount for share repurchases under the DHI Group Repurchase Program was $676 million.

[0001571996-17-000004:mdna:273]
On December 13, 2016, the board of directors approved a new stock repurchase program (the "Class V Group Repurchase Program") under which we are authorized to use assets of the Class V Group to repurchase up to $500 million of shares of Class V Common Stock over a period of six months.  To the extent not retired, shares repurchased under the Class V Group Repurchase Program will be held as treasury stock.

[0001571996-17-000004:mdna:274]
During the fiscal year ended February 3, 2017, we repurchased 7 million shares of Class V Common Stock for $418 million under the Class V Group Repurchase Program.  As of February 3, 2017, our remaining authorized amount for share repurchases under the Class V Group Repurchase Program was $82 million.

[0001571996-17-000004:mdna:275]
VMware Class A Common Stock Repurchases — In April 2016, VMware's board of directors authorized the repurchase of up to $1.2 billion of shares of VMware's Class A common stock through the end of 2016.  All shares repurchased under VMware's stock repurchase programs are retired.  During the period from September 7, 2016 through February 3, 2017, VMware repurchased $611 million of its Class A common stock under the April 2016 program, and the authorized amount for repurchases of VMware Class A common stock was fully utilized as of February 3, 2017.

[0001571996-17-000004:mdna:276]
On December 15, 2016, we entered into a stock purchase agreement with VMware pursuant to which VMware agreed to purchase for cash $500 million of shares of VMware Class A common stock from a subsidiary of Dell Technologies.  We will apply the proceeds from the sale to the repurchase of shares of our Class V Common Stock under the Class V Group Repurchase Program described above.  During the period from September 7, 2016 through February 3, 2017, VMware repurchased approximately 4.8 million shares of its Class A common stock under the December 2016 program.  On February 15, 2017, subsequent to the close of our fiscal year, VMware repurchased an additional 1.4 million shares of its Class A common stock to complete the transactions contemplated by the stock purchase agreement.

[0001571996-17-000004:mdna:277]
In January 2017, VMware's board of directors authorized the repurchase of up to $1.2 billion of shares of VMware's Class A common stock through the end of Fiscal 2018.

[0001571996-17-000004:mdna:278]
For more information regarding share repurchase programs, see Note 18 of Notes to the Consolidated Financial Statements included in this report, and "Part II — Item 5 — Market for Registrant's Common Equity, Related Stockholder Matters and Issuer Purchases of Equity Securities."

[0001571996-17-000004:mdna:279]
Contractual Cash Obligations

[0001571996-17-000004:mdna:280]
The following table summarizes our contractual cash obligations as of February 3, 2017:

[0001571996-17-000004:mdna:281]
|  |  |  | Payments Due by Fiscal Year |
|  | Total |  | 2018 |  | 2019-2020 |  | 2021-2022 |  | Thereafter |
|  | (in millions) |
| Contractual cash obligations: |  |  |  |  |  |  |  |  |  |
| Principal payments on long-term debt | $ | 50,356 |  |  | $ | 6,357 |  |  | $ | 11,842 |  |  | $ | 12,053 |  |  | $ | 20,104 |  |
| Operating leases | 2,156 |  |  | 443 |  |  | 619 |  |  | 355 |  |  | 739 |  |
| Purchase obligations | 2,498 |  |  | 2,279 |  |  | 186 |  |  | 25 |  |  | 8 |  |
| Interest | 17,597 |  |  | 2,091 |  |  | 3,677 |  |  | 2,974 |  |  | 8,855 |  |
| Uncertain tax positions (a) | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Contractual cash obligations | $ | 72,607 |  |  | $ | 11,170 |  |  | $ | 16,324 |  |  | $ | 15,407 |  |  | $ | 29,706 |  |

[0001571996-17-000004:mdna:282]
____________________

[0001571996-17-000004:mdna:283]
| (a) | We have approximately $3.1 billion in additional liabilities associated with uncertain tax positions as of February 3, 2017. We are unable to reliably estimate the expected payment dates for any liabilities for uncertain tax positions. |

[0001571996-17-000004:mdna:284]
Principal Payments on Borrowings — Our expected principal cash payments on borrowings are exclusive of discounts and premiums.  We have outstanding long-term notes with varying maturities.  As of February 3, 2017, the future principal payments related to our structured financing debt were expected to be $2.1 billion in Fiscal 2018, $1.4 billion in Fiscal 2019-2020, and immaterial thereafter.  For additional information about our debt, see Note 8 of the Notes to the Consolidated Financial Statements included in this report.

[0001571996-17-000004:mdna:285]
Interest — See Note 8 of the Notes to the Consolidated Financial Statements included in this report for further discussion of our debt and related interest expense.

[0001571996-17-000004:mdna:286]
Purchase Obligations — Purchase obligations are defined as contractual obligations to purchase goods or services that are enforceable and legally binding on us.  These obligations specify all significant terms, including fixed or minimum quantities to be purchased; fixed, minimum, or variable price provisions; and the approximate timing of the transaction.  Purchase obligations do not include contracts that may be canceled without penalty.

[0001571996-17-000004:mdna:287]
We utilize several suppliers to manufacture sub-assemblies for our products.  Our efficient supply chain management allows us to enter into flexible and mutually beneficial purchase arrangements with our suppliers in order to minimize inventory risk.  Consistent with industry practice, we acquire raw materials or other goods and services, including product components, by issuing to suppliers authorizations to purchase based on our projected demand and manufacturing needs.  These purchase orders are typically fulfilled within 30 days and are entered into during the ordinary course of business in order to establish best pricing and continuity of supply for our production.  Purchase orders are not included in the table above as they typically represent our authorization to purchase rather than binding purchase obligations.

[0001571996-17-000004:mdna:288]
Operating Leases — We lease property and equipment, manufacturing facilities, and office space under non-cancelable leases.  Certain of these leases obligate us to pay taxes, maintenance, and repair costs.

[0001571996-17-000004:mdna:289]
73

[0001571996-17-000004:mdna:290]
Critical Accounting Policies

[0001571996-17-000004:mdna:291]
We prepare our financial statements in conformity with GAAP.  The preparation of financial statements in accordance with GAAP requires certain estimates, assumptions, and judgments to be made that may affect our Consolidated Statements of Financial Position and Consolidated Statements of Income.  Accounting policies that have a significant impact on our Consolidated Financial Statements are described in Note 2 of the Notes to the Consolidated Financial Statements included in this report.  The accounting estimates and assumptions discussed in this section are those that we consider to be the most critical.  We consider an accounting policy to be critical if the nature of the estimate or assumption is subject to a material level of judgment and if changes in those estimates or assumptions are reasonably likely to materially impact our Consolidated Financial Statements.  We have discussed the development, selection, and disclosure of our critical accounting policies with the Audit Committee of our board of directors.

[0001571996-17-000004:mdna:292]
Revenue Recognition and Related Allowances — We enter into contracts to sell our products and services, and frequently enter into sales arrangements with customers that contain multiple elements or deliverables, such as hardware, services, software licenses, and peripherals.  Significant judgments and estimates are necessary for the allocation of the proceeds received from an arrangement to the multiple elements, and the appropriate timing of revenue recognition.

[0001571996-17-000004:mdna:293]
We record reductions to revenue for estimated customer sales returns, rebates, and certain other customer incentive programs.  These reductions to revenue are made based upon reasonable and reliable estimates that are determined by historical experience, contractual terms, and current conditions.  The primary factors affecting our accrual for estimated customer returns include estimated return rates as well as the number of units shipped that have a right of return that has not expired as of the balance sheet date.  If returns cannot be reliably estimated, revenue is not recognized until a reliable estimate can be made or the return right lapses.  Each quarter, we reevaluate our estimates to assess the adequacy of our recorded accruals and allowance for doubtful accounts, and adjust the amounts as necessary.

[0001571996-17-000004:mdna:294]
We sell our products directly to customers as well as through other distribution channels, including retailers, distributors, and resellers.  Sales through our distribution channels are primarily made under agreements allowing for limited rights of return, price protection, rebates, and marketing development funds.  We have generally limited return rights through contractual caps or we have an established selling history for these arrangements.  Therefore, there are sufficient data to establish reasonable and reliable estimates of returns for the majority of these sales.  To the extent price protection or return rights are not limited and a reliable estimate cannot be made, all of the revenue and related costs are deferred until the product has been sold to the end-user or the rights expire.  We record estimated reductions to revenue or an expense for distribution channel programs at the later of the offer or the time revenue is recognized.

[0001571996-17-000004:mdna:295]
Another significant judgment includes determining whether Dell or a reseller is acting as the principal in a transaction.  For arrangements in which a reseller is the principal, revenue is recognized on a net basis.  All other revenue is recognized on a gross basis.

[0001571996-17-000004:mdna:296]
As our business evolves, the mix of products and services sold will impact the timing of when revenue and related costs are recognized.  We analyze various factors, including a review of specific transactions, the credit-worthiness of our customers, our historical experience, and market and economic conditions.  Changes in judgments on these factors could materially impact the timing and amount of revenue and costs recognized.

[0001571996-17-000004:mdna:297]
Business Combinations and Intangible Assets, Including Goodwill — We account for business combinations using the acquisition method of accounting, and, accordingly, the assets and liabilities of the acquired business are recorded at their fair values at the date of acquisition.  The excess of the purchase price over the estimated fair value is recorded as goodwill.  Any changes in the estimated fair values of the net assets recorded for acquisitions prior to the finalization of more detailed analysis, but not to exceed one year from the date of acquisition, will change the amount of the purchase price allocable to goodwill.  The cumulative impact of any subsequent changes to any purchase price allocations that are material to our consolidated financial results will be adjusted in the reporting period in which the adjustment amount is determined.  All acquisition costs are expensed as incurred.  Identifiable intangible assets with finite lives are amortized over their estimated useful lives.  In-process research and development costs are recorded at fair value as an indefinite-lived intangible asset and assessed for impairment thereafter until completion, at which point the asset is amortized over its expected useful life.  Separately recognized transactions associated with business combinations are generally expensed subsequent to the acquisition date.  The application of business combination and impairment accounting requires the use of significant estimates and assumptions.

[0001571996-17-000004:mdna:298]
The results of operations of acquired businesses are included in our Consolidated Financial Statements from the acquisition date.

[0001571996-17-000004:mdna:299]
Goodwill and indefinite-lived intangible assets are tested for impairment annually during the third fiscal quarter and whenever events or circumstances may indicate that an impairment has occurred.  To determine whether goodwill is impaired, we first assess certain qualitative factors.  Based on this assessment, if it is determined more likely than not that the fair value of a reporting unit is less than its carrying amount, we perform the quantitative analysis of the goodwill impairment test.  We determine the fair values of each of our reportable business units using a discounted cash flow methodology and then compare the fair values to the carrying values of each reportable business unit.

[0001571996-17-000004:mdna:300]
Standard Warranty Liabilities — We record warranty liabilities at the time of sale for the estimated costs that may be incurred under the terms of the limited warranty.  The liability for standard warranties is included in accrued and other current and other non-current liabilities on the Consolidated Statements of Financial Position.  The specific warranty terms and conditions vary depending upon the product sold and the country in which we do business, but generally include technical support, parts, and labor over a period ranging from one to three years.  Factors that affect our warranty liability include the number of installed units currently under warranty, historical and anticipated rates of warranty claims on those units, and cost per claim to satisfy our warranty obligation.  The anticipated rate of warranty claims is the primary factor impacting our estimated warranty obligation.  The other factors are less significant due to the fact that the average remaining aggregate warranty period of the covered installed base is approximately 16 months, repair parts are generally already in stock or available at pre-determined prices, and labor rates are generally arranged at pre-established amounts with service providers.  Warranty claims are reasonably predictable based on historical experience of failure rates.  If actual results differ from our estimates, we revise our estimated warranty liability to reflect such changes.  Each quarter, we reevaluate our estimates to assess the adequacy of the recorded warranty liabilities and adjust the amounts as necessary.

[0001571996-17-000004:mdna:301]
Income Taxes — We are subject to income tax in the United States and numerous foreign jurisdictions.  Significant judgments are required in determining the consolidated provision for income taxes.  We calculate a provision for income taxes using the asset and liability method, under which deferred tax assets and liabilities are recognized by identifying the temporary differences arising from the different treatment of items for tax and accounting purposes.  We provide related valuation allowances for deferred tax assets, where appropriate.  Significant judgment is required in determining any valuation allowance against deferred tax assets.  In assessing the need for a valuation allowance, we consider all available evidence for each jurisdiction, including past operating results, estimates of future taxable income, and the feasibility of ongoing tax planning strategies.  In the event we determine all or part of the net deferred tax assets are not realizable in the future, we will make an adjustment to the valuation allowance that would be charged to earnings in the period such determination is made.

[0001571996-17-000004:mdna:302]
Significant judgment is also required in evaluating our uncertain tax positions.  Although we believe our tax return positions are sustainable, we recognize tax benefits from uncertain tax positions in the financial statements only when it is more likely than not that the positions will be sustained upon examination, including resolution of any related appeals or litigation processes, based on the technical merits and a consideration of the relevant taxing authority's administrative practices and precedents.  To the extent that the final tax outcome of these matters is different than the amounts recorded, such differences will impact the provision for income taxes in the period in which such determination is made.  The provision for income taxes includes the impact of reserve provisions and changes to reserves that are considered appropriate, as well as the related net interest and penalties.  We believe we have provided adequate reserves for all uncertain tax positions.

[0001571996-17-000004:mdna:303]
Loss Contingencies — We are subject to the possibility of various losses arising in the ordinary course of business.  We consider the likelihood of loss or impairment of an asset or the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss, in determining loss contingencies.  An estimated loss contingency is accrued when it is probable that an asset has been impaired or a liability has been incurred and the amount of loss can be reasonably estimated.  We regularly evaluate current information available to us to determine whether such accruals should be adjusted and whether new accruals are required.  Third parties have in the past asserted, and may in the future assert, claims or initiate litigation related to exclusive patent, copyright, and other intellectual property rights to technologies and related standards that are relevant to us.  If any infringement or other intellectual property claim made against us by any third party is successful, or if we fail to develop non-infringing technology or license the proprietary rights on commercially reasonable terms and conditions, our business, operating results, and financial condition could be materially and adversely affected.

[0001571996-17-000004:mdna:304]
Inventories — We state our inventory at the lower of cost or market.  We record a write-down for inventories of components and products, including third-party products held for resale, which have become obsolete or are in excess of anticipated demand or net realizable value.  We perform a detailed review of inventory each fiscal quarter that considers multiple factors, including demand forecasts, product life cycle status, product development plans, current sales levels, and component cost trends.  The industries in which we compete are subject to demand changes.  If future demand or market conditions for our products are less

[0001571996-17-000004:mdna:305]
favorable than forecasted or if unforeseen technological changes negatively impact the utility of component inventory, we may be required to record additional write-downs, which would adversely affect our gross margin.

[0001571996-17-000004:mdna:306]
Recently Issued Accounting Pronouncements

[0001571996-17-000004:mdna:307]
See Note 2 of the Notes to the Consolidated Financial Statements included in this report for a summary of recently issued accounting pronouncements that are applicable to our Consolidated Financial Statements.
