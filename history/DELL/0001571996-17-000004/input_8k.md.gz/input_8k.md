# DELL 8-K — 0001193125-17-102777 filed 2017-03-30

## item codes, every 8-K on or before 2017-03-31

- 2017-03-30 0001193125-17-102794 — 8.01
- 2017-03-30 0001193125-17-102777 — 2.02, 9.01
- 2017-03-09 0001193125-17-076981 — 1.01, 2.03, 9.01
- 2017-01-17 0001193125-17-011125 — 8.01
- 2016-12-15 0001193125-16-793722 — 8.01
- 2016-12-08 0001193125-16-787976 — 2.02, 9.01
- 2016-11-10 0001193125-16-765964 — 1.02, 8.01
- 2016-11-04 0001193125-16-760249 — 8.01
- 2016-09-13 0001193125-16-708600 — 3.02
- 2016-09-09 0001193125-16-706567 — 1.01, 1.02, 2.01, 2.03, 3.02, 3.03, 5.02, 9.01
- 2016-09-07 0001193125-16-703370 — 3.03, 5.07, 7.01, 8.01, 9.01
- 2016-09-06 0001193125-16-702057 — 2.02, 9.01
- 2016-08-31 0001193125-16-697268 — 8.01, 9.01
- 2016-08-26 0001193125-16-692921 — 8.01, 9.01
- 2016-07-11 0001193125-16-645610 — 8.01
- 2016-07-05 0001193125-16-641679 — 8.01
- 2016-06-22 0001193125-16-629055 — 1.01, 2.03, 8.01, 9.01
- 2016-06-21 0001193125-16-627071 — 8.01, 9.01
- 2016-06-10 0001193125-16-618483 — 2.02, 9.01
- 2016-06-09 0001193125-16-617893 — 8.01, 9.01

## late-filing notifications on or before 2017-03-31

- none on or before 2017-03-31

## item 2.02 — earnings release, exhibit 99.1

[0001193125-17-102777:8k_2_02:1]
EX-99.1
2
d337810dex991.htm
EX-99.1

[0001193125-17-102777:8k_2_02:2]
EX-99.1

[0001193125-17-102777:8k_2_02:3]
Exhibit 99.1

[0001193125-17-102777:8k_2_02:4]
|  |  | News Release |  |  |

[0001193125-17-102777:8k_2_02:5]
Dell Technologies Reports Fiscal Year 2017 Fourth Quarter and Full Year Financial Results

[0001193125-17-102777:8k_2_02:6]
ROUND ROCK, Texas – March 30, 2017

[0001193125-17-102777:8k_2_02:7]
News
summary

[0001193125-17-102777:8k_2_02:8]
|  | • |  | Fourth quarter revenue of $20.1 billion, with full-year revenue of $61.6 billion |

[0001193125-17-102777:8k_2_02:9]
|  | • |  | Non-GAAP fourth quarter revenue of $20.6 billion, with non-GAAP annual revenue of $62.8 billion |

[0001193125-17-102777:8k_2_02:10]
|  | • |  | Fourth quarter operating loss of $1.7 billion, with non-GAAP operating income of $1.8 billion |

[0001193125-17-102777:8k_2_02:11]
|  | • |  | Fiscal 2017 accomplishments include completion of industry’s largest merger transaction, combined award-winning solutions portfolio, completed announced divestitures and reduced debt |

[0001193125-17-102777:8k_2_02:12]
Full story

[0001193125-17-102777:8k_2_02:13]
Dell Technologies (NYSE: DVMT) announces its
fiscal 2017 fourth quarter and full year results, which reflect the growth and impact of the EMC transaction.

[0001193125-17-102777:8k_2_02:14]
For the fourth quarter, consolidated
revenue from continuing operations was $20.1 billion and non-GAAP revenue from continuing operations was $20.6 billion. During the quarter, the company generated an operating loss of
$1.7 billion, with a non-GAAP operating income of $1.8 billion.

[0001193125-17-102777:8k_2_02:15]
For the full year, consolidated revenue
from continuing operations was $61.6 billion and non-GAAP revenue from continuing operations was $62.8 billion. The company generated an operating loss of $3.3 billion, with a non-GAAP operating income of $5.1 billion.

[0001193125-17-102777:8k_2_02:16]
Due to the EMC transaction as well as the Dell going-private
transaction, significant non-cash bridging items will remain between GAAP and non-GAAP results for the next few years. Prior-year historical Dell Technologies financials
do not include EMC historical results, thereby impacting any year-over-year comparisons.

[0001193125-17-102777:8k_2_02:17]
“I’m pleased with our overall fiscal 2017 performance,
with growth in our client business and positive momentum from investments we’re making in our infrastructure business,” said Tom Sweet, chief financial officer, Dell Technologies Inc. “In our fiscal year 2018, we’ll drive that
momentum forward, beginning with our new sales go-to-market capabilities, and continue to target identified revenue and cost synergies while investing in our broad
portfolio of solutions.”

[0001193125-17-102777:8k_2_02:18]
The company ended the year with a cash and investments balance of $15.3 billion, an increase of
$287 million from the third quarter.

[0001193125-17-102777:8k_2_02:19]
Since closing the EMC transaction, Dell Technologies has paid down approximately $7 billion in debt and
repurchased $824 million of Class V Common Stock under the previously announced Class V Common Stock repurchase programs.

[0001193125-17-102777:8k_2_02:20]
Today the
company also announced the board has approved an amendment to its existing Class V Group Repurchase Program for up to an additional $300 million over six months. The amount will be funded solely through a new VMware Class A Stock
Purchase Agreement with VMware.

[0001193125-17-102777:8k_2_02:21]
Fiscal year 2017 fourth quarter and full year results

[0001193125-17-102777:8k_2_02:22]
|  |  | Three Months Ended |  |  | Change |  |  | Fiscal Year Ended |  |  | Change |  |
|  |  | February 3, 2017 |  |  | January 29, 2016 |  |  |  | February 3, 2017 |  |  | January 29, 2016 |  |  |
|  |  | (in millions, except percentages, unaudited) |  |
| Net revenue |  | $ | 20,074 |  |  | $ | 12,679 |  |  |  | 58 | % |  | $ | 61,642 |  |  | $ | 50,911 |  |  |  | 21 | % |
| Operating loss |  | $ | (1,668 | ) |  | $ | (26 | ) |  |  | NM |  |  | $ | (3,252 | ) |  | $ | (514 | ) |  |  | (533 | )% |
| Net loss from continuing operations |  | $ | (1,414 | ) |  | $ | (168 | ) |  |  | (742 | )% |  | $ | (3,737 | ) |  | $ | (1,168 | ) |  |  | (220 | )% |
| Non-GAAP net revenue |  | $ | 20,581 |  |  | $ | 12,768 |  |  |  | 61 | % |  | $ | 62,822 |  |  | $ | 51,370 |  |  |  | 22 | % |
| Non-GAAP operating income |  | $ | 1,843 |  |  | $ | 655 |  |  |  | 181 | % |  | $ | 5,113 |  |  | $ | 2,225 |  |  |  | 130 | % |
| Non-GAAP net income from continuing operations |  | $ | 1,091 |  |  | $ | 382 |  |  |  | 186 | % |  | $ | 2,687 |  |  | $ | 1,053 |  |  |  | 155 | % |
| Adjusted EBITDA |  | $ | 2,184 |  |  | $ | 753 |  |  |  | 190 | % |  | $ | 5,941 |  |  | $ | 2,633 |  |  |  | 126 | % |

[0001193125-17-102777:8k_2_02:23]
Dell Technologies’ fiscal year 2017 included an additional week, which is incorporated into the company’s fourth
quarter results.

[0001193125-17-102777:8k_2_02:24]
Information about Dell Technologies’ use of non-GAAP financial information is
provided under “Non-GAAP Financial Measures” below. All comparisons in this press release are year over year unless otherwise noted.

[0001193125-17-102777:8k_2_02:25]
Operating segments summary

[0001193125-17-102777:8k_2_02:26]
Client
Solutions Group continued to outgrow the market worldwide for units in both commercial and consumer product categories on a calendar year basis. Revenue for the fiscal fourth quarter was $9.8 billion, up 11 percent versus the fourth
quarter of last year, and revenue for the full year was $36.8 billion, up 2 percent year over fiscal year 2016. Operating income was $342 million for the quarter, and $1.8 billion for the full year.

[0001193125-17-102777:8k_2_02:27]
Key calendar fourth quarter highlights include:

[0001193125-17-102777:8k_2_02:28]
|  | • |  | PC shipments of 11 million, representing the largest volume of products shipped since the fourth quarter of 2011 1 |

[0001193125-17-102777:8k_2_02:29]
|  | • |  | 8.2 percent year-over-year PC shipment increase, the best among the top seven PC vendors, with 16 consecutive quarters of year-over-year PC unit share growth and 150 basis points of unit share gained for the calendar year 1 |

[0001193125-17-102777:8k_2_02:30]
|  | • |  | No. 1 share position worldwide for displays, gaining unit share year-over-year for the 16th consecutive quarter 2 |

[0001193125-17-102777:8k_2_02:31]
Infrastructure Solutions Group generated $8.4 billion of revenue in the fourth
quarter, which includes $3.6 billion in servers and networking and $4.8 billion in storage, and an operating income of $1 billion.

[0001193125-17-102777:8k_2_02:32]
Key calendar fourth quarter highlights:

[0001193125-17-102777:8k_2_02:33]
|  | • |  | Regained the No. 1 worldwide server unit share position driven by strength in the mainstream PowerEdge business 3 |

[0001193125-17-102777:8k_2_02:34]
|  | • |  | No. 1 market share position in all-flash arrays4, which exited 2016 at a more than $4 billion demand run rate |

[0001193125-17-102777:8k_2_02:35]
|  | • |  | The industry’s fastest growing hyperconverged infrastructure vendor during the calendar fourth quarter with more than 300 percent demand growth |

[0001193125-17-102777:8k_2_02:36]
VMware revenue for the fourth quarter was $1.9 billion, with operating income of $565 million, or 29.2 percent of
revenue.

[0001193125-17-102777:8k_2_02:37]
Conference call information

[0001193125-17-102777:8k_2_02:38]
As previously
announced, the company will hold a conference call to discuss its fourth quarter and full-year performance today at 7 a.m. CDT. The conference call will be broadcast live over the internet and can be accessed at
investors.delltechnologies.com. For those unable to listen to the live broadcast, an archived version will be available at the same location for 30 days.

[0001193125-17-102777:8k_2_02:39]
A slide presentation containing additional financial and operating information may be downloaded from Dell Technologies’ website at
investors.delltechnologies.com.

[0001193125-17-102777:8k_2_02:40]
Dell Technologies Investor Meeting

[0001193125-17-102777:8k_2_02:41]
Dell Technologies will host a meeting for investors April 5, 2017, at 1:30 p.m. EDT in New York. The meeting will feature discussions from Chief Financial
Officer Tom Sweet, Infrastructure Solutions Group President David Goulden, and Treasurer Tyler Johnson with a focus on the company’s strategy, integration efforts and capital structure. Due to limited seating, onsite attendance is by invitation
only. A live webcast and replay of the meeting will be available on the event page of Dell Technologies Investor Relations website at investors.delltechnologies.com.

[0001193125-17-102777:8k_2_02:42]
Dell EMC World

[0001193125-17-102777:8k_2_02:43]
Join us May 8-11, 2017 at Dell EMC World in Las Vegas, Dell Technologies’ flagship event, bringing together technology and business professionals to network, share ideas and help
co-create a better future. This is the first time the Dell Technologies family of brands will be all in one place, at one conference. Meet our experts and more than 12,000 IT practitioners and business leaders
who are making Digital Transformation a reality. Learn more at www.dellemcworld.com and follow #DellEMCWorld on Twitter.

[0001193125-17-102777:8k_2_02:44]
About Dell Technologies

[0001193125-17-102777:8k_2_02:45]
Dell Technologies is a unique family of businesses that provides the essential infrastructure for organizations to build their digital future, transform
IT and protect their most important asset, information. The company services customers of all sizes across 180 countries – ranging from 98 percent of the Fortune 500 to individual consumers – with the industry’s most
comprehensive and innovative portfolio from the edge to the core to the cloud.

[0001193125-17-102777:8k_2_02:46]
MEDIA CONTACTS:

[0001193125-17-102777:8k_2_02:47]
Dave Farmer

[0001193125-17-102777:8k_2_02:48]
(508)
293-7206

[0001193125-17-102777:8k_2_02:49]
dave.farmer@dell.com

[0001193125-17-102777:8k_2_02:50]
Lauren Lee

[0001193125-17-102777:8k_2_02:51]
(512)
728-4374

[0001193125-17-102777:8k_2_02:52]
lauren.lee@dell.com

[0001193125-17-102777:8k_2_02:53]
INVESTOR RELATIONS CONTACTS:

[0001193125-17-102777:8k_2_02:54]
Kristy Harris Bias

[0001193125-17-102777:8k_2_02:55]
(512) 728-1658

[0001193125-17-102777:8k_2_02:56]
kristy.harris.bias@dell.com

[0001193125-17-102777:8k_2_02:57]
Karen Litzler-Hollier

[0001193125-17-102777:8k_2_02:58]
(512) 728-0388

[0001193125-17-102777:8k_2_02:59]
karen.litzler-hollie@dell.com

[0001193125-17-102777:8k_2_02:60]
# # #

[0001193125-17-102777:8k_2_02:61]
Copyright © 2017 Dell Inc. or its subsidiaries. All Rights Reserved. Dell, Dell EMC, Dell Inc. and the Dell logo are trademarks of Dell Technologies in the United States and/or other jurisdictions. All
other marks and names mentioned herein may be trademarks of their respective companies.

[0001193125-17-102777:8k_2_02:62]
| 1 | IDC Worldwide Quarterly Personal Computing Device (PCD) Tracker CY16Q4 |

[0001193125-17-102777:8k_2_02:63]
| 2 | IDC Worldwide Quarterly PC Monitor Tracker CY16Q4 |

[0001193125-17-102777:8k_2_02:64]
| 3 | IDC Worldwide Quarterly Server Tracker, March 2017 |

[0001193125-17-102777:8k_2_02:65]
| 4 | IDC Worldwide Quarterly Enterprise Storage Systems Tracker, March 2017 |

[0001193125-17-102777:8k_2_02:66]
Non-GAAP Financial Measures

[0001193125-17-102777:8k_2_02:67]
The press release presents information about the Company’s non-GAAP net revenue, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income from continuing operations, EBITDA and adjusted EBITDA,
which are non-GAAP financial measures provided as a supplement to the results provided in accordance with generally accepted accounting principles in the United States of America (“GAAP”). A
reconciliation of each of the foregoing historical non-GAAP financial measures to the most directly comparable historical GAAP financial measures is provided in the attached tables for each of the fiscal
periods indicated.

[0001193125-17-102777:8k_2_02:68]
Special Note on Forward-Looking Statements:

[0001193125-17-102777:8k_2_02:69]
Dell Technologies’ results or events in future periods could differ materially from those expressed or
implied by these forward-looking statements because of risks, uncertainties, and other factors that include, but are not limited to, the following: competitive pressures; Dell Technologies’ reliance on third-party suppliers for products and
components, including reliance on single-source or limited-source suppliers; Dell Technologies’ ability to achieve favorable pricing from its vendors; adverse global economic conditions and instability in financial markets; Dell
Technologies’ execution of its growth, business and acquisition strategies; the success of Dell Technologies’ cost efficiency measures; Dell Technologies’ ability to manage solutions and products and services transitions in an
effective manner; Dell Technologies’ ability to deliver high-quality products and services; Dell Technologies’ foreign operations and ability to generate substantial non-U.S.net revenue; Dell
Technologies’ product, customer, and geographic sales mix, and seasonal sales trends; the performance of Dell Technologies’ sales channel partners; access to the capital markets by Dell Technologies or its customers; weak economic
conditions and additional regulation; counterparty default risks; the loss by Dell Technologies of any services contracts with its customers, including government contracts, and its ability to perform such contracts at its estimated costs; Dell
Technologies’ ability to develop and protect its proprietary intellectual property or obtain licenses to intellectual property developed by others on commercially reasonable and competitive terms; infrastructure disruptions, cyberattacks, or
other data security breaches; Dell Technologies’ ability to hedge effectively its exposure to fluctuations in foreign currency exchange rates and interest rates; expiration of tax holidays or favorable tax rate structures, or unfavorable
outcomes in tax audits and other tax compliance matters; impairment of portfolio investments; unfavorable results of legal proceedings; increased costs and additional regulations and requirements as a result of Dell Technologies becoming a newly
public company; Dell Technologies’ ability to develop and maintain effective internal control over financial reporting; compliance requirements of changing environmental and safety laws; the effect of armed hostilities, terrorism, natural
disasters, and public health issues; the costs, time, and effort required to be dedicated to the integration of the Dell and EMC businesses; the ability to realize the anticipated synergies from the merger with EMC; the ability to integrate
EMC’s technology, solutions, products, and services with those of Dell in an effective manner; the impact of the financial performance of VMware; and the market volatility of Dell Technologies’ pension plan assets.

[0001193125-17-102777:8k_2_02:70]
This list of risks, uncertainties, and other factors is not complete. Dell Technologies discusses some of these matters more fully, as well as certain risk
factors that could affect the Dell Technologies’ business, financial condition, results of operations, and prospects, in its filings with the Securities and Exchange Commission, including Dell Technologies’ annual report on Form 10-K, which we expect to file on March 31, 2017, and current reports on Form 8-K. These filings are available for review through the Securities and Exchange
Commission’s website at www.sec.gov. Any or all forward-looking statements Dell Technologies makes may turn out to be wrong and can be affected by inaccurate assumptions Dell Technologies might make or by known or unknown risks, uncertainties
and other factors, including those identified in this press release. Accordingly, you should not place undue reliance on the forward-looking statements made in this press release, which speak only as of its date. Dell Technologies does not undertake
to update, and expressly disclaims any duty to update, its forward-looking statements, whether as a result of circumstances or events that arise after the date they are made, new information, or otherwise.

[0001193125-17-102777:8k_2_02:71]
Special Note on the Divestitures:

[0001193125-17-102777:8k_2_02:72]
On
March 27, 2016, Dell entered into a definitive agreement with NTT Data International L.L.C. to sell substantially all of Dell Services for cash consideration of approximately $3.0 billion. On June 19, 2016, Dell entered into a
definitive agreement with Francisco Partners and Elliot Management Corporation to sell substantially all of Dell Software Group for cash consideration of approximately $2.4 billion. On Sept. 12, 2016, EMC Corporation entered into a definitive
agreement with OpenText to divest the Dell EMC Enterprise Content Division, or ECD, for cash consideration of approximately $1.6 billion. Accordingly, the results of operations of Dell Services, Dell Software Group and ECD have been excluded
from the results of continuing operations and from segment results. On October 31, 2016, Dell completed the sale of Dell Software Group. On November 2, 2016, Dell completed substantially all of the sale of Dell Services. The remainder
of the Dell Services transaction closed subsequent to the fiscal year ended February 3, 2017. On January 23, 2017, Dell Technologies completed the sale of ECD.

[0001193125-17-102777:8k_2_02:73]
DELL TECHNOLOGIES INC.

[0001193125-17-102777:8k_2_02:74]
Consolidated Statements of Income (Loss) and Related Financial Highlights

[0001193125-17-102777:8k_2_02:75]
(in millions, except per share amounts and percentages; unaudited)

[0001193125-17-102777:8k_2_02:76]
|  |  | Three Months Ended |  |  |  |  |  | Fiscal Year Ended |  |  |  |  |
|  |  | February 3, 2017 |  |  | January 29, 2016 |  |  | Change |  |  | February 3, 2017 |  |  | January 29, 2016 |  |  | Change |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  | $ | 15,196 |  |  | $ | 10,642 |  |  |  | 43 | % |  | $ | 48,706 |  |  | $ | 42,742 |  |  |  | 14 | % |
| Services |  |  | 4,878 |  |  |  | 2,037 |  |  |  | 139 | % |  |  | 12,936 |  |  |  | 8,169 |  |  |  | 58 | % |
| Total net revenue |  |  | 20,074 |  |  |  | 12,679 |  |  |  | 58 | % |  |  | 61,642 |  |  |  | 50,911 |  |  |  | 21 | % |
| Cost of net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  |  | 13,313 |  |  |  | 9,208 |  |  |  | 45 | % |  |  | 42,169 |  |  |  | 37,563 |  |  |  | 12 | % |
| Services |  |  | 2,230 |  |  |  | 1,217 |  |  |  | 83 | % |  |  | 6,514 |  |  |  | 4,961 |  |  |  | 31 | % |
| Total cost of net revenue |  |  | 15,543 |  |  |  | 10,425 |  |  |  | 49 | % |  |  | 48,683 |  |  |  | 42,524 |  |  |  | 14 | % |
| Gross margin |  |  | 4,531 |  |  |  | 2,254 |  |  |  | 101 | % |  |  | 12,959 |  |  |  | 8,387 |  |  |  | 55 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative |  |  | 4,928 |  |  |  | 2,001 |  |  |  | 146 | % |  |  | 13,575 |  |  |  | 7,850 |  |  |  | 73 | % |
| Research and development |  |  | 1,271 |  |  |  | 279 |  |  |  | 356 | % |  |  | 2,636 |  |  |  | 1,051 |  |  |  | 151 | % |
| Total operating expenses |  |  | 6,199 |  |  |  | 2,280 |  |  |  | 172 | % |  |  | 16,211 |  |  |  | 8,901 |  |  |  | 82 | % |
| Operating loss |  |  | (1,668 | ) |  |  | (26 | ) |  |  | NM |  |  |  | (3,252 | ) |  |  | (514 | ) |  |  | (533 | )% |
| Interest and other, net |  |  | (742 | ) |  |  | (172 | ) |  |  | (331 | )% |  |  | (2,104 | ) |  |  | (772 | ) |  |  | (173 | )% |
| Loss from continuing operations before income taxes |  |  | (2,410 | ) |  |  | (198 | ) |  |  | NM |  |  |  | (5,356 | ) |  |  | (1,286 | ) |  |  | (316 | )% |
| Income tax benefit |  |  | (996 | ) |  |  | (30 | ) |  |  | NM |  |  |  | (1,619 | ) |  |  | (118 | ) |  |  | NM |  |
| Net loss from continuing operations |  |  | (1,414 | ) |  |  | (168 | ) |  |  | (742 | )% |  |  | (3,737 | ) |  |  | (1,168 | ) |  |  | (220 | )% |
| Income from discontinued operations, net of income taxes |  |  | 1,144 |  |  |  | 13 |  |  |  | NM |  |  |  | 2,019 |  |  |  | 64 |  |  |  | NM |  |
| Net loss |  |  | (270 | ) |  |  | (155 | ) |  |  | (74 | )% |  |  | (1,718 | ) |  |  | (1,104 | ) |  |  | (56 | )% |
| Less: Net loss attributable to non-controlling interests |  |  | (34 | ) |  |  | — |  |  |  | NA |  |  |  | (46 | ) |  |  | — |  |  |  | NA |  |
| Net loss attributable to Dell Technologies Inc. |  | $ | (236 | ) |  | $ | (155 | ) |  |  | (52 | )% |  | $ | (1,672 | ) |  | $ | (1,104 | ) |  |  | (51 | )% |
| Earnings (loss) per share attributable to Dell Technologies Inc. - basic: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Continuing operations - Class V Common Stock - basic |  | $ | 0.64 |  |  | $ | — |  |  |  |  |  |  | $ | 1.44 |  |  | $ | — |  |  |  |  |  |
| Continuing operations - DHI Group - basic |  | $ | (2.68 | ) |  | $ | (0.41 | ) |  |  |  |  |  | $ | (8.52 | ) |  | $ | (2.88 | ) |  |  |  |  |
| Discontinued operations - DHI Group - basic |  | $ | 2.02 |  |  | $ | 0.03 |  |  |  |  |  |  | $ | 4.30 |  |  | $ | 0.16 |  |  |  |  |  |
| Earnings (loss) per share attributable to Dell Technologies Inc. - diluted: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Continuing operations - Class V Common Stock - diluted |  | $ | 0.64 |  |  | $ | — |  |  |  |  |  |  | $ | 1.43 |  |  | $ | — |  |  |  |  |  |
| Continuing operations - DHI Group - diluted |  | $ | (2.68 | ) |  | $ | (0.41 | ) |  |  |  |  |  | $ | (8.52 | ) |  | $ | (2.88 | ) |  |  |  |  |
| Discontinued operations - DHI Group - diluted |  | $ | 2.02 |  |  | $ | 0.03 |  |  |  |  |  |  | $ | 4.30 |  |  | $ | 0.16 |  |  |  |  |  |
| Weighted-average shares outstanding: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic - Class V Common Stock |  |  | 215 |  |  |  | — |  |  |  |  |  |  |  | 217 |  |  |  | — |  |  |  |  |  |
| Diluted - Class V Common Stock |  |  | 215 |  |  |  | — |  |  |  |  |  |  |  | 217 |  |  |  | — |  |  |  |  |  |
| Basic - DHI Group |  |  | 566 |  |  |  | 405 |  |  |  |  |  |  |  | 470 |  |  |  | 405 |  |  |  |  |  |
| Diluted - DHI Group |  |  | 566 |  |  |  | 405 |  |  |  |  |  |  |  | 470 |  |  |  | 405 |  |  |  |  |  |
| Percentage of Total Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Gross margin |  |  | 23 | % |  |  | 18 | % |  |  |  |  |  |  | 21 | % |  |  | 16 | % |  |  |  |  |
| Selling, general, and administrative |  |  | 25 | % |  |  | 16 | % |  |  |  |  |  |  | 22 | % |  |  | 15 | % |  |  |  |  |
| Research and development |  |  | 6 | % |  |  | 2 | % |  |  |  |  |  |  | 4 | % |  |  | 2 | % |  |  |  |  |
| Operating expenses |  |  | 31 | % |  |  | 18 | % |  |  |  |  |  |  | 26 | % |  |  | 17 | % |  |  |  |  |
| Operating loss |  |  | (8 | )% |  |  | (0 | )% |  |  |  |  |  |  | (5 | )% |  |  | (1 | )% |  |  |  |  |
| Loss from continuing operations before income taxes |  |  | (12 | )% |  |  | (2 | )% |  |  |  |  |  |  | (9 | )% |  |  | (3 | )% |  |  |  |  |
| Net loss from continuing operations |  |  | (7 | )% |  |  | (1 | )% |  |  |  |  |  |  | (6 | )% |  |  | (2 | )% |  |  |  |  |
| Income tax rate |  |  | 41 | % |  |  | 15 | % |  |  |  |  |  |  | 30 | % |  |  | 9 | % |  |  |  |  |

[0001193125-17-102777:8k_2_02:77]
DELL TECHNOLOGIES INC.

[0001193125-17-102777:8k_2_02:78]
Consolidated Statements of Financial Position

[0001193125-17-102777:8k_2_02:79]
(in millions; unaudited)

[0001193125-17-102777:8k_2_02:80]
|  |  | February 3, 2017 |  |  | January 29, 2016 |  |
| ASSETS |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 9,474 |  |  | $ | 6,322 |  |
| Short-term investments |  |  | 1,975 |  |  |  | — |  |
| Accounts receivable, net |  |  | 9,420 |  |  |  | 4,887 |  |
| Short-term financing receivables, net |  |  | 3,222 |  |  |  | 2,915 |  |
| Inventories, net |  |  | 2,538 |  |  |  | 1,619 |  |
| Other current assets |  |  | 4,144 |  |  |  | 3,497 |  |
| Current assets held for sale |  |  | — |  |  |  | 4,333 |  |
| Total current assets |  |  | 30,773 |  |  |  | 23,573 |  |
| Property, plant, and equipment, net |  |  | 5,653 |  |  |  | 1,649 |  |
| Long-term investments |  |  | 3,802 |  |  |  | 114 |  |
| Long-term financing receivables, net |  |  | 2,651 |  |  |  | 2,177 |  |
| Goodwill |  |  | 38,910 |  |  |  | 8,406 |  |
| Intangible assets, net |  |  | 35,053 |  |  |  | 8,577 |  |
| Other non-current assets |  |  | 1,364 |  |  |  | 626 |  |
| Total assets |  | $ | 118,206 |  |  | $ | 45,122 |  |
| LIABILITIES, REDEEMABLE SHARES, AND STOCKHOLDERS’ EQUITY |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term debt |  | $ | 6,329 |  |  | $ | 2,981 |  |
| Accounts payable |  |  | 14,422 |  |  |  | 12,881 |  |
| Accrued and other |  |  | 7,119 |  |  |  | 4,217 |  |
| Short-term deferred revenue |  |  | 10,265 |  |  |  | 3,632 |  |
| Current liabilities held for sale |  |  | — |  |  |  | 1,599 |  |
| Total current liabilities |  |  | 38,135 |  |  |  | 25,310 |  |
| Long-term debt |  |  | 43,061 |  |  |  | 10,650 |  |
| Long-term deferred revenue |  |  | 8,431 |  |  |  | 4,089 |  |
| Other non-current liabilities |  |  | 9,339 |  |  |  | 3,501 |  |
| Total liabilities |  |  | 98,966 |  |  |  | 43,550 |  |
| Redeemable shares |  |  | 231 |  |  |  | 106 |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Total Dell Technologies Inc. stockholders’ equity |  |  | 13,243 |  |  |  | 1,466 |  |
| Non-controlling interests |  |  | 5,766 |  |  |  | — |  |
| Total stockholders’ equity |  |  | 19,009 |  |  |  | 1,466 |  |
| Total liabilities, redeemable shares, and stockholders’ equity |  | $ | 118,206 |  |  | $ | 45,122 |  |

[0001193125-17-102777:8k_2_02:81]
DELL TECHNOLOGIES INC.

[0001193125-17-102777:8k_2_02:82]
Consolidated Statements of Cash Flows

[0001193125-17-102777:8k_2_02:83]
(in millions; unaudited)

[0001193125-17-102777:8k_2_02:84]
|  |  | Three Months Ended |  |  | Fiscal Year Ended |  |
|  |  | February 3, 2017 |  |  | January 29, 2016 |  |  | February 3, 2017 |  |  | January 29, 2016 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net loss |  | $ | (270 | ) |  | $ | (155 | ) |  | $ | (1,718 | ) |  | $ | (1,104 | ) |
| Adjustments to reconcile net loss to net cash provided by operating activities |  |  | 946 |  |  |  | 1,126 |  |  |  | 3,940 |  |  |  | 3,266 |  |
| Change in cash from operating activities |  |  | 676 |  |  |  | 971 |  |  |  | 2,222 |  |  |  | 2,162 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Purchases |  |  | (267 | ) |  |  | (1 | ) |  |  | (778 | ) |  |  | (27 | ) |
| Maturities and sales |  |  | 612 |  |  |  | 6 |  |  |  | 1,173 |  |  |  | 7 |  |
| Capital expenditures |  |  | (282 | ) |  |  | (142 | ) |  |  | (699 | ) |  |  | (482 | ) |
| Proceeds from sale of facilities, land, and other assets |  |  | — |  |  |  | — |  |  |  | 24 |  |  |  | 88 |  |
| Capitalized software development costs |  |  | (122 | ) |  |  | — |  |  |  | (207 | ) |  |  | — |  |
| Collections on purchased financing receivables |  |  | 4 |  |  |  | 14 |  |  |  | 35 |  |  |  | 85 |  |
| Acquisition of businesses, net of cash acquired |  |  | (15 | ) |  |  | — |  |  |  | (37,629 | ) |  |  | — |  |
| Divestitures of businesses, net of cash transferred |  |  | 6,873 |  |  |  | — |  |  |  | 6,873 |  |  |  | 8 |  |
| Other |  |  | — |  |  |  | — |  |  |  | (48 | ) |  |  | — |  |
| Change in cash from investing activities |  |  | 6,803 |  |  |  | (123 | ) |  |  | (31,256 | ) |  |  | (321 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Payment of dissenting shares obligation |  |  | — |  |  |  | — |  |  |  | (446 | ) |  |  | — |  |
| Proceeds from the issuance of DHI Group Common Stock |  |  | 18 |  |  |  | — |  |  |  | 4,422 |  |  |  | — |  |
| Proceeds from the issuance of common stock of subsidiaries |  |  | 63 |  |  |  | — |  |  |  | 164 |  |  |  | — |  |
| Repurchases of DHI Group Common Stock |  |  | — |  |  |  | — |  |  |  | (10 | ) |  |  | — |  |
| Repurchases of Class V Common Stock |  |  | (569 | ) |  |  | — |  |  |  | (701 | ) |  |  | — |  |
| Repurchases of VMware Class A Common Stock |  |  | — |  |  |  | — |  |  |  | (611 | ) |  |  | — |  |
| Issuance of common stock under employee plans |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 2 |  |
| Payments for debt issuance costs |  |  | (4 | ) |  |  | — |  |  |  | (853 | ) |  |  | (10 | ) |
| Proceeds from debt |  |  | 907 |  |  |  | 567 |  |  |  | 46,893 |  |  |  | 5,460 |  |
| Repayments of debt |  |  | (7,322 | ) |  |  | (742 | ) |  |  | (16,960 | ) |  |  | (5,950 | ) |
| Other |  |  | 5 |  |  |  | — |  |  |  | 10 |  |  |  | 2 |  |
| Change in cash from financing activities |  |  | (6,902 | ) |  |  | (175 | ) |  |  | 31,908 |  |  |  | (496 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  |  | (7 | ) |  |  | (79 | ) |  |  | 24 |  |  |  | (167 | ) |
| Change in cash and cash equivalents |  |  | 570 |  |  |  | 594 |  |  |  | 2,898 |  |  |  | 1,178 |  |
| Cash and cash equivalents at beginning of the period, including amounts held for sale |  |  | 8,904 |  |  |  | 5,982 |  |  |  | 6,576 |  |  |  | 5,398 |  |
| Cash and cash equivalents at end of the period |  | $ | 9,474 |  |  | $ | 6,576 |  |  | $ | 9,474 |  |  | $ | 6,576 |  |
| Less: Cash included in current assets held for sale |  |  | — |  |  |  | 254 |  |  |  | — |  |  |  | 254 |  |
| Cash and cash equivalents from continuing operations |  | $ | 9,474 |  |  | $ | 6,322 |  |  | $ | 9,474 |  |  | $ | 6,322 |  |

[0001193125-17-102777:8k_2_02:85]
DELL TECHNOLOGIES INC.

[0001193125-17-102777:8k_2_02:86]
Segment Information

[0001193125-17-102777:8k_2_02:87]
(in
millions, except percentages; unaudited)

[0001193125-17-102777:8k_2_02:88]
|  |  | Three Months Ended |  |  |  |  |  | Fiscal Year Ended |  |  |  |  |
|  |  | February 3, 2017 |  |  | January 29, 2016 |  |  | Change |  |  | February 3, 2017 |  |  | January 29, 2016 |  |  | Change |  |
| Client Solutions Group (CSG): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial |  | $ | 6,663 |  |  | $ | 5,969 |  |  |  | 12 | % |  | $ | 26,006 |  |  | $ | 25,747 |  |  |  | 1 | % |
| Consumer |  |  | 3,113 |  |  |  | 2,868 |  |  |  | 9 | % |  |  | 10,748 |  |  |  | 10,130 |  |  |  | 6 | % |
| Total CSG net revenue |  | $ | 9,776 |  |  | $ | 8,837 |  |  |  | 11 | % |  | $ | 36,754 |  |  | $ | 35,877 |  |  |  | 2 | % |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| CSG operating income |  | $ | 342 |  |  | $ | 484 |  |  |  | (29 | )% |  | $ | 1,845 |  |  | $ | 1,410 |  |  |  | 31 | % |
| % of CSG net revenue |  |  | 3 | % |  |  | 5 | % |  |  |  |  |  |  | 5 | % |  |  | 4 | % |  |  |  |  |
| % of total segment operating income |  |  | 18 | % |  |  | 64 | % |  |  |  |  |  |  | 34 | % |  |  | 57 | % |  |  |  |  |
| Infrastructure Solutions Group (ISG): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Servers and networking |  | $ | 3,612 |  |  | $ | 3,234 |  |  |  | 12 | % |  | $ | 12,834 |  |  | $ | 12,761 |  |  |  | 1 | % |
| Storage |  |  | 4,783 |  |  |  | 562 |  |  |  | 751 | % |  |  | 8,942 |  |  |  | 2,217 |  |  |  | 303 | % |
| Total ISG net revenue |  | $ | 8,395 |  |  | $ | 3,796 |  |  |  | 121 | % |  | $ | 21,776 |  |  | $ | 14,978 |  |  |  | 45 | % |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| ISG operating income |  | $ | 1,004 |  |  | $ | 276 |  |  |  | 264 | % |  | $ | 2,393 |  |  | $ | 1,052 |  |  |  | 127 | % |
| % of ISG net revenue |  |  | 12 | % |  |  | 7 | % |  |  |  |  |  |  | 11 | % |  |  | 7 | % |  |  |  |  |
| % of total segment operating income |  |  | 53 | % |  |  | 36 | % |  |  |  |  |  |  | 45 | % |  |  | 43 | % |  |  |  |  |
| VMware: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total VMware net revenue |  | $ | 1,936 |  |  | $ | — |  |  |  | NA |  |  | $ | 3,225 |  |  | $ | — |  |  |  | NA |  |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| VMware operating income |  | $ | 565 |  |  | $ | — |  |  |  | NA |  |  | $ | 1,113 |  |  | $ | — |  |  |  | NA |  |
| % of VMware net revenue |  |  | 29 | % |  |  | NA |  |  |  |  |  |  |  | 35 | % |  |  | NA |  |  |  |  |  |
| % of total segment operating income |  |  | 30 | % |  |  | NA |  |  |  |  |  |  |  | 21 | % |  |  | NA |  |  |  |  |  |
| Reconciliation to consolidated net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Reportable segment net revenue |  | $ | 20,107 |  |  | $ | 12,633 |  |  |  |  |  |  | $ | 61,755 |  |  | $ | 50,855 |  |  |  |  |  |
| Other businesses (a) |  |  | 480 |  |  |  | 107 |  |  |  |  |  |  |  | 1,026 |  |  |  | 382 |  |  |  |  |  |
| Unallocated transactions (b) |  |  | (6 | ) |  |  | 28 |  |  |  |  |  |  |  | 41 |  |  |  | 133 |  |  |  |  |  |
| Impact of purchase accounting (c) |  |  | (507 | ) |  |  | (89 | ) |  |  |  |  |  |  | (1,180 | ) |  |  | (459 | ) |  |  |  |  |
| Total net revenue |  | $ | 20,074 |  |  | $ | 12,679 |  |  |  |  |  |  | $ | 61,642 |  |  | $ | 50,911 |  |  |  |  |  |
| Reconciliation to consolidated operating income (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Reportable segment operating income |  | $ | 1,911 |  |  | $ | 760 |  |  |  |  |  |  | $ | 5,351 |  |  | $ | 2,462 |  |  |  |  |  |
| Other businesses (a) |  |  | (3 | ) |  |  | (16 | ) |  |  |  |  |  |  | (39 | ) |  |  | (78 | ) |  |  |  |  |
| Unallocated transactions (b) |  |  | (65 | ) |  |  | (89 | ) |  |  |  |  |  |  | (199 | ) |  |  | (159 | ) |  |  |  |  |
| Impact of purchase accounting (c) |  |  | (1,240 | ) |  |  | (129 | ) |  |  |  |  |  |  | (2,294 | ) |  |  | (604 | ) |  |  |  |  |
| Amortization of intangibles |  |  | (1,535 | ) |  |  | (491 | ) |  |  |  |  |  |  | (3,681 | ) |  |  | (1,969 | ) |  |  |  |  |
| Transaction-related expenses (d) |  |  | (159 | ) |  |  | (42 | ) |  |  |  |  |  |  | (1,488 | ) |  |  | (109 | ) |  |  |  |  |
| Other corporate expenses (e) |  |  | (577 | ) |  |  | (19 | ) |  |  |  |  |  |  | (902 | ) |  |  | (57 | ) |  |  |  |  |
| Total operating loss |  | $ | (1,668 | ) |  | $ | (26 | ) |  |  |  |  |  | $ | (3,252 | ) |  | $ | (514 | ) |  |  |  |  |

[0001193125-17-102777:8k_2_02:89]
| (a) | Other businesses consist of RSA Information Security, SecureWorks, Pivotal, and Boomi offerings, and do not constitute a reportable segment, either individually or collectively, as the results of the businesses are not material to the Company’s overall results and the businesses do not meet the criteria for reportable segments. |

[0001193125-17-102777:8k_2_02:90]
| (b) | Unallocated transactions includes long-term incentives, certain short-term incentive compensation expenses, and other corporate items that are not allocated to Dell Technologies’ reportable segments. |

[0001193125-17-102777:8k_2_02:91]
| (c) | Impact of purchase accounting includes non-cash purchase accounting adjustments that are primarily related to the EMC merger transaction, as well as the going-private transaction. |

[0001193125-17-102777:8k_2_02:92]
| (d) | Transaction-related expenses includes acquisition and integration-related costs. |

[0001193125-17-102777:8k_2_02:93]
| (e) | Other corporate expenses includes severance and facility action costs as well as stock-based compensation expense. |

[0001193125-17-102777:8k_2_02:94]
SUPPLEMENTAL SELECTED NON-GAAP FINANCIAL MEASURES

[0001193125-17-102777:8k_2_02:95]
These tables present information about the Company’s non-GAAP net revenue, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net
income from continuing operations, EBITDA, and adjusted EBITDA, which are non-GAAP financial measures provided as a supplement to the results provided in accordance with generally accepted accounting
principles in the United States of America (“GAAP”). A detailed discussion of Dell Technologies’ reasons for including these non-GAAP financial measures, the limitations associated with these
measures, the items excluded from these measures, and our reason for excluding those items are presented in “Management’s Discussion and Analysis of Financial Condition and Results of Operations -
Non-GAAP Financial Measures” in our periodic reports filed with the SEC. Dell Technologies encourages investors to review the non-GAAP discussion in conjunction
with the presentation of non-GAAP financial measures.

[0001193125-17-102777:8k_2_02:96]
DELL TECHNOLOGIES INC.

[0001193125-17-102777:8k_2_02:97]
Selected Non-GAAP Financial Measures

[0001193125-17-102777:8k_2_02:98]
(in millions, except percentages; unaudited)

[0001193125-17-102777:8k_2_02:99]
|  |  | Three Months Ended |  |  |  |  |  | Fiscal Year Ended |  |  |  |  |
|  |  | February 3, 2017 |  |  | January 29, 2016 |  |  | Change |  |  | February 3, 2017 |  |  | January 29, 2016 |  |  | Change |  |
| Non-GAAP net revenue |  | $ | 20,581 |  |  | $ | 12,768 |  |  |  | 61 | % |  | $ | 62,822 |  |  | $ | 51,370 |  |  |  | 22 | % |
| Non-GAAP gross margin |  | $ | 6,595 |  |  | $ | 2,458 |  |  |  | 168 | % |  | $ | 16,819 |  |  | $ | 9,307 |  |  |  | 81 | % |
| % of non-GAAP net revenue |  |  | 32 | % |  |  | 19 | % |  |  |  |  |  |  | 27 | % |  |  | 18 | % |  |  |  |  |
| Non-GAAP operating expenses |  | $ | 4,752 |  |  | $ | 1,803 |  |  |  | 164 | % |  | $ | 11,706 |  |  | $ | 7,082 |  |  |  | 65 | % |
| % of non-GAAP net revenue |  |  | 23 | % |  |  | 14 | % |  |  |  |  |  |  | 19 | % |  |  | 14 | % |  |  |  |  |
| Non-GAAP operating income |  | $ | 1,843 |  |  | $ | 655 |  |  |  | 181 | % |  | $ | 5,113 |  |  | $ | 2,225 |  |  |  | 130 | % |
| % of non-GAAP net revenue |  |  | 9 | % |  |  | 5 | % |  |  |  |  |  |  | 8 | % |  |  | 4 | % |  |  |  |  |
| Non-GAAP net income from continuing operations |  | $ | 1,091 |  |  | $ | 382 |  |  |  | 186 | % |  | $ | 2,687 |  |  | $ | 1,053 |  |  |  | 155 | % |
| % of non-GAAP net revenue |  |  | 5 | % |  |  | 3 | % |  |  |  |  |  |  | 4 | % |  |  | 2 | % |  |  |  |  |
| Adjusted EBITDA |  | $ | 2,184 |  |  | $ | 753 |  |  |  | 190 | % |  | $ | 5,941 |  |  | $ | 2,633 |  |  |  | 126 | % |
| % of non-GAAP net revenue |  |  | 11 | % |  |  | 6 | % |  |  |  |  |  |  | 9 | % |  |  | 5 | % |  |  |  |  |

[0001193125-17-102777:8k_2_02:100]
DELL TECHNOLOGIES INC.

[0001193125-17-102777:8k_2_02:101]
Reconciliation of Selected Non-GAAP Financial Measures

[0001193125-17-102777:8k_2_02:102]
(in millions, except percentages; unaudited)

[0001193125-17-102777:8k_2_02:103]
|  |  | Three Months Ended |  |  |  |  |  | Fiscal Year Ended |  |  |  |  |
|  |  | February 3, 2017 |  |  | January 29, 2016 |  |  | Change |  |  | February 3, 2017 |  |  | January 29, 2016 |  |  | Change |  |
| Net revenue |  | $ | 20,074 |  |  | $ | 12,679 |  |  |  | 58 | % |  | $ | 61,642 |  |  | $ | 50,911 |  |  |  | 21 | % |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting |  |  | 507 |  |  |  | 89 |  |  |  |  |  |  |  | 1,180 |  |  |  | 459 |  |  |  |  |  |
| Non-GAAP net revenue |  | $ | 20,581 |  |  | $ | 12,768 |  |  |  | 61 | % |  | $ | 62,822 |  |  | $ | 51,370 |  |  |  | 22 | % |
| Gross margin |  | $ | 4,531 |  |  | $ | 2,254 |  |  |  | 101 | % |  | $ | 12,959 |  |  | $ | 8,387 |  |  |  | 55 | % |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting |  |  | 1,110 |  |  |  | 104 |  |  |  |  |  |  |  | 2,007 |  |  |  | 512 |  |  |  |  |  |
| Amortization of intangibles |  |  | 847 |  |  |  | 97 |  |  |  |  |  |  |  | 1,653 |  |  |  | 392 |  |  |  |  |  |
| Transaction-related expenses |  |  | 18 |  |  |  | — |  |  |  |  |  |  |  | 43 |  |  |  | 6 |  |  |  |  |  |
| Other corporate expenses |  |  | 89 |  |  |  | 3 |  |  |  |  |  |  |  | 157 |  |  |  | 10 |  |  |  |  |  |
| Non-GAAP gross margin |  | $ | 6,595 |  |  | $ | 2,458 |  |  |  | 168 | % |  | $ | 16,819 |  |  | $ | 9,307 |  |  |  | 81 | % |
| Operating expenses |  | $ | 6,199 |  |  | $ | 2,280 |  |  |  | 172 | % |  | $ | 16,211 |  |  | $ | 8,901 |  |  |  | 82 | % |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting |  |  | (130 | ) |  |  | (25 | ) |  |  |  |  |  |  | (287 | ) |  |  | (92 | ) |  |  |  |  |
| Amortization of intangibles |  |  | (688 | ) |  |  | (394 | ) |  |  |  |  |  |  | (2,028 | ) |  |  | (1,577 | ) |  |  |  |  |
| Transaction-related expenses |  |  | (141 | ) |  |  | (42 | ) |  |  |  |  |  |  | (1,445 | ) |  |  | (103 | ) |  |  |  |  |
| Other corporate expenses |  |  | (488 | ) |  |  | (16 | ) |  |  |  |  |  |  | (745 | ) |  |  | (47 | ) |  |  |  |  |
| Non-GAAP operating expenses |  | $ | 4,752 |  |  | $ | 1,803 |  |  |  | 164 | % |  | $ | 11,706 |  |  | $ | 7,082 |  |  |  | 65 | % |
| Operating loss |  | $ | (1,668 | ) |  | $ | (26 | ) |  |  | NM |  |  | $ | (3,252 | ) |  | $ | (514 | ) |  |  | (533 | )% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting |  |  | 1,240 |  |  |  | 129 |  |  |  |  |  |  |  | 2,294 |  |  |  | 604 |  |  |  |  |  |
| Amortization of intangibles |  |  | 1,535 |  |  |  | 491 |  |  |  |  |  |  |  | 3,681 |  |  |  | 1,969 |  |  |  |  |  |
| Transaction-related expenses |  |  | 159 |  |  |  | 42 |  |  |  |  |  |  |  | 1,488 |  |  |  | 109 |  |  |  |  |  |
| Other corporate expenses |  |  | 577 |  |  |  | 19 |  |  |  |  |  |  |  | 902 |  |  |  | 57 |  |  |  |  |  |
| Non-GAAP operating income |  | $ | 1,843 |  |  | $ | 655 |  |  |  | 181 | % |  | $ | 5,113 |  |  | $ | 2,225 |  |  |  | 130 | % |
| Net loss from continuing operations |  | $ | (1,414 | ) |  | $ | (168 | ) |  |  | (742 | )% |  | $ | (3,737 | ) |  | $ | (1,168 | ) |  |  | (220 | )% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting |  |  | 1,240 |  |  |  | 129 |  |  |  |  |  |  |  | 2,294 |  |  |  | 604 |  |  |  |  |  |
| Amortization of intangibles |  |  | 1,535 |  |  |  | 491 |  |  |  |  |  |  |  | 3,681 |  |  |  | 1,969 |  |  |  |  |  |
| Transaction-related expenses |  |  | 159 |  |  |  | 42 |  |  |  |  |  |  |  | 1,485 |  |  |  | 83 |  |  |  |  |  |
| Other corporate expenses |  |  | 577 |  |  |  | 19 |  |  |  |  |  |  |  | 902 |  |  |  | 77 |  |  |  |  |  |
| Aggregate adjustment for income taxes |  |  | (1,006 | ) |  |  | (131 | ) |  |  |  |  |  |  | (1,938 | ) |  |  | (512 | ) |  |  |  |  |
| Non-GAAP net income from continuing operations |  | $ | 1,091 |  |  | $ | 382 |  |  |  | 186 | % |  | $ | 2,687 |  |  | $ | 1,053 |  |  |  | 155 | % |
| Net loss from continuing operations |  | $ | (1,414 | ) |  | $ | (168 | ) |  |  | (742 | )% |  | $ | (3,737 | ) |  | $ | (1,168 | ) |  |  | (220 | )% |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest and other, net |  |  | 742 |  |  |  | 172 |  |  |  |  |  |  |  | 2,104 |  |  |  | 772 |  |  |  |  |  |
| Income tax benefit |  |  | (996 | ) |  |  | (30 | ) |  |  |  |  |  |  | (1,619 | ) |  |  | (118 | ) |  |  |  |  |
| Depreciation and amortization |  |  | 2,041 |  |  |  | 623 |  |  |  |  |  |  |  | 4,840 |  |  |  | 2,494 |  |  |  |  |  |
| EBITDA |  | $ | 373 |  |  | $ | 597 |  |  |  | (38 | )% |  | $ | 1,588 |  |  | $ | 1,980 |  |  |  | (20 | )% |
| EBITDA |  | $ | 373 |  |  | $ | 597 |  |  |  | (38 | )% |  | $ | 1,588 |  |  | $ | 1,980 |  |  |  | (20 | )% |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense |  |  | 215 |  |  |  | 17 |  |  |  |  |  |  |  | 392 |  |  |  | 63 |  |  |  |  |  |
| Impact of purchase accounting |  |  | 1,075 |  |  |  | 95 |  |  |  |  |  |  |  | 1,926 |  |  |  | 487 |  |  |  |  |  |
| Transaction-related expenses |  |  | 159 |  |  |  | 42 |  |  |  |  |  |  |  | 1,525 |  |  |  | 83 |  |  |  |  |  |
| Other corporate expenses |  |  | 362 |  |  |  | 2 |  |  |  |  |  |  |  | 510 |  |  |  | 20 |  |  |  |  |  |
| Adjusted EBITDA |  | $ | 2,184 |  |  | $ | 753 |  |  |  | 190 | % |  | $ | 5,941 |  |  | $ | 2,633 |  |  |  | 126 | % |
