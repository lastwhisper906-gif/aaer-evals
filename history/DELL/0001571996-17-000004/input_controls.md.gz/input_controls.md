# DELL 10-K controls and the auditor's report


## auditors_report

10-K auditors_report: 2 candidate headings, none whose body matches 'critical audit matter'.


## item_9a

[0001571996-17-000004:item_9a:1]
ITEM 9A — CONTROLS AND PROCEDURES

[0001571996-17-000004:item_9a:2]
This report includes the certifications of our Chief Executive Officer and Chief Financial Officer required by Rule 13a-14 under the Securities Exchange Act of 1934, or Exchange Act.  See Exhibits 31.1 and 31.2 filed with this report.  This Item 9A includes information concerning the controls and control evaluations referred to in those certifications.

[0001571996-17-000004:item_9a:3]
This annual report does not include a report of management's assessment regarding internal control over financial reporting or an attestation report of our registered public accounting firm in reliance on the transition period exemption established by SEC rules for newly public companies.

[0001571996-17-000004:item_9a:4]
Evaluation of Disclosure Controls and Procedures

[0001571996-17-000004:item_9a:5]
Disclosure controls and procedures (as defined in Rules 13a-15(e) and 15d-15(e) under the Exchange Act) are designed to ensure that information required to be disclosed in reports filed or submitted under the Exchange Act is recorded, processed, summarized, and reported within the time periods specified in SEC rules and forms and that such information is accumulated and communicated to management, including the chief executive officer and the chief financial officer, to allow timely decisions regarding required disclosures.

[0001571996-17-000004:item_9a:6]
In connection with the preparation of this report, our management, under the supervision and with the participation of our Chief Executive Officer and Chief Financial Officer, conducted an evaluation of the effectiveness of the design and operation of our disclosure controls and procedures as of February 3, 2017.  Based on that evaluation, our management has concluded that our disclosure controls and procedures were effective as of February 3, 2017.

[0001571996-17-000004:item_9a:7]
Changes in Internal Control over Financial Reporting

[0001571996-17-000004:item_9a:8]
On September 7, 2016, we completed our acquisition by merger of EMC Corporation as described elsewhere in this report.  Revenues of approximately $9.2 billion and net loss of approximately $2.1 billion attributable to EMC were included in the Consolidated Statements of Income (Loss) for the period from September 7, 2016 through February 3, 2017.

[0001571996-17-000004:item_9a:9]
We continue to integrate policies, processes, people, technology, and operations relating to this transaction, and will continue to evaluate the impact of any related changes to our internal control over financial reporting.  Except for any changes related to the integration of EMC, there were no changes in our internal control over financial reporting during the fiscal quarter ended February 3, 2017 that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.
