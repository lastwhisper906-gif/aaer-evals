# DELL 8-K — 0001571996-22-000004 filed 2022-02-24

## item codes, every 8-K on or before 2022-03-24

- 2022-02-24 0001571996-22-000004 — 2.02, 8.01, 9.01
- 2021-12-20 0001193125-21-362482 — 8.01, 9.01
- 2021-12-15 0001193125-21-357927 — 1.01, 2.03, 9.01
- 2021-12-07 0001193125-21-349218 — 8.01, 9.01
- 2021-11-23 0001571996-21-000060 — 2.02, 9.01
- 2021-11-05 0001571996-21-000057 — 1.02, 2.01, 7.01, 8.01, 9.01 — amendment, the index does not say of what
- 2021-11-01 0001571996-21-000052 — 8.01, 9.01
- 2021-11-01 0001193125-21-315488 — 1.01, 1.02, 2.01, 8.01, 9.01
- 2021-10-21 0001193125-21-304052 — 8.01, 9.01
- 2021-10-19 0001571996-21-000050 — 8.01, 9.01
- 2021-10-07 0001193125-21-294210 — 8.01, 9.01
- 2021-09-30 0001571996-21-000047 — 5.02
- 2021-09-27 0001571996-21-000045 — 8.01
- 2021-09-23 0001193125-21-280190 — 7.01, 8.01, 9.01
- 2021-09-20 0001193125-21-276810 — 7.01, 9.01
- 2021-08-26 0001571996-21-000037 — 2.02, 9.01
- 2021-07-01 0001571996-21-000034 — 3.02
- 2021-06-24 0001571996-21-000031 — 5.07
- 2021-06-24 0001193125-21-197644 — 7.01, 9.01
- 2021-06-16 0001571996-21-000029 — 5.02
- 2021-05-27 0001571996-21-000019 — 2.02, 9.01
- 2021-05-03 0001571996-21-000010 — 8.01, 9.01
- 2021-04-14 0001193125-21-116271 — 1.01, 7.01, 9.01
- 2021-02-25 0001571996-21-000003 — 2.02, 9.01
- 2021-02-18 0001193125-21-047844 — 1.01, 2.03, 9.01
- 2020-11-24 0001571996-20-000048 — 2.02, 9.01
- 2020-08-27 0001571996-20-000041 — 2.02, 9.01
- 2020-07-02 0001571996-20-000037 — 5.07
- 2020-05-28 0001571996-20-000028 — 2.02, 9.01
- 2020-04-09 0001193125-20-102602 — 1.01, 2.03, 9.01
- 2020-04-08 0001571996-20-000021 — 5.02
- 2020-04-03 0001571996-20-000019 — 8.01, 9.01
- 2020-03-26 0001571996-20-000015 — 7.01
- 2020-02-27 0001571996-20-000009 — 2.02, 8.01, 9.01
- 2020-02-18 0001571996-20-000005 — 8.01, 9.01
- 2020-01-09 0001571996-20-000002 — 3.02
- 2020-01-06 0001193125-20-002200 — 3.02
- 2019-12-13 0001193125-19-313947 — 3.02
- 2019-12-10 0001571996-19-000052 — 5.02
- 2019-12-02 0001571996-19-000044 — 5.02, 7.01, 9.01
- 2019-11-26 0001571996-19-000042 — 2.02, 9.01
- 2019-09-23 0001193125-19-252192 — 1.01, 2.03, 9.01
- 2019-08-29 0001571996-19-000036 — 2.02, 9.01
- 2019-08-22 0001193125-19-226939 — 7.01, 8.01, 9.01
- 2019-07-11 0001571996-19-000032 — 5.02, 5.07, 9.01
- 2019-07-03 0001571996-19-000030 — 3.02
- 2019-06-27 0001571996-19-000028 — 3.02
- 2019-05-30 0001571996-19-000021 — 2.02, 9.01
- 2019-04-02 0001571996-19-000010 — 5.02
- 2019-03-21 0001193125-19-082281 — 1.01, 1.02, 2.03, 9.01
- 2019-03-19 0001571996-19-000005 — 5.02, 9.01
- 2019-03-14 0001193125-19-074935 — 1.01, 2.03, 9.01
- 2019-03-07 0001193125-19-066045 — 8.01, 9.01
- 2019-02-28 0001571996-19-000002 — 2.02, 9.01
- 2018-12-28 0001193125-18-360943 — 1.01, 1.02, 3.01, 3.03, 5.02, 5.03, 7.01, 8.01, 9.01
- 2018-12-21 0001193125-18-356324 — 1.01, 2.03, 9.01
- 2018-12-14 0001193125-18-349469 — 8.01
- 2018-12-11 0001193125-18-346958 — 5.07, 8.01, 9.01
- 2018-11-29 0001571996-18-000041 — 2.02, 9.01
- 2018-11-28 0001571996-18-000037 — 7.01, 8.01, 9.01
- 2018-11-26 0001193125-18-333967 — 8.01, 9.01
- 2018-11-15 0001193125-18-328110 — 1.01, 9.01 — amendment of 0001193125-18-327222
- 2018-11-15 0001193125-18-327222 — 1.01, 7.01, 9.01
- 2018-10-03 0001193125-18-291390 — 8.01
- 2018-09-06 0001571996-18-000029 — 2.02, 9.01
- 2018-08-06 0001571996-18-000027 — 8.01, 9.01
- 2018-07-02 0001193125-18-210339 — 1.01, 7.01, 9.01
- 2018-06-28 0001571996-18-000024 — 5.07
- 2018-06-04 0001571996-18-000019 — 2.02, 9.01
- 2018-05-17 0001571996-18-000016 — 7.01
- 2018-04-26 0001571996-18-000009 — 7.01, 9.01
- 2018-03-08 0001193125-18-074168 — 2.02, 9.01
- 2018-02-02 0001193125-18-029947 — 7.01, 9.01
- 2017-12-07 0001571996-17-000042 — 2.02, 9.01
- 2017-10-24 0001571996-17-000037 — 1.01, 2.03, 9.01
- 2017-09-15 0001571996-17-000027 — 5.02
- 2017-09-07 0001571996-17-000017 — 2.02, 9.01
- 2017-08-24 0001571996-17-000014 — 8.01
- 2017-06-29 0001571996-17-000011 — 3.03, 5.07, 8.01, 9.01
- 2017-06-08 0001193125-17-197638 — 2.02, 9.01
- 2017-03-30 0001193125-17-102794 — 8.01
- 2017-03-30 0001193125-17-102777 — 2.02, 9.01
- 2017-03-09 0001193125-17-076981 — 1.01, 2.03, 9.01
- 2017-01-17 0001193125-17-011125 — 8.01
- 2016-12-15 0001193125-16-793722 — 8.01
- 2016-12-08 0001193125-16-787976 — 2.02, 9.01
- 2016-11-10 0001193125-16-765964 — 1.02, 8.01
- 2016-11-04 0001193125-16-760249 — 8.01
- 2016-09-13 0001193125-16-708600 — 3.02
- 2016-09-09 0001193125-16-706567 — 1.01, 1.02, 2.01, 2.03, 3.02, 3.03, 5.02, 9.01
- 2016-09-07 0001193125-16-703370 — 3.03, 5.07, 7.01, 8.01, 9.01
- 2016-09-06 0001193125-16-702057 — 2.02, 9.01
- 2016-08-31 0001193125-16-697268 — 8.01, 9.01
- 2016-08-26 0001193125-16-692921 — 8.01, 9.01
- 2016-07-11 0001193125-16-645610 — 8.01
- 2016-07-05 0001193125-16-641679 — 8.01
- 2016-06-22 0001193125-16-629055 — 1.01, 2.03, 8.01, 9.01
- 2016-06-21 0001193125-16-627071 — 8.01, 9.01
- 2016-06-10 0001193125-16-618483 — 2.02, 9.01
- 2016-06-09 0001193125-16-617893 — 8.01, 9.01

## late-filing notifications on or before 2022-03-24

- none on or before 2022-03-24

## item 2.02 — earnings release, exhibit 99.1

[0001571996-22-000004:8k_2_02:1]
EX-99.1
2
exhibit991earnings8kq4fy22.htm
EX-99.1

[0001571996-22-000004:8k_2_02:2]
Document

[0001571996-22-000004:8k_2_02:3]
Exhibit 99.1

[0001571996-22-000004:8k_2_02:4]
Dell Technologies Delivers Fourth Quarter and Full-Year Fiscal 2022 Financial Results

[0001571996-22-000004:8k_2_02:5]
News summary

[0001571996-22-000004:8k_2_02:6]
•Record full-year revenue of $101.2 billion, up 17%, fueled by continued growth across all business units and record PC shipments

[0001571996-22-000004:8k_2_02:7]
•Record full-year diluted earnings per share of $6.26, up 114%, and non-GAAP diluted earnings per share of $6.22, up 27%

[0001571996-22-000004:8k_2_02:8]
•Announcing a quarterly cash dividend policy, with an initial quarterly dividend of $0.33 per share and expected aggregate fiscal 2023 dividends of approximately $1 billion

[0001571996-22-000004:8k_2_02:9]
ROUND ROCK, Texas — February 24, 2022

[0001571996-22-000004:8k_2_02:10]
Full story

[0001571996-22-000004:8k_2_02:11]
Dell Technologies (NYSE: DELL) announces financial results for its fiscal 2022 fourth quarter and full year. The company also announces that its board of directors has approved a dividend policy under which the company intends to pay quarterly cash dividends on its common stock, with an initial dividend rate of $1.32 per share per year for fiscal 2023, or approximately $1 billion in aggregate. The board has declared the initial quarterly dividend of $0.33 per share, which will be payable on April 29 to stockholders of record as of April 20.

[0001571996-22-000004:8k_2_02:12]
Full-year revenue was a record $101.2 billion, up 17% over the prior year, fueled by record demand, strong execution, continued growth across all business units, and record PC shipments. The company generated record operating income of $4.7 billion, a 26% increase over the prior year, and record non-GAAP operating income of $7.8 billion, up 12%. For the full year, both net income from continuing operations and non-GAAP net income were $4.9 billion.  Cash flow from operations was $10.3 billion and cash flow from operations excluding VMware was a record $7.1 billion.  Full-year diluted earnings per share from continuing operations was $6.26, up 114%, and non-GAAP diluted earnings per share was $6.22, up 27%.

[0001571996-22-000004:8k_2_02:13]
Fourth quarter revenue increased 16% to $28 billion. The company generated operating income of $1.6 billion, up 13%, and non-GAAP operating income of $2.2 billion, up 1%.  Net loss from continuing operations was $29 million, non-GAAP net income was $1.4 billion and adjusted EBITDA was $2.7 billion. Cash flow from operations was $3.1 billion. Fourth quarter diluted loss per share was $0.04, and non-GAAP diluted earnings per share was $1.72, in each case resulting in part from a higher than anticipated effective tax rate in the quarter.

[0001571996-22-000004:8k_2_02:14]
1

[0001571996-22-000004:8k_2_02:15]
Fourth Quarter and Full-Year Fiscal 2022 Financial Results

[0001571996-22-000004:8k_2_02:16]
|  | Three Months Ended |  |  |  | Fiscal Year Ended |  |  |
|  | January 28, 2022 |  | January 29, 2021 |  | Change |  | January 28, 2022 |  | January 29, 2021 |  | Change |
|  | (in millions, except per share amounts and percentages; unaudited) |
| Total net revenue | $ | 27,992 |  |  | $ | 24,150 |  |  | 16% |  | $ | 101,197 |  |  | $ | 86,670 |  |  | 17% |
| Operating income | $ | 1,609 |  |  | $ | 1,423 |  |  | 13% |  | $ | 4,659 |  |  | $ | 3,685 |  |  | 26% |
| Net income (loss) from continuing operations | $ | (29) |  |  | $ | 695 |  |  | (104)% |  | $ | 4,942 |  |  | $ | 2,245 |  |  | 120% |
| Earnings (loss) per share from continuing operations attributable to Dell Technologies Inc. — diluted: | $ | (0.04) |  |  | $ | 0.90 |  |  | (104)% |  | $ | 6.26 |  |  | $ | 2.93 |  |  | 114% |
| Non-GAAP net revenue | $ | 28,000 |  |  | $ | 24,176 |  |  | 16% |  | $ | 101,229 |  |  | $ | 86,776 |  |  | 17% |
| Non-GAAP operating income | $ | 2,191 |  |  | $ | 2,170 |  |  | 1% |  | $ | 7,785 |  |  | $ | 6,949 |  |  | 12% |
| Non-GAAP net income | $ | 1,390 |  |  | $ | 1,362 |  |  | 2% |  | $ | 4,924 |  |  | $ | 3,746 |  |  | 31% |
| Adjusted EBITDA | $ | 2,686 |  |  | $ | 2,620 |  |  | 3% |  | $ | 9,660 |  |  | $ | 8,645 |  |  | 12% |
| Non-GAAP earnings per share - diluted | $ | 1.72 |  |  | $ | 1.76 |  |  | (2)% |  | $ | 6.22 |  |  | $ | 4.88 |  |  | 27% |

[0001571996-22-000004:8k_2_02:17]
Information about Dell Technologies’ use of non-GAAP financial information is provided under “Non-GAAP Financial Measures” below.  All comparisons in this press release are year-over-year unless otherwise noted.

[0001571996-22-000004:8k_2_02:18]
Dell Technologies ended the quarter with remaining performance obligations of $42 billion, up 20% year-over-year, deferred revenue of $27.6 billion, and cash and investments of $11.3 billion. The company had net debt paydowns of $16.5 billion in fiscal 2022 and received an Investment Grade corporate family rating from all three major credit rating agencies.

[0001571996-22-000004:8k_2_02:19]
Operating segments summary

[0001571996-22-000004:8k_2_02:20]
Client Solutions Group delivered record results, with revenue for the fourth quarter of $17.3 billion, up 26% year-over-year. This performance was driven by $12.9 billion in commercial revenue – a 30% increase year-over-year – and $4.4 billion in consumer revenue – a 16% increase year-over-year.  Operating income was $1.2 billion, or approximately 6.7% of Client Solutions Group revenue.  For the full year, Client Solutions Group delivered record revenue of $61.5 billion, up 27% versus the prior year.  Client Solutions Group full-year operating income was $4.4 billion, a 31% increase versus the prior year.

[0001571996-22-000004:8k_2_02:21]
Key areas of innovation:

[0001571996-22-000004:8k_2_02:22]
•Won 47 awards at CES, where Dell introduced the new XPS 13 Plus – a completely redesigned XPS that brings together modern design with more performance.

[0001571996-22-000004:8k_2_02:23]
•Introduced the world’s thinnest gaming laptop (Alienware x14), the world's first quantum dot OLED gaming monitor (Alienware 34 Curved QD-OLED gaming monitor) and the most powerful 17-inch AMD Advantage gaming laptop.

[0001571996-22-000004:8k_2_02:24]
•Launched the latest UltraSharp video conferencing monitor, which features a 4K webcam, echo cancelling microphones and Microsoft Teams certification to provide the best collaboration and visual experience possible.

[0001571996-22-000004:8k_2_02:25]
•Introduced Concept Luna, an advanced commercial notebook concept built around sustainability, recyclability and reuse.

[0001571996-22-000004:8k_2_02:26]
2

[0001571996-22-000004:8k_2_02:27]
Infrastructure Solutions Group revenue for the fourth quarter was $9.2 billion, up 3% year-over-year. Storage revenue was $4.5 billion, while servers and networking revenue was $4.7 billion – up 7% year-over-year. Operating income was $1.1 billion or approximately 12% of Infrastructure Solutions Group revenue. For the full year, revenue was $34.4 billion, with operating income of $3.7 billion.

[0001571996-22-000004:8k_2_02:28]
Key areas of innovation:

[0001571996-22-000004:8k_2_02:29]
•Announced expansions to our APEX multi-cloud capabilities, enabling customers to move from multi-cloud by default to multi-cloud by design, as well as connect to multiple clouds without hyperscale lock-in.

[0001571996-22-000004:8k_2_02:30]
•Introduced Dell PowerProtect Cyber Recovery for AWS (Amazon Web Services), giving organizations modern data protection to isolate critical data from a ransomware attack and accelerate data recovery.

[0001571996-22-000004:8k_2_02:31]
Executive Quotes:

[0001571996-22-000004:8k_2_02:32]
•“Fiscal 2022 was the best year in Dell Technologies history. We reached more than $100 billion in revenue and grew 17% - a huge achievement and ahead of our long-term growth targets,” said Jeff Clarke, vice chairman and co-chief operating officer, Dell Technologies. “For our customers, the biggest opportunity is to turn data into insight, action and progress, and they are prioritizing investments in technology.”

[0001571996-22-000004:8k_2_02:33]
•“In FY22, widespread digital transformation continued to accelerate growth in technology spend, and we are encouraged by growing demand across our entire portfolio,” said Chuck Whitten, co-chief operating officer, Dell Technologies. “We also made strategic progress across multi-cloud, edge, as-a-Service and telecom. We launched solutions in these spaces, engaged customers, and made investments to position Dell for future growth.”

[0001571996-22-000004:8k_2_02:34]
•“Last year we achieved a number of milestones that unleashed shareholder value. We generated cash flow of $10.3 billion, achieved investment grade rating and spun-off VMware,” said Tom Sweet, chief financial officer, Dell Technologies. “We remain focused on executing our strategy to consolidate and modernize our core and build new growth engines that enable our customers' multi-cloud future while delivering shareholder value.”

[0001571996-22-000004:8k_2_02:35]
Dell Technologies World

[0001571996-22-000004:8k_2_02:36]
Join us May 2 – May 5 for Dell Technologies World, the company’s flagship event that brings together the latest trends, technology and gurus. During the event, customers and partners will explore the connected ecosystem of IT infrastructure, applications, devices and security along with our APEX and multi-cloud solutions that give customers greater flexibility to scale IT to meet business needs, transform and inspire the next breakthrough. Register here.

[0001571996-22-000004:8k_2_02:37]
Conference call information

[0001571996-22-000004:8k_2_02:38]
As previously announced, the Company will hold a conference call to discuss its fiscal 2022 fourth quarter and full-year performance and financial guidance, February 24, 2022 at 4:30 p.m. CST. The conference call will be broadcast live over the internet and can be accessed at

[0001571996-22-000004:8k_2_02:39]
https://investors.delltechnologies.com/events-and-presentations/upcoming-events

[0001571996-22-000004:8k_2_02:40]
For those unable to listen to the live broadcast, an archived version will be available at the same location for one year.

[0001571996-22-000004:8k_2_02:41]
3

[0001571996-22-000004:8k_2_02:42]
Additional financial and operating information may be downloaded from

[0001571996-22-000004:8k_2_02:43]
https://investors.delltechnologies.com/financial-information/quarterly-results

[0001571996-22-000004:8k_2_02:44]
Customer Highlights Blog

[0001571996-22-000004:8k_2_02:45]
Read our quarterly blog from Bill Scannell, Dell Technologies president of Global Sales & Customer Operations, to learn more about how we are helping customers with their digital transformations: https://www.dell.com/en-us/blog/giving-customers-an-edge-in-todays-digital-world/

[0001571996-22-000004:8k_2_02:46]
Environmental, Social and Governance (ESG)

[0001571996-22-000004:8k_2_02:47]
Our Environmental, Social and Governance (ESG) efforts are focused on driving positive impact for people and our planet while delivering long-term value for all stakeholders. Explore our ESG resources.

[0001571996-22-000004:8k_2_02:48]
About Dell Technologies

[0001571996-22-000004:8k_2_02:49]
Dell Technologies (NYSE:DELL) helps organizations and individuals build their digital future and transform how they work, live and play. The company provides customers with the industry’s broadest and most innovative technology and services portfolio for the data era.

[0001571996-22-000004:8k_2_02:50]
Contacts

[0001571996-22-000004:8k_2_02:51]
Investors: Investor_Relations@Dell.com

[0001571996-22-000004:8k_2_02:52]
Media: Media.Relations@Dell.com

[0001571996-22-000004:8k_2_02:53]
# # #

[0001571996-22-000004:8k_2_02:54]
Copyright © 2022 Dell Inc. or its subsidiaries. All Rights Reserved. Dell Technologies, Dell, EMC and Dell EMC are trademarks of Dell Inc. or its subsidiaries. Other trademarks may be trademarks of their respective owners.

[0001571996-22-000004:8k_2_02:55]
Non-GAAP Financial Measures:

[0001571996-22-000004:8k_2_02:56]
This press release presents information about Dell Technologies’ non-GAAP net revenue, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, non-GAAP net income attributable to non-controlling interests, non-GAAP net income attributable to Dell Technologies Inc. - basic, non-GAAP net income attributable to Dell Technologies Inc. - diluted, non-GAAP earnings per share attributable to Dell Technologies Inc. - basic, non-GAAP earnings per share attributable to Dell Technologies Inc. - diluted, EBITDA, and adjusted EBITDA, which are non-GAAP financial measures provided as a supplement to the results provided in accordance with generally accepted accounting principles in the United States of America (“GAAP”). A reconciliation of each non-GAAP financial measure to the most directly comparable GAAP financial measure is provided in the attached tables for each of the fiscal periods indicated.

[0001571996-22-000004:8k_2_02:57]
Special Note on Forward-Looking Statements:

[0001571996-22-000004:8k_2_02:58]
Dell Technologies’ results or events in future periods could differ materially from those expressed or implied by these forward-looking statements because of risks, uncertainties, and other factors that include, but are not limited to, the following: risks and uncertainties relating to our spin-off of VMware, Inc., including the potential effects on our business of the transaction; the effects of the COVID-19 pandemic; competitive pressures; Dell Technologies’ reliance on third-party suppliers for products and components, including reliance on single-source or limited-source suppliers; Dell Technologies’ ability to achieve favorable pricing from its vendors; adverse global economic conditions and instability in financial markets; Dell Technologies’ execution of its growth, business and acquisition strategies; the success of Dell Technologies’ cost efficiency measures; Dell Technologies’ ability to manage solutions and products and services transitions in an effective manner; Dell Technologies’ ability to deliver high-quality products, software, and services; cyber attacks or other data security incidents; Dell Technologies’ foreign operations and ability to generate substantial non-U.S. net revenue; Dell Technologies’ product, services, customer, and geographic sales mix, and seasonal sales trends; the performance of Dell Technologies’ sales channel partners; access to the capital markets by Dell Technologies or its customers; material impairment of the value of goodwill or intangible assets; weak economic conditions and the effect of additional regulation on Dell Technologies’ financial services activities; counterparty default risks; the loss by Dell Technologies of any contracts for ISG services and solutions and its ability to perform such contracts at their estimated costs; loss by Dell Technologies of government contracts; Dell Technologies’ ability to develop and protect its proprietary intellectual property or obtain licenses to intellectual property developed by others on commercially reasonable and competitive terms; disruptions in Dell Technologies’ infrastructure; Dell Technologies’ ability to hedge effectively its exposure to fluctuations in foreign currency exchange rates and interest

[0001571996-22-000004:8k_2_02:59]
4

[0001571996-22-000004:8k_2_02:60]
rates; expiration of tax holidays or favorable tax rate structures, or unfavorable outcomes in tax audits and other tax compliance matters; impairment of portfolio investments; unfavorable results of legal proceedings; compliance requirements of changing environmental and safety laws or other laws; the effect of armed hostilities, terrorism, natural disasters, and public health issues; Dell Technologies’ dependence on the services of Michael Dell and key employees; Dell Technologies’ level of indebtedness; and business and financial factors and legal restrictions affecting continuation of Dell Technologies’ quarterly cash dividend policy and dividend rate.

[0001571996-22-000004:8k_2_02:61]
This list of risks, uncertainties, and other factors is not complete. Dell Technologies discusses some of these matters more fully, as well as certain risk factors that could affect Dell Technologies’ business, financial condition, results of operations, and prospects, in its reports filed with the SEC, including Dell Technologies’ annual report on Form 10-K for the fiscal year ended January 29, 2021, quarterly reports on Form 10-Q, and current reports on Form 8-K. These filings are available for review through the SEC’s website at www.sec.gov. Any or all forward-looking statements Dell Technologies makes may turn out to be wrong and can be affected by inaccurate assumptions Dell Technologies might make or by known or unknown risks, uncertainties and other factors, including those identified in this press release. Accordingly, you should not place undue reliance on the forward-looking statements made in this press release, which speak only as of its date. Dell Technologies does not undertake to update, and expressly disclaims any duty to update, its forward-looking statements, whether as a result of circumstances or events that arise after the date they are made, new information, or otherwise.

[0001571996-22-000004:8k_2_02:62]
5

[0001571996-22-000004:8k_2_02:63]
DELL TECHNOLOGIES INC. FINANCIAL INFORMATION

[0001571996-22-000004:8k_2_02:64]
Basis of Presentation

[0001571996-22-000004:8k_2_02:65]
Spin-Off of VMware, Inc. —  On November 1, 2021, Dell Technologies Inc. completed its previously announced spin-off of VMware, Inc. by means of a special stock dividend (the “VMware Spin-off”).  The VMware Spin-off was effectuated pursuant to a Separation and Distribution Agreement, dated as of April 14, 2021.

[0001571996-22-000004:8k_2_02:66]
In accordance with applicable accounting guidance, the results of VMware, Inc., excluding Dell Technologies’ resale of VMware, Inc. offerings, are presented as discontinued operations in the Consolidated Statements of Income and, as such, have been excluded from both continuing operations and segment results for all periods presented.  The results of Dell Technologies’ resale of VMware, Inc. offerings are presented as continuing operations for all periods presented.

[0001571996-22-000004:8k_2_02:67]
Dell Technologies reclassified the assets and liabilities of VMware, Inc. as assets and liabilities of discontinued operations in the Consolidated Statements of Financial Position as of January 29, 2021.  The Consolidated Statements of Cash Flows are presented on a consolidated basis for both continuing operations and discontinued operations.  Except as noted, the presentation in this press release is consistent with the foregoing accounting guidance.

[0001571996-22-000004:8k_2_02:68]
6

[0001571996-22-000004:8k_2_02:69]
DELL TECHNOLOGIES INC.

[0001571996-22-000004:8k_2_02:70]
Consolidated Statements of Income and Related Financial Highlights

[0001571996-22-000004:8k_2_02:71]
(in millions, except percentages; unaudited)

[0001571996-22-000004:8k_2_02:72]
|  | Three Months Ended |  |  |  | Fiscal Year Ended |  |  |
|  | January 28, 2022 |  | January 29, 2021 |  | Change |  | January 28, 2022 |  | January 29, 2021 |  | Change |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Products | $ | 22,469 |  | $ | 19,167 |  | 17% |  | $ | 79,830 |  |  | $ | 67,744 |  |  | 18% |
| Services | 5,523 |  | 4,983 |  | 11% |  | 21,367 |  |  | 18,926 |  |  | 13% |
| Total net revenue | 27,992 |  | 24,150 |  | 16% |  | 101,197 |  |  | 86,670 |  |  | 17% |
| Cost of net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Products | 19,265 |  | 15,879 |  | 21% |  | 67,224 |  |  | 56,431 |  |  | 19% |
| Services | 3,109 |  | 2,747 |  | 13% |  | 12,082 |  |  | 10,099 |  |  | 20% |
| Total cost of net revenue | 22,374 |  | 18,626 |  | 20% |  | 79,306 |  |  | 66,530 |  |  | 19% |
| Gross margin | 5,618 |  | 5,524 |  | 2% |  | 21,891 |  |  | 20,140 |  |  | 9% |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative | 3,398 |  | 3,467 |  | (2)% |  | 14,655 |  |  | 14,000 |  |  | 5% |
| Research and development | 611 |  | 634 |  | (4)% |  | 2,577 |  |  | 2,455 |  |  | 5% |
| Total operating expenses | 4,009 |  | 4,101 |  | (2)% |  | 17,232 |  |  | 16,455 |  |  | 5% |
| Operating income | 1,609 |  | 1,423 |  | 13% |  | 4,659 |  |  | 3,685 |  |  | 26% |
| Interest and other, net | (1,657) |  | (475) |  | (249)% |  | 1,264 |  |  | (1,339) |  |  | 194% |
| Income (loss) before income taxes | (48) |  | 948 |  | (105)% |  | 5,923 |  |  | 2,346 |  |  | 152% |
| Income tax expense (benefit) | (19) |  | 253 |  | (108)% |  | 981 |  |  | 101 |  |  | 871% |
| Net income (loss) from continuing operations | (29) |  | 695 |  | (104)% |  | 4,942 |  |  | 2,245 |  |  | 120% |
| Income from discontinued operations, net of income taxes | 30 |  | 648 |  | (95)% |  | 765 |  |  | 1,260 |  |  | (39)% |
| Net income | 1 |  | 1,343 |  | (100)% |  | 5,707 |  |  | 3,505 |  |  | 63% |
| Less: Net loss attributable to non-controlling interests | (1) |  | (2) |  | 50% |  | (6) |  |  | (4) |  |  | (50)% |
| Less: Net income attributable to non-controlling interests of discontinued operations | — |  | 118 |  | (100)% |  | 150 |  |  | 259 |  |  | (42)% |
| Net income attributable to Dell Technologies Inc. | $ | 2 |  | $ | 1,227 |  | (100)% |  | $ | 5,563 |  |  | $ | 3,250 |  |  | 71% |
| Percentage of Total Net Revenue: |  |  |  |  |  |  |  |  |  |  |
| Gross margin | 20 | % |  | 23 | % |  |  |  | 22 | % |  | 23 | % |  |  |
| Selling, general, and administrative | 12 | % |  | 14 | % |  |  |  | 14 | % |  | 16 | % |  |  |
| Research and development | 2 | % |  | 3 | % |  |  |  | 3 | % |  | 3 | % |  |  |
| Operating expenses | 14 | % |  | 17 | % |  |  |  | 17 | % |  | 19 | % |  |  |
| Operating income | 6 | % |  | 6 | % |  |  |  | 5 | % |  | 4 | % |  |  |
| Income (loss) from continuing operations before income taxes | — | % |  | 4 | % |  |  |  | 6 | % |  | 3 | % |  |  |
| Net income (loss) from continuing operations | — | % |  | 3 | % |  |  |  | 5 | % |  | 3 | % |  |  |
| Income tax rate | 39.6 | % |  | 26.7 | % |  |  |  | 16.6 | % |  | 4.3 | % |  |  |

[0001571996-22-000004:8k_2_02:73]
Amounts are based on underlying data and may not visually foot due to rounding.

[0001571996-22-000004:8k_2_02:74]
7

[0001571996-22-000004:8k_2_02:75]
DELL TECHNOLOGIES INC.

[0001571996-22-000004:8k_2_02:76]
Consolidated Statements of Financial Position

[0001571996-22-000004:8k_2_02:77]
(in millions; unaudited)

[0001571996-22-000004:8k_2_02:78]
|  | January 28, 2022 |  | January 29, 2021 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 9,477 |  |  | $ | 9,508 |  |
| Accounts receivable, net | 12,912 |  |  | 10,731 |  |
| Short-term financing receivables, net | 5,089 |  |  | 5,148 |  |
| Inventories, net | 5,898 |  |  | 3,403 |  |
| Other current assets | 11,581 |  |  | 9,810 |  |
| Current assets of discontinued operations | — |  |  | 4,967 |  |
| Total current assets | 44,957 |  |  | 43,567 |  |
| Property, plant, and equipment, net | 5,415 |  |  | 4,833 |  |
| Long-term investments | 1,839 |  |  | 1,334 |  |
| Long-term financing receivables, net | 5,522 |  |  | 5,339 |  |
| Goodwill | 19,770 |  |  | 20,028 |  |
| Intangible assets, net | 7,461 |  |  | 9,115 |  |
| Other non-current assets | 7,695 |  |  | 7,184 |  |
| Non-current assets of discontinued operations | — |  |  | 32,015 |  |
| Total assets | $ | 92,659 |  |  | $ | 123,415 |  |
| LIABILITIES, REDEEMABLE SHARES, AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Short-term debt | $ | 5,823 |  |  | $ | 6,357 |  |
| Accounts payable | 27,143 |  |  | 21,572 |  |
| Due to related parties, net | 1,338 |  |  | 1,346 |  |
| Accrued and other | 7,578 |  |  | 7,166 |  |
| Short-term deferred revenue | 14,261 |  |  | 13,201 |  |
| Current liabilities of discontinued operations | — |  |  | 4,490 |  |
| Total current liabilities | 56,143 |  |  | 54,132 |  |
| Long-term debt | 21,131 |  |  | 32,865 |  |
| Long-term deferred revenue | 13,312 |  |  | 12,391 |  |
| Other non-current liabilities | 3,653 |  |  | 3,923 |  |
| Non-current liabilities of discontinued operations | — |  |  | 12,079 |  |
| Total liabilities | 94,239 |  |  | 115,390 |  |
| Redeemable shares | — |  |  | 472 |  |
| Stockholders’ equity: |  |  |  |
| Total Dell Technologies Inc. stockholders’ equity (deficit) | (1,685) |  |  | 2,479 |  |
| Non-controlling interests | 105 |  |  | 96 |  |
| Non-controlling interests of discontinued operations | — |  |  | 4,978 |  |
| Total stockholders’ equity (deficit) | (1,580) |  |  | 7,553 |  |
| Total liabilities, redeemable shares, and stockholders’ equity | $ | 92,659 |  |  | $ | 123,415 |  |

[0001571996-22-000004:8k_2_02:79]
8

[0001571996-22-000004:8k_2_02:80]
DELL TECHNOLOGIES INC.

[0001571996-22-000004:8k_2_02:81]
Consolidated Statements of Cash Flows

[0001571996-22-000004:8k_2_02:82]
(in millions; unaudited)

[0001571996-22-000004:8k_2_02:83]
|  | Three Months Ended |  | Fiscal Year Ended |
|  | January 28, 2022 |  | January 29, 2021 |  | January 28, 2022 |  | January 29, 2021 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |
| Net income | $ | 1 |  |  | $ | 1,343 |  |  | $ | 5,707 |  |  | $ | 3,505 |  |
| Adjustments to reconcile net income to net cash provided by operating activities | 3,092 |  |  | 4,534 |  |  | 4,600 |  |  | 7,902 |  |
| Change in cash from operating activities | 3,093 |  |  | 5,877 |  |  | 10,307 |  |  | 11,407 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |
| Purchases of investments | (94) |  |  | (42) |  |  | (414) |  |  | (338) |  |
| Maturities and sales of investments | 59 |  |  | 71 |  |  | 513 |  |  | 169 |  |
| Capital expenditures and capitalized software development costs | (740) |  |  | (498) |  |  | (2,796) |  |  | (2,082) |  |
| Acquisition of businesses and assets, net | — |  |  | (19) |  |  | (16) |  |  | (424) |  |
| Divestitures of businesses and assets, net | — |  |  | — |  |  | 3,957 |  |  | 2,187 |  |
| Other | 28 |  |  | 2 |  |  | 62 |  |  | 28 |  |
| Change in cash from investing activities | (747) |  |  | (486) |  |  | 1,306 |  |  | (460) |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |
| Dividends paid by VMware, Inc. to non-controlling interests | (2,240) |  |  | — |  |  | (2,240) |  |  | — |  |
| Proceeds from the issuance of common stock | 8 |  |  | 63 |  |  | 334 |  |  | 452 |  |
| Repurchases of parent common stock (a) | (628) |  |  | (1) |  |  | (663) |  |  | (241) |  |
| Repurchases of subsidiary common stock (a) | (1) |  |  | (473) |  |  | (1,175) |  |  | (1,363) |  |
| Proceeds from debt | 7,388 |  |  | 1,619 |  |  | 20,425 |  |  | 16,391 |  |
| Repayments of debt | (13,654) |  |  | (3,675) |  |  | (26,723) |  |  | (20,919) |  |
| Net transfer of cash, cash equivalents, and restricted cash to VMware, Inc. | (5,052) |  |  | — |  |  | (5,052) |  |  | — |  |
| Debt related costs and other, net | (1,402) |  |  | — |  |  | (1,515) |  |  | (270) |  |
| Change in cash from financing activities | (15,581) |  |  | (2,467) |  |  | (16,609) |  |  | (5,950) |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash | (52) |  |  | 103 |  |  | (106) |  |  | 36 |  |
| Change in cash, cash equivalents, and restricted cash | (13,287) |  |  | 3,027 |  |  | (5,102) |  |  | 5,033 |  |
| Cash, cash equivalents, and restricted cash at beginning of the period, including cash attributable to discontinued operations | 23,369 |  |  | 12,157 |  |  | 15,184 |  |  | 10,151 |  |
| Cash, cash equivalents, and restricted cash at end of the period, including cash attributable to discontinued operations | $ | 10,082 |  |  | $ | 15,184 |  |  | $ | 10,082 |  |  | $ | 15,184 |  |

[0001571996-22-000004:8k_2_02:84]
_________________

[0001571996-22-000004:8k_2_02:85]
(a) Common stock repurchases are inclusive of employee tax withholding on stock-based compensation.

[0001571996-22-000004:8k_2_02:86]
9

[0001571996-22-000004:8k_2_02:87]
DELL TECHNOLOGIES INC.

[0001571996-22-000004:8k_2_02:88]
Segment Information

[0001571996-22-000004:8k_2_02:89]
(in millions, except percentages; unaudited; continued on next page)

[0001571996-22-000004:8k_2_02:90]
|  | Three Months Ended |  |  |  | Fiscal Year Ended |  |  |
|  | January 28, 2022 |  | January 29, 2021 |  | Change |  | January 28, 2022 |  | January 29, 2021 |  | Change |
| Infrastructure Solutions Group (ISG): |
| Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Servers and networking | $ | 4,720 |  |  | $ | 4,405 |  |  | 7% |  | $ | 17,901 |  |  | $ | 16,592 |  |  | 8% |
| Storage | 4,499 |  |  | 4,510 |  |  | —% |  | 16,465 |  |  | 16,410 |  |  | —% |
| Total ISG net revenue | $ | 9,219 |  |  | $ | 8,915 |  |  | 3% |  | $ | 34,366 |  |  | $ | 33,002 |  |  | 4% |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| ISG operating income | $ | 1,102 |  |  | $ | 1,183 |  |  | (7)% |  | $ | 3,736 |  |  | $ | 3,753 |  |  | —% |
| % of ISG net revenue | 12 | % |  | 13 | % |  |  |  | 11 | % |  | 11 | % |  |  |
| % of total reportable segment operating income | 49 | % |  | 53 | % |  |  |  | 46 | % |  | 53 | % |  |  |
| Client Solutions Group (CSG): |
| Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 12,891 |  |  | $ | 9,946 |  |  | 30% |  | $ | 45,576 |  |  | $ | 35,423 |  |  | 29% |
| Consumer | 4,438 |  |  | 3,824 |  |  | 16% |  | 15,888 |  |  | 12,964 |  |  | 23% |
| Total CSG net revenue | $ | 17,329 |  |  | $ | 13,770 |  |  | 26% |  | $ | 61,464 |  |  | $ | 48,387 |  |  | 27% |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| CSG operating income | $ | 1,157 |  |  | $ | 1,040 |  |  | 11% |  | $ | 4,365 |  |  | $ | 3,333 |  |  | 31% |
| % of CSG net revenue | 7 | % |  | 8 | % |  |  |  | 7 | % |  | 7 | % |  |  |
| % of total reportable segment operating income | 51 | % |  | 47 | % |  |  |  | 54 | % |  | 47 | % |  |  |

[0001571996-22-000004:8k_2_02:91]
Amounts are based on underlying data and may not visually foot due to rounding.

[0001571996-22-000004:8k_2_02:92]
10

[0001571996-22-000004:8k_2_02:93]
DELL TECHNOLOGIES INC.

[0001571996-22-000004:8k_2_02:94]
Segment Information

[0001571996-22-000004:8k_2_02:95]
(in millions, except percentages; unaudited; continued)

[0001571996-22-000004:8k_2_02:96]
|  | Three Months Ended |  | Fiscal Year Ended |
|  | January 28, 2022 |  | January 29, 2021 |  | January 28, 2022 |  | January 29, 2021 |
| Reconciliation to consolidated net revenue: |  |  |  |  |  |  |
| Reportable segment net revenue | $ | 26,548 |  |  | $ | 22,685 |  |  | $ | 95,830 |  |  | $ | 81,389 |  |
| Other businesses (a) | 1,448 |  |  | 1,488 |  |  | 5,388 |  |  | 5,382 |  |
| Unallocated transactions (b) | 4 |  |  | 3 |  |  | 11 |  |  | 5 |  |
| Impact of purchase accounting (c) | (8) |  |  | (26) |  |  | (32) |  |  | (106) |  |
| Total consolidated net revenue | $ | 27,992 |  |  | $ | 24,150 |  |  | $ | 101,197 |  |  | $ | 86,670 |  |
| Reconciliation to consolidated operating income: |  |  |  |  |  |  |  |
| Reportable segment operating income | $ | 2,259 |  |  | $ | 2,223 |  |  | $ | 8,101 |  |  | $ | 7,086 |  |
| Other businesses (a) | (71) |  |  | (56) |  |  | (319) |  |  | (139) |  |
| Unallocated transactions (b) | 3 |  |  | 3 |  |  | 3 |  |  | 2 |  |
| Impact of purchase accounting (c) | (20) |  |  | (36) |  |  | (67) |  |  | (144) |  |
| Amortization of intangibles | (323) |  |  | (527) |  |  | (1,641) |  |  | (2,133) |  |
| Transaction-related expenses (d) | 22 |  |  | (19) |  |  | (273) |  |  | (124) |  |
| Stock-based compensation expense (e) | (216) |  |  | (137) |  |  | (808) |  |  | (487) |  |
| Other corporate expenses (f) | (45) |  |  | (28) |  |  | (337) |  |  | (376) |  |
| Total consolidated operating income | $ | 1,609 |  |  | $ | 1,423 |  |  | $ | 4,659 |  |  | $ | 3,685 |  |

[0001571996-22-000004:8k_2_02:97]
_________________

[0001571996-22-000004:8k_2_02:98]
(a)Other businesses consists of: 1) Dell’s resale of standalone VMware, Inc. products and services, “VMware Resale”, 2) Secureworks, and 3) Virtustream, and do not meet the requirements for a reportable segment, either individually or collectively.  On September 1, 2020, the Company completed the sale of RSA Security and, on October 1, 2021, the Company completed the sale of Boomi.  Prior to the divestitures, Boomi and RSA Security’s results were included within Other businesses.

[0001571996-22-000004:8k_2_02:99]
(b)Unallocated transactions includes other corporate items that are not allocated to Dell Technologies’ reportable segments.

[0001571996-22-000004:8k_2_02:100]
(c)Impact of purchase accounting includes non-cash purchase accounting adjustments that are primarily related to the EMC merger transaction.

[0001571996-22-000004:8k_2_02:101]
(d)Transaction-related expenses includes acquisition, integration, and divestiture related costs.

[0001571996-22-000004:8k_2_02:102]
(e)Stock-based compensation expense consists of equity awards granted based on the estimated fair value of those awards at grant date.

[0001571996-22-000004:8k_2_02:103]
(f)Other corporate expenses includes impairment charges, incentive charges related to equity investments, severance, facilities action, and other costs.

[0001571996-22-000004:8k_2_02:104]
11

[0001571996-22-000004:8k_2_02:105]
SUPPLEMENTAL SELECTED NON-GAAP FINANCIAL MEASURES

[0001571996-22-000004:8k_2_02:106]
These tables present information about the Company’s non-GAAP net revenue, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, non-GAAP net income attributable to Dell Technologies Inc. - basic and diluted, non-GAAP earnings per share attributable to Dell Technologies Inc. - basic, non-GAAP earnings per share attributable to Dell Technologies Inc. - diluted, EBITDA, adjusted EBITDA, which are non-GAAP financial measures provided as a supplement to the results provided in accordance with generally accepted accounting principles in the United States of America (“GAAP”). A detailed discussion of Dell Technologies’ reasons for including these non-GAAP financial measures, the limitations associated with these measures, the items excluded from these measures, and our reason for excluding those items are presented in “Management’s Discussion and Analysis of Financial Condition and Results of Operations — Non-GAAP Financial Measures” in our periodic reports filed with the SEC. Dell Technologies encourages investors to review the non-GAAP discussion in these reports in conjunction with the presentation of non-GAAP financial measures.

[0001571996-22-000004:8k_2_02:107]
12

[0001571996-22-000004:8k_2_02:108]
DELL TECHNOLOGIES INC.

[0001571996-22-000004:8k_2_02:109]
Selected Non-GAAP Financial Measures

[0001571996-22-000004:8k_2_02:110]
(in millions, except per share amounts and percentages; unaudited)

[0001571996-22-000004:8k_2_02:111]
|  | Three Months Ended |  |  |  | Fiscal Year Ended |  |  |
|  | January 28, 2022 |  | January 29, 2021 |  | Change |  | January 28, 2022 |  | January 29, 2021 |  | Change |
| Non-GAAP net revenue | $ | 28,000 |  | $ | 24,176 |  | 16% |  | $ | 101,229 |  | $ | 86,776 |  | 17% |
| Non-GAAP gross margin | $ | 5,818 |  | $ | 5,791 |  | —% |  | $ | 22,684 |  | $ | 21,233 |  | 7% |
| % of non-GAAP net revenue | 21 | % |  | 24 | % |  |  |  | 22 | % |  | 24 | % |  |  |
| Non-GAAP operating expenses | $ | 3,627 |  | $ | 3,621 |  | —% |  | $ | 14,899 |  | $ | 14,284 |  | 4% |
| % of non-GAAP net revenue | 13 | % |  | 15 | % |  |  |  | 15 | % |  | 16 | % |  |  |
| Non-GAAP operating income | $ | 2,191 |  | $ | 2,170 |  | 1% |  | $ | 7,785 |  | $ | 6,949 |  | 12% |
| % of non-GAAP net revenue | 8 | % |  | 9 | % |  |  |  | 8 | % |  | 8 | % |  |  |
| Non-GAAP net income | $ | 1,390 |  | $ | 1,362 |  | 2% |  | $ | 4,924 |  | $ | 3,746 |  | 31% |
| % of non-GAAP net revenue | 5 | % |  | 6 | % |  |  |  | 5 | % |  | 4 | % |  |  |
| Adjusted EBITDA | $ | 2,686 |  | $ | 2,620 |  | 3% |  | $ | 9,660 |  | $ | 8,645 |  | 12% |
| % of non-GAAP net revenue | 10 | % |  | 11 | % |  |  |  | 10 | % |  | 10 | % |  |  |
| Non-GAAP earnings per share - diluted | $ | 1.72 |  | $ | 1.76 |  | (2)% |  | $ | 6.22 |  | $ | 4.88 |  | 27% |

[0001571996-22-000004:8k_2_02:112]
Amounts are based on underlying data and may not visually foot due to rounding.

[0001571996-22-000004:8k_2_02:113]
13

[0001571996-22-000004:8k_2_02:114]
DELL TECHNOLOGIES INC.

[0001571996-22-000004:8k_2_02:115]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-22-000004:8k_2_02:116]
(in millions, except percentages; unaudited; continued on next page)

[0001571996-22-000004:8k_2_02:117]
|  | Three Months Ended |  |  |  | Fiscal Year Ended |  |  |
|  | January 28, 2022 |  | January 29, 2021 |  | Change |  | January 28, 2022 |  | January 29, 2021 |  | Change |
| Net revenue | $ | 27,992 |  |  | $ | 24,150 |  |  | 16% |  | $ | 101,197 |  |  | $ | 86,670 |  |  | 17% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 8 |  |  | 26 |  |  |  |  | 32 |  |  | 106 |  |  |  |
| Non-GAAP net revenue | $ | 28,000 |  |  | $ | 24,176 |  |  | 16% |  | $ | 101,229 |  |  | $ | 86,776 |  |  | 17% |
| Gross margin | $ | 5,618 |  |  | $ | 5,524 |  |  | 2% |  | $ | 21,891 |  |  | $ | 20,140 |  |  | 9% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 150 |  |  | 213 |  |  |  |  | 598 |  |  | 853 |  |  |  |
| Impact of purchase accounting | 8 |  |  | 25 |  |  |  |  | 35 |  |  | 109 |  |  |  |
| Stock-based compensation expense | 37 |  |  | 22 |  |  |  |  | 133 |  |  | 75 |  |  |  |
| Other corporate expenses | 5 |  |  | 7 |  |  |  |  | 27 |  |  | 56 |  |  |  |
| Non-GAAP gross margin | $ | 5,818 |  |  | $ | 5,791 |  |  | —% |  | $ | 22,684 |  |  | $ | 21,233 |  |  | 7% |
| Operating expenses | $ | 4,009 |  |  | $ | 4,101 |  |  | (2)% |  | $ | 17,232 |  |  | $ | 16,455 |  |  | 5% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | (173) |  |  | (314) |  |  |  |  | (1,043) |  |  | (1,280) |  |  |  |
| Impact of purchase accounting | (12) |  |  | (11) |  |  |  |  | (32) |  |  | (35) |  |  |  |
| Transaction-related expenses | 22 |  |  | (19) |  |  |  |  | (273) |  |  | (124) |  |  |  |
| Stock-based compensation expense | (179) |  |  | (115) |  |  |  |  | (675) |  |  | (412) |  |  |  |
| Other corporate expenses | (40) |  |  | (21) |  |  |  |  | (310) |  |  | (320) |  |  |  |
| Non-GAAP operating expenses | $ | 3,627 |  |  | $ | 3,621 |  |  | —% |  | $ | 14,899 |  |  | $ | 14,284 |  |  | 4% |
| Operating income | $ | 1,609 |  |  | $ | 1,423 |  |  | 13% |  | $ | 4,659 |  |  | $ | 3,685 |  |  | 26% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 323 |  |  | 527 |  |  |  |  | 1,641 |  |  | 2,133 |  |  |  |
| Impact of purchase accounting | 20 |  |  | 36 |  |  |  |  | 67 |  |  | 144 |  |  |  |
| Transaction-related (income) expenses | (22) |  |  | 19 |  |  |  |  | 273 |  |  | 124 |  |  |  |
| Stock-based compensation expense | 216 |  |  | 137 |  |  |  |  | 808 |  |  | 487 |  |  |  |
| Other corporate expenses | 45 |  |  | 28 |  |  |  |  | 337 |  |  | 376 |  |  |  |
| Non-GAAP operating income | $ | 2,191 |  |  | $ | 2,170 |  |  | 1% |  | $ | 7,785 |  |  | $ | 6,949 |  |  | 12% |

[0001571996-22-000004:8k_2_02:118]
14

[0001571996-22-000004:8k_2_02:119]
DELL TECHNOLOGIES INC.

[0001571996-22-000004:8k_2_02:120]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-22-000004:8k_2_02:121]
(in millions, except percentages; unaudited; continued)

[0001571996-22-000004:8k_2_02:122]
|  | Three Months Ended |  |  |  | Fiscal Year Ended |  |  |
|  | January 28, 2022 |  | January 29, 2021 |  | Change |  | January 28, 2022 |  | January 29, 2021 |  | Change |
| Net income (loss) from continuing operations | $ | (29) |  |  | $ | 695 |  |  | (104)% |  | $ | 4,942 |  |  | $ | 2,245 |  |  | 120% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 323 |  |  | 527 |  |  |  |  | 1,641 |  |  | 2,133 |  |  |  |
| Impact of purchase accounting | 20 |  |  | 36 |  |  |  |  | 67 |  |  | 144 |  |  |  |
| Transaction-related (income) expenses | 1,492 |  |  | 19 |  |  |  |  | (2,143) |  |  | (332) |  |  |  |
| Stock-based compensation expense | 216 |  |  | 137 |  |  |  |  | 808 |  |  | 487 |  |  |  |
| Other corporate expenses | 45 |  |  | 28 |  |  |  |  | 337 |  |  | 268 |  |  |  |
| Fair value adjustments on equity investments | (192) |  |  | (16) |  |  |  |  | (572) |  |  | (427) |  |  |  |
| Aggregate adjustment for income taxes | (485) |  |  | (64) |  |  |  |  | (156) |  |  | (772) |  |  |  |
| Non-GAAP net income | $ | 1,390 |  |  | $ | 1,362 |  |  | 2% |  | $ | 4,924 |  |  | $ | 3,746 |  |  | 31% |
| Net income (loss) from continuing operations attributable to Dell Technologies Inc. | $ | (28) |  |  | $ | 697 |  |  | (104)% |  | $ | 4,948 |  |  | $ | 2,249 |  |  | 120% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 323 |  |  | 527 |  |  |  |  | 1,641 |  |  | 2,133 |  |  |  |
| Impact of purchase accounting | 20 |  |  | 36 |  |  |  |  | 67 |  |  | 144 |  |  |  |
| Transaction-related (income) expenses | 1,492 |  |  | 19 |  |  |  |  | (2,143) |  |  | (332) |  |  |  |
| Stock-based compensation expense | 216 |  |  | 137 |  |  |  |  | 808 |  |  | 487 |  |  |  |
| Other corporate expenses | 45 |  |  | 28 |  |  |  |  | 337 |  |  | 268 |  |  |  |
| Fair value adjustments on equity investments | (192) |  |  | (16) |  |  |  |  | (572) |  |  | (427) |  |  |  |
| Aggregate adjustment for income taxes | (485) |  |  | (64) |  |  |  |  | (156) |  |  | (772) |  |  |  |
| Total non-GAAP adjustments attributable to non-controlling interests | (1) |  |  | (2) |  |  |  |  | (7) |  |  | (6) |  |  |  |
| Non-GAAP net income attributable to Dell Technologies Inc. | $ | 1,390 |  |  | $ | 1,362 |  |  | 2% |  | $ | 4,923 |  |  | $ | 3,744 |  |  | 31% |
| Net income (loss) from continuing operations | $ | (29) |  |  | $ | 695 |  |  | (104)% |  | $ | 4,942 |  |  | $ | 2,245 |  |  | 120% |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Interest and other, net | 1,657 |  |  | 475 |  |  |  |  | (1,264) |  |  | 1,339 |  |  |  |
| Income tax expense (benefit) | (19) |  |  | 253 |  |  |  |  | 981 |  |  | 101 |  |  |  |
| Depreciation and amortization | 830 |  |  | 987 |  |  |  |  | 3,547 |  |  | 3,867 |  |  |  |
| EBITDA | $ | 2,439 |  |  | $ | 2,410 |  |  | 1% |  | $ | 8,206 |  |  | $ | 7,552 |  |  | 9% |
| EBITDA | $ | 2,439 |  |  | $ | 2,410 |  |  | 1% |  | $ | 8,206 |  |  | $ | 7,552 |  |  | 9% |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense | 216 |  |  | 137 |  |  |  |  | 808 |  |  | 487 |  |  |  |
| Impact of purchase accounting | 8 |  |  | 26 |  |  |  |  | 36 |  |  | 106 |  |  |  |
| Transaction-related (income) expenses | (22) |  |  | 19 |  |  |  |  | 273 |  |  | 124 |  |  |  |
| Other corporate expenses | 45 |  |  | 28 |  |  |  |  | 337 |  |  | 376 |  |  |  |
| Adjusted EBITDA | $ | 2,686 |  |  | $ | 2,620 |  |  | 3% |  | $ | 9,660 |  |  | $ | 8,645 |  |  | 12% |

[0001571996-22-000004:8k_2_02:123]
15

[0001571996-22-000004:8k_2_02:124]
DELL TECHNOLOGIES INC.

[0001571996-22-000004:8k_2_02:125]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-22-000004:8k_2_02:126]
(in millions, except percentages and per share amounts; unaudited; continued)

[0001571996-22-000004:8k_2_02:127]
|  | Three Months Ended |  |  |  | Fiscal Year Ended |  |  |
|  | January 28, 2022 |  | January 29, 2021 |  | Change |  | January 28, 2022 |  | January 29, 2021 |  | Change |
| Earnings per share from continuing operations attributable to Dell Technologies Inc. |  |  |  |  |
| Net income (loss) from continuing operations attributable to Dell Technologies Inc. - basic | $ | (28) |  |  | $ | 697 |  |  |  |  | $ | 4,948 |  |  | $ | 2,249 |  |  |  |
| Weighted-average shares outstanding — basic | 763 |  | 750 |  |  |  | 762 |  | 744 |  |  |
| Earnings (loss) per share attributable to Dell Technologies Inc. - basic | $ | (0.04) |  |  | $ | 0.93 |  |  | (104)% |  | $ | 6.49 |  |  | $ | 3.02 |  |  | 115% |
| Net income (loss) from continuing operations attributable to Dell Technologies Inc. - diluted | $ | (28) |  |  | $ | 697 |  |  |  |  | $ | 4,948 |  |  | $ | 2,249 |  |  |  |
| Weighted-average shares outstanding — diluted | 763 |  | 776 |  |  |  | 791 |  | 767 |  |  |
| Earnings (loss) per share attributable to Dell Technologies Inc. — diluted: | $ | (0.04) |  |  | $ | 0.90 |  |  | (104)% |  | $ | 6.26 |  |  | $ | 2.93 |  |  | 114% |
| Earnings per share from discontinued operations attributable to Dell Technologies Inc. |  |  |  |  |
| Net income from discontinued operations attributable to Dell Technologies Inc. - basic | $ | 30 |  |  | $ | 530 |  |  |  |  | $ | 615 |  |  | $ | 1,001 |  |  |  |
| Weighted-average shares outstanding — basic | 763 |  | 750 |  |  |  | 762 |  | 744 |  |  |
| Earnings per share attributable to Dell Technologies Inc. - basic | $ | 0.04 |  |  | $ | 0.71 |  |  | (94)% |  | $ | 0.81 |  |  | $ | 1.35 |  |  | (40)% |
| Incremental dilution from VMware, Inc. attributable to Dell Technologies | — |  |  | (5) |  |  |  |  | (7) |  |  | (13) |  |  |  |
| Net income from discontinued operations attributable to Dell Technologies Inc. - diluted | $ | 30 |  |  | $ | 525 |  |  |  |  | $ | 608 |  |  | $ | 988 |  |  |  |
| Weighted-average shares outstanding — diluted | 763 |  | 776 |  |  |  | 791 |  | 767 |  |  |
| Earnings per share attributable to Dell Technologies Inc. — diluted | $ | 0.04 |  |  | $ | 0.67 |  |  | (94)% |  | $ | 0.76 |  |  | $ | 1.29 |  |  | (41)% |
| Non-GAAP earnings per share attributable to Dell Technologies Inc. |  |  |
| Non-GAAP net income attributable to Dell Technologies Inc. - basic | $ | 1,390 |  |  | $ | 1,362 |  |  |  |  | $ | 4,923 |  |  | $ | 3,744 |  |  |  |
| Weighted-average shares outstanding — basic | 763 |  | 750 |  |  |  | 762 |  | 744 |  |  |
| Earnings per share attributable to Dell Technologies Inc. - basic | $ | 1.82 |  |  | $ | 1.82 |  |  | —% |  | $ | 6.46 |  |  | $ | 5.03 |  |  | 28% |
| Non-GAAP net income attributable to Dell Technologies Inc. - diluted | $ | 1,390 |  |  | $ | 1,362 |  |  |  |  | $ | 4,923 |  |  | $ | 3,744 |  |  |  |
| Weighted-average shares outstanding — diluted | 810 |  | 776 |  |  |  | 791 |  | 767 |  |  |
| Earnings per share attributable to Dell Technologies Inc. — diluted | $ | 1.72 |  |  | $ | 1.76 |  |  | (2)% |  | $ | 6.22 |  |  | $ | 4.88 |  |  | 27% |

[0001571996-22-000004:8k_2_02:128]
Amounts may not visually recalculate due to rounding.

[0001571996-22-000004:8k_2_02:129]
16
