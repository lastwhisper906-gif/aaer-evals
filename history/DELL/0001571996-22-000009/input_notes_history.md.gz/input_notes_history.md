# DELL note change history — 0001571996-21-000040 → 0001571996-21-000063


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2021-12-03):
[0001571996-21-000063:note_history:1]
The Company has contractual obligations to purchase goods or services, which specify significant terms, including fixed or minimum quantities to be purchased; fixed, minimum, or variable price provisions; and the approximate timing of the transaction.  As of October 29, 2021, purchase obligations were $5.2 billion, $0.7 billion, and $0.8 billion for the remaining three months of Fiscal 2022, for Fiscal 2023, and for Fiscal 2024 and thereafter, respectively.
  (was, 2021-09-03, similarity 0.8953):
[0001571996-21-000040:note_history:1]
The Company has contractual obligations to purchase goods or services, which specify significant terms, including fixed or minimum quantities to be purchased; fixed, minimum, or variable price provisions; and the approximate timing of the transaction.  As of July 30, 2021, purchase obligations were $5.2 billion, $0.6 billion, and $0.9 billion for the remaining six month of Fiscal 2022, Fiscal 2023, and Fiscal 2024 and thereafter, respectively.

- added (2021-12-03):
[0001571996-21-000063:note_history:2]
In accordance with the relevant accounting guidance, the Company provides disclosures of matters where it is at least reasonably possible that the Company could experience a material loss exceeding the amounts already accrued for these or other proceedings or matters.  In addition, the Company also discloses matters based on its consideration of other matters and qualitative factors, including the experience of other companies in the industry, and investor, customer, and employee relations considerations.  As of October 29, 2021, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for these or other proceedings or matters has been incurred.  However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company’s business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters.  Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company’s business, financial condition, results of operations, or cash flows will depend on a number of factors, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.

- removed (2021-12-03):
[0001571996-21-000040:note_history:3]
In accordance with the relevant accounting guidance, the Company provides disclosures of matters where it is at least reasonably possible that the Company could experience a material loss exceeding the amounts already accrued for these or other proceedings or matters.  In addition, the Company also discloses matters based on its consideration of other matters and qualitative factors, including the experience of other companies in the industry, and investor, customer, and employee relations considerations.  As of July 30, 2021, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for these or other proceedings or matters has been incurred.  However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company’s business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters.  Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company’s business, financial condition, results of operations, or cash flows will depend on a number of factors, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.


## dell:CreditLossFinancialInstrumentLeasesDebtVariableInterestEntitiesAndCustomerReceivablesSalesTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-12-03):
[0001571996-21-000063:note_history:4]
The Company offers or arranges various financing options, services, and alternative payment structures for its customers in North America, Europe, Australia, and New Zealand through Dell Financial Services and its affiliates (“DFS”).  The Company also arranges financing for some of its customers in various countries where DFS does not currently operate as a captive enterprise.  The Company further strengthens customer relationships through flexible consumption models, which enable the Company to offer its customers the option to pay over time and, in certain cases, based on utilization, to provide them with financial flexibility to meet their changing technological requirements.  The key activities of DFS include originating, collecting, and servicing customer financing arrangements primarily related to the purchase or use of Dell Technologies products and services.  In some cases, DFS also offers financing on the purchase of third-party technology products that complement the Dell Technologies portfolio of products and services.  New financing originations were $2.0 billion and $2.1 billion for the three months ended October 29, 2021 and October 30, 2020, respectively, and $5.8 billion and $6.5 billion for the nine months ended October 29, 2021 and October 30, 2020, respectively.
  (was, 2021-09-03, similarity 0.9686):
[0001571996-21-000040:note_history:4]
The Company offers or arranges various financing options, services, and alternative payment structures for its customers in North America, Europe, Australia, and New Zealand through Dell Financial Services and its affiliates (“DFS”).  The Company also arranges financing for some of its customers in various countries where DFS does not currently operate as a captive enterprise.  The Company further strengthens customer relationships through flexible consumption models, which enable the Company to offer its customers the option to pay over time and, in certain cases, based on utilization, to provide them with financial flexibility to meet their changing technological requirements.  The key activities of DFS include originating, collecting, and servicing customer financing arrangements primarily related to the purchase or use of Dell Technologies products and services.  In some cases, DFS also offers financing on the purchase of third-party technology products that complement the Dell Technologies portfolio of products and services.  New financing originations were $1.9 billion and $2.6 billion for the three months ended July 30, 2021 and July 31, 2020, respectively, and $3.8 billion and $4.4 billion for the six months ended July 30, 2021 and July 31, 2020, respectively.

- changed (2021-12-03):
[0001571996-21-000063:note_history:5]
|  | October 29, 2021 |  | January 29, 2021 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Financing receivables, net: |  |  |  |  |  |  |  |  |  |  |  |
| Customer receivables, gross (a) | $ | 705 |  |  | $ | 9,495 |  |  | $ | 10,200 |  |  | $ | 796 |  |  | $ | 9,595 |  |  | $ | 10,391 |  |
| Allowances for losses | (112) |  |  | (113) |  |  | (225) |  |  | (148) |  |  | (173) |  |  | (321) |  |
| Customer receivables, net | 593 |  |  | 9,382 |  |  | 9,975 |  |  | 648 |  |  | 9,422 |  |  | 10,070 |  |
| Residual interest | — |  |  | 265 |  |  | 265 |  |  | — |  |  | 424 |  |  | 424 |  |
| Financing receivables, net | $ | 593 |  |  | $ | 9,647 |  |  | $ | 10,240 |  |  | $ | 648 |  |  | $ | 9,846 |  |  | $ | 10,494 |  |
| Short-term | $ | 593 |  |  | $ | 4,377 |  |  | $ | 4,970 |  |  | $ | 648 |  |  | $ | 4,507 |  |  | $ | 5,155 |  |
| Long-term | $ | — |  |  | $ | 5,270 |  |  | $ | 5,270 |  |  | $ | — |  |  | $ | 5,339 |  |  | $ | 5,339 |  |
  (was, 2021-09-03, similarity 0.993):
[0001571996-21-000040:note_history:5]
|  | July 30, 2021 |  | January 29, 2021 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Financing receivables, net: |  |  |  |  |  |  |  |  |  |  |  |
| Customer receivables, gross (a) | $ | 726 |  |  | $ | 9,527 |  |  | $ | 10,253 |  |  | $ | 796 |  |  | $ | 9,595 |  |  | $ | 10,391 |  |
| Allowances for losses | (126) |  |  | (161) |  |  | (287) |  |  | (148) |  |  | (173) |  |  | (321) |  |
| Customer receivables, net | 600 |  |  | 9,366 |  |  | 9,966 |  |  | 648 |  |  | 9,422 |  |  | 10,070 |  |
| Residual interest | — |  |  | 319 |  |  | 319 |  |  | — |  |  | 424 |  |  | 424 |  |
| Financing receivables, net | $ | 600 |  |  | $ | 9,685 |  |  | $ | 10,285 |  |  | $ | 648 |  |  | $ | 9,846 |  |  | $ | 10,494 |  |
| Short-term | $ | 600 |  |  | $ | 4,355 |  |  | $ | 4,955 |  |  | $ | 648 |  |  | $ | 4,507 |  |  | $ | 5,155 |  |
| Long-term | $ | — |  |  | $ | 5,330 |  |  | $ | 5,330 |  |  | $ | — |  |  | $ | 5,339 |  |  | $ | 5,339 |  |

- added (2021-12-03):
[0001571996-21-000063:note_history:6]
|  | Three Months Ended |
|  | October 29, 2021 |  | October 30, 2020 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |  |  |  |  |  |  |  |  |  |  |  |
| Balances at beginning of period | $ | 126 |  |  | $ | 161 |  |  | $ | 287 |  |  | $ | 143 |  |  | $ | 180 |  |  | $ | 323 |  |
| Charge-offs, net of recoveries | (9) |  |  | (20) |  |  | (29) |  |  | (13) |  |  | (6) |  |  | (19) |  |
| Provision charged to income statement | (5) |  |  | (28) |  |  | (33) |  |  | 12 |  |  | (9) |  |  | 3 |  |
| Balances at end of period | $ | 112 |  |  | $ | 113 |  |  | $ | 225 |  |  | $ | 142 |  |  | $ | 165 |  |  | $ | 307 |  |

- added (2021-12-03):
[0001571996-21-000063:note_history:7]
|  | Nine Months Ended |
|  | October 29, 2021 |  | October 30, 2020 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |  |  |  |  |  |  |  |  |  |  |  |
| Balances at beginning of period | $ | 148 |  |  | $ | 173 |  |  | $ | 321 |  |  | $ | 70 |  |  | $ | 79 |  |  | $ | 149 |  |
| Adjustment for adoption of accounting standard | — |  |  | — |  |  | — |  |  | 40 |  |  | 71 |  |  | 111 |  |
| Charge-offs, net of recoveries | (32) |  |  | (25) |  |  | (57) |  |  | (51) |  |  | (22) |  |  | (73) |  |
| Provision charged to income statement | (4) |  |  | (35) |  |  | (39) |  |  | 83 |  |  | 37 |  |  | 120 |  |
| Balances at end of period | $ | 112 |  |  | $ | 113 |  |  | $ | 225 |  |  | $ | 142 |  |  | $ | 165 |  |  | $ | 307 |  |

- changed (2021-12-03):
[0001571996-21-000063:note_history:8]
|  | October 29, 2021 |  | January 29, 2021 |
|  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |
|  | (in millions) |
| Revolving — DPA | $ | 485 |  |  | $ | 34 |  |  | $ | 10 |  |  | $ | 529 |  |  | $ | 578 |  |  | $ | 30 |  |  | $ | 13 |  |  | $ | 621 |  |
| Revolving — DBC | 157 |  |  | 16 |  |  | 3 |  |  | 176 |  |  | 157 |  |  | 14 |  |  | 4 |  |  | 175 |  |
| Fixed-term — Consumer and Commercial | 9,063 |  |  | 411 |  |  | 21 |  |  | 9,495 |  |  | 9,192 |  |  | 316 |  |  | 87 |  |  | 9,595 |  |
| Total customer receivables, gross | $ | 9,705 |  |  | $ | 461 |  |  | $ | 34 |  |  | $ | 10,200 |  |  | $ | 9,927 |  |  | $ | 360 |  |  | $ | 104 |  |  | $ | 10,391 |  |
  (was, 2021-09-03, similarity 0.991):
[0001571996-21-000040:note_history:8]
|  | July 30, 2021 |  | January 29, 2021 |
|  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |
|  | (in millions) |
| Revolving — DPA | $ | 515 |  |  | $ | 32 |  |  | $ | 8 |  |  | $ | 555 |  |  | $ | 578 |  |  | $ | 30 |  |  | $ | 13 |  |  | $ | 621 |  |
| Revolving — DBC | 155 |  |  | 13 |  |  | 3 |  |  | 171 |  |  | 157 |  |  | 14 |  |  | 4 |  |  | 175 |  |
| Fixed-term — Consumer and Commercial | 9,264 |  |  | 238 |  |  | 25 |  |  | 9,527 |  |  | 9,192 |  |  | 316 |  |  | 87 |  |  | 9,595 |  |
| Total customer receivables, gross | $ | 9,934 |  |  | $ | 283 |  |  | $ | 36 |  |  | $ | 10,253 |  |  | $ | 9,927 |  |  | $ | 360 |  |  | $ | 104 |  |  | $ | 10,391 |  |

- changed (2021-12-03):
[0001571996-21-000063:note_history:9]
Fixed-term consumer and commercial customer receivables are placed on non-accrual status if principal or interest is past due and considered delinquent, or if there is concern about collectibility of a specific customer receivable.  These receivables identified as doubtful for collectibility may be classified as current for aging purposes.  Aged revolving portfolio customer receivables identified as delinquent are charged-off.  Receivables are moved back to accrual status when the collection of  interest is probable, or the collection of the net investment is no longer doubtful.
  (was, 2021-09-03, similarity 0.9983):
[0001571996-21-000040:note_history:9]
Fixed-term consumer and commercial customer receivables are placed on non-accrual status if principal or interest is past due and considered delinquent, or if there is concern about collectibility of a specific customer receivable.  These receivables identified as doubtful for collectibility may be classified as current for aging purposes.  Aged revolving portfolio customer receivables identified as delinquent are charged off.  Receivables are moved back to accrual status when the collection of  interest is probable, or the collection of the net investment is no longer doubtful.

- changed (2021-12-03):
[0001571996-21-000063:note_history:10]
|  | October 29, 2021 |
|  | Fixed-term — Consumer and Commercial |  |  |  |  |  |  |
|  | Fiscal Year of Origination |
|  | 2022 |  | 2021 |  | 2020 |  | 2019 |  | 2018 |  | Years Prior |  | Revolving — DPA |  | Revolving — DBC |  | Total |
|  | (in millions) |
| Higher | $ | 2,441 |  |  | $ | 2,055 |  |  | $ | 1,108 |  |  | $ | 297 |  |  | $ | 45 |  |  | $ | 5 |  |  | $ | 135 |  |  | $ | 45 |  |  | $ | 6,131 |  |
| Mid | 765 |  |  | 863 |  |  | 426 |  |  | 126 |  |  | 24 |  |  | 1 |  |  | 163 |  |  | 55 |  |  | 2,423 |  |
| Lower | 486 |  |  | 515 |  |  | 267 |  |  | 60 |  |  | 10 |  |  | 1 |  |  | 231 |  |  | 76 |  |  | 1,646 |  |
| Total | $ | 3,692 |  |  | $ | 3,433 |  |  | $ | 1,801 |  |  | $ | 483 |  |  | $ | 79 |  |  | $ | 7 |  |  | $ | 529 |  |  | $ | 176 |  |  | $ | 10,200 |  |
  (was, 2021-09-03, similarity 0.9814):
[0001571996-21-000040:note_history:10]
|  | July 30, 2021 |
|  | Fixed-term — Consumer and Commercial |  |  |  |  |  |  |
|  | Fiscal Year of Origination |  |  |  |  |  |  |
|  | 2022 |  | 2021 |  | 2020 |  | 2019 |  | 2018 |  | Years Prior |  | Revolving — DPA |  | Revolving — DBC |  | Total |
|  | (in millions) |
| Higher | $ | 1,806 |  |  | $ | 2,362 |  |  | $ | 1,330 |  |  | $ | 373 |  |  | $ | 73 |  |  | $ | 8 |  |  | $ | 149 |  |  | $ | 45 |  |  | $ | 6,146 |  |
| Mid | 520 |  |  | 925 |  |  | 487 |  |  | 162 |  |  | 32 |  |  | 1 |  |  | 172 |  |  | 52 |  |  | 2,351 |  |
| Lower | 376 |  |  | 634 |  |  | 327 |  |  | 92 |  |  | 17 |  |  | 2 |  |  | 234 |  |  | 74 |  |  | 1,756 |  |
| Total | $ | 2,702 |  |  | $ | 3,921 |  |  | $ | 2,144 |  |  | $ | 627 |  |  | $ | 122 |  |  | $ | 11 |  |  | $ | 555 |  |  | $ | 171 |  |  | $ | 10,253 |  |

- changed (2021-12-03):
[0001571996-21-000063:note_history:11]
|  | January 29, 2021 |
|  | Fixed-term — Consumer and Commercial |  |  |  |  |  |  |
|  | Fiscal Year of Origination |
|  | 2021 |  | 2020 |  | 2019 |  | 2018 |  | 2017 |  | Years Prior |  | Revolving — DPA |  | Revolving — DBC |  | Total |
|  | (in millions) |
| Higher | $ | 3,125 |  |  | $ | 1,802 |  |  | $ | 661 |  |  | $ | 166 |  |  | $ | 26 |  |  | $ | — |  |  | $ | 172 |  |  | $ | 47 |  |  | $ | 5,999 |  |
| Mid | 1,121 |  |  | 671 |  |  | 287 |  |  | 73 |  |  | 9 |  |  | — |  |  | 188 |  |  | 52 |  |  | 2,401 |  |
| Lower | 865 |  |  | 499 |  |  | 243 |  |  | 38 |  |  | 9 |  |  | — |  |  | 261 |  |  | 76 |  |  | 1,991 |  |
| Total | $ | 5,111 |  |  | $ | 2,972 |  |  | $ | 1,191 |  |  | $ | 277 |  |  | $ | 44 |  |  | $ | — |  |  | $ | 621 |  |  | $ | 175 |  |  | $ | 10,391 |  |
  (was, 2021-09-03, similarity 0.9903):
[0001571996-21-000040:note_history:11]
|  | January 29, 2021 |
|  | Fixed-term — Consumer and Commercial |  |  |  |  |  |  |
|  | Fiscal Year of Origination |  |  |  |  |  |  |
|  | 2021 |  | 2020 |  | 2019 |  | 2018 |  | 2017 |  | Years Prior |  | Revolving — DPA |  | Revolving — DBC |  | Total |
|  | (in millions) |
| Higher | $ | 3,125 |  |  | $ | 1,802 |  |  | $ | 661 |  |  | $ | 166 |  |  | $ | 26 |  |  | $ | — |  |  | $ | 172 |  |  | $ | 47 |  |  | $ | 5,999 |  |
| Mid | 1,121 |  |  | 671 |  |  | 287 |  |  | 73 |  |  | 9 |  |  | — |  |  | 188 |  |  | 52 |  |  | 2,401 |  |
| Lower | 865 |  |  | 499 |  |  | 243 |  |  | 38 |  |  | 9 |  |  | — |  |  | 261 |  |  | 76 |  |  | 1,991 |  |
| Total | $ | 5,111 |  |  | $ | 2,972 |  |  | $ | 1,191 |  |  | $ | 277 |  |  | $ | 44 |  |  | $ | — |  |  | $ | 621 |  |  | $ | 175 |  |  | $ | 10,391 |  |

- changed (2021-12-03):
[0001571996-21-000063:note_history:12]
Interest income on sales-type lease receivables was $59 million and $69 million for the three months ended October 29, 2021 and October 30, 2020, respectively, and $186 million and $200 million for the nine months ended October 29, 2021, and October 30, 2020, respectively.
  (was, 2021-09-03, similarity 0.7579):
[0001571996-21-000040:note_history:12]
Interest income on sales-type lease receivables was $63 million and $66 million for the three months ended July 30, 2021 and July 31, 2020, respectively, and $127 million and $131 million for the six months ended July 30, 2021, and July 31, 2020, respectively.

- changed (2021-12-03):
[0001571996-21-000063:note_history:13]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 29, 2021 |  | October 30, 2020 |  | October 29, 2021 |  | October 30, 2020 |
|  | (in millions) |
| Net revenue — products | $ | 183 |  |  | $ | 184 |  |  | $ | 607 |  |  | $ | 648 |  |
| Cost of net revenue — products | 162 |  |  | 102 |  |  | 467 |  |  | 435 |  |
| Gross margin — products | $ | 21 |  |  | $ | 82 |  |  | $ | 140 |  |  | $ | 213 |  |
  (was, 2021-09-03, similarity 0.8444):
[0001571996-21-000040:note_history:13]
|  | Three Months Ended |  | Six Months Ended |
|  | July 30, 2021 |  | July 31, 2020 |  | July 30, 2021 |  | July 31, 2020 |
|  | (in millions) |
| Net revenue — products | $ | 194 |  |  | $ | 249 |  |  | $ | 424 |  |  | $ | 464 |  |
| Cost of net revenue — products | 142 |  |  | 174 |  |  | 305 |  |  | 333 |  |
| Gross margin — products | $ | 52 |  |  | $ | 75 |  |  | $ | 119 |  |  | $ | 131 |  |

- changed (2021-12-03):
[0001571996-21-000063:note_history:14]
|  | October 29, 2021 |
|  | (in millions) |
| Fiscal 2022 (remaining three months) | $ | 775 |  |
| Fiscal 2023 | 2,207 |  |
| Fiscal 2024 | 1,445 |  |
| Fiscal 2025 | 735 |  |
| Fiscal 2026 and beyond | 335 |  |
| Total undiscounted cash flows | 5,497 |  |
| Fixed-term loans | 4,620 |  |
| Revolving loans | 705 |  |
| Less: unearned income | (622) |  |
| Total customer receivables, gross | $ | 10,200 |  |
  (was, 2021-09-03, similarity 0.6742):
[0001571996-21-000040:note_history:14]
|  | July 30, 2021 |
|  | (in millions) |
| Fiscal 2022 (remaining six months) | $ | 371 |  |
| Fiscal 2023 | 600 |  |
| Fiscal 2024 | 338 |  |
| Fiscal 2025 | 109 |  |
| Fiscal 2026 and beyond | 17 |  |
| Total | $ | 1,435 |  |

- changed (2021-12-03):
[0001571996-21-000063:note_history:15]
|  | October 29, 2021 |  | January 29, 2021 |
|  | (in millions) |
| Equipment under operating lease, gross | $ | 2,367 |  |  | $ | 1,746 |  |
| Less: accumulated depreciation | (787) |  |  | (432) |  |
| Equipment under operating lease, net | $ | 1,580 |  |  | $ | 1,314 |  |
  (was, 2021-09-03, similarity 0.9763):
[0001571996-21-000040:note_history:15]
|  | July 30, 2021 |  | January 29, 2021 |
|  | (in millions) |
| Equipment under operating lease, gross | $ | 2,094 |  |  | $ | 1,746 |  |
| Less: accumulated depreciation | (657) |  |  | (432) |  |
| Equipment under operating lease, net | $ | 1,437 |  |  | $ | 1,314 |  |

- added (2021-12-03):
[0001571996-21-000063:note_history:16]
The following table presents operating lease income related to lease payments and depreciation expense for the Company’s operating lease portfolio for the periods indicated:

- added (2021-12-03):
[0001571996-21-000063:note_history:17]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 29, 2021 |  | October 30, 2020 |  | October 29, 2021 |  | October 30, 2020 |
|  | (in millions) |
| Income related to lease payments | $187 |  | $120 |  | $510 |  | $310 |
| Depreciation expense | $140 |  | $92 |  | $383 |  | $228 |

- added (2021-12-03):
[0001571996-21-000063:note_history:18]
|  | October 29, 2021 |
|  | (in millions) |
| Fiscal 2022 (remaining three months) | $ | 220 |  |
| Fiscal 2023 | 702 |  |
| Fiscal 2024 | 437 |  |
| Fiscal 2025 | 189 |  |
| Fiscal 2026 and beyond | 21 |  |
| Total | $ | 1,569 |  |

- changed (2021-12-03):
[0001571996-21-000063:note_history:19]
|  | October 29, 2021 |  | January 29, 2021 |
|  | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing and securitization facilities | $ | 2,650 |  |  | $ | 3,311 |  |
| Fixed-term securitization offerings | 3,618 |  |  | 2,961 |  |
| Other | 147 |  |  | 140 |  |
| Total DFS U.S. debt | 6,415 |  |  | 6,412 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 751 |  |  | 786 |  |
| Other borrowings | 809 |  |  | 1,006 |  |
| Note payable | 250 |  |  | 250 |  |
| Dell Bank Senior Unsecured Eurobonds | 1,752 |  |  | 1,212 |  |
| Total DFS international debt | 3,562 |  |  | 3,254 |  |
| Total DFS debt | $ | 9,977 |  |  | $ | 9,666 |  |
| Total short-term DFS debt | $ | 5,475 |  |  | $ | 4,888 |  |
| Total long-term DFS debt | $ | 4,502 |  |  | $ | 4,778 |  |
  (was, 2021-09-03, similarity 0.9916):
[0001571996-21-000040:note_history:19]
|  | July 30, 2021 |  | January 29, 2021 |
|  | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing and securitization facilities | $ | 3,182 |  |  | $ | 3,311 |  |
| Fixed-term securitization offerings | 2,929 |  |  | 2,961 |  |
| Other | 176 |  |  | 140 |  |
| Total DFS U.S. debt | 6,287 |  |  | 6,412 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 768 |  |  | 786 |  |
| Other borrowings | 1,063 |  |  | 1,006 |  |
| Note payable | 250 |  |  | 250 |  |
| Dell Bank Senior Unsecured Eurobonds | 1,189 |  |  | 1,212 |  |
| Total DFS international debt | 3,270 |  |  | 3,254 |  |
| Total DFS debt | $ | 9,557 |  |  | $ | 9,666 |  |
| Total short-term DFS debt | $ | 5,281 |  |  | $ | 4,888 |  |
| Total long-term DFS debt | $ | 4,276 |  |  | $ | 4,778 |  |

- changed (2021-12-03):
[0001571996-21-000063:note_history:20]
Asset-Based Financing and Securitization Facilities — The Company maintains separate asset-based financing facilities and a securitization facility in the United States, which are revolving facilities for fixed-term leases and loans and for revolving loans, respectively.  This debt is collateralized solely by the U.S. lease and loan payments and associated equipment in the facilities.  The debt has a variable interest rate and the duration of the debt is based on the terms of the underlying loan and lease payment streams.  As of October 29, 2021, the total debt capacity related to the U.S. asset-based financing and securitization facilities was $4.5 billion.  The Company enters into interest swap agreements to effectively convert a portion of this debt from a floating rate to a fixed rate.  See Note 6 of the Notes to the Condensed Consolidated Financial Statements for additional information about interest rate swaps.
  (was, 2021-09-03, similarity 0.9798):
[0001571996-21-000040:note_history:20]
Asset-Based Financing and Securitization Facilities — The Company maintains separate asset-based financing facilities and a securitization facility in the United States, which are revolving facilities for fixed-term leases and loans and for revolving loans, respectively.  This debt is collateralized solely by the U.S. loan and lease payments and associated equipment in the facilities.  The debt has a variable interest rate and the duration of the debt is based on the terms of the underlying loan and lease payment streams.  As of July 30, 2021, the total debt capacity related to the U.S. asset-based financing and securitization facilities was $4.5 billion.  The Company enters into interest swap agreements to effectively convert a portion of this debt from a floating rate to a fixed rate.  See Note 6 of the Notes to the Condensed Consolidated Financial Statements for additional information about interest rate swaps.

- changed (2021-12-03):
[0001571996-21-000063:note_history:21]
The asset-based financing and securitization facilities contain standard structural features related to the performance of the funded receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the facility, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of October 29, 2021, these criteria were met.
  (was, 2021-09-03, similarity 0.9902):
[0001571996-21-000040:note_history:21]
The asset-based financing and securitization facilities contain standard structural features related to the performance of the funded receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the facility, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of July 30, 2021, these criteria were met.

- changed (2021-12-03):
[0001571996-21-000063:note_history:22]
Securitization Facility — The Company maintains a securitization facility in Europe for fixed-term leases and loans.  This facility is effective through December 21, 2022 and had a total debt capacity of $934 million as of October 29, 2021.
  (was, 2021-09-03, similarity 0.9577):
[0001571996-21-000040:note_history:22]
Securitization Facility — The Company maintains a securitization facility in Europe for fixed-term leases and loans.  This facility is effective through December 21, 2022 and had a total debt capacity of $951 million as of July 30, 2021.

- changed (2021-12-03):
[0001571996-21-000063:note_history:23]
The securitization facility contains standard structural features related to the performance of the securitized receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the program, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of October 29, 2021, these criteria were met.
  (was, 2021-09-03, similarity 0.9897):
[0001571996-21-000040:note_history:23]
The securitization facility contains standard structural features related to the performance of the securitized receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the program, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of July 30, 2021, these criteria were met.

- added (2021-12-03):
[0001571996-21-000063:note_history:24]
Other Borrowings — In connection with the Company’s international financing operations, the Company enters into revolving structured financing debt programs related to its fixed-term lease and loan products sold in Canada, Europe, Australia, and New Zealand.  The Canadian facility, which is collateralized solely by Canadian lease and loan payments and associated equipment, had a total debt capacity of $364 million as of October 29, 2021, and is effective through January 16, 2025.  The European facility, which is collateralized solely by European loan and lease payments and associated equipment, had a total debt capacity of $701 million as of October 29, 2021, and is effective through December 14, 2023.  The Australia and New Zealand facility, which is collateralized solely by Australia and New Zealand loan and lease payments and associated equipment, had a total debt capacity of $339 million as of October 29, 2021, and is effective through April 20, 2023.

- changed (2021-12-03):
[0001571996-21-000063:note_history:25]
Note Payable — On August 7, 2020, the Company entered into two new unsecured credit agreements to fund receivables in Mexico.  As of October 29, 2021, the aggregate principal amount of the notes payable was $250 million.  The notes bear interest at an annual rate of 3.37% and will mature on June 1, 2022.
  (was, 2021-09-03, similarity 0.9804):
[0001571996-21-000040:note_history:25]
Note Payable — On August 7, 2020, the Company entered into two new unsecured credit agreements to fund receivables in Mexico.  As of July 30, 2021, the aggregate principal amount of the notes payable was $250 million.  The notes bear interest at an annual rate of 3.37% and will mature on June 1, 2022.

- changed (2021-12-03):
[0001571996-21-000063:note_history:26]
Dell Bank Senior Unsecured Eurobonds — On October 17, 2019, Dell Bank International D.A.C., a wholly-owned subsidiary of Dell Technologies Inc., issued 500 million Euro of 0.625% senior unsecured three year eurobonds due October 2022.  On June 24, 2020, Dell Bank International D.A.C. issued 500 million Euro of 1.625% senior unsecured four year eurobonds due June 2024.  On October 27, 2021, Dell Bank International D.A.C. issued 500 million Euro of 0.5% senior unsecured five year eurobonds due October 2026.  The issuances of the senior unsecured eurobonds support the expansion of the financing operations in Europe.
  (was, 2021-09-03, similarity 0.8652):
[0001571996-21-000040:note_history:26]
Dell Bank Senior Unsecured Eurobonds — On October 17, 2019, Dell Bank International D.A.C., a wholly-owned subsidiary of Dell Technologies Inc., issued 500 million Euro of 0.625% senior unsecured three year eurobonds due October 2022.  On June 24, 2020, Dell Bank International D.A.C. issued an additional 500 million Euro of 1.625% senior unsecured four year eurobonds due June 2024.  The issuances of the senior unsecured eurobonds support the expansion of the financing operations in Europe.

- changed (2021-12-03):
[0001571996-21-000063:note_history:27]
|  | October 29, 2021 |  | January 29, 2021 |
|  | (in millions) |
| Assets held by consolidated VIEs |  |  |  |
| Other current assets | $ | 843 |  |  | $ | 838 |  |
| Financing receivables, net of allowance |  |  |  |
| Short-term | $ | 3,467 |  |  | $ | 3,534 |  |
| Long-term | $ | 3,294 |  |  | $ | 3,314 |  |
| Property, plant, and equipment, net | $ | 874 |  |  | $ | 792 |  |
| Liabilities held by consolidated VIEs |  |  |  |
| Debt, net of unamortized debt issuance costs |  |  |  |
| Short-term | $ | 4,180 |  |  | $ | 4,208 |  |
| Long-term | $ | 2,826 |  |  | $ | 2,841 |  |
  (was, 2021-09-03, similarity 0.9891):
[0001571996-21-000040:note_history:27]
|  | July 30, 2021 |  | January 29, 2021 |
|  | (in millions) |
| Assets held by consolidated VIEs |  |  |  |
| Other current assets | $ | 770 |  |  | $ | 838 |  |
| Financing receivables, net of allowance |  |  |  |
| Short-term | $ | 3,457 |  |  | $ | 3,534 |  |
| Long-term | $ | 3,229 |  |  | $ | 3,314 |  |
| Property, plant, and equipment, net | $ | 838 |  |  | $ | 792 |  |
| Liabilities held by consolidated VIEs |  |  |  |
| Debt, net of unamortized debt issuance costs |  |  |  |
| Short-term | $ | 4,472 |  |  | $ | 4,208 |  |
| Long-term | $ | 2,398 |  |  | $ | 2,841 |  |

- changed (2021-12-03):
[0001571996-21-000063:note_history:28]
Loan and lease payments and associated equipment transferred via securitization through SPEs were $1.4 billion and $1.6 billion for the three months ended October 29, 2021 and October 30, 2020, respectively, and $4.1 billion and $4.6 billion for the nine months ended October 29, 2021 and October 30, 2020, respectively.
  (was, 2021-09-03, similarity 0.7972):
[0001571996-21-000040:note_history:28]
Loan and lease payments and associated equipment transferred via securitization through SPEs were $1.3 billion and $1.2 billion for the three months ended July 30, 2021 and July 31, 2020, respectively, and $2.7 billion and $3.0 billion for the six months ended July 30, 2021 and July 31, 2020, respectively.

- added (2021-12-03):
[0001571996-21-000063:note_history:29]
Customer Receivables Sales
To manage certain concentrations of customer credit exposure, the Company may sell selected fixed-term customer receivables to unrelated third parties on a periodic basis, without recourse.  The amount of customer receivables sold for this purpose was $180 million and $414 million for the nine months ended October 29, 2021 and October 30, 2020, respectively.  The Company’s continuing involvement in such customer receivables is primarily limited to servicing arrangements.  The transactions are accounted for as sales and, accordingly, the customer receivables are derecognized from the Condensed Consolidated Statements of Financial Position at the time of sale.

- removed (2021-12-03):
[0001571996-21-000040:note_history:30]
|  | Three Months Ended |
|  | July 30, 2021 |  | July 31, 2020 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |  |  |  |  |  |  |  |  |  |  |  |
| Balances at beginning of period | $ | 139 |  |  | $ | 177 |  |  | $ | 316 |  |  | $ | 144 |  |  | $ | 177 |  |  | $ | 321 |  |
| Charge-offs, net of recoveries | (10) |  |  | (3) |  |  | (13) |  |  | (18) |  |  | (7) |  |  | (25) |  |
| Provision charged to income statement | (3) |  |  | (13) |  |  | (16) |  |  | 17 |  |  | 10 |  |  | 27 |  |
| Balances at end of period | $ | 126 |  |  | $ | 161 |  |  | $ | 287 |  |  | $ | 143 |  |  | $ | 180 |  |  | $ | 323 |  |

- removed (2021-12-03):
[0001571996-21-000040:note_history:31]
|  | Six Months Ended |
|  | July 30, 2021 |  | July 31, 2020 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |  |  |  |  |  |  |  |  |  |  |  |
| Balances at beginning of period | $ | 148 |  |  | $ | 173 |  |  | $ | 321 |  |  | $ | 70 |  |  | $ | 79 |  |  | $ | 149 |  |
| Adjustment for adoption of accounting standard | — |  |  | — |  |  | — |  |  | 40 |  |  | 71 |  |  | 111 |  |
| Charge-offs, net of recoveries | (23) |  |  | (5) |  |  | (28) |  |  | (38) |  |  | (16) |  |  | (54) |  |
| Provision charged to income statement | 1 |  |  | (7) |  |  | (6) |  |  | 71 |  |  | 46 |  |  | 117 |  |
| Balances at end of period | $ | 126 |  |  | $ | 161 |  |  | $ | 287 |  |  | $ | 143 |  |  | $ | 180 |  |  | $ | 323 |  |

- removed (2021-12-03):
[0001571996-21-000040:note_history:32]
|  | July 30, 2021 |
|  | (in millions) |
| Fiscal 2022 (remaining six months) | $ | 1,479 |  |
| Fiscal 2023 | 2,052 |  |
| Fiscal 2024 | 1,303 |  |
| Fiscal 2025 | 592 |  |
| Fiscal 2026 and beyond | 252 |  |
| Total undiscounted cash flows | 5,678 |  |
| Fixed-term loans | 4,493 |  |
| Revolving loans | 726 |  |
| Less: unearned income | (644) |  |
| Total customer receivables, gross | $ | 10,253 |  |

- removed (2021-12-03):
[0001571996-21-000040:note_history:33]
Operating lease income relating to lease payments was $167 million and $103 million for the three months ended July 30, 2021 and July 31, 2020, respectively, and $323 million and $190 million for the six months ended July 30, 2021, and July 31, 2020, respectively.  Depreciation expense was $127 million and $74 million for the three months ended July 30, 2021 and July 31, 2020, respectively, and $243 million and $136 million for the six months ended July 30, 2021, and July 31, 2020, respectively.

- removed (2021-12-03):
[0001571996-21-000040:note_history:34]
Other Borrowings — In connection with the Company’s international financing operations, the Company enters into revolving structured financing debt programs related to its fixed-term lease and loan products sold in Canada, Europe, Australia, and New Zealand.  The Canadian facility, which is collateralized solely by Canadian loan and lease payments and associated equipment, had a total debt capacity of $362 million as of July 30, 2021, and is effective through January 16, 2025.  The European facility, which is collateralized solely by European loan and lease payments and associated equipment, had a total debt capacity of $713 million as of July 30, 2021, and is effective through December 14, 2023.  The Australia and New Zealand facility, which is collateralized solely by Australia and New Zealand loan and lease payments and associated equipment, had a total debt capacity of $333 million as of July 30, 2021, and is effective through April 20, 2023.

- removed (2021-12-03):
[0001571996-21-000040:note_history:35]
Customer Receivables Sales
To manage certain concentrations of customer credit exposure, the Company may sell selected fixed-term customer receivables to unrelated third parties on a periodic basis, without recourse.  The amount of customer receivables sold for this purpose was $101 million and $228 million for the six months ended July 30, 2021 and July 31, 2020, respectively.  The Company’s continuing involvement in such customer receivables is primarily limited to servicing arrangements.  The transactions are accounted for as sales and, accordingly, the customer receivables are derecognized from the Condensed Consolidated Statements of Financial Position at the time of sale.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-12-03):
[0001571996-21-000063:note_history:36]
|  | October 29, 2021 |  | January 29, 2021 |
|  | (in millions) |
| Secured Debt |  |  |  |
| Senior Secured Credit Facilities: |  |  |  |
| 2.00% Term Loan B-2 Facility due September 2025 (a) | $ | 3,120 |  |  | $ | 3,143 |  |
| 1.84% Term Loan A-6 Facility due March 2024 (a) | 3,134 |  |  | 3,134 |  |
| First Lien Notes: |  |  |  |
| 5.45% due June 2023 (a) | 3,750 |  |  | 3,750 |  |
| 4.00% due July 2024 | 1,000 |  |  | 1,000 |  |
| 5.85% due July 2025 | 1,000 |  |  | 1,000 |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 4.90% due October 2026 | 1,750 |  |  | 1,750 |  |
| 6.10% due July 2027 | 500 |  |  | 500 |  |
| 5.30% due October 2029 | 1,750 |  |  | 1,750 |  |
| 6.20% due July 2030 | 750 |  |  | 750 |  |
| 8.10% due July 2036 | 1,500 |  |  | 1,500 |  |
| 8.35% due July 2046 | 2,000 |  |  | 2,000 |  |
| Unsecured Debt |  |  |  |
| Unsecured Notes and Debentures: |  |  |  |
| 4.625% due April 2021 | — |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| Senior Notes: |  |  |  |
| 5.875% due June 2021 | — |  |  | 1,075 |  |
| 7.125% due June 2024 (a) | 1,625 |  |  | 1,625 |  |
| EMC Notes: |  |  |  |
| 3.375% due June 2023 | — |  |  | 1,000 |  |
| VMware Notes: |  |  |  |
| 2.95% due August 2022 | 1,500 |  |  | 1,500 |  |
| 0.60% due August 2023 | 1,000 |  |  | — |  |
| 1.00% due August 2024 | 1,250 |  |  | — |  |
| 4.50% due May 2025 | 750 |  |  | 750 |  |
| 1.40% due August 2026 | 1,500 |  |  | — |  |
| 4.65% due May 2027 | 500 |  |  | 500 |  |
| 3.90% due August 2027 | 1,250 |  |  | 1,250 |  |
| 1.80% due August 2028 | 750 |  |  | — |  |
| 4.70% due May 2030 | 750 |  |  | 750 |  |
| 2.20% due August 2031 | 1,500 |  |  | — |  |
| DFS Debt (Note 3) | 9,977 |  |  | 9,666 |  |
| Other |  |  |  |
| 2.44% Margin Loan Facility due April 2022 | — |  |  | 4,000 |  |
| Other | 400 |  |  | 235 |  |
| Total debt, principal amount | $ | 48,458 |  |  | $ | 48,480 |  |
  (was, 2021-09-03, similarity 0.7337):
[0001571996-21-000040:note_history:36]
|  | July 30, 2021 |  | January 29, 2021 |
|  | (in millions) |
| Secured Debt |  |  |  |
| Senior Secured Credit Facilities: |  |  |  |
| 2.00% Term Loan B-2 Facility due September 2025 | $ | 3,127 |  |  | $ | 3,143 |  |
| 1.86% Term Loan A-6 Facility due March 2024 | 3,134 |  |  | 3,134 |  |
| First Lien Notes: |  |  |  |
| 5.45% due June 2023 | 3,750 |  |  | 3,750 |  |
| 4.00% due July 2024 | 1,000 |  |  | 1,000 |  |
| 5.85% due July 2025 | 1,000 |  |  | 1,000 |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 4.90% due October 2026 | 1,750 |  |  | 1,750 |  |
| 6.10% due July 2027 | 500 |  |  | 500 |  |
| 5.30% due October 2029 | 1,750 |  |  | 1,750 |  |
| 6.20% due July 2030 | 750 |  |  | 750 |  |
| 8.10% due July 2036 | 1,500 |  |  | 1,500 |  |
| 8.35% due July 2046 | 2,000 |  |  | 2,000 |  |
| Unsecured Debt |  |  |  |
| Unsecured Notes and Debentures: |  |  |  |
| 4.625% due April 2021 | — |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| Senior Notes: |  |  |  |
| 5.875% due June 2021 | — |  |  | 1,075 |  |
| 7.125% due June 2024 | 1,625 |  |  | 1,625 |  |
| EMC Notes: |  |  |  |
| 3.375% due June 2023 | 1,000 |  |  | 1,000 |  |
| Debt of Public Subsidiary |  |  |  |
| VMware Notes: |  |  |  |
| 2.95% due August 2022 | 1,500 |  |  | 1,500 |  |
| 4.50% due May 2025 | 750 |  |  | 750 |  |
| 4.65% due May 2027 | 500 |  |  | 500 |  |
| 3.90% due August 2027 | 1,250 |  |  | 1,250 |  |
| 4.70% due May 2030 | 750 |  |  | 750 |  |
| DFS Debt (Note 3) | 9,557 |  |  | 9,666 |  |
| Other |  |  |  |
| 2.44% Margin Loan Facility due April 2022 | 1,000 |  |  | 4,000 |  |
| Other | 392 |  |  | 235 |  |
| Total debt, principal amount | $ | 44,037 |  |  | $ | 48,480 |  |

- changed (2021-12-03):
[0001571996-21-000063:note_history:37]
|  | October 29, 2021 |  | January 29, 2021 |
|  | (in millions) |
| Total debt, principal amount | $ | 48,458 |  |  | $ | 48,480 |  |
| Unamortized discount, net of unamortized premium | (175) |  |  | (194) |  |
| Debt issuance costs | (304) |  |  | (302) |  |
| Total debt, carrying value | $ | 47,979 |  |  | $ | 47,984 |  |
| Total short-term debt, carrying value (b) | $ | 16,280 |  |  | $ | 6,362 |  |
| Total long-term debt, carrying value | $ | 31,699 |  |  | $ | 41,622 |  |
  (was, 2021-09-03, similarity 0.9589):
[0001571996-21-000040:note_history:37]
|  | July 30, 2021 |  | January 29, 2021 |
|  | (in millions) |
| Total debt, principal amount | $ | 44,037 |  |  | $ | 48,480 |  |
| Unamortized discount, net of unamortized premium | (174) |  |  | (194) |  |
| Debt issuance costs | (269) |  |  | (302) |  |
| Total debt, carrying value | $ | 43,594 |  |  | $ | 47,984 |  |
| Total short-term debt, carrying value | $ | 6,427 |  |  | $ | 6,362 |  |
| Total long-term debt, carrying value | $ | 37,167 |  |  | $ | 41,622 |  |

- added (2021-12-03):
[0001571996-21-000063:note_history:38]
____________________

- added (2021-12-03):
[0001571996-21-000063:note_history:39]
(a)    Subsequent to October 29, 2021, the Company used the net proceeds from its $9.3 billion pro rata share of the cash dividend received in connection with the VMware Spin-off, as well as cash on hand, to repay $3.12 billion principal amount of the 2.00% Term Loan B-2 Facility due September 2025, $3.13 billion principal amount of the 1.84% Term Loan A-6 Facility due March 2024, $1.63 billion principal amount of the 7.125% Senior Notes due June 2024, and $1.50 billion principal amount of the 5.45% First Lien Notes due June 2023.

- added (2021-12-03):
[0001571996-21-000063:note_history:40]
(b)    Given the probability of the close of the VMware Spin-off and the Company’s intent and ability to repay, the Company classified $9.4 billion principal amount of debt as short-term liabilities on the Condensed Consolidated Statements of Financial Position as of October 29, 2021.

- changed (2021-12-03):
[0001571996-21-000063:note_history:41]
During the nine months ended October 29, 2021, the net decrease in the Company’s debt balance was primarily due to:
  (was, 2021-09-03, similarity 0.9252):
[0001571996-21-000040:note_history:41]
During the six months ended July 30, 2021, the net decrease in the Company’s debt balance was primarily due to:

- changed (2021-12-03):
[0001571996-21-000063:note_history:42]
•repayment of $1.0 billion principal amount of the 3.375% EMC Notes due June 2023;
  (was, 2021-09-03, similarity 0.915):
[0001571996-21-000040:note_history:42]
•repayment of $1,075 million principal amount of the 5.875% Senior Notes due June 2021; and

- changed (2021-12-03):
[0001571996-21-000063:note_history:43]
•repayment of $4.0 billion principal amount of the 2.44% Margin Loan Facility due April 2022;
  (was, 2021-09-03, similarity 0.982):
[0001571996-21-000040:note_history:43]
•repayment of $3.0 billion principal amount of the Margin Loan Facility due April 2022;

- changed (2021-12-03):
[0001571996-21-000063:note_history:44]
•repayment of $1.1 billion principal amount of the 5.875% Senior Notes due June 2021; and
  (was, 2021-09-03, similarity 0.8428):
[0001571996-21-000040:note_history:44]
•repayment of $400 million principal amount of the 4.625% Unsecured Notes due April 2021.

- added (2021-12-03):
[0001571996-21-000063:note_history:45]
•repayment of $0.4 billion principal amount of the 4.625% Unsecured Notes due April 2021.

- added (2021-12-03):
[0001571996-21-000063:note_history:46]
See Note 18 of the Notes to the Condensed Consolidated Financial Statements for more information about debt repayments that occurred subsequent to October 29, 2021.

- changed (2021-12-03):
[0001571996-21-000063:note_history:47]
Senior Secured Credit Facilities — The Company has entered into a credit agreement (the “Existing Credit Agreement”) that provides for senior secured credit facilities (the “Senior Secured Credit Facilities”) comprising (a) term loan facilities and (b) a senior secured Revolving Credit Facility, which provides for a borrowing capacity of up to $4.5 billion for general corporate purposes, including capacity for up to $0.5 billion of letters of credit and for borrowings of up to $0.4 billion under swing-line loans.  The Revolving Credit Facility expires December 20, 2023.
  (was, 2021-09-03, similarity 0.8168):
[0001571996-21-000040:note_history:47]
Senior Secured Credit Facilities — The Company has entered into a credit agreement that provides for senior secured credit facilities (the “Senior Secured Credit Facilities”) comprising (a) term loan facilities and (b) a senior secured Revolving Credit Facility, which provides for a borrowing capacity of up to $4.5 billion for general corporate purposes, including capacity for up to $0.5 billion of letters of credit and for borrowings of up to $0.4 billion under swing-line loans.  The Revolving Credit Facility expires December 20, 2023.

- changed (2021-12-03):
[0001571996-21-000063:note_history:48]
As of October 29, 2021, available borrowings under the Revolving Credit Facility totaled $4.5 billion.  The Senior Secured Credit Facilities provide that the borrowers have the right at any time, subject to customary conditions, to request incremental term loans or incremental revolving commitments.
  (was, 2021-09-03, similarity 0.981):
[0001571996-21-000040:note_history:48]
As of July 30, 2021, available borrowings under the Revolving Credit Facility totaled $4.5 billion.  The Senior Secured Credit Facilities provide that the borrowers have the right at any time, subject to customary conditions, to request incremental term loans or incremental revolving commitments.

- changed (2021-12-03):
[0001571996-21-000063:note_history:49]
On February 18, 2021, the Company entered into an eighth refinancing amendment to the credit agreement for the Senior Secured Credit Facilities to refinance the existing term B loans (the “Original Term B Loans”) with a new term loan B facility consisting of an aggregate principal amount of $3.1 billion refinancing term B-2 loans (the “Refinancing Term B-2 Loans”) maturing on September 19, 2025.  Proceeds from the Refinancing Term B-2 Loans, together with other funds available to the borrowers, were used to repay in full the Original Term B Loans and all accrued and unpaid fees in respect thereof.
  (was, 2021-09-03, similarity 0.9983):
[0001571996-21-000040:note_history:49]
On February 18, 2021, the Company entered into an eighth refinancing amendment to the credit agreement for the Senior Secured Credit Facilities to refinance the existing term B loans (the “Original Term B Loans”) with a new term loan B facility consisting of an aggregate principal amount of $3,143 million refinancing term B-2 loans (the “Refinancing Term B-2 Loans”) maturing on September 19, 2025.  Proceeds from the Refinancing Term B-2 Loans, together with other funds available to the borrowers, were used to repay in full the Original Term B Loans and all accrued and unpaid fees in respect thereof.

- added (2021-12-03):
[0001571996-21-000063:note_history:50]
Borrowings under the Senior Secured Credit Facilities bear interest at a rate per annum equal to an applicable margin, plus, at the borrowers’ option, either (a) a base rate, or (b) the London Interbank Offered Rate (“LIBOR”).  The Term Loan A-6 Facility

- changed (2021-12-03):
[0001571996-21-000063:note_history:51]
bears interest at LIBOR plus an applicable margin ranging from 1.25% to 2.00% or a base rate plus an applicable margin ranging from 0.25% to 1.00%.  The Refinancing Term B-2 Loans bear interest at LIBOR plus an applicable margin of 1.75% or a base rate plus an applicable margin of 0.75%.  Interest is payable, in the case of loans bearing interest based on LIBOR, at the end of each interest period (but at least every three months), in arrears and, in the case of loans bearing interest based on the base rate, quarterly in arrears.
  (was, 2021-09-03, similarity 0.8019):
[0001571996-21-000040:note_history:51]
Borrowings under the Senior Secured Credit Facilities bear interest at a rate per annum equal to an applicable margin, plus, at the borrowers’ option, either (a) a base rate, or (b) the London Interbank Offered Rate (“LIBOR”).  The Term Loan A-6 Facility bears interest at LIBOR plus an applicable margin ranging from 1.25% to 2.00% or a base rate plus an applicable margin ranging from 0.25% to 1.00%.  The Refinancing Term B-2 Loans bear interest at LIBOR plus an applicable margin of 1.75% or a base rate plus an applicable margin of 0.75%.  Interest is payable, in the case of loans bearing interest based on LIBOR, at the end of each interest period (but at least every three months), in arrears and, in the case of loans bearing interest based on the base rate, quarterly in arrears.

- added (2021-12-03):
[0001571996-21-000063:note_history:52]
Subsequent to October 29, 2021, the Company repaid the remaining $3.12 billion principal amount of the Term B-2 Loans and the remaining $3.13 billion principal amount of the Term Loan A-6 Facility.  On November 1, 2021, the Company entered into a new senior secured Revolving Credit Facility (the “2021 Revolving Credit Facility”) to replace the old senior secured Revolving Credit Facility under the Existing Credit Agreement.  Following the full redemption of the outstanding term loan facilities and placement of the Revolving Credit Facility, the Existing Credit Agreement was terminated.  See Note 18 of the Notes to the Condensed Consolidated Financial Statements for more information.

- changed (2021-12-03):
[0001571996-21-000063:note_history:53]
In June 2021, Dell International L.L.C and EMC Corporation completed the previously announced offers to exchange any and all outstanding First Lien Notes for registered first lien notes having terms substantially identical to the terms of the First Lien Notes.  The Issuers issued an aggregate $18.4 billion principal amount of registered first lien notes in exchange for the same principal amount of First Lien Notes.  The aggregate principal amount of unregistered First Lien Notes remaining outstanding following the settlement of the exchange offers was approximately $0.1 billion.  Following the exchange offer, such registered first lien notes, together with the remaining unregistered First Lien Notes, are collectively referred to as “First Lien Notes” in these Notes to the Condensed Consolidated Financial Statements.
  (was, 2021-09-03, similarity 0.8367):
[0001571996-21-000040:note_history:53]
In June 2021, Dell International L.L.C and EMC Corporation completed the previously announced offers to exchange any and all outstanding First Lien Notes for registered first lien notes having terms substantially identical to the terms of the First Lien Notes.  The Issuers issued an aggregate $18.4 billion principal amount of registered first lien notes in exchange for the same principal amount of First Lien Notes.  As of July 30, 2021, the aggregate principal amount of unregistered First Lien Notes remaining outstanding following the settlement of the exchange offers was approximately $0.1 billion.  Following the exchange

- added (2021-12-03):
[0001571996-21-000063:note_history:54]
Subsequent to October 29, 2021, the Company repaid $1.5 billion principal amount of First Lien Notes.  Further, in conjunction with the termination of the Existing Credit Agreement, the tangible and intangible assets of the issuers and guarantors that secure obligations under the Senior Secured Credit Facilities were released as collateral and the First Lien Notes became fully unsecured.  See Note 18 of the Notes to the Condensed Consolidated Financial Statements for more information about the First Lien Notes principal repayment subsequent to October 29, 2021.

- added (2021-12-03):
[0001571996-21-000063:note_history:55]
Senior Notes — The senior unsecured notes (collectively, the “Senior Notes”) were issued on June 22, 2016 in an aggregate principal amount of $3.3 billion.  Interest on outstanding borrowings is payable semiannually.  Subsequent to October 29, 2021, the Company repaid the remaining $1.63 billion principal amount of Senior Notes.  Following the full redemption of the Senior Note, the indenture governing the Senior Notes was terminated.  See Note 18 of the Notes to the Condensed Consolidated Financial Statements for more information about the Senior Notes principal repayment subsequent to October 29, 2021.

- added (2021-12-03):
[0001571996-21-000063:note_history:56]
EMC Notes — On September 7, 2016, as result of the merger with EMC, Dell acquired multiple outstanding Notes (collectively, the “EMC Notes”).  During the three months ended October 29, 2021, the Company repaid the remaining  $1.0 billion principal amount of the EMC Notes.

- changed (2021-12-03):
[0001571996-21-000063:note_history:57]
VMware Notes — VMware, Inc. completed public offerings of unsecured senior notes in the aggregate amounts of $4.0 billion, $2.0 billion, and $6.0 billion on August 21, 2017, April 7, 2020, and August 2, 2021, respectively (the “VMware Notes”).   None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.  Interest on outstanding borrowings is payable semiannually.
  (was, 2021-09-03, similarity 0.7057):
[0001571996-21-000040:note_history:57]
VMware Notes — VMware, Inc. completed public offerings of unsecured senior notes in the aggregate amounts of $4.0 billion and $2.0 billion on August 21, 2017 and April 7, 2020, respectively (the “VMware Notes”).  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.  Interest on outstanding borrowings is payable semiannually.  Subsequent to July 30, 2021, VMware, Inc. issued five series of unsecured senior notes (the “2021 VMware Notes”) in the aggregate principal amount of $6.0 billion pursuant to a public offering.  See Note 18 of the Notes to the Condensed Consolidated Financial Statements for more information about issuance of the 2021 VMware Notes.

- added (2021-12-03):
[0001571996-21-000063:note_history:58]
VMware Revolving Credit Facility and Term Loan Facilities — On September 12, 2017, VMware, Inc. entered into an unsecured credit agreement, that established a revolving credit facility (the “VMware Revolving Credit Facility”) with a syndicate of lenders that provided the company with a borrowing capacity of up to $1.0 billion for VMware, Inc. general corporate purposes.  On September 2, 2021, VMware, Inc. entered into an unsecured credit agreement establishing a revolving credit facility with a syndicate of lenders that provides VMware, Inc. with a borrowing capacity of up to $1.5 billion for general corporate purposes (the “2021 VMware Revolving Credit Facility”).  The 2021 VMware Revolving Credit Facility replaced VMware, Inc.’s existing $1.0 billion revolving credit facility that was undrawn.  Commitments under the 2021 Revolving Credit Facility are available for a period of five years, which may be extended, subject to the satisfaction of certain conditions, by up to two one-year periods.  The credit agreement contains certain representations, warranties and covenants.  Commitment fees, interest rates and other terms of borrowing under the 2021 Revolving Credit Facility may vary based on VMware’s external credit ratings.  As of October 29, 2021, there were no outstanding borrowings under the 2021 VMware Revolving Credit Facility.

- added (2021-12-03):
[0001571996-21-000063:note_history:59]
In addition, VMware, Inc. received commitments from financial institutions for a 3-year senior unsecured term loan facility and a 5-year senior unsecured term loan facility that would provide VMware, Inc. with a borrowing capacity of up to $4.0 billion (the “VMware Term Loan Facilities”).  VMware, Inc. may borrow against the term loan once up to its borrowing capacity of $4.0 billion.  Subsequent to October 29, 2021, and in advance of the close of the VMware Spin-off on November 1, 2021, VMware, Inc. borrowed $4.0 billion against the VMware Term Loan Facilities with the proceeds utilized to fund a portion of the special cash dividend paid by VMware, Inc. in connection with the VMware Spin-off transaction.  See Note 18 of the Notes to the Condensed Consolidated Financial Statements for more information about the VMware Spin-off transaction.

- added (2021-12-03):
[0001571996-21-000063:note_history:60]
None of the net proceeds of the 2021 VMware Revolving Credit Facility or the VMware Term Loan Facilities will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.

- changed (2021-12-03):
[0001571996-21-000063:note_history:61]
Margin Loan Facility — On April 12, 2017, the Company entered into the Margin Loan Facility in an aggregate principal amount of $2.0 billion.  In connection with the Class V transaction described in Note 1 of the Notes to the Condensed Consolidated Financial Statements, on December 20, 2018, the Company amended the Margin Loan Facility to increase the aggregate principal amount to $3.4 billion.  In connection with obtaining the Term Loan A-6 Facility during the fiscal year ended January 31, 2020, the Company increased the aggregate principal amount of the Margin Loan Facility to $4.0 billion.  VMware Holdco LLC, a wholly-owned subsidiary of EMC, was the borrower under the Margin Loan Facility, which was secured by approximately 76 million shares of Class B common stock of VMware, Inc. and approximately 24 million shares of Class A common stock of VMware, Inc.
  (was, 2021-09-03, similarity 0.7634):
[0001571996-21-000040:note_history:61]
Margin Loan Facility — On April 12, 2017, the Company entered into the Margin Loan Facility in an aggregate principal amount of $2.0 billion.  In connection with the Class V transaction described in Note 1 of the Notes to the Condensed Consolidated Financial Statements, on December 20, 2018, the Company amended the Margin Loan Facility to increase the aggregate principal amount to $3.35 billion.  In connection with obtaining the Term Loan A-6 Facility during the fiscal year ended January 31, 2020, the Company increased the aggregate principal amount of the Margin Loan Facility to $4.0 billion. VMware Holdco LLC, a wholly-owned subsidiary of EMC, is the borrower under the Margin Loan Facility, which is secured by approximately 76 million shares of Class B common stock of VMware, Inc. and approximately 24 million shares of Class A common stock of VMware, Inc.

- added (2021-12-03):
[0001571996-21-000063:note_history:62]
Loans under the Margin Loan Facility bore interest at a rate per annum payable, at the borrower’s option, either at (a) a base rate plus 1.25% per annum or (b) a LIBOR-based rate plus 2.25% per annum.  Interest under the Margin Loan Facility was payable quarterly.  The Margin Loan Facility was scheduled to mature in April 2022.  The borrower had the option to  voluntarily repay outstanding loans under the Margin Loan Facility at any time without premium or penalty, other than customary “breakage” costs, subject to certain minimum threshold amounts for prepayment.  During the nine months ended October 29, 2021, the Company repaid the $4.0 billion principal amount of the Margin Loan Facility.  Upon repayment, the VMware, Inc. common stock pledged to secure the Margin Loan Facility was released as collateral in accordance with the associated Margin Loan Facility agreement.

- changed (2021-12-03):
[0001571996-21-000063:note_history:63]
The following table presents the aggregate future maturities of the Company’s debt as of October 29, 2021 for the periods indicated:
  (was, 2021-09-03, similarity 0.9562):
[0001571996-21-000040:note_history:63]
The following table presents the aggregate future maturities of the Company’s debt as of July 30, 2021 for the periods indicated:

- added (2021-12-03):
[0001571996-21-000063:note_history:64]
|  | Maturities by Fiscal Year (a) |
|  | 2022(remaining three months) |  | 2023 |  | 2024 |  | 2025 |  | 2026 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Secured Credit Facilities and First Lien Notes | $ | 7,754 |  |  | $ | — |  |  | $ | 2,250 |  |  | $ | 1,000 |  |  | $ | 1,000 |  |  | $ | 12,750 |  |  | $ | 24,754 |  |
| Unsecured Notes and Debentures | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 952 |  |  | 952 |  |
| Senior Notes and EMC Notes | 1,625 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 1,625 |  |
| VMware Notes | — |  |  | 1,500 |  |  | 1,000 |  |  | 1,250 |  |  | 750 |  |  | 6,250 |  |  | 10,750 |  |
| DFS Debt | 1,378 |  |  | 5,019 |  |  | 1,888 |  |  | 1,016 |  |  | 86 |  |  | 590 |  |  | 9,977 |  |
| Other | 9 |  |  | 33 |  |  | 187 |  |  | 124 |  |  | 23 |  |  | 24 |  |  | 400 |  |
| Total maturities, principal amount | 10,766 |  |  | 6,552 |  |  | 5,325 |  |  | 3,390 |  |  | 1,859 |  |  | 20,566 |  |  | 48,458 |  |
| Associated carrying value adjustments | (94) |  |  | (7) |  |  | (20) |  |  | (20) |  |  | (6) |  |  | (332) |  |  | (479) |  |
| Total maturities, carrying value amount | $ | 10,672 |  |  | $ | 6,545 |  |  | $ | 5,305 |  |  | $ | 3,370 |  |  | $ | 1,853 |  |  | $ | 20,234 |  |  | $ | 47,979 |  |

- added (2021-12-03):
[0001571996-21-000063:note_history:65]
____________________

- added (2021-12-03):
[0001571996-21-000063:note_history:66]
(a) Maturities by Fiscal Year reflects $9.4 billion principal amount of debt within the remaining three months of Fiscal 2022 to align to the classification of this debt as short-term on the Condensed Consolidated Statements of Financial Position and reflect the Company’s intent to repay during the fourth quarter of Fiscal 2022.

- changed (2021-12-03):
[0001571996-21-000063:note_history:67]
As of October 29, 2021, the Company had certain consolidated subsidiaries that were designated as unrestricted subsidiaries for all purposes of the applicable credit agreements and the indentures governing the First Lien Notes and the Senior Notes.  Substantially all of the net assets of the Company’s consolidated subsidiaries were restricted, with the exception of the Company’s unrestricted subsidiaries, primarily VMware, Inc., Secureworks, and their respective subsidiaries, as of October 29, 2021.
  (was, 2021-09-03, similarity 0.9775):
[0001571996-21-000040:note_history:67]
As of July 30, 2021, the Company had certain consolidated subsidiaries that were designated as unrestricted subsidiaries for all purposes of the applicable credit agreements and the indentures governing the First Lien Notes and the Senior Notes.  Substantially all of the net assets of the Company’s consolidated subsidiaries were restricted, with the exception of the Company’s unrestricted subsidiaries, primarily VMware, Inc., Secureworks, and their respective subsidiaries, as of July 30, 2021.

- changed (2021-12-03):
[0001571996-21-000063:note_history:68]
The Senior Secured Credit Facilities and the Revolving Credit Facility are subject to a first lien leverage ratio covenant that is tested at the end of each fiscal quarter of Dell with respect to Dell’s preceding four fiscal quarters.  The Company was in compliance with all financial covenants as of October 29, 2021.
  (was, 2021-09-03, similarity 0.9822):
[0001571996-21-000040:note_history:68]
The Senior Secured Credit Facilities and the Revolving Credit Facility are subject to a first lien leverage ratio covenant that is tested at the end of each fiscal quarter of Dell with respect to Dell’s preceding four fiscal quarters.  The Company was in compliance with all financial covenants as of July 30, 2021.

- added (2021-12-03):
[0001571996-21-000063:note_history:69]
Subsequent to October 29, 2021 and following the full redemption of the outstanding term loan facilities and Senior Notes, the Existing Credit Agreement and the indenture governing the Senior Notes were terminated.  The 2021 Revolving Credit Facility contains customary negative covenants that generally limit the ability of Dell, Dell International L.L.C, and EMC to create liens and make fundamental changes.  The 2021 Revolving Credit Facility is subject to an interest coverage ratio covenant that is tested at the end of each fiscal quarter of Dell with respect to Dell’s preceding four fiscal quarters.  See Note 18 of the Notes to the Condensed Consolidated Financial Statements for more information about debt repayments that occurred subsequent to October 29, 2021.

- removed (2021-12-03):
[0001571996-21-000040:note_history:70]
offer, such registered first lien notes, together with the remaining unregistered First Lien Notes, are collectively referred to as “First Lien Notes” in these Notes to the Condensed Consolidated Financial Statements.

- removed (2021-12-03):
[0001571996-21-000040:note_history:71]
Senior Notes — The senior unsecured notes (collectively, the “Senior Notes”) were issued on June 22, 2016 in an aggregate principal amount of $3.25 billion.  Interest on outstanding borrowings is payable semiannually.

- removed (2021-12-03):
[0001571996-21-000040:note_history:72]
EMC Notes — On September 7, 2016, as result of the merger with EMC, Dell acquired multiple outstanding Notes (collectively, the “EMC Notes”), of which $1.0 billion aggregate principal amount of its 3.375% Note remains.  Interest on the outstanding borrowing is payable semiannually.

- removed (2021-12-03):
[0001571996-21-000040:note_history:73]
VMware Revolving Credit Facility — On September 12, 2017, VMware, Inc. entered into an unsecured credit agreement, establishing a revolving credit facility (the “VMware Revolving Credit Facility”) with a syndicate of lenders that provides the company with a borrowing capacity of up to $1.0 billion for VMware, Inc. general corporate purposes.  Commitments under the VMware Revolving Credit Facility are available for a period of five years, expiring September 12, 2022 and may be extended, subject to the satisfaction of certain conditions, by up to two one year periods.  The credit agreement contains certain representations, warranties, and covenants.  Commitment fees, interest rates, and other terms of borrowing under the VMware Revolving Credit Facility may vary based on VMware, Inc.’s external credit ratings.  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.  As of July 30, 2021, there were no outstanding borrowings under the VMware Revolving Credit Facility.

- removed (2021-12-03):
[0001571996-21-000040:note_history:74]
Loans under the Margin Loan Facility bear interest at a rate per annum payable, at the borrower’s option, either at (a) a base rate plus 1.25% per annum or (b) a LIBOR-based rate plus 2.25% per annum.  Interest under the Margin Loan Facility is payable quarterly.  The Margin Loan Facility will mature in April 2022.  The borrower may voluntarily repay outstanding loans under the Margin Loan Facility at any time without premium or penalty, other than customary “breakage” costs, subject to certain minimum threshold amounts for prepayment.  During the three months ended July 30, 2021, the Company repaid $3.0 billion principal amount of the Margin Loan Facility.  Subsequent to July 30, 2021, the Company repaid the remaining $1.0 billion principal amount of the Margin Loan Facility.  See Note 18 of the Notes to the Condensed Consolidated Financial Statements for more information about the Margin Loan Facility principal repayment, subsequent to July 30, 2021.

- removed (2021-12-03):
[0001571996-21-000040:note_history:75]
|  | Maturities by Fiscal Year |
|  | 2022(remaining six months) |  | 2023 |  | 2024 |  | 2025 |  | 2026 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Secured Credit Facilities and First Lien Notes | $ | 16 |  |  | $ | 213 |  |  | $ | 6,007 |  |  | $ | 1,758 |  |  | $ | 4,017 |  |  | $ | 12,750 |  |  | $ | 24,761 |  |
| Unsecured Notes and Debentures | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 952 |  |  | 952 |  |
| Senior Notes and EMC Notes | — |  |  | — |  |  | 1,000 |  |  | 1,625 |  |  | — |  |  | — |  |  | 2,625 |  |
| VMware Notes | — |  |  | 1,500 |  |  | — |  |  | — |  |  | 750 |  |  | 2,500 |  |  | 4,750 |  |
| DFS Debt | 2,752 |  |  | 4,463 |  |  | 1,454 |  |  | 851 |  |  | 37 |  |  | — |  |  | 9,557 |  |
| Margin Loan Facility | — |  |  | 1,000 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 1,000 |  |
| Other | 27 |  |  | 33 |  |  | 190 |  |  | 94 |  |  | 24 |  |  | 24 |  |  | 392 |  |
| Total maturities, principal amount | 2,795 |  |  | 7,209 |  |  | 8,651 |  |  | 4,328 |  |  | 4,828 |  |  | 16,226 |  |  | 44,037 |  |
| Associated carrying value adjustments | (3) |  |  | (5) |  |  | (27) |  |  | (65) |  |  | (45) |  |  | (298) |  |  | (443) |  |
| Total maturities, carrying value amount | $ | 2,792 |  |  | $ | 7,204 |  |  | $ | 8,624 |  |  | $ | 4,263 |  |  | $ | 4,783 |  |  | $ | 15,928 |  |  | $ | 43,594 |  |


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2021-12-03):
[0001571996-21-000063:note_history:76]
|  | October 29, 2021 |  | January 29, 2021 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Secured Credit Facilities | $ | 6.2 |  |  | $ | 6.3 |  |  | $ | 6.2 |  |  | $ | 6.3 |  |
| First Lien Notes | $ | 18.3 |  |  | $ | 22.8 |  |  | $ | 18.3 |  |  | $ | 22.8 |  |
| Unsecured Notes and Debentures | $ | 0.8 |  |  | $ | 1.2 |  |  | $ | 1.2 |  |  | $ | 1.6 |  |
| Senior Notes | $ | 1.6 |  |  | $ | 1.7 |  |  | $ | 2.7 |  |  | $ | 2.8 |  |
| EMC Notes | $ | — |  |  | $ | — |  |  | $ | 1.0 |  |  | $ | 1.0 |  |
| VMware Notes | $ | 10.7 |  |  | $ | 11.1 |  |  | $ | 4.7 |  |  | $ | 5.3 |  |
| Margin Loan Facility | $ | — |  |  | $ | — |  |  | $ | 4.0 |  |  | $ | 3.9 |  |

- removed (2021-12-03):
[0001571996-21-000040:note_history:77]
|  | July 30, 2021 |  | January 29, 2021 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Secured Credit Facilities | $ | 6.2 |  |  | $ | 6.3 |  |  | $ | 6.2 |  |  | $ | 6.3 |  |
| First Lien Notes | $ | 18.3 |  |  | $ | 23.1 |  |  | $ | 18.3 |  |  | $ | 22.8 |  |
| Unsecured Notes and Debentures | $ | 0.8 |  |  | $ | 1.2 |  |  | $ | 1.2 |  |  | $ | 1.6 |  |
| Senior Notes | $ | 1.6 |  |  | $ | 1.7 |  |  | $ | 2.7 |  |  | $ | 2.8 |  |
| EMC Notes | $ | 1.0 |  |  | $ | 1.0 |  |  | $ | 1.0 |  |  | $ | 1.0 |  |
| VMware Notes | $ | 4.7 |  |  | $ | 5.3 |  |  | $ | 4.7 |  |  | $ | 5.3 |  |
| Margin Loan Facility | $ | 1.0 |  |  | $ | 1.0 |  |  | $ | 4.0 |  |  | $ | 3.9 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-12-03):
[0001571996-21-000063:note_history:78]
|  | October 29, 2021 |  | January 29, 2021 |
|  | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing and securitization facilities | $ | 2,650 |  |  | $ | 3,311 |  |
| Fixed-term securitization offerings | 3,618 |  |  | 2,961 |  |
| Other | 147 |  |  | 140 |  |
| Total DFS U.S. debt | 6,415 |  |  | 6,412 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 751 |  |  | 786 |  |
| Other borrowings | 809 |  |  | 1,006 |  |
| Note payable | 250 |  |  | 250 |  |
| Dell Bank Senior Unsecured Eurobonds | 1,752 |  |  | 1,212 |  |
| Total DFS international debt | 3,562 |  |  | 3,254 |  |
| Total DFS debt | $ | 9,977 |  |  | $ | 9,666 |  |
| Total short-term DFS debt | $ | 5,475 |  |  | $ | 4,888 |  |
| Total long-term DFS debt | $ | 4,502 |  |  | $ | 4,778 |  |
  (was, 2021-09-03, similarity 0.9916):
[0001571996-21-000040:note_history:78]
|  | July 30, 2021 |  | January 29, 2021 |
|  | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing and securitization facilities | $ | 3,182 |  |  | $ | 3,311 |  |
| Fixed-term securitization offerings | 2,929 |  |  | 2,961 |  |
| Other | 176 |  |  | 140 |  |
| Total DFS U.S. debt | 6,287 |  |  | 6,412 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 768 |  |  | 786 |  |
| Other borrowings | 1,063 |  |  | 1,006 |  |
| Note payable | 250 |  |  | 250 |  |
| Dell Bank Senior Unsecured Eurobonds | 1,189 |  |  | 1,212 |  |
| Total DFS international debt | 3,270 |  |  | 3,254 |  |
| Total DFS debt | $ | 9,557 |  |  | $ | 9,666 |  |
| Total short-term DFS debt | $ | 5,281 |  |  | $ | 4,888 |  |
| Total long-term DFS debt | $ | 4,276 |  |  | $ | 4,778 |  |

- changed (2021-12-03):
[0001571996-21-000063:note_history:79]
|  | October 29, 2021 |  | January 29, 2021 |
|  | (in millions) |
| Secured Debt |  |  |  |
| Senior Secured Credit Facilities: |  |  |  |
| 2.00% Term Loan B-2 Facility due September 2025 (a) | $ | 3,120 |  |  | $ | 3,143 |  |
| 1.84% Term Loan A-6 Facility due March 2024 (a) | 3,134 |  |  | 3,134 |  |
| First Lien Notes: |  |  |  |
| 5.45% due June 2023 (a) | 3,750 |  |  | 3,750 |  |
| 4.00% due July 2024 | 1,000 |  |  | 1,000 |  |
| 5.85% due July 2025 | 1,000 |  |  | 1,000 |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 4.90% due October 2026 | 1,750 |  |  | 1,750 |  |
| 6.10% due July 2027 | 500 |  |  | 500 |  |
| 5.30% due October 2029 | 1,750 |  |  | 1,750 |  |
| 6.20% due July 2030 | 750 |  |  | 750 |  |
| 8.10% due July 2036 | 1,500 |  |  | 1,500 |  |
| 8.35% due July 2046 | 2,000 |  |  | 2,000 |  |
| Unsecured Debt |  |  |  |
| Unsecured Notes and Debentures: |  |  |  |
| 4.625% due April 2021 | — |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| Senior Notes: |  |  |  |
| 5.875% due June 2021 | — |  |  | 1,075 |  |
| 7.125% due June 2024 (a) | 1,625 |  |  | 1,625 |  |
| EMC Notes: |  |  |  |
| 3.375% due June 2023 | — |  |  | 1,000 |  |
| VMware Notes: |  |  |  |
| 2.95% due August 2022 | 1,500 |  |  | 1,500 |  |
| 0.60% due August 2023 | 1,000 |  |  | — |  |
| 1.00% due August 2024 | 1,250 |  |  | — |  |
| 4.50% due May 2025 | 750 |  |  | 750 |  |
| 1.40% due August 2026 | 1,500 |  |  | — |  |
| 4.65% due May 2027 | 500 |  |  | 500 |  |
| 3.90% due August 2027 | 1,250 |  |  | 1,250 |  |
| 1.80% due August 2028 | 750 |  |  | — |  |
| 4.70% due May 2030 | 750 |  |  | 750 |  |
| 2.20% due August 2031 | 1,500 |  |  | — |  |
| DFS Debt (Note 3) | 9,977 |  |  | 9,666 |  |
| Other |  |  |  |
| 2.44% Margin Loan Facility due April 2022 | — |  |  | 4,000 |  |
| Other | 400 |  |  | 235 |  |
| Total debt, principal amount | $ | 48,458 |  |  | $ | 48,480 |  |
  (was, 2021-09-03, similarity 0.7337):
[0001571996-21-000040:note_history:79]
|  | July 30, 2021 |  | January 29, 2021 |
|  | (in millions) |
| Secured Debt |  |  |  |
| Senior Secured Credit Facilities: |  |  |  |
| 2.00% Term Loan B-2 Facility due September 2025 | $ | 3,127 |  |  | $ | 3,143 |  |
| 1.86% Term Loan A-6 Facility due March 2024 | 3,134 |  |  | 3,134 |  |
| First Lien Notes: |  |  |  |
| 5.45% due June 2023 | 3,750 |  |  | 3,750 |  |
| 4.00% due July 2024 | 1,000 |  |  | 1,000 |  |
| 5.85% due July 2025 | 1,000 |  |  | 1,000 |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 4.90% due October 2026 | 1,750 |  |  | 1,750 |  |
| 6.10% due July 2027 | 500 |  |  | 500 |  |
| 5.30% due October 2029 | 1,750 |  |  | 1,750 |  |
| 6.20% due July 2030 | 750 |  |  | 750 |  |
| 8.10% due July 2036 | 1,500 |  |  | 1,500 |  |
| 8.35% due July 2046 | 2,000 |  |  | 2,000 |  |
| Unsecured Debt |  |  |  |
| Unsecured Notes and Debentures: |  |  |  |
| 4.625% due April 2021 | — |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| Senior Notes: |  |  |  |
| 5.875% due June 2021 | — |  |  | 1,075 |  |
| 7.125% due June 2024 | 1,625 |  |  | 1,625 |  |
| EMC Notes: |  |  |  |
| 3.375% due June 2023 | 1,000 |  |  | 1,000 |  |
| Debt of Public Subsidiary |  |  |  |
| VMware Notes: |  |  |  |
| 2.95% due August 2022 | 1,500 |  |  | 1,500 |  |
| 4.50% due May 2025 | 750 |  |  | 750 |  |
| 4.65% due May 2027 | 500 |  |  | 500 |  |
| 3.90% due August 2027 | 1,250 |  |  | 1,250 |  |
| 4.70% due May 2030 | 750 |  |  | 750 |  |
| DFS Debt (Note 3) | 9,557 |  |  | 9,666 |  |
| Other |  |  |  |
| 2.44% Margin Loan Facility due April 2022 | 1,000 |  |  | 4,000 |  |
| Other | 392 |  |  | 235 |  |
| Total debt, principal amount | $ | 44,037 |  |  | $ | 48,480 |  |

- changed (2021-12-03):
[0001571996-21-000063:note_history:80]
|  | October 29, 2021 |  | January 29, 2021 |
|  | (in millions) |
| Total debt, principal amount | $ | 48,458 |  |  | $ | 48,480 |  |
| Unamortized discount, net of unamortized premium | (175) |  |  | (194) |  |
| Debt issuance costs | (304) |  |  | (302) |  |
| Total debt, carrying value | $ | 47,979 |  |  | $ | 47,984 |  |
| Total short-term debt, carrying value (b) | $ | 16,280 |  |  | $ | 6,362 |  |
| Total long-term debt, carrying value | $ | 31,699 |  |  | $ | 41,622 |  |
  (was, 2021-09-03, similarity 0.9589):
[0001571996-21-000040:note_history:80]
|  | July 30, 2021 |  | January 29, 2021 |
|  | (in millions) |
| Total debt, principal amount | $ | 44,037 |  |  | $ | 48,480 |  |
| Unamortized discount, net of unamortized premium | (174) |  |  | (194) |  |
| Debt issuance costs | (269) |  |  | (302) |  |
| Total debt, carrying value | $ | 43,594 |  |  | $ | 47,984 |  |
| Total short-term debt, carrying value | $ | 6,427 |  |  | $ | 6,362 |  |
| Total long-term debt, carrying value | $ | 37,167 |  |  | $ | 41,622 |  |

- added (2021-12-03):
[0001571996-21-000063:note_history:81]
____________________

- added (2021-12-03):
[0001571996-21-000063:note_history:82]
(a)    Subsequent to October 29, 2021, the Company used the net proceeds from its $9.3 billion pro rata share of the cash dividend received in connection with the VMware Spin-off, as well as cash on hand, to repay $3.12 billion principal amount of the 2.00% Term Loan B-2 Facility due September 2025, $3.13 billion principal amount of the 1.84% Term Loan A-6 Facility due March 2024, $1.63 billion principal amount of the 7.125% Senior Notes due June 2024, and $1.50 billion principal amount of the 5.45% First Lien Notes due June 2023.

- added (2021-12-03):
[0001571996-21-000063:note_history:83]
(b)    Given the probability of the close of the VMware Spin-off and the Company’s intent and ability to repay, the Company classified $9.4 billion principal amount of debt as short-term liabilities on the Condensed Consolidated Statements of Financial Position as of October 29, 2021.


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-12-03):
[0001571996-21-000063:note_history:84]
The following table presents the aggregate future maturities of the Company’s debt as of October 29, 2021 for the periods indicated:
  (was, 2021-09-03, similarity 0.9562):
[0001571996-21-000040:note_history:84]
The following table presents the aggregate future maturities of the Company’s debt as of July 30, 2021 for the periods indicated:

- added (2021-12-03):
[0001571996-21-000063:note_history:85]
|  | Maturities by Fiscal Year (a) |
|  | 2022(remaining three months) |  | 2023 |  | 2024 |  | 2025 |  | 2026 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Secured Credit Facilities and First Lien Notes | $ | 7,754 |  |  | $ | — |  |  | $ | 2,250 |  |  | $ | 1,000 |  |  | $ | 1,000 |  |  | $ | 12,750 |  |  | $ | 24,754 |  |
| Unsecured Notes and Debentures | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 952 |  |  | 952 |  |
| Senior Notes and EMC Notes | 1,625 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 1,625 |  |
| VMware Notes | — |  |  | 1,500 |  |  | 1,000 |  |  | 1,250 |  |  | 750 |  |  | 6,250 |  |  | 10,750 |  |
| DFS Debt | 1,378 |  |  | 5,019 |  |  | 1,888 |  |  | 1,016 |  |  | 86 |  |  | 590 |  |  | 9,977 |  |
| Other | 9 |  |  | 33 |  |  | 187 |  |  | 124 |  |  | 23 |  |  | 24 |  |  | 400 |  |
| Total maturities, principal amount | 10,766 |  |  | 6,552 |  |  | 5,325 |  |  | 3,390 |  |  | 1,859 |  |  | 20,566 |  |  | 48,458 |  |
| Associated carrying value adjustments | (94) |  |  | (7) |  |  | (20) |  |  | (20) |  |  | (6) |  |  | (332) |  |  | (479) |  |
| Total maturities, carrying value amount | $ | 10,672 |  |  | $ | 6,545 |  |  | $ | 5,305 |  |  | $ | 3,370 |  |  | $ | 1,853 |  |  | $ | 20,234 |  |  | $ | 47,979 |  |

- added (2021-12-03):
[0001571996-21-000063:note_history:86]
____________________

- added (2021-12-03):
[0001571996-21-000063:note_history:87]
(a) Maturities by Fiscal Year reflects $9.4 billion principal amount of debt within the remaining three months of Fiscal 2022 to align to the classification of this debt as short-term on the Condensed Consolidated Statements of Financial Position and reflect the Company’s intent to repay during the fourth quarter of Fiscal 2022.

- removed (2021-12-03):
[0001571996-21-000040:note_history:88]
|  | Maturities by Fiscal Year |
|  | 2022(remaining six months) |  | 2023 |  | 2024 |  | 2025 |  | 2026 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Secured Credit Facilities and First Lien Notes | $ | 16 |  |  | $ | 213 |  |  | $ | 6,007 |  |  | $ | 1,758 |  |  | $ | 4,017 |  |  | $ | 12,750 |  |  | $ | 24,761 |  |
| Unsecured Notes and Debentures | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 952 |  |  | 952 |  |
| Senior Notes and EMC Notes | — |  |  | — |  |  | 1,000 |  |  | 1,625 |  |  | — |  |  | — |  |  | 2,625 |  |
| VMware Notes | — |  |  | 1,500 |  |  | — |  |  | — |  |  | 750 |  |  | 2,500 |  |  | 4,750 |  |
| DFS Debt | 2,752 |  |  | 4,463 |  |  | 1,454 |  |  | 851 |  |  | 37 |  |  | — |  |  | 9,557 |  |
| Margin Loan Facility | — |  |  | 1,000 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 1,000 |  |
| Other | 27 |  |  | 33 |  |  | 190 |  |  | 94 |  |  | 24 |  |  | 24 |  |  | 392 |  |
| Total maturities, principal amount | 2,795 |  |  | 7,209 |  |  | 8,651 |  |  | 4,328 |  |  | 4,828 |  |  | 16,226 |  |  | 44,037 |  |
| Associated carrying value adjustments | (3) |  |  | (5) |  |  | (27) |  |  | (65) |  |  | (45) |  |  | (298) |  |  | (443) |  |
| Total maturities, carrying value amount | $ | 2,792 |  |  | $ | 7,204 |  |  | $ | 8,624 |  |  | $ | 4,263 |  |  | $ | 4,783 |  |  | $ | 15,928 |  |  | $ | 43,594 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-12-03):
[0001571996-21-000063:note_history:89]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 29, 2021 |  | October 30, 2020 |  | October 29, 2021 |  | October 30, 2020 |
|  | (in millions) |
| Net revenue: |  |  |  |  |  |  |  |
| Infrastructure Solutions Group: |  |  |  |  |  |  |  |
| Servers and networking | $ | 4,533 |  |  | $ | 4,164 |  |  | $ | 13,104 |  |  | $ | 12,118 |  |
| Storage | 3,895 |  |  | 3,860 |  |  | 11,667 |  |  | 11,682 |  |
| Total ISG net revenue | 8,428 |  |  | 8,024 |  |  | 24,771 |  |  | 23,800 |  |
| Client Solutions Group: |  |  |  |  |  |  |  |
| Commercial | 12,292 |  |  | 8,783 |  |  | 32,668 |  |  | 25,456 |  |
| Consumer | 4,254 |  |  | 3,503 |  |  | 11,446 |  |  | 9,137 |  |
| Total CSG net revenue | 16,546 |  |  | 12,286 |  |  | 44,114 |  |  | 34,593 |  |
| VMware: |  |  |  |  |  |  |  |
| Total VMware net revenue | 3,178 |  |  | 2,893 |  |  | 9,317 |  |  | 8,556 |  |
| Total segment net revenue | $ | 28,152 |  |  | $ | 23,203 |  |  | $ | 78,202 |  |  | $ | 66,949 |  |
  (was, 2021-09-03, similarity 0.9275):
[0001571996-21-000040:note_history:89]
|  | Three Months Ended |  | Six Months Ended |
|  | July 30, 2021 |  | July 31, 2020 |  | July 30, 2021 |  | July 31, 2020 |
|  | (in millions) |
| Net revenue: |  |  |  |  |  |  |  |
| Infrastructure Solutions Group: |  |  |  |  |  |  |  |
| Servers and networking | $ | 4,462 |  |  | $ | 4,196 |  |  | $ | 8,571 |  |  | $ | 7,954 |  |
| Storage | 3,970 |  |  | 4,011 |  |  | 7,772 |  |  | 7,822 |  |
| Total ISG net revenue | 8,432 |  |  | 8,207 |  |  | 16,343 |  |  | 15,776 |  |
| Client Solutions Group: |  |  |  |  |  |  |  |
| Commercial | 10,573 |  |  | 8,039 |  |  | 20,376 |  |  | 16,673 |  |
| Consumer | 3,690 |  |  | 3,164 |  |  | 7,192 |  |  | 5,634 |  |
| Total CSG net revenue | 14,263 |  |  | 11,203 |  |  | 27,568 |  |  | 22,307 |  |
| VMware: |  |  |  |  |  |  |  |
| Total VMware net revenue | 3,148 |  |  | 2,908 |  |  | 6,139 |  |  | 5,663 |  |
| Total segment net revenue | $ | 25,843 |  |  | $ | 22,318 |  |  | $ | 50,050 |  |  | $ | 43,746 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2021-12-03):
[0001571996-21-000063:note_history:90]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 29, 2021 |  | October 30, 2020 |  | October 29, 2021 |  | October 30, 2020 |
|  | (in millions) |
| Deferred revenue: |  |  |  |  |  |  |  |
| Deferred revenue at beginning of period | $ | 31,843 |  |  | $ | 28,791 |  |  | $ | 30,801 |  |  | $ | 27,800 |  |
| Revenue deferrals | 5,706 |  |  | 5,432 |  |  | 18,889 |  |  | 17,560 |  |
| Revenue recognized | (6,095) |  |  | (5,542) |  |  | (18,092) |  |  | (16,418) |  |
| Other (a) | — |  |  | — |  |  | (144) |  |  | (261) |  |
| Deferred revenue at end of period | $ | 31,454 |  |  | $ | 28,681 |  |  | $ | 31,454 |  |  | $ | 28,681 |  |
| Short-term deferred revenue | $ | 16,569 |  |  | $ | 15,259 |  |  | $ | 16,569 |  |  | $ | 15,259 |  |
| Long-term deferred revenue | $ | 14,885 |  |  | $ | 13,422 |  |  | $ | 14,885 |  |  | $ | 13,422 |  |

- added (2021-12-03):
[0001571996-21-000063:note_history:91]
(a) For the nine months ended October 29, 2021, Other consists of divested deferred revenue from the sale of Boomi.  For the nine months ended October 30, 2020, Other consists of divested deferred revenue from the sale of RSA Security.  See Note 1 of the Notes to the Condensed Consolidated Financial Statements for more information about the divestitures of Boomi and of RSA Security.  There was no impact to deferred revenue for the three months ended October 29, 2021 or October 30, 2020 as liabilities in both instances were previously classified as held for sale.

- changed (2021-12-03):
[0001571996-21-000063:note_history:92]
Remaining Performance Obligations — Remaining performance obligations represent the aggregate amount of the transaction price allocated to performance obligations not delivered, or partially undelivered, as of the end of the reporting period.  Remaining performance obligations include deferred revenue plus unbilled amounts not yet recorded in deferred revenue.  The value of the transaction price allocated to remaining performance obligations as of October 29, 2021 was approximately $47 billion.  The Company expects to recognize approximately 62% of remaining performance obligations as revenue in the next twelve months, and the remainder thereafter.
  (was, 2021-09-03, similarity 0.9915):
[0001571996-21-000040:note_history:92]
Remaining Performance Obligations — Remaining performance obligations represent the aggregate amount of the transaction price allocated to performance obligations not delivered, or partially undelivered, as of the end of the reporting period.  Remaining performance obligations include deferred revenue plus unbilled amounts not yet recorded in deferred revenue.  The value of the transaction price allocated to remaining performance obligations as of July 30, 2021 was approximately $46 billion.  The Company expects to recognize approximately 61% of remaining performance obligations as revenue in the next twelve months, and the remainder thereafter.

- removed (2021-12-03):
[0001571996-21-000040:note_history:93]
|  | Three Months Ended |  | Six Months Ended |
|  | July 30, 2021 |  | July 31, 2020 |  | July 30, 2021 |  | July 31, 2020 |
|  | (in millions) |
| Deferred revenue: |  |  |  |  |  |  |  |
| Deferred revenue at beginning of period | $ | 31,376 |  |  | $ | 27,617 |  |  | $ | 30,801 |  |  | $ | 27,800 |  |
| Revenue deferrals | 6,674 |  |  | 6,550 |  |  | 13,154 |  |  | 12,095 |  |
| Revenue recognized | (6,052) |  |  | (5,376) |  |  | (11,957) |  |  | (10,843) |  |
| Other (a) | (155) |  |  | — |  |  | (155) |  |  | (261) |  |
| Deferred revenue at end of period | $ | 31,843 |  |  | $ | 28,791 |  |  | $ | 31,843 |  |  | $ | 28,791 |  |
| Short-term deferred revenue | $ | 17,003 |  |  | $ | 15,341 |  |  | $ | 17,003 |  |  | $ | 15,341 |  |
| Long-term deferred revenue | $ | 14,840 |  |  | $ | 13,450 |  |  | $ | 14,840 |  |  | $ | 13,450 |  |

- removed (2021-12-03):
[0001571996-21-000040:note_history:94]
(a) For the three and six months ended July 30, 2021, Other represents the reclassification of Boomi deferred revenue to liabilities held for sale.  For the six months ended July 31, 2020, Other represents the reclassification of RSA Security deferred revenue to liabilities held for sale.  See Note 1 of the Notes to the Condensed Consolidated Financial Statements for more information about the divestitures of Boomi and of RSA Security.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2021-12-03):
[0001571996-21-000063:note_history:95]
SUBSEQUENT EVENTS 
Spin-off of VMware, Inc.

- added (2021-12-03):
[0001571996-21-000063:note_history:96]
On November 1, 2021, the Company completed its previously announced spin-off of VMware, Inc. as described in Note 1 of the Notes to the Condensed Consolidated Financial Statements.  Dell Technologies effectuated the VMware Spin-off by means of a special stock dividend of 30,678,605 shares of Class A common stock and 307,221,836 shares of Class B common stock of VMware, Inc. to Dell Technologies stockholders of record as of 5:00 p.m., New York City time, on October 29, 2021.

- added (2021-12-03):
[0001571996-21-000063:note_history:97]
Prior to receipt of the VMware, Inc. common stock by the Company’s stockholders, each share of VMware, Inc. Class B common stock automatically converted into one share of VMware, Inc. Class A common stock.  As result of these transactions, each holder of record of shares of Dell Technologies common stock as of the distribution record date received approximately 0.440626 of a share of VMware Class A common stock for each share of Dell Technologies common stock held as of such date, based on shares outstanding as of the completion of the VMware Spin-off.

- added (2021-12-03):
[0001571996-21-000063:note_history:98]
Immediately following the payment by VMware, Inc. to its stockholders of a special cash dividend of $11.5 billion, of which Dell Technologies received approximately $9.3 billion, the separation of VMware, Inc. from Dell Technologies occurred, including through the termination or settlement of certain intercompany accounts and intercompany contracts.

- added (2021-12-03):
[0001571996-21-000063:note_history:99]
Repayment of Indebtedness and Termination of the Existing Credit Agreement

- added (2021-12-03):
[0001571996-21-000063:note_history:100]
The Company used the net proceeds from its $9.3 billion pro rata portion of the cash dividend received in connection with the VMware Spin-off, as well as cash on hand, to repay outstanding debt as described below.

- added (2021-12-03):
[0001571996-21-000063:note_history:101]
On November 1, 2021, the Company repaid the remaining $3,134 million and $3,120 million principal amounts related to the 1.84% Term Loan A-6 Facility due March 2024 and the 2.00% Term Loan B-2 Facility due September 2025, respectively, and terminated all obligations and commitments under the Existing Credit Agreement.

- added (2021-12-03):
[0001571996-21-000063:note_history:102]
On November 2, 2021, the Company repaid $1,500 million principal amount of the 5.45% First Lien Notes due June 2023 and the remaining $1,625 million principal amount of the 7.125% Senior Notes due June 2024.  Further, in conjunction with the termination of the Existing Credit Agreement, the tangible and intangible assets of the issuers and guarantors that secure obligations under the Senior Secured Credit Facilities were released as collateral and the First Lien Notes became fully unsecured.

- added (2021-12-03):
[0001571996-21-000063:note_history:103]
In connection with the above debt repayments, the Company incurred $181 million of debt breakage fees and recognized $110 million in unamortized debt discounts associated with the early extinguishment of the debt.

- added (2021-12-03):
[0001571996-21-000063:note_history:104]
2021 Revolving Credit Facility

- added (2021-12-03):
[0001571996-21-000063:note_history:105]
On November 1, 2021, the Company entered into the 2021 Revolving Credit Facility, a senior unsecured revolving credit facility with JPMorgan Chase Bank, N.A., as administrative agent, and each of the lenders and other parties from time to time party thereto.

- added (2021-12-03):
[0001571996-21-000063:note_history:106]
The 2021 Revolving Credit Facility, which matures on November 1, 2026, provides the Company with revolving commitments in an aggregate principal amount of $5.0 billion for general corporate purposes and includes a letter of credit sub-facility of up to $500 million and a swing-line loan sub-facility of up to $500 million.  The 2021 Revolving Credit Facility also allows the Company to request incremental commitments on one or more occasions in a minimum amount of $10 million.

- added (2021-12-03):
[0001571996-21-000063:note_history:107]
2023 First Lien Notes Notice of Prepayment

- added (2021-12-03):
[0001571996-21-000063:note_history:108]
On November 19, 2021, the Company issued a partial redemption notice of $1.25 billion principal amount of the 5.45% First Lien Notes due June 2023 with the repayment expected to occur on December 6, 2021.

- added (2021-12-03):
[0001571996-21-000063:note_history:109]
Common Stock Repurchases

- added (2021-12-03):
[0001571996-21-000063:note_history:110]
Subsequent to October 29, 2021, the Company began repurchases under the 2021 Stock Repurchase Program described in Note 13 of the Notes to the Condensed Consolidated Financial Statements.  Through November 30, 2021, the Company repurchased  approximately 3.1 million shares of Class C Common Stock for approximately $173 million.

- changed (2021-12-03):
[0001571996-21-000063:note_history:111]
Other than the matters identified above, there were no known events occurring after October 29, 2021 and up until the date of issuance of this report that would materially affect the information presented herein.
  (was, 2021-09-03, similarity 0.9732):
[0001571996-21-000040:note_history:111]
Other than the matters identified above, there were no known events occurring after July 30, 2021 and up until the date of issuance of this report that would materially affect the information presented herein.

- removed (2021-12-03):
[0001571996-21-000040:note_history:112]
SUBSEQUENT EVENTS 
VMware, Inc. Unsecured Senior Notes - Public Debt Offering

- removed (2021-12-03):
[0001571996-21-000040:note_history:113]
On August 2, 2021, VMware, Inc. issued five series of unsecured senior notes pursuant to a public offering in the aggregate principal amount of $6.0 billion, consisting of outstanding principal due on the following dates:

- removed (2021-12-03):
[0001571996-21-000040:note_history:114]
•$1.0 billion 0.60% Senior Note due August 15, 2023

- removed (2021-12-03):
[0001571996-21-000040:note_history:115]
•$1.25 billion 1.00% Senior Note due August 15, 2024

- removed (2021-12-03):
[0001571996-21-000040:note_history:116]
•$1.5 billion 1.40% Senior Note due August 15, 2026

- removed (2021-12-03):
[0001571996-21-000040:note_history:117]
•$750 million 1.80% Senior Note due August 15, 2028

- removed (2021-12-03):
[0001571996-21-000040:note_history:118]
•$1.5 billion 2.20% Senior Note due August 15, 2031

- removed (2021-12-03):
[0001571996-21-000040:note_history:119]
The 2021 VMware Notes are payable semi annually on February 15 and August 15 of each year, commencing on February 15, 2022.

- removed (2021-12-03):
[0001571996-21-000040:note_history:120]
The net proceeds from the 2021 VMware Notes are expected to be used by VMware, Inc. to fund a portion of the cash dividend payable in connection with the VMware Spin-off pursuant to the terms of the Separation and Distribution Agreement entered into on April 14, 2021 and, to the extent any proceeds remain, for general VMware, Inc. corporate purposes.  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.  See Note 1 of the Notes to the Condensed Consolidated Financial Statements included in this report for additional information related to the VMware Spin-off.

- removed (2021-12-03):
[0001571996-21-000040:note_history:121]
VMware, Inc. Revolving Credit Facility and Term Loan Facilities

- removed (2021-12-03):
[0001571996-21-000040:note_history:122]
On September 2, 2021, VMware, Inc. entered into an unsecured credit agreement establishing a revolving credit facility with a syndicate of lenders that provides VMware, Inc. with a borrowing capacity of up to $1.5 billion for general corporate purposes (the “2021 VMware Revolving Credit Facility”).  The 2021 VMware Revolving Credit Facility will replace VMware, Inc.’s existing $1.0 billion revolving credit facility that is currently undrawn.

- removed (2021-12-03):
[0001571996-21-000040:note_history:123]
In addition, VMware, Inc. received commitments from financial institutions for a 3-year senior unsecured term loan facility and a 5-year senior unsecured term loan facility that would provide VMware, Inc. with a borrowing capacity of up to $4.0 billion, which, if funded, may be used to finance a portion of the Special Dividend and for VMware, Inc. general corporate purposes. VMware, Inc. may borrow against the term loan once up to its borrowing capacity of $4.0 billion until the earlier of (x) April 28, 2022 and (y) the date on which the Separation Agreement is terminated.  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.

- removed (2021-12-03):
[0001571996-21-000040:note_history:124]
Margin Loan Facility

- removed (2021-12-03):
[0001571996-21-000040:note_history:125]
Subsequent to July 30, 2021, the Company repaid the remaining $1.0 billion principal amount of the Margin Loan Facility due April 2022.  Upon repayment, the VMware, Inc. common stock pledged to secure the Margin Loan Facility was released as collateral in accordance with the associated Margin Loan Facility agreement.
