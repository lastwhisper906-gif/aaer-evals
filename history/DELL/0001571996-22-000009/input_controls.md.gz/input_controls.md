# DELL 10-K controls and the auditor's report


## auditors_report

[0001571996-22-000009:auditors_report:1]
Report of Independent Registered Public Accounting Firm

[0001571996-22-000009:auditors_report:2]
To the Board of Directors and Stockholders of Dell Technologies Inc.

[0001571996-22-000009:auditors_report:3]
Opinions on the Financial Statements and Internal Control over Financial Reporting

[0001571996-22-000009:auditors_report:4]
We have audited the accompanying consolidated statements of financial position of Dell Technologies Inc. and its subsidiaries (the “Company”) as of January 28, 2022 and January 29, 2021, and the related consolidated statements of income, of comprehensive income, of stockholders’ equity (deficit) and of cash flows for each of the three years in the period ended January 28, 2022, including the related notes (collectively referred to as the “consolidated financial statements”).  We also have audited the Company's internal control over financial reporting as of January 28, 2022, based on criteria established in Internal Control - Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (COSO).

[0001571996-22-000009:auditors_report:5]
In our opinion, the consolidated financial statements referred to above present fairly, in all material respects, the financial position of the Company as of January 28, 2022 and January 29, 2021, and the results of its operations and its cash flows for each of the three years in the period ended January 28, 2022 in conformity with accounting principles generally accepted in the United States of America.  Also in our opinion, the Company maintained, in all material respects, effective internal control over financial reporting as of January 28, 2022, based on criteria established in Internal Control - Integrated Framework (2013) issued by the COSO.

[0001571996-22-000009:auditors_report:6]
Change in Accounting Principle

[0001571996-22-000009:auditors_report:7]
As discussed in Note 2 to the consolidated financial statements, the Company changed the manner in which it accounts for leases as of February 2, 2019.

[0001571996-22-000009:auditors_report:8]
Basis for Opinions

[0001571996-22-000009:auditors_report:9]
The Company's management is responsible for these consolidated financial statements, for maintaining effective internal control over financial reporting, and for its assessment of the effectiveness of internal control over financial reporting, included in Management's Annual Report on Internal Control Over Financial Reporting appearing under Item 9A.  Our responsibility is to express opinions on the Company’s consolidated financial statements and on the Company's internal control over financial reporting based on our audits.  We are a public accounting firm registered with the Public Company Accounting Oversight Board (United States) (PCAOB) and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0001571996-22-000009:auditors_report:10]
We conducted our audits in accordance with the standards of the PCAOB.  Those standards require that we plan and perform the audits to obtain reasonable assurance about whether the consolidated financial statements are free of material misstatement, whether due to error or fraud, and whether effective internal control over financial reporting was maintained in all material respects.

[0001571996-22-000009:auditors_report:11]
Our audits of the consolidated financial statements included performing procedures to assess the risks of material misstatement of the consolidated financial statements, whether due to error or fraud, and performing procedures that respond to those risks.  Such procedures included examining, on a test basis, evidence regarding the amounts and disclosures in the consolidated financial statements.  Our audits also included evaluating the accounting principles used and significant estimates made by management, as well as evaluating the overall presentation of the consolidated financial statements.  Our audit of internal control over financial reporting included obtaining an understanding of internal control over financial reporting, assessing the risk that a material weakness exists, and testing and evaluating the design and operating effectiveness of internal control based on the assessed risk.  Our audits also included performing such other procedures as we considered necessary in the circumstances.  We believe that our audits provide a reasonable basis for our opinions.

[0001571996-22-000009:auditors_report:12]
Definition and Limitations of Internal Control over Financial Reporting

[0001571996-22-000009:auditors_report:13]
A company’s internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles.  A company’s internal control over financial reporting includes those policies and procedures that (i) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and

[0001571996-22-000009:auditors_report:14]
dispositions of the assets of the company; (ii) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the company are being made only in accordance with authorizations of management and directors of the company; and (iii) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the company’s assets that could have a material effect on the financial statements.

[0001571996-22-000009:auditors_report:15]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements.  Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0001571996-22-000009:auditors_report:16]
Critical Audit Matters

[0001571996-22-000009:auditors_report:17]
The critical audit matters communicated below are matters arising from the current period audit of the consolidated financial statements that were communicated or required to be communicated to the audit committee and that (i) relate to accounts or disclosures that are material to the consolidated financial statements and (ii) involved our especially challenging, subjective, or complex judgments.  The communication of critical audit matters does not alter in any way our opinion on the consolidated financial statements, taken as a whole, and we are not, by communicating the critical audit matters below, providing separate opinions on the critical audit matters or on the accounts or disclosures to which they relate.

[0001571996-22-000009:auditors_report:18]
Revenue Recognition - Identification of Performance Obligations in Revenue Contracts

[0001571996-22-000009:auditors_report:19]
As described in Notes 2 and 19 to the consolidated financial statements, the Company’s contracts with customers often include the promise to transfer multiple goods and services to a customer.  Distinct promises within a contract are referred to as performance obligations and are accounted for as separate units of account.  Management assesses whether each promised good or service is distinct for the purpose of identifying the performance obligations in the contract.  This assessment involves subjective determinations and requires management to make judgments about the individual promised goods or services and whether such goods or services are separable from the other aspects of the contractual relationship.  The Company’s performance obligations include various distinct goods and services such as hardware, software licenses, support and maintenance agreements, and other service offerings and solutions.  For the year ended January 28, 2022, a significant portion of the $34.4 billion Infrastructure Solutions Group (“ISG”) reportable segment net revenues relate to contracts with multiple performance obligations.

[0001571996-22-000009:auditors_report:20]
The principal considerations for our determination that performing procedures relating to the identification of performance obligations in revenue contracts is a critical audit matter are the significant judgment by management in identifying performance obligations in revenue contracts, which in turn led to a high degree of auditor judgment, subjectivity and effort in performing procedures to evaluate whether performance obligations in revenue contracts were appropriately identified by management.

[0001571996-22-000009:auditors_report:21]
Addressing the matter involved performing procedures and evaluating audit evidence in connection with forming our overall opinion on the consolidated financial statements.  These procedures included testing the effectiveness of controls relating to the revenue recognition process, including controls related to the proper identification of performance obligations in revenue contracts.  These procedures also included, among others, testing the completeness and accuracy of management’s identification of performance obligations by examining revenue contracts on a test basis.

[0001571996-22-000009:auditors_report:22]
Tax-free Determination of the Distribution of VMware Inc.

[0001571996-22-000009:auditors_report:23]
As described in Note 3 to the consolidated financial statements, management determined that the VMware Spin-off, and related distributions, qualified as tax-free for U.S. federal income tax purposes, which required significant judgment.  In making these determinations, management applied U.S. federal tax law to relevant facts and circumstances and obtained a favorable private letter ruling from the Internal Revenue Service, a tax opinion, and other external tax advice related to the concluded tax treatment.  If the completed transactions were to fail to qualify for tax-free treatment, the Company could be subject to significant liabilities, and there could be material adverse impacts on the Company’s business, financial condition, results of operations and cash flows in future reporting periods.

[0001571996-22-000009:auditors_report:24]
The principal considerations for our determination that performing procedures relating to the tax-free determination of the distribution of VMware Inc. is a critical audit matter are the significant judgment by management regarding the tax technical merits of the transaction and the application of the appropriate tax laws and regulations in determining that the distribution of VMware qualifies for tax-free status.  This in turn led to a high degree of auditor judgment, subjectivity and effort in

[0001571996-22-000009:auditors_report:25]
performing procedures and evaluating audit evidence relating to the tax-free determination of the distribution of VMware.  In addition, the audit effort involved the use of professionals with specialized skill and knowledge.

[0001571996-22-000009:auditors_report:26]
Addressing the matter involved performing procedures and evaluating audit evidence in connection with forming our overall opinion on the consolidated financial statements.  These procedures included testing the effectiveness of controls relating to the key judgments and evaluation of the tax treatment relating to management’s determination of the tax-free nature of the transaction.  These procedures also included, among others (i) testing management’s process for determining the tax-free treatment of the transaction, (ii) evaluating the information used in management’s determination, including tax rulings from relevant taxing authorities and supporting information, tax opinion, and relevant tax laws, and (iii) evaluating the reasonableness of management’s position that the transaction qualifies for tax-free status.  Professionals with specialized skill and knowledge were used to assist in the evaluation of the transaction, related assumptions, private letter ruling and tax opinion, and certain representations from management, as well as the application of relevant tax laws.

[0001571996-22-000009:auditors_report:27]
/s/ PricewaterhouseCoopers LLP

[0001571996-22-000009:auditors_report:28]
Austin, Texas

[0001571996-22-000009:auditors_report:29]
March 24, 2022

[0001571996-22-000009:auditors_report:30]
We have served as the Company’s auditor since 1986.

[0001571996-22-000009:auditors_report:31]
DELL TECHNOLOGIES INC.

[0001571996-22-000009:auditors_report:32]
CONSOLIDATED STATEMENTS OF FINANCIAL POSITION

[0001571996-22-000009:auditors_report:33]
(in millions; continued on next page)

[0001571996-22-000009:auditors_report:34]
|  | January 28, 2022 |  | January 29, 2021 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 9,477 |  |  | $ | 9,508 |  |
| Accounts receivable, net of allowance of $90 and $99 (Note 20) | 12,912 |  |  | 10,731 |  |
| Due from related party, net | 131 |  |  | 115 |  |
| Short-term financing receivables, net of allowance of $142 and $228 (Note 5) | 5,089 |  |  | 5,148 |  |
| Inventories | 5,898 |  |  | 3,403 |  |
| Other current assets | 11,526 |  |  | 9,810 |  |
| Current assets of discontinued operations (Note 3) | — |  |  | 4,852 |  |
| Total current assets | 45,033 |  |  | 43,567 |  |
| Property, plant, and equipment, net | 5,415 |  |  | 4,833 |  |
| Long-term investments | 1,839 |  |  | 1,334 |  |
| Long-term financing receivables, net of allowance of $47 and $93 (Note 5) | 5,522 |  |  | 5,339 |  |
| Goodwill | 19,770 |  |  | 20,028 |  |
| Intangible assets, net | 7,461 |  |  | 9,115 |  |
| Due from related party, net | 710 |  |  | 451 |  |
| Other non-current assets | 6,985 |  |  | 6,733 |  |
| Non-current assets of discontinued operations (Note 3) | — |  |  | 32,015 |  |
| Total assets | $ | 92,735 |  |  | $ | 123,415 |  |
| LIABILITIES, REDEEMABLE SHARES, AND STOCKHOLDERS’ EQUITY (continued on next page) |
| Current liabilities: |  |  |  |
| Short-term debt | $ | 5,823 |  |  | $ | 6,357 |  |
| Accounts payable | 27,143 |  |  | 21,572 |  |
| Due to related party | 1,414 |  |  | 1,461 |  |
| Accrued and other | 7,578 |  |  | 7,166 |  |
| Short-term deferred revenue | 14,261 |  |  | 13,201 |  |
| Current liabilities of discontinued operations (Note 3) | — |  |  | 4,375 |  |
| Total current liabilities | 56,219 |  |  | 54,132 |  |
| Long-term debt | 21,131 |  |  | 32,865 |  |
| Long-term deferred revenue | 13,312 |  |  | 12,391 |  |
| Other non-current liabilities | 3,653 |  |  | 3,923 |  |
| Non-current liabilities of discontinued operations (Note 3) | — |  |  | 12,079 |  |
| Total liabilities | 94,315 |  |  | 115,390 |  |

[0001571996-22-000009:auditors_report:35]
The accompanying notes are an integral part of these Consolidated Financial Statements.

[0001571996-22-000009:auditors_report:36]
80

[0001571996-22-000009:auditors_report:37]
DELL TECHNOLOGIES INC.

[0001571996-22-000009:auditors_report:38]
CONSOLIDATED STATEMENTS OF FINANCIAL POSITION

[0001571996-22-000009:auditors_report:39]
(continued; in millions)

[0001571996-22-000009:auditors_report:40]
|  | January 28, 2022 |  | January 29, 2021 |
| LIABILITIES, REDEEMABLE SHARES, AND STOCKHOLDERS’ EQUITY (continued) |
| Commitments and contingencies (Note 11) |  |  |  |
| Redeemable shares (Note 17) | — |  |  | 472 |  |
| Stockholders’ equity (deficit): |  |  |  |
| Common stock and capital in excess of $0.01 par value (Note 14) | 7,898 |  |  | 16,849 |  |
| Treasury stock at cost | (964) |  |  | (305) |  |
| Accumulated deficit | (8,188) |  |  | (13,751) |  |
| Accumulated other comprehensive loss | (431) |  |  | (314) |  |
| Total Dell Technologies Inc. stockholders’ equity (deficit) | (1,685) |  |  | 2,479 |  |
| Non-controlling interests | 105 |  |  | 96 |  |
| Non-controlling interests of discontinued operations | — |  |  | 4,978 |  |
| Total stockholders’ equity (deficit) | (1,580) |  |  | 7,553 |  |
| Total liabilities, redeemable shares, and stockholders’ equity | $ | 92,735 |  |  | $ | 123,415 |  |

[0001571996-22-000009:auditors_report:41]
The accompanying notes are an integral part of these Consolidated Financial Statements.

[0001571996-22-000009:auditors_report:42]
DELL TECHNOLOGIES INC.


## item_9a

[0001571996-22-000009:item_9a:1]
ITEM 9A — CONTROLS AND PROCEDURES

[0001571996-22-000009:item_9a:2]
This report includes the certifications of our Chief Executive Officer and Chief Financial Officer required by Rule 13a-14 under the Securities Exchange Act of 1934 (the “Exchange Act”).  See Exhibits 31.1 and 31.2 filed with this report.  This Item 9A includes information concerning the controls and control evaluations referred to in those certifications.

[0001571996-22-000009:item_9a:3]
Evaluation of Disclosure Controls and Procedures

[0001571996-22-000009:item_9a:4]
Disclosure controls and procedures (as defined in Rules 13a-15(e) and 15d-15(e) under the Exchange Act) are designed to provide reasonable assurance that information required to be disclosed in reports filed or submitted under the Exchange Act is recorded, processed, summarized, and reported within the time periods specified in SEC rules and forms and that such information is accumulated and communicated to management, including the Chief Executive Officer and the Chief Financial Officer, as appropriate to allow timely decisions regarding required disclosures.

[0001571996-22-000009:item_9a:5]
In connection with the preparation of this report, our management, under the supervision and with the participation of our Chief Executive Officer and Chief Financial Officer, conducted an evaluation of the effectiveness of the design and operation of our disclosure controls and procedures as of January 28, 2022.  Based on that evaluation, our Chief Executive Officer and Chief Financial Officer have concluded that our disclosure controls and procedures were effective at the reasonable assurance level as of January 28, 2022.

[0001571996-22-000009:item_9a:6]
Management’s Annual Report on Internal Control Over Financial Reporting

[0001571996-22-000009:item_9a:7]
Management, under the supervision of the Chief Executive Officer and the Chief Financial Officer, is responsible for establishing and maintaining adequate internal control over financial reporting.  Internal control over financial reporting (as defined in Rules 13a-15(f) and 15d(f) under the Exchange Act) is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles.  Internal control over financial reporting includes those policies and procedures which (a) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of assets, (b) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, (c) provide reasonable assurance that receipts and expenditures are being made only in accordance with appropriate authorization of management and the board of directors, and (d) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of assets that could have a material effect on the financial statements.

[0001571996-22-000009:item_9a:8]
In connection with the preparation of this report, our management, under the supervision and with the participation of our Chief Executive Officer and Chief Financial Officer, conducted an evaluation of the effectiveness of our internal control over financial reporting as of January 28, 2022, based on the criteria established in Internal Control — Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission.  As a result of that evaluation, management has concluded that our internal control over financial reporting was effective as of January 28, 2022.

[0001571996-22-000009:item_9a:9]
The effectiveness of our internal control over financial reporting as of January 28, 2022 has been audited by PricewaterhouseCoopers LLP, our independent registered public accounting firm, as stated in their report, which is included in “Item 8 — Financial Statements and Supplementary Data.”

[0001571996-22-000009:item_9a:10]
Changes in Internal Control Over Financial Reporting

[0001571996-22-000009:item_9a:11]
There were no changes in our internal control over financial reporting during the fiscal quarter ended January 28, 2022 that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.

[0001571996-22-000009:item_9a:12]
Limitations on the Effectiveness of Controls

[0001571996-22-000009:item_9a:13]
159

[0001571996-22-000009:item_9a:14]
Our system of controls is designed to provide reasonable, not absolute, assurance regarding the reliability and integrity of accounting and financial reporting.  Management does not expect that our disclosure controls and procedures or our internal control over financial reporting will prevent or detect all errors and all fraud.  A control system, no matter how well designed and operated, can provide only reasonable, not absolute, assurance that the objectives of the control system will be met.  These inherent limitations include the following:

[0001571996-22-000009:item_9a:15]
•Judgments in decision-making can be faulty, and control and process breakdowns can occur because of simple errors or mistakes.

[0001571996-22-000009:item_9a:16]
•Controls can be circumvented by individuals, acting alone or in collusion with each other, or by management override.

[0001571996-22-000009:item_9a:17]
•The design of any system of controls is based in part on certain assumptions about the likelihood of future events, and there can be no assurance that any design will succeed in achieving its stated goals under all potential future conditions.

[0001571996-22-000009:item_9a:18]
•Over time, controls may become inadequate because of changes in conditions or deterioration in the degree of compliance with associated policies or procedures.

[0001571996-22-000009:item_9a:19]
•The design of a control system must reflect the fact that resources are constrained, and the benefits of controls must be considered relative to their costs.

[0001571996-22-000009:item_9a:20]
160
