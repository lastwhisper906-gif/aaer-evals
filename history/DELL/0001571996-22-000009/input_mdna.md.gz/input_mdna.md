# DELL MD&A — 0001571996-22-000009


## mdna

[0001571996-22-000009:mdna:1]
ITEM 7 — MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0001571996-22-000009:mdna:2]
This management’s discussion and analysis should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in this Annual Report on Form 10-K.

[0001571996-22-000009:mdna:3]
Unless otherwise indicated, all results presented are prepared in a manner that complies, in all material respects, with accounting principles generally accepted in the United States of America (“GAAP”).  Additionally, unless otherwise indicated, all changes identified for the current-period results represent comparisons to results for the prior corresponding fiscal period.

[0001571996-22-000009:mdna:4]
Unless the context indicates otherwise, references in this report to “we,” “us,” “our,” the “Company,” and “Dell Technologies” mean Dell Technologies Inc. and its consolidated subsidiaries, references to “Dell” mean Dell Inc. and Dell Inc.’s consolidated subsidiaries, references to “EMC” mean EMC Corporation and EMC Corporation’s consolidated subsidiaries, and references to “VMware” refer to VMware, Inc. and VMware, Inc.’s consolidated subsidiaries.

[0001571996-22-000009:mdna:5]
On November 1, 2021, the Company completed its previously announced spin-off of VMware.  In accordance with applicable accounting guidance, the results of VMware, excluding Dell's resale of VMware offerings, are presented as discontinued operations in the Consolidated Statements of Income and, as such, have been excluded from both continuing operations and segment results for all periods presented.  Further, the Company reclassified the assets and liabilities of VMware as assets and liabilities of discontinued operations in the Consolidated Statements of Financial Position as of January 29, 2021.  The Consolidated Statements of Cash Flows are presented on a consolidated basis for both continuing operations and discontinued operations.

[0001571996-22-000009:mdna:6]
Our fiscal year is the 52- or 53-week period ending on the Friday nearest January 31.  We refer to our fiscal years ended January 28, 2022, January 29, 2021, and January 31, 2020 as “Fiscal 2022,” “Fiscal 2021,” and “Fiscal 2020,” respectively.  All fiscal years presented included 52 weeks.

[0001571996-22-000009:mdna:7]
INTRODUCTION

[0001571996-22-000009:mdna:8]
Fiscal 2022 Significant Developments

[0001571996-22-000009:mdna:9]
On November 1, 2021, we completed our previously announced spin-off of VMware by means of a special stock dividend.  The VMware Spin-off was effectuated pursuant to a Separation and Distribution Agreement, dated as of April 14, 2021, between Dell Technologies and VMware.  As part of the transaction, VMware paid a special cash dividend, pro rata, to each holder of VMware common stock in an aggregate amount equal to $11.5 billion, of which Dell Technologies received $9.3 billion.

[0001571996-22-000009:mdna:10]
In connection with and upon completion of the VMware Spin-off, we entered into a Commercial Framework Agreement (the “CFA”) with VMware, which provides the framework under which we and VMware will continue our commercial relationship after the transaction.

[0001571996-22-000009:mdna:11]
On October 1, 2021, we completed the sale of Boomi, Inc. (“Boomi”) and certain related assets and received total cash consideration of approximately $4.0 billion.  The transaction was intended to support our focus on fueling growth initiatives through targeted investments to modernize Dell Technologies’ core infrastructure and through expansion in high-priority areas, including hybrid and private cloud, edge, telecommunications solutions, and our APEX offerings.

[0001571996-22-000009:mdna:12]
With the proceeds from the VMware Spin-off and cash on hand, we were able to make steady progress on paying down our outstanding debt throughout Fiscal 2022.  As a result of our debt reduction and our continued focus on deleveraging, we achieved an investment grade rating from three major credit rating agencies.

[0001571996-22-000009:mdna:13]
36

[0001571996-22-000009:mdna:14]
During Fiscal 2022, the coronavirus disease 2019 (“COVID-19”) pandemic continued to present global challenges that directly impacted Dell Technologies, most notably in relation to supply chain dynamics and the mix of our products and services sold.  As a result of the global economic recovery coupled with industry-wide constraints on the supply of limited-source components, we experienced demand which outpaced supply across many of our product offerings.  Throughout Fiscal 2022, these impacts led to an increase in orders pending fulfillment and extended lead times for our customers for certain offerings as well as increases in component and logistics costs.  We also experienced significant demand growth for our CSG offerings driven by the continuation of the work and learn from home environment.  This led to a shift in the mix of products and services sold towards CSG, which impacted our overall profitability.  In response to these pressures, we took steps to address our customers’ demands while balancing profitability and growth.  We continue to closely monitor the impacts of COVID-19 and keep the health of our employees, customers, business partners, and communities as our primary focus.  Although we continue to experience some uncertainty in the global market as a result of the ongoing COVID-19 pandemic, we see opportunities to create value and grow in Fiscal 2023 in the midst of resilient demand for our IT solutions driven by a technology-enabled world.

[0001571996-22-000009:mdna:15]
See “Recent Transactions” below and Note 3, Note 1, and Note 7 of the Notes to the Consolidated Financial Statements included in this report for additional information regarding the VMware Spin-off, the Boomi divestiture, and our outstanding debt.

[0001571996-22-000009:mdna:16]
Company Overview

[0001571996-22-000009:mdna:17]
Dell Technologies helps organizations build their digital futures and individuals transform how they work, live and play.  We provide customers with one of the industry’s broadest and most innovative solutions portfolio for the data era, including traditional infrastructure and extending to multi-cloud environments.  We continue to seamlessly deliver differentiated and holistic IT solutions to our customers which has helped drive consistent revenue growth.

[0001571996-22-000009:mdna:18]
Dell Technologies’ integrated solutions help customers modernize their IT infrastructure, manage and operate in a multi-cloud world, address workforce transformation, and provide critical solutions that keep people and organizations connected, which has proven even more important through the COVID-19 pandemic.  We are helping customers accelerate their digital transformations to improve and strengthen business and workforce productivity.  With our extensive portfolio and our commitment to innovation, we offer secure, integrated solutions that extend from the edge to the core to the cloud, and we are at the forefront of the software-defined and cloud native infrastructure era.  As further evidence of our commitment to innovation, we are evolving and expanding our IT as-a-Service and cloud offerings including APEX-branded solutions which provide our customers with greater flexibility to scale IT to meet their evolving business needs and budgets.

[0001571996-22-000009:mdna:19]
Dell Technologies’ end-to-end portfolio is supported by a world-class organization that operates globally in approximately 180 countries across key functional areas, including technology and product development, marketing, sales, financial services, and services.  Our go-to-market engine includes a 32,000-person sales force and a global network of over 200,000 channel partners.  Dell Financial Services and its affiliates (“DFS”) offer customers payment flexibility and enables synergies across the business.  DFS funded $8.5 billion of originations in Fiscal 2022 and maintains a $11 billion global portfolio of high-quality financing receivables.  We employ approximately 35,000 full-time service and support professionals and maintain more than 2,400 vendor-managed service centers.  We manage a world-class supply chain that drives long-term growth and operating efficiencies, with approximately $75 billion in annual procurement expenditures and over 750 parts distribution centers.  Together, these elements provide a critical foundation for our success.

[0001571996-22-000009:mdna:20]
Our Vision and Strategy

[0001571996-22-000009:mdna:21]
Our vision is to become the most essential technology company for the data era.  We seek to address our customers’ evolving needs and their broader digital transformation objectives as they embrace today’s hybrid multi-cloud environment.  We intend to execute on our vision by focusing on two overarching strategic priorities:

[0001571996-22-000009:mdna:22]
•Grow and modernize our core offerings in the markets in which we predominantly compete

[0001571996-22-000009:mdna:23]
•Pursue attractive new growth opportunities such as Edge, Telecom, data management, and as-a-Service consumption models

[0001571996-22-000009:mdna:24]
We believe that we are uniquely positioned in the data and multi-cloud era and that our results will benefit from our durable competitive advantages.  We intend to continue to execute our business model to position our company for long-term success while balancing liquidity, profitability, and growth.

[0001571996-22-000009:mdna:25]
We are seeing an accelerated rate of change in the IT industry and increased demand for simpler, more agile IT as companies leverage multiple clouds in their IT environments.  COVID-19 has accelerated the introduction and adoption of new technologies to ensure productivity and collaboration from anywhere.  To meet our customer needs, we continue to invest in research and development, sales, and other key areas of our business to deliver superior products and solutions capabilities and to drive long-term sustainable growth.

[0001571996-22-000009:mdna:26]
Products and Services

[0001571996-22-000009:mdna:27]
We design, develop, manufacture, market, sell, and support a wide range of comprehensive and integrated solutions, products, and services.  We are organized into two business units, referred to as Infrastructure Solutions Group and Client Solutions Group, which are our reportable segments.

[0001571996-22-000009:mdna:28]
•Infrastructure Solutions Group (“ISG”) — ISG enables our customers’ digital transformation through our trusted multi-cloud and big data solutions, which are built upon modern data center infrastructure.  ISG helps customers in the area of hybrid cloud deployment with the goal of simplifying, streamlining, and automating cloud operations.  ISG solutions are built for multi-cloud environments and are optimized to run cloud native workloads in both public and private clouds, as well as traditional on-premise workloads.

[0001571996-22-000009:mdna:29]
Our comprehensive portfolio of advanced storage solutions includes traditional storage solutions as well as next-generation storage solutions (such as all-flash arrays, scale-out file, object platforms, and software-defined solutions).    In May 2020, we released our new PowerStore offering, a differentiated midrange storage solution that enables seamless updates using microservices and container-based software architecture.  This offering allows us to compete more effectively within midrange storage.  We continue to make enhancements to our storage solutions offerings and expect that these offerings will drive long-term improvements in the business.

[0001571996-22-000009:mdna:30]
Our server portfolio includes high-performance rack, blade, tower, and hyperscale servers, optimized to run high value workloads, including artificial intelligence and machine learning.  Our networking portfolio helps our business customers transform and modernize their infrastructure, mobilize and enrich end-user experiences, and accelerate business applications and processes.

[0001571996-22-000009:mdna:31]
Our strengths in server, storage, and virtualization software solutions enable us to offer leading converged and hyper-converged solutions, allowing our customers to accelerate their IT transformation by acquiring scalable integrated IT solutions instead of building and assembling their own IT platforms.  ISG also offers attached software, peripherals and services, including support and deployment, configuration, and extended warranty services.

[0001571996-22-000009:mdna:32]
Approximately half of ISG revenue is generated by sales to customers in the Americas, with the remaining portion derived from sales to customers in the Europe, Middle East, and Africa region (“EMEA”) and the Asia-Pacific and Japan region (“APJ”).

[0001571996-22-000009:mdna:33]
•Client Solutions Group (“CSG”) — CSG includes branded hardware (such as desktops, workstations, and notebooks) and branded peripherals (such as displays and projectors), as well as third-party software and peripherals.  Our computing devices are designed with our commercial and consumer customers’ needs in mind, and we seek to optimize performance, reliability, manageability, design, and security.  For our customers that are seeking to simplify client lifecycle management, Dell PC as a Service offering combines hardware, software, lifecycle services, and financing into one all-encompassing solution that provides predictable pricing per seat per month.  CSG also offers attached software, peripherals, and services, including support and deployment, configuration, and extended warranty services.

[0001571996-22-000009:mdna:34]
Approximately half of CSG revenue is generated by sales to customers in the Americas, with the remaining portion derived from sales to customers in EMEA and APJ.

[0001571996-22-000009:mdna:35]
Our other businesses, described below, consists of our resale of standalone VMware offerings, referred to as VMware Resale, as well as product and service offerings of Secureworks and Virtustream.  These businesses are not classified as reportable segments, either individually or collectively.

[0001571996-22-000009:mdna:36]
•VMware Resale consists of our sale of standalone VMware offerings.  Under the CFA entered into as part of the VMware Spin-off, Dell Technologies continues to act as a key channel partner in this relationship, reselling VMware offerings to our customers.  This partnership is intended to facilitate mutually beneficial growth for both Dell and VMware.

[0001571996-22-000009:mdna:37]
VMware works with customers in the areas of hybrid and multi-cloud, modern applications, networking, security, and digital workspaces, helping customers manage their IT resources across private clouds and complex multi-cloud, multi-device environments.

[0001571996-22-000009:mdna:38]
•Secureworks (NASDAQ: SCWX) is a leading global provider of intelligence-driven information security solutions singularly focused on protecting its clients from cyber attacks.  The solutions offered by Secureworks enable organizations of varying size and complexity to fortify their cyber defenses to prevent security breaches, detect malicious activity in near real time, prioritize and respond rapidly to security incidents and predict emerging threats.

[0001571996-22-000009:mdna:39]
•Virtustream offers cloud software and Infrastructure-as-a-Service solutions that enable customers to migrate, run, and manage mission-critical applications in cloud-based IT environments.

[0001571996-22-000009:mdna:40]
We believe the collaboration, innovation, and coordination of the operations and strategies across all segments of our business, as well as our differentiated go-to-market model, will continue to drive revenue synergies.  Through our research and development activities, we are able to engineer leading innovative solutions that incorporate the distinct set of hardware, software, and services across all segments of our business.

[0001571996-22-000009:mdna:41]
Our products and services offerings are continually evolving in response to industry dynamics.  As a result, reclassifications of certain products and services solutions in major product categories may be required.  For further discussion regarding our current reportable segments, see “Results of Operations — Business Unit Results” and Note 19 of the Notes to the Consolidated Financial Statements included in this report.

[0001571996-22-000009:mdna:42]
Dell Financial Services

[0001571996-22-000009:mdna:43]
DFS supports our businesses by offering and arranging various financing options and services for our customers globally.  DFS originates, collects, and services customer receivables primarily related to the purchase or use of our product, software, and services solutions.  We also arrange financing for some of our customers in various countries where DFS does not currently operate as a captive entity.  DFS further strengthens our customer relationships through its flexible consumption models which provide our customers with financial flexibility to meet their changing technological requirements.  Our flexible consumption models enable us to offer our customers the option to pay over time and, in certain cases, based on utilization.  The results of these operations are allocated to our segments based on the underlying product or service financed.  For additional information about our financing arrangements, see Note 5 of the Notes to the Consolidated Financial Statements included in this report.

[0001571996-22-000009:mdna:44]
Recent Transactions

[0001571996-22-000009:mdna:45]
Spin-Off of VMware — As described in Note 1 and Note 3 of the Notes to the Consolidated Financial Statements included in this report, on November 1, 2021, the Company completed its previously announced VMware Spin-off.

[0001571996-22-000009:mdna:46]
Dell Technologies effectuated the VMware Spin-off by means of a special stock dividend of 30,678,605 shares of Class A common stock and 307,221,836 of Class B common stock of VMware to Dell Technologies stockholders of record on October 29, 2021.  Prior to receipt of the VMware common stock by the Company’s stockholders, each share of VMware Class B common stock automatically converted into one share of VMware Class A common stock.  As a result of these transactions, each holder of record of shares of Dell Technologies common stock as of the distribution record date received approximately 0.440626 of a share of VMware Class A common stock for each outstanding share of Dell Technologies common stock owned by such holder as of such date.  VMware paid a special cash dividend, pro rata, to each holder of VMware common stock in an aggregate amount equal to $11.5 billion, of which Dell Technologies received $9.3 billion.

[0001571996-22-000009:mdna:47]
39

[0001571996-22-000009:mdna:48]
Immediately following VMware’s payment of the special cash dividend, pursuant to the Separation and Distribution Agreement, the businesses of VMware were separated from the remaining businesses of Dell Technologies through a series of transactions that resulted in the pre-transaction stockholders of Dell Technologies owning shares in two separate public companies, consisting of (1) VMware, which continues to own the businesses of VMware, Inc. and its subsidiaries, and (2) Dell Technologies, which continues to own Dell Technologies’ other businesses and subsidiaries.  In connection with and upon completion of the VMware Spin-off, Dell Technologies and VMware entered into a Commercial Framework Agreement.  The CFA provides a framework under which Dell Technologies and VMware will continue their commercial relationship after the transaction.  The CFA has an initial term of five years, with automatic one-year renewals occurring annually thereafter, subject to certain terms and conditions.  Dell Technologies and VMware also entered into other agreements that will govern other aspects of their relationship, including, among others, a tax matters agreement and a transition services agreement.

[0001571996-22-000009:mdna:49]
Pursuant to the CFA, Dell Technologies will continue to act as a distributor of VMware’s standalone products and services and purchase such products and services for resale to end-user customers.  Dell Technologies will also continue to integrate VMware’s products and services with Dell Technologies’ offerings and sell them to end users.  The results of these transactions are classified as continuing operations within the Company’s Consolidated Statements of Income for all periods presented.  See Note 3 of the Notes to the Consolidated Financial Statements for additional information on the VMware Spin-off.

[0001571996-22-000009:mdna:50]
The operating results of VMware, excluding Dell's resale of VMware offerings, are presented as discontinued operations in our Consolidated Statements of Income and as such, have been excluded from both continuing operations and segment results for all periods presented, except as otherwise indicated.  Further, the Company reclassified the related assets and liabilities of VMware as assets and liabilities of discontinued operations in the Consolidated Statements of Financial Position as of January 29, 2021.  The Consolidated Statements of Cash Flows are presented on a consolidated basis for both continuing operations and discontinued operations.  See Note 3 of the Notes to the Consolidated Financial Statements included in this report for more information related to the discontinued operations.

[0001571996-22-000009:mdna:51]
Boomi Divestiture — On October 1, 2021, we completed the sale of Boomi and certain related assets for a total cash consideration of approximately $4.0 billion, resulting in a pre-tax gain on sale of $4.0 billion.  The Company ultimately recorded a $3.0 billion gain, net of $1.0 billion in tax expense.

[0001571996-22-000009:mdna:52]
RSA Divestiture — On September 1, 2020, we completed the sale of RSA Security LLC (“RSA Security”) for total cash consideration of approximately $2.082 billion, resulting in a pre-tax gain on sale of $338 million.  The Company ultimately recorded a $21 million loss net of taxes.  The transaction was intended to further simplify our product portfolio and corporate structure.

[0001571996-22-000009:mdna:53]
Prior to the divestitures, the operating results of Boomi and RSA Security were included within other businesses and did not qualify for presentation as discontinued operations.  See Note 1 of the Notes to the Consolidated Financial Statements included in this report for more information about these transactions.

[0001571996-22-000009:mdna:54]
Relationship with VMware

[0001571996-22-000009:mdna:55]
Effective upon the completion of the VMware Spin-off, VMware is considered to be a related party of the Company.  The related party relationship is as a result of Michael Dell’s ownership interest of both Dell Technologies and VMware and Michael Dell’s continued positions as Chairman and Chief Executive Officer of Dell Technologies, and Chairman of the Board of VMware.  Following the completion of the VMware Spin-off, the majority of transactions that occur between Dell Technologies and VMware consist of Dell Technologies’ purchase of VMware products and services for resale, either on a standalone basis or as a part of integrated offerings.  For more information regarding related party transactions with VMware, see Note 21 of the Notes to the Consolidated Financial Statements included in this report.

[0001571996-22-000009:mdna:56]
Strategic Investments and Acquisitions

[0001571996-22-000009:mdna:57]
As part of our strategy, we will continue to evaluate opportunities for strategic investments through our venture capital investment arm, Dell Technologies Capital, with a focus on emerging technology areas that are relevant to all segments of our business and that will complement our existing portfolio of solutions.  Our investment areas include storage, software-defined networking, management and orchestration, security, machine learning and artificial intelligence, Big Data and analytics, cloud, edge computing, and software development operations.  As of January 28, 2022 and January 29, 2021, Dell Technologies held strategic investments in non-marketable securities of $1.4 billion and $0.9 billion, respectively.

[0001571996-22-000009:mdna:58]
In addition to these investments, we also may make disciplined acquisitions targeting businesses that advance our strategic objectives and accelerate our innovation agenda.

[0001571996-22-000009:mdna:59]
Business Trends and Challenges

[0001571996-22-000009:mdna:60]
Ukraine — We are monitoring and responding to the escalating conflict in Ukraine and the associated sanctions and other restrictions.  As of the date of this report, as a result of the conflict, we are not selling, servicing or supporting products in Russia, Belarus, and the Donetsk and Luhansk regions of Ukraine.  The full impact of the conflict on our business operations and financial performance remains uncertain and will depend on future developments, including the severity and duration of the conflict and its impact on regional and global economic conditions.  We will continue to monitor the conflict and assess the related restrictions and other effects and pursue prudent decisions for our team members, customers, and business.

[0001571996-22-000009:mdna:61]
COVID-19 Pandemic and Response — We continue to monitor the COVID-19 pandemic and variants of the virus, as well as the impact it has on our employees, customers, business partners, and communities.  Our crisis management team is actively engaged in evaluating changes in our environment and aligning our response to recommendations of the World Health Organization and the U.S. Centers for Disease Control and Prevention, and with governmental regulations.  We are deploying return-to-site processes in certain regions based on our ongoing assessments of local conditions.  We will continue to monitor regional conditions and utilize remote work practices to ensure the health and safety of our employees, customers, and business partners.

[0001571996-22-000009:mdna:62]
The full impact of the COVID-19 pandemic on our business operations and financial performance remains uncertain and will depend on future developments, including, the severity, duration and scope of the pandemic across different geographies; the effectiveness of actions taken to contain, mitigate or prevent the spread of variants of the virus; the further development, availability, and acceptance of effective treatments or vaccines; and governmental, business and individuals’ actions that have been and continue to be taken in response to the pandemic.  We will continue to actively monitor global events and pursue prudent decisions to navigate in this uncertain and ever-changing environment.  For additional information about impacts of COVID-19 on our operations, see “Results of Operations—Consolidated Results” and “—Business Unit Results.”

[0001571996-22-000009:mdna:63]
Supply Chain — Dell Technologies maintains limited-source supplier relationships for certain components, because the relationships are advantageous in the areas of performance, quality, support, delivery, capacity, and price considerations.

[0001571996-22-000009:mdna:64]
During Fiscal 2022, we were impacted by industry-wide constraints in the supply of limited-source components in certain product offerings as a result of the global impacts of COVID-19.  Further, global economic recovery led to growth in demand that outpaced supply, resulting in an increase in orders pending fulfillment and extended lead times for our customers for certain products.  These supply constraints coupled with increasing demand also led to increases in component and logistics costs, both of which increased in the aggregate during Fiscal 2022.  Logistics costs increased as a result of both expedited shipments of components and rate increases in the freight network as capacity remained constrained.  In response to these pressures, we continue to take steps to actively address our customers’ demands while balancing profitability and growth.

[0001571996-22-000009:mdna:65]
We expect to continue to manage supply constraints and increased freight costs into the first half of Fiscal 2023.  Component cost trends are dependent on the strength or weakness of actual end user demand and supply dynamics, which will continue to evolve and ultimately impact the translation of the cost environment to pricing and operating results.  We expect the overall component cost environment to shift to deflationary during the first half of Fiscal 2023.

[0001571996-22-000009:mdna:66]
ISG — We expect that ISG will continue to be impacted by the changing nature of the IT infrastructure market and competitive environment.  During Fiscal 2022, ISG demand benefited from improvements in the macroeconomic environment which we expect to continue into Fiscal 2023.  We expect that demand growth will continue to benefit net revenue in future periods.  With our scale and strong solutions portfolio, we believe we are well-positioned to respond to ongoing competitive dynamics.  Within servers and networking, we will continue to be selective in determining whether to pursue certain large hyperscale and other server transactions.  We continue to focus on customer base expansion and lifetime value of customer relationships.

[0001571996-22-000009:mdna:67]
The unprecedented growth throughout all industries is generating continued demand for our storage solutions and services.  Cloud native applications are expected to continue as a primary growth driver in the infrastructure market.  We believe the complementary cloud solutions across our business position us to meet these demands for our customers.  We benefit from offering solutions that address the emerging trends of enterprises deploying software-defined storage, hyper-converged infrastructure, and modular solutions based on server-centric architectures.  These trends are changing the way customers are consuming our traditional storage offerings.  We continue to expand our offerings in external storage arrays, which incorporate flexible, cloud-based functionality.

[0001571996-22-000009:mdna:68]
Through our research and development efforts, we are developing new solutions in this rapidly changing industry that we believe will enable us to continue to provide superior solutions to our customers.  Our customer base includes a growing number of service providers, such as cloud service providers, Software-as-a-Service companies, consumer webtech providers, and telecommunications companies.  These service providers turn to Dell Technologies for our advanced solutions that enable efficient service delivery at cloud scale.  Through our collaborative, customer-focused approach to innovation, we strive to deliver new and relevant solutions and software to the market quickly and efficiently.

[0001571996-22-000009:mdna:69]
CSG — Our CSG offerings are an important element of our strategy, generating strong cash flow and opportunities for cross-selling of complementary solutions.  During Fiscal 2022, CSG demand was strong across product offerings, driven primarily by the global economic recovery coupled with customers seeking improved connectivity and productivity in both personal and professional environments.

[0001571996-22-000009:mdna:70]
During Fiscal 2023, we expect demand growth to be at a more moderate rate than in Fiscal 2022.  Further, we expect that the CSG demand environment will continue to be subject to seasonal trends.  Competitive dynamics continue to be a factor in our CSG business and will impact pricing and operating results.  We remain committed to our long-term strategy for CSG and we will continue to make investments to innovate across the portfolio while benefiting from consolidation trends that are occurring in the markets in which we compete.

[0001571996-22-000009:mdna:71]
Recurring Revenue and Consumption Models — Our customers are seeking new and innovative models that address how they consume our solutions.  We offer options including as-a-Service, utility, leases, and immediate pay models, designed to match customers’ consumption and financing preferences.  We continue to evolve and build momentum across our family of as-a-Service offerings as we pursue our strategy of modernizing our core business solutions, with APEX at the forefront.  We expect that our flexible consumption models and as-a-Service offerings will further strengthen our customer relationships and provide a foundation for growth in recurring revenue.

[0001571996-22-000009:mdna:72]
These offerings typically result in multiyear agreements which generate recurring revenue streams over the term of the arrangement.  We define recurring revenue as revenue recognized primarily related to hardware and software maintenance as well as subscription, as-a-Service, and usage-based offerings, and operating leases.

[0001571996-22-000009:mdna:73]
Macroeconomic Risks and Uncertainties — The impacts of trade protection measures, including increases in tariffs and trade barriers, changes in government policies and international trade arrangements, and geopolitical issues may affect our ability to conduct business in some non-U.S. markets.  We monitor and seek to mitigate these risks with adjustments to our manufacturing, supply chain, and distribution networks.

[0001571996-22-000009:mdna:74]
We manage our business on a U.S. dollar basis.  However, we have a large global presence, generating approximately half of our net revenue from sales to customers outside of the United States during Fiscal 2022, Fiscal 2021, and Fiscal 2020.  As a result, our revenue can be impacted by fluctuations in foreign currency exchange rates.  We utilize a comprehensive hedging strategy intended to mitigate the impact of foreign currency volatility over time, and we adjust pricing when possible to further minimize foreign currency impacts.

[0001571996-22-000009:mdna:75]
42

[0001571996-22-000009:mdna:76]
Key Performance Metrics

[0001571996-22-000009:mdna:77]
Our key performance metrics include net revenue, operating income, adjusted EBITDA, and cash flows from operations, which are discussed elsewhere in this management’s discussion and analysis.

[0001571996-22-000009:mdna:78]
43

[0001571996-22-000009:mdna:79]
NON-GAAP FINANCIAL MEASURES

[0001571996-22-000009:mdna:80]
In this management’s discussion and analysis, we use supplemental measures of our performance which are derived from our consolidated financial information but which are not presented in our consolidated financial statements prepared in accordance with GAAP.  These non-GAAP financial measures include non-GAAP product net revenue; non-GAAP services net revenue; non-GAAP net revenue; non-GAAP product gross margin; non-GAAP services gross margin; non-GAAP gross margin; non-GAAP operating expenses; non-GAAP operating income; non-GAAP net income; earnings before interest and other, net, taxes, depreciation, and amortization (“EBITDA”); and adjusted EBITDA.  The non-GAAP financial measures are not meant to be considered as indicators of performance in isolation from or as a substitute for net revenue, gross margin, operating expenses, operating income, or net income from continuing operations prepared in accordance with GAAP, and should be read only in conjunction with financial information presented on a GAAP basis.

[0001571996-22-000009:mdna:81]
We use non-GAAP financial measures to supplement financial information presented on a GAAP basis.  Management considers these non-GAAP measures in evaluating our operating trends and performance.  Moreover, we believe these non-GAAP financial measures provide our stakeholders with useful and transparent information to help them evaluate our operating results by facilitating an enhanced understanding of our operating performance and enabling them to make more meaningful period to period comparisons.  There are limitations to the use of the non-GAAP financial measures presented in this report.  Our non-GAAP financial measures may not be comparable to similarly titled measures of other companies.  Other companies, including companies in our industry, may calculate non-GAAP financial measures differently than we do, limiting the usefulness of those measures for comparative purposes.

[0001571996-22-000009:mdna:82]
Non-GAAP product net revenue, non-GAAP services net revenue, non-GAAP net revenue, non-GAAP product gross margin, non-GAAP services gross margin, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, and non-GAAP net income, as defined by us, exclude amortization of intangible assets, the impact of purchase accounting, transaction-related expenses, stock-based compensation expense, other corporate expenses and, for non-GAAP net income, fair value adjustments on equity adjustments and an aggregate adjustment for income taxes.  As the excluded items have a material impact on our financial results, our management compensates for this limitation by relying primarily on our GAAP results and using non-GAAP financial measures supplementally or for projections when comparable GAAP financial measures are not available.

[0001571996-22-000009:mdna:83]
Reconciliations of each non-GAAP financial measure to its most directly comparable GAAP financial measure are presented below.  We encourage you to review the reconciliations in conjunction with the presentation of the non-GAAP financial measures for each of the periods presented.  The discussion below includes information on each of the excluded items as well as our reasons for excluding them from our non-GAAP results.  In future fiscal periods, we may exclude such items and may incur income and expenses similar to these excluded items.  Accordingly, the exclusion of these items and other similar items in our non-GAAP presentation should not be interpreted as implying that these items are non-recurring, infrequent, or unusual.

[0001571996-22-000009:mdna:84]
The following is a summary of the items excluded from the most comparable GAAP financial measures to calculate our non-GAAP financial measures:

[0001571996-22-000009:mdna:85]
•Amortization of Intangible Assets — Amortization of intangible assets primarily consists of amortization of customer relationships, developed technology, and trade names.  In connection with our acquisition by merger of EMC on September 7, 2016, referred to as the “EMC merger transaction,” and the acquisition of Dell Inc. by Dell Technologies Inc. on October 29, 2013, referred to as the “going-private transaction,” all of the tangible and intangible assets and liabilities of EMC and Dell, Inc. and its consolidated subsidiaries, respectively, were accounted for and recognized at fair value on the transaction dates.  Accordingly, for the periods presented, amortization of intangible assets represents amortization associated with intangible assets recognized in connection with the EMC merger transaction and the going-private transaction.  Amortization charges for purchased intangible assets are significantly impacted by the timing and magnitude of our acquisitions, and these charges may vary in amount from period to period.  We exclude these charges for purposes of calculating the non-GAAP financial measures presented below to facilitate an enhanced understanding of our current operating performance and provide more meaningful period to period comparisons.

[0001571996-22-000009:mdna:86]
•Impact of Purchase Accounting — The impact of purchase accounting includes purchase accounting adjustments related to the EMC merger transaction and, to a lesser extent, the going-private transaction, recorded under the acquisition method of accounting in accordance with the accounting guidance for business combinations.  This guidance prescribes that the purchase price be allocated to assets acquired and liabilities assumed based on the estimated fair value of such assets and liabilities on the date of the transaction.  Accordingly, all of the assets and liabilities acquired in the EMC merger transaction and the going-private transaction were accounted for and recognized at fair value as of the respective transaction dates, and the fair value adjustments are being amortized over the estimated useful lives in the periods following the transactions.  The fair value adjustments primarily relate to deferred revenue, inventory, and property, plant, and equipment.  Although purchase accounting adjustments and related amortization of those adjustments are reflected in our GAAP results, we evaluate the operating results of the underlying businesses on a non-GAAP basis, after removing such adjustments.  We believe that excluding the impact of purchase accounting for purposes of calculating the non-GAAP financial measures presented below facilitates an enhanced understanding of our current operating performance and provides more meaningful period to period comparisons.

[0001571996-22-000009:mdna:87]
•Transaction-related (income) expenses — Transaction-related expenses typically consist of acquisition, integration, and divestiture related costs, as well as the costs incurred in the VMware Spin-off, and are expensed as incurred.  These expenses primarily represent costs for legal, banking, consulting, and advisory services.  During Fiscal 2022, this category includes $1.5 billion in debt extinguishment fees primarily associated with the early retirement of certain senior notes.  See Note 7 of the Notes to the Consolidated Financial Statements included in this report for additional information on our debt activity.  From time to time, this category also may include transaction-related income related to divestitures of businesses or asset sales.  During Fiscal 2022, we recognized a pre-tax gain of $4.0 billion on the sale of Boomi and during Fiscal 2021 we recognized a pre-tax gain of $338 million on the sale of RSA Security.  We exclude these items for purposes of calculating the non-GAAP financial measures presented below to facilitate an enhanced understanding of our current operating performance and provide more meaningful period to period comparisons.

[0001571996-22-000009:mdna:88]
•Stock-based Compensation Expense — Stock-based compensation expense consists of equity awards granted based on the estimated fair value of those awards at grant date.  We estimate the fair value of service-based stock options using the Black-Scholes valuation model.  To estimate the fair value of performance-based awards containing a market condition, we use the Monte Carlo valuation model.  For all other share-based awards, the fair value is based on the closing price of the Class C Common Stock as reported on the NYSE on the date of grant.  Although stock-based compensation is an important aspect of the compensation of our employees and executives, the fair value of the stock-based awards may bear little resemblance to the actual value realized upon the vesting or future exercise of the related stock-based awards.  We believe that excluding stock-based compensation expense for purposes of calculating the non-GAAP financial measures presented below facilitates an enhanced understanding of our current operating performance and provides more meaningful period to period comparisons.  See Note 16 of the Notes to the Consolidated Financial Statements included in this report for additional information on equity award issuances.

[0001571996-22-000009:mdna:89]
•Other Corporate Expenses — Other corporate expenses consist of impairment charges, incentive charges related to equity investments, severance, facility action, and other costs.  Virtustream non-cash pre-tax asset impairment charges of $619 million were recognized in Fiscal 2020.  Severance costs are primarily related to severance and benefits for employees terminated pursuant to cost savings initiatives.  We continue to optimize our facilities footprint and may incur additional costs as we seek opportunities for operational efficiencies.  Other corporate expenses vary from period to period and are significantly impacted by the timing and nature of these events.  Therefore, although we may incur these types of expenses in the future, we believe that eliminating these charges for purposes of calculating the non-GAAP financial measures presented below facilitates an enhanced understanding of our current operating performance and provides more meaningful period to period comparisons.

[0001571996-22-000009:mdna:90]
•Fair Value Adjustments on Equity Investments — Fair value adjustments on equity investments primarily consist of the gain (loss) on strategic investments, which includes the recurring fair value adjustments of investments in publicly-traded companies, as well as those in privately-held companies, which are adjusted for observable price changes, and, to a lesser extent, any potential impairments.  See Note 4 of the Notes to the Consolidated Financial Statements included in this report for additional information on our strategic investment activity.  Given the volatility in the ongoing adjustments to the valuation of these strategic investments, we believe that excluding these gains and losses for purposes of calculating non-GAAP net income presented below facilitates an enhanced understanding of our current operating performance and provides more meaningful period to period comparisons.

[0001571996-22-000009:mdna:91]
45

[0001571996-22-000009:mdna:92]
•Aggregate Adjustment for Income Taxes — The aggregate adjustment for income taxes is the estimated combined income tax effect for the adjustments described above, as well as an adjustment for discrete tax items.  Due to the variability in recognition of discrete tax items from period to period, we believe that excluding these benefits or charges for purposes of calculating non-GAAP net income facilitates an enhanced understanding of our current operating performance and provides more meaningful period to period comparisons.  The tax effects are determined based on the tax jurisdictions where the above items were incurred.  See Note 12 of the Notes to the Consolidated Financial Statements included in this report for additional information on our income taxes.

[0001571996-22-000009:mdna:93]
The following table presents a reconciliation of each non-GAAP financial measure to the most directly comparable GAAP measure for the periods indicated:

[0001571996-22-000009:mdna:94]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  |  |  | January 28,2022 |  | % Change |  | January 29,2021 |  | % Change |  | January 31,2020 |
|  |  |  |  |  |  |  | (in millions, except percentages) |
| Product net revenue |  |  |  |  |  |  | $ | 79,830 |  |  | 18 | % |  | $ | 67,744 |  |  | — | % |  | $ | 67,607 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting |  |  |  |  |  |  | — |  |  |  |  | 2 |  |  |  |  | 5 |  |
| Non-GAAP product net revenue |  |  |  |  |  |  | $ | 79,830 |  |  | 18 | % |  | $ | 67,746 |  |  | — | % |  | $ | 67,612 |  |
| Services net revenue |  |  |  |  |  |  | $ | 21,367 |  |  | 13 | % |  | $ | 18,926 |  |  | 10 | % |  | $ | 17,208 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting |  |  |  |  |  |  | 32 |  |  |  |  | 104 |  |  |  |  | 224 |  |
| Non-GAAP services net revenue |  |  |  |  |  |  | $ | 21,399 |  |  | 12 | % |  | $ | 19,030 |  |  | 9 | % |  | $ | 17,432 |  |
| Net revenue |  |  |  |  |  |  | $ | 101,197 |  |  | 17 | % |  | $ | 86,670 |  |  | 2 | % |  | $ | 84,815 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting |  |  |  |  |  |  | 32 |  |  |  |  | 106 |  |  |  |  | 229 |  |
| Non-GAAP net revenue |  |  |  |  |  |  | $ | 101,229 |  |  | 17 | % |  | $ | 86,776 |  |  | 2 | % |  | $ | 85,044 |  |
| Product gross margin |  |  |  |  |  |  | $ | 12,606 |  |  | 11 | % |  | $ | 11,313 |  |  | (8) | % |  | $ | 12,238 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles |  |  |  |  |  |  | 598 |  |  |  |  | 853 |  |  |  |  | 1,268 |  |
| Impact of purchase accounting |  |  |  |  |  |  | 3 |  |  |  |  | 5 |  |  |  |  | 11 |  |
| Transaction-related (income) expenses |  |  |  |  |  |  | — |  |  |  |  | — |  |  |  |  | (2) |  |
| Stock-based compensation expense |  |  |  |  |  |  | 48 |  |  |  |  | 23 |  |  |  |  | 9 |  |
| Other corporate expenses |  |  |  |  |  |  | 6 |  |  |  |  | 17 |  |  |  |  | 16 |  |
| Non-GAAP product gross margin |  |  |  |  |  |  | $ | 13,261 |  |  | 9 | % |  | $ | 12,211 |  |  | (10) | % |  | $ | 13,540 |  |
| Services gross margin |  |  |  |  |  |  | $ | 9,285 |  |  | 5 | % |  | $ | 8,827 |  |  | 5 | % |  | $ | 8,401 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting |  |  |  |  |  |  | 32 |  |  |  |  | 104 |  |  |  |  | 220 |  |
| Transaction-related expenses |  |  |  |  |  |  | — |  |  |  |  | — |  |  |  |  | 2 |  |
| Stock-based compensation expense |  |  |  |  |  |  | 85 |  |  |  |  | 52 |  |  |  |  | 23 |  |
| Other corporate expenses |  |  |  |  |  |  | 21 |  |  |  |  | 39 |  |  |  |  | 43 |  |
| Non-GAAP services gross margin |  |  |  |  |  |  | $ | 9,423 |  |  | 4 | % |  | $ | 9,022 |  |  | 4 | % |  | $ | 8,689 |  |

[0001571996-22-000009:mdna:95]
47

[0001571996-22-000009:mdna:96]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  |  |  | January 28,2022 |  | % Change |  | January 29,2021 |  | % Change |  | January 31,2020 |
|  |  |  |  |  |  |  | (in millions, except percentages) |
| Gross margin |  |  |  |  |  |  | $ | 21,891 |  |  | 9 | % |  | $ | 20,140 |  |  | (2) | % |  | $ | 20,639 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles |  |  |  |  |  |  | 598 |  |  |  |  | 853 |  |  |  |  | 1,268 |  |
| Impact of purchase accounting |  |  |  |  |  |  | 35 |  |  |  |  | 109 |  |  |  |  | 231 |  |
| Stock-based compensation expense |  |  |  |  |  |  | 133 |  |  |  |  | 75 |  |  |  |  | 32 |  |
| Other corporate expenses |  |  |  |  |  |  | 27 |  |  |  |  | 56 |  |  |  |  | 59 |  |
| Non-GAAP gross margin |  |  |  |  |  |  | $ | 22,684 |  |  | 7 | % |  | $ | 21,233 |  |  | (4) | % |  | $ | 22,229 |  |
| Operating expenses |  |  |  |  |  |  | $ | 17,232 |  |  | 5 | % |  | $ | 16,455 |  |  | (10) | % |  | $ | 18,273 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles |  |  |  |  |  |  | (1,043) |  |  |  |  | (1,280) |  |  |  |  | (1,703) |  |
| Impact of purchase accounting |  |  |  |  |  |  | (32) |  |  |  |  | (35) |  |  |  |  | (43) |  |
| Transaction-related expenses |  |  |  |  |  |  | (273) |  |  |  |  | (124) |  |  |  |  | (116) |  |
| Stock-based compensation expense |  |  |  |  |  |  | (675) |  |  |  |  | (412) |  |  |  |  | (213) |  |
| Other corporate expenses |  |  |  |  |  |  | (310) |  |  |  |  | (320) |  |  |  |  | (785) |  |
| Non-GAAP operating expenses |  |  |  |  |  |  | $ | 14,899 |  |  | 4 | % |  | $ | 14,284 |  |  | (7) | % |  | $ | 15,413 |  |
| Operating income |  |  |  |  |  |  | $ | 4,659 |  |  | 26 | % |  | $ | 3,685 |  |  | 56 | % |  | $ | 2,366 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles |  |  |  |  |  |  | 1,641 |  |  |  |  | 2,133 |  |  |  |  | 2,971 |  |
| Impact of purchase accounting |  |  |  |  |  |  | 67 |  |  |  |  | 144 |  |  |  |  | 274 |  |
| Transaction-related expenses |  |  |  |  |  |  | 273 |  |  |  |  | 124 |  |  |  |  | 116 |  |
| Stock-based compensation expense |  |  |  |  |  |  | 808 |  |  |  |  | 487 |  |  |  |  | 245 |  |
| Other corporate expenses |  |  |  |  |  |  | 337 |  |  |  |  | 376 |  |  |  |  | 844 |  |
| Non-GAAP operating income |  |  |  |  |  |  | $ | 7,785 |  |  | 12 | % |  | $ | 6,949 |  |  | 2 | % |  | $ | 6,816 |  |
| Net income from continuing operations |  |  |  |  |  |  | $ | 4,942 |  |  | 120 | % |  | $ | 2,245 |  |  | 331 | % |  | $ | 521 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles |  |  |  |  |  |  | 1,641 |  |  |  |  | 2,133 |  |  |  |  | 2,971 |  |
| Impact of purchase accounting |  |  |  |  |  |  | 67 |  |  |  |  | 144 |  |  |  |  | 274 |  |
| Transaction-related (income) expenses |  |  |  |  |  |  | (2,143) |  |  |  |  | (332) |  |  |  |  | 116 |  |
| Stock-based compensation expense |  |  |  |  |  |  | 808 |  |  |  |  | 487 |  |  |  |  | 245 |  |
| Other corporate expenses |  |  |  |  |  |  | 337 |  |  |  |  | 268 |  |  |  |  | 844 |  |
| Fair value adjustments on equity investments |  |  |  |  |  |  | (572) |  |  |  |  | (427) |  |  |  |  | (159) |  |
| Aggregate adjustment for income taxes |  |  |  |  |  |  | (156) |  |  |  |  | (772) |  |  |  |  | (1,361) |  |
| Non-GAAP net income |  |  |  |  |  |  | $ | 4,924 |  |  | 31 | % |  | $ | 3,746 |  |  | 9 | % |  | $ | 3,451 |  |

[0001571996-22-000009:mdna:97]
48

[0001571996-22-000009:mdna:98]
In addition to the above measures, we also use EBITDA and adjusted EBITDA to provide additional information for evaluation of our operating performance.  Adjusted EBITDA excludes purchase accounting adjustments related to the EMC merger transaction and the going-private transaction, acquisition, integration, and divestiture related costs, impairment charges, and severance, facility action, and other costs, and stock-based compensation expense.  We believe that, due to the non-operational nature of the purchase accounting entries, it is appropriate to exclude these adjustments.

[0001571996-22-000009:mdna:99]
As is the case with the non-GAAP measures presented above, users should consider the limitations of using EBITDA and adjusted EBITDA, including the fact that those measures do not provide a complete measure of our operating performance.  EBITDA and adjusted EBITDA do not purport to be alternatives to net income (loss) as measures of operating performance or to cash flows from operating activities as a measure of liquidity.  In particular, EBITDA and adjusted EBITDA are not intended to be a measure of free cash flow available for management’s discretionary use, as these measures do not consider certain cash requirements, such as working capital needs, capital expenditures, contractual commitments, interest payments, tax payments, and other debt service requirements.

[0001571996-22-000009:mdna:100]
The following table presents a reconciliation of EBITDA and adjusted EBITDA to net income (loss) for the periods indicated:

[0001571996-22-000009:mdna:101]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  |  |  | January 28,2022 |  | % Change |  | January 29,2021 |  | % Change |  | January 31,2020 |
|  |  |  |  |  |  |  | (in millions, except percentages) |
| Net income from continuing operations |  |  |  |  |  |  | $ | 4,942 |  |  | 120 | % |  | $ | 2,245 |  |  | 331 | % |  | $ | 521 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest and other, net (a) |  |  |  |  |  |  | (1,264) |  |  |  |  | 1,339 |  |  |  |  | 2,417 |  |
| Income tax expense (benefit) (b) |  |  |  |  |  |  | 981 |  |  |  |  | 101 |  |  |  |  | (572) |  |
| Depreciation and amortization |  |  |  |  |  |  | 3,547 |  |  |  |  | 3,867 |  |  |  |  | 4,458 |  |
| EBITDA |  |  |  |  |  |  | $ | 8,206 |  |  | 9 | % |  | $ | 7,552 |  |  | 11 | % |  | $ | 6,824 |  |
| EBITDA |  |  |  |  |  |  | $ | 8,206 |  |  | 9 | % |  | $ | 7,552 |  |  | 11 | % |  | $ | 6,824 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense |  |  |  |  |  |  | 808 |  |  |  |  | 487 |  |  |  |  | 245 |  |
| Impact of purchase accounting (c) |  |  |  |  |  |  | 36 |  |  |  |  | 106 |  |  |  |  | 229 |  |
| Transaction-related expenses (d) |  |  |  |  |  |  | 273 |  |  |  |  | 124 |  |  |  |  | 116 |  |
| Other corporate expenses (e) |  |  |  |  |  |  | 337 |  |  |  |  | 376 |  |  |  |  | 812 |  |
| Adjusted EBITDA |  |  |  |  |  |  | $ | 9,660 |  |  | 12 | % |  | $ | 8,645 |  |  | 5 | % |  | $ | 8,226 |  |

[0001571996-22-000009:mdna:102]
____________________

[0001571996-22-000009:mdna:103]
(a)See “Results of Operations — Interest and Other, Net” for more information on the components of interest and other, net.

[0001571996-22-000009:mdna:104]
(b)See Note 12 of the Notes to the Consolidated Financial Statements included in this report for additional information on discrete tax items.

[0001571996-22-000009:mdna:105]
(c)This amount includes the non-cash purchase accounting adjustments related to the EMC merger transaction and the going-private transaction.

[0001571996-22-000009:mdna:106]
(d)Transaction-related expenses consist of acquisition, integration, and divestiture related costs, as well as the costs incurred in the VMware Spin-off.

[0001571996-22-000009:mdna:107]
(e)Other corporate expenses includes impairment charges, incentive charges related to equity investments, severance, facility action, and other costs.  For the fiscal year ended January 31, 2020, this category includes Virtustream pre-tax impairment charges of $619 million.

[0001571996-22-000009:mdna:108]
RESULTS OF OPERATIONS

[0001571996-22-000009:mdna:109]
Consolidated Results

[0001571996-22-000009:mdna:110]
The following table summarizes our consolidated results for the periods indicated.  Unless otherwise indicated, all changes identified for the current period results represent comparisons to results for the prior corresponding fiscal period.

[0001571996-22-000009:mdna:111]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  |  |  | January 28, 2022 |  |  |  | January 29, 2021 |  |  |  | January 31, 2020 |
|  |  |  |  |  |  |  |  |  |  |  | Dollars |  | % ofNet Revenue |  | %Change |  | Dollars |  | % ofNet Revenue |  | %Change |  | Dollars |  | % ofNet Revenue |
|  |  |  |  |  |  |  |  |  |  |  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  |  |  |  |  |  |  |  |  |  | $ | 79,830 |  |  | 78.9 | % |  | 18 | % |  | $ | 67,744 |  |  | 78.2 | % |  | — | % |  | $ | 67,607 |  |  | 79.7 | % |
| Services |  |  |  |  |  |  |  |  |  |  | 21,367 |  |  | 21.1 | % |  | 13 | % |  | 18,926 |  |  | 21.8 | % |  | 10 | % |  | 17,208 |  |  | 20.3 | % |
| Total net revenue |  |  |  |  |  |  |  |  |  |  | $ | 101,197 |  |  | 100.0 | % |  | 17 | % |  | $ | 86,670 |  |  | 100.0 | % |  | 2 | % |  | $ | 84,815 |  |  | 100.0 | % |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products (a) |  |  |  |  |  |  |  |  |  |  | $ | 12,606 |  |  | 15.8 | % |  | 11 | % |  | $ | 11,313 |  |  | 16.7 | % |  | (8) | % |  | $ | 12,238 |  |  | 18.1 | % |
| Services (b) |  |  |  |  |  |  |  |  |  |  | 9,285 |  |  | 43.5 | % |  | 5 | % |  | 8,827 |  |  | 46.6 | % |  | 5 | % |  | 8,401 |  |  | 48.8 | % |
| Total gross margin |  |  |  |  |  |  |  |  |  |  | $ | 21,891 |  |  | 21.6 | % |  | 9 | % |  | $ | 20,140 |  |  | 23.2 | % |  | (2) | % |  | $ | 20,639 |  |  | 24.3 | % |
| Operating expenses |  |  |  |  |  |  |  |  |  |  | $ | 17,232 |  |  | 17.0 | % |  | 5 | % |  | $ | 16,455 |  |  | 18.9 | % |  | (10) | % |  | $ | 18,273 |  |  | 21.5 | % |
| Operating income |  |  |  |  |  |  |  |  |  |  | $ | 4,659 |  |  | 4.6 | % |  | 26 | % |  | $ | 3,685 |  |  | 4.3 | % |  | 56 | % |  | $ | 2,366 |  |  | 2.8 | % |
| Net income from continuing operations |  |  |  |  |  |  |  |  |  |  | $ | 4,942 |  |  | 4.9 | % |  | 120 | % |  | $ | 2,245 |  |  | 2.6 | % |  | 331 | % |  | $ | 521 |  |  | 0.6 | % |
| Non-GAAP Financial Information |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |  |  |  | Fiscal Year Ended |
|  |  |  |  |  |  |  |  |  |  |  | January 28, 2022 |  |  |  | January 29, 2021 |  |  |  | January 31, 2020 |
|  |  |  |  |  |  |  |  |  |  | Dollars |  | % of Non-GAAP Net Revenue |  | %Change |  | Dollars |  | % of Non-GAAP Net Revenue |  | %Change |  | Dollars |  | % of Non-GAAP Net Revenue |
|  |  |  |  |  |  |  |  |  |  |  | (in millions, except percentages) |
| Non-GAAP net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  |  |  |  |  |  |  |  |  |  | $ | 79,830 |  |  | 78.9 | % |  | 18 | % |  | $ | 67,746 |  |  | 78.1 | % |  | — | % |  | $ | 67,612 |  |  | 79.5 | % |
| Services |  |  |  |  |  |  |  |  |  |  | 21,399 |  |  | 21.1 | % |  | 12 | % |  | 19,030 |  |  | 21.9 | % |  | 9 | % |  | 17,432 |  |  | 20.5 | % |
| Total non-GAAP net revenue |  |  |  |  |  |  |  |  |  |  | $ | 101,229 |  |  | 100.0 | % |  | 17 | % |  | $ | 86,776 |  |  | 100.0 | % |  | 2 | % |  | $ | 85,044 |  |  | 100.0 | % |
| Non-GAAP gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products (a) |  |  |  |  |  |  |  |  |  |  | $ | 13,261 |  |  | 16.6 | % |  | 9 | % |  | $ | 12,211 |  |  | 18.0 | % |  | (10) | % |  | $ | 13,540 |  |  | 20.0 | % |
| Services (b) |  |  |  |  |  |  |  |  |  |  | 9,423 |  |  | 44.0 | % |  | 4 | % |  | 9,022 |  |  | 47.4 | % |  | 4 | % |  | 8,689 |  |  | 49.8 | % |
| Total non-GAAP gross margin |  |  |  |  |  |  |  |  |  |  | $ | 22,684 |  |  | 22.4 | % |  | 7 | % |  | $ | 21,233 |  |  | 24.5 | % |  | (4) | % |  | $ | 22,229 |  |  | 26.1 | % |
| Non-GAAP operating expenses |  |  |  |  |  |  |  |  |  |  | $ | 14,899 |  |  | 14.7 | % |  | 4 | % |  | $ | 14,284 |  |  | 16.5 | % |  | (7) | % |  | $ | 15,413 |  |  | 18.1 | % |
| Non-GAAP operating income |  |  |  |  |  |  |  |  |  |  | $ | 7,785 |  |  | 7.7 | % |  | 12 | % |  | $ | 6,949 |  |  | 8.0 | % |  | 2 | % |  | $ | 6,816 |  |  | 8.0 | % |
| Non-GAAP net income |  |  |  |  |  |  |  |  |  |  | $ | 4,924 |  |  | 4.9 | % |  | 31 | % |  | $ | 3,746 |  |  | 4.3 | % |  | 9 | % |  | $ | 3,451 |  |  | 4.1 | % |
| EBITDA |  |  |  |  |  |  |  |  |  |  | $ | 8,206 |  |  | 8.1 | % |  | 9 | % |  | $ | 7,552 |  |  | 8.7 | % |  | 11 | % |  | $ | 6,824 |  |  | 8.0 | % |
| Adjusted EBITDA |  |  |  |  |  |  |  |  |  |  | $ | 9,660 |  |  | 9.5 | % |  | 12 | % |  | $ | 8,645 |  |  | 10.0 | % |  | 5 | % |  | $ | 8,226 |  |  | 9.7 | % |

[0001571996-22-000009:mdna:112]
____________________

[0001571996-22-000009:mdna:113]
(a)Product gross margin percentages represent product gross margin as a percentage of product net revenue, and non-GAAP product gross margin percentages represent non-GAAP product gross margin as a percentage of non-GAAP product net revenue.

[0001571996-22-000009:mdna:114]
(b)Services gross margin percentages represent services gross margin as a percentage of services net revenue, and non-GAAP services gross margin percentages represent non-GAAP services gross margin as a percentage of non-GAAP services net revenue.

[0001571996-22-000009:mdna:115]
Non-GAAP product net revenue, non-GAAP services net revenue, non-GAAP net revenue, non-GAAP product gross margin, non-GAAP services gross margin, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, EBITDA, and adjusted EBITDA are not measurements of financial performance prepared in accordance with GAAP.  Non-GAAP financial measures as a percentage of revenue are calculated based on non-GAAP net revenue.  See “Non‑GAAP Financial Measures” for additional information about these non-GAAP financial measures, including our reasons for including these measures, material limitations with respect to the usefulness of the measures, and a reconciliation of each non-GAAP financial measure to the most directly comparable GAAP financial measure.

[0001571996-22-000009:mdna:116]
Overview

[0001571996-22-000009:mdna:117]
During Fiscal 2022, our net revenue and non-GAAP net revenue both increased 17% primarily due to growth in net revenue for CSG and, to a lesser extent, an increase in ISG net revenue.  CSG net revenue benefited from increased sales of both commercial and consumer offerings, driven by the strong demand as a result of the continued global economic recovery coupled with customers seeking improved connectivity and productivity.  ISG net revenue continued to benefit from overall improvements in the macroeconomic environment and a shift toward investment in IT infrastructure.

[0001571996-22-000009:mdna:118]
During Fiscal 2022, our operating income increased 26% to $4.7 billion and our non-GAAP operating income increased 12% to $7.8 billion.  The increases in both operating income and non-GAAP operating income were primarily driven by growth in operating income for CSG, driven principally by our commercial offerings.  Operating income also benefited from a decrease in amortization of intangible assets partially offset by an increase in stock-based compensation expense.

[0001571996-22-000009:mdna:119]
Operating income as a percentage of net revenue increased 30 basis points to 4.6%, primarily due to the favorable impact of a decrease in amortization of intangible assets.  The increase in operating income as a percentage of net revenue was mostly offset by a decline in gross margin as a percentage of net revenue, which was principally attributable to a shift in mix towards CSG offerings coupled with a mix shift within ISG.  Further, the decline in gross margin as a percentage of net revenue was driven by the impacts of supply chain challenges and associated increases in component and logistics costs, the effects of which were not fully offset by pricing adjustments.  As a result of these dynamics, non-GAAP operating income as a percentage of net revenue decreased 30 basis points to 7.7%.

[0001571996-22-000009:mdna:120]
Cash provided by operating activities was $10.3 billion and $11.4 billion during Fiscal 2022 and Fiscal 2021, respectively.  Our cash flow from operations in Fiscal 2022 were primarily attributable to strong revenue growth throughout the year.  See “Market Conditions, Liquidity, Capital Commitments, and Contractual Cash Obligations” for further information on our cash flow metrics.

[0001571996-22-000009:mdna:121]
We continue to see opportunities to create value and grow in response to resilient demand for our IT solutions driven by a technology-enabled world.  We have demonstrated our ability to adjust as needed to changing market conditions with complementary solutions across all segments of our business, an agile workforce, and the strength of our global supply chain.  As we continue to innovate and modernize our core offerings, we believe that Dell Technologies is well-positioned for long-term profitable growth.

[0001571996-22-000009:mdna:122]
Net Revenue

[0001571996-22-000009:mdna:123]
Fiscal 2022 compared to Fiscal 2021

[0001571996-22-000009:mdna:124]
During Fiscal 2022, our net revenue and non-GAAP net revenue both increased 17%.  The increases in net revenue and non-GAAP net revenue were primarily attributable to an increase in net revenue for CSG and, to a lesser extent, an increase in net revenue for ISG.  See “Business Unit Results” for further information.

[0001571996-22-000009:mdna:125]
•Product Net Revenue — Product net revenue includes revenue from the sale of hardware products and software licenses.  During Fiscal 2022, both product net revenue and non-GAAP product net revenue increased 18%, primarily due to an increase in product net revenue for CSG and, to a lesser extent, ISG product net revenue.  CSG product net revenue increased primarily due to increases in units sold of both commercial and consumer product offerings as a result of continued strength in the demand environment and, to a lesser extent, an increase in average selling price principally related to our commercial offerings.  ISG product net revenue increased primarily due to increased sales volumes of our server offerings.

[0001571996-22-000009:mdna:126]
•Services Net Revenue — Services net revenue includes revenue from our services offerings and support services related to hardware products and software licenses.  During Fiscal 2022, services net revenue and non-GAAP services net revenue increased 13% and 12%, respectively, driven primarily by growth in CSG services net revenue and, to a lesser extent, growth in both ISG and other businesses services net revenue.  Growth in CSG services net revenue was primarily due to increases in services net revenue attributable to both CSG hardware support and maintenance and CSG third-party software support and maintenance.  ISG services net revenue increased primarily as a result of growth within hardware support services while other businesses services net revenue increased due to growth in software support and maintenance within VMware Resale.  A substantial portion of services net revenue is derived from offerings that have been deferred over a period of time, and, as a result, reported services net revenue growth rates will be different than reported product net revenue growth rates.

[0001571996-22-000009:mdna:127]
From a geographical perspective, net revenue generated by sales to customers in all regions increased during Fiscal 2022 primarily driven by strong CSG performance and, to a lesser extent, ISG performance.

[0001571996-22-000009:mdna:128]
Fiscal 2021 compared to Fiscal 2020

[0001571996-22-000009:mdna:129]
During Fiscal 2021, our net revenue and non-GAAP net revenue both increased 2%.  The increases in net revenue and non-GAAP net revenue were primarily attributable to an increase in net revenue for CSG, partially offset by a decline in ISG net revenue.  See “Business Unit Results” for further information.

[0001571996-22-000009:mdna:130]
•Product Net Revenue — During Fiscal 2021, both product net revenue and non-GAAP product net revenue remained flat, primarily due to a decrease in product net revenue for ISG, which was offset by an increase in product net revenue for CSG.

[0001571996-22-000009:mdna:131]
•Services Net Revenue — During Fiscal 2021, services net revenue and non-GAAP services net revenue increased 10% and 9%, respectively.  These increases were primarily attributable to an increase in services net revenue for CSG third-party software support and maintenance as well as an increase in VMware resale.

[0001571996-22-000009:mdna:132]
From a geographical perspective, net revenue generated by sales to customers in the Americas and EMEA both increased during Fiscal 2021 due to strong CSG performance partially offset by declines in ISG net revenue.  Net revenue generated by sales to customers in APJ decreased for both CSG and ISG as a result of a weaker demand environment.

[0001571996-22-000009:mdna:133]
Gross Margin

[0001571996-22-000009:mdna:134]
Fiscal 2022 compared to Fiscal 2021

[0001571996-22-000009:mdna:135]
During Fiscal 2022, our gross margin increased 9% to $21.9 billion principally driven by growth in CSG gross margin and the favorable impact of a decrease in amortization of intangible assets.  This increase was partially offset by a decrease in gross margin for other businesses primarily as a result of the impact of the divestiture of RSA Security during Fiscal 2021.  Non-GAAP gross margin increased 7% to $22.7 billion and was driven by the same CSG and other businesses dynamics discussed above.

[0001571996-22-000009:mdna:136]
During Fiscal 2022, our gross margin percentage decreased 160 basis points to 21.6%.  The decrease in gross margin percentage was principally due to a shift in mix towards CSG offerings coupled with a mix shift within ISG.  Further, the decline in gross margin as a percentage of net revenue was driven by the impacts of supply chain challenges and associated increases in component and logistics costs, the effects of which were not fully offset by pricing adjustments.  These decreases were partially offset by the favorable impact of a decrease in amortization of intangible assets.  Non-GAAP gross margin percentage decreased 210 basis points to 22.4% due to the same CSG and ISG dynamics discussed above.

[0001571996-22-000009:mdna:137]
•Products Gross Margin — During Fiscal 2022, product gross margin increased 11% to $12.6 billion primarily as a result of growth in CSG product gross margin coupled with the favorable impact of a decrease in amortization of intangible assets.  These effects were partially offset by a decline in other businesses product gross margin as a result of the impact of the divestiture of RSA Security.  Non-GAAP product gross margin increased 9% to $13.3 billion due to the same CSG and other businesses impacts.

[0001571996-22-000009:mdna:138]
During Fiscal 2022, product gross margin percentage decreased 90 basis points to 15.8%, primarily due to a decline in product gross margin percentage for both CSG and ISG and, to a lesser extent, a shift in mix towards CSG.  These impacts

[0001571996-22-000009:mdna:139]
52

[0001571996-22-000009:mdna:140]
were partially offset by the favorable impact of a decrease in amortization of intangible assets.  Non-GAAP product gross margin percentage decreased 140 basis points to 16.6% and was driven by the same CSG and ISG impacts discussed above.

[0001571996-22-000009:mdna:141]
•Services Gross Margin — During Fiscal 2022, services gross margin increased 5% to $9.3 billion and non-GAAP services gross margin increased 4% to $9.4 billion.  The increases were driven primarily by CSG and ISG services gross margin, partially offset by other businesses services gross margin as a result of the impact of the divestiture of RSA Security.  Both CSG and ISG services gross margin increased primarily due to growth in hardware support and maintenance.

[0001571996-22-000009:mdna:142]
Services gross margin percentage decreased 310 basis points to 43.5% and non-GAAP services gross margin percentage decreased 340 basis points to 44.0%.  The decreases were primarily driven by declines in services gross margin percentage across CSG, ISG, and other businesses and, to a lesser extent, a shift in mix towards CSG.

[0001571996-22-000009:mdna:143]
Fiscal 2021 compared to Fiscal 2020

[0001571996-22-000009:mdna:144]
During Fiscal 2021, our gross margin and non-GAAP gross margin decreased 2% to $20.1 billion and 4% to $21.2 billion, respectively.  The decrease in gross margin was primarily due to a decline in gross margin for ISG and other businesses, mostly offset by an increase in CSG gross margin coupled with a favorable impact of a decrease in amortization of intangible assets.  The decline in gross margin for other businesses decrease was driven by the divestiture of RSA Security.  The non-GAAP gross margin decrease was driven by the same ISG and other businesses dynamics discussed above.

[0001571996-22-000009:mdna:145]
During Fiscal 2021, our gross margin percentage and non-GAAP gross margin percentage decreased 110 basis points to 23.2% and 160 basis points to 24.5%, respectively.  The decreases in gross margin percentage and non-GAAP gross margin percentage were driven by a shift in product mix due to strong CSG sales, as well as decreases in gross margin percentages for ISG and CSG.  The decrease in gross margin percentage was partially offset by the favorable impact of a decrease in amortization of intangible assets.

[0001571996-22-000009:mdna:146]
•Products Gross Margin — During Fiscal 2021, product gross margin decreased 8% to $11.3 billion and non-GAAP product gross margin decreased 10% to $12.2 billion.  The decreases in product gross margin and non-GAAP product gross margin were primarily a decrease in ISG product net revenue, as well as a shift in product mix towards CSG.  These unfavorable impacts to product net revenue were partially offset by a decrease in amortization of intangibles.

[0001571996-22-000009:mdna:147]
During Fiscal 2021, product gross margin percentage decreased 140 basis points to 16.7% and non-GAAP product gross margin percentage decreased 200 basis points to 18.0%.  The decreases in product gross margin percentage and non-GAAP product gross margin percentage were attributable to a shift in product mix towards CSG, as well as decreases in product gross margin percentages for ISG and CSG.

[0001571996-22-000009:mdna:148]
•Services Gross Margin — During Fiscal 2021, services gross margin and non-GAAP services gross margin increased 5% to $8.8 billion and 4% to $9.0 billion, respectively.  The increases in both services gross margin and non-GAAP services gross margin were as a result of growth in CSG third-party software support and maintenance.  Further, services gross margin increased due to the favorable impact of a decrease in purchase accounting adjustments.

[0001571996-22-000009:mdna:149]
Services gross margin percentage and non-GAAP services gross margin percentage decreased 220 basis points to 46.6% and 240 basis points to 47.4%, respectively.  Both services gross margin percentage and non-GAAP services gross margin percentage decreased primarily due to a mix shift towards CSG coupled with a decline in CSG services gross margin percentage.  Services gross margin percentage was partially offset by the favorable impact of a decrease in purchase accounting adjustments.

[0001571996-22-000009:mdna:150]
Vendor Programs and Settlements

[0001571996-22-000009:mdna:151]
Our gross margin is affected by our ability to achieve competitive pricing with our vendors and contract manufacturers, including through our negotiation of a variety of vendor rebate programs to achieve lower net costs for the various components we include in our products.  Under these programs, vendors provide us with rebates or other discounts from the list prices for the components, which are generally elements of their pricing strategy.  We account for vendor rebates and other discounts as a reduction in cost of net revenue.  We manage our costs on a total net cost basis, which includes supplier list prices reduced by vendor rebates and other discounts.

[0001571996-22-000009:mdna:152]
The terms and conditions of our vendor rebate programs are largely based on product volumes and are generally negotiated either at the beginning of the annual or quarterly period, depending on the program.  The timing and amount of vendor rebates and other discounts we receive under the programs may vary from period to period, reflecting changes in the competitive environment.  We monitor our component costs and seek to address the effects of any changes to terms that might arise under our vendor rebate programs.  Our gross margins for Fiscal 2022, Fiscal 2021, and Fiscal 2020 were not materially affected by any changes to the terms of our vendor rebate programs, as the amounts we received under these programs were generally stable relative to our total net cost.  We are not aware of any significant changes to vendor pricing or rebate programs that may impact our results in the near term.

[0001571996-22-000009:mdna:153]
Operating Expenses

[0001571996-22-000009:mdna:154]
The following table presents information regarding our operating expenses for the periods indicated:

[0001571996-22-000009:mdna:155]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  |  |  | January 28, 2022 |  |  |  | January 29, 2021 |  |  |  | January 31, 2020 |
|  |  |  |  |  |  |  |  |  |  |  | Dollars |  | % ofNet Revenue |  | %Change |  | Dollars |  | % ofNet Revenue |  | %Change |  | Dollars |  | % ofNet Revenue |
|  |  |  |  |  |  |  |  |  |  |  | (in millions, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative |  |  |  |  |  |  |  |  |  |  | $ | 14,655 |  |  | 14.5 | % |  | 5 | % |  | $ | 14,000 |  |  | 16.1 | % |  | (11) | % |  | $ | 15,819 |  |  | 18.6 | % |
| Research and development |  |  |  |  |  |  |  |  |  |  | 2,577 |  |  | 2.5 | % |  | 5 | % |  | 2,455 |  |  | 2.8 | % |  | — | % |  | 2,454 |  |  | 2.9 | % |
| Total operating expenses |  |  |  |  |  |  |  |  |  |  | $ | 17,232 |  |  | 17.0 | % |  | 5 | % |  | $ | 16,455 |  |  | 18.9 | % |  | (10) | % |  | $ | 18,273 |  |  | 21.5 | % |
|  |  |  |  |  |  |  |  |  |  |  | Fiscal Year Ended |
|  |  |  |  |  |  |  |  |  |  |  | January 28, 2022 |  |  |  | January 29, 2021 |  |  |  | January 31, 2020 |
|  |  |  |  |  |  |  |  |  |  |  | Dollars |  | % of Non-GAAP Net Revenue |  | %Change |  | Dollars |  | % of Non-GAAP Net Revenue |  | %Change |  | Dollars |  | % of Non-GAAP Net Revenue |
|  |  |  |  |  |  |  |  |  |  | (in millions, except percentages) |
| Non-GAAP operating expenses |  |  |  |  |  |  |  |  |  |  | $ | 14,899 |  |  | 14.7 | % |  | 4 | % |  | $ | 14,284 |  |  | 16.5 | % |  | (7) | % |  | $ | 15,413 |  |  | 18.1 | % |

[0001571996-22-000009:mdna:156]
Fiscal 2022 compared to Fiscal 2021

[0001571996-22-000009:mdna:157]
During Fiscal 2022, total operating expenses and non-GAAP operating expenses increased 5% and 4%, respectively, primarily due to an increase in selling, general, and administrative expenses and, to a lesser extent, an increase in research and development expenses.

[0001571996-22-000009:mdna:158]
•Selling, General, and Administrative — Selling, general, and administrative (“SG&A”) expenses increased 5% during Fiscal 2022.  The increase was primarily due to an increase in consulting and contractor costs incurred in connection with our transformational initiatives, primarily the VMware Spin-off.  Further, SG&A expenses increased as a result of  employee-related compensation and benefits expense due to the reintroduction of expenses that were temporarily reduced during Fiscal 2021 in response to COVID-19, as well as an increase in advertising and promotion expense.

[0001571996-22-000009:mdna:159]
•Research and Development — Research and development (“R&D”) expenses are primarily composed of personnel-related expenses related to product development.  R&D expenses grew 5% during Fiscal 2022.  As a percentage of net revenue, R&D expenses for Fiscal 2022 and Fiscal 2021 were approximately 2.5% and 2.8%, respectively.  The decrease in R&D expenses as a percentage of net revenue was attributable to revenue growth that outpaced R&D investments.  We intend to continue to support R&D initiatives to innovate and introduce new and enhanced solutions into the market.

[0001571996-22-000009:mdna:160]
We continue to make selective investments designed to enable growth, marketing, and R&D, while balancing our efforts to drive cost efficiencies in the business.  We also expect to continue to make investments in support of our own digital transformation to modernize our IT operations.

[0001571996-22-000009:mdna:161]
Fiscal 2021 compared to Fiscal 2020

[0001571996-22-000009:mdna:162]
During Fiscal 2021, total operating expenses decreased 10% and total non-GAAP operating expenses decreased 7% primarily due to a decrease in selling, general, and administrative expense.

[0001571996-22-000009:mdna:163]
•Selling, General, and Administrative — Selling, general, and administrative (“SG&A”) expenses decreased 11% during Fiscal 2021.  The decrease in SG&A expenses was partly attributable to measures taken as a result of the COVID-19 pandemic, which included global hiring limitations, reductions in consulting and contractor costs and facilities-related costs, global travel restrictions, and suspension of the Dell 401(k) match program for U.S. employees, as well as a decrease in amortization of intangible assets.  Additionally, during Fiscal 2021, SG&A expenses benefited from the absence of Virtustream pre-tax impairment charges of $619 million recognized in Fiscal 2020.

[0001571996-22-000009:mdna:164]
•Research and Development — R&D expenses remained flat during Fiscal 2021 when compared to Fiscal 2020.  R&D expenses as a percentage of net revenue also remained essentially flat during Fiscal 2021at 2.8% compared to 2.9% during Fiscal 2020.

[0001571996-22-000009:mdna:165]
Operating Income

[0001571996-22-000009:mdna:166]
Fiscal 2022 compared to Fiscal 2021

[0001571996-22-000009:mdna:167]
During Fiscal 2022, our operating income and non-GAAP operating income increased 26% to $4.7 billion and 12% to $7.8 billion, respectively.  The increases were primarily due to growth in operating income for CSG, driven primarily by our commercial offerings.  Operating income also benefited from the favorable impact of a decrease in amortization of intangible assets, which was partially offset by an increase in stock-based compensation expense.

[0001571996-22-000009:mdna:168]
Operating income as a percentage of net revenue increased 30 basis points to 4.6%, primarily due to the favorable impact of a decrease in amortization of intangible assets.  The increase in operating income as a percentage of net revenue was mostly offset by a decline in gross margin as a percentage of net revenue principally due to a shift in mix towards CSG offerings coupled with a mix shift within ISG.  Further, the decline in gross margin as a percentage of net revenue was driven by the impacts of supply chain challenges and associated increases in component and logistics costs, the effects of which were not fully offset by pricing adjustments.  As a result of these dynamics, non-GAAP operating income as a percentage of net revenue decreased 30 basis points to 7.7%.

[0001571996-22-000009:mdna:169]
Fiscal 2021 compared to Fiscal 2020

[0001571996-22-000009:mdna:170]
During Fiscal 2021, our operating income increased 56% to $3.7 billion, primarily driven by a decrease in amortization of intangible assets and other corporate expenses, most notably resulting from the absence of Virtustream impairment charges of $619 million recognized in Fiscal 2020.  Non-GAAP operating income increased 2% to $6.9 billion during Fiscal 2021 primarily due to an increase in operating income for CSG, which was partially offset by a decrease in operating income for ISG.  Operating income for both CSG and ISG benefited from lower selling, general, and administrative expenses as we realized the benefit of cost reduction initiatives, of which select initiatives began to be reinstated in the fourth quarter of Fiscal 2021.

[0001571996-22-000009:mdna:171]
Operating income as a percentage of net revenue increased 150 basis points to 4.3% and was primarily driven by the favorable impact of decreases in both amortization of intangible assets and other corporate expenses resulting from the absence of Virtustream impairment charges of $619 million recognized in Fiscal 2020.  Non-GAAP operating income as a percentage of net revenue remained flat at 8.0% as result of a decrease in gross margin percentage offset by decreases in operating expenses as a percentage of net revenue.

[0001571996-22-000009:mdna:172]
Interest and Other, Net

[0001571996-22-000009:mdna:173]
The following table presents information regarding interest and other, net for the periods indicated:

[0001571996-22-000009:mdna:174]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  | January 28, 2022 |  | January 29, 2021 |  | January 31, 2020 |
|  |  |  |  |  | (in millions) |
| Interest and other, net: |  |  |  |  |  |  |  |  |  |
| Investment income, primarily interest |  |  |  |  | $ | 42 |  |  | $ | 47 |  |  | $ | 99 |  |
| Gain on investments, net |  |  |  |  | 569 |  |  | 425 |  |  | 158 |  |
| Interest expense |  |  |  |  | (1,542) |  |  | (2,052) |  |  | (2,334) |  |
| Foreign exchange |  |  |  |  | (221) |  |  | (160) |  |  | (195) |  |
| Gain on disposition of businesses and assets |  |  |  |  | 3,968 |  |  | 458 |  |  | — |  |
| Debt extinguishment fees |  |  |  |  | (1,572) |  |  | (158) |  |  | (83) |  |
| Other |  |  |  |  | 20 |  |  | 101 |  |  | (62) |  |
| Total interest and other, net |  |  |  |  | $ | 1,264 |  |  | $ | (1,339) |  |  | $ | (2,417) |  |

[0001571996-22-000009:mdna:175]
Fiscal 2022 compared to Fiscal 2021

[0001571996-22-000009:mdna:176]
During Fiscal 2022, the change in interest and other, net was favorable by $2.6 billion, which was primarily driven by the pre-tax gain of $4.0 billion on the sale of Boomi coupled with a decrease in interest expense due to debt paydowns.  These effects were partially offset by debt extinguishment fees of $1.6 billion primarily associated with the early retirement of certain senior notes.  Refer to Note 7 of the Notes to the Consolidated Financial Statements for further details associated with the retirement of this debt.

[0001571996-22-000009:mdna:177]
Fiscal 2021 compared to Fiscal 2020

[0001571996-22-000009:mdna:178]
During Fiscal 2021, the change in interest and other, net was favorable by $1.1 billion, primarily due to a $233 million net gain on the fair value adjustment of one of our strategic investments and a pre-tax gain of $338 million on the sale of RSA Security.  Interest and other, net also benefited from a decrease in interest expense due to debt paydowns over the period.

[0001571996-22-000009:mdna:179]
Income and Other Taxes

[0001571996-22-000009:mdna:180]
The following table presents information regarding our income and other taxes for the periods indicated:

[0001571996-22-000009:mdna:181]
|  | Fiscal Year Ended |
|  | January 28, 2022 |  | January 29, 2021 |  | January 31, 2020 |
|  | (in millions, except percentages) |
| Income (loss) before income taxes | $ | 5,923 |  |  | $ | 2,346 |  |  | $ | (51) |  |
| Income tax expense (benefit) | $ | 981 |  |  | $ | 101 |  |  | $ | (572) |  |
| Effective income tax rate | 16.6 | % |  | 4.3 | % |  | 1121.6 | % |

[0001571996-22-000009:mdna:182]
For Fiscal 2022, Fiscal 2021, and Fiscal 2020, our effective income tax rates were 16.6% on pre-tax income of $5,923 million, 4.3% on pre-tax income of $2,346 million, and 1121.6% on a pre-tax loss of $51 million, respectively.  The changes in our effective income tax rate for Fiscal 2022 as compared to Fiscal 2021 and for Fiscal 2021 as compared to Fiscal 2020, were primarily driven by discrete tax items and a change in our jurisdictional mix of income.

[0001571996-22-000009:mdna:183]
For Fiscal 2022, the Company’s effective tax rate includes tax expense of $1.0 billion on pre-tax gain of$4.0 billion related to the divestiture of Boomi during the period, as well as tax benefits of $367 million on $1.6 billion debt extinguishment fees and $244 million related to the restructuring of certain legal entities.  For Fiscal 2021, the Company’s effective tax rate includes tax benefits of $746 million related to an audit settlement and tax expense of $359 million on pre-tax gain of $338 million relating

[0001571996-22-000009:mdna:184]
56

[0001571996-22-000009:mdna:185]
to the divestiture of RSA Security during the period.  For Fiscal 2020, the Company’s effective tax rate includes tax benefits of $405 million related to an intra-entity asset transfer and $305 million related to an audit settlement.

[0001571996-22-000009:mdna:186]
Our effective income tax rate can fluctuate depending on the geographic distribution of our worldwide earnings, as our foreign earnings are generally taxed at lower rates than in the United States.  The differences between our effective income tax rate and the U.S. federal statutory rate of 21% principally result from the geographical distribution of income, differences between the book and tax treatment of certain items and the discrete tax items described above.  In certain jurisdictions, our tax rate is significantly less than the applicable statutory rate as a result of tax holidays.  The majority of our foreign income that is subject to these tax holidays is attributable to Singapore and China.  A significant portion of these income tax benefits relates to a tax holiday that will be effective until January 31, 2029.  Our other tax holidays will expire in whole or in part during Fiscal 2030 through Fiscal 2031.  Many of these tax holidays and reduced tax rates may be extended when certain conditions are met or may be terminated early if certain conditions are not met.  As of January 28, 2022, we were not aware of any matters of noncompliance related to these tax holidays.

[0001571996-22-000009:mdna:187]
For further discussion regarding tax matters, including the status of income tax audits, see Note 12 of the Notes to the Consolidated Financial Statements included in this report.

[0001571996-22-000009:mdna:188]
Net Income from Continuing Operations

[0001571996-22-000009:mdna:189]
Fiscal 2022 compared to Fiscal 2021

[0001571996-22-000009:mdna:190]
Net income from continuing operations was $4.9 billion in Fiscal 2022, compared to $2.2 billion in Fiscal 2021.  The increase in net income from continuing operations was primarily attributable to a favorable change in interest and other, net coupled with an increase in operating income, partially offset by an increase in tax expense during the period.

[0001571996-22-000009:mdna:191]
Non-GAAP net income was $4.9 billion in Fiscal 2022, compared to $3.7 billion in Fiscal 2021.  The increase in non-GAAP net income was primarily attributable to an increase in non-GAAP operating income coupled with a favorable change in interest and other, net.

[0001571996-22-000009:mdna:192]
Fiscal 2021 compared to Fiscal 2020

[0001571996-22-000009:mdna:193]
Net income from continuing operations was $2.2 billion in Fiscal 2021, compared to $0.5 billion in Fiscal 2020.  The increase in net income from continuing operations during Fiscal 2021 was primarily attributable to an increase in operating income and a favorable change in interest and other, net, partially offset by an increase in tax expense for the period.

[0001571996-22-000009:mdna:194]
Non-GAAP net income was $3.7 billion in Fiscal 2021, compared to $3.5 billion in Fiscal 2020.  The increase in non-GAAP net income during Fiscal 2021 was primarily attributable to an increase in operating income and a favorable change in interest and other, net for the period.

[0001571996-22-000009:mdna:195]
Business Unit Results

[0001571996-22-000009:mdna:196]
Our reportable segments are based on the following business units: ISG and CSG.  A description of our business units is provided under “Introduction.”  See Note 19 of the Notes to the Consolidated Financial Statements included in this report for a reconciliation of net revenue and operating income by reportable segment to consolidated net revenue and consolidated operating income (loss), respectively.

[0001571996-22-000009:mdna:197]
Infrastructure Solutions Group

[0001571996-22-000009:mdna:198]
The following table presents net revenue and operating income attributable to ISG for the periods indicated:

[0001571996-22-000009:mdna:199]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  |  |  | January 28, 2022 |  | % Change |  | January 29, 2021 |  | % Change |  | January 31, 2020 |
|  |  |  |  |  |  |  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Servers and networking |  |  |  |  |  |  | $ | 17,901 |  | 8 | % |  | $ | 16,592 |  | (3) | % |  | $ | 17,193 |
| Storage |  |  |  |  |  |  | 16,465 |  | — | % |  | 16,410 |  | (4) | % |  | 17,174 |
| Total ISG net revenue |  |  |  |  |  |  | $ | 34,366 |  | 4 | % |  | $ | 33,002 |  | (4) | % |  | $ | 34,367 |
| Operating income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| ISG operating income |  |  |  |  |  |  | $ | 3,736 |  | — | % |  | $ | 3,753 |  | (5) | % |  | $ | 3,948 |
| % of segment net revenue |  |  |  |  |  |  | 10.9 | % |  |  |  | 11.4 | % |  |  |  | 11.5 | % |

[0001571996-22-000009:mdna:200]
Fiscal 2022 compared to Fiscal 2021

[0001571996-22-000009:mdna:201]
Net Revenue — During Fiscal 2022, ISG net revenue increased 4% primarily due to an increase in sales of servers and networking.   This increase was attributable to improvements in the macroeconomic environment and a shift towards investment in IT infrastructure compared to Fiscal 2021 which was impacted by a weaker demand environment as a result of COVID-19.

[0001571996-22-000009:mdna:202]
Revenue from the sales of servers and networking increased 8% during Fiscal 2022, primarily driven by an increase in units sold due to continued strong demand for our PowerEdge servers.

[0001571996-22-000009:mdna:203]
Storage revenue remained flat during Fiscal 2022.  Within storage, revenue associated with our hyper-converged infrastructure offerings increased during the same period.  We continue to experience growth in demand across most of our storage offerings which we expect will benefit net revenue in future periods.

[0001571996-22-000009:mdna:204]
ISG customers are interested in new and innovative models that address how they consume our solutions.  We offer options that include as-a-Service, utility, leases, and immediate pay models, designed to match customers’ consumption and financing preferences.  Our multiyear agreements typically result in recurring revenue streams over the term of the arrangement.  We expect our flexible consumption models and as-a-Service offerings through APEX will further strengthen our customer relationships and provide a foundation for growth in recurring revenue.

[0001571996-22-000009:mdna:205]
From a geographical perspective, net revenue attributable to ISG increased in all regions during Fiscal 2022.

[0001571996-22-000009:mdna:206]
Operating Income — During Fiscal 2022, ISG operating income as a percentage of net revenue decreased 50 basis points to 10.9% due to a decline in ISG gross margin percentage.  The decline in ISG gross margin percentage was driven by a shift in mix within ISG towards servers and networking, competitive pricing pressure, and the impacts of industry-wide supply chain challenges which were not fully offset by pricing adjustments.  Supply chain challenges included component availability, increased logistics costs, and the inflationary component cost environment.  The decrease in ISG operating income as a percentage of net revenue was partially offset by a decrease in ISG operating expense as a percentage of net revenue.

[0001571996-22-000009:mdna:207]
Fiscal 2021 compared to Fiscal 2020

[0001571996-22-000009:mdna:208]
Net Revenue — During Fiscal 2021, ISG net revenue decreased 4% due to decreases in sales of servers and networking and storage.  ISG net revenue decreased primarily due to a weaker demand environment, as customers shifted their investments toward remote work and business continuity solutions.

[0001571996-22-000009:mdna:209]
Revenue from the sales of servers and networking decreased 3% during Fiscal 2021, primarily driven by a decline in demand of our PowerEdge servers due to the broader macroeconomic environment, including the effects of COVID-19.

[0001571996-22-000009:mdna:210]
Storage revenue decreased 4% during Fiscal 2021 primarily due to declines in demand for our core storage solutions offerings, partially offset by increased demand for converged and hyper-converged infrastructure solutions.  We continue to make enhancements to our storage solutions offerings and expect that these offerings, including our PowerStore storage array released in May 2020, will drive long-term improvements in the business.

[0001571996-22-000009:mdna:211]
From a geographical perspective, net revenue attributable to ISG decreased in all regions during Fiscal 2021, driven by a weaker demand environment as a result of pervasive global COVID-19 disruptions.

[0001571996-22-000009:mdna:212]
Operating Income — During Fiscal 2021, ISG operating income as a percentage of net revenue decreased 10 basis points to 11.4%.  The decline in ISG operating income percentage during Fiscal 2021 was driven by a decrease in ISG gross margin percentage from higher server configuration costs, increased freight costs, and lower benefits from component cost deflation.  During Fiscal 2021, ISG component costs remained deflationary in the aggregate, but to a lesser degree relative to Fiscal 2020.  The decline in ISG gross margin percentage in Fiscal 2021 was partially offset by a decrease in ISG operating expenses as a percentage of net revenue, as we realized the benefit of cost reduction initiatives.

[0001571996-22-000009:mdna:213]
59

[0001571996-22-000009:mdna:214]
Client Solutions Group

[0001571996-22-000009:mdna:215]
The following table presents net revenue and operating income attributable to CSG for the periods indicated:

[0001571996-22-000009:mdna:216]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  |  |  | January 28, 2022 |  | % Change |  | January 29, 2021 |  | % Change |  | January 31, 2020 |
|  |  |  |  |  |  |  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial |  |  |  |  |  |  | $ | 45,576 |  | 29 | % |  | $ | 35,423 |  | 3 | % |  | $ | 34,293 |
| Consumer |  |  |  |  |  |  | 15,888 |  | 23 | % |  | 12,964 |  | 12 | % |  | 11,562 |
| Total CSG net revenue |  |  |  |  |  |  | $ | 61,464 |  | 27 | % |  | $ | 48,387 |  | 6 | % |  | $ | 45,855 |
| Operating income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| CSG operating income |  |  |  |  |  |  | $ | 4,365 |  | 31 | % |  | $ | 3,333 |  | 7 | % |  | $ | 3,114 |
| % of segment net revenue |  |  |  |  |  |  | 7.1 | % |  |  |  | 6.9 | % |  |  |  | 6.8 | % |

[0001571996-22-000009:mdna:217]
Fiscal 2022 compared to Fiscal 2021

[0001571996-22-000009:mdna:218]
Net Revenue — During Fiscal 2022, CSG net revenue increased 27% primarily due to increases in units sold of both commercial and consumer product offerings.  The commercial and consumer increases were driven by strength in the demand environment as a result of the continued global economic recovery coupled with customers seeking improved connectivity and productivity.

[0001571996-22-000009:mdna:219]
Commercial revenue increased 29% during Fiscal 2022 primarily due to an increase in sales across the majority of our commercial offerings.  To a lesser extent, increases in average selling price also contributed to the growth in commercial revenue as we navigated through supply chain shortages and managed pricing in response to the inflationary cost environment.

[0001571996-22-000009:mdna:220]
Consumer revenue increased 23% during Fiscal 2022 primarily due to an increase in units sold as a result of strong demand across the majority of our consumer product offerings.

[0001571996-22-000009:mdna:221]
From a geographical perspective, net revenue attributable to CSG increased across all regions during Fiscal 2022.

[0001571996-22-000009:mdna:222]
Operating Income — During Fiscal 2022, CSG operating income as a percentage of net revenue increased 20 basis points to 7.1%, driven primarily by a decrease in CSG operating expenses as a percentage of revenue.  This benefit was mostly offset by a decrease in CSG gross margin percentage which was impacted by heightened supply chain challenges, logistics costs, and the inflationary component cost environment, the effects of which were not fully offset by pricing adjustments.

[0001571996-22-000009:mdna:223]
Fiscal 2021 compared to Fiscal 2020

[0001571996-22-000009:mdna:224]
Net Revenue — During Fiscal 2021, CSG net revenue increased 6% primarily due to an increase in commercial and consumer notebook sales, partially offset by a decrease in commercial desktop sales.  Much of this demand was driven by the imperative for remote work and remote learning solutions, as business, government, and education customers sought to maintain productivity in the midst of COVID-19.

[0001571996-22-000009:mdna:225]
Commercial revenue increased 3% during Fiscal 2021 due to an increase in commercial notebooks sales, and particularly for entry-level commercial notebooks driven by customers in education and state and local government.  The increases were partially offset by lower sales of commercial desktops.

[0001571996-22-000009:mdna:226]
Consumer revenue increased 12% during Fiscal 2021 due to increases in average selling prices across all consumer product offerings, coupled with continued strong demand for consumer notebooks and high-end and gaming systems.

[0001571996-22-000009:mdna:227]
From a geographical perspective, net revenue attributable to CSG increased in the Americas and EMEA during Fiscal 2021.  These increases were partially offset by a decline in net revenue attributable to CSG in APJ during the period.

[0001571996-22-000009:mdna:228]
Operating Income — During Fiscal 2021, CSG operating income as a percentage of net revenue increased 10 basis points to 6.9%.  This increase was primarily attributable to a decrease in CSG operating expenses as a percentage of revenue, as we realized the benefit of cost reduction initiatives.  This benefit was mostly offset by a decrease in CSG gross margin percentage driven by a shift in product mix to entry-level commercial notebooks and lower component cost deflation relative to pricing.

[0001571996-22-000009:mdna:229]
61

[0001571996-22-000009:mdna:230]
OTHER BALANCE SHEET ITEMS

[0001571996-22-000009:mdna:231]
Accounts Receivable

[0001571996-22-000009:mdna:232]
We sell products and services directly to customers and through a variety sales channels, including retail distribution.  Our accounts receivable, net, was $12.9 billion and $10.7 billion as of January 28, 2022 and January 29, 2021, respectively.  We maintain an allowance for expected credit losses to cover receivables that may be deemed uncollectible.  The allowance for expected credit losses is an estimate based on an analysis of historical loss experience, current receivables aging, and management’s assessment of current conditions and reasonable and supportable expectation of future conditions, as well as specific identifiable customer accounts that are deemed at risk.  As of January 28, 2022 and January 29, 2021, the allowance for expected credit losses was $90 million and $99 million, respectively.  Based on our assessment, we believe that we are adequately reserved for expected credit losses.  We will continue to monitor the aging of our accounts receivable and take actions, where necessary, to reduce our exposure to credit losses.

[0001571996-22-000009:mdna:233]
Dell Financial Services and Financing Receivables

[0001571996-22-000009:mdna:234]
The Company offers or arranges various financing options and services for our customers globally, including through captive financing operations.  DFS originates, collects, and services customer receivables primarily related to the purchase of our product, software, and service solutions.  The Company further strengthens our customer relationships through its flexible consumption models, which enable us to offer our customers the option to pay over time and, in certain cases, based on utilization, to provide them with financial flexibility to meet their changing technological requirements.  New financing originations were $8.5 billion, $8.9 billion, and $8.5 billion for Fiscal 2022, Fiscal 2021, and Fiscal 2020, respectively.

[0001571996-22-000009:mdna:235]
The Company’s leases are classified as sales-type leases, direct financing leases, or operating leases.  Amounts due from lessees under sales-type leases or direct financing leases are recorded as part of financing receivables, with interest income recognized over the contract term.  On commencement of sales-type leases, we typically qualify for up-front revenue recognition.  On originations of operating leases, we record equipment under operating leases, classified as property, plant, and equipment, and recognize rental revenue and depreciation expense, classified as cost of net revenue, over the contract term.  Direct financing leases are immaterial.  Leases that commenced prior to the effective date of the current lease accounting standard continue to be accounted for under previous lease accounting guidance.

[0001571996-22-000009:mdna:236]
As of January 28, 2022 and January 29, 2021, our financing receivables, net were $10.6 billion and $10.5 billion, respectively.  We maintain an allowance to cover expected financing receivable credit losses and evaluate credit loss expectations based on our total portfolio.  For Fiscal 2022, Fiscal 2021, and Fiscal 2020, the principal charge-off rate for our financing receivables portfolio was 0.6%, 0.7%, and 1.0%, respectively.  The credit quality of our financing receivables has improved in recent years as the mix of high-quality commercial accounts in our portfolio has continued to increase.  We continue to monitor broader economic indicators and their potential impact on future credit loss performance.  We have an extensive process to manage our exposure to customer credit risk, including active management of credit lines and our collection activities.  We also sell selected fixed-term financing receivables without recourse to unrelated third parties on a periodic basis, primarily to manage certain concentrations of customer credit exposure.  Based on our assessment of the customer financing receivables, we believe that we are adequately reserved.

[0001571996-22-000009:mdna:237]
We retain a residual interest in equipment leased under our lease programs.  As of January 28, 2022 and January 29, 2021, the residual interest recorded as part of financing receivables was $217 million and $424 million, respectively.  The decline in residual interest during Fiscal 2022 was principally attributable to a corresponding increase in originations of operating leases.  The amount of the residual interest is established at the inception of the lease based upon estimates of the value of the equipment at the end of the lease term using historical studies, industry data, and future value-at-risk demand valuation methods.  On a quarterly basis, we assess the carrying amount of our recorded residual values for impairment.  Generally, expected losses as a result of residual value risk on equipment under lease are not considered to be significant primarily because of the existence of a secondary market with respect to the equipment.  Further, the lease agreement clearly defines applicable return conditions and remedies for non-compliance, to ensure that the leased equipment will be in good operating condition upon return.  No expected losses were recorded related to residual assets during Fiscal 2022 or Fiscal 2021.

[0001571996-22-000009:mdna:238]
As of January 28, 2022 and January 29, 2021, equipment under operating leases, net was $1.7 billion and $1.3 billion, respectively.  We assess the carrying amount of the equipment under operating leases for impairment whenever events or circumstances may indicate that an impairment has occurred.  No material impairment losses were recorded related to such equipment during Fiscal 2022, Fiscal 2021, or Fiscal 2020.

[0001571996-22-000009:mdna:239]
62

[0001571996-22-000009:mdna:240]
DFS offerings are initially funded through cash on hand at the time of origination, most of which is subsequently replaced with asset-backed financing.  For DFS offerings which qualify as sales-type leases, the initial funding of financing receivables is reflected as an impact to cash flows from operations, and is largely subsequently offset by cash proceeds from financing.  For DFS operating leases, the initial funding is classified as a capital expenditure and reflected as an impact to cash flows used in investing activities.

[0001571996-22-000009:mdna:241]
See Note 5 of the Notes to the Consolidated Financial Statements included in this report for additional information about our financing receivables and the associated allowances, and equipment under operating leases.

[0001571996-22-000009:mdna:242]
63

[0001571996-22-000009:mdna:243]
LIQUIDITY, CAPITAL COMMITMENTS, CONTRACTUAL CASH OBLIGATIONS, AND MARKET CONDITIONS

[0001571996-22-000009:mdna:244]
Liquidity and Capital Resources

[0001571996-22-000009:mdna:245]
To support our ongoing business operations, we rely on operating cash flows as our primary source of liquidity.  We monitor the efficiency of our balance sheet to ensure that we have adequate liquidity to support our business and strategic initiatives.  In addition to internally generated cash, we have access to other capital sources to finance our strategic initiatives and fund growth in our financing operations.  Our strategy is to deploy capital from any potential source, whether internally generated cash or debt, depending on the adequacy and availability of that source of capital and whether it can be accessed in a cost-effective manner.

[0001571996-22-000009:mdna:246]
We believe that our current cash and cash equivalents, together with cash that will be provided by future operations and borrowings expected to be available under our revolving credit facility, will be sufficient over at least the next twelve months and for the foreseeable future thereafter meet our material cash requirements, including funding of our operations, debt related payments, capital expenditures, and other corporate needs.

[0001571996-22-000009:mdna:247]
As part our overall capital allocation strategy, we intend to drive growth while maintaining our investment grade rating and focusing on returning capital to our shareholders through both share repurchase programs and dividend payments.

[0001571996-22-000009:mdna:248]
The following table presents our cash and cash equivalents as well as our available borrowings as of the dates indicated:

[0001571996-22-000009:mdna:249]
|  | January 28, 2022 |  | January 29, 2021 |
|  | (in millions) |
| Cash and cash equivalents, and available borrowings: |  |  |  |
| Cash and cash equivalents | $ | 9,477 |  |  | $ | 9,508 |  |
| Remaining available borrowings under revolving credit facilities | 4,969 |  |  | 4,467 |  |
| Total cash, cash equivalents, and available borrowings | $ | 14,446 |  |  | $ | 13,975 |  |

[0001571996-22-000009:mdna:250]
Our revolving credit facilities as of January 28, 2022 consist only of the 2021 Revolving Credit Facility which has a maximum capacity of $5.0 billion and available borrowings under this facility are reduced by draws on the facility and outstanding letters of credit.  As of January 28, 2022, there were no borrowings outstanding under the facility and remaining available borrowings totaled approximately $5.0 billion.  We may regularly use our available borrowings from the 2021 Revolving Credit Facility on a short-term basis for general corporate purposes.  See Note 7 of the Notes to the Consolidated Financial Statements included in this report for additional information about the 2021 Revolving Credit Facility.

[0001571996-22-000009:mdna:251]
Debt

[0001571996-22-000009:mdna:252]
The following table presents our outstanding debt as of the dates indicated:

[0001571996-22-000009:mdna:253]
|  | January 28, 2022 |  | Increase (Decrease) |  | January 29, 2021 |
|  | (in millions) |
| Core debt |  |  |  |  |  |
| Senior Notes | $ | 16,300 |  |  | $ | (11,177) |  |  | $ | 27,477 |  |
| Legacy Notes and Debentures | 952 |  |  | (400) |  |  | 1,352 |  |
| EMC Notes | — |  |  | (1,000) |  |  | 1,000 |  |
| DFS allocated debt | (1,133) |  |  | (467) |  |  | (666) |  |
| Total core debt | 16,119 |  |  | (13,044) |  |  | 29,163 |  |
| DFS related debt |  |  |  |  |  |
| DFS debt | 9,646 |  |  | (20) |  |  | 9,666 |  |
| DFS allocated debt | 1,133 |  |  | 467 |  |  | 666 |  |
| Total DFS related debt | 10,779 |  |  | 447 |  |  | 10,332 |  |
| Other | 337 |  |  | 157 |  |  | 180 |  |
| Total debt, principal amount | 27,235 |  |  | (12,440) |  |  | 39,675 |  |
| Carrying value adjustments | (281) |  |  | 172 |  |  | (453) |  |
| Total debt, carrying value | $ | 26,954 |  |  | $ | (12,268) |  |  | $ | 39,222 |  |

[0001571996-22-000009:mdna:254]
During Fiscal 2022, the outstanding principal amount of our debt decreased by $12.4 billion to $27.2 billion as of January 28, 2022, primarily driven by net repayments of core debt.

[0001571996-22-000009:mdna:255]
We define core debt as the total principal amount of our debt, less DFS related debt and other debt.  Our core debt was $16.1 billion and $29.2 billion as of January 28, 2022 and January 29, 2021, respectively.  The decrease in our core debt during Fiscal 2022 was driven by principal repayments which were primarily funded with the proceeds from the VMware Spin-off special dividend of $9.3 billion paid to Dell Technologies and, to a lesser extent, cash on hand.  See Note 7 of the Notes to the Consolidated Financial Statements included in this report for more information about our debt.

[0001571996-22-000009:mdna:256]
DFS related debt primarily represents debt from our securitization and structured financing programs.  The majority of DFS debt represents borrowings under securitization programs and structured financing programs, for which our risk of loss is limited to transferred lease and loan payments and associated equipment, and under which the credit holders have no recourse to Dell Technologies.

[0001571996-22-000009:mdna:257]
To fund expansion of the DFS business, we balance the use of the securitization and structured financing programs with other sources of liquidity.  We approximate the amount of our debt used to fund the DFS business by applying a 7:1 debt to equity ratio to the sum of our financing receivables balance and equipment under our DFS operating leases, net.  The debt to equity ratio is based on the underlying credit quality of the assets.  See Note 5 of the Notes to the Consolidated Financial Statements included in this report for more information about our DFS debt.

[0001571996-22-000009:mdna:258]
We have made steady progress in paying down debt and we will continue to pursue deleveraging as an important component of our overall strategy.  As a result of our debt reduction and liability management strategy, we achieved an investment grade corporate family rating from three major credit rating agencies during Fiscal 2022.

[0001571996-22-000009:mdna:259]
We believe we will continue to be able to make our debt principal and interest payments, including the short-term maturities, from existing and expected sources of cash, primarily from operating cash flows.  Cash used for debt principal and interest payments may include short-term borrowings under our revolving credit facility.  Under our variable-rate debt, we could experience variations in our future interest expense from potential fluctuations in applicable reference rates, or from possible fluctuations in the level of DFS debt required to meet future demand for customer financing.  For Fiscal 2023, there are no scheduled maturities related to our outstanding core debt.  However, at our sole discretion, we may purchase, redeem, prepay, refinance, or otherwise retire any amount of our outstanding indebtedness under the terms of such indebtedness at any time and from time to time, in open market or negotiated transactions with the holders of such indebtedness or otherwise, as appropriate market conditions exist.

[0001571996-22-000009:mdna:260]
Cash Flows

[0001571996-22-000009:mdna:261]
The following table presents a summary of our Consolidated Statements of Cash Flows for the periods indicated:

[0001571996-22-000009:mdna:262]
|  | Fiscal Year Ended |
|  | January 28, 2022 |  | January 29, 2021 |  | January 31, 2020 |
|  | (in millions) |
| Net change in cash from: |  |  |  |  |  |
| Operating activities | $ | 10,307 |  |  | $ | 11,407 |  |  | $ | 9,291 |  |
| Investing activities | 1,306 |  |  | (460) |  |  | (4,686) |  |
| Financing activities | (16,609) |  |  | (5,950) |  |  | (4,604) |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash | (106) |  |  | 36 |  |  | (90) |  |
| Change in cash, cash equivalents, and restricted cash | $ | (5,102) |  |  | $ | 5,033 |  |  | $ | (89) |  |

[0001571996-22-000009:mdna:263]
Operating Activities — Fiscal 2022 includes cash provided by operating activities related to VMware through the date of the VMware Spin-off.  In comparison, Fiscal 2021 and Fiscal 2020 reflect cash provided by operating activities related to VMware for the full fiscal year.  Cash provided by operating activities was $10.3 billion during Fiscal 2022 and was primarily attributable to strong revenue growth throughout the year.

[0001571996-22-000009:mdna:264]
Cash provided by operating activities was $11.4 billion during Fiscal 2021 which was primarily driven by strong profitability, revenue growth and working capital dynamics as the impacts of COVID-19 began to normalize.  During Fiscal 2020, cash provided by operating activities was $9.3 billion which was attributable to improved profitability and working capital discipline.

[0001571996-22-000009:mdna:265]
Investing Activities — Investing activities primarily consist of cash used to fund capital expenditures for property, plant, and equipment, which includes equipment under DFS operating leases.  Additional activities include capitalized software development costs, strategic investments, acquisitions of businesses by VMware, and the maturities, sales, and purchases of investments.  During Fiscal 2022, cash provided by investing activities was $1.3 billion and was primarily driven by net cash proceeds from the divestiture of Boomi, partially offset by capital expenditures.

[0001571996-22-000009:mdna:266]
Cash used in investing activities was $460 million during Fiscal 2021 and was primarily driven by capital expenditures and cash used in acquisition of businesses by VMware, largely offset by net cash proceeds from the divestiture of RSA Security.  During Fiscal 2020, cash used in investing activities was $4.7 billion and was primarily driven by capital expenditures and acquisitions of businesses by VMware.

[0001571996-22-000009:mdna:267]
Financing Activities — Financing activities primarily consist of the proceeds and repayments of debt and cash used to repurchase common stock.  As a result of the VMware Spin-off, financing activities during Fiscal 2022 also include the net transfer of cash, cash equivalents, and restricted cash to VMware, and dividends paid by VMware to non-controlling interests.  Cash used in financing activities of $16.6 billion during Fiscal 2022 primarily consisted of debt repayments and associated debt

[0001571996-22-000009:mdna:268]
extinguishment fees, as well as our financing activities related to the VMware Spin-off.  The effect of these activities was partially offset by cash proceeds from the issuance of senior notes by Dell Technologies and VMware.

[0001571996-22-000009:mdna:269]
Cash used in financing activities of $6.0 billion during Fiscal 2021 primarily consisted of debt repayments and repurchases of common stock by our public subsidiaries, partially offset by cash proceeds from the issuances of senior notes by Dell Technologies and VMware.  During Fiscal 2020, cash used in financing activities of $4.6 billion primarily consisted of net debt repayments and repurchases of common stock by our public subsidiaries, primarily related to VMware Inc.’s acquisition of Pivotal Software, Inc.

[0001571996-22-000009:mdna:270]
DFS Cash Flow Impacts  — DFS offerings are initially funded through cash on hand at the time of origination, most of which is subsequently replaced with asset-backed financing.  For DFS offerings that qualify as sales-type leases, the initial funding of financing receivables is reflected as an impact to cash flows from operations and is largely subsequently offset by cash proceeds from financing.  For DFS operating leases, which have increased under the current lease accounting standard, the initial funding is classified as a capital expenditure and reflected as cash flows used in investing activities.  DFS new financing originations were $8.5 billion, $8.9 billion, and $8.5 billion during Fiscal 2022, Fiscal 2021, and Fiscal 2020, respectively.  As of January 28, 2022, DFS had $10.6 billion of total net financing receivables and $1.7 billion of equipment under DFS operating leases, net.

[0001571996-22-000009:mdna:271]
Capital Commitments

[0001571996-22-000009:mdna:272]
Capital Expenditures — During Fiscal 2022 and Fiscal 2021, we spent $2.8 billion and $2.1 billion, respectively, on property, plant, and equipment and capitalized software development costs, of which the funding of equipment under DFS operating leases was $1.0 billion and $0.7 billion, respectively.  Product demand, product mix, the use of contract manufacturers, and ongoing investments in operating and information technology infrastructure, influence the level and prioritization of our capital expenditures.  Aggregate capital expenditures for Fiscal 2023 are currently expected to total between $2.8 billion and $3.0 billion, of which approximately $0.8 billion of expenditures are expected to be applied to equipment under DFS operating leases and approximately $0.3 billion to capitalized software development costs.

[0001571996-22-000009:mdna:273]
Repurchases of Common Stock

[0001571996-22-000009:mdna:274]
Dell Technologies Common Stock Repurchases by Dell Technologies during Fiscal 2022

[0001571996-22-000009:mdna:275]
Effective as of September 23, 2021, our board of directors approved a stock repurchase program with no established expiration date under which we are authorized to repurchase up to $5 billion of shares of the Company’s Class C Common Stock.  During the fiscal year ended January 28, 2022, we repurchased approximately 12 million shares of Class C Common Stock for a total purchase price of approximately $659 million.

[0001571996-22-000009:mdna:276]
Dell Technologies Common Stock Repurchases by Dell Technologies during Fiscal 2021

[0001571996-22-000009:mdna:277]
During the fiscal year ended January 29, 2021, we repurchased approximately 6 million shares of Class C Common Stock for a total purchase price of approximately $240 million under a previous stock repurchase program that was subsequently suspended and, in Fiscal 2022, terminated.

[0001571996-22-000009:mdna:278]
Dividend Payments

[0001571996-22-000009:mdna:279]
On February 24, 2022, we announced that our board of directors has adopted a dividend policy under which we intend to pay quarterly cash dividends on its common stock, beginning in the first fiscal quarter of fiscal year 2023, at an initial rate of $0.33 per share per fiscal quarter.  We also announced that our board has declared the initial quarterly dividend under the policy in the amount of $0.33 per share, which will be payable on April 29, 2022 to the holders of record of all of the issued and outstanding shares of common stock as of the close of business on April 20, 2022.

[0001571996-22-000009:mdna:280]
The dividend policy and the declaration and payment of each quarterly cash dividend will be subject to the board’s continuing determination that the policy and the declaration of dividends thereunder are in the best interests of our stockholders and are in compliance with applicable law.  The board retains the power to modify, suspend, or cancel the dividend policy in any manner and at any time that it may deem necessary or appropriate.

[0001571996-22-000009:mdna:281]
67

[0001571996-22-000009:mdna:282]
Contractual Cash Obligations

[0001571996-22-000009:mdna:283]
The following table presents a summary of our contractual cash obligations as of January 28, 2022:

[0001571996-22-000009:mdna:284]
|  |  |  | Payments Due by Fiscal Year |
|  | Total |  | 2023 |  | 2024-2025 |  | 2026-2027 |  | Thereafter |
|  | (in millions) |
| Contractual cash obligations: |  |  |  |  |  |  |  |  |  |
| Principal payments on debt: |  |  |  |  |  |  |  |  |  |
| Core debt (a) | $ | 17,252 |  |  | $ | — |  |  | $ | 2,000 |  |  | $ | 7,250 |  |  | $ | 8,002 |  |
| DFS debt | 9,646 |  |  | 5,803 |  |  | 3,195 |  |  | 648 |  |  | — |  |
| Other | 337 |  |  | 25 |  |  | 289 |  |  | 21 |  |  | 2 |  |
| Total principal payments on debt | 27,235 |  |  | 5,828 |  |  | 5,484 |  |  | 7,919 |  |  | 8,004 |  |
| Interest | 9,181 |  |  | 1,068 |  |  | 1,896 |  |  | 1,539 |  |  | 4,678 |  |
| Purchase obligations | 6,278 |  |  | 5,623 |  |  | 433 |  |  | 160 |  |  | 62 |  |
| Operating leases | 1,092 |  |  | 286 |  |  | 373 |  |  | 217 |  |  | 216 |  |
| Tax obligations | 164 |  |  | 19 |  |  | 84 |  |  | 61 |  |  | — |  |
| Contractual cash obligations | $ | 43,950 |  |  | $ | 12,824 |  |  | $ | 8,270 |  |  | $ | 9,896 |  |  | $ | 12,960 |  |

[0001571996-22-000009:mdna:285]
____________________

[0001571996-22-000009:mdna:286]
(a)    Contractual cash obligations associated with core debt exclude DFS allocated debt.

[0001571996-22-000009:mdna:287]
Principal Payments on Debt — Our expected principal cash payments on borrowings are exclusive of discounts and premiums.  We have outstanding long-term notes with varying maturities.  For additional information about our debt, see Note 5 and Note 7 of the Notes to the Consolidated Financial Statements included in this report.

[0001571996-22-000009:mdna:288]
Interest —  Of the total cash obligations for interest presented in the table above, the amounts related to our DFS debt were expected to be $78 million in Fiscal 2023 and $40 million in Fiscal 2024-2025.  See Note 5 and Note 7 of the Notes to the Consolidated Financial Statements included in this report for further discussion of our debt and related interest expense.

[0001571996-22-000009:mdna:289]
Purchase Obligations — Purchase obligations are defined as contractual obligations to purchase goods or services that are enforceable and legally binding on us.  These obligations specify all significant terms, including fixed or minimum quantities to be purchased; fixed, minimum, or variable price provisions; and the approximate timing of the transaction.  Purchase obligations do not include contracts that may be canceled without penalty.

[0001571996-22-000009:mdna:290]
We utilize several suppliers to manufacture sub-assemblies for our products.  Our efficient supply chain management allows us to enter into flexible and mutually beneficial purchase arrangements with our suppliers in order to minimize inventory risk.  Consistent with industry practice, we acquire raw materials or other goods and services, including product components, by issuing to suppliers authorizations to purchase based on our projected demand and manufacturing needs.  These purchase orders are typically fulfilled within 30 days and are entered into during the ordinary course of business in order to establish best pricing and continuity of supply for our production.  Purchase orders are not included in purchase obligations, as they typically represent our authorization to purchase rather than binding purchase obligations.

[0001571996-22-000009:mdna:291]
Operating Leases — We lease property and equipment, manufacturing facilities, and office space under non-cancelable leases.  Certain of these leases obligate us to pay taxes, maintenance, and repair costs.  See Note 6 of the Notes to the Consolidated Financial Statements included in this report for additional information about our leasing transactions in which we are the lessee.

[0001571996-22-000009:mdna:292]
Tax Obligations — Tax obligations represent a one-time mandatory deemed repatriation tax on undistributed earnings of foreign subsidiaries.  Excluded from the table above are $1.2 billion in additional liabilities associated with uncertain tax positions as of January 28, 2022.  We are unable to reliably estimate the expected payment dates for any liabilities for uncertain tax positions.  See Note 12 of the Notes to the Consolidated Financial Statements included in this report for more information on these tax matters.

[0001571996-22-000009:mdna:293]
Market Conditions

[0001571996-22-000009:mdna:294]
We regularly monitor economic conditions and associated impacts on the financial markets and our business.  We consistently evaluate the financial health of our supplier base, carefully manage customer credit, diversify counterparty risk, and monitor the concentration risk of our cash and cash equivalents balances globally.  We routinely monitor our financial exposure to borrowers and counterparties.

[0001571996-22-000009:mdna:295]
We monitor credit risk associated with our financial counterparties using various market credit risk indicators such as credit ratings issued by nationally recognized credit rating agencies and changes in market credit default swap levels.  We perform periodic evaluations of our positions with these counterparties and may limit exposure to any one counterparty in accordance with our policies.  We monitor and manage these activities depending on current and expected market developments.

[0001571996-22-000009:mdna:296]
We use derivative instruments to hedge certain foreign currency exposures.  We use forward contracts and purchased options designated as cash flow hedges to protect against the foreign currency exchange rate risks inherent in our forecasted transactions denominated in currencies other than the U.S. dollar.  In addition, we primarily use forward contracts and may use purchased options to hedge monetary assets and liabilities denominated in a foreign currency.  See Note 8 of the Notes to the Consolidated Financial Statements included in this report for more information about our use of derivative instruments.

[0001571996-22-000009:mdna:297]
We are exposed to interest rate risk related to our variable-rate debt portfolio.  In the normal course of business, we follow established policies and procedures to manage this risk, including monitoring of our asset and liability mix.  As a result, we do not anticipate any material losses from interest rate risk.

[0001571996-22-000009:mdna:298]
The impact of any credit adjustments related to our use of counterparties on our Consolidated Financial Statements included in this report has been immaterial.

[0001571996-22-000009:mdna:299]
Summarized Guarantor Financial Information

[0001571996-22-000009:mdna:300]
As discussed in Note 7 of the Notes to the Consolidated Financial Statements included in this report, Dell International L.L.C. and EMC Corporation (the “Issuers”), both of which are wholly-owned subsidiaries of Dell Technologies, completed private offerings of multiple series of senior secured notes issued on June 1, 2016, March 20, 2019, and April 9, 2020 (the “First Lien Notes”).  In June 2021, the Issuers completed an exchange offer and issued $18.4 billion aggregate principal amount of registered first lien notes under the Securities Act of 1933 in exchange for the same principal amount and substantially identical terms of the First Lien Notes.  The aggregate principal amount of unregistered First Lien Notes remaining outstanding following the settlement of the exchange offer was approximately $0.1 billion.  Such registered first lien notes, together with the remaining unregistered First Lien Notes, were previously referred to as “First Lien Notes.”

[0001571996-22-000009:mdna:301]
The First Lien Notes were previously secured on a pari passu basis with the Senior Secured Credit Facilities, on a first-priority basis by substantially all of the tangible and intangible assets of the issuers and guarantors that secured obligations under the Senior Secured Credit Facilities, including pledges of all capital stock of the issuers, Dell, Inc. (“Dell”), a wholly-owned subsidiary of Dell Technologies, and certain wholly-owned material subsidiaries of the issuers and guarantors, subject to certain exceptions.

[0001571996-22-000009:mdna:302]
On November 1, 2021, the Company entered into a new senior unsecured revolving credit facility to replace the previous senior secured revolving credit facility.  Following the full redemption of the previously outstanding term loan facilities and replacement of the senior secured revolving credit facility, the credit agreement governing the former senior secured revolving credit facility was terminated.  Subsequent to the termination of the previous credit agreement, and upon Dell Technologies receiving investment grade credit ratings, the tangible and intangible assets of the issuers and guarantors that secured obligations under the Senior Secured Credit Facilities were released as collateral.  As a result, the First Lien Notes became fully unsecured and are collectively referred to as “Senior Notes.”  In addition, all guarantees by Dell’s subsidiaries were released.

[0001571996-22-000009:mdna:303]
Guarantees — The Senior Notes are guaranteed on a joint and several unsecured basis by Dell Technologies and its wholly-owned subsidiaries, Denali Intermediate, Inc., and Dell (collectively, the “Guarantors”).

[0001571996-22-000009:mdna:304]
Basis of Preparation of the Summarized Financial Information — The tables below are summarized financial information provided in conformity with Rule 13-01 of the SEC’s Regulation S-X.  The summarized financial information of the Issuers and Guarantors (collectively, the “Obligor Group”) is presented on a combined basis, excluding intercompany balances and transactions between entities in the Obligor Group.  To the extent material, the Obligor Group’s amounts due from, amounts due to and transactions with Non-Obligor Subsidiaries and the Related Party have been presented separately.  The Obligor Group’s investment balances in Non-Obligor Subsidiaries have been excluded.

[0001571996-22-000009:mdna:305]
The following table presents summarized results of operations information for the Obligor Group for the period indicated:

[0001571996-22-000009:mdna:306]
|  | Fiscal Year Ended |
|  | January 28, 2022 |
|  | (in millions) |
| Net revenue (a) | $ | 9,974 |  |
| Gross margin (b) | 3,948 |  |
| Operating income | 236 |  |
| Interest and other, net (c) | (3,776) |  |
| Loss before income taxes | (3,540) |  |
| Net loss attributable to Obligor Group | $ | (2,379) |  |

[0001571996-22-000009:mdna:307]
____________________

[0001571996-22-000009:mdna:308]
(a)   Includes net revenue from services provided and product sales to Non-Guarantor Subsidiaries of $1,061 million and $185 million, respectively.

[0001571996-22-000009:mdna:309]
(b)   Includes cost of net revenue from resale of solutions purchased from Non-Guarantor Subsidiaries and the Related Party of $1,132 million and $500 million, respectively.  Includes costs of net revenue from shared services provided by Non-Guarantor Subsidiaries of $793 million.

[0001571996-22-000009:mdna:310]
(c)   Includes interest expense on inter-company loan payables of $1,030 million and other expenses from services provided by Non-Guarantor Subsidiaries of $11 million.

[0001571996-22-000009:mdna:311]
The following table presents summarized balance sheet information for the Obligor Group as of the dates indicated:

[0001571996-22-000009:mdna:312]
|  | January 28, 2022 |  |  |
|  | (in millions) |
| ASSETS |
| Current assets | $ | 3,106 |  |  |  |
| Intercompany receivables | 988 |  |  |  |
| Due from related party, net | 59 |  |  |  |
| Total current assets | 4,153 |  |  |  |
| Due from related party, net | 710 |  |  |  |
| Goodwill and intangible assets | 15,399 |  |  |  |
| Other non-current assets | 2,810 |  |  |  |
| Total assets | $ | 23,072 |  |  |  |
| LIABILITIES |
| Current liabilities | $ | 4,625 |  |  |  |
| Due to related party | 192 |  |  |  |
| Total current liabilities | 4,817 |  |  |  |
| Long-term debt | 17,001 |  |  |  |
| Intercompany loan payables | 37,509 |  |  |  |
| Other non-current liabilities | 3,473 |  |  |  |
| Total liabilities | $ | 62,800 |  |  |  |

[0001571996-22-000009:mdna:313]
71

[0001571996-22-000009:mdna:314]
Critical Accounting Estimates

[0001571996-22-000009:mdna:315]
We prepare our financial statements in conformity with GAAP, which requires certain estimates, assumptions, and judgments to be made that may affect our Consolidated Statements of Financial Position and Consolidated Statements of Income.  Accounting policies that have a significant impact on our Consolidated Financial Statements are described in Note 2 of the Notes to the Consolidated Financial Statements included in this report.  The accounting estimates and assumptions discussed in this section are those that we consider to be the most critical.  We consider an accounting policy to be critical if the nature of the estimate or assumption is subject to a material level of judgment and if changes in those estimates or assumptions are reasonably likely to materially impact our Consolidated Financial Statements.  We have discussed the development, selection, and disclosure of our critical accounting policies with the Audit Committee of our Board of Directors.

[0001571996-22-000009:mdna:316]
Revenue Recognition — We sell a wide portfolio of products and services offerings to our customers.  Our agreements have varying terms and conditions depending on the goods and services being sold, the rights and obligations conveyed, and the legal jurisdiction of the arrangement.

[0001571996-22-000009:mdna:317]
Our contracts with customers often include multiple performance obligations for various distinct goods and services such as hardware, software licenses, support and maintenance agreements, and other service offerings and solutions.  We use significant judgment to assess whether these promises are distinct performance obligations that should be accounted for separately.  In certain hardware solutions, the hardware is highly interdependent on, and interrelated with, the embedded software.  In these offerings, the hardware and software licenses are accounted for as a single performance obligation.

[0001571996-22-000009:mdna:318]
The transaction price reflects the amount of consideration to which we expect to be entitled in exchange for transferring goods or services to the customer.  If the consideration promised in a contract includes a variable amount, we estimate the amount to which we expect to be entitled using either the expected value or most likely amount method.  Estimates are updated each reporting period as the variability is resolved or if additional information becomes available.  Generally, volume discounts, rebates, and sales returns reduce the transaction price.  When we determine the transaction price, we only include amounts that are not subject to significant future reversal.

[0001571996-22-000009:mdna:319]
When a contract includes multiple performance obligations, the transaction price is allocated to each performance obligation in proportion to the standalone selling price (“SSP”) of each performance obligation.

[0001571996-22-000009:mdna:320]
Judgment is required when determining the SSP of our performance obligations.  If the observable price is available, we utilize that price for the SSP.  If the observable price is not available, the SSP must be estimated.  We estimate SSP by considering multiple factors, including, but not limited to, pricing practices, internal costs, and profit objectives as well as overall market conditions, which include geographic or regional specific factors, competitive positioning, and competitor actions.  SSP for our performance obligations is periodically reassessed.

[0001571996-22-000009:mdna:321]
Goodwill and Indefinite-Lived Intangible Assets Impairment Assessments — Goodwill and indefinite-lived intangible assets are tested for impairment annually during the third fiscal quarter and whenever events or circumstances may indicate that an impairment has occurred.

[0001571996-22-000009:mdna:322]
To determine whether goodwill is impaired, we first assess certain qualitative factors.  Qualitative factors that may be assessed include but are not limited to macroeconomic conditions, industry and market considerations, cost factors, overall financial performance, or other relevant company-specific events.  Based on this assessment, if it is determined more likely than not that the fair value of a goodwill reporting unit is less than its carrying amount, we perform the quantitative analysis of the goodwill impairment test.  Alternatively, we may bypass the qualitative assessment and perform a quantitative impairment test.

[0001571996-22-000009:mdna:323]
Significant judgment is exercised in the identification of goodwill reporting units, assignment of assets and liabilities to goodwill reporting units, assignment of goodwill to reporting units, and determination of the fair value of each goodwill reporting unit.  The fair value of each of our goodwill reporting units is generally estimated using a combination of public company multiples and discounted cash flow methodologies, and then compared to the carrying value of each goodwill reporting unit.  The discounted cash flow and public company multiples methodologies require significant judgment, including estimation of future revenues, gross margins, and operating expenses, which are dependent on internal forecasts, current and anticipated economic conditions and trends, selection of market multiples through assessment of the reporting unit’s performance relative to peer competitors, the estimation of the long-term revenue growth rate and discount rate of our business, and the determination of our weighted average cost of capital.  Changes in these estimates and assumptions could materially affect the fair value of the goodwill reporting unit, potentially resulting in a non-cash impairment charge.

[0001571996-22-000009:mdna:324]
The fair value of the indefinite-lived intangible assets is generally estimated using discounted cash flow methodologies.  The discounted cash flow methodologies require significant judgment, including estimation of future revenue, the estimation of the long-term revenue growth rate of our business, and the determination of the weighted average cost of capital and royalty rates.  Changes in these estimates and assumptions could materially affect the fair value of the indefinite-lived intangible assets, potentially resulting in a non-cash impairment charge.

[0001571996-22-000009:mdna:325]
Income Taxes — We are subject to income tax in the United States and numerous foreign jurisdictions.  Significant judgments are required in determining the consolidated provision for income taxes.  We calculate a provision for income taxes using the asset and liability method, under which deferred tax assets and liabilities are recognized by identifying the temporary differences arising from the different treatment of items for tax and accounting purposes.  We account for the tax impact of including Global Intangible Low-Taxed Income (GILTI) in U.S. taxable income as a period cost.  We provide related valuation allowances for deferred tax assets, where appropriate.  Significant judgment is required in determining any valuation allowance against deferred tax assets.  In assessing the need for a valuation allowance, we consider all available evidence for each jurisdiction, including past operating results, estimates of future taxable income, and the feasibility of ongoing tax planning strategies.  In the event we determine that all or part of the net deferred tax assets are not realizable in the future, we will make an adjustment to the valuation allowance that would be charged to earnings in the period such determination is made.

[0001571996-22-000009:mdna:326]
Significant judgment is also required in evaluating our uncertain tax positions.  Although we believe our tax return positions are sustainable, we recognize tax benefits from uncertain tax positions in the financial statements only when it is more likely than not that the positions will be sustained upon examination, including resolution of any related appeals or litigation processes, based on the technical merits and a consideration of the relevant taxing authority’s administrative practices and precedents.  To the extent that the final tax outcome of these matters is different from the amounts recorded, such differences will impact the provision for income taxes in the period in which such determination is made.  The provision for income taxes includes the impact of reserve provisions and changes to reserves that are considered appropriate, as well as the related net interest and penalties.  We believe we have provided adequate reserves for all uncertain tax positions.

[0001571996-22-000009:mdna:327]
Legal and Other Contingencies — The outcomes of legal proceedings and claims brought against us are subject to significant uncertainty.  An estimated loss from a loss contingency such as a legal proceeding or claim is accrued by a charge to income if it is probable that an asset has been impaired or a liability has been incurred and the amount of the loss can be reasonably estimated.  In determining whether a loss should be accrued we evaluate, among other factors, the degree of probability of an unfavorable outcome and the ability to make a reasonable estimate of the amount of loss.  Changes in these factors could materially impact our consolidated financial statements.

[0001571996-22-000009:mdna:328]
Inventories — We state our inventory at the lower of cost or net realizable value.  We record a write-down for inventories of components and products, including third-party products held for resale, which have become obsolete or are in excess of anticipated demand or net realizable value.  We perform a detailed review of inventory each fiscal quarter that considers multiple factors, including demand forecasts, product life cycle status, product development plans, current sales levels, product pricing, and component cost trends.  The industries in which we compete are subject to demand changes.  If future demand or market conditions for our products are less favorable than forecasted or if unforeseen technological changes negatively impact the utility of component inventory, we may be required to record additional write-downs, which would adversely affect our gross margin.

[0001571996-22-000009:mdna:329]
Recently Issued Accounting Pronouncements

[0001571996-22-000009:mdna:330]
See Note 2 of the Notes to the Consolidated Financial Statements included in this report for a summary of recently issued accounting pronouncements that are applicable to our Consolidated Financial Statements.
