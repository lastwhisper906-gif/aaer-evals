# DELL notes — 0001571996-22-000009


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001571996-22-000009:notes:1]
DOCUMENTS INCORPORATED BY REFERENCE

[0001571996-22-000009:notes:2]
The information required by Part III of this report, to the extent not set forth herein, is incorporated by reference from the registrant’s proxy statement relating to its annual meeting of stockholders to be held in 2022.  The proxy statement will be filed with the Securities and Exchange Commission within 120 days after the end of the fiscal year to which this report relates.


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001571996-22-000009:notes:3]
Basis of Presentation — These Consolidated Financial Statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“GAAP”)


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001571996-22-000009:notes:4]
DESCRIPTION OF BUSINESS AND SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES 
Description of Business — The Company is a leading global end-to-end technology provider that offers a broad range of comprehensive and integrated solutions, which include servers and networking products, storage products, cloud solutions products, desktops, notebooks, services, software, and third-party software and peripherals.

[0001571996-22-000009:notes:5]
The Company’s fiscal year is the 52- or 53-week period ending on the Friday nearest January 31.  The fiscal years ended January 28, 2022, January 29, 2021, and January 31, 2020 were 52-week periods.

[0001571996-22-000009:notes:6]
Principles of Consolidation — These Consolidated Financial Statements include the accounts of Dell Technologies and its wholly-owned subsidiaries, as well as the accounts of Secureworks, which, as indicated above, is majority-owned by Dell Technologies and VMware through the date of the VMware Spin-off.  All intercompany transactions have been eliminated.

[0001571996-22-000009:notes:7]
The Company also consolidates Variable Interest Entities ("VIEs") where it has been determined that the Company is the primary beneficiary of the applicable entities’ operations.  For each VIE, the primary beneficiary is the party that has both the power to direct the activities that most significantly impact the VIE's economic performance and the obligation to absorb losses or the right to receive benefits of the VIE that could potentially be significant to such VIE.  In evaluating whether the Company is the primary beneficiary of each entity, the Company evaluates its power to direct the most significant activities of the VIE by considering the purpose and design of each entity and the risks each entity was designed to create and pass through to its respective variable interest holders.  The Company also evaluates its economic interests in each of the VIEs.  See Note 5 of the Notes to the Consolidated Financial Statements for more information regarding consolidated VIEs.

[0001571996-22-000009:notes:8]
Use of Estimates — The preparation of financial statements in accordance with GAAP requires management to make estimates and assumptions that affect the amounts reported in the Consolidated Financial Statements and the accompanying Notes.  Management has considered the actual and potential impacts of the coronavirus disease 2019 (“COVID-19”) pandemic on the Company’s critical and significant accounting estimates.  Actual results could differ materially from those estimates.

[0001571996-22-000009:notes:9]
Cash and Cash Equivalents — All highly liquid investments, including credit card receivables due from banks, with original maturities of 90 days or less at date of purchase, are reported at fair value and are considered to be cash equivalents.  All other investments not considered to be cash equivalents are separately categorized as investments.

[0001571996-22-000009:notes:10]
Investments — The Company has strategic investments in equity securities as well as investments in fixed-income debt securities.  All equity and other securities are recorded as long-term investments in the Consolidated Statements of Financial Position.

[0001571996-22-000009:notes:11]
Strategic investments in marketable equity and other securities are recorded at fair value based on quoted prices in active markets.  Strategic investments in non-marketable equity and other securities without readily determinable fair values are recorded at cost, less impairment, and are adjusted for observable price changes.  Fair value measurements and impairments for strategic investments are recognized in interest and other, net in the Consolidated Statements of Income.  In evaluating equity investments without readily determinable fair values for impairment or observable price changes, the Company uses inputs that include pre- and post-money valuations of recent financing events and the impact of those events on its fully diluted ownership percentages, as well as other available information regarding the issuer’s historical and forecasted performance.

[0001571996-22-000009:notes:12]
Fixed-income debt securities are carried at amortized cost.  The Company intends to hold the fixed-income debt securities to maturity.

[0001571996-22-000009:notes:13]
Allowance for Expected Credit Losses — The Company recognizes an allowance for losses on accounts receivable in an amount equal to the current expected credit losses.  The estimation of the allowance is based on an analysis of historical loss experience, current receivables aging, and management’s assessment of current conditions and reasonable and supportable expectation of future conditions, as well as an assessment of specific identifiable customer accounts considered at risk or uncollectible.  The Company assesses collectibility by pooling receivables where similar characteristics exist and evaluates receivables individually when specific customer balances no longer share those risk characteristics and are considered at risk or uncollectible.  The expense associated with the allowance for expected credit losses is recognized in selling, general, and administrative expenses.

[0001571996-22-000009:notes:14]
The Company’s policy for estimating this allowance is based on an expected loss model and reflects the adoption of the accounting standard related to current expected credit losses in the fiscal year ended January 29, 2021.  See “Recently Adopted Accounting Pronouncements” in this Note for more information.  In prior periods, this allowance was estimated using an incurred loss model, which did not require the consideration of forward-looking information and conditions in the reserve calculation.

[0001571996-22-000009:notes:15]
Accounting for Operating Leases as a Lessee — In its ordinary course of business, the Company enters into leases as a lessee for office buildings, warehouses, employee vehicles, and equipment.  The Company determines if an arrangement is a lease or contains a lease at inception.  Operating leases result in the recognition of right of use (“ROU”) assets and lease liabilities on the Consolidated Statements of Financial Position.  ROU assets represent the right to use an underlying asset for the lease term and lease liabilities represent the obligation to make lease payments arising from the lease, measured on a discounted basis.  At lease commencement, the lease liability is measured at the present value of the lease payments over the lease term.  The operating lease ROU asset equals the lease liability adjusted for any initial direct costs, prepaid or deferred rent, and lease incentives.  The Company uses the implicit rate when readily determinable.  As most of the leases do not provide an implicit rate, the Company uses its incremental borrowing rate based on the information available at the commencement date to determine the present value of lease payments.

[0001571996-22-000009:notes:16]
The lease term may include options to extend or to terminate the lease that the Company is reasonably certain to exercise.  .  The Company has elected not to record leases with an initial term of 12 months or less on the Consolidated Statements of Financial Position.  Lease expense is recognized on a straight-line basis over the lease term in most instances.  The Company does not generate material sublease income and has no material related party leases.  The Company’s lease agreements do not contain any material residual value guarantees or material restrictive covenants.

[0001571996-22-000009:notes:17]
The Company’s office building agreements contain costs such as common area maintenance and other executory costs that may be either fixed or variable in nature.  Variable lease costs are expensed as incurred.  The Company combines lease and non-lease components, including fixed common area and other maintenance costs, in calculating the ROU assets and lease liabilities for its office buildings and employee vehicles.  Under certain service agreements with third-party logistics providers, the Company directs the use of the inventory within the warehouses and, therefore, controls the assets.  The warehouses and some of the equipment used are considered embedded leases.  The Company accounts for the lease and non-lease components separately.  The lease components consist of the warehouses and some of the equipment, such as conveyor belts.  The non-lease components consist of services and other shared equipment, such as material handling and transportation.  The Company allocates the consideration to the lease and non-lease components using their relative standalone values.  See Note 6 of the Notes to the Consolidated Financial Statements for additional information.

[0001571996-22-000009:notes:18]
Accounting for Leases as a Lessor — The Company’s wholly-owned subsidiary Dell Financial Services and its affiliates (“DFS”) act as a lessor to provide equipment financing to customers through a variety of lease arrangements (“DFS leases”).  The Company’s leases are classified as sales-type leases, direct financing leases, or operating leases.  Direct financing leases are immaterial.  Leases that commenced prior to the adoption of the current lease standard were not reassessed or restated pursuant to the practical expedients elected and continue to be accounted for under previous lease accounting guidance.

[0001571996-22-000009:notes:19]
The Company also offers alternative payment structures and “as-a-Service” offerings that are assessed to determine whether an embedded lease arrangement exists.  The Company accounts for those contracts as a lease arrangement if it is determined that the contract contains an identified asset and that control of that asset has transferred to the customer.

[0001571996-22-000009:notes:20]
When a contract includes lease and non-lease components, the Company allocates consideration under the contract to each component based on relative standalone selling price and subsequently assesses lease classification for each lease component within a contract.  DFS provides lessees with the option to extend the lease or purchase the underlying asset at the end of the lease term, which is considered when evaluating lease classification.  In general, DFS’s lease arrangements do not have variable payment terms and are typically non-cancelable.

[0001571996-22-000009:notes:21]
On commencement of sales-type leases, the Company recognizes profit up-front, and amounts due from the customer under the lease contract are recognized as financing receivables on the Consolidated Statements of Financial Position.  Interest income is recognized as net product revenue over the term of the lease based on the effective interest method.  The Company has elected not to include sales and other taxes collected from the lessee as part of lease revenue.

[0001571996-22-000009:notes:22]
All other leases that do not meet the definition of a sales-type lease or direct financing lease are classified as operating leases.  The underlying asset in an operating lease arrangement is carried at depreciated cost as “Equipment under operating leases” within Property, plant, and equipment, net on the Consolidated Statements of Financial Position.  Depreciation is calculated using the straight-line method over the term of the underlying lease contract and is recognized as Cost of net revenue.  The depreciable basis is the original cost of the equipment less the estimated residual value of the equipment at the end of the lease term.  The residual value is based upon estimates of the value of the equipment at the end of the lease term using historical studies, industry data, and future value-at-risk demand valuation methods.  The Company recognizes operating lease income to product revenue generally on a straight-line basis over the lease term and expenses deferred initial direct costs on the same basis.  The Company recognizes variable operating lease income to product revenue generally as earned.  Impairment of equipment under operating leases is assessed on the same basis as other long-lived assets.

[0001571996-22-000009:notes:23]
Financing Receivables — Financing receivables are presented net of allowance for losses and consist of customer receivables and residual interest.  Gross customer receivables include amounts due from customers under revolving loans, fixed-term loans, fixed-term sales-type or direct financing leases, and accrued interest.  The Company has two portfolios, consisting of (i) fixed-term leases and loans and (ii) revolving loans, and assesses risk at the portfolio level to determine the appropriate allowance levels.  The portfolio segments are further segregated into classes based on products, customer type, and credit risk evaluation: (i) Revolving — Dell Preferred Account (“DPA”); (ii) Revolving — Dell Business Credit (“DBC”); and (iii) Fixed-term — Consumer and Commercial.  Fixed-term leases and loans are offered to qualified small and medium-sized businesses, large commercial accounts, governmental organizations, and educational entities.  Fixed-term loans are also offered to qualified individual consumers.  Revolving loans are offered under private label credit financing programs.  The DPA revolving loan programs are primarily offered to individual consumers and the DBC revolving loan programs are primarily offered to small and medium-sized business customers.

[0001571996-22-000009:notes:24]
The Company retains a residual interest in equipment leased under its fixed-term lease programs.  The amount of the residual interest is established at the inception of the lease based upon estimates of the value of the equipment at the end of the lease term using historical studies, industry data, and future value-at-risk demand valuation methods.

[0001571996-22-000009:notes:25]
Allowance for Financing Receivables Losses — The Company recognizes an allowance for financing receivable losses, including both the lease receivable and unguaranteed residual, in an amount equal to the probable losses net of recoveries.  The allowance for financing receivable losses on the lease receivable is determined based on various factors, including lifetime expected losses determined using macroeconomic forecast assumptions and management judgments applicable to and through the expected life of the portfolios as well as past due receivables, receivable type, and customer risk profile.  Both fixed and revolving financing receivable loss rates are affected by macroeconomic conditions, including the level of gross domestic product (“GDP”) growth, the level of commercial capital equipment investment, unemployment rates, and the credit quality of the borrower.

[0001571996-22-000009:notes:26]
Generally, expected credit losses as a result of residual value risk on equipment under lease are not considered to be significant primarily because of the existence of a secondary market with respect to the equipment.  The lease agreement also defines applicable return conditions and remedies for non-compliance to ensure that the leased equipment will be in good operating condition upon return.  Model changes and updates, as well as market strength and product acceptance, are monitored and adjustments are made to residual values in accordance with the significance of any such changes.

[0001571996-22-000009:notes:27]
When an account is deemed to be uncollectible, customer account principal and interest are charged off to the allowance for losses.  While the Company does not generally place financing receivables on non-accrual status during the delinquency period, accrued interest is included in the allowance for loss calculation and, therefore, the Company is adequately reserved in the event of charge off.  Recoveries on receivables previously charged off as uncollectible are recorded to the allowance for financing receivables losses.  The expense associated with the allowance for financing receivables losses is recognized as cost of net revenue.

[0001571996-22-000009:notes:28]
Asset Securitization — The Company transfers certain U.S. and European customer loan and lease payments and associated equipment to Special Purpose Entities (“SPEs”) that meet the definition of a Variable Interest Entity (“VIE”) and are consolidated into the Consolidated Financial Statements.  These SPEs are bankruptcy-remote legal entities with separate assets and liabilities.  The purpose of the SPEs is to facilitate the funding of customer loan and lease payments and associated equipment in the capital markets.  Some of these SPEs have entered into financing arrangements with multi-seller conduits that, in turn, issue asset-backed debt securities in the capital markets.  The asset securitizations in the SPEs are accounted for as secured borrowings.

[0001571996-22-000009:notes:29]
Inventories — Inventories are stated at the lower of cost or net realizable value, with cost being determined on a first-in, first-out basis.  Adjustments to reduce the cost of inventory to its net realizable value are made, if required, for estimated excess, obsolescence, or impaired balances.  At the point of the loss recognition, a new, lower cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in the newly established cost basis.

[0001571996-22-000009:notes:30]
Property, Plant, and Equipment — Property, plant, and equipment are carried at depreciated cost.  Depreciation is determined using the straight-line method over the shorter of the estimated useful lives of the assets or the lease term, as applicable.  The estimated useful lives of the Company’s property, plant, and equipment are generally as follows:

[0001571996-22-000009:notes:31]
|  | Estimated Useful Life |
| Computer equipment | 3-5 years |
| Equipment under operating leases | Term of underlying lease contract |
| Buildings and building improvements | 10-30 years or term of underlying land lease |
| Leasehold improvements | 5 years or contract term |
| Machinery and equipment | 3-5 years |

[0001571996-22-000009:notes:32]
Gains or losses related to retirements or dispositions of fixed assets are recognized in the period during which the retirement or disposition occurs.

[0001571996-22-000009:notes:33]
Capitalized Software Development Costs — Software development costs related to the development of new product offerings are capitalized subsequent to the establishment of technological feasibility, which is demonstrated by the completion of a detailed program design or working model, if no program design is completed.  The Company amortizes capitalized costs on a straight-line basis over the estimated useful lives of the products, which generally range from two to four years.

[0001571996-22-000009:notes:34]
As of January 28, 2022 and January 29, 2021, capitalized software development costs were $672 million and $610 million, respectively, and are included in other non-current assets, net in the accompanying Consolidated Statements of Financial Position.  Amortization expense for the fiscal years ended January 28, 2022, January 29, 2021, and January 31, 2020 was $263 million, $315 million, and $273 million, respectively.

[0001571996-22-000009:notes:35]
The Company capitalizes certain internal and external costs to acquire or create internal use software which are incurred subsequent to the completion of the preliminary project stage.  Development costs are generally amortized on a straight-line basis over five years.  Costs associated with maintenance and minor enhancements to the features and functionality of the Company’s internal use software, including its website, are expensed as incurred.

[0001571996-22-000009:notes:36]
Impairment of Long-Lived Assets — The Company reviews long-lived assets for impairment when events or changes in circumstances indicate the carrying amount of an asset may not be recoverable.  The Company assesses the recoverability of the assets based on the undiscounted future cash flows expected from the use and eventual disposition of the asset.  If the carrying amount of the asset is determined not to be recoverable, a write-down to fair value is recorded.  Fair values are determined based on quoted market values, discounted cash flows, or external appraisals, as applicable.  Long-lived assets to be disposed of are reported at the lower of carrying amount or fair value less costs to sell.

[0001571996-22-000009:notes:37]
Intangible Assets Including Goodwill — Identifiable intangible assets with finite lives are amortized over their estimated useful lives.  Indefinite-lived intangible assets are not amortized.  Definite-lived intangible assets are reviewed for impairment when events and circumstances indicate the asset may be impaired.  Goodwill and indefinite-lived intangible assets are tested for impairment annually during the third fiscal quarter and whenever events or circumstances indicate that an impairment may have occurred.

[0001571996-22-000009:notes:38]
Foreign Currency Translation — The majority of the Company’s international sales are made by international subsidiaries, some of which have the U.S. Dollar as their functional currency.  The Company’s subsidiaries that do not use the U.S. Dollar as their functional currency translate assets and liabilities at current exchange rates in effect at the balance sheet date.  Revenue and expenses from these international subsidiaries are translated using either the monthly average exchange rates in effect for the period in which the activity was recognized or the specific daily exchange rate associated with the date the transactions actually occur.  Foreign currency translation adjustments are included as a component of accumulated other comprehensive income (loss) (“AOCI”) in stockholders’ equity (deficit).

[0001571996-22-000009:notes:39]
Local currency transactions of international subsidiaries that have the U.S. Dollar as their functional currency are remeasured into U.S. Dollars using the current rates of exchange for monetary assets and liabilities and historical rates of exchange for nonmonetary assets and liabilities.  Gains and losses from remeasurement of monetary assets and liabilities are included in interest and other, net on the Consolidated Statements of Income.  See Note 20 of the Notes to the Consolidated Financial Statements for amounts recognized from remeasurement during the periods presented.

[0001571996-22-000009:notes:40]
Hedging Instruments — The Company uses derivative financial instruments, primarily forward contracts, options, and swaps, to hedge certain foreign currency and interest rate exposures.  The relationships between hedging instruments and hedged items, as well as the risk management objectives and strategies for undertaking hedge transactions, are formally documented.  The Company does not use derivatives for speculative purposes.  All derivative instruments are recognized as either assets or liabilities in the Consolidated Statements of Financial Position and are measured at fair value.

[0001571996-22-000009:notes:41]
The Company’s hedge portfolio includes non-designated derivatives and derivatives designated as cash flow hedges.  For derivative instruments that are designated as cash flow hedges, the Company assesses hedge effectiveness at the onset of the hedge, then performs qualitative assessments at regular intervals throughout the life of the derivative.  The gain or loss on cash flow hedges is recorded in accumulated other comprehensive income (loss), as a separate component of stockholders’ equity (deficit), and reclassified into earnings in the period during which the hedged transaction is recognized in earnings.  For derivatives that are not designated as hedges or do not qualify for hedge accounting treatment, the Company recognizes the change in the instrument’s fair value currently in earnings as a component of interest and other, net.

[0001571996-22-000009:notes:42]
Cash flows from derivative instruments are presented in the same category on the Consolidated Statements of Cash Flows as the cash flows from the underlying hedged items.  See Note 8 of the Notes to the Consolidated Financial Statements for a description of the Company’s derivative financial instrument activities.

[0001571996-22-000009:notes:43]
Revenue Recognition — The Company sells a wide portfolio of products and services to its customers.  The Company’s agreements have varying requirements depending on the goods and services being sold, the rights and obligations conveyed, and the legal jurisdiction of the arrangement.

[0001571996-22-000009:notes:44]
Revenue is recognized for these arrangements based on the following five steps:

[0001571996-22-000009:notes:45]
(1)    Identify the contract with a customer.  The Company evaluates facts and circumstances regarding sales transactions in order to identify contracts with its customers.  An agreement must meet all of the following criteria to qualify as a contract eligible for revenue recognition under the model:  (i) the contract must be approved by all parties who are committed to perform their respective obligations; (ii) each party’s rights regarding the goods and services to be transferred to the customer can be identified; (iii) the payment terms for the goods and services can be identified; (iv) the customer has the ability and intent to pay and it is probable that the Company will collect substantially all of the consideration to which it will be entitled; and (v) the contract must have commercial substance.  Judgment is used in determining the customer’s ability and intent to pay, which is based upon various factors, including the customer’s historical payment experience or customer credit and financial information.

[0001571996-22-000009:notes:46]
(2)    Identify the performance obligations in the contract.  The Company’s contracts with customers often include the promise to transfer multiple goods and services to the customer.  Distinct promises within a contract are referred to as “performance obligations” and are accounted for as separate units of account.  The Company assesses whether each promised good or service is distinct for the purpose of identifying the performance obligations in the contract.  This assessment involves subjective determinations and requires management to make judgments about the individual promised goods or services and whether such goods or services are separable from the other aspects of the contractual relationship.  Promised goods and services are considered distinct provided that: (i) the customer can benefit from the good or service either on its own or together with other resources that are readily available to the customer (that is, the good or service is capable of being distinct); and (ii) the Company’s promise to transfer the good or service to the customer is separately identifiable from other promises in the contract (that is, the promise to transfer the good or service is distinct within the context of the contract).  The Company’s performance obligations include various distinct goods and services such as hardware, software licenses, support and maintenance agreements, and other service offerings and solutions.  Promised goods and services are explicitly identified in the Company’s contracts and may be sold on a standalone basis or bundled as part of a combined solution.  In certain hardware solutions, the hardware is highly interdependent on, and interrelated with, the embedded software.  In these offerings, the hardware and software licenses are accounted for as a single performance obligation.

[0001571996-22-000009:notes:47]
(3)    Determine the transaction price.  The transaction price reflects the amount of consideration to which the Company expects to be entitled in exchange for transferring goods or services to the customer.  If the consideration promised in a contract includes a variable amount, the Company estimates the amount to which it expects to be entitled using either the expected value or most likely amount method.  Generally, volume discounts, rebates, and sales returns reduce the transaction price.  In determining the transaction price, the Company only includes amounts that are not subject to significant future reversal.

[0001571996-22-000009:notes:48]
(4)    Allocate the transaction price to performance obligations in the contract.  When a contract includes multiple performance obligations, the transaction price is allocated to each performance obligation in an amount that depicts the consideration to which the Company expects to be entitled in exchange for transferring the promised goods or services.  For contracts with multiple performance obligations, the transaction price is allocated in proportion to the standalone selling price (“SSP”) of each performance obligation.

[0001571996-22-000009:notes:49]
The best evidence of SSP is the observable price of a good or service when the Company sells that good or service separately in similar circumstances to similar customers.  If a directly observable price is available, the Company will utilize that price for the SSP.  If a directly observable price is not available, the SSP must be estimated.  The Company estimates SSP by considering multiple factors, including, but not limited to, pricing practices, internal costs, and profit objectives as well as overall market conditions, which include geographic or regional specific factors, competitive positioning, and competitor actions.

[0001571996-22-000009:notes:50]
(5)    Recognize revenue when (or as) the performance obligation is satisfied.  Revenue is recognized when obligations under the terms of the contract with the Company’s customer are satisfied.  Revenue is recognized either over time or at a point in time, depending on when the underlying products or services are transferred to the customer.  Revenue is recognized at a point in time for products upon transfer of control.  Revenue is recognized over time for support and deployment services, software support, Software-as-a-Service (“SaaS”), and Infrastructure-as-a-Service (“IaaS”).  Revenue is recognized either over time or at a point in time for professional services and training depending on the nature of the offering to the customer.

[0001571996-22-000009:notes:51]
The Company reports revenue net of any revenue-based taxes assessed by governmental authorities that are imposed on and concurrently with specific revenue-producing transactions.

[0001571996-22-000009:notes:52]
The Company has elected the following practical expedients:

[0001571996-22-000009:notes:53]
•The Company does not account for significant financing components if the period between revenue recognition and when the customer pays for the product or service will be one year or less.

[0001571996-22-000009:notes:54]
•The Company recognizes revenue equal to the amount it has a right to invoice when the amount corresponds directly with the value to the customer of the Company’s performance to date.

[0001571996-22-000009:notes:55]
•The Company does not account for shipping and handling activities as a separate performance obligation, but rather as an activity performed to transfer the promised good.

[0001571996-22-000009:notes:56]
The following summarizes the nature of revenue recognized and the manner in which the Company accounts for sales transactions.

[0001571996-22-000009:notes:57]
Products

[0001571996-22-000009:notes:58]
Product revenue consists of revenue from sales of hardware products, including notebooks and desktop PCs, servers, storage hardware, and other hardware-related devices, as well as revenue from software license sales, including non-essential software applications and third-party software licenses.

[0001571996-22-000009:notes:59]
Revenue from sales of hardware products is recognized when control has transferred to the customer, which typically occurs when the hardware has been shipped to the customer, risk of loss has transferred to the customer, the Company has a present right to payment, and customer acceptance has been satisfied.  Customer acceptance is satisfied if acceptance is obtained from the customer, if all acceptance provisions lapse, or if the Company has evidence that all acceptance provisions will be, or have been, satisfied.  Revenue from software license sales is generally recognized when control has transferred to the customer, which is typically upon shipment, electronic delivery, or when the software is available for download by the customer.  For certain software arrangements in which the customer is granted a right to additional unspecified future software licenses, the Company’s promise to the customer is considered a stand-ready obligation in which the transfer of control and revenue recognition will occur over time.

[0001571996-22-000009:notes:60]
Services

[0001571996-22-000009:notes:61]
Services revenue consists of revenue from sales of support services, including hardware support that extends beyond the Company’s standard warranties, software maintenance, and installation; professional services; training; SaaS; and IaaS.  Revenue associated with undelivered performance obligations is deferred and recognized when or as control is transferred to the customer.  Revenue from fixed-price support or maintenance contracts sold for both hardware and software is recognized on a straight-line basis over the period of performance because the Company is required to provide services at any given time.  Other services revenue is recognized when the Company performs the services and the customer receives and consumes the benefits.

[0001571996-22-000009:notes:62]
Other

[0001571996-22-000009:notes:63]
Revenue from leasing arrangements is not subject to the revenue standard for contracts with customers and remains separately accounted for under lease accounting guidance.  The Company records operating lease rental revenue as product revenue on a straight-line basis over the lease term.  The Company records revenue from the sale of equipment under sales-type leases as product revenue in an amount equal to the present value of minimum lease payments at the inception of the lease.  Sales-type leases also produce financing income, which is included in product net revenue in the Consolidated Statements of Income and is recognized at effective rates of return over the lease term.  The Company also offers qualified customers fixed-term loans and revolving credit lines for the purchase of products and services offered by the Company.  Financing income attributable to these loans is recognized in product net revenue on an accrual basis.

[0001571996-22-000009:notes:64]
Principal versus Agent — For transactions that involve a third party, the Company evaluates whether it is acting as the principal or the agent in the transaction.  This determination requires significant judgement and impacts the amount and timing of revenue recognized.  If the Company determines that it controls a good or service before it is transferred to the customer, the Company is acting as the principal and recognizes revenue at the gross amount of consideration it is entitled to from the customer.  Conversely, if the Company determines that it does not control the good or service before it is transferred to the customer, the Company is acting as an agent in the transaction.  As an agent, the Company is arranging for the good or service to be provided by another party and recognizes revenue at the net amount of consideration retained.

[0001571996-22-000009:notes:65]
Disaggregation of Revenue — The Company’s revenue is presented on a disaggregated basis on the Consolidated Statements of Income and in Note 19 of the Notes to the Consolidated Financial Statements based on an evaluation of disclosures outside of the financial statements, information regularly reviewed by the chief operating decision maker for evaluating the financial performance of operating segments, and other information that is used to evaluate the Company’s financial performance or make resource allocations.  This information includes revenue from products and services, revenue from reportable segments, and revenue by major product categories within the segments.

[0001571996-22-000009:notes:66]
Contract Assets — Contract assets are rights to consideration in exchange for goods or services that the Company has transferred to a customer when such a right is conditional on something other than the passage of time.  Such amounts have been insignificant to date.

[0001571996-22-000009:notes:67]
Contract Liabilities — Contract liabilities primarily consist of deferred revenue.  Deferred revenue is recorded when the Company has invoiced or payments have been received for undelivered products or services, or in situations where revenue recognition criteria have not been met.  Deferred revenue primarily includes amounts received in advance for extended warranty services and software maintenance.  Revenue is recognized on these items when the revenue recognition criteria are met, generally resulting in ratable recognition over the contract term.  The Company also has deferred revenue related to undelivered hardware and professional services, consisting of installations and consulting engagements, which are recognized

[0001571996-22-000009:notes:68]
when the Company’s performance obligations under the contract are completed.  See Note 10 of the Notes to the Consolidated Financial Statements for additional information about deferred revenue.

[0001571996-22-000009:notes:69]
Costs to Obtain a Contract — The Company capitalizes incremental direct costs to obtain a contract, primarily sales commissions and employer taxes related to commission payments, if the costs are deemed to be recoverable.  The Company has elected, as a practical expedient, to expense as incurred costs to obtain a contract equal to or less than one year in duration.  Capitalized costs are deferred and amortized over the period of contract performance or the estimated life of the customer relationship, if renewals are expected, and are typically amortized over an average period of three to five years.  Amortization expense is recognized on a straight-line basis and included in selling, general, and administrative expenses in the Consolidated Statements of Income.

[0001571996-22-000009:notes:70]
The Company periodically reviews these deferred costs to determine whether events or changes in circumstances have occurred that could impact the carrying value or period of benefit of the deferred sales commissions.  There were no material impairment losses for deferred costs to obtain a contract during the fiscal years ended January 28, 2022, January 29, 2021, and January 31, 2020.

[0001571996-22-000009:notes:71]
Deferred costs to obtain a contract as of January 28, 2022 and January 29, 2021 were $734 million and $737 million, respectively.  Deferred costs to obtain a contract are classified as current assets and other non-current assets on the Consolidated Statements of Financial Position, based on when the expense is expected to be recognized.  Amortization of costs to obtain a contract during the fiscal years ended January 28, 2022, January 29, 2021, and January 31, 2020 was $380 million, $385 million, and $376 million, respectively.

[0001571996-22-000009:notes:72]
Standard Warranty Liabilities — The Company records warranty liabilities for estimated costs of fulfilling its obligations under standard limited hardware and software warranties at the time of sale.  The liabilities for standard warranties are included in accrued and other current and other non-current liabilities in the Consolidated Statements of Financial Position.  The specific warranty terms and conditions vary depending upon the product sold and the country in which the Company does business, but generally includes technical support, parts, and labor over a period ranging from one to three years.  Factors that affect the Company’s warranty liabilities include the number of installed units currently under warranty, historical and anticipated rates of warranty claims on those units, and cost per claim to satisfy the Company’s warranty obligation.  The anticipated rate of warranty claims is the primary factor impacting the estimated warranty obligation.  The other factors are less significant due to the fact that the average remaining aggregate warranty period of the covered installed base is approximately 18 months, repair parts are generally already in stock or available at pre-determined prices, and labor rates are generally arranged at preestablished amounts with service providers.  Warranty claims are relatively predictable based on historical experience of failure rates.  If actual results differ from the estimates, the Company revises its estimated warranty liability.  Each quarter, the Company reevaluates its estimates to assess the adequacy of its recorded warranty liabilities and adjusts the amounts as necessary.

[0001571996-22-000009:notes:73]
Vendor Rebates and Settlements — The Company may receive consideration from vendors in the normal course of business.  Certain of these funds are rebates of purchase price paid and others are related to reimbursement of costs incurred by the Company to sell the vendor’s products.  The Company recognizes a reduction of cost of goods sold if the funds are determined to be a reduction of the price of the vendor’s products.  If the consideration is a reimbursement of costs incurred by the Company to sell or develop the vendor’s products, then the consideration is classified as a reduction of such costs, most often operating expenses, in the Consolidated Statements of Income.  In order to be recognized as a reduction of operating expenses, the reimbursement must be for a specific, incremental, and identifiable cost incurred by the Company in selling the vendor’s products or services.

[0001571996-22-000009:notes:74]
In addition, the Company may settle commercial disputes with vendors from time to time.  Claims for loss recoveries are recognized when a loss event has occurred, recovery is considered probable, the agreement is finalized, and collectibility is assured.  Amounts received by the Company from vendors for loss recoveries are generally recorded as a reduction of cost of goods sold.

[0001571996-22-000009:notes:75]
Loss Contingencies — The Company is subject to the possibility of various losses arising in the ordinary course of business.  The Company considers the likelihood of loss or impairment of an asset or the incurrence of a liability, as well as the Company’s ability to reasonably estimate the amount of loss, in determining loss contingencies.  An estimated loss contingency is accrued when it is probable that an asset has been impaired or a liability has been incurred and the amount of loss can be reasonably estimated.  The Company regularly evaluates current information available to determine whether such accruals should be adjusted and whether new accruals are required.

[0001571996-22-000009:notes:76]
Shipping Costs — The Company’s shipping and handling costs are included in cost of net revenue in the Consolidated Statements of Income.

[0001571996-22-000009:notes:77]
Selling, General, and Administrative — Selling expenses include items such as sales salaries and commissions, marketing and advertising costs, contractor services, and allowance for expected credit losses.  Advertising costs are expensed as incurred in selling, general, and administrative expenses in the Consolidated Statements of Income.  For the fiscal years ended January 28, 2022, January 29, 2021, and January 31, 2020, advertising expenses were $1.3 billion, $1.0 billion, and $1.1 billion, respectively.  General and administrative expenses include items for the Company’s administrative functions, such as finance, legal, human resources, and information technology support.  These functions include costs for items such as salaries and benefits and other personnel-related costs, maintenance and supplies, outside services, intangible asset amortization, and depreciation expense.

[0001571996-22-000009:notes:78]
Research and Development — Research and development (“R&D”) costs are expensed as incurred.  As noted in Capitalized Software Development Costs in this Note, qualifying software development costs are capitalized and amortized over time.  R&D costs include salaries and benefits and other personnel-related costs associated with product development.  Also included in R&D expenses are infrastructure costs, which consist of equipment and material costs, facilities-related costs, and depreciation expense.

[0001571996-22-000009:notes:79]
Income Taxes — Deferred tax assets and liabilities are recorded based on the difference between the financial statement and tax basis of assets and liabilities using enacted tax rates in effect for the year in which the differences are expected to reverse.  The Company calculates a provision for income taxes using the asset and liability method, under which deferred tax assets and liabilities are recognized by identifying the temporary differences arising from the different treatment of items for tax and accounting purposes.  The Company accounts for the tax impact of including Global Intangible Low-Taxed Income (GILTI) in U.S. taxable income as a period cost.  The Company provides valuation allowances for deferred tax assets, where appropriate.  In assessing the need for a valuation allowance, the Company considers all available evidence for each jurisdiction, including past operating results, estimates of future taxable income, and the feasibility of ongoing tax planning strategies.  In the event the Company determines that all or part of the net deferred tax assets are not realizable in the future, the Company will make an adjustment to the valuation allowance that will be charged to earnings in the period in which such a determination is made.

[0001571996-22-000009:notes:80]
The accounting guidance for uncertainties in income tax prescribes a comprehensive model for the financial statement recognition, measurement, presentation, and disclosure of uncertain tax positions taken or expected to be taken in income tax returns.  The Company recognizes a tax benefit from an uncertain tax position in the financial statements only when it is more likely than not that the position will be sustained upon examination, including resolution of any related appeals or litigation processes, based on the technical merits and a consideration of the relevant taxing authority’s administrative practices and precedents.

[0001571996-22-000009:notes:81]
Stock-Based Compensation — The Company measures stock-based compensation expense for all share-based awards granted based on the estimated fair value of those awards at grant date.  To estimate the fair value of performance-based awards containing a market condition, the Company uses the Monte Carlo valuation model.  The fair value of all other share-based awards is generally based on the closing price of the Class C Common Stock as reported on the New York Stock Exchange (“NYSE”) on the date of grant.

[0001571996-22-000009:notes:82]
The compensation cost of service-based stock options, restricted stock, and restricted stock units is recognized net of any estimated forfeitures on a straight-line basis over the employee requisite service period.  Compensation cost for performance-based awards is recognized on a graded accelerated basis net of estimated forfeitures over the requisite service period.  Forfeiture rates are estimated at grant date based on historical experience and adjusted in subsequent periods for differences in actual forfeitures from those estimates.

[0001571996-22-000009:notes:83]
Recently Issued Accounting Pronouncements

[0001571996-22-000009:notes:84]
Accounting for Contract Assets and Contract Liabilities from Contracts with Customers — In October 2021, the Financial Accounting Standards Board (“FASB”) issued guidance which requires companies to apply Topic 606, Revenue from Contracts with Customers, to recognize and measure contract assets and contract liabilities from contracts with customers acquired in a business combination.  Public entities must adopt the new guidance for fiscal years beginning after December 15, 2022 and interim periods within those fiscal years, with early adoption permitted.  The Company is currently evaluating the impact and timing of adoption of this guidance.

[0001571996-22-000009:notes:85]
Reference Rate Reform — In March 2020, the FASB issued guidance which provides temporary optional expedients and exceptions to GAAP guidance on contract modifications and certain hedging relationships to ease the financial reporting burdens related to the expected market transition from the London Interbank Offered Rate to alternative reference rates.  The Company may elect to apply the amendments prospectively through December 31, 2022.  Adoption of the new guidance is not expected to have a material impact on the Company’s financial results.

[0001571996-22-000009:notes:86]
Recently Adopted Accounting Pronouncements

[0001571996-22-000009:notes:87]
Accounting for Convertible Instruments and Contracts in an Entity’s Own Equity — In August 2020, the FASB issued guidance to simplify the accounting for convertible debt instruments and convertible preferred stock, and the derivatives scope exception for contracts in an entity's own equity.  In addition, the guidance on calculating diluted earnings per share has been simplified and made more internally consistent.  The Company early adopted this standard as of January 30, 2021.  There was no impact on the Consolidated Financial Statements or to diluted earnings per share as of the adoption date.

[0001571996-22-000009:notes:88]
Simplifying Accounting for Income Taxes — In December 2019, the FASB issued guidance to simplify the accounting for income taxes by removing certain exceptions to the general principles in Topic 740, Income Taxes, and by clarifying and amending existing guidance in order to improve consistent application of GAAP for other areas of Topic 740.  The Company adopted the standard as of April 30, 2021.  The impact of the adoption of this standard was immaterial to the Consolidated Financial Statements.

[0001571996-22-000009:notes:89]
Measurement of Credit Losses on Financial Instruments — In June 2016, the FASB issued amended guidance which replaced the incurred loss impairment methodology for measurement of credit losses on financial instruments with a methodology (the “current expected credit losses model” or “CECL model”) that reflects expected credit losses and requires consideration of a broader range of reasonable and supportable information to inform credit loss estimates.  Under the CECL model, the allowance for losses on financial assets, measured at amortized cost, reflects management’s estimate of credit losses over the remaining expected life of such assets.

[0001571996-22-000009:notes:90]
The Company adopted the standard (the “CECL standard”) as of February 1, 2020 using the modified retrospective method, with the cumulative-effect adjustment to the opening balance of stockholders’ equity (deficit) as of the adoption date.  The cumulative effect of adopting the CECL standard resulted in an increase of $111 million and $27 million to the allowance for expected credit losses within financing receivables, net and accounts receivable, net, respectively, on the Consolidated Statements of Financial Position, and a corresponding decrease of $28 million to other non-current liabilities related to deferred taxes and $110 million to stockholders’ equity (deficit) as of February 1, 2020.  See Note 5 and Note 20 of the Notes to the Consolidated Financial Statements for additional information about the Company’s allowance for financing receivables losses and allowance for expected credit losses of accounts receivable.

[0001571996-22-000009:notes:91]
Leases — In February 2016, the FASB issued amended guidance on the accounting for leasing transactions.  The Company adopted the new lease standard as of February 2, 2019 using the modified retrospective approach, with the cumulative-effect adjustment to the opening balance of stockholders’ equity (deficit) as of the adoption date.  The Company recorded an immaterial adjustment to stockholders’ equity (deficit) as of February 2, 2019 to reflect the cumulative effect of adoption of the new lease standard.

[0001571996-22-000009:notes:92]
See Note 5 and Note 6 of the Notes to the Consolidated Financial Statements for additional information about the Company’s leases from a lessor and lessee perspective, respectively.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0001571996-22-000009:notes:93]
In addition, the Company may settle commercial disputes with vendors from time to time.  Claims for loss recoveries are recognized when a loss event has occurred, recovery is considered probable, the agreement is finalized, and collectibility is assured.  Amounts received by the Company from vendors for loss recoveries are generally recorded as a reduction of cost of goods sold.
Shipping Costs — The Company’s shipping and handling costs are included in cost of net revenue in the Consolidated Statements of Income.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001571996-22-000009:notes:94]
DISCONTINUED OPERATIONS 
VMware Spin-Off —  As disclosed in Note 1 of the Notes to the Consolidated Financial Statements, on November 1, 2021, the Company completed its previously announced spin-off of VMware by means of a special stock dividend of 30,678,605 shares of Class A common stock and 307,221,836 shares of Class B common stock of VMware to Dell Technologies stockholders of record as of October 29, 2021.

[0001571996-22-000009:notes:95]
Prior to receipt of the VMware common stock by the Company’s stockholders, each share of VMware Class B common stock automatically converted into one share of VMware Class A common stock.  As a result of these transactions, each holder of record of shares of Dell Technologies common stock as of the distribution record date received approximately 0.440626 of a share of VMware Class A common stock for each share of Dell Technologies common stock held as of such date, based on shares outstanding as of the completion of the VMware Spin-off.  The pre-transaction stockholders of Dell Technologies owned shares in two separate public companies, consisting of (1) VMware, which continues to own the businesses of VMware, Inc. and its subsidiaries, and (2) Dell Technologies, which continues to own Dell Technologies’ other businesses and subsidiaries.  After the separation, Dell Technologies does not beneficially own any shares of VMware common stock.

[0001571996-22-000009:notes:96]
VMware paid a cash dividend, pro rata, to each of the holders of VMware common stock in an aggregate amount equal to $11.5 billion, of which Dell Technologies received $9.3 billion.  Following the payment by VMware to its stockholders, the separation of VMware from Dell Technologies occurred, including the termination or settlement of certain intercompany accounts and intercompany contracts.  Dell Technologies used the net proceeds from its pro rata share of the cash dividend to repay a portion of its outstanding debt.

[0001571996-22-000009:notes:97]
Dell Technologies determined that the VMware Spin-off, and related distributions, qualified as tax-free for U.S. federal income tax purposes, which required significant judgment by management.  In making these determinations, Dell Technologies applied U.S. federal tax law to relevant facts and circumstances and obtained a favorable private letter ruling from the Internal Revenue Service, a tax opinion, and other external tax advice related to the concluded tax treatment.  If the completed transactions were to fail to qualify for tax-free treatment for U.S. federal income tax purposes, the Company could be subject to significant liabilities, and there could be material adverse impacts on the Company’s business, financial condition, results of operations and cash flows in future reporting periods.

[0001571996-22-000009:notes:98]
In connection with and upon completion of the VMware Spin-off, Dell Technologies and VMware entered into various agreements that provide a framework for the relationship between the companies after the transaction, including, among others, a commercial framework agreement, a tax matters agreement, and a transition services agreement.

[0001571996-22-000009:notes:99]
The CFA referred to in Note 1 to the Notes to the Consolidated Financial Statements provides a framework under which the Company and VMware will continue their commercial relationship after the transaction, particularly with respect to projects mutually agreed by the parties as having the potential to accelerate the growth of an industry, product, service, or platform that may provide one or both companies with a strategic market opportunity.  The CFA has an initial term of five years, with automatic one-year renewals occurring annually thereafter, subject to certain terms and conditions.

[0001571996-22-000009:notes:100]
Pursuant to the CFA, Dell Technologies will continue to act as a distributor of VMware’s standalone products and services and purchase such products and services for resale to end-user customers.  Dell Technologies will also continue to integrate VMware’s products and services with Dell Technologies’ offerings and sell them to end users.  The Company has determined that it is generally acting as principal in such transactions.  The results of such operations are classified as continuing operations within the Company’s Consolidated Statements of Income.

[0001571996-22-000009:notes:101]
In accordance with applicable accounting guidance, the results of VMware, excluding Dell's resale of VMware offerings, are presented as discontinued operations in the Consolidated Statements of Income and, as such, have been excluded from both continuing operations and segment results for all periods presented.  Further, the Company reclassified the assets and liabilities of VMware as assets and liabilities of discontinued operations in the Consolidated Statements of Financial Position as of January 29, 2021.  The Consolidated Statements of Cash Flows are presented on a consolidated basis for both continuing operations and discontinued operations.

[0001571996-22-000009:notes:102]
The tax matters agreement between the Company and VMware governs the respective rights, responsibilities, and obligations of Dell Technologies and VMware with respect to tax liabilities (including taxes, if any, incurred as a result of any failure of the VMware Spin-off to qualify for tax-free treatment for U.S. federal income tax purposes) and benefits, tax attributes, the preparation and filing of tax returns, the control of audits and other tax proceedings, cooperation, and other matters regarding tax.

[0001571996-22-000009:notes:103]
The transition services agreement between the Company and VMware governs the various administrative services which the Company will provide to VMware on an interim transitional basis.  Transition services may be provided for up to one year.

[0001571996-22-000009:notes:104]
Dell Technologies has continuing involvement with VMware due to the activities supported under the CFA.  Cash flows between Dell and VMware primarily relate to Dell’s purchase of VMware products and services for resale.  See Note 21 of the Notes to the Consolidated Financial Statements for additional information regarding transactions between Dell Technologies and VMware.

[0001571996-22-000009:notes:105]
The following table presents key components of “Income from discontinued operations, net of income taxes” for the fiscal years ended January 28, 2022, January 29, 2021, and January 31, 2020:

[0001571996-22-000009:notes:106]
|  |  | Fiscal Year Ended (a) |
|  |  | January 28, 2022 |  | January 29, 2021 |  | January 31, 2020 |
|  |  | (in millions) |
| Net revenue |  | $ | 5,798 |  |  | $ | 7,554 |  |  | $ | 7,339 |  |
| Cost of net revenue |  | (1,632) |  |  | (1,723) |  |  | (955) |  |
| Operating expenses |  | 6,384 |  |  | 7,818 |  |  | 8,038 |  |
| Interest and other, net |  | 232 |  |  | 135 |  |  | 209 |  |
| Income from discontinued operations before income taxes |  | 814 |  |  | 1,324 |  |  | 47 |  |
| Income tax expense (benefit) |  | 49 |  |  | 64 |  |  | (4,961) |  |
| Income from discontinued operations, net of income taxes |  | $ | 765 |  |  | $ | 1,260 |  |  | $ | 5,008 |  |

[0001571996-22-000009:notes:107]
____________________

[0001571996-22-000009:notes:108]
(a)    The table above reflects the offsetting effects of historical intercompany transactions which are presented on a gross basis within continuing operations on the Consolidated Statements of Income.

[0001571996-22-000009:notes:109]
The following table presents assets and liabilities that are classified as discontinued operations on the Consolidated Statements of Financial Position as of January 29, 2021:

[0001571996-22-000009:notes:110]
|  |  | January 29, 2021 (a) |
|  |  | (in millions) |
| ASSETS |
| Current assets: |  |  |
| Cash and cash equivalents |  | $ | 4,693 |  |
| Accounts receivable, net |  | 2,057 |  |
| Other current assets |  | (1,898) |  |
| Total current assets |  | 4,852 |  |
| Property, plant, and equipment, net |  | 1,598 |  |
| Long-term investments |  | 290 |  |
| Goodwill |  | 20,801 |  |
| Intangible assets, net |  | 5,314 |  |
| Other non-current assets |  | 4,012 |  |
| Total assets |  | $ | 36,867 |  |
| LIABILITIES |
| Current liabilities: |  |  |
| Accounts payable |  | $ | 124 |  |
| Accrued and other |  | 927 |  |
| Short-term deferred revenue |  | 3,324 |  |
| Total current liabilities |  | 4,375 |  |
| Long-term debt |  | 8,757 |  |
| Long-term deferred revenue |  | 1,885 |  |
| Other non-current liabilities |  | 1,437 |  |
| Total liabilities |  | $ | 16,454 |  |

[0001571996-22-000009:notes:111]
(a)    The table above reflects the offsetting effects of historical intercompany transactions which are presented on a gross basis within continuing operations on the Consolidated Statements of Financial Position.

[0001571996-22-000009:notes:112]
The following table presents significant cash flow items from discontinued operations for the fiscal years ended January 28, 2022, January 29, 2021, and January 31, 2020 included within the Consolidated Statements of Cash Flows:

[0001571996-22-000009:notes:113]
|  |  | Fiscal Year Ended (a) |
|  |  | January 28, 2022 |  | January 29, 2021 |  | January 31, 2020 |
|  |  | (in millions) |
| Depreciation and amortization |  | $ | 1,004 |  |  | $ | 1,523 |  |  | $ | 1,685 |  |
| Capital expenditures |  | $ | 263 |  |  | $ | 329 |  |  | $ | 279 |  |
| Stock-based compensation expense |  | $ | 814 |  |  | $ | 1,122 |  |  | $ | 1,017 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001571996-22-000009:notes:114]
FAIR VALUE MEASUREMENTS AND INVESTMENTS
The following table presents the Company’s hierarchy for its assets and liabilities measured at fair value on a recurring basis as of the dates indicated:

[0001571996-22-000009:notes:115]
|  | January 28, 2022 |  | January 29, 2021 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | Quoted Prices in Active Markets for Identical Assets |  | Significant Other Observable Inputs |  | Significant Unobservable Inputs |  |  |  | Quoted Prices in Active Markets for Identical Assets |  | Significant Other Observable Inputs |  | Significant Unobservable Inputs |  |  |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 3,737 |  |  | $ | — |  |  | $ | — |  |  | $ | 3,737 |  |  | $ | 5,109 |  |  | $ | — |  |  | $ | — |  |  | $ | 5,109 |  |
| Marketable equity and other securities | 86 |  |  | — |  |  | — |  |  | 86 |  |  | 287 |  |  | — |  |  | — |  |  | 287 |  |
| Derivative instruments | — |  |  | 253 |  |  | — |  |  | 253 |  |  | — |  |  | 95 |  |  | — |  |  | 95 |  |
| Total assets | $ | 3,823 |  |  | $ | 253 |  |  | $ | — |  |  | $ | 4,076 |  |  | $ | 5,396 |  |  | $ | 95 |  |  | $ | — |  |  | $ | 5,491 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative instruments | $ | — |  |  | $ | 138 |  |  | $ | — |  |  | $ | 138 |  |  | $ | — |  |  | $ | 128 |  |  | $ | — |  |  | $ | 128 |  |
| Total liabilities | $ | — |  |  | $ | 138 |  |  | $ | — |  |  | $ | 138 |  |  | $ | — |  |  | $ | 128 |  |  | $ | — |  |  | $ | 128 |  |

[0001571996-22-000009:notes:116]
The following section describes the valuation methodologies the Company uses to measure financial instruments at fair value:

[0001571996-22-000009:notes:117]
Money Market Funds — The Company’s investment in money market funds that are classified as cash equivalents hold underlying investments with a weighted average maturity of 90 days or less and are recognized at fair value.  The valuations of these securities are based on quoted prices in active markets for identical assets, when available, or pricing models whereby all significant inputs are observable or can be derived from or corroborated by observable market data.  The Company reviews security pricing and assesses liquidity on a quarterly basis.

[0001571996-22-000009:notes:118]
Marketable Equity and Other Securities — The majority of the Company’s investments in equity and other securities that are measured at fair value on a recurring basis consist of strategic investments in publicly-traded companies.  The valuation of these securities is based on quoted prices in active markets.

[0001571996-22-000009:notes:119]
Derivative Instruments — The Company’s derivative financial instruments consist primarily of foreign currency forward and purchased option contracts and interest rate swaps.  The fair value of the portfolio is determined using valuation models based on market observable inputs, including interest rate curves, forward and spot prices for currencies, and implied volatilities.  Credit risk is also factored into the fair value calculation of the Company’s derivative financial instrument portfolio.  See Note 8 of the Notes to the Consolidated Financial Statements for a description of the Company’s derivative financial instrument activities.

[0001571996-22-000009:notes:120]
Deferred Compensation Plans —The Company offers deferred compensation plans for eligible employees, which allow participants to defer a portion of their compensation.  Assets were the same as liabilities associated with the plans at approximately $192 million and $168 million as of January 28, 2022 and January 29, 2021, respectively, and are included in other assets and other liabilities on the Consolidated Statements of Financial Position.  The net impact to the Consolidated Statements of Income is not material since changes in the fair value of the assets substantially offset changes in the fair value of the liabilities.  As such, assets and liabilities associated with these plans have not been included in the recurring fair value table above.

[0001571996-22-000009:notes:121]
Assets and Liabilities Measured at Fair Value on a Nonrecurring Basis — Certain assets are measured at fair value on a nonrecurring basis and therefore are not included in the recurring fair value table above.  These assets consist primarily of non-

[0001571996-22-000009:notes:122]
financial assets such as goodwill and intangible assets.  See Note 9 of the Notes to the Consolidated Financial Statements for additional information about goodwill and intangible assets.

[0001571996-22-000009:notes:123]
As of January 28, 2022 and January 29, 2021, the Company held strategic investments in non-marketable equity and other securities of $1.4 billion and $0.9 billion, respectively.  As these investments represent early-stage companies without readily determinable fair values, they are not included in the recurring fair value table above.

[0001571996-22-000009:notes:124]
Carrying Value and Estimated Fair Value of Outstanding Debt — The following table presents the carrying value and estimated fair value of the Company’s outstanding debt as described in Note 7 of the Notes to the Consolidated Financial Statements, including the current portion, as of the dates indicated:

[0001571996-22-000009:notes:125]
|  | January 28, 2022 |  | January 29, 2021 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Secured Credit Facilities | $ | — |  |  | $ | — |  |  | $ | 6.2 |  |  | $ | 6.3 |  |
| Senior Notes | $ | 16.1 |  |  | $ | 18.5 |  |  | $ | 20.9 |  |  | $ | 25.5 |  |
| Legacy Notes and Debentures | $ | 0.8 |  |  | $ | 1.1 |  |  | $ | 1.2 |  |  | $ | 1.6 |  |
| EMC Notes | $ | — |  |  | $ | — |  |  | $ | 1.0 |  |  | $ | 1.0 |  |

[0001571996-22-000009:notes:126]
The fair values of the outstanding debt shown in the table above, as well as the DFS debt described in Note 5 of the Notes to the Consolidated Financial Statements, were determined based on observable market prices in a less active market or based on valuation methodologies using observable inputs and were categorized as Level 2 in the fair value hierarchy.  The carrying value of DFS debt approximates fair value.

[0001571996-22-000009:notes:127]
Investments

[0001571996-22-000009:notes:128]
The Company has strategic investments in equity and other securities as well as investments in fixed-income debt securities.  As of January 28, 2022 and January 29, 2021, total investments were $1.8 billion and $1.3 billion, respectively.

[0001571996-22-000009:notes:129]
Equity and Other Securities

[0001571996-22-000009:notes:130]
Equity and other securities include strategic investments in marketable and non-marketable securities.  Investments in marketable securities are measured at fair value on a recurring basis.  The Company has elected to apply the measurement alternative for non-marketable securities.  Under the alternative, the Company measures investments without readily determinable fair values at cost, less impairment, adjusted by observable price changes.  The Company makes a separate election to use the alternative for each eligible investment and is required to reassess at each reporting period whether an investment qualifies for the alternative.  In evaluating these investments for impairment or observable price changes, the Company uses inputs including pre- and post-money valuations of recent financing events and the impact of those events on its fully diluted ownership percentages, as well as other available information regarding the issuer’s historical and forecasted performance.

[0001571996-22-000009:notes:131]
Carrying Value of Equity and Other Securities

[0001571996-22-000009:notes:132]
The following table presents the amortized cost, cumulative unrealized gains, cumulative unrealized losses, and carrying value of the Company's strategic investments in marketable and non-marketable equity securities as of the dates indicated.

[0001571996-22-000009:notes:133]
|  | January 28, 2022 |  | January 29, 2021 |
|  | Cost |  | Unrealized Gain |  | Unrealized Loss |  | Carrying Value |  | Cost |  | Unrealized Gain |  | Unrealized Loss |  | Carrying Value |
|  | (in millions) |
| Marketable | $ | 126 |  |  | $ | 79 |  |  | $ | (119) |  |  | $ | 86 |  |  | $ | 185 |  |  | $ | 144 |  |  | $ | (42) |  |  | $ | 287 |  |
| Non-marketable | 593 |  |  | 900 |  |  | (52) |  |  | 1,441 |  |  | 454 |  |  | 419 |  |  | (11) |  |  | 862 |  |
| Total equity and other securities | $ | 719 |  |  | $ | 979 |  |  | $ | (171) |  |  | $ | 1,527 |  |  | $ | 639 |  |  | $ | 563 |  |  | $ | (53) |  |  | $ | 1,149 |  |

[0001571996-22-000009:notes:134]
Gains and Losses on Equity and Other Securities

[0001571996-22-000009:notes:135]
The following table presents unrealized gains and losses on marketable and non-marketable equity and other securities for the periods indicated:

[0001571996-22-000009:notes:136]
|  | Fiscal Year Ended |
|  | January 28, 2022 |  | January 29, 2021 |  | January 31, 2020 |
|  | (in millions) |
| Marketable securities |  |  |  |  |  |
| Unrealized gain | $ | 45 |  |  | $ | 288 |  |  | $ | 5 |  |
| Unrealized loss | (151) |  |  | (45) |  |  | (18) |  |
| Net unrealized gain (loss) | (106) |  |  | 243 |  |  | (13) |  |
| Non-marketable securities |  |  |  |  |  |
| Unrealized gain | 604 |  |  | 190 |  |  | 75 |  |
| Unrealized loss | (43) |  |  | (59) |  |  | (15) |  |
| Net unrealized gain (a) | 561 |  |  | 131 |  |  | 60 |  |
| Total net gain on equity and other securities | $ | 455 |  |  | $ | 374 |  |  | $ | 47 |  |

[0001571996-22-000009:notes:137]
(a)    For all periods presented, net gains on non-marketable securities are due to upward adjustments for observable price changes offset by losses primarily attributable to impairments.

[0001571996-22-000009:notes:138]
Fixed Income Debt Securities

[0001571996-22-000009:notes:139]
The Company has fixed income debt securities carried at amortized cost which are held as collateral for borrowings.  The Company intends to hold the investments to maturity.

[0001571996-22-000009:notes:140]
The following table summarizes the Company’s debt securities for the periods indicated:

[0001571996-22-000009:notes:141]
|  | January 28, 2022 |  | January 29, 2021 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Loss |  | Carrying Value |  | Amortized Cost |  | Unrealized Gains |  | Unrealized Loss |  | Carrying Value |
|  | (in millions) |
| Fixed income debt securities | $ | 333 |  |  | $ | 26 |  |  | $ | (47) |  |  | $ | 312 |  |  | $ | 176 |  |  | $ | 12 |  |  | $ | (3) |  |  | $ | 185 |  |


## dell:CreditLossFinancialInstrumentLeasesDebtVariableInterestEntitiesAndCustomerReceivablesSalesTextBlock

[0001571996-22-000009:notes:142]
FINANCIAL SERVICES
The Company offers or arranges various financing options and services, and alternative payment structures for its customers globally.  The Company also arranges financing for some of its customers in various countries where DFS does not currently operate as a captive enterprise.  The Company further strengthens customer relationships through flexible consumption models, which enable the Company to offer its customers the option to pay over time and, in certain cases, based on utilization, to provide them with financial flexibility to meet their changing technological requirements.  The key activities of DFS include originating, collecting, and servicing customer financing arrangements primarily related to the purchase or use of Dell Technologies products and services.  In some cases, DFS also offers financing for the purchase of third-party technology products that complement the Dell Technologies portfolio of products and services.  New financing originations were $8.5 billion, $8.9 billion, and $8.5 billion for the fiscal years ended January 28, 2022, January 29, 2021, and January 31, 2020, respectively.

[0001571996-22-000009:notes:143]
The Company’s lease and loan arrangements with customers are aggregated primarily into the following categories:

[0001571996-22-000009:notes:144]
Revolving loans — Revolving loans offered under private label credit financing programs provide qualified customers with a revolving credit line for the purchase of products and services offered by Dell Technologies.  These private label credit financing programs are referred to as Dell Preferred Account (“DPA”) and Dell Business Credit (“DBC”).  The DPA product is primarily offered to individual consumer customers, and the DBC product is primarily offered to small and medium-sized commercial customers.  Revolving loans in the United States bear interest at a variable annual percentage rate that is tied to the prime rate.  Based on historical payment patterns, revolving loan transactions are typically repaid within twelve months on average.  Due to the short-term nature of the revolving loan portfolio, the carrying value of the portfolio approximates fair value.

[0001571996-22-000009:notes:145]
Fixed-term leases and loans — The Company enters into financing arrangements with customers who seek lease financing for equipment.  DFS leases are classified as sales-type leases, direct financing leases, or operating leases.  Direct financing leases are immaterial.  Leases that commenced prior to the effective date of the current lease accounting standard continue to be accounted for under previous lease accounting guidance.  Leases with business customers have fixed terms of generally two to four years.

[0001571996-22-000009:notes:146]
The Company also offers fixed-term loans to qualified small businesses, large commercial accounts, governmental organizations, educational entities, and certain individual consumer customers.  These loans are repaid in equal payments including interest and have defined terms of generally three to five years.  The fair value of the fixed-term loan portfolio is determined using market observable inputs.  The carrying value of these loans approximates fair value.

[0001571996-22-000009:notes:147]
Financing Receivables

[0001571996-22-000009:notes:148]
The following table presents the components of the Company’s financing receivables segregated by portfolio segment as of the dates indicated:

[0001571996-22-000009:notes:149]
|  | January 28, 2022 |  | January 29, 2021 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Financing receivables, net: |  |  |  |  |  |  |  |  |  |  |  |
| Customer receivables, gross (a) | $ | 750 |  |  | $ | 9,833 |  |  | $ | 10,583 |  |  | $ | 796 |  |  | $ | 9,588 |  |  | $ | 10,384 |  |
| Allowances for losses | (102) |  |  | (87) |  |  | (189) |  |  | (148) |  |  | (173) |  |  | (321) |  |
| Customer receivables, net | 648 |  |  | 9,746 |  |  | 10,394 |  |  | 648 |  |  | 9,415 |  |  | 10,063 |  |
| Residual interest | — |  |  | 217 |  |  | 217 |  |  | — |  |  | 424 |  |  | 424 |  |
| Financing receivables, net | $ | 648 |  |  | $ | 9,963 |  |  | $ | 10,611 |  |  | $ | 648 |  |  | $ | 9,839 |  |  | $ | 10,487 |  |
| Short-term | $ | 648 |  |  | $ | 4,441 |  |  | $ | 5,089 |  |  | $ | 648 |  |  | $ | 4,500 |  |  | $ | 5,148 |  |
| Long-term | $ | — |  |  | $ | 5,522 |  |  | $ | 5,522 |  |  | $ | — |  |  | $ | 5,339 |  |  | $ | 5,339 |  |

[0001571996-22-000009:notes:150]
(a)    Customer receivables, gross include amounts due from customers under revolving loans, fixed-term loans, fixed-term sales-type or direct financing leases, and accrued interest.

[0001571996-22-000009:notes:151]
The following table presents the changes in allowance for financing receivable losses for the periods indicated:

[0001571996-22-000009:notes:152]
|  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |  |  |  |  |  |
| Balances as of February 1, 2019 | $ | 75 |  |  | $ | 61 |  |  | $ | 136 |  |
| Charge-offs, net of recoveries | (71) |  |  | (23) |  |  | (94) |  |
| Provision charged to income statement | 66 |  |  | 41 |  |  | 107 |  |
| Balances as of January 31, 2020 | 70 |  |  | 79 |  |  | 149 |  |
| Adjustment for adoption of accounting standard (Note 2) | 40 |  |  | 71 |  |  | 111 |  |
| Charge-offs, net of recoveries | (62) |  |  | (29) |  |  | (91) |  |
| Provision charged to income statement | 100 |  |  | 52 |  |  | 152 |  |
| Balances as of January 29, 2021 | 148 |  |  | 173 |  |  | 321 |  |
| Charge-offs, net of recoveries | (43) |  |  | (29) |  |  | (72) |  |
| Provision charged to income statement | (3) |  |  | (57) |  |  | (60) |  |
| Balances as of January 28, 2022 | $ | 102 |  |  | $ | 87 |  |  | $ | 189 |  |

[0001571996-22-000009:notes:153]
Aging

[0001571996-22-000009:notes:154]
The following table presents the aging of the Company’s customer financing receivables, gross, including accrued interest, segregated by class, as of the dates indicated:

[0001571996-22-000009:notes:155]
|  | January 28, 2022 |  | January 29, 2021 |
|  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |
|  | (in millions) |
| Revolving — DPA | $ | 520 |  |  | $ | 40 |  |  | $ | 11 |  |  | $ | 571 |  |  | $ | 578 |  |  | $ | 30 |  |  | $ | 13 |  |  | $ | 621 |  |
| Revolving — DBC | 158 |  |  | 18 |  |  | 3 |  |  | 179 |  |  | 157 |  |  | 14 |  |  | 4 |  |  | 175 |  |
| Fixed-term — Consumer and Commercial | 9,444 |  |  | 345 |  |  | 44 |  |  | 9,833 |  |  | 9,185 |  |  | 316 |  |  | 87 |  |  | 9,588 |  |
| Total customer receivables, gross | $ | 10,122 |  |  | $ | 403 |  |  | $ | 58 |  |  | $ | 10,583 |  |  | $ | 9,920 |  |  | $ | 360 |  |  | $ | 104 |  |  | $ | 10,384 |  |

[0001571996-22-000009:notes:156]
Aging is likely to fluctuate as a result of the variability in volume of large transactions entered into over the period, and the administrative processes that accompany those transactions.  Aging is also impacted by the timing of the Dell Technologies fiscal period end date relative to calendar month-end customer payment due dates.  As a result of these factors, fluctuations in aging from period to period do not necessarily indicate a material change in the collectibility of the portfolio.

[0001571996-22-000009:notes:157]
Fixed-term consumer and commercial customer receivables are placed on non-accrual status if principal or interest is past due and considered delinquent, or if there is concern about collectibility of a specific customer receivable.  These receivables identified as doubtful for collectibility may be classified as current for aging purposes.  Aged revolving portfolio customer receivables identified as delinquent are charged off.

[0001571996-22-000009:notes:158]
Credit Quality

[0001571996-22-000009:notes:159]
The following tables present customer receivables, gross, including accrued interest, by credit quality indicator segregated by class, as of the dates indicated:

[0001571996-22-000009:notes:160]
|  | January 28, 2022 |
|  | Fixed-term — Consumer and Commercial |  |  |  |  |  |  |
|  | Fiscal Year of Origination |  |  |  |  |  |  |
|  | 2022 |  | 2021 |  | 2020 |  | 2019 |  | 2018 |  | Years Prior |  | Revolving — DPA |  | Revolving — DBC |  | Total |
|  | (in millions) |
| Higher | $ | 3,279 |  |  | $ | 1,824 |  |  | $ | 914 |  |  | $ | 221 |  |  | $ | 25 |  |  | $ | 3 |  |  | $ | 150 |  |  | $ | 46 |  |  | $ | 6,462 |  |
| Mid | 1,071 |  |  | 751 |  |  | 329 |  |  | 94 |  |  | 17 |  |  | — |  |  | 166 |  |  | 57 |  |  | 2,485 |  |
| Lower | 599 |  |  | 450 |  |  | 208 |  |  | 42 |  |  | 6 |  |  | — |  |  | 255 |  |  | 76 |  |  | 1,636 |  |
| Total | $ | 4,949 |  |  | $ | 3,025 |  |  | $ | 1,451 |  |  | $ | 357 |  |  | $ | 48 |  |  | $ | 3 |  |  | $ | 571 |  |  | $ | 179 |  |  | $ | 10,583 |  |

[0001571996-22-000009:notes:161]
|  | January 29, 2021 |
|  | Fixed-term — Consumer and Commercial |  |  |  |  |  |  |
|  | Fiscal Year of Origination |  |  |  |  |  |  |
|  | 2021 |  | 2020 |  | 2019 |  | 2018 |  | 2017 |  | Years Prior |  | Revolving — DPA |  | Revolving — DBC |  | Total |
|  | (in millions) |
| Higher | $ | 3,119 |  |  | $ | 1,801 |  |  | $ | 661 |  |  | $ | 166 |  |  | $ | 26 |  |  | $ | — |  |  | $ | 172 |  |  | $ | 47 |  |  | $ | 5,992 |  |
| Mid | 1,121 |  |  | 671 |  |  | 287 |  |  | 73 |  |  | 9 |  |  | — |  |  | 188 |  |  | 52 |  |  | 2,401 |  |
| Lower | 865 |  |  | 499 |  |  | 243 |  |  | 38 |  |  | 9 |  |  | — |  |  | 261 |  |  | 76 |  |  | 1,991 |  |
| Total | $ | 5,105 |  |  | $ | 2,971 |  |  | $ | 1,191 |  |  | $ | 277 |  |  | $ | 44 |  |  | $ | — |  |  | $ | 621 |  |  | $ | 175 |  |  | $ | 10,384 |  |

[0001571996-22-000009:notes:162]
The categories shown in the tables above segregate customer receivables based on the relative degrees of credit risk.  The credit quality indicators for DPA revolving accounts are measured primarily as of each quarter-end date, while all other indicators are generally updated on a periodic basis.

[0001571996-22-000009:notes:163]
For DPA revolving receivables shown in the table above, the Company makes credit decisions based on proprietary scorecards, which include the customer’s credit history, payment history, credit usage, and other credit agency-related elements.  The higher quality category includes prime accounts generally of a higher credit quality that are comparable to U.S. customer FICO scores of 720 or above.  The mid-category represents the mid-tier accounts that are comparable to U.S. customer FICO scores from 660 to 719.  The lower category is generally sub-prime and represents lower credit quality accounts that are comparable to U.S. customer FICO scores below 660.  For the DBC revolving receivables and fixed-term commercial receivables shown in the table above, an internal grading system is utilized that assigns a credit level score based on a number of considerations, including liquidity, operating performance, and industry outlook.  The grading criteria and classifications for the fixed-term products differ from those for the revolving products as loss experience varies between these product and customer groups.  The credit quality categories cannot be compared between the different classes as loss experience varies substantially between the classes.

[0001571996-22-000009:notes:164]
Leases

[0001571996-22-000009:notes:165]
Interest income on sales-type lease receivables was $246 million, $270 million, and $259 million for the fiscal years ended January 28, 2022, January 29, 2021, and January 31, 2020, respectively.

[0001571996-22-000009:notes:166]
The following table presents the net revenue, cost of net revenue, and gross margin recognized at the commencement date of sales-type leases for the periods indicated:

[0001571996-22-000009:notes:167]
|  | Fiscal Year Ended |
|  | January 28, 2022 |  | January 29, 2021 |  | January 31, 2020 |
|  | (in millions) |
| Net revenue — products | $ | 756 |  |  | $ | 824 |  |  | $ | 770 |  |
| Cost of net revenue — products | 583 |  |  | 578 |  |  | 582 |  |
| Gross margin — products | $ | 173 |  |  | $ | 246 |  |  | $ | 188 |  |

[0001571996-22-000009:notes:168]
The following table presents the future maturity of the Company’s fixed-term customer leases and associated financing payments, and reconciles the undiscounted cash flows to the customer receivables, gross recognized on the Consolidated Statements of Financial Position as of the date indicated:

[0001571996-22-000009:notes:169]
|  | January 28, 2022 |
|  | (in millions) |
| Fiscal 2023 | $ | 2,488 |  |
| Fiscal 2024 | 1,627 |  |
| Fiscal 2025 | 938 |  |
| Fiscal 2026 | 375 |  |
| Fiscal 2027 and beyond | 96 |  |
| Total undiscounted cash flows | 5,524 |  |
| Fixed-term loans | 4,921 |  |
| Revolving loans | 750 |  |
| Less: unearned income | (612) |  |
| Total customer receivables, gross | $ | 10,583 |  |

[0001571996-22-000009:notes:170]
Operating Leases

[0001571996-22-000009:notes:171]
The following table presents the components of the Company’s operating lease portfolio included in Property, plant, and equipment, net as of the dates indicated:

[0001571996-22-000009:notes:172]
|  | January 28, 2022 |  | January 29, 2021 |
|  | (in millions) |
| Equipment under operating lease, gross | $ | 2,643 |  |  | $ | 1,746 |  |
| Less: accumulated depreciation | (935) |  |  | (432) |  |
| Equipment under operating lease, net | $ | 1,708 |  |  | $ | 1,314 |  |

[0001571996-22-000009:notes:173]
Operating lease income relating to lease payments was $717 million, $452 million, and $169 million for the fiscal years ended January 28, 2022, January 29, 2021, and January 31, 2020, respectively.  Depreciation expense was $536 million, $334 million, and $115 million for the fiscal years ended January 28, 2022, January 29, 2021, and January 31, 2020, respectively.

[0001571996-22-000009:notes:174]
The following table presents the future payments to be received by the Company as lessor in operating lease contracts as of the date indicated:

[0001571996-22-000009:notes:175]
|  | January 28, 2022 |
|  | (in millions) |
| Fiscal 2023 | $ | 809 |  |
| Fiscal 2024 | 557 |  |
| Fiscal 2025 | 311 |  |
| Fiscal 2026 | 82 |  |
| Fiscal 2027 and beyond | 25 |  |
| Total | $ | 1,784 |  |

[0001571996-22-000009:notes:176]
DFS Debt

[0001571996-22-000009:notes:177]
The Company maintains programs that facilitate the funding of leases, loans, and other alternative payment structures in the capital markets.  The majority of DFS debt is non-recourse to Dell Technologies and represents borrowings under securitization programs and structured financing programs, for which the Company’s risk of loss is limited to transferred loan and lease payments and associated equipment.  The following table presents DFS debt as of the dates indicated.  The table excludes the allocated portion of the Company’s other borrowings, which represents the additional amount considered to fund the DFS business.

[0001571996-22-000009:notes:178]
|  | January 28, 2022 |  | January 29, 2021 |
| DFS debt | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing and securitization facilities | $ | 3,054 |  |  | $ | 3,311 |  |
| Fixed-term securitization offerings | 3,011 |  |  | 2,961 |  |
| Other | 135 |  |  | 140 |  |
| Total DFS U.S. debt | 6,200 |  |  | 6,412 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 739 |  |  | 786 |  |
| Other borrowings | 785 |  |  | 1,006 |  |
| Note payable | 250 |  |  | 250 |  |
| Dell Bank Senior Unsecured Eurobonds | 1,672 |  |  | 1,212 |  |
| Total DFS international debt | 3,446 |  |  | 3,254 |  |
| Total DFS debt | $ | 9,646 |  |  | $ | 9,666 |  |
| Total short-term DFS debt | $ | 5,803 |  |  | $ | 4,888 |  |
| Total long-term DFS debt | $ | 3,843 |  |  | $ | 4,778 |  |

[0001571996-22-000009:notes:179]
DFS U.S. Debt

[0001571996-22-000009:notes:180]
Asset-Based Financing and Securitization Facilities — The Company maintains separate asset-based financing facilities and a securitization facility in the United States, which are revolving facilities for fixed-term leases and loans and for revolving loans, respectively.  This debt is collateralized solely by the U.S. loan and lease payments and associated equipment in the facilities.  The debt has a variable interest rate and the duration of the debt is based on the terms of the underlying loan and lease payment streams.  As of January 28, 2022, the total debt capacity related to the U.S. asset-based financing and securitization facilities was $4.5 billion.  The Company enters into interest swap agreements to effectively convert a portion of this debt from a floating rate to a fixed rate.  See Note 8 of the Notes to the Consolidated Financial Statements for additional information about interest rate swaps.

[0001571996-22-000009:notes:181]
The Company’s U.S. securitization facility for revolving loans is effective through June 25, 2022.  The Company’s two U.S. asset-based financing facilities for fixed-term leases and loans are effective through July 10, 2023 and July 26, 2022, respectively.

[0001571996-22-000009:notes:182]
The asset-based financing and securitization facilities contain standard structural features related to the performance of the funded receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the facility, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of January 28, 2022, these criteria were met.

[0001571996-22-000009:notes:183]
Fixed-Term Securitization Offerings — The Company periodically issues asset-backed debt securities under fixed-term securitization programs to private investors.  The asset-backed debt securities are collateralized solely by the U.S. fixed-term leases and loans in the offerings, which are held by Special Purpose Entities (“SPEs”), as discussed below.  The interest rate on these securities is fixed and ranges from 0.18% to 5.92% per annum, and the duration of these securities is based on the terms of the underlying lease and loan payment streams.

[0001571996-22-000009:notes:184]
DFS International Debt

[0001571996-22-000009:notes:185]
Securitization Facility — The Company maintains a securitization facility in Europe for fixed-term leases and loans.  This facility is effective through December 21, 2022 and had a total debt capacity of $892 million as of January 28, 2022.

[0001571996-22-000009:notes:186]
The securitization facility contains standard structural features related to the performance of the securitized receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the program, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of January 28, 2022, these criteria were met.

[0001571996-22-000009:notes:187]
Other Borrowings — In connection with the Company’s international financing operations, the Company has entered into revolving structured financing debt programs related to its fixed-term lease and loan products sold in Canada, Europe, Australia, and New Zealand.  The Canadian facility, which is collateralized solely by Canadian loan and lease payments and associated equipment, had a total debt capacity of $353 million as of January 28, 2022, and is effective through January 16, 2025.  The European facility, which is collateralized solely by European loan and lease payments and associated equipment, had a total debt capacity of $669 million as of January 28, 2022, and is effective through December 14, 2023.  The Australia and New Zealand facility, which is collateralized solely by Australia and New Zealand loan and lease payments and associated equipment, had a total debt capacity of $316 million as of January 28, 2022, and is effective through April 20, 2023.

[0001571996-22-000009:notes:188]
Note Payable —On August 7, 2020, the Company entered into two new unsecured credit agreements to fund receivables in Mexico.  As of January 28, 2022, the aggregate principal amount of the notes payable was $250 million.  The notes bear interest at an annual rate of 3.37% and will mature on June 1, 2022.

[0001571996-22-000009:notes:189]
Dell Bank Senior Unsecured Eurobonds  — On October 17, 2019, Dell Bank International D.A.C. issued 500 million Euro of 0.625% senior unsecured three year eurobonds due October 2022.  On June 24, 2020, Dell Bank International D.A.C. issued an additional 500 million Euro of 1.625% senior unsecured four year eurobonds due June 2024.  On October 27, 2021, Dell Bank International D.A.C issued 500 million Euro of 0.5% senior unsecured five years eurobonds due October 2026.  The issuance of the senior unsecured eurobonds support the expansion of the financing operations in Europe.

[0001571996-22-000009:notes:190]
Variable Interest Entities

[0001571996-22-000009:notes:191]
In connection with the asset-based financing facilities, securitization facilities, and fixed-term securitization offerings discussed above, the Company transfers certain U.S. and European loan and lease payments and associated equipment to SPEs that meet the definition of a Variable Interest Entity (“VIE”) and are consolidated, along with the associated debt detailed above, into the Consolidated Financial Statements, as the Company is the primary beneficiary of the VIEs.  The SPEs are bankruptcy-remote legal entities with separate assets and liabilities.  The purpose of the SPEs is to facilitate the funding of customer loan and lease payments and associated equipment in the capital markets.

[0001571996-22-000009:notes:192]
Some of the SPEs have entered into financing arrangements with multi-seller conduits that, in turn, issue asset-backed debt securities in the capital markets.  DFS debt outstanding held by the consolidated VIEs is collateralized by the loan and lease payments and associated equipment.  The Company’s risk of loss related to securitized receivables is limited to the amount by which the Company’s right to receive collections for assets securitized exceeds the amount required to pay interest, principal, and fees and expenses related to the asset-backed securities.  The Company provides credit enhancement to the securitization in the form of over-collateralization.

[0001571996-22-000009:notes:193]
The following table presents the assets and liabilities held by the consolidated VIEs as of the dates indicated, which are included in the Consolidated Statements of Financial Position:

[0001571996-22-000009:notes:194]
|  | January 28, 2022 |  | January 29, 2021 |
|  | (in millions) |
| Assets held by consolidated VIEs |  |  |  |
| Other current assets | $ | 535 |  |  | $ | 838 |  |
| Financing receivables, net of allowance |  |  |  |
| Short-term | $ | 3,368 |  |  | $ | 3,534 |  |
| Long-term | $ | 3,141 |  |  | $ | 3,314 |  |
| Property, plant, and equipment, net | $ | 945 |  |  | $ | 792 |  |
| Liabilities held by consolidated VIEs |  |  |  |
| Debt, net of unamortized debt issuance costs |  |  |  |
| Short-term | $ | 4,560 |  |  | $ | 4,208 |  |
| Long-term | $ | 2,235 |  |  | $ | 2,841 |  |

[0001571996-22-000009:notes:195]
Loan and lease payments and associated equipment transferred via securitization through SPEs were $5.3 billion and $6.1 billion for the fiscal years ended January 28, 2022 and January 29, 2021, respectively.

[0001571996-22-000009:notes:196]
Customer Receivable Sales

[0001571996-22-000009:notes:197]
To manage certain concentrations of customer credit exposure, the Company may sell selected fixed-term customer receivables to unrelated third parties on a periodic basis, without recourse.  The amount of customer receivables sold for this purpose was $201 million, $648 million, and $538 million for the fiscal years ended January 28, 2022, January 29, 2021, and January 31, 2020, respectively.  The Company’s continuing involvement in these customer receivables is primarily limited to servicing arrangements.


## us-gaap:ScheduleOfDebtTableTextBlock

[0001571996-22-000009:notes:198]
The majority of DFS debt is non-recourse to Dell Technologies and represents borrowings under securitization programs and structured financing programs, for which the Company’s risk of loss is limited to transferred loan and lease payments and associated equipment.  The following table presents DFS debt as of the dates indicated.  The table excludes the allocated portion of the Company’s other borrowings, which represents the additional amount considered to fund the DFS business.

[0001571996-22-000009:notes:199]
The following table summarizes the Company’s outstanding debt as of the dates indicated:

[0001571996-22-000009:notes:200]
|  | January 28, 2022 |  | January 29, 2021 |
|  | (in millions) |
| Senior Secured Credit Facilities: |  |  |  |
| 2.00% Term Loan B-1 Facility due September 2025 | $ | — |  |  | $ | 3,143 |  |
| 1.84% Term Loan A-6 Facility due March 2024 | — |  |  | 3,134 |  |
| Senior Notes: |  |  |  |
| 5.88% due June 2021 | — |  |  | 1,075 |  |
| 5.45% due June 2023 | 1,000 |  |  | 3,750 |  |
| 7.13% due June 2024 | — |  |  | 1,625 |  |
| 4.00% due July 2024 | 1,000 |  |  | 1,000 |  |
| 5.85% due July 2025 | 1,000 |  |  | 1,000 |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 4.90% due October 2026 | 1,750 |  |  | 1,750 |  |
| 6.10% due July 2027 | 500 |  |  | 500 |  |
| 5.30% due October 2029 | 1,750 |  |  | 1,750 |  |
| 6.20% due July 2030 | 750 |  |  | 750 |  |
| 8.10% due July 2036 | 1,000 |  |  | 1,500 |  |
| 3.38% due December 2041 | 1,000 |  |  | — |  |
| 8.35% due July 2046 | 800 |  |  | 2,000 |  |
| 3.45% due December 2051 | 1,250 |  |  | — |  |
| Legacy Notes and Debentures: |  |  |  |
| 4.63% due April 2021 | — |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| EMC Notes: |  |  |  |
| 3.38% due June 2023 | — |  |  | 1,000 |  |
| DFS Debt (Note 5) | 9,646 |  |  | 9,666 |  |
| Other | 337 |  |  | 180 |  |
| Total debt, principal amount | $ | 27,235 |  |  | $ | 39,675 |  |
| Unamortized discount, net of unamortized premium | (134) |  |  | (178) |  |
| Debt issuance costs | (147) |  |  | (275) |  |
| Total debt, carrying value | $ | 26,954 |  |  | $ | 39,222 |  |
| Total short-term debt, carrying value | $ | 5,823 |  |  | $ | 6,357 |  |
| Total long-term debt, carrying value | $ | 21,131 |  |  | $ | 32,865 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0001571996-22-000009:notes:201]
LEASES 
The Company enters into leasing transactions in which the Company is the lessee.  These lease contracts are typically classified as operating leases.  The Company’s lease contracts are generally for office buildings used to conduct its business, and the determination of whether such contracts contain leases generally does not require significant estimates or judgments.  The Company also leases certain global logistics warehouses, employee vehicles, and equipment.  As of January 28, 2022, the remaining terms of the Company’s leases range from less than two months to eleven years.

[0001571996-22-000009:notes:202]
The Company also enters into leasing transactions in which the Company is the lessor, primarily through customer financing arrangements offered through DFS.  DFS originates leases that are primarily classified as either sales-type leases or operating leases.  See Note 5 of the Notes to the Consolidated Financial Statements for more information on the DFS lease portfolio and related lease disclosures.

[0001571996-22-000009:notes:203]
Financial information associated with the Company’s leases in which the Company is the lessee is contained in this Note.  As of January 28, 2022 and January 29, 2021, there were no material finance leases for which the Company was a lessee.

[0001571996-22-000009:notes:204]
The following table presents components of lease costs included in the Consolidated Statements of Income for the periods indicated:

[0001571996-22-000009:notes:205]
|  | Fiscal Year Ended |
|  | January 28, 2022 |  | January 29, 2021 |
|  | (in millions) |
| Operating lease costs | $ | 335 |  |  | $ | 348 |  |
| Variable costs | 96 |  |  | 132 |  |
| Total lease costs | $ | 431 |  |  | $ | 480 |  |

[0001571996-22-000009:notes:206]
During the fiscal years ended January 28, 2022 and January 29, 2021, sublease income, finance lease costs, and short-term lease costs were immaterial.

[0001571996-22-000009:notes:207]
The following table presents supplemental information related to operating leases included in the Consolidated Statements of Financial Position as of the dates indicated:

[0001571996-22-000009:notes:208]
|  | Classification | January 28, 2022 |  | January 29, 2021 |  |  |
|  |  | (in millions, except for term and discount rate) |
| Operating lease Right-of-Use assets | Other non-current assets | $ | 871 |  | $ | 1,121 |  |  |
| Current operating lease liabilities | Accrued and other current liabilities | $ | 287 |  | $ | 328 |  |  |
| Non-current operating lease liabilities | Other non-current liabilities | 720 |  | 897 |  |  |
| Total operating lease liabilities |  | $ | 1,007 |  | $ | 1,225 |  |  |
| Weighted-average remaining lease term (in years) |  | 5.51 |  | 5.68 |  |  |
| Weighted-average discount rate |  | 3.01 | % |  | 3.23 | % |  |  |

[0001571996-22-000009:notes:209]
The following table presents supplemental cash flow information related to leases for the periods indicated:

[0001571996-22-000009:notes:210]
|  | Fiscal Year Ended |
|  | January 28, 2022 |  | January 29, 2021 |
|  | (in millions) |
| Cash paid for amounts included in the measurement of lease liabilities — operating cash outflows from operating leases (a) | $ | 459 |  |  | $ | 523 |  |
| Right-of-Use assets obtained in exchange for new operating lease liabilities | $ | 144 |  |  | $ | 548 |  |

[0001571996-22-000009:notes:211]
(a) Cash paid for amounts included in the measurement of lease liabilities - operating cash outflows from operating leases from discontinued operations was $135 million and $174 million for the fiscal years ended January 28, 2022 and January 29, 2021 respectively.

[0001571996-22-000009:notes:212]
The following table presents the future maturity of the Company’s operating lease liabilities under non-cancelable leases and reconciles the undiscounted cash flows for these leases to the lease liability recognized on the Consolidated Statements of Financial Position as of the date indicated:

[0001571996-22-000009:notes:213]
|  | January 28, 2022 |  |  |
|  | (in millions) |
| Fiscal 2023 | $ | 286 |  |  |  |
| Fiscal 2024 | 219 |  |  |  |
| Fiscal 2025 | 154 |  |  |  |
| Fiscal 2026 | 120 |  |  |  |
| Fiscal 2027 | 97 |  |  |  |
| Thereafter | 216 |  |  |  |
| Total lease payments | 1,092 |  |  |  |
| Less: Imputed interest | (85) |  |  |  |
| Total | $ | 1,007 |  |  |  |
| Current operating lease liabilities | $ | 287 |  |  |  |
| Non-current operating lease liabilities | $ | 720 |  |  |  |

[0001571996-22-000009:notes:214]
As of January 28, 2022, the Company’s undiscounted operating leases that had not yet commenced were immaterial.


## us-gaap:DebtDisclosureTextBlock

[0001571996-22-000009:notes:215]
DEBT
The following table summarizes the Company’s outstanding debt as of the dates indicated:

[0001571996-22-000009:notes:216]
During the fiscal year ended January 28, 2022, total outstanding debt decreased by $12.3 billion primarily as a result of principal repayments funded by proceeds from the VMware Spin-off special dividend of $9.3 billion and cash on hand.  The net decrease in the Company’s debt balance was attributable to repayments of $7.2 billion principal amount of Senior Notes, $6.3 billion principal amount of Senior Secured Credit Facilities, $1.0 billion principal amount of EMC Notes, and $0.4 billion principal amount of Legacy Notes and Debentures.  These decreases were partially offset by the issuance of $2.3 billion in aggregate principal amount of Senior Notes.

[0001571996-22-000009:notes:217]
2021 Debt Tender Offers

[0001571996-22-000009:notes:218]
On December 21, 2021, the Company completed tender offers for outstanding Senior Notes.  The transaction was funded with the net proceeds received from the December 13, 2021 issuance of $1.0 billion aggregate principal amount of 3.38% Senior Notes due December 15, 2041 and $1.3 billion aggregate principal amount of 3.45% Senior Notes due December 15, 2051, as well as $0.7 billion of cash and cash equivalents.

[0001571996-22-000009:notes:219]
As a result of the transaction, the Company retired $1.2 billion in aggregate principal amount of 8.35% Senior Notes due 2046 and $0.5 billion in aggregate principal amount of 8.10% Senior Notes due 2036.  The Company incurred $1.2 billion in debt extinguishment fees recognized in interest and other, net in the Consolidated Statements of Income.

[0001571996-22-000009:notes:220]
2021 Revolving Credit Facility

[0001571996-22-000009:notes:221]
On November 1, 2021, the Company entered into a new senior unsecured Revolving Credit Facility (the “2021 Revolving Credit Facility”) to replace the previous senior secured Revolving Credit Facility (the “Revolving Credit Facility”).  Following the full redemption of the outstanding term loan facilities and replacement of the Revolving Credit Facility, the credit agreement governing the Revolving Credit Facility (the “Previous Credit Agreement”) was terminated.

[0001571996-22-000009:notes:222]
The 2021 Revolving Credit Facility, which matures on November 1, 2026, provides the Company with revolving commitments in an aggregate principal amount of $5.0 billion for general corporate purposes and includes a letter of credit sub-facility of up to $0.5 billion and a swing-line loan sub-facility of up to $0.5 billion.  The 2021 Revolving Credit Facility also allows the Company to request incremental commitments on one or more occasions in minimum amounts of $10 million.

[0001571996-22-000009:notes:223]
The Company may conduct borrowings under the 2021 Revolving Credit Facility through London Interbank Offered Rate (“LIBOR”) borrowings or Base Rate Loan borrowings.  LIBOR borrowings bear interest at a rate per annum equal to the LIBOR, plus an applicable rate that varies based upon the Company’s existing debt ratings (the “applicable rate”).  Base Rate Loan borrowings bear interest at a rate per annum equal to the base rate plus the applicable rate.  The base rate is calculated based upon the greatest of the specified prime rate, the specified federal reserve bank rate, or LIBOR plus 1%.

[0001571996-22-000009:notes:224]
The borrowers may voluntarily repay outstanding loans under the 2021 Revolving Credit Facility at any time without premium or penalty, other than customary breakage costs.

[0001571996-22-000009:notes:225]
As of January 28, 2022, available borrowings under the 2021 Revolving Credit Facility totaled $5.0 billion.

[0001571996-22-000009:notes:226]
Outstanding Debt

[0001571996-22-000009:notes:227]
Senior Notes — The Company completed private offerings of multiple series of senior notes which were issued on June 1, 2016, June 22, 2016, March 20, 2019, April 9, 2020, and December 13, 2021 in aggregate principal amounts of $20.0 billion, $3.3 billion, $4.5 billion, $2.3 billion, and $2.3 billion respectively (the “Senior Notes”).  Interest on these borrowings is payable semiannually.

[0001571996-22-000009:notes:228]
In June 2021, Dell International L.L.C and EMC Corporation (the “Issuers”), wholly-owned subsidiaries of Dell Technologies, completed offers to exchange any and all outstanding Senior Notes issued on June 1,2016, March 20, 2019, and April 9, 2020 (the “First Lien Notes”) for first lien notes registered under the Securities Act of 1933 having terms substantially identical to the terms of the outstanding First Lien Notes.  The Issuers issued $18.4 billion aggregate principal amount of registered first lien notes in exchange for the same aggregate principal amount of First Lien Notes.  The aggregate principal amount of unregistered First Lien Notes remaining outstanding following the settlement of the exchange offers was approximately $0.1 billion.

[0001571996-22-000009:notes:229]
Such registered first lien notes, together with the remaining unregistered First Lien Notes, were previously secured on a pari passu basis with the Senior Secured Credit Facilities, on a first-priority basis by substantially all of the tangible and intangible assets of the issuers and guarantors that secured obligations under the Previous Credit Agreement, including pledges of all capital stock of the issuers, Dell Inc., a wholly-owned subsidiary of Dell Technologies Inc., and certain wholly-owned material subsidiaries of the issuers and the guarantors, subject to certain exceptions.

[0001571996-22-000009:notes:230]
Following the termination of the Previous Credit Agreement, and upon Dell Technologies receiving investment grade credit ratings, the tangible and intangible assets of the issuers and guarantors that secured obligations under the Senior Secured Credit Facilities were released as collateral.  As a result, the registered first lien notes and the remaining unregistered First Lien Notes are fully unsecured and are collectively referred to as “Senior Notes” in these Notes to the Consolidated Financial Statements.

[0001571996-22-000009:notes:231]
Legacy Notes and Debentures — The Company has outstanding unsecured notes and debentures (collectively, the “Legacy Notes and Debentures”) that were issued by Dell prior to the acquisition of Dell Inc. by Dell Technologies Inc. in the going-private transaction that closed in October 2013.  Interest on these borrowings is payable semiannually.

[0001571996-22-000009:notes:232]
DFS Debt — See Note 5 and Note 8 of the Notes to the Consolidated Financial Statements, respectively, for discussion of DFS debt and the interest rate swap agreements that hedge a portion of that debt.

[0001571996-22-000009:notes:233]
Covenants — The credit agreement governing the 2021 Revolving Credit Facility and the indentures governing the Senior Notes and the Legacy Notes and Debentures variously impose limitations, subject to exceptions, on creating certain liens and entering into sale and lease-back transactions.  The foregoing credit agreement and indentures contain customary events of default, including failure to make required payments, failure to comply with covenants, and the occurrence of certain events of bankruptcy and insolvency.  The 2021 Revolving Credit Facility is also subject to an interest coverage ratio covenant that is tested at the end of each fiscal quarter with respect to the Company’s preceding four fiscal quarters.   The Company was in compliance with financial covenants as of January 28, 2022.

[0001571996-22-000009:notes:234]
Aggregate Future Maturities

[0001571996-22-000009:notes:235]
The following tables presents the aggregate future maturities of the Company’s debt as of January 28, 2022 for the periods indicated:

[0001571996-22-000009:notes:236]
|  | Maturities by Fiscal Year |
|  | 2023 |  | 2024 |  | 2025 |  | 2026 |  | 2027 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Notes | $ | — |  |  | $ | 1,000 |  |  | $ | 1,000 |  |  | $ | 1,000 |  |  | $ | 6,250 |  |  | $ | 7,050 |  |  | $ | 16,300 |  |
| Legacy Notes and Debentures | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 952 |  |  | 952 |  |
| DFS Debt | 5,803 |  |  | 2,195 |  |  | 1,000 |  |  | 85 |  |  | 563 |  |  | — |  |  | 9,646 |  |
| Other | 25 |  |  | 173 |  |  | 116 |  |  | 20 |  |  | 1 |  |  | 2 |  |  | 337 |  |
| Total maturities, principal amount | 5,828 |  |  | 3,368 |  |  | 2,116 |  |  | 1,105 |  |  | 6,814 |  |  | 8,004 |  |  | 27,235 |  |
| Associated carrying value adjustments | (5) |  |  | (6) |  |  | (9) |  |  | (8) |  |  | (59) |  |  | (194) |  |  | (281) |  |
| Total maturities, carrying value amount | $ | 5,823 |  |  | $ | 3,362 |  |  | $ | 2,107 |  |  | $ | 1,097 |  |  | $ | 6,755 |  |  | $ | 7,810 |  |  | $ | 26,954 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001571996-22-000009:notes:237]
DERIVATIVE INSTRUMENTS AND HEDGING ACTIVITIES 
As part of its risk management strategy, the Company uses derivative instruments, primarily foreign currency forward and option contracts and interest rate swaps, to hedge certain foreign currency and interest rate exposures, respectively.

[0001571996-22-000009:notes:238]
The Company’s objective is to offset gains and losses resulting from these exposures with gains and losses on the derivative contracts used to hedge the exposures, thereby reducing volatility of earnings and protecting the fair values of assets and liabilities.  The earnings effects of the derivative instruments are presented in the same income statement line items as the earnings effects of the hedged items.  For derivatives designated as cash flow hedges, the Company assesses hedge effectiveness both at the onset of the hedge and at regular intervals throughout the life of the derivative.  The Company does not have any derivatives designated as fair value hedges.

[0001571996-22-000009:notes:239]
Foreign Exchange Risk

[0001571996-22-000009:notes:240]
The Company uses foreign currency forward and option contracts designated as cash flow hedges to protect against the foreign currency exchange rate risks inherent in its forecasted transactions denominated in currencies other than the U.S. Dollar.  Hedge accounting is applied based upon the criteria established by accounting guidance for derivative instruments and hedging activities.  The risk of loss associated with purchased options is limited to premium amounts paid for the option contracts.  The risk of loss associated with forward contracts is equal to the exchange rate differential from the time the contract is entered into until the time it is settled.  The majority of these contracts typically expire in twelve months or less.

[0001571996-22-000009:notes:241]
During the fiscal years ended January 28, 2022, January 29, 2021, and January 31, 2020, the Company did not discontinue any cash flow hedges related to foreign exchange contracts that had a material impact on the Company’s results of operations due to the probability that the forecasted cash flows would not occur.

[0001571996-22-000009:notes:242]
The Company uses forward contracts to hedge monetary assets and liabilities denominated in a foreign currency.  These contracts generally expire in three months or less, are considered economic hedges, and are not designated for hedge accounting.  The change in the fair value of these instruments represents a natural hedge as their gains and losses offset the changes in the underlying fair value of the monetary assets and liabilities due to movements in currency exchange rates.

[0001571996-22-000009:notes:243]
In connection with expanded offerings of DFS in Europe, forward contracts are used to hedge financing receivables denominated in foreign currencies other than Euro.  These contracts are not designated for hedge accounting and most expire within three years or less.

[0001571996-22-000009:notes:244]
Interest Rate Risk

[0001571996-22-000009:notes:245]
The Company uses interest rate swaps to hedge the variability in cash flows related to the interest rate payments on structured financing debt.  The interest rate swaps economically convert the variable rate on the structured financing debt to a fixed interest rate to match the underlying fixed rate being received on fixed-term customer leases and loans.  These contracts are not designated for hedge accounting and most expire within four years or less.

[0001571996-22-000009:notes:246]
Interest rate swaps are utilized to manage the interest rate risk, at a portfolio level, associated with DFS operations in Europe.  The interest rate swaps economically convert the fixed rate on financing receivables to a three-month Euribor floating rate in order to match the floating rate nature of the banks’ funding pool.  These contracts are not designated for hedge accounting and most expire within five years or less.

[0001571996-22-000009:notes:247]
The Company utilizes cross-currency amortizing swaps to hedge the currency and interest rate risk exposure associated with the European securitization program.  The cross currency swaps combine a Euro-based interest rate swap with a British Pound or U.S. Dollar foreign exchange forward contract in which the Company pays a fixed British Pound or U.S. Dollar amount and receives a floating amount in Euros linked to the one-month Euribor.  The notional value of the swaps amortizes in line with the expected cash flows and run-off of the securitized assets.  The swaps are not designated for hedge accounting and expire within five years or less.

[0001571996-22-000009:notes:248]
Derivative Instruments

[0001571996-22-000009:notes:249]
Notional Amounts of Outstanding Derivative Instruments

[0001571996-22-000009:notes:250]
|  | January 28, 2022 |  | January 29, 2021 |
|  | (in millions) |
| Foreign exchange contracts: |  |  |  |
| Designated as cash flow hedging instruments | $ | 7,879 |  |  | $ | 6,840 |  |
| Non-designated as hedging instruments | 8,713 |  |  | 9,890 |  |
| Total (a) | $ | 16,592 |  |  | $ | 16,730 |  |
| Interest rate contracts: |  |  |  |
| Non-designated as hedging instruments | $ | 6,715 |  |  | $ | 5,859 |  |

[0001571996-22-000009:notes:251]
(a)    Total foreign exchange contracts attributable to discontinued operations was $1.7 billion as of January 29, 2021.

[0001571996-22-000009:notes:252]
Effect of Derivative Instruments Designated as Hedging Instruments on the Consolidated Statements of Financial Position and the Consolidated Statements of Income

[0001571996-22-000009:notes:253]
| Derivatives in Cash Flow Hedging Relationships |  | Gain (Loss) Recognized in Accumulated OCI, Net of Tax, on Derivatives |  | Location of Gain (Loss) Reclassified from Accumulated OCI into Income |  | Gain (Loss) Reclassified from Accumulated OCI into Income |
|  |  | (in millions) |  |  |  | (in millions) |
| For the fiscal year ended January 28, 2022 |
|  |  |  |  | Total net revenue |  | $ | 158 |  |
| Foreign exchange contracts |  | $ | 374 |  |  | Total cost of net revenue |  | (3) |  |
| Interest rate contracts |  | — |  |  | Interest and other, net |  | — |  |
| Total |  | $ | 374 |  |  | Income from discontinued operations |  | 3 |  |
|  |  |  |  | Total |  | $ | 158 |  |
| For the fiscal year ended January 29, 2021 |
|  |  |  |  | Total net revenue |  | $ | (98) |  |
| Foreign exchange contracts |  | $ | (200) |  |  | Total cost of net revenue |  | 5 |  |
| Interest rate contracts |  | — |  |  | Interest and other, net |  | — |  |
| Total |  | $ | (200) |  |  | Income from discontinued operations |  | (7) |  |
|  |  |  |  | Total |  | $ | (100) |  |
| For the fiscal year ended January 31, 2020 |
|  |  |  |  | Total net revenue |  | $ | 217 |  |
| Foreign exchange contracts |  | $ | 269 |  |  | Total cost of net revenue |  | — |  |
| Interest rate contracts |  | — |  |  | Interest and other, net |  | — |  |
| Total |  | $ | 269 |  |  | Income from discontinued operations |  | 9 |  |
|  |  |  |  | Total |  | $ | 226 |  |

[0001571996-22-000009:notes:254]
Effect of Derivative Instruments Not Designated as Hedging Instruments on the Consolidated Statements of Income

[0001571996-22-000009:notes:255]
|  | Fiscal Year Ended |  |  |
|  | January 28, 2022 |  | January 29, 2021 |  | January 31, 2020 |  | Location of Gain (Loss) Recognized |
|  | (in millions) |  |  |
| Foreign exchange contracts | $ | (469) |  |  | $ | 169 |  |  | $ | (206) |  |  | Interest and other, net |
| Interest rate contracts | 10 |  |  | (45) |  |  | (28) |  |  | Interest and other, net |
| Foreign exchange contracts | 26 |  |  | (62) |  |  | 54 |  |  | Income from discontinued operations |
| Total | $ | (433) |  |  | $ | 62 |  |  | $ | (180) |  |  |  |

[0001571996-22-000009:notes:256]
Fair Value of Derivative Instruments in the Consolidated Statements of Financial Position

[0001571996-22-000009:notes:257]
The Company presents its foreign exchange derivative instruments on a net basis in the Consolidated Statements of Financial Position due to the right of offset by its counterparties under master netting arrangements.  The following tables present the fair value of those derivative instruments presented on a gross basis as the dates indicated:

[0001571996-22-000009:notes:258]
|  | January 28, 2022 |
|  | Other CurrentAssets |  | Other Non-Current Assets |  | Other CurrentLiabilities |  | Other Non-CurrentLiabilities |  | TotalFair Value |
|  | (in millions) |
| Derivatives designated as hedging instruments: |
| Foreign exchange contracts in an asset position | $ | 135 |  |  | $ | — |  |  | $ | 50 |  |  | $ | — |  |  | $ | 185 |  |
| Foreign exchange contracts in a liability position | (5) |  |  | — |  |  | (8) |  |  | — |  |  | (13) |  |
| Net asset (liability) | 130 |  |  | — |  |  | 42 |  |  | — |  |  | 172 |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts in an asset position | 280 |  |  | 2 |  |  | 106 |  |  | — |  |  | 388 |  |
| Foreign exchange contracts in a liability position | (189) |  |  | — |  |  | (244) |  |  | (5) |  |  | (438) |  |
| Interest rate contracts in an asset position | — |  |  | 30 |  |  | — |  |  |  |  | 30 |  |
| Interest rate contracts in a liability position | — |  |  | — |  |  | — |  |  | (37) |  |  | (37) |  |
| Net asset (liability) | 91 |  |  | 32 |  |  | (138) |  |  | (42) |  |  | (57) |  |
| Total derivatives at fair value | $ | 221 |  |  | $ | 32 |  |  | $ | (96) |  |  | $ | (42) |  |  | $ | 115 |  |
|  | January 29, 2021 |
|  | Other CurrentAssets |  | Other Non-Current Assets |  | Other CurrentLiabilities |  | Other Non-CurrentLiabilities |  | TotalFair Value |
|  | (in millions) |
| Derivatives designated as hedging instruments: |
| Foreign exchange contracts in an asset position | $ | 28 |  |  | $ | — |  |  | $ | 18 |  |  | $ | — |  |  | $ | 46 |  |
| Foreign exchange contracts in a liability position | (10) |  |  | — |  |  | (14) |  |  | — |  |  | (24) |  |
| Net asset (liability) | 18 |  |  | — |  |  | 4 |  |  | — |  |  | 22 |  |
| Derivatives not designated as hedging instruments: |
| Foreign exchange contracts in an asset position | 175 |  |  | — |  |  | 58 |  |  | — |  |  | 233 |  |
| Foreign exchange contracts in a liability position | (108) |  |  | — |  |  | (155) |  |  | (4) |  |  | (267) |  |
| Interest rate contracts in an asset position | — |  |  | 10 |  |  | — |  |  | — |  |  | 10 |  |
| Interest rate contracts in a liability position | — |  |  | — |  |  | — |  |  | (31) |  |  | (31) |  |
| Net asset (liability) | 67 |  |  | 10 |  |  | (97) |  |  | (35) |  |  | (55) |  |
| Total derivatives at fair value | $ | 85 |  |  | $ | 10 |  |  | $ | (93) |  |  | $ | (35) |  |  | $ | (33) |  |

[0001571996-22-000009:notes:259]
The following tables present the gross amounts of the Company’s derivative instruments, amounts offset due to master netting agreements with the Company’s counterparties, and the net amounts recognized in the Consolidated Statements of Financial Position as of the dates indicated:

[0001571996-22-000009:notes:260]
|  | January 28, 2022 |
|  | Gross Amounts of Recognized Assets/ (Liabilities) |  | Gross Amounts Offset in the Statement of Financial Position |  | Net Amounts of Assets/ (Liabilities) Presented in the Statement of Financial Position |  | Gross Amounts not Offset in the Statement of Financial Position |  | Net Amount of Assets/ (Liabilities) Recognized in the Statement of Financial Position |
|  | Financial Instruments |  | Cash Collateral Received or Pledged |  |
|  | (in millions) |
| Derivative instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Financial assets | $ | 603 |  |  | $ | (350) |  |  | $ | 253 |  |  | $ | — |  |  | $ | — |  |  | $ | 253 |  |
| Financial liabilities | (488) |  |  | 350 |  |  | (138) |  |  | — |  |  | 24 |  |  | (114) |  |
| Total derivative instruments | $ | 115 |  |  | $ | — |  |  | $ | 115 |  |  | $ | — |  |  | $ | 24 |  |  | $ | 139 |  |
|  | January 29, 2021 |
|  | Gross Amounts of Recognized Assets/ (Liabilities) |  | Gross Amounts Offset in the Statement of Financial Position |  | Net Amounts of Assets/ (Liabilities) Presented in the Statement of Financial Position |  | Gross Amounts not Offset in the Statement of Financial Position |  | Net Amount of Assets/ (Liabilities) Recognized in the Statement of Financial Position |
|  | Financial Instruments |  | Cash Collateral Received or Pledged |  |
|  | (in millions) |
| Derivative instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Financial assets | $ | 289 |  |  | $ | (194) |  |  | $ | 95 |  |  | $ | — |  |  | $ | — |  |  | $ | 95 |  |
| Financial liabilities | (322) |  |  | 194 |  |  | (128) |  |  | — |  |  | 2 |  |  | (126) |  |
| Total derivative instruments | $ | (33) |  |  | $ | — |  |  | $ | (33) |  |  | $ | — |  |  | $ | 2 |  |  | $ | (31) |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001571996-22-000009:notes:261]
GOODWILL AND INTANGIBLE ASSETS
Goodwill

[0001571996-22-000009:notes:262]
The Infrastructure Solutions Group and Client Solutions Group reporting units are consistent with the reportable segments identified in Note 19 of the Notes to the Consolidated Financial Statements.  Other businesses consists of VMware Resale, Secureworks and Virtustream which each represent separate reporting units.

[0001571996-22-000009:notes:263]
The following table presents goodwill allocated to the Company’s reportable segments and changes in the carrying amount of goodwill as of the dates indicated:

[0001571996-22-000009:notes:264]
|  | Infrastructure Solutions Group |  | Client Solutions Group |  | Other Businesses |  | Total |
|  | (in millions) |
| Balances as of January 31, 2020 | $ | 15,089 |  |  | $ | 4,237 |  |  | $ | 1,833 |  |  | $ | 21,159 |  |
| Goodwill acquired | — |  |  | — |  |  | 9 |  |  | 9 |  |
| Impact of foreign currency translation | 236 |  |  | — |  |  | 9 |  |  | 245 |  |
| Goodwill divested (a) | — |  |  | — |  |  | (1,385) |  |  | (1,385) |  |
| Balances as of January 29, 2021 | 15,325 |  |  | 4,237 |  |  | 466 |  |  | 20,028 |  |
| Impact of foreign currency translation | (219) |  |  | — |  |  | — |  |  | (219) |  |
| Goodwill divested (b) | — |  |  | — |  |  | (39) |  |  | (39) |  |
| Balances as of January 28, 2022 | $ | 15,106 |  |  | $ | 4,237 |  |  | $ | 427 |  |  | $ | 19,770 |  |

[0001571996-22-000009:notes:265]
(a)    During the fiscal year ended January 29, 2021, Dell Technologies completed its sale of RSA Security.  Prior to the divestiture, RSA Security was included within other businesses.  See Note 1 of the Notes to the Consolidated Financial Statements for additional information about the divestiture of RSA Security.

[0001571996-22-000009:notes:266]
(b)    During the fiscal year ended January 28, 2022, Dell Technologies completed its sale of Boomi.  Prior to the divestiture, Boomi was included within other businesses.  See Note 1 of the Notes to the Consolidated Financial Statements for additional information about the divestiture of Boomi.

[0001571996-22-000009:notes:267]
Intangible Assets

[0001571996-22-000009:notes:268]
The following table presents the Company’s intangible assets as of the dates indicated:

[0001571996-22-000009:notes:269]
|  | January 28, 2022 |  | January 29, 2021 |
|  | Gross |  | AccumulatedAmortization |  | Net |  | Gross |  | AccumulatedAmortization |  | Net |
|  | (in millions) |
| Customer relationships | $ | 16,956 |  |  | $ | (13,938) |  |  | $ | 3,018 |  |  | $ | 16,964 |  |  | $ | (12,929) |  |  | $ | 4,035 |  |
| Developed technology | 9,635 |  |  | (8,405) |  |  | 1,230 |  |  | 9,659 |  |  | (7,834) |  |  | 1,825 |  |
| Trade names | 885 |  |  | (757) |  |  | 128 |  |  | 885 |  |  | (715) |  |  | 170 |  |
| Definite-lived intangible assets | 27,476 |  |  | (23,100) |  |  | 4,376 |  |  | 27,508 |  |  | (21,478) |  |  | 6,030 |  |
| Indefinite-lived trade names | 3,085 |  |  | — |  |  | 3,085 |  |  | 3,085 |  |  | — |  |  | 3,085 |  |
| Total intangible assets | $ | 30,561 |  |  | $ | (23,100) |  |  | $ | 7,461 |  |  | $ | 30,593 |  |  | $ | (21,478) |  |  | $ | 9,115 |  |

[0001571996-22-000009:notes:270]
Amortization expense related to definite-lived intangible assets was approximately $1.6 billion, $2.1 billion, and $3.0 billion for the fiscal years ended January 28, 2022, January 29, 2021, and January 31, 2020, respectively.  There were no material impairment charges related to intangible assets during the fiscal years ended January 28, 2022 and January 29, 2021.  During the fiscal year ended January 31, 2020, the Company recognized an impairment charge of approximately $266 million related to Virtustream intangible assets, net and within in Selling, general, and administrative in the Consolidated Statements of Income.

[0001571996-22-000009:notes:271]
During the fiscal year ended January 29, 2021, the Company recognized proceeds and a gain of $120 million from the sale of certain internally developed intellectual property assets.

[0001571996-22-000009:notes:272]
The following table presents the estimated future annual pre-tax amortization expense of definite-lived intangible assets as of the date indicated:

[0001571996-22-000009:notes:273]
|  | January 28, 2022 |
|  | (in millions) |
| Fiscal 2023 | $ | 977 |  |
| Fiscal 2024 | 776 |  |
| Fiscal 2025 | 607 |  |
| Fiscal 2026 | 474 |  |
| Fiscal 2027 | 361 |  |
| Thereafter | 1,181 |  |
| Total | $ | 4,376 |  |

[0001571996-22-000009:notes:274]
Goodwill and Intangible Assets Impairment Testing

[0001571996-22-000009:notes:275]
Goodwill and indefinite-lived intangible assets are tested for impairment annually during the third fiscal quarter and whenever events or circumstances may indicate that an impairment has occurred.

[0001571996-22-000009:notes:276]
For the annual impairment review in the third quarter of Fiscal 2022, the Company elected to bypass the assessment of qualitative factors to determine whether it was more likely than not that the fair value of a reporting unit was less than its carrying amount, including goodwill.  In electing to bypass the qualitative assessment, the Company proceeded directly to perform a quantitative goodwill impairment test to measure the fair value of each goodwill reporting unit relative to its carrying amount, and to determine the amount of goodwill impairment loss to be recognized, if any.

[0001571996-22-000009:notes:277]
Management exercised significant judgment related to the above assessment, including the identification of goodwill reporting units, assignment of assets and liabilities to goodwill reporting units, assignment of goodwill to reporting units, and determination of the fair value of each goodwill reporting unit.  The fair value of each goodwill reporting unit is generally estimated using a combination of public company multiples and discounted cash flow methodologies, except with respect to Secureworks, which is a publicly-traded entity, in which case the fair value is determined based primarily on the public company market valuation.  The discounted cash flow and public company multiples methodologies require significant judgment, including estimation of future revenues, gross margins, and operating expenses, which are dependent on internal forecasts, current and anticipated economic conditions and trends, selection of market multiples through assessment of the reporting unit’s performance relative to peer competitors, the estimation of the long-term revenue growth rate and discount rate of the Company’s business, and the determination of the Company’s weighted average cost of capital.  Changes in these estimates and assumptions could materially affect the fair value of the goodwill reporting unit, potentially resulting in a non-cash impairment charge.

[0001571996-22-000009:notes:278]
The fair value of the indefinite-lived trade names is generally estimated using discounted cash flow methodologies.  The discounted cash flow methodology requires significant judgment, including estimation of future revenue, the estimation of the long-term revenue growth rate of the Company’s business and the determination of the Company’s weighted average cost of capital and royalty rates.  Changes in these estimates and assumptions could materially affect the fair value of the indefinite-lived intangible assets, potentially resulting in a non-cash impairment charge.

[0001571996-22-000009:notes:279]
Based on the results of the annual impairment test performed during the fiscal year ended January 28, 2022, the fair values of each of the reporting units exceeded their carrying values.  No impairment test was performed during the fiscal year ended January 28, 2022 other than the Company’s annual impairment review.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001571996-22-000009:notes:280]
DEFERRED REVENUE 
Deferred Revenue — Deferred revenue is recorded for support and deployment services, software maintenance, professional services, training, and Software-as-a-Service when the Company has invoiced or payments have been received for undelivered products or services where transfer of control has not occurred.  Revenue is recognized on these items when the revenue recognition criteria are met, generally resulting in ratable recognition over the contract term.  The Company also has deferred revenue related to undelivered hardware and professional services, consisting of installations and consulting engagements, which is recognized as the Company’s performance obligations under the contract are completed.

[0001571996-22-000009:notes:281]
The following table presents the changes in the Company’s deferred revenue for the periods indicated:

[0001571996-22-000009:notes:282]
|  | Fiscal Year Ended |
|  | January 28, 2022 |  | January 29, 2021 |
|  | (in millions) |
| Deferred revenue: |  |  |  |
| Deferred revenue at beginning of period | $ | 25,592 |  |  | $ | 22,539 |  |
| Revenue deferrals | 20,968 |  |  | 20,412 |  |
| Revenue recognized | (18,843) |  |  | (17,098) |  |
| Other (a) | (144) |  |  | (261) |  |
| Deferred revenue at end of period | $ | 27,573 |  |  | $ | 25,592 |  |
| Short-term deferred revenue | $ | 14,261 |  |  | $ | 13,201 |  |
| Long-term deferred revenue | $ | 13,312 |  |  | $ | 12,391 |  |

[0001571996-22-000009:notes:283]
(a)    For the fiscal year ended January 28, 2022, Other consists of divested deferred revenue from the sale of Boomi.  For the fiscal year ended January 29, 2021, Other consists of divested deferred revenue from the sale of RSA Security.  See Note 1 of the Notes to the Consolidated Financial Statements for more information about the divestitures of Boomi and RSA Security.

[0001571996-22-000009:notes:284]
Remaining Performance Obligations — Remaining performance obligations represent the aggregate amount of the transaction price allocated to performance obligations not delivered, or partially undelivered, as of the end of the reporting period.  Remaining performance obligations include deferred revenue plus unbilled amounts not yet recorded in deferred revenue.  The value of the transaction price allocated to remaining performance obligations as of January 28, 2022 was approximately $42 billion.  The Company expects to recognize approximately 62% of remaining performance obligations as revenue in the next twelve months, and the remainder thereafter.

[0001571996-22-000009:notes:285]
The aggregate amount of the transaction price allocated to remaining performance obligations does not include amounts owed under cancelable contracts where there is no substantive termination penalty.  The Company applied the practical expedient to exclude the value of remaining performance obligations for contracts for which revenue is recognized at the amount to which the Company has the right to invoice for services performed.

[0001571996-22-000009:notes:286]
Remaining performance obligation estimates are subject to change and are affected by several factors, including terminations, changes in the scope of contracts, periodic revalidation, adjustments for revenue that have not materialized, and adjustments for currency.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001571996-22-000009:notes:287]
COMMITMENTS AND CONTINGENCIES 
Purchase Obligations

[0001571996-22-000009:notes:288]
The Company has contractual obligations to purchase goods or services, which specify significant terms, (including fixed or minimum quantities to be purchased), fixed, minimum, or variable price provisions; and the approximate timing of the transaction.  As of January 28, 2022, such purchase obligations were $5.6 billion, $0.3 billion, and $0.4 billion for fiscal 2023, fiscal 2024, and fiscal 2025 and thereafter, respectively.

[0001571996-22-000009:notes:289]
Legal Matters

[0001571996-22-000009:notes:290]
The Company is involved in various claims, suits, assessments, investigations, and legal proceedings that arise from time to time in the ordinary course of its business, including those identified below, consisting of matters involving consumer, antitrust, tax, intellectual property, and other issues on a global basis.  Pursuant to the Separation and Distribution Agreement referred to below, Dell Technologies shares responsibility with VMware for certain matters, as indicated below, and VMware has agreed to indemnify Dell Technologies in whole or in part with respect to certain matters.

[0001571996-22-000009:notes:291]
The Company accrues a liability when it believes that it is both probable that a liability has been incurred and that it can reasonably estimate the amount of the loss.  The Company reviews these accruals at least quarterly and adjusts them to reflect ongoing negotiations, settlements, rulings, advice of legal counsel, and other relevant information.  To the extent new information is obtained and the Company’s views on the probable outcomes of claims, suits, assessments, investigations, or legal proceedings change, changes in the Company’s accrued liabilities are recorded in the period in which such a determination is made.  For some matters, the amount of liability is not probable or the amount cannot be reasonably estimated and therefore accruals have not been made.

[0001571996-22-000009:notes:292]
The following is a discussion of the Company’s significant legal matters and other proceedings:

[0001571996-22-000009:notes:293]
Class Actions Related to the Class V Transaction — On December 28, 2018, the Company completed a transaction (the “Class V transaction”) in which it paid $14.0 billion in cash and issued 149,387,617 shares of its Class C Common Stock to holders of its Class V Common Stock in exchange for all outstanding shares of Class V Common Stock.  As a result of the Class V transaction, the tracking stock feature of the Company’s capital structure associated with the Class V Common Stock was terminated.  In November 2018, four purported stockholders brought putative class action complaints arising out of the Class V transaction.  The actions were captioned Hallandale Beach Police and Fire Retirement Plan v. Michael Dell et al. (Civil Action No. 2018-0816-JTL), Howard Karp v. Michael Dell et al. (Civil Action No. 2019-0032-JTL), Miramar Police Officers’ Retirement Plan v. Michael Dell et al. (Civil Action No. 2019-0049-JTL), and Steamfitters Local 449 Pension Plan v. Michael Dell et al. (Civil Action No. 2019-0115-JTL).  The four actions were consolidated in the Delaware Chancery Court into In Re Dell Class V Litigation (Consol. C.A. No. 2018-0816-JTL).  The suit currently names as defendants certain of the directors serving on the board of directors at the time of the Class V transaction, certain stockholders of the Company, consisting of Michael S. Dell and Silver Lake Group LLC and certain of its affiliated funds, and Goldman Sachs & Co. LLC (“Goldman Sachs”), which served as financial advisor to the Company in connection with the Class V transaction.  In an amended complaint filed in August 2019,  the plaintiffs generally alleged that the director and stockholder defendants breached their fiduciary duties under Delaware law to the former holders of Class V Common Stock in connection with the Class V transaction by allegedly causing the Company to enter into a transaction that favored the interests of the controlling stockholders at the expense of such former stockholders, thereby depriving the former stockholders of the fair value of their shares.  On August 20, 2021, the plaintiffs added Goldman Sachs as a defendant and alleged that it had aided and abetted the alleged primary violations.  In the complaint, the plaintiffs seek, among other remedies, a judicial declaration that the director and stockholder defendants breached their fiduciary duties.  The plaintiffs also seek disgorgement of all profits, benefits, and other compensation obtained by the defendants as a result of such alleged conduct and an award of unspecified damages, fees, and costs.  The defendants filed a motion to dismiss the action in September 2019.  The court denied the motion in June 2020 and the case is currently in the discovery phase.  Trial is scheduled to begin on December 5, 2022.  The Company is not a defendant in this action but is subject to director indemnification provisions under its certificate of incorporation and bylaws, and is a party to agreements with the defendants that contain indemnification obligations of the Company, conditioned on the satisfaction of the requirements set forth in such agreements, relating to service as a director, ownership of the Company’s securities, and provision of services, as applicable.

[0001571996-22-000009:notes:294]
Class Actions Related to VMware, Inc.’s Acquisition of Pivotal — Two purported stockholders brought putative class action complaints arising out of VMware, Inc.’s acquisition of Pivotal Software, Inc. on December 30, 2019.  The two actions were consolidated in the Delaware Chancery Court into In re: Pivotal Software, Inc. Stockholders Litigation (Civil Action No. 2020-0440-KSJM).  The complaint names as defendants the Company, VMware, Inc., Michael S. Dell, and certain officers of Pivotal.  The plaintiffs generally allege that the defendants breached their fiduciary duties to the former holders of Pivotal Class A Common Stock in connection with VMware, Inc.’s acquisition of Pivotal by allegedly causing Pivotal to enter into a transaction that favored the interests of Pivotal’s controlling stockholders at the expense of such former stockholders.  The plaintiffs seek, among other remedies, a judicial declaration that the defendants breached their fiduciary duties and an award of damages, fees, and costs.  Trial is scheduled to begin on July 6, 2022.

[0001571996-22-000009:notes:295]
Other Litigation — Dell does not currently anticipate that any of the other various legal proceedings it is involved in will have a material adverse effect on its business, financial condition, results of operations, or cash flows.

[0001571996-22-000009:notes:296]
In accordance with the relevant accounting guidance, the Company provides disclosures of matters where it is at least reasonably possible that the Company could experience a material loss exceeding the amounts already accrued for these or other proceedings or matters.  In addition, the Company also discloses matters based on its consideration of other matters and qualitative factors, including the experience of other companies in the industry, and investor, customer, and employee relations considerations.  As of January 28, 2022, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for these or other proceedings or matters has been incurred.  However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company’s business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters.  Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company’s business, financial condition, results of operations, or cash flows will depend on a number of factors, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.

[0001571996-22-000009:notes:297]
Indemnifications Obligations

[0001571996-22-000009:notes:298]
In the ordinary course of business, the Company enters into various contracts under which it may agree to indemnify other parties for losses incurred from certain events as defined in the relevant contract, such as litigation, regulatory penalties, or claims relating to past performance.  Such indemnification obligations may not be subject to maximum loss clauses.  Historically, payments related to these indemnification obligations have not been material to the Company.

[0001571996-22-000009:notes:299]
Under the Separation and Distribution Agreement described in Note 3 of the Notes to the Consolidated Financial Statements, Dell Technologies has agreed to indemnify VMware, Inc., each of its subsidiaries and each of their respective directors, officers and employees from and against all liabilities relating to, arising out of or resulting from, among other matters, the liabilities allocated to Dell Technologies as part of the separation of  Dell Technologies and VMware and their respective businesses as a result of the VMware Spin-off (the “Separation”).  VMware similarly has agreed to indemnify Dell Technologies, Inc., each of its subsidiaries and each of their respective directors, officers, and employees from and against all liabilities relating to, arising out of or resulting from, among other matters, the liabilities allocated to VMware as part of the Separation.  Dell Technologies expects VMware to fully perform under the terms of the Separation and Distribution Agreement.

[0001571996-22-000009:notes:300]
For information on the cross-indemnifications related to the tax matters agreement between the Company and VMware described in Note 3 of the Notes to the Consolidated Financial Statements effective upon the Separation on November 1, 2021, see Note 3 and Note 21 of the Notes to the Consolidated Financial Statements.

[0001571996-22-000009:notes:301]
Certain Concentrations

[0001571996-22-000009:notes:302]
The Company maintains cash and cash equivalents, derivatives, and certain other financial instruments with various financial institutions that potentially subject it to concentration of credit risk.  As part of its risk management processes, the Company performs periodic evaluations of the relative credit standing of these financial institutions.  The Company has not sustained material credit losses from instruments held at these financial institutions.  Further, the Company does not anticipate nonperformance by any of the counterparties.

[0001571996-22-000009:notes:303]
The Company markets and sells its products and services to large corporate clients, governments, and health care and education accounts, as well as to small and medium-sized businesses and individuals.  No single customer accounted for more than 10%

[0001571996-22-000009:notes:304]
of the Company’s consolidated net revenue during the fiscal year ended January 28, 2022, January 29, 2021, or January 31, 2020.

[0001571996-22-000009:notes:305]
The Company utilizes a limited number of contract manufacturers that assemble a portion of its products.  The Company may purchase components from suppliers and sell those components to such contract manufacturers, thereby creating receivables balances from the contract manufacturers.  The agreements with the majority of the contract manufacturers permit the Company to offset its payables against these receivables, thus mitigating the credit risk wholly or in part.  Receivables from the Company’s four largest contract manufacturers represented the majority of the Company’s gross non-trade receivables of $5.7 billion and $4.1 billion as of January 28, 2022 and January 29, 2021, respectively, of which $4.2 billion and $3.1 billion as of January 28, 2022 and January 29, 2021, respectively, have been offset against the corresponding payables.  The portion of receivables not offset against payables is included in other current assets in the Consolidated Statements of Financial Position.  The Company does not reflect the sale of the components in revenue and does not recognize any profit on the component sales until the related products are sold.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001571996-22-000009:notes:306]
INCOME AND OTHER TAXES
The following table presents components of the income tax expense (benefit) for continuing operations recognized for the periods indicated:

[0001571996-22-000009:notes:307]
|  | Fiscal Year Ended |
|  | January 28, 2022 |  | January 29, 2021 |  | January 31, 2020 |
|  | (in millions) |
| Current: |  |  |  |  |  |
| Federal | $ | 166 |  |  | $ | (514) |  |  | $ | (144) |  |
| State/local | 76 |  |  | (22) |  |  | 41 |  |
| Foreign | 960 |  |  | 825 |  |  | 647 |  |
| Current | 1,202 |  |  | 289 |  |  | 544 |  |
| Deferred: |  |  |  |  |  |
| Federal | (54) |  |  | (16) |  |  | (404) |  |
| State/local | — |  |  | (115) |  |  | (90) |  |
| Foreign | (167) |  |  | (57) |  |  | (622) |  |
| Deferred | (221) |  |  | (188) |  |  | (1,116) |  |
| Income tax expense (benefit) | $ | 981 |  |  | $ | 101 |  |  | $ | (572) |  |

[0001571996-22-000009:notes:308]
The following table presents components of income (loss) before income taxes for continuing operations for the periods indicated:

[0001571996-22-000009:notes:309]
|  | Fiscal Year Ended |
|  | January 28, 2022 |  | January 29, 2021 |  | January 31, 2020 |
|  | (in millions) |
| Domestic | $ | 1,414 |  |  | $ | (1,361) |  |  | $ | (2,894) |  |
| Foreign | 4,509 |  |  | 3,707 |  |  | 2,843 |  |
| Income (loss) before income taxes | $ | 5,923 |  |  | $ | 2,346 |  |  | $ | (51) |  |

[0001571996-22-000009:notes:310]
The following table presents a reconciliation of the Company’s effective tax rate to the statutory U.S. federal tax rate for continuing operations for the periods indicated:

[0001571996-22-000009:notes:311]
|  | Fiscal Year Ended |
|  | January 28, 2022 |  | January 29, 2021 |  | January 31, 2020 |
| U.S. federal statutory rate | 21.0 | % |  | 21.0 | % |  | 21.0 | % |
| State income taxes, net of federal tax benefit | 1.7 |  |  | (3.5) |  |  | 45.1 |  |
| Tax impact of foreign operations | (0.3) |  |  | 8.9 |  |  | (274.5) |  |
| Impact of intangible property transfers | — |  |  | — |  |  | 794.1 |  |
| Change in valuation allowance | 0.4 |  |  | — |  |  | (233.3) |  |
| U.S. tax audit settlement | — |  |  | (31.8) |  |  | 598.0 |  |
| Non-deductible transaction-related costs | 1.2 |  |  | 1.0 |  |  | (35.3) |  |
| Stock-based compensation expense | (2.4) |  |  | (3.2) |  |  | 243.1 |  |
| U.S. R&D tax credits | (1.3) |  |  | (2.5) |  |  | 121.6 |  |
| Legal entity restructuring | (4.1) |  |  | — |  |  | — |  |
| RSA Security divestiture | — |  |  | 12.3 |  |  | — |  |
| Other | 0.4 |  |  | 2.1 |  |  | (158.2) |  |
| Total | 16.6 | % |  | 4.3 | % |  | 1121.6 | % |

[0001571996-22-000009:notes:312]
The changes in the Company’s effective tax rates for all periods presented were primarily driven by discrete tax items and a change in the Company’s jurisdictional mix of income.

[0001571996-22-000009:notes:313]
The Company’s effective tax rate for the fiscal year ended January 28, 2022 includes tax expense of $1.0 billion on a pre-tax gain of $4.0 billion related to the divestiture of Boomi during the period, as well as tax benefits of $367 million on $1.6 billion of debt extinguishment fees and $244 million related to the restructuring of certain legal entities.  The Company’s effective tax rate for the fiscal year ended January 29, 2021 includes tax benefits of $746 million related to an audit settlement and tax expense of $359 million on pre-tax gain of $338 million relating to the divestiture of RSA Security during the period.  The Company’s effective tax rate for the fiscal year ended January 31, 2020 includes tax benefits of $405 million related to an intra-entity asset transfer and $305 million related to an audit settlement.  The intra-entity asset transfer was of certain intellectual property to an Irish subsidiary.

[0001571996-22-000009:notes:314]
The differences between the Company’s effective income tax rates and the U.S. federal statutory rate of 21% principally result from the geographical distribution of income, differences between the book and tax treatment of certain items, and the discrete tax items discussed above.  In certain jurisdictions, the Company’s tax rate is significantly less than the applicable statutory rate as a result of tax holidays.  The majority of the Company’s foreign income that is subject to these tax holidays is attributable to Singapore and China.  A significant portion of these income tax benefits relate to a tax holiday that will be effective until January 31, 2029.  The Company’s other tax holidays will expire in whole or in part during fiscal years 2030 through 2031.  Many of these tax holidays and reduced tax rates may be extended when certain conditions are met or may be terminated early if certain conditions are not met.  As of January 28, 2022, the Company was not aware of any matters of noncompliance related to these tax holidays.  For the fiscal years ended January 28, 2022, January 29, 2021, and January 31, 2020, the income tax benefits attributable to the tax status of the affected subsidiaries were estimated to be approximately $466 million ($0.59 per share), $359 million ($0.47 per share), and $444 million ($0.59 per share), respectively.  These income tax benefits are included in tax impact of foreign operations in the table above.

[0001571996-22-000009:notes:315]
The Company believes that a significant portion of the Company’s undistributed earnings as of January 28, 2022 will not be subject to further U.S. federal taxation.  As of January 28, 2022, the Company has undistributed earnings of certain foreign subsidiaries of approximately $36.5 billion that remain indefinitely reinvested, and as such has not recognized a deferred tax liability.  Determination of the amount of unrecognized deferred income tax liability related to these undistributed earnings is not practicable.

[0001571996-22-000009:notes:316]
The following table presents the components of the Company’s net deferred tax assets (liabilities) as of the dates indicated:

[0001571996-22-000009:notes:317]
|  | January 28, 2022 |  | January 29, 2021 |
|  | (in millions) |
| Deferred tax assets: |  |  |  |
| Deferred revenue and warranty provisions | $ | 1,555 |  |  | $ | 1,493 |  |
| Provisions for product returns and doubtful accounts | 95 |  |  | 132 |  |
| Credit carryforwards | 1,094 |  |  | 985 |  |
| Loss carryforwards | 379 |  |  | 438 |  |
| Operating and compensation related accruals | 512 |  |  | 478 |  |
| Other | 301 |  |  | 296 |  |
| Deferred tax assets | 3,936 |  |  | 3,822 |  |
| Valuation allowance | (1,423) |  |  | (1,297) |  |
| Deferred tax assets, net of valuation allowance | 2,513 |  |  | 2,525 |  |
| Deferred tax liabilities: |  |  |  |
| Leasing and financing | (382) |  |  | (375) |  |
| Property and equipment | (452) |  |  | (351) |  |
| Intangibles | (673) |  |  | (986) |  |
| Other | (363) |  |  | (341) |  |
| Deferred tax liabilities | (1,870) |  |  | (2,053) |  |
| Net deferred tax assets | $ | 643 |  |  | $ | 472 |  |

[0001571996-22-000009:notes:318]
The following tables present the net operating loss carryforwards, tax credit carryforwards, and other deferred tax assets with related valuation allowances recognized as of the dates indicated:

[0001571996-22-000009:notes:319]
|  | January 28, 2022 |  |  |
|  | Deferred Tax Assets |  | Valuation Allowance |  | Net Deferred Tax Assets |  | First Year Expiring |
|  | (in millions) |  |  |
| Credit carryforwards | $ | 1,094 |  |  | $ | (917) |  |  | $ | 177 |  |  | Fiscal 2023 |
| Loss carryforwards | 379 |  |  | (276) |  |  | 103 |  |  | Fiscal 2023 |
| Other deferred tax assets | 2,463 |  |  | (230) |  |  | 2,233 |  |  | NA |
| Total | $ | 3,936 |  |  | $ | (1,423) |  |  | $ | 2,513 |  |  |  |
|  | January 29, 2021 |  |  |
|  | Deferred Tax Assets |  | Valuation Allowance |  | Net Deferred Tax Assets |  | First Year Expiring |
|  | (in millions) |  |  |
| Credit carryforwards | $ | 985 |  |  | $ | (822) |  |  | $ | 163 |  |  | Fiscal 2022 |
| Loss carryforwards | 438 |  |  | (258) |  |  | 180 |  |  | Fiscal 2022 |
| Other deferred tax assets | 2,399 |  |  | (217) |  |  | 2,182 |  |  | NA |
| Total | $ | 3,822 |  |  | $ | (1,297) |  |  | $ | 2,525 |  |  |  |

[0001571996-22-000009:notes:320]
The Company’s credit carryforwards as of January 28, 2022 and January 29, 2021 relate primarily to U.S. tax credits and include state and federal tax credits associated with research and development, as well as foreign tax credits associated with the U.S. Tax Cuts and Jobs Act enacted in December 2017 (“U.S. Tax Reform”).  The more significant amounts of the Company’s carryforwards begin expiring in fiscal year 2028.  The Company assessed the realizability of these U.S. tax credits and has recorded a valuation allowance against the credits it does not expect to utilize.  The change in the valuation allowance against these credits is included in change in valuation allowance in the Company’s effective tax reconciliation.  The Company’s loss

[0001571996-22-000009:notes:321]
carryforwards as of January 28, 2022 and January 29, 2021 include net operating loss carryforwards from federal, state, and foreign jurisdictions.  The valuation allowances for other deferred tax assets as of January 28, 2022 and January 29, 2021 primarily relate to foreign jurisdictions, the changes in which are included in tax impact of foreign operations in the Company’s effective tax reconciliation.  The Company has determined that it will be able to realize the remainder of its deferred tax assets, based on the future reversal of deferred tax liabilities.

[0001571996-22-000009:notes:322]
The following table presents a reconciliation of the Company’s beginning and ending balances of unrecognized tax benefits for the periods indicated:

[0001571996-22-000009:notes:323]
|  | Fiscal Year Ended |
|  | January 28, 2022 |  | January 29, 2021 |  | January 31, 2020 |
|  | (in millions) |
| Beginning Balance | $ | 1,620 |  |  | $ | 2,235 |  |  | $ | 2,842 |  |
| Increases related to tax positions of the current year | 113 |  |  | 102 |  |  | 122 |  |
| Increases related to tax position of prior years | 143 |  |  | 385 |  |  | 437 |  |
| Reductions for tax positions of prior years | (153) |  |  | (673) |  |  | (659) |  |
| Lapse of statute of limitations | (78) |  |  | (27) |  |  | (105) |  |
| Audit settlements | (50) |  |  | (402) |  |  | (402) |  |
| Ending Balance | $ | 1,595 |  |  | $ | 1,620 |  |  | $ | 2,235 |  |

[0001571996-22-000009:notes:324]
The table does not include accrued interest and penalties of $383 million, $404 million, and $721 million as of January 28, 2022, January 29, 2021, and January 31, 2020, respectively.  Additionally, the table does not include certain tax benefits associated with interest and state tax deductions and other indirect jurisdictional effects of uncertain tax positions, which were $817 million, $835 million, and $601 million as of January 28, 2022, January 29, 2021, and January 31, 2020, respectively.  After taking these items into account, the Company’s net unrecognized tax benefits were $1.2 billion, $1.2 billion, and $2.4 billion as of January 28, 2022, January 29, 2021, and January 31, 2020, respectively, and are included in accrued and other and other non-current liabilities in the Consolidated Statements of Financial Position.

[0001571996-22-000009:notes:325]
The unrecognized tax benefits in the table above include $0.9 billion, $0.9 billion, and $1.8 billion as of January 28, 2022, January 29, 2021, and January 31, 2020, respectively, that, if recognized, would have impacted income tax expense.  Interest and penalties related to income tax liabilities are included in income tax expense.  The Company recorded tax benefits for interest and penalties of $14 million and $247 million for the fiscal years ended January 28, 2022 and January 29, 2021, respectively, and tax expense of $179 million for the fiscal year ended January 31, 2020.

[0001571996-22-000009:notes:326]
The Internal Revenue Service is currently conducting tax examinations of the Company for fiscal years 2015 through 2019.  The Company is also currently under income tax audits in various state and foreign taxing jurisdictions.  The Company is undergoing negotiations, and in some cases contested proceedings, relating to tax matters with the taxing authorities in these jurisdictions.  The Company believes that it has provided adequate reserves related to all matters contained in tax periods open to examination.  Although the Company believes it has made adequate provisions for the uncertainties surrounding these audits, should the Company experience unfavorable outcomes, such outcomes could have a material impact on its results of operations, financial position, and cash flows.  With respect to major U.S. state and foreign taxing jurisdictions, the Company is generally not subject to tax examinations for years prior to the fiscal year ended January 29, 2010.

[0001571996-22-000009:notes:327]
Judgment is required in evaluating the Company’s uncertain tax positions and determining the Company’s provision for income taxes.  The Company does not expect a significant change to the total amount of unrecognized tax benefits within the next twelve months.

[0001571996-22-000009:notes:328]
The Company takes certain non-income tax positions in the jurisdictions in which it operates and has received certain non-income tax assessments from various jurisdictions.  The Company believes that a material loss in these matters is not probable and that it is not reasonably possible that a material loss exceeding amounts already accrued has been incurred.  The Company believes its positions in these non-income tax litigation matters are supportable and that it ultimately will prevail in the matters.  In the normal course of business, the Company’s positions and conclusions related to its non-income taxes could be challenged and assessments may be made.  To the extent new information is obtained and the Company’s views on its positions, probable outcomes of assessments, or litigation change, changes in estimates to the Company’s accrued liabilities would be recorded in the period in which such a determination is made.  In the resolution process for income tax and non-income tax audits, the 
Company is required in certain situations to provide collateral guarantees or indemnification to regulators and tax authorities until the matter is resolved.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001571996-22-000009:notes:329]
ACCUMULATED OTHER COMPREHENSIVE INCOME (LOSS) 
Accumulated other comprehensive income (loss) is presented in stockholders’ equity (deficit) in the Consolidated Statements of Financial Position and consists of amounts related to foreign currency translation adjustments, unrealized net gains (losses) on investments, unrealized net gains (losses) on cash flow hedges, and actuarial net gains (losses) from pension and other postretirement plans.

[0001571996-22-000009:notes:330]
The following table presents changes in accumulated other comprehensive income (loss), net of tax, by the following components as of the dates indicated:

[0001571996-22-000009:notes:331]
|  | Foreign Currency Translation Adjustments |  |  |  | Cash Flow Hedges |  | Pension and Other Postretirement Plans |  | Accumulated Other Comprehensive Income (Loss) |
|  | (in millions) |
| Balances as of February 1, 2019 | $ | (452) |  |  |  |  | $ | (29) |  |  | $ | 14 |  |  | $ | (467) |  |
| Other comprehensive income (loss) before reclassifications | (226) |  |  |  |  | 269 |  |  | (60) |  |  | (17) |  |
| Amounts reclassified from accumulated other comprehensive income (loss) | — |  |  |  |  | (226) |  |  | 1 |  |  | (225) |  |
| Total change for the period | (226) |  |  |  |  | 43 |  |  | (59) |  |  | (242) |  |
| Balances as of January 31, 2020 | $ | (678) |  |  |  |  | $ | 14 |  |  | $ | (45) |  |  | $ | (709) |  |
| Other comprehensive income (loss) before reclassifications | 528 |  |  |  |  | (200) |  |  | (38) |  |  | 290 |  |
| Amounts reclassified from accumulated other comprehensive income (loss) | — |  |  |  |  | 100 |  |  | 5 |  |  | 105 |  |
| Total change for the period | 528 |  |  |  |  | (100) |  |  | (33) |  |  | 395 |  |
| Balances as of January 29, 2021 | $ | (150) |  |  |  |  | $ | (86) |  |  | $ | (78) |  |  | $ | (314) |  |
| Other comprehensive income (loss) before reclassifications | (385) |  |  |  |  | 374 |  |  | 37 |  |  | 26 |  |
| Amounts reclassified from accumulated other comprehensive income (loss) | — |  |  |  |  | (158) |  |  | 7 |  |  | (151) |  |
| Spin-off of VMware | 9 |  |  |  |  | (1) |  |  | — |  |  | 8 |  |
| Total change for the period | (376) |  |  |  |  | 215 |  |  | 44 |  |  | (117) |  |
| Balances as of January 28, 2022 | $ | (526) |  |  |  |  | $ | 129 |  |  | $ | (34) |  |  | $ | (431) |  |

[0001571996-22-000009:notes:332]
Amounts related to investments are reclassified to net income (loss) when gains and losses are realized.  See Note 4 of the Notes to the Consolidated Financial Statements for more information on the Company’s investments.  Amounts related to the Company’s cash flow hedges are reclassified to net income during the same period in which the items being hedged are recognized in earnings.  See Note 8 of the Notes to the Consolidated Financial Statements for more information on the Company’s derivative instruments.

[0001571996-22-000009:notes:333]
The following table presents reclassifications out of accumulated other comprehensive income (loss), net of tax, to net income for the periods indicated:

[0001571996-22-000009:notes:334]
|  |  |  | Fiscal Year Ended |
|  |  |  | January 28, 2022 |  |  |  | January 29, 2021 |
|  |  |  | Cash Flow Hedges |  | Pensions |  | Total |  |  |  | Cash Flow Hedges |  | Pensions |  | Total |
|  |  |  | (in millions) |
| Total reclassifications, net of tax: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue |  |  | $ | 158 |  |  | $ | — |  |  | $ | 158 |  |  |  |  | $ | (98) |  |  | $ | — |  |  | $ | (98) |  |
| Cost of net revenue |  |  | (3) |  |  | — |  |  | (3) |  |  |  |  | 5 |  |  | — |  |  | 5 |  |
| Operating expenses |  |  | — |  |  | (7) |  |  | (7) |  |  |  |  | — |  |  | (5) |  |  | (5) |  |
| Income from discontinued operations |  |  | 3 |  |  | — |  |  | 3 |  |  |  |  | (7) |  |  | — |  |  | (7) |  |
| Total reclassifications, net of tax |  |  | $ | 158 |  |  | $ | (7) |  |  | $ | 151 |  |  |  |  | $ | (100) |  |  | $ | (5) |  |  | $ | (105) |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001571996-22-000009:notes:335]
CAPITALIZATION 
The following table presents the Company’s authorized, issued, and outstanding common stock as of the dates indicated:

[0001571996-22-000009:notes:336]
|  | Authorized |  | Issued |  | Outstanding |
|  | (in millions) |
| Common stock as of January 28, 2022 |
| Class A | 600 |  |  | 379 |  |  | 379 |  |
| Class B | 200 |  |  | 95 |  |  | 95 |  |
| Class C | 7,900 |  |  | 303 |  |  | 283 |  |
| Class D | 100 |  |  | — |  |  | — |  |
| Class V | 343 |  |  | — |  |  | — |  |
|  | 9,143 |  |  | 777 |  |  | 757 |  |
| Common stock as of January 29, 2021 |
| Class A | 600 |  |  | 385 |  |  | 385 |  |
| Class B | 200 |  |  | 102 |  |  | 102 |  |
| Class C | 7,900 |  |  | 274 |  |  | 266 |  |
| Class D | 100 |  |  | — |  |  | — |  |
| Class V | 343 |  |  | — |  |  | — |  |
|  | 9,143 |  |  | 761 |  |  | 753 |  |

[0001571996-22-000009:notes:337]
Under the Company’s certificate of incorporation, the Company is prohibited from issuing any of the authorized shares of Class V Common Stock.

[0001571996-22-000009:notes:338]
Preferred Stock

[0001571996-22-000009:notes:339]
The Company is authorized to issue one million shares of preferred stock, par value $0.01 per share.  As of January 28, 2022 and January 29, 2021, no shares of preferred stock were issued or outstanding.

[0001571996-22-000009:notes:340]
Common Stock

[0001571996-22-000009:notes:341]
Dell Technologies Common Stock — The Class A Common Stock, the Class B Common Stock, the Class C Common Stock, and the Class D Common Stock are collectively referred to as Dell Technologies Common Stock.  The par value for all classes of Dell Technologies Common Stock is $0.01 per share.  The Class A Common Stock, the Class B Common Stock, the Class C Common Stock, and the Class D Common Stock share equally in dividends declared or accumulated and have equal participation rights in undistributed earnings.

[0001571996-22-000009:notes:342]
Voting Rights — Each holder of record of (a) Class A Common Stock is entitled to ten votes per share of Class A Common Stock; (b) Class B Common Stock is entitled to ten votes per share of Class B Common Stock; (c) Class C Common Stock is entitled to one vote per share of Class C Common Stock; and (d) Class D Common Stock is not entitled to any vote on any matter except to the extent required by provisions of Delaware law (in which case such holder is entitled to one vote per share of Class D Common Stock).

[0001571996-22-000009:notes:343]
Conversion Rights — Under the Company’s certificate of incorporation, at any time and from time to time, any holder of Class A Common Stock or Class B Common Stock has the right to convert all or any of the shares of Class A Common Stock or Class B Common Stock, as applicable, held by such holder into shares of Class C Common Stock on a one-to-one basis.

[0001571996-22-000009:notes:344]
During the fiscal year ended January 28, 2022, the Company issued an aggregate of 5,985,573 shares of Class C Common Stock to stockholders upon their conversion of the same number of shares of Class A Common Stock into Class C Common Stock in accordance with the Company’s certificate of incorporation.

[0001571996-22-000009:notes:345]
During the fiscal year ended January 28, 2022, the Company issued 6,334,990 shares of Class C Common Stock to stockholders upon their conversion of the same number of shares of Class B Common Stock into Class C Common Stock in accordance with the Company’s certificate of incorporation.

[0001571996-22-000009:notes:346]
During the fiscal year ended January 29, 2021, the Company issued an aggregate of 72,727 shares of Class C Common Stock to stockholders upon their conversion of the same number of shares of Class A Common Stock into Class C Common Stock in accordance with the Company’s certificate of incorporation.

[0001571996-22-000009:notes:347]
Repurchases of Common Stock and Treasury Stock

[0001571996-22-000009:notes:348]
Dell Technologies Common Stock Repurchases by Dell Technologies during Fiscal 2022

[0001571996-22-000009:notes:349]
Effective as of September 23, 2021, the Company’s Board of Directors terminated the Company’s previous stock repurchase program and approved a new stock repurchase program (the “2021 Stock Repurchase Program”) under which the Company is authorized to use assets to repurchase up to $5 billion of shares of the Company’s Class C Common Stock with no established expiration date.  During the fiscal year ended January 28, 2022, the Company repurchased approximately 12 million shares of Class C Common Stock for a total purchase price of approximately $659 million.

[0001571996-22-000009:notes:350]
Dell Technologies Common Stock Repurchases by Dell Technologies during Fiscal 2021

[0001571996-22-000009:notes:351]
During the fiscal year ended January 29, 2021, the Company repurchased approximately 6 million shares of Class C Common Stock for a total purchase price of approximately $240 million under a previous stock repurchase program that was subsequently suspended and, in the fiscal year ended January 28, 2022,  terminated.

[0001571996-22-000009:notes:352]
To the extent not retired, shares repurchased under the repurchase program are placed in the Company’s treasury.


## us-gaap:EarningsPerShareTextBlock

[0001571996-22-000009:notes:353]
EARNINGS PER SHARE
Basic earnings per share is based on the weighted-average effect of all common shares issued and outstanding and is calculated by dividing net income by the weighted-average shares outstanding during the period.  Diluted earnings per share is calculated by dividing net income by the weighted-average number of common shares used in the basic earnings per share calculation plus the number of common shares that would be issued assuming exercise or conversion of all potentially dilutive instruments.  The Company excludes equity instruments from the calculation of diluted earnings per share if the effect of including such instruments is antidilutive.

[0001571996-22-000009:notes:354]
The following table presents basic and diluted earnings per share for the periods indicated:

[0001571996-22-000009:notes:355]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  | January 28, 2022 |  | January 29, 2021 |  | January 31, 2020 |
| Earnings per share attributable to Dell Technologies Inc. - basic |
| Continuing operations |  |  |  |  | $ | 6.49 |  |  | $ | 3.02 |  |  | $ | 0.73 |  |
| Discontinued operations |  |  |  |  | $ | 0.81 |  |  | $ | 1.35 |  |  | $ | 5.65 |  |
| Earnings per share attributable to Dell Technologies Inc. — diluted |
| Continuing operations |  |  |  |  | $ | 6.26 |  |  | $ | 2.93 |  |  | $ | 0.70 |  |
| Discontinued operations |  |  |  |  | $ | 0.76 |  |  | $ | 1.29 |  |  | $ | 5.33 |  |

[0001571996-22-000009:notes:356]
The following table presents the computation of basic and diluted earnings per share for the periods indicated:

[0001571996-22-000009:notes:357]
|  | Fiscal Year Ended |  |  |  |
|  | January 28, 2022 |  | January 29, 2021 |  | January 31, 2020 |  |  |  |
|  | (in millions) |  |  |  |
| Numerator: Continuing operations |  |  |  |  |  |  |  |  |
| Net income attributable to Dell Technologies Inc. from continuing operations - basic and diluted | $ | 4,948 |  |  | $ | 2,249 |  |  | $ | 525 |  |  |  |  |
| Numerator: Discontinued operations |  |  |  |  |  |  |  |  |
| Income from discontinued operations, net of income taxes - basic | $ | 615 |  |  | $ | 1,001 |  |  | $ | 4,091 |  |  |  |  |
| Incremental dilution from VMware (a) | (7) |  |  | (13) |  |  | (84) |  |  |  |  |
| Income from discontinued operations, net of income taxes, attributable to Dell Technologies Inc. - diluted | $ | 608 |  |  | $ | 988 |  |  | $ | 4,007 |  |  |  |  |
| Denominator: Dell Technologies Common Stock weighted-average shares outstanding |  |  |  |  |  |  |  |  |
| Weighted-average shares outstanding — basic | 762 |  |  | 744 |  |  | 724 |  |  |  |  |
| Dilutive effect of options, restricted stock units, restricted stock, and other | 29 |  |  | 23 |  |  | 27 |  |  |  |  |
| Weighted-average shares outstanding — diluted | 791 |  |  | 767 |  |  | 751 |  |  |  |  |
| Weighted-average shares outstanding — antidilutive |  |  |  |  |  |  |  |  |

[0001571996-22-000009:notes:358]
(a)    The incremental dilution from VMware represents the impact of VMware’s dilutive securities on diluted earnings per share of Dell Technologies Common Stock, and is calculated by multiplying the difference between VMware’s basic and diluted earnings (loss) per share by the number of shares of VMware common stock held by the Company.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001571996-22-000009:notes:359]
STOCK-BASED COMPENSATION 
Stock-Based Compensation Expense

[0001571996-22-000009:notes:360]
The following table presents stock-based compensation expense recognized in the Consolidated Statements of Income for the periods indicated:

[0001571996-22-000009:notes:361]
|  | Fiscal Year Ended |
|  | January 28, 2022 |  | January 29, 2021 |  | January 31, 2020 |
|  | (in millions) |
| Stock-based compensation expense: |  |  |  |  |  |
| Cost of net revenue | $ | 133 |  |  | $ | 75 |  |  | $ | 32 |  |
| Operating expenses | 675 |  |  | 412 |  |  | 213 |  |
| Stock-based compensation expense from continuing operations before taxes | 808 |  |  | 487 |  |  | 245 |  |
| Stock-based compensation expense from discontinued operations before taxes (a) | 814 |  |  | 1,122 |  |  | 1,017 |  |
| Total stock-based compensation expense before taxes | 1,622 |  |  | 1,609 |  |  | 1,262 |  |
| Income tax benefit | (296) |  |  | (313) |  |  | (392) |  |
| Total stock-based compensation expense, net of income taxes | $ | 1,326 |  |  | $ | 1,296 |  |  | $ | 870 |  |

[0001571996-22-000009:notes:362]
(a)    Stock-based compensation expense from discontinued operations before taxes represents VMware stock-based compensation expense and is included in Income from discontinued operations, net of taxes, on the Consolidated Statements of Income.

[0001571996-22-000009:notes:363]
Dell Technologies Inc. Stock-Based Compensation Plan

[0001571996-22-000009:notes:364]
Dell Technologies Inc. 2013 Stock Incentive Plan  — Employees, consultants, non-employee directors, and other service providers of the Company or its affiliates are eligible to participate in the Dell Technologies Inc. 2013 Stock Incentive Plan, as amended and restated as of July 9, 2019, (the “2013 Plan”).  The 2013 Plan authorizes the Company to grant stock options, restricted stock units (“RSUs”), stock appreciation rights (“SARs”), restricted stock awards, and dividend equivalents.  Stock options have been granted with option exercise prices equal to the fair market value of the Company’s Class C Common Stock and expire ten years after the grant date.

[0001571996-22-000009:notes:365]
The 2013 Plan provides for an equitable adjustment of the share pool authorized under the 2013 Plan and outstanding awards in the event of a corporate restructuring event.  In connection with the VMware Spin-off, the authorized share pool under the 2013 Plan and stock awards that were outstanding at the time of the VMware Spin-off were adjusted using a conversion ratio of approximately 1.97 to 1.  The conversion ratio was based on the Company’s pre-VMware Spin-off closing stock price on November 1, 2021 and post-VMware Spin-off opening stock price on November 2, 2021.  The adjustment resulted in an increase of approximately 30 million restricted stock units and 2 million stock options.  The exercise price of unexercised stock options was also adjusted in accordance with the terms of the 2013 Plan using the conversion ratio of approximately 1.97 to 1.  The adjustment did not result in material incremental stock-based compensation expense for the fiscal year ended January 28, 2022 as the adjustment was required by the 2013 Plan.

[0001571996-22-000009:notes:366]
The 2013 Plan authorizes the issuance of an aggregate of 165.5 million shares of the Company’s Class C Common Stock, including 55.0 million shares automatically added to the share pool pursuant to the equitable adjustment provisions relating to the VMware Spin-off.  As of January 28, 2022, there were approximately 46 million shares of Class C Common Stock available for future grants under the 2013 Plan.

[0001571996-22-000009:notes:367]
Stock Option Activity — The following table presents stock option activity settled in Dell Technologies Common Stock for the periods indicated:

[0001571996-22-000009:notes:368]
|  | Number of Options |  | Weighted-Average Exercise Price |  | Weighted-Average Remaining Contractual Term |  | Aggregate Intrinsic Value (a) |
|  | (in millions) |  | (per share) |  | (in years) |  | (in millions) |
| Options outstanding as of February 1, 2019 | 42 |  |  | $ | 14.76 |  |  |  |  |  |
| Granted | — |  |  | — |  |  |  |  |  |
| Exercised | (24) |  |  | 14.86 |  |  |  |  |  |
| Forfeited | — |  |  | — |  |  |  |  |  |
| Canceled/expired | — |  |  | — |  |  |  |  |  |
| Options outstanding as of January 31, 2020 | 18 |  |  | 14.82 |  |  |  |  |  |
| Granted | — |  |  | — |  |  |  |  |  |
| Exercised | (12) |  |  | 14.32 |  |  |  |  |  |
| Forfeited | — |  |  | — |  |  |  |  |  |
| Canceled/expired | — |  |  | — |  |  |  |  |  |
| Options outstanding as of January 29, 2021 | 6 |  |  | 15.87 |  |  |  |  |  |
| Granted | — |  |  | — |  |  |  |  |  |
| VMware Spin-off adjustment | 2 |  |  | NA |  |  |  |  |
| Exercised | (5) |  |  | 13.36 |  |  |  |  |  |
| Forfeited | — |  |  | — |  |  |  |  |  |
| Canceled/expired | — |  |  | — |  |  |  |  |  |
| Options outstanding as of January 28, 2022 (b) | 3 |  |  | $ | 9.62 |  |  | 2.8 |  | $ | 132 |  |
| Exercisable as of January 28, 2022 | 3 |  |  | $ | 9.34 |  |  | 2.7 |  | $ | 131 |  |
| Vested and expected to vest (net of estimated forfeitures) as of January 28, 2022 | 3 |  |  | $ | 9.62 |  |  | 2.8 |  | $ | 132 |  |

[0001571996-22-000009:notes:369]
(a)    The aggregate intrinsic values represent the total pre-tax intrinsic values based on the closing price of $56.24 of the Company’s Class C Common Stock on January 28, 2022 as reported on the NYSE that would have been received by the option holders had all in-the-money options been exercised as of that date.

[0001571996-22-000009:notes:370]
(b)    In connection with the VMware Spin-off, Dell Technologies made certain adjustments to the number of stock options to preserve the intrinsic value of the awards prior to the VMware Spin-off.  The ending weighted-average exercise price was calculated based on underlying options outstanding as of January 28, 2022.  Of the 3 million stock options outstanding on January 28, 2022, 2 million stock options related to performance-based awards and 1 million stock options related to service-based awards.

[0001571996-22-000009:notes:371]
The total fair value of options vested was not material for the fiscal years ended January 28, 2022, January 29, 2021, and January 31, 2020.  The pre-tax intrinsic value of the options exercised was $340 million, $591 million, and $835 million for the fiscal years ended January 28, 2022, January 29, 2021, and January 31, 2020, respectively.  Cash proceeds from the exercise of stock options was $62 million, $179 million, and $350 million for the fiscal years ended January 28, 2022, January 29, 2021, and  January 31, 2020, respectively.

[0001571996-22-000009:notes:372]
The tax benefit realized from the exercise of stock options was $76 million, $139 million, and $197 million for the fiscal years ended January 28, 2022, January 29, 2021, and January 31, 2020, respectively.

[0001571996-22-000009:notes:373]
Restricted Stock — The Company’s restricted stock primarily consists of RSUs granted to employees.  During the fiscal year ended January 28, 2022, January 29, 2021, and January 31, 2020, the Company granted long-term incentive awards in the form of service-based RSUs and performance-based RSUs (“PSUs”) in order to align critical talent retention programs with the interests of holders of the Class C Common Stock.

[0001571996-22-000009:notes:374]
Service-based RSUs have a fair value based on the closing price of the Class C Common Stock price as reported on the NYSE on the grant date or the trade day immediately preceding the grant date, if the grant date falls on a non-trading day.  Most of such RSUs vest ratably over a three-year period.  Each service-based RSU represents the right to acquire one share of Class C Common Stock upon vesting.

[0001571996-22-000009:notes:375]
The PSUs granted during the periods presented are reflected as target units for performance periods not yet complete.  The actual number of units that ultimately vest will range from 0% to 200% of target, based on the level of achievement of the performance goals and continued employment with the Company over a three-year performance period.  Approximately half of the PSUs granted are subject to achievement of market-based performance goals based on relative total shareholder return and were valued utilizing a Monte Carlo valuation model to simulate the probabilities of achievement.  The remaining PSUs are subject to internal financial measures and have fair values based on the closing price of the Class C Common Stock as reported on the NYSE on the accounting grant date.

[0001571996-22-000009:notes:376]
Prior to the Class V transaction, the Company granted market-based PSUs to certain members of the Company’s senior leadership team, which were also valued using the Monte Carlo model.  The vesting and payout of the PSU awards depended upon the return on equity achieved on various measurement dates through the five-year anniversary of the Company’s  acquisition of EMC Corporation in a transaction that closed in September 2016 (the “EMC merger transaction”) or specified liquidity events.

[0001571996-22-000009:notes:377]
The following table presents the assumptions utilized in the Monte Carlo valuation model for the periods indicated:

[0001571996-22-000009:notes:378]
|  | Fiscal Year Ended |
|  | January 28, 2022 |  | January 29, 2021 |  | January 31, 2020 |
| Weighted-average grant date fair value | $ | 134.01 |  |  | $ | 40.01 |  |  | $ | 87.17 |  |
| Term (in years) | 3 |  | 3 |  | 3 |
| Risk-free rate (U.S. Government Treasury Note) | 0.3 | % |  | 0.6 | % |  | 2.4 | % |
| Expected volatility | 43 | % |  | 47 | % |  | 45 | % |
| Expected dividend yield | — | % |  | — | % |  | — | % |

[0001571996-22-000009:notes:379]
The following table presents restricted stock and restricted stock units activity settled in Dell Technologies Common Stock for the periods indicated:

[0001571996-22-000009:notes:380]
|  | Number of Units |  | Weighted-Average Grant Date Fair Value |  | Aggregate Intrinsic Value (a) |
|  | (in millions) |  | (per unit) |  |  |
| Outstanding, February 1, 2019 | 5 |  |  | $ | 18.90 |  |  |  |
| Granted | 13 |  |  | 60.55 |  |  |  |
| Vested | (1) |  |  | 30.24 |  |  |  |
| Forfeited | (1) |  |  | 46.50 |  |  |  |
| Outstanding, January 31, 2020 | 16 |  |  | $ | 50.78 |  |  |  |
| Granted | 25 |  |  | 39.14 |  |  |  |
| Vested | (5) |  |  | 48.15 |  |  |  |
| Forfeited | (3) |  |  | 41.56 |  |  |  |
| Outstanding, January 29, 2021 | 33 |  |  | $ | 43.09 |  |  |  |
| Granted | 13 |  |  | 88.13 |  |  |  |
| VMware Spin-off adjustment | 30 |  |  | NA |  |  |
| Vested | (13) |  |  | 39.33 |  |  |  |
| Forfeited | (4) |  |  | 46.27 |  |  |  |
| Outstanding, January 28, 2022(b) | 59 |  |  | $ | 31.67 |  |  | $ | 3,337 |  |
| Vested and expected to vest, January 28, 2022 | 55 |  |  | $ | 31.30 |  |  | $ | 3,070 |  |

[0001571996-22-000009:notes:381]
(a)    The aggregate intrinsic value represents the total pre-tax intrinsic values based on the closing price of $56.24 of the Company’s Class C Common Stock on January 28, 2022 as reported on the NYSE that would have been received by the RSU holders had the RSUs been issued as of January 28, 2022.

[0001571996-22-000009:notes:382]
(b)    In connection with the VMware Spin-off, Dell Technologies made certain adjustments to the number of RSUs to preserve the intrinsic value of the awards prior to the VMware Spin-off.  The ending weighted-average grant date fair value was calculated based on underlying RSUs outstanding as of January 28, 2022.  As of January 28, 2022, the 59 million units outstanding included 48 million RSUs and 11 million PSUs.

[0001571996-22-000009:notes:383]
The total fair value of restricted stock that vested during the fiscal years ended January 28, 2022, January 29, 2021, and January 31, 2020 was $493 million, $235 million, and $27 million, respectively, with a pre-tax intrinsic value was $1,097 million, $226 million, and $47 million, respectively.

[0001571996-22-000009:notes:384]
As of January 28, 2022, there was $963 million of unrecognized stock-based compensation expense, net of estimated forfeitures, related to these awards expected to be recognized over a weighted-average period of approximately 1.9 years.

[0001571996-22-000009:notes:385]
Dell Technologies Shares Withheld for Taxes — Under certain situations, shares of Class C Common Stock are withheld from issuance to cover employee taxes for both the vesting of restricted stock units and the exercise of stock options.  For the fiscal years ended January 28, 2022, January 29, 2021, and January 31, 2020, 0.4 million, 0.1 million, and 0.1 million shares, respectively, were withheld to cover $40 million, $1 million, and $4 million, respectively, of employees’ tax obligations.

[0001571996-22-000009:notes:386]
Other Plans
In addition to the 2013 Plan described above, the Company has a consolidated subsidiary, Secureworks, that maintains its own equity plan and issues equity grants settling in its own Class A common stock.  The stock option and restricted stock unit activity under this plan was not material during the fiscal years ended January 28, 2022, January 29, 2021, and January 31, 2020.


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001571996-22-000009:notes:387]
REDEEMABLE SHARES 
Through June 27, 2021, awards under the Company’s stock incentive plans included certain rights that allow the holder to exercise a put feature for the underlying Class A or Class C Common Stock after a six-month holding period following the issuance of such common stock.  The put feature required the Company to purchase the stock at its fair market value.  Accordingly, these awards and such common stock were subject to reclassification from equity to temporary equity.  The put feature expired on June 27, 2021, and as a result, there were no issued and outstanding awards that were reclassified as temporary equity as of January 28, 2022.

[0001571996-22-000009:notes:388]
As of the fiscal year ended January 29, 2021, the Company determined the award amounts to be classified as temporary equity as follows:

[0001571996-22-000009:notes:389]
•For stock options to purchase Class C Common Stock subject to service requirements, the intrinsic value of the option is multiplied by the portion of the option for which services have been rendered.  Upon exercise of the option, the amount in temporary equity represents the fair value of the Class C Common Stock.

[0001571996-22-000009:notes:390]
•For stock appreciation rights, restricted stock units, or restricted stock awards, any of which stock award types are subject to service requirements, the fair value of the share is multiplied by the portion of the share for which services have been rendered.

[0001571996-22-000009:notes:391]
•For share-based arrangements that are subject to the occurrence of a contingent event, the amounts are reclassified to temporary equity based on a probability assessment performed by the Company on a periodic basis.  Contingent events include the achievement of performance-based measures.

[0001571996-22-000009:notes:392]
The following table presents the amount of redeemable shares classified as temporary equity and summarizes the award type as of January 29, 2021:

[0001571996-22-000009:notes:393]
|  |  |  | January 29, 2021 |
|  |  |  | (in millions) |
| Redeemable shares classified as temporary equity |  |  | $ | 472 |  |
| Issued and outstanding unrestricted common shares |  |  | 2 |  |
| Outstanding stock options |  |  | 6 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001571996-22-000009:notes:394]
RETIREMENT PLAN BENEFITS 
Defined Benefit Retirement Plans

[0001571996-22-000009:notes:395]
The Company sponsors retirement plans for certain employees in the United States and internationally, some of which meet the criteria of a defined benefit retirement plan.  Benefits under defined benefit retirement plans guarantee a particular payment to the employee in retirement.  The amount of retirement benefit is defined by the plan and is typically a function of the number of years of service rendered by the employee and the employee’s average salary or salary at retirement.  The annual costs of the plans are determined using the projected unit credit actuarial cost method that includes actuarial assumptions and estimates which are subject to change.

[0001571996-22-000009:notes:396]
U.S. Pension Plan — The Company sponsors a noncontributory defined benefit retirement plan in the United States (the “U.S. pension plan”) which was assumed in connection with the EMC merger transaction.  As of December 1999, the U.S. pension plan was frozen, so employees no longer accrue retirement benefits for future services.  The measurement date for the U.S. pension plan is the end of the Company’s fiscal year.  The Company did not make any significant contributions to the U.S. pension plan for the fiscal years ended January 28, 2022, January 29, 2021, and January 31, 2020, and does not expect to make any significant contributions in Fiscal 2023.

[0001571996-22-000009:notes:397]
Net periodic benefit costs related to the U.S. pension plan were immaterial for the fiscal years ended January 28, 2022, January 29, 2021, and January 31, 2020.

[0001571996-22-000009:notes:398]
The following table presents attributes of the U.S. pension plan as of the dates indicated:

[0001571996-22-000009:notes:399]
|  | January 28, 2022 |  | January 29, 2021 |
|  | (in millions) |
| Plan assets at fair value (a) | $ | 550 |  |  | $ | 572 |  |
| Benefit obligations | (582) |  |  | (635) |  |
| Underfunded position (b) | $ | (32) |  |  | $ | (63) |  |

[0001571996-22-000009:notes:400]
(a)    Plan assets are managed by outside investment managers.  The Company’s investment strategy with respect to plan assets is to achieve a long-term growth of capital, consistent with an appropriate level of risk.  Assets are recognized at fair value and are primarily classified within Level 2 of the fair value hierarchy.

[0001571996-22-000009:notes:401]
(b)    The underfunded position of the U.S. pension plan is recognized in other non-current liabilities in the Consolidated Statements of Financial Position.

[0001571996-22-000009:notes:402]
As of January 28, 2022, future benefit payments for the U.S. pension plan are expected to be paid as follows: $35 million in fiscal 2023; $36 million in fiscal 2024; $37 million in fiscal 2025; $37 million in fiscal 2026; $38 million in fiscal 2027; and $184 million thereafter.

[0001571996-22-000009:notes:403]
International Pension Plans — The Company also sponsors retirement plans outside of the United States which qualify as defined benefit plans.  The following table presents attributes of the international pension plans as of the dates indicated:

[0001571996-22-000009:notes:404]
|  | January 28, 2022 |  | January 29, 2021 |
|  | (in millions) |
| Plan assets at fair value (a) | $ | 245 |  |  | $ | 256 |  |
| Benefit obligations | (479) |  |  | (517) |  |
| Underfunded position (b) | $ | (234) |  |  | $ | (261) |  |

[0001571996-22-000009:notes:405]
(b)    The underfunded position is recognized in other non-current liabilities in the Consolidated Statements of Financial Position.

[0001571996-22-000009:notes:406]
Defined Contribution Retirement Plans

[0001571996-22-000009:notes:407]
Dell 401(k) Plan — The Company has a defined contribution retirement plan (the “Dell 401(k) Plan”) that complies with Section 401(k) of the Internal Revenue Code.  Only U.S. employees and employees of certain subsidiaries, except those who are covered by a collective bargaining agreement, classified as a leased employee, a nonresident alien, or are covered under a separate plan, are eligible to participate in the Dell 401(k) Plan.  Participation in the Dell 401(k) Plan is at the election of the employee.  Historically, through May 31, 2020, the Company matched 100% of each participant’s voluntary contributions (the “Dell 401(k) employer match”), subject to a maximum contribution of 6% of the participant’s eligible compensation, up to an annual limit of $7,500, and participants vest immediately in all contributions to the Dell 401(k) Plan.  On June 1, 2020, the Company suspended the Dell 401(k) employer match for U.S. employees as a precautionary measure to preserve financial flexibility in light of COVID-19.  Effective January 1, 2021, the Dell 401(k) employer match was reinstated, with no change to the employer match policy or participant eligibility requirements.
The Company’s matching contributions as well as participants’ voluntary contributions are invested according to each participant’s elections in the investment options provided under the Dell 401(k) Plan.  The Company’s contributions during the fiscal years ended January 28, 2022, January 29, 2021, and January 31, 2020 were $249 million, $154 million, and $267 million, respectively.  The Company’s contributions decreased during the fiscal year ended January 29, 2021 due to the suspension of the Dell 401(k) employer match between June 1, 2020 and December 31, 2020, as discussed above.


## us-gaap:ScheduleOfChangesInFairValueOfPlanAssetsTableTextBlock

[0001571996-22-000009:notes:408]
(b)    The underfunded position of the U.S. pension plan is recognized in other non-current liabilities in the Consolidated Statements of Financial Position.  
The following table presents attributes of the international pension plans as of the dates indicated:

[0001571996-22-000009:notes:409]
(a)    Plan assets are managed by outside investment managers.  The Company’s investment strategy with respect to plan assets is to achieve a long-term growth of capital, consistent with an appropriate level of risk.  Assets are recognized at fair value and are primarily classified within Level 2 of the fair value hierarchy.
(b)    The underfunded position is recognized in other non-current liabilities in the Consolidated Statements of Financial Position.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001571996-22-000009:notes:410]
SEGMENT INFORMATION 
The Company has two reportable segments that are based on the following business units:  Infrastructure Solutions Group (“ISG”) and Client Solutions Group (“CSG”).

[0001571996-22-000009:notes:411]
ISG enables the digital transformation of the Company’s customers through its trusted multi-cloud and big data solutions, which are built upon a modern data center infrastructure.  The ISG comprehensive portfolio of advanced storage solutions includes traditional storage solutions as well as next-generation storage solutions (such as all-flash arrays, scale-out file, object platforms, and software-defined solutions), while the Company’s server portfolio includes high-performance rack, blade, tower, and hyperscale servers.  The ISG networking portfolio helps business customers transform and modernize their infrastructure, mobilize and enrich end-user experiences, and accelerate business applications and processes.  ISG also offers attached software, peripherals, and services, including support and deployment, configuration, and extended warranty services.

[0001571996-22-000009:notes:412]
CSG includes sales to commercial and consumer customers of branded hardware (such as desktops, workstations, and notebooks) and branded peripherals (such as displays and projectors), as well as services and third-party software and peripherals.  CSG also offers attached software, peripherals, and services, including support and deployment, configuration, and extended warranty services.

[0001571996-22-000009:notes:413]
The reportable segments disclosed herein are based on information reviewed by the Company’s management to evaluate the business segment results.  The Company’s measure of segment revenue and segment operating income for management reporting purposes excludes operating results of other businesses, unallocated corporate transactions, the impact of purchase accounting, amortization of intangible assets, transaction-related expenses, stock-based compensation expense, and other corporate expenses, as applicable.  The Company does not allocate assets to the above reportable segments for internal reporting purposes.

[0001571996-22-000009:notes:414]
As described in Note 1 and Note 3 of the Notes to the Consolidated Financial Statements, the Company completed the VMware Spin-off on November 1, 2021.

[0001571996-22-000009:notes:415]
Pursuant to the CFA described in such Notes, Dell Technologies will continue to act as a distributor of VMware’s standalone products and services and purchase such products and services for resale to end-user customers (“VMware Resale”).  Dell Technologies will also continue to integrate VMware’s products and services with Dell Technologies’ offerings and sell them to end users.  The results of such operations are classified as continuing operations within the Company’s Consolidated Statements of Income.  The results of standalone VMware Resale transactions are reflected in other businesses.  The results of integrated offering transactions are reflected within CSG or ISG, depending upon the nature of the underlying offering sold.  The Company's prior period segment results have been recast to reflect this change.

[0001571996-22-000009:notes:416]
In accordance with applicable accounting guidance, the results of VMware, excluding Dell's resale of VMware offerings, are presented as discontinued operations in the Consolidated Statements of Income and, as such, have been excluded from both continuing operations and segment results for all periods presented.

[0001571996-22-000009:notes:417]
The following table presents a reconciliation of net revenue by the Company’s reportable segments to the Company’s consolidated net revenue as well as a reconciliation of consolidated segment operating income to the Company’s consolidated operating income (loss) for the periods indicated:

[0001571996-22-000009:notes:418]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  | January 28, 2022 |  | January 29, 2021 |  | January 31, 2020 |
|  |  |  |  |  | (in millions) |
| Consolidated net revenue: |  |  |  |  |  |  |  |  |  |
| Infrastructure Solutions Group |  |  |  |  | $ | 34,366 |  |  | $ | 33,002 |  |  | $ | 34,367 |  |
| Client Solutions Group |  |  |  |  | 61,464 |  |  | 48,387 |  |  | 45,855 |  |
| Reportable segment net revenue |  |  |  |  | 95,830 |  |  | 81,389 |  |  | 80,222 |  |
| Other businesses (a) (b) |  |  |  |  | 5,388 |  |  | 5,382 |  |  | 4,823 |  |
| Unallocated transactions (c) |  |  |  |  | 11 |  |  | 5 |  |  | (1) |  |
| Impact of purchase accounting (d) |  |  |  |  | (32) |  |  | (106) |  |  | (229) |  |
| Total consolidated net revenue |  |  |  |  | $ | 101,197 |  |  | $ | 86,670 |  |  | $ | 84,815 |  |
| Consolidated operating income: |  |  |  |  |  |  |  |  |  |
| Infrastructure Solutions Group |  |  |  |  | $ | 3,736 |  |  | $ | 3,753 |  |  | $ | 3,948 |  |
| Client Solutions Group |  |  |  |  | 4,365 |  |  | 3,333 |  |  | 3,114 |  |
| Reportable segment operating income |  |  |  |  | 8,101 |  |  | 7,086 |  |  | 7,062 |  |
| Other businesses (a) (b) |  |  |  |  | (319) |  |  | (139) |  |  | (217) |  |
| Unallocated transactions (c) |  |  |  |  | 3 |  |  | 2 |  |  | (29) |  |
| Impact of purchase accounting (d) |  |  |  |  | (67) |  |  | (144) |  |  | (274) |  |
| Amortization of intangibles |  |  |  |  | (1,641) |  |  | (2,133) |  |  | (2,971) |  |
| Transaction-related expenses (e) |  |  |  |  | (273) |  |  | (124) |  |  | (116) |  |
| Stock-based compensation expense (f) |  |  |  |  | (808) |  |  | (487) |  |  | (245) |  |
| Other corporate expenses (g) |  |  |  |  | (337) |  |  | (376) |  |  | (844) |  |
| Total consolidated operating income |  |  |  |  | $ | 4,659 |  |  | $ | 3,685 |  |  | $ | 2,366 |  |

[0001571996-22-000009:notes:419]
(a)Other businesses consists of i) VMware Resale, ii) Secureworks, and iii) Virtustream, and do not meet the requirements for a reportable segment, either individually or collectively.

[0001571996-22-000009:notes:420]
(b)The Company completed the sale of RSA Security on September 1, 2020, and the sale of Boomi on October 1, 2021.  Prior to the divestitures, Boomi and RSA Security’s results were included within other businesses.  See Note 1 of the Notes to the Consolidated Financial Statements for further details related to the divestitures of RSA Security and Boomi.

[0001571996-22-000009:notes:421]
(c)Unallocated transactions includes other corporate items that are not allocated to Dell Technologies’ reportable segments.

[0001571996-22-000009:notes:422]
(d)Impact of purchase accounting includes non-cash purchase accounting adjustments that are primarily related to the EMC merger transaction.

[0001571996-22-000009:notes:423]
(e)Transaction-related expenses includes acquisition, integration, and divestiture related costs, as well as the costs incurred in the VMware Spin-off described in Note 1 of the Notes to the Consolidated Financial Statements.

[0001571996-22-000009:notes:424]
(f)Stock-based compensation expense consists of equity awards granted based on the estimated fair value of those awards at grant date.

[0001571996-22-000009:notes:425]
(g)Other corporate expenses includes impairment charges, incentive charges related to equity investments, severance, facility action, and other costs.  For the fiscal year ended January 31, 2020 this category includes Virtustream pre-tax impairment charges of $619 million.

[0001571996-22-000009:notes:426]
The following table presents the disaggregation of net revenue by reportable segment, and by major product categories within the segments for the periods indicated:

[0001571996-22-000009:notes:427]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  | January 28, 2022 |  | January 29, 2021 |  | January 31, 2020 |
|  |  |  |  |  | (in millions) |
| Net revenue: |  |  |  |  |  |  |  |  |  |
| Infrastructure Solutions Group: |  |  |  |  |  |  |  |  |  |
| Servers and networking |  |  |  |  | $ | 17,901 |  |  | $ | 16,592 |  |  | $ | 17,193 |  |
| Storage |  |  |  |  | 16,465 |  |  | 16,410 |  |  | 17,174 |  |
| Total ISG net revenue |  |  |  |  | $ | 34,366 |  |  | $ | 33,002 |  |  | $ | 34,367 |  |
| Client Solutions Group: |  |  |  |  |  |  |  |  |  |
| Commercial |  |  |  |  | 45,576 |  |  | 35,423 |  |  | 34,293 |  |
| Consumer |  |  |  |  | 15,888 |  |  | 12,964 |  |  | 11,562 |  |
| Total CSG net revenue |  |  |  |  | $ | 61,464 |  |  | $ | 48,387 |  |  | $ | 45,855 |  |

[0001571996-22-000009:notes:428]
The following table presents net revenue allocated between the United States and foreign countries for the periods indicated:

[0001571996-22-000009:notes:429]
|  | Fiscal Year Ended |
|  | January 28, 2022 |  | January 29, 2021 |  | January 31, 2020 |
|  | (in millions) |
| Net revenue: |  |  |  |  |  |
| United States | $ | 46,752 |  |  | $ | 42,009 |  |  | $ | 40,338 |  |
| Foreign countries | 54,445 |  |  | 44,661 |  |  | 44,477 |  |
| Total net revenue | $ | 101,197 |  |  | $ | 86,670 |  |  | $ | 84,815 |  |

[0001571996-22-000009:notes:430]
The following table presents property, plant, and equipment, net allocated between the United States and foreign countries as of the dates indicated:

[0001571996-22-000009:notes:431]
|  | January 28, 2022 |  | January 29, 2021 |
|  | (in millions) |
| Property, plant, and equipment, net: |  |  |  |
| United States | $ | 3,667 |  |  | $ | 2,926 |  |
| Foreign countries | 1,748 |  |  | 1,907 |  |
| Total property, plant, and equipment, net | $ | 5,415 |  |  | $ | 4,833 |  |

[0001571996-22-000009:notes:432]
The allocation between domestic and foreign net revenue is based on the location of the customers.  Net revenue from any single foreign country did not constitute more than 10% of the Company’s consolidated net revenue for any of the fiscal years ended January 28, 2022, January 29, 2021, and January 31, 2020.  As of January 28, 2022 and January 29, 2021, property, plant, and equipment, net primarily related to domestic ownership with the remaining ownership consisting of individually immaterial balances in foreign countries.


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001571996-22-000009:notes:433]
SUPPLEMENTAL CONSOLIDATED FINANCIAL INFORMATION
The following table presents additional information on selected asset accounts included in the Consolidated Statements of Financial Position as of the dates indicated:

[0001571996-22-000009:notes:434]
|  | January 28, 2022 |  | January 29, 2021 |
|  | (in millions) |
| Cash, cash equivalents, and restricted cash: |  |  |  |
| Cash and cash equivalents | $ | 9,477 |  |  | $ | 9,508 |  |
| Restricted cash - other current assets (a) | 534 |  |  | 836 |  |
| Restricted cash - other non-current assets (a) | 71 |  |  | 70 |  |
| Total cash, cash equivalents, and restricted cash | $ | 10,082 |  |  | $ | 10,414 |  |
| Inventories, net: |  |  |  |
| Production materials | $ | 3,653 |  |  | $ | 1,718 |  |
| Work-in-process | 855 |  |  | 677 |  |
| Finished goods | 1,390 |  |  | 1,008 |  |
| Total inventories, net | $ | 5,898 |  |  | $ | 3,403 |  |
| Prepaid expenses: |  |  |  |
| Total prepaid expenses (c) | $ | 886 |  |  | $ | 721 |  |
| Deferred Costs: |  |  |  |
| Total deferred costs, current (c) | $ | 4,996 |  |  | $ | 4,306 |  |
| Property, plant, and equipment, net: |  |  |  |
| Computer equipment | $ | 6,497 |  |  | $ | 5,622 |  |
| Land and buildings | 3,095 |  |  | 3,169 |  |
| Machinery and other equipment | 2,714 |  |  | 3,093 |  |
| Total property, plant, and equipment | 12,306 |  |  | 11,884 |  |
| Accumulated depreciation and amortization (b) | (6,891) |  |  | (7,051) |  |
| Total property, plant, and equipment, net | $ | 5,415 |  |  | $ | 4,833 |  |

[0001571996-22-000009:notes:435]
(a)    Restricted cash includes cash required to be held in escrow pursuant to DFS securitization arrangements.

[0001571996-22-000009:notes:436]
(b)    During the fiscal years ended January 28, 2022, January 29, 2021, and January 31, 2020, the Company recognized $1.6 billion, $1.3 billion, and $1.1 billion, respectively, in depreciation expense.

[0001571996-22-000009:notes:437]
(c)    Deferred costs and prepaid expenses are included in other current assets in the Consolidated Statements of Financial Position.

[0001571996-22-000009:notes:438]
Valuation and Qualifying Accounts

[0001571996-22-000009:notes:439]
The provisions recognized on the Consolidated Statements of Income during the fiscal years ended January 29, 2021 and January 28, 2022 are based on assessments of the impact of current and expected future economic conditions, inclusive of the effect of the COVID-19 pandemic on credit losses related to trade receivables and financing receivables.  The duration and severity of COVID-19 and continued market volatility is highly uncertain and, as such, the impacts on expected credit losses for trade receivables and financing receivables are subject to significant judgment and may cause variability in the Company’s allowance for credit losses in future periods for trade receivables and financing receivables.  See Note 2 of the Notes to the Consolidated Financial Statements for additional information about the new CECL standard.

[0001571996-22-000009:notes:440]
The following table presents the Company’s valuation and qualifying accounts for the periods indicated:

[0001571996-22-000009:notes:441]
|  | Fiscal Year Ended |
|  | January 28, 2022 |  | January 29, 2021 |  | January 31, 2020 |
|  | (in millions) |
| Trade Receivables — Allowance for expected credit losses: |  |  |  |  |  |
| Balance at beginning of period | $ | 99 |  |  | $ | 88 |  |  | $ | 84 |  |
| Adjustment for adoption of accounting standard (a) | — |  |  | 27 |  |  | — |  |
| Allowance charged to provision | 32 |  |  | 46 |  |  | 64 |  |
| Bad debt write-offs | (41) |  |  | (62) |  |  | (60) |  |
| Balance at end of period | $ | 90 |  |  | $ | 99 |  |  | $ | 88 |  |
| Customer Financing Receivables — Allowance for financing receivable losses: |  |  |  |  |  |
| Balances at beginning of period | $ | 321 |  |  | $ | 149 |  |  | $ | 136 |  |
| Adjustment for adoption of accounting standard (a) | — |  |  | 111 |  |  | — |  |
| Charge-offs, net of recoveries (b) | (72) |  |  | (91) |  |  | (94) |  |
| Provision charged to income statement | (60) |  |  | 152 |  |  | 107 |  |
| Balances at end of period | $ | 189 |  |  | $ | 321 |  |  | $ | 149 |  |
| Tax Valuation Allowance: |  |  |  |  |  |
| Balance at beginning of period | $ | 1,297 |  |  | $ | 1,313 |  |  | $ | 1,364 |  |
| Charged to income tax provision | 155 |  |  | 41 |  |  | (2) |  |
| Charged to other accounts | (29) |  |  | (57) |  |  | (49) |  |
| Balance at end of period | $ | 1,423 |  |  | $ | 1,297 |  |  | $ | 1,313 |  |

[0001571996-22-000009:notes:442]
(a)    The Company adopted the current expected credit losses standard as of February 1, 2020 using the modified retrospective method, with the cumulative-effect adjustment to the opening balance of stockholders’ equity (deficit) as of the adoption date.

[0001571996-22-000009:notes:443]
(b)    Charge-offs for customer financing receivables includes principal and interest.

[0001571996-22-000009:notes:444]
Warranty Liability

[0001571996-22-000009:notes:445]
The following table presents changes in the Company’s liability for standard limited warranties for the periods indicated:

[0001571996-22-000009:notes:446]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  | January 28, 2022 |  | January 29, 2021 |  | January 31, 2020 |
|  |  |  |  |  | (in millions) |
| Warranty liability: |  |  |  |  |  |  |  |  |  |
| Warranty liability at beginning of period |  |  |  |  | $ | 473 |  |  | $ | 496 |  |  | $ | 524 |  |
| Costs accrued for new warranty contracts and changes in estimates for pre-existing warranties (a) (b) |  |  |  |  | 957 |  |  | 782 |  |  | 854 |  |
| Service obligations honored |  |  |  |  | (950) |  |  | (805) |  |  | (882) |  |
| Warranty liability at end of period |  |  |  |  | $ | 480 |  |  | $ | 473 |  |  | $ | 496 |  |
| Current portion |  |  |  |  | $ | 353 |  |  | $ | 356 |  |  | $ | 341 |  |
| Non-current portion |  |  |  |  | $ | 127 |  |  | $ | 117 |  |  | $ | 155 |  |

[0001571996-22-000009:notes:447]
(a)Changes in cost estimates related to pre-existing warranties are aggregated with accruals for new standard warranty contracts.  The Company’s warranty liability process does not differentiate between estimates made for pre-existing warranties and new warranty obligations.

[0001571996-22-000009:notes:448]
(b)Includes the impact of foreign currency exchange rate fluctuations.

[0001571996-22-000009:notes:449]
Severance Charges

[0001571996-22-000009:notes:450]
The Company incurs costs related to employee severance and records a liability for these costs when it is probable that employees will be entitled to termination benefits and the amounts can be reasonably estimated.  The liability related to these actions is included in accrued and other current liabilities in the Consolidated Statements of Financial Position.

[0001571996-22-000009:notes:451]
The following table presents the activity related to the Company’s severance liability for the periods indicated:

[0001571996-22-000009:notes:452]
|  |  |  | Fiscal Year Ended |
|  |  |  |  |  | January 28, 2022 |  | January 29, 2021 |  | January 31, 2020 |
|  |  |  |  |  | (in millions) |
| Severance liability: |  |  |  |  |  |  |  |  |  |
| Severance liability at beginning of period |  |  |  |  | $ | 109 |  |  | $ | 117 |  |  | $ | 102 |  |
| Severance charges |  |  |  |  | 134 |  |  | 368 |  |  | 174 |  |
| Cash paid and other |  |  |  |  | (169) |  |  | (376) |  |  | (159) |  |
| Severance liability at end of period |  |  |  |  | $ | 74 |  |  | $ | 109 |  |  | $ | 117 |  |

[0001571996-22-000009:notes:453]
The following table presents severance charges as included in the Consolidated Statements of Income for the periods indicated:

[0001571996-22-000009:notes:454]
|  | Fiscal Year Ended |
|  | January 28, 2022 |  | January 29, 2021 |  | January 31, 2020 |
|  | (in millions) |
| Severance charges: |  |  |  |  |  |
| Cost of net revenue | $ | 29 |  |  | $ | 58 |  |  | $ | 24 |  |
| Selling, general, and administrative | 98 |  |  | 262 |  |  | 122 |  |
| Research and development | 7 |  |  | 48 |  |  | 28 |  |
| Total severance charges | $ | 134 |  |  | $ | 368 |  |  | $ | 174 |  |

[0001571996-22-000009:notes:455]
Interest and other, net

[0001571996-22-000009:notes:456]
The following table presents information regarding interest and other, net for the periods indicated:

[0001571996-22-000009:notes:457]
|  | Fiscal Year Ended |
|  | January 28, 2022 |  | January 29, 2021 |  | January 31, 2020 |
|  | (in millions) |
| Interest and other, net: |  |  |  |  |  |
| Investment income, primarily interest | $ | 42 |  |  | $ | 47 |  |  | $ | 99 |  |
| Gain on investments, net | 569 |  |  | 425 |  |  | 158 |  |
| Interest expense | (1,542) |  |  | (2,052) |  |  | (2,334) |  |
| Foreign exchange | (221) |  |  | (160) |  |  | (195) |  |
| Gain on disposition of businesses and assets | 3,968 |  |  | 458 |  |  | — |  |
| Debt extinguishment fees | (1,572) |  |  | (158) |  |  | (83) |  |
| Other | 20 |  |  | 101 |  |  | (62) |  |
| Total interest and other, net | $ | 1,264 |  |  | $ | (1,339) |  |  | $ | (2,417) |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001571996-22-000009:notes:458]
RELATED PARTY TRANSACTIONS 
Effective upon the completion of the VMware Spin-off, VMware is considered to be a related party of the Company.  The related party relationship is a result of Michael Dell’s ownership interest in both Dell Technologies and VMware as well as Michael Dell’s continued positions as Chairman and Chief Executive Officer of Dell Technologies and as Chairman of the Board of VMware, Inc.  See Note 1 and Note 3 of the Notes to the Consolidated Financial Statements for more information about the VMware Spin-off.

[0001571996-22-000009:notes:459]
The information provided below includes a summary of transactions with VMware and with its consolidated subsidiaries (collectively, “VMware”).  Transactions with related parties other than VMware during the periods presented were immaterial, individually and in aggregate.

[0001571996-22-000009:notes:460]
Transactions with VMware

[0001571996-22-000009:notes:461]
Dell Technologies and VMware engage in the following ongoing related party transactions:

[0001571996-22-000009:notes:462]
•Pursuant to original equipment manufacturer and reseller arrangements, Dell Technologies integrates or bundles VMware’s products and services with Dell Technologies’ products and sells them to end-users.  Dell Technologies also acts as a distributor, purchasing VMware’s standalone products and services for resale to end-user customers.  Where applicable, costs under these arrangements are presented net of rebates received by Dell Technologies.

[0001571996-22-000009:notes:463]
•Dell Technologies procures products and services from VMware for its internal use.

[0001571996-22-000009:notes:464]
•Dell Technologies sells and leases products and sells services to VMware.  Sales of services were immaterial for all periods presented.

[0001571996-22-000009:notes:465]
•Dell Technologies and VMware also enter into joint marketing, sales, and branding arrangements, for which both parties may incur costs.

[0001571996-22-000009:notes:466]
•DFS provides financing to certain VMware’s end users.  Upon acceptance of the financing arrangement by both VMware’s end users and DFS, DFS recognizes amounts due to related parties on the Consolidated Statements of Financial Position.  Associated financing fees are recorded to net revenue on the Consolidated Statements of Income.  The associated financing fees were not material during the fiscal years ended January 28, 2022, January 29, 2021, and January 31, 2020.

[0001571996-22-000009:notes:467]
•Dell Technologies and VMware enter into agreements to collaborate on technology projects in which one party pays the corresponding party for services or the reimbursement of costs.  For the fiscal years ended January 28, 2022, January 29, 2021, and January 31, 2020 collaborative technology projects were not material.

[0001571996-22-000009:notes:468]
•Dell Technologies provides support services and support from Dell Technologies personnel to VMware in certain geographic regions where VMware does not have an established legal entity.  These employees are managed by VMware but Dell Technologies incurs the costs for these services.  The costs incurred by Dell Technologies on VMware’s behalf to these employees are charged to VMware.  For the fiscal years ended January 28, 2022, January 29, 2021, and January 31, 2020 costs associated with such seconded employees were not material.

[0001571996-22-000009:notes:469]
•Dell Technologies and VMware entered into the TSA in connection with the VMware Spin-off to provide various support services including investment advisory services, certain support services from Dell Technologies personnel, and other transitional services.  Costs associated with the TSA were not material for the fiscal year ended January 28, 2022.  See Note 1 and Note 3 of the Notes to the Consolidated Financial Statements for more information about the VMware Spin-off.

[0001571996-22-000009:notes:470]
The following table presents information about the impact of Dell Technologies’ related party transactions with VMware on the Consolidated Statements of Income for the periods indicated:

[0001571996-22-000009:notes:471]
|  |  |  | Fiscal Year Ended |
|  | Classification |  | January 28, 2022 |  | January 29, 2021 |  | January 31, 2020 |  |  |  |
|  |  |  | (in millions) |  |  |  |
| Sales and leases of products to VMware | Net revenue - products |  | $ | 188 |  |  | $ | 166 |  |  | $ | 94 |  |  |  |  |
| Purchase of VMware products for resale | Cost of net revenue - products |  | $ | 1,577 |  |  | $ | 1,493 |  |  | $ | 1,425 |  |  |  |  |
| Purchase of VMware services for resale | Cost of net revenue - services |  | $ | 2,487 |  |  | $ | 1,848 |  |  | $ | 1,226 |  |  |  |  |
| Purchase of VMware products and services for internal use | Operating expenses |  | $ | 66 |  |  | $ | 58 |  |  | $ | 68 |  |  |  |  |
| Consideration received from VMware for joint marketing, sales, and branding | Operating expenses |  | $ | (109) |  |  | $ | (110) |  |  | $ | (91) |  |  |  |  |

[0001571996-22-000009:notes:472]
The following table presents information about the impact of Dell Technologies’ related party transactions with VMware on the Consolidated Statements of Financial Position for the periods indicated:

[0001571996-22-000009:notes:473]
|  | Classification | January 28, 2022 |  | January 29, 2021 |
|  |  | (in millions) |
| Deferred costs related to VMware products and services for resale | Other current assets | $ | 2,571 |  |  | $ | 2,123 |  |
| Deferred costs related to VMware products and services for resale | Other non-current assets | $ | 2,311 |  |  | $ | 2,087 |  |

[0001571996-22-000009:notes:474]
Related Party Tax Matters

[0001571996-22-000009:notes:475]
Tax Sharing Agreement — In connection with the VMware Spin-off and concurrently with the execution of the Separation and Distribution Agreement, effective as of April 14, 2021, Dell Technologies and VMware entered into a Tax Matters Agreement (the “Tax Matters Agreement”) and agreed to terminate the tax sharing agreement as amended on December 30, 2019 (together with the Tax Matters Agreement, the “Tax Agreements”).  The Tax Matters Agreement governs Dell Technologies’ and VMware’s respective rights and obligations, both for pre-spin-off periods and post-spin-off periods, regarding income and other taxes, and related matters, including tax liabilities and benefits, attributes and returns.

[0001571996-22-000009:notes:476]
Net payments received from VMware pursuant to the Tax Agreements were $36 million, $307 million, and $159 million during the fiscal years ended January 28, 2022, January 29, 2021, and January 31, 2020, respectively, and relate to VMware’s portion of federal income taxes on Dell Technologies’ consolidated tax return as well as state tax payments for combined states.

[0001571996-22-000009:notes:477]
The timing of the tax payments due to and from related parties is governed by the Tax Agreements.  VMware’s portion of the mandatory one-time transition tax on accumulated earnings of foreign subsidiaries (the “Transition Tax”) is governed by a letter agreement between VMware and Dell Technologies entered into on April 1, 2019.

[0001571996-22-000009:notes:478]
As a result of the activity under the Tax Agreements with VMware, amounts due from VMware were $621 million and $451 million as of January 28, 2022 and January 29, 2021, respectively, primarily related to VMware’s estimated tax obligation resulting from the Transition Tax.  U.S. Tax Reform included a deferral election for an eight-year installment payment method on the Transition Tax.  Dell Technologies expects VMware to pay the remainder of its Transition Tax over a period of four years.

[0001571996-22-000009:notes:479]
Indemnification — Upon consummation of the VMware Spin-off, Dell Technologies recorded net income tax indemnification receivables from VMware related to certain income tax liabilities for which Dell Technologies is jointly and severally liable, but for which it is indemnified by VMware under the Tax Matters Agreement.  The amounts that VMware may be obligated to

[0001571996-22-000009:notes:480]
pay Dell Technologies could vary depending on the outcome of certain unresolved tax matters, which may not be resolved for several years.  The net receivable as of January 28, 2022 was $144 million.

[0001571996-22-000009:notes:481]
Due To/From Related Party

[0001571996-22-000009:notes:482]
The following table presents amounts due to and from VMware as of the dates indicated:

[0001571996-22-000009:notes:483]
|  | January 28, 2022 |  | January 29, 2021 |
|  | (in millions) |
| Due from related party, net, current (a) | $ | 131 |  |  | $ | 115 |  |
| Due from related party, net, non-current (b) | $ | 710 |  |  | $ | 451 |  |
| Due to related party, current (c) | $ | 1,414 |  |  | $ | 1,461 |  |

[0001571996-22-000009:notes:484]
(a)    Amounts due from related party, current consists of amounts due from VMware, inclusive of current net tax receivables from VMware under the Tax Agreements.  Amounts, excluding tax, are generally settled in cash within 60 days of each quarter-end.

[0001571996-22-000009:notes:485]
(b)  Amounts in due from related party, non-current consists of non-current portion of net receivables from VMware under the Tax Agreements.

[0001571996-22-000009:notes:486]
(c)  Amounts in due to related party, current includes amounts due to VMware which are generally settled in cash within 60 days of each quarter-end.

[0001571996-22-000009:notes:487]
Special Dividend by VMware

[0001571996-22-000009:notes:488]
On November 1, 2021, in connection with the closing of the VMware Spin-off, VMware paid a special cash dividend of $11.5 billion, in aggregate, to VMware common stockholders of record on October 29, 2021, of which Dell Technologies received approximately $9.3 billion.

[0001571996-22-000009:notes:489]
See Note 1 and Note 3 of the Notes to the Consolidated Financial Statements for more information about the VMware Spin-off.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001571996-22-000009:notes:490]
UNAUDITED QUARTERLY RESULTS 
The following tables present selected unaudited consolidated statements of income (loss) for each quarter of the periods indicated:

[0001571996-22-000009:notes:491]
|  | Fiscal 2022 |
|  | Q1 |  | Q2 |  | Q3 |  | Q4 |
|  | (in millions, except per share data) |
| Net revenue | $ | 22,590 |  |  | $ | 24,191 |  |  | $ | 26,424 |  |  | $ | 27,992 |  |
| Gross margin | $ | 5,264 |  |  | $ | 5,475 |  |  | $ | 5,534 |  |  | $ | 5,618 |  |
| Net income (loss) from continuing operations | $ | 659 |  |  | $ | 629 |  |  | $ | 3,683 |  |  | $ | (29) |  |
| Income from discontinued operations, net of income taxes | $ | 279 |  |  | $ | 251 |  |  | $ | 205 |  |  | $ | 30 |  |
| Net income attributable to Dell Technologies Inc. | $ | 887 |  |  | $ | 831 |  |  | $ | 3,843 |  |  | $ | 2 |  |
| Earnings (loss) per share attributable to Dell Technologies Inc. - basic |  |  |  |  |  |  |  |
| Continuing operations | $ | 0.87 |  |  | $ | 0.83 |  |  | $ | 4.81 |  |  | $ | (0.04) |  |
| Discontinued operations | $ | 0.30 |  |  | $ | 0.26 |  |  | $ | 0.21 |  |  | $ | 0.04 |  |
| Earnings (loss) per share attributable to Dell Technologies Inc. - diluted |  |  |  |  |  |  |  |
| Continuing operations | $ | 0.84 |  |  | $ | 0.80 |  |  | $ | 4.68 |  |  | $ | (0.04) |  |
| Discontinued operations | $ | 0.29 |  |  | $ | 0.25 |  |  | $ | 0.19 |  |  | $ | 0.04 |  |

[0001571996-22-000009:notes:492]
|  | Fiscal 2021 |
|  | Q1 |  | Q2 |  | Q3 |  | Q4 |
|  | (in millions, except per share data) |
| Net revenue | $ | 20,078 |  |  | $ | 20,853 |  |  | $ | 21,589 |  |  | $ | 24,150 |  |
| Gross margin | $ | 4,715 |  |  | $ | 4,877 |  |  | $ | 5,024 |  |  | $ | 5,524 |  |
| Net income (loss) from continuing operations | $ | 33 |  |  | $ | 924 |  |  | $ | 593 |  |  | $ | 695 |  |
| Income from discontinued operations, net of income taxes | $ | 149 |  |  | $ | 175 |  |  | $ | 288 |  |  | $ | 648 |  |
| Net income attributable to Dell Technologies Inc. | $ | 143 |  |  | $ | 1,048 |  |  | $ | 832 |  |  | $ | 1,227 |  |
| Earnings per share attributable to Dell Technologies Inc. - basic |  |  |  |  |  |  |  |
| Continuing operations | $ | 0.05 |  |  | $ | 1.25 |  |  | $ | 0.80 |  |  | $ | 0.93 |  |
| Discontinued operations | $ | 0.14 |  |  | $ | 0.16 |  |  | $ | 0.31 |  |  | $ | 0.71 |  |
| Earnings per share attributable to Dell Technologies Inc. - diluted |  |  |  |  |  |  |  |
| Continuing operations | $ | 0.05 |  |  | $ | 1.21 |  |  | $ | 0.77 |  |  | $ | 0.90 |  |
| Discontinued operations | $ | 0.14 |  |  | $ | 0.16 |  |  | $ | 0.31 |  |  | $ | 0.67 |  |


## us-gaap:SubsequentEventsTextBlock

[0001571996-22-000009:notes:493]
SUBSEQUENT EVENTS 
Dividend Announcement — On February 24, 2022, the Company announced that its Board of Directors has adopted a dividend policy under which the Company intends to pay quarterly cash dividends on its common stock, beginning in the first fiscal quarter of fiscal year 2023, at an initial rate of $0.33 per share per fiscal quarter.  The Company also announced that the Board of Directors has declared the initial quarterly dividend under the new policy in the amount of $0.33 per share, which will be payable on April 29, 2022 to the holders of record of all of the issued and outstanding shares of common stock as of the close of business on April 20, 2022.

[0001571996-22-000009:notes:494]
The dividend policy and the declaration and payment of each quarterly cash dividend will be subject to the Board of Director’s continuing determination that the policy and the declaration of dividends thereunder are in the best interests of the Company’s stockholders and are in compliance with applicable law.  The Board of Directors retains the power to modify, suspend, or cancel the dividend policy in any manner and at any time that it may deem necessary or appropriate.

[0001571996-22-000009:notes:495]
Other than the item noted above, there were no known events occurring after January 28, 2022 and up until the date of the issuance of this report that would materially affect the information presented herein.
