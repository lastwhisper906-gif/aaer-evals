# DELL 10-K controls and the auditor's report


## auditors_report

10-K auditors_report: 3 candidate headings, none whose body matches 'critical audit matter'.


## item_9a

[0001571996-18-000004:item_9a:1]
ITEM 9A — CONTROLS AND PROCEDURES

[0001571996-18-000004:item_9a:2]
This report includes the certifications of our Chief Executive Officer and Chief Financial Officer required by Rule 13a-14 under the Securities Exchange Act of 1934 (the "Exchange Act").  See Exhibits 31.1 and 31.2 filed with this report.  This Item 9A includes information concerning the controls and control evaluations referred to in those certifications.

[0001571996-18-000004:item_9a:3]
Evaluation of Disclosure Controls and Procedures

[0001571996-18-000004:item_9a:4]
Disclosure controls and procedures (as defined in Rules 13a-15(e) and 15d-15(e) under the Exchange Act) are designed to provide reasonable assurance that information required to be disclosed in reports filed or submitted under the Exchange Act is recorded, processed, summarized, and reported within the time periods specified in SEC rules and forms and that such information is accumulated and communicated to management, including the chief executive officer and the chief financial officer, as appropriate to allow timely decisions regarding required disclosures.

[0001571996-18-000004:item_9a:5]
In connection with the preparation of this report, our management, under the supervision and with the participation of our Chief Executive Officer and Chief Financial Officer, conducted an evaluation of the effectiveness of the design and operation of our disclosure controls and procedures as of February 2, 2018.  Based on that evaluation, our Chief Executive Officer and Chief Financial Officer have concluded that our disclosure controls and procedures were effective at the reasonable assurance level as of February 2, 2018.

[0001571996-18-000004:item_9a:6]
Management’s Annual Report on Internal Control Over Financial Reporting

[0001571996-18-000004:item_9a:7]
Management, under the supervision of the Chief Executive Officer and the Chief Financial Officer, is responsible for establishing and maintaining adequate internal control over financial reporting.  Internal control over financial reporting (as defined in Rules 13a-15(f) and 15d(f) under the Exchange Act) is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles.  Internal control over financial reporting includes those policies and procedures which (a) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of assets, (b) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, (c) provide reasonable assurance that receipts and expenditures are being made only in accordance with appropriate authorization of management and the board of directors, and (d) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of assets that could have a material effect on the financial statements.

[0001571996-18-000004:item_9a:8]
In connection with the preparation of this report, our management, under the supervision and with the participation of our Chief Executive Officer and Chief Financial Officer, conducted an evaluation of the effectiveness of our internal control over financial reporting as of February 2, 2018, based on the criteria established in Internal Control — Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission.  As a result of that evaluation, management has concluded that our internal control over financial reporting was effective as of February 2, 2018.

[0001571996-18-000004:item_9a:9]
The effectiveness of our internal control over financial reporting as of February 2, 2018, has been audited by PricewaterhouseCoopers LLP, our independent registered public accounting firm, as stated in their report, which is included in “Part II — Item 8 — Financial Statements and Supplementary Data.”

[0001571996-18-000004:item_9a:10]
Changes in Internal Control Over Financial Reporting

[0001571996-18-000004:item_9a:11]
On September 7, 2016, we completed our acquisition by merger of EMC Corporation as described elsewhere in this report.  We continue to integrate policies, processes, people, technology, and operations relating to this transaction, and will continue to evaluate the impact of any related changes to our internal control over financial reporting.  There were no changes in our internal control over financial reporting during the fiscal quarter ended February 2, 2018 that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.

[0001571996-18-000004:item_9a:12]
171

[0001571996-18-000004:item_9a:13]
Limitations on the Effectiveness of Controls

[0001571996-18-000004:item_9a:14]
Our system of controls is designed to provide reasonable, not absolute, assurance regarding the reliability and integrity of accounting and financial reporting. Management does not expect that our disclosure controls and procedures or our internal control over financial reporting will prevent or detect all errors and all fraud. A control system, no matter how well designed and operated, can provide only reasonable, not absolute, assurance that the objectives of the control system will be met. These inherent limitations include the following:

[0001571996-18-000004:item_9a:15]
| • | Judgments in decision-making can be faulty, and control and process breakdowns can occur because of simple errors or mistakes. |

[0001571996-18-000004:item_9a:16]
| • | Controls can be circumvented by individuals, acting alone or in collusion with each other, or by management override. |

[0001571996-18-000004:item_9a:17]
| • | The design of any system of controls is based in part on certain assumptions about the likelihood of future events, and there can be no assurance that any design will succeed in achieving its stated goals under all potential future conditions. |

[0001571996-18-000004:item_9a:18]
| • | Over time, controls may become inadequate because of changes in conditions or deterioration in the degree of compliance with associated policies or procedures. |

[0001571996-18-000004:item_9a:19]
| • | The design of a control system must reflect the fact that resources are constrained, and the benefits of controls must be considered relative to their costs. |
