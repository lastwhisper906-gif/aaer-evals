# DELL note change history — 0001571996-17-000020 → 0001571996-17-000045


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2017-12-12):
[0001571996-17-000045:note_history:1]
The complaints in the IBEW, Barrett, Graulich, Vassallo, City of Miami, Lasker, Local Union No. 373, City of Lakeland, and Ma actions generally allege that the EMC directors breached their fiduciary duties to EMC shareholders in connection with the EMC merger by, among other things, failing to maximize shareholder value and agreeing to provisions in the EMC merger agreement that discouraged competing bids.  After consolidating the fifteen complaints, by decision dated December 7, 2015, the Business Litigation Session of the Suffolk County Superior Court in Massachusetts dismissed all nine complaints for failure to make a demand on the EMC board of directors.  Three of the nine plaintiffs in the consolidated actions appealed the judgment dismissing their complaints.  The Massachusetts Supreme Judicial Court granted an application for direct appellate review, and heard oral argument on the appeal on November 7, 2016.  On March 6, 2017, the Supreme Judicial Court issued a decision affirming the dismissal.  This decision terminated the consolidated actions.
  (was, 2017-09-08, similarity 0.9947):
[0001571996-17-000020:note_history:1]
The complaints in the IBEW, Barrett, Graulich, Vassallo, City of Miami, Lasker, Local Union No. 373, City of Lakeland, and Ma actions generally allege that the EMC directors breached their fiduciary duties to EMC shareholders in connection with the EMC merger by, among other things, failing to maximize shareholder value and agreeing to provisions in the EMC merger agreement that discouraged competing bids.  After consolidating the nine complaints, by decision dated December 7, 2015, the Business Litigation Session of the Suffolk County Superior Court in Massachusetts dismissed all nine complaints for failure to make a demand on the EMC board of directors.  Three of the nine plaintiffs in the consolidated actions appealed the judgment dismissing their complaints.  The Massachusetts Supreme Judicial Court granted an application for direct appellate review, and heard oral argument on the appeal on November 7, 2016.  On March 6, 2017, the Supreme Judicial Court issued a decision affirming the dismissal.  This decision terminated the consolidated actions.

- changed (2017-12-12):
[0001571996-17-000045:note_history:2]
The complaints in the Walsh, Stull, Pancake, and Booth actions allege that the EMC directors breached their fiduciary duties to EMC shareholders in connection with the EMC merger by, among other things, failing to maximize shareholder value and agreeing to provisions in the EMC merger agreement that discouraged competing bids.  The complaints generally further allege that the preliminary registration statement on Form S-4 filed by the Company on December 14, 2015, in connection with the transaction contained material misstatements and omissions, in violation of Section 14(a) of the Securities Exchange Act of 1934 (the "Exchange Act") and SEC Rule 14a-9 promulgated thereunder and that the Company, Dell, and Universal acted as controlling persons of EMC under Section 20(a) of the Exchange Act.  On June 6, 2016, the Securities and Exchange Commission declared effective the Company's registration statement on Form S-4 relating to the EMC merger (the "SEC Form S-4"), including the amendments thereto.  On June 17, 2016, the parties to the Walsh, Stull, Pancake, and Booth actions submitted to the Court a Stipulation and Proposed Order Dismissing Action and Retaining Jurisdiction to Determine Plaintiffs' Counsel's Application for an Award of Attorneys' Fees and Reimbursement of Expenses.  In the stipulation, the plaintiffs represented to the Court that they believe sufficient information had been disclosed to warrant dismissal of the actions as moot in light of the disclosures in the SEC Form S-4, including the amendments thereto.  On October 25, 2016, following an agreement between the parties with respect to payment of attorneys' fees and expenses, the Court entered an order terminating the four actions for all purposes.
  (was, 2017-09-08, similarity 0.9918):
[0001571996-17-000020:note_history:2]
The complaints in the Walsh, Stull, Pancake, and Booth actions allege that the EMC directors breached their fiduciary duties to EMC shareholders in connection with the EMC merger by, among other things, failing to maximize shareholder value and agreeing to provisions in the EMC merger agreement that discouraged competing bids.  The complaints generally further allege that the preliminary registration statement on Form S-4 filed by the Company on December 14, 2015 in connection with the transaction contained material misstatements and omissions, in violation of Section 14(a) of the Securities Exchange Act of 1934 (the "Exchange Act") and SEC Rule 14a-9 promulgated thereunder and/or that the Company, Dell, and Universal acted as controlling persons of EMC under Section 20(a) of the Exchange Act.  On June 6, 2016, the Securities and Exchange Commission declared effective the Company's registration statement on Form S-4 relating to the EMC merger (the "SEC Form S-4"), including the amendments thereto.  On June 17, 2016, the parties to the Walsh, Stull, Pancake, and Booth actions submitted to the Court a Stipulation and Proposed Order Dismissing Action and Retaining Jurisdiction to Determine Plaintiffs' Counsel's Application for an Award of Attorneys' Fees and Reimbursement of Expenses.  In the stipulation, the plaintiffs represented to the Court that they believe sufficient information had been disclosed to warrant dismissal of the actions as moot in light of the disclosures in the SEC Form S-4, including the amendments thereto.  On October 25, 2016, following an agreement between the parties with respect to attorneys' fees and expenses, the Court entered an order terminating the four actions for all purposes.

- changed (2017-12-12):
[0001571996-17-000045:note_history:3]
Appraisal Proceedings — On October 29, 2013, Dell Technologies acquired Dell in a transaction referred to as the going-private transaction.  Holders of shares of Dell common stock who did not vote on September 12, 2013 in favor of the proposal to adopt the amended going-private transaction agreement and who properly demanded appraisal of their shares and who otherwise comply with the requirements of Section 262 of the Delaware General Corporate Law ("DGCL") are entitled to seek appraisal for, and obtain payment in cash for the judicially determined "fair value" (as defined pursuant to Section 262 of the DGCL) of, their shares in lieu of receiving the going-private transaction consideration.  Dell initially recorded a liability of $13.75 for each share with respect to which appraisal has been demanded and as to which the demand has not been withdrawn, together with interest at the statutory rate discussed below.  This liability was approximately $129 million as of both November 3, 2017 and February 3, 2017.  The Court of Chancery ruled that the fair value of the appraisal shares as of October 29, 2013, the date on which the going-private transaction became effective, was $17.62 per share.  This ruling would entitle the holders of the remaining 5,505,730 shares subject to the appraisal proceedings to $17.62 per share, plus interest at a statutory rate, compounded quarterly.  On November 21, 2016, the Court of Chancery entered final judgment in the appraisal action.  On November 22, 2016, Dell filed a notice of appeal to the Delaware Supreme Court, and a hearing was held on that appeal on September 27, 2017.  A ruling on the appeal is pending.  The Company believes it was adequately reserved for the appraisal proceedings as of November 3, 2017.
  (was, 2017-09-08, similarity 0.9617):
[0001571996-17-000020:note_history:3]
Appraisal Proceedings — On October 29, 2013, Dell Technologies acquired Dell in a transaction referred to as the going-private transaction.  Holders of shares of Dell common stock who did not vote on September 12, 2013 in favor of the proposal to adopt the amended going-private transaction agreement and who properly demanded appraisal of their shares and who otherwise comply with the requirements of Section 262 of the Delaware General Corporate Law ("DGCL") are entitled to seek appraisal for, and obtain payment in cash for the judicially determined "fair value" (as defined pursuant to Section 262 of the DGCL) of, their shares in lieu of receiving the going-private transaction consideration.  Dell initially recorded a liability of $13.75 for each share with respect to which appraisal has been demanded and as to which the demand has not been withdrawn, together with interest at the statutory rate discussed below.  This liability was approximately $129 million as of both August 4, 2017 and February 3, 2017.  The Court of Chancery ruled that the fair value of the appraisal shares as of October 29, 2013, the date on which the going-private transaction became effective, was $17.62 per share.  This ruling would entitle the holders of the remaining 5,505,730 shares subject to the appraisal proceedings to $17.62 per share, plus interest at a statutory rate, compounded quarterly.  On November 21, 2016, the Court of Chancery entered final judgment in the appraisal action.  On November 22, 2016, Dell filed a notice of appeal to the Delaware Supreme Court, and a hearing is scheduled on that appeal for September 27, 2017.  The Company believes it was adequately reserved for the appraisal proceedings as of August 4, 2017.

- added (2017-12-12):
[0001571996-17-000045:note_history:4]
As of November 3, 2017, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for these or other proceedings or matters has been incurred.  However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company's business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters.  Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company's business, financial condition, results of operations, or cash flows will depend on a number of variables, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.

- changed (2017-12-12):
[0001571996-17-000045:note_history:5]
The Company has contractual obligations to purchase goods or services, which specify significant terms, including fixed or minimum quantities to be purchased; fixed, minimum, or variable price provisions; and the approximate timing of the transaction.  As of November 3, 2017, the Company had $3,055 million, $278 million, and $458 million in purchase obligations for Fiscal 2018 (remaining three months), Fiscal 2019, and Fiscal 2020 and thereafter, respectively.
  (was, 2017-09-08, similarity 0.8082):
[0001571996-17-000020:note_history:5]
The Company has contractual obligations to purchase goods or services, which specify significant terms, including fixed or minimum quantities to be purchased; fixed, minimum, or variable price provisions; and the approximate timing of the transaction.  As of August 4, 2017, the Company had $2,724 million, $267 million, and $448 million in purchase obligations for Fiscal 2018 (remaining six months), Fiscal 2019, and Fiscal 2020 and thereafter, respectively.

- removed (2017-12-12):
[0001571996-17-000020:note_history:6]
As of August 4, 2017, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for these or other proceedings or matters has been incurred.  However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company's business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters.  Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company's business, financial condition, results of operations, or cash flows will depend on a number of variables, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2017-12-12):
[0001571996-17-000045:note_history:7]
Basis of Presentation — The accompanying unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes filed with the U.S. Securities and Exchange Commission ("SEC") in the Company's Annual Report on Form 10-K for the fiscal year ended February 3, 2017.  These Condensed Consolidated Financial Statements have been prepared in accordance with accounting principles generally accepted in the United States of America ("GAAP").  In the opinion of management, the accompanying Condensed Consolidated Financial Statements reflect all adjustments of a normal recurring nature considered necessary to fairly state the financial position of Dell Technologies Inc. (individually and together with its consolidated subsidiaries, the "Company" or "Dell Technologies") as of November 3, 2017 and February 3, 2017, the results of its operations and corresponding comprehensive income (loss) for the three and nine months ended November 3, 2017 and October 28, 2016, as well as its cash flows for the nine months ended November 3, 2017 and October 28, 2016.
  (was, 2017-09-08, similarity 0.8449):
[0001571996-17-000020:note_history:7]
Basis of Presentation — The accompanying unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes filed with the U.S. Securities and Exchange Commission ("SEC") in the Company's Annual Report on Form 10-K for the fiscal year ended February 3, 2017.  These Condensed Consolidated Financial Statements have been prepared in accordance with accounting principles generally accepted in the United States of America ("GAAP").  In the opinion of management, the accompanying Condensed Consolidated Financial Statements reflect all adjustments of a normal recurring nature considered necessary to fairly state the financial position of Dell Technologies Inc. (individually and together with its consolidated subsidiaries, the "Company" or "Dell Technologies") as of August 4, 2017 and February 3, 2017, the results of its operations and corresponding comprehensive income (loss) for the three and six months ended August 4, 2017 and July 29, 2016, as well as its cash flows for the six months ended August 4, 2017 and July 29, 2016.

- changed (2017-12-12):
[0001571996-17-000045:note_history:8]
The preparation of financial statements in accordance with GAAP requires management to make estimates and assumptions that affect the amounts reported in the Condensed Consolidated Financial Statements and the accompanying Notes.  Actual results could differ materially from those estimates.  The results of operations and comprehensive income (loss) for the three and nine months ended November 3, 2017 and October 28, 2016 and cash flows for the nine months ended November 3, 2017 and October 28, 2016 are not necessarily indicative of the results to be expected for the full fiscal year or for any other fiscal period.
  (was, 2017-09-08, similarity 0.7345):
[0001571996-17-000020:note_history:8]
The preparation of financial statements in accordance with GAAP requires management to make estimates and assumptions that affect the amounts reported in the Condensed Consolidated Financial Statements and the accompanying Notes.  Actual results could differ materially from those estimates.  The results of operations and comprehensive income (loss) for the three and six months ended August 4, 2017 and July 29, 2016 and cash flows for the six months ended August 4, 2017 and July 29, 2016 are not necessarily indicative of the results to be expected for the full fiscal year or for any other fiscal period.

- added (2017-12-12):
[0001571996-17-000045:note_history:9]
As a result of the EMC merger transaction completed on September 7, 2016, the Company's results of operations, comprehensive income (loss), and cash flows for the fiscal periods reflected in these Condensed Consolidated Financial Statements are not directly comparable as the results of the acquired businesses are only included in the consolidated results from September 7, 2016.

- changed (2017-12-12):
[0001571996-17-000045:note_history:10]
Unless the context indicates otherwise, references in these Notes to the Condensed Consolidated Financial Statements to "VMware" mean the VMware reportable segment, which reflects the operations of VMware, Inc. (NYSE: VMW) within Dell Technologies.  See Exhibit 99.1 filed with the Company's quarterly report on Form 10-Q for the quarterly period ended November 3, 2017 for information on the differences between VMware reportable segment results and VMware, Inc. results.
  (was, 2017-09-08, similarity 0.855):
[0001571996-17-000020:note_history:10]
Unless the context indicates otherwise, references in these Notes to the Condensed Consolidated Financial Statements to "VMware" mean the VMware reportable segment, which reflects the operations of VMware, Inc. (NYSE: VMW) within Dell Technologies.  See Exhibit 99.1 filed with the Company's quarterly report on Form 10-Q for the quarterly period ended August 4, 2017 for information on the differences between VMware reportable segment results and VMware, Inc. results.

- changed (2017-12-12):
[0001571996-17-000045:note_history:11]
Recognition and Measurement of Financial Assets and Financial Liabilities — In January 2016, the FASB issued amended guidance that addresses certain aspects of recognition, measurement, presentation, and disclosure of financial instruments.  Public entities must adopt the new guidance for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017.  The amended guidance requires changes in the fair value of equity investments to be recognized through net income, rather than other comprehensive income.  Adoption of the standard will be applied through a cumulative one-time adjustment to retained earnings.  For the Company’s equity investments without readily determinable fair values, the Company expects to elect the measurement alternative to record those investments at cost, less impairment, and adjusted by observable price changes on a prospective basis.  The impact of the standard on the Consolidated Statements of Income (Loss) will depend on the relative changes in market price of the equity investments.
  (was, 2017-09-08, similarity 0.972):
[0001571996-17-000020:note_history:11]
Recognition and Measurement of Financial Assets and Financial Liabilities — In January 2016, the FASB issued amended guidance that addresses certain aspects of recognition, measurement, presentation, and disclosure of financial instruments.  Public entities must adopt the new guidance for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017.  The amended guidance requires changes in the fair value of equity investments to be recognized through net income, rather than other comprehensive income.  Adoption of the standard will be applied through a cumulative one-time adjustment to retained earnings.  For the Company’s equity investments without readily determinable fair values, the Company expects to elect the measurement alternative to record those investments at cost, less impairment, and adjusted by observable price changes on a prospective basis.  The impact of the standard on the Consolidated Statements of Income (Loss) will depend on the relative changes in market price of the equity investments, although the impact is currently expected to be immaterial.

- added (2017-12-12):
[0001571996-17-000045:note_history:12]
Leases — In February 2016, the FASB issued amended guidance on the accounting for leasing transactions.  The primary objective of this update is to increase transparency and comparability among organizations by requiring lessees to recognize lease assets and lease liabilities on the balance sheet and disclosing key information about leasing arrangements.  The guidance makes some changes to lessor accounting, including the elimination of the use of third-party residual value guarantee insurance in the sales-type lease test.  Public entities must adopt the new guidance for reporting periods beginning after December 15, 2018, with early adoption permitted.  Companies are required to use a modified retrospective approach for leases that exist or are entered into after the beginning of the earliest comparative period in the financial statements.  The Company is currently evaluating the impact that the standard will have on the Consolidated Financial Statements.

- changed (2017-12-12):
[0001571996-17-000045:note_history:13]
Classification of Certain Cash Receipts and Cash Payments — In August 2016, the FASB issued amended guidance on the presentation and classification of eight specific cash flow issues with the objective of reducing existing diversity in practice.  Public entities must adopt the new guidance for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017, with early adoption permitted.  Companies should reflect any adjustments on a retrospective basis, if practicable; otherwise, adoption is required to be applied as of the earliest date practicable.  The Company will adopt this standard as of May 4, 2018, and will apply adjustments retrospectively to each prior period presented on the Condensed Consolidated Statements of Cash Flows for that period.  The Company is currently evaluating the impact of the standard, and other than certain reclassifications on the Consolidated Statements of Cash Flows, it is not expected to have a material impact on the Consolidated Financial Statements.
  (was, 2017-09-08, similarity 0.9819):
[0001571996-17-000020:note_history:13]
Classification of Certain Cash Receipts and Cash Payments — In August 2016, the FASB issued amended guidance on the presentation and classification of eight specific cash flow issues with the objective of reducing existing diversity in practice.  Public entities must adopt the new guidance for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017, with early adoption permitted.  Companies should reflect any adjustments on a retrospective basis, if practicable; otherwise, adoption is required to be applied as of the earliest date practicable.  The Company will adopt this standard during the fiscal quarter ending May 4, 2018, and will apply adjustments retrospectively to each prior period presented on the Condensed Consolidated Statements of Cash Flows for that period.  The Company is currently evaluating the impact of the standard, and other than certain reclassifications on the Consolidated Statements of Cash Flows, it is not expected to have a material impact on the Consolidated Financial Statements.

- added (2017-12-12):
[0001571996-17-000045:note_history:14]
Statement of Cash Flows, Restricted Cash — In November 2016, the FASB issued amended guidance requiring entities to include explanations of changes in restricted cash and restricted cash equivalents on the cash flow statement, and also to provide a supplemental reconciliation of cash, cash equivalents and restricted cash.  Public entities must adopt the new guidance for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017, with early adoption permitted. The Company will adopt this standard as of May 4, 2018, and will apply adjustments retrospectively to each prior period presented on the Condensed Consolidated Statements of Cash Flows for that period and provide the supplemental reconciliation.  The Company does not expect that the standard will have a material impact on its Consolidated Financial Statements as its restricted cash balance does not change significantly from period to period.

- changed (2017-12-12):
[0001571996-17-000045:note_history:15]
Derivatives and Hedging — In August 2017, the FASB issued amended guidance that will make more financial and non-financial hedging strategies eligible for hedge accounting.  The amended guidance changes how companies assess effectiveness, and also amends the presentation and disclosure requirements.  The guidance is intended to simplify the application of hedge accounting and increase transparency as to the scope and results of hedging programs.  Immediate early adoption is permitted in any interim or annual period.  The Company will early adopt this guidance at the beginning of the fiscal year ending February 1, 2019.  The Company is currently evaluating the application of the new guidance, but does not expect that it will have a material impact on the Consolidated Financial Statements.
  (was, 2017-09-08, similarity 0.7497):
[0001571996-17-000020:note_history:15]
Derivatives and Hedging — In August 2017, the FASB issued amended guidance that will make more financial and non-financial hedging strategies eligible for hedge accounting.  The amended guidance changes how companies assess effectiveness, and also amends the presentation and disclosure requirements.  The guidance is intended to simplify the application of hedge accounting and increase transparency as to the scope and results of hedging programs.  Immediate early adoption is permitted in any interim or annual period.  The mandatory effective date for calendar year-end public companies is January 1, 2019.  The Company is currently evaluating the impact that the new guidance will have on the Consolidated Financial Statements.

- removed (2017-12-12):
[0001571996-17-000020:note_history:16]
As a result of the EMC merger transaction completed on September 7, 2016, the Company's results of operations, comprehensive income (loss), and cash flows for the fiscal periods reflected in these Condensed Consolidated Financial Statements are not directly comparable.  The results of the businesses acquired in the EMC merger transaction are included in the consolidated results of Dell Technologies for the three and six months ended August 4, 2017, but are not included in the consolidated results of Dell Technologies for the three and six months ended July 29, 2016.  The Dell Technologies unaudited Condensed Consolidated Statements of Financial Position reflect the full consolidation of EMC's assets and liabilities as of both August 4, 2017 and February 3, 2017.

- removed (2017-12-12):
[0001571996-17-000020:note_history:17]
Reclassifications — The amounts presented for the three and six months ended July 29, 2016 are different from those previously reported on Form 10-Q for the quarterly period ended July 29, 2016 because the Company reclassified an immaterial amount of net income from discontinued operations to continuing operations to reflect the updated terms of the applicable divestitures referred to above as the result of continued negotiations and finalization of terms of the sale.

- removed (2017-12-12):
[0001571996-17-000020:note_history:18]
Leases — In February 2016, the FASB issued amended guidance on the accounting for leasing transactions.  The primary objective of this update is to increase transparency and comparability among organizations by recognizing lease assets and lease liabilities on the balance sheet and disclosing key information about leasing arrangements.  Public entities must adopt the new guidance for reporting periods beginning after December 15, 2018, with early adoption permitted.  Companies are required to use a modified retrospective approach for leases that exist or are entered into after the beginning of the earliest comparative period in the financial statements.  The Company is currently evaluating the impact that the standard will have on the Consolidated Financial Statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2017-12-12):
[0001571996-17-000045:note_history:19]
|  | November 3, 2017 |  | February 3, 2017 |
|  | (in millions) |
| Secured Debt |  |  |  |
| Structured financing debt | $ | 4,348 |  |  | $ | 3,464 |  |
| Senior Secured Credit Facilities: |  |  |  |
| 3.25% Term Loan B Facility due September 2023 | 5,000 |  |  | 4,987 |  |
| Term Loan A-1 Facility due December 2018 | — |  |  | 600 |  |
| 3.00% Term Loan A-2 Facility due September 2021 | 4,450 |  |  | 3,876 |  |
| 2.75% Term Loan A-3 Facility due December 2018 | 1,438 |  |  | 1,800 |  |
| 2.75% Revolving Credit Facility due September 2021 | — |  |  | 375 |  |
| First Lien Notes: |  |  |  |
| 3.48% due June 2019 | 3,750 |  |  | 3,750 |  |
| 4.42% due June 2021 | 4,500 |  |  | 4,500 |  |
| 5.45% due June 2023 | 3,750 |  |  | 3,750 |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 8.10% due June 2036 | 1,500 |  |  | 1,500 |  |
| 8.35% due June 2046 | 2,000 |  |  | 2,000 |  |
| Unsecured Debt |  |  |  |
| Unsecured Notes and Debentures: |  |  |  |
| 5.65% due April 2018 | 500 |  |  | 500 |  |
| 5.875% due June 2019 | 600 |  |  | 600 |  |
| 4.625% due April 2021 | 400 |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 265 |  |  | 265 |  |
| Senior Notes: |  |  |  |
| 5.875% due June 2021 | 1,625 |  |  | 1,625 |  |
| 7.125% due June 2024 | 1,625 |  |  | 1,625 |  |
| EMC Notes: |  |  |  |
| 1.875% due June 2018 | 2,500 |  |  | 2,500 |  |
| 2.650% due June 2020 | 2,000 |  |  | 2,000 |  |
| 3.375% due June 2023 | 1,000 |  |  | 1,000 |  |
| VMware Notes: |  |  |  |
| 2.30% due August 2020 | 1,250 |  |  | — |  |
| 2.95% due August 2022 | 1,500 |  |  | — |  |
| 3.90% due August 2027 | 1,250 |  |  | — |  |
| Other |  |  |  |
| 3.63% Margin Loan Facility due April 2022 | 2,000 |  |  | — |  |
| Margin Bridge Facility due September 2017 | — |  |  | 2,500 |  |
| VMware Note Bridge Facility due September 2017 | — |  |  | 1,500 |  |
| Other | 83 |  |  | 51 |  |
| Total debt, principal amount | $ | 52,522 |  |  | $ | 50,356 |  |
| Unamortized discount, net of unamortized premium | (268 | ) |  | (284 | ) |
| Debt issuance costs | (603 | ) |  | (682 | ) |
| Total debt, carrying value | $ | 51,651 |  |  | $ | 49,390 |  |
| Total short-term debt, carrying value | $ | 6,235 |  |  | $ | 6,329 |  |
| Total long-term debt, carrying value | $ | 45,416 |  |  | $ | 43,061 |  |

- added (2017-12-12):
[0001571996-17-000045:note_history:20]
During the nine months ended November 3, 2017 the Company completed two refinancing transactions of the Senior Secured Credit Facilities described below.  In the first refinancing transaction, which occurred during the three months ended May 5, 2017, the Company refinanced the Term Loan B Facility to reduce the interest rate margin by 0.75% and to increase the outstanding principal amount by $500 million.  The Company applied the proceeds from the Term Loan B Facility refinancing to repay $500 million principal amount of the Margin Bridge Facility, without premium or penalty, and accrued and unpaid interest thereon.  Additionally, during the three months ended May 5, 2017, the Company entered into the Margin Loan Facility in the principal amount of $2.0 billion, and used the proceeds of the new facility to repay the Margin Bridge Facility, without premium or penalty.

- added (2017-12-12):
[0001571996-17-000045:note_history:21]
In the second refinancing transaction, which occurred during the three months ended November 3, 2017, the Company refinanced the Term Loan A-2 Facility, Term Loan A-3 Facility, Term Loan B Facility, and the Revolving Credit Facility.  As a result, the interest rate margin decreased 0.50% for each of the Term Loan A-2 Facility, Term Loan A-3 Facility, Term Loan B Facility, and the Revolving Credit Facility.  Additionally, the outstanding principal amount of the Term Loan A-2 Facility increased by $672 million which was used to pay $212 million of principal outstanding of the Term Loan A-3 Facility and $460 million of principal outstanding of the Term Loan B Facility.  Further, the Revolving Credit Facility's borrowing capacity increased $180 million to $3.3 billion.

- added (2017-12-12):
[0001571996-17-000045:note_history:22]
During the nine months ended November 3, 2017, the Company repaid approximately $0.9 billion principal amount of its term loan facilities and $0.4 billion under the Revolving Credit Facility and issued an additional $0.9 billion, net, in structured financing debt to support the expansion of its financing receivables portfolio.

- added (2017-12-12):
[0001571996-17-000045:note_history:23]
Further, during the three months ended November 3, 2017, VMware, Inc. completed a public offering of senior notes in the aggregate amount of $4.0 billion.  VMware, Inc. used a portion of the net proceeds from the offering to repay certain intercompany promissory notes previously issued by it to EMC in the aggregate principal amount of $1.2 billion.  The Company applied the proceeds of this repayment, and other cash, to repay $1.5 billion principal amount of the VMware Note Bridge Facility, without premium or penalty.

- changed (2017-12-12):
[0001571996-17-000045:note_history:24]
Senior Secured Credit Facilities — At the closing of the EMC merger transaction on September 7, 2016, the Company entered into a credit agreement that provides for senior secured credit facilities (the "Senior Secured Credit Facilities") in the aggregate principal amount of $17.8 billion comprising (a) term loan facilities and (b) a senior secured Revolving Credit Facility, which includes capacity for up to $0.5 billion of letters of credit and for borrowings of up to $0.4 billion under swing-line loans.  As of November 3, 2017, available borrowings under the Revolving Credit Facility totaled $3.3 billion.  The Senior Secured Credit Facilities provide that the borrowers have the right at any time, subject to customary conditions, to request incremental term loans or incremental revolving commitments.
  (was, 2017-09-08, similarity 0.9911):
[0001571996-17-000020:note_history:24]
Senior Secured Credit Facilities — At the closing of the EMC merger transaction on September 7, 2016, the Company entered into a credit agreement that provides for senior secured credit facilities (the "Senior Secured Credit Facilities") in the aggregate principal amount of $17.6 billion comprising (a) term loan facilities and (b) a senior secured Revolving Credit Facility, which includes capacity for up to $0.5 billion of letters of credit and for borrowings of up to $0.4 billion under swing-line loans.  As of August 4, 2017, available borrowings under the Revolving Credit Facility totaled $3.1 billion.  The Senior Secured Credit Facilities provide that the borrowers have the right at any time, subject to customary conditions, to request incremental term loans or incremental revolving commitments.

- changed (2017-12-12):
[0001571996-17-000045:note_history:25]
The Term Loan A-2 Facility amortizes in equal quarterly installments in aggregate annual amounts equal to 5% of the original principal amount in the first year after the closing date of the refinancing transaction on October 20, 2017, 10% of the original principal amount in each of the second and third years after October 20, 2017, and 70% of the original principal amount in the fourth year after October 20, 2017.  The Term Loan B Facility amortizes in equal quarterly installments in aggregate annual amounts equal to 1% of the original principal amount.  The Term Loan A-3 Facility and the Revolving Credit Facility have no amortization. The Term Loan A-3 Facility requires the borrowers to prepay outstanding borrowings under these facilities with 100% of the net cash proceeds of certain non-ordinary course asset sales or dispositions.  The borrowers may voluntarily repay outstanding loans under the term loan facilities and the Revolving Credit Facility at any time without premium or penalty, other than customary "breakage" costs.
  (was, 2017-09-08, similarity 0.7404):
[0001571996-17-000020:note_history:25]
The Term Loan A-1 Facility, the Term Loan A-3 Facility, and the Revolving Credit Facility have no amortization.  The Term Loan A-2 Facility amortizes in equal quarterly installments in aggregate annual amounts equal to 5% of the original principal amount in each of the first two years after the closing date of the EMC merger transaction, 10% of the original principal amount in each of the third and fourth years after the closing date of the EMC merger transaction, and 70% of the original principal amount in the fifth year after the closing date of the EMC merger transaction.  The Term Loan B Facility amortizes in equal quarterly installments in aggregate annual amounts equal to 1% of the original principal amount.  The Term Loan A-1 and Term Loan A-3 Facilities require the borrowers to prepay outstanding borrowings under these facilities with 100% of the net cash proceeds of certain non-ordinary course asset sales or dispositions.  The borrowers may voluntarily repay outstanding loans under the term loan facilities and the Revolving Credit Facility at any time without premium or penalty, other than customary "breakage" costs.

- changed (2017-12-12):
[0001571996-17-000045:note_history:26]
All obligations of the borrowers under the Senior Secured Credit Facilities and certain swap agreements, cash management arrangements, and certain letters of credit provided by any lender or agent party to the Senior Secured Credit Facilities or any of its affiliates and certain other persons are secured by (a) a first-priority security interest in certain tangible and intangible assets of the borrowers and the guarantors and (b) a first-priority pledge of 100% of the capital stock of the borrowers, Dell Inc., and each wholly-owned material restricted subsidiary of the borrowers and the guarantors, in each case subject to certain thresholds, exceptions, and permitted liens.
  (was, 2017-09-08, similarity 0.9446):
[0001571996-17-000020:note_history:26]
All obligations of the borrowers under the Senior Secured Credit Facilities and certain swap agreements, cash management arrangements, and certain letters of credit provided by any lender or agent party to the Senior Secured Credit Facilities or any of its affiliates and certain other persons are secured by (a) a first-priority security interest in certain tangible and intangible assets of the borrowers and the guarantors and (b) a first-priority pledge of 100% of the capital stock of the borrowers, Dell Inc., an indirect wholly-owned subsidiary of Dell Technologies ("Dell"), and each wholly-owned material restricted subsidiary of the borrowers and the guarantors, in each case subject to certain thresholds, exceptions, and permitted liens.

- added (2017-12-12):
[0001571996-17-000045:note_history:27]
China Revolving Credit Facility — On October 31, 2017, the Company entered into a credit agreement (the "China Revolving Credit Facility") with the Bank of China (Hong Kong) Limited for a secured revolving loan facility in an aggregate principal amount not to exceed $500 million.  Borrowings under the China Revolving Credit Facility bear interest at a rate per annum of 0.6% plus LIBOR.  The Company may voluntarily repay outstanding loans under the China Revolving Credit Facility at any time without premium or penalty, other than customary "breakage" costs.  The facility will expire on October 31, 2018.  As of November 3, 2017, there were no outstanding borrowings under the China Revolving Credit Facility.

- added (2017-12-12):
[0001571996-17-000045:note_history:28]
Pivotal Revolving Credit Facility — On September 7, 2017, Pivotal entered into a credit agreement (the "Pivotal Revolving Credit Facility") with Silicon Valley Bank and certain other banks for a senior secured revolving loan facility in an aggregate principal amount not to exceed $100 million.  The credit facility contains customary representations, warranties, and covenants, including financial covenants that require compliance with minimum earnings attainment and liquidity ratios as well as covenants by Pivotal limiting additional indebtedness, liens, guaranties, mergers and consolidations, asset sales, investments and loans, sale and leasebacks, transactions with affiliates and fundamental changes. The credit agreement will expire on September 8, 2020, unless it is terminated by Pivotal or an event of default has occurred prior to such date.  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of Pivotal and Pivotal's subsidiaries.  As of November 3, 2017, there were no outstanding borrowings under the Pivotal Revolving Credit Facility.

- added (2017-12-12):
[0001571996-17-000045:note_history:29]
VMware Notes — On August 21, 2017, VMware, Inc. completed a public offering of senior notes in the aggregate amount of $4.0 billion, consisting of outstanding principal due on the following dates: $1.25 billion due August 21, 2020, $1.50 billion due August 21, 2022, and $1.25 billion due August 21, 2027 (collectively, the "VMware Notes"). The VMware Notes bear interest, payable semiannually, at annual rates of 2.30%, 2.95%, and 3.90%, respectively.  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.

- added (2017-12-12):
[0001571996-17-000045:note_history:30]
VMware Revolving Credit Facility —  On September 12, 2017, VMware, Inc. entered into an unsecured credit agreement, establishing a revolving credit facility (the “VMware Revolving Credit Facility”), with a syndicate of lenders that provides the company with a borrowing capacity of up to $1.0 billion which may be used for VMware, Inc. corporate purposes.  Commitments under the VMware Revolving Credit Facility are available for a period of five years, which may be extended, subject to the satisfaction of certain conditions, by up to two one year periods.  As of November 3, 2017, there were no outstanding borrowings under the VMware Revolving Credit Facility.  The credit agreement contains certain representations, warranties, and covenants. Commitment fees, interest rates, and other terms of borrowing under the VMware Revolving Credit Facility may vary based on VMware, Inc.’s external credit ratings.  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.

- changed (2017-12-12):
[0001571996-17-000045:note_history:31]
Margin Loan Facility — During the three months ended May 5, 2017, the Company entered into the Margin Loan Facility in an aggregate principal amount of $2.0 billion.  VMW Holdco LLC, a wholly-owned subsidiary of EMC, is the borrower under the Margin Loan Facility, which is secured by 60 million shares of Class B common stock of VMware, Inc. and 20 million shares of Class A common stock of VMware, Inc.  Loans under the Margin Loan Facility bear interest at a rate per annum payable, at the borrower's option, either at (a) a base rate plus 1.25% per annum or (b) a LIBOR-based rate plus 2.25% per annum.  Interest under the Margin Loan Facility is payable quarterly.
  (was, 2017-09-08, similarity 0.9861):
[0001571996-17-000020:note_history:31]
Margin Loan Facility — During the three months ended May 5, 2017, the Company issued the Margin Loan Facility in an aggregate principal amount of $2.0 billion.  VMW Holdco LLC, a wholly-owned subsidiary of EMC, is the borrower under the Margin Loan Facility, which is secured by 60 million shares of Class B common stock of VMware, Inc. and 20 million shares of Class A common stock of VMware, Inc.  Loans under the Margin Loan Facility bear interest at a rate per annum payable, at the borrower's option, either at (a) a base rate plus 1.25% per annum or (b) a LIBOR-based rate plus 2.25% per annum.  Interest under the Margin Loan Facility is payable quarterly.

- changed (2017-12-12):
[0001571996-17-000045:note_history:32]
VMware Note Bridge Facility — On September 7, 2016, Merger Sub and EMC entered into a credit agreement providing for a senior secured note bridge facility in an aggregate principal amount of $1.5 billion (the "VMware Note Bridge Facility").  As described above, the Company repaid the VMware Note Bridge Facility during the three months ended November 3, 2017.
  (was, 2017-09-08, similarity 0.6402):
[0001571996-17-000020:note_history:32]
VMware Note Bridge Facility — On September 7, 2016, Merger Sub and EMC entered into a credit agreement providing for a senior secured note bridge facility in an aggregate principal amount of $1.5 billion (the "VMware Note Bridge Facility").  The VMware Note Bridge Facility is secured solely by certain intercompany notes in an aggregate principal amount of $1.5 billion issued by VMware, Inc. that are payable to EMC, and the proceeds thereof.

- changed (2017-12-12):
[0001571996-17-000045:note_history:33]
Structured Financing Debt — As of November 3, 2017 and February 3, 2017, the Company had $4.3 billion and $3.5 billion, respectively, in outstanding structured financing debt, which was primarily related to the fixed-term lease and loan securitization programs and the revolving loan securitization programs.  See Note 6 and Note 8 of the Notes to the Condensed Consolidated Financial Statements for further discussion of the structured financing debt and the interest rate swap agreements that hedge a portion of that debt.
  (was, 2017-09-08, similarity 0.9862):
[0001571996-17-000020:note_history:33]
Structured Financing Debt — As of August 4, 2017 and February 3, 2017, the Company had $4.1 billion and $3.5 billion, respectively, in outstanding structured financing debt, which was primarily related to the fixed-term lease and loan securitization programs and the revolving loan securitization programs.  See Note 6 and Note 8 of the Notes to the Condensed Consolidated Financial Statements for further discussion of the structured financing debt and the interest rate swap agreements that hedge a portion of that debt.

- changed (2017-12-12):
[0001571996-17-000045:note_history:34]
Unsecured Notes and Debentures — The Company has outstanding unsecured notes and debentures (collectively, the "Unsecured Notes and Debentures") that were issued prior to the acquisition of Dell by Dell Technologies Inc.  Interest on these borrowings is payable semiannually.
  (was, 2017-09-08, similarity 0.9776):
[0001571996-17-000020:note_history:34]
Unsecured Notes and Debentures — The Company has unsecured notes and debentures (collectively, the "Unsecured Notes and Debentures") that were issued prior to the acquisition of Dell by Dell Technologies Inc.  Interest on these borrowings is payable semiannually.

- changed (2017-12-12):
[0001571996-17-000045:note_history:35]
Aggregate Future Maturities — As of November 3, 2017, aggregate future maturities of the Company's debt were as follows:
  (was, 2017-09-08, similarity 0.9386):
[0001571996-17-000020:note_history:35]
Aggregate Future Maturities — As of August 4, 2017, aggregate future maturities of the Company's debt were as follows:

- added (2017-12-12):
[0001571996-17-000045:note_history:36]
|  | Maturities by Fiscal Year |
|  | 2018 (remaining three months) |  | 2019 |  | 2020 |  | 2021 |  | 2022 |  | Thereafter |  | Total |
|  | (in millions) |
| Structured Financing Debt | $ | 909 |  |  | $ | 2,470 |  |  | $ | 649 |  |  | $ | 254 |  |  | $ | 62 |  |  | $ | 4 |  |  | $ | 4,348 |  |
| Senior Secured Credit Facilities and First Lien Notes | 81 |  |  | 1,765 |  |  | 4,245 |  |  | 371 |  |  | 7,888 |  |  | 16,538 |  |  | 30,888 |  |
| Unsecured Notes and Debentures | — |  |  | 500 |  |  | 600 |  |  | — |  |  | 400 |  |  | 953 |  |  | 2,453 |  |
| Senior Notes and EMC Notes | — |  |  | 2,500 |  |  | — |  |  | 2,000 |  |  | 1,625 |  |  | 2,625 |  |  | 8,750 |  |
| VMware Notes | — |  |  | — |  |  | — |  |  | 1,250 |  |  | — |  |  | 2,750 |  |  | 4,000 |  |
| Margin Loan Facility | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 2,000 |  |  | 2,000 |  |
| Other | 13 |  |  | 10 |  |  | 8 |  |  | 26 |  |  | — |  |  | 26 |  |  | 83 |  |
| Total maturities, principal amount | 1,003 |  |  | 7,245 |  |  | 5,502 |  |  | 3,901 |  |  | 9,975 |  |  | 24,896 |  |  | 52,522 |  |
| Associated carrying value adjustments | (1 | ) |  | (24 | ) |  | (40 | ) |  | (10 | ) |  | (206 | ) |  | (590 | ) |  | (871 | ) |
| Total maturities, carrying value amount | $ | 1,002 |  |  | $ | 7,221 |  |  | $ | 5,462 |  |  | $ | 3,891 |  |  | $ | 9,769 |  |  | $ | 24,306 |  |  | $ | 51,651 |  |

- changed (2017-12-12):
[0001571996-17-000045:note_history:37]
Covenants and Unrestricted Net Assets — The credit agreement for the Senior Secured Credit Facilities contain customary negative covenants that generally limit the ability of Denali Intermediate Inc., a wholly-owned subsidiary of Dell Technologies ("Dell Intermediate"), Dell, and Dell's and Denali Intermediate's other restricted subsidiaries to incur debt, create liens, make fundamental changes, enter into asset sales, make certain investments, pay dividends or distribute or redeem certain equity interests, prepay or redeem certain debt, and enter into certain transactions with affiliates.  The indenture governing the Senior Notes contains customary negative covenants that generally limit the ability of Denali Intermediate, Dell, and Dell's and Denali Intermediate's other restricted subsidiaries to incur additional debt or issue certain preferred shares, pay dividends on or make other distributions in respect of capital stock or make other restricted payments, make certain investments, sell or transfer certain assets, create liens on certain assets to secure debt, consolidate, merge, sell, or otherwise dispose of all or substantially all assets, enter into certain transactions with affiliates, and designate subsidiaries as unrestricted subsidiaries.  The negative covenants under such credit agreements and indenture are subject to certain exceptions, qualifications, and "baskets."  The indentures governing the First Lien Notes, the Unsecured Notes and Debentures, and the EMC Notes variously impose limitations, subject to specified exceptions, on creating certain liens, entering into sale and lease-back transactions, and entering into certain asset sales.  As of November 3, 2017, the Company had certain consolidated subsidiaries that were designated as unrestricted subsidiaries for all purposes of the applicable credit agreements and the indentures governing the First Lien Notes and the Senior Notes.  The foregoing credit agreements and indentures contain customary events of default, including failure to make required payments, failure to comply with covenants, and the occurrence of certain events of bankruptcy and insolvency.
  (was, 2017-09-08, similarity 0.9967):
[0001571996-17-000020:note_history:37]
Covenants and Unrestricted Net Assets — The credit agreement for the Senior Secured Credit Facilities contain customary negative covenants that generally limit the ability of Denali Intermediate Inc., a wholly-owned subsidiary of Dell Technologies ("Dell Intermediate"), Dell, and Dell's and Denali Intermediate's other restricted subsidiaries to incur debt, create liens, make fundamental changes, enter into asset sales, make certain investments, pay dividends or distribute or redeem certain equity interests, prepay or redeem certain debt, and enter into certain transactions with affiliates.  The indenture governing the Senior Notes contains customary negative covenants that generally limit the ability of Denali Intermediate, Dell, and Dell's and Denali Intermediate's other restricted subsidiaries to incur additional debt or issue certain preferred shares, pay dividends on or make other distributions in respect of capital stock or make other restricted payments, make certain investments, sell or transfer certain assets, create liens on certain assets to secure debt, consolidate, merge, sell, or otherwise dispose of all or substantially all assets, enter into certain transactions with affiliates, and designate subsidiaries as unrestricted subsidiaries.  The negative covenants under such credit agreements and indenture are subject to certain exceptions, qualifications, and "baskets."  The indentures governing the First Lien Notes, the Unsecured Notes and Debentures, and the EMC Notes variously impose limitations, subject to specified exceptions, on creating certain liens, entering into sale and lease-back transactions, and entering into certain asset sales.  As of August 4, 2017, the Company had certain consolidated subsidiaries that were designated as unrestricted subsidiaries for all purposes of the applicable credit agreements and the indentures governing the First Lien Notes and the Senior Notes.  The foregoing credit agreements and indentures contain customary events of default, including failure to make required payments, failure to comply with covenants, and the occurrence of certain events of bankruptcy and insolvency.

- changed (2017-12-12):
[0001571996-17-000045:note_history:38]
The Term Loan A-2 Facility, the Term Loan A-3 Facility, and the Revolving Credit Facility are subject to a first lien net leverage ratio covenant that is tested at the end of each fiscal quarter of Dell with respect to Dell's preceding four fiscal quarters.  The Company was in compliance with all financial covenants as of November 3, 2017.
  (was, 2017-09-08, similarity 0.9282):
[0001571996-17-000020:note_history:38]
The Term Loan A-1 Facility, the Term Loan A-2 Facility, the Term Loan A-3 Facility, and the Revolving Credit Facility are subject to a first lien net leverage ratio covenant that is tested at the end of each fiscal quarter of Dell with respect to Dell's preceding four fiscal quarters.  The Company was in compliance with all financial covenants as of August 4, 2017.

- removed (2017-12-12):
[0001571996-17-000020:note_history:39]
|  | August 4, 2017 |  | February 3, 2017 |
|  | (in millions) |
| Secured Debt |  |  |  |
| Structured financing debt | $ | 4,050 |  |  | $ | 3,464 |  |
| Senior Secured Credit Facilities: |  |  |  |
| 3.74% Term Loan B Facility due September 2023 | 5,460 |  |  | 4,987 |  |
| 3.24% Term Loan A-1 Facility due December 2018 | 69 |  |  | 600 |  |
| 3.49% Term Loan A-2 Facility due September 2021 | 3,778 |  |  | 3,876 |  |
| 3.24% Term Loan A-3 Facility due December 2018 | 1,800 |  |  | 1,800 |  |
| 2.78% Revolving Credit Facility due September 2021 | — |  |  | 375 |  |
| First Lien Notes: |  |  |  |
| 3.48% due June 2019 | 3,750 |  |  | 3,750 |  |
| 4.42% due June 2021 | 4,500 |  |  | 4,500 |  |
| 5.45% due June 2023 | 3,750 |  |  | 3,750 |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 8.10% due June 2036 | 1,500 |  |  | 1,500 |  |
| 8.35% due June 2046 | 2,000 |  |  | 2,000 |  |
| Unsecured Debt |  |  |  |
| Unsecured Notes and Debentures: |  |  |  |
| 5.65% due April 2018 | 500 |  |  | 500 |  |
| 5.875% due June 2019 | 600 |  |  | 600 |  |
| 4.625% due April 2021 | 400 |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 265 |  |  | 265 |  |
| Senior Notes: |  |  |  |
| 5.875% due June 2021 | 1,625 |  |  | 1,625 |  |
| 7.125% due June 2024 | 1,625 |  |  | 1,625 |  |
| EMC Notes: |  |  |  |
| 1.875% due June 2018 | 2,500 |  |  | 2,500 |  |
| 2.650% due June 2020 | 2,000 |  |  | 2,000 |  |
| 3.375% due June 2023 | 1,000 |  |  | 1,000 |  |
| Other |  |  |  |
| 3.56% Margin Loan Facility due April 2022 | 2,000 |  |  | — |  |
| 2.53% Margin Bridge Facility due September 2017 | — |  |  | 2,500 |  |
| 2.99% VMware Note Bridge Facility due September 2017 | 1,500 |  |  | 1,500 |  |
| Other | 86 |  |  | 51 |  |
| Total debt, principal amount | $ | 49,946 |  |  | $ | 50,356 |  |
| Unamortized discount, net of unamortized premium | (281 | ) |  | (284 | ) |
| Debt issuance costs | (605 | ) |  | (682 | ) |
| Total debt, carrying value | $ | 49,060 |  |  | $ | 49,390 |  |
| Total short-term debt, carrying value | $ | 7,686 |  |  | $ | 6,329 |  |
| Total long-term debt, carrying value | $ | 41,374 |  |  | $ | 43,061 |  |

- removed (2017-12-12):
[0001571996-17-000020:note_history:40]
During the three months ended May 5, 2017, the Company refinanced the Term Loan B Facility to reduce the interest rate margin by 0.75% and to increase the outstanding principal amount by $500 million.  The Company applied the proceeds from the Term Loan B Facility refinancing to repay $500 million principal amount of the Margin Bridge Facility, without premium or penalty, and accrued and unpaid interest thereon.  Additionally, during the three months ended May 5, 2017, the Company issued the Margin Loan Facility in the principal amount of $2.0 billion, and used the proceeds of the new facility to repay the Margin Bridge Facility, without premium or penalty.  Further, during the six months ended August 4, 2017, the Company repaid approximately $0.6 billion principal amount of its term loan facilities, repaid $0.4 billion, net, under the Revolving Credit Facility, and issued an additional $0.6 billion, net, in structured financing debt to support the expansion of its financing receivables portfolio.

- removed (2017-12-12):
[0001571996-17-000020:note_history:41]
Interest under the VMware Note Bridge Facility is payable, at the borrower's option, either at (a) a base rate plus 0.75% per annum or (b) a LIBOR-based rate plus 1.75% per annum.  Interest is payable, in the case of loans bearing interest based on LIBOR, at the end of each interest period (but at least every three months), in arrears and, in the case of loans bearing interest based on the base rate, quarterly in arrears.

- removed (2017-12-12):
[0001571996-17-000020:note_history:42]
The VMware Note Bridge Facility has no amortization.  The borrower is required to prepay outstanding borrowings under the VMware Note Bridge Facility with 100% of the net cash proceeds of any asset sale or other disposition of the pledged VMware, Inc. promissory notes.  The borrower may voluntarily repay outstanding loans under the VMware Note Bridge Facility at any time without premium or penalty, other than customary "breakage" costs, subject to certain minimum threshold amounts for prepayment.  For more information regarding the VMware Note Bridge Facility see Note 21 of the Notes to the Condensed Consolidated Financial Statements.

- removed (2017-12-12):
[0001571996-17-000020:note_history:43]
|  | Maturities by Fiscal Year |
|  | 2018 (remaining six months) |  | 2019 |  | 2020 |  | 2021 |  | 2022 |  | Thereafter |  | Total |
|  | (in millions) |
| Structured Financing Debt | $ | 1,653 |  |  | $ | 1,827 |  |  | $ | 422 |  |  | $ | 117 |  |  | $ | 30 |  |  | $ | 1 |  |  | $ | 4,050 |  |
| Senior Secured Credit Facilities and First Lien Notes | 125 |  |  | 2,169 |  |  | 4,198 |  |  | 336 |  |  | 7,302 |  |  | 16,977 |  |  | 31,107 |  |
| Unsecured Notes and Debentures | — |  |  | 500 |  |  | 600 |  |  | — |  |  | 400 |  |  | 953 |  |  | 2,453 |  |
| Senior Notes and EMC Notes | — |  |  | 2,500 |  |  | — |  |  | 2,000 |  |  | 1,625 |  |  | 2,625 |  |  | 8,750 |  |
| Margin Loan Facility | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 2,000 |  |  | 2,000 |  |
| Bridge Facility | 1,500 |  |  | — |  |  | — |  |  | — |  |  | — |  |  |  |  |  | 1,500 |  |
| Other | 18 |  |  | 10 |  |  | 5 |  |  | 27 |  |  | — |  |  | 26 |  |  | 86 |  |
| Total maturities, principal amount | 3,296 |  |  | 7,006 |  |  | 5,225 |  |  | 2,480 |  |  | 9,357 |  |  | 22,582 |  |  | 49,946 |  |
| Associated carrying value adjustments | (3 | ) |  | (29 | ) |  | (45 | ) |  | (1 | ) |  | (217 | ) |  | (591 | ) |  | (886 | ) |
| Total maturities, carrying value amount | $ | 3,293 |  |  | $ | 6,977 |  |  | $ | 5,180 |  |  | $ | 2,479 |  |  | $ | 9,140 |  |  | $ | 21,991 |  |  | $ | 49,060 |  |


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2017-12-12):
[0001571996-17-000045:note_history:44]
|  | November 3, 2017 |  | February 3, 2017 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Secured Credit Facilities | $ | 10.7 |  |  | $ | 10.9 |  |  | $ | 11.4 |  |  | $ | 11.7 |  |
| First Lien Notes | $ | 19.7 |  |  | $ | 22.2 |  |  | $ | 19.7 |  |  | $ | 21.8 |  |
| Unsecured Notes and Debentures | $ | 2.3 |  |  | $ | 2.5 |  |  | $ | 2.3 |  |  | $ | 2.5 |  |
| Senior Notes | $ | 3.1 |  |  | $ | 3.5 |  |  | $ | 3.1 |  |  | $ | 3.5 |  |
| EMC Notes | $ | 5.5 |  |  | $ | 5.4 |  |  | $ | 5.5 |  |  | $ | 5.4 |  |
| VMware Notes | $ | 4.0 |  |  | $ | 4.0 |  |  | $ | — |  |  | $ | — |  |
| Margin Loan Facility | $ | 2.0 |  |  | $ | 2.0 |  |  | $ | — |  |  | $ | — |  |
| Bridge Facilities | $ | — |  |  | $ | — |  |  | $ | 4.0 |  |  | $ | 4.0 |  |

- removed (2017-12-12):
[0001571996-17-000020:note_history:45]
|  | August 4, 2017 |  | February 3, 2017 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Secured Credit Facilities | $ | 10.9 |  |  | $ | 11.2 |  |  | $ | 11.4 |  |  | $ | 11.7 |  |
| First Lien Notes | $ | 19.7 |  |  | $ | 22.3 |  |  | $ | 19.7 |  |  | $ | 21.8 |  |
| Unsecured Notes and Debentures | $ | 2.3 |  |  | $ | 2.5 |  |  | $ | 2.3 |  |  | $ | 2.5 |  |
| Senior Notes | $ | 3.1 |  |  | $ | 3.5 |  |  | $ | 3.1 |  |  | $ | 3.5 |  |
| EMC Notes | $ | 5.5 |  |  | $ | 5.3 |  |  | $ | 5.5 |  |  | $ | 5.4 |  |
| Margin Loan Facility | $ | 2.0 |  |  | $ | 2.0 |  |  | $ | — |  |  | $ | — |  |
| Bridge Facilities | $ | 1.5 |  |  | $ | 1.5 |  |  | $ | 4.0 |  |  | $ | 4.0 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2017-12-12):
[0001571996-17-000045:note_history:46]
|  | November 3, 2017 |  | February 3, 2017 |
|  | (in millions) |
| Secured Debt |  |  |  |
| Structured financing debt | $ | 4,348 |  |  | $ | 3,464 |  |
| Senior Secured Credit Facilities: |  |  |  |
| 3.25% Term Loan B Facility due September 2023 | 5,000 |  |  | 4,987 |  |
| Term Loan A-1 Facility due December 2018 | — |  |  | 600 |  |
| 3.00% Term Loan A-2 Facility due September 2021 | 4,450 |  |  | 3,876 |  |
| 2.75% Term Loan A-3 Facility due December 2018 | 1,438 |  |  | 1,800 |  |
| 2.75% Revolving Credit Facility due September 2021 | — |  |  | 375 |  |
| First Lien Notes: |  |  |  |
| 3.48% due June 2019 | 3,750 |  |  | 3,750 |  |
| 4.42% due June 2021 | 4,500 |  |  | 4,500 |  |
| 5.45% due June 2023 | 3,750 |  |  | 3,750 |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 8.10% due June 2036 | 1,500 |  |  | 1,500 |  |
| 8.35% due June 2046 | 2,000 |  |  | 2,000 |  |
| Unsecured Debt |  |  |  |
| Unsecured Notes and Debentures: |  |  |  |
| 5.65% due April 2018 | 500 |  |  | 500 |  |
| 5.875% due June 2019 | 600 |  |  | 600 |  |
| 4.625% due April 2021 | 400 |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 265 |  |  | 265 |  |
| Senior Notes: |  |  |  |
| 5.875% due June 2021 | 1,625 |  |  | 1,625 |  |
| 7.125% due June 2024 | 1,625 |  |  | 1,625 |  |
| EMC Notes: |  |  |  |
| 1.875% due June 2018 | 2,500 |  |  | 2,500 |  |
| 2.650% due June 2020 | 2,000 |  |  | 2,000 |  |
| 3.375% due June 2023 | 1,000 |  |  | 1,000 |  |
| VMware Notes: |  |  |  |
| 2.30% due August 2020 | 1,250 |  |  | — |  |
| 2.95% due August 2022 | 1,500 |  |  | — |  |
| 3.90% due August 2027 | 1,250 |  |  | — |  |
| Other |  |  |  |
| 3.63% Margin Loan Facility due April 2022 | 2,000 |  |  | — |  |
| Margin Bridge Facility due September 2017 | — |  |  | 2,500 |  |
| VMware Note Bridge Facility due September 2017 | — |  |  | 1,500 |  |
| Other | 83 |  |  | 51 |  |
| Total debt, principal amount | $ | 52,522 |  |  | $ | 50,356 |  |
| Unamortized discount, net of unamortized premium | (268 | ) |  | (284 | ) |
| Debt issuance costs | (603 | ) |  | (682 | ) |
| Total debt, carrying value | $ | 51,651 |  |  | $ | 49,390 |  |
| Total short-term debt, carrying value | $ | 6,235 |  |  | $ | 6,329 |  |
| Total long-term debt, carrying value | $ | 45,416 |  |  | $ | 43,061 |  |

- removed (2017-12-12):
[0001571996-17-000020:note_history:47]
|  | August 4, 2017 |  | February 3, 2017 |
|  | (in millions) |
| Secured Debt |  |  |  |
| Structured financing debt | $ | 4,050 |  |  | $ | 3,464 |  |
| Senior Secured Credit Facilities: |  |  |  |
| 3.74% Term Loan B Facility due September 2023 | 5,460 |  |  | 4,987 |  |
| 3.24% Term Loan A-1 Facility due December 2018 | 69 |  |  | 600 |  |
| 3.49% Term Loan A-2 Facility due September 2021 | 3,778 |  |  | 3,876 |  |
| 3.24% Term Loan A-3 Facility due December 2018 | 1,800 |  |  | 1,800 |  |
| 2.78% Revolving Credit Facility due September 2021 | — |  |  | 375 |  |
| First Lien Notes: |  |  |  |
| 3.48% due June 2019 | 3,750 |  |  | 3,750 |  |
| 4.42% due June 2021 | 4,500 |  |  | 4,500 |  |
| 5.45% due June 2023 | 3,750 |  |  | 3,750 |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 8.10% due June 2036 | 1,500 |  |  | 1,500 |  |
| 8.35% due June 2046 | 2,000 |  |  | 2,000 |  |
| Unsecured Debt |  |  |  |
| Unsecured Notes and Debentures: |  |  |  |
| 5.65% due April 2018 | 500 |  |  | 500 |  |
| 5.875% due June 2019 | 600 |  |  | 600 |  |
| 4.625% due April 2021 | 400 |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 265 |  |  | 265 |  |
| Senior Notes: |  |  |  |
| 5.875% due June 2021 | 1,625 |  |  | 1,625 |  |
| 7.125% due June 2024 | 1,625 |  |  | 1,625 |  |
| EMC Notes: |  |  |  |
| 1.875% due June 2018 | 2,500 |  |  | 2,500 |  |
| 2.650% due June 2020 | 2,000 |  |  | 2,000 |  |
| 3.375% due June 2023 | 1,000 |  |  | 1,000 |  |
| Other |  |  |  |
| 3.56% Margin Loan Facility due April 2022 | 2,000 |  |  | — |  |
| 2.53% Margin Bridge Facility due September 2017 | — |  |  | 2,500 |  |
| 2.99% VMware Note Bridge Facility due September 2017 | 1,500 |  |  | 1,500 |  |
| Other | 86 |  |  | 51 |  |
| Total debt, principal amount | $ | 49,946 |  |  | $ | 50,356 |  |
| Unamortized discount, net of unamortized premium | (281 | ) |  | (284 | ) |
| Debt issuance costs | (605 | ) |  | (682 | ) |
| Total debt, carrying value | $ | 49,060 |  |  | $ | 49,390 |  |
| Total short-term debt, carrying value | $ | 7,686 |  |  | $ | 6,329 |  |
| Total long-term debt, carrying value | $ | 41,374 |  |  | $ | 43,061 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-12-12):
[0001571996-17-000045:note_history:48]
As of November 3, 2017, aggregate future maturities of the Company's debt were as follows:
  (was, 2017-09-08, similarity 0.9167):
[0001571996-17-000020:note_history:48]
As of August 4, 2017, aggregate future maturities of the Company's debt were as follows:

- added (2017-12-12):
[0001571996-17-000045:note_history:49]
|  | Maturities by Fiscal Year |
|  | 2018 (remaining three months) |  | 2019 |  | 2020 |  | 2021 |  | 2022 |  | Thereafter |  | Total |
|  | (in millions) |
| Structured Financing Debt | $ | 909 |  |  | $ | 2,470 |  |  | $ | 649 |  |  | $ | 254 |  |  | $ | 62 |  |  | $ | 4 |  |  | $ | 4,348 |  |
| Senior Secured Credit Facilities and First Lien Notes | 81 |  |  | 1,765 |  |  | 4,245 |  |  | 371 |  |  | 7,888 |  |  | 16,538 |  |  | 30,888 |  |
| Unsecured Notes and Debentures | — |  |  | 500 |  |  | 600 |  |  | — |  |  | 400 |  |  | 953 |  |  | 2,453 |  |
| Senior Notes and EMC Notes | — |  |  | 2,500 |  |  | — |  |  | 2,000 |  |  | 1,625 |  |  | 2,625 |  |  | 8,750 |  |
| VMware Notes | — |  |  | — |  |  | — |  |  | 1,250 |  |  | — |  |  | 2,750 |  |  | 4,000 |  |
| Margin Loan Facility | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 2,000 |  |  | 2,000 |  |
| Other | 13 |  |  | 10 |  |  | 8 |  |  | 26 |  |  | — |  |  | 26 |  |  | 83 |  |
| Total maturities, principal amount | 1,003 |  |  | 7,245 |  |  | 5,502 |  |  | 3,901 |  |  | 9,975 |  |  | 24,896 |  |  | 52,522 |  |
| Associated carrying value adjustments | (1 | ) |  | (24 | ) |  | (40 | ) |  | (10 | ) |  | (206 | ) |  | (590 | ) |  | (871 | ) |
| Total maturities, carrying value amount | $ | 1,002 |  |  | $ | 7,221 |  |  | $ | 5,462 |  |  | $ | 3,891 |  |  | $ | 9,769 |  |  | $ | 24,306 |  |  | $ | 51,651 |  |

- removed (2017-12-12):
[0001571996-17-000020:note_history:50]
|  | Maturities by Fiscal Year |
|  | 2018 (remaining six months) |  | 2019 |  | 2020 |  | 2021 |  | 2022 |  | Thereafter |  | Total |
|  | (in millions) |
| Structured Financing Debt | $ | 1,653 |  |  | $ | 1,827 |  |  | $ | 422 |  |  | $ | 117 |  |  | $ | 30 |  |  | $ | 1 |  |  | $ | 4,050 |  |
| Senior Secured Credit Facilities and First Lien Notes | 125 |  |  | 2,169 |  |  | 4,198 |  |  | 336 |  |  | 7,302 |  |  | 16,977 |  |  | 31,107 |  |
| Unsecured Notes and Debentures | — |  |  | 500 |  |  | 600 |  |  | — |  |  | 400 |  |  | 953 |  |  | 2,453 |  |
| Senior Notes and EMC Notes | — |  |  | 2,500 |  |  | — |  |  | 2,000 |  |  | 1,625 |  |  | 2,625 |  |  | 8,750 |  |
| Margin Loan Facility | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 2,000 |  |  | 2,000 |  |
| Bridge Facility | 1,500 |  |  | — |  |  | — |  |  | — |  |  | — |  |  |  |  |  | 1,500 |  |
| Other | 18 |  |  | 10 |  |  | 5 |  |  | 27 |  |  | — |  |  | 26 |  |  | 86 |  |
| Total maturities, principal amount | 3,296 |  |  | 7,006 |  |  | 5,225 |  |  | 2,480 |  |  | 9,357 |  |  | 22,582 |  |  | 49,946 |  |
| Associated carrying value adjustments | (3 | ) |  | (29 | ) |  | (45 | ) |  | (1 | ) |  | (217 | ) |  | (591 | ) |  | (886 | ) |
| Total maturities, carrying value amount | $ | 3,293 |  |  | $ | 6,977 |  |  | $ | 5,180 |  |  | $ | 2,479 |  |  | $ | 9,140 |  |  | $ | 21,991 |  |  | $ | 49,060 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2017-12-12):
[0001571996-17-000045:note_history:51]
On November 27, 2017, DFS entered into a credit agreement that provided for borrowings in an aggregate principal amount of $200 million.  The borrowings will accrue interest at a rate per annum of either 3.67%, if denominated in U.S. dollars, or 9.43%, if denominated in Mexican pesos.  The note will mature on December 1, 2020.

- added (2017-12-12):
[0001571996-17-000045:note_history:52]
During November 2017, VMware, Inc. entered into a definitive agreement to acquire VeloCloud Networks, Inc. (“VeloCloud”), a provider of cloud-delivered software-defined wide-area network (SD-WAN) technology for enterprises and service providers.  The acquisition of VeloCloud will enable VMware to build on its network virtualization platform, VMware NSX, and expand its networking portfolio.  The cash payment upon closing of the transaction is estimated to be approximately $470 million; however, the determination of the purchase price is dependent upon several factors at the date of closing and cannot be reasonably estimated until such time.  The transaction is expected to close during the fourth quarter of Fiscal 2018 and is subject to regulatory approvals and customary closing conditions.

- removed (2017-12-12):
[0001571996-17-000020:note_history:53]
Amendment of Class V Common Stock Repurchase Program — On August 18, 2017, the Company's board of directors approved a second amendment of the Class V Group Repurchase Program (as so amended, the “August 2017 Class V Group Repurchase Program”) further extending the program to authorize the Company to use assets of the Company’s Class V Group to repurchase up to an additional $300 million of shares of the Company’s Class V Common Stock.  The repurchase of shares pursuant to the August 2017 Class V Group Repurchase Program is expected to be funded from proceeds received by the VMware, Inc. Class A Common Stock Repurchase program described below.

- removed (2017-12-12):
[0001571996-17-000020:note_history:54]
VMware, Inc. Class A Common Stock Repurchase — In August 2017, VMware, Inc.'s board of directors authorized the repurchase of up to an additional $1 billion of VMware, Inc. Class A common stock through August 31, 2018.  The authorization is in addition to VMware, Inc.’s ongoing $1.2 billion stock repurchase program, originally announced in January 2017, of which $0.9 billion remains available.  On August 23, 2017, the Company and VMware, Inc. entered into a purchase commitment supplement to the March 2017 Stock Purchase Agreement (as amended, the “August 2017 Stock Purchase Agreement”).  Under the August 2017 Stock Purchase Agreement, VMware, Inc. will purchase for cash $300 million of VMware, Inc. Class A common stock from EMC Equity Assets LLC, an indirect wholly-owned subsidiary of the Company.  The Company will apply the proceeds from the sale to the repurchase of shares of its Class V Common Stock under the August 2017 Class V Group Repurchase Program described above, but may use such proceeds for other purposes at the discretion of the Capital Stock Committee of the board of directors and the board of directors.  The total number of shares to be purchased by VMware, Inc. under the August 2017 Stock Purchase Agreement will be based on the volume-weighted average per share price of the VMware, Inc. Class A common stock as reported on the New York Stock Exchange during a specified reference period, less a discount of 3.5% from that volume-weighted average per share price, and subject to adjustment in certain circumstances.

- removed (2017-12-12):
[0001571996-17-000020:note_history:55]
VMware, Inc. Public Debt Offering — On August 21, 2017, VMware, Inc. completed a public debt offering in the aggregate amount of $4.0 billion, consisting of outstanding principal due on the following dates: $1.25 billion due August 21, 2020, $1.5 billion due August 21, 2022, and $1.25 billion due August 21, 2027. The notes bear interest, payable semi-annually, at annual rates of 2.30%, 2.95%, and 3.90%, respectively.  Upon closing, a portion of the net proceeds from the offering was used to repay certain intercompany promissory notes previously issued to EMC in the aggregate principal amount of $1.2 billion.

- removed (2017-12-12):
[0001571996-17-000020:note_history:56]
VMware Note Bridge Facility Repayment — Subsequent to August 4, 2017, the Company repaid the $1.5 billion VMware Note Bridge Facility in full with proceeds of $1.2 billion from the foregoing VMware public debt offering and other cash.
