# DELL 8-K — 0001193125-18-074168 filed 2018-03-08

## item codes, every 8-K on or before 2018-03-29

- 2018-03-08 0001193125-18-074168 — 2.02, 9.01
- 2018-02-02 0001193125-18-029947 — 7.01, 9.01
- 2017-12-07 0001571996-17-000042 — 2.02, 9.01
- 2017-10-24 0001571996-17-000037 — 1.01, 2.03, 9.01
- 2017-09-15 0001571996-17-000027 — 5.02
- 2017-09-07 0001571996-17-000017 — 2.02, 9.01
- 2017-08-24 0001571996-17-000014 — 8.01
- 2017-06-29 0001571996-17-000011 — 3.03, 5.07, 8.01, 9.01
- 2017-06-08 0001193125-17-197638 — 2.02, 9.01
- 2017-03-30 0001193125-17-102794 — 8.01
- 2017-03-30 0001193125-17-102777 — 2.02, 9.01
- 2017-03-09 0001193125-17-076981 — 1.01, 2.03, 9.01
- 2017-01-17 0001193125-17-011125 — 8.01
- 2016-12-15 0001193125-16-793722 — 8.01
- 2016-12-08 0001193125-16-787976 — 2.02, 9.01
- 2016-11-10 0001193125-16-765964 — 1.02, 8.01
- 2016-11-04 0001193125-16-760249 — 8.01
- 2016-09-13 0001193125-16-708600 — 3.02
- 2016-09-09 0001193125-16-706567 — 1.01, 1.02, 2.01, 2.03, 3.02, 3.03, 5.02, 9.01
- 2016-09-07 0001193125-16-703370 — 3.03, 5.07, 7.01, 8.01, 9.01
- 2016-09-06 0001193125-16-702057 — 2.02, 9.01
- 2016-08-31 0001193125-16-697268 — 8.01, 9.01
- 2016-08-26 0001193125-16-692921 — 8.01, 9.01
- 2016-07-11 0001193125-16-645610 — 8.01
- 2016-07-05 0001193125-16-641679 — 8.01
- 2016-06-22 0001193125-16-629055 — 1.01, 2.03, 8.01, 9.01
- 2016-06-21 0001193125-16-627071 — 8.01, 9.01
- 2016-06-10 0001193125-16-618483 — 2.02, 9.01
- 2016-06-09 0001193125-16-617893 — 8.01, 9.01

## late-filing notifications on or before 2018-03-29

- none on or before 2018-03-29

## item 2.02 — earnings release, exhibit 99.1

[0001193125-18-074168:8k_2_02:1]
EX-99.1
2
d741027dex991.htm
EX-99.1

[0001193125-18-074168:8k_2_02:2]
EX-99.1

[0001193125-18-074168:8k_2_02:3]
Exhibit 99.1

[0001193125-18-074168:8k_2_02:4]
Dell Technologies Reports Fiscal Year 2018 Fourth Quarter

[0001193125-18-074168:8k_2_02:5]
and Full Year Financial Results

[0001193125-18-074168:8k_2_02:6]
ROUND
ROCK, Texas – March 8, 2018

[0001193125-18-074168:8k_2_02:7]
News summary

[0001193125-18-074168:8k_2_02:8]
|  | • |  | Strong velocity with record revenue of $21.9 billion for the fourth quarter, up 9 percent |

[0001193125-18-074168:8k_2_02:9]
|  | • |  | $6.8 billion cash flow from operations for the full year and paid $10 billion of debt since EMC transaction close |

[0001193125-18-074168:8k_2_02:10]
|  | • |  | Exited the fiscal year with growth across all segments; strong customer acceptance across the Dell Technologies portfolio |

[0001193125-18-074168:8k_2_02:11]
|  | • |  | Leader in 21 of the top market share categories |

[0001193125-18-074168:8k_2_02:12]
Full story

[0001193125-18-074168:8k_2_02:13]
Dell Technologies (NYSE: DVMT) announces its fiscal 2018 fourth quarter and full year results. For the fourth quarter, consolidated revenue was
$21.9 billion, up 9 percent, and non-GAAP revenue was $22.2 billion, up 8 percent from the prior period. During the quarter, the company generated a GAAP operating loss of $321 million1, with a non-GAAP operating income of $2.1 billion, up 15 percent.

[0001193125-18-074168:8k_2_02:14]
For the full year, consolidated revenue was $78.7 billion and non-GAAP revenue was $79.9 billion. The
company generated an annual GAAP operating loss of $3.3 billion, with a non-GAAP operating income of $6.9 billion.

[0001193125-18-074168:8k_2_02:15]
“I was pleased with our results in fiscal 2018. We finished the year with good revenue and profitability momentum, with
non-GAAP operating income up 15 percent year-over-year,” said Tom Sweet, chief financial officer, Dell Technologies. “We drove velocity at or above market rate in multiple areas of the business
and generated strong operating cash flow as we brought the full capabilities of Dell Technologies together. In fiscal 2019 we’ll continue to execute our long-term strategy, capitalizing on our broad portfolio of solutions for customers at every
stage of the digital transformation journey.”

[0001193125-18-074168:8k_2_02:16]
The company ended the year with a cash and investments balance of $20.3 billion, an increase of
$2.3 billion from the third quarter and an increase of $5.0 billion from last year. Since closing the EMC transaction, Dell Technologies has paid down approximately $10 billion in gross debt, excluding Dell Financial Services debt.

[0001193125-18-074168:8k_2_02:17]
Fiscal year 2018 fourth quarter and full year results

[0001193125-18-074168:8k_2_02:18]
|  |  | Three Months Ended |  |  |  |  |  | Fiscal Year Ended |  |  |  |  |
|  |  | February 2,2018 |  |  | February 3,2017 |  |  | Change |  |  | February 2,2018 |  |  | February 3,2017 |  |  | Change |  |
|  |  | (in millions, except percentages; unaudited) |  |
| Net revenue |  | $ | 21,935 |  |  | $ | 20,074 |  |  |  | 9 | % |  | $ | 78,660 |  |  | $ | 61,642 |  |  |  | 28 | % |
| Operating loss |  | $ | (321 | ) |  | $ | (1,668 | ) |  |  | 81 | % |  | $ | (3,333 | ) |  | $ | (3,252 | ) |  |  | (2) | % |
| Net loss from continuing operations |  | $ | (553 | ) |  | $ | (1,414 | ) |  |  | 61 | % |  | $ | (3,855 | ) |  | $ | (3,737 | ) |  |  | (3) | % |
| Non-GAAP net revenue |  | $ | 22,219 |  |  | $ | 20,581 |  |  |  | 8 | % |  | $ | 79,929 |  |  | $ | 62,822 |  |  |  | 27 | % |
| Non-GAAP operating income |  | $ | 2,120 |  |  | $ | 1,843 |  |  |  | 15 | % |  | $ | 6,855 |  |  | $ | 5,113 |  |  |  | 34 | % |
| Non-GAAP net income from continuing operations |  | $ | 1,097 |  |  | $ | 1,091 |  |  |  | 1 | % |  | $ | 3,660 |  |  | $ | 2,687 |  |  |  | 36 | % |
| Adjusted EBITDA |  | $ | 2,466 |  |  | $ | 2,184 |  |  |  | 13 | % |  | $ | 8,217 |  |  | $ | 5,941 |  |  |  | 38 | % |

[0001193125-18-074168:8k_2_02:19]
Dell Technologies’ fiscal year 2017 included an additional week, which is incorporated into the company’s fourth
quarter results for FY2017. Fourth quarter fiscal 2018 non-GAAP operating income excludes approximately $2.4 billion of adjustments, and full year fiscal 2018
non-GAAP operating income excludes approximately $10.2 billion of adjustments, primarily related to purchase accounting and amortization of intangible assets.

[0001193125-18-074168:8k_2_02:20]
Information about Dell Technologies’ use of non-GAAP financial information is provided under “Non-GAAP
Financial Measures” below. All comparisons in this press release are year-over-year unless otherwise noted.

[0001193125-18-074168:8k_2_02:21]
“We exited the year with growth
across all of our segments, with particular strength in commercial client and in servers and networking. In addition, we saw demand growth up double digits for all-flash and triple digits for hyper-converged
infrastructure in the fourth quarter, and we see a significant opportunity to ignite momentum in traditional storage in fiscal 2019,” said Jeff Clarke, vice-chairman, Products & Operations, Dell Technologies. “With our industry
leadership, innovation and laser-like focus on making our solutions easy to buy and own, we’ll continue in fiscal year 2019 to deliver on the commitments we make to customers.”

[0001193125-18-074168:8k_2_02:22]
Operating segments summary

[0001193125-18-074168:8k_2_02:23]
Client
Solutions Group revenue for the fiscal fourth quarter was $10.6 billion, up 8 percent versus the fourth quarter of last year. Commercial revenue grew 9 percent to $7.3 billion and Consumer revenue was up 6 percent to
$3.3 billion. Revenue for the full year was $39.5 billion. Operating income for the fourth quarter was $581 million, a 70 percent increase, and was $2.2 billion for the full year.

[0001193125-18-074168:8k_2_02:24]
Key fourth quarter highlights include:

[0001193125-18-074168:8k_2_02:25]
|  | • |  | Year-over-year worldwide PC share growth for 20th consecutive quarter2 |

[0001193125-18-074168:8k_2_02:26]
|  | • |  | No. 1 share position worldwide for displays, gaining unit share year-over-year for the 18th consecutive quarter3 |

[0001193125-18-074168:8k_2_02:27]
|  | • |  | Record holiday season sales for consumer and gaming products |

[0001193125-18-074168:8k_2_02:28]
|  | • |  | Record-high 87 product awards at the Consumer Electronics Show |

[0001193125-18-074168:8k_2_02:29]
Infrastructure Solutions
Group revenue for the fourth quarter was $8.8 billion, a 5 percent increase. This was driven by $4.6 billion in servers and networking, a 27 percent increase, and $4.2 billion in storage. Revenue for the full year was
$30.7 billion, with servers and networking revenue at $15.4 billion and storage revenue at $15.3 billion. Operating income was $748 million for the fourth quarter and $2.2 billion for the full year.

[0001193125-18-074168:8k_2_02:30]
Key fourth quarter highlights:

[0001193125-18-074168:8k_2_02:31]
|  | • |  | Third consecutive quarter of record server revenue, fueled by double-digit growth for both PowerEdge and Cloud servers |

[0001193125-18-074168:8k_2_02:32]
|  | • |  | Worldwide leader for x86 servers in calendar fourth quarter, both in units and revenue4 |

[0001193125-18-074168:8k_2_02:33]
|  | • |  | No. 1 market share position in all-flash arrays4 |

[0001193125-18-074168:8k_2_02:34]
|  | • |  | Demand for all-flash offerings exited fiscal 2018 at a nearly $5 billion run rate |

[0001193125-18-074168:8k_2_02:35]
VMware revenue for the fourth quarter was $2.3 billion, up 20 percent, with operating income of $834 million, up
48 percent, and 35.8 percent of revenue.

[0001193125-18-074168:8k_2_02:36]
Fourth quarter revenue from other businesses, including Pivotal, RSA,
Secureworks and Virtustream, was $492 million, up 3 percent.

[0001193125-18-074168:8k_2_02:37]
Conference call information

[0001193125-18-074168:8k_2_02:38]
As previously announced, the company will hold a conference call to discuss its fourth quarter and full-year performance today at 7 a.m. CDT. The
conference call will be broadcast live over the internet and can be accessed at investors.delltechnologies.com. For those unable to listen to the live broadcast, an archived version will be available at the same location for one year.

[0001193125-18-074168:8k_2_02:39]
A slide presentation containing additional financial and operating information may be downloaded from Dell Technologies’ website at
investors.delltechnologies.com.

[0001193125-18-074168:8k_2_02:40]
Dell Technologies World

[0001193125-18-074168:8k_2_02:41]
Join us April 30 - May 3 in Las Vegas at Dell Technologies World, the company’s flagship event that brings together latest emerging trends, technology and
gurus, from the edge to the core to the cloud. During the event, experts from all seven Dell Technologies businesses will demonstrate to customers and partners the connected ecosystem of IT infrastructure, applications, devices and security that can
enable real transformation across their organizations. Learn more at www.delltechnologiesworld.com.

[0001193125-18-074168:8k_2_02:42]
About Dell Technologies

[0001193125-18-074168:8k_2_02:43]
Dell Technologies is a unique family of businesses that provides the essential infrastructure for organizations to build their digital future, transform IT and
protect their most important asset, information. The company services customers of all sizes across 180 countries – ranging from 99 percent of the Fortune 500 to individual consumers – with the industry’s most comprehensive
and innovative portfolio from the edge to the core to the cloud.

[0001193125-18-074168:8k_2_02:44]
MEDIA CONTACTS:

[0001193125-18-074168:8k_2_02:45]
Dave Farmer

[0001193125-18-074168:8k_2_02:46]
(508)
293-7206

[0001193125-18-074168:8k_2_02:47]
dave.farmer@dell.com

[0001193125-18-074168:8k_2_02:48]
Lauren Lee

[0001193125-18-074168:8k_2_02:49]
(512)
728-4374

[0001193125-18-074168:8k_2_02:50]
lauren.lee@dell.com

[0001193125-18-074168:8k_2_02:51]
INVESTOR RELATIONS CONTACTS:

[0001193125-18-074168:8k_2_02:52]
Karen Litzler-Hollier

[0001193125-18-074168:8k_2_02:53]
(512) 728-0388

[0001193125-18-074168:8k_2_02:54]
karen.litzler-hollie@dell.com

[0001193125-18-074168:8k_2_02:55]
Hall Butler

[0001193125-18-074168:8k_2_02:56]
(512)
723-4963

[0001193125-18-074168:8k_2_02:57]
hall.butler@dell.com

[0001193125-18-074168:8k_2_02:58]
# # #

[0001193125-18-074168:8k_2_02:59]
Copyright © 2018 Dell Inc. or its subsidiaries. All Rights Reserved. Dell Technologies, Dell, EMC and Dell EMC are trademarks of Dell Inc. or its subsidiaries. Other trademarks may be trademarks of their
respective owners.

[0001193125-18-074168:8k_2_02:60]
1 Due to the EMC transaction as well as the Dell going-private transaction,
significant non-cash bridging items will remain between GAAP and non-GAAP results for the next few years. Prior-year historical Dell Technologies financials do not
include EMC historical results for the first and second quarters and a portion of the third quarter in fiscal 2017, thereby impacting any year-over-year comparisons for the full year. EMC results are included for the full fourth quarter of Fiscal
2017, thereby year-over-year results are comparable for the fourth quarter.

[0001193125-18-074168:8k_2_02:61]
2 IDC WW Quarterly Personal Computing Device (PCD) Tracker CY17Q4

[0001193125-18-074168:8k_2_02:62]
3 DisplaySearch Desktop Monitor Market Tracker CY17Q3

[0001193125-18-074168:8k_2_02:63]
4 IDC WW
Quarterly Server Tracker CY17Q4

[0001193125-18-074168:8k_2_02:64]
Non-GAAP Financial Measures:

[0001193125-18-074168:8k_2_02:65]
This press release presents information about Dell Technologies’ non-GAAP net revenue, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net
income from continuing operations, EBITDA and adjusted EBITDA, which are non-GAAP financial measures provided as a supplement to the results provided in accordance with generally accepted accounting principles
in the United States of America (“GAAP”). A reconciliation of each of the foregoing historical non-GAAP financial measures to the most directly comparable historical GAAP financial measures is
provided in the attached tables for each of the fiscal periods indicated.

[0001193125-18-074168:8k_2_02:66]
Special Note on Forward-Looking Statements:

[0001193125-18-074168:8k_2_02:67]
Dell Technologies’ results or events in future periods could differ materially from those expressed or implied by these forward-looking statements
because of risks, uncertainties, and other factors that include, but are not limited to, the following: competitive pressures; Dell Technologies’ reliance on third-party suppliers for products and components including reliance on single-source
or limited-source suppliers; Dell Technologies’ ability to achieve favorable pricing from its vendors; adverse global economic conditions and instability in financial markets; Dell Technologies’ execution of its growth, business and
acquisition strategies; the success of Dell Technologies’ cost efficiency measures; Dell Technologies’ ability to manage solutions and products and services transitions in an effective manner; Dell Technologies’ ability to deliver
high-quality products and services; Dell Technologies’ foreign operations and ability to generate substantial non-U.S. net revenue; Dell Technologies’ product, customer, and geographic sales mix, and
seasonal sales trends; the performance of Dell Technologies’ sales channel partners; access to the capital markets by Dell Technologies or its customers; weak economic conditions and additional regulation; counterparty default risks; the loss
by Dell Technologies of any services contracts with its customers, including government contracts, and

[0001193125-18-074168:8k_2_02:68]
its ability to perform such contracts at its estimated costs; Dell Technologies’ ability to develop and protect its proprietary intellectual property or obtain licenses to intellectual
property developed by others on commercially reasonable and competitive terms; infrastructure disruptions, cyberattacks, or other data security breaches; Dell Technologies’ ability to hedge effectively its exposure to fluctuations in foreign
currency exchange rates and interest rates; expiration of tax holidays or favorable tax rate structures, or unfavorable outcomes in tax audits and other tax compliance matters; impairment of portfolio investments; unfavorable results of legal
proceedings; increased costs and additional regulations and requirements as a result of Dell Technologies’ operation as a public company; Dell Technologies’ ability to develop and maintain effective internal control over financial
reporting; compliance requirements of changing environmental and safety laws; the effect of armed hostilities, terrorism, natural disasters, and public health issues; the impact of the financial performance of VMware; and the market volatility of
Dell Technologies’ pension plan assets.

[0001193125-18-074168:8k_2_02:69]
This list of risks, uncertainties, and other factors is not complete. Dell Technologies discusses
some of these matters more fully, as well as certain risk factors that could affect the Dell Technologies’ business, financial condition, results of operations, and prospects, in its reports filed with the Securities and Exchange Commission,
including Dell Technologies’ Annual Report on Form 10-K for the fiscal year ended February 3, 2017, quarterly reports on Form 10-Q, and current reports on Form
8-K. These filings are available for review through the Securities and Exchange Commission’s website at www.sec.gov. Any or all forward-looking statements Dell Technologies makes may turn out to be wrong
and can be affected by inaccurate assumptions Dell Technologies might make or by known or unknown risks, uncertainties and other factors, including those identified in this press release. Accordingly, you should not place undue reliance on the
forward-looking statements made in this press release, which speak only as of its date. Dell Technologies does not undertake to update, and expressly disclaims any duty to update, its forward-looking statements, whether as a result of circumstances
or events that arise after the date they are made, new information, or otherwise.

[0001193125-18-074168:8k_2_02:70]
DELL TECHNOLOGIES INC.

[0001193125-18-074168:8k_2_02:71]
Condensed Consolidated Statements of Income (Loss) and Related Financial Highlights

[0001193125-18-074168:8k_2_02:72]
(in millions, except per share amounts and percentages; unaudited)

[0001193125-18-074168:8k_2_02:73]
|  |  | Three Months Ended |  |  | Fiscal Year Ended |  |
|  |  | February 2,2018 |  |  | February 3,2017 |  |  | Change |  |  | February 2,2018 |  |  | February 3,2017 |  |  | Change |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  | $ | 16,798 |  |  | $ | 15,196 |  |  |  | 11 | % |  | $ | 58,801 |  |  | $ | 48,706 |  |  |  | 21 | % |
| Services |  |  | 5,137 |  |  |  | 4,878 |  |  |  | 5 | % |  |  | 19,859 |  |  |  | 12,936 |  |  |  | 54 | % |
| Total net revenue |  |  | 21,935 |  |  |  | 20,074 |  |  |  | 9 | % |  |  | 78,660 |  |  |  | 61,642 |  |  |  | 28 | % |
| Cost of net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  |  | 14,009 |  |  |  | 13,313 |  |  |  | 5 | % |  |  | 50,215 |  |  |  | 42,169 |  |  |  | 19 | % |
| Services |  |  | 2,146 |  |  |  | 2,230 |  |  |  | (4 | )% |  |  | 8,391 |  |  |  | 6,514 |  |  |  | 29 | % |
| Total cost of net revenue |  |  | 16,155 |  |  |  | 15,543 |  |  |  | 4 | % |  |  | 58,606 |  |  |  | 48,683 |  |  |  | 20 | % |
| Gross margin |  |  | 5,780 |  |  |  | 4,531 |  |  |  | 28 | % |  |  | 20,054 |  |  |  | 12,959 |  |  |  | 55 | % |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative |  |  | 5,014 |  |  |  | 4,928 |  |  |  | 2 | % |  |  | 19,003 |  |  |  | 13,575 |  |  |  | 40 | % |
| Research and development |  |  | 1,087 |  |  |  | 1,271 |  |  |  | (14 | )% |  |  | 4,384 |  |  |  | 2,636 |  |  |  | 66 | % |
| Total operating expenses |  |  | 6,101 |  |  |  | 6,199 |  |  |  | (2 | )% |  |  | 23,387 |  |  |  | 16,211 |  |  |  | 44 | % |
| Operating loss |  |  | (321 | ) |  |  | (1,668 | ) |  |  | 81 | % |  |  | (3,333 | ) |  |  | (3,252 | ) |  |  | (2 | )% |
| Interest and other, net |  |  | (555 | ) |  |  | (742 | ) |  |  | 25 | % |  |  | (2,355 | ) |  |  | (2,104 | ) |  |  | (12 | )% |
| Loss from continuing operations before income taxes |  |  | (876 | ) |  |  | (2,410 | ) |  |  | 64 | % |  |  | (5,688 | ) |  |  | (5,356 | ) |  |  | (6 | )% |
| Income tax benefit |  |  | (323 | ) |  |  | (996 | ) |  |  | 68 | % |  |  | (1,833 | ) |  |  | (1,619 | ) |  |  | (13 | )% |
| Net loss from continuing operations |  |  | (553 | ) |  |  | (1,414 | ) |  |  | 61 | % |  |  | (3,855 | ) |  |  | (3,737 | ) |  |  | (3 | )% |
| Income from discontinued operations, net of income taxes |  |  | — |  |  |  | 1,144 |  |  |  | (100 | )% |  |  | — |  |  |  | 2,019 |  |  |  | (100 | )% |
| Net loss |  |  | (553 | ) |  |  | (270 | ) |  |  | (105 | )% |  |  | (3,855 | ) |  |  | (1,718 | ) |  |  | (124 | )% |
| Less: Net loss attributable to non-controlling interests |  |  | (42 | ) |  |  | (34 | ) |  |  | (24 | )% |  |  | (127 | ) |  |  | (46 | ) |  |  | (176 | )% |
| Net loss attributable to Dell Technologies Inc. |  | $ | (511 | ) |  | $ | (236 | ) |  |  | (117 | )% |  | $ | (3,728 | ) |  | $ | (1,672 | ) |  |  | (123 | )% |
| Earnings (loss) per share attributable to Dell Technologies Inc. – basic: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Continuing operations – Class V Common Stock – basic |  | $ | (1.12 | ) |  | $ | 0.64 |  |  |  |  |  |  | $ | 1.41 |  |  | $ | 1.44 |  |  |  |  |  |
| Continuing operations – DHI Group – basic |  | $ | (0.51 | ) |  | $ | (2.68 | ) |  |  |  |  |  | $ | (7.08 | ) |  | $ | (8.52 | ) |  |  |  |  |
| Discontinued operations – DHI Group – basic |  | $ | — |  |  | $ | 2.02 |  |  |  |  |  |  | $ | — |  |  | $ | 4.30 |  |  |  |  |  |
| Earnings (loss) per share attributable to Dell Technologies Inc. – diluted: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Continuing operations – Class V Common Stock – diluted |  | $ | (1.12 | ) |  | $ | 0.64 |  |  |  |  |  |  | $ | 1.39 |  |  | $ | 1.43 |  |  |  |  |  |
| Continuing operations – DHI Group – diluted |  | $ | (0.51 | ) |  | $ | (2.68 | ) |  |  |  |  |  | $ | (7.08 | ) |  | $ | (8.52 | ) |  |  |  |  |
| Discontinued operations – DHI Group – diluted |  | $ | — |  |  | $ | 2.02 |  |  |  |  |  |  | $ | — |  |  | $ | 4.30 |  |  |  |  |  |
| Weighted-average shares outstanding: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic – Class V Common Stock |  |  | 199 |  |  |  | 215 |  |  |  |  |  |  |  | 203 |  |  |  | 217 |  |  |  |  |  |
| Diluted – Class V Common Stock |  |  | 199 |  |  |  | 215 |  |  |  |  |  |  |  | 203 |  |  |  | 217 |  |  |  |  |  |
| Basic – DHI Group |  |  | 568 |  |  |  | 566 |  |  |  |  |  |  |  | 567 |  |  |  | 470 |  |  |  |  |  |
| Diluted – DHI Group |  |  | 568 |  |  |  | 566 |  |  |  |  |  |  |  | 567 |  |  |  | 470 |  |  |  |  |  |
| Percentage of Total Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Gross margin |  |  | 26 | % |  |  | 23 | % |  |  |  |  |  |  | 25 | % |  |  | 21 | % |  |  |  |  |
| Selling, general, and administrative |  |  | 23 | % |  |  | 25 | % |  |  |  |  |  |  | 24 | % |  |  | 22 | % |  |  |  |  |
| Research and development |  |  | 5 | % |  |  | 6 | % |  |  |  |  |  |  | 6 | % |  |  | 4 | % |  |  |  |  |
| Operating expenses |  |  | 28 | % |  |  | 31 | % |  |  |  |  |  |  | 30 | % |  |  | 26 | % |  |  |  |  |
| Operating loss |  |  | (1 | )% |  |  | (8 | )% |  |  |  |  |  |  | (4 | )% |  |  | (5 | )% |  |  |  |  |
| Loss from continuing operations before income taxes |  |  | (4 | )% |  |  | (12 | )% |  |  |  |  |  |  | (7 | )% |  |  | (9 | )% |  |  |  |  |
| Net loss from continuing operations |  |  | (3 | )% |  |  | (7 | )% |  |  |  |  |  |  | (5 | )% |  |  | (6 | )% |  |  |  |  |
| Income tax rate |  |  | 37 | % |  |  | 41 | % |  |  |  |  |  |  | 32 | % |  |  | 30 | % |  |  |  |  |

[0001193125-18-074168:8k_2_02:74]
1

[0001193125-18-074168:8k_2_02:75]
DELL TECHNOLOGIES INC.

[0001193125-18-074168:8k_2_02:76]
Consolidated Statements of Financial Position

[0001193125-18-074168:8k_2_02:77]
(in millions; unaudited)

[0001193125-18-074168:8k_2_02:78]
|  |  | February 2,2018 |  |  | February 3,2017 |  |
| ASSETS |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 13,942 |  |  | $ | 9,474 |  |
| Short-term investments |  |  | 2,187 |  |  |  | 1,975 |  |
| Accounts receivable, net |  |  | 11,177 |  |  |  | 9,420 |  |
| Short-term financing receivables, net |  |  | 3,919 |  |  |  | 3,222 |  |
| Inventories, net |  |  | 2,678 |  |  |  | 2,538 |  |
| Other current assets |  |  | 5,054 |  |  |  | 4,144 |  |
| Total current assets |  |  | 38,957 |  |  |  | 30,773 |  |
| Property, plant, and equipment, net |  |  | 5,390 |  |  |  | 5,653 |  |
| Long-term investments |  |  | 4,163 |  |  |  | 3,802 |  |
| Long-term financing receivables, net |  |  | 3,724 |  |  |  | 2,651 |  |
| Goodwill |  |  | 39,920 |  |  |  | 38,910 |  |
| Intangible assets, net |  |  | 28,265 |  |  |  | 35,053 |  |
| Other non-current assets |  |  | 1,862 |  |  |  | 1,364 |  |
| Total assets |  | $ | 122,281 |  |  | $ | 118,206 |  |
| LIABILITIES, REDEEMABLE SHARES, AND STOCKHOLDERS’ EQUITY |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term debt |  | $ | 7,873 |  |  | $ | 6,329 |  |
| Accounts payable |  |  | 18,334 |  |  |  | 14,422 |  |
| Accrued and other |  |  | 7,661 |  |  |  | 7,119 |  |
| Short-term deferred revenue |  |  | 12,024 |  |  |  | 10,265 |  |
| Total current liabilities |  |  | 45,892 |  |  |  | 38,135 |  |
| Long-term debt |  |  | 43,998 |  |  |  | 43,061 |  |
| Long-term deferred revenue |  |  | 10,223 |  |  |  | 8,431 |  |
| Other non-current liabilities |  |  | 6,797 |  |  |  | 9,339 |  |
| Total liabilities |  |  | 106,910 |  |  |  | 98,966 |  |
| Redeemable shares |  |  | 384 |  |  |  | 231 |  |
| Stockholders’ equity: |  |  |  |  |  |  |  |  |
| Total Dell Technologies Inc. stockholders’ equity |  |  | 9,326 |  |  |  | 13,243 |  |
| Non-controlling interests |  |  | 5,661 |  |  |  | 5,766 |  |
| Total stockholders’ equity |  |  | 14,987 |  |  |  | 19,009 |  |
| Total liabilities, redeemable shares, and stockholders’ equity |  | $ | 122,281 |  |  | $ | 118,206 |  |

[0001193125-18-074168:8k_2_02:79]
2

[0001193125-18-074168:8k_2_02:80]
DELL TECHNOLOGIES INC.

[0001193125-18-074168:8k_2_02:81]
Condensed Consolidated Statements of Cash Flows

[0001193125-18-074168:8k_2_02:82]
(in millions; unaudited)

[0001193125-18-074168:8k_2_02:83]
|  |  | Three Months Ended |  |  | Fiscal Year Ended |  |
|  |  | February 2,2018 |  |  | February 3,2017 |  |  | February 2,2018 |  |  | February 3,2017 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net loss |  | $ | (553 | ) |  | $ | (270 | ) |  | $ | (3,855 | ) |  | $ | (1,718 | ) |
| Adjustments to reconcile net loss to net cash provided by operating activities |  |  | 3,684 |  |  |  | 1,010 |  |  |  | 10,665 |  |  |  | 4,027 |  |
| Change in cash from operating activities |  |  | 3,131 |  |  |  | 740 |  |  |  | 6,810 |  |  |  | 2,309 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Purchases |  |  | (935 | ) |  |  | (267 | ) |  |  | (4,389 | ) |  |  | (778 | ) |
| Maturities and sales |  |  | 885 |  |  |  | 612 |  |  |  | 3,878 |  |  |  | 1,173 |  |
| Capital expenditures |  |  | (310 | ) |  |  | (282 | ) |  |  | (1,212 | ) |  |  | (699 | ) |
| Proceeds from sale of facilities, land, and other assets |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 24 |  |
| Capitalized software development costs |  |  | (88 | ) |  |  | (122 | ) |  |  | (369 | ) |  |  | (207 | ) |
| Collections on purchased financing receivables |  |  | 5 |  |  |  | 4 |  |  |  | 30 |  |  |  | 35 |  |
| Acquisition of businesses, net |  |  | (435 | ) |  |  | (15 | ) |  |  | (658 | ) |  |  | (37,629 | ) |
| Divestitures of businesses, net |  |  | — |  |  |  | 6,873 |  |  |  | — |  |  |  | 6,873 |  |
| Asset acquisitions, net |  |  | (1 | ) |  |  | — |  |  |  | (96 | ) |  |  | — |  |
| Asset dispositions, net |  |  | (6 | ) |  |  | — |  |  |  | (59 | ) |  |  | — |  |
| Other |  |  | (6 | ) |  |  | — |  |  |  | (6 | ) |  |  | (48 | ) |
| Change in cash from investing activities |  |  | (891 | ) |  |  | 6,803 |  |  |  | (2,881 | ) |  |  | (31,256 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Payment of dissenting shares obligation |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (446 | ) |
| Share repurchases for tax withholdings on vesting of equity awards |  |  | (86 | ) |  |  | (65 | ) |  |  | (385 | ) |  |  | (93 | ) |
| Proceeds from the issuance of DHI Group Common Stock |  |  | — |  |  |  | 18 |  |  |  | — |  |  |  | 4,422 |  |
| Proceeds from the issuance of common stock of subsidiaries |  |  | 21 |  |  |  | 63 |  |  |  | 131 |  |  |  | 164 |  |
| Repurchases of DHI Group Common Stock |  |  | — |  |  |  | — |  |  |  | (6 | ) |  |  | (10 | ) |
| Repurchases of Class V Common Stock |  |  | (1 | ) |  |  | (569 | ) |  |  | (723 | ) |  |  | (701 | ) |
| Repurchases of common stock of subsidiaries |  |  | (169 | ) |  |  | — |  |  |  | (724 | ) |  |  | (611 | ) |
| Payments for debt issuance costs |  |  | (4 | ) |  |  | (4 | ) |  |  | (48 | ) |  |  | (853 | ) |
| Proceeds from debt |  |  | 1,247 |  |  |  | 907 |  |  |  | 14,439 |  |  |  | 46,893 |  |
| Repayments of debt |  |  | (1,140 | ) |  |  | (7,322 | ) |  |  | (12,321 | ) |  |  | (16,960 | ) |
| Other |  |  | — |  |  |  | 6 |  |  |  | 1 |  |  |  | 16 |  |
| Change in cash from financing activities |  |  | (132 | ) |  |  | (6,966 | ) |  |  | 364 |  |  |  | 31,821 |  |
| Effect of exchange rate changes on cash and cash equivalents |  |  | 128 |  |  |  | (7 | ) |  |  | 175 |  |  |  | 24 |  |
| Change in cash and cash equivalents |  |  | 2,236 |  |  |  | 570 |  |  |  | 4,468 |  |  |  | 2,898 |  |
| Cash and cash equivalents at beginning of period, including amounts held for sale |  |  | 11,706 |  |  |  | 8,904 |  |  |  | 9,474 |  |  |  | 6,576 |  |
| Cash and cash equivalents at end of the period |  | $ | 13,942 |  |  | $ | 9,474 |  |  | $ | 13,942 |  |  | $ | 9,474 |  |

[0001193125-18-074168:8k_2_02:84]
3

[0001193125-18-074168:8k_2_02:85]
DELL TECHNOLOGIES INC.

[0001193125-18-074168:8k_2_02:86]
Segment Information

[0001193125-18-074168:8k_2_02:87]
(in
millions, except percentages; unaudited)

[0001193125-18-074168:8k_2_02:88]
|  |  | Three Months Ended |  |  | Fiscal Year Ended |  |
|  |  | February 2,2018 |  |  | February 3,2017 |  |  | Change |  |  | February 2,2018 |  |  | February 3,2017 |  |  | Change |  |
| Client Solutions Group (CSG): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial |  | $ | 7,294 |  |  | $ | 6,663 |  |  |  | 9 | % |  | $ | 27,747 |  |  | $ | 26,006 |  |  |  | 7 | % |
| Consumer |  |  | 3,295 |  |  |  | 3,113 |  |  |  | 6 | % |  |  | 11,708 |  |  |  | 10,748 |  |  |  | 9 | % |
| Total CSG net revenue |  | $ | 10,589 |  |  | $ | 9,776 |  |  |  | 8 | % |  | $ | 39,455 |  |  | $ | 36,754 |  |  |  | 7 | % |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| CSG operating income |  | $ | 581 |  |  | $ | 342 |  |  |  | 70 | % |  | $ | 2,193 |  |  | $ | 1,845 |  |  |  | 19 | % |
| % of CSG net revenue |  |  | 5 | % |  |  | 3 | % |  |  |  |  |  |  | 6 | % |  |  | 5 | % |  |  |  |  |
| % of total segment operating income |  |  | 27 | % |  |  | 18 | % |  |  |  |  |  |  | 32 | % |  |  | 34 | % |  |  |  |  |
| Infrastructure Solutions Group (ISG): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Servers and networking |  | $ | 4,576 |  |  | $ | 3,612 |  |  |  | 27 | % |  | $ | 15,398 |  |  | $ | 12,834 |  |  |  | 20 | % |
| Storage |  |  | 4,236 |  |  |  | 4,783 |  |  |  | (11 | )% |  |  | 15,254 |  |  |  | 8,942 |  |  |  | 71 | % |
| Total ISG net revenue |  | $ | 8,812 |  |  | $ | 8,395 |  |  |  | 5 | % |  | $ | 30,652 |  |  | $ | 21,776 |  |  |  | 41 | % |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| ISG operating income |  | $ | 748 |  |  | $ | 1,004 |  |  |  | (25 | )% |  | $ | 2,179 |  |  | $ | 2,393 |  |  |  | (9 | )% |
| % of ISG net revenue |  |  | 8 | % |  |  | 12 | % |  |  |  |  |  |  | 7 | % |  |  | 11 | % |  |  |  |  |
| % of total segment operating income |  |  | 35 | % |  |  | 53 | % |  |  |  |  |  |  | 32 | % |  |  | 45 | % |  |  |  |  |
| VMware: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Total VMware net revenue |  | $ | 2,329 |  |  | $ | 1,936 |  |  |  | 20 | % |  | $ | 7,925 |  |  | $ | 3,225 |  |  |  | 146 | % |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| VMware operating income |  | $ | 834 |  |  | $ | 565 |  |  |  | 48 | % |  | $ | 2,520 |  |  | $ | 1,113 |  |  |  | 126 | % |
| % of VMware net revenue |  |  | 36 | % |  |  | 29 | % |  |  |  |  |  |  | 32 | % |  |  | 35 | % |  |  |  |  |
| % of total segment operating income |  |  | 38 | % |  |  | 30 | % |  |  |  |  |  |  | 36 | % |  |  | 21 | % |  |  |  |  |
| Reconciliation to consolidated net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Reportable segment net revenue |  | $ | 21,730 |  |  | $ | 20,107 |  |  |  |  |  |  | $ | 78,032 |  |  | $ | 61,755 |  |  |  |  |  |
| Other businesses (a) |  |  | 492 |  |  |  | 480 |  |  |  |  |  |  |  | 1,901 |  |  |  | 1,026 |  |  |  |  |  |
| Unallocated transactions (b) |  |  | (3 | ) |  |  | (6 | ) |  |  |  |  |  |  | (4 | ) |  |  | 41 |  |  |  |  |  |
| Impact of purchase accounting (c) |  |  | (284 | ) |  |  | (507 | ) |  |  |  |  |  |  | (1,269 | ) |  |  | (1,180 | ) |  |  |  |  |
| Total net revenue |  | $ | 21,935 |  |  | $ | 20,074 |  |  |  |  |  |  | $ | 78,660 |  |  | $ | 61,642 |  |  |  |  |  |
| Reconciliation to consolidated operating income (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Reportable segment operating income |  | $ | 2,163 |  |  | $ | 1,911 |  |  |  |  |  |  | $ | 6,892 |  |  | $ | 5,351 |  |  |  |  |  |
| Other businesses (a) |  |  | (31 | ) |  |  | (3 | ) |  |  |  |  |  |  | (21 | ) |  |  | (39 | ) |  |  |  |  |
| Unallocated transactions (b) |  |  | (12 | ) |  |  | (65 | ) |  |  |  |  |  |  | (16 | ) |  |  | (199 | ) |  |  |  |  |
| Impact of purchase accounting (c) |  |  | (351 | ) |  |  | (1,240 | ) |  |  |  |  |  |  | (1,546 | ) |  |  | (2,294 | ) |  |  |  |  |
| Amortization of intangibles |  |  | (1,730 | ) |  |  | (1,535 | ) |  |  |  |  |  |  | (6,980 | ) |  |  | (3,681 | ) |  |  |  |  |
| Transaction-related expenses (d) |  |  | (87 | ) |  |  | (159 | ) |  |  |  |  |  |  | (502 | ) |  |  | (1,488 | ) |  |  |  |  |
| Other corporate expenses (e) |  |  | (273 | ) |  |  | (577 | ) |  |  |  |  |  |  | (1,160 | ) |  |  | (902 | ) |  |  |  |  |
| Total operating loss |  | $ | (321 | ) |  | $ | (1,668 | ) |  |  |  |  |  | $ | (3,333 | ) |  | $ | (3,252 | ) |  |  |  |  |

[0001193125-18-074168:8k_2_02:89]
| (a) | Other businesses consist of RSA Information Security, SecureWorks, Pivotal, and Boomi, and do not constitute a reportable segment, either individually or collectively, as the results of the businesses are not material to the Company’s overall results and the businesses do not meet the criteria for reportable segments. |

[0001193125-18-074168:8k_2_02:90]
| (b) | Unallocated transactions includes long-term incentives, certain short-term incentive compensation expenses, and other corporate items that are not allocated to Dell Technologies’ reportable segments. |

[0001193125-18-074168:8k_2_02:91]
| (c) | Impact of purchase accounting includes non-cash purchase accounting adjustments that are primarily related to the EMC merger transaction. |

[0001193125-18-074168:8k_2_02:92]
| (d) | Transaction-related expenses includes acquisition, integration, and divestiture related costs. |

[0001193125-18-074168:8k_2_02:93]
| (e) | Other corporate expenses includes severance and facility action costs as well as stock-based compensation expense. |

[0001193125-18-074168:8k_2_02:94]
4

[0001193125-18-074168:8k_2_02:95]
SUPPLEMENTAL SELECTED NON-GAAP FINANCIAL MEASURES

[0001193125-18-074168:8k_2_02:96]
These tables present information about the Company’s non-GAAP net revenue, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income,
non-GAAP net income from continuing operations, EBITDA, and adjusted EBITDA, which are non-GAAP financial measures provided as a supplement to the results provided in accordance with generally accepted accounting principles in the United States of
America (“GAAP”). A detailed discussion of Dell Technologies’ reasons for including these non-GAAP financial measures, the limitations associated with these measures, the items excluded from these measures, and our reason for
excluding those items are presented in “Management’s Discussion and Analysis of Financial Condition and Results of Operations – Non-GAAP Financial Measures” in our periodic reports filed with the SEC. Dell Technologies
encourages investors to review the non-GAAP discussion in conjunction with the presentation of non-GAAP financial measures.

[0001193125-18-074168:8k_2_02:97]
5

[0001193125-18-074168:8k_2_02:98]
DELL TECHNOLOGIES INC.

[0001193125-18-074168:8k_2_02:99]
Selected Non-GAAP Financial Measures

[0001193125-18-074168:8k_2_02:100]
(in millions, except percentages; unaudited)

[0001193125-18-074168:8k_2_02:101]
|  |  | Three Months Ended |  |  | Fiscal Year Ended |  |
|  |  | February 2,2018 |  |  | February 3,2017 |  |  | Change |  |  | February 2,2018 |  |  | February 3,2017 |  |  | Change |  |
| Non-GAAP net revenue |  | $ | 22,219 |  |  | $ | 20,581 |  |  |  | 8 | % |  | $ | 79,929 |  |  | $ | 62,822 |  |  |  | 27 | % |
| Non-GAAP gross margin |  | $ | 7,022 |  |  | $ | 6,595 |  |  |  | 6 | % |  | $ | 25,185 |  |  | $ | 16,819 |  |  |  | 50 | % |
| % of non-GAAP net revenue |  |  | 32 | % |  |  | 32 | % |  |  |  |  |  |  | 32 | % |  |  | 27 | % |  |  |  |  |
| Non-GAAP operating expenses |  | $ | 4,902 |  |  | $ | 4,752 |  |  |  | 3 | % |  | $ | 18,330 |  |  | $ | 11,706 |  |  |  | 57 | % |
| % of non-GAAP net revenue |  |  | 22 | % |  |  | 23 | % |  |  |  |  |  |  | 23 | % |  |  | 19 | % |  |  |  |  |
| Non-GAAP operating income |  | $ | 2,120 |  |  | $ | 1,843 |  |  |  | 15 | % |  | $ | 6,855 |  |  | $ | 5,113 |  |  |  | 34 | % |
| % of non-GAAP net revenue |  |  | 10 | % |  |  | 9 | % |  |  |  |  |  |  | 9 | % |  |  | 8 | % |  |  |  |  |
| Non-GAAP net income from continuing operations |  | $ | 1,097 |  |  | $ | 1,091 |  |  |  | 1 | % |  | $ | 3,660 |  |  | $ | 2,687 |  |  |  | 36 | % |
| % of non-GAAP net revenue |  |  | 5 | % |  |  | 5 | % |  |  |  |  |  |  | 5 | % |  |  | 4 | % |  |  |  |  |
| Adjusted EBITDA |  | $ | 2,466 |  |  | $ | 2,184 |  |  |  | 13 | % |  | $ | 8,217 |  |  | $ | 5,941 |  |  |  | 38 | % |
| % of non-GAAP net revenue |  |  | 11 | % |  |  | 11 | % |  |  |  |  |  |  | 10 | % |  |  | 9 | % |  |  |  |  |

[0001193125-18-074168:8k_2_02:102]
6

[0001193125-18-074168:8k_2_02:103]
DELL TECHNOLOGIES INC.

[0001193125-18-074168:8k_2_02:104]
Reconciliation of Selected Non-GAAP Financial Measures

[0001193125-18-074168:8k_2_02:105]
(in millions, except percentages; unaudited)

[0001193125-18-074168:8k_2_02:106]
|  |  | Three Months Ended |  |  | Fiscal Year Ended |  |
|  |  | February 2,2018 |  |  | February 3,2017 |  |  | Change |  |  | February 2,2018 |  |  | February 3,2017 |  |  | Change |  |
| Net revenue |  | $ | 21,935 |  |  | $ | 20,074 |  |  |  | 9 | % |  | $ | 78,660 |  |  | $ | 61,642 |  |  |  | 28 | % |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting |  |  | 284 |  |  |  | 507 |  |  |  |  |  |  |  | 1,269 |  |  |  | 1,180 |  |  |  |  |  |
| Non-GAAP net revenue |  | $ | 22,219 |  |  | $ | 20,581 |  |  |  | 8 | % |  | $ | 79,929 |  |  | $ | 62,822 |  |  |  | 27 | % |
| Gross margin |  | $ | 5,780 |  |  | $ | 4,531 |  |  |  | 28 | % |  | $ | 20,054 |  |  | $ | 12,959 |  |  |  | 55 | % |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles |  |  | 910 |  |  |  | 847 |  |  |  |  |  |  |  | 3,694 |  |  |  | 1,653 |  |  |  |  |  |
| Impact of purchase accounting |  |  | 292 |  |  |  | 1,110 |  |  |  |  |  |  |  | 1,312 |  |  |  | 2,007 |  |  |  |  |  |
| Transaction-related expenses |  |  | 2 |  |  |  | 18 |  |  |  |  |  |  |  | 24 |  |  |  | 43 |  |  |  |  |  |
| Other corporate expenses |  |  | 38 |  |  |  | 89 |  |  |  |  |  |  |  | 101 |  |  |  | 157 |  |  |  |  |  |
| Non-GAAP gross margin |  | $ | 7,022 |  |  | $ | 6,595 |  |  |  | 6 | % |  | $ | 25,185 |  |  | $ | 16,819 |  |  |  | 50 | % |
| Operating expenses |  | $ | 6,101 |  |  | $ | 6,199 |  |  |  | (2 | )% |  | $ | 23,387 |  |  | $ | 16,211 |  |  |  | 44 | % |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles |  |  | (820 | ) |  |  | (688 | ) |  |  |  |  |  |  | (3,286 | ) |  |  | (2,028 | ) |  |  |  |  |
| Impact of purchase accounting |  |  | (59 | ) |  |  | (130 | ) |  |  |  |  |  |  | (234 | ) |  |  | (287 | ) |  |  |  |  |
| Transaction-related expenses |  |  | (85 | ) |  |  | (141 | ) |  |  |  |  |  |  | (478 | ) |  |  | (1,445 | ) |  |  |  |  |
| Other corporate expenses |  |  | (235 | ) |  |  | (488 | ) |  |  |  |  |  |  | (1,059 | ) |  |  | (745 | ) |  |  |  |  |
| Non-GAAP operating expenses |  | $ | 4,902 |  |  | $ | 4,752 |  |  |  | 3 | % |  | $ | 18,330 |  |  | $ | 11,706 |  |  |  | 57 | % |
| Operating loss |  | $ | (321 | ) |  | $ | (1,668 | ) |  |  | 81 | % |  | $ | (3,333 | ) |  | $ | (3,252 | ) |  |  | (2 | )% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles |  |  | 1,730 |  |  |  | 1,535 |  |  |  |  |  |  |  | 6,980 |  |  |  | 3,681 |  |  |  |  |  |
| Impact of purchase accounting |  |  | 351 |  |  |  | 1,240 |  |  |  |  |  |  |  | 1,546 |  |  |  | 2,294 |  |  |  |  |  |
| Transaction-related expenses |  |  | 87 |  |  |  | 159 |  |  |  |  |  |  |  | 502 |  |  |  | 1,488 |  |  |  |  |  |
| Other corporate expenses |  |  | 273 |  |  |  | 577 |  |  |  |  |  |  |  | 1,160 |  |  |  | 902 |  |  |  |  |  |
| Non-GAAP operating income |  | $ | 2,120 |  |  | $ | 1,843 |  |  |  | 15 | % |  | $ | 6,855 |  |  | $ | 5,113 |  |  |  | 34 | % |
| Net loss from continuing operations |  | $ | (553 | ) |  | $ | (1,414 | ) |  |  | 61 | % |  | $ | (3,855 | ) |  | $ | (3,737 | ) |  |  | (3 | )% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles |  |  | 1,730 |  |  |  | 1,535 |  |  |  |  |  |  |  | 6,980 |  |  |  | 3,681 |  |  |  |  |  |
| Impact of purchase accounting |  |  | 351 |  |  |  | 1,240 |  |  |  |  |  |  |  | 1,546 |  |  |  | 2,294 |  |  |  |  |  |
| Transaction-related expenses |  |  | 87 |  |  |  | 159 |  |  |  |  |  |  |  | 502 |  |  |  | 1,485 |  |  |  |  |  |
| Other corporate expenses |  |  | 273 |  |  |  | 577 |  |  |  |  |  |  |  | 1,160 |  |  |  | 902 |  |  |  |  |  |
| Aggregate adjustment for income taxes |  |  | (791 | ) |  |  | (1,006 | ) |  |  |  |  |  |  | (2,673 | ) |  |  | (1,938 | ) |  |  |  |  |
| Non-GAAP net income from continuing operations |  | $ | 1,097 |  |  | $ | 1,091 |  |  |  | 1 | % |  | $ | 3,660 |  |  | $ | 2,687 |  |  |  | 36 | % |
| Net loss from continuing operations |  | $ | (553 | ) |  | $ | (1,414 | ) |  |  | 61 | % |  | $ | (3,855 | ) |  | $ | (3,737 | ) |  |  | (3 | )% |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest and other, net |  |  | 555 |  |  |  | 742 |  |  |  |  |  |  |  | 2,355 |  |  |  | 2,104 |  |  |  |  |  |
| Income tax benefit |  |  | (323 | ) |  |  | (996 | ) |  |  |  |  |  |  | (1,833 | ) |  |  | (1,619 | ) |  |  |  |  |
| Depreciation and amortization |  |  | 2,143 |  |  |  | 2,041 |  |  |  |  |  |  |  | 8,634 |  |  |  | 4,840 |  |  |  |  |  |
| EBITDA |  | $ | 1,822 |  |  | $ | 373 |  |  |  | 388 | % |  | $ | 5,301 |  |  | $ | 1,588 |  |  |  | 234 | % |
| EBITDA |  | $ | 1,822 |  |  | $ | 373 |  |  |  | 388 | % |  | $ | 5,301 |  |  | $ | 1,588 |  |  |  | 234 | % |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense |  |  | 205 |  |  |  | 215 |  |  |  |  |  |  |  | 835 |  |  |  | 392 |  |  |  |  |  |
| Impact of purchase accounting |  |  | 284 |  |  |  | 1,075 |  |  |  |  |  |  |  | 1,274 |  |  |  | 1,926 |  |  |  |  |  |
| Transaction-related expenses |  |  | 87 |  |  |  | 159 |  |  |  |  |  |  |  | 502 |  |  |  | 1,525 |  |  |  |  |  |
| Other corporate expenses |  |  | 68 |  |  |  | 362 |  |  |  |  |  |  |  | 305 |  |  |  | 510 |  |  |  |  |  |
| Adjusted EBITDA |  | $ | 2,466 |  |  | $ | 2,184 |  |  |  | 13 | % |  | $ | 8,217 |  |  | $ | 5,941 |  |  |  | 38 | % |

[0001193125-18-074168:8k_2_02:107]
7
