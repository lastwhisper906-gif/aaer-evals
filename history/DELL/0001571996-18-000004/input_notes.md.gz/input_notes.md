# DELL notes — 0001571996-18-000004


## dvmt:ReconciliationofConsolidatedNetIncomeLossTableTextBlock

[0001571996-18-000004:notes:1]
The following table presents a reconciliation to the consolidated net income (loss) attributable to Dell Technologies Inc.:

[0001571996-18-000004:notes:2]
|  | Fiscal Year Ended |
|  | February 2, 2018 |  | February 3, 2017 |  | January 29, 2016 |
| Net income from continuing operations attributable to Class V Common Stock | $ | 286 |  |  | $ | 313 |  |  | $ | — |  |
| Net loss from continuing operations attributable to DHI Group | (4,014 | ) |  | (4,004 | ) |  | (1,168 | ) |
| Net loss from continuing operations attributable to Dell Technologies Inc. | (3,728 | ) |  | (3,691 | ) |  | (1,168 | ) |
| Income from discontinued operations, net of income taxes (Note 4) | — |  |  | 2,019 |  |  | 64 |  |
| Net loss attributable to Dell Technologies Inc. | $ | (3,728 | ) |  | $ | (1,672 | ) |  | $ | (1,104 | ) |

[0001571996-18-000004:notes:3]
The following table presents a reconciliation of (1) the equity in net loss of subsidiaries to the net loss attributable to Dell Technologies Inc. and (2) consolidated net loss to comprehensive net loss attributable to Dell Technologies Inc. for the fiscal years ended February 2, 2018, February 3, 2017, and January 29, 2016.

[0001571996-18-000004:notes:4]
|  | Fiscal Year Ended |
|  | February 2, 2018 |  | February 3, 2017 |  | January 29, 2016 |
|  | (in millions) |
| Equity in net loss from continuing operations of subsidiaries attributable to Dell Technologies Inc. | $ | (3,723 | ) |  | $ | (3,684 | ) |  | $ | (1,177 | ) |
| Equity in net income (loss) from discontinued operations of subsidiaries | — |  |  | 2,019 |  |  | 64 |  |
| Equity in net loss of subsidiaries attributable to Dell Technologies Inc. | (3,723 | ) |  | (1,665 | ) |  | (1,113 | ) |
| Parent - Interest and other, net | (2 | ) |  | (11 | ) |  | 8 |  |
| Parent - Income tax expense (benefit) | 3 |  |  | (4 | ) |  | (1 | ) |
| Consolidated net loss attributable to Dell Technologies Inc. | (3,728 | ) |  | (1,672 | ) |  | (1,104 | ) |
| Consolidated net loss attributable to Dell Technologies Inc. | (3,728 | ) |  | (1,672 | ) |  | (1,104 | ) |
| Other comprehensive income (loss) of subsidiaries attributable to Dell Technologies Inc. | 725 |  |  | (271 | ) |  | (353 | ) |
| Comprehensive loss attributable to Dell Technologies Inc. | $ | (3,003 | ) |  | $ | (1,943 | ) |  | $ | (1,457 | ) |


## dvmt:SummaryofValuationandQualifyingAccountsTableTextBlock

[0001571996-18-000004:notes:5]
Valuation and Qualifying Accounts

[0001571996-18-000004:notes:6]
The following table summarizes the Company's valuation and qualifying accounts for the fiscal years ended February 2, 2018, February 3, 2017, and January 29, 2016:

[0001571996-18-000004:notes:7]
|  | Fiscal Year Ended |
|  | February 2, 2018 |  | February 3, 2017 |  | January 29, 2016 |
|  | (in millions) |
| Trade Receivables - Allowance for doubtful accounts |  |  |  |  |  |
| Balance at beginning of period | $ | 57 |  |  | $ | 36 |  |  | $ | 38 |  |
| Provision charged to income statement | 60 |  |  | 43 |  |  | 64 |  |
| Bad debt write-offs | (14 | ) |  | (22 | ) |  | (66 | ) |
| Balance at end of period | $ | 103 |  |  | $ | 57 |  |  | $ | 36 |  |
| Trade Receivables - Allowance for customer returns |  |  |  |  |  |
| Balance at beginning of period | $ | 293 |  |  | $ | 123 |  |  | $ | 130 |  |
| Provision charged to income statement | 473 |  |  | 470 |  |  | 410 |  |
| Sales returns | (471 | ) |  | (300 | ) |  | (417 | ) |
| Balance at end of period | $ | 295 |  |  | $ | 293 |  |  | $ | 123 |  |
| Customer Financing Receivables - Allowance for financing receivable losses |  |  |  |  |  |
| Balance at beginning of period | $ | 143 |  |  | $ | 176 |  |  | $ | 194 |  |
| Provision charged to income statement | 103 |  |  | 75 |  |  | 104 |  |
| Charge-offs, net of recoveries (a) | (101 | ) |  | (108 | ) |  | (122 | ) |
| Balance at end of period | $ | 145 |  |  | $ | 143 |  |  | $ | 176 |  |
| Tax Valuation Allowance |  |  |  |  |  |
| Balance at beginning of period | $ | 737 |  |  | $ | 816 |  |  | $ | 432 |  |
| Charged to income tax provision | 78 |  |  | (488 | ) |  | 384 |  |
| Allowance acquired | — |  |  | 409 |  |  | — |  |
| Balance at end of period | $ | 815 |  |  | $ | 737 |  |  | $ | 816 |  |

[0001571996-18-000004:notes:8]
____________________

[0001571996-18-000004:notes:9]
| (a) | Charge-offs to the allowance for financing receivable losses for customer financing receivables includes principal and interest. |


## invest:InvestmentTableTextBlock

[0001571996-18-000004:notes:10]
The following table summarizes, by major security type, the carrying value and amortized cost of the Company's investments.  All debt security investments with remaining effective maturities in excess of one year and substantially all equity and other securities are recorded as long-term investments in the Consolidated Statements of Financial Position.

[0001571996-18-000004:notes:11]
|  | February 2, 2018 |  | February 3, 2017 |
|  | Cost |  | Unrealized Gain |  | Unrealized (Loss) |  | Carrying Value |  | Cost |  | Unrealized Gain |  | Unrealized (Loss) |  | Carrying Value |
|  | (in millions) |
| Investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government and agencies | $ | 485 |  |  | $ | — |  |  | $ | (2 | ) |  | $ | 483 |  |  | $ | 231 |  |  | $ | — |  |  | $ | — |  |  | $ | 231 |  |
| U.S. corporate debt securities | 660 |  |  | — |  |  | (2 | ) |  | 658 |  |  | 651 |  |  | — |  |  | (1 | ) |  | 650 |  |
| Foreign debt securities | 1,048 |  |  | — |  |  | (2 | ) |  | 1,046 |  |  | 743 |  |  | — |  |  | (1 | ) |  | 742 |  |
| Municipal obligations | — |  |  | — |  |  | — |  |  | — |  |  | 348 |  |  | — |  |  | — |  |  | 348 |  |
| Asset-backed securities | — |  |  | — |  |  | — |  |  | — |  |  | 4 |  |  | — |  |  | — |  |  | 4 |  |
| Total short-term investments | 2,193 |  |  | — |  |  | (6 | ) |  | 2,187 |  |  | 1,977 |  |  | — |  |  | (2 | ) |  | 1,975 |  |
| U.S. government and agencies | 600 |  |  | — |  |  | (9 | ) |  | 591 |  |  | 689 |  |  | — |  |  | (6 | ) |  | 683 |  |
| U.S. corporate debt securities | 1,361 |  |  | — |  |  | (16 | ) |  | 1,345 |  |  | 1,164 |  |  | — |  |  | (14 | ) |  | 1,150 |  |
| Foreign debt securities | 1,518 |  |  | — |  |  | (17 | ) |  | 1,501 |  |  | 1,356 |  |  | — |  |  | (15 | ) |  | 1,341 |  |
| Municipal obligations | — |  |  | — |  |  | — |  |  | — |  |  | 4 |  |  | — |  |  | — |  |  | 4 |  |
| Equity and other securities (a) | 640 |  |  | 86 |  |  | — |  |  | 726 |  |  | 604 |  |  | 22 |  |  | (2 | ) |  | 624 |  |
| Total long-term investments | 4,119 |  |  | 86 |  |  | (42 | ) |  | 4,163 |  |  | 3,817 |  |  | 22 |  |  | (37 | ) |  | 3,802 |  |
| Total investments | $ | 6,312 |  |  | $ | 86 |  |  | $ | (48 | ) |  | $ | 6,350 |  |  | $ | 5,794 |  |  | $ | 22 |  |  | $ | (39 | ) |  | $ | 5,777 |  |

[0001571996-18-000004:notes:12]
| (a) | The majority of equity and other securities are strategic investments accounted for under the cost method, while the remainder are investments that are measured at fair value on a recurring basis. See Note 5 of the Notes to the Consolidated Financial Statements for additional information on investments measured at fair value on a recurring basis. |


## invest:InvestmentTextBlock

[0001571996-18-000004:notes:13]
INVESTMENTS

[0001571996-18-000004:notes:14]
The Company's investments in debt securities are classified as available-for-sale securities, which are carried at fair value.  As of February 2, 2018, the aggregate fair value of investments held in a continuous unrealized loss position for greater than 12 months was $1.9 billion, and the unrealized loss of these investments was $25 million.  As of February 3, 2017, all investments in an unrealized loss position were in a continuous unrealized loss position for less than 12 months.

[0001571996-18-000004:notes:15]
The maturities of debt securities held at February 2, 2018 are as follows:

[0001571996-18-000004:notes:16]
|  | Amortized Cost |  | Carrying Value |
|  | (in millions) |
| Due within one year | $ | 2,193 |  |  | $ | 2,187 |  |
| Due after 1 year through 5 years | 3,419 |  |  | 3,378 |  |
| Due after 5 years through 10 years | 60 |  |  | 59 |  |
| Total | $ | 5,672 |  |  | $ | 5,624 |  |


## us-gaap:AllowanceForCreditLossesOnFinancingReceivablesTableTextBlock

[0001571996-18-000004:notes:17]
The following tables summarize the changes in the allowance for financing receivable losses for the respective periods:

[0001571996-18-000004:notes:18]
|  | Fiscal Year Ended |
|  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |  |  |  |  |  |
| Balances as of January 30, 2015 | $ | 145 |  |  | $ | 49 |  |  | $ | 194 |  |
| Charge-offs, net of recoveries | (105 | ) |  | (17 | ) |  | (122 | ) |
| Provision charged to income statement | 78 |  |  | 26 |  |  | 104 |  |
| Balances as of January 29, 2016 | 118 |  |  | 58 |  |  | 176 |  |
| Charge-offs, net of recoveries | (91 | ) |  | (17 | ) |  | (108 | ) |
| Provision charged to income statement | 64 |  |  | 11 |  |  | 75 |  |
| Balances as of February 3, 2017 | 91 |  |  | 52 |  |  | 143 |  |
| Charge-offs, net of recoveries | (84 | ) |  | (17 | ) |  | (101 | ) |
| Provision charged to income statement | 74 |  |  | 29 |  |  | 103 |  |
| Balances as of February 2, 2018 | $ | 81 |  |  | $ | 64 |  |  | $ | 145 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001571996-18-000004:notes:19]
These Consolidated Financial Statements have been prepared in accordance with accounting principles generally accepted in the United States of America ("GAAP").  References in these Notes to the Consolidated Financial Statements to the "Company" or "Dell Technologies" mean Dell Technologies Inc. individually and together with its consolidated subsidiaries.


## us-gaap:BusinessAcquisitionProFormaInformationTextBlock

[0001571996-18-000004:notes:20]
The following table provides unaudited pro forma results of operations for the periods presented as if the transaction date had occurred on January 31, 2015, the first day of the fiscal year ended January 29, 2016.

[0001571996-18-000004:notes:21]
|  | Fiscal Year Ended |
|  | February 3, 2017 |  | January 29, 2016 |
|  | (in millions) |
| Total net revenue | $ | 74,225 |  |  | $ | 73,138 |  |
| Net loss attributable to Dell Technologies Inc. | $ | (3,200 | ) |  | $ | (6,013 | ) |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001571996-18-000004:notes:22]
BUSINESS COMBINATIONS

[0001571996-18-000004:notes:23]
Fiscal 2018

[0001571996-18-000004:notes:24]
VMware, Inc. Acquisitions

[0001571996-18-000004:notes:25]
VeloCloud Networks, Inc. — During the fourth quarter of the fiscal year ended February 2, 2018, VMware, Inc. completed the acquisition of VeloCloud Networks, Inc. (“VeloCloud”), a provider of cloud-delivered software-defined wide-area network (SD-WAN) technology for enterprises and service providers.  VMware, Inc. acquired VeloCloud to build on its network virtualization platform, VMware NSX, and to expand its networking portfolio.  The total purchase price was $499 million, net of cash acquired of $24 million. The purchase price primarily included $142 million of identifiable intangible assets and $326 million of goodwill that is not expected to be deductible for tax purposes.  The identifiable intangible assets primarily include completed technology of $87 million and customer contracts of $44 million, with estimated useful lives of six to seven years.  The fair value of assumed unvested equity attributed to post-combination services was $30 million and will be expensed over the remaining requisite service periods on a straight-line basis.  The estimated fair value of the stock options assumed by the Company was determined using the Black-Scholes option pricing model.

[0001571996-18-000004:notes:26]
The preliminary allocation of the purchase price was based on a preliminary valuation and assumptions, and is subject to change within the measurement period.  VMware, Inc. expects to finalize the allocation of the purchase price as soon as practicable and not later than one year from the acquisition date.

[0001571996-18-000004:notes:27]
Prior to the closing of the acquisition, Dell Technologies, including VMware Inc., held an ownership interest in VeloCloud.  Upon completion of the step acquisition, Dell Technologies recognized a gain of $8 million in interest and other, net for the remeasurement of its previously held ownership interest to fair value, which was $12 million.

[0001571996-18-000004:notes:28]
The Company has not presented pro forma results of operations for the VeloCloud acquisition because it is not material to the Company's consolidated results of operations, financial position, or cash flows.

[0001571996-18-000004:notes:29]
Other Business Combinations — During the second quarter of the fiscal year ended February 2, 2018, VMware, Inc. completed the acquisitions of Wavefront and Apteligent, Inc., which were not material to the Consolidated Financial Statements.  These acquisitions are a part of VMware, Inc.’s strategy to accelerate the development of VMware, Inc.'s Cloud services and other technologies.  The aggregate purchase price for the two acquisitions was $323 million, inclusive of the fair value of the Company's existing investment in Wavefront of $69 million and cash acquired of $35 million.  The aggregate purchase price included $36 million of identifiable intangible assets and $238 million of goodwill that is not expected to be deductible for tax purposes.  The identifiable intangible assets primarily relate to purchased technology, with estimated useful lives of five years.  The fair value of assumed unvested equity attributable to post-combination services was $37 million and will be expensed over the remaining requisite service periods on a straight-line basis.  The estimated fair value of the stock options assumed by the Company was determined using the Black-Scholes option pricing model.

[0001571996-18-000004:notes:30]
Prior to the closing of the acquisition, Dell Technologies, including VMware, Inc., held an ownership interest in Wavefront.  Upon completion of the step acquisition, Dell Technologies recognized a $45 million gain in interest and other, net for the remeasurement of its previously held ownership interest to fair value.

[0001571996-18-000004:notes:31]
The Company has not presented pro forma results of operations for the foregoing acquisitions because they are not material to the Company's consolidated results of operations, financial position, or cash flows.

[0001571996-18-000004:notes:32]
Fiscal 2017

[0001571996-18-000004:notes:33]
EMC Merger Transaction

[0001571996-18-000004:notes:34]
On September 7, 2016, EMC became a wholly-owned subsidiary of the Company as a result of the merger of Merger Sub with and into EMC.  Pursuant to the terms of the merger agreement, upon the completion of the EMC merger transaction, each issued and outstanding share of common stock, par value $0.01 per share, of EMC (approximately 2.0 billion shares as of September 7, 2016) was converted into the right to receive (1) $24.05 in cash, without interest, and (2) 0.11146 validly issued, fully paid, and non-assessable shares of common stock of the Company designated as Class V Common Stock, par value $0.01 per share (the "Class V Common Stock"), plus cash in lieu of any fractional shares.  Shares of the Class V Common Stock were approved for listing on the New York Stock Exchange (the "NYSE") under the ticker symbol "DVMT" and began trading on September 7, 2016.

[0001571996-18-000004:notes:35]
In connection with the EMC merger transaction, the Company authorized 343 million shares of Class V Common Stock.  On September 7, 2016, Dell Technologies issued 223 million shares of Class V Common Stock to EMC shareholders at a purchase price of $45.07 per share for an aggregate purchase price of approximately $10 billion.  The total fair value of consideration transferred to effect the EMC merger transaction was approximately $64 billion, which primarily consisted of cash and such shares of Class V Common Stock, as well as the fair value of non-controlling interests in VMware, Inc. and Pivotal, majority-owned consolidated subsidiaries of EMC.  See Note 18 of the Notes to the Consolidated Financial Statements for additional information on the Class V Common Stock.

[0001571996-18-000004:notes:36]
Fair Value of Consideration Transferred — The following table summarizes the consideration transferred to effect the EMC merger transaction:

[0001571996-18-000004:notes:37]
|  | Purchase Price |
|  | (in millions) |
| Consideration transferred: |  |
| Cash | $ | 47,694 |  |
| Expense and other (a) | 968 |  |
| Class V Common Stock (b) | 10,041 |  |
| Total consideration transferred | 58,703 |  |
| Non-controlling interests (c) | 6,048 |  |
| Less: Post-merger stock compensation expense (d) | (800 | ) |
| Total purchase price to allocate | $ | 63,951 |  |

[0001571996-18-000004:notes:38]
(a)   Expense and other primarily consists of cash payment for post-merger stock compensation expense, as described in footnote (d), and the value related to pre-merger services of EMC equity awards converted to deferred cash awards.

[0001571996-18-000004:notes:39]
| (b) | The fair value of the Class V Common Stock is based on the issuance of approximately 223 million shares with a per-share fair value of $45.07 (the opening share price of the Class V Common Stock on the NYSE on September 7, 2016, the first day of trading), which shares were intended to track the economic performance of approximately 65% of the Company's economic interest in the VMware business, as of the closing date of the EMC merger transaction. |

[0001571996-18-000004:notes:40]
| (c) | Non-controlling interests in VMware, Inc. and Pivotal was $6.0 billion as of September 7, 2016. The fair value of the non-controlling interest related to VMware, Inc. was calculated by multiplying outstanding shares of VMware, Inc. common stock that were not owned by EMC by $73.28 (the opening share price of VMware, Inc. Class A common stock on the NYSE on September 7, 2016). The fair value of the non-controlling interest relating to Pivotal was calculated based on the fair value of Pivotal, the ownership percentage of the non-controlling interests, and a discount for lack of control related to the non-controlling interest. |

[0001571996-18-000004:notes:41]
| (d) | Pursuant to the guidelines of ASC 805, a portion of the consideration related to accelerated EMC equity awards was recorded as post-merger day one stock compensation expense. This expense is attributable to post-merger services not rendered due to the acceleration. |

[0001571996-18-000004:notes:42]
Assets Acquired and Liabilities Assumed — The EMC merger transaction has been accounted for as a business combination under the acquisition method of accounting.  The cumulative impact of any subsequent changes resulting from the facts and circumstances that existed as of the transaction date will be adjusted in the reporting period in which the adjustment amount is determined.  The following table summarizes, as of February 2, 2018, the purchase price allocation to the assets acquired and the liabilities assumed in the EMC merger transaction (in millions):

[0001571996-18-000004:notes:43]
| Current assets: |  |
| Cash and cash equivalents | $ | 10,080 |  |
| Short-term investments | 1,765 |  |
| Accounts receivable | 2,810 |  |
| Short-term financing receivables | 64 |  |
| Inventories, net | 1,993 |  |
| Other current assets | 903 |  |
| Total current assets | 17,615 |  |
| Property, plant, and equipment | 4,490 |  |
| Long-term investments | 4,317 |  |
| Long-term financing receivables, net | 65 |  |
| Goodwill | 31,539 |  |
| Purchased intangibles | 31,218 |  |
| Other non-current assets | 445 |  |
| Total assets | $ | 89,689 |  |
| Current liabilities: |  |
| Short-term debt | $ | 905 |  |
| Accounts payable | 728 |  |
| Accrued and other | 3,259 |  |
| Short-term deferred revenue | 4,954 |  |
| Total current liabilities | 9,846 |  |
| Long-term debt | 5,474 |  |
| Long-term deferred revenue | 3,469 |  |
| Deferred tax liabilities | 6,625 |  |
| Other non-current liabilities | 324 |  |
| Total liabilities | 25,738 |  |
| Total net assets | $ | 63,951 |  |

[0001571996-18-000004:notes:44]
The table above includes amounts allocated to ECD, which was divested in the fiscal year ended February 3, 2017.  See Note 4 of the Notes to the Consolidated Financial Statements for more information on discontinued operations.

[0001571996-18-000004:notes:45]
Pro Forma Financial Information — The following table provides unaudited pro forma results of operations for the periods presented as if the transaction date had occurred on January 31, 2015, the first day of the fiscal year ended January 29, 2016.

[0001571996-18-000004:notes:46]
The pro forma information for the fiscal year ended February 3, 2017 combines the Company's historical results for the fiscal year ended February 3, 2017 and EMC's historical results for the period from February 1, 2016 to September 6, 2016.  The pro forma information for the fiscal year ended January 29, 2016 combines the Company's historical results for the fiscal year ended January 29, 2016 with EMC's historical results for the fiscal year ended December 31, 2015.  The historical results have been adjusted in the pro forma information to give effect to items that are (a) directly attributable to the EMC merger transaction, (b) factually supportable, and (c) expected to have a continuing impact on the combined company's results.  The unaudited pro forma results include the recognition of non-recurring purchase accounting adjustments related to the step-up of inventory of $0.7 billion as well as the recognition of non-recurring transaction and integration costs, including accelerated stock-based compensation expense, of $1.5 billion in the fiscal year ended January 29, 2016.

[0001571996-18-000004:notes:47]
The pro forma information does not purport to represent what the combined company's results of operations or financial condition would have been had the EMC merger transaction actually occurred on the date indicated, and does not purport to project the combined company's results of operations for any future period or as of any future date.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock

[0001571996-18-000004:notes:48]
BASIS OF PRESENTATION

[0001571996-18-000004:notes:49]
EMC Merger Transaction — On September 7, 2016, a wholly-owned subsidiary of Dell Technologies Inc. ("Merger Sub") merged with and into EMC Corporation, a Massachusetts corporation ("EMC"), with EMC surviving the merger as a wholly-owned subsidiary of Dell Technologies Inc. (the "EMC merger transaction").  See Note 3 of the Notes to the Consolidated Financial Statements for additional information on the EMC merger transaction.

[0001571996-18-000004:notes:50]
Divestitures — On November 2, 2016, Dell Inc. ("Dell"), a wholly-owned subsidiary of Dell Technologies Inc., completed substantially all of the divestiture of Dell Services.  On October 31, 2016, Dell completed the divestiture of Dell Software Group ("DSG").  On January 23, 2017, EMC, a subsidiary of the Company, completed the divestiture of the Dell EMC Enterprise Content Division ("ECD").  In accordance with applicable accounting guidance, the results of Dell Services, DSG, and ECD are presented as discontinued operations in the Consolidated Statements of Income (Loss) and, as such, have been excluded from both continuing operations and segment results for the relevant periods.  See Note 4 of the Notes to the Consolidated Financial Statements for additional information.

[0001571996-18-000004:notes:51]
Going-Private Transaction - On October 29, 2013, Dell Technologies acquired Dell in a transaction referred to as the going-private transaction.

[0001571996-18-000004:notes:52]
Basis of Presentation — These Consolidated Financial Statements have been prepared in accordance with accounting principles generally accepted in the United States of America ("GAAP").  References in these Notes to the Consolidated Financial Statements to the "Company" or "Dell Technologies" mean Dell Technologies Inc. individually and together with its consolidated subsidiaries.

[0001571996-18-000004:notes:53]
As a result of the EMC merger transaction completed on September 7, 2016, the Company's results of operations, comprehensive income (loss), and cash flows for the fiscal periods reflected in these Consolidated Financial Statements are not directly comparable as the results of the acquired businesses are only included in the consolidated results from September 7, 2016.

[0001571996-18-000004:notes:54]
Unless the context indicates otherwise, references in these Notes to the Consolidated Financial Statements to "VMware" mean the VMware reportable segment, which reflects the operations of VMware, Inc. (NYSE: VMW) within Dell Technologies.  See Exhibit 99.1 filed with the annual report on Form 10-K for the fiscal year ended February 2, 2018 for information on the differences between VMware reportable segment results and VMware, Inc. results.


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0001571996-18-000004:notes:55]
All highly liquid investments, including credit card receivables due from banks, with original maturities of 90 days or less at date of purchase, are reported at fair value and are considered to be cash equivalents.  All other investments not considered to be cash equivalents are separately categorized as investments.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001571996-18-000004:notes:56]
COMMITMENTS AND CONTINGENCIES

[0001571996-18-000004:notes:57]
Lease Commitments

[0001571996-18-000004:notes:58]
The Company leases property and equipment, manufacturing facilities, and office space under non-cancelable leases.  Certain of these leases obligate the Company to pay taxes, maintenance, and repair costs.  As of February 2, 2018 future minimum lease payments under these non-cancelable leases were as follows: $405 million in Fiscal 2019; $345 million in Fiscal 2020; $275 million in Fiscal 2021; $204 million in Fiscal 2022; $131 million in Fiscal 2023; and $700 million thereafter.

[0001571996-18-000004:notes:59]
The amount of the future lease commitments after Fiscal 2023 is primarily for the ground leases on VMware Inc.'s Palo Alto, California headquarter facilities, which expire in Fiscal 2047.

[0001571996-18-000004:notes:60]
For the fiscal years ended February 2, 2018, February 3, 2017, and January 29, 2016, rent expense under all leases totaled $571 million, $279 million, and $91 million, respectively.

[0001571996-18-000004:notes:61]
Purchase Obligations

[0001571996-18-000004:notes:62]
The Company has contractual obligations to purchase goods or services, which specify significant terms, including fixed or minimum quantities to be purchased; fixed, minimum, or variable price provisions; and the approximate timing of the transaction.  As of February 2, 2018, purchase obligations were $3,046 million, $219 million, and $256 million for Fiscal 2019, Fiscal 2020, and Fiscal 2021 and thereafter, respectively.

[0001571996-18-000004:notes:63]
Legal Matters

[0001571996-18-000004:notes:64]
The Company is involved in various claims, suits, assessments, investigations, and legal proceedings that arise from time to time in the ordinary course of its business, including those identified below, consisting of matters involving consumer, antitrust, tax, intellectual property, and other issues on a global basis.  The Company accrues a liability when it believes that it is both probable that a liability has been incurred and that it can reasonably estimate the amount of the loss.  The Company reviews these accruals at least quarterly and adjusts them to reflect ongoing negotiations, settlements, rulings, advice of legal counsel, and other relevant information.  To the extent new information is obtained and the Company's views on the probable outcomes of claims, suits, assessments, investigations, or legal proceedings change, changes in the Company's accrued liabilities would be recorded in the period in which such a determination is made.  For some matters, the amount of liability is not probable or the amount cannot be reasonably estimated and therefore accruals have not been made.  The following is a discussion of the Company's significant legal matters and other proceedings:

[0001571996-18-000004:notes:65]
EMC Merger Litigation — The Company, Dell, and Universal Acquisition Co. ("Universal") were named as defendants in fifteen putative class-action lawsuits brought by purported EMC shareholders and VMware, Inc. stockholders challenging the proposed merger between the Company, Dell, and Universal on the one hand, and EMC on the other (the "EMC merger").  Those suits are captioned as follows:

[0001571996-18-000004:notes:66]
| Case | Court | Filing Date |
| 1. | IBEW Local No. 129 Benefit Fund v. Tucci,Civ. No. 1584-3130-BLS1 | Mass. Superior Court, Suffolk County | 10/15/2015 |
| 2. | Barrett v. Tucci,Civ. No. 15-6023-A | Mass. Superior Court, Middlesex County | 10/16/2015 |
| 3. | Graulich v. Tucci,Civ. No. 1584-3169-BLS1 | Mass. Superior Court, Suffolk County | 10/19/2015 |
| 4. | Vassallo v. EMC Corp.,Civ. No. 1584-3173-BLS1 | Mass. Superior Court, Suffolk County | 10/19/2015 |
| 5. | City of Miami Police Relief & Pension Fund v. Tucci,Civ. No. 1584-3174-BLS1 | Mass. Superior Court, Suffolk County | 10/19/2015 |
| 6. | Lasker v. EMC Corp.,Civ. No. 1584-3214-BLS1 | Mass. Superior Court, Suffolk County | 10/23/2015 |
| 7. | Walsh v. EMC Corp.,Civ. No. 15-13654 | U.S. District Court,District of Massachusetts | 10/27/2015 |
| 8. | Local Union No. 373 U.A. Pension Plan v. EMC Corp.,Civ. No. 1584-3253-BLS1 | Mass. Superior Court, Suffolk County | 10/28/2015 |
| 9. | City of Lakeland Emps.' Pension & Ret. Fund v. Tucci,Civ. No. 1584-3269-BLS1 | Mass. Superior Court, Suffolk County | 10/28/2015 |
| 10. | Ma v. Tucci,Civ. No. 1584-3281-BLS1 | Mass. Superior Court, Suffolk County | 10/29/2015 |
| 11. | Stull v. EMC Corp.,Civ. No. 15-13692 | U.S. District Court,District of Massachusetts | 10/30/2015 |
| 12. | Jacobs v. EMC Corp.,Civ. No. 15-6318-H | Mass. Superior Court, Middlesex County | 11/12/2015 |
| 13. | Ford v. VMware, Inc.,C.A. No. 11714-VCL | Delaware Chancery Court | 11/17/2015 |
| 14. | Pancake v. EMC Corp.,Civ. No. 16-10040 | U.S. District Court,District of Massachusetts | 1/11/2016 |
| 15. | Booth Family Trust v. EMC Corp.,Civ. No. 16-10114 | U.S. District Court,District of Massachusetts | 1/26/2016 |

[0001571996-18-000004:notes:67]
The fifteen lawsuits sought, among other things, injunctive relief enjoining the EMC merger, rescission of the EMC merger if consummated, an award of fees and costs, and/or an award of damages.

[0001571996-18-000004:notes:68]
The complaints in the IBEW, Barrett, Graulich, Vassallo, City of Miami, Lasker, Local Union No. 373, City of Lakeland, and Ma actions generally allege that the EMC directors breached their fiduciary duties to EMC shareholders in connection with the EMC merger by, among other things, failing to maximize shareholder value and agreeing to provisions in the EMC merger agreement that discouraged competing bids.  After consolidating the fifteen complaints, by decision dated December 7, 2015, the Business Litigation Session of the Suffolk County Superior Court in Massachusetts dismissed all nine complaints for failure to make a demand on the EMC board of directors.  Three of the nine plaintiffs in the consolidated actions appealed the judgment dismissing their complaints.  The Massachusetts Supreme Judicial Court granted an application for direct appellate review, and heard oral argument on the appeal on November 7, 2016.  On March 6, 2017, the Supreme Judicial Court issued a decision affirming the dismissal.  This decision terminated the consolidated actions.

[0001571996-18-000004:notes:69]
The complaints in the Walsh, Stull, Pancake, and Booth actions allege that the EMC directors breached their fiduciary duties to EMC shareholders in connection with the EMC merger by, among other things, failing to maximize shareholder value and agreeing to provisions in the EMC merger agreement that discouraged competing bids.  The complaints generally further allege that the preliminary registration statement on Form S-4 filed by the Company on December 14, 2015, in connection with the transaction contained material misstatements and omissions, in violation of Section 14(a) of the Securities Exchange Act of 1934 (the "Exchange Act") and SEC Rule 14a-9 promulgated thereunder and that the Company, Dell, and Universal acted as controlling persons of EMC under Section 20(a) of the Exchange Act.  On June 6, 2016, the Securities and Exchange Commission declared effective the Company's registration statement on Form S-4 relating to the EMC merger (the "SEC Form S-4"), including the amendments thereto.  On June 17, 2016, the parties to the Walsh, Stull, Pancake, and Booth actions submitted to the Court a Stipulation and Proposed Order Dismissing Action and Retaining Jurisdiction to Determine Plaintiffs' Counsel's Application for an Award of Attorneys' Fees and Reimbursement of Expenses.  In the stipulation, the plaintiffs represented to the Court that they believe sufficient information had been disclosed to warrant dismissal of the actions as moot in light of the disclosures in the SEC Form S-4, including the amendments thereto.  On October 25, 2016, following an agreement between the parties with respect to payment of attorneys' fees and expenses, the Court entered an order terminating the four actions for all purposes.

[0001571996-18-000004:notes:70]
The amended complaints in the Jacobs and Ford actions allege that EMC, as the majority stockholder of VMware, Inc., and the individual defendants, who were directors of EMC, VMware, Inc., or both, breached their fiduciary duties to minority stockholders of VMware, Inc. in connection with the proposed EMC merger by allegedly entering into or approving a merger that favors the interests of EMC and Dell at the expense of the minority stockholders.  The plaintiffs in the Jacobs action also brought suit against the Company, Dell, and Universal as alleged aiders and abettors.  Effective December 2, 2016, the parties entered into an agreement to resolve the Jacobs action, pursuant to which the plaintiff voluntarily dismissed the action with prejudice.  Under the operative amended complaint in the Ford action, the plaintiffs also brought suit against the Company and Dell for alleged breach of fiduciary duties to VMware, Inc. and its stockholders, and against the Company, Dell, and Universal for aiding and abetting the alleged breach of fiduciary duties by EMC's and VMware, Inc.'s directors.  Certain defendants filed motions to dismiss the amended complaint on June 21, 2016.  A hearing on those motions was held on February 3, 2017.  On May 2, 2017, the Court dismissed the amended complaint for failure to state a claim upon which relief could be granted and no appeal was taken.  All fifteen EMC merger-related lawsuits are now fully and finally resolved.

[0001571996-18-000004:notes:71]
Appraisal Proceedings — On October 29, 2013, Dell Technologies acquired Dell in a transaction referred to as the going-private transaction.  Holders of shares of Dell common stock who did not vote on September 12, 2013 in favor of the proposal to adopt the amended going-private transaction agreement and who properly demanded appraisal of their shares and who otherwise comply with the requirements of Section 262 of the Delaware General Corporate Law ("DGCL") are entitled to seek appraisal for, and obtain payment in cash for the judicially determined "fair value" (as defined pursuant to Section 262 of the DGCL) of, their shares in lieu of receiving the going-private transaction consideration.  Dell initially recorded a liability of $13.75 for each share with respect to which appraisal has been demanded and as to which the demand has not been withdrawn, together with interest at the statutory rate discussed below.  This liability was approximately $129 million as of both February 2, 2018 and February 3, 2017.  The Court of Chancery ruled that the fair value of the appraisal shares as of October 29, 2013, the date on which the going-private transaction became effective, was $17.62 per share.  This ruling would entitle the holders of the remaining 5,505,630 shares subject to the appraisal proceedings to $17.62 per share, plus interest at a statutory rate, compounded quarterly.  On November 21, 2016, the Court of Chancery entered final judgment in the appraisal action.  On November 22, 2016, Dell filed a notice of appeal to the Delaware Supreme Court, which issued a decision on December 14, 2017.  In its decision, the Delaware Supreme Court reversed, in part, and affirmed, in part, the decision of the Delaware Court of Chancery.  On January 2, 2018, the Delaware Supreme Court issued its formal mandate remanding the matter to the Court of Chancery for further proceedings consistent with its opinion.  In accordance with direction by the Court of Chancery, the parties have submitted proposals to the Court of Chancery outlining the remaining issues to be adjudicated and a schedule for resolving those issues.  The Company believes it was adequately reserved for the appraisal proceedings as of February 2, 2018.

[0001571996-18-000004:notes:72]
Securities Litigation — On May 22, 2014, a securities class action seeking compensatory damages was filed in the United States District Court for the Southern District of New York, captioned the City of Pontiac Employee Retirement System vs. Dell Inc. et. al. (Case No. 1:14-cv-03644).  The action names as defendants Dell Inc. and certain current and former executive officers, and alleges that Dell made false and misleading statements about Dell's business operations and products between February 22, 2012 and May 22, 2012, which resulted in artificially inflated stock prices.  The case was transferred to the United States District Court for the Western District of Texas, where the defendants filed a motion to dismiss.  On September 16, 2016, the Court denied the motion to dismiss and the case is proceeding with discovery.  The defendants believe the claims asserted are without merit and the risk of material loss is remote.

[0001571996-18-000004:notes:73]
Copyright Levies — The Company's obligation to collect and remit copyright levies in certain European Union ("EU") countries may be affected by the resolution of legal proceedings pending in Germany and other EU member states against various companies, including Dell subsidiaries.  The plaintiffs in those proceedings generally seek to impose or modify the levies with respect to sales of such equipment as multifunction devices, phones, personal computers, storage devices, and printers, alleging that such products enable the copying of copyrighted materials.  Some of the proceedings also challenge whether the levy schemes in those countries comply with EU law.  Certain EU member countries that do not yet impose levies on digital devices are expected to implement legislation to enable them to extend existing levy schemes, while some other EU member countries are expected to limit the scope of levy schemes and their applicability in the digital hardware environment.  Dell, other companies, and various industry associations have opposed the extension of levies to the digital environment and have advocated alternative models of compensation to rights holders.  The Company continues to collect levies in certain EU countries where it has determined that based on local laws it is probable that it has a payment obligation.  The amount of levies is generally based on the number of products sold and the per-product amounts of the levies, which vary.  The Company accrues a liability when it believes that it is both probable that a loss has been incurred and when it can reasonably estimate the amount of the loss.

[0001571996-18-000004:notes:74]
Other Litigation — The various legal proceedings in which Dell is involved include commercial litigation and a variety of patent suits.  In some of these cases, Dell is the sole defendant.  More often, particularly in the patent suits, Dell is one of a number of defendants in the electronics and technology industries.  Dell is actively defending a number of patent infringement suits, and several pending claims are in various stages of evaluation.  While the number of patent cases varies over time, Dell does not currently anticipate that any of these matters will have a material adverse effect on its business, financial condition, results of operations, or cash flows.

[0001571996-18-000004:notes:75]
As of February 2, 2018, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for these or other proceedings or matters has been incurred.  However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company's business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters.  Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company's business, financial condition, results of operations, or cash flows will depend on a number of variables, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.

[0001571996-18-000004:notes:76]
Indemnifications

[0001571996-18-000004:notes:77]
In the ordinary course of business, the Company enters into contractual arrangements under which it may agree to indemnify the third party to such arrangements from any losses incurred relating to the services it performs on behalf of the Company or for losses arising from certain events as defined in the particular contract, such as litigation or claims relating to past performance.  Such indemnification obligations may not be subject to maximum loss clauses.  Historically, payments related to these indemnifications have not been material to the Company.

[0001571996-18-000004:notes:78]
In connection with the divestitures discussed in Note 4 of the Notes to the Consolidated Financial Statements, the Company has indemnified the purchasers of businesses for the occurrence of specified events.  The Company does not currently believe that contingent obligations to provide indemnification in connection with these divestitures will have a material adverse effect on the Company.

[0001571996-18-000004:notes:79]
Certain Concentrations

[0001571996-18-000004:notes:80]
The Company maintains cash and cash equivalents, derivatives, and certain other financial instruments with various financial institutions that potentially subject it to concentration of credit risk.  As part of its risk management processes, the Company performs periodic evaluations of the relative credit standing of these financial institutions.  The Company has not sustained material credit losses from instruments held at these financial institutions.  Further, the Company does not anticipate nonperformance by any of the counterparties.

[0001571996-18-000004:notes:81]
The Company markets and sells its products and services to large corporate clients, governments, and health care and education accounts, as well as to small and medium-sized businesses and individuals.  No single customer accounted for more than 10% of the Company's consolidated net revenue during the fiscal year ended February 2, 2018, February 3, 2017, or January 29, 2016.

[0001571996-18-000004:notes:82]
The Company utilizes a limited number of contract manufacturers who assemble a portion of its products.  The Company may purchase components from suppliers and sell those components to the contract manufacturers, thereby creating receivable balances from the contract manufacturers.  The agreements with the majority of the contract manufacturers allow the Company a legal right to offset its payables against these receivables, thus mitigating the credit risk wholly or in part.  Receivables from the Company's four largest contract manufacturers represented the majority of the gross non-trade receivables of $3.3 billion and $2.7 billion as of February 2, 2018 and February 3, 2017, respectively, of which $2.8 billion and $2.2 billion as of February 2, 2018 and February 3, 2017, respectively, have been offset against the corresponding payables.  The portion of receivables not offset against payables is included in other current assets in the Consolidated Statement of Financial Position.  The Company does not reflect the sale of the components in revenue and does not recognize any profit on the component sales until the related products are sold.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock

[0001571996-18-000004:notes:83]
The Company is subject to the possibility of various losses arising in the ordinary course of business.  The Company considers the likelihood of loss or impairment of an asset or the incurrence of a liability, as well as the Company's ability to reasonably estimate the amount of loss, in determining loss contingencies.  An estimated loss contingency is accrued when it is probable that an asset has been impaired or a liability has been incurred and the amount of loss can be reasonably estimated.  The Company regularly evaluates current information available to determine whether such accruals should be adjusted and whether new accruals are required.

[0001571996-18-000004:notes:84]
The Company accrues a liability when it believes that it is both probable that a liability has been incurred and that it can reasonably estimate the amount of the loss.  The Company reviews these accruals at least quarterly and adjusts them to reflect ongoing negotiations, settlements, rulings, advice of legal counsel, and other relevant information.  To the extent new information is obtained and the Company's views on the probable outcomes of claims, suits, assessments, investigations, or legal proceedings change, changes in the Company's accrued liabilities would be recorded in the period in which such a determination is made.  For some matters, the amount of liability is not probable or the amount cannot be reasonably estimated and therefore accruals have not been made.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001571996-18-000004:notes:85]
ACCUMULATED OTHER COMPREHENSIVE LOSS

[0001571996-18-000004:notes:86]
Accumulated other comprehensive loss is presented in stockholders' equity in the Consolidated Statements of Financial Position and consists of amounts related to foreign currency translation adjustments, unrealized net gains (losses) on investments, unrealized net gains (losses) on cash flow hedges, and actuarial net gains (losses) from pension and other postretirement plans.

[0001571996-18-000004:notes:87]
The following table presents changes in accumulated other comprehensive loss, net of tax, by the following components for the periods indicated:

[0001571996-18-000004:notes:88]
|  | Foreign Currency Translation Adjustments |  | Investments |  | Cash Flow Hedges |  | Pension and Other Postretirement Plans |  | Accumulated Other Comprehensive Loss |
|  | (in millions) |
| Balances as of January 30, 2015 | $ | (220 | ) |  | $ | — |  |  | $ | 249 |  |  | $ | — |  |  | $ | 29 |  |
| Other comprehensive income (loss) before reclassifications | (138 | ) |  | — |  |  | 152 |  |  | — |  |  | 14 |  |
| Amounts reclassified from accumulated other comprehensive loss | — |  |  | — |  |  | (367 | ) |  | — |  |  | (367 | ) |
| Total change for the period | (138 | ) |  | — |  |  | (215 | ) |  | — |  |  | (353 | ) |
| Balances as of January 29, 2016 | (358 | ) |  | — |  |  | 34 |  |  | — |  |  | (324 | ) |
| Other comprehensive income (loss) before reclassifications | (254 | ) |  | (17 | ) |  | 20 |  |  | 19 |  |  | (232 | ) |
| Amounts reclassified from accumulated other comprehensive loss | — |  |  | 1 |  |  | (43 | ) |  | — |  |  | (42 | ) |
| Total change for the period | (254 | ) |  | (16 | ) |  | (23 | ) |  | 19 |  |  | (274 | ) |
| Less: Change in comprehensive income (loss) attributable to non-controlling interests | — |  |  | (3 | ) |  | — |  |  | — |  |  | (3 | ) |
| Balances as of February 3, 2017 | (612 | ) |  | (13 | ) |  | 11 |  |  | 19 |  |  | (595 | ) |
| Other comprehensive income (loss) before reclassifications | 791 |  |  | 31 |  |  | (248 | ) |  | 13 |  |  | 587 |  |
| Amounts reclassified from accumulated other comprehensive loss | — |  |  | 2 |  |  | 134 |  |  | — |  |  | 136 |  |
| Total change for the period | 791 |  |  | 33 |  |  | (114 | ) |  | 13 |  |  | 723 |  |
| Less: Change in comprehensive loss attributable to non-controlling interests | — |  |  | (2 | ) |  | — |  |  | — |  |  | (2 | ) |
| Balances as of February 2, 2018 | $ | 179 |  |  | $ | 22 |  |  | $ | (103 | ) |  | $ | 32 |  |  | $ | 130 |  |

[0001571996-18-000004:notes:89]
Amounts related to investments are reclassified to net income when gains and losses are realized.  See Note 5 and Note 6 of the Notes to the Consolidated Financial Statements for more information on the Company's investments.  Amounts related to the Company's cash flow hedges are reclassified to net income during the same period in which the items being hedged are recognized in earnings.  In addition, any hedge ineffectiveness related to cash flow hedges is recognized currently in net income.  See Note 9 of the Notes to the Consolidated Financial Statements for more information on the Company's derivative instruments.

[0001571996-18-000004:notes:90]
The following table presents reclassifications out of accumulated other comprehensive loss, net of tax, to net income (loss) for the periods presented:

[0001571996-18-000004:notes:91]
|  | Fiscal Year Ended |
|  | February 2, 2018 |  | February 3, 2017 |
|  | Investments |  | Cash Flow Hedges |  | Total |  | Investments |  | Cash Flow Hedges |  | Total |
|  | (in millions) |
| Total reclassifications, net of tax: |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue | $ | — |  |  | $ | (77 | ) |  | $ | (77 | ) |  | $ | — |  |  | $ | 57 |  |  | $ | 57 |  |
| Cost of net revenue | — |  |  | (57 | ) |  | (57 | ) |  | — |  |  | (13 | ) |  | (13 | ) |
| Interest and other, net | (2 | ) |  | — |  |  | (2 | ) |  | (1 | ) |  | (1 | ) |  | (2 | ) |
| Total reclassifications, net of tax | $ | (2 | ) |  | $ | (134 | ) |  | $ | (136 | ) |  | $ | (1 | ) |  | $ | 43 |  |  | $ | 42 |  |


## us-gaap:CondensedFinancialInformationOfParentCompanyOnlyDisclosureTextBlock

[0001571996-18-000004:notes:92]
SUPPLEMENTAL CONSOLIDATED FINANCIAL INFORMATION

[0001571996-18-000004:notes:93]
The following table provides additional information on selected accounts included in the Consolidated Statements of Financial Position as of February 2, 2018 and February 3, 2017:

[0001571996-18-000004:notes:94]
|  | February 2, 2018 |  | February 3, 2017 |
|  | (in millions) |
| Accounts receivable, net: |  |  |  |
| Gross accounts receivable | $ | 11,575 |  |  | $ | 9,770 |  |
| Allowance for doubtful accounts | (103 | ) |  | (57 | ) |
| Allowance for customer returns | (295 | ) |  | (293 | ) |
| Total accounts receivable, net | $ | 11,177 |  |  | $ | 9,420 |  |
| Inventories, net: |  |  |  |
| Production materials | $ | 967 |  |  | $ | 925 |  |
| Work-in-process | 514 |  |  | 503 |  |
| Finished goods | 1,197 |  |  | 1,110 |  |
| Total inventories, net | $ | 2,678 |  |  | $ | 2,538 |  |
| Prepaid expenses (a) |  |  |  |
| Total prepaid expenses | $ | 1,016 |  |  | $ | 850 |  |
| Property, plant, and equipment, net: |  |  |  |
| Computer equipment | $ | 5,085 |  |  | $ | 5,045 |  |
| Land and buildings | 4,343 |  |  | 4,299 |  |
| Machinery and other equipment | 3,845 |  |  | 3,770 |  |
| Total property, plant, and equipment | 13,273 |  |  | 13,114 |  |
| Accumulated depreciation and amortization (b) | (7,883 | ) |  | (7,461 | ) |
| Total property, plant, and equipment, net | $ | 5,390 |  |  | $ | 5,653 |  |
| Accrued and other current liabilities: |  |  |  |
| Compensation | $ | 2,948 |  |  | $ | 2,641 |  |
| Warranty liability | 367 |  |  | 405 |  |
| Income and other taxes | 1,229 |  |  | 943 |  |
| Other | 3,117 |  |  | 3,130 |  |
| Total accrued and other current liabilities | $ | 7,661 |  |  | $ | 7,119 |  |
| Other non-current liabilities: |  |  |  |
| Warranty liability | $ | 172 |  |  | $ | 199 |  |
| Deferred and other tax liabilities | 6,110 |  |  | 8,607 |  |
| Other | 515 |  |  | 533 |  |
| Total other non-current liabilities | $ | 6,797 |  |  | $ | 9,339 |  |

[0001571996-18-000004:notes:95]
| (a) | Prepaid expenses are included in other current assets in the Consolidated Statements of Financial Position. |

[0001571996-18-000004:notes:96]
| (b) | During the fiscal years ended February 2, 2018, February 3, 2017, and January 29, 2016, the Company recognized $1.5 billion, $1.2 billion, and $0.5 billion, respectively, in depreciation expense. Additionally, during the fiscal year ended February 2, 2018, the Company retired $1.1 billion of fully depreciated property, plant, and equipment. |

[0001571996-18-000004:notes:97]
Additional Consolidated Statements of Income (Loss) Information

[0001571996-18-000004:notes:98]
The table below provides details of interest and other, net for the fiscal years ended February 2, 2018, February 3, 2017, and January 29, 2016:

[0001571996-18-000004:notes:99]
|  | Fiscal Year Ended |
|  | February 2, 2018 |  | February 3, 2017 |  | January 29, 2016 |
|  | (in millions) |
| Interest and other, net: |  |  |  |  |  |
| Investment income, primarily interest | $ | 207 |  |  | $ | 102 |  |  | $ | 39 |  |
| Gain (loss) on investments, net | 72 |  |  | 4 |  |  | (2 | ) |
| Interest expense | (2,406 | ) |  | (1,751 | ) |  | (680 | ) |
| Foreign exchange | (113 | ) |  | (77 | ) |  | (107 | ) |
| Debt extinguishment | — |  |  | (337 | ) |  | — |  |
| Other | (115 | ) |  | (45 | ) |  | (22 | ) |
| Total interest and other, net | $ | (2,355 | ) |  | $ | (2,104 | ) |  | $ | (772 | ) |

[0001571996-18-000004:notes:100]
Condensed Financial Information of Parent Company

[0001571996-18-000004:notes:101]
Dell Technologies Inc. has no material assets or standalone operations other than its ownership in its consolidated subsidiaries. There are restrictions under credit agreements and indentures governing the First Lien Notes and the Senior Notes on the Company's ability to obtain funds from any of its subsidiaries through dividends, loans, or advances.  As of February 2, 2018, the Company had certain consolidated subsidiaries that were designated as unrestricted subsidiaries for all purposes of the applicable credit agreements and such indentures.  As of February 2, 2018, substantially all of the net assets of the Company's consolidated subsidiaries were restricted, with the exception of the Company's unrestricted subsidiaries, primarily VMware, Inc., SecureWorks, Pivotal, and their respective subsidiaries.  Accordingly, this condensed financial information is presented on a "Parent-only" basis.  Under a Parent-only presentation, Dell Technologies Inc.'s investments in its consolidated subsidiaries are presented under the equity method of accounting.

[0001571996-18-000004:notes:102]
The following table presents the financial position of Dell Technologies Inc. (Parent) as of February 2, 2018 and February 3, 2017:

[0001571996-18-000004:notes:103]
| Dell Technologies Inc. (Parent) | February 2, 2018 |  | February 3, 2017 |
|  | (in millions) |
| Assets: |  |  |  |
| Cash and cash equivalents | $ | — |  |  | $ | 123 |  |
| Other current assets | 1 |  |  | — |  |
| Investments in subsidiaries | 9,735 |  |  | 13,412 |  |
| Other non-current assets | — |  |  | 4 |  |
| Total assets | 9,736 |  |  | 13,539 |  |
| Long-term debt (a) | 26 |  |  | 26 |  |
| Accrued and other | — |  |  | 39 |  |
| Redeemable shares | 384 |  |  | 231 |  |
| Stockholders' equity: |  |  |  |
| Common stock and capital in excess of $.01 par value | 18,449 |  |  | 19,447 |  |
| Retained earnings (deficit) | (9,253 | ) |  | (5,609 | ) |
| Accumulated other comprehensive income (loss) | 130 |  |  | (595 | ) |
| Total stockholders' equity | 9,326 |  |  | 13,243 |  |
| Total liabilities, redeemable shares, and stockholders' equity | $ | 9,736 |  |  | $ | 13,539 |  |

[0001571996-18-000004:notes:104]
| (a) | In connection with the acquisition of Dell by Dell Technologies Inc. in the going-private transaction, Dell Technologies Inc. issued a $2.0 billion subordinated note to Microsoft Global Finance, a subsidiary of Microsoft Corporation. As of February 2, 2018 and February 3, 2017, the outstanding principal amount of the Microsoft Note was $26 million, payable at maturity in October 2023. |

[0001571996-18-000004:notes:105]
The following table presents the cash flows of Dell Technologies Inc. (Parent) for the fiscal years ended February 2, 2018, February 3, 2017, and January 29, 2016.

[0001571996-18-000004:notes:106]
|  | Fiscal Year Ended |
| Dell Technologies Inc. (Parent) | February 2, 2018 |  | February 3, 2017 |  | January 29, 2016 |
|  | (in millions) |
| Change in cash from operating activities | $ | (2 | ) |  | $ | (2 | ) |  | $ | (2 | ) |
| Cash flow from investing activities: |  |  |  |  |  |
| Transfer to/from subsidiary | 640 |  |  | 35,941 |  |  | 2 |  |
| Acquisition of business, net of cash acquired | — |  |  | (39,521 | ) |  | — |  |
| Change in cash from investing activities | 640 |  |  | (3,580 | ) |  | 2 |  |
| Cash flow from financing activities: |  |  |  |  |  |
| Proceeds from the issuance of DHI Group Common Stock | — |  |  | 4,422 |  |  | — |  |
| Shares repurchased for tax withholdings of equity awards | (33 | ) |  | (6 | ) |  | (2 | ) |
| Repurchases of DHI Group Common Stock | (6 | ) |  | (10 | ) |  | — |  |
| Repurchases of Class V Common Stock | (723 | ) |  | (701 | ) |  | — |  |
| Other | 1 |  |  | — |  |  | 2 |  |
| Change in cash from financing activities | (761 | ) |  | 3,705 |  |  | — |  |
| Change in cash and cash equivalents | (123 | ) |  | 123 |  |  | — |  |
| Cash and cash equivalents at beginning of the period | 123 |  |  | — |  |  | — |  |
| Cash and cash equivalents at end of the period | $ | — |  |  | $ | 123 |  |  | $ | — |  |


## us-gaap:ConsolidationLessThanWhollyOwnedSubsidiaryParentOwnershipInterestEffectsOfChangesNetTextBlock

[0001571996-18-000004:notes:107]
The effect of changes in the Company's ownership interest in VMware, Inc., SecureWorks, and Pivotal on the Company's equity was as follows:

[0001571996-18-000004:notes:108]
|  | Fiscal Year Ended |
|  | February 2, 2018 |
|  | (in millions) |
| Net loss attributable to Dell Technologies Inc. | $ | (3,728 | ) |
| Transfers (to) from the non-controlling interests: |  |
| Increase in Dell Technologies Inc. additional paid-in-capital for equity issuances and other equity activity | 620 |  |
| Decrease in Dell Technologies Inc. additional paid-in-capital for equity issuances and other equity activity | (855 | ) |
| Net transfers to non-controlling interests | (235 | ) |
| Change from net loss attributable to Dell Technologies Inc. and transfers to/from the non-controlling interests | $ | (3,963 | ) |


## us-gaap:ConsolidationPolicyTextBlock

[0001571996-18-000004:notes:109]
These consolidated financial statements include the accounts of Dell Technologies and its wholly-owned subsidiaries, as well as the accounts of SecureWorks Corp. (“SecureWorks"), VMware, Inc., and Pivotal Software, Inc. ("Pivotal"), companies which are majority-owned by Dell Technologies.  All intercompany transactions have been eliminated.


## us-gaap:DebtDisclosureTextBlock

[0001571996-18-000004:notes:110]
DEBT

[0001571996-18-000004:notes:111]
The following table summarizes the Company's outstanding debt as of the dates indicated:

[0001571996-18-000004:notes:112]
|  | February 2, 2018 |  | February 3, 2017 |
|  | (in millions) |
| Secured Debt |  |  |  |
| Senior Secured Credit Facilities: |  |  |  |
| 3.58% Term Loan B Facility due September 2023 | $ | 4,988 |  |  | $ | 4,987 |  |
| Term Loan A-1 Facility due December 2018 | — |  |  | 600 |  |
| 3.33% Term Loan A-2 Facility due September 2021 | 4,394 |  |  | 3,876 |  |
| 3.08% Term Loan A-3 Facility due December 2018 | 1,213 |  |  | 1,800 |  |
| 3.33% Revolving Credit Facility due September 2021 | — |  |  | 375 |  |
| First Lien Notes: |  |  |  |
| 3.48% due June 2019 | 3,750 |  |  | 3,750 |  |
| 4.42% due June 2021 | 4,500 |  |  | 4,500 |  |
| 5.45% due June 2023 | 3,750 |  |  | 3,750 |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 8.10% due July 2036 | 1,500 |  |  | 1,500 |  |
| 8.35% due July 2046 | 2,000 |  |  | 2,000 |  |
| Unsecured Debt |  |  |  |
| Unsecured Notes and Debentures: |  |  |  |
| 5.65% due April 2018 | 500 |  |  | 500 |  |
| 5.875% due June 2019 | 600 |  |  | 600 |  |
| 4.625% due April 2021 | 400 |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 265 |  |
| Senior Notes: |  |  |  |
| 5.875% due June 2021 | 1,625 |  |  | 1,625 |  |
| 7.125% due June 2024 | 1,625 |  |  | 1,625 |  |
| EMC Notes: |  |  |  |
| 1.875% due June 2018 | 2,500 |  |  | 2,500 |  |
| 2.650% due June 2020 | 2,000 |  |  | 2,000 |  |
| 3.375% due June 2023 | 1,000 |  |  | 1,000 |  |
| VMware Notes: |  |  |  |
| 2.30% due August 2020 | 1,250 |  |  | — |  |
| 2.95% due August 2022 | 1,500 |  |  | — |  |
| 3.90% due August 2027 | 1,250 |  |  | — |  |
| DFS Debt (Note 7) | 4,796 |  |  | 3,464 |  |
| Other |  |  |  |
| 4.02% Margin Loan Facility due April 2022 | 2,000 |  |  | — |  |
| Margin Bridge Facility due September 2017 | — |  |  | 2,500 |  |
| VMware Note Bridge Facility due September 2017 | — |  |  | 1,500 |  |
| Other | 101 |  |  | 51 |  |
| Total debt, principal amount | $ | 52,694 |  |  | $ | 50,356 |  |

[0001571996-18-000004:notes:113]
|  | February 2, 2018 |  | February 3, 2017 |
|  | (in millions) |
| Total debt, principal amount | $ | 52,694 |  |  | $ | 50,356 |  |
| Unamortized discount, net of unamortized premium | (266 | ) |  | (284 | ) |
| Debt issuance costs | (557 | ) |  | (682 | ) |
| Total debt, carrying value | $ | 51,871 |  |  | $ | 49,390 |  |
| Total short-term debt, carrying value | $ | 7,873 |  |  | $ | 6,329 |  |
| Total long-term debt, carrying value | $ | 43,998 |  |  | $ | 43,061 |  |

[0001571996-18-000004:notes:114]
During the fiscal year ended February 2, 2018, the Company completed two refinancing transactions of the Senior Secured Credit Facilities described below.  In the first refinancing transaction, which occurred during the three months ended May 5, 2017, the Company refinanced the Term Loan B Facility to reduce the interest rate margin by 0.75% and to increase the outstanding principal amount by $500 million.  The Company applied the proceeds from the Term Loan B Facility refinancing to repay $500 million principal amount of the Margin Bridge Facility, without premium or penalty, and accrued and unpaid interest thereon.  Additionally, during the three months ended May 5, 2017, the Company entered into the Margin Loan Facility in the principal amount of $2.0 billion, and used the proceeds of the new facility to repay the Margin Bridge Facility, without premium or penalty.

[0001571996-18-000004:notes:115]
In the second refinancing transaction, which occurred during the three months ended November 3, 2017, the Company refinanced the Term Loan A-2 Facility, Term Loan A-3 Facility, Term Loan B Facility, and the Revolving Credit Facility.  As a result, the interest rate margin decreased 0.50% for each of the Term Loan A-2 Facility, Term Loan A-3 Facility, Term Loan B Facility, and the Revolving Credit Facility.  Additionally, the outstanding principal amount of the Term Loan A-2 Facility increased by $672 million, which was used to pay $212 million principal amount of the Term Loan A-3 Facility and $460 million principal amount of the Term Loan B Facility.  Further, the Revolving Credit Facility's borrowing capacity increased $180 million to $3.3 billion.

[0001571996-18-000004:notes:116]
During the fiscal year ended February 2, 2018, the Company repaid approximately $1.2 billion principal amount of its term loan facilities and $0.4 billion under the Revolving Credit Facility and issued an additional $1.3 billion, net, in DFS debt to support the expansion of its financing receivables portfolio.

[0001571996-18-000004:notes:117]
Further, during the fiscal year ended February 2, 2018, VMware, Inc. completed a public offering of senior notes in the aggregate amount of $4.0 billion.  VMware, Inc. used a portion of the net proceeds from the offering to repay certain intercompany promissory notes previously issued by it to EMC in the aggregate principal amount of $1.2 billion.  The Company applied the proceeds of this repayment, and other cash, to repay $1.5 billion principal amount of the VMware Note Bridge Facility, without premium or penalty.

[0001571996-18-000004:notes:118]
Secured Debt

[0001571996-18-000004:notes:119]
Senior Secured Credit Facilities — At the closing of the EMC merger transaction on September 7, 2016, the Company entered into a credit agreement that provides for senior secured credit facilities (the "Senior Secured Credit Facilities") in the aggregate principal amount of $17.6 billion comprising (a) term loan facilities and (b) a senior secured Revolving Credit Facility, which includes capacity for up to $0.5 billion of letters of credit and for borrowings of up to $0.4 billion under swing-line loans.  As of February 2, 2018, available borrowings under the Revolving Credit Facility totaled $3.3 billion.  The Senior Secured Credit Facilities provide that the borrowers have the right at any time, subject to customary conditions, to request incremental term loans or incremental revolving commitments.

[0001571996-18-000004:notes:120]
Borrowings under the Senior Secured Credit Facilities bear interest at a rate per annum equal to an applicable margin, plus, at the borrowers' option, either (a) a base rate, which, under the Term Loan B Facility, is subject to an interest rate floor of 1.75% per annum, and under all other borrowings is subject to an interest rate floor of 0% per annum, or (b) a London interbank offered rate ("LIBOR"), which, under the Term Loan B Facility, is subject to an interest rate floor of 0.75% per annum, and under all other borrowings is subject to an interest rate floor of 0% per annum.  Interest is payable, in the case of loans bearing interest based on LIBOR, at the end of each interest period (but at least every three months), in arrears and, in the case of loans bearing interest based on the base rate, quarterly in arrears.

[0001571996-18-000004:notes:121]
The Term Loan A-2 Facility amortizes in equal quarterly installments in aggregate annual amounts equal to 5% of the original principal amount in the first year after the closing date of the refinancing transaction on October 20, 2017, 10% of the original principal amount in each of the second and third years after October 20, 2017, and 70% of the original principal amount in the fourth year after October 20, 2017.  The Term Loan B Facility amortizes in equal quarterly installments in aggregate annual amounts equal to 1% of the original principal amount.  The Term Loan A-3 Facility and the Revolving Credit Facility have no amortization.  The Term Loan A-3 Facility requires the borrowers to prepay outstanding borrowings under these facilities with 100% of the net cash proceeds of certain non-ordinary course asset sales or dispositions.  The borrowers may voluntarily repay outstanding loans under the term loan facilities and the Revolving Credit Facility at any time without premium or penalty, other than customary "breakage" costs.

[0001571996-18-000004:notes:122]
All obligations of the borrowers under the Senior Secured Credit Facilities and certain swap agreements, cash management arrangements, and certain letters of credit provided by any lender or agent party to the Senior Secured Credit Facilities or any of its affiliates and certain other persons are secured by (a) a first-priority security interest in certain tangible and intangible assets of the borrowers and the guarantors and (b) a first-priority pledge of 100% of the capital stock of the borrowers, Dell Inc., and each wholly-owned material restricted subsidiary of the borrowers and the guarantors, in each case subject to certain thresholds, exceptions, and permitted liens.

[0001571996-18-000004:notes:123]
First Lien Notes — The senior secured notes (collectively, the "First Lien Notes") were issued on June 1, 2016 in an aggregate principal amount of $20.0 billion.  Interest on these borrowings is payable semiannually.  The First Lien Notes are secured, on a pari passu basis with the Senior Secured Credit Facilities, on a first-priority basis by substantially all of the tangible and intangible assets of the issuers and guarantors that secure obligations under the Senior Secured Credit Facilities, including pledges of all capital stock of the issuers, of Dell, and of certain wholly-owned material subsidiaries of the issuers and the guarantors, subject to certain exceptions.

[0001571996-18-000004:notes:124]
The Company has agreed to use commercially reasonable efforts to register with the SEC notes having terms substantially identical to the terms of the First Lien Notes as part of an offer to exchange such registered notes for the First Lien Notes.  The Company will be obligated to pay additional interest on the First Lien Notes if it fails to consummate such an exchange offer within five years after the closing date of the EMC merger transaction.

[0001571996-18-000004:notes:125]
China Revolving Credit Facility — On October 31, 2017, the Company entered into a credit agreement (the "China Revolving Credit Facility") with a bank lender for a secured revolving loan facility in an aggregate principal amount not to exceed $500 million.  Borrowings under the China Revolving Credit Facility bear interest at a rate per annum of 0.6% plus LIBOR.  The Company may voluntarily repay outstanding loans under the China Revolving Credit Facility at any time without premium or penalty, other than customary "breakage" costs.  The facility will expire on October 31, 2018.  As of February 2, 2018, there were no outstanding borrowings under the China Revolving Credit Facility.

[0001571996-18-000004:notes:126]
Unsecured Debt

[0001571996-18-000004:notes:127]
Unsecured Notes and Debentures — The Company has outstanding unsecured notes and debentures (collectively, the "Unsecured Notes and Debentures") that were issued prior to the acquisition of Dell by Dell Technologies Inc. in the going-private transaction.  Interest on these borrowings is payable semiannually.

[0001571996-18-000004:notes:128]
Senior Notes — The senior unsecured notes (collectively, the "Senior Notes") were issued on June 22, 2016 in an aggregate principal amount of $3.25 billion.  Interest on these borrowings is payable semiannually.

[0001571996-18-000004:notes:129]
EMC Notes — On September 7, 2016, EMC had outstanding $2.5 billion aggregate principal amount of its 1.875% Notes due June 2018, $2.0 billion aggregate principal amount of its 2.650% Notes due June 2020, and $1.0 billion aggregate principal amount of its 3.375% Notes due June 2023 (collectively, the "EMC Notes").  Interest on these borrowings is payable semiannually.  The EMC Notes remain outstanding following the closing of the EMC merger transaction.

[0001571996-18-000004:notes:130]
VMware Notes — On August 21, 2017, VMware, Inc. completed a public offering of senior notes in the aggregate amount of $4.0 billion, consisting of outstanding principal due on the following dates: $1.25 billion due August 21, 2020, $1.50 billion due August 21, 2022, and $1.25 billion due August 21, 2027 (collectively, the "VMware Notes").  The VMware Notes bear interest, payable semiannually, at annual rates of 2.30%, 2.95%, and 3.90%, respectively.  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.

[0001571996-18-000004:notes:131]
VMware Revolving Credit Facility —  On September 12, 2017, VMware, Inc. entered into an unsecured credit agreement, establishing a revolving credit facility (the “VMware Revolving Credit Facility”), with a syndicate of lenders that provides the company with a borrowing capacity of up to $1.0 billion which may be used for VMware, Inc. corporate purposes.  Commitments under the VMware Revolving Credit Facility are available for a period of five years, which may be extended, subject to the satisfaction of certain conditions, by up to two one year periods.  The credit agreement contains certain representations, warranties, and covenants.  Commitment fees, interest rates, and other terms of borrowings under the VMware Revolving Credit Facility may vary based on VMware, Inc.’s external credit ratings.  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.  As of February 2, 2018, there were no outstanding borrowings under the VMware Revolving Credit Facility.

[0001571996-18-000004:notes:132]
DFS Debt

[0001571996-18-000004:notes:133]
See Note 7 and Note 9 of the Notes to the Consolidated Financial Statements, respectively, for discussion of DFS debt and the interest rate swap agreements that hedge a portion of that debt.

[0001571996-18-000004:notes:134]
Other

[0001571996-18-000004:notes:135]
Margin Loan Facility — On April 12, 2017, the Company entered into the Margin Loan Facility in an aggregate principal amount of $2.0 billion.  VMW Holdco LLC, a wholly-owned subsidiary of EMC, is the borrower under the Margin Loan Facility, which is secured by 60 million shares of Class B common stock of VMware, Inc. and 20 million shares of Class A common stock of VMware, Inc.  Loans under the Margin Loan Facility bear interest at a rate per annum payable, at the borrower's option, either at (a) a base rate plus 1.25% per annum or (b) a LIBOR-based rate plus 2.25% per annum.  Interest under the Margin Loan Facility is payable quarterly.

[0001571996-18-000004:notes:136]
The Margin Loan Facility will mature in April 2022.  The borrower may voluntarily repay outstanding loans under the Margin Loan Facility at any time without premium or penalty, other than customary "breakage" costs, subject to certain minimum threshold amounts for prepayment.

[0001571996-18-000004:notes:137]
Margin Bridge Facility — On September 7, 2016, Merger Sub and EMC entered into a credit agreement providing for a senior secured margin bridge facility in an aggregate principal amount of $2.5 billion (the "Margin Bridge Facility").

[0001571996-18-000004:notes:138]
As described above, during the three months ended May 5, 2017, the Company separately applied the proceeds from the Term Loan B Facility refinancing and the issuance of the Margin Loan Facility to repay the Margin Bridge Facility, without premium or penalty.

[0001571996-18-000004:notes:139]
VMware Note Bridge Facility — On September 7, 2016, Merger Sub and EMC entered into a credit agreement providing for a senior secured note bridge facility in an aggregate principal amount of $1.5 billion (the "VMware Note Bridge Facility").  As described above, the Company repaid the VMware Note Bridge Facility during the fiscal year ended February 2, 2018.

[0001571996-18-000004:notes:140]
Pivotal Revolving Credit Facility — On September 7, 2017, Pivotal entered into a credit agreement (the "Pivotal Revolving Credit Facility") that provides for a senior secured revolving loan facility in an aggregate principal amount not to exceed $100 million.  The credit facility contains customary representations, warranties, and covenants, including financial covenants. The credit agreement will expire on September 8, 2020, unless it is terminated earlier.  None of the net proceeds of borrowings under the facility will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of Pivotal and Pivotal's subsidiaries.  As of February 2, 2018, outstanding borrowings under the Pivotal Revolving Credit Facility were $20 million.

[0001571996-18-000004:notes:141]
Aggregate Future Maturities

[0001571996-18-000004:notes:142]
As of February 2, 2018, aggregate future maturities of the Company's debt were as follows:

[0001571996-18-000004:notes:143]
|  | Maturities by Fiscal Year |
|  | 2019 |  | 2020 |  | 2021 |  | 2022 |  | 2023 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Secured Credit Facilities and First Lien Notes | $ | 1,541 |  |  | $ | 4,245 |  |  | $ | 371 |  |  | $ | 7,888 |  |  | $ | 63 |  |  | $ | 16,487 |  |  | $ | 30,595 |  |
| Unsecured Notes and Debentures | 500 |  |  | 600 |  |  | — |  |  | 400 |  |  | — |  |  | 952 |  |  | 2,452 |  |
| Senior Notes and EMC Notes | 2,500 |  |  | — |  |  | 2,000 |  |  | 1,625 |  |  | — |  |  | 2,625 |  |  | 8,750 |  |
| VMware Notes | — |  |  | — |  |  | 1,250 |  |  | — |  |  | 1,500 |  |  | 1,250 |  |  | 4,000 |  |
| DFS Debt | 3,328 |  |  | 847 |  |  | 530 |  |  | 82 |  |  | 9 |  |  | — |  |  | 4,796 |  |
| Margin Loan Facility | — |  |  | — |  |  | — |  |  | — |  |  | 2,000 |  |  | — |  |  | 2,000 |  |
| Other | 19 |  |  | — |  |  | 56 |  |  | — |  |  | — |  |  | 26 |  |  | 101 |  |
| Total maturities, principal amount | 7,888 |  |  | 5,692 |  |  | 4,207 |  |  | 9,995 |  |  | 3,572 |  |  | 21,340 |  |  | 52,694 |  |
| Associated carrying value adjustments | (14 | ) |  | (32 | ) |  | (8 | ) |  | (192 | ) |  | (30 | ) |  | (547 | ) |  | (823 | ) |
| Total maturities, carrying value amount | $ | 7,874 |  |  | $ | 5,660 |  |  | $ | 4,199 |  |  | $ | 9,803 |  |  | $ | 3,542 |  |  | $ | 20,793 |  |  | $ | 51,871 |  |

[0001571996-18-000004:notes:144]
Covenants and Unrestricted Net Assets — The credit agreement for the Senior Secured Credit Facilities contain customary negative covenants that generally limit the ability of Denali Intermediate Inc., a wholly-owned subsidiary of Dell Technologies ("Dell Intermediate"), Dell, and Dell's and Denali Intermediate's other restricted subsidiaries to incur debt, create liens, make fundamental changes, enter into asset sales, make certain investments, pay dividends or distribute or redeem certain equity interests, prepay or redeem certain debt, and enter into certain transactions with affiliates.  The indenture governing the Senior Notes contains customary negative covenants that generally limit the ability of Denali Intermediate, Dell, and Dell's and Denali Intermediate's other restricted subsidiaries to incur additional debt or issue certain preferred shares, pay dividends on or make other distributions in respect of capital stock or make other restricted payments, make certain investments, sell or transfer certain assets, create liens on certain assets to secure debt, consolidate, merge, sell, or otherwise dispose of all or substantially all assets, enter into certain transactions with affiliates, and designate subsidiaries as unrestricted subsidiaries.  The negative covenants under such credit agreements and indenture are subject to certain exceptions, qualifications, and "baskets."  The indentures governing the First Lien Notes, the Unsecured Notes and Debentures, and the EMC Notes variously impose limitations, subject to specified exceptions, on creating certain liens, entering into sale and lease-back transactions, and entering into certain asset sales.  The foregoing credit agreements and indentures contain customary events of default, including failure to make required payments, failure to comply with covenants, and the occurrence of certain events of bankruptcy and insolvency.

[0001571996-18-000004:notes:145]
As of February 2, 2018, the Company had certain consolidated subsidiaries that were designated as unrestricted subsidiaries for all purposes of the applicable credit agreements and the indentures governing the First Lien Notes and the Senior Notes.  Substantially all of the net assets of the Company's consolidated subsidiaries were restricted, with the exception of the Company's unrestricted subsidiaries, primarily VMware Inc., SecureWorks, Pivotal, and their respective subsidiaries, as of February 2, 2018.

[0001571996-18-000004:notes:146]
The Term Loan A-2 Facility, the Term Loan A-3 Facility, and the Revolving Credit Facility are subject to a first lien net leverage ratio covenant that is tested at the end of each fiscal quarter of Dell with respect to Dell's preceding four fiscal quarters.  The Company was in compliance with all financial covenants as of February 2, 2018.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001571996-18-000004:notes:147]
DERIVATIVE INSTRUMENTS AND HEDGING ACTIVITIES

[0001571996-18-000004:notes:148]
Derivative Instruments

[0001571996-18-000004:notes:149]
As part of its risk management strategy, the Company uses derivative instruments, primarily foreign currency forward and option contracts and interest rate swaps, to hedge certain foreign currency and interest rate exposures, respectively.

[0001571996-18-000004:notes:150]
The Company's objective is to offset gains and losses resulting from these exposures with gains and losses on the derivative contracts used to hedge the exposures, thereby reducing volatility of earnings and protecting the fair values of assets and liabilities.  For derivatives designated as cash flow hedges, the Company assesses hedge effectiveness both at the onset of the hedge and at regular intervals throughout the life of the derivative and recognizes any ineffective portion of the hedge in earnings as a component of interest and other, net.  Hedge ineffectiveness recognized in earnings was not material during the fiscal years ended February 2, 2018, February 3, 2017, and January 29, 2016.

[0001571996-18-000004:notes:151]
Foreign Exchange Risk

[0001571996-18-000004:notes:152]
The Company uses foreign currency forward and option contracts designated as cash flow hedges to protect against the foreign currency exchange rate risks inherent in its forecasted transactions denominated in currencies other than the U.S. dollar.  Hedge accounting is applied based upon the criteria established by accounting guidance for derivative instruments and hedging activities.  The risk of loss associated with purchased options is limited to premium amounts paid for the option contracts.  The risk of loss associated with forward contracts is equal to the exchange rate differential from the time the contract is entered into until the time it is settled.  The majority of these contracts typically expire in twelve months or less.

[0001571996-18-000004:notes:153]
During the fiscal years ended February 2, 2018, February 3, 2017, and January 29, 2016, the Company did not discontinue any cash flow hedges related to foreign exchange contracts that had a material impact on the Company's results of operations due to the probability that the forecasted cash flows would not occur.

[0001571996-18-000004:notes:154]
The Company uses forward contracts to hedge monetary assets and liabilities denominated in a foreign currency.  These contracts generally expire in three months or less, are considered economic hedges, and are not designated for hedge accounting.  The change in the fair value of these instruments represents a natural hedge as their gains and losses offset the changes in the underlying fair value of the monetary assets and liabilities due to movements in currency exchange rates.

[0001571996-18-000004:notes:155]
In connection with the expanded offerings of DFS in Europe, forward contracts are used to hedge financing receivables denominated in foreign currencies.  These contracts are not designated for hedge accounting and most expire within three years or less.

[0001571996-18-000004:notes:156]
Interest Rate Risk

[0001571996-18-000004:notes:157]
The Company uses interest rate swaps to hedge the variability in cash flows related to the interest rate payments on structured financing debt.  The interest rate swaps economically convert the variable rate on the structured financing debt to a fixed interest rate to match the underlying fixed rate being received on fixed-term customer leases and loans.  These contracts are not designated for hedge accounting and most expire within three years or less.

[0001571996-18-000004:notes:158]
Interest rate swaps are utilized to manage the interest rate risk, at a portfolio level, associated with DFS operations in Europe.  The interest rate swaps economically convert the fixed rate on financing receivables to a three-month Euribor floating rate basis in order to match the floating rate nature of the banks' funding pool.  These contracts are not designated for hedge accounting and most expire within three years or less.

[0001571996-18-000004:notes:159]
The Company utilizes cross currency amortizing swaps to hedge the currency and interest rate risk exposure associated with the securitization program that was established in Europe in January 2017.  The cross currency swaps combine a Euro-based interest rate swap with a British Pound or U.S. Dollar foreign exchange forward contract in which the Company pays a fixed British Pound or U.S. Dollar amount and receives a floating amount in Euro linked to the one-month Euribor.  The notional value of the swaps amortizes in line with the expected cash flows and run-off of the securitized assets.  The swaps mature within five years or less and are not designated for hedge accounting.

[0001571996-18-000004:notes:160]
Notional Amounts of Outstanding Derivative Instruments

[0001571996-18-000004:notes:161]
The notional amounts of the Company's outstanding derivative instruments were as follows as of the dates indicated:

[0001571996-18-000004:notes:162]
|  | February 2, 2018 |  | February 3, 2017 (a) |
|  | (in millions) |
| Foreign exchange contracts: |  |  |  |  |  |
| Designated as cash flow hedging instruments | $ | 4,392 |  |  | $ | 3,781 |  |
| Non-designated as hedging instruments | 6,223 |  |  | 5,146 |  |
| Total | $ | 10,615 |  |  | $ | 8,927 |  |
| Interest rate contracts: |  |  |  |
| Non-designated as hedging instruments | $ | 1,897 |  |  | $ | 1,251 |  |

[0001571996-18-000004:notes:163]
| (a) | During the fiscal year ended February 2, 2018, the notional amount calculation methodology was enhanced to reflect the sum of the absolute value of derivative instruments netted by currency. Prior period amounts have been updated to conform with the current period presentation. |

[0001571996-18-000004:notes:164]
Effect of Derivative Instruments on the Consolidated Statements of Financial Position and the Consolidated Statements of Income (Loss)

[0001571996-18-000004:notes:165]
| Derivatives inCash FlowHedging Relationships |  | Gain (Loss)Recognizedin AccumulatedOCI, Netof Tax, onDerivatives(Effective Portion) |  | Location of Gain (Loss)Reclassifiedfrom AccumulatedOCI into Income(Effective Portion) |  | Gain (Loss)Reclassifiedfrom AccumulatedOCI into Income(Effective Portion) |  | Location of Gain (Loss) Recognized in Income on Derivative (Ineffective Portion) |  | Gain (Loss) Recognized in Income on Derivative (Ineffective Portion) |
| (in millions) |
| For the fiscal year ended February 2, 2018 |  |  |  |  |  |  |
|  |  |  |  |  | Total net revenue |  | $ | (77 | ) |  |  |  |  |
| Foreign exchange contracts |  | $ | (248 | ) |  | Total cost of net revenue |  | (57 | ) |  |  |  |  |
| Interest rate contracts |  | — |  |  | Interest and other, net |  | — |  |  | Interest and other, net |  | $ | — |  |
| Total |  | $ | (248 | ) |  |  |  | $ | (134 | ) |  |  |  | $ | — |  |
| For the fiscal year ended February 3, 2017 |  |  |  |  |  |  |
|  |  |  |  |  | Total net revenue |  | $ | 57 |  |  |  |  |  |
| Foreign exchange contracts |  | $ | 20 |  |  | Total cost of net revenue |  | (13 | ) |  |  |  |  |
| Interest rate contracts |  | — |  |  | Interest and other, net |  | — |  |  | Interest and other, net |  | $ | (1 | ) |
| Total |  | $ | 20 |  |  |  |  | $ | 44 |  |  |  |  | $ | (1 | ) |
| For the fiscal year ended January 29, 2016 |  |  |  |  |  |  |
|  |  |  |  |  | Total net revenue |  | $ | 328 |  |  |  |  |  |
| Foreign exchange contracts |  | $ | 152 |  |  | Total cost of net revenue |  | 40 |  |  |  |  |  |
| Interest rate contracts |  | — |  |  | Interest and other, net |  | — |  |  | Interest and other, net |  | $ | (1 | ) |
| Total |  | $ | 152 |  |  |  |  | $ | 368 |  |  |  |  | $ | (1 | ) |

[0001571996-18-000004:notes:166]
Fair Value of Derivative Instruments in the Consolidated Statements of Financial Position

[0001571996-18-000004:notes:167]
The Company presents its foreign exchange derivative instruments on a net basis in the Consolidated Statements of Financial Position due to the right of offset by its counterparties under master netting arrangements.  The fair value of those derivative instruments presented on a gross basis as of each date indicated below was as follows:

[0001571996-18-000004:notes:168]
|  | February 2, 2018 |
|  | Other CurrentAssets |  | Other Non-Current Assets |  | Other CurrentLiabilities |  | Other Non-CurrentLiabilities |  | TotalFair Value |
|  |  |  | (in millions) |  |  |
| Derivatives designated as hedging instruments: |
| Foreign exchange contracts in an asset position | $ | 9 |  |  | $ | — |  |  | $ | 11 |  |  | $ | — |  |  | $ | 20 |  |
| Foreign exchange contracts in a liability position | (7 | ) |  | — |  |  | (52 | ) |  | — |  |  | (59 | ) |
| Net asset (liability) | 2 |  |  | — |  |  | (41 | ) |  | — |  |  | (39 | ) |
| Derivatives not designated as hedging instruments: |
| Foreign exchange contracts in an asset position | 194 |  |  | 3 |  |  | 141 |  |  | — |  |  | 338 |  |
| Foreign exchange contracts in a liability position | (127 | ) |  | — |  |  | (283 | ) |  | — |  |  | (410 | ) |
| Interest rate contracts in an asset position | — |  |  | 11 |  |  | — |  |  | — |  |  | 11 |  |
| Interest rate contracts in a liability position | — |  |  | — |  |  | — |  |  | (1 | ) |  | (1 | ) |
| Net asset (liability) | 67 |  |  | 14 |  |  | (142 | ) |  | (1 | ) |  | (62 | ) |
| Total derivatives at fair value | $ | 69 |  |  | $ | 14 |  |  | $ | (183 | ) |  | $ | (1 | ) |  | $ | (101 | ) |
|  | February 3, 2017 |
|  | Other CurrentAssets |  | Other Non-Current Assets |  | Other CurrentLiabilities |  | Other Non-CurrentLiabilities |  | TotalFair Value |
|  |  |  | (in millions) |  |  |
| Derivatives designated as hedging instruments: |
| Foreign exchange contracts in an asset position | $ | 41 |  |  | $ | — |  |  | $ | 17 |  |  | $ | — |  |  | $ | 58 |  |
| Foreign exchange contracts in a liability position | (19 | ) |  | — |  |  | (6 | ) |  | — |  |  | (25 | ) |
| Net asset (liability) | 22 |  |  | — |  |  | 11 |  |  | — |  |  | 33 |  |
| Derivatives not designated as hedging instruments: |
| Foreign exchange contracts in an asset position | 309 |  |  | 2 |  |  | 31 |  |  | — |  |  | 342 |  |
| Foreign exchange contracts in a liability position | (131 | ) |  | — |  |  | (103 | ) |  | — |  |  | (234 | ) |
| Interest rate contracts in an asset position | — |  |  | 3 |  |  | — |  |  | — |  |  | 3 |  |
| Interest rate contracts in a liability position | — |  |  | — |  |  | — |  |  | (3 | ) |  | (3 | ) |
| Net asset (liability) | 178 |  |  | 5 |  |  | (72 | ) |  | (3 | ) |  | 108 |  |
| Total derivatives at fair value | $ | 200 |  |  | $ | 5 |  |  | $ | (61 | ) |  | $ | (3 | ) |  | $ | 141 |  |

[0001571996-18-000004:notes:169]
The following table presents the gross amounts of the Company's derivative instruments, amounts offset due to master netting agreements with the Company's counterparties, and the net amounts recognized in the Consolidated Statements of Financial Position.

[0001571996-18-000004:notes:170]
|  | February 2, 2018 |
|  | Gross Amounts of Recognized Assets/ (Liabilities) |  | Gross Amounts Offset in the Statement of Financial Position |  | Net Amounts of Assets/ (Liabilities) Presented in the Statement of Financial Position |  | Gross Amounts not Offset in the Statement of Financial Position |  | Net Amount |
|  | Financial Instruments |  | Cash Collateral Received or Pledged |  |
|  | (in millions) |
| Derivative instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Financial assets | $ | 369 |  |  | $ | (286 | ) |  | $ | 83 |  |  | $ | — |  |  | $ | — |  |  | $ | 83 |  |
| Financial liabilities | (470 | ) |  | 286 |  |  | (184 | ) |  | — |  |  | — |  |  | (184 | ) |
| Total derivative instruments | $ | (101 | ) |  | $ | — |  |  | $ | (101 | ) |  | $ | — |  |  | $ | — |  |  | $ | (101 | ) |
|  | February 3, 2017 |
|  | Gross Amounts of Recognized Assets/ (Liabilities) |  | Gross Amounts Offset in the Statement of Financial Position |  | Net Amounts of Assets/ (Liabilities) Presented in the Statement of Financial Position |  | Gross Amounts not Offset in the Statement of Financial Position |  | Net Amount |
|  | Financial Instruments |  | Cash Collateral Received or Pledged |  |
|  | (in millions) |
| Derivative instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Financial assets | $ | 403 |  |  | $ | (198 | ) |  | $ | 205 |  |  | $ | — |  |  | $ | — |  |  | $ | 205 |  |
| Financial liabilities | (262 | ) |  | 198 |  |  | (64 | ) |  | — |  |  | — |  |  | (64 | ) |
| Total derivative instruments | $ | 141 |  |  | $ | — |  |  | $ | 141 |  |  | $ | — |  |  | $ | — |  |  | $ | 141 |  |


## us-gaap:DerivativesPolicyTextBlock

[0001571996-18-000004:notes:171]
The Company uses derivative financial instruments, primarily forwards, options, and swaps, to hedge certain foreign currency and interest rate exposures.  The relationships between hedging instruments and hedged items, as well as the risk management objectives and strategies for undertaking hedge transactions, are formally documented.  The Company does not use derivatives for speculative purposes.

[0001571996-18-000004:notes:172]
All derivative instruments are recognized as either assets or liabilities in the Consolidated Statements of Financial Position and are measured at fair value.  Hedge accounting is applied based upon the criteria established by accounting guidance for derivative instruments and hedging activities.  Derivatives are assessed for hedge effectiveness both at the onset of the hedge and at regular intervals throughout the life of the derivative.  Any hedge ineffectiveness is recognized currently in earnings as a component of interest and other, net.  For derivatives that are not designated as hedges or do not qualify for hedge accounting treatment, the Company recognizes the change in the instrument's fair value currently in earnings as a component of interest and other, net.  The Company's hedge portfolio includes non-designated derivatives and derivatives designated as cash flow hedges.

[0001571996-18-000004:notes:173]
For derivative instruments that are designated as cash flow hedges, hedge ineffectiveness is measured by comparing the cumulative change in the fair value of the hedge contract with the cumulative change in the fair value of the hedged item, both of which are based on forward rates.  The Company records the effective portion of the gain or loss on the derivative instrument in accumulated other comprehensive income (loss), as a separate component of stockholders' equity, and reclassifies the gain or loss into earnings in the period during which the hedged transaction is recognized in earnings.

[0001571996-18-000004:notes:174]
Cash flows from derivative instruments are presented in the same category on the Consolidated Statements of Cash Flows as the cash flows from the underlying hedged items.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001571996-18-000004:notes:175]
STOCK-BASED COMPENSATION

[0001571996-18-000004:notes:176]
Stock-based Compensation Expense

[0001571996-18-000004:notes:177]
Stock-based compensation expense for the Company was recognized in the Consolidated Statements of Income (Loss) as follows for the respective periods:

[0001571996-18-000004:notes:178]
|  | Fiscal Year Ended |
|  | February 2, 2018 |  | February 3, 2017 |  | January 29, 2016 |
|  | (in millions) |
| Stock-based compensation expense (a) (b): |  |  |  |  |  |  |
| Cost of net revenue | $ | 66 |  |  | $ | 35 |  |  | $ | 10 |  |
| Operating expenses | 769 |  |  | 363 |  |  | 62 |  |
| Stock-based compensation expense before taxes | 835 |  |  | 398 |  |  | 72 |  |
| Income tax benefit | (268 | ) |  | (122 | ) |  | (26 | ) |
| Stock-based compensation expense, net of income taxes | $ | 567 |  |  | $ | 276 |  |  | $ | 46 |  |

[0001571996-18-000004:notes:179]
| (a) | As a result of the EMC merger transaction, stock-based compensation expense before taxes for the fiscal year ended February 2, 2018 includes $683 million related to VMware, Inc. plans discussed below. Stock-based compensation expense before taxes for the fiscal year ended February 3, 2017 includes $279 million related to VMware, Inc. plans for the period from September 7, 2016 through February 3, 2017. |

[0001571996-18-000004:notes:180]
| (b) | Stock-based compensation expense before taxes for the fiscal year ended February 3, 2017 does not include $807 million of post-merger stock-based compensation expense and related taxes resulting from the EMC merger transaction. See Note 3 of the Notes to the Consolidated Financial Statements for more information on the EMC merger transaction. |

[0001571996-18-000004:notes:181]
Dell Technologies Inc. Stock-based Compensation Plans

[0001571996-18-000004:notes:182]
Dell Technologies Inc. 2013 Stock Incentive Plan — On September 7, 2016, at the effective time of the EMC merger transaction, the Denali Holding Inc. 2013 Stock Incentive Plan (the "2013 Plan") was amended and restated as the Dell Technologies Inc. 2013 Stock Incentive Plan (the "Restated Plan").  Employees, consultants, non-employee directors, and other service providers of the Company or its affiliates are eligible to participate in the Restated Plan.  The Restated Plan authorizes the issuance of an aggregate of 75 million shares of the Company's Class C Common Stock and 500,000 shares of the Company's Class V Common Stock, of which 61 million shares of Class C Common Stock were previously reserved for issuance under the 2013 Plan.  The Restated Plan authorizes the Company to grant stock options, restricted stock units ("RSUs"), stock appreciation rights ("SARs"), RSAs, and dividend equivalents.

[0001571996-18-000004:notes:183]
As of February 2, 2018 and February 3, 2017, there were 30 million and 26 million shares, respectively, of common stock of Dell Technologies available for future grants under the Restated Plan.

[0001571996-18-000004:notes:184]
Stock Option Agreements — Stock options granted under the Restated Plan include service-based awards and performance-based awards.  A majority of the service-based stock options vest pro-rata at each option anniversary date over a five-year period.  Performance-based stock options, with a market condition, become exercisable upon achievement of return on equity ("ROE") metrics up to the seven-year anniversary of the going-private transaction date, depending upon the achievement of the market condition.  Both service-based and performance-based stock options are granted with option exercise prices equal to the fair market value of the Company's common stock, as determined by the Company's board of directors or authorized committee.  Generally, shares of common stock issued under both service-based and performance-based awards are subject to liquidity events, such as an initial public offering, change in control, sales of common stock under a semi-annual company liquidity program, and calls and puts resulting upon the occurrence of specified events.  A majority of the stock options expire ten years after the date of grant.

[0001571996-18-000004:notes:185]
Stock Option Activity — The following table summarizes stock option activity settled in DHI Group Common Stock during the fiscal years ended February 2, 2018, February 3, 2017, and January 29, 2016:

[0001571996-18-000004:notes:186]
|  | Number of Options |  | Weighted-Average Exercise Price |  | Weighted Average Remaining Contractual Term |  | Aggregate Intrinsic Value (a) |
|  | (in millions) |  | (per share) |  | (in years) |  | (in millions) |
| Options outstanding as of January 30, 2015 | 55 |  |  | $ | 14.11 |  |  |  |  |  |
| Granted | 2 |  |  | 24.05 |  |  |  |  |  |
| Exercised | — |  |  | — |  |  |  |  |  |
| Forfeited | (3 | ) |  | 19.07 |  |  |  |  |  |
| Canceled/expired | — |  |  | — |  |  |  |  |  |
| Options outstanding as of January 29, 2016 | 54 |  |  | 14.30 |  |  |  |  |  |
| Granted | 2 |  |  | 27.09 |  |  |  |  |  |
| Exercised | (1 | ) |  | 14.12 |  |  |  |  |  |
| Forfeited | (7 | ) |  | 15.51 |  |  |  |  |  |
| Canceled/expired | — |  |  | — |  |  |  |  |  |
| Options outstanding as of February 3, 2017 | 48 |  |  | 14.75 |  |  |  |  |  |
| Granted | — |  |  | — |  |  |  |  |  |
| Exercised | (4 | ) |  | 14.62 |  |  |  |  |  |
| Forfeited | (2 | ) |  | 13.75 |  |  |  |  |  |
| Canceled/expired | — |  |  | — |  |  |  |  |  |
| Options outstanding as of February 2, 2018 (b) | 42 |  |  | $ | 14.80 |  |  | 5.7 |  | $ | 776 |  |
| Exercisable as of February 2, 2018 | 18 |  |  | $ | 15.17 |  |  | 5.5 |  | $ | 329 |  |
| Vested and expected to vest (net of estimated forfeitures) as of February 2, 2018 | 40 |  |  | $ | 14.80 |  |  | 5.7 |  | $ | 732 |  |

[0001571996-18-000004:notes:187]
| (a) | The aggregate intrinsic values represent the total pre-tax intrinsic values based on the fair market value of the DHI Group Common Stock as of February 2, 2018 that would have been received by the option holders had all in-the-money options been exercised as of that date. |

[0001571996-18-000004:notes:188]
| (b) | Of the 42 million stock options outstanding on February 2, 2018, 19 million related to performance-based awards and 23 million related to service-based awards. |

[0001571996-18-000004:notes:189]
The total fair value of options vested was $45 million, $50 million, and $42 million for the fiscal years ended February 2, 2018, February 3, 2017, and January 29, 2016, respectively.  The pre-tax intrinsic value of the options exercised was $62 million, $18 million, and $4 million for the fiscal years ended February 2, 2018, February 3, 2017, and January 29, 2016, respectively.  As of February 2, 2018, there was $45 million of total unrecognized stock-based compensation expense, net of estimated forfeitures, related to unvested stock options expected to be recognized over a weighted-average period of 1.6 years.

[0001571996-18-000004:notes:190]
The tax benefit realized from the exercise of stock options was $21 million, $6 million, and $1 million for the fiscal years ended February 2, 2018, February 3, 2017, and January 29, 2016, respectively.

[0001571996-18-000004:notes:191]
In connection with the EMC merger transaction and in accordance with the merger agreement, certain executives holding unvested restricted stock units of EMC ("EMC RSUs") were given the opportunity to elect to exchange each unvested EMC RSU held by such executives that would otherwise have vested in the ordinary course on or after January 1, 2017 for (a) a deferred cash award having a cash value equal to the closing price of a share of EMC common stock on the last trading day before the closing date of the EMC merger transaction, or $29.05, and (b) an option ("rollover option") to purchase a share of Class C Common Stock of Dell Technologies (the "rollover opportunity").  The rollover options have a three-year term and a per share exercise price equal to the fair market value of a share of Class C Common Stock on the date of grant, or $27.50, and, to the extent vested, may be exercised using a cashless exercise method for both the exercise price and the applicable minimum required tax withholding (subject to certain limitations).  Each deferred cash award will vest, and each rollover option will vest and thereby become exercisable, on the same schedule as the EMC RSU for which they were exchanged (with any performance-vesting condition deemed satisfied at the target level of performance upon the closing of the EMC merger transaction).  Pursuant to the rollover opportunity, options to purchase 1.8 million shares of Class C Common Stock were issued and have been included within the stock option activity table above as granted options.

[0001571996-18-000004:notes:192]
Valuation of Service-Based Stock Option Awards — For service-based stock options granted under the 2013 Plan and the Restated Plan, the Company utilized the Black-Scholes option pricing model to estimate the fair value of stock options at the grant date.  The Black-Scholes option pricing model incorporates various assumptions, including leveraged adjusted volatility of a public peer group, expected term, risk-free interest rates, and dividend yields.  The weighted assumptions utilized for valuation of options under this model as well as the weighted-average grant date fair value of stock options granted during the respective periods are presented below.

[0001571996-18-000004:notes:193]
The expected term is based on historical experience and on the terms and conditions of the stock awards granted to employees.  For the periods presented, option valuations used leverage-adjusted volatility of a peer group, and the expected term was based on analysis of the Company's historical option settlement experience and on the terms and conditions of the stock awards granted.

[0001571996-18-000004:notes:194]
The assumptions utilized in this model as well as the weighted-average grant date fair value of stock options granted in DHI Group Common Stock are presented below.  The Company granted an immaterial number of service-based stock options during the fiscal year ended February 2, 2018.

[0001571996-18-000004:notes:195]
|  | Fiscal Year Ended |
|  | February 3, 2017 |  | January 29, 2016 |
| Weighted-average grant date fair value of stock options granted per option | $ | 10.36 |  |  | $ | 10.05 |  |
| Expected term (in years) | 3.4 |  |  | 5.1 |  |
| Risk-free rate (U.S. Government Treasury Note) | 0.9 | % |  | 1.5 | % |
| Expected volatility | 51 | % |  | 46 | % |
| Expected dividend yield | — | % |  | — | % |

[0001571996-18-000004:notes:196]
Valuation of Performance-Based Stock Option Awards — For performance-based stock options granted under the 2013 Plan and the Restated Plan, the Company utilized the Monte Carlo valuation model to simulate probabilities of achievement of the market condition and the grant date fair value.  The valuation model for performance-based option grants during the fiscal years ended February 2, 2018, February 3, 2017, and January 29, 2016 used a weighted-average leverage adjusted five years peer volatility and corresponding risk free interest rate.  Upon fulfillment of a ROE condition, a specific portion of the performance options become exercisable.  An embedded binomial lattice option pricing model was used to determine the value of these exercisable options using the assumption that each option will be exercised at the midpoint between the date of satisfaction of a ROE condition and the expiration date of such option.

[0001571996-18-000004:notes:197]
The assumptions utilized in this model as well as the weighted-average grant date fair value of stock options granted are presented below.  There were no performance-based stock options granted during the fiscal year ended February 2, 2018.

[0001571996-18-000004:notes:198]
|  | Fiscal Year Ended |
|  | February 3, 2017 |  | January 29, 2016 |
| Weighted-average grant date fair value of stock options granted per option | $ | 8.83 |  |  | $ | 10.85 |  |
| Expected term (in years) | — |  |  | — |  |
| Risk-free rate (U.S. Government Treasury Note) | 1.7 | % |  | 2.0 | % |
| Expected volatility | 44 | % |  | 50 | % |
| Expected dividend yield | — | % |  | — | % |

[0001571996-18-000004:notes:199]
Restricted Stock — The Company's restricted stock primarily consists of RSU awards granted to employees.  RSUs are valued based on the Company's Class C Common Stock price on the date of grant.  The shares underlying the RSU awards are not issued until the RSU vests.  Upon vesting, each RSU converts into one share of DHI Group Common Stock.

[0001571996-18-000004:notes:200]
The Company's restricted stock also includes performance stock unit ("PSU") awards, which have been granted to certain members of the Company's senior leadership team.  The PSU awards include performance conditions and, in certain cases, a time-based vesting component.  For PSU awards granted under the Restated Plan, the Company utilized the Monte Carlo valuation model to simulate the probabilities of achievement of the market condition to determine the grant date fair value.  The vesting and payout of the PSU awards depends upon the return on equity achieved on various measurement dates or liquidity events.

[0001571996-18-000004:notes:201]
The following table summarizes restricted stock and restricted stock units activity settled in DHI Group Common Stock during the fiscal years ended February 2, 2018 and February 3, 2017.  For the fiscal year ended January 29, 2016, the total estimated vest date fair value of restricted stock unit awards was not material.

[0001571996-18-000004:notes:202]
|  | Number of Units |  | Weighted-Average Grant Date Fair Value |
|  | (in millions) |  | (per unit) |
| Outstanding, January 29, 2016 | — |  |  | $ | — |  |
| Granted | 11 |  |  | 19.66 |  |
| Vested | — |  |  | — |  |
| Forfeited | (1 | ) |  | 19.63 |  |
| Outstanding, February 3, 2017 | 10 |  |  | 19.63 |  |
| Granted | 1 |  |  | 23.04 |  |
| Vested | (1 | ) |  | 27.59 |  |
| Forfeited | (3 | ) |  | 19.13 |  |
| Outstanding, February 2, 2018 (a) | 7 |  |  | $ | 18.73 |  |

[0001571996-18-000004:notes:203]
_________________

[0001571996-18-000004:notes:204]
| (a) | As of February 2, 2018, the 7 million units outstanding included 2 million RSUs and 5 million PSUs. |

[0001571996-18-000004:notes:205]
As of February 2, 2018, restricted stock that is expected to vest was as follows:

[0001571996-18-000004:notes:206]
|  | Number of Units |  | Weighted Average Remaining Contractual Term |  | Aggregate Intrinsic Value (a) |
|  | (in millions) |  | (in years) |  | (in millions) |
| Expected to vest, February 2, 2018 | 6 |  |  | 3.3 |  | $ | 212 |  |

[0001571996-18-000004:notes:207]
| (a) | The aggregate intrinsic values represent the total pre-tax intrinsic values based on the fair market value of the DHI Group Common Stock as of February 2, 2018 that would have been received by the RSU holders had the RSUs been issued as of February 2, 2018. |

[0001571996-18-000004:notes:208]
The total fair value of restricted stock that vested during the year ended February 2, 2018 was $37 million and the pre-tax intrinsic value was $44 million.  As of February 2, 2018, 7 million shares of restricted stock were outstanding, with an aggregate intrinsic value of $246 million.

[0001571996-18-000004:notes:209]
As of February 2, 2018, there was $78 million of unrecognized stock-based compensation expense, net of estimated forfeitures, related to these awards expected to be recognized over a weighted-average period of approximately 1.7 years.

[0001571996-18-000004:notes:210]
Dell Technologies Shares Withheld for Taxes — Under certain situations, shares are sold to cover employee taxes for both the vesting of restricted stock units and the exercise of stock options.  For the fiscal years ended February 2, 2018 and February 3, 2017, 1.0 million and 0.2 million shares, respectively, were withheld to cover $35 million and $6 million, respectively, of employees' tax obligations.  Shares withheld for taxes for the fiscal year ended January 29, 2016 were immaterial.

[0001571996-18-000004:notes:211]
VMware, Inc. Stock-based Compensation Plans

[0001571996-18-000004:notes:212]
VMware, Inc. 2007 Equity and Incentive Plan — In June 2007, VMware, Inc. adopted its 2007 Equity and Incentive Plan (the "2007 Plan").  As of February 2, 2018, the number of authorized shares of VMware, Inc.  Class A common stock under the 2007 Plan was 126 million.  The number of shares underlying outstanding equity awards that VMware, Inc. assumes in the course of business acquisitions are also added to the 2007 Plan reserve on an as-converted basis.  VMware, Inc. has assumed 6 million shares, which accordingly have been added to the authorized shares under the 2007 Plan reserve.

[0001571996-18-000004:notes:213]
Awards under the 2007 Plan may be in the form of stock-based awards such as RSUs or stock options.  VMware, Inc.'s Compensation and Corporate Governance Committee determines the vesting schedule for all equity awards.  Generally, restricted stock grants made under the 2007 Plan have a three-year to four-year period over which they vest and vest 25% the first year and semi-annually thereafter.  The value of RSU grants is based on VMware, Inc.'s stock price on the date of grant.  The shares underlying the RSU awards are not issued until the RSUs vest.  Upon vesting, each RSU converts into one share of VMware, Inc. Class A common stock.  VMware, Inc.'s restricted stock also includes PSU awards which have been granted to certain VMware, Inc. executives and employees.  The PSU awards include performance conditions and, in certain cases, a time-based or market-based vesting component.  Upon vesting, each PSU award will convert into VMware, Inc.'s Class A common stock at various ratios ranging from 0.5 to 2.0 shares per PSU, depending upon the degree of achievement of the performance target designated by each award.  If minimum performance thresholds are not achieved, then no shares will be issued.

[0001571996-18-000004:notes:214]
The per share exercise price for a stock option awarded under the 2007 Plan shall not be less than 100% of the per share fair market value of VMware, Inc.  Class A common stock on the date of grant.  Most options granted under the 2007 Plan vest 25% after the first year and monthly thereafter over the following three years and expire between six and seven years from the date of grant.  VMware, Inc. utilizes authorized and unissued shares to satisfy all shares issued under the 2007 Plan.  As of February 2, 2018, there were an aggregate of approximately 16 million shares of common stock available for issuance pursuant to future grants under the 2007 Plan.

[0001571996-18-000004:notes:215]
VMware, Inc. Employee Stock Purchase Plan — In June 2007, VMware, Inc. adopted its 2007 Employee Stock Purchase Plan (the "ESPP"), which is intended to be qualified under Section 423 of the Internal Revenue Code.  As of February 2, 2018, the number of authorized shares under the ESPP was approximately 23 million.  Under the ESPP, eligible VMware, Inc. employees are granted options to purchase shares at the lower of 85% of the fair market value of the stock at the time of grant or 85% of the fair market value at the time of exercise.

[0001571996-18-000004:notes:216]
The option period is generally twelve months and includes two embedded six-month option periods.  Options are exercised at the end of each embedded option period.  If the fair market value of the stock is lower on the first day of the second embedded option period than it was at the time of grant, then the twelve-month option period expires and each enrolled participant is granted a new twelve-month option.  As of February 2, 2018, approximately 9 million shares of VMware, Inc. Class A common stock were available for issuance under the ESPP.

[0001571996-18-000004:notes:217]
The following table summarizes ESPP activity for the fiscal year ended February 2, 2018, and during the period from September 7, 2016 through February 3, 2017:

[0001571996-18-000004:notes:218]
|  | Fiscal Year Ended February 2, 2018 |  | For the Period September 7, 2016 through February 3, 2017 |
|  | (in millions, except per share amounts) |
| Cash proceeds | $ | 65 |  |  | $ | 60 |  |
| Class A common shares purchased | 0.9 |  |  | 1.5 |  |
| Weighted-average price per share | $ | 72.40 |  |  | $ | 40.65 |  |

[0001571996-18-000004:notes:219]
As of February 2, 2018, $80 million of ESPP withholdings were recorded as a liability in accrued and other on the Consolidated Statements of Financial Position for the purchase that occurred on February 28, 2018.  Total unrecognized stock-based compensation expense as of February 2, 2018 for the ESPP was $7 million.

[0001571996-18-000004:notes:220]
VMware, Inc. 2007 Equity and Incentive Plan Stock Options — The following table summarizes stock option activity for VMware, Inc. employees in VMware, Inc. stock options:

[0001571996-18-000004:notes:221]
|  | Number of Options |  | Weighted-Average Exercise Price |  | Weighted Average Remaining Contractual Term |  | Aggregate Intrinsic Value (a) |
|  | (in millions) |  | (per share) |  | (in years) |  | (in millions) |
| Options outstanding as of September 7, 2016 | 2 |  |  | $ | 65.01 |  |  |  |  |  |
| Granted | — |  |  | — |  |  |  |  |  |
| Exercised | — |  |  | — |  |  |  |  |  |
| Forfeited | — |  |  |  |  |  |  |  |
| Canceled/Expired | — |  |  |  |  |  |  |  |
| Options outstanding as of February 3, 2017 (b) | 2 |  |  | 69.38 |  |  |  |  |  |
| Granted | 1 |  |  | 13.79 |  |  |  |  |  |
| Exercised | (1 | ) |  | 53.50 |  |  |  |  |  |
| Forfeited | — |  |  | — |  |  |  |  |  |
| Canceled/Expired | — |  |  | — |  |  |  |  |  |
| Options outstanding as of February 2, 2018 | 2 |  |  | $ | 54.63 |  |  | 5.1 |  | $ | 112 |  |
| Exercisable as of February 2, 2018 | 1 |  |  | $ | 73.60 |  |  | 3.3 |  | $ | 50 |  |
| Vested and expected to vest (net of estimated forfeitures) as of February 2, 2018 | 2 |  |  | $ | 54.56 |  |  | 5.1 |  | $ | 112 |  |

[0001571996-18-000004:notes:222]
| (a) | The aggregate intrinsic values represent the total pre-tax intrinsic values based on VMware, Inc.'s closing stock price of $122.72 as of February 2, 2018 that would have been received by the option holders had all in-the-money options been exercised as of that date. |

[0001571996-18-000004:notes:223]
(b)   Stock option activity during the period was immaterial.  The ending weighted-average exercise price was calculated based on underlying options outstanding as of February 3, 2017.

[0001571996-18-000004:notes:224]
The above table includes stock options granted in conjunction with unvested stock options assumed in business combinations.  As a result, the weighted-average exercise price per share may vary from the VMware, Inc. stock price at time of grant.  The total fair value of VMware, Inc. stock options that vested during the fiscal year ended February 2, 2018 and for the period from September 7, 2016 through February 3, 2017 was $32 million and $13 million, respectively.  The pre-tax intrinsic value of the options exercised during the fiscal year ended February 2, 2018 and for the period from September 7, 2016 through February 3, 2017 was $62 million and $13 million, respectively.

[0001571996-18-000004:notes:225]
The tax benefit realized from the exercise of stock options was $21 million and $4 million for the fiscal year ended February 2, 2018 and for the period from September 7, 2016 through February 3, 2017, respectively.  As of February 2, 2018, there was $46 million of total unrecognized stock-based compensation expense, net of estimated forfeitures, related to unvested stock options expected to be recognized over a weighted-average period of approximately one year.

[0001571996-18-000004:notes:226]
Fair Value of VMware, Inc. Options — The fair value of each option to acquire VMware, Inc. Class A common stock granted is estimated on the date of grant using the Black-Scholes option-pricing model.  The assumptions utilized in this model, as well as the weighted-average assumptions, are presented below.  There were no stock options granted under the 2007 Plan during the period from September 7, 2016 through February 3, 2017.

[0001571996-18-000004:notes:227]
|  | Fiscal Year Ended |
|  | February 2, 2018 |
| VMware, Inc. 2007 Equity and Incentive Plan |  |
| Weighted-average grant date fair value of stock options granted per option | $ | 83.62 |  |
| Expected term (in years) | 3.3 |  |
| Risk-free rate (U.S. Government Treasury Note) | 1.7 | % |
| Expected volatility | 29 | % |
| Expected dividend yield | — | % |

[0001571996-18-000004:notes:228]
|  | Fiscal Year Ended |
|  | February 2, 2018 |  | February 3, 2017 |
| VMware, Inc. Employee Stock Purchase Plan |  |  |  |
| Weighted-average grant date fair value of stock options granted per option | $ | 21.93 |  |  | $ | 13.57 |  |
| Expected term (in years) | 0.9 |  |  | 0.8 |  |
| Risk-free rate (U.S. Government Treasury Note) | 1.2 | % |  | 0.5 | % |
| Expected volatility | 23 | % |  | 38 | % |
| Expected dividend yield | — | % |  | — | % |

[0001571996-18-000004:notes:229]
The weighted-average grant date fair value of VMware, Inc. stock options can fluctuate from period to period primarily due to higher valued options assumed through business combinations with exercise prices lower than the fair market value of VMware, Inc.'s stock on the date of grant.

[0001571996-18-000004:notes:230]
For equity awards granted, volatility is based on an analysis of historical stock prices and implied volatilities of VMware, Inc.'s Class A common stock.  The expected term is based on historical exercise patterns and post-vesting termination behavior, the term of the option period for grants made under the ESPP, or the weighted-average remaining term for options assumed in acquisitions.  VMware, Inc.'s expected dividend yield input was zero as it has not historically paid, nor expects in the future to pay, cash dividends on its common stock.  The risk-free interest rate is based on a U.S. Treasury instrument whose term is consistent with the expected term of the stock options.

[0001571996-18-000004:notes:231]
VMware, Inc. Restricted Stock — The following table summarizes VMware, Inc.'s restricted stock activity since September 7, 2016:

[0001571996-18-000004:notes:232]
|  | Number of Units |  | Weighted-Average Grant Date Fair Value |
|  | (in millions) |  | (per unit) |
| Outstanding, September 7, 2016 | 22 |  |  | $ | 67.01 |  |
| Granted | 2 |  |  | 79.81 |  |
| Vested | (3 | ) |  | 72.94 |  |
| Forfeited | (1 | ) |  | 69.19 |  |
| Outstanding, February 3, 2017 | 20 |  |  | 67.41 |  |
| Granted | 8 |  |  | 93.84 |  |
| Vested | (9 | ) |  | 67.89 |  |
| Forfeited | (2 | ) |  | 72.68 |  |
| Outstanding, February 2, 2018 (a) | 17 |  |  | $ | 78.62 |  |

[0001571996-18-000004:notes:233]
| (a) | As of February 2, 2018, the 17 million units outstanding included 16.7 million RSUs and 0.7 million PSUs. The above table includes RSUs issued in exchange for outstanding unvested RSUs in connection with business combinations. |

[0001571996-18-000004:notes:234]
|  | Number of Units |  | Weighted Average Remaining Contractual Term |  | Aggregate Intrinsic Value (a) |
|  | (in millions) |  | (in years) |  | (in millions) |
| Expected to vest, February 2, 2018 | 15 |  |  | 2.5 |  | $ | 1,855 |  |

[0001571996-18-000004:notes:235]
| (a) | The aggregate intrinsic value represent the total pre-tax intrinsic values based on VMware, Inc.'s closing stock price of $122.72 as of February 2, 2018 that would have been received by the RSU holders had the RSUs been issued as of February 2, 2018. |

[0001571996-18-000004:notes:236]
The total fair value of VMware, Inc. restricted stock awards that vested during the fiscal year ended February 2, 2018 and the period from September 7, 2016 through February 3, 2017 was $616 million and $203 million, respectively, and the pre-tax intrinsic value was $946 million and $218 million, respectively.  As of February 2, 2018, 17 million restricted shares of VMware, Inc.'s Class A common stock were outstanding, with an aggregate intrinsic value of $2,130 million based on VMware, Inc.'s closing stock price as of February 2, 2018.

[0001571996-18-000004:notes:237]
As of February 2, 2018, there was $999 million of unrecognized stock-based compensation expense, net of estimated forfeitures, related to these awards expected to be recognized over a weighted-average period of approximately 1.5 years.

[0001571996-18-000004:notes:238]
VMware, Inc. Shares Withheld for Taxes — For the fiscal year ended February 2, 2018 and for the period from September 7, 2016 through February 3, 2017, VMware, Inc. repurchased and retired or withheld 3 million shares and 1 million shares of VMware, Inc. Class A common stock, respectively, for $348 million and $77 million, respectively, to cover tax withholding obligations.  These amounts may differ from the amounts of cash remitted for tax withholding obligations on the consolidated statements of cash flows due to the timing of payments.  Pursuant to the respective award agreements, these shares were withheld in conjunction with the net share settlement upon the vesting of restricted stock and restricted stock units (including PSUs) during the period.  The value of the withheld shares, including restricted stock units, was classified as a reduction to additional paid-in capital.

[0001571996-18-000004:notes:239]
Other Plans

[0001571996-18-000004:notes:240]
In addition to the plans disclosed above, the Company has issued equity grants settling in its Class V Common Stock as well as classes of stock of its subsidiaries, including SecureWorks.  The stock option and restricted stock unit activity under these plans was not material during the fiscal years ended February 2, 2018, February 3, 2017, and January 29, 2016.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001571996-18-000004:notes:241]
DISCONTINUED OPERATIONS

[0001571996-18-000004:notes:242]
During the fiscal year ended February 3, 2017, Dell Inc. entered into a definitive agreement with NTT Data International L.L.C. to divest substantially all of Dell Services, and on November 2, 2016, the parties closed substantially all of the transaction.  During the fiscal year ended February 3, 2017, Dell Inc. entered into a definitive agreement with Francisco Partners and Elliot Management Corporation to divest substantially all of DSG, and on October 31, 2016, the parties closed the transaction.  During the fiscal year ended February 3, 2017, EMC, a subsidiary of the Company, entered into a definitive agreement with OpenText Corporation to divest the Dell EMC Enterprise Content Division, and on January 23, 2017, the parties closed the transaction.  Upon closing of the respective transactions, the Company entered into transition services agreements with NTT Data International L.L.C., Francisco Partners and Elliot Management, and OpenText Corporation pursuant to which the Company provides various administrative services on an interim transitional basis.  Transition services may be provided for up to one year, with an option to renew after that period.  The Company also entered into various commercial agreements with NTT Data International L.L.C., Francisco Partners and Elliot Management, and OpenText Corporation that include reseller agreements for certain offerings.

[0001571996-18-000004:notes:243]
In accordance with applicable accounting guidance, the Company reclassified the financial results of Dell Services, DSG, and ECD as discontinued operations in the Consolidated Statements of Income (Loss) for the relevant periods.  The following tables present key financial results of Dell Services, DSG, and ECD included in "Income from discontinued operations, net of income taxes" for the fiscal years ended February 3, 2017 and January 29, 2016:

[0001571996-18-000004:notes:244]
|  | Fiscal Year Ended February 3, 2017 |
|  | ECD (a) |  | Dell Services |  | DSG |  | Total |
|  | (in millions) |
| Net revenue | $ | 209 |  |  | $ | 1,980 |  |  | $ | 975 |  |  | $ | 3,164 |  |
| Cost of net revenue | 56 |  |  | 1,563 |  |  | 252 |  |  | 1,871 |  |
| Operating expenses | 137 |  |  | 347 |  |  | 726 |  |  | 1,210 |  |
| Interest and other, net | (1 | ) |  | (8 | ) |  | (2 | ) |  | (11 | ) |
| Income (loss) from discontinued operations before income taxes and gain (loss) on disposal | 15 |  |  | 62 |  |  | (5 | ) |  | 72 |  |
| Income tax provision (benefit) | 3 |  |  | (40 | ) |  | (23 | ) |  | (60 | ) |
| Income from discontinued operations, net of income taxes, before gain (loss) on disposal | 12 |  |  | 102 |  |  | 18 |  |  | 132 |  |
| Gain (loss) on disposal, net of tax expense (benefit) of $182, $(256), and $506, respectively | (356 | ) |  | 1,680 |  |  | 563 |  |  | 1,887 |  |
| Income (loss) from discontinued operations, net of income taxes | $ | (344 | ) |  | $ | 1,782 |  |  | $ | 581 |  |  | $ | 2,019 |  |

[0001571996-18-000004:notes:245]
| (a) | The Company classified the results of ECD as discontinued operations for the period from September 7, 2016 through February 3, 2017 because the ECD business was only included in the Company's consolidated results since the closing of the EMC merger transaction on September 7, 2016. |

[0001571996-18-000004:notes:246]
|  | Fiscal Year Ended January 29, 2016 |
|  | Dell Services |  | DSG |  | Total |
|  | (in millions) |
| Net revenue | $ | 2,686 |  |  | $ | 1,289 |  |  | $ | 3,975 |  |
| Cost of net revenue | 2,157 |  |  | 373 |  |  | 2,530 |  |
| Operating expenses | 399 |  |  | 915 |  |  | 1,314 |  |
| Interest and other, net | — |  |  | (20 | ) |  | (20 | ) |
| Loss from discontinued operations before income taxes | 130 |  |  | (19 | ) |  | 111 |  |
| Income tax benefit | 42 |  |  | 5 |  |  | 47 |  |
| Loss from discontinued operations, net of income taxes | $ | 88 |  |  | $ | (24 | ) |  | $ | 64 |  |

[0001571996-18-000004:notes:247]
Cash flows from the Company's discontinued operations are included in the accompanying Consolidated Statements of Cash Flows.  The significant cash flow items from Dell Services and DSG for the fiscal years ended February 3, 2017 and January 29, 2016 were as follows:

[0001571996-18-000004:notes:248]
|  | Fiscal Year Ended |
|  | February 3, 2017 |  | January 29, 2016 |
| Depreciation and amortization (a) | $ | 32 |  |  | $ | 211 |  |
| Capital expenditures | $ | 82 |  |  | $ | 91 |  |

[0001571996-18-000004:notes:249]
| (a) | Depreciation and amortization ceased upon determination that Dell Services and DSG had met the criteria for discontinued operations reporting as of March 27, 2016 and June 19, 2016, respectively. Depreciation and amortization for ECD ceased upon determination that the held for sale criteria were met as of September 7, 2016, concurrently with the closing of the EMC merger transaction. |

[0001571996-18-000004:notes:250]
Depreciation and amortization for ECD ceased upon determination that the held-for-sale criteria were met.  Capital expenditures for ECD were immaterial for the period from September 7, 2016 through October 28, 2016.


## us-gaap:EarningsPerShareTextBlock

[0001571996-18-000004:notes:251]
EARNINGS (LOSS) PER SHARE

[0001571996-18-000004:notes:252]
Basic earnings (loss) per share is based on the weighted-average effect of all common shares issued and outstanding and is calculated by dividing net income (loss) by the weighted-average shares outstanding during the period.  Diluted earnings (loss) per share is calculated by dividing net income (loss) by the weighted-average number of common shares used in the basic earnings (loss) per share calculation plus the number of common shares that would be issued assuming exercise or conversion of all potentially dilutive instruments.  The Company excludes equity instruments from the calculation of diluted earnings (loss) per share if the effect of including such instruments is antidilutive.

[0001571996-18-000004:notes:253]
The Company has two groups of common stock, denoted as the DHI Group Common Stock and the Class V Common Stock.  The DHI Group Common Stock consists of four classes of common stock, referred to as Class A Common Stock, Class B Common Stock, Class C Common Stock, and Class D Common Stock.  The DHI Group generally refers to the direct and indirect interest of Dell Technologies in all of Dell Technologies' business, assets, properties, liabilities, and preferred stock other than those attributable to the Class V Group, as well as the DHI Group's retained interest in the Class V Group equal to approximately 39% of the Company's economic interest in the Class V Group as of February 2, 2018.  The Class V Common Stock is intended to track the economic performance of approximately 61% of the Company's economic interest in the Class V Group as of such date.  The Class V Group consists solely of VMware, Inc. common stock held by the Company.  As of February 2, 2018, the Class V Group consisted of approximately 331 million shares of VMware, Inc. common stock.  See Note 18 of the Notes to the Consolidated Financial Statements and Exhibit 99.1 filed with the annual report on Form 10-K for the fiscal year ended February 2, 2018 for more information regarding the allocation of earnings from Dell Technologies' interest in VMware, Inc. between the DHI Group and the Class V Common Stock.

[0001571996-18-000004:notes:254]
For purposes of calculating earnings (loss) per share, the Company used the two-class method.  As all classes of DHI Group Common Stock share the same rights in dividends, basic and diluted earnings (loss) per share are the same for each class of DHI Group Common Stock.

[0001571996-18-000004:notes:255]
The following table sets forth basic and diluted earnings (loss) per share for each of the periods presented:

[0001571996-18-000004:notes:256]
|  | Fiscal Year Ended |
|  | February 2, 2018 |  | February 3, 2017 |  | January 29, 2016 |
|  | (in millions) |
| Earnings (loss) per share attributable to Dell Technologies Inc. - basic: |
| Continuing operations - Class V Common Stock - basic | $ | 1.41 |  |  | $ | 1.44 |  |  | $ | — |  |
| Continuing operations - DHI Group - basic | $ | (7.08 | ) |  | $ | (8.52 | ) |  | $ | (2.88 | ) |
| Discontinued operations - DHI Group - basic | $ | — |  |  | $ | 4.30 |  |  | $ | 0.16 |  |
| Earnings (loss) per share attributable to Dell Technologies Inc. - diluted: |
| Continuing operations - Class V Common Stock - diluted | $ | 1.39 |  |  | $ | 1.43 |  |  | $ | — |  |
| Continuing operations - DHI Group - diluted | $ | (7.08 | ) |  | $ | (8.52 | ) |  | $ | (2.88 | ) |
| Discontinued operations - DHI Group - diluted | $ | — |  |  | $ | 4.30 |  |  | $ | 0.16 |  |

[0001571996-18-000004:notes:257]
The following table sets forth the computation of basic and diluted earnings (loss) per share for each of the periods presented:

[0001571996-18-000004:notes:258]
|  | Fiscal Year Ended |
|  | February 2, 2018 |  | February 3, 2017 |  | January 29, 2016 |
|  | (in millions) |
| Numerator: Continuing operations - Class V Common Stock |  |  |  |  |  |
| Net income from continuing operations attributable to Class V Common Stock - basic | $ | 286 |  |  | $ | 313 |  |  | $ | — |  |
| Incremental dilution from VMware, Inc. attributable to Class V Common Stock (a) | (4 | ) |  | (3 | ) |  | — |  |
| Net income from continuing operations attributable to Class V Common Stock - diluted | $ | 282 |  |  | $ | 310 |  |  | $ | — |  |
| Numerator: Continuing operations - DHI Group |  |  |  |  |  |
| Net loss from continuing operations attributable to DHI Group - basic | $ | (4,014 | ) |  | $ | (4,004 | ) |  | $ | (1,168 | ) |
| Incremental dilution from VMware, Inc. attributable to DHI Group (a) | (3 | ) |  | (2 | ) |  | — |  |
| Net loss from continuing operations attributable to DHI Group - diluted | $ | (4,017 | ) |  | $ | (4,006 | ) |  | $ | (1,168 | ) |
| Numerator: Discontinued operations - DHI Group |  |  |  |  |  |
| Income from discontinued operations, net of income taxes - basic and diluted | $ | — |  |  | $ | 2,019 |  |  | $ | 64 |  |
| Denominator: Class V Common Stock weighted-average shares outstanding |  |  |  |  |  |  |  |  |
| Weighted-average shares outstanding - basic | 203 |  |  | 217 |  |  | — |  |
| Dilutive effect of options, restricted stock units, restricted stock, and other (b) | — |  |  | — |  |  | — |  |
| Weighted-average shares outstanding - diluted | 203 |  |  | 217 |  |  | — |  |
| Weighted-average shares outstanding - antidilutive (b) | — |  |  | — |  |  | — |  |
| Denominator: DHI Group weighted-average shares outstanding |  |  |  |  |  |
| Weighted-average shares outstanding - basic | 567 |  |  | 470 |  |  | 405 |  |
| Dilutive effect of options, restricted stock units, restricted stock, and other | — |  |  | — |  |  | — |  |
| Weighted-average shares outstanding - diluted | 567 |  |  | 470 |  |  | 405 |  |
| Weighted-average shares outstanding - antidilutive (c) | 35 |  |  | 31 |  |  | 53 |  |

[0001571996-18-000004:notes:259]
| (a) | The incremental dilution from VMware, Inc. represents the impact of VMware, Inc.'s dilutive securities on the diluted earnings (loss) per share of the DHI Group and the Class V Common Stock, respectively, and is calculated by multiplying the difference between VMware, Inc.'s basic and diluted earnings (loss) per share by the number of shares of VMware, Inc. Class A common stock owned by the Company. |

[0001571996-18-000004:notes:260]
| (b) | The dilutive effect of Class V Common Stock-based incentive awards was not material to the calculation of the weighted-average Class V Common Stock shares outstanding. The antidilutive effect of these awards was also not material. |

[0001571996-18-000004:notes:261]
| (c) | Stock-based incentive awards have been excluded from the calculation of the DHI Group's diluted earnings (loss) per share because their effect would have been antidilutive, as the Company had a net loss from continuing operations attributable to the DHI Group for the periods presented. |


## us-gaap:FairValueDisclosuresTextBlock

[0001571996-18-000004:notes:262]
FAIR VALUE MEASUREMENTS

[0001571996-18-000004:notes:263]
The following table presents the Company's hierarchy for its assets and liabilities measured at fair value on a recurring basis as of February 2, 2018 and February 3, 2017:

[0001571996-18-000004:notes:264]
|  | February 2, 2018 (a) |  | February 3, 2017 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | QuotedPricesin ActiveMarkets forIdenticalAssets |  | SignificantOtherObservableInputs |  | SignificantUnobservableInputs |  |  |  | QuotedPricesin ActiveMarkets forIdenticalAssets |  | SignificantOtherObservableInputs |  | SignificantUnobservableInputs |  |  |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 8,641 |  |  | $ | — |  |  | $ | — |  |  | $ | 8,641 |  |  | $ | 4,866 |  |  | $ | — |  |  | $ | — |  |  | $ | 4,866 |  |
| Municipal obligations | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 3 |  |  | — |  |  | 3 |  |
| U.S. corporate debt securities | — |  |  | 23 |  |  | — |  |  | 23 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Foreign corporate debt securities | — |  |  | 65 |  |  | — |  |  | 65 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Debt securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government and agencies | 682 |  |  | 392 |  |  | — |  |  | 1,074 |  |  | 444 |  |  | 470 |  |  | — |  |  | 914 |  |
| U.S. corporate | — |  |  | 2,003 |  |  | — |  |  | 2,003 |  |  | — |  |  | 1,800 |  |  | — |  |  | 1,800 |  |
| Foreign | — |  |  | 2,547 |  |  | — |  |  | 2,547 |  |  | — |  |  | 2,083 |  |  | — |  |  | 2,083 |  |
| Municipal obligations | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 352 |  |  | — |  |  | 352 |  |
| Asset-backed securities | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Equity and other securities | 236 |  |  | 5 |  |  | — |  |  | 241 |  |  | 169 |  |  | — |  |  | — |  |  | 169 |  |
| Derivative instruments | — |  |  | 83 |  |  | — |  |  | 83 |  |  | — |  |  | 205 |  |  | — |  |  | 205 |  |
| Total assets | $ | 9,559 |  |  | $ | 5,118 |  |  | $ | — |  |  | $ | 14,677 |  |  | $ | 5,479 |  |  | $ | 4,917 |  |  | $ | — |  |  | $ | 10,396 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative instruments | $ | — |  |  | $ | 184 |  |  | $ | — |  |  | $ | 184 |  |  | $ | — |  |  | $ | 64 |  |  | $ | — |  |  | $ | 64 |  |
| Total liabilities | $ | — |  |  | $ | 184 |  |  | $ | — |  |  | $ | 184 |  |  | $ | — |  |  | $ | 64 |  |  | $ | — |  |  | $ | 64 |  |

[0001571996-18-000004:notes:265]
(a)   The Company did not transfer any securities between levels during the fiscal year ended February 2, 2018.

[0001571996-18-000004:notes:266]
The following section describes the valuation methodologies the Company uses to measure financial instruments at fair value:

[0001571996-18-000004:notes:267]
Money Market Funds — The Company's investment in money market funds that are classified as cash equivalents hold underlying investments with a weighted average maturity of 90 days or less and are recognized at fair value.  The valuations of these securities are based on quoted prices in active markets for identical assets, when available, or pricing models whereby all significant inputs are observable or can be derived from or corroborated by observable market data.  The Company reviews security pricing and assesses liquidity on a quarterly basis.  As of February 2, 2018, the Company's U.S. portfolio had no material exposure to money market funds with a fluctuating net asset value.

[0001571996-18-000004:notes:268]
Equity and Other Securities — The majority of the Company's investments in equity and other securities that are measured at fair value on a recurring basis consist of strategic investments in publicly traded companies.  The valuation of these securities is based on quoted prices in active markets.

[0001571996-18-000004:notes:269]
Debt Securities — The majority of the Company's debt securities consists of various fixed income securities such as U.S. government and agencies, U.S. corporate, and foreign.  Valuation is based on pricing models whereby all significant inputs, including benchmark yields, reported trades, broker-dealer quotes, issue spreads, benchmark securities, bids, offers, and other market related data, are observable or can be derived from or corroborated by observable market data for substantially the full term of the asset.  Inputs are documented in accordance with the fair value measurements hierarchy.  The Company reviews security pricing and assesses liquidity on a quarterly basis.  See Note 6 of the Notes to the Consolidated Financial Statements for additional information about investments.

[0001571996-18-000004:notes:270]
Derivative Instruments — The Company's derivative financial instruments consist primarily of foreign currency forward and purchased option contracts and interest rate swaps.  The fair value of the portfolio is determined using valuation models based on market observable inputs, including interest rate curves, forward and spot prices for currencies, and implied volatilities.  Credit risk is also factored into the fair value calculation of the Company's derivative instrument portfolio.  See Note 9 of the Notes to the Consolidated Financial Statements for a description of the Company's derivative financial instrument activities.

[0001571996-18-000004:notes:271]
Assets and Liabilities Measured at Fair Value on a Nonrecurring Basis — Certain assets are measured at fair value on a nonrecurring basis and therefore are not included in the recurring fair value table above.  These assets consist primarily of non-financial assets such as goodwill and intangible assets.  See Note 10 of the Notes to the Consolidated Financial Statements for additional information about goodwill and intangible assets.

[0001571996-18-000004:notes:272]
As of February 2, 2018 and February 3, 2017, the Company held strategic investments of $485 million and $455 million, respectively.  These investments are accounted for under the cost method and are not included in the recurring fair value table above.  Investments accounted for under the cost method are recorded at cost initially, which approximates fair value.  Subsequently, if there is an indicator of impairment, the impairment is recognized.  In evaluating these investments for impairment, the Company uses inputs including pre- and post-money valuations of recent financing events and the impact of those on its fully diluted ownership percentages, as well as other available information regarding the issuer's historical and forecasted performance.  As these investments are early-stage companies which are not publicly traded, it is not practicable for the Company to reliably estimate the fair value of these investments.

[0001571996-18-000004:notes:273]
Carrying Value and Estimated Fair Value of Outstanding Debt — The following table summarizes the carrying value and estimated fair value of the Company's outstanding debt as described in Note 8 of the Notes to the Consolidated Financial Statements, including the current portion, as of the dates indicated:

[0001571996-18-000004:notes:274]
|  | February 2, 2018 |  | February 3, 2017 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Secured Credit Facilities | $ | 10.4 |  |  | $ | 10.6 |  |  | $ | 11.4 |  |  | $ | 11.7 |  |
| First Lien Notes | $ | 19.7 |  |  | $ | 21.9 |  |  | $ | 19.7 |  |  | $ | 21.8 |  |
| Unsecured Notes and Debentures | $ | 2.3 |  |  | $ | 2.5 |  |  | $ | 2.3 |  |  | $ | 2.5 |  |
| Senior Notes | $ | 3.1 |  |  | $ | 3.4 |  |  | $ | 3.1 |  |  | $ | 3.5 |  |
| EMC Notes | $ | 5.5 |  |  | $ | 5.4 |  |  | $ | 5.5 |  |  | $ | 5.4 |  |
| VMware Notes | $ | 4.0 |  |  | $ | 3.9 |  |  | $ | — |  |  | $ | — |  |
| Margin Bridge Facility | $ | — |  |  | $ | — |  |  | $ | 2.5 |  |  | $ | 2.5 |  |
| Margin Loan Facility | $ | 2.0 |  |  | $ | 2.0 |  |  | $ | — |  |  | $ | — |  |
| VMware Note Bridge Facility | $ | — |  |  | $ | — |  |  | $ | 1.5 |  |  | $ | 1.5 |  |

[0001571996-18-000004:notes:275]
The fair values of the outstanding debt shown in the table above, as well as the DFS debt, were determined based on observable market prices in a less active market or based on valuation methodologies using observable inputs and were categorized as Level 2 in the fair value hierarchy.  The fair value of DFS debt approximates carrying value.


## us-gaap:FinancingReceivableCreditQualityIndicatorsTableTextBlock

[0001571996-18-000004:notes:276]
The following table summarizes customer receivables, gross, including accrued interest, by credit quality indicator segregated by class, as of February 2, 2018 and February 3, 2017.  The categories shown in the table below segregate customer receivables based on the relative degrees of credit risk.  The credit quality indicators for DPA revolving accounts are measured primarily as of each quarter-end date, while all other indicators are generally updated on a periodic basis.

[0001571996-18-000004:notes:277]
For DPA revolving receivables shown in the table below, the Company makes credit decisions based on proprietary scorecards, which include the customer's credit history, payment history, credit usage, and other credit agency-related elements.  The higher quality category includes prime accounts generally of a higher credit quality that are comparable to U.S. customer FICO scores of 720 or above.  The mid-category represents the mid-tier accounts that are comparable to U.S. customer FICO scores from 660 to 719.  The lower category is generally sub-prime and represents lower credit quality accounts that are comparable to U.S. customer FICO scores below 660.  For the DBC revolving receivables and fixed-term commercial receivables shown in the table below, an internal grading system is utilized that assigns a credit level score based on a number of considerations, including liquidity, operating performance, and industry outlook.  The grading criteria and classifications for the fixed-term products differ from those for the revolving products as loss experience varies between these product and customer groups.  The credit quality categories cannot be compared between the different classes as loss experience varies substantially between the classes.

[0001571996-18-000004:notes:278]
|  | February 2, 2018 |  | February 3, 2017 |
|  | Higher |  | Mid |  | Lower |  | Total |  | Higher |  | Mid |  | Lower |  | Total |
|  | (in millions) |
| Revolving — DPA | $ | 131 |  |  | $ | 223 |  |  | $ | 361 |  |  | $ | 715 |  |  | $ | 136 |  |  | $ | 244 |  |  | $ | 428 |  |  | $ | 808 |  |
| Revolving — DBC | $ | 48 |  |  | $ | 58 |  |  | $ | 79 |  |  | $ | 185 |  |  | $ | 61 |  |  | $ | 60 |  |  | $ | 80 |  |  | $ | 201 |  |
| Fixed-term — Consumer and Commercial (a) | $ | 3,334 |  |  | $ | 1,828 |  |  | $ | 1,120 |  |  | $ | 6,282 |  |  | $ | 2,232 |  |  | $ | 1,428 |  |  | $ | 870 |  |  | $ | 4,530 |  |

[0001571996-18-000004:notes:279]
| (a) | During the three months ended May 5, 2017, the Company modified its credit scoring methodology for fixed-term financing receivables in response to changes in its go-to-market strategy. This methodology has been modified to a single, consistent, and comparable model across all fixed-term product customers. In connection with this change, the Company has recategorized existing fixed-term customers and has recast prior period credit quality categories to align with the current period presentation. |


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0001571996-18-000004:notes:280]
The majority of the Company's international sales are made by international subsidiaries, most of which have the U.S. dollar as their functional currency.  The Company's subsidiaries that do not have the U.S. dollar as their functional currency translate assets and liabilities at current rates of exchange in effect at the balance sheet date.  Revenue and expenses from these international subsidiaries are translated using the monthly average exchange rates in effect for the period in which the transactions occur.  Foreign currency translation adjustments are included as a component of accumulated other comprehensive income (loss) ("OCI") in stockholders' equity.

[0001571996-18-000004:notes:281]
Local currency transactions of international subsidiaries that have the U.S. dollar as the functional currency are remeasured into U.S. dollars using the current rates of exchange for monetary assets and liabilities and historical rates of exchange for non-monetary assets and liabilities.  Gains and losses from remeasurement of monetary assets and liabilities are included in interest and other, net.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001571996-18-000004:notes:282]
GOODWILL AND INTANGIBLE ASSETS

[0001571996-18-000004:notes:283]
Goodwill

[0001571996-18-000004:notes:284]
The following table presents goodwill allocated to the Company's business segments as of February 2, 2018, February 3, 2017, and January 29, 2016 and changes in the carrying amount of goodwill for the respective periods:

[0001571996-18-000004:notes:285]
|  | Client Solutions Group |  | Infrastructure Solutions Group (a) |  | VMware |  | Other Businesses (b) |  | Total |
|  | (in millions) |
| Balances as of January 29, 2016 | $ | 4,428 |  |  | $ | 3,907 |  |  | $ | — |  |  | $ | 71 |  |  | $ | 8,406 |  |
| Goodwill acquired | — |  |  | 12,872 |  |  | 15,070 |  |  | 3,597 |  |  | 31,539 |  |
| Impact of foreign currency translation | — |  |  | (169 | ) |  | — |  |  | (32 | ) |  | (201 | ) |
| Goodwill divested | — |  |  | (834 | ) |  | — |  |  | — |  |  | (834 | ) |
| Other adjustments | (191 | ) |  | (169 | ) |  | — |  |  | 360 |  |  | — |  |
| Balances as of February 3, 2017 | 4,237 |  |  | 15,607 |  |  | 15,070 |  |  | 3,996 |  |  | 38,910 |  |
| Goodwill acquired | — |  |  | — |  |  | 565 |  |  | 9 |  |  | 574 |  |
| Impact of foreign currency translation | — |  |  | 359 |  |  | — |  |  | 90 |  |  | 449 |  |
| Goodwill divested | — |  |  | (13 | ) |  | — |  |  | — |  |  | (13 | ) |
| Balances as of February 2, 2018 | $ | 4,237 |  |  | $ | 15,953 |  |  | $ | 15,635 |  |  | $ | 4,095 |  |  | $ | 39,920 |  |

[0001571996-18-000004:notes:286]
| (a) | Infrastructure Solutions Group is composed of the Core Storage, Servers, and Networking goodwill reporting unit and Virtustream goodwill reporting unit. |

[0001571996-18-000004:notes:287]
| (b) | Other Businesses consists of offerings by RSA Information Security, SecureWorks, Pivotal, and Boomi. |

[0001571996-18-000004:notes:288]
Goodwill and indefinite-lived intangible assets are tested for impairment annually during the third fiscal quarter and whenever events or circumstances may indicate that an impairment has occurred.  Based on the results of the annual impairment test, which was a quantitative test for certain goodwill reporting units and a qualitative test for others, no impairment of goodwill or indefinite-lived intangible assets existed for any reporting unit as of November 3, 2017.  As a result of this analysis, it was determined that the excess of fair value over carrying amount was greater than 20% for all of the Company's existing goodwill reporting units as of November 3, 2017, with the exception of the Core Storage, Servers, and Networking goodwill reporting unit within the Infrastructure Solutions Group segment, which had an excess of fair value over carrying amount of 18% as of such date.  Management will continue to monitor the Core Storage, Servers, and Networking goodwill reporting unit and consider potential impacts to the impairment assessment.  Further, the Company did not have any accumulated goodwill impairment charges as of February 2, 2018.

[0001571996-18-000004:notes:289]
Management exercised significant judgment related to the above assessment, including the identification of goodwill reporting units, assignment of assets and liabilities to goodwill reporting units, assignment of goodwill to reporting units, and determination of the fair value of each goodwill reporting unit.  The fair value of each goodwill reporting unit is generally estimated using a combination of public company multiples and discounted cash flow methodologies.  This analysis requires significant judgment, including estimation of future cash flows, which is dependent on internal forecasts, the estimation of the long-term growth rate of the Company's business, and the determination of the Company's weighted average cost of capital.  Changes in these estimates and assumptions could materially affect the fair value of the goodwill reporting unit, potentially resulting in a non-cash impairment charge.

[0001571996-18-000004:notes:290]
Intangible Assets

[0001571996-18-000004:notes:291]
The Company's intangible assets as of February 2, 2018 and February 3, 2017 were as follows:

[0001571996-18-000004:notes:292]
|  | February 2, 2018 |  | February 3, 2017 |
|  | Gross |  | AccumulatedAmortization |  | Net |  | Gross |  | AccumulatedAmortization |  | Net |
|  | (in millions) |
| Customer relationships | $ | 22,764 |  |  | $ | (8,637 | ) |  | $ | 14,127 |  |  | $ | 22,708 |  |  | $ | (5,552 | ) |  | $ | 17,156 |  |
| Developed technology | 15,586 |  |  | (6,196 | ) |  | 9,390 |  |  | 14,569 |  |  | (2,510 | ) |  | 12,059 |  |
| Trade names | 1,277 |  |  | (407 | ) |  | 870 |  |  | 1,268 |  |  | (201 | ) |  | 1,067 |  |
| Leasehold assets (liabilities) | 128 |  |  | (6 | ) |  | 122 |  |  | 128 |  |  | (1 | ) |  | 127 |  |
| Definite-lived intangible assets | 39,755 |  |  | (15,246 | ) |  | 24,509 |  |  | 38,673 |  |  | (8,264 | ) |  | 30,409 |  |
| In-process research and development | — |  |  | — |  |  | — |  |  | 890 |  |  | — |  |  | 890 |  |
| Indefinite-lived trade names | 3,756 |  |  | — |  |  | 3,756 |  |  | 3,754 |  |  | — |  |  | 3,754 |  |
| Total intangible assets | $ | 43,511 |  |  | $ | (15,246 | ) |  | $ | 28,265 |  |  | $ | 43,317 |  |  | $ | (8,264 | ) |  | $ | 35,053 |  |

[0001571996-18-000004:notes:293]
Amortization expense related to definite-lived intangible assets was approximately $7.0 billion, $3.7 billion, and $2.0 billion for the fiscal years ended February 2, 2018, February 3, 2017, and January 29, 2016, respectively.  The amortization expense for the fiscal year ended February 2, 2018 was primarily related to the intangible assets acquired in the EMC merger transaction.  There were no material impairment charges related to intangible assets during the fiscal years ended February 2, 2018, February 3, 2017, and January 29, 2016.

[0001571996-18-000004:notes:294]
Estimated future annual pre-tax amortization expense of definite-lived intangible assets as of February 2, 2018 over the next five fiscal years and thereafter is as follows:

[0001571996-18-000004:notes:295]
| Fiscal Years | (in millions) |
| 2019 | $ | 6,083 |  |
| 2020 | 4,297 |  |
| 2021 | 3,356 |  |
| 2022 | 2,638 |  |
| 2023 | 1,754 |  |
| Thereafter | 6,381 |  |
| Total | $ | 24,509 |  |


## us-gaap:GoodwillAndIntangibleAssetsPolicyTextBlock

[0001571996-18-000004:notes:296]
Identifiable intangible assets with finite lives are amortized over their estimated useful lives.  Intangible assets are reviewed for impairment when events and circumstances indicate the asset may be impaired.  Goodwill and indefinite-lived intangible assets are tested for impairment annually during the third fiscal quarter and whenever events or circumstances indicate that an impairment may have occurred.


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsPolicyTextBlock

[0001571996-18-000004:notes:297]
The Company reviews long-lived assets for impairment when events or changes in circumstances indicate the carrying amount of an asset may not be recoverable.  The Company assesses the recoverability of the assets based on the undiscounted future cash flows expected from the use and eventual disposition of the asset.  If the carrying amount of the asset is determined not to be recoverable, a write-down to fair value is recorded.  Fair values are determined based on quoted market values, discounted cash flows, or external appraisals, as applicable.  Long-lived assets to be disposed of are reported at the lower of carrying amount or fair value less costs to sell.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001571996-18-000004:notes:298]
INCOME AND OTHER TAXES

[0001571996-18-000004:notes:299]
On December 22, 2017, the Tax Cuts and Jobs Act of 2017 (“U.S. Tax Reform” or the “Act”) was signed into law.  Among other things, U.S. Tax Reform lowers the U.S. corporate income tax rate to 21% from 35% and establishes a modified territorial system requiring a mandatory deemed repatriation tax on undistributed earnings of foreign subsidiaries (the “Transition Tax”).  For Fiscal 2019, U.S. Tax Reform also requires a minimum tax on certain future earnings generated by foreign subsidiaries while providing for future tax-free repatriation of earnings through a 100% dividends-received deduction, and places limitations on the deductibility of net interest expense.

[0001571996-18-000004:notes:300]
GAAP requires the effect of a change in tax laws to be recognized in the period that includes the enactment date.  Due to the complexities involved in accounting for the enactment of U.S. Tax Reform, the SEC staff issued Staff Accounting Bulletin No. 118 (“SAB 118”), which allows companies to record provisional amounts in earnings for the first year following the Act's enactment, with those provisional amounts required to be finalized by the end of that year.  In accordance with GAAP and SAB 118, the Company recognized a provisional tax benefit in the fourth quarter of Fiscal 2018 of $0.3 billion related to U.S. Tax Reform, primarily driven by a $1.3 billion tax benefit related to the remeasurement of deferred tax assets and liabilities, offset by $1.0 billion current and future income tax expenses related to the Transition Tax.  The Company’s provisional estimates are based on its initial analysis using available information and estimates.  Given the significant complexity of U.S. Tax Reform, anticipated guidance from the U.S. Treasury, the potential for additional guidance from the SEC or the FASB related to the Act, or additional information becoming available, in accordance with SAB 118, the Company’s provisional benefit may be adjusted during Fiscal 2019 and will be finalized no later than the fourth quarter of Fiscal 2019.  Revisions to the Company’s provisional estimates may be material to the Company.

[0001571996-18-000004:notes:301]
The Company's provision for income taxes for the fiscal periods reflected in the Consolidated Financial Statements are not directly comparable primarily due to U.S. Tax Reform in Fiscal 2018 as well as purchase accounting adjustments, interest charges, and stock-based compensation charges incurred as a result of the EMC merger transaction that was completed in Fiscal 2017.  For more information regarding the EMC merger transaction, see Note 3 of the Notes to the Consolidated Financial Statements.

[0001571996-18-000004:notes:302]
The provision (benefit) for income taxes from continuing operations consisted of the following for the respective periods:

[0001571996-18-000004:notes:303]
|  | Fiscal Year Ended |
|  | February 2, 2018 |  | February 3, 2017 |  | January 29, 2016 |
|  | (in millions) |
| Current: |  |  |  |  |  |
| Federal | $ | 52 |  |  | $ | (139 | ) |  | $ | (174 | ) |
| State/local | 111 |  |  | 46 |  |  | (2 | ) |
| Foreign | 599 |  |  | 322 |  |  | 228 |  |
| Current | 762 |  |  | 229 |  |  | 52 |  |
| Deferred: |  |  |  |  |  |
| Federal | (2,301 | ) |  | (1,676 | ) |  | (119 | ) |
| State/local | (156 | ) |  | (120 | ) |  | (15 | ) |
| Foreign | (138 | ) |  | (52 | ) |  | (36 | ) |
| Deferred | (2,595 | ) |  | (1,848 | ) |  | (170 | ) |
| Provision (benefit) for income taxes | $ | (1,833 | ) |  | $ | (1,619 | ) |  | $ | (118 | ) |

[0001571996-18-000004:notes:304]
The Company's income (loss) from continuing operations before income taxes consisted of the following for the respective periods:

[0001571996-18-000004:notes:305]
|  | Fiscal Year Ended |
|  | February 2, 2018 |  | February 3, 2017 |  | January 29, 2016 |
|  | (in millions) |
| Domestic | $ | (6,494 | ) |  | $ | (7,173 | ) |  | $ | (3,498 | ) |
| Foreign | 806 |  |  | 1,817 |  |  | 2,212 |  |
| Loss from continuing operations before income taxes | $ | (5,688 | ) |  | $ | (5,356 | ) |  | $ | (1,286 | ) |

[0001571996-18-000004:notes:306]
A reconciliation of the Company's income tax benefit from continuing operations to the statutory U.S. federal tax rate is as follows:

[0001571996-18-000004:notes:307]
|  | Fiscal Year Ended |
|  | February 2, 2018 |  | February 3, 2017 |  | January 29, 2016 |
| U.S. federal statutory rate | 33.7 | % |  | 35.0 | % |  | 35.0 | % |
| State income taxes, net of federal tax benefit | 2.7 |  |  | 2.7 |  |  | 1.9 |  |
| Tax impact of foreign operations | (8.0 | ) |  | (4.9 | ) |  | (33.4 | ) |
| Change in valuation allowance impacting tax rate and non-deductible operating losses | (1.7 | ) |  | (1.1 | ) |  | 4.2 |  |
| U.S. Tax Reform | 5.6 |  |  | — |  |  | — |  |
| IRS tax audit settlement | — |  |  | 5.5 |  |  | — |  |
| Vendor and other settlements | 0.4 |  |  | 0.5 |  |  | 2.5 |  |
| Non-deductible transaction-related costs | — |  |  | (2.1 | ) |  | (0.6 | ) |
| Other | (0.5 | ) |  | (5.4 | ) |  | (0.4 | ) |
| Total | 32.2 | % |  | 30.2 | % |  | 9.2 | % |

[0001571996-18-000004:notes:308]
A portion of the Company's operations is subject to a reduced tax rate or is free of tax under various tax holidays.  For the fiscal years ended February 2, 2018, February 3, 2017, and January 29, 2016, the income tax benefits attributable to the tax status of the affected subsidiaries were estimated to be approximately $238 million ($0.42 per share of DHI Group Common Stock), $369 million ($0.79 per share of DHI Group Common Stock), and $205 million ($0.51 per share of DHI Group Common Stock), respectively.  These income tax benefits are included in tax impact of foreign operations in the table above.  Although a significant portion of these income tax benefits relate to a tax holiday that expired during the fiscal year ended February 3, 2017, the Company has negotiated new terms for the affected subsidiary.  These new terms provide for a reduced income tax rate and will be effective for a two-year bridge period expiring at the end of Fiscal 2019.  The Company is currently seeking new terms for the affected subsidiary beyond Fiscal 2019 and it is uncertain whether any terms will be agreed upon.  The Company's other tax holidays will expire in whole or in part during Fiscal 2019 through Fiscal 2023.  Many of these tax holidays and reduced tax rates may be extended when certain conditions are met or may be terminated early if certain conditions are not met.

[0001571996-18-000004:notes:309]
Prior to U.S. Tax Reform, the Company had not provided deferred taxes on undistributed earnings and other outside basis differences of its foreign subsidiaries as it was the Company's intention for these basis differences to remain indefinitely reinvested.  U.S. Tax Reform fundamentally changes the U.S. approach to taxation of foreign earnings to a partial territorial tax system, which generally allows companies to make distributions of non-U.S. earnings to the United States without incurring additional U.S. tax.  Additionally, as a result of the Transition Tax, substantially all of the Company’s undistributed earnings as of December 31, 2017 will not be subject to further U.S. federal income taxation.  As a result, as of February 2, 2018, the Company intends to repatriate certain foreign earnings that have been taxed in the United States to the extent the foreign earnings are not restricted by local laws and can be accessed in a cost-effective manner.  The Company recorded an immaterial deferred tax liability for the additional non-U.S. taxes which are expected to be incurred related to the repatriation of these earnings.

[0001571996-18-000004:notes:310]
The Company carries other outside basis differences in its subsidiaries, primarily arising from purchase accounting adjustments, undistributed earnings that are considered indefinitely reinvested, and foreign earnings that are restricted by local laws or are cost prohibitive for repatriation.  As of February 2, 2018, the Company has not recognized deferred income tax on $68.2 billion of outside basis differences because it has the intent and ability to indefinitely reinvest these basis differences.  These basis differences could be reversed through a sale of the subsidiaries or the receipt of dividends from the subsidiaries, as well as various other events, none of which are considered probable as of the date of the Company’s annual report on Form 10‑K for the fiscal year ended February 2, 2018.  Determination of the amount of unrecognized deferred income tax liability related to these outside basis differences is not practicable.

[0001571996-18-000004:notes:311]
The components of the Company's net deferred tax assets (liabilities) were as follows as of February 2, 2018 and February 3, 2017:

[0001571996-18-000004:notes:312]
|  | February 2, 2018 |  | February 3, 2017 |
|  | (in millions) |
| Deferred tax assets: |  |  |  |
| Deferred revenue and warranty provisions | $ | 1,447 |  |  | $ | 1,955 |  |
| Provisions for product returns and doubtful accounts | 115 |  |  | 131 |  |
| Credit carryforwards | 540 |  |  | 511 |  |
| Loss carryforwards | 509 |  |  | 372 |  |
| Operating and compensation related accruals | 604 |  |  | 765 |  |
| Other | 122 |  |  | 262 |  |
| Deferred tax assets | 3,337 |  |  | 3,996 |  |
| Valuation allowance | (815 | ) |  | (737 | ) |
| Deferred tax assets, net of valuation allowance | 2,522 |  |  | 3,259 |  |
| Deferred tax liabilities: |  |  |  |
| Leasing and financing | (178 | ) |  | (109 | ) |
| Property and equipment | (483 | ) |  | (743 | ) |
| Acquired intangibles | (4,004 | ) |  | (7,281 | ) |
| Other | (194 | ) |  | (38 | ) |
| Deferred tax liabilities | (4,859 | ) |  | (8,171 | ) |
| Net deferred tax assets (liabilities) | $ | (2,337 | ) |  | $ | (4,912 | ) |

[0001571996-18-000004:notes:313]
The tables below summarize the net operating loss carryforwards, tax credit carryforwards, and other deferred tax assets with related valuation allowances recognized as of February 2, 2018 and February 3, 2017:

[0001571996-18-000004:notes:314]
|  | February 2, 2018 |
|  | Deferred Tax Assets |  | Valuation Allowance |  | Net Deferred Tax Assets |  | First Year Expiring |
|  | (in millions) |
| Credit carryforwards | $ | 540 |  |  | $ | (366 | ) |  | $ | 174 |  |  | Fiscal 2019 |
| Loss carryforwards | 509 |  |  | (279 | ) |  | 230 |  |  | Fiscal 2019 |
| Other deferred tax assets | 2,288 |  |  | (170 | ) |  | 2,118 |  |  | NA |
| Total | $ | 3,337 |  |  | $ | (815 | ) |  | $ | 2,522 |  |  |  |
|  | February 3, 2017 |
|  | Deferred Tax Assets |  | Valuation Allowance |  | Net Deferred Tax Assets |  | First Year Expiring |
|  | (in millions) |
| Credit carryforwards | $ | 511 |  |  | $ | (406 | ) |  | $ | 105 |  |  | Fiscal 2018 |
| Loss carryforwards | 372 |  |  | (205 | ) |  | 167 |  |  | Fiscal 2018 |
| Other deferred tax assets | 3,113 |  |  | (126 | ) |  | 2,987 |  |  | NA |
| Total | $ | 3,996 |  |  | $ | (737 | ) |  | $ | 3,259 |  |  |  |

[0001571996-18-000004:notes:315]
The Company's credit carryforwards as of February 2, 2018 and February 3, 2017 relate primarily to U.S. tax credits.  The Company had deferred tax assets related to federal, state, and foreign net operating loss carryforwards of $96 million, $172 million, and $241 million, respectively, as of February 2, 2018, and $132 million, $62 million, and $178 million, respectively, as of February 3, 2017.  The valuation allowances for other deferred tax assets as of February 2, 2018 and February 3, 2017 are primarily related to foreign jurisdictions.  The Company has determined that it will be able to realize the remainder of its deferred tax assets, based on the future reversal of deferred tax liabilities.

[0001571996-18-000004:notes:316]
A reconciliation of the Company's beginning and ending balance of unrecognized tax benefits is as follows:

[0001571996-18-000004:notes:317]
|  | Fiscal Year Ended |
|  | February 2, 2018 |  | February 3, 2017 |  | January 29, 2016 |
|  | (in millions) |
| Balance, beginning of year | $ | 2,752 |  |  | $ | 2,479 |  |  | $ | 2,455 |  |
| Unrecognized tax benefits assumed through EMC merger transaction | — |  |  | 558 |  |  | — |  |
| Increases related to tax positions of the current year | 155 |  |  | 116 |  |  | 70 |  |
| Increases related to tax position of prior years | 98 |  |  | 227 |  |  | 52 |  |
| Reductions for tax positions of prior years | (90 | ) |  | (379 | ) |  | (61 | ) |
| Lapse of statute of limitations | (34 | ) |  | (30 | ) |  | (24 | ) |
| Audit settlements | (14 | ) |  | (219 | ) |  | (13 | ) |
| Balance, end of year | $ | 2,867 |  |  | $ | 2,752 |  |  | $ | 2,479 |  |

[0001571996-18-000004:notes:318]
During the fiscal year ended February 3, 2017, the Company acquired $558 million of unrecognized tax benefits in connection with the EMC merger transaction.  The Company's net unrecognized tax benefits were $3.2 billion and $3.1 billion as of February 2, 2018 and February 3, 2017, respectively, and are included in other non-current liabilities in the Consolidated Statements of Financial Position.

[0001571996-18-000004:notes:319]
The unrecognized tax benefits in the table above include $2.2 billion and $2.3 billion as of February 2, 2018 and February 3, 2017, respectively, that, if recognized, would have impacted income tax expense.  The table does not include accrued interest and penalties of $860 million and $737 million as of February 2, 2018 and February 3, 2017, respectively.  Tax benefits associated with interest and state tax deductions and other indirect jurisdictional effects of uncertain tax positions were $537 million and $286 million as of February 2, 2018 and February 3, 2017, respectively.  Interest and penalties related to income tax liabilities are included in income tax expense.  The Company recorded interest and penalties of $184 million, $94 million, and $63 million for the fiscal years ended February 2, 2018, February 3, 2017, and January 29, 2016, respectively.

[0001571996-18-000004:notes:320]
Judgment is required in evaluating the Company's uncertain tax positions and determining the Company's provision for income taxes.  The Company does not anticipate a significant change to the total amount of unrecognized tax benefits within the next twelve months.

[0001571996-18-000004:notes:321]
During the fiscal year ended February 3, 2017, the Company closed the Internal Revenue Service ("IRS") audit for fiscal years 2004 through 2006.  As a result, during Fiscal 2017, the Company recorded a net benefit to the provision for income taxes of $297 million.

[0001571996-18-000004:notes:322]
The Company's U.S. federal income tax returns for fiscal years 2007 through 2009 are currently under consideration by the Office of Appeals of the IRS.  The IRS issued a Revenue Agent's Report ("RAR") related to those years during the fiscal year ended February 3, 2017.  The IRS has proposed adjustments primarily relating to transfer pricing matters with which the Company disagrees and will contest through the IRS administrative appeals procedures.  In May 2017, the IRS commenced a federal income tax audit for fiscal years 2010 through 2014, which could take several years to complete.  Prior to the EMC merger transaction, EMC received a RAR for its tax years 2009 and 2010.  On May 5, 2017, EMC received an RAR for its tax year 2011.  The Company also disagrees with certain proposed adjustments in these RARs and is currently contesting the proposed adjustments through the IRS administrative appeals process.

[0001571996-18-000004:notes:323]
The Company is also currently under income tax audits in various state and foreign jurisdictions.  The Company is undergoing negotiations, and in some cases contested proceedings, relating to tax matters with the taxing authorities in these jurisdictions.  The Company believes that it has provided adequate reserves related to all matters contained in tax periods open to examination.  Although the Company believes it has made adequate provisions for the uncertainties surrounding these audits, should the Company experience unfavorable outcomes, such outcomes could have a material impact on its results of operations, financial position, and cash flows.  With respect to major U.S. state and foreign taxing jurisdictions, the Company is generally not subject to tax examinations for years prior to fiscal year 2007.

[0001571996-18-000004:notes:324]
The Company takes certain non-income tax positions in the jurisdictions in which it operates and has received certain non-income tax assessments from various jurisdictions.  The Company believes that a material loss in these matters is not probable and that it is not reasonably possible that a material loss exceeding amounts already accrued has been incurred.  The Company believes its positions in these non-income tax litigation matters are supportable and that it ultimately will prevail in the matters.  In the normal course of business, the Company's positions and conclusions related to its non-income taxes could be challenged and assessments may be made.  To the extent new information is obtained and the Company's views on its positions, probable outcomes of assessments, or litigation change, changes in estimates to the Company's accrued liabilities would be recorded in the period in which such a determination is made.  In the resolution process for income tax and non-income tax audits, in certain situations the Company will be required to provide collateral guarantees or indemnification to regulators and tax authorities until the matter is resolved.


## us-gaap:IncomeTaxPolicyTextBlock

[0001571996-18-000004:notes:325]
Deferred tax assets and liabilities are recorded based on the difference between the financial statement and tax basis of assets and liabilities using enacted tax rates in effect for the year in which the differences are expected to reverse.  The Company calculates a provision for income taxes using the asset and liability method, under which deferred tax assets and liabilities are recognized by identifying the temporary differences arising from the different treatment of items for tax and accounting purposes.  The Company provides valuation allowances for deferred tax assets, where appropriate.  In assessing the need for a valuation allowance, the Company considers all available evidence for each jurisdiction, including past operating results, estimates of future taxable income, and the feasibility of ongoing tax planning strategies.  In the event the Company determines that all or part of the net deferred tax assets are not realizable in the future, the Company will make an adjustment to the valuation allowance that would be charged to earnings in the period in which such determination is made.

[0001571996-18-000004:notes:326]
The Global Intangible Low-Taxed Income ("GILTI") provisions of the Tax Cuts and Reform Act signed into law on December 22, 2017 require the Company to include in its U.S. income tax return foreign subsidiary earnings in excess of an allowable return on the foreign subsidiary's tangible assets.  The Company has not yet elected an accounting policy related to how it will account for GILTI and therefore has not provided any deferred tax impacts of GILTI in its Consolidated Financial Statements for the fiscal year ended February 2, 2018.


## us-gaap:InventoryPolicyTextBlock

[0001571996-18-000004:notes:327]
Inventories are stated at the lower of cost or market with cost being determined on a first-in, first-out basis.  Adjustments to reduce the cost of inventory to its net realizable value are made, if required, for estimated excess, obsolescence, or impaired balances.


## us-gaap:InvestmentPolicyTextBlock

[0001571996-18-000004:notes:328]
All debt security investments with effective maturities in excess of one year and substantially all equity and other securities are recorded as long-term investments in the Consolidated Statements of Financial Position.  In comparison, debt security instruments with an effective maturity of one year or less are classified as short-term investments in the Consolidated Statements of Financial Position.

[0001571996-18-000004:notes:329]
Unrealized gain and loss positions on investments classified as available-for-sale are included within accumulated other comprehensive income (loss), net of any related tax effect.  Realized gains and losses and other-than-temporary impairments are reclassified from accumulated other comprehensive income (loss) to interest and other, net.  Investments accounted for under the cost method are recorded at cost initially, which approximates fair value.  Subsequently, if there is an indicator of impairment, the impairment is recognized in interest and other, net in the Consolidated Statements of Income (Loss).


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0001571996-18-000004:notes:330]
FINANCIAL SERVICES

[0001571996-18-000004:notes:331]
The Company offers or arranges various financing options and services for its customers in North America, Europe, Australia, and New Zealand through Dell Financial Services and its affiliates ("DFS").  The key activities of DFS include originating, collecting, and servicing customer receivables primarily related to the purchase of Dell Technologies products and services.  In some cases, DFS also offers financing on the purchase of third-party technology products that complement the Dell Technologies portfolio of products and services.  New financing originations were $6.3 billion, $4.5 billion, and $3.7 billion for the fiscal years ended February 2, 2018, February 3, 2017, and January 29, 2016, respectively.  The increases in new financing originations and financing receivables during the fiscal year ended February 2, 2018 were attributable to growth in the DFS offerings related to customer purchases of products and services from the EMC acquired businesses.

[0001571996-18-000004:notes:332]
In June 2017, as part of the global expansion of Dell Technologies' captive financing model, the Company purchased a portfolio of customer fixed-term financing receivables totaling approximately $89 million from Bank of Queensland.  Bank of Queensland was previously the Company's preferred financing partner in Australia and New Zealand.

[0001571996-18-000004:notes:333]
Financing Receivables

[0001571996-18-000004:notes:334]
The Company's financing receivables are aggregated into the following categories:

[0001571996-18-000004:notes:335]
| • | Revolving loans — Revolving loans offered under private label credit financing programs provide qualified customers with a revolving credit line for the purchase of products and services offered by Dell Technologies. These private label credit financing programs are referred to as Dell Preferred Account ("DPA") and Dell Business Credit ("DBC"). The DPA product is primarily offered to individual consumer customers, and the DBC product is primarily offered to small and medium-sized commercial customers. Revolving loans in the United States bear interest at a variable annual percentage rate that is tied to the prime rate. Based on historical payment patterns, revolving loan transactions are typically repaid within twelve months on average. |

[0001571996-18-000004:notes:336]
| • | Fixed-term sales-type leases and loans — The Company enters into sales-type lease arrangements with customers who seek lease financing. Leases with business customers have fixed terms of generally two to four years. Future maturities of minimum lease and associated financing payments as of February 2, 2018 were as follows: Fiscal 2019 - $2,210 million; Fiscal 2020 - $1,449 million; Fiscal 2021 - $717 million; Fiscal 2022 - $198 million; Fiscal 2023 and beyond - $48 million. Future maturities and associated financing payments referenced herein represent the aggregate payments under the customer lease contract. The Company also offers fixed-term loans to qualified small businesses, large commercial accounts, governmental organizations, educational entities, and certain individual consumer customers. These loans are repaid in equal payments including interest and have defined terms of generally three to five years. |

[0001571996-18-000004:notes:337]
The following table summarizes the components of the Company's financing receivables segregated by portfolio segment as of February 2, 2018 and February 3, 2017:

[0001571996-18-000004:notes:338]
|  | February 2, 2018 |  | February 3, 2017 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Financing receivables, net: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer receivables, gross | $ | 900 |  |  | $ | 6,282 |  |  | $ | 7,182 |  |  | $ | 1,009 |  |  | $ | 4,530 |  |  | $ | 5,539 |  |
| Allowances for losses | (81 | ) |  | (64 | ) |  | (145 | ) |  | (91 | ) |  | (52 | ) |  | (143 | ) |
| Customer receivables, net | 819 |  |  | 6,218 |  |  | 7,037 |  |  | 918 |  |  | 4,478 |  |  | 5,396 |  |
| Residual interest | — |  |  | 606 |  |  | 606 |  |  | — |  |  | 477 |  |  | 477 |  |
| Financing receivables, net | $ | 819 |  |  | $ | 6,824 |  |  | $ | 7,643 |  |  | $ | 918 |  |  | $ | 4,955 |  |  | $ | 5,873 |  |
| Short-term | $ | 819 |  |  | $ | 3,100 |  |  | $ | 3,919 |  |  | $ | 918 |  |  | $ | 2,304 |  |  | $ | 3,222 |  |
| Long-term | $ | — |  |  | $ | 3,724 |  |  | $ | 3,724 |  |  | $ | — |  |  | $ | 2,651 |  |  | $ | 2,651 |  |

[0001571996-18-000004:notes:339]
The following table summarizes the aging of the Company's customer financing receivables, gross, including accrued interest, as of February 2, 2018 and February 3, 2017, segregated by class:

[0001571996-18-000004:notes:340]
|  | February 2, 2018 |  | February 3, 2017 |
|  | Current |  | Past Due 1 — 90 Days |  | Past Due > 90 Days |  | Total |  | Current |  | Past Due 1 — 90 Days |  | Past Due > 90 Days |  | Total |
|  | (in millions) |
| Revolving — DPA | $ | 633 |  |  | $ | 59 |  |  | $ | 23 |  |  | $ | 715 |  |  | $ | 715 |  |  | $ | 66 |  |  | $ | 27 |  |  | $ | 808 |  |
| Revolving — DBC | 162 |  |  | 19 |  |  | 4 |  |  | 185 |  |  | 175 |  |  | 22 |  |  | 4 |  |  | 201 |  |
| Fixed-term — Consumer and Commercial | 5,414 |  |  | 775 |  |  | 93 |  |  | 6,282 |  |  | 3,994 |  |  | 506 |  |  | 30 |  |  | 4,530 |  |
| Total customer receivables, gross | $ | 6,209 |  |  | $ | 853 |  |  | $ | 120 |  |  | $ | 7,182 |  |  | $ | 4,884 |  |  | $ | 594 |  |  | $ | 61 |  |  | $ | 5,539 |  |

[0001571996-18-000004:notes:341]
The increase in the Company's fixed-term past due balances was attributable to administrative processes for larger transactions, and, to a lesser extent, additional originations from the EMC merger transaction, and does not indicate a deterioration in the credit quality of the portfolio.

[0001571996-18-000004:notes:342]
Credit Quality

[0001571996-18-000004:notes:343]
The Company maintains programs which facilitate the funding of financing receivables in the capital markets in North America, Europe, Australia, and New Zealand.  The following table summarizes DFS debt as of the periods indicated.

[0001571996-18-000004:notes:344]
|  | February 2, 2018 |  | February 3, 2017 |
|  | (in millions) |
| DFS U.S. debt |  |  |  |
| Securitization facilities | $ | 1,498 |  |  | $ | 1,481 |  |
| Fixed-term securitization offerings | 2,034 |  |  | 1,364 |  |
| Other | 32 |  |  | 4 |  |
| Total DFS U.S. debt | 3,564 |  |  | 2,849 |  |
| DFS international debt |  |  |  |
| Securitization facility | 404 |  |  | 233 |  |
| Other structured facilities | 628 |  |  | 382 |  |
| Note payable | 200 |  |  | — |  |
| Total DFS international debt | 1,232 |  |  | 615 |  |
| Total DFS debt | $ | 4,796 |  |  | $ | 3,464 |  |
| Total short-term DFS debt | $ | 3,327 |  |  | $ | 2,088 |  |
| Total long-term DFS debt | $ | 1,469 |  |  | $ | 1,376 |  |

[0001571996-18-000004:notes:345]
DFS U.S. Debt

[0001571996-18-000004:notes:346]
Securitization Facilities — The Company maintains separate securitization facilities in the United States for fixed-term leases and loans and revolving loans.  This debt is collateralized solely by the U.S. financing receivables in the facilities.  The debt has a variable interest rate and the duration of this debt is based on the terms of the underlying financing receivables.  As of February 2, 2018, the total debt capacity related to the U.S. securitization facilities was $2.1 billion.  The Company enters into interest swap agreements to effectively convert a portion of its securitization debt from a floating rate to a fixed rate.  See Note 9 of the Notes to the Consolidated Financial Statements for additional information about interest rate swaps.

[0001571996-18-000004:notes:347]
The Company's U.S. securitization facility for revolving loans is effective through June 10, 2018.  The Company's U.S. securitization facility for fixed-term leases and loans was renewed on February 12, 2018 and is now effective through February 22, 2020.

[0001571996-18-000004:notes:348]
The securitization facilities contain standard structural features related to the performance of the securitized receivables which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the facility, no further funding of receivables will be permitted and the timing of the Company's expected cash flows from over-collateralization will be delayed.  As of February 2, 2018, these criteria were met.

[0001571996-18-000004:notes:349]
Fixed-Term Securitization Offerings — The Company periodically issues asset-backed debt securities under fixed-term securitization programs to private investors.  The asset-backed debt securities are collateralized solely by the U.S. fixed-term financing receivables in the offerings, which are held by SPEs, as discussed below.  The interest rate on these securities is fixed and ranges from 0.53% to 3.61%, and the duration of these securities is based on the terms of the underlying financing receivables.

[0001571996-18-000004:notes:350]
DFS International Debt

[0001571996-18-000004:notes:351]
Securitization Facility — The Company maintains a securitization facility in Europe for fixed-term leases and loans.  This facility is effective through January 13, 2019.  As of February 2, 2018, the total debt capacity related to the international securitization facility was $751 million.

[0001571996-18-000004:notes:352]
The securitization facility contains standard structural features related to the performance of the securitized receivables which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the program, no further funding of receivables will be permitted and the timing of the Company's expected cash flows from over-collateralization will be delayed.  As of February 2, 2018, these criteria were met.

[0001571996-18-000004:notes:353]
Other Structured Facilities — In connection with the Company's international financing operations, the Company has entered into revolving structured financing debt programs related to its fixed-term lease and loan products sold in Canada, Europe, Australia, and New Zealand.  The Canadian facility, which is collateralized solely by Canadian financing receivables, had a total debt capacity of $183 million as of February 2, 2018, and is effective through January 16, 2023.  The European facility, which is collateralized solely by European financing receivables, had a total debt capacity of $500 million as of February 2, 2018, and is effective through December 14, 2020.  The Australia and New Zealand facility, which is collateralized solely by the Australia and New Zealand financing receivables, had a total debt capacity of $96 million as of February 2, 2018, and is effective through January 29, 2020.

[0001571996-18-000004:notes:354]
Note Payable — On November 27, 2017, the Company entered into an unsecured credit agreement to fund receivables in Mexico.  The aggregate principal amount of the note payable is $200 million.  The note will bear interest at either LIBOR plus 2.25%, for the borrowings denominated in U.S. dollars, or the Mexican Interbank Equilibrium Interest Rate ("TIIE") plus 2.00%, for the borrowings denominated in Mexican pesos.  The note will mature on December 1, 2020.  Although the note is unsecured, the Company intends to manage the note in the same manner as its structured financing programs, so that the collections from financing receivables in Mexico will be used to pay down principal and interest of the note.

[0001571996-18-000004:notes:355]
Variable Interest Entities

[0001571996-18-000004:notes:356]
In connection with the securitization facilities discussed above, the Company transfers certain U.S. and European customer financing receivables to Special Purpose Entities ("SPEs") that meet the definition of a Variable Interest Entity ("VIE") and are consolidated, along with the associated debt, into the Consolidated Financial Statements, as the Company is the primary beneficiary of those VIEs.  These SPEs are bankruptcy-remote legal entities with separate assets and liabilities.  The purpose of these SPEs is to facilitate the funding of customer receivables in the capital markets.

[0001571996-18-000004:notes:357]
The following table shows financing receivables held by the consolidated VIEs as of the respective dates:

[0001571996-18-000004:notes:358]
|  | February 2, 2018 |  | February 3, 2017 |
|  | (in millions) |
| Financing receivables held by consolidated VIEs, net: |  |  |  |  |  |
| Short-term, net | $ | 2,572 |  |  | $ | 2,227 |  |
| Long-term, net | 1,981 |  |  | 1,381 |  |
| Financing receivables held by consolidated VIEs, net | $ | 4,553 |  |  | $ | 3,608 |  |

[0001571996-18-000004:notes:359]
Financing receivables transferred via securitization through SPEs were $3.9 billion and $3.3 billion for the fiscal years ended February 2, 2018 and February 3, 2017, respectively.

[0001571996-18-000004:notes:360]
Some of the SPEs have entered into financing arrangements with multi-seller conduits that, in turn, issue asset-backed debt securities in the capital markets.  The DFS debt outstanding, which is collateralized by the financing receivables held by the consolidated VIEs, was $3.9 billion and $3.1 billion as of February 2, 2018 and February 3, 2017, respectively.  The Company's risk of loss related to securitized receivables is limited to the amount by which the Company's right to receive collections for assets securitized exceeds the amount required to pay interest, principal, and fees and expenses related to the asset-backed securities.  The Company provides credit enhancement to the securitization in the form of over-collateralization.

[0001571996-18-000004:notes:361]
Financing Receivable Sales

[0001571996-18-000004:notes:362]
To manage certain concentrations of customer credit exposure, the Company may sell selected fixed-term financing receivables to unrelated third parties on a periodic basis.  The amount of financing receivables sold was $683 million, $321 million, and $91 million for the fiscal years ended February 2, 2018, February 3, 2017, and January 29, 2016, respectively.  The increase in financing receivable sales during the fiscal year ended February 2, 2018 was primarily attributable to the growth in customer syndications related to the financing of products and services from the EMC acquired businesses.


## us-gaap:MinorityInterestDisclosureTextBlock

[0001571996-18-000004:notes:363]
NON-CONTROLLING INTERESTS

[0001571996-18-000004:notes:364]
VMware, Inc. — The non-controlling interests' share of equity in VMware, Inc. is reflected as a component of the non-controlling interests in the accompanying Consolidated Statements of Financial Position and was $5.1 billion and $5.2 billion as of February 2, 2018 and February 3, 2017, respectively.  As of February 2, 2018 and February 3, 2017, the Company held approximately 81.9% and 82.5%, respectively, of the outstanding equity interest in VMware, Inc.  VMware, Inc. restricted stock awards ("RSAs") were not included in the determination of these ownership interest percentages, as VMware, Inc. had no RSAs outstanding as of February 2, 2018, and an immaterial number of RSAs outstanding as of February 3, 2017.

[0001571996-18-000004:notes:365]
SecureWorks — On April 27, 2016, SecureWorks completed a registered underwritten initial public offering of its Class A common stock.  The non-controlling interests' share of equity in SecureWorks is reflected as a component of the non-controlling interests in the accompanying Consolidated Statements of Financial Position and was $87 million and $86 million as of February 2, 2018 and February 3, 2017, respectively.  As of February 2, 2018 and February 3, 2017, the Company held approximately 87.1% and 87.5%, respectively, of the outstanding equity interest in SecureWorks, excluding RSAs.  As of February 2, 2018 and February 3, 2017, the Company held approximately 86.3% and 86.9%, respectively, of the outstanding equity interest in SecureWorks, including RSAs.

[0001571996-18-000004:notes:366]
Pivotal — A portion of the non-controlling interests in Pivotal is held by third parties in the form of preferred equity instruments.  Due to the terms of such instruments, Pivotal's results of operations and equity activity are not attributable to such interests in Pivotal in the Consolidated Statements of Income (Loss) and Consolidated Statements of Financial Position.  The preferred equity instruments are convertible into common shares at the non-controlling owner's election at any time.  The remaining portion of the non-controlling interests in Pivotal is held by third parties in the form of common stock.  Pivotal's results of operations and equity activity are attributable to such interests in Pivotal in the Consolidated Statements of Income (Loss) and Consolidated Statements of Financial Position.  The non-controlling interests' share of equity in Pivotal, including both preferred equity instruments and common stock, is reflected as a component of the non-controlling interests in the accompanying Consolidated Statements of Financial Position and was $489 million and $472 million as of February 2, 2018 and February 3, 2017, respectively.  As of February 2, 2018 and February 3, 2017, the Company held approximately 77.1% and 77.8%, respectively, of the outstanding equity interest in Pivotal.  Pivotal RSAs were not included in the determination of these ownership interest percentages, as Pivotal had an immaterial number of RSAs outstanding as of February 2, 2018 and February 3, 2017.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001571996-18-000004:notes:367]
Recently Issued Accounting Pronouncements

[0001571996-18-000004:notes:368]
Revenue from Contracts with Customers — In May 2014, the Financial Accounting Standards Board (the "FASB") issued amended guidance on the recognition of revenue from contracts with customers.  The objective of the new standard is to establish a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and will supersede substantially all of the existing revenue recognition guidance, including industry-specific guidance.  The new standard requires entities to recognize revenue when it transfers promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services.  Further, the new standard requires additional disclosures to help enable users of the financial statements to better understand the nature, amount, timing, risks, and judgments related to revenue recognition and related cash flows from contracts with customers.  Concurrently, the FASB issued guidance on the accounting for costs to fulfill or obtain a customer contract.  The Company elected to adopt the new standards effective February 3, 2018 using the full retrospective method, which requires the Company to recast each prior period presented consistent with the new guidance.

[0001571996-18-000004:notes:369]
Adoption of the standard will have a material impact on the Company's Consolidated Financial Statements.  The most significant changes are the following:

[0001571996-18-000004:notes:370]
| • | Software license revenue. Currently, the Company defers revenue for certain software arrangements due to the absence of vendor specific objective evidence ("VSOE") of fair value for all or a portion of the deliverables. Under the new standard, the Company will no longer be required to establish VSOE of fair value in order to account for elements in an arrangement as separate units of accounting, and will be able to record revenue upon satisfaction of each performance obligation, resulting in more up-front recognition of software license revenue. |

[0001571996-18-000004:notes:371]
In addition, the Company currently accounts for third-party software licenses and post-contract customer support ("PCS") as a single unit of account, because it does not have VSOE of fair value for PCS in most cases.  Thus, the Company currently presents the entire arrangement for the software license and PCS together in services revenue and cost of services revenue.  Under the new standard, the Company will separate the value of the license from the value of the PCS.  The license value will be recognized upon delivery and the PCS will be recognized over the related contractual term.  For presentation purposes, the license revenue and cost of net revenue will be recorded in products, and the PCS revenue and cost of net revenue will be recorded in services on the Company’s Consolidated Statement of Income (Loss).

[0001571996-18-000004:notes:372]
| • | Variable consideration. The Company will estimate the transaction price for elements of consideration which are variable, primarily customer rebates. This consideration will then be recognized to the Consolidated Statement of Income (Loss) commensurate with the timing of the performance obligation to which it is related. |

[0001571996-18-000004:notes:373]
| • | Extended warranty revenue. For contracts that include both hardware and extended warranty, the new standard will result in more of the aggregate transaction price being allocated to the hardware and less to extended warranty, because the Company will no longer defer revenue based on the separately stated price of the extended warranty provided under the contract. With more of the transaction price being allocated to the hardware, more revenue under these arrangements will be recognized earlier, upon shipment of the hardware. |

[0001571996-18-000004:notes:374]
| • | Costs to obtain a contract. Within the scope of the new accounting standard, the FASB issued additional accounting guidance for certain costs related to a contract with a customer. In particular, the guidance relates to the incremental costs of obtaining a contract with a customer and costs incurred in fulfilling a contract with a customer. For contracts over one year, the Company will capitalize proportional sales commission costs, including bonuses associated with goal attainment, and will amortize these costs over their expected period of benefit. |

[0001571996-18-000004:notes:375]
The expected impacts to the opening Consolidated Statement of Financial Position are summarized as follows:

[0001571996-18-000004:notes:376]
| • | Accounts receivable, net. The adoption of the new revenue standard will result in an increase to accounts receivable, net primarily due to the following two factors: |

[0001571996-18-000004:notes:377]
First, the return rights provision, which represents an estimate of expected customer returns currently presented as a reduction of accounts receivable, net, will instead be presented outside of accounts receivable, net in two separate balance sheet line items.  A liability will be recorded in accrued and other for the estimated value of the sales amounts to be returned to the customer, and an asset will be recorded in other current assets representing the cost of the inventory estimated to be returned.

[0001571996-18-000004:notes:378]
Second, the standard provides new guidance regarding transfer of control of goods to the customer.  Under these new guidelines, the Company has determined that for certain hardware contracts in the United States, transfer of control and recognition of revenue can occur earlier.  This will result in an increase in accounts receivable, net and a decrease in the in-transit deferral recorded in other current assets.

[0001571996-18-000004:notes:379]
| • | Other assets. The adoption of the standard will result in an increase in other assets due to capitalization of the costs to obtain a contract, as well as the accounts receivable, net of impacts discussed above. |

[0001571996-18-000004:notes:380]
| • | Deferred revenue. The adoption of the standard will result in a decline in deferred revenue due to earlier recognition of revenue for software licenses, and less of aggregate transaction price being allocated to extended warranty. This reduction will be partially offset by an increase resulting from the change in presentation of deferred costs on third-party software offerings, which are routinely sold as an attached component of the Company's hardware offering. |

[0001571996-18-000004:notes:381]
The pre-tax impact to the opening Consolidated Statement of Financial Position as of January 29, 2016 is currently estimated to be an approximately $1 billion benefit to accumulated deficit.  For the fiscal year ended February 3, 2017, the impact to net revenue is currently estimated to be an increase of between $0.4 billion and $0.6 billion, and the impact to operating income is expected to be an increase of between $0.7 billion and $0.9 billion.  The Company is still assessing the income tax impact of the adoption of the new standard, as well as the impact that the standard will have on the Consolidated Statement of Income (Loss) for the fiscal year ended February 2, 2018.  Adoption of the standard will have no impact to cash from or used in operating, financing or investing activities on the Consolidated Statements of Cash Flows.

[0001571996-18-000004:notes:382]
Recognition and Measurement of Financial Assets and Financial Liabilities — In January 2016, the FASB issued amended guidance that addresses certain aspects of recognition, measurement, presentation, and disclosure of financial instruments.  The amended guidance requires changes in the fair value of equity investments, other than those accounted for under the equity method, to be recognized through net income, rather than other comprehensive income.  Adoption of the standard will be applied through a cumulative one-time adjustment to retained earnings, which is not expected to be material to the Consolidated Financial Statements.  For the Company’s equity investments without readily determinable fair values, the Company expects to elect the measurement alternative to record those investments at cost, less impairment, and adjusted by observable price changes on a prospective basis.  The impact of the standard on the Consolidated Statements of Income (Loss) will depend on the relative changes in market price of the equity investments.  The Company will adopt this standard for the fiscal year beginning February 3, 2018.

[0001571996-18-000004:notes:383]
Leases — In February 2016, the FASB issued amended guidance on the accounting for leasing transactions.  The primary objective of this update is to increase transparency and comparability among organizations by requiring lessees to recognize a lease liability for the obligation to make lease payments and a right-of-use asset for the right to use the underlying asset for the lease term.  The guidance also makes some changes to lessor accounting and requires additional disclosures about all leasing arrangements.  Companies are required to use a modified retrospective approach for leases that exist or are entered into after the beginning of the earliest comparative period in the financial statements.  The Company is currently evaluating the impact that the standard will have on the Consolidated Financial Statements.  In the area of lessee accounting, the Company anticipates that the most significant change will be recognition of right of use assets and lease liabilities on the Consolidated Statements of Financial Position.  In the area of lessor accounting, the Company anticipates that the most significant change will be an increase in originations of operating leases due to elimination of the third-party residual value guarantee insurance in the sales-type lease test.  The Company will adopt this standard for the fiscal year beginning February 2, 2019.

[0001571996-18-000004:notes:384]
Measurement of Credit Losses on Financial Instruments — In June 2016, the FASB issued amended guidance which replaces the current incurred loss impairment methodology for measurement of credit losses on financial instruments with a methodology that reflects expected credit losses and requires consideration of a broader range of reasonable and supportable information to inform credit loss estimates.  Public entities must adopt the new guidance for fiscal years beginning after December 15, 2019, and interim periods within those fiscal years, with early adoption permitted for fiscal periods beginning after December 15, 2018.  The Company is currently evaluating the impact that the standard will have on the Consolidated Financial Statements.

[0001571996-18-000004:notes:385]
Classification of Certain Cash Receipts and Cash Payments — In August 2016, the FASB issued amended guidance on the presentation and classification of eight specific cash flow issues with the objective of reducing existing diversity in practice.  Companies should reflect any adjustments on a retrospective basis, if practicable; otherwise, adoption is required to be applied as of the earliest date practicable.  The Company will adopt this standard for the fiscal year beginning February 3, 2018, and will apply adjustments retrospectively to each prior period presented on the Condensed Consolidated Statements of Cash Flows for that period.  The Company is currently evaluating the impact of the standard, which other than requiring certain reclassifications on the Consolidated Statements of Cash Flows is not expected to have a material impact on the Consolidated Financial Statements.

[0001571996-18-000004:notes:386]
Statement of Cash Flows, Restricted Cash — In November 2016, the FASB issued amended guidance requiring entities to include restricted cash and restricted cash equivalents in cash balances on the cash flow statement, and also to provide a supplemental reconciliation of cash, cash equivalents and restricted cash.  Public entities must adopt the new guidance for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017, with early adoption permitted.  The Company will adopt this standard for the fiscal year beginning February 3, 2018, and will apply adjustments retrospectively to each prior period presented on the Condensed Consolidated Statements of Cash Flows for that period and provide the supplemental reconciliation.  The Company does not expect that the standard will have a material impact on its Consolidated Financial Statements as its restricted cash balance does not change significantly from period to period.

[0001571996-18-000004:notes:387]
Simplifying the Test for Goodwill Impairment — In January 2017, the FASB issued amended guidance to simplify the subsequent measurement of goodwill by removing Step 2 of the goodwill impairment test.  Instead, under the amendments in the new guidance, an entity should perform its annual, or interim, goodwill impairment test by comparing the fair value of a reporting unit with its carrying amount.  An entity should recognize an impairment charge for the amount by which the carrying amount exceeds the reporting unit's fair value.  Public entities must adopt the new guidance in fiscal years beginning after December 15, 2019, with early adoption permitted.  The Company is currently evaluating the impact of the new guidance, but does not expect that the standard will have an impact on its Consolidated Financial Statements.

[0001571996-18-000004:notes:388]
Derivatives and Hedging — In August 2017, the FASB issued amended guidance that will make more financial and non-financial hedging strategies eligible for hedge accounting.  The amended guidance changes how companies assess effectiveness, and also amends the presentation and disclosure requirements.  The guidance is intended to simplify the application of hedge accounting and increase transparency as to the scope and results of hedging programs.  Immediate early adoption is permitted in any interim or annual period.  The Company will early adopt this standard for the fiscal year beginning February 3, 2018.  The Company does not expect the adoption of this standard to have a material impact on the Consolidated Financial Statements.

[0001571996-18-000004:notes:389]
Income Statement - Reporting Comprehensive Income — In February 2018, the FASB issued guidance that will permit entities to reclassify to retained earnings tax effects stranded in accumulated other comprehensive income as a result of U.S. Tax Reform, discussed in Note 14 to the Notes to the Consolidated Financial Statements.  The guidance gives entities the option to reclassify these amounts, but requires new disclosures regardless of whether they elect to do so.  The guidance is effective for fiscal years beginning after December 15, 2018, and interim periods within those fiscal years.  Early adoption is permitted.  Companies may apply the standard retrospectively or as a cumulative adjustment in the period of adoption.  The Company does not expect the adoption of this standard to have a material impact that the standard will have on the Consolidated Financial Statements.

[0001571996-18-000004:notes:390]
Recently Adopted Accounting Pronouncements

[0001571996-18-000004:notes:391]
Improvements to Employee Share-Based Payment Accounting — In March 2016, the FASB issued amended guidance on the accounting for employee share-based payments, including the accounting for income taxes and forfeitures, classification of awards as either equity or liabilities, and classification of cash flows.  The Company adopted this guidance at the beginning of Fiscal 2018.  In accordance with the new guidance, excess tax benefits or deficiencies for stock-based compensation are now reflected as a component of the provision for income taxes on the Consolidated Statements of Income (Loss), whereas they were previously recorded as additional paid-in capital.  The Company has elected to continue to estimate expected forfeitures.  Additionally, the Company now presents excess tax benefits as an operating activity rather than a financing activity on the Consolidated Statements of Cash Flows, while the cash flows related to employee taxes paid for withheld shares are presented as a financing activity, with prior periods adjusted accordingly.  The adoption of the amended guidance did not have a material impact on the Consolidated Financial Statements.  The prospective impact of the new standard will depend on the Company's stock price at the vesting or exercise dates of the awards and the number of awards that vest or are exercised in each period, but the Company does not expect the impact to be material in future periods.

[0001571996-18-000004:notes:392]
Intra-Entity Transfers of Assets Other Than Inventory — In October 2016, the FASB issued amended guidance on the accounting for income taxes.  The new guidance requires companies to recognize the income tax effects of intra-entity asset transfers, other than transfers of inventory, when the transfer occurs instead of when the asset is sold to a third party.  The new guidance should be applied on a modified-retrospective basis with the cumulative-effect adjustment to retained earnings as of the beginning of the period of adoption.  The Company early adopted this guidance at the beginning of Fiscal 2018.  At adoption, approximately $84 million was reclassified from other non-current liabilities to retained earnings, resulting in a net credit to retained earnings.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001571996-18-000004:notes:393]
RETIREMENT PLAN BENEFITS

[0001571996-18-000004:notes:394]
Defined Benefit Pension Plan

[0001571996-18-000004:notes:395]
In connection with the EMC merger transaction completed on September 7, 2016, the Company assumed all of EMC's defined benefit obligations and related plan assets, including a noncontributory defined benefit pension plan (the "Pension Plan") which was assumed as a result of EMC's prior acquisition of Data General.  Certain of the Company's foreign subsidiaries also have defined benefit pension plans which were assumed as part of the EMC merger transaction and do not have a material impact on the results of operations or financial position of the Company.

[0001571996-18-000004:notes:396]
Benefits under the Pension Plan are generally based on either career average or final average salaries and creditable years of service as defined in the plan.  The annual cost for the Pension Plan is determined using the projected unit credit actuarial cost method that includes actuarial assumptions and estimates which are subject to change.  As of December 1999, this plan was frozen, so employees no longer accrue pension benefits for future services.  The measurement date for the Pension Plan is the end of the Company's fiscal year.

[0001571996-18-000004:notes:397]
The following table presents the components of the changes in the Pension Plan benefit obligation for the periods indicated:

[0001571996-18-000004:notes:398]
|  | Benefit Obligation |
|  | (in millions) |
| Benefit obligation as of September 7, 2016 | $ | 590 |  |
| Interest cost | 8 |  |
| Benefits paid | (11 | ) |
| Actuarial loss (gain) | (52 | ) |
| Benefit obligation as of February 3, 2017 | 535 |  |
| Interest cost | 21 |  |
| Benefits paid | (24 | ) |
| Actuarial loss (gain) | 14 |  |
| Benefit obligation as of February 2, 2018 | $ | 546 |  |

[0001571996-18-000004:notes:399]
On a weighted-average basis, the assumed discount rate used to determine the benefit obligations at February 2, 2018, February 3, 2017, and September 7, 2016 was 3.8%, 4.1%, and 3.4%, respectively.

[0001571996-18-000004:notes:400]
The following table presents the components of the changes in the fair value of plan assets for the periods indicated:

[0001571996-18-000004:notes:401]
|  | Plan Assets |
|  | (in millions) |
| Fair value of plan assets as of September 7, 2016 | $ | 493 |  |
| Actual return on plan assets | (12 | ) |
| Benefits paid | (11 | ) |
| Fair value of plan assets as of February 3, 2017 | 470 |  |
| Actual return on plan assets | 59 |  |
| Benefits paid | (24 | ) |
| Fair value of plan assets as of February 2, 2018 | $ | 505 |  |

[0001571996-18-000004:notes:402]
The under-funded status of the Pension Plan at February 2, 2018 and February 3, 2017 was $41 million and $65 million, respectively, and is classified as a component of other long-term liabilities in the Consolidated Statements of Financial Position.  The Company did not make any significant contributions to the plan for the fiscal year ended February 2, 2018 and for the period from September 7, 2016 through February 3, 2017, and does not expect to make any significant contributions to the Pension Plan in Fiscal 2019.

[0001571996-18-000004:notes:403]
The following table presents the components of net periodic benefit cost recognized for the periods indicated:

[0001571996-18-000004:notes:404]
|  | Fiscal Year Ended |
|  | February 2, 2018 |  | September 7, 2016 through February 3, 2017 |
|  | (in millions) |
| Interest cost | $ | 21 |  |  | $ | 8 |  |
| Expected return on plan assets | (30 | ) |  | (16 | ) |
| Recognized actuarial loss | — |  |  | — |  |
| Net periodic benefit cost | $ | (9 | ) |  | $ | (8 | ) |

[0001571996-18-000004:notes:405]
The discount rate and expected long-term rate of return on plan assets used in the accounting for the Pension Plan to determine the net periodic benefit cost for the fiscal year ended February 2, 2018 was 4.1% and 6.5%, respectively.  The discount rate and expected long-term rate of return on plan assets used in the accounting for the Pension Plan to determine the net periodic benefit cost for the period from September 7, 2016 through February 3, 2017 was 3.4% and 6.5%, respectively.

[0001571996-18-000004:notes:406]
For the fiscal year ended February 2, 2018, the Pension Plan had net gains of $39 million that were primarily the result of an increase in the discount rate and the rate of return on plan assets.  The net gains were recognized in accumulated other comprehensive loss.

[0001571996-18-000004:notes:407]
There were no reclassifications from accumulated other comprehensive loss to a component of net periodic benefit cost during the fiscal year ended February 2, 2018.  Additionally, the Company expects that none of the total balance included in accumulated other comprehensive loss at February 2, 2018 will be recognized as a component of net periodic benefit cost in Fiscal 2019.

[0001571996-18-000004:notes:408]
At February 2, 2018, future benefit payments are expected to be paid as follows: $26 million in Fiscal 2019; $28 million in Fiscal 2020; $29 million in Fiscal 2021; $31 million in Fiscal 2022; $32 million in Fiscal 2023; and $173 million thereafter.

[0001571996-18-000004:notes:409]
Fair Value of Plan Assets — The following table presents the fair value of each class of plan assets by level within the fair value hierarchy as of February 2, 2018 and February 3, 2017:

[0001571996-18-000004:notes:410]
|  | February 2, 2018 |  | February 3, 2017 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (in millions) |
| Common collective trusts (a) | $ | — |  |  | $ | 350 |  |  | $ | — |  |  | $ | 350 |  |  | $ | — |  |  | $ | 331 |  |  | $ | — |  |  | $ | 331 |  |
| U.S. Treasury securities | 7 |  |  | — |  |  | — |  |  | 7 |  |  | 1 |  |  | — |  |  | — |  |  | 1 |  |
| Corporate debt securities (b) | — |  |  | 147 |  |  | — |  |  | 147 |  |  | — |  |  | 137 |  |  | — |  |  | 137 |  |
| Total | $ | 7 |  |  | $ | 497 |  |  | $ | — |  |  | 504 |  |  | $ | 1 |  |  | $ | 468 |  |  | $ | — |  |  | 469 |  |
| Plan payables, net of accrued interest and dividends (c) |  |  |  |  |  |  | 1 |  |  |  |  |  |  |  |  | 1 |  |
| Total, net |  |  |  |  |  |  | $ | 505 |  |  |  |  |  |  |  |  | $ | 470 |  |

[0001571996-18-000004:notes:411]
| (a) | Common collective trusts are valued at the net asset value calculated by the fund manager based on the underlying investments and are classified within Level 2 of the fair value hierarchy. |

[0001571996-18-000004:notes:412]
| (b) | Corporate debt securities are valued daily at the closing price reported in active U.S. financial markets and are classified within Level 2 of the fair value hierarchy. |

[0001571996-18-000004:notes:413]
| (c) | Dividends, accrued interest, and net plan payables are not material to the plan assets and therefore have not been classified into the fair value hierarchy. |

[0001571996-18-000004:notes:414]
Investment Strategy — The Pension Plan's assets are managed by outside investment managers.  The Company's investment strategy with respect to plan assets is to achieve a long-term growth of capital, consistent with an appropriate level of risk.  The expected long-term rate of return on the plan assets considers the current level of expected returns on risk-free investments (primarily government bonds), the historical level of the risk premium associated with the other asset classes in which the portfolio is invested, and the expectations for future returns of each asset class.  The expected return for each asset class was weighted based on the target asset allocation to develop the expected long-term rate of return on assets.  As market conditions permit, the Company expects to shift the asset allocation to lower the percentage of investments in equities and increase the percentage of investments in long-duration fixed-income securities.  The changes could result in a reduction in the long-term rate of return on the plan assets and increase future pension expense.

[0001571996-18-000004:notes:415]
The following table presents the target allocation of plan assets as of February 2, 2018, and actual allocation of plan assets as of February 2, 2018 and February 3, 2017:

[0001571996-18-000004:notes:416]
|  | Target Allocation |  | Actual Allocation |
|  | February 2, 2018 |  | February 2, 2018 |  | February 3, 2017 |
| U.S. large capitalization equity securities | 25 | % |  | 27 | % |  | 27 | % |
| U.S. small capitalization equity securities | 5 |  |  | 5 |  |  | 5 |  |
| Foreign equity securities | 7 |  |  | 7 |  |  | 7 |  |
| U.S. long-duration fixed income securities | 60 |  |  | 58 |  |  | 57 |  |
| Below investment grade corporate fixed income securities | 3 |  |  | 3 |  |  | 4 |  |
| Total | 100 | % |  | 100 | % |  | 100 | % |

[0001571996-18-000004:notes:417]
Employee Benefit Plans

[0001571996-18-000004:notes:418]
Dell 401(k) Plan — The Company has a defined contribution retirement plan (the "Dell 401(k) Plan") that complies with Section 401(k) of the Internal Revenue Code.  Substantially all Dell employees in the United States before the completion of the EMC merger transaction are eligible to participate in the Dell 401(k) Plan.  As of February 2, 2018, the Company matches 100% of each participant's voluntary contributions, subject to a maximum contribution of 6% of the participant's eligible compensation, up to an annual limit of $7,500, and participants vest immediately in all contributions to the Dell 401(k) Plan.  The Company's contributions during the fiscal years ended February 2, 2018, February 3, 2017, and January 29, 2016 were $129 million, $158 million, and $169 million, respectively.  The Company's matching contributions as well as participants' voluntary contributions are invested according to each participant's elections in the investment options provided under the 401(k) Plan.

[0001571996-18-000004:notes:419]
EMC 401(k) Plan — The EMC defined contribution retirement plan (the "EMC 401(k) Plan") was assumed in connection with the EMC merger transaction on September 7, 2016.  Effective January 1, 2018, the EMC 401(k) Plan was terminated and participant account balances were transferred to the Dell 401(k) Plan.  The EMC 401(k) plan complied with Section 401(k) of the Internal Revenue Code for certain employees who were EMC employees before the completion of the EMC merger transaction.  Before the transition into the Dell 401(k) Plan on January 1, 2018, the Company's contributions during the fiscal year ended February 2, 2018 to the EMC 401(k) Plan were $94 million.  The Company's contributions during the period from September 7, 2016 through February 3, 2017 to the EMC 401(k) Plan were $31 million.

[0001571996-18-000004:notes:420]
VMware, Inc., SecureWorks, and Pivotal have defined contribution programs for certain employees that comply with Section 401(k) of the Internal Revenue Code.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001571996-18-000004:notes:421]
WARRANTY LIABILITY

[0001571996-18-000004:notes:422]
The Company records a liability for its standard limited warranties at the time of sale for the estimated costs that may be incurred.  The liability for standard warranties is included in accrued and other current liabilities and other non-current liabilities in the Consolidated Statements of Financial Position.

[0001571996-18-000004:notes:423]
Changes in the Company's liability for standard limited warranties are presented in the following table for the periods indicated.

[0001571996-18-000004:notes:424]
|  | Fiscal Year Ended |
|  | February 2, 2018 |  | February 3, 2017 |  | January 29, 2016 |
|  | (in millions) |
| Warranty liability: |  |  |  |  |  |
| Warranty liability at beginning of period | $ | 604 |  |  | $ | 574 |  |  | $ | 679 |  |
| Warranty liability assumed through EMC merger transaction | — |  |  | 125 |  |  | — |  |
| Costs accrued for new warranty contracts and changes in estimates for pre-existing warranties (a) (b) | 905 |  |  | 852 |  |  | 754 |  |
| Service obligations honored | (970 | ) |  | (947 | ) |  | (859 | ) |
| Warranty liability at end of period | $ | 539 |  |  | $ | 604 |  |  | $ | 574 |  |
| Current portion | $ | 367 |  |  | $ | 405 |  |  | $ | 381 |  |
| Non-current portion | $ | 172 |  |  | $ | 199 |  |  | $ | 193 |  |

[0001571996-18-000004:notes:425]
| (a) | Changes in cost estimates related to pre-existing warranties are aggregated with accruals for new standard warranty contracts. The Company's warranty liability process does not differentiate between estimates made for pre-existing warranties and new warranty obligations. |

[0001571996-18-000004:notes:426]
| (b) | Includes the impact of foreign currency exchange rate fluctuations. |


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0001571996-18-000004:notes:427]
Property, plant, and equipment are carried at depreciated cost.  Depreciation is determined using the straight-line method over the shorter of the estimated economic lives of the assets or the lease term.  The estimated useful lives of the Company's property, plant, and equipment are generally as follows:

[0001571996-18-000004:notes:428]
|  | Estimated Useful Life |
| Computer equipment | 3-5 years |
| Buildings | 10-30 years or term of underlying land lease |
| Leasehold improvements | Shorter of 5-20 years or lease term |
| Machinery and equipment | 3-5 years |

[0001571996-18-000004:notes:429]
Gains or losses related to retirements or dispositions of fixed assets are recognized in the period during which the retirement or disposition occurs.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001571996-18-000004:notes:430]
UNAUDITED QUARTERLY RESULTS

[0001571996-18-000004:notes:431]
The following tables present selected unaudited consolidated statements of income (loss) for each quarter of Fiscal 2018 and Fiscal 2017:

[0001571996-18-000004:notes:432]
|  | Fiscal 2018 |
|  | Q1 |  | Q2 |  | Q3 |  | Q4 |
|  | (in millions, except per share data) |
| Net revenue | $ | 17,816 |  |  | $ | 19,299 |  |  | $ | 19,610 |  |  | $ | 21,935 |  |
| Gross margin | $ | 4,302 |  |  | $ | 4,809 |  |  | $ | 5,163 |  |  | $ | 5,780 |  |
| Net income (loss) from continuing operations attributable to Class V Common Stock | $ | 118 |  |  | $ | 168 |  |  | $ | 223 |  |  | $ | (223 | ) |
| Net loss from continuing operations attributable to DHI Group | (1,452 | ) |  | (1,114 | ) |  | (1,160 | ) |  | (288 | ) |
| Net loss from continuing operations attributable to Dell Technologies Inc. | (1,334 | ) |  | (946 | ) |  | (937 | ) |  | (511 | ) |
| Income (loss) from discontinued operations, net of income taxes | — |  |  | — |  |  | — |  |  | — |  |
| Net loss attributable to Dell Technologies Inc. | $ | (1,334 | ) |  | $ | (946 | ) |  | $ | (937 | ) |  | $ | (511 | ) |
| Earnings (loss) per share attributable to Dell Technologies Inc. - basic: |  |  |  |  |  |  |  |
| Continuing operations - Class V Common Stock - basic | $ | 0.57 |  |  | $ | 0.83 |  |  | $ | 1.10 |  |  | $ | (1.12 | ) |
| Continuing operations - DHI Group - basic | $ | (2.57 | ) |  | $ | (1.97 | ) |  | $ | (2.05 | ) |  | $ | (0.51 | ) |
| Discontinued operations - DHI Group - basic | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Earnings (loss) per share attributable to Dell Technologies Inc. - diluted: |  |  |  |  |  |  |  |
| Continuing operations - Class V Common Stock - diluted | $ | 0.56 |  |  | $ | 0.82 |  |  | $ | 1.09 |  |  | $ | (1.12 | ) |
| Continuing operations - DHI Group - diluted | $ | (2.57 | ) |  | $ | (1.97 | ) |  | $ | (2.05 | ) |  | $ | (0.51 | ) |
| Discontinued operations - DHI Group - diluted | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |

[0001571996-18-000004:notes:433]
|  | Fiscal 2017 |
|  | Q1 |  | Q2 |  | Q3 |  | Q4 |
|  | (in millions, except per share data) |
| Net revenue | $ | 12,241 |  |  | $ | 13,080 |  |  | $ | 16,247 |  |  | $ | 20,074 |  |
| Gross margin | $ | 2,193 |  |  | $ | 2,336 |  |  | $ | 3,899 |  |  | $ | 4,531 |  |
| Net income from continuing operations attributable to Class V Common Stock | $ | — |  |  | $ | — |  |  | $ | 175 |  |  | $ | 138 |  |
| Net loss from continuing operations attributable to DHI Group | (424 | ) |  | (261 | ) |  | (1,801 | ) |  | (1,518 | ) |
| Net loss from continuing operations attributable to Dell Technologies Inc. | (424 | ) |  | (261 | ) |  | (1,626 | ) |  | (1,380 | ) |
| Income (loss) from discontinued operations, net of income taxes | 479 |  |  | 834 |  |  | (438 | ) |  | 1,144 |  |
| Net income (loss) attributable to Dell Technologies Inc. | $ | 55 |  |  | $ | 573 |  |  | $ | (2,064 | ) |  | $ | (236 | ) |
| Earnings (loss) per share attributable to Dell Technologies Inc. - basic: |  |  |  |  |  |  |  |
| Continuing operations - Class V Common Stock - basic | $ | — |  |  | $ | — |  |  | $ | 0.79 |  |  | $ | 0.64 |  |
| Continuing operations - DHI Group - basic | $ | (1.05 | ) |  | $ | (0.65 | ) |  | $ | (3.62 | ) |  | $ | (2.68 | ) |
| Discontinued operations - DHI Group - basic | $ | 1.18 |  |  | $ | 2.06 |  |  | $ | (0.88 | ) |  | $ | 2.02 |  |
| Earnings (loss) per share attributable to Dell Technologies Inc. - diluted: |  |  |  |  |  |  |  |
| Continuing operations - Class V Common Stock - diluted | $ | — |  |  | $ | — |  |  | $ | 0.78 |  |  | $ | 0.64 |  |
| Continuing operations - DHI Group - diluted | $ | (1.05 | ) |  | $ | (0.65 | ) |  | $ | (3.63 | ) |  | $ | (2.68 | ) |
| Discontinued operations - DHI Group - diluted | $ | 1.18 |  |  | $ | 2.06 |  |  | $ | (0.88 | ) |  | $ | 2.02 |  |


## us-gaap:ReconciliationOfRevenueFromSegmentsToConsolidatedTextBlock

[0001571996-18-000004:notes:434]
The following table presents a reconciliation of net revenue by the Company's reportable segments to the Company's consolidated net revenue as well as a reconciliation of consolidated segment operating income to the Company's consolidated operating loss:

[0001571996-18-000004:notes:435]
|  | Fiscal Year Ended |
|  | February 2, 2018 |  | February 3, 2017 |  | January 29, 2016 |
|  | (in millions) |
| Consolidated net revenue: |  |  |  |  |  |  |  |
| Client Solutions Group | $ | 39,455 |  |  | $ | 36,754 |  |  | $ | 35,877 |  |
| Infrastructure Solutions Group | 30,652 |  |  | 21,776 |  |  | 14,978 |  |
| VMware | 7,925 |  |  | 3,225 |  |  | — |  |
| Reportable segment net revenue | 78,032 |  |  | 61,755 |  |  | 50,855 |  |
| Other businesses (a) | 1,901 |  |  | 1,026 |  |  | 382 |  |
| Unallocated transactions (b) | (4 | ) |  | 41 |  |  | 133 |  |
| Impact of purchase accounting (c) | (1,269 | ) |  | (1,180 | ) |  | (459 | ) |
| Total net revenue | $ | 78,660 |  |  | $ | 61,642 |  |  | $ | 50,911 |  |
| Consolidated operating income (loss): |  |  |  |  |  |
| Client Solutions Group | $ | 2,193 |  |  | $ | 1,845 |  |  | $ | 1,410 |  |
| Infrastructure Solutions Group | 2,179 |  |  | 2,393 |  |  | 1,052 |  |
| VMware | 2,520 |  |  | 1,113 |  |  | — |  |
| Reportable segment operating income | 6,892 |  |  | 5,351 |  |  | 2,462 |  |
| Other businesses (a) | (21 | ) |  | (39 | ) |  | (78 | ) |
| Unallocated transactions (b) | (16 | ) |  | (199 | ) |  | (159 | ) |
| Impact of purchase accounting (c) | (1,546 | ) |  | (2,294 | ) |  | (604 | ) |
| Amortization of intangibles | (6,980 | ) |  | (3,681 | ) |  | (1,969 | ) |
| Transaction-related expenses (d) | (502 | ) |  | (1,488 | ) |  | (109 | ) |
| Other corporate expenses (e) | (1,160 | ) |  | (902 | ) |  | (57 | ) |
| Total operating loss | $ | (3,333 | ) |  | $ | (3,252 | ) |  | $ | (514 | ) |

[0001571996-18-000004:notes:436]
| (a) | Other businesses consist of RSA Information Security, SecureWorks, Pivotal, and Boomi, and do not constitute a reportable segment, either individually or collectively, as the results of the businesses are not material to the Company's overall results and the businesses do not meet the criteria for reportable segments. |

[0001571996-18-000004:notes:437]
| (b) | Unallocated transactions includes long-term incentives, certain short-term incentive compensation expenses, and other corporate items that are not allocated to Dell Technologies' reportable segments. |

[0001571996-18-000004:notes:438]
| (c) | Impact of purchase accounting includes non-cash purchase accounting adjustments that are primarily related to the EMC merger transaction. |

[0001571996-18-000004:notes:439]
| (d) | Transaction-related expenses includes acquisition, integration, and divestiture related costs. |

[0001571996-18-000004:notes:440]
| (e) | Other corporate expenses includes severance and facility action costs as well as stock-based compensation expense. |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001571996-18-000004:notes:441]
RELATED PARTY TRANSACTIONS

[0001571996-18-000004:notes:442]
Dell Technologies is a large global organization which engages in millions of purchase, sales, and other transactions during the fiscal year.  The Company enters into purchase and sales transactions with other publicly-traded and privately-held companies,  as well as not-for-profit organizations that could be influenced by members of the Company's board of directors or the Comany's executive officers.  The Company enters into these arrangements in the ordinary course of its business.  Transactions with related parties were immaterial for the fiscal years ended February 2, 2018, February 3, 2017, and January 29, 2016.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001571996-18-000004:notes:443]
SEVERANCE CHARGES

[0001571996-18-000004:notes:444]
In connection with the transformation of the Company's business model, the Company incurs costs related to employee severance.  The Company records a liability for these costs when it is probable that employees will be entitled to termination benefits and the amounts can be reasonably estimated.  The liability related to these actions is included in accrued and other current liabilities in the Consolidated Statements of Financial Position.

[0001571996-18-000004:notes:445]
The following table sets forth the activity related to the Company's severance liability for the respective periods:

[0001571996-18-000004:notes:446]
|  | Severance Costs |
|  | (in millions) |
| Balance as of January 30, 2015 | $ | 95 |  |
| Severance charges to provision | 20 |  |
| Cash paid and other | (89 | ) |
| Balance as of January 29, 2016 | 26 |  |
| Severance liability assumed through EMC merger transaction | 70 |  |
| Severance charges to provision | 541 |  |
| Cash paid and other | (221 | ) |
| Balance as of February 3, 2017 | 416 |  |
| Severance charges to provision | 159 |  |
| Cash paid and other | (400 | ) |
| Balance as of February 2, 2018 | $ | 175 |  |

[0001571996-18-000004:notes:447]
Severance costs are included in cost of net revenue, selling, general, and administrative expenses, and research and development expenses in the Consolidated Statements of Income (Loss) as follows:

[0001571996-18-000004:notes:448]
|  | Fiscal Year Ended |
|  | February 2, 2018 |  | February 3, 2017 |  | January 29, 2016 |
|  | (in millions) |
| Severance charges: |  |  |  |  |  |
| Cost of net revenue | $ | 46 |  |  | $ | 122 |  |  | $ | 1 |  |
| Selling, general, and administrative | 46 |  |  | 355 |  |  | (1 | ) |
| Research and development | 67 |  |  | 64 |  |  | 20 |  |
| Total | $ | 159 |  |  | $ | 541 |  |  | $ | 20 |  |


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001571996-18-000004:notes:449]
Net revenue primarily includes sales of hardware, services, software licenses, and peripherals.  The Company recognizes revenue for these products and services when it is realized or realizable and earned.  Revenue is recognized when persuasive evidence of an arrangement exists; delivery has occurred or services have been rendered; the Company's fee to its customer is fixed or determinable; and collection of the resulting receivable is reasonably assured.  This policy is applicable to all sales, including sales to resellers and end-users.

[0001571996-18-000004:notes:450]
Revenue from certain third-party software sales and extended warranties for third-party products, for which the Company does not meet the criteria for gross revenue recognition, is recognized on a net basis.  All other revenue is recognized on a gross basis.

[0001571996-18-000004:notes:451]
The following summarizes the major terms of contractual relationships with customers and the manner in which the Company accounts for sales transactions.

[0001571996-18-000004:notes:452]
Products

[0001571996-18-000004:notes:453]
Product revenue consists of computer hardware, enterprise hardware, and software licenses sales that are delivered, sold as a subscription or sold on a consumption basis.  Computer hardware and enterprise hardware include notebooks and desktop PCs, servers, storage hardware, and other hardware-related devices.  Software license sales include optional, stand-alone software applications.  Software applications provide customers with resource management, backup and archiving, information security, information management and intelligence, data analytics, and server virtualization capabilities.  Revenue from the sale of hardware products and systems is recognized when title and risk of loss pass to the customer.  Delivery is considered complete when products have been shipped to the Company's customer, title and risk of loss have transferred to the customer, and customer acceptance has been satisfied.  Customer acceptance is satisfied if acceptance is obtained from the customer, if all acceptance provisions lapse, or if the Company has evidence that all acceptance provisions have been satisfied.  Depending on the nature of the arrangement, revenue from software license sales is generally recognized upon shipment or electronic delivery.  For certain arrangements, revenue is recognized based on usage or ratably over the term of the arrangement.  License revenue from royalty arrangements is recognized upon either receipt of royalty reports or payments from third parties.

[0001571996-18-000004:notes:454]
The Company records reductions to revenue for estimated customer sales returns, rebates, and certain other customer incentive programs.  These reductions to revenue are made based upon reasonable and reliable estimates that are determined by historical experience, contractual terms, and current conditions.  The primary factors affecting the Company's accrual for estimated customer returns include estimated return rates as well as the number of units shipped that have a right of return that has not expired as of the balance sheet date.  If returns cannot be reliably estimated, revenue is not recognized until a reliable estimate can be made or the return right lapses.

[0001571996-18-000004:notes:455]
The Company sells its products directly to customers as well as through other sales channels, such as value-added resellers, system integrators, distributors, and retailers.  The Company recognizes revenue on these sales when the reseller has economic substance apart from the Company; any credit risk has been identified and quantified; title and risk of loss have passed to the channel; the fee paid to the Company is not contingent upon resale or payment by the end user; and the Company has no further obligations related to bringing about resale or delivery.

[0001571996-18-000004:notes:456]
Sales through the Company's sales channels are primarily made under agreements allowing for limited rights of return, price protection, rebates, and marketing development funds.  The Company has generally limited return rights through contractual caps or has an established selling history for these arrangements.  Therefore, there is sufficient data to establish reasonable and reliable estimates of returns for the majority of these sales.  To the extent price protection or return rights are not limited and a reliable estimate cannot be made, all of the revenue and related costs are deferred until the product has been sold to the end-user or the rights expire.  The Company records estimated reductions to revenue or an expense for channel programs at the later of the offer or the time revenue is recognized.

[0001571996-18-000004:notes:457]
The Company defers the cost of shipped products awaiting revenue recognition until revenue is recognized.

[0001571996-18-000004:notes:458]
Services

[0001571996-18-000004:notes:459]
Services revenue consists of hardware and software maintenance, installation services, professional services, training revenue, third-party software revenue, and software sold as a service.  The Company recognizes revenue from fixed-price support or maintenance contracts sold for both hardware and software ratably over the contract period and recognizes the costs associated with these contracts as incurred.  For sales of extended warranties with a separate contract price, the Company defers revenue equal to the separately stated price.  Revenue associated with undelivered elements is deferred and recorded when delivery occurs or services are provided.  Revenue from extended warranty and service contracts, for which the Company is obligated to perform, is recorded as deferred revenue and subsequently recognized over the term of the contract on a straight-line basis or when the service is completed and the costs associated with these contracts are recognized as incurred.

[0001571996-18-000004:notes:460]
Multiple Deliverables

[0001571996-18-000004:notes:461]
When an arrangement has more than one element, such as hardware, software, and services contained in a single arrangement, the Company first allocates revenue based upon the relative selling price into two categories: (1) non-software components, such as hardware and any hardware-related items, such as required system software that functions with the hardware to deliver the essential functionality of the hardware and related post-contract customer support, software as a service subscriptions, and other services; and (2) software components, such as optional software applications and related items, such as post-contract customer support and other services.  The Company then allocates revenue within the non-software category to each element based upon its relative selling price using a hierarchy of vendor-specific objective evidence ("VSOE"), third-party evidence of selling price ("TPE"), or estimated selling prices ("ESP"), if VSOE or TPE does not exist.  The Company allocates revenue within the software category to the undelivered elements based upon their fair value using VSOE, with the residual revenue allocated to the delivered elements.  If the Company cannot objectively determine the VSOE of the fair value of any undelivered software element, it defers revenue for all software components until all elements are delivered and services have been performed, until fair value can objectively be determined for any remaining undelivered elements, or until software maintenance is the only undelivered element, in which case revenue is recognized over the maintenance term for all software elements.

[0001571996-18-000004:notes:462]
The Company allocates the amount of revenue recognized for delivered elements to the amount that is not subject to forfeiture or refund or contingent on the future delivery of products or services.

[0001571996-18-000004:notes:463]
Customers under software maintenance agreements are entitled to receive updates and upgrades on a when-and-if-available basis, and various types of technical support based on the level of support purchased.  In the event specific features, functionality, entitlements, or the release version of an upgrade or new product have been announced but not delivered, and customers will receive that upgrade or new product as part of a current software maintenance contract, a specified upgrade is deemed created and product revenues are deferred on purchases made after the announcement date until delivery of the upgrade or new product.  The amount and elements to be deferred are dependent on whether the Company has established VSOE of fair value for the upgrade or new product.

[0001571996-18-000004:notes:464]
The Company records revenue from the sale of equipment under sales-type leases as product revenue in an amount equal to the present value of minimum lease payments at the inception of the lease.  Sales-type leases also produce financing income, which is included in net products revenue in the Consolidated Statements of Income (Loss) and is recognized at consistent rates of return over the lease term.  Revenue from operating leases is recognized over the lease period.  The Company also offers qualified customers revolving credit lines for the purchase of products and services offered by the Company.  Financing income attributable to these revolving loans is recognized in net products revenue on an accrual basis.

[0001571996-18-000004:notes:465]
The Company reports revenue net of any revenue-based taxes assessed by governmental authorities that are imposed on and concurrently with specific revenue-producing transactions.


## us-gaap:ScheduleOfDebtTableTextBlock

[0001571996-18-000004:notes:466]
The following table summarizes DFS debt as of the periods indicated.


## us-gaap:ScheduleOfDisposalGroupsIncludingDiscontinuedOperationsIncomeStatementBalanceSheetAndAdditionalDisclosuresTextBlock

[0001571996-18-000004:notes:467]
The significant cash flow items from Dell Services and DSG for the fiscal years ended February 3, 2017 and January 29, 2016 were as follows:

[0001571996-18-000004:notes:468]
The following tables present key financial results of Dell Services, DSG, and ECD included in "Income from discontinued operations, net of income taxes" for the fiscal years ended February 3, 2017 and January 29, 2016:


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0001571996-18-000004:notes:469]
The following table presents net revenue by business unit categories:

[0001571996-18-000004:notes:470]
|  | Fiscal Year Ended |
|  | February 2, 2018 |  | February 3, 2017 |  | January 29, 2016 |
|  | (in millions) |
| Net revenue: |  |  |  |  |  |  |  |  |
| Client Solutions Group: |  |  |  |  |  |
| Commercial | $ | 27,747 |  |  | $ | 26,006 |  |  | $ | 25,747 |  |
| Consumer | 11,708 |  |  | 10,748 |  |  | 10,130 |  |
| Total CSG net revenue | 39,455 |  |  | 36,754 |  |  | 35,877 |  |
| Infrastructure Solutions Group: |  |  |  |  |  |
| Servers and networking | 15,398 |  |  | 12,834 |  |  | 12,761 |  |
| Storage | 15,254 |  |  | 8,942 |  |  | 2,217 |  |
| Total ISG net revenue | 30,652 |  |  | 21,776 |  |  | 14,978 |  |
| VMware |  |  |  |  |  |
| Total VMware net revenue | 7,925 |  |  | 3,225 |  |  | — |  |
| Total segment net revenue | $ | 78,032 |  |  | $ | 61,755 |  |  | $ | 50,855 |  |

[0001571996-18-000004:notes:471]
The following tables present net revenue and property, plant, and equipment, net allocated between the United States and foreign countries:

[0001571996-18-000004:notes:472]
|  | Fiscal Year Ended |
|  | February 2, 2018 |  | February 3, 2017 |  | January 29, 2016 |
|  | (in millions) |
| Net revenue: |  |  |  |  |  |  |  |  |
| United States | $ | 38,342 |  |  | $ | 30,699 |  |  | $ | 24,309 |  |
| Foreign countries | 40,318 |  |  | 30,943 |  |  | 26,602 |  |
| Total net revenue | $ | 78,660 |  |  | $ | 61,642 |  |  | $ | 50,911 |  |

[0001571996-18-000004:notes:473]
|  | February 2, 2018 |  | February 3, 2017 |
|  | (in millions) |
| Property, plant, and equipment, net: |  |  |  |
| United States | $ | 4,093 |  |  | $ | 4,320 |  |
| Foreign countries | 1,297 |  |  | 1,333 |  |
| Total property, plant, and equipment, net | $ | 5,390 |  |  | $ | 5,653 |  |


## us-gaap:ScheduleOfShareBasedCompensationEmployeeStockPurchasePlanActivityTableTextBlock

[0001571996-18-000004:notes:474]
The following table summarizes stock option activity for VMware, Inc. employees in VMware, Inc. stock options:


## us-gaap:ScheduleOfShareBasedPaymentAwardStockOptionsValuationAssumptionsTableTextBlock

[0001571996-18-000004:notes:475]
There were no performance-based stock options granted during the fiscal year ended February 2, 2018.

[0001571996-18-000004:notes:476]
The Company granted an immaterial number of service-based stock options during the fiscal year ended February 2, 2018.

[0001571996-18-000004:notes:477]
The assumptions utilized in this model, as well as the weighted-average assumptions, are presented below.  There were no stock options granted under the 2007 Plan during the period from September 7, 2016 through February 3, 2017.


## us-gaap:ScheduleOfStockByClassTextBlock

[0001571996-18-000004:notes:478]
The following table presents the repurchase activity with respect to the Class V Common Stock for the fiscal year ended February 2, 2018, and the attribution of the Class V Group between the Class V Common Stock and the DHI Group's retained interest as of the dates indicated:

[0001571996-18-000004:notes:479]
|  | Class V Common Stock |  | DHI Group Retained Interest |
|  | Shares of Class V Common Stock |  | Interest in Class V Group |  | Retained Interest Shares |  | Interest in Class V Group |
| As of September 7, 2016 | 223 |  |  | 65 | % |  | 120 |  |  | 35 | % |
| DHI Group Repurchase Program | (7 | ) |  |  |  | 7 |  |  |  |
| Class V Group Repurchase Program | (7 | ) |  |  |  | — |  |  |  |
| As of February 3, 2017 | 209 |  |  | 62 | % |  | 127 |  |  | 38 | % |
| Repurchases of Class V Common Stock | (10 | ) |  |  |  | — |  |  |  |
| As of February 2, 2018 | 199 |  |  | 61 | % |  | 127 |  |  | 39 | % |

[0001571996-18-000004:notes:480]
The following table summarizes the Company's authorized, issued, and outstanding common stock as of the dates indicated:

[0001571996-18-000004:notes:481]
|  | Authorized |  | Issued |  | Outstanding |
|  | (in millions of shares) |
| Common stock as of February 3, 2017 |
| Class A | 600 |  |  | 410 |  |  | 410 |  |
| Class B | 200 |  |  | 137 |  |  | 137 |  |
| Class C | 900 |  |  | 22 |  |  | 22 |  |
| Class D | 100 |  |  | — |  |  | — |  |
| Class V | 343 |  |  | 223 |  |  | 209 |  |
|  | 2,143 |  |  | 792 |  |  | 778 |  |
| Common stock as of February 2, 2018 |
| Class A | 600 |  |  | 410 |  |  | 410 |  |
| Class B | 200 |  |  | 137 |  |  | 137 |  |
| Class C | 7,900 |  |  | 24 |  |  | 23 |  |
| Class D | 100 |  |  | — |  |  | — |  |
| Class V | 343 |  |  | 223 |  |  | 199 |  |
|  | 9,143 |  |  | 794 |  |  | 769 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001571996-18-000004:notes:482]
SEGMENT INFORMATION

[0001571996-18-000004:notes:483]
The Company has three reportable segments that are based on the following business units: Client Solutions Group ("CSG"); Infrastructure Solutions Group ("ISG"); and VMware.

[0001571996-18-000004:notes:484]
CSG includes sales to commercial and consumer customers of desktops, thin client products, and notebooks, as well as services and third-party software and peripherals that are closely tied to the sale of CSG hardware.  ISG includes servers, networking, and storage, as well as services and third-party software and peripherals that are closely tied to the sale of ISG hardware.  VMware includes a broad portfolio of virtualization technologies across three main product groups: software-defined data center; hybrid cloud computing; and end-user computing.

[0001571996-18-000004:notes:485]
ISG includes Virtustream product and service offerings.  Virtustream's cloud software and infrastructure-as-a-service solutions enable customers to migrate, run, and manage mission-critical applications in cloud-based IT environments.  Beginning in the first quarter of Fiscal 2019, the Company will no longer manage Virtustream as part of ISG and, as such, will report Virtustream results within other businesses, rather than within ISG.  This change in reporting structure will not impact the Company's previously reported consolidated financial results, but the Company's prior period segment results will be recast to reflect the change.

[0001571996-18-000004:notes:486]
The reportable segments disclosed herein are based on information reviewed by the Company's management to evaluate the business segment results.  The Company's measure of segment operating income for management reporting purposes excludes the impact of other businesses, purchase accounting, amortization of intangible assets, unallocated corporate transactions, severance and facility action costs, and transaction-related expenses.  The Company does not allocate assets to the above reportable segments for internal reporting purposes.

[0001571996-18-000004:notes:487]
The allocation between domestic and foreign net revenue is based on the location of the customers.  Net revenue from any single foreign country did not constitute more than 10% of the Company's consolidated net revenue for the fiscal year ended February 2, 2018, February 3, 2017, or January 29, 2016.  Property, plant, and equipment, net from any single foreign country did not constitute more than 10% of the Company's consolidated property, plant, and equipment, net as of February 2, 2018 or February 3, 2017.


## us-gaap:SellingGeneralAndAdministrativeExpensesPolicyTextBlock

[0001571996-18-000004:notes:488]
Selling expenses include items such as sales salaries and commissions, marketing and advertising costs, and contractor services.  Advertising costs are expensed as incurred in selling, general, and administrative expenses in the Consolidated Statements of Income (Loss).  For the fiscal years ended February 2, 2018, February 3, 2017, and January 29, 2016, advertising expenses were $1,045 million, $772 million, and $594 million, respectively.  General and administrative expenses include items for the Company's administrative functions, such as finance, legal, human resources, and information technology support.  These functions include costs for items such as salaries, maintenance and supplies, insurance, depreciation expense, and allowance for doubtful accounts.


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001571996-18-000004:notes:489]
REDEEMABLE SHARES

[0001571996-18-000004:notes:490]
Awards under the Company's stock incentive plans include certain rights that allow the holder to exercise a put feature for the underlying Class A or Class C Common Stock after a six month holding period following the issuance of such common stock.  The put feature requires the Company to purchase the stock at its fair market value.  Accordingly, these awards and common stock are subject to reclassification from equity to temporary equity, and the Company determines the award amounts to be classified as temporary equity as follows:

[0001571996-18-000004:notes:491]
| • | For stock options to purchase Class C Common Stock subject to service requirements, the intrinsic value of the option is multiplied by the portion of the option for which services have been rendered. Upon exercise of the option, the amount in temporary equity represents the fair value of the Class C Common Stock. |

[0001571996-18-000004:notes:492]
| • | For SARs, RSUs, or RSAs, any of which stock award types are subject to service requirements, the fair value of the share is multiplied by the portion of the shares for which services have been rendered. |

[0001571996-18-000004:notes:493]
| • | For share-based arrangements that are subject to the occurrence of a contingent event, those amounts are not reclassified to temporary equity until the contingency has been satisfied. |

[0001571996-18-000004:notes:494]
The amount of redeemable shares classified as temporary equity as of February 2, 2018 was $384 million, which consisted of 2.9 million issued and outstanding unrestricted common shares, 0.4 million RSUs, 0.1 million RSAs, and 15.3 million outstanding stock options.  The amount of redeemable shares classified as temporary equity as of February 3, 2017 was $231 million, which consisted of 1.1 million issued and outstanding unrestricted common shares, 0.4 million RSUs, 0.1 million RSAs, and 13.7 million outstanding stock options.


## us-gaap:ShippingAndHandlingCostPolicyTextBlock

[0001571996-18-000004:notes:495]
The Company's shipping and handling costs are included in cost of net revenue in the Consolidated Statements of Income (Loss).


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001571996-18-000004:notes:496]
DESCRIPTION OF BUSINESS AND SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES

[0001571996-18-000004:notes:497]
Description of Business — The Company is a strategically aligned family of businesses that offers a broad range of technology solutions, including desktops, notebooks, servers and networking products, storage products, cloud solutions products, services, software, and third-party software and peripherals.

[0001571996-18-000004:notes:498]
Fiscal Year — The Company's fiscal year is the 52- or 53-week period ending on the Friday nearest January 31.  The fiscal years ended February 2, 2018 ("Fiscal 2018") and January 29, 2016 ("Fiscal 2016") were 52-week periods.  The fiscal year ended February 3, 2017 ("Fiscal 2017") was a 53-week period.

[0001571996-18-000004:notes:499]
Principles of Consolidation — These consolidated financial statements include the accounts of Dell Technologies and its wholly-owned subsidiaries, as well as the accounts of SecureWorks Corp. (“SecureWorks"), VMware, Inc., and Pivotal Software, Inc. ("Pivotal"), companies which are majority-owned by Dell Technologies.  All intercompany transactions have been eliminated.

[0001571996-18-000004:notes:500]
On April 27, 2016, SecureWorks completed a registered underwritten initial public offering of its Class A common stock.  As of February 2, 2018, Dell Technologies held approximately 87.1% of the outstanding equity interest in SecureWorks.  As Dell Technologies is the controlling stockholder of SecureWorks, SecureWorks' financial results have been consolidated with those of Dell Technologies.  The portion of the results of operations of SecureWorks allocable to its other owners is shown as net income (loss) attributable to the non-controlling interests in the Consolidated Statements of Income (Loss), as an adjustment to net income (loss) attributable to Dell Technologies stockholders.  Additionally, the cumulative portion of the results of operations of SecureWorks allocable to those other owners, along with the interest in the net assets of SecureWorks attributable to those other owners, is shown as a component of non-controlling interests in the Consolidated Statements of Financial Position as of February 2, 2018.

[0001571996-18-000004:notes:501]
As of February 2, 2018, Dell Technologies held approximately 81.9% of the outstanding equity interest in VMware, Inc.  VMware, Inc.'s financial results have been consolidated with those of Dell Technologies since September 7, 2016, at which time Dell Technologies became VMware, Inc.'s controlling stockholder.  The portion of the results of operations of VMware, Inc. allocable to its other owners is shown as net income (loss) attributable to the non-controlling interests in the Consolidated Statements of Income (Loss) as an adjustment to net income (loss) attributable to Dell Technologies stockholders.  Additionally, the cumulative portion of the results of operations of VMware, Inc. allocable to those other owners, along with the interest in the net assets of VMware, Inc. attributable to those other owners, is shown as a component of non-controlling interests in the Consolidated Statements of Financial Position as of February 2, 2018.

[0001571996-18-000004:notes:502]
As of February 2, 2018, Dell Technologies held approximately 77.1% of the outstanding equity interest in Pivotal.  Pivotal's financial results have been consolidated with those of Dell Technologies since September 7, 2016, at which time Dell Technologies became Pivotal's controlling stockholder.  A portion of the non-controlling interest in Pivotal is held by third parties in the form of preferred equity instruments.  Accordingly, there is no net income attributable to this portion of non-controlling interest in the Consolidated Statements of Income (Loss).  The other portion of the non-controlling interest in Pivotal is held by third parties in the form of common stock.  As such, there is net income (loss) attributable to this portion of non-controlling interest in the Consolidated Statements of Income (Loss) as an adjustment to net income (loss) attributable to Dell Technologies stockholders.  Additionally, the interest in the net assets of Pivotal attributable to those other owners is shown as a component of non-controlling interests in the Consolidated Statements of Financial Position as of February 2, 2018.

[0001571996-18-000004:notes:503]
Use of Estimates — The preparation of financial statements in accordance with GAAP requires management to make estimates and assumptions that affect the amounts reported in the Consolidated Financial Statements and the accompanying Notes.  Actual results could differ materially from those estimates.

[0001571996-18-000004:notes:504]
Cash and Cash Equivalents — All highly liquid investments, including credit card receivables due from banks, with original maturities of 90 days or less at date of purchase, are reported at fair value and are considered to be cash equivalents.  All other investments not considered to be cash equivalents are separately categorized as investments.

[0001571996-18-000004:notes:505]
Investments — All debt security investments with effective maturities in excess of one year and substantially all equity and other securities are recorded as long-term investments in the Consolidated Statements of Financial Position.  In comparison, debt security instruments with an effective maturity of one year or less are classified as short-term investments in the Consolidated Statements of Financial Position.

[0001571996-18-000004:notes:506]
Allowance for Doubtful Accounts — The Company recognizes an allowance for losses on accounts receivable in an amount equal to the estimated probable losses, net of recoveries.  The allowance is based on an analysis of current receivables aging and expected future write-offs, as well as an assessment of specific identifiable customer accounts considered at risk or uncollectible.  The expense associated with the allowance for doubtful accounts is recognized in selling, general, and administrative expenses.

[0001571996-18-000004:notes:507]
Financing Receivables — Financing receivables are presented net of allowance for losses and consist of customer receivables and residual interest.  Customer receivables include revolving loans and fixed-term leases and loans resulting primarily from the sale of the Company's products and services.  The Company has two portfolios: (1) fixed-term leases and loans and (2) revolving loans, and assesses risk at the portfolio level to determine the appropriate allowance levels.  The portfolio segments are further segregated into classes based on products, customer type, and credit risk evaluation: (1) Revolving - Dell Preferred Account ("DPA"); (2) Revolving - Dell Business Credit ("DBC"); and (3) Fixed-term - Consumer and Commercial.  Fixed-term leases and loans are offered to qualified small and medium-sized businesses, large commercial accounts, governmental organizations, and educational entities.  Additionally, fixed-term loans are also offered to certain individual consumer customers.  Revolving loans are offered under private label credit financing programs.  The DPA revolving loan programs are offered to individual consumers and the DBC revolving loan programs are offered to small and medium-sized business customers.

[0001571996-18-000004:notes:508]
The Company retains a residual interest in equipment leased under its fixed-term lease programs.  The amount of the residual interest is established at the inception of the lease based upon estimates of the value of the equipment at the end of the lease term using historical studies, industry data, and future value-at-risk demand valuation methods.  On a quarterly basis, the Company assesses the carrying amount of its recorded residual values for impairment.  Anticipated declines in specific future residual values that are considered to be other-than-temporary are recorded currently in earnings.

[0001571996-18-000004:notes:509]
Allowance for Financing Receivable Losses — The Company recognizes an allowance for losses on financing receivables in an amount equal to the probable losses net of recoveries.  The allowance for losses is generally determined at the aggregate portfolio level based on a variety of factors, including historical and anticipated experience, past due receivables, receivable type, and customer risk profile.  Customer account principal and interest are charged to the allowance for losses when an account is deemed to be uncollectible or generally when the account is 180 days delinquent.  While the Company does not generally place financing receivables on non-accrual status during the delinquency period, accrued interest is included in the allowance for loss calculation and, therefore, the Company is adequately reserved in the event of charge off.  Recoveries on receivables previously charged off as uncollectible are recorded to the allowance for financing receivables losses.  The expense associated with the allowance for financing receivables losses is recognized as cost of net revenue.  Both fixed and revolving receivable loss rates are affected by macroeconomic conditions, including the level of gross domestic product ("GDP") growth, unemployment rates, the level of commercial capital equipment investment, and the credit quality of the borrower.

[0001571996-18-000004:notes:510]
Asset Securitization — The Company transfers certain U.S. and European customer financing receivables to Special Purpose Entities ("SPEs") that meet the definition of a Variable Interest Entity ("VIE") and are consolidated into the Consolidated Financial Statements.  These SPEs are bankruptcy-remote legal entities with separate assets and liabilities.  The purpose of the SPEs is to facilitate the funding of customer receivables in the capital markets.  These SPEs have entered into financing arrangements with multi-seller conduits that, in turn, issue asset-backed debt securities in the capital markets.  The asset securitizations in the SPEs are accounted for as secured borrowings.  See Note 7 of the Notes to the Consolidated Financial Statements for additional information on the impact of the consolidation.

[0001571996-18-000004:notes:511]
Inventories — Inventories are stated at the lower of cost or market with cost being determined on a first-in, first-out basis.  Adjustments to reduce the cost of inventory to its net realizable value are made, if required, for estimated excess, obsolescence, or impaired balances.

[0001571996-18-000004:notes:512]
Property, Plant, and Equipment — Property, plant, and equipment are carried at depreciated cost.  Depreciation is determined using the straight-line method over the shorter of the estimated economic lives of the assets or the lease term.  The estimated useful lives of the Company's property, plant, and equipment are generally as follows:

[0001571996-18-000004:notes:513]
Capitalized Software Development Costs — In accordance with the applicable accounting standards, software development costs related to the development of new product offerings are capitalized subsequent to the establishment of technological feasibility, which is demonstrated by the completion of a detailed program design or working model, if no program design is completed.  The Company amortizes capitalized costs straight line over the estimated useful lives of the products, which is generally two years.

[0001571996-18-000004:notes:514]
As of February 2, 2018, capitalized software development costs were $489 million and are included in other non-current assets, net in the accompanying Consolidated Statements of Financial Position.  Amortization expense for the period ended February 2, 2018 was $82 million.  Amortization expense for the period from September 7, 2016 through February 3, 2017 was immaterial.

[0001571996-18-000004:notes:515]
Prior to the EMC merger transaction, there were no significant capitalized software development costs specific to the legacy businesses of Dell Technologies due to the timing in the research and development process of establishing technological feasibility.

[0001571996-18-000004:notes:516]
The Company capitalizes certain internal and external costs to acquire or create internal use software which are incurred subsequent to the completion of the preliminary project stage.  Development costs are amortized straight line over the shorter of the expected useful life of the software or five years.  Costs associated with maintenance and minor enhancements to the features and functionality of the Company's website are expensed as incurred.

[0001571996-18-000004:notes:517]
Impairment of Long-Lived Assets — The Company reviews long-lived assets for impairment when events or changes in circumstances indicate the carrying amount of an asset may not be recoverable.  The Company assesses the recoverability of the assets based on the undiscounted future cash flows expected from the use and eventual disposition of the asset.  If the carrying amount of the asset is determined not to be recoverable, a write-down to fair value is recorded.  Fair values are determined based on quoted market values, discounted cash flows, or external appraisals, as applicable.  Long-lived assets to be disposed of are reported at the lower of carrying amount or fair value less costs to sell.

[0001571996-18-000004:notes:518]
Business Combinations — The Company accounts for business combinations, including the EMC merger transaction and the going-private transaction described in Note 1 of the Notes to the Consolidated Financial Statements.  See Note 3 of the Notes to the Consolidated Financial Statements for more information on the EMC merger transaction.  Accordingly, the assets and liabilities of the acquired business are recorded at their fair values at the date of acquisition.  The excess of the purchase price over the fair value of the tangible and intangible assets acquired and the liabilities assumed is recorded as goodwill.  During the measurement period, if new information is obtained about facts and circumstances that existed as of the acquisition date, cumulative changes in the estimated fair values of the net assets recorded may change the amount of the purchase price allocable to goodwill.  During the measurement period, which expires one year from the acquisition date, changes to any purchase price allocations that are material to the Company's consolidated financial results will be adjusted in the reporting period in which the adjustment amount is determined.

[0001571996-18-000004:notes:519]
In-process research and development costs are recorded at fair value as an indefinite-lived intangible asset and assessed for impairment thereafter until completion, at which point the asset is amortized over its expected useful life.  All acquisition costs are expensed as incurred, and the results of operations of acquired businesses are included in the Consolidated Financial Statements from the acquisition date.

[0001571996-18-000004:notes:520]
Intangible Assets Including Goodwill — Identifiable intangible assets with finite lives are amortized over their estimated useful lives.  Intangible assets are reviewed for impairment when events and circumstances indicate the asset may be impaired.  Goodwill and indefinite-lived intangible assets are tested for impairment annually during the third fiscal quarter and whenever events or circumstances indicate that an impairment may have occurred.

[0001571996-18-000004:notes:521]
Foreign Currency Translation — The majority of the Company's international sales are made by international subsidiaries, most of which have the U.S. dollar as their functional currency.  The Company's subsidiaries that do not have the U.S. dollar as their functional currency translate assets and liabilities at current rates of exchange in effect at the balance sheet date.  Revenue and expenses from these international subsidiaries are translated using the monthly average exchange rates in effect for the period in which the transactions occur.  Foreign currency translation adjustments are included as a component of accumulated other comprehensive income (loss) ("OCI") in stockholders' equity.

[0001571996-18-000004:notes:522]
Hedging Instruments — The Company uses derivative financial instruments, primarily forwards, options, and swaps, to hedge certain foreign currency and interest rate exposures.  The relationships between hedging instruments and hedged items, as well as the risk management objectives and strategies for undertaking hedge transactions, are formally documented.  The Company does not use derivatives for speculative purposes.

[0001571996-18-000004:notes:523]
Cash flows from derivative instruments are presented in the same category on the Consolidated Statements of Cash Flows as the cash flows from the underlying hedged items.  See Note 9 of the Notes to the Consolidated Financial Statements for a description of the Company's derivative financial instrument activities.

[0001571996-18-000004:notes:524]
Revenue Recognition — Net revenue primarily includes sales of hardware, services, software licenses, and peripherals.  The Company recognizes revenue for these products and services when it is realized or realizable and earned.  Revenue is recognized when persuasive evidence of an arrangement exists; delivery has occurred or services have been rendered; the Company's fee to its customer is fixed or determinable; and collection of the resulting receivable is reasonably assured.  This policy is applicable to all sales, including sales to resellers and end-users.

[0001571996-18-000004:notes:525]
Standard Warranty Liabilities — The Company records warranty liabilities for estimated costs of fulfilling its obligations under standard limited hardware and software warranties at the time of sale.  The liability for standard warranties is included in accrued and other current and other non-current liabilities in the Consolidated Statements of Financial Position.  The specific warranty terms and conditions vary depending upon the product sold and the country in which the Company does business, but generally includes technical support, parts, and labor over a period ranging from one to three years.  Factors that affect the Company's warranty liability include the number of installed units currently under warranty, historical and anticipated rates of warranty claims on those units, and cost per claim to satisfy the Company's warranty obligation.  The anticipated rate of warranty claims is the primary factor impacting the estimated warranty obligation.  The other factors are less significant due to the fact that the average remaining aggregate warranty period of the covered installed base is approximately 19 months, repair parts are generally already in stock or available at pre-determined prices, and labor rates are generally arranged at pre-established amounts with service providers.  Warranty claims are relatively predictable based on historical experience of failure rates.  If actual results differ from the estimates, the Company revises its estimated warranty liability.  Each quarter, the Company reevaluates its estimates to assess the adequacy of its recorded warranty liabilities and adjusts the amounts as necessary.

[0001571996-18-000004:notes:526]
Deferred Revenue — Deferred revenue is recorded when billings have been generated or payments have been received for undelivered products or services, or in the situation where revenue recognition criteria have not been met.  Deferred revenue represents amounts received in advance for extended warranty services, software maintenance, unearned license fees, and deferred profit on third-party software offerings.  Deferred revenue is recognized on these items when the revenue recognition criteria are met, generally resulting in ratable recognition over the contract term.  The Company also has deferred revenue related to undelivered hardware and professional services, consisting of installations and consulting engagements, which are recognized as the Company's obligations under the contract are completed.

[0001571996-18-000004:notes:527]
Vendor Rebates and Settlements — The Company may receive consideration from vendors in the normal course of business.  Certain of these funds are rebates of purchase price paid and others are related to reimbursement of costs incurred by the Company to sell the vendor's products.  The Company recognizes a reduction of cost of goods sold if the funds are determined to be a reduction of the price of the vendor's products.  If the consideration is a reimbursement of costs incurred by the Company to sell or develop the vendor's products, then the consideration is classified as a reduction of that cost, most often operating expenses, in the Consolidated Statements of Income (Loss).  In order to be recognized as a reduction of operating expenses, the reimbursement must be for a specific, incremental, and identifiable cost incurred by the Company in selling the vendor's products or services.

[0001571996-18-000004:notes:528]
In addition, the Company may settle commercial disputes with vendors from time to time.  Claims for loss recoveries are recognized when a loss event has occurred, recovery is considered probable, the agreement is finalized, and collectibility is assured.  Amounts received by the Company from vendors for loss recoveries are generally recorded as a reduction of cost of goods sold.

[0001571996-18-000004:notes:529]
Loss Contingencies — The Company is subject to the possibility of various losses arising in the ordinary course of business.  The Company considers the likelihood of loss or impairment of an asset or the incurrence of a liability, as well as the Company's ability to reasonably estimate the amount of loss, in determining loss contingencies.  An estimated loss contingency is accrued when it is probable that an asset has been impaired or a liability has been incurred and the amount of loss can be reasonably estimated.  The Company regularly evaluates current information available to determine whether such accruals should be adjusted and whether new accruals are required.

[0001571996-18-000004:notes:530]
Shipping Costs — The Company's shipping and handling costs are included in cost of net revenue in the Consolidated Statements of Income (Loss).

[0001571996-18-000004:notes:531]
Selling, General, and Administrative — Selling expenses include items such as sales salaries and commissions, marketing and advertising costs, and contractor services.  Advertising costs are expensed as incurred in selling, general, and administrative expenses in the Consolidated Statements of Income (Loss).  For the fiscal years ended February 2, 2018, February 3, 2017, and January 29, 2016, advertising expenses were $1,045 million, $772 million, and $594 million, respectively.  General and administrative expenses include items for the Company's administrative functions, such as finance, legal, human resources, and information technology support.  These functions include costs for items such as salaries, maintenance and supplies, insurance, depreciation expense, and allowance for doubtful accounts.

[0001571996-18-000004:notes:532]
Research and Development — Research and development ("R&D") costs are expensed as incurred.  R&D costs include salaries and benefits and other personnel-related costs associated with product development.  Also included in R&D expenses are infrastructure costs, which consist of equipment and material costs, facilities-related costs, depreciation expense, and intangible asset amortization.

[0001571996-18-000004:notes:533]
Income Taxes — Deferred tax assets and liabilities are recorded based on the difference between the financial statement and tax basis of assets and liabilities using enacted tax rates in effect for the year in which the differences are expected to reverse.  The Company calculates a provision for income taxes using the asset and liability method, under which deferred tax assets and liabilities are recognized by identifying the temporary differences arising from the different treatment of items for tax and accounting purposes.  The Company provides valuation allowances for deferred tax assets, where appropriate.  In assessing the need for a valuation allowance, the Company considers all available evidence for each jurisdiction, including past operating results, estimates of future taxable income, and the feasibility of ongoing tax planning strategies.  In the event the Company determines that all or part of the net deferred tax assets are not realizable in the future, the Company will make an adjustment to the valuation allowance that would be charged to earnings in the period in which such determination is made.

[0001571996-18-000004:notes:534]
The accounting guidance for uncertainties in income tax prescribes a comprehensive model for the financial statement recognition, measurement, presentation, and disclosure of uncertain tax positions taken or expected to be taken in income tax returns.  The Company recognizes a tax benefit from an uncertain tax position in the financial statements only when it is more likely than not that the position will be sustained upon examination, including resolution of any related appeals or litigation processes, based on the technical merits and a consideration of the relevant taxing authority's administrative practices and precedents.

[0001571996-18-000004:notes:535]
Stock-Based Compensation — The Company measures stock-based compensation expense for all share-based awards granted based on the estimated fair value of those awards at grant date.  For service-based stock options, the Company typically estimates the fair value of these awards using the Black-Scholes valuation model and for performance-based stock options, the Company estimates the fair value of these awards using the Monte Carlo valuation model.

[0001571996-18-000004:notes:536]
The compensation cost of service-based stock options, restricted stock, and restricted stock units is recognized net of any estimated forfeitures on a straight-line basis over the employee requisite service period.  Compensation cost for performance-based options, containing a market condition, is recognized on a graded accelerated basis net of estimated forfeitures over the requisite service period.  Forfeiture rates are estimated at grant date based on historical experience and adjusted in subsequent periods for differences in actual forfeitures from those estimates.  See Note 19 of the Notes to the Consolidated Financial Statements for further discussion of stock-based compensation.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001571996-18-000004:notes:537]
CAPITALIZATION

[0001571996-18-000004:notes:538]
On June 26, 2017, the stockholders of the Company voted at the Company’s 2017 annual meeting of stockholders to adopt an amendment to the Company’s certificate of incorporation to increase (1) the total authorized number of shares of the Company’s capital stock, including preferred stock, from 2,144,025,308 shares to 9,144,025,308 shares, (2) the total authorized number of shares of the Company’s common stock from 2,143,025,308 shares to 9,143,025,308 shares and (3) the total authorized number of shares of the Company’s Class C Common Stock from 900,000,000 shares to 7,900,000,000 shares, in each case representing an increase of seven billion shares.  A certificate of amendment to the Company’s certificate of incorporation effectuating the amendment was filed with the Secretary of State of the State of Delaware on June 29, 2017 and became effective on that date.

[0001571996-18-000004:notes:539]
Preferred Stock — The Company is authorized to issue one million shares of preferred stock, par value $.01 per share.  As of February 2, 2018, no shares of preferred stock were issued or outstanding.

[0001571996-18-000004:notes:540]
Common Stock

[0001571996-18-000004:notes:541]
DHI Group Common Stock and DHI Group— The Class A Common Stock, the Class B Common Stock, the Class C Common Stock, and the Class D Common Stock are collectively referred to as the DHI Group Common Stock.  The par value for all classes of DHI Group Common Stock is $.01 per share.  The Class A Common Stock, the Class B Common Stock, the Class C Common Stock, and the Class D Common Stock share equally in dividends declared or accumulated and have equal participation rights in undistributed earnings.  The DHI Group generally refers to the direct and indirect interest of Dell Technologies in all of Dell Technologies' business, assets, properties, liabilities, and preferred stock other than those attributable to the Class V Group, as well as the DHI Group's retained interest in the Class V Group.

[0001571996-18-000004:notes:542]
Of the 164 million shares of DHI Group Common Stock issued during the fiscal year ended February 3, 2017 (other than in connection with the reclassification of the previously outstanding Series A, Series B, and Series C common stock of the Company), 160 million shares were issued in connection with the EMC merger transaction.  The Company issued and sold the following shares of DHI Group Common Stock at a purchase price of $27.50 per share to the persons identified below for an aggregate purchase price of $4.4 billion, pursuant to four separate common stock purchase agreements:

[0001571996-18-000004:notes:543]
| • | 86,909,091 shares of Class A Common Stock to Michael S. Dell and a separate property trust for the benefit of his wife |

[0001571996-18-000004:notes:544]
| • | 16,104,050 shares of Class A Common Stock to investment funds affiliated with MSD Partners, L.P. |

[0001571996-18-000004:notes:545]
| • | 38,805,040 shares of Class B Common Stock to investment funds affiliated with Silver Lake Partners |

[0001571996-18-000004:notes:546]
| • | 18,181,818 shares of Class C Common Stock to Temasek Holdings Private Limited |

[0001571996-18-000004:notes:547]
The Company applied the proceeds from the sale of the shares to finance a portion of the consideration for the EMC merger transaction.

[0001571996-18-000004:notes:548]
Class V Common Stock and Class V Group — In connection with the EMC merger transaction, the Company authorized 343 million shares of Class V Common Stock.  The Class V Common Stock is a type of common stock commonly referred to as a tracking stock, which is a class of common stock that is intended to track the economic performance of a defined set of assets and liabilities.  As of February 2, 2018, the 199 million shares of outstanding Class V Common Stock were intended to track the economic performance of approximately 61% of Dell Technologies' economic interest in the Class V Group.  The Class V Group as of such date consisted solely of approximately 331 million shares of VMware, Inc. common stock held by the Company.  The remaining 39% economic interest in the Class V Group as of February 2, 2018 was represented by the approximately 127 million retained interest shares held by the DHI Group.

[0001571996-18-000004:notes:549]
Repurchases of Common Stock; Treasury Stock

[0001571996-18-000004:notes:550]
Class V Common Stock Repurchases by Dell Technologies Inc. — On September 7, 2016, the board of directors of the Company approved a stock repurchase program (the "DHI Group Repurchase Program") under which the Company is authorized to use assets of the DHI Group to repurchase up to $1.0 billion of shares of Class V Common Stock over a period of two years.  During the fiscal year ended February 3, 2017, the Company repurchased 7 million shares of Class V Common Stock for $324 million using cash of the DHI Group.  Shares repurchased under the DHI Group Repurchase Program are being held as treasury stock at cost.  On December 13, 2016, the board of directors approved the suspension of the DHI Group Repurchase Program until such time as the board of directors authorizes the reinstatement of that program.  As of February 2, 2018, the Company's remaining authorized amount for share repurchases under the DHI Group Repurchase Program was $676 million.  As cash of the DHI Group was used for Class V Common Stock repurchases under the DHI Group Repurchase Program, these repurchased shares were attributed to the DHI Group for the purposes of determining the DHI Group's retained interest in the Class V Group.  As a result, the number of retained interest shares of the DHI Group, which, together with the number of shares of Class V Common Stock outstanding, are used to calculate such retained interest, increased on a one-for-one basis for each share of Class V Common Stock repurchased under the program.

[0001571996-18-000004:notes:551]
On December 13, 2016, the board of directors approved a stock repurchase program (the "Class V Group Repurchase Program") which authorized the Company to use assets of the Class V Group to repurchase up to $500 million of shares of Class V Common Stock over a period of six months.  During the fiscal year ended February 2, 2018, the Company repurchased 1.3 million shares of Class V Common Stock for $82 million pursuant to and in completion of this initial authorization.  The Company repurchased a total of 8.4 million shares under this initial authorization, including shares repurchased during the fiscal year ended February 3, 2017.

[0001571996-18-000004:notes:552]
On March 27, 2017 and August 18, 2017, the board of directors approved two amendments of the Class V Group Repurchase Program (the "March 2017 Class V Group Repurchase Program" and the “August 2017 Class V Group Repurchase Program,” respectively) which, when combined, authorized the Company to use assets of the Class V Group to repurchase up to an additional $600 million of shares of Class V Common Stock over additional six month periods from the respective board approval dates.  On May 9, 2017, the Company completed the March 2017 Class V Group Repurchase Program, pursuant to which it repurchased 4.6 million shares of Class V Common Stock for $300 million.  On October 31, 2017, the Company completed the August 2017 Class V Group Repurchase Program, pursuant to which it repurchased 3.8 million shares of Class V Common Stock for $300 million.

[0001571996-18-000004:notes:553]
All shares of Class V Common Stock repurchased by the Company pursuant to the repurchase programs are held as treasury stock at cost.  The repurchase of shares pursuant to the Class V Group repurchase programs was funded from proceeds received by the Class V Group from the sale by a subsidiary of the Company of shares of Class A common stock of VMware, Inc. owned by such subsidiary, as described below under "Class A Common Stock Repurchases by VMware, Inc."  Share repurchases made by VMware, Inc. of its Class A common stock from a subsidiary of the Company do not affect the determination of the respective interests of the Class V Common Stock and the DHI Group in the Class V Group.  See Exhibit 99.1 filed with the annual report on Form 10-K for the fiscal year ended  February 2, 2018 for more information regarding Unaudited Attributed Financial Information for the Class V Group.

[0001571996-18-000004:notes:554]
Class A Common Stock Repurchases by VMware, Inc. — On December 15, 2016, the Company entered into a stock purchase agreement with VMware, Inc. (the "December 2016 Stock Purchase Agreement"), pursuant to which VMware, Inc. agreed to repurchase for cash $500 million of shares of VMware, Inc. Class A common stock from a subsidiary of the Company.  During the fiscal year ended February 2, 2018, VMware, Inc. repurchased 1.4 million shares for $125 million pursuant to and in completion of the December 2016 Stock Purchase Agreement.  VMware, Inc. repurchased a total of 6.2 million shares under this agreement, including shares repurchased during the fiscal year ended February 3, 2017.  The Company applied the proceeds from the sale to the repurchase of shares of its Class V Common Stock under the Class V Group Repurchase Program described above.  All shares repurchased under VMware, Inc.'s stock repurchase programs are retired.

[0001571996-18-000004:notes:555]
In January 2017 and August 2017, VMware, Inc.'s board of directors authorized the repurchase of up to $2.2 billion of shares of VMware, Inc. Class A common stock (the "January 2017 Authorization" for up to $1.2 billion through the end of Fiscal 2018, and the "August 2017 Authorization" for up to $1.0 billion through August 31, 2018).  On March 29, 2017 and August 23, 2017, the Company entered into two new stock purchase agreements with VMware, Inc. (the "March 2017 Stock Purchase Agreement" and the "August 2017 Stock Purchase Agreement," respectively), pursuant to which VMware, Inc. agreed to repurchase for cash a total of $600 million of shares of VMware, Inc. Class A common stock from a subsidiary of the Company.  VMware, Inc. repurchased approximately 6.1 million shares of Class A common stock, consisting of 3.4 million shares pursuant to the March 2017 Stock Purchase Agreement and 2.7 million shares pursuant to the August 2017 Stock Purchase Agreement.  The proceeds from the sales were applied by the Company to the repurchase of shares of the Class V Common Stock under the March 2017 and August 2017 Class V Group Repurchase Programs described above.  As of November 3, 2017, the sale transactions under the March 2017 and August 2017 Stock Purchase Agreements were completed.  The purchase prices of the 3.4 million shares and 2.7 million shares repurchased by VMware, Inc. were each based on separate volume-weighted average per share prices of the Class A common stock as reported on the New York Stock Exchange during separate specified reference periods, less a discount of 3.5% from the respective volume-weighted average per share price.

[0001571996-18-000004:notes:556]
During the fiscal year ended February 2, 2018, VMware, Inc. repurchased 6.4 million shares of Class A common stock in the open market for $724 million.

[0001571996-18-000004:notes:557]
As of February 2, 2018, the cumulative authorized amount remaining for share repurchases by VMware, Inc. was $876 million, which represents the $2.2 billion authorized since January 2017, less $600 million of the Class A common stock repurchases from a subsidiary of the Company during the fiscal year ended February 2, 2018, and less $724 million of the Class A common stock repurchases in the open market during the fiscal year ended February 2, 2018.

[0001571996-18-000004:notes:558]
DHI Group Common Stock Repurchases — During the fiscal years ended February 2, 2018 and February 3, 2017, the Company repurchased an immaterial number of shares of DHI Group Common Stock for approximately $6 million and $10 million, respectively.


## us-gaap:SubsequentEventsTextBlock

[0001571996-18-000004:notes:559]
SUBSEQUENT EVENTS

[0001571996-18-000004:notes:560]
Divestiture — On February 12, 2018, the Company entered into an agreement with Carbonite, Inc. to sell Mozy, Inc., a business of EMC that provides solutions for enterprise cloud backup, for a transaction price of approximately $146 million.  Upon the closing of the transaction on March 19, 2018, the Company entered into a transition services agreement with Carbonite, Inc. pursuant to which the Company provides various administrative services on an interim transitional basis with an option to renew after that period.

[0001571996-18-000004:notes:561]
DFS Securitization Facility — On February 9, 2018, the Company entered into a credit agreement with financial institutions that provides DFS with $1 billion of additional capacity for the funding of U.S. customer financing receivables.  The debt incurred under this agreement will be collateralized solely by the U.S. financing receivables in the facility.  The debt will accrue interest at a variable rate and the duration of the debt will be based on the terms of the underlying financing receivables.  Unless earlier terminated, the credit agreement will terminate on February 10, 2020.

[0001571996-18-000004:notes:562]
Pivotal Initial Public Offering — On March 23, 2018, in preparation for an initial public offering of Pivotal's Class A common stock, Pivotal filed a registration statement on Form S-1 with the SEC.  No public market currently exists for Pivotal's Class A common stock.

[0001571996-18-000004:notes:563]
Other than the matters identified above, there were no known events occurring after the balance sheet date and up until the date of the issuance of this report that would materially affect the information presented herein.
