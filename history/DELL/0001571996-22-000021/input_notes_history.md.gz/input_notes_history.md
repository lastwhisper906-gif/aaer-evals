# DELL note change history — 0001571996-21-000063 → 0001571996-22-000021


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-06-06):
[0001571996-22-000021:note_history:1]
COMMITMENTS AND CONTINGENCIES 
Purchase Obligations
  (was, 2021-12-03, similarity 0.6591):
[0001571996-21-000063:note_history:1]
NOTE 9 — COMMITMENTS AND CONTINGENCIES

- changed (2022-06-06):
[0001571996-22-000021:note_history:2]
The Company has contractual obligations to purchase goods or services, which specify significant terms (including fixed or minimum quantities to be purchased), fixed, minimum, or variable price provisions; and the approximate timing of the transaction.  As of April 29, 2022, such purchase obligations were $3.1 billion, $0.4 billion, and $0.8 billion for the remaining nine months of Fiscal 2023, Fiscal 2024, and Fiscal 2025 and thereafter, respectively.
  (was, 2021-12-03, similarity 0.87):
[0001571996-21-000063:note_history:2]
The Company has contractual obligations to purchase goods or services, which specify significant terms, including fixed or minimum quantities to be purchased; fixed, minimum, or variable price provisions; and the approximate timing of the transaction.  As of October 29, 2021, purchase obligations were $5.2 billion, $0.7 billion, and $0.8 billion for the remaining three months of Fiscal 2022, for Fiscal 2023, and for Fiscal 2024 and thereafter, respectively.

- changed (2022-06-06):
[0001571996-22-000021:note_history:3]
The Company is involved in various claims, suits, assessments, investigations, and legal proceedings that arise from time to time in the ordinary course of its business, including those identified below, consisting of matters involving consumer, antitrust, tax, intellectual property, and other issues on a global basis.  Pursuant to the Separation and Distribution Agreement referred to below, Dell Technologies shares responsibility with VMware for certain matters, as indicated below, and VMware has agreed to indemnify Dell Technologies in whole or in part with respect to certain matters.
  (was, 2021-12-03, similarity 0.7018):
[0001571996-21-000063:note_history:3]
The Company is involved in various claims, suits, assessments, investigations, and legal proceedings that arise from time to time in the ordinary course of its business, including those identified below, consisting of matters involving consumer, antitrust, tax, intellectual property, and other issues on a global basis.

- added (2022-06-06):
[0001571996-22-000021:note_history:4]
The Company accrues a liability when it believes that it is both probable that a liability has been incurred and that it can reasonably estimate the amount of the loss.  The Company reviews these accruals at least quarterly and adjusts them to reflect ongoing negotiations, settlements, rulings, advice of legal counsel, and other relevant information.  To the extent new information is obtained and the Company’s views on the probable outcomes of claims, suits, assessments, investigations, or legal proceedings change, changes in the Company’s accrued liabilities are recorded in the period in which such a determination is made.  For some matters, the amount of liability is not probable or the amount cannot be reasonably estimated and therefore accruals have not been made.

- added (2022-06-06):
[0001571996-22-000021:note_history:5]
Class Actions Related to the Class V Transaction — On December 28, 2018, the Company completed a transaction (the “Class V transaction”) in which it paid $14.0 billion in cash and issued 149,387,617 shares of its Class C Common Stock to holders of its Class V Common Stock in exchange for all outstanding shares of Class V Common Stock.  As a result of the Class V transaction, the tracking stock feature of the Company’s capital structure associated with the Class V Common Stock was terminated.  In November 2018, four purported stockholders brought putative class action complaints arising out of the Class V transaction.  The actions were captioned Hallandale Beach Police and Fire Retirement Plan v. Michael Dell et al. (Civil Action No. 2018-0816-JTL), Howard Karp v. Michael Dell et al. (Civil Action No. 2019-0032-JTL), Miramar Police Officers’ Retirement Plan v. Michael Dell et al. (Civil Action No. 2019-0049-JTL), and Steamfitters Local 449 Pension Plan v. Michael Dell et al. (Civil Action No. 2019-0115-JTL).  The four actions were consolidated in the Delaware Chancery Court into In Re Dell Class V Litigation (Consol. C.A. No. 2018-0816-JTL).  The suit currently names as defendants Michael S. Dell and certain of the other directors serving on the board of directors at the time of the Class V transaction, certain stockholders of the Company, consisting of Michael S. Dell and Silver Lake Group LLC and certain of its affiliated funds, and Goldman Sachs & Co. LLC (“Goldman Sachs”), which served as financial advisor to the Company in connection with the Class V transaction.  In an amended complaint filed in August 2019,  the plaintiffs generally allege that the director and stockholder defendants breached their fiduciary duties under Delaware law to the former holders of Class V Common Stock in connection with the Class V transaction by offering a transaction value that was allegedly billions of dollars below the fair value.  The plaintiffs contend that the offer understated the value of shares surrendered by the former stockholders, which the plaintiffs allege should have reflected higher alternative valuations, including a valuation related to the value of the shares of VMware, Inc. common stock, and that the difference in values was wrongfully appropriated by the stockholder defendants.  On August 20, 2021, the plaintiffs added Goldman Sachs as a defendant and allege that it aided and abetted the alleged primary violations.  In the complaint, the plaintiffs seek, among other remedies, a judicial declaration that the director and stockholder defendants breached their fiduciary duties.  The plaintiffs also seek in the complaint disgorgement of all profits, benefits, and other compensation obtained by the defendants as a result of such alleged conduct and an award of unspecified damages, fees, and costs.  The defendants filed a motion to dismiss the action in September 2019.  The court denied the motion in June 2020 and the case is currently in the discovery phase.  Trial is scheduled to begin on December 5, 2022.  The Company is not a defendant in this action but is subject to director indemnification provisions under its certificate of incorporation and bylaws, and is a party to agreements with

- added (2022-06-06):
[0001571996-22-000021:note_history:6]
the defendants that contain indemnification obligations of the Company, conditioned on the satisfaction of the requirements set forth in such agreements, relating to service as a director, ownership of the Company’s securities, and provision of services, as applicable.

- changed (2022-06-06):
[0001571996-22-000021:note_history:7]
Class Actions Related to VMware, Inc.’s Acquisition of Pivotal — Two purported stockholders brought putative class action complaints arising out of VMware, Inc.’s acquisition of Pivotal Software, Inc. on December 30, 2019.  The two actions were consolidated in the Delaware Chancery Court into In re: Pivotal Software, Inc. Stockholders Litigation (Civil Action No. 2020-0440-KSJM).  The complaint names as defendants the Company, VMware, Inc., Michael S. Dell, and certain officers of Pivotal.  The plaintiffs generally allege that the defendants breached their fiduciary duties to the former holders of Pivotal Class A Common Stock in connection with VMware, Inc.’s acquisition of Pivotal by allegedly causing Pivotal to enter into a transaction that favored the interests of Pivotal’s controlling stockholders at the expense of such former stockholders.  The parties have reached an agreement to settle the litigation and are seeking the court’s approval of the settlement.
  (was, 2021-12-03, similarity 0.8099):
[0001571996-21-000063:note_history:7]
Class Actions Related to VMware, Inc.’s Acquisition of Pivotal — Two purported stockholders brought putative class action complaints arising out of VMware, Inc.’s acquisition of Pivotal Software, Inc. on December 30, 2019 as described in Note 1 of the Notes to the Condensed Consolidated Financial Statements.  The two actions were consolidated in the Delaware Chancery Court into In re: Pivotal Software, Inc. Stockholders Litigation (Civil Action No. 2020-0440-KSJM).  The complaint names as defendants the Company, VMware, Inc., Michael S. Dell, and certain officers of Pivotal.  The plaintiffs generally allege that the defendants breached their fiduciary duties to the former holders of Pivotal Class A common stock in connection with VMware, Inc.’s acquisition of Pivotal by allegedly causing Pivotal to enter into a transaction that favored the interests of Pivotal’s controlling stockholders at the expense of such former stockholders.  The plaintiffs seek, among other remedies, a judicial declaration that the defendants breached their fiduciary duties and an award of damages, fees, and costs.  Trial is currently scheduled to begin on July 6, 2022.

- changed (2022-06-06):
[0001571996-22-000021:note_history:8]
Other Litigation — Dell does not currently anticipate that any of the other various legal proceedings it is involved in will have a material adverse effect on its business, financial condition, results of operations, or cash flows.
  (was, 2021-12-03, similarity 0.8651):
[0001571996-21-000063:note_history:8]
Other Litigation — Dell does not currently expect that any other proceedings or matters will have a material adverse effect on its business, financial condition, results of operations, or cash flows.

- changed (2022-06-06):
[0001571996-22-000021:note_history:9]
In accordance with the relevant accounting guidance, the Company provides disclosures of matters where it is at least reasonably possible that the Company could experience a material loss exceeding the amounts already accrued for these or other proceedings or matters.  In addition, the Company also discloses matters based on its consideration of other matters and qualitative factors, including the experience of other companies in the industry, and investor, customer, and employee relations considerations.  As of April 29, 2022, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for these or other proceedings or matters has been incurred.  However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company’s business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters.  Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company’s business, financial condition, results of operations, or cash flows will depend on a number of factors, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.
  (was, 2021-12-03, similarity 0.9958):
[0001571996-21-000063:note_history:9]
In accordance with the relevant accounting guidance, the Company provides disclosures of matters where it is at least reasonably possible that the Company could experience a material loss exceeding the amounts already accrued for these or other proceedings or matters.  In addition, the Company also discloses matters based on its consideration of other matters and qualitative factors, including the experience of other companies in the industry, and investor, customer, and employee relations considerations.  As of October 29, 2021, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for these or other proceedings or matters has been incurred.  However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company’s business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters.  Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company’s business, financial condition, results of operations, or cash flows will depend on a number of factors, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.

- changed (2022-06-06):
[0001571996-22-000021:note_history:10]
Indemnifications Obligations
  (was, 2021-12-03, similarity 0.7273):
[0001571996-21-000063:note_history:10]
Indemnifications

- changed (2022-06-06):
[0001571996-22-000021:note_history:11]
In the ordinary course of business, the Company enters into various contracts under which it may agree to indemnify other parties for losses incurred from certain events as defined in the relevant contract, such as litigation, regulatory penalties, or claims relating to past performance.  Such indemnification obligations may not be subject to maximum loss clauses.  Historically, payments related to these indemnification obligations have not been material to the Company.
  (was, 2021-12-03, similarity 0.9255):
[0001571996-21-000063:note_history:11]
In the ordinary course of business, the Company enters into contractual arrangements under which it may agree to indemnify other parties for losses incurred from certain events as defined in the relevant contract, such as litigation, regulatory penalties, or claims relating to past performance.  Such indemnification obligations may not be subject to maximum loss clauses.  Historically, payments related to these indemnifications have not been material to the Company.

- added (2022-06-06):
[0001571996-22-000021:note_history:12]
Under the Separation and Distribution Agreement described in Note 2 of the Notes to the Condensed Consolidated Financial Statements, Dell Technologies has agreed to indemnify VMware, Inc., each of its subsidiaries and each of their respective directors, officers, and employees from and against all liabilities relating to, arising out of or resulting from, among other matters, the liabilities allocated to Dell Technologies as part of the separation of  Dell Technologies and VMware and their respective businesses as a result of the VMware Spin-off (the “Separation”).  VMware similarly has agreed to indemnify Dell Technologies, Inc., each of its subsidiaries and each of their respective directors, officers, and employees from and against all liabilities relating to, arising out of or resulting from, among other matters, the liabilities allocated to VMware as part of the Separation.  Dell Technologies expects VMware to fully perform under the terms of the Separation and Distribution Agreement.
For information on the cross-indemnifications related to the tax matters agreement between the Company and VMware described in Note 2 of the Notes to the Condensed Consolidated Financial Statements effective upon the Separation on November 1, 2021, see Note 2 and Note 16 of the Notes to the Condensed Consolidated Financial Statements.

- removed (2022-06-06):
[0001571996-21-000063:note_history:13]
Purchase Obligations

- removed (2022-06-06):
[0001571996-21-000063:note_history:14]
The Company accrues a liability when it believes that it is both probable that a liability has been incurred and that it can reasonably estimate the amount of the loss.  The Company reviews these accruals at least quarterly and adjusts them to reflect ongoing negotiations, settlements, rulings, advice of legal counsel, and other relevant information.  As additional information is obtained and the Company’s views on the probable outcomes of claims, suits, assessments, investigations, or legal proceedings change, the Company would record related impacts to accrued liabilities in the period in which a determination is made.  For some matters, the incurrence of a liability is not probable or the amount cannot be reasonably estimated and therefore accruals have not been made.

- removed (2022-06-06):
[0001571996-21-000063:note_history:15]
Class Actions Related to the Class V Transaction — Four purported stockholders brought putative class action complaints arising out of the Class V transaction described in Note 1 of the Notes to the Condensed Consolidated Financial Statements.  The actions were captioned Hallandale Beach Police and Fire Retirement Plan v. Michael Dell et al. (Civil Action No. 2018-0816-JTL), Howard Karp v. Michael Dell et al. (Civil Action No. 2019-0032-JTL), Miramar Police Officers’ Retirement Plan v. Michael Dell et al. (Civil Action No. 2019-0049-JTL), and Steamfitters Local 449 Pension Plan v. Michael Dell et al. (Civil Action No. 2019-0115-JTL).  The four actions were consolidated in the Delaware Chancery Court into In Re Dell Class V Litigation (Consol. C.A. No. 2018-0816-JTL), which names as defendants the Company’s board of directors, Goldman Sachs & Co. LLC,  and certain stockholders of the Company, including Michael S. Dell.  The plaintiffs generally allege that the defendants breached their fiduciary duties to the former holders of Class V Common Stock in connection with the Class V transaction by allegedly causing the Company to enter into a transaction that favored the interests of the controlling stockholders at the expense of such former stockholders.  The plaintiffs seek, among other remedies, a judicial declaration that the defendants breached their fiduciary duties and an award of damages, fees, and costs.  The plaintiffs filed an amended complaint in August 2019 making substantially similar allegations to those described above.  The defendants filed a motion to dismiss the action in September 2019.  The court denied the motion in June 2020 and the case is currently in the discovery phase.  Trial is currently scheduled to begin on December 5, 2022.

- removed (2022-06-06):
[0001571996-21-000063:note_history:16]
Patent Litigation — On April 25, 2019, Cirba Inc. and Cirba IP, Inc. (collectively, “Cirba”) filed a lawsuit against VMware, Inc. in the United States District Court for the District of Delaware (the “Delaware Court”), alleging two patent infringement claims and three trademark infringement-related claims (the “First Action”).  Following a hearing on August 6, 2019, the Delaware Court denied Cirba’s preliminary injunction motion.  On August 20, 2019, VMware, Inc. filed counterclaims against Cirba, asserting among other claims that Cirba is infringing four VMware, Inc. patents.  The Delaware Court severed those claims from the January 2020 trial on Cirba’s claims.  On January 24, 2020, a jury returned a verdict that VMware, Inc. had willfully infringed Cirba’s two patents and awarded approximately $237 million in damages.  As to Cirba’s trademark-related claims, the jury found that VMware, Inc. was not liable.  A total of $237 million was accrued for the First Action as of January 31, 2020, which reflected the estimated losses that were considered both probable and reasonably estimable at that time.  The amount accrued for this matter was included in Accrued and other in the Consolidated Statements of Financial Position as of January 31, 2020, and the charge was classified in Selling, general and administrative in the Consolidated Statements of Income (Loss) for the fiscal year ended January 31, 2020.  On March 9, 2020, the parties filed post-trial motions in the First Action.  On December 21, 2020, the Delaware Court granted VMware, Inc.’s request for a new trial based, in part, on Cirba’s Inc.’s lack of standing, set aside the verdict and damages award, and denied Cirba’s post-trial motions (the “Post-Trial Order”).

- removed (2022-06-06):
[0001571996-21-000063:note_history:17]
On October 22, 2019, VMware, Inc. filed a separate lawsuit against Cirba in the United States District Court for the Eastern District of Virginia alleging infringement of four additional VMware, Inc. patents (The “Second Action”).  The Virginia court transferred the Second Action to the Delaware Court on February 25, 2020.  On March 23, 2020, Cirba filed a counterclaim asserting one additional patent against VMware, Inc.  The Delaware Court consolidated the First and Second Actions and ordered a consolidated trial on all of the parties’ patent infringement claims and counterclaims.  On May 3, 2021, the Court denied Cirba’s motion to certify the Post-Trial Order to enable an interlocutory appeal to the United States Court of Appeals for the Federal Circuit.  Also, on May 3, 2021, the Court granted Cirba’s motion for leave to assert an additional patent against VMware, Inc.  Separately, VMware has filed challenges with the United States Patent and Trademark Office against each of the four patents that are subject of Cirba’s allegation.  To date, of the four challenges, two ex parte reexams have been granted and one Inter Partes Review has been instituted.  As of January 29, 2021, VMware, Inc. reassessed its estimated loss accrual for the First Action based on the Post-Trial Order and determined that a loss was no longer probable and reasonably estimable with respect to the consolidated First and Second Actions.  Accordingly, the estimated loss accrual recognized during the fiscal year ended January 31, 2020 totaling $237 million was adjusted to $0 with the credit included in Selling, general, and administrative in the Consolidated Statements of Income (Loss) for the fiscal year ended January 29, 2021.  VMware, Inc. has reported that it is unable at this time to assess whether, or to what extent, it may be found liable and, if found liable, the amount any damages that may be awarded.  VMware, Inc. intends to vigorously defend itself in this matter.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock (contingencies) — matched_by: no_current_note, score: 0.0

- removed (2022-06-06):
[0001571996-21-000063:note_history:18]
Legal Matters

- removed (2022-06-06):
[0001571996-21-000063:note_history:19]
The Company is involved in various claims, suits, assessments, investigations, and legal proceedings that arise from time to time in the ordinary course of its business, including those identified below, consisting of matters involving consumer, antitrust, tax, intellectual property, and other issues on a global basis.  
The Company accrues a liability when it believes that it is both probable that a liability has been incurred and that it can reasonably estimate the amount of the loss.  The Company reviews these accruals at least quarterly and adjusts them to reflect ongoing negotiations, settlements, rulings, advice of legal counsel, and other relevant information.  As additional information is obtained and the Company’s views on the probable outcomes of claims, suits, assessments, investigations, or legal proceedings change, the Company would record related impacts to accrued liabilities in the period in which a determination is made.  For some matters, the incurrence of a liability is not probable or the amount cannot be reasonably estimated and therefore accruals have not been made.


## dell:CreditLossFinancialInstrumentLeasesDebtVariableInterestEntitiesAndCustomerReceivablesSalesTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-06-06):
[0001571996-22-000021:note_history:20]
FINANCIAL SERVICES
The Company offers or arranges various financing options and services and alternative payment structures for its customers globally primarily through Dell Financial Services and its affiliates (“DFS”).  The Company also arranges financing for some of its customers in various countries where DFS does not currently operate as a captive enterprise.  The key activities of DFS include originating, collecting, and servicing customer financing arrangements primarily related to the purchase or use of Dell Technologies products and services.  In some cases, DFS also offers financing for the purchase of third-party technology products that complement the Dell Technologies portfolio of products and services.  New financing originations were $2.1 billion and $1.9 billion for the three months ended April 29, 2022 and April 30, 2021, respectively.
  (was, 2021-12-03, similarity 0.6367):
[0001571996-21-000063:note_history:20]
The Company offers or arranges various financing options, services, and alternative payment structures for its customers in North America, Europe, Australia, and New Zealand through Dell Financial Services and its affiliates (“DFS”).  The Company also arranges financing for some of its customers in various countries where DFS does not currently operate as a captive enterprise.  The Company further strengthens customer relationships through flexible consumption models, which enable the Company to offer its customers the option to pay over time and, in certain cases, based on utilization, to provide them with financial flexibility to meet their changing technological requirements.  The key activities of DFS include originating, collecting, and servicing customer financing arrangements primarily related to the purchase or use of Dell Technologies products and services.  In some cases, DFS also offers financing on the purchase of third-party technology products that complement the Dell Technologies portfolio of products and services.  New financing originations were $2.0 billion and $2.1 billion for the three months ended October 29, 2021 and October 30, 2020, respectively, and $5.8 billion and $6.5 billion for the nine months ended October 29, 2021 and October 30, 2020, respectively.

- changed (2022-06-06):
[0001571996-22-000021:note_history:21]
The Company’s lease and loan arrangements with customers are aggregated primarily into the following categories:
  (was, 2021-12-03, similarity 0.9065):
[0001571996-21-000063:note_history:21]
The Company’s loan and lease arrangements with customers are aggregated into the following categories:

- changed (2022-06-06):
[0001571996-22-000021:note_history:22]
Fixed-term leases and loans — The Company enters into financing arrangements with customers who seek lease financing for equipment.  DFS leases are generally classified as sales-type leases or operating leases.  Leases with business customers have fixed terms of generally two to four years.
  (was, 2021-12-03, similarity 0.701):
[0001571996-21-000063:note_history:22]
Fixed-term leases and loans — The Company enters into financing arrangements with customers who seek lease financing for equipment.  DFS leases are classified as sales-type leases, direct financing leases, or operating leases.  Direct financing leases are immaterial.  Leases that commenced prior to the effective date of the current lease accounting standard continue to be accounted for under previous lease accounting guidance.  Leases with business customers have fixed terms of generally two to four years.

- added (2022-06-06):
[0001571996-22-000021:note_history:23]
The Company further strengthens customer relationships through flexible consumption models, which enable the Company to offer its customers the option to pay over time and, in certain cases, based on utilization, to provide them with financial flexibility to meet their changing technological requirements.

- changed (2022-06-06):
[0001571996-22-000021:note_history:24]
|  | April 29, 2022 |  | January 28, 2022 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Financing receivables, net: |  |  |  |  |  |  |  |  |  |  |  |
| Customer receivables, gross (a) | $ | 716 |  |  | $ | 9,483 |  |  | $ | 10,199 |  |  | $ | 750 |  |  | $ | 9,833 |  |  | $ | 10,583 |  |
| Allowances for losses | (94) |  |  | (87) |  |  | (181) |  |  | (102) |  |  | (87) |  |  | (189) |  |
| Customer receivables, net | 622 |  |  | 9,396 |  |  | 10,018 |  |  | 648 |  |  | 9,746 |  |  | 10,394 |  |
| Residual interest | — |  |  | 176 |  |  | 176 |  |  | — |  |  | 217 |  |  | 217 |  |
| Financing receivables, net | $ | 622 |  |  | $ | 9,572 |  |  | $ | 10,194 |  |  | $ | 648 |  |  | $ | 9,963 |  |  | $ | 10,611 |  |
| Short-term | $ | 622 |  |  | $ | 4,174 |  |  | $ | 4,796 |  |  | $ | 648 |  |  | $ | 4,441 |  |  | $ | 5,089 |  |
| Long-term | $ | — |  |  | $ | 5,398 |  |  | $ | 5,398 |  |  | $ | — |  |  | $ | 5,522 |  |  | $ | 5,522 |  |
  (was, 2021-12-03, similarity 0.9924):
[0001571996-21-000063:note_history:24]
|  | October 29, 2021 |  | January 29, 2021 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Financing receivables, net: |  |  |  |  |  |  |  |  |  |  |  |
| Customer receivables, gross (a) | $ | 705 |  |  | $ | 9,495 |  |  | $ | 10,200 |  |  | $ | 796 |  |  | $ | 9,595 |  |  | $ | 10,391 |  |
| Allowances for losses | (112) |  |  | (113) |  |  | (225) |  |  | (148) |  |  | (173) |  |  | (321) |  |
| Customer receivables, net | 593 |  |  | 9,382 |  |  | 9,975 |  |  | 648 |  |  | 9,422 |  |  | 10,070 |  |
| Residual interest | — |  |  | 265 |  |  | 265 |  |  | — |  |  | 424 |  |  | 424 |  |
| Financing receivables, net | $ | 593 |  |  | $ | 9,647 |  |  | $ | 10,240 |  |  | $ | 648 |  |  | $ | 9,846 |  |  | $ | 10,494 |  |
| Short-term | $ | 593 |  |  | $ | 4,377 |  |  | $ | 4,970 |  |  | $ | 648 |  |  | $ | 4,507 |  |  | $ | 5,155 |  |
| Long-term | $ | — |  |  | $ | 5,270 |  |  | $ | 5,270 |  |  | $ | — |  |  | $ | 5,339 |  |  | $ | 5,339 |  |

- changed (2022-06-06):
[0001571996-22-000021:note_history:25]
(a)    Customer receivables, gross include amounts due from customers under revolving loans, fixed-term loans, fixed-term sales-type or direct financing leases, and accrued interest.
  (was, 2021-12-03, similarity 0.9972):
[0001571996-21-000063:note_history:25]
(a)    Customer receivables, gross includes amounts due from customers under revolving loans, fixed-term loans, fixed-term sales-type or direct financing leases, and accrued interest.

- changed (2022-06-06):
[0001571996-22-000021:note_history:26]
The following table presents the changes in allowance for financing receivable losses for the periods indicated:
  (was, 2021-12-03, similarity 0.9911):
[0001571996-21-000063:note_history:26]
The following tables present the changes in allowance for financing receivable losses for the periods indicated:

- added (2022-06-06):
[0001571996-22-000021:note_history:27]
|  | Three Months Ended |
|  | April 29, 2022 |  | April 30, 2021 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |  |  |  |  |  |  |  |  |  |  |  |
| Balances at beginning of period | $ | 102 |  |  | $ | 87 |  |  | $ | 189 |  |  | $ | 148 |  |  | $ | 173 |  |  | $ | 321 |  |
| Charge-offs, net of recoveries | (13) |  |  | (2) |  |  | (15) |  |  | (13) |  |  | (2) |  |  | (15) |  |
| Provision charged to income statement | 5 |  |  | 2 |  |  | 7 |  |  | 4 |  |  | 6 |  |  | 10 |  |
| Balances at end of period | $ | 94 |  |  | $ | 87 |  |  | $ | 181 |  |  | $ | 139 |  |  | $ | 177 |  |  | $ | 316 |  |

- changed (2022-06-06):
[0001571996-22-000021:note_history:28]
|  | April 29, 2022 |  | January 28, 2022 |
|  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |
|  | (in millions) |
| Revolving — DPA | $ | 488 |  |  | $ | 35 |  |  | $ | 12 |  |  | $ | 535 |  |  | $ | 520 |  |  | $ | 40 |  |  | $ | 11 |  |  | $ | 571 |  |
| Revolving — DBC | 164 |  |  | 14 |  |  | 3 |  |  | 181 |  |  | 158 |  |  | 18 |  |  | 3 |  |  | 179 |  |
| Fixed-term — Consumer and Commercial | 8,962 |  |  | 485 |  |  | 36 |  |  | 9,483 |  |  | 9,444 |  |  | 345 |  |  | 44 |  |  | 9,833 |  |
| Total customer receivables, gross | $ | 9,614 |  |  | $ | 534 |  |  | $ | 51 |  |  | $ | 10,199 |  |  | $ | 10,122 |  |  | $ | 403 |  |  | $ | 58 |  |  | $ | 10,583 |  |
  (was, 2021-12-03, similarity 0.9902):
[0001571996-21-000063:note_history:28]
|  | October 29, 2021 |  | January 29, 2021 |
|  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |
|  | (in millions) |
| Revolving — DPA | $ | 485 |  |  | $ | 34 |  |  | $ | 10 |  |  | $ | 529 |  |  | $ | 578 |  |  | $ | 30 |  |  | $ | 13 |  |  | $ | 621 |  |
| Revolving — DBC | 157 |  |  | 16 |  |  | 3 |  |  | 176 |  |  | 157 |  |  | 14 |  |  | 4 |  |  | 175 |  |
| Fixed-term — Consumer and Commercial | 9,063 |  |  | 411 |  |  | 21 |  |  | 9,495 |  |  | 9,192 |  |  | 316 |  |  | 87 |  |  | 9,595 |  |
| Total customer receivables, gross | $ | 9,705 |  |  | $ | 461 |  |  | $ | 34 |  |  | $ | 10,200 |  |  | $ | 9,927 |  |  | $ | 360 |  |  | $ | 104 |  |  | $ | 10,391 |  |

- changed (2022-06-06):
[0001571996-22-000021:note_history:29]
Aging is likely to fluctuate as a result of the variability in volume of large transactions entered into over the period, and the administrative processes that accompany those transactions.  Aging is also impacted by the timing of the Dell Technologies
  (was, 2021-12-03, similarity 0.6676):
[0001571996-21-000063:note_history:29]
Aging is likely to fluctuate as a result of the variability in volume of large transactions entered into over the period, and the administrative processes that accompany those larger transactions.  Aging is also impacted by the timing of the Dell Technologies fiscal period end date, relative to calendar month-end customer payment due dates.  As a result of these factors, fluctuations in aging from period to period do not necessarily indicate a material change in the collectibility of the portfolio.

- added (2022-06-06):
[0001571996-22-000021:note_history:30]
fiscal period end date relative to calendar month-end customer payment due dates.  As a result of these factors, fluctuations in aging from period to period do not necessarily indicate a material change in the collectibility of the portfolio.

- changed (2022-06-06):
[0001571996-22-000021:note_history:31]
Fixed-term consumer and commercial customer receivables are placed on non-accrual status if principal or interest is past due and considered delinquent, or if there is concern about collectibility of a specific customer receivable.  The receivables identified as doubtful for collectibility may be classified as current for aging purposes.  Aged revolving portfolio customer receivables identified as delinquent are charged off.
  (was, 2021-12-03, similarity 0.8441):
[0001571996-21-000063:note_history:31]
Fixed-term consumer and commercial customer receivables are placed on non-accrual status if principal or interest is past due and considered delinquent, or if there is concern about collectibility of a specific customer receivable.  These receivables identified as doubtful for collectibility may be classified as current for aging purposes.  Aged revolving portfolio customer receivables identified as delinquent are charged-off.  Receivables are moved back to accrual status when the collection of  interest is probable, or the collection of the net investment is no longer doubtful.

- changed (2022-06-06):
[0001571996-22-000021:note_history:32]
The following tables present customer receivables, gross, including accrued interest, by credit quality indicator segregated by class, as of the dates indicated:
  (was, 2021-12-03, similarity 0.9306):
[0001571996-21-000063:note_history:32]
The following tables present customer receivables, gross, including accrued interest, by credit quality indicator segregated by class and year of origination, as of the dates indicated:

- changed (2022-06-06):
[0001571996-22-000021:note_history:33]
|  | April 29, 2022 |
|  | Fixed-term — Consumer and Commercial |  |  |  |  |  |  |
|  | Fiscal Year of Origination |  |  |  |  |  |  |
|  | 2023 |  | 2022 |  | 2021 |  | 2020 |  | 2019 |  | Years Prior |  | Revolving — DPA |  | Revolving — DBC |  | Total |
|  | (in millions) |
| Higher | $ | 1,223 |  |  | $ | 2,587 |  |  | $ | 1,450 |  |  | $ | 695 |  |  | $ | 145 |  |  | $ | 15 |  |  | $ | 132 |  |  | $ | 46 |  |  | $ | 6,293 |  |
| Mid | 345 |  |  | 866 |  |  | 621 |  |  | 235 |  |  | 64 |  |  | 8 |  |  | 155 |  |  | 57 |  |  | 2,351 |  |
| Lower | 179 |  |  | 505 |  |  | 369 |  |  | 142 |  |  | 29 |  |  | 5 |  |  | 248 |  |  | 78 |  |  | 1,555 |  |
| Total | $ | 1,747 |  |  | $ | 3,958 |  |  | $ | 2,440 |  |  | $ | 1,072 |  |  | $ | 238 |  |  | $ | 28 |  |  | $ | 535 |  |  | $ | 181 |  |  | $ | 10,199 |  |
  (was, 2021-12-03, similarity 0.9806):
[0001571996-21-000063:note_history:33]
|  | October 29, 2021 |
|  | Fixed-term — Consumer and Commercial |  |  |  |  |  |  |
|  | Fiscal Year of Origination |
|  | 2022 |  | 2021 |  | 2020 |  | 2019 |  | 2018 |  | Years Prior |  | Revolving — DPA |  | Revolving — DBC |  | Total |
|  | (in millions) |
| Higher | $ | 2,441 |  |  | $ | 2,055 |  |  | $ | 1,108 |  |  | $ | 297 |  |  | $ | 45 |  |  | $ | 5 |  |  | $ | 135 |  |  | $ | 45 |  |  | $ | 6,131 |  |
| Mid | 765 |  |  | 863 |  |  | 426 |  |  | 126 |  |  | 24 |  |  | 1 |  |  | 163 |  |  | 55 |  |  | 2,423 |  |
| Lower | 486 |  |  | 515 |  |  | 267 |  |  | 60 |  |  | 10 |  |  | 1 |  |  | 231 |  |  | 76 |  |  | 1,646 |  |
| Total | $ | 3,692 |  |  | $ | 3,433 |  |  | $ | 1,801 |  |  | $ | 483 |  |  | $ | 79 |  |  | $ | 7 |  |  | $ | 529 |  |  | $ | 176 |  |  | $ | 10,200 |  |

- changed (2022-06-06):
[0001571996-22-000021:note_history:34]
|  | January 28, 2022 |
|  | Fixed-term — Consumer and Commercial |  |  |  |  |  |  |
|  | Fiscal Year of Origination |  |  |  |  |  |  |
|  | 2022 |  | 2021 |  | 2020 |  | 2019 |  | 2018 |  | Years Prior |  | Revolving — DPA |  | Revolving — DBC |  | Total |
|  | (in millions) |
| Higher | $ | 3,279 |  |  | $ | 1,824 |  |  | $ | 914 |  |  | $ | 221 |  |  | $ | 25 |  |  | $ | 3 |  |  | $ | 150 |  |  | $ | 46 |  |  | $ | 6,462 |  |
| Mid | 1,071 |  |  | 751 |  |  | 329 |  |  | 94 |  |  | 17 |  |  | — |  |  | 166 |  |  | 57 |  |  | 2,485 |  |
| Lower | 599 |  |  | 450 |  |  | 208 |  |  | 42 |  |  | 6 |  |  | — |  |  | 255 |  |  | 76 |  |  | 1,636 |  |
| Total | $ | 4,949 |  |  | $ | 3,025 |  |  | $ | 1,451 |  |  | $ | 357 |  |  | $ | 48 |  |  | $ | 3 |  |  | $ | 571 |  |  | $ | 179 |  |  | $ | 10,583 |  |
  (was, 2021-12-03, similarity 0.9226):
[0001571996-21-000063:note_history:34]
|  | January 29, 2021 |
|  | Fixed-term — Consumer and Commercial |  |  |  |  |  |  |
|  | Fiscal Year of Origination |
|  | 2021 |  | 2020 |  | 2019 |  | 2018 |  | 2017 |  | Years Prior |  | Revolving — DPA |  | Revolving — DBC |  | Total |
|  | (in millions) |
| Higher | $ | 3,125 |  |  | $ | 1,802 |  |  | $ | 661 |  |  | $ | 166 |  |  | $ | 26 |  |  | $ | — |  |  | $ | 172 |  |  | $ | 47 |  |  | $ | 5,999 |  |
| Mid | 1,121 |  |  | 671 |  |  | 287 |  |  | 73 |  |  | 9 |  |  | — |  |  | 188 |  |  | 52 |  |  | 2,401 |  |
| Lower | 865 |  |  | 499 |  |  | 243 |  |  | 38 |  |  | 9 |  |  | — |  |  | 261 |  |  | 76 |  |  | 1,991 |  |
| Total | $ | 5,111 |  |  | $ | 2,972 |  |  | $ | 1,191 |  |  | $ | 277 |  |  | $ | 44 |  |  | $ | — |  |  | $ | 621 |  |  | $ | 175 |  |  | $ | 10,391 |  |

- changed (2022-06-06):
[0001571996-22-000021:note_history:35]
|  | Three Months Ended |
|  | April 29, 2022 |  | April 30, 2021 |
|  | (in millions) |
| Net revenue — products | $ | 220 |  |  | $ | 230 |  |
| Cost of net revenue — products | 204 |  |  | 163 |  |
| Gross margin — products | $ | 16 |  |  | $ | 67 |  |
  (was, 2021-12-03, similarity 0.7102):
[0001571996-21-000063:note_history:35]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 29, 2021 |  | October 30, 2020 |  | October 29, 2021 |  | October 30, 2020 |
|  | (in millions) |
| Net revenue — products | $ | 183 |  |  | $ | 184 |  |  | $ | 607 |  |  | $ | 648 |  |
| Cost of net revenue — products | 162 |  |  | 102 |  |  | 467 |  |  | 435 |  |
| Gross margin — products | $ | 21 |  |  | $ | 82 |  |  | $ | 140 |  |  | $ | 213 |  |

- changed (2022-06-06):
[0001571996-22-000021:note_history:36]
|  | April 29, 2022 |
|  | (in millions) |
| Fiscal 2023 (remaining nine months) | $ | 1,876 |  |
| Fiscal 2024 | 1,721 |  |
| Fiscal 2025 | 1,050 |  |
| Fiscal 2026 | 474 |  |
| Fiscal 2027 and beyond | 144 |  |
| Total undiscounted cash flows | 5,265 |  |
| Fixed-term loans | 4,814 |  |
| Revolving loans | 716 |  |
| Less: Unearned income | (596) |  |
| Total customer receivables, gross | $ | 10,199 |  |
  (was, 2021-12-03, similarity 0.958):
[0001571996-21-000063:note_history:36]
|  | October 29, 2021 |
|  | (in millions) |
| Fiscal 2022 (remaining three months) | $ | 775 |  |
| Fiscal 2023 | 2,207 |  |
| Fiscal 2024 | 1,445 |  |
| Fiscal 2025 | 735 |  |
| Fiscal 2026 and beyond | 335 |  |
| Total undiscounted cash flows | 5,497 |  |
| Fixed-term loans | 4,620 |  |
| Revolving loans | 705 |  |
| Less: unearned income | (622) |  |
| Total customer receivables, gross | $ | 10,200 |  |

- changed (2022-06-06):
[0001571996-22-000021:note_history:37]
|  | April 29, 2022 |  | January 28, 2022 |
|  | (in millions) |
| Equipment under operating lease, gross | $ | 2,942 |  |  | $ | 2,643 |  |
| Less: Accumulated depreciation | (1,076) |  |  | (935) |  |
| Equipment under operating lease, net | $ | 1,866 |  |  | $ | 1,708 |  |
  (was, 2021-12-03, similarity 0.9742):
[0001571996-21-000063:note_history:37]
|  | October 29, 2021 |  | January 29, 2021 |
|  | (in millions) |
| Equipment under operating lease, gross | $ | 2,367 |  |  | $ | 1,746 |  |
| Less: accumulated depreciation | (787) |  |  | (432) |  |
| Equipment under operating lease, net | $ | 1,580 |  |  | $ | 1,314 |  |

- added (2022-06-06):
[0001571996-22-000021:note_history:38]
|  | Three Months Ended |
|  | April 29, 2022 |  | April 30, 2021 |
|  | (in millions) |
| Income related to lease payments | $232 |  | $156 |
| Depreciation expense | $165 |  | $116 |

- changed (2022-06-06):
[0001571996-22-000021:note_history:39]
|  | April 29, 2022 |
|  | (in millions) |
| Fiscal 2023 (remaining nine months) | $ | 663 |  |
| Fiscal 2024 | 650 |  |
| Fiscal 2025 | 397 |  |
| Fiscal 2026 | 122 |  |
| Fiscal 2027 and beyond | 32 |  |
| Total | $ | 1,864 |  |
  (was, 2021-12-03, similarity 0.9554):
[0001571996-21-000063:note_history:39]
|  | October 29, 2021 |
|  | (in millions) |
| Fiscal 2022 (remaining three months) | $ | 220 |  |
| Fiscal 2023 | 702 |  |
| Fiscal 2024 | 437 |  |
| Fiscal 2025 | 189 |  |
| Fiscal 2026 and beyond | 21 |  |
| Total | $ | 1,569 |  |

- changed (2022-06-06):
[0001571996-22-000021:note_history:40]
The Company maintains programs that facilitate the funding of leases, loans, and other alternative payment structures in the capital markets.  The majority of DFS debt is non-recourse to Dell Technologies and represents borrowings under securitization programs and structured financing programs, for which the Company’s risk of loss is limited to transferred loan and lease payments and associated equipment.
  (was, 2021-12-03, similarity 0.7895):
[0001571996-21-000063:note_history:40]
The Company maintains programs that facilitate the funding of leases, loans, and other alternative payment structures in the capital markets.  The majority of DFS debt is non-recourse to Dell Technologies and represents borrowings under securitization programs and structured financing programs, for which the Company’s risk of loss is limited to transferred loan and lease payments and associated equipment.  The following table presents DFS debt as of the dates indicated.  The table excludes the allocated portion of the Company’s other borrowings, which represents the additional amount considered to fund the DFS business.

- added (2022-06-06):
[0001571996-22-000021:note_history:41]
The following table presents DFS debt as of the dates indicated and excludes the allocated portion of the Company’s other borrowings, which represents the additional amount considered to fund the DFS business:

- changed (2022-06-06):
[0001571996-22-000021:note_history:42]
|  | April 29, 2022 |  | January 28, 2022 |
| DFS debt | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing and securitization facilities | $ | 2,720 |  |  | $ | 3,054 |  |
| Fixed-term securitization offerings | 3,607 |  |  | 3,011 |  |
| Other | 125 |  |  | 135 |  |
| Total DFS U.S. debt | 6,452 |  |  | 6,200 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 730 |  |  | 739 |  |
| Other borrowings | 818 |  |  | 785 |  |
| Note payable | 250 |  |  | 250 |  |
| Dell Bank senior unsecured eurobonds | 1,575 |  |  | 1,672 |  |
| Total DFS international debt | 3,373 |  |  | 3,446 |  |
| Total DFS debt | $ | 9,825 |  |  | $ | 9,646 |  |
| Total short-term DFS debt | $ | 5,907 |  |  | $ | 5,803 |  |
| Total long-term DFS debt | $ | 3,918 |  |  | $ | 3,843 |  |
  (was, 2021-12-03, similarity 0.9842):
[0001571996-21-000063:note_history:42]
|  | October 29, 2021 |  | January 29, 2021 |
|  | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing and securitization facilities | $ | 2,650 |  |  | $ | 3,311 |  |
| Fixed-term securitization offerings | 3,618 |  |  | 2,961 |  |
| Other | 147 |  |  | 140 |  |
| Total DFS U.S. debt | 6,415 |  |  | 6,412 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 751 |  |  | 786 |  |
| Other borrowings | 809 |  |  | 1,006 |  |
| Note payable | 250 |  |  | 250 |  |
| Dell Bank Senior Unsecured Eurobonds | 1,752 |  |  | 1,212 |  |
| Total DFS international debt | 3,562 |  |  | 3,254 |  |
| Total DFS debt | $ | 9,977 |  |  | $ | 9,666 |  |
| Total short-term DFS debt | $ | 5,475 |  |  | $ | 4,888 |  |
| Total long-term DFS debt | $ | 4,502 |  |  | $ | 4,778 |  |

- changed (2022-06-06):
[0001571996-22-000021:note_history:43]
Asset-Based Financing and Securitization Facilities — The Company maintains separate asset-based financing facilities and a securitization facility in the United States, which are revolving facilities for fixed-term leases and loans and for revolving loans, respectively.  This debt is collateralized solely by the U.S. loan and lease payments and associated equipment in the facilities.  The debt has a variable interest rate and the duration of the debt is based on the terms of the underlying loan and lease payment streams.  As of April 29, 2022, the total debt capacity related to the U.S. asset-based financing and securitization facilities was $4.5 billion.  The Company enters into interest swap agreements to effectively convert a portion of this debt from a floating rate to a fixed rate.  See Note 8 of the Notes to the Condensed Consolidated Financial Statements for additional information about interest rate swaps.
  (was, 2021-12-03, similarity 0.9793):
[0001571996-21-000063:note_history:43]
Asset-Based Financing and Securitization Facilities — The Company maintains separate asset-based financing facilities and a securitization facility in the United States, which are revolving facilities for fixed-term leases and loans and for revolving loans, respectively.  This debt is collateralized solely by the U.S. lease and loan payments and associated equipment in the facilities.  The debt has a variable interest rate and the duration of the debt is based on the terms of the underlying loan and lease payment streams.  As of October 29, 2021, the total debt capacity related to the U.S. asset-based financing and securitization facilities was $4.5 billion.  The Company enters into interest swap agreements to effectively convert a portion of this debt from a floating rate to a fixed rate.  See Note 6 of the Notes to the Condensed Consolidated Financial Statements for additional information about interest rate swaps.

- changed (2022-06-06):
[0001571996-22-000021:note_history:44]
The asset-based financing and securitization facilities contain standard structural features related to the performance of the funded receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the facility, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of April 29, 2022, these criteria were met.
  (was, 2021-12-03, similarity 0.9893):
[0001571996-21-000063:note_history:44]
The asset-based financing and securitization facilities contain standard structural features related to the performance of the funded receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the facility, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of October 29, 2021, these criteria were met.

- changed (2022-06-06):
[0001571996-22-000021:note_history:45]
Fixed-Term Securitization Offerings — The Company periodically issues asset-backed debt securities under fixed-term securitization programs to private investors.  The asset-backed debt securities are collateralized solely by the U.S. fixed-term leases and loans in the offerings, which are held by Special Purpose Entities (“SPEs”), as discussed below.  The interest rate on these securities is fixed and ranges from 0.18% to 5.92% per annum, and the duration of these securities is based on the terms of the underlying lease and loan payment streams.
  (was, 2021-12-03, similarity 0.9761):
[0001571996-21-000063:note_history:45]
Fixed-Term Securitization Offerings — The Company periodically issues asset-backed debt securities under fixed-term securitization programs to private investors.  The asset-backed debt securities are collateralized solely by the U.S. fixed-term leases and loans in the offerings, which are held by Special Purpose Entities (“SPEs”), as discussed below.  The interest rate on these securities is fixed and ranges from 0.18% to 5.92% per annum, and the duration of these securities is based on the terms of the underlying loan and lease payment streams.

- changed (2022-06-06):
[0001571996-22-000021:note_history:46]
Securitization Facility — The Company maintains a securitization facility in Europe for fixed-term leases and loans.  This facility is effective through December 21, 2022 and had a total debt capacity of $840 million as of April 29, 2022.
  (was, 2021-12-03, similarity 0.9556):
[0001571996-21-000063:note_history:46]
Securitization Facility — The Company maintains a securitization facility in Europe for fixed-term leases and loans.  This facility is effective through December 21, 2022 and had a total debt capacity of $934 million as of October 29, 2021.

- changed (2022-06-06):
[0001571996-22-000021:note_history:47]
The securitization facility contains standard structural features related to the performance of the securitized receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the program, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of April 29, 2022, these criteria were met.
  (was, 2021-12-03, similarity 0.9888):
[0001571996-21-000063:note_history:47]
The securitization facility contains standard structural features related to the performance of the securitized receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the program, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of October 29, 2021, these criteria were met.

- changed (2022-06-06):
[0001571996-22-000021:note_history:48]
Other Borrowings — In connection with the Company’s international financing operations, the Company has entered into revolving structured financing debt programs related to its fixed-term lease and loan products sold in Canada, Europe, Australia, and New Zealand.  The Canadian facility, which is collateralized solely by Canadian loan and lease payments and associated equipment, had a total debt capacity of $351 million as of April 29, 2022 and is effective through January 16, 2025.  The European facility, which is collateralized solely by European loan and lease payments and associated equipment, had a total debt capacity of $630 million as of April 29, 2022 and is effective through December 14, 2023.  The Australia and New Zealand facility, which is collateralized solely by Australia and New Zealand loan and lease payments and associated equipment, had a total debt capacity of $319 million as of April 29, 2022 and is effective through April 20, 2023.
  (was, 2021-12-03, similarity 0.9572):
[0001571996-21-000063:note_history:48]
Other Borrowings — In connection with the Company’s international financing operations, the Company enters into revolving structured financing debt programs related to its fixed-term lease and loan products sold in Canada, Europe, Australia, and New Zealand.  The Canadian facility, which is collateralized solely by Canadian lease and loan payments and associated equipment, had a total debt capacity of $364 million as of October 29, 2021, and is effective through January 16, 2025.  The European facility, which is collateralized solely by European loan and lease payments and associated equipment, had a total debt capacity of $701 million as of October 29, 2021, and is effective through December 14, 2023.  The Australia and New Zealand facility, which is collateralized solely by Australia and New Zealand loan and lease payments and associated equipment, had a total debt capacity of $339 million as of October 29, 2021, and is effective through April 20, 2023.

- changed (2022-06-06):
[0001571996-22-000021:note_history:49]
Note Payable —On August 7, 2020, the Company entered into two unsecured credit agreements to fund receivables in Mexico.  As of April 29, 2022, the aggregate principal amount of the notes payable was $250 million.  The notes bear interest at an annual rate of 3.37% and will mature on June 1, 2022.
  (was, 2021-12-03, similarity 0.9695):
[0001571996-21-000063:note_history:49]
Note Payable — On August 7, 2020, the Company entered into two new unsecured credit agreements to fund receivables in Mexico.  As of October 29, 2021, the aggregate principal amount of the notes payable was $250 million.  The notes bear interest at an annual rate of 3.37% and will mature on June 1, 2022.

- changed (2022-06-06):
[0001571996-22-000021:note_history:50]
Dell Bank Senior Unsecured Eurobonds  — On October 17, 2019, Dell Bank International D.A.C. (“Dell Bank”) issued 500 million Euro of 0.625% senior unsecured three year eurobonds due October 2022.  On June 24, 2020, Dell Bank issued 500 million Euro of 1.625% senior unsecured four year eurobonds due June 2024.  On October 27, 2021, Dell Bank issued 500 million Euro of 0.5% senior unsecured five year eurobonds due October 2026.  The issuance of the senior unsecured eurobonds support the expansion of the financing operations in Europe.
  (was, 2021-12-03, similarity 0.6402):
[0001571996-21-000063:note_history:50]
Dell Bank Senior Unsecured Eurobonds — On October 17, 2019, Dell Bank International D.A.C., a wholly-owned subsidiary of Dell Technologies Inc., issued 500 million Euro of 0.625% senior unsecured three year eurobonds due October 2022.  On June 24, 2020, Dell Bank International D.A.C. issued 500 million Euro of 1.625% senior unsecured four year eurobonds due June 2024.  On October 27, 2021, Dell Bank International D.A.C. issued 500 million Euro of 0.5% senior unsecured five year eurobonds due October 2026.  The issuances of the senior unsecured eurobonds support the expansion of the financing operations in Europe.

- changed (2022-06-06):
[0001571996-22-000021:note_history:51]
In connection with the asset-based financing facilities, securitization facilities, and fixed-term securitization offerings discussed above, the Company transfers certain U.S. and European lease and loan payments and associated equipment to SPEs that meet the definition of a Variable Interest Entity (“VIE”) and are consolidated, along with the associated debt detailed above, into the Condensed Consolidated Financial Statements, as the Company is the primary beneficiary of the VIEs.  The SPEs are bankruptcy-remote legal entities with separate assets and liabilities.  The purpose of the SPEs is to facilitate the funding of customer loan and lease payments and associated equipment in the capital markets.
  (was, 2021-12-03, similarity 0.9803):
[0001571996-21-000063:note_history:51]
In connection with the asset-based financing facilities, securitization facilities, and fixed-term securitization offerings discussed above, the Company transfers certain U.S. and European loan and lease payments and associated equipment to SPEs that meet the definition of a Variable Interest Entity (“VIE”) and are consolidated, along with the associated debt detailed above, into the Condensed Consolidated Financial Statements, as the Company is the primary beneficiary of those VIEs.  The SPEs are bankruptcy-remote legal entities with separate assets and liabilities.  The purpose of the SPEs is to facilitate the funding of customer loan and lease payments and associated equipment in the capital markets.

- changed (2022-06-06):
[0001571996-22-000021:note_history:52]
Some of the SPEs have entered into financing arrangements with multi-seller conduits that, in turn, issue asset-backed debt securities in the capital markets.  DFS debt outstanding held by the consolidated VIEs is collateralized by the lease and loan payments and associated equipment.  The Company’s risk of loss related to securitized receivables is limited to the amount by which the Company’s right to receive collections for assets securitized exceeds the amount required to pay interest, principal, and fees and expenses related to the asset-backed securities.  The Company provides credit enhancement to the securitization in the form of over-collateralization.
  (was, 2021-12-03, similarity 0.9805):
[0001571996-21-000063:note_history:52]
Some of the SPEs have entered into financing arrangements with multi-seller conduits that, in turn, issue asset-backed debt securities in the capital markets.  DFS debt outstanding held by the consolidated VIEs is collateralized by the loan and lease payments and associated equipment.  The Company’s risk of loss related to securitized receivables is limited to the amount by which the Company’s right to receive collections for assets securitized exceeds the amount required to pay interest, principal, and fees and expenses related to the asset-backed securities.  The Company provides credit enhancement to the securitization in the form of over-collateralization.

- added (2022-06-06):
[0001571996-22-000021:note_history:53]
The following table presents the assets and liabilities held by the consolidated VIEs as of the dates indicated, which are included in the Condensed Consolidated Statements of Financial Position:

- changed (2022-06-06):
[0001571996-22-000021:note_history:54]
|  | April 29, 2022 |  | January 28, 2022 |
|  | (in millions) |
| Assets held by consolidated VIEs |  |  |  |
| Other current assets | $ | 547 |  |  | $ | 535 |  |
| Financing receivables, net of allowance |  |  |  |
| Short-term | $ | 3,376 |  |  | $ | 3,368 |  |
| Long-term | $ | 3,270 |  |  | $ | 3,141 |  |
| Property, plant, and equipment, net | $ | 1,030 |  |  | $ | 945 |  |
| Liabilities held by consolidated VIEs |  |  |  |
| Debt, net of unamortized debt issuance costs |  |  |  |
| Short-term | $ | 4,545 |  |  | $ | 4,560 |  |
| Long-term | $ | 2,500 |  |  | $ | 2,235 |  |
  (was, 2021-12-03, similarity 0.9881):
[0001571996-21-000063:note_history:54]
|  | October 29, 2021 |  | January 29, 2021 |
|  | (in millions) |
| Assets held by consolidated VIEs |  |  |  |
| Other current assets | $ | 843 |  |  | $ | 838 |  |
| Financing receivables, net of allowance |  |  |  |
| Short-term | $ | 3,467 |  |  | $ | 3,534 |  |
| Long-term | $ | 3,294 |  |  | $ | 3,314 |  |
| Property, plant, and equipment, net | $ | 874 |  |  | $ | 792 |  |
| Liabilities held by consolidated VIEs |  |  |  |
| Debt, net of unamortized debt issuance costs |  |  |  |
| Short-term | $ | 4,180 |  |  | $ | 4,208 |  |
| Long-term | $ | 2,826 |  |  | $ | 2,841 |  |

- changed (2022-06-06):
[0001571996-22-000021:note_history:55]
Lease and loan payments and associated equipment transferred via securitization through SPEs were $1.7 billion and $1.4 billion for the three months ended April 29, 2022 and April 30, 2021, respectively.
  (was, 2021-12-03, similarity 0.6527):
[0001571996-21-000063:note_history:55]
Loan and lease payments and associated equipment transferred via securitization through SPEs were $1.4 billion and $1.6 billion for the three months ended October 29, 2021 and October 30, 2020, respectively, and $4.1 billion and $4.6 billion for the nine months ended October 29, 2021 and October 30, 2020, respectively.

- added (2022-06-06):
[0001571996-22-000021:note_history:56]
Customer Receivable Sales

- changed (2022-06-06):
[0001571996-22-000021:note_history:57]
To manage certain concentrations of customer credit exposure, the Company may sell selected fixed-term customer receivables to unrelated third parties on a periodic basis, without recourse.  The amount of customer receivables sold for this purpose was $148 million and $101 million for the three months ended April 29, 2022 and April 30, 2021, respectively.  The Company’s continuing involvement in these customer receivables is primarily limited to servicing arrangements.
  (was, 2021-12-03, similarity 0.7462):
[0001571996-21-000063:note_history:57]
Customer Receivables Sales
To manage certain concentrations of customer credit exposure, the Company may sell selected fixed-term customer receivables to unrelated third parties on a periodic basis, without recourse.  The amount of customer receivables sold for this purpose was $180 million and $414 million for the nine months ended October 29, 2021 and October 30, 2020, respectively.  The Company’s continuing involvement in such customer receivables is primarily limited to servicing arrangements.  The transactions are accounted for as sales and, accordingly, the customer receivables are derecognized from the Condensed Consolidated Statements of Financial Position at the time of sale.

- removed (2022-06-06):
[0001571996-21-000063:note_history:58]
NOTE 3 — FINANCIAL SERVICES

- removed (2022-06-06):
[0001571996-21-000063:note_history:59]
|  | Three Months Ended |
|  | October 29, 2021 |  | October 30, 2020 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |  |  |  |  |  |  |  |  |  |  |  |
| Balances at beginning of period | $ | 126 |  |  | $ | 161 |  |  | $ | 287 |  |  | $ | 143 |  |  | $ | 180 |  |  | $ | 323 |  |
| Charge-offs, net of recoveries | (9) |  |  | (20) |  |  | (29) |  |  | (13) |  |  | (6) |  |  | (19) |  |
| Provision charged to income statement | (5) |  |  | (28) |  |  | (33) |  |  | 12 |  |  | (9) |  |  | 3 |  |
| Balances at end of period | $ | 112 |  |  | $ | 113 |  |  | $ | 225 |  |  | $ | 142 |  |  | $ | 165 |  |  | $ | 307 |  |

- removed (2022-06-06):
[0001571996-21-000063:note_history:60]
|  | Nine Months Ended |
|  | October 29, 2021 |  | October 30, 2020 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |  |  |  |  |  |  |  |  |  |  |  |
| Balances at beginning of period | $ | 148 |  |  | $ | 173 |  |  | $ | 321 |  |  | $ | 70 |  |  | $ | 79 |  |  | $ | 149 |  |
| Adjustment for adoption of accounting standard | — |  |  | — |  |  | — |  |  | 40 |  |  | 71 |  |  | 111 |  |
| Charge-offs, net of recoveries | (32) |  |  | (25) |  |  | (57) |  |  | (51) |  |  | (22) |  |  | (73) |  |
| Provision charged to income statement | (4) |  |  | (35) |  |  | (39) |  |  | 83 |  |  | 37 |  |  | 120 |  |
| Balances at end of period | $ | 112 |  |  | $ | 113 |  |  | $ | 225 |  |  | $ | 142 |  |  | $ | 165 |  |  | $ | 307 |  |

- removed (2022-06-06):
[0001571996-21-000063:note_history:61]
Interest income on sales-type lease receivables was $59 million and $69 million for the three months ended October 29, 2021 and October 30, 2020, respectively, and $186 million and $200 million for the nine months ended October 29, 2021, and October 30, 2020, respectively.

- removed (2022-06-06):
[0001571996-21-000063:note_history:62]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 29, 2021 |  | October 30, 2020 |  | October 29, 2021 |  | October 30, 2020 |
|  | (in millions) |
| Income related to lease payments | $187 |  | $120 |  | $510 |  | $310 |
| Depreciation expense | $140 |  | $92 |  | $383 |  | $228 |

- removed (2022-06-06):
[0001571996-21-000063:note_history:63]
The following table presents financing receivables and equipment under operating leases, net held by the consolidated VIEs as of the dates indicated:


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-06-06):
[0001571996-22-000021:note_history:64]
DEBT
The following table summarizes the Company’s outstanding debt as of the dates indicated:
  (was, 2021-12-03, similarity 0.905):
[0001571996-21-000063:note_history:64]
The following table presents the Company’s outstanding debt as of the dates indicated:

- added (2022-06-06):
[0001571996-22-000021:note_history:65]
|  | April 29, 2022 |  | January 28, 2022 |
|  | (in millions) |
| Senior Notes: |  |  |  |
| 5.45% due June 2023 | 1,000 |  |  | 1,000 |  |
| 4.00% due July 2024 | 1,000 |  |  | 1,000 |  |
| 5.85% due July 2025 | 1,000 |  |  | 1,000 |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 4.90% due October 2026 | 1,750 |  |  | 1,750 |  |
| 6.10% due July 2027 | 500 |  |  | 500 |  |
| 5.30% due October 2029 | 1,750 |  |  | 1,750 |  |
| 6.20% due July 2030 | 750 |  |  | 750 |  |
| 8.10% due July 2036 | 1,000 |  |  | 1,000 |  |
| 3.38% due December 2041 | 1,000 |  |  | 1,000 |  |
| 8.35% due July 2046 | 800 |  |  | 800 |  |
| 3.45% due December 2051 | 1,250 |  |  | 1,250 |  |
| Legacy Notes and Debentures: |  |  |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| DFS Debt (Note 5) | 9,825 |  |  | 9,646 |  |
| Other | 320 |  |  | 337 |  |
| Total debt, principal amount | $ | 27,397 |  |  | $ | 27,235 |  |
| Unamortized discount, net of unamortized premium | (131) |  |  | (134) |  |
| Debt issuance costs | (144) |  |  | (147) |  |
| Total debt, carrying value | $ | 27,122 |  |  | $ | 26,954 |  |
| Total short-term debt, carrying value | $ | 5,925 |  |  | $ | 5,823 |  |
| Total long-term debt, carrying value | $ | 21,197 |  |  | $ | 21,131 |  |

- added (2022-06-06):
[0001571996-22-000021:note_history:66]
Outstanding Debt

- added (2022-06-06):
[0001571996-22-000021:note_history:67]
Senior Notes — The Company completed private offerings of multiple series of senior notes which were issued on June 1, 2016, June 22, 2016, March 20, 2019, April 9, 2020, and December 13, 2021 in aggregate principal amounts of $20.0 billion, $3.3 billion, $4.5 billion, $2.3 billion, and $2.3 billion respectively (the “Senior Notes”).  Interest on these borrowings is payable semiannually.

- added (2022-06-06):
[0001571996-22-000021:note_history:68]
In June 2021, Dell International L.L.C. and EMC Corporation, wholly-owned subsidiaries of Dell Technologies and issuers of the Senior Notes (the “Issuers”), completed offers to exchange any and all outstanding Senior Notes issued on June 1, 2016, March 20, 2019, and April 9, 2020 for senior notes registered under the Securities Act of 1933 having terms substantially identical to the terms of the outstanding Senior Notes.  The Issuers issued $18.4 billion aggregate principal amount of registered senior notes in exchange for the same aggregate principal amount of Senior Notes.  The aggregate principal amount of unregistered Senior Notes remaining outstanding following the settlement of the exchange offers was approximately $0.1 billion.

- changed (2022-06-06):
[0001571996-22-000021:note_history:69]
Legacy Notes and Debentures — The Company has outstanding unsecured notes and debentures (collectively, the “Legacy Notes and Debentures”) that were issued by Dell prior to the acquisition of Dell Inc. by Dell Technologies Inc. in the going-private transaction that closed in October 2013.  Interest on these borrowings is payable semiannually.
  (was, 2021-12-03, similarity 0.9255):
[0001571996-21-000063:note_history:69]
Unsecured Notes and Debentures — The Company has outstanding unsecured notes and debentures (collectively, the “Unsecured Notes and Debentures”) that were issued by Dell prior to the acquisition of Dell by Dell Technologies Inc. in the going-private transaction that closed in October 2013.  Interest on outstanding borrowings is payable semiannually.

- changed (2022-06-06):
[0001571996-22-000021:note_history:70]
DFS Debt — See Note 5 and Note 8 of the Notes to the Condensed Consolidated Financial Statements, respectively, for discussion of DFS debt and the interest rate swap agreements that hedge a portion of that debt.
  (was, 2021-12-03, similarity 0.9732):
[0001571996-21-000063:note_history:70]
See Note 3 and Note 6 of the Notes to the Condensed Consolidated Financial Statements, respectively, for discussion of DFS debt and the interest rate swap agreements that hedge a portion of that debt.

- added (2022-06-06):
[0001571996-22-000021:note_history:71]
2021 Revolving Credit Facility  — The 2021 Revolving Credit Facility, which was entered into on November 1, 2021, matures on November 1, 2026, This facility provides the Company with revolving commitments in an aggregate principal amount of $5.0 billion for general corporate purposes and includes a letter of credit sub-facility of up to $0.5 billion and a swing-line loan sub-facility of up to $0.5 billion.  The 2021 Revolving Credit Facility also allows the Company to obtain incremental additional commitments on one or more occasions in minimum amounts of $10 million.

- added (2022-06-06):
[0001571996-22-000021:note_history:72]
The Company may conduct borrowings under the 2021 Revolving Credit Facility through London Interbank Offered Rate (“LIBOR”) borrowings or Base Rate Loan borrowings.  LIBOR borrowings bear interest at a rate per annum equal to the LIBOR, plus an applicable rate that varies based upon the Company’s existing debt ratings (the “applicable rate”).  Base Rate Loan borrowings bear interest at a rate per annum equal to the base rate plus the applicable rate.  The base rate is calculated based upon the greatest of the specified prime rate, the specified federal reserve bank rate, or LIBOR plus 1%.

- changed (2022-06-06):
[0001571996-22-000021:note_history:73]
The borrowers may voluntarily repay outstanding loans under the 2021 Revolving Credit Facility at any time without premium or penalty, other than customary breakage costs.
  (was, 2021-12-03, similarity 0.9151):
[0001571996-21-000063:note_history:73]
The borrowers may voluntarily repay outstanding loans under the term loan facilities and the Revolving Credit Facility at any time without premium or penalty, other than customary “breakage” costs.

- added (2022-06-06):
[0001571996-22-000021:note_history:74]
As of April 29, 2022, available borrowings under the 2021 Revolving Credit Facility totaled $5.0 billion.

- added (2022-06-06):
[0001571996-22-000021:note_history:75]
Covenants — The credit agreement governing the 2021 Revolving Credit Facility and the indentures governing the Senior Notes and the Legacy Notes and Debentures variously impose limitations, subject to exceptions, on creating certain liens and entering into sale and lease-back transactions.  The foregoing credit agreement and indentures contain customary events of default, including failure to make required payments, failure to comply with covenants, and the occurrence of certain events of bankruptcy and insolvency.  The 2021 Revolving Credit Facility is also subject to an interest coverage ratio covenant that is tested at the end of each fiscal quarter with respect to the Company’s preceding four fiscal quarters.  The Company was in compliance with this financial covenant as of April 29, 2022.

- changed (2022-06-06):
[0001571996-22-000021:note_history:76]
The following tables presents the aggregate future maturities of the Company’s debt as of April 29, 2022 for the periods indicated:
  (was, 2021-12-03, similarity 0.9565):
[0001571996-21-000063:note_history:76]
The following table presents the aggregate future maturities of the Company’s debt as of October 29, 2021 for the periods indicated:

- added (2022-06-06):
[0001571996-22-000021:note_history:77]
|  | Maturities by Fiscal Year |
|  | 2023 (remaining nine months) |  | 2024 |  | 2025 |  | 2026 |  | 2027 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Notes | $ | — |  |  | $ | 1,000 |  |  | $ | 1,000 |  |  | $ | 1,000 |  |  | $ | 6,250 |  |  | $ | 7,050 |  |  | $ | 16,300 |  |
| Legacy Notes and Debentures | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 952 |  |  | 952 |  |
| DFS Debt | 5,201 |  |  | 2,612 |  |  | 1,294 |  |  | 165 |  |  | 550 |  |  | 3 |  |  | 9,825 |  |
| Other | 23 |  |  | 165 |  |  | 109 |  |  | 20 |  |  | 1 |  |  | 2 |  |  | 320 |  |
| Total maturities, principal amount | 5,224 |  |  | 3,777 |  |  | 2,403 |  |  | 1,185 |  |  | 6,801 |  |  | 8,007 |  |  | 27,397 |  |
| Associated carrying value adjustments | (5) |  |  | (6) |  |  | (9) |  |  | (8) |  |  | (56) |  |  | (191) |  |  | (275) |  |
| Total maturities, carrying value amount | $ | 5,219 |  |  | $ | 3,771 |  |  | $ | 2,394 |  |  | $ | 1,177 |  |  | $ | 6,745 |  |  | $ | 7,816 |  |  | $ | 27,122 |  |

- removed (2022-06-06):
[0001571996-21-000063:note_history:78]
NOTE 5 — DEBT

- removed (2022-06-06):
[0001571996-21-000063:note_history:79]
|  | October 29, 2021 |  | January 29, 2021 |
|  | (in millions) |
| Secured Debt |  |  |  |
| Senior Secured Credit Facilities: |  |  |  |
| 2.00% Term Loan B-2 Facility due September 2025 (a) | $ | 3,120 |  |  | $ | 3,143 |  |
| 1.84% Term Loan A-6 Facility due March 2024 (a) | 3,134 |  |  | 3,134 |  |
| First Lien Notes: |  |  |  |
| 5.45% due June 2023 (a) | 3,750 |  |  | 3,750 |  |
| 4.00% due July 2024 | 1,000 |  |  | 1,000 |  |
| 5.85% due July 2025 | 1,000 |  |  | 1,000 |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 4.90% due October 2026 | 1,750 |  |  | 1,750 |  |
| 6.10% due July 2027 | 500 |  |  | 500 |  |
| 5.30% due October 2029 | 1,750 |  |  | 1,750 |  |
| 6.20% due July 2030 | 750 |  |  | 750 |  |
| 8.10% due July 2036 | 1,500 |  |  | 1,500 |  |
| 8.35% due July 2046 | 2,000 |  |  | 2,000 |  |
| Unsecured Debt |  |  |  |
| Unsecured Notes and Debentures: |  |  |  |
| 4.625% due April 2021 | — |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| Senior Notes: |  |  |  |
| 5.875% due June 2021 | — |  |  | 1,075 |  |
| 7.125% due June 2024 (a) | 1,625 |  |  | 1,625 |  |
| EMC Notes: |  |  |  |
| 3.375% due June 2023 | — |  |  | 1,000 |  |
| VMware Notes: |  |  |  |
| 2.95% due August 2022 | 1,500 |  |  | 1,500 |  |
| 0.60% due August 2023 | 1,000 |  |  | — |  |
| 1.00% due August 2024 | 1,250 |  |  | — |  |
| 4.50% due May 2025 | 750 |  |  | 750 |  |
| 1.40% due August 2026 | 1,500 |  |  | — |  |
| 4.65% due May 2027 | 500 |  |  | 500 |  |
| 3.90% due August 2027 | 1,250 |  |  | 1,250 |  |
| 1.80% due August 2028 | 750 |  |  | — |  |
| 4.70% due May 2030 | 750 |  |  | 750 |  |
| 2.20% due August 2031 | 1,500 |  |  | — |  |
| DFS Debt (Note 3) | 9,977 |  |  | 9,666 |  |
| Other |  |  |  |
| 2.44% Margin Loan Facility due April 2022 | — |  |  | 4,000 |  |
| Other | 400 |  |  | 235 |  |
| Total debt, principal amount | $ | 48,458 |  |  | $ | 48,480 |  |

- removed (2022-06-06):
[0001571996-21-000063:note_history:80]
|  | October 29, 2021 |  | January 29, 2021 |
|  | (in millions) |
| Total debt, principal amount | $ | 48,458 |  |  | $ | 48,480 |  |
| Unamortized discount, net of unamortized premium | (175) |  |  | (194) |  |
| Debt issuance costs | (304) |  |  | (302) |  |
| Total debt, carrying value | $ | 47,979 |  |  | $ | 47,984 |  |
| Total short-term debt, carrying value (b) | $ | 16,280 |  |  | $ | 6,362 |  |
| Total long-term debt, carrying value | $ | 31,699 |  |  | $ | 41,622 |  |

- removed (2022-06-06):
[0001571996-21-000063:note_history:81]
____________________

- removed (2022-06-06):
[0001571996-21-000063:note_history:82]
(a)    Subsequent to October 29, 2021, the Company used the net proceeds from its $9.3 billion pro rata share of the cash dividend received in connection with the VMware Spin-off, as well as cash on hand, to repay $3.12 billion principal amount of the 2.00% Term Loan B-2 Facility due September 2025, $3.13 billion principal amount of the 1.84% Term Loan A-6 Facility due March 2024, $1.63 billion principal amount of the 7.125% Senior Notes due June 2024, and $1.50 billion principal amount of the 5.45% First Lien Notes due June 2023.

- removed (2022-06-06):
[0001571996-21-000063:note_history:83]
(b)    Given the probability of the close of the VMware Spin-off and the Company’s intent and ability to repay, the Company classified $9.4 billion principal amount of debt as short-term liabilities on the Condensed Consolidated Statements of Financial Position as of October 29, 2021.

- removed (2022-06-06):
[0001571996-21-000063:note_history:84]
During the nine months ended October 29, 2021, the net decrease in the Company’s debt balance was primarily due to:

- removed (2022-06-06):
[0001571996-21-000063:note_history:85]
•repayment of $1.0 billion principal amount of the 3.375% EMC Notes due June 2023;

- removed (2022-06-06):
[0001571996-21-000063:note_history:86]
•repayment of $4.0 billion principal amount of the 2.44% Margin Loan Facility due April 2022;

- removed (2022-06-06):
[0001571996-21-000063:note_history:87]
•repayment of $1.1 billion principal amount of the 5.875% Senior Notes due June 2021; and

- removed (2022-06-06):
[0001571996-21-000063:note_history:88]
•repayment of $0.4 billion principal amount of the 4.625% Unsecured Notes due April 2021.

- removed (2022-06-06):
[0001571996-21-000063:note_history:89]
See Note 18 of the Notes to the Condensed Consolidated Financial Statements for more information about debt repayments that occurred subsequent to October 29, 2021.

- removed (2022-06-06):
[0001571996-21-000063:note_history:90]
Secured Debt

- removed (2022-06-06):
[0001571996-21-000063:note_history:91]
Senior Secured Credit Facilities — The Company has entered into a credit agreement (the “Existing Credit Agreement”) that provides for senior secured credit facilities (the “Senior Secured Credit Facilities”) comprising (a) term loan facilities and (b) a senior secured Revolving Credit Facility, which provides for a borrowing capacity of up to $4.5 billion for general corporate purposes, including capacity for up to $0.5 billion of letters of credit and for borrowings of up to $0.4 billion under swing-line loans.  The Revolving Credit Facility expires December 20, 2023.

- removed (2022-06-06):
[0001571996-21-000063:note_history:92]
As of October 29, 2021, available borrowings under the Revolving Credit Facility totaled $4.5 billion.  The Senior Secured Credit Facilities provide that the borrowers have the right at any time, subject to customary conditions, to request incremental term loans or incremental revolving commitments.

- removed (2022-06-06):
[0001571996-21-000063:note_history:93]
On February 18, 2021, the Company entered into an eighth refinancing amendment to the credit agreement for the Senior Secured Credit Facilities to refinance the existing term B loans (the “Original Term B Loans”) with a new term loan B facility consisting of an aggregate principal amount of $3.1 billion refinancing term B-2 loans (the “Refinancing Term B-2 Loans”) maturing on September 19, 2025.  Proceeds from the Refinancing Term B-2 Loans, together with other funds available to the borrowers, were used to repay in full the Original Term B Loans and all accrued and unpaid fees in respect thereof.

- removed (2022-06-06):
[0001571996-21-000063:note_history:94]
Except for a change in the interest rate, the Refinancing Term B-2 Loans have substantially the same terms as the Original Term B Loans under the sixth refinancing amendment to the Senior Secured Credit Agreement.  Amortization payments on the Refinancing Term B-2 Loans are equal to 0.25% of the aggregate principal amount of Refinancing Term B-2 Loans outstanding on the effective date of the eighth refinancing amendment, payable at the end of each fiscal quarter, commencing with the fiscal quarter ended April 30, 2021.

- removed (2022-06-06):
[0001571996-21-000063:note_history:95]
Borrowings under the Senior Secured Credit Facilities bear interest at a rate per annum equal to an applicable margin, plus, at the borrowers’ option, either (a) a base rate, or (b) the London Interbank Offered Rate (“LIBOR”).  The Term Loan A-6 Facility

- removed (2022-06-06):
[0001571996-21-000063:note_history:96]
bears interest at LIBOR plus an applicable margin ranging from 1.25% to 2.00% or a base rate plus an applicable margin ranging from 0.25% to 1.00%.  The Refinancing Term B-2 Loans bear interest at LIBOR plus an applicable margin of 1.75% or a base rate plus an applicable margin of 0.75%.  Interest is payable, in the case of loans bearing interest based on LIBOR, at the end of each interest period (but at least every three months), in arrears and, in the case of loans bearing interest based on the base rate, quarterly in arrears.

- removed (2022-06-06):
[0001571996-21-000063:note_history:97]
The Term Loan A-6 Facility amortizes in equal quarterly installments in aggregate annual amounts equal to 5% of the original principal amount in each of the first four years after the facility closing date of March 13, 2019, and 80% of the original principal amount in the fifth year after March 13, 2019.  The Revolving Credit Facility has no amortization.

- removed (2022-06-06):
[0001571996-21-000063:note_history:98]
All obligations of the borrowers under the Senior Secured Credit Facilities and certain swap agreements, cash management arrangements, and certain letters of credit provided by any lender or agent party to the Senior Secured Credit Facilities or any of its affiliates and certain other persons are secured by (a) a first-priority security interest in certain tangible and intangible assets of the borrowers and the guarantors and (b) a first-priority pledge of 100% of the capital stock of the borrowers, Dell Inc., a wholly-owned subsidiary of the Company (“Dell”), and each wholly-owned material restricted subsidiary of the borrowers and the guarantors, in each case subject to certain thresholds, exceptions, and permitted liens.

- removed (2022-06-06):
[0001571996-21-000063:note_history:99]
Subsequent to October 29, 2021, the Company repaid the remaining $3.12 billion principal amount of the Term B-2 Loans and the remaining $3.13 billion principal amount of the Term Loan A-6 Facility.  On November 1, 2021, the Company entered into a new senior secured Revolving Credit Facility (the “2021 Revolving Credit Facility”) to replace the old senior secured Revolving Credit Facility under the Existing Credit Agreement.  Following the full redemption of the outstanding term loan facilities and placement of the Revolving Credit Facility, the Existing Credit Agreement was terminated.  See Note 18 of the Notes to the Condensed Consolidated Financial Statements for more information.

- removed (2022-06-06):
[0001571996-21-000063:note_history:100]
First Lien Notes — Dell International L.L.C. and EMC Corporation (collectively, the “Issuers”), both of which are wholly-owned subsidiaries of Dell Technologies Inc., completed offerings of multiple series of senior secured notes (collectively, the “First Lien Notes”) pursuant to Rule 144A and Regulation S. Various series of the First Lien Notes were issued on June 1, 2016, March 20, 2019, and April 9, 2020 in aggregate principal amounts of $20.0 billion, $4.5 billion, and $2.25 billion, respectively.  Interest on the First Lien Notes is payable semiannually.  The First Lien Notes are secured on an equal and ratable basis with the Senior Secured Credit Facilities by substantially all of the tangible and intangible assets of the issuers and guarantors that secure obligations under the Senior Secured Credit Facilities, including pledges of all capital stock of the issuers, Dell, and certain wholly-owned material subsidiaries of the issuers and the guarantors, subject to certain exceptions.

- removed (2022-06-06):
[0001571996-21-000063:note_history:101]
In June 2021, Dell International L.L.C and EMC Corporation completed the previously announced offers to exchange any and all outstanding First Lien Notes for registered first lien notes having terms substantially identical to the terms of the First Lien Notes.  The Issuers issued an aggregate $18.4 billion principal amount of registered first lien notes in exchange for the same principal amount of First Lien Notes.  The aggregate principal amount of unregistered First Lien Notes remaining outstanding following the settlement of the exchange offers was approximately $0.1 billion.  Following the exchange offer, such registered first lien notes, together with the remaining unregistered First Lien Notes, are collectively referred to as “First Lien Notes” in these Notes to the Condensed Consolidated Financial Statements.

- removed (2022-06-06):
[0001571996-21-000063:note_history:102]
Subsequent to October 29, 2021, the Company repaid $1.5 billion principal amount of First Lien Notes.  Further, in conjunction with the termination of the Existing Credit Agreement, the tangible and intangible assets of the issuers and guarantors that secure obligations under the Senior Secured Credit Facilities were released as collateral and the First Lien Notes became fully unsecured.  See Note 18 of the Notes to the Condensed Consolidated Financial Statements for more information about the First Lien Notes principal repayment subsequent to October 29, 2021.

- removed (2022-06-06):
[0001571996-21-000063:note_history:103]
Unsecured Debt

- removed (2022-06-06):
[0001571996-21-000063:note_history:104]
Senior Notes — The senior unsecured notes (collectively, the “Senior Notes”) were issued on June 22, 2016 in an aggregate principal amount of $3.3 billion.  Interest on outstanding borrowings is payable semiannually.  Subsequent to October 29, 2021, the Company repaid the remaining $1.63 billion principal amount of Senior Notes.  Following the full redemption of the Senior Note, the indenture governing the Senior Notes was terminated.  See Note 18 of the Notes to the Condensed Consolidated Financial Statements for more information about the Senior Notes principal repayment subsequent to October 29, 2021.

- removed (2022-06-06):
[0001571996-21-000063:note_history:105]
EMC Notes — On September 7, 2016, as result of the merger with EMC, Dell acquired multiple outstanding Notes (collectively, the “EMC Notes”).  During the three months ended October 29, 2021, the Company repaid the remaining  $1.0 billion principal amount of the EMC Notes.

- removed (2022-06-06):
[0001571996-21-000063:note_history:106]
VMware Notes — VMware, Inc. completed public offerings of unsecured senior notes in the aggregate amounts of $4.0 billion, $2.0 billion, and $6.0 billion on August 21, 2017, April 7, 2020, and August 2, 2021, respectively (the “VMware Notes”).   None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.  Interest on outstanding borrowings is payable semiannually.

- removed (2022-06-06):
[0001571996-21-000063:note_history:107]
VMware Revolving Credit Facility and Term Loan Facilities — On September 12, 2017, VMware, Inc. entered into an unsecured credit agreement, that established a revolving credit facility (the “VMware Revolving Credit Facility”) with a syndicate of lenders that provided the company with a borrowing capacity of up to $1.0 billion for VMware, Inc. general corporate purposes.  On September 2, 2021, VMware, Inc. entered into an unsecured credit agreement establishing a revolving credit facility with a syndicate of lenders that provides VMware, Inc. with a borrowing capacity of up to $1.5 billion for general corporate purposes (the “2021 VMware Revolving Credit Facility”).  The 2021 VMware Revolving Credit Facility replaced VMware, Inc.’s existing $1.0 billion revolving credit facility that was undrawn.  Commitments under the 2021 Revolving Credit Facility are available for a period of five years, which may be extended, subject to the satisfaction of certain conditions, by up to two one-year periods.  The credit agreement contains certain representations, warranties and covenants.  Commitment fees, interest rates and other terms of borrowing under the 2021 Revolving Credit Facility may vary based on VMware’s external credit ratings.  As of October 29, 2021, there were no outstanding borrowings under the 2021 VMware Revolving Credit Facility.

- removed (2022-06-06):
[0001571996-21-000063:note_history:108]
In addition, VMware, Inc. received commitments from financial institutions for a 3-year senior unsecured term loan facility and a 5-year senior unsecured term loan facility that would provide VMware, Inc. with a borrowing capacity of up to $4.0 billion (the “VMware Term Loan Facilities”).  VMware, Inc. may borrow against the term loan once up to its borrowing capacity of $4.0 billion.  Subsequent to October 29, 2021, and in advance of the close of the VMware Spin-off on November 1, 2021, VMware, Inc. borrowed $4.0 billion against the VMware Term Loan Facilities with the proceeds utilized to fund a portion of the special cash dividend paid by VMware, Inc. in connection with the VMware Spin-off transaction.  See Note 18 of the Notes to the Condensed Consolidated Financial Statements for more information about the VMware Spin-off transaction.

- removed (2022-06-06):
[0001571996-21-000063:note_history:109]
None of the net proceeds of the 2021 VMware Revolving Credit Facility or the VMware Term Loan Facilities will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.

- removed (2022-06-06):
[0001571996-21-000063:note_history:110]
DFS Debt

- removed (2022-06-06):
[0001571996-21-000063:note_history:111]
Other

- removed (2022-06-06):
[0001571996-21-000063:note_history:112]
Margin Loan Facility — On April 12, 2017, the Company entered into the Margin Loan Facility in an aggregate principal amount of $2.0 billion.  In connection with the Class V transaction described in Note 1 of the Notes to the Condensed Consolidated Financial Statements, on December 20, 2018, the Company amended the Margin Loan Facility to increase the aggregate principal amount to $3.4 billion.  In connection with obtaining the Term Loan A-6 Facility during the fiscal year ended January 31, 2020, the Company increased the aggregate principal amount of the Margin Loan Facility to $4.0 billion.  VMware Holdco LLC, a wholly-owned subsidiary of EMC, was the borrower under the Margin Loan Facility, which was secured by approximately 76 million shares of Class B common stock of VMware, Inc. and approximately 24 million shares of Class A common stock of VMware, Inc.

- removed (2022-06-06):
[0001571996-21-000063:note_history:113]
Loans under the Margin Loan Facility bore interest at a rate per annum payable, at the borrower’s option, either at (a) a base rate plus 1.25% per annum or (b) a LIBOR-based rate plus 2.25% per annum.  Interest under the Margin Loan Facility was payable quarterly.  The Margin Loan Facility was scheduled to mature in April 2022.  The borrower had the option to  voluntarily repay outstanding loans under the Margin Loan Facility at any time without premium or penalty, other than customary “breakage” costs, subject to certain minimum threshold amounts for prepayment.  During the nine months ended October 29, 2021, the Company repaid the $4.0 billion principal amount of the Margin Loan Facility.  Upon repayment, the VMware, Inc. common stock pledged to secure the Margin Loan Facility was released as collateral in accordance with the associated Margin Loan Facility agreement.

- removed (2022-06-06):
[0001571996-21-000063:note_history:114]
|  | Maturities by Fiscal Year (a) |
|  | 2022(remaining three months) |  | 2023 |  | 2024 |  | 2025 |  | 2026 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Secured Credit Facilities and First Lien Notes | $ | 7,754 |  |  | $ | — |  |  | $ | 2,250 |  |  | $ | 1,000 |  |  | $ | 1,000 |  |  | $ | 12,750 |  |  | $ | 24,754 |  |
| Unsecured Notes and Debentures | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 952 |  |  | 952 |  |
| Senior Notes and EMC Notes | 1,625 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 1,625 |  |
| VMware Notes | — |  |  | 1,500 |  |  | 1,000 |  |  | 1,250 |  |  | 750 |  |  | 6,250 |  |  | 10,750 |  |
| DFS Debt | 1,378 |  |  | 5,019 |  |  | 1,888 |  |  | 1,016 |  |  | 86 |  |  | 590 |  |  | 9,977 |  |
| Other | 9 |  |  | 33 |  |  | 187 |  |  | 124 |  |  | 23 |  |  | 24 |  |  | 400 |  |
| Total maturities, principal amount | 10,766 |  |  | 6,552 |  |  | 5,325 |  |  | 3,390 |  |  | 1,859 |  |  | 20,566 |  |  | 48,458 |  |
| Associated carrying value adjustments | (94) |  |  | (7) |  |  | (20) |  |  | (20) |  |  | (6) |  |  | (332) |  |  | (479) |  |
| Total maturities, carrying value amount | $ | 10,672 |  |  | $ | 6,545 |  |  | $ | 5,305 |  |  | $ | 3,370 |  |  | $ | 1,853 |  |  | $ | 20,234 |  |  | $ | 47,979 |  |

- removed (2022-06-06):
[0001571996-21-000063:note_history:115]
____________________

- removed (2022-06-06):
[0001571996-21-000063:note_history:116]
(a) Maturities by Fiscal Year reflects $9.4 billion principal amount of debt within the remaining three months of Fiscal 2022 to align to the classification of this debt as short-term on the Condensed Consolidated Statements of Financial Position and reflect the Company’s intent to repay during the fourth quarter of Fiscal 2022.

- removed (2022-06-06):
[0001571996-21-000063:note_history:117]
Covenants and Unrestricted Net Assets — The credit agreement for the Senior Secured Credit Facilities contains customary negative covenants that generally limit the ability of Denali Intermediate Inc., a wholly-owned subsidiary of Dell Technologies (“Denali Intermediate”), Dell, and Dell’s and Denali Intermediate’s other restricted subsidiaries to incur debt, create liens, make fundamental changes, enter into asset sales, make certain investments, pay dividends or distribute or redeem certain equity interests, prepay or redeem certain debt, and enter into certain transactions with affiliates.  The indenture governing the Senior Notes contains customary negative covenants that generally limit the ability of Denali Intermediate, Dell, and Dell’s and Denali Intermediate’s other restricted subsidiaries to incur additional debt or issue certain preferred shares, pay dividends on or make other distributions in respect of capital stock or make other restricted payments, make certain investments, sell or transfer certain assets, create liens on certain assets to secure debt, consolidate, merge, sell, or otherwise dispose of all or substantially all assets, enter into certain transactions with affiliates, and designate subsidiaries as unrestricted subsidiaries.  The negative covenants under such credit agreements and indenture are subject to certain exceptions, qualifications, and “baskets.”  The indentures governing the First Lien Notes, the Unsecured Notes and Debentures, and the EMC Notes variously impose limitations, subject to specified exceptions, on creating certain liens, entering into sale and lease-back transactions, and entering into certain asset sales.  The foregoing credit agreements and indentures contain customary events of default, including failure to make required payments, failure to comply with covenants, and the occurrence of certain events of bankruptcy and insolvency.

- removed (2022-06-06):
[0001571996-21-000063:note_history:118]
As of October 29, 2021, the Company had certain consolidated subsidiaries that were designated as unrestricted subsidiaries for all purposes of the applicable credit agreements and the indentures governing the First Lien Notes and the Senior Notes.  Substantially all of the net assets of the Company’s consolidated subsidiaries were restricted, with the exception of the Company’s unrestricted subsidiaries, primarily VMware, Inc., Secureworks, and their respective subsidiaries, as of October 29, 2021.

- removed (2022-06-06):
[0001571996-21-000063:note_history:119]
The Senior Secured Credit Facilities and the Revolving Credit Facility are subject to a first lien leverage ratio covenant that is tested at the end of each fiscal quarter of Dell with respect to Dell’s preceding four fiscal quarters.  The Company was in compliance with all financial covenants as of October 29, 2021.

- removed (2022-06-06):
[0001571996-21-000063:note_history:120]
Subsequent to October 29, 2021 and following the full redemption of the outstanding term loan facilities and Senior Notes, the Existing Credit Agreement and the indenture governing the Senior Notes were terminated.  The 2021 Revolving Credit Facility contains customary negative covenants that generally limit the ability of Dell, Dell International L.L.C, and EMC to create liens and make fundamental changes.  The 2021 Revolving Credit Facility is subject to an interest coverage ratio covenant that is tested at the end of each fiscal quarter of Dell with respect to Dell’s preceding four fiscal quarters.  See Note 18 of the Notes to the Condensed Consolidated Financial Statements for more information about debt repayments that occurred subsequent to October 29, 2021.


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2022-06-06):
[0001571996-22-000021:note_history:121]
|  | April 29, 2022 |  | January 28, 2022 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Notes | $ | 16.1 |  |  | $ | 16.7 |  |  | $ | 16.1 |  |  | $ | 18.5 |  |
| Legacy Notes and Debentures | $ | 0.8 |  |  | $ | 1.0 |  |  | $ | 0.8 |  |  | $ | 1.1 |  |

- removed (2022-06-06):
[0001571996-21-000063:note_history:122]
|  | October 29, 2021 |  | January 29, 2021 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Secured Credit Facilities | $ | 6.2 |  |  | $ | 6.3 |  |  | $ | 6.2 |  |  | $ | 6.3 |  |
| First Lien Notes | $ | 18.3 |  |  | $ | 22.8 |  |  | $ | 18.3 |  |  | $ | 22.8 |  |
| Unsecured Notes and Debentures | $ | 0.8 |  |  | $ | 1.2 |  |  | $ | 1.2 |  |  | $ | 1.6 |  |
| Senior Notes | $ | 1.6 |  |  | $ | 1.7 |  |  | $ | 2.7 |  |  | $ | 2.8 |  |
| EMC Notes | $ | — |  |  | $ | — |  |  | $ | 1.0 |  |  | $ | 1.0 |  |
| VMware Notes | $ | 10.7 |  |  | $ | 11.1 |  |  | $ | 4.7 |  |  | $ | 5.3 |  |
| Margin Loan Facility | $ | — |  |  | $ | — |  |  | $ | 4.0 |  |  | $ | 3.9 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2022-06-06):
[0001571996-22-000021:note_history:123]
The majority of DFS debt is non-recourse to Dell Technologies and represents borrowings under securitization programs and structured financing programs, for which the Company’s risk of loss is limited to transferred loan and lease payments and associated equipment.  
The following table presents DFS debt as of the dates indicated and excludes the allocated portion of the Company’s other borrowings, which represents the additional amount considered to fund the DFS business:

- changed (2022-06-06):
[0001571996-22-000021:note_history:124]
|  | April 29, 2022 |  | January 28, 2022 |
| DFS debt | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing and securitization facilities | $ | 2,720 |  |  | $ | 3,054 |  |
| Fixed-term securitization offerings | 3,607 |  |  | 3,011 |  |
| Other | 125 |  |  | 135 |  |
| Total DFS U.S. debt | 6,452 |  |  | 6,200 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 730 |  |  | 739 |  |
| Other borrowings | 818 |  |  | 785 |  |
| Note payable | 250 |  |  | 250 |  |
| Dell Bank senior unsecured eurobonds | 1,575 |  |  | 1,672 |  |
| Total DFS international debt | 3,373 |  |  | 3,446 |  |
| Total DFS debt | $ | 9,825 |  |  | $ | 9,646 |  |
| Total short-term DFS debt | $ | 5,907 |  |  | $ | 5,803 |  |
| Total long-term DFS debt | $ | 3,918 |  |  | $ | 3,843 |  |
  (was, 2021-12-03, similarity 0.9842):
[0001571996-21-000063:note_history:124]
|  | October 29, 2021 |  | January 29, 2021 |
|  | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing and securitization facilities | $ | 2,650 |  |  | $ | 3,311 |  |
| Fixed-term securitization offerings | 3,618 |  |  | 2,961 |  |
| Other | 147 |  |  | 140 |  |
| Total DFS U.S. debt | 6,415 |  |  | 6,412 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 751 |  |  | 786 |  |
| Other borrowings | 809 |  |  | 1,006 |  |
| Note payable | 250 |  |  | 250 |  |
| Dell Bank Senior Unsecured Eurobonds | 1,752 |  |  | 1,212 |  |
| Total DFS international debt | 3,562 |  |  | 3,254 |  |
| Total DFS debt | $ | 9,977 |  |  | $ | 9,666 |  |
| Total short-term DFS debt | $ | 5,475 |  |  | $ | 4,888 |  |
| Total long-term DFS debt | $ | 4,502 |  |  | $ | 4,778 |  |

- changed (2022-06-06):
[0001571996-22-000021:note_history:125]
The following table summarizes the Company’s outstanding debt as of the dates indicated:
  (was, 2021-12-03, similarity 0.931):
[0001571996-21-000063:note_history:125]
The following table presents the Company’s outstanding debt as of the dates indicated:

- added (2022-06-06):
[0001571996-22-000021:note_history:126]
|  | April 29, 2022 |  | January 28, 2022 |
|  | (in millions) |
| Senior Notes: |  |  |  |
| 5.45% due June 2023 | 1,000 |  |  | 1,000 |  |
| 4.00% due July 2024 | 1,000 |  |  | 1,000 |  |
| 5.85% due July 2025 | 1,000 |  |  | 1,000 |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 4.90% due October 2026 | 1,750 |  |  | 1,750 |  |
| 6.10% due July 2027 | 500 |  |  | 500 |  |
| 5.30% due October 2029 | 1,750 |  |  | 1,750 |  |
| 6.20% due July 2030 | 750 |  |  | 750 |  |
| 8.10% due July 2036 | 1,000 |  |  | 1,000 |  |
| 3.38% due December 2041 | 1,000 |  |  | 1,000 |  |
| 8.35% due July 2046 | 800 |  |  | 800 |  |
| 3.45% due December 2051 | 1,250 |  |  | 1,250 |  |
| Legacy Notes and Debentures: |  |  |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| DFS Debt (Note 5) | 9,825 |  |  | 9,646 |  |
| Other | 320 |  |  | 337 |  |
| Total debt, principal amount | $ | 27,397 |  |  | $ | 27,235 |  |
| Unamortized discount, net of unamortized premium | (131) |  |  | (134) |  |
| Debt issuance costs | (144) |  |  | (147) |  |
| Total debt, carrying value | $ | 27,122 |  |  | $ | 26,954 |  |
| Total short-term debt, carrying value | $ | 5,925 |  |  | $ | 5,823 |  |
| Total long-term debt, carrying value | $ | 21,197 |  |  | $ | 21,131 |  |

- removed (2022-06-06):
[0001571996-21-000063:note_history:127]
The following table presents DFS debt as of the dates indicated.  The table excludes the allocated portion of the Company’s other borrowings, which represents the additional amount considered to fund the DFS business.

- removed (2022-06-06):
[0001571996-21-000063:note_history:128]
|  | October 29, 2021 |  | January 29, 2021 |
|  | (in millions) |
| Secured Debt |  |  |  |
| Senior Secured Credit Facilities: |  |  |  |
| 2.00% Term Loan B-2 Facility due September 2025 (a) | $ | 3,120 |  |  | $ | 3,143 |  |
| 1.84% Term Loan A-6 Facility due March 2024 (a) | 3,134 |  |  | 3,134 |  |
| First Lien Notes: |  |  |  |
| 5.45% due June 2023 (a) | 3,750 |  |  | 3,750 |  |
| 4.00% due July 2024 | 1,000 |  |  | 1,000 |  |
| 5.85% due July 2025 | 1,000 |  |  | 1,000 |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 4.90% due October 2026 | 1,750 |  |  | 1,750 |  |
| 6.10% due July 2027 | 500 |  |  | 500 |  |
| 5.30% due October 2029 | 1,750 |  |  | 1,750 |  |
| 6.20% due July 2030 | 750 |  |  | 750 |  |
| 8.10% due July 2036 | 1,500 |  |  | 1,500 |  |
| 8.35% due July 2046 | 2,000 |  |  | 2,000 |  |
| Unsecured Debt |  |  |  |
| Unsecured Notes and Debentures: |  |  |  |
| 4.625% due April 2021 | — |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| Senior Notes: |  |  |  |
| 5.875% due June 2021 | — |  |  | 1,075 |  |
| 7.125% due June 2024 (a) | 1,625 |  |  | 1,625 |  |
| EMC Notes: |  |  |  |
| 3.375% due June 2023 | — |  |  | 1,000 |  |
| VMware Notes: |  |  |  |
| 2.95% due August 2022 | 1,500 |  |  | 1,500 |  |
| 0.60% due August 2023 | 1,000 |  |  | — |  |
| 1.00% due August 2024 | 1,250 |  |  | — |  |
| 4.50% due May 2025 | 750 |  |  | 750 |  |
| 1.40% due August 2026 | 1,500 |  |  | — |  |
| 4.65% due May 2027 | 500 |  |  | 500 |  |
| 3.90% due August 2027 | 1,250 |  |  | 1,250 |  |
| 1.80% due August 2028 | 750 |  |  | — |  |
| 4.70% due May 2030 | 750 |  |  | 750 |  |
| 2.20% due August 2031 | 1,500 |  |  | — |  |
| DFS Debt (Note 3) | 9,977 |  |  | 9,666 |  |
| Other |  |  |  |
| 2.44% Margin Loan Facility due April 2022 | — |  |  | 4,000 |  |
| Other | 400 |  |  | 235 |  |
| Total debt, principal amount | $ | 48,458 |  |  | $ | 48,480 |  |

- removed (2022-06-06):
[0001571996-21-000063:note_history:129]
|  | October 29, 2021 |  | January 29, 2021 |
|  | (in millions) |
| Total debt, principal amount | $ | 48,458 |  |  | $ | 48,480 |  |
| Unamortized discount, net of unamortized premium | (175) |  |  | (194) |  |
| Debt issuance costs | (304) |  |  | (302) |  |
| Total debt, carrying value | $ | 47,979 |  |  | $ | 47,984 |  |
| Total short-term debt, carrying value (b) | $ | 16,280 |  |  | $ | 6,362 |  |
| Total long-term debt, carrying value | $ | 31,699 |  |  | $ | 41,622 |  |

- removed (2022-06-06):
[0001571996-21-000063:note_history:130]
____________________

- removed (2022-06-06):
[0001571996-21-000063:note_history:131]
(a)    Subsequent to October 29, 2021, the Company used the net proceeds from its $9.3 billion pro rata share of the cash dividend received in connection with the VMware Spin-off, as well as cash on hand, to repay $3.12 billion principal amount of the 2.00% Term Loan B-2 Facility due September 2025, $3.13 billion principal amount of the 1.84% Term Loan A-6 Facility due March 2024, $1.63 billion principal amount of the 7.125% Senior Notes due June 2024, and $1.50 billion principal amount of the 5.45% First Lien Notes due June 2023.

- removed (2022-06-06):
[0001571996-21-000063:note_history:132]
(b)    Given the probability of the close of the VMware Spin-off and the Company’s intent and ability to repay, the Company classified $9.4 billion principal amount of debt as short-term liabilities on the Condensed Consolidated Statements of Financial Position as of October 29, 2021.


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-06-06):
[0001571996-22-000021:note_history:133]
The following tables presents the aggregate future maturities of the Company’s debt as of April 29, 2022 for the periods indicated:
  (was, 2021-12-03, similarity 0.9565):
[0001571996-21-000063:note_history:133]
The following table presents the aggregate future maturities of the Company’s debt as of October 29, 2021 for the periods indicated:

- added (2022-06-06):
[0001571996-22-000021:note_history:134]
|  | Maturities by Fiscal Year |
|  | 2023 (remaining nine months) |  | 2024 |  | 2025 |  | 2026 |  | 2027 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Notes | $ | — |  |  | $ | 1,000 |  |  | $ | 1,000 |  |  | $ | 1,000 |  |  | $ | 6,250 |  |  | $ | 7,050 |  |  | $ | 16,300 |  |
| Legacy Notes and Debentures | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 952 |  |  | 952 |  |
| DFS Debt | 5,201 |  |  | 2,612 |  |  | 1,294 |  |  | 165 |  |  | 550 |  |  | 3 |  |  | 9,825 |  |
| Other | 23 |  |  | 165 |  |  | 109 |  |  | 20 |  |  | 1 |  |  | 2 |  |  | 320 |  |
| Total maturities, principal amount | 5,224 |  |  | 3,777 |  |  | 2,403 |  |  | 1,185 |  |  | 6,801 |  |  | 8,007 |  |  | 27,397 |  |
| Associated carrying value adjustments | (5) |  |  | (6) |  |  | (9) |  |  | (8) |  |  | (56) |  |  | (191) |  |  | (275) |  |
| Total maturities, carrying value amount | $ | 5,219 |  |  | $ | 3,771 |  |  | $ | 2,394 |  |  | $ | 1,177 |  |  | $ | 6,745 |  |  | $ | 7,816 |  |  | $ | 27,122 |  |

- removed (2022-06-06):
[0001571996-21-000063:note_history:135]
|  | Maturities by Fiscal Year (a) |
|  | 2022(remaining three months) |  | 2023 |  | 2024 |  | 2025 |  | 2026 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Secured Credit Facilities and First Lien Notes | $ | 7,754 |  |  | $ | — |  |  | $ | 2,250 |  |  | $ | 1,000 |  |  | $ | 1,000 |  |  | $ | 12,750 |  |  | $ | 24,754 |  |
| Unsecured Notes and Debentures | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 952 |  |  | 952 |  |
| Senior Notes and EMC Notes | 1,625 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 1,625 |  |
| VMware Notes | — |  |  | 1,500 |  |  | 1,000 |  |  | 1,250 |  |  | 750 |  |  | 6,250 |  |  | 10,750 |  |
| DFS Debt | 1,378 |  |  | 5,019 |  |  | 1,888 |  |  | 1,016 |  |  | 86 |  |  | 590 |  |  | 9,977 |  |
| Other | 9 |  |  | 33 |  |  | 187 |  |  | 124 |  |  | 23 |  |  | 24 |  |  | 400 |  |
| Total maturities, principal amount | 10,766 |  |  | 6,552 |  |  | 5,325 |  |  | 3,390 |  |  | 1,859 |  |  | 20,566 |  |  | 48,458 |  |
| Associated carrying value adjustments | (94) |  |  | (7) |  |  | (20) |  |  | (20) |  |  | (6) |  |  | (332) |  |  | (479) |  |
| Total maturities, carrying value amount | $ | 10,672 |  |  | $ | 6,545 |  |  | $ | 5,305 |  |  | $ | 3,370 |  |  | $ | 1,853 |  |  | $ | 20,234 |  |  | $ | 47,979 |  |

- removed (2022-06-06):
[0001571996-21-000063:note_history:136]
____________________

- removed (2022-06-06):
[0001571996-21-000063:note_history:137]
(a) Maturities by Fiscal Year reflects $9.4 billion principal amount of debt within the remaining three months of Fiscal 2022 to align to the classification of this debt as short-term on the Condensed Consolidated Statements of Financial Position and reflect the Company’s intent to repay during the fourth quarter of Fiscal 2022.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: no_prior_note, score: 0.0

- added (2022-06-06):
[0001571996-22-000021:note_history:138]
RELATED PARTY TRANSACTIONS 
Effective upon the completion of the VMware Spin-off, VMware is considered to be a related party of the Company.  The related party relationship is a result of Michael Dell’s ownership interest in both Dell Technologies and VMware as well as Mr. Dell’s continued service as Chairman and Chief Executive Officer of Dell Technologies and as Chairman of the Board of VMware, Inc.  See Note 1 and Note 2 of the Notes to the Condensed Consolidated Financial Statements for more information about the VMware Spin-off.

- added (2022-06-06):
[0001571996-22-000021:note_history:139]
The information provided below includes a summary of transactions with VMware, Inc. and with its consolidated subsidiaries (collectively, “VMware”).  Transactions with related parties other than VMware during the periods presented were immaterial, individually and in aggregate.

- added (2022-06-06):
[0001571996-22-000021:note_history:140]
Transactions with VMware

- added (2022-06-06):
[0001571996-22-000021:note_history:141]
Dell Technologies and VMware engage in the following ongoing related party transactions:

- added (2022-06-06):
[0001571996-22-000021:note_history:142]
•Pursuant to original equipment manufacturer and reseller arrangements, Dell Technologies integrates or bundles VMware’s products and services with Dell Technologies’ products and sells them to end-users.  Dell Technologies also acts as a distributor, purchasing VMware’s standalone products and services for resale to end-user customers.  Where applicable, costs under these arrangements are presented net of rebates received by Dell Technologies.

- added (2022-06-06):
[0001571996-22-000021:note_history:143]
•Dell Technologies procures products and services from VMware for its internal use.  For the three months ended April 29, 2022 and April 30, 2021, cost incurred associated with products and services purchased from VMware for internal use was immaterial.

- added (2022-06-06):
[0001571996-22-000021:note_history:144]
•Dell Technologies sells and leases products and sells services to VMware.  For the three months ended April 29, 2022 and April 30, 2021, revenue recognized from sales of services to VMware was immaterial.

- added (2022-06-06):
[0001571996-22-000021:note_history:145]
•Dell Technologies and VMware also enter into joint marketing, sales, and branding arrangements, for which both parties may incur costs.  For the three months ended April 29, 2022 and April 30, 2021, consideration received from VMware for joint marketing, sales, and branding arrangements was immaterial.

- added (2022-06-06):
[0001571996-22-000021:note_history:146]
•DFS provides financing to certain VMware end users.  Upon acceptance of the financing arrangement by both VMware’s end users and DFS, DFS recognizes amounts due to related parties on the Condensed Consolidated Statements of Financial Position.  Associated financing fees are recorded to product net revenue on the Condensed Consolidated Statements of Income.

- added (2022-06-06):
[0001571996-22-000021:note_history:147]
•Dell Technologies and VMware enter into agreements to collaborate on technology projects in which one party pays the corresponding party for services or the reimbursement of costs.  For the three months ended April 29, 2022 and April 30, 2021, collaborative technology projects were immaterial.

- added (2022-06-06):
[0001571996-22-000021:note_history:148]
•Dell Technologies provides support services and support from Dell Technologies personnel to VMware in certain geographic regions where VMware does not have an established legal entity.  These employees are managed by VMware but Dell Technologies incurs the costs for these such services.  The costs incurred by Dell Technologies on VMware’s behalf to these employees are charged to VMware.  For the three months ended April 29, 2022 and April 30, 2021, costs associated with such seconded employees were immaterial.

- added (2022-06-06):
[0001571996-22-000021:note_history:149]
•Dell Technologies and VMware entered into a transition services agreement in connection with the VMware Spin-off to provide various support services including investment advisory services, certain support services from Dell Technologies personnel, and other transitional services.  Costs associated with this agreement were immaterial for the three months ended April 29, 2022.

- added (2022-06-06):
[0001571996-22-000021:note_history:150]
The following table presents information about the impact of Dell Technologies’ related party transactions with VMware on the Condensed Consolidated Statements of Income for the periods indicated:

- added (2022-06-06):
[0001571996-22-000021:note_history:151]
|  |  |  | Three Months Ended |  |  |  |  |  |
|  | Classification |  | April 29, 2022 |  | April 30, 2021 |  |  |  |  |  |
|  |  |  | (in millions) |  |  |  |
| Sales and leases of products to VMware | Net revenue - products |  | 46 |  |  | 47 |  |  |  |  |  |  |
| Purchase of VMware products for resale | Cost of net revenue - products |  | 255 |  |  | 319 |  |  |  |  |  |  |
| Purchase of VMware services for resale | Cost of net revenue - services |  | 709 |  |  | 578 |  |  |  |  |  |  |

- added (2022-06-06):
[0001571996-22-000021:note_history:152]
The following table presents information about the impact of Dell Technologies’ related party transactions with VMware on the Condensed Consolidated Statements of Financial Position for the periods indicated:

- added (2022-06-06):
[0001571996-22-000021:note_history:153]
|  | Classification | April 29, 2022 |  | January 28, 2022 |
|  |  | (in millions) |
| Deferred costs related to VMware products and services for resale | Other current assets | $ | 2,493 |  |  | $ | 2,571 |  |
| Deferred costs related to VMware products and services for resale | Other non-current assets | $ | 2,060 |  |  | $ | 2,311 |  |

- added (2022-06-06):
[0001571996-22-000021:note_history:154]
Related Party Tax Matters

- added (2022-06-06):
[0001571996-22-000021:note_history:155]
Tax Agreements — In connection with the VMware Spin-off and concurrently with the execution of the Separation and Distribution Agreement, effective as of April 14, 2021, Dell Technologies and VMware entered into a Tax Matters Agreement (the “Tax Matters Agreement”) and agreed to terminate the tax sharing agreement as amended on December 30, 2019 (together with the Tax Matters Agreement, the “Tax Agreements”).  The Tax Matters Agreement governs Dell Technologies’ and VMware’s respective rights and obligations, both for pre-spin-off periods and post-spin-off periods, regarding income and other taxes, and related matters, including tax liabilities and benefits, attributes, and returns.

- added (2022-06-06):
[0001571996-22-000021:note_history:156]
Net payments made to VMware pursuant to the Tax Agreements were immaterial during the three months ended April 29, 2022 and April 30, 2021, and relate to VMware’s portion of federal income taxes on Dell Technologies’ consolidated tax return as well as state tax payments for combined states.

- added (2022-06-06):
[0001571996-22-000021:note_history:157]
The timing of the tax payments due to and from related parties is governed by the Tax Agreements.  VMware’s portion of the mandatory one-time transition tax on accumulated earnings of foreign subsidiaries (the “Transition Tax”) is governed by a letter agreement between VMware and Dell Technologies entered into on April 1, 2019.

- added (2022-06-06):
[0001571996-22-000021:note_history:158]
As a result of the activity under the Tax Agreements with VMware, amounts due from VMware were $630 million and $621 million as of April 29, 2022 and January 28, 2022, respectively, primarily related to VMware’s estimated tax obligation resulting from the Transition Tax.  The 2017 Tax Cuts and Jobs Act included a deferral election for an eight-year installment payment method on the Transition Tax.  Dell Technologies expects VMware to pay the remainder of its Transition Tax over a period of four years.

- added (2022-06-06):
[0001571996-22-000021:note_history:159]
Indemnification — Upon consummation of the VMware Spin-off, Dell Technologies recorded net income tax indemnification receivables from VMware related to certain income tax liabilities for which Dell Technologies is jointly and severally liable, but for which it is indemnified by VMware under the Tax Matters Agreement.  The amounts that VMware may be obligated to pay Dell Technologies could vary depending on the outcome of certain unresolved tax matters, which may not be resolved for several years.  The net receivable as of April 29, 2022 was $147 million.

- added (2022-06-06):
[0001571996-22-000021:note_history:160]
Due To/From Related Party

- added (2022-06-06):
[0001571996-22-000021:note_history:161]
The following table presents amounts due to and from VMware as of the dates indicated:

- added (2022-06-06):
[0001571996-22-000021:note_history:162]
|  | April 29, 2022 |  | January 28, 2022 |
|  | (in millions) |
| Due from related party, net, current (a) | $ | 131 |  |  | $ | 131 |  |
| Due from related party, net, non-current (b) | $ | 713 |  |  | $ | 710 |  |
| Due to related party, current (c) | $ | 622 |  |  | $ | 1,414 |  |

- added (2022-06-06):
[0001571996-22-000021:note_history:163]
____________________

- added (2022-06-06):
[0001571996-22-000021:note_history:164]
(a)    Amounts due from related party, current consists of amounts due from VMware, inclusive of current net tax receivables from VMware under the Tax Agreements.  Amounts, excluding tax, are generally settled in cash within 60 days of each quarter-end.

- added (2022-06-06):
[0001571996-22-000021:note_history:165]
(b)  Amounts in due from related party, non-current consists of non-current portion of net receivables from VMware under the Tax Agreements.

- added (2022-06-06):
[0001571996-22-000021:note_history:166]
(c)  Amounts in due to related party, current includes amounts due to VMware which are generally settled in cash within 60 days of each quarter-end.


## us-gaap:ScheduleOfRelatedPartyTransactionsTableTextBlock (related_parties) — matched_by: no_prior_note, score: 0.0

- added (2022-06-06):
[0001571996-22-000021:note_history:167]
The following table presents information about the impact of Dell Technologies’ related party transactions with VMware on the Condensed Consolidated Statements of Income for the periods indicated:

- added (2022-06-06):
[0001571996-22-000021:note_history:168]
|  |  |  | Three Months Ended |  |  |  |  |  |
|  | Classification |  | April 29, 2022 |  | April 30, 2021 |  |  |  |  |  |
|  |  |  | (in millions) |  |  |  |
| Sales and leases of products to VMware | Net revenue - products |  | 46 |  |  | 47 |  |  |  |  |  |  |
| Purchase of VMware products for resale | Cost of net revenue - products |  | 255 |  |  | 319 |  |  |  |  |  |  |
| Purchase of VMware services for resale | Cost of net revenue - services |  | 709 |  |  | 578 |  |  |  |  |  |  |

- added (2022-06-06):
[0001571996-22-000021:note_history:169]
The following table presents information about the impact of Dell Technologies’ related party transactions with VMware on the Condensed Consolidated Statements of Financial Position for the periods indicated:

- added (2022-06-06):
[0001571996-22-000021:note_history:170]
|  | Classification | April 29, 2022 |  | January 28, 2022 |
|  |  | (in millions) |
| Deferred costs related to VMware products and services for resale | Other current assets | $ | 2,493 |  |  | $ | 2,571 |  |
| Deferred costs related to VMware products and services for resale | Other non-current assets | $ | 2,060 |  |  | $ | 2,311 |  |

- added (2022-06-06):
[0001571996-22-000021:note_history:171]
The following table presents amounts due to and from VMware as of the dates indicated:

- added (2022-06-06):
[0001571996-22-000021:note_history:172]
|  | April 29, 2022 |  | January 28, 2022 |
|  | (in millions) |
| Due from related party, net, current (a) | $ | 131 |  |  | $ | 131 |  |
| Due from related party, net, non-current (b) | $ | 713 |  |  | $ | 710 |  |
| Due to related party, current (c) | $ | 622 |  |  | $ | 1,414 |  |

- added (2022-06-06):
[0001571996-22-000021:note_history:173]
____________________

- added (2022-06-06):
[0001571996-22-000021:note_history:174]
(a)    Amounts due from related party, current consists of amounts due from VMware, inclusive of current net tax receivables from VMware under the Tax Agreements.  Amounts, excluding tax, are generally settled in cash within 60 days of each quarter-end.

- added (2022-06-06):
[0001571996-22-000021:note_history:175]
(b)  Amounts in due from related party, non-current consists of non-current portion of net receivables from VMware under the Tax Agreements.

- added (2022-06-06):
[0001571996-22-000021:note_history:176]
(c)  Amounts in due to related party, current includes amounts due to VMware which are generally settled in cash within 60 days of each quarter-end.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2022-06-06):
[0001571996-22-000021:note_history:177]
|  |  |  | Three Months Ended |
|  |  |  |  |  | April 29, 2022 |  | April 30, 2021 |  |  |
|  |  |  |  |  | (in millions) |
| Net revenue: |  |  |  |  |  |  |  |  |  |
| Infrastructure Solutions Group: |  |  |  |  |  |  |  |  |  |
| Servers and networking |  |  |  |  | $ | 5,048 |  |  | $ | 4,140 |  |  |  |
| Storage |  |  |  |  | 4,237 |  |  | 3,893 |  |  |  |
| Total ISG net revenue |  |  |  |  | $ | 9,285 |  |  | $ | 8,033 |  |  |  |
| Client Solutions Group: |  |  |  |  |  |  |  |  |  |
| Commercial |  |  |  |  | $ | 11,971 |  |  | $ | 9,808 |  |  |  |
| Consumer |  |  |  |  | 3,616 |  |  | 3,503 |  |  |  |
| Total CSG net revenue |  |  |  |  | $ | 15,587 |  |  | $ | 13,311 |  |  |  |

- removed (2022-06-06):
[0001571996-21-000063:note_history:178]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 29, 2021 |  | October 30, 2020 |  | October 29, 2021 |  | October 30, 2020 |
|  | (in millions) |
| Net revenue: |  |  |  |  |  |  |  |
| Infrastructure Solutions Group: |  |  |  |  |  |  |  |
| Servers and networking | $ | 4,533 |  |  | $ | 4,164 |  |  | $ | 13,104 |  |  | $ | 12,118 |  |
| Storage | 3,895 |  |  | 3,860 |  |  | 11,667 |  |  | 11,682 |  |
| Total ISG net revenue | 8,428 |  |  | 8,024 |  |  | 24,771 |  |  | 23,800 |  |
| Client Solutions Group: |  |  |  |  |  |  |  |
| Commercial | 12,292 |  |  | 8,783 |  |  | 32,668 |  |  | 25,456 |  |
| Consumer | 4,254 |  |  | 3,503 |  |  | 11,446 |  |  | 9,137 |  |
| Total CSG net revenue | 16,546 |  |  | 12,286 |  |  | 44,114 |  |  | 34,593 |  |
| VMware: |  |  |  |  |  |  |  |
| Total VMware net revenue | 3,178 |  |  | 2,893 |  |  | 9,317 |  |  | 8,556 |  |
| Total segment net revenue | $ | 28,152 |  |  | $ | 23,203 |  |  | $ | 78,202 |  |  | $ | 66,949 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2022-06-06):
[0001571996-22-000021:note_history:179]
DEFERRED REVENUE 
Deferred Revenue — Deferred revenue consists of support and deployment services, software maintenance, training, Software-as-a-Service, and undelivered hardware and professional services, consisting of installations and consulting engagements.  Deferred revenue is recorded when the Company has invoiced or payments have been received for undelivered products or services where transfer of control has not occurred.  Revenue is recognized as the Company’s performance obligations under the contract are completed.

- changed (2022-06-06):
[0001571996-22-000021:note_history:180]
|  | Three Months Ended |
|  | April 29, 2022 |  | April 30, 2021 |
|  | (in millions) |
| Deferred revenue: |  |  |  |
| Deferred revenue at beginning of period | $ | 27,573 |  |  | $ | 25,592 |  |
| Revenue deferrals | 4,975 |  |  | 5,279 |  |
| Revenue recognized | (4,980) |  |  | (4,589) |  |
| Other (a) | (165) |  |  | — |  |
| Deferred revenue at end of period | $ | 27,403 |  |  | $ | 26,282 |  |
| Short-term deferred revenue | $ | 14,329 |  |  | $ | 13,641 |  |
| Long-term deferred revenue | $ | 13,074 |  |  | $ | 12,641 |  |
  (was, 2021-12-03, similarity 0.7473):
[0001571996-21-000063:note_history:180]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 29, 2021 |  | October 30, 2020 |  | October 29, 2021 |  | October 30, 2020 |
|  | (in millions) |
| Deferred revenue: |  |  |  |  |  |  |  |
| Deferred revenue at beginning of period | $ | 31,843 |  |  | $ | 28,791 |  |  | $ | 30,801 |  |  | $ | 27,800 |  |
| Revenue deferrals | 5,706 |  |  | 5,432 |  |  | 18,889 |  |  | 17,560 |  |
| Revenue recognized | (6,095) |  |  | (5,542) |  |  | (18,092) |  |  | (16,418) |  |
| Other (a) | — |  |  | — |  |  | (144) |  |  | (261) |  |
| Deferred revenue at end of period | $ | 31,454 |  |  | $ | 28,681 |  |  | $ | 31,454 |  |  | $ | 28,681 |  |
| Short-term deferred revenue | $ | 16,569 |  |  | $ | 15,259 |  |  | $ | 16,569 |  |  | $ | 15,259 |  |
| Long-term deferred revenue | $ | 14,885 |  |  | $ | 13,422 |  |  | $ | 14,885 |  |  | $ | 13,422 |  |

- added (2022-06-06):
[0001571996-22-000021:note_history:181]
(a)    Other represents the reclassification of deferred revenue to accrued and other liabilities.

- changed (2022-06-06):
[0001571996-22-000021:note_history:182]
Remaining Performance Obligations — Remaining performance obligations represent the aggregate amount of the transaction price allocated to performance obligations not delivered, or partially undelivered, as of the end of the reporting period.  Remaining performance obligations include deferred revenue plus unbilled amounts not yet recorded in deferred revenue.  The value of the transaction price allocated to remaining performance obligations as of April 29, 2022 was approximately $42 billion.  The Company expects to recognize approximately 62% of remaining performance obligations as revenue in the next twelve months, and the remainder thereafter.
  (was, 2021-12-03, similarity 0.9907):
[0001571996-21-000063:note_history:182]
Remaining Performance Obligations — Remaining performance obligations represent the aggregate amount of the transaction price allocated to performance obligations not delivered, or partially undelivered, as of the end of the reporting period.  Remaining performance obligations include deferred revenue plus unbilled amounts not yet recorded in deferred revenue.  The value of the transaction price allocated to remaining performance obligations as of October 29, 2021 was approximately $47 billion.  The Company expects to recognize approximately 62% of remaining performance obligations as revenue in the next twelve months, and the remainder thereafter.

- changed (2022-06-06):
[0001571996-22-000021:note_history:183]
The aggregate amount of the transaction price allocated to remaining performance obligations does not include amounts owed under cancelable contracts where there is no substantive termination penalty.  The Company applied the practical expedient to exclude the value of remaining performance obligations for contracts for which revenue is recognized at the amount to which the Company has the right to invoice for services performed.
  (was, 2021-12-03, similarity 0.9942):
[0001571996-21-000063:note_history:183]
The aggregate amount of the transaction price allocated to remaining performance obligations does not include amounts owed under cancellable contracts where there is no substantive termination penalty.  The Company applied the practical expedient to exclude the value of remaining performance obligations for contracts for which revenue is recognized in the amount to which the Company has the right to invoice for services performed.

- removed (2022-06-06):
[0001571996-21-000063:note_history:184]
NOTE 8 — DEFERRED REVENUE

- removed (2022-06-06):
[0001571996-21-000063:note_history:185]
Deferred Revenue — Deferred revenue is recorded for support and deployment services, software maintenance, professional services, training, and software-as-a-service when the Company has a right to invoice or payments have been received for undelivered products or services where transfer of control has not occurred.  Revenue is recognized on these items when the revenue recognition criteria are met, generally resulting in ratable recognition over the contract term.  The Company also has deferred revenue related to undelivered hardware and professional services, consisting of installations and consulting engagements, which are recognized as the Company’s performance obligations under the contract are completed.

- removed (2022-06-06):
[0001571996-21-000063:note_history:186]
(a) For the nine months ended October 29, 2021, Other consists of divested deferred revenue from the sale of Boomi.  For the nine months ended October 30, 2020, Other consists of divested deferred revenue from the sale of RSA Security.  See Note 1 of the Notes to the Condensed Consolidated Financial Statements for more information about the divestitures of Boomi and of RSA Security.  There was no impact to deferred revenue for the three months ended October 29, 2021 or October 30, 2020 as liabilities in both instances were previously classified as held for sale.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2022-06-06):
[0001571996-22-000021:note_history:187]
SUBSEQUENT EVENTS There were no known events occurring after April 29, 2022 and up until the date of the issuance of this report that would materially affect the information presented herein.

- removed (2022-06-06):
[0001571996-21-000063:note_history:188]
SUBSEQUENT EVENTS 
Spin-off of VMware, Inc.

- removed (2022-06-06):
[0001571996-21-000063:note_history:189]
On November 1, 2021, the Company completed its previously announced spin-off of VMware, Inc. as described in Note 1 of the Notes to the Condensed Consolidated Financial Statements.  Dell Technologies effectuated the VMware Spin-off by means of a special stock dividend of 30,678,605 shares of Class A common stock and 307,221,836 shares of Class B common stock of VMware, Inc. to Dell Technologies stockholders of record as of 5:00 p.m., New York City time, on October 29, 2021.

- removed (2022-06-06):
[0001571996-21-000063:note_history:190]
Prior to receipt of the VMware, Inc. common stock by the Company’s stockholders, each share of VMware, Inc. Class B common stock automatically converted into one share of VMware, Inc. Class A common stock.  As result of these transactions, each holder of record of shares of Dell Technologies common stock as of the distribution record date received approximately 0.440626 of a share of VMware Class A common stock for each share of Dell Technologies common stock held as of such date, based on shares outstanding as of the completion of the VMware Spin-off.

- removed (2022-06-06):
[0001571996-21-000063:note_history:191]
Immediately following the payment by VMware, Inc. to its stockholders of a special cash dividend of $11.5 billion, of which Dell Technologies received approximately $9.3 billion, the separation of VMware, Inc. from Dell Technologies occurred, including through the termination or settlement of certain intercompany accounts and intercompany contracts.

- removed (2022-06-06):
[0001571996-21-000063:note_history:192]
Repayment of Indebtedness and Termination of the Existing Credit Agreement

- removed (2022-06-06):
[0001571996-21-000063:note_history:193]
The Company used the net proceeds from its $9.3 billion pro rata portion of the cash dividend received in connection with the VMware Spin-off, as well as cash on hand, to repay outstanding debt as described below.

- removed (2022-06-06):
[0001571996-21-000063:note_history:194]
On November 1, 2021, the Company repaid the remaining $3,134 million and $3,120 million principal amounts related to the 1.84% Term Loan A-6 Facility due March 2024 and the 2.00% Term Loan B-2 Facility due September 2025, respectively, and terminated all obligations and commitments under the Existing Credit Agreement.

- removed (2022-06-06):
[0001571996-21-000063:note_history:195]
On November 2, 2021, the Company repaid $1,500 million principal amount of the 5.45% First Lien Notes due June 2023 and the remaining $1,625 million principal amount of the 7.125% Senior Notes due June 2024.  Further, in conjunction with the termination of the Existing Credit Agreement, the tangible and intangible assets of the issuers and guarantors that secure obligations under the Senior Secured Credit Facilities were released as collateral and the First Lien Notes became fully unsecured.

- removed (2022-06-06):
[0001571996-21-000063:note_history:196]
In connection with the above debt repayments, the Company incurred $181 million of debt breakage fees and recognized $110 million in unamortized debt discounts associated with the early extinguishment of the debt.

- removed (2022-06-06):
[0001571996-21-000063:note_history:197]
2021 Revolving Credit Facility

- removed (2022-06-06):
[0001571996-21-000063:note_history:198]
On November 1, 2021, the Company entered into the 2021 Revolving Credit Facility, a senior unsecured revolving credit facility with JPMorgan Chase Bank, N.A., as administrative agent, and each of the lenders and other parties from time to time party thereto.

- removed (2022-06-06):
[0001571996-21-000063:note_history:199]
The 2021 Revolving Credit Facility, which matures on November 1, 2026, provides the Company with revolving commitments in an aggregate principal amount of $5.0 billion for general corporate purposes and includes a letter of credit sub-facility of up to $500 million and a swing-line loan sub-facility of up to $500 million.  The 2021 Revolving Credit Facility also allows the Company to request incremental commitments on one or more occasions in a minimum amount of $10 million.

- removed (2022-06-06):
[0001571996-21-000063:note_history:200]
2023 First Lien Notes Notice of Prepayment

- removed (2022-06-06):
[0001571996-21-000063:note_history:201]
On November 19, 2021, the Company issued a partial redemption notice of $1.25 billion principal amount of the 5.45% First Lien Notes due June 2023 with the repayment expected to occur on December 6, 2021.

- removed (2022-06-06):
[0001571996-21-000063:note_history:202]
Common Stock Repurchases

- removed (2022-06-06):
[0001571996-21-000063:note_history:203]
Subsequent to October 29, 2021, the Company began repurchases under the 2021 Stock Repurchase Program described in Note 13 of the Notes to the Condensed Consolidated Financial Statements.  Through November 30, 2021, the Company repurchased  approximately 3.1 million shares of Class C Common Stock for approximately $173 million.

- removed (2022-06-06):
[0001571996-21-000063:note_history:204]
Other than the matters identified above, there were no known events occurring after October 29, 2021 and up until the date of issuance of this report that would materially affect the information presented herein.
