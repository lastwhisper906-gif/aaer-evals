# DELL notes — 0001571996-22-000021


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001571996-22-000021:notes:1]
Basis of Presentation — The accompanying unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes filed with the U.S. Securities and Exchange Commission (“SEC”) in the Company’s Annual Report on Form 10-K for the fiscal year ended January 28, 2022.  These Condensed Consolidated Financial Statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“GAAP”).  In the opinion of management, the accompanying Condensed Consolidated Financial Statements reflect all adjustments of a normal recurring nature considered necessary to fairly state the financial position of the Company as of April 29, 2022 and January 28, 2022 and the results of its operations, corresponding comprehensive income, and its cash flows for the three months ended April 29, 2022 and April 30, 2021.


## us-gaap:ConsolidationPolicyTextBlock

[0001571996-22-000021:notes:2]
Principles of Consolidation — These Condensed Consolidated Financial Statements include the accounts of Dell Technologies Inc., its wholly-owned subsidiaries, and the accounts of SecureWorks Corp. (“Secureworks”), which is majority-owned by Dell Technologies.  All intercompany transactions have been eliminated.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001571996-22-000021:notes:3]
Recently Issued Accounting Pronouncements

[0001571996-22-000021:notes:4]
Accounting for Contract Assets and Contract Liabilities from Contracts with Customers — In October 2021, the Financial Accounting Standards Board (“FASB”) issued guidance which requires companies to apply Topic 606, Revenue from Contracts with Customers, to recognize and measure contract assets and contract liabilities from contracts with customers acquired in a business combination.  Public entities must adopt the new guidance for fiscal years beginning after December 15, 2022 and interim periods within those fiscal years, with early adoption permitted.  The Company is currently evaluating the impact and timing of adoption of this guidance.
Reference Rate Reform — In March 2020, the FASB issued guidance which provides temporary optional expedients and exceptions to GAAP guidance on contract modifications and certain hedging relationships to ease the financial reporting burdens related to the expected market transition from the London Interbank Offered Rate to alternative reference rates.  The Company may elect to apply the amendments prospectively through December 31, 2022.  Adoption of the new guidance is not expected to have a material impact on the Company’s financial results.


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001571996-22-000021:notes:5]
DISCONTINUED OPERATIONS
VMware Spin-Off —  As disclosed in Note 1 of the Notes to the Condensed Consolidated Financial Statements, on November 1, 2021, the Company completed its spin-off of VMware by means of a special stock dividend of 30,678,605 shares of Class A common stock and 307,221,836 shares of Class B common stock of VMware to Dell Technologies stockholders of record as of October 29, 2021.

[0001571996-22-000021:notes:6]
Prior to receipt of the VMware common stock by the Company’s stockholders, each share of VMware Class B common stock automatically converted into one share of VMware Class A common stock.  As a result of these transactions, each holder of record of shares of Dell Technologies common stock as of the distribution record date received approximately 0.440626 of a share of VMware Class A common stock for each share of Dell Technologies common stock held as of such date, based on shares outstanding as of the completion of the VMware Spin-off.  Following completion of the transaction, the pre-transaction stockholders of Dell Technologies owned shares in two separate public companies, consisting of (1) VMware, which continues to own the businesses of VMware, Inc. and its subsidiaries, and (2) Dell Technologies, which continues to own Dell Technologies’ other businesses and subsidiaries.  After the separation, Dell Technologies does not beneficially own any shares of VMware common stock.

[0001571996-22-000021:notes:7]
VMware paid a cash dividend, pro rata, to each of the holders of VMware common stock in an aggregate amount equal to $11.5 billion, of which Dell Technologies received $9.3 billion.  Following the payment by VMware to its stockholders, the separation of VMware from Dell Technologies occurred, including the termination or settlement of certain intercompany accounts and intercompany contracts.  Dell Technologies used the net proceeds from its pro rata share of the cash dividend to repay a portion of its outstanding debt.

[0001571996-22-000021:notes:8]
Dell Technologies determined that the VMware Spin-off, and related distributions, qualified as tax-free for U.S. federal income tax purposes, which required significant judgment by management.  In making these determinations, Dell Technologies applied U.S. federal tax law to relevant facts and circumstances and obtained a favorable private letter ruling from the Internal Revenue Service, a tax opinion, and other external tax advice related to the concluded tax treatment.  If the completed transactions were to fail to qualify for tax-free treatment for U.S. federal income tax purposes, the Company could be subject to significant liabilities, and there could be material adverse impacts on the Company’s business, financial condition, results of operations and cash flows in future reporting periods.

[0001571996-22-000021:notes:9]
In connection with and upon completion of the VMware Spin-off, Dell Technologies and VMware entered into various agreements that provide a framework for the relationship between the companies after the transaction, including, among others, a commercial framework agreement, a tax matters agreement, and a transition services agreement.

[0001571996-22-000021:notes:10]
The CFA referred to in Note 1 to the Notes to the Condensed Consolidated Financial Statements provides a framework under which the Company and VMware will continue their commercial relationship after the transaction, particularly with respect to projects mutually agreed by the parties as having the potential to accelerate the growth of an industry, product, service, or platform that may provide one or both companies with a strategic market opportunity.  The CFA has an initial term of five years, with automatic one-year renewals occurring annually thereafter, subject to certain terms and conditions.

[0001571996-22-000021:notes:11]
Pursuant to the CFA, Dell Technologies continues to act as a distributor of VMware’s standalone products and services and purchases such products and services for resale to end-user customers.  Dell Technologies also continues to integrate VMware’s products and services with Dell Technologies’ offerings and sell them to end users.  Cash flows between Dell and VMware primarily relate to such transactions.  The Company has determined that it is generally acting as principal in these arrangements.  The results of such operations are classified as continuing operations within the Company’s Condensed Consolidated Statements of Income.  See Note 16 of the Notes to the Condensed Consolidated Financial Statements for additional information regarding transactions between Dell Technologies and VMware.

[0001571996-22-000021:notes:12]
In accordance with applicable accounting guidance, the results of VMware, excluding Dell's resale of VMware offerings, are presented as discontinued operations in the Condensed Consolidated Statements of Income and, as such, have been excluded from both continuing operations and segment results for the three months ended April 30, 2021.  The Condensed Consolidated Statements of Cash Flows are presented on a consolidated basis for both continuing operations and discontinued operations.

[0001571996-22-000021:notes:13]
The tax matters agreement between the Company and VMware governs the respective rights, responsibilities, and obligations of Dell Technologies and VMware with respect to tax liabilities (including taxes, if any, incurred as a result of any failure of the VMware Spin-off to qualify for tax-free treatment for U.S. federal income tax purposes) and benefits, tax attributes, the preparation and filing of tax returns, the control of audits and other tax proceedings, cooperation, and other matters regarding tax.

[0001571996-22-000021:notes:14]
The transition services agreement between the Company and VMware governs the various administrative services which the Company will provide to VMware on an interim transitional basis.  Transition services may be provided for up to one year.

[0001571996-22-000021:notes:15]
The following table presents key components of “Income from discontinued operations, net of income taxes” for the three months ended April 30, 2021:

[0001571996-22-000021:notes:16]
|  |  | Three Months Ended (a) |  |  |
|  |  | April 30, 2021 |  |  |
|  |  | (in millions) |  |  |
| Net revenue |  | $ | 1,897 |  |  |  |
| Cost of net revenue |  | (497) |  |  |  |
| Operating expenses |  | 2,006 |  |  |  |
| Interest and other, net |  | 100 |  |  |  |
| Income from discontinued operations before income taxes |  | 288 |  |  |  |
| Income tax expense |  | 9 |  |  |  |
| Income from discontinued operations, net of income taxes |  | $ | 279 |  |  |  |

[0001571996-22-000021:notes:17]
____________________

[0001571996-22-000021:notes:18]
(a)    The table above reflects the offsetting effects of historical intercompany transactions which are presented on a gross basis within continuing operations on the Condensed Consolidated Statements of Income.

[0001571996-22-000021:notes:19]
The following table presents significant cash flow items from discontinued operations for the three months ended April 30, 2021 included within the Condensed Consolidated Statements of Cash Flows:

[0001571996-22-000021:notes:20]
|  |  | Three Months Ended |  |  |
|  |  | April 30, 2021 |  |  |
|  |  | (in millions) |  |  |
| Depreciation and amortization |  | $ | 333 |  |  |  |
| Capital expenditures |  | $ | 70 |  |  |  |
| Stock-based compensation expense |  | $ | 263 |  |  |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001571996-22-000021:notes:21]
FAIR VALUE MEASUREMENTS
The following table presents the Company’s hierarchy for its assets and liabilities measured at fair value on a recurring basis as of the dates indicated:

[0001571996-22-000021:notes:22]
|  | April 29, 2022 |  | January 28, 2022 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | Quoted Prices in Active Markets for Identical Assets |  | Significant Other Observable Inputs |  | Significant Unobservable Inputs |  |  |  | Quoted Prices in Active Markets for Identical Assets |  | Significant Other Observable Inputs |  | Significant Unobservable Inputs |  |  |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 1,977 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,977 |  |  | $ | 3,737 |  |  | $ | — |  |  | $ | — |  |  | $ | 3,737 |  |
| Marketable equity and other securities | 61 |  |  | — |  |  | — |  |  | 61 |  |  | 86 |  |  | — |  |  | — |  |  | 86 |  |
| Derivative instruments | — |  |  | 471 |  |  | — |  |  | 471 |  |  | — |  |  | 253 |  |  | — |  |  | 253 |  |
| Total assets | $ | 2,038 |  |  | $ | 471 |  |  | $ | — |  |  | $ | 2,509 |  |  | $ | 3,823 |  |  | $ | 253 |  |  | $ | — |  |  | $ | 4,076 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative instruments | $ | — |  |  | $ | 180 |  |  | $ | — |  |  | $ | 180 |  |  | $ | — |  |  | $ | 138 |  |  | $ | — |  |  | $ | 138 |  |
| Total liabilities | $ | — |  |  | $ | 180 |  |  | $ | — |  |  | $ | 180 |  |  | $ | — |  |  | $ | 138 |  |  | $ | — |  |  | $ | 138 |  |

[0001571996-22-000021:notes:23]
[same as prior period, unchanged from 0001571996-21-000063:notes:12]

[0001571996-22-000021:notes:24]
Money Market Funds — The Company’s investment in money market funds that are classified as cash equivalents hold underlying investments with a weighted average maturity of 90 days or less and are recognized at fair value.  The valuations of these securities are based on quoted prices in active markets for identical assets, when available, or pricing models whereby all significant inputs are observable or can be derived from or corroborated by observable market data.  The Company reviews security pricing and assesses liquidity on a quarterly basis.

[0001571996-22-000021:notes:25]
Marketable Equity and Other Securities — The majority of the Company’s investments in equity and other securities that are measured at fair value on a recurring basis consist of strategic investments in publicly-traded companies.  The valuation of these securities is based on quoted prices in active markets.

[0001571996-22-000021:notes:26]
Derivative Instruments — The Company’s derivative financial instruments consist primarily of foreign currency forward and purchased option contracts and interest rate swaps.  The fair value of the portfolio is determined using valuation models based on market observable inputs, including interest rate curves, forward and spot prices for currencies, and implied volatilities.  Credit risk is also factored into the fair value calculation of the Company’s derivative financial instrument portfolio.  See Note 8 of the Notes to the Condensed Consolidated Financial Statements for a description of the Company’s derivative financial instrument activities.

[0001571996-22-000021:notes:27]
Deferred Compensation Plans —The Company offers deferred compensation plans for eligible employees, which allow participants to defer a portion of their compensation.  Assets were the same as liabilities associated with the plans at approximately $187 million and $192 million as of April 29, 2022 and January 28, 2022, respectively, and are included in other assets and other liabilities on the Condensed Consolidated Statements of Financial Position.  The net impact to the Condensed Consolidated Statements of Income is not material since changes in the fair value of the assets substantially offset changes in the fair value of the liabilities.  As such, assets and liabilities associated with these plans have not been included in the recurring fair value table above.

[0001571996-22-000021:notes:28]
Assets and Liabilities Measured at Fair Value on a Nonrecurring Basis — Certain assets are measured at fair value on a nonrecurring basis and therefore are not included in the recurring fair value table above.  These assets consist primarily of non-financial assets such as goodwill and intangible assets.  See Note 9 of the Notes to the Condensed Consolidated Financial Statements for additional information about goodwill and intangible assets.

[0001571996-22-000021:notes:29]
As of April 29, 2022 and January 28, 2022, the Company held strategic investments in non-marketable equity and other securities of $1.5 billion and $1.4 billion, respectively.  As these investments represent early-stage companies without readily determinable fair values, they are not included in the recurring fair value table above.

[0001571996-22-000021:notes:30]
Carrying Value and Estimated Fair Value of Outstanding Debt — The following table presents the carrying value and estimated fair value of the Company’s outstanding debt as described in Note 7 of the Notes to the Condensed Consolidated Financial Statements, including the current portion, as of the dates indicated:

[0001571996-22-000021:notes:31]
|  | April 29, 2022 |  | January 28, 2022 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Notes | $ | 16.1 |  |  | $ | 16.7 |  |  | $ | 16.1 |  |  | $ | 18.5 |  |
| Legacy Notes and Debentures | $ | 0.8 |  |  | $ | 1.0 |  |  | $ | 0.8 |  |  | $ | 1.1 |  |

[0001571996-22-000021:notes:32]
The fair values of the outstanding debt shown in the table above, as well as the DFS debt described in Note 5 of the Notes to the Condensed Consolidated Financial Statements, were determined based on observable market prices in a less active market or based on valuation methodologies using observable inputs and were categorized as Level 2 in the fair value hierarchy.  The carrying value of DFS debt approximates fair value.


## us-gaap:InvestmentTextBlock

[0001571996-22-000021:notes:33]
INVESTMENTS
The Company has strategic investments in equity and other securities as well as investments in fixed-income debt securities.  As of April 29, 2022 and January 28, 2022, total investments were $1.9 billion and $1.8 billion, respectively.

[0001571996-22-000021:notes:34]
Equity and Other Securities

[0001571996-22-000021:notes:35]
Equity and other securities include strategic investments in marketable and non-marketable securities.  Investments in marketable securities are measured at fair value on a recurring basis.  The Company has elected to apply the measurement alternative for non-marketable securities.  Under the alternative, the Company measures investments without readily determinable fair values at cost, less impairment, adjusted by observable price changes.  The Company makes a separate election to use the alternative for each eligible investment and is required to reassess at each reporting period whether an investment qualifies for the alternative.  In evaluating these investments for impairment or observable price changes, the Company uses inputs including pre- and post-money valuations of recent financing events and the impact of those events on its fully diluted ownership percentages, as well as other available information regarding the issuer’s historical and forecasted performance.

[0001571996-22-000021:notes:36]
Carrying Value of Equity and Other Securities

[0001571996-22-000021:notes:37]
The following table presents the amortized cost, cumulative unrealized gains, cumulative unrealized losses, and carrying value of the Company's strategic investments in marketable and non-marketable equity securities as of the dates indicated:

[0001571996-22-000021:notes:38]
|  | April 29, 2022 |  | January 28, 2022 |
|  | Cost |  | Unrealized Gain |  | Unrealized Loss |  | Carrying Value |  | Cost |  | Unrealized Gain |  | Unrealized Loss |  | Carrying Value |
|  | (in millions) |
| Marketable | $ | 114 |  |  | $ | 78 |  |  | $ | (131) |  |  | $ | 61 |  |  | $ | 126 |  |  | $ | 79 |  |  | $ | (119) |  |  | $ | 86 |  |
| Non-marketable | 668 |  |  | 910 |  |  | (65) |  |  | 1,513 |  |  | 593 |  |  | 900 |  |  | (52) |  |  | 1,441 |  |
| Total equity and other securities | $ | 782 |  |  | $ | 988 |  |  | $ | (196) |  |  | $ | 1,574 |  |  | $ | 719 |  |  | $ | 979 |  |  | $ | (171) |  |  | $ | 1,527 |  |

[0001571996-22-000021:notes:39]
Gains and Losses on Equity and Other Securities

[0001571996-22-000021:notes:40]
The following table presents unrealized gains and losses on marketable and non-marketable equity and other securities for the periods indicated:

[0001571996-22-000021:notes:41]
|  | April 29, 2022 |  | April 30, 2021 |
|  | (in millions) |
| Marketable securities |  |  |  |
| Unrealized gain | $ | — |  |  | $ | 16 |  |
| Unrealized loss | (18) |  |  | (8) |  |
| Net unrealized gain (loss) | (18) |  |  | 8 |  |
| Non-marketable securities |  |  |  |
| Unrealized gain | 21 |  |  | 182 |  |
| Unrealized loss | — |  |  | (77) |  |
| Net unrealized gain (a) | 21 |  |  | 105 |  |
| Total net gain on equity and other securities | $ | 3 |  |  | $ | 113 |  |

[0001571996-22-000021:notes:42]
(a)    For all periods presented, net gains on non-marketable securities are due to upward adjustments for observable price changes offset by losses primarily attributable to impairments.

[0001571996-22-000021:notes:43]
Fixed Income Debt Securities

[0001571996-22-000021:notes:44]
The Company has fixed income debt securities carried at amortized cost which are held as collateral for borrowings.  The Company intends to hold the investments to maturity.

[0001571996-22-000021:notes:45]
The following table summarizes the Company’s debt securities as of the dates indicated:

[0001571996-22-000021:notes:46]
|  | April 29, 2022 |  | January 28, 2022 |
|  | Amortized Cost |  | Unrealized Gains |  | Unrealized Loss |  | Carrying Value |  | Amortized Cost |  | Unrealized Gains |  | Unrealized Loss |  | Carrying Value |
|  | (in millions) |
| Fixed income debt securities | $ | 334 |  |  | $ | 28 |  |  | $ | (68) |  |  | $ | 294 |  |  | $ | 333 |  |  | $ | 26 |  |  | $ | (47) |  |  | $ | 312 |  |


## dell:CreditLossFinancialInstrumentLeasesDebtVariableInterestEntitiesAndCustomerReceivablesSalesTextBlock

[0001571996-22-000021:notes:47]
FINANCIAL SERVICES
The Company offers or arranges various financing options and services and alternative payment structures for its customers globally primarily through Dell Financial Services and its affiliates (“DFS”).  The Company also arranges financing for some of its customers in various countries where DFS does not currently operate as a captive enterprise.  The key activities of DFS include originating, collecting, and servicing customer financing arrangements primarily related to the purchase or use of Dell Technologies products and services.  In some cases, DFS also offers financing for the purchase of third-party technology products that complement the Dell Technologies portfolio of products and services.  New financing originations were $2.1 billion and $1.9 billion for the three months ended April 29, 2022 and April 30, 2021, respectively.

[0001571996-22-000021:notes:48]
The Company’s lease and loan arrangements with customers are aggregated primarily into the following categories:

[0001571996-22-000021:notes:49]
Revolving loans — Revolving loans offered under private label credit financing programs provide qualified customers with a revolving credit line for the purchase of products and services offered by Dell Technologies.  These private label credit financing programs are referred to as Dell Preferred Account (“DPA”) and Dell Business Credit (“DBC”).  The DPA product is primarily offered to individual consumer customers, and the DBC product is primarily offered to small and medium-sized commercial customers.  Revolving loans in the United States bear interest at a variable annual percentage rate that is tied to the prime rate.  Based on historical payment patterns, revolving loan transactions are typically repaid within twelve months on average.  Due to the short-term nature of the revolving loan portfolio, the carrying value of the portfolio approximates fair value.

[0001571996-22-000021:notes:50]
Fixed-term leases and loans — The Company enters into financing arrangements with customers who seek lease financing for equipment.  DFS leases are generally classified as sales-type leases or operating leases.  Leases with business customers have fixed terms of generally two to four years.

[0001571996-22-000021:notes:51]
The Company also offers fixed-term loans to qualified small businesses, large commercial accounts, governmental organizations, educational entities, and certain individual consumer customers.  These loans are repaid in equal payments including interest and have defined terms of generally three to five years.  The fair value of the fixed-term loan portfolio is determined using market observable inputs.  The carrying value of these loans approximates fair value.

[0001571996-22-000021:notes:52]
The Company further strengthens customer relationships through flexible consumption models, which enable the Company to offer its customers the option to pay over time and, in certain cases, based on utilization, to provide them with financial flexibility to meet their changing technological requirements.

[0001571996-22-000021:notes:53]
Financing Receivables

[0001571996-22-000021:notes:54]
The following table presents the components of the Company’s financing receivables segregated by portfolio segment as of the dates indicated:

[0001571996-22-000021:notes:55]
|  | April 29, 2022 |  | January 28, 2022 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Financing receivables, net: |  |  |  |  |  |  |  |  |  |  |  |
| Customer receivables, gross (a) | $ | 716 |  |  | $ | 9,483 |  |  | $ | 10,199 |  |  | $ | 750 |  |  | $ | 9,833 |  |  | $ | 10,583 |  |
| Allowances for losses | (94) |  |  | (87) |  |  | (181) |  |  | (102) |  |  | (87) |  |  | (189) |  |
| Customer receivables, net | 622 |  |  | 9,396 |  |  | 10,018 |  |  | 648 |  |  | 9,746 |  |  | 10,394 |  |
| Residual interest | — |  |  | 176 |  |  | 176 |  |  | — |  |  | 217 |  |  | 217 |  |
| Financing receivables, net | $ | 622 |  |  | $ | 9,572 |  |  | $ | 10,194 |  |  | $ | 648 |  |  | $ | 9,963 |  |  | $ | 10,611 |  |
| Short-term | $ | 622 |  |  | $ | 4,174 |  |  | $ | 4,796 |  |  | $ | 648 |  |  | $ | 4,441 |  |  | $ | 5,089 |  |
| Long-term | $ | — |  |  | $ | 5,398 |  |  | $ | 5,398 |  |  | $ | — |  |  | $ | 5,522 |  |  | $ | 5,522 |  |

[0001571996-22-000021:notes:56]
(a)    Customer receivables, gross include amounts due from customers under revolving loans, fixed-term loans, fixed-term sales-type or direct financing leases, and accrued interest.

[0001571996-22-000021:notes:57]
The following table presents the changes in allowance for financing receivable losses for the periods indicated:

[0001571996-22-000021:notes:58]
|  | Three Months Ended |
|  | April 29, 2022 |  | April 30, 2021 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |  |  |  |  |  |  |  |  |  |  |  |
| Balances at beginning of period | $ | 102 |  |  | $ | 87 |  |  | $ | 189 |  |  | $ | 148 |  |  | $ | 173 |  |  | $ | 321 |  |
| Charge-offs, net of recoveries | (13) |  |  | (2) |  |  | (15) |  |  | (13) |  |  | (2) |  |  | (15) |  |
| Provision charged to income statement | 5 |  |  | 2 |  |  | 7 |  |  | 4 |  |  | 6 |  |  | 10 |  |
| Balances at end of period | $ | 94 |  |  | $ | 87 |  |  | $ | 181 |  |  | $ | 139 |  |  | $ | 177 |  |  | $ | 316 |  |

[0001571996-22-000021:notes:59]
Aging

[0001571996-22-000021:notes:60]
The following table presents the aging of the Company’s customer financing receivables, gross, including accrued interest, segregated by class, as of the dates indicated:

[0001571996-22-000021:notes:61]
|  | April 29, 2022 |  | January 28, 2022 |
|  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |
|  | (in millions) |
| Revolving — DPA | $ | 488 |  |  | $ | 35 |  |  | $ | 12 |  |  | $ | 535 |  |  | $ | 520 |  |  | $ | 40 |  |  | $ | 11 |  |  | $ | 571 |  |
| Revolving — DBC | 164 |  |  | 14 |  |  | 3 |  |  | 181 |  |  | 158 |  |  | 18 |  |  | 3 |  |  | 179 |  |
| Fixed-term — Consumer and Commercial | 8,962 |  |  | 485 |  |  | 36 |  |  | 9,483 |  |  | 9,444 |  |  | 345 |  |  | 44 |  |  | 9,833 |  |
| Total customer receivables, gross | $ | 9,614 |  |  | $ | 534 |  |  | $ | 51 |  |  | $ | 10,199 |  |  | $ | 10,122 |  |  | $ | 403 |  |  | $ | 58 |  |  | $ | 10,583 |  |

[0001571996-22-000021:notes:62]
Aging is likely to fluctuate as a result of the variability in volume of large transactions entered into over the period, and the administrative processes that accompany those transactions.  Aging is also impacted by the timing of the Dell Technologies

[0001571996-22-000021:notes:63]
fiscal period end date relative to calendar month-end customer payment due dates.  As a result of these factors, fluctuations in aging from period to period do not necessarily indicate a material change in the collectibility of the portfolio.

[0001571996-22-000021:notes:64]
Fixed-term consumer and commercial customer receivables are placed on non-accrual status if principal or interest is past due and considered delinquent, or if there is concern about collectibility of a specific customer receivable.  The receivables identified as doubtful for collectibility may be classified as current for aging purposes.  Aged revolving portfolio customer receivables identified as delinquent are charged off.

[0001571996-22-000021:notes:65]
Credit Quality

[0001571996-22-000021:notes:66]
The following tables present customer receivables, gross, including accrued interest, by credit quality indicator segregated by class, as of the dates indicated:

[0001571996-22-000021:notes:67]
|  | April 29, 2022 |
|  | Fixed-term — Consumer and Commercial |  |  |  |  |  |  |
|  | Fiscal Year of Origination |  |  |  |  |  |  |
|  | 2023 |  | 2022 |  | 2021 |  | 2020 |  | 2019 |  | Years Prior |  | Revolving — DPA |  | Revolving — DBC |  | Total |
|  | (in millions) |
| Higher | $ | 1,223 |  |  | $ | 2,587 |  |  | $ | 1,450 |  |  | $ | 695 |  |  | $ | 145 |  |  | $ | 15 |  |  | $ | 132 |  |  | $ | 46 |  |  | $ | 6,293 |  |
| Mid | 345 |  |  | 866 |  |  | 621 |  |  | 235 |  |  | 64 |  |  | 8 |  |  | 155 |  |  | 57 |  |  | 2,351 |  |
| Lower | 179 |  |  | 505 |  |  | 369 |  |  | 142 |  |  | 29 |  |  | 5 |  |  | 248 |  |  | 78 |  |  | 1,555 |  |
| Total | $ | 1,747 |  |  | $ | 3,958 |  |  | $ | 2,440 |  |  | $ | 1,072 |  |  | $ | 238 |  |  | $ | 28 |  |  | $ | 535 |  |  | $ | 181 |  |  | $ | 10,199 |  |

[0001571996-22-000021:notes:68]
|  | January 28, 2022 |
|  | Fixed-term — Consumer and Commercial |  |  |  |  |  |  |
|  | Fiscal Year of Origination |  |  |  |  |  |  |
|  | 2022 |  | 2021 |  | 2020 |  | 2019 |  | 2018 |  | Years Prior |  | Revolving — DPA |  | Revolving — DBC |  | Total |
|  | (in millions) |
| Higher | $ | 3,279 |  |  | $ | 1,824 |  |  | $ | 914 |  |  | $ | 221 |  |  | $ | 25 |  |  | $ | 3 |  |  | $ | 150 |  |  | $ | 46 |  |  | $ | 6,462 |  |
| Mid | 1,071 |  |  | 751 |  |  | 329 |  |  | 94 |  |  | 17 |  |  | — |  |  | 166 |  |  | 57 |  |  | 2,485 |  |
| Lower | 599 |  |  | 450 |  |  | 208 |  |  | 42 |  |  | 6 |  |  | — |  |  | 255 |  |  | 76 |  |  | 1,636 |  |
| Total | $ | 4,949 |  |  | $ | 3,025 |  |  | $ | 1,451 |  |  | $ | 357 |  |  | $ | 48 |  |  | $ | 3 |  |  | $ | 571 |  |  | $ | 179 |  |  | $ | 10,583 |  |

[0001571996-22-000021:notes:69]
The categories shown in the tables above segregate customer receivables based on the relative degrees of credit risk.  The credit quality indicators for DPA revolving accounts are measured primarily as of each quarter-end date, while all other indicators are generally updated on a periodic basis.

[0001571996-22-000021:notes:70]
For DPA revolving receivables shown in the table above, the Company makes credit decisions based on proprietary scorecards, which include the customer’s credit history, payment history, credit usage, and other credit agency-related elements.  The higher quality category includes prime accounts generally of a higher credit quality that are comparable to U.S. customer FICO scores of 720 or above.  The mid-category represents the mid-tier accounts that are comparable to U.S. customer FICO scores from 660 to 719.  The lower category is generally sub-prime and represents lower credit quality accounts that are comparable to U.S. customer FICO scores below 660.  For the DBC revolving receivables and fixed-term commercial receivables shown in the table above, an internal grading system is utilized that assigns a credit level score based on a number of considerations, including liquidity, operating performance, and industry outlook.  The grading criteria and classifications for the fixed-term products differ from those for the revolving products as loss experience varies between these product and customer groups.  The credit quality categories cannot be compared between the different classes as loss experience varies substantially between the classes.

[0001571996-22-000021:notes:71]
Leases

[0001571996-22-000021:notes:72]
The following table presents the net revenue, cost of net revenue, and gross margin recognized at the commencement date of sales-type leases for the periods indicated:

[0001571996-22-000021:notes:73]
|  | Three Months Ended |
|  | April 29, 2022 |  | April 30, 2021 |
|  | (in millions) |
| Net revenue — products | $ | 220 |  |  | $ | 230 |  |
| Cost of net revenue — products | 204 |  |  | 163 |  |
| Gross margin — products | $ | 16 |  |  | $ | 67 |  |

[0001571996-22-000021:notes:74]
The following table presents the future maturity of the Company’s fixed-term customer leases and associated financing payments, and reconciles the undiscounted cash flows to the customer receivables, gross recognized on the Condensed Consolidated Statements of Financial Position as of the date indicated:

[0001571996-22-000021:notes:75]
|  | April 29, 2022 |
|  | (in millions) |
| Fiscal 2023 (remaining nine months) | $ | 1,876 |  |
| Fiscal 2024 | 1,721 |  |
| Fiscal 2025 | 1,050 |  |
| Fiscal 2026 | 474 |  |
| Fiscal 2027 and beyond | 144 |  |
| Total undiscounted cash flows | 5,265 |  |
| Fixed-term loans | 4,814 |  |
| Revolving loans | 716 |  |
| Less: Unearned income | (596) |  |
| Total customer receivables, gross | $ | 10,199 |  |

[0001571996-22-000021:notes:76]
Operating Leases

[0001571996-22-000021:notes:77]
The following table presents the components of the Company’s operating lease portfolio included in property, plant, and equipment, net as of the dates indicated:

[0001571996-22-000021:notes:78]
|  | April 29, 2022 |  | January 28, 2022 |
|  | (in millions) |
| Equipment under operating lease, gross | $ | 2,942 |  |  | $ | 2,643 |  |
| Less: Accumulated depreciation | (1,076) |  |  | (935) |  |
| Equipment under operating lease, net | $ | 1,866 |  |  | $ | 1,708 |  |

[0001571996-22-000021:notes:79]
The following table presents operating lease income related to lease payments and depreciation expense for the Company’s operating lease portfolio for the periods indicated:

[0001571996-22-000021:notes:80]
|  | Three Months Ended |
|  | April 29, 2022 |  | April 30, 2021 |
|  | (in millions) |
| Income related to lease payments | $232 |  | $156 |
| Depreciation expense | $165 |  | $116 |

[0001571996-22-000021:notes:81]
The following table presents the future payments to be received by the Company as lessor in operating lease contracts as of the date indicated:

[0001571996-22-000021:notes:82]
|  | April 29, 2022 |
|  | (in millions) |
| Fiscal 2023 (remaining nine months) | $ | 663 |  |
| Fiscal 2024 | 650 |  |
| Fiscal 2025 | 397 |  |
| Fiscal 2026 | 122 |  |
| Fiscal 2027 and beyond | 32 |  |
| Total | $ | 1,864 |  |

[0001571996-22-000021:notes:83]
DFS Debt

[0001571996-22-000021:notes:84]
The Company maintains programs that facilitate the funding of leases, loans, and other alternative payment structures in the capital markets.  The majority of DFS debt is non-recourse to Dell Technologies and represents borrowings under securitization programs and structured financing programs, for which the Company’s risk of loss is limited to transferred loan and lease payments and associated equipment.

[0001571996-22-000021:notes:85]
The following table presents DFS debt as of the dates indicated and excludes the allocated portion of the Company’s other borrowings, which represents the additional amount considered to fund the DFS business:

[0001571996-22-000021:notes:86]
|  | April 29, 2022 |  | January 28, 2022 |
| DFS debt | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing and securitization facilities | $ | 2,720 |  |  | $ | 3,054 |  |
| Fixed-term securitization offerings | 3,607 |  |  | 3,011 |  |
| Other | 125 |  |  | 135 |  |
| Total DFS U.S. debt | 6,452 |  |  | 6,200 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 730 |  |  | 739 |  |
| Other borrowings | 818 |  |  | 785 |  |
| Note payable | 250 |  |  | 250 |  |
| Dell Bank senior unsecured eurobonds | 1,575 |  |  | 1,672 |  |
| Total DFS international debt | 3,373 |  |  | 3,446 |  |
| Total DFS debt | $ | 9,825 |  |  | $ | 9,646 |  |
| Total short-term DFS debt | $ | 5,907 |  |  | $ | 5,803 |  |
| Total long-term DFS debt | $ | 3,918 |  |  | $ | 3,843 |  |

[0001571996-22-000021:notes:87]
DFS U.S. Debt

[0001571996-22-000021:notes:88]
Asset-Based Financing and Securitization Facilities — The Company maintains separate asset-based financing facilities and a securitization facility in the United States, which are revolving facilities for fixed-term leases and loans and for revolving loans, respectively.  This debt is collateralized solely by the U.S. loan and lease payments and associated equipment in the facilities.  The debt has a variable interest rate and the duration of the debt is based on the terms of the underlying loan and lease payment streams.  As of April 29, 2022, the total debt capacity related to the U.S. asset-based financing and securitization facilities was $4.5 billion.  The Company enters into interest swap agreements to effectively convert a portion of this debt from a floating rate to a fixed rate.  See Note 8 of the Notes to the Condensed Consolidated Financial Statements for additional information about interest rate swaps.

[0001571996-22-000021:notes:89]
The Company’s U.S. securitization facility for revolving loans is effective through June 25, 2025.  The Company’s two U.S. asset-based financing facilities for fixed-term leases and loans are effective through July 10, 2023 and July 26, 2022, respectively.

[0001571996-22-000021:notes:90]
The asset-based financing and securitization facilities contain standard structural features related to the performance of the funded receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the facility, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of April 29, 2022, these criteria were met.

[0001571996-22-000021:notes:91]
Fixed-Term Securitization Offerings — The Company periodically issues asset-backed debt securities under fixed-term securitization programs to private investors.  The asset-backed debt securities are collateralized solely by the U.S. fixed-term leases and loans in the offerings, which are held by Special Purpose Entities (“SPEs”), as discussed below.  The interest rate on these securities is fixed and ranges from 0.18% to 5.92% per annum, and the duration of these securities is based on the terms of the underlying lease and loan payment streams.

[0001571996-22-000021:notes:92]
DFS International Debt

[0001571996-22-000021:notes:93]
Securitization Facility — The Company maintains a securitization facility in Europe for fixed-term leases and loans.  This facility is effective through December 21, 2022 and had a total debt capacity of $840 million as of April 29, 2022.

[0001571996-22-000021:notes:94]
The securitization facility contains standard structural features related to the performance of the securitized receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the program, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of April 29, 2022, these criteria were met.

[0001571996-22-000021:notes:95]
Other Borrowings — In connection with the Company’s international financing operations, the Company has entered into revolving structured financing debt programs related to its fixed-term lease and loan products sold in Canada, Europe, Australia, and New Zealand.  The Canadian facility, which is collateralized solely by Canadian loan and lease payments and associated equipment, had a total debt capacity of $351 million as of April 29, 2022 and is effective through January 16, 2025.  The European facility, which is collateralized solely by European loan and lease payments and associated equipment, had a total debt capacity of $630 million as of April 29, 2022 and is effective through December 14, 2023.  The Australia and New Zealand facility, which is collateralized solely by Australia and New Zealand loan and lease payments and associated equipment, had a total debt capacity of $319 million as of April 29, 2022 and is effective through April 20, 2023.

[0001571996-22-000021:notes:96]
Note Payable —On August 7, 2020, the Company entered into two unsecured credit agreements to fund receivables in Mexico.  As of April 29, 2022, the aggregate principal amount of the notes payable was $250 million.  The notes bear interest at an annual rate of 3.37% and will mature on June 1, 2022.

[0001571996-22-000021:notes:97]
Dell Bank Senior Unsecured Eurobonds  — On October 17, 2019, Dell Bank International D.A.C. (“Dell Bank”) issued 500 million Euro of 0.625% senior unsecured three year eurobonds due October 2022.  On June 24, 2020, Dell Bank issued 500 million Euro of 1.625% senior unsecured four year eurobonds due June 2024.  On October 27, 2021, Dell Bank issued 500 million Euro of 0.5% senior unsecured five year eurobonds due October 2026.  The issuance of the senior unsecured eurobonds support the expansion of the financing operations in Europe.

[0001571996-22-000021:notes:98]
Variable Interest Entities

[0001571996-22-000021:notes:99]
In connection with the asset-based financing facilities, securitization facilities, and fixed-term securitization offerings discussed above, the Company transfers certain U.S. and European lease and loan payments and associated equipment to SPEs that meet the definition of a Variable Interest Entity (“VIE”) and are consolidated, along with the associated debt detailed above, into the Condensed Consolidated Financial Statements, as the Company is the primary beneficiary of the VIEs.  The SPEs are bankruptcy-remote legal entities with separate assets and liabilities.  The purpose of the SPEs is to facilitate the funding of customer loan and lease payments and associated equipment in the capital markets.

[0001571996-22-000021:notes:100]
Some of the SPEs have entered into financing arrangements with multi-seller conduits that, in turn, issue asset-backed debt securities in the capital markets.  DFS debt outstanding held by the consolidated VIEs is collateralized by the lease and loan payments and associated equipment.  The Company’s risk of loss related to securitized receivables is limited to the amount by which the Company’s right to receive collections for assets securitized exceeds the amount required to pay interest, principal, and fees and expenses related to the asset-backed securities.  The Company provides credit enhancement to the securitization in the form of over-collateralization.

[0001571996-22-000021:notes:101]
The following table presents the assets and liabilities held by the consolidated VIEs as of the dates indicated, which are included in the Condensed Consolidated Statements of Financial Position:

[0001571996-22-000021:notes:102]
|  | April 29, 2022 |  | January 28, 2022 |
|  | (in millions) |
| Assets held by consolidated VIEs |  |  |  |
| Other current assets | $ | 547 |  |  | $ | 535 |  |
| Financing receivables, net of allowance |  |  |  |
| Short-term | $ | 3,376 |  |  | $ | 3,368 |  |
| Long-term | $ | 3,270 |  |  | $ | 3,141 |  |
| Property, plant, and equipment, net | $ | 1,030 |  |  | $ | 945 |  |
| Liabilities held by consolidated VIEs |  |  |  |
| Debt, net of unamortized debt issuance costs |  |  |  |
| Short-term | $ | 4,545 |  |  | $ | 4,560 |  |
| Long-term | $ | 2,500 |  |  | $ | 2,235 |  |

[0001571996-22-000021:notes:103]
Lease and loan payments and associated equipment transferred via securitization through SPEs were $1.7 billion and $1.4 billion for the three months ended April 29, 2022 and April 30, 2021, respectively.

[0001571996-22-000021:notes:104]
Customer Receivable Sales

[0001571996-22-000021:notes:105]
To manage certain concentrations of customer credit exposure, the Company may sell selected fixed-term customer receivables to unrelated third parties on a periodic basis, without recourse.  The amount of customer receivables sold for this purpose was $148 million and $101 million for the three months ended April 29, 2022 and April 30, 2021, respectively.  The Company’s continuing involvement in these customer receivables is primarily limited to servicing arrangements.


## us-gaap:ScheduleOfDebtTableTextBlock

[0001571996-22-000021:notes:106]
The majority of DFS debt is non-recourse to Dell Technologies and represents borrowings under securitization programs and structured financing programs, for which the Company’s risk of loss is limited to transferred loan and lease payments and associated equipment.  
The following table presents DFS debt as of the dates indicated and excludes the allocated portion of the Company’s other borrowings, which represents the additional amount considered to fund the DFS business:

[0001571996-22-000021:notes:107]
The following table summarizes the Company’s outstanding debt as of the dates indicated:

[0001571996-22-000021:notes:108]
|  | April 29, 2022 |  | January 28, 2022 |
|  | (in millions) |
| Senior Notes: |  |  |  |
| 5.45% due June 2023 | 1,000 |  |  | 1,000 |  |
| 4.00% due July 2024 | 1,000 |  |  | 1,000 |  |
| 5.85% due July 2025 | 1,000 |  |  | 1,000 |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 4.90% due October 2026 | 1,750 |  |  | 1,750 |  |
| 6.10% due July 2027 | 500 |  |  | 500 |  |
| 5.30% due October 2029 | 1,750 |  |  | 1,750 |  |
| 6.20% due July 2030 | 750 |  |  | 750 |  |
| 8.10% due July 2036 | 1,000 |  |  | 1,000 |  |
| 3.38% due December 2041 | 1,000 |  |  | 1,000 |  |
| 8.35% due July 2046 | 800 |  |  | 800 |  |
| 3.45% due December 2051 | 1,250 |  |  | 1,250 |  |
| Legacy Notes and Debentures: |  |  |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| DFS Debt (Note 5) | 9,825 |  |  | 9,646 |  |
| Other | 320 |  |  | 337 |  |
| Total debt, principal amount | $ | 27,397 |  |  | $ | 27,235 |  |
| Unamortized discount, net of unamortized premium | (131) |  |  | (134) |  |
| Debt issuance costs | (144) |  |  | (147) |  |
| Total debt, carrying value | $ | 27,122 |  |  | $ | 26,954 |  |
| Total short-term debt, carrying value | $ | 5,925 |  |  | $ | 5,823 |  |
| Total long-term debt, carrying value | $ | 21,197 |  |  | $ | 21,131 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0001571996-22-000021:notes:109]
LEASES 
The Company enters into leasing transactions in which the Company is the lessee.  These lease contracts are typically classified as operating leases.  The Company’s lease contracts are generally for office buildings used to conduct its business, and the determination of whether such contracts contain leases generally does not require significant estimates or judgments.  The Company also leases certain global logistics warehouses, employee vehicles, and equipment.  As of April 29, 2022, the remaining terms of the Company’s leases range from less than one month to approximately ten years.

[0001571996-22-000021:notes:110]
The Company also enters into leasing transactions in which the Company is the lessor, primarily through customer financing arrangements offered through DFS.  DFS originates leases that are primarily classified as either sales-type leases or operating leases.  See Note 5 of the Notes to the Condensed Consolidated Financial Statements for more information on the DFS lease portfolio and related lease disclosures.

[0001571996-22-000021:notes:111]
Financial information associated with the Company’s leases in which the Company is the lessee is contained in this Note.  As of April 29, 2022 and January 28, 2022, there were no material finance leases for which the Company was a lessee.

[0001571996-22-000021:notes:112]
[same as prior period, unchanged from 0001571996-21-000063:notes:97]

[0001571996-22-000021:notes:113]
|  | Three Months Ended |
|  | April 29, 2022 |  | April 30, 2021 |
|  | (in millions) |
| Operating lease costs | $ | 72 |  |  | $ | 94 |  |
| Variable costs | 25 |  |  | 26 |  |
| Total lease costs | $ | 97 |  |  | $ | 120 |  |

[0001571996-22-000021:notes:114]
During the three months ended April 29, 2022 and April 30, 2021, sublease income, finance lease costs, and short-term lease costs were immaterial.

[0001571996-22-000021:notes:115]
[same as prior period, unchanged from 0001571996-21-000063:notes:100]

[0001571996-22-000021:notes:116]
|  | Classification | April 29, 2022 |  | January 28, 2022 |  |  |
|  |  | (in millions, except for term and discount rate) |
| Operating lease right-of-use assets | Other non-current assets | $ | 837 |  | $ | 871 |  |  |
| Current operating lease liabilities | Accrued and other current liabilities | $ | 273 |  | $ | 287 |  |  |
| Non-current operating lease liabilities | Other non-current liabilities | 687 |  | 720 |  |  |
| Total operating lease liabilities |  | $ | 960 |  | $ | 1,007 |  |  |
| Weighted-average remaining lease term (in years) |  | 5.43 |  | 5.51 |  |  |
| Weighted-average discount rate |  | 2.97 | % |  | 3.01 | % |  |  |

[0001571996-22-000021:notes:117]
[same as prior period, unchanged from 0001571996-21-000063:notes:102]

[0001571996-22-000021:notes:118]
|  | Three Months Ended |
|  | April 29, 2022 |  | April 30, 2021 |
|  | (in millions) |
| Cash paid for amounts included in the measurement of lease liabilities — operating cash outflows from operating leases (a) | $ | 80 |  |  | $ | 134 |  |
| Right-of-use assets obtained in exchange for new operating lease liabilities | $ | 72 |  |  | $ | 97 |  |

[0001571996-22-000021:notes:119]
(a) Cash paid for amounts included in the measurement of lease liabilities - operating cash outflows from operating leases from discontinued operations was $50 million for the three months ended April 30, 2021.

[0001571996-22-000021:notes:120]
The following table presents the future maturity of the Company’s operating lease liabilities under non-cancelable leases and reconciles the undiscounted cash flows for these leases to the lease liability recognized on the Condensed Consolidated Statements of Financial Position as of the date indicated:

[0001571996-22-000021:notes:121]
|  | April 29, 2022 |  |  |
|  | (in millions) |
| Fiscal 2023 (remaining nine months) | $ | 209 |  |  |  |
| Fiscal 2024 | 225 |  |  |  |
| Fiscal 2025 | 160 |  |  |  |
| Fiscal 2026 | 128 |  |  |  |
| Fiscal 2027 | 105 |  |  |  |
| Thereafter | 215 |  |  |  |
| Total lease payments | 1,042 |  |  |  |
| Less: Imputed interest | (82) |  |  |  |
| Total | $ | 960 |  |  |  |
| Current operating lease liabilities | $ | 273 |  |  |  |
| Non-current operating lease liabilities | $ | 687 |  |  |  |

[0001571996-22-000021:notes:122]
As of April 29, 2022, the Company’s undiscounted operating leases that had not yet commenced were immaterial.


## us-gaap:DebtDisclosureTextBlock

[0001571996-22-000021:notes:123]
DEBT
The following table summarizes the Company’s outstanding debt as of the dates indicated:

[0001571996-22-000021:notes:124]
Outstanding Debt

[0001571996-22-000021:notes:125]
Senior Notes — The Company completed private offerings of multiple series of senior notes which were issued on June 1, 2016, June 22, 2016, March 20, 2019, April 9, 2020, and December 13, 2021 in aggregate principal amounts of $20.0 billion, $3.3 billion, $4.5 billion, $2.3 billion, and $2.3 billion respectively (the “Senior Notes”).  Interest on these borrowings is payable semiannually.

[0001571996-22-000021:notes:126]
In June 2021, Dell International L.L.C. and EMC Corporation, wholly-owned subsidiaries of Dell Technologies and issuers of the Senior Notes (the “Issuers”), completed offers to exchange any and all outstanding Senior Notes issued on June 1, 2016, March 20, 2019, and April 9, 2020 for senior notes registered under the Securities Act of 1933 having terms substantially identical to the terms of the outstanding Senior Notes.  The Issuers issued $18.4 billion aggregate principal amount of registered senior notes in exchange for the same aggregate principal amount of Senior Notes.  The aggregate principal amount of unregistered Senior Notes remaining outstanding following the settlement of the exchange offers was approximately $0.1 billion.

[0001571996-22-000021:notes:127]
Legacy Notes and Debentures — The Company has outstanding unsecured notes and debentures (collectively, the “Legacy Notes and Debentures”) that were issued by Dell prior to the acquisition of Dell Inc. by Dell Technologies Inc. in the going-private transaction that closed in October 2013.  Interest on these borrowings is payable semiannually.

[0001571996-22-000021:notes:128]
DFS Debt — See Note 5 and Note 8 of the Notes to the Condensed Consolidated Financial Statements, respectively, for discussion of DFS debt and the interest rate swap agreements that hedge a portion of that debt.

[0001571996-22-000021:notes:129]
2021 Revolving Credit Facility  — The 2021 Revolving Credit Facility, which was entered into on November 1, 2021, matures on November 1, 2026, This facility provides the Company with revolving commitments in an aggregate principal amount of $5.0 billion for general corporate purposes and includes a letter of credit sub-facility of up to $0.5 billion and a swing-line loan sub-facility of up to $0.5 billion.  The 2021 Revolving Credit Facility also allows the Company to obtain incremental additional commitments on one or more occasions in minimum amounts of $10 million.

[0001571996-22-000021:notes:130]
The Company may conduct borrowings under the 2021 Revolving Credit Facility through London Interbank Offered Rate (“LIBOR”) borrowings or Base Rate Loan borrowings.  LIBOR borrowings bear interest at a rate per annum equal to the LIBOR, plus an applicable rate that varies based upon the Company’s existing debt ratings (the “applicable rate”).  Base Rate Loan borrowings bear interest at a rate per annum equal to the base rate plus the applicable rate.  The base rate is calculated based upon the greatest of the specified prime rate, the specified federal reserve bank rate, or LIBOR plus 1%.

[0001571996-22-000021:notes:131]
The borrowers may voluntarily repay outstanding loans under the 2021 Revolving Credit Facility at any time without premium or penalty, other than customary breakage costs.

[0001571996-22-000021:notes:132]
As of April 29, 2022, available borrowings under the 2021 Revolving Credit Facility totaled $5.0 billion.

[0001571996-22-000021:notes:133]
Covenants — The credit agreement governing the 2021 Revolving Credit Facility and the indentures governing the Senior Notes and the Legacy Notes and Debentures variously impose limitations, subject to exceptions, on creating certain liens and entering into sale and lease-back transactions.  The foregoing credit agreement and indentures contain customary events of default, including failure to make required payments, failure to comply with covenants, and the occurrence of certain events of bankruptcy and insolvency.  The 2021 Revolving Credit Facility is also subject to an interest coverage ratio covenant that is tested at the end of each fiscal quarter with respect to the Company’s preceding four fiscal quarters.  The Company was in compliance with this financial covenant as of April 29, 2022.

[0001571996-22-000021:notes:134]
Aggregate Future Maturities

[0001571996-22-000021:notes:135]
The following tables presents the aggregate future maturities of the Company’s debt as of April 29, 2022 for the periods indicated:

[0001571996-22-000021:notes:136]
|  | Maturities by Fiscal Year |
|  | 2023 (remaining nine months) |  | 2024 |  | 2025 |  | 2026 |  | 2027 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Notes | $ | — |  |  | $ | 1,000 |  |  | $ | 1,000 |  |  | $ | 1,000 |  |  | $ | 6,250 |  |  | $ | 7,050 |  |  | $ | 16,300 |  |
| Legacy Notes and Debentures | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 952 |  |  | 952 |  |
| DFS Debt | 5,201 |  |  | 2,612 |  |  | 1,294 |  |  | 165 |  |  | 550 |  |  | 3 |  |  | 9,825 |  |
| Other | 23 |  |  | 165 |  |  | 109 |  |  | 20 |  |  | 1 |  |  | 2 |  |  | 320 |  |
| Total maturities, principal amount | 5,224 |  |  | 3,777 |  |  | 2,403 |  |  | 1,185 |  |  | 6,801 |  |  | 8,007 |  |  | 27,397 |  |
| Associated carrying value adjustments | (5) |  |  | (6) |  |  | (9) |  |  | (8) |  |  | (56) |  |  | (191) |  |  | (275) |  |
| Total maturities, carrying value amount | $ | 5,219 |  |  | $ | 3,771 |  |  | $ | 2,394 |  |  | $ | 1,177 |  |  | $ | 6,745 |  |  | $ | 7,816 |  |  | $ | 27,122 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001571996-22-000021:notes:137]
DERIVATIVE INSTRUMENTS AND HEDGING ACTIVITIES 
As part of its risk management strategy, the Company uses derivative instruments, primarily foreign currency forward and option contracts and interest rate swaps, to hedge certain foreign currency and interest rate exposures, respectively.

[0001571996-22-000021:notes:138]
[same as prior period, unchanged from 0001571996-21-000063:notes:151]

[0001571996-22-000021:notes:139]
[same as prior period, unchanged from 0001571996-21-000063:notes:152]

[0001571996-22-000021:notes:140]
[same as prior period, unchanged from 0001571996-21-000063:notes:153]

[0001571996-22-000021:notes:141]
During the three months ended April 29, 2022 and April 30, 2021, the Company did not discontinue any cash flow hedges related to foreign exchange contracts that had a material impact on the Company’s results of operations due to the probability that the forecasted cash flows would not occur.

[0001571996-22-000021:notes:142]
[same as prior period, unchanged from 0001571996-21-000063:notes:155]

[0001571996-22-000021:notes:143]
[same as prior period, unchanged from 0001571996-21-000063:notes:156]

[0001571996-22-000021:notes:144]
[same as prior period, unchanged from 0001571996-21-000063:notes:157]

[0001571996-22-000021:notes:145]
[same as prior period, unchanged from 0001571996-21-000063:notes:158]

[0001571996-22-000021:notes:146]
Interest rate swaps are utilized to manage the interest rate risk, at a portfolio level, associated with DFS operations in Europe.  The interest rate swaps economically convert the fixed rate on financing receivables to a three-month Euribor floating rate in order to match the floating rate nature of the banks’ funding pool.  These contracts are not designated for hedge accounting and most expire within five years or less.

[0001571996-22-000021:notes:147]
The Company utilizes cross-currency amortizing swaps to hedge the currency and interest rate risk exposure associated with the European securitization program.  The cross currency swaps combine a Euro-based interest rate swap with a British Pound or U.S. Dollar foreign exchange forward contract in which the Company pays a fixed or floating British Pound or U.S. Dollar amount and receives a fixed or floating amount in Euros linked to the one-month Euribor.  The notional value of the swaps amortizes in line with the expected cash flows and run-off of the securitized assets.  The swaps are not designated for hedge accounting and expire within five years or less.

[0001571996-22-000021:notes:148]
[same as prior period, unchanged from 0001571996-21-000063:notes:161]

[0001571996-22-000021:notes:149]
The following table presents the notional amounts of outstanding derivative instruments as of the dates indicated:

[0001571996-22-000021:notes:150]
|  | April 29, 2022 |  | January 28, 2022 |
|  | (in millions) |
| Foreign exchange contracts: |  |  |  |
| Designated as cash flow hedging instruments | $ | 8,758 |  |  | $ | 7,879 |  |
| Non-designated as hedging instruments | 8,047 |  |  | 8,713 |  |
| Total | $ | 16,805 |  |  | $ | 16,592 |  |
| Interest rate contracts: |  |  |  |
| Non-designated as hedging instruments | $ | 6,146 |  |  | $ | 6,715 |  |

[0001571996-22-000021:notes:151]
The following table presents the effect of derivative instruments designated as hedging instruments on the Condensed Consolidated Statements of Financial Position and the Condensed Consolidated Statements of Income for the periods indicated:

[0001571996-22-000021:notes:152]
| Derivatives in Cash Flow Hedging Relationships |  | Gain (Loss) Recognized in Accumulated OCI, Net of Tax, on Derivatives |  | Location of Gain (Loss) Reclassified from Accumulated OCI into Income |  | Gain (Loss) Reclassified from Accumulated OCI into Income |
|  |  | (in millions) |  |  |  | (in millions) |
| For the three months ended April 29, 2022 |
|  |  |  |  | Total net revenue |  | $ | 123 |  |
| Foreign exchange contracts |  | $ | 372 |  |  | Total cost of net revenue |  | (27) |  |
| Interest rate contracts |  | — |  |  | Interest and other, net |  | — |  |
| Total |  | $ | 372 |  |  | Total |  | $ | 96 |  |
| For the three months ended April 30, 2021 |
|  |  |  |  | Total net revenue |  | $ | (30) |  |
| Foreign exchange contracts |  | $ | (1) |  |  | Total cost of net revenue |  | 2 |  |
| Interest rate contracts |  | — |  |  | Interest and other, net |  | — |  |
| Total |  | $ | (1) |  |  | Income from discontinued operations |  | 1 |  |
|  |  |  |  | Total |  | $ | (27) |  |

[0001571996-22-000021:notes:153]
The following table presents the effect of derivative instruments not designated as hedging instruments on the Condensed Consolidated Statements of Income as of the dates indicated:

[0001571996-22-000021:notes:154]
|  | Three Months Ended |  |  |
|  | April 29, 2022 |  | April 30, 2021 |  |  |  | Location of Gain (Loss) Recognized |
|  | (in millions) |  |  |
| Foreign exchange contracts | $ | (231) |  |  | $ | (29) |  |  |  |  | Interest and other, net |
| Interest rate contracts | 17 |  |  | 1 |  |  |  |  | Interest and other, net |
| Foreign exchange contracts | — |  |  | 5 |  |  |  |  | Income from discontinued operations |
| Total | $ | (214) |  |  | $ | (23) |  |  |  |  |  |

[0001571996-22-000021:notes:155]
The Company presents its foreign exchange derivative instruments on a net basis in the Condensed Consolidated Statements of Financial Position due to the right of offset by its counterparties under master netting arrangements.  The following tables present the fair value of those derivative instruments presented on a gross basis as the dates indicated:

[0001571996-22-000021:notes:156]
|  | April 29, 2022 |
|  | Other CurrentAssets |  | Other Non-Current Assets |  | Other CurrentLiabilities |  | Other Non-CurrentLiabilities |  | TotalFair Value |
|  | (in millions) |
| Derivatives designated as hedging instruments: |
| Foreign exchange contracts in an asset position | $ | 290 |  |  | $ | — |  |  | $ | 200 |  |  | $ | — |  |  | $ | 490 |  |
| Foreign exchange contracts in a liability position | (1) |  |  | — |  |  | (8) |  |  | — |  |  | (9) |  |
| Net asset | 289 |  |  | — |  |  | 192 |  |  | — |  |  | 481 |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts in an asset position | 480 |  |  | 1 |  |  | 303 |  |  | — |  |  | 784 |  |
| Foreign exchange contracts in a liability position | (389) |  |  | — |  |  | (609) |  |  | (2) |  |  | (1,000) |  |
| Interest rate contracts in an asset position | — |  |  | 90 |  |  | — |  |  |  |  | 90 |  |
| Interest rate contracts in a liability position | — |  |  | — |  |  | — |  |  | (64) |  |  | (64) |  |
| Net asset (liability) | 91 |  |  | 91 |  |  | (306) |  |  | (66) |  |  | (190) |  |
| Total derivatives at fair value | $ | 380 |  |  | $ | 91 |  |  | $ | (114) |  |  | $ | (66) |  |  | $ | 291 |  |
|  | January 28, 2022 |
|  | Other CurrentAssets |  | Other Non-Current Assets |  | Other CurrentLiabilities |  | Other Non-CurrentLiabilities |  | TotalFair Value |
|  | (in millions) |
| Derivatives designated as hedging instruments: |
| Foreign exchange contracts in an asset position | $ | 135 |  |  | $ | — |  |  | $ | 50 |  |  | $ | — |  |  | $ | 185 |  |
| Foreign exchange contracts in a liability position | (5) |  |  | — |  |  | (8) |  |  | — |  |  | (13) |  |
| Net asset | 130 |  |  | — |  |  | 42 |  |  | — |  |  | 172 |  |
| Derivatives not designated as hedging instruments: |
| Foreign exchange contracts in an asset position | 280 |  |  | 2 |  |  | 106 |  |  | — |  |  | 388 |  |
| Foreign exchange contracts in a liability position | (189) |  |  | — |  |  | (244) |  |  | (5) |  |  | (438) |  |
| Interest rate contracts in an asset position | — |  |  | 30 |  |  | — |  |  |  |  | 30 |  |
| Interest rate contracts in a liability position | — |  |  | — |  |  | — |  |  | (37) |  |  | (37) |  |
| Net asset (liability) | 91 |  |  | 32 |  |  | (138) |  |  | (42) |  |  | (57) |  |
| Total derivatives at fair value | $ | 221 |  |  | $ | 32 |  |  | $ | (96) |  |  | $ | (42) |  |  | $ | 115 |  |

[0001571996-22-000021:notes:157]
[same as prior period, unchanged from 0001571996-21-000063:notes:171]

[0001571996-22-000021:notes:158]
|  | April 29, 2022 |
|  | Gross Amounts of Recognized Assets/ (Liabilities) |  | Gross Amounts Offset in the Statement of Financial Position |  | Net Amounts of Assets/ (Liabilities) Presented in the Statement of Financial Position |  | Gross Amounts not Offset in the Statement of Financial Position |  | Net Amount of Assets/ (Liabilities) Recognized in the Statement of Financial Position |
|  | Financial Instruments |  | Cash Collateral Received or Pledged |  |
|  | (in millions) |
| Derivative instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Financial assets | $ | 1,364 |  |  | $ | (893) |  |  | $ | 471 |  |  | $ | — |  |  | $ | — |  |  | $ | 471 |  |
| Financial liabilities | (1,073) |  |  | 893 |  |  | (180) |  |  | — |  |  | 42 |  |  | (138) |  |
| Total derivative instruments | $ | 291 |  |  | $ | — |  |  | $ | 291 |  |  | $ | — |  |  | $ | 42 |  |  | $ | 333 |  |
|  | January 28, 2022 |
|  | Gross Amounts of Recognized Assets/ (Liabilities) |  | Gross Amounts Offset in the Statement of Financial Position |  | Net Amounts of Assets/ (Liabilities) Presented in the Statement of Financial Position |  | Gross Amounts not Offset in the Statement of Financial Position |  | Net Amount of Assets/ (Liabilities) Recognized in the Statement of Financial Position |
|  | Financial Instruments |  | Cash Collateral Received or Pledged |  |
|  | (in millions) |
| Derivative instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Financial assets | $ | 603 |  |  | $ | (350) |  |  | $ | 253 |  |  | $ | — |  |  | $ | — |  |  | $ | 253 |  |
| Financial liabilities | (488) |  |  | 350 |  |  | (138) |  |  | — |  |  | 24 |  |  | (114) |  |
| Total derivative instruments | $ | 115 |  |  | $ | — |  |  | $ | 115 |  |  | $ | — |  |  | $ | 24 |  |  | $ | 139 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001571996-22-000021:notes:159]
GOODWILL AND INTANGIBLE ASSETS
Goodwill

[0001571996-22-000021:notes:160]
The Infrastructure Solutions Group and Client Solutions Group reporting units are consistent with the reportable segments identified in Note 17 of the Notes to the Condensed Consolidated Financial Statements.  Other businesses consists of VMware Resale, Secureworks, and Virtustream, which each represent separate reporting units.

[0001571996-22-000021:notes:161]
[same as prior period, unchanged from 0001571996-21-000063:notes:176]

[0001571996-22-000021:notes:162]
|  | Infrastructure Solutions Group |  | Client Solutions Group |  | Other Businesses |  | Total |
|  | (in millions) |
| Balances as of January 28, 2022 | $ | 15,106 |  |  | $ | 4,237 |  |  | $ | 427 |  |  | $ | 19,770 |  |
| Impact of foreign currency translation | (172) |  |  | — |  |  | — |  |  | (172) |  |
| Balances as of April 29, 2022 | $ | 14,934 |  |  | $ | 4,237 |  |  | $ | 427 |  |  | $ | 19,598 |  |

[0001571996-22-000021:notes:163]
[same as prior period, unchanged from 0001571996-21-000063:notes:179]

[0001571996-22-000021:notes:164]
[same as prior period, unchanged from 0001571996-21-000063:notes:180]

[0001571996-22-000021:notes:165]
|  | April 29, 2022 |  | January 28, 2022 |
|  | Gross |  | AccumulatedAmortization |  | Net |  | Gross |  | AccumulatedAmortization |  | Net |
|  | (in millions) |
| Customer relationships | $ | 16,956 |  |  | $ | (14,071) |  |  | $ | 2,885 |  |  | $ | 16,956 |  |  | $ | (13,938) |  |  | $ | 3,018 |  |
| Developed technology | 9,634 |  |  | (8,507) |  |  | 1,127 |  |  | 9,635 |  |  | (8,405) |  |  | 1,230 |  |
| Trade names | 885 |  |  | (765) |  |  | 120 |  |  | 885 |  |  | (757) |  |  | 128 |  |
| Definite-lived intangible assets | 27,475 |  |  | (23,343) |  |  | 4,132 |  |  | 27,476 |  |  | (23,100) |  |  | 4,376 |  |
| Indefinite-lived trade names | 3,085 |  |  | — |  |  | 3,085 |  |  | 3,085 |  |  | — |  |  | 3,085 |  |
| Total intangible assets | $ | 30,560 |  |  | $ | (23,343) |  |  | $ | 7,217 |  |  | $ | 30,561 |  |  | $ | (23,100) |  |  | $ | 7,461 |  |

[0001571996-22-000021:notes:166]
Amortization expense related to definite-lived intangible assets was $243 million and $445 million for the three months ended April 29, 2022 and April 30, 2021, respectively.  There were no material impairment charges related to intangible assets during the three months ended April 29, 2022 and April 30, 2021.

[0001571996-22-000021:notes:167]
[same as prior period, unchanged from 0001571996-21-000063:notes:184]

[0001571996-22-000021:notes:168]
|  | April 29, 2022 |
|  | (in millions) |
| Fiscal 2023 (remaining nine months) | $ | 732 |  |
| Fiscal 2024 | 776 |  |
| Fiscal 2025 | 607 |  |
| Fiscal 2026 | 474 |  |
| Fiscal 2027 | 361 |  |
| Thereafter | 1,182 |  |
| Total | $ | 4,132 |  |

[0001571996-22-000021:notes:169]
[same as prior period, unchanged from 0001571996-21-000063:notes:186]

[0001571996-22-000021:notes:170]
[same as prior period, unchanged from 0001571996-21-000063:notes:187]

[0001571996-22-000021:notes:171]
For the annual impairment review in the third quarter of Fiscal 2022, the Company elected to bypass the assessment of qualitative factors to determine whether it was more likely than not that the fair value of a reporting unit was less than its carrying amount, including goodwill.  In electing to bypass the qualitative assessment, the Company proceeded directly to perform a quantitative goodwill impairment test to measure the fair value of each goodwill reporting unit relative to its carrying amount, and to determine the amount of goodwill impairment loss to be recognized, if any.

[0001571996-22-000021:notes:172]
Management exercised significant judgment related to the above assessment, including the identification of goodwill reporting units, assignment of assets and liabilities to goodwill reporting units, assignment of goodwill to reporting units, and determination of the fair value of each goodwill reporting unit.  The fair value of each goodwill reporting unit is generally estimated using a combination of public company multiples and discounted cash flow methodologies, except with respect to Secureworks, which is a publicly-traded entity, in which case the fair value is determined based primarily on the public company market valuation.  The discounted cash flow and public company multiples methodologies require significant judgment, including estimation of future revenues, gross margins, and operating expenses, which are dependent on internal forecasts, current and anticipated economic conditions and trends, selection of market multiples through assessment of the reporting unit’s performance relative to peer competitors, the estimation of the long-term revenue growth rate and discount rate of the Company’s business, and the determination of the Company’s weighted average cost of capital.  Changes in these estimates and assumptions could materially affect the fair value of the goodwill reporting unit, potentially resulting in a non-cash impairment charge.

[0001571996-22-000021:notes:173]
[same as prior period, unchanged from 0001571996-21-000063:notes:190]

[0001571996-22-000021:notes:174]
Based on the results of the annual impairment test performed during the fiscal year ended January 28, 2022, the fair values of each of the reporting units exceeded their carrying values.  No impairment test was performed during the three months ended April 29, 2022.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001571996-22-000021:notes:175]
DEFERRED REVENUE 
Deferred Revenue — Deferred revenue consists of support and deployment services, software maintenance, training, Software-as-a-Service, and undelivered hardware and professional services, consisting of installations and consulting engagements.  Deferred revenue is recorded when the Company has invoiced or payments have been received for undelivered products or services where transfer of control has not occurred.  Revenue is recognized as the Company’s performance obligations under the contract are completed.

[0001571996-22-000021:notes:176]
[same as prior period, unchanged from 0001571996-21-000063:notes:194]

[0001571996-22-000021:notes:177]
|  | Three Months Ended |
|  | April 29, 2022 |  | April 30, 2021 |
|  | (in millions) |
| Deferred revenue: |  |  |  |
| Deferred revenue at beginning of period | $ | 27,573 |  |  | $ | 25,592 |  |
| Revenue deferrals | 4,975 |  |  | 5,279 |  |
| Revenue recognized | (4,980) |  |  | (4,589) |  |
| Other (a) | (165) |  |  | — |  |
| Deferred revenue at end of period | $ | 27,403 |  |  | $ | 26,282 |  |
| Short-term deferred revenue | $ | 14,329 |  |  | $ | 13,641 |  |
| Long-term deferred revenue | $ | 13,074 |  |  | $ | 12,641 |  |

[0001571996-22-000021:notes:178]
(a)    Other represents the reclassification of deferred revenue to accrued and other liabilities.

[0001571996-22-000021:notes:179]
Remaining Performance Obligations — Remaining performance obligations represent the aggregate amount of the transaction price allocated to performance obligations not delivered, or partially undelivered, as of the end of the reporting period.  Remaining performance obligations include deferred revenue plus unbilled amounts not yet recorded in deferred revenue.  The value of the transaction price allocated to remaining performance obligations as of April 29, 2022 was approximately $42 billion.  The Company expects to recognize approximately 62% of remaining performance obligations as revenue in the next twelve months, and the remainder thereafter.

[0001571996-22-000021:notes:180]
The aggregate amount of the transaction price allocated to remaining performance obligations does not include amounts owed under cancelable contracts where there is no substantive termination penalty.  The Company applied the practical expedient to exclude the value of remaining performance obligations for contracts for which revenue is recognized at the amount to which the Company has the right to invoice for services performed.

[0001571996-22-000021:notes:181]
[same as prior period, unchanged from 0001571996-21-000063:notes:199]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001571996-22-000021:notes:182]
COMMITMENTS AND CONTINGENCIES 
Purchase Obligations

[0001571996-22-000021:notes:183]
The Company has contractual obligations to purchase goods or services, which specify significant terms (including fixed or minimum quantities to be purchased), fixed, minimum, or variable price provisions; and the approximate timing of the transaction.  As of April 29, 2022, such purchase obligations were $3.1 billion, $0.4 billion, and $0.8 billion for the remaining nine months of Fiscal 2023, Fiscal 2024, and Fiscal 2025 and thereafter, respectively.

[0001571996-22-000021:notes:184]
Legal Matters

[0001571996-22-000021:notes:185]
The Company is involved in various claims, suits, assessments, investigations, and legal proceedings that arise from time to time in the ordinary course of its business, including those identified below, consisting of matters involving consumer, antitrust, tax, intellectual property, and other issues on a global basis.  Pursuant to the Separation and Distribution Agreement referred to below, Dell Technologies shares responsibility with VMware for certain matters, as indicated below, and VMware has agreed to indemnify Dell Technologies in whole or in part with respect to certain matters.

[0001571996-22-000021:notes:186]
The Company accrues a liability when it believes that it is both probable that a liability has been incurred and that it can reasonably estimate the amount of the loss.  The Company reviews these accruals at least quarterly and adjusts them to reflect ongoing negotiations, settlements, rulings, advice of legal counsel, and other relevant information.  To the extent new information is obtained and the Company’s views on the probable outcomes of claims, suits, assessments, investigations, or legal proceedings change, changes in the Company’s accrued liabilities are recorded in the period in which such a determination is made.  For some matters, the amount of liability is not probable or the amount cannot be reasonably estimated and therefore accruals have not been made.

[0001571996-22-000021:notes:187]
The following is a discussion of the Company’s significant legal matters and other proceedings:

[0001571996-22-000021:notes:188]
Class Actions Related to the Class V Transaction — On December 28, 2018, the Company completed a transaction (the “Class V transaction”) in which it paid $14.0 billion in cash and issued 149,387,617 shares of its Class C Common Stock to holders of its Class V Common Stock in exchange for all outstanding shares of Class V Common Stock.  As a result of the Class V transaction, the tracking stock feature of the Company’s capital structure associated with the Class V Common Stock was terminated.  In November 2018, four purported stockholders brought putative class action complaints arising out of the Class V transaction.  The actions were captioned Hallandale Beach Police and Fire Retirement Plan v. Michael Dell et al. (Civil Action No. 2018-0816-JTL), Howard Karp v. Michael Dell et al. (Civil Action No. 2019-0032-JTL), Miramar Police Officers’ Retirement Plan v. Michael Dell et al. (Civil Action No. 2019-0049-JTL), and Steamfitters Local 449 Pension Plan v. Michael Dell et al. (Civil Action No. 2019-0115-JTL).  The four actions were consolidated in the Delaware Chancery Court into In Re Dell Class V Litigation (Consol. C.A. No. 2018-0816-JTL).  The suit currently names as defendants Michael S. Dell and certain of the other directors serving on the board of directors at the time of the Class V transaction, certain stockholders of the Company, consisting of Michael S. Dell and Silver Lake Group LLC and certain of its affiliated funds, and Goldman Sachs & Co. LLC (“Goldman Sachs”), which served as financial advisor to the Company in connection with the Class V transaction.  In an amended complaint filed in August 2019,  the plaintiffs generally allege that the director and stockholder defendants breached their fiduciary duties under Delaware law to the former holders of Class V Common Stock in connection with the Class V transaction by offering a transaction value that was allegedly billions of dollars below the fair value.  The plaintiffs contend that the offer understated the value of shares surrendered by the former stockholders, which the plaintiffs allege should have reflected higher alternative valuations, including a valuation related to the value of the shares of VMware, Inc. common stock, and that the difference in values was wrongfully appropriated by the stockholder defendants.  On August 20, 2021, the plaintiffs added Goldman Sachs as a defendant and allege that it aided and abetted the alleged primary violations.  In the complaint, the plaintiffs seek, among other remedies, a judicial declaration that the director and stockholder defendants breached their fiduciary duties.  The plaintiffs also seek in the complaint disgorgement of all profits, benefits, and other compensation obtained by the defendants as a result of such alleged conduct and an award of unspecified damages, fees, and costs.  The defendants filed a motion to dismiss the action in September 2019.  The court denied the motion in June 2020 and the case is currently in the discovery phase.  Trial is scheduled to begin on December 5, 2022.  The Company is not a defendant in this action but is subject to director indemnification provisions under its certificate of incorporation and bylaws, and is a party to agreements with

[0001571996-22-000021:notes:189]
the defendants that contain indemnification obligations of the Company, conditioned on the satisfaction of the requirements set forth in such agreements, relating to service as a director, ownership of the Company’s securities, and provision of services, as applicable.

[0001571996-22-000021:notes:190]
Class Actions Related to VMware, Inc.’s Acquisition of Pivotal — Two purported stockholders brought putative class action complaints arising out of VMware, Inc.’s acquisition of Pivotal Software, Inc. on December 30, 2019.  The two actions were consolidated in the Delaware Chancery Court into In re: Pivotal Software, Inc. Stockholders Litigation (Civil Action No. 2020-0440-KSJM).  The complaint names as defendants the Company, VMware, Inc., Michael S. Dell, and certain officers of Pivotal.  The plaintiffs generally allege that the defendants breached their fiduciary duties to the former holders of Pivotal Class A Common Stock in connection with VMware, Inc.’s acquisition of Pivotal by allegedly causing Pivotal to enter into a transaction that favored the interests of Pivotal’s controlling stockholders at the expense of such former stockholders.  The parties have reached an agreement to settle the litigation and are seeking the court’s approval of the settlement.

[0001571996-22-000021:notes:191]
Other Litigation — Dell does not currently anticipate that any of the other various legal proceedings it is involved in will have a material adverse effect on its business, financial condition, results of operations, or cash flows.

[0001571996-22-000021:notes:192]
In accordance with the relevant accounting guidance, the Company provides disclosures of matters where it is at least reasonably possible that the Company could experience a material loss exceeding the amounts already accrued for these or other proceedings or matters.  In addition, the Company also discloses matters based on its consideration of other matters and qualitative factors, including the experience of other companies in the industry, and investor, customer, and employee relations considerations.  As of April 29, 2022, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for these or other proceedings or matters has been incurred.  However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company’s business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters.  Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company’s business, financial condition, results of operations, or cash flows will depend on a number of factors, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.

[0001571996-22-000021:notes:193]
Indemnifications Obligations

[0001571996-22-000021:notes:194]
In the ordinary course of business, the Company enters into various contracts under which it may agree to indemnify other parties for losses incurred from certain events as defined in the relevant contract, such as litigation, regulatory penalties, or claims relating to past performance.  Such indemnification obligations may not be subject to maximum loss clauses.  Historically, payments related to these indemnification obligations have not been material to the Company.

[0001571996-22-000021:notes:195]
Under the Separation and Distribution Agreement described in Note 2 of the Notes to the Condensed Consolidated Financial Statements, Dell Technologies has agreed to indemnify VMware, Inc., each of its subsidiaries and each of their respective directors, officers, and employees from and against all liabilities relating to, arising out of or resulting from, among other matters, the liabilities allocated to Dell Technologies as part of the separation of  Dell Technologies and VMware and their respective businesses as a result of the VMware Spin-off (the “Separation”).  VMware similarly has agreed to indemnify Dell Technologies, Inc., each of its subsidiaries and each of their respective directors, officers, and employees from and against all liabilities relating to, arising out of or resulting from, among other matters, the liabilities allocated to VMware as part of the Separation.  Dell Technologies expects VMware to fully perform under the terms of the Separation and Distribution Agreement.
For information on the cross-indemnifications related to the tax matters agreement between the Company and VMware described in Note 2 of the Notes to the Condensed Consolidated Financial Statements effective upon the Separation on November 1, 2021, see Note 2 and Note 16 of the Notes to the Condensed Consolidated Financial Statements.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001571996-22-000021:notes:196]
INCOME AND OTHER TAXES
For the three months ended April 29, 2022, the Company’s effective income tax rate was 11.9% on pre-tax income of $1.2 billion compared to 5.7% on pre-tax income of $0.7 billion for the three months ended April 30, 2021.  The change in the Company’s effective income tax rate was attributable in part to the impact of discrete tax benefits related to stock-based compensation of $91 million and $97 million for the three months ended April 29, 2022 and April 30, 2021, respectively.  The change in the Company’s effective income tax rate was also due to a change in the Company’s jurisdictional mix of income and higher U.S. tax on foreign operations, the effects of which were partially offset by higher benefits from foreign tax credits.

[0001571996-22-000021:notes:197]
Higher U.S. tax on foreign operations was due to the capitalization of research and development costs.  Under the Tax Cuts and Jobs Act, which was enacted on December 22, 2017, research and development costs incurred for tax years beginning after December 31, 2021 must be capitalized and amortized ratably over five or 15 years for tax purposes, depending on where the research activities are conducted.  The effective income tax rate for future quarters of Fiscal 2023 may be impacted by actions taken by the U.S. government to defer or repeal this provision, as well as by the actual mix of jurisdictions in which income is generated and the impact of any discrete tax items.

[0001571996-22-000021:notes:198]
The differences between the estimated effective income tax rates and the U.S. federal statutory rate of 21% principally result from the Company’s geographical distribution of income, differences between the book and tax treatment of certain items, and discrete tax items.  In certain jurisdictions, the Company’s tax rate is significantly less than the applicable statutory rate as a result of tax holidays.  The majority of the Company’s foreign income that is subject to these tax holidays and lower tax rates is attributable to Singapore and China.  A significant portion of these income tax benefits relate to a tax holiday that will be effective until January 31, 2029.  The Company’s other tax holidays will expire in whole or in part during fiscal years 2030 through 2031.  Many of these tax holidays and reduced tax rates may be extended when certain conditions are met or may be terminated early if certain conditions are not met.  As of April 29, 2022, the Company was not aware of any matters of non-compliance related to these tax holidays.

[0001571996-22-000021:notes:199]
The Internal Revenue Service is currently conducting tax examinations of the Company for fiscal years 2015 through 2019.  The Company is also currently under income tax audits in various state and foreign jurisdictions.  The Company is undergoing negotiations, and in some cases contested proceedings, relating to tax matters with the taxing authorities in these jurisdictions.  The Company believes that it has valid positions supporting its tax returns and that it has provided adequate reserves related to all matters contained in tax periods open to examination.  Although the Company believes it has made adequate provisions for the uncertainties surrounding these audits, should the Company experience unfavorable outcomes, such outcomes could have a material impact on its results of operations, financial position, and cash flows.  With respect to major U.S., state and foreign taxing jurisdictions, the Company is generally not subject to tax examinations for years prior to the fiscal year ended January 29, 2010.

[0001571996-22-000021:notes:200]
Judgment is required in evaluating the Company’s uncertain tax positions and determining the Company’s provision for income taxes.  The unrecognized tax benefits were $1.2 billion as of both April 29, 2022 and January 28, 2022, and are included in other non-current liabilities in the Condensed Consolidated Statements of Financial Position.  The Company does not anticipate a significant change to the total amount of unrecognized tax benefits within the next twelve months.

[0001571996-22-000021:notes:201]
The Company takes certain non-income tax positions in the jurisdictions in which it operates and has received certain non-income tax assessments from various jurisdictions.  The Company believes that a material loss in these matters is not probable and that it is not reasonably possible that a material loss exceeding amounts already accrued has been incurred.  The Company believes its positions in these non-income tax litigation matters are supportable and that it ultimately will prevail in the matters.  In the normal course of business, the Company’s positions and conclusions related to its non-income taxes could be challenged and assessments may be made.  To the extent new information is obtained and the Company’s views on its positions, probable outcomes of assessments, or litigation change, changes in estimates to the Company’s accrued liabilities would be recorded in the period in which such a determination is made.  In the resolution process for income tax and non-income tax audits, the Company is required in certain situations to provide collateral guarantees or indemnification to regulators and tax authorities until the matter is resolved.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001571996-22-000021:notes:202]
ACCUMULATED OTHER COMPREHENSIVE INCOME (LOSS) 
Accumulated other comprehensive income (loss) is presented in stockholders’ equity (deficit) in the Condensed Consolidated Statements of Financial Position and consists of amounts related to foreign currency translation adjustments, unrealized net gains (losses) on cash flow hedges, and actuarial net gains (losses) from pension and other postretirement plans.

[0001571996-22-000021:notes:203]
[same as prior period, unchanged from 0001571996-21-000063:notes:224]

[0001571996-22-000021:notes:204]
|  | Foreign Currency Translation Adjustments |  |  |  | Cash Flow Hedges |  | Pension and Other Postretirement Plans |  | Accumulated Other Comprehensive Income (Loss) |
|  | (in millions) |
| Balances as of January 28, 2022 | $ | (526) |  |  |  |  | $ | 129 |  |  | $ | (34) |  |  | $ | (431) |  |
| Other comprehensive income (loss) before reclassifications | (286) |  |  |  |  | 372 |  |  | 17 |  |  | 103 |  |
| Amounts reclassified from accumulated other comprehensive income (loss) | — |  |  |  |  | (96) |  |  | — |  |  | (96) |  |
| Total change for the period | (286) |  |  |  |  | 276 |  |  | 17 |  |  | 7 |  |
| Balances as of April 29, 2022 | $ | (812) |  |  |  |  | $ | 405 |  |  | $ | (17) |  |  | $ | (424) |  |

[0001571996-22-000021:notes:205]
Amounts related to the Company’s cash flow hedges are reclassified to net income during the same period in which the items being hedged are recognized in earnings.  See Note 8 of the Notes to the Condensed Consolidated Financial Statements for more information on the Company’s derivative instruments.

[0001571996-22-000021:notes:206]
[same as prior period, unchanged from 0001571996-21-000063:notes:227]

[0001571996-22-000021:notes:207]
|  |  |  | Three Months Ended |
|  |  |  | April 29, 2022 |  |  |  | April 30, 2021 |
|  |  |  | Cash Flow Hedges |  | Pensions |  | Total |  |  |  | Cash Flow Hedges |  | Pensions |  | Total |
|  |  |  | (in millions) |
| Total reclassifications, net of tax: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue |  |  | $ | 123 |  |  | $ | — |  |  | $ | 123 |  |  |  |  | $ | (30) |  |  | $ | — |  |  | $ | (30) |  |
| Cost of net revenue |  |  | (27) |  |  | — |  |  | (27) |  |  |  |  | 2 |  |  | — |  |  | 2 |  |
| Income from discontinued operations |  |  | — |  |  | — |  |  | — |  |  |  |  | 1 |  |  | — |  |  | 1 |  |
| Total reclassifications, net of tax |  |  | $ | 96 |  |  | $ | — |  |  | $ | 96 |  |  |  |  | $ | (27) |  |  | $ | — |  |  | $ | (27) |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001571996-22-000021:notes:208]
CAPITALIZATION 
The following table presents the Company’s authorized, issued, and outstanding common stock as of the dates indicated:

[0001571996-22-000021:notes:209]
|  | Authorized |  | Issued |  | Outstanding |
|  | (in millions) |
| Common stock as of April 29, 2022 |
| Class A | 600 |  |  | 379 |  |  | 379 |  |
| Class B | 200 |  |  | 95 |  |  | 95 |  |
| Class C | 7,900 |  |  | 321 |  |  | 273 |  |
| Class D | 100 |  |  | — |  |  | — |  |
| Class V | 343 |  |  | — |  |  | — |  |
|  | 9,143 |  |  | 795 |  |  | 747 |  |
| Common stock as of January 28, 2022 |
| Class A | 600 |  |  | 379 |  |  | 379 |  |
| Class B | 200 |  |  | 95 |  |  | 95 |  |
| Class C | 7,900 |  |  | 303 |  |  | 283 |  |
| Class D | 100 |  |  | — |  |  | — |  |
| Class V | 343 |  |  | — |  |  | — |  |
|  | 9,143 |  |  | 777 |  |  | 757 |  |

[0001571996-22-000021:notes:210]
Under the Company’s certificate of incorporation, the Company is prohibited from issuing any of the authorized shares of Class V Common Stock.

[0001571996-22-000021:notes:211]
[same as prior period, unchanged from 0001571996-21-000063:notes:238]

[0001571996-22-000021:notes:212]
The Company is authorized to issue one million shares of preferred stock, par value $0.01 per share.  As of April 29, 2022 and January 28, 2022, no shares of preferred stock were issued or outstanding.

[0001571996-22-000021:notes:213]
[same as prior period, unchanged from 0001571996-21-000063:notes:240]

[0001571996-22-000021:notes:214]
[same as prior period, unchanged from 0001571996-21-000063:notes:241]

[0001571996-22-000021:notes:215]
[same as prior period, unchanged from 0001571996-21-000063:notes:242]

[0001571996-22-000021:notes:216]
Conversion Rights — Under the Company’s certificate of incorporation, at any time and from time to time, any holder of Class A Common Stock or Class B Common Stock has the right to convert all or any of the shares of Class A Common Stock or Class B Common Stock, as applicable, held by such holder into shares of Class C Common Stock on a one-to-one basis.

[0001571996-22-000021:notes:217]
During the three months ended April 29, 2022, there were no conversions of shares of Class A or Class B Common Stock into shares of Class C Common Stock.

[0001571996-22-000021:notes:218]
Dividends

[0001571996-22-000021:notes:219]
On February 24, 2022, the Company announced that its Board of Directors has adopted a dividend policy under which the Company intends to pay quarterly cash dividends on its common stock at an initial rate of $0.33 per share per fiscal quarter.

[0001571996-22-000021:notes:220]
During the three months ended April 29, 2022, the Company paid an initial quarterly dividend under the new policy in the amount of $248 million to the holders of record of all of the issued and outstanding shares of common stock as of the close of business on April 20, 2022.

[0001571996-22-000021:notes:221]
[same as prior period, unchanged from 0001571996-21-000063:notes:244]

[0001571996-22-000021:notes:222]
Effective as of September 23, 2021, the Company’s Board of Directors terminated the Company’s previous stock repurchase program and approved a new stock repurchase program (the “2021 Stock Repurchase Program”) under which the Company is authorized to use assets to repurchase up to $5 billion of shares of the Company’s Class C Common Stock with no established expiration date.  During the three months ended April 29, 2022, the Company repurchased approximately 28.8 million shares of Class C Common Stock for a total purchase price of approximately $1.5 billion.

[0001571996-22-000021:notes:223]
The above repurchases of Class C Common Stock exclude shares repurchased to settle employee tax withholding related to the vesting of stock awards.  Pursuant to the respective award agreements, these shares were withheld in conjunction with the net share settlement upon the vesting of restricted stock units during the period.
The Company did not repurchase any shares of Class C Common Stock during the three months ended April 30, 2021 under the previous stock repurchase program.


## us-gaap:EarningsPerShareTextBlock

[0001571996-22-000021:notes:224]
EARNINGS PER SHARE
Basic earnings per share is based on the weighted-average effect of all common shares issued and outstanding and is calculated by dividing net income by the weighted-average shares outstanding during the period.  Diluted earnings per share is calculated by dividing net income by the weighted-average number of common shares used in the basic earnings per share calculation plus the number of common shares that would be issued assuming exercise or conversion of all potentially dilutive instruments.  The Company excludes equity instruments from the calculation of diluted earnings per share if the effect of including such instruments is antidilutive.

[0001571996-22-000021:notes:225]
The following table presents basic and diluted earnings per share for the periods indicated:

[0001571996-22-000021:notes:226]
|  |  |  | Three Months Ended |  |  |
|  |  |  |  |  | April 29, 2022 |  | April 30, 2021 |  |  |
| Earnings per share attributable to Dell Technologies Inc. - basic |
| Continuing operations |  |  |  |  | $ | 1.42 |  |  | $ | 0.87 |  |  |  |
| Discontinued operations |  |  |  |  | $ | — |  |  | $ | 0.30 |  |  |  |
| Earnings per share attributable to Dell Technologies Inc. — diluted |
| Continuing operations |  |  |  |  | $ | 1.37 |  |  | $ | 0.84 |  |  |  |
| Discontinued operations |  |  |  |  | $ | — |  |  | $ | 0.29 |  |  |  |

[0001571996-22-000021:notes:227]
[same as prior period, unchanged from 0001571996-21-000063:notes:259]

[0001571996-22-000021:notes:228]
|  | Three Months Ended |  |  |  |  |  |
|  | April 29, 2022 |  | April 30, 2021 |  |  |  |  |  |
|  | (in millions) |  |  |  |
| Numerator: Continuing operations |  |  |  |  |  |  |  |  |
| Net income attributable to Dell Technologies Inc. from continuing operations - basic and diluted | $ | 1,072 |  |  | $ | 660 |  |  |  |  |  |  |
| Numerator: Discontinued operations |  |  |  |  |  |  |  |  |
| Income from discontinued operations, net of income taxes - basic | $ | — |  |  | $ | 227 |  |  |  |  |  |  |
| Incremental dilution from VMware (a) | — |  |  | (2) |  |  |  |  |  |  |
| Income from discontinued operations, net of income taxes, attributable to Dell Technologies Inc. - diluted | $ | — |  |  | $ | 225 |  |  |  |  |  |  |
| Denominator: Dell Technologies Common Stock weighted-average shares outstanding |  |  |  |  |  |  |  |  |
| Weighted-average shares outstanding — basic | 754 |  |  | 757 |  |  |  |  |  |  |
| Dilutive effect of options, restricted stock units, restricted stock, and other | 26 |  |  | 25 |  |  |  |  |  |  |
| Weighted-average shares outstanding — diluted | 780 |  |  | 782 |  |  |  |  |  |  |
| Weighted-average shares outstanding — antidilutive | 1 |  |  | — |  |  |  |  |  |  |

[0001571996-22-000021:notes:229]
(a)    The incremental dilution from VMware represents the impact of VMware, Inc.’s dilutive securities on diluted earnings per share of Dell Technologies Common Stock, and is calculated by multiplying the difference between VMware, Inc.’s basic and diluted earnings (loss) per share by the number of shares of VMware, Inc. common stock held by the Company.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001571996-22-000021:notes:230]
RELATED PARTY TRANSACTIONS 
Effective upon the completion of the VMware Spin-off, VMware is considered to be a related party of the Company.  The related party relationship is a result of Michael Dell’s ownership interest in both Dell Technologies and VMware as well as Mr. Dell’s continued service as Chairman and Chief Executive Officer of Dell Technologies and as Chairman of the Board of VMware, Inc.  See Note 1 and Note 2 of the Notes to the Condensed Consolidated Financial Statements for more information about the VMware Spin-off.

[0001571996-22-000021:notes:231]
The information provided below includes a summary of transactions with VMware, Inc. and with its consolidated subsidiaries (collectively, “VMware”).  Transactions with related parties other than VMware during the periods presented were immaterial, individually and in aggregate.

[0001571996-22-000021:notes:232]
Transactions with VMware

[0001571996-22-000021:notes:233]
Dell Technologies and VMware engage in the following ongoing related party transactions:

[0001571996-22-000021:notes:234]
•Pursuant to original equipment manufacturer and reseller arrangements, Dell Technologies integrates or bundles VMware’s products and services with Dell Technologies’ products and sells them to end-users.  Dell Technologies also acts as a distributor, purchasing VMware’s standalone products and services for resale to end-user customers.  Where applicable, costs under these arrangements are presented net of rebates received by Dell Technologies.

[0001571996-22-000021:notes:235]
•Dell Technologies procures products and services from VMware for its internal use.  For the three months ended April 29, 2022 and April 30, 2021, cost incurred associated with products and services purchased from VMware for internal use was immaterial.

[0001571996-22-000021:notes:236]
•Dell Technologies sells and leases products and sells services to VMware.  For the three months ended April 29, 2022 and April 30, 2021, revenue recognized from sales of services to VMware was immaterial.

[0001571996-22-000021:notes:237]
•Dell Technologies and VMware also enter into joint marketing, sales, and branding arrangements, for which both parties may incur costs.  For the three months ended April 29, 2022 and April 30, 2021, consideration received from VMware for joint marketing, sales, and branding arrangements was immaterial.

[0001571996-22-000021:notes:238]
•DFS provides financing to certain VMware end users.  Upon acceptance of the financing arrangement by both VMware’s end users and DFS, DFS recognizes amounts due to related parties on the Condensed Consolidated Statements of Financial Position.  Associated financing fees are recorded to product net revenue on the Condensed Consolidated Statements of Income.

[0001571996-22-000021:notes:239]
•Dell Technologies and VMware enter into agreements to collaborate on technology projects in which one party pays the corresponding party for services or the reimbursement of costs.  For the three months ended April 29, 2022 and April 30, 2021, collaborative technology projects were immaterial.

[0001571996-22-000021:notes:240]
•Dell Technologies provides support services and support from Dell Technologies personnel to VMware in certain geographic regions where VMware does not have an established legal entity.  These employees are managed by VMware but Dell Technologies incurs the costs for these such services.  The costs incurred by Dell Technologies on VMware’s behalf to these employees are charged to VMware.  For the three months ended April 29, 2022 and April 30, 2021, costs associated with such seconded employees were immaterial.

[0001571996-22-000021:notes:241]
•Dell Technologies and VMware entered into a transition services agreement in connection with the VMware Spin-off to provide various support services including investment advisory services, certain support services from Dell Technologies personnel, and other transitional services.  Costs associated with this agreement were immaterial for the three months ended April 29, 2022.

[0001571996-22-000021:notes:242]
The following table presents information about the impact of Dell Technologies’ related party transactions with VMware on the Condensed Consolidated Statements of Income for the periods indicated:

[0001571996-22-000021:notes:243]
|  |  |  | Three Months Ended |  |  |  |  |  |
|  | Classification |  | April 29, 2022 |  | April 30, 2021 |  |  |  |  |  |
|  |  |  | (in millions) |  |  |  |
| Sales and leases of products to VMware | Net revenue - products |  | 46 |  |  | 47 |  |  |  |  |  |  |
| Purchase of VMware products for resale | Cost of net revenue - products |  | 255 |  |  | 319 |  |  |  |  |  |  |
| Purchase of VMware services for resale | Cost of net revenue - services |  | 709 |  |  | 578 |  |  |  |  |  |  |

[0001571996-22-000021:notes:244]
The following table presents information about the impact of Dell Technologies’ related party transactions with VMware on the Condensed Consolidated Statements of Financial Position for the periods indicated:

[0001571996-22-000021:notes:245]
|  | Classification | April 29, 2022 |  | January 28, 2022 |
|  |  | (in millions) |
| Deferred costs related to VMware products and services for resale | Other current assets | $ | 2,493 |  |  | $ | 2,571 |  |
| Deferred costs related to VMware products and services for resale | Other non-current assets | $ | 2,060 |  |  | $ | 2,311 |  |

[0001571996-22-000021:notes:246]
Related Party Tax Matters

[0001571996-22-000021:notes:247]
Tax Agreements — In connection with the VMware Spin-off and concurrently with the execution of the Separation and Distribution Agreement, effective as of April 14, 2021, Dell Technologies and VMware entered into a Tax Matters Agreement (the “Tax Matters Agreement”) and agreed to terminate the tax sharing agreement as amended on December 30, 2019 (together with the Tax Matters Agreement, the “Tax Agreements”).  The Tax Matters Agreement governs Dell Technologies’ and VMware’s respective rights and obligations, both for pre-spin-off periods and post-spin-off periods, regarding income and other taxes, and related matters, including tax liabilities and benefits, attributes, and returns.

[0001571996-22-000021:notes:248]
Net payments made to VMware pursuant to the Tax Agreements were immaterial during the three months ended April 29, 2022 and April 30, 2021, and relate to VMware’s portion of federal income taxes on Dell Technologies’ consolidated tax return as well as state tax payments for combined states.

[0001571996-22-000021:notes:249]
The timing of the tax payments due to and from related parties is governed by the Tax Agreements.  VMware’s portion of the mandatory one-time transition tax on accumulated earnings of foreign subsidiaries (the “Transition Tax”) is governed by a letter agreement between VMware and Dell Technologies entered into on April 1, 2019.

[0001571996-22-000021:notes:250]
As a result of the activity under the Tax Agreements with VMware, amounts due from VMware were $630 million and $621 million as of April 29, 2022 and January 28, 2022, respectively, primarily related to VMware’s estimated tax obligation resulting from the Transition Tax.  The 2017 Tax Cuts and Jobs Act included a deferral election for an eight-year installment payment method on the Transition Tax.  Dell Technologies expects VMware to pay the remainder of its Transition Tax over a period of four years.

[0001571996-22-000021:notes:251]
Indemnification — Upon consummation of the VMware Spin-off, Dell Technologies recorded net income tax indemnification receivables from VMware related to certain income tax liabilities for which Dell Technologies is jointly and severally liable, but for which it is indemnified by VMware under the Tax Matters Agreement.  The amounts that VMware may be obligated to pay Dell Technologies could vary depending on the outcome of certain unresolved tax matters, which may not be resolved for several years.  The net receivable as of April 29, 2022 was $147 million.

[0001571996-22-000021:notes:252]
Due To/From Related Party

[0001571996-22-000021:notes:253]
The following table presents amounts due to and from VMware as of the dates indicated:

[0001571996-22-000021:notes:254]
|  | April 29, 2022 |  | January 28, 2022 |
|  | (in millions) |
| Due from related party, net, current (a) | $ | 131 |  |  | $ | 131 |  |
| Due from related party, net, non-current (b) | $ | 713 |  |  | $ | 710 |  |
| Due to related party, current (c) | $ | 622 |  |  | $ | 1,414 |  |

[0001571996-22-000021:notes:255]
(a)    Amounts due from related party, current consists of amounts due from VMware, inclusive of current net tax receivables from VMware under the Tax Agreements.  Amounts, excluding tax, are generally settled in cash within 60 days of each quarter-end.

[0001571996-22-000021:notes:256]
(b)  Amounts in due from related party, non-current consists of non-current portion of net receivables from VMware under the Tax Agreements.

[0001571996-22-000021:notes:257]
(c)  Amounts in due to related party, current includes amounts due to VMware which are generally settled in cash within 60 days of each quarter-end.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001571996-22-000021:notes:258]
SEGMENT INFORMATION 
The Company has two reportable segments that are based on the following business units:  Infrastructure Solutions Group (“ISG”) and Client Solutions Group (“CSG”).

[0001571996-22-000021:notes:259]
ISG enables the digital transformation of the Company’s customers through its trusted multi-cloud and big data solutions, which are built upon a modern data center infrastructure.  The ISG comprehensive portfolio of advanced storage solutions includes traditional storage solutions as well as next-generation storage solutions (such as all-flash arrays, scale-out file, object platforms, and software-defined solutions), while the Company’s server portfolio includes high-performance rack, blade, tower, and hyperscale servers.  The ISG networking portfolio helps business customers transform and modernize their infrastructure, mobilize and enrich end-user experiences, and accelerate business applications and processes.  ISG also offers attached software, peripherals, and services, including support and deployment, configuration, and extended warranty services.

[0001571996-22-000021:notes:260]
[same as prior period, unchanged from 0001571996-21-000063:notes:273]

[0001571996-22-000021:notes:261]
The reportable segments disclosed herein are based on information reviewed by the Company’s management to evaluate the business segment results.  The Company’s measure of segment revenue and segment operating income for management reporting purposes excludes operating results of other businesses, unallocated corporate transactions, the impact of purchase accounting, amortization of intangible assets, transaction-related expenses, stock-based compensation expense, and other corporate expenses, as applicable.  The Company does not allocate assets to the above reportable segments for internal reporting purposes.

[0001571996-22-000021:notes:262]
As described in Note 1 and Note 2 of the Notes to the Condensed Consolidated Financial Statements, the Company completed the VMware Spin-off on November 1, 2021.

[0001571996-22-000021:notes:263]
Pursuant to the CFA described in such Notes, Dell Technologies continues to act as a distributor of VMware’s standalone products and services and purchase such products and services for resale to end-user customers (“VMware Resale”).  Dell Technologies also continues to integrate VMware’s products and services with Dell Technologies’ offerings and sell them to end users.  The results of such operations are classified as continuing operations within the Company’s Condensed Consolidated Statements of Income.  The results of standalone VMware Resale transactions are reflected in other businesses.  The results of integrated offering transactions are reflected within CSG or ISG, depending upon the nature of the underlying offering sold.  The Company's prior period segment results have been recast to reflect this change.

[0001571996-22-000021:notes:264]
In accordance with applicable accounting guidance, the results of VMware, excluding Dell's resale of VMware offerings, are presented as discontinued operations in the Condensed Consolidated Statements of Income and, as such, have been excluded from both continuing operations and segment results for prior periods presented.

[0001571996-22-000021:notes:265]
The following table presents a reconciliation of net revenue by the Company’s reportable segments to the Company’s consolidated net revenue as well as a reconciliation of segment operating income to the Company’s consolidated operating income for the periods indicated:

[0001571996-22-000021:notes:266]
|  |  |  | Three Months Ended |
|  |  |  |  |  | April 29, 2022 |  | April 30, 2021 |  |  |
|  |  |  |  |  | (in millions) |
| Consolidated net revenue: |  |  |  |  |  |  |  |  |  |
| Infrastructure Solutions Group |  |  |  |  | $ | 9,285 |  |  | $ | 8,033 |  |  |  |
| Client Solutions Group |  |  |  |  | 15,587 |  |  | 13,311 |  |  |  |
| Reportable segment net revenue |  |  |  |  | 24,872 |  |  | 21,344 |  |  |  |
| Other businesses (a) |  |  |  |  | 1,239 |  |  | 1,252 |  |  |  |
| Unallocated transactions (b) |  |  |  |  | 5 |  |  | 2 |  |  |  |
| Impact of purchase accounting (c) |  |  |  |  | — |  |  | (8) |  |  |  |
| Total consolidated net revenue |  |  |  |  | $ | 26,116 |  |  | $ | 22,590 |  |  |  |
| Consolidated operating income: |  |  |  |  |  |  |  |  |  |
| Infrastructure Solutions Group |  |  |  |  | $ | 1,082 |  |  | $ | 778 |  |  |  |
| Client Solutions Group |  |  |  |  | 1,115 |  |  | 1,080 |  |  |  |
| Reportable segment operating income |  |  |  |  | 2,197 |  |  | 1,858 |  |  |  |
| Other businesses (a) |  |  |  |  | (64) |  |  | (90) |  |  |  |
| Unallocated transactions (b) |  |  |  |  | 2 |  |  | 2 |  |  |  |
| Impact of purchase accounting (c) |  |  |  |  | (9) |  |  | (20) |  |  |  |
| Amortization of intangibles |  |  |  |  | (243) |  |  | (445) |  |  |  |
| Transaction-related expenses (d) |  |  |  |  | (5) |  |  | (29) |  |  |  |
| Stock-based compensation expense (e) |  |  |  |  | (232) |  |  | (172) |  |  |  |
| Other corporate expenses (f) |  |  |  |  | (96) |  |  | (117) |  |  |  |
| Total consolidated operating income |  |  |  |  | $ | 1,550 |  |  | $ | 987 |  |  |  |

[0001571996-22-000021:notes:267]
(a)Other businesses consists of (i) VMware Resale, (ii) Secureworks, and (iii) Virtustream, and do not meet the requirements for a reportable segment, either individually or collectively.

[0001571996-22-000021:notes:268]
[same as prior period, unchanged from 0001571996-21-000063:notes:280]

[0001571996-22-000021:notes:269]
(c)Impact of purchase accounting includes non-cash purchase accounting adjustments that are primarily related to the EMC merger transaction that was completed in September 2016.

[0001571996-22-000021:notes:270]
(d)Transaction-related expenses includes acquisition, integration, and divestiture related costs, as well as the costs incurred in the VMware Spin-off described in Note 1 and Note 2 of the Notes to the Condensed Consolidated Financial Statements.

[0001571996-22-000021:notes:271]
[same as prior period, unchanged from 0001571996-21-000063:notes:283]

[0001571996-22-000021:notes:272]
(f)Other corporate expenses includes impairment charges, incentive charges related to equity investments, severance, facility action, payroll taxes associated with stock-based compensation, and other costs.

[0001571996-22-000021:notes:273]
[same as prior period, unchanged from 0001571996-21-000063:notes:285]

[0001571996-22-000021:notes:274]
|  |  |  | Three Months Ended |
|  |  |  |  |  | April 29, 2022 |  | April 30, 2021 |  |  |
|  |  |  |  |  | (in millions) |
| Net revenue: |  |  |  |  |  |  |  |  |  |
| Infrastructure Solutions Group: |  |  |  |  |  |  |  |  |  |
| Servers and networking |  |  |  |  | $ | 5,048 |  |  | $ | 4,140 |  |  |  |
| Storage |  |  |  |  | 4,237 |  |  | 3,893 |  |  |  |
| Total ISG net revenue |  |  |  |  | $ | 9,285 |  |  | $ | 8,033 |  |  |  |
| Client Solutions Group: |  |  |  |  |  |  |  |  |  |
| Commercial |  |  |  |  | $ | 11,971 |  |  | $ | 9,808 |  |  |  |
| Consumer |  |  |  |  | 3,616 |  |  | 3,503 |  |  |  |
| Total CSG net revenue |  |  |  |  | $ | 15,587 |  |  | $ | 13,311 |  |  |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001571996-22-000021:notes:275]
SUPPLEMENTAL CONSOLIDATED FINANCIAL INFORMATION
The following table presents additional information on selected asset accounts included in the Condensed Consolidated Statements of Financial Position as of the dates indicated:

[0001571996-22-000021:notes:276]
|  | April 29, 2022 |  | January 28, 2022 |
|  | (in millions) |
| Cash, cash equivalents, and restricted cash: |  |  |  |
| Cash and cash equivalents | $ | 6,654 |  |  | $ | 9,477 |  |
| Restricted cash - other current assets (a) | 546 |  |  | 534 |  |
| Restricted cash - other non-current assets (a) | 76 |  |  | 71 |  |
| Total cash, cash equivalents, and restricted cash | $ | 7,276 |  |  | $ | 10,082 |  |
| Inventories, net: |  |  |  |
| Production materials | $ | 4,123 |  |  | $ | 3,653 |  |
| Work-in-process | 885 |  |  | 855 |  |
| Finished goods | 1,269 |  |  | 1,390 |  |
| Total inventories, net | $ | 6,277 |  |  | $ | 5,898 |  |
| Deferred Costs: |  |  |  |
| Total deferred costs, current (b) | $ | 4,979 |  |  | $ | 4,996 |  |
| Property, plant, and equipment, net: |  |  |  |
| Computer equipment | $ | 6,851 |  |  | $ | 6,497 |  |
| Land and buildings | 3,052 |  |  | 3,095 |  |
| Machinery and other equipment | 2,798 |  |  | 2,714 |  |
| Total property, plant, and equipment | 12,701 |  |  | 12,306 |  |
| Accumulated depreciation and amortization | (7,185) |  |  | (6,891) |  |
| Total property, plant, and equipment, net | $ | 5,516 |  |  | $ | 5,415 |  |

[0001571996-22-000021:notes:277]
(a)    Restricted cash includes cash required to be held in escrow pursuant to DFS securitization arrangements.

[0001571996-22-000021:notes:278]
(b)    Deferred costs are included in other current assets in the Condensed Consolidated Statements of Financial Position.

[0001571996-22-000021:notes:279]
[same as prior period, unchanged from 0001571996-21-000063:notes:295]

[0001571996-22-000021:notes:280]
[same as prior period, unchanged from 0001571996-21-000063:notes:296]

[0001571996-22-000021:notes:281]
|  |  |  | Three Months Ended |
|  |  |  |  |  | April 29, 2022 |  | April 30, 2021 |  |  |
|  |  |  |  |  | (in millions) |
| Warranty liability: |  |  |  |  |  |  |  |  |  |
| Warranty liability at beginning of period |  |  |  |  | $ | 480 |  |  | $ | 473 |  |  |  |
| Costs accrued for new warranty contracts and changes in estimates for pre-existing warranties (a) |  |  |  |  | 223 |  |  | 202 |  |  |  |
| Service obligations honored |  |  |  |  | (235) |  |  | (217) |  |  |  |
| Warranty liability at end of period |  |  |  |  | $ | 468 |  |  | $ | 458 |  |  |  |

[0001571996-22-000021:notes:282]
(a)Changes in cost estimates related to pre-existing warranties are aggregated with accruals for new standard warranty contracts.  The Company’s warranty liability process does not differentiate between estimates made for pre-existing warranties and those made for new warranty obligations.

[0001571996-22-000021:notes:283]
Interest and other, net

[0001571996-22-000021:notes:284]
The following table presents information regarding interest and other, net for the periods indicated:

[0001571996-22-000021:notes:285]
|  | Three Months Ended |
|  | April 29, 2022 |  | April 30, 2021 |  |  |
|  | (in millions) |
| Interest and other, net: |  |  |  |  |  |
| Investment income, primarily interest | $ | 15 |  |  | $ | 10 |  |  |  |
| Gain on investments, net | 14 |  |  | 193 |  |  |  |
| Interest expense | (265) |  |  | (433) |  |  |  |
| Foreign exchange | (89) |  |  | (52) |  |  |  |
| Other | (12) |  |  | (6) |  |  |  |
| Total interest and other, net | $ | (337) |  |  | $ | (288) |  |  |  |


## us-gaap:SubsequentEventsTextBlock

[0001571996-22-000021:notes:286]
SUBSEQUENT EVENTS There were no known events occurring after April 29, 2022 and up until the date of the issuance of this report that would materially affect the information presented herein.
