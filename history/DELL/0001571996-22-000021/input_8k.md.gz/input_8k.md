# DELL 8-K — 0001571996-22-000013 filed 2022-05-26

## item codes, every 8-K on or before 2022-06-06

- 2022-05-26 0001571996-22-000013 — 2.02, 9.01
- 2022-02-24 0001571996-22-000004 — 2.02, 8.01, 9.01
- 2021-12-20 0001193125-21-362482 — 8.01, 9.01
- 2021-12-15 0001193125-21-357927 — 1.01, 2.03, 9.01
- 2021-12-07 0001193125-21-349218 — 8.01, 9.01
- 2021-11-23 0001571996-21-000060 — 2.02, 9.01
- 2021-11-05 0001571996-21-000057 — 1.02, 2.01, 7.01, 8.01, 9.01 — amendment, the index does not say of what
- 2021-11-01 0001571996-21-000052 — 8.01, 9.01
- 2021-11-01 0001193125-21-315488 — 1.01, 1.02, 2.01, 8.01, 9.01
- 2021-10-21 0001193125-21-304052 — 8.01, 9.01
- 2021-10-19 0001571996-21-000050 — 8.01, 9.01
- 2021-10-07 0001193125-21-294210 — 8.01, 9.01
- 2021-09-30 0001571996-21-000047 — 5.02
- 2021-09-27 0001571996-21-000045 — 8.01
- 2021-09-23 0001193125-21-280190 — 7.01, 8.01, 9.01
- 2021-09-20 0001193125-21-276810 — 7.01, 9.01
- 2021-08-26 0001571996-21-000037 — 2.02, 9.01
- 2021-07-01 0001571996-21-000034 — 3.02
- 2021-06-24 0001571996-21-000031 — 5.07
- 2021-06-24 0001193125-21-197644 — 7.01, 9.01
- 2021-06-16 0001571996-21-000029 — 5.02
- 2021-05-27 0001571996-21-000019 — 2.02, 9.01
- 2021-05-03 0001571996-21-000010 — 8.01, 9.01
- 2021-04-14 0001193125-21-116271 — 1.01, 7.01, 9.01
- 2021-02-25 0001571996-21-000003 — 2.02, 9.01
- 2021-02-18 0001193125-21-047844 — 1.01, 2.03, 9.01
- 2020-11-24 0001571996-20-000048 — 2.02, 9.01
- 2020-08-27 0001571996-20-000041 — 2.02, 9.01
- 2020-07-02 0001571996-20-000037 — 5.07
- 2020-05-28 0001571996-20-000028 — 2.02, 9.01
- 2020-04-09 0001193125-20-102602 — 1.01, 2.03, 9.01
- 2020-04-08 0001571996-20-000021 — 5.02
- 2020-04-03 0001571996-20-000019 — 8.01, 9.01
- 2020-03-26 0001571996-20-000015 — 7.01
- 2020-02-27 0001571996-20-000009 — 2.02, 8.01, 9.01
- 2020-02-18 0001571996-20-000005 — 8.01, 9.01
- 2020-01-09 0001571996-20-000002 — 3.02
- 2020-01-06 0001193125-20-002200 — 3.02
- 2019-12-13 0001193125-19-313947 — 3.02
- 2019-12-10 0001571996-19-000052 — 5.02
- 2019-12-02 0001571996-19-000044 — 5.02, 7.01, 9.01
- 2019-11-26 0001571996-19-000042 — 2.02, 9.01
- 2019-09-23 0001193125-19-252192 — 1.01, 2.03, 9.01
- 2019-08-29 0001571996-19-000036 — 2.02, 9.01
- 2019-08-22 0001193125-19-226939 — 7.01, 8.01, 9.01
- 2019-07-11 0001571996-19-000032 — 5.02, 5.07, 9.01
- 2019-07-03 0001571996-19-000030 — 3.02
- 2019-06-27 0001571996-19-000028 — 3.02
- 2019-05-30 0001571996-19-000021 — 2.02, 9.01
- 2019-04-02 0001571996-19-000010 — 5.02
- 2019-03-21 0001193125-19-082281 — 1.01, 1.02, 2.03, 9.01
- 2019-03-19 0001571996-19-000005 — 5.02, 9.01
- 2019-03-14 0001193125-19-074935 — 1.01, 2.03, 9.01
- 2019-03-07 0001193125-19-066045 — 8.01, 9.01
- 2019-02-28 0001571996-19-000002 — 2.02, 9.01
- 2018-12-28 0001193125-18-360943 — 1.01, 1.02, 3.01, 3.03, 5.02, 5.03, 7.01, 8.01, 9.01
- 2018-12-21 0001193125-18-356324 — 1.01, 2.03, 9.01
- 2018-12-14 0001193125-18-349469 — 8.01
- 2018-12-11 0001193125-18-346958 — 5.07, 8.01, 9.01
- 2018-11-29 0001571996-18-000041 — 2.02, 9.01
- 2018-11-28 0001571996-18-000037 — 7.01, 8.01, 9.01
- 2018-11-26 0001193125-18-333967 — 8.01, 9.01
- 2018-11-15 0001193125-18-328110 — 1.01, 9.01 — amendment of 0001193125-18-327222
- 2018-11-15 0001193125-18-327222 — 1.01, 7.01, 9.01
- 2018-10-03 0001193125-18-291390 — 8.01
- 2018-09-06 0001571996-18-000029 — 2.02, 9.01
- 2018-08-06 0001571996-18-000027 — 8.01, 9.01
- 2018-07-02 0001193125-18-210339 — 1.01, 7.01, 9.01
- 2018-06-28 0001571996-18-000024 — 5.07
- 2018-06-04 0001571996-18-000019 — 2.02, 9.01
- 2018-05-17 0001571996-18-000016 — 7.01
- 2018-04-26 0001571996-18-000009 — 7.01, 9.01
- 2018-03-08 0001193125-18-074168 — 2.02, 9.01
- 2018-02-02 0001193125-18-029947 — 7.01, 9.01
- 2017-12-07 0001571996-17-000042 — 2.02, 9.01
- 2017-10-24 0001571996-17-000037 — 1.01, 2.03, 9.01
- 2017-09-15 0001571996-17-000027 — 5.02
- 2017-09-07 0001571996-17-000017 — 2.02, 9.01
- 2017-08-24 0001571996-17-000014 — 8.01
- 2017-06-29 0001571996-17-000011 — 3.03, 5.07, 8.01, 9.01
- 2017-06-08 0001193125-17-197638 — 2.02, 9.01
- 2017-03-30 0001193125-17-102794 — 8.01
- 2017-03-30 0001193125-17-102777 — 2.02, 9.01
- 2017-03-09 0001193125-17-076981 — 1.01, 2.03, 9.01
- 2017-01-17 0001193125-17-011125 — 8.01
- 2016-12-15 0001193125-16-793722 — 8.01
- 2016-12-08 0001193125-16-787976 — 2.02, 9.01
- 2016-11-10 0001193125-16-765964 — 1.02, 8.01
- 2016-11-04 0001193125-16-760249 — 8.01
- 2016-09-13 0001193125-16-708600 — 3.02
- 2016-09-09 0001193125-16-706567 — 1.01, 1.02, 2.01, 2.03, 3.02, 3.03, 5.02, 9.01
- 2016-09-07 0001193125-16-703370 — 3.03, 5.07, 7.01, 8.01, 9.01
- 2016-09-06 0001193125-16-702057 — 2.02, 9.01
- 2016-08-31 0001193125-16-697268 — 8.01, 9.01
- 2016-08-26 0001193125-16-692921 — 8.01, 9.01
- 2016-07-11 0001193125-16-645610 — 8.01
- 2016-07-05 0001193125-16-641679 — 8.01
- 2016-06-22 0001193125-16-629055 — 1.01, 2.03, 8.01, 9.01
- 2016-06-21 0001193125-16-627071 — 8.01, 9.01
- 2016-06-10 0001193125-16-618483 — 2.02, 9.01
- 2016-06-09 0001193125-16-617893 — 8.01, 9.01

## late-filing notifications on or before 2022-06-06

- none on or before 2022-06-06

## item 2.02 — earnings release, exhibit 99.1

[0001571996-22-000013:8k_2_02:1]
EX-99.1
2
exhibit991earnings8kq1fy23.htm
EX-99.1

[0001571996-22-000013:8k_2_02:2]
Document

[0001571996-22-000013:8k_2_02:3]
Exhibit 99.1

[0001571996-22-000013:8k_2_02:4]
Dell Technologies Delivers Record First Quarter Fiscal 2023 Financial Results

[0001571996-22-000013:8k_2_02:5]
News summary

[0001571996-22-000013:8k_2_02:6]
•Record first quarter revenue of $26.1 billion, up 16%, with growth across ISG and CSG

[0001571996-22-000013:8k_2_02:7]
•Record first quarter operating income of $1.6 billion, up 57%, and record first quarter non-GAAP operating income of $2.1 billion, up 21%

[0001571996-22-000013:8k_2_02:8]
•Record first quarter diluted earnings per share of $1.37, up 63%, and record non-GAAP diluted earnings per share of $1.84, up 36%

[0001571996-22-000013:8k_2_02:9]
ROUND ROCK, Texas — May 26, 2022

[0001571996-22-000013:8k_2_02:10]
Full story

[0001571996-22-000013:8k_2_02:11]
Dell Technologies (NYSE: DELL) announces financial results for its fiscal 2023 first quarter. Revenue was a first quarter record of $26.1 billion, up 16%, with growth across Infrastructure Solutions Group (ISG) and Client Solutions Group (CSG). The company generated record first quarter operating income of $1.6 billion, a 57% increase, and record non-GAAP operating income of $2.1 billion, up 21%. Net income from continuing operations was $1.1 billion, up 62%, and non-GAAP net income was $1.4 billion, up 36%, both driven by growth in operating income and lower interest expense due to reduced debt balances. Diluted earnings per share was $1.37, up 63%, and non-GAAP diluted earnings per share was $1.84, up 36%.

[0001571996-22-000013:8k_2_02:12]
Dell Technologies ended the quarter with remaining performance obligations of $42 billion, up 14% year-over-year, deferred revenue of $27.4 billion, and cash and investments of $8.5 billion. Recurring revenue for the first quarter was approximately $5.3 billion, up 15%.

[0001571996-22-000013:8k_2_02:13]
First Quarter Fiscal 2023 Financial Results

[0001571996-22-000013:8k_2_02:14]
|  | Three Months Ended |  |  |  |  |  |  |
|  | April 29, 2022 |  | April 30, 2021 |  | Change |  |  |  |  |  |  |
|  | (in millions, except per share amounts and percentages; unaudited) |
| Total net revenue | $ | 26,116 |  |  | $ | 22,590 |  |  | 16% |  |  |  |  |  |  |
| Operating income | $ | 1,550 |  |  | $ | 987 |  |  | 57% |  |  |  |  |  |  |
| Net income from continuing operations | $ | 1,069 |  |  | $ | 659 |  |  | 62% |  |  |  |  |  |  |
| Earnings per share - diluted | $ | 1.37 |  |  | $ | 0.84 |  |  | 63% |  |  |  |  |  |  |
| Non-GAAP net revenue | $ | 26,116 |  |  | $ | 22,598 |  |  | 16% |  |  |  |  |  |  |
| Non-GAAP operating income | $ | 2,135 |  |  | $ | 1,770 |  |  | 21% |  |  |  |  |  |  |
| Non-GAAP net income | $ | 1,434 |  |  | $ | 1,055 |  |  | 36% |  |  |  |  |  |  |
| Non-GAAP earnings per share - diluted | $ | 1.84 |  |  | $ | 1.35 |  |  | 36% |  |  |  |  |  |  |

[0001571996-22-000013:8k_2_02:15]
Information about Dell Technologies’ use of non-GAAP financial information is provided under “Non-GAAP Financial Measures” below.  All comparisons in this press release are year-over-year unless otherwise noted.

[0001571996-22-000013:8k_2_02:16]
Operating segments summary

[0001571996-22-000013:8k_2_02:17]
Infrastructure Solutions Group delivered record first quarter revenue of $9.3 billion, up 16%. Storage revenue was $4.2 billion, up 9%, with demand across the company’s broad storage portfolio. Servers and networking revenue was $5 billion, up 22% year-over-year. Operating income was $1.1 billion or approximately 11.7% of Infrastructure Solutions Group revenue.

[0001571996-22-000013:8k_2_02:18]
Key areas of innovation:

[0001571996-22-000013:8k_2_02:19]
•More than 500 storage software advancements across Dell PowerStore, PowerMax and PowerFlex to help customers deliver faster insights, achieve better multi-cloud data control and increase cyber resiliency.

[0001571996-22-000013:8k_2_02:20]
•APEX Cyber Recovery Services, the first in a series of APEX full stack solutions, offering customers a cloud experience and simplifying recovery from cyberattacks.

[0001571996-22-000013:8k_2_02:21]
•A collaboration with Snowflake will connect on-premises data from Dell’s industry-leading enterprise storage portfolio with the Snowflake Data Cloud.

[0001571996-22-000013:8k_2_02:22]
•Dell Telecom Multi-Cloud Foundation helps communications service providers (CSPs) build and deploy open, cloud-native networks faster with lower cost and complexity.

[0001571996-22-000013:8k_2_02:23]
•Dell Validated Design for Retail Edge helps retailers simplify edge infrastructure and launch new applications for better customer experiences.

[0001571996-22-000013:8k_2_02:24]
Client Solutions Group delivered record first quarter revenue of $15.6 billion, up 17% year-over-year. Performance was driven by continued strength in commercial PCs, with commercial PC revenue of $12 billion, a 22% increase year-over-year. Consumer revenue was $3.6 billion, a 3% increase year-over-year. Operating income was $1.1 billion, or approximately 7.2% of Client Solutions Group revenue.

[0001571996-22-000013:8k_2_02:25]
Key areas of innovation:

[0001571996-22-000013:8k_2_02:26]
•Dell Optimizer software, which is built into commercial PCs, integrates AI for increased privacy, connectivity and collaboration to provide greater intelligence for hybrid work styles.

[0001571996-22-000013:8k_2_02:27]
2

[0001571996-22-000013:8k_2_02:28]
•Latitude 9330, the world’s first laptop with a collaboration touchpad that lets users mute, turn video on/off, screen share and chat. Also announced the Latitude 5000 series, Dell’s most sustainable laptops yet, featuring the world’s most innovative use of sustainable materials.

[0001571996-22-000013:8k_2_02:29]
•New Precision mobile workstations for creators, engineers and architects – including the Precision 5470, the world’s smallest, thinnest and most powerful 14” mobile workstation. New 16- and 17-inch workstations offer a new form factor for DDR5 memory that enables a thinner chassis design and makes systems more accessible for repairs.

[0001571996-22-000013:8k_2_02:30]
•Asset Recovery Services expansion into 35 new countries across EMEA and APJ, includes new data sanitization offers and simplifies the asset disposal process of PCs, servers, peripherals and accessories.

[0001571996-22-000013:8k_2_02:31]
•New Latitude, Precision and XPS devices now ship with 100% recyclable packaging that is also made from 100% recycled or renewable materials.

[0001571996-22-000013:8k_2_02:32]
Executive Quotes:

[0001571996-22-000013:8k_2_02:33]
•“We followed a record FY22 with a record first quarter FY23. Revenue was $26.1 billion, up 16%, with growth across our business units,” said Jeff Clarke, vice chairman and co-chief operating officer, Dell Technologies. “We are built to outperform, in a balanced and consistent way across the company, as our customers invest in their digital futures and choose Dell as their trusted partner.”

[0001571996-22-000013:8k_2_02:34]
•“Our first quarter – with record Q1 revenue, operating income and diluted EPS – demonstrates the benefits of having a strong, geographically and sector-diverse business covering the edge to the core data center to the cloud,” said Chuck Whitten, co-chief operating officer. “Plus we are positioned to pursue growth wherever it materializes in the IT market, given the predictability, durability and flexibility in our business.”

[0001571996-22-000013:8k_2_02:35]
•“In our first quarter, we returned $1.75 billion to our shareholders through a combination of share repurchases and dividends,” said Tom Sweet, chief financial officer, Dell Technologies. “We are delivering long-term value by executing our strategy for growth, taking share, generating strong cash flow from operations and executing our capital allocation framework.”

[0001571996-22-000013:8k_2_02:36]
Conference call information

[0001571996-22-000013:8k_2_02:37]
As previously announced, the Company will hold a conference call to discuss its performance and financial guidance on May 26, 2022, at 4:30 p.m. CDT. The conference call will be broadcast live over the internet and can be accessed at

[0001571996-22-000013:8k_2_02:38]
https://investors.delltechnologies.com/events-and-presentations/upcoming-events

[0001571996-22-000013:8k_2_02:39]
For those unable to listen to the live broadcast, an archived version will be available at the same location for one year.

[0001571996-22-000013:8k_2_02:40]
Additional financial and operating information may be downloaded from

[0001571996-22-000013:8k_2_02:41]
https://investors.delltechnologies.com/financial-information/quarterly-results

[0001571996-22-000013:8k_2_02:42]
Customer Highlights Blog

[0001571996-22-000013:8k_2_02:43]
Read our quarterly blog from Bill Scannell, Dell Technologies president of Global Sales & Customer Operations, to learn more about how we are helping customers with their digital transformations:

[0001571996-22-000013:8k_2_02:44]
https://www.dell.com/en-us/blog/accelerating-customer-transformation-at-the-center-of-multi-cloud/

[0001571996-22-000013:8k_2_02:45]
Environmental, Social and Governance (ESG)

[0001571996-22-000013:8k_2_02:46]
Our Environmental, Social and Governance (ESG) efforts focus on driving positive impact for people and our planet while delivering long-term value for our stakeholders. The FY22 ESG report will publish June 30, 2022, and the Company will hold a conference call to discuss the report in July. ESG resources can be accessed at

[0001571996-22-000013:8k_2_02:47]
https://www.dell.com/en-us/dt/corporate/social-impact/reporting/esg-governance.htm

[0001571996-22-000013:8k_2_02:48]
About Dell Technologies

[0001571996-22-000013:8k_2_02:49]
Dell Technologies (NYSE:DELL) helps organizations and individuals build their digital future and transform how they work, live and play. The company provides customers with the industry’s broadest and most innovative technology and services portfolio for the data era.

[0001571996-22-000013:8k_2_02:50]
Contacts

[0001571996-22-000013:8k_2_02:51]
Investors: Investor_Relations@Dell.com

[0001571996-22-000013:8k_2_02:52]
Media: Media.Relations@Dell.com

[0001571996-22-000013:8k_2_02:53]
# # #

[0001571996-22-000013:8k_2_02:54]
Copyright © 2022 Dell Inc. or its subsidiaries. All Rights Reserved. Dell Technologies, Dell, EMC and Dell EMC are trademarks of Dell Inc. or its subsidiaries. Other trademarks may be trademarks of their respective owners.

[0001571996-22-000013:8k_2_02:55]
Non-GAAP Financial Measures:

[0001571996-22-000013:8k_2_02:56]
This press release presents information about Dell Technologies’ non-GAAP net revenue, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, non-GAAP net income attributable to non-controlling interests, non-GAAP net income attributable to Dell Technologies Inc. - basic, non-GAAP net income attributable to Dell Technologies Inc. - diluted, non-GAAP earnings per share attributable to Dell Technologies Inc. - basic, and non-GAAP earnings per share attributable to Dell Technologies Inc. - diluted, which are non-GAAP financial measures provided as a supplement to the results provided in accordance with generally accepted accounting principles in the United States of America (“GAAP”). A reconciliation of each non-GAAP financial measure to the most directly comparable GAAP financial measure is provided in the attached tables for each of the fiscal periods indicated.

[0001571996-22-000013:8k_2_02:57]
Special Note on Forward-Looking Statements:

[0001571996-22-000013:8k_2_02:58]
Dell Technologies’ results or events in future periods could differ materially from those expressed or implied by these forward-looking statements because of risks, uncertainties, and other factors that include, but are not limited to, the following: risks and uncertainties relating to our spin-off of VMware, Inc., including the potential effects on our business of the transaction; the effects of the COVID-19 pandemic; competitive pressures; Dell Technologies’ reliance on third-party suppliers for products and components, including reliance on single-source or limited-source suppliers; Dell Technologies’ ability to achieve favorable pricing from its vendors; adverse global economic conditions and instability in financial markets; Dell Technologies’ execution of its growth, business and acquisition strategies; the success of Dell Technologies’ cost efficiency measures; Dell Technologies’ ability to manage solutions and products and services transitions in an effective manner; Dell Technologies’ ability to deliver high-quality products, software, and services; cyber attacks or other data security incidents; Dell Technologies’ foreign operations and ability to generate substantial non-U.S. net revenue; Dell Technologies’ product, services, customer, and geographic sales mix, and seasonal sales trends; the performance of Dell Technologies’ sales channel partners; access to the capital markets by Dell Technologies or its customers; material impairment of the value of goodwill or intangible assets; weak economic conditions and the effect of additional regulation on Dell Technologies’ financial services activities; counterparty default risks; the loss by Dell Technologies of any contracts for ISG services and solutions and its ability to perform such contracts at their estimated costs; loss by Dell Technologies of government contracts; Dell Technologies’ ability to develop and protect its proprietary intellectual property or obtain licenses to intellectual property developed by others on commercially reasonable and competitive terms; disruptions in Dell Technologies’ infrastructure; Dell Technologies’ ability to hedge effectively its exposure to fluctuations in foreign currency exchange rates and interest rates; expiration of tax holidays or favorable tax rate structures, or unfavorable outcomes in tax audits and other tax compliance matters; impairment of portfolio investments; unfavorable results of legal proceedings; compliance requirements of changing environmental and safety laws or other laws; the effect of armed hostilities, terrorism, natural disasters, and public health issues; the effect of global climate change and legal, regulatory, or market measures to address climate change; Dell Technologies’ dependence on the services of Michael Dell and key employees; Dell Technologies’ level of indebtedness; the effect of the transition from LIBOR as a reference rate to calculate interest

[0001571996-22-000013:8k_2_02:59]
4

[0001571996-22-000013:8k_2_02:60]
rates under our variable-rate indebtedness; and business and financial factors and legal restrictions affecting continuation of Dell Technologies’ quarterly cash dividend policy and dividend rate.

[0001571996-22-000013:8k_2_02:61]
This list of risks, uncertainties, and other factors is not complete. Dell Technologies discusses some of these matters more fully, as well as certain risk factors that could affect Dell Technologies’ business, financial condition, results of operations, and prospects, in its reports filed with the SEC, including Dell Technologies’ annual report on Form 10-K for the fiscal year ended January 28, 2022, quarterly reports on Form 10-Q, and current reports on Form 8-K. These filings are available for review through the SEC’s website at www.sec.gov. Any or all forward-looking statements Dell Technologies makes may turn out to be wrong and can be affected by inaccurate assumptions Dell Technologies might make or by known or unknown risks, uncertainties and other factors, including those identified in this press release. Accordingly, you should not place undue reliance on the forward-looking statements made in this press release, which speak only as of its date. Dell Technologies does not undertake to update, and expressly disclaims any duty to update, its forward-looking statements, whether as a result of circumstances or events that arise after the date they are made, new information, or otherwise.

[0001571996-22-000013:8k_2_02:62]
5

[0001571996-22-000013:8k_2_02:63]
DELL TECHNOLOGIES INC. FINANCIAL INFORMATION

[0001571996-22-000013:8k_2_02:64]
Basis of Presentation

[0001571996-22-000013:8k_2_02:65]
Spin-Off of VMware, Inc. — On November 1, 2021, Dell Technologies Inc. completed its spin-off of VMware, Inc. by means of a special stock dividend (the “VMware Spin-off”). The VMware Spin-off was effectuated pursuant to a Separation and Distribution Agreement, dated as of April 14, 2021.

[0001571996-22-000013:8k_2_02:66]
In accordance with applicable accounting guidance, the results of VMware, excluding Dell's resale of VMware offerings, are presented as discontinued operations in the Condensed Consolidated Statements of Income and, as such, have been excluded from both continuing operations and segment results for the three months ended April 30, 2021.  The Condensed Consolidated Statements of Cash Flows are presented on a consolidated basis for both continuing operations and discontinued operations.

[0001571996-22-000013:8k_2_02:67]
6

[0001571996-22-000013:8k_2_02:68]
DELL TECHNOLOGIES INC.

[0001571996-22-000013:8k_2_02:69]
Consolidated Statements of Income and Related Financial Highlights

[0001571996-22-000013:8k_2_02:70]
(in millions, except percentages; unaudited)

[0001571996-22-000013:8k_2_02:71]
|  | Three Months Ended |  |  |  |  |  |  |
|  | April 29, 2022 |  | April 30, 2021 |  | Change |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Products | $ | 20,464 |  | $ | 17,487 |  | 17% |  |  |  |  |  |  |
| Services | 5,652 |  | 5,103 |  | 11% |  |  |  |  |  |  |
| Total net revenue | 26,116 |  | 22,590 |  | 16% |  |  |  |  |  |  |
| Cost of net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Products | 17,009 |  | 14,434 |  | 18% |  |  |  |  |  |  |
| Services | 3,323 |  | 2,892 |  | 15% |  |  |  |  |  |  |
| Total cost of net revenue | 20,332 |  | 17,326 |  | 17% |  |  |  |  |  |  |
| Gross margin | 5,784 |  | 5,264 |  | 10% |  |  |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative | 3,553 |  | 3,658 |  | (3)% |  |  |  |  |  |  |
| Research and development | 681 |  | 619 |  | 10% |  |  |  |  |  |  |
| Total operating expenses | 4,234 |  | 4,277 |  | (1)% |  |  |  |  |  |  |
| Operating income | 1,550 |  | 987 |  | 57% |  |  |  |  |  |  |
| Interest and other, net | (337) |  | (288) |  | (17)% |  |  |  |  |  |  |
| Income before income taxes | 1,213 |  | 699 |  | 74% |  |  |  |  |  |  |
| Income tax expense | 144 |  | 40 |  | 260% |  |  |  |  |  |  |
| Net income from continuing operations | 1,069 |  | 659 |  | 62% |  |  |  |  |  |  |
| Income from discontinued operations, net of income taxes | — |  | 279 |  | (100)% |  |  |  |  |  |  |
| Net income | 1,069 |  | 938 |  | 14% |  |  |  |  |  |  |
| Less: Net loss attributable to non-controlling interests | (3) |  | (1) |  | (200)% |  |  |  |  |  |  |
| Less: Net income attributable to non-controlling interests of discontinued operations | — |  | 52 |  | (100)% |  |  |  |  |  |  |
| Net income attributable to Dell Technologies Inc. | $ | 1,072 |  | $ | 887 |  | 21% |  |  |  |  |  |  |
| Percentage of Total Net Revenue: |  |  |  |  |  |  |  |  |  |  |
| Gross margin | 22.1 | % |  | 23.3 | % |  |  |  |  |  |  |  |  |
| Selling, general, and administrative | 13.6 | % |  | 16.2 | % |  |  |  |  |  |  |  |  |
| Research and development | 2.6 | % |  | 2.7 | % |  |  |  |  |  |  |  |  |
| Operating expenses | 16.2 | % |  | 18.9 | % |  |  |  |  |  |  |  |  |
| Operating income | 5.9 | % |  | 4.4 | % |  |  |  |  |  |  |  |  |
| Income before income taxes | 4.6 | % |  | 3.1 | % |  |  |  |  |  |  |  |  |
| Net income from continuing operations | 4.1 | % |  | 2.9 | % |  |  |  |  |  |  |  |  |
| Income tax rate | 11.9 | % |  | 5.7 | % |  |  |  |  |  |  |  |  |

[0001571996-22-000013:8k_2_02:72]
Amounts are based on underlying data and may not visually foot due to rounding.

[0001571996-22-000013:8k_2_02:73]
7

[0001571996-22-000013:8k_2_02:74]
DELL TECHNOLOGIES INC.

[0001571996-22-000013:8k_2_02:75]
Consolidated Statements of Financial Position

[0001571996-22-000013:8k_2_02:76]
(in millions; unaudited)

[0001571996-22-000013:8k_2_02:77]
|  | April 29, 2022 |  | January 28, 2022 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 6,654 |  |  | $ | 9,477 |  |
| Accounts receivable, net | 11,837 |  |  | 12,912 |  |
| Due from related party, net | 131 |  |  | 131 |  |
| Short-term financing receivables, net | 4,796 |  |  | 5,089 |  |
| Inventories | 6,277 |  |  | 5,898 |  |
| Other current assets | 11,681 |  |  | 11,526 |  |
| Total current assets | 41,376 |  |  | 45,033 |  |
| Property, plant, and equipment, net | 5,516 |  |  | 5,415 |  |
| Long-term investments | 1,868 |  |  | 1,839 |  |
| Long-term financing receivables, net | 5,398 |  |  | 5,522 |  |
| Goodwill | 19,598 |  |  | 19,770 |  |
| Intangible assets, net | 7,217 |  |  | 7,461 |  |
| Due from related party, net | 713 |  |  | 710 |  |
| Other non-current assets | 6,720 |  |  | 6,985 |  |
| Total assets | $ | 88,406 |  |  | $ | 92,735 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Short-term debt | $ | 5,925 |  |  | $ | 5,823 |  |
| Accounts payable | 25,585 |  |  | 27,143 |  |
| Due to related party | 622 |  |  | 1,414 |  |
| Accrued and other | 6,598 |  |  | 7,578 |  |
| Short-term deferred revenue | 14,329 |  |  | 14,261 |  |
| Total current liabilities | 53,059 |  |  | 56,219 |  |
| Long-term debt | 21,197 |  |  | 21,131 |  |
| Long-term deferred revenue | 13,074 |  |  | 13,312 |  |
| Other non-current liabilities | 3,431 |  |  | 3,653 |  |
| Total liabilities | 90,761 |  |  | 94,315 |  |
| Stockholders’ equity (deficit): |  |  |  |
| Total Dell Technologies Inc. stockholders’ equity (deficit) | (2,462) |  |  | (1,685) |  |
| Non-controlling interests | 107 |  |  | 105 |  |
| Total stockholders’ equity (deficit) | (2,355) |  |  | (1,580) |  |
| Total liabilities and stockholders’ equity | $ | 88,406 |  |  | $ | 92,735 |  |

[0001571996-22-000013:8k_2_02:78]
8

[0001571996-22-000013:8k_2_02:79]
DELL TECHNOLOGIES INC.

[0001571996-22-000013:8k_2_02:80]
Consolidated Statements of Cash Flows

[0001571996-22-000013:8k_2_02:81]
(in millions; unaudited)

[0001571996-22-000013:8k_2_02:82]
|  | Three Months Ended |  |  |
|  | April 29, 2022 |  | April 30, 2021 |  |  |  |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |
| Net income | $ | 1,069 |  |  | $ | 938 |  |  |  |  |  |
| Adjustments to reconcile net income to net cash provided by operating activities: | (1,338) |  |  | 1,300 |  |  |  |  |  |
| Change in cash from operating activities | (269) |  |  | 2,238 |  |  |  |  |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |
| Purchases of investments | (52) |  |  | (146) |  |  |  |  |  |
| Maturities and sales of investments | 18 |  |  | 256 |  |  |  |  |  |
| Capital expenditures and capitalized software development costs | (690) |  |  | (625) |  |  |  |  |  |
| Acquisition of businesses and assets, net | — |  |  | (10) |  |  |  |  |  |
| Other | 4 |  |  | 6 |  |  |  |  |  |
| Change in cash from investing activities | (720) |  |  | (519) |  |  |  |  |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |
| Proceeds from the issuance of common stock | 4 |  |  | 160 |  |  |  |  |  |
| Repurchases of parent common stock (a) | (1,779) |  |  | (9) |  |  |  |  |  |
| Repurchases of subsidiary common stock (a) | (7) |  |  | (434) |  |  |  |  |  |
| Payment of dividend to stockholders | (248) |  |  | — |  |  |  |  |  |
| Proceeds from debt | 3,034 |  |  | 2,726 |  |  |  |  |  |
| Repayments of debt | (2,703) |  |  | (4,070) |  |  |  |  |  |
| Debt-related costs and other, net | (7) |  |  | (11) |  |  |  |  |  |
| Change in cash from financing activities | (1,706) |  |  | (1,638) |  |  |  |  |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash | (111) |  |  | (5) |  |  |  |  |  |
| Change in cash, cash equivalents, and restricted cash | (2,806) |  |  | 76 |  |  |  |  |  |
| Cash, cash equivalents, and restricted cash at beginning of the period, including cash attributable to discontinued operations | 10,082 |  |  | 15,184 |  |  |  |  |  |
| Cash, cash equivalents, and restricted cash at end of the period, including cash attributable to discontinued operations | 7,276 |  |  | 15,260 |  |  |  |  |  |
| Less: Cash, cash equivalents, and restricted cash attributable to discontinued operations | — |  |  | 5,667 |  |  |  |  |  |
| Cash, cash equivalents, and restricted cash from continuing operations | $ | 7,276 |  |  | $ | 9,593 |  |  |  |  |  |

[0001571996-22-000013:8k_2_02:83]
_________________

[0001571996-22-000013:8k_2_02:84]
(a)Common stock repurchases are inclusive of employee tax withholding on stock-based compensation.

[0001571996-22-000013:8k_2_02:85]
9

[0001571996-22-000013:8k_2_02:86]
DELL TECHNOLOGIES INC.

[0001571996-22-000013:8k_2_02:87]
Segment Information

[0001571996-22-000013:8k_2_02:88]
(in millions, except percentages; unaudited; continued on next page)

[0001571996-22-000013:8k_2_02:89]
|  | Three Months Ended |  |  |  |  |  |  |
|  | April 29, 2022 |  | April 30, 2021 |  | Change |  |  |  |  |  |  |
| Infrastructure Solutions Group (ISG): |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Servers and networking | $ | 5,048 |  |  | $ | 4,140 |  |  | 22% |  |  |  |  |  |  |
| Storage | 4,237 |  |  | 3,893 |  |  | 9% |  |  |  |  |  |  |
| Total ISG net revenue | $ | 9,285 |  |  | $ | 8,033 |  |  | 16% |  |  |  |  |  |  |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| ISG operating income | $ | 1,082 |  |  | $ | 778 |  |  | 39% |  |  |  |  |  |  |
| % of ISG net revenue | 11.7 | % |  | 9.7 | % |  |  |  |  |  |  |  |  |
| % of total reportable segment operating income | 49 | % |  | 42 | % |  |  |  |  |  |  |  |  |
| Client Solutions Group (CSG): |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 11,971 |  |  | $ | 9,808 |  |  | 22% |  |  |  |  |  |  |
| Consumer | 3,616 |  |  | 3,503 |  |  | 3% |  |  |  |  |  |  |
| Total CSG net revenue | $ | 15,587 |  |  | $ | 13,311 |  |  | 17% |  |  |  |  |  |  |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| CSG operating income | $ | 1,115 |  |  | $ | 1,080 |  |  | 3% |  |  |  |  |  |  |
| % of CSG net revenue | 7.2 | % |  | 8.1 | % |  |  |  |  |  |  |  |  |
| % of total reportable segment operating income | 51 | % |  | 58 | % |  |  |  |  |  |  |  |  |

[0001571996-22-000013:8k_2_02:90]
Amounts are based on underlying data and may not visually foot due to rounding.

[0001571996-22-000013:8k_2_02:91]
DELL TECHNOLOGIES INC.

[0001571996-22-000013:8k_2_02:92]
Segment Information

[0001571996-22-000013:8k_2_02:93]
(in millions, except percentages; unaudited; continued)

[0001571996-22-000013:8k_2_02:94]
|  | Three Months Ended |  |  |
|  | April 29, 2022 |  | April 30, 2021 |  |  |  |  |
| Reconciliation to consolidated net revenue: |  |  |  |  |  |  |
| Reportable segment net revenue | $ | 24,872 |  |  | $ | 21,344 |  |  |  |  |  |
| Other businesses (a) | 1,239 |  |  | 1,252 |  |  |  |  |  |
| Unallocated transactions (b) | 5 |  |  | 2 |  |  |  |  |  |
| Impact of purchase accounting (c) | — |  |  | (8) |  |  |  |  |  |
| Total consolidated net revenue | $ | 26,116 |  |  | $ | 22,590 |  |  |  |  |  |
| Reconciliation to consolidated operating income: |  |  |  |  |  |  |  |
| Reportable segment operating income | $ | 2,197 |  |  | $ | 1,858 |  |  |  |  |  |
| Other businesses (a) | (64) |  |  | (90) |  |  |  |  |  |
| Unallocated transactions (b) | 2 |  |  | 2 |  |  |  |  |  |
| Impact of purchase accounting (c) | (9) |  |  | (20) |  |  |  |  |  |
| Amortization of intangibles | (243) |  |  | (445) |  |  |  |  |  |
| Transaction-related expenses (d) | (5) |  |  | (29) |  |  |  |  |  |
| Stock-based compensation expense (e) | (232) |  |  | (172) |  |  |  |  |  |
| Other corporate expenses (f) | (96) |  |  | (117) |  |  |  |  |  |
| Total consolidated operating income | $ | 1,550 |  |  | $ | 987 |  |  |  |  |  |

[0001571996-22-000013:8k_2_02:95]
_________________

[0001571996-22-000013:8k_2_02:96]
(a)Other businesses consists of: 1) Dell’s resale of standalone VMware, Inc. products and services, “VMware Resale”, 2) Secureworks, and 3) Virtustream, and do not meet the requirements for a reportable segment, either individually or collectively.

[0001571996-22-000013:8k_2_02:97]
(b)Unallocated transactions includes other corporate items that are not allocated to Dell Technologies’ reportable segments.

[0001571996-22-000013:8k_2_02:98]
(c)Impact of purchase accounting includes non-cash purchase accounting adjustments that are primarily related to the EMC merger transaction.

[0001571996-22-000013:8k_2_02:99]
(d)Transaction-related expenses includes acquisition, integration, and divestiture related costs.

[0001571996-22-000013:8k_2_02:100]
(e)Stock-based compensation expense consists of equity awards granted based on the estimated fair value of those awards at grant date.

[0001571996-22-000013:8k_2_02:101]
(f)Other corporate expenses includes impairment charges, incentive charges related to equity investments, severance, payroll taxes associated with stock-based compensation, facilities action, and other costs.

[0001571996-22-000013:8k_2_02:102]
SUPPLEMENTAL SELECTED NON-GAAP FINANCIAL MEASURES

[0001571996-22-000013:8k_2_02:103]
These tables present information about the Company’s non-GAAP net revenue, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, non-GAAP net income attributable to Dell Technologies Inc. - basic and diluted, non-GAAP earnings per share attributable to Dell Technologies Inc. - basic, and non-GAAP earnings per share attributable to Dell Technologies Inc. - diluted which are non-GAAP financial measures provided as a supplement to the results provided in accordance with generally accepted accounting principles in the United States of America (“GAAP”). A detailed discussion of Dell Technologies’ reasons for including these non-GAAP financial measures, the limitations associated with these measures, the items excluded from these measures, and our reason for excluding those items are presented in “Management’s Discussion and Analysis of Financial Condition and Results of Operations — Non-GAAP Financial Measures” in our periodic reports filed with the SEC. Dell Technologies encourages investors to review the non-GAAP discussion in these reports in conjunction with the presentation of non-GAAP financial measures.

[0001571996-22-000013:8k_2_02:104]
12

[0001571996-22-000013:8k_2_02:105]
DELL TECHNOLOGIES INC.

[0001571996-22-000013:8k_2_02:106]
Selected Non-GAAP Financial Measures

[0001571996-22-000013:8k_2_02:107]
(in millions, except per share amounts and percentages; unaudited)

[0001571996-22-000013:8k_2_02:108]
|  | Three Months Ended |  |  |  |  |  |  |
|  | April 29, 2022 |  | April 30, 2021 |  | Change |  |  |  |  |  |  |
| Non-GAAP net revenue | $ | 26,116 |  | $ | 22,598 |  | 16% |  |  |  |  |  |  |
| Non-GAAP gross margin | $ | 5,941 |  | $ | 5,464 |  | 9% |  |  |  |  |  |  |
| % of non-GAAP net revenue | 22.7 | % |  | 24.2 | % |  |  |  |  |  |  |  |  |
| Non-GAAP operating expenses | $ | 3,806 |  | $ | 3,694 |  | 3% |  |  |  |  |  |  |
| % of non-GAAP net revenue | 14.5 | % |  | 16.4 | % |  |  |  |  |  |  |  |  |
| Non-GAAP operating income | $ | 2,135 |  | $ | 1,770 |  | 21% |  |  |  |  |  |  |
| % of non-GAAP net revenue | 8.2 | % |  | 7.8 | % |  |  |  |  |  |  |  |  |
| Non-GAAP net income | $ | 1,434 |  | $ | 1,055 |  | 36% |  |  |  |  |  |  |
| % of non-GAAP net revenue | 5.5 | % |  | 4.7 | % |  |  |  |  |  |  |  |  |
| Non-GAAP earnings per share - diluted | $ | 1.84 |  | $ | 1.35 |  | 36% |  |  |  |  |  |  |

[0001571996-22-000013:8k_2_02:109]
Amounts are based on underlying data and may not visually foot due to rounding.

[0001571996-22-000013:8k_2_02:110]
13

[0001571996-22-000013:8k_2_02:111]
DELL TECHNOLOGIES INC.

[0001571996-22-000013:8k_2_02:112]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-22-000013:8k_2_02:113]
(in millions, except percentages; unaudited; continued on next page)

[0001571996-22-000013:8k_2_02:114]
|  | Three Months Ended |  |  |  |  |  |  |
|  | April 29, 2022 |  | April 30, 2021 |  | Change |  |  |  |  |  |  |
| Net revenue | $ | 26,116 |  |  | $ | 22,590 |  |  | 16% |  |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | — |  |  | 8 |  |  |  |  |  |  |  |  |  |
| Non-GAAP net revenue | $ | 26,116 |  |  | $ | 22,598 |  |  | 16% |  |  |  |  |  |  |
| Gross margin | $ | 5,784 |  |  | $ | 5,264 |  |  | 10% |  |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 104 |  |  | 150 |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 2 |  |  | 9 |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense | 38 |  |  | 28 |  |  |  |  |  |  |  |  |  |
| Other corporate expenses | 13 |  |  | 13 |  |  |  |  |  |  |  |  |  |
| Non-GAAP gross margin | $ | 5,941 |  |  | $ | 5,464 |  |  | 9% |  |  |  |  |  |  |
| Operating expenses | $ | 4,234 |  |  | $ | 4,277 |  |  | (1)% |  |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | (139) |  |  | (295) |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | (7) |  |  | (11) |  |  |  |  |  |  |  |  |  |
| Transaction-related expenses | (5) |  |  | (29) |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense | (194) |  |  | (144) |  |  |  |  |  |  |  |  |  |
| Other corporate expenses | (83) |  |  | (104) |  |  |  |  |  |  |  |  |  |
| Non-GAAP operating expenses | $ | 3,806 |  |  | $ | 3,694 |  |  | 3% |  |  |  |  |  |  |
| Operating income | $ | 1,550 |  |  | $ | 987 |  |  | 57% |  |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 243 |  |  | 445 |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 9 |  |  | 20 |  |  |  |  |  |  |  |  |  |
| Transaction-related (income) expenses | 5 |  |  | 29 |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense | 232 |  |  | 172 |  |  |  |  |  |  |  |  |  |
| Other corporate expenses | 96 |  |  | 117 |  |  |  |  |  |  |  |  |  |
| Non-GAAP operating income | $ | 2,135 |  |  | $ | 1,770 |  |  | 21% |  |  |  |  |  |  |

[0001571996-22-000013:8k_2_02:115]
14

[0001571996-22-000013:8k_2_02:116]
DELL TECHNOLOGIES INC.

[0001571996-22-000013:8k_2_02:117]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-22-000013:8k_2_02:118]
(in millions, except percentages; unaudited; continued)

[0001571996-22-000013:8k_2_02:119]
|  | Three Months Ended |  |  |  |  |  |  |
|  | April 29, 2022 |  | April 30, 2021 |  | Change |  |  |  |  |  |  |
| Net income from continuing operations | $ | 1,069 |  |  | $ | 659 |  |  | 62% |  |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 243 |  |  | 445 |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 9 |  |  | 20 |  |  |  |  |  |  |  |  |  |
| Transaction-related (income) expenses | (2) |  |  | 29 |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense | 232 |  |  | 172 |  |  |  |  |  |  |  |  |  |
| Other corporate expenses | 96 |  |  | 117 |  |  |  |  |  |  |  |  |  |
| Fair value adjustments on equity investments | (14) |  |  | (194) |  |  |  |  |  |  |  |  |  |
| Aggregate adjustment for income taxes | (199) |  |  | (193) |  |  |  |  |  |  |  |  |  |
| Non-GAAP net income | $ | 1,434 |  |  | $ | 1,055 |  |  | 36% |  |  |  |  |  |  |
| Net income from continuing operations attributable to Dell Technologies Inc. | $ | 1,072 |  |  | $ | 660 |  |  | 62% |  |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 243 |  |  | 445 |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 9 |  |  | 20 |  |  |  |  |  |  |  |  |  |
| Transaction-related (income) expenses | (2) |  |  | 29 |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense | 232 |  |  | 172 |  |  |  |  |  |  |  |  |  |
| Other corporate expenses | 96 |  |  | 117 |  |  |  |  |  |  |  |  |  |
| Fair value adjustments on equity investments | (14) |  |  | (194) |  |  |  |  |  |  |  |  |  |
| Aggregate adjustment for income taxes | (199) |  |  | (193) |  |  |  |  |  |  |  |  |  |
| Total non-GAAP adjustments attributable to non-controlling interests | (2) |  |  | (1) |  |  |  |  |  |  |  |  |  |
| Non-GAAP net income attributable to Dell Technologies Inc. | $ | 1,435 |  |  | $ | 1,055 |  |  | 36% |  |  |  |  |  |  |

[0001571996-22-000013:8k_2_02:120]
DELL TECHNOLOGIES INC.

[0001571996-22-000013:8k_2_02:121]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-22-000013:8k_2_02:122]
(in millions, except percentages and per share amounts; unaudited; continued)

[0001571996-22-000013:8k_2_02:123]
|  | Three Months Ended |  |  |  |  |  |  |
|  | April 29, 2022 |  | April 30, 2021 |  | Change |  |  |  |  |  |  |
| Earnings per share from continuing operations attributable to Dell Technologies Inc. |  |  |  |  |
| Net income from continuing operations attributable to Dell Technologies Inc. — basic | $ | 1,072 |  |  | $ | 660 |  |  |  |  |  |  |  |  |  |
| Weighted-average shares outstanding — basic | 754 |  | 757 |  |  |  |  |  |  |  |  |
| Earnings per share attributable to Dell Technologies Inc. — basic | $ | 1.42 |  |  | $ | 0.87 |  |  | 63% |  |  |  |  |  |  |
| Net income from continuing operations attributable to Dell Technologies Inc. — diluted | $ | 1,072 |  |  | $ | 660 |  |  |  |  |  |  |  |  |  |
| Weighted-average shares outstanding — diluted | 780 |  | 782 |  |  |  |  |  |  |  |  |
| Earnings per share attributable to Dell Technologies Inc. — diluted: | $ | 1.37 |  |  | $ | 0.84 |  |  | 63% |  |  |  |  |  |  |
| Earnings per share from discontinued operations attributable to Dell Technologies Inc. |  |  |  |  |
| Net income from discontinued operations attributable to Dell Technologies Inc. — basic | $ | — |  |  | $ | 227 |  |  |  |  |  |  |  |  |  |
| Weighted-average shares outstanding — basic | — |  |  | 757 |  |  |  |  |  |  |  |  |
| Earnings per share attributable to Dell Technologies Inc. — basic | $ | — |  |  | $ | 0.30 |  |  | NM |  |  |  |  |  |  |
| Incremental dilution from VMware, Inc. attributable to Dell Technologies | — |  |  | (2) |  |  |  |  |  |  |  |  |  |
| Net income from discontinued operations attributable to Dell Technologies Inc. — diluted | $ | — |  |  | $ | 225 |  |  |  |  |  |  |  |  |  |
| Weighted-average shares outstanding — diluted | — |  |  | 782 |  |  |  |  |  |  |  |  |
| Earnings per share attributable to Dell Technologies Inc. — diluted | $ | — |  |  | $ | 0.29 |  |  | NM |  |  |  |  |  |  |
| Non-GAAP earnings per share attributable to Dell Technologies Inc. |  |  |
| Non-GAAP net income attributable to Dell Technologies Inc. — basic | $ | 1,435 |  |  | $ | 1,055 |  |  |  |  |  |  |  |  |  |
| Weighted-average shares outstanding — basic | 754 |  | 757 |  |  |  |  |  |  |  |  |
| Earnings per share attributable to Dell Technologies Inc. — basic | $ | 1.90 |  |  | $ | 1.39 |  |  | 37% |  |  |  |  |  |  |
| Non-GAAP net income attributable to Dell Technologies Inc. — diluted | $ | 1,435 |  |  | $ | 1,055 |  |  |  |  |  |  |  |  |  |
| Weighted-average shares outstanding — diluted | 780 |  | 782 |  |  |  |  |  |  |  |  |
| Earnings per share attributable to Dell Technologies Inc. — diluted | $ | 1.84 |  |  | $ | 1.35 |  |  | 36% |  |  |  |  |  |  |

[0001571996-22-000013:8k_2_02:124]
Amounts may not visually recalculate due to rounding.

[0001571996-22-000013:8k_2_02:125]
16
