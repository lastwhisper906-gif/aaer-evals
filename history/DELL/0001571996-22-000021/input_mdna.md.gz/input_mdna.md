# DELL MD&A — 0001571996-22-000021


## mdna

[0001571996-22-000021:mdna:1]
[same as prior period, unchanged from 0001571996-21-000063:mdna:1]

[0001571996-22-000021:mdna:2]
[same as prior period, unchanged from 0001571996-21-000063:mdna:2]

[0001571996-22-000021:mdna:3]
[same as prior period, unchanged from 0001571996-21-000063:mdna:3]

[0001571996-22-000021:mdna:4]
On November 1, 2021, the Company completed its spin-off of VMware, Inc (“VMware”).  In accordance with applicable accounting guidance, the results of VMware, excluding Dell's resale of VMware offerings, are presented as discontinued operations in the Condensed Consolidated Statements of Income and, as such, have been excluded from both continuing operations and segment results for prior periods presented.  The Condensed Consolidated Statements of Cash Flows are presented on a consolidated basis for both continuing operations and discontinued operations.

[0001571996-22-000021:mdna:5]
Our fiscal year is the 52- or 53-week period ending on the Friday nearest January 31.  We refer to our fiscal year ending February 3, 2023 as “Fiscal 2023” and our fiscal year ended January 28, 2022 as “Fiscal 2022.”  Fiscal 2023 includes 53 weeks and Fiscal 2022 includes 52 weeks.

[0001571996-22-000021:mdna:6]
[same as prior period, unchanged from 0001571996-21-000063:mdna:5]

[0001571996-22-000021:mdna:7]
Company Overview

[0001571996-22-000021:mdna:8]
Dell Technologies helps organizations build their digital futures and individuals transform how they work, live and play.  We provide customers with one of the industry’s broadest and most innovative solutions portfolio for the data era, including traditional infrastructure and extending to multi-cloud environments.  We continue to seamlessly deliver differentiated and holistic IT solutions to our customers which has helped drive consistent revenue growth.

[0001571996-22-000021:mdna:9]
Dell Technologies’ integrated solutions help customers modernize their IT infrastructure, manage and operate in a multi-cloud world, address workforce transformation, and provide critical solutions that keep people and organizations connected, which has proven even more important through the COVID-19 pandemic.  We are helping customers accelerate their digital transformations to improve and strengthen business and workforce productivity.  With our extensive portfolio and our commitment to innovation, we offer secure, integrated solutions that extend from the edge to the core to the cloud, and we are at the forefront of the software-defined and cloud native infrastructure era.  As further evidence of our commitment to innovation, we are evolving and expanding our IT as-a-Service and cloud offerings including APEX-branded solutions which provide our customers with greater flexibility to scale IT to meet their evolving business needs and budgets.

[0001571996-22-000021:mdna:10]
Dell Technologies’ end-to-end portfolio is supported by a world-class organization that operates globally in approximately 180 countries across key functional areas, including technology and product development, marketing, sales, financial services, and services.  Our go-to-market engine includes a 32,000-person sales force and a global network of over 200,000 channel partners.  Dell Financial Services and its affiliates (“DFS”) offer customers payment flexibility and enable synergies across the business.  We employ approximately 35,000 full-time service and support professionals and maintain more than 2,400 vendor-managed service centers.  We manage a world-class supply chain that drives long-term growth and operating efficiencies, with approximately $75 billion in annual procurement expenditures and over 750 parts distribution centers.  Together, these elements provide a critical foundation for our success.

[0001571996-22-000021:mdna:11]
Our Vision and Strategy

[0001571996-22-000021:mdna:12]
Our vision is to become the most essential technology company for the data era.  We seek to address our customers’ evolving needs and their broader digital transformation objectives as they embrace today’s hybrid multi-cloud environment.  We intend to execute on our vision by focusing on two overarching strategic priorities:

[0001571996-22-000021:mdna:13]
•Grow and modernize our core offerings in the markets in which we predominantly compete

[0001571996-22-000021:mdna:14]
•Pursue attractive new growth opportunities such as Edge, Telecom, data management, and as-a-Service consumption models

[0001571996-22-000021:mdna:15]
We believe that we are uniquely positioned in the data and multi-cloud era and that our results will benefit from our durable competitive advantages.  We intend to continue to execute our business model to position our company for long-term success while balancing liquidity, profitability, and growth.

[0001571996-22-000021:mdna:16]
We are seeing an accelerated rate of change in the IT industry and increased demand for simpler, more agile IT as companies leverage multiple clouds in their IT environments.  COVID-19 has accelerated the introduction and adoption of new technologies to ensure productivity and collaboration from anywhere.  To meet our customer needs, we continue to invest in research and development, sales, and other key areas of our business to deliver superior products and solutions capabilities and to drive long-term sustainable growth.

[0001571996-22-000021:mdna:17]
[same as prior period, unchanged from 0001571996-21-000063:mdna:17]

[0001571996-22-000021:mdna:18]
We design, develop, manufacture, market, sell, and support a wide range of comprehensive and integrated solutions, products, and services.  We are organized into two business units, referred to as Infrastructure Solutions Group and Client Solutions Group, which are our reportable segments.

[0001571996-22-000021:mdna:19]
•Infrastructure Solutions Group (“ISG”) — ISG enables our customers’ digital transformation through our trusted multi-cloud and big data solutions, which are built upon modern data center infrastructure.  ISG helps customers in the area of hybrid cloud deployment with the goal of simplifying, streamlining, and automating cloud operations.  ISG solutions are built for multi-cloud environments and are optimized to run cloud native workloads in both public and private clouds, as well as traditional on-premise workloads.

[0001571996-22-000021:mdna:20]
Our comprehensive portfolio of advanced storage solutions includes traditional storage solutions as well as next-generation storage solutions (such as all-flash arrays, scale-out file, object platforms, and software-defined solutions).    Our PowerStore offering, a differentiated midrange storage solution that enables seamless updates using microservices and container-based software architecture, allows us to compete more effectively within midrange storage.  We continue to make enhancements to our storage solutions offerings and expect that these offerings will drive long-term improvements in the business.

[0001571996-22-000021:mdna:21]
Our server portfolio includes high-performance rack, blade, tower, and hyperscale servers, optimized to run high value workloads, including artificial intelligence and machine learning.  Our networking portfolio helps our business customers transform and modernize their infrastructure, mobilize and enrich end-user experiences, and accelerate business applications and processes.

[0001571996-22-000021:mdna:22]
Our strengths in server, storage, and virtualization software solutions enable us to offer leading converged and hyper-converged solutions, allowing our customers to accelerate their IT transformation by acquiring scalable integrated IT solutions instead of building and assembling their own IT platforms.  ISG also offers attached software, peripherals and services, including support and deployment, configuration, and extended warranty services.

[0001571996-22-000021:mdna:23]
[same as prior period, unchanged from 0001571996-21-000063:mdna:23]

[0001571996-22-000021:mdna:24]
•Client Solutions Group (“CSG”) — CSG includes branded hardware (such as desktops, workstations, and notebooks) and branded peripherals (such as displays and projectors), as well as third-party software and peripherals.  Our computing devices are designed with our commercial and consumer customers’ needs in mind, and we seek to

[0001571996-22-000021:mdna:25]
optimize performance, reliability, manageability, design, and security.  For our customers that are seeking to simplify client lifecycle management, Dell PC as a Service offering combines hardware, software, lifecycle services, and financing into one all-encompassing solution that provides predictable pricing per seat per month.  CSG also offers attached software, peripherals, and services, including support and deployment, configuration, and extended warranty services.

[0001571996-22-000021:mdna:26]
[same as prior period, unchanged from 0001571996-21-000063:mdna:25]

[0001571996-22-000021:mdna:27]
Our other businesses, described below, consists of our resale of standalone VMware offerings, referred to as VMware Resale, as well as product and service offerings of SecureWorks Corp. (“Secureworks”) and Virtustream.  These businesses are not classified as reportable segments, either individually or collectively.

[0001571996-22-000021:mdna:28]
•VMware Resale consists of our sale of standalone VMware offerings.  Under the Commercial Framework Agreement entered into as part of our spin-off of VMware, Dell Technologies continues to act as a key channel partner in this relationship, reselling VMware offerings to our customers.  This partnership is intended to facilitate mutually beneficial growth for both Dell and VMware.

[0001571996-22-000021:mdna:29]
VMware works with customers in the areas of hybrid and multi-cloud, modern applications, networking, security, and digital workspaces, helping customers manage their IT resources across private clouds and complex multi-cloud, multi-device environments.

[0001571996-22-000021:mdna:30]
•Secureworks (NASDAQ: SCWX) is a leading global provider of intelligence-driven information security solutions singularly focused on protecting its clients from cyber attacks.  The solutions offered by Secureworks enable organizations of varying size and complexity to fortify their cyber defenses to prevent security breaches, detect malicious activity in near real time, prioritize and respond rapidly to security incidents and predict emerging threats.

[0001571996-22-000021:mdna:31]
•Virtustream offers cloud software and Infrastructure-as-a-Service solutions that enable customers to migrate, run, and manage mission-critical applications in cloud-based IT environments.

[0001571996-22-000021:mdna:32]
We believe the collaboration, innovation, and coordination of the operations and strategies across all segments of our business, as well as our differentiated go-to-market model, will continue to drive revenue synergies.  Through our research and development activities, we are able to engineer leading innovative solutions that incorporate the distinct set of hardware, software, and services across all segments of our business.

[0001571996-22-000021:mdna:33]
Our products and services offerings are continually evolving in response to industry dynamics.  As a result, reclassifications of certain products and services solutions in major product categories may be required.  For further discussion regarding our current reportable segments, see “Results of Operations — Business Unit Results” and Note 17 of the Notes to the Condensed Consolidated Financial Statements included in this report.

[0001571996-22-000021:mdna:34]
[same as prior period, unchanged from 0001571996-21-000063:mdna:37]

[0001571996-22-000021:mdna:35]
DFS supports our businesses by offering and arranging various financing options and services for our customers globally.  DFS originates, collects, and services customer receivables primarily related to the purchase or use of our product, software, and services solutions.  We also arrange financing for some of our customers in various countries where DFS does not currently operate as a captive entity.  DFS further strengthens our customer relationships through its flexible consumption models which provide our customers with financial flexibility to meet their changing technological requirements.  Our flexible consumption models enable us to offer our customers the option to pay over time and, in certain cases, based on utilization.  The results of these operations are allocated to our segments based on the underlying product or service financed.  For additional information about our financing arrangements, see Note 5 of the Notes to the Condensed Consolidated Financial Statements included in this report.

[0001571996-22-000021:mdna:36]
Recent Transactions

[0001571996-22-000021:mdna:37]
Spin-Off of VMware, Inc. —  On November 1, 2021, we completed our spin-off of VMware by means of a special stock dividend (the “VMware Spin-off”).  The VMware Spin-off was effectuated pursuant to a Separation and Distribution Agreement, dated as of April 14, 2021 between Dell Technologies and VMware.  As part of the transaction, VMware paid a special cash dividend, pro rata, to each holder of VMware common stock in an aggregate amount equal to $11.5 billion, of which Dell Technologies received $9.3 billion.

[0001571996-22-000021:mdna:38]
In connection with and upon completion of the VMware Spin-off, we entered into a Commercial Framework Agreement (the “CFA”) with VMware, which provides the framework under which we and VMware will continue our commercial relationship after the transaction.  Pursuant to the CFA, we continue to act as a distributor of VMware’s standalone products and services and purchase such products and services for resale to customers.  We also continue to integrate VMware’s products and services with Dell Technologies’ offerings and sell them to customers.  The results of such operations are presented as continuing operations within our Condensed Consolidated Statements of Income for all periods presented.

[0001571996-22-000021:mdna:39]
The results of VMware, excluding Dell's resale of VMware offerings, are presented as discontinued operations in the Condensed Consolidated Statements of Income and, as such, have been excluded from both continuing operations and segment results for the three months ended April 30, 2021.  The Condensed Consolidated Statements of Cash Flows are presented on a consolidated basis for both continuing operations and discontinued operations.  See Note 2 of the Notes to the Condensed Consolidated Financial Statements for additional information about the VMware Spin-off.

[0001571996-22-000021:mdna:40]
Boomi Divestiture — On October 1, 2021, we completed the sale of Boomi, Inc. (“Boomi”) and certain related assets for a total cash consideration of approximately $4.0 billion, resulting in a pre-tax gain on sale of $4.0 billion.  The Company ultimately recorded a $3.0 billion gain, net of $1.0 billion in tax expense.  Prior to the divestiture, the operating results of Boomi were included within other businesses and did not qualify for presentation as discontinued operations.  See Note 1 of the Notes to the Condensed Consolidated Financial Statements included in this report for more information about this transaction.

[0001571996-22-000021:mdna:41]
Relationship with VMware

[0001571996-22-000021:mdna:42]
Effective upon the completion of the VMware Spin-off, VMware is considered to be a related party of the Company.  The related party relationship is as a result of Michael Dell’s ownership interest in both Dell Technologies and VMware and Mr. Dell’s continued service as Chairman and Chief Executive Officer of Dell Technologies and as Chairman of the Board of VMware.  Following the completion of the VMware Spin-off, the majority of transactions that occur between Dell Technologies and VMware consist of Dell Technologies’ purchase of VMware products and services for resale, either on a standalone basis or as a part of integrated offerings.  For more information regarding related party transactions with VMware, see Note 16 of the Notes to the Condensed Consolidated Financial Statements included in this report.

[0001571996-22-000021:mdna:43]
[same as prior period, unchanged from 0001571996-21-000063:mdna:39]

[0001571996-22-000021:mdna:44]
As part of our strategy, we will continue to evaluate opportunities for strategic investments through our venture capital investment arm, Dell Technologies Capital, with a focus on emerging technology areas that are relevant to all segments of our business and that will complement our existing portfolio of solutions.  Our investment areas include storage, software-defined networking, management and orchestration, security, machine learning and artificial intelligence, Big Data and analytics, cloud, edge computing, and software development operations.  The technologies or products these companies have under development are typically in the early stages and may never materialize, which could result in a loss of a substantial part of our initial investment in the companies.  As of April 29, 2022 and January 28, 2022, Dell Technologies held strategic investments in non-marketable securities of $1.5 billion and $1.4 billion, respectively.

[0001571996-22-000021:mdna:45]
[same as prior period, unchanged from 0001571996-21-000063:mdna:41]

[0001571996-22-000021:mdna:46]
57

[0001571996-22-000021:mdna:47]
[same as prior period, unchanged from 0001571996-21-000063:mdna:42]

[0001571996-22-000021:mdna:48]
Ukraine — We are monitoring and responding to effects of the ongoing military conflict in Ukraine.  As a result of the conflict, we are not selling, servicing or supporting products in Russia, Belarus, and the Donetsk and Luhansk regions of Ukraine.  Operations in Russia and Ukraine accounted for less than 1% of net revenue in Fiscal 2022 and assets attributable to Russian operations accounted for less than 0.5% of total assets as of April 29, 2022.

[0001571996-22-000021:mdna:49]
The conflict and the related economic sanctions are impacting markets worldwide.  Our business may be adversely affected by effects of the conflict, which could include supply chain disruptions, product shipping delays, macroeconomic impacts resulting from the exclusion of Russian financial institutions from the global banking system, volatility in foreign exchange rates and interest rates, inflationary pressures, and heightened cybersecurity and data theft threats.  The full impact of the conflict on our business operations and financial performance remains uncertain and will depend on future developments.  We will continue to monitor the conflict and assess the related restrictions and other effects and pursue prudent decisions for our team members, customers, and business.

[0001571996-22-000021:mdna:50]
COVID-19 Pandemic and Response — We continue to monitor the COVID-19 pandemic and variants of the virus, as well as the impact the pandemic has on our employees, customers, business partners, and communities.  Our crisis management team is actively engaged in evaluating changes in our environment and aligning our response to recommendations of the World Health Organization and the U.S. Centers for Disease Control and Prevention, and with governmental regulations.  We are deploying return-to-site processes based on our ongoing assessments of local conditions.  We continue to monitor regional conditions and utilize remote work practices to ensure the health and safety of our employees, customers, and business partners.

[0001571996-22-000021:mdna:51]
As discussed below, we continue to manage through the impacts of the COVID-19 pandemic on our supply chain. The full impact of the COVID-19 pandemic on our business operations and financial performance remains uncertain and will depend on future developments, including the severity, duration, and scope of the pandemic across different geographies; the effectiveness of actions taken to contain, mitigate or prevent the spread of variants of the virus; the further development, availability, and acceptance of effective treatments or vaccines; and governmental, business, and individuals’ actions that have been and continue to be taken in response to the pandemic.  We will continue to actively monitor global events and pursue prudent decisions to navigate in this uncertain and ever-changing environment.  For additional information about impacts of COVID-19 on our operations, see “Results of Operations—Consolidated Results” and “—Business Unit Results.”

[0001571996-22-000021:mdna:52]
Supply Chain — Dell Technologies maintains limited-source supplier relationships for certain components, because the relationships are advantageous in the areas of performance, quality, support, delivery, capacity, and price considerations.

[0001571996-22-000021:mdna:53]
During the first quarter of Fiscal 2023, we continued to be impacted by industry-wide constraints in the supply of limited-source components in certain product offerings as a result of the global impacts of COVID-19.  Demand for such components continues to outpace supply, resulting in an increase in orders pending fulfillment and extended lead times for our customers for certain products, as well as an increase in logistics costs.  Logistics costs remain elevated as a result of both expedited shipments of components and overall rate costs in the freight network as capacity remains constrained.

[0001571996-22-000021:mdna:54]
Component cost trends are dependent on the strength or weakness of actual end user demand and supply dynamics, which will continue to evolve and ultimately impact the translation of the cost environment to pricing and operating results.  Component costs were deflationary during the first quarter of Fiscal 2023.

[0001571996-22-000021:mdna:55]
We expect to continue to manage supply constraints and anticipate that the overall cost environment will be inflationary for the remainder of Fiscal 2023.  In response to these pressures, we continue to take steps to actively address our customers’ demands while balancing profitability and growth.

[0001571996-22-000021:mdna:56]
ISG — We expect that ISG will continue to be impacted by the changing nature of the IT infrastructure market and competitive environment.  During the first quarter of Fiscal 2023, ISG net revenue benefited from continued demand for IT infrastructure.  While we expect ISG net revenue growth to continue throughout the remainder of Fiscal 2023, we anticipate that the rate of growth will moderate in the second half of the fiscal year.  With our scale and strong solutions portfolio, we believe we are well-positioned to respond to ongoing competitive dynamics.  Within servers and networking, we will continue to be selective in determining whether to pursue certain large hyperscale and other server transactions.  We continue to focus on customer base expansion and lifetime value of customer relationships.

[0001571996-22-000021:mdna:57]
Growth throughout industries is generating continued demand for our storage solutions and services.  Cloud native applications are expected to continue as a primary growth driver in the infrastructure market.  We benefit from offering solutions that address the emerging trends of enterprises deploying software-defined storage, hyper-converged infrastructure, and modular solutions based on server-centric architectures.  These trends are changing the way customers are consuming our traditional storage offerings.  We continue to expand our offerings in external storage arrays, which incorporate flexible, cloud-based functionality.

[0001571996-22-000021:mdna:58]
Through our research and development efforts, we are developing new solutions in this rapidly changing industry that we believe will enable us to continue to provide superior solutions to our customers.  Our customer base includes a growing number of service providers, such as cloud service providers, Software-as-a-Service companies, consumer webtech providers, and telecommunications companies.  These service providers turn to Dell Technologies for our advanced solutions that enable efficient service delivery at cloud scale.  Through our collaborative, customer-focused approach to innovation, we strive to deliver new and relevant solutions and software to the market quickly and efficiently.

[0001571996-22-000021:mdna:59]
CSG — Our CSG offerings are an important element of our strategy, generating strong cash flow and opportunities for cross-selling of complementary solutions.  During the first quarter of Fiscal 2023, CSG net revenue growth continued at a more moderate rate than in Fiscal 2022.  We expect CSG net revenue growth to continue to moderate throughout Fiscal 2023 as customers shift investment towards IT infrastructure and industry-wide demand for consumer offerings declines.  Further, we expect that the CSG demand environment will continue to be subject to seasonal trends.

[0001571996-22-000021:mdna:60]
Competitive dynamics continue to be a factor in our CSG business and will impact pricing and operating results.  We remain committed to our long-term strategy for CSG and we will continue to make investments to innovate across the portfolio while benefiting from consolidation trends that are occurring in the markets in which we compete.

[0001571996-22-000021:mdna:61]
Recurring Revenue and Consumption Models — Our customers are seeking new and innovative models that address how they consume our solutions.  We offer options including as-a-Service, utility, leases, and immediate pay models designed to match customers’ consumption and financing preferences.  We continue to evolve and build momentum across our family of as-a-Service offerings as we pursue our strategy of modernizing our core business solutions, with APEX at the forefront.  We expect that our flexible consumption models and as-a-Service offerings will further strengthen our customer relationships and provide a foundation for growth in recurring revenue.

[0001571996-22-000021:mdna:62]
These offerings typically result in multiyear agreements which generate recurring revenue streams over the term of the arrangement.  We define recurring revenue as revenue recognized primarily related to hardware and software maintenance as well as subscription, as-a-Service, and usage-based offerings, and operating leases.

[0001571996-22-000021:mdna:63]
Macroeconomic Risks and Uncertainties — The impacts of trade protection measures, including increases in tariffs and trade barriers, changes in government policies and international trade arrangements, and geopolitical issues may affect our ability to conduct business in some non-U.S. markets.  We monitor and seek to mitigate these risks with adjustments to our manufacturing, supply chain, and distribution networks.

[0001571996-22-000021:mdna:64]
We manage our business on a U.S. dollar basis.  However, we have a large global presence, generating approximately half of our net revenue from sales to customers outside of the United States during the first quarters of Fiscal 2023 and Fiscal 2022.  As a result, our revenue can be impacted by fluctuations in foreign currency exchange rates.  We utilize a comprehensive hedging strategy intended to mitigate the impact of foreign currency volatility over time, and we adjust pricing when possible to further minimize foreign currency impacts.

[0001571996-22-000021:mdna:65]
[same as prior period, unchanged from 0001571996-21-000063:mdna:67]

[0001571996-22-000021:mdna:66]
Our key performance metrics include net revenue, operating income, and cash flows from operations, which are discussed elsewhere in this management’s discussion and analysis.

[0001571996-22-000021:mdna:67]
59

[0001571996-22-000021:mdna:68]
[same as prior period, unchanged from 0001571996-21-000063:mdna:69]

[0001571996-22-000021:mdna:69]
In this management’s discussion and analysis, we use supplemental measures of our performance which are derived from our consolidated financial information but which are not presented in our consolidated financial statements prepared in accordance with GAAP.  These non-GAAP financial measures include non-GAAP product net revenue; non-GAAP services net revenue; non-GAAP net revenue; non-GAAP product gross margin; non-GAAP services gross margin; non-GAAP gross margin; non-GAAP operating expenses; non-GAAP operating income; non-GAAP net income; earnings before interest and other, net, taxes, depreciation, and amortization (“EBITDA”); and adjusted EBITDA.   The non-GAAP financial measures are not meant to be considered as indicators of performance in isolation from or as a substitute for net revenue, gross margin, operating expenses, operating income, or net income from continuing operations prepared in accordance with GAAP, and should be read only in conjunction with financial information presented on a GAAP basis.

[0001571996-22-000021:mdna:70]
Effective in the first quarter of Fiscal 2023, non-GAAP product net revenue, non-GAAP services net revenue, and non-GAAP net revenue no longer differ from the most comparable GAAP financial measures.  Such non-GAAP financial measures are provided below for all periods presented as a result of purchase accounting adjustments that impacted such financial measures in prior periods.

[0001571996-22-000021:mdna:71]
[same as prior period, unchanged from 0001571996-21-000063:mdna:71]

[0001571996-22-000021:mdna:72]
Non-GAAP product net revenue, non-GAAP services net revenue, non-GAAP net revenue, non-GAAP product gross margin, non-GAAP services gross margin, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, and non-GAAP net income, as defined by us, exclude amortization of intangible assets, the impact of purchase accounting, transaction-related expenses, stock-based compensation expense, other corporate expenses and, for non-GAAP net income, fair value adjustments on equity adjustments and an aggregate adjustment for income taxes.  As the excluded items have a material impact on our financial results, our management compensates for this limitation by relying primarily on our GAAP results and using non-GAAP financial measures supplementally or for projections when comparable GAAP financial measures are not available.

[0001571996-22-000021:mdna:73]
[same as prior period, unchanged from 0001571996-21-000063:mdna:73]

[0001571996-22-000021:mdna:74]
[same as prior period, unchanged from 0001571996-21-000063:mdna:74]

[0001571996-22-000021:mdna:75]
•Amortization of Intangible Assets — Amortization of intangible assets primarily consists of amortization of customer relationships, developed technology, and trade names.  In connection with our acquisition by merger of EMC on September 7, 2016, referred to as the “EMC merger transaction,” and the acquisition of Dell Inc. by Dell Technologies Inc. on October 29, 2013, referred to as the “going-private transaction,” all of the tangible and intangible assets and liabilities of EMC and Dell, Inc. and its consolidated subsidiaries, respectively, were accounted for and recognized at fair value on the transaction dates.  Accordingly, for the periods presented, amortization of intangible assets represents amortization associated with intangible assets recognized in connection with the EMC merger transaction and the going-private transaction.  Amortization charges for purchased intangible assets are significantly impacted by the timing and magnitude of our acquisitions, and these charges may vary in amount from period to period.  We exclude these charges for purposes of calculating the non-GAAP financial measures presented below to facilitate an enhanced understanding of our current operating performance and provide more meaningful period to period comparisons.

[0001571996-22-000021:mdna:76]
•Impact of Purchase Accounting — The impact of purchase accounting includes purchase accounting adjustments related to the EMC merger transaction and, to a lesser extent, the going-private transaction, recorded under the acquisition method of accounting in accordance with the accounting guidance for business combinations.  Accordingly, all of the assets and liabilities acquired in such transactions were accounted for and recognized at fair value as of the respective transaction dates, and the fair value adjustments are being amortized over the estimated useful lives in the periods following the transactions.  The fair value adjustments primarily relate to property, plant, and equipment.  We believe that excluding the impact of purchase accounting for purposes of calculating the non-GAAP financial measures presented below facilitates an enhanced understanding of our current operating performance and provides more meaningful period to period comparisons.

[0001571996-22-000021:mdna:77]
•Transaction-related (income) expenses — Transaction-related expenses typically consist of acquisition, integration, and divestiture related costs, as well as the costs incurred in the VMware Spin-off, and are expensed as incurred.  These expenses primarily represent costs for legal, banking, consulting, and advisory services.  From time to time, this category also may include transaction-related income related to divestitures of businesses or asset sales.  We exclude these items for purposes of calculating the non-GAAP financial measures presented below to facilitate an enhanced understanding of our current operating performance and provide more meaningful period to period comparisons.

[0001571996-22-000021:mdna:78]
•Stock-based Compensation Expense — Stock-based compensation expense consists of equity awards granted based on the estimated fair value of those awards at grant date.  We estimate the fair value of service-based stock options using the Black-Scholes valuation model.  To estimate the fair value of performance-based awards containing a market condition, we use the Monte Carlo valuation model.  For all other share-based awards, the fair value is based on the closing price of the Class C Common Stock as reported on the NYSE on the date of grant.  Although stock-based compensation is an important aspect of the compensation of our employees and executives, the fair value of the stock-based awards may bear little resemblance to the actual value realized upon the vesting or future exercise of the related stock-based awards.  We believe that excluding stock-based compensation expense for purposes of calculating the non-GAAP financial measures presented below facilitates an enhanced understanding of our current operating performance and provides more meaningful period to period comparisons.

[0001571996-22-000021:mdna:79]
•Other Corporate Expenses — Other corporate expenses consist of impairment charges, incentive charges related to equity investments, severance, facility action, payroll taxes associated with stock-based compensation, and other costs.  Severance costs are primarily related to severance and benefits for employees terminated pursuant to cost savings initiatives.  We continue to optimize our facilities footprint and may incur additional costs as we seek opportunities for operational efficiencies.  Other corporate expenses vary from period to period and are significantly impacted by the timing and nature of these events.  Therefore, although we may incur these types of expenses in the future, we believe that eliminating these charges for purposes of calculating the non-GAAP financial measures presented below facilitates an enhanced understanding of our current operating performance and provides more meaningful period to period comparisons.

[0001571996-22-000021:mdna:80]
•Fair Value Adjustments on Equity Investments — Fair value adjustments on equity investments primarily consist of the gain (loss) on strategic investments, which includes the recurring fair value adjustments of investments in publicly-traded companies, as well as those in privately-held companies, which are adjusted for observable price changes, and, to a lesser extent, any potential impairments.  See Note 3 of the Notes to the Condensed Consolidated Financial Statements included in this report for additional information on our strategic investment activity.  Given the volatility in the ongoing adjustments to the valuation of these strategic investments, we believe that excluding these gains and losses for purposes of calculating non-GAAP net income presented below facilitates an enhanced understanding of our current operating performance and provides more meaningful period to period comparisons.

[0001571996-22-000021:mdna:81]
•Aggregate Adjustment for Income Taxes — The aggregate adjustment for income taxes is the estimated combined income tax effect for the adjustments described above, as well as an adjustment for discrete tax items.  Due to the variability in recognition of discrete tax items from period to period, we believe that excluding these benefits or charges for purposes of calculating non-GAAP net income facilitates an enhanced understanding of our current operating performance and provides more meaningful period to period comparisons.  The tax effects are determined based on the tax jurisdictions where the above items were incurred.  See Note 12 of the Notes to the Condensed Consolidated Financial Statements included in this report for additional information on our income taxes.

[0001571996-22-000021:mdna:82]
The following table presents a reconciliation of each non-GAAP financial measure to the most directly comparable GAAP measure for the periods indicated:

[0001571996-22-000021:mdna:83]
|  |  |  | Three Months Ended |
|  |  |  |  |  |  |  | April 29,2022 |  | % Change |  | April 30,2021 |  |  |  |  |
|  |  |  |  |  |  |  | (in millions, except percentages) |
| Product net revenue |  |  |  |  |  |  | $ | 20,464 |  |  | 17 | % |  | $ | 17,487 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting |  |  |  |  |  |  | — |  |  |  |  | (1) |  |  |  |  |  |
| Non-GAAP product net revenue |  |  |  |  |  |  | $ | 20,464 |  |  | 17 | % |  | $ | 17,486 |  |  |  |  |  |
| Services net revenue |  |  |  |  |  |  | $ | 5,652 |  |  | 11 | % |  | $ | 5,103 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting |  |  |  |  |  |  | — |  |  |  |  | 9 |  |  |  |  |  |
| Non-GAAP services net revenue |  |  |  |  |  |  | $ | 5,652 |  |  | 11 | % |  | $ | 5,112 |  |  |  |  |  |
| Net revenue |  |  |  |  |  |  | $ | 26,116 |  |  | 16 | % |  | $ | 22,590 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting |  |  |  |  |  |  | — |  |  |  |  | 8 |  |  |  |  |  |
| Non-GAAP net revenue |  |  |  |  |  |  | $ | 26,116 |  |  | 16 | % |  | $ | 22,598 |  |  |  |  |  |
| Product gross margin |  |  |  |  |  |  | $ | 3,455 |  |  | 13 | % |  | $ | 3,053 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles |  |  |  |  |  |  | 104 |  |  |  |  | 151 |  |  |  |  |  |
| Impact of purchase accounting |  |  |  |  |  |  | 2 |  |  |  |  | — |  |  |  |  |  |
| Stock-based compensation expense |  |  |  |  |  |  | 13 |  |  |  |  | 9 |  |  |  |  |  |
| Other corporate expenses |  |  |  |  |  |  | 3 |  |  |  |  | 3 |  |  |  |  |  |
| Non-GAAP product gross margin |  |  |  |  |  |  | $ | 3,577 |  |  | 11 | % |  | $ | 3,216 |  |  |  |  |  |
| Services gross margin |  |  |  |  |  |  | $ | 2,329 |  |  | 5 | % |  | $ | 2,211 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles |  |  |  |  |  |  | — |  |  |  |  | (1) |  |  |  |  |  |
| Impact of purchase accounting |  |  |  |  |  |  | — |  |  |  |  | 9 |  |  |  |  |  |
| Stock-based compensation expense |  |  |  |  |  |  | 25 |  |  |  |  | 19 |  |  |  |  |  |
| Other corporate expenses |  |  |  |  |  |  | 10 |  |  |  |  | 10 |  |  |  |  |  |
| Non-GAAP services gross margin |  |  |  |  |  |  | $ | 2,364 |  |  | 5 | % |  | $ | 2,248 |  |  |  |  |  |

[0001571996-22-000021:mdna:84]
[same as prior period, unchanged from 0001571996-21-000063:mdna:28]

[0001571996-22-000021:mdna:85]
|  |  |  | Three Months Ended |
|  |  |  |  |  |  |  | April 29,2022 |  | % Change |  | April 30,2021 |  |  |  |  |
|  |  |  |  |  |  |  | (in millions, except percentages) |
| Gross margin |  |  |  |  |  |  | $ | 5,784 |  |  | 10 | % |  | $ | 5,264 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles |  |  |  |  |  |  | 104 |  |  |  |  | 150 |  |  |  |  |  |
| Impact of purchase accounting |  |  |  |  |  |  | 2 |  |  |  |  | 9 |  |  |  |  |  |
| Stock-based compensation expense |  |  |  |  |  |  | 38 |  |  |  |  | 28 |  |  |  |  |  |
| Other corporate expenses |  |  |  |  |  |  | 13 |  |  |  |  | 13 |  |  |  |  |  |
| Non-GAAP gross margin |  |  |  |  |  |  | $ | 5,941 |  |  | 9 | % |  | $ | 5,464 |  |  |  |  |  |
| Operating expenses |  |  |  |  |  |  | $ | 4,234 |  |  | (1) | % |  | $ | 4,277 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles |  |  |  |  |  |  | (139) |  |  |  |  | (295) |  |  |  |  |  |
| Impact of purchase accounting |  |  |  |  |  |  | (7) |  |  |  |  | (11) |  |  |  |  |  |
| Transaction-related expenses |  |  |  |  |  |  | (5) |  |  |  |  | (29) |  |  |  |  |  |
| Stock-based compensation expense |  |  |  |  |  |  | (194) |  |  |  |  | (144) |  |  |  |  |  |
| Other corporate expenses |  |  |  |  |  |  | (83) |  |  |  |  | (104) |  |  |  |  |  |
| Non-GAAP operating expenses |  |  |  |  |  |  | $ | 3,806 |  |  | 3 | % |  | $ | 3,694 |  |  |  |  |  |
| Operating income |  |  |  |  |  |  | $ | 1,550 |  |  | 57 | % |  | $ | 987 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles |  |  |  |  |  |  | 243 |  |  |  |  | 445 |  |  |  |  |  |
| Impact of purchase accounting |  |  |  |  |  |  | 9 |  |  |  |  | 20 |  |  |  |  |  |
| Transaction-related expenses |  |  |  |  |  |  | 5 |  |  |  |  | 29 |  |  |  |  |  |
| Stock-based compensation expense |  |  |  |  |  |  | 232 |  |  |  |  | 172 |  |  |  |  |  |
| Other corporate expenses |  |  |  |  |  |  | 96 |  |  |  |  | 117 |  |  |  |  |  |
| Non-GAAP operating income |  |  |  |  |  |  | $ | 2,135 |  |  | 21 | % |  | $ | 1,770 |  |  |  |  |  |
| Net income from continuing operations |  |  |  |  |  |  | $ | 1,069 |  |  | 62 | % |  | $ | 659 |  |  |  |  |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles |  |  |  |  |  |  | 243 |  |  |  |  | 445 |  |  |  |  |  |
| Impact of purchase accounting |  |  |  |  |  |  | 9 |  |  |  |  | 20 |  |  |  |  |  |
| Transaction-related (income) expenses |  |  |  |  |  |  | (2) |  |  |  |  | 29 |  |  |  |  |  |
| Stock-based compensation expense |  |  |  |  |  |  | 232 |  |  |  |  | 172 |  |  |  |  |  |
| Other corporate expenses |  |  |  |  |  |  | 96 |  |  |  |  | 117 |  |  |  |  |  |
| Fair value adjustments on equity investments |  |  |  |  |  |  | (14) |  |  |  |  | (194) |  |  |  |  |  |
| Aggregate adjustment for income taxes |  |  |  |  |  |  | (199) |  |  |  |  | (193) |  |  |  |  |  |
| Non-GAAP net income |  |  |  |  |  |  | $ | 1,434 |  |  | 36 | % |  | $ | 1,055 |  |  |  |  |  |

[0001571996-22-000021:mdna:86]
63

[0001571996-22-000021:mdna:87]
In addition to the above measures, we also use EBITDA and adjusted EBITDA to provide additional information for evaluation of our operating performance.  Adjusted EBITDA excludes purchase accounting adjustments related to the EMC merger transaction and the going-private transaction, acquisition, integration, and divestiture related costs, impairment charges, and severance, facility action, and other costs, and stock-based compensation expense.  We believe that, due to the non-operational nature of the purchase accounting entries, it is appropriate to exclude these adjustments.

[0001571996-22-000021:mdna:88]
As is the case with the non-GAAP measures presented above, users should consider the limitations of using EBITDA and adjusted EBITDA, including the fact that those measures do not provide a complete measure of our operating performance.  EBITDA and adjusted EBITDA do not purport to be alternatives to net income as measures of operating performance or to cash flows from operating activities as a measure of liquidity.  In particular, EBITDA and adjusted EBITDA are not intended to be a measure of free cash flow available for management’s discretionary use, as these measures do not consider certain cash requirements, such as working capital needs, capital expenditures, contractual commitments, interest payments, tax payments, and other debt service requirements.

[0001571996-22-000021:mdna:89]
The following table presents a reconciliation of EBITDA and adjusted EBITDA to net income for the periods indicated:

[0001571996-22-000021:mdna:90]
|  |  |  | Three Months Ended |
|  |  |  |  |  |  |  | April 29,2022 |  | % Change |  | April 30,2021 |  |  |  |  |
|  |  |  |  |  |  |  | (in millions, except percentages) |
| Net income from continuing operations |  |  |  |  |  |  | $ | 1,069 |  |  | 62 | % |  | $ | 659 |  |  |  |  |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest and other, net (a) |  |  |  |  |  |  | 337 |  |  |  |  | 288 |  |  |  |  |  |
| Income tax expense (benefit) (b) |  |  |  |  |  |  | 144 |  |  |  |  | 40 |  |  |  |  |  |
| Depreciation and amortization |  |  |  |  |  |  | 726 |  |  |  |  | 905 |  |  |  |  |  |
| EBITDA |  |  |  |  |  |  | $ | 2,276 |  |  | 20 | % |  | $ | 1,892 |  |  |  |  |  |
| EBITDA |  |  |  |  |  |  | $ | 2,276 |  |  | 20 | % |  | $ | 1,892 |  |  |  |  |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense |  |  |  |  |  |  | 232 |  |  |  |  | 172 |  |  |  |  |  |
| Impact of purchase accounting (c) |  |  |  |  |  |  | — |  |  |  |  | 12 |  |  |  |  |  |
| Transaction-related expenses (d) |  |  |  |  |  |  | 5 |  |  |  |  | 29 |  |  |  |  |  |
| Other corporate expenses (e) |  |  |  |  |  |  | 96 |  |  |  |  | 117 |  |  |  |  |  |
| Adjusted EBITDA |  |  |  |  |  |  | $ | 2,609 |  |  | 17 | % |  | $ | 2,222 |  |  |  |  |  |

[0001571996-22-000021:mdna:91]
[same as prior period, unchanged from 0001571996-21-000063:mdna:92]

[0001571996-22-000021:mdna:92]
[same as prior period, unchanged from 0001571996-21-000063:mdna:93]

[0001571996-22-000021:mdna:93]
(b)See Note 12 of the Notes to the Condensed Consolidated Financial Statements included in this report for additional information on discrete tax items recorded during the first quarter of Fiscal 2023 and Fiscal 2022.

[0001571996-22-000021:mdna:94]
(c)This amount includes the non-cash purchase accounting adjustments related to the EMC merger transaction and the going-private transaction.

[0001571996-22-000021:mdna:95]
(d)Transaction-related expenses consist of acquisition, integration, and divestiture related costs, as well as the costs incurred in the VMware Spin-off.

[0001571996-22-000021:mdna:96]
(e)Other corporate expenses includes impairment charges, incentive charges related to equity investments, severance, facility action, payroll taxes associated with stock-based compensation, and other costs.

[0001571996-22-000021:mdna:97]
[same as prior period, unchanged from 0001571996-21-000063:mdna:98]

[0001571996-22-000021:mdna:98]
[same as prior period, unchanged from 0001571996-21-000063:mdna:99]

[0001571996-22-000021:mdna:99]
The following table summarizes our consolidated results for the periods indicated.  Unless otherwise indicated, all changes identified for the current period results represent comparisons to results for the prior corresponding fiscal period.

[0001571996-22-000021:mdna:100]
|  |  |  | Three Months Ended |
|  |  |  |  |  |  |  | April 29, 2022 |  |  |  | April 30, 2021 |  |  |  |  |
|  |  |  |  |  |  |  |  |  |  |  | Dollars |  | % ofNet Revenue |  | %Change |  | Dollars |  | % ofNet Revenue |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |  |  |  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  |  |  |  |  |  |  |  |  |  | $ | 20,464 |  |  | 78.4 | % |  | 17 | % |  | $ | 17,487 |  |  | 77.4 | % |  |  |  |  |  |  |
| Services |  |  |  |  |  |  |  |  |  |  | 5,652 |  |  | 21.6 | % |  | 11 | % |  | 5,103 |  |  | 22.6 | % |  |  |  |  |  |  |
| Total net revenue |  |  |  |  |  |  |  |  |  |  | $ | 26,116 |  |  | 100.0 | % |  | 16 | % |  | $ | 22,590 |  |  | 100.0 | % |  |  |  |  |  |  |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products (a) |  |  |  |  |  |  |  |  |  |  | $ | 3,455 |  |  | 16.9 | % |  | 13 | % |  | $ | 3,053 |  |  | 17.5 | % |  |  |  |  |  |  |
| Services (b) |  |  |  |  |  |  |  |  |  |  | 2,329 |  |  | 41.2 | % |  | 5 | % |  | 2,211 |  |  | 43.3 | % |  |  |  |  |  |  |
| Total gross margin |  |  |  |  |  |  |  |  |  |  | $ | 5,784 |  |  | 22.1 | % |  | 10 | % |  | $ | 5,264 |  |  | 23.3 | % |  |  |  |  |  |  |
| Operating expenses |  |  |  |  |  |  |  |  |  |  | $ | 4,234 |  |  | 16.2 | % |  | (1) | % |  | $ | 4,277 |  |  | 18.9 | % |  |  |  |  |  |  |
| Operating income |  |  |  |  |  |  |  |  |  |  | $ | 1,550 |  |  | 5.9 | % |  | 57 | % |  | $ | 987 |  |  | 4.4 | % |  |  |  |  |  |  |
| Net income from continuing operations |  |  |  |  |  |  |  |  |  |  | $ | 1,069 |  |  | 4.1 | % |  | 62 | % |  | $ | 659 |  |  | 2.9 | % |  |  |  |  |  |  |
| Non-GAAP Financial Information |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |  |  |  | Three Months Ended |
|  |  |  |  |  |  |  |  |  |  |  | April 29, 2022 |  |  |  | April 30, 2021 |  |  |  |  |
|  |  |  |  |  |  |  |  |  |  | Dollars |  | % of Non-GAAP Net Revenue |  | %Change |  | Dollars |  | % of Non-GAAP Net Revenue |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |  |  |  | (in millions, except percentages) |
| Non-GAAP net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  |  |  |  |  |  |  |  |  |  | $ | 20,464 |  |  | 78.4 | % |  | 17 | % |  | $ | 17,486 |  |  | 77.4 | % |  |  |  |  |  |  |
| Services |  |  |  |  |  |  |  |  |  |  | 5,652 |  |  | 21.6 | % |  | 11 | % |  | 5,112 |  |  | 22.6 | % |  |  |  |  |  |  |
| Total non-GAAP net revenue |  |  |  |  |  |  |  |  |  |  | $ | 26,116 |  |  | 100.0 | % |  | 16 | % |  | $ | 22,598 |  |  | 100.0 | % |  |  |  |  |  |  |
| Non-GAAP gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products (a) |  |  |  |  |  |  |  |  |  |  | $ | 3,577 |  |  | 17.5 | % |  | 11 | % |  | $ | 3,216 |  |  | 18.4 | % |  |  |  |  |  |  |
| Services (b) |  |  |  |  |  |  |  |  |  |  | 2,364 |  |  | 41.8 | % |  | 5 | % |  | 2,248 |  |  | 44.0 | % |  |  |  |  |  |  |
| Total non-GAAP gross margin |  |  |  |  |  |  |  |  |  |  | $ | 5,941 |  |  | 22.7 | % |  | 9 | % |  | $ | 5,464 |  |  | 24.2 | % |  |  |  |  |  |  |
| Non-GAAP operating expenses |  |  |  |  |  |  |  |  |  |  | $ | 3,806 |  |  | 14.5 | % |  | 3 | % |  | $ | 3,694 |  |  | 16.4 | % |  |  |  |  |  |  |
| Non-GAAP operating income |  |  |  |  |  |  |  |  |  |  | $ | 2,135 |  |  | 8.2 | % |  | 21 | % |  | $ | 1,770 |  |  | 7.8 | % |  |  |  |  |  |  |
| Non-GAAP net income |  |  |  |  |  |  |  |  |  |  | $ | 1,434 |  |  | 5.5 | % |  | 36 | % |  | $ | 1,055 |  |  | 4.7 | % |  |  |  |  |  |  |
| EBITDA |  |  |  |  |  |  |  |  |  |  | $ | 2,276 |  |  | 8.7 | % |  | 20 | % |  | $ | 1,892 |  |  | 8.4 | % |  |  |  |  |  |  |
| Adjusted EBITDA |  |  |  |  |  |  |  |  |  |  | $ | 2,609 |  |  | 10.0 | % |  | 17 | % |  | $ | 2,222 |  |  | 9.8 | % |  |  |  |  |  |  |

[0001571996-22-000021:mdna:101]
[same as prior period, unchanged from 0001571996-21-000063:mdna:102]

[0001571996-22-000021:mdna:102]
[same as prior period, unchanged from 0001571996-21-000063:mdna:103]

[0001571996-22-000021:mdna:103]
(b)    Services gross margin percentages represent services gross margin as a percentage of services net revenue, and non-GAAP  services gross margin percentages represent non-GAAP services gross margin as a percentage of non-GAAP services net revenue.

[0001571996-22-000021:mdna:104]
65

[0001571996-22-000021:mdna:105]
Non-GAAP product net revenue, non-GAAP services net revenue, non-GAAP net revenue, non-GAAP product gross margin, non-GAAP services gross margin, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, EBITDA, and adjusted EBITDA are not measurements of financial performance prepared in accordance with GAAP.  Non-GAAP financial measures as a percentage of revenue are calculated based on non-GAAP net revenue.  See “Non‑GAAP Financial Measures” for additional information about these non-GAAP financial measures, including our reasons for including these measures, material limitations with respect to the usefulness of the measures, and a reconciliation of each non-GAAP financial measure to the most directly comparable GAAP financial measure.

[0001571996-22-000021:mdna:106]
[same as prior period, unchanged from 0001571996-21-000063:mdna:106]

[0001571996-22-000021:mdna:107]
During the first quarter of Fiscal 2023, our net revenue increased 16% due to growth in net revenue for both CSG and ISG.  CSG net revenue benefited primarily from strength in our commercial offerings.  ISG net revenue growth resulted from demand for overall investment in IT infrastructure as customers continue to invest in digital transformation.

[0001571996-22-000021:mdna:108]
During the first quarter of Fiscal 2023, our operating income increased 57% to $1.6 billion and our non-GAAP operating income increased 21% to $2.1 billion.  These increases were primarily due to growth in operating income for ISG, driven principally by our storage offerings.  Operating income also benefited from the favorable impact of a decrease in amortization of intangible assets.

[0001571996-22-000021:mdna:109]
Operating income and non-GAAP operating income as a percentage of net revenue increased 150 basis points to 5.9% and 40 basis points to 8.2%, respectively, primarily driven by ISG.  ISG operating income as a percentage of net revenue increased as a result of a decrease in operating expenses as a percentage of net revenue due to strong revenue growth coupled with disciplined cost management.  These factors were partially offset by declines in gross margin as a percentage of net revenue for both CSG and ISG which declined in part as a result of increased cost of net revenue that was not entirely offset by pricing adjustments.    Operating income as a percentage of net revenue also increased as a result of the favorable impact of a decrease in amortization of intangible assets.

[0001571996-22-000021:mdna:110]
Cash used by operating activities was $0.3 billion during the first quarter of Fiscal 2023.  Operating cash flows during the first quarter of the fiscal year are typically lower due to seasonal revenue trends as well as the timing of annual personnel-related payments.  Operating cash flows were also impacted by higher than normal inventory balances as we continue to proactively manage supply chain challenges.  During the first quarter of Fiscal 2022, cash provided by operating activities was $2.2 billion.  See “Market Conditions, Liquidity, Capital Commitments, and Contractual Cash Obligations” for further information on our cash flow metrics.

[0001571996-22-000021:mdna:111]
We continue to see opportunities to create value and grow in response to resilient demand for our IT solutions driven by a technology-enabled world.  We have demonstrated our ability to adjust to changing market conditions with complementary solutions across both segments of our business, an agile workforce, and the strength of our global supply chain.  As we continue to innovate and modernize our core offerings, we believe that Dell Technologies is well-positioned for long-term profitable growth.

[0001571996-22-000021:mdna:112]
[same as prior period, unchanged from 0001571996-21-000063:mdna:112]

[0001571996-22-000021:mdna:113]
During the first quarter of Fiscal 2023, our net revenue increased 16% primarily due to an increase in net revenue for both CSG and ISG.  See “Business Unit Results” for further information.

[0001571996-22-000021:mdna:114]
•Product Net Revenue — Product net revenue includes revenue from the sale of hardware products and software licenses.  During the first quarter of Fiscal 2023, our product net revenue increased 17% driven by growth within both CSG and ISG.  CSG product net revenue increased principally due to an increase in average selling price for our commercial offerings.  ISG product net revenue growth was primarily attributable to growth in net revenue for servers and networking, driven by an increase in average selling price, and, to a lesser extent, an increase in net revenue for storage.

[0001571996-22-000021:mdna:115]
•Services Net Revenue — Services net revenue includes revenue from our services offerings and support services related to hardware products and software licenses.  During the first quarter of Fiscal 2023,  services net revenue increased 11%, driven primarily by growth in CSG services net revenue and, to a lesser extent, growth in ISG services net revenue.  Growth in CSG services net revenue was primarily due to increases in services net revenue attributable to both hardware support and maintenance and third-party software support and maintenance.  ISG services net revenue increased primarily as a result of growth within hardware support services.  A substantial portion of services net revenue is derived from

[0001571996-22-000021:mdna:116]
offerings that have been deferred over a period of time, and, as a result, reported services net revenue growth rates will be different than reported product net revenue growth rates.

[0001571996-22-000021:mdna:117]
From a geographical perspective, net revenue generated by sales to customers in all regions increased during the first quarter of Fiscal 2023, driven by both CSG and ISG.

[0001571996-22-000021:mdna:118]
[same as prior period, unchanged from 0001571996-21-000063:mdna:117]

[0001571996-22-000021:mdna:119]
During the first quarter of Fiscal 2023, our gross margin increased 10% to $5.8 billion and our non-GAAP gross margin increased 9% to $5.9 billion. These increases were driven primarily by growth in ISG gross margin and, to a lesser extent, growth within CSG gross margin as we benefited from continued strength across both businesses.

[0001571996-22-000021:mdna:120]
During the first quarter of Fiscal 2023, our gross margin percentage decreased 120 basis points to 22.1% due to a decline in gross margin percentage for both CSG and ISG, the effect of which was partially offset by the favorable impact of a decrease in amortization of intangible assets.  Both CSG and ISG gross margin percentage declined in part as a result of increased cost of net revenue that was not entirely offset by pricing adjustments.  Increased cost of net revenue was principally driven by the cumulative effect of cost inflation that occurred throughout Fiscal 2022, which broadly impacted our product offerings.  ISG gross margin percentage also declined as a result of a shift in revenue mix towards servers and networking.   Non-GAAP gross margin percentage decreased 150 basis points to 22.7% due to the same CSG and ISG dynamics discussed above.

[0001571996-22-000021:mdna:121]
•Products Gross Margin — During the first quarter of Fiscal 2023, product gross margin increased 13% to $3.5 billion and non-GAAP product gross margin increased 11% to $3.6 billion primarily driven by growth within ISG.  ISG product gross margin increased principally due to revenue growth in our storage offerings coupled with an increase in the average selling price of our server offerings.

[0001571996-22-000021:mdna:122]
During the first quarter of Fiscal 2023, product gross margin percentage decreased 60 basis points to 16.9%, primarily due to a decline in product gross margin percentage for CSG.  The decline in CSG product gross margin percentage was partially offset by growth in product gross margin percentage for ISG coupled with the favorable impact of a decrease in amortization of intangible assets.  Non-GAAP product gross margin percentage decreased 90 basis points to 17.5% and was driven by the same CSG and ISG impacts discussed above.

[0001571996-22-000021:mdna:123]
•Services Gross Margin — During the first quarter of Fiscal 2023, services gross margin and non-GAAP services gross margin both increased 5% to $2.3 billion and $2.4 billion, respectively.  The increases were driven primarily by increased CSG services gross margin as a result of growth within hardware support and maintenance associated with products sold in prior periods.

[0001571996-22-000021:mdna:124]
Services gross margin percentage decreased 210 basis points to 41.2% and non-GAAP services gross margin percentage decreased 220 basis points to 41.8%.  The decreases were primarily driven by declines in services gross margin percentage across CSG and ISG, to a lesser extent, a shift in mix towards CSG.

[0001571996-22-000021:mdna:125]
[same as prior period, unchanged from 0001571996-21-000063:mdna:124]

[0001571996-22-000021:mdna:126]
[same as prior period, unchanged from 0001571996-21-000063:mdna:125]

[0001571996-22-000021:mdna:127]
The terms and conditions of our vendor rebate programs are largely based on product volumes and are generally negotiated either at the beginning of the annual or quarterly period, depending on the program.  The timing and amount of vendor rebates and other discounts we receive under the programs may vary from period to period, reflecting changes in the competitive environment.  We monitor our component costs and seek to address the effects of any changes to terms that might arise under our vendor rebate programs.  Our gross margins for the first quarter of Fiscal 2023 and the first quarter of Fiscal 2022 were not materially affected by any changes to the terms of our vendor rebate programs, as the amounts we received under these programs were generally stable relative to our total net cost.  We are not aware of any significant changes to vendor pricing or rebate programs that may impact our results in the near term.

[0001571996-22-000021:mdna:128]
[same as prior period, unchanged from 0001571996-21-000063:mdna:127]

[0001571996-22-000021:mdna:129]
[same as prior period, unchanged from 0001571996-21-000063:mdna:128]

[0001571996-22-000021:mdna:130]
|  |  |  | Three Months Ended |
|  |  |  |  |  |  |  | April 29, 2022 |  |  |  | April 30, 2021 |  |  |  |  |
|  |  |  |  |  |  |  |  |  |  |  | Dollars |  | % of Net Revenue |  | %Change |  | Dollars |  | % of Net Revenue |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |  |  |  | (in millions, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative |  |  |  |  |  |  |  |  |  |  | $ | 3,553 |  |  | 13.6 | % |  | (3) | % |  | $ | 3,658 |  |  | 16.2 | % |  |  |  |  |  |  |
| Research and development |  |  |  |  |  |  |  |  |  |  | 681 |  |  | 2.6 | % |  | 10 | % |  | 619 |  |  | 2.7 | % |  |  |  |  |  |  |
| Total operating expenses |  |  |  |  |  |  |  |  |  |  | $ | 4,234 |  |  | 16.2 | % |  | (1) | % |  | $ | 4,277 |  |  | 18.9 | % |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |  |  |  | Three Months Ended |
|  |  |  |  |  |  |  |  |  |  |  | April 29, 2022 |  |  |  | April 30, 2021 |  |  |  |  |
|  |  |  |  |  |  |  |  |  |  |  | Dollars |  | % of Non-GAAP Net Revenue |  | %Change |  | Dollars |  | % of Non-GAAP Net Revenue |  |  |  |  |  |  |
|  |  |  |  |  |  |  |  |  |  | (in millions, except percentages) |
| Non-GAAP operating expenses |  |  |  |  |  |  |  |  |  |  | $ | 3,806 |  |  | 14.5 | % |  | 3 | % |  | $ | 3,694 |  |  | 16.4 | % |  |  |  |  |  |  |

[0001571996-22-000021:mdna:131]
During the first quarter of Fiscal 2023, total operating expenses remained essentially flat as a decrease in selling, general, and administrative expenses was mostly offset by an increase in research and development expenses.  Non-GAAP operating expenses increased 3% primarily as a result of increased employee compensation and benefits driven by growth in employee headcount.

[0001571996-22-000021:mdna:132]
•Selling, General, and Administrative — Selling, general, and administrative (“SG&A”) expenses decreased 3% during the first quarter of Fiscal 2023.  The decrease was primarily attributable to a decrease in amortization of intangible assets, partially offset by an increase in employee compensation and benefits principally due to growth in employee headcount.

[0001571996-22-000021:mdna:133]
•Research and Development — Research and development (“R&D”) expenses are primarily composed of personnel-related expenses related to product development.  During the first quarter of Fiscal 2023, R&D expenses grew 10% as a result of an increase in employee compensation and benefits primarily due to growth in employee headcount.  As a percentage of net revenue, R&D expenses for the first three months of Fiscal 2023 and Fiscal 2022 were essentially flat at approximately 2.6% and 2.7%, respectively.  We intend to continue supporting R&D initiatives to innovate and introduce new and enhanced solutions into the market.

[0001571996-22-000021:mdna:134]
We continue to make selective investments designed to enable growth, marketing, and R&D, while balancing our efforts to drive cost efficiencies in the business.  We also expect to continue making investments in support of our own digital transformation to modernize our IT operations.

[0001571996-22-000021:mdna:135]
[same as prior period, unchanged from 0001571996-21-000063:mdna:134]

[0001571996-22-000021:mdna:136]
During the first quarter of Fiscal 2023, our operating income increased 57% to $1.6 billion and our non-GAAP operating income increased 21% to $2.1 billion. These increases were principally attributable to growth in operating income for ISG, driven primarily by our storage offerings.  Operating income also benefited from the favorable impact of a decrease in amortization of intangible assets.

[0001571996-22-000021:mdna:137]
Operating income and non-GAAP operating income as a percentage of net revenue increased 150 basis points to 5.9% and 40 basis points to 8.2%, respectively, primarily driven by ISG.  ISG operating income as a percentage of net revenue increased as a result of a decrease in operating expenses as a percentage of net revenue due to strong revenue growth coupled with disciplined cost management.  These factors were partially offset by a decline in gross margin as a percentage of net revenue for both CSG and ISG which declined in part as a result of increased cost of net revenue that was not entirely offset by pricing adjustments.  Operating income as a percentage of net revenue further benefited from the favorable impact of the decrease in amortization of intangible assets.

[0001571996-22-000021:mdna:138]
[same as prior period, unchanged from 0001571996-21-000063:mdna:137]

[0001571996-22-000021:mdna:139]
[same as prior period, unchanged from 0001571996-21-000063:mdna:138]

[0001571996-22-000021:mdna:140]
|  |  |  | Three Months Ended |
|  |  |  |  |  | April 29, 2022 |  | April 30, 2021 |  |  |
|  |  |  |  |  | (in millions) |
| Interest and other, net: |  |  |  |  |  |  |  |  |  |
| Investment income, primarily interest |  |  |  |  | $ | 15 |  |  | $ | 10 |  |  |  |
| Gain on investments, net |  |  |  |  | 14 |  |  | 193 |  |  |  |
| Interest expense |  |  |  |  | (265) |  |  | (433) |  |  |  |
| Foreign exchange |  |  |  |  | (89) |  |  | (52) |  |  |  |
| Other |  |  |  |  | (12) |  |  | (6) |  |  |  |
| Total interest and other, net |  |  |  |  | $ | (337) |  |  | $ | (288) |  |  |  |

[0001571996-22-000021:mdna:141]
During the first quarter of Fiscal 2023, the change in interest and other, net was unfavorable by $49 million primarily due to a decrease in gain on investments, net, partially offset by a decrease in interest expense resulting from debt repayments.

[0001571996-22-000021:mdna:142]
[same as prior period, unchanged from 0001571996-21-000063:mdna:141]

[0001571996-22-000021:mdna:143]
[same as prior period, unchanged from 0001571996-21-000063:mdna:142]

[0001571996-22-000021:mdna:144]
|  | Three Months Ended |  |  |
|  | April 29, 2022 |  | April 30, 2021 |  |  |
|  | (in millions, except percentages) |
| Income before income taxes | $ | 1,213 |  |  | $ | 699 |  |  |  |
| Income tax expense | $ | 144 |  |  | $ | 40 |  |  |  |
| Effective income tax rate | 11.9 | % |  | 5.7 | % |  |  |

[0001571996-22-000021:mdna:145]
For the first quarter of Fiscal 2023 and the first quarter of Fiscal 2022, our effective income tax rates were 11.9% on pre-tax income of $1.2 billion, and 5.7% on pre-tax income of $0.7 billion, respectively.  The change in our effective income tax rate was primarily driven by the impact of discrete tax benefits related to stock-based compensation, a change in our jurisdictional mix of income, and higher U.S. tax on foreign operations, the effects of which were partially offset by higher benefits from foreign tax credits.

[0001571996-22-000021:mdna:146]
Higher U.S. tax on foreign operations was due to the capitalization of research and development costs.  Under the Tax Cuts and Jobs Act, which was enacted on December 22, 2017, research and development expenses incurred for tax years beginning after December 31, 2021 must be capitalized and amortized ratably over five or 15 years for tax purposes, depending on where the research activities were conducted.  Our effective income tax rate for future quarters of Fiscal 2023 may be impacted by actions taken by the U.S. government to defer or repeal this provision, as well as by the actual mix of jurisdictions in which income is generated and the impact of any discrete tax items.  In addition, if the provision is not deferred or repealed, we expect it will result in a significant increase in our cash tax liabilities for Fiscal 2023, as well as significantly reduce our deferred tax liabilities.

[0001571996-22-000021:mdna:147]
Our effective income tax rate can fluctuate depending on the geographic distribution of our worldwide earnings, as our foreign earnings are generally taxed at lower rates than in the United States.  The differences between our effective income tax rate and the U.S. federal statutory rate of 21% principally result from the geographical distribution of income, differences between the book and tax treatment of certain items, and discrete tax items.  In certain jurisdictions, our tax rate is significantly less than the applicable statutory rate as a result of tax holidays.  The majority of our foreign income that is subject to these tax holidays is attributable to Singapore and China.  A significant portion of these income tax benefits relates to a tax holiday that will be effective until January 31, 2029.  Our other tax holidays will expire in whole or in part during Fiscal 2030 through Fiscal 2031.  Many of these tax holidays and reduced tax rates may be extended when certain conditions are met or may be terminated early if certain conditions are not met.  As of April 29, 2022, we were not aware of any matters of noncompliance related to these tax holidays.

[0001571996-22-000021:mdna:148]
For further discussion regarding tax matters, including the status of income tax audits, see Note 12 of the Notes to the Condensed Consolidated Financial Statements included in this report.

[0001571996-22-000021:mdna:149]
Net Income from Continuing Operations

[0001571996-22-000021:mdna:150]
Net income from continuing operations was $1.1 billion in the first quarter of Fiscal 2023, compared to $0.7 billion in the first quarter of Fiscal 2022 while non-GAAP net income was $1.4 billion in the first quarter of Fiscal 2023, compared to $1.1 billion in the first quarter of Fiscal 2022.  The increases were primarily attributable to an increase in operating income, partially offset by an increase in tax expense during the period.  Non-GAAP net income further benefited from a favorable change in interest and other, net.

[0001571996-22-000021:mdna:151]
[same as prior period, unchanged from 0001571996-21-000063:mdna:87]

[0001571996-22-000021:mdna:152]
[same as prior period, unchanged from 0001571996-21-000063:mdna:155]

[0001571996-22-000021:mdna:153]
Our reportable segments are based on the ISG and CSG business units.  A description of our business units is provided under “Introduction.”  See Note 17 of the Notes to the Condensed Consolidated Financial Statements included in this report for a reconciliation of net revenue and operating income by reportable segment to consolidated net revenue and consolidated operating income (loss), respectively.

[0001571996-22-000021:mdna:154]
[same as prior period, unchanged from 0001571996-21-000063:mdna:157]

[0001571996-22-000021:mdna:155]
[same as prior period, unchanged from 0001571996-21-000063:mdna:158]

[0001571996-22-000021:mdna:156]
|  |  |  | Three Months Ended |
|  |  |  |  |  |  |  | April 29, 2022 |  | % Change |  | April 30, 2021 |  |  |  |  |
|  |  |  |  |  |  |  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Servers and networking |  |  |  |  |  |  | $ | 5,048 |  | 22 | % |  | $ | 4,140 |  |  |  |  |
| Storage |  |  |  |  |  |  | 4,237 |  | 9 | % |  | 3,893 |  |  |  |  |
| Total ISG net revenue |  |  |  |  |  |  | $ | 9,285 |  | 16 | % |  | $ | 8,033 |  |  |  |  |
| Operating income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| ISG operating income |  |  |  |  |  |  | $ | 1,082 |  | 39 | % |  | $ | 778 |  |  |  |  |
| % of segment net revenue |  |  |  |  |  |  | 11.7 | % |  |  |  | 9.7 | % |  |  |  |  |

[0001571996-22-000021:mdna:157]
Net Revenue — During the first quarter of Fiscal 2023, ISG net revenue increased 16% due to growth in net revenue for both servers and networking and storage as a result of demand for IT infrastructure as customers continue to invest in digital transformation.

[0001571996-22-000021:mdna:158]
Revenue from the sales of servers and networking increased 22% during the first quarter of Fiscal 2023.  The increased revenue was primarily driven by an increase in average selling price of our server offerings as we continue to manage pricing in response to supply chain challenges including component availability and increased logistics costs.

[0001571996-22-000021:mdna:159]
During the first quarter of Fiscal 2023, storage revenue increased 9% due to strength across the majority of our storage offerings.

[0001571996-22-000021:mdna:160]
ISG customers are interested in new and innovative models that address how they consume our solutions.  We offer options that include as-a-Service, utility, leases, and immediate pay models which are designed to match customers’ consumption and financing preferences.  Our multiyear agreements typically result in recurring revenue streams over the term of the arrangement.  We expect that our flexible consumption models and as-a-Service offerings through APEX will further strengthen our customer relationships and provide a foundation for growth in recurring revenue.

[0001571996-22-000021:mdna:161]
From a geographical perspective, net revenue attributable to ISG increased in all regions during the first quarter of Fiscal 2023.

[0001571996-22-000021:mdna:162]
Operating Income — During the first quarter of Fiscal 2023, ISG operating income as a percentage of net revenue increased 200 basis points to 11.7% primarily due to a decrease in operating expenses as a percentage of revenue that resulted from strong revenue growth coupled with disciplined cost management.  The favorable impact of the decrease in operating expenses as a percentage of revenue was partially offset by the impact of a shift in revenue mix towards servers and networking.

[0001571996-22-000021:mdna:163]
[same as prior period, unchanged from 0001571996-21-000063:mdna:167]

[0001571996-22-000021:mdna:164]
[same as prior period, unchanged from 0001571996-21-000063:mdna:168]

[0001571996-22-000021:mdna:165]
|  |  |  | Three Months Ended |
|  |  |  |  |  |  |  | April 29, 2022 |  | % Change |  | April 30, 2021 |  |  |  |  |
|  |  |  |  |  |  |  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial |  |  |  |  |  |  | $ | 11,971 |  | 22 | % |  | $ | 9,808 |  |  |  |  |
| Consumer |  |  |  |  |  |  | 3,616 |  | 3 | % |  | 3,503 |  |  |  |  |
| Total CSG net revenue |  |  |  |  |  |  | $ | 15,587 |  | 17 | % |  | $ | 13,311 |  |  |  |  |
| Operating income: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| CSG operating income |  |  |  |  |  |  | $ | 1,115 |  | 3 | % |  | $ | 1,080 |  |  |  |  |
| % of segment net revenue |  |  |  |  |  |  | 7.2 | % |  |  |  | 8.1 | % |  |  |  |  |

[0001571996-22-000021:mdna:166]
Net Revenue — During the first quarter of Fiscal 2023, CSG net revenue increased 17% primarily driven by an increase in revenue attributable to our commercial offerings.

[0001571996-22-000021:mdna:167]
Commercial and consumer net revenue increased 22% and 3%, respectively, primarily due to an increase in average selling price across our product offerings.  To a lesser extent, an increase in units sold of commercial offerings also contributed to net revenue growth.  Within consumer, the effect of increased average selling price was partially offset by a decrease in units sold.  We increased average selling prices for both our commercial and consumer offerings as we continued to manage pricing in response to supply chain challenges including component availability and increased logistic costs.

[0001571996-22-000021:mdna:168]
From a geographical perspective, net revenue attributable to CSG increased across all regions during the first quarter of Fiscal 2023.

[0001571996-22-000021:mdna:169]
Operating Income — During the first quarter of Fiscal 2023, CSG operating income as a percentage of net revenue decreased 90 basis points to 7.2% primarily as a result of increased cost of net revenue that was not entirely offset by pricing adjustments.  Increased cost of net revenue was principally driven by the cumulative effect of cost inflation that occurred throughout Fiscal 2022, which broadly impacted our product offerings.  These factors were partially offset by a decrease in operating expenses as a percentage of revenue.

[0001571996-22-000021:mdna:170]
[same as prior period, unchanged from 0001571996-21-000063:mdna:183]

[0001571996-22-000021:mdna:171]
[same as prior period, unchanged from 0001571996-21-000063:mdna:184]

[0001571996-22-000021:mdna:172]
We sell products and services directly to customers and through a variety of sales channels, including retail distribution.  Our accounts receivable, net, was $11.8 billion and $12.9 billion as of April 29, 2022 and January 28, 2022, respectively.  We maintain an allowance for expected credit losses to cover receivables that may be deemed uncollectible.  As of April 29, 2022 and January 28, 2022, the allowance for expected credit losses was $72 million and $90 million, respectively.  Based on our assessment, we believe that we are adequately reserved for expected credit losses.  We will continue to monitor the aging of our accounts receivable and take actions, where necessary, to reduce our exposure to credit losses.

[0001571996-22-000021:mdna:173]
Dell Financial Services and Financing Receivables

[0001571996-22-000021:mdna:174]
The Company offers or arranges various financing options and services for our customers globally, including through captive financing operations.  DFS originates, collects, and services customer receivables primarily related to the purchase of our product, software, and service solutions.  The Company further strengthens our customer relationships through its flexible consumption models, which enable us to offer our customers the option to pay over time and, in certain cases, based on utilization, to provide them with financial flexibility to meet their changing technological requirements.  New financing originations were $2.1 billion and $1.9 billion for the first quarter of Fiscal 2023 and Fiscal 2022, respectively.

[0001571996-22-000021:mdna:175]
The Company’s leases are generally classified as sales-type leases or operating leases.  Amounts due from lessees under sales-type leases or direct financing leases are recorded as part of financing receivables, with interest income recognized over the contract term.  On commencement of sales-type leases, we typically qualify for up-front revenue recognition.  On originations of operating leases, we record equipment under operating leases, classified as property, plant, and equipment, and recognize rental revenue and depreciation expense, classified as cost of net revenue, over the contract term.

[0001571996-22-000021:mdna:176]
As of April 29, 2022 and January 28, 2022, our financing receivables, net were $10.2 billion and $10.6 billion, respectively.  We maintain an allowance to cover expected financing receivable credit losses and evaluate credit loss expectations based on our total portfolio.  For both the first quarter of Fiscal 2023 and Fiscal 2022, the principal charge-off rate for our financing receivables portfolio was 0.5%.  The credit quality of our financing receivables has improved in recent years as the mix of high-quality commercial accounts in our portfolio has continued to increase.  We continue to monitor broader economic indicators and their potential impact on future credit loss performance.  We have an extensive process to manage our exposure to customer credit risk, including active management of credit lines and our collection activities.  We also sell selected fixed-term financing receivables without recourse to unrelated third parties on a periodic basis, primarily to manage certain concentrations of customer credit exposure.  Based on our assessment of the customer financing receivables, we believe that we are adequately reserved.

[0001571996-22-000021:mdna:177]
We retain a residual interest in equipment leased under our lease programs.  As of April 29, 2022 and January 28, 2022, the residual interest recorded as part of financing receivables was $176 million and $217 million, respectively.  The decline in residual interest was principally attributable to a corresponding increase in originations of operating leases.  The amount of the residual interest is established at the inception of the lease based upon estimates of the value of the equipment at the end of the lease term using historical studies, industry data, and future value-at-risk demand valuation methods.  On a quarterly basis, we assess the carrying amount of our recorded residual values for impairment.  Generally, expected losses as a result of residual value risk on equipment under lease are not considered to be significant primarily because of the existence of a secondary market with respect to the equipment.  Further, the lease agreement clearly defines applicable return conditions and remedies for non-compliance, to ensure that the leased equipment will be in good operating condition upon return.  No expected losses were recorded related to residual assets during the first quarter of Fiscal 2023 and Fiscal 2022.

[0001571996-22-000021:mdna:178]
As of April 29, 2022 and January 28, 2022, equipment under operating leases, net was $1.9 billion and $1.7 billion, respectively.  We assess the carrying amount of the equipment under operating leases for impairment whenever events or circumstances may indicate that an impairment has occurred.  No material impairment losses were recorded related to such equipment during the first quarter of Fiscal 2023 and Fiscal 2022.

[0001571996-22-000021:mdna:179]
DFS offerings are initially funded through cash on hand at the time of origination, most of which is subsequently replaced with asset-backed financing.  For DFS offerings which qualify as sales-type leases, the initial funding of financing receivables is reflected as an impact to cash flows from operations, and is largely subsequently offset by cash proceeds from financing.

[0001571996-22-000021:mdna:180]
For DFS operating leases, the initial funding is classified as a capital expenditure and reflected as an impact to cash flows used in investing activities.

[0001571996-22-000021:mdna:181]
See Note 5 of the Notes to the Condensed Consolidated Financial Statements included in this report for additional information about our financing receivables and the associated allowances, and equipment under operating leases.

[0001571996-22-000021:mdna:182]
74

[0001571996-22-000021:mdna:183]
LIQUIDITY, CAPITAL COMMITMENTS, AND MARKET CONDITIONS

[0001571996-22-000021:mdna:184]
[same as prior period, unchanged from 0001571996-21-000063:mdna:203]

[0001571996-22-000021:mdna:185]
[same as prior period, unchanged from 0001571996-21-000063:mdna:204]

[0001571996-22-000021:mdna:186]
We believe that our current cash and cash equivalents, together with cash that will be provided by future operations and borrowings expected to be available under our revolving credit facility, will be sufficient over at least the next twelve months and for the foreseeable future thereafter meet our material cash requirements, including funding of our operations, debt-related payments, capital expenditures, and other corporate needs.

[0001571996-22-000021:mdna:187]
As part of our overall capital allocation strategy, we intend to drive growth while maintaining our investment grade rating and focusing on returning capital to our stockholders through both share repurchase programs and dividend payments.

[0001571996-22-000021:mdna:188]
[same as prior period, unchanged from 0001571996-21-000063:mdna:205]

[0001571996-22-000021:mdna:189]
|  | April 29, 2022 |  | January 28, 2022 |
|  | (in millions) |
| Cash and cash equivalents, and available borrowings: |  |  |  |
| Cash and cash equivalents | $ | 6,654 |  |  | $ | 9,477 |  |
| Remaining available borrowings under revolving credit facilities | 4,969 |  |  | 4,969 |  |
| Total cash, cash equivalents, and available borrowings | $ | 11,623 |  |  | $ | 14,446 |  |

[0001571996-22-000021:mdna:190]
During the first quarter of Fiscal 2023, cash and cash equivalents decreased by $2.8 billion, primarily driven by return of approximately $1.75 billion of capital to stockholders through both share repurchases and our first quarterly dividend payment.

[0001571996-22-000021:mdna:191]
Our revolving credit facilities as of April 29, 2022 consist of the 2021 Revolving Credit Facility, which has a maximum capacity of $5.0 billion.  Available borrowings under this facility are reduced by draws on the facility and outstanding letters of credit.  As of April 29, 2022, there were no borrowings outstanding under the facility and remaining available borrowings totaled approximately $5.0 billion.  We may regularly use our available borrowings from the 2021 Revolving Credit Facility on a short-term basis for general corporate purposes.  See Note 7 of the Notes to the Condensed Consolidated Financial Statements included in this report for additional information about the 2021 Revolving Credit Facility.

[0001571996-22-000021:mdna:192]
[same as prior period, unchanged from 0001571996-21-000063:mdna:215]

[0001571996-22-000021:mdna:193]
The following table presents our outstanding debt as of the dates indicated:

[0001571996-22-000021:mdna:194]
|  | April 29, 2022 |  | Change |  | January 28, 2022 |
|  | (in millions) |
| Core debt |  |  |  |  |  |
| Senior Notes | $ | 16,300 |  |  | $ | — |  |  | $ | 16,300 |  |
| Legacy Notes and Debentures | 952 |  |  | — |  |  | 952 |  |
| DFS allocated debt | (728) |  |  | 405 |  |  | (1,133) |  |
| Total core debt | 16,524 |  |  | 405 |  |  | 16,119 |  |
| DFS related debt |  |  |  |  |  |
| DFS debt | 9,825 |  |  | 179 |  |  | 9,646 |  |
| DFS allocated debt | 728 |  |  | (405) |  |  | 1,133 |  |
| Total DFS related debt | 10,553 |  |  | (226) |  |  | 10,779 |  |
| Other | 320 |  |  | (17) |  |  | 337 |  |
| Total debt, principal amount | 27,397 |  |  | 162 |  |  | 27,235 |  |
| Carrying value adjustments | (275) |  |  | 6 |  |  | (281) |  |
| Total debt, carrying value | $ | 27,122 |  |  | $ | 168 |  |  | $ | 26,954 |  |

[0001571996-22-000021:mdna:195]
During the first quarter of Fiscal 2023, the outstanding principal amount of our debt increased by $0.2 billion to $27.4 billion as of April 29, 2022, primarily driven by net DFS debt activity.

[0001571996-22-000021:mdna:196]
We define core debt as the total principal amount of our debt, less DFS related debt and other debt.  Our core debt was $16.5 billion and $16.1 billion as of April 29, 2022 and January 28, 2022, respectively.  See Note 7 of the Notes to the Condensed Consolidated Financial Statements included in this report for more information about our debt.

[0001571996-22-000021:mdna:197]
DFS related debt primarily represents debt from our securitization and structured financing programs.  Our risk of loss under these programs is limited to transferred lease and loan payments and associated equipment, as the credit holders have no recourse to Dell Technologies.

[0001571996-22-000021:mdna:198]
To fund expansion of the DFS business, we balance the use of the securitization and structured financing programs with other sources of liquidity.  We approximate the amount of our debt used to fund the DFS business by applying a 7:1 debt to equity ratio to the sum of our financing receivables balance and equipment under our DFS operating leases, net.  The debt to equity ratio is based on the underlying credit quality of the assets.  See Note 5 of the Notes to the Condensed Consolidated Financial Statements included in this report for more information about our DFS debt.

[0001571996-22-000021:mdna:199]
We have made steady progress in paying down debt and we will continue to pursue deleveraging as an important component of our overall strategy.  As a result of our debt reduction and liability management strategy, we achieved an investment grade corporate family rating from three major credit rating agencies during Fiscal 2022.

[0001571996-22-000021:mdna:200]
We believe we will continue to be able to make our debt principal and interest payments, including the short-term maturities, from existing and expected sources of cash, primarily from operating cash flows.  Cash used for debt principal and interest payments may include short-term borrowings under our revolving credit facility.  Under our variable-rate debt, we could experience variations in our future interest expense from potential fluctuations in applicable reference rates, or from possible fluctuations in the level of DFS debt required to meet future demand for customer financing.  There are no scheduled maturities related to our outstanding core debt during Fiscal 2023.  However, at our sole discretion, we may purchase, redeem, prepay, refinance, or otherwise retire any amount of our outstanding indebtedness under the terms of such indebtedness at any time and from time to time, in open market or negotiated transactions with the holders of such indebtedness or otherwise, as appropriate market conditions exist.

[0001571996-22-000021:mdna:201]
76

[0001571996-22-000021:mdna:202]
[same as prior period, unchanged from 0001571996-21-000063:mdna:229]

[0001571996-22-000021:mdna:203]
[same as prior period, unchanged from 0001571996-21-000063:mdna:230]

[0001571996-22-000021:mdna:204]
|  | Three Months Ended |
|  | April 29, 2022 |  | April 30, 2021 |  |  |
|  | (in millions) |
| Net change in cash from: |  |  |  |  |  |
| Operating activities | $ | (269) |  |  | $ | 2,238 |  |  |  |
| Investing activities | (720) |  |  | (519) |  |  |  |
| Financing activities | (1,706) |  |  | (1,638) |  |  |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash | (111) |  |  | (5) |  |  |  |
| Change in cash, cash equivalents, and restricted cash | $ | (2,806) |  |  | $ | 76 |  |  |  |

[0001571996-22-000021:mdna:205]
Cash flows for the three months ended April 30, 2021 are inclusive of cash flows attributable to VMware.  Effective November 1, 2021, as a result of the VMware Spin-off, cash flows ceased to include VMware.  See “Introduction” and Note 1 and Note 2 of the Notes to the Condensed Consolidated Financial Statements included in this report for additional information regarding the VMware Spin-off.

[0001571996-22-000021:mdna:206]
Operating Activities — Cash used by operating activities of $0.3 billion during the first quarter of Fiscal 2023 primarily reflected lower seasonal sales trends affecting parts of our business as well as the timing of annual personnel-related payments.  Operating cash flows were also impacted by higher than normal inventory balances as we continue to proactively manage supply chain challenges.  During the first quarter of Fiscal 2022, cash provided by operating activities was $2.2 billion, of which $1.3 billion related to VMware, and was driven by both working capital management and profitability.

[0001571996-22-000021:mdna:207]
Investing Activities — Investing activities primarily consist of cash used to fund capital expenditures for property, plant, and equipment, which includes equipment under DFS operating leases.  Additional activities include capitalized software development costs, strategic investments, and the maturities, sales, and purchases of investments.  During the first quarter of Fiscal 2023 and Fiscal 2022, cash used in investing activities was $0.7 billion and $0.5 billion, respectively, and was primarily used by capital expenditures.

[0001571996-22-000021:mdna:208]
Financing Activities — Financing activities primarily consist of the proceeds and repayments of debt and cash used to repurchase common stock.  Cash used in financing activities was $1.7 billion during the first quarter of Fiscal 2023 and primarily consisted of repurchases of common stock, including shares repurchased to settle employee tax withholding on stock-based compensation, and the payment of our first quarterly dividend.  Cash used in financing activities of $1.6 billion during the first quarter of Fiscal 2022 primarily consisted of debt repayments and repurchases of common stock by our public subsidiaries.

[0001571996-22-000021:mdna:209]
DFS Cash Flow Impacts  — DFS offerings are initially funded through cash on hand at the time of origination, most of which is subsequently replaced with asset-backed financing.  For DFS offerings that qualify as sales-type leases, the initial funding of financing receivables is reflected as an impact to cash flows from operations and is largely subsequently offset by cash proceeds from financing.  For DFS operating leases, which have increased under the current lease accounting standard, the initial funding is classified as a capital expenditure and reflected as cash flows used in investing activities.  DFS new financing originations were $2.1 billion and $1.9 billion during the first quarter of Fiscal 2023 and Fiscal 2022, respectively.  As of April 29, 2022, DFS had $10.2 billion of total net financing receivables and $1.9 billion of equipment under DFS operating leases, net.

[0001571996-22-000021:mdna:210]
[same as prior period, unchanged from 0001571996-21-000063:mdna:236]

[0001571996-22-000021:mdna:211]
Capital Expenditures — We spent $0.7 billion during the first quarter of Fiscal 2023 and Fiscal 2022 on property, plant, and equipment and capitalized software development costs, of which the funding of equipment under DFS operating leases totaled $0.2 billion for both periods.  Product demand, product mix, the use of contract manufacturers, and ongoing investments in operating and information technology infrastructure, influence the level and prioritization of our capital expenditures.  Aggregate capital expenditures for Fiscal 2023 are currently expected to total between $2.9 billion and $3.1 billion, of which approximately $0.9 billion of expenditures are expected to be applied to equipment under DFS operating leases and approximately $0.3 billion to capitalized software development costs.

[0001571996-22-000021:mdna:212]
Repurchases of Common Stock — Effective as of September 23, 2021, our board of directors approved a stock repurchase program with no established expiration date under which we are authorized to repurchase up to $5 billion of shares of our Class C Common Stock.  During the first quarter of Fiscal 2023, we repurchased approximately 29 million shares of Class C Common Stock for a total purchase price of approximately $1.5 billion.  These amounts exclude shares repurchased to settle employee tax withholding related to the vesting of stock awards.

[0001571996-22-000021:mdna:213]
Dividend Payments — On February 24, 2022, the Company announced that its Board of Directors has adopted a dividend policy under which the Company intends to pay quarterly cash dividends on its common stock at an initial rate of $0.33 per share per fiscal quarter.

[0001571996-22-000021:mdna:214]
During the three months ended April 29, 2022, the Company paid an initial quarterly dividend under the new policy in the amount of $248 million to the holders of record of all of the issued and outstanding shares of common stock as of the close of business on April 20, 2022.

[0001571996-22-000021:mdna:215]
[same as prior period, unchanged from 0001571996-21-000063:mdna:239]

[0001571996-22-000021:mdna:216]
We utilize several suppliers to manufacture sub-assemblies for our products.  Our efficient supply chain management allows us to enter into flexible and mutually beneficial purchase arrangements with our suppliers in order to minimize inventory risk.  Consistent with industry practice, we acquire raw materials or other goods and services, including product components, by issuing to suppliers authorizations to purchase based on our projected demand and manufacturing needs.  These purchase orders are typically fulfilled within 30 days and are entered into during the ordinary course of business in order to establish best pricing and continuity of supply for our production.  Purchase orders are not included in purchase obligations, as they typically represent our authorization to purchase rather than binding purchase obligations.

[0001571996-22-000021:mdna:217]
As of April 29, 2022, such purchase obligations were $3.1 billion, $0.4 billion, and $0.8 billion for the remaining nine months of Fiscal 2023, Fiscal 2024, and Fiscal 2025 and thereafter, respectively.

[0001571996-22-000021:mdna:218]
[same as prior period, unchanged from 0001571996-21-000063:mdna:197]

[0001571996-22-000021:mdna:219]
[same as prior period, unchanged from 0001571996-21-000063:mdna:198]

[0001571996-22-000021:mdna:220]
[same as prior period, unchanged from 0001571996-21-000063:mdna:199]

[0001571996-22-000021:mdna:221]
We use derivative instruments to hedge certain foreign currency exposures.  We use forward contracts and purchased options designated as cash flow hedges to protect against the foreign currency exchange rate risks inherent in our forecasted transactions denominated in currencies other than the U.S. dollar.  In addition, we primarily use forward contracts and may use purchased options to hedge monetary assets and liabilities denominated in a foreign currency.  See Note 8 of the Notes to the Condensed Consolidated Financial Statements included in this report for more information about our use of derivative instruments.

[0001571996-22-000021:mdna:222]
We are exposed to interest rate risk related to our variable-rate debt portfolio.  In the normal course of business we follow established policies and procedures to manage this risk, including monitoring of our asset and liability mix.  As a result, we do not anticipate any material losses from interest rate risk.

[0001571996-22-000021:mdna:223]
[same as prior period, unchanged from 0001571996-21-000063:mdna:243]

[0001571996-22-000021:mdna:224]
As discussed in Note 7 of the Notes to the Condensed Consolidated Financial Statements included in this report, Dell International L.L.C. and EMC Corporation (the “Issuers”), both of which are wholly-owned subsidiaries of Dell Technologies, completed private offerings of multiple series of senior secured notes issued on June 1, 2016, March 20, 2019, and April 9, 2020 (the “Senior Notes”).  In June 2021, the Issuers completed an exchange offer and issued $18.4 billion aggregate principal amount of registered senior notes under the Securities Act of 1933 in exchange for the same principal amount and substantially identical terms of the Senior Notes.  The aggregate principal amount of unregistered Senior Notes remaining outstanding following the settlement of the exchange offer was approximately $0.1 billion. During Fiscal 2022, the tangible and intangible assets of the Issuers and guarantors that secured obligations under the Senior Notes were released as collateral.  As a result, the Senior Notes became fully unsecured.  In addition, all guarantees of the Senior Notes by subsidiaries of Dell Inc. were released.

[0001571996-22-000021:mdna:225]
Guarantees — The Senior Notes are guaranteed on a joint and several unsecured basis by Dell Technologies and its wholly-owned subsidiaries, Denali Intermediate, Inc. and Dell Inc. (collectively, the “Guarantors”).

[0001571996-22-000021:mdna:226]
Basis of Preparation of the Summarized Financial Information — The tables below are summarized financial information provided in conformity with Rule 13-01 of the SEC’s Regulation S-X.  The summarized financial information of the Issuers and Guarantors (collectively, the “Obligor Group”) is presented on a combined basis, excluding intercompany balances and transactions between entities in the Obligor Group.  The Obligor Group’s amounts due from, amounts due to, and transactions with Non-Obligor Subsidiaries and VMware, Inc. and its consolidated subsidiaries (the “Related Party”) have been presented separately.  The Obligor Group’s investment balances in Non-Obligor Subsidiaries have been excluded.

[0001571996-22-000021:mdna:227]
[same as prior period, unchanged from 0001571996-21-000063:mdna:248]

[0001571996-22-000021:mdna:228]
|  | Three Months Ended |
|  | April 29, 2022 |
|  | (in millions) |
| Net revenue (a) | $ | 2,504 |  |
| Gross margin (b) | 1,115 |  |
| Operating income | 275 |  |
| Interest and other, net (c) | (544) |  |
| Loss before income taxes | (269) |  |
| Net loss attributable to Obligor Group | $ | (171) |  |

[0001571996-22-000021:mdna:229]
[same as prior period, unchanged from 0001571996-21-000063:mdna:207]

[0001571996-22-000021:mdna:230]
(a)  Includes net revenue from services provided and product sales to Non-Obligor Subsidiaries of $277 million and $35 million, respectively.

[0001571996-22-000021:mdna:231]
(b)  Includes cost of net revenue from resale of solutions purchased from Non-Obligor Subsidiaries and the Related Party of $251 million and $171 million, respectively.  Includes costs of net revenue from shared services provided by Non-Obligor Subsidiaries of $184 million.

[0001571996-22-000021:mdna:232]
(c)   Includes interest expense on inter-company loan payables of $302 million.

[0001571996-22-000021:mdna:233]
[same as prior period, unchanged from 0001571996-21-000063:mdna:254]

[0001571996-22-000021:mdna:234]
|  | April 29, 2022 |  | January 28, 2022 |
|  | (in millions) |
| ASSETS |
| Current assets | $ | 3,038 |  |  | $ | 3,106 |  |
| Intercompany receivables | 623 |  |  | 988 |  |
| Due from related party, net | 65 |  |  | 59 |  |
| Total current assets | 3,726 |  |  | 4,153 |  |
| Due from related party, net | 713 |  |  | 710 |  |
| Goodwill and intangible assets | 15,259 |  |  | 15,399 |  |
| Other non-current assets | 2,857 |  |  | 2,810 |  |
| Total assets | $ | 22,555 |  |  | $ | 23,072 |  |
| LIABILITIES |
| Current liabilities | $ | 4,616 |  |  | $ | 4,625 |  |
| Due to related party | 81 |  |  | 192 |  |
| Total current liabilities | 4,697 |  |  | 4,817 |  |
| Long-term debt | 17,006 |  |  | 17,001 |  |
| Intercompany loan payables | 37,476 |  |  | 37,509 |  |
| Other non-current liabilities | 3,515 |  |  | 3,473 |  |
| Total liabilities | $ | 62,694 |  |  | $ | 62,800 |  |

[0001571996-22-000021:mdna:235]
80
