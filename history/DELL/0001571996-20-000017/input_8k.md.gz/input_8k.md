# DELL 8-K — 0001571996-20-000009 filed 2020-02-27

## item codes, every 8-K on or before 2020-03-27

- 2020-03-26 0001571996-20-000015 — 7.01
- 2020-02-27 0001571996-20-000009 — 2.02, 8.01, 9.01
- 2020-02-18 0001571996-20-000005 — 8.01, 9.01
- 2020-01-09 0001571996-20-000002 — 3.02
- 2020-01-06 0001193125-20-002200 — 3.02
- 2019-12-13 0001193125-19-313947 — 3.02
- 2019-12-10 0001571996-19-000052 — 5.02
- 2019-12-02 0001571996-19-000044 — 5.02, 7.01, 9.01
- 2019-11-26 0001571996-19-000042 — 2.02, 9.01
- 2019-09-23 0001193125-19-252192 — 1.01, 2.03, 9.01
- 2019-08-29 0001571996-19-000036 — 2.02, 9.01
- 2019-08-22 0001193125-19-226939 — 7.01, 8.01, 9.01
- 2019-07-11 0001571996-19-000032 — 5.02, 5.07, 9.01
- 2019-07-03 0001571996-19-000030 — 3.02
- 2019-06-27 0001571996-19-000028 — 3.02
- 2019-05-30 0001571996-19-000021 — 2.02, 9.01
- 2019-04-02 0001571996-19-000010 — 5.02
- 2019-03-21 0001193125-19-082281 — 1.01, 1.02, 2.03, 9.01
- 2019-03-19 0001571996-19-000005 — 5.02, 9.01
- 2019-03-14 0001193125-19-074935 — 1.01, 2.03, 9.01
- 2019-03-07 0001193125-19-066045 — 8.01, 9.01
- 2019-02-28 0001571996-19-000002 — 2.02, 9.01
- 2018-12-28 0001193125-18-360943 — 1.01, 1.02, 3.01, 3.03, 5.02, 5.03, 7.01, 8.01, 9.01
- 2018-12-21 0001193125-18-356324 — 1.01, 2.03, 9.01
- 2018-12-14 0001193125-18-349469 — 8.01
- 2018-12-11 0001193125-18-346958 — 5.07, 8.01, 9.01
- 2018-11-29 0001571996-18-000041 — 2.02, 9.01
- 2018-11-28 0001571996-18-000037 — 7.01, 8.01, 9.01
- 2018-11-26 0001193125-18-333967 — 8.01, 9.01
- 2018-11-15 0001193125-18-328110 — 1.01, 9.01 — amendment of 0001193125-18-327222
- 2018-11-15 0001193125-18-327222 — 1.01, 7.01, 9.01
- 2018-10-03 0001193125-18-291390 — 8.01
- 2018-09-06 0001571996-18-000029 — 2.02, 9.01
- 2018-08-06 0001571996-18-000027 — 8.01, 9.01
- 2018-07-02 0001193125-18-210339 — 1.01, 7.01, 9.01
- 2018-06-28 0001571996-18-000024 — 5.07
- 2018-06-04 0001571996-18-000019 — 2.02, 9.01
- 2018-05-17 0001571996-18-000016 — 7.01
- 2018-04-26 0001571996-18-000009 — 7.01, 9.01
- 2018-03-08 0001193125-18-074168 — 2.02, 9.01
- 2018-02-02 0001193125-18-029947 — 7.01, 9.01
- 2017-12-07 0001571996-17-000042 — 2.02, 9.01
- 2017-10-24 0001571996-17-000037 — 1.01, 2.03, 9.01
- 2017-09-15 0001571996-17-000027 — 5.02
- 2017-09-07 0001571996-17-000017 — 2.02, 9.01
- 2017-08-24 0001571996-17-000014 — 8.01
- 2017-06-29 0001571996-17-000011 — 3.03, 5.07, 8.01, 9.01
- 2017-06-08 0001193125-17-197638 — 2.02, 9.01
- 2017-03-30 0001193125-17-102794 — 8.01
- 2017-03-30 0001193125-17-102777 — 2.02, 9.01
- 2017-03-09 0001193125-17-076981 — 1.01, 2.03, 9.01
- 2017-01-17 0001193125-17-011125 — 8.01
- 2016-12-15 0001193125-16-793722 — 8.01
- 2016-12-08 0001193125-16-787976 — 2.02, 9.01
- 2016-11-10 0001193125-16-765964 — 1.02, 8.01
- 2016-11-04 0001193125-16-760249 — 8.01
- 2016-09-13 0001193125-16-708600 — 3.02
- 2016-09-09 0001193125-16-706567 — 1.01, 1.02, 2.01, 2.03, 3.02, 3.03, 5.02, 9.01
- 2016-09-07 0001193125-16-703370 — 3.03, 5.07, 7.01, 8.01, 9.01
- 2016-09-06 0001193125-16-702057 — 2.02, 9.01
- 2016-08-31 0001193125-16-697268 — 8.01, 9.01
- 2016-08-26 0001193125-16-692921 — 8.01, 9.01
- 2016-07-11 0001193125-16-645610 — 8.01
- 2016-07-05 0001193125-16-641679 — 8.01
- 2016-06-22 0001193125-16-629055 — 1.01, 2.03, 8.01, 9.01
- 2016-06-21 0001193125-16-627071 — 8.01, 9.01
- 2016-06-10 0001193125-16-618483 — 2.02, 9.01
- 2016-06-09 0001193125-16-617893 — 8.01, 9.01

## late-filing notifications on or before 2020-03-27

- none on or before 2020-03-27

## item 2.02 — earnings release, exhibit 99.1

[0001571996-20-000009:8k_2_02:1]
EX-99.1
2
exhibit991earnings8kfy.htm
EXHIBIT 99.1

[0001571996-20-000009:8k_2_02:2]
Exhibit

[0001571996-20-000009:8k_2_02:3]
Exhibit 99.1

[0001571996-20-000009:8k_2_02:4]
News Release

[0001571996-20-000009:8k_2_02:5]
Dell Technologies Reports Fiscal Year 2020 Fourth Quarter

[0001571996-20-000009:8k_2_02:6]
and Full Year Financial Results

[0001571996-20-000009:8k_2_02:7]
ROUND ROCK, Texas — February 27, 2020

[0001571996-20-000009:8k_2_02:8]
News summary

[0001571996-20-000009:8k_2_02:9]
| • | Record full year revenue of $92.2 billion |

[0001571996-20-000009:8k_2_02:10]
| • | Full year net income of $5.5 billion; adjusted EBITDA of $11.8 billion |

[0001571996-20-000009:8k_2_02:11]
| • | Record Client Solutions Group full year revenue of $45.8 billion |

[0001571996-20-000009:8k_2_02:12]
| • | Share repurchase program of up to $1 billion over the next 24 months |

[0001571996-20-000009:8k_2_02:13]
Full story

[0001571996-20-000009:8k_2_02:14]
Dell Technologies (NYSE: DELL) announces financial results for its fiscal 2020 fourth quarter and full year.

[0001571996-20-000009:8k_2_02:15]
Fourth quarter revenue was $24.0 billion, up 1 percent, and non-GAAP revenue was $24.1 billion, up 1 percent, over the same period last year.  During the quarter, the company generated operating income of $717 million, a 117 percent increase over the same period in the prior year, and non-GAAP operating income of $2.8 billion, up 4 percent over the prior year.  Net income was $416 million or approximately 2 percent of revenue.  Non-GAAP net income was $1.7 billion or 7 percent of non-GAAP revenue.  Diluted earnings per share was $0.54 and non-GAAP diluted earnings per share was $2.00.

[0001571996-20-000009:8k_2_02:16]
For the full year, revenue was $92.2 billion, up 2 percent, and non-GAAP revenue was $92.5 billion, up 1 percent, over the prior year.  The company increased its operating income to $2.6 billion from a $0.2 billion loss in the prior year and generated non-GAAP operating income of $10.1 billion, up 15 percent over the prior year.  Cash flow from operations was $9.3 billion, up 33 percent from fiscal year 2019.  For the full year, net income was $5.5 billion and non-GAAP net income was $6.1 billion.  Diluted earnings per share was $6.03 and non-GAAP diluted earnings per share was $7.35.

[0001571996-20-000009:8k_2_02:17]
“In fiscal 2020, we focused on integration and simplicity across our businesses and product portfolio to accelerate winning go-to-market solutions for our customers,” said Jeff Clarke, chief operating officer, Dell Technologies.  “With more than $180 billion in revenue over the past two years and significant investments in research, innovation and breadth of capability, we have a uniquely advantaged position heading into the next digital decade.”

[0001571996-20-000009:8k_2_02:18]
1

[0001571996-20-000009:8k_2_02:19]
Fourth Quarter and Full Year Fiscal 2020 Financial Results

[0001571996-20-000009:8k_2_02:20]
|  | Three Months Ended |  |  |  | Fiscal Year Ended |  |  |
|  | January 31, 2020 |  | February 1, 2019 |  | Change |  | January 31, 2020 |  | February 1, 2019 |  | Change |
|  | (in millions, except percentages; unaudited) |
| Total net revenue | $ | 24,032 |  |  | $ | 23,841 |  |  | 1% |  | $ | 92,154 |  |  | $ | 90,621 |  |  | 2% |
| Operating income (loss) | $ | 717 |  |  | $ | 331 |  |  | 117% |  | $ | 2,622 |  |  | $ | (191 | ) |  | NM |
| Net income (loss) | $ | 416 |  |  | $ | (287 | ) |  | 245% |  | $ | 5,529 |  |  | $ | (2,181 | ) |  | 354% |
| Non-GAAP net revenue | $ | 24,129 |  |  | $ | 24,008 |  |  | 1% |  | $ | 92,501 |  |  | $ | 91,324 |  |  | 1% |
| Non-GAAP operating income | $ | 2,767 |  |  | $ | 2,656 |  |  | 4% |  | $ | 10,148 |  |  | $ | 8,854 |  |  | 15% |
| Non-GAAP net income | $ | 1,684 |  |  | $ | 1,592 |  |  | 6% |  | $ | 6,089 |  |  | $ | 5,227 |  |  | 16% |
| Adjusted EBITDA | $ | 3,201 |  |  | $ | 3,028 |  |  | 6% |  | $ | 11,787 |  |  | $ | 10,296 |  |  | 14% |

[0001571996-20-000009:8k_2_02:21]
Information about Dell Technologies’ use of non-GAAP financial information is provided under “Non-GAAP Financial Measures” below.  All comparisons in this press release are year-over-year unless otherwise noted.

[0001571996-20-000009:8k_2_02:22]
Dell Technologies ended the quarter with a cash and investments balance of $10.2 billion.  The company repaid approximately $1.5 billion of gross debt in the quarter and $5 billion for the year, achieving its fiscal 2020 target.  The company has paid down $19.5 billion in gross debt since closing the EMC transaction in September 2016.

[0001571996-20-000009:8k_2_02:23]
“This year’s results were driven by operational focus and expanding synergies across Dell Technologies and our ability to adjust to win in any environment,” said Tom Sweet, chief financial officer, Dell Technologies.  “We delivered full year net income of $5.5 billion and adjusted EBITDA of $11.8 billion in fiscal 2020.  I’m pleased with our profitability and remain committed to maximizing Dell Technologies’ equity value for all aligned shareholders.”

[0001571996-20-000009:8k_2_02:24]
The company also announced today a new share repurchase program of up to $1 billion over the next 24 months, effective immediately.  While de-levering remains the primary capital allocation goal, the company sees an opportunity to take advantage of what it believes is a significant discount in the current stock price.  This share repurchase plan is another lever the company will use as it continues to focus on creating value for shareholders.

[0001571996-20-000009:8k_2_02:25]
Operating segments summary

[0001571996-20-000009:8k_2_02:26]
Client Solutions Group revenue for the fourth quarter was $11.8 billion, up 8 percent year over year.  This was driven by $8.6 billion in commercial revenue, a 10 percent increase, and $3.2 billion in consumer revenue, a 4 percent increase.  Operating income was $624 million or approximately 5 percent of Client Solutions Group revenue.  For the full year, the Client Solutions Group delivered record revenue of $45.8 billion, up 6 percent versus the prior year, with commercial up 11 percent.  Client Solutions Group full year operating income was $3.1 billion.

[0001571996-20-000009:8k_2_02:27]
2

[0001571996-20-000009:8k_2_02:28]
Key highlights:

[0001571996-20-000009:8k_2_02:29]
| • | Shipped a record 46.5 million units during the 2019 calendar year1 |

[0001571996-20-000009:8k_2_02:30]
| • | Gained PC unit share for the last seven years in a row1 |

[0001571996-20-000009:8k_2_02:31]
| • | Achieved double-digit unit and revenue growth in commercial desktops and workstations, completing a full fiscal year of quarterly double-digit growth in the segment |

[0001571996-20-000009:8k_2_02:32]
Infrastructure Solutions Group revenue for the fourth quarter was $8.8 billion, down 11 percent.  Storage revenue was $4.5 billion, down 3 percent, while servers and networking revenue was $4.3 billion, down 19 percent.  Operating income for the group was $1.1 billion or approximately 13 percent of revenue.  Revenue for full fiscal 2020 was $34.0 billion, with operating income of $4.0 billion.

[0001571996-20-000009:8k_2_02:33]
Key highlights:

[0001571996-20-000009:8k_2_02:34]
| • | Gained 590 basis points of mainstream server revenue share over the last 3 years, and have been the #1 worldwide provider for 7 quarters2 |

[0001571996-20-000009:8k_2_02:35]
| • | Strong customer traction with our co-engineered “first and best” solutions, including Dell Technologies Cloud, Unified Workspace, VxRail and smart fabric director |

[0001571996-20-000009:8k_2_02:36]
| • | Announced the latest advancements to Dell Technologies Cloud, including a new subscription-based model that makes it easier for customers to accelerate hybrid cloud deployments and simplify IT operations |

[0001571996-20-000009:8k_2_02:37]
VMware revenue for the fourth quarter was $3.1 billion, with operating income of $1.0 billion.  The segment delivered $10.9 billion in revenue and $3.1 billion in operating income for the full fiscal year.   During the fourth quarter, VMware, Inc. acquired Pivotal Software, Inc. (“Pivotal”), and VMware’s segment results are inclusive of Pivotal.  Prior periods have been recast to conform with current period presentation.

[0001571996-20-000009:8k_2_02:38]
Dell Technologies World

[0001571996-20-000009:8k_2_02:39]
Join us May 4 - May 7 in Las Vegas at Dell Technologies World, the company’s flagship event that brings together latest emerging trends, technology and gurus.  During the event, experts from all of Dell Technologies businesses will demonstrate to customers and partners the connected ecosystem of IT infrastructure, applications, devices and security that can enable real transformation across their organizations.  Register here.

[0001571996-20-000009:8k_2_02:40]
Conference call information

[0001571996-20-000009:8k_2_02:41]
As previously announced, the company will hold a conference call to discuss its fourth quarter and full year performance and financial guidance today, February 27, 2020, at 4:30 p.m. CST.  The conference call will be broadcast live over the internet and can be accessed at https://investors.delltechnologies.com/events-and-presentations/upcoming-events

[0001571996-20-000009:8k_2_02:42]
For those unable to listen to the live broadcast, an archived version will be available at the same location for one year.

[0001571996-20-000009:8k_2_02:43]
A slide presentation containing additional financial and operating information may be downloaded from Dell Technologies’ website at https://investors.delltechnologies.com/financial-information/quarterly-results.

[0001571996-20-000009:8k_2_02:44]
3

[0001571996-20-000009:8k_2_02:45]
About Dell Technologies

[0001571996-20-000009:8k_2_02:46]
Dell Technologies (NYSE:DELL) helps organizations and individuals build their digital future and transform how they work, live and play.  The company provides customers with the industry’s broadest and most innovative technology and services portfolio for the data era.

[0001571996-20-000009:8k_2_02:47]
CONTACTS:

[0001571996-20-000009:8k_2_02:48]
Investor Relations: Investor_Relations@Dell.com

[0001571996-20-000009:8k_2_02:49]
Media Relations: Media.Relations@Dell.com

[0001571996-20-000009:8k_2_02:50]
# # #

[0001571996-20-000009:8k_2_02:51]
Copyright © 2020 Dell Inc. or its subsidiaries.  All Rights Reserved. Dell Technologies, Dell, EMC and Dell EMC are trademarks of Dell Inc. or its subsidiaries.  Other trademarks may be trademarks of their respective owners.

[0001571996-20-000009:8k_2_02:52]
| 1 | IDC WW Quarterly Personal Computing Device (PDC) Tracker CY19Q4. |

[0001571996-20-000009:8k_2_02:53]
| 2 | IDC WW Quarterly Server Tracker CY19Q3; share gains calculated on a trailing-twelve-months basis. |

[0001571996-20-000009:8k_2_02:54]
Non-GAAP Financial Measures:

[0001571996-20-000009:8k_2_02:55]
This press release presents information about Dell Technologies’ non-GAAP net revenue, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, non-GAAP net income attributable to non-controlling interests, non-GAAP net income attributable to Dell Technologies Inc. - basic, non-GAAP net income attributable to Dell Technologies Inc. - diluted, non-GAAP earnings per share attributable to Dell Technologies Inc. - basic, non-GAAP earnings per share attributable to Dell Technologies Inc. - diluted, EBITDA, and adjusted EBITDA, which are non-GAAP financial measures provided as a supplement to the results provided in accordance with generally accepted accounting principles in the United States of America (“GAAP”). A reconciliation of each non-GAAP financial measure to the most directly comparable GAAP financial measure is provided in the attached tables for each of the fiscal periods indicated.

[0001571996-20-000009:8k_2_02:56]
Special Note on Forward-Looking Statements:

[0001571996-20-000009:8k_2_02:57]
Dell Technologies’ results or events in future periods could differ materially from those expressed or implied by these forward-looking statements because of risks, uncertainties, and other factors that include, but are not limited to, the following: competitive pressures; Dell Technologies’ reliance on third-party suppliers for products and components, including reliance on single-source or limited-source suppliers; Dell Technologies’ ability to achieve favorable pricing from its vendors; adverse global economic conditions and instability in financial markets; Dell Technologies’ execution of its growth, business and acquisition strategies; the success of Dell Technologies’ cost efficiency measures; Dell Technologies’ ability to manage solutions and products and services transitions in an effective manner; Dell Technologies’ ability to deliver high-quality products and services; Dell Technologies’ foreign operations and ability to generate substantial non-U.S. net revenue; Dell Technologies’ product, customer, and geographic sales mix, and seasonal sales trends; the performance of Dell Technologies’ sales channel partners; access to the capital markets by Dell Technologies or its customers; weak economic conditions and additional regulation including tariffs and other effects of trade regulation; counterparty default risks; the loss by Dell Technologies of any services contracts with its customers, including government contracts, and its ability to perform such contracts at its estimated costs; Dell Technologies’ ability to develop and protect its proprietary intellectual property or obtain licenses to intellectual property developed by others on commercially reasonable and competitive terms; infrastructure disruptions, cyberattacks, or other data security breaches; Dell Technologies’ ability to hedge effectively its exposure to fluctuations in foreign currency exchange rates and interest rates; expiration of tax holidays or favorable tax rate structures, or unfavorable outcomes in tax audits and other tax compliance matters; impairment of portfolio investments; unfavorable results of legal proceedings; increased costs and additional regulations and requirements as a result of Dell Technologies’ operation as a public company; Dell Technologies’ ability to develop and maintain effective internal control over financial reporting; compliance requirements of changing environmental and safety laws; the effect of armed hostilities, terrorism, natural disasters, and public health issues; Dell Technologies’ substantial level of indebtedness; the impact of the financial performance of VMware, Inc.; and the market volatility of Dell Technologies’ pension plan assets.

[0001571996-20-000009:8k_2_02:58]
This list of risks, uncertainties, and other factors is not complete. Dell Technologies discusses some of these matters more fully, as well as certain risk factors that could affect Dell Technologies’ business, financial condition, results of operations, and prospects, in its reports filed with the SEC, including Dell Technologies’ annual report on Form 10-K for the fiscal year ended February 1, 2019, quarterly reports on

[0001571996-20-000009:8k_2_02:59]
Form 10-Q, and current reports on Form 8-K. These filings are available for review through the SEC’s website at www.sec.gov. Any or all forward-looking statements Dell Technologies makes may turn out to be wrong and can be affected by inaccurate assumptions Dell Technologies might make or by known or unknown risks, uncertainties and other factors, including those identified in this press release. Accordingly, you should not place undue reliance on the forward-looking statements made in this press release, which speak only as of its date. Dell Technologies does not undertake to update, and expressly disclaims any duty to update, its forward-looking statements, whether as a result of circumstances or events that arise after the date they are made, new information, or otherwise.

[0001571996-20-000009:8k_2_02:60]
5

[0001571996-20-000009:8k_2_02:61]
DELL TECHNOLOGIES INC.

[0001571996-20-000009:8k_2_02:62]
Condensed Consolidated Statements of Income (Loss) and Related Financial Highlights

[0001571996-20-000009:8k_2_02:63]
(in millions, except percentages; unaudited)

[0001571996-20-000009:8k_2_02:64]
|  | Three Months Ended |  |  |  | Fiscal Year Ended |  |  |
|  | January 31, 2020 |  | February 1, 2019 |  | Change |  | January 31, 2020 |  | February 1, 2019 |  | Change |
| Net revenue (a): |  |  |  |  |  |  |  |  |  |  |  |
| Products | $ | 18,153 |  |  | $ | 18,676 |  |  | (3)% |  | $ | 69,918 |  |  | $ | 70,751 |  |  | (1)% |
| Services | 5,879 |  |  | 5,165 |  |  | 14% |  | 22,236 |  |  | 19,870 |  |  | 12% |
| Total net revenue | 24,032 |  |  | 23,841 |  |  | 1% |  | 92,154 |  |  | 90,621 |  |  | 2% |
| Cost of net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Products | 13,999 |  |  | 14,775 |  |  | (5)% |  | 54,525 |  |  | 57,889 |  |  | (6)% |
| Services | 2,349 |  |  | 1,957 |  |  | 20% |  | 8,696 |  |  | 7,679 |  |  | 13% |
| Total cost of net revenue | 16,348 |  |  | 16,732 |  |  | (2)% |  | 63,221 |  |  | 65,568 |  |  | (4)% |
| Gross margin | 7,684 |  |  | 7,109 |  |  | 8% |  | 28,933 |  |  | 25,053 |  |  | 15% |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative | 5,642 |  |  | 5,576 |  |  | 1% |  | 21,319 |  |  | 20,640 |  |  | 3% |
| Research and development | 1,325 |  |  | 1,202 |  |  | 10% |  | 4,992 |  |  | 4,604 |  |  | 8% |
| Total operating expenses | 6,967 |  |  | 6,778 |  |  | 3% |  | 26,311 |  |  | 25,244 |  |  | 4% |
| Operating income (loss) | 717 |  |  | 331 |  |  | 117% |  | 2,622 |  |  | (191 | ) |  | NM |
| Interest and other, net | (626 | ) |  | (606 | ) |  | (3)% |  | (2,626 | ) |  | (2,170 | ) |  | (21)% |
| Income (loss) before income taxes | 91 |  |  | (275 | ) |  | 133% |  | (4 | ) |  | (2,361 | ) |  | 100% |
| Income tax provision (benefit) | (325 | ) |  | 12 |  |  | NM |  | (5,533 | ) |  | (180 | ) |  | NM |
| Net income (loss) | 416 |  |  | (287 | ) |  | 245% |  | 5,529 |  |  | (2,181 | ) |  | 354% |
| Less: Net income attributable to non-controlling interests | 8 |  |  | 12 |  |  | (33)% |  | 913 |  |  | 129 |  |  | 608% |
| Net income (loss) attributable to Dell Technologies Inc. | $ | 408 |  |  | $ | (299 | ) |  | 236% |  | $ | 4,616 |  |  | $ | (2,310 | ) |  | 300% |
| Percentage of Total Net Revenue: |  |  |  |  |  |  |  |  |  |  |
| Gross margin | 32 | % |  | 30 | % |  |  |  | 31 | % |  | 28 | % |  |  |
| Selling, general, and administrative | 23 | % |  | 23 | % |  |  |  | 23 | % |  | 23 | % |  |  |
| Research and development | 6 | % |  | 5 | % |  |  |  | 5 | % |  | 5 | % |  |  |
| Operating expenses | 29 | % |  | 28 | % |  |  |  | 29 | % |  | 28 | % |  |  |
| Operating income (loss) | 3 | % |  | 1 | % |  |  |  | 3 | % |  | — | % |  |  |
| Income (loss) before income taxes | — | % |  | (1 | )% |  |  |  | — | % |  | (3 | )% |  |  |
| Net income (loss) | 2 | % |  | (1 | )% |  |  |  | 6 | % |  | (2 | )% |  |  |
| Income tax rate | (357.1 | )% |  | (4.4 | )% |  |  |  | 138325.0 | % |  | 7.6 | % |  |  |

[0001571996-20-000009:8k_2_02:65]
____________________

[0001571996-20-000009:8k_2_02:66]
| (a) | During the fourth quarter of Fiscal 2020, the Company reclassified revenue associated with certain service and software-as-a-service offerings from product revenue to services revenue. There was no change to total revenue as a result of the reclassifications. Prior period results have been recast to conform with current period presentation. |

[0001571996-20-000009:8k_2_02:67]
6

[0001571996-20-000009:8k_2_02:68]
DELL TECHNOLOGIES INC.

[0001571996-20-000009:8k_2_02:69]
Consolidated Statements of Financial Position

[0001571996-20-000009:8k_2_02:70]
(in millions; unaudited)

[0001571996-20-000009:8k_2_02:71]
|  | January 31, 2020 |  | February 1, 2019 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 9,302 |  |  | $ | 9,676 |  |
| Accounts receivable, net | 12,484 |  |  | 12,371 |  |
| Short-term financing receivables, net | 4,895 |  |  | 4,398 |  |
| Inventories, net | 3,281 |  |  | 3,649 |  |
| Other current assets | 6,934 |  |  | 6,044 |  |
| Total current assets | 36,896 |  |  | 36,138 |  |
| Property, plant, and equipment, net | 6,027 |  |  | 5,259 |  |
| Long-term investments | 864 |  |  | 1,005 |  |
| Long-term financing receivables, net | 4,848 |  |  | 4,224 |  |
| Goodwill | 41,691 |  |  | 40,089 |  |
| Intangible assets, net | 18,107 |  |  | 22,270 |  |
| Other non-current assets | 10,428 |  |  | 2,835 |  |
| Total assets | $ | 118,861 |  |  | $ | 111,820 |  |
| LIABILITIES, REDEEMABLE SHARES, AND STOCKHOLDERS’ EQUITY (DEFICIT) |
| Current liabilities: |  |  |  |
| Short-term debt | $ | 7,737 |  |  | $ | 4,320 |  |
| Accounts payable | 20,065 |  |  | 19,213 |  |
| Accrued and other | 9,359 |  |  | 8,495 |  |
| Short-term deferred revenue | 14,881 |  |  | 12,944 |  |
| Total current liabilities | 52,042 |  |  | 44,972 |  |
| Long-term debt | 44,319 |  |  | 49,201 |  |
| Long-term deferred revenue | 12,919 |  |  | 11,066 |  |
| Other non-current liabilities | 5,797 |  |  | 6,327 |  |
| Total liabilities | 115,077 |  |  | 111,566 |  |
| Redeemable shares | 629 |  |  | 1,196 |  |
| Stockholders’ equity (deficit): |  |  |  |
| Total Dell Technologies Inc. stockholders’ deficit | (1,574 | ) |  | (5,765 | ) |
| Non-controlling interests | 4,729 |  |  | 4,823 |  |
| Total stockholders’ equity (deficit) | 3,155 |  |  | (942 | ) |
| Total liabilities, redeemable shares, and stockholders’ equity (deficit) | $ | 118,861 |  |  | $ | 111,820 |  |

[0001571996-20-000009:8k_2_02:72]
7

[0001571996-20-000009:8k_2_02:73]
DELL TECHNOLOGIES INC.

[0001571996-20-000009:8k_2_02:74]
Condensed Consolidated Statements of Cash Flows

[0001571996-20-000009:8k_2_02:75]
(in millions; unaudited)

[0001571996-20-000009:8k_2_02:76]
|  | Three Months Ended |  | Fiscal Year Ended |
|  | January 31, 2020 |  | February 1, 2019 |  | January 31, 2020 |  | February 1, 2019 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |
| Net income (loss) | $ | 416 |  |  | $ | (287 | ) |  | $ | 5,529 |  |  | $ | (2,181 | ) |
| Adjustments to reconcile net income (loss) to net cash provided by operating activities | 3,092 |  |  | 2,653 |  |  | 3,762 |  |  | 9,172 |  |
| Change in cash from operating activities | 3,508 |  |  | 2,366 |  |  | 9,291 |  |  | 6,991 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |
| Investments: |  |  |  |  |  |  |  |
| Purchases | (39 | ) |  | (13 | ) |  | (181 | ) |  | (925 | ) |
| Maturities and sales | 48 |  |  | 4,427 |  |  | 497 |  |  | 6,612 |  |
| Capital expenditures | (629 | ) |  | (297 | ) |  | (2,241 | ) |  | (1,158 | ) |
| Capitalized software development costs | (71 | ) |  | (93 | ) |  | (335 | ) |  | (339 | ) |
| Acquisition of businesses, net | (26 | ) |  | (419 | ) |  | (2,455 | ) |  | (912 | ) |
| Divestitures of businesses, net | — |  |  | — |  |  | — |  |  | 142 |  |
| Asset acquisitions, net | — |  |  | — |  |  | (8 | ) |  | (59 | ) |
| Asset dispositions, net | — |  |  | — |  |  | (3 | ) |  | (12 | ) |
| Other | 13 |  |  | 5 |  |  | 40 |  |  | 40 |  |
| Change in cash from investing activities | (704 | ) |  | 3,610 |  |  | (4,686 | ) |  | 3,389 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |
| Share repurchases for tax withholdings of equity awards | (140 | ) |  | (136 | ) |  | (547 | ) |  | (387 | ) |
| Dividends paid to VMware, Inc.’s public stockholders | — |  |  | (2,134 | ) |  | — |  |  | (2,134 | ) |
| Proceeds from the issuance of common stock | 207 |  |  | 37 |  |  | 658 |  |  | 805 |  |
| Repurchases of Class V Common Stock | — |  |  | (14,000 | ) |  | — |  |  | (14,000 | ) |
| Repurchases of common stock of subsidiaries | (1,721 | ) |  | (55 | ) |  | (3,006 | ) |  | (56 | ) |
| Proceeds from debt | 2,982 |  |  | 6,602 |  |  | 20,638 |  |  | 13,045 |  |
| Repayments of debt | (3,326 | ) |  | (1,782 | ) |  | (22,274 | ) |  | (11,451 | ) |
| Other | (6 | ) |  | (17 | ) |  | (73 | ) |  | (151 | ) |
| Change in cash from financing activities | (2,004 | ) |  | (11,485 | ) |  | (4,604 | ) |  | (14,329 | ) |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash | 10 |  |  | 73 |  |  | (90 | ) |  | (189 | ) |
| Change in cash, cash equivalents, and restricted cash | 810 |  |  | (5,436 | ) |  | (89 | ) |  | (4,138 | ) |
| Cash, cash equivalents, and restricted cash at beginning of the period | 9,341 |  |  | 15,676 |  |  | 10,240 |  |  | 14,378 |  |
| Cash, cash equivalents, and restricted cash at end of the period | $ | 10,151 |  |  | $ | 10,240 |  |  | $ | 10,151 |  |  | $ | 10,240 |  |

[0001571996-20-000009:8k_2_02:77]
8

[0001571996-20-000009:8k_2_02:78]
DELL TECHNOLOGIES INC.

[0001571996-20-000009:8k_2_02:79]
Segment Information

[0001571996-20-000009:8k_2_02:80]
(in millions, except percentages; unaudited; continued on next page)

[0001571996-20-000009:8k_2_02:81]
|  | Three Months Ended |  |  |  | Fiscal Year Ended |  |  |
|  | January 31, 2020 |  | February 1, 2019 |  | Change |  | January 31, 2020 |  | February 1, 2019 |  | Change |
| Infrastructure Solutions Group (ISG): |
| Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Servers and networking | $ | 4,269 |  |  | $ | 5,253 |  |  | (19)% |  | $ | 17,127 |  |  | $ | 19,953 |  |  | (14)% |
| Storage | 4,487 |  |  | 4,636 |  |  | (3)% |  | 16,842 |  |  | 16,767 |  |  | —% |
| Total ISG net revenue | $ | 8,756 |  |  | $ | 9,889 |  |  | (11)% |  | $ | 33,969 |  |  | $ | 36,720 |  |  | (7)% |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| ISG operating income | $ | 1,112 |  |  | $ | 1,265 |  |  | (12)% |  | $ | 4,001 |  |  | $ | 4,151 |  |  | (4)% |
| % of ISG net revenue | 13 | % |  | 13 | % |  |  |  | 12 | % |  | 11 | % |  |  |
| % of total reportable segment operating income | 40 | % |  | 47 | % |  |  |  | 39 | % |  | 46 | % |  |  |
| Client Solutions Group (CSG): |
| Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 8,563 |  |  | $ | 7,808 |  |  | 10% |  | $ | 34,277 |  |  | $ | 30,893 |  |  | 11% |
| Consumer | 3,207 |  |  | 3,084 |  |  | 4% |  | 11,561 |  |  | 12,303 |  |  | (6)% |
| Total CSG net revenue | $ | 11,770 |  |  | $ | 10,892 |  |  | 8% |  | $ | 45,838 |  |  | $ | 43,196 |  |  | 6% |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| CSG operating income | $ | 624 |  |  | $ | 555 |  |  | 12% |  | $ | 3,138 |  |  | $ | 1,960 |  |  | 60% |
| % of CSG net revenue | 5 | % |  | 5 | % |  |  |  | 7 | % |  | 5 | % |  |  |
| % of total reportable segment operating income | 23 | % |  | 21 | % |  |  |  | 31 | % |  | 22 | % |  |  |
| VMware (a): |
| Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Total VMware net revenue | $ | 3,126 |  |  | $ | 2,798 |  |  | 12% |  | $ | 10,905 |  |  | $ | 9,741 |  |  | 12% |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| VMware operating income | $ | 1,026 |  |  | $ | 850 |  |  | 21% |  | $ | 3,081 |  |  | $ | 2,926 |  |  | 5% |
| % of VMware net revenue | 33 | % |  | 30 | % |  |  |  | 28 | % |  | 30 | % |  |  |
| % of total reportable segment operating income | 37 | % |  | 32 | % |  |  |  | 30 | % |  | 32 | % |  |  |

[0001571996-20-000009:8k_2_02:82]
____________________

[0001571996-20-000009:8k_2_02:83]
| (a) | During the fourth quarter of Fiscal 2020, the Company reclassified Pivotal operating results from Other businesses to the VMware reportable segment. There was no change to consolidated results as a result of the reclassification. Prior period results have been recast to conform with current period presentation. |

[0001571996-20-000009:8k_2_02:84]
DELL TECHNOLOGIES INC.

[0001571996-20-000009:8k_2_02:85]
Segment Information

[0001571996-20-000009:8k_2_02:86]
(in millions, except percentages; unaudited; continued)

[0001571996-20-000009:8k_2_02:87]
|  | Three Months Ended |  | Fiscal Year Ended |
|  | January 31, 2020 |  | February 1, 2019 |  | January 31, 2020 |  | February 1, 2019 |
| Reconciliation to consolidated net revenue: |  |  |  |  |  |  |
| Reportable segment net revenue (a) | $ | 23,652 |  |  | $ | 23,579 |  |  | $ | 90,712 |  |  | $ | 89,657 |  |
| Other businesses (a) (b) | 477 |  |  | 432 |  |  | 1,788 |  |  | 1,676 |  |
| Unallocated transactions (c) | — |  |  | (3 | ) |  | 1 |  |  | (9 | ) |
| Impact of purchase accounting (d) | (97 | ) |  | (167 | ) |  | (347 | ) |  | (703 | ) |
| Total consolidated net revenue | $ | 24,032 |  |  | $ | 23,841 |  |  | $ | 92,154 |  |  | $ | 90,621 |  |
| Reconciliation to consolidated operating income (loss): |  |  |  |  |
| Reportable segment operating income (a) | $ | 2,762 |  |  | $ | 2,670 |  |  | $ | 10,220 |  |  | $ | 9,037 |  |
| Other businesses (a) (b) | 5 |  |  | (13 | ) |  | (43 | ) |  | (111 | ) |
| Unallocated transactions (c) | — |  |  | (1 | ) |  | (29 | ) |  | (72 | ) |
| Impact of purchase accounting (d) | (112 | ) |  | (190 | ) |  | (411 | ) |  | (820 | ) |
| Amortization of intangibles | (1,074 | ) |  | (1,544 | ) |  | (4,408 | ) |  | (6,138 | ) |
| Transaction-related expenses (e) | (120 | ) |  | (313 | ) |  | (285 | ) |  | (750 | ) |
| Stock-based compensation expense (f) | (376 | ) |  | (247 | ) |  | (1,262 | ) |  | (918 | ) |
| Other corporate expenses (g) | (368 | ) |  | (31 | ) |  | (1,160 | ) |  | (419 | ) |
| Total consolidated operating income (loss) | $ | 717 |  |  | $ | 331 |  |  | $ | 2,622 |  |  | $ | (191 | ) |

[0001571996-20-000009:8k_2_02:88]
_________________

[0001571996-20-000009:8k_2_02:89]
| (a) | During the fourth quarter of Fiscal 2020, the Company reclassified Pivotal operating results from Other businesses to the VMware reportable segment. Prior period results have been recast to conform with current period presentation. |

[0001571996-20-000009:8k_2_02:90]
| (b) | Secureworks, RSA Security, Virtustream, and Boomi constitute “Other businesses” and do not meet the requirements for a reportable segment, either individually or collectively. The results of Other businesses are not material to the Company’s overall results. |

[0001571996-20-000009:8k_2_02:91]
| (c) | Unallocated transactions includes other corporate items that are not allocated to Dell Technologies’ reportable segments. |

[0001571996-20-000009:8k_2_02:92]
| (d) | Impact of purchase accounting includes non-cash purchase accounting adjustments that are primarily related to the EMC merger transaction. |

[0001571996-20-000009:8k_2_02:93]
| (e) | Transaction-related expenses includes acquisition, integration, and divestiture related costs, as well as the costs incurred in the Class V transaction. |

[0001571996-20-000009:8k_2_02:94]
| (f) | Stock-based compensation expense consists of equity awards granted based on the estimated fair value of those awards at grant date. |

[0001571996-20-000009:8k_2_02:95]
| (g) | Other corporate expenses includes impairment charges and severance, facility action, and other costs. |

[0001571996-20-000009:8k_2_02:96]
10

[0001571996-20-000009:8k_2_02:97]
SUPPLEMENTAL SELECTED NON-GAAP FINANCIAL MEASURES

[0001571996-20-000009:8k_2_02:98]
These tables present information about the Company’s non-GAAP net revenue, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, non-GAAP net income attributable to non-controlling interests, non-GAAP net income attributable to Dell Technologies Inc. - basic, non-GAAP net income attributable to Dell Technologies Inc. - diluted, non-GAAP earnings per share attributable to Dell Technologies Inc. - basic, non-GAAP earnings per share attributable to Dell Technologies Inc. - diluted, EBITDA, and adjusted EBITDA, which are non-GAAP financial measures provided as a supplement to the results provided in accordance with generally accepted accounting principles in the United States of America (“GAAP”). A detailed discussion of Dell Technologies’ reasons for including these non-GAAP financial measures, the limitations associated with these measures, the items excluded from these measures, and our reason for excluding those items are presented in “Management’s Discussion and Analysis of Financial Condition and Results of Operations - Non-GAAP Financial Measures” in our periodic reports filed with the SEC. Dell Technologies encourages investors to review the non-GAAP discussion in these reports in conjunction with the presentation of non-GAAP financial measures.

[0001571996-20-000009:8k_2_02:99]
11

[0001571996-20-000009:8k_2_02:100]
DELL TECHNOLOGIES INC.

[0001571996-20-000009:8k_2_02:101]
Selected Non-GAAP Financial Measures

[0001571996-20-000009:8k_2_02:102]
(in millions, except percentages; unaudited)

[0001571996-20-000009:8k_2_02:103]
|  | Three Months Ended |  |  |  | Fiscal Year Ended |  |  |
|  | January 31, 2020 |  | February 1, 2019 |  | Change |  | January 31, 2020 |  | February 1, 2019 |  | Change |
| Non-GAAP net revenue | $ | 24,129 |  |  | $ | 24,008 |  |  | 1% |  | $ | 92,501 |  |  | $ | 91,324 |  |  | 1% |
| Non-GAAP gross margin | $ | 8,375 |  |  | $ | 8,037 |  |  | 4% |  | $ | 31,563 |  |  | $ | 29,022 |  |  | 9% |
| % of non-GAAP net revenue | 35 | % |  | 33 | % |  |  |  | 34 | % |  | 32 | % |  |  |
| Non-GAAP operating expenses | $ | 5,608 |  |  | $ | 5,381 |  |  | 4% |  | $ | 21,415 |  |  | $ | 20,168 |  |  | 6% |
| % of non-GAAP net revenue | 23 | % |  | 22 | % |  |  |  | 23 | % |  | 22 | % |  |  |
| Non-GAAP operating income | $ | 2,767 |  |  | $ | 2,656 |  |  | 4% |  | $ | 10,148 |  |  | $ | 8,854 |  |  | 15% |
| % of non-GAAP net revenue | 11 | % |  | 11 | % |  |  |  | 11 | % |  | 10 | % |  |  |
| Non-GAAP net income | $ | 1,684 |  |  | $ | 1,592 |  |  | 6% |  | $ | 6,089 |  |  | $ | 5,227 |  |  | 16% |
| % of non-GAAP net revenue | 7 | % |  | 7 | % |  |  |  | 7 | % |  | 6 | % |  |  |
| Adjusted EBITDA | $ | 3,201 |  |  | $ | 3,028 |  |  | 6% |  | $ | 11,787 |  |  | $ | 10,296 |  |  | 14% |
| % of non-GAAP net revenue | 13 | % |  | 13 | % |  |  |  | 13 | % |  | 11 | % |  |  |

[0001571996-20-000009:8k_2_02:104]
12

[0001571996-20-000009:8k_2_02:105]
DELL TECHNOLOGIES INC.

[0001571996-20-000009:8k_2_02:106]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-20-000009:8k_2_02:107]
(in millions, except percentages; unaudited; continued on next page)

[0001571996-20-000009:8k_2_02:108]
|  | Three Months Ended |  |  |  | Fiscal Year Ended |  |  |
|  | January 31, 2020 |  | February 1, 2019 |  | Change |  | January 31, 2020 |  | February 1, 2019 |  | Change |
| Net revenue | $ | 24,032 |  |  | $ | 23,841 |  |  | 1% |  | $ | 92,154 |  |  | $ | 90,621 |  |  | 2% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 97 |  |  | 167 |  |  |  |  | 347 |  |  | 703 |  |  |  |
| Non-GAAP net revenue | $ | 24,129 |  |  | $ | 24,008 |  |  | 1% |  | $ | 92,501 |  |  | $ | 91,324 |  |  | 1% |
| Gross margin | $ | 7,684 |  |  | $ | 7,109 |  |  | 8% |  | $ | 28,933 |  |  | $ | 25,053 |  |  | 15% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 526 |  |  | 729 |  |  |  |  | 2,081 |  |  | 2,883 |  |  |  |
| Impact of purchase accounting | 98 |  |  | 171 |  |  |  |  | 353 |  |  | 720 |  |  |  |
| Transaction-related expenses | — |  |  | (26 | ) |  |  |  | (5 | ) |  | 213 |  |  |  |
| Stock-based compensation expense | 38 |  |  | 37 |  |  |  |  | 129 |  |  | 91 |  |  |  |
| Other corporate expenses | 29 |  |  | 17 |  |  |  |  | 72 |  |  | 62 |  |  |  |
| Non-GAAP gross margin | $ | 8,375 |  |  | $ | 8,037 |  |  | 4% |  | $ | 31,563 |  |  | $ | 29,022 |  |  | 9% |
| Operating expenses | $ | 6,967 |  |  | $ | 6,778 |  |  | 3% |  | $ | 26,311 |  |  | $ | 25,244 |  |  | 4% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | (548 | ) |  | (815 | ) |  |  |  | (2,327 | ) |  | (3,255 | ) |  |  |
| Impact of purchase accounting | (14 | ) |  | (19 | ) |  |  |  | (58 | ) |  | (100 | ) |  |  |
| Transaction-related expenses | (120 | ) |  | (339 | ) |  |  |  | (290 | ) |  | (537 | ) |  |  |
| Stock-based compensation expense | (338 | ) |  | (210 | ) |  |  |  | (1,133 | ) |  | (827 | ) |  |  |
| Other corporate expenses | (339 | ) |  | (14 | ) |  |  |  | (1,088 | ) |  | (357 | ) |  |  |
| Non-GAAP operating expenses | $ | 5,608 |  |  | $ | 5,381 |  |  | 4% |  | $ | 21,415 |  |  | $ | 20,168 |  |  | 6% |
| Operating income (loss) | $ | 717 |  |  | $ | 331 |  |  | 117% |  | $ | 2,622 |  |  | $ | (191 | ) |  | NM |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 1,074 |  |  | 1,544 |  |  |  |  | 4,408 |  |  | 6,138 |  |  |  |
| Impact of purchase accounting | 112 |  |  | 190 |  |  |  |  | 411 |  |  | 820 |  |  |  |
| Transaction-related expenses | 120 |  |  | 313 |  |  |  |  | 285 |  |  | 750 |  |  |  |
| Stock-based compensation expense | 376 |  |  | 247 |  |  |  |  | 1,262 |  |  | 918 |  |  |  |
| Other corporate expenses | 368 |  |  | 31 |  |  |  |  | 1,160 |  |  | 419 |  |  |  |
| Non-GAAP operating income | $ | 2,767 |  |  | $ | 2,656 |  |  | 4% |  | $ | 10,148 |  |  | $ | 8,854 |  |  | 15% |

[0001571996-20-000009:8k_2_02:109]
13

[0001571996-20-000009:8k_2_02:110]
DELL TECHNOLOGIES INC.

[0001571996-20-000009:8k_2_02:111]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-20-000009:8k_2_02:112]
(in millions, except percentages; unaudited; continued)

[0001571996-20-000009:8k_2_02:113]
|  | Three Months Ended |  |  |  | Fiscal Year Ended |  |  |
|  | January 31, 2020 |  | February 1, 2019 |  | Change |  | January 31, 2020 |  | February 1, 2019 |  | Change |
| Net income (loss) | $ | 416 |  |  | $ | (287 | ) |  | 245% |  | $ | 5,529 |  |  | $ | (2,181 | ) |  | 354% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 1,074 |  |  | 1,544 |  |  |  |  | 4,408 |  |  | 6,138 |  |  |  |
| Impact of purchase accounting | 112 |  |  | 190 |  |  |  |  | 411 |  |  | 820 |  |  |  |
| Transaction-related expenses | 120 |  |  | 387 |  |  |  |  | 285 |  |  | 824 |  |  |  |
| Stock-based compensation expense | 376 |  |  | 247 |  |  |  |  | 1,262 |  |  | 918 |  |  |  |
| Other corporate expenses | 368 |  |  | 31 |  |  |  |  | 1,160 |  |  | 419 |  |  |  |
| Fair value adjustments on equity investments | (34 | ) |  | (113 | ) |  |  |  | (194 | ) |  | (342 | ) |  |  |
| Aggregate adjustment for income taxes | (748 | ) |  | (407 | ) |  |  |  | (6,772 | ) |  | (1,369 | ) |  |  |
| Non-GAAP net income (a) | $ | 1,684 |  |  | $ | 1,592 |  |  | 6% |  | $ | 6,089 |  |  | $ | 5,227 |  |  | 16% |
| Net income (loss) | $ | 416 |  |  | $ | (287 | ) |  | 245% |  | $ | 5,529 |  |  | $ | (2,181 | ) |  | 354% |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Interest and other, net | 626 |  |  | 606 |  |  |  |  | 2,626 |  |  | 2,170 |  |  |  |
| Income tax provision (benefit) | (325 | ) |  | 12 |  |  |  |  | (5,533 | ) |  | (180 | ) |  |  |
| Depreciation and amortization | 1,535 |  |  | 1,940 |  |  |  |  | 6,143 |  |  | 7,746 |  |  |  |
| EBITDA | $ | 2,252 |  |  | $ | 2,271 |  |  | (1)% |  | $ | 8,765 |  |  | $ | 7,555 |  |  | 16% |
| EBITDA | $ | 2,252 |  |  | $ | 2,271 |  |  | (1)% |  | $ | 8,765 |  |  | $ | 7,555 |  |  | 16% |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense | 376 |  |  | 247 |  |  |  |  | 1,262 |  |  | 918 |  |  |  |
| Impact of purchase accounting | 96 |  |  | 168 |  |  |  |  | 347 |  |  | 704 |  |  |  |
| Transaction-related expenses | 120 |  |  | 313 |  |  |  |  | 285 |  |  | 722 |  |  |  |
| Other corporate expenses | 357 |  |  | 29 |  |  |  |  | 1,128 |  |  | 397 |  |  |  |
| Adjusted EBITDA | $ | 3,201 |  |  | $ | 3,028 |  |  | 6% |  | $ | 11,787 |  |  | $ | 10,296 |  |  | 14% |

[0001571996-20-000009:8k_2_02:114]
14

[0001571996-20-000009:8k_2_02:115]
DELL TECHNOLOGIES INC.

[0001571996-20-000009:8k_2_02:116]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-20-000009:8k_2_02:117]
For the Three Months Ended January 31, 2020

[0001571996-20-000009:8k_2_02:118]
(in millions, except per share amounts; unaudited)

[0001571996-20-000009:8k_2_02:119]
|  | GAAP |  | Amortization of intangibles |  | Impact of purchase accounting |  | Transaction-related expenses |  | Stock-based compensation expense |  | Other corporate expenses |  | Fair value adjustments on equity investments |  | Aggregate adjustment for income taxes |  | Non-GAAP |
| Net income | $ | 416 |  |  | 1,074 |  |  | 112 |  |  | 120 |  |  | 376 |  |  | 368 |  |  | (34 | ) |  | (748 | ) |  | $ | 1,684 |  |
| Less: Net income attributable to non-controlling interests (a) | 8 |  |  | 76 |  |  | 6 |  |  | 32 |  |  | 65 |  |  | 45 |  |  | — |  |  | (61 | ) |  | 171 |  |
| Net income attributable to Dell Technologies Inc. - basic | 408 |  |  | 998 |  |  | 106 |  |  | 88 |  |  | 311 |  |  | 323 |  |  | (34 | ) |  | (687 | ) |  | 1,513 |  |
| Incremental dilution from VMware, Inc. attributable to Dell Technologies Inc. (b) | (3 | ) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (8 | ) |
| Net income attributable to Dell Technologies Inc. - diluted | $ | 405 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 1,505 |  |
| Earnings per share - basic | $ | 0.56 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 2.06 |  |
| Earnings per share - diluted | $ | 0.54 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 2.00 |  |
| Weighted-average shares outstanding - basic | 734 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 734 |  |
| Weighted-average shares outstanding - diluted | 754 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 754 |  |

[0001571996-20-000009:8k_2_02:120]
_________________

[0001571996-20-000009:8k_2_02:121]
| (a) | Net income attributable to non-controlling interests is calculated by multiplying the minority interest percentage of VMware, Inc., Pivotal Software, Inc., and SecureWorks Corp. by their non-GAAP net income adjustments for the period presented. |

[0001571996-20-000009:8k_2_02:122]
| (b) | Incremental dilution from VMware, Inc. attributable to Dell Technologies Inc. represents the impact of VMware, Inc.’s dilutive securities on the diluted earnings per share of Dell Technologies Inc. and is calculated by multiplying the difference between VMware, Inc.’s basic and diluted earnings per share by the number of shares of VMware, Inc. common stock held by Dell Technologies Inc. |

[0001571996-20-000009:8k_2_02:123]
DELL TECHNOLOGIES INC.

[0001571996-20-000009:8k_2_02:124]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-20-000009:8k_2_02:125]
For the Fiscal Year Ended January 31, 2020

[0001571996-20-000009:8k_2_02:126]
(in millions, except per share amounts; unaudited)

[0001571996-20-000009:8k_2_02:127]
|  | GAAP |  | Amortization of intangibles |  | Impact of purchase accounting |  | Transaction-related expenses |  | Stock-based compensation expense |  | Other corporate expenses |  | Fair value adjustments on equity investments |  | Aggregate adjustment for income taxes |  | Non-GAAP |
| Net income | $ | 5,529 |  |  | 4,408 |  |  | 411 |  |  | 285 |  |  | 1,262 |  |  | 1,160 |  |  | (194 | ) |  | (6,772 | ) |  | $ | 6,089 |  |
| Less: Net income attributable to non-controlling interests (a) | 913 |  |  | 295 |  |  | 23 |  |  | 50 |  |  | 217 |  |  | 45 |  |  | 24 |  |  | (1,032 | ) |  | 535 |  |
| Net income attributable to Dell Technologies Inc. - basic | 4,616 |  |  | 4,113 |  |  | 388 |  |  | 235 |  |  | 1,045 |  |  | 1,115 |  |  | (218 | ) |  | (5,740 | ) |  | 5,554 |  |
| Incremental dilution from VMware, Inc. attributable to Dell Technologies Inc. (b) | (84 | ) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (35 | ) |
| Net income attributable to Dell Technologies Inc. - diluted | $ | 4,532 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 5,519 |  |
| Earnings per share - basic | $ | 6.38 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 7.67 |  |
| Earnings per share - diluted | $ | 6.03 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 7.35 |  |
| Weighted-average shares outstanding - basic | 724 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 724 |  |
| Weighted-average shares outstanding - diluted | 751 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 751 |  |

[0001571996-20-000009:8k_2_02:128]
_________________

[0001571996-20-000009:8k_2_02:129]
| (a) | Net income attributable to non-controlling interests is calculated by multiplying the minority interest percentage of VMware, Inc., Pivotal Software, Inc., and SecureWorks Corp. by their non-GAAP net income adjustments for the period presented. |

[0001571996-20-000009:8k_2_02:130]
| (b) | Incremental dilution from VMware, Inc. attributable to Dell Technologies Inc. represents the impact of VMware, Inc.’s dilutive securities on the diluted earnings per share of Dell Technologies Inc. and is calculated by multiplying the difference between VMware, Inc.’s basic and diluted earnings per share by the number of shares of VMware, Inc. common stock held by Dell Technologies Inc. |

[0001571996-20-000009:8k_2_02:131]
16
