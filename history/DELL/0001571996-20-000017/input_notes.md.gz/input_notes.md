# DELL notes — 0001571996-20-000017


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001571996-20-000017:notes:1]
DOCUMENTS INCORPORATED BY REFERENCE

[0001571996-20-000017:notes:2]
The information required by Part III of this report, to the extent not set forth herein, is incorporated by reference from the registrant’s proxy statement relating to its annual meeting of stockholders to be held in 2020.  The proxy statement will be filed with the Securities and Exchange Commission within 120 days after the end of the fiscal year to which this report relates.


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001571996-20-000017:notes:3]
Basis of Presentation — These Consolidated Financial Statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“GAAP”)


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001571996-20-000017:notes:4]
NOTE 2 — DESCRIPTION OF BUSINESS AND SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES

[0001571996-20-000017:notes:5]
Description of Business — The Company is a leading global end-to-end technology provider that offers a broad range of comprehensive and integrated solutions, which include servers and networking products, storage products, cloud solutions products, desktops, notebooks, services, software, and third-party software and peripherals.

[0001571996-20-000017:notes:6]
The Company’s fiscal year is the 52- or 53-week period ending on the Friday nearest January 31.  The fiscal years ended January 31, 2020, February 1, 2019, and February 2, 2018 were 52-week periods.

[0001571996-20-000017:notes:7]
Principles of Consolidation — These Consolidated Financial Statements include the accounts of Dell Technologies and its wholly-owned subsidiaries, as well as the accounts of VMware, Inc., Pivotal, and SecureWorks Corp. (“Secureworks”), each of which is majority-owned by Dell Technologies, except for Pivotal, which is a wholly-owned subsidiary of VMware, Inc. as of December 30, 2019 upon completion of the acquisition of Pivotal’s non-controlling interest.  All intercompany transactions have been eliminated.

[0001571996-20-000017:notes:8]
Use of Estimates — The preparation of financial statements in accordance with GAAP requires management to make estimates and assumptions that affect the amounts reported in the Consolidated Financial Statements and the accompanying Notes.  Actual results could differ materially from those estimates.

[0001571996-20-000017:notes:9]
Cash and Cash Equivalents — All highly liquid investments, including credit card receivables due from banks, with original maturities of 90 days or less at date of purchase, are reported at fair value and are considered to be cash equivalents.  All other investments not considered to be cash equivalents are separately categorized as investments.

[0001571996-20-000017:notes:10]
Investments — All equity and other securities are recorded as long-term investments in the Consolidated Statements of Financial Position.

[0001571996-20-000017:notes:11]
Strategic investments in publicly-traded companies are recorded at fair value based on quoted prices in active markets.  Strategic investments in privately-held companies without readily determinable fair values are recorded at cost, less impairment, and are adjusted for observable price changes.  Fair value measurements and impairments for strategic investments are recognized in interest and other, net in the Consolidated Statements of Income (Loss).  In evaluating equity investments without readily determinable fair values for impairment or observable price changes, the Company uses inputs that include pre- and post-money valuations of recent financing events and the impact of those events on its fully diluted ownership percentages, as well as other available information regarding the issuer’s historical and forecasted performance.

[0001571996-20-000017:notes:12]
Allowance for Doubtful Accounts — The Company recognizes an allowance for losses on accounts receivable in an amount equal to the estimated probable losses, net of recoveries.  The allowance is based on an analysis of current receivables aging and expected future write-offs, as well as an assessment of specific identifiable customer accounts considered at risk or uncollectible.  The expense associated with the allowance for doubtful accounts is recognized in selling, general, and administrative expenses.

[0001571996-20-000017:notes:13]
Accounting for Operating Leases as a Lessee — In its ordinary course of business, the Company enters into leases as a lessee for office buildings, warehouses, employee vehicles, and equipment.  The Company determines if an arrangement is a lease or contains a lease at inception.  Operating leases result in the recognition of right of use (“ROU”) assets and lease liabilities on the Consolidated Statements of Financial Position.  ROU assets represent the right to use an underlying asset for the lease term and lease liabilities represent the obligation to make lease payments arising from the lease, measured on a discounted basis.  At lease inception, the lease liability is measured at the present value of the lease payments over the lease term.  The operating lease ROU asset equals the lease liability adjusted for any initial direct costs, prepaid or deferred rent, and lease incentives.  The Company uses the implicit rate when readily determinable.  As most of the leases do not provide an implicit rate, the Company uses its incremental borrowing rate based on the information available at the commencement date to determine the present value of lease payments.  Incremental borrowing rates used to determine the present value of lease payments were derived by reference to the Company’s secured-debt yields corresponding to the lease commencement date.

[0001571996-20-000017:notes:14]
The lease term may include options to extend or to terminate the lease that the Company is reasonably certain to exercise.  Lease expense is recognized on a straight-line basis over the lease term in most instances.  The Company has elected not to record leases with an initial term of 12 months or less on the Consolidated Statements of Financial Position.  Lease expense on such leases is recognized on a straight-line basis over the lease term.  The Company does not generate material sublease income and has no material related party leases.  The Company’s lease agreements do not contain any material residual value guarantees or material restrictive covenants.

[0001571996-20-000017:notes:15]
The Company’s office building agreements contain costs such as common area maintenance and other executory costs that are variable in nature.  Variable lease costs are expensed as incurred.  The Company combines lease and non-lease components, such as common area and other maintenance costs, in calculating the ROU assets and lease liabilities for its office buildings and employee vehicles.  Under certain service agreements with third-party logistics providers, the Company directs the use of the inventory within the warehouses and, therefore, controls the assets.  The warehouses and some of the equipment used are considered embedded leases.  The Company accounts for the lease and non-lease components separately.  The lease components consist of the warehouses and some of the equipment, such as conveyor belts.  The non-lease components consist of services and other shared equipment, such as material handling and transportation.  The Company allocates the consideration to the lease and non-lease components using their relative standalone values.  See Note 5 of the Notes to the Consolidated Financial Statements for additional information.

[0001571996-20-000017:notes:16]
Accounting for Leases as a Lessor — The Company’s wholly-owned subsidiary Dell Financial Services and its affiliates (“DFS”) act as a lessor to provide equipment financing to customers through a variety of lease arrangements (“DFS leases”).  Subsequent to the adoption of amended accounting guidance for leasing transactions (the “new lease standard”), new DFS leases are classified as sales-type leases, direct financing leases, or operating leases.  Direct financing leases under the new lease standard are immaterial.  Leases that commenced prior to the adoption of the new lease standard were not reassessed or restated pursuant to the practical expedients elected and will continue to be accounted for under previous lease accounting guidance.

[0001571996-20-000017:notes:17]
When a contract includes lease and non-lease components, DFS allocates consideration under the contract to each component based on relative standalone selling price.  Whenever the terms of the lease transfer control to the lessee, the contract is typically classified as a sales-type lease.  Through these arrangements, the lessee has the right to substantially all of the economic benefits from use of the identified asset and has the right to direct the use of such asset during the period of use.  In many arrangements, the lessee also retains ownership at the end of the lease term.  On commencement of sales-type leases, the Company recognizes profit up-front, and amounts due from the customer under the lease contract are recognized as financing receivables on the Consolidated Statements of Financial Position.  Interest income is recognized as Net revenue over the term of the lease based on the effective interest method.  The Company has elected not to include sales and other taxes collected from the lessee as part of lease revenue.

[0001571996-20-000017:notes:18]
All other leases that do not meet the definition of a sales-type lease or direct financing lease are classified as operating leases.  The underlying asset in an operating lease arrangement is carried at depreciated cost as “Equipment under operating leases” within Property, plant, and equipment, net on the Consolidated Statements of Financial Position.  Depreciation is calculated using the straight-line method over the term of the underlying lease contract and is recognized as Cost of net revenue.  The depreciable basis is the original cost of the equipment less the estimated residual value of the equipment at the end of the lease term.  The Company recognizes operating lease revenue on a straight-line basis over the lease term and expenses deferred initial direct costs on the same basis.  Impairment of equipment under operating leases is assessed on the same basis as other long-lived assets.

[0001571996-20-000017:notes:19]
DFS provides lessees with the option to extend the lease or purchase the underlying asset at the end of the lease term, which is considered when evaluating lease classification.  In general, DFS’s lease arrangements do not have variable payment terms and are non-cancelable.

[0001571996-20-000017:notes:20]
See Note 4 of the Notes to the Consolidated Financial Statements for more information regarding DFS leasing arrangements.

[0001571996-20-000017:notes:21]
Financing Receivables — Financing receivables are presented net of allowance for losses and consist of customer receivables and residual interest.  Gross customer receivables includes amounts due from customers under revolving loans, fixed-term loans, fixed-term sales-type or direct financing leases, and accrued interest.  The Company has two portfolios, consisting of  (1) fixed-term leases and loans and (2) revolving loans, and assesses risk at the portfolio level to determine the appropriate allowance levels.  The portfolio segments are further segregated into classes based on products, customer type, and credit risk evaluation: (1) Revolving — Dell Preferred Account (“DPA”); (2) Revolving — Dell Business Credit (“DBC”); and (3) Fixed-term — Consumer and Commercial.  Fixed-term leases and loans are offered to qualified small and medium-sized businesses, large commercial accounts, governmental organizations, and educational entities.  Additionally, fixed-term loans are also offered to certain individual consumer customers.  Revolving loans are offered under private label credit financing programs.  The DPA revolving loan programs are primarily offered to individual consumers and the DBC revolving loan programs are primarily offered to small and medium-sized business customers.

[0001571996-20-000017:notes:22]
The Company retains a residual interest in equipment leased under its fixed-term lease programs.  The amount of the residual interest is established at the inception of the lease based upon estimates of the value of the equipment at the end of the lease term using historical studies, industry data, and future value-at-risk demand valuation methods.  On a quarterly basis, the Company assesses the carrying amount of its recorded residual values for impairment.  Anticipated declines in specific future residual values that are considered to be other-than-temporary are recorded currently in earnings.  Generally, residual value risk on equipment under lease is not considered to be significant because of the existence of a secondary market with respect to the equipment.  The lease agreement also clearly defines applicable return conditions and remedies for non-compliance, to ensure that the leased equipment will be in good operating condition upon return.  Model changes and updates, as well as market strength and product acceptance, are monitored and adjustments are made to residual values in accordance with the significance of any such changes.  The remarketing sales staff works closely with customers and dealers to manage the sale of lease returns and the recovery of residual exposure.  As of January 31, 2020, the Company has not recorded significant residual value impairment.

[0001571996-20-000017:notes:23]
Allowance for Financing Receivables Losses — The Company recognizes an allowance for losses on financing receivables in an amount equal to the probable losses net of recoveries.  The allowance for losses is generally determined at the aggregate portfolio level based on a variety of factors, including historical and anticipated experience, past due receivables, receivable type, and customer risk profile.  Customer account principal and interest are charged to the allowance for losses when an account is deemed to be uncollectible or generally when the account is 180 days delinquent.  While the Company does not generally place financing receivables on non-accrual status during the delinquency period, accrued interest is included in the allowance for loss calculation and, therefore, the Company is adequately reserved in the event of charge off.  Recoveries on receivables previously charged off as uncollectible are recorded to the allowance for financing receivables losses.  The expense associated with the allowance for financing receivables losses is recognized as cost of net revenue.  Both fixed and revolving receivable loss rates are affected by macroeconomic conditions, including the level of gross domestic product (“GDP”) growth, unemployment rates, the level of commercial capital equipment investment, and the credit quality of the borrower.

[0001571996-20-000017:notes:24]
Asset Securitization — The Company transfers certain U.S. and European customer loan and lease payments and associated equipment to Special Purpose Entities (“SPEs”) that meet the definition of a Variable Interest Entity (“VIE”) and are consolidated into the Consolidated Financial Statements.  These SPEs are bankruptcy-remote legal entities with separate assets and liabilities.  The purpose of the SPEs is to facilitate the funding of customer loan and lease payments and associated equipment in the capital markets.  These SPEs have entered into financing arrangements with multi-seller conduits that, in turn, issue asset-backed debt securities in the capital markets.  The asset securitizations in the SPEs are accounted for as secured borrowings.  See Note 4 of the Notes to the Consolidated Financial Statements for additional information on the impact of the consolidation.

[0001571996-20-000017:notes:25]
Inventories — Inventories are stated at the lower of cost or market with cost being determined on a first-in, first-out basis.  Adjustments to reduce the cost of inventory to its net realizable value are made, if required, for estimated excess, obsolescence, or impaired balances.

[0001571996-20-000017:notes:26]
Property, Plant, and Equipment — Property, plant, and equipment are carried at depreciated cost.  Depreciation is determined using the straight-line method over the shorter of the estimated economic lives of the assets or the lease term.  The estimated useful lives of the Company’s property, plant, and equipment are generally as follows:

[0001571996-20-000017:notes:27]
|  | Estimated Useful Life |
| Computer equipment | 3-5 years |
| Equipment under operating leases | Term of underlying lease contract |
| Buildings | 10-30 years or term of underlying land lease |
| Leasehold improvements | Shorter of 5-20 years or lease term |
| Machinery and equipment | 3-5 years |

[0001571996-20-000017:notes:28]
Gains or losses related to retirements or dispositions of fixed assets are recognized in the period during which the retirement or disposition occurs.

[0001571996-20-000017:notes:29]
Capitalized Software Development Costs — Software development costs related to the development of new product offerings are capitalized subsequent to the establishment of technological feasibility, which is demonstrated by the completion of a detailed program design or working model, if no program design is completed.  The Company amortizes capitalized costs on a straight-line basis over the estimated useful lives of the products, which generally range from two to four years.

[0001571996-20-000017:notes:30]
As of January 31, 2020 and February 1, 2019, capitalized software development costs were $679 million and $617 million, respectively, and are included in other non-current assets, net in the accompanying Consolidated Statements of Financial Position.  Amortization expense for the fiscal years ended January 31, 2020, February 1, 2019, and February 2, 2018 was $273 million, $211 million, and $82 million, respectively.

[0001571996-20-000017:notes:31]
The Company capitalizes certain internal and external costs to acquire or create internal use software which are incurred subsequent to the completion of the preliminary project stage.  Development costs are amortized on a straight-line basis over the shorter of the expected useful life of the software or five years.  Costs associated with maintenance and minor enhancements to the features and functionality of the Company’s website are expensed as incurred.

[0001571996-20-000017:notes:32]
Impairment of Long-Lived Assets — The Company reviews long-lived assets for impairment when events or changes in circumstances indicate the carrying amount of an asset may not be recoverable.  The Company assesses the recoverability of the assets based on the undiscounted future cash flows expected from the use and eventual disposition of the asset.  If the carrying amount of the asset is determined not to be recoverable, a write-down to fair value is recorded.  Fair values are determined based on quoted market values, discounted cash flows, or external appraisals, as applicable.  Long-lived assets to be disposed of are reported at the lower of carrying amount or fair value less costs to sell.

[0001571996-20-000017:notes:33]
Business Combinations — The assets and liabilities of acquired businesses are recorded at their fair values at the date of acquisition.  The excess of the purchase price over the fair value of the tangible and intangible assets acquired and the liabilities assumed is recorded as goodwill.  During the measurement period, which expires one year from the acquisition date, if new information is obtained about facts and circumstances that existed as of the acquisition date, cumulative changes in the estimated fair values of the net assets recorded may change the amount of the purchase price allocable to goodwill.  If material, the amount  will be adjusted in the reporting period in which the adjustment amount is determined.  See Note 8 of the Notes to the Consolidated Financial Statements for more information on business combinations.

[0001571996-20-000017:notes:34]
In-process research and development costs are recorded at fair value as an indefinite-lived intangible asset and assessed for impairment thereafter until completion, at which point the asset is amortized over its expected useful life.  All acquisition costs are expensed as incurred, and the results of operations of acquired businesses are included in the Consolidated Financial Statements from the acquisition date.

[0001571996-20-000017:notes:35]
Intangible Assets Including Goodwill — Identifiable intangible assets with finite lives are amortized over their estimated useful lives.  Definite-lived intangible assets are reviewed for impairment when events and circumstances indicate the asset may be impaired.  Goodwill and indefinite-lived intangible assets are tested for impairment annually during the third fiscal quarter and whenever events or circumstances indicate that an impairment may have occurred.

[0001571996-20-000017:notes:36]
Foreign Currency Translation — The majority of the Company’s international sales are made by international subsidiaries, some of which have the U.S. Dollar as their functional currency.  The Company’s subsidiaries that do not use the U.S. Dollar as their functional currency translate assets and liabilities at current exchange rates in effect at the balance sheet date.  Revenue and expenses from these international subsidiaries are translated using either the monthly average exchange rates in effect for the period in which the activity was recognized or the specific daily exchange rate associated with the date the transactions actually occur.  Foreign currency translation adjustments are included as a component of accumulated other comprehensive income (loss) (“OCI”) in stockholders’ equity (deficit).

[0001571996-20-000017:notes:37]
Local currency transactions of international subsidiaries that have the U.S. Dollar as their functional currency are remeasured into U.S. Dollars using the current rates of exchange for monetary assets and liabilities and historical rates of exchange for nonmonetary assets and liabilities.  Gains and losses from remeasurement of monetary assets and liabilities are included in interest and other, net.

[0001571996-20-000017:notes:38]
Hedging Instruments — The Company uses derivative financial instruments, primarily forward contracts, options, and swaps, to hedge certain foreign currency and interest rate exposures.  The relationships between hedging instruments and hedged items, as well as the risk management objectives and strategies for undertaking hedge transactions, are formally documented.  The Company does not use derivatives for speculative purposes.  All derivative instruments are recognized as either assets or liabilities in the Consolidated Statements of Financial Position and are measured at fair value.

[0001571996-20-000017:notes:39]
The Company’s hedge portfolio includes non-designated derivatives and derivatives designated as cash flow hedges.  For derivative instruments that are designated as cash flow hedges, the Company assesses hedge effectiveness at the onset of the hedge, then performs qualitative assessments at regular intervals throughout the life of the derivative.  The gain or loss on cash flow hedges is recorded in accumulated other comprehensive income (loss), as a separate component of stockholders’ equity (deficit), and reclassified into earnings in the period during which the hedged transaction is recognized in earnings.  For derivatives that are not designated as hedges or do not qualify for hedge accounting treatment, the Company recognizes the change in the instrument’s fair value currently in earnings as a component of interest and other, net.

[0001571996-20-000017:notes:40]
Cash flows from derivative instruments are presented in the same category on the Consolidated Statements of Cash Flows as the cash flows from the underlying hedged items.  See Note 7 of the Notes to the Consolidated Financial Statements for a description of the Company’s derivative financial instrument activities.

[0001571996-20-000017:notes:41]
Revenue Recognition — The Company sells a wide portfolio of products and services to its customers.  The Company’s agreements have varying requirements depending on the goods and services being sold, the rights and obligations conveyed, and the legal jurisdiction of the arrangement.

[0001571996-20-000017:notes:42]
Revenue is recognized for these arrangements based on the following five steps:

[0001571996-20-000017:notes:43]
| (1) | Identify the contract with a customer. The term “contract” refers to the enforceable rights and obligations provided in an agreement between the Company and the customer in exchange for payment. The Company evaluates facts and circumstances regarding sales transactions in order to identify contracts with its customers. An agreement must meet all of the following criteria to qualify as a contract eligible for revenue recognition under the model: (i) the contract must be approved by all parties who are committed to perform their respective obligations; (ii) each party’s rights regarding the goods and services to be transferred to the customer can be identified; (iii) the payment terms for the goods and services can be identified; (iv) the customer has the ability and intent to pay and it is probable that the Company will collect substantially all of the consideration to which it will be entitled; and (v) the contract must have commercial substance. Judgment is used in determining the customer’s ability and intent to pay, which is based upon various factors, including the customer’s historical payment experience or customer credit and financial information. |

[0001571996-20-000017:notes:44]
| (2) | Identify the performance obligations in the contract. The Company’s contracts with customer often include the promise to transfer multiple goods and services to a customer. Distinct promises within a contract are referred to as “performance obligations” and are accounted for as separate units of account. The Company assesses whether each promised good or service is distinct for the purpose of identifying the performance obligations in the contract. This assessment involves subjective determinations and requires management to make judgments about the individual promised goods or services and whether such goods or services are separable from the other aspects of the contractual relationship. Promised goods and services are considered distinct provided that: (i) the customer can benefit from the |

[0001571996-20-000017:notes:45]
good or service either on its own or together with other resources that are readily available to the customer (that is, the good or service is capable of being distinct); and (ii) the Company’s promise to transfer the good or service to the customer is separately identifiable from other promises in the contract (that is, the promise to transfer the good or service is distinct within the context of the contract).  The Company’s performance obligations include various distinct goods and services such as hardware, software licenses, warranties, and other service offerings and solutions.  Promised goods and services are explicitly identified in the Company’s contracts and may be sold on a standalone basis or bundled as part of a combined solution.  In certain hardware solutions, the hardware is highly interdependent on, and interrelated with, the embedded software.  In these offerings, the hardware and software licenses are accounted for as a single performance obligation.

[0001571996-20-000017:notes:46]
| (3) | Determine the transaction price. The transaction price reflects the amount of consideration to which the Company expects to be entitled in exchange for transferring goods or services to the customer. If the consideration promised in a contract includes a variable amount, the Company estimates the amount to which it expects to be entitled using either the expected value or most likely amount method. Generally, volume discounts, rebates, and sales returns reduce the transaction price. In determining the transaction price, the Company only includes amounts that are not subject to significant future reversal. |

[0001571996-20-000017:notes:47]
| (4) | Allocate the transaction price to performance obligations in the contract. When a contract includes multiple performance obligations, the transaction price is allocated to each performance obligation in an amount that depicts the consideration to which the Company expects to be entitled in exchange for transferring the promised goods or services. For contracts with multiple performance obligations, the transaction price is allocated in proportion to the standalone selling price (“SSP”) of each performance obligation. |

[0001571996-20-000017:notes:48]
The best evidence of SSP is the observable price of a good or service when the Company sells that good or service separately in similar circumstances to similar customers.  If a directly observable price is available, the Company will utilize that price for the SSP.  If a directly observable price is not available, the SSP must be estimated.  The Company estimates SSP by considering multiple factors, including, but not limited to, pricing practices, internal costs, and profit objectives as well as overall market conditions, which include geographic or regional specific factors, competitive positioning, and competitor actions.

[0001571996-20-000017:notes:49]
| (5) | Recognize revenue when (or as) the performance obligation is satisfied. Revenue is recognized when obligations under the terms of the contract with the Company’s customer are satisfied. Revenue is recognized either over time or at a point in time, depending on when the underlying products or services are transferred to the customer. Revenue is recognized at a point in time for products upon transfer of control. Revenue is recognized over time for support and deployment services, software support, software-as-a-service (“SaaS”), and infrastructure-as-a-service (“IaaS”). Revenue is recognized either over time or at a point in time for professional services and training depending on the nature of the offering to the customer. |

[0001571996-20-000017:notes:50]
The Company reports revenue net of any revenue-based taxes assessed by governmental authorities that are imposed on and concurrently with specific revenue-producing transactions.

[0001571996-20-000017:notes:51]
The Company has elected the following practical expedients with the adoption of the new revenue standard:

[0001571996-20-000017:notes:52]
| • | The Company does not account for significant financing components if the period between revenue recognition and when the customer pays for the product or service will be one year or less. |

[0001571996-20-000017:notes:53]
| • | The Company recognizes revenue equal to the amount it has a right to invoice when the amount corresponds directly with the value to the customer of the Company’s performance to date. |

[0001571996-20-000017:notes:54]
| • | The Company does not account for shipping and handling activities as a separate performance obligation, but rather as an activity performed to transfer the promised good. |

[0001571996-20-000017:notes:55]
The following summarizes the nature of revenue recognized and the manner in which the Company accounts for sales transactions.

[0001571996-20-000017:notes:56]
Products

[0001571996-20-000017:notes:57]
Product revenue consists of hardware and software license sales that are delivered, sold as a subscription, or sold on a consumption basis.  Hardware includes notebooks and desktop PCs, servers, storage hardware, and other hardware-related devices.  Software license sales include non-essential software applications.  Software applications provide customers with resource management, backup and archiving, information security, information management and intelligence, data analytics, and server virtualization capabilities.

[0001571996-20-000017:notes:58]
Revenue from the sale of hardware products is recognized when control has transferred to the customer, which typically occurs when the hardware has been shipped to the customer, risk of loss has transferred to the customer, the Company has a present right to payment, and customer acceptance has been satisfied.  Customer acceptance is satisfied if acceptance is obtained from the customer, if all acceptance provisions lapse, or if the Company has evidence that all acceptance provisions will be, or have been, satisfied.  Revenue from software license sales is generally recognized when control has transferred to the customer, which is typically upon shipment, electronic delivery, or when the software is available for download by the customer.  For certain software arrangements in which the customer is granted a right to additional unspecified future software licenses, the Company’s promise to the customer is considered a stand-ready obligation in which the transfer of control and revenue recognition will be over time.  Invoices for products are generally issued as control transfers, which is typically upon shipment or delivery.  There was no significant revenue in any period presented related to performance obligations satisfied or partially satisfied in prior periods.

[0001571996-20-000017:notes:59]
Services

[0001571996-20-000017:notes:60]
Services revenue consists of revenue from sales of support services, including hardware support that extends beyond the Company’s standard warranties, software maintenance, and installation; professional services; training; SaaS; and IaaS.  Revenue associated with undelivered performance obligations is deferred and recognized when or as control is transferred to the customer.  Revenue from fixed-price support or maintenance contracts sold for both hardware and software is recognized on a straight-line basis over the period of performance because the Company is required to provide services at any given time.  Other services revenue is recognized when the Company performs the services and the customer receives and consumes the benefits.

[0001571996-20-000017:notes:61]
Invoices for services may be issued at the start of a service term, which is typically the case for support and deployment services, or as services are rendered, which is typically the case for professional services, training, SaaS, and IaaS.

[0001571996-20-000017:notes:62]
Other

[0001571996-20-000017:notes:63]
Revenue from leasing arrangements is not subject to the revenue standard for contracts with customers and remains separately accounted for under existing lease accounting guidance.  The Company records operating lease rental revenue as product revenue on a straight-line basis over the lease term.  The Company records revenue from the sale of equipment under sales-type leases as product revenue in an amount equal to the present value of minimum lease payments at the inception of the lease.  Sales-type leases also produce financing income, which is included in products net revenue in the Consolidated Statements of Income (Loss) and is recognized at effective rates of return over the lease term.  The Company also offers qualified customers fixed-term loans and revolving credit lines for the purchase of products and services offered by the Company.  Financing income attributable to these loans is recognized in products net revenue on an accrual basis.

[0001571996-20-000017:notes:64]
Disaggregation of Revenue — The Company’s revenue is presented on a disaggregated basis on the Consolidated Statements of Income (Loss) and in Note 19 of the Notes to the Consolidated Financial Statements based on an evaluation of disclosures outside of the financial statements, information regularly reviewed by the chief operating decision maker for evaluating the financial performance of operating segments, and other information that is used to evaluate the Company’s financial performance or make resource allocations.  This information includes revenue from products and services, revenue from reportable segments, and revenue by major product categories within the segments.

[0001571996-20-000017:notes:65]
Contract Assets — Contract assets are rights to consideration in exchange for goods or services that the Company has transferred to a customer when such a right is conditional on something other than the passage of time.  Such amounts have been insignificant to date.

[0001571996-20-000017:notes:66]
Contract Liabilities — Contract liabilities primarily consist of deferred revenue.  Deferred revenue is recorded when the Company has a right to invoice or payments have been received for undelivered products or services, or in situations where revenue recognition criteria have not been met.  Deferred revenue also represents amounts received in advance for extended warranty services and software maintenance.  Revenue is recognized on these items when the revenue recognition criteria are met, generally resulting in ratable recognition over the contract term.  The Company also has deferred revenue related to undelivered hardware and professional services, consisting of installations and consulting engagements, which are recognized when the Company’s performance obligations under the contract are completed.  See Note 9 of the Notes to the Consolidated Financial Statements for additional information about deferred revenue.

[0001571996-20-000017:notes:67]
Costs to Obtain a Contract — The incremental direct costs of obtaining a contract primarily consist of sales commissions and employer taxes related to commission payments.  The Company has elected, as a practical expedient, to expense as incurred costs to obtain a contract equal to or less than one year in duration.  For contracts greater than one year in duration, the associated costs to obtain a contract are deferred and amortized over the period of contract performance or a longer period, generally the estimated life of the customer relationship, if renewals are expected and the renewal commission is not commensurate with the initial commission.  Deferred costs to obtain a contract are typically amortized over an average period of three to seven years, depending on the contract term and expectation of the period of benefit for the costs, which may exceed the contract term.  Amortization expense is recognized on a straight-line basis and included in selling, general, and administrative expenses in the Consolidated Statements of Income (Loss).

[0001571996-20-000017:notes:68]
The Company periodically reviews these deferred costs to determine whether events or changes in circumstances have occurred that could impact the carrying value or period of benefit of the deferred sales commissions.  There were no material impairment losses for deferred costs to obtain a contract during the fiscal years ended January 31, 2020, February 1, 2019, and February 2, 2018.

[0001571996-20-000017:notes:69]
Deferred costs to obtain a contract as of January 31, 2020 and February 1, 2019 were $1.6 billion and $1.3 billion, respectively.  Deferred costs to obtain a contract are classified as current assets and other non-current assets on the Consolidated Statements of Financial Position, based on when the expense is expected to be recognized.  Amortization of costs to obtain a contract during the fiscal years ended January 31, 2020, February 1, 2019, and February 2, 2018 was $675 million, $517 million, and $292 million, respectively.

[0001571996-20-000017:notes:70]
Standard Warranty Liabilities — The Company records warranty liabilities for estimated costs of fulfilling its obligations under standard limited hardware and software warranties at the time of sale.  The liability for standard warranties is included in accrued and other current and other non-current liabilities in the Consolidated Statements of Financial Position.  The specific warranty terms and conditions vary depending upon the product sold and the country in which the Company does business, but generally includes technical support, parts, and labor over a period ranging from one to three years.  Factors that affect the Company’s warranty liability include the number of installed units currently under warranty, historical and anticipated rates of warranty claims on those units, and cost per claim to satisfy the Company’s warranty obligation.  The anticipated rate of warranty claims is the primary factor impacting the estimated warranty obligation.  The other factors are less significant due to the fact that the average remaining aggregate warranty period of the covered installed base is approximately 18 months, repair parts are generally already in stock or available at pre-determined prices, and labor rates are generally arranged at preestablished amounts with service providers.  Warranty claims are relatively predictable based on historical experience of failure rates.  If actual results differ from the estimates, the Company revises its estimated warranty liability.  Each quarter, the Company reevaluates its estimates to assess the adequacy of its recorded warranty liabilities and adjusts the amounts as necessary.

[0001571996-20-000017:notes:71]
Vendor Rebates and Settlements — The Company may receive consideration from vendors in the normal course of business.  Certain of these funds are rebates of purchase price paid and others are related to reimbursement of costs incurred by the Company to sell the vendor’s products.  The Company recognizes a reduction of cost of goods sold if the funds are determined to be a reduction of the price of the vendor’s products.  If the consideration is a reimbursement of costs incurred by the Company to sell or develop the vendor’s products, then the consideration is classified as a reduction of such costs, most often operating expenses, in the Consolidated Statements of Income (Loss).  In order to be recognized as a reduction of operating

[0001571996-20-000017:notes:72]
expenses, the reimbursement must be for a specific, incremental, and identifiable cost incurred by the Company in selling the vendor’s products or services.

[0001571996-20-000017:notes:73]
In addition, the Company may settle commercial disputes with vendors from time to time.  Claims for loss recoveries are recognized when a loss event has occurred, recovery is considered probable, the agreement is finalized, and collectibility is assured.  Amounts received by the Company from vendors for loss recoveries are generally recorded as a reduction of cost of goods sold.

[0001571996-20-000017:notes:74]
Loss Contingencies — The Company is subject to the possibility of various losses arising in the ordinary course of business.  The Company considers the likelihood of loss or impairment of an asset or the incurrence of a liability, as well as the Company’s ability to reasonably estimate the amount of loss, in determining loss contingencies.  An estimated loss contingency is accrued when it is probable that an asset has been impaired or a liability has been incurred and the amount of loss can be reasonably estimated.  The Company regularly evaluates current information available to determine whether such accruals should be adjusted and whether new accruals are required.

[0001571996-20-000017:notes:75]
Shipping Costs — The Company’s shipping and handling costs are included in cost of net revenue in the Consolidated Statements of Income (Loss).

[0001571996-20-000017:notes:76]
Selling, General, and Administrative — Selling expenses include items such as sales salaries and commissions, marketing and advertising costs, contractor services, and allowance for doubtful accounts.  Advertising costs are expensed as incurred in selling, general, and administrative expenses in the Consolidated Statements of Income (Loss).  For the fiscal years ended January 31, 2020, February 1, 2019, and February 2, 2018, advertising expenses were $1.3 billion, $1.1 billion, and $1.0 billion, respectively.  General and administrative expenses include items for the Company’s administrative functions, such as finance, legal, human resources, and information technology support.  These functions include costs for items such as salaries and benefits and other personnel-related costs, maintenance and supplies, outside services, intangible asset amortization, and depreciation expense.

[0001571996-20-000017:notes:77]
Research and Development — Research and development (“R&D”) costs are expensed as incurred.  R&D costs include salaries and benefits and other personnel-related costs associated with product development.  Also included in R&D expenses are infrastructure costs, which consist of equipment and material costs, facilities-related costs, and depreciation expense.

[0001571996-20-000017:notes:78]
Income Taxes — Deferred tax assets and liabilities are recorded based on the difference between the financial statement and tax basis of assets and liabilities using enacted tax rates in effect for the year in which the differences are expected to reverse.  The Company calculates a provision for income taxes using the asset and liability method, under which deferred tax assets and liabilities are recognized by identifying the temporary differences arising from the different treatment of items for tax and accounting purposes.  The Company accounts for the tax impact of including Global Intangible Low-Taxed Income (GILTI) in U.S. taxable income as a period cost.  The Company provides valuation allowances for deferred tax assets, where appropriate.  In assessing the need for a valuation allowance, the Company considers all available evidence for each jurisdiction, including past operating results, estimates of future taxable income, and the feasibility of ongoing tax planning strategies.  In the event the Company determines that all or part of the net deferred tax assets are not realizable in the future, the Company will make an adjustment to the valuation allowance that would be charged to earnings in the period in which such a determination is made.

[0001571996-20-000017:notes:79]
The accounting guidance for uncertainties in income tax prescribes a comprehensive model for the financial statement recognition, measurement, presentation, and disclosure of uncertain tax positions taken or expected to be taken in income tax returns.  The Company recognizes a tax benefit from an uncertain tax position in the financial statements only when it is more likely than not that the position will be sustained upon examination, including resolution of any related appeals or litigation processes, based on the technical merits and a consideration of the relevant taxing authority’s administrative practices and precedents.

[0001571996-20-000017:notes:80]
Stock-Based Compensation — The Company measures stock-based compensation expense for all share-based awards granted based on the estimated fair value of those awards at grant date.  The Company estimates the fair value of service-based stock options using the Black-Scholes valuation model.  To estimate the fair value of performance-based awards containing a market condition, the Company uses the Monte Carlo valuation model.  The fair value of all other share-based awards is based on the closing price of the Class C Common Stock as reported on the NYSE on the date of grant.

[0001571996-20-000017:notes:81]
The compensation cost of service-based stock options, restricted stock, and restricted stock units is recognized net of any estimated forfeitures on a straight-line basis over the employee requisite service period.  Compensation cost for performance-based awards is recognized on a graded accelerated basis net of estimated forfeitures over the requisite service period.  Forfeiture rates are estimated at grant date based on historical experience and adjusted in subsequent periods for differences in actual forfeitures from those estimates.  See Note 16 of the Notes to the Consolidated Financial Statements for further discussion of stock-based compensation.

[0001571996-20-000017:notes:82]
Recently Issued Accounting Pronouncements

[0001571996-20-000017:notes:83]
Measurement of Credit Losses on Financial Instruments — In June 2016, the Financial Accounting Standards Board (“FASB”) issued amended guidance which replaces the current incurred loss impairment methodology for measurement of credit losses on financial instruments with a methodology that reflects expected credit losses and requires consideration of a broader range of reasonable and supportable information to inform credit loss estimates.  Public entities must adopt the new guidance for fiscal years beginning after December 15, 2019, and interim periods within those fiscal years, with early adoption permitted for fiscal periods beginning after December 15, 2018.  Adoption of the standard will be applied using a modified retrospective approach through a cumulative-effect adjustment to accumulated deficit as of the effective date beginning February 1, 2020.  The Company expects the adoption of this guidance to have an immaterial impact on accounts receivable, net, financing receivables, net, and accumulated deficit in the Consolidated Financial Statements.

[0001571996-20-000017:notes:84]
Intangibles - Goodwill and Other - Internal-Use Software — In August 2018, the FASB issued guidance on a customer’s accounting for implementation costs incurred in a cloud-computing arrangement when hosted by a vendor.  In a hosting arrangement that is a service contract, certain implementation costs should be capitalized and amortized over the term of the arrangement.  Public entities must adopt the new guidance for fiscal years beginning after December 15, 2019, and interim periods within those fiscal years, with early adoption permitted for fiscal periods beginning after December 15, 2018.  The Company will adopt this standard using the prospective approach as of the effective date beginning February 1, 2020, and does not expect adoption to have a material impact on the Consolidated Financial Statements.

[0001571996-20-000017:notes:85]
Simplifying Accounting for Income Taxes — In December 2019, the FASB issued guidance to simplify the accounting for income taxes by removing certain exceptions to the general principles in Topic 740, Income Taxes, and by clarifying and amending existing guidance in order to improve consistent application of GAAP for other areas of Topic 740.  Public entities must adopt the new guidance for fiscal years beginning after December 15, 2020, and interim periods within those fiscal years, with early adoption permitted for fiscal periods beginning after December 15, 2019.  The Company is currently evaluating the impact and timing of adoption of this guidance.

[0001571996-20-000017:notes:86]
Recently Adopted Accounting Pronouncements

[0001571996-20-000017:notes:87]
Leases — In February 2016, the FASB issued amended guidance on the accounting for leasing transactions.  The primary objective of this update is to increase transparency and comparability among organizations by requiring lessees to recognize a lease liability for the obligation to make lease payments and an ROU asset for the right to use the underlying asset for the lease term.  The guidance also results in some changes to lessor accounting and requires additional disclosures about all leasing arrangements.

[0001571996-20-000017:notes:88]
The Company adopted the new lease standard as of February 2, 2019 using the modified retrospective approach, with the cumulative-effect adjustment to the opening balance of stockholders’ equity (deficit) as of the adoption date.  The Company elected to apply the practical expedient using the transition option whereby prior comparative periods were not retrospectively adjusted in the Consolidated Financial Statements.  Accordingly, prior comparative periods have not been adjusted in the Consolidated Financial Statements.  The Company also elected the package of practical expedients that does not require reassessment of initial direct costs, classification of a lease, and definition of a lease.

[0001571996-20-000017:notes:89]
The adoption of the new lease standard resulted in the recognition of $1.6 billion in operating lease liabilities and related ROU assets on the Consolidated Statements of Financial Position.  The Company recorded an immaterial adjustment to stockholders’ equity (deficit) as of February 2, 2019 to reflect the cumulative effect of adoption of the new lease standard.  As of February 2, 2019, there were no material finance leases for which the Company was a lessee.

[0001571996-20-000017:notes:90]
In the area of lessor accounting, as of February 2, 2019, the Company began to originate operating leases due to the elimination of third-party residual value guarantee insurance from the sales-type lease classification test.  Leases that commenced prior to the adoption of the new lease standard were not reassessed or restated pursuant to the practical expedients elected.  Accordingly, there was no cumulative adjustment to stockholders’ equity (deficit) related to lessor accounting.

[0001571996-20-000017:notes:91]
See Note 4 and Note 5 of the Notes to the Consolidated Financial Statements for additional information about the Company’s leases from a lessor and lessee perspective, respectively.

[0001571996-20-000017:notes:92]
Revenue from Contracts with Customers — In May 2014, the FASB issued amended guidance on the recognition of revenue from contracts with customers.  The new standard established a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes substantially all of the previous revenue recognition guidance, including industry-specific guidance.  The new standard requires entities to recognize revenue when it transfers promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services.  Further, the new standard requires additional disclosures to help enable users of the financial statements to better understand the nature, amount, timing, risks, and judgments related to revenue recognition and related cash flows from contracts with customers.  Concurrently, the FASB issued guidance on the accounting for costs to fulfill or obtain a customer contract.  The Company adopted these standards during the three months ended May 4, 2018 using the full retrospective method, which requires the Company to recast each prior period presented consistent with the new guidance.  The Company recorded a credit of approximately $1 billion to retained earnings as of January 29, 2016 to reflect the cumulative effect of the adoption.

[0001571996-20-000017:notes:93]
Recognition and Measurement of Financial Assets and Financial Liabilities — In January 2016, the FASB issued amended guidance that generally requires changes in the fair value of equity investments, other than those accounted for under the equity method, to be recognized through net income, rather than other comprehensive income.  For equity investments without readily determinable fair values, the Company is no longer permitted to use the cost method of accounting.  The Company has elected to apply the measurement alternative for those investments.  Under the alternative, the Company measures investments without readily determinable fair values at cost, less impairment, adjusted by observable price changes on a prospective basis.  The Company must make a separate election to use the alternative for each eligible investment and is required to reassess at each reporting period whether an investment qualifies for the alternative.  The Company adopted this standard during the three months ended May 4, 2018.  Adoption of the standard was applied through a cumulative one-time adjustment to accumulated deficit of $56 million for the accumulated unrealized gain previously recorded in other comprehensive income.

[0001571996-20-000017:notes:94]
Classification of Certain Cash Receipts and Cash Payments — In August 2016, the FASB issued amended guidance on the presentation and classification of eight specific cash flow issues with the objective of reducing existing diversity in practice.  Companies should reflect any adjustments on a retrospective basis, if practicable; otherwise, adoption is required to be applied as of the earliest date practicable.  The Company adopted this standard during the three months ended May 4, 2018.

[0001571996-20-000017:notes:95]
Statement of Cash Flows, Restricted Cash — In November 2016, the FASB issued amended guidance requiring entities to include restricted cash and restricted cash equivalents in cash balances on the cash flow statement, and also to provide a supplemental reconciliation of cash, cash equivalents, and restricted cash.  Public entities must adopt the new guidance for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017, with early adoption permitted.  The Company adopted this standard during the three months ended May 4, 2018.  See Note 20 of the Notes to the Consolidated Financial Statements for supplemental cash flow information.

[0001571996-20-000017:notes:96]
Intra-Entity Transfers of Assets Other Than Inventory — In October 2016, the FASB issued amended guidance on the accounting for income taxes.  The new guidance requires companies to recognize the income tax effects of intra-entity asset transfers, other than transfers of inventory, when the transfer occurs instead of when the asset is sold to a third party.  The new guidance should be applied on a modified-retrospective basis with the cumulative-effect adjustment to retained earnings as of the beginning of the period of adoption.  The Company early adopted this guidance during the three months ended May 5, 2017.  At adoption, approximately $84 million was reclassified from other non-current liabilities to retained earnings, resulting in a net credit to retained earnings.

[0001571996-20-000017:notes:97]
Simplifying the Test for Goodwill Impairment — In January 2017, the FASB issued amended guidance to simplify the subsequent measurement of goodwill by removing Step 2 of the goodwill impairment test.  Instead, under the amendments in the new guidance, an entity should perform its annual, or interim, goodwill impairment test by comparing the fair value of a reporting unit with its carrying amount.  An entity should recognize an impairment charge for the amount by which the carrying amount exceeds the reporting unit’s fair value.  Public entities must adopt the new guidance in fiscal years beginning after December 15, 2019, with early adoption permitted.  In conjunction with its annual goodwill and indefinite-lived intangible assets impairment testing which occurs during the third fiscal quarter of each year, the Company elected to early adopt this guidance during the three months ended November 2, 2018.  See Note 8 of the Notes to the Consolidated Financial Statements for additional information about goodwill impairment testing.

[0001571996-20-000017:notes:98]
Derivatives and Hedging — In August 2017, the FASB issued amended guidance that will make more financial and non-financial hedging strategies eligible for hedge accounting.  The amended guidance changes how companies assess effectiveness, and also amends the presentation and disclosure requirements.  The guidance is intended to simplify the application of hedge accounting and increase transparency as to the scope and results of hedging programs.  Immediate early adoption is permitted in any interim or annual period.  The Company elected to early adopt this standard during the three months ended May 4, 2018.  The impact of the adoption of the standard was immaterial to the Consolidated Financial Statements.

[0001571996-20-000017:notes:99]
Income Statement - Reporting Comprehensive Income — In February 2018, the FASB issued guidance that will permit entities to reclassify the tax effects stranded in accumulated other comprehensive income to accumulated deficit as a result of U.S. Tax Reform, discussed in Note 11 of the Notes to the Consolidated Financial Statements.  The guidance gives entities the option to reclassify these amounts, but requires new disclosures regardless of whether they elect to do so.  The guidance is effective for fiscal years beginning after December 15, 2018, and interim periods within those fiscal years.  The Company elected to early adopt this standard during the three months ended May 4, 2018 and recorded the impact of the adoption as a cumulative adjustment to accumulated deficit.  The impact of the adoption was immaterial to the Consolidated Financial Statements.


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001571996-20-000017:notes:100]
The estimated useful lives of the Company’s property, plant, and equipment are generally as follows:

[0001571996-20-000017:notes:101]
The following table presents the components of the Company’s operating lease portfolio included in Property, plant, and equipment, net as of the date indicated:

[0001571996-20-000017:notes:102]
|  | January 31, 2020 |
|  | (in millions) |
| Equipment under operating lease, gross | $ | 956 |  |
| Less: accumulated depreciation | (116 | ) |
| Equipment under operating lease, net | $ | 840 |  |


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock

[0001571996-20-000017:notes:103]
The Company accrues a liability when it believes that it is both probable that a liability has been incurred and that it can reasonably estimate the amount of the loss.  The Company reviews these accruals at least quarterly and adjusts them to reflect ongoing negotiations, settlements, rulings, advice of legal counsel, and other relevant information.  To the extent new information is obtained and the Company’s views on the probable outcomes of claims, suits, assessments, investigations, or legal proceedings change, changes in the Company’s accrued liabilities would be recorded in the period in which such a determination is made.  For some matters, the amount of liability is not probable or the amount cannot be reasonably estimated and therefore accruals have not been made.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0001571996-20-000017:notes:104]
Deferred costs to obtain a contract as of January 31, 2020 and February 1, 2019 were $1.6 billion and $1.3 billion, respectively.  Deferred costs to obtain a contract are classified as current assets and other non-current assets on the Consolidated Statements of Financial Position, based on when the expense is expected to be recognized.
Vendor Rebates and Settlements — The Company may receive consideration from vendors in the normal course of business.  Certain of these funds are rebates of purchase price paid and others are related to reimbursement of costs incurred by the Company to sell the vendor’s products.  The Company recognizes a reduction of cost of goods sold if the funds are determined to be a reduction of the price of the vendor’s products.  If the consideration is a reimbursement of costs incurred by the Company to sell or develop the vendor’s products, then the consideration is classified as a reduction of such costs, most often operating expenses, in the Consolidated Statements of Income (Loss).  In order to be recognized as a reduction of operating


## us-gaap:FairValueDisclosuresTextBlock

[0001571996-20-000017:notes:105]
NOTE 3 — FAIR VALUE MEASUREMENTS AND INVESTMENTS

[0001571996-20-000017:notes:106]
The following table presents the Company’s hierarchy for its assets and liabilities measured at fair value on a recurring basis as of the dates indicated:

[0001571996-20-000017:notes:107]
|  | January 31, 2020 |  | February 1, 2019 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | QuotedPricesin ActiveMarkets forIdenticalAssets |  | SignificantOtherObservableInputs |  | SignificantUnobservableInputs |  |  |  | QuotedPricesin ActiveMarkets forIdenticalAssets |  | SignificantOtherObservableInputs |  | SignificantUnobservableInputs |  |  |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 4,621 |  |  | $ | — |  |  | $ | — |  |  | $ | 4,621 |  |  | $ | 5,221 |  |  | $ | — |  |  | $ | — |  |  | $ | 5,221 |  |
| Equity and other securities | 12 |  |  | — |  |  | — |  |  | 12 |  |  | 314 |  |  | 20 |  |  | — |  |  | 334 |  |
| Derivative instruments | — |  |  | 81 |  |  | — |  |  | 81 |  |  | — |  |  | 97 |  |  | — |  |  | 97 |  |
| Total assets | $ | 4,633 |  |  | $ | 81 |  |  | $ | — |  |  | $ | 4,714 |  |  | $ | 5,535 |  |  | $ | 117 |  |  | $ | — |  |  | $ | 5,652 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative instruments | $ | — |  |  | $ | 68 |  |  | $ | — |  |  | $ | 68 |  |  | $ | — |  |  | $ | 60 |  |  | $ | — |  |  | $ | 60 |  |
| Total liabilities | $ | — |  |  | $ | 68 |  |  | $ | — |  |  | $ | 68 |  |  | $ | — |  |  | $ | 60 |  |  | $ | — |  |  | $ | 60 |  |

[0001571996-20-000017:notes:108]
The following section describes the valuation methodologies the Company uses to measure financial instruments at fair value:

[0001571996-20-000017:notes:109]
Money Market Funds — The Company’s investment in money market funds that are classified as cash equivalents hold underlying investments with a weighted average maturity of 90 days or less and are recognized at fair value.  The valuations of these securities are based on quoted prices in active markets for identical assets, when available, or pricing models whereby all significant inputs are observable or can be derived from or corroborated by observable market data.  The Company reviews security pricing and assesses liquidity on a quarterly basis.  As of January 31, 2020, the Company’s U.S. portfolio had no material exposure to money market funds with a fluctuating net asset value.

[0001571996-20-000017:notes:110]
Equity and Other Securities — The majority of the Company’s investments in equity and other securities that are measured at fair value on a recurring basis consist of strategic investments in publicly-traded companies.  The valuation of these securities is based on quoted prices in active markets.

[0001571996-20-000017:notes:111]
Derivative Instruments — The Company’s derivative financial instruments consist primarily of foreign currency forward and purchased option contracts and interest rate swaps.  The fair value of the portfolio is determined using valuation models based on market observable inputs, including interest rate curves, forward and spot prices for currencies, and implied volatilities.  Credit risk is also factored into the fair value calculation of the Company’s derivative financial instrument portfolio.  See Note 7 of the Notes to the Consolidated Financial Statements for a description of the Company’s derivative financial instrument activities.

[0001571996-20-000017:notes:112]
Deferred Compensation Plans —The Company offers deferred compensation plans for eligible employees, which allow participants to defer payment for a portion of their compensation.  Assets were the same as liabilities associated with the plans at approximately $241 million and $192 million as of January 31, 2020 and February 1, 2019, respectively, and are included in other assets and other liabilities on the Consolidated Statements of Financial Position.  The net impact to the Consolidated Statements of Income (Loss) is not material since changes in the fair value of the assets substantially offset changes in the fair value of the liabilities.  As such, assets and liabilities associated with these plans have not been included in the recurring fair value table above.

[0001571996-20-000017:notes:113]
Assets and Liabilities Measured at Fair Value on a Nonrecurring Basis — Certain assets are measured at fair value on a nonrecurring basis and therefore are not included in the recurring fair value table above.  These assets consist primarily of non-financial assets such as goodwill and intangible assets.  See Note 8 of the Notes to the Consolidated Financial Statements for additional information about goodwill and intangible assets.

[0001571996-20-000017:notes:114]
As of January 31, 2020 and February 1, 2019, the Company held private strategic investments of $852 million and $671 million, respectively.  As these investments represent early-stage companies without readily determinable fair values, they are not included in the recurring fair value table above.

[0001571996-20-000017:notes:115]
The Company has elected to apply the measurement alternative for these investments.  Under the alternative, the Company measures investments without readily determinable fair values at cost, less impairment, adjusted by observable price changes.  The Company must make a separate election to use the alternative for each eligible investment and is required to reassess at each reporting period whether an investment qualifies for the alternative.  In evaluating these investments for impairment or observable price changes, the Company uses inputs including pre- and post-money valuations of recent financing events and the impact of those events on its fully diluted ownership percentages, as well as other available information regarding the issuer’s historical and forecasted performance.

[0001571996-20-000017:notes:116]
Carrying Value and Estimated Fair Value of Outstanding Debt — The following table summarizes the carrying value and estimated fair value of the Company’s outstanding debt as described in Note 6 of the Notes to the Consolidated Financial Statements, including the current portion, as of the dates indicated:

[0001571996-20-000017:notes:117]
|  | January 31, 2020 |  | February 1, 2019 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Secured Credit Facilities | $ | 8.8 |  |  | $ | 9.0 |  |  | $ | 12.5 |  |  | $ | 12.6 |  |
| First Lien Notes | $ | 20.5 |  |  | $ | 23.9 |  |  | $ | 19.8 |  |  | $ | 21.0 |  |
| Unsecured Notes and Debentures | $ | 1.2 |  |  | $ | 1.5 |  |  | $ | 1.8 |  |  | $ | 1.9 |  |
| Senior Notes | $ | 2.6 |  |  | $ | 2.8 |  |  | $ | 3.1 |  |  | $ | 3.4 |  |
| EMC Notes | $ | 1.6 |  |  | $ | 1.6 |  |  | $ | 3.0 |  |  | $ | 2.9 |  |
| VMware Notes and VMware Term Loan Facility | $ | 5.5 |  |  | $ | 5.6 |  |  | $ | 4.0 |  |  | $ | 3.9 |  |
| Margin Loan Facility | $ | 4.0 |  |  | $ | 3.9 |  |  | $ | 3.3 |  |  | $ | 3.4 |  |

[0001571996-20-000017:notes:118]
The fair values of the outstanding debt shown in the table above, as well as the DFS debt described in Note 4 of the Notes to the Consolidated Financial Statements, were determined based on observable market prices in a less active market or based on valuation methodologies using observable inputs and were categorized as Level 2 in the fair value hierarchy.  The carrying value of DFS debt approximates fair value.

[0001571996-20-000017:notes:119]
Investments

[0001571996-20-000017:notes:120]
The following table presents the carrying value of the Company’s strategic investments in publicly-traded and privately-held companies as of the dates indicated:

[0001571996-20-000017:notes:121]
|  | January 31, 2020 |  | February 1, 2019 |
|  | Cost |  | Unrealized Gain |  | Unrealized (Loss) |  | Carrying Value |  | Cost |  | Unrealized Gain |  | Unrealized (Loss) |  | Carrying Value |
|  | (in millions) |
| Equity and other securities | $ | 783 |  |  | $ | 116 |  |  | $ | (35 | ) |  | $ | 864 |  |  | $ | 638 |  |  | $ | 539 |  |  | $ | (172 | ) |  | $ | 1,005 |  |

[0001571996-20-000017:notes:122]
For the fiscal year ended January 31, 2020, the equity and other securities without readily determinable fair values of $852 million increased by $110 million due to upward adjustments for observable price changes, offset by $15 million of downward adjustments that were primarily attributable to impairments.  For the fiscal year ended February 1, 2019, the equity and other securities without readily determinable fair values increased by $233 million due to upward adjustments for observable price changes, offset by $80 million of downward adjustments that were primarily attributable to impairments.  The remainder of equity and other securities consisted of publicly-traded investments that are measured at fair value on a recurring basis for both the fiscal years ended January 31, 2020 and February 1, 2019.


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0001571996-20-000017:notes:123]
NOTE 4 — FINANCIAL SERVICES

[0001571996-20-000017:notes:124]
The Company offers or arranges various financing options and services, and alternative payment structures for its customers in North America, Europe, Australia, and New Zealand through DFS.  The Company also arranges financing for some of its customers in various countries where DFS does not currently operate as a captive enterprise.  The key activities of DFS include originating, collecting, and servicing of customer financing arrangements primarily related to the purchase or use of Dell Technologies products and services.  In some cases, DFS also offers financing for the purchase of third-party technology products that complement the Dell Technologies portfolio of products and services.  New financing originations were $8.5 billion, $7.3 billion, and $6.3 billion for the fiscal years ended January 31, 2020, February 1, 2019, and February 2, 2018, respectively.

[0001571996-20-000017:notes:125]
The Company’s lease and loan arrangements with customers are aggregated into the following categories:

[0001571996-20-000017:notes:126]
Revolving loans — Revolving loans offered under private label credit financing programs provide qualified customers with a revolving credit line for the purchase of products and services offered by Dell Technologies.  These private label credit financing programs are referred to as Dell Preferred Account (“DPA”) and Dell Business Credit (“DBC”).  The DPA product is primarily offered to individual consumer customers, and the DBC product is primarily offered to small and medium-sized commercial customers.  Revolving loans in the United States bear interest at a variable annual percentage rate that is tied to the prime rate.  Based on historical payment patterns, revolving loan transactions are typically repaid within twelve months on average.  Due to the short-term nature of the revolving loan portfolio, the carrying value of the portfolio approximates fair value.

[0001571996-20-000017:notes:127]
Fixed-term leases and loans — The Company enters into financing arrangements with customers who seek lease financing for equipment they might otherwise purchase.  Under the new lease standard discussed in Note 2 of the Notes to the Consolidated Financial Statements, new DFS leases are classified as sales-type leases, direct financing leases, or operating leases.  When the terms of the DFS lease transfer control of the underlying asset to the lessee, the contract is typically classified as a sales-type lease.  Direct financing leases under the new lease standard are immaterial.  All other new DFS leases are classified as operating leases.  Leases that commenced prior to the adoption of the new lease standard were not reassessed or restated pursuant to the practical expedients elected and will continue to be accounted for under previous lease accounting guidance.  Leases with business customers have fixed terms of generally two to four years.

[0001571996-20-000017:notes:128]
The Company also offers fixed-term loans to qualified small businesses, large commercial accounts, governmental organizations, educational entities, and certain individual consumer customers.  These loans are repaid in equal payments including interest and have defined terms of generally three to five years.  The fair value of the fixed-term loan portfolio is determined using market observable inputs.  The carrying value of these loans approximates fair value.

[0001571996-20-000017:notes:129]
Financing Receivables

[0001571996-20-000017:notes:130]
The following table presents the components of the Company’s financing receivables segregated by portfolio segment as of the dates indicated:

[0001571996-20-000017:notes:131]
|  | January 31, 2020 |  | February 1, 2019 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Financing receivables, net: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer receivables, gross (a) | $ | 824 |  |  | $ | 8,486 |  |  | $ | 9,310 |  |  | $ | 835 |  |  | $ | 7,249 |  |  | $ | 8,084 |  |
| Allowances for losses | (70 | ) |  | (79 | ) |  | (149 | ) |  | (75 | ) |  | (61 | ) |  | (136 | ) |
| Customer receivables, net | 754 |  |  | 8,407 |  |  | 9,161 |  |  | 760 |  |  | 7,188 |  |  | 7,948 |  |
| Residual interest | — |  |  | 582 |  |  | 582 |  |  | — |  |  | 674 |  |  | 674 |  |
| Financing receivables, net | $ | 754 |  |  | $ | 8,989 |  |  | $ | 9,743 |  |  | $ | 760 |  |  | $ | 7,862 |  |  | $ | 8,622 |  |
| Short-term | $ | 754 |  |  | $ | 4,141 |  |  | $ | 4,895 |  |  | $ | 760 |  |  | $ | 3,638 |  |  | $ | 4,398 |  |
| Long-term | $ | — |  |  | $ | 4,848 |  |  | $ | 4,848 |  |  | $ | — |  |  | $ | 4,224 |  |  | $ | 4,224 |  |

[0001571996-20-000017:notes:132]
____________________

[0001571996-20-000017:notes:133]
| (a) | Customer receivables, gross includes amounts due from customers under revolving loans, fixed-term loans, fixed-term sales-type or direct financing leases, and accrued interest. |

[0001571996-20-000017:notes:134]
The following table presents the changes in allowance for financing receivable losses for the periods indicated:

[0001571996-20-000017:notes:135]
|  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |  |  |  |  |  |
| Balances as of February 3, 2017 | $ | 91 |  |  | $ | 52 |  |  | $ | 143 |  |
| Charge-offs, net of recoveries | (84 | ) |  | (17 | ) |  | (101 | ) |
| Provision charged to income statement | 74 |  |  | 29 |  |  | 103 |  |
| Balances as of February 2, 2018 | 81 |  |  | 64 |  |  | 145 |  |
| Charge-offs, net of recoveries | (78 | ) |  | (26 | ) |  | (104 | ) |
| Provision charged to income statement | 72 |  |  | 23 |  |  | 95 |  |
| Balances as of February 1, 2019 | 75 |  |  | 61 |  |  | 136 |  |
| Charge-offs, net of recoveries | (71 | ) |  | (23 | ) |  | (94 | ) |
| Provision charged to income statement | 66 |  |  | 41 |  |  | 107 |  |
| Balances as of January 31, 2020 | $ | 70 |  |  | $ | 79 |  |  | $ | 149 |  |

[0001571996-20-000017:notes:136]
Aging

[0001571996-20-000017:notes:137]
The following table presents the aging of the Company’s customer financing receivables, gross, including accrued interest, segregated by class, as of the dates indicated:

[0001571996-20-000017:notes:138]
|  | January 31, 2020 |  | February 1, 2019 |
|  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |
|  | (in millions) |
| Revolving — DPA | $ | 550 |  |  | $ | 51 |  |  | $ | 20 |  |  | $ | 621 |  |  | $ | 583 |  |  | $ | 53 |  |  | $ | 21 |  |  | $ | 657 |  |
| Revolving — DBC | 184 |  |  | 15 |  |  | 4 |  |  | 203 |  |  | 155 |  |  | 19 |  |  | 4 |  |  | 178 |  |
| Fixed-term — Consumer and Commercial | 8,005 |  |  | 373 |  |  | 108 |  |  | 8,486 |  |  | 6,282 |  |  | 878 |  |  | 89 |  |  | 7,249 |  |
| Total customer receivables, gross | $ | 8,739 |  |  | $ | 439 |  |  | $ | 132 |  |  | $ | 9,310 |  |  | $ | 7,020 |  |  | $ | 950 |  |  | $ | 114 |  |  | $ | 8,084 |  |

[0001571996-20-000017:notes:139]
Aging is likely to fluctuate as a result of the variability in volume of large transactions entered into over the period, and the administrative processes that accompany those transactions.  Aging is also impacted by the timing of Dell Technologies fiscal period end date, relative to calendar month-end customer payment due dates.  As a result of these factors, fluctuations in aging from period to period do not necessarily indicate a material change in the collectibility of the portfolio.

[0001571996-20-000017:notes:140]
Credit Quality

[0001571996-20-000017:notes:141]
The following table presents customer receivables, gross, including accrued interest, by credit quality indicator segregated by class, as of the dates indicated.  The categories shown in the table below segregate customer receivables based on the relative degrees of credit risk.  The credit quality indicators for DPA revolving accounts are measured primarily as of each quarter-end date, while all other indicators are generally updated on a periodic basis.

[0001571996-20-000017:notes:142]
|  | January 31, 2020 |  | February 1, 2019 |
|  | Higher |  | Mid |  | Lower |  | Total |  | Higher |  | Mid |  | Lower |  | Total |
|  | (in millions) |
| Revolving — DPA | $ | 137 |  |  | $ | 175 |  |  | $ | 309 |  |  | $ | 621 |  |  | $ | 128 |  |  | $ | 192 |  |  | $ | 337 |  |  | $ | 657 |  |
| Revolving — DBC | $ | 55 |  |  | $ | 63 |  |  | $ | 85 |  |  | $ | 203 |  |  | $ | 47 |  |  | $ | 54 |  |  | $ | 77 |  |  | $ | 178 |  |
| Fixed-term — Consumer and Commercial | $ | 5,042 |  |  | $ | 2,036 |  |  | $ | 1,408 |  |  | $ | 8,486 |  |  | $ | 3,980 |  |  | $ | 1,984 |  |  | $ | 1,285 |  |  | $ | 7,249 |  |

[0001571996-20-000017:notes:143]
For DPA revolving receivables shown in the table above, the Company makes credit decisions based on proprietary scorecards, which include the customer’s credit history, payment history, credit usage, and other credit agency-related elements.  The higher quality category includes prime accounts generally of a higher credit quality that are comparable to U.S. customer FICO scores of 720 or above.  The mid-category represents the mid-tier accounts that are comparable to U.S. customer FICO scores from 660 to 719.  The lower category is generally sub-prime and represents lower credit quality accounts that are comparable to U.S. customer FICO scores below 660.  For the DBC revolving receivables and fixed-term commercial receivables shown in the table above, an internal grading system is utilized that assigns a credit level score based on a number of considerations, including liquidity, operating performance, and industry outlook.  The grading criteria and classifications for the fixed-term products differ from those for the revolving products as loss experience varies between these product and customer groups.  The credit quality categories cannot be compared between the different classes as loss experience varies substantially between the classes.

[0001571996-20-000017:notes:144]
Leases

[0001571996-20-000017:notes:145]
Interest income on sales-type lease receivables was $259 million for the fiscal year ended January 31, 2020.

[0001571996-20-000017:notes:146]
The following table presents the net revenue, cost of net revenue, and gross margin recognized at the commencement date of sales-type leases for the period indicated:

[0001571996-20-000017:notes:147]
|  | Fiscal Year Ended |
|  | January 31, 2020 |
|  | (in millions) |
| Net revenue — products | $ | 770 |  |
| Cost of net revenue — products | 582 |  |
| Gross margin — products | $ | 188 |  |

[0001571996-20-000017:notes:148]
The following table presents the future maturity of the Company’s fixed-term customer leases and associated financing payments, and reconciles the undiscounted cash flows to the customer receivables, gross recognized on the Consolidated Statements of Financial Position as of the date indicated:

[0001571996-20-000017:notes:149]
|  | January 31, 2020 |
| Fiscal Years | (in millions) |
| Fiscal 2021 | $ | 2,615 |  |
| Fiscal 2022 | 1,705 |  |
| Fiscal 2023 | 901 |  |
| Fiscal 2024 | 313 |  |
| Fiscal 2025 and beyond | 93 |  |
| Total undiscounted cash flows | 5,627 |  |
| Fixed-term loans | 3,440 |  |
| Revolving loans | 824 |  |
| Less: unearned income | (581 | ) |
| Total customer receivables, gross | $ | 9,310 |  |

[0001571996-20-000017:notes:150]
Disclosure related to periods prior to adoption of the new lease standard — Future maturities of minimum lease and associated financing payments as of February 1, 2019 were as follows: $2.6 billion in Fiscal 2020; $1.7 billion in Fiscal 2021; $0.9 billion in Fiscal 2022; $0.3 billion in Fiscal 2023; and $0.1 billion in Fiscal 2024 and beyond.  Future maturities and associated financing payments referenced herein represent the aggregate payments under the customer lease contract.

[0001571996-20-000017:notes:151]
Operating Leases

[0001571996-20-000017:notes:152]
As of February 1, 2019, the Company’s equipment under operating lease, net was immaterial.

[0001571996-20-000017:notes:153]
Operating lease income relating to lease payments was $169 million for the fiscal year ended January 31, 2020.  Depreciation expense was $115 million for the fiscal year ended January 31, 2020.

[0001571996-20-000017:notes:154]
The following table presents the future payments to be received by the Company as lessor in operating lease contracts as of the date indicated:

[0001571996-20-000017:notes:155]
|  | January 31, 2020 |
| Fiscal Years | (in millions) |
| Fiscal 2021 | $ | 333 |  |
| Fiscal 2022 | 313 |  |
| Fiscal 2023 | 211 |  |
| Fiscal 2024 | 25 |  |
| Fiscal 2025 and beyond | 5 |  |
| Total | $ | 887 |  |

[0001571996-20-000017:notes:156]
DFS Debt

[0001571996-20-000017:notes:157]
The Company maintains programs that facilitate the funding of leases, loans, and other alternative payment structures in the capital markets.  The majority of  DFS debt is non-recourse to Dell Technologies and represents borrowings under securitization programs and structured financing programs, for which the Company’s risk of loss is limited to transferred loan and lease payments and associated equipment.  The following table presents DFS debt as of the dates indicated.  The table excludes the allocated portion of the Company’s other borrowings, which represents the additional amount considered to fund the DFS business.

[0001571996-20-000017:notes:158]
|  | January 31, 2020 |  | February 1, 2019 |
| DFS debt | (in millions) |
| DFS U.S. debt: |  |  |  |
| Securitization facilities | $ | 2,606 |  |  | $ | 1,914 |  |
| Fixed-term securitization offerings | 2,593 |  |  | 2,303 |  |
| Other | 141 |  |  | 223 |  |
| Total DFS U.S. debt | 5,340 |  |  | 4,440 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 743 |  |  | 584 |  |
| Other borrowings | 931 |  |  | 708 |  |
| Note payable | 200 |  |  | 197 |  |
| Dell Bank Senior Unsecured Eurobonds | 551 |  |  | — |  |
| Total DFS international debt | 2,425 |  |  | 1,489 |  |
| Total DFS debt | $ | 7,765 |  |  | $ | 5,929 |  |
| Total short-term DFS debt | $ | 4,152 |  |  | $ | 3,113 |  |
| Total long-term DFS debt | $ | 3,613 |  |  | $ | 2,816 |  |

[0001571996-20-000017:notes:159]
DFS U.S. Debt

[0001571996-20-000017:notes:160]
Securitization Facilities — The Company maintains separate securitization facilities in the United States for fixed-term leases and loans and for revolving loans.  This debt is collateralized solely by the U.S. loan and lease payments and associated equipment in the facilities.  The debt has a variable interest rate and the duration of the debt is based on the terms of the underlying loan and lease payments.  As of January 31, 2020, the total debt capacity related to the U.S. securitization facilities was $4.0 billion.  The Company enters into interest swap agreements to effectively convert a portion of its securitization debt from a floating rate to a fixed rate.  See Note 7 of the Notes to the Consolidated Financial Statements for additional information about interest rate swaps.

[0001571996-20-000017:notes:161]
The Company’s U.S. securitization facility for revolving loans is effective through June 25, 2022.  The Company’s two U.S. securitization facilities for fixed-term leases and loans are effective through August 22, 2021 and July 26, 2022, respectively.

[0001571996-20-000017:notes:162]
The securitization facilities contain standard structural features related to the performance of the securitized receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the facility, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of January 31, 2020, these criteria were met.

[0001571996-20-000017:notes:163]
Fixed-Term Securitization Offerings — The Company periodically issues asset-backed debt securities under fixed-term securitization programs to private investors.  The asset-backed debt securities are collateralized solely by the U.S. fixed-term leases and loans in the offerings, which are held by Special Purpose Entities (“SPEs”), as discussed below.  The interest rate on these securities is fixed and ranges from 1.91% to 3.97% per annum, and the duration of these securities is based on the terms of the underlying lease and loan payment streams.

[0001571996-20-000017:notes:164]
DFS International Debt

[0001571996-20-000017:notes:165]
Securitization Facility — The Company maintains a securitization facility in Europe for fixed-term leases and loans.  This facility is effective through December 21, 2020 and had a total debt capacity of $883 million as of January 31, 2020.

[0001571996-20-000017:notes:166]
The securitization facility contains standard structural features related to the performance of the securitized receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the program, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of January 31, 2020, these criteria were met.

[0001571996-20-000017:notes:167]
Other Borrowings — In connection with the Company’s international financing operations, the Company has entered into revolving structured financing debt programs related to its fixed-term lease and loan products sold in Canada, Europe, Australia, and New Zealand.  The Canadian facility, which is collateralized solely by Canadian loan and lease payments and associated equipment, had a total debt capacity of $284 million as of January 31, 2020, and is effective through January 16, 2023.  The European facility, which is collateralized solely by European loan and lease payments and associated equipment, had a total debt capacity of $662 million as of January 31, 2020, and is effective through June 14, 2022.  The Australia and New Zealand facility, which is collateralized solely by Australia and New Zealand loan and lease payments and associated equipment, had a total debt capacity of $202 million as of January 31, 2020, and is effective through December 20, 2021.

[0001571996-20-000017:notes:168]
Note Payable — On November 27, 2017, the Company entered into an unsecured credit agreement to fund receivables in Mexico.  As of January 31, 2020, the aggregate principal amount of the note payable is $200 million.  The note bears interest at either the applicable London Interbank Offered Rate (“LIBOR”) plus 2.25%, for the borrowings denominated in U.S. Dollars, or the Mexican Interbank Equilibrium Interest Rate (“TIIE”) plus 2.00%, for the borrowings denominated in Mexican pesos.  The note will mature on December 1, 2020.  Although the note is unsecured, the Company manages the note in the same manner as its structured financing programs, so that the collections from loan and lease payments and associated equipment in Mexico are used to pay down principal and interest of the note.

[0001571996-20-000017:notes:169]
Dell Bank Senior Unsecured Eurobonds  — On October 17, 2019, Dell Bank International D.A.C. issued 500 million Euro of 0.625% senior unsecured three year eurobonds due October 2022.  The issuance of the senior unsecured eurobonds supports the expansion of the financing operations in Europe.

[0001571996-20-000017:notes:170]
Variable Interest Entities

[0001571996-20-000017:notes:171]
In connection with the securitization facilities and offerings discussed above, the Company transfers certain U.S. and European loan and lease payments and associated equipment to SPEs that meet the definition of a Variable Interest Entity (“VIE”) and are consolidated, along with the associated debt detailed above, into the Consolidated Financial Statements, as the Company is the primary beneficiary of those VIEs.  The SPEs are bankruptcy-remote legal entities with separate assets and liabilities.  The purpose of the SPEs is to facilitate the funding of customer loan and lease payments and associated equipment in the capital markets.

[0001571996-20-000017:notes:172]
The following table presents financing receivables and equipment under operating leases, net held by the consolidated VIEs as of the dates indicated:

[0001571996-20-000017:notes:173]
|  | January 31, 2020 |  | February 1, 2019 |
|  | (in millions) |
| Assets held by consolidated VIEs, net: |  |  |  |  |  |
| Short-term, net | $ | 3,316 |  |  | $ | 2,940 |  |
| Long-term, net | 3,348 |  |  | 2,508 |  |
| Assets held by consolidated VIEs, net | $ | 6,664 |  |  | $ | 5,448 |  |

[0001571996-20-000017:notes:174]
Loan and lease payments and associated equipment transferred via securitization through SPEs were $5.4 billion and $4.6 billion for the fiscal years ended January 31, 2020 and February 1, 2019, respectively.

[0001571996-20-000017:notes:175]
Some of the SPEs have entered into financing arrangements with multi-seller conduits that, in turn, issue asset-backed debt securities in the capital markets.  The DFS debt outstanding, which is collateralized by the loan and lease payments and associated equipment held by the consolidated VIEs, was $5.9 billion and $4.8 billion as of January 31, 2020 and February 1, 2019, respectively.  The Company’s risk of loss related to securitized receivables is limited to the amount by which the Company’s right to receive collections for assets securitized exceeds the amount required to pay interest, principal, and fees and expenses related to the asset-backed securities.  The Company provides credit enhancement to the securitization in the form of over-collateralization.

[0001571996-20-000017:notes:176]
Customer Receivable Sales

[0001571996-20-000017:notes:177]
To manage certain concentrations of customer credit exposure, the Company may sell selected fixed-term customer receivables to unrelated third parties on a periodic basis, without recourse.  The amount of customer receivables sold for this purpose was $538 million, $949 million, and $683 million for the fiscal years ended January 31, 2020, February 1, 2019, and February 2, 2018, respectively.  The Company’s continuing involvement in the above mentioned customer receivables is primarily limited to servicing arrangements.


## us-gaap:ScheduleOfDebtTableTextBlock

[0001571996-20-000017:notes:178]
The majority of  DFS debt is non-recourse to Dell Technologies and represents borrowings under securitization programs and structured financing programs, for which the Company’s risk of loss is limited to transferred loan and lease payments and associated equipment.  The following table presents DFS debt as of the dates indicated.  The table excludes the allocated portion of the Company’s other borrowings, which represents the additional amount considered to fund the DFS business.

[0001571996-20-000017:notes:179]
The following table summarizes the Company’s outstanding debt as of the dates indicated:

[0001571996-20-000017:notes:180]
|  | January 31, 2020 |  | February 1, 2019 |
|  | (in millions) |
| Secured Debt |  |  |  |
| Senior Secured Credit Facilities: |  |  |  |
| Term Loan B Facility due September 2023 | $ | — |  |  | $ | 4,938 |  |
| 3.65% Term Loan B-1 Facility due September 2025 | 4,738 |  |  | — |  |
| Term Loan A-2 Facility due September 2021 | — |  |  | 4,116 |  |
| 3.40% Term Loan A-4 Facility due December 2023 | 679 |  |  | 1,650 |  |
| Term Loan A-5 Facility due December 2019 | — |  |  | 2,016 |  |
| 3.41% Term Loan A-6 Facility due March 2024 | 3,497 |  |  | — |  |
| First Lien Notes: |  |  |  |
| 3.48% due June 2019 | — |  |  | 3,750 |  |
| 4.42% due June 2021 | 4,500 |  |  | 4,500 |  |
| 5.45% due June 2023 | 3,750 |  |  | 3,750 |  |
| 4.00% due July 2024 | 1,000 |  |  | — |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 4.90% due October 2026 | 1,750 |  |  | — |  |
| 5.30% due October 2029 | 1,750 |  |  | — |  |
| 8.10% due July 2036 | 1,500 |  |  | 1,500 |  |
| 8.35% due July 2046 | 2,000 |  |  | 2,000 |  |
| Unsecured Debt |  |  |  |
| Unsecured Notes and Debentures: |  |  |  |
| 5.875% due June 2019 | — |  |  | 600 |  |
| 4.625% due April 2021 | 400 |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| Senior Notes: |  |  |  |
| 5.875% due June 2021 | 1,075 |  |  | 1,625 |  |
| 7.125% due June 2024 | 1,625 |  |  | 1,625 |  |
| EMC Notes: |  |  |  |
| 2.650% due June 2020 | 600 |  |  | 2,000 |  |
| 3.375% due June 2023 | 1,000 |  |  | 1,000 |  |
| Debt of Public Subsidiary |  |  |  |
| VMware Notes: |  |  |  |
| 2.30% due August 2020 | 1,250 |  |  | 1,250 |  |
| 2.95% due August 2022 | 1,500 |  |  | 1,500 |  |
| 3.90% due August 2027 | 1,250 |  |  | 1,250 |  |
| VMware Term Loan Facility | 1,500 |  |  | — |  |
| DFS Debt (Note 4) | 7,765 |  |  | 5,929 |  |
| Other |  |  |  |
| 4.03% Margin Loan Facility due April 2022 | 4,000 |  |  | 3,350 |  |
| Other | 84 |  |  | 38 |  |
| Total debt, principal amount | $ | 52,665 |  |  | $ | 54,239 |  |

[0001571996-20-000017:notes:181]
|  | January 31, 2020 |  | February 1, 2019 |
|  | (in millions) |
| Total debt, principal amount | $ | 52,665 |  |  | $ | 54,239 |  |
| Unamortized discount, net of unamortized premium | (241 | ) |  | (271 | ) |
| Debt issuance costs | (368 | ) |  | (447 | ) |
| Total debt, carrying value | $ | 52,056 |  |  | $ | 53,521 |  |
| Total short-term debt, carrying value | $ | 7,737 |  |  | $ | 4,320 |  |
| Total long-term debt, carrying value | $ | 44,319 |  |  | $ | 49,201 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0001571996-20-000017:notes:182]
NOTE 5 — LEASES

[0001571996-20-000017:notes:183]
The Company enters into leasing transactions in which the Company is the lessee.  These lease contracts are typically classified as operating leases.  The Company’s lease contracts are generally for office buildings used to conduct its business, and the determination of whether such contracts contain leases generally does not require significant estimates or judgments.  The Company also leases certain global logistics warehouses, employee vehicles, and equipment.  As of January 31, 2020, the remaining terms of the Company’s leases range from less than one month to 27 years.

[0001571996-20-000017:notes:184]
The Company also enters into leasing transactions in which the Company is the lessor, primarily through customer financing arrangements offered through DFS.  DFS originates leases that are primarily classified as either sales-type leases or operating leases.  See Note 4 of the Notes to the Consolidated Financial Statements for more information on the DFS lease portfolio and related lease disclosures.

[0001571996-20-000017:notes:185]
In adopting the new lease standard discussed in Note 2 of the Notes to the Consolidated Financial Statements, the Company elected to apply a transition method that does not require the retrospective application to periods prior to adoption.  Financial information associated with the Company’s leases in which the Company is the lessee is contained in this Note 5.  As of January 31, 2020, there were no material finance leases for which the Company was a lessee.

[0001571996-20-000017:notes:186]
The following table presents components of lease costs included in the Consolidated Statements of Income (Loss) for the period indicated:

[0001571996-20-000017:notes:187]
|  | Fiscal Year Ended |
|  | January 31, 2020 |
|  | (in millions) |
| Operating lease costs | $ | 510 |  |
| Variable costs | 161 |  |
| Total lease costs | $ | 671 |  |

[0001571996-20-000017:notes:188]
During the fiscal year ended January 31, 2020, sublease income, finance lease costs, and short-term lease costs were immaterial.

[0001571996-20-000017:notes:189]
The following table presents supplemental information related to operating leases included in the Consolidated Statements of Financial Position as of the date indicated:

[0001571996-20-000017:notes:190]
|  | Classification |  | January 31, 2020 |
|  |  |  | (in millions, except for term and discount rate) |
| Operating lease ROU assets | Other non-current assets |  | $ | 1,780 |  |
| Current operating lease liabilities | Accrued and other current liabilities |  | $ | 432 |  |
| Non-current operating lease liabilities | Other non-current liabilities |  | 1,360 |  |
| Total operating lease liabilities |  |  | $ | 1,792 |  |
| Weighted-average remaining lease term (in years) |  |  | 8.57 |  |
| Weighted-average discount rate |  |  | 3.81 | % |

[0001571996-20-000017:notes:191]
The following table presents supplemental cash flow information related to leases for the period indicated:

[0001571996-20-000017:notes:192]
|  | Fiscal Year Ended |
|  | January 31, 2020 |
|  | (in millions) |
| Cash paid for amounts included in the measurement of lease liabilities — operating cash outflows from operating leases | $ | 501 |  |
| ROU assets obtained in exchange for new operating lease liabilities | $ | 630 |  |

[0001571996-20-000017:notes:193]
The following table presents the future maturity of the Company’s operating lease liabilities under non-cancelable leases and reconciles the undiscounted cash flows for these leases to the lease liability recognized on the Consolidated Statements of Financial Position as of the date indicated:

[0001571996-20-000017:notes:194]
|  | January 31, 2020 |
| Fiscal Years | (in millions) |
| Fiscal 2021 | $ | 458 |  |
| Fiscal 2022 | 380 |  |
| Fiscal 2023 | 292 |  |
| Fiscal 2024 | 201 |  |
| Fiscal 2025 | 131 |  |
| Thereafter | 677 |  |
| Total lease payments | $ | 2,139 |  |
| Less: Imputed interest | (347 | ) |
| Total | $ | 1,792 |  |
| Current operating lease liabilities | $ | 432 |  |
| Non-current operating lease liabilities | $ | 1,360 |  |

[0001571996-20-000017:notes:195]
The amount of future lease commitments after Fiscal 2025 is primarily for the ground lease on VMware, Inc.’s Palo Alto, California headquarter facilities, which expires in Fiscal 2047.

[0001571996-20-000017:notes:196]
As of January 31, 2020, the Company has additional operating leases that have not yet commenced of $681 million.  These operating leases will commence during Fiscal 2021 with lease terms of one year to 16 years.

[0001571996-20-000017:notes:197]
Disclosure related to periods prior to adoption of the new lease standard

[0001571996-20-000017:notes:198]
Prior to the adoption of the new lease standard, the Company had the following future minimum lease payments under non-cancelable leases:

[0001571996-20-000017:notes:199]
|  | February 1, 2019 |
| Fiscal Years | (in millions) |
| Fiscal 2020 | $ | 371 |  |
| Fiscal 2021 | 314 |  |
| Fiscal 2022 | 240 |  |
| Fiscal 2023 | 175 |  |
| Fiscal 2024 | 113 |  |
| Thereafter | 643 |  |
| Total | $ | 1,856 |  |


## us-gaap:DebtDisclosureTextBlock

[0001571996-20-000017:notes:200]
NOTE 6 — DEBT

[0001571996-20-000017:notes:201]
During the fiscal year ended January 31, 2020, the Company repaid $1.4 billion principal amount of its EMC 2.650% unsecured notes due June 2020, $550 million principal amount of its 5.875% senior unsecured notes due June 2021, $600 million principal amount of its 5.875% senior unsecured notes due June 2019, $950 million principal amount of its Term Loan A-4 Facility, and approximately $193 million of principal amortization under its term loan facilities.  As described below under “Refinancing Transactions,” the Company also repaid $162.5 million principal amount as part of the Term Loan B Facility refinancing and the remaining principal amount of approximately $1,277 million of its Term Loan A-2 Facility in connection with the First Lien Notes issued on March 20, 2019.

[0001571996-20-000017:notes:202]
Additionally, during the fiscal year ended January 31, 2020, the Company issued an additional $1.8 billion, net, in DFS debt to support the expansion of its financing receivables portfolio.  See Note 4 of the Notes to the Consolidated Financial Statements for more information about DFS debt.

[0001571996-20-000017:notes:203]
During the fiscal year ended February 1, 2019, the Company repaid $3.0 billion principal amount of its unsecured notes and $1.5 billion principal amount of its term loan facilities, which included approximately $0.3 billion of amortization.  The Term Loan A-3 Facility was fully repaid during the three months ended November 2, 2018.  Additionally, during the fiscal year ended February 1, 2019, the Company issued an additional $1.2 billion, net, in DFS debt to support the expansion of its financing receivables portfolio.

[0001571996-20-000017:notes:204]
Refinancing Transactions

[0001571996-20-000017:notes:205]
In connection with the Class V transaction described in Note 14 of the Notes to the Consolidated Financial Statements, on December 20, 2018, the Company entered into an amendment to the credit agreement for the Senior Secured Credit Facilities, described below, which included (a) a new senior secured Term Loan A-4 Facility under its Senior Secured Credit Facilities consisting of $1.7 billion term A-4 loans, (b) a new senior secured Term Loan A-5 Facility under the Senior Secured Credit Facilities consisting of $2.0 billion term A-5 loans, (c) $1.4 billion in incremental loans under the Margin Loan Facility, and (d) an increase in the aggregate revolving commitments available under the Revolving Credit Facility to $4.5 billion.  See below for additional information regarding the Senior Secured Credit Facilities, the Margin Loan Facility, and the Revolving Credit Facility.

[0001571996-20-000017:notes:206]
On March 7, 2019, the Company amended the Margin Loan Facility agreement to increase the aggregate principal amount of borrowings under the Margin Loan Facility by $650 million.  See below for additional information regarding the Margin Loan Facility.

[0001571996-20-000017:notes:207]
On March 13, 2019, the Company entered into an amendment to the credit agreement for the Senior Secured Credit Facilities to obtain a new senior secured Term Loan A-6 Facility in order to refinance the $5 billion aggregate principal amount of debt incurred in connection with the Class V transaction described in Note 14 of the Notes to the Consolidated Financial Statements.  The Term Loan A-6 Facility aggregate principal amount of $3,634 million matures on March 13, 2024, of which $2,839 million aggregate principal amount represents the amounts outstanding under the Term Loan A-2 Facility that rolled over into the new facility.  The remaining principal amount outstanding under the Term Loan A-2 Facility was subsequently repaid in full during the fiscal year ended January 31, 2020, partially with proceeds from a private offering of First Lien Notes described below.

[0001571996-20-000017:notes:208]
On March 20, 2019, Dell International L.L.C. and EMC Corporation, both of which are wholly-owned subsidiaries of Dell Technologies Inc., completed a private offering of multiple series of First Lien Notes in an aggregate principal amount of $4.5 billion.  The principal amount, interest rate, and maturity of each series of such First Lien Notes were $1,000 million of 4.00% First Lien Notes due July 15, 2024, $1,750 million of 4.90% First Lien Notes due October 1, 2026, and $1,750 million of 5.30% First Lien Notes due October 1, 2029.  See below for additional information regarding the First Lien Notes.

[0001571996-20-000017:notes:209]
A majority of the proceeds from the First Lien Notes issued on March 20, 2019 was used to repay all of the outstanding $3,750 million principal amount of the 3.48% First Lien Notes due June 2019.  In addition, proceeds of approximately $800 million of borrowings under the new Term Loan A-6 Facility, the proceeds of the $650 million increase in the Margin Loan Facility, and a portion of the proceeds from the 2019 First Lien Notes were used to repay all $2,016 million of outstanding amounts under the Term Loan A-5 Facility due December 2019.  The remaining proceeds available from the 2019 First Lien Notes were used to repay a portion of outstanding amounts under the Term Loan A-2 Facility as described above, and to pay related premiums, accrued interest, fees, and expenses.

[0001571996-20-000017:notes:210]
On September 19, 2019, the Company entered into a sixth refinancing amendment to the Senior Secured Credit Agreement (the “Sixth Refinancing Amendment”) to refinance the Term Loan B Facility due September 2023 with a new term loan B facility consisting of an aggregate principal amount of $4,750 million refinancing term B-1 loans maturing on September 19, 2025 (the “Term Loan B-1 Facility”).  The Company used the proceeds from the Term Loan B-1 Facility, together with other available funds, to repay $4,913 million of outstanding amounts under the Term Loan B Facility due September 2023 and to pay related accrued interest, fees and expenses.

[0001571996-20-000017:notes:211]
The refinancing and amendments were evaluated in accordance with FASB ASC 470, “Debt-Modifications and Extinguishments.”  The amendment to the Margin Loan Facility agreement on March 7, 2019, the term debt refinancing on March 13, 2019, and the Term Loan B Facility refinancing on September 19, 2019 were accounted for as modifications for all existing lenders and as new issuances for new lenders.  The First Lien Notes issued on March 20, 2019 were accounted for as new issuances for all lenders, and repayment of the Company’s outstanding amounts under the Term Loan A-5 Facility was accounted for as an extinguishment.

[0001571996-20-000017:notes:212]
In connection with the refinancing and amendments described above, the Company capitalized $80.4 million in new fees paid to creditors as a result of the modifications and new issuances, and also recognized expenses of $33.8 million in write-offs of unamortized costs and $12.2 million in new third-party costs during the fiscal year ended January 31, 2020.

[0001571996-20-000017:notes:213]
Secured Debt

[0001571996-20-000017:notes:214]
Senior Secured Credit Facilities — The Company has entered into a credit agreement that provides for senior secured credit facilities (the “Senior Secured Credit Facilities”) comprising (a) term loan facilities and (b) a senior secured Revolving Credit Facility, which includes capacity for up to $0.5 billion of letters of credit and for borrowings of up to $0.4 billion under swing-line loans.

[0001571996-20-000017:notes:215]
As of January 31, 2020, available borrowings under the Revolving Credit Facility totaled $4.5 billion.  The Senior Secured Credit Facilities provide that the borrowers have the right at any time, subject to customary conditions, to request incremental term loans or incremental revolving commitments.

[0001571996-20-000017:notes:216]
Borrowings under the Senior Secured Credit Facilities bear interest at a rate per annum equal to an applicable margin, plus, at the borrowers’ option, either (a) a base rate, or (b) a London Interbank Offered Rate (“LIBOR”).  The Term Loan B-1 Facility bears interest at LIBOR plus an applicable margin of 2.00% or a base rate plus an applicable margin of 1.00%.  The Term Loan A-4 Facility and the Term Loan A-6 Facility bear interest at LIBOR plus an applicable margin ranging from 1.25% to 2.00% or a base rate plus an applicable margin ranging from 0.25% to 1.00%.  Interest is payable, in the case of loans bearing interest based on LIBOR, at the end of each interest period (but at least every three months), in arrears and, in the case of loans bearing interest based on the base rate, quarterly in arrears.

[0001571996-20-000017:notes:217]
The Term Loan B-1 Facility amortizes in equal quarterly installments in aggregate annual amounts equal to 1% of the original principal amount.  The Term Loan A-4 Facility amortizes in equal quarterly installments in aggregate annual amounts equal to 5% of the original principal in each of the first four years after the facility closing date of December 20, 2018, and 80% of the original principal amount in the fifth year after December 20, 2018.  The Term Loan A-6 Facility amortizes in equal quarterly installments in aggregate annual amounts equal to 5% of the original principal amount in each of the first four years after the facility closing date of March 13, 2019, and 80% of the original principal amount in the fifth year after March 13, 2019.  The Revolving Credit Facility has no amortization.

[0001571996-20-000017:notes:218]
The borrowers may voluntarily repay outstanding loans under the term loan facilities and the Revolving Credit Facility at any time without premium or penalty, other than customary “breakage” costs.

[0001571996-20-000017:notes:219]
All obligations of the borrowers under the Senior Secured Credit Facilities and certain swap agreements, cash management arrangements, and certain letters of credit provided by any lender or agent party to the Senior Secured Credit Facilities or any of its affiliates and certain other persons are secured by (a) a first-priority security interest in certain tangible and intangible assets of the borrowers and the guarantors and (b) a first-priority pledge of 100% of the capital stock of the borrowers, Dell Inc., a wholly‑owned subsidiary of the Company (“Dell”), and each wholly-owned material restricted subsidiary of the borrowers and the guarantors, in each case subject to certain thresholds, exceptions, and permitted liens.

[0001571996-20-000017:notes:220]
First Lien Notes — The senior secured notes (collectively, the “First Lien Notes”) were issued on June 1, 2016 and March 20, 2019 in an aggregate principal amount of $20.0 billion and $4.5 billion, respectively.  As discussed above, during the three months ended May 3, 2019, the Company used a portion of the proceeds from the First Lien Notes issued on March 20, 2019 to repay all of the outstanding $3,750 million principal amount of its 3.48% First Lien Notes due June 2019.  Interest on these borrowings is payable semiannually.  The First Lien Notes are secured on a pari passu basis with the Senior Secured Credit Facilities, on a first-priority basis by substantially all of the tangible and intangible assets of the issuers and guarantors that secure obligations under the Senior Secured Credit Facilities, including pledges of all capital stock of the issuers, Dell, and certain wholly-owned material subsidiaries of the issuers and the guarantors, subject to certain exceptions.

[0001571996-20-000017:notes:221]
The Company has agreed to use commercially reasonable efforts to register with the SEC notes having terms substantially identical to the terms of the First Lien Notes as part of an offer to exchange such registered notes for the First Lien Notes.  The Company will be obligated to pay additional interest on the First Lien Notes if it fails to consummate such an exchange offer within five years after the closing date of the EMC merger transaction, in the case of the First Lien Notes issued on June 1, 2016, and within five years after their issue date, in the case of the First Lien Notes issued on March 20, 2019.

[0001571996-20-000017:notes:222]
China Revolving Credit Facility — During the fiscal year ended January 31, 2020, the Company renewed its credit agreement (the “China Revolving Credit Facility”) with a bank lender.  The new terms provided an uncommitted line, with no change to the aggregate principal amount not to exceed $500 million at an interest rate of LIBOR plus 0.6% per annum.  As of January 31, 2020, no amounts were outstanding under the facility, which expires on February 26, 2020.  Unaudited update: Subsequent to the fiscal year ended January 31, 2020, the China Revolving Credit Facility was terminated as of its expiration date.

[0001571996-20-000017:notes:223]
Unsecured Debt

[0001571996-20-000017:notes:224]
Unsecured Notes and Debentures — The Company has outstanding unsecured notes and debentures (collectively, the “Unsecured Notes and Debentures”) that were issued by Dell prior to the acquisition of Dell by Dell Technologies Inc. in the going-private transaction that closed in October 2013.  Interest on these borrowings is payable semiannually.

[0001571996-20-000017:notes:225]
Senior Notes — The senior unsecured notes (collectively, the “Senior Notes”) were issued on June 22, 2016 in an aggregate principal amount of $3.25 billion.  Interest on these borrowings is payable semiannually.

[0001571996-20-000017:notes:226]
EMC Notes — On September 7, 2016, EMC had outstanding $2.5 billion aggregate principal amount of its 1.875% Notes due June 2018, which the Company fully repaid during the three months ended August 3, 2018, $2.0 billion aggregate principal amount of its 2.650% Notes due June 2020, and $1.0 billion aggregate principal amount of its 3.375% Notes due June 2023 (collectively, the “EMC Notes”).  Interest on these borrowings is payable semiannually.

[0001571996-20-000017:notes:227]
VMware Notes — On August 21, 2017, VMware, Inc. completed a public offering of unsecured senior notes in the aggregate amount of $4.0 billion, consisting of outstanding principal due on the following dates: $1.25 billion due August 21, 2020, $1.50 billion due August 21, 2022, and $1.25 billion due August 21, 2027 (collectively, the “VMware Notes”).  The VMware Notes bear interest, payable semiannually, at annual rates of 2.30%, 2.95%, and 3.90%, respectively.  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.

[0001571996-20-000017:notes:228]
VMware Revolving Credit Facility — On September 12, 2017, VMware, Inc. entered into an unsecured credit agreement, establishing a revolving credit facility (the “VMware Revolving Credit Facility”), with a syndicate of lenders that provides the company with a borrowing capacity of up to $1.0 billion which may be used for VMware, Inc. general corporate purposes.  Commitments under the VMware Revolving Credit Facility are available for a period of five years, which may be extended, subject to the satisfaction of certain conditions, by up to two one year periods.  The credit agreement contains certain representations, warranties, and covenants.  Commitment fees, interest rates, and other terms of borrowing under the VMware Revolving Credit Facility may vary based on VMware, Inc.’s external credit ratings.  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.  As of January 31, 2020, there were no outstanding borrowings under the VMware Revolving Credit Facility.

[0001571996-20-000017:notes:229]
VMware Term Loan Facility — On September 26, 2019, VMware, Inc. entered into a senior unsecured term loan facility (the “VMware Term Loan Facility”) with a syndicate of lenders that provides VMware, Inc. with a borrowing capacity of up to $2.0 billion for VMware, Inc. general corporate purposes.  VMware, Inc. may borrow against the VMware Term Loan Facility two times up to its borrowing capacity of $2.0 billion until February 7, 2020.  The VMware Term Loan Facility matures on the 364th day following the initial funding under the facility.  The VMware Term Loan Facility bears interest at LIBOR plus 0.75% to 1.25%, or an alternative base rate plus 0.00% to 0.25%, depending on VMware Inc.’s external credit ratings.  During the fiscal year ended January 31, 2020, VMware, Inc. drew down $3.4 billion and repaid $1.9 billion.  As of January 31, 2020, the outstanding borrowings under the VMware Term Loan Facility were $1.5 billion, with no remaining amount available for additional borrowings.  The VMware Term Loan Facility contains certain representations, warranties, and covenants.  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.

[0001571996-20-000017:notes:230]
See Note 4 and Note 7 of the Notes to the Consolidated Financial Statements, respectively, for discussion of DFS debt and the interest rate swap agreements that hedge a portion of that debt.

[0001571996-20-000017:notes:231]
Margin Loan Facility — On April 12, 2017, the Company entered into the Margin Loan Facility in an aggregate principal amount of $2.0 billion.  In connection with the Class V transaction, on December 20, 2018, the Company amended the Margin Loan Facility to increase the aggregate principal amount of the facility to $3.35 billion.  In connection with obtaining the Term Loan A-6 Facility, the Company increased the aggregate principal amount of the Margin Loan Facility to $4.0 billion.  VMW Holdco LLC, a wholly-owned subsidiary of EMC, is the borrower under the Margin Loan Facility, which is secured by 60 million shares of Class B common stock of VMware, Inc. and 20 million shares of Class A common stock of VMware, Inc.  Loans under the Margin Loan Facility bear interest at a rate per annum payable, at the borrower’s option, either at (a) a base rate plus 1.25% or (b) a LIBOR-based rate plus 2.25%.  Interest under the Margin Loan Facility is payable quarterly.  The Margin Loan Facility will mature in April 2022.  The borrower may voluntarily repay outstanding loans under the Margin Loan Facility at any time without premium or penalty, other than customary “breakage” costs, subject to certain minimum threshold amounts for prepayment.

[0001571996-20-000017:notes:232]
Pivotal Revolving Credit Facility — On September 7, 2017, Pivotal entered into a credit agreement (the “Pivotal Revolving Credit Facility”) that provided for a senior secured revolving loan facility in an aggregate principal amount not to exceed $100 million.  The credit facility contained customary representations, warranties, and covenants, including financial covenants.  During the fiscal year ended January 31, 2020, the Pivotal Revolving Credit Facility was terminated.

[0001571996-20-000017:notes:233]
Aggregate Future Maturities

[0001571996-20-000017:notes:234]
As of January 31, 2020, aggregate future maturities of the Company’s debt were as follows:

[0001571996-20-000017:notes:235]
|  | Maturities by Fiscal Year |
|  | 2021 |  | 2022 |  | 2023 |  | 2024 |  | 2025 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Secured Credit Facilities and First Lien Notes | $ | 229 |  |  | $ | 4,672 |  |  | $ | 286 |  |  | $ | 6,702 |  |  | $ | 1,775 |  |  | $ | 16,000 |  |  | $ | 29,664 |  |
| Unsecured Notes and Debentures | — |  |  | 400 |  |  | — |  |  | — |  |  | — |  |  | 952 |  |  | 1,352 |  |
| Senior Notes and EMC Notes | 600 |  |  | 1,075 |  |  | — |  |  | 1,000 |  |  | 1,625 |  |  | — |  |  | 4,300 |  |
| VMware Notes | 2,750 |  |  | — |  |  | 1,500 |  |  | — |  |  | — |  |  | 1,250 |  |  | 5,500 |  |
| DFS Debt | 4,154 |  |  | 1,894 |  |  | 1,622 |  |  | 85 |  |  | 10 |  |  | — |  |  | 7,765 |  |
| Margin Loan Facility | — |  |  | — |  |  | 4,000 |  |  | — |  |  | — |  |  | — |  |  | 4,000 |  |
| Other | 14 |  |  | 11 |  |  | 7 |  |  | 8 |  |  | 7 |  |  | 37 |  |  | 84 |  |
| Total maturities, principal amount | 7,747 |  |  | 8,052 |  |  | 7,415 |  |  | 7,795 |  |  | 3,417 |  |  | 18,239 |  |  | 52,665 |  |
| Associated carrying value adjustments | (10 | ) |  | (52 | ) |  | (24 | ) |  | (50 | ) |  | (96 | ) |  | (377 | ) |  | (609 | ) |
| Total maturities, carrying value amount | $ | 7,737 |  |  | $ | 8,000 |  |  | $ | 7,391 |  |  | $ | 7,745 |  |  | $ | 3,321 |  |  | $ | 17,862 |  |  | $ | 52,056 |  |

[0001571996-20-000017:notes:236]
Covenants and Unrestricted Net Assets — The credit agreement for the Senior Secured Credit Facilities contains customary negative covenants that generally limit the ability of Denali Intermediate Inc., a wholly-owned subsidiary of Dell Technologies (“Dell Intermediate”), Dell, and Dell’s and Denali Intermediate’s other restricted subsidiaries to incur debt, create liens, make fundamental changes, enter into asset sales, make certain investments, pay dividends or distribute or redeem certain equity interests, prepay or redeem certain debt, and enter into certain transactions with affiliates.  The indenture governing the Senior Notes contains customary negative covenants that generally limit the ability of Denali Intermediate, Dell, and Dell’s and Denali Intermediate’s other restricted subsidiaries to incur additional debt or issue certain preferred shares, pay dividends on or make other distributions in respect of capital stock or make other restricted payments, make certain investments, sell or transfer certain assets, create liens on certain assets to secure debt, consolidate, merge, sell, or otherwise dispose of all or substantially all assets, enter into certain transactions with affiliates, and designate subsidiaries as unrestricted subsidiaries.

[0001571996-20-000017:notes:237]
The negative covenants under such credit agreements and indenture are subject to certain exceptions, qualifications, and “baskets.”  The indentures governing the First Lien Notes, the Unsecured Notes and Debentures, and the EMC Notes variously impose limitations, subject to specified exceptions, on creating certain liens, entering into sale and lease-back transactions, and entering into certain asset sales.  The foregoing credit agreements and indentures contain customary events of default, including failure to make required payments, failure to comply with covenants, and the occurrence of certain events of bankruptcy and insolvency.

[0001571996-20-000017:notes:238]
As of January 31, 2020, the Company had certain consolidated subsidiaries that were designated as unrestricted subsidiaries for all purposes of the applicable credit agreements and the indentures governing the First Lien Notes and the Senior Notes.   Substantially all of the net assets of the Company’s consolidated subsidiaries were restricted, with the exception of the Company’s unrestricted subsidiaries, primarily VMware Inc., Secureworks, and their respective subsidiaries, as of January 31, 2020.

[0001571996-20-000017:notes:239]
The Term Loan A-4 Facility, the Term Loan A-6 Facility, and the Revolving Credit Facility are subject to a first lien leverage ratio covenant that is tested at the end of each fiscal quarter of Dell with respect to Dell’s preceding four fiscal quarters.  The Company was in compliance with all financial covenants as of January 31, 2020.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001571996-20-000017:notes:240]
NOTE 7 — DERIVATIVE INSTRUMENTS AND HEDGING ACTIVITIES

[0001571996-20-000017:notes:241]
As part of its risk management strategy, the Company uses derivative instruments, primarily foreign currency forward and option contracts and interest rate swaps, to hedge certain foreign currency and interest rate exposures, respectively.

[0001571996-20-000017:notes:242]
The Company’s objective is to offset gains and losses resulting from these exposures with gains and losses on the derivative contracts used to hedge the exposures, thereby reducing volatility of earnings and protecting the fair values of assets and liabilities.  The earnings effects of the derivative instruments are presented in the same income statement line items as the earnings effects of the hedged items.  For derivatives designated as cash flow hedges, the Company assesses hedge effectiveness both at the onset of the hedge, and at regular intervals throughout the life of the derivative.  The Company does not have any derivatives designated as fair value hedges.

[0001571996-20-000017:notes:243]
Foreign Exchange Risk

[0001571996-20-000017:notes:244]
The Company uses foreign currency forward and option contracts designated as cash flow hedges to protect against the foreign currency exchange rate risks inherent in its forecasted transactions denominated in currencies other than the U.S. Dollar.  Hedge accounting is applied based upon the criteria established by accounting guidance for derivative instruments and hedging activities.  The risk of loss associated with purchased options is limited to premium amounts paid for the option contracts.  The risk of loss associated with forward contracts is equal to the exchange rate differential from the time the contract is entered into until the time it is settled.  The majority of these contracts typically expire in twelve months or less.

[0001571996-20-000017:notes:245]
During the fiscal years ended January 31, 2020, February 1, 2019, and February 2, 2018, the Company did not discontinue any cash flow hedges related to foreign exchange contracts that had a material impact on the Company’s results of operations due to the probability that the forecasted cash flows would not occur.

[0001571996-20-000017:notes:246]
The Company uses forward contracts to hedge monetary assets and liabilities denominated in a foreign currency.  These contracts generally expire in three months or less, are considered economic hedges, and are not designated for hedge accounting.  The change in the fair value of these instruments represents a natural hedge as their gains and losses offset the changes in the underlying fair value of the monetary assets and liabilities due to movements in currency exchange rates.

[0001571996-20-000017:notes:247]
In connection with expanded offerings of DFS in Europe, forward contracts are used to hedge financing receivables denominated in foreign currencies other than Euro.  These contracts are not designated for hedge accounting and most expire within three years or less.

[0001571996-20-000017:notes:248]
Interest Rate Risk

[0001571996-20-000017:notes:249]
The Company uses interest rate swaps to hedge the variability in cash flows related to the interest rate payments on structured financing debt.  The interest rate swaps economically convert the variable rate on the structured financing debt to a fixed interest rate to match the underlying fixed rate being received on fixed-term customer leases and loans.  These contracts are not designated for hedge accounting and most expire within three years or less.

[0001571996-20-000017:notes:250]
Interest rate swaps are utilized to manage the interest rate risk, at a portfolio level, associated with DFS operations in Europe.  The interest rate swaps economically convert the fixed rate on financing receivables to a three-month Euribor-based floating rate in order to match the floating rate nature of the banks’ funding pool.  These contracts are not designated for hedge accounting and most expire within five years or less.

[0001571996-20-000017:notes:251]
The Company utilizes cross currency amortizing swaps to hedge the currency and interest rate risk exposure associated with the securitization program that was established in Europe in January 2017.  The cross currency swaps combine a Euro-based interest rate swap with a British Pound or U.S. Dollar foreign exchange forward contract in which the Company pays a fixed British Pound or U.S. Dollar amount and receives a floating amount in Euros linked to the one-month Euribor.  The notional value of the swaps amortizes in line with the expected cash flows and run-off of the securitized assets.  The swaps are not designated for hedge accounting and expire within five years or less.

[0001571996-20-000017:notes:252]
Derivative Instruments

[0001571996-20-000017:notes:253]
Notional Amounts of Outstanding Derivative Instruments

[0001571996-20-000017:notes:254]
|  | January 31, 2020 |  | February 1, 2019 |
|  | (in millions) |
| Foreign exchange contracts: |  |  |  |  |  |
| Designated as cash flow hedging instruments | $ | 8,703 |  |  | $ | 7,573 |  |
| Non-designated as hedging instruments | 7,711 |  |  | 6,129 |  |
| Total | $ | 16,414 |  |  | $ | 13,702 |  |
| Interest rate contracts: |  |  |  |
| Non-designated as hedging instruments | $ | 4,043 |  |  | $ | 2,674 |  |

[0001571996-20-000017:notes:255]
Effect of Derivative Instruments Designated as Hedging Instruments on the Consolidated Statements of Financial Position and the Consolidated Statements of Income (Loss)

[0001571996-20-000017:notes:256]
| Derivatives in Cash Flow Hedging Relationships |  | Gain (Loss) Recognized in Accumulated OCI, Net of Tax, on Derivatives |  | Location of Gain (Loss) Reclassified from Accumulated OCI into Income |  | Gain (Loss) Reclassified from Accumulated OCI into Income |
|  |  | (in millions) |  |  |  | (in millions) |
| For the fiscal year ended January 31, 2020 |
|  |  |  |  |  | Total net revenue |  | $ | 226 |  |
| Foreign exchange contracts |  | $ | 269 |  |  | Total cost of net revenue |  | — |  |
| Interest rate contracts |  | — |  |  | Interest and other, net |  | — |  |
| Total |  | $ | 269 |  |  |  |  | $ | 226 |  |
| For the fiscal year ended February 1, 2019 |
|  |  |  |  |  | Total net revenue |  | $ | 225 |  |
| Foreign exchange contracts |  | $ | 299 |  |  | Total cost of net revenue |  | — |  |
| Interest rate contracts |  | — |  |  | Interest and other, net |  | — |  |
| Total |  | $ | 299 |  |  |  |  | $ | 225 |  |
| For the fiscal year ended February 2, 2018 |
|  |  |  |  |  | Total net revenue |  | $ | (77 | ) |
| Foreign exchange contracts |  | $ | (248 | ) |  | Total cost of net revenue |  | (57 | ) |
| Interest rate contracts |  | — |  |  | Interest and other, net |  | — |  |
| Total |  | $ | (248 | ) |  |  |  | $ | (134 | ) |

[0001571996-20-000017:notes:257]
Effect of Derivative Instruments Not Designated as Hedging Instruments on the Consolidated Statements of Income (Loss)

[0001571996-20-000017:notes:258]
|  | Fiscal Year Ended |  |  |
|  | January 31, 2020 |  | February 1, 2019 |  | February 2, 2018 |  | Location of Gain (Loss) Recognized |
|  | (in millions) |  |  |
| Foreign exchange contracts | $ | (152 | ) |  | $ | (67 | ) |  | $ | (106 | ) |  | Interest and other, net |
| Interest rate contracts | (28 | ) |  | (8 | ) |  | 4 |  |  | Interest and other, net |
| Total | $ | (180 | ) |  | $ | (75 | ) |  | $ | (102 | ) |  |  |

[0001571996-20-000017:notes:259]
Fair Value of Derivative Instruments in the Consolidated Statements of Financial Position

[0001571996-20-000017:notes:260]
The Company presents its foreign exchange derivative instruments on a net basis in the Consolidated Statements of Financial Position due to the right of offset by its counterparties under master netting arrangements.  The following tables present the fair value of those derivative instruments presented on a gross basis as the dates indicated:

[0001571996-20-000017:notes:261]
|  | January 31, 2020 |
|  | Other CurrentAssets |  | Other Non-Current Assets |  | Other CurrentLiabilities |  | Other Non-CurrentLiabilities |  | TotalFair Value |
|  | (in millions) |
| Derivatives designated as hedging instruments: |
| Foreign exchange contracts in an asset position | $ | 108 |  |  | $ | — |  |  | $ | 15 |  |  | $ | — |  |  | $ | 123 |  |
| Foreign exchange contracts in a liability position | (2 | ) |  | — |  |  | (3 | ) |  | — |  |  | (5 | ) |
| Net asset (liability) | 106 |  |  | — |  |  | 12 |  |  | — |  |  | 118 |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts in an asset position | 136 |  |  | — |  |  | 39 |  |  | — |  |  | 175 |  |
| Foreign exchange contracts in a liability position | (162 | ) |  | — |  |  | (81 | ) |  | (6 | ) |  | (249 | ) |
| Interest rate contracts in an asset position | — |  |  | 1 |  |  | — |  |  | — |  |  | 1 |  |
| Interest rate contracts in a liability position | — |  |  | — |  |  | — |  |  | (32 | ) |  | (32 | ) |
| Net asset (liability) | (26 | ) |  | 1 |  |  | (42 | ) |  | (38 | ) |  | (105 | ) |
| Total derivatives at fair value | $ | 80 |  |  | $ | 1 |  |  | $ | (30 | ) |  | $ | (38 | ) |  | $ | 13 |  |
|  | February 1, 2019 |
|  | Other CurrentAssets |  | Other Non-Current Assets |  | Other CurrentLiabilities |  | Other Non-CurrentLiabilities |  | TotalFair Value |
|  | (in millions) |
| Derivatives designated as hedging instruments: |
| Foreign exchange contracts in an asset position | $ | 45 |  |  | $ | — |  |  | $ | 29 |  |  | $ | — |  |  | $ | 74 |  |
| Foreign exchange contracts in a liability position | (19 | ) |  | — |  |  | (20 | ) |  | — |  |  | (39 | ) |
| Net asset (liability) | 26 |  |  | — |  |  | 9 |  |  | — |  |  | 35 |  |
| Derivatives not designated as hedging instruments: |
| Foreign exchange contracts in an asset position | 178 |  |  | — |  |  | 57 |  |  | — |  |  | 235 |  |
| Foreign exchange contracts in a liability position | (110 | ) |  | — |  |  | (115 | ) |  | (2 | ) |  | (227 | ) |
| Interest rate contracts in an asset position | — |  |  | 3 |  |  | — |  |  | — |  |  | 3 |  |
| Interest rate contracts in a liability position | — |  |  | — |  |  | — |  |  | (9 | ) |  | (9 | ) |
| Net asset (liability) | 68 |  |  | 3 |  |  | (58 | ) |  | (11 | ) |  | 2 |  |
| Total derivatives at fair value | $ | 94 |  |  | $ | 3 |  |  | $ | (49 | ) |  | $ | (11 | ) |  | $ | 37 |  |

[0001571996-20-000017:notes:262]
The following tables present the gross amounts of the Company’s derivative instruments, amounts offset due to master netting agreements with the Company’s counterparties, and the net amounts recognized in the Consolidated Statements of Financial Position as of the dates indicated:

[0001571996-20-000017:notes:263]
|  | January 31, 2020 |
|  | Gross Amounts of Recognized Assets/ (Liabilities) |  | Gross Amounts Offset in the Statement of Financial Position |  | Net Amounts of Assets/ (Liabilities) Presented in the Statement of Financial Position |  | Gross Amounts not Offset in the Statement of Financial Position |  | Net Amount |
|  | Financial Instruments |  | Cash Collateral Received or Pledged |  |
|  | (in millions) |
| Derivative instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Financial assets | $ | 299 |  |  | $ | (218 | ) |  | $ | 81 |  |  | $ | — |  |  | $ | — |  |  | $ | 81 |  |
| Financial liabilities | (286 | ) |  | 218 |  |  | (68 | ) |  | — |  |  | 15 |  |  | (53 | ) |
| Total derivative instruments | $ | 13 |  |  | $ | — |  |  | $ | 13 |  |  | $ | — |  |  | $ | 15 |  |  | $ | 28 |  |
|  | February 1, 2019 |
|  | Gross Amounts of Recognized Assets/ (Liabilities) |  | Gross Amounts Offset in the Statement of Financial Position |  | Net Amounts of Assets/ (Liabilities) Presented in the Statement of Financial Position |  | Gross Amounts not Offset in the Statement of Financial Position |  | Net Amount |
|  | Financial Instruments |  | Cash Collateral Received or Pledged |  |
|  | (in millions) |
| Derivative instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Financial assets | $ | 312 |  |  | $ | (215 | ) |  | $ | 97 |  |  | $ | — |  |  | $ | — |  |  | $ | 97 |  |
| Financial liabilities | (275 | ) |  | 215 |  |  | (60 | ) |  | — |  |  | 4 |  |  | (56 | ) |
| Total derivative instruments | $ | 37 |  |  | $ | — |  |  | $ | 37 |  |  | $ | — |  |  | $ | 4 |  |  | $ | 41 |  |


## dell:BusinessCombinationGoodwillAndIntangibleAssetsTextBlock

[0001571996-20-000017:notes:264]
NOTE 8 — BUSINESS COMBINATIONS, GOODWILL AND INTANGIBLE ASSETS

[0001571996-20-000017:notes:265]
Business Combinations

[0001571996-20-000017:notes:266]
Fiscal year ended January 31, 2020

[0001571996-20-000017:notes:267]
VMware, Inc. Acquisition of Carbon Black, Inc.

[0001571996-20-000017:notes:268]
On October 8, 2019, VMware, Inc. completed the acquisition of Carbon Black, Inc. (“Carbon Black”), a developer of cloud-native endpoint protection, in a cash tender offer for all of the outstanding shares of Carbon Black’s common stock, at a price of $26.00 per share.  VMware, Inc. acquired Carbon Black to create a comprehensive intrinsic security portfolio to protect workloads, clients, and infrastructure from cloud to edge.  VMware, Inc. believes that the acquisition will result in synergies with the Carbon Black platform and VMware NSX and VMware Workspace ONE offerings, among others, and enable VMware, Inc. to offer a highly-differentiated intrinsic security platform addressing multiple concerns of the security industry.  The total preliminary purchase price was $2.0 billion, net of cash acquired of $111 million.

[0001571996-20-000017:notes:269]
Merger consideration totaling $18 million is held with a third-party paying agent and is payable to a certain employee of Carbon Black subject to specified future employment conditions and is being recognized as an expense over the requisite service period of approximately two years on a straight-line basis.

[0001571996-20-000017:notes:270]
VMware, Inc. assumed all of Carbon Black’s unvested stock options and restricted stock awards outstanding at the completion of the acquisition with an estimated fair value of $181 million.  Of the total consideration, $10 million was allocated to the purchase price and $171 million was allocated to future services and will be expensed over the remaining requisite service periods of approximately three years on a straight-line basis.  The estimated fair value of the stock options assumed by VMware, Inc. was determined using the Black-Scholes option pricing model.  A share conversion ratio of 0.2 was applied to convert Carbon Black’s outstanding stock awards into awards for shares of VMware, Inc.'s common stock.

[0001571996-20-000017:notes:271]
The following table summarizes the preliminary allocation of the consideration to the fair value of the assets acquired and liabilities assumed on the date of acquisition.

[0001571996-20-000017:notes:272]
|  | Preliminary Allocation |
|  | (in millions) |
| Cash | $ | 111 |  |
| Accounts receivable | 58 |  |
| Intangible assets | 492 |  |
| Goodwill | 1,588 |  |
| Other acquired assets | 52 |  |
| Total assets acquired | 2,301 |  |
| Deferred revenue | 151 |  |
| Other assumed liabilities | 45 |  |
| Total liabilities assumed | 196 |  |
| Fair value of assets acquired and liabilities assumed | $ | 2,105 |  |

[0001571996-20-000017:notes:273]
The following table summarizes the components of the intangible assets acquired and their estimated useful lives by VMware, Inc. in conjunction with the acquisition.

[0001571996-20-000017:notes:274]
|  | Weighted-Average Useful Lives |  | Fair Value Amount |
|  | (in years) |  | (in millions) |
| Purchased technology | 4.2 |  | $ | 232 |  |
| Customer relationships and customer lists | 7.0 |  | 215 |  |
| Trademarks and tradenames | 5.0 |  | 25 |  |
| Other | 2.0 |  | 20 |  |
| Total definite-lived intangible assets |  |  | $ | 492 |  |

[0001571996-20-000017:notes:275]
The excess of the purchase consideration over the fair value of net tangible and identifiable intangible assets acquired was recorded as goodwill.  The estimated fair value assigned to the tangible assets, identifiable intangible assets, and assumed liabilities were based on VMware, Inc. management's estimates and assumptions.  The initial allocation of the purchase price was based on preliminary valuations and assumptions and is subject to change within the measurement period.  Additionally, current and non-current income taxes payable and deferred taxes may be subject to change as additional information is received and tax returns are finalized.  VMware, Inc. expects to finalize the allocation of the purchase price within the measurement period.  VMware, Inc. expects that goodwill and identifiable intangible assets will not be deductible for tax purposes.

[0001571996-20-000017:notes:276]
The pro forma financial information assuming the acquisition had occurred as of the beginning of the fiscal year prior to the fiscal year of acquisition, as well as the revenue and earnings generated during the current fiscal year, were not material for disclosure purposes.

[0001571996-20-000017:notes:277]
Other VMware, Inc. Acquisitions

[0001571996-20-000017:notes:278]
During the fiscal year ended January 31, 2020, VMware, Inc. completed the acquisition of Avi Networks, Inc., a provider of multi-cloud application delivery services.  Together, VMware, Inc. and Avi Networks, Inc. expect to deliver a software defined networking stack built for the multi-cloud environment.  The total purchase price was $326 million, net of cash acquired of $9 million.  The purchase price primarily included $94 million of identifiable intangible assets and $228 million of goodwill that is not expected to be deductible for tax purposes.  The Company has not presented pro forma results of operations for this acquisition because it is not material to the Company’s consolidated results of operations, financial position, or cash flows.

[0001571996-20-000017:notes:279]
VMware, Inc. completed other acquisitions during the fiscal year ended January 31, 2020 which were not material individually or collectively to the Consolidated Financial Statements.  VMware, Inc. expects that these acquisitions will enhance its product features and capabilities for its software-defined data center solutions and software-as-a-service offerings.

[0001571996-20-000017:notes:280]
For each of the acquisitions during the fiscal year ended January 31, 2020, the initial allocation of the purchase price was based on preliminary valuations and assumptions and is subject to change within the measurement period.  VMware, Inc. expects to finalize the allocation of the purchase price for each of the acquisitions within the measurement period.

[0001571996-20-000017:notes:281]
Fiscal year ended February 1, 2019

[0001571996-20-000017:notes:282]
VMware, Inc. Acquisitions

[0001571996-20-000017:notes:283]
CloudHealth Technologies, Inc. — During the third quarter of the fiscal year ended February 1, 2019, VMware, Inc. completed the acquisition of CloudHealth Technologies, Inc. (“CloudHealth Technologies”), a company delivering a cloud operations platform that enables customers to analyze and manage cloud cost, usage, security, and performance centrally for native public clouds.  The total purchase price was $495 million, net of cash acquired of $26 million and primarily included $101 million of identifiable intangible assets and $394 million of goodwill that is not expected to be deductible for tax purposes.  The identifiable intangible assets included completed technology of $69 million and customer relationships of $18 million, with estimated useful lives of one to five years.  The fair value of assumed unvested equity awards attributed to post-combination services was $39 million and will be expensed over the remaining requisite service periods on a straight-line basis.

[0001571996-20-000017:notes:284]
Heptio Inc.  —  During the fourth quarter of the fiscal year ended February 1, 2019, VMware, Inc. completed the acquisition of Heptio Inc. (“Heptio”), a provider of products and services that help enterprises deploy and operationalize Kubernetes software.  The total purchase price was $420 million, net of cash acquired of $15 million.  The purchase price primarily included $27 million of identifiable intangible assets and $392 million of goodwill that is not expected to be deductible for tax purposes.  The identifiable intangible assets primarily consisted of completed technology of $20 million, with an estimated useful life of five years.  Merger consideration totaling $117 million, including $24 million that was held in escrow, is payable to certain employees of Heptio subject to specified future employment conditions and is being recognized as expense over the requisite service periods on a straight-line basis.  Compensation expense recognized during the year ended February 1, 2019 was not significant.  The fair value of assumed unvested equity awards attributed to post-combination services was $47 million and will be expensed over the remaining requisite service periods on a straight-line basis.

[0001571996-20-000017:notes:285]
The Company has not presented pro forma results of operations for the foregoing acquisitions because they are not material to the Company’s consolidated results of operations, financial position, or cash flows.

[0001571996-20-000017:notes:286]
Fiscal year ended February 2, 2018

[0001571996-20-000017:notes:287]
VeloCloud Networks, Inc. — During the fourth quarter of the fiscal year ended February 2, 2018, VMware, Inc. completed the acquisition of VeloCloud Networks, Inc. (“VeloCloud”), a provider of cloud-delivered software-defined wide-area network (SD-WAN) technology for enterprises and service providers.  VMware, Inc. acquired VeloCloud to build on its network virtualization platform, VMware NSX, and to expand its networking portfolio.  The total purchase price was $449 million, net of cash acquired of $24 million.  Prior to the closing of the acquisition, Dell Technologies, including VMware Inc., held an ownership interest in VeloCloud.  Upon completion of the step acquisition, Dell Technologies recognized a gain of $8 million in interest and other, net for the remeasurement of its previously held ownership interest to fair value, which was $12 million.

[0001571996-20-000017:notes:288]
Other Business Combinations — During the second quarter of the fiscal year ended February 2, 2018, VMware, Inc. completed the acquisitions of Wavefront and Apteligent, Inc., which were not material to the Consolidated Financial Statements.  These acquisitions are a part of VMware, Inc.’s strategy to accelerate the development of VMware, Inc.’s cloud services and other technologies.  The aggregate purchase price for the two acquisitions was $323 million, inclusive of the fair value of the Company’s existing investment in Wavefront of $69 million and cash acquired of $35 million.  The aggregate purchase price included $36 million of identifiable intangible assets and $238 million of goodwill that is not expected to be deductible for tax purposes.  Prior to the closing of the acquisition, Dell Technologies, including VMware, Inc., held an ownership interest in Wavefront.  Upon completion of the step acquisition, Dell Technologies recognized a $45 million gain in interest and other, net for the remeasurement of its previously held ownership interest to fair value.

[0001571996-20-000017:notes:289]
Goodwill

[0001571996-20-000017:notes:290]
The Infrastructure Solutions Group, Client Solutions Group, and VMware reporting units are consistent with the reportable segments identified in Note 19 of the Notes to the Consolidated Financial Statements.  Offerings within Other Businesses as defined below represent separate reporting units.

[0001571996-20-000017:notes:291]
During the fiscal year ended January 31, 2020, VMware, Inc. completed its acquisition of Pivotal which was accounted for as a transaction by entities under common control, and Dell Technologies now reports Pivotal results within the VMware reportable segment.  Pivotal results and goodwill were previously included within Other businesses.  The historical segment results and the historical carrying amounts of goodwill attributable to Pivotal ($2.2 billion as of February 2, 2018) have been recast to reflect this change.  See Note 19 of the Notes to the Consolidated Financial Statements for the recast of segment results.

[0001571996-20-000017:notes:292]
During the fiscal year ended February 1, 2019, the Company made certain segment reporting changes, which included the movement of operating results of Virtustream Group Holdings, Inc. (“Virtustream”) from the Infrastructure Solutions Group segment to Other Businesses.  The historical carrying amount of goodwill attributable to Virtustream was reclassified to Other Businesses to align with these reporting changes.

[0001571996-20-000017:notes:293]
The following table presents goodwill allocated to the Company’s reportable segments and changes in the carrying amount of goodwill as of the dates indicated:

[0001571996-20-000017:notes:294]
|  | Infrastructure Solutions Group |  | Client Solutions Group |  | VMware |  | Other Businesses (a) |  | Total |
|  | (in millions) |
| Balances as of February 2, 2018 | $ | 15,557 |  |  | $ | 4,237 |  |  | $ | 17,863 |  |  | $ | 2,263 |  |  | $ | 39,920 |  |
| Goodwill acquired (b) | — |  |  | — |  |  | 784 |  |  | — |  |  | 784 |  |
| Impact of foreign currency translation | (289 | ) |  | — |  |  | (26 | ) |  | (41 | ) |  | (356 | ) |
| Goodwill divested | (69 | ) |  | — |  |  | — |  |  | — |  |  | (69 | ) |
| Goodwill impaired (c) | — |  |  | — |  |  | — |  |  | (190 | ) |  | (190 | ) |
| Balances as of February 1, 2019 | 15,199 |  |  | 4,237 |  |  | 18,621 |  |  | 2,032 |  |  | 40,089 |  |
| Goodwill acquired (b) | — |  |  | — |  |  | 1,911 |  |  | 16 |  |  | 1,927 |  |
| Impact of foreign currency translation | (110 | ) |  | — |  |  | — |  |  | (8 | ) |  | (118 | ) |
| Goodwill impaired (c) | — |  |  | — |  |  | — |  |  | (207 | ) |  | (207 | ) |
| Balance as of January 31, 2020 | $ | 15,089 |  |  | $ | 4,237 |  |  | $ | 20,532 |  |  | $ | 1,833 |  |  | $ | 41,691 |  |

[0001571996-20-000017:notes:295]
| (a) | Other Businesses consists of offerings by Secureworks, Virtustream, Boomi, and RSA Security. |

[0001571996-20-000017:notes:296]
| (b) | VMware, Inc. business combinations completed during the fiscal years ended January 31, 2020 and February 1, 2019, as discussed above. |

[0001571996-20-000017:notes:297]
| (c) | The Company recognized goodwill impairment charges related to Virtustream during the fiscal years ended January 31, 2020 and February 1, 2019, as discussed below. |

[0001571996-20-000017:notes:298]
Annual Goodwill Impairment Test — Goodwill and indefinite-lived intangible assets are tested for impairment annually during the third fiscal quarter and whenever events or circumstances may indicate that an impairment has occurred.  The Company elected to bypass the assessment of qualitative factors to determine whether it was more likely than not that the fair value of a reporting unit was less than its carrying amount, including goodwill.  In electing to bypass the qualitative assessment, the Company proceeded directly to performing a quantitative goodwill impairment test to measure the fair value of each goodwill reporting unit relative to its carrying amount, and to determine the amount of goodwill impairment loss to be recognized, if any.

[0001571996-20-000017:notes:299]
Management exercised significant judgment related to the above assessment, including the identification of goodwill reporting units, assignment of assets and liabilities to goodwill reporting units, assignment of goodwill to reporting units, and determination of the fair value of each goodwill reporting unit.  The fair value of each goodwill reporting unit is generally estimated using a combination of public company multiples and discounted cash flow methodologies, unless the reporting unit relates to a publicly-traded entity (VMware, Inc. or Secureworks), in which case the fair value is determined based primarily on the public company market valuation.  The discounted cash flow and public company multiples methodologies require significant judgment, including estimation of future cash flows, which is dependent on internal forecasts, current and anticipated economic conditions and trends, selection of market multiples through assessment of the reporting unit’s performance relative to peer competitors, the estimation of the long-term revenue growth rate and discount rate of the Company’s business, and the determination of the Company’s weighted average cost of capital.  Changes in these estimates and assumptions could materially affect the fair value of the goodwill reporting unit, potentially resulting in a non-cash impairment charge.

[0001571996-20-000017:notes:300]
The fair value of the indefinite-lived trade names is generally estimated using discounted cash flow methodologies.  The discounted cash flow methodology requires significant judgment, including estimation of future revenue, which is dependent on internal forecasts, the estimation of the long-term revenue growth rate of the Company’s business and the determination of the Company’s weighted average cost of capital and royalty rates.  Changes in these estimates and assumptions could materially affect the fair value of the indefinite-lived intangible assets, potentially resulting in a non-cash impairment charge.

[0001571996-20-000017:notes:301]
Based on the results of the annual impairment test performed during the fiscal year ended January 31, 2020, the fair values of each of the reporting units exceeded their carrying values.  However, it was determined that the fair value of the RSA Security reporting unit exceeded its carrying value by 13% as of November 1, 2019.  The Company’s entry into a definitive agreement to

[0001571996-20-000017:notes:302]
sell RSA Security for $2.075 billion provided a new fair value indication that the RSA Security reporting unit exceeds carrying value.  Subsequent to the annual impairment test, based on fair value indicators as of January 31, 2020 it was determined that the fair value of the RSA Security reporting unit exceeded its carrying amount by 20%.  For more information regarding the pending sale of RSA Security, see Note 24 of the Notes to the Consolidated Financial Statements.  During the fiscal year ended January 31, 2020, an interim impairment assessment of Virtustream was required as discussed further below.

[0001571996-20-000017:notes:303]
During the fiscal year ended February 1, 2019, an annual impairment test was performed, and then an additional interim impairment analysis was performed following the close of the Class V transaction in December 2018 given the availability of market data for the fair value of the Class C Common Stock.  Based on the results of the impairment tests performed during the fiscal year ended February 1, 2019, the fair values of each of the reporting units, except for the Virtustream reporting unit, exceeded their carrying values.

[0001571996-20-000017:notes:304]
Virtustream’s results, which are reported within the Company’s Other businesses, do not meet the requirements for a reportable segment and are not material to the Company’s overall results.  Virtustream delivers an application management cloud platform for enterprise mission-critical workloads in the infrastructure-as-a-service market, and had approximately $0.4 billion in goodwill that was derived from the EMC merger transaction during the fiscal year ended February 3, 2017.  Virtustream forecasts were revised downward due to a resetting of the longer term business model that is focused on a streamlined product portfolio.

[0001571996-20-000017:notes:305]
During the fiscal year ended February 1, 2019, it was determined that the carrying value of the Virtustream reporting unit exceeded its fair value, and, as such, a goodwill impairment charge of approximately $190 million was recognized, and was classified in Selling, general, and administrative in the Consolidated Statements of Income (Loss).  The impairment is reflected as a reduction in Goodwill of approximately $190 million in the Consolidated Statements of Financial Position as of February 1, 2019.  The Company did not have any accumulated goodwill impairment charges from prior period goodwill impairment tests.

[0001571996-20-000017:notes:306]
During the fiscal year ended January 31, 2020, the Company evaluated strategic alternatives for Virtustream that provided new fair value indicators and resulted in the need to perform an interim impairment assessment of both long-lived assets (including intangible assets) and goodwill.  Based on the results of the impairment assessment, it was determined that the fair value of the asset group was less than its carrying value.  A gross impairment charge of $619 million ($524 million net of tax benefits) was recognized related to Virtustream intangible assets, property, plant, and equipment, and remaining goodwill during the three months ended August 2, 2019 and was classified in Selling, general, and administrative in the Consolidated Statements of Income (Loss).  Additionally, required deferred tax adjustments associated with the intangible assets and property, plant, and equipment resulted in the recognition of an income tax benefit of $95 million in the Consolidated Statements of Income (Loss).  The impairment is reflected in the Consolidated Statements of Financial Position as of January 31, 2020 as a reduction in Goodwill of $207 million, a reduction in Intangible assets, net of $266 million, a reduction in Property, plant, and equipment, net of $146 million, and a reduction in Other non-current liabilities of $95 million related to deferred income taxes.

[0001571996-20-000017:notes:307]
There are no remaining balances of Virtustream goodwill, intangible assets, or property, plant, and equipment as of January 31, 2020 following the respective impairment charges recognized during the fiscal years ended January 31, 2020 and February 1, 2019.

[0001571996-20-000017:notes:308]
Intangible Assets

[0001571996-20-000017:notes:309]
The following table presents the Company’s intangible assets as of the dates indicated:

[0001571996-20-000017:notes:310]
|  | January 31, 2020 |  | February 1, 2019 |
|  | Gross |  | AccumulatedAmortization |  | Net |  | Gross |  | AccumulatedAmortization |  | Net |
|  | (in millions) |
| Customer relationships | $ | 22,950 |  |  | $ | (13,821 | ) |  | $ | 9,129 |  |  | $ | 22,750 |  |  | $ | (11,703 | ) |  | $ | 11,047 |  |
| Developed technology | 15,707 |  |  | (10,974 | ) |  | 4,733 |  |  | 15,701 |  |  | (9,036 | ) |  | 6,665 |  |
| Trade names | 1,306 |  |  | (816 | ) |  | 490 |  |  | 1,291 |  |  | (606 | ) |  | 685 |  |
| Leasehold assets (liabilities) | — |  |  | — |  |  | — |  |  | 128 |  |  | (10 | ) |  | 118 |  |
| Definite-lived intangible assets | 39,963 |  |  | (25,611 | ) |  | 14,352 |  |  | 39,870 |  |  | (21,355 | ) |  | 18,515 |  |
| Indefinite-lived trade names | 3,755 |  |  | — |  |  | 3,755 |  |  | 3,755 |  |  | — |  |  | 3,755 |  |
| Total intangible assets | $ | 43,718 |  |  | $ | (25,611 | ) |  | $ | 18,107 |  |  | $ | 43,625 |  |  | $ | (21,355 | ) |  | $ | 22,270 |  |

[0001571996-20-000017:notes:311]
Amortization expense related to definite-lived intangible assets was approximately $4.4 billion, $6.1 billion, and $7.0 billion for the fiscal years ended January 31, 2020, February 1, 2019, and February 2, 2018, respectively.  During the fiscal year ended January 31, 2020, an impairment charge related to Virtustream intangible assets, net was approximately $266 million, as discussed above.  During the fiscal year ended February 1, 2019, due to Virtustream business changes, the Virtustream definite-lived intangible assets were tested for impairment using a quantitative analysis, and no impairment was identified.  There were no material impairment charges related to intangible assets during the fiscal year ended February 2, 2018.

[0001571996-20-000017:notes:312]
Due to the adoption of the new lease standard discussed in Note 2 of the Notes to the Consolidated Financial Statements, the Company derecognized all intangible leasehold assets and adjusted the carrying amount of the ROU assets by a corresponding amount as of January 31, 2020.

[0001571996-20-000017:notes:313]
The following table presents the estimated future annual pre-tax amortization expense of definite-lived intangible assets as of the date indicated:

[0001571996-20-000017:notes:314]
|  | January 31, 2020 |
| Fiscal Years | (in millions) |
| 2021 | 3,431 |  |
| 2022 | 2,722 |  |
| 2023 | 1,838 |  |
| 2024 | 1,464 |  |
| 2025 | 1,128 |  |
| Thereafter | 3,769 |  |
| Total | $ | 14,352 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001571996-20-000017:notes:315]
NOTE 9 — DEFERRED REVENUE

[0001571996-20-000017:notes:316]
Deferred Revenue — Deferred revenue is recorded for support and deployment services, software maintenance, professional services, training, and SaaS when the Company has a right to invoice or payments have been received for undelivered products or services where transfer of control has not occurred.  Revenue is recognized on these items when the revenue recognition criteria are met, generally resulting in ratable recognition over the contract term.  The Company also has deferred revenue related to undelivered hardware and professional services, consisting of installations and consulting engagements, which are recognized as the Company’s performance obligations under the contract are completed.

[0001571996-20-000017:notes:317]
The following table presents the changes in the Company’s deferred revenue for the periods indicated:

[0001571996-20-000017:notes:318]
|  | Fiscal Year Ended |
|  | January 31, 2020 |  | February 1, 2019 |
|  | (in millions) |
| Deferred revenue: |  |  |  |
| Deferred revenue at beginning of period | $ | 24,010 |  |  | $ | 20,816 |  |
| Revenue deferrals for new contracts and changes in estimates for pre-existing contracts (a) | 23,315 |  |  | 20,580 |  |
| Revenue recognized | (19,676 | ) |  | (17,386 | ) |
| Other (b) | 151 |  |  | — |  |
| Deferred revenue at end of period | $ | 27,800 |  |  | $ | 24,010 |  |
| Short-term deferred revenue | $ | 14,881 |  |  | $ | 12,944 |  |
| Long-term deferred revenue | $ | 12,919 |  |  | $ | 11,066 |  |

[0001571996-20-000017:notes:319]
| (a) | Includes the impact of foreign currency exchange rate fluctuations. |

[0001571996-20-000017:notes:320]
| (b) | Acquired deferred revenue from Carbon Black, Inc. during the fiscal year ended January 31, 2020. See Note 8 of the Notes to the Consolidated Financial Statements for additional information related to this acquisition. |

[0001571996-20-000017:notes:321]
Remaining Performance Obligations — Remaining performance obligations represent the aggregate amount of the transaction price allocated to performance obligations not delivered, or partially undelivered, as of the end of the reporting period.  Remaining performance obligations include deferred revenue plus unbilled amounts not yet recorded in deferred revenue.  The value of the transaction price allocated to remaining performance obligations as of January 31, 2020 was approximately $36 billion.  The Company expects to recognize approximately 61% of remaining performance obligations as revenue in the next twelve months, and the remainder thereafter.

[0001571996-20-000017:notes:322]
The aggregate amount of the transaction price allocated to remaining performance obligations does not include amounts owed under cancelable contracts where there is no substantive termination penalty.  The Company applied the practical expedient to exclude the value of remaining performance obligations for contracts for which revenue is recognized at the amount to which the Company has the right to invoice for services performed.

[0001571996-20-000017:notes:323]
Remaining performance obligation estimates are subject to change and are affected by several factors, including terminations, changes in the scope of contracts, periodic revalidation, adjustments for revenue that have not materialized, and adjustments for currency.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001571996-20-000017:notes:324]
NOTE 10 — COMMITMENTS AND CONTINGENCIES

[0001571996-20-000017:notes:325]
Purchase Obligations

[0001571996-20-000017:notes:326]
The Company has contractual obligations to purchase goods or services, which specify significant terms, including fixed or minimum quantities to be purchased; fixed, minimum, or variable price provisions; and the approximate timing of the transaction.  As of January 31, 2020, purchase obligations were $3,900 million, $298 million, and $154 million for Fiscal 2021, Fiscal 2022, and Fiscal 2023 and thereafter, respectively.

[0001571996-20-000017:notes:327]
Lease Commitments

[0001571996-20-000017:notes:328]
The Company leases property and equipment, manufacturing facilities, and office space under non-cancelable leases.  As of January 31, 2020, the future maturity of the Company’s operating lease liabilities under non-cancelable leases was as follows:  $458 million in Fiscal 2021; $380 million  in Fiscal 2022; $292 million in Fiscal 2023; $201 million in Fiscal 2024; $131 million in Fiscal 2025; and $677 million  thereafter.

[0001571996-20-000017:notes:329]
Legal Matters

[0001571996-20-000017:notes:330]
The Company is involved in various claims, suits, assessments, investigations, and legal proceedings that arise from time to time in the ordinary course of its business, including those identified below, consisting of matters involving consumer, antitrust, tax, intellectual property, and other issues on a global basis.

[0001571996-20-000017:notes:331]
The following is a discussion of the Company’s significant legal matters and other proceedings:

[0001571996-20-000017:notes:332]
Securities Litigation — On May 21, 2014, a securities class action seeking compensatory damages was filed in the United States District Court for the Southern District of New York, captioned City of Pontiac General Employees’ Retirement System v. Dell Inc., et. al. (Case No. 1:14-cv-03644).  The action names as defendants Dell Inc. (“Dell”) and certain current and former executive officers, and alleges that Dell made false and misleading statements about Dell’s financial results and future prospects between February 21, 2012 and May 22, 2012, which resulted in artificially inflated stock prices.  The case was transferred to the United States District Court for the Western District of Texas under the same caption (Case No. 1:15-cv-00374), where the defendants filed a motion to dismiss.  On September 16, 2016, the Court denied the motion to dismiss.  On March 29, 2018, the Court granted the plaintiffs’ motion for class certification, and certified a class consisting of all purchasers of Dell common stock between February 22, 2012 and May 22, 2012.  The parties subsequently agreed to an immaterial settlement amount, and notice of the settlement was mailed to stockholders in October 2019.  The Count approved the settlement on January 10, 2020 and payments are currently being made thereunder.  The matter is now closed.

[0001571996-20-000017:notes:333]
Class Actions Related to the Class V Transaction — Four purported stockholders brought putative class action complaints arising out of the Class V transaction described in Note 14 of the Notes to the Consolidated Financial Statements.  The actions were captioned Hallandale Beach Police and Fire Retirement Plan v. Michael Dell et al. (Civil Action No. 2018-0816-JTL), Howard Karp v. Michael Dell et al. (Civil Action No. 2019-0032-JTL), Miramar Police Officers’ Retirement Plan v. Michael Dell et al. (Civil Action No. 2019-0049-JTL), and Steamfitters Local 449 Pension Plan v. Michael Dell et al. (Civil Action No. 2019-0115-JTL).  The four actions were consolidated into In Re Dell Class V Litigation (Consol. C.A. No. 2018-0816-JTL), which names as defendants the Company’s board of directors and certain stockholders of the Company, including Michael S. Dell.  The plaintiffs generally allege that the defendants breached their fiduciary duties to the former holders of Class V Common Stock in connection with the Class V transaction by allegedly causing the Company to enter into a transaction that favored the interests of the controlling stockholders at the expense of such former stockholders.  The plaintiffs filed an amended complaint in August 2019 making substantially similar allegations to those described above.  The defendants filed a motion to dismiss the action in September 2019.  The plaintiffs replied to the motion to dismiss in November 2019, and the defendants filed a reply in December 2019.  A hearing on the motion to dismiss was held on March 13, 2020, and we expect a decision within ninety days.

[0001571996-20-000017:notes:334]
Patent Litigation — On April 25, 2019, Cirba Inc. (“Cirba”) filed a lawsuit against VMware, Inc. in the United States District Court for the District of Delaware, alleging two patent infringement claims and three trademark infringement-related claims.  On May 6, 2019, Cirba filed a motion seeking a preliminary injunction tied to one of the two patents it alleges VMware, Inc. infringes.  Following a hearing on August 6, 2019, the Court denied Cirba’s preliminary injunction motion and set the case for trial in mid-January 2020.  On August 20, 2019, VMware, Inc. filed counterclaims against Cirba, asserting among other claims that Cirba is infringing four VMware, Inc. patents.  The Delaware Court severed those claims from the January 2020 trial on Cirba’s claims, and the trial on VMware, Inc.’s patent claims is currently set for September 2021.  On October 22, 2019, VMware, Inc. filed a separate patent infringement lawsuit against Cirba in the United States District Court for the Eastern District of Virginia, asserting that Cirba infringes four additional VMware, Inc. patents.  The trial on Cirba’s claims in Delaware was completed on January 23, 2020, and on January 24, 2020, the jury returned a verdict finding that VMware, Inc. willfully infringed the two asserted patents and awarding approximately $237 million in damages.  The jury further found that VMware, Inc. was not liable on Cirba’s trademark infringement-related claims.  A total of $237 million has been accrued for the Delaware action and reflects the estimated losses that are considered both probable and reasonably estimable at this time.  The parties will now move to the post-trial briefing stage in the Delaware Court.  VMware, Inc. intends to vigorously defend itself in this matter, including seeking to overturn the jury’s verdict in the first Delaware trial during the post-trial briefing stage and, if necessary, on appeal.  Cirba has expressed its intent to seek a permanent injunction, enhanced damages, and attorneys’ fees in the Delaware action.  As noted above, VMware, Inc. intends to pursue arguments both in the Delaware Court and, if necessary, the Federal Circuit to overturn the jury’s verdict.  Final resolution of this matter could be materially different from the amount accrued.  The amount accrued for this matter is included in Accrued and other on the Consolidated Statements of Financial Position, and the charge is classified in Selling, general and administrative on the Consolidated Statements of Income (Loss).

[0001571996-20-000017:notes:335]
Copyright Levies — The Company is involved in various proceedings and negotiations regarding Dell’s obligation to collect and remit copyright levies in certain European countries that seek to impose or modify levies on computing products (such as PCs, multi-function devices, and external storage devices) alleging those products enable the production of private copies of copyrighted materials.  The levies are generally based upon the number of products sold and the per-product amounts of the levies, which vary.  The Company continues to collect levies in European countries where it has determined that local laws require payment.  The Company, along with other companies and various industry associations, also continues to oppose levy schemes that it believes do not comply with the European Union controlling law and continues to oppose extension of levies to the digital environment.  In some European countries, the Company expects that levies will be extended to other products or that new, higher levies will be implemented.  In other European countries, levies could become more limited, especially if arguments related to commercial users of devices or the industry’s opposition to levies in the digital environment are successful.  Based on sales of products impacted by levies and its assessment of the merits of proceedings and negotiations, the Company believes it has accrued sufficient amounts to address current disputes.

[0001571996-20-000017:notes:336]
Other Litigation — The various legal proceedings in which Dell is involved include commercial and intellectual property litigation.  Dell does not currently anticipate that any of these matters will have a material adverse effect on its business, financial condition, results of operations, or cash flows.

[0001571996-20-000017:notes:337]
As of January 31, 2020, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for these or other proceedings or matters has been incurred.  However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company’s business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters.  Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company’s business, financial condition, results of operations, or cash flows will depend on a number of variables, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.

[0001571996-20-000017:notes:338]
Indemnifications

[0001571996-20-000017:notes:339]
In the ordinary course of business, the Company enters into contractual arrangements under which it may agree to indemnify the third party to such arrangements from any losses incurred relating to the services it performs on behalf of the Company or for losses arising from certain events as defined in the particular contract, such as litigation or claims relating to past performance.  Such indemnification obligations may not be subject to maximum loss clauses.  Historically, payments related to these indemnifications have not been material to the Company.

[0001571996-20-000017:notes:340]
Certain Concentrations

[0001571996-20-000017:notes:341]
The Company maintains cash and cash equivalents, derivatives, and certain other financial instruments with various financial institutions that potentially subject it to concentration of credit risk.  As part of its risk management processes, the Company performs periodic evaluations of the relative credit standing of these financial institutions.  The Company has not sustained material credit losses from instruments held at these financial institutions.  Further, the Company does not anticipate nonperformance by any of the counterparties.

[0001571996-20-000017:notes:342]
The Company markets and sells its products and services to large corporate clients, governments, and health care and education accounts, as well as to small and medium-sized businesses and individuals.  No single customer accounted for more than 10% of the Company’s consolidated net revenue during the fiscal year ended January 31, 2020, February 1, 2019, or February 2, 2018.

[0001571996-20-000017:notes:343]
The Company utilizes a limited number of contract manufacturers that assemble a portion of its products.  The Company may purchase components from suppliers and sell those components to such contract manufacturers, thereby creating receivables balances from the contract manufacturers.  The agreements with the majority of the contract manufacturers permit the Company to offset its payables against these receivables, thus mitigating the credit risk wholly or in part.  Receivables from the Company’s four largest contract manufacturers represented the majority of the Company’s gross non-trade receivables of $3.2 billion and $3.7 billion as of January 31, 2020 and February 1, 2019, respectively, of which $2.6 billion and $3.2 billion as of January 31, 2020 and February 1, 2019, respectively, have been offset against the corresponding payables.  The portion of receivables not offset against payables is included in other current assets in the Consolidated Statements of Financial Position.  The Company does not reflect the sale of the components in revenue and does not recognize any profit on the component sales until the related products are sold.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001571996-20-000017:notes:344]
NOTE 11 — INCOME AND OTHER TAXES

[0001571996-20-000017:notes:345]
The following table presents components of the income tax benefit recognized for the periods indicated:

[0001571996-20-000017:notes:346]
|  | Fiscal Year Ended |
|  | January 31, 2020 |  | February 1, 2019 |  | February 2, 2018 |
|  | (in millions) |
| Current: |  |  |  |  |  |
| Federal | $ | (150 | ) |  | $ | 461 |  |  | $ | 52 |  |
| State/local | 69 |  |  | 74 |  |  | 111 |  |
| Foreign | 887 |  |  | 616 |  |  | 599 |  |
| Current | 806 |  |  | 1,151 |  |  | 762 |  |
| Deferred: |  |  |  |  |  |
| Federal | (862 | ) |  | (1,150 | ) |  | (2,368 | ) |
| State/local | (150 | ) |  | (85 | ) |  | (139 | ) |
| Foreign | (5,327 | ) |  | (96 | ) |  | (98 | ) |
| Deferred | (6,339 | ) |  | (1,331 | ) |  | (2,605 | ) |
| Income tax benefit | $ | (5,533 | ) |  | $ | (180 | ) |  | $ | (1,843 | ) |

[0001571996-20-000017:notes:347]
The Company’s provision for income taxes for the fiscal periods reflected in the Consolidated Financial Statements are not directly comparable primarily due to the intra-entity asset transfers of certain of its intellectual property completed in the fiscal year ended January 31, 2020 and the enactment of the Tax Cuts and Jobs Act of 2017 (“U.S. Tax Reform”) during the fiscal year ended February 2, 2018.

[0001571996-20-000017:notes:348]
During the fiscal year ended January 31, 2020, the Company completed two intra-entity asset transfers of certain of its intellectual property (the “IP”) to Irish subsidiaries, resulting in discrete tax benefits of $4.9 billion.  The tax benefit for each intra-entity asset transfer was recorded as a deferred tax asset in the period of transaction and represents the book and tax basis difference on the transferred assets measured based on the IP’s current fair value and applicable Irish statutory tax rate.  The Company applied significant judgment when determining the fair value of the IP, which serves as the tax basis of the deferred tax asset, and in evaluating the associated tax laws in the applicable jurisdictions.  The tax deductions for amortization of the assets will be recognized in the future, and any amortization not deducted for tax purposes will be carried forward indefinitely under Irish tax laws.  The Company expects to be able to realize the deferred tax assets resulting from these intra-entity asset transfers.

[0001571996-20-000017:notes:349]
U.S. Tax Reform was signed into law on December 22, 2017.  Among other things, U.S. Tax Reform lowers the U.S. corporate income tax rate to 21% from 35%, establishes a modified territorial system requiring a mandatory deemed repatriation tax on undistributed earnings of foreign subsidiaries (the “Transition Tax”), requires a minimum tax on certain future earnings generated by foreign subsidiaries while providing for future tax-free repatriation of earnings through a 100% dividends-received deduction, and places limitations on the deductibility of net interest expense.  In December 2019, the U.S. Department of the Treasury released final and newly proposed regulations related to foreign tax credits and the base erosion anti-abuse tax, the impact of which was not material.  The Company anticipates that the U.S. Department of the Treasury and the Internal Revenue Service (“IRS”) will continue to issue regulatory guidance clarifying certain provisions of U.S. Tax Reform.  When additional guidance is issued, the Company will recognize the related tax impact of implementation of the guidance in the fiscal quarter of such issuance.  For the fiscal year ended February 2, 2018, the Company recognized a provisional tax benefit of $0.5 billion under the SEC staff’s Accounting Bulletin No. 118.  The provisional tax benefit was primarily attributable to a $1.5 billion tax benefit related to the remeasurement of deferred tax assets and liabilities, offset by $1.0 billion of current and future income tax expenses related to the Transition Tax.  The Company completed its accounting for the income tax effects of U.S. Tax Reform during the fourth quarter of the fiscal year ended February 1, 2019 and determined that the adjustment to the provisional estimate was not material.  These impacts are included in the U.S. Tax Reform in the Company’s effective tax rate reconciliation.

[0001571996-20-000017:notes:350]
The following table presents components of income (loss) before income taxes for the periods indicated:

[0001571996-20-000017:notes:351]
|  | Fiscal Year Ended |
|  | January 31, 2020 |  | February 1, 2019 |  | February 2, 2018 |
|  | (in millions) |
| Domestic | $ | (3,067 | ) |  | $ | (4,645 | ) |  | $ | (5,995 | ) |
| Foreign | 3,063 |  |  | 2,284 |  |  | 1,226 |  |
| Loss before income taxes | $ | (4 | ) |  | $ | (2,361 | ) |  | $ | (4,769 | ) |

[0001571996-20-000017:notes:352]
The following table presents a reconciliation of the Company’s income tax benefit to the statutory U.S. federal tax rate for the periods indicated:

[0001571996-20-000017:notes:353]
|  | Fiscal Year Ended |
|  | January 31, 2020 |  | February 1, 2019 |  | February 2, 2018 |
| U.S. federal statutory rate | 21.0 |  |  | 21.0 |  |  | 33.7 |  |
| State income taxes, net of federal tax benefit | 1194.6 |  |  | 0.5 |  |  | 2.9 |  |
| Tax impact of foreign operations | (2741.3 | ) |  | (19.5 | ) |  | (11.0 | ) |
| Impact of intangible property transfers | 123367.9 |  |  | — |  |  | — |  |
| Change in valuation allowance | 1030.6 |  |  | (6.6 | ) |  | (1.8 | ) |
| Indirect tax effects of adoption of new revenue standard | — |  |  | 6.5 |  |  | — |  |
| U.S. Tax Reform | — |  |  | 1.5 |  |  | 11.6 |  |
| U.S. tax audit settlement | 7615.7 |  |  | — |  |  | — |  |
| Non-deductible transaction-related costs | (700.0 | ) |  | (1.9 | ) |  | — |  |
| Stock-based compensation | 5873.2 |  |  | 4.1 |  |  | 1.6 |  |
| U.S. R&D tax credits | 4424.9 |  |  | 6.9 |  |  | 2.6 |  |
| Other | (1761.6 | ) |  | (4.9 | ) |  | (1.0 | ) |
| Total | 138325.0 | % |  | 7.6 | % |  | 38.6 | % |

[0001571996-20-000017:notes:354]
The change in the Company’s effective tax rate for the fiscal year ended January 31, 2020 as compared to the fiscal year ended February 1, 2019 was primarily driven by discrete tax items and a change in the Company’s jurisdictional mix of income.  For the fiscal year ended January 31, 2020, the Company had $5.5 billion in tax benefits on a loss before income taxes of $4 million.  The change in the Company’s effective tax rate for the fiscal year ended February 1, 2019 as compared to the fiscal year ended February 2, 2018 was primarily attributable to impacts of U.S. Tax Reform.

[0001571996-20-000017:notes:355]
The Company’s effective tax rate for the fiscal year ended January 31, 2020 includes $4.9 billion of discrete tax benefits related to the intra-entity asset transfers described above, $351 million of discrete tax benefits related to stock-based compensation, $305 million of discrete tax benefits related to an audit settlement, and $95 million of discrete tax benefits relating to Virtustream impairment charges discussed in Note 8 of the Notes to the Consolidated Financial Statements and included in Other in the table above.  For the fiscal year ended February 1, 2019, the Company’s effective tax rate included $154 million of discrete tax benefits resulting from the impact of its adoption of the new revenue recognition standard.

[0001571996-20-000017:notes:356]
The differences between the estimated effective income tax rates and the U.S. federal statutory rate of 21% principally result from the Company’s geographical distribution of income and differences between the book and tax treatment of certain items.  In certain jurisdictions, the Company’s tax rate is significantly less than the applicable statutory rate as a result of tax holidays.  The majority of the Company’s foreign income that is subject to these tax holidays and lower tax rates is attributable to Singapore, China, and Malaysia.  A significant portion of these income tax benefits relate to a tax holiday that will be effective until January 31, 2029.  The Company’s other tax holidays will expire in whole or in part during fiscal years 2022 through 2030.  Many of these tax holidays and reduced tax rates may be extended when certain conditions are met or may be terminated early if certain conditions are not met.  As of January 31, 2020, the Company was not aware of any matters of noncompliance related to these tax holidays.  For the fiscal years ended January 31, 2020, February 1, 2019, and February 2, 2018, the income

[0001571996-20-000017:notes:357]
tax benefits attributable to the tax status of the affected subsidiaries were estimated to be approximately $444 million ($0.59 per share of Dell Technologies Common Stock), $313 million ($0.54 per share of DHI Group Common Stock), and $238 million ($0.42 per share of DHI Group Common Stock), respectively.  These income tax benefits are included in tax impact of foreign operations in the table above.

[0001571996-20-000017:notes:358]
Prior to U.S. Tax Reform, the Company had not provided deferred taxes on undistributed earnings of its foreign subsidiaries as it was the Company’s intention for these basis differences to remain indefinitely reinvested.  U.S. Tax Reform fundamentally changes the U.S. approach to taxation of foreign earnings to a partial territorial tax system, which generally allows companies to make distributions of non-U.S. earnings to the United States without incurring additional U.S. tax.  Additionally, as a result of the U.S. Tax Reform measures described above, the Company believes a significant portion of the Company’s undistributed earnings as of January 31, 2020 will not be subject to further U.S. federal taxation.  As of January 31, 2020, the Company has undistributed earnings of certain foreign subsidiaries of approximately $34.1 billion that remain indefinitely reinvested, and as such has not recognized a deferred tax liability.  Determination of the amount of unrecognized deferred income tax liability related to these undistributed earnings is not practicable.

[0001571996-20-000017:notes:359]
The following table presents the components of the Company’s net deferred tax assets (liabilities) as of the dates indicated:

[0001571996-20-000017:notes:360]
|  | January 31, 2020 |  | February 1, 2019 |
|  | (in millions) |
| Deferred tax assets: |  |  |  |
| Deferred revenue and warranty provisions | $ | 1,672 |  |  | $ | 1,267 |  |
| Provisions for product returns and doubtful accounts | 107 |  |  | 117 |  |
| Credit carryforwards | 1,951 |  |  | 1,927 |  |
| Loss carryforwards | 580 |  |  | 466 |  |
| Operating and compensation related accruals | 744 |  |  | 683 |  |
| Operating leases | 239 |  |  | — |  |
| Intangible assets | 2,420 |  |  | — |  |
| Other | 205 |  |  | 193 |  |
| Deferred tax assets | 7,918 |  |  | 4,653 |  |
| Valuation allowance | (1,687 | ) |  | (1,704 | ) |
| Deferred tax assets, net of valuation allowance | 6,231 |  |  | 2,949 |  |
| Deferred tax liabilities: |  |  |  |
| Leasing and financing | (369 | ) |  | (356 | ) |
| Operating leases | (210 | ) |  | — |  |
| Property and equipment | (509 | ) |  | (547 | ) |
| Acquired intangibles | — |  |  | (3,254 | ) |
| Other | (205 | ) |  | (242 | ) |
| Deferred tax liabilities | (1,293 | ) |  | (4,399 | ) |
| Net deferred tax assets (liabilities) | $ | 4,938 |  |  | $ | (1,450 | ) |

[0001571996-20-000017:notes:361]
The following tables present the net operating loss carryforwards, tax credit carryforwards, and other deferred tax assets with related valuation allowances recognized as of the dates indicated:

[0001571996-20-000017:notes:362]
|  | January 31, 2020 |  |  |
|  | Deferred Tax Assets |  | Valuation Allowance |  | Net Deferred Tax Assets |  | First Year Expiring |
|  | (in millions) |  |  |
| Credit carryforwards | $ | 1,951 |  |  | $ | (1,257 | ) |  | $ | 694 |  |  | Fiscal 2021 |
| Loss carryforwards | 580 |  |  | (348 | ) |  | 232 |  |  | Fiscal 2021 |
| Other deferred tax assets | 5,387 |  |  | (82 | ) |  | 5,305 |  |  | NA |
| Total | $ | 7,918 |  |  | $ | (1,687 | ) |  | $ | 6,231 |  |  |  |
|  | February 1, 2019 |  |  |
|  | Deferred Tax Assets |  | Valuation Allowance |  | Net Deferred Tax Assets |  | First Year Expiring |
|  | (in millions) |  |  |
| Credit carryforwards | $ | 1,927 |  |  | $ | (1,152 | ) |  | $ | 775 |  |  | Fiscal 2020 |
| Loss carryforwards | 466 |  |  | (403 | ) |  | 63 |  |  | Fiscal 2020 |
| Other deferred tax assets | 2,260 |  |  | (149 | ) |  | 2,111 |  |  | NA |
| Total | $ | 4,653 |  |  | $ | (1,704 | ) |  | $ | 2,949 |  |  |  |

[0001571996-20-000017:notes:363]
The Company’s credit carryforwards as of January 31, 2020 and February 1, 2019 relate primarily to U.S. tax credits, including foreign tax credits associated with U.S. Tax Reform that will expire in Fiscal 2028.  The Company assessed the realizability of these U.S. tax credits based on currently enacted and proposed regulations issued by the U.S. Department of the Treasury and the IRS and recorded a valuation allowance of $634 million against these assets for the fiscal year ended February 1, 2019, which is included with other impacts of U.S. Tax Reform in the Company’s effective tax rate reconciliation.  The change in the valuation allowance against these credits is included in Change in valuation allowance in the Company’s effective tax reconciliation for the fiscal year ended January 31, 2020.  The Company’s loss carryforwards as of January 31, 2020 and February 1, 2019 include net operating loss carryforwards from federal, state, and foreign jurisdictions.  The valuation allowances for other deferred tax assets as of January 31, 2020 and February 1, 2019 are primarily related to foreign jurisdictions, the changes in which are included in Tax impact of foreign operations in the Company’s effective tax reconciliation.  The Company has determined that it will be able to realize the remainder of its deferred tax assets, based on the future reversal of deferred tax liabilities.

[0001571996-20-000017:notes:364]
The following table presents a reconciliation of the Company’s beginning and ending balances of unrecognized tax benefits for the periods indicated:

[0001571996-20-000017:notes:365]
|  | Fiscal Year Ended |
|  | January 31, 2020 |  | February 1, 2019 |  | February 2, 2018 |
|  | (in millions) |
| Beginning Balance | $ | 2,989 |  |  | $ | 2,867 |  |  | $ | 2,752 |  |
| Increases related to tax positions of the current year | 145 |  |  | 116 |  |  | 155 |  |
| Increases related to tax position of prior years | 332 |  |  | 288 |  |  | 98 |  |
| Reductions for tax positions of prior years | (490 | ) |  | (170 | ) |  | (90 | ) |
| Lapse of statute of limitations | (127 | ) |  | (90 | ) |  | (34 | ) |
| Audit settlements | (402 | ) |  | (22 | ) |  | (14 | ) |
| Ending Balance | $ | 2,447 |  |  | $ | 2,989 |  |  | $ | 2,867 |  |

[0001571996-20-000017:notes:366]
The Company’s net unrecognized tax benefits were $2.5 billion, $3.4 billion, and $3.2 billion as of January 31, 2020, February 1, 2019, and February 2, 2018, respectively, and are included in accrued and other and other non-current liabilities in the Consolidated Statements of Financial Position.

[0001571996-20-000017:notes:367]
The unrecognized tax benefits in the table above include $2.0 billion, $2.4 billion, and $2.2 billion as of January 31, 2020, February 1, 2019, and February 2, 2018, respectively, that, if recognized, would have impacted income tax expense.  The table does not include accrued interest and penalties of $0.8 billion, $1.0 billion, and $0.9 billion as of January 31, 2020, February 1, 2019, and February 2, 2018, respectively.  Tax benefits associated with interest and state tax deductions and other indirect jurisdictional effects of uncertain tax positions were $629 million, $611 million, and $537 million as of January 31, 2020, February 1, 2019, and February 2, 2018, respectively.  Interest and penalties related to income tax liabilities are included in income tax expense.  The Company recorded interest and penalties of $174 million, $127 million, and $184 million for the fiscal years ended January 31, 2020, February 1, 2019, and February 2, 2018, respectively.

[0001571996-20-000017:notes:368]
During the third quarter of the fiscal year ended January 31, 2020, the Company made a cash payment of $438 million in settlement of the IRS audit for fiscal years 2007 through 2009.  In December 2019, the Company received a Revenue Agent’s Report (“RAR”) for the IRS’s examination of fiscal years 2010 through 2014.  The Company disagrees with certain of the proposed assessments and is contesting them through the IRS administrative appeals procedures.  Although this process has been progressing and the timing of any resolution remains uncertain, the Company anticipates reaching a settlement with the IRS in the first half of Fiscal 2021.  The IRS has started its examination of fiscal years 2015 through 2019.  The Company believes it has valid positions supporting its tax returns and that it is adequately reserved.

[0001571996-20-000017:notes:369]
The Company is also currently under income tax audits in various U.S. state and foreign taxing jurisdictions.  The Company is undergoing negotiations, and in some cases contested proceedings, relating to tax matters with the taxing authorities in these jurisdictions.  The Company believes that it has provided adequate reserves related to all matters contained in tax periods open to examination.  Although the Company believes it has made adequate provisions for the uncertainties surrounding these audits, should the Company experience unfavorable outcomes, such outcomes could have a material impact on its results of operations, financial position, and cash flows.  With respect to major U.S. state and foreign taxing jurisdictions, the Company is generally not subject to tax examinations for years prior to the fiscal year ended January 29, 2010.

[0001571996-20-000017:notes:370]
Judgment is required in evaluating the Company’s uncertain tax positions and determining the Company’s provision for income taxes.  Although timing of resolution or closure of uncertain tax positions is not certain, the Company believes it is reasonably possible that certain tax matters in various jurisdictions, including those matters discussed above, could be concluded within the next twelve months.  The resolution of these matters could reduce the Company’s unrecognized tax benefits by an estimated amount of between $550 million to $850 million.  Such a reduction will have a material effect on the Company’s effective tax rate.

[0001571996-20-000017:notes:371]
The Company takes certain non-income tax positions in the jurisdictions in which it operates and has received certain non-income tax assessments from various jurisdictions.  The Company believes that a material loss in these matters is not probable and that it is not reasonably possible that a material loss exceeding amounts already accrued has been incurred.  The Company believes its positions in these non-income tax litigation matters are supportable and that it ultimately will prevail in the matters.  In the normal course of business, the Company’s positions and conclusions related to its non-income taxes could be challenged and assessments may be made.  To the extent new information is obtained and the Company’s views on its positions, probable outcomes of assessments, or litigation change, changes in estimates to the Company’s accrued liabilities would be recorded in the period in which such a determination is made.  In the resolution process for income tax and non-income tax audits, the Company is required in certain situations to provide collateral guarantees or indemnification to regulators and tax authorities until the matter is resolved.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001571996-20-000017:notes:372]
NOTE 12 — ACCUMULATED OTHER COMPREHENSIVE INCOME (LOSS)

[0001571996-20-000017:notes:373]
Accumulated other comprehensive income (loss) is presented in stockholders’ equity (deficit) in the Consolidated Statements of Financial Position and consists of amounts related to foreign currency translation adjustments, unrealized net gains (losses) on investments, unrealized net gains (losses) on cash flow hedges, and actuarial net gains (losses) from pension and other postretirement plans.

[0001571996-20-000017:notes:374]
The following table presents changes in accumulated other comprehensive income (loss), net of tax, by the following components as of the dates indicated:

[0001571996-20-000017:notes:375]
|  | Foreign Currency Translation Adjustments |  | Investments |  | Cash Flow Hedges |  | Pension and Other Postretirement Plans |  | Accumulated Other Comprehensive Income (Loss) |
|  | (in millions) |
| Balances as of February 3, 2017 | $ | (612 | ) |  | $ | (13 | ) |  | $ | 11 |  |  | $ | 19 |  |  | $ | (595 | ) |
| Other comprehensive income (loss) before reclassifications | 791 |  |  | 31 |  |  | (248 | ) |  | 13 |  |  | 587 |  |
| Amounts reclassified from accumulated other comprehensive income (loss) | — |  |  | 2 |  |  | 134 |  |  | — |  |  | 136 |  |
| Total change for the period | 791 |  |  | 33 |  |  | (114 | ) |  | 13 |  |  | 723 |  |
| Less: Change in comprehensive loss attributable to non-controlling interests | — |  |  | (2 | ) |  | — |  |  | — |  |  | (2 | ) |
| Balances as of February 2, 2018 | 179 |  |  | 22 |  |  | (103 | ) |  | 32 |  |  | 130 |  |
| Adjustment for adoption of accounting standards (Note 2) | — |  |  | (61 | ) |  | — |  |  | 3 |  |  | (58 | ) |
| Other comprehensive income (loss) before reclassifications | (631 | ) |  | 2 |  |  | 299 |  |  | (21 | ) |  | (351 | ) |
| Amounts reclassified from accumulated other comprehensive income (loss) | — |  |  | 43 |  |  | (225 | ) |  | — |  |  | (182 | ) |
| Total change for the period | (631 | ) |  | (16 | ) |  | 74 |  |  | (18 | ) |  | (591 | ) |
| Less: Change in comprehensive income attributable to non-controlling interests | — |  |  | 6 |  |  | — |  |  | — |  |  | 6 |  |
| Balances as of February 1, 2019 | (452 | ) |  | — |  |  | (29 | ) |  | 14 |  |  | (467 | ) |
| Other comprehensive income (loss) before reclassifications | (226 | ) |  | — |  |  | 269 |  |  | (60 | ) |  | (17 | ) |
| Amounts reclassified from accumulated other comprehensive income (loss) | — |  |  | — |  |  | (226 | ) |  | 1 |  |  | (225 | ) |
| Total change for the period | (226 | ) |  | — |  |  | 43 |  |  | (59 | ) |  | (242 | ) |
| Less: Change in comprehensive income (loss) attributable to non-controlling interests | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Balances as of January 31, 2020 | $ | (678 | ) |  | $ | — |  |  | $ | 14 |  |  | $ | (45 | ) |  | $ | (709 | ) |

[0001571996-20-000017:notes:376]
Amounts related to investments are reclassified to net income (loss) when gains and losses are realized.  See Note 3 of the Notes to the Consolidated Financial Statements for more information on the Company’s investments.  Amounts related to the Company’s cash flow hedges are reclassified to net income during the same period in which the items being hedged are recognized in earnings.  See Note 7 of the Notes to the Consolidated Financial Statements for more information on the Company’s derivative instruments.

[0001571996-20-000017:notes:377]
The following tables presents reclassifications out of accumulated other comprehensive income (loss), net of tax, to net income (loss) for the periods indicated:

[0001571996-20-000017:notes:378]
|  | Fiscal Year Ended |
|  | January 31, 2020 |
|  | Investments |  | Cash Flow Hedges |  | Pensions |  | Total |
|  | (in millions) |
| Total reclassifications, net of tax: |  |  |  |  |  |  |  |
| Net revenue | $ | — |  |  | $ | 226 |  |  | $ | — |  |  | $ | 226 |  |
| Operating expenses | — |  |  | — |  |  | (1 | ) |  | (1 | ) |
| Interest and other, net | — |  |  | — |  |  | — |  |  | — |  |
| Total reclassifications, net of tax | $ | — |  |  | $ | 226 |  |  | $ | (1 | ) |  | $ | 225 |  |

[0001571996-20-000017:notes:379]
|  | Fiscal Year Ended |
|  | February 1, 2019 |
|  | Investments |  | Cash Flow Hedges |  | Pensions |  | Total |
|  | (in millions) |
| Total reclassifications, net of tax: |  |  |  |  |  |  |  |
| Net revenue | $ | — |  |  | $ | 225 |  |  | $ | — |  |  | $ | 225 |  |
| Operating expenses | — |  |  | — |  |  | — |  |  | — |  |
| Interest and other, net | (43 | ) |  | — |  |  | — |  |  | (43 | ) |
| Total reclassifications, net of tax | $ | (43 | ) |  | $ | 225 |  |  | $ | — |  |  | $ | 182 |  |


## us-gaap:MinorityInterestDisclosureTextBlock

[0001571996-20-000017:notes:380]
NOTE 13 — NON-CONTROLLING INTERESTS

[0001571996-20-000017:notes:381]
VMware, Inc. — The non-controlling interests’ share of equity in VMware, Inc. is reflected as a component of the non-controlling interests in the Consolidated Statements of Financial Position and was $4.6 billion and $3.8 billion as of January 31, 2020 and February 1, 2019, respectively.  As of January 31, 2020 and February 1, 2019, the Company held approximately 80.9% and 80.5%, respectively, of the outstanding equity interest in VMware, Inc.  Restricted stock awards (“RSAs”) of VMware, Inc. were not included in the determination of these ownership interest percentages, as VMware, Inc. had no RSAs outstanding as of January 31, 2020 or February 1, 2019.

[0001571996-20-000017:notes:382]
Pivotal — As a result of VMware, Inc.’s acquisition of the non-controlling interest in Pivotal from Pivotal’s public shareholders on December 30, 2019, the non-controlling interests’ share of equity in Pivotal is only reflected as a component of the non-controlling interest through December 30, 2019.  Pivotal’s Class A common stock ceased to be listed and traded on the NYSE as of the acquisition date, and Dell Technologies did not have a non-controlling interest in Pivotal as of January 31, 2020.  For more information regarding VMware Inc.’s acquisition of Pivotal, see Note 1 of the Notes to the Consolidated Financial Statements.

[0001571996-20-000017:notes:383]
As of February 1, 2019, the non-controlling interests’ share of equity in Pivotal was reflected as a component of the non-controlling interest in the accompanying Consolidated Statements of Financial Position and was $983 million.  The Company held approximately 62.8% of the outstanding equity interest in Pivotal as of February 1, 2019.

[0001571996-20-000017:notes:384]
Secureworks — The non-controlling interests’ share of equity in Secureworks is reflected as a component of the non-controlling interests in the Consolidated Statements of Financial Position and was $88 million and $87 million as of January 31, 2020 and February 1, 2019, respectively.  As of January 31, 2020 and February 1, 2019, the Company held approximately 86.8% and 87.4%, respectively, of the outstanding equity interest in Secureworks, excluding RSAs.  As of January 31, 2020 and February 1, 2019, the Company held approximately 86.2% and 86.4%, respectively, of the outstanding equity interest in Secureworks, including RSAs.

[0001571996-20-000017:notes:385]
The effect of changes in the Company’s ownership interest in VMware, Inc., Pivotal, and Secureworks on the Company’s equity was as follows:

[0001571996-20-000017:notes:386]
|  | Fiscal Year Ended |
|  | January 31, 2020 |
|  | (in millions) |
| Net income attributable to Dell Technologies Inc. | $ | 4,616 |  |
| Transfers (to)/from the non-controlling interests: |  |
| Increase in Dell Technologies Inc. additional paid-in-capital for equity issuances and other equity activity | 1,997 |  |
| Decrease in Dell Technologies Inc. additional paid-in-capital and accumulated deficit for equity issuances and other equity activity | (3,318 | ) |
| Net transfers to non-controlling interests | (1,321 | ) |
| Change from net income attributable to Dell Technologies Inc. and transfers to the non-controlling interests | $ | 3,295 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001571996-20-000017:notes:387]
NOTE 14 — CAPITALIZATION

[0001571996-20-000017:notes:388]
The following table presents the Company’s authorized, issued, and outstanding common stock as of the dates indicated:

[0001571996-20-000017:notes:389]
|  | Authorized |  | Issued |  | Outstanding |
|  | (in millions) |
| Common stock as of February 1, 2019 |
| Class A | 600 |  |  | 410 |  |  | 410 |  |
| Class B | 200 |  |  | 137 |  |  | 137 |  |
| Class C | 7,900 |  |  | 174 |  |  | 172 |  |
| Class D | 100 |  |  | — |  |  | — |  |
| Class V | 343 |  |  | — |  |  | — |  |
|  | 9,143 |  |  | 721 |  |  | 719 |  |
| Common stock as of January 31, 2020 |
| Class A | 600 |  |  | 385 |  |  | 385 |  |
| Class B | 200 |  |  | 102 |  |  | 102 |  |
| Class C | 7,900 |  |  | 258 |  |  | 256 |  |
| Class D | 100 |  |  | — |  |  | — |  |
| Class V | 343 |  |  | — |  |  | — |  |
|  | 9,143 |  |  | 745 |  |  | 743 |  |

[0001571996-20-000017:notes:390]
Under the Company’s certificate of incorporation as amended and restated upon the completion of the Class V transaction described below, the Company is prohibited from issuing any of the authorized shares of Class V Common Stock.

[0001571996-20-000017:notes:391]
Preferred Stock

[0001571996-20-000017:notes:392]
The Company is authorized to issue one million shares of preferred stock, par value $0.01 per share.  As of January 31, 2020 and February 1, 2019, no shares of preferred stock were issued or outstanding.

[0001571996-20-000017:notes:393]
Common Stock

[0001571996-20-000017:notes:394]
Common Stock for Fiscal 2020 and Thereafter

[0001571996-20-000017:notes:395]
Dell Technologies Common Stock — For Fiscal 2020, the Class A Common Stock, the Class B Common Stock, the Class C Common Stock, and the Class D Common Stock, formerly collectively referred to as the DHI Group Common Stock, are collectively referred to as Dell Technologies Common Stock.  The redesignation of such classes of common stock from DHI Group Common Stock to Dell Technologies Common Stock is intended to align the Company’s reporting with how such classes are referred to by securities analysts, investors, and other users of the financial statements since the completion on December 28, 2018 of the Class V transaction described below.  As a result of the cancellation of all outstanding Class V Common Stock upon the closing of that transaction, there is no requirement after the fourth quarter of Fiscal 2019 to allocate net income (loss) between two separate groups of common stock denoted the DHI Group Common Stock and the Class V Common Stock or to report earnings (loss) per share for each such group.  Accordingly, net income (loss), earnings (loss) per share and other relevant information are reported for Dell Technologies Common Stock for all fiscal periods beginning with the first quarter of Fiscal 2020 and, because of lack of comparability with the new reporting, are reported separately for the DHI Group and the Class V Common Stock, as applicable, for prior fiscal periods.  The par value for all classes of Dell Technologies Common Stock is $0.01 per share.  For purposes of calculating earnings (loss) per share, the Company continues to use the two-class method.  The Class A Common Stock, the Class B Common Stock, the Class C Common Stock, and the Class D Common Stock share equally in dividends declared or accumulated and have equal participation rights in undistributed earnings.  As a result, earnings (loss) per share are the same for all classes of Dell Technologies Common Stock and are presented together.

[0001571996-20-000017:notes:396]
Common Stock prior to Fiscal 2020

[0001571996-20-000017:notes:397]
DHI Group Common Stock and DHI Group — For the fiscal periods prior to Fiscal 2020, the Class A Common Stock, the Class B Common Stock, the Class C Common Stock, and the Class D Common Stock were collectively referred to as the DHI Group Common Stock.  All classes of DHI Group Common Stock have a par value of $0.01 per share, and the Class A Common Stock, the Class B Common Stock, the Class C Common Stock, and the Class D Common Stock share equally in dividends declared or accumulated and have equal participation rights in undistributed earnings.  Prior to the completion on December 28, 2018 of the Class V transaction, the DHI Group referred to the direct and indirect interest of Dell Technologies in all of Dell Technologies’ business, assets, properties, liabilities, and preferred stock other than those attributable to the Class V Group, as well as the DHI Group’s retained interest in the Class V Group.  Subsequent to the completion of the Class V transaction, the DHI Group refers to all classes of issued and outstanding DHI Group Common Stock.

[0001571996-20-000017:notes:398]
Class V Common Stock and Class V Group — The Class V Common Stock was a class of common stock intended to track the performance of a portion of Dell Technologies’ economic interest in the Class V Group.  The Class V Group consisted solely of VMware, Inc. common stock held by the Company.  As of January 31, 2020, no shares of Class V Common Stock remained outstanding.

[0001571996-20-000017:notes:399]
Voting Rights — Each holder of record of (a) Class A Common Stock is entitled to ten votes per share of Class A Common Stock; (b) Class B Common Stock is entitled to ten votes per share of Class B Common Stock; (c) Class C Common Stock is entitled to one vote per share of Class C Common Stock; and (d) Class D Common Stock is not entitled to any vote on any matter except to the extent required by provisions of Delaware law (in which case such holder is entitled to one vote per share of Class D Common Stock).

[0001571996-20-000017:notes:400]
Conversion Rights — Under the Company’s certificate of incorporation, at any time and from time to time, any holder of Class A Common Stock or Class B Common Stock has the right to convert all or any of the shares of Class A Common Stock or Class B Common Stock, as applicable, held by such holder into shares of Class C Common Stock on a one-to-one basis.  During the fiscal year ended January 31, 2020, the Company issued 35,822,123 shares of Class C Common Stock to  stockholders upon their conversion of the same number of shares of Class A Common Stock into Class C Common Stock in accordance with the Company’s certificate of incorporation.  During the fiscal year ended January 31, 2020, the Company issued 35,301,641 shares of Class C Common Stock to stockholders upon their conversion of the same number of shares of Class B Common Stock into Class C Common Stock in accordance with the Company’s certificate of incorporation.

[0001571996-20-000017:notes:401]
Class V Transaction

[0001571996-20-000017:notes:402]
On December 28, 2018, the Company completed a transaction, referred to as the “Class V transaction,” pursuant to an Agreement and Plan of Merger (the “Merger Agreement”), dated as of July 1, 2018 and amended as of November 14, 2018, between Dell Technologies and Teton Merger Sub Inc. (“Merger Sub”), a Delaware corporation and wholly-owned subsidiary of Dell Technologies.  Pursuant to the Merger Agreement, Merger Sub was merged with and into Dell Technologies (the “Merger”), with Dell Technologies continuing as the surviving corporation.

[0001571996-20-000017:notes:403]
Dell Technologies completed the Class V transaction following approval of the transaction by its stockholders at a special meeting held on December 11, 2018.  Dell Technologies paid $14.0 billion in cash and issued 149,387,617 shares of its Class C Common Stock in connection with the Class V transaction.  The non-cash consideration portion of the Class V transaction totaled $6.9 billion.  The Class C Common Stock began trading on the NYSE on a when-issued basis as of the opening of trading on December 26, 2018 and on a regular-way basis as of the opening of trading on December 28, 2018.  The Class V Common Stock ceased trading on the NYSE prior to the opening of trading on December 28, 2018.

[0001571996-20-000017:notes:404]
The Class V Common Stock was a class of common stock intended to track the economic performance of a portion of the Company’s interest in the Class V Group, which consisted solely of VMware, Inc. common stock held by the Company.  As a result of the Class V transaction, pursuant to which all outstanding shares of Class V Common Stock ceased to be outstanding, the tracking stock feature of the Company’s capital structure was terminated.  The Class C Common Stock issued to former holders of the Class V Common Stock represents an interest in the Company’s entire business and, unlike the Class V Common Stock, is not intended to track the performance of any distinct assets or business.  The Company’s amended and restated

[0001571996-20-000017:notes:405]
certificate of incorporation that went into effect as of the effective time of the Merger (the “Effective Time”) prohibits the Company from issuing shares of Class V Common Stock.

[0001571996-20-000017:notes:406]
At the Effective Time, each outstanding share of Class V Common Stock was exchanged for either (a) $120.00 in cash, without interest, subject to a cap of $14.0 billion on the aggregate cash consideration, or (b) 1.8066 shares of Class C Common Stock.  The exchange ratio was calculated based on the aggregate amount of cash elections, as well as the aggregate volume-weighted average price per share of Class V Common Stock on the NYSE (as reported on Bloomberg) of $104.8700 for the period of 17 consecutive trading days that began on November 28, 2018 and ended on December 21, 2018.

[0001571996-20-000017:notes:407]
The aggregate cash consideration and the fees and expenses incurred in connection with the Class V transaction were funded with proceeds of $3.67 billion from new term loans under the Company’s senior secured credit facilities, proceeds of a margin loan financing in an aggregate principal amount of $1.35 billion, proceeds of the Company’s pro-rata portion, in the amount of $8.87 billion, of a special $11 billion cash dividend paid by VMware, Inc. in connection with the Class V transaction, and cash on hand at Dell Technologies and its subsidiaries.  See Note 6 of the Notes to the Consolidated Financial Statements for information about the debt incurred by the Company to finance the Class V transaction.

[0001571996-20-000017:notes:408]
The Merger and the Class V transaction have been accounted for as a hybrid liability and equity transaction involving the repurchase of outstanding common stock, with the consideration consisting of a variable combination of cash and shares.  Upon settlement, the accounting for the Class V transaction reflected that the outstanding Class V Common Stock was canceled and exchanged for shares of Class C Common Stock or $120.00 per share in cash or combination of cash and shares, depending on each holder’s election and subject to proration of the cash elections.  The variable nature of the cash obligation to repurchase the shares of Class V Common Stock required the Company to settle a portion of the shares in exchange for cash and therefore was accounted for as a financial instrument with an immaterial mark-to-market adjustment for the change in fair value from the date of the stockholder meeting at which the Company’s stockholders voted to approve the Class V transaction to the election deadline by which holders of Class V Common Stock elected the form of consideration for which they exchanged their shares.

[0001571996-20-000017:notes:409]
For additional information about the Class V transaction, see “Part I — Item 1 — Business” included in this the Company’s annual report on Form 10-K for the fiscal year ended January 31, 2020.

[0001571996-20-000017:notes:410]
Repurchases of Common Stock and Treasury Stock

[0001571996-20-000017:notes:411]
Class V Common Stock Repurchases by Dell Technologies Inc.

[0001571996-20-000017:notes:412]
Prior to the Class V transaction and since the date of the EMC merger transaction, the Company authorized several programs to repurchase shares of its Class V Common Stock.  As of February 1, 2019, no amounts of the $2.1 billion total authorized repurchases under the various programs remained available.  The DHI Group Repurchase program described below was suspended as of December 13, 2016 and the $676 million remaining repurchases authorized expired two years after the authorization date.  All $1.1 billion authorized under various Class V Group Repurchase Programs described below were fully utilized as of the fiscal year ended February 2, 2018.  The Company repurchased no shares of Class V Common Stock under repurchase programs during the fiscal year ended February 1, 2019.

[0001571996-20-000017:notes:413]
On September 7, 2016, the board of directors of the Company approved a stock repurchase program (the “DHI Group Repurchase Program”) under which the Company was authorized to use assets of the DHI Group to repurchase up to $1.0 billion shares of Class V Common Stock over a period of  two years.  On December 13, 2016, the board of directors approved the suspension of the DHI Group Repurchase Program until such time as the board of directors authorized the reinstatement of that program.  Shares repurchased under the DHI Group Repurchase Program were held as treasury stock at cost until the completion of the Class V transaction, at which time all shares of Class V Common Stock held in treasury were retired.  As cash of the DHI Group was used for Class V Common Stock repurchases under the DHI Group Repurchase Program, these repurchased shares were attributed to the DHI Group for the purposes of determining the DHI Group’s retained interest in the Class V Group.  As a result, the number of retained interest shares of the DHI Group, which, together with the number of shares of Class V Common Stock outstanding, were used to calculate such retained interest, increased on a one-for-one basis for each share of Class V Common Stock repurchased under the program.

[0001571996-20-000017:notes:414]
On March 27, 2017 and August 18, 2017, the board of directors approved two amendments of the Class V Group Repurchase Program (the “March 2017 Class V Group Repurchase Program” and the “August 2017 Class V Group Repurchase Program,” respectively) which, when combined, authorized the Company to use assets of the Class V Group to repurchase up to an additional $600 million of Class V Common Stock over additional six month periods from the respective board approval dates.  On May 9, 2017, the Company completed the March 2017 Class V Group Repurchase Program, pursuant to which it repurchased 4.6 million shares of Class V Common Stock for $300 million.  On October 31, 2017, the Company completed the August 2017 Class V Group Repurchase Program, pursuant to which it repurchased 3.8 million shares of Class V Common Stock for $300 million.  The repurchase of shares pursuant to the Class V Group repurchase programs was funded from proceeds received by the Class V Group from the sale by a subsidiary of the Company of shares of Class A common stock of VMware, Inc. owned by such subsidiary, as described below under “Class A Common Stock Repurchases by VMware, Inc.” Share repurchases made by VMware, Inc. of its Class A common stock from a subsidiary of the Company did not affect the determination of the respective interests of the Class V Common Stock and the DHI Group in the Class V Group.  Shares repurchased under the V Group Repurchase Program were held as treasury stock at cost until the retirement of such shares upon the completion of the Class V transaction.

[0001571996-20-000017:notes:415]
The following table presents the repurchase activity with respect to the Class V Common Stock through the completion of the Class V transaction as of the dates indicated:

[0001571996-20-000017:notes:416]
|  | Class V Common Stock |  | DHI Group Retained Interest |
|  | Shares of Class V Common Stock |  | Interest in Class V Group |  | Retained Interest Shares |  | Interest in Class V Group |
|  | (in millions, except percentages) |
| As of February 3, 2017 | 209 |  |  | 62% |  | 127 |  |  | 38% |
| Class V Group Repurchase Program | (10 | ) |  |  |  | — |  |  |  |
| As of February 2, 2018 | 199 |  |  | 61% |  | 127 |  |  | 39% |
| Repurchases of Class V Common Stock | (199 | ) |  |  |  | (127 | ) |  |  |
| As of December 28, 2018 | — |  |  | —% |  | — |  |  | —% |

[0001571996-20-000017:notes:417]
As a result of the Class V transaction, pursuant to which all 199,356,591 outstanding shares of Class V Common Stock ceased to be outstanding, the tracking stock feature of the Company’s capital structure was terminated.

[0001571996-20-000017:notes:418]
DHI Group Common Stock Repurchases

[0001571996-20-000017:notes:419]
Prior to the Class V transaction during the fiscal year ended February 1, 2019, the Company repurchased approximately one million shares of DHI Group Common Stock for approximately $47 million.  During the fiscal year ended February 2, 2018, the Company repurchased an immaterial number of shares of DHI Group Common Stock for approximately $6 million.

[0001571996-20-000017:notes:420]
All shares of DHI Group Common Stock repurchased by the Company were held as treasury stock at cost.

[0001571996-20-000017:notes:421]
VMware, Inc. Class A Common Stock Repurchases by VMware, Inc.

[0001571996-20-000017:notes:422]
On May 29, 2019, VMware, Inc.’s board of directors authorized the repurchase of an additional $1.5 billion of VMware, Inc.’s Class A common stock.  Since the date of the EMC merger transaction, VMware, Inc.’s board of directors has authorized total repurchases of  $3.7 billion, of which $1.0 billion remained available as of January 31, 2020.  During fiscal year ended January 31, 2020, VMware repurchased 7.7 million shares of its Class A common stock on the open market for approximately $1.3 billion, of which approximately $0.2 billion impacted Dell Technologies’ accumulated deficit balance as of January 31, 2020 as a result of periodic depletion of VMware, Inc.’s additional paid-in capital balance.  During the fiscal year ended February 1, 2019, VMware, Inc. repurchased 0.3 million shares of its Class A common stock in the open market for approximately $42 million.

[0001571996-20-000017:notes:423]
On December 15, 2016, the Company entered into a stock purchase agreement with VMware, Inc. (the “December 2016 Stock Purchase Agreement”), pursuant to which VMware, Inc. agreed to repurchase for cash $500 million of shares of VMware, Inc. Class A common stock from a subsidiary of the Company.  During the fiscal year ended February 2, 2018, VMware, Inc. repurchased 1.4 million shares for $125 million pursuant to and in completion of the December 2016 Stock Purchase Agreement.  VMware, Inc. repurchased a total of 6.2 million shares under this agreement, including shares repurchased during the fiscal year ended February 3, 2017.  The Company applied the proceeds from the sale to the repurchase of shares of its Class V Common Stock under the Class V Group Repurchase Program described above.

[0001571996-20-000017:notes:424]
In January 2017 and August 2017, VMware, Inc.’s board of directors authorized the repurchase of up to $2.2 billion of shares of VMware, Inc. Class A common stock (the “January 2017 Authorization” for up to $1.2 billion through the end of Fiscal 2018, and the “August 2017 Authorization” for up to $1.0 billion through August 31, 2018).  In July 2018, VMware, Inc.’s board of directors extended the August 2017 Authorization through August 31, 2019.

[0001571996-20-000017:notes:425]
On March 29, 2017 and August 23, 2017, the Company entered into two new stock purchase agreements with VMware, Inc. (the “March 2017 Stock Purchase Agreement” and the “August 2017 Stock Purchase Agreement,” respectively), pursuant to which VMware, Inc. agreed to repurchase for cash a total of $600 million of VMware, Inc. Class A common stock from a subsidiary of the Company.  VMware, Inc. repurchased approximately 6.1 million shares of Class A common stock, consisting of 3.4 million shares pursuant to the March 2017 Stock Purchase Agreement and 2.7 million shares pursuant to the August 2017 Stock Purchase Agreement.  The proceeds from the sales were applied by the Company to the repurchase of shares of the Class V Common Stock under the March 2017 and August 2017 Class V Group Repurchase Programs described above.  As of November 3, 2017, the sale transactions under the March 2017 and August 2017 Stock Purchase Agreements were completed.  The purchase prices of the 3.4 million shares and 2.7 million shares repurchased by VMware, Inc. were each based on separate volume-weighted average per share prices of the Class A common stock as reported on the NYSE during separate specified reference periods, less a discount of 3.5% from the respective volume-weighted average per share price.  During the fiscal year ended February 2, 2018, VMware, Inc. repurchased 6.4 million shares of its Class A common stock in the open market for $724 million.  During the period from September 7, 2016 through February 3, 2017, VMware, Inc. repurchased 8.3 million shares of its Class A common stock in the open market for $611 million.

[0001571996-20-000017:notes:426]
All shares repurchased under VMware, Inc.’s stock repurchase programs are retired.


## us-gaap:EarningsPerShareTextBlock

[0001571996-20-000017:notes:427]
NOTE 15 — EARNINGS (LOSS) PER SHARE

[0001571996-20-000017:notes:428]
Basic earnings (loss) per share is based on the weighted-average effect of all common shares issued and outstanding and is calculated by dividing net income (loss) by the weighted-average shares outstanding during the period.  Diluted earnings (loss) per share is calculated by dividing net income (loss) by the weighted-average number of common shares used in the basic earnings (loss) per share calculation plus the number of common shares that would be issued assuming exercise or conversion of all potentially dilutive instruments.  The Company excludes equity instruments from the calculation of diluted earnings (loss) per share if the effect of including such instruments is antidilutive.

[0001571996-20-000017:notes:429]
Until the completion on December 28, 2018 of the Class V transaction described in Note 14 of the Notes to the Consolidated Financial Statements, the Company had two groups of common stock, denoted as the DHI Group Common Stock and the Class V Common Stock.

[0001571996-20-000017:notes:430]
The Class V Common Stock was a class of common stock intended to track the economic performance of 61% of the Company’s interest in the Class V Group, which consisted solely of VMware, Inc. common stock held by the Company, as of February 2, 2018 and as of immediately before the completion of the Class V transaction.  Upon the completion of the Class V transaction, all outstanding shares of Class V Common Stock ceased to be outstanding, and the tracking stock structure was terminated.  The Class C Common Stock issued to former holders of the Class V Common Stock in the Class V transaction represents an interest in the Company’s entire business and, unlike the Class V Common Stock, is not intended to track the performance of any distinct assets or business.

[0001571996-20-000017:notes:431]
Prior to the fiscal year ended January 31, 2020, the DHI Group Common Stock consisted of four classes of common stock, including the Class A Common Stock, the Class B Common Stock, the Class C Common Stock, and the Class D Common Stock.  Prior to the completion of the Class V transaction, the DHI Group referred to the direct and indirect interest of Dell Technologies in all of Dell Technologies’ business, assets, properties, liabilities, and preferred stock other than those attributable to the Class V Group, as well as the DHI Group’s retained interest in the Class V Group.  Subsequent to the completion of the Class V transaction, the DHI Group refers to all classes of issued and outstanding DHI Group Common Stock.

[0001571996-20-000017:notes:432]
For purposes of calculating earnings (loss) per share, the Company continues to use the two-class method.  The Class A Common Stock, the Class B Common Stock, the Class C Common Stock, and the Class D Common Stock share equally in dividends declared or accumulated and have equal participation rights in undistributed earnings.  As a result, earnings (loss) per share are the same for all classes of Dell Technologies Common Stock and are presented together.

[0001571996-20-000017:notes:433]
The Company accounted for the VMware, Inc. acquisition of the controlling interest in Pivotal from Dell Technologies described in Note 1 of the Notes to the Consolidated Financial Statements as a transaction by entities under common control.  Consequently, the Pivotal acquisition had no net effect on the Company’s consolidated financial statements or earnings (loss) per share as previously reported, which includes the periods in which the Class V Common Stock was outstanding.

[0001571996-20-000017:notes:434]
The following table presents basic and diluted earnings (loss) per share for the periods indicated:

[0001571996-20-000017:notes:435]
|  | Fiscal Year Ended |
|  | January 31, 2020 |  | February 1, 2019 |  | February 2, 2018 |
| Earnings (loss) per share attributable to Dell Technologies Inc. — basic: |
| Dell Technologies Common Stock | $ | 6.38 |  |  |  |  |  |
| Class V Common Stock |  |  | $ | 6.01 |  |  | $ | 1.63 |  |
| DHI Group |  |  | $ | (6.02 | ) |  | $ | (5.61 | ) |
| Earnings (loss) per share attributable to Dell Technologies Inc. — diluted: |
| Dell Technologies Common Stock | $ | 6.03 |  |  |  |  |  |
| Class V Common Stock |  |  | $ | 5.91 |  |  | $ | 1.61 |  |
| DHI Group |  |  | $ | (6.04 | ) |  | $ | (5.62 | ) |

[0001571996-20-000017:notes:436]
The following table presents the computation of basic and diluted earnings (loss) per share for the periods indicated:

[0001571996-20-000017:notes:437]
|  | Fiscal Year Ended |
|  | January 31, 2020 |
|  | (in millions) |
| Numerator: Dell Technologies Common Stock |  |
| Net income attributable to Dell Technologies — basic | $ | 4,616 |  |
| Incremental dilution from VMware, Inc. attributable to Dell Technologies (a) | (84 | ) |
| Net income attributable to Dell Technologies — diluted | $ | 4,532 |  |
| Denominator: Dell Technologies Common Stock weighted-average shares outstanding |  |
| Weighted-average shares outstanding — basic | 724 |  |
| Dilutive effect of options, restricted stock units, restricted stock, and other | 27 |  |
| Weighted-average shares outstanding — diluted | 751 |  |
| Weighted-average shares outstanding — antidilutive | — |  |

[0001571996-20-000017:notes:438]
| (a) | The incremental dilution from VMware, Inc. represents the impact of VMware, Inc.’s dilutive securities on diluted earnings (loss) per share of Dell Technologies Common Stock, and is calculated by multiplying the difference between VMware, Inc.’s basic and diluted earnings (loss) per share by the number of shares of VMware, Inc. common stock held by the Company. For the fiscal year ended January 31, 2020, incremental dilution from VMware, Inc. was calculated by the Company without regard to VMware Inc.’s required retrospective adjustments for the Pivotal acquisition in its stand-alone financial statements. There is no incremental dilution from Pivotal and Secureworks due to the net loss position of these entities for the periods presented. |

[0001571996-20-000017:notes:439]
The following table presents the computation of basic and diluted earnings (loss) per share prior to the fiscal year ended January 31, 2020 for the periods indicated:

[0001571996-20-000017:notes:440]
|  | Fiscal Year Ended |
|  | February 1, 2019 |  | February 2, 2018 |
|  | (in millions) |
| Numerator: Class V Common Stock |  |  |  |
| Net income attributable to Class V Common Stock — basic (a) | $ | 1,195 |  |  | $ | 331 |  |
| Incremental dilution from VMware, Inc. attributable to Class V Common Stock (b) | (18 | ) |  | (5 | ) |
| Net income attributable to Class V Common Stock — diluted | $ | 1,177 |  |  | $ | 326 |  |
| Numerator: DHI Group |  |  |  |
| Net loss attributable to DHI Group — basic | $ | (3,505 | ) |  | $ | (3,180 | ) |
| Incremental dilution from VMware, Inc. attributable to DHI Group (b) | (13 | ) |  | (4 | ) |
| Net loss attributable to DHI Group — diluted | $ | (3,518 | ) |  | $ | (3,184 | ) |
| Denominator: Class V Common Stock weighted-average shares outstanding |  |  |  |  |
| Weighted-average shares outstanding — basic (c) | 199 |  |  | 203 |  |
| Dilutive effect of options, restricted stock units, restricted stock, and other (d) | — |  |  | — |  |
| Weighted-average shares outstanding — diluted | 199 |  |  | 203 |  |
| Weighted-average shares outstanding — antidilutive (d) | — |  |  | — |  |
| Denominator: DHI Group weighted-average shares outstanding |  |  |  |
| Weighted-average shares outstanding — basic (e) | 582 |  |  | 567 |  |
| Dilutive effect of options, restricted stock units, restricted stock, and other | — |  |  | — |  |
| Weighted-average shares outstanding — diluted | 582 |  |  | 567 |  |
| Weighted-average shares outstanding — antidilutive (f) | 44 |  |  | 35 |  |

[0001571996-20-000017:notes:441]
| (a) | For the fiscal year ended February 1, 2019, net income attributable to the Class V Common Stock - basic represents net income attributable to the Class V Group for the period ended December 27, 2018, the last date on which the Class V Common Stock was traded on the NYSE. |

[0001571996-20-000017:notes:442]
| (b) | The incremental dilution from VMware, Inc. represents the impact of VMware, Inc.’s dilutive securities on the diluted earnings (loss) per share of the DHI Group and the Class V Common Stock, respectively, and is calculated by multiplying the difference between VMware, Inc.’s basic and diluted earnings (loss) per share by the number of shares of VMware, Inc. common stock held by the Company. |

[0001571996-20-000017:notes:443]
| (c) | For the fiscal year ended February 1, 2019, the Class V Common Stock weighted-average shares outstanding - basic represents the weighted-average for the period ended December 27, 2018, the last date on which the Class V Common Stock was traded on the NYSE. |

[0001571996-20-000017:notes:444]
| (d) | The dilutive effect of Class V Common Stock-based incentive awards was not material to the calculation of the weighted-average Class V Common Stock shares outstanding. The antidilutive effect of these awards was also not material. |

[0001571996-20-000017:notes:445]
| (e) | For the fiscal year ended February 1, 2019, the DHI Group weighted-average shares outstanding - basic represents the weighted-average shares over the twelve month period, with the Class C shares appropriately weighted for the number of days outstanding before and after the completion of the Class V transaction. |

[0001571996-20-000017:notes:446]
| (f) | Stock-based incentive awards have been excluded from the calculation of the DHI Group’s diluted loss per share because their effect would have been antidilutive, as the Company had a net loss attributable to the DHI Group for the periods presented. |

[0001571996-20-000017:notes:447]
The income allocation and earnings per share for the fiscal years ended February 1, 2019 and February 2, 2018 were not impacted by the acquisition of Pivotal by VMware, Inc., because shares of Class V Common Stock are no longer outstanding.  The following table presents a summary of the net loss attributable to Dell Technologies Inc. for the periods indicated:

[0001571996-20-000017:notes:448]
|  | Fiscal Year Ended |
|  | February 1, 2019 |  | February 2, 2018 |
|  | (in millions) |
| Net income attributable to Class V Common Stock | $ | 1,195 |  |  | $ | 331 |  |
| Net loss attributable to DHI Group | (3,505 | ) |  | (3,180 | ) |
| Net loss attributable to Dell Technologies Inc. | $ | (2,310 | ) |  | $ | (2,849 | ) |

[0001571996-20-000017:notes:449]
The following table presents the basis of allocation of net income attributable to the Class V Group for the periods indicated:

[0001571996-20-000017:notes:450]
|  |  | Fiscal Year Ended |
|  |  | February 1, 2019 |  | February 2, 2018 |
|  |  | (in millions) |
| Net income attributable to VMware |  | $ | 2,422 |  |  | $ | 659 |  |
| Less: Net income attributable to VMware for the period from December 28, 2018 to February 1, 2019 |  | (15 | ) |  | — |  |
| Less: Net income attributable to non-controlling interests |  | (452 | ) |  | (121 | ) |
| Net income attributable to Class V Group |  | 1,955 |  |  | 538 |  |
| Less: DHI Group's 38.90% and 38.48%, respectively, weighted average retained interest in Class V Group |  | (760 | ) |  | (207 | ) |
| Class V Common Stock economic interest in Class V Group (a) |  | $ | 1,195 |  |  | $ | 331 |  |

[0001571996-20-000017:notes:451]
| (a) | For the fiscal year ended February 1, 2019, Class V Common Stock economic interest in the Class V Group represents net income attributable to the Class V Group for the period ended December 27, 2018, the last date on which the Class V Common Stock traded on the New York Stock Exchange. |

[0001571996-20-000017:notes:452]
The following table presents a reconciliation of the VMware reportable segment results to the VMware, Inc. results attributable to the Class V Group pursuant to the tracking stock policy for the periods indicated.  The VMware reportable segment results presented below were recast as discussed in Note 19 of the Notes to the Consolidated Financial Statements.  The VMware, Inc. results were not impacted by the Pivotal acquisition.

[0001571996-20-000017:notes:453]
|  | Fiscal Year Ended |
|  | February 1, 2019 |  | February 2, 2018 |
|  | VMware Reportable Segment |  | Adjustments and Eliminations (a) |  | VMware |  | VMware Reportable Segment |  | Adjustments and Eliminations (a) |  | VMware |
|  | (in millions) |
| Net revenue | $ | 9,741 |  |  | $ | (767 | ) |  | $ | 8,974 |  |  | $ | 8,485 |  |  | $ | (623 | ) |  | $ | 7,862 |  |
| Cost of net revenue | 1,312 |  |  | (54 | ) |  | 1,258 |  |  | 1,205 |  |  | (64 | ) |  | 1,141 |  |
| Gross margin | 8,429 |  |  | (713 | ) |  | 7,716 |  |  | 7,280 |  |  | (559 | ) |  | 6,721 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative | 3,720 |  |  | (29 | ) |  | 3,691 |  |  | 3,062 |  |  | 202 |  |  | 3,264 |  |
| Research and development | 1,783 |  |  | 192 |  |  | 1,975 |  |  | 1,547 |  |  | 208 |  |  | 1,755 |  |
| Total operating expenses | 5,503 |  |  | 163 |  |  | 5,666 |  |  | 4,609 |  |  | 410 |  |  | 5,019 |  |
| Operating income (loss) | $ | 2,926 |  |  | $ | (876 | ) |  | $ | 2,050 |  |  | $ | 2,671 |  |  | $ | (969 | ) |  | $ | 1,702 |  |
| Interest and other income (expense), net attributable to VMware |  |  |  |  | 833 |  |  |  |  |  |  | 112 |  |
| Income before income taxes attributable to VMware |  |  |  |  | 2,883 |  |  |  |  |  |  | 1,814 |  |
| Income tax provision attributable to VMware |  |  |  |  | 461 |  |  |  |  |  |  | 1,155 |  |
| Net income attributable to VMware |  |  |  |  | $ | 2,422 |  |  |  |  |  |  | $ | 659 |  |

[0001571996-20-000017:notes:454]
(a)

[0001571996-20-000017:notes:455]
Adjustments and eliminations primarily consist of intercompany sales and allocated expenses, as well as expenses that are excluded from the VMware reportable segment, such as amortization of intangible assets, stock-based compensation expense, severance, and integration and acquisition-related costs.  Adjustments also include adjustments and eliminations pertaining to Pivotal results.


## dell:ReconciliationofConsolidatedNetIncomeLossTableTextBlock

[0001571996-20-000017:notes:456]
The following table presents a summary of the net loss attributable to Dell Technologies Inc. for the periods indicated:

[0001571996-20-000017:notes:457]
For the fiscal year ended February 1, 2019, Class V Common Stock economic interest in the Class V Group represents net income attributable to the Class V Group for the period ended December 27, 2018, the last date on which the Class V Common Stock traded on the New York Stock Exchange.

[0001571996-20-000017:notes:458]
The following table presents a reconciliation of the equity in net loss of subsidiaries to the net loss attributable to Dell Technologies Inc., and a reconciliation of consolidated net loss to comprehensive net loss attributable to Dell Technologies Inc. for the periods indicated:

[0001571996-20-000017:notes:459]
|  | Fiscal Year Ended |
|  | January 31, 2020 |  | February 1, 2019 |  | February 2, 2018 |
|  | (in millions) |
| Equity in net loss of subsidiaries attributable to Dell Technologies Inc. | $ | 4,643 |  |  | $ | (2,042 | ) |  | $ | (2,844 | ) |
| Parent - Total operating expense (a) | (21 | ) |  | (273 | ) |  | — |  |
| Parent - Interest and other, net | — |  |  | (20 | ) |  | (2 | ) |
| Parent - Income tax expense (benefit) (a) | 6 |  |  | (25 | ) |  | 3 |  |
| Parent - Loss before equity in net income of subsidiaries | $ | (27 | ) |  | $ | (268 | ) |  | $ | (5 | ) |
| Consolidated net income (loss) attributable to Dell Technologies Inc. | 4,616 |  |  | (2,310 | ) |  | (2,849 | ) |
| Other comprehensive income (loss) of subsidiaries attributable to Dell Technologies Inc. | (242 | ) |  | (539 | ) |  | 725 |  |
| Comprehensive income (loss) attributable to Dell Technologies Inc. | $ | 4,374 |  |  | $ | (2,849 | ) |  | $ | (2,124 | ) |

[0001571996-20-000017:notes:460]
During the fiscal years ended January 31, 2020 and February 1, 2019, the operating expense and the associated income tax expense (benefit) were primarily related to the costs incurred in the Class V transaction described in Note 14 of the Notes to the Consolidated Financial Statements.


## us-gaap:ReconciliationOfRevenueFromSegmentsToConsolidatedTextBlock

[0001571996-20-000017:notes:461]
The following table presents a reconciliation of net revenue by the Company’s reportable segments to the Company’s consolidated net revenue as well as a reconciliation of consolidated segment operating income to the Company’s consolidated operating income (loss) for the periods indicated:

[0001571996-20-000017:notes:462]
|  | Fiscal Year Ended |
|  | January 31, 2020 |  | February 1, 2019 |  | February 2, 2018 |
|  | (in millions) |
| Consolidated net revenue: |  |  |  |  |  |  |  |
| Infrastructure Solutions Group | $ | 33,969 |  |  | $ | 36,720 |  |  | $ | 30,917 |  |
| Client Solutions Group | 45,838 |  |  | 43,196 |  |  | 39,218 |  |
| VMware | 10,905 |  |  | 9,741 |  |  | 8,485 |  |
| Reportable segment net revenue | 90,712 |  |  | 89,657 |  |  | 78,620 |  |
| Other businesses (a) | 1,788 |  |  | 1,676 |  |  | 1,704 |  |
| Unallocated transactions (b) | 1 |  |  | (9 | ) |  | (15 | ) |
| Impact of purchase accounting (c) | (347 | ) |  | (703 | ) |  | (1,269 | ) |
| Total consolidated net revenue | $ | 92,154 |  |  | $ | 90,621 |  |  | $ | 79,040 |  |
| Consolidated operating income (loss): |  |  |  |  |  |
| Infrastructure Solutions Group | $ | 4,001 |  |  | $ | 4,151 |  |  | $ | 3,068 |  |
| Client Solutions Group | 3,138 |  |  | 1,960 |  |  | 2,044 |  |
| VMware | 3,081 |  |  | 2,926 |  |  | 2,671 |  |
| Reportable segment operating income | 10,220 |  |  | 9,037 |  |  | 7,783 |  |
| Other businesses (a) | (43 | ) |  | (111 | ) |  | 13 |  |
| Unallocated transactions (b) | (29 | ) |  | (72 | ) |  | (24 | ) |
| Impact of purchase accounting (c) | (411 | ) |  | (820 | ) |  | (1,546 | ) |
| Amortization of intangibles | (4,408 | ) |  | (6,138 | ) |  | (6,980 | ) |
| Transaction-related expenses (d) | (285 | ) |  | (750 | ) |  | (502 | ) |
| Stock-based compensation expense (e) | (1,262 | ) |  | (918 | ) |  | (835 | ) |
| Other corporate expenses (f) | (1,160 | ) |  | (419 | ) |  | (325 | ) |
| Total consolidated operating income (loss) | $ | 2,622 |  |  | $ | (191 | ) |  | $ | (2,416 | ) |

[0001571996-20-000017:notes:463]
| (a) | Secureworks, RSA Security, Virtustream, and Boomi constitute “Other businesses” and do not meet the requirements for a reportable segment, either individually or collectively. The results of Other businesses are not material to the Company’s overall results. |

[0001571996-20-000017:notes:464]
| (b) | Unallocated transactions includes other corporate items that are not allocated to Dell Technologies’ reportable segments. |

[0001571996-20-000017:notes:465]
| (c) | Impact of purchase accounting includes non-cash purchase accounting adjustments that are primarily related to the EMC merger transaction. |

[0001571996-20-000017:notes:466]
| (d) | Transaction-related expenses includes acquisition, integration, and divestiture related costs, as well as the costs incurred in the Class V transaction. |

[0001571996-20-000017:notes:467]
| (e) | Stock-based compensation expense consists of equity awards granted based on the estimated fair value of those awards at grant date. |

[0001571996-20-000017:notes:468]
| (f) | Other corporate expenses includes impairment charges, severance, facility action, and other costs. See Note 8 of the Notes to the Consolidated Financial Statements for additional information on Virtustream impairment charges. |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001571996-20-000017:notes:469]
NOTE 16 — STOCK-BASED COMPENSATION

[0001571996-20-000017:notes:470]
Stock-Based Compensation Expense

[0001571996-20-000017:notes:471]
The following table presents stock-based compensation expense recognized in the Consolidated Statements of Income (Loss) for the periods indicated:

[0001571996-20-000017:notes:472]
|  | Fiscal Year Ended |
|  | January 31, 2020 |  | February 1, 2019 |  | February 2, 2018 |
|  | (in millions) |
| Stock-based compensation expense (a): |  |  |  |  |  |  |
| Cost of net revenue | $ | 129 |  |  | $ | 76 |  |  | $ | 66 |  |
| Operating expenses | 1,133 |  |  | 842 |  |  | 769 |  |
| Stock-based compensation expense before taxes | 1,262 |  |  | 918 |  |  | 835 |  |
| Income tax benefit | (392 | ) |  | (260 | ) |  | (268 | ) |
| Stock-based compensation expense, net of income taxes | $ | 870 |  |  | $ | 658 |  |  | $ | 567 |  |

[0001571996-20-000017:notes:473]
| (a) | Stock-based compensation expense before taxes for the fiscal years ended January 31, 2020, February 1, 2019, and February 2, 2018 includes $892 million, $731 million and $683 million, respectively, related to the VMware, Inc. plans discussed below. |

[0001571996-20-000017:notes:474]
Dell Technologies Inc. Stock-Based Compensation Plans

[0001571996-20-000017:notes:475]
Dell Technologies Inc. 2013 Stock Incentive Plan (As Amended and Restated as of July, 9, 2019) — On September 7, 2016, at the effective time of the EMC merger transaction, the Denali Holding Inc. 2013 Stock Incentive Plan (the “2013 Plan”) was amended and restated as the Dell Technologies Inc. 2013 Stock Incentive Plan (the “Restated Plan”).  Employees, consultants, non-employee directors, and other service providers of the Company or its affiliates are eligible to participate in the Restated Plan.  The Restated Plan authorized the issuance of an aggregate of 75 million shares of the Company’s Class C Common Stock and 500,000 shares of the Company’s Class V Common Stock, of which 61 million shares of Class C Common Stock were previously reserved for issuance under the 2013 Plan.  The Restated Plan authorizes the Company to grant stock options, restricted stock units (“RSUs”), stock appreciation rights (“SARs”), RSAs, and dividend equivalents.

[0001571996-20-000017:notes:476]
Upon the completion of the Class V transaction on December 28, 2018, the Restated Plan was amended to remove allowance for employee awards to be settled in Class V Common Stock and reflected an increase in the total authorized shares of Class C Common Stock issued under the plan to 75.5 million shares from 75 million shares upon the conversion of 500,000 shares of Class V Common Stock previously authorized under the plan into the same number of shares of Class C Common Stock.  In connection with the Class V transaction, an immaterial number of Class V Common Stock awards issued to the Company’s independent directors were converted into an immaterial number of Class C Common Stock awards, which are reflected in the underlying stock option and restricted stock data as outstanding.  See Note 14 of the Notes to the Consolidated Financial Statements for additional information on the Class V transaction.

[0001571996-20-000017:notes:477]
During the second quarter of the fiscal year ended January 31, 2020, the Company’s stockholders approved an amendment to the Restated Plan to authorize an additional 35 million shares of Class C Common Stock for issuance pursuant to the Plan.  Upon effectiveness of the amendment, a total of 110.5 million shares of Class C Common Stock are authorized for issuance.  As of January 31, 2020, there were approximately 55 million shares of Class C Common Stock available for future grants under the Restated Plan.

[0001571996-20-000017:notes:478]
Stock Option Agreements — Stock options granted under the Restated Plan include service-based awards and performance-based awards.  A majority of the service-based stock options vest pro-rata at each option anniversary date over a five-year period.  Outstanding performance-based stock options became fully vested upon the achievement of a prescribed return on equity (“ROE”) measurement that was approved by the Company’s board of directors in connection with the Class V transaction.  Both service-based and performance-based stock options are granted with option exercise prices equal to the fair market value of the Company’s common stock.  Prior to the Class V transaction, the fair market value was determined by the Company’s board of directors or authorized committee.  After the Class V transaction, the fair market value is based on the closing price of the Class C Common Stock as reported on the NYSE on the grant date.  A majority of the stock options expire ten years after the date of grant.

[0001571996-20-000017:notes:479]
Stock Option Activity — The following table presents stock option activity settled in Dell Technologies Common Stock or DHI Group Common Stock for the periods indicated:

[0001571996-20-000017:notes:480]
|  | Number of Options |  | Weighted-Average Exercise Price |  | Weighted-Average Remaining Contractual Term |  | Aggregate Intrinsic Value (a) |
|  | (in millions) |  | (per share) |  | (in years) |  | (in millions) |
| Options outstanding as of February 3, 2017 | 48 |  |  | $ | 14.75 |  |  |  |  |  |
| Granted | — |  |  | — |  |  |  |  |  |
| Exercised | (4 | ) |  | 14.62 |  |  |  |  |  |
| Forfeited | (2 | ) |  | 13.75 |  |  |  |  |  |
| Canceled/expired | — |  |  | — |  |  |  |  |  |
| Options outstanding as of February 2, 2018 | 42 |  |  | 14.80 |  |  |  |  |  |
| Granted | — |  |  | — |  |  |  |  |  |
| Exercised | — |  |  | — |  |  |  |  |  |
| Forfeited | — |  |  | — |  |  |  |  |  |
| Canceled/expired | — |  |  | — |  |  |  |  |  |
| Options outstanding as of February 1, 2019 (b) | 42 |  |  | 14.76 |  |  |  |  |  |
| Granted | — |  |  | — |  |  |  |  |  |
| Exercised | (24 | ) |  | 14.86 |  |  |  |  |  |
| Forfeited | — |  |  | — |  |  |  |  |  |
| Canceled/expired | — |  |  | — |  |  |  |  |  |
| Options outstanding as of January 31, 2020 (c) | 18 |  |  | $ | 14.82 |  |  | 3.5 |  | $ | 617 |  |
| Exercisable as of January 31, 2020 | 18 |  |  | $ | 14.55 |  |  | 3.4 |  | $ | 612 |  |
| Vested and expected to vest (net of estimated forfeitures) as of January 31, 2020 | 18 |  |  | $ | 14.81 |  |  | 3.5 |  | $ | 616 |  |

[0001571996-20-000017:notes:481]
| (a) | The aggregate intrinsic values represent the total pre-tax intrinsic values based on the closing price of $48.77 of the Company’s Class C Common Stock on January 31, 2020 as reported on the NYSE that would have been received by the option holders had all in-the-money options been exercised as of that date. |

[0001571996-20-000017:notes:482]
| (b) | Stock option activity during the period was immaterial. The ending weighted-average exercise price was calculated based on underlying options outstanding as of February 1, 2019. |

[0001571996-20-000017:notes:483]
| (c) | Other than stock option exercises, stock option activity during the period was immaterial. The ending weighted-average exercise price was calculated based on underlying options outstanding as of January 31, 2020. Of the 18 million stock options outstanding on January 31, 2020, 10 million related to performance-based awards and 8 million related to service-based awards. |

[0001571996-20-000017:notes:484]
The total fair value of options vested was $4 million, $150 million, and $45 million for the fiscal years ended January 31, 2020, February 1, 2019, and February 2, 2018, respectively.  The pre-tax intrinsic value of the options exercised was $835 million, $18 million, and $62 million for the fiscal years ended January 31, 2020, February 1, 2019, and February 2, 2018, respectively.  Cash proceeds from the exercise of stock options were $350 million for the fiscal year ended January 31, 2020 and immaterial for both the fiscal years ended February 1, 2019 and February 2, 2018.

[0001571996-20-000017:notes:485]
The tax benefit realized from the exercise of stock options was $197 million, $5 million, and $21 million for the fiscal years ended January 31, 2020, February 1, 2019, and February 2, 2018, respectively.  As of January 31, 2020, there was $2 million of total unrecognized stock-based compensation expense, net of estimated forfeitures, related to unvested stock options expected to be recognized over a weighted-average period of 1.5 years.

[0001571996-20-000017:notes:486]
Valuation of Service-Based Stock Option Awards — The Company granted an immaterial number of service-based stock options under the Restated Plan during the fiscal years ended January 31, 2020, February 1, 2019, and February 2, 2018.

[0001571996-20-000017:notes:487]
Valuation of Performance-Based Stock Option Awards — There were no performance-based stock options granted under the Restated Plan during the fiscal years ended January 31, 2020, February 1, 2019, and February 2, 2018.

[0001571996-20-000017:notes:488]
Restricted Stock — The Company’s restricted stock primarily consists of RSUs granted to employees.  During the fiscal year ended January 31, 2020, the Company granted long-term incentive awards in the form of service-based RSUs and performance-based RSUs (“PSUs”) in order to align critical talent retention programs with the interests of holders of the Class C Common Stock.

[0001571996-20-000017:notes:489]
Service-based RSUs have a fair value based on the closing price of the Class C Common Stock price as reported on the NYSE on the grant date or the trade day immediately preceding the grant date, if the grant date falls on a non-trading day.  Most of such RSUs vest ratably over a three-year period.  Each service-based RSU represents the right to acquire one share of Class C Common Stock upon vesting.  Prior to the Class V transaction, each RSU converted into one share of DHI Group Common Stock upon vesting.

[0001571996-20-000017:notes:490]
The PSUs granted after the Class V transaction are reflected as target units while the actual number of units that ultimately vest will range from 0% to 200% of target, based on the level of achievement of the performance goals and continued employment with the Company over a three-year performance period.  Approximately half of the PSUs granted are subject to achievement of market-based performance goals based on relative total shareholder return and were valued utilizing a Monte Carlo valuation model to simulate the probabilities of achievement.  The remaining PSUs are subject to internal financial metrics and have fair values based on the closing price of the Class C Common Stock as reported on the NYSE on the accounting grant date.  For the fiscal year ended January 31, 2020, approximately one-third of the non-market performance awards have been valued and are considered outstanding for accounting purposes.

[0001571996-20-000017:notes:491]
Prior to the Class V transaction, the Company granted market-based PSUs to certain members of the Company’s senior leadership team, which were also valued using the Monte Carlo model.  The vesting and payout of the PSU awards depends upon the return on equity achieved on various measurement dates through the five year anniversary of the EMC merger transaction or specified liquidity events.

[0001571996-20-000017:notes:492]
The following table presents the assumptions utilized in the Monte Carlo valuation model for the period indicated:

[0001571996-20-000017:notes:493]
|  | Fiscal Year Ended |
|  | January 31, 2020 |
| Weighted-average grant date fair value | $ | 87.17 |  |
| Expected term (in years) | 3.0 |  |
| Risk-free rate (U.S. Government Treasury Note) | 2.4 | % |
| Expected volatility | 45 | % |
| Expected dividend yield | — | % |

[0001571996-20-000017:notes:494]
The following table presents restricted stock and restricted stock units activity settled in Dell Technologies Common Stock or DHI Group Common Stock for the periods indicated:

[0001571996-20-000017:notes:495]
|  | Number of Units |  | Weighted-Average Grant Date Fair Value |
|  | (in millions) |  | (per unit) |
| Outstanding, February 3, 2017 | 10 |  |  | $ | 19.63 |  |
| Granted | 1 |  |  | 23.04 |  |
| Vested | (1 | ) |  | 27.59 |  |
| Forfeited | (3 | ) |  | 19.13 |  |
| Outstanding, February 2, 2018 | 7 |  |  | $ | 18.73 |  |
| Granted (a) | — |  |  | — |  |
| Vested | (1 | ) |  | 28.03 |  |
| Forfeited | (1 | ) |  | 17.88 |  |
| Outstanding, February 1, 2019 | 5 |  |  | $ | 18.90 |  |
| Granted | 13 |  |  | 60.55 |  |
| Vested | (1 | ) |  | 30.24 |  |
| Forfeited | (1 | ) |  | 46.50 |  |
| Outstanding, January 31, 2020 (b) | 16 |  |  | $ | 50.78 |  |

[0001571996-20-000017:notes:496]
| (a) | The Company granted an immaterial number of restricted stock awards during the fiscal year ended February 1, 2019. |

[0001571996-20-000017:notes:497]
| (b) | As of January 31, 2020, the 16 million units outstanding included 11 million RSUs and 5 million PSUs. |

[0001571996-20-000017:notes:498]
The following table presents restricted stock that is expected to vest as of the date indicated:

[0001571996-20-000017:notes:499]
|  | Number of Units |  | Weighted-Average Remaining Contractual Term |  | Aggregate Intrinsic Value (a) |
|  | (in millions) |  | (in years) |  | (in millions) |
| Expected to vest, January 31, 2020 | 14 |  |  | 1.6 |  | $ | 695 |  |

[0001571996-20-000017:notes:500]
| (a) | The aggregate intrinsic value represents the total pre-tax intrinsic values based on the closing price of $48.77 of the Company’s Class C Common Stock on January 31, 2020 as reported on the NYSE that would have been received by the RSU holders had the RSUs been issued as of January 31, 2020. |

[0001571996-20-000017:notes:501]
The total fair value of restricted stock that vested during the fiscal years ended January 31, 2020, February 1, 2019, and February 2, 2018 was $27 million, $24 million, and $37 million, respectively, and the pre-tax intrinsic value was $47 million, $63 million, and $44 million, respectively.  As of January 31, 2020, 16 million shares of restricted stock were outstanding, with an aggregate intrinsic value of $774 million.

[0001571996-20-000017:notes:502]
As of January 31, 2020, there was $464 million of unrecognized stock-based compensation expense, net of estimated forfeitures, related to these awards expected to be recognized over a weighted-average period of approximately 2.2 years.

[0001571996-20-000017:notes:503]
Dell Technologies Shares Withheld for Taxes — Under certain situations, shares are withheld from issuance to cover employee taxes for both the vesting of restricted stock units and the exercise of stock options.  For the fiscal years ended January 31, 2020, February 1, 2019, and February 2, 2018, 0.1 million, 0.4 million, and 1.0 million shares, respectively, were withheld to cover $4 million, $28 million, and $35 million, respectively, of employees’ tax obligations.

[0001571996-20-000017:notes:504]
VMware, Inc. Stock-Based Compensation Plans

[0001571996-20-000017:notes:505]
VMware, Inc. 2007 Equity and Incentive Plan — In June 2007, VMware, Inc. adopted its 2007 Equity and Incentive Plan (the “2007 Plan”).  In June 2019, VMware, Inc. amended its 2007 Plan to increase the number of shares of Class A common stock available for issuance by 13 million.  As of January 31, 2020, the number of authorized shares of VMware, Inc. Class A common stock under the 2007 Plan was approximately 145 million.  The number of shares underlying outstanding equity awards that VMware, Inc. assumes in the course of business acquisitions are also added to the 2007 Plan reserve on an as-converted basis.  VMware, Inc. has assumed approximately 11 million shares, which accordingly have been added to the authorized shares under the 2007 Plan reserve.

[0001571996-20-000017:notes:506]
Awards under the 2007 Plan may be in the form of stock-based awards such as RSUs or stock options.  VMware, Inc.’s Compensation and Corporate Governance Committee determines the vesting schedule for all equity awards.  Generally, restricted stock grants made under the 2007 Plan have a three-year to four-year period over which they vest and vest 25% the first year and semiannually thereafter.  The value of RSU grants is based on VMware, Inc.’s stock price on the date of grant.  The shares underlying the RSU awards are not issued until the RSUs vest.  Upon vesting, each RSU converts into one share of VMware, Inc. Class A common stock.  VMware, Inc.’s restricted stock also includes PSU awards which have been granted to certain VMware, Inc. executives and employees.  The PSU awards include performance conditions and, in certain cases, a time-based or market-based vesting component.  Upon vesting, each PSU award will convert into VMware, Inc.’s Class A common stock at various ratios ranging from 0.1 to 2.0 shares per PSU, depending upon the degree of achievement of the performance or market based target designated by each award.  If minimum performance thresholds are not achieved, then no shares will be issued.

[0001571996-20-000017:notes:507]
The per share exercise price for a stock option awarded under the 2007 Plan will not be less than 100% of the per share fair market value of VMware, Inc. Class A common stock on the date of grant.  Most options granted under the 2007 Plan vest 25% after the first year and monthly thereafter over the following three years and expire between six and seven years from the date of grant.  VMware, Inc. utilizes authorized and unissued shares to satisfy all shares issued under the 2007 Plan.  As of January 31, 2020, there was an aggregate of approximately 24 million shares of common stock available for issuance pursuant to future grants under the 2007 Plan.

[0001571996-20-000017:notes:508]
Pivotal Equity Plan — Upon the completion of the acquisition by VMware, Inc. as described in Note 1 of the Notes to the Consolidated Financial Statements, Pivotal’s equity plan was terminated and no further awards can be granted under the plan.  Pivotal’s outstanding unvested RSUs and options on the date of the acquisition were converted to VMware, Inc. RSUs and options and valued at their historical carrying amounts.  The activity under Pivotal’s equity plan was not material during the fiscal years ended January 31, 2020, February 1, 2019, and February 2, 2018.

[0001571996-20-000017:notes:509]
VMware, Inc. Employee Stock Purchase Plan — In June 2007, VMware, Inc. adopted its 2007 Employee Stock Purchase Plan (the “ESPP”), which is intended to be qualified under Section 423 of the Internal Revenue Code.  In June 2019, VMware, Inc. amended its ESPP to increase the number of shares of Class A common stock available for issuance by 9 million.  As of January 31, 2020, the number of authorized shares under the ESPP was approximately 32 million.  Under the ESPP, eligible VMware, Inc. employees are granted options to purchase shares at the lower of 85% of the fair market value of the stock at the time of grant or 85% of the fair market value at the time of exercise.

[0001571996-20-000017:notes:510]
The option period is generally twelve months and includes two embedded six-month option periods.  Options are exercised at the end of each embedded option period.  If the fair market value of the stock is lower on the first day of the second embedded option period than it was at the time of grant, then the twelve-month option period expires and each enrolled participant is granted a new twelve-month option.  As of January 31, 2020, approximately 14 million shares of VMware, Inc. Class A common stock were available for issuance under the ESPP.

[0001571996-20-000017:notes:511]
The following table presents ESPP activity for the periods indicated:

[0001571996-20-000017:notes:512]
|  | Fiscal Year Ended |
|  | January 31, 2020 |  | February 1, 2019 |  | February 2, 2018 |
|  | (in millions, except per share amounts) |
| Cash proceeds | $ | 172 |  |  | $ | 161 |  |  | $ | 65 |  |
| Class A common shares purchased | 1.5 |  |  | 1.9 |  |  | 0.9 |  |
| Weighted-average price per share | $ | 115.51 |  |  | $ | 84.95 |  |  | $ | 72.40 |  |

[0001571996-20-000017:notes:513]
As of January 31, 2020, $95 million of ESPP withholdings were recorded as a liability in accrued and other on the Consolidated Statements of Financial Position related to a purchase under the ESPP that occurred on February 29, 2020, subsequent to the fiscal year ended January 31, 2020.  Total unrecognized stock-based compensation expense as of January 31, 2020 for the ESPP was $39 million.

[0001571996-20-000017:notes:514]
VMware, Inc. 2007 Equity and Incentive Plan Stock Options — The following table presents stock option activity for VMware, Inc. employees in VMware, Inc. stock options for the periods indicated:

[0001571996-20-000017:notes:515]
|  | Number of Options |  | Weighted-Average Exercise Price |  | Weighted-Average Remaining Contractual Term |  | Aggregate Intrinsic Value (a) |
|  | (in millions) |  | (per share) |  | (in years) |  | (in millions) |
| Options outstanding as of February 3, 2017 | 2 |  |  | $ | 69.38 |  |  |  |  |  |
| Granted | 1 |  |  | 13.79 |  |  |  |  |  |
| Exercised | (1 | ) |  | 53.50 |  |  |  |  |  |
| Forfeited | — |  |  | — |  |  |  |  |  |
| Canceled/expired | — |  |  | — |  |  |  |  |  |
| Options outstanding as of February 2, 2018 | 2 |  |  | 54.63 |  |  |  |  |  |
| Granted | 1 |  |  | 16.07 |  |  |  |  |  |
| Adjustment for special cash dividend | — |  |  | — |  |  |  |  |  |
| Exercised | (1 | ) |  | 46.73 |  |  |  |  |  |
| Forfeited | — |  |  | — |  |  |  |  |  |
| Canceled/expired | — |  |  | — |  |  |  |  |  |
| Options outstanding as of February 1, 2019 (b) | 2 |  |  | 36.50 |  |  |  |  |  |
| Granted | 2 |  |  | 73.19 |  |  |  |  |  |
| Exercised | (1 | ) |  | 39.94 |  |  |  |  |  |
| Forfeited | — |  |  | — |  |  |  |  |  |
| Canceled/expired | — |  |  | — |  |  |  |  |  |
| Options outstanding as of January 31, 2020 | 3 |  |  | $ | 56.58 |  |  | 6.4 |  | $ | 239 |  |
| Exercisable as of January 31, 2020 | 1 |  |  | $ | 47.24 |  |  | 3.8 |  | $ | 95 |  |
| Vested and expected to vest (net of estimated forfeitures) as of January 31, 2020 | 3 |  |  | $ | 56.13 |  |  | 6.4 |  | $ | 238 |  |

[0001571996-20-000017:notes:516]
| (a) | The aggregate intrinsic value represents the total pre-tax intrinsic values based on VMware, Inc.’s closing stock price of $148.06 on January 31, 2020 as reported on the NYSE that would have been received by the option holders had all in-the-money options been exercised as of that date. |

[0001571996-20-000017:notes:517]
| (b) | The number of options and weighted-average exercise price of options outstanding as of February 1, 2019 reflect the non-cash adjustments to the options as a result of the special cash dividend. |

[0001571996-20-000017:notes:518]
The above table includes stock options granted in conjunction with unvested stock options assumed in business combinations, including 0.6 million options issued for unvested options assumed as part of the Pivotal acquisition.  As a result, the weighted-average exercise price per share may vary from the VMware, Inc. stock price at time of grant.  The total fair value of VMware, Inc. stock options that vested during the fiscal years ended January 31, 2020, February 1, 2019, and February 2, 2018 was $64 million, $35 million, and $32 million, respectively.  The pre-tax intrinsic value of the options exercised during the fiscal years ended January 31, 2020, February 1, 2019, and February 2, 2018 was $103 million, $56 million, and $62 million, respectively.

[0001571996-20-000017:notes:519]
The tax benefit realized from the exercise of stock options was $25 million, $13 million, and $21 million for the fiscal years ended January 31, 2020, February 1, 2019, and February 2, 2018, respectively.  As of January 31, 2020, there was $129 million of total unrecognized stock-based compensation expense, net of estimated forfeitures, related to unvested stock options expected to be recognized over a weighted-average period of approximately one year.

[0001571996-20-000017:notes:520]
Fair Value of VMware, Inc. Options — The fair value of each option to acquire VMware, Inc. Class A common stock granted is estimated on the date of grant using the Black-Scholes option-pricing model.  The following tables present the assumptions utilized in this model, as well as the weighted-average assumptions for the periods indicated:

[0001571996-20-000017:notes:521]
|  | Fiscal Year Ended |
|  | January 31, 2020 |  | February 1, 2019 |  | February 2, 2018 |
| VMware, Inc. 2007 Equity and Incentive Plan |  |  |  |  |  |
| Weighted-average grant date fair value of stock options granted per option | $ | 98.00 |  |  | $ | 143.01 |  |  | $ | 83.62 |  |
| Expected term (in years) | 2.7 |  |  | 3.2 |  |  | 3.3 |  |
| Risk-free rate (U.S. Government Treasury Note) | 1.5 | % |  | 2.9 | % |  | 1.7 | % |
| Expected volatility | 34 | % |  | 32 | % |  | 29 | % |
| Expected dividend yield | — | % |  | — | % |  | — | % |

[0001571996-20-000017:notes:522]
|  | Fiscal Year Ended |
|  | January 31, 2020 |  | February 1, 2019 |  | February 2, 2018 |
| VMware, Inc. Employee Stock Purchase Plan |  |  |  |  |  |
| Weighted-average grant date fair value of stock options granted per option | $ | 35.66 |  |  | $ | 34.72 |  |  | $ | 21.93 |  |
| Expected term (in years) | 0.6 |  |  | 0.8 |  |  | 0.9 |  |
| Risk-free rate (U.S. Government Treasury Note) | 1.7 | % |  | 2.0 | % |  | 1.2 | % |
| Expected volatility | 27 | % |  | 33 | % |  | 23 | % |
| Expected dividend yield | — | % |  | — | % |  | — | % |

[0001571996-20-000017:notes:523]
The weighted-average grant date fair value of VMware, Inc. stock options can fluctuate from period to period primarily due to higher valued options assumed through business combinations with exercise prices lower than the fair market value of VMware, Inc.’s stock on the date of grant.

[0001571996-20-000017:notes:524]
For equity awards granted, volatility was based on an analysis of historical stock prices and implied volatilities of VMware, Inc.’s Class A common stock.  The expected term was based on historical exercise patterns and post-vesting termination behavior, the term of the option period for grants made under the ESPP, or the weighted-average remaining term for options assumed in acquisitions.  VMware, Inc.’s expected dividend yield input was zero as it has not historically paid cash dividends on its common stock, other than the special cash dividend paid in connection with the Class V transaction described in Note 14 of the Notes to the Consolidated Financial Statements and below, and does not expect to pay cash dividends in the future.  The risk-free interest rate was based on a U.S. Treasury instrument whose term is consistent with the expected term of the stock options.

[0001571996-20-000017:notes:525]
On July 1, 2018, in connection with the Class V transaction, VMware, Inc.’s board of directors declared a $11 billion special cash dividend, paid pro-rata to VMware, Inc. stockholders on December 28, 2018 in the amount of $26.81 per outstanding share of VMware, Inc. common stock.

[0001571996-20-000017:notes:526]
VMware, Inc. stock awards that were outstanding at the time of the special cash dividend were adjusted pursuant to anti-dilution provisions in VMware, Inc. equity incentive plan documents that provide for equitable adjustments to be determined by VMware’s Compensation and Corporate Governance Committee in the event of an extraordinary cash dividend.  The adjustments to awards included increasing the number of outstanding restricted stock units and stock options, as well as reducing the exercise prices of outstanding stock options.  The adjustments did not result in incremental stock-based compensation expense as the anti-dilutive adjustments were required by VMware, Inc.’s equity incentive plan.

[0001571996-20-000017:notes:527]
VMware, Inc. Restricted Stock — The following table presents VMware, Inc.’s restricted stock activity for the periods indicated:

[0001571996-20-000017:notes:528]
|  | Number of Units |  | Weighted-Average Grant Date Fair Value |
|  | (in millions) |  | (per unit) |
| Outstanding, February 3, 2017 | 20 |  |  | $ | 67.41 |  |
| Granted | 8 |  |  | 93.84 |  |
| Vested | (9 | ) |  | 67.89 |  |
| Forfeited | (2 | ) |  | 72.68 |  |
| Outstanding, February 2, 2018 | 17 |  |  | $ | 78.62 |  |
| Granted | 7 |  |  | 146.61 |  |
| Adjustment for special cash dividend (a) | 3 |  |  | NA |  |
| Vested | (7 | ) |  | 75.45 |  |
| Forfeited | (2 | ) |  | 86.90 |  |
| Outstanding, February 1, 2019 (a) | 18 |  |  | $ | 90.06 |  |
| Granted | 9 |  |  | 157.07 |  |
| Vested | (8 | ) |  | 80.28 |  |
| Forfeited | (2 | ) |  | 101.29 |  |
| Outstanding, January 31, 2020 (b) | 17 |  |  | $ | 128.38 |  |

[0001571996-20-000017:notes:529]
| (a) | The weighted-average grant date fair value of outstanding RSU awards as of February 1, 2019 reflects the non-cash adjustments to the awards as a result of the special cash dividend. |

[0001571996-20-000017:notes:530]
| (b) | As of January 31, 2020, the 17 million units outstanding included 16 million RSUs and 1 million PSUs. The above table includes RSUs issued for outstanding unvested RSUs in connection with business combinations, including 2.2 million RSUs issued for unvested RSUs assumed as part of the Pivotal acquisition. |

[0001571996-20-000017:notes:531]
|  | Number of Units |  | Weighted-Average Remaining Contractual Term |  | Aggregate Intrinsic Value (a) |
|  | (in millions) |  | (in years) |  | (in millions) |
| Expected to vest, January 31, 2020 | 16 |  |  | 2.4 |  | $ | 2,320 |  |

[0001571996-20-000017:notes:532]
| (a) | The aggregate intrinsic value represents the total pre-tax intrinsic values based on VMware, Inc.’s closing stock price of $148.06 on January 31, 2020 as reported on the NYSE that would have been received by the RSU holders had the RSUs been issued as of January 31, 2020. |

[0001571996-20-000017:notes:533]
The total fair value of VMware, Inc. restricted stock awards that vested during the fiscal years ended January 31, 2020, February 1, 2019 and February 2, 2018 was $657 million, $556 million, and $616 million, respectively, and the pre-tax intrinsic value was $1,414 million, $1,061 million, and $946 million, respectively.  As of January 31, 2020, 17 million restricted shares of VMware, Inc.’s Class A common stock were outstanding, with an aggregate intrinsic value of $2,587 million based on VMware, Inc.’s closing stock price on January 31, 2020 as reported on the NYSE.

[0001571996-20-000017:notes:534]
As of January 31, 2020, there was $1,589 million of unrecognized stock-based compensation expense, net of estimated forfeitures, related to these awards expected to be recognized over a weighted-average period of approximately 1.6 years.

[0001571996-20-000017:notes:535]
VMware, Inc. Shares Withheld for Taxes — For the fiscal years ended January 31, 2020, February 1, 2019, and February 2, 2018, VMware, Inc. repurchased and retired or withheld 3 million shares of VMware, Inc. Class A common stock, each year; for $521 million, $373 million, and $348 million, respectively, to cover tax withholding obligations.  These amounts may differ from the amounts of cash remitted for tax withholding obligations on the Consolidated Statements of Cash Flows due to the timing of payments.  Pursuant to the respective award agreements, these shares were withheld in conjunction with the net share settlement upon the vesting of restricted stock and restricted stock units (including PSUs) during the period.  The value of the withheld shares, including restricted stock units, was classified as a reduction to additional paid-in capital.

[0001571996-20-000017:notes:536]
Other Plans

[0001571996-20-000017:notes:537]
In addition to the plans disclosed above, the Company has a consolidated subsidiary, Secureworks, that maintains its own equity plan and issues equity grants settling in its own stock.  The stock option and restricted stock unit activity under this plan was not material during the fiscal years ended January 31, 2020, February 1, 2019, and February 2, 2018.


## us-gaap:ScheduleOfShareBasedPaymentAwardStockOptionsValuationAssumptionsTableTextBlock

[0001571996-20-000017:notes:538]
The following tables present the assumptions utilized in this model, as well as the weighted-average assumptions for the periods indicated:


## us-gaap:ScheduleOfShareBasedCompensationEmployeeStockPurchasePlanActivityTableTextBlock

[0001571996-20-000017:notes:539]
The following table presents stock option activity for VMware, Inc. employees in VMware, Inc. stock options for the periods indicated:

[0001571996-20-000017:notes:540]
(b)

[0001571996-20-000017:notes:541]
The number of options and weighted-average exercise price of options outstanding as of February 1, 2019 reflect the non-cash adjustments to the options as a result of the special cash dividend.


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001571996-20-000017:notes:542]
NOTE 17 — REDEEMABLE SHARES

[0001571996-20-000017:notes:543]
Awards under the Company’s stock incentive plans include certain rights that allow the holder to exercise a put feature for the underlying Class A or Class C Common Stock after a six-month holding period following the issuance of such common stock.  The put feature requires the Company to purchase the stock at its fair market value.  Accordingly, these awards and such common stock are subject to reclassification from equity to temporary equity, and the Company determines the award amounts to be classified as temporary equity as follows:

[0001571996-20-000017:notes:544]
| • | For stock options to purchase Class C Common Stock subject to service requirements, the intrinsic value of the option is multiplied by the portion of the option for which services have been rendered. Upon exercise of the option, the amount in temporary equity represents the fair value of the Class C Common Stock. |

[0001571996-20-000017:notes:545]
| • | For stock appreciation rights, RSUs, or RSAs, any of which stock award types are subject to service requirements, the fair value of the share is multiplied by the portion of the share for which services have been rendered. |

[0001571996-20-000017:notes:546]
| • | For share-based arrangements that are subject to the occurrence of a contingent event, those amounts are reclassified to temporary equity based on a probability assessment performed by the Company on a periodic basis. Contingent events include the achievement of performance-based metrics. |

[0001571996-20-000017:notes:547]
In connection with the Class V transaction described in Note 14 of the Notes to the Consolidated Financial Statements, the put feature provisions were amended to provide that the put feature will terminate upon the earlier of June 27, 2021 or the consummation of any underwritten public offering of shares of Class C Common Stock.

[0001571996-20-000017:notes:548]
The following table presents the amount of redeemable shares classified as temporary equity and summarizes the award type as of the dates indicated:

[0001571996-20-000017:notes:549]
|  | January 31, 2020 |  | February 1, 2019 |
|  | (in millions) |
| Redeemable shares classified as temporary equity | $ | 629 |  |  | $ | 1,196 |  |
| Issued and outstanding unrestricted common shares | 2 |  |  | 3 |  |
| Restricted stock units | 1 |  |  | 1 |  |
| Restricted stock awards | — |  |  | — |  |
| Outstanding stock options | 15 |  |  | 31 |  |

[0001571996-20-000017:notes:550]
The decrease in the value of redeemable shares during the fiscal year ended January 31, 2020 was primarily attributable to a decline in Class C Common Stock fair value and a reduction in the number of shares eligible for put rights.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001571996-20-000017:notes:551]
NOTE 18 — RETIREMENT PLAN BENEFITS

[0001571996-20-000017:notes:552]
Defined Benefit Retirement Plans

[0001571996-20-000017:notes:553]
The Company sponsors retirement plans for certain employees in the United States and internationally, and some of these plans meet the criteria of a defined benefit retirement plan.  Benefits under defined benefit retirement plans guarantee a particular payment to the employee in retirement.  The amount of retirement benefit is defined by the plan, and is typically a function of the number of years of service rendered by the employee and the employee’s average salary or salary at retirement.  The annual costs of the plans are determined using the projected unit credit actuarial cost method that includes actuarial assumptions and estimates which are subject to change.

[0001571996-20-000017:notes:554]
Net periodic benefit costs related to defined benefit retirement plans were immaterial for the fiscal years ended January 31, 2020, February 1, 2019, and February 2, 2018.  The Company did not make any significant contributions to defined benefit retirement plans for the fiscal years ended January 31, 2020, February 1, 2019, and February 2, 2018, and does not expect to make any significant contributions in Fiscal 2021.

[0001571996-20-000017:notes:555]
U.S. Pension Plan — The Company sponsors a noncontributory defined benefit retirement plan in the United States (the “U.S. pension plan”) which was assumed in connection with the EMC merger transaction.  As of December 1999, the U.S. pension plan was frozen, so employees no longer accrue retirement benefits for future services.  The measurement date for the U.S. pension plan is the end of the Company’s fiscal year.

[0001571996-20-000017:notes:556]
The following table presents attributes of the U.S. pension plan as of the dates indicated:

[0001571996-20-000017:notes:557]
|  | January 31, 2020 |  | February 1, 2019 |
|  | (in millions) |
| Plan assets at fair value (a) | $ | 547 |  |  | $ | 474 |  |
| Benefit obligations | (588 | ) |  | (524 | ) |
| Underfunded position (b) | $ | (41 | ) |  | $ | (50 | ) |

[0001571996-20-000017:notes:558]
| (a) | Plan assets are managed by outside investment managers. The Company’s investment strategy with respect to plan assets is to achieve a long-term growth of capital, consistent with an appropriate level of risk. Assets are recognized at fair value and are primarily classified within Level 2 of the fair value hierarchy. |

[0001571996-20-000017:notes:559]
| (b) | The underfunded position of the U.S. pension plan is recognized in other non-current liabilities in the Consolidated Statements of Financial Position. |

[0001571996-20-000017:notes:560]
As of January 31, 2020, future benefit payments for the U.S. pension plan are expected to be paid as follows: $30 million in Fiscal 2021; $31 million in Fiscal 2022; $33 million in Fiscal 2023; $34 million in Fiscal 2024; $34 million in Fiscal 2025; and $175 million thereafter.

[0001571996-20-000017:notes:561]
International Pension Plans — The Company also sponsors retirement plans outside of the United States which qualify as defined benefit plans.  As of January 31, 2020, the aggregate fair value of plan assets for the international pension plans was $0.2 billion, the aggregate benefit obligations were $0.4 billion, and the aggregate net underfunded position was $0.2 billion.  The underfunded position of the international pension plans is recognized in other non-current liabilities in the Consolidated Statements of Financial Position.

[0001571996-20-000017:notes:562]
Defined Contribution Retirement Plans

[0001571996-20-000017:notes:563]
Dell 401(k) Plan — The Company has a defined contribution retirement plan (the “Dell 401(k) Plan”) that complies with Section 401(k) of the Internal Revenue Code.  Only U.S. employees are eligible to participate in the Dell 401(k) plan.  As of January 31, 2020, the Company matches 100% of each participant’s voluntary contributions, subject to a maximum contribution of 6% of the participant’s eligible compensation, up to an annual limit of $7,500, and participants vest immediately in all contributions to the Dell 401(k) Plan.  The Company’s matching contributions as well as participants’ voluntary contributions are invested according to each participant’s elections in the investment options provided under the Dell 401(k) Plan.  The Company’s contributions during the fiscal years ended January 31, 2020, February 1, 2019, and February 2, 2018 were $267 million, $254 million, and $129 million, respectively.  Contributions increased during the fiscal year ended February 1, 2019 due to the additional participants that were transferred from the EMC 401(k) Plan, as discussed below.

[0001571996-20-000017:notes:564]
EMC 401(k) Plan — The EMC defined contribution retirement plan (the “EMC 401(k) Plan”) was assumed in connection with the EMC merger transaction on September 7, 2016.  Effective January 1, 2018, the EMC 401(k) Plan was terminated and participant account balances were transferred to the Dell 401(k) Plan and the newly-created Pivotal defined contribution plan.  Prior to the termination of the EMC 401(k) Plan on January 1, 2018, the Company’s contributions during the fiscal year ended February 2, 2018 to the EMC 401(k) Plan were $94 million.

[0001571996-20-000017:notes:565]
VMware, Inc. and Pivotal have defined contribution programs for certain employees that comply with Section 401(k) of the Internal Revenue Code.  Pivotal’s defined contribution program was acquired by VMware, Inc. in connection with VMware Inc.’s acquisition of Pivotal on December 30, 2019.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001571996-20-000017:notes:566]
NOTE 19 — SEGMENT INFORMATION

[0001571996-20-000017:notes:567]
The Company has three reportable segments that are based on the following business units:  Infrastructure Solutions Group (“ISG”); Client Solutions Group (“CSG”); and VMware.

[0001571996-20-000017:notes:568]
On December 30, 2019, VMware, Inc. completed its acquisition of Pivotal.  Due to the Company’s ownership of a controlling interest in Pivotal, the Company and VMware, Inc. accounted for the Pivotal acquisition as a transaction by entities under common control, and consequently the transaction had no net effect to the Company’s consolidated financial statements.  Pivotal now operates as a wholly-owned subsidiary of VMware, Inc. and Dell Technologies reports Pivotal results within the VMware reportable segment.  Previously, Pivotal results were reported within Other businesses.

[0001571996-20-000017:notes:569]
ISG includes servers, networking, and storage, as well as services and third-party software and peripherals that are closely tied to the sale of ISG hardware.  CSG includes sales to commercial and consumer customers of desktops, thin client products, and notebooks, as well as services and third-party software and peripherals that are closely tied to the sale of CSG hardware.  VMware works with customers in the areas of hybrid and multi-cloud, modern applications, networking, security, and digital workspaces  to enable VMware customers to digitally transform their operations as they ready their applications, infrastructure, and employees for constantly evolving business needs.

[0001571996-20-000017:notes:570]
The reportable segments disclosed herein are based on information reviewed by the Company’s management to evaluate the business segment results.  The Company’s measure of segment revenue and segment operating income for management reporting purposes excludes operating results of Other businesses, unallocated corporate transactions, the impact of purchase accounting, amortization of intangible assets, transaction-related expenses, stock-based compensation expense, and other corporate expenses, as applicable.  The Company does not allocate assets to the above reportable segments for internal reporting purposes.

[0001571996-20-000017:notes:571]
The following table presents the disaggregation of net revenue by reportable segment, and by major product categories within the segments for the periods indicated:

[0001571996-20-000017:notes:572]
|  | Fiscal Year Ended |
|  | January 31, 2020 |  | February 1, 2019 |  | February 2, 2018 |
|  | (in millions) |
| Net revenue: |  |  |  |  |  |  |
| Infrastructure Solutions Group: |  |  |  |  |  |
| Servers and networking | $ | 17,127 |  |  | $ | 19,953 |  |  | $ | 15,533 |  |
| Storage | 16,842 |  |  | 16,767 |  |  | 15,384 |  |
| Total ISG net revenue | 33,969 |  |  | 36,720 |  |  | 30,917 |  |
| Client Solutions Group: |  |  |  |  |  |
| Commercial | 34,277 |  |  | 30,893 |  |  | 27,507 |  |
| Consumer | 11,561 |  |  | 12,303 |  |  | 11,711 |  |
| Total CSG net revenue | 45,838 |  |  | 43,196 |  |  | 39,218 |  |
| VMware: |  |  |  |  |  |
| Total VMware net revenue | 10,905 |  |  | 9,741 |  |  | 8,485 |  |
| Total segment net revenue | $ | 90,712 |  |  | $ | 89,657 |  |  | $ | 78,620 |  |

[0001571996-20-000017:notes:573]
The following table presents net revenue allocated between the United States and foreign countries for the periods indicated:

[0001571996-20-000017:notes:574]
|  | Fiscal Year Ended |
|  | January 31, 2020 |  | February 1, 2019 |  | February 2, 2018 |
|  | (in millions) |
| Net revenue: |  |  |  |  |  |  |  |  |
| United States | $ | 43,829 |  |  | $ | 42,803 |  |  | $ | 38,528 |  |
| Foreign countries | 48,325 |  |  | 47,818 |  |  | 40,512 |  |
| Total net revenue | $ | 92,154 |  |  | $ | 90,621 |  |  | $ | 79,040 |  |

[0001571996-20-000017:notes:575]
The following table presents property, plant, and equipment, net allocated between the United States and foreign countries as of the dates indicated:

[0001571996-20-000017:notes:576]
|  | January 31, 2020 |  | February 1, 2019 |
|  | (in millions) |
| Property, plant, and equipment, net: |  |  |  |
| United States | $ | 4,322 |  |  | $ | 4,058 |  |
| Foreign countries | 1,733 |  |  | 1,201 |  |
| Total property, plant, and equipment, net | $ | 6,055 |  |  | $ | 5,259 |  |

[0001571996-20-000017:notes:577]
The allocation between domestic and foreign net revenue is based on the location of the customers.  Net revenue from any single foreign country did not constitute more than 10% of the Company’s consolidated net revenue for each of the fiscal years ended January 31, 2020, February 1, 2019, and February 2, 2018.  Property, plant, and equipment, net from any single foreign country did not constitute more than 10% of the Company’s consolidated property, plant, and equipment, net as of January 31, 2020 or February 1, 2019.


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001571996-20-000017:notes:578]
NOTE 20 — SUPPLEMENTAL CONSOLIDATED FINANCIAL INFORMATION

[0001571996-20-000017:notes:579]
The following table presents additional information on selected asset accounts included in the Consolidated Statements of Financial Position as of the dates indicated:

[0001571996-20-000017:notes:580]
|  | January 31, 2020 |  | February 1, 2019 |
|  | (in millions) |
| Cash, cash equivalents, and restricted cash: |  |  |  |
| Cash and cash equivalents | $ | 9,302 |  |  | $ | 9,676 |  |
| Restricted cash - other current assets (a) | 730 |  |  | 522 |  |
| Restricted cash - other non-current assets (a) | 119 |  |  | 42 |  |
| Total cash, cash equivalents, and restricted cash | $ | 10,151 |  |  | $ | 10,240 |  |
| Accounts receivable, net: |  |  |  |
| Gross accounts receivable | $ | 12,578 |  |  | $ | 12,456 |  |
| Allowance for doubtful accounts | (94 | ) |  | (85 | ) |
| Total accounts receivable, net | $ | 12,484 |  |  | $ | 12,371 |  |
| Inventories, net: |  |  |  |
| Production materials | $ | 1,590 |  |  | $ | 1,794 |  |
| Work-in-process | 563 |  |  | 702 |  |
| Finished goods | 1,128 |  |  | 1,153 |  |
| Total inventories, net | $ | 3,281 |  |  | $ | 3,649 |  |
| Prepaid expenses: |  |  |  |
| Total prepaid expenses (b) | $ | 885 |  |  | $ | 795 |  |
| Property, plant, and equipment, net: |  |  |  |
| Computer equipment | $ | 6,330 |  |  | $ | 5,219 |  |
| Land and buildings | 4,700 |  |  | 4,559 |  |
| Machinery and other equipment | 3,597 |  |  | 3,829 |  |
| Total property, plant, and equipment | 14,627 |  |  | 13,607 |  |
| Accumulated depreciation and amortization (c) | (8,572 | ) |  | (8,348 | ) |
| Total property, plant, and equipment, net | $ | 6,055 |  |  | $ | 5,259 |  |
| Other non-current assets: |  |  |  |
| Deferred and other tax assets | $ | 5,960 |  |  | $ | 654 |  |
| Operating lease ROU assets | 1,780 |  |  | — |  |
| Deferred Commissions | 998 |  |  | 817 |  |
| Other | 1,690 |  |  | 1,364 |  |
| Total other non-current assets | $ | 10,428 |  |  | $ | 2,835 |  |

[0001571996-20-000017:notes:581]
| (a) | Restricted cash includes cash required to be held in escrow pursuant to DFS securitization arrangements and VMware, Inc. restricted cash. |

[0001571996-20-000017:notes:582]
| (b) | Prepaid expenses are included in other current assets in the Consolidated Statements of Financial Position. |

[0001571996-20-000017:notes:583]
| (c) | During the fiscal years ended January 31, 2020, February 1, 2019, and February 2, 2018, the Company recognized $1.3 billion, $1.3 billion, and $1.5 billion, respectively, in depreciation expense. Additionally, during the fiscal years ended January 31, 2020, February 1, 2019, and February 2, 2018, the Company retired $0.8 billion, $0.8 billion, and $1.1 billion, respectively, of fully depreciated property, plant, and equipment. |

[0001571996-20-000017:notes:584]
The following table presents additional information on selected liability accounts included in the Consolidated Statements of Financial Position as of the dates indicated:

[0001571996-20-000017:notes:585]
|  | January 31, 2020 |  | February 1, 2019 |
|  | (in millions) |
| Accrued and other current liabilities: |  |  |  |
| Compensation | $ | 3,717 |  |  | $ | 3,646 |  |
| Income and other taxes | 1,767 |  |  | 1,396 |  |
| Sales and marketing programs | 1,387 |  |  | 1,209 |  |
| Operating lease liabilities | 432 |  |  | — |  |
| Warranty liability | 341 |  |  | 355 |  |
| Other | 2,129 |  |  | 1,889 |  |
| Total accrued and other current liabilities | $ | 9,773 |  |  | $ | 8,495 |  |
| Other non-current liabilities: |  |  |  |
| Deferred and other tax liabilities | $ | 3,110 |  |  | $ | 5,527 |  |
| Operating lease liabilities | 1,360 |  |  | — |  |
| Warranty liability | 155 |  |  | 169 |  |
| Other | 758 |  |  | 631 |  |
| Total other non-current liabilities | $ | 5,383 |  |  | $ | 6,327 |  |

[0001571996-20-000017:notes:586]
Valuation and Qualifying Accounts

[0001571996-20-000017:notes:587]
The following table presents the Company’s valuation and qualifying accounts for the periods indicated:

[0001571996-20-000017:notes:588]
|  | Fiscal Year Ended |
|  | January 31, 2020 |  | February 1, 2019 |  | February 2, 2018 |
|  | (in millions) |
| Trade Receivables - Allowance for doubtful accounts: |  |  |  |  |  |
| Balance at beginning of period | $ | 85 |  |  | $ | 103 |  |  | $ | 57 |  |
| Provision charged to income statement | 71 |  |  | 77 |  |  | 60 |  |
| Bad debt write-offs | (62 | ) |  | (95 | ) |  | (14 | ) |
| Balance at end of period | $ | 94 |  |  | $ | 85 |  |  | $ | 103 |  |
| Customer Financing Receivables - Allowance for financing receivable losses: |  |  |  |  |  |
| Balance at beginning of period | $ | 136 |  |  | $ | 145 |  |  | $ | 143 |  |
| Provision charged to income statement | 107 |  |  | 95 |  |  | 103 |  |
| Charge-offs, net of recoveries (a) | (94 | ) |  | (104 | ) |  | (101 | ) |
| Balance at end of period | $ | 149 |  |  | $ | 136 |  |  | $ | 145 |  |
| Tax Valuation Allowance: |  |  |  |  |  |
| Balance at beginning of period | $ | 1,704 |  |  | $ | 777 |  |  | $ | 709 |  |
| Charged to income tax provision | 32 |  |  | 927 |  |  | 68 |  |
| Charged to other accounts | (49 | ) |  | — |  |  | — |  |
| Balance at end of period | $ | 1,687 |  |  | $ | 1,704 |  |  | $ | 777 |  |

[0001571996-20-000017:notes:589]
| (a) | Charge-offs for customer financing receivables includes principal and interest. |

[0001571996-20-000017:notes:590]
Warranty Liability

[0001571996-20-000017:notes:591]
The following table presents changes in the Company’s liability for standard limited warranties for the periods indicated:

[0001571996-20-000017:notes:592]
|  | Fiscal Year Ended |
|  | January 31, 2020 |  | February 1, 2019 |  | February 2, 2018 |
|  | (in millions) |
| Warranty liability: |  |  |  |  |  |
| Warranty liability at beginning of period | $ | 524 |  |  | $ | 539 |  |  | $ | 604 |  |
| Costs accrued for new warranty contracts and changes in estimates for pre-existing warranties (a) (b) | 853 |  |  | 856 |  |  | 905 |  |
| Service obligations honored | (882 | ) |  | (871 | ) |  | (970 | ) |
| Warranty liability at end of period | $ | 496 |  |  | $ | 524 |  |  | $ | 539 |  |
| Current portion | $ | 341 |  |  | $ | 355 |  |  | $ | 367 |  |
| Non-current portion | $ | 155 |  |  | $ | 169 |  |  | $ | 172 |  |

[0001571996-20-000017:notes:593]
| (a) | Changes in cost estimates related to pre-existing warranties are aggregated with accruals for new standard warranty contracts. The Company’s warranty liability process does not differentiate between estimates made for pre-existing warranties and new warranty obligations. |

[0001571996-20-000017:notes:594]
| (b) | Includes the impact of foreign currency exchange rate fluctuations. |

[0001571996-20-000017:notes:595]
Severance Charges

[0001571996-20-000017:notes:596]
The Company incurs costs related to employee severance and records a liability for these costs when it is probable that employees will be entitled to termination benefits and the amounts can be reasonably estimated.  The liability related to these actions is included in accrued and other current liabilities in the Consolidated Statements of Financial Position.

[0001571996-20-000017:notes:597]
The following table presents the activity related to the Company’s severance liability for the periods indicated:

[0001571996-20-000017:notes:598]
|  | Fiscal Year Ended |
|  | January 31, 2020 |  | February 1, 2019 |  | February 2, 2018 |
|  | (in millions) |
| Severance liability: |  |  |  |  |  |
| Severance liability at beginning of period | $ | 146 |  |  | $ | 175 |  |  | $ | 416 |  |
| Severance charges to provision | 266 |  |  | 215 |  |  | 159 |  |
| Cash paid and other | (216 | ) |  | (244 | ) |  | (400 | ) |
| Severance liability at end of period | $ | 196 |  |  | $ | 146 |  |  | $ | 175 |  |

[0001571996-20-000017:notes:599]
The following table presents severance charges as included in the Consolidated Statements of Income (Loss) for the periods indicated:

[0001571996-20-000017:notes:600]
|  | Fiscal Year Ended |
|  | January 31, 2020 |  | February 1, 2019 |  | February 2, 2018 |
|  | (in millions) |
| Severance charges: |  |  |  |  |  |
| Cost of net revenue | $ | 37 |  |  | $ | 17 |  |  | $ | 46 |  |
| Selling, general, and administrative | 177 |  |  | 146 |  |  | 46 |  |
| Research and development | 52 |  |  | 52 |  |  | 67 |  |
| Total severance charges | $ | 266 |  |  | $ | 215 |  |  | $ | 159 |  |

[0001571996-20-000017:notes:601]
Interest and other, net

[0001571996-20-000017:notes:602]
The following table presents information regarding interest and other, net for the periods indicated:

[0001571996-20-000017:notes:603]
|  | Fiscal Year Ended |
|  | January 31, 2020 |  | February 1, 2019 |  | February 2, 2018 |
|  | (in millions) |
| Interest and other, net: |  |  |  |  |  |
| Investment income, primarily interest | $ | 160 |  |  | $ | 313 |  |  | $ | 207 |  |
| Gain on investments, net | 194 |  |  | 342 |  |  | 72 |  |
| Interest expense | (2,675 | ) |  | (2,488 | ) |  | (2,406 | ) |
| Foreign exchange | (162 | ) |  | (206 | ) |  | (113 | ) |
| Other | (143 | ) |  | (131 | ) |  | (113 | ) |
| Total interest and other, net | $ | (2,626 | ) |  | $ | (2,170 | ) |  | $ | (2,353 | ) |


## us-gaap:CondensedFinancialInformationOfParentCompanyOnlyDisclosureTextBlock

[0001571996-20-000017:notes:604]
NOTE 21 — CONDENSED FINANCIAL INFORMATION OF PARENT COMPANY

[0001571996-20-000017:notes:605]
Dell Technologies Inc. has no material assets or standalone operations other than its ownership in its consolidated subsidiaries.  There are restrictions under credit agreements and indentures governing the First Lien Notes and the Senior Notes, described in Note 6 of the Notes to the Consolidated Financial Statements, on the Company’s ability to obtain funds from any of its subsidiaries through dividends, loans, or advances.  As of January 31, 2020, the Company had certain consolidated subsidiaries that were designated as unrestricted subsidiaries for all purposes of the applicable credit agreements and such indentures.  As of January 31, 2020, substantially all of the net assets of the Company’s consolidated subsidiaries were restricted, with the exception of the Company’s unrestricted subsidiaries, primarily VMware, Inc., Secureworks, and their respective subsidiaries.  Accordingly, this condensed financial information is presented on a “Parent-only” basis.  Under a Parent-only presentation, Dell Technologies Inc.’s investments in its consolidated subsidiaries are presented under the equity method of accounting.

[0001571996-20-000017:notes:606]
The following table presents the financial position of Dell Technologies Inc. (Parent) as of the dates indicated:

[0001571996-20-000017:notes:607]
| Dell Technologies Inc. (Parent) | January 31, 2020 |  | February 1, 2019 |
|  | (in millions) |
| Assets: |  |  |  |
| Other non-current assets | $ | — |  |  | $ | 25 |  |
| Total assets | $ | — |  |  | $ | 25 |  |
| Liabilities: |  |  |  |
| Short-term debt | $ | — |  |  | $ | 13 |  |
| Guarantees of subsidiary obligations (a) | 945 |  |  | 4,581 |  |
| Total liabilities | 945 |  |  | 4,594 |  |
| Redeemable shares | 629 |  |  | 1,196 |  |
| Stockholders’ equity (deficit): |  |  |  |
| Common stock and capital in excess of $0.01 par value | 16,091 |  |  | 16,114 |  |
| Treasury stock at cost | (65 | ) |  | (63 | ) |
| Accumulated deficit | (16,891 | ) |  | (21,349 | ) |
| Accumulated other comprehensive income (loss) | (709 | ) |  | (467 | ) |
| Total stockholders’ equity (deficit) | (1,574 | ) |  | (5,765 | ) |
| Total liabilities, redeemable shares, and stockholders’ equity (deficit) | $ | — |  |  | $ | 25 |  |

[0001571996-20-000017:notes:608]
| (a) | Guarantees of subsidiary obligations represents the capital Dell Technologies Inc. received in excess of the carrying amount of its investments in subsidiaries. |

[0001571996-20-000017:notes:609]
| (a) | During the fiscal years ended January 31, 2020 and February 1, 2019, the operating expense and the associated income tax expense (benefit) were primarily related to the costs incurred in the Class V transaction described in Note 14 of the Notes to the Consolidated Financial Statements. |

[0001571996-20-000017:notes:610]
The following table presents the cash flows of Dell Technologies Inc. (Parent) for the periods indicated:

[0001571996-20-000017:notes:611]
|  | Fiscal Year Ended |
| Dell Technologies Inc. (Parent) | January 31, 2020 |  | February 1, 2019 |  | February 2, 2018 |
|  | (in millions) |
| Change in cash from operating activities | $ | (21 | ) |  | $ | (274 | ) |  | $ | (2 | ) |
| Cash flows from investing activities: |  |  |  |  |  |
| Transfer (to)/from subsidiary | (308 | ) |  | 14,360 |  |  | 640 |  |
| Change in cash from investing activities | (308 | ) |  | 14,360 |  |  | 640 |  |
| Cash flows from financing activities: |  |  |  |  |  |
| Share repurchases for tax withholdings of equity awards | (6 | ) |  | (28 | ) |  | (33 | ) |
| Proceeds from the issuance of common stock | 350 |  |  | 2 |  |  | 1 |  |
| Repurchases of Class V Common Stock | — |  |  | (14,000 | ) |  | (723 | ) |
| Repayments of debt | (13 | ) |  | (13 | ) |  | — |  |
| Other | (2 | ) |  | (47 | ) |  | (6 | ) |
| Change in cash from financing activities | 329 |  |  | (14,086 | ) |  | (761 | ) |
| Change in cash, cash equivalents, and restricted cash | — |  |  | — |  |  | (123 | ) |
| Cash, cash equivalents, and restricted cash at beginning of the period | — |  |  | — |  |  | 123 |  |
| Cash, cash equivalents, and restricted cash at end of the period | $ | — |  |  | $ | — |  |  | $ | — |  |


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001571996-20-000017:notes:612]
NOTE 22 — UNAUDITED QUARTERLY RESULTS

[0001571996-20-000017:notes:613]
The following tables present selected unaudited consolidated statements of income (loss) for each quarter of the periods indicated:

[0001571996-20-000017:notes:614]
|  | Fiscal 2020 |
|  | Q1 |  | Q2 |  | Q3 |  | Q4 |
|  | (in millions, except per share data) |
| Net revenue | $ | 21,908 |  |  | $ | 23,370 |  |  | $ | 22,844 |  |  | $ | 24,032 |  |
| Gross margin | $ | 6,797 |  |  | $ | 7,326 |  |  | $ | 7,126 |  |  | $ | 7,684 |  |
| Net income attributable to Dell Technologies Inc. | $ | 293 |  |  | $ | 3,416 |  |  | $ | 499 |  |  | $ | 408 |  |
| Earnings per share attributable to Dell Technologies Inc. - basic | $ | 0.41 |  |  | $ | 4.75 |  |  | $ | 0.69 |  |  | $ | 0.56 |  |
| Earnings per share attributable to Dell Technologies Inc. - diluted | $ | 0.38 |  |  | $ | 4.47 |  |  | $ | 0.66 |  |  | $ | 0.54 |  |

[0001571996-20-000017:notes:615]
|  | Fiscal 2019 |
|  | Q1 |  | Q2 |  | Q3 |  | Q4 (a) |
|  | (in millions, except per share data) |
| Net revenue | $ | 21,356 |  |  | $ | 22,942 |  |  | $ | 22,482 |  |  | $ | 23,841 |  |
| Gross margin | $ | 5,878 |  |  | $ | 6,123 |  |  | $ | 5,943 |  |  | $ | 7,109 |  |
| Net income attributable to Class V Common Stock | $ | 470 |  |  | $ | 320 |  |  | $ | 165 |  |  | $ | 240 |  |
| Net loss attributable to DHI Group | (1,106 | ) |  | (819 | ) |  | (1,041 | ) |  | (539 | ) |
| Net loss attributable to Dell Technologies Inc. | $ | (636 | ) |  | $ | (499 | ) |  | $ | (876 | ) |  | $ | (299 | ) |
| Earnings (loss) per share attributable to Dell Technologies Inc. - basic: |  |  |  |  |  |  |  |
| Class V Common Stock - basic | $ | 2.36 |  |  | $ | 1.61 |  |  | $ | 0.83 |  |  | $ | 1.21 |  |
| DHI Group - basic | $ | (1.95 | ) |  | $ | (1.44 | ) |  | $ | (1.84 | ) |  | $ | (0.86 | ) |
| Earnings (loss) per share attributable to Dell Technologies Inc. - diluted: |  |  |  |  |  |  |  |
| Class V Common Stock - diluted | $ | 2.33 |  |  | $ | 1.58 |  |  | $ | 0.81 |  |  | $ | 1.19 |  |
| DHI Group - diluted | $ | (1.95 | ) |  | $ | (1.45 | ) |  | $ | (1.84 | ) |  | $ | (0.86 | ) |

[0001571996-20-000017:notes:616]
For the three months ended February 1, 2019, net income attributable to the Class V Common Stock represents net income attributable to the Class V Group from November 3, 2018 to December 27, 2018, the last date on which the Class V Common Stock was traded on the NYSE.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001571996-20-000017:notes:617]
NOTE 23 — RELATED PARTY TRANSACTIONS

[0001571996-20-000017:notes:618]
Dell Technologies is a large global organization that engages in millions of purchase, sales, and other transactions during the fiscal year.  The Company enters into purchase and sales transactions with other publicly-traded and privately-held companies, as well as not-for-profit organizations, that could be influenced by members of the Company’s board of directors or the Company’s executive officers.  The Company enters into these arrangements in the ordinary course of its business.  Transactions with related parties were immaterial for the fiscal years ended January 31, 2020, February 1, 2019, and February 2, 2018.


## us-gaap:SubsequentEventsTextBlock

[0001571996-20-000017:notes:619]
NOTE 24 — SUBSEQUENT EVENTS

[0001571996-20-000017:notes:620]
RSA Security Divestiture — On February 18, 2020, Dell Technologies announced its entry into a definitive agreement with a consortium led by Symphony Technology Group, Ontario Teachers’ Pension Plan Board and AlpInvest Partners to sell RSA Security in an all-cash transaction for approximately $2.075 billion, subject to certain closing adjustments.  The transaction, which includes the purchase of RSA Archer, RSA NetWitness Platform, RSA SecurID, RSA Fraud and Risk Intelligence and RSA Conference, is expected to close in six to nine months following the announcement and is subject to customary conditions.  The transaction is intended to further simplify Dell Technologies’ product portfolio and corporate structure.

[0001571996-20-000017:notes:621]
RSA Security is included within Other Businesses and does not meet the requirements for a reportable segment.  The transaction is not expected to have a material impact on the Company’s operating results or financial position.

[0001571996-20-000017:notes:622]
Share Repurchase Program — On February 24, 2020, the Company’s board of directors approved a stock repurchase program under which the Company is authorized to repurchase up to $1.0 billion of shares of the Class C Common Stock over a 24-month period expiring on February 28, 2022.

[0001571996-20-000017:notes:623]
Revolving Credit Facility — In March 2020, the Company drew $3.0 billion under the Revolving Credit Facility, with the majority of the proceeds held as cash and cash equivalents.  The Company increased its borrowing under the Revolving Credit Facility as a precautionary measure to increase its cash position and preserve financial flexibility in light of current disruption and uncertainty in the global markets resulting from the outbreak of COVID-19.

[0001571996-20-000017:notes:624]
Margin Loan Facility — In March 2020, due to volatility in the U.S. stock market resulting from the outbreak of COVID-19, VMW Holdco LLC proactively pledged additional shares of VMware, Inc. common stock to secure its obligations under the Margin Loan Facility agreement.  This resulted in an aggregate number of shares pledged of approximately 76 million shares of VMware, Inc. Class B common stock and approximately 24 million shares of VMware, Inc. Class A common stock.

[0001571996-20-000017:notes:625]
Other than the matters identified above, there were no known events occurring after the balance sheet date and up until the date of the issuance of this report that would materially affect the information presented herein.
