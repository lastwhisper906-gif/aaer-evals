# DELL MD&A — 0001571996-20-000017


## mdna

[0001571996-20-000017:mdna:1]
ITEM 7 — MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0001571996-20-000017:mdna:2]
This management’s discussion and analysis should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in this annual report on Form 10-K.

[0001571996-20-000017:mdna:3]
Unless otherwise indicated, all results presented are prepared in a manner that complies, in all material respects, with accounting principles generally accepted in the United States of America (“GAAP”).  Additionally, unless otherwise indicated, all changes identified for the current-period results represent comparisons to results for the prior corresponding fiscal period.

[0001571996-20-000017:mdna:4]
Unless the context indicates otherwise, references in this report to “we,” “us,” “our,” the “Company,” and “Dell Technologies” mean Dell Technologies Inc. and its consolidated subsidiaries, references to “Dell” mean Dell Inc. and Dell Inc.’s consolidated subsidiaries, and references to “EMC” mean EMC Corporation and EMC Corporation’s consolidated subsidiaries.

[0001571996-20-000017:mdna:5]
Our fiscal year is the 52- or 53-week period ending on the Friday nearest January 31.  We refer to our fiscal years ended January 31, 2020, February 1, 2019, and February 2, 2018 as “Fiscal 2020,” “Fiscal 2019,” and “Fiscal 2018,” respectively.  All fiscal years presented included 52 weeks.

[0001571996-20-000017:mdna:6]
INTRODUCTION

[0001571996-20-000017:mdna:7]
Dell Technologies is a leading global end-to-end technology provider, with a comprehensive portfolio of IT hardware, software and services solutions spanning both traditional infrastructure and emerging, multi-cloud technologies that enable our customers to build their digital future and transform how they work and live.  We operate globally across key functional areas such as technology and product development, marketing, go-to-market and global services, and are supported by Dell Financial Services.  We continue to seamlessly deliver differentiated and holistic IT solutions to our customers, which has driven significant revenue growth and share gains.

[0001571996-20-000017:mdna:8]
Dell Technologies operates with significant scale and an unmatched breadth of complementary offerings.  Digital transformation has become essential to all businesses, and we have expanded our portfolio to include holistic solutions that enable our customers to drive their ongoing digital transformation initiatives.  Dell Technologies’ integrated solutions help customers modernize their IT infrastructure, address workforce transformation, and provide critical security solutions to protect against the ever increasing and evolving security threats.  With our extensive portfolio and our commitment to innovation, we have the ability to offer secure, integrated solutions that extend from the edge to the core to the cloud, and we are at the forefront of the software-defined and cloud native infrastructure era.  Our end-to-end portfolio is supported by a differentiated go-to-market engine, which includes a 43,000-person sales force, a global network of channel partners, and a world-class supply chain that together drive revenue growth and operating efficiencies.

[0001571996-20-000017:mdna:9]
Products and Services

[0001571996-20-000017:mdna:10]
We design, develop, manufacture, market, sell, and support a wide range of products and services.  We are organized into the following business units, which are our reportable segments: Infrastructure Solutions Group; Client Solutions Group; and VMware.

[0001571996-20-000017:mdna:11]
| • | Infrastructure Solutions Group (“ISG”) — ISG enables the digital transformation of our customers through our trusted multi-cloud and big data solutions, which are built upon a modern data center infrastructure. Our comprehensive portfolio of advanced storage solutions includes traditional storage solutions as well as next-generation storage solutions (such as all-flash arrays, scale-out file, object platforms and software-defined solutions). We have simplified our storage portfolio to ensure that we deliver the technology needed for our customers’ digital transformation. Our server portfolio includes high-performance rack, blade, tower and hyperscale servers, optimized for artificial intelligence and machine learning workloads. Our networking portfolio helps our business customers transform and modernize their infrastructure, mobilize and enrich end-user experiences, and accelerate business applications and |

[0001571996-20-000017:mdna:12]
processes.  Our strengths in server, storage, and virtualization software solutions enable us to offer leading converged and hyper-converged solutions, allowing our customers to accelerate their IT transformation by acquiring scalable integrated IT solutions instead of building and assembling their own IT platforms.  ISG also offers attached software, peripherals and services, including support and deployment, configuration, and extended warranty services.

[0001571996-20-000017:mdna:13]
We recently unveiled the Dell Technologies Cloud, a new set of cloud infrastructure solutions to make hybrid cloud environments simpler to deploy and manage.  The Dell Technologies Cloud portfolio consists of the new Dell Technologies Cloud Platforms and the new Data Center-as-a-Service offering referred to as VMware Cloud on Dell EMC.  These solutions enable a flexible range of IT and management options with tight integration and a single vendor experience for purchasing, deployment, services, and financing, giving customers more control as the operational hub of their hybrid clouds.

[0001571996-20-000017:mdna:14]
Approximately half of ISG revenue is generated by sales to customers in the Americas, with the remaining portion derived from sales to customers in the Europe, Middle East, and Africa region (“EMEA”) and the Asia-Pacific and Japan region (“APJ”).

[0001571996-20-000017:mdna:15]
| • | Client Solutions Group (“CSG”) — CSG includes branded hardware (such as desktops, workstations, and notebooks) and branded peripherals (such as displays and projectors), as well as third-party software and peripherals. Our computing devices are designed with our commercial and consumer customers’ needs in mind, and we seek to optimize performance, reliability, manageability, design, and security. In addition to our traditional hardware business, we have a portfolio of thin client offerings that we believe will allow us to benefit from the growth trends in cloud computing. For our customers that are seeking to simplify client lifecycle management, Dell PC as a Service offering combines hardware, software, lifecycle services, and financing into one all-encompassing solution that provides predictable pricing per seat per month through Dell Financial Services. CSG also offers attached software, peripherals, and services, including support and deployment, configuration, and extended warranty services. |

[0001571996-20-000017:mdna:16]
Approximately half of CSG revenue is generated by sales to customers in the Americas, with the remaining portion derived from sales to customers in EMEA and APJ.

[0001571996-20-000017:mdna:17]
| • | VMware — The VMware reportable segment (“VMware”) reflects the operations of VMware, Inc. (NYSE: VMW) within Dell Technologies. VMware works with customers in the areas of hybrid and multi-cloud, modern applications, networking, security, and digital workspaces, helping customers manage their IT resources across private clouds and complex multi-cloud, multi-device environments. VMware’s portfolio supports and addresses the key IT priorities of customers: accelerating their cloud journey, modernizing their applications, empowering digital workspaces, transforming networking, and embracing intrinsic security. VMware enables its customers to digitally transform their operations as they ready their applications, infrastructure, and employees for constantly evolving business needs. |

[0001571996-20-000017:mdna:18]
During the third quarter of Fiscal 2020, VMware, Inc. completed its acquisition of Carbon Black, Inc. (“Carbon Black”), a developer of cloud-native endpoint protection.

[0001571996-20-000017:mdna:19]
On December 30, 2019, VMware, Inc. completed its acquisition of Pivotal, Inc. (“Pivotal”).  Before the transaction, Pivotal was a majority-owned subsidiary of Dell Technologies through EMC and VMware, Inc.  Pivotal provides a leading cloud-native platform that makes software development and IT operations a strategic advantage for customers.  Pivotal’s cloud-native platform, Pivotal Cloud Foundry, accelerates and streamlines software development by reducing the complexity of building, deploying and operating new cloud-native applications, and modernizing legacy applications.  With the acquisition, which aligns key software assets, VMware, Inc. will drive and build on a comprehensive development platform with Kubernetes.

[0001571996-20-000017:mdna:20]
Under the terms of the transaction, each outstanding share of Pivotal’s Class A common stock (other than shares held by Pivotal stockholders who properly exercised their appraisal rights under Delaware law) was converted into the right to receive $15.00 in cash, without interest, and each outstanding share of Pivotal’s Class B common stock was converted into the right to receive 0.0550 of a share of Class B common stock of VMware, Inc.  Dell Technologies, which held all outstanding shares of Pivotal’s Class B common stock, received approximately 7.2 million shares of Class B common stock of VMware, Inc. in the transaction.

[0001571996-20-000017:mdna:21]
The purchase of the controlling interest in Pivotal from Dell Technologies was accounted for as a transaction by entities under common control.  Assets and liabilities of Pivotal remained at their historical carrying amounts on the

[0001571996-20-000017:mdna:22]
date of the transaction, with no new goodwill being recognized.  This transaction required retrospective combination of the VMware, Inc. and Pivotal results for all periods presented, as if the combination had been in effect since the inception of common control on the date of the EMC merger transaction in September 2016.

[0001571996-20-000017:mdna:23]
Dell Technologies now reports Pivotal results within the VMware reportable segment, and the historical segment results have been recast to reflect this change.  Pivotal results were previously reported within other businesses.  See Note 19 of the Notes to the Consolidated Financial Statements included in this report for the recast of segment results.

[0001571996-20-000017:mdna:24]
Approximately half of VMware revenue is generated by sales to customers in the United States.

[0001571996-20-000017:mdna:25]
Our other businesses, described below, consist of product and service offerings of Secureworks, Virtustream, Boomi, and RSA Security, each of which is majority-owned by Dell Technologies.  These businesses are not classified as reportable segments, either individually or collectively, as the results of the businesses are not material to our overall results and the businesses do not meet the criteria for reportable segments.

[0001571996-20-000017:mdna:26]
| • | Secureworks (NASDAQ: SCWX) is a leading global provider of intelligence-driven information security solutions singularly focused on protecting its clients from cyber attacks. The solutions offered by Secureworks enable organizations of varying size and complexity to fortify their cyber defenses to prevent security breaches, detect malicious activity in near real time, prioritize and respond rapidly to security incidents and predict emerging threats. |

[0001571996-20-000017:mdna:27]
| • | Virtustream offers cloud software and infrastructure-as-a-service solutions that enable customers to migrate, run, and manage mission-critical applications in cloud-based IT environments. Beginning in the first quarter of Fiscal 2019, Virtustream results are reported within other businesses, rather than within ISG. This change in reporting structure did not impact our previously reported consolidated financial results, but our prior period segment results have been recast to reflect the change. |

[0001571996-20-000017:mdna:28]
| • | Boomi specializes in cloud-based integration, connecting information between existing on-premise and cloud-based applications to ensure business processes are optimized, data is accurate and workflow is reliable. |

[0001571996-20-000017:mdna:29]
| • | RSA Security provides essential cybersecurity solutions engineered to enable organizations to detect, investigate, and respond to advanced attacks, confirm and manage identities, and, ultimately, help reduce IP theft, fraud, and cybercrime. In February 2020, Dell Technologies announced its entry into a definitive agreement to sell RSA Security to a consortium of investors in an all-cash transaction for approximately $2.075 billion, subject to certain closing adjustments. The transaction is intended to further simplify our product portfolio and corporate structure. |

[0001571996-20-000017:mdna:30]
We believe the collaboration, innovation, and coordination of the operations and strategies across all segments of our business, as well as our differentiated go-to-market model, will continue to drive revenue synergies.  Through our coordinated research and development activities, we are able to jointly engineer leading innovative solutions that incorporate the distinct set of hardware, software, and services across all segments of our business.

[0001571996-20-000017:mdna:31]
Our products and services offerings are continually evolving in response to industry dynamics.  As a result, reclassifications of certain products and services solutions in major product categories may be required.  For further discussion regarding our current reportable segments, see “Results of Operations — Business Unit Results” and Note 19 of the Notes to the Consolidated Financial Statements included in this report.

[0001571996-20-000017:mdna:32]
Dell Financial Services

[0001571996-20-000017:mdna:33]
Dell Financial Services and its affiliates (“DFS”) support our businesses by offering and arranging various financing options and services for our customers in North America, Europe, Australia, and New Zealand.  DFS originates, collects, and services customer receivables primarily related to the purchase or use of our product, software, and service solutions.  We also arrange financing for some of our customers in various countries where DFS does not currently operate as a captive.  DFS further strengthens our customer relationships through its flexible consumption models, which enable us to offer our customers the option to pay over time and, in certain cases, based on utilization, providing them with financial flexibility to meet their changing technological requirements.  The results of these operations are allocated to our segments based on the underlying product or service financed.  For additional information about our financing arrangements, see Note 4 of the Notes to the Consolidated Financial Statements included in this report.

[0001571996-20-000017:mdna:34]
Strategic Investments and Acquisitions

[0001571996-20-000017:mdna:35]
As part of our strategy, we will continue to evaluate opportunities for strategic investments through our venture capital investment arm, Dell Technologies Capital, with a focus on emerging technology areas that are relevant to the Dell Technologies unique family of businesses and that will complement our existing portfolio of solutions.  Our investment areas include storage, software-defined networking, management and orchestration, security, machine learning and artificial intelligence, Big Data and analytics, cloud, Internet of Things (“IoT”), and software development operations.  In addition to these investments, we also may make disciplined acquisitions targeting businesses that advance our strategic objectives.  As of January 31, 2020 and February 1, 2019, Dell Technologies held strategic investments of $0.9 billion and $1.0 billion, respectively.

[0001571996-20-000017:mdna:36]
Business Trends and Challenges

[0001571996-20-000017:mdna:37]
Our vision is to be an essential infrastructure company and leader in end-user computing, software-defined data center solutions, data management, virtualization, IoT, and cloud software.  We believe that our results will benefit from an integrated go-to-market strategy, including enhanced coordination across all segments of our business, and from our differentiated products and solutions capabilities.  We intend to continue to execute on our business model and seek to balance liquidity, profitability, and growth to position our company for long-term success.

[0001571996-20-000017:mdna:38]
We are seeing an accelerated rate of change in the IT industry.  We seek to address our customers’ evolving needs and their broader digital transformation objectives as they embrace the hybrid multi-cloud environment of today.  New technologies are being introduced and adopted quickly.  In light of this rapid pace of innovation, we continue to invest in research and development, sales, and other key areas of our business to deliver superior products and solutions capabilities and to drive execution of long-term sustainable growth.

[0001571996-20-000017:mdna:39]
We expect that ISG will continue to be impacted by the changing nature of the IT infrastructure market and competitive environment.  The overall server demand environment remains varied among international regions.  We will continue to be selective in determining whether to pursue certain large hyperscale and other server transactions as we drive for balanced growth and profitability.  With our scale and strong solutions portfolio, we believe we are well positioned to respond to ongoing competitive dynamics.  We continue to focus on customer base expansion and lifetime value of customer measurements.

[0001571996-20-000017:mdna:40]
Cloud-native applications are expected to continue as a primary growth driver in the infrastructure market as IT organizations increasingly adopt cloud native architectures.  We believe the complementary cloud solutions across our business strongly position us to meet these demands for our customers who are increasingly looking to leverage cloud native architectures, whether on-premises, private or public.

[0001571996-20-000017:mdna:41]
The unprecedented data growth throughout all industries is generating continued demand for our storage solutions and services.  We benefit by offering solutions that address the emerging trends of enterprises deploying software-defined storage, hyper-converged infrastructure, and modular solutions based on server-centric architectures.  These trends are changing the way customers are consuming our traditional storage offerings.  We continue to expand our offerings in external storage arrays, which incorporate flexible, cloud-based functionality.  Through our research and development efforts, we are developing new solutions in this rapidly changing industry that we believe will enable us to continue to provide superior solutions to our customers.

[0001571996-20-000017:mdna:42]
Our customers are interested in new and innovative models that address how they consume our solutions.  We offer options including as-a-service, utility, leases, or immediate pay models, all designed to match customers’ consumption preferences.  These solutions are generally multi-year agreements that typically result in recurring revenue streams over the term of the arrangement.  We expect these flexible consumption models will further strengthen our customer relationships and provide a foundation for growth in deferred revenue.

[0001571996-20-000017:mdna:43]
Our CSG offerings are an important element of our strategy, generating strong cash flow and opportunities for cross-selling of complementary solutions.  Given current market trends, we expect that the CSG demand environment will continue to be cyclical.  For instance, CSG demand was robust in Fiscal 2020 as we realized benefits from the Microsoft Windows 10 operating system refresh cycle.  Although we expect continued strong demand into the early part of Fiscal 2021, we expect overall CSG demand will decelerate in Fiscal 2021 as the Windows 10 refresh cycle winds down.  Competitive dynamics will continue to be a factor in our CSG business as we seek to balance profitability and growth.  We are committed to a long-term

[0001571996-20-000017:mdna:44]
growth strategy, and beyond Fiscal 2021 we believe CSG will benefit from a steady demand environment due to the consolidation trends that are occurring in the markets in which we compete.

[0001571996-20-000017:mdna:45]
During Fiscal 2020, we recognized benefits to our CSG and ISG operating results from significant component cost declines.  We are seeing cost inflation across certain components, and we expect the overall environment to be inflationary, which may result in Fiscal 2021 consolidated operating results that trend more toward Fiscal 2019 levels.  The component cost trends and forecasts are dependent on the strength or weakness of actual end user demand and supply dynamics, which will continue to evolve and ultimately impact the translation of the cost environment to pricing and operating results.

[0001571996-20-000017:mdna:46]
Dell Technologies maintains limited-source supplier relationships for processors, because the relationships are advantageous in the areas of performance, quality, support, delivery, capacity, and price considerations.  We have seen the impact of processor and other supply constraints in certain product offerings.  Delays in the supply of limited-source components could affect the timing of shipments of certain products in desired quantities or configurations.

[0001571996-20-000017:mdna:47]
The impacts of trade protection measures, including increases in tariffs and trade barriers due to the current geopolitical climate and changes in government policies and international trade arrangements, may affect our ability to conduct business in some non-U.S. markets.  Among such impacts, we expect slower demand in China may affect our results in Fiscal 2021.  We monitor and seek to mitigate these risks with adjustments to our manufacturing, supply chain and distribution networks.

[0001571996-20-000017:mdna:48]
Our business operations could be adversely affected by uncertainty and disruption resulting from the global spread of the coronavirus disease 2019 (COVID-19).  While we are currently seeing heightened interest in work from home solutions and continuing execution in our global supply chain, we are unable to predict the extent to which the global COVID-19 pandemic may adversely impact our business operations, financial performance and results of operations for Fiscal 2021.  We have taken precautionary measures to increase our cash position and preserve financial flexibility.  We will continue to monitor global events and respond accordingly to any potential business disruptions that may occur.

[0001571996-20-000017:mdna:49]
We manage our business on a U.S. Dollar basis.  However, we have a large global presence, generating approximately half of our revenue by sales to customers outside of the United States during Fiscal 2020, Fiscal 2019, and Fiscal 2018.  As a result, our revenue can be impacted by fluctuations in foreign currency exchange rates.  We utilize a comprehensive hedging strategy intended to mitigate the impact of foreign currency volatility over time, and we adjust pricing when possible to further minimize foreign currency impacts.

[0001571996-20-000017:mdna:50]
Key Performance Metrics

[0001571996-20-000017:mdna:51]
Our key performance metrics are net revenue, operating income, adjusted EBITDA, and cash flows from operations, which are discussed elsewhere in this report.

[0001571996-20-000017:mdna:52]
Class V Transaction

[0001571996-20-000017:mdna:53]
On December 28, 2018, we completed a transaction (“Class V transaction”) in which we paid $14.0 billion in cash and issued 149,387,617 shares of our Class C Common Stock to holders of our Class V Common Stock in exchange for all outstanding shares of Class V Common Stock.  The non-cash consideration portion of the Class V transaction totaled $6.9 billion.  As a result of the Class V transaction, the tracking stock feature of Dell Technologies’ capital structure was terminated.  The Class C Common Stock is traded on the New York Stock Exchange.

[0001571996-20-000017:mdna:54]
The aggregate cash consideration and the fees and expenses incurred in connection with the Class V transaction were funded with proceeds of $3.67 billion from new term loans under our senior secured credit facilities, proceeds of a margin loan financing in an aggregate principal amount of $1.35 billion, proceeds of Dell Technologies’ pro-rata portion, in the amount of $8.87 billion, of a special $11 billion cash dividend paid by VMware, Inc. in connection with the Class V transaction, and cash on hand at Dell Technologies and its subsidiaries.  See Note 6 of the Notes to the Consolidated Financial Statements included in this report for information about the debt we incurred to finance the Class V transaction.

[0001571996-20-000017:mdna:55]
NON-GAAP FINANCIAL MEASURES

[0001571996-20-000017:mdna:56]
In this management’s discussion and analysis, we use supplemental measures of our performance which are derived from our consolidated financial information but which are not presented in our consolidated financial statements prepared in accordance with GAAP.  These non-GAAP financial measures include non-GAAP product net revenue; non-GAAP services net revenue; non-GAAP net revenue; non-GAAP product gross margin; non-GAAP services gross margin; non-GAAP gross margin; non-GAAP operating expenses; non-GAAP operating income; non-GAAP net income; earnings before interest and other, net, taxes, depreciation, and amortization (“EBITDA”); and adjusted EBITDA.

[0001571996-20-000017:mdna:57]
We use non-GAAP financial measures to supplement financial information presented on a GAAP basis.  We believe that excluding certain items from our GAAP results allows management to better understand our consolidated financial performance from period to period and better project our future consolidated financial performance as forecasts are developed at a level of detail different from that used to prepare GAAP-based financial measures.  Moreover, we believe these non-GAAP financial measures provide our stakeholders with useful information to help them evaluate our operating results by facilitating an enhanced understanding of our operating performance and enabling them to make more meaningful period to period comparisons.  There are limitations to the use of the non-GAAP financial measures presented in this report.  Our non-GAAP financial measures may not be comparable to similarly titled measures of other companies.  Other companies, including companies in our industry, may calculate non-GAAP financial measures differently than we do, limiting the usefulness of those measures for comparative purposes.

[0001571996-20-000017:mdna:58]
Non-GAAP product net revenue, non-GAAP services net revenue, non-GAAP net revenue, non-GAAP product gross margin, non-GAAP services gross margin, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, and non-GAAP net income, as defined by us, exclude amortization of intangible assets, the impact of purchase accounting, transaction-related expenses, stock-based compensation expense, other corporate expenses and, for non-GAAP net income, fair value adjustments on equity adjustments and an aggregate adjustment for income taxes.  As the excluded items have a material impact on our financial results, our management compensates for this limitation by relying primarily on our GAAP results and using non-GAAP financial measures supplementally or for projections when comparable GAAP financial measures are not available.  The non-GAAP financial measures are not meant to be considered as indicators of performance in isolation from or as a substitute for net revenue, gross margin, operating expenses, operating income, or net income prepared in accordance with GAAP, and should be read only in conjunction with financial information presented on a GAAP basis.

[0001571996-20-000017:mdna:59]
Reconciliations of each non-GAAP financial measure to its most directly comparable GAAP financial measure are presented below.  We encourage you to review the reconciliations in conjunction with the presentation of the non-GAAP financial measures for each of the periods presented.  The discussion below includes information on each of the excluded items as well as our reasons for excluding them from our non-GAAP results.  In future fiscal periods, we may exclude such items and may incur income and expenses similar to these excluded items.  Accordingly, the exclusion of these items and other similar items in our non-GAAP presentation should not be interpreted as implying that these items are non-recurring, infrequent, or unusual.

[0001571996-20-000017:mdna:60]
Revenue Reclassifications — During Fiscal 2020, Dell Technologies made certain reclassifications of net revenue and non-GAAP net revenue between the products and services categories.  The reclassifications were made to provide a more meaningful representation of the nature of certain service and software-as-a-service offerings of VMware, Inc.  Prior period results were recast to conform with these changes, and resulted in an increase to services revenue and an equal and offsetting decrease to product revenue in the following amounts:  $584 million for the nine months ended November 1, 2019; $580 million for Fiscal 2019; and $353 million for Fiscal 2018.  Total net revenue, total gross margin, total non-GAAP net revenue, and total non-GAAP gross margin as previously reported remain unchanged.  The Company did not adjust cost of goods sold for the affected product offerings due to immateriality.

[0001571996-20-000017:mdna:61]
The following is a summary of the items excluded from the most comparable GAAP financial measures to calculate our non-GAAP financial measures:

[0001571996-20-000017:mdna:62]
| • | Amortization of Intangible Assets — Amortization of intangible assets primarily consists of amortization of customer relationships, developed technology, and trade names. In connection with our acquisition by merger of EMC on September 7, 2016, referred to as the EMC merger transaction, and the acquisition of Dell Inc. by Dell Technologies Inc. on October 29, 2013, referred to as the going-private transaction, all of the tangible and intangible assets and liabilities of EMC and Dell, respectively, were accounted for and recognized at fair value on the transaction dates. Accordingly, for the periods presented, amortization of intangible assets represents amortization associated with intangible assets recognized in connection with the EMC merger transaction and the going-private transaction. Amortization charges for purchased intangible assets are significantly impacted by the timing and magnitude of our acquisitions, and these charges may vary in amount from period to period. We exclude these charges for purposes of calculating the non-GAAP financial measures presented below to facilitate a more meaningful evaluation of our current operating performance and comparisons to our past operating performance. |

[0001571996-20-000017:mdna:63]
| • | Impact of Purchase Accounting — The impact of purchase accounting includes purchase accounting adjustments, related to the EMC merger transaction and, to a lesser extent, the going-private transaction, recorded under the acquisition method of accounting in accordance with the accounting guidance for business combinations. This guidance prescribes that the purchase price be allocated to assets acquired and liabilities assumed based on the estimated fair value of such assets and liabilities on the date of the transaction. Accordingly, all of the assets and liabilities acquired in the EMC merger transaction and the going-private transaction were accounted for and recognized at fair value as of the respective transaction dates, and the fair value adjustments are being amortized over the estimated useful lives in the periods following the transactions. The fair value adjustments primarily relate to deferred revenue, inventory, and property, plant, and equipment. Although purchase accounting adjustments and related amortization of those adjustments are reflected in our GAAP results, we evaluate the operating results of the underlying businesses on a non-GAAP basis, after removing such adjustments. We believe that excluding the impact of purchase accounting provides results that are useful in understanding our current operating performance and provides more meaningful comparisons to our past operating performance. |

[0001571996-20-000017:mdna:64]
| • | Transaction-related Expenses — Transaction-related expenses consist of acquisition, integration, and divestiture related costs, as well as the costs incurred in the Class V transaction, and are expensed as incurred. These expenses primarily represent costs for legal, banking, consulting, and advisory services, as well as certain compensatory retention awards directly related to the EMC merger transaction. During Fiscal 2020, transaction expenses related to various acquisition costs, primarily costs of VMware, Inc.’s acquisitions of Carbon Black and Pivotal. During Fiscal 2019, we incurred expenses of approximately $316 million for the completion of the Class V transaction, approximately $116 million for customer evaluation units, and approximately $100 million for manufacturing and engineering inventory. |

[0001571996-20-000017:mdna:65]
| • | Stock-based Compensation Expense — Stock-based compensation expense consists of equity awards granted based on the estimated fair value of those awards at grant date. We estimate the fair value of service-based stock options using the Black-Scholes valuation model. To estimate the fair value of performance-based awards containing a market condition, we use the Monte Carlo valuation model. For all other share-based awards, the fair value is based on the closing price of the Class C Common Stock as reported on the NYSE on the date of grant. Our non-GAAP adjustment for stock-based compensation expense was previously included within the non-GAAP adjustment for other corporate expenses. Due to the growth in our stock-based compensation expense, we have revised our presentation to present stock-based compensation expense separately in our reconciliations presented below. Although stock-based compensation is an important aspect of the compensation of the Company’s employees and executives, the fair value of the stock-based awards may bear little resemblance to the actual value realized upon the vesting or future exercise of the related stock-based awards. We believe that excluding stock-based compensation expense for purposes of calculating the non-GAAP financial measures presented below facilitates a more meaningful evaluation of our current operating performance and comparisons to our past operating performance. See Note 16 of the Notes to the Consolidated Financial Statements included in this report for additional information on equity award issuances. |

[0001571996-20-000017:mdna:66]
50

[0001571996-20-000017:mdna:67]
| • | Other Corporate Expenses — Other corporate expenses consist of impairment charges, severance, facility action, and other costs. Virtustream non-cash gross impairment charges of $619 million and $190 million were recognized in Fiscal 2020 and Fiscal 2019, respectively. See Note 8 of the Notes to the Consolidated Financial Statements included in this report for additional information on Virtustream impairment charges. During Fiscal 2020, this category includes a VMware, Inc. legal accrual of $237 million related to patent litigation. Severance costs are primarily related to severance and benefits for employees terminated pursuant to cost savings initiatives. We continue to integrate owned and leased facilities and may incur additional costs as we seek opportunities for operational efficiencies. Other corporate expenses vary from period to period and are significantly impacted by the timing and nature of these events. Therefore, although we may incur these types of expenses in the future, we believe that eliminating these charges for purposes of calculating the non-GAAP financial measures presented below facilitates a more meaningful evaluation of our current operating performance and comparisons to our past operating performance. |

[0001571996-20-000017:mdna:68]
| • | Fair Value Adjustments on Equity Investments — Fair value adjustments on equity investments primarily consists of the gain (loss) on strategic investments, which includes the recurring fair value adjustments of investments in publicly-traded companies, as well as those in privately-held companies, which are adjusted for observable price changes, and to a lesser extent, any potential impairments. Given the volatility in the ongoing adjustments to the valuation of these strategic investments, we believe that excluding these gains or losses for purposes of calculating non-GAAP net income presented below facilitates a more meaningful evaluation of our current operating performance and comparisons to our past operating performance. |

[0001571996-20-000017:mdna:69]
| • | Aggregate Adjustment for Income Taxes — The aggregate adjustment for income taxes is the estimated combined income tax effect for the adjustments described above, as well as an adjustment for discrete tax items. Due to the variability in recognition of discrete tax items from period to period, we believe that excluding these benefits or charges for purposes of calculating non-GAAP net income facilitates a more meaningful evaluation of our current operating performance and comparisons to our past operating performance. The tax effects are determined based on the tax jurisdictions where the above items were incurred. This category includes discrete tax benefits of $4.9 billion related to intra-entity asset transfers, $351 million related to stock-based compensation, and $305 million related to an audit settlement. See Note 11 of the Notes to the Consolidated Financial Statements included in this report for additional information on our income taxes. |

[0001571996-20-000017:mdna:70]
51

[0001571996-20-000017:mdna:71]
The table below presents a reconciliation of each non-GAAP financial measure to the most directly comparable GAAP measure for each of the periods presented.

[0001571996-20-000017:mdna:72]
|  | Fiscal Year Ended |
|  | January 31, 2020 |  | % Change |  | February 1, 2019 |  | % Change |  | February 2, 2018 |
|  | (in millions, except percentages) |
| Product net revenue | $ | 69,918 |  |  | (1 | )% |  | $ | 70,707 |  |  | 16 | % |  | $ | 60,898 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 19 |  |  |  |  | 61 |  |  |  |  | 170 |  |
| Non-GAAP product net revenue | $ | 69,937 |  |  | (1 | )% |  | $ | 70,768 |  |  | 16 | % |  | $ | 61,068 |  |
| Services net revenue | $ | 22,236 |  |  | 12 | % |  | $ | 19,914 |  |  | 10 | % |  | $ | 18,142 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 328 |  |  |  |  | 642 |  |  |  |  | 1,099 |  |
| Non-GAAP services net revenue | $ | 22,564 |  |  | 10 | % |  | $ | 20,556 |  |  | 7 | % |  | $ | 19,241 |  |
| Net revenue | $ | 92,154 |  |  | 2 | % |  | $ | 90,621 |  |  | 15 | % |  | $ | 79,040 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 347 |  |  |  |  | 703 |  |  |  |  | 1,269 |  |
| Non-GAAP net revenue | $ | 92,501 |  |  | 1 | % |  | $ | 91,324 |  |  | 14 | % |  | $ | 80,309 |  |
| Product gross margin | $ | 15,393 |  |  | 20 | % |  | $ | 12,818 |  |  | 35 | % |  | $ | 9,465 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 2,081 |  |  |  |  | 2,883 |  |  |  |  | 3,694 |  |
| Impact of purchase accounting | 28 |  |  |  |  | 78 |  |  |  |  | 213 |  |
| Transaction-related expenses | (5 | ) |  |  |  | 210 |  |  |  |  | 11 |  |
| Stock-based compensation expense | 10 |  |  |  |  | 27 |  |  |  |  | 6 |  |
| Other corporate expenses | 16 |  |  |  |  | 5 |  |  |  |  | 19 |  |
| Non-GAAP product gross margin | $ | 17,523 |  |  | 9 | % |  | $ | 16,021 |  |  | 19 | % |  | $ | 13,408 |  |
| Services gross margin | $ | 13,540 |  |  | 11 | % |  | $ | 12,235 |  |  | 11 | % |  | $ | 11,072 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 325 |  |  |  |  | 642 |  |  |  |  | 1,099 |  |
| Transaction-related expenses | — |  |  |  |  | 3 |  |  |  |  | 13 |  |
| Stock-based compensation expense | 119 |  |  |  |  | 64 |  |  |  |  | 60 |  |
| Other corporate expenses | 56 |  |  |  |  | 57 |  |  |  |  | 16 |  |
| Non-GAAP services gross margin | $ | 14,040 |  |  | 8 | % |  | $ | 13,001 |  |  | 6 | % |  | $ | 12,260 |  |

[0001571996-20-000017:mdna:73]
|  | Fiscal Year Ended |
|  | January 31, 2020 |  | % Change |  | February 1, 2019 |  | % Change |  | February 2, 2018 |
|  | (in millions, except percentages) |
| Gross margin | $ | 28,933 |  |  | 15 | % |  | $ | 25,053 |  |  | 22 | % |  | $ | 20,537 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 2,081 |  |  |  |  | 2,883 |  |  |  |  | 3,694 |  |
| Impact of purchase accounting | 353 |  |  |  |  | 720 |  |  |  |  | 1,312 |  |
| Transaction-related expenses | (5 | ) |  |  |  | 213 |  |  |  |  | 24 |  |
| Stock-based compensation expense | 129 |  |  |  |  | 91 |  |  |  |  | 66 |  |
| Other corporate expenses | 72 |  |  |  |  | 62 |  |  |  |  | 35 |  |
| Non-GAAP gross margin | $ | 31,563 |  |  | 9 | % |  | $ | 29,022 |  |  | 13 | % |  | $ | 25,668 |  |
| Operating expenses | $ | 26,311 |  |  | 4 | % |  | $ | 25,244 |  |  | 10 | % |  | $ | 22,953 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | (2,327 | ) |  |  |  | (3,255 | ) |  |  |  | (3,286 | ) |
| Impact of purchase accounting | (58 | ) |  |  |  | (100 | ) |  |  |  | (234 | ) |
| Transaction-related expenses | (290 | ) |  |  |  | (537 | ) |  |  |  | (478 | ) |
| Stock-based compensation expense | (1,133 | ) |  |  |  | (827 | ) |  |  |  | (769 | ) |
| Other corporate expenses | (1,088 | ) |  |  |  | (357 | ) |  |  |  | (290 | ) |
| Non-GAAP operating expenses | $ | 21,415 |  |  | 6 | % |  | $ | 20,168 |  |  | 13 | % |  | $ | 17,896 |  |
| Operating income (loss) | $ | 2,622 |  |  | NM |  |  | $ | (191 | ) |  | 92 | % |  | $ | (2,416 | ) |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 4,408 |  |  |  |  | 6,138 |  |  |  |  | 6,980 |  |
| Impact of purchase accounting | 411 |  |  |  |  | 820 |  |  |  |  | 1,546 |  |
| Transaction-related expenses | 285 |  |  |  |  | 750 |  |  |  |  | 502 |  |
| Stock-based compensation expense | 1,262 |  |  |  |  | 918 |  |  |  |  | 835 |  |
| Other corporate expenses | 1,160 |  |  |  |  | 419 |  |  |  |  | 325 |  |
| Non-GAAP operating income | $ | 10,148 |  |  | 15 | % |  | $ | 8,854 |  |  | 14 | % |  | $ | 7,772 |  |
| Net income (loss) | $ | 5,529 |  |  | 354 | % |  | $ | (2,181 | ) |  | 25 | % |  | $ | (2,926 | ) |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 4,408 |  |  |  |  | 6,138 |  |  |  |  | 6,980 |  |
| Impact of purchase accounting | 411 |  |  |  |  | 820 |  |  |  |  | 1,546 |  |
| Transaction-related expenses | 285 |  |  |  |  | 824 |  |  |  |  | 502 |  |
| Stock-based compensation expense | 1,262 |  |  |  |  | 918 |  |  |  |  | 835 |  |
| Other corporate expenses | 1,160 |  |  |  |  | 419 |  |  |  |  | 325 |  |
| Fair value adjustments on equity investments | (194 | ) |  |  |  | (342 | ) |  |  |  | (72 | ) |
| Aggregate adjustment for income taxes | (6,772 | ) |  |  |  | (1,369 | ) |  |  |  | (2,835 | ) |
| Non-GAAP net income | $ | 6,089 |  |  | 16 | % |  | $ | 5,227 |  |  | 20 | % |  | $ | 4,355 |  |

[0001571996-20-000017:mdna:74]
____________________

[0001571996-20-000017:mdna:75]
NM Not meaningful

[0001571996-20-000017:mdna:76]
53

[0001571996-20-000017:mdna:77]
In addition to the above measures, we also use EBITDA and adjusted EBITDA to provide additional information for evaluation of our operating performance.  Adjusted EBITDA excludes purchase accounting adjustments related to the EMC merger transaction and the going-private transaction, acquisition, integration, and divestiture related costs, impairment charges, and severance, facility action, and other costs, and stock-based compensation expense.  We believe that, due to the non-operational nature of the purchase accounting entries, it is appropriate to exclude these adjustments.

[0001571996-20-000017:mdna:78]
As is the case with the non-GAAP measures presented above, users should consider the limitations of using EBITDA and adjusted EBITDA, including the fact that those measures do not provide a complete measure of our operating performance.  EBITDA and adjusted EBITDA do not purport to be alternatives to net income (loss) as measures of operating performance or to cash flows from operating activities as a measure of liquidity.  In particular, EBITDA and adjusted EBITDA are not intended to be a measure of free cash flow available for management’s discretionary use, as these measures do not consider certain cash requirements, such as working capital needs, capital expenditures, contractual commitments, interest payments, tax payments, and other debt service requirements.

[0001571996-20-000017:mdna:79]
The table below presents a reconciliation of EBITDA and adjusted EBITDA to net income (loss) for the periods indicated:

[0001571996-20-000017:mdna:80]
|  | Fiscal Year Ended |
|  | January 31, 2020 |  | % Change |  | February 1, 2019 |  | % Change |  | February 2, 2018 |
|  | (in millions, except percentages) |
| Net income (loss) | $ | 5,529 |  |  | 354 | % |  | $ | (2,181 | ) |  | 25 | % |  | $ | (2,926 | ) |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Interest and other, net (a) | 2,626 |  |  |  |  | 2,170 |  |  |  |  | 2,353 |  |
| Income tax benefit (b) | (5,533 | ) |  |  |  | (180 | ) |  |  |  | (1,843 | ) |
| Depreciation and amortization | 6,143 |  |  |  |  | 7,746 |  |  |  |  | 8,634 |  |
| EBITDA | $ | 8,765 |  |  | 16 | % |  | $ | 7,555 |  |  | 22 | % |  | $ | 6,218 |  |
| EBITDA | $ | 8,765 |  |  | 16 | % |  | $ | 7,555 |  |  | 22 | % |  | $ | 6,218 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense | 1,262 |  |  |  |  | 918 |  |  |  |  | 835 |  |
| Impact of purchase accounting (c) | 347 |  |  |  |  | 704 |  |  |  |  | 1,274 |  |
| Transaction-related expenses (d) | 285 |  |  |  |  | 722 |  |  |  |  | 502 |  |
| Other corporate expenses (e) | 1,128 |  |  |  |  | 397 |  |  |  |  | 305 |  |
| Adjusted EBITDA | $ | 11,787 |  |  | 14 | % |  | $ | 10,296 |  |  | 13 | % |  | $ | 9,134 |  |

[0001571996-20-000017:mdna:81]
____________________

[0001571996-20-000017:mdna:82]
| (a) | See “Results of Operations — Interest and Other, Net” for more information on the components of interest and other, net. |

[0001571996-20-000017:mdna:83]
| (b) | See Note 11 of the Notes to the Consolidated Financial Statements included in this report for additional information on discrete tax items recorded in Fiscal 2020. |

[0001571996-20-000017:mdna:84]
| (c) | This amount includes the non-cash purchase accounting adjustments related to the EMC merger transaction and the going-private transaction. |

[0001571996-20-000017:mdna:85]
| (d) | Transaction-related expenses consist of acquisition, integration, and divestiture related costs, as well as the costs incurred in the Class V transaction. |

[0001571996-20-000017:mdna:86]
| (e) | Other corporate expenses includes impairment charges, severance, facility action, and other costs. See Note 8 of the Notes to the Consolidated Financial Statements included in this report for additional information on Virtustream impairment charges. |

[0001571996-20-000017:mdna:87]
RESULTS OF OPERATIONS

[0001571996-20-000017:mdna:88]
Consolidated Results

[0001571996-20-000017:mdna:89]
The following table summarizes our consolidated results for each of the periods presented.  Unless otherwise indicated, all changes identified for the current period results represent comparisons to results for the prior corresponding fiscal period.

[0001571996-20-000017:mdna:90]
Revenue Reclassifications — During Fiscal 2020, Dell Technologies made certain reclassifications of net revenue between the products and services categories.  Prior period results were recast to conform with these changes.  The Company did not recast cost of goods sold for the related revenue reclassifications due to immateriality.  Total net revenue, total gross margin, total non-GAAP net revenue, and total non-GAAP gross margin remain unchanged.  See Note 1 of the Notes to the Consolidated Financial Statements included in this report for further information regarding the reclassifications.

[0001571996-20-000017:mdna:91]
|  | Fiscal Year Ended |
|  | January 31, 2020 |  |  |  | February 1, 2019 |  |  |  | February 2, 2018 |
|  | Dollars |  | % ofNet Revenue |  | %Change |  | Dollars |  | % ofNet Revenue |  | %Change |  | Dollars |  | % ofNet Revenue |
|  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products | $ | 69,918 |  |  | 75.9 | % |  | (1 | )% |  | $ | 70,707 |  |  | 78.0 | % |  | 16 | % |  | $ | 60,898 |  |  | 77.0 | % |
| Services | 22,236 |  |  | 24.1 | % |  | 12 | % |  | 19,914 |  |  | 22.0 | % |  | 10 | % |  | 18,142 |  |  | 23.0 | % |
| Total net revenue | $ | 92,154 |  |  | 100.0 | % |  | 2 | % |  | $ | 90,621 |  |  | 100.0 | % |  | 15 | % |  | $ | 79,040 |  |  | 100.0 | % |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products (a) | $ | 15,393 |  |  | 22.0 | % |  | 20 | % |  | $ | 12,818 |  |  | 18.1 | % |  | 35 | % |  | $ | 9,465 |  |  | 15.5 | % |
| Services (b) | 13,540 |  |  | 60.9 | % |  | 11 | % |  | 12,235 |  |  | 61.4 | % |  | 11 | % |  | 11,072 |  |  | 61.0 | % |
| Total gross margin | $ | 28,933 |  |  | 31.4 | % |  | 15 | % |  | $ | 25,053 |  |  | 27.6 | % |  | 22 | % |  | $ | 20,537 |  |  | 26.0 | % |
| Operating expenses | $ | 26,311 |  |  | 28.6 | % |  | 4 | % |  | $ | 25,244 |  |  | 27.8 | % |  | 10 | % |  | $ | 22,953 |  |  | 29.1 | % |
| Operating income (loss) | $ | 2,622 |  |  | 2.8 | % |  | NM |  |  | $ | (191 | ) |  | (0.2 | )% |  | 92 | % |  | $ | (2,416 | ) |  | (3.1 | )% |
| Net income (loss) | $ | 5,529 |  |  | 6.0 | % |  | 354 | % |  | $ | (2,181 | ) |  | (2.4 | )% |  | 25 | % |  | $ | (2,926 | ) |  | (3.7 | )% |
| Net income (loss) attributable to Dell Technologies Inc. | $ | 4,616 |  |  | 5.0 | % |  | 300 | % |  | $ | (2,310 | ) |  | (2.5 | )% |  | 19 | % |  | $ | (2,849 | ) |  | (3.6 | )% |
| Non-GAAP Financial Information |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 69,937 |  |  | 75.6 | % |  | (1 | )% |  | $ | 70,768 |  |  | 77.5 | % |  | 16 | % |  | $ | 61,068 |  |  | 76.0 | % |
| Services | 22,564 |  |  | 24.4 | % |  | 10 | % |  | 20,556 |  |  | 22.5 | % |  | 7 | % |  | 19,241 |  |  | 24.0 | % |
| Total non-GAAP net revenue | $ | 92,501 |  |  | 100.0 | % |  | 1 | % |  | $ | 91,324 |  |  | 100.0 | % |  | 14 | % |  | $ | 80,309 |  |  | 100.0 | % |
| Non-GAAP gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product (a) | $ | 17,523 |  |  | 25.1 | % |  | 9 | % |  | $ | 16,021 |  |  | 22.6 | % |  | 19 | % |  | $ | 13,408 |  |  | 22.0 | % |
| Services (b) | 14,040 |  |  | 62.2 | % |  | 8 | % |  | 13,001 |  |  | 63.2 | % |  | 6 | % |  | 12,260 |  |  | 63.7 | % |
| Total non-GAAP gross margin | $ | 31,563 |  |  | 34.1 | % |  | 9 | % |  | $ | 29,022 |  |  | 31.8 | % |  | 13 | % |  | $ | 25,668 |  |  | 32.0 | % |
| Non-GAAP operating expenses | $ | 21,415 |  |  | 23.2 | % |  | 6 | % |  | $ | 20,168 |  |  | 22.1 | % |  | 13 | % |  | $ | 17,896 |  |  | 22.3 | % |
| Non-GAAP operating income | $ | 10,148 |  |  | 11.0 | % |  | 15 | % |  | $ | 8,854 |  |  | 9.7 | % |  | 14 | % |  | $ | 7,772 |  |  | 9.7 | % |
| Non-GAAP net income | $ | 6,089 |  |  | 6.6 | % |  | 16 | % |  | $ | 5,227 |  |  | 5.7 | % |  | 20 | % |  | $ | 4,355 |  |  | 5.4 | % |
| EBITDA | $ | 8,765 |  |  | 9.5 | % |  | 16 | % |  | $ | 7,555 |  |  | 8.3 | % |  | 22 | % |  | $ | 6,218 |  |  | 7.7 | % |
| Adjusted EBITDA | $ | 11,787 |  |  | 12.7 | % |  | 14 | % |  | $ | 10,296 |  |  | 11.3 | % |  | 13 | % |  | $ | 9,134 |  |  | 11.4 | % |

[0001571996-20-000017:mdna:92]
____________________

[0001571996-20-000017:mdna:93]
| (a) | Product gross margin percentages represent product gross margin as a percentage of product net revenue, and non-GAAP product gross margin percentages represent non-GAAP product gross margin as a percentage of non-GAAP product net revenue. |

[0001571996-20-000017:mdna:94]
| (b) | Services gross margin percentages represent services gross margin as a percentage of services net revenue, and non-GAAP services gross margin percentages represent non-GAAP services gross margin as a percentage of non-GAAP services net revenue. |

[0001571996-20-000017:mdna:95]
NM Not meaningful

[0001571996-20-000017:mdna:96]
55

[0001571996-20-000017:mdna:97]
Non-GAAP product net revenue, non-GAAP services net revenue, non-GAAP net revenue, non-GAAP product gross margin, non-GAAP services gross margin, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, EBITDA, and adjusted EBITDA are not measurements of financial performance prepared in accordance with GAAP.  Non-GAAP financial measures as a percentage of revenue are calculated based on non-GAAP net revenue.  See “Non‑GAAP Financial Measures” for additional information about these non-GAAP financial measures, including our reasons for including these measures, material limitations with respect to the usefulness of the measures, and a reconciliation of each non-GAAP financial measure to the most directly comparable GAAP financial measure.

[0001571996-20-000017:mdna:98]
Overview

[0001571996-20-000017:mdna:99]
During Fiscal 2020, our net revenue and non-GAAP net revenue increased 2% and 1%, respectively.  The increases in net revenue and non-GAAP net revenue were attributable to increases in net revenue in CSG and VMware, which were partially offset by declines in ISG net revenue.  The increase in CSG revenue primarily resulted from the Microsoft Windows 10 operating system refresh cycle combined with strong execution by the business.  VMware net revenue increased due to growth in software license revenue and strong renewals of VMware enterprise agreements, maintenance contracts sold in previous periods, and additional maintenance contracts sold in conjunction with new software license sales.  ISG net revenue decreased primarily because of weakness in servers and networking.  During Fiscal 2020, we benefited from the strength of our broad IT solutions portfolio, which helped us navigate market volatility and competitive pressures.  We believe we are well-positioned for long-term profitable growth while also maintaining the ability to adjust as needed to changing market conditions with complementary solutions across our businesses.

[0001571996-20-000017:mdna:100]
During Fiscal 2020 and Fiscal 2019, our operating income was $2.6 billion and operating loss was $0.2 billion, respectively.  The increase in our operating income for Fiscal 2020 was primarily attributable to an increase in operating income for CSG, resulting mainly from lower component costs and a decrease in amortization of intangible assets.  These benefits were partially offset by an increase in other corporate expenses, which primarily included Virtustream impairment charges.

[0001571996-20-000017:mdna:101]
Amortization of intangible assets and other corporate expenses that impacted operating income totaled $5.6 billion and $6.6 billion for Fiscal 2020 and Fiscal 2019, respectively.  Excluding these costs, the impact of purchase accounting, transaction-related expenses, and stock-based compensation expense, our non-GAAP operating income increased 15% to $10.1 billion during Fiscal 2020.  The increase in non-GAAP operating income for Fiscal 2020 was primarily due to an increase in operating income for CSG.

[0001571996-20-000017:mdna:102]
Cash provided by operating activities was $9.3 billion and $7.0 billion during Fiscal 2020 and Fiscal 2019, respectively.  The increase in operating cash flows during Fiscal 2020 was primarily driven by improved profitability and continued working capital discipline.  See “Market Conditions, Liquidity, Capital Commitments, and Contractual Cash Obligations” for further information on our cash flow metrics.

[0001571996-20-000017:mdna:103]
Net Revenue

[0001571996-20-000017:mdna:104]
Fiscal 2020 compared to Fiscal 2019

[0001571996-20-000017:mdna:105]
During Fiscal 2020, our net revenue and non-GAAP net revenue increased 2% and 1%, respectively.  The increases in net revenue and non-GAAP net revenue were attributable to increases in net revenue in CSG and VMware, which were partially offset by declines in ISG net revenue.  See “Business Unit Results” for further information.

[0001571996-20-000017:mdna:106]
| • | Product Net Revenue — Product net revenue includes revenue from the sale of hardware products and software licenses. During Fiscal 2020, both product net revenue and non-GAAP product net revenue decreased 1%. These decreases were primarily driven by decreases in product net revenue for ISG servers and networking, which were partially offset by increases in product net revenue for CSG and VMware. |

[0001571996-20-000017:mdna:107]
| • | Services Net Revenue — Services net revenue includes revenue from our services offerings and support services related to hardware products and software licenses. During Fiscal 2020, services net revenue and non-GAAP services net revenue increased 12% and 10%, respectively. These increases were primarily attributable to an increase in services revenue for hardware support and deployment and software maintenance due to growth in CSG and VMware. A substantial portion of services net revenue is derived from offerings that have been deferred over a period of time, and, as a result, reported services net revenue growth rates will be different than product net revenue growth rates. |

[0001571996-20-000017:mdna:108]
56

[0001571996-20-000017:mdna:109]
From a geographical perspective, net revenue generated by sales to customers in the Americas increased during Fiscal 2020 due to strong performance in CSG and VMware.  In EMEA, net revenue from sales to customers remained flat during Fiscal 2020.  Net revenue from sales to customers in APJ decreased slightly during Fiscal 2020, primarily as the result of a weaker demand environment for ISG servers and networking, particularly in China.

[0001571996-20-000017:mdna:110]
Fiscal 2019 compared to Fiscal 2018

[0001571996-20-000017:mdna:111]
During Fiscal 2019, our net revenue and non-GAAP net revenue increased 15% and 14%, respectively.  The increases in net revenue and non-GAAP net revenue were attributable to increases in net revenue across all three business units.  See “Business Unit Results” for further information.

[0001571996-20-000017:mdna:112]
| • | Product Net Revenue — During Fiscal 2019, both product net revenue and non-GAAP product net revenue increased 16%. These increases were attributable to an increase in product revenue across all three business units, driven by strength in sales across all product categories. |

[0001571996-20-000017:mdna:113]
| • | Services Net Revenue — During Fiscal 2019, services net revenue and non-GAAP services net revenue increased 10% and 7%, respectively. These increases were primarily due to an increase in services revenue for hardware support and deployment and software maintenance due to growth in the business. |

[0001571996-20-000017:mdna:114]
From a geographical perspective, net revenue generated by sales to customers in all regions increased in Fiscal 2019 due to strong performance globally in all three business units.

[0001571996-20-000017:mdna:115]
Gross Margin

[0001571996-20-000017:mdna:116]
Fiscal 2020 compared to Fiscal 2019

[0001571996-20-000017:mdna:117]
During Fiscal 2020, our gross margin increased 15% to $28.9 billion, and our gross margin percentage increased 380 basis points to 31.4%.  The increase in our gross margin percentage during Fiscal 2020 was primarily attributable to a deflationary component cost environment for both ISG and CSG, a greater contribution of VMware gross margin in the gross margin mix, and a decrease in amortization of intangibles and purchase accounting adjustments.

[0001571996-20-000017:mdna:118]
Our gross margin for Fiscal 2020 and Fiscal 2019 included the impact of amortization of intangibles and purchase accounting adjustments of $2.4 billion and $3.6 billion, respectively.  Excluding these costs, transaction-related expenses, stock-based compensation expense, and other corporate expenses, non-GAAP gross margin for Fiscal 2020 increased 9% to $31.6 billion, and non-GAAP gross margin percentage increased 230 basis points to 34.1%.  The increase in our non-GAAP gross margin was attributable to increases in gross margin for CSG and VMware.  The increase in our non-GAAP gross margin percentage was primarily due to higher gross margin percentages for both ISG and CSG which benefited from the deflationary component cost environment and a greater contribution of VMware gross margin in the gross margin mix.

[0001571996-20-000017:mdna:119]
| • | Products — During Fiscal 2020, product gross margin increased 20% to $15.4 billion, and product gross margin percentage increased 390 basis points to 22.0%. During Fiscal 2020, non-GAAP product gross margin increased 9% to $17.5 billion, and non-GAAP product gross margin percentage increased 250 basis points to 25.1%. The increases in product gross margin and non-GAAP product gross margin were driven primarily by the strength in sales of CSG commercial products and VMware software licenses and the deflationary component cost environment for ISG and CSG. Product gross margin also benefited from a decrease in amortization of intangibles and transaction-related costs. Product gross margin percentage and non-GAAP product gross margin percentage increased primarily due to the higher product gross margin percentages for both ISG and CSG, which benefited from the deflationary component cost environment. |

[0001571996-20-000017:mdna:120]
57

[0001571996-20-000017:mdna:121]
| • | Services — During Fiscal 2020, services gross margin increased 11% to $13.5 billion, and services gross margin percentage decreased slightly by 50 basis points to 60.9%. Services gross margin increased due to growth in services gross margin in VMware software maintenance. Services gross margin also benefited from a decrease in purchase accounting adjustments, which totaled $0.3 billion and $0.6 billion during Fiscal 2020 and Fiscal 2019, respectively. Excluding these costs, transaction-related expenses, stock-based compensation expense, and other corporate expenses, non-GAAP services gross margin increased 8% to $14.0 billion, and non-GAAP services gross margin percentage decreased 100 basis points to 62.2%. The decrease in services gross margin percentage and non-GAAP services gross margin percentage was primarily attributable to a decline in services gross margin percentage for CSG. |

[0001571996-20-000017:mdna:122]
Fiscal 2019 compared to Fiscal 2018

[0001571996-20-000017:mdna:123]
During Fiscal 2019, our gross margin increased 22% to $25.1 billion, and our gross margin percentage increased 160 basis points to 27.6%.  The increase in our gross margin percentage during Fiscal 2020 was primarily attributable to a decrease in amortization of intangibles and purchase accounting adjustments, offset partially by gross margin rate pressure in CSG and product mix dynamics in ISG due to growth in sales of servers, which typically have a lower gross margin than storage products.

[0001571996-20-000017:mdna:124]
Our gross margin for Fiscal 2019 and Fiscal 2018 included the impact of amortization of intangibles and purchase accounting adjustments of $3.6 billion and $5.0 billion, respectively.  Excluding these costs, transaction-related expenses, stock-based compensation expense, and other corporate expenses, non-GAAP gross margin for Fiscal 2019 increased 13% to $29.0 billion, and non-GAAP gross margin percentage decreased 20 basis points to 31.8%.  The increase in our non-GAAP gross margin was attributable to increases in gross margin across all three business units.  The decrease in our non-GAAP gross margin percentage was primarily due to product mix dynamics in ISG due to growth in sales of servers and gross margin rate pressure in CSG.

[0001571996-20-000017:mdna:125]
| • | Products — During Fiscal 2019, product gross margin increased 35% to $12.8 billion, and product gross margin percentage increased 260 basis points to 18.1%. The increases in both product gross margin and product gross margin percentage were primarily attributable to a decrease in amortization of intangibles and purchase accounting adjustments. During Fiscal 2019, non-GAAP product gross margin increased 19% to $16.0 billion, and non-GAAP product gross margin percentage increased 60 basis points to 22.6%. The increases in product gross margin and non-GAAP product gross margin were driven primarily by increases in product revenue in all three business units due to strength in sales of ISG servers and storage, CSG commercial products, and VMware software licenses. Product gross margin percentage and non-GAAP product gross margin percentage increased primarily as a result of higher product gross margin percentages for ISG and VMware. |

[0001571996-20-000017:mdna:126]
Our gross margins include benefits relating primarily to settlements from certain vendors regarding their past pricing practices.  During Fiscal 2018, we entered into a settlement agreement with a vendor to resolve a dispute regarding past pricing practices.  Vendor settlements are allocated to our segments based on the relative amount of affected vendor products sold by each segment.  Our gross margin for Fiscal 2018 included a benefit of $68 million related to receipt of payment under the settlement, which was entirely allocated to CSG.

[0001571996-20-000017:mdna:127]
| • | Services — During Fiscal 2019, services gross margin increased 11% to $12.2 billion, and services gross margin percentage increased 40 basis points to 61.4%. Services gross margin increased due to growth in services gross margin in CSG and VMware, particularly in hardware support and deployment and software maintenance. During Fiscal 2019 and Fiscal 2018, services gross margin also benefited from a decrease in purchase accounting adjustments, which totaled $0.6 billion and $1.1 billion, respectively. Excluding these costs, transaction-related expenses, stock-based compensation expense, and other corporate expenses, non-GAAP services gross margin increased 6% to $13.0 billion, and non-GAAP services gross margin percentage decreased 50 basis points to 63.2%. Services gross margin percentage decreased primarily due to lower services gross margin percentages in CSG and ISG. |

[0001571996-20-000017:mdna:128]
58

[0001571996-20-000017:mdna:129]
Vendor Programs and Settlements

[0001571996-20-000017:mdna:130]
Our gross margin is affected by our ability to achieve competitive pricing with our vendors and contract manufacturers, including through our negotiation of a variety of vendor rebate programs to achieve lower net costs for the various components we include in our products.  Under these programs, vendors provide us with rebates or other discounts from the list prices for the components, which are generally elements of their pricing strategy.  We account for vendor rebates and other discounts as a reduction in cost of net revenue.  We manage our costs on a total net cost basis, which includes supplier list prices reduced by vendor rebates and other discounts.

[0001571996-20-000017:mdna:131]
The terms and conditions of our vendor rebate programs are largely based on product volumes and are generally negotiated either at the beginning of the annual or quarterly period, depending on the program.  The timing and amount of vendor rebates and other discounts we receive under the programs may vary from period to period, reflecting changes in the competitive environment.  We monitor our component costs and seek to address the effects of any changes to terms that might arise under our vendor rebate programs.  Our gross margins for Fiscal 2020 and Fiscal 2019 were not materially affected by any changes to the terms of our vendor rebate programs, as the amounts we received under these programs were generally stable relative to our total net cost.  We are not aware of any significant changes to vendor pricing or rebate programs that may impact our results in the near term.

[0001571996-20-000017:mdna:132]
In addition, we have pursued legal action against certain vendors and are currently involved in negotiations with other vendors regarding their past pricing practices.  We have negotiated settlements with some of these vendors and may have additional settlements in future periods.  These settlements are allocated to our segments based on the relative amount of affected vendor products sold by each segment.  No such settlements were recorded in Fiscal 2020 or Fiscal 2019 that would have a material impact on product gross margins or affect comparability with product gross margin in Fiscal 2019 or Fiscal 2018.  Pricing settlements benefited product gross margins in Fiscal 2018 by $68 million.

[0001571996-20-000017:mdna:133]
Operating Expenses

[0001571996-20-000017:mdna:134]
The following table presents information regarding our operating expenses during each of the periods presented:

[0001571996-20-000017:mdna:135]
|  | Fiscal Year Ended |
|  | January 31, 2020 |  |  |  | February 1, 2019 |  |  |  | February 2, 2018 |
|  | Dollars |  | % ofNet Revenue |  | %Change |  | Dollars |  | % ofNet Revenue |  | %Change |  | Dollars |  | % ofNet Revenue |
|  | (in millions, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative | $ | 21,319 |  |  | 23.2 | % |  | 3 | % |  | $ | 20,640 |  |  | 22.7 | % |  | 11 | % |  | $ | 18,569 |  |  | 23.6 | % |
| Research and development | 4,992 |  |  | 5.4 | % |  | 8 | % |  | 4,604 |  |  | 5.1 | % |  | 5 | % |  | 4,384 |  |  | 5.5 | % |
| Total operating expenses | $ | 26,311 |  |  | 28.6 | % |  | 4 | % |  | $ | 25,244 |  |  | 27.8 | % |  | 10 | % |  | $ | 22,953 |  |  | 29.1 | % |
| Other Financial Information |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP operating expenses | $ | 21,415 |  |  | 23.2 | % |  | 6 | % |  | $ | 20,168 |  |  | 22.1 | % |  | 13 | % |  | $ | 17,896 |  |  | 22.3 | % |

[0001571996-20-000017:mdna:136]
Fiscal 2020 compared to Fiscal 2019

[0001571996-20-000017:mdna:137]
During Fiscal 2020, total operating expenses increased 4% primarily due to an increase in selling, general, and administrative expenses, partially offset by a decrease in amortization of intangibles.  Our operating expenses include the impact of purchase accounting, amortization of intangible assets, transaction-related expenses, stock-based compensation expense, and other corporate expenses.  In aggregate, these items totaled $4.9 billion and $5.1 billion in Fiscal 2020 and Fiscal 2019, respectively.  Excluding these costs, total non-GAAP operating expenses for Fiscal 2020 increased 6%.

[0001571996-20-000017:mdna:138]
| • | Selling, General, and Administrative — Selling, general, and administrative (“SG&A”) expenses increased 3% during Fiscal 2020. The increases in SG&A expenses were driven by investments in our go-to-market capabilities, including sales headcount, and higher performance-based compensation and commission costs. SG&A expenses also include Virtustream |

[0001571996-20-000017:mdna:139]
non-cash gross impairment charges of $619 million and $190 million in Fiscal 2020 and Fiscal 2019, respectively.  These increases were partially offset by a decrease in amortization of intangibles.

[0001571996-20-000017:mdna:140]
| • | Research and Development — Research and development (“R&D”) expenses are primarily composed of personnel-related expenses related to product development. R&D expenses as a percentage of net revenue for Fiscal 2020 and Fiscal 2019 were approximately 5.4% and 5.1%, respectively. As our industry continues to change and as the needs of our customers evolve, we intend to support R&D initiatives to innovate and introduce new and enhanced solutions into the market. |

[0001571996-20-000017:mdna:141]
We continue to make targeted investments designed to enable growth, particularly in our sales force, marketing, and R&D, while balancing these investments with our efforts to drive cost efficiencies in the business.  We also expect to continue to make investments in support of our own digital transformation to modernize and streamline our IT operations.

[0001571996-20-000017:mdna:142]
Fiscal 2019 compared to Fiscal 2018

[0001571996-20-000017:mdna:143]
During Fiscal 2019, total operating expenses increased 10%.  Other corporate expenses included a goodwill impairment charge of approximately $190 million.  In aggregate, the impact of purchase accounting, amortization of intangible assets, transaction-related expenses, stock-based compensation expense, and other corporate expenses totaled $5.1 billion for both Fiscal 2019 and Fiscal 2018.  Excluding these costs, total non-GAAP operating expenses for Fiscal 2019 increased 13%.  The increases in operating expenses and non-GAAP operating expenses were primarily due to an increase in selling, general, and administrative expenses associated with our revenue growth and sales headcount.

[0001571996-20-000017:mdna:144]
| • | Selling, General, and Administrative — Selling, general, and administrative expenses increased 11% during Fiscal 2019. The increases in SG&A expenses were primarily driven by investments in our go-to-market capabilities, including sales headcount, and higher performance-based compensation and commission costs, as well as a goodwill impairment charge of $190 million. |

[0001571996-20-000017:mdna:145]
| • | Research and Development — Research and development expenses are primarily composed of personnel-related expenses related to product development. R&D expenses as a percentage of net revenue for Fiscal 2019 and Fiscal 2018 were approximately 5.1% and 5.5%, respectively. The decreases in R&D expenses as a percentage of net revenue were attributable to revenue growth that outpaced the scale of R&D investments. As our industry continues to change and as the needs of our customers evolve, we intend to support R&D initiatives to innovate and introduce new and enhanced solutions into the market. |

[0001571996-20-000017:mdna:146]
Operating Income/Loss

[0001571996-20-000017:mdna:147]
Fiscal 2020 compared to Fiscal 2019

[0001571996-20-000017:mdna:148]
During Fiscal 2020, our operating income was $2.6 billion compared to an operating loss of $0.2 billion in Fiscal 2019 primarily due to lower component costs.  The operating income we recognized for Fiscal 2020 was primarily attributable to an increase in operating income for CSG and a decrease in amortization of intangible assets, partially offset by an increase in other corporate expenses, which primarily included Virtustream impairment charges.

[0001571996-20-000017:mdna:149]
Amortization of intangible assets and other corporate expenses that impacted operating income totaled $5.6 billion and $6.6 billion for Fiscal 2020 and Fiscal 2019, respectively.  Excluding these costs, the impact of purchase accounting, stock-based compensation expense, and transaction-related expenses, our non-GAAP operating income increased 15% to $10.1 billion during Fiscal 2020.  The increase in non-GAAP operating income for Fiscal 2020 was primarily due to an increase in operating income for CSG.

[0001571996-20-000017:mdna:150]
Fiscal 2019 compared to Fiscal 2018

[0001571996-20-000017:mdna:151]
During Fiscal 2019, our operating loss decreased 92% to $191 million.  The decrease in our operating loss for Fiscal 2019 was primarily attributable to a decrease in amortization of intangible assets and purchase accounting adjustments and an increase in operating income for ISG and, to a lesser extent, VMware.

[0001571996-20-000017:mdna:152]
60

[0001571996-20-000017:mdna:153]
Amortization of intangible assets and purchase accounting adjustments that impacted operating income totaled $7.0 billion and $8.5 billion for Fiscal 2019 and Fiscal 2018, respectively.  Excluding these costs, transaction-related expenses, stock-based compensation expense, and other corporate expenses, non-GAAP operating income increased 14% to $8.9 billion during Fiscal 2019.  The increase in non-GAAP operating income for Fiscal 2019 was primarily due to an increase in operating income for ISG and, to a lesser extent, VMware.

[0001571996-20-000017:mdna:154]
Interest and Other, Net

[0001571996-20-000017:mdna:155]
The following table provides information regarding interest and other, net for each of the periods presented:

[0001571996-20-000017:mdna:156]
|  | Fiscal Year Ended |
|  | January 31, 2020 |  | February 1, 2019 |  | February 2, 2018 |
|  | (in millions) |
| Interest and other, net: |  |  |  |  |  |  |  |
| Investment income, primarily interest | $ | 160 |  |  | $ | 313 |  |  | $ | 207 |  |
| Gain (loss) on strategic investments, net | 194 |  |  | 342 |  |  | 72 |  |
| Interest expense | (2,675 | ) |  | (2,488 | ) |  | (2,406 | ) |
| Foreign exchange | (162 | ) |  | (206 | ) |  | (113 | ) |
| Other | (143 | ) |  | (131 | ) |  | (113 | ) |
| Total interest and other, net | $ | (2,626 | ) |  | $ | (2,170 | ) |  | $ | (2,353 | ) |

[0001571996-20-000017:mdna:157]
Fiscal 2020 compared to Fiscal 2019

[0001571996-20-000017:mdna:158]
During Fiscal 2020, the change in interest and other, net was unfavorable by $456 million, primarily due to higher interest expense on higher average debt balances and decreases in net gain on strategic investments and investment income.  In connection with the Class V transaction, we incurred additional debt and liquidated a significant amount of our investments to fund a portion of the cash consideration paid.  This resulted in higher interest expense and lower investment income in Fiscal 2020.  The effect of increased debt incurred in connection with the Class V transaction was offset in part by our repayment of approximately $5 billion principal amount of debt during Fiscal 2020.  See Note 3 and Note 6 of the Notes to the Consolidated Financial Statements included in this report for further information regarding our investments and debt, respectively.

[0001571996-20-000017:mdna:159]
Fiscal 2019 compared to Fiscal 2018

[0001571996-20-000017:mdna:160]
In Fiscal 2019, we adopted the new accounting guidance for “Recognition and Measurement of Financial Assets and Financial Liabilities” on a prospective basis.  As a result, we record in interest and other, net changes in the fair value of our publicly-traded strategic investments and changes in the value of our strategic investments without readily determinable fair values when adjusted to fair value upon observable price changes or impairment.  During Fiscal 2019, the change in interest and other, net was favorable by $183 million, primarily due to gains on strategic investments.

[0001571996-20-000017:mdna:161]
Income and Other Taxes

[0001571996-20-000017:mdna:162]
Our effective income tax rate benefits were 138325.0%, 7.6%, and 38.6% on pre-tax losses of $4 million, $2,361 million, and $4,769 million for Fiscal 2020, Fiscal 2019,  and Fiscal 2018, respectively.  The change in our effective income tax rate for Fiscal 2020 as compared to Fiscal 2019 was primarily driven by discrete tax items and a change in our jurisdictional mix of income.  For Fiscal 2020, we had $5.5 billion in tax benefits on a loss before income taxes of $4 million.  The change in our effective income tax rate for Fiscal 2019 as compared to Fiscal 2018 was primarily attributable to impacts of the Tax Cuts and Jobs Act of 2017 (“U.S. Tax Reform”).

[0001571996-20-000017:mdna:163]
Our effective income tax rate in Fiscal 2020 includes $4.9 billion of discrete tax benefits related to intra-entity asset transfers, $351 million of discrete tax benefits related to stock-based compensation, $305 million of discrete tax benefits related to an audit settlement, and $95 million of discrete tax benefits relating to Virtustream impairment charges discussed in Note 8 of the Notes to the Consolidated Financial Statements included in this report.  In the first and second quarters of Fiscal 2020, we completed two intra-entity asset transfers of certain of our intellectual property to Irish subsidiaries, resulting in discrete tax benefits of $4.9 billion.  The tax benefit for each intra-entity asset transfer was recorded as a deferred tax asset in the period of

[0001571996-20-000017:mdna:164]
61

[0001571996-20-000017:mdna:165]
transaction and represents the book and tax basis difference on the transferred assets measured based on the applicable Irish statutory tax rate.  The tax deductions for amortization of the assets will be recognized in the future and any amortization not deducted for tax purposes will be carried forward indefinitely under Irish Tax laws.  We expect to be able to realize the deferred tax assets resulting from these intra-entity asset transfers.  Our effective tax rate in Fiscal 2019 includes $154 million of discrete tax benefits resulting from the impact of our adoption of the new revenue standard under ASC 606 in the first quarter of Fiscal 2019.

[0001571996-20-000017:mdna:166]
U.S. Tax Reform was signed into law on December 22, 2017.  Among other things, U.S. Tax Reform lowers the U.S. corporate income tax rate to 21% from 35%, establishes a modified territorial system requiring a mandatory deemed repatriation tax on undistributed earnings of foreign subsidiaries, requires a minimum tax on certain future earnings generated by foreign subsidiaries while providing for future tax-free repatriation of earnings through a 100% dividends-received deduction, and places limitations on the deductibility of net interest expense.  In December 2019, the U.S. Department of the Treasury released final and newly proposed regulations related to foreign tax credits and the base erosion anti-abuse tax, the impact of which was not material.  We anticipate that the U.S. Department of the Treasury and the Internal Revenue Service will continue to issue regulatory guidance clarifying certain provisions of U.S. Tax Reform.  When additional guidance is issued, we will recognize the related tax impact of our implementation of the guidance in the fiscal quarter of such issuance.

[0001571996-20-000017:mdna:167]
Our effective income tax rate can fluctuate depending on the geographic distribution of our worldwide earnings, as our foreign earnings are generally taxed at lower rates than in the United States.  The differences between our effective income tax rate and the U.S. federal statutory rate of 21% principally result from the geographical distribution of income and differences between the book and tax treatment of certain items.  In certain jurisdictions, our tax rate is significantly less than the applicable statutory rate as a result of tax holidays.  The majority of our foreign income that is subject to these tax holidays and lower tax rates is attributable to Singapore, China, and Malaysia.  A significant portion of these income tax benefits relates to a tax holiday that will be effective until January 31, 2029.  Our other tax holidays will expire in whole or in part during Fiscal 2022 through Fiscal 2030.  Many of these tax holidays and reduced tax rates may be extended when certain conditions are met or may be terminated early if certain conditions are not met.  As of January 31, 2020, we were not aware of any matters of noncompliance related to these tax holidays.

[0001571996-20-000017:mdna:168]
For further discussion regarding tax matters, including the status of income tax audits, see Note 11 of the Notes to the Consolidated Financial Statements included in this report.

[0001571996-20-000017:mdna:169]
Net Income/Loss

[0001571996-20-000017:mdna:170]
Fiscal 2020 compared to Fiscal 2019

[0001571996-20-000017:mdna:171]
During Fiscal 2020, net income was $5.5 billion, compared to a net loss of $2.2 billion in Fiscal 2019.  The net income we recognized during Fiscal 2020 was primarily attributable to an increase in tax benefit and, to a lesser extent, an increase in operating income, which was partially offset by an increase in interest and other, net expense.

[0001571996-20-000017:mdna:172]
Net income for Fiscal 2020 and net loss for Fiscal 2019 included amortization of intangible assets, the impact of purchase accounting, transaction-related expenses, stock-based compensation expense, other corporate expenses, fair value adjustments on equity investments, and discrete tax items.  Excluding these costs and the related tax impacts, non-GAAP net income increased 16% to $6.1 billion during Fiscal 2020.  The increase in non-GAAP net income during Fiscal 2020 was primarily attributable to an increase in operating income, which was partially offset by an increase in interest and other, net expense.

[0001571996-20-000017:mdna:173]
Fiscal 2019 compared to Fiscal 2018

[0001571996-20-000017:mdna:174]
During Fiscal 2019, net loss decreased 25% to $2.2 billion.  The decrease in net loss during Fiscal 2019 was primarily attributable to a decrease in operating loss and, to a lesser extent, a decrease in interest and other, net expense, which was partially offset by a decrease in tax benefit.

[0001571996-20-000017:mdna:175]
Excluding amortization of intangible assets, the impact of purchase accounting, transaction-related expenses, stock-based compensation expense, other corporate expenses, fair value adjustments on equity investments, discrete tax items, and the related tax impacts, non-GAAP net income increased 20% to $5.2 billion during Fiscal 2019.  The increase in non-GAAP net income during Fiscal 2019 was primarily attributable to an increase in operating income and a decrease in interest and other, net expense, which was partially offset by an increase in income tax expense.

[0001571996-20-000017:mdna:176]
62

[0001571996-20-000017:mdna:177]
Non-controlling Interests

[0001571996-20-000017:mdna:178]
Fiscal 2020 compared to Fiscal 2019

[0001571996-20-000017:mdna:179]
Net income or loss attributable to non-controlling interests consisted of net income or loss attributable to our non-controlling interests in VMware, Inc., Pivotal, and Secureworks.  Subsequent to VMware, Inc.’s acquisition of the non-controlling interest in Pivotal on December 30, 2019, we no longer have a separate non-controlling interest in Pivotal as of January 31, 2020.  During Fiscal 2020 and Fiscal 2019, net income attributable to non-controlling interests was $913 million and $129 million, respectively.  The increase in net income attributable to non-controlling interests in Fiscal 2020 was attributable to an increase in net income attributable to our non-controlling interest in VMware, Inc.  For more information about our non-controlling interests, see Note 13 of the Notes to the Consolidated Financial Statements included in this report.

[0001571996-20-000017:mdna:180]
Fiscal 2019 compared to Fiscal 2018

[0001571996-20-000017:mdna:181]
During Fiscal 2019, net income attributable to non-controlling interests was $129 million, compared to a net loss attributable to non-controlling interests of $77 million during Fiscal 2018.  Net income or loss attributable to non-controlling interests consisted of net income or loss attributable to our non-controlling interests in VMware, Inc., Pivotal, and Secureworks.

[0001571996-20-000017:mdna:182]
Net Income/Loss Attributable to Dell Technologies Inc.

[0001571996-20-000017:mdna:183]
Fiscal 2020 compared to Fiscal 2019

[0001571996-20-000017:mdna:184]
Net income or loss attributable to Dell Technologies Inc. represents net income or loss and an adjustment for non-controlling interests.  Net income attributable to Dell Technologies Inc. was $4.6 billion in Fiscal 2020, compared to net loss attributable to Dell Technologies Inc. of $2.3 billion in Fiscal 2019.  The net income attributable to Dell Technologies Inc. we recognized during Fiscal 2020 was primarily attributable to an increase in net income for the period.

[0001571996-20-000017:mdna:185]
Fiscal 2019 compared to Fiscal 2018

[0001571996-20-000017:mdna:186]
Net loss attributable to Dell Technologies Inc. represents net loss and an adjustment for non-controlling interests.  Net loss attributable to Dell Technologies Inc. was $2.3 billion and $2.8 billion, respectively, during Fiscal 2019 and Fiscal 2018.  The decrease in net loss attributable to Dell Technologies Inc. during Fiscal 2019 was primarily attributable to a decrease in net loss for the period.

[0001571996-20-000017:mdna:187]
Business Unit Results

[0001571996-20-000017:mdna:188]
Our reportable segments are based on the following business units: ISG, CSG, and VMware.  A description of our three business units is provided under “Introduction.”  See Note 19 of the Notes to the Consolidated Financial Statements included in this report for a reconciliation of net revenue and operating income by reportable segment to consolidated net revenue and consolidated operating income (loss), respectively.

[0001571996-20-000017:mdna:189]
Infrastructure Solutions Group:

[0001571996-20-000017:mdna:190]
The following table presents net revenue and operating income attributable to ISG for the respective periods:

[0001571996-20-000017:mdna:191]
|  | Fiscal Year Ended |
|  | January 31, 2020 |  | % Change |  | February 1, 2019 |  | % Change |  | February 2, 2018 |
|  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |  |  |  |  |
| Servers and networking | $ | 17,127 |  |  | (14 | )% |  | $ | 19,953 |  |  | 28 | % |  | $ | 15,533 |  |
| Storage | 16,842 |  |  | — | % |  | 16,767 |  |  | 9 | % |  | 15,384 |  |
| Total ISG net revenue | $ | 33,969 |  |  | (7 | )% |  | $ | 36,720 |  |  | 19 | % |  | $ | 30,917 |  |
| Operating income: |  |  |  |  |  |  |  |  |  |
| ISG operating income | $ | 4,001 |  |  | (4 | )% |  | $ | 4,151 |  |  | 35 | % |  | $ | 3,068 |  |
| % of segment net revenue | 11.8 | % |  |  |  | 11.3 | % |  |  |  | 9.9 | % |

[0001571996-20-000017:mdna:192]
Fiscal 2020 compared to Fiscal 2019

[0001571996-20-000017:mdna:193]
Net Revenue — During Fiscal 2020, ISG net revenue decreased 7% primarily due to a decrease in sales of servers and networking.  Revenue from servers and networking decreased 14% during Fiscal 2020, primarily driven by a decline in units sold of our PowerEdge servers due to a weaker demand environment.  Certain competitive dynamics also contributed to lower server sales volumes, as we focused on profitability over net revenue growth.  The decrease in ISG net revenue during Fiscal 2020 also reflected a decrease in average selling prices for servers due to competitive pressures in certain geographies, as well as component cost deflation.

[0001571996-20-000017:mdna:194]
Storage revenue remained flat during Fiscal 2020, with strong demand for hyper-converged products offset by softness in core storage.  We continue to make go-to-market investments and enhancements to our storage solutions offerings and expect that these investments will drive long-term improvements in the business.

[0001571996-20-000017:mdna:195]
Component costs were deflationary in the aggregate for ISG during Fiscal 2020, and we continue to monitor our pricing in response to the changing cost environment.  For Fiscal 2021, we expect an inflationary component cost environment, which may put pressure on ISG operating results, particularly in servers and networking.

[0001571996-20-000017:mdna:196]
We continue to see interest in flexible consumption models by our ISG customers as they seek to build greater flexibility into their cost structures.  We generally provide these solutions under multi-year contracts that typically result in recognition of revenue over the term of the arrangement.  We expect these flexible consumption models will further strengthen our customer relationships and will build more predictable revenue streams over time.

[0001571996-20-000017:mdna:197]
From a geographical perspective, net revenue attributable to ISG decreased in all regions during Fiscal 2020, with the largest decline in APJ.  The decrease in ISG revenue in APJ was driven by a weaker demand environment, particularly in China, which we expect to continue into Fiscal 2021.

[0001571996-20-000017:mdna:198]
Operating Income — During Fiscal 2020, ISG operating income as a percentage of net revenue increased 50 basis points to 11.8% due to an increase in ISG gross margin percentage resulting from the deflationary cost environment which benefited servers, as discussed above.  The increase in ISG operating margins was offset by an increase in ISG operating expenses as a percentage of ISG net revenue due to investments we made in our go-to-market capabilities to serve the needs of our customers.

[0001571996-20-000017:mdna:199]
64

[0001571996-20-000017:mdna:200]
Fiscal 2019 compared to Fiscal 2018

[0001571996-20-000017:mdna:201]
Net Revenue — During Fiscal 2019, ISG net revenue increased 19% primarily due to an increase in sales of servers and networking as well as an increase in sales of storage.  Revenue from servers and networking increased 28% during Fiscal 2019, driven by an increase in both average selling price and units sold of our PowerEdge servers.  Average selling prices increased due to the sale of servers with more robust compute capacity and higher memory and storage content, which was driven by customer demand for servers that enable big data analytics and software-defined storage solutions, including hyper-converged infrastructure, as well as increased component costs during the first half of Fiscal 2019.  Storage revenue increased 9% during Fiscal 2019 due to strong growth in our network-attached storage and object storage solutions.  Although component costs were inflationary during the first half of Fiscal 2019, they were slightly deflationary in the aggregate for ISG during the second half of Fiscal 2019.

[0001571996-20-000017:mdna:202]
From a geographical perspective, net revenue attributable to ISG increased across all regions during Fiscal 2019.

[0001571996-20-000017:mdna:203]
Operating Income — During Fiscal 2019, ISG operating income as a percentage of net revenue increased 140 basis points to 11.3% primarily due to a decrease in operating expenses as a percentage of revenue, partially offset by a decrease in ISG gross margin percentage.  Revenue growth outpaced our investments in go-to-market capabilities and solutions offerings, and, as a result, operating expenses decreased as a percentage of revenue.  We experienced gross margin pressure due to a shift in product mix to servers, which typically have a lower gross margin than storage products.

[0001571996-20-000017:mdna:204]
Client Solutions Group:

[0001571996-20-000017:mdna:205]
The following table presents net revenue and operating income attributable to CSG for the respective periods:

[0001571996-20-000017:mdna:206]
|  | Fiscal Year Ended |
|  | January 31, 2020 |  | % Change |  | February 1, 2019 |  | % Change |  | February 2, 2018 |
|  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 34,277 |  |  | 11 | % |  | $ | 30,893 |  |  | 12 | % |  | $ | 27,507 |  |
| Consumer | 11,561 |  |  | (6 | )% |  | 12,303 |  |  | 5 | % |  | 11,711 |  |
| Total CSG net revenue | $ | 45,838 |  |  | 6 | % |  | $ | 43,196 |  |  | 10 | % |  | $ | 39,218 |  |
| Operating income: |  |  |  |  |  |  |  |  |  |
| CSG operating income | $ | 3,138 |  |  | 60 | % |  | $ | 1,960 |  |  | (4 | )% |  | $ | 2,044 |  |
| % of segment net revenue | 6.8 | % |  |  |  | 4.5 | % |  |  |  | 5.2 | % |

[0001571996-20-000017:mdna:207]
Fiscal 2020 compared to Fiscal 2019

[0001571996-20-000017:mdna:208]
Net Revenue — During Fiscal 2020, CSG net revenue increased 6% primarily driven by the Microsoft Windows 10 operating system refresh cycle, combined with strong execution by the business.  Although we expect continued strong CSG demand into the early part of Fiscal 2021, we expect overall CSG demand will decelerate in Fiscal 2021 as the Windows 10 refresh cycle winds down.

[0001571996-20-000017:mdna:209]
During Fiscal 2020, commercial net revenue increased 11% due to continued strong demand for our commercial products across all product categories.  Consumer net revenue decreased 6%, due to lower demand as we continue to focus on commercial and higher-end consumer products.  The decline in consumer demand was partially offset by an increase in average selling prices in all consumer product categories in Fiscal 2020.

[0001571996-20-000017:mdna:210]
The aggregate CSG component cost environment was deflationary in Fiscal 2020, but for Fiscal 2021, we currently expect an inflationary component cost environment, which will put pressure on CSG operating results.

[0001571996-20-000017:mdna:211]
From a geographical perspective, net revenue attributable to CSG increased in the Americas, EMEA, and APJ increased during Fiscal 2020.

[0001571996-20-000017:mdna:212]
Operating Income — During Fiscal 2020, CSG operating income as a percentage of net revenue increased 230 basis points to 6.8%.  The increase was primarily due to lower component costs that positively impacted CSG gross margin and a shift in product mix to higher-margin product offerings.

[0001571996-20-000017:mdna:213]
Fiscal 2019 compared to Fiscal 2018

[0001571996-20-000017:mdna:214]
Net Revenue — During Fiscal 2019, CSG net revenue increased 10% due to continued strong demand for our commercial products and overall higher average selling prices driven by an increase in consumer sales.  Commercial net revenue increased 12%, driven primarily by increased demand across all product categories.  Consumer net revenue increased 5%, driven primarily by a shift in product mix to our high-end notebooks.  During Fiscal 2019, we effectively managed our pricing in response to supply chain dynamics, geographical mix, foreign currency exchange fluctuations, and the component cost environment.  The aggregate CSG component cost environment was deflationary in the second half of Fiscal 2019.

[0001571996-20-000017:mdna:215]
From a geographical perspective, net revenue attributable to CSG increased across all regions during Fiscal 2019.

[0001571996-20-000017:mdna:216]
Operating Income — During Fiscal 2019, CSG operating income as a percentage of net revenue decreased 70 basis points to 4.5%.  The decrease was primarily due to higher component costs during the first half of Fiscal 2019 that negatively impacted CSG gross margin and to increases in CSG operating expense as a percentage of revenue resulting from higher performance-driven commission costs and marketing expense related to our net revenue growth.  In addition, the decline in CSG operating income as a percentage of revenue during Fiscal 2019 was partially attributable to a $68 million vendor settlement benefit recorded during Fiscal 2018, which added an incremental 20 basis points to our operating income percentage in the prior period that did not recur.  Excluding the effect of this vendor settlement, CSG operating income as a percentage of revenue decreased 50 basis points during Fiscal 2019.

[0001571996-20-000017:mdna:217]
VMware:

[0001571996-20-000017:mdna:218]
The following table presents net revenue and operating income attributable to VMware for the respective periods.  During Fiscal 2020, the Company reclassified Pivotal operating results from other businesses to the VMware reportable segment.  Prior period results have been recast to conform with current period presentation.

[0001571996-20-000017:mdna:219]
|  | Fiscal Year Ended |
|  | January 31, 2020 |  | % Change |  | February 1, 2019 |  | % Change |  | February 2, 2018 |
|  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |  |  |  |  |
| VMware net revenue | $ | 10,905 |  |  | 12 | % |  | $ | 9,741 |  |  | 15 | % |  | $ | 8,485 |  |
| Operating income: |  |  |  |  |  |  |  |  |  |
| VMware operating income | $ | 3,081 |  |  | 5 | % |  | $ | 2,926 |  |  | 10 | % |  | $ | 2,671 |  |
| % of segment net revenue | 28.3 | % |  |  |  | 30.0 | % |  |  |  | 31.5 | % |

[0001571996-20-000017:mdna:220]
Fiscal 2020 compared to Fiscal 2019

[0001571996-20-000017:mdna:221]
Net Revenue — VMware net revenue, inclusive of Pivotal, primarily consists of revenue from the sale of software licenses under perpetual licenses for subscriptions and  SaaS, related software maintenance services, and support, training, consulting services, and hosted services.  VMware net revenue during Fiscal 2020 increased 12% primarily due to growth in subscriptions and SaaS, as well as an increase in sales of software maintenance services.  Software maintenance revenue benefited from strong renewals of VMware enterprise agreements, revenue recognized from maintenance contracts sold in prior periods, and additional maintenance contracts sold in conjunction with new software license sales.

[0001571996-20-000017:mdna:222]
66

[0001571996-20-000017:mdna:223]
From a geographical perspective, approximately half of VMware net revenue during Fiscal 2020 was generated by sales to customers in the United States.  VMware net revenue for Fiscal 2020 was positively affected by growth across U.S. and international markets.

[0001571996-20-000017:mdna:224]
Operating Income — During Fiscal 2020, VMware operating income as a percentage of net revenue decreased 170 basis points to 28.3%.  The decrease was driven by an increase in operating expenses as a percentage of net revenue as the result of an increase in compensation-related expense associated with sales and sales support, primarily due to increased headcount, as well as to an increase in R&D expenses.

[0001571996-20-000017:mdna:225]
Fiscal 2019 compared to Fiscal 2018

[0001571996-20-000017:mdna:226]
Net Revenue — VMware net revenue during Fiscal 2019 increased 15% primarily due to growth in subscription and SaaS software license revenue and sales of software maintenance services.  Software license revenue benefited from broad-based growth across the product portfolio.  Software maintenance revenue benefited from strong renewals, revenue recognized from maintenance contracts sold in prior periods, and new maintenance contracts sold during the period.

[0001571996-20-000017:mdna:227]
From a geographical perspective, approximately half of VMware net revenue during Fiscal 2019 was generated by sales to customers in the United States.  VMware net revenue for Fiscal 2019 benefited from growth across U.S. and international markets.

[0001571996-20-000017:mdna:228]
Operating Income — During Fiscal 2019, VMware operating income as a percentage of net revenue decreased 150 basis points to 30.0%.  The decrease was driven by an increase in operating expenses as a percentage of revenue due to an increase in compensation-related expense associated with sales and sales support, which reflected increased performance-driven commission costs and headcount, as well as to an increase in R&D expenses.

[0001571996-20-000017:mdna:229]
OTHER BALANCE SHEET ITEMS

[0001571996-20-000017:mdna:230]
Accounts Receivable

[0001571996-20-000017:mdna:231]
We sell products and services directly to customers and through other sales channels, such as value-added resellers, system integrators, distributors, and retailers.  Our accounts receivable, net, was $12.5 billion and $12.4 billion as of January 31, 2020 and February 1, 2019, respectively.  We maintain an allowance for doubtful accounts to cover receivables that may be deemed uncollectible.  The allowance for losses is based on a provision for accounts that are collectively evaluated based on historical bad debt experience as well as specific identifiable customer accounts that are deemed at risk.  As of January 31, 2020 and February 1, 2019, the allowance for doubtful accounts was $94 million and $85 million, respectively.  Based on our assessment, we believe that we are adequately reserved for expected credit losses.  We monitor the aging of our accounts receivable and continue to take actions to reduce our exposure to credit losses.

[0001571996-20-000017:mdna:232]
Dell Financial Services and Financing Receivables

[0001571996-20-000017:mdna:233]
Dell Financial Services and its affiliates (“DFS”) support Dell Technologies by offering and arranging various financing options and services for our customers globally, including through captive financing operations in North America, Europe, Australia, and New Zealand.  DFS originates, collects, and services customer receivables primarily related to the purchase of our product, software, and service solutions.  DFS further strengthens our customer relationships through its flexible consumption models, which enable us to offer our customers the option to pay over time and, in certain cases, based on utilization, to provide them with financial flexibility to meet their changing technological requirements.  New financing originations were $8.5 billion, $7.3 billion, and $6.3 billion for Fiscal 2020, Fiscal 2019, and Fiscal 2018, respectively.

[0001571996-20-000017:mdna:234]
As of February 2, 2019, we adopted the new lease standard discussed in Note 2 of the Notes to the Consolidated Financial Statements included in this report.  The adoption of the new lease standard did not result in a change to leases that commenced prior to adoption.  For new leases that commenced subsequent to the adoption of the new lease standard, we account for the leases as sales-type leases, direct financing leases, or operating leases depending on lease classification guidance.  Amounts due from lessees under sales-type leases or direct financing leases are recorded as part of financing receivables, with interest income recognized over the contract term.  On commencement of sales-type leases, we typically qualify for up-front revenue recognition.  On originations of operating leases, we record equipment under operating leases, classified as property, plant, and equipment, and recognize rental revenue and depreciation expense, classified as cost of net revenue, over the contract term.  Direct financing leases under the new lease standard are immaterial.

[0001571996-20-000017:mdna:235]
As of January 31, 2020 and February 1, 2019, our financing receivables, net were $9.7 billion and $8.6 billion, respectively.  We maintain an allowance to cover expected financing receivable credit losses and evaluate credit loss expectations based on our total portfolio.  For Fiscal 2020, Fiscal 2019, and Fiscal 2018, the principal charge-off rate for our total portfolio was 1.0%, 1.2%, and 1.5%, respectively.  The credit quality of our financing receivables has improved in recent years due to an overall improvement in the credit environment and as the mix of high-quality commercial accounts in our portfolio has continued to increase.  We continue to monitor broader economic indicators and their potential impact on future loss performance.  We have an extensive process to manage our exposure to customer credit risk, including active management of credit lines and our collection activities.  We also sell selected fixed-term financing receivables to unrelated third parties on a periodic basis, primarily to manage certain concentrations of customer credit exposure.  Based on our assessment of the customer financing receivables, we believe that we are adequately reserved.

[0001571996-20-000017:mdna:236]
We retain a residual interest in equipment leased under our lease programs.  As of January 31, 2020 and February 1, 2019, the residual interest recorded as part of financing receivables was $582 million and $674 million, respectively.  The amount of the residual interest is established at the inception of the lease based upon estimates of the value of the equipment at the end of the lease term using historical studies, industry data, and future value-at-risk demand valuation methods.  On a quarterly basis, we assess the carrying amount of our recorded residual values for impairment.  Generally, residual value risk on equipment under lease is not considered to be significant, because of the existence of a secondary market with respect to the equipment.  The lease agreement also clearly defines applicable return conditions and remedies for non-compliance, to ensure that the leased equipment will be in good operating condition upon return.  Model changes and updates, as well as market strength and product acceptance, are monitored and adjustments are made to residual values in accordance with the significance of any such changes.  Our remarketing sales staff works closely with customers and dealers to manage the sale of lease returns and the recovery of residual exposure.  No impairment losses were recorded related to residual assets during Fiscal 2020.

[0001571996-20-000017:mdna:237]
Equipment under operating leases, net was $840 million as of January 31, 2020 and was immaterial as of February 1, 2019.  The increase in equipment under operating leases, net is due to our adoption of the new lease standard and the elimination of the third-party residual value guarantee insurance in the lease classification test for sales-type leases.  Based on triggering events, we assess the carrying amount of the equipment under operating leases recorded for impairment.  No material impairment losses were recorded related to such equipment during Fiscal 2020.

[0001571996-20-000017:mdna:238]
DFS offerings are initially funded through cash on hand at the time of origination, most of which is subsequently replaced with third-party financing.  For DFS offerings which qualify as sales-type leases, the initial funding of financing receivables is reflected as an impact to cash flows from operations, and is largely subsequently offset by cash proceeds from financing.  For DFS operating leases, which have increased in Fiscal 2020 with the adoption of the new leasing standard, the initial funding is classified as a capital expenditure and reflected as an impact to cash flows used in investing activities.

[0001571996-20-000017:mdna:239]
See Note 4 of the Notes to the Consolidated Financial Statements included in this report for additional information about our financing receivables and the associated allowances.

[0001571996-20-000017:mdna:240]
Off-Balance Sheet Arrangements

[0001571996-20-000017:mdna:241]
As of January 31, 2020, we had no off-balance sheet arrangements that have or are reasonably likely to have a current or future material effect on our financial condition or results of operations.

[0001571996-20-000017:mdna:242]
69

[0001571996-20-000017:mdna:243]
MARKET CONDITIONS, LIQUIDITY, CAPITAL COMMITMENTS, AND CONTRACTUAL CASH OBLIGATIONS

[0001571996-20-000017:mdna:244]
Market Conditions

[0001571996-20-000017:mdna:245]
We regularly monitor economic conditions and associated impacts on the financial markets and our business.  We consistently evaluate the financial health of our supplier base, carefully manage customer credit, diversify counterparty risk, and monitor the concentration risk of our cash and cash equivalents balances globally.  We routinely monitor our financial exposure to borrowers and counterparties.

[0001571996-20-000017:mdna:246]
We monitor credit risk associated with our financial counterparties using various market credit risk indicators such as credit ratings issued by nationally recognized credit rating agencies and changes in market credit default swap levels.  We perform periodic evaluations of our positions with these counterparties and may limit exposure to any one counterparty in accordance with our policies.  We monitor and manage these activities depending on current and expected market developments.

[0001571996-20-000017:mdna:247]
We use derivative instruments to hedge certain foreign currency exposures.  We use forward contracts and purchased options designated as cash flow hedges to protect against the foreign currency exchange rate risks inherent in our forecasted transactions denominated in currencies other than the U.S. Dollar.  In addition, we primarily use forward contracts and may use purchased options to hedge monetary assets and liabilities denominated in a foreign currency.  See Note 7 of the Notes to the Consolidated Financial Statements included in this report for more information about our use of derivative instruments.

[0001571996-20-000017:mdna:248]
We are exposed to interest rate risk related to our variable-rate debt portfolio.  In the normal course of business, we follow established policies and procedures to manage this risk, including monitoring of our asset and liability mix.  As a result, we do not anticipate any material losses from interest rate risk.

[0001571996-20-000017:mdna:249]
The impact of any credit adjustments related to our use of counterparties on our Consolidated Financial Statements included in this report is immaterial.

[0001571996-20-000017:mdna:250]
Liquidity and Capital Resources

[0001571996-20-000017:mdna:251]
To support our ongoing business operations, we rely on operating cash flows as our primary source of liquidity.  We monitor the efficiency of our balance sheet to ensure that we have adequate liquidity to support our strategic initiatives.  In addition to internally generated cash, we have access to other capital sources to finance our strategic initiatives and fund growth in our financing operations.  As of January 31, 2020, we had $9.3 billion of total cash and cash equivalents.  Our strategy is to deploy capital from any potential source, whether internally generated cash or debt, depending on the adequacy and availability of that source of capital and whether it can be accessed in a cost-effective manner.

[0001571996-20-000017:mdna:252]
During the fourth quarter of Fiscal 2019, as discussed above in “Introduction — Class V Transaction,” we completed a transaction in which all issued and outstanding shares of Class V Common Stock were exchanged for cash or shares of Class C Common Stock at the stockholder’s election.  We paid a total of $14 billion of cash to holders of Class V Common Stock.  To fund a majority of the cash payment to stockholders, VMware, Inc. declared a $11 billion one-time special cash dividend (the “Special Dividend”), which was paid pro-rata to VMware, Inc. stockholders as of the dividend record date of December 27, 2018 and in connection with the completion of the Class V transaction.  Our cash, cash equivalents, and investments declined significantly, commensurate with the cash required to fund this transaction.

[0001571996-20-000017:mdna:253]
We funded a majority of the cash consideration paid in the Class V transaction from the $8.87 billion of the proceeds of the Special Dividend.  The remaining amount of the cash consideration was primarily funded with $3.67 billion of proceeds from new senior secured term loans under our senior secured credit facilities and proceeds of a margin loan financing in an aggregate principal amount of $1.35 billion.  See Note 6 of the Notes to the Consolidated Financial Statements included in this report for information about the debt we incurred to finance the Class V transaction.

[0001571996-20-000017:mdna:254]
The following table presents our cash and cash equivalents as well as our available borrowings as of the dates indicated:

[0001571996-20-000017:mdna:255]
|  | January 31, 2020 |  | February 1, 2019 |
|  | (in millions) |
| Cash and cash equivalents, and available borrowings: |  |  |  |
| Cash and cash equivalents (a) | $ | 9,302 |  |  | $ | 9,676 |  |
| Remaining available borrowings under revolving credit facilities | 5,972 |  |  | 5,586 |  |
| Total cash, cash equivalents, and available borrowings | $ | 15,274 |  |  | $ | 15,262 |  |

[0001571996-20-000017:mdna:256]
____________________

[0001571996-20-000017:mdna:257]
| (a) | Of the $9.3 billion of cash and cash equivalents as of January 31, 2020, $2.9 billion was held by VMware, Inc. |

[0001571996-20-000017:mdna:258]
Our revolving credit facilities as of January 31, 2020 include the Revolving Credit Facility and the China Revolving Credit Facility.  The Revolving Credit Facility and the China Revolving Credit Facility have maximum aggregate borrowings of $4.5 billion and $0.5 billion, respectively.  Available borrowings under these facilities are reduced by draws on the facility and, under the Revolving Credit Facility, outstanding letters of credit.  As of January 31, 2020, there were no borrowings outstanding under the facilities and remaining available borrowings totaled approximately $5.0 billion.  We may regularly use our available borrowings from our Revolving Credit Facility on a short-term basis for general corporate purposes.

[0001571996-20-000017:mdna:259]
In March 2020, we drew $3.0 billion under the Revolving Credit Facility, with the majority of the proceeds held as cash and cash equivalents.  We increased our borrowing under the Revolving Credit Facility as a precautionary measure to increase our cash position and preserve financial flexibility in light of current disruption and uncertainty in the global markets resulting from the outbreak of COVID-19.

[0001571996-20-000017:mdna:260]
Subsequent to January 31, 2020, upon the expiration of the China Revolving Credit Facility in February 2020, the facility terminated.

[0001571996-20-000017:mdna:261]
The VMware Revolving Credit Facility has maximum aggregate borrowings of $1.0 billion.  As of January 31, 2020, $1.0 billion was available under the VMware Revolving Credit Facility.  The VMware Term Loan Facility has a borrowing capacity of up to $2.0 billion.  VMware, Inc. may borrow against the VMware Term Loan Facility two times up to its borrowing capacity of $2.0 billion until February 7, 2020.  As of January 31, 2020, borrowings under the facility were $1.5 billion, with no remaining amount available for additional borrowings.  None of the net proceeds of such borrowings are made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.

[0001571996-20-000017:mdna:262]
The Pivotal Revolving Credit Facility had maximum aggregate borrowings of $100 million and was terminated during Fiscal 2020.

[0001571996-20-000017:mdna:263]
See Note 6 of the Notes to the Consolidated Financial Statements included in this report for additional information about each of the foregoing revolving credit facilities.

[0001571996-20-000017:mdna:264]
We believe that our current cash and cash equivalents, together with cash that will be provided by future operations and expected borrowings under our revolving credit facilities, will be sufficient over at least the next twelve months to fund our operations, debt service requirements and maturities, capital expenditures, share repurchases, and other corporate needs.

[0001571996-20-000017:mdna:265]
Debt

[0001571996-20-000017:mdna:266]
The following table presents our outstanding debt as of the dates indicated:

[0001571996-20-000017:mdna:267]
|  | January 31, 2020 |  | Increase (Decrease) |  | February 1, 2019 |
|  | (in millions) |
| Core debt |  |  |  |  |  |
| Senior Secured Credit Facilities and First Lien Notes | $ | 29,664 |  |  | $ | (3,056 | ) |  | $ | 32,720 |  |
| Unsecured Notes and Debentures | 1,352 |  |  | (600 | ) |  | 1,952 |  |
| Senior Notes | 2,700 |  |  | (550 | ) |  | 3,250 |  |
| EMC Notes | 1,600 |  |  | (1,400 | ) |  | 3,000 |  |
| DFS allocated debt | (1,495 | ) |  | 120 |  |  | (1,615 | ) |
| Total core debt | 33,821 |  |  | (5,486 | ) |  | 39,307 |  |
| DFS related debt |  |  |  |  |  |
| DFS debt | 7,765 |  |  | 1,836 |  |  | 5,929 |  |
| DFS allocated debt | 1,495 |  |  | (120 | ) |  | 1,615 |  |
| Total DFS related debt | 9,260 |  |  | 1,716 |  |  | 7,544 |  |
| Margin Loan Facility and other | 4,024 |  |  | 636 |  |  | 3,388 |  |
| Debt of public subsidiary |  |  |  |  |  |
| VMware Notes | 4,000 |  |  | — |  |  | 4,000 |  |
| VMware Term Loan Facility | 1,500 |  |  | 1,500 |  |  | — |  |
| Other | 60 |  |  | 60 |  |  | — |  |
| Total public subsidiary debt | 5,560 |  |  | 1,560 |  |  | 4,000 |  |
| Total debt, principal amount | 52,665 |  |  | (1,574 | ) |  | 54,239 |  |
| Carrying value adjustments | (609 | ) |  | 109 |  |  | (718 | ) |
| Total debt, carrying value | $ | 52,056 |  |  | $ | (1,465 | ) |  | $ | 53,521 |  |

[0001571996-20-000017:mdna:268]
During Fiscal 2020, the outstanding principal amount of our debt decreased by $1.6 billion to $52.7 billion as of January 31, 2020.

[0001571996-20-000017:mdna:269]
During Fiscal 2020, core debt decreased by $5.5 billion to $33.8 billion as of January 31, 2020.  We define core debt as the total principal amount of our debt, less DFS related debt, our Margin Loan Facility and other debt, and public subsidiary debt.  The decrease in core debt was primarily due to our deleveraging efforts.  See Note 6 of the Notes to the Consolidated Financial Statements included in this report for more information about our debt.

[0001571996-20-000017:mdna:270]
During Fiscal 2020, we issued an additional $1.8 billion, net, in DFS debt to support the expansion of its financing receivables portfolio.  DFS related debt primarily represents debt from our securitization and structured financing programs.  The majority of DFS debt is non-recourse to Dell Technologies and represents borrowings under securitization programs and structured financing programs, for which our risk of loss is limited to transferred lease and loan payments and associated equipment, and the credit holders under these programs have no recourse to Dell Technologies.

[0001571996-20-000017:mdna:271]
To fund expansion of the DFS business, we balance the use of the securitization and structured financing programs with other sources of liquidity.  We approximate the amount of our debt used to fund the DFS business by applying a 7:1 debt to equity ratio to the sum of our financing receivables balance and equipment under our DFS operating leases, net.  The debt to equity ratio is based on the underlying credit quality of the assets.  See Note 4 of the Notes to the Consolidated Financial Statements included in this report for more information about our DFS debt.

[0001571996-20-000017:mdna:272]
As of January 31, 2020, margin loan and other debt primarily consisted of the $4.0 billion Margin Loan Facility.  We amended the Margin Loan Facility during the first quarter of Fiscal 2020, and increased the principal amount of the facility by $650 million to $4.0 billion.  As of February 1, 2019, margin loan and other debt primarily consisted of the $3.4 billion Margin Loan Facility.

[0001571996-20-000017:mdna:273]
72

[0001571996-20-000017:mdna:274]
Public subsidiary debt represents VMware, Inc. indebtedness.  During Fiscal 2020, VMware, Inc. entered into a senior unsecured term loan facility described above.  As of January 31, 2020, borrowings under the facility were $1.5 billion.  See Note 6 of the Notes to the Consolidated Financial Statements included in this report for more information about VMware, Inc. debt.

[0001571996-20-000017:mdna:275]
VMware, Inc. and its respective subsidiaries are unrestricted subsidiaries for purposes of the core debt of Dell Technologies.  Neither Dell Technologies nor any of its subsidiaries, other than VMware, Inc., is obligated to make payment on the VMware Notes or the VMware Term Loan Facility.  None of the net proceeds of the VMware Notes or the VMware Term Loan Facility are made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and its subsidiaries.

[0001571996-20-000017:mdna:276]
Our requirements for cash to pay principal and interest on our debt increased significantly due to the borrowings we incurred to finance the EMC merger transaction, and to a lesser extent, the Class V transaction.  We have made good progress in paying down core debt since the EMC merger transaction.  We believe we will continue to be able to make our debt principal and interest payments, including the short-term maturities, from existing and expected sources of cash, primarily from operating cash flows.  Cash used for debt principal and interest payments may include short-term borrowings under our revolving credit facilities.  We will continue to focus on paying down core debt.  Under our variable-rate debt, we could experience variations in our future interest expense from potential fluctuations in LIBOR, or from possible fluctuations in the level of DFS debt required to meet future demand for customer financing.  We or our affiliates or their related persons, at our or their sole discretion, may purchase, redeem, prepay, refinance, or otherwise retire any amount of our outstanding indebtedness under the terms of such indebtedness at any time and from time to time, in open market or negotiated transactions with the holders of such indebtedness or otherwise, as appropriate market conditions exist.

[0001571996-20-000017:mdna:277]
Cash Flows

[0001571996-20-000017:mdna:278]
The following table presents a summary of our Consolidated Statements of Cash Flows for the periods indicated:

[0001571996-20-000017:mdna:279]
|  | Fiscal Year Ended |
|  | January 31, 2020 |  | February 1, 2019 |  | February 2, 2018 |
|  | (in millions) |
| Net change in cash from: |  |  |  |  |  |
| Operating activities | $ | 9,291 |  |  | $ | 6,991 |  |  | $ | 6,843 |  |
| Investing activities | (4,686 | ) |  | 3,389 |  |  | (2,875 | ) |
| Financing activities | (4,604 | ) |  | (14,329 | ) |  | 403 |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash | (90 | ) |  | (189 | ) |  | 175 |  |
| Change in cash, cash equivalents, and restricted cash | $ | (89 | ) |  | $ | (4,138 | ) |  | $ | 4,546 |  |

[0001571996-20-000017:mdna:280]
Operating Activities — Cash provided by operating activities was $9.3 billion and $7.0 billion during Fiscal 2020 and Fiscal 2019, respectively.  The increase in operating cash flows during Fiscal 2020 was attributable improved profitability and working capital discipline.  During Fiscal 2019, we experienced supply chain dynamics that temporarily increased our inventory and negatively impacted working capital.  These dynamics normalized in Fiscal 2020 with a resulting decrease to inventory and beneficial impact to our working capital.

[0001571996-20-000017:mdna:281]
Cash provided by operating activities was $7.0 billion and $6.8 billion during Fiscal 2019 and Fiscal 2018, respectively.  The increase in operating cash flows during Fiscal 2019 was attributable to business growth, which drove higher deferred revenue and improved profitability due to product mix and higher average selling prices, partially offset by an increase in inventory.

[0001571996-20-000017:mdna:282]
DFS offerings are initially funded through cash on hand at the time of origination, most of which is subsequently replaced with third-party financing.  For DFS offerings which qualify as sales-type leases, the initial funding of financing receivables is reflected as an impact to cash flows from operations, and is largely subsequently offset by cash proceeds from financing.  For DFS operating leases, which have increased in Fiscal 2020 with the adoption of the new leasing standard,  the initial funding is classified as capital expenditures and reflected as cash flows used in investing activities.  DFS new financing originations were

[0001571996-20-000017:mdna:283]
$8.5 billion and $7.3 billion during Fiscal 2020 and Fiscal 2019, respectively.  As of January 31, 2020, DFS had $9.7 billion of total net financing receivables and $0.8 billion of equipment under DFS operating leases, net.

[0001571996-20-000017:mdna:284]
Investing Activities — Investing activities primarily consist of cash used to fund capital expenditures for property, plant, and equipment, capital expenditures for equipment under DFS operating leases, capitalized software development costs, strategic investments, acquisitions of businesses, and the maturities, sales, and purchases of investments.  During Fiscal 2020, cash used in investing activities was $4.7 billion and was primarily driven by capital expenditures and acquisition of businesses.

[0001571996-20-000017:mdna:285]
Cash provided by investing activities was $3.4 billion during Fiscal 2019 and was primarily driven by the net sales of investments used to fund the Class V transaction, partially offset by capital expenditures and strategic investments.  During Fiscal 2018, cash used by investing activities was $2.9 billion and was primarily driven by capital expenditures, capitalized software development costs, and net purchases of investments.

[0001571996-20-000017:mdna:286]
Financing Activities — Financing activities primarily consist of the proceeds and repayments of debt, cash used to repurchase common stock, and proceeds from the issuance of common stock of subsidiaries.  Cash used in financing activities of $4.6 billion during Fiscal 2020 primarily consisted of net repayments of debt and repurchases of common stock by our public subsidiaries, primarily related to VMware Inc.’s acquisition of Pivotal.

[0001571996-20-000017:mdna:287]
Cash used in financing activities of $14.3 billion during Fiscal 2019 primarily consisted of $14.0 billion in cash paid to holders of the Class V Common Stock in the Class V transaction, partially offset by debt proceeds of $5.0 billion of debt incurred to fund a portion of this payment.  Cash used by financing activities also included our repayments of an EMC Note in the amount of $2.5 billion and the Term Loan A-3 Facility in the amount of $1.2 billion, as well as the payment to VMware, Inc.’s public stockholders of $2.1 billion of the Special Dividend.

[0001571996-20-000017:mdna:288]
During Fiscal 2018, cash provided by financing activities of $0.4 billion was primarily driven by net proceeds from debt, primarily due to the issuance of the VMware Notes, partially offset by cash used for share repurchases.

[0001571996-20-000017:mdna:289]
Capital Commitments

[0001571996-20-000017:mdna:290]
Capital Expenditures — During Fiscal 2020, we spent $2.2 billion on property, plant, and equipment, which included equipment under DFS operating leases of $0.9 billion.  During Fiscal 2019, we spent $1.2 billion on property, plant, and equipment.  These expenditures were incurred in connection with our global expansion efforts and infrastructure investments made to support future growth, and, in Fiscal 2020, the funding of equipment under DFS operating leases.  Product demand, product mix, and the use of contract manufacturers, as well as ongoing investments in operating and information technology infrastructure, influence the level and prioritization of our capital expenditures.  Aggregate capital expenditures for Fiscal 2021, are expected to total between $2.4 billion and $2.6 billion, of which approximately $1.0 billion to $1.1 billion is expected for  equipment under DFS operating leases.

[0001571996-20-000017:mdna:291]
Repurchases of Common Stock

[0001571996-20-000017:mdna:292]
On February 24, 2020, our board of directors approved a share repurchase program under which we are authorized to repurchase up to $1.0 billion of shares of Class C Common Stock over a 24-month period expiring on February 28, 2022.

[0001571996-20-000017:mdna:293]
Class V Common Stock Repurchases by Dell Technologies Inc.

[0001571996-20-000017:mdna:294]
Since the date of the EMC merger transaction, our board of directors authorized several programs with a total authorization of $2.1 billion to repurchase shares of our Class V Common Stock.  Upon the completion of the Class V transaction, no Class V Common Stock remained outstanding for repurchase.

[0001571996-20-000017:mdna:295]
During Fiscal 2019, we did not repurchase any shares of Class V Common Stock under our stock repurchase programs.  During Fiscal 2018, we repurchased 9.7 million shares of Class V Common Stock for an aggregate purchase price of $682 million.  The repurchase of these shares was funded by proceeds received by the Class V Group from the sale by our subsidiary of shares of Class A common stock of VMware, Inc. owned by such subsidiary, as discussed below.

[0001571996-20-000017:mdna:296]
DHI Group Common Stock Repurchases by Dell Technologies Inc.

[0001571996-20-000017:mdna:297]
During Fiscal 2019 and Fiscal 2018, we repurchased an immaterial number of shares of DHI Group Common Stock for $47 million and $6 million, respectively.

[0001571996-20-000017:mdna:298]
VMware, Inc. Class A Common Stock Repurchases by VMware, Inc.

[0001571996-20-000017:mdna:299]
On May 29, 2019, VMware, Inc.’s board of directors authorized the repurchase of an additional $1.5 billion of VMware, Inc.’s Class A common stock.  Since the date of the EMC merger transaction, VMware, Inc.’s board of directors has authorized total repurchases of $3.7 billion, of which $1.0 billion remained available as of January 31, 2020.  During Fiscal 2020, VMware, Inc. repurchased 7.7 million shares of its Class A common stock in the open market for approximately $1.3 billion, of which approximately $0.2 billion impacted Dell Technologies’ accumulated deficit balance as of January 31, 2020 as a result of the periodic depletion of VMware, Inc.’s additional paid-in capital balance.

[0001571996-20-000017:mdna:300]
During Fiscal 2019, VMware, Inc. repurchased approximately 0.3 million shares of its Class A common stock in the open market for an aggregate purchase price of $42 million.  During Fiscal 2018, pursuant to stock repurchase agreements between Dell Technologies Inc. and VMware, Inc., VMware, Inc. repurchased 7.5 million shares of its Class A common stock from us for an aggregate purchase price of $725 million.  VMware, Inc. received 4.1 million shares of its Class A common stock during the first quarter of Fiscal 2018, 0.7 million shares during the second quarter of Fiscal 2018 and the remaining 2.7 million shares of its Class A common stock during the third quarter of Fiscal 2018.  The proceeds from the sales were used by us to repurchase shares of our Class V Common Stock, as described above.

[0001571996-20-000017:mdna:301]
Contractual Cash Obligations

[0001571996-20-000017:mdna:302]
The following table presents a summary our contractual cash obligations as of January 31, 2020:

[0001571996-20-000017:mdna:303]
|  |  |  | Payments Due by Fiscal Year |
|  | Total |  | 2021 |  | 2022-2023 |  | 2024-2025 |  | Thereafter |
|  | (in millions) |
| Contractual cash obligations: |  |  |  |  |  |  |  |  |  |
| Principal payments on long-term debt: |  |  |  |  |  |  |  |  |  |
| Core debt | $ | 35,316 |  |  | $ | 829 |  |  | $ | 6,433 |  |  | $ | 11,102 |  |  | $ | 16,952 |  |
| DFS related debt | 7,765 |  |  | 4,154 |  |  | 3,516 |  |  | 95 |  |  | — |  |
| Margin Loan Facility and other | 4,024 |  |  | 12 |  |  | 4,005 |  |  | — |  |  | 7 |  |
| Debt of public subsidiary | 5,560 |  |  | 2,753 |  |  | 1,513 |  |  | 15 |  |  | 1,279 |  |
| Total principal payments on long-term debt | 52,665 |  |  | 7,747 |  |  | 15,467 |  |  | 11,212 |  |  | 18,239 |  |
| Interest | 13,821 |  |  | 1,997 |  |  | 3,234 |  |  | 2,143 |  |  | 6,447 |  |
| Purchase obligations | 4,352 |  |  | 3,900 |  |  | 385 |  |  | 64 |  |  | 3 |  |
| Operating leases | 2,139 |  |  | 458 |  |  | 672 |  |  | 332 |  |  | 677 |  |
| Tax obligations | 183 |  |  | 19 |  |  | 55 |  |  | 109 |  |  | — |  |
| Contractual cash obligations | $ | 73,160 |  |  | $ | 14,121 |  |  | $ | 19,813 |  |  | $ | 13,860 |  |  | $ | 25,366 |  |

[0001571996-20-000017:mdna:304]
Principal Payments on Long-Term Debt — Our expected principal cash payments on borrowings are exclusive of discounts and premiums.  We have outstanding long-term notes with varying maturities.  As of January 31, 2020, the future principal payments related to our DFS debt were expected to be $4.2 billion in Fiscal 2021, $3.5 billion in Fiscal 2022-2023, and $95 million in Fiscal 2024-2025.  For additional information about our debt, see Note 6 of the Notes to the Consolidated Financial Statements included in this report.

[0001571996-20-000017:mdna:305]
Interest — See Note 6 of the Notes to the Consolidated Financial Statements included in this report for further discussion of our debt and related interest expense.

[0001571996-20-000017:mdna:306]
Purchase Obligations — Purchase obligations are defined as contractual obligations to purchase goods or services that are enforceable and legally binding on us.  These obligations specify all significant terms, including fixed or minimum quantities to be purchased; fixed, minimum, or variable price provisions; and the approximate timing of the transaction.  Purchase obligations do not include contracts that may be canceled without penalty.

[0001571996-20-000017:mdna:307]
We utilize several suppliers to manufacture sub-assemblies for our products.  Our efficient supply chain management allows us to enter into flexible and mutually beneficial purchase arrangements with our suppliers in order to minimize inventory risk.  Consistent with industry practice, we acquire raw materials or other goods and services, including product components, by issuing to suppliers authorizations to purchase based on our projected demand and manufacturing needs.  These purchase orders are typically fulfilled within 30 days and are entered into during the ordinary course of business in order to establish best pricing and continuity of supply for our production.  Purchase orders are not included in purchase obligations, as they typically represent our authorization to purchase rather than binding purchase obligations.

[0001571996-20-000017:mdna:308]
Operating Leases — We lease property and equipment, manufacturing facilities, and office space under non-cancelable leases.  Certain of these leases obligate us to pay taxes, maintenance, and repair costs.  See Note 5 of the Notes to the Consolidated Financial Statements included in this report for additional information about our leasing transactions in which we are the lessee.

[0001571996-20-000017:mdna:309]
Tax Obligations — Tax obligations represent a one-time mandatory deemed repatriation tax on undistributed earnings of foreign subsidiaries, payable over eight years.  Excluded from the table above are $2.5 billion in additional liabilities associated with uncertain tax positions as of January 31, 2020.  We are unable to reliably estimate the expected payment dates for any liabilities for uncertain tax positions.  See Note 11 of the Notes to the Consolidated Financial Statements included in this report for more information on these tax matters.

[0001571996-20-000017:mdna:310]
76

[0001571996-20-000017:mdna:311]
Critical Accounting Policies

[0001571996-20-000017:mdna:312]
We prepare our financial statements in conformity with GAAP, which requires certain estimates, assumptions, and judgments to be made that may affect our Consolidated Statements of Financial Position and Consolidated Statements of Income (Loss).  Accounting policies that have a significant impact on our Consolidated Financial Statements are described in Note 2 of the Notes to the Consolidated Financial Statements included in this report.  The accounting estimates and assumptions discussed in this section are those that we consider to be the most critical.  We consider an accounting policy to be critical if the nature of the estimate or assumption is subject to a material level of judgment and if changes in those estimates or assumptions are reasonably likely to materially impact our Consolidated Financial Statements.  We have discussed the development, selection, and disclosure of our critical accounting policies with the Audit Committee of our board of directors.

[0001571996-20-000017:mdna:313]
Revenue Recognition — We sell a wide portfolio of products and services offerings to our customers.  Our agreements have varying requirements depending on the goods and services being sold, the rights and obligations conveyed, and the legal jurisdiction of the arrangement.

[0001571996-20-000017:mdna:314]
Revenue is recognized for these arrangements based on the following five steps:

[0001571996-20-000017:mdna:315]
| (1) | Identify the contract with a customer. The term “contract” refers to the enforceable rights and obligations provided in an agreement between us and the customer in exchange for payment. We evaluate facts and circumstances regarding sales transactions in order to identify contracts with our customers. An agreement must meet all of the following criteria to qualify as a contract eligible for revenue recognition under the model: (i) the contract must be approved by all parties who are committed to perform their respective obligations; (ii) each party’s rights regarding the goods and services to be transferred to the customer can be identified; (iii) the payment terms for the goods and services can be identified; (iv) the customer has the ability and intent to pay and it is probable that we will collect substantially all of the consideration to which it will be entitled; and (v) the contract must have commercial substance. Judgment is used in determining the customer’s ability and intent to pay, which is based upon various factors including the customer’s historical payment experience or customer credit and financial information. |

[0001571996-20-000017:mdna:316]
| (2) | Identify the performance obligations in the contract. Our contracts with customers often include the promise to transfer multiple goods and services to a customer. Distinct promises within a contract are referred to as “performance obligations” and are accounted for as separate units of account. We assess whether each promised good or service is distinct for the purpose of identifying the performance obligations in the contract. This assessment involves subjective determinations and requires management to make judgments about the individual promised goods or services and whether such goods or services are separable from the other aspects of the contractual relationship. Promised goods and services are considered distinct provided that: (i) the customer can benefit from the good or service either on its own or together with other resources that are readily available to the customer (that is, the good or service is capable of being distinct); and (ii) our promise to transfer the good or service to the customer is separately identifiable from other promises in the contract (that is, the promise to transfer the good or service is distinct within the context of the contract). Our performance obligations include various distinct goods and services such as hardware, software licenses, warranties, and other service offerings and solutions. Promised goods and services are explicitly identified in our contracts and may be sold on a standalone basis or bundled as part of a combined solution. In certain hardware solutions, the hardware is highly interdependent on, and interrelated with the embedded software. In these offerings, the hardware and software licenses are accounted for as a single performance obligation. |

[0001571996-20-000017:mdna:317]
| (3) | Determine the transaction price. The transaction price reflects the amount of consideration to which we expect to be entitled in exchange for transferring goods or services to the customer. If the consideration promised in a contract includes a variable amount, we estimate the amount to which we expect to be entitled using either the expected value or most likely amount method. Generally, volume discounts, rebates, and sales returns reduce the transaction price. When we determine the transaction price, we only include amounts that are not subject to significant future reversal. |

[0001571996-20-000017:mdna:318]
| (4) | Allocate the transaction price to performance obligations in the contract. When a contract includes multiple performance obligations, the transaction price is allocated to each performance obligation in an amount that depicts the consideration to which we expect to be entitled in exchange for transferring the promised goods or services. For contracts with multiple performance obligations, the transaction price is allocated in proportion to the standalone selling price (“SSP”) of each performance obligation. |

[0001571996-20-000017:mdna:319]
The best evidence of SSP is the observable price of a good or service when we sell that good or service separately in similar circumstances to similar customers.  If a directly observable price is available, we utilize that price for the SSP.  If a directly observable price is not available, the SSP must be estimated.  We estimate SSP by considering multiple factors, including, but not limited to, pricing practices, internal costs, and profit objectives as well as overall market conditions, which include geographic or regional specific factors, competitive positioning, and competitor actions.

[0001571996-20-000017:mdna:320]
| (5) | Recognize revenue when (or as) the performance obligation is satisfied. Revenue is recognized when obligations under the terms of the contract with our customer are satisfied. Revenue is recognized either over time or at a point in time, depending on when the underlying products or services are transferred to the customer. Revenue is recognized at a point in time for products upon transfer of control. Revenue is recognized over time for support and deployment services, software support, software-as-a-service (“SaaS”), and infrastructure-as-a-service (“IaaS”). Revenue is recognized either over time or at a point in time for professional services and training depending on the nature of the offering to the customer. |

[0001571996-20-000017:mdna:321]
We report revenue net of any revenue-based taxes assessed by governmental authorities that are imposed on and concurrently with specific revenue-producing transactions.

[0001571996-20-000017:mdna:322]
We elected the following practical expedients with the adoption of the new revenue standard:

[0001571996-20-000017:mdna:323]
| • | We do not account for significant financing components if the period between revenue recognition and when the customer pays for the product or service will be one year or less. |

[0001571996-20-000017:mdna:324]
| • | We recognize revenue equal to the amount we have a right to invoice when the amount corresponds directly with the value to the customer of our performance to date. |

[0001571996-20-000017:mdna:325]
| • | We do not account for shipping and handling activities as a separate performance obligation, but rather as an activity performed to transfer the promised good. |

[0001571996-20-000017:mdna:326]
The following summarizes the nature of revenue recognized and the manner in which we account for sales transactions.

[0001571996-20-000017:mdna:327]
Products

[0001571996-20-000017:mdna:328]
Product revenue consists of hardware and software license sales that are delivered, sold as a subscription, or sold on a consumption basis.  Hardware includes notebooks and desktop PCs, servers, storage hardware, and other hardware-related devices.  Software license sales include non-essential software applications.  Software applications provide customers with resource management, backup and archiving, information security, information management and intelligence, data analytics, and server virtualization capabilities.

[0001571996-20-000017:mdna:329]
Revenue from the sale of hardware products is recognized when control has transferred to the customer, which typically occurs when the hardware has been shipped to the customer, risk of loss has transferred to the customer, we have a present right to payment, and customer acceptance has been satisfied.  Customer acceptance is satisfied if acceptance is obtained from the customer, if all acceptance provisions lapse, or if we have evidence that all acceptance provisions will be, or have been, satisfied.  Revenue from software license sales is generally recognized when control has transferred to the customer, which is typically upon shipment, electronic delivery, or when the software is available for download by the customer.  For certain software arrangements in which the customer is granted a right to additional unspecified future software licenses, our promise to the customer is considered a stand-ready obligation in which the transfer of control, and revenue recognition, will be over time.  Invoices for products are generally issued as control transfers, which is typically upon shipment or delivery.  There was no significant revenue in any period presented related to performance obligations satisfied or partially satisfied in prior periods.

[0001571996-20-000017:mdna:330]
78

[0001571996-20-000017:mdna:331]
Services

[0001571996-20-000017:mdna:332]
Services revenue consists of revenue from sales of support services, including hardware support that extends beyond our standard warranties, software maintenance, and installation; professional services; training; SaaS; and IaaS.  Revenue associated with undelivered performance obligations is deferred and recognized when or as control is transferred to the customer.  Revenue from fixed-price support or maintenance contracts sold for both hardware and software is recognized on a straight-line basis over the period of performance because we are required to provide services at any given time.  Other services revenue is recognized when we perform the services and the customer receives and consumes the benefits.  Invoices for services may be issued at the start of a service term, which is typically the case for support and deployment services, or as services are rendered, which is typically the case for professional services, training, SaaS, and IaaS.

[0001571996-20-000017:mdna:333]
Other

[0001571996-20-000017:mdna:334]
Revenue from leasing arrangements is not subject to the revenue standard for contracts with customers and remains separately accounted for under existing lease accounting guidance.  The Company records operating lease rental revenue as product revenue on a straight-line basis over the lease term.  We record revenue from the sale of equipment under sales-type leases as product revenue in an amount equal to the present value of minimum lease payments at the inception of the lease.  Sales-type leases also produce financing income, which is included in net products revenue in the Consolidated Statements of Income (Loss) and is recognized at effective rates of return over the lease term.  We also offer qualified customers fixed-term loans and revolving credit lines for the purchase of our products and services.  Financing income attributable to these loans is recognized in product net revenue on an accrual basis.

[0001571996-20-000017:mdna:335]
Disaggregation of Revenue — Our revenue is presented on a disaggregated basis on the Consolidated Statements of Income (Loss) and in Note 19 of the Notes to the Consolidated Financial Statements based on an evaluation of disclosures outside of the financial statements, information regularly reviewed by the chief operating decision maker for evaluating the financial performance of operating segments, and other information that is used to evaluate our financial performance or make resource allocations.  This information includes revenue from products and services, revenue from reportable segments, and revenue by major product categories within the segments.

[0001571996-20-000017:mdna:336]
Contract Assets — Contract assets are rights to consideration in exchange for goods or services that we have transferred to a customer when such a right is conditional on something other than the passage of time.  Such amounts have been insignificant to date.

[0001571996-20-000017:mdna:337]
Contract Liabilities — Contract liabilities primarily consist of deferred revenue.  Deferred revenue is recorded when we have a right to invoice or payments have been received for undelivered products or services, or in situations where revenue recognition criteria have not been met.  Deferred revenue also represents amounts received in advance for extended warranty services and software maintenance.  Revenue is recognized on these items when the revenue recognition criteria are met, generally resulting in ratable recognition over the contract term.  We also have deferred revenue related to undelivered hardware and professional services, consisting of installations and consulting engagements, which are recognized when our performance obligations under the contract are completed.  See Note 9 of the Notes to the Consolidated Financial Statements included in this report for additional information about deferred revenue.

[0001571996-20-000017:mdna:338]
Costs to Obtain a Contract — The incremental direct costs of obtaining a contract primarily consist of sales commissions and employer taxes related to commission payments.  We elected, as a practical expedient, to expense as incurred costs to obtain a contract equal to or less than one year in duration.  For contracts greater than one year in duration, the associated costs to obtain a contract are deferred and amortized over the period of contract performance or a longer period, generally the estimated life of the customer relationship, if renewals are expected and the renewal commission is not commensurate with the initial commission.  Deferred costs to obtain a contract are typically amortized over a period of three to seven years, depending on the contract term and expectation of the period of benefit for the costs, which may exceed the contract term.  Amortization expense is recognized on a straight-line basis and included in selling, general, and administrative expenses in the Consolidated Statements of Income (Loss).  We periodically review these deferred costs to determine whether events or changes in circumstances have occurred that could impact the carrying value or period of benefit of the deferred sales commissions.

[0001571996-20-000017:mdna:339]
Deferred Revenue — Deferred revenue is recorded when we have a right to invoice or payments have been received for undelivered products or services in contracts where transfer of control has not occurred.  Deferred revenue represents amounts received in advance for support and deployment services, software maintenance, professional services, training, SaaS, and IaaS.  Revenue is recognized on these items when the revenue recognition criteria are met, generally resulting in ratable recognition over the contract term.  We also have deferred revenue related to undelivered hardware and professional services, consisting of installations and consulting engagements, which are recognized as our performance obligations under the contract are completed.

[0001571996-20-000017:mdna:340]
Business Combinations and Intangible Assets, Including Goodwill — We account for business combinations using the acquisition method of accounting, and, accordingly, the assets and liabilities of the acquired business are recorded at their fair values at the date of acquisition.  The excess of the purchase price over the estimated fair value is recorded as goodwill.  Any changes in the estimated fair values of the net assets recorded for acquisitions prior to the finalization of more detailed analysis, but not to exceed one year from the date of acquisition, will change the amount of the purchase price allocable to goodwill.  The cumulative impact of any subsequent changes to any purchase price allocations that are material to our consolidated financial results will be adjusted in the reporting period in which the adjustment amount is determined.  All acquisition costs are expensed as incurred.  Identifiable intangible assets with finite lives are amortized over their estimated useful lives.  In-process research and development costs are recorded at fair value as an indefinite-lived intangible asset and assessed for impairment thereafter until completion, at which point the asset is amortized over its expected useful life.  Separately recognized transactions associated with business combinations are generally expensed subsequent to the acquisition date.  The application of business combination and impairment accounting requires the use of significant estimates and assumptions.

[0001571996-20-000017:mdna:341]
The results of operations of acquired businesses are included in our Consolidated Financial Statements from the acquisition date.

[0001571996-20-000017:mdna:342]
Goodwill and indefinite-lived intangible assets are tested for impairment annually during the third fiscal quarter and whenever events or circumstances may indicate that an impairment has occurred.  To determine whether goodwill is impaired, we first assess certain qualitative factors.  Based on this assessment, if it is determined more likely than not that the fair value of a goodwill reporting unit is less than its carrying amount, we perform the quantitative analysis of the goodwill impairment test.  The fair value of each of our goodwill reporting units is generally estimated using a combination of public company multiples and discounted cash flow methodologies, and then compared to the carrying value of each goodwill reporting unit.

[0001571996-20-000017:mdna:343]
Income Taxes — We are subject to income tax in the United States and numerous foreign jurisdictions.  Significant judgments are required in determining the consolidated provision for income taxes.  We calculate a provision for income taxes using the asset and liability method, under which deferred tax assets and liabilities are recognized by identifying the temporary differences arising from the different treatment of items for tax and accounting purposes.  We account for the tax impact of including Global Intangible Low-Taxed Income (GILTI) in U.S. taxable income as a period cost.  We provide related valuation allowances for deferred tax assets, where appropriate.  Significant judgment is required in determining any valuation allowance against deferred tax assets.  In assessing the need for a valuation allowance, we consider all available evidence for each jurisdiction, including past operating results, estimates of future taxable income, and the feasibility of ongoing tax planning strategies.  In the event we determine that all or part of the net deferred tax assets are not realizable in the future, we will make an adjustment to the valuation allowance that would be charged to earnings in the period such determination is made.

[0001571996-20-000017:mdna:344]
Significant judgment is also required in evaluating our uncertain tax positions.  Although we believe our tax return positions are sustainable, we recognize tax benefits from uncertain tax positions in the financial statements only when it is more likely than not that the positions will be sustained upon examination, including resolution of any related appeals or litigation processes, based on the technical merits and a consideration of the relevant taxing authority’s administrative practices and precedents.  To the extent that the final tax outcome of these matters is different from the amounts recorded, such differences will impact the provision for income taxes in the period in which such determination is made.  The provision for income taxes includes the impact of reserve provisions and changes to reserves that are considered appropriate, as well as the related net interest and penalties.  We believe we have provided adequate reserves for all uncertain tax positions.

[0001571996-20-000017:mdna:345]
Loss Contingencies — We are subject to the possibility of various losses arising in the ordinary course of business.  We consider the likelihood of loss or impairment of an asset or the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss, in determining loss contingencies.  An estimated loss contingency is accrued when it is probable that an asset has been impaired or a liability has been incurred and the amount of loss can be reasonably estimated.  We regularly evaluate current information available to us to determine whether such accruals should be adjusted and whether new accruals are required.  Third parties have in the past asserted, and may in the future assert, claims or initiate litigation related to exclusive patent, copyright, and other intellectual property rights to technologies and related standards that are relevant to us.  If any infringement or other intellectual property claim made against us by any third party is successful, or if we fail to develop non-infringing technology or license the proprietary rights on commercially reasonable terms and conditions, our business, operating results, and financial condition could be materially and adversely affected.

[0001571996-20-000017:mdna:346]
Inventories — We state our inventory at the lower of cost or market.  We record a write-down for inventories of components and products, including third-party products held for resale, which have become obsolete or are in excess of anticipated demand or net realizable value.  We perform a detailed review of inventory each fiscal quarter that considers multiple factors, including demand forecasts, product life cycle status, product development plans, current sales levels, and component cost trends.  The industries in which we compete are subject to demand changes.  If future demand or market conditions for our products are less favorable than forecasted or if unforeseen technological changes negatively impact the utility of component inventory, we may be required to record additional write-downs, which would adversely affect our gross margin.

[0001571996-20-000017:mdna:347]
Recently Issued Accounting Pronouncements

[0001571996-20-000017:mdna:348]
See Note 2 of the Notes to the Consolidated Financial Statements included in this report for a summary of recently issued accounting pronouncements that are applicable to our Consolidated Financial Statements.

[0001571996-20-000017:mdna:349]
81
