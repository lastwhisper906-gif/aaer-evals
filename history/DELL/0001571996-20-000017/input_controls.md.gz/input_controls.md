# DELL 10-K controls and the auditor's report


## auditors_report

[0001571996-20-000017:auditors_report:1]
Report of Independent Registered Public Accounting Firm

[0001571996-20-000017:auditors_report:2]
To the Board of Directors and Stockholders of Dell Technologies Inc.

[0001571996-20-000017:auditors_report:3]
Opinions on the Financial Statements and Internal Control over Financial Reporting

[0001571996-20-000017:auditors_report:4]
We have audited the accompanying consolidated statements of financial position of Dell Technologies Inc. and its subsidiaries (the “Company”) as of January 31, 2020 and February 1, 2019, and the related consolidated statements of income (loss), of comprehensive income (loss), of stockholders' equity (deficit) and of cash flows for each of the three years in the period ended January 31, 2020, including the related notes (collectively referred to as the “consolidated financial statements”). We also have audited the Company's internal control over financial reporting as of January 31, 2020, based on criteria established in Internal Control - Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (COSO).

[0001571996-20-000017:auditors_report:5]
In our opinion, the consolidated financial statements referred to above present fairly, in all material respects, the financial position of the Company as of January 31, 2020 and February 1, 2019, and the results of its operations and its cash flows for each of the three years in the period ended January 31, 2020 in conformity with accounting principles generally accepted in the United States of America. Also in our opinion, the Company maintained, in all material respects, effective internal control over financial reporting as of January 31, 2020, based on criteria established in Internal Control - Integrated Framework (2013) issued by the COSO.

[0001571996-20-000017:auditors_report:6]
Change in Accounting Principle

[0001571996-20-000017:auditors_report:7]
As discussed in Note 2 to the consolidated financial statements, the Company changed the manner in which it accounts for leases as of February 2, 2019.

[0001571996-20-000017:auditors_report:8]
Basis for Opinions

[0001571996-20-000017:auditors_report:9]
The Company's management is responsible for these consolidated financial statements, for maintaining effective internal control over financial reporting, and for its assessment of the effectiveness of internal control over financial reporting, included in Management’s Annual Report on Internal Control Over Financial Reporting appearing under Item 9A. Our responsibility is to express opinions on the Company’s consolidated financial statements and on the Company's internal control over financial reporting based on our audits. We are a public accounting firm registered with the Public Company Accounting Oversight Board (United States) (PCAOB) and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0001571996-20-000017:auditors_report:10]
We conducted our audits in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audits to obtain reasonable assurance about whether the consolidated financial statements are free of material misstatement, whether due to error or fraud, and whether effective internal control over financial reporting was maintained in all material respects.

[0001571996-20-000017:auditors_report:11]
Our audits of the consolidated financial statements included performing procedures to assess the risks of material misstatement of the consolidated financial statements, whether due to error or fraud, and performing procedures that respond to those risks. Such procedures included examining, on a test basis, evidence regarding the amounts and disclosures in the consolidated financial statements. Our audits also included evaluating the accounting principles used and significant estimates made by management, as well as evaluating the overall presentation of the consolidated financial statements. Our audit of internal control over financial reporting included obtaining an understanding of internal control over financial reporting, assessing the risk that a material weakness exists, and testing and evaluating the design and operating effectiveness of internal control based on the assessed risk. Our audits also included performing such other procedures as we considered necessary in the circumstances. We believe that our audits provide a reasonable basis for our opinions.

[0001571996-20-000017:auditors_report:12]
Definition and Limitations of Internal Control over Financial Reporting

[0001571996-20-000017:auditors_report:13]
A company’s internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. A company’s internal control over financial reporting includes those policies and procedures that (i) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the company; (ii) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the company are being made only in accordance with authorizations of management and directors of the company; and (iii) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the company’s assets that could have a material effect on the financial statements.

[0001571996-20-000017:auditors_report:14]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0001571996-20-000017:auditors_report:15]
Critical Audit Matters

[0001571996-20-000017:auditors_report:16]
The critical audit matters communicated below are matters arising from the current period audit of the consolidated financial statements that were communicated or required to be communicated to the audit committee and that (i) relate to accounts or disclosures that are material to the consolidated financial statements and (ii) involved our especially challenging, subjective, or complex judgments. The communication of critical audit matters does not alter in any way our opinion on the consolidated financial statements, taken as a whole, and we are not, by communicating the critical audit matters below, providing separate opinions on the critical audit matters or on the accounts or disclosures to which they relate.

[0001571996-20-000017:auditors_report:17]
Revenue Recognition - Identification of Performance Obligations in Revenue Contracts

[0001571996-20-000017:auditors_report:18]
As described in Notes 2 and 19 to the consolidated financial statements, the Company’s contracts with customers often include the promise to transfer multiple goods and services to a customer. Distinct promises within a contract are referred to as performance obligations and are accounted for as separate units of account. Management assesses whether each promised good or service is distinct for the purpose of identifying the performance obligations in the contract. This assessment involves subjective determinations and requires management to make judgments about the individual promised goods or services and whether such goods or services are separable from the other aspects of the contractual relationship. The Company’s performance obligations include various distinct goods and services such as hardware, software licenses, warranties, and other service offerings and solutions. For the year ended January 31, 2020, a significant portion of the $34 billion Infrastructure Solutions Group (“ISG”) and $10.9 billion VMware reportable segment net revenues relate to contracts with multiple performance obligations.

[0001571996-20-000017:auditors_report:19]
The principal considerations for our determination that performing procedures relating to the identification of performance obligations in revenue contracts is a critical audit matter are there was significant judgment by management in identifying performance obligations in revenue contracts, which in turn led to a high degree of auditor judgment, subjectivity and effort in performing procedures to evaluate whether performance obligations in revenue contracts were appropriately identified by management.

[0001571996-20-000017:auditors_report:20]
Addressing the matter involved performing procedures and evaluating audit evidence in connection with forming our overall opinion on the consolidated financial statements. These procedures included testing the effectiveness of controls relating to the revenue recognition process, including controls related to the proper identification of performance obligations in revenue contracts. These procedures also included, among others, testing the completeness and accuracy of management’s identification of performance obligations by examining revenue contracts on a test basis.

[0001571996-20-000017:auditors_report:21]
Goodwill and Indefinite-lived Trade Names Impairment Assessments

[0001571996-20-000017:auditors_report:22]
As described in Note 8 to the consolidated financial statements, the Company’s consolidated goodwill and indefinite-lived trade names balances were $41.7 billion and $3.8 billion as of January 31, 2020, respectively. The goodwill associated with the Infrastructure Solutions Group (“ISG”) and RSA Security (“RSA”) goodwill reporting units represent a portion of the total goodwill balance. Goodwill and indefinite-lived intangible assets are tested for impairment annually during the third fiscal quarter and whenever events or circumstances may indicate that an impairment has occurred. Management performs a quantitative goodwill impairment test to measure the fair value of each goodwill reporting unit relative to its carrying amount, and to determine the amount of goodwill impairment loss to be recognized, if any. The fair value of the goodwill reporting units are generally estimated using a combination of public company multiples and discounted cash flow methodologies which require significant judgment, including estimation of future cash flows, which is dependent on internal forecasts, current and anticipated economic conditions and trends, selection of market multiples through assessment of the reporting unit’s performance relative to peer competitors, the estimation of the long-term revenue growth rate and discount rate of the Company’s business, and the determination of the Company’s weighted average cost of capital. The fair value of the indefinite-lived trade names is generally estimated using discounted cash flow methodologies.  The discounted cash flow methodology requires significant judgment, including estimation of future revenue, which is dependent on internal forecasts, the estimation of the long-term revenue growth rate of the Company’s business and the determination of the Company’s weighted average cost of capital and royalty rates.

[0001571996-20-000017:auditors_report:23]
The principal considerations for our determination that performing procedures relating to goodwill and indefinite-lived trade names impairment assessments is a critical audit matter are that there was significant judgment by management when developing the fair value measurements of the ISG and RSA reporting units and certain of the indefinite-lived trade names, which in turn led to a high degree of auditor judgment, subjectivity and effort in performing procedures and evaluating audit evidence related to management’s selection of market multiples and cash flow projections, including significant assumptions related to long-term revenue growth rates and the discount rate. In addition, the audit effort involved the use of professionals with specialized skill and knowledge to assist in evaluating the audit evidence obtained from these procedures.

[0001571996-20-000017:auditors_report:24]
Addressing the matter involved performing procedures and evaluating audit evidence in connection with forming our overall opinion on the consolidated financial statements. These procedures included testing the effectiveness of controls relating to management’s goodwill and indefinite-lived trade names impairment assessments, including controls over the fair value of the ISG and RSA reporting units and indefinite-lived trade names. These procedures also included, among others, testing management’s process for developing the fair value estimates, evaluating the appropriateness of the public company multiples and discounted cash flow methodologies, testing completeness and accuracy of underlying data used in the methodologies, and evaluating the reasonableness of management’s selection of market multiples, and significant assumptions used by management in estimating the fair value of the ISG and RSA reporting units and certain of the indefinite-lived trade names, including the long-term revenue growth rates and the discount rate. Evaluating the assumptions related to the long-term revenue growth rates involved evaluating whether assumptions used by management were reasonable considering the past performance of each reporting unit and certain of the indefinite-lived trade names, consistency with third-party industry data, and whether the assumptions were consistent with evidence obtained in other areas of the audit. Professionals with specialized skill and knowledge were used to assist in the evaluation of the Company’s discounted future cash flow methodologies and certain assumptions, including the discount rate.

[0001571996-20-000017:auditors_report:25]
Intra-entity Transfer of Intellectual Property Rights

[0001571996-20-000017:auditors_report:26]
As described in Note 11 to the consolidated financial statements, the Company completed two intra-entity asset transfers of certain of its intellectual property (the “IP”) to Irish subsidiaries, resulting in discrete tax benefits of $4.9 billion. The tax benefit for each intra-entity asset transfer was recorded as a deferred tax asset in the period of transaction and represents the book and tax basis difference on the transferred assets measured based on the IP’s current fair value and applicable Irish statutory tax rate. The Company applied significant judgment when determining the fair value of the IP, which serves as the tax basis of the deferred tax asset, and in evaluating the associated tax laws in the applicable jurisdictions.

[0001571996-20-000017:auditors_report:27]
The principal considerations for our determination that performing procedures relating to the intra-entity transfers of the intellectual property rights is a critical audit matter are (i) there was significant judgment by management when determining the fair value of certain of the intellectual property subject to the intra-entity asset transfers which serves as the tax basis of the deferred tax asset and in evaluating the associated application of tax laws in the applicable jurisdictions, which in turn led to a high degree of auditor judgment, subjectivity and effort in applying procedures relating to the reasonableness of management’s determination of the fair value of certain of the intellectual property subject to the intra-entity asset transfers which serves as the tax basis of the deferred tax asset and in evaluating the associated application of tax laws in the applicable jurisdiction and (ii) the audit effort also involved the use of professionals with specialized skill and knowledge to assist in evaluating the audit evidence obtained from these procedures.

[0001571996-20-000017:auditors_report:28]
Addressing the matter involved performing procedures and evaluating audit evidence in connection with forming our overall opinion on the consolidated financial statements. These procedures included testing the effectiveness of controls relating to the accounting for certain of the intra-entity transfers of the intellectual property, including controls over management’s review of the underlying agreements, determination of the tax basis, and management's assessment of the tax laws applicable to the transfer of a license for intellectual property. These procedures also included, among others, (i) examination of the underlying agreements, (ii) testing the information used in the calculation of the deferred tax asset, including management’s estimate of the fair value of certain of the intellectual property which serves as the tax basis for the deferred tax asset and evaluating the tax laws applicable to the transfer of the intellectual property, and (iii) testing the calculation of the deferred tax asset. Professionals with specialized skill and knowledge were used to assist in the evaluation of management’s determination of the fair value of the intellectual property which serves as the tax basis for the deferred tax asset and applicability of the Irish income tax laws and regulations.

[0001571996-20-000017:auditors_report:29]
/s/ PricewaterhouseCoopers LLP

[0001571996-20-000017:auditors_report:30]
Austin, Texas

[0001571996-20-000017:auditors_report:31]
March 27, 2020

[0001571996-20-000017:auditors_report:32]
We have served as the Company’s auditor since 1986.

[0001571996-20-000017:auditors_report:33]
DELL TECHNOLOGIES INC.

[0001571996-20-000017:auditors_report:34]
CONSOLIDATED STATEMENTS OF FINANCIAL POSITION

[0001571996-20-000017:auditors_report:35]
(in millions)

[0001571996-20-000017:auditors_report:36]
|  | January 31, 2020 |  | February 1, 2019 |
| ASSETS |
| Current assets: |  |  |  |  |  |
| Cash and cash equivalents | $ | 9,302 |  |  | $ | 9,676 |  |
| Accounts receivable, net | 12,484 |  |  | 12,371 |  |
| Short-term financing receivables, net | 4,895 |  |  | 4,398 |  |
| Inventories, net | 3,281 |  |  | 3,649 |  |
| Other current assets | 6,906 |  |  | 6,044 |  |
| Total current assets | 36,868 |  |  | 36,138 |  |
| Property, plant, and equipment, net | 6,055 |  |  | 5,259 |  |
| Long-term investments | 864 |  |  | 1,005 |  |
| Long-term financing receivables, net | 4,848 |  |  | 4,224 |  |
| Goodwill | 41,691 |  |  | 40,089 |  |
| Intangible assets, net | 18,107 |  |  | 22,270 |  |
| Other non-current assets | 10,428 |  |  | 2,835 |  |
| Total assets | $ | 118,861 |  |  | $ | 111,820 |  |
| LIABILITIES, REDEEMABLE SHARES, AND STOCKHOLDERS’ EQUITY (DEFICIT) |
| Current liabilities: |  |  |  |  |  |
| Short-term debt | $ | 7,737 |  |  | $ | 4,320 |  |
| Accounts payable | 20,065 |  |  | 19,213 |  |
| Accrued and other | 9,773 |  |  | 8,495 |  |
| Short-term deferred revenue | 14,881 |  |  | 12,944 |  |
| Total current liabilities | 52,456 |  |  | 44,972 |  |
| Long-term debt | 44,319 |  |  | 49,201 |  |
| Long-term deferred revenue | 12,919 |  |  | 11,066 |  |
| Other non-current liabilities | 5,383 |  |  | 6,327 |  |
| Total liabilities | 115,077 |  |  | 111,566 |  |
| Commitments and contingencies (Note 10) |  |  |  |  |  |
| Redeemable shares (Note 17) | 629 |  |  | 1,196 |  |
| Stockholders’ equity (deficit): |  |  |  |
| Common stock and capital in excess of $0.01 par value (Note 14) | 16,091 |  |  | 16,114 |  |
| Treasury stock at cost | (65 | ) |  | (63 | ) |
| Accumulated deficit | (16,891 | ) |  | (21,349 | ) |
| Accumulated other comprehensive loss | (709 | ) |  | (467 | ) |
| Total Dell Technologies Inc. stockholders’ deficit | (1,574 | ) |  | (5,765 | ) |
| Non-controlling interests | 4,729 |  |  | 4,823 |  |
| Total stockholders’ equity (deficit) | 3,155 |  |  | (942 | ) |
| Total liabilities, redeemable shares, and stockholders’ equity (deficit) | $ | 118,861 |  |  | $ | 111,820 |  |

[0001571996-20-000017:auditors_report:37]
The accompanying notes are an integral part of these Consolidated Financial Statements.

[0001571996-20-000017:auditors_report:38]
89

[0001571996-20-000017:auditors_report:39]
DELL TECHNOLOGIES INC.


## item_9a

[0001571996-20-000017:item_9a:1]
ITEM 9A — CONTROLS AND PROCEDURES

[0001571996-20-000017:item_9a:2]
This report includes the certifications of our Chief Executive Officer and Chief Financial Officer required by Rule 13a-14 under the Securities Exchange Act of 1934 (the “Exchange Act”).  See Exhibits 31.1 and 31.2 filed with this report.  This Item 9A includes information concerning the controls and control evaluations referred to in those certifications.

[0001571996-20-000017:item_9a:3]
Evaluation of Disclosure Controls and Procedures

[0001571996-20-000017:item_9a:4]
Disclosure controls and procedures (as defined in Rules 13a-15(e) and 15d-15(e) under the Exchange Act) are designed to provide reasonable assurance that information required to be disclosed in reports filed or submitted under the Exchange Act is recorded, processed, summarized, and reported within the time periods specified in SEC rules and forms and that such information is accumulated and communicated to management, including the Chief Executive Officer and the Chief Financial Officer, as appropriate to allow timely decisions regarding required disclosures.

[0001571996-20-000017:item_9a:5]
In connection with the preparation of this report, our management, under the supervision and with the participation of our Chief Executive Officer and Chief Financial Officer, conducted an evaluation of the effectiveness of the design and operation of our disclosure controls and procedures as of January 31, 2020.  Based on that evaluation, our Chief Executive Officer and Chief Financial Officer have concluded that our disclosure controls and procedures were effective at the reasonable assurance level as of January 31, 2020.

[0001571996-20-000017:item_9a:6]
Management’s Annual Report on Internal Control Over Financial Reporting

[0001571996-20-000017:item_9a:7]
Management, under the supervision of the Chief Executive Officer and the Chief Financial Officer, is responsible for establishing and maintaining adequate internal control over financial reporting.  Internal control over financial reporting (as defined in Rules 13a-15(f) and 15d(f) under the Exchange Act) is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles.  Internal control over financial reporting includes those policies and procedures which (a) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of assets, (b) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, (c) provide reasonable assurance that receipts and expenditures are being made only in accordance with appropriate authorization of management and the board of directors, and (d) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of assets that could have a material effect on the financial statements.

[0001571996-20-000017:item_9a:8]
In connection with the preparation of this report, our management, under the supervision and with the participation of our Chief Executive Officer and Chief Financial Officer, conducted an evaluation of the effectiveness of our internal control over financial reporting as of January 31, 2020, based on the criteria established in Internal Control — Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission.  As a result of that evaluation, management has concluded that our internal control over financial reporting was effective as of January 31, 2020.

[0001571996-20-000017:item_9a:9]
The effectiveness of our internal control over financial reporting as of January 31, 2020 has been audited by PricewaterhouseCoopers LLP, our independent registered public accounting firm, as stated in their report, which is included in “Item 8 — Financial Statements and Supplementary Data.”

[0001571996-20-000017:item_9a:10]
184

[0001571996-20-000017:item_9a:11]
Changes in Internal Control Over Financial Reporting

[0001571996-20-000017:item_9a:12]
There were no changes in our internal control over financial reporting during the fiscal quarter ended January 31, 2020 that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.  During the first quarter of the fiscal year ended January 31, 2020, we implemented new lease reporting systems and related controls to enable us to adopt the new accounting guidance set forth in ASC 842, “Leases.”  Given the significance of these changes, we will continue to review and refine the systems, processes, and internal controls over leases, as appropriate.

[0001571996-20-000017:item_9a:13]
Limitations on the Effectiveness of Controls

[0001571996-20-000017:item_9a:14]
Our system of controls is designed to provide reasonable, not absolute, assurance regarding the reliability and integrity of accounting and financial reporting.  Management does not expect that our disclosure controls and procedures or our internal control over financial reporting will prevent or detect all errors and all fraud.  A control system, no matter how well designed and operated, can provide only reasonable, not absolute, assurance that the objectives of the control system will be met.  These inherent limitations include the following:

[0001571996-20-000017:item_9a:15]
| • | Judgments in decision-making can be faulty, and control and process breakdowns can occur because of simple errors or mistakes. |

[0001571996-20-000017:item_9a:16]
| • | Controls can be circumvented by individuals, acting alone or in collusion with each other, or by management override. |

[0001571996-20-000017:item_9a:17]
| • | The design of any system of controls is based in part on certain assumptions about the likelihood of future events, and there can be no assurance that any design will succeed in achieving its stated goals under all potential future conditions. |

[0001571996-20-000017:item_9a:18]
| • | Over time, controls may become inadequate because of changes in conditions or deterioration in the degree of compliance with associated policies or procedures. |

[0001571996-20-000017:item_9a:19]
| • | The design of a control system must reflect the fact that resources are constrained, and the benefits of controls must be considered relative to their costs. |

[0001571996-20-000017:item_9a:20]
185
