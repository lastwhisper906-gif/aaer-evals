# DELL 10-Q controls and the auditor's report


## item_4_controls

[0001571996-17-000020:item_4_controls:1]
ITEM 4 — CONTROLS AND PROCEDURES

[0001571996-17-000020:item_4_controls:2]
This report includes the certifications of our Chief Executive Officer and Chief Financial Officer required by Rule 13a-14 under the Securities Exchange Act of 1934 (the "Exchange Act").  See Exhibits 31.1 and 31.2 filed with this report.  This Item 4 includes information concerning the controls and control evaluations referred to in those certifications.

[0001571996-17-000020:item_4_controls:3]
Evaluation of Disclosure Controls and Procedures

[0001571996-17-000020:item_4_controls:4]
Disclosure controls and procedures (as defined in Rules 13a-15(e) and 15d-15(e) under the Exchange Act) are designed to ensure that information required to be disclosed in reports filed or submitted under the Exchange Act is recorded, processed, summarized, and reported within the time periods specified in SEC rules and forms and that such information is accumulated and communicated to management, including the chief executive officer and the chief financial officer, to allow timely decisions regarding required disclosures.

[0001571996-17-000020:item_4_controls:5]
In connection with the preparation of this report, our management, under the supervision and with the participation of our Chief Executive Officer and Chief Financial Officer, conducted an evaluation of the effectiveness of the design and operation of our disclosure controls and procedures as of August 4, 2017.  Based on that evaluation, our management has concluded that our disclosure controls and procedures were effective as of August 4, 2017.

[0001571996-17-000020:item_4_controls:6]
Changes in Internal Control over Financial Reporting

[0001571996-17-000020:item_4_controls:7]
On September 7, 2016, we completed our acquisition by merger of EMC Corporation as described elsewhere in this report.  We continue to integrate policies, processes, people, technology, and operations relating to this transaction, and will continue to evaluate the impact of any related changes to our internal control over financial reporting.  Except for any changes related to the integration of EMC, there were no changes in our internal control over financial reporting during the fiscal quarter ended August 4, 2017 that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.
