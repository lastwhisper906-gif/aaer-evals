# DELL note change history — 0001571996-17-000009 → 0001571996-17-000020


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2017-09-08):
[0001571996-17-000020:note_history:1]
Appraisal Proceedings — On October 29, 2013, Dell Technologies acquired Dell in a transaction referred to as the going-private transaction.  Holders of shares of Dell common stock who did not vote on September 12, 2013 in favor of the proposal to adopt the amended going-private transaction agreement and who properly demanded appraisal of their shares and who otherwise comply with the requirements of Section 262 of the Delaware General Corporate Law ("DGCL") are entitled to seek appraisal for, and obtain payment in cash for the judicially determined "fair value" (as defined pursuant to Section 262 of the DGCL) of, their shares in lieu of receiving the going-private transaction consideration.  Dell initially recorded a liability of $13.75 for each share with respect to which appraisal has been demanded and as to which the demand has not been withdrawn, together with interest at the statutory rate discussed below.  This liability was approximately $129 million as of both August 4, 2017 and February 3, 2017.  The Court of Chancery ruled that the fair value of the appraisal shares as of October 29, 2013, the date on which the going-private transaction became effective, was $17.62 per share.  This ruling would entitle the holders of the remaining 5,505,730 shares subject to the appraisal proceedings to $17.62 per share, plus interest at a statutory rate, compounded quarterly.  On November 21, 2016, the Court of Chancery entered final judgment in the appraisal action.  On November 22, 2016, Dell filed a notice of appeal to the Delaware Supreme Court, and a hearing is scheduled on that appeal for September 27, 2017.  The Company believes it was adequately reserved for the appraisal proceedings as of August 4, 2017.
  (was, 2017-06-09, similarity 0.8965):
[0001571996-17-000009:note_history:1]
Appraisal Proceedings — Holders of shares of Dell common stock who did not vote on September 12, 2013 in favor of the proposal to adopt the amended going-private transaction agreement and who properly demanded appraisal of their shares and who otherwise comply with the requirements of Section 262 of the Delaware General Corporate Law ("DGCL") are entitled to seek appraisal for, and obtain payment in cash for the judicially determined "fair value" (as defined pursuant to Section 262 of the DGCL) of, their shares in lieu of receiving the going-private transaction consideration.  Dell initially recorded a liability of $13.75 for each share with respect to which appraisal has been demanded and as to which the demand has not been withdrawn, together with interest at the statutory rate discussed below.  As of May 5, 2017 and February 3, 2017, this liability was approximately $129 million.  The Court of Chancery ruled that the fair value of the appraisal shares as of October 29, 2013, the date on which the going-private transaction became effective, was $17.62 per share.  This ruling would entitle the holders of the remaining 5,505,730 shares subject to the appraisal proceedings to $17.62 per share, plus interest at a statutory rate, compounded quarterly.  On November 21, 2016, the Court of Chancery entered final judgment in the appraisal action.  On November 22, 2016, Dell filed a notice of appeal to the Delaware Supreme Court.  That appeal is pending.  The Company believes it was adequately reserved for the appraisal proceedings as of May 5, 2017.

- changed (2017-09-08):
[0001571996-17-000020:note_history:2]
Copyright Levies — The Company's obligation to collect and remit copyright levies in certain European Union ("EU") countries may be affected by the resolution of legal proceedings pending in Germany and other EU member states against various companies, including Dell subsidiaries.  The plaintiffs in those proceedings generally seek to impose or modify the levies with respect to sales of such equipment as multifunction devices, phones, personal computers, storage devices, and printers, alleging that such products enable the copying of copyrighted materials.  Some of the proceedings also challenge whether the levy schemes in those countries comply with EU law.  Certain EU member countries that do not yet impose levies on digital devices are expected to implement legislation to enable them to extend existing levy schemes, while some other EU member countries are expected to limit the scope of levy schemes and their applicability in the digital hardware environment.  Dell, other companies, and various industry associations have opposed the extension of levies to the digital environment and have advocated alternative models of compensation to rights holders.  The Company continues to collect levies in certain EU countries where it has determined that based on local laws it is probable that it has a payment obligation.  The amount of levies is generally based on the number of products sold and the per-product amounts of the levies, which vary.  The Company accrues a liability when it believes that it is both probable that a loss has been incurred and when it can reasonably estimate the amount of the loss.
  (was, 2017-06-09, similarity 0.9452):
[0001571996-17-000009:note_history:2]
Copyright Levies — The Company's obligation to collect and remit copyright levies in certain European Union ("EU") countries may be affected by the resolution of legal proceedings pending in Germany against various companies, including Dell's German subsidiary, and elsewhere in the EU against other companies in Dell's industry.  The plaintiffs in those proceedings, some of which are described below, generally seek to impose or modify the levies with respect to sales of such equipment as multifunction devices, phones, personal computers, and printers, alleging that such products enable the copying of copyrighted materials.  Some of the proceedings also challenge whether the levy schemes in those countries comply with EU law.  Certain EU member countries that do not yet impose levies on digital devices are expected to implement legislation to enable them to extend existing levy schemes, while some other EU member countries are expected to limit the scope of levy schemes and their applicability in the digital hardware environment.  Dell, other companies, and various industry associations have opposed the extension of levies to the digital environment and have advocated alternative models of compensation to rights holders.  The Company continues to collect levies in certain EU countries where it has determined that based on local laws it is probable that it has a payment obligation.  The amount of levies is generally based on the number of products sold and the per-product amounts of the levies, which vary.  The Company accrues a liability when it believes that it is both probable that a loss has been incurred and when it can reasonably estimate the amount of the loss.

- added (2017-09-08):
[0001571996-17-000020:note_history:3]
As of August 4, 2017, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for these or other proceedings or matters has been incurred.  However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company's business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters.  Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company's business, financial condition, results of operations, or cash flows will depend on a number of variables, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.

- changed (2017-09-08):
[0001571996-17-000020:note_history:4]
The Company has contractual obligations to purchase goods or services, which specify significant terms, including fixed or minimum quantities to be purchased; fixed, minimum, or variable price provisions; and the approximate timing of the transaction.  As of August 4, 2017, the Company had $2,724 million, $267 million, and $448 million in purchase obligations for Fiscal 2018 (remaining six months), Fiscal 2019, and Fiscal 2020 and thereafter, respectively.
  (was, 2017-06-09, similarity 0.9254):
[0001571996-17-000009:note_history:4]
The Company has contractual obligations to purchase goods or services, which specify significant terms, including fixed or minimum quantities to be purchased; fixed, minimum, or variable price provisions; and the approximate timing of the transaction.  As of May 5, 2017, the Company had $2,674 million, $260 million, and $432 million in purchase obligations for Fiscal 2018, Fiscal 2019, and Fiscal 2020 and thereafter, respectively.

- removed (2017-09-08):
[0001571996-17-000009:note_history:5]
On December 29, 2005, Zentralstelle für private Überspielungsrechte ("ZPÜ"), a joint association of various German collecting societies, instituted arbitration proceedings against Dell's German subsidiary before the Board of Arbitration at the German Patent and Trademark Office in Munich, and subsequently filed a lawsuit in the German Regional Court in Munich on February 21, 2008, seeking levies to be paid on each personal computer sold by Dell in Germany through the end of calendar year 2007.  On December 23, 2009, ZPÜ and the German industry association, BCH, reached a settlement regarding audio-video copyright levy litigation (with levies ranging from €3.15 to €13.65 per unit).  Dell joined this settlement on February 23, 2010, and has paid the amounts due under the settlement.  On March 25, 2014, ZPÜ and Dell reached a settlement for levies to be paid on each personal computer sold for the period of January 2, 2011 through December 31, 2016.  The amount of the settlement is not material to the Company.  The amount of any levies payable after calendar year 2016, as well as the Company's ability to recover such amounts through increased prices, remains uncertain.

- removed (2017-09-08):
[0001571996-17-000009:note_history:6]
German courts are also considering a lawsuit originally filed in July 2004 by VG Wort, a German collecting society representing certain copyright holders, against Hewlett-Packard Company in the Stuttgart Civil Court seeking levies on printers, and a lawsuit originally filed in September 2003 by the same plaintiff against Fujitsu Siemens Computer GmbH in Munich Civil Court in Munich, Germany seeking levies on personal computers.  In each case, the civil and appellate courts held that the subject classes of equipment were subject to levies.  In July 2011, the German Federal Supreme Court, to which the lower court holdings have been appealed, referred each case to the Court of Justice of the European Union, submitting a number of legal questions on the interpretation of the European Copyright Directive which the German Federal Supreme Court deems necessary for its decision.  In August 2014, the German Supreme Court delivered an opinion ruling that printers and personal computers are subject to levies, and referred the case back to the Court of Appeals.  Dell joined the industry settlement in the Fujitsu Siemens case, and Dell believes it has no remaining material obligations in either case.

- removed (2017-09-08):
[0001571996-17-000009:note_history:7]
Proceedings seeking to impose or modify copyright levies for sales of digital devices also have been instituted in courts in other EU member states.  Even in countries where Dell is not a party to such proceedings, decisions in those cases could impact Dell's business and the amount of copyright levies Dell may be required to collect.

- removed (2017-09-08):
[0001571996-17-000009:note_history:8]
The ultimate resolution of these proceedings and the associated financial impact to the Company, if any, including the number of units potentially affected, the amount of levies imposed, and the ability of the Company to recover such amounts, remain uncertain at this time.  Should the courts determine there is liability for previous units shipped beyond the amount of levies the Company has collected or accrued, the Company would be liable for such incremental amounts.  Recovery of any such amounts from others by the Company would be possible only on future collections related to future shipments.

- removed (2017-09-08):
[0001571996-17-000009:note_history:9]
As of May 5, 2017, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for these or other proceedings or matters has been incurred.  However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company's business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters.  Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company's business, financial condition, results of operations, or cash flows will depend on a number of variables, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2017-09-08):
[0001571996-17-000020:note_history:10]
Basis of Presentation — The accompanying unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes filed with the U.S. Securities and Exchange Commission ("SEC") in the Company's Annual Report on Form 10-K for the fiscal year ended February 3, 2017.  These Condensed Consolidated Financial Statements have been prepared in accordance with accounting principles generally accepted in the United States of America ("GAAP").  In the opinion of management, the accompanying Condensed Consolidated Financial Statements reflect all adjustments of a normal recurring nature considered necessary to fairly state the financial position of Dell Technologies Inc. (individually and together with its consolidated subsidiaries, the "Company" or "Dell Technologies") as of August 4, 2017 and February 3, 2017, the results of its operations and corresponding comprehensive income (loss) for the three and six months ended August 4, 2017 and July 29, 2016, as well as its cash flows for the six months ended August 4, 2017 and July 29, 2016.

- added (2017-09-08):
[0001571996-17-000020:note_history:11]
The preparation of financial statements in accordance with GAAP requires management to make estimates and assumptions that affect the amounts reported in the Condensed Consolidated Financial Statements and the accompanying Notes.  Actual results could differ materially from those estimates.  The results of operations and comprehensive income (loss) for the three and six months ended August 4, 2017 and July 29, 2016 and cash flows for the six months ended August 4, 2017 and July 29, 2016 are not necessarily indicative of the results to be expected for the full fiscal year or for any other fiscal period.

- added (2017-09-08):
[0001571996-17-000020:note_history:12]
As a result of the EMC merger transaction completed on September 7, 2016, the Company's results of operations, comprehensive income (loss), and cash flows for the fiscal periods reflected in these Condensed Consolidated Financial Statements are not directly comparable.  The results of the businesses acquired in the EMC merger transaction are included in the consolidated results of Dell Technologies for the three and six months ended August 4, 2017, but are not included in the consolidated results of Dell Technologies for the three and six months ended July 29, 2016.  The Dell Technologies unaudited Condensed Consolidated Statements of Financial Position reflect the full consolidation of EMC's assets and liabilities as of both August 4, 2017 and February 3, 2017.

- changed (2017-09-08):
[0001571996-17-000020:note_history:13]
Unless the context indicates otherwise, references in these Notes to the Condensed Consolidated Financial Statements to "VMware" mean the VMware reportable segment, which reflects the operations of VMware, Inc. (NYSE: VMW) within Dell Technologies.  See Exhibit 99.1 filed with the Company's quarterly report on Form 10-Q for the quarterly period ended August 4, 2017 for information on the differences between VMware reportable segment results and VMware, Inc. results.
  (was, 2017-06-09, similarity 0.7639):
[0001571996-17-000009:note_history:13]
Unless the context indicates otherwise, references in these Notes to the Condensed Consolidated Financial Statements to "VMware" mean the VMware reportable segment, which reflects the operations of VMware, Inc. (NYSE: VMW) within Dell Technologies.  See Exhibit 99.1 filed with the Company's quarterly report on Form 10-Q for the quarterly period ended May 5, 2017 for information on the differences between VMware reportable segment results and VMware, Inc. results.

- added (2017-09-08):
[0001571996-17-000020:note_history:14]
Reclassifications — The amounts presented for the three and six months ended July 29, 2016 are different from those previously reported on Form 10-Q for the quarterly period ended July 29, 2016 because the Company reclassified an immaterial amount of net income from discontinued operations to continuing operations to reflect the updated terms of the applicable divestitures referred to above as the result of continued negotiations and finalization of terms of the sale.

- changed (2017-09-08):
[0001571996-17-000020:note_history:15]
In August 2015, the FASB approved a one-year deferral of the effective date of this standard.  Public entities are required to adopt the new standard for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017.  The new revenue standard may be applied retrospectively to each prior period presented (full retrospective method) or retrospectively with the cumulative effect of initially applying the standard recognized at the date of initial application in retained earnings (modified retrospective method).  The Company currently expects to adopt this standard retrospectively to each prior period presented for the fiscal year beginning February 3, 2018.
  (was, 2017-06-09, similarity 0.9948):
[0001571996-17-000009:note_history:15]
In August 2015, the FASB approved a one-year deferral of the effective date of this standard.  Public entities are required to adopt the new standard for fiscal years, and interim periods within those years, beginning after December 15, 2017.  The new revenue standard may be applied retrospectively to each prior period presented (full retrospective method) or retrospectively with the cumulative effect of initially applying the standard recognized at the date of initial application in retained earnings (modified retrospective method).  The Company currently expects to adopt this standard retrospectively to each prior period presented for the fiscal year beginning February 3, 2018.

- changed (2017-09-08):
[0001571996-17-000020:note_history:16]
While the Company is currently evaluating the financial and system impacts that the new standard will have on the Consolidated Financial Statements, the Company expects that unearned license revenue related to the sale of software licenses and related deliverables will decline upon adoption.  Currently, the Company defers revenue for certain software arrangements due to the absence of vendor specific objective evidence ("VSOE") of fair value for all or a portion of the deliverables.  Under the new standard, the Company will no longer be required to establish VSOE of fair value in order to account for elements in an arrangement as separate units of accounting, and will be able to record revenue upon satisfaction of each performance obligation.  Additionally, the Company expects the new standard to have an impact on the way the transaction price is allocated for certain non-standard warranties.  The new standard is expected to result in more of the aggregate transaction price related to the non-standard warranty being recorded as revenue upon delivery of the underlying product, because the Company will no longer defer revenue based on the separately stated price of the non-standard warranty provided under the contract.  The Company continues to make progress in assessing the impacts of the standard on the Consolidated Financial Statements and will continue to evaluate the impact of any changes to the standard or interpretations should they become available.
  (was, 2017-06-09, similarity 0.9926):
[0001571996-17-000009:note_history:16]
While the Company is currently evaluating the financial and system impacts that the new standard will have on the Condensed Consolidated Financial Statements, the Company expects that unearned license revenue related to the sale of software licenses and related deliverables will decline upon adoption.  Currently, the Company defers revenue for certain software arrangements due to the absence of vendor specific objective evidence ("VSOE") of fair value for all or a portion of the deliverables.  Under the new standard, the Company will no longer be required to establish VSOE of fair value in order to account for elements in an arrangement as separate units of accounting, and will be able to record revenue upon satisfaction of each performance obligation.  Additionally, the Company expects the new standard to have an impact in the way the transaction price is allocated for certain non-standard warranties.  The new standard is expected to result in more of the aggregate transaction price related to the non-standard warranty being recorded as revenue upon delivery of the underlying product, because the Company will no longer defer revenue based on the separately stated price of the non-standard warranty provided under the contract.  The Company continues to make progress in assessing the impacts of the standard on the Condensed Consolidated Financial Statements and will continue to evaluate the impact of any changes to the standard or interpretations should they become available.

- added (2017-09-08):
[0001571996-17-000020:note_history:17]
Recognition and Measurement of Financial Assets and Financial Liabilities — In January 2016, the FASB issued amended guidance that addresses certain aspects of recognition, measurement, presentation, and disclosure of financial instruments.  Public entities must adopt the new guidance for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017.  The amended guidance requires changes in the fair value of equity investments to be recognized through net income, rather than other comprehensive income.  Adoption of the standard will be applied through a cumulative one-time adjustment to retained earnings.  For the Company’s equity investments without readily determinable fair values, the Company expects to elect the measurement alternative to record those investments at cost, less impairment, and adjusted by observable price changes on a prospective basis.  The impact of the standard on the Consolidated Statements of Income (Loss) will depend on the relative changes in market price of the equity investments, although the impact is currently expected to be immaterial.

- changed (2017-09-08):
[0001571996-17-000020:note_history:18]
Leases — In February 2016, the FASB issued amended guidance on the accounting for leasing transactions.  The primary objective of this update is to increase transparency and comparability among organizations by recognizing lease assets and lease liabilities on the balance sheet and disclosing key information about leasing arrangements.  Public entities must adopt the new guidance for reporting periods beginning after December 15, 2018, with early adoption permitted.  Companies are required to use a modified retrospective approach for leases that exist or are entered into after the beginning of the earliest comparative period in the financial statements.  The Company is currently evaluating the impact that the standard will have on the Consolidated Financial Statements.
  (was, 2017-06-09, similarity 0.9935):
[0001571996-17-000009:note_history:18]
Leases — In February 2016, the FASB issued amended guidance on the accounting for leasing transactions.  The primary objective of this update is to increase transparency and comparability among organizations by recognizing lease assets and lease liabilities on the balance sheet and disclosing key information about leasing arrangements.  Public entities must adopt the new guidance for reporting periods beginning after December 15, 2018, with early adoption permitted.  Companies are required to use a modified retrospective approach for leases that exist or are entered into after the beginning of the earliest comparative period in the financial statements.  The Company is currently evaluating the impact that the standard will have on the Condensed Consolidated Financial Statements.

- changed (2017-09-08):
[0001571996-17-000020:note_history:19]
Measurement of Credit Losses on Financial Instruments — In June 2016, the FASB issued amended guidance which replaces the current incurred loss impairment methodology for measurement of credit losses on financial instruments with a methodology that reflects expected credit losses and requires consideration of a broader range of reasonable and supportable information to inform credit loss estimates.  Public entities must adopt the new guidance for fiscal years beginning after December 15, 2019, and interim periods within those fiscal years, with early adoption permitted for fiscal periods beginning after December 15, 2018.  The Company is currently evaluating the impact that the standard will have on the Consolidated Financial Statements.
  (was, 2017-06-09, similarity 0.782):
[0001571996-17-000009:note_history:19]
Measurement of Credit Losses on Financial Instruments — In June 2016, the FASB issued amended guidance which replaces the current incurred loss impairment methodology with a methodology that reflects expected credit losses and requires consideration of a broader range of reasonable and supportable information to inform credit loss estimates.  Public entities must adopt the new guidance for fiscal years beginning after December 15, 2019, including interim periods within those fiscal years.  All entities may adopt the amendments in the new standard as of fiscal years beginning after December 15, 2018, including interim periods within those fiscal years.  Earlier adoption is not permitted.  The Company is currently evaluating the impact that the standard will have on the Condensed Consolidated Financial Statements.

- changed (2017-09-08):
[0001571996-17-000020:note_history:20]
Classification of Certain Cash Receipts and Cash Payments — In August 2016, the FASB issued amended guidance on the presentation and classification of eight specific cash flow issues with the objective of reducing existing diversity in practice.  Public entities must adopt the new guidance for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017, with early adoption permitted.  Companies should reflect any adjustments on a retrospective basis, if practicable; otherwise, adoption is required to be applied as of the earliest date practicable.  The Company will adopt this standard during the fiscal quarter ending May 4, 2018, and will apply adjustments retrospectively to each prior period presented on the Condensed Consolidated Statements of Cash Flows for that period.  The Company is currently evaluating the impact of the standard, and other than certain reclassifications on the Consolidated Statements of Cash Flows, it is not expected to have a material impact on the Consolidated Financial Statements.
  (was, 2017-06-09, similarity 0.6761):
[0001571996-17-000009:note_history:20]
Classification of Certain Cash Receipts and Cash Payments — In August 2016, the FASB issued amended guidance on the presentation and classification of eight specific cash flow issues with the objective of reducing existing diversity in practice.  Public entities must adopt the new guidance for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017, with early adoption permitted.  Companies should reflect any adjustments on a retrospective basis, if practicable; otherwise, adoption is required to be applied as of the earliest date practicable.  The Company is currently evaluating the timing of adoption as well as the impact that the standard will have on the Condensed Consolidated Financial Statements.

- changed (2017-09-08):
[0001571996-17-000020:note_history:21]
Simplifying the Test for Goodwill Impairment — In January 2017, the FASB issued amended guidance to simplify the subsequent measurement of goodwill by removing Step 2 of the goodwill impairment test.  Instead, under the amendments in the new guidance, an entity should perform its annual, or interim, goodwill impairment test by comparing the fair value of a reporting unit with its carrying amount.  An entity should recognize an impairment charge for the amount by which the carrying amount exceeds the reporting unit's fair value.  Public entities must adopt the new guidance in fiscal years beginning after December 15, 2019, with early adoption permitted.  The Company is currently evaluating the impact of the new guidance, but does not expect that the standard will have an impact on its Consolidated Financial Statements.
  (was, 2017-06-09, similarity 0.9802):
[0001571996-17-000009:note_history:21]
Simplifying the Test for Goodwill Impairment — In January 2017, the FASB issued amended guidance to simplify the subsequent measurement of goodwill by removing Step 2 of the goodwill impairment test.  Instead, under the amendments in the new guidance, an entity should perform its annual, or interim, goodwill impairment test by comparing the fair value of a reporting unit with its carrying amount.  An entity should recognize an impairment charge for the amount by which the carrying amount exceeds the reporting unit's fair value.  Public entities must adopt the new guidance in fiscal years beginning after December 15, 2019, with early adoption permitted.  The Company is currently evaluating the impact of the new guidance and timing of adoption, but does not expect that the standard will have an impact on its Condensed Consolidated Financial Statements.

- added (2017-09-08):
[0001571996-17-000020:note_history:22]
Derivatives and Hedging — In August 2017, the FASB issued amended guidance that will make more financial and non-financial hedging strategies eligible for hedge accounting.  The amended guidance changes how companies assess effectiveness, and also amends the presentation and disclosure requirements.  The guidance is intended to simplify the application of hedge accounting and increase transparency as to the scope and results of hedging programs.  Immediate early adoption is permitted in any interim or annual period.  The mandatory effective date for calendar year-end public companies is January 1, 2019.  The Company is currently evaluating the impact that the new guidance will have on the Consolidated Financial Statements.

- added (2017-09-08):
[0001571996-17-000020:note_history:23]
Recently Adopted Accounting Pronouncements

- changed (2017-09-08):
[0001571996-17-000020:note_history:24]
Improvements to Employee Share-Based Payment Accounting — In March 2016, the FASB issued amended guidance on the accounting for employee share-based payments, including the accounting for income taxes and forfeitures, classification of awards as either equity or liabilities, and classification of cash flows.  The Company adopted this guidance at the beginning of Fiscal 2018.  In accordance with the new guidance, excess tax benefits or deficiencies for stock-based compensation are now reflected as a component of the provision for income taxes on the Consolidated Statements of Income (Loss), whereas they were previously recorded as additional paid-in capital.  The Company has elected to continue to estimate expected forfeitures.  Additionally, the Company now presents excess tax benefits as an operating activity rather than a financing activity on the Consolidated Statements of Cash Flows, while the cash flows related to employee taxes paid for withheld shares are presented as a financing activity with prior periods adjusted accordingly.  The adoption of the amended guidance did not have a material impact on the Consolidated Financial Statements.  The prospective impact of the new standard will depend on the Company's stock price at the vesting or exercise dates of the awards and the number of awards that vest or are exercised in each period, but the Company does not expect the impact to be material in future periods.
  (was, 2017-06-09, similarity 0.9618):
[0001571996-17-000009:note_history:24]
Improvements to Employee Share-Based Payment Accounting — In March 2016, the FASB issued amended guidance on the accounting for employee share-based payments, including the accounting for income taxes and forfeitures, classification of awards as either equity or liabilities, and classification of cash flows.  The Company adopted this guidance during the three months ended May 5, 2017.  In accordance with the new guidance, excess tax benefits or deficiencies for stock-based compensation are now reflected as a component of the provision for income taxes on the Condensed Consolidated Statements of Income (Loss), whereas they were previously recorded as additional paid-in capital.  The Company has elected to continue to estimate expected forfeitures.  Additionally, the Company now presents excess tax benefits as an operating activity rather than a financing activity on the Condensed Consolidated Statements of Cash Flows, while the cash flows related to employee taxes paid for withheld shares are presented as a financing activity with prior periods adjusted accordingly.  The adoption of the amended guidance did not have a material impact on the Condensed Consolidated Financial Statements.  The prospective impact of the new standard will depend on the Company's stock price at the vesting or exercise dates of the awards and the number of awards that vest or are exercised in each period, but we do not expect the impact to be material in future periods.

- changed (2017-09-08):
[0001571996-17-000020:note_history:25]
Intra-Entity Transfers of Assets Other Than Inventory — In October 2016, the FASB issued amended guidance on the accounting for income taxes.  The new guidance requires companies to recognize the income tax effects of intra-entity asset transfers, other than transfers of inventory, when the transfer occurs instead of when the asset is sold to a third party.  The new guidance should be applied on a modified-retrospective basis with the cumulative-effect adjustment to retained earnings as of the beginning of the period of adoption.  The Company early adopted this guidance at the beginning of Fiscal 2018.  At adoption, approximately $84 million was reclassified from other non-current liabilities to retained earnings, resulting in a net credit to retained earnings.
  (was, 2017-06-09, similarity 0.96):
[0001571996-17-000009:note_history:25]
Intra-Entity Transfers of Assets Other Than Inventory — In October 2016, the FASB issued amended guidance on the accounting for income taxes.  The new guidance requires companies to recognize the income tax effects of intra-entity asset transfers, other than transfers of inventory, when the transfer occurs instead of when the asset is sold to a third party.  The new guidance should be applied on a modified-retrospective basis with the cumulative-effect adjustment to retained earnings as of the beginning of the period of adoption.  The Company early adopted this guidance during the three months ended May 5, 2017.  At adoption, approximately $84 million was reclassified from other non-current liabilities to retained earnings, resulting in a net credit to retained earnings.

- removed (2017-09-08):
[0001571996-17-000009:note_history:26]
Basis of Presentation — The accompanying Unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes filed with the U.S. Securities and Exchange Commission ("SEC") in the Company's Annual Report on Form 10-K for the fiscal year ended February 3, 2017 ("Fiscal 2017").  These Condensed Consolidated Financial Statements have been prepared in accordance with accounting principles generally accepted in the United States of America ("GAAP").  In the opinion of management, the accompanying Condensed Consolidated Financial Statements reflect all adjustments of a normal recurring nature considered necessary to fairly state the financial position of Dell Technologies Inc. (individually and together with its consolidated subsidiaries, the "Company" or "Dell Technologies") as of May 5, 2017 and February 3, 2017, the results of its operations and corresponding comprehensive income (loss), as well as its cash flows, for the three months ended May 5, 2017 and April 29, 2016.

- removed (2017-09-08):
[0001571996-17-000009:note_history:27]
The preparation of financial statements in accordance with GAAP requires management to make estimates and assumptions that

- removed (2017-09-08):
[0001571996-17-000009:note_history:28]
affect the amounts reported in the Condensed Consolidated Financial Statements and the accompanying Notes.  Actual results could differ materially from those estimates.  The results of operations, comprehensive income (loss), and cash flows for the three months ended May 5, 2017 and April 29, 2016 are not necessarily indicative of the results to be expected for the full fiscal year or for any other fiscal period.

- removed (2017-09-08):
[0001571996-17-000009:note_history:29]
As a result of the EMC merger transaction completed on September 7, 2016, the Company's results for the fiscal periods reflected in these Condensed Consolidated Financial Statements are not directly comparable.  The results of the businesses acquired in the EMC merger transaction are included in the consolidated results of Dell Technologies for the three months ended May 5, 2017.  The Dell Technologies balance sheet reflects the full consolidation of EMC's assets and liabilities as a result of the closing of the EMC merger transaction on September 7, 2016.

- removed (2017-09-08):
[0001571996-17-000009:note_history:30]
Recognition and Measurement of Financial Assets and Financial Liabilities — In January 2016, the FASB issued amended guidance on Recognition and Measurement of Financial Assets and Financial Liabilities.  The standard addresses certain aspects of recognition, measurement, presentation, and disclosure of financial instruments.  Public entities must adopt the new guidance for fiscal years, and interim periods within those years, beginning after December 15, 2017.  The Company does not expect that the standard will have a material impact on the Condensed Consolidated Financial Statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-09-08):
[0001571996-17-000020:note_history:31]
|  | August 4, 2017 |  | February 3, 2017 |
|  | (in millions) |
| Secured Debt |  |  |  |
| Structured financing debt | $ | 4,050 |  |  | $ | 3,464 |  |
| Senior Secured Credit Facilities: |  |  |  |
| 3.74% Term Loan B Facility due September 2023 | 5,460 |  |  | 4,987 |  |
| 3.24% Term Loan A-1 Facility due December 2018 | 69 |  |  | 600 |  |
| 3.49% Term Loan A-2 Facility due September 2021 | 3,778 |  |  | 3,876 |  |
| 3.24% Term Loan A-3 Facility due December 2018 | 1,800 |  |  | 1,800 |  |
| 2.78% Revolving Credit Facility due September 2021 | — |  |  | 375 |  |
| First Lien Notes: |  |  |  |
| 3.48% due June 2019 | 3,750 |  |  | 3,750 |  |
| 4.42% due June 2021 | 4,500 |  |  | 4,500 |  |
| 5.45% due June 2023 | 3,750 |  |  | 3,750 |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 8.10% due June 2036 | 1,500 |  |  | 1,500 |  |
| 8.35% due June 2046 | 2,000 |  |  | 2,000 |  |
| Unsecured Debt |  |  |  |
| Unsecured Notes and Debentures: |  |  |  |
| 5.65% due April 2018 | 500 |  |  | 500 |  |
| 5.875% due June 2019 | 600 |  |  | 600 |  |
| 4.625% due April 2021 | 400 |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 265 |  |  | 265 |  |
| Senior Notes: |  |  |  |
| 5.875% due June 2021 | 1,625 |  |  | 1,625 |  |
| 7.125% due June 2024 | 1,625 |  |  | 1,625 |  |
| EMC Notes: |  |  |  |
| 1.875% due June 2018 | 2,500 |  |  | 2,500 |  |
| 2.650% due June 2020 | 2,000 |  |  | 2,000 |  |
| 3.375% due June 2023 | 1,000 |  |  | 1,000 |  |
| Other |  |  |  |
| 3.56% Margin Loan Facility due April 2022 | 2,000 |  |  | — |  |
| 2.53% Margin Bridge Facility due September 2017 | — |  |  | 2,500 |  |
| 2.99% VMware Note Bridge Facility due September 2017 | 1,500 |  |  | 1,500 |  |
| Other | 86 |  |  | 51 |  |
| Total debt, principal amount | $ | 49,946 |  |  | $ | 50,356 |  |
| Unamortized discount, net of unamortized premium | (281 | ) |  | (284 | ) |
| Debt issuance costs | (605 | ) |  | (682 | ) |
| Total debt, carrying value | $ | 49,060 |  |  | $ | 49,390 |  |
| Total short-term debt, carrying value | $ | 7,686 |  |  | $ | 6,329 |  |
| Total long-term debt, carrying value | $ | 41,374 |  |  | $ | 43,061 |  |
  (was, 2017-06-09, similarity 0.7649):
[0001571996-17-000009:note_history:31]
|  | May 5, 2017 |  | February 3, 2017 |
|  | (in millions) |
| Secured Debt |  |  |  |
| Structured financing debt | $ | 3,869 |  |  | $ | 3,464 |  |
| Senior Secured Credit Facilities: |  |  |  |
| 3.50% Term Loan B Facility due September 2023 | 5,473 |  |  | 4,987 |  |
| 3.00% Term Loan A-1 Facility due December 2018 | 599 |  |  | 600 |  |
| 3.25% Term Loan A-2 Facility due September 2021 | 3,827 |  |  | 3,876 |  |
| 3.00% Term Loan A-3 Facility due December 2018 | 1,800 |  |  | 1,800 |  |
| 3.00% Revolving Credit Facility due September 2021 | 375 |  |  | 375 |  |
| First Lien Notes: |  |  |  |
| 3.48% due June 2019 | 3,750 |  |  | 3,750 |  |
| 4.42% due June 2021 | 4,500 |  |  | 4,500 |  |
| 5.45% due June 2023 | 3,750 |  |  | 3,750 |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 8.10% due June 2036 | 1,500 |  |  | 1,500 |  |
| 8.35% due June 2046 | 2,000 |  |  | 2,000 |  |
| Unsecured Debt |  |  |  |
| Unsecured Notes and Debentures: |  |  |  |
| 5.65% due April 2018 | 500 |  |  | 500 |  |
| 5.875% due June 2019 | 600 |  |  | 600 |  |
| 4.625% due April 2021 | 400 |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 265 |  |  | 265 |  |
| Senior Notes: |  |  |  |
| 5.875% due June 2021 | 1,625 |  |  | 1,625 |  |
| 7.125% due June 2024 | 1,625 |  |  | 1,625 |  |
| EMC Notes: |  |  |  |
| 1.875% due June 2018 | 2,500 |  |  | 2,500 |  |
| 2.650% due June 2020 | 2,000 |  |  | 2,000 |  |
| 3.375% due June 2023 | 1,000 |  |  | 1,000 |  |
| Other |  |  |  |
| 3.42% Margin Loan Facility due April 2022 | 2,000 |  |  | — |  |
| 2.53% Margin Bridge Facility due September 2017 | — |  |  | 2,500 |  |
| 2.75% VMware Note Bridge Facility due September 2017 | 1,500 |  |  | 1,500 |  |
| Other | 82 |  |  | 51 |  |
| Total debt, principal amount | $ | 50,728 |  |  | $ | 50,356 |  |
| Unamortized discount, net of unamortized premium | (293 | ) |  | (284 | ) |
| Debt issuance costs | (645 | ) |  | (682 | ) |
| Total debt, carrying value | $ | 49,790 |  |  | $ | 49,390 |  |
| Total short-term debt, carrying value | $ | 4,842 |  |  | $ | 6,329 |  |
| Total long-term debt, carrying value | $ | 44,948 |  |  | $ | 43,061 |  |

- changed (2017-09-08):
[0001571996-17-000020:note_history:32]
During the three months ended May 5, 2017, the Company refinanced the Term Loan B Facility to reduce the interest rate margin by 0.75% and to increase the outstanding principal amount by $500 million.  The Company applied the proceeds from the Term Loan B Facility refinancing to repay $500 million principal amount of the Margin Bridge Facility, without premium or penalty, and accrued and unpaid interest thereon.  Additionally, during the three months ended May 5, 2017, the Company issued the Margin Loan Facility in the principal amount of $2.0 billion, and used the proceeds of the new facility to repay the Margin Bridge Facility, without premium or penalty.  Further, during the six months ended August 4, 2017, the Company repaid approximately $0.6 billion principal amount of its term loan facilities, repaid $0.4 billion, net, under the Revolving Credit Facility, and issued an additional $0.6 billion, net, in structured financing debt to support the expansion of its financing receivables portfolio.
  (was, 2017-06-09, similarity 0.785):
[0001571996-17-000009:note_history:32]
During the three months ended May 5, 2017, the Company refinanced the Term Loan B Facility to reduce the interest rate margin by 0.75% and to increase the outstanding principal amount by $500 million.  The Company applied the proceeds from the Term Loan B Facility refinancing to repay $500 million principal amount of the Margin Bridge Facility, without premium or penalty, and accrued and unpaid interest thereon.  Additionally, during the three months ended May 5, 2017, the Company issued the Margin Loan Facility in the principal amount of $2.0 billion, and used the proceeds of the new facility to extinguish the Margin Bridge Facility, without premium or penalty.

- changed (2017-09-08):
[0001571996-17-000020:note_history:33]
Senior Secured Credit Facilities — At the closing of the EMC merger transaction on September 7, 2016, the Company entered into a credit agreement that provides for senior secured credit facilities (the "Senior Secured Credit Facilities") in the aggregate principal amount of $17.6 billion comprising (a) term loan facilities and (b) a senior secured Revolving Credit Facility, which includes capacity for up to $0.5 billion of letters of credit and for borrowings of up to $0.4 billion under swing-line loans.  As of August 4, 2017, available borrowings under the Revolving Credit Facility totaled $3.1 billion.  The Senior Secured Credit Facilities provide that the borrowers have the right at any time, subject to customary conditions, to request incremental term loans or incremental revolving commitments.
  (was, 2017-06-09, similarity 0.9943):
[0001571996-17-000009:note_history:33]
Senior Secured Credit Facilities — At the closing of the EMC merger transaction on September 7, 2016, the Company entered into a credit agreement that provides for senior secured credit facilities (the "Senior Secured Credit Facilities") in the aggregate principal amount of $17.6 billion comprising (a) term loan facilities and (b) a senior secured Revolving Credit Facility, which includes capacity for up to $0.5 billion of letters of credit and for borrowings of up to $0.4 billion under swing-line loans.  As of May 5, 2017, available borrowings under the Revolving Credit Facility totaled $2.7 billion.  The Senior Secured Credit Facilities provide that the borrowers have the right at any time, subject to customary conditions, to request incremental term loans or incremental revolving commitments.

- changed (2017-09-08):
[0001571996-17-000020:note_history:34]
Margin Loan Facility — During the three months ended May 5, 2017, the Company issued the Margin Loan Facility in an aggregate principal amount of $2.0 billion.  VMW Holdco LLC, a wholly-owned subsidiary of EMC, is the borrower under the Margin Loan Facility, which is secured by 60 million shares of Class B common stock of VMware, Inc. and 20 million shares of Class A common stock of VMware, Inc.  Loans under the Margin Loan Facility bear interest at a rate per annum payable, at the borrower's option, either at (a) a base rate plus 1.25% per annum or (b) a LIBOR-based rate plus 2.25% per annum.  Interest under the Margin Loan Facility is payable quarterly.
  (was, 2017-06-09, similarity 0.9984):
[0001571996-17-000009:note_history:34]
Margin Loan Facility — During the three months ended May 5, 2017, the Company issued the Margin Loan Facility in an aggregate principal amount of $2.0 billion.  VMW Holdco LLC, a wholly owned subsidiary of EMC, is the borrower under the Margin Loan Facility, which is secured by 60 million shares of Class B common stock of VMware, Inc. and 20 million shares of Class A common stock of VMware, Inc.  Loans under the Margin Loan Facility bear interest at a rate per annum payable, at the borrower's option, either at (a) a base rate plus 1.25% per annum or (b) a LIBOR-based rate plus 2.25% per annum.  Interest under the Margin Loan Facility is payable quarterly.

- changed (2017-09-08):
[0001571996-17-000020:note_history:35]
During the three months ended May 5, 2017, the Company separately applied the proceeds from the Term Loan B Facility refinancing and the issuance of the Margin Loan Facility to repay the Margin Bridge Facility, without premium or penalty.
  (was, 2017-06-09, similarity 0.9682):
[0001571996-17-000009:note_history:35]
During the three months ended May 5, 2017, the Company separately applied the proceeds from the Term Loan B Facility refinancing and the issuance of the Margin Loan Facility to extinguish the Margin Bridge Facility, without premium or penalty.

- changed (2017-09-08):
[0001571996-17-000020:note_history:36]
The VMware Note Bridge Facility has no amortization.  The borrower is required to prepay outstanding borrowings under the VMware Note Bridge Facility with 100% of the net cash proceeds of any asset sale or other disposition of the pledged VMware, Inc. promissory notes.  The borrower may voluntarily repay outstanding loans under the VMware Note Bridge Facility at any time without premium or penalty, other than customary "breakage" costs, subject to certain minimum threshold amounts for prepayment.  For more information regarding the VMware Note Bridge Facility see Note 21 of the Notes to the Condensed Consolidated Financial Statements.
  (was, 2017-06-09, similarity 0.8773):
[0001571996-17-000009:note_history:36]
The VMware Note Bridge Facility has no amortization.  The borrower is required to prepay outstanding borrowings under the VMware Note Bridge Facility with 100% of the net cash proceeds of any asset sale or other disposition of the pledged VMware, Inc. promissory notes.  The borrower may voluntarily repay outstanding loans under the VMware Note Bridge Facility at any time without premium or penalty, other than customary "breakage" costs, subject to certain minimum threshold amounts for prepayment.

- changed (2017-09-08):
[0001571996-17-000020:note_history:37]
Structured Financing Debt — As of August 4, 2017 and February 3, 2017, the Company had $4.1 billion and $3.5 billion, respectively, in outstanding structured financing debt, which was primarily related to the fixed-term lease and loan securitization programs and the revolving loan securitization programs.  See Note 6 and Note 8 of the Notes to the Condensed Consolidated Financial Statements for further discussion of the structured financing debt and the interest rate swap agreements that hedge a portion of that debt.
  (was, 2017-06-09, similarity 0.9911):
[0001571996-17-000009:note_history:37]
Structured Financing Debt — As of May 5, 2017 and February 3, 2017, the Company had $3.9 billion and $3.5 billion, respectively, in outstanding structured financing debt, which was primarily related to the fixed-term lease and loan securitization programs and the revolving loan securitization programs.  See Note 6 and Note 8 of the Notes to the Condensed Consolidated Financial Statements for further discussion of the structured financing debt and the interest rate swap agreements that hedge a portion of that debt.

- changed (2017-09-08):
[0001571996-17-000020:note_history:38]
Unsecured Notes and Debentures — The Company has unsecured notes and debentures (collectively, the "Unsecured Notes and Debentures") that were issued prior to the acquisition of Dell by Dell Technologies Inc.  Interest on these borrowings is payable semiannually.
  (was, 2017-06-09, similarity 0.9962):
[0001571996-17-000009:note_history:38]
Unsecured Notes and Debentures — The Company has unsecured notes and debentures (collectively, the "Unsecured Notes and Dentures") that were issued prior to the acquisition of Dell by Dell Technologies Inc.  Interest on these borrowings is payable semiannually.

- changed (2017-09-08):
[0001571996-17-000020:note_history:39]
Aggregate Future Maturities — As of August 4, 2017, aggregate future maturities of the Company's debt were as follows:
  (was, 2017-06-09, similarity 0.9686):
[0001571996-17-000009:note_history:39]
Aggregate Future Maturities — As of May 5, 2017, aggregate future maturities of the Company's debt were as follows:

- changed (2017-09-08):
[0001571996-17-000020:note_history:40]
|  | Maturities by Fiscal Year |
|  | 2018 (remaining six months) |  | 2019 |  | 2020 |  | 2021 |  | 2022 |  | Thereafter |  | Total |
|  | (in millions) |
| Structured Financing Debt | $ | 1,653 |  |  | $ | 1,827 |  |  | $ | 422 |  |  | $ | 117 |  |  | $ | 30 |  |  | $ | 1 |  |  | $ | 4,050 |  |
| Senior Secured Credit Facilities and First Lien Notes | 125 |  |  | 2,169 |  |  | 4,198 |  |  | 336 |  |  | 7,302 |  |  | 16,977 |  |  | 31,107 |  |
| Unsecured Notes and Debentures | — |  |  | 500 |  |  | 600 |  |  | — |  |  | 400 |  |  | 953 |  |  | 2,453 |  |
| Senior Notes and EMC Notes | — |  |  | 2,500 |  |  | — |  |  | 2,000 |  |  | 1,625 |  |  | 2,625 |  |  | 8,750 |  |
| Margin Loan Facility | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 2,000 |  |  | 2,000 |  |
| Bridge Facility | 1,500 |  |  | — |  |  | — |  |  | — |  |  | — |  |  |  |  |  | 1,500 |  |
| Other | 18 |  |  | 10 |  |  | 5 |  |  | 27 |  |  | — |  |  | 26 |  |  | 86 |  |
| Total maturities, principal amount | 3,296 |  |  | 7,006 |  |  | 5,225 |  |  | 2,480 |  |  | 9,357 |  |  | 22,582 |  |  | 49,946 |  |
| Associated carrying value adjustments | (3 | ) |  | (29 | ) |  | (45 | ) |  | (1 | ) |  | (217 | ) |  | (591 | ) |  | (886 | ) |
| Total maturities, carrying value amount | $ | 3,293 |  |  | $ | 6,977 |  |  | $ | 5,180 |  |  | $ | 2,479 |  |  | $ | 9,140 |  |  | $ | 21,991 |  |  | $ | 49,060 |  |
  (was, 2017-06-09, similarity 0.9949):
[0001571996-17-000009:note_history:40]
|  | Maturities by Fiscal Year |
|  | 2018 (remaining nine months) |  | 2019 |  | 2020 |  | 2021 |  | 2022 |  | Thereafter |  | Total |
|  | (in millions) |
| Structured Financing Debt | $ | 2,039 |  |  | $ | 1,291 |  |  | $ | 406 |  |  | $ | 107 |  |  | $ | 26 |  |  | $ | — |  |  | $ | 3,869 |  |
| Senior Secured Credit Facilities and First Lien Notes | 188 |  |  | 2,699 |  |  | 4,197 |  |  | 336 |  |  | 7,677 |  |  | 16,977 |  |  | 32,074 |  |
| Unsecured Notes and Debentures | — |  |  | 500 |  |  | 600 |  |  | — |  |  | 400 |  |  | 953 |  |  | 2,453 |  |
| Senior Notes and EMC Notes | — |  |  | 2,500 |  |  | — |  |  | 2,000 |  |  | 1,625 |  |  | 2,625 |  |  | 8,750 |  |
| Margin Loan Facility | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 2,000 |  |  | 2,000 |  |
| Bridge Facility | 1,500 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 1,500 |  |
| Other | 9 |  |  | 18 |  |  | 3 |  |  | 27 |  |  | — |  |  | 25 |  |  | 82 |  |
| Total maturities, principal amount | 3,736 |  |  | 7,008 |  |  | 5,206 |  |  | 2,470 |  |  | 9,728 |  |  | 22,580 |  |  | 50,728 |  |
| Associated carrying value adjustments | (9 | ) |  | (42 | ) |  | (51 | ) |  | (1 | ) |  | (230 | ) |  | (605 | ) |  | (938 | ) |
| Total maturities, carrying value amount | $ | 3,727 |  |  | $ | 6,966 |  |  | $ | 5,155 |  |  | $ | 2,469 |  |  | $ | 9,498 |  |  | $ | 21,975 |  |  | $ | 49,790 |  |

- changed (2017-09-08):
[0001571996-17-000020:note_history:41]
Covenants and Unrestricted Net Assets — The credit agreement for the Senior Secured Credit Facilities contain customary negative covenants that generally limit the ability of Denali Intermediate Inc., a wholly-owned subsidiary of Dell Technologies ("Dell Intermediate"), Dell, and Dell's and Denali Intermediate's other restricted subsidiaries to incur debt, create liens, make fundamental changes, enter into asset sales, make certain investments, pay dividends or distribute or redeem certain equity interests, prepay or redeem certain debt, and enter into certain transactions with affiliates.  The indenture governing the Senior Notes contains customary negative covenants that generally limit the ability of Denali Intermediate, Dell, and Dell's and Denali Intermediate's other restricted subsidiaries to incur additional debt or issue certain preferred shares, pay dividends on or make other distributions in respect of capital stock or make other restricted payments, make certain investments, sell or transfer certain assets, create liens on certain assets to secure debt, consolidate, merge, sell, or otherwise dispose of all or substantially all assets, enter into certain transactions with affiliates, and designate subsidiaries as unrestricted subsidiaries.  The negative covenants under such credit agreements and indenture are subject to certain exceptions, qualifications, and "baskets."  The indentures governing the First Lien Notes, the Unsecured Notes and Debentures, and the EMC Notes variously impose limitations, subject to specified exceptions, on creating certain liens, entering into sale and lease-back transactions, and entering into certain asset sales.  As of August 4, 2017, the Company had certain consolidated subsidiaries that were designated as unrestricted subsidiaries for all purposes of the applicable credit agreements and the indentures governing the First Lien Notes and the Senior Notes.  The foregoing credit agreements and indentures contain customary events of default, including failure to make required payments, failure to comply with covenants, and the occurrence of certain events of bankruptcy and insolvency.
  (was, 2017-06-09, similarity 0.9979):
[0001571996-17-000009:note_history:41]
Covenants and Unrestricted Net Assets — The credit agreement for the Senior Secured Credit Facilities contain customary negative covenants that generally limit the ability of Denali Intermediate Inc., a wholly-owned subsidiary of Dell Technologies ("Dell Intermediate"), Dell, and Dell's and Denali Intermediate's other restricted subsidiaries to incur debt, create liens, make fundamental changes, enter into asset sales, make certain investments, pay dividends or distribute or redeem certain equity interests, prepay or redeem certain debt, and enter into certain transactions with affiliates.  The indenture governing the Senior Notes contains customary negative covenants that generally limit the ability of Denali Intermediate, Dell, and Dell's and Denali Intermediate's other restricted subsidiaries to incur additional debt or issue certain preferred shares, pay dividends on or make other distributions in respect of capital stock or make other restricted payments, make certain investments, sell or transfer certain assets, create liens on certain assets to secure debt, consolidate, merge, sell, or otherwise dispose of all or substantially all assets, enter into certain transactions with affiliates, and designate subsidiaries as unrestricted subsidiaries.  The negative covenants under such credit agreements and indenture are subject to certain exceptions, qualifications, and "baskets."  The indentures governing the First Lien Notes, the Unsecured Notes and Debentures, and the EMC Notes variously impose limitations, subject to specified exceptions, on creating certain liens, entering into sale and lease-back transactions, and entering into certain asset sales.  As of May 5, 2017, the Company had certain consolidated subsidiaries that were designated as unrestricted subsidiaries for all purposes of the applicable credit agreements and the indentures governing the First Lien Notes and the Senior Notes.  The foregoing credit agreements and indentures contain customary events of default, including failure to make required payments, failure to comply with covenants, and the occurrence of certain events of bankruptcy and insolvency.

- changed (2017-09-08):
[0001571996-17-000020:note_history:42]
The Term Loan A-1 Facility, the Term Loan A-2 Facility, the Term Loan A-3 Facility, and the Revolving Credit Facility are subject to a first lien net leverage ratio covenant that is tested at the end of each fiscal quarter of Dell with respect to Dell's preceding four fiscal quarters.  The Company was in compliance with all financial covenants as of August 4, 2017.
  (was, 2017-06-09, similarity 0.9764):
[0001571996-17-000009:note_history:42]
The Term Loan A-1 Facility, the Term Loan A-2 Facility, the Term Loan A-3 Facility, and the Revolving Credit Facility are subject to a first lien net leverage ratio covenant that is tested at the end of each fiscal quarter of Dell with respect to Dell's preceding four fiscal quarters.  The Company was in compliance with all financial covenants as of May 5, 2017.

- removed (2017-09-08):
[0001571996-17-000009:note_history:43]
During the three months ended May 5, 2017, the Company refinanced the Term Loan B Facility to reduce the interest rate margin by 0.75% and to increase the outstanding principal amount by $500 million.


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-09-08):
[0001571996-17-000020:note_history:44]
|  | August 4, 2017 |  | February 3, 2017 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Secured Credit Facilities | $ | 10.9 |  |  | $ | 11.2 |  |  | $ | 11.4 |  |  | $ | 11.7 |  |
| First Lien Notes | $ | 19.7 |  |  | $ | 22.3 |  |  | $ | 19.7 |  |  | $ | 21.8 |  |
| Unsecured Notes and Debentures | $ | 2.3 |  |  | $ | 2.5 |  |  | $ | 2.3 |  |  | $ | 2.5 |  |
| Senior Notes | $ | 3.1 |  |  | $ | 3.5 |  |  | $ | 3.1 |  |  | $ | 3.5 |  |
| EMC Notes | $ | 5.5 |  |  | $ | 5.3 |  |  | $ | 5.5 |  |  | $ | 5.4 |  |
| Margin Loan Facility | $ | 2.0 |  |  | $ | 2.0 |  |  | $ | — |  |  | $ | — |  |
| Bridge Facilities | $ | 1.5 |  |  | $ | 1.5 |  |  | $ | 4.0 |  |  | $ | 4.0 |  |
  (was, 2017-06-09, similarity 0.9927):
[0001571996-17-000009:note_history:44]
|  | May 5, 2017 |  | February 3, 2017 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Secured Credit Facilities | $ | 11.8 |  |  | $ | 12.1 |  |  | $ | 11.4 |  |  | $ | 11.7 |  |
| First Lien Notes | $ | 19.7 |  |  | $ | 22.1 |  |  | $ | 19.7 |  |  | $ | 21.8 |  |
| Unsecured Notes and Debentures | $ | 2.3 |  |  | $ | 2.5 |  |  | $ | 2.3 |  |  | $ | 2.5 |  |
| Senior Notes | $ | 3.1 |  |  | $ | 3.5 |  |  | $ | 3.1 |  |  | $ | 3.5 |  |
| EMC Notes | $ | 5.5 |  |  | $ | 5.4 |  |  | $ | 5.5 |  |  | $ | 5.4 |  |
| Margin Loan Facility | $ | 2.0 |  |  | $ | 2.0 |  |  | $ | — |  |  | $ | — |  |
| Bridge Facilities | $ | 1.5 |  |  | $ | 1.5 |  |  | $ | 4.0 |  |  | $ | 4.0 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-09-08):
[0001571996-17-000020:note_history:45]
|  | August 4, 2017 |  | February 3, 2017 |
|  | (in millions) |
| Secured Debt |  |  |  |
| Structured financing debt | $ | 4,050 |  |  | $ | 3,464 |  |
| Senior Secured Credit Facilities: |  |  |  |
| 3.74% Term Loan B Facility due September 2023 | 5,460 |  |  | 4,987 |  |
| 3.24% Term Loan A-1 Facility due December 2018 | 69 |  |  | 600 |  |
| 3.49% Term Loan A-2 Facility due September 2021 | 3,778 |  |  | 3,876 |  |
| 3.24% Term Loan A-3 Facility due December 2018 | 1,800 |  |  | 1,800 |  |
| 2.78% Revolving Credit Facility due September 2021 | — |  |  | 375 |  |
| First Lien Notes: |  |  |  |
| 3.48% due June 2019 | 3,750 |  |  | 3,750 |  |
| 4.42% due June 2021 | 4,500 |  |  | 4,500 |  |
| 5.45% due June 2023 | 3,750 |  |  | 3,750 |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 8.10% due June 2036 | 1,500 |  |  | 1,500 |  |
| 8.35% due June 2046 | 2,000 |  |  | 2,000 |  |
| Unsecured Debt |  |  |  |
| Unsecured Notes and Debentures: |  |  |  |
| 5.65% due April 2018 | 500 |  |  | 500 |  |
| 5.875% due June 2019 | 600 |  |  | 600 |  |
| 4.625% due April 2021 | 400 |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 265 |  |  | 265 |  |
| Senior Notes: |  |  |  |
| 5.875% due June 2021 | 1,625 |  |  | 1,625 |  |
| 7.125% due June 2024 | 1,625 |  |  | 1,625 |  |
| EMC Notes: |  |  |  |
| 1.875% due June 2018 | 2,500 |  |  | 2,500 |  |
| 2.650% due June 2020 | 2,000 |  |  | 2,000 |  |
| 3.375% due June 2023 | 1,000 |  |  | 1,000 |  |
| Other |  |  |  |
| 3.56% Margin Loan Facility due April 2022 | 2,000 |  |  | — |  |
| 2.53% Margin Bridge Facility due September 2017 | — |  |  | 2,500 |  |
| 2.99% VMware Note Bridge Facility due September 2017 | 1,500 |  |  | 1,500 |  |
| Other | 86 |  |  | 51 |  |
| Total debt, principal amount | $ | 49,946 |  |  | $ | 50,356 |  |
| Unamortized discount, net of unamortized premium | (281 | ) |  | (284 | ) |
| Debt issuance costs | (605 | ) |  | (682 | ) |
| Total debt, carrying value | $ | 49,060 |  |  | $ | 49,390 |  |
| Total short-term debt, carrying value | $ | 7,686 |  |  | $ | 6,329 |  |
| Total long-term debt, carrying value | $ | 41,374 |  |  | $ | 43,061 |  |
  (was, 2017-06-09, similarity 0.7649):
[0001571996-17-000009:note_history:45]
|  | May 5, 2017 |  | February 3, 2017 |
|  | (in millions) |
| Secured Debt |  |  |  |
| Structured financing debt | $ | 3,869 |  |  | $ | 3,464 |  |
| Senior Secured Credit Facilities: |  |  |  |
| 3.50% Term Loan B Facility due September 2023 | 5,473 |  |  | 4,987 |  |
| 3.00% Term Loan A-1 Facility due December 2018 | 599 |  |  | 600 |  |
| 3.25% Term Loan A-2 Facility due September 2021 | 3,827 |  |  | 3,876 |  |
| 3.00% Term Loan A-3 Facility due December 2018 | 1,800 |  |  | 1,800 |  |
| 3.00% Revolving Credit Facility due September 2021 | 375 |  |  | 375 |  |
| First Lien Notes: |  |  |  |
| 3.48% due June 2019 | 3,750 |  |  | 3,750 |  |
| 4.42% due June 2021 | 4,500 |  |  | 4,500 |  |
| 5.45% due June 2023 | 3,750 |  |  | 3,750 |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 8.10% due June 2036 | 1,500 |  |  | 1,500 |  |
| 8.35% due June 2046 | 2,000 |  |  | 2,000 |  |
| Unsecured Debt |  |  |  |
| Unsecured Notes and Debentures: |  |  |  |
| 5.65% due April 2018 | 500 |  |  | 500 |  |
| 5.875% due June 2019 | 600 |  |  | 600 |  |
| 4.625% due April 2021 | 400 |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 265 |  |  | 265 |  |
| Senior Notes: |  |  |  |
| 5.875% due June 2021 | 1,625 |  |  | 1,625 |  |
| 7.125% due June 2024 | 1,625 |  |  | 1,625 |  |
| EMC Notes: |  |  |  |
| 1.875% due June 2018 | 2,500 |  |  | 2,500 |  |
| 2.650% due June 2020 | 2,000 |  |  | 2,000 |  |
| 3.375% due June 2023 | 1,000 |  |  | 1,000 |  |
| Other |  |  |  |
| 3.42% Margin Loan Facility due April 2022 | 2,000 |  |  | — |  |
| 2.53% Margin Bridge Facility due September 2017 | — |  |  | 2,500 |  |
| 2.75% VMware Note Bridge Facility due September 2017 | 1,500 |  |  | 1,500 |  |
| Other | 82 |  |  | 51 |  |
| Total debt, principal amount | $ | 50,728 |  |  | $ | 50,356 |  |
| Unamortized discount, net of unamortized premium | (293 | ) |  | (284 | ) |
| Debt issuance costs | (645 | ) |  | (682 | ) |
| Total debt, carrying value | $ | 49,790 |  |  | $ | 49,390 |  |
| Total short-term debt, carrying value | $ | 4,842 |  |  | $ | 6,329 |  |
| Total long-term debt, carrying value | $ | 44,948 |  |  | $ | 43,061 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-09-08):
[0001571996-17-000020:note_history:46]
As of August 4, 2017, aggregate future maturities of the Company's debt were as follows:
  (was, 2017-06-09, similarity 0.9571):
[0001571996-17-000009:note_history:46]
As of May 5, 2017, aggregate future maturities of the Company's debt were as follows:

- changed (2017-09-08):
[0001571996-17-000020:note_history:47]
|  | Maturities by Fiscal Year |
|  | 2018 (remaining six months) |  | 2019 |  | 2020 |  | 2021 |  | 2022 |  | Thereafter |  | Total |
|  | (in millions) |
| Structured Financing Debt | $ | 1,653 |  |  | $ | 1,827 |  |  | $ | 422 |  |  | $ | 117 |  |  | $ | 30 |  |  | $ | 1 |  |  | $ | 4,050 |  |
| Senior Secured Credit Facilities and First Lien Notes | 125 |  |  | 2,169 |  |  | 4,198 |  |  | 336 |  |  | 7,302 |  |  | 16,977 |  |  | 31,107 |  |
| Unsecured Notes and Debentures | — |  |  | 500 |  |  | 600 |  |  | — |  |  | 400 |  |  | 953 |  |  | 2,453 |  |
| Senior Notes and EMC Notes | — |  |  | 2,500 |  |  | — |  |  | 2,000 |  |  | 1,625 |  |  | 2,625 |  |  | 8,750 |  |
| Margin Loan Facility | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 2,000 |  |  | 2,000 |  |
| Bridge Facility | 1,500 |  |  | — |  |  | — |  |  | — |  |  | — |  |  |  |  |  | 1,500 |  |
| Other | 18 |  |  | 10 |  |  | 5 |  |  | 27 |  |  | — |  |  | 26 |  |  | 86 |  |
| Total maturities, principal amount | 3,296 |  |  | 7,006 |  |  | 5,225 |  |  | 2,480 |  |  | 9,357 |  |  | 22,582 |  |  | 49,946 |  |
| Associated carrying value adjustments | (3 | ) |  | (29 | ) |  | (45 | ) |  | (1 | ) |  | (217 | ) |  | (591 | ) |  | (886 | ) |
| Total maturities, carrying value amount | $ | 3,293 |  |  | $ | 6,977 |  |  | $ | 5,180 |  |  | $ | 2,479 |  |  | $ | 9,140 |  |  | $ | 21,991 |  |  | $ | 49,060 |  |
  (was, 2017-06-09, similarity 0.9949):
[0001571996-17-000009:note_history:47]
|  | Maturities by Fiscal Year |
|  | 2018 (remaining nine months) |  | 2019 |  | 2020 |  | 2021 |  | 2022 |  | Thereafter |  | Total |
|  | (in millions) |
| Structured Financing Debt | $ | 2,039 |  |  | $ | 1,291 |  |  | $ | 406 |  |  | $ | 107 |  |  | $ | 26 |  |  | $ | — |  |  | $ | 3,869 |  |
| Senior Secured Credit Facilities and First Lien Notes | 188 |  |  | 2,699 |  |  | 4,197 |  |  | 336 |  |  | 7,677 |  |  | 16,977 |  |  | 32,074 |  |
| Unsecured Notes and Debentures | — |  |  | 500 |  |  | 600 |  |  | — |  |  | 400 |  |  | 953 |  |  | 2,453 |  |
| Senior Notes and EMC Notes | — |  |  | 2,500 |  |  | — |  |  | 2,000 |  |  | 1,625 |  |  | 2,625 |  |  | 8,750 |  |
| Margin Loan Facility | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 2,000 |  |  | 2,000 |  |
| Bridge Facility | 1,500 |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 1,500 |  |
| Other | 9 |  |  | 18 |  |  | 3 |  |  | 27 |  |  | — |  |  | 25 |  |  | 82 |  |
| Total maturities, principal amount | 3,736 |  |  | 7,008 |  |  | 5,206 |  |  | 2,470 |  |  | 9,728 |  |  | 22,580 |  |  | 50,728 |  |
| Associated carrying value adjustments | (9 | ) |  | (42 | ) |  | (51 | ) |  | (1 | ) |  | (230 | ) |  | (605 | ) |  | (938 | ) |
| Total maturities, carrying value amount | $ | 3,727 |  |  | $ | 6,966 |  |  | $ | 5,155 |  |  | $ | 2,469 |  |  | $ | 9,498 |  |  | $ | 21,975 |  |  | $ | 49,790 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2017-09-08):
[0001571996-17-000020:note_history:48]
Amendment of Class V Common Stock Repurchase Program — On August 18, 2017, the Company's board of directors approved a second amendment of the Class V Group Repurchase Program (as so amended, the “August 2017 Class V Group Repurchase Program”) further extending the program to authorize the Company to use assets of the Company’s Class V Group to repurchase up to an additional $300 million of shares of the Company’s Class V Common Stock.  The repurchase of shares pursuant to the August 2017 Class V Group Repurchase Program is expected to be funded from proceeds received by the VMware, Inc. Class A Common Stock Repurchase program described below.

- added (2017-09-08):
[0001571996-17-000020:note_history:49]
VMware, Inc. Class A Common Stock Repurchase — In August 2017, VMware, Inc.'s board of directors authorized the repurchase of up to an additional $1 billion of VMware, Inc. Class A common stock through August 31, 2018.  The authorization is in addition to VMware, Inc.’s ongoing $1.2 billion stock repurchase program, originally announced in January 2017, of which $0.9 billion remains available.  On August 23, 2017, the Company and VMware, Inc. entered into a purchase commitment supplement to the March 2017 Stock Purchase Agreement (as amended, the “August 2017 Stock Purchase Agreement”).  Under the August 2017 Stock Purchase Agreement, VMware, Inc. will purchase for cash $300 million of VMware, Inc. Class A common stock from EMC Equity Assets LLC, an indirect wholly-owned subsidiary of the Company.  The Company will apply the proceeds from the sale to the repurchase of shares of its Class V Common Stock under the August 2017 Class V Group Repurchase Program described above, but may use such proceeds for other purposes at the discretion of the Capital Stock Committee of the board of directors and the board of directors.  The total number of shares to be purchased by VMware, Inc. under the August 2017 Stock Purchase Agreement will be based on the volume-weighted average per share price of the VMware, Inc. Class A common stock as reported on the New York Stock Exchange during a specified reference period, less a discount of 3.5% from that volume-weighted average per share price, and subject to adjustment in certain circumstances.

- added (2017-09-08):
[0001571996-17-000020:note_history:50]
VMware, Inc. Public Debt Offering — On August 21, 2017, VMware, Inc. completed a public debt offering in the aggregate amount of $4.0 billion, consisting of outstanding principal due on the following dates: $1.25 billion due August 21, 2020, $1.5 billion due August 21, 2022, and $1.25 billion due August 21, 2027. The notes bear interest, payable semi-annually, at annual rates of 2.30%, 2.95%, and 3.90%, respectively.  Upon closing, a portion of the net proceeds from the offering was used to repay certain intercompany promissory notes previously issued to EMC in the aggregate principal amount of $1.2 billion.

- added (2017-09-08):
[0001571996-17-000020:note_history:51]
VMware Note Bridge Facility Repayment — Subsequent to August 4, 2017, the Company repaid the $1.5 billion VMware Note Bridge Facility in full with proceeds of $1.2 billion from the foregoing VMware public debt offering and other cash.

- removed (2017-09-08):
[0001571996-17-000009:note_history:52]
Federal Income Taxes — In May 2017, the IRS commenced a federal income tax audit for fiscal years 2010 through 2014, which could take several years to complete.  Dell believes that adequate reserves have been provided related to all matters contained in tax periods open to examination.  For further discussion regarding tax matters, including the status of income tax audits, see Note 13 of the Notes to the Condensed Consolidated Financial Statements.
