# DELL notes — 0001571996-17-000020


## dvmt:ReconciliationofConsolidatedNetIncomeLossTableTextBlock

[0001571996-17-000020:notes:1]
[same as prior period, unchanged from 0001571996-17-000009:notes:1]

[0001571996-17-000020:notes:2]
|  | Three Months Ended |  | Six Months Ended |
|  | August 4, 2017 |  | July 29, 2016 |  | August 4, 2017 |  | July 29, 2016 |
|  | (in millions) |
| Net income from continuing operations attributable to Class V Common Stock | $ | 168 |  |  | $ | — |  |  | $ | 286 |  |  | $ | — |  |
| Net loss from continuing operations attributable to DHI Group | (1,114 | ) |  | (261 | ) |  | (2,566 | ) |  | (685 | ) |
| Net loss from continuing operations attributable to Dell Technologies Inc. | (946 | ) |  | (261 | ) |  | (2,280 | ) |  | (685 | ) |
| Income from discontinued operations, net of income taxes (Note 3) | — |  |  | 834 |  |  | — |  |  | 1,313 |  |
| Net income (loss) attributable to Dell Technologies Inc. | $ | (946 | ) |  | $ | 573 |  |  | $ | (2,280 | ) |  | $ | 628 |  |


## invest:InvestmentTableTextBlock

[0001571996-17-000020:notes:3]
[same as prior period, unchanged from 0001571996-17-000009:notes:3]

[0001571996-17-000020:notes:4]
|  | August 4, 2017 |  | February 3, 2017 |
|  | Cost |  | Unrealized Gain |  | Unrealized (Loss) |  | Carrying Value |  | Cost |  | Unrealized Gain |  | Unrealized (Loss) |  | Carrying Value |
|  | (in millions) |
| Investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government and agencies | $ | 441 |  |  | $ | — |  |  | $ | — |  |  | $ | 441 |  |  | $ | 231 |  |  | $ | — |  |  | $ | — |  |  | $ | 231 |  |
| U.S. corporate debt securities | 670 |  |  | — |  |  | (1 | ) |  | 669 |  |  | 651 |  |  | — |  |  | (1 | ) |  | 650 |  |
| Foreign debt securities | 906 |  |  | — |  |  | (1 | ) |  | 905 |  |  | 743 |  |  | — |  |  | (1 | ) |  | 742 |  |
| Municipal obligations | — |  |  | — |  |  | — |  |  | — |  |  | 348 |  |  | — |  |  | — |  |  | 348 |  |
| Asset-backed securities | — |  |  | — |  |  | — |  |  | — |  |  | 4 |  |  | — |  |  | — |  |  | 4 |  |
| Total short-term investments | 2,017 |  |  | — |  |  | (2 | ) |  | 2,015 |  |  | 1,977 |  |  | — |  |  | (2 | ) |  | 1,975 |  |
| U.S. government and agencies | 632 |  |  | — |  |  | (3 | ) |  | 629 |  |  | 689 |  |  | — |  |  | (6 | ) |  | 683 |  |
| U.S. corporate debt securities | 1,227 |  |  | 2 |  |  | (5 | ) |  | 1,224 |  |  | 1,164 |  |  | — |  |  | (14 | ) |  | 1,150 |  |
| Foreign debt securities | 1,430 |  |  | 2 |  |  | (5 | ) |  | 1,427 |  |  | 1,356 |  |  | — |  |  | (15 | ) |  | 1,341 |  |
| Municipal obligations | — |  |  | — |  |  | — |  |  | — |  |  | 4 |  |  | — |  |  | — |  |  | 4 |  |
| Equity and other securities (a) | 667 |  |  | 75 |  |  | — |  |  | 742 |  |  | 604 |  |  | 22 |  |  | (2 | ) |  | 624 |  |
| Total long-term investments | 3,956 |  |  | 79 |  |  | (13 | ) |  | 4,022 |  |  | 3,817 |  |  | 22 |  |  | (37 | ) |  | 3,802 |  |
| Total investments | $ | 5,973 |  |  | $ | 79 |  |  | $ | (15 | ) |  | $ | 6,037 |  |  | $ | 5,794 |  |  | $ | 22 |  |  | $ | (39 | ) |  | $ | 5,777 |  |

[0001571996-17-000020:notes:5]
[same as prior period, unchanged from 0001571996-17-000009:notes:5]

[0001571996-17-000020:notes:6]
[same as prior period, unchanged from 0001571996-17-000009:notes:6]


## invest:InvestmentTextBlock

[0001571996-17-000020:notes:7]
[same as prior period, unchanged from 0001571996-17-000009:notes:7]

[0001571996-17-000020:notes:8]
The Company's investments in debt securities are classified as available-for-sale securities, which are carried at fair value.  As of August 4, 2017, all investments in an unrealized loss position have been in a continuous unrealized loss position for less than 12 months.

[0001571996-17-000020:notes:9]
The maturities of debt securities held at August 4, 2017 are as follows:

[0001571996-17-000020:notes:10]
|  | Amortized Cost |  | Carrying Value |
|  | (in millions) |
| Due within one year | $ | 2,017 |  |  | $ | 2,015 |  |
| Due after 1 year through 5 years | 3,219 |  |  | 3,209 |  |
| Due after 5 years through 10 years | 70 |  |  | 71 |  |
| Total | $ | 5,306 |  |  | $ | 5,295 |  |


## us-gaap:AllowanceForCreditLossesOnFinancingReceivablesTableTextBlock

[0001571996-17-000020:notes:11]
The following tables summarize the changes in the allowance for financing receivable losses for the respective periods:

[0001571996-17-000020:notes:12]
|  | Three Months Ended |
|  | August 4, 2017 |  | July 29, 2016 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |
| Balances at beginning of period | $ | 85 |  |  | $ | 51 |  |  | $ | 136 |  |  | $ | 107 |  |  | $ | 58 |  |  | $ | 165 |  |
| Charge-offs, net of recoveries | (20 | ) |  | (5 | ) |  | (25 | ) |  | (23 | ) |  | (2 | ) |  | (25 | ) |
| Provision charged to income statement | 16 |  |  | 8 |  |  | 24 |  |  | 16 |  |  | — |  |  | 16 |  |
| Balances at end of period | $ | 81 |  |  | $ | 54 |  |  | $ | 135 |  |  | $ | 100 |  |  | $ | 56 |  |  | $ | 156 |  |

[0001571996-17-000020:notes:13]
|  | Six Months Ended |
|  | August 4, 2017 |  | July 29, 2016 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |
| Balances at beginning of period | $ | 91 |  |  | $ | 52 |  |  | $ | 143 |  |  | $ | 118 |  |  | $ | 58 |  |  | $ | 176 |  |
| Charge-offs, net of recoveries | (42 | ) |  | (8 | ) |  | (50 | ) |  | (48 | ) |  | (5 | ) |  | (53 | ) |
| Provision charged to income statement | 32 |  |  | 10 |  |  | 42 |  |  | 30 |  |  | 3 |  |  | 33 |  |
| Balances at end of period | $ | 81 |  |  | $ | 54 |  |  | $ | 135 |  |  | $ | 100 |  |  | $ | 56 |  |  | $ | 156 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001571996-17-000020:notes:14]
The accompanying unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes filed with the U.S. Securities and Exchange Commission ("SEC") in the Company's Annual Report on Form 10-K for the fiscal year ended February 3, 2017.  These Condensed Consolidated Financial Statements have been prepared in accordance with accounting principles generally accepted in the United States of America ("GAAP").  In the opinion of management, the accompanying Condensed Consolidated Financial Statements reflect all adjustments of a normal recurring nature considered necessary to fairly state the financial position of Dell Technologies Inc. (individually and together with its consolidated subsidiaries, the "Company" or "Dell Technologies") as of August 4, 2017 and February 3, 2017, the results of its operations and corresponding comprehensive income (loss) for the three and six months ended August 4, 2017 and July 29, 2016, as well as its cash flows for the six months ended August 4, 2017 and July 29, 2016.

[0001571996-17-000020:notes:15]
The preparation of financial statements in accordance with GAAP requires management to make estimates and assumptions that affect the amounts reported in the Condensed Consolidated Financial Statements and the accompanying Notes.  Actual results could differ materially from those estimates.  The results of operations and comprehensive income (loss) for the three and six months ended August 4, 2017 and July 29, 2016 and cash flows for the six months ended August 4, 2017 and July 29, 2016 are not necessarily indicative of the results to be expected for the full fiscal year or for any other fiscal period.


## us-gaap:BusinessAcquisitionProFormaInformationTextBlock

[0001571996-17-000020:notes:16]
The following table provides unaudited pro forma results of operations for the periods presented as if the transaction date had occurred on January 31, 2015, the first day of the fiscal year ended January 29, 2016.

[0001571996-17-000020:notes:17]
|  | Three Months Ended |  | Six Months Ended |
|  | July 29, 2016 |  | July 29, 2016 |
|  | (in millions, except per share amounts) |
| Total net revenue | $ | 18,562 |  |  | $ | 35,767 |  |
| Net loss attributable to Dell Technologies Inc. | $ | (1,158 | ) |  | $ | (2,542 | ) |
| Earnings (loss) per share attributable to Dell Technologies Inc. - basic (a): |  |  |  |
| Continuing operations - Class V Common Stock | $ | 0.66 |  |  | $ | 1.05 |  |
| Continuing operations - DHI Group | $ | (2.28 | ) |  | $ | (4.87 | ) |
| Earnings (loss) per share attributable to Dell Technologies Inc. - diluted (a): |  |  |  |
| Continuing operations - Class V Common Stock | $ | 0.66 |  |  | $ | 1.05 |  |
| Continuing operations - DHI Group | $ | (2.28 | ) |  | $ | (4.87 | ) |

[0001571996-17-000020:notes:18]
[same as prior period, unchanged from 0001571996-17-000009:notes:18]


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001571996-17-000020:notes:19]
[same as prior period, unchanged from 0001571996-17-000009:notes:19]

[0001571996-17-000020:notes:20]
[same as prior period, unchanged from 0001571996-17-000009:notes:20]

[0001571996-17-000020:notes:21]
[same as prior period, unchanged from 0001571996-17-000009:notes:21]

[0001571996-17-000020:notes:22]
[same as prior period, unchanged from 0001571996-17-000009:notes:22]

[0001571996-17-000020:notes:23]
Assets Acquired and Liabilities Assumed — The EMC merger transaction has been accounted for as a business combination under the acquisition method of accounting.  The cumulative impact of any subsequent changes resulting from the facts and circumstances that existed as of the transaction date will be adjusted in the reporting period in which the adjustment amount is determined.  The Company's purchase accounting is substantially complete.  The following table summarizes, as of August 4, 2017, the preliminary purchase price allocation to the assets acquired and the liabilities assumed in the EMC merger transaction (in millions):

[0001571996-17-000020:notes:24]
[same as prior period, unchanged from 0001571996-17-000009:notes:24]

[0001571996-17-000020:notes:25]
[same as prior period, unchanged from 0001571996-17-000009:notes:25]

[0001571996-17-000020:notes:26]
Pro Forma Financial Information — The following table provides unaudited pro forma results of operations for the periods presented as if the transaction date had occurred on January 31, 2015, the first day of the fiscal year ended January 29, 2016.

[0001571996-17-000020:notes:27]
The pro forma information for the three and six months ended July 29, 2016 combines the Company's historical results for the three and six months ended July 29, 2016 and EMC's historical results for the three and six months ended June 30, 2016.  The historical results have been adjusted in the pro forma information to give effect to items that are (a) directly attributable to the EMC merger transaction, (b) factually supportable, and (c) expected to have a continuing impact on the combined company's results.  The pro forma information is presented for informational purposes only.  The unaudited pro forma results include the elimination of non-recurring transaction and integration costs of $81 million and $144 million, respectively, for the three and six months ended July 29, 2016.  The pro forma information does not purport to represent what the combined company's results of operations or financial condition would have been had the EMC merger transaction actually occurred on the date indicated, and does not purport to project the combined company's results of operations for any future period or as of any future date.

[0001571996-17-000020:notes:28]
Acquisitions by VMware, Inc.

[0001571996-17-000020:notes:29]
During the three months ended August 4, 2017, VMware, Inc. completed the acquisitions of Wavefront and Apteligent, Inc., which were not material to the Condensed Consolidated Financial Statements.  These acquisitions are a part of VMware's strategy to accelerate the development of VMware Inc.'s Cloud services and other technologies.  The aggregate purchase price for the two acquisitions was $323 million, inclusive of the fair value of the Company's existing investment in Wavefront of $69 million and cash acquired of $35 million.  The aggregate purchase price included $36 million of identifiable intangible assets and $238 million of goodwill that is not expected to be deductible for tax purposes.  The identifiable intangible assets primarily relate to purchased technology, with estimated useful lives of five years.  The fair value of assumed unvested equity attributable to post-combination services was $37 million and will be expensed over the remaining requisite service periods on a straight-line basis.  The estimated fair value of the stock options assumed by the Company was determined using the Black-Scholes option pricing model.

[0001571996-17-000020:notes:30]
Prior to the closing of the acquisition, Dell Technologies, including VMware, Inc., held an ownership interest in Wavefront.  Upon completion of the step acquisition, Dell Technologies recognized a $45 million gain in interest and other, net for the remeasurement of its ownership interest to fair value.  The gain recognized on the step acquisition is not expected to be taxable.

[0001571996-17-000020:notes:31]
The Company has not presented pro forma results of operations for the foregoing acquisitions because they are not material to the Company's consolidated results of operations, financial position, or cash flows.


## us-gaap:BusinessDescriptionAndBasisOfPresentationTextBlock

[0001571996-17-000020:notes:32]
[same as prior period, unchanged from 0001571996-17-000009:notes:28]

[0001571996-17-000020:notes:33]
[same as prior period, unchanged from 0001571996-17-000009:notes:29]

[0001571996-17-000020:notes:34]
[same as prior period, unchanged from 0001571996-17-000009:notes:30]

[0001571996-17-000020:notes:35]
[same as prior period, unchanged from 0001571996-17-000009:notes:31]

[0001571996-17-000020:notes:36]
Basis of Presentation — The accompanying unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes filed with the U.S. Securities and Exchange Commission ("SEC") in the Company's Annual Report on Form 10-K for the fiscal year ended February 3, 2017.  These Condensed Consolidated Financial Statements have been prepared in accordance with accounting principles generally accepted in the United States of America ("GAAP").  In the opinion of management, the accompanying Condensed Consolidated Financial Statements reflect all adjustments of a normal recurring nature considered necessary to fairly state the financial position of Dell Technologies Inc. (individually and together with its consolidated subsidiaries, the "Company" or "Dell Technologies") as of August 4, 2017 and February 3, 2017, the results of its operations and corresponding comprehensive income (loss) for the three and six months ended August 4, 2017 and July 29, 2016, as well as its cash flows for the six months ended August 4, 2017 and July 29, 2016.

[0001571996-17-000020:notes:37]
[same as prior period, unchanged from 0001571996-17-000009:notes:33]

[0001571996-17-000020:notes:38]
As a result of the EMC merger transaction completed on September 7, 2016, the Company's results of operations, comprehensive income (loss), and cash flows for the fiscal periods reflected in these Condensed Consolidated Financial Statements are not directly comparable.  The results of the businesses acquired in the EMC merger transaction are included in the consolidated results of Dell Technologies for the three and six months ended August 4, 2017, but are not included in the consolidated results of Dell Technologies for the three and six months ended July 29, 2016.  The Dell Technologies unaudited Condensed Consolidated Statements of Financial Position reflect the full consolidation of EMC's assets and liabilities as of both August 4, 2017 and February 3, 2017.

[0001571996-17-000020:notes:39]
Unless the context indicates otherwise, references in these Notes to the Condensed Consolidated Financial Statements to "VMware" mean the VMware reportable segment, which reflects the operations of VMware, Inc. (NYSE: VMW) within Dell Technologies.  See Exhibit 99.1 filed with the Company's quarterly report on Form 10-Q for the quarterly period ended August 4, 2017 for information on the differences between VMware reportable segment results and VMware, Inc. results.

[0001571996-17-000020:notes:40]
Reclassifications — The amounts presented for the three and six months ended July 29, 2016 are different from those previously reported on Form 10-Q for the quarterly period ended July 29, 2016 because the Company reclassified an immaterial amount of net income from discontinued operations to continuing operations to reflect the updated terms of the applicable divestitures referred to above as the result of continued negotiations and finalization of terms of the sale.

[0001571996-17-000020:notes:41]
Recently Issued Accounting Pronouncements

[0001571996-17-000020:notes:42]
[same as prior period, unchanged from 0001571996-17-000009:notes:37]

[0001571996-17-000020:notes:43]
In August 2015, the FASB approved a one-year deferral of the effective date of this standard.  Public entities are required to adopt the new standard for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017.  The new revenue standard may be applied retrospectively to each prior period presented (full retrospective method) or retrospectively with the cumulative effect of initially applying the standard recognized at the date of initial application in retained earnings (modified retrospective method).  The Company currently expects to adopt this standard retrospectively to each prior period presented for the fiscal year beginning February 3, 2018.

[0001571996-17-000020:notes:44]
While the Company is currently evaluating the financial and system impacts that the new standard will have on the Consolidated Financial Statements, the Company expects that unearned license revenue related to the sale of software licenses and related deliverables will decline upon adoption.  Currently, the Company defers revenue for certain software arrangements due to the absence of vendor specific objective evidence ("VSOE") of fair value for all or a portion of the deliverables.  Under the new standard, the Company will no longer be required to establish VSOE of fair value in order to account for elements in an arrangement as separate units of accounting, and will be able to record revenue upon satisfaction of each performance obligation.  Additionally, the Company expects the new standard to have an impact on the way the transaction price is allocated for certain non-standard warranties.  The new standard is expected to result in more of the aggregate transaction price related to the non-standard warranty being recorded as revenue upon delivery of the underlying product, because the Company will no longer defer revenue based on the separately stated price of the non-standard warranty provided under the contract.  The Company continues to make progress in assessing the impacts of the standard on the Consolidated Financial Statements and will continue to evaluate the impact of any changes to the standard or interpretations should they become available.

[0001571996-17-000020:notes:45]
Recognition and Measurement of Financial Assets and Financial Liabilities — In January 2016, the FASB issued amended guidance that addresses certain aspects of recognition, measurement, presentation, and disclosure of financial instruments.  Public entities must adopt the new guidance for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017.  The amended guidance requires changes in the fair value of equity investments to be recognized through net income, rather than other comprehensive income.  Adoption of the standard will be applied through a cumulative one-time adjustment to retained earnings.  For the Company’s equity investments without readily determinable fair values, the Company expects to elect the measurement alternative to record those investments at cost, less impairment, and adjusted by observable price changes on a prospective basis.  The impact of the standard on the Consolidated Statements of Income (Loss) will depend on the relative changes in market price of the equity investments, although the impact is currently expected to be immaterial.

[0001571996-17-000020:notes:46]
Leases — In February 2016, the FASB issued amended guidance on the accounting for leasing transactions.  The primary objective of this update is to increase transparency and comparability among organizations by recognizing lease assets and lease liabilities on the balance sheet and disclosing key information about leasing arrangements.  Public entities must adopt the new guidance for reporting periods beginning after December 15, 2018, with early adoption permitted.  Companies are required to use a modified retrospective approach for leases that exist or are entered into after the beginning of the earliest comparative period in the financial statements.  The Company is currently evaluating the impact that the standard will have on the Consolidated Financial Statements.

[0001571996-17-000020:notes:47]
Measurement of Credit Losses on Financial Instruments — In June 2016, the FASB issued amended guidance which replaces the current incurred loss impairment methodology for measurement of credit losses on financial instruments with a methodology that reflects expected credit losses and requires consideration of a broader range of reasonable and supportable information to inform credit loss estimates.  Public entities must adopt the new guidance for fiscal years beginning after December 15, 2019, and interim periods within those fiscal years, with early adoption permitted for fiscal periods beginning after December 15, 2018.  The Company is currently evaluating the impact that the standard will have on the Consolidated Financial Statements.

[0001571996-17-000020:notes:48]
Classification of Certain Cash Receipts and Cash Payments — In August 2016, the FASB issued amended guidance on the presentation and classification of eight specific cash flow issues with the objective of reducing existing diversity in practice.  Public entities must adopt the new guidance for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017, with early adoption permitted.  Companies should reflect any adjustments on a retrospective basis, if practicable; otherwise, adoption is required to be applied as of the earliest date practicable.  The Company will adopt this standard during the fiscal quarter ending May 4, 2018, and will apply adjustments retrospectively to each prior period presented on the Condensed Consolidated Statements of Cash Flows for that period.  The Company is currently evaluating the impact of the standard, and other than certain reclassifications on the Consolidated Statements of Cash Flows, it is not expected to have a material impact on the Consolidated Financial Statements.

[0001571996-17-000020:notes:49]
Simplifying the Test for Goodwill Impairment — In January 2017, the FASB issued amended guidance to simplify the subsequent measurement of goodwill by removing Step 2 of the goodwill impairment test.  Instead, under the amendments in the new guidance, an entity should perform its annual, or interim, goodwill impairment test by comparing the fair value of a reporting unit with its carrying amount.  An entity should recognize an impairment charge for the amount by which the carrying amount exceeds the reporting unit's fair value.  Public entities must adopt the new guidance in fiscal years beginning after December 15, 2019, with early adoption permitted.  The Company is currently evaluating the impact of the new guidance, but does not expect that the standard will have an impact on its Consolidated Financial Statements.

[0001571996-17-000020:notes:50]
Derivatives and Hedging — In August 2017, the FASB issued amended guidance that will make more financial and non-financial hedging strategies eligible for hedge accounting.  The amended guidance changes how companies assess effectiveness, and also amends the presentation and disclosure requirements.  The guidance is intended to simplify the application of hedge accounting and increase transparency as to the scope and results of hedging programs.  Immediate early adoption is permitted in any interim or annual period.  The mandatory effective date for calendar year-end public companies is January 1, 2019.  The Company is currently evaluating the impact that the new guidance will have on the Consolidated Financial Statements.

[0001571996-17-000020:notes:51]
Recently Adopted Accounting Pronouncements

[0001571996-17-000020:notes:52]
Improvements to Employee Share-Based Payment Accounting — In March 2016, the FASB issued amended guidance on the accounting for employee share-based payments, including the accounting for income taxes and forfeitures, classification of awards as either equity or liabilities, and classification of cash flows.  The Company adopted this guidance at the beginning of Fiscal 2018.  In accordance with the new guidance, excess tax benefits or deficiencies for stock-based compensation are now reflected as a component of the provision for income taxes on the Consolidated Statements of Income (Loss), whereas they were previously recorded as additional paid-in capital.  The Company has elected to continue to estimate expected forfeitures.  Additionally, the Company now presents excess tax benefits as an operating activity rather than a financing activity on the Consolidated Statements of Cash Flows, while the cash flows related to employee taxes paid for withheld shares are presented as a financing activity with prior periods adjusted accordingly.  The adoption of the amended guidance did not have a material impact on the Consolidated Financial Statements.  The prospective impact of the new standard will depend on the Company's stock price at the vesting or exercise dates of the awards and the number of awards that vest or are exercised in each period, but the Company does not expect the impact to be material in future periods.

[0001571996-17-000020:notes:53]
Intra-Entity Transfers of Assets Other Than Inventory — In October 2016, the FASB issued amended guidance on the accounting for income taxes.  The new guidance requires companies to recognize the income tax effects of intra-entity asset transfers, other than transfers of inventory, when the transfer occurs instead of when the asset is sold to a third party.  The new guidance should be applied on a modified-retrospective basis with the cumulative-effect adjustment to retained earnings as of the beginning of the period of adoption.  The Company early adopted this guidance at the beginning of Fiscal 2018.  At adoption, approximately $84 million was reclassified from other non-current liabilities to retained earnings, resulting in a net credit to retained earnings.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001571996-17-000020:notes:54]
COMMITMENTS AND CONTINGENCIES

[0001571996-17-000020:notes:55]
Legal Matters

[0001571996-17-000020:notes:56]
The Company is involved in various claims, suits, assessments, investigations, and legal proceedings that arise from time to time in the ordinary course of its business, including those identified below, consisting of matters involving consumer, antitrust, tax, intellectual property, and other issues on a global basis.  The Company accrues a liability when it believes that it is both probable that a liability has been incurred and that it can reasonably estimate the amount of the loss.  The Company reviews these accruals at least quarterly and adjusts them to reflect ongoing negotiations, settlements, rulings, advice of legal counsel, and other relevant information.  To the extent new information is obtained and the Company's views on the probable outcomes of claims, suits, assessments, investigations, or legal proceedings change, changes in the Company's accrued liabilities would be recorded in the period in which such a determination is made.  For some matters, the amount of liability is not probable or the amount cannot be reasonably estimated and therefore accruals have not been made.  The following is a discussion of the Company's significant legal matters and other proceedings:

[0001571996-17-000020:notes:57]
EMC Merger Litigation — The Company, Dell, and Universal Acquisition Co. ("Universal") were named as defendants in fifteen putative class-action lawsuits brought by purported EMC shareholders and VMware, Inc. stockholders challenging the proposed merger between the Company, Dell, and Universal on the one hand, and EMC on the other (the "EMC merger").  Those suits are captioned as follows:

[0001571996-17-000020:notes:58]
| Case | Court | Filing Date |
| 1. | IBEW Local No. 129 Benefit Fund v. Tucci,Civ. No. 1584-3130-BLS1 | Mass. Superior Court, Suffolk County | 10/15/2015 |
| 2. | Barrett v. Tucci,Civ. No. 15-6023-A | Mass. Superior Court, Middlesex County | 10/16/2015 |
| 3. | Graulich v. Tucci,Civ. No. 1584-3169-BLS1 | Mass. Superior Court, Suffolk County | 10/19/2015 |
| 4. | Vassallo v. EMC Corp.,Civ. No. 1584-3173-BLS1 | Mass. Superior Court, Suffolk County | 10/19/2015 |
| 5. | City of Miami Police Relief & Pension Fund v. Tucci,Civ. No. 1584-3174-BLS1 | Mass. Superior Court, Suffolk County | 10/19/2015 |
| 6. | Lasker v. EMC Corp.,Civ. No. 1584-3214-BLS1 | Mass. Superior Court, Suffolk County | 10/23/2015 |
| 7. | Walsh v. EMC Corp.,Civ. No. 15-13654 | U.S. District Court,District of Massachusetts | 10/27/2015 |
| 8. | Local Union No. 373 U.A. Pension Plan v. EMC Corp.,Civ. No. 1584-3253-BLS1 | Mass. Superior Court, Suffolk County | 10/28/2015 |
| 9. | City of Lakeland Emps.' Pension & Ret. Fund v. Tucci,Civ. No. 1584-3269-BLS1 | Mass. Superior Court, Suffolk County | 10/28/2015 |
| 10. | Ma v. Tucci,Civ. No. 1584-3281-BLS1 | Mass. Superior Court, Suffolk County | 10/29/2015 |
| 11. | Stull v. EMC Corp.,Civ. No. 15-13692 | U.S. District Court,District of Massachusetts | 10/30/2015 |
| 12. | Jacobs v. EMC Corp.,Civ. No. 15-6318-H | Mass. Superior Court, Middlesex County | 11/12/2015 |
| 13. | Ford v. VMware, Inc.,C.A. No. 11714-VCL | Delaware Chancery Court | 11/17/2015 |
| 14. | Pancake v. EMC Corp.,Civ. No. 16-10040 | U.S. District Court,District of Massachusetts | 1/11/2016 |
| 15. | Booth Family Trust v. EMC Corp.,Civ. No. 16-10114 | U.S. District Court,District of Massachusetts | 1/26/2016 |

[0001571996-17-000020:notes:59]
The fifteen lawsuits sought, among other things, injunctive relief enjoining the EMC merger, rescission of the EMC merger if consummated, an award of fees and costs, and/or an award of damages.

[0001571996-17-000020:notes:60]
The complaints in the IBEW, Barrett, Graulich, Vassallo, City of Miami, Lasker, Local Union No. 373, City of Lakeland, and Ma actions generally allege that the EMC directors breached their fiduciary duties to EMC shareholders in connection with the EMC merger by, among other things, failing to maximize shareholder value and agreeing to provisions in the EMC merger agreement that discouraged competing bids.  After consolidating the nine complaints, by decision dated December 7, 2015, the Business Litigation Session of the Suffolk County Superior Court in Massachusetts dismissed all nine complaints for failure to make a demand on the EMC board of directors.  Three of the nine plaintiffs in the consolidated actions appealed the judgment dismissing their complaints.  The Massachusetts Supreme Judicial Court granted an application for direct appellate review, and heard oral argument on the appeal on November 7, 2016.  On March 6, 2017, the Supreme Judicial Court issued a decision affirming the dismissal.  This decision terminated the consolidated actions.

[0001571996-17-000020:notes:61]
The complaints in the Walsh, Stull, Pancake, and Booth actions allege that the EMC directors breached their fiduciary duties to EMC shareholders in connection with the EMC merger by, among other things, failing to maximize shareholder value and agreeing to provisions in the EMC merger agreement that discouraged competing bids.  The complaints generally further allege that the preliminary registration statement on Form S-4 filed by the Company on December 14, 2015 in connection with the transaction contained material misstatements and omissions, in violation of Section 14(a) of the Securities Exchange Act of 1934 (the "Exchange Act") and SEC Rule 14a-9 promulgated thereunder and/or that the Company, Dell, and Universal acted as controlling persons of EMC under Section 20(a) of the Exchange Act.  On June 6, 2016, the Securities and Exchange Commission declared effective the Company's registration statement on Form S-4 relating to the EMC merger (the "SEC Form S-4"), including the amendments thereto.  On June 17, 2016, the parties to the Walsh, Stull, Pancake, and Booth actions submitted to the Court a Stipulation and Proposed Order Dismissing Action and Retaining Jurisdiction to Determine Plaintiffs' Counsel's Application for an Award of Attorneys' Fees and Reimbursement of Expenses.  In the stipulation, the plaintiffs represented to the Court that they believe sufficient information had been disclosed to warrant dismissal of the actions as moot in light of the disclosures in the SEC Form S-4, including the amendments thereto.  On October 25, 2016, following an agreement between the parties with respect to attorneys' fees and expenses, the Court entered an order terminating the four actions for all purposes.

[0001571996-17-000020:notes:62]
The amended complaints in the Jacobs and Ford actions allege that EMC, as the majority stockholder of VMware, Inc., and the individual defendants, who were directors of EMC, VMware, Inc., or both, breached their fiduciary duties to minority stockholders of VMware, Inc. in connection with the proposed EMC merger by allegedly entering into or approving a merger that favors the interests of EMC and Dell at the expense of the minority stockholders.  The plaintiffs in the Jacobs action also brought suit against the Company, Dell, and Universal as alleged aiders and abettors.  Effective December 2, 2016, the parties entered into an agreement to resolve the Jacobs action, pursuant to which the plaintiff voluntarily dismissed the action with prejudice.  Under the operative amended complaint in the Ford action, the plaintiffs also brought suit against the Company and Dell for alleged breach of fiduciary duties to VMware, Inc. and its stockholders, and against the Company, Dell, and Universal for aiding and abetting the alleged breach of fiduciary duties by EMC's and VMware, Inc.'s directors.  Certain defendants filed motions to dismiss the amended complaint on June 21, 2016.  A hearing on those motions was held on February 3, 2017.  On May 2, 2017, the Court dismissed the amended complaint for failure to state a claim upon which relief could be granted and no appeal was taken.  All fifteen EMC merger-related lawsuits are now fully and finally resolved.

[0001571996-17-000020:notes:63]
Appraisal Proceedings — On October 29, 2013, Dell Technologies acquired Dell in a transaction referred to as the going-private transaction.  Holders of shares of Dell common stock who did not vote on September 12, 2013 in favor of the proposal to adopt the amended going-private transaction agreement and who properly demanded appraisal of their shares and who otherwise comply with the requirements of Section 262 of the Delaware General Corporate Law ("DGCL") are entitled to seek appraisal for, and obtain payment in cash for the judicially determined "fair value" (as defined pursuant to Section 262 of the DGCL) of, their shares in lieu of receiving the going-private transaction consideration.  Dell initially recorded a liability of $13.75 for each share with respect to which appraisal has been demanded and as to which the demand has not been withdrawn, together with interest at the statutory rate discussed below.  This liability was approximately $129 million as of both August 4, 2017 and February 3, 2017.  The Court of Chancery ruled that the fair value of the appraisal shares as of October 29, 2013, the date on which the going-private transaction became effective, was $17.62 per share.  This ruling would entitle the holders of the remaining 5,505,730 shares subject to the appraisal proceedings to $17.62 per share, plus interest at a statutory rate, compounded quarterly.  On November 21, 2016, the Court of Chancery entered final judgment in the appraisal action.  On November 22, 2016, Dell filed a notice of appeal to the Delaware Supreme Court, and a hearing is scheduled on that appeal for September 27, 2017.  The Company believes it was adequately reserved for the appraisal proceedings as of August 4, 2017.

[0001571996-17-000020:notes:64]
Securities Litigation — On May 22, 2014, a securities class action seeking compensatory damages was filed in the United States District Court for the Southern District of New York, captioned the City of Pontiac Employee Retirement System vs. Dell Inc. et. al. (Case No. 1:14-cv-03644).  The action names as defendants Dell Inc. and certain current and former executive officers, and alleges that Dell made false and misleading statements about Dell's business operations and products between February 22, 2012 and May 22, 2012, which resulted in artificially inflated stock prices.  The case was transferred to the United States District Court for the Western District of Texas, where the defendants filed a motion to dismiss.  On September 16, 2016, the Court denied the motion to dismiss and the case is proceeding with discovery.  The defendants believe the claims asserted are without merit and the risk of material loss is remote.

[0001571996-17-000020:notes:65]
Copyright Levies — The Company's obligation to collect and remit copyright levies in certain European Union ("EU") countries may be affected by the resolution of legal proceedings pending in Germany and other EU member states against various companies, including Dell subsidiaries.  The plaintiffs in those proceedings generally seek to impose or modify the levies with respect to sales of such equipment as multifunction devices, phones, personal computers, storage devices, and printers, alleging that such products enable the copying of copyrighted materials.  Some of the proceedings also challenge whether the levy schemes in those countries comply with EU law.  Certain EU member countries that do not yet impose levies on digital devices are expected to implement legislation to enable them to extend existing levy schemes, while some other EU member countries are expected to limit the scope of levy schemes and their applicability in the digital hardware environment.  Dell, other companies, and various industry associations have opposed the extension of levies to the digital environment and have advocated alternative models of compensation to rights holders.  The Company continues to collect levies in certain EU countries where it has determined that based on local laws it is probable that it has a payment obligation.  The amount of levies is generally based on the number of products sold and the per-product amounts of the levies, which vary.  The Company accrues a liability when it believes that it is both probable that a loss has been incurred and when it can reasonably estimate the amount of the loss.

[0001571996-17-000020:notes:66]
Other Litigation — The various legal proceedings in which Dell is involved include commercial litigation and a variety of patent suits.  In some of these cases, Dell is the sole defendant.  More often, particularly in the patent suits, Dell is one of a number of defendants in the electronics and technology industries.  Dell is actively defending a number of patent infringement suits, and several pending claims are in various stages of evaluation.  While the number of patent cases varies over time, Dell does not currently anticipate that any of these matters will have a material adverse effect on its business, financial condition, results of operations, or cash flows.

[0001571996-17-000020:notes:67]
As of August 4, 2017, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for these or other proceedings or matters has been incurred.  However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company's business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters.  Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company's business, financial condition, results of operations, or cash flows will depend on a number of variables, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.

[0001571996-17-000020:notes:68]
Indemnifications

[0001571996-17-000020:notes:69]
In the ordinary course of business, the Company enters into contractual arrangements under which it may agree to indemnify the third party to such arrangements from any losses incurred relating to the services it performs on behalf of the Company or for losses arising from certain events as defined in the particular contract, such as litigation or claims relating to past performance.  Such indemnification obligations may not be subject to maximum loss clauses.  Historically, payments related to these indemnifications have not been material to the Company.

[0001571996-17-000020:notes:70]
In connection with the divestitures discussed in Note 3 of the Notes to the Condensed Consolidated Financial Statements, the Company has indemnified the purchasers of businesses for the occurrence of specified events.  The Company does not currently believe that contingent obligations to provide indemnification in connection with these divestitures will have a material adverse effect on the Company.

[0001571996-17-000020:notes:71]
Purchase Obligations

[0001571996-17-000020:notes:72]
The Company has contractual obligations to purchase goods or services, which specify significant terms, including fixed or minimum quantities to be purchased; fixed, minimum, or variable price provisions; and the approximate timing of the transaction.  As of August 4, 2017, the Company had $2,724 million, $267 million, and $448 million in purchase obligations for Fiscal 2018 (remaining six months), Fiscal 2019, and Fiscal 2020 and thereafter, respectively.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001571996-17-000020:notes:73]
[same as prior period, unchanged from 0001571996-17-000009:notes:70]

[0001571996-17-000020:notes:74]
[same as prior period, unchanged from 0001571996-17-000009:notes:71]

[0001571996-17-000020:notes:75]
[same as prior period, unchanged from 0001571996-17-000009:notes:72]

[0001571996-17-000020:notes:76]
|  | Foreign Currency Translation Adjustments |  | Investments |  | Cash Flow Hedges |  | Pension and Other Postretirement Plans |  | Accumulated Other Comprehensive Loss |
|  | (in millions) |
| Balances as of February 3, 2017 | $ | (612 | ) |  | $ | (13 | ) |  | $ | 11 |  |  | $ | 19 |  |  | $ | (595 | ) |
| Other comprehensive income (loss) before reclassifications | 450 |  |  | 47 |  |  | (157 | ) |  | — |  |  | 340 |  |
| Amounts reclassified from accumulated other comprehensive loss | — |  |  | 3 |  |  | 49 |  |  | — |  |  | 52 |  |
| Total change for the period | 450 |  |  | 50 |  |  | (108 | ) |  | — |  |  | 392 |  |
| Less: Change in comprehensive income attributable to non-controlling interests | — |  |  | 4 |  |  | — |  |  | — |  |  | 4 |  |
| Balances as of August 4, 2017 | $ | (162 | ) |  | $ | 33 |  |  | $ | (97 | ) |  | $ | 19 |  |  | $ | (207 | ) |

[0001571996-17-000020:notes:77]
[same as prior period, unchanged from 0001571996-17-000009:notes:74]

[0001571996-17-000020:notes:78]
The following tables present reclassifications out of accumulated other comprehensive loss, net of tax, to net income (loss) for the periods presented:

[0001571996-17-000020:notes:79]
|  | Three Months Ended |
|  | August 4, 2017 |  | July 29, 2016 |
|  | Investments |  | Cash Flow Hedges |  | Total |  | Investments |  | Cash Flow Hedges |  | Total |
|  | (in millions) |
| Total reclassifications, net of tax: |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue | $ | — |  |  | $ | (49 | ) |  | $ | (49 | ) |  | $ | — |  |  | $ | (21 | ) |  | $ | (21 | ) |
| Cost of net revenue | — |  |  | (21 | ) |  | (21 | ) |  | — |  |  | (6 | ) |  | (6 | ) |
| Interest and other, net | (2 | ) |  | — |  |  | (2 | ) |  | — |  |  | — |  |  | — |  |
| Total reclassifications, net of tax | $ | (2 | ) |  | $ | (70 | ) |  | $ | (72 | ) |  | $ | — |  |  | $ | (27 | ) |  | $ | (27 | ) |

[0001571996-17-000020:notes:80]
|  | Six Months Ended |
|  | August 4, 2017 |  | July 29, 2016 |
|  | Investments |  | Cash Flow Hedges |  | Total |  | Investments |  | Cash Flow Hedges |  | Total |
|  | (in millions) |
| Total reclassifications, net of tax: |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue | $ | — |  |  | $ | (32 | ) |  | $ | (32 | ) |  | $ | — |  |  | $ | (66 | ) |  | $ | (66 | ) |
| Cost of net revenue | — |  |  | (17 | ) |  | (17 | ) |  | — |  |  | (14 | ) |  | (14 | ) |
| Interest and other, net | (3 | ) |  | — |  |  | (3 | ) |  | — |  |  | (1 | ) |  | (1 | ) |
| Total reclassifications, net of tax | $ | (3 | ) |  | $ | (49 | ) |  | $ | (52 | ) |  | $ | — |  |  | $ | (81 | ) |  | $ | (81 | ) |


## us-gaap:ConsolidationLessThanWhollyOwnedSubsidiaryParentOwnershipInterestEffectsOfChangesNetTextBlock

[0001571996-17-000020:notes:81]
The effect of changes in the Company's ownership interest in VMware, Inc., SecureWorks, and Pivotal on the Company's equity for the period presented was as follows:

[0001571996-17-000020:notes:82]
|  | Six Months Ended |
|  | August 4, 2017 |
|  | (in millions) |
| Net loss attributable to Dell Technologies Inc. | $ | (2,280 | ) |
| Transfers (to) from the non-controlling interests: |  |
| Increase in Dell Technologies Inc. additional paid-in-capital for equity issuances and other equity activity | 305 |  |
| Decrease in Dell Technologies Inc. additional paid-in-capital for equity issuances and other equity activity | (351 | ) |
| Net transfers to non-controlling interests | (46 | ) |
| Change from net loss attributable to Dell Technologies Inc. and transfers to/from the non-controlling interests | $ | (2,326 | ) |


## us-gaap:DebtDisclosureTextBlock

[0001571996-17-000020:notes:83]
DEBT

[0001571996-17-000020:notes:84]
The following table summarizes the Company's outstanding debt as of the dates indicated:

[0001571996-17-000020:notes:85]
|  | August 4, 2017 |  | February 3, 2017 |
|  | (in millions) |
| Secured Debt |  |  |  |
| Structured financing debt | $ | 4,050 |  |  | $ | 3,464 |  |
| Senior Secured Credit Facilities: |  |  |  |
| 3.74% Term Loan B Facility due September 2023 | 5,460 |  |  | 4,987 |  |
| 3.24% Term Loan A-1 Facility due December 2018 | 69 |  |  | 600 |  |
| 3.49% Term Loan A-2 Facility due September 2021 | 3,778 |  |  | 3,876 |  |
| 3.24% Term Loan A-3 Facility due December 2018 | 1,800 |  |  | 1,800 |  |
| 2.78% Revolving Credit Facility due September 2021 | — |  |  | 375 |  |
| First Lien Notes: |  |  |  |
| 3.48% due June 2019 | 3,750 |  |  | 3,750 |  |
| 4.42% due June 2021 | 4,500 |  |  | 4,500 |  |
| 5.45% due June 2023 | 3,750 |  |  | 3,750 |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 8.10% due June 2036 | 1,500 |  |  | 1,500 |  |
| 8.35% due June 2046 | 2,000 |  |  | 2,000 |  |
| Unsecured Debt |  |  |  |
| Unsecured Notes and Debentures: |  |  |  |
| 5.65% due April 2018 | 500 |  |  | 500 |  |
| 5.875% due June 2019 | 600 |  |  | 600 |  |
| 4.625% due April 2021 | 400 |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 265 |  |  | 265 |  |
| Senior Notes: |  |  |  |
| 5.875% due June 2021 | 1,625 |  |  | 1,625 |  |
| 7.125% due June 2024 | 1,625 |  |  | 1,625 |  |
| EMC Notes: |  |  |  |
| 1.875% due June 2018 | 2,500 |  |  | 2,500 |  |
| 2.650% due June 2020 | 2,000 |  |  | 2,000 |  |
| 3.375% due June 2023 | 1,000 |  |  | 1,000 |  |
| Other |  |  |  |
| 3.56% Margin Loan Facility due April 2022 | 2,000 |  |  | — |  |
| 2.53% Margin Bridge Facility due September 2017 | — |  |  | 2,500 |  |
| 2.99% VMware Note Bridge Facility due September 2017 | 1,500 |  |  | 1,500 |  |
| Other | 86 |  |  | 51 |  |
| Total debt, principal amount | $ | 49,946 |  |  | $ | 50,356 |  |
| Unamortized discount, net of unamortized premium | (281 | ) |  | (284 | ) |
| Debt issuance costs | (605 | ) |  | (682 | ) |
| Total debt, carrying value | $ | 49,060 |  |  | $ | 49,390 |  |
| Total short-term debt, carrying value | $ | 7,686 |  |  | $ | 6,329 |  |
| Total long-term debt, carrying value | $ | 41,374 |  |  | $ | 43,061 |  |

[0001571996-17-000020:notes:86]
During the three months ended May 5, 2017, the Company refinanced the Term Loan B Facility to reduce the interest rate margin by 0.75% and to increase the outstanding principal amount by $500 million.  The Company applied the proceeds from the Term Loan B Facility refinancing to repay $500 million principal amount of the Margin Bridge Facility, without premium or penalty, and accrued and unpaid interest thereon.  Additionally, during the three months ended May 5, 2017, the Company issued the Margin Loan Facility in the principal amount of $2.0 billion, and used the proceeds of the new facility to repay the Margin Bridge Facility, without premium or penalty.  Further, during the six months ended August 4, 2017, the Company repaid approximately $0.6 billion principal amount of its term loan facilities, repaid $0.4 billion, net, under the Revolving Credit Facility, and issued an additional $0.6 billion, net, in structured financing debt to support the expansion of its financing receivables portfolio.

[0001571996-17-000020:notes:87]
Senior Secured Credit Facilities — At the closing of the EMC merger transaction on September 7, 2016, the Company entered into a credit agreement that provides for senior secured credit facilities (the "Senior Secured Credit Facilities") in the aggregate principal amount of $17.6 billion comprising (a) term loan facilities and (b) a senior secured Revolving Credit Facility, which includes capacity for up to $0.5 billion of letters of credit and for borrowings of up to $0.4 billion under swing-line loans.  As of August 4, 2017, available borrowings under the Revolving Credit Facility totaled $3.1 billion.  The Senior Secured Credit Facilities provide that the borrowers have the right at any time, subject to customary conditions, to request incremental term loans or incremental revolving commitments.

[0001571996-17-000020:notes:88]
Borrowings under the Senior Secured Credit Facilities bear interest at a rate per annum equal to an applicable margin, plus, at the borrowers' option, either (a) a base rate, which, under the Term Loan B Facility, is subject to an interest rate floor of 1.75% per annum, and under all other borrowings is subject to an interest rate floor of 0% per annum, or (b) a London interbank offered rate ("LIBOR"), which, under the Term Loan B Facility, is subject to an interest rate floor of 0.75% per annum, and under all other borrowings is subject to an interest rate floor of 0% per annum.  Interest is payable, in the case of loans bearing interest based on LIBOR, at the end of each interest period (but at least every three months), in arrears and, in the case of loans bearing interest based on the base rate, quarterly in arrears.

[0001571996-17-000020:notes:89]
The Term Loan A-1 Facility, the Term Loan A-3 Facility, and the Revolving Credit Facility have no amortization.  The Term Loan A-2 Facility amortizes in equal quarterly installments in aggregate annual amounts equal to 5% of the original principal amount in each of the first two years after the closing date of the EMC merger transaction, 10% of the original principal amount in each of the third and fourth years after the closing date of the EMC merger transaction, and 70% of the original principal amount in the fifth year after the closing date of the EMC merger transaction.  The Term Loan B Facility amortizes in equal quarterly installments in aggregate annual amounts equal to 1% of the original principal amount.  The Term Loan A-1 and Term Loan A-3 Facilities require the borrowers to prepay outstanding borrowings under these facilities with 100% of the net cash proceeds of certain non-ordinary course asset sales or dispositions.  The borrowers may voluntarily repay outstanding loans under the term loan facilities and the Revolving Credit Facility at any time without premium or penalty, other than customary "breakage" costs.

[0001571996-17-000020:notes:90]
All obligations of the borrowers under the Senior Secured Credit Facilities and certain swap agreements, cash management arrangements, and certain letters of credit provided by any lender or agent party to the Senior Secured Credit Facilities or any of its affiliates and certain other persons are secured by (a) a first-priority security interest in certain tangible and intangible assets of the borrowers and the guarantors and (b) a first-priority pledge of 100% of the capital stock of the borrowers, Dell Inc., an indirect wholly-owned subsidiary of Dell Technologies ("Dell"), and each wholly-owned material restricted subsidiary of the borrowers and the guarantors, in each case subject to certain thresholds, exceptions, and permitted liens.

[0001571996-17-000020:notes:91]
First Lien Notes — The senior secured notes (collectively, the "First Lien Notes") were issued on June 1, 2016 in an aggregate principal amount of $20.0 billion.  Interest on these borrowings is payable semiannually.  The First Lien Notes are secured, on a pari passu basis with the Senior Secured Credit Facilities, on a first-priority basis by substantially all of the tangible and intangible assets of the issuers and guarantors that secure obligations under the Senior Secured Credit Facilities, including pledges of all capital stock of the issuers, of Dell, and of certain wholly-owned material subsidiaries of the issuers and the guarantors, subject to certain exceptions.

[0001571996-17-000020:notes:92]
The Company has agreed to use commercially reasonable efforts to register with the SEC notes having terms substantially identical to the terms of the First Lien Notes as part of an offer to exchange such registered notes for the First Lien Notes.  The Company will be obligated to pay additional interest on the First Lien Notes if it fails to consummate such an exchange offer within five years after the closing date of the EMC merger transaction.

[0001571996-17-000020:notes:93]
Senior Notes — The senior unsecured notes (collectively, the "Senior Notes") were issued on June 22, 2016 in an aggregate principal amount of $3.25 billion.  Interest on these borrowings is payable semiannually.

[0001571996-17-000020:notes:94]
EMC Notes — On September 7, 2016, EMC had outstanding $2.5 billion aggregate principal amount of its 1.875% Notes due June 2018, $2.0 billion aggregate principal amount of its 2.650% Notes due June 2020, and $1.0 billion aggregate principal amount of its 3.375% Notes due June 2023 (collectively, the "EMC Notes").  Interest on these borrowings is payable semiannually.  The EMC Notes remain outstanding following the closing of the EMC merger transaction.

[0001571996-17-000020:notes:95]
Margin Loan Facility — During the three months ended May 5, 2017, the Company issued the Margin Loan Facility in an aggregate principal amount of $2.0 billion.  VMW Holdco LLC, a wholly-owned subsidiary of EMC, is the borrower under the Margin Loan Facility, which is secured by 60 million shares of Class B common stock of VMware, Inc. and 20 million shares of Class A common stock of VMware, Inc.  Loans under the Margin Loan Facility bear interest at a rate per annum payable, at the borrower's option, either at (a) a base rate plus 1.25% per annum or (b) a LIBOR-based rate plus 2.25% per annum.  Interest under the Margin Loan Facility is payable quarterly.

[0001571996-17-000020:notes:96]
The Margin Loan Facility will mature in April 2022.  The borrower may voluntarily repay outstanding loans under the Margin Loan Facility at any time without premium or penalty, other than customary "breakage" costs, subject to certain minimum threshold amounts for prepayment.

[0001571996-17-000020:notes:97]
Margin Bridge Facility — On September 7, 2016, Merger Sub and EMC entered into a credit agreement providing for a senior secured margin bridge facility in an aggregate principal amount of $2.5 billion (the "Margin Bridge Facility").

[0001571996-17-000020:notes:98]
During the three months ended May 5, 2017, the Company separately applied the proceeds from the Term Loan B Facility refinancing and the issuance of the Margin Loan Facility to repay the Margin Bridge Facility, without premium or penalty.

[0001571996-17-000020:notes:99]
VMware Note Bridge Facility — On September 7, 2016, Merger Sub and EMC entered into a credit agreement providing for a senior secured note bridge facility in an aggregate principal amount of $1.5 billion (the "VMware Note Bridge Facility").  The VMware Note Bridge Facility is secured solely by certain intercompany notes in an aggregate principal amount of $1.5 billion issued by VMware, Inc. that are payable to EMC, and the proceeds thereof.

[0001571996-17-000020:notes:100]
Interest under the VMware Note Bridge Facility is payable, at the borrower's option, either at (a) a base rate plus 0.75% per annum or (b) a LIBOR-based rate plus 1.75% per annum.  Interest is payable, in the case of loans bearing interest based on LIBOR, at the end of each interest period (but at least every three months), in arrears and, in the case of loans bearing interest based on the base rate, quarterly in arrears.

[0001571996-17-000020:notes:101]
The VMware Note Bridge Facility has no amortization.  The borrower is required to prepay outstanding borrowings under the VMware Note Bridge Facility with 100% of the net cash proceeds of any asset sale or other disposition of the pledged VMware, Inc. promissory notes.  The borrower may voluntarily repay outstanding loans under the VMware Note Bridge Facility at any time without premium or penalty, other than customary "breakage" costs, subject to certain minimum threshold amounts for prepayment.  For more information regarding the VMware Note Bridge Facility see Note 21 of the Notes to the Condensed Consolidated Financial Statements.

[0001571996-17-000020:notes:102]
Structured Financing Debt — As of August 4, 2017 and February 3, 2017, the Company had $4.1 billion and $3.5 billion, respectively, in outstanding structured financing debt, which was primarily related to the fixed-term lease and loan securitization programs and the revolving loan securitization programs.  See Note 6 and Note 8 of the Notes to the Condensed Consolidated Financial Statements for further discussion of the structured financing debt and the interest rate swap agreements that hedge a portion of that debt.

[0001571996-17-000020:notes:103]
Unsecured Notes and Debentures — The Company has unsecured notes and debentures (collectively, the "Unsecured Notes and Debentures") that were issued prior to the acquisition of Dell by Dell Technologies Inc.  Interest on these borrowings is payable semiannually.

[0001571996-17-000020:notes:104]
Aggregate Future Maturities — As of August 4, 2017, aggregate future maturities of the Company's debt were as follows:

[0001571996-17-000020:notes:105]
|  | Maturities by Fiscal Year |
|  | 2018 (remaining six months) |  | 2019 |  | 2020 |  | 2021 |  | 2022 |  | Thereafter |  | Total |
|  | (in millions) |
| Structured Financing Debt | $ | 1,653 |  |  | $ | 1,827 |  |  | $ | 422 |  |  | $ | 117 |  |  | $ | 30 |  |  | $ | 1 |  |  | $ | 4,050 |  |
| Senior Secured Credit Facilities and First Lien Notes | 125 |  |  | 2,169 |  |  | 4,198 |  |  | 336 |  |  | 7,302 |  |  | 16,977 |  |  | 31,107 |  |
| Unsecured Notes and Debentures | — |  |  | 500 |  |  | 600 |  |  | — |  |  | 400 |  |  | 953 |  |  | 2,453 |  |
| Senior Notes and EMC Notes | — |  |  | 2,500 |  |  | — |  |  | 2,000 |  |  | 1,625 |  |  | 2,625 |  |  | 8,750 |  |
| Margin Loan Facility | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 2,000 |  |  | 2,000 |  |
| Bridge Facility | 1,500 |  |  | — |  |  | — |  |  | — |  |  | — |  |  |  |  |  | 1,500 |  |
| Other | 18 |  |  | 10 |  |  | 5 |  |  | 27 |  |  | — |  |  | 26 |  |  | 86 |  |
| Total maturities, principal amount | 3,296 |  |  | 7,006 |  |  | 5,225 |  |  | 2,480 |  |  | 9,357 |  |  | 22,582 |  |  | 49,946 |  |
| Associated carrying value adjustments | (3 | ) |  | (29 | ) |  | (45 | ) |  | (1 | ) |  | (217 | ) |  | (591 | ) |  | (886 | ) |
| Total maturities, carrying value amount | $ | 3,293 |  |  | $ | 6,977 |  |  | $ | 5,180 |  |  | $ | 2,479 |  |  | $ | 9,140 |  |  | $ | 21,991 |  |  | $ | 49,060 |  |

[0001571996-17-000020:notes:106]
Covenants and Unrestricted Net Assets — The credit agreement for the Senior Secured Credit Facilities contain customary negative covenants that generally limit the ability of Denali Intermediate Inc., a wholly-owned subsidiary of Dell Technologies ("Dell Intermediate"), Dell, and Dell's and Denali Intermediate's other restricted subsidiaries to incur debt, create liens, make fundamental changes, enter into asset sales, make certain investments, pay dividends or distribute or redeem certain equity interests, prepay or redeem certain debt, and enter into certain transactions with affiliates.  The indenture governing the Senior Notes contains customary negative covenants that generally limit the ability of Denali Intermediate, Dell, and Dell's and Denali Intermediate's other restricted subsidiaries to incur additional debt or issue certain preferred shares, pay dividends on or make other distributions in respect of capital stock or make other restricted payments, make certain investments, sell or transfer certain assets, create liens on certain assets to secure debt, consolidate, merge, sell, or otherwise dispose of all or substantially all assets, enter into certain transactions with affiliates, and designate subsidiaries as unrestricted subsidiaries.  The negative covenants under such credit agreements and indenture are subject to certain exceptions, qualifications, and "baskets."  The indentures governing the First Lien Notes, the Unsecured Notes and Debentures, and the EMC Notes variously impose limitations, subject to specified exceptions, on creating certain liens, entering into sale and lease-back transactions, and entering into certain asset sales.  As of August 4, 2017, the Company had certain consolidated subsidiaries that were designated as unrestricted subsidiaries for all purposes of the applicable credit agreements and the indentures governing the First Lien Notes and the Senior Notes.  The foregoing credit agreements and indentures contain customary events of default, including failure to make required payments, failure to comply with covenants, and the occurrence of certain events of bankruptcy and insolvency.

[0001571996-17-000020:notes:107]
The Term Loan A-1 Facility, the Term Loan A-2 Facility, the Term Loan A-3 Facility, and the Revolving Credit Facility are subject to a first lien net leverage ratio covenant that is tested at the end of each fiscal quarter of Dell with respect to Dell's preceding four fiscal quarters.  The Company was in compliance with all financial covenants as of August 4, 2017.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001571996-17-000020:notes:108]
[same as prior period, unchanged from 0001571996-17-000009:notes:105]

[0001571996-17-000020:notes:109]
[same as prior period, unchanged from 0001571996-17-000009:notes:106]

[0001571996-17-000020:notes:110]
[same as prior period, unchanged from 0001571996-17-000009:notes:107]

[0001571996-17-000020:notes:111]
The Company's objective is to offset gains and losses resulting from these exposures with gains and losses on the derivative contracts used to hedge the exposures, thereby reducing volatility of earnings and protecting the fair values of assets and liabilities.  For derivatives designated as cash flow hedges, the Company assesses hedge effectiveness both at the onset of the hedge and at regular intervals throughout the life of the derivative and recognizes any ineffective portion of the hedge in earnings as a component of interest and other, net.  Hedge ineffectiveness recognized in earnings was not material during the three and six months ended August 4, 2017 and July 29, 2016.

[0001571996-17-000020:notes:112]
[same as prior period, unchanged from 0001571996-17-000009:notes:109]

[0001571996-17-000020:notes:113]
[same as prior period, unchanged from 0001571996-17-000009:notes:110]

[0001571996-17-000020:notes:114]
During the three and six months ended August 4, 2017 and July 29, 2016, the Company did not discontinue any cash flow hedges related to foreign exchange contracts that had a material impact on the Company's results of operations due to the probability that the forecasted cash flows would not occur.

[0001571996-17-000020:notes:115]
[same as prior period, unchanged from 0001571996-17-000009:notes:112]

[0001571996-17-000020:notes:116]
[same as prior period, unchanged from 0001571996-17-000009:notes:113]

[0001571996-17-000020:notes:117]
[same as prior period, unchanged from 0001571996-17-000009:notes:114]

[0001571996-17-000020:notes:118]
[same as prior period, unchanged from 0001571996-17-000009:notes:115]

[0001571996-17-000020:notes:119]
[same as prior period, unchanged from 0001571996-17-000009:notes:116]

[0001571996-17-000020:notes:120]
[same as prior period, unchanged from 0001571996-17-000009:notes:117]

[0001571996-17-000020:notes:121]
[same as prior period, unchanged from 0001571996-17-000009:notes:118]

[0001571996-17-000020:notes:122]
[same as prior period, unchanged from 0001571996-17-000009:notes:119]

[0001571996-17-000020:notes:123]
|  | August 4, 2017 |  | February 3, 2017 (a) |
|  | (in millions) |
| Foreign exchange contracts: |  |  |  |  |  |
| Designated as cash flow hedging instruments | $ | 4,181 |  |  | $ | 3,781 |  |
| Non-designated as hedging instruments | 6,601 |  |  | 5,146 |  |
| Total | $ | 10,782 |  |  | $ | 8,927 |  |
| Interest rate contracts: |  |  |  |
| Non-designated as hedging instruments | $ | 1,519 |  |  | $ | 1,251 |  |

[0001571996-17-000020:notes:124]
| (a) | During the three months ended May 5, 2017, the notional amount calculation methodology was enhanced to reflect the sum of the absolute value of derivative instruments netted by currency. Prior period amounts have been updated to conform with the current period presentation. |

[0001571996-17-000020:notes:125]
[same as prior period, unchanged from 0001571996-17-000009:notes:122]

[0001571996-17-000020:notes:126]
| Derivatives inCash FlowHedging Relationships |  | Gain (Loss)Recognizedin AccumulatedOCI, Netof Tax, onDerivatives(Effective Portion) |  | Location of Gain (Loss)Reclassifiedfrom AccumulatedOCI into Income(Effective Portion) |  | Gain (Loss)Reclassifiedfrom AccumulatedOCI into Income(Effective Portion) |  | Location of Gain (Loss) Recognized in Income on Derivative (Ineffective Portion) |  | Gain (Loss) Recognized in Income on Derivative (Ineffective Portion) |
| (in millions) |
| For the three months ended August 4, 2017 |  |  |  |  |  |  |
|  |  |  |  |  | Total net revenue |  | $ | (49 | ) |  |  |  |  |
| Foreign exchange contracts |  | $ | (141 | ) |  | Total cost of net revenue |  | (21 | ) |  |  |  |  |
| Interest rate contracts |  | — |  |  | Interest and other, net |  | — |  |  | Interest and other, net |  | $ | — |  |
| Total |  | $ | (141 | ) |  |  |  | $ | (70 | ) |  |  |  | $ | — |  |
| For the three months ended July 29, 2016 |  |  |  |  |  |  |
|  |  |  |  |  | Total net revenue |  | $ | (21 | ) |  |  |  |  |
| Foreign exchange contracts |  | $ | 58 |  |  | Total cost of net revenue |  | (6 | ) |  |  |  |  |
| Interest rate contracts |  | — |  |  | Interest and other, net |  | — |  |  | Interest and other, net |  | $ | — |  |
| Total |  | $ | 58 |  |  |  |  | $ | (27 | ) |  |  |  | $ | — |  |
| For the six months ended August 4, 2017 |  |  |  |  |  |  |
|  |  |  |  |  | Total net revenue |  | $ | (32 | ) |  |  |  |  |
| Foreign exchange contracts |  | $ | (157 | ) |  | Total cost of net revenue |  | (17 | ) |  |  |  |  |
| Interest rate contracts |  | — |  |  | Interest and other, net |  | — |  |  | Interest and other, net |  | $ | — |  |
| Total |  | $ | (157 | ) |  |  |  | $ | (49 | ) |  |  |  | $ | — |  |
| For the six months ended July 29, 2016 |  |  |  |  |  |  |
|  |  |  |  |  | Total net revenue |  | $ | (66 | ) |  |  |  |  |
| Foreign exchange contracts |  | $ | (107 | ) |  | Total cost of net revenue |  | (14 | ) |  |  |  |  |
| Interest rate contracts |  | — |  |  | Interest and other, net |  | — |  |  | Interest and other, net |  | $ | (1 | ) |
| Total |  | $ | (107 | ) |  |  |  | $ | (80 | ) |  |  |  | $ | (1 | ) |

[0001571996-17-000020:notes:127]
[same as prior period, unchanged from 0001571996-17-000009:notes:124]

[0001571996-17-000020:notes:128]
[same as prior period, unchanged from 0001571996-17-000009:notes:125]

[0001571996-17-000020:notes:129]
|  | August 4, 2017 |
|  | Other CurrentAssets |  | Other Non-Current Assets |  | Other CurrentLiabilities |  | Other Non-CurrentLiabilities |  | TotalFair Value |
|  |  |  | (in millions) |  |  |
| Derivatives designated as hedging instruments: |
| Foreign exchange contracts in an asset position | $ | 19 |  |  | $ | — |  |  | $ | 23 |  |  | $ | — |  |  | $ | 42 |  |
| Foreign exchange contracts in a liability position | (23 | ) |  | — |  |  | (57 | ) |  | — |  |  | (80 | ) |
| Net asset (liability) | (4 | ) |  | — |  |  | (34 | ) |  | — |  |  | (38 | ) |
| Derivatives not designated as hedging instruments: |
| Foreign exchange contracts in an asset position | 179 |  |  | 2 |  |  | 68 |  |  | — |  |  | 249 |  |
| Foreign exchange contracts in a liability position | (59 | ) |  | — |  |  | (214 | ) |  | — |  |  | (273 | ) |
| Interest rate contracts in an asset position | — |  |  | 7 |  |  | — |  |  | — |  |  | 7 |  |
| Interest rate contracts in a liability position | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Net asset (liability) | 120 |  |  | 9 |  |  | (146 | ) |  | — |  |  | (17 | ) |
| Total derivatives at fair value | $ | 116 |  |  | $ | 9 |  |  | $ | (180 | ) |  | $ | — |  |  | $ | (55 | ) |
|  | February 3, 2017 |
|  | Other CurrentAssets |  | Other Non-Current Assets |  | Other CurrentLiabilities |  | Other Non-CurrentLiabilities |  | TotalFair Value |
|  |  |  | (in millions) |  |  |
| Derivatives designated as hedging instruments: |
| Foreign exchange contracts in an asset position | $ | 41 |  |  | $ | — |  |  | $ | 17 |  |  | $ | — |  |  | $ | 58 |  |
| Foreign exchange contracts in a liability position | (19 | ) |  | — |  |  | (6 | ) |  | — |  |  | (25 | ) |
| Net asset (liability) | 22 |  |  | — |  |  | 11 |  |  | — |  |  | 33 |  |
| Derivatives not designated as hedging instruments: |
| Foreign exchange contracts in an asset position | 309 |  |  | 2 |  |  | 31 |  |  | — |  |  | 342 |  |
| Foreign exchange contracts in a liability position | (131 | ) |  | — |  |  | (103 | ) |  | — |  |  | (234 | ) |
| Interest rate contracts in an asset position | — |  |  | 3 |  |  | — |  |  | — |  |  | 3 |  |
| Interest rate contracts in a liability position | — |  |  | — |  |  | — |  |  | (3 | ) |  | (3 | ) |
| Net asset (liability) | 178 |  |  | 5 |  |  | (72 | ) |  | (3 | ) |  | 108 |  |
| Total derivatives at fair value | $ | 200 |  |  | $ | 5 |  |  | $ | (61 | ) |  | $ | (3 | ) |  | $ | 141 |  |

[0001571996-17-000020:notes:130]
[same as prior period, unchanged from 0001571996-17-000009:notes:127]

[0001571996-17-000020:notes:131]
|  | August 4, 2017 |
|  | Gross Amounts of Recognized Assets/ (Liabilities) |  | Gross Amounts Offset in the Statement of Financial Position |  | Net Amounts of Assets/ (Liabilities) Presented in the Statement of Financial Position |  | Gross Amounts not Offset in the Statement of Financial Position |  | Net Amount |
|  | Financial Instruments |  | Cash Collateral Received or Pledged |  |
|  | (in millions) |
| Derivative instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Financial assets | $ | 298 |  |  | $ | (173 | ) |  | $ | 125 |  |  | $ | — |  |  | $ | — |  |  | $ | 125 |  |
| Financial liabilities | (353 | ) |  | 173 |  |  | (180 | ) |  | — |  |  | — |  |  | (180 | ) |
| Total derivative instruments | $ | (55 | ) |  | $ | — |  |  | $ | (55 | ) |  | $ | — |  |  | $ | — |  |  | $ | (55 | ) |
|  | February 3, 2017 |
|  | Gross Amounts of Recognized Assets/ (Liabilities) |  | Gross Amounts Offset in the Statement of Financial Position |  | Net Amounts of Assets/ (Liabilities) Presented in the Statement of Financial Position |  | Gross Amounts not Offset in the Statement of Financial Position |  | Net Amount |
|  | Financial Instruments |  | Cash Collateral Received or Pledged |  |
|  | (in millions) |
| Derivative instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Financial assets | $ | 403 |  |  | $ | (198 | ) |  | $ | 205 |  |  | $ | — |  |  | $ | — |  |  | $ | 205 |  |
| Financial liabilities | (262 | ) |  | 198 |  |  | (64 | ) |  | — |  |  | — |  |  | (64 | ) |
| Total derivative instruments | $ | 141 |  |  | $ | — |  |  | $ | 141 |  |  | $ | — |  |  | $ | — |  |  | $ | 141 |  |


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001571996-17-000020:notes:132]
[same as prior period, unchanged from 0001571996-17-000009:notes:129]

[0001571996-17-000020:notes:133]
Dell Inc. ("Dell") entered into a definitive agreement with NTT Data International L.L.C. to divest substantially all of Dell Services, and on November 2, 2016, the parties closed substantially all of the transaction.  Dell Inc. entered into a definitive agreement with Francisco Partners and Elliot Management Corporation to divest substantially all of DSG, and on October 31, 2016, the parties closed the transaction.  EMC, a subsidiary of the Company, entered into a definitive agreement with OpenText Corporation to divest the Dell EMC Enterprise Content Division, and on January 23, 2017, the parties closed the transaction.  Upon closing of the respective transactions, the Company entered into transition services agreements with NTT Data International L.L.C., Francisco Partners and Elliot Management, and OpenText Corporation pursuant to which the Company provides various administrative services on an interim transitional basis.  Transition services may be provided for up to one year, with an option to renew after that period.  The Company also entered into various commercial agreements with NTT Data International L.L.C., Francisco Partners and Elliot Management, and OpenText Corporation that include reseller agreements for certain offerings.

[0001571996-17-000020:notes:134]
In accordance with applicable accounting guidance, the Company reclassified the financial results of Dell Services, DSG, and ECD as discontinued operations in the Condensed Consolidated Statements of Income (Loss) for the relevant periods.  The following table presents key financial results of Dell Services and DSG included in "Income from discontinued operations, net of income taxes" for the three and six months ended July 29, 2016:

[0001571996-17-000020:notes:135]
|  | Three Months Ended July 29, 2016 |  | Six Months Ended July 29, 2016 |
|  | Dell Services (b) |  | DSG |  | Total |  | Dell Services (b) |  | DSG |  | Total |
|  | (in millions) |
| Net revenue | $ | 664 |  |  | $ | 321 |  |  | $ | 985 |  |  | $ | 1,310 |  |  | $ | 642 |  |  | $ | 1,952 |  |
| Cost of net revenue | 513 |  |  | 85 |  |  | 598 |  |  | 1,032 |  |  | 175 |  |  | 1,207 |  |
| Operating expenses | 95 |  |  | 239 |  |  | 334 |  |  | 206 |  |  | 488 |  |  | 694 |  |
| Interest and other, net | — |  |  | (7 | ) |  | (7 | ) |  | — |  |  | 7 |  |  | 7 |  |
| Income (loss) from discontinued operations before income taxes | 56 |  |  | (10 | ) |  | 46 |  |  | 72 |  |  | (14 | ) |  | 58 |  |
| Income tax benefit (a) | (455 | ) |  | (333 | ) |  | (788 | ) |  | (918 | ) |  | (337 | ) |  | (1,255 | ) |
| Income from discontinued operations, net of income taxes | $ | 511 |  |  | $ | 323 |  |  | $ | 834 |  |  | $ | 990 |  |  | $ | 323 |  |  | $ | 1,313 |  |

[0001571996-17-000020:notes:136]
| (a) | The tax benefit for Dell Services and DSG for the three and six months ended July 29, 2016 was primarily due to the Company's determination that it could no longer assert permanent reinvestment in the outside basis of the entities that would be divested. |

[0001571996-17-000020:notes:137]
| (b) | See Note 1 of the Notes to the Condensed Consolidated Financial Statements for additional information on reclassifications from previously reported amounts. |

[0001571996-17-000020:notes:138]
Cash flows from the Company's discontinued operations are included in the accompanying Condensed Consolidated Statements of Cash Flows.  The significant cash flow items from Dell Services and DSG for the six months ended July 29, 2016 were as follows:

[0001571996-17-000020:notes:139]
|  | Six Months Ended July 29, 2016 |
|  | Dell Services |  | DSG |  | Total |
|  | (in millions) |
| Depreciation and amortization (a) | $ | 32 |  |  | $ | 66 |  |  | $ | 98 |  |
| Capital expenditures | $ | 47 |  |  | $ | 15 |  |  | $ | 62 |  |

[0001571996-17-000020:notes:140]
[same as prior period, unchanged from 0001571996-17-000009:notes:137]


## us-gaap:EarningsPerShareTextBlock

[0001571996-17-000020:notes:141]
[same as prior period, unchanged from 0001571996-17-000009:notes:138]

[0001571996-17-000020:notes:142]
[same as prior period, unchanged from 0001571996-17-000009:notes:139]

[0001571996-17-000020:notes:143]
The Company has two groups of common stock, denoted as the DHI Group Common Stock and the Class V Common Stock.  The DHI Group Common Stock consists of four classes of common stock, referred to as Class A Common Stock, Class B Common Stock, Class C Common Stock, and Class D Common Stock.  The DHI Group generally refers to the direct and indirect interest of Dell Technologies in all of Dell Technologies' business, assets, properties, liabilities, and preferred stock other than those attributable to the Class V Group, as well as its retained interest in the Class V Group equal to approximately 38% of the Company's economic interest in the Class V Group as of August 4, 2017.  The Class V Common Stock is intended to track the economic performance of approximately 62% of the Company's economic interest in the Class V Group as of such date.  As of August 4, 2017, the Class V Group consisted solely of approximately 333 million shares of VMware, Inc. common stock held by the Company.  See Note 17 of the Notes to the Condensed Consolidated Financial Statements and Exhibit 99.1 to the Company's quarterly report on Form 10-Q for the quarterly period ended August 4, 2017 for more information regarding the allocation of earnings from Dell Technologies' interest in VMware, Inc. between the DHI Group and the Class V Common Stock.

[0001571996-17-000020:notes:144]
[same as prior period, unchanged from 0001571996-17-000009:notes:141]

[0001571996-17-000020:notes:145]
[same as prior period, unchanged from 0001571996-17-000009:notes:142]

[0001571996-17-000020:notes:146]
|  | Three Months Ended |  | Six Months Ended |
|  | August 4, 2017 |  | July 29, 2016 |  | August 4, 2017 |  | July 29, 2016 |
| Earnings (loss) per share attributable to Dell Technologies Inc. - basic: |  |  |  |  |
| Continuing operations - Class V Common Stock - basic | $ | 0.83 |  |  | $ | — |  |  | $ | 1.40 |  |  | $ | — |  |
| Continuing operations - DHI Group - basic | $ | (1.97 | ) |  | $ | (0.64 | ) |  | $ | (4.53 | ) |  | $ | (1.69 | ) |
| Discontinued operations - DHI Group - basic | $ | — |  |  | $ | 2.06 |  |  | $ | — |  |  | $ | 3.24 |  |
| Earnings (loss) per share attributable to Dell Technologies Inc. - diluted: |  |  |  |  |
| Continuing operations - Class V Common Stock - diluted | $ | 0.82 |  |  | $ | — |  |  | $ | 1.38 |  |  | $ | — |  |
| Continuing operations - DHI Group - diluted | $ | (1.97 | ) |  | $ | (0.64 | ) |  | $ | (4.54 | ) |  | $ | (1.69 | ) |
| Discontinued operations - DHI Group - diluted | $ | — |  |  | $ | 2.06 |  |  | $ | — |  |  | $ | 3.24 |  |

[0001571996-17-000020:notes:147]
[same as prior period, unchanged from 0001571996-17-000009:notes:144]

[0001571996-17-000020:notes:148]
|  | Three Months Ended |  | Six Months Ended |
|  | August 4, 2017 |  | July 29, 2016 |  | August 4, 2017 |  | July 29, 2016 |
|  | (in millions) |
| Numerator: Continuing operations - Class V Common Stock |  |  |  |  |  |  |  |
| Net income from continuing operations attributable to Class V Common Stock - basic | $ | 168 |  |  | $ | — |  |  | $ | 286 |  |  | $ | — |  |
| Incremental dilution from VMware, Inc. attributable to Class V Common Stock (a) | (2 | ) |  | — |  |  | (4 | ) |  | — |  |
| Net income from continuing operations attributable to Class V Common Stock - diluted | $ | 166 |  |  | $ | — |  |  | $ | 282 |  |  | $ | — |  |
| Numerator: Continuing operations - DHI Group |  |  |  |  |  |  |  |
| Net loss from continuing operations attributable to DHI Group - basic | $ | (1,114 | ) |  | $ | (261 | ) |  | $ | (2,566 | ) |  | $ | (685 | ) |
| Incremental dilution from VMware, Inc. attributable to DHI Group (a) | (1 | ) |  | — |  |  | (2 | ) |  | — |  |
| Net loss from continuing operations attributable to DHI Group - diluted | $ | (1,115 | ) |  | $ | (261 | ) |  | $ | (2,568 | ) |  | $ | (685 | ) |
| Numerator: Discontinued operations - DHI Group |  |  |  |  |  |  |  |
| Income from discontinued operations, net of income taxes - basic and diluted | $ | — |  |  | $ | 834 |  |  | $ | — |  |  | $ | 1,313 |  |
| Denominator: Class V Common Stock weighted-average shares outstanding |  |  |  |  |  |  |  |  |  |  |  |
| Weighted-average shares outstanding - basic | 203 |  |  | — |  |  | 205 |  |  | — |  |
| Dilutive effect of options, restricted stock units, restricted stock, and other (b) | — |  |  | — |  |  | — |  |  | — |  |
| Weighted-average shares outstanding - diluted | 203 |  |  | — |  |  | 205 |  |  | — |  |
| Weighted-average shares outstanding - antidilutive (b) | — |  |  | — |  |  | — |  |  | — |  |
| Denominator: DHI Group weighted-average shares outstanding |  |  |  |  |  |  |  |
| Weighted-average shares outstanding - basic | 566 |  |  | 405 |  |  | 566 |  |  | 405 |  |
| Dilutive effect of options, restricted stock units, restricted stock, and other | — |  |  | — |  |  | — |  |  | — |  |
| Weighted-average shares outstanding - diluted | 566 |  |  | 405 |  |  | 566 |  |  | 405 |  |
| Weighted-average shares outstanding - antidilutive (c) | 36 |  |  | 53 |  |  | 37 |  |  | 54 |  |

[0001571996-17-000020:notes:149]
[same as prior period, unchanged from 0001571996-17-000009:notes:146]

[0001571996-17-000020:notes:150]
[same as prior period, unchanged from 0001571996-17-000009:notes:147]

[0001571996-17-000020:notes:151]
[same as prior period, unchanged from 0001571996-17-000009:notes:148]


## us-gaap:FairValueDisclosuresTextBlock

[0001571996-17-000020:notes:152]
[same as prior period, unchanged from 0001571996-17-000009:notes:149]

[0001571996-17-000020:notes:153]
The following table presents the Company's hierarchy for its assets and liabilities measured at fair value on a recurring basis as of August 4, 2017 and February 3, 2017:

[0001571996-17-000020:notes:154]
|  | August 4, 2017 (a) |  | February 3, 2017 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | QuotedPricesin ActiveMarkets forIdenticalAssets |  | SignificantOtherObservableInputs |  | SignificantUnobservableInputs |  |  |  | QuotedPricesin ActiveMarkets forIdenticalAssets |  | SignificantOtherObservableInputs |  | SignificantUnobservableInputs |  |  |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 4,853 |  |  | $ | — |  |  | $ | — |  |  | $ | 4,853 |  |  | $ | 4,866 |  |  | $ | — |  |  | $ | — |  |  | $ | 4,866 |  |
| Municipal obligations | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 3 |  |  | — |  |  | 3 |  |
| U.S. and foreign corporate debt securities | — |  |  | 183 |  |  | — |  |  | 183 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| U.S. government and agencies | — |  |  | 45 |  |  | — |  |  | 45 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Foreign government and agencies | — |  |  | 3 |  |  | — |  |  | 3 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Debt securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government and agencies | 658 |  |  | 412 |  |  | — |  |  | 1,070 |  |  | 444 |  |  | 470 |  |  | — |  |  | 914 |  |
| U.S. corporate | — |  |  | 1,893 |  |  | — |  |  | 1,893 |  |  | — |  |  | 1,800 |  |  | — |  |  | 1,800 |  |
| Foreign | — |  |  | 2,332 |  |  | — |  |  | 2,332 |  |  | — |  |  | 2,083 |  |  | — |  |  | 2,083 |  |
| Municipal obligations | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 352 |  |  | — |  |  | 352 |  |
| Asset-backed securities | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 4 |  |  | — |  |  | 4 |  |
| Equity and other securities | 224 |  |  | 2 |  |  | — |  |  | 226 |  |  | 169 |  |  | — |  |  | — |  |  | 169 |  |
| Derivative instruments | — |  |  | 125 |  |  | — |  |  | 125 |  |  | — |  |  | 205 |  |  | — |  |  | 205 |  |
| Total assets | $ | 5,735 |  |  | $ | 4,995 |  |  | $ | — |  |  | $ | 10,730 |  |  | $ | 5,479 |  |  | $ | 4,917 |  |  | $ | — |  |  | $ | 10,396 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative instruments | $ | — |  |  | $ | 180 |  |  | $ | — |  |  | $ | 180 |  |  | $ | — |  |  | $ | 64 |  |  | $ | — |  |  | $ | 64 |  |
| Total liabilities | $ | — |  |  | $ | 180 |  |  | $ | — |  |  | $ | 180 |  |  | $ | — |  |  | $ | 64 |  |  | $ | — |  |  | $ | 64 |  |

[0001571996-17-000020:notes:155]
(a)   The Company did not transfer any securities between levels during the six months ended August 4, 2017.

[0001571996-17-000020:notes:156]
[same as prior period, unchanged from 0001571996-17-000009:notes:153]

[0001571996-17-000020:notes:157]
Money Market Funds — The Company's investment in money market funds that are classified as cash equivalents hold underlying investments with a weighted average maturity of 90 days or less and are recognized at fair value.  The valuations of these securities are based on quoted prices in active markets for identical assets, when available, or pricing models whereby all significant inputs are observable or can be derived from or corroborated by observable market data.  The Company reviews security pricing and assesses liquidity on a quarterly basis.  As of August 4, 2017, the Company's U.S. portfolio had no material exposure to money market funds with a fluctuating net asset value.

[0001571996-17-000020:notes:158]
[same as prior period, unchanged from 0001571996-17-000009:notes:157]

[0001571996-17-000020:notes:159]
[same as prior period, unchanged from 0001571996-17-000009:notes:156]

[0001571996-17-000020:notes:160]
[same as prior period, unchanged from 0001571996-17-000009:notes:158]

[0001571996-17-000020:notes:161]
[same as prior period, unchanged from 0001571996-17-000009:notes:159]

[0001571996-17-000020:notes:162]
As of August 4, 2017 and February 3, 2017, the Company held strategic investments of $516 million and $455 million, respectively.  These investments are accounted for under the cost method and are not included in the recurring fair value table above.  Investments accounted for under the cost method are recorded at cost initially, which approximates fair value.  Subsequently, if there is an indicator of impairment, the impairment is recognized.  In evaluating these investments for impairment, the Company uses inputs including pre- and post-money valuations of recent financing events and the impact of those on its fully diluted ownership percentages, as well as other available information regarding the issuer's historical and forecasted performance.  As these investments are early-stage companies which are not publicly traded, it is not practicable for the Company to reliably estimate the fair value of these investments.

[0001571996-17-000020:notes:163]
[same as prior period, unchanged from 0001571996-17-000009:notes:161]

[0001571996-17-000020:notes:164]
|  | August 4, 2017 |  | February 3, 2017 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Secured Credit Facilities | $ | 10.9 |  |  | $ | 11.2 |  |  | $ | 11.4 |  |  | $ | 11.7 |  |
| First Lien Notes | $ | 19.7 |  |  | $ | 22.3 |  |  | $ | 19.7 |  |  | $ | 21.8 |  |
| Unsecured Notes and Debentures | $ | 2.3 |  |  | $ | 2.5 |  |  | $ | 2.3 |  |  | $ | 2.5 |  |
| Senior Notes | $ | 3.1 |  |  | $ | 3.5 |  |  | $ | 3.1 |  |  | $ | 3.5 |  |
| EMC Notes | $ | 5.5 |  |  | $ | 5.3 |  |  | $ | 5.5 |  |  | $ | 5.4 |  |
| Margin Loan Facility | $ | 2.0 |  |  | $ | 2.0 |  |  | $ | — |  |  | $ | — |  |
| Bridge Facilities | $ | 1.5 |  |  | $ | 1.5 |  |  | $ | 4.0 |  |  | $ | 4.0 |  |

[0001571996-17-000020:notes:165]
[same as prior period, unchanged from 0001571996-17-000009:notes:163]


## us-gaap:FinancingReceivableCreditQualityIndicatorsTableTextBlock

[0001571996-17-000020:notes:166]
The following table summarizes customer receivables, gross, including accrued interest, by credit quality indicator segregated by class, as of August 4, 2017 and February 3, 2017.  The categories shown in the table below segregate customer receivables based on the relative degrees of credit risk.  The credit quality indicators for DPA revolving accounts are measured primarily as of each quarter-end date, while all other indicators are generally updated on a periodic basis.

[0001571996-17-000020:notes:167]
[same as prior period, unchanged from 0001571996-17-000009:notes:165]

[0001571996-17-000020:notes:168]
|  | August 4, 2017 |  | February 3, 2017 |
|  | Higher |  | Mid |  | Lower |  | Total |  | Higher |  | Mid |  | Lower |  | Total |
|  | (in millions) |
| Revolving — DPA | $ | 132 |  |  | $ | 220 |  |  | $ | 368 |  |  | $ | 720 |  |  | $ | 136 |  |  | $ | 244 |  |  | $ | 428 |  |  | $ | 808 |  |
| Revolving — DBC | $ | 46 |  |  | $ | 56 |  |  | $ | 77 |  |  | $ | 179 |  |  | $ | 61 |  |  | $ | 60 |  |  | $ | 80 |  |  | $ | 201 |  |
| Fixed-term — Consumer and Commercial (a) | $ | 2,770 |  |  | $ | 1,668 |  |  | $ | 947 |  |  | $ | 5,385 |  |  | $ | 2,232 |  |  | $ | 1,428 |  |  | $ | 870 |  |  | $ | 4,530 |  |

[0001571996-17-000020:notes:169]
| (a) | During the three months ended May 5, 2017, the Company modified its credit scoring methodology for fixed-term financing receivables in response to changes in its go-to-market strategy. This methodology has been modified to a single, consistent, and comparable model across all fixed-term product customers. In connection with this change, the Company has recategorized existing fixed-term customers and has recast prior period credit quality categories to align with the current period presentation. |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001571996-17-000020:notes:170]
[same as prior period, unchanged from 0001571996-17-000009:notes:168]

[0001571996-17-000020:notes:171]
[same as prior period, unchanged from 0001571996-17-000009:notes:169]

[0001571996-17-000020:notes:172]
The following table presents goodwill allocated to the Company's business segments as of August 4, 2017 and February 3, 2017, and changes in the carrying amount of goodwill for the respective periods:

[0001571996-17-000020:notes:173]
|  | Client Solutions Group |  | Infrastructure Solutions Group |  | VMware |  | Other Businesses (a) |  | Total |
|  | (in millions) |
| Balances as of February 3, 2017 | $ | 4,237 |  |  | $ | 15,607 |  |  | $ | 15,070 |  |  | $ | 3,996 |  |  | $ | 38,910 |  |
| Goodwill acquired during the period | — |  |  | — |  |  | 238 |  |  | 9 |  |  | 247 |  |
| Goodwill divested | — |  |  | (13 | ) |  | — |  |  | — |  |  | (13 | ) |
| Impact of foreign currency translation | — |  |  | 220 |  |  | — |  |  | 43 |  |  | 263 |  |
| Balances as of August 4, 2017 | $ | 4,237 |  |  | $ | 15,814 |  |  | $ | 15,308 |  |  | $ | 4,048 |  |  | $ | 39,407 |  |

[0001571996-17-000020:notes:174]
| (a) | Other Businesses consists of offerings by RSA Information Security, SecureWorks, Pivotal, and Boomi. |

[0001571996-17-000020:notes:175]
Goodwill and indefinite-lived intangible assets are tested for impairment annually during the third fiscal quarter and whenever events or circumstances may indicate that an impairment has occurred.  Based on the results of the annual impairment test, which was a qualitative test, no impairment of goodwill or indefinite-lived intangible assets existed for any reporting unit as of October 28, 2016.  No events or circumstances transpired subsequent to the annual impairment test that would indicate a potential impairment of goodwill as of August 4, 2017.  Further, the Company did not have any accumulated goodwill impairment charges as of August 4, 2017.

[0001571996-17-000020:notes:176]
Management exercised significant judgment related to the above assessment, including the identification of goodwill reporting units, assignment of assets and liabilities to goodwill reporting units, assignment of goodwill to reporting units, and determination of the fair value of each goodwill reporting unit.  The fair value of each goodwill reporting unit is generally estimated using a discounted cash flow methodology.  This analysis requires significant judgment, including estimation of future cash flows, which is dependent on internal forecasts, the estimation of the long-term growth rate of the Company's business, and the determination of the Company's weighted average cost of capital.  Changes in these estimates and assumptions could materially affect the fair value of the goodwill reporting unit, potentially resulting in a non-cash impairment charge.

[0001571996-17-000020:notes:177]
[same as prior period, unchanged from 0001571996-17-000009:notes:175]

[0001571996-17-000020:notes:178]
The Company's intangible assets as of August 4, 2017 and February 3, 2017 were as follows:

[0001571996-17-000020:notes:179]
|  | August 4, 2017 |  | February 3, 2017 |
|  | Gross |  | AccumulatedAmortization |  | Net |  | Gross |  | AccumulatedAmortization |  | Net |
|  | (in millions) |
| Customer relationships | $ | 22,715 |  |  | $ | (7,095 | ) |  | $ | 15,620 |  |  | $ | 22,708 |  |  | $ | (5,552 | ) |  | $ | 17,156 |  |
| Developed technology | 15,494 |  |  | (4,375 | ) |  | 11,119 |  |  | 14,569 |  |  | (2,510 | ) |  | 12,059 |  |
| Trade names | 1,270 |  |  | (308 | ) |  | 962 |  |  | 1,268 |  |  | (201 | ) |  | 1,067 |  |
| Leasehold assets (liabilities) | 128 |  |  | (4 | ) |  | 124 |  |  | 128 |  |  | (1 | ) |  | 127 |  |
| Definite-lived intangible assets | 39,607 |  |  | (11,782 | ) |  | 27,825 |  |  | 38,673 |  |  | (8,264 | ) |  | 30,409 |  |
| In-process research and development | — |  |  | — |  |  | — |  |  | 890 |  |  | — |  |  | 890 |  |
| Indefinite-lived trade names | 3,755 |  |  | — |  |  | 3,755 |  |  | 3,754 |  |  | — |  |  | 3,754 |  |
| Total intangible assets | $ | 43,362 |  |  | $ | (11,782 | ) |  | $ | 31,580 |  |  | $ | 43,317 |  |  | $ | (8,264 | ) |  | $ | 35,053 |  |

[0001571996-17-000020:notes:180]
Amortization expense related to definite-lived intangible assets was approximately $1,740 million and $491 million during the three months ended August 4, 2017 and July 29, 2016, respectively, and $3,516 million and $982 million during the six months ended August 4, 2017 and July 29, 2016, respectively.  There were no material impairment charges related to intangible assets during the three and six months ended August 4, 2017 and July 29, 2016.

[0001571996-17-000020:notes:181]
Estimated future annual pre-tax amortization expense of definite-lived intangible assets as of August 4, 2017 over the next five fiscal years and thereafter is as follows:

[0001571996-17-000020:notes:182]
| Fiscal Years | (in millions) |
| 2018 (remaining six months) | $ | 3,463 |  |
| 2019 | 6,059 |  |
| 2020 | 4,274 |  |
| 2021 | 3,333 |  |
| 2022 | 2,616 |  |
| Thereafter | 8,080 |  |
| Total | $ | 27,825 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001571996-17-000020:notes:183]
[same as prior period, unchanged from 0001571996-17-000009:notes:181]

[0001571996-17-000020:notes:184]
For the three and six months ended August 4, 2017, the Company's effective income tax rates for continuing operations were 35.8% and 34.4%, respectively, on pre-tax losses from continuing operations of $1,524 million and $3,597 million, respectively.  For the three and six months ended July 29, 2016, the Company's effective income tax rates for continuing operations were 7.1% and (7.2)%, respectively, on pre-tax losses from continuing operations of $282 million and $640 million, respectively.  The change in the Company's effective income tax rate was primarily attributable to prior year tax charges recognized during the three and six months ended July 29, 2016 related to the divestiture of Dell Services and DSG, as well as tax benefits from charges associated with the EMC merger transaction incurred during the six months ended August 4, 2017, including purchase accounting adjustments, interest charges, and stock-based compensation expense.  For more information regarding the EMC merger transaction, see Note 2 of the Notes to the Condensed Consolidated Financial Statements.  The income tax rate for future quarters of Fiscal 2018 will be impacted by the actual mix of jurisdictions in which income is generated.

[0001571996-17-000020:notes:185]
[same as prior period, unchanged from 0001571996-17-000009:notes:183]

[0001571996-17-000020:notes:186]
The Company's U.S. federal income tax returns for fiscal years 2007 through 2009 are currently under consideration by the Office of Appeals of the Internal Revenue Service (the "IRS").  The IRS issued a Revenue Agent's Report ("RAR") related to those years during the fiscal year ended February 3, 2017.  The IRS has proposed adjustments primarily relating to transfer pricing matters with which the Company disagrees and will contest through the IRS administrative appeals procedures.  In May 2017, the IRS commenced a federal income tax audit for fiscal years 2010 through 2014, which could take several years to complete.  Prior to the EMC merger transaction, EMC received a RAR for its tax years 2009 and 2010, and during the three months ended May 5, 2017, EMC received an RAR for its tax year 2011.  The Company also disagrees with certain proposed adjustments in these RARs and is currently contesting the proposed adjustments through the IRS administrative appeals process.

[0001571996-17-000020:notes:187]
[same as prior period, unchanged from 0001571996-17-000009:notes:185]

[0001571996-17-000020:notes:188]
Judgment is required in evaluating the Company's uncertain tax positions and determining the Company's provision for income taxes.  The Company's net unrecognized tax benefits were $3.2 billion and $3.1 billion as of August 4, 2017 and February 3, 2017, respectively, and are included in other non-current liabilities in the Condensed Consolidated Statements of Financial Position.  The Company does not anticipate a significant change to the total amount of unrecognized tax benefits within the next twelve months.

[0001571996-17-000020:notes:189]
The Company takes certain non-income tax positions in the jurisdictions in which it operates and has received certain non-income tax assessments from various jurisdictions.  The Company believes that a material loss in these matters is not probable and that it is not reasonably possible that a material loss exceeding amounts already accrued has been incurred.  The Company believes its positions in these non-income tax litigation matters are supportable and that it ultimately will prevail in the matters.  In the normal course of business, the Company's positions and conclusions related to its non-income taxes could be challenged and assessments may be made.  To the extent new information is obtained and the Company's views on its positions, probable outcomes of assessments, or litigation change, changes in estimates to the Company's accrued liabilities would be recorded in the period in which such a determination is made.  In the resolution process for income tax and non-income tax audits, the Company may be required to provide collateral guarantees or indemnification to regulators and tax authorities until the matter is resolved.


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0001571996-17-000020:notes:190]
[same as prior period, unchanged from 0001571996-17-000009:notes:188]

[0001571996-17-000020:notes:191]
The Company offers or arranges various financing options and services for its business and consumer customers in North America, Europe, Australia, and New Zealand through Dell Financial Services and its affiliates (collectively, "DFS").  The key activities of DFS include the origination, collection, and servicing of customer receivables primarily related to the purchase of Dell Technologies' products and services.  New financing originations, which represent the amounts of financing provided by DFS to customers for equipment and related software and services, including third-party originations, were $1.6 billion and $1.0 billion for three months ended August 4, 2017 and July 29, 2016, respectively, and $2.7 billion and $1.9 billion for the six months ended August 4, 2017 and July 29, 2016, respectively.

[0001571996-17-000020:notes:192]
In June 2017, as part of the global expansion of Dell Technologies' captive financing model, the Company purchased a portfolio of customer fixed-term financing receivables totaling approximately $89 million from Bank of Queensland.  Bank of Queensland was previously the Company's preferred financing partner in Australia and New Zealand.

[0001571996-17-000020:notes:193]
[same as prior period, unchanged from 0001571996-17-000009:notes:190]

[0001571996-17-000020:notes:194]
| • | Revolving loans — Revolving loans offered under private label credit financing programs provide qualified customers with a revolving credit line for the purchase of products and services offered by Dell Technologies. These private label credit financing programs are referred to as Dell Preferred Account ("DPA") and Dell Business Credit ("DBC"). The DPA product is primarily offered to individual consumer customers, and the DBC product is primarily offered to small and medium-sized commercial customers. Revolving loans in the United States bear interest at a variable annual percentage rate that is tied to the prime rate. Based on historical payment patterns, revolving loan transactions are typically repaid within twelve months on average. |

[0001571996-17-000020:notes:195]
| • | Fixed-term sales-type leases and loans — The Company enters into sales-type lease arrangements with customers who seek lease financing. Leases with business customers have fixed terms of generally two to four years. Future maturities of minimum lease payments as of August 4, 2017 were as follows: Fiscal 2018 (remaining six months) - $1,121 million; Fiscal 2019 - $1,552 million; Fiscal 2020 - $949 million; Fiscal 2021 - $354 million; Fiscal 2022 and beyond - $96 million. The Company also offers fixed-term loans to qualified small businesses, large commercial accounts, governmental organizations, educational entities, and certain individual consumer customers. These loans are repaid in equal payments including interest and have defined terms of generally three to five years. |

[0001571996-17-000020:notes:196]
The following table summarizes the components of the Company's financing receivables segregated by portfolio segment as of August 4, 2017 and February 3, 2017:

[0001571996-17-000020:notes:197]
|  | August 4, 2017 |  | February 3, 2017 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Financing receivables, net: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer receivables, gross | $ | 899 |  |  | $ | 5,385 |  |  | $ | 6,284 |  |  | $ | 1,009 |  |  | $ | 4,530 |  |  | $ | 5,539 |  |
| Allowances for losses | (81 | ) |  | (54 | ) |  | (135 | ) |  | (91 | ) |  | (52 | ) |  | (143 | ) |
| Customer receivables, net | 818 |  |  | 5,331 |  |  | 6,149 |  |  | 918 |  |  | 4,478 |  |  | 5,396 |  |
| Residual interest | — |  |  | 523 |  |  | 523 |  |  | — |  |  | 477 |  |  | 477 |  |
| Financing receivables, net | $ | 818 |  |  | $ | 5,854 |  |  | $ | 6,672 |  |  | $ | 918 |  |  | $ | 4,955 |  |  | $ | 5,873 |  |
| Short-term | $ | 818 |  |  | $ | 2,655 |  |  | $ | 3,473 |  |  | $ | 918 |  |  | $ | 2,304 |  |  | $ | 3,222 |  |
| Long-term | $ | — |  |  | $ | 3,199 |  |  | $ | 3,199 |  |  | $ | — |  |  | $ | 2,651 |  |  | $ | 2,651 |  |

[0001571996-17-000020:notes:198]
The following table summarizes the aging of the Company's customer financing receivables, gross, including accrued interest, as of August 4, 2017 and February 3, 2017, segregated by class:

[0001571996-17-000020:notes:199]
|  | August 4, 2017 |  | February 3, 2017 |
|  | Current |  | Past Due 1 — 90 Days |  | Past Due > 90 Days |  | Total |  | Current |  | Past Due 1 — 90 Days |  | Past Due > 90 Days |  | Total |
|  | (in millions) |
| Revolving — DPA | $ | 639 |  |  | $ | 58 |  |  | $ | 23 |  |  | $ | 720 |  |  | $ | 715 |  |  | $ | 66 |  |  | $ | 27 |  |  | $ | 808 |  |
| Revolving — DBC | 154 |  |  | 20 |  |  | 5 |  |  | 179 |  |  | 175 |  |  | 22 |  |  | 4 |  |  | 201 |  |
| Fixed-term — Consumer and Commercial | 4,539 |  |  | 787 |  |  | 59 |  |  | 5,385 |  |  | 3,994 |  |  | 506 |  |  | 30 |  |  | 4,530 |  |
| Total customer receivables, gross | $ | 5,332 |  |  | $ | 865 |  |  | $ | 87 |  |  | $ | 6,284 |  |  | $ | 4,884 |  |  | $ | 594 |  |  | $ | 61 |  |  | $ | 5,539 |  |

[0001571996-17-000020:notes:200]
[same as prior period, unchanged from 0001571996-17-000009:notes:197]

[0001571996-17-000020:notes:201]
[same as prior period, unchanged from 0001571996-17-000009:notes:198]

[0001571996-17-000020:notes:202]
The Company maintains programs which facilitate the funding of financing receivables in the capital markets in the United States, Canada, and Europe.  The Company's total structured financing debt, which is collateralized by financing receivables, was $4.1 billion and $3.5 billion as of August 4, 2017 and February 3, 2017, respectively, under the following programs:

[0001571996-17-000020:notes:203]
| • | Securitization Programs — The Company maintains securitization programs in the United States and Europe. The securitization programs in the United States include the fixed-term lease and loan securitization program and the revolving loan securitization program. The outstanding balance of debt under these U.S. programs was $1.4 billion and $1.5 billion as of August 4, 2017 and February 3, 2017, respectively. This debt is collateralized solely by the U.S. financing receivables in the programs. The debt has a variable interest rate and the duration of this debt is based on the terms of the underlying financing receivables. As of August 4, 2017, the total debt capacity related to the U.S. securitization programs was $2.1 billion. The Company enters into interest swap agreements to effectively convert the portion of its structured financing debt from a floating rate to a fixed rate. See Note 8 of the Notes to the Condensed Consolidated Financial Statements for additional information about interest rate swaps. |

[0001571996-17-000020:notes:204]
The Company's U.S. securitization programs became effective on October 29, 2013.  The revolving program, which was extended during the third quarter of Fiscal 2017, is effective for four and one-half years beginning October 29, 2013.  The fixed-term program, which was extended during the second quarter of Fiscal 2018, is effective for four and one-half years beginning October 29, 2013.

[0001571996-17-000020:notes:205]
The Company established a securitization program in Europe for fixed-term leases and loans.  This program became effective on January 13, 2017, and is effective for two years.  The outstanding balance of debt under this program was $373 million as of August 4, 2017, and the total debt capacity related to the securitization program was $712 million.

[0001571996-17-000020:notes:206]
The securitization programs contain standard structural features related to the performance of the securitized receivables which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the program, no further funding of receivables will be permitted and the timing of the Company's expected cash flows from over-collateralization will be delayed.  As of August 4, 2017, these criteria were met.

[0001571996-17-000020:notes:207]
| • | Fixed-Term Securitization Programs — The Company periodically issues asset-backed debt securities under fixed-term securitization programs to private investors. As of August 4, 2017 and February 3, 2017, the associated debt balance of these securities was $1.8 billion and $1.4 billion, respectively. The asset-backed debt securities are collateralized solely by the U.S. fixed-term financing receivables in the offerings, which are held by SPEs, as discussed below. The interest rate on these securities is fixed and ranges from 0.42% to 3.61%, and the duration of these securities is based on the terms of the underlying financing receivables. |

[0001571996-17-000020:notes:208]
| • | Other Structured Financing Programs — In connection with the Company's international financing operations, the Company has entered into revolving structured financing debt programs related to its fixed-term lease and loan products sold in Canada and Europe. The aggregate outstanding balances of the Canadian and European revolving structured loans as of August 4, 2017 and February 3, 2017 were $446 million and $382 million, respectively. As of August 4, 2017, the Canadian program, which was extended during the fiscal year ended February 3, 2017, had a total debt capacity of $175 million. This program is effective for two years, beginning on April 15, 2016, and is collateralized solely by the Canadian financing receivables. The European program, which was extended during the first quarter of Fiscal 2016, is now effective for four years, beginning on December 23, 2013. The program is collateralized solely by the European financing receivables and had a total debt capacity of $356 million as of August 4, 2017. |

[0001571996-17-000020:notes:209]
[same as prior period, unchanged from 0001571996-17-000009:notes:206]

[0001571996-17-000020:notes:210]
[same as prior period, unchanged from 0001571996-17-000009:notes:207]

[0001571996-17-000020:notes:211]
[same as prior period, unchanged from 0001571996-17-000009:notes:208]

[0001571996-17-000020:notes:212]
|  | August 4, 2017 |  | February 3, 2017 |
|  | (in millions) |
| Financing receivables held by consolidated VIEs, net: |  |  |  |  |  |
| Short-term, net | $ | 2,440 |  |  | $ | 2,227 |  |
| Long-term, net | 1,790 |  |  | 1,381 |  |
| Financing receivables held by consolidated VIEs, net | $ | 4,230 |  |  | $ | 3,608 |  |

[0001571996-17-000020:notes:213]
Financing receivables transferred via securitization through SPEs were $1.0 billion and $0.8 billion for the three months ended August 4, 2017 and July 29, 2016, respectively, and $1.9 billion and $1.4 billion for the six months ended August 4, 2017 and July 29, 2016, respectively.

[0001571996-17-000020:notes:214]
Some of the SPEs have entered into financing arrangements with multi-seller conduits that, in turn, issue asset-backed debt securities in the capital markets.  The structured financing debt outstanding, which is collateralized by the financing receivables held by the consolidated VIEs, was $3.6 billion and $3.1 billion as of August 4, 2017 and February 3, 2017, respectively.  The Company's risk of loss related to securitized receivables is limited to the amount by which the Company's right to receive collections for assets securitized exceeds the amount required to pay interest, principal, and fees and expenses related to the asset-backed securities.  The Company provides credit enhancement to the securitization in the form of over-collateralization.

[0001571996-17-000020:notes:215]
[same as prior period, unchanged from 0001571996-17-000009:notes:212]

[0001571996-17-000020:notes:216]
To manage certain concentrations of customer credit exposure, the Company may sell selected fixed-term financing receivables to unrelated third parties on a periodic basis.  The amount of financing receivables sold was $228 million and $98 million for the six months ended August 4, 2017 and July 29, 2016, respectively.


## us-gaap:MinorityInterestDisclosureTextBlock

[0001571996-17-000020:notes:217]
[same as prior period, unchanged from 0001571996-17-000009:notes:214]

[0001571996-17-000020:notes:218]
VMware, Inc. — The non-controlling interests' share of equity in VMware, Inc. is reflected as a component of the non-controlling interests in the accompanying Condensed Consolidated Statements of Financial Position and was $5.4 billion and $5.2 billion as of August 4, 2017 and February 3, 2017, respectively.  As of August 4, 2017 and February 3, 2017, the Company held approximately 81.4% and 82.5%, respectively, of the outstanding equity interest in VMware, Inc.

[0001571996-17-000020:notes:219]
SecureWorks — On April 27, 2016, SecureWorks completed a registered underwritten IPO of its Class A common stock.  The non-controlling interests' share of equity in SecureWorks is reflected as a component of the non-controlling interests in the accompanying Condensed Consolidated Statements of Financial Position and was $87 million and $86 million as of August 4, 2017 and February 3, 2017, respectively.  As of August 4, 2017 and February 3, 2017, the Company held approximately 87.1% and 87.5%, respectively, of the outstanding equity interest in SecureWorks.

[0001571996-17-000020:notes:220]
Pivotal — A portion of the non-controlling interests in Pivotal is held by third parties in the form of preferred equity instruments.  Due to the terms of such instruments, Pivotal's results of operations and equity activity are not attributable to such interests in Pivotal in the Condensed Consolidated Statements of Income (Loss) and Condensed Consolidated Statements of Financial Position.  The preferred equity instruments are convertible into common shares at the non-controlling owner's election at any time.  The remaining portion of the non-controlling interests in Pivotal is held by third parties in the form of common stock.  Pivotal's results of operations and equity activity are attributable to such interests in Pivotal in the Condensed Consolidated Statements of Income (Loss) and Condensed Consolidated Statements of Financial Position.  The non-controlling interests' share of equity in Pivotal, including both preferred equity instruments and common stock, is reflected as a component of the non-controlling interests in the accompanying Condensed Consolidated Statements of Financial Position and was $477 million and $472 million as of August 4, 2017 and February 3, 2017, respectively.  As of August 4, 2017 and February 3, 2017, the Company held approximately 77.4% and 77.8%, respectively, of the outstanding equity interest in Pivotal.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001571996-17-000020:notes:221]
[same as prior period, unchanged from 0001571996-17-000009:notes:218]

[0001571996-17-000020:notes:222]
[same as prior period, unchanged from 0001571996-17-000009:notes:219]

[0001571996-17-000020:notes:223]
[same as prior period, unchanged from 0001571996-17-000009:notes:220]

[0001571996-17-000020:notes:224]
|  | Three Months Ended |  | Six Months Ended |
|  | August 4, 2017 |  | July 29, 2016 |  | August 4, 2017 |  | July 29, 2016 |
|  | (in millions) |
| Warranty liability: |  |  |  |  |  |  |  |
| Warranty liability at beginning of period | $ | 607 |  |  | $ | 561 |  |  | $ | 604 |  |  | $ | 574 |  |
| Costs accrued for new warranty contracts and changes in estimates for pre-existing warranties (a) (b) | 223 |  |  | 182 |  |  | 463 |  |  | 382 |  |
| Service obligations honored | (242 | ) |  | (178 | ) |  | (479 | ) |  | (391 | ) |
| Warranty liability at end of period | $ | 588 |  |  | $ | 565 |  |  | $ | 588 |  |  | $ | 565 |  |
| Current portion | $ | 412 |  |  | $ | 385 |  |  | $ | 412 |  |  | $ | 385 |  |
| Non-current portion | $ | 176 |  |  | $ | 180 |  |  | $ | 176 |  |  | $ | 180 |  |

[0001571996-17-000020:notes:225]
[same as prior period, unchanged from 0001571996-17-000009:notes:222]

[0001571996-17-000020:notes:226]
[same as prior period, unchanged from 0001571996-17-000009:notes:223]


## us-gaap:ReconciliationOfRevenueFromSegmentsToConsolidatedTextBlock

[0001571996-17-000020:notes:227]
[same as prior period, unchanged from 0001571996-17-000009:notes:224]

[0001571996-17-000020:notes:228]
|  | Three Months Ended |  | Six Months Ended |
|  | August 4, 2017 |  | July 29, 2016 |  | August 4, 2017 |  | July 29, 2016 |
|  | (in millions) |
| Consolidated net revenue: |  |  |  |  |  |  |  |  |
| Client Solutions Group | $ | 9,851 |  |  | $ | 9,220 |  |  | $ | 18,907 |  |  | $ | 17,791 |  |
| Infrastructure Solutions Group | 7,406 |  |  | 3,779 |  |  | 14,322 |  |  | 7,392 |  |
| VMware | 1,907 |  |  | — |  |  | 3,643 |  |  | — |  |
| Reportable segment net revenue | 19,164 |  |  | 12,999 |  |  | 36,872 |  |  | 25,183 |  |
| Other businesses (a) | 472 |  |  | 118 |  |  | 934 |  |  | 228 |  |
| Unallocated transactions (b) | (2 | ) |  | 28 |  |  | (1 | ) |  | 53 |  |
| Impact of purchase accounting (c) | (335 | ) |  | (65 | ) |  | (690 | ) |  | (143 | ) |
| Total net revenue | $ | 19,299 |  |  | $ | 13,080 |  |  | $ | 37,115 |  |  | $ | 25,321 |  |
| Consolidated operating income (loss): |  |  |  |  |  |  |  |
| Client Solutions Group | $ | 566 |  |  | $ | 484 |  |  | $ | 940 |  |  | $ | 869 |  |
| Infrastructure Solutions Group | 430 |  |  | 300 |  |  | 753 |  |  | 492 |  |
| VMware | 561 |  |  | — |  |  | 1,047 |  |  | — |  |
| Reportable segment operating income | 1,557 |  |  | 784 |  |  | 2,740 |  |  | 1,361 |  |
| Other businesses (a) | 1 |  |  | (11 | ) |  | 4 |  |  | (27 | ) |
| Unallocated transactions (b) | (6 | ) |  | (17 | ) |  | 5 |  |  | (39 | ) |
| Impact of purchase accounting (c) | (406 | ) |  | (98 | ) |  | (829 | ) |  | (204 | ) |
| Amortization of intangibles | (1,740 | ) |  | (491 | ) |  | (3,516 | ) |  | (982 | ) |
| Transaction-related expenses (d) | (138 | ) |  | (72 | ) |  | (329 | ) |  | (129 | ) |
| Other corporate expenses (e) | (247 | ) |  | (28 | ) |  | (554 | ) |  | (52 | ) |
| Total operating income (loss) | $ | (979 | ) |  | $ | 67 |  |  | $ | (2,479 | ) |  | $ | (72 | ) |

[0001571996-17-000020:notes:229]
[same as prior period, unchanged from 0001571996-17-000009:notes:226]

[0001571996-17-000020:notes:230]
| (a) | Other businesses consist of RSA Information Security, SecureWorks, Pivotal, and Boomi, and do not constitute a reportable segment, either individually or collectively, as the results of the businesses are not material to the Company's overall results and the businesses do not meet the criteria for reportable segments. |

[0001571996-17-000020:notes:231]
[same as prior period, unchanged from 0001571996-17-000009:notes:228]

[0001571996-17-000020:notes:232]
[same as prior period, unchanged from 0001571996-17-000009:notes:229]

[0001571996-17-000020:notes:233]
[same as prior period, unchanged from 0001571996-17-000009:notes:230]

[0001571996-17-000020:notes:234]
[same as prior period, unchanged from 0001571996-17-000009:notes:231]


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001571996-17-000020:notes:235]
[same as prior period, unchanged from 0001571996-17-000009:notes:232]

[0001571996-17-000020:notes:236]
In connection with the transformation of the Company's business model, the Company incurs costs related to employee severance.  The Company records a liability for these costs when it is probable that employees will be entitled to termination benefits and the amounts can be reasonably estimated.  The liability related to these actions is included in accrued and other current liabilities in the Condensed Consolidated Statements of Financial Position.

[0001571996-17-000020:notes:237]
[same as prior period, unchanged from 0001571996-17-000009:notes:234]

[0001571996-17-000020:notes:238]
|  | Three Months Ended |  | Six Months Ended |
|  | August 4, 2017 |  | July 29, 2016 |  | August 4, 2017 |  | July 29, 2016 |
|  | (in millions) |
| Balance at beginning of period | $ | 257 |  |  | $ | 29 |  |  | $ | 416 |  |  | $ | 26 |  |
| Severance charges to provision | 14 |  |  | 9 |  |  | 44 |  |  | 26 |  |
| Cash paid and other | (85 | ) |  | (16 | ) |  | (274 | ) |  | (30 | ) |
| Balance at end of period | $ | 186 |  |  | $ | 22 |  |  | $ | 186 |  |  | $ | 22 |  |

[0001571996-17-000020:notes:239]
[same as prior period, unchanged from 0001571996-17-000009:notes:236]

[0001571996-17-000020:notes:240]
|  | Three Months Ended |  | Six Months Ended |
|  | August 4, 2017 |  | July 29, 2016 |  | August 4, 2017 |  | July 29, 2016 |
|  | (in millions) |
| Severance charges: |  |  |  |  |  |  |  |
| Cost of net revenue | $ | (1 | ) |  | $ | 1 |  |  | $ | 4 |  |  | $ | 5 |  |
| Selling, general, and administrative | 7 |  |  | 6 |  |  | 14 |  |  | 13 |  |
| Research and development | 8 |  |  | 2 |  |  | 26 |  |  | 8 |  |
| Total | $ | 14 |  |  | $ | 9 |  |  | $ | 44 |  |  | $ | 26 |  |


## us-gaap:ScheduleOfAmountsRecognizedInBalanceSheetTableTextBlock

[0001571996-17-000020:notes:241]
The following table provides additional information on selected accounts included in the Condensed Consolidated Statements of Financial Position as of August 4, 2017 and February 3, 2017:

[0001571996-17-000020:notes:242]
|  | August 4, 2017 |  | February 3, 2017 |
|  | (in millions) |
| Inventories, net: |  |  |  |
| Production materials | $ | 926 |  |  | $ | 925 |  |
| Work-in-process | 538 |  |  | 503 |  |
| Finished goods | 1,130 |  |  | 1,110 |  |
| Total inventories, net | 2,594 |  |  | 2,538 |  |
| Other non-current liabilities: |  |  |  |
| Warranty liability | 176 |  |  | 199 |  |
| Deferred and other tax liabilities | 7,124 |  |  | 8,607 |  |
| Other | 547 |  |  | 533 |  |
| Total other non-current liabilities | $ | 7,847 |  |  | $ | 9,339 |  |


## us-gaap:ScheduleOfDisposalGroupsIncludingDiscontinuedOperationsIncomeStatementBalanceSheetAndAdditionalDisclosuresTextBlock

[0001571996-17-000020:notes:243]
The following table presents key financial results of Dell Services and DSG included in "Income from discontinued operations, net of income taxes" for the three and six months ended July 29, 2016:

[0001571996-17-000020:notes:244]
The significant cash flow items from Dell Services and DSG for the six months ended July 29, 2016 were as follows:


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0001571996-17-000020:notes:245]
[same as prior period, unchanged from 0001571996-17-000009:notes:242]

[0001571996-17-000020:notes:246]
|  | Three Months Ended |  | Six Months Ended |
|  | August 4, 2017 |  | July 29, 2016 |  | August 4, 2017 |  | July 29, 2016 |
|  | (in millions) |
| Net revenue: |  |  |  |  |  |  |  |  |  |
| Client Solutions Group: |  |  |  |  |  |  |  |
| Commercial | $ | 7,196 |  |  | $ | 6,798 |  |  | $ | 13,546 |  |  | $ | 12,943 |  |
| Consumer | 2,655 |  |  | 2,422 |  |  | 5,361 |  |  | 4,848 |  |
| Total CSG net revenue | 9,851 |  |  | 9,220 |  |  | 18,907 |  |  | 17,791 |  |
| Infrastructure Solutions Group: |  |  |  |  |  |  |  |
| Servers and networking | 3,740 |  |  | 3,237 |  |  | 6,971 |  |  | 6,312 |  |
| Storage | 3,666 |  |  | 542 |  |  | 7,351 |  |  | 1,080 |  |
| Total ISG net revenue | 7,406 |  |  | 3,779 |  |  | 14,322 |  |  | 7,392 |  |
| VMware |  |  |  |  |  |  |  |
| Total VMware net revenue | 1,907 |  |  | — |  |  | 3,643 |  |  | — |  |
| Total segment net revenue | $ | 19,164 |  |  | $ | 12,999 |  |  | $ | 36,872 |  |  | $ | 25,183 |  |


## us-gaap:ScheduleOfStockByClassTextBlock

[0001571996-17-000020:notes:247]
The following table presents the repurchase activity with respect to the Class V Common Stock for the six months ended August 4, 2017, and the attribution of the Class V Group between the Class V Common Stock and the DHI Group's retained interest as of the dates indicated:

[0001571996-17-000020:notes:248]
|  | Class V Common Stock |  | DHI Group Retained Interest |
|  | Shares of Class V Common Stock |  | Interest in Class V Group |  | Retained Interest Shares |  | Interest in Class V Group |
|  | (in millions of shares) |
| As of February 3, 2017 | 209 |  |  | 62 | % |  | 127 |  |  | 38 | % |
| Repurchases of Class V Common Stock | (6 | ) |  |  |  | — |  |  |  |
| As of August 4, 2017 | 203 |  |  | 62 | % |  | 127 |  |  | 38 | % |

[0001571996-17-000020:notes:249]
[same as prior period, unchanged from 0001571996-17-000009:notes:244]

[0001571996-17-000020:notes:250]
|  | Authorized |  | Issued |  | Outstanding |
|  | (in millions of shares) |
| Common stock as of February 3, 2017 |
| Class A | 600 |  |  | 410 |  |  | 410 |  |
| Class B | 200 |  |  | 137 |  |  | 137 |  |
| Class C | 900 |  |  | 22 |  |  | 22 |  |
| Class D | 100 |  |  | — |  |  | — |  |
| Class V | 343 |  |  | 223 |  |  | 209 |  |
|  | 2,143 |  |  | 792 |  |  | 778 |  |
| Common stock as of August 4, 2017 |
| Class A | 600 |  |  | 410 |  |  | 410 |  |
| Class B | 200 |  |  | 137 |  |  | 137 |  |
| Class C | 7,900 |  |  | 23 |  |  | 23 |  |
| Class D | 100 |  |  | — |  |  | — |  |
| Class V | 343 |  |  | 223 |  |  | 203 |  |
|  | 9,143 |  |  | 793 |  |  | 773 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001571996-17-000020:notes:251]
[same as prior period, unchanged from 0001571996-17-000009:notes:248]

[0001571996-17-000020:notes:252]
[same as prior period, unchanged from 0001571996-17-000009:notes:249]

[0001571996-17-000020:notes:253]
[same as prior period, unchanged from 0001571996-17-000009:notes:250]

[0001571996-17-000020:notes:254]
[same as prior period, unchanged from 0001571996-17-000009:notes:251]


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001571996-17-000020:notes:255]
[same as prior period, unchanged from 0001571996-17-000009:notes:252]

[0001571996-17-000020:notes:256]
[same as prior period, unchanged from 0001571996-17-000009:notes:253]

[0001571996-17-000020:notes:257]
[same as prior period, unchanged from 0001571996-17-000009:notes:254]

[0001571996-17-000020:notes:258]
[same as prior period, unchanged from 0001571996-17-000009:notes:255]

[0001571996-17-000020:notes:259]
| • | For share-based arrangements that are subject to the occurrence of a contingent event, those amounts are not reclassified to temporary equity until the contingency has been satisfied. |

[0001571996-17-000020:notes:260]
The amount of redeemable shares classified as temporary equity as of August 4, 2017 was $333 million, which consisted of 2.0 million issued and outstanding unrestricted common shares, 0.9 million RSUs, 0.3 million RSAs, and 14.8 million outstanding stock options.  The amount of redeemable shares classified as temporary equity as of February 3, 2017 was $231 million, which consisted of 1.1 million issued and outstanding unrestricted common shares, 0.4 million RSUs, 0.1 million RSAs, and 13.7 million outstanding stock options.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001571996-17-000020:notes:261]
[same as prior period, unchanged from 0001571996-17-000009:notes:258]

[0001571996-17-000020:notes:262]
On June 26, 2017, the stockholders of the Company voted at the Company’s 2017 annual meeting of stockholders to adopt an amendment to the Company’s certificate of incorporation to increase (1) the total authorized number of shares of the Company’s capital stock, including preferred stock, from 2,144,025,308 shares to 9,144,025,308 shares, (2) the total authorized number of shares of the Company’s common stock from 2,143,025,308 shares to 9,143,025,308 shares and (3) the total authorized number of shares of the Company’s Class C Common Stock from 900,000,000 shares to 7,900,000,000 shares, in each case representing an increase of seven billion shares.  A certificate of amendment to the Company’s certificate of incorporation effectuating the amendment was filed with the Secretary of State of the State of Delaware on June 29, 2017 and became effective on that date.

[0001571996-17-000020:notes:263]
Preferred Stock — The Company is authorized to issue one million shares of preferred stock, par value $.01 per share.  As of August 4, 2017, no shares of preferred stock were issued or outstanding.

[0001571996-17-000020:notes:264]
Class V Common Stock and Class V Group — In connection with the EMC merger transaction, the Company authorized 343 million shares of Class V Common Stock.  The Class V Common Stock is a type of common stock commonly referred to as a tracking stock, which is a class of common stock that is intended to track the economic performance of a defined set of assets and liabilities.  As of August 4, 2017, the 203 million shares of outstanding Class V Common Stock were intended to track the economic performance of approximately 62% of Dell Technologies' economic interest in the Class V Group.  The Class V Group as of such date consisted solely of approximately 333 million shares of VMware, Inc. common stock held by the Company.  The remaining 38% economic interest in the Class V Group as of August 4, 2017 was represented by the approximately 127 million retained interest shares held by the DHI Group.  The DHI Group generally refers, in addition to such retained interest, to the direct and indirect interest of Dell Technologies in all of Dell Technologies' business, assets, properties, liabilities, and preferred stock other than those attributable to the Class V Group.

[0001571996-17-000020:notes:265]
[same as prior period, unchanged from 0001571996-17-000009:notes:261]

[0001571996-17-000020:notes:266]
Class V Common Stock Repurchases — On December 13, 2016, the board of directors approved a stock repurchase program (the "Class V Group Repurchase Program") which authorized the Company to use assets of the Class V Group to repurchase up to $500 million of shares of Class V Common Stock over a period of six months.  During the three months ended May 5, 2017, the Company repurchased 1.3 million shares of Class V Common Stock for $82 million pursuant to this initial authorization.

[0001571996-17-000020:notes:267]
On March 27, 2017, the board of directors approved an amendment of the Class V Group Repurchase Program (the "March 2017 Class V Group Repurchase Program") which authorized the Company to use assets of the Class V Group to repurchase up to an additional $300 million of shares of Class V Common Stock over a period of an additional six months.  During the six months ended August 4, 2017, the Company repurchased 4.6 million shares of Class V Common Stock for $300 million pursuant to the March 2017 Class V Group Repurchase Program.  On May 9, 2017, the March 2017 Class V Group Repurchase Program was completed.

[0001571996-17-000020:notes:268]
All shares of Class V Common Stock repurchased by the Company pursuant to the repurchase programs are held as treasury stock at cost.  The repurchase of shares pursuant to the Class V Common Stock repurchase programs was funded from proceeds received by the Class V Group from the sale by a subsidiary of the Company of shares of Class A common stock of VMware, Inc. owned by such subsidiary, as described below under "VMware, Inc. Class A Common Stock Repurchases."  Share repurchases made by VMware, Inc. of its Class A common stock from a subsidiary of the Company do not affect the determination of the respective interests of the Class V Common Stock and the DHI Group in the Class V Group.  See Exhibit 99.1 to the Company's quarterly report on Form 10-Q for the quarterly period ended August 4, 2017 for more information regarding Unaudited Attributed Financial Information for the Class V Group.

[0001571996-17-000020:notes:269]
VMware, Inc. Class A Common Stock Repurchases — On December 15, 2016, the Company entered into a stock purchase agreement with VMware, Inc. (the "December 2016 Stock Purchase Agreement"), pursuant to which VMware, Inc. agreed to repurchase for cash $500 million of shares of VMware, Inc. Class A common stock from a subsidiary of the Company.  During the three months ended May 5, 2017, VMware, Inc. repurchased 1.4 million shares pursuant to the December 2016 Stock Purchase Agreement.  VMware, Inc. repurchased a total of 6.2 million shares under this agreement.  The Company applied the proceeds from the sale to the repurchase of shares of its Class V Common Stock under the Class V Group Repurchase Program described above.  All shares repurchased under VMware, Inc.'s stock repurchase programs are retired.

[0001571996-17-000020:notes:270]
In January 2017, VMware, Inc.'s board of directors authorized the repurchase of up to an additional $1.2 billion of shares of VMware, Inc. Class A common stock (the "January 2017 Authorization") through the end of Fiscal 2018.  On March 29, 2017, the Company entered into a new stock purchase agreement with VMware, Inc. (the "March 2017 Stock Purchase Agreement"), pursuant to which VMware, Inc. agreed to repurchase for cash $300 million of shares of VMware, Inc. Class A common stock from a subsidiary of the Company.  During the six months ended August 4, 2017, VMware, Inc. repurchased approximately 3.4 million shares of Class A common stock pursuant to the January 2017 Authorization and the March 2017 Stock Purchase Agreement.  The proceeds from the sale were applied by the Company to the repurchase of shares of the Class V Common Stock under the March 2017 Class V Group Repurchase Program described above.  On May 10, 2017, the sale transaction under the March 2017 Stock Purchase Agreement was completed.  The total of 3.4 million shares repurchased by VMware, Inc. was based on the volume-weighted average per share price of the Class A common stock as reported on the New York Stock Exchange during a specified reference period, less a discount of 3.5% from that volume-weighted average per share price.  As of August 4, 2017, the cumulative authorized amount remaining for share repurchases by VMware, Inc. under the January 2017 Authorization was $900 million.

[0001571996-17-000020:notes:271]
For more information regarding common stock repurchase programs, see Note 21 of the Notes to the Condensed Consolidated Financial Statements.


## us-gaap:SubsequentEventsTextBlock

[0001571996-17-000020:notes:272]
SUBSEQUENT EVENTS

[0001571996-17-000020:notes:273]
Amendment of Class V Common Stock Repurchase Program — On August 18, 2017, the Company's board of directors approved a second amendment of the Class V Group Repurchase Program (as so amended, the “August 2017 Class V Group Repurchase Program”) further extending the program to authorize the Company to use assets of the Company’s Class V Group to repurchase up to an additional $300 million of shares of the Company’s Class V Common Stock.  The repurchase of shares pursuant to the August 2017 Class V Group Repurchase Program is expected to be funded from proceeds received by the VMware, Inc. Class A Common Stock Repurchase program described below.

[0001571996-17-000020:notes:274]
VMware, Inc. Class A Common Stock Repurchase — In August 2017, VMware, Inc.'s board of directors authorized the repurchase of up to an additional $1 billion of VMware, Inc. Class A common stock through August 31, 2018.  The authorization is in addition to VMware, Inc.’s ongoing $1.2 billion stock repurchase program, originally announced in January 2017, of which $0.9 billion remains available.  On August 23, 2017, the Company and VMware, Inc. entered into a purchase commitment supplement to the March 2017 Stock Purchase Agreement (as amended, the “August 2017 Stock Purchase Agreement”).  Under the August 2017 Stock Purchase Agreement, VMware, Inc. will purchase for cash $300 million of VMware, Inc. Class A common stock from EMC Equity Assets LLC, an indirect wholly-owned subsidiary of the Company.  The Company will apply the proceeds from the sale to the repurchase of shares of its Class V Common Stock under the August 2017 Class V Group Repurchase Program described above, but may use such proceeds for other purposes at the discretion of the Capital Stock Committee of the board of directors and the board of directors.  The total number of shares to be purchased by VMware, Inc. under the August 2017 Stock Purchase Agreement will be based on the volume-weighted average per share price of the VMware, Inc. Class A common stock as reported on the New York Stock Exchange during a specified reference period, less a discount of 3.5% from that volume-weighted average per share price, and subject to adjustment in certain circumstances.

[0001571996-17-000020:notes:275]
VMware, Inc. Public Debt Offering — On August 21, 2017, VMware, Inc. completed a public debt offering in the aggregate amount of $4.0 billion, consisting of outstanding principal due on the following dates: $1.25 billion due August 21, 2020, $1.5 billion due August 21, 2022, and $1.25 billion due August 21, 2027. The notes bear interest, payable semi-annually, at annual rates of 2.30%, 2.95%, and 3.90%, respectively.  Upon closing, a portion of the net proceeds from the offering was used to repay certain intercompany promissory notes previously issued to EMC in the aggregate principal amount of $1.2 billion.

[0001571996-17-000020:notes:276]
VMware Note Bridge Facility Repayment — Subsequent to August 4, 2017, the Company repaid the $1.5 billion VMware Note Bridge Facility in full with proceeds of $1.2 billion from the foregoing VMware public debt offering and other cash.

[0001571996-17-000020:notes:277]
Other than the matters identified above, there were no known events occurring after the balance sheet date and up until the date of the issuance of this report that would materially affect the information presented herein.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001571996-17-000020:notes:278]
[same as prior period, unchanged from 0001571996-17-000009:notes:271]
