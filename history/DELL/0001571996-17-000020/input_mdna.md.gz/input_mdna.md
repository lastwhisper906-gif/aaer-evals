# DELL MD&A — 0001571996-17-000020


## mdna

[0001571996-17-000020:mdna:1]
[same as prior period, unchanged from 0001571996-17-000009:mdna:1]

[0001571996-17-000020:mdna:2]
[same as prior period, unchanged from 0001571996-17-000009:mdna:2]

[0001571996-17-000020:mdna:3]
[same as prior period, unchanged from 0001571996-17-000009:mdna:3]

[0001571996-17-000020:mdna:4]
Our fiscal year is the 52- or 53-week period ending on the Friday nearest January 31.  We refer to our fiscal years ended February 2, 2018 and February 3, 2017 as "Fiscal 2018" and "Fiscal 2017," respectively.  Fiscal 2017 included 53 weeks, with the extra week included in the fourth quarter of Fiscal 2017.  Fiscal 2018 will include 52 weeks.

[0001571996-17-000020:mdna:5]
On September 7, 2016, we completed our acquisition by merger of EMC.  The consolidated results of EMC are included in Dell Technologies' consolidated results for the Fiscal 2018 periods presented.  During Fiscal 2017, we closed the Dell Services, Dell Services Group ("DSG"), and Enterprise Content Division ("ECD") divestiture transactions.  Accordingly, the results of operations of Dell Services, DSG, and ECD, as well as the related gains or losses on sale, have been excluded from the results of continuing operations in the relevant periods, except as otherwise indicated.

[0001571996-17-000020:mdna:6]
[same as prior period, unchanged from 0001571996-17-000009:mdna:6]

[0001571996-17-000020:mdna:7]
Dell Technologies is a strategically aligned family of businesses that brings together the entire infrastructure from hardware to software to services — from the edge to the data center to the cloud.  Dell Technologies is a leader in the traditional technology of today and a leader in the cloud-native infrastructure of tomorrow.  We are a leading provider of scalable IT solutions enabling customers to be more efficient, mobile, informed, and secure.  Through our recent combination with EMC, Dell Technologies now primarily encompasses our Client Solutions Group, Infrastructure Solutions Group, VMware, Inc., RSA Information Security, SecureWorks Corp. ("SecureWorks"), Pivotal Software, Inc. ("Pivotal"), and Boomi, Inc ("Boomi").  We are focused on providing technology solutions and services that accelerate digital transformation.  We believe technology exists to drive human progress on a global scale — to create new markets, reshape industries, and improve lives.  We are positioned to help customers of any size build the essential infrastructure to modernize IT and enable digital business, and are differentiated by our practical innovation and efficient, simple, and affordable solutions.

[0001571996-17-000020:mdna:8]
[same as prior period, unchanged from 0001571996-17-000009:mdna:8]

[0001571996-17-000020:mdna:9]
We are actively working on the integration of EMC acquired businesses and in our combined go-to-market initiatives.  During this period of transition and integration, we remain focused on supporting our customers with outstanding solutions, products, and services.  We will continue our focus on building superior customer relationships through our direct model and our network of channel partners, which includes value-added resellers, system integrators, distributors, and retailers.  We also will continue investing in strategic solutions and enhancing our go-to-market sales and marketing capabilities as we seek to strengthen our position as leading global technology company poised for long-term sustainable growth and innovation.

[0001571996-17-000020:mdna:10]
[same as prior period, unchanged from 0001571996-17-000009:mdna:11]

[0001571996-17-000020:mdna:11]
| • | Extend our market leading position through our Client Solutions Group and Infrastructure Solutions Group offerings |

[0001571996-17-000020:mdna:12]
| • | Grow our strong position in IT infrastructure for traditional and cloud-native workloads, both on- and off-premises |

[0001571996-17-000020:mdna:13]
| • | Innovate with winning technology that spans and unites on- and off-premises applications and infrastructure and that enables IT, security, and workforce transformation required by our customers |

[0001571996-17-000020:mdna:14]
As part of this strategy, we will continue to evaluate opportunities for strategic investments through our venture capital investment arm, Dell Technologies Capital, with a focus on emerging technology areas that are relevant to the Dell Technologies' unique family of businesses and that will complement our existing portfolio of solutions.  Our investment areas include storage, software-defined networking, management and orchestration, security, machine learning and artificial intelligence, Big Data and analytics, cloud, Internet of Things, and software development operations.  In addition to these investments, we also may make disciplined acquisitions targeting businesses that advance our strategic objectives.

[0001571996-17-000020:mdna:15]
[same as prior period, unchanged from 0001571996-17-000009:mdna:16]

[0001571996-17-000020:mdna:16]
[same as prior period, unchanged from 0001571996-17-000009:mdna:17]

[0001571996-17-000020:mdna:17]
We design, develop, manufacture, market, sell, and support a wide range of products and services.  We are organized into the following business units, which are our reportable segments: Client Solutions Group; Infrastructure Solutions Group; and VMware.  Due to our divestitures of Dell Services, Dell Software Group, and Dell EMC Enterprise Content Division, the results of these businesses, as well as the related gains or losses on sale, have been excluded from the relevant periods, except as otherwise indicated.

[0001571996-17-000020:mdna:18]
| • | Client Solutions Group (CSG) — Offerings by CSG include branded hardware, such as desktop PCs, notebooks, and workstations, and branded peripherals, such as monitors, printers, and projectors. CSG also offers attached software, peripherals, and services, including support and deployment, configuration, and extended warranty services. |

[0001571996-17-000020:mdna:19]
Approximately half of CSG revenue is generated by sales to customers in the Americas, with the remaining portion derived from sales to customers in the Europe, Middle East and Africa region ("EMEA") and the Asia-Pacific and Japan region ("APJ").

[0001571996-17-000020:mdna:20]
| • | Infrastructure Solutions Group (ISG) — EMC's Information Storage segment and our former Enterprise Solutions Group were merged to create the Infrastructure Solutions Group, or ISG, which contains storage, server, and networking offerings. The comprehensive portfolio of advanced storage solutions includes traditional storage solutions as well as next-generation storage solutions (including all flash arrays and scale-out file, and object platforms). The server portfolio includes high-performance rack, blade, tower, and hyperscale servers. The networking portfolio enables our business customers transform and modernize their infrastructure, mobilize and enrich end-user experiences, and accelerate business applications and processes. Similar to CSG, ISG also offers attached software, peripherals, and services, including support and deployment, configuration, and extended warranty services. |

[0001571996-17-000020:mdna:21]
[same as prior period, unchanged from 0001571996-17-000009:mdna:22]

[0001571996-17-000020:mdna:22]
[same as prior period, unchanged from 0001571996-17-000009:mdna:23]

[0001571996-17-000020:mdna:23]
[same as prior period, unchanged from 0001571996-17-000009:mdna:24]

[0001571996-17-000020:mdna:24]
[same as prior period, unchanged from 0001571996-17-000009:mdna:25]

[0001571996-17-000020:mdna:25]
[same as prior period, unchanged from 0001571996-17-000009:mdna:26]

[0001571996-17-000020:mdna:26]
[same as prior period, unchanged from 0001571996-17-000009:mdna:27]

[0001571996-17-000020:mdna:27]
[same as prior period, unchanged from 0001571996-17-000009:mdna:28]

[0001571996-17-000020:mdna:28]
[same as prior period, unchanged from 0001571996-17-000009:mdna:29]

[0001571996-17-000020:mdna:29]
[same as prior period, unchanged from 0001571996-17-000009:mdna:30]

[0001571996-17-000020:mdna:30]
[same as prior period, unchanged from 0001571996-17-000009:mdna:31]

[0001571996-17-000020:mdna:31]
[same as prior period, unchanged from 0001571996-17-000009:mdna:32]

[0001571996-17-000020:mdna:32]
[same as prior period, unchanged from 0001571996-17-000009:mdna:33]

[0001571996-17-000020:mdna:33]
We also offer or arrange various financing options and services for our commercial and consumer customers in North America, Europe, Australia, and New Zealand through Dell Financial Services ("DFS") and its affiliates.  DFS services include originating, collecting, and servicing customer receivables primarily related to the purchase of Dell Technologies products.  The results of these operations are allocated to our segments based on the underlying product or service financed.  For additional information about our financing arrangements, see Note 6 of the Notes to the Condensed Consolidated Financial Statements included in this report.

[0001571996-17-000020:mdna:34]
[same as prior period, unchanged from 0001571996-17-000009:mdna:35]

[0001571996-17-000020:mdna:35]
We are seeing an unprecedented rate of change in the IT industry.  Organizations of all kinds are embracing digital technology to achieve their business objectives.  Our vision is to be the essential infrastructure company and leader in end-user computing, data center infrastructure solutions, virtualization, and cloud software that our customers continue to trust and rely on for their IT solutions and transformations.  We accelerate results for our customers by enabling them to be more efficient, mobile, informed, and secure.  We continue to invest in research and development, sales, and other key areas of our business to deliver superior products and solutions capabilities and to drive execution of long-term sustainable growth.  We believe that our results will benefit from an integrated go-to-market strategy, including enhanced coordination among the family of Dell Technologies companies, and from our differentiated products and solutions capabilities.  We intend to continue to execute on our business model and seek to balance liquidity, profitability, and growth to position our company for long-term success.

[0001571996-17-000020:mdna:36]
We are able to leverage our traditional strength in the PC market to offer solutions and services that provide higher-value, recurring revenue streams.  Given current market trends, we expect that the demand environment will continue to be cyclical and that competitive dynamics will continue to pressure our CSG business.  However, we are committed to a long-term growth strategy that we believe will benefit from the consolidation trends that are occurring in our markets.  Our CSG offerings remain an important element of our strategy, generating strong cash flow and opportunities for cross-selling of complementary solutions.

[0001571996-17-000020:mdna:37]
We expect that ISG will continue to be affected by declines in the traditional storage and server markets.  Cloud-native applications are expected to continue as a primary growth driver in the infrastructure market as IT organizations increasingly become multi-cloud environments.  We believe the complementary cloud solutions across our business, created through our combination with EMC, strongly position us to meet these demands for our customers who are increasingly looking to leverage cloud-based computing.  Further, we will provide new and more robust storage and data center solutions to meet the evolving needs of our customers.  We also continue to be impacted by the emerging trends of enterprises deploying software-defined storage, hyper-converged, and modular solutions based on server-centric architectures.  We have leading solutions in these categories through our ISG and VMware data center offerings.  In addition, through our research and development efforts, we expect to develop new solutions in this rapidly changing industry that we believe will enable us to continue to provide superior solutions to our customers.

[0001571996-17-000020:mdna:38]
In ISG, we are also seeing increased interest in "as a service" flexible consumption models by our customers as they seek to build greater flexibility into their cost structures.  We have introduced various financing and consumption model to meet our customers' needs.

[0001571996-17-000020:mdna:39]
During the first six months of Fiscal 2018, we have experienced higher component costs which primarily impact CSG and ISG.  We expect to see this trend continue in the near term.

[0001571996-17-000020:mdna:40]
We manage our business on a U.S. dollar basis.  However, we have a large global presence, generating approximately half of our revenue by sales to customers outside of the United States during the second quarter and first six months of Fiscal 2018 and the second quarter and first six months of Fiscal 2017.  Our revenues, therefore, can be impacted by fluctuations in foreign currency exchange rates.  We utilize a comprehensive hedging strategy intended to mitigate the impact of foreign currency volatility over time, and we adjust pricing when possible to further minimize foreign currency impacts.  The percentage of our revenues generated in regions outside of the United States did not change substantially as a result of the EMC merger transaction.

[0001571996-17-000020:mdna:41]
[same as prior period, unchanged from 0001571996-17-000009:mdna:42]

[0001571996-17-000020:mdna:42]
[same as prior period, unchanged from 0001571996-17-000009:mdna:43]

[0001571996-17-000020:mdna:43]
Pursuant to the terms of the merger agreement, upon the completion of the EMC merger transaction, each issued and outstanding share of common stock, par value $0.01 per share, of EMC Corporation (approximately 2.0 billion as of September 7, 2016) was converted into the right to receive (1) $24.05 in cash, without interest, and (2) 0.11146 validly issued, fully paid and non-assessable shares of common stock of the Company designated as Class V Common Stock, par value $0.01 per share, plus cash in lieu of any fractional shares.  Shares of the Class V Common Stock were approved for listing on the New York Stock Exchange (the "NYSE") under the ticker symbol "DVMT" and began trading on September 7, 2016.

[0001571996-17-000020:mdna:44]
In connection with the EMC merger transaction, all principal, accrued but unpaid interest, fees, and other amounts (other than certain contingent obligations) outstanding at the effective time of the EMC merger transaction under EMC's unsecured revolving credit facility, Dell's asset-based revolving credit facility, and Dell's term facilities were substantially repaid concurrently with the closing.  Further, all commitments to lend and guarantees and security interests, as applicable, in connection therewith were terminated or released.  The aggregate amounts of principal, interest, and premium necessary to redeem in full the outstanding $1.4 billion in aggregate principal amount of 5.625% Senior First Lien Notes due 2020 co-issued by Dell International and Denali Finance Corp. were deposited with the trustee for such notes, and such notes were thereby satisfied and discharged, concurrently with the effective time of the EMC merger transaction.  All of Dell's other outstanding senior notes and all of EMC's outstanding senior notes remained outstanding after the effective time of the EMC merger transaction in accordance with their respective terms.

[0001571996-17-000020:mdna:45]
Dell Technologies financed the EMC merger transaction, the repayment of the foregoing indebtedness of EMC and Dell outstanding as of the closing of the EMC merger transaction, and the payment of related fees and expenses, with debt financing arrangements in an aggregate principal amount of approximately $45.9 billion, equity financing arrangements of approximately $4.4 billion, and cash on hand of approximately $7.8 billion.

[0001571996-17-000020:mdna:46]
[same as prior period, unchanged from 0001571996-17-000009:mdna:47]

[0001571996-17-000020:mdna:47]
[same as prior period, unchanged from 0001571996-17-000009:mdna:63]

[0001571996-17-000020:mdna:48]
[same as prior period, unchanged from 0001571996-17-000009:mdna:48]

[0001571996-17-000020:mdna:49]
[same as prior period, unchanged from 0001571996-17-000009:mdna:49]

[0001571996-17-000020:mdna:50]
[same as prior period, unchanged from 0001571996-17-000009:mdna:50]

[0001571996-17-000020:mdna:51]
[same as prior period, unchanged from 0001571996-17-000009:mdna:51]

[0001571996-17-000020:mdna:52]
[same as prior period, unchanged from 0001571996-17-000009:mdna:52]

[0001571996-17-000020:mdna:53]
[same as prior period, unchanged from 0001571996-17-000009:mdna:53]

[0001571996-17-000020:mdna:54]
[same as prior period, unchanged from 0001571996-17-000009:mdna:54]

[0001571996-17-000020:mdna:55]
[same as prior period, unchanged from 0001571996-17-000009:mdna:55]

[0001571996-17-000020:mdna:56]
[same as prior period, unchanged from 0001571996-17-000009:mdna:56]

[0001571996-17-000020:mdna:57]
[same as prior period, unchanged from 0001571996-17-000009:mdna:57]

[0001571996-17-000020:mdna:58]
| • | Other Corporate Expenses — Other corporate expenses consists of severance, facility action costs, and stock-based compensation expense associated with equity awards. Severance costs are primarily related to severance and benefits for employees terminated pursuant to cost savings initiatives. Facility action costs included in the second quarter and first six months of Fiscal 2018 were $29 million and $108 million, respectively. We expect to incur these costs over the next six months as we continue to integrate owned and leased facilities and as we seek opportunities for operational efficiencies and cost savings. Other corporate expenses vary from period to period and are significantly impacted by the timing and nature of these events. Therefore, although we may incur these types of expenses in the future, we believe that eliminating these charges for purposes of calculating the non-GAAP financial measures presented below facilitates a more meaningful evaluation of our current operating performance and comparisons to our past operating performance. |

[0001571996-17-000020:mdna:59]
| • | Aggregate Adjustment for Income Taxes — The aggregate adjustment for income taxes is the estimated combined income tax effect for the adjustments described above. During the second quarter and first six months of Fiscal 2017, this amount also includes tax charges of approximately $66 million and $201 million, respectively, on previously untaxed earnings of a foreign subsidiary that will no longer be permanently reinvested as a result of the Dell Services and DSG divestitures. The tax effects are determined based on the tax jurisdictions where the above items were incurred. |

[0001571996-17-000020:mdna:60]
[same as prior period, unchanged from 0001571996-17-000009:mdna:74]

[0001571996-17-000020:mdna:61]
[same as prior period, unchanged from 0001571996-17-000009:mdna:61]

[0001571996-17-000020:mdna:62]
|  | Three Months Ended |  | Six Months Ended |
|  | August 4, 2017 |  | % Change |  | July 29, 2016 (a) |  | August 4, 2017 |  | % Change |  | July 29, 2016 (a) |
|  | (in millions, except percentages) |
| Product net revenue | $ | 14,355 |  |  | 31 | % |  | $ | 10,961 |  |  | $ | 27,323 |  |  | 29 | % |  | $ | 21,144 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 50 |  |  |  |  | — |  |  | 105 |  |  |  |  | (1 | ) |
| Non-GAAP product net revenue | $ | 14,405 |  |  | 31 | % |  | $ | 10,961 |  |  | $ | 27,428 |  |  | 30 | % |  | $ | 21,143 |  |
| Services net revenue | $ | 4,944 |  |  | 133 | % |  | $ | 2,119 |  |  | $ | 9,792 |  |  | 134 | % |  | $ | 4,177 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 285 |  |  |  |  | 65 |  |  | 585 |  |  |  |  | 144 |  |
| Non-GAAP services net revenue | $ | 5,229 |  |  | 139 | % |  | $ | 2,184 |  |  | $ | 10,377 |  |  | 140 | % |  | $ | 4,321 |  |
| Net revenue | $ | 19,299 |  |  | 48 | % |  | $ | 13,080 |  |  | $ | 37,115 |  |  | 47 | % |  | $ | 25,321 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 335 |  |  |  |  | 65 |  |  | 690 |  |  |  |  | 143 |  |
| Non-GAAP net revenue | $ | 19,634 |  |  | 49 | % |  | $ | 13,145 |  |  | $ | 37,805 |  |  | 48 | % |  | $ | 25,464 |  |
| Product gross margin | $ | 1,977 |  |  | 35 | % |  | $ | 1,466 |  |  | $ | 3,486 |  |  | 22 | % |  | $ | 2,850 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 63 |  |  |  |  | 12 |  |  | 128 |  |  |  |  | 24 |  |
| Amortization of intangibles | 920 |  |  |  |  | 101 |  |  | 1,870 |  |  |  |  | 202 |  |
| Transaction-related expenses | 6 |  |  |  |  | (2 | ) |  | 8 |  |  |  |  | (2 | ) |
| Other corporate expenses | 3 |  |  |  |  | 3 |  |  | 6 |  |  |  |  | 4 |  |
| Non-GAAP product gross margin | $ | 2,969 |  |  | 88 | % |  | $ | 1,580 |  |  | $ | 5,498 |  |  | 79 | % |  | $ | 3,078 |  |
| Services gross margin | $ | 2,832 |  |  | 226 | % |  | $ | 870 |  |  | $ | 5,625 |  |  | 235 | % |  | $ | 1,679 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 285 |  |  |  |  | 67 |  |  | 585 |  |  |  |  | 144 |  |
| Amortization of intangibles | — |  |  |  |  | — |  |  | — |  |  |  |  | — |  |
| Transaction-related expenses | 4 |  |  |  |  | (2 | ) |  | 9 |  |  |  |  | (3 | ) |
| Other corporate expenses | 10 |  |  |  |  | — |  |  | 29 |  |  |  |  | 2 |  |
| Non-GAAP services gross margin | $ | 3,131 |  |  | 235 | % |  | $ | 935 |  |  | $ | 6,248 |  |  | 243 | % |  | $ | 1,822 |  |
| Gross margin | $ | 4,809 |  |  | 106 | % |  | $ | 2,336 |  |  | $ | 9,111 |  |  | 101 | % |  | $ | 4,529 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 348 |  |  |  |  | 79 |  |  | 713 |  |  |  |  | 168 |  |
| Amortization of intangibles | 920 |  |  |  |  | 101 |  |  | 1,870 |  |  |  |  | 202 |  |
| Transaction-related expenses | 10 |  |  |  |  | (4 | ) |  | 17 |  |  |  |  | (5 | ) |
| Other corporate expenses | 13 |  |  |  |  | 3 |  |  | 35 |  |  |  |  | 6 |  |
| Non-GAAP gross margin | $ | 6,100 |  |  | 143 | % |  | $ | 2,515 |  |  | $ | 11,746 |  |  | 140 | % |  | $ | 4,900 |  |

[0001571996-17-000020:mdna:63]
[same as prior period, unchanged from 0001571996-17-000009:mdna:83]

[0001571996-17-000020:mdna:64]
|  | Three Months Ended |  | Six Months Ended |
|  | August 4, 2017 |  | % Change |  | July 29, 2016 (a) |  | August 4, 2017 |  | % Change |  | July 29, 2016 (a) |
|  | (in millions, except percentages) |
| Operating expenses | $ | 5,788 |  |  | 155 | % |  | $ | 2,269 |  |  | $ | 11,590 |  |  | 152 | % |  | $ | 4,601 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | (58 | ) |  |  |  | (19 | ) |  | (116 | ) |  |  |  | (36 | ) |
| Amortization of intangibles | (820 | ) |  |  |  | (390 | ) |  | (1,646 | ) |  |  |  | (780 | ) |
| Transaction-related expenses | (128 | ) |  |  |  | (76 | ) |  | (312 | ) |  |  |  | (134 | ) |
| Other corporate expenses | (234 | ) |  |  |  | (25 | ) |  | (519 | ) |  |  |  | (46 | ) |
| Non-GAAP operating expenses | $ | 4,548 |  |  | 159 | % |  | $ | 1,759 |  |  | $ | 8,997 |  |  | 150 | % |  | $ | 3,605 |  |
| Operating income (loss) | $ | (979 | ) |  | NM |  |  | $ | 67 |  |  | $ | (2,479 | ) |  | NM |  |  | $ | (72 | ) |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 406 |  |  |  |  | 98 |  |  | 829 |  |  |  |  | 204 |  |
| Amortization of intangibles | 1,740 |  |  |  |  | 491 |  |  | 3,516 |  |  |  |  | 982 |  |
| Transaction-related expenses | 138 |  |  |  |  | 72 |  |  | 329 |  |  |  |  | 129 |  |
| Other corporate expenses | 247 |  |  |  |  | 28 |  |  | 554 |  |  |  |  | 52 |  |
| Non-GAAP operating income | $ | 1,552 |  |  | 105 | % |  | $ | 756 |  |  | $ | 2,749 |  |  | 112 | % |  | $ | 1,295 |  |
| Net loss from continuing operations | $ | (978 | ) |  | (273 | )% |  | $ | (262 | ) |  | $ | (2,361 | ) |  | (244 | )% |  | $ | (686 | ) |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 406 |  |  |  |  | 98 |  |  | 829 |  |  |  |  | 204 |  |
| Amortization of intangibles | 1,740 |  |  |  |  | 491 |  |  | 3,516 |  |  |  |  | 982 |  |
| Transaction-related expenses | 138 |  |  |  |  | 69 |  |  | 329 |  |  |  |  | 126 |  |
| Other corporate expenses | 247 |  |  |  |  | 28 |  |  | 554 |  |  |  |  | 52 |  |
| Aggregate adjustment for income taxes | (680 | ) |  |  |  | (62 | ) |  | (1,413 | ) |  |  |  | (52 | ) |
| Non-GAAP net income from continuing operations | $ | 873 |  |  | 141 | % |  | $ | 362 |  |  | $ | 1,454 |  |  | 132 | % |  | $ | 626 |  |

[0001571996-17-000020:mdna:65]
_____________________

[0001571996-17-000020:mdna:66]
(a)    The amounts presented for the three and six months ended July 29, 2016 are different from those reported on our Form 10-Q for the quarterly period ended July 29, 2016 previously filed with the SEC, because we reclassified an immaterial amount of net income from discontinued operations to continuing operations to reflect the updated terms of the applicable divestitures as the result of continued negotiations and finalization of terms of the sale.

[0001571996-17-000020:mdna:67]
In addition to the above measures, we also use EBITDA and adjusted EBITDA to provide additional information for evaluation of our operating performance.  Adjusted EBITDA excludes purchase accounting adjustments related to the EMC merger transaction and the going-private transaction, acquisition, integration, and divestiture related costs, severance and facility actions, and stock-based compensation expense.  We believe that, due to the non-operational nature of the purchase accounting entries, it is appropriate to exclude these adjustments.

[0001571996-17-000020:mdna:68]
[same as prior period, unchanged from 0001571996-17-000009:mdna:66]

[0001571996-17-000020:mdna:69]
67

[0001571996-17-000020:mdna:70]
[same as prior period, unchanged from 0001571996-17-000009:mdna:67]

[0001571996-17-000020:mdna:71]
|  | Three Months Ended |  | Six Months Ended |
|  | August 4, 2017 |  | % Change |  | July 29, 2016 |  | August 4, 2017 |  | % Change |  | July 29, 2016 |
|  | (in millions, except percentages) |
| Net loss from continuing operations | $ | (978 | ) |  | (273 | )% |  | $ | (262 | ) |  | $ | (2,361 | ) |  | (244 | )% |  | $ | (686 | ) |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Interest and other, net (a) | 545 |  |  |  |  | 349 |  |  | 1,118 |  |  |  |  | 568 |  |
| Income tax provision (benefit) | (546 | ) |  |  |  | (20 | ) |  | (1,236 | ) |  |  |  | 46 |  |
| Depreciation and amortization | 2,142 |  |  |  |  | 605 |  |  | 4,354 |  |  |  |  | 1,223 |  |
| EBITDA | $ | 1,163 |  |  | 73 | % |  | $ | 672 |  |  | $ | 1,875 |  |  | 63 | % |  | $ | 1,151 |  |
| EBITDA | $ | 1,163 |  |  | 73 | % |  | $ | 672 |  |  | $ | 1,875 |  |  | 63 | % |  | $ | 1,151 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense | 208 |  |  |  |  | 19 |  |  | 409 |  |  |  |  | 33 |  |
| Impact of purchase accounting (b) | 335 |  |  |  |  | 75 |  |  | 692 |  |  |  |  | 158 |  |
| Transaction-related expenses (c) | 138 |  |  |  |  | 109 |  |  | 329 |  |  |  |  | 166 |  |
| Other corporate expenses (d) | 22 |  |  |  |  | 9 |  |  | 128 |  |  |  |  | 19 |  |
| Adjusted EBITDA | $ | 1,866 |  |  | 111 | % |  | $ | 884 |  |  | $ | 3,433 |  |  | 125 | % |  | $ | 1,527 |  |

[0001571996-17-000020:mdna:72]
[same as prior period, unchanged from 0001571996-17-000009:mdna:69]

[0001571996-17-000020:mdna:73]
[same as prior period, unchanged from 0001571996-17-000009:mdna:70]

[0001571996-17-000020:mdna:74]
[same as prior period, unchanged from 0001571996-17-000009:mdna:71]

[0001571996-17-000020:mdna:75]
[same as prior period, unchanged from 0001571996-17-000009:mdna:72]

[0001571996-17-000020:mdna:76]
[same as prior period, unchanged from 0001571996-17-000009:mdna:73]

[0001571996-17-000020:mdna:77]
68

[0001571996-17-000020:mdna:78]
[same as prior period, unchanged from 0001571996-17-000009:mdna:75]

[0001571996-17-000020:mdna:79]
[same as prior period, unchanged from 0001571996-17-000009:mdna:76]

[0001571996-17-000020:mdna:80]
[same as prior period, unchanged from 0001571996-17-000009:mdna:77]

[0001571996-17-000020:mdna:81]
|  | Three Months Ended |  | Six Months Ended |
|  | August 4, 2017 |  |  |  | July 29, 2016 (a) |  | August 4, 2017 |  |  |  | July 29, 2016 (a) |
|  | Dollars |  | % ofNet Revenue |  | %Change |  | Dollars |  | % ofNet Revenue |  | Dollars |  | % ofNet Revenue |  | %Change |  | Dollars |  | % ofNet Revenue |
|  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 14,355 |  |  | 74.4 | % |  | 31 | % |  | $ | 10,961 |  |  | 83.8 | % |  | $ | 27,323 |  |  | 73.6 | % |  | 29 | % |  | $ | 21,144 |  |  | 83.5 | % |
| Services | 4,944 |  |  | 25.6 | % |  | 133 | % |  | 2,119 |  |  | 16.2 | % |  | 9,792 |  |  | 26.4 | % |  | 134 | % |  | 4,177 |  |  | 16.5 | % |
| Total net revenue | $ | 19,299 |  |  | 100.0 | % |  | 48 | % |  | $ | 13,080 |  |  | 100.0 | % |  | $ | 37,115 |  |  | 100.0 | % |  | 47 | % |  | $ | 25,321 |  |  | 100.0 | % |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product (b) | $ | 1,977 |  |  | 13.8 | % |  | 35 | % |  | $ | 1,466 |  |  | 13.4 | % |  | $ | 3,486 |  |  | 12.8 | % |  | 22 | % |  | $ | 2,850 |  |  | 13.5 | % |
| Services (c) | 2,832 |  |  | 57.3 | % |  | 226 | % |  | 870 |  |  | 41.1 | % |  | 5,625 |  |  | 57.4 | % |  | 235 | % |  | 1,679 |  |  | 40.2 | % |
| Total gross margin | $ | 4,809 |  |  | 24.9 | % |  | 106 | % |  | $ | 2,336 |  |  | 17.9 | % |  | $ | 9,111 |  |  | 24.5 | % |  | 101 | % |  | $ | 4,529 |  |  | 17.9 | % |
| Operating expenses | $ | 5,788 |  |  | 30.0 | % |  | 155 | % |  | $ | 2,269 |  |  | 17.3 | % |  | $ | 11,590 |  |  | 31.2 | % |  | 152 | % |  | $ | 4,601 |  |  | 18.2 | % |
| Operating income (loss) | $ | (979 | ) |  | (5.1 | )% |  | NM |  | $ | 67 |  |  | 0.5 | % |  | $ | (2,479 | ) |  | (6.7 | )% |  | NM |  | $ | (72 | ) |  | (0.3 | )% |
| Net loss from continuing operations | $ | (978 | ) |  | (5.1 | )% |  | (273 | )% |  | $ | (262 | ) |  | (2.0 | )% |  | $ | (2,361 | ) |  | (6.4 | )% |  | (244 | )% |  | $ | (686 | ) |  | (2.7 | )% |
| Net income (loss) attributable to Dell Technologies Inc. | $ | (946 | ) |  | (4.9 | )% |  | NM |  | $ | 573 |  |  | 4.4 | % |  | $ | (2,280 | ) |  | (6.1 | )% |  | (463 | )% |  | $ | 628 |  |  | 2.5 | % |
| Non-GAAP Financial Information |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 14,405 |  |  | 73.4 | % |  | 31 | % |  | $ | 10,961 |  |  | 83.4 | % |  | $ | 27,428 |  |  | 72.6 | % |  | 30 | % |  | $ | 21,143 |  |  | 83.0 | % |
| Services | 5,229 |  |  | 26.6 | % |  | 139 | % |  | 2,184 |  |  | 16.6 | % |  | 10,377 |  |  | 27.4 | % |  | 140 | % |  | 4,321 |  |  | 17.0 | % |
| Total non-GAAP net revenue | $ | 19,634 |  |  | 100.0 | % |  | 49 | % |  | $ | 13,145 |  |  | 100.0 | % |  | $ | 37,805 |  |  | 100.0 | % |  | 48 | % |  | $ | 25,464 |  |  | 100.0 | % |
| Non-GAAP gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product (b) | $ | 2,969 |  |  | 20.6 | % |  | 88 | % |  | $ | 1,580 |  |  | 14.4 | % |  | $ | 5,498 |  |  | 20.0 | % |  | 79 | % |  | $ | 3,078 |  |  | 14.6 | % |
| Services (c) | 3,131 |  |  | 59.9 | % |  | 235 | % |  | 935 |  |  | 42.8 | % |  | 6,248 |  |  | 60.2 | % |  | 243 | % |  | 1,822 |  |  | 42.2 | % |
| Total non-GAAP gross margin | $ | 6,100 |  |  | 31.1 | % |  | 143 | % |  | $ | 2,515 |  |  | 19.1 | % |  | $ | 11,746 |  |  | 31.1 | % |  | 140 | % |  | $ | 4,900 |  |  | 19.2 | % |
| Non-GAAP operating expenses | $ | 4,548 |  |  | 23.2 | % |  | 159 | % |  | $ | 1,759 |  |  | 13.4 | % |  | $ | 8,997 |  |  | 23.8 | % |  | 150 | % |  | $ | 3,605 |  |  | 14.2 | % |
| Non-GAAP operating income | $ | 1,552 |  |  | 7.9 | % |  | 105 | % |  | $ | 756 |  |  | 5.8 | % |  | $ | 2,749 |  |  | 7.3 | % |  | 112 | % |  | $ | 1,295 |  |  | 5.1 | % |
| Non-GAAP net income from continuing operations | $ | 873 |  |  | 4.4 | % |  | 141 | % |  | $ | 362 |  |  | 2.8 | % |  | $ | 1,454 |  |  | 3.8 | % |  | 132 | % |  | $ | 626 |  |  | 2.5 | % |
| EBITDA | $ | 1,163 |  |  | 5.9 | % |  | 143 | % |  | $ | 672 |  |  | 3.6 | % |  | $ | 1,875 |  |  | 5.0 | % |  | 63 | % |  | $ | 1,151 |  |  | 4.5 | % |
| Adjusted EBITDA | $ | 1,866 |  |  | 9.5 | % |  | 190 | % |  | $ | 884 |  |  | 4.9 | % |  | $ | 3,433 |  |  | 9.1 | % |  | 125 | % |  | $ | 1,527 |  |  | 6.0 | % |

[0001571996-17-000020:mdna:82]
[same as prior period, unchanged from 0001571996-17-000009:mdna:79]

[0001571996-17-000020:mdna:83]
(a)    The amounts presented for the three and six months ended July 29, 2016 are different from those reported on our Form 10-Q for the quarterly period ended July 29, 2016 previously filed with the SEC, because we reclassified an immaterial amount of net income from discontinued operations to continuing operations to reflect the updated terms of the applicable divestitures as the result of continued negotiations and finalization of terms of the sale.

[0001571996-17-000020:mdna:84]
| (b) | Product gross margin percentages represent product gross margin as a percentage of product net revenue, and non-GAAP product gross margin as a percentage of non-GAAP product net revenue. |

[0001571996-17-000020:mdna:85]
| (c) | Services gross margin percentages represent services gross margin as a percentage of services net revenue, and non-GAAP services gross margin as a percentage of non-GAAP services net revenue. |

[0001571996-17-000020:mdna:86]
[same as prior period, unchanged from 0001571996-17-000009:mdna:82]

[0001571996-17-000020:mdna:87]
[same as prior period, unchanged from 0001571996-17-000009:mdna:116]

[0001571996-17-000020:mdna:88]
[same as prior period, unchanged from 0001571996-17-000009:mdna:84]

[0001571996-17-000020:mdna:89]
As a result of the EMC merger transaction completed on September 7, 2016 and its impact on the second quarter and first six months of Fiscal 2018, our results for the fiscal periods discussed below are not directly comparable.

[0001571996-17-000020:mdna:90]
[same as prior period, unchanged from 0001571996-17-000009:mdna:86]

[0001571996-17-000020:mdna:91]
During the second quarter and first six months of Fiscal 2018, our net revenue increased 48% and 47%, respectively.  During the second quarter and first six months of Fiscal 2018, our non-GAAP net revenue increased 49% and 48%, respectively.  The increase in net revenue and non-GAAP net revenue was primarily attributable to revenue from the EMC acquired businesses and, to a lesser extent, an increase in revenue from CSG.  The EMC merger transaction had an impact on the mix of revenue contributed by our business units.  CSG net revenue represented approximately 50% of our net revenue during the second quarter and first six months of Fiscal 2018.  In comparison, CSG net revenue represented a higher proportion of our revenue prior to the EMC merger transaction, accounting for approximately 70% of our net revenue during the second quarter and first six months of Fiscal 2017.

[0001571996-17-000020:mdna:92]
During the second quarter of Fiscal 2018, our operating loss was $1.0 billion, compared to an operating income of $0.1 billion during the second quarter of Fiscal 2017.  During the first six months of Fiscal 2018 and Fiscal 2017, our operating loss was $2.5 billion and $0.1 billion, respectively.  The increase in our operating loss for the second quarter and first six months of Fiscal 2018 was primarily attributable to an increase in amortization of intangible assets, purchase accounting adjustments, and compensation and benefits expense as a result of growth in our headcount related to the EMC merger transaction.  The increase in operating expenses was partially offset by the favorable impact of incremental gross margin from the EMC acquired businesses.

[0001571996-17-000020:mdna:93]
Our operating loss was impacted by purchase accounting adjustments associated with the EMC merger transaction and, to a lesser extent, the going-private transaction, amortization of intangible assets, transaction-related expenses, and other corporate expenses.  In aggregate, these items totaled $2.5 billion and $5.2 billion for the second quarter and first six months of Fiscal 2018, respectively.  In comparison, these items totaled $0.7 billion and $1.4 billion for the second quarter and first six months of Fiscal 2017, respectively, and in these periods purchase accounting adjustments related only to the going-private transaction.  Excluding these adjustments, non-GAAP operating income increased 105% to $1.6 billion during the second quarter of Fiscal 2018 and 112% to $2.7 billion during the first six months of Fiscal 2018.  The increase in non-GAAP operating income in both periods was primarily attributable to the favorable impact of incremental non-GAAP operating income from the EMC acquired businesses.

[0001571996-17-000020:mdna:94]
Cash provided by operating activities was $2.1 billion and $1.8 billion during the first six months of Fiscal 2018 and Fiscal 2017, respectively.  Operating cash flows during the first six months of Fiscal 2018 were driven by overall profitability, partially offset by cash paid for interest and taxes.  See "Market Conditions, Liquidity, and Capital Commitments" for further information on our cash flow metrics.

[0001571996-17-000020:mdna:95]
[same as prior period, unchanged from 0001571996-17-000009:mdna:91]

[0001571996-17-000020:mdna:96]
During the second quarter and first six months of Fiscal 2018, our net revenue increased 48% and 47%, respectively, primarily due to incremental revenue from the EMC acquired businesses, offset partially by an increase in purchase accounting adjustments as a result of the EMC merger transaction.  Our non-GAAP net revenue increased 49% and 48%, respectively, during the second quarter and first six months of Fiscal 2018 primarily due to the incremental net revenue from the EMC acquired businesses.  An increase of 7% and 6%, respectively, in CSG net revenue also contributed to higher net revenue and non-GAAP net revenue during the second quarter and first six months of Fiscal 2018, but to a lesser extent.  See "Business Unit Results — Client Solutions Group" for further information.

[0001571996-17-000020:mdna:97]
| • | Product Net Revenue — Product net revenue includes revenue from the sale of hardware products and Dell Technologies-owned software licenses. During the second quarter and first six months of Fiscal 2018, product net revenue increased 31% and 29%, respectively. During the second quarter and first six months of Fiscal 2018, non-GAAP product net revenue increased 31% and 30%, respectively. The increases in product net revenue and non-GAAP product net revenue were primarily due to the incremental product net revenue from the EMC acquired businesses. |

[0001571996-17-000020:mdna:98]
| • | Services Net Revenue — Services net revenue includes revenue from our services offerings, third-party software license sales, and support services related to Dell Technologies-owned software and hardware. During the second quarter and first six months of Fiscal 2018, services net revenue increased 133% and 134%, respectively. Non-GAAP services net revenue increased 139% and 140% during the second quarter and first six months of Fiscal 2018, respectively. These increases were primarily due to the incremental services net revenue from the EMC acquired businesses. |

[0001571996-17-000020:mdna:99]
[same as prior period, unchanged from 0001571996-17-000009:mdna:95]

[0001571996-17-000020:mdna:100]
From a geographical perspective, net revenue generated by sales to customers in all regions increased during the second quarter and first six months of Fiscal 2018 primarily as a result of the incremental net revenue from the EMC acquired businesses.  Our mix of revenues generated in the Americas, EMEA, and APJ did not change substantially as a result of the EMC merger transaction.

[0001571996-17-000020:mdna:101]
[same as prior period, unchanged from 0001571996-17-000009:mdna:97]

[0001571996-17-000020:mdna:102]
During the second quarter and first six months of Fiscal 2018, our gross margin increased 106% to $4.8 billion, and 101% to $9.1 billion, respectively.  During the second quarter and first six months of Fiscal 2018 our gross margin percentage increased 700 basis points to 24.9%, and 660 basis points to 24.5%, respectively.  The increases in our gross margin and gross margin percentage were primarily attributable to incremental gross margin from the EMC acquired businesses, which have higher gross margin percentages.  This increase was partially offset by the higher impact of purchase accounting adjustments and amortization of intangibles as a result of the EMC merger transaction.

[0001571996-17-000020:mdna:103]
Our gross margin for the second quarter and first six months of Fiscal 2018 included the effect of $1.3 billion and $2.6 billion, respectively, of amortization of intangibles and purchase accounting adjustments related to the EMC merger transaction and, to a lesser extent, the going-private transaction.  In comparison, the impact of purchase accounting and amortization of intangibles totaled $0.2 billion and $0.4 billion in the second quarter and first six months of Fiscal 2017, respectively, and in these periods related only to the going-private transaction.  Excluding these costs, transaction-related expenses, and other corporate expenses, non-GAAP gross margin for the second quarter increased 143% to $6.1 billion and non-GAAP gross margin percentage increased 1,200 basis points to 31.1%.  For the first six months of Fiscal 2018, non-GAAP gross margin increased 140% to $11.7 billion and non-GAAP gross margin percentage increased 1190 basis points to 31.1%.  The increase in non-GAAP gross margin and non-GAAP gross margin percentage was primarily attributable to incremental gross margin from the EMC acquired businesses, which have higher gross margin percentages.

[0001571996-17-000020:mdna:104]
| • | Products — During the second quarter of Fiscal 2018, product gross margin increased 35% to $2.0 billion and product gross margin percentage increased 40 basis points to 13.8%. The increase in product gross margin and product gross margin percentage was driven primarily by additional product gross margin from the EMC acquired businesses, which was largely offset by an increase in amortization of intangibles related to the EMC merger transaction. |

[0001571996-17-000020:mdna:105]
During the first six months of Fiscal 2018, product gross margin increased 22% to $3.5 billion and product gross margin percentage decreased 70 basis points to 12.8%.  The increase in product gross margin was driven primarily by additional product gross margin from the EMC acquired businesses, which was largely offset by an increase in amortization of intangibles related to the EMC merger transaction.  The decrease in product gross margin percentage was driven by an increase in amortization of intangibles and, to a lesser extent, a decrease in CSG product gross margin percentage primarily driven by the increase in component costs during the period.

[0001571996-17-000020:mdna:106]
During the second quarter of Fiscal 2018, non-GAAP product gross margin increased 88% to $3.0 billion and non-GAAP product gross margin percentage increased 620 basis points to 20.6%.  During the first six months of Fiscal 2018, non-GAAP product gross margin increased 79% to $5.5 billion, and non-GAAP product gross margin percentage increased 540 basis points to 20.0%.  The increases in non-GAAP product gross margin and non-GAAP product gross margin percentage were primarily attributable to the incremental product gross margin from the EMC acquired businesses, which have higher gross margin percentages.

[0001571996-17-000020:mdna:107]
In the second quarter of Fiscal 2018, we entered into a settlement agreement with a vendor to resolve a dispute regarding past pricing practices.  Our gross margin for the second quarter of Fiscal 2018 included a benefit of $68 million related to receipt of payment under the settlement.  Vendor settlements are allocated to our segments based on the relative amount of affected vendor products sold by each segment.  The $68 million settlement benefit was entirely allocated to CSG.

[0001571996-17-000020:mdna:108]
| • | Services — During the second quarter of Fiscal 2018, services gross margin increased 226% to $2.8 billion and services gross margin percentage increased 1,620 basis points to 57.3%. The increase in services gross margin and services gross margin percentage was primarily attributable to the incremental services gross margin from the EMC acquired businesses, which have higher gross margin percentages. Purchase accounting adjustments totaled $0.3 billion during the second quarter of Fiscal 2018, compared to $0.1 billion during the second quarter of Fiscal 2017. Excluding these costs, transaction-related expenses, and other corporate expenses, non-GAAP services gross margin increased 235% to $3.1 billion and non-GAAP services gross margin percentage increased 1,710 basis points to 59.9%. |

[0001571996-17-000020:mdna:109]
During the first six months of Fiscal 2018, services gross margin increased 235% to $5.6 billion and services gross margin percentage increased 1,720 basis points to 57.4%.  The increase in services gross margin and gross margin percentage was primarily attributable to the incremental services gross margin from the EMC acquired businesses, which have higher gross margin percentages.  Purchase accounting adjustments totaled $0.6 billion during the first six months of Fiscal 2018, compared to $0.1 billion during the first six months of Fiscal 2017.  Excluding these costs, transaction-related expenses, and other corporate expenses, non-GAAP services gross margin increased 243% to $6.2 billion and non-GAAP services gross margin percentage increased 1800 basis points to 60.2%.

[0001571996-17-000020:mdna:110]
[same as prior period, unchanged from 0001571996-17-000009:mdna:103]

[0001571996-17-000020:mdna:111]
[same as prior period, unchanged from 0001571996-17-000009:mdna:104]

[0001571996-17-000020:mdna:112]
The terms and conditions of our vendor rebate programs are largely based on product volumes and are generally negotiated either at the beginning of the annual or quarterly period, depending on the program.  The timing and amount of vendor rebates and other discounts we receive under the programs may vary from period to period, reflecting changes in the competitive environment.  We monitor our component costs and seek to address the effects of any changes to terms that might arise under our vendor rebate programs.  Our gross margins for the second quarter and first six months of Fiscal 2018 and Fiscal 2017 were not materially affected by any changes to the terms of our vendor rebate programs, as the amounts we received under these programs were generally stable relative to our total net cost.  We are not aware of any significant changes to vendor pricing or rebate programs that may impact our results in the near term.

[0001571996-17-000020:mdna:113]
In addition, we have pursued legal action against certain vendors and are currently involved in negotiations with other vendors regarding their past pricing practices.  We have negotiated settlements with some of these vendors and may have additional settlements in future periods.  These settlements are allocated to our segments based on the relative amount of affected vendor products sold by each segment.  As discussed above, a pricing settlement was recorded in the second quarter of Fiscal 2018 that benefited product gross margins by $68 million in the second quarter and first six months of Fiscal 2018.  No such settlements were recorded in the second quarter and first six months of Fiscal 2017 that would have a material impact on product gross margins in the current quarter or affect comparability with product gross margin in the second quarter and first six months of Fiscal 2018.

[0001571996-17-000020:mdna:114]
72

[0001571996-17-000020:mdna:115]
[same as prior period, unchanged from 0001571996-17-000009:mdna:107]

[0001571996-17-000020:mdna:116]
[same as prior period, unchanged from 0001571996-17-000009:mdna:108]

[0001571996-17-000020:mdna:117]
|  | Three Months Ended |  | Six Months Ended |
|  | August 4, 2017 |  |  |  | July 29, 2016 |  | August 4, 2017 |  |  |  | July 29, 2016 |
|  | Dollars |  | % ofNet Revenue |  | %Change |  | Dollars |  | % ofNet Revenue |  | Dollars |  | % ofNet Revenue |  | %Change |  | Dollars |  | % ofNet Revenue |
|  | (in millions, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative | $ | 4,695 |  |  | 24.3 | % |  | 132 | % |  | $ | 2,023 |  |  | 15.5 | % |  | $ | 9,364 |  |  | 25.2 | % |  | 129 | % |  | $ | 4,091 |  |  | 16.2 | % |
| Research and development | 1,093 |  |  | 5.7 | % |  | 344 | % |  | 246 |  |  | 1.9 | % |  | 2,226 |  |  | 6.0 | % |  | 336 | % |  | 510 |  |  | 2.0 | % |
| Total operating expenses | $ | 5,788 |  |  | 30.0 | % |  | 155 | % |  | $ | 2,269 |  |  | 17.4 | % |  | $ | 11,590 |  |  | 31.2 | % |  | 152 | % |  | $ | 4,601 |  |  | 18.2 | % |
| Other Financial Information |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP operating expenses | $ | 4,548 |  |  | 23.2 | % |  | 159 | % |  | $ | 1,759 |  |  | 13.4 | % |  | $ | 8,997 |  |  | 23.8 | % |  | 150 | % |  | $ | 3,605 |  |  | 14.2 | % |

[0001571996-17-000020:mdna:118]
During the second quarter and first six months of Fiscal 2018, total operating expenses increased 155% and 152%, respectively.  The increase in total operating expenses was primarily due to incremental operating costs of the EMC acquired businesses.  Our operating expenses include the impact of purchase accounting associated with the EMC merger transaction and, to a lesser extent, the going-private transaction, amortization of intangible assets, transaction-related expenses, and other corporate expenses.  In aggregate, these items totaled $1.2 billion and $0.5 billion for the second quarter of Fiscal 2018 and Fiscal 2017, respectively, and $2.6 billion and $1.0 billion for the first six months of Fiscal 2018 and Fiscal 2017, respectively.  Excluding these costs, total non-GAAP operating expenses for the second quarter and first six months of Fiscal 2018 increased 159% and 150%, respectively, primarily due to the incremental operating costs from the EMC acquired businesses.

[0001571996-17-000020:mdna:119]
| • | Selling, General, and Administrative — Selling, general, and administrative ("SG&A") expenses increased 132% and 129%, respectively, during the second quarter and first six months of Fiscal 2018. The increases in SG&A expenses were primarily driven by incremental operating costs of the EMC acquired businesses. |

[0001571996-17-000020:mdna:120]
| • | Research and Development — Research and development ("R&D") expenses are primarily composed of personnel-related expenses related to product development. R&D expenses as a percentage of net revenue for the second quarter and first six months of Fiscal 2018 were approximately 5.7% and 6.0%, respectively. In comparison, R&D expenses as a percentage of net revenue for the second quarter and first six months of Fiscal 2017 were 1.9% and 2.0%, respectively. The increases in R&D expenses were attributable to the expansion of our R&D capability through the EMC merger transaction. As our industry continues to change and as the needs of our customers evolve, we intend to support R&D initiatives to innovate and introduce new and enhanced solutions into the market. |

[0001571996-17-000020:mdna:121]
[same as prior period, unchanged from 0001571996-17-000009:mdna:113]

[0001571996-17-000020:mdna:122]
[same as prior period, unchanged from 0001571996-17-000009:mdna:148]

[0001571996-17-000020:mdna:123]
[same as prior period, unchanged from 0001571996-17-000009:mdna:114]

[0001571996-17-000020:mdna:124]
Our operating loss was $1.0 billion during the second quarter of Fiscal 2018, compared to an operating income of $0.1 billion during the second quarter of Fiscal 2017.  Operating loss was $2.5 billion during the first six months of Fiscal 2018 compared to $0.1 billion during the first six months of Fiscal 2017.  The increase in operating loss was primarily attributable to higher operating expenses, partially offset by increases in gross margin.  Our operating loss includes the impact of purchase accounting associated with the EMC merger transaction and, to a lesser extent, the going-private transaction, amortization of intangible assets, transaction-related expenses, and other corporate expenses.  In aggregate, these items totaled $2.5 billion and $0.7 billion for the first quarter of Fiscal 2018 and Fiscal 2017, respectively, and $5.2 billion and $1.4 billion for the first six months of Fiscal 2018 and Fiscal 2017, respectively.  Excluding these costs, non-GAAP operating income for the second quarter of Fiscal 2018 increased 105% to $1.6 billion, and non-GAAP operating income for the first six months of Fiscal 2018 increased 112% to $2.7 billion.  The increase in non-GAAP operating income was primarily attributable to an increase in gross margin, which was partially offset by higher operating expenses from the EMC acquired businesses.

[0001571996-17-000020:mdna:125]
[same as prior period, unchanged from 0001571996-17-000009:mdna:118]

[0001571996-17-000020:mdna:126]
[same as prior period, unchanged from 0001571996-17-000009:mdna:119]

[0001571996-17-000020:mdna:127]
|  | Three Months Ended |  | Six Months Ended |
|  | August 4, 2017 |  | July 29, 2016 |  | August 4, 2017 |  | July 29, 2016 |
|  | (in millions) |
| Interest and other, net: |  |  |  |  |  |  |  |  |  |  |
| Investment income, primarily interest | $ | 57 |  |  | $ | 15 |  |  | $ | 95 |  |  | $ | 24 |  |
| Gain on investments, net | 26 |  |  | 2 |  |  | 25 |  |  | 2 |  |
| Interest expense | (598 | ) |  | (352 | ) |  | (1,195 | ) |  | (515 | ) |
| Foreign exchange | (15 | ) |  | (13 | ) |  | (42 | ) |  | (55 | ) |
| Other | (15 | ) |  | (1 | ) |  | (1 | ) |  | (24 | ) |
| Total interest and other, net | $ | (545 | ) |  | $ | (349 | ) |  | $ | (1,118 | ) |  | $ | (568 | ) |

[0001571996-17-000020:mdna:128]
During the second quarter and first six months of Fiscal 2018, changes in interest and other, net were unfavorable by $196 million and $550 million, respectively, primarily due to an increase in interest expense from higher average debt balances from debt issued in connection with the EMC merger transaction.  See Note 7 of the Notes to the Condensed Consolidated Financial Statements included in this report for further information regarding our debt.

[0001571996-17-000020:mdna:129]
[same as prior period, unchanged from 0001571996-17-000009:mdna:122]

[0001571996-17-000020:mdna:130]
For the second quarter and first six months of Fiscal 2018 our effective income tax rates for continuing operations were 35.8% and 34.4%, respectively, on pre-tax losses from continuing operations of $1,524 million and $3,597 million, respectively.  For the second quarter and first six months of Fiscal 2017, our effective income tax rates for continuing operations were 7.1% and (7.2)%, respectively, on pre-tax losses from continuing operations of $282 million and $640 million, respectively.  The change in our effective income tax rate was primarily attributable to prior year tax charges recognized in the first six months of Fiscal 2017 related to the divestiture of Dell Services and DSG, as well as tax benefits from charges associated with the EMC merger transaction incurred in the first six months of Fiscal 2018, including purchase accounting adjustments, interest charges, and stock-based compensation expense.  See Note 2 of the Notes to the Condensed Consolidated Financial Statements included in this report for more information on the EMC merger transaction.  The income tax rate for future quarters of Fiscal 2018 will be impacted by the actual mix of jurisdictions in which income is generated.

[0001571996-17-000020:mdna:131]
[same as prior period, unchanged from 0001571996-17-000009:mdna:124]

[0001571996-17-000020:mdna:132]
For further discussion regarding tax matters, including the status of income tax audits, see Note 13 of the Notes to the Condensed Consolidated Financial Statements included in this report.

[0001571996-17-000020:mdna:133]
[same as prior period, unchanged from 0001571996-17-000009:mdna:126]

[0001571996-17-000020:mdna:134]
During the second quarter and first six months of Fiscal 2018, net loss from continuing operations increased 273% to a net loss of $1.0 billion and 244% to a net loss of $2.4 billion, respectively.  The increase in net loss from continuing operations was primarily attributable to an increase in operating loss and to an increase in interest and other, net expense.  The effect of these factors was partially offset by an increase in tax benefit during the periods.  See Note 13 of the Notes to the Condensed Consolidated Financial Statements included in this report for more information regarding our effective tax rate.

[0001571996-17-000020:mdna:135]
Net loss from continuing operations for the second quarter and first six months of Fiscal 2018 included amortization of intangible assets, the impact of purchase accounting, transaction-related expenses, and other corporate expenses.  Excluding these costs, non-GAAP net income from continuing operations increased 141% to $0.9 billion and 132% to $1.5 billion during the second quarter and first six months of Fiscal 2018, respectively.  These increases in non-GAAP net income from continuing operations were primarily attributable to increases in operating income, the effects of which were partially offset by increases in interest and other, net expense.

[0001571996-17-000020:mdna:136]
[same as prior period, unchanged from 0001571996-17-000009:mdna:129]

[0001571996-17-000020:mdna:137]
During the second quarter and first six months of Fiscal 2018, net loss attributable to non-controlling interests was $32 million and $81 million, respectively, which primarily consisted of net loss attributable to non-controlling interest in VMware, Inc. of $27 million and $72 million, respectively.  During the second quarter and first six months of Fiscal 2017, Dell Technologies had an immaterial amount of non-controlling interest related to SecureWorks, which completed a registered underwritten initial public offering of its Class A common stock on April 27, 2016.  For more information about our non-controlling interests, see Note 15 of the Notes to the Condensed Consolidated Financial Statements included in this report.

[0001571996-17-000020:mdna:138]
[same as prior period, unchanged from 0001571996-17-000009:mdna:131]

[0001571996-17-000020:mdna:139]
Net loss attributable to Dell Technologies Inc. represents net income/loss from continuing operations, an adjustment for non-controlling interests, and, in Fiscal 2017, an adjustment for discontinued operations.  During the second quarter and first six months of Fiscal 2018, net loss attributable to Dell Technologies Inc. was $0.9 billion and 2.3 billion, respectively, compared to net income attributable to Dell Technologies Inc. of $0.6 billion during both the second quarter and first six months of Fiscal 2017.  These increases in net loss attributable to Dell Technologies Inc. were primarily attributable to an increase in net loss from continuing operations and the absence of income from our discontinued operations in Fiscal 2018, due to the completion of the divestiture transactions in Fiscal 2017.  For more information regarding our discontinued operations, see Note 3 of the Notes to the Condensed Consolidated Financial Statements included in this report.

[0001571996-17-000020:mdna:140]
75

[0001571996-17-000020:mdna:141]
[same as prior period, unchanged from 0001571996-17-000009:mdna:134]

[0001571996-17-000020:mdna:142]
[same as prior period, unchanged from 0001571996-17-000009:mdna:135]

[0001571996-17-000020:mdna:143]
[same as prior period, unchanged from 0001571996-17-000009:mdna:136]

[0001571996-17-000020:mdna:144]
[same as prior period, unchanged from 0001571996-17-000009:mdna:137]

[0001571996-17-000020:mdna:145]
|  | Three Months Ended |  | Six Months Ended |
|  | August 4, 2017 |  | % Change |  | July 29, 2016 |  | August 4, 2017 |  | % Change |  | July 29, 2016 |
|  | (in millions, except percentages) |
| Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 7,196 |  |  | 6% |  | $ | 6,798 |  |  | $ | 13,546 |  |  | 5 | % |  | $ | 12,943 |  |
| Consumer | 2,655 |  |  | 10% |  | 2,422 |  |  | 5,361 |  |  | 11 | % |  | 4,848 |  |
| Total CSG net revenue | $ | 9,851 |  |  | 7% |  | $ | 9,220 |  |  | $ | 18,907 |  |  | 6 | % |  | $ | 17,791 |  |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| CSG operating income | $ | 566 |  |  | 17% |  | $ | 484 |  |  | $ | 940 |  |  | 8 | % |  | $ | 869 |  |
| % of segment net revenue | 5.7 | % |  |  |  | 5.2 | % |  | 5.0 | % |  |  |  | 4.9 | % |

[0001571996-17-000020:mdna:146]
Net Revenue — During the second quarter and first six months of Fiscal 2018, CSG net revenue increased 7% and 6%, respectively, driven by an increase in both commercial and consumer net revenue.  The increases in CSG net revenue were primarily driven by increases in units sold as we benefited from a general improvement in customer demand for our products, which favored premium notebooks and workstations.  CSG revenue also benefited from an increase in overall average selling price, particularly in consumer, as we managed our pricing in response to the cost environment during the period.  From a geographical perspective, net revenue attributable to CSG increased across all regions during the second quarter and first six months of Fiscal 2018.

[0001571996-17-000020:mdna:147]
Operating Income — During the second quarter and first six months of Fiscal 2018, CSG operating income as a percentage of net revenue increased 50 basis points to 5.7%, and 10 basis points to 5.0%, respectively.  The increases in our operating income percentage included a $68 million favorable impact from a vendor pricing settlement received during the second quarter of Fiscal 2018, which resulted in an incremental benefit of 70 basis points and 40 basis points to our operating income percentage during the second quarter and first six months of Fiscal 2018, respectively.  Excluding the benefit of the vendor settlement to operating income, we experienced an overall decline in our operating income percentage due to increases in certain component costs that we were not able to fully offset through pricing.  We expect that component cost increases will continue to be challenging in the near term.  The decline in our operating income percentage was partially offset by favorability in our operating expense percentage as we continue to manage our cost position.

[0001571996-17-000020:mdna:148]
[same as prior period, unchanged from 0001571996-17-000009:mdna:142]

[0001571996-17-000020:mdna:149]
[same as prior period, unchanged from 0001571996-17-000009:mdna:143]

[0001571996-17-000020:mdna:150]
|  | Three Months Ended |  | Six Months Ended |
|  | August 4, 2017 |  | % Change |  | July 29, 2016 |  | August 4, 2017 |  | % Change |  | July 29, 2016 |
|  | (in millions, except percentages) |
| Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Servers and networking | $ | 3,740 |  |  | 16% |  | $ | 3,237 |  |  | $ | 6,971 |  |  | 10% |  | $ | 6,312 |  |
| Storage | 3,666 |  |  | 576% |  | 542 |  |  | 7,351 |  |  | 581% |  | 1,080 |  |
| Total ISG net revenue | $ | 7,406 |  |  | 96% |  | $ | 3,779 |  |  | $ | 14,322 |  |  | 94% |  | $ | 7,392 |  |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| ISG operating income | $ | 430 |  |  | 43% |  | $ | 300 |  |  | $ | 753 |  |  | 53% |  | $ | 492 |  |
| % of segment net revenue | 5.8 | % |  |  |  | 7.9 | % |  | 5.3 | % |  |  |  | 6.7 | % |

[0001571996-17-000020:mdna:151]
Net Revenue — During the second quarter and first six months of Fiscal 2018, ISG net revenue increased 96% and 94%, respectively.  The increases in ISG revenue during the second quarter and first six months of Fiscal 2018 were primarily due to incremental storage net revenue associated with the acquired EMC storage business.  We are experiencing reduced demand in ISG for certain elements of our storage portfolio, particularly traditional midrange storage offerings.  Midrange products are generally defined as those products priced between $25,000-$250,000.  We are addressing this dynamic through investments in our go-to-market capability and product enhancements.  Revenue from servers and networking during the second quarter and first six months of Fiscal 2018 increased 16% and 10%, respectively, primarily resulting from an increase in sale of PowerEdge units, and an increase in average selling prices of PowerEdge as we managed our pricing in response to the current component cost environment.

[0001571996-17-000020:mdna:152]
From a geographical perspective, during the second quarter and first six months of Fiscal 2018, ISG net revenue increased in all regions due to the incremental revenue from the EMC acquired storage business.  The EMC acquired storage business operates on a world-wide basis with a geographic mix similar to that of the legacy Dell ISG business.

[0001571996-17-000020:mdna:153]
Operating Income — During the second quarter and first six months of Fiscal 2018, ISG operating income as a percentage of net revenue decreased 210 basis points to 5.8%, and 140 basis points to 5.3%, respectively.  While the acquired EMC storage business contributed higher gross margin overall, we experienced gross margin pressure due to changing product mix within ISG as well as component cost inflation, which we expect to continue in the near term.  ISG operating income also was affected by increased operating expenses reflecting larger investments in sales and research and development.

[0001571996-17-000020:mdna:154]
[same as prior period, unchanged from 0001571996-17-000009:mdna:183]

[0001571996-17-000020:mdna:155]
[same as prior period, unchanged from 0001571996-17-000009:mdna:149]

[0001571996-17-000020:mdna:156]
[same as prior period, unchanged from 0001571996-17-000009:mdna:150]

[0001571996-17-000020:mdna:157]
|  | Three Months Ended |  | Six Months Ended |
|  | August 4, 2017 |  | % Change |  | July 29, 2016 |  | August 4, 2017 |  | % Change |  | July 29, 2016 |
|  | (in millions, except percentages) |
| Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| VMware net revenue | $ | 1,907 |  |  | NA |  | $ | — |  |  | $ | 3,643 |  |  | NA |  | $ | — |  |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| VMware operating income | $ | 561 |  |  | NA |  | $ | — |  |  | $ | 1,047 |  |  | NA |  | $ | — |  |
| % of segment net revenue | 29.4 | % |  |  |  | NA |  | 28.7 | % |  |  |  | NA |

[0001571996-17-000020:mdna:158]
Net Revenue — VMware net revenue during the second quarter and first six months of Fiscal 2018 primarily consisted of revenue from the sale of software licenses under perpetual licenses, related software maintenance and support, training, consulting services, and hosted services.  VMware net revenue for the second quarter of Fiscal 2018 grew 10% relative to the first quarter of Fiscal 2018, benefiting from balanced performance in all major geographies and broad strength across the product portfolio, particularly in our emerging product offerings.

[0001571996-17-000020:mdna:159]
From a geographical perspective, approximately half of VMware net revenue during the second quarter and first six months of Fiscal 2018 was generated from sales to customers in the United States.

[0001571996-17-000020:mdna:160]
Operating Income — During the second quarter and first six months of Fiscal 2018, VMware operating income as a percentage of net revenue was 29.4% and 28.7%, respectively.

[0001571996-17-000020:mdna:161]
[same as prior period, unchanged from 0001571996-17-000009:mdna:155]

[0001571996-17-000020:mdna:162]
[same as prior period, unchanged from 0001571996-17-000009:mdna:156]

[0001571996-17-000020:mdna:163]
We sell products and services directly to customers and through a variety of sales channels, including retail distribution.  Our accounts receivable, net, was $9.7 billion and $9.4 billion as of August 4, 2017 and February 3, 2017, respectively.  We maintain an allowance for doubtful accounts to cover receivables that may be deemed uncollectible.  The allowance for losses is based on a provision for accounts that are collectively evaluated based on historical bad debt experience as well as specific identifiable customer accounts that are deemed at risk.  As of August 4, 2017 and February 3, 2017, the allowance for doubtful accounts was $80 million and $57 million, respectively.  Based on our assessment, we believe that we are adequately reserved for expected credit losses.  We monitor the aging of our accounts receivable and continue to take actions to reduce our exposure to credit losses.

[0001571996-17-000020:mdna:164]
[same as prior period, unchanged from 0001571996-17-000009:mdna:158]

[0001571996-17-000020:mdna:165]
Dell Financial Services, referred to as DFS, offers a wide range of financial services, including originating, collecting, and servicing customer receivables primarily related to the purchase of Dell products.  Following the closing of the EMC merger transaction, DFS began offering similar financial services related to the purchase of Dell EMC and VMware products.  In some cases, we originate financing activities for our commercial customers related to the purchase of third-party technology products that complement our portfolio of products and services.  New financing originations, which represent the amounts of financing provided by DFS to customers for equipment and related software and services, including third-party originations, were $1.6 billion and $1.0 billion for the second quarter of Fiscal 2018 and Fiscal 2017, respectively, and $2.7 billion and $1.9 billion for the first six months of Fiscal 2018 and Fiscal 2017, respectively.  As of August 4, 2017 and February 3, 2017, our financing receivables, net were $6.7 billion and $5.9 billion, respectively.

[0001571996-17-000020:mdna:166]
We have securitization programs to fund revolving loans and fixed-term leases and loans through consolidated special purpose entities, referred to as SPEs, which we account for as secured borrowings.  We transfer certain U.S. and European customer financing receivables to these SPEs, whose purpose is to facilitate the funding of customer receivables through financing arrangements with multi-seller conduits that issue asset-backed debt securities in the capital markets and to private investors.  During the second quarter of Fiscal 2018 and Fiscal 2017, we transferred $1.0 billion and $0.8 billion, respectively, to these SPEs, and during the first six months of Fiscal 2018 and Fiscal 2017, we transferred $1.9 billion and $1.4 billion, respectively, to the SPEs.  The structured financing debt related to all of our securitization programs included as secured borrowing was $3.6 billion and $3.1 billion as of August 4, 2017 and February 3, 2017, respectively.  In addition, the carrying amount of the corresponding financing receivables was $4.2 billion and $3.6 billion as of August 4, 2017 and February 3, 2017, respectively.  As a result of the EMC merger transaction, we are expanding our existing securitization programs to allow for additional funding of customer receivables in the capital markets.

[0001571996-17-000020:mdna:167]
We maintain an allowance to cover expected financing receivable credit losses and evaluate credit loss expectations based on our total portfolio.  For the second quarter of Fiscal 2018 and Fiscal 2017, the principal charge-off rate for our total portfolio was 1.8% and 2.0%, respectively.  For the first six months of Fiscal 2018 and Fiscal 2017, the principal charge-off rate for our total portfolio was 1.7% and 2.1%, respectively.  The credit quality of our financing receivables has improved in recent years due to an overall improvement in the credit environment and as the mix of high-quality commercial accounts in our portfolio has increased.  We expect that trend to continue with increased commercial customer volume resulting from the EMC merger transaction.  The allowance for losses is determined based on various factors, including historical and anticipated experience, past due receivables, receivable type, and customer risk profile.  At August 4, 2017 and February 3, 2017, the allowance for financing receivable losses was $135 million and $143 million, respectively.  In general, the loss rates on our financing receivables have improved over the periods presented.  We expect relatively stable loss rates in future periods, with movements in these rates being primarily driven by seasonality and a continued shift in portfolio composition to lower risk commercial assets.  We continue to monitor broader economic indicators and their potential impact on future loss performance.  We have an extensive process to manage our exposure to customer credit risk, including active management of credit lines and our collection activities.  We also sell selected fixed-term financing receivables to unrelated third parties on a periodic basis, primarily to manage certain concentrations of customer credit exposure.  Based on our assessment of the customer financing receivables, we believe that we are adequately reserved.

[0001571996-17-000020:mdna:168]
[same as prior period, unchanged from 0001571996-17-000009:mdna:162]

[0001571996-17-000020:mdna:169]
[same as prior period, unchanged from 0001571996-17-000009:mdna:201]

[0001571996-17-000020:mdna:170]
[same as prior period, unchanged from 0001571996-17-000009:mdna:163]

[0001571996-17-000020:mdna:171]
[same as prior period, unchanged from 0001571996-17-000009:mdna:164]

[0001571996-17-000020:mdna:172]
Our total deferred revenue was $19.6 billion and $18.7 billion as of August 4, 2017 and February 3, 2017, respectively.  A majority of our deferred revenue as of August 4, 2017 is expected to be recognized over the next two years.

[0001571996-17-000020:mdna:173]
[same as prior period, unchanged from 0001571996-17-000009:mdna:166]

[0001571996-17-000020:mdna:174]
As of August 4, 2017, we had no off-balance sheet arrangements that have or are reasonably likely to have a current or future material effect on our financial condition or results of operations.

[0001571996-17-000020:mdna:175]
[same as prior period, unchanged from 0001571996-17-000009:mdna:212]

[0001571996-17-000020:mdna:176]
[same as prior period, unchanged from 0001571996-17-000009:mdna:169]

[0001571996-17-000020:mdna:177]
[same as prior period, unchanged from 0001571996-17-000009:mdna:170]

[0001571996-17-000020:mdna:178]
[same as prior period, unchanged from 0001571996-17-000009:mdna:171]

[0001571996-17-000020:mdna:179]
[same as prior period, unchanged from 0001571996-17-000009:mdna:172]

[0001571996-17-000020:mdna:180]
[same as prior period, unchanged from 0001571996-17-000009:mdna:173]

[0001571996-17-000020:mdna:181]
[same as prior period, unchanged from 0001571996-17-000009:mdna:174]

[0001571996-17-000020:mdna:182]
The impact of any credit adjustments related to our use of counterparties on our Condensed Consolidated Financial Statements included in this report has been immaterial.

[0001571996-17-000020:mdna:183]
[same as prior period, unchanged from 0001571996-17-000009:mdna:176]

[0001571996-17-000020:mdna:184]
To support our ongoing business operations, we rely on operating cash flows as our primary source of liquidity.  We monitor the efficiency of our balance sheet to ensure that we have adequate liquidity to support our strategic initiatives.  In addition to internally generated cash, we have access to other capital sources to finance our strategic initiatives and fund growth in our financing operations.  As of August 4, 2017, we had $9.2 billion of total cash and cash equivalents, the majority of which was held outside of the United States.  Our strategy is to deploy capital from any potential source, whether internally generated cash or debt, depending on the adequacy and availability of that source of capital and whether it can be accessed in a cost-effective manner.

[0001571996-17-000020:mdna:185]
[same as prior period, unchanged from 0001571996-17-000009:mdna:178]

[0001571996-17-000020:mdna:186]
The following table summarizes our cash and cash equivalents as well as our available borrowings as of August 4, 2017 and February 3, 2017:

[0001571996-17-000020:mdna:187]
|  | August 4, 2017 |  | February 3, 2017 |
|  | (in millions) |
| Cash and cash equivalents, and available borrowings: |  |  |  |
| Cash and cash equivalents (a) | $ | 9,213 |  |  | $ | 9,474 |  |
| Remaining available borrowings under the Revolving Credit Facility | 3,104 |  |  | 2,678 |  |
| Total cash, cash equivalents, and available borrowings | $ | 12,317 |  |  | $ | 12,152 |  |

[0001571996-17-000020:mdna:188]
[same as prior period, unchanged from 0001571996-17-000009:mdna:181]

[0001571996-17-000020:mdna:189]
(a)  Of the $9.2 billion of cash and cash equivalents as of August 4, 2017, $3.6 billion was held by VMware, Inc.

[0001571996-17-000020:mdna:190]
The Revolving Credit Facility has maximum aggregate borrowings of approximately $3.2 billion.  Available borrowings under the Revolving Credit Facility are reduced by draws on the facility as well as by outstanding letters of credit.  As of August 4, 2017, remaining available borrowings under this facility totaled approximately $3.1 billion.  These available borrowings may be used periodically for general corporate purposes.

[0001571996-17-000020:mdna:191]
We believe that our current cash and cash equivalents, along with cash that will be provided by future operations and borrowings expected to be available under the Revolving Credit Facility, will be sufficient over at least the next twelve months to fund our operations, capital expenditures, share repurchases, and debt service requirements.

[0001571996-17-000020:mdna:192]
[same as prior period, unchanged from 0001571996-17-000009:mdna:186]

[0001571996-17-000020:mdna:193]
The following table summarizes our outstanding debt as of August 4, 2017 and February 3, 2017:

[0001571996-17-000020:mdna:194]
|  | August 4, 2017 |  | February 3, 2017 |
|  | (in millions) |
| Outstanding Debt: |  |  |  |
| Structured financing debt | $ | 4,050 |  |  | $ | 3,464 |  |
| Senior Secured Credit Facilities and First Lien Notes | 31,107 |  |  | 31,638 |  |
| Unsecured Notes and Debentures | 2,453 |  |  | 2,453 |  |
| Senior Notes | 3,250 |  |  | 3,250 |  |
| EMC Notes | 5,500 |  |  | 5,500 |  |
| Margin Loan Facility | 2,000 |  |  | — |  |
| Bridge Facilities | 1,500 |  |  | 4,000 |  |
| Other | 86 |  |  | 51 |  |
| Total debt, principal amount | 49,946 |  |  | 50,356 |  |
| Carrying value adjustments | (886 | ) |  | (966 | ) |
| Total debt, carrying value | $ | 49,060 |  |  | $ | 49,390 |  |

[0001571996-17-000020:mdna:195]
To finance the EMC merger transaction, we issued an aggregate principal amount of $45.9 billion in new debt, which included proceeds from the sale of the First Lien Notes and Senior Notes, as well as borrowings under the Senior Secured Credit Facilities (including the Revolving Credit Facility), the Asset Sale Bridge Facility, the Margin Bridge Facility, and the VMware Bridge Facility at the closing of the transaction.  Additionally, on September 7, 2016, EMC had outstanding senior notes (the "EMC Notes") consisting of $2.5 billion aggregate principal amount of its 1.875% Notes due June 2018, $2.0 billion aggregate principal amount of its 2.650% Notes due June 2020 and $1.0 billion aggregate principal amount of its 3.375% Notes due June 2023.  The EMC Notes remain outstanding following the closing of the EMC merger transaction.

[0001571996-17-000020:mdna:196]
During the first quarter of Fiscal 2018, we refinanced the Term Loan B Facility to reduce the interest rate margin by 0.75% and to increase the outstanding principal amount by $0.5 billion.  We applied the proceeds from the Term Loan B Facility refinancing to repay $0.5 billion principal amount of the Margin Bridge Facility.  Additionally, during the first quarter of Fiscal 2018, we issued the Margin Loan Facility in the principal amount of $2.0 billion, and used the proceeds of the new facility to repay the Margin Bridge Facility.  Further, during the first six months of Fiscal 2018, we repaid approximately $0.6 billion principal amount of our term loan facilities, repaid $0.4 billion, net, under the Revolving Credit Facility, and issued an additional $0.6 billion, net, in structured financing debt to support the expansion of our financing receivables portfolio.

[0001571996-17-000020:mdna:197]
Our requirements for cash to pay principal and interest have increased significantly due to the borrowings that were required to finance the EMC merger transaction.  We or our affiliates, at our or their sole discretion, may purchase, redeem, prepay, refinance, or otherwise retire our outstanding indebtedness under the terms of such indebtedness at any time and from time to time, in open market or negotiated transactions with the holders of such indebtedness, as appropriate market conditions exist.

[0001571996-17-000020:mdna:198]
We balance the use of our securitization programs with working capital and other sources of liquidity to fund growth in our global financial services business.  Of the $49.9 billion in outstanding principal debt as of August 4, 2017, $5.8 billion, which includes $4.1 billion in structured financing debt, is used to fund this business.

[0001571996-17-000020:mdna:199]
Subsequent to the end of the second quarter of Fiscal 2018, VMware, Inc. issued public debt in the aggregate principal amount of $4.0 billion.  Upon closing, a portion of the net proceeds from the offering was used to repay certain intercompany promissory notes previously issued to EMC in the aggregate principal amount of $1.2 billion.  VMware, Inc. has disclosed that it intends to use the remaining net proceeds to fund additional repurchases of up to $1.0 billion of its Class A common stock over the next 12 months, and for general VMware, Inc. corporate purposes, including mergers and acquisitions and repaying other indebtedness.

[0001571996-17-000020:mdna:200]
VMware, Inc. and its subsidiaries are unrestricted subsidiaries for purposes of the existing debt of Dell Technologies.  Neither Dell Technologies nor any of its subsidiaries, other than VMware, Inc., is obligated to make payment on the VMware, Inc. public debt.  None of the net proceeds of such public debt will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.

[0001571996-17-000020:mdna:201]
See Note 7 of the Notes to the Condensed Consolidated Financial Statements included in this report for more information about our debt and our unrestricted subsidiaries.  See Note 21 of the Notes to the Condensed Consolidated Financial Statements included in this report for more information about subsequent events.

[0001571996-17-000020:mdna:202]
[same as prior period, unchanged from 0001571996-17-000009:mdna:195]

[0001571996-17-000020:mdna:203]
[same as prior period, unchanged from 0001571996-17-000009:mdna:196]

[0001571996-17-000020:mdna:204]
|  | Six Months Ended |
|  | August 4, 2017 |  | July 29, 2016 |
|  | (in millions) |
| Net change in cash from: |  |  |  |
| Operating activities | $ | 2,056 |  |  | $ | 1,815 |  |
| Investing activities | (1,290 | ) |  | (221 | ) |
| Financing activities | (1,075 | ) |  | (849 | ) |
| Effect of exchange rate changes on cash and cash equivalents | 48 |  |  | 52 |  |
| Change in cash and cash equivalents | $ | (261 | ) |  | $ | 797 |  |

[0001571996-17-000020:mdna:205]
Operating Activities — Cash provided by operating activities was $2.1 billion and $1.8 billion during the first six months of Fiscal 2018 and Fiscal 2017, respectively.  Operating cash flows during the first six months of Fiscal 2018 were driven by overall profitability, partially offset by cash paid for interest and taxes.

[0001571996-17-000020:mdna:206]
Investing Activities — Investing activities primarily consist of the maturities, sales, and purchases of investments, capital expenditures for property, plant, and equipment, and capitalized software development costs.  Cash used by investing activities was $1.3 billion and $0.2 billion during the first six months of Fiscal 2018 and Fiscal 2017, respectively.  The change in cash from investing activities was primarily driven by increased capital expenditures, capitalized software development costs, and purchases of investments.  Further, during the first six months of Fiscal 2018, we used $0.2 billion, net, in connection with the acquisition of businesses, primarily related to VMware, Inc.'s acquisition of Wavefront.  See Note 2 of the Notes to the Condensed Consolidated Financial Statements included in this report for more information about VMware, Inc.'s acquisitions.

[0001571996-17-000020:mdna:207]
Financing Activities — Financing activities primarily consist of the proceeds and repayments of debt and cash used to repurchase common stock.  Cash used by financing activities was $1.1 billion during the first six months of Fiscal 2018.  We repaid $0.6 billion principal amount of borrowings under our term loan facilities and repaid $0.4 billion, net, under the Revolving Credit Facility.  Additionally, we repurchased $0.4 billion of shares of Class V Common Stock under the programs described below and repurchased $0.2 billion of other shares of common stock for tax withholdings on vesting of equity awards.  In comparison, cash used in financing activities was $0.8 billion during the first six months of Fiscal 2017 and primarily consisted of $0.6 billion repayments of borrowings and related foreign currency derivative settlements.  Also during the first six months of Fiscal 2017, we paid $0.4 billion in dissenting shares obligation related to appraisal litigation from the going-private transaction.  See Note 7 and Note 17 of the Notes to the Condensed Consolidated Financial Statements included in this report for more information about our debt and share repurchase programs, respectively.

[0001571996-17-000020:mdna:208]
[same as prior period, unchanged from 0001571996-17-000009:mdna:202]

[0001571996-17-000020:mdna:209]
[same as prior period, unchanged from 0001571996-17-000009:mdna:203]

[0001571996-17-000020:mdna:210]
[same as prior period, unchanged from 0001571996-17-000009:mdna:204]

[0001571996-17-000020:mdna:211]
[same as prior period, unchanged from 0001571996-17-000009:mdna:205]

[0001571996-17-000020:mdna:212]
|  | Three Months Ended |
|  | August 4, 2017 |  | July 29, 2016 |
| Days of sales outstanding (a) | 49 |  |  | 41 |  |
| Days of supply in inventory (b) | 17 |  |  | 12 |  |
| Days in accounts payable (c) | (112 | ) |  | (120 | ) |
| Cash conversion cycle (d) | (46 | ) |  | (67 | ) |

[0001571996-17-000020:mdna:213]
[same as prior period, unchanged from 0001571996-17-000009:mdna:207]

[0001571996-17-000020:mdna:214]
| (a) | Days of sales outstanding, referred to as DSO, calculates the average collection period of our receivables. DSO is based on the ending net trade receivables and the most recent quarterly non-GAAP net revenue for each period. DSO also includes the effect of product costs related to customer shipments not yet recognized as revenue that are classified in other current assets, as we believe this provides a more relevant metric that aligns with actual sales activity in the quarter, regardless of revenue recognition under GAAP. DSO is calculated by adding accounts receivable, net of allowance for doubtful accounts, and customer shipments in transit and dividing that sum by average non-GAAP net revenue per day for the current quarter (90 days for the three months ended August 4, 2017 and July 29, 2016). As of August 4, 2017, DSO and days of customer shipments not yet recognized were 45 and 4 days, respectively. As of July 29, 2016, DSO and days of customer shipments not yet recognized were 36 and 5 days, respectively. |

[0001571996-17-000020:mdna:215]
| (b) | Days of supply in inventory, referred to as DSI, measures the average number of days from procurement to sale of our products. DSI is based on ending inventory and non-GAAP cost of goods sold for each period. DSI is calculated by dividing ending inventory by average non-GAAP cost of goods sold per day for the current quarter (90 days for the three months ended August 4, 2017 and July 29, 2016). |

[0001571996-17-000020:mdna:216]
| (c) | Days in accounts payable, referred to as DPO, calculates the average number of days our payables remain outstanding before payment. DPO is based on ending accounts payable and non-GAAP cost of goods sold for each period. DPO is calculated by dividing accounts payable by average non-GAAP cost of goods sold per day for the current quarter (90 days for the three months ended August 4, 2017 and July 29, 2016). |

[0001571996-17-000020:mdna:217]
[same as prior period, unchanged from 0001571996-17-000009:mdna:211]

[0001571996-17-000020:mdna:218]
84

[0001571996-17-000020:mdna:219]
The table below provides reconciliations of each non-GAAP financial measure used in calculating the DSO, DSI and DPO metrics to its most directly comparable GAAP financial measure:

[0001571996-17-000020:mdna:220]
|  | Three Months Ended |
|  | August 4, 2017 |  | July 29, 2016 |
|  | (in millions) |
| Cost of goods sold | $ | 14,490 |  |  | $ | 10,744 |  |
| Non-GAAP adjustments: |  |  |  |
| Impact of purchase accounting | (13 | ) |  | (14 | ) |
| Amortization of intangibles | (920 | ) |  | (101 | ) |
| Transaction-related expenses | (10 | ) |  | 4 |  |
| Other corporate expenses | (13 | ) |  | (3 | ) |
| Non-GAAP cost of goods sold | $ | 13,534 |  |  | $ | 10,630 |  |

[0001571996-17-000020:mdna:221]
For the three months ended August 4, 2017, changes in our cash conversion cycle were unfavorable by 21 days when compared to the three months ended July 29, 2016.  The changes were primarily attributable to the acquisition of EMC, which had a negative impact across all three components.  We experienced an eight day decrease in DPO, primarily driven by supplier payments terms of the EMC acquired businesses.  An eight day increase in DSO was primarily driven by differences in collections management from the EMC acquired businesses.  A five day increase in DSI was primarily the result of the longer inventory cycle associated with the EMC acquired product lines.  We are continuing the integration of the EMC acquired businesses and, as a result, our supplier arrangements, collection activities, and operating cycles will continue to evolve.  We believe our business model allows us to maintain an efficient cash conversion cycle, which compares favorably with that of others in our industry.

[0001571996-17-000020:mdna:222]
[same as prior period, unchanged from 0001571996-17-000009:mdna:216]

[0001571996-17-000020:mdna:223]
Capital Expenditures — During the first six months of Fiscal 2018 and Fiscal 2017, we spent $561 million and $235 million, respectively, on property, plant, and equipment.  These expenditures were primarily incurred in connection with our global expansion efforts and infrastructure investments made to support future growth.  Product demand, product mix, and the use of contract manufacturers, as well as ongoing investments in operating and information technology infrastructure, influence the level and prioritization of our capital expenditures.  Aggregate capital expenditures for Fiscal 2018, which will be primarily related to infrastructure investments and strategic initiatives, are currently expected to total approximately $1.3 billion.

[0001571996-17-000020:mdna:224]
[same as prior period, unchanged from 0001571996-17-000009:mdna:218]

[0001571996-17-000020:mdna:225]
Class V Common Stock Repurchases — On December 13, 2016, the board of directors approved a stock repurchase program under which we were authorized to use assets of the Class V Group to repurchase up to $500 million of shares of Class V Common Stock over a period of six months.  During the first quarter of Fiscal 2018, we repurchased 1.3 million shares of Class V Common Stock for $82 million pursuant to this initial authorization.

[0001571996-17-000020:mdna:226]
On March 27, 2017, the board of directors approved an amendment of the stock repurchase program which authorized us to use assets of the Class V Group to repurchase up to an additional $300 million of shares of Class V Common Stock over a period of an additional six months.  During the first six months of Fiscal 2018, we repurchased 4.6 million shares of Class V Common Stock for $300 million pursuant to the extended stock repurchase program.  On May 9, 2017, the program was completed.

[0001571996-17-000020:mdna:227]
VMware, Inc. Class A Common Stock Repurchases — On December 15, 2016, we entered into a stock purchase agreement with VMware, Inc., pursuant to which VMware, Inc. agreed to repurchase for cash $500 million of shares of VMware, Inc. Class A common stock from a subsidiary of Dell Technologies.  During the first quarter of Fiscal 2018, VMware, Inc. repurchased 1.4 million shares pursuant to this stock purchase agreement.

[0001571996-17-000020:mdna:228]
In January 2017, VMware, Inc.'s board of directors authorized the repurchase of up to an additional $1.2 billion of shares of VMware, Inc. Class A common stock through the end of Fiscal 2018.  On March 29, 2017, we entered into a new stock purchase agreement with VMware, Inc., pursuant to which VMware, Inc. agreed to repurchase for cash $300 million of shares of VMware, Inc. Class A common stock from a subsidiary of Dell Technologies.  During the first six months of Fiscal 2018, VMware, Inc. repurchased approximately 3.4 million shares of Class A common stock pursuant to the January 2017 authorization and the new stock purchase agreement.  We applied the proceeds from the sale to the repurchase of shares of our Class V Common Stock under the repurchase program described above.  On May 10, 2017, the sale transaction under the new stock purchase agreement was completed.  As of August 4, 2017, the cumulative authorized amount remaining for share repurchases by VMware, Inc. under the January 2017 authorization was $900 million.

[0001571996-17-000020:mdna:229]
For more information regarding share repurchase programs, see Note 17  and Note 21 of the Notes to the Condensed Consolidated Financial Statements included in this report, and "Part II — Item 2 — Unregistered Sales of Equity Securities and Use of Proceeds."

[0001571996-17-000020:mdna:230]
[same as prior period, unchanged from 0001571996-17-000009:mdna:226]

[0001571996-17-000020:mdna:231]
We utilize several suppliers to manufacture sub-assemblies for our products.  Our efficient supply chain management allows us to enter into flexible and mutually beneficial purchase arrangements with our suppliers in order to minimize inventory risk.  Consistent with industry practice, we acquire raw materials or other goods and services, including product components, by issuing to suppliers authorizations to purchase based on our projected demand and manufacturing needs.  These purchase orders are typically fulfilled within 30 days and are entered into during the ordinary course of business in order to establish best pricing and continuity of supply for our production.  Purchase orders are not included in purchase obligations as they typically represent our authorization to purchase rather than binding purchase obligations.

[0001571996-17-000020:mdna:232]
As of August 4, 2017, we had $2.7 billion, $0.3 billion, and $0.4 billion in purchase obligations for Fiscal 2018 (remaining six months), Fiscal 2019, and Fiscal 2020 and thereafter, respectively.

[0001571996-17-000020:mdna:233]
86
