# DELL 8-K — 0001571996-17-000017 filed 2017-09-07

## item codes, every 8-K on or before 2017-09-08

- 2017-09-07 0001571996-17-000017 — 2.02, 9.01
- 2017-08-24 0001571996-17-000014 — 8.01
- 2017-06-29 0001571996-17-000011 — 3.03, 5.07, 8.01, 9.01
- 2017-06-08 0001193125-17-197638 — 2.02, 9.01
- 2017-03-30 0001193125-17-102794 — 8.01
- 2017-03-30 0001193125-17-102777 — 2.02, 9.01
- 2017-03-09 0001193125-17-076981 — 1.01, 2.03, 9.01
- 2017-01-17 0001193125-17-011125 — 8.01
- 2016-12-15 0001193125-16-793722 — 8.01
- 2016-12-08 0001193125-16-787976 — 2.02, 9.01
- 2016-11-10 0001193125-16-765964 — 1.02, 8.01
- 2016-11-04 0001193125-16-760249 — 8.01
- 2016-09-13 0001193125-16-708600 — 3.02
- 2016-09-09 0001193125-16-706567 — 1.01, 1.02, 2.01, 2.03, 3.02, 3.03, 5.02, 9.01
- 2016-09-07 0001193125-16-703370 — 3.03, 5.07, 7.01, 8.01, 9.01
- 2016-09-06 0001193125-16-702057 — 2.02, 9.01
- 2016-08-31 0001193125-16-697268 — 8.01, 9.01
- 2016-08-26 0001193125-16-692921 — 8.01, 9.01
- 2016-07-11 0001193125-16-645610 — 8.01
- 2016-07-05 0001193125-16-641679 — 8.01
- 2016-06-22 0001193125-16-629055 — 1.01, 2.03, 8.01, 9.01
- 2016-06-21 0001193125-16-627071 — 8.01, 9.01
- 2016-06-10 0001193125-16-618483 — 2.02, 9.01
- 2016-06-09 0001193125-16-617893 — 8.01, 9.01

## late-filing notifications on or before 2017-09-08

- none on or before 2017-09-08

## item 2.02 — earnings release, exhibit 99.1

[0001571996-17-000017:8k_2_02:1]
EX-99.1
2
exhibit991-pressrelease.htm
EXHIBIT 99.1

[0001571996-17-000017:8k_2_02:2]
Exhibit

[0001571996-17-000017:8k_2_02:3]
Exhibit 99.1

[0001571996-17-000017:8k_2_02:4]
News Release

[0001571996-17-000017:8k_2_02:5]
Dell Technologies Reports Fiscal Year 2018 Second Quarter

[0001571996-17-000017:8k_2_02:6]
Financial Results

[0001571996-17-000017:8k_2_02:7]
ROUND ROCK, Texas - Sept. 7, 2017

[0001571996-17-000017:8k_2_02:8]
News summary:

[0001571996-17-000017:8k_2_02:9]
| • | Second quarter revenue of $19.3 billion, non-GAAP revenue of $19.6 billion |

[0001571996-17-000017:8k_2_02:10]
| • | Operating loss of $1.0 billion, non-GAAP operating income of $1.6 billion |

[0001571996-17-000017:8k_2_02:11]
| • | Cash flow from operations of $1.8 billion |

[0001571996-17-000017:8k_2_02:12]
| • | Today marks first anniversary of historic merger between Dell and EMC |

[0001571996-17-000017:8k_2_02:13]
Full story

[0001571996-17-000017:8k_2_02:14]
Dell Technologies (NYSE: DVMT) announces its fiscal 2018 second quarter results1. For the second quarter, consolidated revenue was $19.3 billion and non-GAAP revenue was $19.6 billion. During the quarter, the company generated an operating loss of $1.0 billion, with non-GAAP operating income of $1.6 billion. The company generated cash flow from operations of $1.8 billion.

[0001571996-17-000017:8k_2_02:15]
“Today we celebrate one year since the historic combination between Dell and EMC. We’ve experienced great progress in bringing together our family of businesses and offering our customers and partners the most comprehensive set of solutions,” said Tom Sweet, chief financial officer, Dell Technologies. “In the second quarter, we generated strong cash flow and made progress on our de-levering goal. We were pleased with the growth velocity of our client, server, hyperconverged and all-flash array offerings. We have the right strategy, portfolio and investments in place to deliver long-term growth.”

[0001571996-17-000017:8k_2_02:16]
Since Sept. 7, 2016, Dell Technologies has delivered significant results, including:

[0001571996-17-000017:8k_2_02:17]
| • | Combining two great companies, creating the essential IT infrastructure company with more than 140,000 employees |

[0001571996-17-000017:8k_2_02:18]
| • | Combining two salesforces into one powerful go-to-market motion and creating an integrated channel program, both of which are driving velocity and revenue synergies across all segments |

[0001571996-17-000017:8k_2_02:19]
| • | Expansion of the Dell Financial Services (DFS) portfolio, now the exclusive originator of Dell EMC business and the VMware preferred finance partner |

[0001571996-17-000017:8k_2_02:20]
| • | Industry leadership in newer and fast-growing categories, including all-flash and hyperconverged infrastructure |

[0001571996-17-000017:8k_2_02:21]
Fiscal second quarter 2018 results

[0001571996-17-000017:8k_2_02:22]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | August 4, 2017 |  | July 29, 2016 |  | Change |  | August 4, 2017 |  | July 29, 2016 |  | Change |
|  | (in millions, except percentages; unaudited) |
| Net revenue | $ | 19,299 |  |  | $ | 13,080 |  |  | 48% |  | $ | 37,115 |  |  | $ | 25,321 |  |  | 47% |
| Operating income (loss) | $ | (979 | ) |  | $ | 67 |  |  | NM |  | $ | (2,479 | ) |  | $ | (72 | ) |  | NM |
| Net loss from continuing operations | $ | (978 | ) |  | $ | (262 | ) |  | (273)% |  | $ | (2,361 | ) |  | $ | (686 | ) |  | (244)% |
| Non-GAAP net revenue | $ | 19,634 |  |  | $ | 13,145 |  |  | 49% |  | $ | 37,805 |  |  | $ | 25,464 |  |  | 48% |
| Non-GAAP operating income | $ | 1,552 |  |  | $ | 756 |  |  | 105% |  | $ | 2,749 |  |  | $ | 1,295 |  |  | 112% |
| Non-GAAP net income from continuing operations | $ | 873 |  |  | $ | 362 |  |  | 141% |  | $ | 1,454 |  |  | $ | 626 |  |  | 132% |
| Adjusted EBITDA | $ | 1,866 |  |  | $ | 884 |  |  | 111% |  | $ | 3,433 |  |  | $ | 1,527 |  |  | 125% |

[0001571996-17-000017:8k_2_02:23]
Information about Dell Technologies' use of non-GAAP financial information is provided under "Non-GAAP Financial Measures" below. All comparisons in this press release are year-over-year unless otherwise noted.

[0001571996-17-000017:8k_2_02:24]
Operating segments summary

[0001571996-17-000017:8k_2_02:25]
Client Solutions Group (Dell) continued to take share globally while growing profitably. Dell outperformed the market worldwide, experiencing 3.7 percent unit growth during the calendar quarter2. Revenue for the second fiscal quarter was $9.9 billion, up 7 percent year over year and the highest since the same quarter of fiscal 2015. Operating income was $566 million for the quarter, a 17 percent increase or 5.7 percent of revenue.

[0001571996-17-000017:8k_2_02:26]
Key highlights:

[0001571996-17-000017:8k_2_02:27]
| • | Increased PC shipments by 3.7 percent, with 18 consecutive quarters of year-over-year PC unit share growth and the highest market share since 20062 |

[0001571996-17-000017:8k_2_02:28]
| • | Strong notebook momentum and double-digit revenue growth across all high-end commercial and consumer product lines |

[0001571996-17-000017:8k_2_02:29]
| • | Ranked No. 1 workstation vendor worldwide3 |

[0001571996-17-000017:8k_2_02:30]
| • | No. 1 displays provider worldwide for the 16th consecutive quarter and double-digit revenue growth4 |

[0001571996-17-000017:8k_2_02:31]
Infrastructure Solutions Group (Dell EMC) generated $7.4 billion in revenue, up 7 percent quarter over quarter. Server and networking revenue was $3.7 billion, a quarter-over-quarter and year-over-year increase of 16 percent, and storage revenue was $3.7 billion. Operating income for the quarter was $430 million.

[0001571996-17-000017:8k_2_02:32]
Key highlights:

[0001571996-17-000017:8k_2_02:33]
| • | Continued triple-digit demand growth for hyperconverged portfolio, including VxRail, which has more than 2,000 customers and 14,000 nodes deployed to date |

[0001571996-17-000017:8k_2_02:34]
| • | Launched and shipped new 14G servers; strong overall server demand growth in each of the major regions |

[0001571996-17-000017:8k_2_02:35]
| • | Strong all-flash growth at scale, more than 2x the nearest competitor |

[0001571996-17-000017:8k_2_02:36]
| • | Double-digit demand growth in next-generation Isilon scale-out NAS with new Infinity architecture |

[0001571996-17-000017:8k_2_02:37]
| • | Strong demand for our flexible consumption and utility models, signing several large, multi-year strategic deals |

[0001571996-17-000017:8k_2_02:38]
VMware segment revenue for the second quarter was $1.9 billion, with operating income of $561 million, or 29.4 percent of revenue.

[0001571996-17-000017:8k_2_02:39]
Additional financial highlights

[0001571996-17-000017:8k_2_02:40]
The company ended the quarter with a cash and investments balance of $15.3 billion. In the second quarter, Dell Technologies paid down $1.0 billion of core debt. Additionally, subsequent to quarter-end, the company paid down the $1.5 billion bridge facility. Including these latest debt payments, the company has repaid approximately $9.5 billion of gross debt, excluding DFS-related debt, since closing the EMC transaction.

[0001571996-17-000017:8k_2_02:41]
Also since closing the EMC transaction, the company has repurchased a total of 19.7 million shares of Class V common stock for $1.1 billion, under both the previously announced Class V Group and DHI Group repurchase programs. The company also has announced its board has approved an amendment to the Class V Group repurchase program for up to an additional $300 million of repurchases over six months. This will be funded from proceeds of sales of VMware Class A common stock under a new stock purchase agreement with VMware.

[0001571996-17-000017:8k_2_02:42]
Conference call information

[0001571996-17-000017:8k_2_02:43]
As previously announced, the company will hold a conference call to discuss its second quarter performance today at 7 a.m. CDT. The conference call will be broadcast live over the internet and can be accessed at investors.delltechnologies.com. For those unable to listen to the live broadcast, an archived version will be available at the same location for 30 days.

[0001571996-17-000017:8k_2_02:44]
A slide presentation containing additional financial and operating information may be downloaded from Dell Technologies' website at investors.delltechnologies.com.

[0001571996-17-000017:8k_2_02:45]
About Dell Technologies

[0001571996-17-000017:8k_2_02:46]
Dell Technologies is a unique family of businesses that provides the essential infrastructure for organizations to build their digital future, transform IT and protect their most important asset, information. The company services customers of all sizes across 180 countries - ranging from 98 percent of the Fortune 500 to individual consumers - with the industry's most comprehensive and innovative portfolio from the edge to the core to the cloud.

[0001571996-17-000017:8k_2_02:47]
MEDIA CONTACTS:

[0001571996-17-000017:8k_2_02:48]
Dave Farmer

[0001571996-17-000017:8k_2_02:49]
(508) 293-7206

[0001571996-17-000017:8k_2_02:50]
dave.farmer@dell.com

[0001571996-17-000017:8k_2_02:51]
Lauren Lee

[0001571996-17-000017:8k_2_02:52]
(512) 728-4374

[0001571996-17-000017:8k_2_02:53]
lauren.lee@dell.com

[0001571996-17-000017:8k_2_02:54]
INVESTOR RELATIONS CONTACTS:

[0001571996-17-000017:8k_2_02:55]
Karen Litzler-Hollier

[0001571996-17-000017:8k_2_02:56]
(512) 728-0388

[0001571996-17-000017:8k_2_02:57]
karen.litzler-hollie@dell.com

[0001571996-17-000017:8k_2_02:58]
Hall Butler

[0001571996-17-000017:8k_2_02:59]
(512) 723-4963

[0001571996-17-000017:8k_2_02:60]
hall.butler@dell.com

[0001571996-17-000017:8k_2_02:61]
# # #

[0001571996-17-000017:8k_2_02:62]
Copyright © 2017 Dell Inc. or its subsidiaries. All Rights Reserved. Dell, Dell Inc. and the Dell logo are trademarks of Dell Technologies in the United States and/or other jurisdictions. All other marks and names mentioned herein may be trademarks of their respective companies.

[0001571996-17-000017:8k_2_02:63]
1 Due to the EMC transaction and to a lesser extent the Dell going-private transaction, significant non-cash bridging items will remain between GAAP and non-GAAP results for the next few years. Prior-year historical Dell Technologies financials do not include EMC historical results, thereby impacting most year-over-year comparisons

[0001571996-17-000017:8k_2_02:64]
2 IDC Worldwide Quarterly Personal Computing Device (PCD) Tracker CY17Q2

[0001571996-17-000017:8k_2_02:65]
3 IDC WW Workstation Tracker CY17Q2

[0001571996-17-000017:8k_2_02:66]
4 DisplaySearch Desktop Monitor Market Tracker CY17Q1

[0001571996-17-000017:8k_2_02:67]
Non-GAAP Financial Measures

[0001571996-17-000017:8k_2_02:68]
This press release presents information about the Company's non-GAAP net revenue, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income from continuing operations, EBITDA and adjusted EBITDA, which are non-GAAP financial measures provided as a supplement to the results provided in accordance with generally accepted accounting principles in the United States of America ("GAAP"). A reconciliation of each of the foregoing historical non-GAAP financial measures to the most directly comparable historical GAAP financial measures is provided in the attached tables for each of the fiscal periods indicated.

[0001571996-17-000017:8k_2_02:69]
Special Note on Forward-Looking Statements:

[0001571996-17-000017:8k_2_02:70]
Dell Technologies' results or events in future periods could differ materially from those expressed or implied by these forward-looking statements because of risks, uncertainties, and other factors that include, but are not limited to, the following: competitive pressures; Dell Technologies' reliance on third-party suppliers for products and components, including reliance on single-source or limited-source suppliers; Dell Technologies' ability to achieve favorable pricing from its vendors; adverse global economic conditions and instability in financial markets; Dell Technologies' execution of its growth, business and acquisition strategies; the success of Dell Technologies' cost efficiency measures; Dell Technologies' ability to manage solutions and products and services transitions in an effective manner; Dell Technologies' ability to deliver high-quality products and services; Dell Technologies' foreign operations and ability to generate substantial non-U.S.net revenue; Dell

[0001571996-17-000017:8k_2_02:71]
Technologies' product, customer, and geographic sales mix, and seasonal sales trends; the performance of Dell Technologies' sales channel partners; access to the capital markets by Dell Technologies or its customers; weak economic conditions and additional regulation; counterparty default risks; the loss by Dell Technologies of any services contracts with its customers, including government contracts, and its ability to perform such contracts at its estimated costs; Dell Technologies' ability to develop and protect its proprietary intellectual property or obtain licenses to intellectual property developed by others on commercially reasonable and competitive terms; infrastructure disruptions, cyberattacks, or other data security breaches; Dell Technologies' ability to hedge effectively its exposure to fluctuations in foreign currency exchange rates and interest rates; expiration of tax holidays or favorable tax rate structures, or unfavorable outcomes in tax audits and other tax compliance matters; impairment of portfolio investments; unfavorable results of legal proceedings; increased costs and additional regulations and requirements as a result of Dell Technologies operation as a public company; Dell Technologies' ability to develop and maintain effective internal control over financial reporting; compliance requirements of changing environmental and safety laws; the effect of armed hostilities, terrorism, natural disasters, and public health issues; the costs, time, and effort required to be dedicated to the integration of the Dell and EMC businesses; the ability to realize the anticipated synergies from the merger with EMC; the ability to integrate EMC's technology, solutions, products, and services with those of Dell in an effective manner; the impact of the financial performance of VMware; and the market volatility of Dell Technologies' pension plan assets.

[0001571996-17-000017:8k_2_02:72]
This list of risks, uncertainties, and other factors is not complete. Dell Technologies discusses some of these matters more fully, as well as certain risk factors that could affect the Dell Technologies' business, financial condition, results of operations, and prospects, in its reports filed with the Securities and Exchange Commission, including Dell Technologies' Annual Report on Form 10-K for the fiscal year ended February 3, 2017, quarterly reports on Form 10-Q, and current reports on Form 8-K. These filings are available for review through the Securities and Exchange Commission's website at www.sec.gov. Any or all forward-looking statements Dell Technologies makes may turn out to be wrong and can be affected by inaccurate assumptions Dell Technologies might make or by known or unknown risks, uncertainties and other factors, including those identified in this press release. Accordingly, you should not place undue reliance on the forward-looking statements made in this press release, which speak only as of its date. Dell Technologies does not undertake to update, and expressly disclaims any duty to update, its forward-looking statements, whether as a result of circumstances or events that arise after the date they are made, new information, or otherwise.

[0001571996-17-000017:8k_2_02:73]
DELL TECHNOLOGIES INC.

[0001571996-17-000017:8k_2_02:74]
Condensed Consolidated Statements of Income (Loss) and Related Financial Highlights

[0001571996-17-000017:8k_2_02:75]
(in millions, except per share amounts and percentages; unaudited; continued on next page)

[0001571996-17-000017:8k_2_02:76]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | August 4, 2017 |  | July 29, 2016 |  | Change |  | August 4, 2017 |  | July 29, 2016 |  | Change |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Products | $ | 14,355 |  |  | $ | 10,961 |  |  | 31% |  | $ | 27,323 |  |  | $ | 21,144 |  |  | 29% |
| Services | 4,944 |  |  | 2,119 |  |  | 133% |  | 9,792 |  |  | 4,177 |  |  | 134% |
| Total net revenue | 19,299 |  |  | 13,080 |  |  | 48% |  | 37,115 |  |  | 25,321 |  |  | 47% |
| Cost of net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Products | 12,378 |  |  | 9,495 |  |  | 30% |  | 23,837 |  |  | 18,294 |  |  | 30% |
| Services | 2,112 |  |  | 1,249 |  |  | 69% |  | 4,167 |  |  | 2,498 |  |  | 67% |
| Total cost of net revenue | 14,490 |  |  | 10,744 |  |  | 35% |  | 28,004 |  |  | 20,792 |  |  | 35% |
| Gross margin | 4,809 |  |  | 2,336 |  |  | 106% |  | 9,111 |  |  | 4,529 |  |  | 101% |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative | 4,695 |  |  | 2,023 |  |  | 132% |  | 9,364 |  |  | 4,091 |  |  | 129% |
| Research and development | 1,093 |  |  | 246 |  |  | 344% |  | 2,226 |  |  | 510 |  |  | 336% |
| Total operating expenses | 5,788 |  |  | 2,269 |  |  | 155% |  | 11,590 |  |  | 4,601 |  |  | 152% |
| Operating income (loss) | (979 | ) |  | 67 |  |  | NM |  | (2,479 | ) |  | (72 | ) |  | NM |
| Interest and other, net | (545 | ) |  | (349 | ) |  | (56)% |  | (1,118 | ) |  | (568 | ) |  | (97)% |
| Loss from continuing operations before income taxes | (1,524 | ) |  | (282 | ) |  | (440)% |  | (3,597 | ) |  | (640 | ) |  | (462)% |
| Income tax provision (benefit) | (546 | ) |  | (20 | ) |  | NM |  | (1,236 | ) |  | 46 |  |  | NM |
| Net loss from continuing operations | (978 | ) |  | (262 | ) |  | (273)% |  | (2,361 | ) |  | (686 | ) |  | (244)% |
| Income from discontinued operations, net of income taxes | — |  |  | 834 |  |  | NA |  | — |  |  | 1,313 |  |  | NA |
| Net income (loss) | (978 | ) |  | 572 |  |  | (271)% |  | (2,361 | ) |  | 627 |  |  | (477)% |
| Less: Net loss attributable to non-controlling interests | (32 | ) |  | (1 | ) |  | NM |  | (81 | ) |  | (1 | ) |  | NM |
| Net income (loss) attributable to Dell Technologies Inc. | $ | (946 | ) |  | $ | 573 |  |  | (265)% |  | $ | (2,280 | ) |  | $ | 628 |  |  | (463)% |

[0001571996-17-000017:8k_2_02:77]
DELL TECHNOLOGIES INC.

[0001571996-17-000017:8k_2_02:78]
Condensed Consolidated Statements of Income (Loss) and Related Financial Highlights

[0001571996-17-000017:8k_2_02:79]
(in millions, except per share amounts and percentages; unaudited; continued)

[0001571996-17-000017:8k_2_02:80]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | August 4, 2017 |  | July 29, 2016 |  |  |  | August 4, 2017 |  | July 29, 2016 |  |  |
| Earnings (loss) per share attributable to Dell Technologies Inc. - basic: |  |  |  |  |  |  |  |  |  |  |  |
| Continuing operations - Class V Common Stock - basic | $ | 0.83 |  |  | $ | — |  |  |  |  | $ | 1.40 |  |  | $ | — |  |  |  |
| Continuing operations - DHI Group - basic | $ | (1.97 | ) |  | $ | (0.64 | ) |  |  |  | $ | (4.53 | ) |  | $ | (1.69 | ) |  |  |
| Discontinued operations - DHI Group - basic | $ | — |  |  | $ | 2.06 |  |  |  |  | $ | — |  |  | $ | 3.24 |  |  |  |
| Earnings (loss) per share attributable to Dell Technologies Inc. - diluted: |  |  |  |  |  |  |  |  |  |  |  |
| Continuing operations - Class V Common Stock - diluted | $ | 0.82 |  |  | $ | — |  |  |  |  | $ | 1.38 |  |  | $ | — |  |  |  |
| Continuing operations - DHI Group - diluted | $ | (1.97 | ) |  | $ | (0.64 | ) |  |  |  | $ | (4.54 | ) |  | $ | (1.69 | ) |  |  |
| Discontinued operations - DHI Group - diluted | $ | — |  |  | $ | 2.06 |  |  |  |  | $ | — |  |  | $ | 3.24 |  |  |  |
| Weighted-average shares outstanding: |  |  |  |  |  |  |  |  |  |  |  |
| Basic - Class V Common Stock | 203 |  |  | — |  |  |  |  | 205 |  |  | — |  |  |  |
| Diluted - Class V Common Stock | 203 |  |  | — |  |  |  |  | 205 |  |  | — |  |  |  |
| Basic - DHI Group | 566 |  |  | 405 |  |  |  |  | 566 |  |  | 405 |  |  |  |
| Diluted - DHI Group | 566 |  |  | 405 |  |  |  |  | 566 |  |  | 405 |  |  |  |
| Percentage of Total Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Gross margin | 25 | % |  | 18 | % |  |  |  | 25 | % |  | 18 | % |  |  |
| Selling, general, and administrative | 24 | % |  | 15 | % |  |  |  | 25 | % |  | 16 | % |  |  |
| Research and development | 6 | % |  | 2 | % |  |  |  | 6 | % |  | 2 | % |  |  |
| Operating expenses | 30 | % |  | 17 | % |  |  |  | 31 | % |  | 18 | % |  |  |
| Operating income (loss) | (5 | )% |  | 1 | % |  |  |  | (7 | )% |  | — | % |  |  |
| Loss from continuing operations before income taxes | (8 | )% |  | (2 | )% |  |  |  | (10 | )% |  | (3 | )% |  |  |
| Net loss from continuing operations | (5 | )% |  | (2 | )% |  |  |  | (6 | )% |  | (3 | )% |  |  |
| Income tax rate | 36 | % |  | 7 | % |  |  |  | 34 | % |  | (7 | )% |  |  |

[0001571996-17-000017:8k_2_02:81]
DELL TECHNOLOGIES INC.

[0001571996-17-000017:8k_2_02:82]
Condensed Consolidated Statements of Financial Position

[0001571996-17-000017:8k_2_02:83]
(in millions; unaudited)

[0001571996-17-000017:8k_2_02:84]
|  | August 4, 2017 |  | February 3, 2017 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 9,213 |  |  | $ | 9,474 |  |
| Short-term investments | 2,015 |  |  | 1,975 |  |
| Accounts receivable, net | 9,716 |  |  | 9,420 |  |
| Short-term financing receivables, net | 3,473 |  |  | 3,222 |  |
| Inventories, net | 2,594 |  |  | 2,538 |  |
| Other current assets | 5,194 |  |  | 4,144 |  |
| Total current assets | 32,205 |  |  | 30,773 |  |
| Property, plant, and equipment, net | 5,400 |  |  | 5,653 |  |
| Long-term investments | 4,022 |  |  | 3,802 |  |
| Long-term financing receivables, net | 3,199 |  |  | 2,651 |  |
| Goodwill | 39,407 |  |  | 38,910 |  |
| Intangible assets, net | 31,580 |  |  | 35,053 |  |
| Other non-current assets | 1,681 |  |  | 1,364 |  |
| Total assets | $ | 117,494 |  |  | $ | 118,206 |  |
| LIABILITIES, REDEEMABLE SHARES, AND STOCKHOLDERS’ EQUITY |
| Current liabilities: |  |  |  |
| Short-term debt | $ | 7,686 |  |  | $ | 6,329 |  |
| Accounts payable | 16,916 |  |  | 14,422 |  |
| Accrued and other | 6,798 |  |  | 7,119 |  |
| Short-term deferred revenue | 10,726 |  |  | 10,265 |  |
| Total current liabilities | 42,126 |  |  | 38,135 |  |
| Long-term debt | 41,374 |  |  | 43,061 |  |
| Long-term deferred revenue | 8,878 |  |  | 8,431 |  |
| Other non-current liabilities | 7,847 |  |  | 9,339 |  |
| Total liabilities | 100,225 |  |  | 98,966 |  |
| Redeemable shares | 333 |  |  | 231 |  |
| Stockholders' equity: |  |  |  |
| Total Dell Technologies Inc. stockholders’ equity | 10,947 |  |  | 13,243 |  |
| Non-controlling interests | 5,989 |  |  | 5,766 |  |
| Total stockholders' equity | 16,936 |  |  | 19,009 |  |
| Total liabilities, redeemable shares, and stockholders' equity | $ | 117,494 |  |  | $ | 118,206 |  |

[0001571996-17-000017:8k_2_02:85]
DELL TECHNOLOGIES INC.

[0001571996-17-000017:8k_2_02:86]
Condensed Consolidated Statements of Cash Flows

[0001571996-17-000017:8k_2_02:87]
(in millions; unaudited)

[0001571996-17-000017:8k_2_02:88]
|  | Three Months Ended |  | Six Months Ended |
|  | August 4, 2017 |  | July 29, 2016 |  | August 4, 2017 |  | July 29, 2016 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |
| Net income (loss) | $ | (978 | ) |  | $ | 572 |  |  | $ | (2,361 | ) |  | $ | 627 |  |
| Adjustments to reconcile net loss to net cash provided by operating activities | 2,794 |  |  | 1,306 |  |  | 4,417 |  |  | 1,188 |  |
| Change in cash from operating activities | 1,816 |  |  | 1,878 |  |  | 2,056 |  |  | 1,815 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |
| Investments: |  |  |  |  |  |  |  |
| Purchases | (1,701 | ) |  | (8 | ) |  | (2,260 | ) |  | (8 | ) |
| Maturities and sales | 1,085 |  |  | 6 |  |  | 2,058 |  |  | 18 |  |
| Capital expenditures | (316 | ) |  | (143 | ) |  | (561 | ) |  | (235 | ) |
| Proceeds from sale of facilities, land, and other assets | — |  |  | 15 |  |  | — |  |  | 19 |  |
| Capitalized software development costs | (98 | ) |  | — |  |  | (187 | ) |  | — |  |
| Collections on purchased financing receivables | 7 |  |  | 9 |  |  | 10 |  |  | 25 |  |
| Acquisition of businesses, net | (211 | ) |  | — |  |  | (223 | ) |  | — |  |
| Divestitures of businesses, net | 20 |  |  | — |  |  | — |  |  | — |  |
| Asset acquisitions, net | (86 | ) |  | — |  |  | (86 | ) |  | — |  |
| Asset dispositions, net | (41 | ) |  | — |  |  | (41 | ) |  | — |  |
| Other | — |  |  | (40 | ) |  | — |  |  | (40 | ) |
| Change in cash from investing activities | (1,341 | ) |  | (161 | ) |  | (1,290 | ) |  | (221 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |
| Payment of dissenting shares obligation | — |  |  | (446 | ) |  | — |  |  | (446 | ) |
| Proceeds from the issuance of common stock of subsidiaries | 72 |  |  | (2 | ) |  | 80 |  |  | 100 |  |
| Repurchases of DHI Group Common Stock | — |  |  | (2 | ) |  | (2 | ) |  | (2 | ) |
| Repurchases of Class V Common Stock | (54 | ) |  | — |  |  | (422 | ) |  | — |  |
| Issuance of common stock under employee plans | — |  |  | — |  |  | 1 |  |  | — |  |
| Payments for debt issuance costs | — |  |  | (13 | ) |  | (5 | ) |  | (15 | ) |
| Proceeds from debt | 1,335 |  |  | 1,596 |  |  | 4,776 |  |  | 2,148 |  |
| Repayments of debt | (2,155 | ) |  | (1,597 | ) |  | (5,309 | ) |  | (2,638 | ) |
| Repurchases for tax withholdings on vesting of equity awards | (68 | ) |  | (1 | ) |  | (194 | ) |  | (2 | ) |
| Other | — |  |  | 3 |  |  | — |  |  | 6 |  |
| Change in cash from financing activities | (870 | ) |  | (462 | ) |  | (1,075 | ) |  | (849 | ) |
| Effect of exchange rate changes on cash and cash equivalents | 54 |  |  | (21 | ) |  | 48 |  |  | 52 |  |
| Change in cash and cash equivalents | (341 | ) |  | 1,234 |  |  | (261 | ) |  | 797 |  |
| Cash and cash equivalents at beginning of the period, including amounts held for sale | 9,554 |  |  | 6,139 |  |  | 9,474 |  |  | 6,576 |  |
| Cash and cash equivalents at end of the period | $ | 9,213 |  |  | $ | 7,373 |  |  | $ | 9,213 |  |  | $ | 7,373 |  |
| Less: Cash included in current assets held for sale | — |  |  | 147 |  |  | — |  |  | 147 |  |
| Cash and cash equivalents from continuing operations | $ | 9,213 |  |  | $ | 7,226 |  |  | $ | 9,213 |  |  | $ | 7,226 |  |

[0001571996-17-000017:8k_2_02:89]
DELL TECHNOLOGIES INC.

[0001571996-17-000017:8k_2_02:90]
Segment Information

[0001571996-17-000017:8k_2_02:91]
(in millions, except percentages; unaudited; continued on next page)

[0001571996-17-000017:8k_2_02:92]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | August 4, 2017 |  | July 29, 2016 |  | Change |  | August 4, 2017 |  | July 29, 2016 |  | Change |
| Client Solutions Group (CSG): |  |  |  |  |  |  |  |  |  |  |  |
| Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 7,196 |  |  | $ | 6,798 |  |  | 6% |  | $ | 13,546 |  |  | $ | 12,943 |  |  | 5% |
| Consumer | 2,655 |  |  | 2,422 |  |  | 10% |  | 5,361 |  |  | 4,848 |  |  | 11% |
| Total CSG net revenue | $ | 9,851 |  |  | $ | 9,220 |  |  | 7% |  | $ | 18,907 |  |  | $ | 17,791 |  |  | 6% |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| CSG operating income | $ | 566 |  |  | $ | 484 |  |  | 17% |  | $ | 940 |  |  | $ | 869 |  |  | 8% |
| % of CSG net revenue | 6 | % |  | 5 | % |  |  |  | 5 | % |  | 5 | % |  |  |
| % of total segment operating income | 36 | % |  | 62 | % |  |  |  | 34 | % |  | 64 | % |  |  |
| Infrastructure Solutions Group (ISG): |  |  |  |  |  |  |  |  |  |  |  |
| Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Servers and networking | $ | 3,740 |  |  | $ | 3,237 |  |  | 16% |  | $ | 6,971 |  |  | $ | 6,312 |  |  | 10% |
| Storage | 3,666 |  |  | 542 |  |  | 576% |  | 7,351 |  |  | 1,080 |  |  | 581% |
| Total ISG net revenue | $ | 7,406 |  |  | $ | 3,779 |  |  | 96% |  | $ | 14,322 |  |  | $ | 7,392 |  |  | 94% |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| ISG operating income | $ | 430 |  |  | $ | 300 |  |  | 43% |  | $ | 753 |  |  | $ | 492 |  |  | 53% |
| % of ISG net revenue | 6 | % |  | 8 | % |  |  |  | 5 | % |  | 7 | % |  |  |
| % of total segment operating income | 28 | % |  | 38 | % |  |  |  | 27 | % |  | 36 | % |  |  |
| VMware: |  |  |  |  |  |  |  |  |  |  |  |
| Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Total VMware net revenue | $ | 1,907 |  |  | $ | — |  |  | NA |  | $ | 3,643 |  |  | $ | — |  |  | NA |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| VMware operating income | $ | 561 |  |  | $ | — |  |  | NA |  | $ | 1,047 |  |  | $ | — |  |  | NA |
| % of VMware net revenue | 29 | % |  | NA |  |  |  |  | 29 | % |  | NA |  |  |  |
| % of total segment operating income | 36 | % |  | NA |  |  |  |  | 38 | % |  | NA |  |  |  |

[0001571996-17-000017:8k_2_02:93]
DELL TECHNOLOGIES INC.

[0001571996-17-000017:8k_2_02:94]
Segment Information

[0001571996-17-000017:8k_2_02:95]
(in millions, except percentages; unaudited; continued)

[0001571996-17-000017:8k_2_02:96]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | August 4, 2017 |  | July 29, 2016 |  |  |  | August 4, 2017 |  | July 29, 2016 |  |  |
| Reconciliation to consolidated net revenue: |  |  |  |  |  |  |  |  |  |  |
| Reportable segment net revenue | $ | 19,164 |  |  | $ | 12,999 |  |  |  |  | $ | 36,872 |  |  | $ | 25,183 |  |  |  |
| Other businesses (a) | 472 |  |  | 118 |  |  |  |  | 934 |  |  | 228 |  |  |  |
| Unallocated transactions (b) | (2 | ) |  | 28 |  |  |  |  | (1 | ) |  | 53 |  |  |  |
| Impact of purchase accounting (c) | (335 | ) |  | (65 | ) |  |  |  | (690 | ) |  | (143 | ) |  |  |
| Total net revenue | $ | 19,299 |  |  | $ | 13,080 |  |  |  |  | $ | 37,115 |  |  | $ | 25,321 |  |  |  |
| Reconciliation to consolidated operating income (loss): |  |  |  |  |  |  |  |  |  |  |
| Reportable segment operating income | $ | 1,557 |  |  | $ | 784 |  |  |  |  | $ | 2,740 |  |  | $ | 1,361 |  |  |  |
| Other businesses (a) | 1 |  |  | (11 | ) |  |  |  | 4 |  |  | (27 | ) |  |  |
| Unallocated transactions (b) | (6 | ) |  | (17 | ) |  |  |  | 5 |  |  | (39 | ) |  |  |
| Impact of purchase accounting (c) | (406 | ) |  | (98 | ) |  |  |  | (829 | ) |  | (204 | ) |  |  |
| Amortization of intangibles | (1,740 | ) |  | (491 | ) |  |  |  | (3,516 | ) |  | (982 | ) |  |  |
| Transaction-related expenses (d) | (138 | ) |  | (72 | ) |  |  |  | (329 | ) |  | (129 | ) |  |  |
| Other corporate expenses (e) | (247 | ) |  | (28 | ) |  |  |  | (554 | ) |  | (52 | ) |  |  |
| Total operating income (loss) | $ | (979 | ) |  | $ | 67 |  |  |  |  | $ | (2,479 | ) |  | $ | (72 | ) |  |  |

[0001571996-17-000017:8k_2_02:97]
_________________

[0001571996-17-000017:8k_2_02:98]
| (a) | Other businesses consist of RSA Information Security, SecureWorks, Pivotal, and Boomi, and do not constitute a reportable segment, either individually or collectively, as the results of the businesses are not material to the Company's overall results and the businesses do not meet the criteria for reportable segments. |

[0001571996-17-000017:8k_2_02:99]
| (b) | Unallocated transactions includes long-term incentives, certain short-term incentive compensation expenses, and other corporate items that are not allocated to Dell Technologies' reportable segments. |

[0001571996-17-000017:8k_2_02:100]
| (c) | Impact of purchase accounting includes non-cash purchase accounting adjustments that are primarily related to the EMC merger transaction. |

[0001571996-17-000017:8k_2_02:101]
| (d) | Transaction-related expenses includes acquisition, integration, and divestiture related costs. |

[0001571996-17-000017:8k_2_02:102]
| (e) | Other corporate expenses includes severance and facility action costs as well as stock-based compensation expense. |

[0001571996-17-000017:8k_2_02:103]
SUPPLEMENTAL SELECTED NON-GAAP FINANCIAL MEASURES

[0001571996-17-000017:8k_2_02:104]
These tables present information about the Company’s non-GAAP net revenue, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income from continuing operations, EBITDA, and adjusted EBITDA, which are non-GAAP financial measures provided as a supplement to the results provided in accordance with generally accepted accounting principles in the United States of America (“GAAP”). A detailed discussion of Dell Technologies’ reasons for including these non-GAAP financial measures, the limitations associated with these measures, the items excluded from these measures, and our reason for excluding those items are presented in “Management’s Discussion and Analysis of Financial Condition and Results of Operations - Non-GAAP Financial Measures” in our periodic reports filed with the SEC. Dell Technologies encourages investors to review the non-GAAP discussion in conjunction with the presentation of non-GAAP financial measures.

[0001571996-17-000017:8k_2_02:105]
DELL TECHNOLOGIES INC.

[0001571996-17-000017:8k_2_02:106]
Selected Non-GAAP Financial Measures

[0001571996-17-000017:8k_2_02:107]
(in millions, except percentages; unaudited)

[0001571996-17-000017:8k_2_02:108]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | August 4, 2017 |  | July 29, 2016 |  | Change |  | August 4, 2017 |  | July 29, 2016 |  | Change |
| Non-GAAP net revenue | $ | 19,634 |  |  | $ | 13,145 |  |  | 49% |  | $ | 37,805 |  |  | $ | 25,464 |  |  | 48% |
| Non-GAAP gross margin | $ | 6,100 |  |  | $ | 2,515 |  |  | 143% |  | $ | 11,746 |  |  | $ | 4,900 |  |  | 140% |
| % of non-GAAP net revenue | 31 | % |  | 19 | % |  |  |  | 31 | % |  | 19 | % |  |  |
| Non-GAAP operating expenses | $ | 4,548 |  |  | $ | 1,759 |  |  | 159% |  | $ | 8,997 |  |  | $ | 3,605 |  |  | 150% |
| % of non-GAAP net revenue | 23 | % |  | 13 | % |  |  |  | 24 | % |  | 14 | % |  |  |
| Non-GAAP operating income | $ | 1,552 |  |  | $ | 756 |  |  | 105% |  | $ | 2,749 |  |  | $ | 1,295 |  |  | 112% |
| % of non-GAAP net revenue | 8 | % |  | 6 | % |  |  |  | 7 | % |  | 5 | % |  |  |
| Non-GAAP net income from continuing operations | $ | 873 |  |  | $ | 362 |  |  | 141% |  | $ | 1,454 |  |  | $ | 626 |  |  | 132% |
| % of non-GAAP net revenue | 4 | % |  | 3 | % |  |  |  | 4 | % |  | 2 | % |  |  |
| Adjusted EBITDA | $ | 1,866 |  |  | $ | 884 |  |  | 111% |  | $ | 3,433 |  |  | $ | 1,527 |  |  | 125% |
| % of non-GAAP net revenue | 10 | % |  | 7 | % |  |  |  | 9 | % |  | 6 | % |  |  |

[0001571996-17-000017:8k_2_02:109]
DELL TECHNOLOGIES INC.

[0001571996-17-000017:8k_2_02:110]
Reconciliation of Non-GAAP Financial Measures

[0001571996-17-000017:8k_2_02:111]
(in millions, except percentages; unaudited; continued on next page)

[0001571996-17-000017:8k_2_02:112]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | August 4, 2017 |  | July 29, 2016 |  | Change |  | August 4, 2017 |  | July 29, 2016 |  | Change |
| Net revenue | $ | 19,299 |  |  | $ | 13,080 |  |  | 48% |  | $ | 37,115 |  |  | $ | 25,321 |  |  | 47% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 335 |  |  | 65 |  |  |  |  | 690 |  |  | 143 |  |  |  |
| Non-GAAP net revenue | $ | 19,634 |  |  | $ | 13,145 |  |  | 49% |  | $ | 37,805 |  |  | $ | 25,464 |  |  | 48% |
| Gross margin | $ | 4,809 |  |  | $ | 2,336 |  |  | 106% |  | $ | 9,111 |  |  | $ | 4,529 |  |  | 101% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 348 |  |  | 79 |  |  |  |  | 713 |  |  | 168 |  |  |  |
| Amortization of intangibles | 920 |  |  | 101 |  |  |  |  | 1,870 |  |  | 202 |  |  |  |
| Transaction-related expenses | 10 |  |  | (4 | ) |  |  |  | 17 |  |  | (5 | ) |  |  |
| Other corporate expenses | 13 |  |  | 3 |  |  |  |  | 35 |  |  | 6 |  |  |  |
| Non-GAAP gross margin | $ | 6,100 |  |  | $ | 2,515 |  |  | 143% |  | $ | 11,746 |  |  | $ | 4,900 |  |  | 140% |
| Operating expenses | $ | 5,788 |  |  | $ | 2,269 |  |  | 155% |  | $ | 11,590 |  |  | $ | 4,601 |  |  | 152% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | (58 | ) |  | (19 | ) |  |  |  | (116 | ) |  | (36 | ) |  |  |
| Amortization of intangibles | (820 | ) |  | (390 | ) |  |  |  | (1,646 | ) |  | (780 | ) |  |  |
| Transaction-related expenses | (128 | ) |  | (76 | ) |  |  |  | (312 | ) |  | (134 | ) |  |  |
| Other corporate expenses | (234 | ) |  | (25 | ) |  |  |  | (519 | ) |  | (46 | ) |  |  |
| Non-GAAP operating expenses | $ | 4,548 |  |  | $ | 1,759 |  |  | 159% |  | $ | 8,997 |  |  | $ | 3,605 |  |  | 150% |
| Operating income (loss) | $ | (979 | ) |  | $ | 67 |  |  | NM |  | $ | (2,479 | ) |  | $ | (72 | ) |  | NM |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 406 |  |  | 98 |  |  |  |  | 829 |  |  | 204 |  |  |  |
| Amortization of intangibles | 1,740 |  |  | 491 |  |  |  |  | 3,516 |  |  | 982 |  |  |  |
| Transaction-related expenses | 138 |  |  | 72 |  |  |  |  | 329 |  |  | 129 |  |  |  |
| Other corporate expenses | 247 |  |  | 28 |  |  |  |  | 554 |  |  | 52 |  |  |  |
| Non-GAAP operating income | $ | 1,552 |  |  | $ | 756 |  |  | 105% |  | $ | 2,749 |  |  | $ | 1,295 |  |  | 112% |
| Net loss from continuing operations | $ | (978 | ) |  | $ | (262 | ) |  | (273)% |  | $ | (2,361 | ) |  | $ | (686 | ) |  | (244)% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 406 |  |  | 98 |  |  |  |  | 829 |  |  | 204 |  |  |  |
| Amortization of intangibles | 1,740 |  |  | 491 |  |  |  |  | 3,516 |  |  | 982 |  |  |  |
| Transaction-related expenses | 138 |  |  | 69 |  |  |  |  | 329 |  |  | 126 |  |  |  |
| Other corporate expenses | 247 |  |  | 28 |  |  |  |  | 554 |  |  | 52 |  |  |  |
| Aggregate adjustment for income taxes | (680 | ) |  | (62 | ) |  |  |  | (1,413 | ) |  | (52 | ) |  |  |
| Non-GAAP net income from continuing operations | $ | 873 |  |  | $ | 362 |  |  | 141% |  | $ | 1,454 |  |  | $ | 626 |  |  | 132% |

[0001571996-17-000017:8k_2_02:113]
DELL TECHNOLOGIES INC.

[0001571996-17-000017:8k_2_02:114]
Reconciliation of Non-GAAP Financial Measures

[0001571996-17-000017:8k_2_02:115]
(in millions, except percentages; unaudited; continued)

[0001571996-17-000017:8k_2_02:116]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | August 4, 2017 |  | July 29, 2016 |  | Change |  | August 4, 2017 |  | July 29, 2016 |  | Change |
| Net loss from continuing operations | $ | (978 | ) |  | $ | (262 | ) |  | (273)% |  | $ | (2,361 | ) |  | $ | (686 | ) |  | (244)% |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Interest and other, net | 545 |  |  | 349 |  |  |  |  | 1,118 |  |  | 568 |  |  |  |
| Income tax provision (benefit) | (546 | ) |  | (20 | ) |  |  |  | (1,236 | ) |  | 46 |  |  |  |
| Depreciation and amortization | 2,142 |  |  | 605 |  |  |  |  | 4,354 |  |  | 1,223 |  |  |  |
| EBITDA | $ | 1,163 |  |  | $ | 672 |  |  | 73% |  | $ | 1,875 |  |  | $ | 1,151 |  |  | 63% |
| EBITDA | $ | 1,163 |  |  | $ | 672 |  |  | 73% |  | $ | 1,875 |  |  | $ | 1,151 |  |  | 63% |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense | 208 |  |  | 19 |  |  |  |  | 409 |  |  | 33 |  |  |  |
| Impact of purchase accounting | 335 |  |  | 75 |  |  |  |  | 692 |  |  | 158 |  |  |  |
| Transaction-related expenses | 138 |  |  | 109 |  |  |  |  | 329 |  |  | 166 |  |  |  |
| Other corporate expenses | 22 |  |  | 9 |  |  |  |  | 128 |  |  | 19 |  |  |  |
| Adjusted EBITDA | $ | 1,866 |  |  | $ | 884 |  |  | 111% |  | $ | 3,433 |  |  | $ | 1,527 |  |  | 125% |
