# DELL note change history — 0001571996-20-000034 → 0001571996-20-000045


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-09-04):
[0001571996-20-000045:note_history:1]
Class Actions Related to the Class V Transaction — Four purported stockholders brought putative class action complaints arising out of the Class V transaction described in Note 1of the Notes to the Condensed Consolidated Financial Statements.  The actions were captioned Hallandale Beach Police and Fire Retirement Plan v. Michael Dell et al. (Civil Action No. 2018-0816-JTL), Howard Karp v. Michael Dell et al. (Civil Action No. 2019-0032-JTL), Miramar Police Officers’ Retirement Plan v. Michael Dell et al. (Civil Action No. 2019-0049-JTL), and Steamfitters Local 449 Pension Plan v. Michael Dell et al. (Civil Action No. 2019-0115-JTL).  The four actions were consolidated in the Delaware Chancery Court into In Re Dell Class V Litigation (Consol. C.A. No. 2018-0816-JTL), which names as defendants the Company’s board of directors and certain stockholders of the Company, including Michael S. Dell.  The plaintiffs generally allege that the defendants breached their fiduciary duties to the former holders of Class V Common Stock in connection with the Class V transaction by allegedly causing the Company to enter into a transaction that favored the interests of the controlling stockholders at the expense of such former stockholders.  The plaintiffs seek, among other remedies, a judicial declaration that the defendants breached their fiduciary duties and an award of damages, fees, and costs.  The plaintiffs filed an amended complaint in August 2019 making substantially similar allegations to those described above.  The defendants filed a motion to dismiss the action in September 2019.  The court denied the motion in June 2020 and the case has now moved to discovery.
  (was, 2020-06-08, similarity 0.9225):
[0001571996-20-000034:note_history:1]
Class Actions Related to the Class V Transaction — Four purported stockholders brought putative class action complaints arising out of the Class V transaction described in Note 1of the Notes to the Condensed Consolidated Financial Statements.  The actions were captioned Hallandale Beach Police and Fire Retirement Plan v. Michael Dell et al. (Civil Action No. 2018-0816-JTL), Howard Karp v. Michael Dell et al. (Civil Action No. 2019-0032-JTL), Miramar Police Officers’ Retirement Plan v. Michael Dell et al. (Civil Action No. 2019-0049-JTL), and Steamfitters Local 449 Pension Plan v. Michael Dell et al. (Civil Action No. 2019-0115-JTL).  The four actions were consolidated in the Delaware Chancery Court into In Re Dell Class V Litigation (Consol. C.A. No. 2018-0816-JTL), which names as defendants the Company’s board of directors and certain stockholders of the Company, including Michael S. Dell.  The plaintiffs generally allege that the defendants breached their fiduciary duties to the former holders of Class V Common Stock in connection with the Class V transaction by allegedly causing the Company to enter into a transaction that favored the interests of the controlling stockholders at the expense of such former stockholders.  The plaintiffs seek, among other remedies, a judicial declaration that the defendants breached their fiduciary duties and an award of damages, fees, and costs.  The plaintiffs filed an amended complaint in August 2019 making substantially similar allegations to those described above.  The defendants filed a motion to dismiss the action in September 2019.  The plaintiffs replied to the motion to dismiss in November 2019, and the defendants filed a reply in December 2019.  A hearing on the motion to dismiss was held on March 13, 2020.  The Court has taken this motion under consideration.

- added (2020-09-04):
[0001571996-20-000045:note_history:2]
Patent Litigation — On April 25, 2019, Cirba Inc. (“Cirba”) filed a lawsuit against VMware, Inc. in the United States District Court for the District of Delaware, alleging two patent infringement claims and three trademark infringement-related claims.  On May 6, 2019, Cirba filed a motion seeking a preliminary injunction tied to one of the two patents it alleges VMware, Inc. infringes.  Following a hearing on August 6, 2019, the Court denied Cirba’s preliminary injunction motion and set the case for trial in mid-January 2020.  On August 20, 2019, VMware, Inc. filed counterclaims against Cirba, asserting among other claims that Cirba is infringing four VMware, Inc. patents.  The Delaware Court severed those claims from the January 2020 trial on Cirba’s claims, and the trial on VMware, Inc.’s patent claims is currently set for September 2021.  The trial on Cirba’s claims in the Delaware court was completed on January 23, 2020, and on January 24, 2020, the jury returned a verdict finding that VMware, Inc. willfully infringed the two asserted patents and awarding approximately $237 million in damages.  The jury further found that VMware, Inc. was not liable on Cirba’s trademark infringement-related claims.  A total of $237 million was accrued for the Delaware action, which reflects the estimated losses that are considered both probable and reasonably estimable at this time.  The parties filed the post-trial motions in which VMware, Inc. moved to set aside the verdict and reduce the damages award, and Cirba moved for a permanent injunction, enhanced damages, setting of an ongoing royalty rate, and an award of pre-judgment and post-judgment interest and supplemental damages.  A hearing was held in the Delaware court on those motions on May 15, 2020, and the Delaware court has taken those motions under advisement.  VMware, Inc. intends to vigorously defend itself in this matter, including, if necessary, via an appeal.  Final resolution of this matter could be materially different from the amount accrued.  The amount accrued for this matter is included in Accrued and other in the Condensed Consolidated Statements of Financial Position as of July 31, 2020 and January 31, 2020, and the charge was classified in Selling, general and administrative in the Consolidated Statements of Income (Loss) during the fiscal year ended January 31, 2020.

- added (2020-09-04):
[0001571996-20-000045:note_history:3]
On October 22, 2019, VMware, Inc. filed a separate patent infringement lawsuit against Cirba in the United States District Court for the Eastern District of Virginia, asserting that Cirba infringes four additional VMware, Inc. patents.  The Virginia court transferred these patent claims to Delaware.  On March 23, 2020, Cirba filed a counterclaim asserting one additional patent against VMware, Inc.  VMware, Inc. intends to vigorously defend itself in this matter.

- added (2020-09-04):
[0001571996-20-000045:note_history:4]
Class Actions Related to VMware, Inc.’s Acquisition of Pivotal Software — Two purported stockholders brought putative class action complaints arising out of VMware, Inc.’s acquisition of Pivotal Software, Inc. on December 30, 2019 as described in Note 1 of the Notes to the Condensed Consolidated Financial Statements.  The two actions were consolidated in the Delaware Chancery Court into In re: Pivotal Software, Inc. Stockholders Litigation (Civil Action No. 2020-0440-KSJM).  The complaint names as defendants the Company, VMware, Inc., Michael S. Dell, and certain officers of Pivotal.  The plaintiffs generally allege that the defendants breached their fiduciary duties to the former holders of Pivotal Class A Common Stock in connection with VMware, Inc.’s acquisition of Pivotal by allegedly causing Pivotal to enter into a transaction that favored the interests of Pivotal’s controlling stockholders at the expense of such former stockholders.  The plaintiffs seek, among other remedies, a judicial declaration that the defendants breached their fiduciary duties and an award of damages, fees, and costs.

- changed (2020-09-04):
[0001571996-20-000045:note_history:5]
As of July 31, 2020, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for these or other proceedings or matters has been incurred.  However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company’s business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters.  Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company’s business, financial condition, results of operations, or cash flows will depend on a number of variables, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.
  (was, 2020-06-08, similarity 0.9973):
[0001571996-20-000034:note_history:5]
As of May 1, 2020, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for these or other proceedings or matters has been incurred.  However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company’s business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters.  Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company’s business, financial condition, results of operations, or cash flows will depend on a number of variables, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.

- removed (2020-09-04):
[0001571996-20-000034:note_history:6]
Patent Litigation — On April 25, 2019, Cirba Inc. (“Cirba”) filed a lawsuit against VMware, Inc. in the United States District Court for the District of Delaware, alleging two patent infringement claims and three trademark infringement-related claims.  On May 6, 2019, Cirba filed a motion seeking a preliminary injunction tied to one of the two patents it alleges VMware, Inc. infringes.  Following a hearing on August 6, 2019, the Court denied Cirba’s preliminary injunction motion and set the case for trial in mid-January 2020.  On August 20, 2019, VMware, Inc. filed counterclaims against Cirba, asserting among other claims that Cirba is infringing four VMware, Inc. patents.  The Delaware Court severed those claims from the January 2020 trial on Cirba’s claims, and the trial on VMware, Inc.’s patent claims is currently set for September 2021.  On October 22, 2019, VMware, Inc. filed a separate patent infringement lawsuit against Cirba in the United States District Court for the Eastern District of Virginia, asserting that Cirba infringes four additional VMware, Inc. patents.  The trial on Cirba’s claims in Delaware was completed on January 23, 2020, and on January 24, 2020, the jury returned a verdict finding that VMware, Inc. willfully infringed the two asserted patents and awarding approximately $237 million in damages.  The jury further found that VMware, Inc. was not liable on Cirba’s trademark infringement-related claims.  A total of $237 million was accrued for the Delaware action during the fiscal year ended January 31, 2020 and reflects the estimated losses that are considered both probable and reasonably estimable at this time.  The parties have completed the post-trial briefing stage in the Delaware Court, with the hearing on those motions having occurred on May 15, 2020.  The Court has taken those motions under consideration.  VMware, Inc. intends to vigorously defend itself in this matter, including having sought to overturn the jury’s verdict in the first Delaware trial during the post-trial briefing stage and, if necessary, on appeal.  In its post-trial motions, Cirba sought a permanent injunction, enhanced damages, and attorneys’ fees in the Delaware action.  As noted above, VMware, Inc. intends to pursue arguments both in the Delaware Court and, if necessary, the

- removed (2020-09-04):
[0001571996-20-000034:note_history:7]
Federal Circuit to overturn the jury’s verdict.  Final resolution of this matter could be materially different from the amount accrued.  The amount accrued for this matter is included in Accrued and other in the Condensed Consolidated Statements of Financial Position as of May 1, 2020 and January 31, 2020, and the charge was classified in Selling, general and administrative in the Consolidated Statements of Income (Loss) during the fiscal year ended January 31, 2020.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2020-09-04):
[0001571996-20-000045:note_history:8]
The Company is involved in various claims, suits, assessments, investigations, and legal proceedings that arise from time to time in the ordinary course of its business, including those identified below, consisting of matters involving consumer, antitrust, tax, intellectual property, and other issues on a global basis.  
The Company accrues a liability when it believes that it is both probable that a liability has been incurred and that it can reasonably estimate the amount of the loss.  The Company reviews these accruals at least quarterly and adjusts them to reflect ongoing negotiations, settlements, rulings, advice of legal counsel, and other relevant information.  To the extent new information is obtained and the Company’s views on the probable outcomes of claims, suits, assessments, investigations, or legal proceedings change, changes in the Company’s accrued liabilities would be recorded in the period in which such a determination is made.  For some matters, the amount of liability is not probable or the amount cannot be reasonably estimated and therefore accruals have not been made.

- removed (2020-09-04):
[0001571996-20-000034:note_history:9]
The Company is involved in various claims, suits, assessments, investigations, and legal proceedings that arise from time to time in the ordinary course of its business, including those identified below, consisting of matters involving consumer, antitrust, tax, intellectual property, and other issues on a global basis.

- removed (2020-09-04):
[0001571996-20-000034:note_history:10]
The Company accrues a liability when it believes that it is both probable that a liability has been incurred and that it can reasonably estimate the amount of the loss.  The Company reviews these accruals at least quarterly and adjusts them to reflect ongoing negotiations, settlements, rulings, advice of legal counsel, and other relevant information.  To the extent new information is obtained and the Company’s views on the probable outcomes of claims, suits, assessments, investigations, or legal proceedings change, changes in the Company’s accrued liabilities would be recorded in the period in which such a determination is made.  For some matters, the amount of liability is not probable or the amount cannot be reasonably estimated and therefore accruals have not been made.


## dell:CreditLossFinancialInstrumentLeasesDebtVariableInterestEntitiesAndCustomerReceivablesSalesTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-09-04):
[0001571996-20-000045:note_history:11]
The Company offers or arranges various financing options, services, and alternative payment structures for its customers in North America, Europe, Australia, and New Zealand through Dell Financial Services and its affiliates (“DFS”).  The Company also arranges financing for some of its customers in various countries where DFS does not currently operate as a captive enterprise.  The key activities of DFS include originating, collecting, and servicing customer financing arrangements primarily related to the purchase or use of Dell Technologies products and services.  In some cases, DFS also offers financing on the purchase of third-party technology products that complement the Dell Technologies portfolio of products and services.  New financing originations were $2.6 billion and $2.0 billion for the three months ended July 31, 2020 and August 2, 2019, respectively, and $4.4 billion and $3.7 billion for the six months ended July 31, 2020 and August 2, 2019, respectively.
  (was, 2020-06-08, similarity 0.9407):
[0001571996-20-000034:note_history:11]
The Company offers or arranges various financing options, services, and alternative payment structures for its customers in North America, Europe, Australia, and New Zealand through Dell Financial Services and its affiliates (“DFS”).  The Company also arranges financing for some of its customers in various countries where DFS does not currently operate as a captive enterprise.  The key activities of DFS include originating, collecting, and servicing customer financing arrangements primarily related to the purchase or use of Dell Technologies products and services.  In some cases, DFS also offers financing on the purchase of third-party technology products that complement the Dell Technologies portfolio of products and services.  New financing originations were $1.8 billion and $1.7 billion for the three months ended May 1, 2020 and May 3, 2019, respectively.

- changed (2020-09-04):
[0001571996-20-000045:note_history:12]
Fixed-term leases and loans — The Company enters into financing arrangements with customers who seek lease financing for equipment.  Pursuant to the current lease accounting standard effective February 2, 2019, new DFS leases are classified as sales-type leases, direct financing leases, or operating leases.  When the terms of the DFS lease transfer control of the underlying asset to the lessee, the contract is typically classified as a sales-type lease.  Direct financing leases are immaterial.  All other new DFS leases are classified as operating leases.  Leases that commenced prior to the effective date of the current lease accounting standard continue to be accounted for under previous lease accounting guidance.  Leases with business customers have fixed terms of generally two to four years.
  (was, 2020-06-08, similarity 0.9814):
[0001571996-20-000034:note_history:12]
Fixed-term leases and loans — The Company enters into financing arrangements with customers who seek lease financing for equipment they might otherwise purchase.  Pursuant to the current lease accounting standard effective February 2, 2019, new DFS leases are classified as sales-type leases, direct financing leases, or operating leases.  When the terms of the DFS lease transfer control of the underlying asset to the lessee, the contract is typically classified as a sales-type lease.  Direct financing leases are immaterial.  All other new DFS leases are classified as operating leases.  Leases that commenced prior to the effective date of the current lease accounting standard continue to be accounted for under previous lease accounting guidance.  Leases with business customers have fixed terms of generally two to four years.

- changed (2020-09-04):
[0001571996-20-000045:note_history:13]
|  | July 31, 2020 |  |  |  |  |  | January 31, 2020 |  |  |  |  |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |  |  |  |  |  |  |  |  |  |  |
| Financing receivables, net: |  |  |  |  |  |  |  |  |  |  |  |
| Customer receivables, gross (a) | $ | 778 |  |  | $ | 9,255 |  |  | $ | 10,033 |  |  | $ | 824 |  |  | $ | 8,486 |  |  | $ | 9,310 |  |
| Allowances for losses | (143) |  |  | (180) |  |  | (323) |  |  | (70) |  |  | (79) |  |  | (149) |  |
| Customer receivables, net | 635 |  |  | 9,075 |  |  | 9,710 |  |  | 754 |  |  | 8,407 |  |  | 9,161 |  |
| Residual interest | — |  |  | 523 |  |  | 523 |  |  | — |  |  | 582 |  |  | 582 |  |
| Financing receivables, net | $ | 635 |  |  | $ | 9,598 |  |  | $ | 10,233 |  |  | $ | 754 |  |  | $ | 8,989 |  |  | $ | 9,743 |  |
| Short-term | $ | 635 |  |  | $ | 4,220 |  |  | $ | 4,855 |  |  | $ | 754 |  |  | $ | 4,141 |  |  | $ | 4,895 |  |
| Long-term | $ | — |  |  | $ | 5,378 |  |  | $ | 5,378 |  |  | $ | — |  |  | $ | 4,848 |  |  | $ | 4,848 |  |
  (was, 2020-06-08, similarity 0.9365):
[0001571996-20-000034:note_history:13]
|  | May 1, 2020 |  | January 31, 2020 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Financing receivables, net: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer receivables, gross (a) | $ | 786 |  |  | $ | 8,446 |  |  | $ | 9,232 |  |  | $ | 824 |  |  | $ | 8,486 |  |  | $ | 9,310 |  |
| Allowances for losses | (144 | ) |  | (177 | ) |  | (321 | ) |  | (70 | ) |  | (79 | ) |  | (149 | ) |
| Customer receivables, net | 642 |  |  | 8,269 |  |  | 8,911 |  |  | 754 |  |  | 8,407 |  |  | 9,161 |  |
| Residual interest | — |  |  | 551 |  |  | 551 |  |  | — |  |  | 582 |  |  | 582 |  |
| Financing receivables, net | $ | 642 |  |  | $ | 8,820 |  |  | $ | 9,462 |  |  | $ | 754 |  |  | $ | 8,989 |  |  | $ | 9,743 |  |
| Short-term | $ | 642 |  |  | $ | 4,110 |  |  | $ | 4,752 |  |  | $ | 754 |  |  | $ | 4,141 |  |  | $ | 4,895 |  |
| Long-term | $ | — |  |  | $ | 4,710 |  |  | $ | 4,710 |  |  | $ | — |  |  | $ | 4,848 |  |  | $ | 4,848 |  |

- changed (2020-09-04):
[0001571996-20-000045:note_history:14]
(a) Customer receivables, gross includes amounts due from customers under revolving loans, fixed-term loans, fixed-term sales-type or direct financing leases, and accrued interest.
  (was, 2020-06-08, similarity 0.9836):
[0001571996-20-000034:note_history:14]
| (a) | Customer receivables, gross includes amounts due from customers under revolving loans, fixed-term loans, fixed-term sales-type or direct financing leases, and accrued interest. |

- changed (2020-09-04):
[0001571996-20-000045:note_history:15]
The allowance for losses as of July 31, 2020 includes the adoption of the new CECL standard, which was adopted as of February 1, 2020 using the modified retrospective method.  Prior period amounts have not been recast.  The provision recognized on the Condensed Consolidated Statements of Income (Loss) for the three and six months ended July 31, 2020 is based on an assessment of the impact of current and expected future economic conditions, inclusive of the effect of the COVID-19 pandemic on credit losses.  The duration and severity of COVID-19 and continued market volatility is highly uncertain and, as such, the impact on expected losses is subject to significant judgment and may cause variability in the Company’s allowance for credit losses in future periods.  See Note 1 and Note 2 of the Notes to the Condensed Consolidated Financial Statements for additional information about the new CECL standard.
  (was, 2020-06-08, similarity 0.9578):
[0001571996-20-000034:note_history:15]
The allowance for losses as of May 1, 2020 includes the adoption of the new CECL standard, which was adopted as of February 1, 2020 using the modified retrospective method.  Prior period amounts have not been recast.  The provision recognized on the Condensed Consolidated Statements of Income (Loss) during the three months ended May 1, 2020 is based on an assessment of the impact of current and expected future economic conditions, inclusive of the effect of the COVID-19 pandemic on credit losses.  The duration and severity of COVID-19 and continued market volatility is highly uncertain and, as such, the impact on expected losses is subject to significant judgment and may cause variability in the Company’s allowance for credit losses in future periods.  See Note 1 and Note 2 of the Notes to the Condensed Consolidated Financial Statements for additional information about the new CECL standard.

- added (2020-09-04):
[0001571996-20-000045:note_history:16]
|  | Three Months Ended |  |  |  |  |  |  |  |  |  |  |
|  | July 31, 2020 |  |  |  |  |  | August 2, 2019 |  |  |  |  |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |  |  |  |  |  |  |  |  |  |  |
| Allowance for financing receivable losses: |  |  |  |  |  |  |  |  |  |  |  |
| Balances at beginning of period | $ | 144 |  |  | $ | 177 |  |  | $ | 321 |  |  | $ | 70 |  |  | $ | 73 |  |  | $ | 143 |  |
| Charge-offs, net of recoveries | (18) |  |  | (7) |  |  | (25) |  |  | (15) |  |  | (9) |  |  | (24) |  |
| Provision charged to income statement | 17 |  |  | 10 |  |  | 27 |  |  | 12 |  |  | 7 |  |  | 19 |  |
| Balances at end of period | $ | 143 |  |  | $ | 180 |  |  | $ | 323 |  |  | $ | 67 |  |  | $ | 71 |  |  | $ | 138 |  |

- added (2020-09-04):
[0001571996-20-000045:note_history:17]
|  | Six Months Ended |  |  |  |  |  |  |  |  |  |  |
|  | July 31, 2020 |  |  |  |  |  | August 2, 2019 |  |  |  |  |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |  |  |  |  |  |  |  |  |  |  |
| Allowance for financing receivable losses: |  |  |  |  |  |  |  |  |  |  |  |
| Balances at beginning of period | $ | 70 |  |  | $ | 79 |  |  | $ | 149 |  |  | $ | 75 |  |  | $ | 61 |  |  | $ | 136 |  |
| Adjustment for adoption of accounting standard (Note 1) | 40 |  |  | 71 |  |  | 111 |  |  | — |  |  | — |  |  | — |  |
| Charge-offs, net of recoveries | (38) |  |  | (16) |  |  | (54) |  |  | (35) |  |  | (12) |  |  | (47) |  |
| Provision charged to income statement | 71 |  |  | 46 |  |  | 117 |  |  | 27 |  |  | 22 |  |  | 49 |  |
| Balances at end of period | $ | 143 |  |  | $ | 180 |  |  | $ | 323 |  |  | $ | 67 |  |  | $ | 71 |  |  | $ | 138 |  |

- changed (2020-09-04):
[0001571996-20-000045:note_history:18]
|  | July 31, 2020 |  |  |  |  |  |  |  | January 31, 2020 |  |  |  |  |  |  |
|  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |
|  | (in millions) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revolving — DPA | $ | 556 |  |  | $ | 29 |  |  | $ | 13 |  |  | $ | 598 |  |  | $ | 550 |  |  | $ | 51 |  |  | $ | 20 |  |  | $ | 621 |  |
| Revolving — DBC | 165 |  |  | 11 |  |  | 4 |  |  | 180 |  |  | 184 |  |  | 15 |  |  | 4 |  |  | 203 |  |
| Fixed-term — Consumer and Commercial | 8,803 |  |  | 381 |  |  | 71 |  |  | 9,255 |  |  | 8,005 |  |  | 373 |  |  | 108 |  |  | 8,486 |  |
| Total customer receivables, gross | $ | 9,524 |  |  | $ | 421 |  |  | $ | 88 |  |  | $ | 10,033 |  |  | $ | 8,739 |  |  | $ | 439 |  |  | $ | 132 |  |  | $ | 9,310 |  |
  (was, 2020-06-08, similarity 0.8207):
[0001571996-20-000034:note_history:18]
|  | May 1, 2020 |  | January 31, 2020 |
|  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |
|  | (in millions) |
| Revolving — DPA | $ | 547 |  |  | $ | 34 |  |  | $ | 17 |  |  | $ | 598 |  |  | $ | 550 |  |  | $ | 51 |  |  | $ | 20 |  |  | $ | 621 |  |
| Revolving — DBC | 162 |  |  | 21 |  |  | 5 |  |  | 188 |  |  | 184 |  |  | 15 |  |  | 4 |  |  | 203 |  |
| Fixed-term — Consumer and Commercial | 6,963 |  |  | 1,333 |  |  | 150 |  |  | 8,446 |  |  | 8,005 |  |  | 373 |  |  | 108 |  |  | 8,486 |  |
| Total customer receivables, gross | $ | 7,672 |  |  | $ | 1,388 |  |  | $ | 172 |  |  | $ | 9,232 |  |  | $ | 8,739 |  |  | $ | 439 |  |  | $ | 132 |  |  | $ | 9,310 |  |

- changed (2020-09-04):
[0001571996-20-000045:note_history:19]
Aging is likely to fluctuate as a result of the variability in volume of large transactions entered into over the period, and the administrative processes that accompany those larger transactions.  Aging is also impacted by the timing of the Dell Technologies fiscal period end date, relative to calendar month-end customer payment due dates.  As a result of these factors, fluctuations in aging from period to period do not necessarily indicate a material change in the collectibility of the portfolio.
  (was, 2020-06-08, similarity 0.996):
[0001571996-20-000034:note_history:19]
Aging is likely to fluctuate as a result of the variability in volume of large transactions entered into over the period, and the administrative processes that accompany those larger transactions.  Aging is also impacted by the timing of Dell Technologies fiscal period end date, relative to calendar month-end customer payment due dates.  As a result of these factors, fluctuations in aging from period to period do not necessarily indicate a material change in the collectibility of the portfolio.

- changed (2020-09-04):
[0001571996-20-000045:note_history:20]
|  | July 31, 2020 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | Fixed-term — Consumer and Commercial |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | Fiscal Year of Origination |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | 2021 |  | 2020 |  | 2019 |  | 2018 |  | 2017 |  | Years Prior |  | Revolving — DPA (a) |  | Revolving — DBC (a) |  | Total |
|  | (in millions) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Higher | $ | 2,019 |  |  | $ | 2,265 |  |  | $ | 992 |  |  | $ | 273 |  |  | $ | 43 |  |  | $ | 1 |  |  | $ | 148 |  |  | $ | 51 |  |  | $ | 5,792 |  |
| Mid | 633 |  |  | 824 |  |  | 417 |  |  | 127 |  |  | 20 |  |  | 1 |  |  | 176 |  |  | 52 |  |  | 2,250 |  |
| Lower | 548 |  |  | 609 |  |  | 379 |  |  | 82 |  |  | 20 |  |  | 2 |  |  | 274 |  |  | 77 |  |  | 1,991 |  |
| Total | $ | 3,200 |  |  | $ | 3,698 |  |  | $ | 1,788 |  |  | $ | 482 |  |  | $ | 83 |  |  | $ | 4 |  |  | $ | 598 |  |  | $ | 180 |  |  | $ | 10,033 |  |
  (was, 2020-06-08, similarity 0.9201):
[0001571996-20-000034:note_history:20]
|  | May 1, 2020 |
|  | Fixed-term — Consumer and Commercial |  |  |  |  |  |  |
|  | Fiscal Year of Origination |  |  |  |  |  |  |
|  | 2021 |  | 2020 |  | 2019 |  | 2018 |  | 2017 |  | Years Prior |  | Revolving — DPA (a) |  | Revolving — DBC (a) |  | Total |
|  | (in millions) |
| Higher | $ | 1,150 |  |  | $ | 2,438 |  |  | $ | 1,141 |  |  | $ | 393 |  |  | $ | 68 |  |  | $ | 2 |  |  | $ | 135 |  |  | $ | 51 |  |  | $ | 5,378 |  |
| Mid | 229 |  |  | 883 |  |  | 498 |  |  | 182 |  |  | 34 |  |  | 2 |  |  | 169 |  |  | 56 |  |  | 2,053 |  |
| Lower | 184 |  |  | 647 |  |  | 443 |  |  | 119 |  |  | 29 |  |  | 4 |  |  | 294 |  |  | 81 |  |  | 1,801 |  |
| Total | $ | 1,563 |  |  | $ | 3,968 |  |  | $ | 2,082 |  |  | $ | 694 |  |  | $ | 131 |  |  | $ | 8 |  |  | $ | 598 |  |  | $ | 188 |  |  | $ | 9,232 |  |

- changed (2020-09-04):
[0001571996-20-000045:note_history:21]
(a) The revolving portfolio is exempt from the requirement to disclose the amortized cost basis by year of origination since determining the appropriate origination year can be complex due to the nature of the revolving portfolio.
  (was, 2020-06-08, similarity 0.9871):
[0001571996-20-000034:note_history:21]
| (a) | The revolving portfolio is exempt from the requirement to disclose the amortized cost basis by year of origination since determining the appropriate origination year can be complex due to the nature of the revolving portfolio. |

- changed (2020-09-04):
[0001571996-20-000045:note_history:22]
|  | January 31, 2020 |  |  |  |  |  |  |
|  | Fixed-term — Consumer and Commercial |  | Revolving — DPA |  | Revolving — DBC |  | Total |
|  | (in millions) |  |  |  |  |  |  |
| Higher | $ | 5,042 |  |  | $ | 137 |  |  | $ | 55 |  |  | $ | 5,234 |  |
| Mid | 2,036 |  |  | 175 |  |  | 63 |  |  | 2,274 |  |
| Lower | 1,408 |  |  | 309 |  |  | 85 |  |  | 1,802 |  |
| Total | $ | 8,486 |  |  | $ | 621 |  |  | $ | 203 |  |  | $ | 9,310 |  |
  (was, 2020-06-08, similarity 0.964):
[0001571996-20-000034:note_history:22]
|  | January 31, 2020 |
|  | Fixed-term — Consumer and Commercial |  | Revolving — DPA |  | Revolving — DBC |  | Total |
|  | (in millions) |
| Higher | $ | 5,042 |  |  | $ | 137 |  |  | $ | 55 |  |  | $ | 5,234 |  |
| Mid | 2,036 |  |  | 175 |  |  | 63 |  |  | 2,274 |  |
| Lower | 1,408 |  |  | 309 |  |  | 85 |  |  | 1,802 |  |
| Total | $ | 8,486 |  |  | $ | 621 |  |  | $ | 203 |  |  | $ | 9,310 |  |

- changed (2020-09-04):
[0001571996-20-000045:note_history:23]
Interest income on sales-type lease receivables was $66 million for both the three months ended July 31, 2020 and August 2, 2019, and $131 million and $130 million for the six months ended July 31, 2020 and August 2, 2019, respectively.
  (was, 2020-06-08, similarity 0.6877):
[0001571996-20-000034:note_history:23]
Interest income on sales-type lease receivables was $65 million and $64 million for the three months ended May 1, 2020 and May 3, 2019, respectively.

- changed (2020-09-04):
[0001571996-20-000045:note_history:24]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | July 31, 2020 |  | August 2, 2019 |  | July 31, 2020 |  | August 2, 2019 |
|  | (in millions) |  |  |  |  |  |  |
| Net revenue — products | $ | 249 |  |  | $ | 223 |  |  | $ | 464 |  |  | $ | 353 |  |
| Cost of net revenue — products | 174 |  |  | 179 |  |  | 333 |  |  | 260 |  |
| Gross margin — products | $ | 75 |  |  | $ | 44 |  |  | $ | 131 |  |  | $ | 93 |  |
  (was, 2020-06-08, similarity 0.7504):
[0001571996-20-000034:note_history:24]
|  | Three Months Ended |
|  | May 1, 2020 |  | May 3, 2019 |
|  | (in millions) |
| Net revenue — products | $ | 215 |  |  | $ | 130 |  |
| Cost of net revenue — products | 159 |  |  | 81 |  |
| Gross margin — products | $ | 56 |  |  | $ | 49 |  |

- changed (2020-09-04):
[0001571996-20-000045:note_history:25]
|  | July 31, 2020 |
| Fiscal Years | (in millions) |
| Fiscal 2021 (remaining six months) | $ | 1,475 |  |
| Fiscal 2022 | 2,159 |  |
| Fiscal 2023 | 1,347 |  |
| Fiscal 2024 | 609 |  |
| Fiscal 2025 and beyond | 250 |  |
| Total undiscounted cash flows | 5,840 |  |
| Fixed-term loans | 4,075 |  |
| Revolving loans | 778 |  |
| Less: unearned income | (660) |  |
| Total customer receivables, gross | $ | 10,033 |  |
  (was, 2020-06-08, similarity 0.6991):
[0001571996-20-000034:note_history:25]
|  | May 1, 2020 |
| Fiscal Years | (in millions) |
| Fiscal 2021 (remaining nine months) | $ | 306 |  |
| Fiscal 2022 | 370 |  |
| Fiscal 2023 | 269 |  |
| Fiscal 2024 | 54 |  |
| Fiscal 2025 and beyond | 7 |  |
| Total | $ | 1,006 |  |

- changed (2020-09-04):
[0001571996-20-000045:note_history:26]
|  | July 31, 2020 |  | January 31, 2020 |
|  | (in millions) |  |  |
| Equipment under operating lease, gross | $ | 1,478 |  |  | $ | 956 |  |
| Less: accumulated depreciation | (258) |  |  | (116) |  |
| Equipment under operating lease, net | $ | 1,220 |  |  | $ | 840 |  |
  (was, 2020-06-08, similarity 0.8951):
[0001571996-20-000034:note_history:26]
|  | May 1, 2020 |  | January 31, 2020 |
|  | (in millions) |
| Equipment under operating lease, gross | $ | 1,150 |  |  | $ | 956 |  |
| Less: accumulated depreciation | (175 | ) |  | (116 | ) |
| Equipment under operating lease, net | $ | 975 |  |  | $ | 840 |  |

- added (2020-09-04):
[0001571996-20-000045:note_history:27]
Operating lease income relating to lease payments was $103 million and $27 million for the three months ended July 31, 2020 and August 2, 2019, respectively, and $190 million and $31 million for the six months ended July 31, 2020 and August 2, 2019, respectively.  Depreciation expense was $74 million and $21 million for the three months ended July 31, 2020 and August 2, 2019, respectively, and $136 million and $24 million for the six months ended July 31, 2020 and August 2, 2019, respectively.

- added (2020-09-04):
[0001571996-20-000045:note_history:28]
|  | July 31, 2020 |
| Fiscal Years | (in millions) |
| Fiscal 2021 (remaining six months) | $ | 258 |  |
| Fiscal 2022 | 461 |  |
| Fiscal 2023 | 351 |  |
| Fiscal 2024 | 89 |  |
| Fiscal 2025 and beyond | 9 |  |
| Total | $ | 1,168 |  |

- changed (2020-09-04):
[0001571996-20-000045:note_history:29]
|  | July 31, 2020 |  | January 31, 2020 |
|  | (in millions) |  |  |
| DFS U.S. debt: |  |  |  |
| Asset-based financing and securitization facilities | $ | 2,936 |  |  | $ | 2,606 |  |
| Fixed-term securitization offerings | 2,788 |  |  | 2,593 |  |
| Other | 187 |  |  | 141 |  |
| Total DFS U.S. debt | 5,911 |  |  | 5,340 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 835 |  |  | 743 |  |
| Other borrowings | 719 |  |  | 931 |  |
| Note payable | 187 |  |  | 200 |  |
| Dell Bank Senior Unsecured Eurobonds | 1,185 |  |  | 551 |  |
| Total DFS international debt | 2,926 |  |  | 2,425 |  |
| Total DFS debt | $ | 8,837 |  |  | $ | 7,765 |  |
| Total short-term DFS debt | $ | 4,188 |  |  | $ | 4,152 |  |
| Total long-term DFS debt | $ | 4,649 |  |  | $ | 3,613 |  |
  (was, 2020-06-08, similarity 0.9704):
[0001571996-20-000034:note_history:29]
|  | May 1, 2020 |  | January 31, 2020 |
|  | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing and securitization facilities | $ | 2,429 |  |  | $ | 2,606 |  |
| Fixed-term securitization offerings | 3,251 |  |  | 2,593 |  |
| Other | 117 |  |  | 141 |  |
| Total DFS U.S. debt | 5,797 |  |  | 5,340 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 773 |  |  | 743 |  |
| Other borrowings | 970 |  |  | 931 |  |
| Note payable | 181 |  |  | 200 |  |
| Dell Bank Senior Unsecured Eurobonds | 548 |  |  | 551 |  |
| Total DFS international debt | 2,472 |  |  | 2,425 |  |
| Total DFS debt | $ | 8,269 |  |  | $ | 7,765 |  |
| Total short-term DFS debt | $ | 4,397 |  |  | $ | 4,152 |  |
| Total long-term DFS debt | $ | 3,872 |  |  | $ | 3,613 |  |

- changed (2020-09-04):
[0001571996-20-000045:note_history:30]
Asset-Based Financing and Securitization Facilities — The Company maintains separate asset-based financing facilities and a securitization facility in the United States, which are revolving facilities for fixed-term leases and loans and for revolving loans, respectively.  This debt is collateralized solely by the U.S. loan and lease payments and associated equipment in the facilities.  The debt has a variable interest rate and the duration of the debt is based on the terms of the underlying loan and lease payment streams.  As of July 31, 2020, the total debt capacity related to the U.S. asset-based financing and securitization facilities was $4.1 billion.  The Company enters into interest swap agreements to effectively convert a portion of this debt from a floating rate to a fixed rate.  See Note 7 of the Notes to the Condensed Consolidated Financial Statements for additional information about interest rate swaps.
  (was, 2020-06-08, similarity 0.9973):
[0001571996-20-000034:note_history:30]
Asset-Based Financing and Securitization Facilities — The Company maintains separate asset-based financing facilities and a securitization facility in the United States, which are revolving facilities for fixed-term leases and loans and for revolving loans, respectively.  This debt is collateralized solely by the U.S. loan and lease payments and associated equipment in the facilities.  The debt has a variable interest rate and the duration of the debt is based on the terms of the underlying loan and lease payment streams.  As of May 1, 2020, the total debt capacity related to the U.S. asset-based financing and securitization facilities was $4.0 billion.  The Company enters into interest swap agreements to effectively convert a portion of this debt from a floating rate to a fixed rate.  See Note 7 of the Notes to the Condensed Consolidated Financial Statements for additional information about interest rate swaps.

- changed (2020-09-04):
[0001571996-20-000045:note_history:31]
The asset-based financing and securitization facilities contain standard structural features related to the performance of the funded receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the facility, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of July 31, 2020, these criteria were met.
  (was, 2020-06-08, similarity 0.9955):
[0001571996-20-000034:note_history:31]
The asset-based financing and securitization facilities contain standard structural features related to the performance of the funded receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the facility, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of May 1, 2020, these criteria were met.

- changed (2020-09-04):
[0001571996-20-000045:note_history:32]
Securitization Facility — The Company maintains a securitization facility in Europe for fixed-term leases and loans.  This facility is effective through December 21, 2020 and has a total debt capacity of $948 million as of July 31, 2020.
  (was, 2020-06-08, similarity 0.9663):
[0001571996-20-000034:note_history:32]
Securitization Facility — The Company maintains a securitization facility in Europe for fixed-term leases and loans.  This facility is effective through December 21, 2020 and has a total debt capacity of $876 million as of May 1, 2020.

- changed (2020-09-04):
[0001571996-20-000045:note_history:33]
The securitization facility contains standard structural features related to the performance of the securitized receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the program, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of July 31, 2020, these criteria were met.
  (was, 2020-06-08, similarity 0.9953):
[0001571996-20-000034:note_history:33]
The securitization facility contains standard structural features related to the performance of the securitized receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the program, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of May 1, 2020, these criteria were met.

- changed (2020-09-04):
[0001571996-20-000045:note_history:34]
Other Borrowings — In connection with the Company’s international financing operations, the Company has entered into revolving structured financing debt programs related to its fixed-term lease and loan products sold in Canada, Europe, Australia, and New Zealand.  The Canadian facility, which is collateralized solely by Canadian loan and lease payments and associated equipment, had a total debt capacity of $279 million as of July 31, 2020, and is effective through January 16, 2023.  The European facility, which is collateralized solely by European loan and lease payments and associated equipment, had a total debt capacity of $711 million as of July 31, 2020, and is effective through June 14, 2022.  The Australia and New Zealand facility, which is collateralized solely by Australia and New Zealand loan and lease payments and associated equipment, had a total debt capacity of $252 million as of July 31, 2020, and is effective through December 20, 2021.
  (was, 2020-06-08, similarity 0.6899):
[0001571996-20-000034:note_history:34]
Other Borrowings — In connection with the Company’s international financing operations, the Company has entered into revolving structured financing debt programs related to its fixed-term lease and loan products sold in Canada, Europe, Australia, and New Zealand.  The Canadian facility, which is collateralized solely by Canadian loan and lease payments and associated equipment, had a total debt capacity of $269 million as of May 1, 2020, and is effective through January 16, 2023.  The European facility, which is collateralized solely by European loan and lease payments and associated equipment, had a total debt capacity of $657 million as of May 1, 2020, and is effective through June 14, 2022.  The Australia and New Zealand facility, which is collateralized solely by Australia and New Zealand loan and lease payments and associated equipment, had a total debt capacity of $228 million as of May 1, 2020, and is effective through December 20, 2021.

- changed (2020-09-04):
[0001571996-20-000045:note_history:35]
Note Payable — On November 27, 2017, the Company entered into an unsecured credit agreement to fund receivables in Mexico.  As of July 31, 2020, the aggregate principal amount of the note payable is $187 million.  The note bears interest at either the applicable London Interbank Offered Rate (“LIBOR”) plus 2.25%, for the borrowings denominated in U.S. dollars, or the Mexican Interbank Equilibrium Interest Rate (“TIIE”) plus 2.00%, for the borrowings denominated in Mexican pesos.  The note will mature on December 1, 2020.
  (was, 2020-06-08, similarity 0.995):
[0001571996-20-000034:note_history:35]
Note Payable — On November 27, 2017, the Company entered into an unsecured credit agreement to fund receivables in Mexico.  As of May 1, 2020, the aggregate principal amount of the note payable is $181 million.  The note bears interest at either the applicable London Interbank Offered Rate (“LIBOR”) plus 2.25%, for the borrowings denominated in U.S. dollars, or the Mexican Interbank Equilibrium Interest Rate (“TIIE”) plus 2.00%, for the borrowings denominated in Mexican pesos.  The note will mature on December 1, 2020.

- changed (2020-09-04):
[0001571996-20-000045:note_history:36]
Dell Bank Senior Unsecured Eurobonds — On October 17, 2019, Dell Bank International D.A.C. issued 500 million Euro of 0.625% senior unsecured three year eurobonds due October 2022.  On June 24, 2020, Dell Bank International D.A.C. issued an additional 500 million Euro of 1.625% senior unsecured four year eurobonds due June 2024.  The issuances of the senior unsecured eurobonds support the expansion of the financing operations in Europe.
  (was, 2020-06-08, similarity 0.6421):
[0001571996-20-000034:note_history:36]
Dell Bank Senior Unsecured Eurobonds — On October 17, 2019, Dell Bank International D.A.C. issued 500 million Euro of 0.625% senior unsecured three year eurobonds due October 2022.  The issuance of the senior unsecured eurobonds supports the expansion of the financing operations in Europe.

- changed (2020-09-04):
[0001571996-20-000045:note_history:37]
|  | July 31, 2020 |  | January 31, 2020 |
|  | (in millions) |  |  |
| Assets held by consolidated VIEs, net: |  |  |  |
| Short-term, net | $ | 3,315 |  |  | $ | 3,316 |  |
| Long-term, net | 3,867 |  |  | 3,348 |  |
| Assets held by consolidated VIEs, net | $ | 7,182 |  |  | $ | 6,664 |  |
  (was, 2020-06-08, similarity 0.9234):
[0001571996-20-000034:note_history:37]
|  | May 1, 2020 |  | January 31, 2020 |
|  | (in millions) |
| Assets held by consolidated VIEs, net: |  |  |  |  |  |
| Short-term, net | $ | 3,384 |  |  | $ | 3,316 |  |
| Long-term, net | 3,628 |  |  | 3,348 |  |
| Assets held by consolidated VIEs, net | $ | 7,012 |  |  | $ | 6,664 |  |

- changed (2020-09-04):
[0001571996-20-000045:note_history:38]
Loan and lease payments and associated equipment transferred via securitization through SPEs were $1.2 billion and $1.3 billion for the three months ended July 31, 2020 and August 2, 2019, respectively, and $3.0 billion and $2.8 billion for the six months ended July 31, 2020 and August 2, 2019, respectively.
  (was, 2020-06-08, similarity 0.7785):
[0001571996-20-000034:note_history:38]
Loan and lease payments and associated equipment transferred via securitization through SPEs were $1.8 billion and $1.5 billion for the three months ended May 1, 2020 and May 3, 2019, respectively.

- changed (2020-09-04):
[0001571996-20-000045:note_history:39]
Some of the SPEs have entered into financing arrangements with multi-seller conduits that, in turn, issue asset-backed debt securities in the capital markets.  The DFS debt outstanding, which is collateralized by the loan and lease payments and associated equipment held by the consolidated VIEs, was $6.6 billion and $5.9 billion as of July 31, 2020 and January 31, 2020, respectively.  The Company’s risk of loss related to securitized receivables is limited to the amount by which the Company’s right to receive collections for assets securitized exceeds the amount required to pay interest, principal, and fees and expenses related to the asset-backed securities.  The Company provides credit enhancement to the securitizations in the form of over-collateralization.
  (was, 2020-06-08, similarity 0.9767):
[0001571996-20-000034:note_history:39]
Some of the SPEs have entered into financing arrangements with multi-seller conduits that, in turn, issue asset-backed debt securities in the capital markets.  The DFS debt outstanding, which is collateralized by the loan and lease payments and associated equipment held by the consolidated VIEs, was $6.5 billion and $5.9 billion as of May 1, 2020 and January 31, 2020, respectively.  The Company’s risk of loss related to securitized receivables is limited to the amount by which the Company’s right to receive collections for assets securitized exceeds the amount required to pay interest, principal, and fees and expenses related to the asset-backed securities.  The Company provides credit enhancement to the securitizations in the form of over-collateralization.

- changed (2020-09-04):
[0001571996-20-000045:note_history:40]
To manage certain concentrations of customer credit exposure, the Company may sell selected fixed-term customer receivables to unrelated third parties on a periodic basis, without recourse.  The amount of customer receivables sold for this purpose was $228 million and $246 million for the six months ended July 31, 2020 and August 2, 2019, respectively.  The Company’s continuing involvement in the above mentioned customer receivables is primarily limited to servicing arrangements.
  (was, 2020-06-08, similarity 0.6146):
[0001571996-20-000034:note_history:40]
To manage certain concentrations of customer credit exposure, the Company may sell selected fixed-term customer receivables to unrelated third parties on a periodic basis, without recourse.  The amount of customer receivables sold for this purpose was $21 million and $101 million for the three months ended May 1, 2020 and May 3, 2019, respectively.  The Company’s continuing involvement in the above mentioned customer receivables is primarily limited to servicing arrangements.

- removed (2020-09-04):
[0001571996-20-000034:note_history:41]
|  | Three Months Ended |
|  | May 1, 2020 |  | May 3, 2019 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |  |  |  |  |  |  |  |  |  |  |  |
| Balances at beginning of period | $ | 70 |  |  | $ | 79 |  |  | $ | 149 |  |  | $ | 75 |  |  | $ | 61 |  |  | $ | 136 |  |
| Adjustment for adoption of the new CECL standard (Note 1) | 40 |  |  | 71 |  |  | 111 |  |  | — |  |  | — |  |  | — |  |
| Charge-offs, net of recoveries | (20 | ) |  | (9 | ) |  | (29 | ) |  | (20 | ) |  | (3 | ) |  | (23 | ) |
| Provision charged to income statement | 54 |  |  | 36 |  |  | 90 |  |  | 15 |  |  | 15 |  |  | 30 |  |
| Balances at end of period | $ | 144 |  |  | $ | 177 |  |  | $ | 321 |  |  | $ | 70 |  |  | $ | 73 |  |  | $ | 143 |  |

- removed (2020-09-04):
[0001571996-20-000034:note_history:42]
|  | May 1, 2020 |
| Fiscal Years | (in millions) |
| Fiscal 2021 (remaining nine months) | $ | 2,050 |  |
| Fiscal 2022 | 1,812 |  |
| Fiscal 2023 | 1,045 |  |
| Fiscal 2024 | 406 |  |
| Fiscal 2025 and beyond | 137 |  |
| Total undiscounted cash flows | 5,450 |  |
| Fixed-term loans | 3,588 |  |
| Revolving loans | 786 |  |
| Less: unearned income | (592 | ) |
| Total customer receivables, gross | $ | 9,232 |  |

- removed (2020-09-04):
[0001571996-20-000034:note_history:43]
Operating lease income relating to lease payments was $87 million and $4 million for the three months ended May 1, 2020 and May 3, 2019, respectively.  Depreciation expense was $62 million and $3 million for the three months ended May 1, 2020 and May 3, 2019, respectively.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-09-04):
[0001571996-20-000045:note_history:44]
|  | July 31, 2020 |  | January 31, 2020 |
|  | (in millions) |  |  |
| Secured Debt |  |  |  |
| Senior Secured Credit Facilities: |  |  |  |
| 2.75% Term Loan B-1 Facility due September 2025 | $ | 4,691 |  |  | $ | 4,738 |  |
| 1.93% Term Loan A-4 Facility due December 2023 | 679 |  |  | 679 |  |
| 1.93% Term Loan A-6 Facility due March 2024 | 3,316 |  |  | 3,497 |  |
| First Lien Notes: |  |  |  |
| 4.42% due June 2021 | 3,065 |  |  | 4,500 |  |
| 5.45% due June 2023 | 3,750 |  |  | 3,750 |  |
| 4.00% due July 2024 | 1,000 |  |  | 1,000 |  |
| 5.85% due July 2025 | 1,000 |  |  | — |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 4.90% due October 2026 | 1,750 |  |  | 1,750 |  |
| 6.10% due July 2027 | 500 |  |  | — |  |
| 5.30% due October 2029 | 1,750 |  |  | 1,750 |  |
| 6.20% due July 2030 | 750 |  |  | — |  |
| 8.10% due July 2036 | 1,500 |  |  | 1,500 |  |
| 8.35% due July 2046 | 2,000 |  |  | 2,000 |  |
| Unsecured Debt |  |  |  |
| Unsecured Notes and Debentures: |  |  |  |
| 4.625% due April 2021 | 400 |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| Senior Notes: |  |  |  |
| 5.875% due June 2021 | 1,075 |  |  | 1,075 |  |
| 7.125% due June 2024 | 1,625 |  |  | 1,625 |  |
| EMC Notes: |  |  |  |
| 2.650% due June 2020 | — |  |  | 600 |  |
| 3.375% due June 2023 | 1,000 |  |  | 1,000 |  |
| Debt of Public Subsidiary |  |  |  |
| VMware Notes: |  |  |  |
| 2.30% due August 2020 | — |  |  | 1,250 |  |
| 2.95% due August 2022 | 1,500 |  |  | 1,500 |  |
| 4.50% due May 2025 | 750 |  |  | — |  |
| 4.65% due May 2027 | 500 |  |  | — |  |
| 3.90% due August 2027 | 1,250 |  |  | 1,250 |  |
| 4.70% due May 2030 | 750 |  |  | — |  |
| VMware Term Loan Facility | 1,500 |  |  | 1,500 |  |
| DFS Debt (Note 4) | 8,837 |  |  | 7,765 |  |
| Other |  |  |  |
| 2.51% Margin Loan Facility due April 2022 | 4,000 |  |  | 4,000 |  |
| Other | 147 |  |  | 84 |  |
| Total debt, principal amount | $ | 54,537 |  |  | $ | 52,665 |  |
  (was, 2020-06-08, similarity 0.6843):
[0001571996-20-000034:note_history:44]
|  | May 1, 2020 |  | January 31, 2020 |
|  | (in millions) |
| Secured Debt |  |  |  |
| Senior Secured Credit Facilities: |  |  |  |
| 2.75% Term Loan B-1 Facility due September 2025 | $ | 4,726 |  |  | $ | 4,738 |  |
| 2.16% Term Loan A-4 Facility due December 2023 | 679 |  |  | 679 |  |
| 2.32% Term Loan A-6 Facility due March 2024 | 3,452 |  |  | 3,497 |  |
| First Lien Notes: |  |  |  |
| 4.42% due June 2021 | 4,500 |  |  | 4,500 |  |
| 5.45% due June 2023 | 3,750 |  |  | 3,750 |  |
| 4.00% due July 2024 | 1,000 |  |  | 1,000 |  |
| 5.85% due July 2025 | 1,000 |  |  | — |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 4.90% due October 2026 | 1,750 |  |  | 1,750 |  |
| 6.10% due July 2027 | 500 |  |  | — |  |
| 5.30% due October 2029 | 1,750 |  |  | 1,750 |  |
| 6.20% due July 2030 | 750 |  |  | — |  |
| 8.10% due July 2036 | 1,500 |  |  | 1,500 |  |
| 8.35% due July 2046 | 2,000 |  |  | 2,000 |  |
| Unsecured Debt |  |  |  |
| Unsecured Notes and Debentures: |  |  |  |
| 4.625% due April 2021 | 400 |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| Senior Notes: |  |  |  |
| 5.875% due June 2021 | 1,075 |  |  | 1,075 |  |
| 7.125% due June 2024 | 1,625 |  |  | 1,625 |  |
| EMC Notes: |  |  |  |
| 2.650% due June 2020 | 600 |  |  | 600 |  |
| 3.375% due June 2023 | 1,000 |  |  | 1,000 |  |
| Debt of Public Subsidiary |  |  |  |
| VMware Notes: |  |  |  |
| 2.30% due August 2020 | 1,250 |  |  | 1,250 |  |
| 2.95% due August 2022 | 1,500 |  |  | 1,500 |  |
| 4.50% due May 2025 | 750 |  |  | — |  |
| 4.65% due May 2027 | 500 |  |  | — |  |
| 3.90% due August 2027 | 1,250 |  |  | 1,250 |  |
| 4.70% due May 2030 | 750 |  |  | — |  |
| VMware Term Loan Facility | 1,500 |  |  | 1,500 |  |
| DFS Debt (Note 4) | 8,269 |  |  | 7,765 |  |
| Other |  |  |  |
| 4.03% Margin Loan Facility due April 2022 | 4,000 |  |  | 4,000 |  |
| Other | 69 |  |  | 84 |  |
| Total debt, principal amount | $ | 57,347 |  |  | $ | 52,665 |  |

- changed (2020-09-04):
[0001571996-20-000045:note_history:45]
|  | July 31, 2020 |  | January 31, 2020 |
|  | (in millions) |  |  |
| Total debt, principal amount | $ | 54,537 |  |  | $ | 52,665 |  |
| Unamortized discount, net of unamortized premium | (226) |  |  | (241) |  |
| Debt issuance costs | (358) |  |  | (368) |  |
| Total debt, carrying value | $ | 53,953 |  |  | $ | 52,056 |  |
| Total short-term debt, carrying value | $ | 10,345 |  |  | $ | 7,737 |  |
| Total long-term debt, carrying value | $ | 43,608 |  |  | $ | 44,319 |  |
  (was, 2020-06-08, similarity 0.9265):
[0001571996-20-000034:note_history:45]
|  | May 1, 2020 |  | January 31, 2020 |
|  | (in millions) |
| Total debt, principal amount | $ | 57,347 |  |  | $ | 52,665 |  |
| Unamortized discount, net of unamortized premium | (234 | ) |  | (241 | ) |
| Debt issuance costs | (385 | ) |  | (368 | ) |
| Total debt, carrying value | $ | 56,728 |  |  | $ | 52,056 |  |
| Total short-term debt, carrying value | $ | 8,375 |  |  | $ | 7,737 |  |
| Total long-term debt, carrying value | $ | 48,353 |  |  | $ | 44,319 |  |

- added (2020-09-04):
[0001571996-20-000045:note_history:46]
During the six months ended July 31, 2020, the net increase in the Company’s debt balance was primarily due to new issuances of $2.25 billion of First Lien Notes on April 9, 2020 and $2.0 billion of VMware Notes on April 7, 2020, both described below, and the incurrence of an additional $1.1 billion, net, in DFS debt to support the expansion of its financing receivables portfolio.  These increases were partially offset by repayment of $1.2 billion and open market repurchases of $235 million of 4.42% First Lien Notes due June 2021, repayment of $600 million principal amount of 2.650% EMC Notes due June 2020 upon maturity, approximately $229 million of principal amortization under the Company’s term loan facilities, and repayment of $1.25 billion principal amount of 2.30% VMware Notes due August 2020.

- changed (2020-09-04):
[0001571996-20-000045:note_history:47]
As of July 31, 2020, available borrowings under the Revolving Credit Facility totaled $4.5 billion.  The Senior Secured Credit Facilities provide that the borrowers have the right at any time, subject to customary conditions, to request incremental term loans or incremental revolving commitments.
  (was, 2020-06-08, similarity 0.9913):
[0001571996-20-000034:note_history:47]
As of May 1, 2020, available borrowings under the Revolving Credit Facility totaled $4.5 billion.  The Senior Secured Credit Facilities provide that the borrowers have the right at any time, subject to customary conditions, to request incremental term loans or incremental revolving commitments.

- changed (2020-09-04):
[0001571996-20-000045:note_history:48]
All obligations of the borrowers under the Senior Secured Credit Facilities and certain swap agreements, cash management arrangements, and certain letters of credit provided by any lender or agent party to the Senior Secured Credit Facilities or any of its affiliates and certain other persons are secured by (a) a first-priority security interest in certain tangible and intangible assets of the borrowers and the guarantors and (b) a first-priority pledge of 100% of the capital stock of the borrowers, Dell Inc., a wholly-owned subsidiary of the Company (“Dell”), and each wholly-owned material restricted subsidiary of the borrowers and the guarantors, in each case subject to certain thresholds, exceptions, and permitted liens.
  (was, 2020-06-08, similarity 0.9986):
[0001571996-20-000034:note_history:48]
All obligations of the borrowers under the Senior Secured Credit Facilities and certain swap agreements, cash management arrangements, and certain letters of credit provided by any lender or agent party to the Senior Secured Credit Facilities or any of its affiliates and certain other persons are secured by (a) a first-priority security interest in certain tangible and intangible assets of the borrowers and the guarantors and (b) a first-priority pledge of 100% of the capital stock of the borrowers, Dell Inc., a wholly‑owned subsidiary of the Company (“Dell”), and each wholly-owned material restricted subsidiary of the borrowers and the guarantors, in each case subject to certain thresholds, exceptions, and permitted liens.

- added (2020-09-04):
[0001571996-20-000045:note_history:49]
China Revolving Credit Facility — The Company entered into a new revolving credit facility for China (the “China Revolving Credit Facility”) effective May 25, 2020.  The new terms provide for collateralized and non-collateralized principal amounts not to exceed $1.0 billion Chinese renminbi and $1.8 billion Chinese renminbi, respectively, or equivalent amounts in U.S. dollars.  Outstanding borrowings under the collateralized portion of the China Revolving Credit Facility bear interest at the loan prime rate (“LPR”) less 0.2%, for borrowings denominated in Chinese renminbi, or LIBOR plus 1.0%, for borrowings denominated in U.S. dollars, and outstanding borrowings under the non-collateralized portion bear interest at LPR less 0.2%, for borrowings denominated in Chinese renminbi, or LIBOR plus 1.4%, for borrowings denominated in U.S. dollars.  The new facility expired on August 30, 2020.

- changed (2020-09-04):
[0001571996-20-000045:note_history:50]
During the fiscal year ended January 31, 2020, the Company renewed the credit agreement for its legacy China revolving credit facility with a bank lender, which provided an uncommitted line with an aggregate principal amount not to exceed $500 million at an interest rate of LIBOR plus 0.6% per annum.  The facility was terminated upon expiration on February 26, 2020.
  (was, 2020-06-08, similarity 0.8693):
[0001571996-20-000034:note_history:50]
China Revolving Credit Facility — During the fiscal year ended January 31, 2020, the Company renewed its credit agreement for a China revolving credit facility with a bank lender, which provided an uncommitted line with an aggregate principal amount not to exceed $500 million at an interest rate of LIBOR plus 0.6% per annum.  The facility was terminated upon expiration on February 26, 2020.

- changed (2020-09-04):
[0001571996-20-000045:note_history:51]
VMware Revolving Credit Facility — On September 12, 2017, VMware, Inc. entered into an unsecured credit agreement, establishing a revolving credit facility (the “VMware Revolving Credit Facility”) with a syndicate of lenders that provides the company with a borrowing capacity of up to $1.0 billion for VMware, Inc. general corporate purposes.  Commitments under the VMware Revolving Credit Facility are available for a period of five years, which may be extended, subject to the satisfaction of certain conditions, by up to two one year periods.  The credit agreement contains certain representations, warranties, and covenants.  Commitment fees, interest rates, and other terms of borrowing under the VMware Revolving Credit Facility may vary based on VMware, Inc.’s external credit ratings.  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.  As of July 31, 2020, there were no outstanding borrowings under the VMware Revolving Credit Facility.
  (was, 2020-06-08, similarity 0.9978):
[0001571996-20-000034:note_history:51]
VMware Revolving Credit Facility — On September 12, 2017, VMware, Inc. entered into an unsecured credit agreement, establishing a revolving credit facility (the “VMware Revolving Credit Facility”) with a syndicate of lenders that provides the company with a borrowing capacity of up to $1.0 billion for VMware, Inc. general corporate purposes.  Commitments under the VMware Revolving Credit Facility are available for a period of five years, which may be extended, subject to the satisfaction of certain conditions, by up to two one year periods.  The credit agreement contains certain representations, warranties, and covenants.  Commitment fees, interest rates, and other terms of borrowing under the VMware Revolving Credit Facility may vary based on VMware, Inc.’s external credit ratings.  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.  As of May 1, 2020, there were no outstanding borrowings under the VMware Revolving Credit Facility.

- changed (2020-09-04):
[0001571996-20-000045:note_history:52]
VMware Term Loan Facility — On September 26, 2019, VMware, Inc. entered into a senior unsecured term loan facility (the “VMware Term Loan Facility”) with a syndicate of lenders that provided VMware, Inc. with a borrowing capacity of up to $2.0 billion through February 7, 2020, for VMware, Inc. general corporate purposes.  The VMware Term Loan Facility matures during the third quarter of Fiscal 2021, on the 364th day following the initial funding under the facility.  The VMware Term Loan Facility bears interest at LIBOR plus 0.75% to 1.25%, or an alternative base rate plus 0.00% to 0.25%, depending on VMware Inc.’s external credit ratings.
  (was, 2020-06-08, similarity 0.9689):
[0001571996-20-000034:note_history:52]
VMware Term Loan Facility — On September 26, 2019, VMware, Inc. entered into a senior unsecured term loan facility (the “VMware Term Loan Facility”) with a syndicate of lenders that provided VMware, Inc. with a borrowing capacity of up to $2.0 billion through February 7, 2020, for VMware, Inc. general corporate purposes.  The VMware Term Loan Facility matures on the 364th day following the initial funding under the facility.  The VMware Term Loan Facility bears interest at LIBOR plus 0.75% to 1.25%, or an alternative base rate plus 0.00% to 0.25%, depending on VMware Inc.’s external credit ratings.

- changed (2020-09-04):
[0001571996-20-000045:note_history:53]
As of July 31, 2020 and January 31, 2020, the outstanding borrowings under the VMware Term Loan Facility were $1.5 billion, with no remaining amount available for additional borrowings.  The VMware Term Loan Facility agreement contains certain representations, warranties, and covenants.  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.
  (was, 2020-06-08, similarity 0.9854):
[0001571996-20-000034:note_history:53]
As of May 1, 2020 and January 31, 2020, the outstanding borrowings under the VMware Term Loan Facility were $1.5 billion, with no remaining amount available for additional borrowings.  The VMware Term Loan Facility contains certain representations, warranties, and covenants.  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.

- changed (2020-09-04):
[0001571996-20-000045:note_history:54]
The following table presents the aggregate future maturities of the Company’s debt as of July 31, 2020 for the periods indicated:
  (was, 2020-06-08, similarity 0.9798):
[0001571996-20-000034:note_history:54]
The following table presents the aggregate future maturities of the Company’s debt as of May 1, 2020 for the periods indicated:

- changed (2020-09-04):
[0001571996-20-000045:note_history:55]
|  | Maturities by Fiscal Year |  |  |  |  |  |  |  |  |  |  |  |  |
|  | 2021 (remaining six months) |  | 2022 |  | 2023 |  | 2024 |  | 2025 |  | Thereafter |  | Total |
|  | (in millions) |  |  |  |  |  |  |  |  |  |  |  |  |
| Senior Secured Credit Facilities and First Lien Notes | $ | — |  |  | $ | 3,237 |  |  | $ | 286 |  |  | $ | 6,702 |  |  | $ | 1,775 |  |  | $ | 18,251 |  |  | $ | 30,251 |  |
| Unsecured Notes and Debentures | — |  |  | 400 |  |  | — |  |  | — |  |  | — |  |  | 952 |  |  | 1,352 |  |
| Senior Notes and EMC Notes | — |  |  | 1,075 |  |  | — |  |  | 1,000 |  |  | 1,625 |  |  | — |  |  | 3,700 |  |
| VMware Notes | 1,500 |  |  | — |  |  | 1,500 |  |  | — |  |  | — |  |  | 3,250 |  |  | 6,250 |  |
| DFS Debt | 2,912 |  |  | 2,906 |  |  | 2,229 |  |  | 163 |  |  | 627 |  |  | — |  |  | 8,837 |  |
| Margin Loan Facility | — |  |  | — |  |  | 4,000 |  |  | — |  |  | — |  |  | — |  |  | 4,000 |  |
| Other | 5 |  |  | 10 |  |  | 11 |  |  | 8 |  |  | 8 |  |  | 105 |  |  | 147 |  |
| Total maturities, principal amount | 4,417 |  |  | 7,628 |  |  | 8,026 |  |  | 7,873 |  |  | 4,035 |  |  | 22,558 |  |  | 54,537 |  |
| Associated carrying value adjustments | (1) |  |  | (29) |  |  | (21) |  |  | (43) |  |  | (84) |  |  | (406) |  |  | (584) |  |
| Total maturities, carrying value amount | $ | 4,416 |  |  | $ | 7,599 |  |  | $ | 8,005 |  |  | $ | 7,830 |  |  | $ | 3,951 |  |  | $ | 22,152 |  |  | $ | 53,953 |  |
  (was, 2020-06-08, similarity 0.9566):
[0001571996-20-000034:note_history:55]
|  | Maturities by Fiscal Year |
|  | 2021 (remaining nine months) |  | 2022 |  | 2023 |  | 2024 |  | 2025 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Secured Credit Facilities and First Lien Notes | $ | 172 |  |  | $ | 4,672 |  |  | $ | 286 |  |  | $ | 6,702 |  |  | $ | 1,775 |  |  | $ | 18,250 |  |  | $ | 31,857 |  |
| Unsecured Notes and Debentures | — |  |  | 400 |  |  | — |  |  | — |  |  | — |  |  | 952 |  |  | 1,352 |  |
| Senior Notes and EMC Notes | 600 |  |  | 1,075 |  |  | — |  |  | 1,000 |  |  | 1,625 |  |  | — |  |  | 4,300 |  |
| VMware Notes | 2,750 |  |  | — |  |  | 1,500 |  |  | — |  |  | — |  |  | 3,250 |  |  | 7,500 |  |
| DFS Debt | 3,661 |  |  | 2,537 |  |  | 1,877 |  |  | 157 |  |  | 37 |  |  | — |  |  | 8,269 |  |
| Margin Loan Facility | — |  |  | — |  |  | 4,000 |  |  | — |  |  | — |  |  | — |  |  | 4,000 |  |
| Other | 8 |  |  | 6 |  |  | 7 |  |  | 8 |  |  | 7 |  |  | 33 |  |  | 69 |  |
| Total maturities, principal amount | 7,191 |  |  | 8,690 |  |  | 7,670 |  |  | 7,867 |  |  | 3,444 |  |  | 22,485 |  |  | 57,347 |  |
| Associated carrying value adjustments | (2 | ) |  | (43 | ) |  | (24 | ) |  | (47 | ) |  | (91 | ) |  | (412 | ) |  | (619 | ) |
| Total maturities, carrying value amount | $ | 7,189 |  |  | $ | 8,647 |  |  | $ | 7,646 |  |  | $ | 7,820 |  |  | $ | 3,353 |  |  | $ | 22,073 |  |  | $ | 56,728 |  |

- changed (2020-09-04):
[0001571996-20-000045:note_history:56]
Covenants and Unrestricted Net Assets — The credit agreement for the Senior Secured Credit Facilities contains customary negative covenants that generally limit the ability of Denali Intermediate Inc., a wholly-owned subsidiary of Dell Technologies, Dell, and Dell’s and Denali Intermediate’s other restricted subsidiaries to incur debt, create liens, make fundamental changes, enter into asset sales, make certain investments, pay dividends or distribute or redeem certain equity interests, prepay or redeem certain debt, and enter into certain transactions with affiliates.  The indenture governing the Senior Notes contains customary negative covenants that generally limit the ability of Denali Intermediate, Dell, and Dell’s and Denali Intermediate’s other restricted subsidiaries to incur additional debt or issue certain preferred shares, pay dividends on or make other distributions in respect of capital stock or make other restricted payments, make certain investments, sell or transfer certain assets, create liens on certain assets to secure debt, consolidate, merge, sell, or otherwise dispose of all or substantially all assets, enter into certain transactions with affiliates, and designate subsidiaries as unrestricted subsidiaries.  The negative covenants under such credit agreements and indenture are subject to certain exceptions, qualifications, and “baskets.”  The indentures governing the First Lien Notes, the Unsecured Notes and Debentures, and the EMC Notes variously impose limitations, subject to specified exceptions, on creating certain liens, entering into sale and lease-back transactions, and entering into certain asset sales.  The foregoing credit agreements and indentures contain customary events of default, including failure to make required payments, failure to comply with covenants, and the occurrence of certain events of bankruptcy and insolvency.
  (was, 2020-06-08, similarity 0.9942):
[0001571996-20-000034:note_history:56]
Covenants and Unrestricted Net Assets — The credit agreement for the Senior Secured Credit Facilities contains customary negative covenants that generally limit the ability of Denali Intermediate Inc., a wholly-owned subsidiary of Dell Technologies (“Dell Intermediate”), Dell, and Dell’s and Denali Intermediate’s other restricted subsidiaries to incur debt, create liens, make fundamental changes, enter into asset sales, make certain investments, pay dividends or distribute or redeem certain equity interests, prepay or redeem certain debt, and enter into certain transactions with affiliates.  The indenture governing the Senior Notes contains customary negative covenants that generally limit the ability of Denali Intermediate, Dell, and Dell’s and Denali Intermediate’s other restricted subsidiaries to incur additional debt or issue certain preferred shares, pay dividends on or make other distributions in respect of capital stock or make other restricted payments, make certain investments, sell or transfer certain assets, create liens on certain assets to secure debt, consolidate, merge, sell, or otherwise dispose of all or substantially all assets, enter into certain transactions with affiliates, and designate subsidiaries as unrestricted subsidiaries.  The negative covenants under such credit agreements and indenture are subject to certain exceptions, qualifications, and “baskets.”  The indentures governing the First Lien Notes, the Unsecured Notes and Debentures, and the EMC Notes variously impose limitations, subject to specified exceptions, on creating certain liens, entering into sale and lease-back transactions, and entering into certain asset sales.  The foregoing credit agreements and indentures contain customary events of default, including failure to make required payments, failure to comply with covenants, and the occurrence of certain events of bankruptcy and insolvency.

- changed (2020-09-04):
[0001571996-20-000045:note_history:57]
As of July 31, 2020, the Company had certain consolidated subsidiaries that were designated as unrestricted subsidiaries for all purposes of the applicable credit agreements and the indentures governing the First Lien Notes and the Senior Notes.  Substantially all of the net assets of the Company’s consolidated subsidiaries were restricted, with the exception of the Company’s unrestricted subsidiaries, primarily VMware, Inc., Secureworks, and their respective subsidiaries, as of July 31, 2020.
  (was, 2020-06-08, similarity 0.9897):
[0001571996-20-000034:note_history:57]
As of May 1, 2020, the Company had certain consolidated subsidiaries that were designated as unrestricted subsidiaries for all purposes of the applicable credit agreements and the indentures governing the First Lien Notes and the Senior Notes.  Substantially all of the net assets of the Company’s consolidated subsidiaries were restricted, with the exception of the Company’s unrestricted subsidiaries, primarily VMware, Inc., Secureworks, and their respective subsidiaries, as of May 1, 2020.

- changed (2020-09-04):
[0001571996-20-000045:note_history:58]
The Term Loan A-4 Facility, the Term Loan A-6 Facility, and the Revolving Credit Facility are subject to a first lien leverage ratio covenant that is tested at the end of each fiscal quarter of Dell with respect to Dell’s preceding four fiscal quarters.  The Company was in compliance with all financial covenants as of July 31, 2020.
  (was, 2020-06-08, similarity 0.9923):
[0001571996-20-000034:note_history:58]
The Term Loan A-4 Facility, the Term Loan A-6 Facility, and the Revolving Credit Facility are subject to a first lien leverage ratio covenant that is tested at the end of each fiscal quarter of Dell with respect to Dell’s preceding four fiscal quarters.  The Company was in compliance with all financial covenants as of May 1, 2020.

- removed (2020-09-04):
[0001571996-20-000034:note_history:59]
During the three months ended May 1, 2020, the net increase in the Company’s debt balance was primarily due to new debt issuances of $2.25 billion of First Lien Notes on April 9, 2020 and $2.0 billion of VMware Notes on April 7, 2020, both described below, and an additional $0.5 billion, net, in DFS debt to support the expansion of its financing receivables portfolio.


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-09-04):
[0001571996-20-000045:note_history:60]
|  | July 31, 2020 |  |  |  | January 31, 2020 |  |  |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |  |  |  |  |  |  |
| Senior Secured Credit Facilities | $ | 8.6 |  |  | $ | 8.6 |  |  | $ | 8.8 |  |  | $ | 9.0 |  |
| First Lien Notes | $ | 21.3 |  |  | $ | 25.1 |  |  | $ | 20.5 |  |  | $ | 23.9 |  |
| Unsecured Notes and Debentures | $ | 1.2 |  |  | $ | 1.5 |  |  | $ | 1.2 |  |  | $ | 1.5 |  |
| Senior Notes | $ | 2.6 |  |  | $ | 2.8 |  |  | $ | 2.6 |  |  | $ | 2.8 |  |
| EMC Notes | $ | 1.0 |  |  | $ | 1.1 |  |  | $ | 1.6 |  |  | $ | 1.6 |  |
| VMware Notes and VMware Term Loan Facility | $ | 6.2 |  |  | $ | 6.8 |  |  | $ | 5.5 |  |  | $ | 5.6 |  |
| Margin Loan Facility | $ | 4.0 |  |  | $ | 3.9 |  |  | $ | 4.0 |  |  | $ | 3.9 |  |
  (was, 2020-06-08, similarity 0.9158):
[0001571996-20-000034:note_history:60]
|  | May 1, 2020 |  | January 31, 2020 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Secured Credit Facilities | $ | 8.7 |  |  | $ | 8.6 |  |  | $ | 8.8 |  |  | $ | 9.0 |  |
| First Lien Notes | $ | 22.8 |  |  | $ | 24.8 |  |  | $ | 20.5 |  |  | $ | 23.9 |  |
| Unsecured Notes and Debentures | $ | 1.2 |  |  | $ | 1.4 |  |  | $ | 1.2 |  |  | $ | 1.5 |  |
| Senior Notes | $ | 2.6 |  |  | $ | 2.8 |  |  | $ | 2.6 |  |  | $ | 2.8 |  |
| EMC Notes | $ | 1.6 |  |  | $ | 1.6 |  |  | $ | 1.6 |  |  | $ | 1.6 |  |
| VMware Notes and VMware Term Loan Facility | $ | 7.5 |  |  | $ | 7.7 |  |  | $ | 5.5 |  |  | $ | 5.6 |  |
| Margin Loan Facility | $ | 4.0 |  |  | $ | 3.9 |  |  | $ | 4.0 |  |  | $ | 3.9 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-09-04):
[0001571996-20-000045:note_history:61]
|  | July 31, 2020 |  | January 31, 2020 |
|  | (in millions) |  |  |
| DFS U.S. debt: |  |  |  |
| Asset-based financing and securitization facilities | $ | 2,936 |  |  | $ | 2,606 |  |
| Fixed-term securitization offerings | 2,788 |  |  | 2,593 |  |
| Other | 187 |  |  | 141 |  |
| Total DFS U.S. debt | 5,911 |  |  | 5,340 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 835 |  |  | 743 |  |
| Other borrowings | 719 |  |  | 931 |  |
| Note payable | 187 |  |  | 200 |  |
| Dell Bank Senior Unsecured Eurobonds | 1,185 |  |  | 551 |  |
| Total DFS international debt | 2,926 |  |  | 2,425 |  |
| Total DFS debt | $ | 8,837 |  |  | $ | 7,765 |  |
| Total short-term DFS debt | $ | 4,188 |  |  | $ | 4,152 |  |
| Total long-term DFS debt | $ | 4,649 |  |  | $ | 3,613 |  |
  (was, 2020-06-08, similarity 0.9704):
[0001571996-20-000034:note_history:61]
|  | May 1, 2020 |  | January 31, 2020 |
|  | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing and securitization facilities | $ | 2,429 |  |  | $ | 2,606 |  |
| Fixed-term securitization offerings | 3,251 |  |  | 2,593 |  |
| Other | 117 |  |  | 141 |  |
| Total DFS U.S. debt | 5,797 |  |  | 5,340 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 773 |  |  | 743 |  |
| Other borrowings | 970 |  |  | 931 |  |
| Note payable | 181 |  |  | 200 |  |
| Dell Bank Senior Unsecured Eurobonds | 548 |  |  | 551 |  |
| Total DFS international debt | 2,472 |  |  | 2,425 |  |
| Total DFS debt | $ | 8,269 |  |  | $ | 7,765 |  |
| Total short-term DFS debt | $ | 4,397 |  |  | $ | 4,152 |  |
| Total long-term DFS debt | $ | 3,872 |  |  | $ | 3,613 |  |

- changed (2020-09-04):
[0001571996-20-000045:note_history:62]
|  | July 31, 2020 |  | January 31, 2020 |
|  | (in millions) |  |  |
| Secured Debt |  |  |  |
| Senior Secured Credit Facilities: |  |  |  |
| 2.75% Term Loan B-1 Facility due September 2025 | $ | 4,691 |  |  | $ | 4,738 |  |
| 1.93% Term Loan A-4 Facility due December 2023 | 679 |  |  | 679 |  |
| 1.93% Term Loan A-6 Facility due March 2024 | 3,316 |  |  | 3,497 |  |
| First Lien Notes: |  |  |  |
| 4.42% due June 2021 | 3,065 |  |  | 4,500 |  |
| 5.45% due June 2023 | 3,750 |  |  | 3,750 |  |
| 4.00% due July 2024 | 1,000 |  |  | 1,000 |  |
| 5.85% due July 2025 | 1,000 |  |  | — |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 4.90% due October 2026 | 1,750 |  |  | 1,750 |  |
| 6.10% due July 2027 | 500 |  |  | — |  |
| 5.30% due October 2029 | 1,750 |  |  | 1,750 |  |
| 6.20% due July 2030 | 750 |  |  | — |  |
| 8.10% due July 2036 | 1,500 |  |  | 1,500 |  |
| 8.35% due July 2046 | 2,000 |  |  | 2,000 |  |
| Unsecured Debt |  |  |  |
| Unsecured Notes and Debentures: |  |  |  |
| 4.625% due April 2021 | 400 |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| Senior Notes: |  |  |  |
| 5.875% due June 2021 | 1,075 |  |  | 1,075 |  |
| 7.125% due June 2024 | 1,625 |  |  | 1,625 |  |
| EMC Notes: |  |  |  |
| 2.650% due June 2020 | — |  |  | 600 |  |
| 3.375% due June 2023 | 1,000 |  |  | 1,000 |  |
| Debt of Public Subsidiary |  |  |  |
| VMware Notes: |  |  |  |
| 2.30% due August 2020 | — |  |  | 1,250 |  |
| 2.95% due August 2022 | 1,500 |  |  | 1,500 |  |
| 4.50% due May 2025 | 750 |  |  | — |  |
| 4.65% due May 2027 | 500 |  |  | — |  |
| 3.90% due August 2027 | 1,250 |  |  | 1,250 |  |
| 4.70% due May 2030 | 750 |  |  | — |  |
| VMware Term Loan Facility | 1,500 |  |  | 1,500 |  |
| DFS Debt (Note 4) | 8,837 |  |  | 7,765 |  |
| Other |  |  |  |
| 2.51% Margin Loan Facility due April 2022 | 4,000 |  |  | 4,000 |  |
| Other | 147 |  |  | 84 |  |
| Total debt, principal amount | $ | 54,537 |  |  | $ | 52,665 |  |
  (was, 2020-06-08, similarity 0.6843):
[0001571996-20-000034:note_history:62]
|  | May 1, 2020 |  | January 31, 2020 |
|  | (in millions) |
| Secured Debt |  |  |  |
| Senior Secured Credit Facilities: |  |  |  |
| 2.75% Term Loan B-1 Facility due September 2025 | $ | 4,726 |  |  | $ | 4,738 |  |
| 2.16% Term Loan A-4 Facility due December 2023 | 679 |  |  | 679 |  |
| 2.32% Term Loan A-6 Facility due March 2024 | 3,452 |  |  | 3,497 |  |
| First Lien Notes: |  |  |  |
| 4.42% due June 2021 | 4,500 |  |  | 4,500 |  |
| 5.45% due June 2023 | 3,750 |  |  | 3,750 |  |
| 4.00% due July 2024 | 1,000 |  |  | 1,000 |  |
| 5.85% due July 2025 | 1,000 |  |  | — |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 4.90% due October 2026 | 1,750 |  |  | 1,750 |  |
| 6.10% due July 2027 | 500 |  |  | — |  |
| 5.30% due October 2029 | 1,750 |  |  | 1,750 |  |
| 6.20% due July 2030 | 750 |  |  | — |  |
| 8.10% due July 2036 | 1,500 |  |  | 1,500 |  |
| 8.35% due July 2046 | 2,000 |  |  | 2,000 |  |
| Unsecured Debt |  |  |  |
| Unsecured Notes and Debentures: |  |  |  |
| 4.625% due April 2021 | 400 |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| Senior Notes: |  |  |  |
| 5.875% due June 2021 | 1,075 |  |  | 1,075 |  |
| 7.125% due June 2024 | 1,625 |  |  | 1,625 |  |
| EMC Notes: |  |  |  |
| 2.650% due June 2020 | 600 |  |  | 600 |  |
| 3.375% due June 2023 | 1,000 |  |  | 1,000 |  |
| Debt of Public Subsidiary |  |  |  |
| VMware Notes: |  |  |  |
| 2.30% due August 2020 | 1,250 |  |  | 1,250 |  |
| 2.95% due August 2022 | 1,500 |  |  | 1,500 |  |
| 4.50% due May 2025 | 750 |  |  | — |  |
| 4.65% due May 2027 | 500 |  |  | — |  |
| 3.90% due August 2027 | 1,250 |  |  | 1,250 |  |
| 4.70% due May 2030 | 750 |  |  | — |  |
| VMware Term Loan Facility | 1,500 |  |  | 1,500 |  |
| DFS Debt (Note 4) | 8,269 |  |  | 7,765 |  |
| Other |  |  |  |
| 4.03% Margin Loan Facility due April 2022 | 4,000 |  |  | 4,000 |  |
| Other | 69 |  |  | 84 |  |
| Total debt, principal amount | $ | 57,347 |  |  | $ | 52,665 |  |

- changed (2020-09-04):
[0001571996-20-000045:note_history:63]
|  | July 31, 2020 |  | January 31, 2020 |
|  | (in millions) |  |  |
| Total debt, principal amount | $ | 54,537 |  |  | $ | 52,665 |  |
| Unamortized discount, net of unamortized premium | (226) |  |  | (241) |  |
| Debt issuance costs | (358) |  |  | (368) |  |
| Total debt, carrying value | $ | 53,953 |  |  | $ | 52,056 |  |
| Total short-term debt, carrying value | $ | 10,345 |  |  | $ | 7,737 |  |
| Total long-term debt, carrying value | $ | 43,608 |  |  | $ | 44,319 |  |
  (was, 2020-06-08, similarity 0.9265):
[0001571996-20-000034:note_history:63]
|  | May 1, 2020 |  | January 31, 2020 |
|  | (in millions) |
| Total debt, principal amount | $ | 57,347 |  |  | $ | 52,665 |  |
| Unamortized discount, net of unamortized premium | (234 | ) |  | (241 | ) |
| Debt issuance costs | (385 | ) |  | (368 | ) |
| Total debt, carrying value | $ | 56,728 |  |  | $ | 52,056 |  |
| Total short-term debt, carrying value | $ | 8,375 |  |  | $ | 7,737 |  |
| Total long-term debt, carrying value | $ | 48,353 |  |  | $ | 44,319 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-09-04):
[0001571996-20-000045:note_history:64]
The following table presents the aggregate future maturities of the Company’s debt as of July 31, 2020 for the periods indicated:
  (was, 2020-06-08, similarity 0.9798):
[0001571996-20-000034:note_history:64]
The following table presents the aggregate future maturities of the Company’s debt as of May 1, 2020 for the periods indicated:

- changed (2020-09-04):
[0001571996-20-000045:note_history:65]
|  | Maturities by Fiscal Year |  |  |  |  |  |  |  |  |  |  |  |  |
|  | 2021 (remaining six months) |  | 2022 |  | 2023 |  | 2024 |  | 2025 |  | Thereafter |  | Total |
|  | (in millions) |  |  |  |  |  |  |  |  |  |  |  |  |
| Senior Secured Credit Facilities and First Lien Notes | $ | — |  |  | $ | 3,237 |  |  | $ | 286 |  |  | $ | 6,702 |  |  | $ | 1,775 |  |  | $ | 18,251 |  |  | $ | 30,251 |  |
| Unsecured Notes and Debentures | — |  |  | 400 |  |  | — |  |  | — |  |  | — |  |  | 952 |  |  | 1,352 |  |
| Senior Notes and EMC Notes | — |  |  | 1,075 |  |  | — |  |  | 1,000 |  |  | 1,625 |  |  | — |  |  | 3,700 |  |
| VMware Notes | 1,500 |  |  | — |  |  | 1,500 |  |  | — |  |  | — |  |  | 3,250 |  |  | 6,250 |  |
| DFS Debt | 2,912 |  |  | 2,906 |  |  | 2,229 |  |  | 163 |  |  | 627 |  |  | — |  |  | 8,837 |  |
| Margin Loan Facility | — |  |  | — |  |  | 4,000 |  |  | — |  |  | — |  |  | — |  |  | 4,000 |  |
| Other | 5 |  |  | 10 |  |  | 11 |  |  | 8 |  |  | 8 |  |  | 105 |  |  | 147 |  |
| Total maturities, principal amount | 4,417 |  |  | 7,628 |  |  | 8,026 |  |  | 7,873 |  |  | 4,035 |  |  | 22,558 |  |  | 54,537 |  |
| Associated carrying value adjustments | (1) |  |  | (29) |  |  | (21) |  |  | (43) |  |  | (84) |  |  | (406) |  |  | (584) |  |
| Total maturities, carrying value amount | $ | 4,416 |  |  | $ | 7,599 |  |  | $ | 8,005 |  |  | $ | 7,830 |  |  | $ | 3,951 |  |  | $ | 22,152 |  |  | $ | 53,953 |  |
  (was, 2020-06-08, similarity 0.9566):
[0001571996-20-000034:note_history:65]
|  | Maturities by Fiscal Year |
|  | 2021 (remaining nine months) |  | 2022 |  | 2023 |  | 2024 |  | 2025 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Secured Credit Facilities and First Lien Notes | $ | 172 |  |  | $ | 4,672 |  |  | $ | 286 |  |  | $ | 6,702 |  |  | $ | 1,775 |  |  | $ | 18,250 |  |  | $ | 31,857 |  |
| Unsecured Notes and Debentures | — |  |  | 400 |  |  | — |  |  | — |  |  | — |  |  | 952 |  |  | 1,352 |  |
| Senior Notes and EMC Notes | 600 |  |  | 1,075 |  |  | — |  |  | 1,000 |  |  | 1,625 |  |  | — |  |  | 4,300 |  |
| VMware Notes | 2,750 |  |  | — |  |  | 1,500 |  |  | — |  |  | — |  |  | 3,250 |  |  | 7,500 |  |
| DFS Debt | 3,661 |  |  | 2,537 |  |  | 1,877 |  |  | 157 |  |  | 37 |  |  | — |  |  | 8,269 |  |
| Margin Loan Facility | — |  |  | — |  |  | 4,000 |  |  | — |  |  | — |  |  | — |  |  | 4,000 |  |
| Other | 8 |  |  | 6 |  |  | 7 |  |  | 8 |  |  | 7 |  |  | 33 |  |  | 69 |  |
| Total maturities, principal amount | 7,191 |  |  | 8,690 |  |  | 7,670 |  |  | 7,867 |  |  | 3,444 |  |  | 22,485 |  |  | 57,347 |  |
| Associated carrying value adjustments | (2 | ) |  | (43 | ) |  | (24 | ) |  | (47 | ) |  | (91 | ) |  | (412 | ) |  | (619 | ) |
| Total maturities, carrying value amount | $ | 7,189 |  |  | $ | 8,647 |  |  | $ | 7,646 |  |  | $ | 7,820 |  |  | $ | 3,353 |  |  | $ | 22,073 |  |  | $ | 56,728 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2020-09-04):
[0001571996-20-000045:note_history:66]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | July 31, 2020 |  | August 2, 2019 |  | July 31, 2020 |  | August 2, 2019 |
|  | (in millions) |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |
| Infrastructure Solutions Group: |  |  |  |  |  |  |  |
| Servers and networking | $ | 4,196 |  |  | $ | 4,437 |  |  | $ | 7,954 |  |  | $ | 8,617 |  |
| Storage | 4,011 |  |  | 4,184 |  |  | 7,822 |  |  | 8,206 |  |
| Total ISG net revenue | 8,207 |  |  | 8,621 |  |  | 15,776 |  |  | 16,823 |  |
| Client Solutions Group: |  |  |  |  |  |  |  |
| Commercial | 8,039 |  |  | 9,077 |  |  | 16,673 |  |  | 17,384 |  |
| Consumer | 3,164 |  |  | 2,671 |  |  | 5,634 |  |  | 5,274 |  |
| Total CSG net revenue | 11,203 |  |  | 11,748 |  |  | 22,307 |  |  | 22,658 |  |
| VMware: |  |  |  |  |  |  |  |
| Total VMware net revenue | 2,908 |  |  | 2,651 |  |  | 5,663 |  |  | 5,108 |  |
| Total segment net revenue | $ | 22,318 |  |  | $ | 23,020 |  |  | $ | 43,746 |  |  | $ | 44,589 |  |

- removed (2020-09-04):
[0001571996-20-000034:note_history:67]
|  | Three Months Ended |
|  | May 1, 2020 |  | May 3, 2019 |
|  | (in millions) |
| Net revenue: |  |  |  |  |
| Infrastructure Solutions Group: |  |  |  |
| Servers and networking | $ | 3,758 |  |  | $ | 4,180 |  |
| Storage | 3,811 |  |  | 4,022 |  |
| Total ISG net revenue | 7,569 |  |  | 8,202 |  |
| Client Solutions Group: |  |  |  |
| Commercial | 8,634 |  |  | 8,307 |  |
| Consumer | 2,470 |  |  | 2,603 |  |
| Total CSG net revenue | 11,104 |  |  | 10,910 |  |
| VMware: |  |  |  |
| Total VMware net revenue | 2,755 |  |  | 2,457 |  |
| Total segment net revenue | $ | 21,428 |  |  | $ | 21,569 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-09-04):
[0001571996-20-000045:note_history:68]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | July 31, 2020 |  | August 2, 2019 |  | July 31, 2020 |  | August 2, 2019 |
|  | (in millions) |  |  |  |  |  |  |
| Deferred revenue: |  |  |  |  |  |  |  |
| Deferred revenue at beginning of period | $ | 27,617 |  |  | $ | 24,178 |  |  | $ | 27,800 |  |  | $ | 24,010 |  |
| Revenue deferrals | 6,550 |  |  | 5,975 |  |  | 12,095 |  |  | 10,875 |  |
| Revenue recognized | (5,376) |  |  | (4,805) |  |  | (10,843) |  |  | (9,537) |  |
| Other (a) | — |  |  | — |  |  | (261) |  |  | — |  |
| Deferred revenue at end of period | $ | 28,791 |  |  | $ | 25,348 |  |  | $ | 28,791 |  |  | $ | 25,348 |  |
| Short-term deferred revenue | $ | 15,341 |  |  | $ | 13,568 |  |  | $ | 15,341 |  |  | $ | 13,568 |  |
| Long-term deferred revenue | $ | 13,450 |  |  | $ | 11,780 |  |  | $ | 13,450 |  |  | $ | 11,780 |  |
  (was, 2020-06-08, similarity 0.7617):
[0001571996-20-000034:note_history:68]
|  | Three Months Ended |
|  | May 1, 2020 |  | May 3, 2019 |
|  | (in millions) |
| Deferred revenue: |  |  |  |
| Deferred revenue at beginning of period | $ | 27,800 |  |  | $ | 24,010 |  |
| Revenue deferrals | 5,423 |  |  | 4,900 |  |
| Revenue recognized | (5,356 | ) |  | (4,732 | ) |
| Other (a) | (250 | ) |  | — |  |
| Deferred revenue at end of period | $ | 27,617 |  |  | $ | 24,178 |  |
| Short-term deferred revenue | $ | 14,766 |  |  | $ | 13,043 |  |
| Long-term deferred revenue | $ | 12,851 |  |  | $ | 11,135 |  |

- changed (2020-09-04):
[0001571996-20-000045:note_history:69]
(a) Reclassification of RSA Security deferred revenue to liabilities held for sale as of July 31, 2020.  See Note 1 and Note 19 of the Notes to the Condensed Consolidated Financial Statements for more information about the divestiture of RSA Security.
  (was, 2020-06-08, similarity 0.9502):
[0001571996-20-000034:note_history:69]
(a) Reclassification of RSA Security deferred revenue to liabilities held for sale as of May 1, 2020.  See Note 1 of the Notes to the Condensed Consolidated Financial Statements for more information about the pending divestiture of RSA Security.

- changed (2020-09-04):
[0001571996-20-000045:note_history:70]
Remaining Performance Obligations — Remaining performance obligations represent the aggregate amount of the transaction price allocated to performance obligations not delivered, or partially undelivered, as of the end of the reporting period.  Remaining performance obligations include deferred revenue plus unbilled amounts not yet recorded in deferred revenue.  The value of the transaction price allocated to remaining performance obligations as of July 31, 2020 was approximately $37 billion.  The Company expects to recognize approximately 62% of remaining performance obligations as revenue in the next twelve months, and the remainder thereafter.
  (was, 2020-06-08, similarity 0.9961):
[0001571996-20-000034:note_history:70]
Remaining Performance Obligations — Remaining performance obligations represent the aggregate amount of the transaction price allocated to performance obligations not delivered, or partially undelivered, as of the end of the reporting period.  Remaining performance obligations include deferred revenue plus unbilled amounts not yet recorded in deferred revenue.  The value of the transaction price allocated to remaining performance obligations as of May 1, 2020 was approximately $37 billion.  The Company expects to recognize approximately 63% of remaining performance obligations as revenue in the next twelve months, and the remainder thereafter.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2020-09-04):
[0001571996-20-000045:note_history:71]
On September 1, 2020, the Company completed its divestiture of RSA Security to a consortium of investors in an all-cash transaction for approximately $2.082 billion.  For more information about this transaction, see Note 1 of the Notes to the Condensed Consolidated Financial Statements.

- changed (2020-09-04):
[0001571996-20-000045:note_history:72]
Other than the matters identified above, there were no known events occurring after July 31, 2020 and up until the date of the issuance of this report that would materially affect the information presented herein.
  (was, 2020-06-08, similarity 0.988):
[0001571996-20-000034:note_history:72]
Other than the matters identified above, there were no known events occurring after May 1, 2020 and up until the date of the issuance of this report that would materially affect the information presented herein.

- removed (2020-09-04):
[0001571996-20-000034:note_history:73]
On May 11, 2020, VMware, Inc. repaid $1.25 billion principal amount of its 2.30% Notes due August 2020.

- removed (2020-09-04):
[0001571996-20-000034:note_history:74]
The Company entered into a new revolving credit facility for China (the “China Revolving Credit Facility”) effective May 25, 2020.  The new terms provide for collateralized and non-collateralized principal amounts not to exceed $1.0 billion Chinese renminbi and $1.8 billion Chinese renminbi, respectively, or equivalent amounts in U.S. dollars.  Outstanding borrowings under the collateralized portion of the China Revolving Credit Facility bear interest at the loan prime rate (LPR) less 0.2%, for borrowings denominated in Chinese renminbi, or LIBOR plus 1.0%, for borrowings denominated in U.S. dollars, and outstanding borrowings under the non-collateralized portion bear interest at LPR less 0.2%, for borrowings denominated in Chinese renminbi, or LIBOR plus 1.4%, for borrowings denominated in U.S. dollars.  The new facility expires on August 30, 2020.
