# DELL notes — 0001571996-20-000045


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001571996-20-000045:notes:1]
Basis of Presentation — The accompanying unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes filed with the U.S. Securities and Exchange Commission (“SEC”) in the Company’s Annual Report on Form 10-K for the fiscal year ended January 31, 2020.  These Condensed Consolidated Financial Statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“GAAP”).  In the opinion of management, the accompanying Condensed Consolidated Financial Statements reflect all adjustments of a normal recurring nature considered necessary to fairly state the financial position of Dell Technologies Inc. as of July 31, 2020 and January 31, 2020, the results of its operations and corresponding comprehensive income (loss) for the three and six months ended July 31, 2020 and August 2, 2019, and its cash flows for the six months ended July 31, 2020 and August 2, 2019.


## us-gaap:ConsolidationPolicyTextBlock

[0001571996-20-000045:notes:2]
[same as prior period, unchanged from 0001571996-20-000034:notes:2]


## us-gaap:ScheduleOfDisposalGroupsIncludingDiscontinuedOperationsIncomeStatementBalanceSheetAndAdditionalDisclosuresTextBlock

[0001571996-20-000045:notes:3]
The following table presents the major classes of assets and liabilities as of July 31, 2020 related to RSA Security which were classified as held for sale as of the date indicated:

[0001571996-20-000045:notes:4]
|  | July 31, 2020 |
|  | (in millions) |
| ASSETS |  |
| Current assets: |  |
| Accounts receivable, net | $ | 146 |  |
| Other current assets | 30 |  |
| Total current assets | 176 |  |
| Goodwill | 1,383 |  |
| Intangible assets, net | 440 |  |
| Other non-current assets | 57 |  |
| Total assets | $ | 2,056 |  |
| LIABILITIES |  |
| Current liabilities: |  |
| Accrued and other | $ | 65 |  |
| Short-term deferred revenue | 229 |  |
| Total current liabilities | 294 |  |
| Long-term deferred revenue | 32 |  |
| Other non-current liabilities | 18 |  |
| Total liabilities | $ | 344 |  |


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001571996-20-000045:notes:5]
Recently Issued Accounting Pronouncements

[0001571996-20-000045:notes:6]
Accounting for Convertible Instruments and Contracts in an Entity’s Own Equity — In August 2020, the Financial Accounting Standards Board (“FASB”) issued guidance to simplify the accounting for convertible debt instruments and convertible preferred stock, and the derivatives scope exception for contracts in an entity's own equity.  In addition, the guidance on calculating diluted earnings per share has been simplified and made more internally consistent.  Public entities must adopt the new guidance for fiscal years beginning after December 15, 2021, and interim periods within those fiscal years, with early adoption permitted for fiscal periods beginning after December 15, 2020.  The Company is currently evaluating the impact and timing of adoption of this guidance.

[0001571996-20-000045:notes:7]
Simplifying Accounting for Income Taxes — In December 2019, the FASB issued guidance to simplify the accounting for income taxes by removing certain exceptions to the general principles in Topic 740, Income Taxes, and by clarifying and amending existing guidance in order to improve consistent application of GAAP for other areas of Topic 740.  Public entities must adopt the new guidance for fiscal years beginning after December 15, 2020, and interim periods within those fiscal years, with early adoption permitted for fiscal periods beginning after December 15, 2019.  The Company is currently evaluating the impact and timing of adoption of this guidance.

[0001571996-20-000045:notes:8]
Recently Adopted Accounting Pronouncements

[0001571996-20-000045:notes:9]
Measurement of Credit Losses on Financial Instruments — In June 2016, the FASB issued amended guidance which replaces the current incurred loss impairment methodology for measurement of credit losses on financial instruments with a methodology (the “current expected credit losses model” or “CECL model”) that reflects expected credit losses and requires consideration of a broader range of reasonable and supportable information to inform credit loss estimates.  Under the CECL model, the allowance for losses on financial assets, measured at amortized cost, reflects management’s estimate of credit losses over the remaining expected life of such assets.

[0001571996-20-000045:notes:10]
The Company adopted the standard (the “new CECL standard”) as of February 1, 2020 using the modified retrospective method, with the cumulative-effect adjustment to the opening balance of stockholders’ equity (deficit) as of the adoption date.  The cumulative effect of adopting the new CECL standard resulted in an increase of $111 million and $27 million to the allowance for expected credit losses within financing receivables, net and accounts receivable, net, respectively, on the Condensed Consolidated Statements of Financial Position, and a corresponding decrease of $28 million to other non-current liabilities related to deferred taxes and $110 million to stockholders’ equity (deficit) as of February 1, 2020.  See Note 2, Note 4, and Note 18 of the Notes to the Condensed Consolidated Financial Statements for additional information about the Company’s allowance for financing receivables losses and allowance for expected credit losses of accounts receivable.
Intangibles - Goodwill and Other - Internal-Use Software — In August 2018, the FASB issued guidance on a customer’s accounting for implementation costs incurred in a cloud-computing arrangement when hosted by a vendor.  The guidance provides that, in a hosting arrangement that is a service contract, certain implementation costs should be capitalized and amortized over the term of the arrangement.  The Company adopted the standard (the “new cloud computing standard”) during the three months ended May 1, 2020 using the prospective method.  The impact of the adoption of this standard was immaterial to the Condensed Consolidated Financial Statements.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001571996-20-000045:notes:11]
[same as prior period, unchanged from 0001571996-20-000034:notes:11]

[0001571996-20-000045:notes:12]
[same as prior period, unchanged from 0001571996-20-000034:notes:12]

[0001571996-20-000045:notes:13]
[same as prior period, unchanged from 0001571996-20-000034:notes:13]

[0001571996-20-000045:notes:14]
[same as prior period, unchanged from 0001571996-20-000034:notes:14]

[0001571996-20-000045:notes:15]
[same as prior period, unchanged from 0001571996-20-000034:notes:15]

[0001571996-20-000045:notes:16]
[same as prior period, unchanged from 0001571996-20-000034:notes:16]


## us-gaap:FairValueDisclosuresTextBlock

[0001571996-20-000045:notes:17]
[same as prior period, unchanged from 0001571996-20-000034:notes:17]

[0001571996-20-000045:notes:18]
[same as prior period, unchanged from 0001571996-20-000034:notes:18]

[0001571996-20-000045:notes:19]
|  | July 31, 2020 |  |  |  |  |  |  |  | January 31, 2020 |  |  |  |  |  |  |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | Quoted Prices in Active Markets for Identical Assets |  | Significant Other Observable Inputs |  | Significant Unobservable Inputs |  |  |  | Quoted Prices in Active Markets for Identical Assets |  | Significant Other Observable Inputs |  | Significant Unobservable Inputs |  |  |
|  | (in millions) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 5,965 |  |  | $ | — |  |  | $ | — |  |  | $ | 5,965 |  |  | $ | 4,621 |  |  | $ | — |  |  | $ | — |  |  | $ | 4,621 |  |
| Equity and other securities | 1 |  |  | — |  |  | — |  |  | 1 |  |  | 12 |  |  | — |  |  | — |  |  | 12 |  |
| Derivative instruments | — |  |  | 338 |  |  | — |  |  | 338 |  |  | — |  |  | 81 |  |  | — |  |  | 81 |  |
| Total assets | $ | 5,966 |  |  | $ | 338 |  |  | $ | — |  |  | $ | 6,304 |  |  | $ | 4,633 |  |  | $ | 81 |  |  | $ | — |  |  | $ | 4,714 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative instruments | $ | — |  |  | $ | 319 |  |  | $ | — |  |  | $ | 319 |  |  | $ | — |  |  | $ | 68 |  |  | $ | — |  |  | $ | 68 |  |
| Total liabilities | $ | — |  |  | $ | 319 |  |  | $ | — |  |  | $ | 319 |  |  | $ | — |  |  | $ | 68 |  |  | $ | — |  |  | $ | 68 |  |

[0001571996-20-000045:notes:20]
[same as prior period, unchanged from 0001571996-20-000034:notes:20]

[0001571996-20-000045:notes:21]
Money Market Funds — The Company’s investments in money market funds that are classified as cash equivalents hold underlying investments with a weighted average maturity of 90 days or less and are recognized at fair value.  The valuations of these securities are based on quoted prices in active markets for identical assets, when available, or pricing models whereby all significant inputs are observable or can be derived from or corroborated by observable market data.  The Company reviews security pricing and assesses liquidity on a quarterly basis.  As of July 31, 2020, the Company’s U.S. portfolio had no material exposure to money market funds with a fluctuating net asset value.

[0001571996-20-000045:notes:22]
[same as prior period, unchanged from 0001571996-20-000034:notes:22]

[0001571996-20-000045:notes:23]
[same as prior period, unchanged from 0001571996-20-000034:notes:23]

[0001571996-20-000045:notes:24]
Deferred Compensation Plans — The Company offers deferred compensation plans for eligible employees, which allow participants to defer payment for a portion of their compensation.  Assets were the same as liabilities associated with the plans at approximately $264 million and $241 million as of July 31, 2020 and January 31, 2020, respectively, and are included in other assets and other liabilities on the Condensed Consolidated Statements of Financial Position.  The net impact to the Condensed Consolidated Statements of Income (Loss) is not material since changes in the fair value of the assets substantially offset changes in the fair value of the liabilities.  As such, assets and liabilities associated with these plans have not been included in the recurring fair value table above.

[0001571996-20-000045:notes:25]
[same as prior period, unchanged from 0001571996-20-000034:notes:25]

[0001571996-20-000045:notes:26]
As of July 31, 2020 and January 31, 2020, the Company held private strategic investments of $983 million and $852 million, respectively.  As these investments represent early-stage companies without readily determinable fair values, they are not included in the recurring fair value table above.

[0001571996-20-000045:notes:27]
[same as prior period, unchanged from 0001571996-20-000034:notes:27]

[0001571996-20-000045:notes:28]
[same as prior period, unchanged from 0001571996-20-000034:notes:28]

[0001571996-20-000045:notes:29]
|  | July 31, 2020 |  |  |  | January 31, 2020 |  |  |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |  |  |  |  |  |  |
| Senior Secured Credit Facilities | $ | 8.6 |  |  | $ | 8.6 |  |  | $ | 8.8 |  |  | $ | 9.0 |  |
| First Lien Notes | $ | 21.3 |  |  | $ | 25.1 |  |  | $ | 20.5 |  |  | $ | 23.9 |  |
| Unsecured Notes and Debentures | $ | 1.2 |  |  | $ | 1.5 |  |  | $ | 1.2 |  |  | $ | 1.5 |  |
| Senior Notes | $ | 2.6 |  |  | $ | 2.8 |  |  | $ | 2.6 |  |  | $ | 2.8 |  |
| EMC Notes | $ | 1.0 |  |  | $ | 1.1 |  |  | $ | 1.6 |  |  | $ | 1.6 |  |
| VMware Notes and VMware Term Loan Facility | $ | 6.2 |  |  | $ | 6.8 |  |  | $ | 5.5 |  |  | $ | 5.6 |  |
| Margin Loan Facility | $ | 4.0 |  |  | $ | 3.9 |  |  | $ | 4.0 |  |  | $ | 3.9 |  |

[0001571996-20-000045:notes:30]
[same as prior period, unchanged from 0001571996-20-000034:notes:30]

[0001571996-20-000045:notes:31]
[same as prior period, unchanged from 0001571996-20-000034:notes:31]

[0001571996-20-000045:notes:32]
The following table presents the carrying value of the Company’s investments as of the dates indicated:

[0001571996-20-000045:notes:33]
|  | July 31, 2020 |  |  |  |  |  |  |  | January 31, 2020 |  |  |  |  |  |  |
|  | Cost |  | Unrealized Gain |  | Unrealized (Loss) |  | Carrying Value |  | Cost |  | Unrealized Gain |  | Unrealized (Loss) |  | Carrying Value |
|  | (in millions) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity and other securities | $ | 909 |  |  | $ | 89 |  |  | $ | (14) |  |  | $ | 984 |  |  | $ | 783 |  |  | $ | 116 |  |  | $ | (35) |  |  | $ | 864 |  |
| Fixed income debt securities | $ | 85 |  |  | $ | 4 |  |  | $ | — |  |  | $ | 89 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |

[0001571996-20-000045:notes:34]
Equity and other securities — The Company has strategic investments in publicly-traded and privately-held companies.  For the six months ended July 31, 2020, the equity and other securities without readily determinable fair values of $983 million increased by $89 million, due to upward adjustments for observable price changes, offset by $11 million of downward adjustments primarily attributable to observable price changes.  The remainder of equity and other securities consists of publicly-traded investments that are measured at fair value on a recurring basis.

[0001571996-20-000045:notes:35]
Fixed income debt securities — The Company has fixed income debt securities carried at amortized cost.  The debt securities are held as collateral for borrowings.  The Company intends to hold the investments to maturity.  Unrealized gains relate to foreign currency impacts.


## dell:CreditLossFinancialInstrumentLeasesDebtVariableInterestEntitiesAndCustomerReceivablesSalesTextBlock

[0001571996-20-000045:notes:36]
NOTE 4 — FINANCIAL SERVICES

[0001571996-20-000045:notes:37]
The Company offers or arranges various financing options, services, and alternative payment structures for its customers in North America, Europe, Australia, and New Zealand through Dell Financial Services and its affiliates (“DFS”).  The Company also arranges financing for some of its customers in various countries where DFS does not currently operate as a captive enterprise.  The key activities of DFS include originating, collecting, and servicing customer financing arrangements primarily related to the purchase or use of Dell Technologies products and services.  In some cases, DFS also offers financing on the purchase of third-party technology products that complement the Dell Technologies portfolio of products and services.  New financing originations were $2.6 billion and $2.0 billion for the three months ended July 31, 2020 and August 2, 2019, respectively, and $4.4 billion and $3.7 billion for the six months ended July 31, 2020 and August 2, 2019, respectively.

[0001571996-20-000045:notes:38]
The Company’s loan and lease arrangements with customers are aggregated into the following categories:

[0001571996-20-000045:notes:39]
Revolving loans — Revolving loans offered under private label credit financing programs provide qualified customers with a revolving credit line for the purchase of products and services offered by Dell Technologies.  These private label credit financing programs are referred to as Dell Preferred Account (“DPA”) and Dell Business Credit (“DBC”).  The DPA product is primarily offered to individual consumer customers, and the DBC product is primarily offered to small and medium-sized commercial customers.  Revolving loans in the United States bear interest at a variable annual percentage rate that is tied to the prime rate.  Based on historical payment patterns, revolving loan transactions are typically repaid within twelve months on average.  Due to the short-term nature of the revolving loan portfolio, the carrying value of the portfolio approximates fair value.

[0001571996-20-000045:notes:40]
Fixed-term leases and loans — The Company enters into financing arrangements with customers who seek lease financing for equipment.  Pursuant to the current lease accounting standard effective February 2, 2019, new DFS leases are classified as sales-type leases, direct financing leases, or operating leases.  When the terms of the DFS lease transfer control of the underlying asset to the lessee, the contract is typically classified as a sales-type lease.  Direct financing leases are immaterial.  All other new DFS leases are classified as operating leases.  Leases that commenced prior to the effective date of the current lease accounting standard continue to be accounted for under previous lease accounting guidance.  Leases with business customers have fixed terms of generally two to four years.

[0001571996-20-000045:notes:41]
The Company also offers fixed-term loans to qualified small businesses, large commercial accounts, governmental organizations, educational entities, and certain individual consumer customers.  These loans are repaid in equal payments including interest and have defined terms of generally three to five years.  The fair value of the fixed-term loan portfolio is determined using market observable inputs.  The carrying value of these loans approximates fair value.

[0001571996-20-000045:notes:42]
Financing Receivables

[0001571996-20-000045:notes:43]
The following table presents the components of the Company’s financing receivables segregated by portfolio segment as of the dates indicated:

[0001571996-20-000045:notes:44]
|  | July 31, 2020 |  |  |  |  |  | January 31, 2020 |  |  |  |  |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |  |  |  |  |  |  |  |  |  |  |
| Financing receivables, net: |  |  |  |  |  |  |  |  |  |  |  |
| Customer receivables, gross (a) | $ | 778 |  |  | $ | 9,255 |  |  | $ | 10,033 |  |  | $ | 824 |  |  | $ | 8,486 |  |  | $ | 9,310 |  |
| Allowances for losses | (143) |  |  | (180) |  |  | (323) |  |  | (70) |  |  | (79) |  |  | (149) |  |
| Customer receivables, net | 635 |  |  | 9,075 |  |  | 9,710 |  |  | 754 |  |  | 8,407 |  |  | 9,161 |  |
| Residual interest | — |  |  | 523 |  |  | 523 |  |  | — |  |  | 582 |  |  | 582 |  |
| Financing receivables, net | $ | 635 |  |  | $ | 9,598 |  |  | $ | 10,233 |  |  | $ | 754 |  |  | $ | 8,989 |  |  | $ | 9,743 |  |
| Short-term | $ | 635 |  |  | $ | 4,220 |  |  | $ | 4,855 |  |  | $ | 754 |  |  | $ | 4,141 |  |  | $ | 4,895 |  |
| Long-term | $ | — |  |  | $ | 5,378 |  |  | $ | 5,378 |  |  | $ | — |  |  | $ | 4,848 |  |  | $ | 4,848 |  |

[0001571996-20-000045:notes:45]
____________________

[0001571996-20-000045:notes:46]
(a) Customer receivables, gross includes amounts due from customers under revolving loans, fixed-term loans, fixed-term sales-type or direct financing leases, and accrued interest.

[0001571996-20-000045:notes:47]
The allowance for losses as of July 31, 2020 includes the adoption of the new CECL standard, which was adopted as of February 1, 2020 using the modified retrospective method.  Prior period amounts have not been recast.  The provision recognized on the Condensed Consolidated Statements of Income (Loss) for the three and six months ended July 31, 2020 is based on an assessment of the impact of current and expected future economic conditions, inclusive of the effect of the COVID-19 pandemic on credit losses.  The duration and severity of COVID-19 and continued market volatility is highly uncertain and, as such, the impact on expected losses is subject to significant judgment and may cause variability in the Company’s allowance for credit losses in future periods.  See Note 1 and Note 2 of the Notes to the Condensed Consolidated Financial Statements for additional information about the new CECL standard.

[0001571996-20-000045:notes:48]
The following table presents the changes in allowance for financing receivable losses for the periods indicated:

[0001571996-20-000045:notes:49]
|  | Three Months Ended |  |  |  |  |  |  |  |  |  |  |
|  | July 31, 2020 |  |  |  |  |  | August 2, 2019 |  |  |  |  |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |  |  |  |  |  |  |  |  |  |  |
| Allowance for financing receivable losses: |  |  |  |  |  |  |  |  |  |  |  |
| Balances at beginning of period | $ | 144 |  |  | $ | 177 |  |  | $ | 321 |  |  | $ | 70 |  |  | $ | 73 |  |  | $ | 143 |  |
| Charge-offs, net of recoveries | (18) |  |  | (7) |  |  | (25) |  |  | (15) |  |  | (9) |  |  | (24) |  |
| Provision charged to income statement | 17 |  |  | 10 |  |  | 27 |  |  | 12 |  |  | 7 |  |  | 19 |  |
| Balances at end of period | $ | 143 |  |  | $ | 180 |  |  | $ | 323 |  |  | $ | 67 |  |  | $ | 71 |  |  | $ | 138 |  |

[0001571996-20-000045:notes:50]
|  | Six Months Ended |  |  |  |  |  |  |  |  |  |  |
|  | July 31, 2020 |  |  |  |  |  | August 2, 2019 |  |  |  |  |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |  |  |  |  |  |  |  |  |  |  |
| Allowance for financing receivable losses: |  |  |  |  |  |  |  |  |  |  |  |
| Balances at beginning of period | $ | 70 |  |  | $ | 79 |  |  | $ | 149 |  |  | $ | 75 |  |  | $ | 61 |  |  | $ | 136 |  |
| Adjustment for adoption of accounting standard (Note 1) | 40 |  |  | 71 |  |  | 111 |  |  | — |  |  | — |  |  | — |  |
| Charge-offs, net of recoveries | (38) |  |  | (16) |  |  | (54) |  |  | (35) |  |  | (12) |  |  | (47) |  |
| Provision charged to income statement | 71 |  |  | 46 |  |  | 117 |  |  | 27 |  |  | 22 |  |  | 49 |  |
| Balances at end of period | $ | 143 |  |  | $ | 180 |  |  | $ | 323 |  |  | $ | 67 |  |  | $ | 71 |  |  | $ | 138 |  |

[0001571996-20-000045:notes:51]
Aging

[0001571996-20-000045:notes:52]
The following table presents the aging of the Company’s customer financing receivables, gross, including accrued interest, segregated by class, as of the dates indicated:

[0001571996-20-000045:notes:53]
|  | July 31, 2020 |  |  |  |  |  |  |  | January 31, 2020 |  |  |  |  |  |  |
|  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |
|  | (in millions) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revolving — DPA | $ | 556 |  |  | $ | 29 |  |  | $ | 13 |  |  | $ | 598 |  |  | $ | 550 |  |  | $ | 51 |  |  | $ | 20 |  |  | $ | 621 |  |
| Revolving — DBC | 165 |  |  | 11 |  |  | 4 |  |  | 180 |  |  | 184 |  |  | 15 |  |  | 4 |  |  | 203 |  |
| Fixed-term — Consumer and Commercial | 8,803 |  |  | 381 |  |  | 71 |  |  | 9,255 |  |  | 8,005 |  |  | 373 |  |  | 108 |  |  | 8,486 |  |
| Total customer receivables, gross | $ | 9,524 |  |  | $ | 421 |  |  | $ | 88 |  |  | $ | 10,033 |  |  | $ | 8,739 |  |  | $ | 439 |  |  | $ | 132 |  |  | $ | 9,310 |  |

[0001571996-20-000045:notes:54]
Aging is likely to fluctuate as a result of the variability in volume of large transactions entered into over the period, and the administrative processes that accompany those larger transactions.  Aging is also impacted by the timing of the Dell Technologies fiscal period end date, relative to calendar month-end customer payment due dates.  As a result of these factors, fluctuations in aging from period to period do not necessarily indicate a material change in the collectibility of the portfolio.

[0001571996-20-000045:notes:55]
Fixed-term consumer and commercial customer receivables are placed on non-accrual status if principal or interest is past due and considered delinquent, or if there is concern about collectibility of a specific customer receivable.  These receivables identified as doubtful for collectibility may be classified as current for aging purposes.  Aged revolving portfolio customer receivables identified as delinquent are charged off.

[0001571996-20-000045:notes:56]
Credit Quality

[0001571996-20-000045:notes:57]
The following table presents customer receivables, gross, including accrued interest, by credit quality indicator segregated by class and year of origination, as of the date indicated:

[0001571996-20-000045:notes:58]
|  | July 31, 2020 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | Fixed-term — Consumer and Commercial |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | Fiscal Year of Origination |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | 2021 |  | 2020 |  | 2019 |  | 2018 |  | 2017 |  | Years Prior |  | Revolving — DPA (a) |  | Revolving — DBC (a) |  | Total |
|  | (in millions) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Higher | $ | 2,019 |  |  | $ | 2,265 |  |  | $ | 992 |  |  | $ | 273 |  |  | $ | 43 |  |  | $ | 1 |  |  | $ | 148 |  |  | $ | 51 |  |  | $ | 5,792 |  |
| Mid | 633 |  |  | 824 |  |  | 417 |  |  | 127 |  |  | 20 |  |  | 1 |  |  | 176 |  |  | 52 |  |  | 2,250 |  |
| Lower | 548 |  |  | 609 |  |  | 379 |  |  | 82 |  |  | 20 |  |  | 2 |  |  | 274 |  |  | 77 |  |  | 1,991 |  |
| Total | $ | 3,200 |  |  | $ | 3,698 |  |  | $ | 1,788 |  |  | $ | 482 |  |  | $ | 83 |  |  | $ | 4 |  |  | $ | 598 |  |  | $ | 180 |  |  | $ | 10,033 |  |

[0001571996-20-000045:notes:59]
(a) The revolving portfolio is exempt from the requirement to disclose the amortized cost basis by year of origination since determining the appropriate origination year can be complex due to the nature of the revolving portfolio.

[0001571996-20-000045:notes:60]
The following table presents customer receivables, gross, including accrued interest, by credit quality indicator segregated by class, as of the date indicated, and was not recast to reflect the impact of adoption of the new CECL standard:

[0001571996-20-000045:notes:61]
|  | January 31, 2020 |  |  |  |  |  |  |
|  | Fixed-term — Consumer and Commercial |  | Revolving — DPA |  | Revolving — DBC |  | Total |
|  | (in millions) |  |  |  |  |  |  |
| Higher | $ | 5,042 |  |  | $ | 137 |  |  | $ | 55 |  |  | $ | 5,234 |  |
| Mid | 2,036 |  |  | 175 |  |  | 63 |  |  | 2,274 |  |
| Lower | 1,408 |  |  | 309 |  |  | 85 |  |  | 1,802 |  |
| Total | $ | 8,486 |  |  | $ | 621 |  |  | $ | 203 |  |  | $ | 9,310 |  |

[0001571996-20-000045:notes:62]
The categories shown in the tables above segregate customer receivables based on the relative degrees of credit risk.  The credit quality indicators for DPA revolving accounts are measured primarily as of each quarter-end date, while all other indicators are generally updated on a periodic basis.

[0001571996-20-000045:notes:63]
For DPA revolving receivables shown in the table above, the Company makes credit decisions based on proprietary scorecards, which include the customer’s credit history, payment history, credit usage, and other credit agency-related elements.  The higher quality category includes prime accounts generally of a higher credit quality that are comparable to U.S. customer FICO scores of 720 or above.  The mid-category represents the mid-tier accounts that are comparable to U.S. customer FICO scores from 660 to 719.  The lower category is generally sub-prime and represents lower credit quality accounts that are comparable to U.S. customer FICO scores below 660.  For the DBC revolving receivables and fixed-term commercial receivables shown in the table above, an internal grading system is utilized that assigns a credit level score based on a number of considerations, including liquidity, operating performance, and industry outlook.  The grading criteria and classifications for the fixed-term products differ from those for the revolving products as loss experience varies between these product and customer groups.  The credit quality categories cannot be compared between the different classes as loss experience varies substantially between the classes.

[0001571996-20-000045:notes:64]
Leases

[0001571996-20-000045:notes:65]
Interest income on sales-type lease receivables was $66 million for both the three months ended July 31, 2020 and August 2, 2019, and $131 million and $130 million for the six months ended July 31, 2020 and August 2, 2019, respectively.

[0001571996-20-000045:notes:66]
The following table presents the net revenue, cost of net revenue, and gross margin recognized at the commencement date of sales-type leases for the periods indicated:

[0001571996-20-000045:notes:67]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | July 31, 2020 |  | August 2, 2019 |  | July 31, 2020 |  | August 2, 2019 |
|  | (in millions) |  |  |  |  |  |  |
| Net revenue — products | $ | 249 |  |  | $ | 223 |  |  | $ | 464 |  |  | $ | 353 |  |
| Cost of net revenue — products | 174 |  |  | 179 |  |  | 333 |  |  | 260 |  |
| Gross margin — products | $ | 75 |  |  | $ | 44 |  |  | $ | 131 |  |  | $ | 93 |  |

[0001571996-20-000045:notes:68]
The following table presents the future maturity of the Company’s fixed-term customer leases and associated financing payments, and reconciles the undiscounted cash flows to the customer receivables, gross recognized on the Condensed Consolidated Statements of Financial Position as of the date indicated:

[0001571996-20-000045:notes:69]
|  | July 31, 2020 |
| Fiscal Years | (in millions) |
| Fiscal 2021 (remaining six months) | $ | 1,475 |  |
| Fiscal 2022 | 2,159 |  |
| Fiscal 2023 | 1,347 |  |
| Fiscal 2024 | 609 |  |
| Fiscal 2025 and beyond | 250 |  |
| Total undiscounted cash flows | 5,840 |  |
| Fixed-term loans | 4,075 |  |
| Revolving loans | 778 |  |
| Less: unearned income | (660) |  |
| Total customer receivables, gross | $ | 10,033 |  |

[0001571996-20-000045:notes:70]
Operating Leases

[0001571996-20-000045:notes:71]
The following table presents the components of the Company’s operating lease portfolio included in Property, plant, and equipment, net as of the dates indicated:

[0001571996-20-000045:notes:72]
|  | July 31, 2020 |  | January 31, 2020 |
|  | (in millions) |  |  |
| Equipment under operating lease, gross | $ | 1,478 |  |  | $ | 956 |  |
| Less: accumulated depreciation | (258) |  |  | (116) |  |
| Equipment under operating lease, net | $ | 1,220 |  |  | $ | 840 |  |

[0001571996-20-000045:notes:73]
Operating lease income relating to lease payments was $103 million and $27 million for the three months ended July 31, 2020 and August 2, 2019, respectively, and $190 million and $31 million for the six months ended July 31, 2020 and August 2, 2019, respectively.  Depreciation expense was $74 million and $21 million for the three months ended July 31, 2020 and August 2, 2019, respectively, and $136 million and $24 million for the six months ended July 31, 2020 and August 2, 2019, respectively.

[0001571996-20-000045:notes:74]
The following table presents the future payments to be received by the Company as lessor in operating lease contracts as of the date indicated:

[0001571996-20-000045:notes:75]
|  | July 31, 2020 |
| Fiscal Years | (in millions) |
| Fiscal 2021 (remaining six months) | $ | 258 |  |
| Fiscal 2022 | 461 |  |
| Fiscal 2023 | 351 |  |
| Fiscal 2024 | 89 |  |
| Fiscal 2025 and beyond | 9 |  |
| Total | $ | 1,168 |  |

[0001571996-20-000045:notes:76]
DFS Debt

[0001571996-20-000045:notes:77]
The Company maintains programs that facilitate the funding of leases, loans, and other alternative payment structures in the capital markets.  The majority of DFS debt is non-recourse to Dell Technologies and represents borrowings under securitization programs and structured financing programs, for which the Company’s risk of loss is limited to transferred loan and lease payments and associated equipment.  The following table presents DFS debt as of the dates indicated.  The table excludes the allocated portion of the Company’s other borrowings, which represents the additional amount considered to fund the DFS business.

[0001571996-20-000045:notes:78]
|  | July 31, 2020 |  | January 31, 2020 |
|  | (in millions) |  |  |
| DFS U.S. debt: |  |  |  |
| Asset-based financing and securitization facilities | $ | 2,936 |  |  | $ | 2,606 |  |
| Fixed-term securitization offerings | 2,788 |  |  | 2,593 |  |
| Other | 187 |  |  | 141 |  |
| Total DFS U.S. debt | 5,911 |  |  | 5,340 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 835 |  |  | 743 |  |
| Other borrowings | 719 |  |  | 931 |  |
| Note payable | 187 |  |  | 200 |  |
| Dell Bank Senior Unsecured Eurobonds | 1,185 |  |  | 551 |  |
| Total DFS international debt | 2,926 |  |  | 2,425 |  |
| Total DFS debt | $ | 8,837 |  |  | $ | 7,765 |  |
| Total short-term DFS debt | $ | 4,188 |  |  | $ | 4,152 |  |
| Total long-term DFS debt | $ | 4,649 |  |  | $ | 3,613 |  |

[0001571996-20-000045:notes:79]
DFS U.S. Debt

[0001571996-20-000045:notes:80]
Asset-Based Financing and Securitization Facilities — The Company maintains separate asset-based financing facilities and a securitization facility in the United States, which are revolving facilities for fixed-term leases and loans and for revolving loans, respectively.  This debt is collateralized solely by the U.S. loan and lease payments and associated equipment in the facilities.  The debt has a variable interest rate and the duration of the debt is based on the terms of the underlying loan and lease payment streams.  As of July 31, 2020, the total debt capacity related to the U.S. asset-based financing and securitization facilities was $4.1 billion.  The Company enters into interest swap agreements to effectively convert a portion of this debt from a floating rate to a fixed rate.  See Note 7 of the Notes to the Condensed Consolidated Financial Statements for additional information about interest rate swaps.

[0001571996-20-000045:notes:81]
The Company’s U.S. securitization facility for revolving loans is effective through June 25, 2022.  The Company’s two U.S. asset-based financing facilities for fixed-term leases and loans are effective through August 22, 2021 and July 26, 2022, respectively.

[0001571996-20-000045:notes:82]
The asset-based financing and securitization facilities contain standard structural features related to the performance of the funded receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the facility, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of July 31, 2020, these criteria were met.

[0001571996-20-000045:notes:83]
Fixed-Term Securitization Offerings — The Company periodically issues asset-backed debt securities under fixed-term securitization programs to private investors.  The asset-backed debt securities are collateralized solely by the U.S. fixed-term leases and loans in the offerings, which are held by Special Purpose Entities (“SPEs”), as discussed below.  The interest rate on these securities is fixed and ranges from 1.91% to 5.92% per annum, and the duration of these securities is based on the terms of the underlying loan and lease payment streams.

[0001571996-20-000045:notes:84]
DFS International Debt

[0001571996-20-000045:notes:85]
Securitization Facility — The Company maintains a securitization facility in Europe for fixed-term leases and loans.  This facility is effective through December 21, 2020 and has a total debt capacity of $948 million as of July 31, 2020.

[0001571996-20-000045:notes:86]
The securitization facility contains standard structural features related to the performance of the securitized receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the program, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of July 31, 2020, these criteria were met.

[0001571996-20-000045:notes:87]
Other Borrowings — In connection with the Company’s international financing operations, the Company has entered into revolving structured financing debt programs related to its fixed-term lease and loan products sold in Canada, Europe, Australia, and New Zealand.  The Canadian facility, which is collateralized solely by Canadian loan and lease payments and associated equipment, had a total debt capacity of $279 million as of July 31, 2020, and is effective through January 16, 2023.  The European facility, which is collateralized solely by European loan and lease payments and associated equipment, had a total debt capacity of $711 million as of July 31, 2020, and is effective through June 14, 2022.  The Australia and New Zealand facility, which is collateralized solely by Australia and New Zealand loan and lease payments and associated equipment, had a total debt capacity of $252 million as of July 31, 2020, and is effective through December 20, 2021.

[0001571996-20-000045:notes:88]
Note Payable — On November 27, 2017, the Company entered into an unsecured credit agreement to fund receivables in Mexico.  As of July 31, 2020, the aggregate principal amount of the note payable is $187 million.  The note bears interest at either the applicable London Interbank Offered Rate (“LIBOR”) plus 2.25%, for the borrowings denominated in U.S. dollars, or the Mexican Interbank Equilibrium Interest Rate (“TIIE”) plus 2.00%, for the borrowings denominated in Mexican pesos.  The note will mature on December 1, 2020.

[0001571996-20-000045:notes:89]
Dell Bank Senior Unsecured Eurobonds — On October 17, 2019, Dell Bank International D.A.C. issued 500 million Euro of 0.625% senior unsecured three year eurobonds due October 2022.  On June 24, 2020, Dell Bank International D.A.C. issued an additional 500 million Euro of 1.625% senior unsecured four year eurobonds due June 2024.  The issuances of the senior unsecured eurobonds support the expansion of the financing operations in Europe.

[0001571996-20-000045:notes:90]
Variable Interest Entities

[0001571996-20-000045:notes:91]
In connection with the asset-based financing facilities, securitization facilities, and fixed-term securitization offerings discussed above, the Company transfers certain U.S. and European loan and lease payments and associated equipment to SPEs that meet the definition of a Variable Interest Entity (“VIE”) and are consolidated, along with the associated debt detailed above, into the Consolidated Financial Statements, as the Company is the primary beneficiary of those VIEs.  The SPEs are bankruptcy-remote legal entities with separate assets and liabilities.  The purpose of the SPEs is to facilitate the funding of customer loan and lease payments and associated equipment in the capital markets.

[0001571996-20-000045:notes:92]
The following table presents financing receivables and equipment under operating leases, net held by the consolidated VIEs as of the dates indicated:

[0001571996-20-000045:notes:93]
|  | July 31, 2020 |  | January 31, 2020 |
|  | (in millions) |  |  |
| Assets held by consolidated VIEs, net: |  |  |  |
| Short-term, net | $ | 3,315 |  |  | $ | 3,316 |  |
| Long-term, net | 3,867 |  |  | 3,348 |  |
| Assets held by consolidated VIEs, net | $ | 7,182 |  |  | $ | 6,664 |  |

[0001571996-20-000045:notes:94]
Loan and lease payments and associated equipment transferred via securitization through SPEs were $1.2 billion and $1.3 billion for the three months ended July 31, 2020 and August 2, 2019, respectively, and $3.0 billion and $2.8 billion for the six months ended July 31, 2020 and August 2, 2019, respectively.

[0001571996-20-000045:notes:95]
Some of the SPEs have entered into financing arrangements with multi-seller conduits that, in turn, issue asset-backed debt securities in the capital markets.  The DFS debt outstanding, which is collateralized by the loan and lease payments and associated equipment held by the consolidated VIEs, was $6.6 billion and $5.9 billion as of July 31, 2020 and January 31, 2020, respectively.  The Company’s risk of loss related to securitized receivables is limited to the amount by which the Company’s right to receive collections for assets securitized exceeds the amount required to pay interest, principal, and fees and expenses related to the asset-backed securities.  The Company provides credit enhancement to the securitizations in the form of over-collateralization.

[0001571996-20-000045:notes:96]
Customer Receivables Sales

[0001571996-20-000045:notes:97]
To manage certain concentrations of customer credit exposure, the Company may sell selected fixed-term customer receivables to unrelated third parties on a periodic basis, without recourse.  The amount of customer receivables sold for this purpose was $228 million and $246 million for the six months ended July 31, 2020 and August 2, 2019, respectively.  The Company’s continuing involvement in the above mentioned customer receivables is primarily limited to servicing arrangements.


## us-gaap:ScheduleOfDebtTableTextBlock

[0001571996-20-000045:notes:98]
The following table presents DFS debt as of the dates indicated.  The table excludes the allocated portion of the Company’s other borrowings, which represents the additional amount considered to fund the DFS business.

[0001571996-20-000045:notes:99]
The following table presents the Company’s outstanding debt as of the dates indicated:

[0001571996-20-000045:notes:100]
|  | July 31, 2020 |  | January 31, 2020 |
|  | (in millions) |  |  |
| Secured Debt |  |  |  |
| Senior Secured Credit Facilities: |  |  |  |
| 2.75% Term Loan B-1 Facility due September 2025 | $ | 4,691 |  |  | $ | 4,738 |  |
| 1.93% Term Loan A-4 Facility due December 2023 | 679 |  |  | 679 |  |
| 1.93% Term Loan A-6 Facility due March 2024 | 3,316 |  |  | 3,497 |  |
| First Lien Notes: |  |  |  |
| 4.42% due June 2021 | 3,065 |  |  | 4,500 |  |
| 5.45% due June 2023 | 3,750 |  |  | 3,750 |  |
| 4.00% due July 2024 | 1,000 |  |  | 1,000 |  |
| 5.85% due July 2025 | 1,000 |  |  | — |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 4.90% due October 2026 | 1,750 |  |  | 1,750 |  |
| 6.10% due July 2027 | 500 |  |  | — |  |
| 5.30% due October 2029 | 1,750 |  |  | 1,750 |  |
| 6.20% due July 2030 | 750 |  |  | — |  |
| 8.10% due July 2036 | 1,500 |  |  | 1,500 |  |
| 8.35% due July 2046 | 2,000 |  |  | 2,000 |  |
| Unsecured Debt |  |  |  |
| Unsecured Notes and Debentures: |  |  |  |
| 4.625% due April 2021 | 400 |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| Senior Notes: |  |  |  |
| 5.875% due June 2021 | 1,075 |  |  | 1,075 |  |
| 7.125% due June 2024 | 1,625 |  |  | 1,625 |  |
| EMC Notes: |  |  |  |
| 2.650% due June 2020 | — |  |  | 600 |  |
| 3.375% due June 2023 | 1,000 |  |  | 1,000 |  |
| Debt of Public Subsidiary |  |  |  |
| VMware Notes: |  |  |  |
| 2.30% due August 2020 | — |  |  | 1,250 |  |
| 2.95% due August 2022 | 1,500 |  |  | 1,500 |  |
| 4.50% due May 2025 | 750 |  |  | — |  |
| 4.65% due May 2027 | 500 |  |  | — |  |
| 3.90% due August 2027 | 1,250 |  |  | 1,250 |  |
| 4.70% due May 2030 | 750 |  |  | — |  |
| VMware Term Loan Facility | 1,500 |  |  | 1,500 |  |
| DFS Debt (Note 4) | 8,837 |  |  | 7,765 |  |
| Other |  |  |  |
| 2.51% Margin Loan Facility due April 2022 | 4,000 |  |  | 4,000 |  |
| Other | 147 |  |  | 84 |  |
| Total debt, principal amount | $ | 54,537 |  |  | $ | 52,665 |  |

[0001571996-20-000045:notes:101]
|  | July 31, 2020 |  | January 31, 2020 |
|  | (in millions) |  |  |
| Total debt, principal amount | $ | 54,537 |  |  | $ | 52,665 |  |
| Unamortized discount, net of unamortized premium | (226) |  |  | (241) |  |
| Debt issuance costs | (358) |  |  | (368) |  |
| Total debt, carrying value | $ | 53,953 |  |  | $ | 52,056 |  |
| Total short-term debt, carrying value | $ | 10,345 |  |  | $ | 7,737 |  |
| Total long-term debt, carrying value | $ | 43,608 |  |  | $ | 44,319 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0001571996-20-000045:notes:102]
[same as prior period, unchanged from 0001571996-20-000034:notes:100]

[0001571996-20-000045:notes:103]
The Company enters into leasing transactions in which the Company is the lessee.  These lease contracts are typically classified as operating leases.  The Company’s lease contracts are generally for office buildings used to conduct its business, and the determination of whether such contracts contain leases generally does not require significant estimates or judgments.  The Company also leases certain global logistics warehouses, employee vehicles, and equipment.  As of July 31, 2020, the remaining terms of the Company’s leases range from less than one month to 26 years.

[0001571996-20-000045:notes:104]
[same as prior period, unchanged from 0001571996-20-000034:notes:102]

[0001571996-20-000045:notes:105]
In adopting the current lease accounting standard effective February 2, 2019, the Company elected to apply a transition method that does not require the retrospective application to periods prior to the effective date.  Financial information associated with the Company’s leases in which the Company is the lessee is contained in this Note.  As of July 31, 2020 and January 31, 2020, there were no material finance leases for which the Company was a lessee.

[0001571996-20-000045:notes:106]
[same as prior period, unchanged from 0001571996-20-000034:notes:104]

[0001571996-20-000045:notes:107]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | July 31, 2020 |  | August 2, 2019 |  | July 31, 2020 |  | August 2, 2019 |
|  | (in millions) |  |  |  |  |  |  |
| Operating lease costs | $ | 124 |  |  | $ | 126 |  |  | $ | 255 |  |  | $ | 243 |  |
| Variable costs | 32 |  |  | 41 |  |  | 76 |  |  | 79 |  |
| Total lease costs | $ | 156 |  |  | $ | 167 |  |  | $ | 331 |  |  | $ | 322 |  |

[0001571996-20-000045:notes:108]
During both the six months ended July 31, 2020 and August 2, 2019, sublease income, finance lease costs, and short-term lease costs were immaterial.

[0001571996-20-000045:notes:109]
[same as prior period, unchanged from 0001571996-20-000034:notes:107]

[0001571996-20-000045:notes:110]
|  | Classification | July 31, 2020 |  | January 31, 2020 |  |  |
|  |  | (in millions, except for term and discount rate) |  |  |  |  |
| Operating lease right of use (“ROU”) assets | Other non-current assets | $ | 1,787 |  |  | $ | 1,780 |  |  |  |
| Current operating lease liabilities | Accrued and other current liabilities | $ | 435 |  |  | $ | 432 |  |  |  |
| Non-current operating lease liabilities | Other non-current liabilities | 1,383 |  |  | 1,360 |  |  |  |
| Total operating lease liabilities |  | $ | 1,818 |  |  | $ | 1,792 |  |  |  |
| Weighted-average remaining lease term (in years) |  | 8.47 |  | 8.57 |  |  |
| Weighted-average discount rate |  | 3.75 | % |  | 3.81 | % |  |  |

[0001571996-20-000045:notes:111]
[same as prior period, unchanged from 0001571996-20-000034:notes:109]

[0001571996-20-000045:notes:112]
|  | Six Months Ended |  |  |
|  | July 31, 2020 |  | August 2, 2019 |
|  | (in millions) |  |  |
| Cash paid for amounts included in the measurement of lease liabilities — operating cash outflows from operating leases | $ | 255 |  |  | $ | 241 |  |
| ROU assets obtained in exchange for new operating lease liabilities | $ | 255 |  |  | $ | 254 |  |

[0001571996-20-000045:notes:113]
[same as prior period, unchanged from 0001571996-20-000034:notes:111]

[0001571996-20-000045:notes:114]
|  | July 31, 2020 |  |  |
| Fiscal Years | (in millions) |  |  |
| Fiscal 2021 (remaining six months) | $ | 236 |  |  |  |
| Fiscal 2022 | 440 |  |  |  |
| Fiscal 2023 | 346 |  |  |  |
| Fiscal 2024 | 239 |  |  |  |
| Fiscal 2025 | 166 |  |  |  |
| Thereafter | 730 |  |  |  |
| Total lease payments | 2,157 |  |  |  |
| Less: Imputed interest | (339) |  |  |  |
| Total | $ | 1,818 |  |  |  |
| Current operating lease liabilities | $ | 435 |  |  |  |
| Non-current operating lease liabilities | $ | 1,383 |  |  |  |

[0001571996-20-000045:notes:115]
[same as prior period, unchanged from 0001571996-20-000034:notes:113]

[0001571996-20-000045:notes:116]
As of July 31, 2020, the Company has additional operating leases that have not yet commenced of $678 million.  These operating leases will commence during Fiscal 2021 with lease terms of one year to 16 years.


## us-gaap:DebtDisclosureTextBlock

[0001571996-20-000045:notes:117]
NOTE 6 — DEBT

[0001571996-20-000045:notes:118]
During the six months ended July 31, 2020, the net increase in the Company’s debt balance was primarily due to new issuances of $2.25 billion of First Lien Notes on April 9, 2020 and $2.0 billion of VMware Notes on April 7, 2020, both described below, and the incurrence of an additional $1.1 billion, net, in DFS debt to support the expansion of its financing receivables portfolio.  These increases were partially offset by repayment of $1.2 billion and open market repurchases of $235 million of 4.42% First Lien Notes due June 2021, repayment of $600 million principal amount of 2.650% EMC Notes due June 2020 upon maturity, approximately $229 million of principal amortization under the Company’s term loan facilities, and repayment of $1.25 billion principal amount of 2.30% VMware Notes due August 2020.

[0001571996-20-000045:notes:119]
Secured Debt

[0001571996-20-000045:notes:120]
Senior Secured Credit Facilities — The Company has entered into a credit agreement that provides for senior secured credit facilities (the “Senior Secured Credit Facilities”) comprising (a) term loan facilities and (b) a senior secured Revolving Credit Facility, which provides for a borrowing capacity of up to $4.5 billion for general corporate purposes, including capacity for up to $0.5 billion of letters of credit and for borrowings of up to $0.4 billion under swing-line loans.

[0001571996-20-000045:notes:121]
As of July 31, 2020, available borrowings under the Revolving Credit Facility totaled $4.5 billion.  The Senior Secured Credit Facilities provide that the borrowers have the right at any time, subject to customary conditions, to request incremental term loans or incremental revolving commitments.

[0001571996-20-000045:notes:122]
Borrowings under the Senior Secured Credit Facilities bear interest at a rate per annum equal to an applicable margin, plus, at the borrowers’ option, either (a) a base rate, or (b) the London Interbank Offered Rate (“LIBOR”).  The Term Loan B-1 Facility bears interest at LIBOR plus an applicable margin of 2.00% or a base rate plus an applicable margin of 1.00%.  The Term Loan A-4 Facility and the Term Loan A-6 Facility bear interest at LIBOR plus an applicable margin ranging from 1.25% to 2.00% or a base rate plus an applicable margin ranging from 0.25% to 1.00%.  Interest is payable, in the case of loans bearing interest based on LIBOR, at the end of each interest period (but at least every three months), in arrears and, in the case of loans bearing interest based on the base rate, quarterly in arrears.

[0001571996-20-000045:notes:123]
The Term Loan B-1 Facility amortizes in equal quarterly installments in aggregate annual amounts equal to 1% of the original principal amount.  The Term Loan A-4 Facility amortizes in equal quarterly installments in aggregate annual amounts equal to 5% of the original principal amount in each of the first four years after the facility closing date of December 20, 2018, and 80% of the original principal amount in the fifth year after December 20, 2018.  The Term Loan A-6 Facility amortizes in equal quarterly installments in aggregate annual amounts equal to 5% of the original principal amount in each of the first four years after the facility closing date of March 13, 2019, and 80% of the original principal amount in the fifth year after March 13, 2019.  The Revolving Credit Facility has no amortization.

[0001571996-20-000045:notes:124]
The borrowers may voluntarily repay outstanding loans under the term loan facilities and the Revolving Credit Facility at any time without premium or penalty, other than customary “breakage” costs.

[0001571996-20-000045:notes:125]
All obligations of the borrowers under the Senior Secured Credit Facilities and certain swap agreements, cash management arrangements, and certain letters of credit provided by any lender or agent party to the Senior Secured Credit Facilities or any of its affiliates and certain other persons are secured by (a) a first-priority security interest in certain tangible and intangible assets of the borrowers and the guarantors and (b) a first-priority pledge of 100% of the capital stock of the borrowers, Dell Inc., a wholly-owned subsidiary of the Company (“Dell”), and each wholly-owned material restricted subsidiary of the borrowers and the guarantors, in each case subject to certain thresholds, exceptions, and permitted liens.

[0001571996-20-000045:notes:126]
First Lien Notes — Dell International L.L.C. and EMC Corporation, both of which are wholly-owned subsidiaries of Dell Technologies Inc., completed private offerings of multiple series of senior secured notes (collectively, the “First Lien Notes”) which were issued on June 1, 2016, March 20, 2019, and April 9, 2020 in aggregate principal amounts of $20.0 billion, $4.5 billion, and $2.25 billion, respectively.  Interest on the First Lien Notes is payable semiannually.  The First Lien Notes are secured on a pari passu basis with the Senior Secured Credit Facilities, on a first-priority basis by substantially all of the tangible and intangible assets of the issuers and guarantors that secure obligations under the Senior Secured Credit Facilities, including pledges of all capital stock of the issuers, Dell, and certain wholly-owned material subsidiaries of the issuers and the guarantors, subject to certain exceptions.

[0001571996-20-000045:notes:127]
The Company has agreed to use commercially reasonable efforts to register with the SEC notes having terms substantially identical to the terms of the First Lien Notes as part of an offer to exchange such registered notes for the First Lien Notes.  The Company will be obligated to pay additional interest on the First Lien Notes if it fails to consummate such an exchange offer within five years after the closing date of the EMC merger transaction, in the case of the First Lien Notes issued on June 1, 2016, and within five years after their respective issue dates, in the case of the First Lien Notes issued on March 20, 2019 and April 9, 2020.

[0001571996-20-000045:notes:128]
China Revolving Credit Facility — The Company entered into a new revolving credit facility for China (the “China Revolving Credit Facility”) effective May 25, 2020.  The new terms provide for collateralized and non-collateralized principal amounts not to exceed $1.0 billion Chinese renminbi and $1.8 billion Chinese renminbi, respectively, or equivalent amounts in U.S. dollars.  Outstanding borrowings under the collateralized portion of the China Revolving Credit Facility bear interest at the loan prime rate (“LPR”) less 0.2%, for borrowings denominated in Chinese renminbi, or LIBOR plus 1.0%, for borrowings denominated in U.S. dollars, and outstanding borrowings under the non-collateralized portion bear interest at LPR less 0.2%, for borrowings denominated in Chinese renminbi, or LIBOR plus 1.4%, for borrowings denominated in U.S. dollars.  The new facility expired on August 30, 2020.

[0001571996-20-000045:notes:129]
During the fiscal year ended January 31, 2020, the Company renewed the credit agreement for its legacy China revolving credit facility with a bank lender, which provided an uncommitted line with an aggregate principal amount not to exceed $500 million at an interest rate of LIBOR plus 0.6% per annum.  The facility was terminated upon expiration on February 26, 2020.

[0001571996-20-000045:notes:130]
Unsecured Debt

[0001571996-20-000045:notes:131]
Unsecured Notes and Debentures — The Company has outstanding unsecured notes and debentures (collectively, the “Unsecured Notes and Debentures”) that were issued by Dell prior to the acquisition of Dell by Dell Technologies Inc. in the going-private transaction that closed in October 2013.  Interest on these borrowings is payable semiannually.

[0001571996-20-000045:notes:132]
Senior Notes — The senior unsecured notes (collectively, the “Senior Notes”) were issued on June 22, 2016 in an aggregate principal amount of $3.25 billion.  Interest on these borrowings is payable semiannually.

[0001571996-20-000045:notes:133]
EMC Notes — On September 7, 2016, EMC had outstanding $2.5 billion aggregate principal amount of its 1.875% Notes due June 2018, which the Company fully repaid during the three months ended August 3, 2018, $2.0 billion aggregate principal amount of its 2.650% Notes due June 2020, and $1.0 billion aggregate principal amount of its 3.375% Notes due June 2023 (collectively, the “EMC Notes”).  Interest on these borrowings is payable semiannually.

[0001571996-20-000045:notes:134]
VMware Notes — VMware, Inc. completed public offerings of unsecured senior notes in the aggregate amounts of $4.0 billion and $2.0 billion on August 21, 2017 and April 7, 2020, respectively (the “VMware Notes”).  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.  Interest on these borrowings is payable semiannually.

[0001571996-20-000045:notes:135]
VMware Revolving Credit Facility — On September 12, 2017, VMware, Inc. entered into an unsecured credit agreement, establishing a revolving credit facility (the “VMware Revolving Credit Facility”) with a syndicate of lenders that provides the company with a borrowing capacity of up to $1.0 billion for VMware, Inc. general corporate purposes.  Commitments under the VMware Revolving Credit Facility are available for a period of five years, which may be extended, subject to the satisfaction of certain conditions, by up to two one year periods.  The credit agreement contains certain representations, warranties, and covenants.  Commitment fees, interest rates, and other terms of borrowing under the VMware Revolving Credit Facility may vary based on VMware, Inc.’s external credit ratings.  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.  As of July 31, 2020, there were no outstanding borrowings under the VMware Revolving Credit Facility.

[0001571996-20-000045:notes:136]
VMware Term Loan Facility — On September 26, 2019, VMware, Inc. entered into a senior unsecured term loan facility (the “VMware Term Loan Facility”) with a syndicate of lenders that provided VMware, Inc. with a borrowing capacity of up to $2.0 billion through February 7, 2020, for VMware, Inc. general corporate purposes.  The VMware Term Loan Facility matures during the third quarter of Fiscal 2021, on the 364th day following the initial funding under the facility.  The VMware Term Loan Facility bears interest at LIBOR plus 0.75% to 1.25%, or an alternative base rate plus 0.00% to 0.25%, depending on VMware Inc.’s external credit ratings.

[0001571996-20-000045:notes:137]
As of July 31, 2020 and January 31, 2020, the outstanding borrowings under the VMware Term Loan Facility were $1.5 billion, with no remaining amount available for additional borrowings.  The VMware Term Loan Facility agreement contains certain representations, warranties, and covenants.  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.

[0001571996-20-000045:notes:138]
See Note 4 and Note 7 of the Notes to the Condensed Consolidated Financial Statements, respectively, for discussion of DFS debt and the interest rate swap agreements that hedge a portion of that debt.

[0001571996-20-000045:notes:139]
Other

[0001571996-20-000045:notes:140]
Margin Loan Facility — On April 12, 2017, the Company entered into the Margin Loan Facility in an aggregate principal amount of $2.0 billion, under which VMW Holdco LLC, a wholly-owned subsidiary of EMC, is the borrower.  In connection with the Class V transaction described in Note 1 of the Notes to the Condensed Consolidated Financial Statements, on December 20, 2018, the Company amended the Margin Loan Facility to increase the aggregate principal amount to $3.35 billion.  In connection with obtaining the Term Loan A-6 Facility during the fiscal year ended January 31, 2020, the Company increased the aggregate principal amount of the Margin Loan Facility to $4.0 billion.

[0001571996-20-000045:notes:141]
During the three months ended May 1, 2020, due to volatility in the U.S. stock market resulting from the outbreak of COVID-19, VMware Holdco LLC proactively pledged additional shares of VMware, Inc. common stock to secure its obligations under the Margin Loan Facility agreement.  This resulted in an aggregate number of shares pledged of approximately 76 million shares of Class B common stock of VMware, Inc. and approximately 24 million shares of Class A common stock of VMware, Inc.

[0001571996-20-000045:notes:142]
Loans under the Margin Loan Facility bear interest at a rate per annum payable, at the borrower’s option, either at (a) a base rate plus 1.25% per annum or (b) a LIBOR-based rate plus 2.25% per annum.  Interest under the Margin Loan Facility is payable quarterly.  The Margin Loan Facility will mature in April 2022.  The borrower may voluntarily repay outstanding loans under the Margin Loan Facility at any time without premium or penalty, other than customary “breakage” costs, subject to certain minimum threshold amounts for prepayment.

[0001571996-20-000045:notes:143]
Aggregate Future Maturities

[0001571996-20-000045:notes:144]
The following table presents the aggregate future maturities of the Company’s debt as of July 31, 2020 for the periods indicated:

[0001571996-20-000045:notes:145]
|  | Maturities by Fiscal Year |  |  |  |  |  |  |  |  |  |  |  |  |
|  | 2021 (remaining six months) |  | 2022 |  | 2023 |  | 2024 |  | 2025 |  | Thereafter |  | Total |
|  | (in millions) |  |  |  |  |  |  |  |  |  |  |  |  |
| Senior Secured Credit Facilities and First Lien Notes | $ | — |  |  | $ | 3,237 |  |  | $ | 286 |  |  | $ | 6,702 |  |  | $ | 1,775 |  |  | $ | 18,251 |  |  | $ | 30,251 |  |
| Unsecured Notes and Debentures | — |  |  | 400 |  |  | — |  |  | — |  |  | — |  |  | 952 |  |  | 1,352 |  |
| Senior Notes and EMC Notes | — |  |  | 1,075 |  |  | — |  |  | 1,000 |  |  | 1,625 |  |  | — |  |  | 3,700 |  |
| VMware Notes | 1,500 |  |  | — |  |  | 1,500 |  |  | — |  |  | — |  |  | 3,250 |  |  | 6,250 |  |
| DFS Debt | 2,912 |  |  | 2,906 |  |  | 2,229 |  |  | 163 |  |  | 627 |  |  | — |  |  | 8,837 |  |
| Margin Loan Facility | — |  |  | — |  |  | 4,000 |  |  | — |  |  | — |  |  | — |  |  | 4,000 |  |
| Other | 5 |  |  | 10 |  |  | 11 |  |  | 8 |  |  | 8 |  |  | 105 |  |  | 147 |  |
| Total maturities, principal amount | 4,417 |  |  | 7,628 |  |  | 8,026 |  |  | 7,873 |  |  | 4,035 |  |  | 22,558 |  |  | 54,537 |  |
| Associated carrying value adjustments | (1) |  |  | (29) |  |  | (21) |  |  | (43) |  |  | (84) |  |  | (406) |  |  | (584) |  |
| Total maturities, carrying value amount | $ | 4,416 |  |  | $ | 7,599 |  |  | $ | 8,005 |  |  | $ | 7,830 |  |  | $ | 3,951 |  |  | $ | 22,152 |  |  | $ | 53,953 |  |

[0001571996-20-000045:notes:146]
Covenants and Unrestricted Net Assets — The credit agreement for the Senior Secured Credit Facilities contains customary negative covenants that generally limit the ability of Denali Intermediate Inc., a wholly-owned subsidiary of Dell Technologies, Dell, and Dell’s and Denali Intermediate’s other restricted subsidiaries to incur debt, create liens, make fundamental changes, enter into asset sales, make certain investments, pay dividends or distribute or redeem certain equity interests, prepay or redeem certain debt, and enter into certain transactions with affiliates.  The indenture governing the Senior Notes contains customary negative covenants that generally limit the ability of Denali Intermediate, Dell, and Dell’s and Denali Intermediate’s other restricted subsidiaries to incur additional debt or issue certain preferred shares, pay dividends on or make other distributions in respect of capital stock or make other restricted payments, make certain investments, sell or transfer certain assets, create liens on certain assets to secure debt, consolidate, merge, sell, or otherwise dispose of all or substantially all assets, enter into certain transactions with affiliates, and designate subsidiaries as unrestricted subsidiaries.  The negative covenants under such credit agreements and indenture are subject to certain exceptions, qualifications, and “baskets.”  The indentures governing the First Lien Notes, the Unsecured Notes and Debentures, and the EMC Notes variously impose limitations, subject to specified exceptions, on creating certain liens, entering into sale and lease-back transactions, and entering into certain asset sales.  The foregoing credit agreements and indentures contain customary events of default, including failure to make required payments, failure to comply with covenants, and the occurrence of certain events of bankruptcy and insolvency.

[0001571996-20-000045:notes:147]
As of July 31, 2020, the Company had certain consolidated subsidiaries that were designated as unrestricted subsidiaries for all purposes of the applicable credit agreements and the indentures governing the First Lien Notes and the Senior Notes.  Substantially all of the net assets of the Company’s consolidated subsidiaries were restricted, with the exception of the Company’s unrestricted subsidiaries, primarily VMware, Inc., Secureworks, and their respective subsidiaries, as of July 31, 2020.

[0001571996-20-000045:notes:148]
The Term Loan A-4 Facility, the Term Loan A-6 Facility, and the Revolving Credit Facility are subject to a first lien leverage ratio covenant that is tested at the end of each fiscal quarter of Dell with respect to Dell’s preceding four fiscal quarters.  The Company was in compliance with all financial covenants as of July 31, 2020.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001571996-20-000045:notes:149]
[same as prior period, unchanged from 0001571996-20-000034:notes:146]

[0001571996-20-000045:notes:150]
[same as prior period, unchanged from 0001571996-20-000034:notes:147]

[0001571996-20-000045:notes:151]
[same as prior period, unchanged from 0001571996-20-000034:notes:148]

[0001571996-20-000045:notes:152]
[same as prior period, unchanged from 0001571996-20-000034:notes:149]

[0001571996-20-000045:notes:153]
[same as prior period, unchanged from 0001571996-20-000034:notes:150]

[0001571996-20-000045:notes:154]
During the three and six months ended July 31, 2020 and August 2, 2019, the Company did not discontinue any cash flow hedges related to foreign exchange contracts that had a material impact on the Company’s results of operations due to the probability that the forecasted cash flows would not occur.

[0001571996-20-000045:notes:155]
[same as prior period, unchanged from 0001571996-20-000034:notes:152]

[0001571996-20-000045:notes:156]
[same as prior period, unchanged from 0001571996-20-000034:notes:153]

[0001571996-20-000045:notes:157]
[same as prior period, unchanged from 0001571996-20-000034:notes:154]

[0001571996-20-000045:notes:158]
[same as prior period, unchanged from 0001571996-20-000034:notes:155]

[0001571996-20-000045:notes:159]
[same as prior period, unchanged from 0001571996-20-000034:notes:156]

[0001571996-20-000045:notes:160]
[same as prior period, unchanged from 0001571996-20-000034:notes:157]

[0001571996-20-000045:notes:161]
[same as prior period, unchanged from 0001571996-20-000034:notes:158]

[0001571996-20-000045:notes:162]
[same as prior period, unchanged from 0001571996-20-000034:notes:159]

[0001571996-20-000045:notes:163]
|  | July 31, 2020 |  | January 31, 2020 |
|  | (in millions) |  |  |
| Foreign exchange contracts: |  |  |  |
| Designated as cash flow hedging instruments | $ | 7,600 |  |  | $ | 8,703 |  |
| Non-designated as hedging instruments | 7,507 |  |  | 7,711 |  |
| Total | $ | 15,107 |  |  | $ | 16,414 |  |
| Interest rate contracts: |  |  |  |
| Non-designated as hedging instruments | $ | 5,333 |  |  | $ | 4,043 |  |

[0001571996-20-000045:notes:164]
[same as prior period, unchanged from 0001571996-20-000034:notes:161]

[0001571996-20-000045:notes:165]
| Derivatives in Cash Flow Hedging Relationships |  | Gain (Loss) Recognized in Accumulated OCI, Net of Tax, on Derivatives |  | Location of Gain (Loss) Reclassified from Accumulated OCI into Income |  | Gain (Loss) Reclassified from Accumulated OCI into Income |  |  |  |  |
|  |  | (in millions) |  |  |  | (in millions) |  |  |  |  |
| For the three months ended July 31, 2020 |  |  |  |  |  |  |  |  |  |  |
|  |  |  |  | Total net revenue |  | $ | 9 |  |  |  |  |  |
| Foreign exchange contracts |  | $ | (257) |  |  | Total cost of net revenue |  | (1) |  |  |  |  |  |
| Interest rate contracts |  | — |  |  | Interest and other, net |  | — |  |  |  |  |  |
| Total |  | $ | (257) |  |  |  |  | $ | 8 |  |  |  |  |  |
| For the three months ended August 2, 2019 |  |  |  |  |  |  |  |  |  |  |
|  |  |  |  | Total net revenue |  | $ | 68 |  |  |  |  |  |
| Foreign exchange contracts |  | $ | 105 |  |  | Total cost of net revenue |  | — |  |  |  |  |  |
| Interest rate contracts |  | — |  |  | Interest and other, net |  | — |  |  |  |  |  |
| Total |  | $ | 105 |  |  |  |  | $ | 68 |  |  |  |  |  |
| For the six months ended July 31, 2020 |  |  |  |  |  |  |  |  |  |  |
|  |  |  |  | Total net revenue |  | $ | 105 |  |  |  |  |  |
| Foreign exchange contracts |  | $ | (90) |  |  | Total cost of net revenue |  | 3 |  |  |  |  |  |
| Interest rate contracts |  | — |  |  | Interest and other, net |  | — |  |  |  |  |  |
| Total |  | $ | (90) |  |  |  |  | $ | 108 |  |  |  |  |  |
| For the six months ended August 2, 2019 |  |  |  |  |  |  |  |  |  |  |
|  |  |  |  | Total net revenue |  | $ | 126 |  |  |  |  |  |
| Foreign exchange contracts |  | $ | 257 |  |  | Total cost of net revenue |  | — |  |  |  |  |  |
| Interest rate contracts |  | — |  |  | Interest and other, net |  | — |  |  |  |  |  |
| Total |  | $ | 257 |  |  |  |  | $ | 126 |  |  |  |  |  |

[0001571996-20-000045:notes:166]
[same as prior period, unchanged from 0001571996-20-000034:notes:163]

[0001571996-20-000045:notes:167]
|  |  | Three Months Ended |  |  |  | Six Months Ended |  |  |  |  |
|  |  | July 31, 2020 |  | August 2, 2019 |  | July 31, 2020 |  | August 2, 2019 |  | Location of Gain (Loss) Recognized |
|  |  | (in millions) |  |  |  |  |  |  |  |  |
| Gain (Loss) Recognized: |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | 162 |  |  | $ | 7 |  |  | $ | 214 |  |  | $ | (59) |  |  | Interest and other, net |
| Interest rate contracts |  | (5) |  |  | (15) |  |  | (44) |  |  | (22) |  |  | Interest and other, net |
| Total |  | $ | 157 |  |  | $ | (8) |  |  | $ | 170 |  |  | $ | (81) |  |  |  |

[0001571996-20-000045:notes:168]
[same as prior period, unchanged from 0001571996-20-000034:notes:165]

[0001571996-20-000045:notes:169]
[same as prior period, unchanged from 0001571996-20-000034:notes:166]

[0001571996-20-000045:notes:170]
|  | July 31, 2020 |  |  |  |  |  |  |  |  |
|  | Other CurrentAssets |  | Other Non-Current Assets |  | Other CurrentLiabilities |  | Other Non-CurrentLiabilities |  | TotalFair Value |
|  | (in millions) |  |  |  |  |  |  |  |  |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts in an asset position | $ | 15 |  |  | $ | — |  |  | $ | 16 |  |  | $ | — |  |  | $ | 31 |  |
| Foreign exchange contracts in a liability position | (37) |  |  | — |  |  | (77) |  |  | — |  |  | (114) |  |
| Net asset (liability) | (22) |  |  | — |  |  | (61) |  |  | — |  |  | (83) |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts in an asset position | 472 |  |  | 1 |  |  | 80 |  |  | — |  |  | 553 |  |
| Foreign exchange contracts in a liability position | (123) |  |  | — |  |  | (290) |  |  | (4) |  |  | (417) |  |
| Interest rate contracts in an asset position | — |  |  | 10 |  |  | — |  |  | — |  |  | 10 |  |
| Interest rate contracts in a liability position | — |  |  | — |  |  | — |  |  | (44) |  |  | (44) |  |
| Net asset (liability) | 349 |  |  | 11 |  |  | (210) |  |  | (48) |  |  | 102 |  |
| Total derivatives at fair value | $ | 327 |  |  | $ | 11 |  |  | $ | (271) |  |  | $ | (48) |  |  | $ | 19 |  |
|  | January 31, 2020 |  |  |  |  |  |  |  |  |
|  | Other CurrentAssets |  | Other Non-Current Assets |  | Other CurrentLiabilities |  | Other Non-CurrentLiabilities |  | TotalFair Value |
|  | (in millions) |  |  |  |  |  |  |  |  |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts in an asset position | $ | 108 |  |  | $ | — |  |  | $ | 15 |  |  | $ | — |  |  | $ | 123 |  |
| Foreign exchange contracts in a liability position | (2) |  |  | — |  |  | (3) |  |  | — |  |  | (5) |  |
| Net asset (liability) | 106 |  |  | — |  |  | 12 |  |  | — |  |  | 118 |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts in an asset position | 136 |  |  | — |  |  | 39 |  |  | — |  |  | 175 |  |
| Foreign exchange contracts in a liability position | (162) |  |  | — |  |  | (81) |  |  | (6) |  |  | (249) |  |
| Interest rate contracts in an asset position | — |  |  | 1 |  |  | — |  |  | — |  |  | 1 |  |
| Interest rate contracts in a liability position | — |  |  | — |  |  | — |  |  | (32) |  |  | (32) |  |
| Net asset (liability) | (26) |  |  | 1 |  |  | (42) |  |  | (38) |  |  | (105) |  |
| Total derivatives at fair value | $ | 80 |  |  | $ | 1 |  |  | $ | (30) |  |  | $ | (38) |  |  | $ | 13 |  |

[0001571996-20-000045:notes:171]
[same as prior period, unchanged from 0001571996-20-000034:notes:168]

[0001571996-20-000045:notes:172]
|  | July 31, 2020 |  |  |  |  |  |  |  |  |  |  |
|  | Gross Amounts of Recognized Assets/ (Liabilities) |  | Gross Amounts Offset in the Statement of Financial Position |  | Net Amounts of Assets/ (Liabilities) Presented in the Statement of Financial Position |  | Gross Amounts not Offset in the Statement of Financial Position |  |  |  | Net Amount |
|  |  |  |  |  |  |  | Financial Instruments |  | Cash Collateral Received or Pledged |  |  |
|  | (in millions) |  |  |  |  |  |  |  |  |  |  |
| Derivative instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Financial assets | $ | 594 |  |  | $ | (256) |  |  | $ | 338 |  |  | $ | — |  |  | $ | — |  |  | $ | 338 |  |
| Financial liabilities | (575) |  |  | 256 |  |  | (319) |  |  | — |  |  | — |  |  | (319) |  |
| Total derivative instruments | $ | 19 |  |  | $ | — |  |  | $ | 19 |  |  | $ | — |  |  | $ | — |  |  | $ | 19 |  |
|  | January 31, 2020 |  |  |  |  |  |  |  |  |  |  |
|  | Gross Amounts of Recognized Assets/ (Liabilities) |  | Gross Amounts Offset in the Statement of Financial Position |  | Net Amounts of Assets/ (Liabilities) Presented in the Statement of Financial Position |  | Gross Amounts not Offset in the Statement of Financial Position |  |  |  | Net Amount |
|  |  |  |  |  |  |  | Financial Instruments |  | Cash Collateral Received or Pledged |  |  |
|  | (in millions) |  |  |  |  |  |  |  |  |  |  |
| Derivative instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Financial assets | $ | 299 |  |  | $ | (218) |  |  | $ | 81 |  |  | $ | — |  |  | $ | — |  |  | $ | 81 |  |
| Financial liabilities | (286) |  |  | 218 |  |  | (68) |  |  | — |  |  | 15 |  |  | (53) |  |
| Total derivative instruments | $ | 13 |  |  | $ | — |  |  | $ | 13 |  |  | $ | — |  |  | $ | 15 |  |  | $ | 28 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001571996-20-000045:notes:173]
[same as prior period, unchanged from 0001571996-20-000034:notes:170]

[0001571996-20-000045:notes:174]
[same as prior period, unchanged from 0001571996-20-000034:notes:171]

[0001571996-20-000045:notes:175]
VMware, Inc. Acquisitions

[0001571996-20-000045:notes:176]
Datrium, Inc. — During the three months ended July 31, 2020, VMware, Inc. completed the acquisition of Datrium, Inc., a provider of cloud-native disaster recovery solutions, to broaden the VMware Site Recovery Disaster Recovery as a Service offerings.  The total purchase price, net of cash acquired, was $137 million.  The purchase price primarily included $25 million of identifiable intangible assets and $91 million of goodwill that is not expected to be deductible for tax purposes.  The identifiable intangible assets, which primarily consisted of completed technology, have estimated useful lives of three years to five years.

[0001571996-20-000045:notes:177]
Lastline, Inc. — During the three months ended July 31, 2020, VMware, Inc. completed the acquisition of Lastline, Inc., a provider of network-based security breach detection products and services, to enhance capabilities for network detection and threat analysis on VMware NSX and SD-WAN offerings.  The total purchase price, net of cash acquired, was $114 million. The purchase price primarily included $29 million of identifiable intangible assets and $86 million of goodwill that is not expected to be deductible for tax purposes.  The identifiable intangible assets, which primarily consisted of completed technology, have estimated useful lives of one year to four years.

[0001571996-20-000045:notes:178]
[same as prior period, unchanged from 0001571996-20-000034:notes:173]

[0001571996-20-000045:notes:179]
Other Fiscal 2021 Acquisitions — During the three months ended July 31, 2020, VMware, Inc. completed two other acquisitions, which were not material individually to the Condensed Consolidated Financial Statements.  VMware, Inc. expects these acquisitions to enhance its product features and capabilities for VMware Carbon Black Cloud and vRealize Operations offerings.  The aggregate purchase price for these two acquisitions, net of cash acquired, was $40 million and primarily included $31 million of identifiable intangible assets and $16 million of goodwill, of which $24 million is expected to be deductible for tax purposes.  The identifiable intangible assets, which primarily consisted of completed technology, have estimated useful lives of one year to five years.

[0001571996-20-000045:notes:180]
The pro forma financial information assuming the Fiscal 2021 acquisitions had occurred as of the beginning of the fiscal year prior to the fiscal year of acquisition, as well as the revenue and earnings generated during the current fiscal year, were not material.

[0001571996-20-000045:notes:181]
[same as prior period, unchanged from 0001571996-20-000034:notes:174]

[0001571996-20-000045:notes:182]
[same as prior period, unchanged from 0001571996-20-000034:notes:175]

[0001571996-20-000045:notes:183]
[same as prior period, unchanged from 0001571996-20-000034:notes:176]

[0001571996-20-000045:notes:184]
|  | Infrastructure Solutions Group |  | Client Solutions Group |  | VMware |  | Other Businesses (a) |  | Total |
|  | (in millions) |  |  |  |  |  |  |  |  |
| Balance as of January 31, 2020 | $ | 15,089 |  |  | $ | 4,237 |  |  | $ | 20,532 |  |  | $ | 1,833 |  |  | $ | 41,691 |  |
| Goodwill acquired (b) | — |  |  | — |  |  | 218 |  |  | — |  |  | 218 |  |
| Impact of foreign currency translation | 111 |  |  | — |  |  | — |  |  | 7 |  |  | 118 |  |
| Reclassification to assets held for sale (c) | — |  |  | — |  |  | — |  |  | (1,383) |  |  | (1,383) |  |
| Balance as of July 31, 2020 | $ | 15,200 |  |  | $ | 4,237 |  |  | $ | 20,750 |  |  | $ | 457 |  |  | $ | 40,644 |  |

[0001571996-20-000045:notes:185]
(a) As of July 31, 2020, goodwill allocated to Other businesses consists of Secureworks, Virtustream, and Boomi.

[0001571996-20-000045:notes:186]
(b) VMware, Inc. business combinations completed during the six months ended July 31, 2020, as discussed above.

[0001571996-20-000045:notes:187]
(c) During the six months ended July 31, 2020, RSA Security’s goodwill was reclassified to current assets held for sale on the Condensed Consolidated Statements of Financial Position due to the Company’s entry into a definitive agreement to sell RSA Security.  See Note 1 and Note 19 of the Notes to the Condensed Consolidated Financial Statements for additional information about the divestiture of RSA Security.

[0001571996-20-000045:notes:188]
Goodwill Impairment Tests — Goodwill and indefinite-lived intangible assets are tested for impairment annually during the third fiscal quarter and whenever events or circumstances may indicate that an impairment has occurred.  As a result of the changes in the current economic environment related to the COVID-19 pandemic, the Company considered whether there was a potential triggering event requiring the evaluation of whether goodwill of any of the reporting units should be tested for impairment.  The Company determined there was no triggering event and no impairment test was performed as of July 31, 2020.

[0001571996-20-000045:notes:189]
For the annual impairment review in the third quarter of Fiscal 2020, the Company elected to bypass the assessment of qualitative factors to determine whether it was more likely than not that the fair value of a reporting unit was less than its carrying amount, including goodwill.  In electing to bypass the qualitative assessment, the Company proceeded directly to performing a quantitative goodwill impairment test to measure the fair value of each goodwill reporting unit relative to its carrying amount, and to determine the amount of goodwill impairment loss to be recognized, if any.

[0001571996-20-000045:notes:190]
[same as prior period, unchanged from 0001571996-20-000034:notes:183]

[0001571996-20-000045:notes:191]
[same as prior period, unchanged from 0001571996-20-000034:notes:184]

[0001571996-20-000045:notes:192]
Based on the results of the annual impairment test performed during the fiscal year ended January 31, 2020, the fair values of each of the reporting units exceeded their carrying values.  Based on this annual impairment test, it was determined that the fair value of the RSA Security reporting unit exceeded its carrying value by 13% as of November 1, 2019.  The Company’s entry into a definitive agreement to sell RSA Security for $2.075 billion, as discussed in Note 1 of the Notes to the Condensed Consolidated Financial Statements, provided a new fair value indication that the RSA Security reporting unit exceeds its carrying value.  Accordingly, subsequent to the annual impairment test, based on fair value indicators as of January 31, 2020 and July 31, 2020, it was determined that the fair value of the RSA Security reporting unit exceeded its carrying amount by 20%.

[0001571996-20-000045:notes:193]
During the fiscal year ended January 31, 2020, an interim impairment assessment of Virtustream was required.  There are no remaining balances of Virtustream goodwill, intangible assets, or property, plant, and equipment as of January 31, 2020 following the gross asset impairment charge of $619 million (comprised of $207 million of goodwill, $266 million of intangible assets, net, and $146 million of property, plant, and equipment, net) recognized during the fiscal year ended January 31, 2020, and a gross goodwill impairment charge of $190 million recognized during the fiscal year ended February 1, 2019.  The impairment is reflected in Other, net within cash flows from operating activities on the Condensed Consolidated Statements of Cash Flows.

[0001571996-20-000045:notes:194]
[same as prior period, unchanged from 0001571996-20-000034:notes:187]

[0001571996-20-000045:notes:195]
[same as prior period, unchanged from 0001571996-20-000034:notes:188]

[0001571996-20-000045:notes:196]
|  | July 31, 2020 |  |  |  |  |  | January 31, 2020 |  |  |  |  |
|  | Gross |  | AccumulatedAmortization |  | Net |  | Gross |  | AccumulatedAmortization |  | Net |
|  | (in millions) |  |  |  |  |  |  |  |  |  |  |
| Customer relationships | $ | 22,392 |  |  | $ | (14,555) |  |  | $ | 7,837 |  |  | $ | 22,950 |  |  | $ | (13,821) |  |  | $ | 9,129 |  |
| Developed technology | 15,451 |  |  | (11,384) |  |  | 4,067 |  |  | 15,707 |  |  | (10,974) |  |  | 4,733 |  |
| Trade names | 1,267 |  |  | (862) |  |  | 405 |  |  | 1,306 |  |  | (816) |  |  | 490 |  |
| Definite-lived intangible assets | 39,110 |  |  | (26,801) |  |  | 12,309 |  |  | 39,963 |  |  | (25,611) |  |  | 14,352 |  |
| Indefinite-lived trade names | 3,755 |  |  | — |  |  | 3,755 |  |  | 3,755 |  |  | — |  |  | 3,755 |  |
| Total intangible assets | $ | 42,865 |  |  | $ | (26,801) |  |  | $ | 16,064 |  |  | $ | 43,718 |  |  | $ | (25,611) |  |  | $ | 18,107 |  |

[0001571996-20-000045:notes:197]
Amortization expense related to definite-lived intangible assets was approximately $0.8 billion and $1.1 billion for the three months ended July 31, 2020 and August 2, 2019, respectively, and $1.7 billion and $2.3 billion for the six months ended July 31, 2020 and August 2, 2019, respectively.  There were no material impairment charges related to intangible assets during  the three and six months ended July 31, 2020.  During the three and six months ended August 2, 2019, an impairment charge related to Virtustream intangible assets, net was approximately $266 million.

[0001571996-20-000045:notes:198]
During the three months ended May 1, 2020, the Company recognized proceeds and a gain of $120 million from the sale of certain internally developed intellectual property assets.

[0001571996-20-000045:notes:199]
[same as prior period, unchanged from 0001571996-20-000034:notes:192]

[0001571996-20-000045:notes:200]
|  | July 31, 2020 |
| Fiscal Years | (in millions) |
| 2021 (remaining six months) | $ | 1,687 |  |
| 2022 | 2,685 |  |
| 2023 | 1,808 |  |
| 2024 | 1,444 |  |
| 2025 | 1,101 |  |
| Thereafter | 3,584 |  |
| Total | $ | 12,309 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001571996-20-000045:notes:201]
[same as prior period, unchanged from 0001571996-20-000034:notes:194]

[0001571996-20-000045:notes:202]
[same as prior period, unchanged from 0001571996-20-000034:notes:195]

[0001571996-20-000045:notes:203]
[same as prior period, unchanged from 0001571996-20-000034:notes:196]

[0001571996-20-000045:notes:204]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | July 31, 2020 |  | August 2, 2019 |  | July 31, 2020 |  | August 2, 2019 |
|  | (in millions) |  |  |  |  |  |  |
| Deferred revenue: |  |  |  |  |  |  |  |
| Deferred revenue at beginning of period | $ | 27,617 |  |  | $ | 24,178 |  |  | $ | 27,800 |  |  | $ | 24,010 |  |
| Revenue deferrals | 6,550 |  |  | 5,975 |  |  | 12,095 |  |  | 10,875 |  |
| Revenue recognized | (5,376) |  |  | (4,805) |  |  | (10,843) |  |  | (9,537) |  |
| Other (a) | — |  |  | — |  |  | (261) |  |  | — |  |
| Deferred revenue at end of period | $ | 28,791 |  |  | $ | 25,348 |  |  | $ | 28,791 |  |  | $ | 25,348 |  |
| Short-term deferred revenue | $ | 15,341 |  |  | $ | 13,568 |  |  | $ | 15,341 |  |  | $ | 13,568 |  |
| Long-term deferred revenue | $ | 13,450 |  |  | $ | 11,780 |  |  | $ | 13,450 |  |  | $ | 11,780 |  |

[0001571996-20-000045:notes:205]
(a) Reclassification of RSA Security deferred revenue to liabilities held for sale as of July 31, 2020.  See Note 1 and Note 19 of the Notes to the Condensed Consolidated Financial Statements for more information about the divestiture of RSA Security.

[0001571996-20-000045:notes:206]
Remaining Performance Obligations — Remaining performance obligations represent the aggregate amount of the transaction price allocated to performance obligations not delivered, or partially undelivered, as of the end of the reporting period.  Remaining performance obligations include deferred revenue plus unbilled amounts not yet recorded in deferred revenue.  The value of the transaction price allocated to remaining performance obligations as of July 31, 2020 was approximately $37 billion.  The Company expects to recognize approximately 62% of remaining performance obligations as revenue in the next twelve months, and the remainder thereafter.

[0001571996-20-000045:notes:207]
[same as prior period, unchanged from 0001571996-20-000034:notes:200]

[0001571996-20-000045:notes:208]
[same as prior period, unchanged from 0001571996-20-000034:notes:201]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001571996-20-000045:notes:209]
NOTE 10 — COMMITMENTS AND CONTINGENCIES

[0001571996-20-000045:notes:210]
Legal Matters

[0001571996-20-000045:notes:211]
The Company is involved in various claims, suits, assessments, investigations, and legal proceedings that arise from time to time in the ordinary course of its business, including those identified below, consisting of matters involving consumer, antitrust, tax, intellectual property, and other issues on a global basis.

[0001571996-20-000045:notes:212]
The Company accrues a liability when it believes that it is both probable that a liability has been incurred and that it can reasonably estimate the amount of the loss.  The Company reviews these accruals at least quarterly and adjusts them to reflect ongoing negotiations, settlements, rulings, advice of legal counsel, and other relevant information.  To the extent new information is obtained and the Company’s views on the probable outcomes of claims, suits, assessments, investigations, or legal proceedings change, changes in the Company’s accrued liabilities would be recorded in the period in which such a determination is made.  For some matters, the amount of liability is not probable or the amount cannot be reasonably estimated and therefore accruals have not been made.

[0001571996-20-000045:notes:213]
The following is a discussion of the Company’s significant legal matters and other proceedings:

[0001571996-20-000045:notes:214]
Class Actions Related to the Class V Transaction — Four purported stockholders brought putative class action complaints arising out of the Class V transaction described in Note 1of the Notes to the Condensed Consolidated Financial Statements.  The actions were captioned Hallandale Beach Police and Fire Retirement Plan v. Michael Dell et al. (Civil Action No. 2018-0816-JTL), Howard Karp v. Michael Dell et al. (Civil Action No. 2019-0032-JTL), Miramar Police Officers’ Retirement Plan v. Michael Dell et al. (Civil Action No. 2019-0049-JTL), and Steamfitters Local 449 Pension Plan v. Michael Dell et al. (Civil Action No. 2019-0115-JTL).  The four actions were consolidated in the Delaware Chancery Court into In Re Dell Class V Litigation (Consol. C.A. No. 2018-0816-JTL), which names as defendants the Company’s board of directors and certain stockholders of the Company, including Michael S. Dell.  The plaintiffs generally allege that the defendants breached their fiduciary duties to the former holders of Class V Common Stock in connection with the Class V transaction by allegedly causing the Company to enter into a transaction that favored the interests of the controlling stockholders at the expense of such former stockholders.  The plaintiffs seek, among other remedies, a judicial declaration that the defendants breached their fiduciary duties and an award of damages, fees, and costs.  The plaintiffs filed an amended complaint in August 2019 making substantially similar allegations to those described above.  The defendants filed a motion to dismiss the action in September 2019.  The court denied the motion in June 2020 and the case has now moved to discovery.

[0001571996-20-000045:notes:215]
Patent Litigation — On April 25, 2019, Cirba Inc. (“Cirba”) filed a lawsuit against VMware, Inc. in the United States District Court for the District of Delaware, alleging two patent infringement claims and three trademark infringement-related claims.  On May 6, 2019, Cirba filed a motion seeking a preliminary injunction tied to one of the two patents it alleges VMware, Inc. infringes.  Following a hearing on August 6, 2019, the Court denied Cirba’s preliminary injunction motion and set the case for trial in mid-January 2020.  On August 20, 2019, VMware, Inc. filed counterclaims against Cirba, asserting among other claims that Cirba is infringing four VMware, Inc. patents.  The Delaware Court severed those claims from the January 2020 trial on Cirba’s claims, and the trial on VMware, Inc.’s patent claims is currently set for September 2021.  The trial on Cirba’s claims in the Delaware court was completed on January 23, 2020, and on January 24, 2020, the jury returned a verdict finding that VMware, Inc. willfully infringed the two asserted patents and awarding approximately $237 million in damages.  The jury further found that VMware, Inc. was not liable on Cirba’s trademark infringement-related claims.  A total of $237 million was accrued for the Delaware action, which reflects the estimated losses that are considered both probable and reasonably estimable at this time.  The parties filed the post-trial motions in which VMware, Inc. moved to set aside the verdict and reduce the damages award, and Cirba moved for a permanent injunction, enhanced damages, setting of an ongoing royalty rate, and an award of pre-judgment and post-judgment interest and supplemental damages.  A hearing was held in the Delaware court on those motions on May 15, 2020, and the Delaware court has taken those motions under advisement.  VMware, Inc. intends to vigorously defend itself in this matter, including, if necessary, via an appeal.  Final resolution of this matter could be materially different from the amount accrued.  The amount accrued for this matter is included in Accrued and other in the Condensed Consolidated Statements of Financial Position as of July 31, 2020 and January 31, 2020, and the charge was classified in Selling, general and administrative in the Consolidated Statements of Income (Loss) during the fiscal year ended January 31, 2020.

[0001571996-20-000045:notes:216]
On October 22, 2019, VMware, Inc. filed a separate patent infringement lawsuit against Cirba in the United States District Court for the Eastern District of Virginia, asserting that Cirba infringes four additional VMware, Inc. patents.  The Virginia court transferred these patent claims to Delaware.  On March 23, 2020, Cirba filed a counterclaim asserting one additional patent against VMware, Inc.  VMware, Inc. intends to vigorously defend itself in this matter.

[0001571996-20-000045:notes:217]
Class Actions Related to VMware, Inc.’s Acquisition of Pivotal Software — Two purported stockholders brought putative class action complaints arising out of VMware, Inc.’s acquisition of Pivotal Software, Inc. on December 30, 2019 as described in Note 1 of the Notes to the Condensed Consolidated Financial Statements.  The two actions were consolidated in the Delaware Chancery Court into In re: Pivotal Software, Inc. Stockholders Litigation (Civil Action No. 2020-0440-KSJM).  The complaint names as defendants the Company, VMware, Inc., Michael S. Dell, and certain officers of Pivotal.  The plaintiffs generally allege that the defendants breached their fiduciary duties to the former holders of Pivotal Class A Common Stock in connection with VMware, Inc.’s acquisition of Pivotal by allegedly causing Pivotal to enter into a transaction that favored the interests of Pivotal’s controlling stockholders at the expense of such former stockholders.  The plaintiffs seek, among other remedies, a judicial declaration that the defendants breached their fiduciary duties and an award of damages, fees, and costs.

[0001571996-20-000045:notes:218]
Other Litigation — The various legal proceedings in which Dell is involved include commercial and intellectual property litigation.  Dell does not currently anticipate that any of these matters will have a material adverse effect on its business, financial condition, results of operations, or cash flows.

[0001571996-20-000045:notes:219]
As of July 31, 2020, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for these or other proceedings or matters has been incurred.  However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company’s business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters.  Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company’s business, financial condition, results of operations, or cash flows will depend on a number of variables, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.

[0001571996-20-000045:notes:220]
Indemnifications

[0001571996-20-000045:notes:221]
In the ordinary course of business, the Company enters into contractual arrangements under which it may agree to indemnify the third party to such arrangements from any losses incurred relating to the services it performs on behalf of the Company or for losses arising from certain events as defined in the particular contract, such as litigation or claims relating to past performance.  Such indemnification obligations may not be subject to maximum loss clauses.  Historically, payments related to these indemnifications have not been material to the Company.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001571996-20-000045:notes:222]
[same as prior period, unchanged from 0001571996-20-000034:notes:214]

[0001571996-20-000045:notes:223]
For the three months ended July 31, 2020 and August 2, 2019, the Company’s effective income tax rate was -119.8% and 3912.6% on pre-tax income of $500 million and pre-tax losses of $111 million, respectively.  For the six months ended July 31, 2020 and August 2, 2019, the Company’s effective income tax rate was -101.4% and 1895.7% on pre-tax income of $636 million and pre-tax losses of $254 million, respectively.  The changes in the Company’s effective tax rates are primarily driven by discrete tax items and a change in the Company’s jurisdictional mix of income.  For the three and six months ended July 31, 2020, the Company’s effective income tax rate benefit includes $746 million of discrete tax benefits related to an audit settlement.  For the six months ended July 31, 2020, the Company’s effective income tax rate also includes a discrete tax benefit of $59 million from an intra-entity asset transfer of certain of Pivotal’s intellectual property to an Irish subsidiary that was completed by VMware, Inc. during the period.  For the three and six months ended August 2, 2019, the Company’s effective tax rate includes discrete tax benefits of $4.5 billion and $4.9 billion, respectively, related to similar intra-entity asset transfers.  The tax benefit for each intra-entity asset transfer was recorded as a deferred tax asset in the period of transaction and represents the book and tax basis difference on the transferred assets measured based on the intellectual property’s current fair value and applicable Irish statutory tax rate.  The Company expects to be able to realize the deferred tax assets resulting from these intra-entity asset transfers.

[0001571996-20-000045:notes:224]
The differences between the estimated effective income tax rates and the U.S. federal statutory rate of 21% principally result from the Company’s geographical distribution of income, differences between the book and tax treatment of certain items, and the discrete tax items discussed above.  In certain jurisdictions, the Company’s tax rate is significantly less than the applicable statutory rate as a result of tax holidays.  The majority of the Company’s foreign income that is subject to these tax holidays and lower tax rates is attributable to Singapore, China, and Malaysia.  A significant portion of these income tax benefits relates to a tax holiday that will be effective until January 31, 2029.  The Company’s other tax holidays will expire in whole or in part during fiscal years 2022 through 2030.  Many of these tax holidays and reduced tax rates may be extended when certain conditions are met or may be terminated early if certain conditions are not met.  As of July 31, 2020, the Company was not aware of any matters of non-compliance related to these tax holidays.  The effective income tax rate for future quarters of Fiscal 2021 may be impacted by the actual mix of jurisdictions in which income is generated.

[0001571996-20-000045:notes:225]
During the three months ended July 31, 2020, the Company effectively settled the Internal Revenue Service (“IRS”) audit for fiscal years 2010 through 2014, for which the Company made a cash payment of $435 million to the IRS on August 3, 2020.  The IRS has started its examination of fiscal years 2015 through 2019.  The Company believes it has valid positions supporting its tax returns and that it is adequately reserved.

[0001571996-20-000045:notes:226]
[same as prior period, unchanged from 0001571996-20-000034:notes:218]

[0001571996-20-000045:notes:227]
Judgment is required in evaluating the Company’s uncertain tax positions and determining the Company’s provision for income taxes.  The unrecognized tax benefits were $1.3 billion and $2.5 billion as of July 31, 2020 and January 31, 2020, respectively, and are included in accrued and other and other non-current liabilities in the Condensed Consolidated Statements of Financial Position.  The Company does not anticipate a significant change to the total amount of unrecognized tax benefits within the next twelve months.
The Company takes certain non-income tax positions in the jurisdictions in which it operates and has received certain non-income tax assessments from various jurisdictions.  The Company believes that a material loss in these matters is not probable and that it is not reasonably possible that a material loss exceeding amounts already accrued has been incurred.  The Company believes its positions in these non-income tax litigation matters are supportable and that it ultimately will prevail in the matters.  In the normal course of business, the Company’s positions and conclusions related to its non-income taxes could be challenged and assessments may be made.  To the extent new information is obtained and the Company’s views on its positions, probable outcomes of assessments, or litigation change, changes in estimates to the Company’s accrued liabilities would be recorded in the period in which such a determination is made.  In the resolution process for income tax and non-income tax audits, the Company is required in certain situations to provide collateral guarantees or indemnification to regulators and tax authorities until the matter is resolved.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001571996-20-000045:notes:228]
[same as prior period, unchanged from 0001571996-20-000034:notes:221]

[0001571996-20-000045:notes:229]
[same as prior period, unchanged from 0001571996-20-000034:notes:222]

[0001571996-20-000045:notes:230]
[same as prior period, unchanged from 0001571996-20-000034:notes:223]

[0001571996-20-000045:notes:231]
|  | Foreign Currency Translation Adjustments |  |  |  | Cash Flow Hedges |  | Pension and Other Postretirement Plans |  | Accumulated Other Comprehensive Income (Loss) |
|  | (in millions) |  |  |  |  |  |  |  |  |
| Balances as of January 31, 2020 | $ | (678) |  |  |  |  | $ | 14 |  |  | $ | (45) |  |  | $ | (709) |  |
| Other comprehensive income (loss) before reclassifications | 264 |  |  |  |  | (90) |  |  | (22) |  |  | 152 |  |
| Amounts reclassified from accumulated other comprehensive income (loss) | — |  |  |  |  | (108) |  |  | 4 |  |  | (104) |  |
| Total change for the period | 264 |  |  |  |  | (198) |  |  | (18) |  |  | 48 |  |
| Less: Change in comprehensive loss attributable to non-controlling interests | — |  |  |  |  | (1) |  |  | — |  |  | (1) |  |
| Balances as of July 31, 2020 | $ | (414) |  |  |  |  | $ | (183) |  |  | $ | (63) |  |  | $ | (660) |  |

[0001571996-20-000045:notes:232]
[same as prior period, unchanged from 0001571996-20-000034:notes:225]

[0001571996-20-000045:notes:233]
[same as prior period, unchanged from 0001571996-20-000034:notes:226]

[0001571996-20-000045:notes:234]
|  |  |  | Three Months Ended |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  |  | July 31, 2020 |  |  |  |  |  |  |  | August 2, 2019 |  |  |  |  |
|  |  |  | Cash Flow Hedges |  | Pensions |  | Total |  |  |  | Cash Flow Hedges |  | Pensions |  | Total |
|  |  |  | (in millions) |  |  |  |  |  |  |  |  |  |  |  |  |
| Total reclassifications, net of tax: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue |  |  | $ | 9 |  |  | $ | — |  |  | $ | 9 |  |  |  |  | $ | 68 |  |  | $ | — |  |  | $ | 68 |  |
| Cost of net revenue |  |  | (1) |  |  | — |  |  | (1) |  |  |  |  | — |  |  | — |  |  | — |  |
| Operating expenses |  |  | — |  |  | (2) |  |  | (2) |  |  |  |  | — |  |  | — |  |  | — |  |
| Total reclassifications, net of tax |  |  | $ | 8 |  |  | $ | (2) |  |  | $ | 6 |  |  |  |  | $ | 68 |  |  | $ | — |  |  | $ | 68 |  |
|  |  |  | Six Months Ended |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  |  | July 31, 2020 |  |  |  |  |  |  |  | August 2, 2019 |  |  |  |  |
|  |  |  | Cash Flow Hedges |  | Pensions |  | Total |  |  |  | Cash Flow Hedges |  | Pensions |  | Total |
|  |  |  | (in millions) |  |  |  |  |  |  |  | (in millions) |  |  |  |  |
| Total reclassifications, net of tax: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue |  |  | $ | 105 |  |  | $ | — |  |  | $ | 105 |  |  |  |  | $ | 126 |  |  | $ | — |  |  | $ | 126 |  |
| Cost of net revenue |  |  | 3 |  |  | — |  |  | 3 |  |  |  |  | — |  |  | — |  |  | — |  |
| Operating expenses |  |  | — |  |  | (4) |  |  | (4) |  |  |  |  | — |  |  | — |  |  | — |  |
| Total reclassifications, net of tax |  |  | $ | 108 |  |  | $ | (4) |  |  | $ | 104 |  |  |  |  | $ | 126 |  |  | $ | — |  |  | $ | 126 |  |


## us-gaap:MinorityInterestDisclosureTextBlock

[0001571996-20-000045:notes:235]
[same as prior period, unchanged from 0001571996-20-000034:notes:228]

[0001571996-20-000045:notes:236]
VMware, Inc. — The non-controlling interests’ share of equity in VMware, Inc. is reflected as a component of the non-controlling interests in the Condensed Consolidated Statements of Financial Position and was $4.9 billion and $4.6 billion as of July 31, 2020 and January 31, 2020, respectively.  As of July 31, 2020 and January 31, 2020, the Company held approximately 80.4% and 80.9%, respectively, of the outstanding equity interest in VMware, Inc.

[0001571996-20-000045:notes:237]
As a result of VMware, Inc.’s acquisition of the non-controlling interest in Pivotal from Pivotal’s public shareholders on December 30, 2019, as described in Note 1 of the Notes to the Condensed Consolidated Financial Statements, the non-controlling interests’ share of equity in Pivotal is only reflected as a component of the non-controlling interest through December 30, 2019.  Pivotal’s Class A common stock ceased to be listed and traded on the NYSE as of the acquisition date, and there was no non-controlling interest in Pivotal as of July 31, 2020 and January 31, 2020.

[0001571996-20-000045:notes:238]
Secureworks — The non-controlling interests’ share of equity in Secureworks is reflected as a component of the non-controlling interests in the Condensed Consolidated Statements of Financial Position and was $94 million and $88 million as of July 31, 2020 and January 31, 2020, respectively.  As of July 31, 2020 and January 31, 2020, the Company held approximately 85.9% and 86.8%, respectively, of the outstanding equity interest in Secureworks, excluding restricted stock awards (“RSAs”).  As of July 31, 2020 and January 31, 2020, the Company held approximately 85.2% and 86.2%, respectively, of the outstanding equity interest in Secureworks, including RSAs.

[0001571996-20-000045:notes:239]
[same as prior period, unchanged from 0001571996-20-000034:notes:232]

[0001571996-20-000045:notes:240]
|  | Six Months Ended |
|  | July 31, 2020 |
|  | (in millions) |
| Net income attributable to Dell Technologies Inc. | $ | 1,191 |  |
| Transfers (to)/from the non-controlling interests: |  |
| Increase in Dell Technologies Inc. additional paid-in-capital for equity issuances and other equity activity | 491 |  |
| Decrease in Dell Technologies Inc. additional paid-in-capital for equity issuances and other equity activity | (529) |  |
| Net transfers to non-controlling interests | (38) |  |
| Change from net income attributable to Dell Technologies Inc. and transfers to the non-controlling interests | $ | 1,153 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001571996-20-000045:notes:241]
[same as prior period, unchanged from 0001571996-20-000034:notes:234]

[0001571996-20-000045:notes:242]
[same as prior period, unchanged from 0001571996-20-000034:notes:235]

[0001571996-20-000045:notes:243]
|  | Authorized |  | Issued |  | Outstanding |
|  | (in millions) |  |  |  |  |
| Common stock as of July 31, 2020 |  |  |  |  |  |
| Class A | 600 |  |  | 385 |  |  | 385 |  |
| Class B | 200 |  |  | 102 |  |  | 102 |  |
| Class C | 7,900 |  |  | 266 |  |  | 258 |  |
| Class D | 100 |  |  | — |  |  | — |  |
| Class V | 343 |  |  | — |  |  | — |  |
|  | 9,143 |  |  | 753 |  |  | 745 |  |
| Common stock as of January 31, 2020 |  |  |  |  |  |
| Class A | 600 |  |  | 385 |  |  | 385 |  |
| Class B | 200 |  |  | 102 |  |  | 102 |  |
| Class C | 7,900 |  |  | 258 |  |  | 256 |  |
| Class D | 100 |  |  | — |  |  | — |  |
| Class V | 343 |  |  | — |  |  | — |  |
|  | 9,143 |  |  | 745 |  |  | 743 |  |

[0001571996-20-000045:notes:244]
[same as prior period, unchanged from 0001571996-20-000034:notes:237]

[0001571996-20-000045:notes:245]
[same as prior period, unchanged from 0001571996-20-000034:notes:238]

[0001571996-20-000045:notes:246]
The Company is authorized to issue one million shares of preferred stock, par value $0.01 per share.  As of July 31, 2020 and January 31, 2020, no shares of preferred stock were issued or outstanding.

[0001571996-20-000045:notes:247]
[same as prior period, unchanged from 0001571996-20-000034:notes:240]

[0001571996-20-000045:notes:248]
[same as prior period, unchanged from 0001571996-20-000034:notes:241]

[0001571996-20-000045:notes:249]
[same as prior period, unchanged from 0001571996-20-000034:notes:242]

[0001571996-20-000045:notes:250]
Conversion Rights — Under the Company’s certificate of incorporation, at any time and from time to time, any holder of Class A Common Stock or Class B Common Stock has the right to convert all or any of the shares of Class A Common Stock or Class B Common Stock, as applicable, held by such holder into shares of Class C Common Stock on a one-to-one basis.  During the six months ended July 31, 2020, the Company issued 72,727 shares of Class C Common Stock to stockholders upon the conversion of the same number of shares of Class A Common Stock into Class C Common Stock in accordance with the Company’s certificate of incorporation.

[0001571996-20-000045:notes:251]
[same as prior period, unchanged from 0001571996-20-000034:notes:244]

[0001571996-20-000045:notes:252]
[same as prior period, unchanged from 0001571996-20-000034:notes:245]

[0001571996-20-000045:notes:253]
On February 24, 2020, the Company’s board of directors approved a stock repurchase program under which the Company is authorized to repurchase up to $1.0 billion of shares of the Class C Common Stock over a 24-month period expiring on February 28, 2022, of which approximately $760 million remained available as of July 31, 2020.  During the six months ended July 31, 2020, the Company repurchased approximately 6 million shares of Class C Common Stock for approximately $240 million. During the three months ended May 1, 2020, the Company suspended activity under its stock repurchase program.  During the six months ended August 2, 2019, Dell Technologies Common Stock repurchases were immaterial.

[0001571996-20-000045:notes:254]
[same as prior period, unchanged from 0001571996-20-000034:notes:247]

[0001571996-20-000045:notes:255]
[same as prior period, unchanged from 0001571996-20-000034:notes:248]

[0001571996-20-000045:notes:256]
On May 29, 2019, VMware, Inc.’s board of directors authorized the repurchase of up to $1.5 billion of VMware, Inc.’s Class A common stock through January 29, 2021.  On July 15, 2020, VMware, Inc.’s board of directors extended authorization of VMware, Inc.’s existing repurchase program and authorized the repurchase of up to an additional $1.0 billion of VMware, Inc.’s Class A common stock through January 28, 2022.  As of July 31, 2020, the cumulative authorized amount remaining for stock repurchases was $1.7 billion.

[0001571996-20-000045:notes:257]
During the six months ended July 31, 2020, VMware, Inc. repurchased 2.5 million shares of its Class A common stock in the open market for approximately $311 million.  During the six months ended August 2, 2019, VMware, Inc. repurchased 5.7 million shares of its Class A common stock in the open market for approximately $1.0 billion, of which approximately $0.1 billion impacted Dell Technologies’ accumulated deficit balance as of August 2, 2019 as a result of the full depletion of VMware, Inc’s additional paid-in capital in the same period.

[0001571996-20-000045:notes:258]
[same as prior period, unchanged from 0001571996-20-000034:notes:250]

[0001571996-20-000045:notes:259]
The above VMware, Inc. Class A common stock repurchases for the six months ended July 31, 2020 and August 2, 2019 exclude shares repurchased to settle employee tax withholding related to the vesting of VMware, Inc. stock awards of $275 million and $348 million, respectively.


## us-gaap:EarningsPerShareTextBlock

[0001571996-20-000045:notes:260]
[same as prior period, unchanged from 0001571996-20-000034:notes:252]

[0001571996-20-000045:notes:261]
[same as prior period, unchanged from 0001571996-20-000034:notes:253]

[0001571996-20-000045:notes:262]
[same as prior period, unchanged from 0001571996-20-000034:notes:254]

[0001571996-20-000045:notes:263]
[same as prior period, unchanged from 0001571996-20-000034:notes:255]

[0001571996-20-000045:notes:264]
[same as prior period, unchanged from 0001571996-20-000034:notes:256]

[0001571996-20-000045:notes:265]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | July 31, 2020 |  | August 2, 2019 |  | July 31, 2020 |  | August 2, 2019 |
| Earnings per share attributable to Dell Technologies Inc. |  |  |  |  |  |  |  |
| Dell Technologies Common Stock — Basic | $ | 1.41 |  |  | $ | 4.75 |  |  | $ | 1.61 |  |  | $ | 5.17 |  |
| Dell Technologies Common Stock — Diluted | $ | 1.37 |  |  | $ | 4.47 |  |  | $ | 1.56 |  |  | $ | 4.84 |  |

[0001571996-20-000045:notes:266]
[same as prior period, unchanged from 0001571996-20-000034:notes:258]

[0001571996-20-000045:notes:267]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | July 31, 2020 |  | August 2, 2019 |  | July 31, 2020 |  | August 2, 2019 |
|  | (in millions) |  |  |  |  |  |  |
| Numerator: Dell Technologies Common Stock |  |  |  |  |  |  |  |
| Net income attributable to Dell Technologies — basic | $ | 1,048 |  |  | $ | 3,416 |  |  | $ | 1,191 |  |  | $ | 3,709 |  |
| Incremental dilution from VMware, Inc. attributable to Dell Technologies (a) | (3) |  |  | (62) |  |  | (5) |  |  | (78) |  |
| Net income attributable to Dell Technologies — diluted | $ | 1,045 |  |  | $ | 3,354 |  |  | $ | 1,186 |  |  | $ | 3,631 |  |
| Denominator: Dell Technologies Common Stock weighted-average shares outstanding |  |  |  |  |  |  |  |
| Weighted-average shares outstanding — basic | 741 |  |  | 719 |  |  | 740 |  |  | 718 |  |
| Dilutive effect of options, restricted stock units, restricted stock, and other | 20 |  |  | 32 |  |  | 18 |  |  | 32 |  |
| Weighted-average shares outstanding — diluted | 761 |  |  | 751 |  |  | 758 |  |  | 750 |  |
| Weighted-average shares outstanding — antidilutive | 6 |  |  | 1 |  |  | 6 |  |  | 1 |  |

[0001571996-20-000045:notes:268]
(a)The incremental dilution from VMware, Inc. represents the impact of VMware, Inc.’s dilutive securities on diluted earnings per share of Dell Technologies Common Stock, and is calculated by multiplying the difference between VMware, Inc.’s basic and diluted earnings per share by the number of shares of VMware, Inc. common stock held by the Company.  For the three and six months ended August 2, 2019, the incremental dilution from VMware, Inc. was calculated by the Company without regard to VMware, Inc.’s required retrospective adjustments for the Pivotal acquisition in its stand-alone financial statements, and there was no incremental dilution from Pivotal due to its net loss position.  For both periods presented, there was no incremental dilution from Secureworks due to its net loss position.


## dell:TemporaryEquityTextBlock

[0001571996-20-000045:notes:269]
[same as prior period, unchanged from 0001571996-20-000034:notes:262]

[0001571996-20-000045:notes:270]
[same as prior period, unchanged from 0001571996-20-000034:notes:263]

[0001571996-20-000045:notes:271]
•For stock options to purchase Class C Common Stock subject to service requirements, the intrinsic value of the option is multiplied by the portion of the option for which services have been rendered.  Upon exercise of the option, the amount in temporary equity represents the fair value of the Class C Common Stock.

[0001571996-20-000045:notes:272]
•For stock appreciation rights, restricted stock units (“RSUs”), or restricted stock awards (“RSAs”), any of which stock award types are subject to service requirements, the fair value of the share is multiplied by the portion of the share for which services have been rendered.

[0001571996-20-000045:notes:273]
•For share-based arrangements that are subject to the occurrence of a contingent event, those amounts are reclassified to temporary equity based on a probability assessment performed by the Company on a periodic basis.  Contingent events include the achievement of performance-based metrics.

[0001571996-20-000045:notes:274]
[same as prior period, unchanged from 0001571996-20-000034:notes:267]

[0001571996-20-000045:notes:275]
[same as prior period, unchanged from 0001571996-20-000034:notes:268]

[0001571996-20-000045:notes:276]
|  | July 31, 2020 |  | January 31, 2020 |
|  | (in millions) |  |  |
| Redeemable shares classified as temporary equity | $ | 610 |  |  | $ | 629 |  |
| Issued and outstanding unrestricted common shares | 2 |  |  | 2 |  |
| Restricted stock units | 1 |  |  | 1 |  |
| Restricted stock awards | — |  |  | — |  |
| Outstanding stock options | 10 |  |  | 15 |  |

[0001571996-20-000045:notes:277]
The decrease in the value of redeemable shares during the six months ended July 31, 2020 was primarily attributable to a reduction in the number of shares eligible for put rights.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001571996-20-000045:notes:278]
[same as prior period, unchanged from 0001571996-20-000034:notes:271]

[0001571996-20-000045:notes:279]
[same as prior period, unchanged from 0001571996-20-000034:notes:272]

[0001571996-20-000045:notes:280]
[same as prior period, unchanged from 0001571996-20-000034:notes:273]

[0001571996-20-000045:notes:281]
[same as prior period, unchanged from 0001571996-20-000034:notes:274]

[0001571996-20-000045:notes:282]
[same as prior period, unchanged from 0001571996-20-000034:notes:275]

[0001571996-20-000045:notes:283]
[same as prior period, unchanged from 0001571996-20-000034:notes:276]

[0001571996-20-000045:notes:284]
[same as prior period, unchanged from 0001571996-20-000034:notes:277]

[0001571996-20-000045:notes:285]
The following table presents a reconciliation of net revenue by the Company’s reportable segments to the Company’s consolidated net revenue as well as a reconciliation of consolidated segment operating income to the Company’s consolidated operating income for the periods indicated:

[0001571996-20-000045:notes:286]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | July 31, 2020 |  | August 2, 2019 |  | July 31, 2020 |  | August 2, 2019 |
|  | (in millions) |  |  |  |  |  |  |
| Consolidated net revenue: |  |  |  |  |  |  |  |
| Infrastructure Solutions Group | $ | 8,207 |  |  | $ | 8,621 |  |  | $ | 15,776 |  |  | $ | 16,823 |  |
| Client Solutions Group | 11,203 |  |  | 11,748 |  |  | 22,307 |  |  | 22,658 |  |
| VMware | 2,908 |  |  | 2,651 |  |  | 5,663 |  |  | 5,108 |  |
| Reportable segment net revenue | 22,318 |  |  | 23,020 |  |  | 43,746 |  |  | 44,589 |  |
| Other businesses (a) | 457 |  |  | 434 |  |  | 974 |  |  | 855 |  |
| Impact of purchase accounting (c) | (42) |  |  | (84) |  |  | (90) |  |  | (166) |  |
| Total consolidated net revenue | $ | 22,733 |  |  | $ | 23,370 |  |  | $ | 44,630 |  |  | $ | 45,278 |  |
| Consolidated operating income: |  |  |  |  |  |  |  |
| Infrastructure Solutions Group | $ | 973 |  |  | $ | 1,050 |  |  | $ | 1,705 |  |  | $ | 1,893 |  |
| Client Solutions Group | 715 |  |  | 982 |  |  | 1,307 |  |  | 1,775 |  |
| VMware | 894 |  |  | 751 |  |  | 1,667 |  |  | 1,346 |  |
| Reportable segment operating income | 2,582 |  |  | 2,783 |  |  | 4,679 |  |  | 5,014 |  |
| Other businesses (a) | 37 |  |  | (14) |  |  | 102 |  |  | (48) |  |
| Unallocated transactions (b) | (1) |  |  | (26) |  |  | (2) |  |  | (27) |  |
| Impact of purchase accounting (c) | (53) |  |  | (102) |  |  | (116) |  |  | (203) |  |
| Amortization of intangibles | (847) |  |  | (1,060) |  |  | (1,702) |  |  | (2,277) |  |
| Transaction-related expenses (d) | (83) |  |  | (47) |  |  | (159) |  |  | (89) |  |
| Stock-based compensation expense (e) | (413) |  |  | (301) |  |  | (783) |  |  | (564) |  |
| Other corporate expenses (f) | (86) |  |  | (714) |  |  | (181) |  |  | (737) |  |
| Total consolidated operating income | $ | 1,136 |  |  | $ | 519 |  |  | $ | 1,838 |  |  | $ | 1,069 |  |

[0001571996-20-000045:notes:287]
(a)Secureworks, RSA Security, Virtustream, and Boomi constitute “Other businesses” and do not meet the requirements for a reportable segment, either individually or collectively.  The results of Other businesses are not material to the Company’s overall results.

[0001571996-20-000045:notes:288]
(b)Unallocated transactions includes other corporate items that are not allocated to Dell Technologies’ reportable segments.

[0001571996-20-000045:notes:289]
(c)Impact of purchase accounting includes non-cash purchase accounting adjustments that are primarily related to the EMC merger transaction.

[0001571996-20-000045:notes:290]
(d)Transaction-related expenses includes acquisition, integration, and divestiture related costs.

[0001571996-20-000045:notes:291]
(e)Stock-based compensation expense consists of equity awards granted based on the estimated fair value of those awards at grant date.

[0001571996-20-000045:notes:292]
(f)Other corporate expenses includes impairment charges, severance, facility action, and other costs.  During the second quarter and first six months of Fiscal 2020, this category includes Virtustream gross impairment charges of $619 million.

[0001571996-20-000045:notes:293]
[same as prior period, unchanged from 0001571996-20-000034:notes:286]

[0001571996-20-000045:notes:294]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | July 31, 2020 |  | August 2, 2019 |  | July 31, 2020 |  | August 2, 2019 |
|  | (in millions) |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |
| Infrastructure Solutions Group: |  |  |  |  |  |  |  |
| Servers and networking | $ | 4,196 |  |  | $ | 4,437 |  |  | $ | 7,954 |  |  | $ | 8,617 |  |
| Storage | 4,011 |  |  | 4,184 |  |  | 7,822 |  |  | 8,206 |  |
| Total ISG net revenue | 8,207 |  |  | 8,621 |  |  | 15,776 |  |  | 16,823 |  |
| Client Solutions Group: |  |  |  |  |  |  |  |
| Commercial | 8,039 |  |  | 9,077 |  |  | 16,673 |  |  | 17,384 |  |
| Consumer | 3,164 |  |  | 2,671 |  |  | 5,634 |  |  | 5,274 |  |
| Total CSG net revenue | 11,203 |  |  | 11,748 |  |  | 22,307 |  |  | 22,658 |  |
| VMware: |  |  |  |  |  |  |  |
| Total VMware net revenue | 2,908 |  |  | 2,651 |  |  | 5,663 |  |  | 5,108 |  |
| Total segment net revenue | $ | 22,318 |  |  | $ | 23,020 |  |  | $ | 43,746 |  |  | $ | 44,589 |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001571996-20-000045:notes:295]
[same as prior period, unchanged from 0001571996-20-000034:notes:288]

[0001571996-20-000045:notes:296]
[same as prior period, unchanged from 0001571996-20-000034:notes:289]

[0001571996-20-000045:notes:297]
|  | July 31, 2020 |  | January 31, 2020 |
|  | (in millions) |  |  |
| Cash, cash equivalents, and restricted cash: |  |  |  |
| Cash and cash equivalents | $ | 11,221 |  |  | $ | 9,302 |  |
| Restricted cash - other current assets (a) | 725 |  |  | 730 |  |
| Restricted cash - other non-current assets (a) | 107 |  |  | 119 |  |
| Total cash, cash equivalents, and restricted cash | $ | 12,053 |  |  | $ | 10,151 |  |
| Inventories, net: |  |  |  |
| Production materials | $ | 1,884 |  |  | $ | 1,590 |  |
| Work-in-process | 677 |  |  | 563 |  |
| Finished goods | 1,041 |  |  | 1,128 |  |
| Total inventories, net | $ | 3,602 |  |  | $ | 3,281 |  |
| Other non-current assets: |  |  |  |
| Deferred and other tax assets | $ | 6,131 |  |  | $ | 5,960 |  |
| Operating lease ROU assets | 1,787 |  |  | 1,780 |  |
| Deferred Commissions | 1,025 |  |  | 998 |  |
| Other | 1,704 |  |  | 1,690 |  |
| Total other non-current assets | $ | 10,647 |  |  | $ | 10,428 |  |
| Other non-current liabilities: |  |  |  |
| Deferred and other tax liabilities | $ | 2,010 |  |  | $ | 3,110 |  |
| Operating lease liabilities | 1,383 |  |  | 1,360 |  |
| Warranty liability | 140 |  |  | 155 |  |
| Other | 1,229 |  |  | 758 |  |
| Total other non-current liabilities | $ | 4,762 |  |  | $ | 5,383 |  |

[0001571996-20-000045:notes:298]
(a) Restricted cash primarily includes cash required to be held in escrow pursuant to DFS securitization arrangements and VMware, Inc. restricted cash.

[0001571996-20-000045:notes:299]
[same as prior period, unchanged from 0001571996-20-000034:notes:292]

[0001571996-20-000045:notes:300]
Allowance for expected credit losses of trade receivables as of July 31, 2020 includes the impact of adoption of the new CECL standard, which was adopted as of February 1, 2020 using the modified retrospective method, as described in Note 1 of the Notes to the Condensed Consolidated Financial Statements.  The provision recognized on the Condensed Consolidated Statements of Income (Loss) during the three and six months ended July 31, 2020 is based on an assessment of the impact of current and expected future conditions, inclusive of the effect of the COVID-19 pandemic on credit losses.  The duration and severity of COVID-19 and continued market volatility is highly uncertain and, as such, the impact on expected credit losses is subject to significant judgment and may cause variability in the Company’s allowance for credit losses in future periods.

[0001571996-20-000045:notes:301]
The following table presents the changes in the Company’s allowance for expected credit losses for the periods indicated:

[0001571996-20-000045:notes:302]
|  | Three Months Ended |  | Six Months Ended |
|  | July 31, 2020 |  | July 31, 2020 |
|  | (in millions) |  |  |
| Trade Receivables - Allowance for expected credit losses: |  |  |  |
| Balance at beginning of period | $ | 144 |  |  | $ | 94 |  |
| Adjustment for adoption of the new CECL standard (Note 1) | — |  |  | 27 |  |
| Provision charged to income statement | 11 |  |  | 47 |  |
| Bad debt write-offs | (9) |  |  | (22) |  |
| Balance at end of period | $ | 146 |  |  | $ | 146 |  |

[0001571996-20-000045:notes:303]
[same as prior period, unchanged from 0001571996-20-000034:notes:296]

[0001571996-20-000045:notes:304]
[same as prior period, unchanged from 0001571996-20-000034:notes:297]

[0001571996-20-000045:notes:305]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | July 31, 2020 |  | August 2, 2019 |  | July 31, 2020 |  | August 2, 2019 |
|  | (in millions) |  |  |  |  |  |  |
| Warranty liability: |  |  |  |  |  |  |  |
| Warranty liability at beginning of period | $ | 476 |  |  | $ | 500 |  |  | $ | 496 |  |  | $ | 524 |  |
| Costs accrued for new warranty contracts and changes in estimates for pre-existing warranties (a) (b) | 206 |  |  | 237 |  |  | 354 |  |  | 440 |  |
| Service obligations honored | (203) |  |  | (212) |  |  | (371) |  |  | (439) |  |
| Warranty liability at end of period | $ | 479 |  |  | $ | 525 |  |  | $ | 479 |  |  | $ | 525 |  |
| Current portion | $ | 339 |  |  | $ | 355 |  |  | $ | 339 |  |  | $ | 355 |  |
| Non-current portion | $ | 140 |  |  | $ | 170 |  |  | $ | 140 |  |  | $ | 170 |  |

[0001571996-20-000045:notes:306]
(a)Changes in cost estimates related to pre-existing warranties are aggregated with accruals for new standard warranty contracts.  The Company’s warranty liability process does not differentiate between estimates made for pre-existing warranties and new warranty obligations.

[0001571996-20-000045:notes:307]
(b)Includes the impact of foreign currency exchange rate fluctuations.


## us-gaap:SubsequentEventsTextBlock

[0001571996-20-000045:notes:308]
NOTE 19 — SUBSEQUENT EVENTS

[0001571996-20-000045:notes:309]
On September 1, 2020, the Company completed its divestiture of RSA Security to a consortium of investors in an all-cash transaction for approximately $2.082 billion.  For more information about this transaction, see Note 1 of the Notes to the Condensed Consolidated Financial Statements.

[0001571996-20-000045:notes:310]
Other than the matters identified above, there were no known events occurring after July 31, 2020 and up until the date of the issuance of this report that would materially affect the information presented herein.
