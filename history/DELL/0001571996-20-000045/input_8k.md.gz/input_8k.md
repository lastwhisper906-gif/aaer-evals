# DELL 8-K — 0001571996-20-000041 filed 2020-08-27

## item codes, every 8-K on or before 2020-09-04

- 2020-08-27 0001571996-20-000041 — 2.02, 9.01
- 2020-07-02 0001571996-20-000037 — 5.07
- 2020-05-28 0001571996-20-000028 — 2.02, 9.01
- 2020-04-09 0001193125-20-102602 — 1.01, 2.03, 9.01
- 2020-04-08 0001571996-20-000021 — 5.02
- 2020-04-03 0001571996-20-000019 — 8.01, 9.01
- 2020-03-26 0001571996-20-000015 — 7.01
- 2020-02-27 0001571996-20-000009 — 2.02, 8.01, 9.01
- 2020-02-18 0001571996-20-000005 — 8.01, 9.01
- 2020-01-09 0001571996-20-000002 — 3.02
- 2020-01-06 0001193125-20-002200 — 3.02
- 2019-12-13 0001193125-19-313947 — 3.02
- 2019-12-10 0001571996-19-000052 — 5.02
- 2019-12-02 0001571996-19-000044 — 5.02, 7.01, 9.01
- 2019-11-26 0001571996-19-000042 — 2.02, 9.01
- 2019-09-23 0001193125-19-252192 — 1.01, 2.03, 9.01
- 2019-08-29 0001571996-19-000036 — 2.02, 9.01
- 2019-08-22 0001193125-19-226939 — 7.01, 8.01, 9.01
- 2019-07-11 0001571996-19-000032 — 5.02, 5.07, 9.01
- 2019-07-03 0001571996-19-000030 — 3.02
- 2019-06-27 0001571996-19-000028 — 3.02
- 2019-05-30 0001571996-19-000021 — 2.02, 9.01
- 2019-04-02 0001571996-19-000010 — 5.02
- 2019-03-21 0001193125-19-082281 — 1.01, 1.02, 2.03, 9.01
- 2019-03-19 0001571996-19-000005 — 5.02, 9.01
- 2019-03-14 0001193125-19-074935 — 1.01, 2.03, 9.01
- 2019-03-07 0001193125-19-066045 — 8.01, 9.01
- 2019-02-28 0001571996-19-000002 — 2.02, 9.01
- 2018-12-28 0001193125-18-360943 — 1.01, 1.02, 3.01, 3.03, 5.02, 5.03, 7.01, 8.01, 9.01
- 2018-12-21 0001193125-18-356324 — 1.01, 2.03, 9.01
- 2018-12-14 0001193125-18-349469 — 8.01
- 2018-12-11 0001193125-18-346958 — 5.07, 8.01, 9.01
- 2018-11-29 0001571996-18-000041 — 2.02, 9.01
- 2018-11-28 0001571996-18-000037 — 7.01, 8.01, 9.01
- 2018-11-26 0001193125-18-333967 — 8.01, 9.01
- 2018-11-15 0001193125-18-328110 — 1.01, 9.01 — amendment of 0001193125-18-327222
- 2018-11-15 0001193125-18-327222 — 1.01, 7.01, 9.01
- 2018-10-03 0001193125-18-291390 — 8.01
- 2018-09-06 0001571996-18-000029 — 2.02, 9.01
- 2018-08-06 0001571996-18-000027 — 8.01, 9.01
- 2018-07-02 0001193125-18-210339 — 1.01, 7.01, 9.01
- 2018-06-28 0001571996-18-000024 — 5.07
- 2018-06-04 0001571996-18-000019 — 2.02, 9.01
- 2018-05-17 0001571996-18-000016 — 7.01
- 2018-04-26 0001571996-18-000009 — 7.01, 9.01
- 2018-03-08 0001193125-18-074168 — 2.02, 9.01
- 2018-02-02 0001193125-18-029947 — 7.01, 9.01
- 2017-12-07 0001571996-17-000042 — 2.02, 9.01
- 2017-10-24 0001571996-17-000037 — 1.01, 2.03, 9.01
- 2017-09-15 0001571996-17-000027 — 5.02
- 2017-09-07 0001571996-17-000017 — 2.02, 9.01
- 2017-08-24 0001571996-17-000014 — 8.01
- 2017-06-29 0001571996-17-000011 — 3.03, 5.07, 8.01, 9.01
- 2017-06-08 0001193125-17-197638 — 2.02, 9.01
- 2017-03-30 0001193125-17-102794 — 8.01
- 2017-03-30 0001193125-17-102777 — 2.02, 9.01
- 2017-03-09 0001193125-17-076981 — 1.01, 2.03, 9.01
- 2017-01-17 0001193125-17-011125 — 8.01
- 2016-12-15 0001193125-16-793722 — 8.01
- 2016-12-08 0001193125-16-787976 — 2.02, 9.01
- 2016-11-10 0001193125-16-765964 — 1.02, 8.01
- 2016-11-04 0001193125-16-760249 — 8.01
- 2016-09-13 0001193125-16-708600 — 3.02
- 2016-09-09 0001193125-16-706567 — 1.01, 1.02, 2.01, 2.03, 3.02, 3.03, 5.02, 9.01
- 2016-09-07 0001193125-16-703370 — 3.03, 5.07, 7.01, 8.01, 9.01
- 2016-09-06 0001193125-16-702057 — 2.02, 9.01
- 2016-08-31 0001193125-16-697268 — 8.01, 9.01
- 2016-08-26 0001193125-16-692921 — 8.01, 9.01
- 2016-07-11 0001193125-16-645610 — 8.01
- 2016-07-05 0001193125-16-641679 — 8.01
- 2016-06-22 0001193125-16-629055 — 1.01, 2.03, 8.01, 9.01
- 2016-06-21 0001193125-16-627071 — 8.01, 9.01
- 2016-06-10 0001193125-16-618483 — 2.02, 9.01
- 2016-06-09 0001193125-16-617893 — 8.01, 9.01

## late-filing notifications on or before 2020-09-04

- none on or before 2020-09-04

## item 2.02 — earnings release, exhibit 99.1

[0001571996-20-000041:8k_2_02:1]
EX-99.1
2
exhibit991earnings8kq2.htm
EX-99.1

[0001571996-20-000041:8k_2_02:2]
Document

[0001571996-20-000041:8k_2_02:3]
Exhibit 99.1

[0001571996-20-000041:8k_2_02:4]
News Release

[0001571996-20-000041:8k_2_02:5]
Future-of-Work Solutions Power Dell Technologies’

[0001571996-20-000041:8k_2_02:6]
Second Quarter Fiscal 2021 Financial Results

[0001571996-20-000041:8k_2_02:7]
ROUND ROCK, Texas — August 27, 2020

[0001571996-20-000041:8k_2_02:8]
News summary

[0001571996-20-000041:8k_2_02:9]
•Second quarter revenue of $22.7 billion, non-GAAP revenue of $22.8 billion

[0001571996-20-000041:8k_2_02:10]
•Operating income up 119% to $1.1 billion, non-GAAP operating income of $2.6 billion

[0001571996-20-000041:8k_2_02:11]
•Dell Technologies continues to effectively navigate COVID-19 environment, providing the essential work- and learn-from-home, cloud and storage solutions customers need

[0001571996-20-000041:8k_2_02:12]
Full story

[0001571996-20-000041:8k_2_02:13]
Dell Technologies (NYSE: DELL) announces financial results for its fiscal 2021 second quarter. Second quarter revenue was $22.7 billion, and non-GAAP revenue was $22.8 billion. During the quarter, the company generated operating income of $1.1 billion, a 119 percent increase over the same period in the prior year, and non-GAAP operating income of $2.6 billion. Net income was $1.1 billion, non-GAAP net income was $1.6 billion and adjusted EBITDA was $3.1 billion. Net cash from operating activities was $3.3 billion. Diluted earnings per share was $1.37 and non-GAAP diluted earnings per share was $1.92.

[0001571996-20-000041:8k_2_02:14]
“We provide the technology solutions customers need to be productive and collaborative no matter where they work or learn, while delivering the data-driven insights and automation they need to innovate and transform,” said Jeff Clarke, vice chairman and chief operating officer, Dell Technologies. “In Q2, we saw strength in the government sector and in education, with orders up 16 and 24 percent, respectively, as parents, teachers and school districts prepare for a new frontier in virtual learning.”

[0001571996-20-000041:8k_2_02:15]
1

[0001571996-20-000041:8k_2_02:16]
Second Quarter Fiscal 2021 Financial Results

[0001571996-20-000041:8k_2_02:17]
|  | Three Months Ended |  |  |  |  |  | Six Months Ended |  |  |  |  |
|  | July 31, 2020 |  | August 2, 2019 |  | Change |  | July 31, 2020 |  | August 2, 2019 |  | Change |
|  | (in millions, except per share amounts and percentages; unaudited) |  |  |  |  |  |  |  |  |  |  |
| Total net revenue | $ | 22,733 |  |  | $ | 23,370 |  |  | (3)% |  | $ | 44,630 |  |  | $ | 45,278 |  |  | (1)% |
| Operating income | $ | 1,136 |  |  | $ | 519 |  |  | 119% |  | $ | 1,838 |  |  | $ | 1,069 |  |  | 72% |
| Net income | $ | 1,099 |  |  | $ | 4,232 |  |  | (74)% |  | $ | 1,281 |  |  | $ | 4,561 |  |  | (72)% |
| Earnings per share - diluted | $ | 1.37 |  |  | $ | 4.47 |  |  | (69)% |  | $ | 1.56 |  |  | $ | 4.84 |  |  | (68)% |
| Non-GAAP net revenue | $ | 22,775 |  |  | $ | 23,454 |  |  | (3)% |  | $ | 44,720 |  |  | $ | 45,444 |  |  | (2)% |
| Non-GAAP operating income | $ | 2,618 |  |  | $ | 2,743 |  |  | (5)% |  | $ | 4,779 |  |  | $ | 4,939 |  |  | (3)% |
| Non-GAAP net income | $ | 1,621 |  |  | $ | 1,751 |  |  | (7)% |  | $ | 2,764 |  |  | $ | 2,960 |  |  | (7)% |
| Adjusted EBITDA | $ | 3,100 |  |  | $ | 3,156 |  |  | (2)% |  | $ | 5,707 |  |  | $ | 5,729 |  |  | —% |
| Non-GAAP earnings per share - diluted | $ | 1.92 |  |  | $ | 2.15 |  |  | (11)% |  | $ | 3.26 |  |  | $ | 3.60 |  |  | (9)% |

[0001571996-20-000041:8k_2_02:18]
Information about Dell Technologies’ use of non-GAAP financial information is provided under “Non-GAAP Financial Measures” below.  All comparisons in this press release are year-over-year unless otherwise noted.

[0001571996-20-000041:8k_2_02:19]
Dell Technologies ended the quarter with cash and investments of $12.3 billion and paid down $3.5 billion in debt during the quarter. The company had total deferred revenue of $28.8 billion during the quarter, up 14 percent year-over-year. Recurring revenue, which includes deferred revenue amortization, utility, and as-a-Service delivered as part of Dell Technologies on Demand, was approximately $6 billion for the quarter, up 15 percent year-over-year.

[0001571996-20-000041:8k_2_02:20]
“Now more than ever, customers need flexibility. We’re seeing increased adoption of our portfolio delivered as-a-service through flexible consumption solutions, which are now on a $1.3 billion revenue run-rate, up 30 percent year-over-year,” said Tom Sweet, chief financial officer, Dell Technologies. “As needs of the market shift, we continue to execute on our strategy of winning in the consolidating markets in which we compete and investing in long-term drivers of value creation for Dell Technologies and our stakeholders.”

[0001571996-20-000041:8k_2_02:21]
Operating segments summary

[0001571996-20-000041:8k_2_02:22]
Client Solutions Group revenue for the second quarter was $11.2 billion. Operating income was $715 million, or 6.4 percent of Client Solutions Group revenue. The company saw continued demand for remote work and learning solutions. Consumer revenue was $3.2 billion, up 18 percent, while commercial client revenue was $8.0 billion, down 11 percent.

[0001571996-20-000041:8k_2_02:23]
Key highlights:

[0001571996-20-000041:8k_2_02:24]
•Strong performance driven by double-digit revenue growth across notebooks and consumer client

[0001571996-20-000041:8k_2_02:25]
•Strength in the XPS premium line and gaming systems including Alienware, with combined orders growth of 25 percent

[0001571996-20-000041:8k_2_02:26]
•The launch of new intelligent Latitude PCs, the world’s most intelligent PC with built-in AI and 5G connectivity, and a reengineered industry-leading Precision workstation portfolio

[0001571996-20-000041:8k_2_02:27]
2

[0001571996-20-000041:8k_2_02:28]
Infrastructure Solutions Group revenue for the second quarter was $8.2 billion, with customers continuing to direct more spending towards remote work and business continuity solutions. Storage revenue was $4.0 billion, while servers and networking revenue was $4.2 billion. Operating income was $973 million for the second quarter, or approximately 11.9 percent of Infrastructure Solutions Group revenue.

[0001571996-20-000041:8k_2_02:29]
Key highlights:

[0001571996-20-000041:8k_2_02:30]
•Continued strong demand for VxRail, with double-digit orders growth for the second straight quarter. Triple-digit orders growth for high-end PowerMax solution and double-digit orders growth in Data Protection

[0001571996-20-000041:8k_2_02:31]
•The announcement of two new VxRail systems—including the first ruggedized VxRail model and introduction of AMD EPYC processors—bringing the power and simplicity of HCI to the most challenging and space-constrained edge environments

[0001571996-20-000041:8k_2_02:32]
•Announced Dell EMC PowerScale, storage systems that help customers capture and capitalize on unstructured data, such as documents, images, videos and social media content in core data centers, edge locations and public cloud

[0001571996-20-000041:8k_2_02:33]
VMware revenue was $2.9 billion for the second quarter, up 10 percent driven by broad-based strength across a diverse product portfolio. Operating income for the quarter was $894 million, or 30.7 percent of VMware revenue.

[0001571996-20-000041:8k_2_02:34]
Conference call information

[0001571996-20-000041:8k_2_02:35]
As previously announced, the Company will hold a conference call to discuss its second quarter performance today, August 27, 2020 at 4:30 p.m. CDT. The conference call will be broadcast live over the internet and can be accessed at https://investors.delltechnologies.com/events-and-presentations/upcoming-events

[0001571996-20-000041:8k_2_02:36]
For those unable to listen to the live broadcast, an archived version will be available at the same location for one year.

[0001571996-20-000041:8k_2_02:37]
Additional financial and operating information may be downloaded from

[0001571996-20-000041:8k_2_02:38]
https://investors.delltechnologies.com/financial-information/quarterly-results

[0001571996-20-000041:8k_2_02:39]
About Dell Technologies

[0001571996-20-000041:8k_2_02:40]
Dell Technologies (NYSE:DELL) helps organizations and individuals build their digital future and transform how they work, live and play.  The company provides customers with the industry’s broadest and most innovative technology and services portfolio for the data era.

[0001571996-20-000041:8k_2_02:41]
Contacts

[0001571996-20-000041:8k_2_02:42]
Investors: Investor_Relations@Dell.com

[0001571996-20-000041:8k_2_02:43]
Media: Media.Relations@Dell.com

[0001571996-20-000041:8k_2_02:44]
# # #

[0001571996-20-000041:8k_2_02:45]
Copyright © 2020 Dell Inc. or its subsidiaries. All Rights Reserved. Dell Technologies, Dell, EMC and Dell EMC are trademarks of Dell Inc. or its subsidiaries. Other trademarks may be trademarks of their respective owners.

[0001571996-20-000041:8k_2_02:46]
3

[0001571996-20-000041:8k_2_02:47]
Non-GAAP Financial Measures:

[0001571996-20-000041:8k_2_02:48]
This press release presents information about Dell Technologies’ non-GAAP net revenue, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, non-GAAP net income attributable to non-controlling interests, non-GAAP net income attributable to Dell Technologies Inc. - basic, non-GAAP net income attributable to Dell Technologies Inc. - diluted, non-GAAP earnings per share attributable to Dell Technologies Inc. - basic, non-GAAP earnings per share attributable to Dell Technologies Inc. - diluted, EBITDA, and adjusted EBITDA, which are non-GAAP financial measures provided as a supplement to the results provided in accordance with generally accepted accounting principles in the United States of America (“GAAP”). A reconciliation of each non-GAAP financial measure to the most directly comparable GAAP financial measure is provided in the attached tables for each of the fiscal periods indicated.

[0001571996-20-000041:8k_2_02:49]
Special Note on Forward-Looking Statements:

[0001571996-20-000041:8k_2_02:50]
Dell Technologies’ results or events in future periods could differ materially from those expressed or implied by these forward-looking statements because of risks, uncertainties, and other factors that include, but are not limited to, the following: competitive pressures; Dell Technologies’ reliance on third-party suppliers for products and components, including reliance on single-source or limited-source suppliers; Dell Technologies’ ability to achieve favorable pricing from its vendors; adverse global economic conditions and instability in financial markets, including as a result of the COVID-19 pandemic; Dell Technologies’ execution of its growth, business and acquisition strategies; the success of Dell Technologies’ cost efficiency measures; Dell Technologies’ ability to manage solutions and products and services transitions in an effective manner; Dell Technologies’ ability to deliver high-quality products and services; Dell Technologies’ foreign operations and ability to generate substantial non-U.S. net revenue; Dell Technologies’ product, customer, and geographic sales mix, and seasonal sales trends; the performance of Dell Technologies’ sales channel partners; access to the capital markets by Dell Technologies or its customers; weak economic conditions and additional regulation including tariffs and other effects of trade regulation; counterparty default risks; effects of customer defaults or the exercise of customer rights on the ability of Dell Technologies to produce revenue under its contracts for services and solutions at expected levels and to perform such contracts at estimated costs; the loss by Dell Technologies of government contracts; Dell Technologies’ ability to develop and protect its proprietary intellectual property or obtain licenses to intellectual property developed by others on commercially reasonable and competitive terms; infrastructure disruptions, cyberattacks, or other data security breaches; Dell Technologies’ ability to hedge effectively its exposure to fluctuations in foreign currency exchange rates and interest rates; expiration of tax holidays or favorable tax rate structures, or unfavorable outcomes in tax audits and other tax compliance matters; impairment of portfolio investments; unfavorable results of legal proceedings; Dell Technologies’ ability to develop and maintain effective internal control over financial reporting; compliance requirements of changing environmental and safety laws; the effect of armed hostilities, terrorism, natural disasters, climate change, and public health issues, including those relating to the COVID-19 pandemic; Dell Technologies’ substantial level of indebtedness; the impact of the financial performance of VMware, Inc.; and the market volatility of Dell Technologies’ pension plan assets.

[0001571996-20-000041:8k_2_02:51]
This list of risks, uncertainties, and other factors is not complete. Dell Technologies discusses some of these matters more fully, as well as certain risk factors that could affect Dell Technologies’ business, financial condition, results of operations, and prospects, in its reports filed with the SEC, including Dell Technologies’ annual report on Form 10-K for the fiscal year ended January 31, 2020, quarterly reports on Form 10-Q, and current reports on Form 8-K. These filings are available for review through the SEC’s website at www.sec.gov. Any or all forward-looking statements Dell Technologies makes may turn out to be wrong and can be affected by inaccurate assumptions Dell Technologies might make or by known or unknown risks, uncertainties and other factors, including those identified in this press release. Accordingly, you should not place undue reliance on the forward-looking statements made in this press release, which speak only as of the date such statements are made. Dell Technologies does not undertake to update any forward-looking statement after the date as of which such statement was made, whether to reflect changes in circumstances or Dell Technologies’ expectations, the occurrence of unanticipated events, or otherwise.

[0001571996-20-000041:8k_2_02:52]
4

[0001571996-20-000041:8k_2_02:53]
DELL TECHNOLOGIES INC.

[0001571996-20-000041:8k_2_02:54]
Condensed Consolidated Statements of Income (Loss) and Related Financial Highlights

[0001571996-20-000041:8k_2_02:55]
(in millions, except percentages; unaudited)

[0001571996-20-000041:8k_2_02:56]
|  | Three Months Ended |  |  |  |  |  | Six Months Ended |  |  |  |  |
|  | July 31, 2020 |  | August 2, 2019 |  | Change |  | July 31, 2020 |  | August 2, 2019 |  | Change |
| Net revenue (a): |  |  |  |  |  |  |  |  |  |  |  |
| Products | $ | 16,737 |  |  | $ | 17,915 |  |  | (7)% |  | $ | 32,775 |  |  | $ | 34,490 |  |  | (5)% |
| Services | 5,996 |  |  | 5,455 |  |  | 10% |  | 11,855 |  |  | 10,788 |  |  | 10% |
| Total net revenue | 22,733 |  |  | 23,370 |  |  | (3)% |  | 44,630 |  |  | 45,278 |  |  | (1)% |
| Cost of net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Products | 13,330 |  |  | 13,889 |  |  | (4)% |  | 26,134 |  |  | 26,968 |  |  | (3)% |
| Services | 2,247 |  |  | 2,155 |  |  | 4% |  | 4,487 |  |  | 4,187 |  |  | 7% |
| Total cost of net revenue | 15,577 |  |  | 16,044 |  |  | (3)% |  | 30,621 |  |  | 31,155 |  |  | (2)% |
| Gross margin | 7,156 |  |  | 7,326 |  |  | (2)% |  | 14,009 |  |  | 14,123 |  |  | (1)% |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative | 4,761 |  |  | 5,578 |  |  | (15)% |  | 9,647 |  |  | 10,649 |  |  | (9)% |
| Research and development | 1,259 |  |  | 1,229 |  |  | 2% |  | 2,524 |  |  | 2,405 |  |  | 5% |
| Total operating expenses | 6,020 |  |  | 6,807 |  |  | (12)% |  | 12,171 |  |  | 13,054 |  |  | (7)% |
| Operating income | 1,136 |  |  | 519 |  |  | 119% |  | 1,838 |  |  | 1,069 |  |  | 72% |
| Interest and other, net | (636) |  |  | (630) |  |  | (1)% |  | (1,202) |  |  | (1,323) |  |  | 9% |
| Income (loss) before income taxes | 500 |  |  | (111) |  |  | 550% |  | 636 |  |  | (254) |  |  | 350% |
| Income tax benefit | (599) |  |  | (4,343) |  |  | 86% |  | (645) |  |  | (4,815) |  |  | 87% |
| Net income | 1,099 |  |  | 4,232 |  |  | (74)% |  | 1,281 |  |  | 4,561 |  |  | (72)% |
| Less: Net income attributable to non-controlling interests | 51 |  |  | 816 |  |  | (94)% |  | 90 |  |  | 852 |  |  | (89)% |
| Net income attributable to Dell Technologies Inc. | $ | 1,048 |  |  | $ | 3,416 |  |  | (69)% |  | $ | 1,191 |  |  | $ | 3,709 |  |  | (68)% |
| Percentage of Total Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Gross margin | 31 | % |  | 31 | % |  |  |  | 31 | % |  | 31 | % |  |  |
| Selling, general, and administrative | 21 | % |  | 24 | % |  |  |  | 22 | % |  | 24 | % |  |  |
| Research and development | 6 | % |  | 5 | % |  |  |  | 6 | % |  | 5 | % |  |  |
| Operating expenses | 26 | % |  | 29 | % |  |  |  | 27 | % |  | 29 | % |  |  |
| Operating income | 5 | % |  | 2 | % |  |  |  | 4 | % |  | 2 | % |  |  |
| Income (loss) before income taxes | 2 | % |  | — | % |  |  |  | 1 | % |  | (1) | % |  |  |
| Net income | 5 | % |  | 18 | % |  |  |  | 3 | % |  | 10 | % |  |  |
| Income tax rate | -119.8 | % |  | 3912.6 | % |  |  |  | -101.4 | % |  | 1895.7 | % |  |  |

[0001571996-20-000041:8k_2_02:57]
____________________

[0001571996-20-000041:8k_2_02:58]
(a) During Fiscal 2020, the Company reclassified revenue associated with certain service and software-as-a-service offerings from product revenue to services revenue. There was no change to total revenue as a result of the reclassifications. Prior period results have been recast to conform with current period presentation.

[0001571996-20-000041:8k_2_02:59]
5

[0001571996-20-000041:8k_2_02:60]
DELL TECHNOLOGIES INC.

[0001571996-20-000041:8k_2_02:61]
Consolidated Statements of Financial Position

[0001571996-20-000041:8k_2_02:62]
(in millions; unaudited)

[0001571996-20-000041:8k_2_02:63]
|  | July 31, 2020 |  | January 31, 2020 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 11,221 |  |  | $ | 9,302 |  |
| Accounts receivable, net | 11,643 |  |  | 12,484 |  |
| Short-term financing receivables, net | 4,855 |  |  | 4,895 |  |
| Inventories, net | 3,602 |  |  | 3,281 |  |
| Other current assets | 7,711 |  |  | 6,906 |  |
| Current assets held for sale | 2,058 |  |  | — |  |
| Total current assets | 41,090 |  |  | 36,868 |  |
| Property, plant, and equipment, net | 6,380 |  |  | 6,055 |  |
| Long-term investments | 1,073 |  |  | 864 |  |
| Long-term financing receivables, net | 5,378 |  |  | 4,848 |  |
| Goodwill | 40,644 |  |  | 41,691 |  |
| Intangible assets, net | 16,064 |  |  | 18,107 |  |
| Other non-current assets | 10,647 |  |  | 10,428 |  |
| Total assets | $ | 121,276 |  |  | $ | 118,861 |  |
| LIABILITIES, REDEEMABLE SHARES, AND STOCKHOLDERS’ EQUITY (DEFICIT) |  |  |  |
| Current liabilities: |  |  |  |
| Short-term debt | $ | 10,345 |  |  | $ | 7,737 |  |
| Accounts payable | 19,500 |  |  | 20,065 |  |
| Accrued and other | 8,758 |  |  | 9,773 |  |
| Short-term deferred revenue | 15,341 |  |  | 14,881 |  |
| Current liabilities held for sale | 344 |  |  | — |  |
| Total current liabilities | 54,288 |  |  | 52,456 |  |
| Long-term debt | 43,608 |  |  | 44,319 |  |
| Long-term deferred revenue | 13,450 |  |  | 12,919 |  |
| Other non-current liabilities | 4,762 |  |  | 5,383 |  |
| Total liabilities | 116,108 |  |  | 115,077 |  |
| Redeemable shares | 610 |  |  | 629 |  |
| Stockholders’ equity (deficit): |  |  |  |
| Total Dell Technologies Inc. stockholders’ deficit | (419) |  |  | (1,574) |  |
| Non-controlling interests | 4,977 |  |  | 4,729 |  |
| Total stockholders’ equity (deficit) | 4,558 |  |  | 3,155 |  |
| Total liabilities, redeemable shares, and stockholders’ equity (deficit) | $ | 121,276 |  |  | $ | 118,861 |  |

[0001571996-20-000041:8k_2_02:64]
6

[0001571996-20-000041:8k_2_02:65]
DELL TECHNOLOGIES INC.

[0001571996-20-000041:8k_2_02:66]
Condensed Consolidated Statements of Cash Flows

[0001571996-20-000041:8k_2_02:67]
(in millions; unaudited)

[0001571996-20-000041:8k_2_02:68]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | July 31, 2020 |  | August 2, 2019 |  | July 31, 2020 |  | August 2, 2019 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |
| Net income | $ | 1,099 |  |  | $ | 4,232 |  |  | $ | 1,281 |  |  | $ | 4,561 |  |
| Adjustments to reconcile net income to net cash provided by (used in) operating activities: | 2,233 |  |  | (952) |  |  | 1,255 |  |  | (599) |  |
| Change in cash from operating activities | 3,332 |  |  | 3,280 |  |  | 2,536 |  |  | 3,962 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |
| Purchases of investments | (118) |  |  | (32) |  |  | (174) |  |  | (70) |  |
| Maturities and sales of investments | 32 |  |  | 93 |  |  | 71 |  |  | 430 |  |
| Capital expenditures and capitalized software development costs | (545) |  |  | (551) |  |  | (1,104) |  |  | (1,267) |  |
| Acquisition of businesses and assets, net | (296) |  |  | (339) |  |  | (334) |  |  | (384) |  |
| Divestitures of businesses and assets, net | — |  |  | — |  |  | 120 |  |  | (3) |  |
| Other | 3 |  |  | 4 |  |  | 12 |  |  | 11 |  |
| Change in cash from investing activities | (924) |  |  | (825) |  |  | (1,409) |  |  | (1,283) |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |
| Proceeds from the issuance of common stock | 105 |  |  | 105 |  |  | 221 |  |  | 239 |  |
| Repurchases of parent common stock | — |  |  | 2 |  |  | (240) |  |  | (4) |  |
| Repurchases of subsidiary common stock | (291) |  |  | (600) |  |  | (591) |  |  | (1,403) |  |
| Proceeds from debt | 1,712 |  |  | 2,638 |  |  | 11,847 |  |  | 12,201 |  |
| Repayments of debt | (4,815) |  |  | (4,342) |  |  | (10,220) |  |  | (13,911) |  |
| Other | (148) |  |  | (6) |  |  | (190) |  |  | (44) |  |
| Change in cash from financing activities | (3,437) |  |  | (2,203) |  |  | 827 |  |  | (2,922) |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash | 84 |  |  | (26) |  |  | (52) |  |  | (62) |  |
| Change in cash, cash equivalents, and restricted cash | (945) |  |  | 226 |  |  | 1,902 |  |  | (305) |  |
| Cash, cash equivalents, and restricted cash at beginning of the period | 12,998 |  |  | 9,709 |  |  | 10,151 |  |  | 10,240 |  |
| Cash, cash equivalents, and restricted cash at end of the period | $ | 12,053 |  |  | $ | 9,935 |  |  | $ | 12,053 |  |  | $ | 9,935 |  |

[0001571996-20-000041:8k_2_02:69]
7

[0001571996-20-000041:8k_2_02:70]
DELL TECHNOLOGIES INC.

[0001571996-20-000041:8k_2_02:71]
Segment Information

[0001571996-20-000041:8k_2_02:72]
(in millions, except percentages; unaudited; continued on next page)

[0001571996-20-000041:8k_2_02:73]
|  | Three Months Ended |  |  |  |  |  | Six Months Ended |  |  |  |  |
|  | July 31, 2020 |  | August 2, 2019 |  | Change |  | July 31, 2020 |  | August 2, 2019 |  | Change |
| Infrastructure Solutions Group (ISG): |  |  |  |  |  |  |  |  |  |  |  |
| Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Servers and networking | $ | 4,196 |  |  | $ | 4,437 |  |  | (5)% |  | $ | 7,954 |  |  | $ | 8,617 |  |  | (8)% |
| Storage | 4,011 |  |  | 4,184 |  |  | (4)% |  | 7,822 |  |  | 8,206 |  |  | (5)% |
| Total ISG net revenue | $ | 8,207 |  |  | $ | 8,621 |  |  | (5)% |  | $ | 15,776 |  |  | $ | 16,823 |  |  | (6)% |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| ISG operating income | $ | 973 |  |  | $ | 1,050 |  |  | (7)% |  | $ | 1,705 |  |  | $ | 1,893 |  |  | (10)% |
| % of ISG net revenue | 12 | % |  | 12 | % |  |  |  | 11 | % |  | 11 | % |  |  |
| % of total reportable segment operating income | 38 | % |  | 38 | % |  |  |  | 36 | % |  | 38 | % |  |  |
| Client Solutions Group (CSG): |  |  |  |  |  |  |  |  |  |  |  |
| Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 8,039 |  |  | $ | 9,077 |  |  | (11)% |  | $ | 16,673 |  |  | $ | 17,384 |  |  | (4)% |
| Consumer | 3,164 |  |  | 2,671 |  |  | 18% |  | 5,634 |  |  | 5,274 |  |  | 7% |
| Total CSG net revenue | $ | 11,203 |  |  | $ | 11,748 |  |  | (5)% |  | $ | 22,307 |  |  | $ | 22,658 |  |  | (2)% |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| CSG operating income | $ | 715 |  |  | $ | 982 |  |  | (27)% |  | $ | 1,307 |  |  | $ | 1,775 |  |  | (26)% |
| % of CSG net revenue | 6 | % |  | 8 | % |  |  |  | 6 | % |  | 8 | % |  |  |
| % of total reportable segment operating income | 28 | % |  | 35 | % |  |  |  | 28 | % |  | 35 | % |  |  |
| VMware (a): |  |  |  |  |  |  |  |  |  |  |  |
| Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Total VMware net revenue | $ | 2,908 |  |  | $ | 2,651 |  |  | 10% |  | $ | 5,663 |  |  | $ | 5,108 |  |  | 11% |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| VMware operating income | $ | 894 |  |  | $ | 751 |  |  | 19% |  | $ | 1,667 |  |  | $ | 1,346 |  |  | 24% |
| % of VMware net revenue | 31 | % |  | 28 | % |  |  |  | 29 | % |  | 26 | % |  |  |
| % of total reportable segment operating income | 35 | % |  | 27 | % |  |  |  | 36 | % |  | 27 | % |  |  |

[0001571996-20-000041:8k_2_02:74]
____________________

[0001571996-20-000041:8k_2_02:75]
(a) During Fiscal 2020, the Company reclassified Pivotal operating results from Other businesses to the VMware reportable segment. There was no change to consolidated results as a result of the reclassification. Prior period results have been recast to conform with current period presentation.

[0001571996-20-000041:8k_2_02:76]
8

[0001571996-20-000041:8k_2_02:77]
DELL TECHNOLOGIES INC.

[0001571996-20-000041:8k_2_02:78]
Segment Information

[0001571996-20-000041:8k_2_02:79]
(in millions, except percentages; unaudited; continued)

[0001571996-20-000041:8k_2_02:80]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | July 31, 2020 |  | August 2, 2019 |  | July 31, 2020 |  | August 2, 2019 |
| Reconciliation to consolidated net revenue: |  |  |  |  |  |  |  |
| Reportable segment net revenue (a) | $ | 22,318 |  |  | $ | 23,020 |  |  | $ | 43,746 |  |  | $ | 44,589 |  |
| Other businesses (a) (b) | 457 |  |  | 434 |  |  | 974 |  |  | 855 |  |
| Impact of purchase accounting (d) | (42) |  |  | (84) |  |  | (90) |  |  | (166) |  |
| Total consolidated net revenue | $ | 22,733 |  |  | $ | 23,370 |  |  | $ | 44,630 |  |  | $ | 45,278 |  |
| Reconciliation to consolidated operating income: |  |  |  |  |  |  |  |
| Reportable segment operating income (a) | $ | 2,582 |  |  | $ | 2,783 |  |  | $ | 4,679 |  |  | $ | 5,014 |  |
| Other businesses (a) (b) | 37 |  |  | (14) |  |  | 102 |  |  | (48) |  |
| Unallocated transactions (c) | (1) |  |  | (26) |  |  | (2) |  |  | (27) |  |
| Impact of purchase accounting (d) | (53) |  |  | (102) |  |  | (116) |  |  | (203) |  |
| Amortization of intangibles | (847) |  |  | (1,060) |  |  | (1,702) |  |  | (2,277) |  |
| Transaction-related expenses (e) | (83) |  |  | (47) |  |  | (159) |  |  | (89) |  |
| Stock-based compensation expense (f) | (413) |  |  | (301) |  |  | (783) |  |  | (564) |  |
| Other corporate expenses (g) | (86) |  |  | (714) |  |  | (181) |  |  | (737) |  |
| Total consolidated operating income | $ | 1,136 |  |  | $ | 519 |  |  | $ | 1,838 |  |  | $ | 1,069 |  |

[0001571996-20-000041:8k_2_02:81]
_________________

[0001571996-20-000041:8k_2_02:82]
(a)During Fiscal 2020, the Company reclassified Pivotal operating results from Other businesses to the VMware reportable segment. Prior period results have been recast to conform with current period presentation.

[0001571996-20-000041:8k_2_02:83]
(b)Secureworks, RSA Security, Virtustream, and Boomi constitute “Other businesses” and do not meet the requirements for a reportable segment, either individually or collectively. The results of Other businesses are not material to the Company’s overall results.

[0001571996-20-000041:8k_2_02:84]
(c)Unallocated transactions includes other corporate items that are not allocated to Dell Technologies’ reportable segments.

[0001571996-20-000041:8k_2_02:85]
(d)Impact of purchase accounting includes non-cash purchase accounting adjustments that are primarily related to the EMC merger transaction.

[0001571996-20-000041:8k_2_02:86]
(e)Transaction-related expenses includes acquisition, integration, and divestiture related costs.

[0001571996-20-000041:8k_2_02:87]
(f)Stock-based compensation expense consists of equity awards granted based on the estimated fair value of those awards at grant date.

[0001571996-20-000041:8k_2_02:88]
(g)Other corporate expenses includes impairment charges, severance, facility action, and other costs.

[0001571996-20-000041:8k_2_02:89]
SUPPLEMENTAL SELECTED NON-GAAP FINANCIAL MEASURES

[0001571996-20-000041:8k_2_02:90]
These tables present information about the Company’s non-GAAP net revenue, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, non-GAAP net income attributable to non-controlling interests, non-GAAP net income attributable to Dell Technologies Inc. - basic, non-GAAP net income attributable to Dell Technologies Inc. - diluted, non-GAAP earnings per share attributable to Dell Technologies Inc. - basic, non-GAAP earnings per share attributable to Dell Technologies Inc. - diluted, EBITDA, and adjusted EBITDA, which are non-GAAP financial measures provided as a supplement to the results provided in accordance with generally accepted accounting principles in the United States of America (“GAAP”). A detailed discussion of Dell Technologies’ reasons for including these non-GAAP financial measures, the limitations associated with these measures, the items excluded from these measures, and our reason for excluding those items are presented in “Management’s Discussion and Analysis of Financial Condition and Results of Operations — Non-GAAP Financial Measures” in our periodic reports filed with the SEC. Dell Technologies encourages investors to review the non-GAAP discussion in these reports in conjunction with the presentation of non-GAAP financial measures.

[0001571996-20-000041:8k_2_02:91]
10

[0001571996-20-000041:8k_2_02:92]
DELL TECHNOLOGIES INC.

[0001571996-20-000041:8k_2_02:93]
Selected Non-GAAP Financial Measures

[0001571996-20-000041:8k_2_02:94]
(in millions, except per share amounts and percentages; unaudited)

[0001571996-20-000041:8k_2_02:95]
|  | Three Months Ended |  |  |  |  |  | Six Months Ended |  |  |  |  |
|  | July 31, 2020 |  | August 2, 2019 |  | Change |  | July 31, 2020 |  | August 2, 2019 |  | Change |
| Non-GAAP net revenue | $ | 22,775 |  |  | $ | 23,454 |  |  | (3)% |  | $ | 44,720 |  |  | $ | 45,444 |  |  | (2)% |
| Non-GAAP gross margin | $ | 7,626 |  |  | $ | 7,986 |  |  | (5)% |  | $ | 14,951 |  |  | $ | 15,420 |  |  | (3)% |
| % of non-GAAP net revenue | 33 | % |  | 34 | % |  |  |  | 33 | % |  | 34 | % |  |  |
| Non-GAAP operating expenses | $ | 5,008 |  |  | $ | 5,243 |  |  | (4)% |  | $ | 10,172 |  |  | $ | 10,481 |  |  | (3)% |
| % of non-GAAP net revenue | 22 | % |  | 22 | % |  |  |  | 23 | % |  | 23 | % |  |  |
| Non-GAAP operating income | $ | 2,618 |  |  | $ | 2,743 |  |  | (5)% |  | $ | 4,779 |  |  | $ | 4,939 |  |  | (3)% |
| % of non-GAAP net revenue | 11 | % |  | 12 | % |  |  |  | 11 | % |  | 11 | % |  |  |
| Non-GAAP net income | $ | 1,621 |  |  | $ | 1,751 |  |  | (7)% |  | $ | 2,764 |  |  | $ | 2,960 |  |  | (7)% |
| % of non-GAAP net revenue | 7 | % |  | 7 | % |  |  |  | 6 | % |  | 7 | % |  |  |
| Adjusted EBITDA | $ | 3,100 |  |  | $ | 3,156 |  |  | (2)% |  | $ | 5,707 |  |  | $ | 5,729 |  |  | —% |
| % of non-GAAP net revenue | 14 | % |  | 13 | % |  |  |  | 13 | % |  | 13 | % |  |  |
| Non-GAAP earnings per share - diluted | $ | 1.92 |  |  | $ | 2.15 |  |  | (11)% |  | $ | 3.26 |  |  | $ | 3.60 |  |  | (9)% |

[0001571996-20-000041:8k_2_02:96]
11

[0001571996-20-000041:8k_2_02:97]
DELL TECHNOLOGIES INC.

[0001571996-20-000041:8k_2_02:98]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-20-000041:8k_2_02:99]
(in millions, except percentages; unaudited; continued on next page)

[0001571996-20-000041:8k_2_02:100]
|  | Three Months Ended |  |  |  |  |  | Six Months Ended |  |  |  |  |
|  | July 31, 2020 |  | August 2, 2019 |  | Change |  | July 31, 2020 |  | August 2, 2019 |  | Change |
| Net revenue | $ | 22,733 |  |  | $ | 23,370 |  |  | (3)% |  | $ | 44,630 |  |  | $ | 45,278 |  |  | (1)% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 42 |  |  | 84 |  |  |  |  | 90 |  |  | 166 |  |  |  |
| Non-GAAP net revenue | $ | 22,775 |  |  | $ | 23,454 |  |  | (3)% |  | $ | 44,720 |  |  | $ | 45,444 |  |  | (2)% |
| Gross margin | $ | 7,156 |  |  | $ | 7,326 |  |  | (2)% |  | $ | 14,009 |  |  | $ | 14,123 |  |  | (1)% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 375 |  |  | 519 |  |  |  |  | 747 |  |  | 1,038 |  |  |  |
| Impact of purchase accounting | 43 |  |  | 85 |  |  |  |  | 94 |  |  | 169 |  |  |  |
| Transaction-related expenses | — |  |  | — |  |  |  |  | — |  |  | (5) |  |  |  |
| Stock-based compensation expense | 50 |  |  | 32 |  |  |  |  | 90 |  |  | 58 |  |  |  |
| Other corporate expenses | 2 |  |  | 24 |  |  |  |  | 11 |  |  | 37 |  |  |  |
| Non-GAAP gross margin | $ | 7,626 |  |  | $ | 7,986 |  |  | (5)% |  | $ | 14,951 |  |  | $ | 15,420 |  |  | (3)% |
| Operating expenses | $ | 6,020 |  |  | $ | 6,807 |  |  | (12)% |  | $ | 12,171 |  |  | $ | 13,054 |  |  | (7)% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | (472) |  |  | (541) |  |  |  |  | (955) |  |  | (1,239) |  |  |  |
| Impact of purchase accounting | (10) |  |  | (17) |  |  |  |  | (22) |  |  | (34) |  |  |  |
| Transaction-related expenses | (83) |  |  | (47) |  |  |  |  | (159) |  |  | (94) |  |  |  |
| Stock-based compensation expense | (363) |  |  | (269) |  |  |  |  | (693) |  |  | (506) |  |  |  |
| Other corporate expenses | (84) |  |  | (690) |  |  |  |  | (170) |  |  | (700) |  |  |  |
| Non-GAAP operating expenses | $ | 5,008 |  |  | $ | 5,243 |  |  | (4)% |  | $ | 10,172 |  |  | $ | 10,481 |  |  | (3)% |
| Operating income | $ | 1,136 |  |  | $ | 519 |  |  | 119% |  | $ | 1,838 |  |  | $ | 1,069 |  |  | 72% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 847 |  |  | 1,060 |  |  |  |  | 1,702 |  |  | 2,277 |  |  |  |
| Impact of purchase accounting | 53 |  |  | 102 |  |  |  |  | 116 |  |  | 203 |  |  |  |
| Transaction-related expenses | 83 |  |  | 47 |  |  |  |  | 159 |  |  | 89 |  |  |  |
| Stock-based compensation expense | 413 |  |  | 301 |  |  |  |  | 783 |  |  | 564 |  |  |  |
| Other corporate expenses | 86 |  |  | 714 |  |  |  |  | 181 |  |  | 737 |  |  |  |
| Non-GAAP operating income | $ | 2,618 |  |  | $ | 2,743 |  |  | (5)% |  | $ | 4,779 |  |  | $ | 4,939 |  |  | (3)% |

[0001571996-20-000041:8k_2_02:101]
12

[0001571996-20-000041:8k_2_02:102]
DELL TECHNOLOGIES INC.

[0001571996-20-000041:8k_2_02:103]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-20-000041:8k_2_02:104]
(in millions, except percentages; unaudited; continued)

[0001571996-20-000041:8k_2_02:105]
|  | Three Months Ended |  |  |  |  |  | Six Months Ended |  |  |  |  |
|  | July 31, 2020 |  | August 2, 2019 |  | Change |  | July 31, 2020 |  | August 2, 2019 |  | Change |
| Net income | $ | 1,099 |  |  | $ | 4,232 |  |  | (74)% |  | $ | 1,281 |  |  | $ | 4,561 |  |  | (72)% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 847 |  |  | 1,060 |  |  |  |  | 1,702 |  |  | 2,277 |  |  |  |
| Impact of purchase accounting | 53 |  |  | 102 |  |  |  |  | 116 |  |  | 203 |  |  |  |
| Transaction-related expenses | 83 |  |  | 47 |  |  |  |  | 39 |  |  | 89 |  |  |  |
| Stock-based compensation expense | 413 |  |  | 301 |  |  |  |  | 783 |  |  | 564 |  |  |  |
| Other corporate expenses | 86 |  |  | 714 |  |  |  |  | 181 |  |  | 737 |  |  |  |
| Fair value adjustments on equity investments | (8) |  |  | (80) |  |  |  |  | (102) |  |  | (142) |  |  |  |
| Aggregate adjustment for income taxes | (952) |  |  | (4,625) |  |  |  |  | (1,236) |  |  | (5,329) |  |  |  |
| Non-GAAP net income | $ | 1,621 |  |  | $ | 1,751 |  |  | (7)% |  | $ | 2,764 |  |  | $ | 2,960 |  |  | (7)% |
| Net income | $ | 1,099 |  |  | $ | 4,232 |  |  | (74)% |  | $ | 1,281 |  |  | $ | 4,561 |  |  | (72)% |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Interest and other, net | 636 |  |  | 630 |  |  |  |  | 1,202 |  |  | 1,323 |  |  |  |
| Income tax benefit | (599) |  |  | (4,343) |  |  |  |  | (645) |  |  | (4,815) |  |  |  |
| Depreciation and amortization | 1,340 |  |  | 1,498 |  |  |  |  | 2,656 |  |  | 3,114 |  |  |  |
| EBITDA | $ | 2,476 |  |  | $ | 2,017 |  |  | 23% |  | $ | 4,494 |  |  | $ | 4,183 |  |  | 7% |
| EBITDA | $ | 2,476 |  |  | $ | 2,017 |  |  | 23% |  | $ | 4,494 |  |  | $ | 4,183 |  |  | 7% |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense | 413 |  |  | 301 |  |  |  |  | 783 |  |  | 564 |  |  |  |
| Impact of purchase accounting | 42 |  |  | 84 |  |  |  |  | 90 |  |  | 167 |  |  |  |
| Transaction-related expenses | 83 |  |  | 47 |  |  |  |  | 159 |  |  | 89 |  |  |  |
| Other corporate expenses | 86 |  |  | 707 |  |  |  |  | 181 |  |  | 726 |  |  |  |
| Adjusted EBITDA | $ | 3,100 |  |  | $ | 3,156 |  |  | (2)% |  | $ | 5,707 |  |  | $ | 5,729 |  |  | —% |

[0001571996-20-000041:8k_2_02:106]
13

[0001571996-20-000041:8k_2_02:107]
DELL TECHNOLOGIES INC.

[0001571996-20-000041:8k_2_02:108]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-20-000041:8k_2_02:109]
For the Three Months Ended July 31, 2020

[0001571996-20-000041:8k_2_02:110]
(in millions, except per share amounts; unaudited)

[0001571996-20-000041:8k_2_02:111]
|  | GAAP |  | Amortization of intangibles |  | Impact of purchase accounting |  | Transaction-related expenses |  | Stock-based compensation expense |  | Other corporate expenses |  | Fair value adjustments on equity investments |  | Aggregate adjustment for income taxes |  | Non-GAAP |
| Net income | $ | 1,099 |  |  | 847 |  |  | 53 |  |  | 83 |  |  | 413 |  |  | 86 |  |  | (8) |  |  | (952) |  |  | $ | 1,621 |  |
| Less: Net income attributable to non-controlling interests (a) | 51 |  |  | 64 |  |  | 4 |  |  | 8 |  |  | 57 |  |  | — |  |  | — |  |  | (29) |  |  | 155 |  |
| Net income attributable to Dell Technologies Inc. - basic | 1,048 |  |  | 783 |  |  | 49 |  |  | 75 |  |  | 356 |  |  | 86 |  |  | (8) |  |  | (923) |  |  | 1,466 |  |
| Incremental dilution from VMware, Inc. attributable to Dell Technologies Inc. (b) | (3) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (5) |  |
| Net income attributable to Dell Technologies Inc. - diluted | $ | 1,045 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 1,461 |  |
| Earnings per share - basic | $ | 1.41 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 1.98 |  |
| Earnings per share - diluted | $ | 1.37 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 1.92 |  |
| Weighted-average shares outstanding - basic | 741 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 741 |  |
| Weighted-average shares outstanding - diluted | 761 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 761 |  |

[0001571996-20-000041:8k_2_02:112]
_________________

[0001571996-20-000041:8k_2_02:113]
(a)  Net income attributable to non-controlling interests is calculated by multiplying the minority interest percentage of VMware, Inc. and SecureWorks Corp. by their non-GAAP net income adjustments for the period presented.

[0001571996-20-000041:8k_2_02:114]
(b)  Incremental dilution from VMware, Inc. attributable to Dell Technologies Inc. represents the impact of VMware, Inc.’s dilutive securities on the diluted earnings per share of Dell Technologies Inc. and is calculated by multiplying the difference between VMware, Inc.’s basic and diluted earnings per share by the number of shares of VMware, Inc. common stock held by Dell Technologies Inc.

[0001571996-20-000041:8k_2_02:115]
14

[0001571996-20-000041:8k_2_02:116]
DELL TECHNOLOGIES INC.

[0001571996-20-000041:8k_2_02:117]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-20-000041:8k_2_02:118]
For the Six Months Ended July 31, 2020

[0001571996-20-000041:8k_2_02:119]
(in millions, except per share amounts; unaudited)

[0001571996-20-000041:8k_2_02:120]
|  | GAAP |  | Amortization of intangibles |  | Impact of purchase accounting |  | Transaction-related expenses |  | Stock-based compensation expense |  | Other corporate expenses |  | Fair value adjustments on equity investments |  | Aggregate adjustment for income taxes |  | Non-GAAP |
| Net income | $ | 1,281 |  |  | 1,702 |  |  | 116 |  |  | 39 |  |  | 783 |  |  | 181 |  |  | (102) |  |  | (1,236) |  |  | $ | 2,764 |  |
| Less: Net income attributable to non-controlling interests (a) | 90 |  |  | 124 |  |  | 7 |  |  | 15 |  |  | 111 |  |  | — |  |  | (1) |  |  | (64) |  |  | 282 |  |
| Net income attributable to Dell Technologies Inc. - basic | 1,191 |  |  | $ | 1,578 |  |  | $ | 109 |  |  | $ | 24 |  |  | $ | 672 |  |  | $ | 181 |  |  | $ | (101) |  |  | $ | (1,172) |  |  | 2,482 |  |
| Incremental dilution from VMware, Inc. attributable to Dell Technologies Inc. (b) | (5) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (9) |  |
| Net income attributable to Dell Technologies Inc. - diluted | $ | 1,186 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 2,473 |  |
| Earnings per share - basic | $ | 1.61 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 3.35 |  |
| Earnings per share - diluted | $ | 1.56 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 3.26 |  |
| Weighted-average shares outstanding - basic | 740 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 740 |  |
| Weighted-average shares outstanding - diluted | 758 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 758 |  |

[0001571996-20-000041:8k_2_02:121]
_________________

[0001571996-20-000041:8k_2_02:122]
(a)  Net income attributable to non-controlling interests is calculated by multiplying the minority interest percentage of VMware, Inc. and SecureWorks Corp. by their non-GAAP net income adjustments for the period presented.

[0001571996-20-000041:8k_2_02:123]
(b)  Incremental dilution from VMware, Inc. attributable to Dell Technologies Inc. represents the impact of VMware, Inc.’s dilutive securities on the diluted earnings per share of Dell Technologies Inc. and is calculated by multiplying the difference between VMware, Inc.’s basic and diluted earnings per share by the number of shares of VMware, Inc. common stock held by Dell Technologies Inc.

[0001571996-20-000041:8k_2_02:124]
15

[0001571996-20-000041:8k_2_02:125]
DELL TECHNOLOGIES INC.

[0001571996-20-000041:8k_2_02:126]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-20-000041:8k_2_02:127]
For the Three Months Ended August 2, 2019

[0001571996-20-000041:8k_2_02:128]
(in millions, except per share amounts; unaudited)

[0001571996-20-000041:8k_2_02:129]
|  | GAAP |  | Amortization of intangibles |  | Impact of purchase accounting |  | Transaction-related expenses |  | Stock-based compensation expense |  | Other corporate expenses |  | Fair value adjustments on equity investments |  | Aggregate adjustment for income taxes |  | Non-GAAP |
| Net income | $ | 4,232 |  |  | 1,060 |  |  | 102 |  |  | 47 |  |  | 301 |  |  | 714 |  |  | (80) |  |  | (4,625) |  |  | $ | 1,751 |  |
| Less: Net income attributable to non-controlling interests (a) | 816 |  |  | 71 |  |  | 6 |  |  | 2 |  |  | 51 |  |  | — |  |  | 100 |  |  | (915) |  |  | 131 |  |
| Net income attributable to Dell Technologies Inc. - basic | 3,416 |  |  | 989 |  |  | 96 |  |  | 45 |  |  | 250 |  |  | 714 |  |  | (180) |  |  | (3,710) |  |  | 1,620 |  |
| Incremental dilution from VMware, Inc. attributable to Dell Technologies Inc. (b) | (62) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (9) |  |
| Net income attributable to Dell Technologies Inc. - diluted | $ | 3,354 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 1,611 |  |
| Earnings per share - basic | $ | 4.75 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 2.25 |  |
| Earnings per share - diluted | $ | 4.47 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 2.15 |  |
| Weighted-average shares outstanding - basic | 719 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 719 |  |
| Weighted-average shares outstanding - diluted | 751 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 751 |  |

[0001571996-20-000041:8k_2_02:130]
_________________

[0001571996-20-000041:8k_2_02:131]
(a)  Net income attributable to non-controlling interests is calculated by multiplying the minority interest percentage of VMware, Inc., Pivotal Software, Inc., and SecureWorks Corp. by their non-GAAP net income adjustments for the period presented.

[0001571996-20-000041:8k_2_02:132]
(b)  Incremental dilution from VMware, Inc. attributable to Dell Technologies Inc. represents the impact of VMware, Inc.’s dilutive securities on the diluted earnings per share of Dell Technologies Inc. and is calculated by multiplying the difference between VMware, Inc.’s basic and diluted earnings per share by the number of shares of VMware, Inc. common stock held by Dell Technologies Inc.

[0001571996-20-000041:8k_2_02:133]
DELL TECHNOLOGIES INC.

[0001571996-20-000041:8k_2_02:134]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-20-000041:8k_2_02:135]
For the Six Months Ended August 2, 2019

[0001571996-20-000041:8k_2_02:136]
(in millions, except per share amounts; unaudited)

[0001571996-20-000041:8k_2_02:137]
|  | GAAP |  | Amortization of intangibles |  | Impact of purchase accounting |  | Transaction-related expenses |  | Stock-based compensation expense |  | Other corporate expenses |  | Fair value adjustments on equity investments |  | Aggregate adjustment for income taxes |  | Non-GAAP |
| Net income | $ | 4,561 |  |  | 2,277 |  |  | 203 |  |  | 89 |  |  | 564 |  |  | 737 |  |  | (142) |  |  | (5,329) |  |  | $ | 2,960 |  |
| Less: Net income attributable to non-controlling interests (a) | 852 |  |  | 144 |  |  | 12 |  |  | 5 |  |  | 97 |  |  | — |  |  | 74 |  |  | (944) |  |  | 240 |  |
| Net income attributable to Dell Technologies Inc. - basic | 3,709 |  |  | 2,133 |  |  | 191 |  |  | 84 |  |  | 467 |  |  | 737 |  |  | (216) |  |  | (4,385) |  |  | 2,720 |  |
| Incremental dilution from VMware, Inc. attributable to Dell Technologies Inc. (b) | (78) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | (17) |  |
| Net income attributable to Dell Technologies Inc. - diluted | $ | 3,631 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 2,703 |  |
| Earnings per share - basic | $ | 5.17 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 3.79 |  |
| Earnings per share - diluted | $ | 4.84 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 3.60 |  |
| Weighted-average shares outstanding - basic | 718 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 718 |  |
| Weighted-average shares outstanding - diluted | 750 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 750 |  |

[0001571996-20-000041:8k_2_02:138]
_________________

[0001571996-20-000041:8k_2_02:139]
(a)  Net income attributable to non-controlling interests is calculated by multiplying the minority interest percentage of VMware, Inc., Pivotal Software, Inc., and SecureWorks Corp. by their non-GAAP net income adjustments for the period presented.

[0001571996-20-000041:8k_2_02:140]
(b)  Incremental dilution from VMware, Inc. attributable to Dell Technologies Inc. represents the impact of VMware, Inc.’s dilutive securities on the diluted earnings per share of Dell Technologies Inc. and is calculated by multiplying the difference between VMware, Inc.’s basic and diluted earnings per share by the number of shares of VMware, Inc. common stock held by Dell Technologies Inc.
