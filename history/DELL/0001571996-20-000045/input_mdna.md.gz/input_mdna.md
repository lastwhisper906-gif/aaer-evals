# DELL MD&A — 0001571996-20-000045


## mdna

[0001571996-20-000045:mdna:1]
[same as prior period, unchanged from 0001571996-20-000034:mdna:1]

[0001571996-20-000045:mdna:2]
[same as prior period, unchanged from 0001571996-20-000034:mdna:2]

[0001571996-20-000045:mdna:3]
[same as prior period, unchanged from 0001571996-20-000034:mdna:3]

[0001571996-20-000045:mdna:4]
[same as prior period, unchanged from 0001571996-20-000034:mdna:4]

[0001571996-20-000045:mdna:5]
[same as prior period, unchanged from 0001571996-20-000034:mdna:5]

[0001571996-20-000045:mdna:6]
[same as prior period, unchanged from 0001571996-20-000034:mdna:6]

[0001571996-20-000045:mdna:7]
Dell Technologies operates with significant scale and an unmatched breadth of complementary offerings.  Digital transformation has become essential to all businesses, and we have expanded our portfolio to include holistic solutions that enable our customers to drive their ongoing digital transformation initiatives.  Dell Technologies’ integrated solutions help customers modernize their IT infrastructure, address workforce transformation, and provide critical solutions to keep people and organizations connected in this current time of disruption.  With our extensive portfolio and our commitment to innovation, we have the ability to offer secure, integrated solutions that extend from the edge to the core to the cloud, and we are at the forefront of the software-defined and cloud native infrastructure era.  Our end-to-end portfolio is supported by a differentiated go-to-market engine, which includes a 43,000-person sales force, a global network of channel partners, and a world-class supply chain that together drive long-term growth and operating efficiencies.

[0001571996-20-000045:mdna:8]
[same as prior period, unchanged from 0001571996-20-000034:mdna:8]

[0001571996-20-000045:mdna:9]
[same as prior period, unchanged from 0001571996-20-000034:mdna:9]

[0001571996-20-000045:mdna:10]
•Infrastructure Solutions Group (“ISG”) — ISG enables the digital transformation of our customers through our trusted multi-cloud and big data solutions, which are built upon a modern data center infrastructure.  ISG works with customers in the area of hybrid cloud deployment with the goal of simplifying, streamlining, and automating cloud operations.  ISG solutions are built for multicloud environments and are optimized to run cloud native workloads in both public and private clouds, as well as traditional on-premise workloads.

[0001571996-20-000045:mdna:11]
[same as prior period, unchanged from 0001571996-20-000034:mdna:11]

[0001571996-20-000045:mdna:12]
[same as prior period, unchanged from 0001571996-20-000034:mdna:12]

[0001571996-20-000045:mdna:13]
•Client Solutions Group (“CSG”) — CSG includes branded hardware (such as desktops, workstations, and notebooks) and branded peripherals (such as displays and projectors), as well as third-party software and peripherals.  Our computing devices are designed with our commercial and consumer customers’ needs in mind, and we seek to optimize performance, reliability, manageability, design, and security.  In addition to our traditional hardware business, we have a portfolio of thin client offerings that we believe will allow us to benefit from the growth trends in cloud computing.  For our customers that are seeking to simplify client lifecycle management, Dell PC as a Service offering combines hardware, software, lifecycle services, and financing into one all-encompassing solution that provides predictable pricing per seat per month through Dell Financial Services.  CSG also offers attached software, peripherals, and services, including support and deployment, configuration, and extended warranty services.

[0001571996-20-000045:mdna:14]
[same as prior period, unchanged from 0001571996-20-000034:mdna:14]

[0001571996-20-000045:mdna:15]
•VMware — The VMware reportable segment (“VMware”) reflects the operations of VMware, Inc. (NYSE: VMW) within Dell Technologies.  VMware works with customers in the areas of hybrid and multi-cloud, modern applications, networking, security, and digital workspaces, helping customers manage their IT resources across private clouds and complex multi-cloud, multi-device environments.  VMware’s portfolio supports and addresses the key IT priorities of customers: accelerating their cloud journey, modernizing their applications, empowering digital workspaces, transforming networking, and embracing intrinsic security.  VMware enables its customers to digitally transform their operations as they ready their applications, infrastructure, and employees for constantly evolving business needs.

[0001571996-20-000045:mdna:16]
[same as prior period, unchanged from 0001571996-20-000034:mdna:16]

[0001571996-20-000045:mdna:17]
On December 30, 2019, VMware, Inc. completed its acquisition of Pivotal Software, Inc. (“Pivotal”).  Before the transaction, Pivotal was a majority-owned subsidiary of Dell Technologies through EMC and VMware, Inc.  Pivotal provides a leading cloud-native platform that makes software development and IT operations a strategic advantage for customers.  Pivotal’s cloud-native platform, Pivotal Cloud Foundry, accelerates and streamlines software development

[0001571996-20-000045:mdna:18]
by reducing the complexity of building, deploying, and operating new cloud-native applications, and modernizing legacy applications.  With the acquisition, which aligns key software assets, VMware, Inc. will drive and build on a comprehensive development platform with Kubernetes.

[0001571996-20-000045:mdna:19]
[same as prior period, unchanged from 0001571996-20-000034:mdna:19]

[0001571996-20-000045:mdna:20]
[same as prior period, unchanged from 0001571996-20-000034:mdna:20]

[0001571996-20-000045:mdna:21]
[same as prior period, unchanged from 0001571996-20-000034:mdna:21]

[0001571996-20-000045:mdna:22]
•Secureworks (NASDAQ: SCWX) is a leading global provider of intelligence-driven information security solutions singularly focused on protecting its clients from cyber attacks.  The solutions offered by Secureworks enable organizations of varying size and complexity to fortify their cyber defenses to prevent security breaches, detect malicious activity in near real time, prioritize and respond rapidly to security incidents, and predict emerging threats.

[0001571996-20-000045:mdna:23]
•Virtustream offers cloud software and infrastructure-as-a-service solutions that enable customers to migrate, run, and manage mission-critical applications in cloud-based IT environments.

[0001571996-20-000045:mdna:24]
•Boomi specializes in cloud-based integration, connecting information between existing on-premise and cloud-based applications to ensure that business processes are optimized, data is accurate and workflow is reliable.

[0001571996-20-000045:mdna:25]
•RSA Security provides essential cybersecurity solutions engineered to enable organizations to detect, investigate, and respond to advanced attacks, confirm and manage identities, and, ultimately, help reduce IP theft, fraud, and cybercrime.  As of July 31, 2020, the assets and liabilities of RSA Security were classified as held for sale on our Condensed Consolidated Statements of Financial Position.  On September 1, 2020, Dell Technologies completed its divestiture of RSA Security to a consortium of investors in an all-cash transaction for approximately $2.082 billion.  The transaction is intended to further simplify our product portfolio and corporate structure.

[0001571996-20-000045:mdna:26]
[same as prior period, unchanged from 0001571996-20-000034:mdna:26]

[0001571996-20-000045:mdna:27]
[same as prior period, unchanged from 0001571996-20-000034:mdna:27]

[0001571996-20-000045:mdna:28]
[same as prior period, unchanged from 0001571996-20-000034:mdna:28]

[0001571996-20-000045:mdna:29]
Dell Financial Services and its affiliates (“DFS”) support our businesses by offering and arranging various financing options and services for our customers in North America, Europe, Australia, and New Zealand.  DFS originates, collects, and services customer receivables primarily related to the purchase or use of our product, software, and service solutions.  We also arrange financing for some of our customers in various countries where DFS does not currently operate as a captive.  DFS further strengthens our customer relationships through its flexible consumption models, which enable us to offer our customers the option to pay over time and, in certain cases, based on utilization, providing them with financial flexibility to meet their changing technological requirements.  The results of these operations are allocated to our segments based on the underlying product or service financed.  In response to the coronavirus disease 2019 (“COVID-19”) pandemic, we are focused on supporting our customers and intend to provide up to $9 billion in financing support by offering low or zero percent interest rate programs as well as payment deferral options.  The financial impact to DFS and our securitization and structured financing

[0001571996-20-000045:mdna:30]
programs is not expected to be material.  For additional information about our financing arrangements, see Note 4 of the Notes to the Condensed Consolidated Financial Statements included in this report.

[0001571996-20-000045:mdna:31]
[same as prior period, unchanged from 0001571996-20-000034:mdna:30]

[0001571996-20-000045:mdna:32]
As part of our strategy, we will continue to evaluate opportunities for strategic investments through our venture capital investment arm, Dell Technologies Capital, with a focus on emerging technology areas that are relevant to all segments of our business and that will complement our existing portfolio of solutions.  Our investment areas include storage, software-defined networking, management and orchestration, security, machine learning and artificial intelligence, Big Data and analytics, cloud, Internet of Things (“IoT”), and software development operations.  In addition to these investments, we also may make disciplined acquisitions targeting businesses that advance our strategic objectives.  As of July 31, 2020 and January 31, 2020, Dell Technologies held strategic investments of $1.0 billion and $0.9 billion, respectively.

[0001571996-20-000045:mdna:33]
[same as prior period, unchanged from 0001571996-20-000034:mdna:32]

[0001571996-20-000045:mdna:34]
COVID-19 Pandemic and Response — In March 2020, the World Health Organization (“WHO”) declared the outbreak of the COVID-19 a global pandemic.  This declaration has been followed by significant governmental measures implemented in the United States and globally, including travel bans and restrictions, shelter-in-place orders, limitations and closures of non-essential businesses, and social distancing requirements in efforts to slow down and control the spread of the virus.

[0001571996-20-000045:mdna:35]
The health of our employees, customers, business partners, and communities remains our primary focus.  We have taken numerous actions to date in response to COVID-19, including a swift implementation of our business continuity plans.  Our crisis management team is actively engaged to respond to changes in our environment quickly and effectively, and to ensure that our preparedness plans and response activities are aligned with recommendations of the WHO, the U.S. Centers for Disease Control and Prevention, and governmental regulations.  We have implemented broad travel restrictions and moved to virtual-only events.  Most of our employees were previously equipped with remote work capabilities over the past several years, thus enabling us to quickly establish a work-from-home posture for the majority of our employees.  Further, we implemented pandemic-specific protocols for our essential employees whose jobs require them to be on-site or with customers.  Certain regions and municipalities within the United States and internationally are beginning to lift stay-at-home and quarantine mandates.  We are actively working with governments across the world to develop return-to-site protocols to ensure the health and safety of our employees, customers, and business partners.

[0001571996-20-000045:mdna:36]
We are working closely with our customers and business partners to support them as they expand their own remote work solutions and contingency plans, helping them access our products and services remotely.  We have benefited from our agility, our breadth, and our scale.  Notable actions we have taken include the following:

[0001571996-20-000045:mdna:37]
•Our global sales teams embraced a new selling process and are successfully supporting our customers and partners remotely.

[0001571996-20-000045:mdna:38]
•We are helping to address our customers’ cash flow requirements by expanding our as-a-service and financing offerings.

[0001571996-20-000045:mdna:39]
•Our close relationships and ability to connect directly with our customers through our e-commerce business have enabled us to quickly meet the immediate demands of the new work- and learn-from-home environments.

[0001571996-20-000045:mdna:40]
•The strength, scale, and resiliency of our global supply chain have afforded us flexibility to manage through this challenging time.  We adapted to events unfolding real-time by applying predictive analytics to model a variety of outcomes to respond quickly to the changing environment.  We optimized our global supply chain footprint to maximize factory uptime, for both Dell Technologies and our suppliers, by working through various local governmental regulations and mandates.  During this time, we established robust safety measures to protect the health and safety of our essential team members.

[0001571996-20-000045:mdna:41]
•We continue to drive innovation and excellence in engineering with a largely remote workforce.  Engineers and product teams recently delivered several critical solutions, including cloud updates and key client product refreshes, as well as the May 2020 launch of the PowerStore midrange storage solution.

[0001571996-20-000045:mdna:42]
During the first six months of Fiscal 2021, we took certain precautionary measures to increase our cash position and preserve financial flexibility.  We also made a series of prudent decisions to manage expenses and preserve liquidity including but not limited to global hiring limitations, reduction in consulting and contractor costs, global travel restrictions, suspension of the Dell 401(k) match program for U.S. employees, and lower facilities-related costs.  All of these actions are aligned with our strategy, which remains unchanged, of focusing on gaining share, integrating and innovating across the Dell Technologies portfolio, and strengthening our capital structure.

[0001571996-20-000045:mdna:43]
We saw unique demand dynamics during the first six months of Fiscal 2021.  For additional information about impacts of COVID-19 on our operations, see “Results of Operations—Consolidated Results” and “—Business Unit Results.”

[0001571996-20-000045:mdna:44]
We are unable to accurately predict the full impact this unprecedented environment may have on our results of operations, financial condition, liquidity and cash flows due to numerous uncertainties involved, including the progression of the COVID-19 pandemic, governmental responses, and the timing of recovery.  We will continue to actively monitor global events and make prudent decisions to navigate in this uncertain and ever-changing environment.  We believe we are well-positioned for long-term success, and that we will continue to lead the industry with innovative solutions and the essential technology that the world needs now more than ever.

[0001571996-20-000045:mdna:45]
[same as prior period, unchanged from 0001571996-20-000034:mdna:46]

[0001571996-20-000045:mdna:46]
We are seeing an accelerated rate of change in the IT industry.  We seek to address our customers’ evolving needs and their broader digital transformation objectives as they embrace the hybrid multi-cloud environment of today.  For many customers right now, a top digital priority is to build stable and resilient remote operational capabilities.  We are seeing demand for simpler, more agile IT across multiple clouds.  The pandemic has accelerated the introduction and adoption of new technologies to ensure productivity and collaboration from anywhere.  In light of this rapid pace of innovation, we continue to invest in research and development, sales, and other key areas of our business to deliver superior products and solutions capabilities and to drive long-term sustainable growth.

[0001571996-20-000045:mdna:47]
ISG — We expect that ISG will continue to be impacted by the changing nature of the IT infrastructure market and competitive environment.  The overall server demand environment was down for the first six months of Fiscal 2021 and remains varied among international regions.  We will continue to be selective in determining whether to pursue certain large hyperscale and other server transactions as we drive for balanced growth and profitability.  With our scale and strong solutions portfolio, we believe we are well-positioned to respond to ongoing competitive dynamics.  We continue to focus on customer base expansion and lifetime value of customer relationships.

[0001571996-20-000045:mdna:48]
[same as prior period, unchanged from 0001571996-20-000034:mdna:49]

[0001571996-20-000045:mdna:49]
[same as prior period, unchanged from 0001571996-20-000034:mdna:50]

[0001571996-20-000045:mdna:50]
CSG — Our CSG offerings are an important element of our strategy, generating strong cash flow and opportunities for cross-selling of complementary solutions.  During the first six months of Fiscal 2021, CSG demand was strong in certain product lines, particularly for notebooks and gaming systems, while demand for commercial desktops decreased.  These demand dynamics were driven by the imperative for remote work and remote learning solutions, as business, government, and education customers sought to maintain productivity in the midst of COVID-19.  We continue to deploy Dell PC as a Service offerings for customers who are seeking simplified solutions and lifecycle management with predictable pricing through DFS.  We expect

[0001571996-20-000045:mdna:51]
68

[0001571996-20-000045:mdna:52]
that the CSG demand environment will to continue to be cyclical, but the near-term demand environment remains uncertain given current macro-economic dynamics, including the effects of COVID-19.  We expect a higher mix toward consumer solutions and entry-level notebooks in the second half of Fiscal 2021, which may put pressure on CSG operating results.  We remain committed to our long-term strategy for CSG and will continue to innovate across the portfolio, while benefiting from consolidation trends that are occurring in the markets in which we compete.  Competitive dynamics will continue to be a factor in our CSG business as we seek to balance profitability and growth.

[0001571996-20-000045:mdna:53]
Recurring Revenue and Consumption Models — Our customers are interested in new and innovative models that address how they consume our solutions.  We offer options including as-a-service, utility, leases, and immediate pay models, all designed to match customers’ consumption and financing preferences.  Our multi-year agreements typically result in recurring revenue streams over the term of the arrangement.  We expect that our flexible consumption models will further strengthen our customer relationships and provide a foundation for growth in recurring revenue.

[0001571996-20-000045:mdna:54]
Supply Chain — During Fiscal 2020, we recognized benefits to our ISG and CSG operating results from significant component cost declines.  During the second quarter of Fiscal 2021, the ISG component cost environment became inflationary.  For CSG, component costs continued to be deflationary during the second quarter of Fiscal 2021, but at a lower rate than during the first quarter of Fiscal 2021.  We currently expect the component cost environment will be inflationary in the aggregate during the third quarter of Fiscal 2021 and then will return to a deflationary environment in the fourth quarter of Fiscal 2021.  The component cost trends and forecasts are dependent on the strength or weakness of actual end-user demand and supply dynamics, which will continue to evolve and ultimately impact the translation of the cost environment to pricing and operating results.

[0001571996-20-000045:mdna:55]
Dell Technologies maintains limited-source supplier relationships for processors, because the relationships are advantageous in the areas of performance, quality, support, delivery, capacity, and price considerations.  In recent periods, we have been impacted by processor and other supply constraints in certain product offerings, some of which resulted from COVID-19 driven demand patterns.  Delays in the supply of limited-source components, including as a result of COVID-19, are affecting the timing of shipments of certain products in desired quantities or configurations.

[0001571996-20-000045:mdna:56]
Macro-Economic Risks and Uncertainties — The impacts of trade protection measures, including increases in tariffs and trade barriers, and changes in government policies and international trade arrangements may affect our ability to conduct business in some non-U.S. markets.  We monitor and seek to mitigate these risks with adjustments to our manufacturing, supply chain, and distribution networks.

[0001571996-20-000045:mdna:57]
We manage our business on a U.S. dollar basis.  However, we have a large global presence, generating approximately half of our revenue by sales to customers outside of the United States during both the first six months of Fiscal 2021 and Fiscal 2020.  As a result, our revenue can be impacted by fluctuations in foreign currency exchange rates.  We utilize a comprehensive hedging strategy intended to mitigate the impact of foreign currency volatility over time, and we adjust pricing when possible to further minimize foreign currency impacts.

[0001571996-20-000045:mdna:58]
[same as prior period, unchanged from 0001571996-20-000034:mdna:57]

[0001571996-20-000045:mdna:59]
[same as prior period, unchanged from 0001571996-20-000034:mdna:58]

[0001571996-20-000045:mdna:60]
[same as prior period, unchanged from 0001571996-20-000034:mdna:59]

[0001571996-20-000045:mdna:61]
[same as prior period, unchanged from 0001571996-20-000034:mdna:60]

[0001571996-20-000045:mdna:62]
VMware, Inc. Ownership

[0001571996-20-000045:mdna:63]
On July 15, 2020, we announced that we are exploring potential alternatives with respect to our ownership in VMware, Inc., including a potential spin-off of that ownership interest to Dell Technologies’ stockholders.  Although this process is currently only at an exploratory stage, we believe a spin-off could benefit both Dell Technologies’ and VMware, Inc.’s stockholders by simplifying capital structures and enhancing strategic flexibility, while still maintaining a mutually beneficial strategic and commercial partnership.  Any potential spin-off would not occur prior to September 2021.  Other strategic options include maintaining the status quo with respect to our ownership interest in VMware, Inc.

[0001571996-20-000045:mdna:64]
70

[0001571996-20-000045:mdna:65]
[same as prior period, unchanged from 0001571996-20-000034:mdna:62]

[0001571996-20-000045:mdna:66]
[same as prior period, unchanged from 0001571996-20-000034:mdna:63]

[0001571996-20-000045:mdna:67]
We use non-GAAP financial measures to supplement financial information presented on a GAAP basis.  Management considers these non-GAAP measures in evaluating our operating trends and performance.  Moreover, we believe these non-GAAP financial measures provide our stakeholders with useful and transparent information to help them evaluate our operating results by facilitating an enhanced understanding of our operating performance and enabling them to make more meaningful period to period comparisons.  There are limitations to the use of the non-GAAP financial measures presented in this report.  Our non-GAAP financial measures may not be comparable to similarly titled measures of other companies.  Other companies, including companies in our industry, may calculate non-GAAP financial measures differently than we do, limiting the usefulness of those measures for comparative purposes.

[0001571996-20-000045:mdna:68]
[same as prior period, unchanged from 0001571996-20-000034:mdna:65]

[0001571996-20-000045:mdna:69]
[same as prior period, unchanged from 0001571996-20-000034:mdna:66]

[0001571996-20-000045:mdna:70]
Revenue Reclassification — During Fiscal 2020, Dell Technologies made certain reclassifications of net revenue between the products and services categories on the Consolidated Statement of Net Income (Loss), which impacted previously reported amounts for the second quarter and first six months of Fiscal 2020.  The reclassifications were made to provide a more meaningful representation of the nature of certain service and software-as-a-service offerings of VMware, Inc.  The reclassifications resulted in an increase to services revenue and an equal and offsetting decrease to product revenue of $195 million and $374 million for the second quarter and first six months of Fiscal 2020, respectively.  Total net revenue as previously reported remains unchanged.  The Company did not recast cost of goods sold for the related revenue reclassifications due to immateriality.

[0001571996-20-000045:mdna:71]
[same as prior period, unchanged from 0001571996-20-000034:mdna:69]

[0001571996-20-000045:mdna:72]
•Amortization of Intangible Assets — Amortization of intangible assets primarily consists of amortization of customer relationships, developed technology, and trade names.  In connection with our acquisition by merger of EMC on September 7, 2016, referred to as the EMC merger transaction, and the acquisition of Dell Inc. by Dell Technologies Inc. on October 29, 2013, referred to as the going-private transaction, all of the tangible and intangible assets and liabilities of EMC and Dell, respectively, were accounted for and recognized at fair value on the transaction dates.  Accordingly, for the periods presented, amortization of intangible assets represents amortization associated with intangible assets recognized in connection with the EMC merger transaction and the going-private transaction.  Amortization charges for purchased intangible assets are significantly impacted by the timing and magnitude of our acquisitions, and these charges may vary in amount from period to period.  We exclude these charges for purposes of calculating the non-GAAP financial measures presented below to facilitate a more meaningful evaluation of our current operating performance and comparisons to our past operating performance.

[0001571996-20-000045:mdna:73]
•Impact of Purchase Accounting — The impact of purchase accounting includes purchase accounting adjustments related to the EMC merger transaction and, to a lesser extent, the going-private transaction, recorded under the acquisition method of accounting in accordance with the accounting guidance for business combinations.  This guidance prescribes that the purchase price be allocated to assets acquired and liabilities assumed based on the estimated fair value of such assets and liabilities on the date of the transaction.  Accordingly, all of the assets and liabilities acquired in the EMC merger transaction and the going-private transaction were accounted for and recognized at fair value as of the respective transaction dates, and the fair value adjustments are being amortized over the estimated useful lives in the periods following the transactions.  The fair value adjustments primarily relate to deferred revenue, inventory, and property, plant, and equipment.  Although the purchase accounting adjustments and related amortization of those adjustments are reflected in our GAAP results, we evaluate the operating results of the underlying businesses on a non-GAAP basis, after removing such adjustments.  We believe that excluding the impact of purchase accounting provides results that are useful in understanding our current operating performance and provides more meaningful comparisons to our past operating performance.

[0001571996-20-000045:mdna:74]
•Transaction-related Expenses — Transaction-related expenses typically consist of acquisition, integration, and divestiture related costs and are expensed as incurred.  These expenses primarily represent costs for legal, banking, consulting, and advisory services.  From time to time, this category also may include transaction-related gains on divestitures of businesses or asset sales.  During the first quarter of Fiscal 2021, we recognized a gain of $120 million on the sale of certain intellectual property assets.  We exclude these items for purposes of calculating the non-GAAP financial measures presented below to facilitate a more meaningful evaluation of our current operating performance and comparisons to our past operating performance.  See Note 8 of the Notes to the Condensed Consolidated Financial Statements for additional information about VMware, Inc. acquisitions.

[0001571996-20-000045:mdna:75]
•Stock-based Compensation Expense — Stock-based compensation expense consists of equity awards granted based on the estimated fair value of those awards at grant date.  We estimate the fair value of service-based stock options using the Black-Scholes valuation model.  To estimate the fair value of performance-based awards containing a market condition, we use the Monte Carlo valuation model.  For all other share-based awards, the fair value is based on the closing price of the Class C Common Stock as reported on the NYSE on the date of grant.  Although stock-based compensation is an important aspect of the compensation of our employees and executives, the fair value of the stock-based awards may bear little resemblance to the actual value realized upon the vesting or future exercise of the related stock-based awards.  We believe that excluding stock-based compensation expense for purposes of calculating the non-GAAP financial measures presented below facilitates a more meaningful evaluation of our current operating performance and comparisons to our past operating performance.

[0001571996-20-000045:mdna:76]
•Other Corporate Expenses — Other corporate expenses consists primarily of severance, facility action, and other costs.  Severance costs are primarily related to severance and benefits for employees terminated pursuant to cost savings initiatives.  We continue to integrate owned and leased facilities and may incur additional costs as we seek opportunities for operational efficiencies.  Other corporate expenses vary from period to period and are significantly impacted by the timing and nature of these events.  Therefore, although we may incur these types of expenses in the future, we believe that eliminating these charges for purposes of calculating the non-GAAP financial measures presented below facilitates a more meaningful evaluation of our current operating performance and comparisons to our past operating performance.  During

[0001571996-20-000045:mdna:77]
72

[0001571996-20-000045:mdna:78]
the second quarter and first six months of Fiscal 2020, this category includes Virtustream gross impairment charges of $619 million.

[0001571996-20-000045:mdna:79]
•Fair Value Adjustments on Equity Investments — Fair value adjustments on equity investments primarily consists of the gain (loss) on strategic investments, which includes the recurring fair value adjustments of investments in publicly-traded companies, as well as those in privately-held companies, which are adjusted for observable price changes and, to a lesser extent, any potential impairments.  Given the volatility in the ongoing adjustments to the valuation of these strategic investments, we believe that excluding these gains and losses for purposes of calculating non-GAAP net income presented below facilitates a more meaningful evaluation of our current operating performance and comparisons to our past operating performance.

[0001571996-20-000045:mdna:80]
•Aggregate Adjustment for Income Taxes — The aggregate adjustment for income taxes is the estimated combined income tax effect for the adjustments described above, as well as an adjustment for discrete tax items.  Due to the variability in recognition of discrete tax items from period to period, we believe that excluding these benefits or charges for purposes of calculating non-GAAP net income facilitates a more meaningful evaluation of our current operating performance and comparisons to our past operating performance.  The tax effects are determined based on the tax jurisdictions where the above items were incurred.  This category includes discrete tax benefits of $746 million related to an audit settlement in the second quarter and first six months of Fiscal 2021, and $59 million from an intra-entity asset transfer of certain of Pivotal’s intellectual property to an Irish subsidiary that was completed by VMware, Inc. during the first six months of Fiscal 2021. This category also includes discrete tax benefits of $4.5 billion and $4.9 billion related to similar intra-entity asset transfers in the second quarter and first six months of Fiscal 2020, respectively.  See Note 11 of the Notes to the Condensed Consolidated Financial Statements for additional information about our income taxes.

[0001571996-20-000045:mdna:81]
73

[0001571996-20-000045:mdna:82]
[same as prior period, unchanged from 0001571996-20-000034:mdna:79]

[0001571996-20-000045:mdna:83]
|  | Three Months Ended |  |  |  |  |  | Six Months Ended |  |  |  |  |
|  | July 31, 2020 |  | % Change |  | August 2, 2019 |  | July 31, 2020 |  | % Change |  | August 2, 2019 |
|  | (in millions, except percentages) |  |  |  |  |  |  |  |  |  |  |
| Product net revenue | $ | 16,737 |  |  | (7) | % |  | $ | 17,915 |  |  | $ | 32,775 |  |  | (5) | % |  | $ | 34,490 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 2 |  |  |  |  | 6 |  |  | 6 |  |  |  |  | 10 |  |
| Non-GAAP product net revenue | $ | 16,739 |  |  | (7) | % |  | $ | 17,921 |  |  | $ | 32,781 |  |  | (5) | % |  | $ | 34,500 |  |
| Services net revenue | $ | 5,996 |  |  | 10 | % |  | $ | 5,455 |  |  | $ | 11,855 |  |  | 10 | % |  | $ | 10,788 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 40 |  |  |  |  | 78 |  |  | 84 |  |  |  |  | 156 |  |
| Non-GAAP services net revenue | $ | 6,036 |  |  | 9 | % |  | $ | 5,533 |  |  | $ | 11,939 |  |  | 9 | % |  | $ | 10,944 |  |
| Net revenue | $ | 22,733 |  |  | (3) | % |  | $ | 23,370 |  |  | $ | 44,630 |  |  | (1) | % |  | $ | 45,278 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 42 |  |  |  |  | 84 |  |  | 90 |  |  |  |  | 166 |  |
| Non-GAAP net revenue | $ | 22,775 |  |  | (3) | % |  | $ | 23,454 |  |  | $ | 44,720 |  |  | (2) | % |  | $ | 45,444 |  |
| Product gross margin | $ | 3,407 |  |  | (15) | % |  | $ | 4,026 |  |  | $ | 6,641 |  |  | (12) | % |  | $ | 7,522 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 374 |  |  |  |  | 519 |  |  | 746 |  |  |  |  | 1,038 |  |
| Impact of purchase accounting | 3 |  |  |  |  | 7 |  |  | 10 |  |  |  |  | 13 |  |
| Transaction-related expenses | — |  |  |  |  | (3) |  |  | — |  |  |  |  | (5) |  |
| Stock-based compensation expense | 6 |  |  |  |  | 4 |  |  | 10 |  |  |  |  | 6 |  |
| Other corporate expenses | 1 |  |  |  |  | 5 |  |  | 3 |  |  |  |  | 9 |  |
| Non-GAAP product gross margin | $ | 3,791 |  |  | (17) | % |  | $ | 4,558 |  |  | $ | 7,410 |  |  | (14) | % |  | $ | 8,583 |  |
| Services gross margin | $ | 3,749 |  |  | 14 | % |  | $ | 3,300 |  |  | $ | 7,368 |  |  | 12 | % |  | $ | 6,601 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 1 |  |  |  |  | — |  |  | 1 |  |  |  |  | — |  |
| Impact of purchase accounting | 40 |  |  |  |  | 78 |  |  | 84 |  |  |  |  | 156 |  |
| Transaction-related expenses | — |  |  |  |  | 3 |  |  | — |  |  |  |  | — |  |
| Stock-based compensation expense | 44 |  |  |  |  | 28 |  |  | 80 |  |  |  |  | 52 |  |
| Other corporate expenses | 1 |  |  |  |  | 19 |  |  | 8 |  |  |  |  | 28 |  |
| Non-GAAP services gross margin | $ | 3,835 |  |  | 12 | % |  | $ | 3,428 |  |  | $ | 7,541 |  |  | 10 | % |  | $ | 6,837 |  |

[0001571996-20-000045:mdna:84]
|  | Three Months Ended |  |  |  |  |  | Six Months Ended |  |  |  |  |
|  | July 31, 2020 |  | % Change |  | August 2, 2019 |  | July 31, 2020 |  | % Change |  | August 2, 2019 |
|  | (in millions, except percentages) |  |  |  |  |  |  |  |  |  |  |
| Gross margin | $ | 7,156 |  |  | (2) | % |  | $ | 7,326 |  |  | $ | 14,009 |  |  | (1) | % |  | $ | 14,123 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 375 |  |  |  |  | 519 |  |  | 747 |  |  |  |  | 1,038 |  |
| Impact of purchase accounting | 43 |  |  |  |  | 85 |  |  | 94 |  |  |  |  | 169 |  |
| Transaction-related expenses | — |  |  |  |  | — |  |  | — |  |  |  |  | (5) |  |
| Stock-based compensation expense | 50 |  |  |  |  | 32 |  |  | 90 |  |  |  |  | 58 |  |
| Other corporate expenses | 2 |  |  |  |  | 24 |  |  | 11 |  |  |  |  | 37 |  |
| Non-GAAP gross margin | $ | 7,626 |  |  | (5) | % |  | $ | 7,986 |  |  | $ | 14,951 |  |  | (3) | % |  | $ | 15,420 |  |
| Operating expenses | $ | 6,020 |  |  | (12) | % |  | $ | 6,807 |  |  | $ | 12,171 |  |  | (7) | % |  | $ | 13,054 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | (472) |  |  |  |  | (541) |  |  | (955) |  |  |  |  | (1,239) |  |
| Impact of purchase accounting | (10) |  |  |  |  | (17) |  |  | (22) |  |  |  |  | (34) |  |
| Transaction-related expenses | (83) |  |  |  |  | (47) |  |  | (159) |  |  |  |  | (94) |  |
| Stock-based compensation expense | (363) |  |  |  |  | (269) |  |  | (693) |  |  |  |  | (506) |  |
| Other corporate expenses | (84) |  |  |  |  | (690) |  |  | (170) |  |  |  |  | (700) |  |
| Non-GAAP operating expenses | $ | 5,008 |  |  | (4) | % |  | $ | 5,243 |  |  | $ | 10,172 |  |  | (3) | % |  | $ | 10,481 |  |
| Operating income | $ | 1,136 |  |  | 119 | % |  | $ | 519 |  |  | $ | 1,838 |  |  | 72 | % |  | $ | 1,069 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 847 |  |  |  |  | 1,060 |  |  | 1,702 |  |  |  |  | 2,277 |  |
| Impact of purchase accounting | 53 |  |  |  |  | 102 |  |  | 116 |  |  |  |  | 203 |  |
| Transaction-related expenses | 83 |  |  |  |  | 47 |  |  | 159 |  |  |  |  | 89 |  |
| Stock-based compensation expense | 413 |  |  |  |  | 301 |  |  | 783 |  |  |  |  | 564 |  |
| Other corporate expenses | 86 |  |  |  |  | 714 |  |  | 181 |  |  |  |  | 737 |  |
| Non-GAAP operating income | $ | 2,618 |  |  | (5) | % |  | $ | 2,743 |  |  | $ | 4,779 |  |  | (3) | % |  | $ | 4,939 |  |
| Net income | $ | 1,099 |  |  | (74) | % |  | $ | 4,232 |  |  | $ | 1,281 |  |  | (72) | % |  | $ | 4,561 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 847 |  |  |  |  | 1,060 |  |  | 1,702 |  |  |  |  | 2,277 |  |
| Impact of purchase accounting | 53 |  |  |  |  | 102 |  |  | 116 |  |  |  |  | 203 |  |
| Transaction-related (income) expenses | 83 |  |  |  |  | 47 |  |  | 39 |  |  |  |  | 89 |  |
| Stock-based compensation expense | 413 |  |  |  |  | 301 |  |  | 783 |  |  |  |  | 564 |  |
| Other corporate expenses | 86 |  |  |  |  | 714 |  |  | 181 |  |  |  |  | 737 |  |
| Fair value adjustments on equity investments | (8) |  |  |  |  | (80) |  |  | (102) |  |  |  |  | (142) |  |
| Aggregate adjustment for income taxes | (952) |  |  |  |  | (4,625) |  |  | (1,236) |  |  |  |  | (5,329) |  |
| Non-GAAP net income | $ | 1,621 |  |  | (7) | % |  | $ | 1,751 |  |  | $ | 2,764 |  |  | (7) | % |  | $ | 2,960 |  |

[0001571996-20-000045:mdna:85]
75

[0001571996-20-000045:mdna:86]
[same as prior period, unchanged from 0001571996-20-000034:mdna:83]

[0001571996-20-000045:mdna:87]
[same as prior period, unchanged from 0001571996-20-000034:mdna:84]

[0001571996-20-000045:mdna:88]
[same as prior period, unchanged from 0001571996-20-000034:mdna:85]

[0001571996-20-000045:mdna:89]
|  | Three Months Ended |  |  |  |  |  | Six Months Ended |  |  |  |  |
|  | July 31, 2020 |  | % Change |  | August 2, 2019 |  | July 31, 2020 |  | % Change |  | August 2, 2019 |
|  | (in millions, except percentages) |  |  |  |  |  |  |  |  |  |  |
| Net income | $ | 1,099 |  |  | (74) | % |  | $ | 4,232 |  |  | $ | 1,281 |  |  | (72) | % |  | $ | 4,561 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Interest and other, net (a) | 636 |  |  |  |  | 630 |  |  | 1,202 |  |  |  |  | 1,323 |  |
| Income tax benefit (b) | (599) |  |  |  |  | (4,343) |  |  | (645) |  |  |  |  | (4,815) |  |
| Depreciation and amortization | 1,340 |  |  |  |  | 1,498 |  |  | 2,656 |  |  |  |  | 3,114 |  |
| EBITDA | $ | 2,476 |  |  | 23 | % |  | $ | 2,017 |  |  | $ | 4,494 |  |  | 7 | % |  | $ | 4,183 |  |
| EBITDA | $ | 2,476 |  |  | 23 | % |  | $ | 2,017 |  |  | $ | 4,494 |  |  | 7 | % |  | $ | 4,183 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense | 413 |  |  |  |  | 301 |  |  | 783 |  |  |  |  | 564 |  |
| Impact of purchase accounting (c) | 42 |  |  |  |  | 84 |  |  | 90 |  |  |  |  | 167 |  |
| Transaction-related expenses (d) | 83 |  |  |  |  | 47 |  |  | 159 |  |  |  |  | 89 |  |
| Other corporate expenses (e) | 86 |  |  |  |  | 707 |  |  | 181 |  |  |  |  | 726 |  |
| Adjusted EBITDA | $ | 3,100 |  |  | (2) | % |  | $ | 3,156 |  |  | $ | 5,707 |  |  | — | % |  | $ | 5,729 |  |

[0001571996-20-000045:mdna:90]
[same as prior period, unchanged from 0001571996-20-000034:mdna:87]

[0001571996-20-000045:mdna:91]
(a)See “Results of Operations — Interest and Other, Net” for more information on the components of interest and other, net.

[0001571996-20-000045:mdna:92]
(b)See Note 11 of the Notes to the Condensed Consolidated Financial Statements included in this report for additional information on discrete tax items recorded during the second quarter and first six months of Fiscal 2021 and Fiscal 2020.

[0001571996-20-000045:mdna:93]
(c)This amount includes the non-cash purchase accounting adjustments related to the EMC merger transaction and the going-private transaction.

[0001571996-20-000045:mdna:94]
(d)Transaction-related expenses consist of acquisition, integration, and divestiture related costs.

[0001571996-20-000045:mdna:95]
(e)Other corporate expenses includes impairment charges, severance, facility action, and other costs.

[0001571996-20-000045:mdna:96]
[same as prior period, unchanged from 0001571996-20-000034:mdna:93]

[0001571996-20-000045:mdna:97]
[same as prior period, unchanged from 0001571996-20-000034:mdna:94]

[0001571996-20-000045:mdna:98]
[same as prior period, unchanged from 0001571996-20-000034:mdna:95]

[0001571996-20-000045:mdna:99]
|  | Three Months Ended |  |  |  |  |  |  |  |  |  | Six Months Ended |  |  |  |  |  |  |  |  |
|  | July 31, 2020 |  |  |  |  |  | August 2, 2019 |  |  |  | July 31, 2020 |  |  |  |  |  | August 2, 2019 |  |  |
|  | Dollars |  | % ofNet Revenue |  | %Change |  | Dollars |  | % ofNet Revenue |  | Dollars |  | % ofNet Revenue |  | %Change |  | Dollars |  | % ofNet Revenue |
|  | (in millions, except percentages) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products (a) | $ | 16,737 |  |  | 73.6 | % |  | (7) | % |  | $ | 17,915 |  |  | 76.7 | % |  | $ | 32,775 |  |  | 73.4 | % |  | (5) | % |  | $ | 34,490 |  |  | 76.2 | % |
| Services (a) | 5,996 |  |  | 26.4 | % |  | 10 | % |  | 5,455 |  |  | 23.3 | % |  | 11,855 |  |  | 26.6 | % |  | 10 | % |  | 10,788 |  |  | 23.8 | % |
| Total net revenue | $ | 22,733 |  |  | 100.0 | % |  | (3) | % |  | $ | 23,370 |  |  | 100.0 | % |  | $ | 44,630 |  |  | 100.0 | % |  | (1) | % |  | $ | 45,278 |  |  | 100.0 | % |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products (b) | $ | 3,407 |  |  | 20.4 | % |  | (15) | % |  | $ | 4,026 |  |  | 22.5 | % |  | $ | 6,641 |  |  | 20.3 | % |  | (12) | % |  | $ | 7,522 |  |  | 21.8 | % |
| Services (c) | 3,749 |  |  | 62.5 | % |  | 14 | % |  | 3,300 |  |  | 60.5 | % |  | 7,368 |  |  | 62.2 | % |  | 12 | % |  | 6,601 |  |  | 61.2 | % |
| Total gross margin | $ | 7,156 |  |  | 31.5 | % |  | (2) | % |  | $ | 7,326 |  |  | 31.3 | % |  | $ | 14,009 |  |  | 31.4 | % |  | (1) | % |  | $ | 14,123 |  |  | 31.2 | % |
| Operating expenses | $ | 6,020 |  |  | 26.5 | % |  | (12) | % |  | $ | 6,807 |  |  | 29.1 | % |  | $ | 12,171 |  |  | 27.3 | % |  | (7) | % |  | $ | 13,054 |  |  | 28.8 | % |
| Operating income | $ | 1,136 |  |  | 5.0 | % |  | 119 | % |  | $ | 519 |  |  | 2.2 | % |  | $ | 1,838 |  |  | 4.1 | % |  | 72 | % |  | $ | 1,069 |  |  | 2.4 | % |
| Net income | $ | 1,099 |  |  | 4.8 | % |  | (74) | % |  | $ | 4,232 |  |  | 18.1 | % |  | $ | 1,281 |  |  | 2.9 | % |  | (72) | % |  | $ | 4,561 |  |  | 10.1 | % |
| Net income attributable to Dell Technologies Inc. | $ | 1,048 |  |  | 4.6 | % |  | (69) | % |  | $ | 3,416 |  |  | 14.6 | % |  | $ | 1,191 |  |  | 2.7 | % |  | (68) | % |  | $ | 3,709 |  |  | 8.2 | % |
| Non-GAAP Financial Information |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products (a) | $ | 16,739 |  |  | 73.5 | % |  | (7) | % |  | $ | 17,921 |  |  | 76.4 | % |  | $ | 32,781 |  |  | 73.3 | % |  | (5) | % |  | $ | 34,500 |  |  | 75.9 | % |
| Services (a) | 6,036 |  |  | 26.5 | % |  | 9 | % |  | 5,533 |  |  | 23.6 | % |  | 11,939 |  |  | 26.7 | % |  | 9 | % |  | 10,944 |  |  | 24.1 | % |
| Total non-GAAP net revenue | $ | 22,775 |  |  | 100.0 | % |  | (3) | % |  | $ | 23,454 |  |  | 100.0 | % |  | $ | 44,720 |  |  | 100.0 | % |  | (2) | % |  | $ | 45,444 |  |  | 100.0 | % |
| Non-GAAP gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products (b) | $ | 3,791 |  |  | 22.6 | % |  | (17) | % |  | $ | 4,558 |  |  | 25.4 | % |  | $ | 7,410 |  |  | 22.6 | % |  | (14) | % |  | $ | 8,583 |  |  | 24.9 | % |
| Services (c) | 3,835 |  |  | 63.5 | % |  | 12 | % |  | 3,428 |  |  | 62.0 | % |  | 7,541 |  |  | 63.2 | % |  | 10 | % |  | 6,837 |  |  | 62.5 | % |
| Total non-GAAP gross margin | $ | 7,626 |  |  | 33.5 | % |  | (5) | % |  | $ | 7,986 |  |  | 34.0 | % |  | $ | 14,951 |  |  | 33.4 | % |  | (3) | % |  | $ | 15,420 |  |  | 33.9 | % |
| Non-GAAP operating expenses | $ | 5,008 |  |  | 22.0 | % |  | (4) | % |  | $ | 5,243 |  |  | 22.4 | % |  | $ | 10,172 |  |  | 22.7 | % |  | (3) | % |  | $ | 10,481 |  |  | 23.1 | % |
| Non-GAAP operating income | $ | 2,618 |  |  | 11.5 | % |  | (5) | % |  | $ | 2,743 |  |  | 11.7 | % |  | $ | 4,779 |  |  | 10.7 | % |  | (3) | % |  | $ | 4,939 |  |  | 10.9 | % |
| Non-GAAP net income | $ | 1,621 |  |  | 7.1 | % |  | (7) | % |  | $ | 1,751 |  |  | 7.5 | % |  | $ | 2,764 |  |  | 6.2 | % |  | (7) | % |  | $ | 2,960 |  |  | 6.5 | % |
| EBITDA | $ | 2,476 |  |  | 10.9 | % |  | 23 | % |  | $ | 2,017 |  |  | 8.6 | % |  | $ | 4,494 |  |  | 10.0 | % |  | 7 | % |  | $ | 4,183 |  |  | 9.2 | % |
| Adjusted EBITDA | $ | 3,100 |  |  | 13.6 | % |  | (2) | % |  | $ | 3,156 |  |  | 13.5 | % |  | $ | 5,707 |  |  | 12.8 | % |  | — | % |  | $ | 5,729 |  |  | 12.6 | % |

[0001571996-20-000045:mdna:100]
[same as prior period, unchanged from 0001571996-20-000034:mdna:97]

[0001571996-20-000045:mdna:101]
(a) During Fiscal 2020, Dell Technologies made certain reclassifications of net revenue between the products and services categories on the Consolidated Statement of Net Income (Loss), which impacted previously reported amounts for the second quarter and first six months of Fiscal 2020.  The Company did not recast cost of goods sold for the related revenue reclassifications due to immateriality.  The reclassifications resulted in an increase to services revenue and an equal and offsetting decrease to product revenue of $195 million and $374 million for the second quarter and first six months of Fiscal 2020, respectively.  Total net revenue as previously reported remains unchanged.

[0001571996-20-000045:mdna:102]
77

[0001571996-20-000045:mdna:103]
(b) Product gross margin percentages represent product gross margin as a percentage of product net revenue, and non-GAAP product gross margin percentages represent non-GAAP product gross margin as a percentage of non-GAAP product net revenue.

[0001571996-20-000045:mdna:104]
(c) Services gross margin percentages represent services gross margin as a percentage of services net revenue, and non-GAAP services gross margin percentages represent non-GAAP services gross margin as a percentage of non-GAAP services net revenue.

[0001571996-20-000045:mdna:105]
Non-GAAP product net revenue, non-GAAP services net revenue, non-GAAP net revenue, non-GAAP product gross margin, non-GAAP services gross margin, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, EBITDA, and adjusted EBITDA are not measurements of financial performance prepared in accordance with GAAP.  Non-GAAP financial measures as a percentage of net revenue are calculated based on non-GAAP net revenue.  See “Non-GAAP Financial Measures” for additional information about these non-GAAP financial measures, including our reasons for including these measures, material limitations with respect to the usefulness of the measures, and a reconciliation of each non-GAAP financial measure to the most directly comparable GAAP financial measure.

[0001571996-20-000045:mdna:106]
[same as prior period, unchanged from 0001571996-20-000034:mdna:103]

[0001571996-20-000045:mdna:107]
During the second quarter and first six months of Fiscal 2021, our net revenue decreased 3% and 1%, respectively, as we benefited from the strength of our broad technology solutions portfolio, which helped us navigate market volatility and competitive pressures, particularly due to the COVID-19 environment.  During the second quarter and first six months of Fiscal 2021, our non-GAAP net revenue decreased 3% and 2%, respectively.  Declines in ISG and CSG net revenue were partially offset by an increase in VMware net revenue for both the second quarter and first six months of Fiscal 2021.  VMware net revenue increased as a result of broad-based strength across the portfolio, primarily due to growth in sales of subscriptions and software-as-a-service offerings.  ISG net revenue decreased primarily due to a weaker demand environment as customers continued to direct their investments towards remote work and business continuity solutions.  The decrease in CSG net revenue was primarily driven by lower demand for commercial desktops, partially offset by growth in consumer solutions and continued demand for commercial notebooks.  Although we are in the midst of unprecedented uncertainty as a result of the ongoing COVID-19 pandemic, we believe we are well-positioned for long-term profitable growth while also maintaining the ability to adjust as needed to changing market conditions with complementary solutions across all segments of our business, an agile workforce, and the strength of our global supply chain.

[0001571996-20-000045:mdna:108]
During the second quarter and first six months of Fiscal 2021, our operating income increased 119% and 72%, respectively, primarily due to the absence of Virtustream impairment charges of $619 million recognized in the second quarter and first six months of Fiscal 2020.  Operating income also benefited from increases in operating income for VMware and other businesses, and decreases in amortization of intangible assets.  These benefits were partially offset by decreases in operating income for CSG and ISG and increases in stock-based compensation expense.

[0001571996-20-000045:mdna:109]
Amortization of intangible assets, stock-based compensation expense, and other corporate expenses that impacted our operating income totaled $1.3 billion and $2.1 billion for the second quarter of Fiscal 2021 and Fiscal 2020, respectively, and $2.7 billion and $3.6 billion for the first six months of Fiscal 2021 and Fiscal 2020, respectively.  Excluding these costs, and the impact of purchase accounting and transaction-related expenses, our non-GAAP operating income decreased 5% and 3% during the second quarter and first six months of Fiscal 2021, respectively, due to decreases in operating income for ISG and CSG, which were partially offset by increases in operating income for VMware and other businesses.

[0001571996-20-000045:mdna:110]
Cash provided by operating activities was $2.5 billion for the first six months of Fiscal 2021 compared to $4.0 billion for the first six months of Fiscal 2020.  The decrease in operating cash flows during the first six months of Fiscal 2021 was primarily attributable to unfavorable working capital impacts of an increase in inventory related to the COVID-19 pandemic and timing of purchases and payments to vendors.  See “Market Conditions, Liquidity, and Capital Commitments” for further information on our cash flow metrics.

[0001571996-20-000045:mdna:111]
[same as prior period, unchanged from 0001571996-20-000034:mdna:108]

[0001571996-20-000045:mdna:112]
During the second quarter and first six months of Fiscal 2021, our net revenue decreased 3% and 1%, respectively.  During the second quarter and first six months of Fiscal 2021, our non-GAAP net revenue decreased 3% and 2%, respectively.  The decreases in net revenue and non-GAAP net revenue were primarily attributable to declines in net revenue in CSG and ISG, which were partially offset by increases in VMware net revenue.  See “Business Unit Results” for further information.

[0001571996-20-000045:mdna:113]
[same as prior period, unchanged from 0001571996-20-000034:mdna:178]

[0001571996-20-000045:mdna:114]
•Product Net Revenue — Product net revenue includes revenue from the sale of hardware products and software licenses.  During the second quarter and first six months of Fiscal 2021, product net revenue decreased 7% and 5%, respectively.  During the second quarter and first six months of Fiscal 2021, non-GAAP product net revenue also decreased 7% and 5%, respectively.  The decreases in product net revenue and non-GAAP product net revenue were due to decreases in product net revenue for ISG and CSG.  The decrease in CSG product net revenue was driven by a decline in sales of commercial desktops during the second quarter and first six months of Fiscal 2021.

[0001571996-20-000045:mdna:115]
•Services Net Revenue — Services net revenue includes revenue from our services offerings and support services related to hardware products and software licenses.  Services net revenue increased 10% during both the second quarter and first six months of Fiscal 2021.  Non-GAAP services net revenue increased 9% during both the second quarter and first six months of Fiscal 2021.  The increases in services net revenue and non-GAAP services net revenue were primarily attributable to increases in services net revenue for CSG third-party software and maintenance and VMware software.  A substantial portion of services net revenue is derived from offerings that have been deferred over a period of time, and, as a result, reported services net revenue growth rates will be different than reported product net revenue growth rates.

[0001571996-20-000045:mdna:116]
From a geographical perspective, net revenue generated by sales to customers in the all regions decreased during the second quarter of Fiscal 2021 due to a weaker demand environment for ISG and CSG stemming from continuing macro-economic challenges.

[0001571996-20-000045:mdna:117]
During the first six months of Fiscal 2021, net revenue generated by sales to customers in the Americas increased primarily as a result of strong performance in CSG during the first quarter of Fiscal 2021.  In EMEA, net revenue from sales to customers decreased due to a weaker demand environment for ISG.  In APJ, a weaker demand environment for ISG and CSG drove the decrease in net revenue from sales to customers.

[0001571996-20-000045:mdna:118]
[same as prior period, unchanged from 0001571996-20-000034:mdna:113]

[0001571996-20-000045:mdna:119]
During the second quarter and first six months of Fiscal 2021, our gross margin decreased 2% to $7.2 billion and 1% to $14.0 billion, respectively.  The decreases in our gross margin during the second quarter and first six months of Fiscal 2021 were driven by gross margin decreases for ISG and CSG, partially offset by favorable impacts of gross margin increases in VMware and decreases in amortization of intangible assets.  During the second quarter and first six months of Fiscal 2021, our gross margin percentage increased 20 basis points to 31.5% and 20 basis points to 31.4%, respectively.  The increases in our gross margin percentage during the second quarter and first six months of Fiscal 2021 were primarily driven by favorable impacts of gross margin percentage increases for VMware and other businesses, and decreases in amortization of intangible assets and purchase accounting adjustments.  These impacts were largely offset by the decreases in gross margin percentages for ISG and CSG.

[0001571996-20-000045:mdna:120]
Our gross margin included the impact of amortization of intangibles and purchase accounting adjustments of $0.4 billion and $0.6 billion for the second quarter of Fiscal 2021 and Fiscal 2020, respectively, and $0.8 billion and $1.2 billion during the first six months of Fiscal 2021 and Fiscal 2020, respectively.  Excluding these costs, transaction-related expenses, stock-based compensation expense, and other corporate expenses, non-GAAP gross margin during the second quarter and first six months of Fiscal 2021 decreased 5% to $7.6 billion and 3% to $15.0 billion, respectively.  Non-GAAP gross margin percentage decreased 50 basis points to 33.5% and 50 basis points to 33.4% during the second quarter and first six months of Fiscal 2021, respectively.

[0001571996-20-000045:mdna:121]
During the second quarter and first six months of Fiscal 2021, the decreases in our non-GAAP gross margin and non-GAAP gross margin percentage were attributable to higher product costs for CSG and ISG and a shift in product mix within CSG.  These negative impacts were partially offset by increases in gross margin and gross margin percentage for VMware and other businesses.

[0001571996-20-000045:mdna:122]
•Products — During the second quarter of Fiscal 2021, product gross margin decreased 15% to $3.4 billion, and product gross margin percentage decreased 210 basis points to 20.4%.  The decreases in product gross margin and product gross margin percentage were primarily driven by higher product costs for CSG and ISG and a shift in product mix within CSG.  These unfavorable impacts were partially offset by a decrease in amortization of intangibles.  During the second quarter of Fiscal 2021, non-GAAP product gross margin decreased 17% to $3.8 billion, and non-GAAP product gross margin percentage decreased 280 basis points to 22.6% due to the same CSG and ISG dynamics discussed above.

[0001571996-20-000045:mdna:123]
During the first six months of Fiscal 2021, product gross margin decreased 12% to $6.6 billion, and product gross margin percentage decreased 150 basis points to 20.3%.  The decreases in product gross margin and product gross margin percentage were primarily driven by higher product costs for CSG and ISG and a shift in product mix within CSG.  These unfavorable impacts were partially offset by a decrease in amortization of intangibles.  During the first six months of Fiscal 2021, non-GAAP product gross margin decreased 14% to $7.4 billion, and non-GAAP product gross margin percentage decreased 230 basis points to 22.6% due to the same CSG and ISG dynamics discussed above.

[0001571996-20-000045:mdna:124]
•Services — During the second quarter of Fiscal 2021, services gross margin increased 14% to $3.7 billion, and services gross margin percentage increased 200 basis points to 62.5%.  Services gross margin increased due to growth in VMware software maintenance and CSG third-party software and maintenance, and a decrease in purchase accounting adjustments.  Excluding purchase accounting adjustments, transaction-related expenses, stock-based compensation expense, and other corporate expenses, non-GAAP services gross margin increased 12% to $3.8 billion during the second quarter of Fiscal 2021 primarily due to growth in VMware software maintenance and CSG third-party software and maintenance.  Non-GAAP services gross margin percentage increased 150 basis points to 63.5% due to increases in services gross margin percentages across all segments.

[0001571996-20-000045:mdna:125]
During the first six months of Fiscal 2021, services gross margin increased 12% to $7.4 billion, and services gross margin percentage increased 100 basis points to 62.2%.  Services gross margin increased due to growth in VMware software maintenance and CSG third-party software and maintenance, and a decrease in purchase accounting adjustments.  Excluding purchase accounting adjustments, transaction-related expenses, stock-based compensation expense, and other corporate expenses, non-GAAP services gross margin increased 10% to $7.5 billion during the first six months of Fiscal 2021 primarily due to growth in VMware software maintenance and CSG third-party software and maintenance.  Non-GAAP services gross margin percentage increased 70 basis points to 63.2% primarily due to an increase in VMware services gross margin percentage.

[0001571996-20-000045:mdna:126]
[same as prior period, unchanged from 0001571996-20-000034:mdna:118]

[0001571996-20-000045:mdna:127]
[same as prior period, unchanged from 0001571996-20-000034:mdna:119]

[0001571996-20-000045:mdna:128]
The terms and conditions of our vendor rebate programs are largely based on product volumes and are generally negotiated either at the beginning of the annual or quarterly period, depending on the program.  The timing and amount of vendor rebates and other discounts we receive under the programs may vary from period to period, reflecting changes in the competitive environment.  We monitor our component costs and seek to address the effects of any changes to terms that might arise under our vendor rebate programs.  Our gross margins for the second quarter and first six months of Fiscal 2021 and Fiscal 2020 were not materially affected by any changes to the terms of our vendor rebate programs, as the amounts we received under these programs were generally stable relative to our total net cost.  We are not aware of any significant changes to vendor pricing or rebate programs that may impact our results in the near term.

[0001571996-20-000045:mdna:129]
80

[0001571996-20-000045:mdna:130]
[same as prior period, unchanged from 0001571996-20-000034:mdna:122]

[0001571996-20-000045:mdna:131]
[same as prior period, unchanged from 0001571996-20-000034:mdna:123]

[0001571996-20-000045:mdna:132]
|  | Three Months Ended |  |  |  |  |  |  |  |  |  | Six Months Ended |  |  |  |  |  |  |  |  |
|  | July 31, 2020 |  |  |  |  |  | August 2, 2019 |  |  |  | July 31, 2020 |  |  |  |  |  | August 2, 2019 |  |  |
|  | Dollars |  | % ofNet Revenue |  | %Change |  | Dollars |  | % ofNet Revenue |  | Dollars |  | % ofNet Revenue |  | %Change |  | Dollars |  | % ofNet Revenue |
|  | (in millions, except percentages) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative | $ | 4,761 |  |  | 21.0 | % |  | (15) | % |  | $ | 5,578 |  |  | 23.8 | % |  | $ | 9,647 |  |  | 21.6 | % |  | (9) | % |  | $ | 10,649 |  |  | 23.5 | % |
| Research and development | 1,259 |  |  | 5.5 | % |  | 2 | % |  | 1,229 |  |  | 5.3 | % |  | 2,524 |  |  | 5.7 | % |  | 5 | % |  | 2,405 |  |  | 5.3 | % |
| Total operating expenses | $ | 6,020 |  |  | 26.5 | % |  | (12) | % |  | $ | 6,807 |  |  | 29.1 | % |  | $ | 12,171 |  |  | 27.3 | % |  | (7) | % |  | $ | 13,054 |  |  | 28.8 | % |
| Other Financial Information |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP operating expenses | $ | 5,008 |  |  | 22.0 | % |  | (4) | % |  | $ | 5,243 |  |  | 22.4 | % |  | $ | 10,172 |  |  | 22.7 | % |  | (3) | % |  | $ | 10,481 |  |  | 23.1 | % |

[0001571996-20-000045:mdna:133]
During the second quarter and first six months of Fiscal 2021, total operating expenses decreased 12% and 7%, respectively, primarily due to a decrease in selling, general and administrative expenses, offset partially by an increase in research and development expenses.  Our operating expenses include amortization of intangible assets, the impact of purchase accounting, transaction-related expenses, stock-based compensation expense, and other corporate expenses.  In aggregate, these items totaled $1.0 billion and $1.6 billion for the second quarter of Fiscal 2021 and Fiscal 2020, respectively, and $2.0 billion and $2.6 billion for the first six months of Fiscal 2021 and Fiscal 2020, respectively.  Excluding these costs, total non-GAAP operating expenses decreased 4% and 3% for the second quarter and first six months of Fiscal 2021, respectively.

[0001571996-20-000045:mdna:134]
•Selling, General, and Administrative — Selling, general, and administrative (“SG&A”) expenses decreased 15% and 9%, respectively, during the second quarter and first six months of Fiscal 2021.  The decreases in SG&A expenses were primarily due to the absence of Virtustream impairment charges of $619 million recognized in the second quarter and first six months of Fiscal 2020.  SG&A expenses also decreased due to measures taken as a result of the COVID-19 pandemic, which included global hiring limitations, reduction in consulting and contractor costs, global travel restrictions, suspension of the Dell 401(k) match program for U.S. employees, and lower facilities-related costs, as well as a decrease in amortization of intangible assets.  With respect to our cost reduction initiatives, we expect that some of the benefits which we recognized during the second quarter and first six months of Fiscal 2021 will phase out over time.

[0001571996-20-000045:mdna:135]
•Research and Development — Research and development (“R&D”) expenses are primarily composed of personnel-related expenses related to product development.  R&D expenses as a percentage of net revenue were approximately 5.5% and 5.3% for the second quarter of Fiscal 2021 and Fiscal 2020, respectively, and 5.7% and 5.3% for the first six months of Fiscal 2021 and Fiscal 2020, respectively.  R&D expenses as a percentage of net revenue increased during the second quarter and first six months of Fiscal 2021 primarily due to an increase in compensation-related expense, including stock-based compensation expense, driven by VMware.  As our industry continues to change and as the needs of our customers evolve, we intend to support R&D initiatives to innovate and introduce new and enhanced solutions into the market.

[0001571996-20-000045:mdna:136]
[same as prior period, unchanged from 0001571996-20-000034:mdna:128]

[0001571996-20-000045:mdna:137]
[same as prior period, unchanged from 0001571996-20-000034:mdna:129]

[0001571996-20-000045:mdna:138]
During the second quarter and first six months of Fiscal 2021, our operating income increased 119% and 72%, respectively.  The increases in our operating income for the second quarter and first six months of Fiscal 2021 were primarily attributable to the absence of Virtustream impairment charges of $619 million recognized in the second quarter and first six months of Fiscal 2020.  Operating income also benefited from increases in operating income for VMware and decreases in amortization of

[0001571996-20-000045:mdna:139]
intangible assets.  These benefits were partially offset by decreases in operating income for CSG and ISG and increases in stock-based compensation expense.

[0001571996-20-000045:mdna:140]
Amortization of intangible assets, stock-based compensation expense, and other corporate expenses that impacted our operating income totaled $1.3 billion and $2.1 billion for the second quarter of Fiscal 2021 and Fiscal 2020, respectively, and $2.7 billion and $3.6 billion for the first six months of Fiscal 2021 and Fiscal 2020, respectively.  Excluding these costs, and the impact of purchase accounting and transaction-related expenses, our non-GAAP operating income decreased 5% to $2.6 billion and 3% to $4.8 billion during the second quarter and first six months of Fiscal 2021, respectively.  The decreases in our non-GAAP operating income for the second quarter and first six months of Fiscal 2021 were primarily due to decreases in operating income for ISG and CSG, which were partially offset by increases in operating income for VMware and other businesses.

[0001571996-20-000045:mdna:141]
[same as prior period, unchanged from 0001571996-20-000034:mdna:133]

[0001571996-20-000045:mdna:142]
[same as prior period, unchanged from 0001571996-20-000034:mdna:134]

[0001571996-20-000045:mdna:143]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | July 31, 2020 |  | August 2, 2019 |  | July 31, 2020 |  | August 2, 2019 |
|  | (in millions) |  |  |  |  |  |  |
| Interest and other, net: |  |  |  |  |  |  |  |
| Investment income, primarily interest | $ | 12 |  |  | $ | 42 |  |  | $ | 36 |  |  | $ | 86 |  |
| Gain on investments, net | 8 |  |  | 80 |  |  | 102 |  |  | 142 |  |
| Interest expense | (617) |  |  | (692) |  |  | (1,289) |  |  | (1,391) |  |
| Foreign exchange | — |  |  | (35) |  |  | (99) |  |  | (80) |  |
| Other | (39) |  |  | (25) |  |  | 48 |  |  | (80) |  |
| Total interest and other, net | $ | (636) |  |  | $ | (630) |  |  | $ | (1,202) |  |  | $ | (1,323) |  |

[0001571996-20-000045:mdna:144]
During the second quarter of Fiscal 2021, interest and other, net was relatively unchanged, as debt extinguishment costs and lower gains on the sale of strategic investments were offset by a decrease in interest expense.  During the first six months of Fiscal 2021, the change in interest and other, net was favorable by $121 million primarily due to a gain of $120 million recognized from the sale of certain intellectual property assets during the first quarter of Fiscal 2021.

[0001571996-20-000045:mdna:145]
[same as prior period, unchanged from 0001571996-20-000034:mdna:137]

[0001571996-20-000045:mdna:146]
For the second quarter of Fiscal 2021 and Fiscal 2020, our effective income tax rates were -119.8% on pre-tax income of $500 million and 3912.6% on pre-tax losses of $111 million, respectively.  For the first six months of Fiscal 2021 and Fiscal 2020, our effective income tax rates were -101.4% on pre-tax income of $636 million and 1895.7% on pre-tax losses of $254 million, respectively.  The changes in our effective tax rates were primarily driven by discrete tax items and changes in our jurisdictional mix of income.  For the second quarter and first six months of Fiscal 2021, our effective income tax rate benefit includes $746 million of discrete tax benefits related to an audit settlement.  For the first six months of Fiscal 2021, our effective income tax rate benefit also includes a discrete tax benefit of $59 million from an intra-entity asset transfer of certain of Pivotal’s intellectual property to an Irish subsidiary that was completed by VMware, Inc. during the period.  For the second quarter and first six months of Fiscal 2020, our effective tax rates include discrete tax benefits of $4.5 billion and $4.9 billion, respectively, related to similar intra-entity asset transfers.  The tax benefit for each intra-entity asset transfer was recorded as a deferred tax asset in the period of transaction and represents the book and tax basis difference on the transferred assets measured based on the applicable Irish statutory tax rate.  We expect to be able to realize the deferred tax assets resulting from these intra-entity asset transfers.

[0001571996-20-000045:mdna:147]
Our effective income tax rate can fluctuate depending on the geographic distribution of our worldwide earnings, as our foreign earnings are generally taxed at lower rates than in the United States.  The differences between our effective income tax rate and the U.S. federal statutory rate of 21% principally result from the geographical distribution of income, differences between the book and tax treatment of certain items, and the discrete tax items discussed above.  In certain jurisdictions, our tax rate is significantly less than the applicable statutory rate as a result of tax holidays.  The majority of our foreign income that is subject to these tax holidays and lower tax rates is attributable to Singapore, China, and Malaysia.  A significant portion of these income tax benefits relates to a tax holiday that will be effective until January 31, 2029.  Our other tax holidays will expire in whole or in part during Fiscal 2022 through Fiscal 2030.  Many of these tax holidays and reduced tax rates may be extended

[0001571996-20-000045:mdna:148]
when certain conditions are met or may be terminated early if certain conditions are not met.  As of July 31, 2020, we were not aware of any matters of non-compliance related to these tax holidays.  The effective income tax rate for future quarters of Fiscal 2021 may be impacted by the actual mix of jurisdictions in which income is generated.

[0001571996-20-000045:mdna:149]
[same as prior period, unchanged from 0001571996-20-000034:mdna:140]

[0001571996-20-000045:mdna:150]
[same as prior period, unchanged from 0001571996-20-000034:mdna:141]

[0001571996-20-000045:mdna:151]
During the second quarter and first six months of Fiscal 2021, net income decreased 74% to $1.1 billion and 72% to $1.3 billion, respectively.  The decreases in net income during the second quarter and first six months of Fiscal 2021 were primarily due to lower discrete tax benefits, which were partially offset by increases in operating income.

[0001571996-20-000045:mdna:152]
Net income for the second quarter and first six months of Fiscal 2021 and Fiscal 2020 included amortization of intangible assets, the impact of purchase accounting, transaction-related expenses, stock-based compensation expense, other corporate expenses, fair value adjustments on equity investments, and discrete tax items.  Excluding these costs and the related tax impacts, non-GAAP net income decreased 7% to $1.6 billion and 7% to $2.8 billion, respectively.  The decreases in non-GAAP net income during the second quarter and first six months of Fiscal 2021 were primarily attributable to decreases in non-GAAP operating income and increases in non-GAAP income taxes.

[0001571996-20-000045:mdna:153]
[same as prior period, unchanged from 0001571996-20-000034:mdna:144]

[0001571996-20-000045:mdna:154]
During the second quarter and first six months of Fiscal 2021, net income attributable to non-controlling interests was $51 million and $90 million, respectively, and consisted of net income or loss attributable to our non-controlling interests in VMware, Inc. and Secureworks.  During the second quarter and first six months of Fiscal 2020, net income attributable to non-controlling interests was $816 million and $852 million, respectively, and consisted of net income or loss attributable to our non-controlling interests in VMware, Inc., Secureworks, and Pivotal.  Pivotal was acquired by VMware, Inc. on December 30, 2019 and, as a result, we no longer have a separate non-controlling interest in Pivotal.  The decreases in net income attributable to non-controlling interests during the second quarter and first six months of Fiscal 2021 were attributable to decreases in net income attributable to our non-controlling interest in VMware, Inc.  For more information about our non-controlling interests, see Note 13 of the Notes to the Condensed Consolidated Financial Statements included in this report.

[0001571996-20-000045:mdna:155]
[same as prior period, unchanged from 0001571996-20-000034:mdna:147]

[0001571996-20-000045:mdna:156]
Net income attributable to Dell Technologies Inc. represents net income and an adjustment for non-controlling interests.  During the second quarter and first six months of Fiscal 2021, net income attributable to Dell Technologies Inc. was $1.0 billion and $1.2 billion, respectively.  During the second quarter and first six months of Fiscal 2020, net income attributable to Dell Technologies Inc. was $3.4 billion and $3.7 billion, respectively.  The decreases in net income attributable to Dell Technologies Inc. during the second quarter and first six months of Fiscal 2021 were primarily attributable to decreases in net income for the periods.

[0001571996-20-000045:mdna:157]
[same as prior period, unchanged from 0001571996-20-000034:mdna:222]

[0001571996-20-000045:mdna:158]
[same as prior period, unchanged from 0001571996-20-000034:mdna:149]

[0001571996-20-000045:mdna:159]
[same as prior period, unchanged from 0001571996-20-000034:mdna:150]

[0001571996-20-000045:mdna:160]
[same as prior period, unchanged from 0001571996-20-000034:mdna:151]

[0001571996-20-000045:mdna:161]
[same as prior period, unchanged from 0001571996-20-000034:mdna:152]

[0001571996-20-000045:mdna:162]
|  | Three Months Ended |  |  |  |  |  | Six Months Ended |  |  |  |  |
|  | July 31, 2020 |  | % Change |  | August 2, 2019 |  | July 31, 2020 |  | % Change |  | August 2, 2019 |
|  | (in millions, except percentages) |  |  |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Servers and networking | $ | 4,196 |  |  | (5) | % |  | $ | 4,437 |  |  | $ | 7,954 |  |  | (8) | % |  | $ | 8,617 |  |
| Storage | 4,011 |  |  | (4) | % |  | 4,184 |  |  | 7,822 |  |  | (5) | % |  | 8,206 |  |
| Total ISG net revenue | $ | 8,207 |  |  | (5) | % |  | $ | 8,621 |  |  | $ | 15,776 |  |  | (6) | % |  | $ | 16,823 |  |
| Operating income: |  |  |  |  |  |  |  |  |  |  |  |
| ISG operating income | $ | 973 |  |  | (7) | % |  | $ | 1,050 |  |  | $ | 1,705 |  |  | (10) | % |  | $ | 1,893 |  |
| % of segment net revenue | 11.9 | % |  |  |  | 12.2 | % |  | 10.8 | % |  |  |  | 11.3 | % |

[0001571996-20-000045:mdna:163]
Net Revenue — During the second quarter and first six months of Fiscal 2021, ISG net revenue decreased 5% and 6%, respectively, due to decreases in sales of servers and networking and storage.  ISG net revenue decreased primarily due to a weaker demand environment, as customers restricted technology spending and directed their investments toward remote work and business continuity solutions.  Revenue from the sales of servers and networking decreased 5% and 8% during the second quarter and first six months of Fiscal 2021, respectively, primarily driven by decreases in average selling prices for servers resulting from competitive pressures in certain geographies, and, to a lesser extent, declines in units sold of our PowerEdge servers due to the broader macro-economic environment, including the effects of COVID-19.

[0001571996-20-000045:mdna:164]
Storage revenue decreased 4% and 5% during the second quarter and first six months of Fiscal 2021, respectively, primarily due to declines in demand for our core storage solutions offerings, partially offset by increased demand for data protection and hyperconverged infrastructure solutions.  We continue to make enhancements to our storage solutions offerings and expect that these offerings, including the release of our new PowerStore storage array in May 2020, will drive long-term improvements in the business.

[0001571996-20-000045:mdna:165]
[same as prior period, unchanged from 0001571996-20-000034:mdna:155]

[0001571996-20-000045:mdna:166]
From a geographical perspective, net revenue attributable to ISG decreased in all regions during both the second quarter and first six months of Fiscal 2021, driven by a weaker demand environment as a result of pervasive global COVID-19 disruptions.

[0001571996-20-000045:mdna:167]
Operating Income — During the second quarter of Fiscal 2021, ISG operating income as a percentage of net revenue decreased 30 basis points to 11.9%.  During the first six months of Fiscal 2021, ISG operating income as a percentage of net revenue decreased 50 basis points to 10.8%.  The declines in operating income percentages during the second quarter and first six months of Fiscal 2021 were driven by a decline in gross margin percentages for servers and networking, which was attributable to higher product costs and competitive pricing dynamics.  During the second quarter of Fiscal 2021, the decline in ISG gross margin percentage was partially offset by a decrease in operating expenses as a percentage of revenue, as we realized the benefit of cost reduction initiatives.

[0001571996-20-000045:mdna:168]
[same as prior period, unchanged from 0001571996-20-000034:mdna:229]

[0001571996-20-000045:mdna:169]
We will continue to monitor our pricing in response to the changing competitive and component cost environment.  We currently expect the ISG component cost environment will be inflationary in the aggregate during the third quarter of Fiscal 2021 and then will return to a deflationary environment in the fourth quarter of Fiscal 2021.  This may put pressure on ISG operating results, particularly for servers and networking.

[0001571996-20-000045:mdna:170]
[same as prior period, unchanged from 0001571996-20-000034:mdna:158]

[0001571996-20-000045:mdna:171]
[same as prior period, unchanged from 0001571996-20-000034:mdna:159]

[0001571996-20-000045:mdna:172]
|  | Three Months Ended |  |  |  |  |  | Six Months Ended |  |  |  |  |
|  | July 31, 2020 |  | % Change |  | August 2, 2019 |  | July 31, 2020 |  | % Change |  | August 2, 2019 |
|  | (in millions, except percentages) |  |  |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 8,039 |  |  | (11) | % |  | $ | 9,077 |  |  | $ | 16,673 |  |  | (4) | % |  | $ | 17,384 |  |
| Consumer | 3,164 |  |  | 18 | % |  | 2,671 |  |  | 5,634 |  |  | 7 | % |  | 5,274 |  |
| Total CSG net revenue | $ | 11,203 |  |  | (5) | % |  | $ | 11,748 |  |  | $ | 22,307 |  |  | (2) | % |  | $ | 22,658 |  |
| Operating income: |  |  |  |  |  |  |  |  |  |  |  |
| CSG operating income | $ | 715 |  |  | (27) | % |  | $ | 982 |  |  | $ | 1,307 |  |  | (26) | % |  | $ | 1,775 |  |
| % of segment net revenue | 6.4 | % |  |  |  | 8.4 | % |  | 5.9 | % |  |  |  | 7.8 | % |

[0001571996-20-000045:mdna:173]
Net Revenue — During the second quarter and first six months of Fiscal 2021, CSG net revenue decreased 5% and 2%, respectively, primarily due to decreases in commercial desktop sales, partially offset by increases in commercial and consumer notebook sales.  Much of this demand was driven by the imperative for remote work and remote learning solutions, as business, government, and education customers sought to maintain productivity in the midst of COVID-19.

[0001571996-20-000045:mdna:174]
Commercial revenue decreased 11% and 4% during the second quarter and first six months of Fiscal 2021, respectively, primarily due to lower demand for commercial desktops.  The decline in demand for commercial desktops was partially offset by an increase in demand for entry-level commercial notebooks, driven by customers in education and state and local government.  Consumer revenue increased 18% and 7% during the second quarter and first six months of Fiscal 2021, respectively, due to increased demand for consumer notebooks and high-end and gaming systems during the second quarter of Fiscal 2021, which more than offset the weakness in consumer demand during the first quarter of Fiscal 2021.

[0001571996-20-000045:mdna:175]
From a geographical perspective, net revenue attributable to CSG decreased in all regions during the second quarter of Fiscal 2021.  During the first six months of Fiscal 2021, net revenue in the Americas and EMEA increased despite weaker demand in the second quarter of Fiscal 2021.  In APJ, net revenue decreased during the first six months of Fiscal 2021.

[0001571996-20-000045:mdna:176]
Operating Income — During the second quarter of Fiscal 2021, CSG operating income as a percentage of net revenue decreased 200 basis points to 6.4%.  During the first six months of Fiscal 2021, CSG operating income as a percentage of net revenue decreased 190 basis points to 5.9%.  The decreases were primarily due to decreases in gross margin percentage, partially offset by a decrease in operating expenses as a percentage of revenue, as we realized the benefit of cost reduction initiatives.  Gross margin percentage decreases were principally driven by higher product costs and a shift in mix to consumer solutions.

[0001571996-20-000045:mdna:177]
We will continue to monitor our pricing in response to the changing competitive and component cost environment.  We expect the CSG component cost environment will be relatively flat in the third quarter of Fiscal 2021 and then will return to a deflationary environment in the fourth quarter of Fiscal 2021.  Higher mix in consumer demand and the related shift in product mix are expected to continue into the second half of Fiscal 2021, which may put pressure on CSG operating results.

[0001571996-20-000045:mdna:178]
85

[0001571996-20-000045:mdna:179]
[same as prior period, unchanged from 0001571996-20-000034:mdna:165]

[0001571996-20-000045:mdna:180]
[same as prior period, unchanged from 0001571996-20-000034:mdna:166]

[0001571996-20-000045:mdna:181]
|  | Three Months Ended |  |  |  |  |  | Six Months Ended |  |  |  |  |
|  | July 31, 2020 |  | % Change |  | August 2, 2019 |  | July 31, 2020 |  | % Change |  | August 2, 2019 |
|  | (in millions, except percentages) |  |  |  |  |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| VMware net revenue | $ | 2,908 |  |  | 10 | % |  | $ | 2,651 |  |  | $ | 5,663 |  |  | 11 | % |  | $ | 5,108 |  |
| Operating income: |  |  |  |  |  |  |  |  |  |  |  |
| VMware operating income | $ | 894 |  |  | 19 | % |  | $ | 751 |  |  | $ | 1,667 |  |  | 24 | % |  | $ | 1,346 |  |
| % of segment net revenue | 30.7 | % |  |  |  | 28.3 | % |  | 29.4 | % |  |  |  | 26.4 | % |

[0001571996-20-000045:mdna:182]
Net Revenue — VMware net revenue, inclusive of Pivotal, primarily consists of revenue from the sale of software licenses under perpetual licenses and subscription and software-as-a-service (“SaaS”) offerings, as well as related software maintenance services, support, training, consulting services, and hosted services.  VMware net revenue for the second quarter and first six months of Fiscal 2021 increased 10% and 11%, respectively, primarily due to growth in sales of subscriptions and SaaS offerings, as well as an increase in sales of software maintenance services.  Growth in sales of subscriptions and SaaS offerings was primarily driven by increased demand for hybrid cloud offerings and digital workspaces.  Software maintenance revenue benefited from maintenance contracts sold in previous periods.

[0001571996-20-000045:mdna:183]
From a geographical perspective, approximately half of VMware net revenue during the second quarter and first six months of Fiscal 2021 was generated by sales to customers in the United States.  VMware net revenue for the second quarter and first six months of Fiscal 2021 increased in both the United States and internationally.

[0001571996-20-000045:mdna:184]
Operating Income — During the second quarter and first six months of Fiscal 2021, VMware operating income as a percentage of net revenue increased 240 basis points to 30.7% and 300 basis points to 29.4%, respectively.  The increases were primarily driven by decreases in selling, general, and administrative expenses as a percentage of net revenue.  While the COVID-19 pandemic has not had a significant adverse financial impact on VMware operations to date, in future periods we expect a negative impact on VMware results of operations, the size and duration of which we are currently unable to predict.

[0001571996-20-000045:mdna:185]
86

[0001571996-20-000045:mdna:186]
[same as prior period, unchanged from 0001571996-20-000034:mdna:171]

[0001571996-20-000045:mdna:187]
[same as prior period, unchanged from 0001571996-20-000034:mdna:172]

[0001571996-20-000045:mdna:188]
We sell products and services directly to customers and through a variety of sales channels, including retail distribution.  Our accounts receivable, net, was $11.6 billion and $12.5 billion as of July 31, 2020 and January 31, 2020, respectively.  We maintain an allowance for expected credit losses to cover receivables that may be deemed uncollectible.  The allowance for expected credit losses is an estimate based on an analysis of historical loss experience, current receivables aging, and management’s assessment of current conditions and reasonable and supportable expectation of future conditions, as well as specific identifiable customer accounts that are deemed at risk.  Our analysis includes assumptions regarding the impact of COVID-19 and continued market volatility, which is highly uncertain and subject to significant judgment.  Given this uncertainty, our allowance for expected credit losses in future periods may vary from our current estimates.  As of July 31, 2020 and January 31, 2020, the allowance for expected credit losses was $146 million and $94 million, respectively.  Allowance for expected credit losses of trade receivables as of July 31, 2020 includes the impact of adoption of the new current expected credit losses (“CECL”) standard, which was adopted as of February 1, 2020 using the modified retrospective method.  Based on our assessment, we believe that we are adequately reserved for expected credit losses.  We will continue to monitor the aging of our accounts receivable and take actions, where necessary, to reduce our exposure to credit losses.

[0001571996-20-000045:mdna:189]
[same as prior period, unchanged from 0001571996-20-000034:mdna:174]

[0001571996-20-000045:mdna:190]
Dell Financial Services and its affiliates (“DFS”) support Dell Technologies by offering and arranging various financing options and services for our customers globally, including through captive financing operations in North America, Europe, Australia, and New Zealand.  DFS originates, collects, and services customer receivables primarily related to the purchase of our product, software, and service solutions.  DFS further strengthens our customer relationships through its flexible consumption models, which enable us to offer our customers the option to pay over time and, in certain cases, based on utilization, to provide them with financial flexibility to meet their changing technological requirements.  New financing originations were $2.6 billion and $2.0 billion for the second quarter of Fiscal 2021 and Fiscal 2020, respectively, and $4.4 billion and $3.7 billion for the first six months of Fiscal 2021 and Fiscal 2020, respectively.

[0001571996-20-000045:mdna:191]
[same as prior period, unchanged from 0001571996-20-000034:mdna:176]

[0001571996-20-000045:mdna:192]
As of July 31, 2020 and January 31, 2020, our financing receivables, net were $10.2 billion and $9.7 billion, respectively.  We maintain an allowance to cover expected financing receivable credit losses and evaluate credit loss expectations based on our total portfolio.  Allowance for expected credit losses of financing receivables as of July 31, 2020 includes the impact of adoption of the CECL standard referred to above.  Our analysis includes assumptions regarding the impact of COVID-19 and continued market volatility, which is highly uncertain and subject to significant judgment.  Given this uncertainty, our allowance for expected credit losses in future periods may vary from our current estimates.  For the second quarter of Fiscal 2021 and Fiscal 2020, the principal charge-off rate for our total portfolio was 0.8% and 1.1%, respectively.  For the first six months of Fiscal 2021 and Fiscal 2020, the principal charge-off rate for our total portfolio was 0.9% and 1.0%, respectively.  The credit quality of our financing receivables has improved in recent years due to an overall improvement in the credit environment and as the mix of high-quality commercial accounts in our portfolio has continued to increase.  We continue to monitor broader economic indicators and their potential impact on future loss performance.  We have an extensive process to manage our exposure to customer credit risk, including active management of credit lines and our collection activities.  We also sell selected fixed-term financing receivables without recourse to unrelated third parties on a periodic basis, primarily to manage certain concentrations of customer credit exposure.  Based on our assessment of the customer financing receivables, we believe that we are adequately reserved.

[0001571996-20-000045:mdna:193]
We retain a residual interest in equipment leased under our lease programs.  As of July 31, 2020 and January 31, 2020, the residual interest recorded as part of financing receivables was $523 million and $582 million, respectively.  The amount of the residual interest is established at the inception of the lease based upon estimates of the value of the equipment at the end of the lease term using historical studies, industry data, and future value-at-risk demand valuation methods.  On a quarterly basis, we assess the carrying amount of our recorded residual values for impairment.  Generally, residual value risk on equipment under lease is not considered to be significant, because of the existence of a secondary market with respect to the equipment.  The lease agreement also clearly defines applicable return conditions and remedies for non-compliance, to ensure that the leased equipment will be in good operating condition upon return.  Model changes and updates, as well as market strength and product acceptance, are monitored and adjustments are made to residual values in accordance with the significance of any such changes.  Our remarketing sales staff works closely with customers and dealers to manage the sale of lease returns and the recovery of residual exposure.  No impairment losses were recorded related to residual assets during the second quarter and first six months of Fiscal 2021.

[0001571996-20-000045:mdna:194]
As of July 31, 2020 and January 31, 2020, equipment under operating leases, net was $1.2 billion and $0.8 billion, respectively.  Based on triggering events, we assess the carrying amount of the equipment under operating leases recorded for impairment.  No material impairment losses were recorded related to such equipment during the second quarter and first six months of Fiscal 2021.

[0001571996-20-000045:mdna:195]
[same as prior period, unchanged from 0001571996-20-000034:mdna:181]

[0001571996-20-000045:mdna:196]
[same as prior period, unchanged from 0001571996-20-000034:mdna:182]

[0001571996-20-000045:mdna:197]
[same as prior period, unchanged from 0001571996-20-000034:mdna:183]

[0001571996-20-000045:mdna:198]
As of July 31, 2020, we had no off-balance sheet arrangements that have or are reasonably likely to have a current or future material effect on our financial condition or results of operations.

[0001571996-20-000045:mdna:199]
[same as prior period, unchanged from 0001571996-20-000034:mdna:185]

[0001571996-20-000045:mdna:200]
[same as prior period, unchanged from 0001571996-20-000034:mdna:186]

[0001571996-20-000045:mdna:201]
[same as prior period, unchanged from 0001571996-20-000034:mdna:187]

[0001571996-20-000045:mdna:202]
[same as prior period, unchanged from 0001571996-20-000034:mdna:188]

[0001571996-20-000045:mdna:203]
[same as prior period, unchanged from 0001571996-20-000034:mdna:189]

[0001571996-20-000045:mdna:204]
[same as prior period, unchanged from 0001571996-20-000034:mdna:190]

[0001571996-20-000045:mdna:205]
[same as prior period, unchanged from 0001571996-20-000034:mdna:191]

[0001571996-20-000045:mdna:206]
[same as prior period, unchanged from 0001571996-20-000034:mdna:192]

[0001571996-20-000045:mdna:207]
[same as prior period, unchanged from 0001571996-20-000034:mdna:193]

[0001571996-20-000045:mdna:208]
In this unprecedented environment resulting from the COVID-19 pandemic, we are taking actions to strengthen our cash position and preserve financial flexibility, while continuing to prioritize our debt paydown target for the fiscal year.

[0001571996-20-000045:mdna:209]
[same as prior period, unchanged from 0001571996-20-000034:mdna:195]

[0001571996-20-000045:mdna:210]
|  | July 31, 2020 |  | January 31, 2020 |
|  | (in millions) |  |  |
| Cash and cash equivalents, and available borrowings: |  |  |  |
| Cash and cash equivalents (a) | $ | 11,221 |  |  | $ | 9,302 |  |
| Remaining available borrowings under revolving credit facilities | 5,871 |  |  | 5,972 |  |
| Total cash, cash equivalents, and available borrowings | $ | 17,092 |  |  | $ | 15,274 |  |

[0001571996-20-000045:mdna:211]
[same as prior period, unchanged from 0001571996-20-000034:mdna:197]

[0001571996-20-000045:mdna:212]
(a) Of the $11.2 billion of cash and cash equivalents as of July 31, 2020, $4.7 billion was held by VMware, Inc.

[0001571996-20-000045:mdna:213]
Our revolving credit facilities as of July 31, 2020 include the Revolving Credit Facility and the China Revolving Credit Facility, which we entered into on May 25, 2020.  The Revolving Credit Facility has a maximum aggregate borrowing capacity of $4.5 billion, and available borrowings under this facility are reduced by draws on the facility and outstanding letters of credit.  As of July 31, 2020, there were no borrowings outstanding under the facility and remaining available borrowings totaled approximately $4.5 billion.  The terms of the China Revolving Credit Facility provide for collateralized and non-collateralized

[0001571996-20-000045:mdna:214]
89

[0001571996-20-000045:mdna:215]
principal amounts not to exceed $1.0 billion Chinese renminbi and $1.8 billion Chinese renminbi, respectively, or equivalent amounts in U.S. dollars.  As of July 31, 2020, there were no borrowings outstanding under the facility and remaining available borrowings totaled approximately $2.8 billion Chinese renminbi or equivalent amounts in U.S. dollars.  We may regularly use our available borrowings from both our Revolving Credit Facility and our China Revolving Credit Facility on a short-term basis for general corporate purposes.

[0001571996-20-000045:mdna:216]
The VMware Revolving Credit Facility has a maximum capacity of $1.0 billion.  As of July 31, 2020, $1.0 billion was available under the VMware Revolving Credit Facility.  None of the net proceeds of borrowings under the VMware Revolving Credit Facility will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.

[0001571996-20-000045:mdna:217]
[same as prior period, unchanged from 0001571996-20-000034:mdna:201]

[0001571996-20-000045:mdna:218]
[same as prior period, unchanged from 0001571996-20-000034:mdna:202]

[0001571996-20-000045:mdna:219]
[same as prior period, unchanged from 0001571996-20-000034:mdna:203]

[0001571996-20-000045:mdna:220]
[same as prior period, unchanged from 0001571996-20-000034:mdna:204]

[0001571996-20-000045:mdna:221]
|  | July 31, 2020 |  | Increase (decrease) |  | January 31, 2020 |
|  | (in millions) |  |  |  |  |
| Core debt |  |  |  |  |  |
| Senior Secured Credit Facilities and First Lien Notes | $ | 30,251 |  |  | $ | 587 |  |  | $ | 29,664 |  |
| Unsecured Notes and Debentures | 1,352 |  |  | — |  |  | 1,352 |  |
| Senior Notes | 2,700 |  |  | — |  |  | 2,700 |  |
| EMC Notes | 1,000 |  |  | (600) |  |  | 1,600 |  |
| DFS allocated debt | (1,184) |  |  | 311 |  |  | (1,495) |  |
| Total core debt | 34,119 |  |  | 298 |  |  | 33,821 |  |
| DFS related debt |  |  |  |  |  |
| DFS debt | 8,837 |  |  | 1,072 |  |  | 7,765 |  |
| DFS allocated debt | 1,184 |  |  | (311) |  |  | 1,495 |  |
| Total DFS related debt | 10,021 |  |  | 761 |  |  | 9,260 |  |
| Margin Loan Facility and other | 4,092 |  |  | 68 |  |  | 4,024 |  |
| Debt of public subsidiary |  |  |  |  |  |
| VMware Notes | 4,750 |  |  | 750 |  |  | 4,000 |  |
| VMware Term Loan Facility | 1,500 |  |  | — |  |  | 1,500 |  |
| Other | 55 |  |  | (5) |  |  | 60 |  |
| Total public subsidiary debt | 6,305 |  |  | 745 |  |  | 5,560 |  |
| Total debt, principal amount | 54,537 |  |  | 1,872 |  |  | 52,665 |  |
| Carrying value adjustments | (584) |  |  | 25 |  |  | (609) |  |
| Total debt, carrying value | $ | 53,953 |  |  | $ | 1,897 |  |  | $ | 52,056 |  |

[0001571996-20-000045:mdna:222]
During the first six months of Fiscal 2021, the outstanding principal amount of our debt increased by $1.9 billion to $54.5 billion as of July 31, 2020, primarily driven by the increase in DFS debt and the VMware Notes.

[0001571996-20-000045:mdna:223]
We define core debt as the total principal amount of our debt, less DFS related debt, our Margin Loan Facility and other debt, and public subsidiary debt.  Our core debt was $34.1 billion as of July 31, 2020.  During the first six months of Fiscal 2021, we

[0001571996-20-000045:mdna:224]
90

[0001571996-20-000045:mdna:225]
issued multiple series of First Lien Notes in an aggregate principal amount of $2.25 billion on April 9, 2020, which were offset by repayment of $1.2 billion and open market repurchases of $235 million of 4.42% First Lien Notes due June 2021, repayment of $600 million principal amount of 2.650% EMC Notes due June 2020 upon maturity, and approximately $229 million of principal amortization under our term loan facilities.  See Note 6 of the Notes to the Condensed Consolidated Financial Statements included in this report for more information about our debt.

[0001571996-20-000045:mdna:226]
There are no scheduled maturities of core debt in the second half of Fiscal 2021, although we intend to continue making core debt principal payments as part of our overall capital allocation strategy.

[0001571996-20-000045:mdna:227]
During the first six months of Fiscal 2021, we issued an additional $1.1 billion, net, in DFS debt to support the expansion of our financing receivables portfolio, which includes the issuance of 500 million Euro of senior unsecured eurobonds on June 24, 2020.  DFS related debt primarily represents debt from our securitization and structured financing programs.  The majority of DFS debt is non-recourse to Dell Technologies and represents borrowings under securitization programs and structured financing programs, for which our risk of loss is limited to transferred lease and loan payments and associated equipment, and under which the credit holders have no recourse to Dell Technologies.

[0001571996-20-000045:mdna:228]
[same as prior period, unchanged from 0001571996-20-000034:mdna:209]

[0001571996-20-000045:mdna:229]
As of July 31, 2020, margin loan and other debt primarily consisted of the $4.0 billion Margin Loan Facility.

[0001571996-20-000045:mdna:230]
Debt of public subsidiary represents VMware, Inc. indebtedness.  The increase in debt of public subsidiary during the first six months of Fiscal 2021 was due to the issuance of VMware Notes in an aggregate principal amount of $2.0 billion on April 7, 2020, partially offset by repayment of $1.25 billion principal amount of its 2.30% Notes due August 2020.  See Note 6 of the Notes to the Condensed Consolidated Financial Statements included in this report for more information about VMware, Inc. debt.

[0001571996-20-000045:mdna:231]
[same as prior period, unchanged from 0001571996-20-000034:mdna:213]

[0001571996-20-000045:mdna:232]
[same as prior period, unchanged from 0001571996-20-000034:mdna:214]

[0001571996-20-000045:mdna:233]
[same as prior period, unchanged from 0001571996-20-000034:mdna:215]

[0001571996-20-000045:mdna:234]
[same as prior period, unchanged from 0001571996-20-000034:mdna:216]

[0001571996-20-000045:mdna:235]
[same as prior period, unchanged from 0001571996-20-000034:mdna:217]

[0001571996-20-000045:mdna:236]
|  | Six Months Ended |  |  |
|  | July 31, 2020 |  | August 2, 2019 |
|  | (in millions) |  |  |
| Net change in cash from: |  |  |  |
| Operating activities | $ | 2,536 |  |  | $ | 3,962 |  |
| Investing activities | (1,409) |  |  | (1,283) |  |
| Financing activities | 827 |  |  | (2,922) |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash | (52) |  |  | (62) |  |
| Change in cash, cash equivalents, and restricted cash | $ | 1,902 |  |  | $ | (305) |  |

[0001571996-20-000045:mdna:237]
Operating Activities — Cash provided by operating activities was $2.5 billion for the first six months of Fiscal 2021 compared to $4.0 billion for the first six months of Fiscal 2020.  The decrease in operating cash flows during the first six months of Fiscal 2021 was primarily attributable to unfavorable working capital impacts of an increase in inventory related to the COVID-19 pandemic and timing of purchases and payments to vendors.

[0001571996-20-000045:mdna:238]
DFS offerings are initially funded through cash on hand at the time of origination, most of which is subsequently replaced with third-party financing.  For DFS offerings which qualify as sales-type leases, the initial funding of financing receivables is reflected as an impact to cash flows from operations, and is largely subsequently offset by cash proceeds from financing.  For DFS operating leases, which have increased under the current leasing standard, the initial funding is classified as a capital expenditure and reflected as cash flows used in investing activities.  DFS new financing originations were $4.4 billion and $3.7 billion during the first six months of Fiscal 2021 and Fiscal 2020, respectively.  As of July 31, 2020, DFS had $10.2 billion of total net financing receivables and $1.2 billion of equipment under DFS operating leases, net.

[0001571996-20-000045:mdna:239]
Investing Activities — Investing activities primarily consist of cash used to fund capital expenditures for property, plant, and equipment, which includes equipment under DFS operating leases, capitalized software development costs, strategic investments, and the maturities, sales, and purchases of investments.  During the first six months of Fiscal 2021, cash used in investing activities was $1.4 billion and was primarily driven by capital expenditures and acquisitions of businesses.  In comparison, cash used in investing activities was $1.3 billion during the first six months of Fiscal 2020 and was primarily driven by capital expenditures and acquisitions of businesses, which were partially offset by net cash proceeds from the net sales of strategic investments.

[0001571996-20-000045:mdna:240]
Financing Activities — Financing activities primarily consist of the proceeds and repayments of debt, cash used to repurchase common stock, and proceeds from the issuance of common stock.  Cash provided by financing activities of $0.8 billion during the first six months of Fiscal 2021 primarily consisted of cash proceeds from the issuances of multiple series of First Lien Notes and VMware Notes, partially offset by debt repayments and repurchases of common stock by our public subsidiaries.  In comparison, cash used in financing activities of $2.9 billion during the first six months of Fiscal 2020 primarily consisted of repayments of debt and repurchases of common stock by our public subsidiaries.

[0001571996-20-000045:mdna:241]
[same as prior period, unchanged from 0001571996-20-000034:mdna:225]

[0001571996-20-000045:mdna:242]
Capital Expenditures — During the first six months of Fiscal 2021 and Fiscal 2020, we spent $1.0 billion and $1.1 billion, respectively, on property, plant, and equipment.  These expenditures were incurred in connection with our global expansion efforts and infrastructure investments made to support future growth, and the funding of equipment under DFS operating leases.  During the first six months of Fiscal 2021 and Fiscal 2020, funding of gross equipment under DFS operating leases was $0.4 billion and $0.5 billion, respectively.  Product demand, product mix, and the use of contract manufacturers, as well as ongoing investments in operating and information technology infrastructure, influence the level and prioritization of our capital expenditures.  Aggregate capital expenditures for Fiscal 2021 are currently expected to total between $2.2 billion and $2.3 billion, of which approximately $1.0 billion is expected for equipment under DFS operating leases.

[0001571996-20-000045:mdna:243]
[same as prior period, unchanged from 0001571996-20-000034:mdna:227]

[0001571996-20-000045:mdna:244]
[same as prior period, unchanged from 0001571996-20-000034:mdna:228]

[0001571996-20-000045:mdna:245]
93
