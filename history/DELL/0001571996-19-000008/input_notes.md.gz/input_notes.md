# DELL notes — 0001571996-19-000008


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001571996-19-000008:notes:1]
Basis of Presentation — These Consolidated Financial Statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“GAAP”).


## us-gaap:ScheduleOfDisposalGroupsIncludingDiscontinuedOperationsIncomeStatementBalanceSheetAndAdditionalDisclosuresTextBlock

[0001571996-19-000008:notes:2]
The following table presents key financial results of Dell Services, DSG, and ECD for the period presented:

[0001571996-19-000008:notes:3]
|  | Fiscal Year Ended February 3, 2017 |
|  | ECD (a) |  | Dell Services |  | DSG |  | Total |
|  | (in millions) |
| Net revenue | $ | 208 |  |  | $ | 1,980 |  |  | $ | 975 |  |  | $ | 3,163 |  |
| Cost of net revenue | 56 |  |  | 1,563 |  |  | 250 |  |  | 1,869 |  |
| Operating expenses | 137 |  |  | 347 |  |  | 726 |  |  | 1,210 |  |
| Interest and other, net | (1 | ) |  | (8 | ) |  | (2 | ) |  | (11 | ) |
| Income (loss) from discontinued operations before income taxes and gain (loss) on disposal | 14 |  |  | 62 |  |  | (3 | ) |  | 73 |  |
| Income tax provision (benefit) | 3 |  |  | (40 | ) |  | (23 | ) |  | (60 | ) |
| Income from discontinued operations, net of income taxes, before gain (loss) on disposal | 11 |  |  | 102 |  |  | 20 |  |  | 133 |  |
| Gain (loss) on disposal, net of tax expense (benefit) of $181, $(262), and $462, respectively | (356 | ) |  | 1,669 |  |  | 470 |  |  | 1,783 |  |
| Income (loss) from discontinued operations, net of income taxes | $ | (345 | ) |  | $ | 1,771 |  |  | $ | 490 |  |  | $ | 1,916 |  |

[0001571996-19-000008:notes:4]
____________________

[0001571996-19-000008:notes:5]
(a)
The results of ECD were classified as discontinued operations for the period from September 7, 2016 through February 3, 2017 because the ECD business was only included in the Company’s consolidated results since the closing of the EMC merger transaction.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001571996-19-000008:notes:6]
NOTE 2 — DESCRIPTION OF BUSINESS AND SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES

[0001571996-19-000008:notes:7]
Description of Business — The Company is a strategically aligned family of businesses that offers a broad range of technology solutions, including desktops, notebooks, servers and networking products, storage products, cloud solutions products, services, software, and third-party software and peripherals.

[0001571996-19-000008:notes:8]
The Company’s fiscal year is the 52- or 53-week period ending on the Friday nearest January 31.  The fiscal years ended February 1, 2019 and February 2, 2018 were 52-week periods.  The fiscal year ended February 3, 2017 was a 53-week period.

[0001571996-19-000008:notes:9]
Principles of Consolidation — These Consolidated Financial Statements include the accounts of Dell Technologies and its wholly-owned subsidiaries, as well as the accounts of VMware, Inc., Pivotal, and SecureWorks Corp. (“Secureworks”), each of which is majority-owned by Dell Technologies.  All intercompany transactions have been eliminated.

[0001571996-19-000008:notes:10]
Use of Estimates — The preparation of financial statements in accordance with GAAP requires management to make estimates and assumptions that affect the amounts reported in the Consolidated Financial Statements and the accompanying Notes.  Actual results could differ materially from those estimates.

[0001571996-19-000008:notes:11]
Cash and Cash Equivalents — All highly liquid investments, including credit card receivables due from banks, with original maturities of 90 days or less at date of purchase, are reported at fair value and are considered to be cash equivalents.  All other investments not considered to be cash equivalents are separately categorized as investments.

[0001571996-19-000008:notes:12]
Investments — All debt security investments with effective maturities in excess of one year and substantially all equity and other securities are recorded as long-term investments in the Consolidated Statements of Financial Position.  In comparison, debt security instruments with an effective maturity of one year or less are classified as short-term investments in the Consolidated Statements of Financial Position.

[0001571996-19-000008:notes:13]
Unrealized gain and loss positions on investments classified as available-for-sale are included within accumulated other comprehensive income (loss), net of any related tax effect.  Realized gains and losses and other-than-temporary impairments are reclassified from accumulated other comprehensive income (loss) to interest and other, net.  Strategic investments in publicly-traded companies are recorded at fair value based on quoted prices in active markets.  Strategic investments in privately-held companies without readily determinable fair values are recorded at cost, less impairment, and are adjusted for observable price changes.  Fair value measurements and impairments for strategic investments are recognized in interest and other, net in the Consolidated Statements of Income (Loss).  In evaluating equity investments without readily determinable fair values for impairment or observable price changes, the Company uses inputs that include pre- and post-money valuations of recent financing events and the impact of those events on its fully diluted ownership percentages, as well as other available information regarding the issuer’s historical and forecasted performance.

[0001571996-19-000008:notes:14]
Allowance for Doubtful Accounts — The Company recognizes an allowance for losses on accounts receivable in an amount equal to the estimated probable losses, net of recoveries.  The allowance is based on an analysis of current receivables aging and expected future write-offs, as well as an assessment of specific identifiable customer accounts considered at risk or uncollectible.  The expense associated with the allowance for doubtful accounts is recognized in selling, general, and administrative expenses.

[0001571996-19-000008:notes:15]
Financing Receivables — Financing receivables are presented net of allowance for losses and consist of customer receivables and residual interest.  Customer receivables include revolving loans and fixed-term leases and loans resulting primarily from the sale of the Company’s products and services.  The Company has two portfolios, consisting of (1) fixed-term leases and loans and (2) revolving loans, and assesses risk at the portfolio level to determine the appropriate allowance levels.  The portfolio segments are further segregated into classes based on products, customer type, and credit risk evaluation: (1) Revolving - Dell Preferred Account (“DPA”); (2) Revolving - Dell Business Credit (“DBC”); and (3) Fixed-term - Consumer and Commercial.  Fixed-term leases and loans are offered to qualified small and medium-sized businesses, large commercial accounts, governmental organizations, and educational entities.  Additionally, fixed-term loans are also offered to certain individual consumer customers.  Revolving loans are offered under private label credit financing programs.  The DPA revolving loan programs are offered to individual consumers and the DBC revolving loan programs are offered to small and medium-sized business customers.

[0001571996-19-000008:notes:16]
The Company retains a residual interest in equipment leased under its fixed-term lease programs.  The amount of the residual interest is established at the inception of the lease based upon estimates of the value of the equipment at the end of the lease term using historical studies, industry data, and future value-at-risk demand valuation methods.  On a quarterly basis, the Company assesses the carrying amount of its recorded residual values for impairment.  Anticipated declines in specific future residual values that are considered to be other-than-temporary are recorded currently in earnings.

[0001571996-19-000008:notes:17]
Allowance for Financing Receivable Losses — The Company recognizes an allowance for losses on financing receivables in an amount equal to the probable losses net of recoveries.  The allowance for losses is generally determined at the aggregate portfolio level based on a variety of factors, including historical and anticipated experience, past due receivables, receivable type, and customer risk profile.  Customer account principal and interest are charged to the allowance for losses when an account is deemed to be uncollectible or generally when the account is 180 days delinquent.  While the Company does not generally place financing receivables on non-accrual status during the delinquency period, accrued interest is included in the allowance for loss calculation and, therefore, the Company is adequately reserved in the event of charge off.  Recoveries on receivables previously charged off as uncollectible are recorded to the allowance for financing receivables losses.  The expense associated with the allowance for financing receivables losses is recognized as cost of net revenue.  Both fixed and revolving receivable loss rates are affected by macroeconomic conditions, including the level of gross domestic product (“GDP”) growth, unemployment rates, the level of commercial capital equipment investment, and the credit quality of the borrower.

[0001571996-19-000008:notes:18]
Asset Securitization — The Company transfers certain U.S. and European customer financing receivables to Special Purpose Entities (“SPEs”) that meet the definition of a Variable Interest Entity (“VIE”) and are consolidated into the Consolidated Financial Statements.  These SPEs are bankruptcy-remote legal entities with separate assets and liabilities.  The purpose of the SPEs is to facilitate the funding of customer receivables in the capital markets.  These SPEs have entered into financing arrangements with multi-seller conduits that, in turn, issue asset-backed debt securities in the capital markets.  The asset securitizations in the SPEs are accounted for as secured borrowings.  See Note 5 of the Notes to the Consolidated Financial Statements for additional information regarding SPEs.

[0001571996-19-000008:notes:19]
Inventories — Inventories are stated at the lower of cost or market with cost being determined on a first-in, first-out basis.  Adjustments to reduce the cost of inventory to its net realizable value are made, if required, for estimated excess, obsolescence, or impaired balances.

[0001571996-19-000008:notes:20]
Property, Plant, and Equipment — Property, plant, and equipment are carried at depreciated cost.  Depreciation is determined using the straight-line method over the shorter of the estimated economic lives of the assets or the lease term.  The estimated useful lives of the Company’s property, plant, and equipment are generally as follows:

[0001571996-19-000008:notes:21]
|  | Estimated Useful Life |
| Computer equipment | 3-5 years |
| Buildings | 10-30 years or term of underlying land lease |
| Leasehold improvements | Shorter of 5-20 years or lease term |
| Machinery and equipment | 3-5 years |

[0001571996-19-000008:notes:22]
Gains or losses related to retirements or dispositions of fixed assets are recognized in the period during which the retirement or disposition occurs.

[0001571996-19-000008:notes:23]
Capitalized Software Development Costs — In accordance with the applicable accounting standards, software development costs related to the development of new product offerings are capitalized subsequent to the establishment of technological feasibility, which is demonstrated by the completion of a detailed program design or working model, if no program design is completed.  The Company amortizes capitalized costs on a straight-line basis over the estimated useful lives of the products, which is generally two years.

[0001571996-19-000008:notes:24]
As of February 1, 2019 and February 2, 2018, capitalized software development costs were $617 million and $489 million and are included in other non-current assets, net in the accompanying Consolidated Statements of Financial Position.  Amortization expense for the fiscal years ended February 1, 2019 and February 2, 2018 was $211 million and $82 million.  Amortization expense for the period from September 7, 2016 through February 3, 2017 was immaterial as a result of the EMC merger transaction.

[0001571996-19-000008:notes:25]
The Company capitalizes certain internal and external costs to acquire or create internal use software which are incurred subsequent to the completion of the preliminary project stage.  Development costs are amortized on a straight-line basis over the shorter of the expected useful life of the software or five years.  Costs associated with maintenance and minor enhancements to the features and functionality of the Company’s website are expensed as incurred.

[0001571996-19-000008:notes:26]
Impairment of Long-Lived Assets — The Company reviews long-lived assets for impairment when events or changes in circumstances indicate the carrying amount of an asset may not be recoverable.  The Company assesses the recoverability of the assets based on the undiscounted future cash flows expected from the use and eventual disposition of the asset.  If the carrying amount of the asset is determined not to be recoverable, a write-down to fair value is recorded.  Fair values are determined based on quoted market values, discounted cash flows, or external appraisals, as applicable.  Long-lived assets to be disposed of are reported at the lower of carrying amount or fair value less costs to sell.

[0001571996-19-000008:notes:27]
Business Combinations — The assets and liabilities of acquired businesses are recorded at their fair values at the date of acquisition.  The excess of the purchase price over the fair value of the tangible and intangible assets acquired and the liabilities assumed is recorded as goodwill.  During the measurement period, if new information is obtained about facts and circumstances that existed as of the acquisition date, cumulative changes in the estimated fair values of the net assets recorded may change the amount of the purchase price allocable to goodwill.  During the measurement period, which expires one year from the acquisition date, changes to any purchase price allocations that are material to the Company’s consolidated financial results will be adjusted in the reporting period in which the adjustment amount is determined.  See Note 8 of the Notes to the Consolidated Financial Statements for more information on business combinations.

[0001571996-19-000008:notes:28]
In-process research and development costs are recorded at fair value as an indefinite-lived intangible asset and assessed for impairment thereafter until completion, at which point the asset is amortized over its expected useful life.  All acquisition costs are expensed as incurred, and the results of operations of acquired businesses are included in the Consolidated Financial Statements from the acquisition date.

[0001571996-19-000008:notes:29]
Intangible Assets Including Goodwill — Identifiable intangible assets with finite lives are amortized over their estimated useful lives.  Intangible assets are reviewed for impairment when events and circumstances indicate the asset may be impaired.  Goodwill and indefinite-lived intangible assets are tested for impairment annually during the third fiscal quarter and whenever events or circumstances indicate that an impairment may have occurred.

[0001571996-19-000008:notes:30]
Foreign Currency Translation — The majority of the Company’s international sales are made by international subsidiaries, most of which have the U.S. dollar as their functional currency.  The Company’s subsidiaries that do not have the U.S. dollar as their functional currency translate assets and liabilities at current rates of exchange in effect at the balance sheet date.  Revenue and expenses from these international subsidiaries are translated using the monthly average exchange rates in effect for the period in which the transactions occur.  Foreign currency translation adjustments are included as a component of accumulated other comprehensive income (loss) (“OCI”) in stockholders’ equity (deficit).

[0001571996-19-000008:notes:31]
Local currency transactions of international subsidiaries that have the U.S. dollar as the functional currency are remeasured into U.S. dollars using the current rates of exchange for monetary assets and liabilities and historical rates of exchange for nonmonetary assets and liabilities.  Gains and losses from remeasurement of monetary assets and liabilities are included in interest and other, net.

[0001571996-19-000008:notes:32]
Hedging Instruments — The Company uses derivative financial instruments, primarily forward contracts, options, and swaps, to hedge certain foreign currency and interest rate exposures.  The relationships between hedging instruments and hedged items, as well as the risk management objectives and strategies for undertaking hedge transactions, are formally documented.  The Company does not use derivatives for speculative purposes.  All derivative instruments are recognized as either assets or liabilities in the Consolidated Statements of Financial Position and are measured at fair value.

[0001571996-19-000008:notes:33]
The Company’s hedge portfolio includes non-designated derivatives and derivatives designated as cash flow hedges.  For derivative instruments that are designated as cash flow hedges, the Company assesses hedge effectiveness both at the onset of the hedge and at regular intervals throughout the life of the derivative.  The gain or loss on cash flow hedges is recorded in accumulated other comprehensive income (loss), as a separate component of stockholders’ equity (deficit), and reclassified into earnings in the period during which the hedged transaction is recognized in earnings.  For derivatives that are not designated as hedges or do not qualify for hedge accounting treatment, the Company recognizes the change in the instrument’s fair value currently in earnings as a component of interest and other, net.

[0001571996-19-000008:notes:34]
Cash flows from derivative instruments are presented in the same category on the Consolidated Statements of Cash Flows as the cash flows from the underlying hedged items.  See Note 7 of the Notes to the Consolidated Financial Statements for a description of the Company’s derivative financial instrument activities.

[0001571996-19-000008:notes:35]
Revenue Recognition — The Company sells a wide portfolio of products and services to its customers.  The Company’s agreements have varying requirements depending on the goods and services being sold, the rights and obligations conveyed, and the legal jurisdiction of the arrangement.

[0001571996-19-000008:notes:36]
Revenue is recognized for these arrangements based on the following five steps:

[0001571996-19-000008:notes:37]
| (1) | Identify the contract with a customer. The term “contract” refers to the enforceable rights and obligations provided in an agreement between the Company and the customer in exchange for payment. The Company evaluates facts and circumstances regarding sales transactions in order to identify contracts with its customers. An agreement must meet all of the following criteria to qualify as a contract eligible for revenue recognition under the model: (i) the contract must be approved by all parties who are committed to perform their respective obligations; (ii) each party’s rights regarding the goods and services to be transferred to the customer can be identified; (iii) the payment terms for the goods and services can be identified; (iv) the customer has the ability and intent to pay and it is probable that the Company will collect substantially all of the consideration to which we will be entitled; and (v) the contract must have commercial substance. Judgment is used in determining the customer’s ability and intent to pay, which is based upon various factors, including the customer’s historical payment experience or customer credit and financial information. |

[0001571996-19-000008:notes:38]
| (2) | Identify the performance obligations in the contract. The Company’s contracts with customer often include the promise to transfer multiple goods and services to a customer. Distinct promises within a contract are referred to as “performance obligations” and are accounted for as separate units of account. The Company assesses whether each promised good or service is distinct for the purpose of identifying the performance obligations in the contract. This assessment involves subjective determinations and requires management to make judgments about the individual promised goods or services and whether such goods or services are separable from the other aspects of the contractual relationship. Promised goods and services are considered distinct provided that: (i) the customer can benefit from the good or service either on its own or together with other resources that are readily available to the customer (that is, the good or service is capable of being distinct); and (ii) the Company’s promise to transfer the good or service to the customer is separately identifiable from other promises in the contract (that is, the promise to transfer the good or service is distinct within the context of the contract). The Company’s performance obligations include various distinct goods and services such as hardware, software licenses, warranties, and other service offerings and solutions. Promised goods and services are explicitly identified in the Company’s contracts and may be sold on a standalone basis or bundled as part of a combined solution. In certain hardware solutions, the hardware is highly interdependent on, and interrelated with, the embedded software. In these offerings, the hardware and software licenses are accounted for as a single performance obligation. |

[0001571996-19-000008:notes:39]
| (3) | Determine the transaction price. The transaction price reflects the amount of consideration to which the Company expects to be entitled in exchange for transferring goods or services to the customer. If the consideration promised in a contract includes a variable amount, the Company estimates the amount to which it expects to be entitled using either the expected value or most likely amount method. Generally, volume discounts, rebates, and sales returns reduce the transaction price. In determining the transaction price, the Company only includes amounts that are not subject to significant future reversal. |

[0001571996-19-000008:notes:40]
| (4) | Allocate the transaction price to performance obligations in the contract. When a contract includes multiple performance obligations, the transaction price is allocated to each performance obligation in an amount that depicts the consideration to which the Company expects to be entitled in exchange for transferring the promised goods or services. For contracts with multiple performance obligations, the transaction price is allocated in proportion to the standalone selling price (“SSP”) of each performance obligation. |

[0001571996-19-000008:notes:41]
The best evidence of SSP is the observable price of a good or service when the Company sells that good or service separately in similar circumstances to similar customers.  If a directly observable price is available, the Company will utilize that price for the SSP.  If a directly observable price is not available, the SSP must be estimated.  The Company estimates SSP by considering multiple factors, including, but not limited to, pricing practices, internal costs, and profit objectives as well as overall market conditions, which include geographic or regional specific factors, competitive positioning, and competitor actions.

[0001571996-19-000008:notes:42]
| (5) | Recognize revenue when (or as) the performance obligation is satisfied. Revenue is recognized when obligations under the terms of the contract with the Company’s customer are satisfied. Revenue is recognized either over time or at a point in time, depending on when the underlying products or services are transferred to the customer. Revenue is recognized at a point in time for products upon transfer of control. Revenue is recognized over time for support and deployment services, software support, SaaS, and IaaS. Revenue is recognized either over time or at a point in time for professional services and training depending on the nature of the offering to the customer. |

[0001571996-19-000008:notes:43]
The Company reports revenue net of any revenue-based taxes assessed by governmental authorities that are imposed on and concurrently with specific revenue-producing transactions.

[0001571996-19-000008:notes:44]
The Company has elected the following practical expedients with the adoption of the new revenue standard:

[0001571996-19-000008:notes:45]
| • | The Company does not account for significant financing components if the period between revenue recognition and when the customer pays for the product or service will be one year or less. |

[0001571996-19-000008:notes:46]
| • | The Company recognizes revenue equal to the amount it has a right to invoice when the amount corresponds directly with the value to the customer of the Company’s performance to date. |

[0001571996-19-000008:notes:47]
| • | The Company does not account for shipping and handling activities as a separate performance obligation, but rather as an activity performed to transfer the promised good. |

[0001571996-19-000008:notes:48]
The following summarizes the nature of revenue recognized and the manner in which the Company accounts for sales transactions.

[0001571996-19-000008:notes:49]
Products

[0001571996-19-000008:notes:50]
Product revenue consists of hardware and software license sales that are delivered, sold as a subscription, or sold on a consumption basis.  Hardware includes notebooks and desktop PCs, servers, storage hardware, and other hardware-related devices.  Software license sales include non-essential software applications.  Software applications provide customers with resource management, backup and archiving, information security, information management and intelligence, data analytics, and server virtualization capabilities.

[0001571996-19-000008:notes:51]
Revenue from the sale of hardware products is recognized when control has transferred to the customer, which typically occurs when the hardware has been shipped to the customer, risk of loss has transferred to the customer, the Company has a present right to payment, and customer acceptance has been satisfied.  Customer acceptance is satisfied if acceptance is obtained from the customer, if all acceptance provisions lapse, or if the Company has evidence that all acceptance provisions will be, or have been, satisfied.  Revenue from software license sales is generally recognized when control has transferred to the customer, which is typically upon shipment, electronic delivery, or when the software is available for download by the customer.  For certain software arrangements in which the customer is granted a right to additional unspecified future software licenses, the Company’s promise to the customer is considered a stand-ready obligation in which the transfer of control, and revenue recognition will be over time.  Invoices for products are generally issued as control transfers, which is typically upon shipment or delivery.  There was no significant revenue in any period presented related to performance obligations satisfied or partially satisfied in prior periods.

[0001571996-19-000008:notes:52]
Services

[0001571996-19-000008:notes:53]
Services revenue consists of revenue from sales of support services, including hardware support that extends beyond the Company’s standard warranties, software maintenance, and installation; professional services; training; SaaS; and IaaS.  Revenue associated with undelivered performance obligations is deferred and recognized when or as control is transferred to the customer.  Revenue from fixed-price support or maintenance contracts sold for both hardware and software is recognized on a straight-line basis over the period of performance because the Company is required to provide services at any given time.  Other services revenue is recognized when the Company performs the services and the customer receives and consumes the benefits.

[0001571996-19-000008:notes:54]
Invoices for services may be issued at the start of a service term, which is typically the case for support and deployment services, or as services are rendered, which is typically the case for professional services, training, SaaS, and IaaS.

[0001571996-19-000008:notes:55]
Other

[0001571996-19-000008:notes:56]
Revenue from leasing arrangements is not subject to the revenue standard for contracts with customers and remains separately accounted for under existing lease accounting guidance.  The Company records revenue from the sale of equipment under sales-type leases as product revenue in an amount equal to the present value of minimum lease payments at the inception of the lease.  Sales-type leases also produce financing income, which is included in products net revenue in the Consolidated Statements of Income (Loss) and is recognized at effective rates of return over the lease term.  The Company also offers qualified customers fixed-term loans and revolving credit lines for the purchase of products and services offered by the Company.  Financing income attributable to these loans is recognized in products net revenue on an accrual basis.

[0001571996-19-000008:notes:57]
Disaggregation of Revenue — The Company’s revenue is presented on a disaggregated basis on the Consolidated Statements of Income (Loss) and in Note 19 of the Notes to the Consolidated Financial Statements based on an evaluation of disclosures outside of the financial statements, information regularly reviewed by the chief operating decision maker for evaluating the financial performance of operating segments, and other information that is used to evaluate the Company’s financial performance or make resource allocations.  This information includes revenue from products and services, revenue from reportable segments, and revenue by major product categories within the segments.

[0001571996-19-000008:notes:58]
Contract Assets — Contract assets are rights to consideration in exchange for goods or services that the Company has transferred to a customer when such a right is conditional on something other than the passage of time.  Such amounts have been insignificant to date.

[0001571996-19-000008:notes:59]
Contract Liabilities — Contract liabilities primarily consist of deferred revenue.  Deferred revenue is recorded when the Company has a right to invoice or payments have been received for undelivered products or services, or in situations where revenue recognition criteria have not been met.  Deferred revenue also represents amounts received in advance for extended warranty services and software maintenance.  Revenue is recognized on these items when the revenue recognition criteria are met, generally resulting in ratable recognition over the contract term.  The Company also has deferred revenue related to undelivered hardware and professional services, consisting of installations and consulting engagements, which are recognized when the Company’s performance obligations under the contract are completed.  See Note 9 of the Notes to the Consolidated Financial Statements for additional information about deferred revenue.

[0001571996-19-000008:notes:60]
Costs to Obtain a Contract — The incremental direct costs of obtaining a contract primarily consist of sales commissions and employer taxes related to commission payments.  The Company has elected, as a practical expedient, to expense as incurred costs to obtain a contract equal to or less than one year in duration.  For contracts greater than one year in duration, the associated costs to obtain a contract are deferred and amortized over the period of contract performance or a longer period, generally the estimated life of the customer relationship, if renewals are expected and the renewal commission is not commensurate with the initial commission.  Deferred costs to obtain a contract are typically amortized over an average period of three to seven years, depending on the contract term and expectation of the period of benefit for the costs, which may exceed the contract term.  Amortization expense is recognized on a straight-line basis and included in selling, general, and administrative expenses in the Consolidated Statements of Income (Loss).

[0001571996-19-000008:notes:61]
The Company periodically reviews these deferred costs to determine whether events or changes in circumstances have occurred that could impact the carrying value or period of benefit of the deferred sales commissions.  There were no material impairment losses for deferred costs to obtain a contract during the fiscal years ended February 1, 2019 and February 2, 2018.

[0001571996-19-000008:notes:62]
Deferred costs to obtain a contract as of February 1, 2019 and February 2, 2018 were $1.3 billion and $0.8 billion, respectively.  Deferred costs to obtain a contract are classified as current assets and other non-current assets on the Consolidated Statements of Financial Position, based on when the expense is expected to be recognized.  Amortization of costs to obtain a contract during the fiscal years ended February 1, 2019, February 2, 2018, and February 3, 2017 was $517 million, $292 million, and $96 million respectively.

[0001571996-19-000008:notes:63]
Standard Warranty Liabilities — The Company records warranty liabilities for estimated costs of fulfilling its obligations under standard limited hardware and software warranties at the time of sale.  The liability for standard warranties is included in accrued and other current and other non-current liabilities in the Consolidated Statements of Financial Position.  The specific warranty terms and conditions vary depending upon the product sold and the country in which the Company does business, but generally includes technical support, parts, and labor over a period ranging from one to three years.  Factors that affect the Company’s warranty liability include the number of installed units currently under warranty, historical and anticipated rates of warranty claims on those units, and cost per claim to satisfy the Company’s warranty obligation.  The anticipated rate of warranty claims is the primary factor impacting the estimated warranty obligation.  The other factors are less significant due to the fact that the average remaining aggregate warranty period of the covered installed base is approximately 18 months, repair parts are generally already in stock or available at pre-determined prices, and labor rates are generally arranged at preestablished amounts with service providers.  Warranty claims are relatively predictable based on historical experience of failure rates.  If actual results differ from the estimates, the Company revises its estimated warranty liability.  Each quarter, the Company reevaluates its estimates to assess the adequacy of its recorded warranty liabilities and adjusts the amounts as necessary.

[0001571996-19-000008:notes:64]
Vendor Rebates and Settlements — The Company may receive consideration from vendors in the normal course of business.  Certain of these funds are rebates of purchase price paid and others are related to reimbursement of costs incurred by the Company to sell the vendor’s products.  The Company recognizes a reduction of cost of goods sold if the funds are determined to be a reduction of the price of the vendor’s products.  If the consideration is a reimbursement of costs incurred by the Company to sell or develop the vendor’s products, then the consideration is classified as a reduction of that cost, most often operating expenses, in the Consolidated Statements of Income (Loss).  In order to be recognized as a reduction of operating expenses, the reimbursement must be for a specific, incremental, and identifiable cost incurred by the Company in selling the vendor’s products or services.

[0001571996-19-000008:notes:65]
In addition, the Company may settle commercial disputes with vendors from time to time.  Claims for loss recoveries are recognized when a loss event has occurred, recovery is considered probable, the agreement is finalized, and collectibility is assured.  Amounts received by the Company from vendors for loss recoveries are generally recorded as a reduction of cost of goods sold.

[0001571996-19-000008:notes:66]
Loss Contingencies — The Company is subject to the possibility of various losses arising in the ordinary course of business.  The Company considers the likelihood of loss or impairment of an asset or the incurrence of a liability, as well as the Company’s ability to reasonably estimate the amount of loss, in determining loss contingencies.  An estimated loss contingency is accrued when it is probable that an asset has been impaired or a liability has been incurred and the amount of loss can be reasonably estimated.  The Company regularly evaluates current information available to determine whether such accruals should be adjusted and whether new accruals are required.

[0001571996-19-000008:notes:67]
Shipping Costs — The Company’s shipping and handling costs are included in cost of net revenue in the Consolidated Statements of Income (Loss).

[0001571996-19-000008:notes:68]
Selling, General, and Administrative — Selling expenses include items such as sales salaries and commissions, marketing and advertising costs, and contractor services.  Advertising costs are expensed as incurred in selling, general, and administrative expenses in the Consolidated Statements of Income (Loss).  For the fiscal years ended February 1, 2019, February 2, 2018, and February 3, 2017, advertising expenses were $1,143 million, $1,045 million, and $772 million, respectively.  General and administrative expenses include items for the Company’s administrative functions, such as finance, legal, human resources, and information technology support.  These functions include costs for items such as salaries and benefits and other personnel-related costs, maintenance and supplies, outside services, depreciation expense, and allowance for doubtful accounts.

[0001571996-19-000008:notes:69]
Research and Development — Research and development (“R&D”) costs are expensed as incurred.  R&D costs include salaries and benefits and other personnel-related costs associated with product development.  Also included in R&D expenses are infrastructure costs, which consist of equipment and material costs, facilities-related costs, depreciation expense, and intangible asset amortization.

[0001571996-19-000008:notes:70]
Income Taxes — Deferred tax assets and liabilities are recorded based on the difference between the financial statement and tax basis of assets and liabilities using enacted tax rates in effect for the year in which the differences are expected to reverse.  The Company calculates a provision for income taxes using the asset and liability method, under which deferred tax assets and liabilities are recognized by identifying the temporary differences arising from the different treatment of items for tax and accounting purposes.  The Company accounts for the tax impact of including Global Intangible Low-Taxed Income (GILTI) in U.S. taxable income as a period cost.  The Company provides valuation allowances for deferred tax assets, where appropriate.  In assessing the need for a valuation allowance, the Company considers all available evidence for each jurisdiction, including past operating results, estimates of future taxable income, and the feasibility of ongoing tax planning strategies.  In the event the Company determines that all or part of the net deferred tax assets are not realizable in the future, the Company will make an adjustment to the valuation allowance that would be charged to earnings in the period in which such a determination is made.

[0001571996-19-000008:notes:71]
The accounting guidance for uncertainties in income tax prescribes a comprehensive model for the financial statement recognition, measurement, presentation, and disclosure of uncertain tax positions taken or expected to be taken in income tax returns.  The Company recognizes a tax benefit from an uncertain tax position in the financial statements only when it is more likely than not that the position will be sustained upon examination, including resolution of any related appeals or litigation processes, based on the technical merits and a consideration of the relevant taxing authority’s administrative practices and precedents.

[0001571996-19-000008:notes:72]
Stock-Based Compensation — The Company measures stock-based compensation expense for all share-based awards granted based on the estimated fair value of those awards at grant date.  For service-based stock options, the Company typically estimates the fair value of these awards using the Black-Scholes valuation model and for performance-based awards containing a market condition, the Company estimates the fair value of these awards using the Monte Carlo valuation model.

[0001571996-19-000008:notes:73]
The compensation cost of service-based stock options, restricted stock, and restricted stock units is recognized net of any estimated forfeitures on a straight-line basis over the employee requisite service period.  Compensation cost for performance-based awards is recognized on a graded accelerated basis net of estimated forfeitures over the requisite service period.  Forfeiture rates are estimated at grant date based on historical experience and adjusted in subsequent periods for differences in actual forfeitures from those estimates.  See Note 16 of the Notes to the Consolidated Financial Statements for further discussion of stock-based compensation.

[0001571996-19-000008:notes:74]
Recently Issued Accounting Pronouncements

[0001571996-19-000008:notes:75]
Leases — In February 2016, the Financial Accounting Standards Board (“FASB”) issued amended guidance on the accounting for leasing transactions.  The primary objective of this update is to increase transparency and comparability among organizations by requiring lessees to recognize a lease liability for the obligation to make lease payments and a right-of-use asset for the right to use the underlying asset for the lease term.  The guidance also makes some changes to lessor accounting and requires additional disclosures about all leasing arrangements.  Companies are required to use a modified retrospective approach, with the option of applying the requirements of the standard either (1) retrospectively to each prior comparative reporting period presented, or (2) on a modified retrospective basis at the beginning of the period of adoption.  The Company will adopt this standard on the effective date, which is the first day of the fiscal year ending January 31, 2020.  Prior comparative periods will not be retrospectively presented in the consolidated financial statements.  The Company expects the cumulative-effect adjustment to accumulated deficit upon adoption to be immaterial.

[0001571996-19-000008:notes:76]
In the area of lessee accounting, the Company expects to recognize approximately $1.6 billion operating lease liabilities and related right-of-use assets on the Consolidated Statements of Financial Position upon adoption.

[0001571996-19-000008:notes:77]
In the area of lessor accounting, the Company anticipates that the most significant change will be an increase to future originations of operating leases due to elimination of the third-party residual value guarantee insurance in the sales-type lease test.  Certain leases, which under the current guidance allow for up front revenue recognition as they qualify as sales-type capital leases, will be classified as operating leases, with the revenue and expense recognized over time.  As a result of the expected increase in future originations of operating leases, the Company expects a shift from financing receivables to capital expenditures.  As such, this is expected to result in a benefit to cash flows provided by operating activities by the amount of the increase in capital expenditures, which will be reported as cash flows used in investing activities.

[0001571996-19-000008:notes:78]
Measurement of Credit Losses on Financial Instruments — In June 2016, the FASB issued amended guidance which replaces the current incurred loss impairment methodology for measurement of credit losses on financial instruments with a methodology that reflects expected credit losses and requires consideration of a broader range of reasonable and supportable information to inform credit loss estimates.  Public entities must adopt the new guidance for fiscal years beginning after December 15, 2019, and interim periods within those fiscal years, with early adoption permitted for fiscal periods beginning after December 15, 2018.  The Company is currently evaluating the impact that the standard will have on the Consolidated Financial Statements.

[0001571996-19-000008:notes:79]
Intangibles - Goodwill and Other - Internal-Use Software — In August 2018, the FASB issued guidance on a customer’s accounting for implementation costs incurred in a cloud-computing arrangement when hosted by a vendor.  In a hosting arrangement that is a service contract, certain implementation costs should be capitalized and amortized over the term of the arrangement.  Public entities must adopt the new guidance for fiscal years beginning after December 15, 2019, and interim periods within those fiscal years, with early adoption permitted for fiscal periods beginning after December 15, 2018.  The Company does not expect the adoption of this guidance to have a material impact on the Consolidated Financial Statements.

[0001571996-19-000008:notes:80]
Recently Adopted Accounting Pronouncements

[0001571996-19-000008:notes:81]
Revenue from Contracts with Customers — In May 2014, the FASB issued amended guidance on the recognition of revenue from contracts with customers.  The new standard established a single comprehensive model for entities to use in accounting for revenue arising from contracts with customers and supersedes substantially all of the previous revenue recognition guidance, including industry-specific guidance.  The new standard requires entities to recognize revenue when it transfers promised goods or services to customers in an amount that reflects the consideration to which the entity expects to be entitled in exchange for those goods or services.  Further, the new standard requires additional disclosures to help enable users of the financial statements to better understand the nature, amount, timing, risks, and judgments related to revenue recognition and related cash flows from contracts with customers.  Concurrently, the FASB issued guidance on the accounting for costs to fulfill or obtain a customer contract.  The Company adopted these standards during the three months ended May 4, 2018 using the full retrospective method, which requires the Company to recast each prior period presented consistent with the new guidance.  The Company recorded a credit of approximately $1 billion to retained earnings as of January 29, 2016 to reflect the cumulative effect of the adoption.  See tables provided below that present the impact of the new accounting standards to the Company’s previously reported financial results.

[0001571996-19-000008:notes:82]
Recognition and Measurement of Financial Assets and Financial Liabilities — In January 2016, the FASB issued amended guidance that generally requires changes in the fair value of equity investments, other than those accounted for under the equity method, to be recognized through net income, rather than other comprehensive income.  For equity investments without readily determinable fair values, the Company is no longer permitted to use the cost method of accounting.  The Company has elected to apply the measurement alternative for those investments.  Under the alternative, the Company measures investments without readily determinable fair values at cost, less impairment, adjusted by observable price changes on a prospective basis.  The Company must make a separate election to use the alternative for each eligible investment and is required to reassess at each reporting period whether an investment qualifies for the alternative.  The Company adopted this standard during the three months ended May 4, 2018.  Adoption of the standard was applied through a cumulative one-time adjustment to accumulated deficit of $56 million for the accumulated unrealized gain previously recorded in other comprehensive income.  The impact of the standard on the Consolidated Statements of Income (Loss) for the fiscal year ended February 1, 2019 was a gain of $354 million, recognized in interest and other, net, and the impact in future periods will depend on the relative observable changes in the market price of the equity investments.

[0001571996-19-000008:notes:83]
Classification of Certain Cash Receipts and Cash Payments — In August 2016, the FASB issued amended guidance on the presentation and classification of eight specific cash flow issues with the objective of reducing existing diversity in practice.  Companies should reflect any adjustments on a retrospective basis, if practicable; otherwise, adoption is required to be applied as of the earliest date practicable.  The Company adopted this standard during the three months ended May 4, 2018.  Prior period amounts on the Consolidated Statements of Cash Flows have been recast to conform with current period presentation as shown in the reconciliation provided below.

[0001571996-19-000008:notes:84]
Intra-Entity Transfers of Assets Other Than Inventory — In October 2016, the FASB issued amended guidance on the accounting for income taxes.  The new guidance requires companies to recognize the income tax effects of intra-entity asset transfers, other than transfers of inventory, when the transfer occurs instead of when the asset is sold to a third party.  The new guidance was applied on a modified-retrospective basis with the cumulative-effect adjustment to accumulated deficit as of the beginning of the period of adoption.  The Company early adopted this guidance during the three months ended May 5, 2017.  At adoption, approximately $84 million was reclassified from other non-current liabilities to accumulated deficit, resulting in a net credit to accumulated deficit.

[0001571996-19-000008:notes:85]
Statement of Cash Flows, Restricted Cash — In November 2016, the FASB issued amended guidance requiring entities to include restricted cash and restricted cash equivalents in cash balances on the cash flow statement, and also to provide a supplemental reconciliation of cash, cash equivalents, and restricted cash.  Public entities must adopt the new guidance for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017, with early adoption permitted.  The Company adopted this standard during the three months ended May 4, 2018.  See Note 20 of the Notes to the Consolidated Financial Statements for supplemental cash flow information.  Prior period amounts on the Consolidated Statements of Cash Flows have been recast to conform with current period presentation as shown in the reconciliation provided below.

[0001571996-19-000008:notes:86]
Clarifying the Definition of a Business — In January 2017, the FASB issued amended guidance to clarify the definition of a business with the objective of adding guidance to assist entities with evaluating whether transactions should be accounted for as acquisitions (or disposals) of assets or businesses.  Public entities must adopt the new guidance for fiscal years beginning after December 15, 2017, and interim periods within those fiscal years.  The new guidance did not have a material impact on the Company’s conclusions regarding transactions that were assessed in the current period.

[0001571996-19-000008:notes:87]
Simplifying the Test for Goodwill Impairment — In January 2017, the FASB issued amended guidance to simplify the subsequent measurement of goodwill by removing Step 2 of the goodwill impairment test.  Instead, under the amendments in the new guidance, an entity should perform its annual, or interim, goodwill impairment test by comparing the fair value of a reporting unit with its carrying amount.  An entity should recognize an impairment charge for the amount by which the carrying amount exceeds the reporting unit’s fair value.  Public entities must adopt the new guidance in fiscal years beginning after December 15, 2019, with early adoption permitted.  In conjunction with its annual goodwill and indefinite-lived intangible assets impairment testing which occurs during the third fiscal quarter of each year, the Company elected to early adopt this guidance during the three months ended November 2, 2018.  An interim goodwill impairment test was not required during the three months ended May 4, 2018 or the three months ended August 3, 2018.  See Note 8 of the Notes to the Consolidated Financial Statements for additional information about goodwill impairment testing.

[0001571996-19-000008:notes:88]
Derivatives and Hedging — In August 2017, the FASB issued amended guidance that will make more financial and non-financial hedging strategies eligible for hedge accounting.  The amended guidance changes how companies assess effectiveness, and also amends the presentation and disclosure requirements.  The guidance is intended to simplify the application of hedge accounting and increase transparency as to the scope and results of hedging programs.  Immediate early adoption is permitted in any interim or annual period.  The Company elected to early adopt this standard during the three months ended May 4, 2018.  The impact of the adoption of the standard was immaterial to the Consolidated Financial Statements.

[0001571996-19-000008:notes:89]
Income Statement - Reporting Comprehensive Income — In February 2018, the FASB issued guidance that will permit entities to reclassify the tax effects stranded in accumulated other comprehensive income to accumulated deficit as a result of U.S. Tax Reform, discussed in Note 11 of the Notes to the Consolidated Financial Statements.  The guidance gives entities the option to reclassify these amounts, but requires new disclosures regardless of whether they elect to do so.  The guidance is effective for fiscal years beginning after December 15, 2018, and interim periods within those fiscal years.  The Company elected to early adopt this standard during the three months ended May 4, 2018 and recorded the impact of the adoption as a cumulative adjustment to accumulated deficit.  The impact of the adoption was immaterial to the Consolidated Financial Statements.

[0001571996-19-000008:notes:90]
Impacts to Previously Reported Periods

[0001571996-19-000008:notes:91]
The following tables present the impact of the new accounting standards to the Company’s previously reported financial results.

[0001571996-19-000008:notes:92]
Selected Captions from the Consolidated Statement of Financial Position

[0001571996-19-000008:notes:93]
|  | February 2, 2018 |
|  | As Reported (a) |  | Revenue from Contracts with Customers |  | As Recast |
|  | (in millions) |
| Assets |  |  |  |  |  |
| Accounts receivable, net | $ | 11,177 |  |  | $ | 544 |  |  | $ | 11,721 |  |
| Other current assets | $ | 5,054 |  |  | $ | 827 |  |  | $ | 5,881 |  |
| Other non-current assets | $ | 1,862 |  |  | $ | 541 |  |  | $ | 2,403 |  |
| Liabilities and Stockholders’ Equity |  |  |  |  |  |
| Accrued and other | $ | 7,661 |  |  | $ | 365 |  |  | $ | 8,026 |  |
| Short-term deferred revenue | $ | 12,024 |  |  | $ | (418 | ) |  | $ | 11,606 |  |
| Long-term deferred revenue | $ | 10,223 |  |  | $ | (1,013 | ) |  | $ | 9,210 |  |
| Other non-current liabilities | $ | 6,797 |  |  | $ | 480 |  |  | $ | 7,277 |  |
| Accumulated deficit | $ | (9,253 | ) |  | $ | 2,393 |  |  | $ | (6,860 | ) |
| Non-controlling interests | $ | 5,661 |  |  | $ | 105 |  |  | $ | 5,766 |  |

[0001571996-19-000008:notes:94]
| (a) | Amounts as reported in the Company’s annual report on Form 10-K for the fiscal year ended February 2, 2018. |

[0001571996-19-000008:notes:95]
The above impacts are summarized as follows:

[0001571996-19-000008:notes:96]
Accounts receivable, net — The adoption of the new revenue standard resulted in an increase to accounts receivable, net primarily due to the following two factors:

[0001571996-19-000008:notes:97]
| • | First, the return rights provision, which represents an estimate of expected customer returns, that was previously presented as a reduction of accounts receivable, net is now being presented outside of accounts receivable, net in two separate balance sheet line items. A liability is recorded in accrued and other for the estimated value of the sales amounts to be returned to the customer, and an asset is recorded in other current assets representing the recoverable cost of the inventory estimated to be returned. |

[0001571996-19-000008:notes:98]
| • | Second, the standard provides new guidance regarding transfer of control of goods to the customer. Under these new guidelines, the Company has determined that for certain hardware contracts in the United States, transfer of control and recognition of revenue can occur earlier. This determination resulted in an increase in accounts receivable, net and a decrease in the in-transit deferral recorded in other current assets. |

[0001571996-19-000008:notes:99]
Other assets — The adoption of the new revenue standard resulted in an increase in other assets due to capitalization of the costs to obtain a contract, as well as the accounts receivable, net of impacts discussed above.

[0001571996-19-000008:notes:100]
Deferred revenue — The adoption of the new revenue standard resulted in a decrease in deferred revenue due to earlier recognition of revenue for software licenses, and a reduction in the portion of the aggregate transaction price allocated to the extended warranty.  Deferred revenue was also reduced by the impact of variable consideration (i.e., price concessions, rebates, and refunds).  The reduction in deferred revenue was partially offset by an increase resulting from the change in presentation of deferred costs on third-party software offerings, which are reported in other assets, and are either sold on a standalone basis or as an attached component of the Company’s hardware offering.  The Company previously reported the associated deferred revenue net of these deferred costs in deferred revenue.

[0001571996-19-000008:notes:101]
Consolidated Statements of Income (Loss)

[0001571996-19-000008:notes:102]
|  | Fiscal Year Ended |
|  | February 2, 2018 |  | February 3, 2017 |
|  | As Reported (a) |  | Revenue from Contracts with Customers |  | As Recast |  | As Reported (a) |  | Revenue from Contracts with Customers |  | As Recast |
|  | (in millions, except per share amounts) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Products | $ | 58,801 |  |  | $ | 2,450 |  |  | $ | 61,251 |  |  | $ | 48,706 |  |  | $ | 2,351 |  |  | $ | 51,057 |  |
| Services | 19,859 |  |  | (2,070 | ) |  | 17,789 |  |  | 12,936 |  |  | (1,829 | ) |  | 11,107 |  |
| Total net revenue | 78,660 |  |  | 380 |  |  | 79,040 |  |  | 61,642 |  |  | 522 |  |  | 62,164 |  |
| Cost of net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Products | 50,215 |  |  | 1,218 |  |  | 51,433 |  |  | 42,169 |  |  | 1,219 |  |  | 43,388 |  |
| Services | 8,391 |  |  | (1,321 | ) |  | 7,070 |  |  | 6,514 |  |  | (1,387 | ) |  | 5,127 |  |
| Total cost of net revenue | 58,606 |  |  | (103 | ) |  | 58,503 |  |  | 48,683 |  |  | (168 | ) |  | 48,515 |  |
| Gross margin | 20,054 |  |  | 483 |  |  | 20,537 |  |  | 12,959 |  |  | 690 |  |  | 13,649 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative | 19,003 |  |  | (434 | ) |  | 18,569 |  |  | 13,575 |  |  | (172 | ) |  | 13,403 |  |
| Research and development | 4,384 |  |  | — |  |  | 4,384 |  |  | 2,636 |  |  | — |  |  | 2,636 |  |
| Total operating expenses | 23,387 |  |  | (434 | ) |  | 22,953 |  |  | 16,211 |  |  | (172 | ) |  | 16,039 |  |
| Operating loss | (3,333 | ) |  | 917 |  |  | (2,416 | ) |  | (3,252 | ) |  | 862 |  |  | (2,390 | ) |
| Interest and other, net | (2,355 | ) |  | 2 |  |  | (2,353 | ) |  | (2,104 | ) |  | — |  |  | (2,104 | ) |
| Income (loss) before income taxes | (5,688 | ) |  | 919 |  |  | (4,769 | ) |  | (5,356 | ) |  | 862 |  |  | (4,494 | ) |
| Income tax provision (benefit) | (1,833 | ) |  | (10 | ) |  | (1,843 | ) |  | (1,619 | ) |  | 199 |  |  | (1,420 | ) |
| Net income (loss) from continuing operations | (3,855 | ) |  | 929 |  |  | (2,926 | ) |  | (3,737 | ) |  | 663 |  |  | (3,074 | ) |
| Income (loss) from discontinued operations, net of income taxes | — |  |  | — |  |  | — |  |  | 2,019 |  |  | (103 | ) |  | 1,916 |  |
| Net income (loss) | $ | (3,855 | ) |  | $ | 929 |  |  | (2,926 | ) |  | (1,718 | ) |  | $ | 560 |  |  | (1,158 | ) |
| Less: Net income (loss) attributable to non-controlling interests | (127 | ) |  | 50 |  |  | (77 | ) |  | (46 | ) |  | 55 |  |  | 9 |  |
| Net income (loss) attributable to Dell Technologies Inc. | $ | (3,728 | ) |  | $ | 879 |  |  | $ | (2,849 | ) |  | $ | (1,672 | ) |  | $ | 505 |  |  | $ | (1,167 | ) |
| Earnings (loss) per share attributable to Dell Technologies Inc. - basic: |  |  |  |  |  |  |  |  |
| Class V Common Stock - basic | $ | 1.41 |  |  | 0.22 |  |  | $ | 1.63 |  |  | $ | 1.44 |  |  | (0.08 | ) |  | $ | 1.36 |  |
| DHI Group - basic | $ | (7.08 | ) |  | 1.47 |  |  | $ | (5.61 | ) |  | $ | (8.52 | ) |  | 1.33 |  |  | $ | (7.19 | ) |
| Discontinued operations - DHI Group - basic | $ | — |  |  | — |  |  | $ | — |  |  | 4.30 |  |  | (0.22 | ) |  | $ | 4.08 |  |
| Earnings (loss) per share attributable to Dell Technologies Inc. - diluted: |  |  |  |  |  |  |  |  |
| Class V Common Stock - diluted | $ | 1.39 |  |  | 0.22 |  |  | $ | 1.61 |  |  | $ | 1.43 |  |  | (0.08 | ) |  | $ | 1.35 |  |
| DHI Group - diluted | $ | (7.08 | ) |  | 1.46 |  |  | $ | (5.62 | ) |  | $ | (8.52 | ) |  | 1.33 |  |  | $ | (7.19 | ) |
| Discontinued operations - DHI Group - basic | $ | — |  |  | — |  |  | $ | — |  |  | $ | 4.30 |  |  | (0.22 | ) |  | $ | 4.08 |  |

[0001571996-19-000008:notes:103]
Net revenue — The adoption of the new revenue standard resulted in an increase to net revenue due to earlier revenue recognition than permitted under the previous standard.

[0001571996-19-000008:notes:104]
Products revenue vs. services revenue — The adoption of the new revenue standard resulted in a change to the classification of products revenue vs. services revenue, due to the following factors:

[0001571996-19-000008:notes:105]
| • | Under the new revenue standard, amounts within a contract are now allocated to the product and services performance obligations based on their respective standalone selling prices, which generally increases product revenue and decreases services revenue relative to previously reported results. |

[0001571996-19-000008:notes:106]
| • | Further, third-party software licenses were previously recognized in services revenue as the Company could not separate the value of the software license from the associated maintenance agreement. Under the new revenue standard, the license value requires separation and will be recognized in product revenue, and the value of the software maintenance will continue to be recognized in services revenue. |

[0001571996-19-000008:notes:107]
Operating expenses — The adoption of the new revenue standard resulted in a decrease to operating expenses due to the deferral of the incremental direct costs of obtaining a contract.

[0001571996-19-000008:notes:108]
Selected Captions from the Consolidated Statement of Cash Flows

[0001571996-19-000008:notes:109]
|  | Fiscal Year Ended February 2, 2018 |
|  | As Reported (a) |  | Classification of Certain Cash Receipts and Cash Payments |  | Statement of Cash Flows, Restricted Cash |  | As Recast |
|  | (in millions) |
| Change in cash from operating activities | $ | 6,810 |  |  | $ | 48 |  |  | $ | (15 | ) |  | $ | 6,843 |  |
| Change in cash from investing activities | $ | (2,881 | ) |  | $ | — |  |  | $ | 6 |  |  | $ | (2,875 | ) |
| Change in cash from financing activities | $ | 364 |  |  | $ | (48 | ) |  | $ | 87 |  |  | $ | 403 |  |
| Change in cash, cash equivalents, and restricted cash | $ | 4,468 |  |  | $ | — |  |  | $ | 78 |  |  | $ | 4,546 |  |
| Cash, cash equivalents, and restricted cash at beginning of the period | 9,474 |  |  | — |  |  | 358 |  |  | $ | 9,832 |  |
| Cash, cash equivalents, and restricted cash at end of the period | $ | 13,942 |  |  | $ | — |  |  | $ | 436 |  |  | $ | 14,378 |  |
|  | Fiscal Year Ended February 3, 2017 |
|  | As Reported (a) |  | Classification of Certain Cash Receipts and Cash Payments |  | Statement of Cash Flows, Restricted Cash |  | As Recast |
|  | (in millions) |
| Change in cash from operating activities | $ | 2,309 |  |  | $ | 39 |  |  | $ | 19 |  |  | $ | 2,367 |  |
| Change in cash from investing activities | $ | (31,256 | ) |  | $ | — |  |  | $ | 20 |  |  | $ | (31,236 | ) |
| Change in cash from financing activities | $ | 31,821 |  |  | $ | (39 | ) |  | $ | 3 |  |  | $ | 31,785 |  |
| Change in cash, cash equivalents, and restricted cash | $ | 2,898 |  |  | $ | — |  |  | $ | 42 |  |  | $ | 2,940 |  |
| Cash, cash equivalents, and restricted cash at beginning of the period | 6,576 |  |  | — |  |  | 316 |  |  | $ | 6,892 |  |
| Cash, cash equivalents, and restricted cash at end of the period | $ | 9,474 |  |  | $ | — |  |  | $ | 358 |  |  | $ | 9,832 |  |

[0001571996-19-000008:notes:110]
(a)
Amounts as reported in the Company’s annual report on Form 10-K for the fiscal year ended February 2, 2018.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock

[0001571996-19-000008:notes:111]
Loss Contingencies — The Company is subject to the possibility of various losses arising in the ordinary course of business.  The Company considers the likelihood of loss or impairment of an asset or the incurrence of a liability, as well as the Company’s ability to reasonably estimate the amount of loss, in determining loss contingencies.  An estimated loss contingency is accrued when it is probable that an asset has been impaired or a liability has been incurred and the amount of loss can be reasonably estimated.  The Company regularly evaluates current information available to determine whether such accruals should be adjusted and whether new accruals are required.
The Company accrues a liability when it believes that it is both probable that a liability has been incurred and that it can reasonably estimate the amount of the loss.  The Company reviews these accruals at least quarterly and adjusts them to reflect ongoing negotiations, settlements, rulings, advice of legal counsel, and other relevant information.  To the extent new information is obtained and the Company’s views on the probable outcomes of claims, suits, assessments, investigations, or legal proceedings change, changes in the Company’s accrued liabilities would be recorded in the period in which such a determination is made.  For some matters, the amount of liability is not probable or the amount cannot be reasonably estimated and therefore accruals have not been made.


## us-gaap:ScheduleOfNewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0001571996-19-000008:notes:112]
(a)
Amounts as reported in the Company’s annual report on Form 10-K for the fiscal year ended February 2, 2018.
Consolidated Statements of Income (Loss)


## us-gaap:FairValueDisclosuresTextBlock

[0001571996-19-000008:notes:113]
FAIR VALUE MEASUREMENTS

[0001571996-19-000008:notes:114]
The following table presents the Company’s hierarchy for its assets and liabilities measured at fair value on a recurring basis as of February 1, 2019 and February 2, 2018:

[0001571996-19-000008:notes:115]
|  | February 1, 2019 (a) |  | February 2, 2018 (a) |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | QuotedPricesin ActiveMarkets forIdenticalAssets |  | SignificantOtherObservableInputs |  | SignificantUnobservableInputs |  |  |  | QuotedPricesin ActiveMarkets forIdenticalAssets |  | SignificantOtherObservableInputs |  | SignificantUnobservableInputs |  |  |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 5,221 |  |  | $ | — |  |  | $ | — |  |  | $ | 5,221 |  |  | $ | 8,641 |  |  | $ | — |  |  | $ | — |  |  | $ | 8,641 |  |
| U.S. corporate debt securities | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 23 |  |  | — |  |  | 23 |  |
| Foreign corporate debt securities | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 65 |  |  | — |  |  | 65 |  |
| Debt securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government and agencies | — |  |  | — |  |  | — |  |  | — |  |  | 682 |  |  | 392 |  |  | — |  |  | 1,074 |  |
| U.S. corporate | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 2,003 |  |  | — |  |  | 2,003 |  |
| Foreign | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 2,547 |  |  | — |  |  | 2,547 |  |
| Equity and other securities | 314 |  |  | 20 |  |  | — |  |  | 334 |  |  | 236 |  |  | 5 |  |  | — |  |  | 241 |  |
| Derivative instruments | — |  |  | 97 |  |  | — |  |  | 97 |  |  | — |  |  | 83 |  |  | — |  |  | 83 |  |
| Total assets | $ | 5,535 |  |  | $ | 117 |  |  | $ | — |  |  | $ | 5,652 |  |  | $ | 9,559 |  |  | $ | 5,118 |  |  | $ | — |  |  | $ | 14,677 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative instruments | $ | — |  |  | $ | 60 |  |  | $ | — |  |  | $ | 60 |  |  | $ | — |  |  | $ | 184 |  |  | $ | — |  |  | $ | 184 |  |
| Total liabilities | $ | — |  |  | $ | 60 |  |  | $ | — |  |  | $ | 60 |  |  | $ | — |  |  | $ | 184 |  |  | $ | — |  |  | $ | 184 |  |

[0001571996-19-000008:notes:116]
| (a) | The Company did not transfer any financial instruments between levels during the fiscal years ended February 1, 2019 and February 2, 2018. |

[0001571996-19-000008:notes:117]
The following section describes the valuation methodologies the Company uses to measure financial instruments at fair value:

[0001571996-19-000008:notes:118]
Money Market Funds — The Company’s investment in money market funds that are classified as cash equivalents hold underlying investments with a weighted average maturity of 90 days or less and are recognized at fair value.  The valuations of these securities are based on quoted prices in active markets for identical assets, when available, or pricing models whereby all significant inputs are observable or can be derived from or corroborated by observable market data.  The Company reviews security pricing and assesses liquidity on a quarterly basis.  As of February 1, 2019, the Company’s U.S. portfolio had no material exposure to money market funds with a fluctuating net asset value.

[0001571996-19-000008:notes:119]
Equity and Other Securities — The majority of the Company’s investments in equity and other securities that are measured at fair value on a recurring basis consist of strategic investments in publicly-traded companies.  The valuation of these securities is based on quoted prices in active markets.

[0001571996-19-000008:notes:120]
Debt Securities — The majority of the Company’s debt securities consists of various fixed income securities such as U.S. government and agencies, U.S. corporate, and foreign.  Valuation is based on pricing models whereby all significant inputs, including benchmark yields, reported trades, broker-dealer quotes, issue spreads, benchmark securities, bids, offers, and other market related data, are observable or can be derived from or corroborated by observable market data for substantially the full term of the asset.  Inputs are documented in accordance with the fair value measurements hierarchy.  The Company reviews security pricing and assesses liquidity on a quarterly basis.  See Note 4 of the Notes to the Consolidated Financial Statements for additional information about investments.

[0001571996-19-000008:notes:121]
Derivative Instruments — The Company’s derivative financial instruments consist primarily of foreign currency forward and purchased option contracts and interest rate swaps.  The fair value of the portfolio is determined using valuation models based on market observable inputs, including interest rate curves, forward and spot prices for currencies, and implied volatilities.  Credit risk is also factored into the fair value calculation of the Company’s derivative instrument portfolio.  See Note 7 of the Notes to the Consolidated Financial Statements for a description of the Company’s derivative financial instrument activities.

[0001571996-19-000008:notes:122]
Assets and Liabilities Measured at Fair Value on a Nonrecurring Basis — Certain assets are measured at fair value on a nonrecurring basis and therefore are not included in the recurring fair value table above.  These assets consist primarily of non-financial assets such as goodwill and intangible assets.  See Note 8 of the Notes to the Consolidated Financial Statements for additional information about goodwill and intangible assets.

[0001571996-19-000008:notes:123]
As of February 1, 2019 and February 2, 2018, the Company held private strategic investments of $671 million and $485 million, respectively.  As these investments represent early-stage companies without readily determinable fair values, they are not included in the recurring fair value table above.

[0001571996-19-000008:notes:124]
The Company has elected to apply the measurement alternative for these investments.  Under the alternative, the Company measures investments without readily determinable fair values at cost, less impairment, adjusted by observable price changes.  The Company must make a separate election to use the alternative for each eligible investment and is required to reassess at each reporting period whether an investment qualifies for the alternative.  In evaluating these investments for impairment or observable price changes, the Company uses inputs including pre- and post-money valuations of recent financing events and the impact of those on its fully diluted ownership percentages, as well as other available information regarding the issuer’s historical and forecasted performance.

[0001571996-19-000008:notes:125]
Carrying Value and Estimated Fair Value of Outstanding Debt — The following table summarizes the carrying value and estimated fair value of the Company’s outstanding debt as described in Note 6 of the Notes to the Consolidated Financial Statements, including the current portion, as of the dates indicated:

[0001571996-19-000008:notes:126]
|  | February 1, 2019 |  | February 2, 2018 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Secured Credit Facilities | $ | 12.5 |  |  | $ | 12.6 |  |  | $ | 10.4 |  |  | $ | 10.6 |  |
| First Lien Notes | $ | 19.8 |  |  | $ | 21.0 |  |  | $ | 19.7 |  |  | $ | 21.9 |  |
| Unsecured Notes and Debentures | $ | 1.8 |  |  | $ | 1.9 |  |  | $ | 2.3 |  |  | $ | 2.5 |  |
| Senior Notes | $ | 3.1 |  |  | $ | 3.4 |  |  | $ | 3.1 |  |  | $ | 3.4 |  |
| EMC Notes | $ | 3.0 |  |  | $ | 2.9 |  |  | $ | 5.5 |  |  | $ | 5.4 |  |
| VMware Notes | $ | 4.0 |  |  | $ | 3.9 |  |  | $ | 4.0 |  |  | $ | 3.9 |  |
| Margin Loan Facility | $ | 3.3 |  |  | $ | 3.4 |  |  | $ | 2.0 |  |  | $ | 2.0 |  |

[0001571996-19-000008:notes:127]
The fair values of the outstanding debt shown in the table above, as well as the DFS debt described in Note 5 of the Notes to the Consolidated Financial Statements, were determined based on observable market prices in a less active market or based on valuation methodologies using observable inputs and were categorized as Level 2 in the fair value hierarchy.  The carrying value of DFS debt approximates fair value.


## invest:InvestmentTextBlock

[0001571996-19-000008:notes:128]
NOTE 4 — INVESTMENTS

[0001571996-19-000008:notes:129]
The following table summarizes, by major security type, the carrying value and amortized cost of the Company’s investments.  All debt security investments with remaining effective maturities in excess of one year and substantially all equity and other securities are recorded as long-term investments in the Consolidated Statements of Financial Position.

[0001571996-19-000008:notes:130]
|  | February 1, 2019 |  | February 2, 2018 |
|  | Cost |  | Unrealized Gain |  | Unrealized (Loss) |  | Carrying Value |  | Cost |  | Unrealized Gain |  | Unrealized (Loss) |  | Carrying Value |
|  | (in millions) |
| Investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government and agencies | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 485 |  |  | $ | — |  |  | $ | (2 | ) |  | $ | 483 |  |
| U.S. corporate debt securities | — |  |  | — |  |  | — |  |  | — |  |  | 660 |  |  | — |  |  | (2 | ) |  | 658 |  |
| Foreign debt securities | — |  |  | — |  |  | — |  |  | — |  |  | 1,048 |  |  | — |  |  | (2 | ) |  | 1,046 |  |
| Total short-term investments | — |  |  | — |  |  | — |  |  | — |  |  | 2,193 |  |  | — |  |  | (6 | ) |  | 2,187 |  |
| U.S. government and agencies | — |  |  | — |  |  | — |  |  | — |  |  | 600 |  |  | — |  |  | (9 | ) |  | 591 |  |
| U.S. corporate debt securities | — |  |  | — |  |  | — |  |  | — |  |  | 1,361 |  |  | — |  |  | (16 | ) |  | 1,345 |  |
| Foreign debt securities | — |  |  | — |  |  | — |  |  | — |  |  | 1,518 |  |  | — |  |  | (17 | ) |  | 1,501 |  |
| Equity and other securities (a) | 638 |  |  | 539 |  |  | (172 | ) |  | 1,005 |  |  | 640 |  |  | 86 |  |  | — |  |  | 726 |  |
| Total long-term investments | 638 |  |  | 539 |  |  | (172 | ) |  | 1,005 |  |  | 4,119 |  |  | 86 |  |  | (42 | ) |  | 4,163 |  |
| Total investments | $ | 638 |  |  | $ | 539 |  |  | $ | (172 | ) |  | $ | 1,005 |  |  | $ | 6,312 |  |  | $ | 86 |  |  | $ | (48 | ) |  | $ | 6,350 |  |

[0001571996-19-000008:notes:131]
| (a) | $671 million and $485 million of equity and other securities as of February 1, 2019 and February 2, 2018, respectively, are private strategic investments without readily determinable fair values, which are recorded at cost, less impairment, and adjusted for observable price changes. For the fiscal year ended February 1, 2019, the equity and other securities without readily determinable fair values increased by $233 million due to upward adjustments for observable price changes, offset by $80 million of downward adjustments that were primarily attributable to impairments. The remainder of equity and other securities consists of publicly-traded investments that are measured at fair value on a recurring basis. See Note 3 of the Notes to the Consolidated Financial Statements for additional information on investments measured at fair value. |

[0001571996-19-000008:notes:132]
The Company’s investments in debt securities are classified as available-for-sale securities, which are carried at fair value.  Subsequent to the Class V transaction described in Note 14 of the Notes to the Consolidated Financial Statements and as of February 1, 2019, the Company did not hold any investments in debt securities.  As of February 2, 2018, the aggregate fair value of investments held in a continuous unrealized loss position for greater than 12 months was $1.9 billion, and the unrealized loss on these investments was $25 million.


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0001571996-19-000008:notes:133]
NOTE 5 — FINANCIAL SERVICES

[0001571996-19-000008:notes:134]
The Company offers or arranges various financing options and services, and alternative payment structures for its customers in North America, Europe, Australia, and New Zealand through Dell Financial Services and its affiliates (“DFS”).  The Company also arranges financing for some of its customers in various countries where DFS does not currently operate as a captive.  The key activities of DFS include originating, collecting, and servicing of customer financing arrangements primarily related to the purchase or usage of Dell Technologies products and services.  In some cases, DFS also offers financing on the purchase of third-party technology products that complement the Dell Technologies portfolio of products and services.  New financing originations were $7.3 billion, $6.3 billion, and $4.5 billion for the fiscal years ended February 1, 2019, February 2, 2018, and February 3, 2017, respectively.

[0001571996-19-000008:notes:135]
Financing Receivables

[0001571996-19-000008:notes:136]
The Company’s financing receivables are aggregated into the following categories:

[0001571996-19-000008:notes:137]
| • | Revolving loans — Revolving loans offered under private label credit financing programs provide qualified customers with a revolving credit line for the purchase of products and services offered by Dell Technologies. These private label credit financing programs are referred to as Dell Preferred Account (“DPA”) and Dell Business Credit (“DBC”). The DPA product is primarily offered to individual consumer customers, and the DBC product is primarily offered to small and medium-sized commercial customers. Revolving loans in the United States bear interest at a variable annual percentage rate that is tied to the prime rate. Based on historical payment patterns, revolving loan transactions are typically repaid within twelve months on average. Due to the short-term nature of the revolving loan portfolio, the carrying value of the portfolio approximates fair value. |

[0001571996-19-000008:notes:138]
| • | Fixed-term sales-type leases and loans — The Company enters into sales-type lease arrangements with customers who seek lease financing. Leases with business customers have fixed terms of generally two to four years. Future maturities of minimum lease and associated financing payments as of February 1, 2019 were as follows: $2.6 billion in Fiscal 2020; $1.7 billion in Fiscal 2021; $0.9 billion in Fiscal 2022; $0.3 billion in Fiscal 2023; and $0.1 billion in Fiscal 2024 and beyond. Future maturities and associated financing payments referenced herein represent the aggregate payments under the customer lease contract. The Company also offers fixed-term loans to qualified small businesses, large commercial accounts, governmental organizations, educational entities, and certain individual consumer customers. These loans are repaid in equal payments including interest and have defined terms of generally three to five years. The fair value of the fixed-term loan portfolio is determined using market observable inputs. The carrying value of these loans approximates fair value. |

[0001571996-19-000008:notes:139]
The following table summarizes the components of the Company’s financing receivables segregated by portfolio segment as of February 1, 2019 and February 2, 2018:

[0001571996-19-000008:notes:140]
|  | February 1, 2019 |  | February 2, 2018 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Financing receivables, net: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Customer receivables, gross (a) | $ | 835 |  |  | $ | 7,249 |  |  | $ | 8,084 |  |  | $ | 900 |  |  | $ | 6,282 |  |  | $ | 7,182 |  |
| Allowances for losses | (75 | ) |  | (61 | ) |  | (136 | ) |  | (81 | ) |  | (64 | ) |  | (145 | ) |
| Customer receivables, net | 760 |  |  | 7,188 |  |  | 7,948 |  |  | 819 |  |  | 6,218 |  |  | 7,037 |  |
| Residual interest | — |  |  | 674 |  |  | 674 |  |  | — |  |  | 606 |  |  | 606 |  |
| Financing receivables, net | $ | 760 |  |  | $ | 7,862 |  |  | $ | 8,622 |  |  | $ | 819 |  |  | $ | 6,824 |  |  | $ | 7,643 |  |
| Short-term | $ | 760 |  |  | $ | 3,638 |  |  | $ | 4,398 |  |  | $ | 819 |  |  | $ | 3,100 |  |  | $ | 3,919 |  |
| Long-term | $ | — |  |  | $ | 4,224 |  |  | $ | 4,224 |  |  | $ | — |  |  | $ | 3,724 |  |  | $ | 3,724 |  |

[0001571996-19-000008:notes:141]
| (a) | Customer financing receivables, gross includes accrued interest. |

[0001571996-19-000008:notes:142]
The following table presents the changes in allowance for financing receivable losses for the respective periods:

[0001571996-19-000008:notes:143]
|  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |  |  |  |  |  |
| Balances as of January 29, 2016 | $ | 118 |  |  | $ | 58 |  |  | $ | 176 |  |
| Charge-offs, net of recoveries | (91 | ) |  | (17 | ) |  | (108 | ) |
| Provision charged to income statement | 64 |  |  | 11 |  |  | 75 |  |
| Balances as of February 3, 2017 | 91 |  |  | 52 |  |  | 143 |  |
| Charge-offs, net of recoveries | (84 | ) |  | (17 | ) |  | (101 | ) |
| Provision charged to income statement | 74 |  |  | 29 |  |  | 103 |  |
| Balances as of February 2, 2018 | 81 |  |  | 64 |  |  | 145 |  |
| Charge-offs, net of recoveries | (78 | ) |  | (26 | ) |  | (104 | ) |
| Provision charged to income statement | 72 |  |  | 23 |  |  | 95 |  |
| Balances as of February 1, 2019 | $ | 75 |  |  | $ | 61 |  |  | $ | 136 |  |

[0001571996-19-000008:notes:144]
The following table summarizes the aging of the Company’s customer financing receivables, gross, including accrued interest, as of February 1, 2019 and February 2, 2018, segregated by class:

[0001571996-19-000008:notes:145]
|  | February 1, 2019 |  | February 2, 2018 |
|  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |
|  | (in millions) |
| Revolving — DPA | $ | 583 |  |  | $ | 53 |  |  | $ | 21 |  |  | $ | 657 |  |  | $ | 633 |  |  | $ | 59 |  |  | $ | 23 |  |  | $ | 715 |  |
| Revolving — DBC | 155 |  |  | 19 |  |  | 4 |  |  | 178 |  |  | 162 |  |  | 19 |  |  | 4 |  |  | 185 |  |
| Fixed-term — Consumer and Commercial | 6,282 |  |  | 878 |  |  | 89 |  |  | 7,249 |  |  | 5,414 |  |  | 775 |  |  | 93 |  |  | 6,282 |  |
| Total customer receivables, gross | $ | 7,020 |  |  | $ | 950 |  |  | $ | 114 |  |  | $ | 8,084 |  |  | $ | 6,209 |  |  | $ | 853 |  |  | $ | 120 |  |  | $ | 7,182 |  |

[0001571996-19-000008:notes:146]
Aging is likely to fluctuate year to year as a result of the variability in volume of large transactions entered into over the period, and the administrative processes that accompany those larger transactions.  As such, fluctuations in aging do not necessarily indicate a material change in the credit quality of the portfolio.

[0001571996-19-000008:notes:147]
Credit Quality

[0001571996-19-000008:notes:148]
The following table summarizes customer receivables, gross, including accrued interest, by credit quality indicator segregated by class, as of February 1, 2019 and February 2, 2018.  The categories shown in the table below segregate customer receivables based on the relative degrees of credit risk.  The credit quality indicators for DPA revolving accounts are measured primarily as of each quarter-end date, while all other indicators are generally updated on a periodic basis.

[0001571996-19-000008:notes:149]
|  | February 1, 2019 |  | February 2, 2018 |
|  | Higher |  | Mid |  | Lower |  | Total |  | Higher |  | Mid |  | Lower |  | Total |
|  | (in millions) |
| Revolving — DPA | $ | 128 |  |  | $ | 192 |  |  | $ | 337 |  |  | $ | 657 |  |  | $ | 131 |  |  | $ | 223 |  |  | $ | 361 |  |  | $ | 715 |  |
| Revolving — DBC | $ | 47 |  |  | $ | 54 |  |  | $ | 77 |  |  | $ | 178 |  |  | $ | 48 |  |  | $ | 58 |  |  | $ | 79 |  |  | $ | 185 |  |
| Fixed-term — Consumer and Commercial | $ | 3,980 |  |  | $ | 1,984 |  |  | $ | 1,285 |  |  | $ | 7,249 |  |  | $ | 3,334 |  |  | $ | 1,828 |  |  | $ | 1,120 |  |  | $ | 6,282 |  |

[0001571996-19-000008:notes:150]
For DPA revolving receivables shown in the table above, the Company makes credit decisions based on proprietary scorecards, which include the customer’s credit history, payment history, credit usage, and other credit agency-related elements.  The higher quality category includes prime accounts generally of a higher credit quality that are comparable to U.S. customer FICO scores of 720 or above.  The mid-category represents the mid-tier accounts that are comparable to U.S. customer FICO scores from 660 to 719.  The lower category is generally sub-prime and represents lower credit quality accounts that are comparable to U.S. customer FICO scores below 660.  For the DBC revolving receivables and fixed-term commercial receivables shown in the table above, an internal grading system is utilized that assigns a credit level score based on a number of considerations, including liquidity, operating performance, and industry outlook.  The grading criteria and classifications for the fixed-term products differ from those for the revolving products as loss experience varies between these product and customer groups.  The credit quality categories cannot be compared between the different classes as loss experience varies substantially between the classes.

[0001571996-19-000008:notes:151]
DFS Debt

[0001571996-19-000008:notes:152]
The Company maintains programs that facilitate the funding of financing receivables and other alternative payment structures in the capital markets.  The following table summarizes DFS debt as of the periods indicated.  The table excludes the allocated portion of the Company’s other borrowings, which represents the additional amount considered to fund the DFS business.

[0001571996-19-000008:notes:153]
|  | February 1, 2019 |  | February 2, 2018 |
|  | (in millions) |
| DFS U.S. debt: |  |  |  |
| Securitization facilities | $ | 1,914 |  |  | $ | 1,498 |  |
| Fixed-term securitization offerings | 2,303 |  |  | 2,034 |  |
| Other | 223 |  |  | 32 |  |
| Total DFS U.S. debt | 4,440 |  |  | 3,564 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 584 |  |  | 404 |  |
| Other borrowings | 708 |  |  | 628 |  |
| Note payable | 197 |  |  | 200 |  |
| Total DFS international debt | 1,489 |  |  | 1,232 |  |
| Total DFS debt | $ | 5,929 |  |  | $ | 4,796 |  |
| Total short-term DFS debt | $ | 3,113 |  |  | $ | 3,327 |  |
| Total long-term DFS debt | $ | 2,816 |  |  | $ | 1,469 |  |

[0001571996-19-000008:notes:154]
DFS U.S. Debt

[0001571996-19-000008:notes:155]
Securitization Facilities — The Company maintains separate securitization facilities in the United States for fixed-term leases and loans and for revolving loans.  This debt is collateralized solely by the U.S. financing receivables in the facilities.  The debt has a variable interest rate and the duration of the debt is based on the terms of the underlying financing receivables.  As of February 1, 2019, the total debt capacity related to the U.S. securitization facilities was $3.5 billion.  The Company enters into interest swap agreements to effectively convert a portion of its securitization debt from a floating rate to a fixed rate.  See Note 7 of the Notes to the Consolidated Financial Statements for additional information about interest rate swaps.

[0001571996-19-000008:notes:156]
The Company’s U.S. securitization facility for revolving loans is effective through June 1, 2020.  The Company’s two U.S. securitization facilities for fixed-term leases and loans are effective through February 10, 2020 and February 22, 2020, respectively.

[0001571996-19-000008:notes:157]
The securitization facilities contain standard structural features related to the performance of the securitized receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the facility, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of February 1, 2019, these criteria were met.

[0001571996-19-000008:notes:158]
Fixed-Term Securitization Offerings — The Company periodically issues asset-backed debt securities under fixed-term securitization programs to private investors.  The asset-backed debt securities are collateralized solely by the U.S. fixed-term financing receivables in the offerings, which are held by Special Purpose Entities (“SPEs”), as discussed below.  The interest rate on these securities is fixed and ranges from 1.97% to 3.97% per annum, and the duration of these securities is based on the terms of the underlying financing receivables.

[0001571996-19-000008:notes:159]
DFS International Debt

[0001571996-19-000008:notes:160]
Securitization Facility — The Company maintains a securitization facility in Europe for fixed-term leases and loans.  This facility is effective through December 21, 2020 and had a total debt capacity of $916 million as of February 1, 2019.

[0001571996-19-000008:notes:161]
The securitization facility contains standard structural features related to the performance of the securitized receivables which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the program, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of February 1, 2019, these criteria were met.

[0001571996-19-000008:notes:162]
Other Borrowings — In connection with the Company’s international financing operations, the Company has entered in to revolving structured financing debt programs related to its fixed-term lease and loan products sold in Canada, Europe, Australia, and New Zealand.  The Canadian facility, which is collateralized solely by Canadian financing receivables, had a total debt capacity of $229 million as of February 1, 2019, and is effective through January 16, 2023.  The European facility, which is collateralized solely by European financing receivables, had a total debt capacity of $687 million as of February 1, 2019, and is effective through December 14, 2020.  The Australia and New Zealand facility, which is collateralized solely by Australia and New Zealand financing receivables, had a total debt capacity of $131 million as of February 1, 2019, and is effective through January 29, 2020.

[0001571996-19-000008:notes:163]
Note Payable — On November 27, 2017, the Company entered into an unsecured credit agreement to fund receivables in Mexico.  As of February 1, 2019, the aggregate principal amount of the note payable is $197 million.  The note bears interest at either the applicable London Interbank Offered Rate (“LIBOR”) plus 2.25%, for the borrowings denominated in U.S. dollars, or the Mexican Interbank Equilibrium Interest Rate (“TIIE”) plus 2.00%, for the borrowings denominated in Mexican pesos.  The note will mature on December 1, 2020.  Although the note is unsecured, the Company intends to manage the note in the same manner as its structured financing programs, so that the collections from financing receivables in Mexico will be used to pay down principal and interest of the note.

[0001571996-19-000008:notes:164]
Variable Interest Entities

[0001571996-19-000008:notes:165]
In connection with the securitization facilities and offerings discussed above, the Company transfers certain U.S. and European customer financing receivables to SPEs that meet the definition of a Variable Interest Entity (“VIE”) and are consolidated, along with the associated debt, into the Consolidated Financial Statements, as the Company is the primary beneficiary of those VIEs.  The SPEs are bankruptcy-remote legal entities with separate assets and liabilities.  The purpose of the SPEs is to facilitate the funding of customer receivables in the capital markets.

[0001571996-19-000008:notes:166]
The following table shows financing receivables held by the consolidated VIEs as of the respective dates:

[0001571996-19-000008:notes:167]
|  | February 1, 2019 |  | February 2, 2018 |
|  | (in millions) |
| Financing receivables held by consolidated VIEs, net: |  |  |  |  |  |
| Short-term, net | $ | 2,940 |  |  | $ | 2,572 |  |
| Long-term, net | 2,508 |  |  | 1,981 |  |
| Financing receivables held by consolidated VIEs, net | $ | 5,448 |  |  | $ | 4,553 |  |

[0001571996-19-000008:notes:168]
Financing receivables transferred via securitization through SPEs were $4.6 billion and $3.9 billion for the fiscal years ended February 1, 2019 and February 2, 2018, respectively.

[0001571996-19-000008:notes:169]
Some of the SPEs have entered into financing arrangements with multi-seller conduits that, in turn, issue asset-backed debt securities in the capital markets.  The DFS debt outstanding, which is collateralized by the financing receivables held by the consolidated VIEs, was $4.8 billion and $3.9 billion as of February 1, 2019 and February 2, 2018, respectively.  The Company’s risk of loss related to securitized receivables is limited to the amount by which the Company’s right to receive collections for assets securitized exceeds the amount required to pay interest, principal, and fees and expenses related to the asset-backed securities.  The Company provides credit enhancement to the securitization in the form of over-collateralization.

[0001571996-19-000008:notes:170]
Financing Receivable Sales

[0001571996-19-000008:notes:171]
To manage certain concentrations of customer credit exposure, the Company may sell selected fixed-term financing receivables to unrelated third parties on a periodic basis.  The amount of financing receivables sold was $949 million, $683 million, and $321 million for the fiscal years ended February 1, 2019, February 2, 2018, and February 3, 2017, respectively.


## us-gaap:ScheduleOfDebtTableTextBlock

[0001571996-19-000008:notes:172]
The following table summarizes DFS debt as of the periods indicated.  The table excludes the allocated portion of the Company’s other borrowings, which represents the additional amount considered to fund the DFS business.

[0001571996-19-000008:notes:173]
The following table summarizes the Company’s outstanding debt as of the dates indicated:

[0001571996-19-000008:notes:174]
|  | February 1, 2019 |  | February 2, 2018 |
|  | (in millions) |
| Secured Debt |  |  |  |
| Senior Secured Credit Facilities: |  |  |  |
| 4.50% Term Loan B Facility due September 2023 | $ | 4,938 |  |  | $ | 4,988 |  |
| 4.25% Term Loan A-2 Facility due September 2021 | 4,116 |  |  | 4,394 |  |
| Term Loan A-3 Facility due December 2018 | — |  |  | 1,213 |  |
| 4.25% Term Loan A-4 Facility due December 2023 | 1,650 |  |  | — |  |
| 4.25% Term Loan A-5 Facility due December 2019 | 2,016 |  |  | — |  |
| First Lien Notes: |  |  |  |
| 3.48% due June 2019 | 3,750 |  |  | 3,750 |  |
| 4.42% due June 2021 | 4,500 |  |  | 4,500 |  |
| 5.45% due June 2023 | 3,750 |  |  | 3,750 |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 8.10% due July 2036 | 1,500 |  |  | 1,500 |  |
| 8.35% due July 2046 | 2,000 |  |  | 2,000 |  |
| Unsecured Debt |  |  |  |
| Unsecured Notes and Debentures: |  |  |  |
| 5.65% due April 2018 | — |  |  | 500 |  |
| 5.875% due June 2019 | 600 |  |  | 600 |  |
| 4.625% due April 2021 | 400 |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| Senior Notes: |  |  |  |
| 5.875% due June 2021 | 1,625 |  |  | 1,625 |  |
| 7.125% due June 2024 | 1,625 |  |  | 1,625 |  |
| EMC Notes: |  |  |  |
| 1.875% due June 2018 | — |  |  | 2,500 |  |
| 2.650% due June 2020 | 2,000 |  |  | 2,000 |  |
| 3.375% due June 2023 | 1,000 |  |  | 1,000 |  |
| VMware Notes: |  |  |  |
| 2.30% due August 2020 | 1,250 |  |  | 1,250 |  |
| 2.95% due August 2022 | 1,500 |  |  | 1,500 |  |
| 3.90% due August 2027 | 1,250 |  |  | 1,250 |  |
| DFS Debt (Note 5) | 5,929 |  |  | 4,796 |  |
| Other |  |  |  |
| 4.99% Margin Loan Facility due April 2022 | 3,350 |  |  | 2,000 |  |
| Other | 38 |  |  | 101 |  |
| Total debt, principal amount | $ | 54,239 |  |  | $ | 52,694 |  |

[0001571996-19-000008:notes:175]
|  | February 1, 2019 |  | February 2, 2018 |
|  | (in millions) |
| Total debt, principal amount | $ | 54,239 |  |  | $ | 52,694 |  |
| Unamortized discount, net of unamortized premium | (271 | ) |  | (266 | ) |
| Debt issuance costs | (447 | ) |  | (557 | ) |
| Total debt, carrying value | $ | 53,521 |  |  | $ | 51,871 |  |
| Total short-term debt, carrying value | $ | 4,320 |  |  | $ | 7,873 |  |
| Total long-term debt, carrying value (a) | $ | 49,201 |  |  | $ | 43,998 |  |

[0001571996-19-000008:notes:176]
(a)
Subsequent to the fiscal year ended February 1, 2019, the Company issued long-term debt and used the net proceeds to repay all of the First Lien Notes due June 2019 and the Term Loan A-5 Facility due December 2019.  As of February 1, 2019, the carrying values of the First Lien Notes due June 2019 and Term Loan A-5 Facility due December 2019 were classified as long-term debt.  See Note 24 of the Notes to the Consolidated Financial Statements for additional information regarding debt issuances and refinancing transactions.


## us-gaap:DebtDisclosureTextBlock

[0001571996-19-000008:notes:177]
NOTE 6 — DEBT

[0001571996-19-000008:notes:178]
| (a) | Subsequent to the fiscal year ended February 1, 2019, the Company issued long-term debt and used the net proceeds to repay all of the First Lien Notes due June 2019 and the Term Loan A-5 Facility due December 2019. As of February 1, 2019, the carrying values of the First Lien Notes due June 2019 and Term Loan A-5 Facility due December 2019 were classified as long-term debt. See Note 24 of the Notes to the Consolidated Financial Statements for additional information regarding debt issuances and refinancing transactions. |

[0001571996-19-000008:notes:179]
During the fiscal year ended February 1, 2019, the Company repaid $3.0 billion principal amount of its unsecured notes and $1.5 billion principal amount of its term loan facilities, which included approximately $0.3 billion of amortization.  The Term Loan A-3 Facility was fully repaid during the three months ended November 2, 2018.

[0001571996-19-000008:notes:180]
In connection with the Class V transaction described in Note 14 of the Notes to the Consolidated Financial Statements, on December 20, 2018, the Company entered into an amendment to the credit agreement for the Senior Secured Credit Facilities, described below, which included (a) a new senior secured Term Loan A-4 Facility under its Senior Secured Credit Facilities consisting of $1.7 billion term A-4 loans, (b) a new senior secured Term Loan A-5 Facility under the Senior Secured Credit Facilities consisting of $2.0 billion term A-5 loans, (c) $1.4 billion in incremental loans under the Margin Loan Facility, and (d) an increase in the aggregate revolving commitments available under the Revolving Credit Facility to $4.5 billion. See below for additional information regarding the Senior Secured Credit Facilities.

[0001571996-19-000008:notes:181]
The Company issued an additional $1.2 billion, net, in DFS debt to support the expansion of its financing receivables portfolio during the fiscal year ended February 1, 2019.

[0001571996-19-000008:notes:182]
Secured Debt

[0001571996-19-000008:notes:183]
Senior Secured Credit Facilities — The Company has entered into a credit agreement that provides for senior secured credit facilities (the “Senior Secured Credit Facilities”) comprising (a) term loan facilities and (b) a senior secured Revolving Credit Facility, which includes capacity for up to $0.5 billion of letters of credit and for borrowings of up to $0.4 billion under swing-line loans.  As of February 1, 2019, the senior secured credit facilities had an aggregate principal amount of $17.6 billion.

[0001571996-19-000008:notes:184]
As of February 1, 2019, available borrowings under the Revolving Credit Facility totaled $4.5 billion.  The Senior Secured Credit Facilities provide that the borrowers have the right at any time, subject to customary conditions, to request incremental term loans or incremental revolving commitments.

[0001571996-19-000008:notes:185]
Borrowings under the Senior Secured Credit Facilities bear interest at a rate per annum equal to an applicable margin, plus, at the borrowers’ option, either (a) a base rate, which, under the Term Loan B Facility, is subject to an interest rate floor of 1.75% per annum, and under all other borrowings is subject to an interest rate floor of 0% per annum, or (b) a London Interbank Offered Rate (“LIBOR”), which, under the Term Loan B Facility, is subject to an interest rate floor of 0.75% per annum, and under all other borrowings is subject to an interest rate floor of 0% per annum.  Interest is payable, in the case of loans bearing interest based on LIBOR, at the end of each interest period (but at least every three months), in arrears and, in the case of loans bearing interest based on the base rate, quarterly in arrears.

[0001571996-19-000008:notes:186]
The Term Loan B Facility amortizes in equal quarterly installments in aggregate annual amounts equal to 1% of the original principal amount.  The Term Loan A-2 Facility amortizes in equal quarterly installments in aggregate annual amounts equal to 5% of the original principal amount in the first year after the closing date of the refinancing transaction on October 20, 2017, 10% of the original principal amount in each of the second and third years after October 20, 2017, and 75% of the original principal amount in the fourth year after October 20, 2017.  The Term Loan A-4 Facility amortizes in equal quarterly installments in aggregate annual amounts equal to 5% of the original principal in the first four years after the facility closing date of December 20, 2018, and 80% of the original principal amount in the fifth year after December 20, 2018.  The Term Loan A-5 Facility and the Revolving Credit Facility have no amortization.

[0001571996-19-000008:notes:187]
The borrowers may voluntarily repay outstanding loans under the term loan facilities and the Revolving Credit Facility at any time without premium or penalty, other than customary “breakage” costs.

[0001571996-19-000008:notes:188]
All obligations of the borrowers under the Senior Secured Credit Facilities and certain swap agreements, cash management arrangements, and certain letters of credit provided by any lender or agent party to the Senior Secured Credit Facilities or any of its affiliates and certain other persons are secured by (a) a first-priority security interest in certain tangible and intangible assets of the borrowers and the guarantors and (b) a first-priority pledge of 100% of the capital stock of the borrowers, Dell Inc., a wholly‑owned subsidiary of the Company (“Dell”), and each wholly-owned material restricted subsidiary of the borrowers and the guarantors, in each case subject to certain thresholds, exceptions, and permitted liens.

[0001571996-19-000008:notes:189]
First Lien Notes — The senior secured notes (collectively, the “First Lien Notes”) were issued on June 1, 2016 in an aggregate principal amount of $20.0 billion.  Interest on these borrowings is payable semiannually.  The First Lien Notes are secured, on a pari passu basis with the Senior Secured Credit Facilities, on a first-priority basis by substantially all of the tangible and intangible assets of the issuers and guarantors that secure obligations under the Senior Secured Credit Facilities, including pledges of all capital stock of the issuers, Dell, and certain wholly-owned material subsidiaries of the issuers and the guarantors, subject to certain exceptions.

[0001571996-19-000008:notes:190]
The Company has agreed to use commercially reasonable efforts to register with the SEC notes having terms substantially identical to the terms of the First Lien Notes as part of an offer to exchange such registered notes for the First Lien Notes.  The Company will be obligated to pay additional interest on the First Lien Notes if it fails to consummate such an exchange offer within five years after the closing date of the EMC merger transaction.

[0001571996-19-000008:notes:191]
China Revolving Credit Facility — On October 31, 2017, the Company entered into a credit agreement (the “China Revolving Credit Facility”) with a bank lender for a secured revolving loan facility in an aggregate principal amount not to exceed $500 million at an interest rate of LIBOR plus 0.6% per annum.  The facility expired on October 31, 2018, with no outstanding borrowings due.  Unaudited update: Subsequent to the fiscal year ended February 1, 2019, the China Revolving Credit Facility was renewed.  The new terms provide an uncommitted line, with no change to the aggregate principal amount of $500 million at an interest rate of LIBOR plus 0.6% per annum.  The new facility expires on February 26, 2020.

[0001571996-19-000008:notes:192]
Unsecured Debt

[0001571996-19-000008:notes:193]
Unsecured Notes and Debentures — The Company has outstanding unsecured notes and debentures (collectively, the “Unsecured Notes and Debentures”) that were issued by Dell prior to the acquisition of Dell by Dell Technologies Inc. in the going-private transaction that closed in October 2013.  Interest on these borrowings is payable semiannually.

[0001571996-19-000008:notes:194]
Senior Notes — The senior unsecured notes (collectively, the “Senior Notes”) were issued on June 22, 2016 in an aggregate principal amount of $3.25 billion.  Interest on these borrowings is payable semiannually.

[0001571996-19-000008:notes:195]
EMC Notes — On September 7, 2016, EMC had outstanding $2.5 billion aggregate principal amount of its 1.875% Notes due June 2018, which the Company fully repaid during the three months ended August 3, 2018, $2.0 billion aggregate principal amount of its 2.650% Notes due June 2020, and $1.0 billion aggregate principal amount of its 3.375% Notes due June 2023 (collectively, the “EMC Notes”).  Interest on these borrowings is payable semiannually.

[0001571996-19-000008:notes:196]
VMware Notes — On August 21, 2017, VMware, Inc. completed a public offering of unsecured senior notes in the aggregate amount of $4.0 billion, consisting of outstanding principal due on the following dates: $1.25 billion due August 21, 2020, $1.50 billion due August 21, 2022, and $1.25 billion due August 21, 2027 (collectively, the “VMware Notes”).  The VMware Notes bear interest, payable semiannually, at annual rates of 2.30%, 2.95%, and 3.90%, respectively.  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.

[0001571996-19-000008:notes:197]
VMware Revolving Credit Facility — On September 12, 2017, VMware, Inc. entered into an unsecured credit agreement, establishing a revolving credit facility (the “VMware Revolving Credit Facility”), with a syndicate of lenders that provides the company with a borrowing capacity of up to $1.0 billion which may be used for VMware, Inc. general corporate purposes.  Commitments under the VMware Revolving Credit Facility are available for a period of five years, which may be extended, subject to the satisfaction of certain conditions, by up to two one year periods.  The credit agreement contains certain representations, warranties, and covenants.  Commitment fees, interest rates, and other terms of borrowing under the VMware Revolving Credit Facility may vary based on VMware, Inc.’s external credit ratings.  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.  As of February 1, 2019, there were no outstanding borrowings under the VMware Revolving Credit Facility.

[0001571996-19-000008:notes:198]
See Note 5 and Note 7 of the Notes to the Consolidated Financial Statements, respectively, for discussion of DFS debt and the interest rate swap agreements that hedge a portion of that debt.

[0001571996-19-000008:notes:199]
Margin Loan Facility — On April 12, 2017, the Company entered into the Margin Loan Facility in an aggregate principal amount of $2.0 billion.  In connection with the Class V transaction, on December 20, 2018, the Company amended the Margin Loan Facility to increase the aggregate principal amount of the facility to $3.4 billion.  VMW Holdco LLC, a wholly-owned subsidiary of EMC, is the borrower under the Margin Loan Facility, which is secured by 60 million shares of Class B common stock of VMware, Inc. and 20 million shares of Class A common stock of VMware, Inc.  Loans under the Margin Loan Facility bear interest at a rate per annum payable, at the borrower’s option, either at (a) a base rate plus 1.25% per annum or (b) a LIBOR-based rate plus 2.25% per annum.  Interest under the Margin Loan Facility is payable quarterly.

[0001571996-19-000008:notes:200]
The Margin Loan Facility will mature in April 2022.  The borrower may voluntarily repay outstanding loans under the Margin Loan Facility at any time without premium or penalty, other than customary “breakage” costs, subject to certain minimum threshold amounts for prepayment.

[0001571996-19-000008:notes:201]
Pivotal Revolving Credit Facility — On September 7, 2017, Pivotal entered into a credit agreement (the “Pivotal Revolving Credit Facility”) that provides for a senior secured revolving loan facility in an aggregate principal amount not to exceed $100 million.  The credit facility contains customary representations, warranties, and covenants, including financial covenants.  The credit agreement will expire on September 8, 2020, unless it is terminated earlier.  None of the net proceeds of borrowings under the facility will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of Pivotal and Pivotal’s subsidiaries.  As of February 1, 2019, there were no outstanding borrowings under the Pivotal Revolving Credit Facility.

[0001571996-19-000008:notes:202]
Aggregate Future Maturities

[0001571996-19-000008:notes:203]
As of February 1, 2019, aggregate future maturities of the Company’s debt were as follows:

[0001571996-19-000008:notes:204]
|  | Maturities by Fiscal Year |
|  | 2020 |  | 2021 |  | 2022 |  | 2023 |  | 2024 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Secured Credit Facilities and First Lien Notes | $ | 6,344 |  |  | $ | 433 |  |  | $ | 7,969 |  |  | $ | 166 |  |  | $ | 9,807 |  |  | $ | 8,001 |  |  | $ | 32,720 |  |
| Unsecured Notes and Debentures | 600 |  |  | — |  |  | 400 |  |  | — |  |  | — |  |  | 952 |  |  | 1,952 |  |
| Senior Notes and EMC Notes | — |  |  | 2,000 |  |  | 1,625 |  |  | — |  |  | 1,000 |  |  | 1,625 |  |  | 6,250 |  |
| VMware Notes | — |  |  | 1,250 |  |  | — |  |  | 1,500 |  |  | — |  |  | 1,250 |  |  | 4,000 |  |
| DFS Debt | 3,113 |  |  | 2,373 |  |  | 335 |  |  | 95 |  |  | 13 |  |  | — |  |  | 5,929 |  |
| Margin Loan Facility | — |  |  | — |  |  | — |  |  | 3,350 |  |  | — |  |  | — |  |  | 3,350 |  |
| Other | 29 |  |  | 9 |  |  | — |  |  | — |  |  | — |  |  |  |  |  | 38 |  |
| Total maturities, principal amount | 10,086 |  |  | 6,065 |  |  | 10,329 |  |  | 5,111 |  |  | 10,820 |  |  | 11,828 |  |  | 54,239 |  |
| Associated carrying value adjustments | (40 | ) |  | (6 | ) |  | (136 | ) |  | (30 | ) |  | (163 | ) |  | (343 | ) |  | (718 | ) |
| Total maturities, carrying value amount | $ | 10,046 |  |  | $ | 6,059 |  |  | $ | 10,193 |  |  | $ | 5,081 |  |  | $ | 10,657 |  |  | $ | 11,485 |  |  | $ | 53,521 |  |

[0001571996-19-000008:notes:205]
The table above classifies aggregate future maturities based on respective contractual maturities as of February 1, 2019.  However, subsequent to February 1, 2019, the Company issued long-term debt and used the net proceeds to repay all of the First Lien Notes due June 2019 and the Term Loan A-5 Facility due December 2019.  Due to the completion of refinancing transactions, the carrying value amounts of the First Lien Notes and Term Loan A-5 Facility were classified as long-term debt within the Company’s Consolidated Statement of Financial Position as of February 1, 2019.  See Note 24 of the Notes to the Consolidated Financial Statements for additional information regarding debt issuances and refinancing transactions.

[0001571996-19-000008:notes:206]
Covenants and Unrestricted Net Assets — The credit agreement for the Senior Secured Credit Facilities contains customary negative covenants that generally limit the ability of Denali Intermediate Inc., a wholly-owned subsidiary of Dell Technologies (“Dell Intermediate”), Dell, and Dell’s and Denali Intermediate’s other restricted subsidiaries to incur debt, create liens, make fundamental changes, enter into asset sales, make certain investments, pay dividends or distribute or redeem certain equity interests, prepay or redeem certain debt, and enter into certain transactions with affiliates.  The indenture governing the Senior Notes contains customary negative covenants that generally limit the ability of Denali Intermediate, Dell, and Dell’s and Denali Intermediate’s other restricted subsidiaries to incur additional debt or issue certain preferred shares, pay dividends on or make other distributions in respect of capital stock or make other restricted payments, make certain investments, sell or transfer certain assets, create liens on certain assets to secure debt, consolidate, merge, sell, or otherwise dispose of all or substantially all assets, enter into certain transactions with affiliates, and designate subsidiaries as unrestricted subsidiaries.

[0001571996-19-000008:notes:207]
The negative covenants under such credit agreements and indenture are subject to certain exceptions, qualifications, and “baskets.”  The indentures governing the First Lien Notes, the Unsecured Notes and Debentures, and the EMC Notes variously impose limitations, subject to specified exceptions, on creating certain liens, entering into sale and lease-back transactions, and entering into certain asset sales.  The foregoing credit agreements and indentures contain customary events of default, including failure to make required payments, failure to comply with covenants, and the occurrence of certain events of bankruptcy and insolvency.

[0001571996-19-000008:notes:208]
As of February 1, 2019, the Company had certain consolidated subsidiaries that were designated as unrestricted subsidiaries for all purposes of the applicable credit agreements and the indentures governing the First Lien Notes and the Senior Notes.   Substantially all of the net assets of the Company’s consolidated subsidiaries were restricted, with the exception of the Company’s unrestricted subsidiaries, primarily VMware Inc., Secureworks, Pivotal, and their respective subsidiaries, as of February 1, 2019.

[0001571996-19-000008:notes:209]
The Term Loan A-2 Facility, the Term Loan A-4 Facility, the Term Loan A-5 Facility, and the Revolving Credit Facility are subject to a first lien leverage ratio covenant that is tested at the end of each fiscal quarter of Dell with respect to Dell’s preceding four fiscal quarters.  The Company was in compliance with all financial covenants as of February 1, 2019.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001571996-19-000008:notes:210]
NOTE 7 — DERIVATIVE INSTRUMENTS AND HEDGING ACTIVITIES

[0001571996-19-000008:notes:211]
As part of its risk management strategy, the Company uses derivative instruments, primarily foreign currency forward and option contracts and interest rate swaps, to hedge certain foreign currency and interest rate exposures, respectively.

[0001571996-19-000008:notes:212]
The Company’s objective is to offset gains and losses resulting from these exposures with gains and losses on the derivative contracts used to hedge the exposures, thereby reducing volatility of earnings and protecting the fair values of assets and liabilities.  The earnings effects of the derivative instruments are presented in the same income statement line items as the earnings effects of the hedged items.  For derivatives designated as cash flow hedges, the Company assesses hedge effectiveness both at the onset of the hedge and at regular intervals throughout the life of the derivative.  The Company does not have any derivatives designated as fair value hedges.

[0001571996-19-000008:notes:213]
Foreign Exchange Risk

[0001571996-19-000008:notes:214]
The Company uses foreign currency forward and option contracts designated as cash flow hedges to protect against the foreign currency exchange rate risks inherent in its forecasted transactions denominated in currencies other than the U.S. dollar.  Hedge accounting is applied based upon the criteria established by accounting guidance for derivative instruments and hedging activities.  The risk of loss associated with purchased options is limited to premium amounts paid for the option contracts.  The risk of loss associated with forward contracts is equal to the exchange rate differential from the time the contract is entered into until the time it is settled.  The majority of these contracts typically expire in twelve months or less.

[0001571996-19-000008:notes:215]
During the fiscal years ended February 1, 2019, February 2, 2018, and February 3, 2017, the Company did not discontinue any cash flow hedges related to foreign exchange contracts that had a material impact on the Company’s results of operations due to the probability that the forecasted cash flows would not occur.

[0001571996-19-000008:notes:216]
The Company uses forward contracts to hedge monetary assets and liabilities denominated in a foreign currency.  These contracts generally expire in three months or less, are considered economic hedges, and are not designated for hedge accounting.  The change in the fair value of these instruments represents a natural hedge as their gains and losses offset the changes in the underlying fair value of the monetary assets and liabilities due to movements in currency exchange rates.

[0001571996-19-000008:notes:217]
In connection with expanded offerings of DFS in Europe, forward contracts are used to hedge financing receivables denominated in foreign currencies.  These contracts are not designated for hedge accounting and most expire within three years or less.

[0001571996-19-000008:notes:218]
Interest Rate Risk

[0001571996-19-000008:notes:219]
The Company uses interest rate swaps to hedge the variability in cash flows related to the interest rate payments on structured financing debt.  The interest rate swaps economically convert the variable rate on the structured financing debt to a fixed interest rate to match the underlying fixed rate being received on fixed-term customer leases and loans.  These contracts are not designated for hedge accounting and most expire within three years or less.

[0001571996-19-000008:notes:220]
Interest rate swaps are utilized to manage the interest rate risk, at a portfolio level, associated with DFS operations in Europe.  The interest rate swaps economically convert the fixed rate on financing receivables to a three-month Euribor floating rate basis in order to match the floating rate nature of the banks’ funding pool.  These contracts are not designated for hedge accounting and most expire within five years or less.

[0001571996-19-000008:notes:221]
The Company utilizes cross currency amortizing swaps to hedge the currency and interest rate risk exposure associated with the securitization program that was established in Europe in January 2017.  The cross currency swaps combine a Euro-based interest rate swap with a British Pound or U.S. Dollar foreign exchange forward contract in which the Company pays a fixed British Pound or U.S. Dollar amount and receives a floating amount in Euros linked to the one-month Euribor.  The notional value of the swaps amortizes in line with the expected cash flows and run-off of the securitized assets.  The swaps are not designated for hedge accounting and expire within five years or less.

[0001571996-19-000008:notes:222]
Derivative Instruments

[0001571996-19-000008:notes:223]
Notional Amounts of Outstanding Derivative Instruments

[0001571996-19-000008:notes:224]
|  | February 1, 2019 |  | February 2, 2018 |
|  | (in millions) |
| Foreign exchange contracts: |  |  |  |  |  |
| Designated as cash flow hedging instruments | $ | 7,573 |  |  | $ | 4,392 |  |
| Non-designated as hedging instruments | 6,129 |  |  | 6,223 |  |
| Total | $ | 13,702 |  |  | $ | 10,615 |  |
| Interest rate contracts: |  |  |  |
| Non-designated as hedging instruments | $ | 2,674 |  |  | $ | 1,897 |  |

[0001571996-19-000008:notes:225]
Effect of Derivative Instruments Designated as Hedging Instruments on the Consolidated Statements of Financial Position and the Consolidated Statements of Income (Loss)

[0001571996-19-000008:notes:226]
| Derivatives in Cash Flow Hedging Relationships |  | Gain (Loss) Recognized in Accumulated OCI, Net of Tax, on Derivatives |  | Location of Gain (Loss) Reclassified from Accumulated OCI into Income |  | Gain (Loss) Reclassified from Accumulated OCI into Income |  | Location of Gain (Loss) Recognized in Income on Derivative (Ineffective Portion) |  | Gain (Loss) Recognized in Income on Derivative (Ineffective Portion) |
|  |  | (in millions) |  |  |  | (in millions) |  |  |  | (in millions) |
| For the fiscal year ended February 1, 2019 |  |  |  |  |
|  |  |  |  |  | Total net revenue |  | $ | 225 |  |  |  |  |  |
| Foreign exchange contracts |  | $ | 299 |  |  | Total cost of net revenue |  | — |  |  |  |  |  |
| Interest rate contracts |  | — |  |  | Interest and other, net |  | — |  |  | Interest and other, net |  | — |  |
| Total |  | $ | 299 |  |  |  |  | $ | 225 |  |  |  |  | $ | — |  |
| For the fiscal year ended February 2, 2018 |  |  |  |  |
|  |  |  |  |  | Total net revenue |  | $ | (77 | ) |  |  |  |  |
| Foreign exchange contracts |  | $ | (248 | ) |  | Total cost of net revenue |  | (57 | ) |  |  |  |  |
| Interest rate contracts |  | — |  |  | Interest and other, net |  | — |  |  | Interest and other, net |  | — |  |
| Total |  | $ | (248 | ) |  |  |  | $ | (134 | ) |  |  |  | $ | — |  |
| For the fiscal year ended February 3, 2017 |  |  |  |  |
|  |  |  |  |  | Total net revenue |  | $ | 57 |  |  |  |  |  |
| Foreign exchange contracts |  | $ | 20 |  |  | Total cost of net revenue |  | (13 | ) |  |  |  |  |
| Interest rate contracts |  | — |  |  | Interest and other, net |  | — |  |  | Interest and other, net |  | (1 | ) |
| Total |  | $ | 20 |  |  |  |  | $ | 44 |  |  |  |  | $ | (1 | ) |

[0001571996-19-000008:notes:227]
Effect of Derivative Instruments Not Designated as Hedging Instruments on the Consolidated Statements of Income (Loss)

[0001571996-19-000008:notes:228]
|  | Fiscal Year Ended |  |  |
|  | February 1, 2019 |  | February 2, 2018 |  | February 3, 2017 |  | Location of Gain (Loss) Recognized |
|  | (in millions) |  |  |
| Foreign exchange contracts | $ | (67 | ) |  | $ | (106 | ) |  | $ | (9 | ) |  | Interest and other, net |
| Interest rate contracts | (8 | ) |  | 4 |  |  | (3 | ) |  | Interest and other, net |
| Total | $ | (75 | ) |  | $ | (102 | ) |  | $ | (12 | ) |  |  |

[0001571996-19-000008:notes:229]
Fair Value of Derivative Instruments in the Consolidated Statements of Financial Position

[0001571996-19-000008:notes:230]
The Company presents its foreign exchange derivative instruments on a net basis in the Consolidated Statements of Financial Position due to the right of offset by its counterparties under master netting arrangements.  The fair value of those derivative instruments presented on a gross basis as of each date indicated below was as follows:

[0001571996-19-000008:notes:231]
|  | February 1, 2019 |
|  | Other CurrentAssets |  | Other Non-Current Assets |  | Other CurrentLiabilities |  | Other Non-CurrentLiabilities |  | TotalFair Value |
|  |  |  | (in millions) |  |  |
| Derivatives designated as hedging instruments: |
| Foreign exchange contracts in an asset position | $ | 45 |  |  | $ | — |  |  | $ | 29 |  |  | $ | — |  |  | $ | 74 |  |
| Foreign exchange contracts in a liability position | (19 | ) |  | — |  |  | (20 | ) |  | — |  |  | (39 | ) |
| Net asset (liability) | 26 |  |  | — |  |  | 9 |  |  | — |  |  | 35 |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts in an asset position | 178 |  |  | — |  |  | 57 |  |  | — |  |  | 235 |  |
| Foreign exchange contracts in a liability position | (110 | ) |  | — |  |  | (115 | ) |  | (2 | ) |  | (227 | ) |
| Interest rate contracts in an asset position | — |  |  | 3 |  |  | — |  |  | — |  |  | 3 |  |
| Interest rate contracts in a liability position | — |  |  | — |  |  | — |  |  | (9 | ) |  | (9 | ) |
| Net asset (liability) | 68 |  |  | 3 |  |  | (58 | ) |  | (11 | ) |  | 2 |  |
| Total derivatives at fair value | $ | 94 |  |  | $ | 3 |  |  | $ | (49 | ) |  | $ | (11 | ) |  | $ | 37 |  |
|  | February 2, 2018 |
|  | Other CurrentAssets |  | Other Non-Current Assets |  | Other CurrentLiabilities |  | Other Non-CurrentLiabilities |  | TotalFair Value |
|  |  |  | (in millions) |  |  |
| Derivatives designated as hedging instruments: |
| Foreign exchange contracts in an asset position | $ | 9 |  |  | $ | — |  |  | $ | 11 |  |  | $ | — |  |  | $ | 20 |  |
| Foreign exchange contracts in a liability position | (7 | ) |  | — |  |  | (52 | ) |  | — |  |  | (59 | ) |
| Net asset (liability) | 2 |  |  | — |  |  | (41 | ) |  | — |  |  | (39 | ) |
| Derivatives not designated as hedging instruments: |
| Foreign exchange contracts in an asset position | 194 |  |  | 3 |  |  | 141 |  |  | — |  |  | 338 |  |
| Foreign exchange contracts in a liability position | (127 | ) |  | — |  |  | (283 | ) |  | — |  |  | (410 | ) |
| Interest rate contracts in an asset position | — |  |  | 11 |  |  | — |  |  | — |  |  | 11 |  |
| Interest rate contracts in a liability position | — |  |  | — |  |  | — |  |  | (1 | ) |  | (1 | ) |
| Net asset (liability) | 67 |  |  | 14 |  |  | (142 | ) |  | (1 | ) |  | (62 | ) |
| Total derivatives at fair value | $ | 69 |  |  | $ | 14 |  |  | $ | (183 | ) |  | $ | (1 | ) |  | $ | (101 | ) |

[0001571996-19-000008:notes:232]
The following tables present the gross amounts of the Company’s derivative instruments, amounts offset due to master netting agreements with the Company’s counterparties, and the net amounts recognized in the Consolidated Statements of Financial Position:

[0001571996-19-000008:notes:233]
|  | February 1, 2019 |
|  | Gross Amounts of Recognized Assets/ (Liabilities) |  | Gross Amounts Offset in the Statement of Financial Position |  | Net Amounts of Assets/ (Liabilities) Presented in the Statement of Financial Position |  | Gross Amounts not Offset in the Statement of Financial Position |  | Net Amount |
|  | Financial Instruments |  | Cash Collateral Received or Pledged |  |
|  | (in millions) |
| Derivative instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Financial assets | $ | 312 |  |  | $ | (215 | ) |  | $ | 97 |  |  | $ | — |  |  | $ | — |  |  | $ | 97 |  |
| Financial liabilities | (275 | ) |  | 215 |  |  | (60 | ) |  | — |  |  | 4 |  |  | (56 | ) |
| Total derivative instruments | $ | 37 |  |  | $ | — |  |  | $ | 37 |  |  | $ | — |  |  | $ | 4 |  |  | $ | 41 |  |
|  | February 2, 2018 |
|  | Gross Amounts of Recognized Assets/ (Liabilities) |  | Gross Amounts Offset in the Statement of Financial Position |  | Net Amounts of Assets/ (Liabilities) Presented in the Statement of Financial Position |  | Gross Amounts not Offset in the Statement of Financial Position |  | Net Amount |
|  | Financial Instruments |  | Cash Collateral Received or Pledged |  |
|  | (in millions) |
| Derivative instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Financial assets | $ | 369 |  |  | $ | (286 | ) |  | $ | 83 |  |  | $ | — |  |  | $ | — |  |  | $ | 83 |  |
| Financial liabilities | (470 | ) |  | 286 |  |  | (184 | ) |  | — |  |  | — |  |  | (184 | ) |
| Total derivative instruments | $ | (101 | ) |  | $ | — |  |  | $ | (101 | ) |  | $ | — |  |  | $ | — |  |  | $ | (101 | ) |


## dell:BusinessCombinationGoodwillAndIntangibleAssetsTextBlock

[0001571996-19-000008:notes:234]
NOTE 8 — BUSINESS COMBINATIONS, GOODWILL AND INTANGIBLE ASSETS

[0001571996-19-000008:notes:235]
Business Combinations

[0001571996-19-000008:notes:236]
Fiscal year ended February 1, 2019

[0001571996-19-000008:notes:237]
VMware, Inc. Acquisitions

[0001571996-19-000008:notes:238]
CloudHealth Technologies, Inc. — During the third quarter of the fiscal year ended February 1, 2019, VMware, Inc. completed the acquisition of CloudHealth Technologies, Inc. (“CloudHealth Technologies”), a company delivering a cloud operations platform that enables customers to analyze and manage cloud cost, usage, security, and performance centrally for native public clouds.  The total purchase price was $495 million, net of cash acquired of $26 million and primarily included $101 million of identifiable intangible assets and $394 million of goodwill that is not expected to be deductible for tax purposes.  The identifiable intangible assets included completed technology of $69 million and customer relationships of $18 million, with estimated useful lives of one to five years.  The fair value of assumed unvested equity awards attributed to post-combination services was $39 million and will be expensed over the remaining requisite service periods on a straight-line basis.

[0001571996-19-000008:notes:239]
The preliminary allocation of the purchase price was based on a preliminary valuation and assumptions and is subject to change within the measurement period.  VMware, Inc. expects to finalize the allocation of the purchase price as soon as practicable and not later than one year from the acquisition date.

[0001571996-19-000008:notes:240]
Heptio Inc.  —  During the fourth quarter of the fiscal year ended February 1, 2019, VMware, Inc. completed the acquisition of Heptio Inc. (“Heptio”), a provider of products and services that help enterprises deploy and operationalize Kubernetes software.  The total purchase price was $420 million, net of cash acquired of $15 million.  The purchase price primarily included $27 million of identifiable intangible assets and $392 million of goodwill that is not expected to be deductible for tax purposes.  The identifiable intangible assets primarily consisted of completed technology of $20 million, with an estimated useful life of five years.  Merger consideration totaling $117 million, including $24 million that was held in escrow, is payable to certain employees of Heptio subject to specified future employment conditions and is being recognized as expense over the requisite service periods on a straight-line basis.  Compensation expense recognized during the year ended February 1, 2019 was not significant.  The fair value of assumed unvested equity awards attributed to post-combination services was $47 million and will be expensed over the remaining requisite service periods on a straight-line basis.

[0001571996-19-000008:notes:241]
The initial allocation of the purchase price was based on a preliminary valuation and assumptions and is subject to change within the measurement period.  VMware expects to finalize the allocation of the purchase price as soon as practicable and no later than one year from the acquisition date.

[0001571996-19-000008:notes:242]
The Company has not presented pro forma results of operations for the foregoing acquisitions because they are not material to the Company’s consolidated results of operations, financial position, or cash flows.

[0001571996-19-000008:notes:243]
Fiscal year ended February 2, 2018

[0001571996-19-000008:notes:244]
VeloCloud Networks, Inc. — During the fourth quarter of the fiscal year ended February 2, 2018, VMware, Inc. completed the acquisition of VeloCloud Networks, Inc. (“VeloCloud”), a provider of cloud-delivered software-defined wide-area network (SD-WAN) technology for enterprises and service providers.  VMware, Inc. acquired VeloCloud to build on its network virtualization platform, VMware NSX, and to expand its networking portfolio.  The total purchase price was $449 million, net of cash acquired of $24 million.  The purchase price primarily included $142 million of identifiable intangible assets and $326 million of goodwill that is not expected to be deductible for tax purposes.  The identifiable intangible assets primarily include completed technology of $87 million and customer contracts of $44 million, with estimated useful lives of six to seven years.  The fair value of assumed unvested equity attributed to post-combination services was $30 million and will be expensed over the remaining requisite service periods on a straight-line basis.

[0001571996-19-000008:notes:245]
Prior to the closing of the acquisition, Dell Technologies, including VMware Inc., held an ownership interest in VeloCloud.  Upon completion of the step acquisition, Dell Technologies recognized a gain of $8 million in interest and other, net for the remeasurement of its previously held ownership interest to fair value, which was $12 million.

[0001571996-19-000008:notes:246]
Other Business Combinations — During the second quarter of the fiscal year ended February 2, 2018, VMware, Inc. completed the acquisitions of Wavefront and Apteligent, Inc., which were not material to the Consolidated Financial Statements.  These acquisitions are a part of VMware, Inc.’s strategy to accelerate the development of VMware, Inc.’s Cloud services and other technologies.  The aggregate purchase price for the two acquisitions was $323 million, inclusive of the fair value of the Company’s existing investment in Wavefront of $69 million and cash acquired of $35 million.  The aggregate purchase price included $36 million of identifiable intangible assets and $238 million of goodwill that is not expected to be deductible for tax purposes.  The identifiable intangible assets primarily relate to purchased technology, with estimated useful lives of five years.  The fair value of assumed unvested equity attributable to post-combination services was $37 million and will be expensed over the remaining requisite service periods on a straight-line basis.  The estimated fair value of the stock options assumed by the Company was determined using the Black-Scholes option pricing model.

[0001571996-19-000008:notes:247]
Prior to the closing of the acquisition, Dell Technologies, including VMware, Inc., held an ownership interest in Wavefront.  Upon completion of the step acquisition, Dell Technologies recognized a $45 million gain in interest and other, net for the remeasurement of its previously held ownership interest to fair value.

[0001571996-19-000008:notes:248]
Fiscal year ended February 3, 2017

[0001571996-19-000008:notes:249]
EMC Merger Transaction

[0001571996-19-000008:notes:250]
On September 7, 2016, EMC became a wholly-owned subsidiary of the Company as a result of the merger of a merger subsidiary of Dell Technologies with and into EMC.  Pursuant to the terms of the merger agreement, upon the completion of the EMC merger transaction, each issued and outstanding share of common stock, par value $0.01 per share, of EMC (approximately 2.0 billion shares as of September 7, 2016) was converted into the right to receive (1) $24.05 in cash, without interest, and (2) 0.11146 validly issued, fully paid, and non-assessable shares of common stock of the Company designated as Class V Common Stock, par value $0.01 per share (the “Class V Common Stock”), plus cash in lieu of any fractional shares.  Shares of the Class V Common Stock were approved for listing on the New York Stock Exchange (the “NYSE”) under the ticker symbol “DVMT” and began trading on September 7, 2016.

[0001571996-19-000008:notes:251]
In connection with the EMC merger transaction, the Company authorized 343 million shares of Class V Common Stock.  On September 7, 2016, Dell Technologies issued 223 million shares of Class V Common Stock to EMC shareholders at a purchase price of $45.07 per share for an aggregate purchase price of approximately $10 billion.  The total fair value of consideration transferred to effect the EMC merger transaction was approximately $64 billion, which primarily consisted of cash and such shares of Class V Common Stock, as well as the fair value of non-controlling interests in VMware, Inc. and Pivotal, majority-owned consolidated subsidiaries of EMC.  See Note 14 of the Notes to the Consolidated Financial Statements for additional information on the Class V Common Stock.

[0001571996-19-000008:notes:252]
Fair Value of Consideration Transferred — The following table summarizes the consideration transferred to effect the EMC merger transaction:

[0001571996-19-000008:notes:253]
|  | Purchase Price |
|  | (in millions) |
| Consideration transferred: |  |
| Cash | $ | 47,694 |  |
| Expense and other (a) | 968 |  |
| Class V Common Stock (b) | 10,041 |  |
| Total consideration transferred | 58,703 |  |
| Non-controlling interests (c) | 6,048 |  |
| Less: Post-merger stock compensation expense (d) | (800 | ) |
| Total purchase price to allocate | $ | 63,951 |  |

[0001571996-19-000008:notes:254]
| (a) | Expense and other primarily consists of cash payment for post-merger stock compensation expense, as described in footnote (d), and the value related to pre-merger services of EMC equity awards converted to deferred cash awards. |

[0001571996-19-000008:notes:255]
| (b) | The fair value of the Class V Common Stock is based on the issuance of approximately 223 million shares with a per-share fair value of $45.07 (the opening share price of the Class V Common Stock on the NYSE on September 7, 2016, the first day of trading), which shares were intended to track the economic performance of approximately 65% of the Company’s economic interest in the VMware business, as of the closing date of the EMC merger transaction. |

[0001571996-19-000008:notes:256]
| (c) | Non-controlling interests in VMware, Inc. and Pivotal was $6 billion as of September 7, 2016. The fair value of the non-controlling interest related to VMware, Inc. was calculated by multiplying outstanding shares of VMware, Inc. common stock that were not owned by EMC by $73.28 (the opening share price of VMware, Inc. Class A common stock on the NYSE on September 7, 2016). The fair value of the non-controlling interest relating to Pivotal was calculated based on the fair value of Pivotal, the ownership percentage of the non-controlling interests, and a discount for lack of control related to the non-controlling interest. |

[0001571996-19-000008:notes:257]
| (d) | Pursuant to the guidelines of ASC 805, a portion of the consideration related to accelerated EMC equity awards was recorded as post-merger day one stock compensation expense. This expense is attributable to post-merger services not rendered due to the acceleration. |

[0001571996-19-000008:notes:258]
Assets Acquired and Liabilities Assumed — The EMC merger transaction has been accounted for as a business combination under the acquisition method of accounting.  The cumulative impact of any subsequent changes resulting from the facts and circumstances that existed as of the transaction date will be adjusted in the reporting period in which the adjustment amount is determined.

[0001571996-19-000008:notes:259]
The following table summarizes, as of February 2, 2018, the purchase price allocation to the assets acquired and the liabilities assumed in the EMC merger transaction (in millions):

[0001571996-19-000008:notes:260]
| Current assets: |  |
| Cash and cash equivalents | $ | 10,080 |  |
| Short-term investments | 1,765 |  |
| Accounts receivable | 2,810 |  |
| Short-term financing receivables | 64 |  |
| Inventories, net | 1,993 |  |
| Other current assets | 903 |  |
| Total current assets | 17,615 |  |
| Property, plant, and equipment | 4,490 |  |
| Long-term investments | 4,317 |  |
| Long-term financing receivables | 65 |  |
| Goodwill | 31,539 |  |
| Purchased intangibles | 31,218 |  |
| Other non-current assets | 445 |  |
| Total assets | $ | 89,689 |  |
| Current liabilities: |  |
| Short-term debt | $ | 905 |  |
| Accounts payable | 728 |  |
| Accrued and other | 3,259 |  |
| Short-term deferred revenue | 4,954 |  |
| Total current liabilities | 9,846 |  |
| Long-term debt | 5,474 |  |
| Long-term deferred revenue | 3,469 |  |
| Deferred tax liabilities | 6,625 |  |
| Other non-current liabilities | 324 |  |
| Total liabilities | 25,738 |  |
| Total net assets | $ | 63,951 |  |

[0001571996-19-000008:notes:261]
The table above includes amounts allocated to ECD, which was divested in the fiscal year ended February 3, 2017.  See Note 1 of the Notes to the Consolidated Financial Statements for more information on discontinued operations.

[0001571996-19-000008:notes:262]
Pro Forma Financial Information — The following table provides unaudited pro forma results of operations for the fiscal year ended February 3, 2017 as if the EMC merger transaction date had occurred on January 31, 2015:

[0001571996-19-000008:notes:263]
|  | Fiscal Year Ended |
|  | February 3, 2017 |
|  | (in millions) |
| Total net revenue | $ | 74,116 |  |
| Net loss attributable to Dell Technologies Inc. | $ | (3,220 | ) |

[0001571996-19-000008:notes:264]
The pro forma information for the fiscal year ended February 3, 2017 combines the Company’s historical results for the fiscal year ended February 3, 2017 and EMC’s historical results for the period from February 1, 2016 to September 6, 2016.  The historical results have been adjusted in the pro forma information to give effect to items that are (a) directly attributable to the EMC merger transaction, (b) factually supportable, and (c) expected to have a continuing impact on the combined company’s results.  Additionally, the unaudited pro forma financial information includes EMC results that have been adjusted for ASC 606.

[0001571996-19-000008:notes:265]
The pro forma information does not purport to represent what the combined company’s results of operations or financial condition would have been had the EMC merger transaction actually occurred on the date indicated, and does not purport to project the combined company’s results of operations for any future period or as of any future date.

[0001571996-19-000008:notes:266]
Goodwill

[0001571996-19-000008:notes:267]
The following table presents goodwill allocated to the Company’s business segments as of February 1, 2019 and February 2, 2018, and changes in the carrying amount of goodwill for the respective periods:

[0001571996-19-000008:notes:268]
|  | Infrastructure Solutions Group (a) |  | Client Solutions Group |  | VMware |  | Other Businesses (b) |  | Total |
|  | (in millions) |
| Balance as of February 3, 2017 | $ | 15,607 |  |  | $ | 4,237 |  |  | $ | 15,070 |  |  | $ | 3,996 |  |  | $ | 38,910 |  |
| Goodwill acquired | — |  |  | — |  |  | 565 |  |  | 9 |  |  | 574 |  |
| Impact of foreign currency translation | 359 |  |  | — |  |  | — |  |  | 90 |  |  | 449 |  |
| Goodwill divested | (13 | ) |  | — |  |  | — |  |  | — |  |  | (13 | ) |
| Balance as of February 2, 2018 | $ | 15,953 |  |  | $ | 4,237 |  |  | $ | 15,635 |  |  | $ | 4,095 |  |  | $ | 39,920 |  |
| Goodwill acquired (c) | — |  |  | — |  |  | 784 |  |  | — |  |  | 784 |  |
| Impact of foreign currency translation | (289 | ) |  | — |  |  | — |  |  | (67 | ) |  | (356 | ) |
| Goodwill divested | (69 | ) |  | — |  |  | — |  |  | — |  |  | (69 | ) |
| Other adjustments (d) | (396 | ) |  | — |  |  | — |  |  | 396 |  |  | — |  |
| Goodwill impaired (e) | — |  |  | — |  |  | — |  |  | (190 | ) |  | (190 | ) |
| Balance as of February 1, 2019 | $ | 15,199 |  |  | $ | 4,237 |  |  | $ | 16,419 |  |  | $ | 4,234 |  |  | $ | 40,089 |  |

[0001571996-19-000008:notes:269]
| (a) | Infrastructure Solutions Group is composed of the Core Storage, Servers, and Networking goodwill reporting unit. |

[0001571996-19-000008:notes:270]
| (b) | Other Businesses consists of offerings by Pivotal, Secureworks, RSA Security LLC (“RSA Security”), Virtustream Group Holdings, Inc. (“Virtustream”), and Boomi, Inc. (“Boomi”). |

[0001571996-19-000008:notes:271]
| (c) | During the fiscal year ended February 1, 2019, VMware, Inc. completed the acquisitions of CloudHealth Technologies and Heptio. |

[0001571996-19-000008:notes:272]
| (d) | During the three months ended May 4, 2018, the Company made certain segment reporting changes, which included the movement of the results of Virtustream from the Infrastructure Solutions Group segment to Other businesses. The amount of goodwill attributable to Virtustream was reclassified to Other businesses to align with these reporting changes. |

[0001571996-19-000008:notes:273]
| (e) | The Company recognized a goodwill impairment charge related to Virtustream, as discussed below. |

[0001571996-19-000008:notes:274]
Annual Goodwill Impairment Test — In connection with its annual impairment cycle, the Company elected to early adopt the amended guidance issued by the FASB that simplified the goodwill impairment test, as discussed in Note 2 of the Notes to the Consolidated Financial Statements.

[0001571996-19-000008:notes:275]
Goodwill and indefinite-lived intangible assets are tested for impairment annually during the third fiscal quarter and whenever events or circumstances may indicate that an impairment has occurred.  The Company elected to bypass the assessment of qualitative factors to determine whether it was more likely than not that the fair value of a reporting unit was less than its carrying amount, including goodwill.  In electing to bypass the qualitative assessment, the Company proceeded directly to performing a quantitative goodwill impairment test to measure the fair value of each goodwill reporting unit relative to its carrying amount, and to determine the amount of goodwill impairment loss to be recognized, if any.

[0001571996-19-000008:notes:276]
Management exercised significant judgment related to the above assessment, including the identification of goodwill reporting units, assignment of assets and liabilities to goodwill reporting units, assignment of goodwill to reporting units, and determination of the fair value of each goodwill reporting unit.  The fair value of each goodwill reporting unit is generally estimated using a combination of public company multiples and discounted cash flow methodologies, unless the reporting unit relates to a publicly traded entity (VMware, Inc., Pivotal, or Secureworks), in which case the fair value is determined based primarily on the public company market valuation.  The discounted cash flow and public company multiples methodologies require significant judgment, including estimation of future cash flows, which is dependent on internal forecasts, current and anticipated economic conditions and trends, selection of market multiples through assessment of the reporting unit’s performance relative to peer competitors, the estimation of the long-term growth rate of the Company’s business, and the determination of the Company’s weighted average cost of capital.  Changes in these estimates and assumptions could materially affect the fair value of the goodwill reporting unit, potentially resulting in a non-cash impairment charge.

[0001571996-19-000008:notes:277]
Based on the results of the annual impairment test, which was a quantitative test for all goodwill reporting units, the fair values of each of the reporting units, except for the Virtustream reporting unit, exceeded their carrying values.  Virtustream’s results, which are reported within the Company’s Other businesses, do not meet the requirements for a reportable segment and are not material to the Company’s overall results.  See Note 19 of the Notes to the Consolidated Financial Statements for additional segment information.

[0001571996-19-000008:notes:278]
Virtustream delivers an application management cloud platform for enterprise mission-critical workloads in the Infrastructure-as-a-Service market, and had approximately $0.4 billion in goodwill that was derived from the EMC merger transaction during the fiscal year ended February 3, 2017.  Virtustream forecasts were revised downward due to a resetting of the longer term business model that is focused on a streamlined product portfolio.

[0001571996-19-000008:notes:279]
It was determined that the carrying value of the Virtustream reporting unit exceeded its fair value, and, as such, a goodwill impairment charge of approximately $190 million was recognized during the three months ended November 2, 2018.  This expense was classified in selling, general, and administrative in the Consolidated Statements of Income (Loss).  The impairment is reflected as a reduction in goodwill of approximately $190 million in the Consolidated Statements of Financial Position as of February 1, 2019.  The Company did not have any accumulated goodwill impairment charges from prior period goodwill impairment tests.  The remaining Virtustream goodwill was approximately $205 million, inclusive of the impact of foreign currency translation, as of February 1, 2019.  Management will continue to monitor the Virtustream goodwill reporting unit and consider potential impacts to the impairment assessment.

[0001571996-19-000008:notes:280]
As a result of the annual impairment test, it was determined that the excess of fair value over carrying amount was less than 20% for the RSA Security reporting unit, which had an excess of fair value over carrying amount of 11% as of November 2, 2018.  Management will continue to monitor the RSA Security goodwill reporting unit and consider potential impacts to the impairment assessment.

[0001571996-19-000008:notes:281]
Additionally, as a result of the Class V transaction, the Company performed an interim impairment analysis during the three months ended February 1, 2019 given the availability of market data.  Other than those disclosed during the Company’s annual goodwill impairment test during the three months ended November 2, 2018, there were no impairment indicators resulting from the interim impairment analysis.

[0001571996-19-000008:notes:282]
Intangible Assets

[0001571996-19-000008:notes:283]
The Company’s intangible assets as of February 1, 2019 and February 2, 2018 were as follows:

[0001571996-19-000008:notes:284]
|  | February 1, 2019 |  | February 2, 2018 |
|  | Gross |  | AccumulatedAmortization |  | Net |  | Gross |  | AccumulatedAmortization |  | Net |
|  | (in millions) |
| Customer relationships | $ | 22,750 |  |  | $ | (11,703 | ) |  | $ | 11,047 |  |  | $ | 22,764 |  |  | $ | (8,637 | ) |  | $ | 14,127 |  |
| Developed technology | 15,701 |  |  | (9,036 | ) |  | 6,665 |  |  | 15,586 |  |  | (6,196 | ) |  | 9,390 |  |
| Trade names | 1,291 |  |  | (606 | ) |  | 685 |  |  | 1,277 |  |  | (407 | ) |  | 870 |  |
| Leasehold assets (liabilities) | 128 |  |  | (10 | ) |  | 118 |  |  | 128 |  |  | (6 | ) |  | 122 |  |
| Definite-lived intangible assets | 39,870 |  |  | (21,355 | ) |  | 18,515 |  |  | 39,755 |  |  | (15,246 | ) |  | 24,509 |  |
| Indefinite-lived trade names | 3,755 |  |  | — |  |  | 3,755 |  |  | 3,756 |  |  | — |  |  | 3,756 |  |
| Total intangible assets | $ | 43,625 |  |  | $ | (21,355 | ) |  | $ | 22,270 |  |  | $ | 43,511 |  |  | $ | (15,246 | ) |  | $ | 28,265 |  |

[0001571996-19-000008:notes:285]
Amortization expense related to definite-lived intangible assets was approximately $6.1 billion, $7.0 billion, and $3.7 billion for the fiscal years ended February 1, 2019, February 2, 2018, and February 3, 2017, respectively.  There were no material impairment charges related to intangible assets during the fiscal years ended February 1, 2019, February 2, 2018, and February 3, 2017

[0001571996-19-000008:notes:286]
Due to Virtustream business changes, the Virtustream definite-lived intangible assets were tested for impairment using a quantitative analysis, and no impairment was identified.

[0001571996-19-000008:notes:287]
Estimated future annual pre-tax amortization expense of definite-lived intangible assets as of February 1, 2019 over the next five fiscal years and thereafter is as follows:

[0001571996-19-000008:notes:288]
| Fiscal Years | (in millions) |
| 2020 | $ | 4,391 |  |
| 2021 | 3,362 |  |
| 2022 | 2,652 |  |
| 2023 | 1,767 |  |
| 2024 | 1,403 |  |
| Thereafter | 4,940 |  |
| Total | $ | 18,515 |  |


## us-gaap:DeferredRevenueDisclosureTextBlock

[0001571996-19-000008:notes:289]
NOTE 9 — DEFERRED REVENUE

[0001571996-19-000008:notes:290]
Deferred Revenue — Deferred revenue is recorded for support and deployment services, software maintenance, professional services, training, and SaaS when the Company has a right to invoice or payments have been received for undelivered products or services where transfer of control has not occurred.  Revenue is recognized on these items when the revenue recognition criteria are met, generally resulting in ratable recognition over the contract term.  The Company also has deferred revenue related to undelivered hardware and professional services, consisting of installations and consulting engagements, which are recognized as the Company’s performance obligations under the contract are completed.

[0001571996-19-000008:notes:291]
Changes in the Company’s deferred revenue are presented in the following table for the periods indicated:

[0001571996-19-000008:notes:292]
|  | Fiscal Year Ended |
|  | February 1, 2019 |  | February 2, 2018 |
|  | (in millions) |
| Deferred revenue: |  |  |  |
| Deferred revenue at beginning of period | $ | 20,816 |  |  | $ | 17,815 |  |
| Revenue deferrals for new contracts and changes in estimates for pre-existing contracts (a) (b) | 20,580 |  |  | 18,478 |  |
| Revenue recognized (b) | (17,386 | ) |  | (15,477 | ) |
| Deferred revenue at end of period | $ | 24,010 |  |  | 20,816 |  |
| Short-term deferred revenue | $ | 12,944 |  |  | $ | 11,606 |  |
| Long-term deferred revenue | $ | 11,066 |  |  | $ | 9,210 |  |

[0001571996-19-000008:notes:293]
| (a) | Includes the impact of foreign currency exchange rate fluctuations. |

[0001571996-19-000008:notes:294]
| (b) | The Company conformed the presentation of certain deferred revenue rollforward activity for the fiscal year ended February 2, 2018 to align to current year presentation. The beginning and ending deferred revenue liability balances remain unchanged. |

[0001571996-19-000008:notes:295]
Remaining Performance Obligations — Remaining performance obligations represent the aggregate amount of the transaction price allocated to performance obligations not delivered, or partially undelivered, as of the end of the reporting period.

[0001571996-19-000008:notes:296]
Remaining performance obligations include deferred revenue plus unbilled amounts not yet recorded in deferred revenue.  The aggregate amount of the transaction price allocated to remaining performance obligations does not include amounts owed under cancelable contracts where there is no substantive termination penalty.

[0001571996-19-000008:notes:297]
The Company applied the practical expedient to exclude the value of remaining performance obligations for contracts for which revenue is recognized at the amount to which the Company has the right to invoice for services performed.  The Company also applied the practical expedient to not disclose the amount of transaction price allocated to remaining performance obligations for the periods prior to adoption of the new revenue standard.

[0001571996-19-000008:notes:298]
Remaining performance obligation estimates are subject to change and are affected by several factors, including terminations, changes in the scope of contracts, periodic revalidation, adjustments for revenue that have not materialized, and adjustments for currency.

[0001571996-19-000008:notes:299]
The value of the transaction price allocated to remaining performance obligations as of February 1, 2019 was approximately $32 billion.  The Company expects to recognize approximately 61% of remaining performance obligations as revenue in the next 12 months, and the remainder thereafter.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001571996-19-000008:notes:300]
NOTE 10 — COMMITMENTS AND CONTINGENCIES

[0001571996-19-000008:notes:301]
Lease Commitments

[0001571996-19-000008:notes:302]
The Company leases property and equipment, manufacturing facilities, and office space under non-cancelable leases.  Certain of these leases obligate the Company to pay taxes, maintenance, and repair costs.  As of February 1, 2019, future minimum lease payments under these non-cancelable leases were as follows: $371 million in Fiscal 2020; $314 million in Fiscal 2021; $240 million in Fiscal 2022; $175 million in Fiscal 2023; $113 million in Fiscal 2024; and $643 million thereafter.

[0001571996-19-000008:notes:303]
The amount of the future lease commitments after Fiscal 2024 is primarily for the ground leases on VMware, Inc.’s Palo Alto, California headquarter facilities, which expire in Fiscal 2047.

[0001571996-19-000008:notes:304]
For the fiscal years ended February 1, 2019, February 2, 2018, and February 3, 2017, rent expense under all leases totaled $457 million, $571 million, and $279 million, respectively.

[0001571996-19-000008:notes:305]
Purchase Obligations

[0001571996-19-000008:notes:306]
The Company has contractual obligations to purchase goods or services, which specify significant terms, including fixed or minimum quantities to be purchased; fixed, minimum, or variable price provisions; and the approximate timing of the transaction.  As of February 1, 2019, purchase obligations were $3,953 million, $354 million, and $298 million for Fiscal 2020, Fiscal 2021, and Fiscal 2022 and thereafter, respectively.

[0001571996-19-000008:notes:307]
Legal Matters

[0001571996-19-000008:notes:308]
The Company is involved in various claims, suits, assessments, investigations, and legal proceedings that arise from time to time in the ordinary course of its business, including those identified below, consisting of matters involving consumer, antitrust, tax, intellectual property, and other issues on a global basis.

[0001571996-19-000008:notes:309]
The Company accrues a liability when it believes that it is both probable that a liability has been incurred and that it can reasonably estimate the amount of the loss.  The Company reviews these accruals at least quarterly and adjusts them to reflect ongoing negotiations, settlements, rulings, advice of legal counsel, and other relevant information.  To the extent new information is obtained and the Company’s views on the probable outcomes of claims, suits, assessments, investigations, or legal proceedings change, changes in the Company’s accrued liabilities would be recorded in the period in which such a determination is made.  For some matters, the amount of liability is not probable or the amount cannot be reasonably estimated and therefore accruals have not been made.

[0001571996-19-000008:notes:310]
The following is a discussion of the Company’s significant legal matters and other proceedings:

[0001571996-19-000008:notes:311]
Appraisal Proceedings — On October 29, 2013, Dell Technologies acquired Dell in a transaction referred to as the going-private transaction.  Holders of shares of Dell common stock who did not vote on September 12, 2013 in favor of the proposal to adopt the amended going-private transaction agreement and who properly demanded appraisal of their shares and who otherwise comply with the requirements of Section 262 of the Delaware General Corporate Law (“DGCL”) are entitled to seek appraisal for, and obtain payment in cash for the judicially determined “fair value” (as defined pursuant to Section 262 of the DGCL) of, their shares in lieu of receiving the going-private transaction consideration.  The liability for the appraisal proceedings was approximately $129 million as of February 2, 2018.  On May 8, 2018, the Company entered into an agreement to settle a portion of the liability related to the appraisal proceedings in the amount of approximately $70 million, and on May 18, 2018, this portion of the liability was fully paid.  The Company settled with the remaining plaintiffs as of July 16, 2018 in the amount of approximately $30 million.  The remaining liability accrual was immaterial and released to Interest and other, net during the three months ended August 3, 2018.  As of August 3, 2018, there was no remaining liability for appraisal proceedings.

[0001571996-19-000008:notes:312]
Securities Litigation — On May 22, 2014, a securities class action seeking compensatory damages was filed in the United States District Court for the Southern District of New York, captioned the City of Pontiac Employee Retirement System vs. Dell Inc. et. al. (Case No. 1:14-cv-03644).  The action names as defendants Dell Inc. and certain current and former executive officers, and alleges that Dell made false and misleading statements about Dell’s business operations and products between February 22, 2012 and May 22, 2012, which resulted in artificially inflated stock prices.  The case was transferred to the United States District Court for the Western District of Texas, where the defendants filed a motion to dismiss.  On September 16, 2016, the Court denied the motion to dismiss and the case is proceeding with discovery.

[0001571996-19-000008:notes:313]
Class Actions Related to the Class V Transaction — Four purported stockholders have brought putative class action complaints arising out of the Class V transaction described in Note 14 of the Notes to the Consolidated Financial Statements.  The actions are captioned Hallandale Beach Police and Fire Retirement Plan v. Michael Dell et al. (Civil Action No. 2018-0816-JTL), Howard Karp v. Michael Dell et al. (Civil Action No. 2019-0032-JTL), Miramar Police Officers’ Retirement Plan v. Michael Dell et al. (Civil Action No. 2019-0049-JTL), and Steamfitters Local 449 Pension Plan v. Michael Dell et al. (Civil Action No. 2019-0115-JTL).  The four actions, which are substantively similar and were all filed in the Court of Chancery of the State of Delaware, name as defendants the Company’s board of directors, and stockholders of the Company, consisting of Michael S. Dell and entities through which Mr. Dell allegedly holds a portion of his and/or his family’s stock.  The plaintiffs generally allege that the defendants breached their fiduciary duties to the former holders of Class V Common Stock in connection with the Class V transaction by allegedly causing the Company to enter into a transaction that favored the interests of the controlling stockholders at the expense of such former stockholders.  The actions have now been consolidated.

[0001571996-19-000008:notes:314]
Other Litigation Related to the Class V Transaction — On October 31, 2018, High River Limited Partnership, Icahn Partners Master Fund LP, and Icahn Partners LP filed an action against Dell in Delaware Chancery Court, captioned High River LP v. Dell Tech. Holdings Inc. (No. 2018-0790), pursuant to Section 220 of the DGCL, seeking (1) to inspect certain of the Company’s books and records purportedly related to the Class V transaction described in Note 14 of the Notes to the Consolidated Financial Statements or the potential initial public offering of the Company’s Class C Common Stock, and (2) the public dissemination of unspecified materials already produced for inspection.  By motion dated October 31, 2018, the plaintiffs sought expedited treatment of their claims.  On November 1, 2018, Dell filed its opposition to the motion for expedited treatment.  On November 5, 2018, the Chancery Court scheduled a trial on the matter for November 19, 2018.  Prior to the scheduled trial, on November 15, 2018, the plaintiffs voluntarily dismissed this action.

[0001571996-19-000008:notes:315]
On November 8, 2018, Hallandale Beach Police and Fire Retirement Plan filed a putative stockholder class action lawsuit, captioned Hallandale Beach Police and Fire Retirement Plan v. Michael Dell, et al., (No. 2018-0816-JTL), against the Company’s directors and Michael S. Dell, a separate property trust for the benefit of Mr. Dell’s wife, investment funds affiliated with Silver Lake Partners, and investment funds affiliated with MSD Partners, L.P. in Delaware Chancery Court, alleging, among other things, that the directors of the Company breached their fiduciary duties to holders of the Class V Common Stock in connection with the Class V transaction, because, among other things, the Class V transaction was allegedly financially unfair and coercive to holders of the Class V Common Stock and there were various conflicts of interest. The lawsuit seeks, among other remedies, a judicial declaration that that defendants breached their fiduciary duties and an award of damages, fees and costs.

[0001571996-19-000008:notes:316]
Copyright Levies — The Company is involved in various proceedings and negotiations regarding Dell’s obligation to collect and remit copyright levies in certain European Union (“EU”) countries.  The Company continues to collect levies in EU countries where it has determined that local laws require payment.  The Company, along with other companies and/or industry associations, also continues to oppose levy schemes that do not comply with EU law.  The Company does not currently anticipate that any of these matters will have a material adverse effect on its business, financial condition, results of operations, or cash flows.

[0001571996-19-000008:notes:317]
Other Litigation — The various legal proceedings in which Dell is involved include commercial litigation and a variety of patent suits.  In some of these cases, Dell is the sole defendant.  More often, particularly in the patent suits, Dell is one of a number of defendants in the electronics and technology industries.  Dell is actively defending a number of patent infringement suits, and several pending claims are in various stages of evaluation.  While the number of patent cases varies over time, Dell does not currently anticipate that any of these matters will have a material adverse effect on its business, financial condition, results of operations, or cash flows.

[0001571996-19-000008:notes:318]
As of February 1, 2019, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for these or other proceedings or matters has been incurred.  However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company’s business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters.  Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company’s business, financial condition, results of operations, or cash flows will depend on a number of variables, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.

[0001571996-19-000008:notes:319]
Indemnifications

[0001571996-19-000008:notes:320]
In the ordinary course of business, the Company enters into contractual arrangements under which it may agree to indemnify the third party to such arrangements from any losses incurred relating to the services it performs on behalf of the Company or for losses arising from certain events as defined in the particular contract, such as litigation or claims relating to past performance.  Such indemnification obligations may not be subject to maximum loss clauses.  Historically, payments related to these indemnifications have not been material to the Company.

[0001571996-19-000008:notes:321]
Certain Concentrations

[0001571996-19-000008:notes:322]
The Company maintains cash and cash equivalents, derivatives, and certain other financial instruments with various financial institutions that potentially subject it to concentration of credit risk.  As part of its risk management processes, the Company performs periodic evaluations of the relative credit standing of these financial institutions.  The Company has not sustained material credit losses from instruments held at these financial institutions.  Further, the Company does not anticipate nonperformance by any of the counterparties.

[0001571996-19-000008:notes:323]
The Company markets and sells its products and services to large corporate clients, governments, and health care and education accounts, as well as to small and medium-sized businesses and individuals.  No single customer accounted for more than 10% of the Company’s consolidated net revenue during the fiscal year ended February 1, 2019, February 2, 2018, or February 3, 2017.

[0001571996-19-000008:notes:324]
The Company utilizes a limited number of contract manufacturers that assemble a portion of its products.  The Company may purchase components from suppliers and sell those components to the contract manufacturers, thereby creating receivables balances from the contract manufacturers.  The agreements with the majority of the contract manufacturers allow the Company a legal right to offset its payables against these receivables, thus mitigating the credit risk wholly or in part.  Receivables from the Company’s four largest contract manufacturers represented the majority of the gross non-trade receivables of $3.7 billion and $3.3 billion as of February 1, 2019 and February 2, 2018, respectively, of which $3.2 billion and $2.8 billion as of February 1, 2019 and February 2, 2018, respectively, have been offset against the corresponding payables.  The portion of receivables not offset against payables is included in other current assets in the Consolidated Statement of Financial Position.  The Company does not reflect the sale of the components in revenue and does not recognize any profit on the component sales until the related products are sold.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001571996-19-000008:notes:325]
NOTE 11 — INCOME AND OTHER TAXES

[0001571996-19-000008:notes:326]
The income tax benefit from continuing operations consisted of the following for the respective periods:

[0001571996-19-000008:notes:327]
|  | Fiscal Year Ended |
|  | February 1, 2019 |  | February 2, 2018 |  | February 3, 2017 |
|  | (in millions) |
| Current: |  |  |  |  |  |
| Federal | $ | 461 |  |  | $ | 52 |  |  | $ | (139 | ) |
| State/local | 74 |  |  | 111 |  |  | 46 |  |
| Foreign | 616 |  |  | 599 |  |  | 322 |  |
| Current | 1,151 |  |  | 762 |  |  | 229 |  |
| Deferred: |  |  |  |  |  |
| Federal | (1,150 | ) |  | (2,368 | ) |  | (1,510 | ) |
| State/local | (85 | ) |  | (139 | ) |  | (105 | ) |
| Foreign | (96 | ) |  | (98 | ) |  | (34 | ) |
| Deferred | (1,331 | ) |  | (2,605 | ) |  | (1,649 | ) |
| Income tax benefit | $ | (180 | ) |  | $ | (1,843 | ) |  | $ | (1,420 | ) |

[0001571996-19-000008:notes:328]
The Company’s provision for income taxes for the fiscal periods reflected in the Consolidated Financial Statements are not directly comparable primarily due to the enactment of the Tax Cuts and Jobs Act of 2017 (“U.S. Tax Reform”) during the fiscal year ended February 2, 2018, as well as purchase accounting adjustments, interest charges, and stock-based compensation charges incurred as a result of the EMC merger transaction that was completed in the fiscal year ended February 3, 2017.  For more information regarding the EMC merger transaction, see Note 1 of the Notes to the Consolidated Financial Statements.

[0001571996-19-000008:notes:329]
U.S. Tax Reform was signed into law on December 22, 2017.  Among other things, U.S. Tax Reform lowers the U.S. corporate income tax rate to 21% from 35%, establishes a modified territorial system requiring a mandatory deemed repatriation tax on undistributed earnings of foreign subsidiaries (the “Transition Tax”), requires a minimum tax on certain future earnings generated by foreign subsidiaries while providing for future tax-free repatriation of earnings through a 100% dividends-received deduction, and places limitations on the deductibility of net interest expense.

[0001571996-19-000008:notes:330]
GAAP requires the effect of a change in tax laws to be recognized in the period that includes the enactment date.  Due to the complexities involved in accounting for the enactment of U.S. Tax Reform, the SEC staff issued Staff Accounting Bulletin No. 118 (“SAB 118”), which allowed companies to record provisional amounts in earnings for the first year following U.S. Tax Reform’s enactment, with those provisional amounts required to be finalized by the end of that year.  For the fiscal year ended February 2, 2018, the Company recognized a provisional tax benefit of $0.5 billion, which was primarily attributable to a $1.5 billion tax benefit related to the remeasurement of deferred tax assets and liabilities, offset by $1.0 billion of current and future income tax expenses related to the Transition Tax.  The Company completed its accounting for the income tax effects of U.S. Tax Reform during the fourth quarter of the fiscal year ended February 1, 2019 and determined that the adjustment to the provisional estimate was not material.  Throughout the fiscal year ended February 1, 2019, the U.S. Department of the Treasury and the Internal Revenue Service (“IRS”) issued preliminary regulatory guidance clarifying certain provisions of U.S. Tax Reform, and the Company anticipates that additional regulatory guidance and technical clarifications will be issued.  When additional guidance is issued, the Company will recognize the related tax impact in the fiscal quarter of such issuance.

[0001571996-19-000008:notes:331]
The Company’s loss from continuing operations before income taxes consisted of the following for the respective periods:

[0001571996-19-000008:notes:332]
|  | Fiscal Year Ended |
|  | February 1, 2019 |  | February 2, 2018 |  | February 3, 2017 |
|  | (in millions) |
| Domestic | $ | (4,645 | ) |  | $ | (5,995 | ) |  | $ | (6,698 | ) |
| Foreign | 2,284 |  |  | 1,226 |  |  | 2,204 |  |
| Loss from continuing operations before income taxes | $ | (2,361 | ) |  | $ | (4,769 | ) |  | $ | (4,494 | ) |

[0001571996-19-000008:notes:333]
A reconciliation of the Company’s income tax benefit from continuing operations to the statutory U.S. federal tax rate is as follows:

[0001571996-19-000008:notes:334]
|  | Fiscal Year Ended |
|  | February 1, 2019 |  | February 2, 2018 (a) |  | February 3, 2017 (a) |
| U.S. federal statutory rate | 21.0 | % |  | 33.7 | % |  | 35.0 | % |
| State income taxes, net of federal tax benefit | 0.5 |  |  | 2.9 |  |  | 2.9 |  |
| Tax impact of foreign operations | (19.5 | ) |  | (11.0 | ) |  | (6.2 | ) |
| Change in valuation allowance | (6.6 | ) |  | (1.8 | ) |  | (1.1 | ) |
| Indirect tax effects of adoption of new revenue standard | 6.5 |  |  | — |  |  | — |  |
| U.S. Tax Reform | 1.5 |  |  | 11.6 |  |  | — |  |
| IRS tax audit settlement | — |  |  | — |  |  | 6.6 |  |
| Non-deductible transaction-related costs | (1.9 | ) |  | — |  |  | (1.1 | ) |
| Stock-based compensation | 4.1 |  |  | 1.6 |  |  | (0.2 | ) |
| Other tax credits | 6.9 |  |  | 2.6 |  |  | 1.1 |  |
| Other | (4.9 | ) |  | (1.0 | ) |  | (5.4 | ) |
| Total | 7.6 | % |  | 38.6 | % |  | 31.6 | % |

[0001571996-19-000008:notes:335]
| (a) | Prior periods have been conformed to current year presentation. |

[0001571996-19-000008:notes:336]
The differences between the estimated effective income tax rates and the U.S. federal statutory rate of 21% principally result from the Company’s geographical distribution of income and differences between the book and tax treatment of certain items.  In certain jurisdictions, the Company’s tax rate is significantly less than the applicable statutory rate as a result of tax holidays.  The majority of the Company’s foreign income that is subject to these tax holidays and lower tax rates is attributable to Singapore, China, and Malaysia.  Although a significant portion of these income tax benefits relate to a tax holiday that expired during the fiscal year ended February 1, 2019, the Company has negotiated new terms for the affected subsidiary.  These new terms provide for a reduced income tax rate and will be effective until January 31, 2029.  The Company’s other tax holidays will expire in whole or in part during fiscal years 2022 through 2030.  Many of these tax holidays and reduced tax rates may be extended when certain conditions are met or may be terminated early if certain conditions are not met.  For the fiscal years ended February 1, 2019, February 2, 2018, and February 3, 2017, the income tax benefits attributable to the tax status of the affected subsidiaries were estimated to be approximately $313 million ($0.54 per share of DHI Group Common Stock), $238 million ($0.42 per share of DHI Group Common Stock), and $369 million ($0.79 per share of DHI Group Common Stock), respectively.  These income tax benefits are included in tax impact of foreign operations in the table above.

[0001571996-19-000008:notes:337]
Prior to U.S. Tax Reform, the Company had not provided deferred taxes on undistributed earnings of its foreign subsidiaries as it was the Company’s intention for these basis differences to remain indefinitely reinvested.  U.S. Tax Reform fundamentally changes the U.S. approach to taxation of foreign earnings to a partial territorial tax system, which generally allows companies to make distributions of non-U.S. earnings to the U.S. without incurring additional U.S. tax.  Additionally, as a result of the U.S. Tax Reform measures described above, the Company believes a significant portion of the Company’s undistributed earnings as of February 1, 2019 will not be subject to further U.S. federal taxation.  As of February 1, 2019, the Company intends to repatriate certain foreign earnings that have been taxed in the U.S. to the extent the foreign earnings are not restricted by local laws and can be accessed in a cost-effective manner.  Accordingly, the Company recorded an immaterial deferred tax liability for the additional non-U.S. taxes that are expected to be incurred related to the repatriation of these earnings.  As of February 1, 2019, the Company has undistributed earnings of certain foreign subsidiaries of approximately $38.4 billion that remain indefinitely reinvested, and as such have not recognized a deferred tax liability.  Determination of the amount of unrecognized deferred income tax liability related to these undistributed earnings is not practicable.

[0001571996-19-000008:notes:338]
The components of the Company’s net deferred tax assets (liabilities) were as follows as of February 1, 2019 and February 2, 2018:

[0001571996-19-000008:notes:339]
|  | February 1, 2019 |  | February 2, 2018 |
|  | (in millions) |
| Deferred tax assets: |  |  |  |
| Deferred revenue and warranty provisions | $ | 1,267 |  |  | $ | 1,022 |  |
| Provisions for product returns and doubtful accounts | 117 |  |  | 95 |  |
| Credit carryforwards | 1,927 |  |  | 540 |  |
| Loss carryforwards | 466 |  |  | 509 |  |
| Operating and compensation related accruals | 683 |  |  | 604 |  |
| Other | 193 |  |  | 158 |  |
| Deferred tax assets | 4,653 |  |  | 2,928 |  |
| Valuation allowance | (1,704 | ) |  | (777 | ) |
| Deferred tax assets, net of valuation allowance | 2,949 |  |  | 2,151 |  |
| Deferred tax liabilities: |  |  |  |
| Leasing and financing | (356 | ) |  | (178 | ) |
| Property and equipment | (547 | ) |  | (483 | ) |
| Acquired intangibles | (3,254 | ) |  | (4,004 | ) |
| Other | (242 | ) |  | (344 | ) |
| Deferred tax liabilities | (4,399 | ) |  | (5,009 | ) |
| Net deferred tax liabilities | $ | (1,450 | ) |  | $ | (2,858 | ) |

[0001571996-19-000008:notes:340]
The tables below summarize the net operating loss carryforwards, tax credit carryforwards, and other deferred tax assets with related valuation allowances recognized as of February 1, 2019 and February 2, 2018:

[0001571996-19-000008:notes:341]
|  | February 1, 2019 |  |  |
|  | Deferred Tax Assets |  | Valuation Allowance |  | Net Deferred Tax Assets |  | First Year Expiring |
|  | (in millions) |
| Credit carryforwards | $ | 1,927 |  |  | $ | (1,152 | ) |  | $ | 775 |  |  | Fiscal 2020 |
| Loss carryforwards | 466 |  |  | (403 | ) |  | 63 |  |  | Fiscal 2020 |
| Other deferred tax assets | 2,260 |  |  | (149 | ) |  | 2,111 |  |  | NA |
| Total | $ | 4,653 |  |  | $ | (1,704 | ) |  | $ | 2,949 |  |  |  |
|  | February 2, 2018 |  |  |
|  | Deferred Tax Assets |  | Valuation Allowance |  | Net Deferred Tax Assets |  | First Year Expiring |
|  | (in millions) |
| Credit carryforwards | $ | 540 |  |  | $ | (366 | ) |  | $ | 174 |  |  | Fiscal 2019 |
| Loss carryforwards | 509 |  |  | (279 | ) |  | 230 |  |  | Fiscal 2019 |
| Other deferred tax assets | 1,879 |  |  | (132 | ) |  | 1,747 |  |  | NA |
| Total | $ | 2,928 |  |  | $ | (777 | ) |  | $ | 2,151 |  |  |  |

[0001571996-19-000008:notes:342]
The Company’s credit carryforwards as of February 1, 2019 and February 2, 2018 relate primarily to U.S. tax credits and the increase in the fiscal year ended February 1, 2019 was primarily attributable to foreign tax credits associated with U.S. Tax Reform that will expire in Fiscal 2028.  The Company assessed the realizability of these U.S. tax credits based on currently enacted and proposed regulations issued by the U.S. Department of the Treasury and the IRS and recorded a valuation allowance of $634 million against these assets, which is included with other impacts of U.S. Tax Reform in the Company’s effective tax rate reconciliation.  The Company’s loss carryforwards as of February 1, 2019 and February 2, 2018 include net operating loss carryforwards from federal, state, and foreign jurisdictions.  The valuation allowances for other deferred tax assets as of February 1, 2019 and February 2, 2018 are primarily related to foreign jurisdictions.  The Company has determined that it will be able to realize the remainder of its deferred tax assets, based on the future reversal of deferred tax liabilities.

[0001571996-19-000008:notes:343]
A reconciliation of the Company’s beginning and ending balances of unrecognized tax benefits is as follows:

[0001571996-19-000008:notes:344]
|  | Fiscal Year Ended |
|  | February 1, 2019 |  | February 2, 2018 |  | February 3, 2017 |
|  | (in millions) |
| Beginning Balance | $ | 2,867 |  |  | $ | 2,752 |  |  | $ | 2,479 |  |
| Unrecognized tax benefits assumed through EMC merger transaction | — |  |  | — |  |  | 558 |  |
| Increases related to tax positions of the current year | 116 |  |  | 155 |  |  | 116 |  |
| Increases related to tax position of prior years | 288 |  |  | 98 |  |  | 227 |  |
| Reductions for tax positions of prior years | (170 | ) |  | (90 | ) |  | (379 | ) |
| Lapse of statute of limitations | (90 | ) |  | (34 | ) |  | (30 | ) |
| Audit settlements | (22 | ) |  | (14 | ) |  | (219 | ) |
| Ending Balance | $ | 2,989 |  |  | $ | 2,867 |  |  | $ | 2,752 |  |

[0001571996-19-000008:notes:345]
During the fiscal year ended February 3, 2017, the Company acquired $558 million of unrecognized tax benefits in connection with the EMC merger transaction.  The Company’s net unrecognized tax benefits were $3.4 billion, $3.2 billion, and $3.1 billion as of February 1, 2019, February 2, 2018, and February 3, 2017, respectively, and are included in other non-current liabilities in the Consolidated Statements of Financial Position.

[0001571996-19-000008:notes:346]
The unrecognized tax benefits in the table above include $2.4 billion, $2.2 billion, and $2.3 billion as of February 1, 2019, February 2, 2018, and February 3, 2017, respectively, that, if recognized, would have impacted income tax expense.  The table does not include accrued interest and penalties of $1.0 billion, $0.9 billion, and $0.7 billion as of February 1, 2019, February 2, 2018, and February 3, 2017, respectively.  Tax benefits associated with interest and state tax deductions and other indirect jurisdictional effects of uncertain tax positions were $611 million, $537 million, and $286 million as of February 1, 2019, February 2, 2018, and February 3, 2017, respectively.  Interest and penalties related to income tax liabilities are included in income tax expense.  The Company recorded interest and penalties of $127 million, $184 million, and $94 million for the fiscal years ended February 1, 2019, February 2, 2018, and February 3, 2017, respectively.

[0001571996-19-000008:notes:347]
Judgment is required in evaluating the Company’s uncertain tax positions and determining the Company’s provision for income taxes.  The Company does not anticipate a significant change to the total amount of unrecognized tax benefits within the next twelve months.  During the fiscal year ended February 3, 2017, the Company closed the IRS audit for fiscal years 2004 through 2006.  As a result, during the fiscal year ended February 3, 2017, the Company recorded a net benefit to the provision for income taxes of $297 million.

[0001571996-19-000008:notes:348]
The Company’s U.S. federal income tax returns for fiscal years 2007 through 2009 are currently under consideration by the Office of Appeals of the IRS.  The IRS issued a Revenue Agent’s Report (“RAR”) related to those years during the fiscal year ended February 3, 2017.  The IRS has proposed adjustments primarily relating to transfer pricing matters with which the Company disagrees and is contesting through the IRS administrative appeals process.  Although this process has been progressing, the timing of any resolution remains uncertain.  In May 2017, the IRS commenced a federal income tax audit for fiscal years 2010 through 2014, which could take several years to complete.

[0001571996-19-000008:notes:349]
Prior to the EMC merger transaction, EMC received a RAR for its tax years 2009 and 2010.  On May 5, 2017, EMC received a RAR for its tax year 2011.  The Company has been contesting certain adjustments proposed in these RARs through the IRS administrative appeals process and, during the three months ended August 3, 2018, reached an agreement on the contested issues with the IRS.  The terms are not material to the Company’s results of operations, financial position, or cash flows.

[0001571996-19-000008:notes:350]
The Company is also currently under income tax audits in various state and foreign jurisdictions.  The Company is undergoing negotiations, and in some cases contested proceedings, relating to tax matters with the taxing authorities in these jurisdictions.  The Company believes that it has provided adequate reserves related to all matters contained in tax periods open to examination.  Although the Company believes it has made adequate provisions for the uncertainties surrounding these audits, should the Company experience unfavorable outcomes, such outcomes could have a material impact on its results of operations, financial position, and cash flows.  With respect to major U.S. state and foreign taxing jurisdictions, the Company is generally not subject to tax examinations for years prior to the fiscal year ended February 2, 2007.

[0001571996-19-000008:notes:351]
The Company takes certain non-income tax positions in the jurisdictions in which it operates and has received certain non-income tax assessments from various jurisdictions.  The Company believes that a material loss in these matters is not probable and that it is not reasonably possible that a material loss exceeding amounts already accrued has been incurred.  The Company believes its positions in these non-income tax litigation matters are supportable and that it ultimately will prevail in the matters.  In the normal course of business, the Company’s positions and conclusions related to its non-income taxes could be challenged and assessments may be made.  To the extent new information is obtained and the Company’s views on its positions, probable outcomes of assessments, or litigation change, changes in estimates to the Company’s accrued liabilities would be recorded in the period in which such a determination is made.  In the resolution process for income tax and non-income tax audits, in certain situations the Company is required to provide collateral guarantees or indemnification to regulators and tax authorities until the matter is resolved.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001571996-19-000008:notes:352]
NOTE 12 — ACCUMULATED OTHER COMPREHENSIVE INCOME (LOSS)

[0001571996-19-000008:notes:353]
Accumulated other comprehensive income (loss) is presented in stockholders’ equity (deficit) in the Consolidated Statements of Financial Position and consists of amounts related to foreign currency translation adjustments, unrealized net gains (losses) on investments, unrealized net gains (losses) on cash flow hedges, and actuarial net gains (losses) from pension and other postretirement plans.

[0001571996-19-000008:notes:354]
The following table presents changes in accumulated other comprehensive income (loss), net of tax, by the following components for the periods indicated:

[0001571996-19-000008:notes:355]
|  | Foreign Currency Translation Adjustments |  | Investments |  | Cash Flow Hedges |  | Pension and Other Postretirement Plans |  | Accumulated Other Comprehensive Income (Loss) |
|  | (in millions) |
| Balances as of January 29, 2016 | $ | (358 | ) |  | $ | — |  |  | $ | 34 |  |  | $ | — |  |  | (324 | ) |
| Other comprehensive income (loss) before reclassifications | (254 | ) |  | (17 | ) |  | 20 |  |  | 19 |  |  | (232 | ) |
| Amounts reclassified from accumulated other comprehensive income (loss) | — |  |  | 1 |  |  | (43 | ) |  | — |  |  | (42 | ) |
| Total change for the period | (254 | ) |  | (16 | ) |  | (23 | ) |  | 19 |  |  | (274 | ) |
| Less: Change in comprehensive income (loss) attributable to non-controlling interests | — |  |  | (3 | ) |  | — |  |  | — |  |  | (3 | ) |
| Balances as of February 3, 2017 | (612 | ) |  | (13 | ) |  | 11 |  |  | 19 |  |  | (595 | ) |
| Other comprehensive income (loss) before reclassifications | 791 |  |  | 31 |  |  | (248 | ) |  | 13 |  |  | 587 |  |
| Amounts reclassified from accumulated other comprehensive income (loss) | — |  |  | 2 |  |  | 134 |  |  | — |  |  | 136 |  |
| Total change for the period | 791 |  |  | 33 |  |  | (114 | ) |  | 13 |  |  | 723 |  |
| Less: Change in comprehensive loss attributable to non-controlling interests | — |  |  | (2 | ) |  | — |  |  | — |  |  | (2 | ) |
| Balances as of February 2, 2018 | 179 |  |  | 22 |  |  | (103 | ) |  | 32 |  |  | 130 |  |
| Adjustment for adoption of accounting standards (Note 2) | — |  |  | (61 | ) |  | — |  |  | 3 |  |  | (58 | ) |
| Other comprehensive income (loss) before reclassifications | (631 | ) |  | 2 |  |  | 299 |  |  | (21 | ) |  | (351 | ) |
| Amounts reclassified from accumulated other comprehensive income (loss) | — |  |  | 43 |  |  | (225 | ) |  | — |  |  | (182 | ) |
| Total change for the period | (631 | ) |  | (16 | ) |  | 74 |  |  | (18 | ) |  | (591 | ) |
| Less: Change in comprehensive income attributable to non-controlling interests | — |  |  | 6 |  |  | — |  |  | — |  |  | 6 |  |
| Balances as of February 1, 2019 | $ | (452 | ) |  | $ | — |  |  | $ | (29 | ) |  | $ | 14 |  |  | $ | (467 | ) |

[0001571996-19-000008:notes:356]
Amounts related to investments are reclassified to net income (loss) when gains and losses are realized.  See Note 3 and Note 4 of the Notes to the Consolidated Financial Statements for more information on the Company’s investments.  Amounts related to the Company’s cash flow hedges are reclassified to net income during the same period in which the items being hedged are recognized in earnings.  See Note 7 of the Notes to the Consolidated Financial Statements for more information on the Company’s derivative instruments.

[0001571996-19-000008:notes:357]
The following tables present reclassifications out of accumulated other comprehensive income (loss), net of tax, to net income (loss) for the periods presented:

[0001571996-19-000008:notes:358]
|  | Fiscal Year Ended |
|  | February 1, 2019 |  | February 2, 2018 |
|  | Investments |  | Cash Flow Hedges |  | Total |  | Investments |  | Cash Flow Hedges |  | Total |
|  | (in millions) |
| Total reclassifications, net of tax: |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue | $ | — |  |  | $ | 225 |  |  | $ | 225 |  |  | $ | — |  |  | $ | (77 | ) |  | $ | (77 | ) |
| Cost of net revenue | — |  |  | — |  |  | — |  |  | — |  |  | (57 | ) |  | (57 | ) |
| Interest and other, net | (43 | ) |  | — |  |  | (43 | ) |  | (2 | ) |  | — |  |  | (2 | ) |
| Total reclassifications, net of tax | $ | (43 | ) |  | $ | 225 |  |  | $ | 182 |  |  | $ | (2 | ) |  | $ | (134 | ) |  | $ | (136 | ) |


## us-gaap:MinorityInterestDisclosureTextBlock

[0001571996-19-000008:notes:359]
NOTE 13 — NON-CONTROLLING INTERESTS

[0001571996-19-000008:notes:360]
VMware, Inc. — The non-controlling interests’ share of equity in VMware, Inc. is reflected as a component of the non-controlling interests in the accompanying Consolidated Statements of Financial Position and was $3.8 billion and $5.2 billion as of February 1, 2019 and February 2, 2018, respectively.  The decrease in non-controlling interest for VMware, Inc. was primarily due to the $2.1 billion cash dividend paid to public stockholders of VMware, Inc. in connection with the Class V transaction described in Note 14 of Notes to the Consolidated Financial Statements.  As of February 1, 2019 and February 2, 2018, the Company held approximately 80.5% and 81.9%, respectively, of the outstanding equity interest in VMware, Inc.  VMware, Inc. restricted stock awards (“RSAs”) were not included in the determination of these ownership interest percentages, as VMware, Inc. had no RSAs outstanding as of February 1, 2019 or February 2, 2018.

[0001571996-19-000008:notes:361]
Pivotal — On April 24, 2018, Pivotal completed a registered underwritten IPO of its Class A common stock.  In conjunction with the IPO, all of Pivotal’s preferred equity shares were converted into shares of its common stock on a one-to-one basis, such that upon completion of its IPO, Pivotal’s outstanding capital stock consisted solely of common stock.  The non-controlling interests’ share of equity in Pivotal is reflected as a component of the non-controlling interest in the accompanying Consolidated Statements of Financial Position and was $983 million and $489 million as of February 1, 2019 and February 2, 2018, respectively.  The increase in non-controlling interest for Pivotal is primarily due to the IPO completed during the three months ended May 4, 2018.  As of February 1, 2019 and February 2, 2018, the Company held approximately 62.8% and 77.1%, respectively, of the outstanding equity interest in Pivotal.

[0001571996-19-000008:notes:362]
Secureworks — The non-controlling interests’ share of equity in Secureworks is reflected as a component of the non-controlling interests in the accompanying Consolidated Statements of Financial Position and was $87 million and $90 million as of February 1, 2019 and February 2, 2018, respectively.  As of February 1, 2019 and February 2, 2018, the Company held approximately 87.4% and 87.1%, respectively, of the outstanding equity interest in Secureworks, excluding RSAs.  As of February 1, 2019 and February 2, 2018, the Company held approximately 86.4% and 86.3%, respectively, of the outstanding equity interest in Secureworks, including RSAs.

[0001571996-19-000008:notes:363]
The effect of changes in the Company’s ownership interest in VMware, Inc., Pivotal, and Secureworks on the Company’s equity was as follows:

[0001571996-19-000008:notes:364]
|  | Fiscal Year Ended |
|  | February 1, 2019 |
|  | (in millions) |
| Net loss attributable to Dell Technologies Inc. | $ | (2,310 | ) |
| Transfers (to)/from the non-controlling interests: |  |
| Increase in Dell Technologies Inc. additional paid-in-capital for equity issuances and other equity activity | 954 |  |
| Decrease in Dell Technologies Inc. additional paid-in-capital for equity issuances and other equity activity | (820 | ) |
| Net transfers from non-controlling interests | 134 |  |
| Change from net loss attributable to Dell Technologies Inc. and transfers (to)/from the non-controlling interests | $ | (2,176 | ) |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001571996-19-000008:notes:365]
NOTE 14 — CAPITALIZATION

[0001571996-19-000008:notes:366]
The following table summarizes the Company’s authorized, issued, and outstanding common stock as of the dates indicated:

[0001571996-19-000008:notes:367]
|  | Authorized |  | Issued |  | Outstanding |
|  | (in millions) |
| Common stock as of February 2, 2018 |
| Class A | 600 |  |  | 410 |  |  | 410 |  |
| Class B | 200 |  |  | 137 |  |  | 137 |  |
| Class C | 7,900 |  |  | 24 |  |  | 23 |  |
| Class D | 100 |  |  | — |  |  | — |  |
| Class V | 343 |  |  | 223 |  |  | 199 |  |
|  | 9,143 |  |  | 794 |  |  | 769 |  |
| Common stock as of February 1, 2019 |
| Class A | 600 |  |  | 410 |  |  | 410 |  |
| Class B | 200 |  |  | 137 |  |  | 137 |  |
| Class C | 7,900 |  |  | 174 |  |  | 172 |  |
| Class D | 100 |  |  | — |  |  | — |  |
| Class V | 343 |  |  | — |  |  | — |  |
|  | 9,143 |  |  | 721 |  |  | 719 |  |

[0001571996-19-000008:notes:368]
Under the Company’s certificate of incorporation as amended and restated upon the completion of the Class V transaction described below, the Company is prohibited from issuing any of the authorized shares of Class V Common Stock.

[0001571996-19-000008:notes:369]
Preferred Stock

[0001571996-19-000008:notes:370]
The Company is authorized to issue one million shares of preferred stock, par value $0.01 per share.  As of February 1, 2019 and February 2, 2018, no shares of preferred stock were issued or outstanding.

[0001571996-19-000008:notes:371]
Common Stock

[0001571996-19-000008:notes:372]
DHI Group Common Stock and DHI Group — The Class A Common Stock, the Class B Common Stock, the Class C Common Stock, and the Class D Common Stock are collectively referred to as the DHI Group Common Stock.  The par value for all classes of DHI Group Common Stock is $0.01 per share.  The Class A Common Stock, the Class B Common Stock, the Class C Common Stock, and the Class D Common Stock share equally in dividends declared or accumulated and have equal participation rights in undistributed earnings.  Prior to the completion of the Class V transaction, the DHI Group referred to the direct and indirect interest of Dell Technologies in all of Dell Technologies’ business, assets, properties, liabilities, and preferred stock other than those attributable to the Class V Group, as well as the DHI Group’s retained interest in the Class V Group.  Subsequent to the completion of the Class V transaction, the DHI Group refers to all classes of issued and outstanding DHI Group Common Stock.

[0001571996-19-000008:notes:373]
Class V Common Stock and Class V Group — The Class V Common Stock was a class of common stock intended to track the performance of a portion of Dell Technologies’ economic interest in the Class V Group.  The Class V Group consisted solely of VMware, Inc. common stock held by the Company.  As of February 1, 2019, no shares of Class V Common Stock remained outstanding.

[0001571996-19-000008:notes:374]
Voting Rights — Each holder of record of: (a) Class A Common Stock is entitled to ten votes per share of Class A Common Stock; (b) Class B Common Stock is entitled to ten votes per share of Class B Common Stock; (c) Class C Common Stock is entitled to one vote per share of Class C Common Stock; and (d) Class D Common Stock is not entitled to any vote on any matter except to the extent required by provisions of Delaware law (in which case such holder is entitled to one vote per share of Class D Common Stock).

[0001571996-19-000008:notes:375]
Class V Transaction

[0001571996-19-000008:notes:376]
On December 28, 2018, the Company completed a transaction, referred to as the “Class V transaction,” pursuant to an Agreement and Plan of Merger (the “Merger Agreement”), dated as of July 1, 2018 and amended as of November 14, 2018, between Dell Technologies and Teton Merger Sub Inc. (“Merger Sub”), a Delaware corporation and wholly-owned subsidiary of Dell Technologies.  Pursuant to the Merger Agreement, Merger Sub was merged with and into Dell Technologies (the “Merger”), with Dell Technologies continuing as the surviving corporation.

[0001571996-19-000008:notes:377]
Dell Technologies completed the Class V transaction following approval of the transaction by its stockholders at a special meeting held on December 11, 2018.  Dell Technologies paid $14.0 billion in cash and issued 149,387,617 shares of its Class C Common Stock in connection with the Class V transaction.  The non-cash consideration portion of the Class V transaction totaled $6.9 billion.  The Class C Common Stock began trading on the NYSE on a when-issued basis as of the opening of trading on December 26, 2018 and on a regular-way basis as of the opening of trading on December 28, 2018.  The Class V Common Stock ceased trading on the NYSE prior to the opening of trading on December 28, 2018.

[0001571996-19-000008:notes:378]
The Class V Common Stock was a class of common stock intended to track the economic performance of a portion of the Company’s interest in the Class V Group, which consisted solely of VMware, Inc. common stock held by the Company.  As a result of the Class V transaction, pursuant to which all outstanding shares of Class V Common Stock ceased to be outstanding, the tracking stock feature of the Company’s capital structure was terminated.  The Class C Common Stock issued to former holders of the Class V Common Stock represents an interest in the Company’s entire business and, unlike the Class V Common Stock, is not intended to track the performance of any distinct assets or business.  The Company’s amended and restated certificate of incorporation that went into effect as of the effective time of the Merger (the “Effective Time”) prohibits the Company from issuing shares of Class V Common Stock.

[0001571996-19-000008:notes:379]
At the Effective Time, each outstanding share of Class V Common Stock was exchanged for either (a) $120.00 in cash, without interest, subject to a cap of $14.0 billion on the aggregate cash consideration, or (b) 1.8066 shares of Class C Common Stock.  The exchange ratio was calculated based on the aggregate amount of cash elections, as well as the aggregate volume-weighted average price per share of Class V Common Stock on the NYSE (as reported on Bloomberg) of $104.8700 for the period of 17 consecutive trading days that began on November 28, 2018 and ended on December 21, 2018.

[0001571996-19-000008:notes:380]
The aggregate cash consideration and the fees and expenses incurred in connection with the Class V transaction were funded with proceeds of $3.67 billion from new term loans under the Company’s senior secured credit facilities, proceeds of a margin loan financing in an aggregate principal amount of $1.35 billion, proceeds of the Company’s pro-rata portion, in the amount of $8.87 billion, of a special $11 billion cash dividend paid by VMware, Inc. in connection with the Class V transaction, and cash on hand at Dell Technologies and its subsidiaries.  See Note 6 of the Notes to the Consolidated Financial Statements for information about the debt incurred by the Company to finance the Class V transaction.

[0001571996-19-000008:notes:381]
The Merger and the Class V transaction have been accounted for as a hybrid liability and equity transaction involving the repurchase of outstanding common stock, with the consideration consisting of a variable combination of cash and shares.  Upon settlement, the accounting for the Class V transaction reflected that the outstanding Class V Common Stock was canceled and exchanged for shares of Class C Common Stock or $120.00 per share in cash or combination of cash and shares, depending on each holder’s election and subject to proration of the cash elections.  The variable nature of the cash obligation to repurchase the shares of Class V Common Stock required the Company to settle a portion of the shares in exchange for cash and therefore was accounted for as a financial instrument with an immaterial mark-to-market adjustment for the change in fair value from the date of the stockholder meeting at which the Company’s stockholders voted to approve the Class V transaction to the election deadline by which holders of Class V Common Stock elected the form of consideration for which they exchanged their shares.

[0001571996-19-000008:notes:382]
For additional information about the Class V transaction, see “Part I — Item 1 — Business” included in this the Company’s annual report on Form 10-K for the fiscal year ended February 1, 2019.

[0001571996-19-000008:notes:383]
Repurchases of Common Stock and Treasury Stock

[0001571996-19-000008:notes:384]
Class V Common Stock Repurchases by Dell Technologies Inc.

[0001571996-19-000008:notes:385]
Since the date of the EMC merger transaction, the Company has authorized several programs to repurchase shares of its Class V Common Stock.  As of February 1, 2019, no amounts of the $2.1 billion total authorized repurchases under the various programs remained available.  The DHI Group Repurchase program described below was suspended as of December 13, 2016 and the $676 million remaining repurchases authorized expired 2 years after the authorization date.  All $1.1 billion authorized under various Class V Group Repurchase Programs described below were fully utilized as of the fiscal year ended February 2, 2018.  The Company repurchased no shares of Class V Common Stock under repurchase programs during the fiscal year ended February 1, 2019.

[0001571996-19-000008:notes:386]
On September 7, 2016, the board of directors of the Company approved a stock repurchase program (the “DHI Group Repurchase Program”) under which the Company was authorized to use assets of the DHI Group to repurchase up to $1.0 billion shares of Class V Common Stock over a period of two years.  During the fiscal year ended February 3, 2017, the Company repurchased 7 million shares of Class V Common Stock for $324 million using cash of the DHI Group.  On December 13, 2016, the board of directors approved the suspension of the DHI Group Repurchase Program until such time as the board of directors authorizes the reinstatement of that program.  Shares repurchased under the DHI Group Repurchase Program were held as treasury stock at cost until the completion of the Class V transaction, at which time all shares of Class V Common Stock held in treasury were retired.  As cash of the DHI Group was used for Class V Common Stock repurchases under the DHI Group Repurchase Program, these repurchased shares were attributed to the DHI Group for the purposes of determining the DHI Group’s retained interest in the Class V Group.  As a result, the number of retained interest shares of the DHI Group, which, together with the number of shares of Class V Common Stock outstanding, were used to calculate such retained interest, increased on a one-for-one basis for each share of Class V Common Stock repurchased under the program.

[0001571996-19-000008:notes:387]
On March 27, 2017 and August 18, 2017, the board of directors approved two amendments of the Class V Group Repurchase Program (the “March 2017 Class V Group Repurchase Program” and the “August 2017 Class V Group Repurchase Program,” respectively) which, when combined, authorized the Company to use assets of the Class V Group to repurchase up to an additional $600 million of Class V Common Stock over additional six month periods from the respective board approval dates. On May 9, 2017, the Company completed the March 2017 Class V Group Repurchase Program, pursuant to which it repurchased 4.6 million shares of Class V Common Stock for $300 million.  On October 31, 2017, the Company completed the August 2017 Class V Group Repurchase Program, pursuant to which it repurchased 3.8 million shares of Class V Common Stock for $300 million.  The repurchase of shares pursuant to the Class V Group repurchase programs was funded from proceeds received by the Class V Group from the sale by a subsidiary of the Company of shares of Class A common stock of VMware, Inc. owned by such subsidiary, as described below under “Class A Common Stock Repurchases by VMware, Inc.” Share repurchases made by VMware, Inc. of its Class A common stock from a subsidiary of the Company did not affect the determination of the respective interests of the Class V Common Stock and the DHI Group in the Class V Group.  Shares repurchased under the V Group Repurchase Program were held as treasury stock at cost until the retirement of such shares upon the completion of the Class V transaction.

[0001571996-19-000008:notes:388]
See Exhibit 99.1 filed with the Company’s annual report on Form 10-K for the fiscal year ended February 1, 2019 for more information regarding Unaudited Attributed Financial Information for the Class V Group.

[0001571996-19-000008:notes:389]
The following table presents the repurchase activity with respect to the Class V Common Stock through the completion of the Class V transaction and the attribution of the Class V Group between the Class V Common Stock and the DHI Group’s retained interest as of the dates indicated:

[0001571996-19-000008:notes:390]
|  | Class V Common Stock |  | DHI Group Retained Interest |
|  | Shares of Class V Common Stock |  | Interest in Class V Group |  | Retained Interest Shares |  | Interest in Class V Group |
|  | (in millions, except percentages) |
| As of September 7, 2016 | 223 |  |  | 65% |  | 120 |  |  | 35% |
| DHI Group Repurchase Program | (7 | ) |  |  |  | 7 |  |  |  |
| Class V Group Repurchase Program | (7 | ) |  |  |  | — |  |  |  |
| As of February 3, 2017 | 209 |  |  | 62% |  | 127 |  |  | 38% |
| Class V Group Repurchase Program | (10 | ) |  |  |  | — |  |  |  |
| As of February 2, 2018 | 199 |  |  | 61% |  | 127 |  |  | 39% |
| Repurchases of Class V Common Stock | (199 | ) |  |  |  | (127 | ) |  |  |
| As of December 28, 2018 | — |  |  | —% |  | — |  |  | —% |

[0001571996-19-000008:notes:391]
As a result of the Class V transaction, pursuant to which all 199,356,591 outstanding shares of Class V Common Stock ceased to be outstanding, the tracking stock feature of the Company’s capital structure was terminated.

[0001571996-19-000008:notes:392]
DHI Group Common Stock Repurchases

[0001571996-19-000008:notes:393]
During the fiscal year ended February 1, 2019, the Company repurchased approximately one million shares of DHI Group Common Stock for approximately $47 million.  During the fiscal years ended February 2, 2018 and February 3, 2017, the Company repurchased an immaterial number of shares of DHI Group Common Stock for approximately $6 million and $10 million, respectively.

[0001571996-19-000008:notes:394]
All shares of DHI Group Common Stock repurchased by the Company are held as treasury stock at cost.

[0001571996-19-000008:notes:395]
VMware, Inc. Class A Common Stock Repurchases by VMware, Inc.

[0001571996-19-000008:notes:396]
Since the date of the EMC merger transaction, VMware, Inc.’s board of directors has authorized the repurchase of a total of $2.2 billion of VMware, Inc.’s Class A common stock, of which $834 million remained available as of February 1, 2019.  VMware, Inc. repurchased 0.3 million shares of its Class A common stock in the open market for approximately $42 million during the fiscal year ended February 1, 2019.

[0001571996-19-000008:notes:397]
On December 15, 2016, the Company entered into a stock purchase agreement with VMware, Inc. (the “December 2016 Stock Purchase Agreement”), pursuant to which VMware, Inc. agreed to repurchase for cash $500 million of shares of VMware, Inc. Class A common stock from a subsidiary of the Company.  During the fiscal year ended February 2, 2018, VMware, Inc. repurchased 1.4 million shares for $125 million pursuant to and in completion of the December 2016 Stock Purchase Agreement.  VMware, Inc. repurchased a total of 6.2 million shares under this agreement, including shares repurchased during the fiscal year ended February 3, 2017.  The Company applied the proceeds from the sale to the repurchase of shares of its Class V Common Stock under the Class V Group Repurchase Program described above.

[0001571996-19-000008:notes:398]
In January 2017 and August 2017, VMware, Inc.’s board of directors authorized the repurchase of up to $2.2 billion of shares of VMware, Inc. Class A common stock (the “January 2017 Authorization” for up to $1.2 billion through the end of Fiscal 2018, and the “August 2017 Authorization” for up to $1.0 billion through August 31, 2018).  In July 2018, VMware, Inc.’s board of directors extended the August 2017 Authorization through August 31, 2019.

[0001571996-19-000008:notes:399]
On March 29, 2017 and August 23, 2017, the Company entered into two new stock purchase agreements with VMware, Inc. (the “March 2017 Stock Purchase Agreement” and the “August 2017 Stock Purchase Agreement,” respectively), pursuant to which VMware, Inc. agreed to repurchase for cash a total of $600 million of VMware, Inc. Class A common stock from a subsidiary of the Company.  VMware, Inc. repurchased approximately 6.1 million shares of Class A common stock, consisting of 3.4 million shares pursuant to the March 2017 Stock Purchase Agreement and 2.7 million shares pursuant to the August 2017 Stock Purchase Agreement.  The proceeds from the sales were applied by the Company to the repurchase of shares of the Class V Common Stock under the March 2017 and August 2017 Class V Group Repurchase Programs described above.  As of November 3, 2017, the sale transactions under the March 2017 and August 2017 Stock Purchase Agreements were completed.  The purchase prices of the 3.4 million shares and 2.7 million shares repurchased by VMware, Inc. were each based on separate volume-weighted average per share prices of the Class A common stock as reported on the New York Stock Exchange during separate specified reference periods, less a discount of 3.5% from the respective volume-weighted average per share price.  During the fiscal year ended February 2, 2018, VMware, Inc. repurchased 6.4 million shares of its Class A common stock in the open market for $724 million.  During the period from September 7, 2016 through February 3, 2017, VMware, Inc. repurchased 8.3 million shares of its Class A common stock in the open market for $611 million.

[0001571996-19-000008:notes:400]
All shares repurchased under VMware, Inc.’s stock repurchase programs are retired.


## us-gaap:EarningsPerShareTextBlock

[0001571996-19-000008:notes:401]
NOTE 15 — EARNINGS (LOSS) PER SHARE

[0001571996-19-000008:notes:402]
Basic earnings (loss) per share is based on the weighted-average effect of all common shares issued and outstanding and is calculated by dividing net income (loss) by the weighted-average shares outstanding during the period.  Diluted earnings (loss) per share is calculated by dividing net income (loss) by the weighted-average number of common shares used in the basic earnings (loss) per share calculation plus the number of common shares that would be issued assuming exercise or conversion of all potentially dilutive instruments.  The Company excludes equity instruments from the calculation of diluted earnings (loss) per share if the effect of including such instruments is antidilutive.

[0001571996-19-000008:notes:403]
Until the completion on December 28, 2018 of the Class V transaction described in Note 14 of the Notes to the Consolidated Financial Statements, the Company had two groups of common stock, denoted as the DHI Group Common Stock and the Class V Common Stock.

[0001571996-19-000008:notes:404]
The Class V Common Stock was a class of common stock intended to track the economic performance of 61% of the Company’s interest in the Class V Group, which consisted solely of VMware, Inc. common stock held by the Company, as of February 2, 2018 and as of immediately before the completion of the Class V transaction.  Upon the completion of the Class V transaction, all outstanding shares of Class V Common Stock ceased to be outstanding, and the tracking stock structure was terminated.  The Class C Common Stock issued to former holders of the Class V Common Stock in the Class V transaction represents an interest in the Company’s entire business and, unlike the Class V Common Stock, is not intended to track the performance of any distinct assets or business.

[0001571996-19-000008:notes:405]
The DHI Group Common Stock consists of four classes of common stock, including the Class A Common Stock, the Class B Common Stock, the Class C Common Stock, and the Class D Common Stock.  Prior to the completion of the Class V transaction, the DHI Group referred to the direct and indirect interest of Dell Technologies in all of Dell Technologies’ business, assets, properties, liabilities, and preferred stock other than those attributable to the Class V Group, as well as the DHI Group’s retained interest in the Class V Group.  Subsequent to the completion of the Class V transaction, the DHI Group refers to all classes of issued and outstanding DHI Group Common Stock.

[0001571996-19-000008:notes:406]
See Note 14 of the Notes to the Consolidated Financial Statements and Exhibit 99.1 filed with the Company’s annual report on Form 10-K for the fiscal year ended February 1, 2019.

[0001571996-19-000008:notes:407]
For purposes of calculating earnings (loss) per share, the Company used the two-class method.  As all classes of DHI Group Common Stock share the same rights in dividends, basic and diluted earnings (loss) per share are the same for each class of DHI Group Common Stock.

[0001571996-19-000008:notes:408]
The following table sets forth basic and diluted earnings (loss) per share for each of the periods presented:

[0001571996-19-000008:notes:409]
|  | Fiscal Year Ended |
|  | February 1, 2019 |  | February 2, 2018 |  | February 3, 2017 |
| Earnings (loss) per share attributable to Dell Technologies Inc. - basic: |  |  |  |  |  |
| Continuing operations - Class V Common Stock - basic | $ | 6.01 |  |  | $ | 1.63 |  |  | $ | 1.36 |  |
| Continuing operations - DHI Group - basic | $ | (6.02 | ) |  | $ | (5.61 | ) |  | $ | (7.19 | ) |
| Discontinued operations - DHI Group - basic | $ | — |  |  | $ | — |  |  | $ | 4.08 |  |
| Earnings (loss) per share attributable to Dell Technologies Inc. - diluted: |  |  |  |  |  |
| Continuing operations - Class V Common Stock - diluted | $ | 5.91 |  |  | $ | 1.61 |  |  | $ | 1.35 |  |
| Continuing operations - DHI Group - diluted | $ | (6.04 | ) |  | $ | (5.62 | ) |  | $ | (7.19 | ) |
| Discontinued operations - DHI Group - diluted | $ | — |  |  | $ | — |  |  | $ | 4.08 |  |

[0001571996-19-000008:notes:410]
The following table sets forth the computation of basic and diluted earnings (loss) per share for each of the periods presented:

[0001571996-19-000008:notes:411]
|  | Fiscal Year Ended |
|  | February 1, 2019 |  | February 2, 2018 |  | February 3, 2017 |
|  | (in millions) |
| Numerator: Continuing operations - Class V Common Stock |  |  |  |  |  |
| Net income from continuing operations attributable to Class V Common Stock - basic (a) | $ | 1,195 |  |  | $ | 331 |  |  | $ | 296 |  |
| Incremental dilution from VMware, Inc. attributable to Class V Common Stock (b) | (18 | ) |  | (5 | ) |  | (3 | ) |
| Net income from continuing operations attributable to Class V Common Stock - diluted | $ | 1,177 |  |  | $ | 326 |  |  | $ | 293 |  |
| Numerator: Continuing operations - DHI Group |  |  |  |  |  |
| Net loss from continuing operations attributable to DHI Group - basic | $ | (3,505 | ) |  | $ | (3,180 | ) |  | $ | (3,379 | ) |
| Incremental dilution from VMware, Inc. attributable to DHI Group (b) | (13 | ) |  | (4 | ) |  | (2 | ) |
| Net loss from continuing operations attributable to DHI Group - diluted | $ | (3,518 | ) |  | $ | (3,184 | ) |  | $ | (3,381 | ) |
| Numerator: Discontinued operations - DHI Group |  |  |  |  |  |
| Income from discontinued operations, net of income taxes - basic and diluted | $ | — |  |  | $ | — |  |  | $ | 1,916 |  |
| Denominator: Class V Common Stock weighted-average shares outstanding |  |  |  |  |  |  |  |
| Weighted-average shares outstanding - basic (c) | 199 |  |  | 203 |  |  | 217 |  |
| Dilutive effect of options, restricted stock units, restricted stock, and other (d) | — |  |  | — |  |  | — |  |
| Weighted-average shares outstanding - diluted | 199 |  |  | 203 |  |  | 217 |  |
| Weighted-average shares outstanding - antidilutive (d) | — |  |  | — |  |  | — |  |
| Denominator: DHI Group weighted-average shares outstanding |  |  |  |  |  |
| Weighted-average shares outstanding - basic (e) | 582 |  |  | 567 |  |  | 470 |  |
| Dilutive effect of options, restricted stock units, restricted stock, and other | — |  |  | — |  |  | — |  |
| Weighted-average shares outstanding - diluted | 582 |  |  | 567 |  |  | 470 |  |
| Weighted-average shares outstanding - antidilutive (f) | 44 |  |  | 35 |  |  | 31 |  |

[0001571996-19-000008:notes:412]
| (a) | For the fiscal year ended February 1, 2019, net income attributable to the Class V Common Stock - basic represents net income attributable to the Class V Group for the period ended December 27, 2018, the last date on which the Class V Common Stock was traded on the NYSE. |

[0001571996-19-000008:notes:413]
| (b) | The incremental dilution from VMware, Inc. represents the impact of VMware, Inc.’s dilutive securities on the diluted earnings (loss) per share of the DHI Group and the Class V Common Stock, respectively, and is calculated by multiplying the difference between VMware, Inc.’s basic and diluted earnings (loss) per share by the number of shares of VMware, Inc. common stock held by the Company. |

[0001571996-19-000008:notes:414]
| (c) | For the fiscal year ended February 1, 2019, the Class V Common Stock weighted-average shares outstanding - basic represents the weighted-average for the period ended December 27, 2018, the last date on which the Class V Common Stock was traded on the NYSE. |

[0001571996-19-000008:notes:415]
| (d) | The dilutive effect of Class V Common Stock-based incentive awards was not material to the calculation of the weighted-average Class V Common Stock shares outstanding. The antidilutive effect of these awards was also not material. |

[0001571996-19-000008:notes:416]
| (e) | For the fiscal year ended February 1, 2019, the DHI Group weighted-average shares outstanding - basic represents the weighted-average shares over the twelve month period, with the Class C shares appropriately weighted for the number of days outstanding before and after the completion of the Class V transaction. |

[0001571996-19-000008:notes:417]
| (f) | Stock-based incentive awards have been excluded from the calculation of the DHI Group’s diluted loss per share because their effect would have been antidilutive, as the Company had a net loss from continuing operations attributable to the DHI Group for the periods presented. |

[0001571996-19-000008:notes:418]
The following table presents a reconciliation to the consolidated net loss attributable to Dell Technologies Inc.:

[0001571996-19-000008:notes:419]
|  | Fiscal Year Ended |
|  | February 1, 2019 |  | February 2, 2018 |  | February 3, 2017 |
|  | (in millions) |
| Net income from continuing operations attributable to Class V Common Stock | $ | 1,195 |  |  | $ | 331 |  |  | $ | 296 |  |
| Net loss from continuing operations attributable to DHI Group | (3,505 | ) |  | (3,180 | ) |  | (3,379 | ) |
| Net loss from continuing operations attributable to Dell Technologies Inc. | (2,310 | ) |  | (2,849 | ) |  | (3,083 | ) |
| Income from discontinued operations, net of income taxes (Note 1) | — |  |  | — |  |  | 1,916 |  |
| Net loss attributable to Dell Technologies Inc. | $ | (2,310 | ) |  | $ | (2,849 | ) |  | $ | (1,167 | ) |


## dell:ReconciliationofConsolidatedNetIncomeLossTableTextBlock

[0001571996-19-000008:notes:420]
The following table presents a reconciliation of (a) the equity in net loss of subsidiaries to the net loss attributable to Dell Technologies Inc. and (b) consolidated net loss to comprehensive net loss attributable to Dell Technologies Inc. for the periods presented:

[0001571996-19-000008:notes:421]
|  | Fiscal Year Ended |
|  | February 1, 2019 |  | February 2, 2018 |  | February 3, 2017 |
|  | (in millions) |
| Equity in net loss from continuing operations of subsidiaries attributable to Dell Technologies Inc. | $ | (2,042 | ) |  | $ | (2,844 | ) |  | $ | (3,076 | ) |
| Equity in net income (loss) from discontinued operations of subsidiaries | — |  |  | — |  |  | 1,916 |  |
| Equity in net loss of subsidiaries attributable to Dell Technologies Inc. | (2,042 | ) |  | (2,844 | ) |  | (1,160 | ) |
| Parent - Total operating expense (a) | (273 | ) |  | — |  |  | — |  |
| Parent - Interest and other, net (a) | (20 | ) |  | (2 | ) |  | (11 | ) |
| Parent - Income tax expense (benefit) (a) | (25 | ) |  | 3 |  |  | (4 | ) |
| Parent - Loss before equity in net income of subsidiaries | $ | (268 | ) |  | $ | (5 | ) |  | $ | (7 | ) |
| Consolidated net loss attributable to Dell Technologies Inc. | (2,310 | ) |  | (2,849 | ) |  | (1,167 | ) |
| Other comprehensive income (loss) of subsidiaries attributable to Dell Technologies Inc. | (539 | ) |  | 725 |  |  | (271 | ) |
| Comprehensive loss attributable to Dell Technologies Inc. | $ | (2,849 | ) |  | $ | (2,124 | ) |  | $ | (1,438 | ) |

[0001571996-19-000008:notes:422]
(a)
During the fiscal year ended February 1, 2019, the increase to expenses and the associated tax benefit was primarily related to the costs incurred in the Class V transaction.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001571996-19-000008:notes:423]
NOTE 16 — STOCK-BASED COMPENSATION

[0001571996-19-000008:notes:424]
Stock-Based Compensation Expense

[0001571996-19-000008:notes:425]
Stock-based compensation expense for the Company was recognized in the Consolidated Statements of Income (Loss) as follows for the respective periods:

[0001571996-19-000008:notes:426]
|  | Fiscal Year Ended |
|  | February 1, 2019 |  | February 2, 2018 |  | February 3, 2017 |
|  | (in millions) |
| Stock-based compensation expense (a) (b): |  |  |  |  |  |  |
| Cost of net revenue | $ | 76 |  |  | $ | 66 |  |  | $ | 35 |  |
| Operating expenses | 842 |  |  | 769 |  |  | 363 |  |
| Stock-based compensation expense before taxes | 918 |  |  | 835 |  |  | 398 |  |
| Income tax benefit | (260 | ) |  | (268 | ) |  | (122 | ) |
| Stock-based compensation expense, net of income taxes | $ | 658 |  |  | $ | 567 |  |  | $ | 276 |  |

[0001571996-19-000008:notes:427]
| (a) | As a result of the EMC merger transaction, stock-based compensation expense before taxes for the fiscal years ended February 1, 2019 and February 2, 2018 includes $731 million and $683 million related to VMware, Inc. plans discussed below. Stock-based compensation expense before taxes for the fiscal year ended February 3, 2017 includes $279 million related to VMware, Inc. plans for the period from September 7, 2016 through February 3, 2017. |

[0001571996-19-000008:notes:428]
| (b) | Stock-based compensation expense before taxes for the fiscal year ended February 3, 2017 does not include $807 million of post-merger stock-based compensation expense and related taxes resulting from the EMC merger transaction. See Note 8 of the Notes to the Consolidated Financial Statements for more information on the EMC merger transaction. |

[0001571996-19-000008:notes:429]
Dell Technologies Inc. Stock-Based Compensation Plans

[0001571996-19-000008:notes:430]
Dell Technologies Inc. 2013 Stock Incentive Plan — On September 7, 2016, at the effective time of the EMC merger transaction, the Denali Holding Inc. 2013 Stock Incentive Plan (the “2013 Plan”) was amended and restated as the Dell Technologies Inc. 2013 Stock Incentive Plan (the “Restated Plan”).  Employees, consultants, non-employee directors, and other service providers of the Company or its affiliates are eligible to participate in the Restated Plan.  The Restated Plan authorized the issuance of an aggregate of 75 million shares of the Company’s Class C Common Stock and 500,000 shares of the Company’s Class V Common Stock, of which 61 million shares of Class C Common Stock were previously reserved for issuance under the 2013 Plan.  The Restated Plan authorizes the Company to grant stock options, restricted stock units (“RSUs”), stock appreciation rights (“SARs”), RSAs, and dividend equivalents.

[0001571996-19-000008:notes:431]
Upon the completion of the Class V transaction on December 28, 2018, the Restated Plan was amended to remove allowance for employee awards to be settled in Class V Common Stock and reflected an increase in the total authorized shares of Class C Common Stock issued under the plan to 75.5 million shares from 75 million shares upon the conversion of 500,000 shares of Class V Common Stock previously authorized under the plan into the same number of shares of Class C Common Stock.  In connection with the Class V transaction, an immaterial number of Class V Common Stock awards issued to the Company’s independent directors were converted into an immaterial number of Class C Common Stock awards, which are reflected in the underlying stock option and restricted stock data as outstanding.  See Note 14 of the Notes to the Consolidated Financial Statements for additional information on the Class V transaction.

[0001571996-19-000008:notes:432]
As of February 1, 2019, there were 32 million shares of Class C Common Stock available for future grants under the Restated Plan.

[0001571996-19-000008:notes:433]
Stock Option Agreements — Stock options granted under the Restated Plan include service-based awards and performance-based awards.  A majority of the service-based stock options vest pro-rata at each option anniversary date over a five-year period.  Performance-based stock options, with a market condition, become exercisable upon achievement of return on equity (“ROE”) metrics up to the seven-year anniversary of the going-private transaction date, depending upon the achievement of the market condition.  Both service-based and performance-based stock options are granted with option exercise prices equal to the fair market value of the Company’s common stock, as determined by the Company’s board of directors or authorized committee.  Generally, shares of common stock issued under both service-based and performance-based awards are subject to liquidity events, such as an initial public offering, change in control, and puts resulting upon the occurrence of specified events.  A majority of the stock options expire ten years after the date of grant.

[0001571996-19-000008:notes:434]
Stock Option Activity — The following table summarizes stock option activity settled in DHI Group Common Stock during the periods presented:

[0001571996-19-000008:notes:435]
|  | Number of Options |  | Weighted-Average Exercise Price |  | Weighted-Average Remaining Contractual Term |  | Aggregate Intrinsic Value (a) |
|  | (in millions) |  | (per share) |  | (in years) |  | (in millions) |
| Options outstanding as of January 29, 2016 | 54 |  |  | $ | 14.30 |  |  |  |  |  |
| Granted | 2 |  |  | 27.09 |  |  |  |  |  |
| Exercised | (1 | ) |  | 14.12 |  |  |  |  |  |
| Forfeited | (7 | ) |  | 15.51 |  |  |  |  |  |
| Canceled/expired | — |  |  | — |  |  |  |  |  |
| Options outstanding as of February 3, 2017 | 48 |  |  | 14.75 |  |  |  |  |  |
| Granted | — |  |  | — |  |  |  |  |  |
| Exercised | (4 | ) |  | 14.62 |  |  |  |  |  |
| Forfeited | (2 | ) |  | 13.75 |  |  |  |  |  |
| Canceled/expired | — |  |  | — |  |  |  |  |  |
| Options outstanding as of February 2, 2018 | 42 |  |  | 14.80 |  |  |  |  |  |
| Granted | — |  |  | — |  |  |  |  |  |
| Exercised | — |  |  | — |  |  |  |  |  |
| Forfeited | — |  |  | — |  |  |  |  |  |
| Canceled/expired | — |  |  | — |  |  |  |  |  |
| Options outstanding as of February 1, 2019 (b) | 42 |  |  | $ | 14.76 |  |  | 4.8 |  | $ | 1,453 |  |
| Exercisable as of February 1, 2019 | 41 |  |  | $ | 14.64 |  |  | 4.8 |  | $ | 1,435 |  |
| Vested and expected to vest (net of estimated forfeitures) as of February 1, 2019 | 42 |  |  | $ | 14.75 |  |  | 4.8 |  | $ | 1,452 |  |

[0001571996-19-000008:notes:436]
| (a) | The aggregate intrinsic values represent the total pre-tax intrinsic values based on the closing price of $49.65 of the Company’s Class C Common Stock as of February 1, 2019 that would have been received by the option holders had all in-the-money options been exercised as of that date. |

[0001571996-19-000008:notes:437]
| (b) | Stock option activity during the period was immaterial. The ending weighted-average exercise price was calculated based on underlying options outstanding as of February 1, 2019. Of the 42 million stock options outstanding on February 1, 2019, 19 million related to performance-based awards and 23 million related to service-based awards. |

[0001571996-19-000008:notes:438]
The total fair value of options vested was $150 million, $45 million, and $50 million for the fiscal years ended February 1, 2019, February 2, 2018, and February 3, 2017, respectively.  The $150 million of the total fair value of options vested for the fiscal year ended February 1, 2019 was primarily attributable to full vesting of 19 million performance-based awards upon achievement of a prescribed ROE measurement that was approved by the Company’s board of directors in connection with the Class V transaction.  The pre-tax intrinsic value of the options exercised was $18 million, $62 million, and $18 million for the fiscal years ended February 1, 2019, February 2, 2018, and February 3, 2017, respectively.  As of February 1, 2019, there was $4 million of total unrecognized stock-based compensation expense, net of estimated forfeitures, related to unvested stock options expected to be recognized over a weighted-average period of 1.6 years.

[0001571996-19-000008:notes:439]
The tax benefit realized from the exercise of stock options was $5 million, $21 million, and $6 million for the fiscal years ended February 1, 2019, February 2, 2018, and February 3, 2017, respectively.

[0001571996-19-000008:notes:440]
In connection with the EMC merger transaction and in accordance with the merger agreement, certain executives holding unvested restricted stock units of EMC (“EMC RSUs”) were given the opportunity to elect to exchange each unvested EMC RSU held by such executives that would otherwise have vested in the ordinary course on or after January 1, 2017 for (a) a deferred cash award having a cash value equal to the closing price of a share of EMC common stock on the last trading day before the closing date of the EMC merger transaction, or $29.05, and (b) an option (“rollover option”) to purchase a share of Class C Common Stock of Dell Technologies (the “rollover opportunity”).  The rollover options have a three-year term and a per share exercise price equal to the fair market value of a share of Class C Common Stock on the date of grant, or $27.50, and, to the extent vested, may be exercised using a cashless exercise method for both the exercise price and the applicable minimum required tax withholding (subject to certain limitations).  Each deferred cash award will vest, and each rollover option will vest and thereby become exercisable, on the same schedule as the EMC RSU for which they were exchanged (with any performance-vesting condition deemed satisfied at the target level of performance upon the closing of the EMC merger transaction).  Pursuant to the rollover opportunity, options to purchase 1.8 million shares of Class C Common Stock were issued and have been included within the stock option activity table above as granted options.

[0001571996-19-000008:notes:441]
Valuation of Service-Based Stock Option Awards — For service-based stock options granted under the 2013 Plan and the Restated Plan, the Company utilized the Black-Scholes option pricing model to estimate the fair value of stock options at the grant date.  The Black-Scholes option pricing model incorporates various assumptions, including leveraged adjusted volatility of a public peer group, expected term, risk-free interest rates, and dividend yields.  The weighted assumptions utilized for valuation of options under this model as well as the weighted-average grant date fair value of stock options granted during the respective periods are presented below.

[0001571996-19-000008:notes:442]
The expected term is based on historical experience and on the terms and conditions of the stock awards granted to employees.  For the periods presented, option valuations used leverage-adjusted volatility of a peer group, and the expected term was based on analysis of the Company’s historical option settlement experience and on the terms and conditions of the stock awards granted.

[0001571996-19-000008:notes:443]
The assumptions utilized in this model as well as the weighted-average grant date fair value of stock options granted in DHI Group Common Stock are presented below.  The Company granted an immaterial number of service-based stock options during the fiscal years ended February 1, 2019 and February 2, 2018.

[0001571996-19-000008:notes:444]
|  | Fiscal Year Ended |
|  | February 3, 2017 |
| Weighted-average grant date fair value of stock options granted per option | $ | 10.36 |  |
| Expected term (in years) | 3.4 |  |
| Risk-free rate (U.S. Government Treasury Note) | 0.9 | % |
| Expected volatility | 51 | % |
| Expected dividend yield | — | % |

[0001571996-19-000008:notes:445]
Valuation of Performance-Based Stock Option Awards — For performance-based stock options granted under the 2013 Plan and the Restated Plan, the Company utilized the Monte Carlo valuation model to simulate probabilities of achievement of the market condition to determine the grant date fair value.  The valuation model for performance-based option grants during the fiscal year ended February 3, 2017 used a weighted-average leverage adjusted five years peer volatility and corresponding risk free interest rate.  Upon fulfillment of a ROE condition, a specific portion of the performance options become exercisable.  An embedded binomial lattice option pricing model was used to determine the value of these exercisable options using the assumption that each option will be exercised at the midpoint between the date of satisfaction of a ROE condition and the expiration date of such option.

[0001571996-19-000008:notes:446]
The assumptions utilized in this model as well as the weighted-average grant date fair value of stock options granted are presented below.  There were no performance-based stock options granted during the fiscal years ended February 1, 2019 and February 2, 2018.

[0001571996-19-000008:notes:447]
|  | Fiscal Year Ended |
|  | February 3, 2017 |
| Weighted-average grant date fair value of stock options granted per option | $ | 8.83 |  |
| Expected term (in years) | — |  |
| Risk-free rate (U.S. Government Treasury Note) | 1.7 | % |
| Expected volatility | 44 | % |
| Expected dividend yield | — | % |

[0001571996-19-000008:notes:448]
Restricted Stock — The Company’s restricted stock primarily consists of RSU awards granted to employees.  RSUs are valued based on the Company’s Class C Common Stock price on the date of grant.  The shares underlying the RSU awards are not issued until the RSU vests.  Upon vesting, each RSU converts into one share of DHI Group Common Stock.

[0001571996-19-000008:notes:449]
The Company’s restricted stock also includes performance stock unit (“PSU”) awards, which have been granted to certain members of the Company’s senior leadership team.  The PSU awards include performance conditions and, in certain cases, a time-based vesting component.  For PSU awards granted under the Restated Plan, the Company utilized the Monte Carlo valuation model to simulate the probabilities of achievement of the market condition to determine the grant date fair value.  The vesting and payout of the PSU awards depends upon the return on equity achieved on various measurement dates or liquidity events.

[0001571996-19-000008:notes:450]
The following table summarizes restricted stock and restricted stock units activity settled in DHI Group Common Stock during the periods presented:

[0001571996-19-000008:notes:451]
|  | Number of Units |  | Weighted-Average Grant Date Fair Value |
|  | (in millions) |  | (per unit) |
| Outstanding, January 29, 2016 | — |  |  | $ | — |  |
| Granted | 11 |  |  | 19.66 |  |
| Vested | — |  |  | — |  |
| Forfeited | (1 | ) |  | 19.63 |  |
| Outstanding, February 3, 2017 | 10 |  |  | $ | 19.63 |  |
| Granted | 1 |  |  | 23.04 |  |
| Vested | (1 | ) |  | 27.59 |  |
| Forfeited | (3 | ) |  | 19.13 |  |
| Outstanding, February 2, 2018 | 7 |  |  | $ | 18.73 |  |
| Granted (a) | — |  |  | — |  |
| Vested | (1 | ) |  | 28.03 |  |
| Forfeited | (1 | ) |  | 17.88 |  |
| Outstanding, February 1, 2019 (b) | 5 |  |  | $ | 18.90 |  |

[0001571996-19-000008:notes:452]
| (a) | The Company granted an immaterial number of restricted stock awards during the fiscal year ended February 1, 2019. |

[0001571996-19-000008:notes:453]
| (b) | As of February 1, 2019, the 5 million units outstanding included 1 million RSUs and 4 million PSUs. |

[0001571996-19-000008:notes:454]
As of February 1, 2019, restricted stock that is expected to vest was as follows:

[0001571996-19-000008:notes:455]
|  | Number of Units |  | Weighted-Average Remaining Contractual Term |  | Aggregate Intrinsic Value (a) |
|  | (in millions) |  | (in years) |  | (in millions) |
| Expected to vest, February 1, 2019 | 5 |  |  | 2.3 |  | $ | 224 |  |

[0001571996-19-000008:notes:456]
| (a) | The aggregate intrinsic value represents the total pre-tax intrinsic values based on the closing price of $49.65 of the Company’s Class C Common Stock as of February 1, 2019 that would have been received by the RSU holders had the RSUs been issued as of February 1, 2019. |

[0001571996-19-000008:notes:457]
The total fair value of restricted stock that vested during the fiscal years ended February 1, 2019 and February 2, 2018 was $24 million and $37 million, respectively, and the pre-tax intrinsic value was $63 million and $44 million, respectively.  As of February 1, 2019, 5 million shares of restricted stock were outstanding, with an aggregate intrinsic value of $238 million.

[0001571996-19-000008:notes:458]
As of February 1, 2019, there was $33 million of unrecognized stock-based compensation expense, net of estimated forfeitures, related to these awards expected to be recognized over a weighted-average period of approximately 1.2 years.

[0001571996-19-000008:notes:459]
Dell Technologies Shares Withheld for Taxes — Under certain situations, shares are withheld from issuance to cover employee taxes for both the vesting of restricted stock units and the exercise of stock options.  For the fiscal years ended February 1, 2019, February 2, 2018, and February 3, 2017, 0.4 million, 1.0 million, and 0.2 million shares, respectively, were withheld to cover $28 million, $35 million, and $6 million, respectively, of employees’ tax obligations.

[0001571996-19-000008:notes:460]
VMware, Inc. Stock-Based Compensation Plans

[0001571996-19-000008:notes:461]
VMware, Inc. 2007 Equity and Incentive Plan — In June 2007, VMware, Inc. adopted its 2007 Equity and Incentive Plan (the “2007 Plan”).  As of February 1, 2019, the number of authorized shares of VMware, Inc.  Class A common stock under the 2007 Plan was 126 million.  The number of shares underlying outstanding equity awards that VMware, Inc. assumes in the course of business acquisitions are also added to the 2007 Plan reserve on an as-converted basis.  VMware, Inc. has assumed 7 million shares, which accordingly have been added to the authorized shares under the 2007 Plan reserve.

[0001571996-19-000008:notes:462]
Awards under the 2007 Plan may be in the form of stock-based awards such as RSUs or stock options.  VMware, Inc.’s Compensation and Corporate Governance Committee determines the vesting schedule for all equity awards.  Generally, restricted stock grants made under the 2007 Plan have a three-year to four-year period over which they vest and vest 25% the first year and semiannually thereafter.  The value of RSU grants is based on VMware, Inc.’s stock price on the date of grant.  The shares underlying the RSU awards are not issued until the RSUs vest.  Upon vesting, each RSU converts into one share of VMware, Inc. Class A common stock.  VMware, Inc.’s restricted stock also includes PSU awards which have been granted to certain VMware, Inc. executives and employees.  The PSU awards include performance conditions and, in certain cases, a time-based or market-based vesting component.  Upon vesting, each PSU award will convert into VMware, Inc.’s Class A common stock at various ratios ranging from 0.5 to 2.0 shares per PSU, depending upon the degree of achievement of the performance or market based target designated by each award.  If minimum performance thresholds are not achieved, then no shares will be issued.

[0001571996-19-000008:notes:463]
The per share exercise price for a stock option awarded under the 2007 Plan will not be less than 100% of the per share fair market value of VMware, Inc. Class A common stock on the date of grant.  Most options granted under the 2007 Plan vest 25% after the first year and monthly thereafter over the following three years and expire between six and seven years from the date of grant.  VMware, Inc. utilizes authorized and unissued shares to satisfy all shares issued under the 2007 Plan.  As of February 1, 2019, there was an aggregate of approximately 12 million shares of common stock available for issuance pursuant to future grants under the 2007 Plan.

[0001571996-19-000008:notes:464]
VMware, Inc. Employee Stock Purchase Plan — In June 2007, VMware, Inc. adopted its 2007 Employee Stock Purchase Plan (the “ESPP”), which is intended to be qualified under Section 423 of the Internal Revenue Code.  As of February 1, 2019, the number of authorized shares under the ESPP was approximately 23 million.  Under the ESPP, eligible VMware, Inc. employees are granted options to purchase shares at the lower of 85% of the fair market value of the stock at the time of grant or 85% of the fair market value at the time of exercise.

[0001571996-19-000008:notes:465]
The option period is generally twelve months and includes two embedded six-month option periods.  Options are exercised at the end of each embedded option period.  If the fair market value of the stock is lower on the first day of the second embedded option period than it was at the time of grant, then the twelve-month option period expires and each enrolled participant is granted a new twelve-month option.  As of February 1, 2019, approximately 7 million shares of VMware, Inc. Class A common stock were available for issuance under the ESPP.

[0001571996-19-000008:notes:466]
The following table summarizes ESPP activity for the periods presented:

[0001571996-19-000008:notes:467]
|  | Fiscal Year Ended |  | For the Period September 7, 2016 through February 3, 2017 |
|  | February 1, 2019 |  | February 2, 2018 |  |
|  | (in millions, except per share amounts) |
| Cash proceeds | $ | 161 |  |  | $ | 65 |  |  | $ | 60 |  |
| Class A common shares purchased | 1.9 |  |  | 0.9 |  |  | 1.5 |  |
| Weighted-average price per share | $ | 84.95 |  |  | $ | 72.40 |  |  | $ | 40.65 |  |

[0001571996-19-000008:notes:468]
As of February 1, 2019, $79 million of ESPP withholdings were recorded as a liability in accrued and other on the Consolidated Statements of Financial Position for the purchase that occurred on February 28, 2019.  Total unrecognized stock-based compensation expense as of February 1, 2019 for the ESPP was $11 million.

[0001571996-19-000008:notes:469]
VMware, Inc. 2007 Equity and Incentive Plan Stock Options — The following table summarizes stock option activity for VMware, Inc. employees in VMware, Inc. stock options:

[0001571996-19-000008:notes:470]
|  | Number of Options |  | Weighted-Average Exercise Price |  | Weighted-Average Remaining Contractual Term |  | Aggregate Intrinsic Value (a) |
|  | (in millions) |  | (per share) |  | (in years) |  | (in millions) |
| Options outstanding as of September 7, 2016 | 2 |  |  | $ | 65.01 |  |  |  |  |  |
| Granted | — |  |  | — |  |  |  |  |  |
| Exercised | — |  |  | — |  |  |  |  |  |
| Forfeited | — |  |  | — |  |  |  |  |  |
| Canceled/expired | — |  |  | — |  |  |  |  |  |
| Options outstanding as of February 3, 2017 (b) | 2 |  |  | 69.38 |  |  |  |  |  |
| Granted | 1 |  |  | 13.79 |  |  |  |  |  |
| Exercised | (1 | ) |  | 53.50 |  |  |  |  |  |
| Forfeited | — |  |  | — |  |  |  |  |  |
| Canceled/expired | — |  |  | — |  |  |  |  |  |
| Options outstanding as of February 2, 2018 | 2 |  |  | 54.63 |  |  |  |  |  |
| Granted | 1 |  |  | 16.07 |  |  |  |  |  |
| Adjustment for special cash dividend (c) | — |  |  | — |  |  |  |  |  |
| Exercised | (1 | ) |  | 46.73 |  |  |  |  |  |
| Forfeited | — |  |  | — |  |  |  |  |  |
| Canceled/expired | — |  |  | — |  |  |  |  |  |
| Options outstanding as of February 1, 2019 (c) | 2 |  |  | $ | 36.50 |  |  | 5.6 |  | $ | 224 |  |
| Exercisable as of February 1, 2019 | 1 |  |  | $ | 55.49 |  |  | 3.2 |  | $ | 103 |  |
| Vested and expected to vest (net of estimated forfeitures) as of February 1, 2019 | 2 |  |  | $ | 36.50 |  |  | 5.6 |  | $ | 224 |  |

[0001571996-19-000008:notes:471]
| (a) | The aggregate intrinsic value represents the total pre-tax intrinsic values based on VMware, Inc.’s closing stock price of $150.51 as of February 1, 2019 that would have been received by the option holders had all in-the-money options been exercised as of that date. |

[0001571996-19-000008:notes:472]
| (b) | Stock option activity during the period was immaterial. The ending weighted-average exercise price was calculated based on underlying options outstanding as of February 3, 2017. |

[0001571996-19-000008:notes:473]
| (c) | The number of options and weighted-average exercise price of options outstanding as of February 1, 2019 reflect the non-cash adjustments to the options as a result of the special cash dividend. |

[0001571996-19-000008:notes:474]
The above table includes stock options granted in conjunction with unvested stock options assumed in business combinations.  As a result, the weighted-average exercise price per share may vary from the VMware, Inc. stock price at time of grant.  The total fair value of VMware, Inc. stock options that vested during the fiscal years ended February 1, 2019 and February 2, 2018 and for the period from September 7, 2016 through February 3, 2017 was $35 million, $32 million, and $13 million, respectively.  The pre-tax intrinsic value of the options exercised during the fiscal years ended February 1, 2019 and February 2, 2018 and for the period from September 7, 2016 through February 3, 2017 was $56 million, $62 million, and $13 million, respectively.

[0001571996-19-000008:notes:475]
The tax benefit realized from the exercise of stock options was $13 million, $21 million, and $4 million for the fiscal years ended February 1, 2019 and February 2, 2018 and for the period from September 7, 2016 through February 3, 2017, respectively.  As of February 1, 2019, there was $89 million of total unrecognized stock-based compensation expense, net of estimated forfeitures, related to unvested stock options expected to be recognized over a weighted-average period of approximately one year.

[0001571996-19-000008:notes:476]
Fair Value of VMware, Inc. Options — The fair value of each option to acquire VMware, Inc. Class A common stock granted is estimated on the date of grant using the Black-Scholes option-pricing model.  The assumptions utilized in this model, as well as the weighted-average assumptions, are presented below.  There were no stock options granted under the 2007 Plan during the period from September 7, 2016 through February 3, 2017.

[0001571996-19-000008:notes:477]
|  | Fiscal Year Ended |
|  | February 1, 2019 |  | February 2, 2018 |
| VMware, Inc. 2007 Equity and Incentive Plan |  |  |  |
| Weighted-average grant date fair value of stock options granted per option | $ | 143.01 |  |  | $ | 83.62 |  |
| Expected term (in years) | 3.2 |  |  | 3.3 |  |
| Risk-free rate (U.S. Government Treasury Note) | 2.9 | % |  | 1.7 | % |
| Expected volatility | 32 | % |  | 29 | % |
| Expected dividend yield | — | % |  | — | % |

[0001571996-19-000008:notes:478]
|  | Fiscal Year Ended |  | September 7, 2016 through |
|  | February 1, 2019 |  | February 2, 2018 |  | February 3, 2017 |
| VMware, Inc. Employee Stock Purchase Plan |  |  |  |  |  |
| Weighted-average grant date fair value of stock options granted per option | $ | 34.72 |  |  | $ | 21.93 |  |  | $ | 13.57 |  |
| Expected term (in years) | 0.8 |  |  | 0.9 |  |  | 0.8 |  |
| Risk-free rate (U.S. Government Treasury Note) | 2.0 | % |  | 1.2 | % |  | 0.5 | % |
| Expected volatility | 33 | % |  | 23 | % |  | 38 | % |
| Expected dividend yield | — | % |  | — | % |  | — | % |

[0001571996-19-000008:notes:479]
The weighted-average grant date fair value of VMware, Inc. stock options can fluctuate from period to period primarily due to higher valued options assumed through business combinations with exercise prices lower than the fair market value of VMware, Inc.’s stock on the date of grant.

[0001571996-19-000008:notes:480]
For equity awards granted, volatility is based on an analysis of historical stock prices and implied volatilities of VMware, Inc.’s Class A common stock.  The expected term is based on historical exercise patterns and post-vesting termination behavior, the term of the option period for grants made under the ESPP, or the weighted-average remaining term for options assumed in acquisitions.  VMware, Inc.’s expected dividend yield input was zero as it has not historically paid cash dividends on its common stock, other than the special cash dividend paid in connection with the Class V transaction described in Note 14 of the Notes to the Consolidated Financial Statements and below, and does not expect to in the future.  The risk-free interest rate is based on a U.S. Treasury instrument whose term is consistent with the expected term of the stock options.

[0001571996-19-000008:notes:481]
On July 1, 2018, VMware, Inc.’s board of directors declared a $11 billion special cash dividend, paid pro-rata to VMware, Inc. stockholders on December 28, 2018 in the amount of $26.81 per outstanding share of VMware, Inc. common stock.

[0001571996-19-000008:notes:482]
VMware, Inc. stock awards that were outstanding at the time of the special cash dividend were adjusted pursuant to anti-dilution provisions in VMware, Inc. equity incentive plan documents that provide for equitable adjustments to be determined by VMware’s Compensation and Corporate Governance Committee in the event of an extraordinary cash dividend.  The adjustments to awards included increasing the number of outstanding restricted stock units and stock options, as well as reducing the exercise prices of outstanding stock options.  The adjustments did not result in incremental stock-based compensation expense as the anti-dilutive adjustments were required by VMware, Inc.’s equity incentive plan.

[0001571996-19-000008:notes:483]
VMware, Inc. Restricted Stock — The following table summarizes VMware, Inc.’s restricted stock activity since September 7, 2016:

[0001571996-19-000008:notes:484]
|  | Number of Units |  | Weighted-Average Grant Date Fair Value |
|  | (in millions) |  | (per unit) |
| Outstanding, September 7, 2016 | 22 |  |  | $ | 67.01 |  |
| Granted | 2 |  |  | 79.81 |  |
| Vested | (3 | ) |  | 72.94 |  |
| Forfeited | (1 | ) |  | 69.19 |  |
| Outstanding, February 3, 2017 | 20 |  |  | $ | 67.41 |  |
| Granted | 8 |  |  | 93.84 |  |
| Vested | (9 | ) |  | 67.89 |  |
| Forfeited | (2 | ) |  | 72.68 |  |
| Outstanding, February 2, 2018 | 17 |  |  | $ | 78.62 |  |
| Granted | 7 |  |  | 146.61 |  |
| Adjustment for special cash dividend | 3 |  |  | NA |  |
| Vested | (7 | ) |  | 75.45 |  |
| Forfeited | (2 | ) |  | 86.90 |  |
| Outstanding, February 1, 2019 (a) | 18 |  |  | $ | 90.06 |  |

[0001571996-19-000008:notes:485]
| (a) | As of February 1, 2019, the 18 million units outstanding included 17 million RSUs and 1 million PSUs. The above table includes RSUs issued for outstanding unvested RSUs in connection with business combinations. The weighted-average grant date fair value of outstanding RSU awards as of February 1, 2019 reflects the non-cash adjustments to the awards as a result of the special cash dividend. |

[0001571996-19-000008:notes:486]
|  | Number of Units |  | Weighted-Average Remaining Contractual Term |  | Aggregate Intrinsic Value (a) |
|  | (in millions) |  | (in years) |  | (in millions) |
| Expected to vest, February 1, 2019 | 16 |  |  | 2.3 |  | $ | 2,438 |  |

[0001571996-19-000008:notes:487]
| (a) | The aggregate intrinsic value represents the total pre-tax intrinsic values based on VMware, Inc.’s closing stock price of $150.51 as of February 1, 2019 that would have been received by the RSU holders had the RSUs been issued as of February 1, 2019. |

[0001571996-19-000008:notes:488]
The total fair value of VMware, Inc. restricted stock awards that vested during the fiscal years ended February 1, 2019 and February 2, 2018 and for the period from September 7, 2016 through February 3, 2017 was $556 million, $616 million, and $203 million, respectively, and the pre-tax intrinsic value was $1,061 million, $946 million, and $218 million, respectively.  As of February 1, 2019, 18 million restricted shares of VMware, Inc.’s Class A common stock were outstanding, with an aggregate intrinsic value of $2,742 million based on VMware, Inc.’s closing stock price as of February 1, 2019.

[0001571996-19-000008:notes:489]
As of February 1, 2019, there was $1,194 million of unrecognized stock-based compensation expense, net of estimated forfeitures, related to these awards expected to be recognized over a weighted-average period of approximately 1.5 years.

[0001571996-19-000008:notes:490]
VMware, Inc. Shares Withheld for Taxes — For the fiscal years ended February 1, 2019 and February 2, 2018 and for the period from September 7, 2016 through February 3, 2017, VMware, Inc. repurchased and retired or withheld 3 million shares, 3 million shares, and 1 million shares of VMware, Inc. Class A common stock, respectively, for $373 million, $348 million, and $77 million, respectively, to cover tax withholding obligations.  These amounts may differ from the amounts of cash remitted for tax withholding obligations on the consolidated statements of cash flows due to the timing of payments.  Pursuant to the respective award agreements, these shares were withheld in conjunction with the net share settlement upon the vesting of restricted stock and restricted stock units (including PSUs) during the period.  The value of the withheld shares, including restricted stock units, was classified as a reduction to additional paid-in capital.

[0001571996-19-000008:notes:491]
Other Plans

[0001571996-19-000008:notes:492]
In addition to the plans disclosed above, the Company has consolidated subsidiaries, Secureworks and Pivotal, that maintain their own equity plans and issue equity grants settling in classes of their own stock.  The stock option and restricted stock unit activity under these plans was not material during the fiscal years ended February 1, 2019, February 2, 2018, and February 3, 2017.


## us-gaap:ScheduleOfShareBasedCompensationEmployeeStockPurchasePlanActivityTableTextBlock

[0001571996-19-000008:notes:493]
The following table summarizes stock option activity for VMware, Inc. employees in VMware, Inc. stock options:

[0001571996-19-000008:notes:494]
(c)
The number of options and weighted-average exercise price of options outstanding as of February 1, 2019 reflect the non-cash adjustments to the options as a result of the special cash dividend.


## us-gaap:ScheduleOfShareBasedPaymentAwardStockOptionsValuationAssumptionsTableTextBlock

[0001571996-19-000008:notes:495]
The assumptions utilized in this model, as well as the weighted-average assumptions, are presented below.  There were no stock options granted under the 2007 Plan during the period from September 7, 2016 through February 3, 2017.


## us-gaap:ShareholdersEquityAndShareBasedPaymentsTextBlock

[0001571996-19-000008:notes:496]
NOTE 17 — REDEEMABLE SHARES

[0001571996-19-000008:notes:497]
Awards under the Company’s stock incentive plans include certain rights that allow the holder to exercise a put feature for the underlying Class A or Class C Common Stock after a six month holding period following the issuance of such common stock.  The put feature requires the Company to purchase the stock at its fair market value.  Accordingly, these awards and such common stock are subject to reclassification from equity to temporary equity, and the Company determines the award amounts to be classified as temporary equity as follows:

[0001571996-19-000008:notes:498]
| • | For stock options to purchase Class C Common Stock subject to service requirements, the intrinsic value of the option is multiplied by the portion of the option for which services have been rendered. Upon exercise of the option, the amount in temporary equity represents the fair value of the Class C Common Stock. |

[0001571996-19-000008:notes:499]
| • | For stock appreciation rights, RSUs, or RSAs, any of which stock award types are subject to service requirements, the fair value of the share is multiplied by the portion of the share for which services have been rendered. |

[0001571996-19-000008:notes:500]
| • | For share-based arrangements that are subject to the occurrence of a contingent event, those amounts are not reclassified to temporary equity until the contingency has been satisfied. Contingent events include the achievement of performance-based metrics. |

[0001571996-19-000008:notes:501]
In connection with the Class V transaction described in Note 14 of the Notes to the Consolidated Financial Statements, the put feature provisions were amended to provide that the put feature will terminate two years after the expiration on June 27, 2019 of the post‑transaction lock‑up applicable to transfers of Dell Technologies securities, or earlier upon consummation of any underwritten public offering of shares of Class C Common Stock.

[0001571996-19-000008:notes:502]
The following table sets forth the amount of redeemable shares classified as temporary equity and summarizes the award type as of the dates indicated:

[0001571996-19-000008:notes:503]
|  | February 1, 2019 |  | February 2, 2018 |
|  | (in millions) |
| Redeemable shares classified as temporary equity | $ | 1,196 |  |  | $ | 384 |  |
| Issued and outstanding unrestricted common shares | 3 |  |  | 3 |  |
| Restricted stock units | 1 |  |  | — |  |
| Restricted stock awards | — |  |  | — |  |
| Outstanding stock options | 31 |  |  | 15 |  |

[0001571996-19-000008:notes:504]
The increase in the value of redeemable shares during the fiscal year ended February 1, 2019 was primarily attributable to an increase in DHI Group Common Stock fair value, as well as the reassessment of vesting of performance-based awards.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001571996-19-000008:notes:505]
RETIREMENT PLAN BENEFITS

[0001571996-19-000008:notes:506]
Defined Benefit Pension Plan

[0001571996-19-000008:notes:507]
In connection with the EMC merger transaction completed on September 7, 2016, the Company assumed all of EMC’s defined benefit obligations and related plan assets, including a noncontributory defined benefit pension plan (the “Pension Plan”) which was assumed as a result of EMC’s prior acquisition of Data General.  Certain of the Company’s foreign subsidiaries also have defined benefit pension plans which were assumed as part of the EMC merger transaction and do not have a material impact on the results of operations or financial position of the Company.

[0001571996-19-000008:notes:508]
Benefits under the Pension Plan are generally based on either career average or final average salaries and creditable years of service as defined in the plan.  The annual cost for the Pension Plan is determined using the projected unit credit actuarial cost method that includes actuarial assumptions and estimates which are subject to change.  As of December 1999, this plan was frozen, so employees no longer accrue pension benefits for future services.  The measurement date for the Pension Plan is the end of the Company’s fiscal year.

[0001571996-19-000008:notes:509]
The following table presents the components of the changes in the Pension Plan benefit obligation for the periods indicated:

[0001571996-19-000008:notes:510]
|  | Benefit Obligation |
|  | (in millions) |
| Benefit obligation as of September 7, 2016 | $ | 590 |  |
| Interest cost | 8 |  |
| Benefits paid | (11 | ) |
| Actuarial loss (gain) | (52 | ) |
| Benefit obligation as of February 3, 2017 | 535 |  |
| Interest cost | 21 |  |
| Benefits paid | (24 | ) |
| Actuarial loss (gain) | 14 |  |
| Benefit obligation as of February 2, 2018 | 546 |  |
| Interest cost | 20 |  |
| Benefits paid | (26 | ) |
| Actuarial loss (gain) | (16 | ) |
| Benefit obligation as of February 1, 2019 | $ | 524 |  |

[0001571996-19-000008:notes:511]
On a weighted-average basis, the assumed discount rate used to determine the benefit obligations at February 1, 2019, February 2, 2018, and February 3, 2017 was 4.0%, 3.8%, and 4.1%, respectively.

[0001571996-19-000008:notes:512]
The following table presents the components of the changes in the fair value of plan assets for the periods indicated:

[0001571996-19-000008:notes:513]
|  | Plan Assets |
|  | (in millions) |
| Fair value of plan assets as of September 7, 2016 | $ | 493 |  |
| Actual return on plan assets | (12 | ) |
| Benefits paid | (11 | ) |
| Fair value of plan assets as of February 3, 2017 | 470 |  |
| Actual return on plan assets | 59 |  |
| Benefits paid | (24 | ) |
| Fair value of plan assets as of February 2, 2018 | 505 |  |
| Actual return on plan assets | (5 | ) |
| Benefits paid | (26 | ) |
| Fair value of plan assets as of February 1, 2019 | $ | 474 |  |

[0001571996-19-000008:notes:514]
The under-funded status of the Pension Plan at February 1, 2019 and February 2, 2018 was $51 million and $41 million, respectively, and is classified as a component of other non-current liabilities in the Consolidated Statements of Financial Position.  The Company did not make any significant contributions to the plan for the fiscal years ended February 1, 2019 and February 2, 2018 and for the period from September 7, 2016 through February 3, 2017, and does not expect to make any significant contributions to the Pension Plan in Fiscal 2020.

[0001571996-19-000008:notes:515]
The following table presents the components of net periodic benefit cost recognized for the periods indicated:

[0001571996-19-000008:notes:516]
|  | Fiscal Year Ended |  | For the Period September 7, 2016 through February 3, 2017 |
|  | February 1, 2019 |  | February 2, 2018 |  |
|  | (in millions) |
| Interest cost | $ | 20 |  |  | $ | 21 |  |  | $ | 8 |  |
| Expected return on plan assets | (28 | ) |  | (30 | ) |  | (16 | ) |
| Net periodic benefit | $ | (8 | ) |  | $ | (9 | ) |  | $ | (8 | ) |

[0001571996-19-000008:notes:517]
The discount rate and expected long-term rate of return on plan assets used in the accounting for the Pension Plan to determine the net periodic benefit cost was 3.8% and 5.8%, respectively, for the fiscal year ended February 1, 2019, and 4.1% and 6.5%, respectively, for the fiscal year ended February 2, 2018.  The discount rate and expected long-term rate of return on plan assets used in the accounting for the Pension Plan to determine the net periodic benefit cost was 3.4% and 6.5%, respectively, for the period from September 7, 2016 through February 3, 2017

[0001571996-19-000008:notes:518]
For the fiscal years ended February 1, 2019 and February 2, 2018, the Pension Plan had net gains of $22 million and $39 million, respectively.  The net gains were recognized in accumulated other comprehensive loss.

[0001571996-19-000008:notes:519]
There were no reclassifications from accumulated other comprehensive loss to a component of net periodic benefit cost during the fiscal years ended February 1, 2019 and February 2, 2018.  Additionally, the Company expects that none of the total balance included in accumulated other comprehensive loss at February 1, 2019 will be recognized as a component of net periodic benefit cost in Fiscal 2020.

[0001571996-19-000008:notes:520]
At February 1, 2019, future benefit payments are expected to be paid as follows: $28 million in Fiscal 2020; $29 million in Fiscal 2021; $31 million in Fiscal 2022; $32 million in Fiscal 2023; $34 million in Fiscal 2024; and $175 million thereafter.

[0001571996-19-000008:notes:521]
Fair Value of Plan Assets — The following table presents the fair value of each class of plan assets by level within the fair value hierarchy as of February 1, 2019 and February 2, 2018:

[0001571996-19-000008:notes:522]
|  | February 1, 2019 |  | February 2, 2018 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | (in millions) |
| Common collective trusts (a) | $ | — |  |  | $ | 322 |  |  | $ | — |  |  | $ | 322 |  |  | $ | — |  |  | $ | 350 |  |  | $ | — |  |  | $ | 350 |  |
| U.S. Treasury securities | 5 |  |  | — |  |  | — |  |  | 5 |  |  | 7 |  |  | — |  |  | — |  |  | 7 |  |
| Corporate debt securities (b) | — |  |  | 147 |  |  | — |  |  | 147 |  |  | — |  |  | 147 |  |  | — |  |  | 147 |  |
| Total | $ | 5 |  |  | $ | 469 |  |  | $ | — |  |  | 474 |  |  | $ | 7 |  |  | $ | 497 |  |  | $ | — |  |  | 504 |  |
| Plan payables, net of accrued interest and dividends (c) |  |  |  |  |  |  | — |  |  |  |  |  |  |  |  | 1 |  |
| Total, net |  |  |  |  |  |  | $ | 474 |  |  |  |  |  |  |  |  | $ | 505 |  |

[0001571996-19-000008:notes:523]
| (a) | Common collective trusts are valued at the net asset value calculated by the fund manager based on the underlying investments and are classified within Level 2 of the fair value hierarchy. |

[0001571996-19-000008:notes:524]
| (b) | Corporate debt securities are valued daily at the closing price reported in active U.S. financial markets and are classified within Level 2 of the fair value hierarchy. |

[0001571996-19-000008:notes:525]
| (c) | Dividends, accrued interest, and net plan payables are not material to the plan assets and therefore have not been classified into the fair value hierarchy. |

[0001571996-19-000008:notes:526]
Investment Strategy — The Pension Plan’s assets are managed by outside investment managers.  The Company’s investment strategy with respect to plan assets is to achieve a long-term growth of capital, consistent with an appropriate level of risk.  The expected long-term rate of return on the plan assets considers the current level of expected returns on risk-free investments (primarily government bonds), the historical level of the risk premium associated with the other asset classes in which the portfolio is invested, and the expectations for future returns of each asset class.  The expected return for each asset class was weighted based on the target asset allocation to develop the expected long-term rate of return on assets.  As market conditions permit, the Company expects to shift the asset allocation to lower the percentage of investments in equities and increase the percentage of investments in long-duration fixed-income securities.  The changes could result in a reduction in the long-term rate of return on the plan assets and increase future pension expense.

[0001571996-19-000008:notes:527]
The following table presents the target allocation of plan assets as of February 1, 2019, and the actual allocation of plan assets as of February 1, 2019 and February 2, 2018:

[0001571996-19-000008:notes:528]
|  | Target Allocation |  | Actual Allocation |
|  | February 1, 2019 |  | February 1, 2019 |  | February 2, 2018 |
| U.S. large capitalization equity securities | 25 | % |  | 24 | % |  | 27 | % |
| U.S. small capitalization equity securities | 5 |  |  | 5 |  |  | 5 |  |
| Foreign equity securities | 7 |  |  | 6 |  |  | 7 |  |
| U.S. long-duration fixed income securities | 60 |  |  | 61 |  |  | 58 |  |
| Below investment grade corporate fixed income securities | 3 |  |  | 4 |  |  | 3 |  |
| Total | 100 | % |  | 100 | % |  | 100 | % |

[0001571996-19-000008:notes:529]
Employee Benefit Plans

[0001571996-19-000008:notes:530]
Dell 401(k) Plan — The Company has a defined contribution retirement plan (the “Dell 401(k) Plan”) that complies with Section 401(k) of the Internal Revenue Code.  Only U.S. employees are eligible to participate in the Dell 401(k) plan.  As of February 1, 2019, the Company matches 100% of each participant’s voluntary contributions, subject to a maximum contribution of 6% of the participant’s eligible compensation, up to an annual limit of $7,500, and participants vest immediately in all contributions to the Dell 401(k) Plan.  The Company’s matching contributions as well as participants’ voluntary contributions are invested according to each participant’s elections in the investment options provided under the Dell 401(k) Plan.  The Company’s contributions during the fiscal years ended February 1, 2019, February 2, 2018, and February 3, 2017 were $254 million, $129 million, and $158 million, respectively.  Contributions increased during the fiscal year ended February 1, 2019 due to the additional participants that were transferred from the EMC 401(k) Plan, as discussed below.

[0001571996-19-000008:notes:531]
EMC 401(k) Plan — The EMC defined contribution retirement plan (the “EMC 401(k) Plan”) was assumed in connection with the EMC merger transaction on September 7, 2016.  Effective January 1, 2018, the EMC 401(k) Plan was terminated and participant account balances were transferred to the Dell 401(k) Plan and the newly-created Pivotal defined contribution plan.  Prior to the termination of the EMC 401(k) Plan on January 1, 2018, the Company’s contributions during the fiscal year ended February 2, 2018 to the EMC 401(k) Plan were $94 million.  The Company’s contributions during the period from September 7, 2016 through February 3, 2017 to the EMC 401(k) Plan were $31 million.

[0001571996-19-000008:notes:532]
VMware, Inc., Secureworks, and Pivotal both have a defined contribution program for certain employees that comply with Section 401(k) of the Internal Revenue Code.


## us-gaap:ScheduleOfAllocationOfPlanAssetsTableTextBlock

[0001571996-19-000008:notes:533]
(c)
Dividends, accrued interest, and net plan payables are not material to the plan assets and therefore have not been classified into the fair value hierarchy.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001571996-19-000008:notes:534]
NOTE 19 — SEGMENT INFORMATION

[0001571996-19-000008:notes:535]
The Company has three reportable segments that are based on the following business units:  Infrastructure Solutions Group (“ISG”); Client Solutions Group (“CSG”); and VMware.

[0001571996-19-000008:notes:536]
ISG previously included Virtustream product and service offerings.  Virtustream’s cloud software and infrastructure-as-a-service solutions enable customers to migrate, run, and manage mission-critical applications in cloud-based IT environments.  During the three months ended May 4, 2018, the Company made certain segment reporting changes, which included the movement of Virtustream’s results from ISG to Other businesses.  None of these changes impacted the Company’s previously reported consolidated financial results, but the Company’s prior period segment results have been recast to reflect this change.

[0001571996-19-000008:notes:537]
ISG includes servers, networking, and storage, as well as services and third-party software and peripherals that are closely tied to the sale of ISG hardware.  CSG includes sales to commercial and consumer customers of desktops, thin client products, and notebooks, as well as services and third-party software and peripherals that are closely tied to the sale of CSG hardware.  VMware’s compute, cloud management, networking and security, storage and availability, and other end-user computing offerings provide a flexible digital foundation to enable the digital transformation VMware’s customers need as they ready their applications, infrastructure, and devices for their future business needs.

[0001571996-19-000008:notes:538]
The reportable segments disclosed herein are based on information reviewed by the Company’s management to evaluate the business segment results.  The Company’s measure of segment operating income for management reporting purposes excludes the impact of Other businesses, purchase accounting, amortization of intangible assets, unallocated corporate transactions, severance and facility action costs, and transaction-related expenses.  The Company does not allocate assets to the above reportable segments for internal reporting purposes.

[0001571996-19-000008:notes:539]
The following table presents a reconciliation of net revenue by the Company’s reportable segments to the Company’s consolidated net revenue as well as a reconciliation of consolidated segment operating income to the Company’s consolidated operating loss:

[0001571996-19-000008:notes:540]
|  | Fiscal Year Ended |
|  | February 1, 2019 |  | February 2, 2018 |  | February 3, 2017 |
|  | (in millions) |
| Consolidated net revenue: |  |  |  |  |  |  |  |
| Infrastructure Solutions Group | $ | 36,720 |  |  | $ | 30,917 |  |  | $ | 22,070 |  |
| Client Solutions Group | 43,196 |  |  | 39,218 |  |  | 36,509 |  |
| VMware | 9,088 |  |  | 7,994 |  |  | 3,543 |  |
| Reportable segment net revenue | 89,004 |  |  | 78,129 |  |  | 62,122 |  |
| Other businesses (a) | 2,329 |  |  | 2,195 |  |  | 1,153 |  |
| Unallocated transactions (b) | (9 | ) |  | (15 | ) |  | 41 |  |
| Impact of purchase accounting (c) | (703 | ) |  | (1,269 | ) |  | (1,152 | ) |
| Total consolidated net revenue | $ | 90,621 |  |  | $ | 79,040 |  |  | $ | 62,164 |  |
| Consolidated operating income (loss): |  |  |  |  |  |
| Infrastructure Solutions Group | $ | 4,151 |  |  | $ | 3,068 |  |  | $ | 2,920 |  |
| Client Solutions Group | 1,960 |  |  | 2,044 |  |  | 1,751 |  |
| VMware | 2,989 |  |  | 2,809 |  |  | 1,516 |  |
| Reportable segment operating income | 9,100 |  |  | 7,921 |  |  | 6,187 |  |
| Other businesses (a) | (174 | ) |  | (125 | ) |  | (42 | ) |
| Unallocated transactions (b) | (72 | ) |  | (24 | ) |  | (198 | ) |
| Impact of purchase accounting (c) | (820 | ) |  | (1,546 | ) |  | (2,266 | ) |
| Amortization of intangibles | (6,138 | ) |  | (6,980 | ) |  | (3,681 | ) |
| Transaction-related expenses (d) | (750 | ) |  | (502 | ) |  | (1,488 | ) |
| Other corporate expenses (e) | (1,337 | ) |  | (1,160 | ) |  | (902 | ) |
| Total consolidated operating loss | $ | (191 | ) |  | $ | (2,416 | ) |  | $ | (2,390 | ) |

[0001571996-19-000008:notes:541]
| (a) | Pivotal, Secureworks, RSA Security, Virtustream, and Boomi constitute “Other businesses” and do not meet the requirements for a reportable segment, either individually or collectively. The results of Other businesses are not material to the Company’s overall results. |

[0001571996-19-000008:notes:542]
| (b) | Unallocated transactions includes long-term incentives, certain short-term incentive compensation expenses, and other corporate items that are not allocated to Dell Technologies’ reportable segments. |

[0001571996-19-000008:notes:543]
| (c) | Impact of purchase accounting includes non-cash purchase accounting adjustments that are primarily related to the EMC merger transaction. |

[0001571996-19-000008:notes:544]
| (d) | Transaction-related expenses includes acquisition, integration, and divestiture related costs, as well as the costs incurred in the Class V transaction. |

[0001571996-19-000008:notes:545]
| (e) | Other corporate expenses includes goodwill impairment charges, severance, facility action costs, and stock-based compensation expense. |

[0001571996-19-000008:notes:546]
The following table presents the disaggregation of net revenue by reportable segment, and by major product categories within the segments:

[0001571996-19-000008:notes:547]
|  | Fiscal Year Ended |
|  | February 1, 2019 |  | February 2, 2018 |  | February 3, 2017 |
|  | (in millions) |
| Net revenue: |  |  |  |  |  |  |
| Infrastructure Solutions Group: |  |  |  |  |  |
| Servers and networking | $ | 19,953 |  |  | $ | 15,533 |  |  | $ | 12,973 |  |
| Storage | 16,767 |  |  | 15,384 |  |  | 9,097 |  |
| Total ISG net revenue | 36,720 |  |  | 30,917 |  |  | 22,070 |  |
| Client Solutions Group: |  |  |  |  |  |
| Commercial | 30,893 |  |  | 27,507 |  |  | 25,773 |  |
| Consumer | 12,303 |  |  | 11,711 |  |  | 10,736 |  |
| Total CSG net revenue | 43,196 |  |  | 39,218 |  |  | 36,509 |  |
| VMware: |  |  |  |  |  |
| Total VMware net revenue | 9,088 |  |  | 7,994 |  |  | 3,543 |  |
| Total segment net revenue | $ | 89,004 |  |  | $ | 78,129 |  |  | $ | 62,122 |  |

[0001571996-19-000008:notes:548]
The following table presents net revenue allocated between the United States and foreign countries for the periods presented:

[0001571996-19-000008:notes:549]
|  | Fiscal Year Ended |
|  | February 1, 2019 |  | February 2, 2018 |  | February 3, 2017 |
|  | (in millions) |
| Net revenue: |  |  |  |  |  |  |  |  |
| United States | $ | 42,803 |  |  | $ | 38,528 |  |  | $ | 30,966 |  |
| Foreign countries | 47,818 |  |  | 40,512 |  |  | 31,198 |  |
| Total net revenue | $ | 90,621 |  |  | $ | 79,040 |  |  | $ | 62,164 |  |

[0001571996-19-000008:notes:550]
The following table presents property, plant, and equipment, net allocated between the United States and foreign countries as of February 1, 2019 and February 2, 2018:

[0001571996-19-000008:notes:551]
|  | February 1, 2019 |  | February 2, 2018 |
|  | (in millions) |
| Property, plant, and equipment, net: |  |  |  |
| United States | $ | 4,058 |  |  | $ | 4,093 |  |
| Foreign countries | 1,201 |  |  | 1,297 |  |
| Total property, plant, and equipment, net | $ | 5,259 |  |  | $ | 5,390 |  |

[0001571996-19-000008:notes:552]
The allocation between domestic and foreign net revenue is based on the location of the customers.  Net revenue from any single foreign country did not constitute more than 10% of the Company’s consolidated net revenue for the fiscal years ended February 1, 2019, February 2, 2018, or February 3, 2017.  Property, plant, and equipment, net from any single foreign country did not constitute more than 10% of the Company’s consolidated property, plant, and equipment, net as of February 1, 2019 or February 2, 2018.


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001571996-19-000008:notes:553]
NOTE 20 — SUPPLEMENTAL CONSOLIDATED FINANCIAL INFORMATION

[0001571996-19-000008:notes:554]
The following table provides additional information on selected accounts included in the Consolidated Statements of Financial Position as of February 1, 2019 and February 2, 2018:

[0001571996-19-000008:notes:555]
|  | February 1, 2019 |  | February 2, 2018 |
|  | (in millions) |
| Cash, cash equivalents, and restricted cash: |  |  |  |
| Cash and cash equivalents | $ | 9,676 |  |  | $ | 13,942 |  |
| Restricted cash - other current assets (a) | 522 |  |  | 423 |  |
| Restricted cash - other non-current assets (a) | 42 |  |  | 13 |  |
| Total cash, cash equivalents, and restricted cash | $ | 10,240 |  |  | $ | 14,378 |  |
| Accounts receivable, net: |  |  |  |
| Gross accounts receivable | $ | 12,456 |  |  | $ | 11,824 |  |
| Allowance for doubtful accounts | (85 | ) |  | (103 | ) |
| Total accounts receivable, net | $ | 12,371 |  |  | $ | 11,721 |  |
| Inventories, net: |  |  |  |
| Production materials | $ | 1,794 |  |  | $ | 967 |  |
| Work-in-process | 702 |  |  | 514 |  |
| Finished goods | 1,153 |  |  | 1,197 |  |
| Total inventories, net | $ | 3,649 |  |  | $ | 2,678 |  |
| Prepaid expenses: |  |  |  |
| Total prepaid expenses (b) | $ | 795 |  |  | $ | 1,016 |  |
| Property, plant, and equipment, net: |  |  |  |
| Computer equipment | $ | 5,219 |  |  | $ | 5,085 |  |
| Land and buildings | 4,559 |  |  | 4,343 |  |
| Machinery and other equipment | 3,829 |  |  | 3,845 |  |
| Total property, plant, and equipment | 13,607 |  |  | 13,273 |  |
| Accumulated depreciation and amortization (c) | (8,348 | ) |  | (7,883 | ) |
| Total property, plant, and equipment, net | $ | 5,259 |  |  | $ | 5,390 |  |
| Accrued and other current liabilities: |  |  |  |
| Compensation | $ | 3,646 |  |  | $ | 2,948 |  |
| Warranty liability | 355 |  |  | 367 |  |
| Income and other taxes | 1,396 |  |  | 1,229 |  |
| Other | 3,098 |  |  | 3,482 |  |
| Total accrued and other current liabilities | $ | 8,495 |  |  | $ | 8,026 |  |
| Other non-current liabilities: |  |  |  |
| Warranty liability | $ | 169 |  |  | $ | 172 |  |
| Deferred and other tax liabilities | 5,527 |  |  | 6,590 |  |
| Other | 631 |  |  | 515 |  |
| Total other non-current liabilities | $ | 6,327 |  |  | $ | 7,277 |  |

[0001571996-19-000008:notes:556]
| (a) | Restricted cash includes cash required to be held in escrow pursuant to DFS securitization arrangements and VMware, Inc. restricted cash. |

[0001571996-19-000008:notes:557]
| (b) | Prepaid expenses are included in other current assets in the Consolidated Statements of Financial Position. |

[0001571996-19-000008:notes:558]
| (c) | During the fiscal years ended February 1, 2019, February 2, 2018, and February 3, 2017, the Company recognized $1.3 billion, $1.5 billion, and $1.2 billion, respectively, in depreciation expense. Additionally, during the fiscal years ended February 1, 2019 and February 2, 2018, the Company retired $0.8 billion and $1.1 billion, respectively, of fully depreciated property, plant, and equipment. |

[0001571996-19-000008:notes:559]
Valuation and Qualifying Accounts

[0001571996-19-000008:notes:560]
The following table summarizes the Company’s valuation and qualifying accounts for the periods indicated:

[0001571996-19-000008:notes:561]
|  | Fiscal Year Ended |
|  | February 1, 2019 |  | February 2, 2018 |  | February 3, 2017 |
|  | (in millions) |
| Trade Receivables - Allowance for doubtful accounts: |  |  |  |  |  |
| Balance at beginning of period | $ | 103 |  |  | $ | 57 |  |  | $ | 36 |  |
| Provision charged to income statement | 77 |  |  | 60 |  |  | 43 |  |
| Bad debt write-offs | (95 | ) |  | (14 | ) |  | (22 | ) |
| Balance at end of period | $ | 85 |  |  | $ | 103 |  |  | $ | 57 |  |
| Customer Financing Receivables - Allowance for financing receivable losses: |  |  |  |  |  |
| Balance at beginning of period | $ | 145 |  |  | $ | 143 |  |  | $ | 176 |  |
| Provision charged to income statement | 95 |  |  | 103 |  |  | 75 |  |
| Charge-offs, net of recoveries (a) | (104 | ) |  | (101 | ) |  | (108 | ) |
| Balance at end of period | $ | 136 |  |  | $ | 145 |  |  | $ | 143 |  |
| Tax Valuation Allowance: |  |  |  |  |  |
| Balance at beginning of period | $ | 777 |  |  | $ | 709 |  |  | $ | 796 |  |
| Charged to income tax provision | 927 |  |  | 68 |  |  | (496 | ) |
| Allowance acquired | — |  |  | — |  |  | 409 |  |
| Balance at end of period | $ | 1,704 |  |  | $ | 777 |  |  | $ | 709 |  |

[0001571996-19-000008:notes:562]
| (a) | Charge-offs to the allowance for financing receivable losses for customer financing receivables includes principal and interest. |

[0001571996-19-000008:notes:563]
Warranty Liability

[0001571996-19-000008:notes:564]
The following table presents changes in the Company’s liability for standard limited warranties for the periods indicated:

[0001571996-19-000008:notes:565]
|  | Fiscal Year Ended |
|  | February 1, 2019 |  | February 2, 2018 |  | February 3, 2017 |
|  | (in millions) |
| Warranty liability: |  |  |  |  |  |
| Warranty liability at beginning of period | $ | 539 |  |  | $ | 604 |  |  | $ | 574 |  |
| Warranty liability assumed through EMC merger transaction | — |  |  | — |  |  | 125 |  |
| Costs accrued for new warranty contracts and changes in estimates for pre-existing warranties (a) (b) | 856 |  |  | 905 |  |  | 852 |  |
| Service obligations honored | (871 | ) |  | (970 | ) |  | (947 | ) |
| Warranty liability at end of period | $ | 524 |  |  | $ | 539 |  |  | $ | 604 |  |
| Current portion | $ | 355 |  |  | $ | 367 |  |  | $ | 405 |  |
| Non-current portion | $ | 169 |  |  | $ | 172 |  |  | $ | 199 |  |

[0001571996-19-000008:notes:566]
| (a) | Changes in cost estimates related to pre-existing warranties are aggregated with accruals for new standard warranty contracts. The Company’s warranty liability process does not differentiate between estimates made for pre-existing warranties and new warranty obligations. |

[0001571996-19-000008:notes:567]
| (b) | Includes the impact of foreign currency exchange rate fluctuations. |

[0001571996-19-000008:notes:568]
Severance Charges

[0001571996-19-000008:notes:569]
The Company incurs costs related to employee severance and records a liability for these costs when it is probable that employees will be entitled to termination benefits and the amounts can be reasonably estimated.  The liability related to these actions is included in accrued and other current liabilities in the Consolidated Statements of Financial Position.

[0001571996-19-000008:notes:570]
The following table presents the activity related to the Company’s severance liability for the periods indicated:

[0001571996-19-000008:notes:571]
|  | Fiscal Year Ended |
|  | February 1, 2019 |  | February 2, 2018 |  | February 3, 2017 |
|  | (in millions) |
| Severance liability: |  |  |  |  |  |
| Severance liability at beginning of period | $ | 175 |  |  | $ | 416 |  |  | $ | 26 |  |
| Severance liability assumed through EMC merger transaction | — |  |  | — |  |  | 70 |  |
| Severance charges to provision | 215 |  |  | 159 |  |  | 541 |  |
| Cash paid and other | (244 | ) |  | (400 | ) |  | (221 | ) |
| Severance liability at end of period | $ | 146 |  |  | $ | 175 |  |  | $ | 416 |  |

[0001571996-19-000008:notes:572]
The following table presents severance charges as included in the Consolidated Statements of Income (Loss) for the periods indicated:

[0001571996-19-000008:notes:573]
|  | Fiscal Year Ended |
|  | February 1, 2019 |  | February 2, 2018 |  | February 3, 2017 |
|  | (in millions) |
| Severance charges: |  |  |  |  |  |
| Cost of net revenue | $ | 17 |  |  | $ | 46 |  |  | $ | 122 |  |
| Selling, general, and administrative | 146 |  |  | 46 |  |  | 355 |  |
| Research and development | 52 |  |  | 67 |  |  | 64 |  |
| Total severance charges | $ | 215 |  |  | $ | 159 |  |  | $ | 541 |  |

[0001571996-19-000008:notes:574]
Interest and other, net

[0001571996-19-000008:notes:575]
The following table provides information regarding interest and other, net for the periods indicated:

[0001571996-19-000008:notes:576]
|  | Fiscal Year Ended |
|  | February 1, 2019 |  | February 2, 2018 |  | February 3, 2017 |
|  | (in millions) |
| Interest and other, net: |  |  |  |  |  |
| Investment income, primarily interest | $ | 313 |  |  | $ | 207 |  |  | $ | 102 |  |
| Gain (loss) on investments, net | 342 |  |  | 72 |  |  | 4 |  |
| Interest expense | (2,488 | ) |  | (2,406 | ) |  | (1,751 | ) |
| Foreign exchange | (206 | ) |  | (113 | ) |  | (77 | ) |
| Debt extinguishment | — |  |  | — |  |  | (337 | ) |
| Other | (131 | ) |  | (113 | ) |  | (45 | ) |
| Total interest and other, net | $ | (2,170 | ) |  | $ | (2,353 | ) |  | $ | (2,104 | ) |


## us-gaap:CondensedFinancialInformationOfParentCompanyOnlyDisclosureTextBlock

[0001571996-19-000008:notes:577]
NOTE 21 — CONDENSED FINANCIAL INFORMATION OF PARENT COMPANY

[0001571996-19-000008:notes:578]
Dell Technologies Inc. has no material assets or standalone operations other than its ownership in its consolidated subsidiaries.  There are restrictions under credit agreements and indentures governing the First Lien Notes and the Senior Notes, described in Note 6 of the Notes to the Consolidated Financial Statements, on the Company’s ability to obtain funds from any of its subsidiaries through dividends, loans, or advances.  As of February 1, 2019, the Company had certain consolidated subsidiaries that were designated as unrestricted subsidiaries for all purposes of the applicable credit agreements and such indentures.  As of February 1, 2019, substantially all of the net assets of the Company’s consolidated subsidiaries were restricted, with the exception of the Company’s unrestricted subsidiaries, primarily VMware, Inc., Secureworks, Pivotal, and their respective subsidiaries.  Accordingly, this condensed financial information is presented on a “Parent-only” basis.  Under a Parent-only presentation, Dell Technologies Inc.’s investments in its consolidated subsidiaries are presented under the equity method of accounting.

[0001571996-19-000008:notes:579]
The following table presents the financial position of Dell Technologies Inc. (Parent) as of February 1, 2019 and February 2, 2018:

[0001571996-19-000008:notes:580]
| Dell Technologies Inc. (Parent) | February 1, 2019 |  | February 2, 2018 |
|  | (in millions) |
| Assets: |  |  |  |
| Other current assets | $ | — |  |  | $ | 1 |  |
| Investments in subsidiaries (a) | — |  |  | 12,128 |  |
| Other non-current assets | 25 |  |  | — |  |
| Total assets | $ | 25 |  |  | $ | 12,129 |  |
| Liabilities: |  |  |  |
| Short-term debt (b) | 13 |  |  | — |  |
| Long-term debt (b) | — |  |  | 26 |  |
| Guarantees of subsidiary obligations (a) | 4,581 |  |  | — |  |
| Total liabilities | 4,594 |  |  | 26 |  |
| Redeemable shares | 1,196 |  |  | 384 |  |
| Stockholders’ equity (deficit): |  |  |  |
| Common stock and capital in excess of $0.01 par value | 16,051 |  |  | 18,449 |  |
| Accumulated deficit | (21,349 | ) |  | (6,860 | ) |
| Accumulated other comprehensive income (loss) | (467 | ) |  | 130 |  |
| Total stockholders’ equity (deficit) | (5,765 | ) |  | 11,719 |  |
| Total liabilities, redeemable shares, and stockholders’ equity (deficit) | $ | 25 |  |  | $ | 12,129 |  |

[0001571996-19-000008:notes:581]
| (a) | Due primarily to the $11 billion cash dividend paid by VMware Inc. in connection with the Class V transaction described in Note 14 of the Notes to the Consolidated Financial Statements, the investments in subsidiaries account was reduced to zero as of February 1, 2019. Guarantees of subsidiary obligations represents the capital Dell Technologies Inc. received in excess of the carrying amount of its investments in subsidiaries. |

[0001571996-19-000008:notes:582]
| (b) | In connection with the acquisition of Dell by Dell Technologies Inc. in the going-private transaction, Dell Technologies Inc. issued a $2.0 billion subordinated note to Microsoft Global Finance, a subsidiary of Microsoft Corporation. As of February 1, 2019 and February 2, 2018, the outstanding principal amount of the Microsoft Note was $13 million and $26 million, respectively. |

[0001571996-19-000008:notes:583]
| (a) | During the fiscal year ended February 1, 2019, the increase to expenses and the associated tax benefit was primarily related to the costs incurred in the Class V transaction. |

[0001571996-19-000008:notes:584]
The following table presents the cash flows of Dell Technologies Inc. (Parent) for the periods presented:

[0001571996-19-000008:notes:585]
|  | Fiscal Year Ended |
| Dell Technologies Inc. (Parent) | February 1, 2019 |  | February 2, 2018 |  | February 3, 2017 |
|  | (in millions) |
| Change in cash from operating activities | $ | (274 | ) |  | $ | (2 | ) |  | $ | (2 | ) |
| Cash flow from investing activities: |  |  |  |  |  |
| Transfer to/from subsidiary | 14,360 |  |  | 640 |  |  | 35,941 |  |
| Acquisition of business, net of cash acquired | — |  |  | — |  |  | (39,521 | ) |
| Change in cash from investing activities | 14,360 |  |  | 640 |  |  | (3,580 | ) |
| Cash flow from financing activities: |  |  |  |  |  |
| Proceeds from the issuance of DHI Group Common Stock | — |  |  | — |  |  | 4,422 |  |
| Shares repurchased for tax withholdings of equity awards | (28 | ) |  | (33 | ) |  | (6 | ) |
| Repurchases of DHI Group Common Stock | (47 | ) |  | (6 | ) |  | (10 | ) |
| Repurchases of Class V Common Stock | (14,000 | ) |  | (723 | ) |  | (701 | ) |
| Repayments of debt | (13 | ) |  | — |  |  | — |  |
| Other | 2 |  |  | 1 |  |  | — |  |
| Change in cash from financing activities | (14,086 | ) |  | (761 | ) |  | 3,705 |  |
| Change in cash, cash equivalents, and restricted cash | — |  |  | (123 | ) |  | 123 |  |
| Cash, cash equivalents, and restricted cash at beginning of the period | — |  |  | 123 |  |  | — |  |
| Cash, cash equivalents, and restricted cash at end of the period | $ | — |  |  | $ | — |  |  | $ | 123 |  |


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001571996-19-000008:notes:586]
NOTE 22 — UNAUDITED QUARTERLY RESULTS

[0001571996-19-000008:notes:587]
The following tables present selected unaudited consolidated statements of income (loss) for each quarter of the fiscal years ended February 1, 2019 and February 2, 2018.  For the fiscal year ended February 2, 2018, unaudited quarterly results have been recast to reflect the adoption of the amended guidance on the recognition of revenue from contracts with customers.

[0001571996-19-000008:notes:588]
|  | Fiscal 2019 |
|  | Q1 |  | Q2 |  | Q3 |  | Q4 (a) |
|  | (in millions, except per share data) |
| Net revenue | $ | 21,356 |  |  | $ | 22,942 |  |  | $ | 22,482 |  |  | $ | 23,841 |  |
| Gross margin | $ | 5,878 |  |  | $ | 6,123 |  |  | $ | 5,943 |  |  | $ | 7,109 |  |
| Net income from continuing operations attributable to Class V Common Stock | $ | 470 |  |  | $ | 320 |  |  | $ | 165 |  |  | $ | 240 |  |
| Net loss from continuing operations attributable to DHI Group | (1,106 | ) |  | (819 | ) |  | (1,041 | ) |  | (539 | ) |
| Net loss from continuing operations attributable to Dell Technologies Inc. | $ | (636 | ) |  | $ | (499 | ) |  | $ | (876 | ) |  | $ | (299 | ) |
| Income (loss) from discontinued operations, net of income taxes | — |  |  | — |  |  | — |  |  | — |  |
| Net loss attributable to Dell Technologies Inc. | $ | (636 | ) |  | $ | (499 | ) |  | $ | (876 | ) |  | $ | (299 | ) |
| Earnings (loss) per share attributable to Dell Technologies Inc. - basic: |  |  |  |  |  |  |  |
| Continuing operations - Class V Common Stock - basic | $ | 2.36 |  |  | $ | 1.61 |  |  | $ | 0.83 |  |  | $ | 1.21 |  |
| Continuing operations - DHI Group - basic | $ | (1.95 | ) |  | $ | (1.44 | ) |  | $ | (1.84 | ) |  | $ | (0.86 | ) |
| Discontinued operations - DHI Group - basic | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Earnings (loss) per share attributable to Dell Technologies Inc. - diluted: |  |  |  |  |  |  |  |
| Continuing operations - Class V Common Stock - diluted | $ | 2.33 |  |  | $ | 1.58 |  |  | $ | 0.81 |  |  | $ | 1.19 |  |
| Continuing operations - DHI Group - diluted | $ | (1.95 | ) |  | $ | (1.45 | ) |  | $ | (1.84 | ) |  | $ | (0.86 | ) |
| Discontinued operations - DHI Group - diluted | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |

[0001571996-19-000008:notes:589]
| (a) | For the three months ended February 1, 2019, net income from continuing operations attributable to the Class V Common Stock represents net income attributable to the Class V Group from November 3, 2018 to December 27, 2018, the last date on which the Class V Common Stock was traded on the NYSE. |

[0001571996-19-000008:notes:590]
|  | Fiscal 2018 |
|  | Q1 |  | Q2 |  | Q3 |  | Q4 |
|  | (in millions, except per share data) |
| Net revenue | $ | 18,000 |  |  | $ | 19,521 |  |  | $ | 19,556 |  |  | $ | 21,963 |  |
| Gross margin | $ | 4,457 |  |  | $ | 4,968 |  |  | $ | 5,220 |  |  | $ | 5,892 |  |
| Net income (loss) from continuing operations attributable to Class V Common Stock | $ | 125 |  |  | $ | 204 |  |  | $ | 198 |  |  | $ | (196 | ) |
| Net income (loss) from continuing operations attributable to DHI Group | (1,296 | ) |  | (936 | ) |  | (1,044 | ) |  | 96 |  |
| Net loss from continuing operations attributable to Dell Technologies Inc. | $ | (1,171 | ) |  | $ | (732 | ) |  | $ | (846 | ) |  | $ | (100 | ) |
| Income (loss) from discontinued operations, net of income taxes | — |  |  | — |  |  | — |  |  | — |  |
| Net loss attributable to Dell Technologies Inc. | $ | (1,171 | ) |  | $ | (732 | ) |  | $ | (846 | ) |  | $ | (100 | ) |
| Earnings (loss) per share attributable to Dell Technologies Inc. - basic: |  |  |  |  |  |  |  |
| Continuing operations - Class V Common Stock - basic | $ | 0.60 |  |  | $ | 1.00 |  |  | $ | 0.98 |  |  | $ | (0.98 | ) |
| Continuing operations - DHI Group - basic | $ | (2.29 | ) |  | $ | (1.65 | ) |  | $ | (1.84 | ) |  | $ | 0.17 |  |
| Discontinued operations - DHI Group - basic | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Earnings (loss) per share attributable to Dell Technologies Inc. - diluted: |  |  |  |  |  |  |  |
| Continuing operations - Class V Common Stock - diluted | $ | 0.59 |  |  | $ | 1.00 |  |  | $ | 0.96 |  |  | $ | (0.98 | ) |
| Continuing operations - DHI Group - diluted | $ | (2.29 | ) |  | $ | (1.66 | ) |  | $ | (1.84 | ) |  | $ | 0.16 |  |
| Discontinued operations - DHI Group - diluted | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001571996-19-000008:notes:591]
RELATED PARTY TRANSACTIONS

[0001571996-19-000008:notes:592]
Dell Technologies is a large global organization that engages in millions of purchase, sales, and other transactions during the fiscal year.  The Company enters into purchase and sales transactions with other publicly-traded and privately-held companies, as well as not-for-profit organizations that could be influenced by members of the Company’s board of directors or the Company’s executive officers.  The Company enters into these arrangements in the ordinary course of its business.  Transactions with related parties were immaterial for the fiscal years ended February 1, 2019, February 2, 2018, and February 3, 2017.


## us-gaap:SubsequentEventsTextBlock

[0001571996-19-000008:notes:593]
NOTE 24 — SUBSEQUENT EVENTS

[0001571996-19-000008:notes:594]
Debt and Refinancing Transactions

[0001571996-19-000008:notes:595]
First Lien Notes — On March 6, 2019, Dell International L.L.C., a Delaware limited liability company, and EMC Corporation, a Massachusetts corporation, both wholly-owned subsidiaries of Dell Technologies Inc., completed a private offering of multiple series of First Lien Notes in an aggregate principal amount of $4.5 billion.  The principal amount, interest rate and maturity of each series of First Lien Notes were as follows:

[0001571996-19-000008:notes:596]
| • | $1,000 million 4.00% First Lien Notes due 2024 |

[0001571996-19-000008:notes:597]
| • | $1,750 million 4.90% First Lien Notes due 2026 |

[0001571996-19-000008:notes:598]
| • | $1,750 million 5.30% First Lien Notes due 2029 |

[0001571996-19-000008:notes:599]
Senior Secured Credit Facilities — On March 13, 2019, the Company entered into an amendment to the credit agreement for the Senior Secured Credit Facilities to obtain a new senior secured Term Loan A-6 Facility in an aggregate principal amount of $3,634 million term A-6 loans maturing on March 13, 2024, of which $2,839 million aggregate principal amount represents the amounts outstanding under the Term Loan A-2 Facility that rolled-over into the Term A-6 Loan Facility.  Subsequently, aggregate principal amount of $1,277 million remained outstanding under the Term Loan A-2 Facility.  The new senior secured term A-6 borrowings amortize quarterly and bear interest at LIBOR plus an applicable margin ranging from 1.25% to 2.00% or a base rate plus an applicable margin of 0.25% to 1.00%

[0001571996-19-000008:notes:600]
Margin Loan Facility — On March 7, 2019, the Company amended the Margin Loan Agreement to increase the aggregate principal amount of borrowings under the facility by $650 million.

[0001571996-19-000008:notes:601]
Proceeds from the First Lien Notes due 2024, First Lien Notes due 2026, and First Lien Notes due 2029, together with the borrowings under the Term Loan A-6 Facility and the incremental Margin Loan Facility financing, were used to repay all of the Company’s outstanding First Lien Notes due June 2019 and repay all outstanding amounts under the Term Loan A-5 Facility due December 2019.  Any remaining proceeds were used to repay outstanding amounts under the Term Loan A-2 Facility and pay related premiums, accrued interest, fees and expenses.

[0001571996-19-000008:notes:602]
Stock-Based Compensation

[0001571996-19-000008:notes:603]
On March 15, 2019, the Company granted long-term incentive awards in the form of 9.2 million serviced-based RSUs and 1.9 million performance-based RSUs in order to align critical talent retention programs with Class C Common Stock shareholder interest.  The service-based RSUs will have a fair value based on the Company’s Class C Common Stock price on the grant date and will vest ratably over a three year period.  Upon vesting, each service-based RSU will convert into one share of Class C Common Stock.  The performance-based RSUs are reflected at target units while the actual number of units that ultimately vest will range from 0% to 200% of target, based on the level of achievement of the performance goals and continued employment with the Company over a performance period ending March 14, 2022.  Approximately 0.9 million of the performance-based RSUs are subject to achievement of market-based performance goals for a relative total shareholder return.  For the non-market performance-based RSUs, the fair values will be based on the Company’s Class C Common Stock price on accounting grant date.  Market-based performance awards will utilize a Monte Carlo valuation model to simulate the probabilities of achievement of relative total shareholder return in order to determine the awards’ fair value.

[0001571996-19-000008:notes:604]
Other than the matters identified above, there were no known events occurring after the balance sheet date and up until the date of the issuance of this report that would materially affect the information presented herein.
