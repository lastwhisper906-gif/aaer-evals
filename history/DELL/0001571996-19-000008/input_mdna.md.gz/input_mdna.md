# DELL MD&A — 0001571996-19-000008


## mdna

[0001571996-19-000008:mdna:1]
ITEM 7 — MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS

[0001571996-19-000008:mdna:2]
This management’s discussion and analysis should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes included in this annual report on Form 10-K.  Multiple accounting standards were adopted during the three months ended May 4, 2018, which resulted in adjustment or reclassification of amounts previously reported.  See Note 2 of the Notes to the Consolidated Financial Statements included in this report for further information regarding our recently adopted accounting standards.

[0001571996-19-000008:mdna:3]
Unless otherwise indicated, all results presented are prepared in a manner that complies, in all material respects, with accounting principles generally accepted in the United States of America (“GAAP”).  Additionally, unless otherwise indicated, all changes identified for the current-period results represent comparisons to results for the prior corresponding fiscal period.

[0001571996-19-000008:mdna:4]
Unless the context indicates otherwise, references in this report to “we,” “us,” “our,” the “Company,” and “Dell Technologies” mean Dell Technologies Inc. and its consolidated subsidiaries, references to “Dell” mean Dell Inc. and Dell Inc.’s consolidated subsidiaries, and references to “EMC” mean EMC Corporation and EMC Corporation’s consolidated subsidiaries.

[0001571996-19-000008:mdna:5]
Our fiscal year is the 52- or 53-week period ending on the Friday nearest January 31.  We refer to our fiscal years ended February 1, 2019, February 2, 2018, and February 3, 2017 as “Fiscal 2019,” “Fiscal 2018,” and “Fiscal 2017,” respectively.  Fiscal 2019 and Fiscal 2018 included 52 weeks.  Fiscal 2017 included 53 weeks, with the extra week included in the fourth quarter of Fiscal 2017.

[0001571996-19-000008:mdna:6]
On September 7, 2016, we completed our acquisition by merger of EMC.  The consolidated results of EMC are included in Dell Technologies’ consolidated results for Fiscal 2019, Fiscal 2018 and the portion of Fiscal 2017 subsequent to the EMC merger transaction.  During Fiscal 2017, we closed the Dell Services, Dell Software Group (“DSG”), and Enterprise Content Division (“ECD”) divestiture transactions.  Accordingly, the results of operations of Dell Services, DSG, and ECD, as well as the related gains or losses on sale, have been excluded from the results of continuing operations in the relevant periods.

[0001571996-19-000008:mdna:7]
INTRODUCTION

[0001571996-19-000008:mdna:8]
Dell Technologies is a leading global end-to-end technology provider, with a comprehensive portfolio of IT hardware, software and service solutions spanning both traditional infrastructure and emerging, multi-cloud technologies that enable our customers to build their digital future and transform how they work and live.  We operate eight complementary businesses: our Infrastructure Solutions Group and our Client Solutions Group, as well as VMware, Inc., Pivotal Software, Inc. (“Pivotal”), SecureWorks Corp. (“Secureworks”), RSA Security LLC (“RSA Security”), Virtustream Group Holdings, Inc. (“Virtustream”), and Boomi, Inc. (“Boomi”).  Together, our strategically aligned family of businesses collaborate across key functional areas such as technology and product development, marketing, go-to-market and global services, and are supported by Dell Financial Services.  We believe this operational philosophy enables our platform to seamlessly deliver differentiated and holistic IT solutions to our customers, which has driven significant revenue growth and share gains.

[0001571996-19-000008:mdna:9]
Dell Technologies operates with significant scale and an unmatched breadth of complementary offerings.  Digital transformation has become essential to all businesses, and we have expanded our portfolio to include holistic solutions that enable our customers to drive their ongoing digital transformation initiatives.  Dell Technologies’ integrated solutions help customers modernize their IT infrastructure, address workforce transformation. and provide critical security solutions to protect against the ever increasing and evolving security threats.  With our extensive portfolio and our commitment to innovation, we have the ability to offer secure, integrated solutions that extend from the edge to the core to the cloud, and we are at the forefront of the software-defined and cloud native infrastructure era.  Our end-to-end portfolio is supported by a differentiated go-to-market engine, which includes a 40,000-person sales force, a global network of channel partners, and a world-class supply chain that together drive revenue growth and operating efficiencies.

[0001571996-19-000008:mdna:10]
Products and Services

[0001571996-19-000008:mdna:11]
We design, develop, manufacture, market, sell, and support a wide range of products and services.  We are organized into the following business units, which are our reportable segments: Infrastructure Solutions Group; Client Solutions Group; and VMware.  Due to our divestitures of Dell Services, DSG, and ECD, the results of these businesses, as well as the related gains or losses on sale, have been excluded from the results of continuing operations in the relevant periods.

[0001571996-19-000008:mdna:12]
| • | Infrastructure Solutions Group (“ISG”) — ISG enables the digital transformation of our customers through our trusted multi-cloud and big data solutions, which are built upon a modern data center infrastructure. Our comprehensive portfolio of advanced storage solutions includes traditional storage solutions as well as next-generation storage solutions (such as all-flash arrays, scale-out file, object platforms and software-defined solutions), while our server portfolio includes high-performance rack, blade, tower and hyperscale servers. Our networking portfolio helps our business customers transform and modernize their infrastructure, mobilize and enrich end-user experiences, and accelerate business applications and processes. Our strengths in server, storage, and virtualization software solutions enable us to offer leading converged and hyper-converged solutions, allowing our customers to accelerate their IT transformation by acquiring scalable integrated IT solutions instead of building and assembling their own IT platforms. ISG also offers attached software, peripherals and services, including support and deployment, configuration, and extended warranty services. |

[0001571996-19-000008:mdna:13]
We are continuing our journey to simplify our storage portfolio, with the goal of ensuring that we deliver the technology needed for our customers’ digital transformation.  As our storage portfolio evolves, we will continue to support our current portfolio of storage solutions.

[0001571996-19-000008:mdna:14]
Approximately half of ISG revenue is generated by sales to customers in the Americas, with the remaining portion derived from sales to customers in the Europe, Middle East, and Africa region (“EMEA”) and the Asia-Pacific and Japan region (“APJ”).

[0001571996-19-000008:mdna:15]
| • | Client Solutions Group (“CSG”) — CSG includes branded hardware (such as desktops, workstations, and notebooks) and branded peripherals (such as displays and projectors), as well as third-party software and peripherals. CSG also offers attached software, peripherals, and services, including support and deployment, configuration, and extended warranty services. |

[0001571996-19-000008:mdna:16]
Approximately half of CSG revenue is generated by sales to customers in the Americas, with the remaining portion derived from sales to customers in EMEA and APJ.

[0001571996-19-000008:mdna:17]
| • | VMware — The VMware reportable segment (“VMware”) reflects the operations of VMware, Inc. (NYSE: VMW) within Dell Technologies. See Exhibit 99.1 filed with this report for further details on the differences between VMware reportable segment results and VMware, Inc. results. |

[0001571996-19-000008:mdna:18]
VMware works with customers in the areas of hybrid cloud, multi-cloud, modern applications, networking and security, and digital workspaces, helping customers manage their IT resources across private clouds and complex multi-cloud, multi-device environments.  VMware’s portfolio supports and addresses the key IT priorities of customers: accelerating their cloud journey, empowering digital workspaces, and transforming networking and security.  VMware solutions provide a flexible digital foundation to enable the digital transformation of VMware’s customers as they ready their applications, infrastructure, and devices for their future business needs.

[0001571996-19-000008:mdna:19]
Approximately half of VMware revenue is generated by sales to customers in the United States.

[0001571996-19-000008:mdna:20]
Our other businesses, described below, consist of product and service offerings of Pivotal, Secureworks, RSA Security, Virtustream, and Boomi, each of which is majority-owned by Dell Technologies.  These businesses are not classified as reportable segments, either individually or collectively, as the results of the businesses are not material to our overall results and the businesses do not meet the criteria for reportable segments.  See Note 19 of the Notes to the Consolidated Financial Statements included in this report for more information about our other businesses.

[0001571996-19-000008:mdna:21]
43

[0001571996-19-000008:mdna:22]
| • | Pivotal (NYSE: PVTL) provides a leading cloud-native platform that makes software development and IT operations a strategic advantage for customers. Pivotal’s cloud-native platform, Pivotal Cloud Foundry, accelerates and streamlines software development by reducing the complexity of building, deploying and operating new cloud-native applications and modernizing legacy applications. On April 24, 2018, Pivotal completed a registered underwritten initial public offering of its Class A common stock. |

[0001571996-19-000008:mdna:23]
| • | Secureworks (NASDAQ: SCWX) is a leading global provider of intelligence-driven information security solutions singularly focused on protecting its clients from cyber attacks. The solutions offered by Secureworks enable organizations of varying size and complexity to fortify their cyber defenses to prevent security breaches, detect malicious activity in near real time, prioritize and respond rapidly to security incidents and predict emerging threats. |

[0001571996-19-000008:mdna:24]
| • | RSA Security provides essential cybersecurity solutions engineered to enable organizations to detect, investigate, and respond to advanced attacks, confirm and manage identities, and, ultimately, help reduce IP theft, fraud, and cybercrime. |

[0001571996-19-000008:mdna:25]
| • | Virtustream offers cloud software and infrastructure-as-a-service solutions that enable customers to migrate, run, and manage mission-critical applications in cloud-based IT environments. Beginning in the first quarter of Fiscal 2019, Virtustream results are reported within other businesses, rather than within ISG. This change in reporting structure did not impact our previously reported consolidated financial results, but our prior period segment results have been recast to reflect the change. |

[0001571996-19-000008:mdna:26]
| • | Boomi specializes in cloud-based integration, connecting information between existing on-premise and cloud-based applications to ensure business processes are optimized, data is accurate and workflow is reliable. |

[0001571996-19-000008:mdna:27]
As the integration of our family of businesses matures, we believe the increasing collaboration, innovation and coordination of the operations and strategies of our businesses, as well as our differentiated go-to-market model, will continue to drive revenue synergies.  Through our coordinated R&D activities, we are able to jointly engineer leading innovative solutions that incorporate the distinct set of hardware, software and services across our businesses.

[0001571996-19-000008:mdna:28]
Our products and services portfolio is continually evolving in response to industry dynamics.  As a result, reclassifications of certain products and services solutions in major product categories may be required.  For further discussion regarding our current reportable segments, see “Results of Operations — Business Unit Results.”

[0001571996-19-000008:mdna:29]
Dell Financial Services

[0001571996-19-000008:mdna:30]
Dell Financial Services and its affiliates (“DFS”) support our businesses by offering and arranging various financing options and services for our customers in North America, Europe, Australia, and New Zealand.  DFS originates, collects, and services customer receivables primarily related to the purchase or use of our product, software, and service solutions.  We also arrange financing for some of our customers in various countries where DFS does not currently operate as a captive.  DFS further strengthens our customer relationships through its flexible consumption models, which enable us to offer our customers the option to pay over time and, in certain cases, based on utilization, providing them with financial flexibility to meet their changing technological requirements.  The results of these operations are allocated to our segments based on the underlying product or service financed.  For additional information about our financing arrangements, see Note 5 of the Notes to the Consolidated Financial Statements included in this report.

[0001571996-19-000008:mdna:31]
Strategic Investments and Acquisitions

[0001571996-19-000008:mdna:32]
As part of our strategy, we will continue to evaluate opportunities for strategic investments through our venture capital investment arm, Dell Technologies Capital, with a focus on emerging technology areas that are relevant to the Dell Technologies unique family of businesses and that will complement our existing portfolio of solutions.  Our investment areas include storage, software-defined networking, management and orchestration, security, machine learning and artificial intelligence, Big Data and analytics, cloud, Internet of Things (“IoT”), and software development operations.  In addition to these investments, we also may make disciplined acquisitions targeting businesses that advance our strategic objectives.  As of February 1, 2019 and February 2, 2018, Dell Technologies held strategic investments of $1.0 billion and $0.7 billion, respectively.

[0001571996-19-000008:mdna:33]
Business Trends and Challenges

[0001571996-19-000008:mdna:34]
We are seeing an unprecedented rate of change in the IT industry.  Organizations of all kinds are embracing digital technology to achieve their business objectives.  Our vision is to be an essential infrastructure company and leader in end-user computing, data center infrastructure solutions, virtualization, IoT, and cloud software that our customers continue to trust and rely on for their IT solutions and transformations as they embrace the multi-cloud environment of today.  We accelerate results for our customers by enabling them to be more efficient, mobile, informed, and secure.  We continue to invest in research and development, sales, and other key areas of our business to deliver superior products and solutions capabilities and to drive execution of long-term sustainable growth.  We believe that our results will benefit from an integrated go-to-market strategy, including enhanced coordination among the family of Dell Technologies companies, and from our differentiated products and solutions capabilities.  We intend to continue to execute on our business model and seek to balance liquidity, profitability, and growth to position our company for long-term success.

[0001571996-19-000008:mdna:35]
We expect that ISG will continue to be impacted by the changing nature of the IT infrastructure market and competitive environment.  Cloud-native applications are expected to continue as a primary growth driver in the infrastructure market as IT organizations increasingly become multi-cloud environments.  We believe the complementary cloud solutions across our business strongly position us to meet these demands for our customers who are increasingly looking to leverage cloud-based computing.  We also continue to be impacted by the emerging trends of enterprises deploying software-defined storage, hyper-converged infrastructure, and modular solutions based on server-centric architectures.  These trends are changing the way customers are consuming our traditional storage offerings, and we are focused on enabling new capabilities in our storage portfolio.  Offsetting such trends, however, is the unprecedented data growth throughout all industries, which is generating continued demand for our storage products and services.  We have leading solutions through our ISG and VMware data center offerings.  In addition, through our research and development efforts, we expect to develop new solutions in this rapidly changing industry that we believe will enable us to continue to provide superior solutions to our customers.

[0001571996-19-000008:mdna:36]
In ISG, we are also seeing increased interest in flexible consumption models by our customers as they seek to build greater flexibility into their cost structures.  These solutions are generally multi-year contracts that typically result in recognition of revenue over the term of the arrangement.  We expect these flexible consumption models will further strengthen our customer relationships and will provide more predictable revenue streams over time.

[0001571996-19-000008:mdna:37]
We are able to leverage our traditional strength in the PC market to offer solutions and services that provide higher-value, recurring revenue streams.  Given current market trends, we expect that the demand environment will continue to be cyclical and that competitive dynamics will continue to pressure our CSG business.  However, we are committed to a long-term growth strategy that we believe will benefit from the consolidation trends that are occurring in our markets.  Our CSG offerings are an important element of our strategy, generating strong cash flow and opportunities for cross-selling of complementary solutions.

[0001571996-19-000008:mdna:38]
We manage our business on a U.S. dollar basis.  However, we have a large global presence, generating approximately half of our revenue by sales to customers outside of the United States during Fiscal 2019, Fiscal 2018, and Fiscal 2017.  Our revenue, therefore, can be impacted by fluctuations in foreign currency exchange rates.  We utilize a comprehensive hedging strategy intended to mitigate the impact of foreign currency volatility over time, and we adjust pricing when possible to further minimize foreign currency impacts.

[0001571996-19-000008:mdna:39]
Key Performance Metrics

[0001571996-19-000008:mdna:40]
Our key performance metrics are net revenue, operating income, adjusted EBITDA, and cash flows from operations, which are discussed elsewhere in this report.

[0001571996-19-000008:mdna:41]
EMC Merger Transaction

[0001571996-19-000008:mdna:42]
As described in Note 8 of the Notes to the Consolidated Financial Statements included in this report, on September 7, 2016, a wholly-owned merger subsidiary of Dell Technologies merged with and into EMC, with EMC surviving the merger as a wholly-owned subsidiary of Dell Technologies Inc. (the “EMC merger transaction”).

[0001571996-19-000008:mdna:43]
Pursuant to the terms of the merger agreement, upon the completion of the EMC merger transaction, each issued and outstanding share of common stock, par value $0.01 per share, of EMC (approximately 2.0 billion as of September 7, 2016) was converted into the right to receive (1) $24.05 in cash, without interest, and (2) 0.11146 validly issued, fully paid and non-assessable shares of common stock of Dell Technologies designated as Class V Common Stock, par value $0.01 per share, plus cash in lieu of any fractional shares.  Shares of the Class V Common Stock were approved for listing on the New York Stock Exchange (the “NYSE”) under the ticker symbol “DVMT” and began trading on September 7, 2016.

[0001571996-19-000008:mdna:44]
In connection with the EMC merger transaction, all principal, accrued but unpaid interest, fees, and other amounts (other than certain contingent obligations) outstanding at the effective time of the EMC merger transaction under EMC’s unsecured revolving credit facility, Dell’s asset-based revolving credit facility, and Dell’s term facilities were substantially repaid concurrently with the closing.  Further, all commitments to lend and guarantees and security interests, as applicable, in connection therewith were terminated or released.  The aggregate amounts of principal, interest, and premium necessary to redeem in full the outstanding $1.4 billion in aggregate principal amount of 5.625% Senior First Lien Notes due 2020 co-issued by Dell International L.L.C. and Denali Finance Corp. were deposited with the trustee for such notes, and such notes were thereby satisfied and discharged, concurrently with the effective time of the EMC merger transaction.  All of Dell’s other outstanding senior notes and all of EMC’s outstanding senior notes remained outstanding after the effective time of the EMC merger transaction in accordance with their respective terms.

[0001571996-19-000008:mdna:45]
Dell Technologies financed the EMC merger transaction, the repayment of the foregoing indebtedness of EMC and Dell outstanding as of the closing of the EMC merger transaction, and the payment of related fees and expenses, with debt financing arrangements in an aggregate principal amount of approximately $45.9 billion, equity financing arrangements of approximately $4.4 billion, and cash on hand of approximately $7.8 billion.

[0001571996-19-000008:mdna:46]
See Note 6 and Note 8 of the Notes to the Consolidated Financial Statements included in this report for additional information regarding the EMC merger transaction and the related financing transactions.

[0001571996-19-000008:mdna:47]
Class V Transaction

[0001571996-19-000008:mdna:48]
Transaction Terms — On December 28, 2018, we completed a transaction, referred to as the “Class V transaction,” pursuant to an Agreement and Plan of Merger (the “Merger Agreement”), dated as of July 1, 2018 and amended as of November 14, 2018, between Dell Technologies and Teton Merger Sub Inc. (“Merger Sub”), a Delaware corporation and wholly-owned subsidiary of Dell Technologies.  Pursuant to the Merger Agreement, Merger Sub was merged with and into Dell Technologies (the “Merger”), with Dell Technologies continuing as the surviving corporation.

[0001571996-19-000008:mdna:49]
Dell Technologies completed the Class V transaction following approval of the transaction by its stockholders at a special meeting held on December 11, 2018.  Dell Technologies paid $14 billion in cash and issued 149,387,617 shares of its Class C Common Stock in connection with the Class V transaction.  The Class C Common Stock began trading on the NYSE on a when-issued basis as of the opening of trading on December 26, 2018 and on a regular-way basis as of the opening of trading on December 28, 2018.  The Class V Common Stock ceased trading on the NYSE prior to the opening of trading on December 28, 2018.

[0001571996-19-000008:mdna:50]
The Class V Common Stock was a type of common stock intended to track the economic performance of a portion of our interest in the Class V Group, which consisted solely of VMware, Inc. common stock held by Dell Technologies.  As a result of the Class V transaction, pursuant to which all outstanding shares of Class V Common Stock ceased to be outstanding, the tracking stock feature of our capital structure was terminated.  The Class C Common Stock issued to former holders of the Class V Common Stock represents an interest in Dell Technologies’ entire business and, unlike the Class V Common Stock, is not intended to track the performance of any distinct assets or business.  Our amended and restated certificate of incorporation that went into effect as of the effective time of the Merger (the “Effective Time”) prohibits Dell Technologies from issuing shares of Class V Common Stock.

[0001571996-19-000008:mdna:51]
At the Effective Time, each outstanding share of Class V Common Stock was exchanged for either (1) $120.00 in cash, without interest, subject to a cap of $14 billion on the aggregate cash consideration, or (2) 1.8066 shares of Class C Common Stock.  The exchange ratio was calculated based on the aggregate amount of cash elections, as well as the aggregate volume-weighted average price per share of Class V Common Stock on the NYSE (as reported on Bloomberg) of $104.8700 for the period of 17 consecutive trading days that began on November 28, 2018 and ended on December 21, 2018.

[0001571996-19-000008:mdna:52]
The aggregate cash consideration and the fees and expenses incurred in connection with the Class V transaction were funded with proceeds of $3.67 billion from new term loans under our senior secured credit facilities, proceeds of a margin loan financing in an aggregate principal amount of $1.35 billion, proceeds of Dell Technologies’ pro-rata portion, in the amount of $8.87 billion, of a special $11 billion cash dividend paid by VMware, Inc. in connection with the Class V transaction, and cash on hand at Dell Technologies and its subsidiaries.  See Note 6 of the Notes to the Consolidated Financial Statements included in this report for information about the debt we incurred to finance the Class V transaction.

[0001571996-19-000008:mdna:53]
For additional information about the Class V transaction, see “Part I — Item 1 — Business.”

[0001571996-19-000008:mdna:54]
Accounting Treatment — The Merger and the Class V transaction have been accounted for as a hybrid liability and equity transaction involving the repurchase of outstanding common stock, with the consideration consisting of a variable combination of cash and shares.  Upon settlement, the accounting for the Class V transaction reflected that the outstanding Class V Common Stock was canceled and exchanged for shares of Class C Common Stock or $120.00 per share in cash or combination of cash and shares, depending on each holder’s election and subject to proration of the cash elections.  The variable nature of the cash obligation to repurchase the shares of Class V Common Stock required us to settle a portion of the shares in exchange for cash and therefore was accounted for as a financial instrument with an immaterial mark-to-market adjustment for the change in fair value from the date of the stockholder meeting at which our stockholders voted to approve the Class V transaction to the election deadline by which holders of Class V Common Stock elected the form of consideration for which they exchanged their shares.

[0001571996-19-000008:mdna:55]
47

[0001571996-19-000008:mdna:56]
NON-GAAP FINANCIAL MEASURES

[0001571996-19-000008:mdna:57]
In this management’s discussion and analysis, we use supplemental measures of our performance which are derived from our consolidated financial information but which are not presented in our consolidated financial statements prepared in accordance with GAAP.  These non-GAAP financial measures include non-GAAP product net revenue; non-GAAP services net revenue; non-GAAP net revenue; non-GAAP product gross margin; non-GAAP services gross margin; non-GAAP gross margin; non-GAAP operating expenses; non-GAAP operating income; non-GAAP net income from continuing operations; earnings before interest and other, net, taxes, depreciation, and amortization (“EBITDA”); and adjusted EBITDA.

[0001571996-19-000008:mdna:58]
We use non-GAAP financial measures to supplement financial information presented on a GAAP basis.  We believe that excluding certain items from our GAAP results allows management to better understand our consolidated financial performance from period to period and better project our future consolidated financial performance as forecasts are developed at a level of detail different from that used to prepare GAAP-based financial measures.  Moreover, we believe these non-GAAP financial measures provide our stakeholders with useful information to help them evaluate our operating results by facilitating an enhanced understanding of our operating performance and enabling them to make more meaningful period to period comparisons.  There are limitations to the use of the non-GAAP financial measures presented in this report.  Our non-GAAP financial measures may not be comparable to similarly titled measures of other companies.  Other companies, including companies in our industry, may calculate non-GAAP financial measures differently than we do, limiting the usefulness of those measures for comparative purposes.

[0001571996-19-000008:mdna:59]
Non-GAAP product net revenue, non-GAAP services net revenue, non-GAAP net revenue, non-GAAP product gross margin, non-GAAP services gross margin, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, and non-GAAP net income from continuing operations, as defined by us, exclude amortization of intangible assets, the impact of purchase accounting, transaction-related expenses, other corporate expenses and, for non-GAAP net income from continuing operations, fair value adjustments on equity adjustments and an aggregate adjustment for income taxes.  As the excluded items have a material impact on our financial results, our management compensates for this limitation by relying primarily on our GAAP results and using non-GAAP financial measures supplementally or for projections when comparable GAAP financial measures are not available.  The non-GAAP financial measures are not meant to be considered as indicators of performance in isolation from or as a substitute for net revenue, gross margin, operating expenses, operating income, or net income prepared in accordance with GAAP, and should be read only in conjunction with financial information presented on a GAAP basis.

[0001571996-19-000008:mdna:60]
Reconciliations of each non-GAAP financial measure to its most directly comparable GAAP financial measure are presented below.  We encourage you to review the reconciliations in conjunction with the presentation of the non-GAAP financial measures for each of the periods presented.  The discussion below includes information on each of the excluded items as well as our reasons for excluding them from our non-GAAP results.  In future fiscal periods, we may exclude such items and may incur income and expenses similar to these excluded items.  Accordingly, the exclusion of these items and other similar items in our non-GAAP presentation should not be interpreted as implying that these items are non-recurring, infrequent, or unusual.

[0001571996-19-000008:mdna:61]
Dell Technologies’ non-GAAP net income from continuing operations now excludes, among other items, fair value adjustments on equity investments as well as discrete tax items.  These items were not excluded in the prior presentation of our non-GAAP net income from continuing operations.  Upon our return to the public markets in December 2018 as a result of the Class V transaction, we reevaluated the presentation of non-GAAP net income from continuing operations and made these changes to facilitate the evaluation of our current operating performance and the comparability of our current operating performance to our past operating performance.  Non-GAAP net income from continuing operations for prior periods has been recast to reflect the current presentation.  The following is a summary of the items excluded from the most comparable GAAP financial measures to calculate our non-GAAP financial measures:

[0001571996-19-000008:mdna:62]
| • | Amortization of Intangible Assets — Amortization of intangible assets primarily consists of amortization of customer relationships, developed technology, and trade names. In connection with the EMC merger transaction and the acquisition of Dell Inc. by Dell Technologies Inc. on October 29, 2013, referred to as the going-private transaction, all of the tangible and intangible assets and liabilities of EMC and Dell, respectively, were accounted for and recognized at fair value on the transaction dates. Accordingly, for the periods presented, amortization of intangible assets represents amortization associated with intangible assets recognized in connection with the EMC merger transaction and the going-private transaction. Amortization charges for purchased intangible assets are significantly impacted by the timing and magnitude of our acquisitions, and these charges may vary in amount from period to period. We exclude these charges for purposes of calculating the non-GAAP financial measures presented below to facilitate a more meaningful evaluation of our current operating performance and comparisons to our past operating performance. |

[0001571996-19-000008:mdna:63]
| • | Impact of Purchase Accounting — The impact of purchase accounting includes purchase accounting adjustments, related to the EMC merger transaction and, to a lesser extent, the going-private transaction, recorded under the acquisition method of accounting in accordance with the accounting guidance for business combinations. This guidance prescribes that the purchase price be allocated to assets acquired and liabilities assumed based on the estimated fair value of such assets and liabilities on the date of the transaction. Accordingly, all of the assets and liabilities acquired in the EMC merger transaction and the going-private transaction were accounted for and recognized at fair value as of the respective transaction dates, and the fair value adjustments are being amortized over the estimated useful lives in the periods following the transactions. The fair value adjustments primarily relate to deferred revenue, inventory, and property, plant, and equipment. The purchase accounting adjustments and related amortization of those adjustments are reflected in our GAAP results; however, we evaluate the operating results of the underlying businesses on a non-GAAP basis, after removing such adjustments. We believe that excluding the impact of purchase accounting provides results that are useful in understanding our current operating performance and provides more meaningful comparisons to our past operating performance. |

[0001571996-19-000008:mdna:64]
| • | Transaction-related Expenses — Transaction-related expenses consist of acquisition, integration, and divestiture related costs, as well as the costs incurred in the Class V transaction, and are expensed as incurred. These expenses primarily represent costs for legal, banking, consulting, and advisory services, as well as certain compensatory retention awards directly related to the EMC merger transaction. For Fiscal 2019, this category also included charges related to integration of our inventory policies and management process. During Fiscal 2019, we incurred approximately $316 million for the completion of the Class V transaction, expenses of approximately $116 million for customer evaluation units, and approximately $100 million for manufacturing and engineering inventory. During Fiscal 2017, transaction-related expenses included $0.8 billion in day one stock-based compensation charges primarily related to the acceleration of vesting of EMC equity awards and related taxes incurred in connection with the EMC merger transaction. |

[0001571996-19-000008:mdna:65]
| • | Other Corporate Expenses — Other corporate expenses consist of goodwill impairment charges, severance, facility action costs, and stock-based compensation expense associated with equity awards. In the third quarter of Fiscal 2019, we incurred a goodwill impairment charge of $190 million. See Note 8 of the Notes to the Consolidated Financial Statements for additional information about goodwill impairment testing. Severance costs are primarily related to severance and benefits for employees terminated pursuant to cost savings initiatives. Facility action costs were $22 million during Fiscal 2019, compared to $205 million during Fiscal 2018. We continue to integrate owned and leased facilities and may incur additional costs as we seek opportunities for operational efficiencies. Other corporate expenses vary from period to period and are significantly impacted by the timing and nature of these events. Therefore, although we may incur these types of expenses in the future, we believe that eliminating these charges for purposes of calculating the non-GAAP financial measures presented below facilitates a more meaningful evaluation of our current operating performance and comparisons to our past operating performance. |

[0001571996-19-000008:mdna:66]
| • | Fair Value Adjustments on Equity Investments — Fair value adjustments on equity investments primarily consists of the gain (loss) on strategic investments, which includes the recurring fair value adjustments of investments in publicly-traded companies, as well as those in privately-held companies, which are adjusted for observable price changes, and to a lesser extent any potential impairments. Given the volatility in the ongoing adjustments to the valuation of these strategic investments, we believe that excluding these charges for purposes of calculating non-GAAP net income from continuing operations presented below facilitates a more meaningful evaluation of our current operating performance and comparisons to our past operating performance. |

[0001571996-19-000008:mdna:67]
| • | Aggregate Adjustment for Income Taxes — The aggregate adjustment for income taxes is the estimated combined income tax effect for the adjustments described above, as well as an adjustment for discrete tax items. Due to the variability in recognition of discrete tax items from period to period, we believe that excluding these benefits or charges for purposes of calculating non-GAAP net income from continuing operations facilitates a more meaningful evaluation of our current operating performance and comparisons to our past operating performance. The tax effects are determined based on the tax jurisdictions where the above items were incurred. |

[0001571996-19-000008:mdna:68]
49

[0001571996-19-000008:mdna:69]
The table below presents a reconciliation of each non-GAAP financial measure to the most directly comparable GAAP measure for each of the periods presented:

[0001571996-19-000008:mdna:70]
|  | Fiscal Year Ended |
|  | February 1, 2019 |  | % Change |  | February 2, 2018 |  | % Change |  | February 3, 2017 |
|  | (in millions, except percentages) |
| Product net revenue | $ | 71,287 |  |  | 16 | % |  | $ | 61,251 |  |  | 20 | % |  | $ | 51,057 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 61 |  |  |  |  | 170 |  |  |  |  | 300 |  |
| Non-GAAP product net revenue | $ | 71,348 |  |  | 16 | % |  | $ | 61,421 |  |  | 20 | % |  | $ | 51,357 |  |
| Services net revenue | $ | 19,334 |  |  | 9 | % |  | $ | 17,789 |  |  | 60 | % |  | $ | 11,107 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 642 |  |  |  |  | 1,099 |  |  |  |  | 852 |  |
| Non-GAAP services net revenue | $ | 19,976 |  |  | 6 | % |  | $ | 18,888 |  |  | 58 | % |  | $ | 11,959 |  |
| Net revenue | $ | 90,621 |  |  | 15 | % |  | $ | 79,040 |  |  | 27 | % |  | $ | 62,164 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 703 |  |  |  |  | 1,269 |  |  |  |  | 1,152 |  |
| Non-GAAP net revenue | $ | 91,324 |  |  | 14 | % |  | $ | 80,309 |  |  | 27 | % |  | $ | 63,316 |  |
| Product gross margin | $ | 13,398 |  |  | 36 | % |  | $ | 9,818 |  |  | 28 | % |  | $ | 7,669 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 2,883 |  |  |  |  | 3,694 |  |  |  |  | 1,652 |  |
| Impact of purchase accounting | 78 |  |  |  |  | 213 |  |  |  |  | 1,104 |  |
| Transaction-related expenses | 210 |  |  |  |  | 11 |  |  |  |  | 24 |  |
| Other corporate expenses | 32 |  |  |  |  | 25 |  |  |  |  | 29 |  |
| Non-GAAP product gross margin | $ | 16,601 |  |  | 21 | % |  | $ | 13,761 |  |  | 31 | % |  | $ | 10,478 |  |
| Services gross margin | $ | 11,655 |  |  | 9 | % |  | $ | 10,719 |  |  | 79 | % |  | $ | 5,980 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | — |  |  |  |  | — |  |  |  |  | 1 |  |
| Impact of purchase accounting | 642 |  |  |  |  | 1,099 |  |  |  |  | 875 |  |
| Transaction-related expenses | 3 |  |  |  |  | 13 |  |  |  |  | 19 |  |
| Other corporate expenses | 121 |  |  |  |  | 76 |  |  |  |  | 128 |  |
| Non-GAAP services gross margin | $ | 12,421 |  |  | 4 | % |  | $ | 11,907 |  |  | 70 | % |  | $ | 7,003 |  |
| Gross margin | $ | 25,053 |  |  | 22 | % |  | $ | 20,537 |  |  | 50 | % |  | $ | 13,649 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 2,883 |  |  |  |  | 3,694 |  |  |  |  | 1,653 |  |
| Impact of purchase accounting | 720 |  |  |  |  | 1,312 |  |  |  |  | 1,979 |  |
| Transaction-related expenses | 213 |  |  |  |  | 24 |  |  |  |  | 43 |  |
| Other corporate expenses | 153 |  |  |  |  | 101 |  |  |  |  | 157 |  |
| Non-GAAP gross margin | $ | 29,022 |  |  | 13 | % |  | $ | 25,668 |  |  | 47 | % |  | $ | 17,481 |  |

[0001571996-19-000008:mdna:71]
50

[0001571996-19-000008:mdna:72]
|  | Fiscal Year Ended |
|  | February 1, 2019 |  | % Change |  | February 2, 2018 |  | % Change |  | February 3, 2017 |
|  | (in millions, except percentages) |
| Operating expenses | $ | 25,244 |  |  | 10 | % |  | $ | 22,953 |  |  | 43 | % |  | $ | 16,039 |  |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | (3,255 | ) |  |  |  | (3,286 | ) |  |  |  | (2,028 | ) |
| Impact of purchase accounting | (100 | ) |  |  |  | (234 | ) |  |  |  | (287 | ) |
| Transaction-related expenses | (537 | ) |  |  |  | (478 | ) |  |  |  | (1,445 | ) |
| Other corporate expenses | (1,184 | ) |  |  |  | (1,059 | ) |  |  |  | (745 | ) |
| Non-GAAP operating expenses | $ | 20,168 |  |  | 13 | % |  | $ | 17,896 |  |  | 55 | % |  | $ | 11,534 |  |
| Operating loss | $ | (191 | ) |  | 92 | % |  | $ | (2,416 | ) |  | (1 | )% |  | $ | (2,390 | ) |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 6,138 |  |  |  |  | 6,980 |  |  |  |  | 3,681 |  |
| Impact of purchase accounting | 820 |  |  |  |  | 1,546 |  |  |  |  | 2,266 |  |
| Transaction-related expenses | 750 |  |  |  |  | 502 |  |  |  |  | 1,488 |  |
| Other corporate expenses | 1,337 |  |  |  |  | 1,160 |  |  |  |  | 902 |  |
| Non-GAAP operating income | $ | 8,854 |  |  | 14 | % |  | $ | 7,772 |  |  | 31 | % |  | $ | 5,947 |  |
| Net loss from continuing operations | $ | (2,181 | ) |  | 25 | % |  | $ | (2,926 | ) |  | 5 | % |  | $ | (3,074 | ) |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 6,138 |  |  |  |  | 6,980 |  |  |  |  | 3,681 |  |
| Impact of purchase accounting | 820 |  |  |  |  | 1,546 |  |  |  |  | 2,266 |  |
| Transaction-related expenses | 824 |  |  |  |  | 502 |  |  |  |  | 1,485 |  |
| Other corporate expenses | 1,337 |  |  |  |  | 1,160 |  |  |  |  | 902 |  |
| Fair value adjustments on equity investments | (342 | ) |  |  |  | (72 | ) |  |  |  | (4 | ) |
| Aggregate adjustment for income taxes | (1,369 | ) |  |  |  | (2,835 | ) |  |  |  | (2,158 | ) |
| Non-GAAP net income from continuing operations (a) | $ | 5,227 |  |  | 20 | % |  | $ | 4,355 |  |  | 41 | % |  | $ | 3,098 |  |

[0001571996-19-000008:mdna:73]
_________________

[0001571996-19-000008:mdna:74]
(a) Non-GAAP net income from continuing operations has been recast to exclude fair value adjustments on equity investments, the corresponding tax effects of those adjustments, and discrete tax items.

[0001571996-19-000008:mdna:75]
In addition to the above measures, we also use EBITDA and adjusted EBITDA to provide additional information for evaluation of our operating performance.  Adjusted EBITDA excludes purchase accounting adjustments related to the EMC merger transaction and the going-private transaction, acquisition, integration, and divestiture related costs, costs incurred in the Class V transaction, goodwill impairment charges, severance and facility action costs, and stock-based compensation expense.  We believe that, due to the non-operational nature of the purchase accounting entries, it is appropriate to exclude these adjustments.

[0001571996-19-000008:mdna:76]
As is the case with the non-GAAP measures presented above, users should consider the limitations of using EBITDA and adjusted EBITDA, including the fact that those measures do not provide a complete measure of our operating performance.  EBITDA and adjusted EBITDA do not purport to be alternatives to net income (loss) as measures of operating performance or to cash flows from operating activities as a measure of liquidity.  In particular, EBITDA and adjusted EBITDA are not intended to be a measure of free cash flow available for management’s discretionary use, as these measures do not consider certain cash requirements, such as working capital needs, capital expenditures, contractual commitments, interest payments, tax payments, and other debt service requirements.

[0001571996-19-000008:mdna:77]
The table below presents a reconciliation of EBITDA and adjusted EBITDA to net loss from continuing operations for the periods presented:

[0001571996-19-000008:mdna:78]
|  | Fiscal Year Ended |
|  | February 1, 2019 |  | % Change |  | February 2, 2018 |  | % Change |  | February 3, 2017 |
|  | (in millions, except percentages) |
| Net loss from continuing operations | $ | (2,181 | ) |  | 25 | % |  | $ | (2,926 | ) |  | 5 | % |  | $ | (3,074 | ) |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Interest and other, net (a) | 2,170 |  |  |  |  | 2,353 |  |  |  |  | 2,104 |  |
| Income tax benefit | (180 | ) |  |  |  | (1,843 | ) |  |  |  | (1,420 | ) |
| Depreciation and amortization | 7,746 |  |  |  |  | 8,634 |  |  |  |  | 4,840 |  |
| EBITDA | $ | 7,555 |  |  | 22 | % |  | $ | 6,218 |  |  | 154 | % |  | $ | 2,450 |  |
| EBITDA | $ | 7,555 |  |  | 22 | % |  | $ | 6,218 |  |  | 154 | % |  | $ | 2,450 |  |
| Adjustments: |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense | 918 |  |  |  |  | 835 |  |  |  |  | 392 |  |
| Impact of purchase accounting (b) | 704 |  |  |  |  | 1,274 |  |  |  |  | 1,898 |  |
| Transaction-related expenses (c) | 722 |  |  |  |  | 502 |  |  |  |  | 1,525 |  |
| Other corporate expenses (d) | 397 |  |  |  |  | 305 |  |  |  |  | 510 |  |
| Adjusted EBITDA | $ | 10,296 |  |  | 13 | % |  | $ | 9,134 |  |  | 35 | % |  | $ | 6,775 |  |

[0001571996-19-000008:mdna:79]
____________________

[0001571996-19-000008:mdna:80]
| (a) | See “Results of Operations — Interest and Other, Net” for more information on the components of interest and other, net. |

[0001571996-19-000008:mdna:81]
| (b) | This amount includes the non-cash purchase accounting adjustments related to the EMC merger transaction and the going-private transaction. |

[0001571996-19-000008:mdna:82]
| (c) | Transaction-related expenses consist of acquisition, integration, and divestiture related costs, as well as the costs incurred in the Class V transaction. |

[0001571996-19-000008:mdna:83]
| (d) | Consists of goodwill impairment charges, severance, and facility action costs. |

[0001571996-19-000008:mdna:84]
52

[0001571996-19-000008:mdna:85]
RESULTS OF OPERATIONS

[0001571996-19-000008:mdna:86]
Consolidated Results

[0001571996-19-000008:mdna:87]
The following table summarizes our consolidated results from continuing operations for each of the periods presented.  Unless otherwise indicated, all changes identified for the current period results represent comparisons to results for the prior corresponding fiscal period.  Multiple accounting standards were adopted during the first quarter of Fiscal 2019, which resulted in adjustment or reclassification of amounts previously reported.  See Note 2 of the Notes to the Consolidated Financial Statements included in this report for further information regarding our recently adopted accounting standards.

[0001571996-19-000008:mdna:88]
|  | Fiscal Year Ended |
|  | February 1, 2019 |  |  |  | February 2, 2018 |  |  |  | February 3, 2017 |
|  | Dollars |  | % ofNet Revenue |  | %Change |  | Dollars |  | % ofNet Revenue |  | %Change |  | Dollars |  | % ofNet Revenue |
|  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 71,287 |  |  | 78.7 | % |  | 16 | % |  | $ | 61,251 |  |  | 77.5 | % |  | 20 | % |  | $ | 51,057 |  |  | 82.1 | % |
| Services | 19,334 |  |  | 21.3 | % |  | 9 | % |  | 17,789 |  |  | 22.5 | % |  | 60 | % |  | 11,107 |  |  | 17.9 | % |
| Total net revenue | $ | 90,621 |  |  | 100.0 | % |  | 15 | % |  | $ | 79,040 |  |  | 100.0 | % |  | 27 | % |  | $ | 62,164 |  |  | 100.0 | % |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product (a) | $ | 13,398 |  |  | 18.8 | % |  | 36 | % |  | $ | 9,818 |  |  | 16.0 | % |  | 28 | % |  | $ | 7,669 |  |  | 15.0 | % |
| Services (b) | 11,655 |  |  | 60.3 | % |  | 9 | % |  | 10,719 |  |  | 60.3 | % |  | 79 | % |  | 5,980 |  |  | 53.8 | % |
| Total gross margin | $ | 25,053 |  |  | 27.6 | % |  | 22 | % |  | $ | 20,537 |  |  | 26.0 | % |  | 50 | % |  | $ | 13,649 |  |  | 22.0 | % |
| Operating expenses | $ | 25,244 |  |  | 27.8 | % |  | 10 | % |  | $ | 22,953 |  |  | 29.0 | % |  | 43 | % |  | $ | 16,039 |  |  | 25.8 | % |
| Operating loss | $ | (191 | ) |  | (0.2 | )% |  | 92 | % |  | $ | (2,416 | ) |  | (3.1 | )% |  | (1 | )% |  | $ | (2,390 | ) |  | (3.8 | )% |
| Net loss from continuing operations | $ | (2,181 | ) |  | (2.4 | )% |  | 25 | % |  | $ | (2,926 | ) |  | (3.7 | )% |  | 5 | % |  | $ | (3,074 | ) |  | (4.9 | )% |
| Net loss attributable to Dell Technologies Inc. | $ | (2,310 | ) |  | (2.5 | )% |  | 19 | % |  | $ | (2,849 | ) |  | (3.6 | )% |  | (144 | )% |  | $ | (1,167 | ) |  | (1.9 | )% |
| Non-GAAP Financial Information |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP net revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 71,348 |  |  | 78.1 | % |  | 16 | % |  | $ | 61,421 |  |  | 76.5 | % |  | 20 | % |  | $ | 51,357 |  |  | 81.1 | % |
| Services | 19,976 |  |  | 21.9 | % |  | 6 | % |  | 18,888 |  |  | 23.5 | % |  | 58 | % |  | 11,959 |  |  | 18.9 | % |
| Total non-GAAP net revenue | $ | 91,324 |  |  | 100.0 | % |  | 14 | % |  | $ | 80,309 |  |  | 100.0 | % |  | 27 | % |  | $ | 63,316 |  |  | 100.0 | % |
| Non-GAAP gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product (a) | $ | 16,601 |  |  | 23.3 | % |  | 21 | % |  | $ | 13,761 |  |  | 22.4 | % |  | 31 | % |  | $ | 10,478 |  |  | 20.4 | % |
| Services (b) | 12,421 |  |  | 62.2 | % |  | 4 | % |  | 11,907 |  |  | 63.0 | % |  | 70 | % |  | 7,003 |  |  | 58.6 | % |
| Total non-GAAP gross margin | $ | 29,022 |  |  | 31.8 | % |  | 13 | % |  | $ | 25,668 |  |  | 32.0 | % |  | 47 | % |  | $ | 17,481 |  |  | 27.6 | % |
| Non-GAAP operating expenses | $ | 20,168 |  |  | 22.1 | % |  | 13 | % |  | $ | 17,896 |  |  | 22.3 | % |  | 55 | % |  | $ | 11,534 |  |  | 18.2 | % |
| Non-GAAP operating income | $ | 8,854 |  |  | 9.7 | % |  | 14 | % |  | $ | 7,772 |  |  | 9.7 | % |  | 31 | % |  | $ | 5,947 |  |  | 9.4 | % |
| Non-GAAP net income from continuing operations (c) | $ | 5,227 |  |  | 5.7 | % |  | 20 | % |  | $ | 4,355 |  |  | 5.4 | % |  | 41 | % |  | $ | 3,098 |  |  | 4.9 | % |
| EBITDA | $ | 7,555 |  |  | 8.3 | % |  | 22 | % |  | $ | 6,218 |  |  | 7.7 | % |  | 154 | % |  | $ | 2,450 |  |  | 3.9 | % |
| Adjusted EBITDA | $ | 10,296 |  |  | 11.3 | % |  | 13 | % |  | $ | 9,134 |  |  | 11.4 | % |  | 35 | % |  | $ | 6,775 |  |  | 10.7 | % |

[0001571996-19-000008:mdna:89]
____________________

[0001571996-19-000008:mdna:90]
| (a) | Product gross margin percentages represent product gross margin as a percentage of product net revenue, and non-GAAP product gross margin percentages represent non-GAAP product gross margin as a percentage of non-GAAP product net revenue. |

[0001571996-19-000008:mdna:91]
| (b) | Services gross margin percentages represent services gross margin as a percentage of services net revenue, and non-GAAP services gross margin percentages represent non-GAAP services gross margin as a percentage of non-GAAP services net revenue. |

[0001571996-19-000008:mdna:92]
| (c) | Non-GAAP net income from continuing operations has been recast to exclude fair value adjustments on equity investments, the corresponding tax effects of those adjustments, and discrete tax items. |

[0001571996-19-000008:mdna:93]
Non-GAAP product net revenue, non-GAAP services net revenue, non-GAAP net revenue, non-GAAP product gross margin, non-GAAP services gross margin, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income from continuing operations, EBITDA, and adjusted EBITDA are not measurements of financial performance prepared in accordance with GAAP.  Non-GAAP financial measures as a percentage of revenue are calculated based on non-GAAP net revenue.  See “Non‑GAAP Financial Measures” for additional information about these non-GAAP financial measures, including our reasons for including these measures, material limitations with respect to the usefulness of the measures, and a reconciliation of each non-GAAP financial measure to the most directly comparable GAAP financial measure.

[0001571996-19-000008:mdna:94]
As a result of the EMC merger transaction completed on September 7, 2016 and its impact on Fiscal 2017 results, our results for the comparison of Fiscal 2018 and Fiscal 2017 discussed below are not directly comparable.

[0001571996-19-000008:mdna:95]
Overview

[0001571996-19-000008:mdna:96]
The strong global macroeconomic environment throughout Fiscal 2019 has generated robust demand for our products.  We believe we are well-positioned to meet this demand with complementary solutions across our strategically aligned family of businesses.  During Fiscal 2019, our net revenue and non-GAAP net revenue increased 15% and 14%, respectively.  The increases in net revenue and non-GAAP net revenue were attributable to increases in net revenue across all three business units.  The momentum in server, client, and VMware that started building last year has continued in Fiscal 2019, and we are seeing progress in the growth of our storage business revenue.

[0001571996-19-000008:mdna:97]
During Fiscal 2019 and Fiscal 2018, our operating loss was $191 million and $2.4 billion, respectively.  The decrease in our operating loss for Fiscal 2019 was primarily attributable to a decrease in amortization of intangible assets and purchase accounting adjustments related to the EMC merger transaction and an increase in operating income for ISG, and, to a lesser extent, VMware.

[0001571996-19-000008:mdna:98]
Amortization of intangible assets and purchase accounting adjustments that impacted operating income totaled $7.0 billion and $8.5 billion for Fiscal 2019 and Fiscal 2018, respectively.  Excluding these costs, transaction-related expenses, and other corporate expenses, non-GAAP operating income increased 14% to $8.9 billion during Fiscal 2019.  The increase in non-GAAP operating income for Fiscal 2019 was primarily due to an increase in operating income for ISG and, to a lesser extent, VMware.

[0001571996-19-000008:mdna:99]
Cash provided by operating activities was $7.0 billion and $6.8 billion during Fiscal 2019 and Fiscal 2018, respectively.  The increase in operating cash flows during Fiscal 2019 was driven by business momentum, improved profitability, and an increase in deferred revenue.  See “Market Conditions, Liquidity, Capital Commitments, and Contractual Cash Obligations” for further information on our cash flow metrics.

[0001571996-19-000008:mdna:100]
Net Revenue

[0001571996-19-000008:mdna:101]
Fiscal 2019 compared to Fiscal 2018

[0001571996-19-000008:mdna:102]
During Fiscal 2019, our net revenue and non-GAAP net revenue increased 15% and 14%, respectively.  The increases in net revenue and non-GAAP net revenue were attributable to increases in net revenue across all three business units.  See “Business Unit Results” for further information.

[0001571996-19-000008:mdna:103]
| • | Product Net Revenue — Product net revenue includes revenue from the sale of hardware products and software licenses. During Fiscal 2019, both product net revenue and non-GAAP product net revenue increased 16%. These increases were attributable to an increase in product revenue across all three business units, driven by strength in sales across all product categories. |

[0001571996-19-000008:mdna:104]
| • | Services Net Revenue — Services net revenue includes revenue from our services offerings and support services related to hardware products and software licenses. During Fiscal 2019, services net revenue and non-GAAP services net revenue increased 9% and 6%, respectively. These increases were primarily due to an increase in services revenue for hardware support and deployment and software maintenance due to growth in the business. A portion of services net revenue is derived from offerings that have been deferred over a period of time, and, as a result, reported services net revenue growth rates will be different than product net revenue growth rates. |

[0001571996-19-000008:mdna:105]
From a geographical perspective, net revenue generated by sales to customers in all regions increased in Fiscal 2019 due to strong performance globally in all three business units.

[0001571996-19-000008:mdna:106]
Fiscal 2018 compared to Fiscal 2017

[0001571996-19-000008:mdna:107]
During Fiscal 2018, our net revenue and non-GAAP net revenue both increased 27%, primarily due to the incremental net revenue from the EMC acquired businesses and, to a lesser extent, an increase in CSG net revenue.  See “Business Unit Results” for further information.

[0001571996-19-000008:mdna:108]
| • | Product Net Revenue — During Fiscal 2018, product net revenue and non-GAAP product net revenue both increased 20%, primarily due to the incremental product net revenue from the EMC acquired businesses and, to a lesser extent, an increase in CSG product net revenue. The increases in product net revenue and non-GAAP product net revenue during Fiscal 2018 were driven by strength in sales of notebooks, workstations, servers, and VMware license revenue. |

[0001571996-19-000008:mdna:109]
| • | Services Net Revenue — During Fiscal 2018, services net revenue and non-GAAP services net revenue increased 60% and 58%, respectively. These increases were primarily due to the incremental services net revenue from the EMC acquired businesses. |

[0001571996-19-000008:mdna:110]
From a geographical perspective, net revenue generated by sales to customers in all regions increased in Fiscal 2018 primarily as a result of the incremental net revenue from the EMC acquired businesses.  Our mix of revenues generated in the Americas, EMEA, and APJ did not change substantially as a result of the EMC merger transaction.

[0001571996-19-000008:mdna:111]
Gross Margin

[0001571996-19-000008:mdna:112]
Fiscal 2019 compared to Fiscal 2018

[0001571996-19-000008:mdna:113]
During Fiscal 2019, our gross margin increased 22% to $25.1 billion, and our gross margin percentage increased 160 basis points to 27.6%.  The increase in our gross margin percentage during Fiscal 2019 was primarily attributable to a decrease in amortization of intangibles and purchase accounting adjustments, offset partially by gross margin rate pressure in CSG and product mix dynamics in ISG due to growth in sales of servers, which typically have a lower gross margin than storage products.

[0001571996-19-000008:mdna:114]
Our gross margin for Fiscal 2019 and Fiscal 2018 included the impact of amortization of intangibles and purchase accounting adjustments of $3.6 billion and $5.0 billion, respectively.  Excluding these costs, transaction-related expenses, and other corporate expenses, non-GAAP gross margin for Fiscal 2019 increased 13% to $29.0 billion, and non-GAAP gross margin percentage decreased 20 basis points to 31.8%.  The increase in our non-GAAP gross margin was attributable to increases in gross margin across all three business units.  The decrease in our non-GAAP gross margin percentage was primarily due to product mix dynamics in ISG due to growth in sales of servers and gross margin rate pressure in CSG.

[0001571996-19-000008:mdna:115]
| • | Products — During Fiscal 2019, product gross margin increased 36% to $13.4 billion, and product gross margin percentage increased 280 basis points to 18.8%. The increases in both product gross margin and product gross margin percentage were primarily attributable to a decrease in amortization of intangibles and purchase accounting adjustments. During Fiscal 2019, non-GAAP product gross margin increased 21% to $16.6 billion, and non-GAAP product gross margin percentage increased 90 basis points to 23.3%. The increases in product gross margin and non-GAAP product gross margin were driven primarily by increases in product revenue in all three business units due to strength in sales of ISG servers and storage, CSG commercial products, and VMware software licenses. Product gross margin percentage and non-GAAP product gross margin percentage increased primarily as a result of higher product gross margin percentages for ISG and VMware. |

[0001571996-19-000008:mdna:116]
Our gross margins include benefits relating primarily to settlements from certain vendors regarding their past pricing practices.  During Fiscal 2018, we entered into a settlement agreement with a vendor to resolve a dispute regarding past pricing practices.  Vendor settlements are allocated to our segments based on the relative amount of affected vendor products sold by each segment.  Our gross margin for Fiscal 2018 included a benefit of $68 million related to receipt of payment under the settlement, which was entirely allocated to CSG.

[0001571996-19-000008:mdna:117]
55

[0001571996-19-000008:mdna:118]
| • | Services — During Fiscal 2019, services gross margin increased 9% to $11.7 billion, and services gross margin percentage was consistent at 60.3%. Services gross margin increased due to growth in services gross margin in CSG and VMware, particularly in hardware support and deployment and software maintenance. During Fiscal 2019 and Fiscal 2018, services gross margin also benefited from a decrease in purchase accounting adjustments, which totaled $0.6 billion and $1.1 billion, respectively. Excluding these costs, transaction-related expenses, and other corporate expenses, non-GAAP services gross margin increased 4% to $12.4 billion, and non-GAAP services gross margin percentage decreased 80 basis points to 62.2%. Services gross margin percentage decreased primarily due to lower services gross margin percentages in all three business units. |

[0001571996-19-000008:mdna:119]
Fiscal 2018 compared to Fiscal 2017

[0001571996-19-000008:mdna:120]
During Fiscal 2018, our gross margin increased 50% to $20.5 billion, and our gross margin percentage increased 400 basis points to 26.0%.  The increases in our gross margin and gross margin percentage were primarily attributable to incremental gross margin from the EMC acquired businesses, which have higher gross margin percentages.  The effect of the higher gross margin and gross margin percentage was partially offset by the combined impact of amortization of intangibles and purchase accounting adjustments as a result of the EMC merger transaction.

[0001571996-19-000008:mdna:121]
Our gross margin for the Fiscal 2018 and Fiscal 2017 included the effect of amortization of intangibles and purchase accounting adjustments related to the EMC merger transaction and, to a lesser extent, the going-private transaction, of $5.0 billion and $3.6 billion, respectively.  Excluding these costs, transaction-related expenses, and other corporate expenses, total non-GAAP gross margin for Fiscal 2018 increased 47% to $25.7 billion and non-GAAP gross margin percentage increased 440 basis points to 32.0%.  The increase in non-GAAP gross margin and non-GAAP gross margin percentage was primarily attributable to incremental gross margin from the EMC acquired businesses.

[0001571996-19-000008:mdna:122]
| • | Products — During Fiscal 2018, product gross margin increased 28% to $9.8 billion, and product gross margin percentage increased 100 basis points to 16.0%. These increases in product gross margin and product gross margin percentage were driven primarily by additional product gross margin from the EMC acquired businesses, which was partially offset by an increase in amortization of intangibles related to the EMC merger transaction, and to a lesser extent, component cost pressures in CSG and ISG. |

[0001571996-19-000008:mdna:123]
During Fiscal 2018, non-GAAP product gross margin increased 31% to $13.8 billion, and non-GAAP product gross margin percentage increased 200 basis points to 22.4%.  The increase in non-GAAP product gross margin from the EMC acquired businesses was partially offset by component cost pressures in CSG and ISG.  Gross margin strengthened throughout Fiscal 2018 as we managed our pricing in response to the cost environment during the period.

[0001571996-19-000008:mdna:124]
Our gross margins included benefits related to receipts under vendor settlements of $68 million and $80 million for Fiscal 2018 and Fiscal 2017, respectively.  These benefits were entirely allocated to CSG.

[0001571996-19-000008:mdna:125]
| • | Services — During Fiscal 2018, services gross margin increased 79% to 10.7 billion, and services gross margin percentage increased 650 basis points to 60.3%. During Fiscal 2018, non-GAAP services gross margin increased 70% to $11.9 billion, and non-GAAP services gross margin percentage increased 440 basis points to 63.0%. These increases were primarily attributable to the incremental services gross margin from the EMC acquired businesses. |

[0001571996-19-000008:mdna:126]
Vendor Programs and Settlements

[0001571996-19-000008:mdna:127]
Our gross margin is affected by our ability to achieve competitive pricing with our vendors and contract manufacturers, including through our negotiation of a variety of vendor rebate programs to achieve lower net costs for the various components we include in our products.  Under these programs, vendors provide us with rebates or other discounts from the list prices for the components, which are generally elements of their pricing strategy.  We account for vendor rebates and other discounts as a reduction in cost of net revenue.  We manage our costs on a total net cost basis, which includes supplier list prices reduced by vendor rebates and other discounts.

[0001571996-19-000008:mdna:128]
The terms and conditions of our vendor rebate programs are largely based on product volumes and are generally negotiated either at the beginning of the annual or quarterly period, depending on the program.  The timing and amount of vendor rebates and other discounts we receive under the programs may vary from period to period, reflecting changes in the competitive environment.  We monitor our component costs and seek to address the effects of any changes to terms that might arise under our vendor rebate programs.  Our gross margins for Fiscal 2019 and Fiscal 2018 were not materially affected by any changes to the terms of our vendor rebate programs, as the amounts we received under these programs were generally stable relative to our total net cost.  We are not aware of any significant changes to vendor pricing or rebate programs that may impact our results in the near term.

[0001571996-19-000008:mdna:129]
In addition, we have pursued legal action against certain vendors and are currently involved in negotiations with other vendors regarding their past pricing practices.  We have negotiated settlements with some of these vendors and may have additional settlements in future periods.  These settlements are allocated to our segments based on the relative amount of affected vendor products sold by each segment.  No such settlements were recorded in Fiscal 2019 that would have a material impact on product gross margins or affect comparability with product gross margin in Fiscal 2018.  Pricing settlements benefited product gross margins in Fiscal 2018 and Fiscal 2017 by $68 million, and $80 million, respectively.

[0001571996-19-000008:mdna:130]
Operating Expenses

[0001571996-19-000008:mdna:131]
The following table presents information regarding our operating expenses during each of the periods presented:

[0001571996-19-000008:mdna:132]
|  | Fiscal Year Ended |
|  | February 1, 2019 |  |  |  | February 2, 2018 |  |  |  | February 3, 2017 |
|  | Dollars |  | % ofNet Revenue |  | %Change |  | Dollars |  | % ofNet Revenue |  | %Change |  | Dollars |  | % ofNet Revenue |
|  | (in millions, except percentages) |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative | $ | 20,640 |  |  | 22.7 | % |  | 11 | % |  | $ | 18,569 |  |  | 23.6 | % |  | 39 | % |  | $ | 13,403 |  |  | 21.6 | % |
| Research and development | 4,604 |  |  | 5.1 | % |  | 5 | % |  | 4,384 |  |  | 5.5 | % |  | 66 | % |  | 2,636 |  |  | 4.2 | % |
| Total operating expenses | $ | 25,244 |  |  | 27.8 | % |  | 10 | % |  | $ | 22,953 |  |  | 29.1 | % |  | 43 | % |  | $ | 16,039 |  |  | 25.8 | % |
| Other Financial Information |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Non-GAAP operating expenses | $ | 20,168 |  |  | 22.1 | % |  | 13 | % |  | $ | 17,896 |  |  | 22.3 | % |  | 55 | % |  | $ | 11,534 |  |  | 18.2 | % |

[0001571996-19-000008:mdna:133]
Fiscal 2019 compared to Fiscal 2018

[0001571996-19-000008:mdna:134]
During Fiscal 2019, total operating expenses increased 10%.  Our operating expenses include the impact of purchase accounting, amortization of intangible assets, transaction-related expenses, and other corporate expenses.  Other corporate expenses included a goodwill impairment charge of approximately $190 million recorded during Fiscal 2019.  In aggregate, these items totaled $5.1 billion for both Fiscal 2019 and Fiscal 2018.  Excluding these costs, total non-GAAP operating expenses for Fiscal 2019 increased 13%.  The increases in operating expenses and non-GAAP operating expenses were primarily due to an increase in selling, general, and administrative expenses associated with our revenue growth and sales headcount.

[0001571996-19-000008:mdna:135]
| • | Selling, General, and Administrative — Selling, general, and administrative (“SG&A”) expenses increased 11% during Fiscal 2019. The increases in SG&A expenses were primarily driven by investments in our go-to-market capabilities, including sales headcount, and higher performance-based compensation and commission costs, as well as a goodwill impairment charge of approximately $190 million recorded during the third quarter of Fiscal 2019. |

[0001571996-19-000008:mdna:136]
| • | Research and Development — Research and development (“R&D”) expenses are primarily composed of personnel-related expenses related to product development. R&D expenses as a percentage of net revenue for Fiscal 2019 and Fiscal 2018 were approximately 5.1% and 5.5%, respectively. The decreases in R&D expenses as a percentage of net revenue were attributable to revenue growth that outpaced the scale of R&D investments. As our industry continues to change and as the needs of our customers evolve, we intend to support R&D initiatives to innovate and introduce new and enhanced solutions into the market. |

[0001571996-19-000008:mdna:137]
We continue to make investments designed to enable growth, particularly in our sales force, marketing, and R&D, while balancing our efforts to drive cost efficiencies in the business.  We also expect to continue to make investments in support of our own digital transformation to modernize and streamline our IT operations.

[0001571996-19-000008:mdna:138]
Fiscal 2018 compared to Fiscal 2017

[0001571996-19-000008:mdna:139]
During Fiscal 2018, total operating expenses increased 43%.  Our operating expenses during Fiscal 2018 and Fiscal 2017 included the impact of purchase accounting associated with the EMC merger transaction and, to a lesser extent, the going-private transaction, amortization of intangible assets, transaction-related expenses, and other corporate expenses.  In aggregate, these items totaled $5.1 billion and $4.5 billion for Fiscal 2018 and Fiscal 2017, respectively.  Excluding these costs, total non-GAAP operating expenses increased 55%.  The increases in operating expenses and non-GAAP operating expenses were primarily due to the incremental operating costs from the EMC acquired businesses.

[0001571996-19-000008:mdna:140]
| • | Selling, General, and Administrative — SG&A expenses increased 39% during Fiscal 2018. The increases in SG&A expenses were primarily driven by incremental operating costs of the EMC acquired businesses. |

[0001571996-19-000008:mdna:141]
| • | Research and Development — R&D expenses as a percentage of net revenue for Fiscal 2018 and Fiscal 2017 were approximately 5.5% and 4.2%, respectively. The increase in R&D expenses was attributable to the expansion of our R&D capability through the EMC merger transaction. |

[0001571996-19-000008:mdna:142]
Operating Income/Loss

[0001571996-19-000008:mdna:143]
Fiscal 2019 compared to Fiscal 2018

[0001571996-19-000008:mdna:144]
During Fiscal 2019, our operating loss decreased 92% to $191 million.  The decrease in our operating loss for Fiscal 2019 was primarily attributable to a decrease in amortization of intangible assets and purchase accounting adjustments and an increase in operating income for ISG, and to a lesser extent, VMware.

[0001571996-19-000008:mdna:145]
Amortization of intangible assets and purchase accounting adjustments that impacted operating income totaled $7.0 billion and $8.5 billion for Fiscal 2019 and Fiscal 2018, respectively.  Excluding these costs, transaction-related expenses, and other corporate expenses, non-GAAP operating income increased 14% to $8.9 billion during Fiscal 2019.  The increase in non-GAAP operating income for Fiscal 2019 was primarily due to an increase in operating income for ISG, and to a lesser extent, VMware.

[0001571996-19-000008:mdna:146]
Fiscal 2018 compared to Fiscal 2017

[0001571996-19-000008:mdna:147]
Our operating loss increased 1% during Fiscal 2018, primarily due to higher operating expenses from the EMC acquired businesses as well as an increase in amortization of intangibles related to the EMC merger transaction, the effects of which were mostly offset by an increase in gross margin.  While the EMC acquired businesses contributed higher gross margin overall, we experienced gross margin pressure in ISG related to the changing product mix within ISG as well as component cost inflation, particularly for memory components used in ISG products.

[0001571996-19-000008:mdna:148]
Our operating loss includes the impact of purchase accounting associated with the EMC merger transaction and, to a lesser extent, the going-private transaction, amortization of intangible assets, transaction-related expenses, and other corporate expenses.  In aggregate, these items totaled $10.2 billion and $8.3 billion for Fiscal 2018 and Fiscal 2017, respectively.  Excluding these costs, non-GAAP operating income for Fiscal 2018 increased 31% to $7.8 billion.  The increase in non-GAAP operating income for Fiscal 2018 was attributable to an increase in operating income for VMware and CSG.

[0001571996-19-000008:mdna:149]
58

[0001571996-19-000008:mdna:150]
Interest and Other, Net

[0001571996-19-000008:mdna:151]
The following table provides information regarding interest and other, net for each of the periods presented:

[0001571996-19-000008:mdna:152]
|  | Fiscal Year Ended |
|  | February 1, 2019 |  | February 2, 2018 |  | February 3, 2017 |
|  | (in millions) |
| Interest and other, net: |  |  |  |  |  |  |  |
| Investment income, primarily interest | $ | 313 |  |  | $ | 207 |  |  | $ | 102 |  |
| Gain (loss) on investments, net | 342 |  |  | 72 |  |  | 4 |  |
| Interest expense | (2,488 | ) |  | (2,406 | ) |  | (1,751 | ) |
| Foreign exchange | (206 | ) |  | (113 | ) |  | (77 | ) |
| Debt extinguishment | — |  |  | — |  |  | (337 | ) |
| Other | (131 | ) |  | (113 | ) |  | (45 | ) |
| Total interest and other, net | $ | (2,170 | ) |  | $ | (2,353 | ) |  | $ | (2,104 | ) |

[0001571996-19-000008:mdna:153]
Fiscal 2019 compared to Fiscal 2018

[0001571996-19-000008:mdna:154]
Effective in the first quarter of Fiscal 2019, we adopted the new accounting guidance for “Recognition and Measurement of Financial Assets and Financial Liabilities.”  As a result, we record in interest and other, net changes in the fair value of our publicly-traded strategic investments and changes in the value of our strategic investments without readily determinable fair values when adjusted to fair value upon observable price changes or impairment.  During Fiscal 2019, the change in interest and other, net was favorable by $183 million, primarily due to gains on strategic investments.  To fund a portion of the cash consideration paid in the Class V transaction, we incurred additional debt and liquidated a significant amount of our investments.  As a result, we expect higher interest expense and lower investment income in Fiscal 2020.  See Note 2 and Note 4 of the Notes to the Consolidated Financial Statements included in this report for further information regarding our recently adopted accounting standards and our investments, respectively.

[0001571996-19-000008:mdna:155]
Fiscal 2018 compared to Fiscal 2017

[0001571996-19-000008:mdna:156]
During Fiscal 2018, changes in interest and other, net were unfavorable by $249 million primarily due to an increase in interest expense from new borrowings associated with the EMC merger transaction.  This change was partially offset by other expenses incurred in Fiscal 2017, which included approximately $337 million related to debt extinguishment and new borrowings that did not recur in Fiscal 2018.

[0001571996-19-000008:mdna:157]
Income and Other Taxes

[0001571996-19-000008:mdna:158]
Our effective income tax rates were 7.6%, 38.6%, and 31.6% on pre-tax losses of $2.4 billion, $4.8 billion, and $4.5 billion for Fiscal 2019, Fiscal 2018, and Fiscal 2017, respectively.  The change in our effective income tax rate for Fiscal 2019 as compared to Fiscal 2018 was primarily attributable to impacts of the Tax Cuts and Jobs Act of 2017 (“U.S. Tax Reform”), which reduced our overall tax benefits as a percentage of pre-tax losses.  These impacts were offset in part by discrete tax benefits of $154 million resulting from the effect of our adoption of the new revenue standard under ASC 606.  The change in our effective income tax rate for Fiscal 2018 as compared to Fiscal 2017 was primarily attributable to tax benefits from charges incurred associated with the EMC merger transaction, including purchase accounting adjustments, interest charges, and stock-based compensation expense.  The change in our effective income tax rate was also impacted by tax benefits recognized in Fiscal 2018 related to U.S. Tax Reform, as well as by $201 million of tax charges recognized in Fiscal 2017 related to the divestiture of Dell Services and DSG.

[0001571996-19-000008:mdna:159]
U.S. Tax Reform was signed into law on December 22, 2017.  U.S. Tax Reform lowers the U.S. corporate income tax rate to 21% from 35%, establishes a modified territorial system requiring a mandatory deemed repatriation tax on undistributed earnings of foreign subsidiaries (the “Transition Tax”), requires a minimum tax on certain future earnings generated by foreign subsidiaries while providing for future tax-free repatriation of earnings through a 100% dividends-received deduction, and places limitations on the deductibility of net interest expense.

[0001571996-19-000008:mdna:160]
GAAP requires the effect of a change in tax laws to be recognized in the period that includes the enactment date.  Accordingly, for Fiscal 2018 we recognized a provisional tax benefit of $0.5 billion related to U.S. Tax Reform, primarily driven by a $1.5 billion tax benefit related to the remeasurement of deferred tax assets and liabilities, offset by $1.0 billion of current and future income tax expenses related to the Transition Tax.  We completed our accounting for the income tax effects of U.S. Tax Reform during the fourth quarter of Fiscal 2019 and determined that the adjustment to the provisional estimate was not material.  Throughout Fiscal 2019, the U.S. Department of the Treasury and the Internal Revenue Service issued preliminary regulatory guidance clarifying certain provisions of U.S. Tax Reform, and we anticipate that additional regulatory guidance and technical clarifications will be issued.  When additional guidance is issued, we will recognize the related tax impact in the fiscal quarter of such issuance.

[0001571996-19-000008:mdna:161]
Our effective income tax rate can fluctuate depending on the geographic distribution of our worldwide earnings, as our foreign earnings are generally taxed at lower rates than in the United States.  The differences between our effective income tax rate and the U.S. federal statutory rate of 21% principally result from the geographical distribution of income and differences between the book and tax treatment of certain items.  In certain jurisdictions, our tax rate is significantly less than the applicable statutory rate as a result of tax holidays.  The majority of our foreign income that is subject to these tax holidays and lower tax rates is attributable to Singapore, China, and Malaysia.  Although a significant portion of these income tax benefits relates to a tax holiday that expired during Fiscal 2019, we have negotiated new terms for the affected subsidiary.  These new terms provide for a reduced income tax rate and will be effective until January 31, 2029.  Our other tax holidays will expire in whole or in part during Fiscal 2022 through Fiscal 2030.  Many of these tax holidays and reduced tax rates may be extended when certain conditions are met or may be terminated early if certain conditions are not met.

[0001571996-19-000008:mdna:162]
For further discussion regarding tax matters, including the status of income tax audits, see Note 11 of the Notes to the Consolidated Financial Statements included in this report.

[0001571996-19-000008:mdna:163]
Net Income/Loss from Continuing Operations

[0001571996-19-000008:mdna:164]
Fiscal 2019 compared to Fiscal 2018

[0001571996-19-000008:mdna:165]
During Fiscal 2019, net loss from continuing operations decreased 25% to $2.2 billion.  The decrease in net loss from continuing operations during Fiscal 2019 was primarily attributable to a decrease in operating loss and, to a lesser extent, a decrease in interest and other, net expense, which was partially offset by a decrease in tax benefit.

[0001571996-19-000008:mdna:166]
Net loss for Fiscal 2019 included amortization of intangible assets, the impact of purchase accounting, transaction-related expenses, other corporate expenses, fair value adjustments on equity investments, and discrete tax items.  Excluding these costs and the related tax impacts, non-GAAP net income from continuing operations increased 20% to $5.2 billion during Fiscal 2019.  The increase in non-GAAP net income from continuing operations during Fiscal 2019 was primarily attributable to an increase in operating income and a decrease in interest and other, net expense, which was partially offset by an increase in income tax expense.

[0001571996-19-000008:mdna:167]
Fiscal 2018 compared to Fiscal 2017

[0001571996-19-000008:mdna:168]
During Fiscal 2018, net loss from continuing operations decreased 5% to a net loss from continuing operations of $2.9 billion.  The decrease in net loss from continuing operations during Fiscal 2018 was primarily attributable to an increase in tax benefit, partially offset by an increase in operating loss and to an increase in interest and other, net expense.  Net loss from continuing operations for Fiscal 2018 included amortization of intangible assets, the impact of purchase accounting, transaction-related expenses, other corporate expenses, fair value adjustments on equity investments, and discrete tax items.  Excluding these costs and the related tax impacts, non-GAAP net income from continuing operations increased 41% to $4.4 billion during Fiscal 2018.  The increase in non-GAAP net income from continuing operations during Fiscal 2018 was primarily attributable to increases in operating income, the effect of which was partially offset by increases in interest and other, net expense and income tax expense.

[0001571996-19-000008:mdna:169]
60

[0001571996-19-000008:mdna:170]
Non-controlling Interests

[0001571996-19-000008:mdna:171]
Fiscal 2019 compared to Fiscal 2018

[0001571996-19-000008:mdna:172]
During Fiscal 2019, net income attributable to non-controlling interests was $129 million, compared to a net loss attributable to non-controlling interests of $77 million during Fiscal 2018.  Net income or loss attributable to non-controlling interests consisted of net income or loss attributable to our non-controlling interests in VMware, Inc., Pivotal, and Secureworks.  For more information about our non-controlling interests, see Note 13 of the Notes to the Consolidated Financial Statements included in this report.

[0001571996-19-000008:mdna:173]
Fiscal 2018 compared to Fiscal 2017

[0001571996-19-000008:mdna:174]
During Fiscal 2018, net loss attributable to non-controlling interests was $77 million, while during Fiscal 2017, net income attributable to non-controlling interests was $9 million.  During Fiscal 2018 net loss attributable to non-controlling interests primarily consisted of net loss attributable to the non-controlling interest in VMware, Inc.

[0001571996-19-000008:mdna:175]
Net Loss Attributable to Dell Technologies Inc.

[0001571996-19-000008:mdna:176]
Fiscal 2019 compared to Fiscal 2018

[0001571996-19-000008:mdna:177]
Net loss attributable to Dell Technologies Inc. represents net loss and an adjustment for non-controlling interests.  Net loss attributable to Dell Technologies Inc. was $2.3 billion and $2.8 billion, respectively, during Fiscal 2019 and Fiscal 2018.  The decrease in net loss attributable to Dell Technologies Inc. during Fiscal 2019 was primarily attributable to a decrease in net loss for the period.

[0001571996-19-000008:mdna:178]
Fiscal 2018 compared to Fiscal 2017

[0001571996-19-000008:mdna:179]
Net loss attributable to Dell Technologies Inc. represents net loss from continuing operations, an adjustment for non-controlling interests, and, in Fiscal 2017, an adjustment for discontinued operations.  During Fiscal 2018 and Fiscal 2017, net loss attributable to Dell Technologies Inc. was $2.8 billion and $1.2 billion, respectively.  The increase in net loss attributable to Dell Technologies Inc. during Fiscal 2018 was primarily attributable to a decrease in net loss from continuing operations and the absence of income from our discontinued operations in Fiscal 2018 as a result of completion of the divestiture transactions in Fiscal 2017.

[0001571996-19-000008:mdna:180]
61

[0001571996-19-000008:mdna:181]
Business Unit Results

[0001571996-19-000008:mdna:182]
Fiscal 2019 compared to Fiscal 2018

[0001571996-19-000008:mdna:183]
Our reportable segments are based on the following business units: ISG, CSG, and VMware.  A description of our three business units is provided under “Introduction.”  See Note 19 of the Notes to the Consolidated Financial Statements included in this report for a reconciliation of net revenue and operating income by reportable segment to consolidated net revenue and consolidated operating loss, respectively.

[0001571996-19-000008:mdna:184]
During the first quarter of Fiscal 2019, we made certain segment reporting changes, which included the movement of Virtustream results from ISG to other businesses.  None of these changes impacted our previously reported consolidated financial results, but our prior period segment results have been recast to reflect this change.

[0001571996-19-000008:mdna:185]
Infrastructure Solutions Group:

[0001571996-19-000008:mdna:186]
The following table presents net revenue and operating income attributable to ISG for the respective periods:

[0001571996-19-000008:mdna:187]
|  | Fiscal Year Ended |
|  | February 1, 2019 |  | % Change |  | February 2, 2018 |  | % Change |  | February 3, 2017 |
|  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |  |  |  |  |
| Servers and networking | $ | 19,953 |  |  | 28 | % |  | $ | 15,533 |  |  | 20 | % |  | $ | 12,973 |  |
| Storage | 16,767 |  |  | 9 | % |  | 15,384 |  |  | 69 | % |  | 9,097 |  |
| Total ISG net revenue | $ | 36,720 |  |  | 19 | % |  | $ | 30,917 |  |  | 40 | % |  | $ | 22,070 |  |
| Operating income: |  |  |  |  |  |  |  |  |  |
| ISG operating income | $ | 4,151 |  |  | 35 | % |  | $ | 3,068 |  |  | 5 | % |  | $ | 2,920 |  |
| % of segment net revenue | 11.3 | % |  |  |  | 9.9 | % |  |  |  | 13.2 | % |

[0001571996-19-000008:mdna:188]
Fiscal 2019 compared to Fiscal 2018

[0001571996-19-000008:mdna:189]
Net Revenue — During Fiscal 2019, ISG net revenue increased 19% primarily due to an increase in sales of servers and networking as well as an increase in sales of storage.  Revenue from servers and networking increased 28% during Fiscal 2019, driven by an increase in both average selling price and units sold of our PowerEdge servers.  Average selling prices increased due to the sale of servers with more robust compute capacity and higher memory and storage content, which was driven by customer demand for servers that enable big data analytics and software-defined storage solutions, including hyper-converged infrastructure, as well as increased component costs during the first half of Fiscal 2019.  Storage revenue increased 9% during Fiscal 2019 due to strong growth in our network-attached storage and object storage solutions.  We have been making go-to-market investments and enhancements to our storage solutions offerings, and expect that these investments will drive long-term improvements in the business.  Although component costs were inflationary during the first half of Fiscal 2019, they were slightly deflationary in the aggregate for ISG during the second half of Fiscal 2019, and we continue to monitor our pricing in response to changes in the component cost environment.  We expect the aggregate ISG component cost environment to continue to be slightly deflationary into the first half of Fiscal 2020.

[0001571996-19-000008:mdna:190]
In ISG, we continue to see interest in flexible consumption models by our customers as they seek to build greater flexibility into their cost structures.  We generally provide these solutions under multi-year contracts that typically result in recognition of revenue over the term of the arrangement.  We expect these flexible consumption models will further strengthen our customer relationships and will build more predictable revenue streams over time.

[0001571996-19-000008:mdna:191]
From a geographical perspective, net revenue attributable to ISG increased across all regions during Fiscal 2019.

[0001571996-19-000008:mdna:192]
Operating Income — During Fiscal 2019, ISG operating income as a percentage of net revenue increased 140 basis points to 11.3% primarily due to a decrease in operating expenses as a percentage of revenue, partially offset by a decrease in ISG gross margin percentage.  Revenue growth outpaced our investments in go-to-market capabilities and solutions offerings, and, as a result, operating expenses decreased as a percentage of revenue.  We experienced gross margin pressure due to a shift in product mix to servers, which typically have a lower gross margin than storage products.

[0001571996-19-000008:mdna:193]
Fiscal 2018 compared to Fiscal 2017

[0001571996-19-000008:mdna:194]
Net Revenue — During Fiscal 2018, ISG net revenue increased 40% primarily due to incremental storage net revenue associated with the EMC acquired storage business and, to a lesser extent, increases in servers and networking.  Revenue from servers and networking increased 20% during Fiscal 2018, driven by an increase in both average selling price and units sold of our PowerEdge server product.  Average selling prices increased as we managed our pricing in response to the current component cost environment, and also reflected the sale of servers with higher memory and storage content.  Storage revenue increased 69% during Fiscal 2018 due to the incremental revenue from the EMC acquired storage business.  Although we experienced strong growth in all-flash and hyper-converged infrastructure products, we are experiencing reduced demand in ISG for certain elements of our storage portfolio, including traditional high-end and midrange storage offerings.  We are addressing this dynamic through investments in our go-to-market capabilities and product enhancements.

[0001571996-19-000008:mdna:195]
From a geographical perspective, during Fiscal 2018, ISG net revenue increased in all regions due to the incremental revenue from the EMC acquired storage business.  The EMC acquired storage business operates on a world-wide basis with a geographic mix similar to that of the legacy Dell ISG business.

[0001571996-19-000008:mdna:196]
Operating Income — During Fiscal 2018, ISG operating income decreased 330 basis points to 9.9% primarily due to increased operating expenses from the EMC acquired businesses and larger investments in our go-to-market capabilities and research and development.  While the EMC acquired storage business contributed higher gross margin overall, we experienced gross margin pressure due to changing product mix within ISG as well as component cost inflation, particularly for memory components used in ISG products.

[0001571996-19-000008:mdna:197]
63

[0001571996-19-000008:mdna:198]
Client Solutions Group:

[0001571996-19-000008:mdna:199]
The following table presents net revenue and operating income attributable to CSG for the respective periods:

[0001571996-19-000008:mdna:200]
|  | Fiscal Year Ended |
|  | February 1, 2019 |  | % Change |  | February 2, 2018 |  | % Change |  | February 3, 2017 |
|  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 30,893 |  |  | 12 | % |  | $ | 27,507 |  |  | 7 | % |  | $ | 25,773 |  |
| Consumer | 12,303 |  |  | 5 | % |  | 11,711 |  |  | 9 | % |  | 10,736 |  |
| Total CSG net revenue | $ | 43,196 |  |  | 10 | % |  | $ | 39,218 |  |  | 7 | % |  | $ | 36,509 |  |
| Operating income: |  |  |  |  |  |  |  |  |  |
| CSG operating income | $ | 1,960 |  |  | (4 | )% |  | $ | 2,044 |  |  | 17 | % |  | $ | 1,751 |  |
| % of segment net revenue | 4.5 | % |  |  |  | 5.2 | % |  |  |  | 4.8 | % |

[0001571996-19-000008:mdna:201]
Fiscal 2019 compared to Fiscal 2018

[0001571996-19-000008:mdna:202]
Net Revenue — During Fiscal 2019, CSG net revenue increased 10% due to continued strong demand for our commercial products and overall higher average selling prices driven by an increase in consumer.  Commercial net revenue increased 12%, driven primarily by increased demand across all product categories.  Consumer net revenue increased 5%, driven primarily by a shift in product mix to our high end notebooks.  During Fiscal 2019, we effectively managed our pricing in response to supply chain dynamics, geographical mix, foreign currency exchange fluctuations, and the component cost environment.  The aggregate CSG component cost environment was deflationary in the second half of Fiscal 2019, and we expect deflationary conditions to continue into the first half of Fiscal 2020.

[0001571996-19-000008:mdna:203]
From a geographical perspective, net revenue attributable to CSG increased across all regions during Fiscal 2019.

[0001571996-19-000008:mdna:204]
Operating Income — During Fiscal 2019, CSG operating income as a percentage of net revenue decreased 70 basis points to 4.5%.  The decrease was primarily due to higher component costs during the first half of Fiscal 2019 that negatively impacted CSG gross margin and to increases in CSG operating expense as a percentage of revenue resulting from higher performance-driven commission costs and marketing expense related to our net revenue growth.  In addition, the decline in CSG operating income as a percentage of revenue during Fiscal 2019 was partially attributable to a $68 million vendor settlement benefit recorded during Fiscal 2018, which resulted in an incremental 20 basis points to our operating income percentage in the prior period that did not recur.  Excluding the effect of this vendor settlement, CSG operating income as a percentage of revenue decreased 50 basis points during Fiscal 2019.

[0001571996-19-000008:mdna:205]
Fiscal 2018 compared to Fiscal 2017

[0001571996-19-000008:mdna:206]
Net Revenue — During Fiscal 2018, CSG net revenue increased 7%, driven by an increase in overall average selling price in both the commercial and consumer product categories, as we managed our pricing in response to the cost environment during the period.  During Fiscal 2018, CSG net revenue also benefited from increases in units sold, as we experienced a general improvement in customer demand, which favored premium notebooks and workstations.

[0001571996-19-000008:mdna:207]
From a geographical perspective, net revenue attributable to CSG increased across all regions during Fiscal 2018.

[0001571996-19-000008:mdna:208]
Operating Income — During Fiscal 2018, CSG operating income as a percentage of net revenue increased 40 basis points to 5.2% primarily due to a reduction in CSG operating expenses as a percentage of net revenue, as we continued to manage our cost position.  This benefit was partially offset by increased component costs, which we were able to mitigate in large part through pricing actions.  The impact of the vendor settlements recorded in Fiscal 2018 and Fiscal 2017 did not affect comparability for these periods.

[0001571996-19-000008:mdna:209]
VMware:

[0001571996-19-000008:mdna:210]
The following table presents net revenue and operating income attributable to VMWare for the respective periods:

[0001571996-19-000008:mdna:211]
|  | Fiscal Year Ended |
|  | February 1, 2019 |  | % Change |  | February 2, 2018 |  | % Change |  | February 3, 2017 |
|  | (in millions, except percentages) |
| Net revenue: |  |  |  |  |  |  |  |  |  |
| VMware net revenue | $ | 9,088 |  |  | 14 | % |  | $ | 7,994 |  |  | 126 | % |  | $ | 3,543 |  |
| Operating income: |  |  |  |  |  |  |  |  |  |
| VMware operating income | $ | 2,989 |  |  | 6 | % |  | $ | 2,809 |  |  | 85 | % |  | $ | 1,516 |  |
| % of segment net revenue | 32.9 | % |  |  |  | 35.1 | % |  |  |  | 42.8 | % |

[0001571996-19-000008:mdna:212]
Fiscal 2019 compared to Fiscal 2018

[0001571996-19-000008:mdna:213]
Net Revenue — VMware net revenue primarily consists of revenue from the sale of software licenses under perpetual licenses, related software maintenance and support, training, consulting services, and hosted services.  VMware net revenue during Fiscal 2019 increased 14% primarily due to growth in software license revenue and sales of software maintenance services.  Software license revenue benefited from broad-based growth across the product portfolio.  Software maintenance revenue benefited from strong renewals, revenue recognized from maintenance contracts sold in prior periods, and new maintenance contracts sold during the period.

[0001571996-19-000008:mdna:214]
From a geographical perspective, approximately half of VMware net revenue during Fiscal 2019 was generated by sales to customers in the United States.  VMware net revenue for Fiscal 2019 benefited from growth across U.S. and international markets.

[0001571996-19-000008:mdna:215]
Operating Income — During Fiscal 2019, VMware operating income as a percentage of net revenue decreased 220 basis points to 32.9%.  The decrease was driven by an increase in operating expenses as a percentage of revenue due to an increase in compensation-related expense associated with sales and sales support, which reflected increased performance-driven commission costs and headcount, as well as to an increase in R&D expenses.

[0001571996-19-000008:mdna:216]
See Exhibit 99.1 filed with this report for information on the differences between VMware reportable segment results and VMware, Inc. results.

[0001571996-19-000008:mdna:217]
Fiscal 2018 compared to Fiscal 2017

[0001571996-19-000008:mdna:218]
Net Revenue — VMware net revenue for Fiscal 2018 benefited from balanced performance in all major geographies and broad strength across the product portfolio.

[0001571996-19-000008:mdna:219]
From a geographical perspective, approximately half of VMware net revenue during Fiscal 2018 was generated by sales to customers in the United States.

[0001571996-19-000008:mdna:220]
Operating Income — During Fiscal 2018, VMware operating income as a percentage of net revenue was 35.1%, primarily driven by strong gross margin performance during the year.

[0001571996-19-000008:mdna:221]
OTHER BALANCE SHEET ITEMS

[0001571996-19-000008:mdna:222]
Accounts Receivable

[0001571996-19-000008:mdna:223]
We sell products and services directly to customers and through a variety of sales channels, including retail distribution.  Our accounts receivable, net, was $12.4 billion and $11.7 billion as of February 1, 2019 and February 2, 2018, respectively.  We maintain an allowance for doubtful accounts to cover receivables that may be deemed uncollectible.  The allowance for losses is based on a provision for accounts that are collectively evaluated based on historical bad debt experience as well as specific identifiable customer accounts that are deemed at risk.  As of February 1, 2019 and February 2, 2018, the allowance for doubtful accounts was $85 million and $103 million, respectively.  Based on our assessment, we believe that we are adequately reserved for expected credit losses.  We monitor the aging of our accounts receivable and continue to take actions to reduce our exposure to credit losses.

[0001571996-19-000008:mdna:224]
Dell Financial Services and Financing Receivables

[0001571996-19-000008:mdna:225]
Dell Financial Services and its affiliates (“DFS”) support Dell Technologies by offering and arranging various financing options and services for our customers globally, including through captive financing operations in North America, Europe, Australia, and New Zealand.  DFS originates, collects, and services customer receivables primarily related to the purchase of our product, software, and service solutions.  DFS further strengthens our customer relationships through its flexible consumption models, which enable us to offer our customers the option to pay over time and, in certain cases, based on utilization, to provide them with financial flexibility to meet their changing technological requirements.  New financing originations were $7.3 billion, $6.3 billion, and $4.5 billion for Fiscal 2019, Fiscal 2018, and Fiscal 2017, respectively.  The growth in new financing originations during Fiscal 2018 was primarily due to increased offerings related to customer purchases of products and services from the businesses acquired as part of the EMC merger transaction.

[0001571996-19-000008:mdna:226]
DFS offerings are initially funded through cash on hand at the time of origination, most of which is subsequently replaced with third-party financing.  As a result, while the initial funding is reflected as an impact to cash flows from operations, it is largely subsequently offset by cash flows from financing.  As of February 1, 2019 and February 2, 2018, our financing receivables, net were $8.6 billion and $7.6 billion, respectively.

[0001571996-19-000008:mdna:227]
We maintain an allowance to cover expected financing receivable credit losses and evaluate credit loss expectations based on our total portfolio.  For Fiscal 2019, Fiscal 2018, and Fiscal 2017, the principal charge-off rate for our total portfolio was 1.2%, 1.5%, and 2.0%, respectively.  The credit quality of our financing receivables has improved in recent years due to an overall improvement in the credit environment and as the mix of high-quality commercial accounts in our portfolio has continued to increase.  The allowance for losses is determined based on various factors, including historical and anticipated experience, past due receivables, receivable type, and customer risk profile.  As of February 1, 2019 and February 2, 2018, the allowance for financing receivable losses was $136 million and $145 million, respectively.  In general, the loss rates on our financing receivables have improved over the periods presented.  We expect relatively stable loss rates in future periods, with movements in these rates being primarily driven by seasonality and a continued shift in portfolio composition to lower risk commercial assets.  We continue to monitor broader economic indicators and their potential impact on future loss performance.  We have an extensive process to manage our exposure to customer credit risk, including active management of credit lines and our collection activities.  We also sell selected fixed-term financing receivables to unrelated third parties on a periodic basis, primarily to manage certain concentrations of customer credit exposure.  Based on our assessment of the customer financing receivables, we believe that we are adequately reserved.

[0001571996-19-000008:mdna:228]
See Note 5 of the Notes to the Consolidated Financial Statements included in this report for additional information about our financing receivables and the associated allowances.

[0001571996-19-000008:mdna:229]
Off-Balance Sheet Arrangements

[0001571996-19-000008:mdna:230]
As of February 1, 2019, we had no off-balance sheet arrangements that have or are reasonably likely to have a current or future material effect on our financial condition or results of operations.

[0001571996-19-000008:mdna:231]
66

[0001571996-19-000008:mdna:232]
MARKET CONDITIONS, LIQUIDITY, CAPITAL COMMITMENTS, AND CONTRACTUAL CASH OBLIGATIONS

[0001571996-19-000008:mdna:233]
Market Conditions

[0001571996-19-000008:mdna:234]
We regularly monitor economic conditions and associated impacts on the financial markets and our business.  We consistently evaluate the financial health of our supplier base, carefully manage customer credit, diversify counterparty risk, and monitor the concentration risk of our cash and cash equivalents balances globally.  We routinely monitor our financial exposure to borrowers and counterparties.

[0001571996-19-000008:mdna:235]
We monitor credit risk associated with our financial counterparties using various market credit risk indicators such as credit ratings issued by nationally recognized credit rating agencies and changes in market credit default swap levels.  We perform periodic evaluations of our positions with these counterparties and may limit exposure to any one counterparty in accordance with our policies.  We monitor and manage these activities depending on current and expected market developments.

[0001571996-19-000008:mdna:236]
We use derivative instruments to hedge certain foreign currency exposures.  We use forward contracts and purchased options designated as cash flow hedges to protect against the foreign currency exchange rate risks inherent in our forecasted transactions denominated in currencies other than the U.S. dollar.  In addition, we primarily use forward contracts and may use purchased options to hedge monetary assets and liabilities denominated in a foreign currency.  See Note 7 of the Notes to the Consolidated Financial Statements included in this report for more information about our use of derivative instruments.

[0001571996-19-000008:mdna:237]
We are exposed to interest rate risk related to our variable-rate debt and investment portfolio.  In the normal course of business, we follow established policies and procedures to manage this risk, including monitoring of our asset and liability mix.  As a result, we do not anticipate any material losses from interest rate risk.

[0001571996-19-000008:mdna:238]
The impact of any credit adjustments related to our use of counterparties on our Consolidated Financial Statements included in this report has been immaterial.

[0001571996-19-000008:mdna:239]
Liquidity and Capital Resources

[0001571996-19-000008:mdna:240]
To support our ongoing business operations, we rely on operating cash flows as our primary source of liquidity.  We monitor the efficiency of our balance sheet to ensure that we have adequate liquidity to support our strategic initiatives.  In addition to internally generated cash, we have access to other capital sources to finance our strategic initiatives and fund growth in our financing operations.  As of February 1, 2019, we had $9.7 billion of total cash and cash equivalents.  Our strategy is to deploy capital from any potential source, whether internally generated cash or debt, depending on the adequacy and availability of that source of capital and whether it can be accessed in a cost-effective manner.

[0001571996-19-000008:mdna:241]
A significant portion of our income is earned in non-U.S. jurisdictions.  Prior to the enactment of U.S. Tax Reform as discussed above in “Results of Operations — Income and Other Taxes”, earnings available to be repatriated to the United States would be subject to U.S. federal income tax, less applicable foreign tax credits.  U.S. Tax Reform fundamentally changes the U.S. approach to taxation of foreign earnings to a modified territorial tax system, which generally allows companies to make distributions of non-U.S. earnings to the United States without incurring additional U.S. federal tax.  However, local and U.S. state taxes may still apply.  We have provided for future tax liabilities on income earned in non-U.S. jurisdictions, except for foreign earnings that are considered indefinitely reinvested outside of the United States.

[0001571996-19-000008:mdna:242]
During the fourth quarter of Fiscal 2019, as discussed above in “Introduction — Class V Transaction,” we completed a transaction in which all issued and outstanding shares of Class V Common Stock were exchanged for cash or shares of Class C Common Stock at the stockholder’s election.  We paid a total of $14 billion of cash to holders of Class V Common Stock.

[0001571996-19-000008:mdna:243]
To fund a majority of the cash payment to stockholders, VMware, Inc. declared a conditional $11 billion one-time special cash dividend (the “Special Dividend”), which was paid pro-rata to VMware, Inc. stockholders as of the dividend record date of December 27, 2018 and in connection with the completion of the Class V transaction.  Our cash, cash equivalents, and investments declined significantly, commensurate with the cash required to fund this transaction.  VMware, Inc. has advised us that, following its payment of the Special Dividend, VMware, Inc. will remain committed to a balanced capital allocation policy through investment in their product and solution offerings, acquisitions, and returning capital to their stockholders through share repurchases.

[0001571996-19-000008:mdna:244]
We funded a majority of the cash consideration paid in the Class V transaction from the $8.87 billion of the proceeds of the Special Dividend.  The remaining amount of the cash consideration was primarily funded with $3.67 billion of proceeds from new senior secured term loans under our senior secured credit facilities and proceeds of a margin loan financing in an aggregate principal amount of $1.35 billion.  See Note 6 of the Notes to the Consolidated Financial Statements included in this report for information about the debt we incurred to finance the Class V transaction.

[0001571996-19-000008:mdna:245]
The following table summarizes our cash and cash equivalents as well as our available borrowings as of February 1, 2019 and February 2, 2018:

[0001571996-19-000008:mdna:246]
|  | February 1, 2019 |  | February 2, 2018 |
|  | (in millions) |
| Cash and cash equivalents, and available borrowings: |  |  |  |
| Cash and cash equivalents (a) | $ | 9,676 |  |  | $ | 13,942 |  |
| Remaining available borrowings under revolving credit facilities | 5,586 |  |  | 4,875 |  |
| Total cash, cash equivalents, and available borrowings | $ | 15,262 |  |  | $ | 18,817 |  |

[0001571996-19-000008:mdna:247]
____________________

[0001571996-19-000008:mdna:248]
| (a) | Of the $9.7 billion of cash and cash equivalents as of February 1, 2019, $2.8 billion was held by VMware, Inc. |

[0001571996-19-000008:mdna:249]
Available borrowings under our Revolving Credit Facility are reduced by draws on the facility and outstanding letters of credit.  As of February 1, 2019, there were no borrowings outstanding under the facility and remaining available borrowings totaled approximately $4.5 billion.

[0001571996-19-000008:mdna:250]
Subsequent to the end of Fiscal 2019, we renewed our China Revolving Credit Facility, which expired on October 31, 2018.  The facility provides an aggregate principal amount not to exceed $500 million at an interest rate of LIBOR plus 0.6% per annum.  We may regularly use our available borrowings from both our Revolving Credit Facility and our China Revolving Credit Facility on a short-term basis for general corporate purposes.

[0001571996-19-000008:mdna:251]
The VMware Revolving Credit Facility and the Pivotal Revolving Credit Facility have maximum aggregate borrowings of $1.0 billion and $100 million, respectively.  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc., Pivotal, and their respective subsidiaries.  As of February 1, 2019, $1.0 billion was available under the VMware Revolving Credit Facility and $100 million was available under the Pivotal Revolving Credit Facility.

[0001571996-19-000008:mdna:252]
See Note 6 of the Notes to the Consolidated Financial Statements included in this report for additional information about each of the foregoing revolving credit facilities.

[0001571996-19-000008:mdna:253]
Even with the significant decline in cash and cash equivalents that resulted from the Class V transaction, we believe that our current cash and cash equivalents, together with cash that will be provided by future operations and expected borrowings under our revolving credit facilities, will be sufficient over at least the next twelve months to fund our operations, debt service requirements and maturities, capital expenditures, share repurchases, and other corporate needs.

[0001571996-19-000008:mdna:254]
Debt

[0001571996-19-000008:mdna:255]
The following table summarizes our outstanding debt as of February 1, 2019 and February 2, 2018:

[0001571996-19-000008:mdna:256]
|  | February 1, 2019 |  | February 2, 2018 |
|  | (in millions) |
| Restricted Subsidiary Debt |  |  |  |
| Core debt: |  |  |  |
| Senior Secured Credit Facilities and First Lien Notes | $ | 32,720 |  |  | $ | 30,595 |  |
| Unsecured Notes and Debentures | 1,952 |  |  | 2,452 |  |
| Senior Notes | 3,250 |  |  | 3,250 |  |
| EMC Notes | 3,000 |  |  | 5,500 |  |
| DFS allocated debt | (1,615 | ) |  | (1,892 | ) |
| Total core debt | 39,307 |  |  | 39,905 |  |
| DFS related debt: |  |  |  |
| DFS debt | 5,929 |  |  | 4,796 |  |
| DFS allocated debt | 1,615 |  |  | 1,892 |  |
| Total DFS related debt | 7,544 |  |  | 6,688 |  |
| Margin Loan and Other | 3,388 |  |  | 2,054 |  |
| Unrestricted Subsidiary Debt |  |  |  |
| VMware Notes | 4,000 |  |  | 4,000 |  |
| Other | — |  |  | 47 |  |
| Total unrestricted subsidiary debt | 4,000 |  |  | 4,047 |  |
| Total debt, principal amount | 54,239 |  |  | 52,694 |  |
| Carrying value adjustments | (718 | ) |  | (823 | ) |
| Total debt, carrying value | $ | 53,521 |  |  | $ | 51,871 |  |

[0001571996-19-000008:mdna:257]
The outstanding principal amount of our debt was $54.2 billion as of February 1, 2019, which included core debt of $39.3 billion.  We define core debt as the total principal amount of our debt, less DFS related debt, other debt, and unrestricted subsidiary debt.

[0001571996-19-000008:mdna:258]
DFS related debt primarily represents debt from our securitization and structured financing programs.  To fund expansion of the DFS business, we balance the use of the securitization and structured financing programs with other sources of liquidity.  We approximate the amount of our debt used to fund the DFS business by applying a 7:1 debt to equity ratio to our financing receivables balance, based on the underlying credit quality of the assets.  See Note 5 of the Notes to the Consolidated Financial Statements included in this report for more information about our DFS debt.

[0001571996-19-000008:mdna:259]
As of February 1, 2019 and February 2, 2018, margin loan and other debt primarily consisted of the $3.4 billion Margin Loan Facility.

[0001571996-19-000008:mdna:260]
VMware, Inc., Pivotal, and their respective subsidiaries are unrestricted subsidiaries for purposes of the existing debt of Dell Technologies.  Neither Dell Technologies nor any of its subsidiaries, other than VMware, Inc., is obligated to make payment on the VMware Notes.  None of the net proceeds of the VMware Notes will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and its subsidiaries.

[0001571996-19-000008:mdna:261]
69

[0001571996-19-000008:mdna:262]
Our requirements for cash to pay principal and interest on our debt increased significantly due to the borrowings we incurred to finance the EMC merger transaction, and to a lesser extent, the Class V transaction.  We have made good progress in paying down core debt since the EMC merger transaction.  We believe we will continue to be able to make our debt principal and interest payments, including the short-term maturities, from existing and expected sources of cash.  Cash used for debt principal and interest payments may include short-term borrowings under revolving credit facilities.  We will continue to focus on paying down core debt.  Despite the debt repayments, interest expense was $2.5 billion during both Fiscal 2019 and Fiscal 2018.  We expect that continued demand for customer financing as well as an increase in LIBOR will impact future interest expense on our variable-rate debt.  We or our affiliates, at our or their sole discretion, may purchase, redeem, prepay, refinance, or otherwise retire any amount of our outstanding indebtedness under the terms of such indebtedness at any time and from time to time, in open market or negotiated transactions with the holders of such indebtedness, as appropriate market conditions exist.

[0001571996-19-000008:mdna:263]
See Note 6 of the Notes to the Consolidated Financial Statements included in this report for more information about our debt and our unrestricted subsidiaries.

[0001571996-19-000008:mdna:264]
Fiscal 2019

[0001571996-19-000008:mdna:265]
During Fiscal 2019, we repaid approximately $1.2 billion principal amount of our 3.81% Term Loan A-3 Facility, $2.5 billion principal amount of our 1.875% unsecured notes, $500 million principal amount of our 5.65% unsecured notes and $328 million principal amount of our other term loan facilities.  Further, we issued an additional $1.2 billion, net in DFS debt to support the expansion of our financing receivables portfolio.

[0001571996-19-000008:mdna:266]
As discussed above, we incurred additional debt of approximately $5 billion in financing related to the completion of the Class V transaction.  Subsequent to Fiscal 2019, we incurred new long-term debt to complete two refinancing transactions.  We issued multiple series of First Lien Notes (the “new First Lien Notes”) totaling approximately $4.5 billion and increased the aggregate principal amount of borrowings under our Margin Loan Facility by $650 million.  In addition, we amended the credit agreement for our senior secured credit facilities to obtain a new senior secured Term Loan A-6 Facility consisting of $3,634 million, of which $2,839 million aggregate principal amount consisted of amounts outstanding that rolled over from our Term Loan A-2 Facility.  Subsequently, $1,277 million aggregate principal amount of Term Loan A-2 Facility remained outstanding.

[0001571996-19-000008:mdna:267]
The proceeds from the new First Lien Notes were used to repay all of our outstanding $3,750 million First Lien Notes due June 2019.  In addition, proceeds of approximately $800 million from our Term Loan A-6 Facility, $650 million from the Margin Loan Facility increase, and the remaining proceeds from the new First Lien Notes were used to repay all of our outstanding amounts under the Term Loan A-5 Facility due December 2019.  The excess proceeds available from our new First Lien Notes were used to repay outstanding amounts from our Term Loan A-2 Facility and to pay related premiums, accrued interest, fees, and expenses.

[0001571996-19-000008:mdna:268]
In refinancing this debt, we sought to minimize our cost of capital and borrowings under our revolving credit facilities while maintaining a manageable maturity profile.  See Note 24 of the Notes to the Consolidated Financial Statements included in this report for additional information about the refinancing transactions.

[0001571996-19-000008:mdna:269]
Fiscal 2018

[0001571996-19-000008:mdna:270]
During Fiscal 2018, we completed two refinancing transactions of the Senior Secured Credit Facilities.  In the first refinancing transaction, which occurred during the first quarter of Fiscal 2018, we refinanced the Term Loan B Facility to reduce the interest rate margin by 0.75% and to increase the outstanding principal amount by $0.5 billion.  We applied the proceeds from the Term Loan B Facility refinancing to repay $0.5 billion principal amount of the Margin Bridge Facility.  Additionally, during the first quarter of Fiscal 2018, we entered into the Margin Loan Facility in the principal amount of $2.0 billion and used the proceeds of the new facility to repay the Margin Bridge Facility in full.

[0001571996-19-000008:mdna:271]
In the second refinancing transaction, which occurred during the third quarter of Fiscal 2018, we refinanced the Term Loan A-2 Facility, Term Loan A-3 Facility, Term Loan B Facility, and the Revolving Credit Facility.  As a result of the refinancing, the interest rate margin under each of these facilities decreased by 0.50% and the outstanding principal amount of the Term Loan A-2 Facility increased by $672 million, which we used to pay $212 million principal amount of the Term Loan A-3 Facility and $460 million principal amount of the Term Loan B Facility.  Further, the Revolving Credit Facility’s borrowing capacity increased by $180 million to $3.3 billion.

[0001571996-19-000008:mdna:272]
70

[0001571996-19-000008:mdna:273]
During Fiscal 2018, we repaid approximately $1.2 billion principal amount of our term loan facilities and $0.4 billion under the Revolving Credit Facility and issued an additional $1.3 billion, net, in DFS debt to support the expansion of the DFS financing receivables portfolio.

[0001571996-19-000008:mdna:274]
Further, during the third quarter of Fiscal 2018, VMware, Inc. completed a public offering of senior notes in the aggregate principal amount of $4.0 billion (the “VMware Notes”).  VMware, Inc. used a portion of the net proceeds from the offering to repay certain intercompany promissory notes previously issued by it to EMC in the aggregate principal amount of $1.2 billion.  We applied the proceeds of this repayment, and other cash, to repay $1.5 billion principal amount of the VMware Note Bridge Facility.

[0001571996-19-000008:mdna:275]
Cash Flows

[0001571996-19-000008:mdna:276]
The following table contains a summary of our Consolidated Statements of Cash Flows for the respective periods:

[0001571996-19-000008:mdna:277]
|  | Fiscal Year Ended |
|  | February 1, 2019 |  | February 2, 2018 |  | February 3, 2017 |
|  | (in millions) |
| Net change in cash from: |  |  |  |  |  |
| Operating activities | $ | 6,991 |  |  | $ | 6,843 |  |  | $ | 2,367 |  |
| Investing activities | 3,389 |  |  | (2,875 | ) |  | (31,236 | ) |
| Financing activities | (14,329 | ) |  | 403 |  |  | 31,785 |  |
| Effect of exchange rate changes on cash and cash equivalents | (189 | ) |  | 175 |  |  | 24 |  |
| Change in cash and cash equivalents | $ | (4,138 | ) |  | $ | 4,546 |  |  | $ | 2,940 |  |

[0001571996-19-000008:mdna:278]
Operating Activities — Cash provided by operating activities was $7.0 billion for Fiscal 2019 compared to $6.8 billion for Fiscal 2018.  The increase in operating cash flows during Fiscal 2019 was attributable to business growth, which drove higher deferred revenue and improved profitability due to product mix and higher average selling prices, partially offset by an increase in inventory.  During Fiscal 2019, we experienced supply chain dynamics that temporarily increased our inventory and negatively impacted working capital.  We expect our inventory and the associated working capital impact to normalize during Fiscal 2020.

[0001571996-19-000008:mdna:279]
DFS offerings are initially funded through cash on hand at the time of origination, most of which is subsequently replaced with third-party financing.  As a result, while the initial funding is reflected as an impact to cash flows from operations, this funding is largely subsequently offset by cash flows from financing.  DFS new financing originations were $7.3 billion and $6.3 billion during Fiscal 2019 and Fiscal 2018, respectively.  As of February 1, 2019, DFS had $8.6 billion of total net financing receivables.  Additionally, as a result of our adoption of the new leasing standard on lessor accounting, we expect an increase to future originations of operating leases which will result in a shift from financing receivables to capital expenditures.  In Fiscal 2020, our cash flows provided by operating activities will benefit by the increase in capital expenditures being reported as cash flows used in investing activities.

[0001571996-19-000008:mdna:280]
In comparison to Fiscal 2018, cash provided by operating activities was $2.4 billion for Fiscal 2017.  The increase in operating cash flows during Fiscal 2018 was driven by improved profitability, predominantly due to the incremental profitability from the EMC acquired businesses, and ongoing working capital initiatives.  Further, cash paid for transaction costs related primarily to the EMC merger transaction during Fiscal 2017 did not recur in Fiscal 2018.  The increase in operating cash flows was partially offset by the growth in our financing receivables portfolio and cash paid for interest and taxes.

[0001571996-19-000008:mdna:281]
Investing Activities — Investing activities primarily consist of cash used to fund strategic investments, the maturities, sales, and purchases of investments, capital expenditures for property, plant, and equipment, and capitalized software development costs.  During Fiscal 2019, cash provided by investing activities was $3.4 billion and was primarily driven by the net sales of investments used to fund the Class V transaction, partially offset by capital expenditures and strategic investments.

[0001571996-19-000008:mdna:282]
In comparison, cash used by investing activities was $2.9 billion during Fiscal 2018 and was primarily driven by capital expenditures, capitalized software development costs, and net purchases of investments.  Cash used in investing activities was $31.2 billion during Fiscal 2017, principally due to our use of $37.6 billion, net cash to fund the EMC merger transaction.

[0001571996-19-000008:mdna:283]
Financing Activities — Financing activities primarily consist of the proceeds and repayments of debt, cash used to repurchase common stock, and proceeds from the issuance of common stock of subsidiaries.  Cash used by financing activities of $14.3 billion during Fiscal 2019 primarily consisted of $14.0 billion in cash paid to holders of the Class V Common Stock in the Class V transaction, partially offset by debt proceeds of $5.0 billion of debt incurred to fund a portion of this payment.  Cash used by financing activities also included our repayments of the EMC Note in the amount of $2.5 billion and the Term Loan A-3 Facility in the amount of $1.2 billion, as well as the payment to VMware, Inc.’s public stockholders of $2.1 billion of the Special Dividend.

[0001571996-19-000008:mdna:284]
In comparison, cash provided by financing activities of $0.4 billion during Fiscal 2018 was primarily driven by net proceeds from debt, primarily due to the issuance of the VMware Notes, partially offset by cash used for share repurchases.  During Fiscal 2017, cash provided by financing activities was $31.8 billion, and consisted primarily of $46.9 billion in cash proceeds from debt, $43.2 billion of which was issued in connection with the EMC merger transaction, and $4.4 billion in proceeds from the sale and issuance of our Class A, Class B, and Class C Common Stock for financing of that transaction.  These issuances were partially offset by $17.0 billion in repayments of debt, $0.9 billion in payments of debt issuance costs, $1.3 billion in payments to repurchase common stock, and $0.4 billion in payments in connection with the appraisal litigation related to the going-private transaction.

[0001571996-19-000008:mdna:285]
Capital Commitments

[0001571996-19-000008:mdna:286]
Capital Expenditures — During both Fiscal 2019 and Fiscal 2018, we spent $1.2 billion on property, plant, and equipment.  These expenditures were primarily incurred in connection with our global expansion efforts and infrastructure investments made to support future growth.  Product demand, product mix, and the use of contract manufacturers, as well as ongoing investments in operating and information technology infrastructure, influence the level and prioritization of our capital expenditures.  Aggregate capital expenditures for Fiscal 2020, which will be primarily related to infrastructure investments and strategic initiatives, are currently expected to total between $2.7 billion and $2.9 billion.  The significant increase in expected aggregate capital expenditures from Fiscal 2019 to Fiscal 2020 is primarily related to the estimated reclassification impact of the new leasing standard on lessor accounting of approximately $1.5 billion.

[0001571996-19-000008:mdna:287]
Repurchases of Common Stock

[0001571996-19-000008:mdna:288]
Class V Common Stock Repurchases by Dell Technologies Inc.

[0001571996-19-000008:mdna:289]
Since the date of the EMC merger transaction, our board of directors authorized several programs with a total authorization of $2.1 billion to repurchase shares of our Class V Common Stock.  Upon the completion of the Class V transaction, no Class V Common Stock remained outstanding for repurchase.

[0001571996-19-000008:mdna:290]
During Fiscal 2019, we did not repurchase any shares of Class V Common Stock under our stock repurchase programs.  During Fiscal 2018, we repurchased 9.7 million shares of Class V Common Stock for an aggregate purchase price of $682 million.  The repurchase of these shares was funded by proceeds received by the Class V Group from the sale by our subsidiary of shares of Class A common stock of VMware, Inc. owned by such subsidiary, as discussed below.

[0001571996-19-000008:mdna:291]
See Note 14 of the Notes to the Consolidated Financial Statements included in this report for information about the Class V Group and the DHI Group.

[0001571996-19-000008:mdna:292]
DHI Group Common Stock Repurchases by Dell Technologies Inc.

[0001571996-19-000008:mdna:293]
During Fiscal 2019 and Fiscal 2018, we repurchased an immaterial number of shares of DHI Group Common Stock for $47 million and $6 million, respectively.

[0001571996-19-000008:mdna:294]
VMware, Inc. Class A Common Stock Repurchases by VMware, Inc.

[0001571996-19-000008:mdna:295]
Since the date of the EMC merger transaction, VMware Inc.’s board of directors has authorized the repurchase of a total of $2.2 billion of VMware Inc.’s Class A common stock, of which $834 million remained available as of February 1, 2019.

[0001571996-19-000008:mdna:296]
72

[0001571996-19-000008:mdna:297]
During Fiscal 2019, VMware, Inc. repurchased approximately 0.3 million shares of its Class A common stock in the open market for an aggregate purchase price of $42 million.  During Fiscal 2018, pursuant to stock repurchase agreements between Dell Technologies Inc. and VMware, Inc., VMware, Inc. repurchased 7.5 million shares of its Class A common stock from us for an aggregate purchase price of $725 million.  VMware, Inc. received 4.1 million shares of its Class A common stock during the first quarter of Fiscal 2018, 0.7 million shares during the second quarter of Fiscal 2018 and the remaining 2.7 million shares of its Class A common stock during the third quarter of Fiscal 2018.  The proceeds from the sales were used by us to repurchase shares of our Class V Common Stock, as described above.

[0001571996-19-000008:mdna:298]
Contractual Cash Obligations

[0001571996-19-000008:mdna:299]
The following table summarizes our contractual cash obligations as of February 1, 2019:

[0001571996-19-000008:mdna:300]
|  |  |  | Payments Due by Fiscal Year |
|  | Total |  | 2020 |  | 2021-2022 |  | 2023-2024 |  | Thereafter |
|  | (in millions) |
| Contractual cash obligations: |  |  |  |  |  |  |  |  |  |
| Principal payments on long-term debt | $ | 54,239 |  |  | $ | 10,086 |  |  | $ | 16,394 |  |  | $ | 15,931 |  |  | $ | 11,828 |  |
| Operating leases | 1,856 |  |  | 371 |  |  | 554 |  |  | 288 |  |  | 643 |  |
| Purchase obligations | 4,605 |  |  | 3,953 |  |  | 627 |  |  | 21 |  |  | 4 |  |
| Interest | 15,362 |  |  | 2,236 |  |  | 3,695 |  |  | 2,374 |  |  | 7,057 |  |
| Tax obligations | 202 |  |  | 19 |  |  | 39 |  |  | 84 |  |  | 60 |  |
| Contractual cash obligations | $ | 76,264 |  |  | $ | 16,665 |  |  | $ | 21,309 |  |  | $ | 18,698 |  |  | $ | 19,592 |  |

[0001571996-19-000008:mdna:301]
Principal Payments on Long-Term Debt — Our expected principal cash payments on borrowings are exclusive of discounts and premiums.  We have outstanding long-term notes with varying maturities.  As of February 1, 2019, the future principal payments related to our DFS debt were expected to be $3.1 billion in Fiscal 2020, $2.7 billion in Fiscal 2021-2022, and $108 million in Fiscal 2023-2024.  For additional information about our debt, see Note 6 of the Notes to the Consolidated Financial Statements included in this report.

[0001571996-19-000008:mdna:302]
Operating Leases — We lease property and equipment, manufacturing facilities, and office space under non-cancelable leases.  Certain of these leases obligate us to pay taxes, maintenance, and repair costs.

[0001571996-19-000008:mdna:303]
Purchase Obligations — Purchase obligations are defined as contractual obligations to purchase goods or services that are enforceable and legally binding on us.  These obligations specify all significant terms, including fixed or minimum quantities to be purchased; fixed, minimum, or variable price provisions; and the approximate timing of the transaction.  Purchase obligations do not include contracts that may be canceled without penalty.

[0001571996-19-000008:mdna:304]
We utilize several suppliers to manufacture sub-assemblies for our products.  Our efficient supply chain management allows us to enter into flexible and mutually beneficial purchase arrangements with our suppliers in order to minimize inventory risk.  Consistent with industry practice, we acquire raw materials or other goods and services, including product components, by issuing to suppliers authorizations to purchase based on our projected demand and manufacturing needs.  These purchase orders are typically fulfilled within 30 days and are entered into during the ordinary course of business in order to establish best pricing and continuity of supply for our production.  Purchase orders are not included in purchase obligations, as they typically represent our authorization to purchase rather than binding purchase obligations.

[0001571996-19-000008:mdna:305]
Interest — See Note 6 of the Notes to the Consolidated Financial Statements included in this report for further discussion of our debt and related interest expense.

[0001571996-19-000008:mdna:306]
Tax Obligations — Tax obligations represent a one-time mandatory deemed repatriation tax on undistributed earnings of foreign subsidiaries, payable over eight years.  Excluded from the table above are $3.4 billion in additional liabilities associated with uncertain tax positions as of February 1, 2019.  We are unable to reliably estimate the expected payment dates for any liabilities for uncertain tax positions.  See Note 11 of the Notes to the Consolidated Financial Statements included in this report for more information on these tax matters.

[0001571996-19-000008:mdna:307]
Critical Accounting Policies

[0001571996-19-000008:mdna:308]
We prepare our financial statements in conformity with GAAP, which requires certain estimates, assumptions, and judgments to be made that may affect our Consolidated Statements of Financial Position and Consolidated Statements of Income.  Accounting policies that have a significant impact on our Consolidated Financial Statements are described in Note 2 of the Notes to the Consolidated Financial Statements included in this report.  The accounting estimates and assumptions discussed in this section are those that we consider to be the most critical.  We consider an accounting policy to be critical if the nature of the estimate or assumption is subject to a material level of judgment and if changes in those estimates or assumptions are reasonably likely to materially impact our Consolidated Financial Statements.  We have discussed the development, selection, and disclosure of our critical accounting policies with the Audit Committee of our board of directors.

[0001571996-19-000008:mdna:309]
Revenue Recognition — We sell a wide portfolio of products and services offerings to our customers.  Our agreements have varying requirements depending on the goods and services being sold, the rights and obligations conveyed, and the legal jurisdiction of the arrangement.

[0001571996-19-000008:mdna:310]
Revenue is recognized for these arrangements based on the following five steps:

[0001571996-19-000008:mdna:311]
| (1) | Identify the contract with a customer. The term “contract” refers to the enforceable rights and obligations provided in an agreement between us and the customer in exchange for payment. We evaluate facts and circumstances regarding sales transactions in order to identify contracts with our customers. An agreement must meet all of the following criteria to qualify as a contract eligible for revenue recognition under the model: (i) the contract must be approved by all parties who are committed to perform their respective obligations; (ii) each party’s rights regarding the goods and services to be transferred to the customer can be identified; (iii) the payment terms for the goods and services can be identified; (iv) the customer has the ability and intent to pay and it is probable that we will collect substantially all of the consideration to which it will be entitled; and (v) the contract must have commercial substance. Judgment is used in determining the customer’s ability and intent to pay, which is based upon various factors including the customer’s historical payment experience or customer credit and financial information. |

[0001571996-19-000008:mdna:312]
| (2) | Identify the performance obligations in the contract. Our contracts with customers often include the promise to transfer multiple goods and services to a customer. Distinct promises within a contract are referred to as “performance obligations” and are accounted for as separate units of account. We assess whether each promised good or service is distinct for the purpose of identifying the performance obligations in the contract. This assessment involves subjective determinations and requires management to make judgments about the individual promised goods or services and whether such goods or services are separable from the other aspects of the contractual relationship. Promised goods and services are considered distinct provided that: (i) the customer can benefit from the good or service either on its own or together with other resources that are readily available to the customer (that is, the good or service is capable of being distinct); and (ii) our promise to transfer the good or service to the customer is separately identifiable from other promises in the contract (that is, the promise to transfer the good or service is distinct within the context of the contract). Our performance obligations include various distinct goods and services such as hardware, software licenses, warranties, and other service offerings and solutions. Promised goods and services are explicitly identified in our contracts and may be sold on a standalone basis or bundled as part of a combined solution. In certain hardware solutions, the hardware is highly interdependent on, and interrelated with the embedded software. In these offerings, the hardware and software licenses are accounted for as a single performance obligation. |

[0001571996-19-000008:mdna:313]
| (3) | Determine the transaction price. The transaction price reflects the amount of consideration to which we expect to be entitled in exchange for transferring goods or services to the customer. If the consideration promised in a contract includes a variable amount, we estimate the amount to which we expect to be entitled using either the expected value or most likely amount method. Generally, volume discounts, rebates, and sales returns reduce the transaction price. When we determine the transaction price, we only include amounts that are not subject to significant future reversal. |

[0001571996-19-000008:mdna:314]
| (4) | Allocate the transaction price to performance obligations in the contract. When a contract includes multiple performance obligations, the transaction price is allocated to each performance obligation in an amount that depicts the consideration to which we expect to be entitled in exchange for transferring the promised goods or services. For contracts with multiple performance obligations, the transaction price is allocated in proportion to the standalone selling price (“SSP”) of each performance obligation. |

[0001571996-19-000008:mdna:315]
74

[0001571996-19-000008:mdna:316]
The best evidence of SSP is the observable price of a good or service when we sell that good or service separately in similar circumstances to similar customers.  If a directly observable price is available, we utilize that price for the SSP.  If a directly observable price is not available, the SSP must be estimated.  We estimate SSP by considering multiple factors, including, but not limited to, pricing practices, internal costs, and profit objectives as well as overall market conditions, which include geographic or regional specific factors, competitive positioning, and competitor actions.

[0001571996-19-000008:mdna:317]
| (5) | Recognize revenue when (or as) the performance obligation is satisfied. Revenue is recognized when obligations under the terms of the contract with our customer are satisfied. Revenue is recognized either over time or at a point in time, depending on when the underlying products or services are transferred to the customer. Revenue is recognized at a point in time for products upon transfer of control. Revenue is recognized over time for support and deployment services, software support, SaaS, and IaaS. Revenue is recognized either over time or at a point in time for professional services and training depending on the nature of the offering to the customer. |

[0001571996-19-000008:mdna:318]
We report revenue net of any revenue-based taxes assessed by governmental authorities that are imposed on and concurrently with specific revenue-producing transactions.

[0001571996-19-000008:mdna:319]
We elected the following practical expedients with the adoption of the new revenue standard:

[0001571996-19-000008:mdna:320]
| • | We do not account for significant financing components if the period between revenue recognition and when the customer pays for the product or service will be one year or less. |

[0001571996-19-000008:mdna:321]
| • | We recognize revenue equal to the amount we have a right to invoice when the amount corresponds directly with the value to the customer of our performance to date. |

[0001571996-19-000008:mdna:322]
| • | We do not account for shipping and handling activities as a separate performance obligation, but rather as an activity performed to transfer the promised good. |

[0001571996-19-000008:mdna:323]
The following summarizes the nature of revenue recognized and the manner in which we account for sales transactions.

[0001571996-19-000008:mdna:324]
Products

[0001571996-19-000008:mdna:325]
Product revenue consists of hardware and software license sales that are delivered, sold as a subscription, or sold on a consumption basis.  Hardware includes notebooks and desktop PCs, servers, storage hardware, and other hardware-related devices.  Software license sales include non-essential software applications.  Software applications provide customers with resource management, backup and archiving, information security, information management and intelligence, data analytics, and server virtualization capabilities.

[0001571996-19-000008:mdna:326]
Revenue from the sale of hardware products is recognized when control has transferred to the customer, which typically occurs when the hardware has been shipped to the customer, risk of loss has transferred to the customer, we have a present right to payment, and customer acceptance has been satisfied.  Customer acceptance is satisfied if acceptance is obtained from the customer, if all acceptance provisions lapse, or if we have evidence that all acceptance provisions will be, or have been, satisfied.  Revenue from software license sales is generally recognized when control has transferred to the customer, which is typically upon shipment, electronic delivery, or when the software is available for download by the customer.  For certain software arrangements in which the customer is granted a right to additional unspecified future software licenses, our promise to the customer is considered a stand-ready obligation in which the transfer of control, and revenue recognition, will be over time.  Invoices for products are generally issued as control transfers, which is typically upon shipment or delivery.  There was no significant revenue in any period presented related to performance obligations satisfied or partially satisfied in prior periods.

[0001571996-19-000008:mdna:327]
Services

[0001571996-19-000008:mdna:328]
Services revenue consists of revenue from sales of support services, including hardware support that extends beyond our standard warranties, software maintenance, and installation; professional services; training; SaaS; and IaaS.  Revenue associated with undelivered performance obligations is deferred and recorded when or as control is transferred to the customer.  Revenue from fixed-price support or maintenance contracts sold for both hardware and software is recognized on a straight-line basis over the period of performance because we are required to provide services at any given time.  Other services revenue is recognized when we perform the services and the customer receives and consumes the benefits.

[0001571996-19-000008:mdna:329]
Invoices for services may be issued at the start of a service term, which is typically the case for support and deployment services, or as services are rendered, which is typically the case for professional services, training, SaaS, and IaaS.

[0001571996-19-000008:mdna:330]
Other

[0001571996-19-000008:mdna:331]
Revenue from leasing arrangements is not subject to the revenue standard for contracts with customers and remains separately accounted for under existing lease accounting guidance.  We record revenue from the sale of equipment under sales-type leases as product revenue in an amount equal to the present value of minimum lease payments at the inception of the lease.  Sales-type leases also produce financing income, which is included in net products revenue in the Consolidated Statements of Income (Loss) and is recognized at effective rates of return over the lease term.  We also offer qualified customers fixed-term loans and revolving credit lines for the purchase of our products and services.  Financing income attributable to these loans is recognized in product net revenue on an accrual basis.

[0001571996-19-000008:mdna:332]
Disaggregation of Revenue — Our revenue is presented on a disaggregated basis on the Consolidated Statements of Income (Loss) and in Note 19 of the Notes to the Consolidated Financial Statements based on an evaluation of disclosures outside of the financial statements, information regularly reviewed by the chief operating decision maker for evaluating the financial performance of operating segments, and other information that is used to evaluate our financial performance or make resource allocations.  This information includes revenue from products and services, revenue from reportable segments, and revenue by major product categories within the segments.

[0001571996-19-000008:mdna:333]
Contract Assets — Contract assets are rights to consideration in exchange for goods or services that we have transferred to a customer when such a right is conditional on something other than the passage of time.  Such amounts have been insignificant to date.

[0001571996-19-000008:mdna:334]
Contract Liabilities — Contract liabilities primarily consist of deferred revenue.  Deferred revenue is recorded when we have a right to invoice or payments have been received for undelivered products or services, or in situations where revenue recognition criteria have not been met.  Deferred revenue also represents amounts received in advance for extended warranty services and software maintenance.  Revenue is recognized on these items when the revenue recognition criteria are met, generally resulting in ratable recognition over the contract term.  We also have deferred revenue related to undelivered hardware and professional services, consisting of installations and consulting engagements, which are recognized when our performance obligations under the contract are completed.  See Note 9 of the Notes to the Consolidated Financial Statements included in this report for additional information about deferred revenue.

[0001571996-19-000008:mdna:335]
Costs to Obtain a Contract — The incremental direct costs of obtaining a contract primarily consist of sales commissions and employer taxes related to commission payments.  We elected, as a practical expedient, to expense as incurred costs to obtain a contract equal to or less than one year in duration.  For contracts greater than one year in duration, the associated costs to obtain a contract are deferred and amortized over the period of contract performance or a longer period, generally the estimated life of the customer relationship, if renewals are expected and the renewal commission is not commensurate with the initial commission.  Deferred costs to obtain a contract are typically amortized over a period of three to seven years, depending on the contract term and expectation of the period of benefit for the costs, which may exceed the contract term.  Amortization expense is recognized on a straight-line basis and included in selling, general, and administrative expenses in the Consolidated Statements of Income (Loss).  We periodically review these deferred costs to determine whether events or changes in circumstances have occurred that could impact the carrying value or period of benefit of the deferred sales commissions.

[0001571996-19-000008:mdna:336]
Deferred Revenue — Deferred revenue is recorded when we have a right to invoice or payments have been received for undelivered products or services in contracts where transfer of control has not occurred.  Deferred revenue represents amounts received in advance for support and deployment services, software maintenance, professional services, training, SaaS, and IaaS.  Revenue is recognized on these items when the revenue recognition criteria are met, generally resulting in ratable recognition over the contract term.  We also have deferred revenue related to undelivered hardware and professional services, consisting of installations and consulting engagements, which are recognized as our performance obligations under the contract are completed.

[0001571996-19-000008:mdna:337]
76

[0001571996-19-000008:mdna:338]
Business Combinations and Intangible Assets, Including Goodwill — We account for business combinations using the acquisition method of accounting, and, accordingly, the assets and liabilities of the acquired business are recorded at their fair values at the date of acquisition.  The excess of the purchase price over the estimated fair value is recorded as goodwill.  Any changes in the estimated fair values of the net assets recorded for acquisitions prior to the finalization of more detailed analysis, but not to exceed one year from the date of acquisition, will change the amount of the purchase price allocable to goodwill.  The cumulative impact of any subsequent changes to any purchase price allocations that are material to our consolidated financial results will be adjusted in the reporting period in which the adjustment amount is determined.  All acquisition costs are expensed as incurred.  Identifiable intangible assets with finite lives are amortized over their estimated useful lives.  In-process research and development costs are recorded at fair value as an indefinite-lived intangible asset and assessed for impairment thereafter until completion, at which point the asset is amortized over its expected useful life.  Separately recognized transactions associated with business combinations are generally expensed subsequent to the acquisition date.  The application of business combination and impairment accounting requires the use of significant estimates and assumptions.

[0001571996-19-000008:mdna:339]
The results of operations of acquired businesses are included in our Consolidated Financial Statements from the acquisition date.

[0001571996-19-000008:mdna:340]
Goodwill and indefinite-lived intangible assets are tested for impairment annually during the third fiscal quarter and whenever events or circumstances may indicate that an impairment has occurred.  To determine whether goodwill is impaired, we first assess certain qualitative factors.  Based on this assessment, if it is determined more likely than not that the fair value of a goodwill reporting unit is less than its carrying amount, we perform the quantitative analysis of the goodwill impairment test.  The fair value of each of our goodwill reporting units is generally estimated using a combination of public company multiples and discounted cash flow methodologies, and then compared to the carrying value of each goodwill reporting unit.

[0001571996-19-000008:mdna:341]
Standard Warranty Liabilities — We record warranty liabilities at the time of sale for the estimated costs that may be incurred under the terms of the limited warranty.  The liability for standard warranties is included in accrued and other current and other non-current liabilities on the Consolidated Statements of Financial Position.  The specific warranty terms and conditions vary depending upon the product sold and the country in which we do business, but generally include technical support, parts, and labor over a period ranging from one to three years.  Factors that affect our warranty liability include the number of installed units currently under warranty, historical and anticipated rates of warranty claims on those units, and cost per claim to satisfy our warranty obligation.  The anticipated rate of warranty claims is the primary factor impacting our estimated warranty obligation.  The other factors are less significant due to the fact that the average remaining aggregate warranty period of the covered installed base is approximately 16 months, repair parts are generally already in stock or available at pre-determined prices, and labor rates are generally arranged at pre-established amounts with service providers.  Warranty claims are reasonably predictable based on historical experience of failure rates.  If actual results differ from our estimates, we revise our estimated warranty liability to reflect such changes.  Each quarter, we reevaluate our estimates to assess the adequacy of the recorded warranty liabilities and adjust the amounts as necessary.

[0001571996-19-000008:mdna:342]
Income Taxes — We are subject to income tax in the United States and numerous foreign jurisdictions.  Significant judgments are required in determining the consolidated provision for income taxes.  We calculate a provision for income taxes using the asset and liability method, under which deferred tax assets and liabilities are recognized by identifying the temporary differences arising from the different treatment of items for tax and accounting purposes.  We account for the tax impact of including Global Intangible Low-Taxed Income (GILTI) in U.S. taxable income as a period cost.  We provide related valuation allowances for deferred tax assets, where appropriate.  Significant judgment is required in determining any valuation allowance against deferred tax assets.  In assessing the need for a valuation allowance, we consider all available evidence for each jurisdiction, including past operating results, estimates of future taxable income, and the feasibility of ongoing tax planning strategies.  In the event we determine that all or part of the net deferred tax assets are not realizable in the future, we will make an adjustment to the valuation allowance that would be charged to earnings in the period such determination is made.

[0001571996-19-000008:mdna:343]
Significant judgment is also required in evaluating our uncertain tax positions.  Although we believe our tax return positions are sustainable, we recognize tax benefits from uncertain tax positions in the financial statements only when it is more likely than not that the positions will be sustained upon examination, including resolution of any related appeals or litigation processes, based on the technical merits and a consideration of the relevant taxing authority’s administrative practices and precedents.  To the extent that the final tax outcome of these matters is different from the amounts recorded, such differences will impact the provision for income taxes in the period in which such determination is made.  The provision for income taxes includes the impact of reserve provisions and changes to reserves that are considered appropriate, as well as the related net interest and penalties.  We believe we have provided adequate reserves for all uncertain tax positions.

[0001571996-19-000008:mdna:344]
Loss Contingencies — We are subject to the possibility of various losses arising in the ordinary course of business.  We consider the likelihood of loss or impairment of an asset or the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss, in determining loss contingencies.  An estimated loss contingency is accrued when it is probable that an asset has been impaired or a liability has been incurred and the amount of loss can be reasonably estimated.  We regularly evaluate current information available to us to determine whether such accruals should be adjusted and whether new accruals are required.  Third parties have in the past asserted, and may in the future assert, claims or initiate litigation related to exclusive patent, copyright, and other intellectual property rights to technologies and related standards that are relevant to us.  If any infringement or other intellectual property claim made against us by any third party is successful, or if we fail to develop non-infringing technology or license the proprietary rights on commercially reasonable terms and conditions, our business, operating results, and financial condition could be materially and adversely affected.

[0001571996-19-000008:mdna:345]
Inventories — We state our inventory at the lower of cost or market.  We record a write-down for inventories of components and products, including third-party products held for resale, which have become obsolete or are in excess of anticipated demand or net realizable value.  We perform a detailed review of inventory each fiscal quarter that considers multiple factors, including demand forecasts, product life cycle status, product development plans, current sales levels, and component cost trends.  The industries in which we compete are subject to demand changes.  If future demand or market conditions for our products are less favorable than forecasted or if unforeseen technological changes negatively impact the utility of component inventory, we may be required to record additional write-downs, which would adversely affect our gross margin.

[0001571996-19-000008:mdna:346]
Recently Issued Accounting Pronouncements

[0001571996-19-000008:mdna:347]
See Note 2 of the Notes to the Consolidated Financial Statements included in this report for a summary of recently issued accounting pronouncements that are applicable to our Consolidated Financial Statements.

[0001571996-19-000008:mdna:348]
78
