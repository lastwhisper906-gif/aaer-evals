# DELL 8-K — 0001571996-19-000002 filed 2019-02-28

## item codes, every 8-K on or before 2019-03-29

- 2019-03-21 0001193125-19-082281 — 1.01, 1.02, 2.03, 9.01
- 2019-03-19 0001571996-19-000005 — 5.02, 9.01
- 2019-03-14 0001193125-19-074935 — 1.01, 2.03, 9.01
- 2019-03-07 0001193125-19-066045 — 8.01, 9.01
- 2019-02-28 0001571996-19-000002 — 2.02, 9.01
- 2018-12-28 0001193125-18-360943 — 1.01, 1.02, 3.01, 3.03, 5.02, 5.03, 7.01, 8.01, 9.01
- 2018-12-21 0001193125-18-356324 — 1.01, 2.03, 9.01
- 2018-12-14 0001193125-18-349469 — 8.01
- 2018-12-11 0001193125-18-346958 — 5.07, 8.01, 9.01
- 2018-11-29 0001571996-18-000041 — 2.02, 9.01
- 2018-11-28 0001571996-18-000037 — 7.01, 8.01, 9.01
- 2018-11-26 0001193125-18-333967 — 8.01, 9.01
- 2018-11-15 0001193125-18-328110 — 1.01, 9.01 — amendment of 0001193125-18-327222
- 2018-11-15 0001193125-18-327222 — 1.01, 7.01, 9.01
- 2018-10-03 0001193125-18-291390 — 8.01
- 2018-09-06 0001571996-18-000029 — 2.02, 9.01
- 2018-08-06 0001571996-18-000027 — 8.01, 9.01
- 2018-07-02 0001193125-18-210339 — 1.01, 7.01, 9.01
- 2018-06-28 0001571996-18-000024 — 5.07
- 2018-06-04 0001571996-18-000019 — 2.02, 9.01
- 2018-05-17 0001571996-18-000016 — 7.01
- 2018-04-26 0001571996-18-000009 — 7.01, 9.01
- 2018-03-08 0001193125-18-074168 — 2.02, 9.01
- 2018-02-02 0001193125-18-029947 — 7.01, 9.01
- 2017-12-07 0001571996-17-000042 — 2.02, 9.01
- 2017-10-24 0001571996-17-000037 — 1.01, 2.03, 9.01
- 2017-09-15 0001571996-17-000027 — 5.02
- 2017-09-07 0001571996-17-000017 — 2.02, 9.01
- 2017-08-24 0001571996-17-000014 — 8.01
- 2017-06-29 0001571996-17-000011 — 3.03, 5.07, 8.01, 9.01
- 2017-06-08 0001193125-17-197638 — 2.02, 9.01
- 2017-03-30 0001193125-17-102794 — 8.01
- 2017-03-30 0001193125-17-102777 — 2.02, 9.01
- 2017-03-09 0001193125-17-076981 — 1.01, 2.03, 9.01
- 2017-01-17 0001193125-17-011125 — 8.01
- 2016-12-15 0001193125-16-793722 — 8.01
- 2016-12-08 0001193125-16-787976 — 2.02, 9.01
- 2016-11-10 0001193125-16-765964 — 1.02, 8.01
- 2016-11-04 0001193125-16-760249 — 8.01
- 2016-09-13 0001193125-16-708600 — 3.02
- 2016-09-09 0001193125-16-706567 — 1.01, 1.02, 2.01, 2.03, 3.02, 3.03, 5.02, 9.01
- 2016-09-07 0001193125-16-703370 — 3.03, 5.07, 7.01, 8.01, 9.01
- 2016-09-06 0001193125-16-702057 — 2.02, 9.01
- 2016-08-31 0001193125-16-697268 — 8.01, 9.01
- 2016-08-26 0001193125-16-692921 — 8.01, 9.01
- 2016-07-11 0001193125-16-645610 — 8.01
- 2016-07-05 0001193125-16-641679 — 8.01
- 2016-06-22 0001193125-16-629055 — 1.01, 2.03, 8.01, 9.01
- 2016-06-21 0001193125-16-627071 — 8.01, 9.01
- 2016-06-10 0001193125-16-618483 — 2.02, 9.01
- 2016-06-09 0001193125-16-617893 — 8.01, 9.01

## late-filing notifications on or before 2019-03-29

- none on or before 2019-03-29

## item 2.02 — earnings release, exhibit 99.1

[0001571996-19-000002:8k_2_02:1]
EX-99.1
2
exhibit991earnings8k.htm
EXHIBIT 99.1

[0001571996-19-000002:8k_2_02:2]
Exhibit

[0001571996-19-000002:8k_2_02:3]
Exhibit 99.1

[0001571996-19-000002:8k_2_02:4]
News Release

[0001571996-19-000002:8k_2_02:5]
Dell Technologies Reports Fiscal Year 2019 Fourth Quarter

[0001571996-19-000002:8k_2_02:6]
and Full Year Financial Results

[0001571996-19-000002:8k_2_02:7]
ROUND ROCK, Texas — February 28, 2019

[0001571996-19-000002:8k_2_02:8]
News summary

[0001571996-19-000002:8k_2_02:9]
| • | Fourth quarter GAAP revenue of $23.8 billion, up 9 percent; non-GAAP fourth quarter revenue of $24.0 billion, up 8 percent |

[0001571996-19-000002:8k_2_02:10]
| • | Full year GAAP revenue of $90.6 billion, up 15 percent; non-GAAP full year revenue of $91.3 billion, up 14 percent |

[0001571996-19-000002:8k_2_02:11]
| • | Full year operating loss reduced by 92 percent to $191 million; non-GAAP full year operating income of $8.9 billion, up 14 percent |

[0001571996-19-000002:8k_2_02:12]
| • | Double-digit revenue growth for the full year across all three business units: ISG, CSG and VMware |

[0001571996-19-000002:8k_2_02:13]
Full story

[0001571996-19-000002:8k_2_02:14]
Dell Technologies (NYSE: DELL) announces its fiscal 2019 fourth quarter and full year results. For the fourth quarter, revenue was $23.8 billion, up 9 percent, and non-GAAP revenue was $24.0 billion, up 8 percent over the same period in the prior year. During the quarter, the company generated operating income of $331 million1, versus an operating loss of $69 million in the fourth quarter of the prior year. Fourth quarter non-GAAP operating income was $2.7 billion. Cash flow from operations was approximately $2.4 billion.

[0001571996-19-000002:8k_2_02:15]
For the full year, revenue was $90.6 billion, up 15 percent, and non-GAAP revenue was $91.3 billion, up 14 percent over the prior year. The company reduced its operating loss by 92 percent to $191 million, and generated a non-GAAP operating income of $8.9 billion, up 14 percent over the prior year. Cash flow from operations was $7.0 billion. During the year, net loss decreased 25 percent to $2.1 billion and adjusted EBITDA increased 13 percent to $10.3 billion.

[0001571996-19-000002:8k_2_02:16]
“I am pleased with our strong fourth quarter and fiscal 2019 velocity and financial performance, including double-digit revenue growth for the year across all three business units and profitable share gains across our portfolio,” said Tom Sweet, chief financial officer, Dell Technologies. “In fiscal 2020 we’ll continue to run the business in a disciplined way.  We will remain focused on generating long-term relative growth, share gain and cash flow while driving long-term value for shareholders and serving our customers’ full range of needs.”

[0001571996-19-000002:8k_2_02:17]
The company ended the year with a cash and investments balance of $10.7 billion. Since closing the EMC transaction, Dell Technologies has paid down approximately $14.6 billion in gross debt, excluding Dell Financial Services related and subsidiary debt.

[0001571996-19-000002:8k_2_02:18]
“Fiscal 2019 was a year of great progress and momentum. We advanced our leading portfolio through a focus on innovation, added new customers through both direct and channel growth, and delivered solutions from the edge to the core to the cloud,” said Jeff Clarke, vice chairman, Products & Operations, Dell Technologies. “As data growth continues to explode alongside technology trends like 5G, AI and machine learning, we’ll continue to drive a wave of innovations to unlock the power of our customers’ data capital.”

[0001571996-19-000002:8k_2_02:19]
Fiscal year 2019 fourth quarter and full year results

[0001571996-19-000002:8k_2_02:20]
|  | Three Months Ended |  |  |  | Fiscal Year Ended |  |  |
|  | February 1, 2019 |  | February 2, 2018 |  | Change |  | February 1, 2019 |  | February 2, 2018 |  | Change |
|  | (in millions, except percentages; unaudited) |
| Total net revenue | $ | 23,841 |  |  | $ | 21,963 |  |  | 9% |  | $ | 90,621 |  |  | $ | 79,040 |  |  | 15% |
| Operating income (loss) | $ | 331 |  |  | $ | (69 | ) |  | 580% |  | $ | (191 | ) |  | $ | (2,416 | ) |  | 92% |
| Net loss | $ | (287 | ) |  | $ | (133 | ) |  | (116)% |  | $ | (2,181 | ) |  | $ | (2,926 | ) |  | 25% |
| Non-GAAP net revenue | $ | 24,008 |  |  | $ | 22,247 |  |  | 8% |  | $ | 91,324 |  |  | $ | 80,309 |  |  | 14% |
| Non-GAAP operating income | $ | 2,656 |  |  | $ | 2,372 |  |  | 12% |  | $ | 8,854 |  |  | $ | 7,772 |  |  | 14% |
| Non-GAAP net income | $ | 1,592 |  |  | $ | 1,268 |  |  | 26% |  | $ | 5,227 |  |  | $ | 4,355 |  |  | 20% |
| Adjusted EBITDA | $ | 3,028 |  |  | $ | 2,718 |  |  | 11% |  | $ | 10,296 |  |  | $ | 9,134 |  |  | 13% |

[0001571996-19-000002:8k_2_02:21]
Information about Dell Technologies’ use of non-GAAP financial information is provided under “Non-GAAP Financial Measures” below. All comparisons in this press release are year over year unless otherwise noted.

[0001571996-19-000002:8k_2_02:22]
Operating segments summary

[0001571996-19-000002:8k_2_02:23]
Infrastructure Solutions Group revenue for the fourth quarter was $9.9 billion, a 10  percent increase year over year. This was driven by $5.3 billion in servers and networking revenue, a 14 percent increase, and $4.6 billion in storage revenue, a 7 percent increase year over year. Revenue for the full year was $36.7 billion, up 19 percent with servers and networking revenue of $20.0 billion, up 28 percent, and storage revenue of $16.7 billion, up 9 percent year over year.  Operating income was  $1.3 billion for the fourth quarter, up 21 percent, and $4.2 billion for the full year, up 35 percent year over year.

[0001571996-19-000002:8k_2_02:24]
Key highlights:

[0001571996-19-000002:8k_2_02:25]
| • | Double-digit ISG revenue growth across all four quarters |

[0001571996-19-000002:8k_2_02:26]
| • | Storage revenue growth in all four quarters |

[0001571996-19-000002:8k_2_02:27]
| • | Servers and networking delivered 28 percent revenue growth for the fiscal year, achieving nine consecutive quarters of revenue growth |

[0001571996-19-000002:8k_2_02:28]
| • | Industry leading x86 server share2 increased another 1.4 percent through the third quarter of calendar year 2018 (calendar fourth quarter results will be published on March 6) |

[0001571996-19-000002:8k_2_02:29]
| • | Gained storage share3 for three straight quarters in calendar year 2018 (calendar fourth quarter results will be published on March 7) |

[0001571996-19-000002:8k_2_02:30]
| • | VxRail grew triple digits on a demand basis again in the fourth quarter |

[0001571996-19-000002:8k_2_02:31]
Client Solutions Group revenue for the fiscal fourth quarter was $10.9 billion, up 4 percent versus the fourth quarter of last year.  Commercial revenue grew 9 percent to $7.8 billion, and Consumer revenue was down 6 percent to $3.1 billion. Client Solutions Group revenue for the full year was $43.2 billion, up 10 percent. Operating income was $555 million for the fourth quarter, or 5.1 percent of Client Solutions Group revenue, and $2.0 billion for the full year.

[0001571996-19-000002:8k_2_02:32]
Key highlights:

[0001571996-19-000002:8k_2_02:33]
| • | Year-over-year worldwide PC share4 growth for 24th consecutive quarter |

[0001571996-19-000002:8k_2_02:34]
| • | Double-digit revenue growth in commercial notebooks and workstations, as well as high-end consumer notebooks and displays |

[0001571996-19-000002:8k_2_02:35]
| • | Reached 20 percent worldwide share position in displays, gaining unit share5 year-over-year for the 23rd consecutive quarter |

[0001571996-19-000002:8k_2_02:36]
| • | Record-high 144 product awards and honors at the Consumer Electronics Show, more than any other company in our industry |

[0001571996-19-000002:8k_2_02:37]
VMware revenue was $2.6 billion for the quarter, up 17 percent, and $9.1 billion for the full year, up 14 percent. Operating income for the quarter was $872 million, or 33 percent of VMware revenue, and $3.0 billion for the full year, or 33 percent of VMware revenue.

[0001571996-19-000002:8k_2_02:38]
Key fourth quarter collaboration highlights:

[0001571996-19-000002:8k_2_02:39]
| • | VMware and Pivotal announced availability of the new VMware PKS Solution Competency |

[0001571996-19-000002:8k_2_02:40]
| • | Dell EMC PowerMax and Dell EMC Unity qualified as external storage arrays with VMware Cloud Foundation |

[0001571996-19-000002:8k_2_02:41]
| • | Virtustream Enterprise Cloud announced as a VMware Cloud Verified service |

[0001571996-19-000002:8k_2_02:42]
Fourth quarter revenue from other businesses, including Pivotal, Secureworks, RSA Security, Virtustream and Boomi, was $593 million, up 5 percent year over year.  Revenue from other businesses for the full year was $2.3 billion, up 6 percent.

[0001571996-19-000002:8k_2_02:43]
Conference call information

[0001571996-19-000002:8k_2_02:44]
As previously announced, the company will hold a conference call to discuss its fourth quarter and full-year performance today at 5:00 p.m. CST. The conference call will be broadcast live over the internet and can be accessed at investors.delltechnologies.com. For those unable to listen to the live broadcast, an archived version will be available at the same location for one year.

[0001571996-19-000002:8k_2_02:45]
A slide presentation containing additional financial and operating information may be downloaded from Dell Technologies’ website at investors.delltechnologies.com.

[0001571996-19-000002:8k_2_02:46]
Dell Technologies World

[0001571996-19-000002:8k_2_02:47]
Join us April 29 - May 2 in Las Vegas at Dell Technologies World, the company’s flagship event that brings together latest emerging trends, technology and gurus, from the edge to the core to the cloud. During the event, experts from all of Dell Technologies businesses will demonstrate to customers and partners the connected ecosystem of IT infrastructure, applications, devices and security that can enable real transformation across their organizations. Register here.

[0001571996-19-000002:8k_2_02:48]
About Dell Technologies

[0001571996-19-000002:8k_2_02:49]
Dell Technologies (NYSE:DELL) is a unique family of businesses that helps organizations and individuals build their digital future and transform how they work and live. The company provides customers with the industry’s broadest and most innovative technology and services portfolio spanning from edge to core to cloud.  The Dell Technologies family includes Dell, Dell EMC, Pivotal, RSA, Secureworks, Virtustream and VMware.

[0001571996-19-000002:8k_2_02:50]
CONTACTS:

[0001571996-19-000002:8k_2_02:51]
Investor Relations: Investor_Relations@Dell.com

[0001571996-19-000002:8k_2_02:52]
Media Relations: Media.Relations@Dell.com

[0001571996-19-000002:8k_2_02:53]
# # #

[0001571996-19-000002:8k_2_02:54]
Copyright © 2019 Dell Inc. or its subsidiaries. All Rights Reserved. Dell Technologies, Dell, EMC and Dell EMC are trademarks of Dell Inc. or its subsidiaries. Other trademarks may be trademarks of their respective owners.

[0001571996-19-000002:8k_2_02:55]
| 1 | Due to the EMC transaction, significant non-cash bridging items will remain between GAAP and non-GAAP results for the next few years. |

[0001571996-19-000002:8k_2_02:56]
| 2 | IDC WW Quarterly Server Tracker CY18Q3 |

[0001571996-19-000002:8k_2_02:57]
| 3 | IDC WW Quarterly External Storage Systems Tracker CY18Q3 |

[0001571996-19-000002:8k_2_02:58]
| 4 | IDC WW Quarterly Personal Computing Device (PCD) Tracker CY18Q4 |

[0001571996-19-000002:8k_2_02:59]
| 5 | IDC PC Monitor Tracker CY18Q4 |

[0001571996-19-000002:8k_2_02:60]
Non-GAAP Financial Measures:

[0001571996-19-000002:8k_2_02:61]
This press release presents information about Dell Technologies’ non-GAAP net revenue, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP net income, EBITDA and adjusted EBITDA, which are non-GAAP financial measures provided as a supplement to the results provided in accordance with generally accepted accounting principles in the United States of America (“GAAP”). A reconciliation of each non-GAAP financial measure to the most directly comparable historical GAAP financial measure is provided in the attached tables for each of the fiscal periods indicated.

[0001571996-19-000002:8k_2_02:62]
Special Note on Forward-Looking Statements:

[0001571996-19-000002:8k_2_02:63]
Dell Technologies’ results or events in future periods could differ materially from those expressed or implied by these forward-looking statements because of risks, uncertainties, and other factors that include, but are not limited to, the following: competitive pressures; Dell Technologies’ reliance on third-party suppliers for products and components, including reliance on single-source or limited-source suppliers; Dell Technologies’ ability to achieve favorable pricing from its vendors; adverse global economic conditions and instability in financial markets; Dell Technologies’ execution of its growth, business and acquisition strategies; the success of Dell Technologies’ cost efficiency measures; Dell Technologies’ ability to manage solutions and products and services transitions in an effective manner; Dell Technologies’ ability to deliver high-quality products and services; Dell Technologies’ foreign operations and ability to generate substantial non-U.S. net revenue; Dell Technologies’ product, customer, and geographic sales mix, and seasonal sales trends; the performance of Dell Technologies’ sales channel partners; access to the capital markets by Dell Technologies or its customers; weak economic conditions and additional regulation; counterparty default risks; the loss by Dell Technologies of any services contracts with its customers, including government contracts, and its ability to perform such contracts at its estimated costs; Dell Technologies’ ability to develop and protect its proprietary intellectual property or obtain licenses to intellectual property developed by others on commercially reasonable and competitive terms; infrastructure disruptions, cyberattacks, or other data security breaches; Dell Technologies’ ability to hedge effectively its exposure to fluctuations in foreign currency exchange rates and interest rates; expiration of tax holidays or favorable tax rate structures, or unfavorable outcomes in tax audits and other tax compliance matters; impairment of portfolio investments; unfavorable results of legal proceedings; increased costs and additional regulations and requirements as a result of Dell Technologies’ operation as a public company; Dell Technologies’ ability to develop and maintain effective internal control over financial reporting; compliance requirements of changing environmental and safety laws; the effect of armed hostilities, terrorism, natural disasters, and public health issues; Dell Technologies’ substantial level of indebtedness; the impact of the financial performance of VMware; and the market volatility of Dell Technologies’ pension plan assets.

[0001571996-19-000002:8k_2_02:64]
This list of risks, uncertainties, and other factors is not complete. Dell Technologies discusses some of these matters more fully, as well as certain risk factors that could affect Dell Technologies’ business, financial condition, results of operations, and prospects, in its reports filed with the SEC, including Dell Technologies’ Annual Report on Form 10-K for the fiscal year ended February 2, 2018, quarterly reports on Form 10-Q, and current reports on Form 8-K. These filings are available for review through the SEC’s website at www.sec.gov. Any or all forward-looking statements Dell Technologies makes may turn out to be wrong and can be affected by inaccurate assumptions Dell Technologies might make or by known or unknown risks, uncertainties and other factors, including those identified in this press release. Accordingly, you should not place undue reliance on the forward-looking statements made in this press release, which speak only as of its date. Dell Technologies does not undertake to update, and expressly disclaims any duty to update, its forward-looking statements, whether as a result of circumstances or events that arise after the date they are made, new information, or otherwise.

[0001571996-19-000002:8k_2_02:65]
DELL TECHNOLOGIES INC.

[0001571996-19-000002:8k_2_02:66]
Condensed Consolidated Statements of Income (Loss) and Related Financial Highlights

[0001571996-19-000002:8k_2_02:67]
(in millions, except percentages; unaudited)

[0001571996-19-000002:8k_2_02:68]
|  | Three Months Ended |  |  |  | Fiscal Year Ended |  |  |
|  | February 1, 2019 |  | February 2, 2018 |  | Change |  | February 1, 2019 |  | February 2, 2018 |  | Change |
| Net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Products | $ | 18,842 |  |  | $ | 17,395 |  |  | 8% |  | $ | 71,287 |  |  | $ | 61,251 |  |  | 16% |
| Services | 4,999 |  |  | 4,568 |  |  | 9% |  | 19,334 |  |  | 17,789 |  |  | 9% |
| Total net revenue | 23,841 |  |  | 21,963 |  |  | 9% |  | 90,621 |  |  | 79,040 |  |  | 15% |
| Cost of net revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Products | 14,775 |  |  | 14,262 |  |  | 4% |  | 57,889 |  |  | 51,433 |  |  | 13% |
| Services | 1,957 |  |  | 1,809 |  |  | 8% |  | 7,679 |  |  | 7,070 |  |  | 9% |
| Total cost of net revenue | 16,732 |  |  | 16,071 |  |  | 4% |  | 65,568 |  |  | 58,503 |  |  | 12% |
| Gross margin | 7,109 |  |  | 5,892 |  |  | 21% |  | 25,053 |  |  | 20,537 |  |  | 22% |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |
| Selling, general, and administrative | 5,576 |  |  | 4,874 |  |  | 14% |  | 20,640 |  |  | 18,569 |  |  | 11% |
| Research and development | 1,202 |  |  | 1,087 |  |  | 11% |  | 4,604 |  |  | 4,384 |  |  | 5% |
| Total operating expenses | 6,778 |  |  | 5,961 |  |  | 14% |  | 25,244 |  |  | 22,953 |  |  | 10% |
| Operating income (loss) | 331 |  |  | (69 | ) |  | 580% |  | (191 | ) |  | (2,416 | ) |  | 92% |
| Interest and other, net | (606 | ) |  | (554 | ) |  | (9)% |  | (2,170 | ) |  | (2,353 | ) |  | 8% |
| Loss before income taxes | (275 | ) |  | (623 | ) |  | 56% |  | (2,361 | ) |  | (4,769 | ) |  | 50% |
| Income tax provision (benefit) | 12 |  |  | (490 | ) |  | 102% |  | (180 | ) |  | (1,843 | ) |  | 90% |
| Net loss | (287 | ) |  | (133 | ) |  | (116)% |  | (2,181 | ) |  | (2,926 | ) |  | 25% |
| Less: Net income (loss) attributable to non-controlling interests | 12 |  |  | (33 | ) |  | (136)% |  | 129 |  |  | (77 | ) |  | (268)% |
| Net loss attributable to Dell Technologies Inc. | $ | (299 | ) |  | $ | (100 | ) |  | (199)% |  | $ | (2,310 | ) |  | $ | (2,849 | ) |  | 19% |
| Percentage of Total Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Gross margin | 30 | % |  | 27 | % |  |  |  | 28 | % |  | 26 | % |  |  |
| Selling, general, and administrative | 23 | % |  | 22 | % |  |  |  | 23 | % |  | 23 | % |  |  |
| Research and development | 5 | % |  | 5 | % |  |  |  | 5 | % |  | 6 | % |  |  |
| Operating expenses | 28 | % |  | 27 | % |  |  |  | 28 | % |  | 29 | % |  |  |
| Operating income (loss) | 1 | % |  | — | % |  |  |  | — | % |  | (3 | )% |  |  |
| Loss before income taxes | (1 | )% |  | (3 | )% |  |  |  | (3 | )% |  | (6 | )% |  |  |
| Net loss | (1 | )% |  | (1 | )% |  |  |  | (2 | )% |  | (4 | )% |  |  |
| Income tax rate | (4.4 | )% |  | 78.7 | % |  |  |  | 7.6 | % |  | 38.6 | % |  |  |

[0001571996-19-000002:8k_2_02:69]
DELL TECHNOLOGIES INC.

[0001571996-19-000002:8k_2_02:70]
Consolidated Statements of Financial Position

[0001571996-19-000002:8k_2_02:71]
(in millions; unaudited)

[0001571996-19-000002:8k_2_02:72]
|  | February 1, 2019 |  | February 2, 2018 |
| ASSETS |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 9,676 |  |  | $ | 13,942 |  |
| Short-term investments | — |  |  | 2,187 |  |
| Accounts receivable, net | 12,371 |  |  | 11,721 |  |
| Short-term financing receivables, net | 4,398 |  |  | 3,919 |  |
| Inventories, net | 3,649 |  |  | 2,678 |  |
| Other current assets | 6,044 |  |  | 5,881 |  |
| Total current assets | 36,138 |  |  | 40,328 |  |
| Property, plant, and equipment, net | 5,259 |  |  | 5,390 |  |
| Long-term investments | 1,005 |  |  | 4,163 |  |
| Long-term financing receivables, net | 4,224 |  |  | 3,724 |  |
| Goodwill | 40,089 |  |  | 39,920 |  |
| Intangible assets, net | 22,270 |  |  | 28,265 |  |
| Other non-current assets | 2,835 |  |  | 2,403 |  |
| Total assets | $ | 111,820 |  |  | $ | 124,193 |  |
| LIABILITIES, REDEEMABLE SHARES, AND STOCKHOLDERS’ EQUITY (DEFICIT) |
| Current liabilities: |  |  |  |
| Short-term debt | $ | 8,062 |  |  | $ | 7,873 |  |
| Accounts payable | 19,213 |  |  | 18,334 |  |
| Accrued and other | 8,495 |  |  | 8,026 |  |
| Short-term deferred revenue | 12,944 |  |  | 11,606 |  |
| Total current liabilities | 48,714 |  |  | 45,839 |  |
| Long-term debt | 45,459 |  |  | 43,998 |  |
| Long-term deferred revenue | 11,066 |  |  | 9,210 |  |
| Other non-current liabilities | 6,327 |  |  | 7,277 |  |
| Total liabilities | 111,566 |  |  | 106,324 |  |
| Redeemable shares | 1,196 |  |  | 384 |  |
| Stockholders’ equity (deficit): |  |  |  |
| Total Dell Technologies Inc. stockholders’ equity (deficit) | (5,765 | ) |  | 11,719 |  |
| Non-controlling interests | 4,823 |  |  | 5,766 |  |
| Total stockholders’ equity (deficit) | (942 | ) |  | 17,485 |  |
| Total liabilities, redeemable shares, and stockholders’ equity (deficit) | $ | 111,820 |  |  | $ | 124,193 |  |

[0001571996-19-000002:8k_2_02:73]
DELL TECHNOLOGIES INC.

[0001571996-19-000002:8k_2_02:74]
Condensed Consolidated Statements of Cash Flows

[0001571996-19-000002:8k_2_02:75]
(in millions; unaudited)

[0001571996-19-000002:8k_2_02:76]
|  | Three Months Ended |  | Fiscal Year Ended |
|  | February 1, 2019 |  | February 2, 2018 |  | February 1, 2019 |  | February 2, 2018 |
| Cash flows from operating activities: |  |  |  |  |  |  |  |
| Net loss | $ | (287 | ) |  | $ | (133 | ) |  | $ | (2,181 | ) |  | $ | (2,926 | ) |
| Adjustments to reconcile net loss to net cash provided by operating activities | 2,653 |  |  | 3,232 |  |  | 9,172 |  |  | 9,769 |  |
| Change in cash from operating activities | 2,366 |  |  | 3,099 |  |  | 6,991 |  |  | 6,843 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |
| Investments: |  |  |  |  |  |  |  |
| Purchases | (13 | ) |  | (935 | ) |  | (925 | ) |  | (4,389 | ) |
| Maturities and sales | 4,427 |  |  | 885 |  |  | 6,612 |  |  | 3,878 |  |
| Capital expenditures | (297 | ) |  | (310 | ) |  | (1,158 | ) |  | (1,212 | ) |
| Proceeds from sale of facilities, land, and other assets | — |  |  | — |  |  | 10 |  |  | — |  |
| Capitalized software development costs | (93 | ) |  | (88 | ) |  | (339 | ) |  | (369 | ) |
| Collections on purchased financing receivables | 5 |  |  | 5 |  |  | 30 |  |  | 30 |  |
| Acquisition of businesses, net | (419 | ) |  | (435 | ) |  | (912 | ) |  | (658 | ) |
| Divestitures of businesses, net | — |  |  | — |  |  | 142 |  |  | — |  |
| Asset acquisitions, net | — |  |  | (1 | ) |  | (59 | ) |  | (96 | ) |
| Asset dispositions, net | — |  |  | (6 | ) |  | (12 | ) |  | (59 | ) |
| Change in cash from investing activities | 3,610 |  |  | (885 | ) |  | 3,389 |  |  | (2,875 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |
| Payment of dissenting shares obligation | — |  |  | — |  |  | (76 | ) |  | — |  |
| Share repurchases for tax withholdings of equity awards | (136 | ) |  | (86 | ) |  | (387 | ) |  | (385 | ) |
| Dividends paid by subsidiaries | (2,134 | ) |  | — |  |  | (2,134 | ) |  | — |  |
| Proceeds from the issuance of common stock of subsidiaries | 36 |  |  | 21 |  |  | 803 |  |  | 131 |  |
| Repurchases of DHI Group Common Stock | — |  |  | — |  |  | (47 | ) |  | (6 | ) |
| Repurchases of Class V Common Stock | (14,000 | ) |  | (1 | ) |  | (14,000 | ) |  | (723 | ) |
| Repurchases of common stock of subsidiaries | (55 | ) |  | (169 | ) |  | (56 | ) |  | (724 | ) |
| Payments for debt issuance costs | (17 | ) |  | (4 | ) |  | (28 | ) |  | (48 | ) |
| Proceeds from debt | 6,602 |  |  | 1,247 |  |  | 13,045 |  |  | 14,415 |  |
| Repayments of debt | (1,782 | ) |  | (1,130 | ) |  | (11,451 | ) |  | (12,258 | ) |
| Other | 1 |  |  | — |  |  | 2 |  |  | 1 |  |
| Change in cash from financing activities | (11,485 | ) |  | (122 | ) |  | (14,329 | ) |  | 403 |  |
| Effect of exchange rate changes on cash, cash equivalents, and restricted cash | 73 |  |  | 128 |  |  | (189 | ) |  | 175 |  |
| Change in cash, cash equivalents, and restricted cash | (5,436 | ) |  | 2,220 |  |  | (4,138 | ) |  | 4,546 |  |
| Cash, cash equivalents, and restricted cash at beginning of the period | 15,676 |  |  | 12,158 |  |  | 14,378 |  |  | 9,832 |  |
| Cash, cash equivalents, and restricted cash at end of the period | $ | 10,240 |  |  | $ | 14,378 |  |  | $ | 10,240 |  |  | $ | 14,378 |  |

[0001571996-19-000002:8k_2_02:77]
DELL TECHNOLOGIES INC.

[0001571996-19-000002:8k_2_02:78]
Segment Information

[0001571996-19-000002:8k_2_02:79]
(in millions, except percentages; unaudited; continued on next page)

[0001571996-19-000002:8k_2_02:80]
|  | Three Months Ended |  |  |  | Fiscal Year Ended |  |  |
|  | February 1, 2019 |  | February 2, 2018 |  | Change |  | February 1, 2019 |  | February 2, 2018 |  | Change |
| Infrastructure Solutions Group (ISG): |  |  |  |  |  |  |  |  |  |  |  |
| Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Servers and networking | $ | 5,253 |  |  | $ | 4,625 |  |  | 14% |  | $ | 19,953 |  |  | $ | 15,533 |  |  | 28% |
| Storage | 4,636 |  |  | 4,329 |  |  | 7% |  | 16,767 |  |  | 15,384 |  |  | 9% |
| Total ISG net revenue | $ | 9,889 |  |  | $ | 8,954 |  |  | 10% |  | $ | 36,720 |  |  | $ | 30,917 |  |  | 19% |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| ISG operating income | $ | 1,265 |  |  | $ | 1,045 |  |  | 21% |  | $ | 4,151 |  |  | $ | 3,068 |  |  | 35% |
| % of ISG net revenue | 13 | % |  | 12 | % |  |  |  | 11 | % |  | 10 | % |  |  |
| % of total reportable segment operating income | 47 | % |  | 43 | % |  |  |  | 46 | % |  | 39 | % |  |  |
| Client Solutions Group (CSG): |  |  |  |  |  |  |  |  |  |  |  |
| Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Commercial | $ | 7,808 |  |  | $ | 7,180 |  |  | 9% |  | $ | 30,893 |  |  | $ | 27,507 |  |  | 12% |
| Consumer | 3,084 |  |  | 3,295 |  |  | (6)% |  | 12,303 |  |  | 11,711 |  |  | 5% |
| Total CSG net revenue | $ | 10,892 |  |  | $ | 10,475 |  |  | 4% |  | $ | 43,196 |  |  | $ | 39,218 |  |  | 10% |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| CSG operating income | $ | 555 |  |  | $ | 561 |  |  | (1)% |  | $ | 1,960 |  |  | $ | 2,044 |  |  | (4)% |
| % of CSG net revenue | 5 | % |  | 5 | % |  |  |  | 5 | % |  | 5 | % |  |  |
| % of total reportable segment operating income | 21 | % |  | 23 | % |  |  |  | 21 | % |  | 26 | % |  |  |
| VMware: |  |  |  |  |  |  |  |  |  |  |  |
| Net Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Total VMware net revenue | $ | 2,637 |  |  | $ | 2,259 |  |  | 17% |  | $ | 9,088 |  |  | $ | 7,994 |  |  | 14% |
| Operating Income: |  |  |  |  |  |  |  |  |  |  |  |
| VMware operating income | $ | 872 |  |  | $ | 836 |  |  | 4% |  | $ | 2,989 |  |  | $ | 2,809 |  |  | 6% |
| % of VMware net revenue | 33 | % |  | 37 | % |  |  |  | 33 | % |  | 35 | % |  |  |
| % of total reportable segment operating income | 32 | % |  | 34 | % |  |  |  | 33 | % |  | 35 | % |  |  |

[0001571996-19-000002:8k_2_02:81]
DELL TECHNOLOGIES INC.

[0001571996-19-000002:8k_2_02:82]
Segment Information

[0001571996-19-000002:8k_2_02:83]
(in millions, except percentages; unaudited; continued)

[0001571996-19-000002:8k_2_02:84]
|  | Three Months Ended |  | Fiscal Year Ended |
|  | February 1, 2019 |  | February 2, 2018 |  | February 1, 2019 |  | February 2, 2018 |
| Reconciliation to consolidated net revenue: |  |  |  |  |  |  |
| Reportable segment net revenue | $ | 23,418 |  |  | $ | 21,688 |  |  | $ | 89,004 |  |  | $ | 78,129 |  |
| Other businesses (a) | 593 |  |  | 566 |  |  | 2,329 |  |  | 2,195 |  |
| Unallocated transactions (b) | (3 | ) |  | (7 | ) |  | (9 | ) |  | (15 | ) |
| Impact of purchase accounting (c) | (167 | ) |  | (284 | ) |  | (703 | ) |  | (1,269 | ) |
| Total consolidated net revenue | $ | 23,841 |  |  | $ | 21,963 |  |  | $ | 90,621 |  |  | $ | 79,040 |  |
| Reconciliation to consolidated operating income (loss): |  |  |  |  |
| Reportable segment operating income | $ | 2,692 |  |  | $ | 2,442 |  |  | $ | 9,100 |  |  | $ | 7,921 |  |
| Other businesses (a) | (35 | ) |  | (54 | ) |  | (174 | ) |  | (125 | ) |
| Unallocated transactions (b) | (1 | ) |  | (16 | ) |  | (72 | ) |  | (24 | ) |
| Impact of purchase accounting (c) | (190 | ) |  | (351 | ) |  | (820 | ) |  | (1,546 | ) |
| Amortization of intangibles | (1,544 | ) |  | (1,730 | ) |  | (6,138 | ) |  | (6,980 | ) |
| Transaction-related expenses (d) | (313 | ) |  | (87 | ) |  | (750 | ) |  | (502 | ) |
| Other corporate expenses (e) | (278 | ) |  | (273 | ) |  | (1,337 | ) |  | (1,160 | ) |
| Total consolidated operating income (loss) | $ | 331 |  |  | $ | (69 | ) |  | $ | (191 | ) |  | $ | (2,416 | ) |

[0001571996-19-000002:8k_2_02:85]
_________________

[0001571996-19-000002:8k_2_02:86]
| (a) | Pivotal, SecureWorks, RSA Security, Virtustream, and Boomi constitute “Other businesses” and do not meet the requirements for a reportable segment, either individually or collectively. The results of Other businesses are not material to the Company’s overall results. |

[0001571996-19-000002:8k_2_02:87]
| (b) | Unallocated transactions includes long-term incentives, certain short-term incentive compensation expenses, and other corporate items that are not allocated to Dell Technologies’ reportable segments. |

[0001571996-19-000002:8k_2_02:88]
| (c) | Impact of purchase accounting includes non-cash purchase accounting adjustments that are primarily related to the EMC merger transaction. |

[0001571996-19-000002:8k_2_02:89]
| (d) | Transaction-related expenses includes acquisition, integration, and divestiture related costs, as well as the costs incurred in the Class V transaction. |

[0001571996-19-000002:8k_2_02:90]
| (e) | Other corporate expenses includes goodwill impairment charges, severance and facility action costs, and stock-based compensation expense. |

[0001571996-19-000002:8k_2_02:91]
SUPPLEMENTAL SELECTED NON-GAAP FINANCIAL MEASURES

[0001571996-19-000002:8k_2_02:92]
Dell Technologies uses non-GAAP financial measures to supplement financial information presented on a GAAP basis, and believes that excluding certain items from its GAAP results allows management to better understand the Company’s consolidated financial performance from period to period and better project its future consolidated financial performance as forecasts are developed at a level of detail different from that used to prepare GAAP-based financial measures.  Moreover, Dell Technologies believes these non-GAAP financial measures provide its stakeholders with useful information to help them evaluate the Company’s operating results by facilitating an enhanced understanding of its operating performance and enabling them to make more meaningful period to period comparisons.

[0001571996-19-000002:8k_2_02:93]
There are limitations to the use of the non-GAAP financial measures presented.  The Company’s non-GAAP financial measures may not be comparable to similarly titled measures of other companies.  Other companies, including companies in Dell Technologies’ industry, may calculate non-GAAP financial measures differently, limiting the usefulness of those measures for comparative purposes.

[0001571996-19-000002:8k_2_02:94]
As the non-GAAP items excluded have a material impact on Dell Technologies’ financial results, the Company’s management compensates for this limitation by relying primarily on its GAAP results and using non-GAAP financial measures supplementally or for projections when comparable GAAP financial measures are not available.  The non-GAAP financial measures are not meant to be considered as indicators of performance in isolation from or as a substitute for net revenue, gross margin, operating expenses, operating income, or net income prepared in accordance with GAAP, and should be read only in conjunction with financial information presented on a GAAP basis.

[0001571996-19-000002:8k_2_02:95]
Reconciliations of each non-GAAP financial measure to its most directly comparable GAAP financial measure are presented below.  The Company encourages you to review the reconciliations in conjunction with the presentation of the non-GAAP financial measures for each of the periods presented.  In future fiscal periods, the Company may exclude such items and may incur income and expenses similar to these excluded items.  Accordingly, the exclusion of these items and other similar items in the Company’s non-GAAP presentation should not be interpreted as implying that these items are non-recurring, infrequent, or unusual.

[0001571996-19-000002:8k_2_02:96]
As described below, Dell Technologies’ non-GAAP net income now excludes, among other items, fair value adjustments on equity investments as well as discrete tax items.  These items were not excluded in the prior presentation of the Company’s non-GAAP net income.  Upon its return to the public markets in December 2018, the Company reevaluated the presentation of non-GAAP net income and made these changes to facilitate an evaluation of its current operating performance and the comparability of its current operating performance to its past operating performance.  Non-GAAP net income for prior periods has been recast to reflect the current presentation.

[0001571996-19-000002:8k_2_02:97]
The following is a summary of the items excluded from the most comparable GAAP financial measures to calculate Dell Technologies’ non-GAAP financial measures:

[0001571996-19-000002:8k_2_02:98]
| • | Amortization of Intangible Assets — Amortization of intangible assets primarily consists of amortization of customer relationships, developed technology, and trade names. For the periods presented, amortization of intangible assets primarily represents amortization associated with intangible assets recognized in connection with the EMC merger transaction and the going-private transaction. Amortization charges for purchased intangible assets are significantly impacted by the timing and magnitude of our acquisitions, and these charges may vary in amount from period to period. |

[0001571996-19-000002:8k_2_02:99]
| • | Impact of Purchase Accounting — The impact of purchase accounting includes purchase accounting adjustments related to the EMC merger transaction and, to a lesser extent, the going-private transaction. The assets and liabilities acquired were recognized at fair value as of the respective transaction dates, and the fair value adjustments are being amortized over the estimated useful lives in the periods following the transactions. |

[0001571996-19-000002:8k_2_02:100]
| • | Transaction-related Expenses — Transaction-related expenses consist of acquisition, integration, and divestiture related costs, as well as the costs incurred in the Class V transaction, and are expensed as incurred. These expenses primarily represent costs for legal, banking, consulting, and advisory services, as well as certain compensatory retention awards directly related to the EMC merger transaction. |

[0001571996-19-000002:8k_2_02:101]
| • | Other Corporate Expenses — Other corporate expenses consist of goodwill impairment charges, severance, facility action costs, and stock-based compensation expense associated with equity awards. Other corporate expenses vary from period to period and are significantly impacted by the timing and nature of these events. |

[0001571996-19-000002:8k_2_02:102]
| • | Fair Value Adjustments on Equity Investments — Fair value adjustments on equity investments primarily consists of the gain (loss) on strategic investments, which includes the recurring fair value adjustments of investments in publicly-traded companies, as well as those in privately-held companies, which are adjusted for observable price changes, and to a lesser extent any potential impairments. Given the volatility in the ongoing adjustments to the valuation of these strategic investments, the Company believes that excluding these charges for purposes of calculating non-GAAP net income presented facilitates a more meaningful evaluation of its current operating performance and comparisons to its past operating performance. |

[0001571996-19-000002:8k_2_02:103]
| • | Aggregate Adjustment for Income Taxes — The aggregate adjustment for income taxes is the estimated combined income tax effect for the adjustments described above, tax benefits resulting from the impact of adopting the new ASC 606 revenue standard in the first quarter of Fiscal 2019, as well as an adjustment for discrete tax items. Due to the variability in recognition of discrete tax items from period to period, the Company believes that excluding these benefits or charges for purposes of calculating non-GAAP net income facilitates a more meaningful evaluation of its current operating performance and comparisons to its past operating performance. The tax effects are determined based on the tax jurisdictions where the above items were incurred. |

[0001571996-19-000002:8k_2_02:104]
The Company also uses EBITDA and adjusted EBITDA to provide additional information for evaluation of its operating performance.  Adjusted EBITDA excludes purchase accounting adjustments related to the EMC merger transaction and the going-private transaction, acquisition, integration, and divestiture related costs, goodwill impairment charges, severance and facility action costs, and stock-based compensation expense.  The Company believes that, due to the non-operational nature of the purchase accounting entries, it is appropriate to exclude these adjustments.

[0001571996-19-000002:8k_2_02:105]
As is the case with the other non-GAAP measures presented, users should consider the limitations of using EBITDA and adjusted EBITDA, including the fact that those measures do not provide a complete measure of our operating performance.  EBITDA and adjusted EBITDA do not purport to be alternatives to net income (loss) as measures of operating performance or to cash flows from operating activities as a measure of liquidity.  In particular, EBITDA and adjusted EBITDA are not intended to be a measure of free cash flow available for management’s discretionary use, as these measures do not consider certain cash requirements, such as working capital needs, capital expenditures, contractual commitments, interest payments, tax payments, and other debt service requirements.

[0001571996-19-000002:8k_2_02:106]
DELL TECHNOLOGIES INC.

[0001571996-19-000002:8k_2_02:107]
Selected Non-GAAP Financial Measures

[0001571996-19-000002:8k_2_02:108]
(in millions, except percentages; unaudited)

[0001571996-19-000002:8k_2_02:109]
|  | Three Months Ended |  |  |  | Fiscal Year Ended |  |  |
|  | February 1, 2019 |  | February 2, 2018 |  | Change |  | February 1, 2019 |  | February 2, 2018 |  | Change |
| Non-GAAP net revenue | $ | 24,008 |  |  | $ | 22,247 |  |  | 8% |  | $ | 91,324 |  |  | $ | 80,309 |  |  | 14% |
| Non-GAAP gross margin | $ | 8,037 |  |  | $ | 7,134 |  |  | 13% |  | $ | 29,022 |  |  | $ | 25,668 |  |  | 13% |
| % of non-GAAP net revenue | 33 | % |  | 32 | % |  |  |  | 32 | % |  | 32 | % |  |  |
| Non-GAAP operating expenses | $ | 5,381 |  |  | $ | 4,762 |  |  | 13% |  | $ | 20,168 |  |  | $ | 17,896 |  |  | 13% |
| % of non-GAAP net revenue | 22 | % |  | 21 | % |  |  |  | 22 | % |  | 22 | % |  |  |
| Non-GAAP operating income | $ | 2,656 |  |  | $ | 2,372 |  |  | 12% |  | $ | 8,854 |  |  | $ | 7,772 |  |  | 14% |
| % of non-GAAP net revenue | 11 | % |  | 11 | % |  |  |  | 10 | % |  | 10 | % |  |  |
| Non-GAAP net income (a) | $ | 1,592 |  |  | $ | 1,268 |  |  | 26% |  | $ | 5,227 |  |  | $ | 4,355 |  |  | 20% |
| % of non-GAAP net revenue | 7 | % |  | 6 | % |  |  |  | 6 | % |  | 5 | % |  |  |
| Adjusted EBITDA | $ | 3,028 |  |  | $ | 2,718 |  |  | 11% |  | $ | 10,296 |  |  | $ | 9,134 |  |  | 13% |
| % of non-GAAP net revenue | 13 | % |  | 12 | % |  |  |  | 11 | % |  | 11 | % |  |  |

[0001571996-19-000002:8k_2_02:110]
_________________

[0001571996-19-000002:8k_2_02:111]
| (a) | Non-GAAP net income has been recast to exclude fair value adjustments on equity investments, the corresponding tax effects of those adjustments, and discrete tax items. |

[0001571996-19-000002:8k_2_02:112]
DELL TECHNOLOGIES INC.

[0001571996-19-000002:8k_2_02:113]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-19-000002:8k_2_02:114]
(in millions, except percentages; unaudited; continued on next page)

[0001571996-19-000002:8k_2_02:115]
|  | Three Months Ended |  |  |  | Fiscal Year Ended |  |  |
|  | February 1, 2019 |  | February 2, 2018 |  | Change |  | February 1, 2019 |  | February 2, 2018 |  | Change |
| Net revenue | $ | 23,841 |  |  | $ | 21,963 |  |  | 9% |  | $ | 90,621 |  |  | $ | 79,040 |  |  | 15% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Impact of purchase accounting | 167 |  |  | 284 |  |  |  |  | 703 |  |  | 1,269 |  |  |  |
| Non-GAAP net revenue | $ | 24,008 |  |  | $ | 22,247 |  |  | 8% |  | $ | 91,324 |  |  | $ | 80,309 |  |  | 14% |
| Gross margin | $ | 7,109 |  |  | $ | 5,892 |  |  | 21% |  | $ | 25,053 |  |  | $ | 20,537 |  |  | 22% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 729 |  |  | 910 |  |  |  |  | 2,883 |  |  | 3,694 |  |  |  |
| Impact of purchase accounting | 171 |  |  | 292 |  |  |  |  | 720 |  |  | 1,312 |  |  |  |
| Transaction-related expenses | (26 | ) |  | 2 |  |  |  |  | 213 |  |  | 24 |  |  |  |
| Other corporate expenses | 54 |  |  | 38 |  |  |  |  | 153 |  |  | 101 |  |  |  |
| Non-GAAP gross margin | $ | 8,037 |  |  | $ | 7,134 |  |  | 13% |  | $ | 29,022 |  |  | $ | 25,668 |  |  | 13% |
| Operating expenses | $ | 6,778 |  |  | $ | 5,961 |  |  | 14% |  | $ | 25,244 |  |  | $ | 22,953 |  |  | 10% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | (815 | ) |  | (820 | ) |  |  |  | (3,255 | ) |  | (3,286 | ) |  |  |
| Impact of purchase accounting | (19 | ) |  | (59 | ) |  |  |  | (100 | ) |  | (234 | ) |  |  |
| Transaction-related expenses | (339 | ) |  | (85 | ) |  |  |  | (537 | ) |  | (478 | ) |  |  |
| Other corporate expenses | (224 | ) |  | (235 | ) |  |  |  | (1,184 | ) |  | (1,059 | ) |  |  |
| Non-GAAP operating expenses | $ | 5,381 |  |  | $ | 4,762 |  |  | 13% |  | $ | 20,168 |  |  | $ | 17,896 |  |  | 13% |
| Operating income (loss) | $ | 331 |  |  | $ | (69 | ) |  | 580% |  | $ | (191 | ) |  | $ | (2,416 | ) |  | 92% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 1,544 |  |  | 1,730 |  |  |  |  | 6,138 |  |  | 6,980 |  |  |  |
| Impact of purchase accounting | 190 |  |  | 351 |  |  |  |  | 820 |  |  | 1,546 |  |  |  |
| Transaction-related expenses | 313 |  |  | 87 |  |  |  |  | 750 |  |  | 502 |  |  |  |
| Other corporate expenses | 278 |  |  | 273 |  |  |  |  | 1,337 |  |  | 1,160 |  |  |  |
| Non-GAAP operating income | $ | 2,656 |  |  | $ | 2,372 |  |  | 12% |  | $ | 8,854 |  |  | $ | 7,772 |  |  | 14% |
| Net loss | $ | (287 | ) |  | $ | (133 | ) |  | (116)% |  | $ | (2,181 | ) |  | $ | (2,926 | ) |  | 25% |
| Non-GAAP adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangibles | 1,544 |  |  | 1,730 |  |  |  |  | 6,138 |  |  | 6,980 |  |  |  |
| Impact of purchase accounting | 190 |  |  | 351 |  |  |  |  | 820 |  |  | 1,546 |  |  |  |
| Transaction-related expenses | 387 |  |  | 87 |  |  |  |  | 824 |  |  | 502 |  |  |  |
| Other corporate expenses | 278 |  |  | 273 |  |  |  |  | 1,337 |  |  | 1,160 |  |  |  |
| Fair value adjustments on equity investments | (113 | ) |  | (50 | ) |  |  |  | (342 | ) |  | (72 | ) |  |  |
| Aggregate adjustment for income taxes | (407 | ) |  | (990 | ) |  |  |  | (1,369 | ) |  | (2,835 | ) |  |  |
| Non-GAAP net income (a) | $ | 1,592 |  |  | $ | 1,268 |  |  | 26% |  | $ | 5,227 |  |  | $ | 4,355 |  |  | 20% |

[0001571996-19-000002:8k_2_02:116]
_________________

[0001571996-19-000002:8k_2_02:117]
| (a) | Non-GAAP net income has been recast to exclude fair value adjustments on equity investments, the corresponding tax effects of those adjustments, and discrete tax items. |

[0001571996-19-000002:8k_2_02:118]
DELL TECHNOLOGIES INC.

[0001571996-19-000002:8k_2_02:119]
Reconciliation of Selected Non-GAAP Financial Measures

[0001571996-19-000002:8k_2_02:120]
(in millions, except percentages; unaudited; continued)

[0001571996-19-000002:8k_2_02:121]
|  | Three Months Ended |  |  |  | Fiscal Year Ended |  |  |
|  | February 1, 2019 |  | February 2, 2018 |  | Change |  | February 1, 2019 |  | February 2, 2018 |  | Change |
| Net loss | $ | (287 | ) |  | $ | (133 | ) |  | (116)% |  | $ | (2,181 | ) |  | $ | (2,926 | ) |  | 25% |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Interest and other, net | 606 |  |  | 554 |  |  |  |  | 2,170 |  |  | 2,353 |  |  |  |
| Income tax provision (benefit) | 12 |  |  | (490 | ) |  |  |  | (180 | ) |  | (1,843 | ) |  |  |
| Depreciation and amortization | 1,940 |  |  | 2,143 |  |  |  |  | 7,746 |  |  | 8,634 |  |  |  |
| EBITDA | $ | 2,271 |  |  | $ | 2,074 |  |  | 9% |  | $ | 7,555 |  |  | $ | 6,218 |  |  | 22% |
| EBITDA | $ | 2,271 |  |  | $ | 2,074 |  |  | 9% |  | $ | 7,555 |  |  | $ | 6,218 |  |  | 22% |
| Adjustments: |  |  |  |  |  |  |  |  |  |  |  |
| Stock-based compensation expense | 247 |  |  | 205 |  |  |  |  | 918 |  |  | 835 |  |  |  |
| Impact of purchase accounting | 168 |  |  | 284 |  |  |  |  | 704 |  |  | 1,274 |  |  |  |
| Transaction-related expenses | 313 |  |  | 87 |  |  |  |  | 722 |  |  | 502 |  |  |  |
| Other corporate expenses | 29 |  |  | 68 |  |  |  |  | 397 |  |  | 305 |  |  |  |
| Adjusted EBITDA | $ | 3,028 |  |  | $ | 2,718 |  |  | 11% |  | $ | 10,296 |  |  | $ | 9,134 |  |  | 13% |
