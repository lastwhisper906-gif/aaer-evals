# DELL note change history — 0001571996-20-000045 → 0001571996-20-000051


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-12-07):
[0001571996-20-000051:note_history:1]
Patent Litigation — On April 25, 2019, Cirba Inc. (“Cirba”) filed a lawsuit against VMware, Inc. in the United States District Court for the District of Delaware, alleging two patent infringement claims and three trademark infringement-related claims.  On May 6, 2019, Cirba filed a motion seeking a preliminary injunction tied to one of the two patents it alleges VMware, Inc. infringes.  Following a hearing on August 6, 2019, the Court denied Cirba’s preliminary injunction motion and set the case for trial in mid-January 2020.  On August 20, 2019, VMware, Inc. filed counterclaims against Cirba, asserting among other claims that Cirba is infringing four VMware, Inc. patents.  The Delaware Court severed those claims from the January 2020 trial on Cirba’s claims, and the trial on VMware, Inc.’s patent claims is currently set for September 2021.  The trial on Cirba’s claims in the Delaware court was completed on January 23, 2020, and on January 24, 2020, the jury returned a verdict finding that VMware, Inc. willfully infringed the two asserted patents and awarding approximately $237 million in damages.  The jury further found that VMware, Inc. was not liable on Cirba’s trademark infringement-related claims.  A total of $237 million was accrued for the Delaware action, which reflects the estimated losses that are considered both probable and reasonably estimable at this time.  The parties filed the post-trial motions in which VMware, Inc. moved to set aside the verdict and reduce the damages award, and Cirba moved for a permanent injunction, enhanced damages, setting of an ongoing royalty rate, and an award of pre-judgment and post-judgment interest and supplemental damages.  A hearing was held in the Delaware court on those motions on May 15, 2020, and the Delaware court has taken those motions under advisement.  VMware, Inc. intends to vigorously defend itself in this matter, including, if necessary, via an appeal.  Final resolution of this matter could be materially different from the amount accrued.  The amount accrued for this matter is included in Accrued and other in the Condensed Consolidated Statements of Financial Position as of October 30, 2020 and January 31, 2020, and the charge was classified in Selling, general and administrative in the Consolidated Statements of Income (Loss) during the fiscal year ended January 31, 2020.
  (was, 2020-09-04, similarity 0.9915):
[0001571996-20-000045:note_history:1]
Patent Litigation — On April 25, 2019, Cirba Inc. (“Cirba”) filed a lawsuit against VMware, Inc. in the United States District Court for the District of Delaware, alleging two patent infringement claims and three trademark infringement-related claims.  On May 6, 2019, Cirba filed a motion seeking a preliminary injunction tied to one of the two patents it alleges VMware, Inc. infringes.  Following a hearing on August 6, 2019, the Court denied Cirba’s preliminary injunction motion and set the case for trial in mid-January 2020.  On August 20, 2019, VMware, Inc. filed counterclaims against Cirba, asserting among other claims that Cirba is infringing four VMware, Inc. patents.  The Delaware Court severed those claims from the January 2020 trial on Cirba’s claims, and the trial on VMware, Inc.’s patent claims is currently set for September 2021.  The trial on Cirba’s claims in the Delaware court was completed on January 23, 2020, and on January 24, 2020, the jury returned a verdict finding that VMware, Inc. willfully infringed the two asserted patents and awarding approximately $237 million in damages.  The jury further found that VMware, Inc. was not liable on Cirba’s trademark infringement-related claims.  A total of $237 million was accrued for the Delaware action, which reflects the estimated losses that are considered both probable and reasonably estimable at this time.  The parties filed the post-trial motions in which VMware, Inc. moved to set aside the verdict and reduce the damages award, and Cirba moved for a permanent injunction, enhanced damages, setting of an ongoing royalty rate, and an award of pre-judgment and post-judgment interest and supplemental damages.  A hearing was held in the Delaware court on those motions on May 15, 2020, and the Delaware court has taken those motions under advisement.  VMware, Inc. intends to vigorously defend itself in this matter, including, if necessary, via an appeal.  Final resolution of this matter could be materially different from the amount accrued.  The amount accrued for this matter is included in Accrued and other in the Condensed Consolidated Statements of Financial Position as of July 31, 2020 and January 31, 2020, and the charge was classified in Selling, general and administrative in the Consolidated Statements of Income (Loss) during the fiscal year ended January 31, 2020.

- changed (2020-12-07):
[0001571996-20-000051:note_history:2]
Class Actions Related to VMware, Inc.’s Acquisition of Pivotal — Two purported stockholders brought putative class action complaints arising out of VMware, Inc.’s acquisition of Pivotal Software, Inc. on December 30, 2019 as described in Note 1 of the Notes to the Condensed Consolidated Financial Statements.  The two actions were consolidated in the Delaware Chancery Court into In re: Pivotal Software, Inc. Stockholders Litigation (Civil Action No. 2020-0440-KSJM).  The complaint names as defendants the Company, VMware, Inc., Michael S. Dell, and certain officers of Pivotal.  The plaintiffs generally allege that the defendants breached their fiduciary duties to the former holders of Pivotal Class A Common Stock in connection with VMware, Inc.’s acquisition of Pivotal by allegedly causing Pivotal to enter into a transaction that favored the interests of Pivotal’s controlling stockholders at the expense of such former stockholders.  The plaintiffs seek, among other remedies, a judicial declaration that the defendants breached their fiduciary duties and an award of damages, fees, and costs.
  (was, 2020-09-04, similarity 0.9959):
[0001571996-20-000045:note_history:2]
Class Actions Related to VMware, Inc.’s Acquisition of Pivotal Software — Two purported stockholders brought putative class action complaints arising out of VMware, Inc.’s acquisition of Pivotal Software, Inc. on December 30, 2019 as described in Note 1 of the Notes to the Condensed Consolidated Financial Statements.  The two actions were consolidated in the Delaware Chancery Court into In re: Pivotal Software, Inc. Stockholders Litigation (Civil Action No. 2020-0440-KSJM).  The complaint names as defendants the Company, VMware, Inc., Michael S. Dell, and certain officers of Pivotal.  The plaintiffs generally allege that the defendants breached their fiduciary duties to the former holders of Pivotal Class A Common Stock in connection with VMware, Inc.’s acquisition of Pivotal by allegedly causing Pivotal to enter into a transaction that favored the interests of Pivotal’s controlling stockholders at the expense of such former stockholders.  The plaintiffs seek, among other remedies, a judicial declaration that the defendants breached their fiduciary duties and an award of damages, fees, and costs.

- changed (2020-12-07):
[0001571996-20-000051:note_history:3]
As of October 30, 2020, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for these or other proceedings or matters has been incurred.  However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company’s business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters.  Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company’s business, financial condition, results of operations, or cash flows will depend on a number of variables, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.
  (was, 2020-09-04, similarity 0.9941):
[0001571996-20-000045:note_history:3]
As of July 31, 2020, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for these or other proceedings or matters has been incurred.  However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company’s business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters.  Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company’s business, financial condition, results of operations, or cash flows will depend on a number of variables, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.


## dell:CreditLossFinancialInstrumentLeasesDebtVariableInterestEntitiesAndCustomerReceivablesSalesTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-12-07):
[0001571996-20-000051:note_history:4]
The Company offers or arranges various financing options, services, and alternative payment structures for its customers in North America, Europe, Australia, and New Zealand through Dell Financial Services and its affiliates (“DFS”).  The Company also arranges financing for some of its customers in various countries where DFS does not currently operate as a captive enterprise.  The key activities of DFS include originating, collecting, and servicing customer financing arrangements primarily related to the purchase or use of Dell Technologies products and services.  In some cases, DFS also offers financing on the purchase of third-party technology products that complement the Dell Technologies portfolio of products and services.  New financing originations were $2.1 billion and $2.0 billion for the three months ended October 30, 2020 and November 1, 2019, respectively, and $6.5 billion and $5.7 billion for the nine months ended October 30, 2020 and November 1, 2019, respectively.
  (was, 2020-09-04, similarity 0.8791):
[0001571996-20-000045:note_history:4]
The Company offers or arranges various financing options, services, and alternative payment structures for its customers in North America, Europe, Australia, and New Zealand through Dell Financial Services and its affiliates (“DFS”).  The Company also arranges financing for some of its customers in various countries where DFS does not currently operate as a captive enterprise.  The key activities of DFS include originating, collecting, and servicing customer financing arrangements primarily related to the purchase or use of Dell Technologies products and services.  In some cases, DFS also offers financing on the purchase of third-party technology products that complement the Dell Technologies portfolio of products and services.  New financing originations were $2.6 billion and $2.0 billion for the three months ended July 31, 2020 and August 2, 2019, respectively, and $4.4 billion and $3.7 billion for the six months ended July 31, 2020 and August 2, 2019, respectively.

- changed (2020-12-07):
[0001571996-20-000051:note_history:5]
|  | October 30, 2020 |  | January 31, 2020 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Financing receivables, net: |  |  |  |  |  |  |  |  |  |  |  |
| Customer receivables, gross (a) | $ | 768 |  |  | $ | 9,313 |  |  | $ | 10,081 |  |  | $ | 824 |  |  | $ | 8,486 |  |  | $ | 9,310 |  |
| Allowances for losses | (142) |  |  | (165) |  |  | (307) |  |  | (70) |  |  | (79) |  |  | (149) |  |
| Customer receivables, net | 626 |  |  | 9,148 |  |  | 9,774 |  |  | 754 |  |  | 8,407 |  |  | 9,161 |  |
| Residual interest | — |  |  | 472 |  |  | 472 |  |  | — |  |  | 582 |  |  | 582 |  |
| Financing receivables, net | $ | 626 |  |  | $ | 9,620 |  |  | $ | 10,246 |  |  | $ | 754 |  |  | $ | 8,989 |  |  | $ | 9,743 |  |
| Short-term | $ | 626 |  |  | $ | 4,246 |  |  | $ | 4,872 |  |  | $ | 754 |  |  | $ | 4,141 |  |  | $ | 4,895 |  |
| Long-term | $ | — |  |  | $ | 5,374 |  |  | $ | 5,374 |  |  | $ | — |  |  | $ | 4,848 |  |  | $ | 4,848 |  |
  (was, 2020-09-04, similarity 0.9548):
[0001571996-20-000045:note_history:5]
|  | July 31, 2020 |  |  |  |  |  | January 31, 2020 |  |  |  |  |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |  |  |  |  |  |  |  |  |  |  |
| Financing receivables, net: |  |  |  |  |  |  |  |  |  |  |  |
| Customer receivables, gross (a) | $ | 778 |  |  | $ | 9,255 |  |  | $ | 10,033 |  |  | $ | 824 |  |  | $ | 8,486 |  |  | $ | 9,310 |  |
| Allowances for losses | (143) |  |  | (180) |  |  | (323) |  |  | (70) |  |  | (79) |  |  | (149) |  |
| Customer receivables, net | 635 |  |  | 9,075 |  |  | 9,710 |  |  | 754 |  |  | 8,407 |  |  | 9,161 |  |
| Residual interest | — |  |  | 523 |  |  | 523 |  |  | — |  |  | 582 |  |  | 582 |  |
| Financing receivables, net | $ | 635 |  |  | $ | 9,598 |  |  | $ | 10,233 |  |  | $ | 754 |  |  | $ | 8,989 |  |  | $ | 9,743 |  |
| Short-term | $ | 635 |  |  | $ | 4,220 |  |  | $ | 4,855 |  |  | $ | 754 |  |  | $ | 4,141 |  |  | $ | 4,895 |  |
| Long-term | $ | — |  |  | $ | 5,378 |  |  | $ | 5,378 |  |  | $ | — |  |  | $ | 4,848 |  |  | $ | 4,848 |  |

- changed (2020-12-07):
[0001571996-20-000051:note_history:6]
The allowance for losses as of October 30, 2020 includes the adoption of the new CECL standard, which was adopted as of February 1, 2020 using the modified retrospective method.  Prior period amounts have not been recast.  The provision recognized on the Condensed Consolidated Statements of Income (Loss) for the three and nine months ended October 30, 2020 is based on an assessment of the impact of current and expected future economic conditions, inclusive of the effect of the COVID-19 pandemic on credit losses.  The duration and severity of COVID-19 and continued market volatility is highly uncertain and, as such, the impact on expected losses is subject to significant judgment and may cause variability in the Company’s allowance for credit losses in future periods.  See Note 1 and Note 2 of the Notes to the Condensed Consolidated Financial Statements for additional information about the new CECL standard.
  (was, 2020-09-04, similarity 0.6648):
[0001571996-20-000045:note_history:6]
The allowance for losses as of July 31, 2020 includes the adoption of the new CECL standard, which was adopted as of February 1, 2020 using the modified retrospective method.  Prior period amounts have not been recast.  The provision recognized on the Condensed Consolidated Statements of Income (Loss) for the three and six months ended July 31, 2020 is based on an assessment of the impact of current and expected future economic conditions, inclusive of the effect of the COVID-19 pandemic on credit losses.  The duration and severity of COVID-19 and continued market volatility is highly uncertain and, as such, the impact on expected losses is subject to significant judgment and may cause variability in the Company’s allowance for credit losses in future periods.  See Note 1 and Note 2 of the Notes to the Condensed Consolidated Financial Statements for additional information about the new CECL standard.

- changed (2020-12-07):
[0001571996-20-000051:note_history:7]
The following tables present the changes in allowance for financing receivable losses for the periods indicated:
  (was, 2020-09-04, similarity 0.9911):
[0001571996-20-000045:note_history:7]
The following table presents the changes in allowance for financing receivable losses for the periods indicated:

- added (2020-12-07):
[0001571996-20-000051:note_history:8]
|  | Three Months Ended |
|  | October 30, 2020 |  | November 1, 2019 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |  |  |  |  |  |  |  |  |  |  |  |
| Balances at beginning of period | $ | 143 |  |  | $ | 180 |  |  | $ | 323 |  |  | $ | 67 |  |  | $ | 71 |  |  | $ | 138 |  |
| Charge-offs, net of recoveries | (13) |  |  | (6) |  |  | (19) |  |  | (18) |  |  | (6) |  |  | (24) |  |
| Provision charged to income statement | 12 |  |  | (9) |  |  | 3 |  |  | 17 |  |  | 13 |  |  | 30 |  |
| Balances at end of period | $ | 142 |  |  | $ | 165 |  |  | $ | 307 |  |  | $ | 66 |  |  | $ | 78 |  |  | $ | 144 |  |

- added (2020-12-07):
[0001571996-20-000051:note_history:9]
|  | Nine Months Ended |
|  | October 30, 2020 |  | November 1, 2019 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |  |  |  |  |  |  |  |  |  |  |  |
| Balances at beginning of period | $ | 70 |  |  | $ | 79 |  |  | $ | 149 |  |  | $ | 75 |  |  | $ | 61 |  |  | $ | 136 |  |
| Adjustment for adoption of accounting standard (Note 1) | 40 |  |  | 71 |  |  | 111 |  |  | — |  |  | — |  |  | — |  |
| Charge-offs, net of recoveries | (51) |  |  | (22) |  |  | (73) |  |  | (53) |  |  | (18) |  |  | (71) |  |
| Provision charged to income statement | 83 |  |  | 37 |  |  | 120 |  |  | 44 |  |  | 35 |  |  | 79 |  |
| Balances at end of period | $ | 142 |  |  | $ | 165 |  |  | $ | 307 |  |  | $ | 66 |  |  | $ | 78 |  |  | $ | 144 |  |

- changed (2020-12-07):
[0001571996-20-000051:note_history:10]
|  | October 30, 2020 |  | January 31, 2020 |
|  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |
|  | (in millions) |
| Revolving — DPA | $ | 548 |  |  | $ | 34 |  |  | $ | 10 |  |  | $ | 592 |  |  | $ | 550 |  |  | $ | 51 |  |  | $ | 20 |  |  | $ | 621 |  |
| Revolving — DBC | 159 |  |  | 14 |  |  | 3 |  |  | 176 |  |  | 184 |  |  | 15 |  |  | 4 |  |  | 203 |  |
| Fixed-term — Consumer and Commercial | 8,947 |  |  | 299 |  |  | 67 |  |  | 9,313 |  |  | 8,005 |  |  | 373 |  |  | 108 |  |  | 8,486 |  |
| Total customer receivables, gross | $ | 9,654 |  |  | $ | 347 |  |  | $ | 80 |  |  | $ | 10,081 |  |  | $ | 8,739 |  |  | $ | 439 |  |  | $ | 132 |  |  | $ | 9,310 |  |
  (was, 2020-09-04, similarity 0.929):
[0001571996-20-000045:note_history:10]
|  | July 31, 2020 |  |  |  |  |  |  |  | January 31, 2020 |  |  |  |  |  |  |
|  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |
|  | (in millions) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Revolving — DPA | $ | 556 |  |  | $ | 29 |  |  | $ | 13 |  |  | $ | 598 |  |  | $ | 550 |  |  | $ | 51 |  |  | $ | 20 |  |  | $ | 621 |  |
| Revolving — DBC | 165 |  |  | 11 |  |  | 4 |  |  | 180 |  |  | 184 |  |  | 15 |  |  | 4 |  |  | 203 |  |
| Fixed-term — Consumer and Commercial | 8,803 |  |  | 381 |  |  | 71 |  |  | 9,255 |  |  | 8,005 |  |  | 373 |  |  | 108 |  |  | 8,486 |  |
| Total customer receivables, gross | $ | 9,524 |  |  | $ | 421 |  |  | $ | 88 |  |  | $ | 10,033 |  |  | $ | 8,739 |  |  | $ | 439 |  |  | $ | 132 |  |  | $ | 9,310 |  |

- changed (2020-12-07):
[0001571996-20-000051:note_history:11]
|  | October 30, 2020 |
|  | Fixed-term — Consumer and Commercial |  |  |  |  |  |  |
|  | Fiscal Year of Origination |  |  |  |  |  |  |
|  | 2021 |  | 2020 |  | 2019 |  | 2018 |  | 2017 |  | Years Prior |  | Revolving — DPA (a) |  | Revolving — DBC (a) |  | Total |
|  | (in millions) |
| Higher | $ | 2,591 |  |  | $ | 1,961 |  |  | $ | 780 |  |  | $ | 191 |  |  | $ | 32 |  |  | $ | — |  |  | $ | 158 |  |  | $ | 48 |  |  | $ | 5,761 |  |
| Mid | 900 |  |  | 736 |  |  | 351 |  |  | 92 |  |  | 13 |  |  | — |  |  | 177 |  |  | 52 |  |  | 2,321 |  |
| Lower | 723 |  |  | 572 |  |  | 303 |  |  | 53 |  |  | 14 |  |  | 1 |  |  | 257 |  |  | 76 |  |  | 1,999 |  |
| Total | $ | 4,214 |  |  | $ | 3,269 |  |  | $ | 1,434 |  |  | $ | 336 |  |  | $ | 59 |  |  | $ | 1 |  |  | $ | 592 |  |  | $ | 176 |  |  | $ | 10,081 |  |
  (was, 2020-09-04, similarity 0.9072):
[0001571996-20-000045:note_history:11]
|  | July 31, 2020 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | Fixed-term — Consumer and Commercial |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | Fiscal Year of Origination |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | 2021 |  | 2020 |  | 2019 |  | 2018 |  | 2017 |  | Years Prior |  | Revolving — DPA (a) |  | Revolving — DBC (a) |  | Total |
|  | (in millions) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Higher | $ | 2,019 |  |  | $ | 2,265 |  |  | $ | 992 |  |  | $ | 273 |  |  | $ | 43 |  |  | $ | 1 |  |  | $ | 148 |  |  | $ | 51 |  |  | $ | 5,792 |  |
| Mid | 633 |  |  | 824 |  |  | 417 |  |  | 127 |  |  | 20 |  |  | 1 |  |  | 176 |  |  | 52 |  |  | 2,250 |  |
| Lower | 548 |  |  | 609 |  |  | 379 |  |  | 82 |  |  | 20 |  |  | 2 |  |  | 274 |  |  | 77 |  |  | 1,991 |  |
| Total | $ | 3,200 |  |  | $ | 3,698 |  |  | $ | 1,788 |  |  | $ | 482 |  |  | $ | 83 |  |  | $ | 4 |  |  | $ | 598 |  |  | $ | 180 |  |  | $ | 10,033 |  |

- changed (2020-12-07):
[0001571996-20-000051:note_history:12]
|  | January 31, 2020 |
|  | Fixed-term — Consumer and Commercial |  | Revolving — DPA |  | Revolving — DBC |  | Total |
|  | (in millions) |
| Higher | $ | 5,042 |  |  | $ | 137 |  |  | $ | 55 |  |  | $ | 5,234 |  |
| Mid | 2,036 |  |  | 175 |  |  | 63 |  |  | 2,274 |  |
| Lower | 1,408 |  |  | 309 |  |  | 85 |  |  | 1,802 |  |
| Total | $ | 8,486 |  |  | $ | 621 |  |  | $ | 203 |  |  | $ | 9,310 |  |
  (was, 2020-09-04, similarity 0.964):
[0001571996-20-000045:note_history:12]
|  | January 31, 2020 |  |  |  |  |  |  |
|  | Fixed-term — Consumer and Commercial |  | Revolving — DPA |  | Revolving — DBC |  | Total |
|  | (in millions) |  |  |  |  |  |  |
| Higher | $ | 5,042 |  |  | $ | 137 |  |  | $ | 55 |  |  | $ | 5,234 |  |
| Mid | 2,036 |  |  | 175 |  |  | 63 |  |  | 2,274 |  |
| Lower | 1,408 |  |  | 309 |  |  | 85 |  |  | 1,802 |  |
| Total | $ | 8,486 |  |  | $ | 621 |  |  | $ | 203 |  |  | $ | 9,310 |  |

- added (2020-12-07):
[0001571996-20-000051:note_history:13]
Interest income on sales-type lease receivables was $69 million and $66 million for the three months ended October 30, 2020 and November 1, 2019, respectively, and $200 million and $196 million for the nine months ended October 30, 2020 and November 1, 2019, respectively.

- changed (2020-12-07):
[0001571996-20-000051:note_history:14]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 30, 2020 |  | November 1, 2019 |  | October 30, 2020 |  | November 1, 2019 |
|  | (in millions) |
| Net revenue — products | $ | 184 |  |  | $ | 251 |  |  | $ | 648 |  |  | $ | 604 |  |
| Cost of net revenue — products | 102 |  |  | 215 |  |  | 435 |  |  | 475 |  |
| Gross margin — products | $ | 82 |  |  | $ | 36 |  |  | $ | 213 |  |  | $ | 129 |  |
  (was, 2020-09-04, similarity 0.8131):
[0001571996-20-000045:note_history:14]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | July 31, 2020 |  | August 2, 2019 |  | July 31, 2020 |  | August 2, 2019 |
|  | (in millions) |  |  |  |  |  |  |
| Net revenue — products | $ | 249 |  |  | $ | 223 |  |  | $ | 464 |  |  | $ | 353 |  |
| Cost of net revenue — products | 174 |  |  | 179 |  |  | 333 |  |  | 260 |  |
| Gross margin — products | $ | 75 |  |  | $ | 44 |  |  | $ | 131 |  |  | $ | 93 |  |

- changed (2020-12-07):
[0001571996-20-000051:note_history:15]
|  | October 30, 2020 |
| Fiscal Years | (in millions) |
| Fiscal 2021 (remaining three months) | $ | 794 |  |
| Fiscal 2022 | 2,378 |  |
| Fiscal 2023 | 1,533 |  |
| Fiscal 2024 | 783 |  |
| Fiscal 2025 and beyond | 360 |  |
| Total undiscounted cash flows | 5,848 |  |
| Fixed-term loans | 4,125 |  |
| Revolving loans | 768 |  |
| Less: unearned income | (660) |  |
| Total customer receivables, gross | $ | 10,081 |  |
  (was, 2020-09-04, similarity 0.6893):
[0001571996-20-000045:note_history:15]
|  | July 31, 2020 |
| Fiscal Years | (in millions) |
| Fiscal 2021 (remaining six months) | $ | 258 |  |
| Fiscal 2022 | 461 |  |
| Fiscal 2023 | 351 |  |
| Fiscal 2024 | 89 |  |
| Fiscal 2025 and beyond | 9 |  |
| Total | $ | 1,168 |  |

- changed (2020-12-07):
[0001571996-20-000051:note_history:16]
|  | October 30, 2020 |  | January 31, 2020 |
|  | (in millions) |
| Equipment under operating lease, gross | $ | 1,592 |  |  | $ | 956 |  |
| Less: accumulated depreciation | (328) |  |  | (116) |  |
| Equipment under operating lease, net | $ | 1,264 |  |  | $ | 840 |  |
  (was, 2020-09-04, similarity 0.9083):
[0001571996-20-000045:note_history:16]
|  | July 31, 2020 |  | January 31, 2020 |
|  | (in millions) |  |  |
| Equipment under operating lease, gross | $ | 1,478 |  |  | $ | 956 |  |
| Less: accumulated depreciation | (258) |  |  | (116) |  |
| Equipment under operating lease, net | $ | 1,220 |  |  | $ | 840 |  |

- added (2020-12-07):
[0001571996-20-000051:note_history:17]
Operating lease income relating to lease payments was $120 million and $63 million for the three months ended October 30, 2020 and November 1, 2019, respectively, and $310 million and $94 million for the nine months ended October 30, 2020 and November 1, 2019, respectively.  Depreciation expense was $92 million and $40 million for the three months ended October 30, 2020 and November 1, 2019, respectively, and $228 million and $64 million for the nine months ended October 30, 2020 and November 1, 2019, respectively.

- added (2020-12-07):
[0001571996-20-000051:note_history:18]
|  | October 30, 2020 |
| Fiscal Years | (in millions) |
| Fiscal 2021 (remaining three months) | $ | 142 |  |
| Fiscal 2022 | 526 |  |
| Fiscal 2023 | 404 |  |
| Fiscal 2024 | 146 |  |
| Fiscal 2025 and beyond | 24 |  |
| Total | $ | 1,242 |  |

- changed (2020-12-07):
[0001571996-20-000051:note_history:19]
|  | October 30, 2020 |  | January 31, 2020 |
|  | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing and securitization facilities | $ | 2,574 |  |  | $ | 2,606 |  |
| Fixed-term securitization offerings | 3,465 |  |  | 2,593 |  |
| Other | 94 |  |  | 141 |  |
| Total DFS U.S. debt | 6,133 |  |  | 5,340 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 860 |  |  | 743 |  |
| Other borrowings | 791 |  |  | 931 |  |
| Note payable | 250 |  |  | 200 |  |
| Dell Bank Senior Unsecured Eurobonds | 1,167 |  |  | 551 |  |
| Total DFS international debt | 3,068 |  |  | 2,425 |  |
| Total DFS debt | $ | 9,201 |  |  | $ | 7,765 |  |
| Total short-term DFS debt | $ | 4,884 |  |  | $ | 4,152 |  |
| Total long-term DFS debt | $ | 4,317 |  |  | $ | 3,613 |  |
  (was, 2020-09-04, similarity 0.9674):
[0001571996-20-000045:note_history:19]
|  | July 31, 2020 |  | January 31, 2020 |
|  | (in millions) |  |  |
| DFS U.S. debt: |  |  |  |
| Asset-based financing and securitization facilities | $ | 2,936 |  |  | $ | 2,606 |  |
| Fixed-term securitization offerings | 2,788 |  |  | 2,593 |  |
| Other | 187 |  |  | 141 |  |
| Total DFS U.S. debt | 5,911 |  |  | 5,340 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 835 |  |  | 743 |  |
| Other borrowings | 719 |  |  | 931 |  |
| Note payable | 187 |  |  | 200 |  |
| Dell Bank Senior Unsecured Eurobonds | 1,185 |  |  | 551 |  |
| Total DFS international debt | 2,926 |  |  | 2,425 |  |
| Total DFS debt | $ | 8,837 |  |  | $ | 7,765 |  |
| Total short-term DFS debt | $ | 4,188 |  |  | $ | 4,152 |  |
| Total long-term DFS debt | $ | 4,649 |  |  | $ | 3,613 |  |

- changed (2020-12-07):
[0001571996-20-000051:note_history:20]
Asset-Based Financing and Securitization Facilities — The Company maintains separate asset-based financing facilities and a securitization facility in the United States, which are revolving facilities for fixed-term leases and loans and for revolving loans, respectively.  This debt is collateralized solely by the U.S. loan and lease payments and associated equipment in the facilities.  The debt has a variable interest rate and the duration of the debt is based on the terms of the underlying loan and lease payment streams.  As of October 30, 2020, the total debt capacity related to the U.S. asset-based financing and securitization facilities was $4.1 billion.  The Company enters into interest swap agreements to effectively convert a portion of this debt from a floating rate to a fixed rate.  See Note 7 of the Notes to the Condensed Consolidated Financial Statements for additional information about interest rate swaps.
  (was, 2020-09-04, similarity 0.994):
[0001571996-20-000045:note_history:20]
Asset-Based Financing and Securitization Facilities — The Company maintains separate asset-based financing facilities and a securitization facility in the United States, which are revolving facilities for fixed-term leases and loans and for revolving loans, respectively.  This debt is collateralized solely by the U.S. loan and lease payments and associated equipment in the facilities.  The debt has a variable interest rate and the duration of the debt is based on the terms of the underlying loan and lease payment streams.  As of July 31, 2020, the total debt capacity related to the U.S. asset-based financing and securitization facilities was $4.1 billion.  The Company enters into interest swap agreements to effectively convert a portion of this debt from a floating rate to a fixed rate.  See Note 7 of the Notes to the Condensed Consolidated Financial Statements for additional information about interest rate swaps.

- changed (2020-12-07):
[0001571996-20-000051:note_history:21]
The asset-based financing and securitization facilities contain standard structural features related to the performance of the funded receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the facility, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of October 30, 2020, these criteria were met.
  (was, 2020-09-04, similarity 0.9902):
[0001571996-20-000045:note_history:21]
The asset-based financing and securitization facilities contain standard structural features related to the performance of the funded receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the facility, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of July 31, 2020, these criteria were met.

- changed (2020-12-07):
[0001571996-20-000051:note_history:22]
Securitization Facility — The Company maintains a securitization facility in Europe for fixed-term leases and loans.  This facility is effective through December 21, 2020 and has a total debt capacity of $934 million as of October 30, 2020.
  (was, 2020-09-04, similarity 0.9577):
[0001571996-20-000045:note_history:22]
Securitization Facility — The Company maintains a securitization facility in Europe for fixed-term leases and loans.  This facility is effective through December 21, 2020 and has a total debt capacity of $948 million as of July 31, 2020.

- changed (2020-12-07):
[0001571996-20-000051:note_history:23]
The securitization facility contains standard structural features related to the performance of the securitized receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the program, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of October 30, 2020, these criteria were met.
  (was, 2020-09-04, similarity 0.9897):
[0001571996-20-000045:note_history:23]
The securitization facility contains standard structural features related to the performance of the securitized receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the program, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of July 31, 2020, these criteria were met.

- changed (2020-12-07):
[0001571996-20-000051:note_history:24]
Other Borrowings — In connection with the Company’s international financing operations, the Company has entered into revolving structured financing debt programs related to its fixed-term lease and loan products sold in Canada, Europe, Australia, and New Zealand.  The Canadian facility, which is collateralized solely by Canadian loan and lease payments and associated equipment, had a total debt capacity of $281 million as of October 30, 2020, and is effective through January 16, 2023.  The European facility, which is collateralized solely by European loan and lease payments and associated equipment, had a total debt capacity of $700 million as of October 30, 2020, and is effective through June 14, 2022.  The Australia and New Zealand facility, which is collateralized solely by Australia and New Zealand loan and lease payments and associated equipment, had a total debt capacity of $246 million as of October 30, 2020, and is effective through December 20, 2021.
  (was, 2020-09-04, similarity 0.6573):
[0001571996-20-000045:note_history:24]
Other Borrowings — In connection with the Company’s international financing operations, the Company has entered into revolving structured financing debt programs related to its fixed-term lease and loan products sold in Canada, Europe, Australia, and New Zealand.  The Canadian facility, which is collateralized solely by Canadian loan and lease payments and associated equipment, had a total debt capacity of $279 million as of July 31, 2020, and is effective through January 16, 2023.  The European facility, which is collateralized solely by European loan and lease payments and associated equipment, had a total debt capacity of $711 million as of July 31, 2020, and is effective through June 14, 2022.  The Australia and New Zealand facility, which is collateralized solely by Australia and New Zealand loan and lease payments and associated equipment, had a total debt capacity of $252 million as of July 31, 2020, and is effective through December 20, 2021.

- added (2020-12-07):
[0001571996-20-000051:note_history:25]
Note Payable — On November 27, 2017 the Company entered into an unsecured credit agreement to fund receivables in Mexico.  As of July 31, 2020, the aggregate principal amount of the note payable was $187 million.  This note was repaid in full during the three months ended October 30, 2020.

- added (2020-12-07):
[0001571996-20-000051:note_history:26]
On August 7, 2020, the Company entered into two new unsecured credit agreements to fund receivables in Mexico.  As of October 30, 2020, the aggregate principal amount of the notes payable was $250 million.  The notes bear interest at 3.37% and will mature on June 1, 2022.

- changed (2020-12-07):
[0001571996-20-000051:note_history:27]
|  | October 30, 2020 |  | January 31, 2020 |
|  | (in millions) |
| Assets held by consolidated VIEs, net: |  |  |  |
| Short-term, net | $ | 3,430 |  |  | $ | 3,316 |  |
| Long-term, net | 4,070 |  |  | 3,348 |  |
| Assets held by consolidated VIEs, net | $ | 7,500 |  |  | $ | 6,664 |  |
  (was, 2020-09-04, similarity 0.9234):
[0001571996-20-000045:note_history:27]
|  | July 31, 2020 |  | January 31, 2020 |
|  | (in millions) |  |  |
| Assets held by consolidated VIEs, net: |  |  |  |
| Short-term, net | $ | 3,315 |  |  | $ | 3,316 |  |
| Long-term, net | 3,867 |  |  | 3,348 |  |
| Assets held by consolidated VIEs, net | $ | 7,182 |  |  | $ | 6,664 |  |

- added (2020-12-07):
[0001571996-20-000051:note_history:28]
Loan and lease payments and associated equipment transferred via securitization through SPEs were $1.6 billion and $1.3 billion for the three months ended October 30, 2020 and November 1, 2019, respectively, and $4.6 billion and $4.1 billion for the nine months ended October 30, 2020 and November 1, 2019, respectively.

- changed (2020-12-07):
[0001571996-20-000051:note_history:29]
Some of the SPEs have entered into financing arrangements with multi-seller conduits that, in turn, issue asset-backed debt securities in the capital markets.  The DFS debt outstanding, which is collateralized by the loan and lease payments and associated equipment held by the consolidated VIEs, was $6.9 billion and $5.9 billion as of October 30, 2020 and January 31, 2020, respectively.  The Company’s risk of loss related to securitized receivables is limited to the amount by which the Company’s right to receive collections for assets securitized exceeds the amount required to pay interest, principal, and fees and expenses related to the asset-backed securities.  The Company provides credit enhancement to the securitizations in the form of over-collateralization.
  (was, 2020-09-04, similarity 0.9927):
[0001571996-20-000045:note_history:29]
Some of the SPEs have entered into financing arrangements with multi-seller conduits that, in turn, issue asset-backed debt securities in the capital markets.  The DFS debt outstanding, which is collateralized by the loan and lease payments and associated equipment held by the consolidated VIEs, was $6.6 billion and $5.9 billion as of July 31, 2020 and January 31, 2020, respectively.  The Company’s risk of loss related to securitized receivables is limited to the amount by which the Company’s right to receive collections for assets securitized exceeds the amount required to pay interest, principal, and fees and expenses related to the asset-backed securities.  The Company provides credit enhancement to the securitizations in the form of over-collateralization.

- changed (2020-12-07):
[0001571996-20-000051:note_history:30]
To manage certain concentrations of customer credit exposure, the Company may sell selected fixed-term customer receivables to unrelated third parties on a periodic basis, without recourse.  The amount of customer receivables sold for this purpose was $414 million and $406 million for the nine months ended October 30, 2020 and November 1, 2019, respectively.  The Company’s continuing involvement in the above mentioned customer receivables is primarily limited to servicing arrangements.
  (was, 2020-09-04, similarity 0.6115):
[0001571996-20-000045:note_history:30]
To manage certain concentrations of customer credit exposure, the Company may sell selected fixed-term customer receivables to unrelated third parties on a periodic basis, without recourse.  The amount of customer receivables sold for this purpose was $228 million and $246 million for the six months ended July 31, 2020 and August 2, 2019, respectively.  The Company’s continuing involvement in the above mentioned customer receivables is primarily limited to servicing arrangements.

- removed (2020-12-07):
[0001571996-20-000045:note_history:31]
|  | Three Months Ended |  |  |  |  |  |  |  |  |  |  |
|  | July 31, 2020 |  |  |  |  |  | August 2, 2019 |  |  |  |  |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |  |  |  |  |  |  |  |  |  |  |
| Allowance for financing receivable losses: |  |  |  |  |  |  |  |  |  |  |  |
| Balances at beginning of period | $ | 144 |  |  | $ | 177 |  |  | $ | 321 |  |  | $ | 70 |  |  | $ | 73 |  |  | $ | 143 |  |
| Charge-offs, net of recoveries | (18) |  |  | (7) |  |  | (25) |  |  | (15) |  |  | (9) |  |  | (24) |  |
| Provision charged to income statement | 17 |  |  | 10 |  |  | 27 |  |  | 12 |  |  | 7 |  |  | 19 |  |
| Balances at end of period | $ | 143 |  |  | $ | 180 |  |  | $ | 323 |  |  | $ | 67 |  |  | $ | 71 |  |  | $ | 138 |  |

- removed (2020-12-07):
[0001571996-20-000045:note_history:32]
|  | Six Months Ended |  |  |  |  |  |  |  |  |  |  |
|  | July 31, 2020 |  |  |  |  |  | August 2, 2019 |  |  |  |  |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |  |  |  |  |  |  |  |  |  |  |
| Allowance for financing receivable losses: |  |  |  |  |  |  |  |  |  |  |  |
| Balances at beginning of period | $ | 70 |  |  | $ | 79 |  |  | $ | 149 |  |  | $ | 75 |  |  | $ | 61 |  |  | $ | 136 |  |
| Adjustment for adoption of accounting standard (Note 1) | 40 |  |  | 71 |  |  | 111 |  |  | — |  |  | — |  |  | — |  |
| Charge-offs, net of recoveries | (38) |  |  | (16) |  |  | (54) |  |  | (35) |  |  | (12) |  |  | (47) |  |
| Provision charged to income statement | 71 |  |  | 46 |  |  | 117 |  |  | 27 |  |  | 22 |  |  | 49 |  |
| Balances at end of period | $ | 143 |  |  | $ | 180 |  |  | $ | 323 |  |  | $ | 67 |  |  | $ | 71 |  |  | $ | 138 |  |

- removed (2020-12-07):
[0001571996-20-000045:note_history:33]
Interest income on sales-type lease receivables was $66 million for both the three months ended July 31, 2020 and August 2, 2019, and $131 million and $130 million for the six months ended July 31, 2020 and August 2, 2019, respectively.

- removed (2020-12-07):
[0001571996-20-000045:note_history:34]
|  | July 31, 2020 |
| Fiscal Years | (in millions) |
| Fiscal 2021 (remaining six months) | $ | 1,475 |  |
| Fiscal 2022 | 2,159 |  |
| Fiscal 2023 | 1,347 |  |
| Fiscal 2024 | 609 |  |
| Fiscal 2025 and beyond | 250 |  |
| Total undiscounted cash flows | 5,840 |  |
| Fixed-term loans | 4,075 |  |
| Revolving loans | 778 |  |
| Less: unearned income | (660) |  |
| Total customer receivables, gross | $ | 10,033 |  |

- removed (2020-12-07):
[0001571996-20-000045:note_history:35]
Operating lease income relating to lease payments was $103 million and $27 million for the three months ended July 31, 2020 and August 2, 2019, respectively, and $190 million and $31 million for the six months ended July 31, 2020 and August 2, 2019, respectively.  Depreciation expense was $74 million and $21 million for the three months ended July 31, 2020 and August 2, 2019, respectively, and $136 million and $24 million for the six months ended July 31, 2020 and August 2, 2019, respectively.

- removed (2020-12-07):
[0001571996-20-000045:note_history:36]
Note Payable — On November 27, 2017, the Company entered into an unsecured credit agreement to fund receivables in Mexico.  As of July 31, 2020, the aggregate principal amount of the note payable is $187 million.  The note bears interest at either the applicable London Interbank Offered Rate (“LIBOR”) plus 2.25%, for the borrowings denominated in U.S. dollars, or the Mexican Interbank Equilibrium Interest Rate (“TIIE”) plus 2.00%, for the borrowings denominated in Mexican pesos.  The note will mature on December 1, 2020.

- removed (2020-12-07):
[0001571996-20-000045:note_history:37]
Loan and lease payments and associated equipment transferred via securitization through SPEs were $1.2 billion and $1.3 billion for the three months ended July 31, 2020 and August 2, 2019, respectively, and $3.0 billion and $2.8 billion for the six months ended July 31, 2020 and August 2, 2019, respectively.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2020-12-07):
[0001571996-20-000051:note_history:38]
|  | October 30, 2020 |  | January 31, 2020 |
|  | (in millions) |
| Secured Debt |  |  |  |
| Senior Secured Credit Facilities: |  |  |  |
| 2.75% Term Loan B-1 Facility due September 2025 | $ | 4,691 |  |  | $ | 4,738 |  |
| 1.90% Term Loan A-4 Facility due December 2023 | 679 |  |  | 679 |  |
| 1.90% Term Loan A-6 Facility due March 2024 | 3,316 |  |  | 3,497 |  |
| First Lien Notes: |  |  |  |
| 4.42% due June 2021 | — |  |  | 4,500 |  |
| 5.45% due June 2023 | 3,750 |  |  | 3,750 |  |
| 4.00% due July 2024 | 1,000 |  |  | 1,000 |  |
| 5.85% due July 2025 | 1,000 |  |  | — |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 4.90% due October 2026 | 1,750 |  |  | 1,750 |  |
| 6.10% due July 2027 | 500 |  |  | — |  |
| 5.30% due October 2029 | 1,750 |  |  | 1,750 |  |
| 6.20% due July 2030 | 750 |  |  | — |  |
| 8.10% due July 2036 | 1,500 |  |  | 1,500 |  |
| 8.35% due July 2046 | 2,000 |  |  | 2,000 |  |
| Unsecured Debt |  |  |  |
| Unsecured Notes and Debentures: |  |  |  |
| 4.625% due April 2021 | 400 |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| Senior Notes: |  |  |  |
| 5.875% due June 2021 | 1,075 |  |  | 1,075 |  |
| 7.125% due June 2024 | 1,625 |  |  | 1,625 |  |
| EMC Notes: |  |  |  |
| 2.650% due June 2020 | — |  |  | 600 |  |
| 3.375% due June 2023 | 1,000 |  |  | 1,000 |  |
| Debt of Public Subsidiary |  |  |  |
| VMware Notes: |  |  |  |
| 2.30% due August 2020 | — |  |  | 1,250 |  |
| 2.95% due August 2022 | 1,500 |  |  | 1,500 |  |
| 4.50% due May 2025 | 750 |  |  | — |  |
| 4.65% due May 2027 | 500 |  |  | — |  |
| 3.90% due August 2027 | 1,250 |  |  | 1,250 |  |
| 4.70% due May 2030 | 750 |  |  | — |  |
| VMware Term Loan Facility | — |  |  | 1,500 |  |
| DFS Debt (Note 4) | 9,201 |  |  | 7,765 |  |
| Other |  |  |  |
| 2.46% Margin Loan Facility due April 2022 | 4,000 |  |  | 4,000 |  |
| Other | 222 |  |  | 84 |  |
| Total debt, principal amount | $ | 50,411 |  |  | $ | 52,665 |  |

- changed (2020-12-07):
[0001571996-20-000051:note_history:39]
|  | October 30, 2020 |  | January 31, 2020 |
|  | (in millions) |
| Total debt, principal amount | $ | 50,411 |  |  | $ | 52,665 |  |
| Unamortized discount, net of unamortized premium | (217) |  |  | (241) |  |
| Debt issuance costs | (333) |  |  | (368) |  |
| Total debt, carrying value | $ | 49,861 |  |  | $ | 52,056 |  |
| Total short-term debt, carrying value | $ | 6,536 |  |  | $ | 7,737 |  |
| Total long-term debt, carrying value | $ | 43,325 |  |  | $ | 44,319 |  |
  (was, 2020-09-04, similarity 0.9465):
[0001571996-20-000045:note_history:39]
|  | July 31, 2020 |  | January 31, 2020 |
|  | (in millions) |  |  |
| Total debt, principal amount | $ | 54,537 |  |  | $ | 52,665 |  |
| Unamortized discount, net of unamortized premium | (226) |  |  | (241) |  |
| Debt issuance costs | (358) |  |  | (368) |  |
| Total debt, carrying value | $ | 53,953 |  |  | $ | 52,056 |  |
| Total short-term debt, carrying value | $ | 10,345 |  |  | $ | 7,737 |  |
| Total long-term debt, carrying value | $ | 43,608 |  |  | $ | 44,319 |  |

- added (2020-12-07):
[0001571996-20-000051:note_history:40]
During the nine months ended October 30, 2020, the net decrease in the Company’s debt balance was primarily due to:

- added (2020-12-07):
[0001571996-20-000051:note_history:41]
•retirement of $4.5 billion principal amount of 4.42% First Lien Notes due June 2021 via repayment of $4,265 million and open market repurchases of $235 million;

- added (2020-12-07):
[0001571996-20-000051:note_history:42]
•repayment of $1.5 billion principal amount of VMware Term Loan Facility upon maturity;

- added (2020-12-07):
[0001571996-20-000051:note_history:43]
•repayment of $1.25 billion principal amount of 2.30% VMware Notes due August 2020;

- added (2020-12-07):
[0001571996-20-000051:note_history:44]
•repayment of $600 million principal amount of 2.650% EMC Notes due June 2020 upon maturity; and

- added (2020-12-07):
[0001571996-20-000051:note_history:45]
•amortization of approximately $229 million of principal under the Company’s term loan facilities.

- added (2020-12-07):
[0001571996-20-000051:note_history:46]
These decreases in the Company’s debt balance were partially offset by:

- added (2020-12-07):
[0001571996-20-000051:note_history:47]
•issuance of $2.25 billion principal amount of First Lien Notes on April 9, 2020, described below;

- added (2020-12-07):
[0001571996-20-000051:note_history:48]
•issuance of $2.0 billion principal amount of VMware Notes on April 7, 2020, described below; and

- added (2020-12-07):
[0001571996-20-000051:note_history:49]
•incurrence of an additional $1.4 billion, net, in DFS debt to support the expansion of its financing receivables portfolio.

- changed (2020-12-07):
[0001571996-20-000051:note_history:50]
As of October 30, 2020, available borrowings under the Revolving Credit Facility totaled $4.5 billion.  The Senior Secured Credit Facilities provide that the borrowers have the right at any time, subject to customary conditions, to request incremental term loans or incremental revolving commitments.
  (was, 2020-09-04, similarity 0.981):
[0001571996-20-000045:note_history:50]
As of July 31, 2020, available borrowings under the Revolving Credit Facility totaled $4.5 billion.  The Senior Secured Credit Facilities provide that the borrowers have the right at any time, subject to customary conditions, to request incremental term loans or incremental revolving commitments.

- changed (2020-12-07):
[0001571996-20-000051:note_history:51]
VMware Revolving Credit Facility — On September 12, 2017, VMware, Inc. entered into an unsecured credit agreement, establishing a revolving credit facility (the “VMware Revolving Credit Facility”) with a syndicate of lenders that provides the company with a borrowing capacity of up to $1.0 billion for VMware, Inc. general corporate purposes.  Commitments under the VMware Revolving Credit Facility are available for a period of five years, which may be extended, subject to the satisfaction of certain conditions, by up to two one year periods.  The credit agreement contains certain representations, warranties, and covenants.  Commitment fees, interest rates, and other terms of borrowing under the VMware Revolving Credit Facility may vary based on VMware, Inc.’s external credit ratings.  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.  As of October 30, 2020, there were no outstanding borrowings under the VMware Revolving Credit Facility.
  (was, 2020-09-04, similarity 0.9951):
[0001571996-20-000045:note_history:51]
VMware Revolving Credit Facility — On September 12, 2017, VMware, Inc. entered into an unsecured credit agreement, establishing a revolving credit facility (the “VMware Revolving Credit Facility”) with a syndicate of lenders that provides the company with a borrowing capacity of up to $1.0 billion for VMware, Inc. general corporate purposes.  Commitments under the VMware Revolving Credit Facility are available for a period of five years, which may be extended, subject to the satisfaction of certain conditions, by up to two one year periods.  The credit agreement contains certain representations, warranties, and covenants.  Commitment fees, interest rates, and other terms of borrowing under the VMware Revolving Credit Facility may vary based on VMware, Inc.’s external credit ratings.  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.  As of July 31, 2020, there were no outstanding borrowings under the VMware Revolving Credit Facility.

- changed (2020-12-07):
[0001571996-20-000051:note_history:52]
VMware Term Loan Facility — On September 26, 2019, VMware, Inc. entered into a senior unsecured term loan facility (the “VMware Term Loan Facility”) with a syndicate of lenders that provided VMware, Inc. with a borrowing capacity of up to $2.0 billion through February 7, 2020, for VMware, Inc. general corporate purposes.  During the three months ended October 30, 2020, VMware, Inc. repaid the outstanding borrowings of $1.5 billion under the VMware Term Loan Facility.
  (was, 2020-09-04, similarity 0.6008):
[0001571996-20-000045:note_history:52]
VMware Term Loan Facility — On September 26, 2019, VMware, Inc. entered into a senior unsecured term loan facility (the “VMware Term Loan Facility”) with a syndicate of lenders that provided VMware, Inc. with a borrowing capacity of up to $2.0 billion through February 7, 2020, for VMware, Inc. general corporate purposes.  The VMware Term Loan Facility matures during the third quarter of Fiscal 2021, on the 364th day following the initial funding under the facility.  The VMware Term Loan Facility bears interest at LIBOR plus 0.75% to 1.25%, or an alternative base rate plus 0.00% to 0.25%, depending on VMware Inc.’s external credit ratings.

- changed (2020-12-07):
[0001571996-20-000051:note_history:53]
As of January 31, 2020, the outstanding borrowings under the VMware Term Loan Facility were $1.5 billion.  None of the net proceeds of such borrowings were made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.
  (was, 2020-09-04, similarity 0.6829):
[0001571996-20-000045:note_history:53]
As of July 31, 2020 and January 31, 2020, the outstanding borrowings under the VMware Term Loan Facility were $1.5 billion, with no remaining amount available for additional borrowings.  The VMware Term Loan Facility agreement contains certain representations, warranties, and covenants.  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.

- changed (2020-12-07):
[0001571996-20-000051:note_history:54]
The following table presents the aggregate future maturities of the Company’s debt as of October 30, 2020 for the periods indicated:
  (was, 2020-09-04, similarity 0.9562):
[0001571996-20-000045:note_history:54]
The following table presents the aggregate future maturities of the Company’s debt as of July 31, 2020 for the periods indicated:

- changed (2020-12-07):
[0001571996-20-000051:note_history:55]
|  | Maturities by Fiscal Year |
|  | 2021 (remaining three months) |  | 2022 |  | 2023 |  | 2024 |  | 2025 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Secured Credit Facilities and First Lien Notes | $ | — |  |  | $ | 172 |  |  | $ | 286 |  |  | $ | 7,384 |  |  | $ | 1,047 |  |  | $ | 18,297 |  |  | $ | 27,186 |  |
| Unsecured Notes and Debentures | — |  |  | 400 |  |  | — |  |  | — |  |  | — |  |  | 952 |  |  | 1,352 |  |
| Senior Notes and EMC Notes | — |  |  | 1,075 |  |  | — |  |  | 1,000 |  |  | 1,625 |  |  | — |  |  | 3,700 |  |
| VMware Notes | — |  |  | — |  |  | 1,500 |  |  | — |  |  | — |  |  | 3,250 |  |  | 4,750 |  |
| DFS Debt | 2,012 |  |  | 3,481 |  |  | 2,654 |  |  | 356 |  |  | 692 |  |  | 6 |  |  | 9,201 |  |
| Margin Loan Facility | — |  |  | — |  |  | 4,000 |  |  | — |  |  | — |  |  | — |  |  | 4,000 |  |
| Other | 3 |  |  | 12 |  |  | 12 |  |  | 156 |  |  | 8 |  |  | 31 |  |  | 222 |  |
| Total maturities, principal amount | 2,015 |  |  | 5,140 |  |  | 8,452 |  |  | 8,896 |  |  | 3,372 |  |  | 22,536 |  |  | 50,411 |  |
| Associated carrying value adjustments | (1) |  |  | (10) |  |  | (14) |  |  | (38) |  |  | (83) |  |  | (404) |  |  | (550) |  |
| Total maturities, carrying value amount | $ | 2,014 |  |  | $ | 5,130 |  |  | $ | 8,438 |  |  | $ | 8,858 |  |  | $ | 3,289 |  |  | $ | 22,132 |  |  | $ | 49,861 |  |
  (was, 2020-09-04, similarity 0.9111):
[0001571996-20-000045:note_history:55]
|  | Maturities by Fiscal Year |  |  |  |  |  |  |  |  |  |  |  |  |
|  | 2021 (remaining six months) |  | 2022 |  | 2023 |  | 2024 |  | 2025 |  | Thereafter |  | Total |
|  | (in millions) |  |  |  |  |  |  |  |  |  |  |  |  |
| Senior Secured Credit Facilities and First Lien Notes | $ | — |  |  | $ | 3,237 |  |  | $ | 286 |  |  | $ | 6,702 |  |  | $ | 1,775 |  |  | $ | 18,251 |  |  | $ | 30,251 |  |
| Unsecured Notes and Debentures | — |  |  | 400 |  |  | — |  |  | — |  |  | — |  |  | 952 |  |  | 1,352 |  |
| Senior Notes and EMC Notes | — |  |  | 1,075 |  |  | — |  |  | 1,000 |  |  | 1,625 |  |  | — |  |  | 3,700 |  |
| VMware Notes | 1,500 |  |  | — |  |  | 1,500 |  |  | — |  |  | — |  |  | 3,250 |  |  | 6,250 |  |
| DFS Debt | 2,912 |  |  | 2,906 |  |  | 2,229 |  |  | 163 |  |  | 627 |  |  | — |  |  | 8,837 |  |
| Margin Loan Facility | — |  |  | — |  |  | 4,000 |  |  | — |  |  | — |  |  | — |  |  | 4,000 |  |
| Other | 5 |  |  | 10 |  |  | 11 |  |  | 8 |  |  | 8 |  |  | 105 |  |  | 147 |  |
| Total maturities, principal amount | 4,417 |  |  | 7,628 |  |  | 8,026 |  |  | 7,873 |  |  | 4,035 |  |  | 22,558 |  |  | 54,537 |  |
| Associated carrying value adjustments | (1) |  |  | (29) |  |  | (21) |  |  | (43) |  |  | (84) |  |  | (406) |  |  | (584) |  |
| Total maturities, carrying value amount | $ | 4,416 |  |  | $ | 7,599 |  |  | $ | 8,005 |  |  | $ | 7,830 |  |  | $ | 3,951 |  |  | $ | 22,152 |  |  | $ | 53,953 |  |

- changed (2020-12-07):
[0001571996-20-000051:note_history:56]
As of October 30, 2020, the Company had certain consolidated subsidiaries that were designated as unrestricted subsidiaries for all purposes of the applicable credit agreements and the indentures governing the First Lien Notes and the Senior Notes.  Substantially all of the net assets of the Company’s consolidated subsidiaries were restricted, with the exception of the Company’s unrestricted subsidiaries, primarily VMware, Inc., Secureworks, and their respective subsidiaries, as of October 30, 2020.
  (was, 2020-09-04, similarity 0.9775):
[0001571996-20-000045:note_history:56]
As of July 31, 2020, the Company had certain consolidated subsidiaries that were designated as unrestricted subsidiaries for all purposes of the applicable credit agreements and the indentures governing the First Lien Notes and the Senior Notes.  Substantially all of the net assets of the Company’s consolidated subsidiaries were restricted, with the exception of the Company’s unrestricted subsidiaries, primarily VMware, Inc., Secureworks, and their respective subsidiaries, as of July 31, 2020.

- changed (2020-12-07):
[0001571996-20-000051:note_history:57]
The Term Loan A-4 Facility, the Term Loan A-6 Facility, and the Revolving Credit Facility are subject to a first lien leverage ratio covenant that is tested at the end of each fiscal quarter of Dell with respect to Dell’s preceding four fiscal quarters.  The Company was in compliance with all financial covenants as of October 30, 2020.
  (was, 2020-09-04, similarity 0.9833):
[0001571996-20-000045:note_history:57]
The Term Loan A-4 Facility, the Term Loan A-6 Facility, and the Revolving Credit Facility are subject to a first lien leverage ratio covenant that is tested at the end of each fiscal quarter of Dell with respect to Dell’s preceding four fiscal quarters.  The Company was in compliance with all financial covenants as of July 31, 2020.

- removed (2020-12-07):
[0001571996-20-000045:note_history:58]
|  | July 31, 2020 |  | January 31, 2020 |
|  | (in millions) |  |  |
| Secured Debt |  |  |  |
| Senior Secured Credit Facilities: |  |  |  |
| 2.75% Term Loan B-1 Facility due September 2025 | $ | 4,691 |  |  | $ | 4,738 |  |
| 1.93% Term Loan A-4 Facility due December 2023 | 679 |  |  | 679 |  |
| 1.93% Term Loan A-6 Facility due March 2024 | 3,316 |  |  | 3,497 |  |
| First Lien Notes: |  |  |  |
| 4.42% due June 2021 | 3,065 |  |  | 4,500 |  |
| 5.45% due June 2023 | 3,750 |  |  | 3,750 |  |
| 4.00% due July 2024 | 1,000 |  |  | 1,000 |  |
| 5.85% due July 2025 | 1,000 |  |  | — |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 4.90% due October 2026 | 1,750 |  |  | 1,750 |  |
| 6.10% due July 2027 | 500 |  |  | — |  |
| 5.30% due October 2029 | 1,750 |  |  | 1,750 |  |
| 6.20% due July 2030 | 750 |  |  | — |  |
| 8.10% due July 2036 | 1,500 |  |  | 1,500 |  |
| 8.35% due July 2046 | 2,000 |  |  | 2,000 |  |
| Unsecured Debt |  |  |  |
| Unsecured Notes and Debentures: |  |  |  |
| 4.625% due April 2021 | 400 |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| Senior Notes: |  |  |  |
| 5.875% due June 2021 | 1,075 |  |  | 1,075 |  |
| 7.125% due June 2024 | 1,625 |  |  | 1,625 |  |
| EMC Notes: |  |  |  |
| 2.650% due June 2020 | — |  |  | 600 |  |
| 3.375% due June 2023 | 1,000 |  |  | 1,000 |  |
| Debt of Public Subsidiary |  |  |  |
| VMware Notes: |  |  |  |
| 2.30% due August 2020 | — |  |  | 1,250 |  |
| 2.95% due August 2022 | 1,500 |  |  | 1,500 |  |
| 4.50% due May 2025 | 750 |  |  | — |  |
| 4.65% due May 2027 | 500 |  |  | — |  |
| 3.90% due August 2027 | 1,250 |  |  | 1,250 |  |
| 4.70% due May 2030 | 750 |  |  | — |  |
| VMware Term Loan Facility | 1,500 |  |  | 1,500 |  |
| DFS Debt (Note 4) | 8,837 |  |  | 7,765 |  |
| Other |  |  |  |
| 2.51% Margin Loan Facility due April 2022 | 4,000 |  |  | 4,000 |  |
| Other | 147 |  |  | 84 |  |
| Total debt, principal amount | $ | 54,537 |  |  | $ | 52,665 |  |

- removed (2020-12-07):
[0001571996-20-000045:note_history:59]
During the six months ended July 31, 2020, the net increase in the Company’s debt balance was primarily due to new issuances of $2.25 billion of First Lien Notes on April 9, 2020 and $2.0 billion of VMware Notes on April 7, 2020, both described below, and the incurrence of an additional $1.1 billion, net, in DFS debt to support the expansion of its financing receivables portfolio.  These increases were partially offset by repayment of $1.2 billion and open market repurchases of $235 million of 4.42% First Lien Notes due June 2021, repayment of $600 million principal amount of 2.650% EMC Notes due June 2020 upon maturity, approximately $229 million of principal amortization under the Company’s term loan facilities, and repayment of $1.25 billion principal amount of 2.30% VMware Notes due August 2020.


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-12-07):
[0001571996-20-000051:note_history:60]
|  | October 30, 2020 |  | January 31, 2020 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Secured Credit Facilities | $ | 8.6 |  |  | $ | 8.6 |  |  | $ | 8.8 |  |  | $ | 9.0 |  |
| First Lien Notes | $ | 18.3 |  |  | $ | 22.0 |  |  | $ | 20.5 |  |  | $ | 23.9 |  |
| Unsecured Notes and Debentures | $ | 1.2 |  |  | $ | 1.5 |  |  | $ | 1.2 |  |  | $ | 1.5 |  |
| Senior Notes | $ | 2.6 |  |  | $ | 2.8 |  |  | $ | 2.6 |  |  | $ | 2.8 |  |
| EMC Notes | $ | 1.0 |  |  | $ | 1.0 |  |  | $ | 1.6 |  |  | $ | 1.6 |  |
| VMware Notes and VMware Term Loan Facility | $ | 4.7 |  |  | $ | 5.3 |  |  | $ | 5.5 |  |  | $ | 5.6 |  |
| Margin Loan Facility | $ | 4.0 |  |  | $ | 3.9 |  |  | $ | 4.0 |  |  | $ | 3.9 |  |
  (was, 2020-09-04, similarity 0.8206):
[0001571996-20-000045:note_history:60]
|  | July 31, 2020 |  |  |  | January 31, 2020 |  |  |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |  |  |  |  |  |  |
| Senior Secured Credit Facilities | $ | 8.6 |  |  | $ | 8.6 |  |  | $ | 8.8 |  |  | $ | 9.0 |  |
| First Lien Notes | $ | 21.3 |  |  | $ | 25.1 |  |  | $ | 20.5 |  |  | $ | 23.9 |  |
| Unsecured Notes and Debentures | $ | 1.2 |  |  | $ | 1.5 |  |  | $ | 1.2 |  |  | $ | 1.5 |  |
| Senior Notes | $ | 2.6 |  |  | $ | 2.8 |  |  | $ | 2.6 |  |  | $ | 2.8 |  |
| EMC Notes | $ | 1.0 |  |  | $ | 1.1 |  |  | $ | 1.6 |  |  | $ | 1.6 |  |
| VMware Notes and VMware Term Loan Facility | $ | 6.2 |  |  | $ | 6.8 |  |  | $ | 5.5 |  |  | $ | 5.6 |  |
| Margin Loan Facility | $ | 4.0 |  |  | $ | 3.9 |  |  | $ | 4.0 |  |  | $ | 3.9 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-12-07):
[0001571996-20-000051:note_history:61]
|  | October 30, 2020 |  | January 31, 2020 |
|  | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing and securitization facilities | $ | 2,574 |  |  | $ | 2,606 |  |
| Fixed-term securitization offerings | 3,465 |  |  | 2,593 |  |
| Other | 94 |  |  | 141 |  |
| Total DFS U.S. debt | 6,133 |  |  | 5,340 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 860 |  |  | 743 |  |
| Other borrowings | 791 |  |  | 931 |  |
| Note payable | 250 |  |  | 200 |  |
| Dell Bank Senior Unsecured Eurobonds | 1,167 |  |  | 551 |  |
| Total DFS international debt | 3,068 |  |  | 2,425 |  |
| Total DFS debt | $ | 9,201 |  |  | $ | 7,765 |  |
| Total short-term DFS debt | $ | 4,884 |  |  | $ | 4,152 |  |
| Total long-term DFS debt | $ | 4,317 |  |  | $ | 3,613 |  |
  (was, 2020-09-04, similarity 0.9674):
[0001571996-20-000045:note_history:61]
|  | July 31, 2020 |  | January 31, 2020 |
|  | (in millions) |  |  |
| DFS U.S. debt: |  |  |  |
| Asset-based financing and securitization facilities | $ | 2,936 |  |  | $ | 2,606 |  |
| Fixed-term securitization offerings | 2,788 |  |  | 2,593 |  |
| Other | 187 |  |  | 141 |  |
| Total DFS U.S. debt | 5,911 |  |  | 5,340 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 835 |  |  | 743 |  |
| Other borrowings | 719 |  |  | 931 |  |
| Note payable | 187 |  |  | 200 |  |
| Dell Bank Senior Unsecured Eurobonds | 1,185 |  |  | 551 |  |
| Total DFS international debt | 2,926 |  |  | 2,425 |  |
| Total DFS debt | $ | 8,837 |  |  | $ | 7,765 |  |
| Total short-term DFS debt | $ | 4,188 |  |  | $ | 4,152 |  |
| Total long-term DFS debt | $ | 4,649 |  |  | $ | 3,613 |  |

- added (2020-12-07):
[0001571996-20-000051:note_history:62]
|  | October 30, 2020 |  | January 31, 2020 |
|  | (in millions) |
| Secured Debt |  |  |  |
| Senior Secured Credit Facilities: |  |  |  |
| 2.75% Term Loan B-1 Facility due September 2025 | $ | 4,691 |  |  | $ | 4,738 |  |
| 1.90% Term Loan A-4 Facility due December 2023 | 679 |  |  | 679 |  |
| 1.90% Term Loan A-6 Facility due March 2024 | 3,316 |  |  | 3,497 |  |
| First Lien Notes: |  |  |  |
| 4.42% due June 2021 | — |  |  | 4,500 |  |
| 5.45% due June 2023 | 3,750 |  |  | 3,750 |  |
| 4.00% due July 2024 | 1,000 |  |  | 1,000 |  |
| 5.85% due July 2025 | 1,000 |  |  | — |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 4.90% due October 2026 | 1,750 |  |  | 1,750 |  |
| 6.10% due July 2027 | 500 |  |  | — |  |
| 5.30% due October 2029 | 1,750 |  |  | 1,750 |  |
| 6.20% due July 2030 | 750 |  |  | — |  |
| 8.10% due July 2036 | 1,500 |  |  | 1,500 |  |
| 8.35% due July 2046 | 2,000 |  |  | 2,000 |  |
| Unsecured Debt |  |  |  |
| Unsecured Notes and Debentures: |  |  |  |
| 4.625% due April 2021 | 400 |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| Senior Notes: |  |  |  |
| 5.875% due June 2021 | 1,075 |  |  | 1,075 |  |
| 7.125% due June 2024 | 1,625 |  |  | 1,625 |  |
| EMC Notes: |  |  |  |
| 2.650% due June 2020 | — |  |  | 600 |  |
| 3.375% due June 2023 | 1,000 |  |  | 1,000 |  |
| Debt of Public Subsidiary |  |  |  |
| VMware Notes: |  |  |  |
| 2.30% due August 2020 | — |  |  | 1,250 |  |
| 2.95% due August 2022 | 1,500 |  |  | 1,500 |  |
| 4.50% due May 2025 | 750 |  |  | — |  |
| 4.65% due May 2027 | 500 |  |  | — |  |
| 3.90% due August 2027 | 1,250 |  |  | 1,250 |  |
| 4.70% due May 2030 | 750 |  |  | — |  |
| VMware Term Loan Facility | — |  |  | 1,500 |  |
| DFS Debt (Note 4) | 9,201 |  |  | 7,765 |  |
| Other |  |  |  |
| 2.46% Margin Loan Facility due April 2022 | 4,000 |  |  | 4,000 |  |
| Other | 222 |  |  | 84 |  |
| Total debt, principal amount | $ | 50,411 |  |  | $ | 52,665 |  |

- changed (2020-12-07):
[0001571996-20-000051:note_history:63]
|  | October 30, 2020 |  | January 31, 2020 |
|  | (in millions) |
| Total debt, principal amount | $ | 50,411 |  |  | $ | 52,665 |  |
| Unamortized discount, net of unamortized premium | (217) |  |  | (241) |  |
| Debt issuance costs | (333) |  |  | (368) |  |
| Total debt, carrying value | $ | 49,861 |  |  | $ | 52,056 |  |
| Total short-term debt, carrying value | $ | 6,536 |  |  | $ | 7,737 |  |
| Total long-term debt, carrying value | $ | 43,325 |  |  | $ | 44,319 |  |
  (was, 2020-09-04, similarity 0.9465):
[0001571996-20-000045:note_history:63]
|  | July 31, 2020 |  | January 31, 2020 |
|  | (in millions) |  |  |
| Total debt, principal amount | $ | 54,537 |  |  | $ | 52,665 |  |
| Unamortized discount, net of unamortized premium | (226) |  |  | (241) |  |
| Debt issuance costs | (358) |  |  | (368) |  |
| Total debt, carrying value | $ | 53,953 |  |  | $ | 52,056 |  |
| Total short-term debt, carrying value | $ | 10,345 |  |  | $ | 7,737 |  |
| Total long-term debt, carrying value | $ | 43,608 |  |  | $ | 44,319 |  |

- removed (2020-12-07):
[0001571996-20-000045:note_history:64]
|  | July 31, 2020 |  | January 31, 2020 |
|  | (in millions) |  |  |
| Secured Debt |  |  |  |
| Senior Secured Credit Facilities: |  |  |  |
| 2.75% Term Loan B-1 Facility due September 2025 | $ | 4,691 |  |  | $ | 4,738 |  |
| 1.93% Term Loan A-4 Facility due December 2023 | 679 |  |  | 679 |  |
| 1.93% Term Loan A-6 Facility due March 2024 | 3,316 |  |  | 3,497 |  |
| First Lien Notes: |  |  |  |
| 4.42% due June 2021 | 3,065 |  |  | 4,500 |  |
| 5.45% due June 2023 | 3,750 |  |  | 3,750 |  |
| 4.00% due July 2024 | 1,000 |  |  | 1,000 |  |
| 5.85% due July 2025 | 1,000 |  |  | — |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 4.90% due October 2026 | 1,750 |  |  | 1,750 |  |
| 6.10% due July 2027 | 500 |  |  | — |  |
| 5.30% due October 2029 | 1,750 |  |  | 1,750 |  |
| 6.20% due July 2030 | 750 |  |  | — |  |
| 8.10% due July 2036 | 1,500 |  |  | 1,500 |  |
| 8.35% due July 2046 | 2,000 |  |  | 2,000 |  |
| Unsecured Debt |  |  |  |
| Unsecured Notes and Debentures: |  |  |  |
| 4.625% due April 2021 | 400 |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| Senior Notes: |  |  |  |
| 5.875% due June 2021 | 1,075 |  |  | 1,075 |  |
| 7.125% due June 2024 | 1,625 |  |  | 1,625 |  |
| EMC Notes: |  |  |  |
| 2.650% due June 2020 | — |  |  | 600 |  |
| 3.375% due June 2023 | 1,000 |  |  | 1,000 |  |
| Debt of Public Subsidiary |  |  |  |
| VMware Notes: |  |  |  |
| 2.30% due August 2020 | — |  |  | 1,250 |  |
| 2.95% due August 2022 | 1,500 |  |  | 1,500 |  |
| 4.50% due May 2025 | 750 |  |  | — |  |
| 4.65% due May 2027 | 500 |  |  | — |  |
| 3.90% due August 2027 | 1,250 |  |  | 1,250 |  |
| 4.70% due May 2030 | 750 |  |  | — |  |
| VMware Term Loan Facility | 1,500 |  |  | 1,500 |  |
| DFS Debt (Note 4) | 8,837 |  |  | 7,765 |  |
| Other |  |  |  |
| 2.51% Margin Loan Facility due April 2022 | 4,000 |  |  | 4,000 |  |
| Other | 147 |  |  | 84 |  |
| Total debt, principal amount | $ | 54,537 |  |  | $ | 52,665 |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-12-07):
[0001571996-20-000051:note_history:65]
The following table presents the aggregate future maturities of the Company’s debt as of October 30, 2020 for the periods indicated:
  (was, 2020-09-04, similarity 0.9562):
[0001571996-20-000045:note_history:65]
The following table presents the aggregate future maturities of the Company’s debt as of July 31, 2020 for the periods indicated:

- changed (2020-12-07):
[0001571996-20-000051:note_history:66]
|  | Maturities by Fiscal Year |
|  | 2021 (remaining three months) |  | 2022 |  | 2023 |  | 2024 |  | 2025 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Secured Credit Facilities and First Lien Notes | $ | — |  |  | $ | 172 |  |  | $ | 286 |  |  | $ | 7,384 |  |  | $ | 1,047 |  |  | $ | 18,297 |  |  | $ | 27,186 |  |
| Unsecured Notes and Debentures | — |  |  | 400 |  |  | — |  |  | — |  |  | — |  |  | 952 |  |  | 1,352 |  |
| Senior Notes and EMC Notes | — |  |  | 1,075 |  |  | — |  |  | 1,000 |  |  | 1,625 |  |  | — |  |  | 3,700 |  |
| VMware Notes | — |  |  | — |  |  | 1,500 |  |  | — |  |  | — |  |  | 3,250 |  |  | 4,750 |  |
| DFS Debt | 2,012 |  |  | 3,481 |  |  | 2,654 |  |  | 356 |  |  | 692 |  |  | 6 |  |  | 9,201 |  |
| Margin Loan Facility | — |  |  | — |  |  | 4,000 |  |  | — |  |  | — |  |  | — |  |  | 4,000 |  |
| Other | 3 |  |  | 12 |  |  | 12 |  |  | 156 |  |  | 8 |  |  | 31 |  |  | 222 |  |
| Total maturities, principal amount | 2,015 |  |  | 5,140 |  |  | 8,452 |  |  | 8,896 |  |  | 3,372 |  |  | 22,536 |  |  | 50,411 |  |
| Associated carrying value adjustments | (1) |  |  | (10) |  |  | (14) |  |  | (38) |  |  | (83) |  |  | (404) |  |  | (550) |  |
| Total maturities, carrying value amount | $ | 2,014 |  |  | $ | 5,130 |  |  | $ | 8,438 |  |  | $ | 8,858 |  |  | $ | 3,289 |  |  | $ | 22,132 |  |  | $ | 49,861 |  |
  (was, 2020-09-04, similarity 0.9111):
[0001571996-20-000045:note_history:66]
|  | Maturities by Fiscal Year |  |  |  |  |  |  |  |  |  |  |  |  |
|  | 2021 (remaining six months) |  | 2022 |  | 2023 |  | 2024 |  | 2025 |  | Thereafter |  | Total |
|  | (in millions) |  |  |  |  |  |  |  |  |  |  |  |  |
| Senior Secured Credit Facilities and First Lien Notes | $ | — |  |  | $ | 3,237 |  |  | $ | 286 |  |  | $ | 6,702 |  |  | $ | 1,775 |  |  | $ | 18,251 |  |  | $ | 30,251 |  |
| Unsecured Notes and Debentures | — |  |  | 400 |  |  | — |  |  | — |  |  | — |  |  | 952 |  |  | 1,352 |  |
| Senior Notes and EMC Notes | — |  |  | 1,075 |  |  | — |  |  | 1,000 |  |  | 1,625 |  |  | — |  |  | 3,700 |  |
| VMware Notes | 1,500 |  |  | — |  |  | 1,500 |  |  | — |  |  | — |  |  | 3,250 |  |  | 6,250 |  |
| DFS Debt | 2,912 |  |  | 2,906 |  |  | 2,229 |  |  | 163 |  |  | 627 |  |  | — |  |  | 8,837 |  |
| Margin Loan Facility | — |  |  | — |  |  | 4,000 |  |  | — |  |  | — |  |  | — |  |  | 4,000 |  |
| Other | 5 |  |  | 10 |  |  | 11 |  |  | 8 |  |  | 8 |  |  | 105 |  |  | 147 |  |
| Total maturities, principal amount | 4,417 |  |  | 7,628 |  |  | 8,026 |  |  | 7,873 |  |  | 4,035 |  |  | 22,558 |  |  | 54,537 |  |
| Associated carrying value adjustments | (1) |  |  | (29) |  |  | (21) |  |  | (43) |  |  | (84) |  |  | (406) |  |  | (584) |  |
| Total maturities, carrying value amount | $ | 4,416 |  |  | $ | 7,599 |  |  | $ | 8,005 |  |  | $ | 7,830 |  |  | $ | 3,951 |  |  | $ | 22,152 |  |  | $ | 53,953 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-12-07):
[0001571996-20-000051:note_history:67]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 30, 2020 |  | November 1, 2019 |  | October 30, 2020 |  | November 1, 2019 |
|  | (in millions) |
| Net revenue: |  |  |  |  |  |  |  |
| Infrastructure Solutions Group: |  |  |  |  |  |  |  |
| Servers and networking | $ | 4,164 |  |  | $ | 4,241 |  |  | $ | 12,118 |  |  | $ | 12,858 |  |
| Storage | 3,860 |  |  | 4,149 |  |  | 11,682 |  |  | 12,355 |  |
| Total ISG net revenue | 8,024 |  |  | 8,390 |  |  | 23,800 |  |  | 25,213 |  |
| Client Solutions Group: |  |  |  |  |  |  |  |
| Commercial | 8,783 |  |  | 8,330 |  |  | 25,456 |  |  | 25,714 |  |
| Consumer | 3,503 |  |  | 3,080 |  |  | 9,137 |  |  | 8,354 |  |
| Total CSG net revenue | 12,286 |  |  | 11,410 |  |  | 34,593 |  |  | 34,068 |  |
| VMware: |  |  |  |  |  |  |  |
| Total VMware net revenue | 2,893 |  |  | 2,671 |  |  | 8,556 |  |  | 7,779 |  |
| Total segment net revenue | $ | 23,203 |  |  | $ | 22,471 |  |  | $ | 66,949 |  |  | $ | 67,060 |  |
  (was, 2020-09-04, similarity 0.9112):
[0001571996-20-000045:note_history:67]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | July 31, 2020 |  | August 2, 2019 |  | July 31, 2020 |  | August 2, 2019 |
|  | (in millions) |  |  |  |  |  |  |
| Net revenue: |  |  |  |  |  |  |  |
| Infrastructure Solutions Group: |  |  |  |  |  |  |  |
| Servers and networking | $ | 4,196 |  |  | $ | 4,437 |  |  | $ | 7,954 |  |  | $ | 8,617 |  |
| Storage | 4,011 |  |  | 4,184 |  |  | 7,822 |  |  | 8,206 |  |
| Total ISG net revenue | 8,207 |  |  | 8,621 |  |  | 15,776 |  |  | 16,823 |  |
| Client Solutions Group: |  |  |  |  |  |  |  |
| Commercial | 8,039 |  |  | 9,077 |  |  | 16,673 |  |  | 17,384 |  |
| Consumer | 3,164 |  |  | 2,671 |  |  | 5,634 |  |  | 5,274 |  |
| Total CSG net revenue | 11,203 |  |  | 11,748 |  |  | 22,307 |  |  | 22,658 |  |
| VMware: |  |  |  |  |  |  |  |
| Total VMware net revenue | 2,908 |  |  | 2,651 |  |  | 5,663 |  |  | 5,108 |  |
| Total segment net revenue | $ | 22,318 |  |  | $ | 23,020 |  |  | $ | 43,746 |  |  | $ | 44,589 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-12-07):
[0001571996-20-000051:note_history:68]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 30, 2020 |  | November 1, 2019 |  | October 30, 2020 |  | November 1, 2019 |
|  | (in millions) |
| Deferred revenue: |  |  |  |  |  |  |  |
| Deferred revenue at beginning of period | $ | 28,791 |  |  | $ | 25,348 |  |  | $ | 27,800 |  |  | $ | 24,010 |  |
| Revenue deferrals | 5,432 |  |  | 5,326 |  |  | 17,560 |  |  | 16,201 |  |
| Revenue recognized | (5,542) |  |  | (4,922) |  |  | (16,418) |  |  | (14,459) |  |
| Other (a) (b) | — |  |  | 151 |  |  | (261) |  |  | 151 |  |
| Deferred revenue at end of period | $ | 28,681 |  |  | $ | 25,903 |  |  | $ | 28,681 |  |  | $ | 25,903 |  |
| Short-term deferred revenue | $ | 15,259 |  |  | $ | 13,787 |  |  | $ | 15,259 |  |  | $ | 13,787 |  |
| Long-term deferred revenue | $ | 13,422 |  |  | $ | 12,116 |  |  | $ | 13,422 |  |  | $ | 12,116 |  |
  (was, 2020-09-04, similarity 0.8638):
[0001571996-20-000045:note_history:68]
|  | Three Months Ended |  |  |  | Six Months Ended |  |  |
|  | July 31, 2020 |  | August 2, 2019 |  | July 31, 2020 |  | August 2, 2019 |
|  | (in millions) |  |  |  |  |  |  |
| Deferred revenue: |  |  |  |  |  |  |  |
| Deferred revenue at beginning of period | $ | 27,617 |  |  | $ | 24,178 |  |  | $ | 27,800 |  |  | $ | 24,010 |  |
| Revenue deferrals | 6,550 |  |  | 5,975 |  |  | 12,095 |  |  | 10,875 |  |
| Revenue recognized | (5,376) |  |  | (4,805) |  |  | (10,843) |  |  | (9,537) |  |
| Other (a) | — |  |  | — |  |  | (261) |  |  | — |  |
| Deferred revenue at end of period | $ | 28,791 |  |  | $ | 25,348 |  |  | $ | 28,791 |  |  | $ | 25,348 |  |
| Short-term deferred revenue | $ | 15,341 |  |  | $ | 13,568 |  |  | $ | 15,341 |  |  | $ | 13,568 |  |
| Long-term deferred revenue | $ | 13,450 |  |  | $ | 11,780 |  |  | $ | 13,450 |  |  | $ | 11,780 |  |

- added (2020-12-07):
[0001571996-20-000051:note_history:69]
(a) For the nine months ended October 30, 2020, Other consists of divested deferred revenue from the sale of RSA Security.  See Note 1 of the Notes to the Condensed Consolidated Financial Statements for more information about the divestiture of RSA Security.  For the three months ended October 30, 2020, there was no impact to deferred revenue because RSA Security was previously classified as held for sale.

- added (2020-12-07):
[0001571996-20-000051:note_history:70]
(b) For the three and nine months ended November 1, 2019, Other consists of acquired deferred revenue from Carbon Black, Inc. by VMware, Inc.

- changed (2020-12-07):
[0001571996-20-000051:note_history:71]
Remaining Performance Obligations — Remaining performance obligations represent the aggregate amount of the transaction price allocated to performance obligations not delivered, or partially undelivered, as of the end of the reporting period.  Remaining performance obligations include deferred revenue plus unbilled amounts not yet recorded in deferred revenue.  The value of the transaction price allocated to remaining performance obligations as of October 30, 2020 was approximately $38 billion.  The Company expects to recognize approximately 63% of remaining performance obligations as revenue in the next twelve months, and the remainder thereafter.
  (was, 2020-09-04, similarity 0.9915):
[0001571996-20-000045:note_history:71]
Remaining Performance Obligations — Remaining performance obligations represent the aggregate amount of the transaction price allocated to performance obligations not delivered, or partially undelivered, as of the end of the reporting period.  Remaining performance obligations include deferred revenue plus unbilled amounts not yet recorded in deferred revenue.  The value of the transaction price allocated to remaining performance obligations as of July 31, 2020 was approximately $37 billion.  The Company expects to recognize approximately 62% of remaining performance obligations as revenue in the next twelve months, and the remainder thereafter.

- removed (2020-12-07):
[0001571996-20-000045:note_history:72]
(a) Reclassification of RSA Security deferred revenue to liabilities held for sale as of July 31, 2020.  See Note 1 and Note 19 of the Notes to the Condensed Consolidated Financial Statements for more information about the divestiture of RSA Security.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2020-12-07):
[0001571996-20-000045:note_history:73]
NOTE 19 — SUBSEQUENT EVENTS

- removed (2020-12-07):
[0001571996-20-000045:note_history:74]
On September 1, 2020, the Company completed its divestiture of RSA Security to a consortium of investors in an all-cash transaction for approximately $2.082 billion.  For more information about this transaction, see Note 1 of the Notes to the Condensed Consolidated Financial Statements.

- removed (2020-12-07):
[0001571996-20-000045:note_history:75]
Other than the matters identified above, there were no known events occurring after July 31, 2020 and up until the date of the issuance of this report that would materially affect the information presented herein.
