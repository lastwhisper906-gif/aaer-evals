# DELL notes — 0001571996-20-000051


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0001571996-20-000051:notes:1]
Basis of Presentation — The accompanying unaudited Condensed Consolidated Financial Statements should be read in conjunction with the audited Consolidated Financial Statements and accompanying Notes filed with the U.S. Securities and Exchange Commission (“SEC”) in the Company’s Annual Report on Form 10-K for the fiscal year ended January 31, 2020.  These Condensed Consolidated Financial Statements have been prepared in accordance with accounting principles generally accepted in the United States of America (“GAAP”).  In the opinion of management, the accompanying Condensed Consolidated Financial Statements reflect all adjustments of a normal recurring nature considered necessary to fairly state the financial position of Dell Technologies Inc. as of October 30, 2020 and January 31, 2020, the results of its operations and corresponding comprehensive income (loss) for the three and nine months ended October 30, 2020 and November 1, 2019, and its cash flows for the nine months ended October 30, 2020 and November 1, 2019.


## us-gaap:ConsolidationPolicyTextBlock

[0001571996-20-000051:notes:2]
[same as prior period, unchanged from 0001571996-20-000045:notes:2]


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001571996-20-000051:notes:3]
Recently Issued Accounting Pronouncements

[0001571996-20-000051:notes:4]
Accounting for Convertible Instruments and Contracts in an Entity’s Own Equity — In August 2020, the Financial Accounting Standards Board (“FASB”) issued guidance to simplify the accounting for convertible debt instruments and convertible preferred stock, and the derivatives scope exception for contracts in an entity's own equity.  In addition, the guidance on calculating diluted earnings per share has been simplified and made more internally consistent.  Public entities must adopt the new guidance for fiscal years beginning after December 15, 2021, and interim periods within those fiscal years, with early adoption permitted for fiscal periods beginning after December 15, 2020.  The Company will early adopt this guidance for the fiscal year beginning January 30, 2021 on a modified retrospective basis.  Adoption of the new guidance is not expected to have a material impact on the Company’s financial results.

[0001571996-20-000051:notes:5]
Simplifying Accounting for Income Taxes — In December 2019, the FASB issued guidance to simplify the accounting for income taxes by removing certain exceptions to the general principles in Topic 740, Income Taxes, and by clarifying and amending existing guidance in order to improve consistent application of GAAP for other areas of Topic 740.  Public entities must adopt the new guidance for fiscal years beginning after December 15, 2020, and interim periods within those fiscal years, with early adoption permitted for fiscal periods beginning after December 15, 2019.  The Company will adopt this guidance for the fiscal year beginning January 30, 2021.  The Company is currently evaluating the impact of adoption of this guidance.

[0001571996-20-000051:notes:6]
Recently Adopted Accounting Pronouncements

[0001571996-20-000051:notes:7]
Measurement of Credit Losses on Financial Instruments — In June 2016, the FASB issued amended guidance which replaces the current incurred loss impairment methodology for measurement of credit losses on financial instruments with a methodology (the “current expected credit losses model” or “CECL model”) that reflects expected credit losses and requires consideration of a broader range of reasonable and supportable information to inform credit loss estimates.  Under the CECL model, the allowance for losses on financial assets, measured at amortized cost, reflects management’s estimate of credit losses over the remaining expected life of such assets.

[0001571996-20-000051:notes:8]
The Company adopted the standard (the “new CECL standard”) as of February 1, 2020 using the modified retrospective method, with the cumulative-effect adjustment to the opening balance of stockholders’ equity (deficit) as of the adoption date.  The cumulative effect of adopting the new CECL standard resulted in an increase of $111 million and $27 million to the allowance for expected credit losses within financing receivables, net and accounts receivable, net, respectively, on the Condensed Consolidated Statements of Financial Position, and a corresponding decrease of $28 million to other non-current liabilities related to deferred taxes and $110 million to stockholders’ equity (deficit) as of February 1, 2020.  See Note 2, Note 4, and Note 18 of the Notes to the Condensed Consolidated Financial Statements for additional information about the Company’s allowance for financing receivables losses and allowance for expected credit losses of accounts receivable.

[0001571996-20-000051:notes:9]
Intangibles - Goodwill and Other - Internal-Use Software — In August 2018, the FASB issued guidance on a customer’s accounting for implementation costs incurred in a cloud-computing arrangement when hosted by a vendor.  The guidance provides that, in a hosting arrangement that is a service contract, certain implementation costs should be capitalized and amortized over the term of the arrangement.  The Company adopted the standard (the “new cloud computing standard”) during the three months ended May 1, 2020 using the prospective method.  The impact of the adoption of this standard was immaterial to the Condensed Consolidated Financial Statements.


## us-gaap:BusinessDescriptionAndAccountingPoliciesTextBlock

[0001571996-20-000051:notes:10]
[same as prior period, unchanged from 0001571996-20-000045:notes:11]

[0001571996-20-000051:notes:11]
[same as prior period, unchanged from 0001571996-20-000045:notes:12]

[0001571996-20-000051:notes:12]
[same as prior period, unchanged from 0001571996-20-000045:notes:13]

[0001571996-20-000051:notes:13]
[same as prior period, unchanged from 0001571996-20-000045:notes:14]

[0001571996-20-000051:notes:14]
[same as prior period, unchanged from 0001571996-20-000045:notes:15]

[0001571996-20-000051:notes:15]
[same as prior period, unchanged from 0001571996-20-000045:notes:16]


## us-gaap:FairValueDisclosuresTextBlock

[0001571996-20-000051:notes:16]
[same as prior period, unchanged from 0001571996-20-000045:notes:17]

[0001571996-20-000051:notes:17]
[same as prior period, unchanged from 0001571996-20-000045:notes:18]

[0001571996-20-000051:notes:18]
|  | October 30, 2020 |  | January 31, 2020 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
|  | Quoted Prices in Active Markets for Identical Assets |  | Significant Other Observable Inputs |  | Significant Unobservable Inputs |  |  |  | Quoted Prices in Active Markets for Identical Assets |  | Significant Other Observable Inputs |  | Significant Unobservable Inputs |  |  |
|  | (in millions) |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 6,562 |  |  | $ | — |  |  | $ | — |  |  | $ | 6,562 |  |  | $ | 4,621 |  |  | $ | — |  |  | $ | — |  |  | $ | 4,621 |  |
| Equity and other securities | 553 |  |  | — |  |  | — |  |  | 553 |  |  | 12 |  |  | — |  |  | — |  |  | 12 |  |
| Derivative instruments | — |  |  | 52 |  |  | — |  |  | 52 |  |  | — |  |  | 81 |  |  | — |  |  | 81 |  |
| Total assets | $ | 7,115 |  |  | $ | 52 |  |  | $ | — |  |  | $ | 7,167 |  |  | $ | 4,633 |  |  | $ | 81 |  |  | $ | — |  |  | $ | 4,714 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative instruments | $ | — |  |  | $ | 181 |  |  | $ | — |  |  | $ | 181 |  |  | $ | — |  |  | $ | 68 |  |  | $ | — |  |  | $ | 68 |  |
| Total liabilities | $ | — |  |  | $ | 181 |  |  | $ | — |  |  | $ | 181 |  |  | $ | — |  |  | $ | 68 |  |  | $ | — |  |  | $ | 68 |  |

[0001571996-20-000051:notes:19]
[same as prior period, unchanged from 0001571996-20-000045:notes:20]

[0001571996-20-000051:notes:20]
Money Market Funds — The Company’s investments in money market funds that are classified as cash equivalents hold underlying investments with a weighted average maturity of 90 days or less and are recognized at fair value.  The valuations of these securities are based on quoted prices in active markets for identical assets, when available, or pricing models whereby all significant inputs are observable or can be derived from or corroborated by observable market data.  The Company reviews security pricing and assesses liquidity on a quarterly basis.  As of October 30, 2020, the Company’s U.S. portfolio had no material exposure to money market funds with a fluctuating net asset value.

[0001571996-20-000051:notes:21]
[same as prior period, unchanged from 0001571996-20-000045:notes:22]

[0001571996-20-000051:notes:22]
[same as prior period, unchanged from 0001571996-20-000045:notes:23]

[0001571996-20-000051:notes:23]
Deferred Compensation Plans — The Company offers deferred compensation plans for eligible employees, which allow participants to defer payment for a portion of their compensation.  Assets were the same as liabilities associated with the plans at approximately $277 million and $241 million as of October 30, 2020 and January 31, 2020, respectively, and are included in other assets and other liabilities on the Condensed Consolidated Statements of Financial Position.  The net impact to the Condensed Consolidated Statements of Income (Loss) is not material since changes in the fair value of the assets substantially offset changes in the fair value of the liabilities.  As such, assets and liabilities associated with these plans have not been included in the recurring fair value table above.

[0001571996-20-000051:notes:24]
[same as prior period, unchanged from 0001571996-20-000045:notes:25]

[0001571996-20-000051:notes:25]
As of October 30, 2020 and January 31, 2020, the Company held private strategic investments of $936 million and $852 million, respectively.  As these investments represent early-stage companies without readily determinable fair values, they are not included in the recurring fair value table above.

[0001571996-20-000051:notes:26]
[same as prior period, unchanged from 0001571996-20-000045:notes:27]

[0001571996-20-000051:notes:27]
[same as prior period, unchanged from 0001571996-20-000045:notes:28]

[0001571996-20-000051:notes:28]
|  | October 30, 2020 |  | January 31, 2020 |
|  | Carrying Value |  | Fair Value |  | Carrying Value |  | Fair Value |
|  | (in billions) |
| Senior Secured Credit Facilities | $ | 8.6 |  |  | $ | 8.6 |  |  | $ | 8.8 |  |  | $ | 9.0 |  |
| First Lien Notes | $ | 18.3 |  |  | $ | 22.0 |  |  | $ | 20.5 |  |  | $ | 23.9 |  |
| Unsecured Notes and Debentures | $ | 1.2 |  |  | $ | 1.5 |  |  | $ | 1.2 |  |  | $ | 1.5 |  |
| Senior Notes | $ | 2.6 |  |  | $ | 2.8 |  |  | $ | 2.6 |  |  | $ | 2.8 |  |
| EMC Notes | $ | 1.0 |  |  | $ | 1.0 |  |  | $ | 1.6 |  |  | $ | 1.6 |  |
| VMware Notes and VMware Term Loan Facility | $ | 4.7 |  |  | $ | 5.3 |  |  | $ | 5.5 |  |  | $ | 5.6 |  |
| Margin Loan Facility | $ | 4.0 |  |  | $ | 3.9 |  |  | $ | 4.0 |  |  | $ | 3.9 |  |

[0001571996-20-000051:notes:29]
[same as prior period, unchanged from 0001571996-20-000045:notes:30]

[0001571996-20-000051:notes:30]
[same as prior period, unchanged from 0001571996-20-000045:notes:31]

[0001571996-20-000051:notes:31]
[same as prior period, unchanged from 0001571996-20-000045:notes:32]

[0001571996-20-000051:notes:32]
|  | October 30, 2020 |  | January 31, 2020 |
|  | Cost |  | Unrealized Gain |  | Unrealized (Loss) |  | Carrying Value |  | Cost |  | Unrealized Gain |  | Unrealized (Loss) |  | Carrying Value |
|  | (in millions) |
| Equity and other securities | $ | 944 |  |  | $ | 579 |  |  | $ | (34) |  |  | $ | 1,489 |  |  | $ | 783 |  |  | $ | 116 |  |  | $ | (35) |  |  | $ | 864 |  |
| Fixed income debt securities | 163 |  |  | 3 |  |  | — |  |  | 166 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Total securities |  |  |  |  |  |  | $ | 1,655 |  |  |  |  |  |  |  |  | $ | 864 |  |

[0001571996-20-000051:notes:33]
Equity and other securities — The Company has strategic investments in publicly-traded and privately-held companies.  For the nine months ended October 30, 2020, the equity and other securities without readily determinable fair values of $936 million increased by $112 million, due to upward adjustments for observable price changes, offset by $31 million of downward adjustments primarily attributable to impairments.  The remainder of equity and other securities consists of publicly-traded investments that are measured at fair value on a recurring basis.

[0001571996-20-000051:notes:34]
In September 2020, one of the Company’s strategic investments, which previously did not have a readily determinable fair value, completed its initial public offering which resulted in it having a readily determinable fair value and in the recognition of an unrealized gain of $465 million for the three and nine months ended October 30, 2020, which is reflected in the table above.  The unrealized gain is reflected in Other, net as a non-cash adjustment within cash flows from operating activities on the Condensed Consolidated Statements of Cash Flows.  As of October 30, 2020, the carrying value of this investment was $543 million.

[0001571996-20-000051:notes:35]
[same as prior period, unchanged from 0001571996-20-000045:notes:35]


## dell:CreditLossFinancialInstrumentLeasesDebtVariableInterestEntitiesAndCustomerReceivablesSalesTextBlock

[0001571996-20-000051:notes:36]
NOTE 4 — FINANCIAL SERVICES

[0001571996-20-000051:notes:37]
The Company offers or arranges various financing options, services, and alternative payment structures for its customers in North America, Europe, Australia, and New Zealand through Dell Financial Services and its affiliates (“DFS”).  The Company also arranges financing for some of its customers in various countries where DFS does not currently operate as a captive enterprise.  The key activities of DFS include originating, collecting, and servicing customer financing arrangements primarily related to the purchase or use of Dell Technologies products and services.  In some cases, DFS also offers financing on the purchase of third-party technology products that complement the Dell Technologies portfolio of products and services.  New financing originations were $2.1 billion and $2.0 billion for the three months ended October 30, 2020 and November 1, 2019, respectively, and $6.5 billion and $5.7 billion for the nine months ended October 30, 2020 and November 1, 2019, respectively.

[0001571996-20-000051:notes:38]
The Company’s loan and lease arrangements with customers are aggregated into the following categories:

[0001571996-20-000051:notes:39]
Revolving loans — Revolving loans offered under private label credit financing programs provide qualified customers with a revolving credit line for the purchase of products and services offered by Dell Technologies.  These private label credit financing programs are referred to as Dell Preferred Account (“DPA”) and Dell Business Credit (“DBC”).  The DPA product is primarily offered to individual consumer customers, and the DBC product is primarily offered to small and medium-sized commercial customers.  Revolving loans in the United States bear interest at a variable annual percentage rate that is tied to the prime rate.  Based on historical payment patterns, revolving loan transactions are typically repaid within twelve months on average.  Due to the short-term nature of the revolving loan portfolio, the carrying value of the portfolio approximates fair value.

[0001571996-20-000051:notes:40]
Fixed-term leases and loans — The Company enters into financing arrangements with customers who seek lease financing for equipment.  Pursuant to the current lease accounting standard effective February 2, 2019, new DFS leases are classified as sales-type leases, direct financing leases, or operating leases.  When the terms of the DFS lease transfer control of the underlying asset to the lessee, the contract is typically classified as a sales-type lease.  Direct financing leases are immaterial.  All other new DFS leases are classified as operating leases.  Leases that commenced prior to the effective date of the current lease accounting standard continue to be accounted for under previous lease accounting guidance.  Leases with business customers have fixed terms of generally two to four years.

[0001571996-20-000051:notes:41]
The Company also offers fixed-term loans to qualified small businesses, large commercial accounts, governmental organizations, educational entities, and certain individual consumer customers.  These loans are repaid in equal payments including interest and have defined terms of generally three to five years.  The fair value of the fixed-term loan portfolio is determined using market observable inputs.  The carrying value of these loans approximates fair value.

[0001571996-20-000051:notes:42]
Financing Receivables

[0001571996-20-000051:notes:43]
The following table presents the components of the Company’s financing receivables segregated by portfolio segment as of the dates indicated:

[0001571996-20-000051:notes:44]
|  | October 30, 2020 |  | January 31, 2020 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Financing receivables, net: |  |  |  |  |  |  |  |  |  |  |  |
| Customer receivables, gross (a) | $ | 768 |  |  | $ | 9,313 |  |  | $ | 10,081 |  |  | $ | 824 |  |  | $ | 8,486 |  |  | $ | 9,310 |  |
| Allowances for losses | (142) |  |  | (165) |  |  | (307) |  |  | (70) |  |  | (79) |  |  | (149) |  |
| Customer receivables, net | 626 |  |  | 9,148 |  |  | 9,774 |  |  | 754 |  |  | 8,407 |  |  | 9,161 |  |
| Residual interest | — |  |  | 472 |  |  | 472 |  |  | — |  |  | 582 |  |  | 582 |  |
| Financing receivables, net | $ | 626 |  |  | $ | 9,620 |  |  | $ | 10,246 |  |  | $ | 754 |  |  | $ | 8,989 |  |  | $ | 9,743 |  |
| Short-term | $ | 626 |  |  | $ | 4,246 |  |  | $ | 4,872 |  |  | $ | 754 |  |  | $ | 4,141 |  |  | $ | 4,895 |  |
| Long-term | $ | — |  |  | $ | 5,374 |  |  | $ | 5,374 |  |  | $ | — |  |  | $ | 4,848 |  |  | $ | 4,848 |  |

[0001571996-20-000051:notes:45]
____________________

[0001571996-20-000051:notes:46]
(a)    Customer receivables, gross includes amounts due from customers under revolving loans, fixed-term loans, fixed-term sales-type or direct financing leases, and accrued interest.

[0001571996-20-000051:notes:47]
The allowance for losses as of October 30, 2020 includes the adoption of the new CECL standard, which was adopted as of February 1, 2020 using the modified retrospective method.  Prior period amounts have not been recast.  The provision recognized on the Condensed Consolidated Statements of Income (Loss) for the three and nine months ended October 30, 2020 is based on an assessment of the impact of current and expected future economic conditions, inclusive of the effect of the COVID-19 pandemic on credit losses.  The duration and severity of COVID-19 and continued market volatility is highly uncertain and, as such, the impact on expected losses is subject to significant judgment and may cause variability in the Company’s allowance for credit losses in future periods.  See Note 1 and Note 2 of the Notes to the Condensed Consolidated Financial Statements for additional information about the new CECL standard.

[0001571996-20-000051:notes:48]
The following tables present the changes in allowance for financing receivable losses for the periods indicated:

[0001571996-20-000051:notes:49]
|  | Three Months Ended |
|  | October 30, 2020 |  | November 1, 2019 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |  |  |  |  |  |  |  |  |  |  |  |
| Balances at beginning of period | $ | 143 |  |  | $ | 180 |  |  | $ | 323 |  |  | $ | 67 |  |  | $ | 71 |  |  | $ | 138 |  |
| Charge-offs, net of recoveries | (13) |  |  | (6) |  |  | (19) |  |  | (18) |  |  | (6) |  |  | (24) |  |
| Provision charged to income statement | 12 |  |  | (9) |  |  | 3 |  |  | 17 |  |  | 13 |  |  | 30 |  |
| Balances at end of period | $ | 142 |  |  | $ | 165 |  |  | $ | 307 |  |  | $ | 66 |  |  | $ | 78 |  |  | $ | 144 |  |

[0001571996-20-000051:notes:50]
|  | Nine Months Ended |
|  | October 30, 2020 |  | November 1, 2019 |
|  | Revolving |  | Fixed-term |  | Total |  | Revolving |  | Fixed-term |  | Total |
|  | (in millions) |
| Allowance for financing receivable losses: |  |  |  |  |  |  |  |  |  |  |  |
| Balances at beginning of period | $ | 70 |  |  | $ | 79 |  |  | $ | 149 |  |  | $ | 75 |  |  | $ | 61 |  |  | $ | 136 |  |
| Adjustment for adoption of accounting standard (Note 1) | 40 |  |  | 71 |  |  | 111 |  |  | — |  |  | — |  |  | — |  |
| Charge-offs, net of recoveries | (51) |  |  | (22) |  |  | (73) |  |  | (53) |  |  | (18) |  |  | (71) |  |
| Provision charged to income statement | 83 |  |  | 37 |  |  | 120 |  |  | 44 |  |  | 35 |  |  | 79 |  |
| Balances at end of period | $ | 142 |  |  | $ | 165 |  |  | $ | 307 |  |  | $ | 66 |  |  | $ | 78 |  |  | $ | 144 |  |

[0001571996-20-000051:notes:51]
Aging

[0001571996-20-000051:notes:52]
The following table presents the aging of the Company’s customer financing receivables, gross, including accrued interest, segregated by class, as of the dates indicated:

[0001571996-20-000051:notes:53]
|  | October 30, 2020 |  | January 31, 2020 |
|  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |  | Current |  | Past Due1 — 90 Days |  | Past Due>90 Days |  | Total |
|  | (in millions) |
| Revolving — DPA | $ | 548 |  |  | $ | 34 |  |  | $ | 10 |  |  | $ | 592 |  |  | $ | 550 |  |  | $ | 51 |  |  | $ | 20 |  |  | $ | 621 |  |
| Revolving — DBC | 159 |  |  | 14 |  |  | 3 |  |  | 176 |  |  | 184 |  |  | 15 |  |  | 4 |  |  | 203 |  |
| Fixed-term — Consumer and Commercial | 8,947 |  |  | 299 |  |  | 67 |  |  | 9,313 |  |  | 8,005 |  |  | 373 |  |  | 108 |  |  | 8,486 |  |
| Total customer receivables, gross | $ | 9,654 |  |  | $ | 347 |  |  | $ | 80 |  |  | $ | 10,081 |  |  | $ | 8,739 |  |  | $ | 439 |  |  | $ | 132 |  |  | $ | 9,310 |  |

[0001571996-20-000051:notes:54]
Aging is likely to fluctuate as a result of the variability in volume of large transactions entered into over the period, and the administrative processes that accompany those larger transactions.  Aging is also impacted by the timing of the Dell Technologies fiscal period end date, relative to calendar month-end customer payment due dates.  As a result of these factors, fluctuations in aging from period to period do not necessarily indicate a material change in the collectibility of the portfolio.

[0001571996-20-000051:notes:55]
Fixed-term consumer and commercial customer receivables are placed on non-accrual status if principal or interest is past due and considered delinquent, or if there is concern about collectibility of a specific customer receivable.  These receivables identified as doubtful for collectibility may be classified as current for aging purposes.  Aged revolving portfolio customer receivables identified as delinquent are charged off.

[0001571996-20-000051:notes:56]
Credit Quality

[0001571996-20-000051:notes:57]
The following table presents customer receivables, gross, including accrued interest, by credit quality indicator segregated by class and year of origination, as of the date indicated:

[0001571996-20-000051:notes:58]
|  | October 30, 2020 |
|  | Fixed-term — Consumer and Commercial |  |  |  |  |  |  |
|  | Fiscal Year of Origination |  |  |  |  |  |  |
|  | 2021 |  | 2020 |  | 2019 |  | 2018 |  | 2017 |  | Years Prior |  | Revolving — DPA (a) |  | Revolving — DBC (a) |  | Total |
|  | (in millions) |
| Higher | $ | 2,591 |  |  | $ | 1,961 |  |  | $ | 780 |  |  | $ | 191 |  |  | $ | 32 |  |  | $ | — |  |  | $ | 158 |  |  | $ | 48 |  |  | $ | 5,761 |  |
| Mid | 900 |  |  | 736 |  |  | 351 |  |  | 92 |  |  | 13 |  |  | — |  |  | 177 |  |  | 52 |  |  | 2,321 |  |
| Lower | 723 |  |  | 572 |  |  | 303 |  |  | 53 |  |  | 14 |  |  | 1 |  |  | 257 |  |  | 76 |  |  | 1,999 |  |
| Total | $ | 4,214 |  |  | $ | 3,269 |  |  | $ | 1,434 |  |  | $ | 336 |  |  | $ | 59 |  |  | $ | 1 |  |  | $ | 592 |  |  | $ | 176 |  |  | $ | 10,081 |  |

[0001571996-20-000051:notes:59]
(a)    The revolving portfolio is exempt from the requirement to disclose the amortized cost basis by year of origination since determining the appropriate origination year can be complex due to the nature of the revolving portfolio.

[0001571996-20-000051:notes:60]
The following table presents customer receivables, gross, including accrued interest, by credit quality indicator segregated by class, as of the date indicated, and was not recast to reflect the impact of adoption of the new CECL standard:

[0001571996-20-000051:notes:61]
|  | January 31, 2020 |
|  | Fixed-term — Consumer and Commercial |  | Revolving — DPA |  | Revolving — DBC |  | Total |
|  | (in millions) |
| Higher | $ | 5,042 |  |  | $ | 137 |  |  | $ | 55 |  |  | $ | 5,234 |  |
| Mid | 2,036 |  |  | 175 |  |  | 63 |  |  | 2,274 |  |
| Lower | 1,408 |  |  | 309 |  |  | 85 |  |  | 1,802 |  |
| Total | $ | 8,486 |  |  | $ | 621 |  |  | $ | 203 |  |  | $ | 9,310 |  |

[0001571996-20-000051:notes:62]
The categories shown in the tables above segregate customer receivables based on the relative degrees of credit risk.  The credit quality indicators for DPA revolving accounts are measured primarily as of each quarter-end date, while all other indicators are generally updated on a periodic basis.

[0001571996-20-000051:notes:63]
For DPA revolving receivables shown in the table above, the Company makes credit decisions based on proprietary scorecards, which include the customer’s credit history, payment history, credit usage, and other credit agency-related elements.  The higher quality category includes prime accounts generally of a higher credit quality that are comparable to U.S. customer FICO scores of 720 or above.  The mid-category represents the mid-tier accounts that are comparable to U.S. customer FICO scores from 660 to 719.  The lower category is generally sub-prime and represents lower credit quality accounts that are comparable to U.S. customer FICO scores below 660.  For the DBC revolving receivables and fixed-term commercial receivables shown in the table above, an internal grading system is utilized that assigns a credit level score based on a number of considerations, including liquidity, operating performance, and industry outlook.  The grading criteria and classifications for the fixed-term products differ from those for the revolving products as loss experience varies between these product and customer groups.  The credit quality categories cannot be compared between the different classes as loss experience varies substantially between the classes.

[0001571996-20-000051:notes:64]
Leases

[0001571996-20-000051:notes:65]
Interest income on sales-type lease receivables was $69 million and $66 million for the three months ended October 30, 2020 and November 1, 2019, respectively, and $200 million and $196 million for the nine months ended October 30, 2020 and November 1, 2019, respectively.

[0001571996-20-000051:notes:66]
The following table presents the net revenue, cost of net revenue, and gross margin recognized at the commencement date of sales-type leases for the periods indicated:

[0001571996-20-000051:notes:67]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 30, 2020 |  | November 1, 2019 |  | October 30, 2020 |  | November 1, 2019 |
|  | (in millions) |
| Net revenue — products | $ | 184 |  |  | $ | 251 |  |  | $ | 648 |  |  | $ | 604 |  |
| Cost of net revenue — products | 102 |  |  | 215 |  |  | 435 |  |  | 475 |  |
| Gross margin — products | $ | 82 |  |  | $ | 36 |  |  | $ | 213 |  |  | $ | 129 |  |

[0001571996-20-000051:notes:68]
The following table presents the future maturity of the Company’s fixed-term customer leases and associated financing payments, and reconciles the undiscounted cash flows to the customer receivables, gross recognized on the Condensed Consolidated Statements of Financial Position as of the date indicated:

[0001571996-20-000051:notes:69]
|  | October 30, 2020 |
| Fiscal Years | (in millions) |
| Fiscal 2021 (remaining three months) | $ | 794 |  |
| Fiscal 2022 | 2,378 |  |
| Fiscal 2023 | 1,533 |  |
| Fiscal 2024 | 783 |  |
| Fiscal 2025 and beyond | 360 |  |
| Total undiscounted cash flows | 5,848 |  |
| Fixed-term loans | 4,125 |  |
| Revolving loans | 768 |  |
| Less: unearned income | (660) |  |
| Total customer receivables, gross | $ | 10,081 |  |

[0001571996-20-000051:notes:70]
Operating Leases

[0001571996-20-000051:notes:71]
The following table presents the components of the Company’s operating lease portfolio included in Property, plant, and equipment, net as of the dates indicated:

[0001571996-20-000051:notes:72]
|  | October 30, 2020 |  | January 31, 2020 |
|  | (in millions) |
| Equipment under operating lease, gross | $ | 1,592 |  |  | $ | 956 |  |
| Less: accumulated depreciation | (328) |  |  | (116) |  |
| Equipment under operating lease, net | $ | 1,264 |  |  | $ | 840 |  |

[0001571996-20-000051:notes:73]
Operating lease income relating to lease payments was $120 million and $63 million for the three months ended October 30, 2020 and November 1, 2019, respectively, and $310 million and $94 million for the nine months ended October 30, 2020 and November 1, 2019, respectively.  Depreciation expense was $92 million and $40 million for the three months ended October 30, 2020 and November 1, 2019, respectively, and $228 million and $64 million for the nine months ended October 30, 2020 and November 1, 2019, respectively.

[0001571996-20-000051:notes:74]
The following table presents the future payments to be received by the Company as lessor in operating lease contracts as of the date indicated:

[0001571996-20-000051:notes:75]
|  | October 30, 2020 |
| Fiscal Years | (in millions) |
| Fiscal 2021 (remaining three months) | $ | 142 |  |
| Fiscal 2022 | 526 |  |
| Fiscal 2023 | 404 |  |
| Fiscal 2024 | 146 |  |
| Fiscal 2025 and beyond | 24 |  |
| Total | $ | 1,242 |  |

[0001571996-20-000051:notes:76]
DFS Debt

[0001571996-20-000051:notes:77]
The Company maintains programs that facilitate the funding of leases, loans, and other alternative payment structures in the capital markets.  The majority of DFS debt is non-recourse to Dell Technologies and represents borrowings under securitization programs and structured financing programs, for which the Company’s risk of loss is limited to transferred loan and lease payments and associated equipment.  The following table presents DFS debt as of the dates indicated.  The table excludes the allocated portion of the Company’s other borrowings, which represents the additional amount considered to fund the DFS business.

[0001571996-20-000051:notes:78]
|  | October 30, 2020 |  | January 31, 2020 |
|  | (in millions) |
| DFS U.S. debt: |  |  |  |
| Asset-based financing and securitization facilities | $ | 2,574 |  |  | $ | 2,606 |  |
| Fixed-term securitization offerings | 3,465 |  |  | 2,593 |  |
| Other | 94 |  |  | 141 |  |
| Total DFS U.S. debt | 6,133 |  |  | 5,340 |  |
| DFS international debt: |  |  |  |
| Securitization facility | 860 |  |  | 743 |  |
| Other borrowings | 791 |  |  | 931 |  |
| Note payable | 250 |  |  | 200 |  |
| Dell Bank Senior Unsecured Eurobonds | 1,167 |  |  | 551 |  |
| Total DFS international debt | 3,068 |  |  | 2,425 |  |
| Total DFS debt | $ | 9,201 |  |  | $ | 7,765 |  |
| Total short-term DFS debt | $ | 4,884 |  |  | $ | 4,152 |  |
| Total long-term DFS debt | $ | 4,317 |  |  | $ | 3,613 |  |

[0001571996-20-000051:notes:79]
DFS U.S. Debt

[0001571996-20-000051:notes:80]
Asset-Based Financing and Securitization Facilities — The Company maintains separate asset-based financing facilities and a securitization facility in the United States, which are revolving facilities for fixed-term leases and loans and for revolving loans, respectively.  This debt is collateralized solely by the U.S. loan and lease payments and associated equipment in the facilities.  The debt has a variable interest rate and the duration of the debt is based on the terms of the underlying loan and lease payment streams.  As of October 30, 2020, the total debt capacity related to the U.S. asset-based financing and securitization facilities was $4.1 billion.  The Company enters into interest swap agreements to effectively convert a portion of this debt from a floating rate to a fixed rate.  See Note 7 of the Notes to the Condensed Consolidated Financial Statements for additional information about interest rate swaps.

[0001571996-20-000051:notes:81]
The Company’s U.S. securitization facility for revolving loans is effective through June 25, 2022.  The Company’s two U.S. asset-based financing facilities for fixed-term leases and loans are effective through August 22, 2021 and July 26, 2022, respectively.

[0001571996-20-000051:notes:82]
The asset-based financing and securitization facilities contain standard structural features related to the performance of the funded receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the facility, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of October 30, 2020, these criteria were met.

[0001571996-20-000051:notes:83]
Fixed-Term Securitization Offerings — The Company periodically issues asset-backed debt securities under fixed-term securitization programs to private investors.  The asset-backed debt securities are collateralized solely by the U.S. fixed-term leases and loans in the offerings, which are held by Special Purpose Entities (“SPEs”), as discussed below.  The interest rate on these securities is fixed and ranges from 0.31% to 5.92% per annum, and the duration of these securities is based on the terms of the underlying loan and lease payment streams.

[0001571996-20-000051:notes:84]
DFS International Debt

[0001571996-20-000051:notes:85]
Securitization Facility — The Company maintains a securitization facility in Europe for fixed-term leases and loans.  This facility is effective through December 21, 2020 and has a total debt capacity of $934 million as of October 30, 2020.

[0001571996-20-000051:notes:86]
The securitization facility contains standard structural features related to the performance of the securitized receivables, which include defined credit losses, delinquencies, average credit scores, and minimum collection requirements.  In the event one or more of these criteria are not met and the Company is unable to restructure the program, no further funding of receivables will be permitted and the timing of the Company’s expected cash flows from over-collateralization will be delayed.  As of October 30, 2020, these criteria were met.

[0001571996-20-000051:notes:87]
Other Borrowings — In connection with the Company’s international financing operations, the Company has entered into revolving structured financing debt programs related to its fixed-term lease and loan products sold in Canada, Europe, Australia, and New Zealand.  The Canadian facility, which is collateralized solely by Canadian loan and lease payments and associated equipment, had a total debt capacity of $281 million as of October 30, 2020, and is effective through January 16, 2023.  The European facility, which is collateralized solely by European loan and lease payments and associated equipment, had a total debt capacity of $700 million as of October 30, 2020, and is effective through June 14, 2022.  The Australia and New Zealand facility, which is collateralized solely by Australia and New Zealand loan and lease payments and associated equipment, had a total debt capacity of $246 million as of October 30, 2020, and is effective through December 20, 2021.

[0001571996-20-000051:notes:88]
Note Payable — On November 27, 2017 the Company entered into an unsecured credit agreement to fund receivables in Mexico.  As of July 31, 2020, the aggregate principal amount of the note payable was $187 million.  This note was repaid in full during the three months ended October 30, 2020.

[0001571996-20-000051:notes:89]
On August 7, 2020, the Company entered into two new unsecured credit agreements to fund receivables in Mexico.  As of October 30, 2020, the aggregate principal amount of the notes payable was $250 million.  The notes bear interest at 3.37% and will mature on June 1, 2022.

[0001571996-20-000051:notes:90]
Dell Bank Senior Unsecured Eurobonds — On October 17, 2019, Dell Bank International D.A.C. issued 500 million Euro of 0.625% senior unsecured three year eurobonds due October 2022.  On June 24, 2020, Dell Bank International D.A.C. issued an additional 500 million Euro of 1.625% senior unsecured four year eurobonds due June 2024.  The issuances of the senior unsecured eurobonds support the expansion of the financing operations in Europe.

[0001571996-20-000051:notes:91]
Variable Interest Entities

[0001571996-20-000051:notes:92]
In connection with the asset-based financing facilities, securitization facilities, and fixed-term securitization offerings discussed above, the Company transfers certain U.S. and European loan and lease payments and associated equipment to SPEs that meet the definition of a Variable Interest Entity (“VIE”) and are consolidated, along with the associated debt detailed above, into the Consolidated Financial Statements, as the Company is the primary beneficiary of those VIEs.  The SPEs are bankruptcy-remote legal entities with separate assets and liabilities.  The purpose of the SPEs is to facilitate the funding of customer loan and lease payments and associated equipment in the capital markets.

[0001571996-20-000051:notes:93]
The following table presents financing receivables and equipment under operating leases, net held by the consolidated VIEs as of the dates indicated:

[0001571996-20-000051:notes:94]
|  | October 30, 2020 |  | January 31, 2020 |
|  | (in millions) |
| Assets held by consolidated VIEs, net: |  |  |  |
| Short-term, net | $ | 3,430 |  |  | $ | 3,316 |  |
| Long-term, net | 4,070 |  |  | 3,348 |  |
| Assets held by consolidated VIEs, net | $ | 7,500 |  |  | $ | 6,664 |  |

[0001571996-20-000051:notes:95]
Loan and lease payments and associated equipment transferred via securitization through SPEs were $1.6 billion and $1.3 billion for the three months ended October 30, 2020 and November 1, 2019, respectively, and $4.6 billion and $4.1 billion for the nine months ended October 30, 2020 and November 1, 2019, respectively.

[0001571996-20-000051:notes:96]
Some of the SPEs have entered into financing arrangements with multi-seller conduits that, in turn, issue asset-backed debt securities in the capital markets.  The DFS debt outstanding, which is collateralized by the loan and lease payments and associated equipment held by the consolidated VIEs, was $6.9 billion and $5.9 billion as of October 30, 2020 and January 31, 2020, respectively.  The Company’s risk of loss related to securitized receivables is limited to the amount by which the Company’s right to receive collections for assets securitized exceeds the amount required to pay interest, principal, and fees and expenses related to the asset-backed securities.  The Company provides credit enhancement to the securitizations in the form of over-collateralization.

[0001571996-20-000051:notes:97]
Customer Receivables Sales

[0001571996-20-000051:notes:98]
To manage certain concentrations of customer credit exposure, the Company may sell selected fixed-term customer receivables to unrelated third parties on a periodic basis, without recourse.  The amount of customer receivables sold for this purpose was $414 million and $406 million for the nine months ended October 30, 2020 and November 1, 2019, respectively.  The Company’s continuing involvement in the above mentioned customer receivables is primarily limited to servicing arrangements.


## us-gaap:ScheduleOfDebtTableTextBlock

[0001571996-20-000051:notes:99]
The following table presents DFS debt as of the dates indicated.  The table excludes the allocated portion of the Company’s other borrowings, which represents the additional amount considered to fund the DFS business.

[0001571996-20-000051:notes:100]
The following table presents the Company’s outstanding debt as of the dates indicated:

[0001571996-20-000051:notes:101]
|  | October 30, 2020 |  | January 31, 2020 |
|  | (in millions) |
| Secured Debt |  |  |  |
| Senior Secured Credit Facilities: |  |  |  |
| 2.75% Term Loan B-1 Facility due September 2025 | $ | 4,691 |  |  | $ | 4,738 |  |
| 1.90% Term Loan A-4 Facility due December 2023 | 679 |  |  | 679 |  |
| 1.90% Term Loan A-6 Facility due March 2024 | 3,316 |  |  | 3,497 |  |
| First Lien Notes: |  |  |  |
| 4.42% due June 2021 | — |  |  | 4,500 |  |
| 5.45% due June 2023 | 3,750 |  |  | 3,750 |  |
| 4.00% due July 2024 | 1,000 |  |  | 1,000 |  |
| 5.85% due July 2025 | 1,000 |  |  | — |  |
| 6.02% due June 2026 | 4,500 |  |  | 4,500 |  |
| 4.90% due October 2026 | 1,750 |  |  | 1,750 |  |
| 6.10% due July 2027 | 500 |  |  | — |  |
| 5.30% due October 2029 | 1,750 |  |  | 1,750 |  |
| 6.20% due July 2030 | 750 |  |  | — |  |
| 8.10% due July 2036 | 1,500 |  |  | 1,500 |  |
| 8.35% due July 2046 | 2,000 |  |  | 2,000 |  |
| Unsecured Debt |  |  |  |
| Unsecured Notes and Debentures: |  |  |  |
| 4.625% due April 2021 | 400 |  |  | 400 |  |
| 7.10% due April 2028 | 300 |  |  | 300 |  |
| 6.50% due April 2038 | 388 |  |  | 388 |  |
| 5.40% due September 2040 | 264 |  |  | 264 |  |
| Senior Notes: |  |  |  |
| 5.875% due June 2021 | 1,075 |  |  | 1,075 |  |
| 7.125% due June 2024 | 1,625 |  |  | 1,625 |  |
| EMC Notes: |  |  |  |
| 2.650% due June 2020 | — |  |  | 600 |  |
| 3.375% due June 2023 | 1,000 |  |  | 1,000 |  |
| Debt of Public Subsidiary |  |  |  |
| VMware Notes: |  |  |  |
| 2.30% due August 2020 | — |  |  | 1,250 |  |
| 2.95% due August 2022 | 1,500 |  |  | 1,500 |  |
| 4.50% due May 2025 | 750 |  |  | — |  |
| 4.65% due May 2027 | 500 |  |  | — |  |
| 3.90% due August 2027 | 1,250 |  |  | 1,250 |  |
| 4.70% due May 2030 | 750 |  |  | — |  |
| VMware Term Loan Facility | — |  |  | 1,500 |  |
| DFS Debt (Note 4) | 9,201 |  |  | 7,765 |  |
| Other |  |  |  |
| 2.46% Margin Loan Facility due April 2022 | 4,000 |  |  | 4,000 |  |
| Other | 222 |  |  | 84 |  |
| Total debt, principal amount | $ | 50,411 |  |  | $ | 52,665 |  |

[0001571996-20-000051:notes:102]
|  | October 30, 2020 |  | January 31, 2020 |
|  | (in millions) |
| Total debt, principal amount | $ | 50,411 |  |  | $ | 52,665 |  |
| Unamortized discount, net of unamortized premium | (217) |  |  | (241) |  |
| Debt issuance costs | (333) |  |  | (368) |  |
| Total debt, carrying value | $ | 49,861 |  |  | $ | 52,056 |  |
| Total short-term debt, carrying value | $ | 6,536 |  |  | $ | 7,737 |  |
| Total long-term debt, carrying value | $ | 43,325 |  |  | $ | 44,319 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0001571996-20-000051:notes:103]
[same as prior period, unchanged from 0001571996-20-000045:notes:102]

[0001571996-20-000051:notes:104]
The Company enters into leasing transactions in which the Company is the lessee.  These lease contracts are typically classified as operating leases.  The Company’s lease contracts are generally for office buildings used to conduct its business, and the determination of whether such contracts contain leases generally does not require significant estimates or judgments.  The Company also leases certain global logistics warehouses, employee vehicles, and equipment.  As of October 30, 2020, the remaining terms of the Company’s leases range from less than one month to 26 years.

[0001571996-20-000051:notes:105]
[same as prior period, unchanged from 0001571996-20-000045:notes:104]

[0001571996-20-000051:notes:106]
In adopting the current lease accounting standard effective February 2, 2019, the Company elected to apply a transition method that does not require the retrospective application to periods prior to the effective date.  Financial information associated with the Company’s leases in which the Company is the lessee is contained in this Note.  As of October 30, 2020 and January 31, 2020, there were no material finance leases for which the Company was a lessee.

[0001571996-20-000051:notes:107]
[same as prior period, unchanged from 0001571996-20-000045:notes:106]

[0001571996-20-000051:notes:108]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 30, 2020 |  | November 1, 2019 |  | October 30, 2020 |  | November 1, 2019 |
|  | (in millions) |
| Operating lease costs | $ | 129 |  |  | $ | 134 |  |  | $ | 384 |  |  | $ | 377 |  |
| Variable costs | 37 |  |  | 41 |  |  | 113 |  |  | 120 |  |
| Total lease costs | $ | 166 |  |  | $ | 175 |  |  | $ | 497 |  |  | $ | 497 |  |

[0001571996-20-000051:notes:109]
During both the nine months ended October 30, 2020 and November 1, 2019, sublease income, finance lease costs, and short-term lease costs were immaterial.

[0001571996-20-000051:notes:110]
[same as prior period, unchanged from 0001571996-20-000045:notes:109]

[0001571996-20-000051:notes:111]
|  | Classification | October 30, 2020 |  | January 31, 2020 |  |  |
|  |  | (in millions, except for term and discount rate) |
| Operating lease right of use (“ROU”) assets | Other non-current assets | $ | 2,179 |  | $ | 1,780 |  |  |
| Current operating lease liabilities | Accrued and other current liabilities | $ | 424 |  | $ | 432 |  |  |
| Non-current operating lease liabilities | Other non-current liabilities | 1,829 |  | 1,360 |  |  |
| Total operating lease liabilities |  | $ | 2,253 |  | $ | 1,792 |  |  |
| Weighted-average remaining lease term (in years) |  | 8.85 |  | 8.57 |  |  |
| Weighted-average discount rate |  | 3.56 | % |  | 3.81 | % |  |  |

[0001571996-20-000051:notes:112]
[same as prior period, unchanged from 0001571996-20-000045:notes:111]

[0001571996-20-000051:notes:113]
|  | Nine Months Ended |
|  | October 30, 2020 |  | November 1, 2019 |
|  | (in millions) |
| Cash paid for amounts included in the measurement of lease liabilities — operating cash outflows from operating leases | $ | 384 |  |  | $ | 367 |  |
| ROU assets obtained in exchange for new operating lease liabilities | $ | 763 |  |  | $ | 495 |  |

[0001571996-20-000051:notes:114]
[same as prior period, unchanged from 0001571996-20-000045:notes:113]

[0001571996-20-000051:notes:115]
|  | October 30, 2020 |  |  |
| Fiscal Years | (in millions) |
| Fiscal 2021 (remaining three months) | $ | 110 |  |  |  |
| Fiscal 2022 | 476 |  |  |  |
| Fiscal 2023 | 429 |  |  |  |
| Fiscal 2024 | 317 |  |  |  |
| Fiscal 2025 | 237 |  |  |  |
| Thereafter | 1,131 |  |  |  |
| Total lease payments | 2,700 |  |  |  |
| Less: Imputed interest | (447) |  |  |  |
| Total | $ | 2,253 |  |  |  |
| Current operating lease liabilities | $ | 424 |  |  |  |
| Non-current operating lease liabilities | $ | 1,829 |  |  |  |

[0001571996-20-000051:notes:116]
Future lease commitments after Fiscal 2025 include the ground lease on VMware, Inc.’s Palo Alto, California headquarter facilities, which expires in Fiscal 2047.

[0001571996-20-000051:notes:117]
As of October 30, 2020, the Company has additional operating leases that have not yet commenced of $81 million.  These operating leases will commence during Fiscal 2021 with lease terms of one year to 10 years.


## us-gaap:DebtDisclosureTextBlock

[0001571996-20-000051:notes:118]
NOTE 6 — DEBT

[0001571996-20-000051:notes:119]
During the nine months ended October 30, 2020, the net decrease in the Company’s debt balance was primarily due to:

[0001571996-20-000051:notes:120]
•retirement of $4.5 billion principal amount of 4.42% First Lien Notes due June 2021 via repayment of $4,265 million and open market repurchases of $235 million;

[0001571996-20-000051:notes:121]
•repayment of $1.5 billion principal amount of VMware Term Loan Facility upon maturity;

[0001571996-20-000051:notes:122]
•repayment of $1.25 billion principal amount of 2.30% VMware Notes due August 2020;

[0001571996-20-000051:notes:123]
•repayment of $600 million principal amount of 2.650% EMC Notes due June 2020 upon maturity; and

[0001571996-20-000051:notes:124]
•amortization of approximately $229 million of principal under the Company’s term loan facilities.

[0001571996-20-000051:notes:125]
These decreases in the Company’s debt balance were partially offset by:

[0001571996-20-000051:notes:126]
•issuance of $2.25 billion principal amount of First Lien Notes on April 9, 2020, described below;

[0001571996-20-000051:notes:127]
•issuance of $2.0 billion principal amount of VMware Notes on April 7, 2020, described below; and

[0001571996-20-000051:notes:128]
•incurrence of an additional $1.4 billion, net, in DFS debt to support the expansion of its financing receivables portfolio.

[0001571996-20-000051:notes:129]
Secured Debt

[0001571996-20-000051:notes:130]
Senior Secured Credit Facilities — The Company has entered into a credit agreement that provides for senior secured credit facilities (the “Senior Secured Credit Facilities”) comprising (a) term loan facilities and (b) a senior secured Revolving Credit Facility, which provides for a borrowing capacity of up to $4.5 billion for general corporate purposes, including capacity for up to $0.5 billion of letters of credit and for borrowings of up to $0.4 billion under swing-line loans.

[0001571996-20-000051:notes:131]
As of October 30, 2020, available borrowings under the Revolving Credit Facility totaled $4.5 billion.  The Senior Secured Credit Facilities provide that the borrowers have the right at any time, subject to customary conditions, to request incremental term loans or incremental revolving commitments.

[0001571996-20-000051:notes:132]
Borrowings under the Senior Secured Credit Facilities bear interest at a rate per annum equal to an applicable margin, plus, at the borrowers’ option, either (a) a base rate, or (b) the London Interbank Offered Rate (“LIBOR”).  The Term Loan B-1 Facility bears interest at LIBOR plus an applicable margin of 2.00% or a base rate plus an applicable margin of 1.00%.  The Term Loan A-4 Facility and the Term Loan A-6 Facility bear interest at LIBOR plus an applicable margin ranging from 1.25% to 2.00% or a base rate plus an applicable margin ranging from 0.25% to 1.00%.  Interest is payable, in the case of loans bearing interest based on LIBOR, at the end of each interest period (but at least every three months), in arrears and, in the case of loans bearing interest based on the base rate, quarterly in arrears.

[0001571996-20-000051:notes:133]
The Term Loan B-1 Facility amortizes in equal quarterly installments in aggregate annual amounts equal to 1% of the original principal amount.  The Term Loan A-4 Facility amortizes in equal quarterly installments in aggregate annual amounts equal to 5% of the original principal amount in each of the first four years after the facility closing date of December 20, 2018, and 80% of the original principal amount in the fifth year after December 20, 2018.  The Term Loan A-6 Facility amortizes in equal quarterly installments in aggregate annual amounts equal to 5% of the original principal amount in each of the first four years after the facility closing date of March 13, 2019, and 80% of the original principal amount in the fifth year after March 13, 2019.  The Revolving Credit Facility has no amortization.

[0001571996-20-000051:notes:134]
The borrowers may voluntarily repay outstanding loans under the term loan facilities and the Revolving Credit Facility at any time without premium or penalty, other than customary “breakage” costs.

[0001571996-20-000051:notes:135]
All obligations of the borrowers under the Senior Secured Credit Facilities and certain swap agreements, cash management arrangements, and certain letters of credit provided by any lender or agent party to the Senior Secured Credit Facilities or any of its affiliates and certain other persons are secured by (a) a first-priority security interest in certain tangible and intangible assets of the borrowers and the guarantors and (b) a first-priority pledge of 100% of the capital stock of the borrowers, Dell Inc., a wholly-owned subsidiary of the Company (“Dell”), and each wholly-owned material restricted subsidiary of the borrowers and the guarantors, in each case subject to certain thresholds, exceptions, and permitted liens.

[0001571996-20-000051:notes:136]
First Lien Notes — Dell International L.L.C. and EMC Corporation, both of which are wholly-owned subsidiaries of Dell Technologies Inc., completed private offerings of multiple series of senior secured notes (collectively, the “First Lien Notes”) which were issued on June 1, 2016, March 20, 2019, and April 9, 2020 in aggregate principal amounts of $20.0 billion, $4.5 billion, and $2.25 billion, respectively.  Interest on the First Lien Notes is payable semiannually.  The First Lien Notes are secured on a pari passu basis with the Senior Secured Credit Facilities, on a first-priority basis by substantially all of the tangible and intangible assets of the issuers and guarantors that secure obligations under the Senior Secured Credit Facilities, including pledges of all capital stock of the issuers, Dell, and certain wholly-owned material subsidiaries of the issuers and the guarantors, subject to certain exceptions.

[0001571996-20-000051:notes:137]
The Company has agreed to use commercially reasonable efforts to register with the SEC notes having terms substantially identical to the terms of the First Lien Notes as part of an offer to exchange such registered notes for the First Lien Notes.  The Company will be obligated to pay additional interest on the First Lien Notes if it fails to consummate such an exchange offer within five years after the closing date of the EMC merger transaction, in the case of the First Lien Notes issued on June 1, 2016, and within five years after their respective issue dates, in the case of the First Lien Notes issued on March 20, 2019 and April 9, 2020.

[0001571996-20-000051:notes:138]
China Revolving Credit Facility — The Company entered into a new revolving credit facility for China (the “China Revolving Credit Facility”) effective May 25, 2020.  The new terms provide for collateralized and non-collateralized principal amounts not to exceed $1.0 billion Chinese renminbi and $1.8 billion Chinese renminbi, respectively, or equivalent amounts in U.S. dollars.  Outstanding borrowings under the collateralized portion of the China Revolving Credit Facility bear interest at the loan prime rate (“LPR”) less 0.2%, for borrowings denominated in Chinese renminbi, or LIBOR plus 1.0%, for borrowings denominated in U.S. dollars, and outstanding borrowings under the non-collateralized portion bear interest at LPR less 0.2%, for borrowings denominated in Chinese renminbi, or LIBOR plus 1.4%, for borrowings denominated in U.S. dollars.  The new facility expired on August 30, 2020.

[0001571996-20-000051:notes:139]
During the fiscal year ended January 31, 2020, the Company renewed the credit agreement for its legacy China revolving credit facility with a bank lender, which provided an uncommitted line with an aggregate principal amount not to exceed $500 million at an interest rate of LIBOR plus 0.6% per annum.  The facility was terminated upon expiration on February 26, 2020.

[0001571996-20-000051:notes:140]
Unsecured Debt

[0001571996-20-000051:notes:141]
Unsecured Notes and Debentures — The Company has outstanding unsecured notes and debentures (collectively, the “Unsecured Notes and Debentures”) that were issued by Dell prior to the acquisition of Dell by Dell Technologies Inc. in the going-private transaction that closed in October 2013.  Interest on these borrowings is payable semiannually.

[0001571996-20-000051:notes:142]
Senior Notes — The senior unsecured notes (collectively, the “Senior Notes”) were issued on June 22, 2016 in an aggregate principal amount of $3.25 billion.  Interest on these borrowings is payable semiannually.

[0001571996-20-000051:notes:143]
EMC Notes — On September 7, 2016, EMC had outstanding $2.5 billion aggregate principal amount of its 1.875% Notes due June 2018, which the Company fully repaid during the three months ended August 3, 2018, $2.0 billion aggregate principal amount of its 2.650% Notes due June 2020, and $1.0 billion aggregate principal amount of its 3.375% Notes due June 2023 (collectively, the “EMC Notes”).  Interest on these borrowings is payable semiannually.

[0001571996-20-000051:notes:144]
VMware Notes — VMware, Inc. completed public offerings of unsecured senior notes in the aggregate amounts of $4.0 billion and $2.0 billion on August 21, 2017 and April 7, 2020, respectively (the “VMware Notes”).  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.  Interest on these borrowings is payable semiannually.

[0001571996-20-000051:notes:145]
VMware Revolving Credit Facility — On September 12, 2017, VMware, Inc. entered into an unsecured credit agreement, establishing a revolving credit facility (the “VMware Revolving Credit Facility”) with a syndicate of lenders that provides the company with a borrowing capacity of up to $1.0 billion for VMware, Inc. general corporate purposes.  Commitments under the VMware Revolving Credit Facility are available for a period of five years, which may be extended, subject to the satisfaction of certain conditions, by up to two one year periods.  The credit agreement contains certain representations, warranties, and covenants.  Commitment fees, interest rates, and other terms of borrowing under the VMware Revolving Credit Facility may vary based on VMware, Inc.’s external credit ratings.  None of the net proceeds of such borrowings will be made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.  As of October 30, 2020, there were no outstanding borrowings under the VMware Revolving Credit Facility.

[0001571996-20-000051:notes:146]
VMware Term Loan Facility — On September 26, 2019, VMware, Inc. entered into a senior unsecured term loan facility (the “VMware Term Loan Facility”) with a syndicate of lenders that provided VMware, Inc. with a borrowing capacity of up to $2.0 billion through February 7, 2020, for VMware, Inc. general corporate purposes.  During the three months ended October 30, 2020, VMware, Inc. repaid the outstanding borrowings of $1.5 billion under the VMware Term Loan Facility.

[0001571996-20-000051:notes:147]
As of January 31, 2020, the outstanding borrowings under the VMware Term Loan Facility were $1.5 billion.  None of the net proceeds of such borrowings were made available to support the operations or satisfy any corporate purposes of Dell Technologies, other than the operations and corporate purposes of VMware, Inc. and VMware, Inc.’s subsidiaries.

[0001571996-20-000051:notes:148]
See Note 4 and Note 7 of the Notes to the Condensed Consolidated Financial Statements, respectively, for discussion of DFS debt and the interest rate swap agreements that hedge a portion of that debt.

[0001571996-20-000051:notes:149]
Other

[0001571996-20-000051:notes:150]
Margin Loan Facility — On April 12, 2017, the Company entered into the Margin Loan Facility in an aggregate principal amount of $2.0 billion, under which VMW Holdco LLC, a wholly-owned subsidiary of EMC, is the borrower.  In connection with the Class V transaction described in Note 1 of the Notes to the Condensed Consolidated Financial Statements, on December 20, 2018, the Company amended the Margin Loan Facility to increase the aggregate principal amount to $3.35 billion.  In connection with obtaining the Term Loan A-6 Facility during the fiscal year ended January 31, 2020, the Company increased the aggregate principal amount of the Margin Loan Facility to $4.0 billion.

[0001571996-20-000051:notes:151]
During the three months ended May 1, 2020, due to volatility in the U.S. stock market resulting from the outbreak of COVID-19, VMware Holdco LLC proactively pledged additional shares of VMware, Inc. common stock to secure its obligations under the Margin Loan Facility agreement.  This resulted in an aggregate number of shares pledged of approximately 76 million shares of Class B common stock of VMware, Inc. and approximately 24 million shares of Class A common stock of VMware, Inc.

[0001571996-20-000051:notes:152]
Loans under the Margin Loan Facility bear interest at a rate per annum payable, at the borrower’s option, either at (a) a base rate plus 1.25% per annum or (b) a LIBOR-based rate plus 2.25% per annum.  Interest under the Margin Loan Facility is payable quarterly.  The Margin Loan Facility will mature in April 2022.  The borrower may voluntarily repay outstanding loans under the Margin Loan Facility at any time without premium or penalty, other than customary “breakage” costs, subject to certain minimum threshold amounts for prepayment.

[0001571996-20-000051:notes:153]
Aggregate Future Maturities

[0001571996-20-000051:notes:154]
The following table presents the aggregate future maturities of the Company’s debt as of October 30, 2020 for the periods indicated:

[0001571996-20-000051:notes:155]
|  | Maturities by Fiscal Year |
|  | 2021 (remaining three months) |  | 2022 |  | 2023 |  | 2024 |  | 2025 |  | Thereafter |  | Total |
|  | (in millions) |
| Senior Secured Credit Facilities and First Lien Notes | $ | — |  |  | $ | 172 |  |  | $ | 286 |  |  | $ | 7,384 |  |  | $ | 1,047 |  |  | $ | 18,297 |  |  | $ | 27,186 |  |
| Unsecured Notes and Debentures | — |  |  | 400 |  |  | — |  |  | — |  |  | — |  |  | 952 |  |  | 1,352 |  |
| Senior Notes and EMC Notes | — |  |  | 1,075 |  |  | — |  |  | 1,000 |  |  | 1,625 |  |  | — |  |  | 3,700 |  |
| VMware Notes | — |  |  | — |  |  | 1,500 |  |  | — |  |  | — |  |  | 3,250 |  |  | 4,750 |  |
| DFS Debt | 2,012 |  |  | 3,481 |  |  | 2,654 |  |  | 356 |  |  | 692 |  |  | 6 |  |  | 9,201 |  |
| Margin Loan Facility | — |  |  | — |  |  | 4,000 |  |  | — |  |  | — |  |  | — |  |  | 4,000 |  |
| Other | 3 |  |  | 12 |  |  | 12 |  |  | 156 |  |  | 8 |  |  | 31 |  |  | 222 |  |
| Total maturities, principal amount | 2,015 |  |  | 5,140 |  |  | 8,452 |  |  | 8,896 |  |  | 3,372 |  |  | 22,536 |  |  | 50,411 |  |
| Associated carrying value adjustments | (1) |  |  | (10) |  |  | (14) |  |  | (38) |  |  | (83) |  |  | (404) |  |  | (550) |  |
| Total maturities, carrying value amount | $ | 2,014 |  |  | $ | 5,130 |  |  | $ | 8,438 |  |  | $ | 8,858 |  |  | $ | 3,289 |  |  | $ | 22,132 |  |  | $ | 49,861 |  |

[0001571996-20-000051:notes:156]
Covenants and Unrestricted Net Assets — The credit agreement for the Senior Secured Credit Facilities contains customary negative covenants that generally limit the ability of Denali Intermediate Inc., a wholly-owned subsidiary of Dell Technologies, Dell, and Dell’s and Denali Intermediate’s other restricted subsidiaries to incur debt, create liens, make fundamental changes, enter into asset sales, make certain investments, pay dividends or distribute or redeem certain equity interests, prepay or redeem certain debt, and enter into certain transactions with affiliates.  The indenture governing the Senior Notes contains customary negative covenants that generally limit the ability of Denali Intermediate, Dell, and Dell’s and Denali Intermediate’s other restricted subsidiaries to incur additional debt or issue certain preferred shares, pay dividends on or make other distributions in respect of capital stock or make other restricted payments, make certain investments, sell or transfer certain assets, create liens on certain assets to secure debt, consolidate, merge, sell, or otherwise dispose of all or substantially all assets, enter into certain transactions with affiliates, and designate subsidiaries as unrestricted subsidiaries.  The negative covenants under such credit agreements and indenture are subject to certain exceptions, qualifications, and “baskets.”  The indentures governing the First Lien Notes, the Unsecured Notes and Debentures, and the EMC Notes variously impose limitations, subject to specified exceptions, on creating certain liens, entering into sale and lease-back transactions, and entering into certain asset sales.  The foregoing credit agreements and indentures contain customary events of default, including failure to make required payments, failure to comply with covenants, and the occurrence of certain events of bankruptcy and insolvency.

[0001571996-20-000051:notes:157]
As of October 30, 2020, the Company had certain consolidated subsidiaries that were designated as unrestricted subsidiaries for all purposes of the applicable credit agreements and the indentures governing the First Lien Notes and the Senior Notes.  Substantially all of the net assets of the Company’s consolidated subsidiaries were restricted, with the exception of the Company’s unrestricted subsidiaries, primarily VMware, Inc., Secureworks, and their respective subsidiaries, as of October 30, 2020.

[0001571996-20-000051:notes:158]
The Term Loan A-4 Facility, the Term Loan A-6 Facility, and the Revolving Credit Facility are subject to a first lien leverage ratio covenant that is tested at the end of each fiscal quarter of Dell with respect to Dell’s preceding four fiscal quarters.  The Company was in compliance with all financial covenants as of October 30, 2020.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001571996-20-000051:notes:159]
[same as prior period, unchanged from 0001571996-20-000045:notes:149]

[0001571996-20-000051:notes:160]
[same as prior period, unchanged from 0001571996-20-000045:notes:150]

[0001571996-20-000051:notes:161]
[same as prior period, unchanged from 0001571996-20-000045:notes:151]

[0001571996-20-000051:notes:162]
[same as prior period, unchanged from 0001571996-20-000045:notes:152]

[0001571996-20-000051:notes:163]
[same as prior period, unchanged from 0001571996-20-000045:notes:153]

[0001571996-20-000051:notes:164]
During the three and nine months ended October 30, 2020 and November 1, 2019, the Company did not discontinue any cash flow hedges related to foreign exchange contracts that had a material impact on the Company’s results of operations due to the probability that the forecasted cash flows would not occur.

[0001571996-20-000051:notes:165]
[same as prior period, unchanged from 0001571996-20-000045:notes:155]

[0001571996-20-000051:notes:166]
[same as prior period, unchanged from 0001571996-20-000045:notes:156]

[0001571996-20-000051:notes:167]
[same as prior period, unchanged from 0001571996-20-000045:notes:157]

[0001571996-20-000051:notes:168]
[same as prior period, unchanged from 0001571996-20-000045:notes:158]

[0001571996-20-000051:notes:169]
[same as prior period, unchanged from 0001571996-20-000045:notes:159]

[0001571996-20-000051:notes:170]
[same as prior period, unchanged from 0001571996-20-000045:notes:160]

[0001571996-20-000051:notes:171]
[same as prior period, unchanged from 0001571996-20-000045:notes:161]

[0001571996-20-000051:notes:172]
[same as prior period, unchanged from 0001571996-20-000045:notes:162]

[0001571996-20-000051:notes:173]
|  | October 30, 2020 |  | January 31, 2020 |
|  | (in millions) |
| Foreign exchange contracts: |  |  |  |
| Designated as cash flow hedging instruments | $ | 6,436 |  |  | $ | 8,703 |  |
| Non-designated as hedging instruments | 8,808 |  |  | 7,711 |  |
| Total | $ | 15,244 |  |  | $ | 16,414 |  |
| Interest rate contracts: |  |  |  |
| Non-designated as hedging instruments | $ | 5,164 |  |  | $ | 4,043 |  |

[0001571996-20-000051:notes:174]
[same as prior period, unchanged from 0001571996-20-000045:notes:164]

[0001571996-20-000051:notes:175]
| Derivatives in Cash Flow Hedging Relationships |  | Gain (Loss) Recognized in Accumulated OCI, Net of Tax, on Derivatives |  | Location of Gain (Loss) Reclassified from Accumulated OCI into Income |  | Gain (Loss) Reclassified from Accumulated OCI into Income |  |  |  |  |
|  |  | (in millions) |  |  |  | (in millions) |  |  |  |  |
| For the three months ended October 30, 2020 |  |  |  |  |
|  |  |  |  | Total net revenue |  | $ | (88) |  |  |  |  |  |
| Foreign exchange contracts |  | $ | 45 |  |  | Total cost of net revenue |  | 4 |  |  |  |  |  |
| Interest rate contracts |  | — |  |  | Interest and other, net |  | — |  |  |  |  |  |
| Total |  | $ | 45 |  |  |  |  | $ | (84) |  |  |  |  |  |
| For the three months ended November 1, 2019 |  |  |  |  |
|  |  |  |  | Total net revenue |  | $ | 71 |  |  |  |  |  |
| Foreign exchange contracts |  | $ | (47) |  |  | Total cost of net revenue |  | — |  |  |  |  |  |
| Interest rate contracts |  | — |  |  | Interest and other, net |  | — |  |  |  |  |  |
| Total |  | $ | (47) |  |  |  |  | $ | 71 |  |  |  |  |  |
| For the nine months ended October 30, 2020 |  |  |  |  |
|  |  |  |  | Total net revenue |  | $ | 17 |  |  |  |  |  |
| Foreign exchange contracts |  | $ | (45) |  |  | Total cost of net revenue |  | 7 |  |  |  |  |  |
| Interest rate contracts |  | — |  |  | Interest and other, net |  | — |  |  |  |  |  |
| Total |  | $ | (45) |  |  |  |  | $ | 24 |  |  |  |  |  |
| For the nine months ended November 1, 2019 |  |  |  |  |
|  |  |  |  | Total net revenue |  | $ | 197 |  |  |  |  |  |
| Foreign exchange contracts |  | $ | 210 |  |  | Total cost of net revenue |  | — |  |  |  |  |  |
| Interest rate contracts |  | — |  |  | Interest and other, net |  | — |  |  |  |  |  |
| Total |  | $ | 210 |  |  |  |  | $ | 197 |  |  |  |  |  |

[0001571996-20-000051:notes:176]
[same as prior period, unchanged from 0001571996-20-000045:notes:166]

[0001571996-20-000051:notes:177]
|  |  | Three Months Ended |  | Nine Months Ended |  |  |
|  |  | October 30, 2020 |  | November 1, 2019 |  | October 30, 2020 |  | November 1, 2019 |  | Location of Gain (Loss) Recognized |
|  |  | (in millions) |  |  |
| Gain (Loss) Recognized: |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | (127) |  |  | $ | 13 |  |  | $ | 87 |  |  | $ | (46) |  |  | Interest and other, net |
| Interest rate contracts |  | 1 |  |  | 1 |  |  | (43) |  |  | (21) |  |  | Interest and other, net |
| Total |  | $ | (126) |  |  | $ | 14 |  |  | $ | 44 |  |  | $ | (67) |  |  |  |

[0001571996-20-000051:notes:178]
[same as prior period, unchanged from 0001571996-20-000045:notes:168]

[0001571996-20-000051:notes:179]
[same as prior period, unchanged from 0001571996-20-000045:notes:169]

[0001571996-20-000051:notes:180]
|  | October 30, 2020 |
|  | Other CurrentAssets |  | Other Non-Current Assets |  | Other CurrentLiabilities |  | Other Non-CurrentLiabilities |  | TotalFair Value |
|  | (in millions) |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts in an asset position | $ | 22 |  |  | $ | — |  |  | $ | 59 |  |  | $ | — |  |  | $ | 81 |  |
| Foreign exchange contracts in a liability position | — |  |  | — |  |  | (13) |  |  | — |  |  | (13) |  |
| Net asset (liability) | 22 |  |  | — |  |  | 46 |  |  | — |  |  | 68 |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts in an asset position | 37 |  |  | 1 |  |  | 79 |  |  | — |  |  | 117 |  |
| Foreign exchange contracts in a liability position | (19) |  |  | — |  |  | (274) |  |  | (2) |  |  | (295) |  |
| Interest rate contracts in an asset position | — |  |  | 11 |  |  | — |  |  | — |  |  | 11 |  |
| Interest rate contracts in a liability position | — |  |  | — |  |  | — |  |  | (30) |  |  | (30) |  |
| Net asset (liability) | 18 |  |  | 12 |  |  | (195) |  |  | (32) |  |  | (197) |  |
| Total derivatives at fair value | $ | 40 |  |  | $ | 12 |  |  | $ | (149) |  |  | $ | (32) |  |  | $ | (129) |  |
|  | January 31, 2020 |
|  | Other CurrentAssets |  | Other Non-Current Assets |  | Other CurrentLiabilities |  | Other Non-CurrentLiabilities |  | TotalFair Value |
|  | (in millions) |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts in an asset position | $ | 108 |  |  | $ | — |  |  | $ | 15 |  |  | $ | — |  |  | $ | 123 |  |
| Foreign exchange contracts in a liability position | (2) |  |  | — |  |  | (3) |  |  | — |  |  | (5) |  |
| Net asset (liability) | 106 |  |  | — |  |  | 12 |  |  | — |  |  | 118 |  |
| Derivatives not designated as hedging instruments: |
| Foreign exchange contracts in an asset position | 136 |  |  | — |  |  | 39 |  |  | — |  |  | 175 |  |
| Foreign exchange contracts in a liability position | (162) |  |  | — |  |  | (81) |  |  | (6) |  |  | (249) |  |
| Interest rate contracts in an asset position | — |  |  | 1 |  |  | — |  |  | — |  |  | 1 |  |
| Interest rate contracts in a liability position | — |  |  | — |  |  | — |  |  | (32) |  |  | (32) |  |
| Net asset (liability) | (26) |  |  | 1 |  |  | (42) |  |  | (38) |  |  | (105) |  |
| Total derivatives at fair value | $ | 80 |  |  | $ | 1 |  |  | $ | (30) |  |  | $ | (38) |  |  | $ | 13 |  |

[0001571996-20-000051:notes:181]
[same as prior period, unchanged from 0001571996-20-000045:notes:171]

[0001571996-20-000051:notes:182]
|  | October 30, 2020 |
|  | Gross Amounts of Recognized Assets/ (Liabilities) |  | Gross Amounts Offset in the Statement of Financial Position |  | Net Amounts of Assets/ (Liabilities) Presented in the Statement of Financial Position |  | Gross Amounts not Offset in the Statement of Financial Position |  | Net Amount |
|  | Financial Instruments |  | Cash Collateral Received or Pledged |  |
|  | (in millions) |
| Derivative instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Financial assets | $ | 209 |  |  | $ | (157) |  |  | $ | 52 |  |  | $ | — |  |  | $ | — |  |  | $ | 52 |  |
| Financial liabilities | (338) |  |  | 157 |  |  | (181) |  |  | — |  |  | (4) |  |  | (185) |  |
| Total derivative instruments | $ | (129) |  |  | $ | — |  |  | $ | (129) |  |  | $ | — |  |  | $ | (4) |  |  | $ | (133) |  |
|  | January 31, 2020 |
|  | Gross Amounts of Recognized Assets/ (Liabilities) |  | Gross Amounts Offset in the Statement of Financial Position |  | Net Amounts of Assets/ (Liabilities) Presented in the Statement of Financial Position |  | Gross Amounts not Offset in the Statement of Financial Position |  | Net Amount |
|  | Financial Instruments |  | Cash Collateral Received or Pledged |  |
|  | (in millions) |
| Derivative instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Financial assets | $ | 299 |  |  | $ | (218) |  |  | $ | 81 |  |  | $ | — |  |  | $ | — |  |  | $ | 81 |  |
| Financial liabilities | (286) |  |  | 218 |  |  | (68) |  |  | — |  |  | 15 |  |  | (53) |  |
| Total derivative instruments | $ | 13 |  |  | $ | — |  |  | $ | 13 |  |  | $ | — |  |  | $ | 15 |  |  | $ | 28 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001571996-20-000051:notes:183]
[same as prior period, unchanged from 0001571996-20-000045:notes:173]

[0001571996-20-000051:notes:184]
[same as prior period, unchanged from 0001571996-20-000045:notes:174]

[0001571996-20-000051:notes:185]
[same as prior period, unchanged from 0001571996-20-000045:notes:175]

[0001571996-20-000051:notes:186]
SaltStack, Inc. — During the three months ended October 30, 2020, VMware, Inc. completed the acquisition of SaltStack, Inc., a developer of intelligent, event-driven automation software, to broaden VMware, Inc.’s Cloud Management capabilities from infrastructure to applications.  The total purchase price, net of cash acquired, was $51 million.  The purchase price primarily included $29 million of intangible assets and $24 million of goodwill that is not expected to be deductible for tax purposes.  The identifiable intangible assets, which primarily consisted of completed technology, have estimated useful lives of three years.

[0001571996-20-000051:notes:187]
[same as prior period, unchanged from 0001571996-20-000045:notes:176]

[0001571996-20-000051:notes:188]
Lastline, Inc. — During the three months ended July 31, 2020, VMware, Inc. completed the acquisition of Lastline, Inc., a provider of network-based security breach detection products and services, to enhance capabilities for network detection and threat analysis on VMware NSX and SD-WAN offerings.  The total purchase price, net of cash acquired, was $114 million.  The purchase price primarily included $29 million of identifiable intangible assets and $86 million of goodwill that is not expected to be deductible for tax purposes.  The identifiable intangible assets, which primarily consisted of completed technology, have estimated useful lives of one year to four years.

[0001571996-20-000051:notes:189]
[same as prior period, unchanged from 0001571996-20-000045:notes:178]

[0001571996-20-000051:notes:190]
Other Fiscal 2021 Acquisitions — During the nine months ended October 30, 2020, VMware, Inc. completed three other acquisitions, which were not material individually to the Condensed Consolidated Financial Statements.  VMware, Inc. expects these acquisitions to enhance its product features and capabilities for VMware Carbon Black Cloud and vRealize Operations offerings.  The aggregate purchase price for these three acquisitions, net of cash acquired, was $44 million and primarily included $35 million of identifiable intangible assets and $16 million of goodwill, of which $24 million is expected to be deductible for tax purposes.  The identifiable intangible assets, which primarily consisted of completed technology, have estimated useful lives of one year to five years.

[0001571996-20-000051:notes:191]
For each of the acquisitions completed during the nine months ended October 30, 2020, the excess of the purchase consideration over the fair value of net tangible and identifiable intangible assets acquired was recorded as goodwill, which management believes represents synergies expected from combining the technologies of VMware, Inc. with those of the acquired businesses.  The estimated fair value assigned to the tangible assets, identifiable intangible assets, and assumed liabilities were based on management's estimates and assumptions.  The initial allocation of the purchase price was based on preliminary valuations and assumptions and is subject to change within the measurement period.  VMware, Inc. expects to finalize the allocation of the purchase price within the measurement period.

[0001571996-20-000051:notes:192]
The pro forma financial information assuming these Fiscal 2021 acquisitions had occurred as of the beginning of the fiscal year prior to the fiscal year of acquisition, as well as the revenue and earnings generated during the current fiscal year, were not material for disclosure purposes.

[0001571996-20-000051:notes:193]
[same as prior period, unchanged from 0001571996-20-000045:notes:181]

[0001571996-20-000051:notes:194]
[same as prior period, unchanged from 0001571996-20-000045:notes:182]

[0001571996-20-000051:notes:195]
[same as prior period, unchanged from 0001571996-20-000045:notes:183]

[0001571996-20-000051:notes:196]
|  | Infrastructure Solutions Group |  | Client Solutions Group |  | VMware |  | Other Businesses (a) |  | Total |
|  | (in millions) |
| Balance as of January 31, 2020 | $ | 15,089 |  |  | $ | 4,237 |  |  | $ | 20,532 |  |  | $ | 1,833 |  |  | $ | 41,691 |  |
| Goodwill acquired (b) | — |  |  | — |  |  | 230 |  |  | 8 |  |  | 238 |  |
| Impact of foreign currency translation | 90 |  |  | — |  |  | — |  |  | 9 |  |  | 99 |  |
| Goodwill divested (c) | — |  |  | — |  |  | — |  |  | (1,385) |  |  | (1,385) |  |
| Balance as of October 30, 2020 | $ | 15,179 |  |  | $ | 4,237 |  |  | $ | 20,762 |  |  | $ | 465 |  |  | $ | 40,643 |  |

[0001571996-20-000051:notes:197]
(a)    As of October 30, 2020, goodwill allocated to Other businesses consists of Secureworks, Virtustream, and Boomi.

[0001571996-20-000051:notes:198]
(b)    Primarily VMware, Inc. business combinations completed during the nine months ended October 30, 2020, as discussed above.

[0001571996-20-000051:notes:199]
(c)    During the three months ended October 30, 2020, Dell Technologies closed the transaction to sell RSA Security.  Prior to the divestiture, RSA Security was included in Other businesses.  See Note 1 of the Notes to the Condensed Consolidated Financial Statements for additional information about the divestiture of RSA Security.

[0001571996-20-000051:notes:200]
Goodwill Impairment Tests — Goodwill and indefinite-lived intangible assets are tested for impairment annually during the third fiscal quarter and whenever events or circumstances may indicate that an impairment has occurred.  As a result of the changes in the current economic environment related to the COVID-19 pandemic, the Company considered whether there was a potential triggering event requiring the evaluation of whether goodwill of any of the reporting units should be tested for impairment.  The Company determined there was no triggering event in previous quarters during Fiscal 2021 and no impairment test was performed other than the Company’s annual impairment review in the third quarter of Fiscal 2021.

[0001571996-20-000051:notes:201]
For the annual impairment review in the third quarter of Fiscal 2021, the Company elected to bypass the assessment of qualitative factors to determine whether it was more likely than not that the fair value of a reporting unit was less than its carrying amount, including goodwill.  In electing to bypass the qualitative assessment, the Company proceeded directly to performing a quantitative goodwill impairment test to measure the fair value of each goodwill reporting unit relative to its carrying amount, and to determine the amount of goodwill impairment loss to be recognized, if any.

[0001571996-20-000051:notes:202]
[same as prior period, unchanged from 0001571996-20-000045:notes:190]

[0001571996-20-000051:notes:203]
The fair value of the indefinite-lived trade names is generally estimated using discounted cash flow methodologies.  The discounted cash flow methodology requires significant judgment, including estimation of future revenue, which is dependent on internal forecasts, the estimation of the long-term revenue growth rate of the Company’s business and the determination of the Company’s weighted average cost of capital and royalty rates.  Changes in these estimates and assumptions could materially affect the fair value of the indefinite-lived intangible assets, potentially resulting in a non-cash impairment charge.

[0001571996-20-000051:notes:204]
Based on the results of the annual impairment test performed during the three months ended October 30, 2020, the fair values of each of the reporting units exceeded their carrying values.

[0001571996-20-000051:notes:205]
During the fiscal year ended January 31, 2020, an interim impairment assessment of Virtustream was required.  There were no remaining balances of Virtustream goodwill, intangible assets, or property, plant, and equipment as of January 31, 2020 following the gross asset impairment charge of $619 million (comprised of $207 million of goodwill, $266 million of intangible assets, net, and $146 million of property, plant, and equipment, net) recognized during the fiscal year ended January 31, 2020, and a gross goodwill impairment charge of $190 million recognized during the fiscal year ended February 1, 2019.  The impairment was reflected in Other, net within cash flows from operating activities on the Condensed Consolidated Statements of Cash Flows.

[0001571996-20-000051:notes:206]
[same as prior period, unchanged from 0001571996-20-000045:notes:194]

[0001571996-20-000051:notes:207]
[same as prior period, unchanged from 0001571996-20-000045:notes:195]

[0001571996-20-000051:notes:208]
|  | October 30, 2020 |  | January 31, 2020 |
|  | Gross |  | AccumulatedAmortization |  | Net |  | Gross |  | AccumulatedAmortization |  | Net |
|  | (in millions) |
| Customer relationships | $ | 22,399 |  |  | $ | (15,004) |  |  | $ | 7,395 |  |  | $ | 22,950 |  |  | $ | (13,821) |  |  | $ | 9,129 |  |
| Developed technology | 15,484 |  |  | (11,758) |  |  | 3,726 |  |  | 15,707 |  |  | (10,974) |  |  | 4,733 |  |
| Trade names | 1,266 |  |  | (885) |  |  | 381 |  |  | 1,306 |  |  | (816) |  |  | 490 |  |
| Definite-lived intangible assets | 39,149 |  |  | (27,647) |  |  | 11,502 |  |  | 39,963 |  |  | (25,611) |  |  | 14,352 |  |
| Indefinite-lived trade names | 3,755 |  |  | — |  |  | 3,755 |  |  | 3,755 |  |  | — |  |  | 3,755 |  |
| Total intangible assets | $ | 42,904 |  |  | $ | (27,647) |  |  | $ | 15,257 |  |  | $ | 43,718 |  |  | $ | (25,611) |  |  | $ | 18,107 |  |

[0001571996-20-000051:notes:209]
Amortization expense related to definite-lived intangible assets was approximately $0.8 billion and $1.1 billion for the three months ended October 30, 2020 and November 1, 2019, respectively, and $2.5 billion and $3.3 billion for the nine months ended October 30, 2020 and November 1, 2019, respectively.  There were no material impairment charges related to intangible assets during the three and nine months ended October 30, 2020.  During the nine months ended November 1, 2019, an impairment charge related to Virtustream intangible assets, net was approximately $266 million.

[0001571996-20-000051:notes:210]
[same as prior period, unchanged from 0001571996-20-000045:notes:198]

[0001571996-20-000051:notes:211]
[same as prior period, unchanged from 0001571996-20-000045:notes:199]

[0001571996-20-000051:notes:212]
|  | October 30, 2020 |
| Fiscal Years | (in millions) |
| 2021 (remaining three months) | $ | 846 |  |
| 2022 | 2,698 |  |
| 2023 | 1,820 |  |
| 2024 | 1,451 |  |
| 2025 | 1,101 |  |
| Thereafter | 3,586 |  |
| Total | $ | 11,502 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001571996-20-000051:notes:213]
[same as prior period, unchanged from 0001571996-20-000045:notes:201]

[0001571996-20-000051:notes:214]
[same as prior period, unchanged from 0001571996-20-000045:notes:202]

[0001571996-20-000051:notes:215]
[same as prior period, unchanged from 0001571996-20-000045:notes:203]

[0001571996-20-000051:notes:216]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 30, 2020 |  | November 1, 2019 |  | October 30, 2020 |  | November 1, 2019 |
|  | (in millions) |
| Deferred revenue: |  |  |  |  |  |  |  |
| Deferred revenue at beginning of period | $ | 28,791 |  |  | $ | 25,348 |  |  | $ | 27,800 |  |  | $ | 24,010 |  |
| Revenue deferrals | 5,432 |  |  | 5,326 |  |  | 17,560 |  |  | 16,201 |  |
| Revenue recognized | (5,542) |  |  | (4,922) |  |  | (16,418) |  |  | (14,459) |  |
| Other (a) (b) | — |  |  | 151 |  |  | (261) |  |  | 151 |  |
| Deferred revenue at end of period | $ | 28,681 |  |  | $ | 25,903 |  |  | $ | 28,681 |  |  | $ | 25,903 |  |
| Short-term deferred revenue | $ | 15,259 |  |  | $ | 13,787 |  |  | $ | 15,259 |  |  | $ | 13,787 |  |
| Long-term deferred revenue | $ | 13,422 |  |  | $ | 12,116 |  |  | $ | 13,422 |  |  | $ | 12,116 |  |

[0001571996-20-000051:notes:217]
(a) For the nine months ended October 30, 2020, Other consists of divested deferred revenue from the sale of RSA Security.  See Note 1 of the Notes to the Condensed Consolidated Financial Statements for more information about the divestiture of RSA Security.  For the three months ended October 30, 2020, there was no impact to deferred revenue because RSA Security was previously classified as held for sale.

[0001571996-20-000051:notes:218]
(b) For the three and nine months ended November 1, 2019, Other consists of acquired deferred revenue from Carbon Black, Inc. by VMware, Inc.

[0001571996-20-000051:notes:219]
Remaining Performance Obligations — Remaining performance obligations represent the aggregate amount of the transaction price allocated to performance obligations not delivered, or partially undelivered, as of the end of the reporting period.  Remaining performance obligations include deferred revenue plus unbilled amounts not yet recorded in deferred revenue.  The value of the transaction price allocated to remaining performance obligations as of October 30, 2020 was approximately $38 billion.  The Company expects to recognize approximately 63% of remaining performance obligations as revenue in the next twelve months, and the remainder thereafter.

[0001571996-20-000051:notes:220]
[same as prior period, unchanged from 0001571996-20-000045:notes:207]

[0001571996-20-000051:notes:221]
[same as prior period, unchanged from 0001571996-20-000045:notes:208]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001571996-20-000051:notes:222]
NOTE 10 — COMMITMENTS AND CONTINGENCIES

[0001571996-20-000051:notes:223]
Legal Matters

[0001571996-20-000051:notes:224]
The Company is involved in various claims, suits, assessments, investigations, and legal proceedings that arise from time to time in the ordinary course of its business, including those identified below, consisting of matters involving consumer, antitrust, tax, intellectual property, and other issues on a global basis.

[0001571996-20-000051:notes:225]
The Company accrues a liability when it believes that it is both probable that a liability has been incurred and that it can reasonably estimate the amount of the loss.  The Company reviews these accruals at least quarterly and adjusts them to reflect ongoing negotiations, settlements, rulings, advice of legal counsel, and other relevant information.  To the extent new information is obtained and the Company’s views on the probable outcomes of claims, suits, assessments, investigations, or legal proceedings change, changes in the Company’s accrued liabilities would be recorded in the period in which such a determination is made.  For some matters, the amount of liability is not probable or the amount cannot be reasonably estimated and therefore accruals have not been made.

[0001571996-20-000051:notes:226]
The following is a discussion of the Company’s significant legal matters and other proceedings:

[0001571996-20-000051:notes:227]
Class Actions Related to the Class V Transaction — Four purported stockholders brought putative class action complaints arising out of the Class V transaction described in Note 1of the Notes to the Condensed Consolidated Financial Statements.  The actions were captioned Hallandale Beach Police and Fire Retirement Plan v. Michael Dell et al. (Civil Action No. 2018-0816-JTL), Howard Karp v. Michael Dell et al. (Civil Action No. 2019-0032-JTL), Miramar Police Officers’ Retirement Plan v. Michael Dell et al. (Civil Action No. 2019-0049-JTL), and Steamfitters Local 449 Pension Plan v. Michael Dell et al. (Civil Action No. 2019-0115-JTL).  The four actions were consolidated in the Delaware Chancery Court into In Re Dell Class V Litigation (Consol. C.A. No. 2018-0816-JTL), which names as defendants the Company’s board of directors and certain stockholders of the Company, including Michael S. Dell.  The plaintiffs generally allege that the defendants breached their fiduciary duties to the former holders of Class V Common Stock in connection with the Class V transaction by allegedly causing the Company to enter into a transaction that favored the interests of the controlling stockholders at the expense of such former stockholders.  The plaintiffs seek, among other remedies, a judicial declaration that the defendants breached their fiduciary duties and an award of damages, fees, and costs.  The plaintiffs filed an amended complaint in August 2019 making substantially similar allegations to those described above.  The defendants filed a motion to dismiss the action in September 2019.  The court denied the motion in June 2020 and the case has now moved to discovery.

[0001571996-20-000051:notes:228]
Patent Litigation — On April 25, 2019, Cirba Inc. (“Cirba”) filed a lawsuit against VMware, Inc. in the United States District Court for the District of Delaware, alleging two patent infringement claims and three trademark infringement-related claims.  On May 6, 2019, Cirba filed a motion seeking a preliminary injunction tied to one of the two patents it alleges VMware, Inc. infringes.  Following a hearing on August 6, 2019, the Court denied Cirba’s preliminary injunction motion and set the case for trial in mid-January 2020.  On August 20, 2019, VMware, Inc. filed counterclaims against Cirba, asserting among other claims that Cirba is infringing four VMware, Inc. patents.  The Delaware Court severed those claims from the January 2020 trial on Cirba’s claims, and the trial on VMware, Inc.’s patent claims is currently set for September 2021.  The trial on Cirba’s claims in the Delaware court was completed on January 23, 2020, and on January 24, 2020, the jury returned a verdict finding that VMware, Inc. willfully infringed the two asserted patents and awarding approximately $237 million in damages.  The jury further found that VMware, Inc. was not liable on Cirba’s trademark infringement-related claims.  A total of $237 million was accrued for the Delaware action, which reflects the estimated losses that are considered both probable and reasonably estimable at this time.  The parties filed the post-trial motions in which VMware, Inc. moved to set aside the verdict and reduce the damages award, and Cirba moved for a permanent injunction, enhanced damages, setting of an ongoing royalty rate, and an award of pre-judgment and post-judgment interest and supplemental damages.  A hearing was held in the Delaware court on those motions on May 15, 2020, and the Delaware court has taken those motions under advisement.  VMware, Inc. intends to vigorously defend itself in this matter, including, if necessary, via an appeal.  Final resolution of this matter could be materially different from the amount accrued.  The amount accrued for this matter is included in Accrued and other in the Condensed Consolidated Statements of Financial Position as of October 30, 2020 and January 31, 2020, and the charge was classified in Selling, general and administrative in the Consolidated Statements of Income (Loss) during the fiscal year ended January 31, 2020.

[0001571996-20-000051:notes:229]
On October 22, 2019, VMware, Inc. filed a separate patent infringement lawsuit against Cirba in the United States District Court for the Eastern District of Virginia, asserting that Cirba infringes four additional VMware, Inc. patents.  The Virginia court transferred these patent claims to Delaware.  On March 23, 2020, Cirba filed a counterclaim asserting one additional patent against VMware, Inc.  VMware, Inc. intends to vigorously defend itself in this matter.

[0001571996-20-000051:notes:230]
Class Actions Related to VMware, Inc.’s Acquisition of Pivotal — Two purported stockholders brought putative class action complaints arising out of VMware, Inc.’s acquisition of Pivotal Software, Inc. on December 30, 2019 as described in Note 1 of the Notes to the Condensed Consolidated Financial Statements.  The two actions were consolidated in the Delaware Chancery Court into In re: Pivotal Software, Inc. Stockholders Litigation (Civil Action No. 2020-0440-KSJM).  The complaint names as defendants the Company, VMware, Inc., Michael S. Dell, and certain officers of Pivotal.  The plaintiffs generally allege that the defendants breached their fiduciary duties to the former holders of Pivotal Class A Common Stock in connection with VMware, Inc.’s acquisition of Pivotal by allegedly causing Pivotal to enter into a transaction that favored the interests of Pivotal’s controlling stockholders at the expense of such former stockholders.  The plaintiffs seek, among other remedies, a judicial declaration that the defendants breached their fiduciary duties and an award of damages, fees, and costs.

[0001571996-20-000051:notes:231]
Other Litigation — The various legal proceedings in which Dell is involved include commercial and intellectual property litigation.  Dell does not currently anticipate that any of these matters will have a material adverse effect on its business, financial condition, results of operations, or cash flows.

[0001571996-20-000051:notes:232]
As of October 30, 2020, the Company does not believe there is a reasonable possibility that a material loss exceeding the amounts already accrued for these or other proceedings or matters has been incurred.  However, since the ultimate resolution of any such proceedings and matters is inherently unpredictable, the Company’s business, financial condition, results of operations, or cash flows could be materially affected in any particular period by unfavorable outcomes in one or more of these proceedings or matters.  Whether the outcome of any claim, suit, assessment, investigation, or legal proceeding, individually or collectively, could have a material adverse effect on the Company’s business, financial condition, results of operations, or cash flows will depend on a number of variables, including the nature, timing, and amount of any associated expenses, amounts paid in settlement, damages, or other remedies or consequences.

[0001571996-20-000051:notes:233]
Indemnifications

[0001571996-20-000051:notes:234]
In the ordinary course of business, the Company enters into contractual arrangements under which it may agree to indemnify the third party to such arrangements from any losses incurred relating to the services it performs on behalf of the Company or for losses arising from certain events as defined in the particular contract, such as litigation or claims relating to past performance.  Such indemnification obligations may not be subject to maximum loss clauses.  Historically, payments related to these indemnifications have not been material to the Company.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001571996-20-000051:notes:235]
[same as prior period, unchanged from 0001571996-20-000045:notes:222]

[0001571996-20-000051:notes:236]
For the three months ended October 30, 2020 and November 1, 2019, the Company’s effective income tax rates were 37.2% and -247.2% on pre-tax income of $1.4 billion and $159 million, respectively.  For the nine months ended October 30, 2020 and November 1, 2019, the Company’s effective income tax rates were -6.1% and 5482.1% on pre-tax income of $2.0 billion and pre-tax losses of $95 million, respectively.  The changes in the Company’s effective income tax rates are primarily driven by discrete tax items and a change in the Company’s jurisdictional mix of income.

[0001571996-20-000051:notes:237]
The Company’s effective income tax rates for the three and nine months ended October 30, 2020 include a discrete tax expense of $359 million relating to the divestiture of RSA Security during the periods due to the relatively low tax basis for the assets sold, particularly goodwill.  For the nine months ended October 30, 2020, the Company’s effective income tax rate also includes discrete tax benefits of $746 million related to an audit settlement and $59 million from an intra-entity asset transfer of certain of Pivotal’s intellectual property to an Irish subsidiary that was completed by VMware, Inc. For the nine months ended November 1, 2019, the Company’s effective income tax rate includes discrete tax benefits of $4.9 billion related to similar intra-entity asset transfers.  The tax benefit for each intra-entity asset transfer was recorded as a deferred tax asset in the period of the transaction and represents the book and tax basis difference on the transferred assets measured based on the intellectual property’s current fair value and applicable Irish statutory tax rate.  The Company expects to be able to realize the deferred tax assets resulting from these intra-entity asset transfers.  The Company’s effective income tax rates for the three and nine months ended November 1, 2019 also include discrete tax benefits of $305 million related to an audit settlement.

[0001571996-20-000051:notes:238]
The differences between the estimated effective income tax rates and the U.S. federal statutory rate of 21% principally result from the Company’s geographical distribution of income, differences between the book and tax treatment of certain items, and the discrete tax items discussed above.  In certain jurisdictions, the Company’s tax rate is significantly less than the applicable statutory rate as a result of tax holidays.  The majority of the Company’s foreign income that is subject to these tax holidays and lower tax rates is attributable to Singapore, China, and Malaysia.  A significant portion of these income tax benefits relates to a tax holiday that will be effective until January 31, 2029.  The Company’s other tax holidays will expire in whole or in part during fiscal years 2022 through 2030.  Many of these tax holidays and reduced tax rates may be extended when certain conditions are met or may be terminated early if certain conditions are not met.  As of October 30, 2020, the Company was not aware of any matters of non-compliance related to these tax holidays.  The effective income tax rate for future quarters of Fiscal 2021 may be impacted by the actual mix of jurisdictions in which income is generated.

[0001571996-20-000051:notes:239]
During the nine months ended October 30, 2020, the Company effectively settled the Internal Revenue Service (“IRS”) audit for fiscal years 2010 through 2014, for which the Company made a cash payment of $435 million to the IRS on August 3, 2020.  The IRS is currently examining fiscal years 2015 through 2019.  The Company believes it has valid positions supporting its tax returns and that it is adequately reserved.

[0001571996-20-000051:notes:240]
[same as prior period, unchanged from 0001571996-20-000045:notes:226]

[0001571996-20-000051:notes:241]
Judgment is required in evaluating the Company’s uncertain tax positions and determining the Company’s provision for income taxes.  The unrecognized tax benefits were $1.4 billion and $2.5 billion as of October 30, 2020 and January 31, 2020, respectively, and are included in accrued and other and other non-current liabilities in the Condensed Consolidated Statements of Financial Position.  The Company does not anticipate a significant change to the total amount of unrecognized tax benefits within the next twelve months.
The Company takes certain non-income tax positions in the jurisdictions in which it operates and has received certain non-income tax assessments from various jurisdictions.  The Company believes that a material loss in these matters is not probable and that it is not reasonably possible that a material loss exceeding amounts already accrued has been incurred.  The Company believes its positions in these non-income tax litigation matters are supportable and that it ultimately will prevail in the matters.  In the normal course of business, the Company’s positions and conclusions related to its non-income taxes could be challenged and assessments may be made.  To the extent new information is obtained and the Company’s views on its positions, probable outcomes of assessments, or litigation change, changes in estimates to the Company’s accrued liabilities would be recorded in the period in which such a determination is made.  In the resolution process for income tax and non-income tax audits, the Company is required in certain situations to provide collateral guarantees or indemnification to regulators and tax authorities until the matter is resolved.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001571996-20-000051:notes:242]
[same as prior period, unchanged from 0001571996-20-000045:notes:228]

[0001571996-20-000051:notes:243]
[same as prior period, unchanged from 0001571996-20-000045:notes:229]

[0001571996-20-000051:notes:244]
[same as prior period, unchanged from 0001571996-20-000045:notes:230]

[0001571996-20-000051:notes:245]
|  | Foreign Currency Translation Adjustments |  |  |  | Cash Flow Hedges |  | Pension and Other Postretirement Plans |  | Accumulated Other Comprehensive Income (Loss) |
|  | (in millions) |
| Balances as of January 31, 2020 | $ | (678) |  |  |  |  | $ | 14 |  |  | $ | (45) |  |  | $ | (709) |  |
| Other comprehensive income (loss) before reclassifications | 243 |  |  |  |  | (45) |  |  | (21) |  |  | 177 |  |
| Amounts reclassified from accumulated other comprehensive income (loss) | — |  |  |  |  | (24) |  |  | 3 |  |  | (21) |  |
| Total change for the period | 243 |  |  |  |  | (69) |  |  | (18) |  |  | 156 |  |
| Less: Change in comprehensive income (loss) attributable to non-controlling interests | — |  |  |  |  | — |  |  | — |  |  | — |  |
| Balances as of October 30, 2020 | $ | (435) |  |  |  |  | $ | (55) |  |  | $ | (63) |  |  | $ | (553) |  |

[0001571996-20-000051:notes:246]
[same as prior period, unchanged from 0001571996-20-000045:notes:232]

[0001571996-20-000051:notes:247]
[same as prior period, unchanged from 0001571996-20-000045:notes:233]

[0001571996-20-000051:notes:248]
|  |  |  | Three Months Ended |
|  |  |  | October 30, 2020 |  |  |  | November 1, 2019 |
|  |  |  | Cash Flow Hedges |  | Pensions |  | Total |  |  |  | Cash Flow Hedges |  | Pensions |  | Total |
|  |  |  | (in millions) |
| Total reclassifications, net of tax: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue |  |  | $ | (88) |  |  | $ | — |  |  | $ | (88) |  |  |  |  | $ | 71 |  |  | $ | — |  |  | $ | 71 |  |
| Cost of net revenue |  |  | 4 |  |  | — |  |  | 4 |  |  |  |  | — |  |  | — |  |  | — |  |
| Operating expenses |  |  | — |  |  | 1 |  |  | 1 |  |  |  |  | — |  |  | — |  |  | — |  |
| Total reclassifications, net of tax |  |  | $ | (84) |  |  | $ | 1 |  |  | $ | (83) |  |  |  |  | $ | 71 |  |  | $ | — |  |  | $ | 71 |  |
|  |  |  | Nine Months Ended |
|  |  |  | October 30, 2020 |  |  |  | November 1, 2019 |
|  |  |  | Cash Flow Hedges |  | Pensions |  | Total |  |  |  | Cash Flow Hedges |  | Pensions |  | Total |
|  |  |  | (in millions) |
| Total reclassifications, net of tax: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net revenue |  |  | $ | 17 |  |  | $ | — |  |  | $ | 17 |  |  |  |  | $ | 197 |  |  | $ | — |  |  | $ | 197 |  |
| Cost of net revenue |  |  | 7 |  |  | — |  |  | 7 |  |  |  |  | — |  |  | — |  |  | — |  |
| Operating expenses |  |  | — |  |  | (3) |  |  | (3) |  |  |  |  | — |  |  | — |  |  | — |  |
| Total reclassifications, net of tax |  |  | $ | 24 |  |  | $ | (3) |  |  | $ | 21 |  |  |  |  | $ | 197 |  |  | $ | — |  |  | $ | 197 |  |


## us-gaap:MinorityInterestDisclosureTextBlock

[0001571996-20-000051:notes:249]
[same as prior period, unchanged from 0001571996-20-000045:notes:235]

[0001571996-20-000051:notes:250]
VMware, Inc. — The non-controlling interests’ share of equity in VMware, Inc. is reflected as a component of the non-controlling interests in the Condensed Consolidated Statements of Financial Position and was $5.0 billion and $4.6 billion as of October 30, 2020 and January 31, 2020, respectively.  As of October 30, 2020 and January 31, 2020, the Company held approximately 80.4% and 80.9%, respectively, of the outstanding equity interest in VMware, Inc.

[0001571996-20-000051:notes:251]
As a result of VMware, Inc.’s acquisition of the non-controlling interest in Pivotal from Pivotal’s public shareholders on December 30, 2019, as described in Note 1 of the Notes to the Condensed Consolidated Financial Statements, the non-controlling interests’ share of equity in Pivotal is only reflected as a component of the non-controlling interest through December 30, 2019.  Pivotal’s Class A common stock ceased to be listed and traded on the NYSE as of the acquisition date, and there was no non-controlling interest in Pivotal as of October 30, 2020 and January 31, 2020.

[0001571996-20-000051:notes:252]
Secureworks — The non-controlling interests’ share of equity in Secureworks is reflected as a component of the non-controlling interests in the Condensed Consolidated Statements of Financial Position and was $94 million and $88 million as of October 30, 2020 and January 31, 2020, respectively.  As of October 30, 2020 and January 31, 2020, the Company held approximately 85.9% and 86.8%, respectively, of the outstanding equity interest in Secureworks, excluding restricted stock awards (“RSAs”).  As of October 30, 2020 and January 31, 2020, the Company held approximately 85.1% and 86.2%, respectively, of the outstanding equity interest in Secureworks, including RSAs.

[0001571996-20-000051:notes:253]
[same as prior period, unchanged from 0001571996-20-000045:notes:239]

[0001571996-20-000051:notes:254]
|  | Nine Months Ended |
|  | October 30, 2020 |
|  | (in millions) |
| Net income attributable to Dell Technologies Inc. | $ | 2,023 |  |
| Transfers (to)/from the non-controlling interests: |  |
| Increase in Dell Technologies Inc. additional paid-in-capital for equity issuances and other equity activity | 774 |  |
| Decrease in Dell Technologies Inc. additional paid-in-capital for equity issuances and other equity activity | (704) |  |
| Net transfers to non-controlling interests | 70 |  |
| Change from net income attributable to Dell Technologies Inc. and transfers to the non-controlling interests | $ | 2,093 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001571996-20-000051:notes:255]
[same as prior period, unchanged from 0001571996-20-000045:notes:241]

[0001571996-20-000051:notes:256]
[same as prior period, unchanged from 0001571996-20-000045:notes:242]

[0001571996-20-000051:notes:257]
|  | Authorized |  | Issued |  | Outstanding |
|  | (in millions) |
| Common stock as of October 30, 2020 |
| Class A | 600 |  |  | 385 |  |  | 385 |  |
| Class B | 200 |  |  | 102 |  |  | 102 |  |
| Class C | 7,900 |  |  | 270 |  |  | 262 |  |
| Class D | 100 |  |  | — |  |  | — |  |
| Class V | 343 |  |  | — |  |  | — |  |
|  | 9,143 |  |  | 757 |  |  | 749 |  |
| Common stock as of January 31, 2020 |
| Class A | 600 |  |  | 385 |  |  | 385 |  |
| Class B | 200 |  |  | 102 |  |  | 102 |  |
| Class C | 7,900 |  |  | 258 |  |  | 256 |  |
| Class D | 100 |  |  | — |  |  | — |  |
| Class V | 343 |  |  | — |  |  | — |  |
|  | 9,143 |  |  | 745 |  |  | 743 |  |

[0001571996-20-000051:notes:258]
[same as prior period, unchanged from 0001571996-20-000045:notes:244]

[0001571996-20-000051:notes:259]
[same as prior period, unchanged from 0001571996-20-000045:notes:245]

[0001571996-20-000051:notes:260]
The Company is authorized to issue one million shares of preferred stock, par value $0.01 per share.  As of October 30, 2020 and January 31, 2020, no shares of preferred stock were issued or outstanding.

[0001571996-20-000051:notes:261]
[same as prior period, unchanged from 0001571996-20-000045:notes:247]

[0001571996-20-000051:notes:262]
[same as prior period, unchanged from 0001571996-20-000045:notes:248]

[0001571996-20-000051:notes:263]
[same as prior period, unchanged from 0001571996-20-000045:notes:249]

[0001571996-20-000051:notes:264]
Conversion Rights — Under the Company’s certificate of incorporation, at any time and from time to time, any holder of Class A Common Stock or Class B Common Stock has the right to convert all or any of the shares of Class A Common Stock or Class B Common Stock, as applicable, held by such holder into shares of Class C Common Stock on a one-to-one basis.  During the nine months ended October 30, 2020, the Company issued 72,727 shares of Class C Common Stock to stockholders upon the conversion of the same number of shares of Class A Common Stock into Class C Common Stock in accordance with the Company’s certificate of incorporation.

[0001571996-20-000051:notes:265]
[same as prior period, unchanged from 0001571996-20-000045:notes:251]

[0001571996-20-000051:notes:266]
[same as prior period, unchanged from 0001571996-20-000045:notes:252]

[0001571996-20-000051:notes:267]
On February 24, 2020, the Company’s board of directors approved a stock repurchase program under which the Company is authorized to repurchase up to $1.0 billion of shares of the Class C Common Stock over a 24-month period expiring on February 28, 2022, of which approximately $760 million remained available as of October 30, 2020.  During the nine months ended October 30, 2020, the Company repurchased approximately 6 million shares of Class C Common Stock for approximately $240 million. During the three months ended May 1, 2020, the Company suspended activity under its stock repurchase program.  During the nine months ended November 1, 2019, Dell Technologies Common Stock repurchases were immaterial.

[0001571996-20-000051:notes:268]
[same as prior period, unchanged from 0001571996-20-000045:notes:254]

[0001571996-20-000051:notes:269]
[same as prior period, unchanged from 0001571996-20-000045:notes:255]

[0001571996-20-000051:notes:270]
On May 29, 2019, VMware, Inc.’s board of directors authorized the repurchase of up to $1.5 billion of VMware, Inc.’s Class A common stock through January 29, 2021.  On July 15, 2020, VMware, Inc.’s board of directors extended authorization of VMware, Inc.’s existing repurchase program and authorized the repurchase of up to an additional $1.0 billion of VMware, Inc.’s Class A common stock through January 28, 2022.  As of October 30, 2020, the cumulative authorized amount remaining for stock repurchases was $1.4 billion.

[0001571996-20-000051:notes:271]
During the nine months ended October 30, 2020, VMware, Inc. repurchased 4.2 million shares of its Class A common stock in the open market for approximately $566 million.  During the nine months ended November 1, 2019, VMware, Inc. repurchased 7.3 million shares of its Class A common stock in the open market for approximately $1.3 billion, of which approximately $0.2 billion impacted Dell Technologies’ accumulated deficit balance as of November 1, 2019 as a result of the full depletion of VMware, Inc’s additional paid-in capital in the same period.

[0001571996-20-000051:notes:272]
[same as prior period, unchanged from 0001571996-20-000045:notes:258]

[0001571996-20-000051:notes:273]
The above VMware, Inc. Class A common stock repurchases for the nine months ended October 30, 2020 and November 1, 2019 exclude shares repurchased to settle employee tax withholding related to the vesting of VMware, Inc. stock awards of $315 million and $442 million, respectively.


## us-gaap:EarningsPerShareTextBlock

[0001571996-20-000051:notes:274]
[same as prior period, unchanged from 0001571996-20-000045:notes:260]

[0001571996-20-000051:notes:275]
[same as prior period, unchanged from 0001571996-20-000045:notes:261]

[0001571996-20-000051:notes:276]
[same as prior period, unchanged from 0001571996-20-000045:notes:262]

[0001571996-20-000051:notes:277]
[same as prior period, unchanged from 0001571996-20-000045:notes:263]

[0001571996-20-000051:notes:278]
[same as prior period, unchanged from 0001571996-20-000045:notes:264]

[0001571996-20-000051:notes:279]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 30, 2020 |  | November 1, 2019 |  | October 30, 2020 |  | November 1, 2019 |
| Earnings per share attributable to Dell Technologies Inc. |  |  |  |  |
| Dell Technologies Common Stock — Basic | $ | 1.11 |  |  | $ | 0.69 |  |  | $ | 2.73 |  |  | $ | 5.84 |  |
| Dell Technologies Common Stock — Diluted | $ | 1.08 |  |  | $ | 0.66 |  |  | $ | 2.64 |  |  | $ | 5.50 |  |

[0001571996-20-000051:notes:280]
[same as prior period, unchanged from 0001571996-20-000045:notes:266]

[0001571996-20-000051:notes:281]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 30, 2020 |  | November 1, 2019 |  | October 30, 2020 |  | November 1, 2019 |
|  | (in millions) |
| Numerator: Dell Technologies Common Stock |  |  |  |  |  |  |  |
| Net income attributable to Dell Technologies — basic | $ | 832 |  |  | $ | 499 |  |  | $ | 2,023 |  |  | $ | 4,208 |  |
| Incremental dilution from VMware, Inc. attributable to Dell Technologies (a) | (3) |  |  | (6) |  |  | (8) |  |  | (81) |  |
| Net income attributable to Dell Technologies — diluted | $ | 829 |  |  | $ | 493 |  |  | $ | 2,015 |  |  | $ | 4,127 |  |
| Denominator: Dell Technologies Common Stock weighted-average shares outstanding |  |  |  |  |
| Weighted-average shares outstanding — basic | 747 |  |  | 725 |  |  | 742 |  |  | 720 |  |
| Dilutive effect of options, restricted stock units, restricted stock, and other | 24 |  |  | 25 |  |  | 22 |  |  | 30 |  |
| Weighted-average shares outstanding — diluted | 771 |  |  | 750 |  |  | 764 |  |  | 750 |  |
| Weighted-average shares outstanding — antidilutive | — |  |  | — |  |  | 1 |  |  | — |  |

[0001571996-20-000051:notes:282]
(a)The incremental dilution from VMware, Inc. represents the impact of VMware, Inc.’s dilutive securities on diluted earnings per share of Dell Technologies Common Stock, and is calculated by multiplying the difference between VMware, Inc.’s basic and diluted earnings per share by the number of shares of VMware, Inc. common stock held by the Company.  For the three and nine months ended November 1, 2019, the incremental dilution from VMware, Inc. was calculated by the Company without regard to VMware, Inc.’s required retrospective adjustments for the Pivotal acquisition in its stand-alone financial statements, and there was no incremental dilution from Pivotal due to its net loss position.  For both periods presented, there was no incremental dilution from Secureworks due to its net loss position.


## dell:TemporaryEquityTextBlock

[0001571996-20-000051:notes:283]
[same as prior period, unchanged from 0001571996-20-000045:notes:269]

[0001571996-20-000051:notes:284]
[same as prior period, unchanged from 0001571996-20-000045:notes:270]

[0001571996-20-000051:notes:285]
[same as prior period, unchanged from 0001571996-20-000045:notes:271]

[0001571996-20-000051:notes:286]
•For stock appreciation rights, restricted stock units, or restricted stock awards, any of which stock award types are subject to service requirements, the fair value of the share is multiplied by the portion of the share for which services have been rendered.

[0001571996-20-000051:notes:287]
[same as prior period, unchanged from 0001571996-20-000045:notes:273]

[0001571996-20-000051:notes:288]
[same as prior period, unchanged from 0001571996-20-000045:notes:274]

[0001571996-20-000051:notes:289]
[same as prior period, unchanged from 0001571996-20-000045:notes:275]

[0001571996-20-000051:notes:290]
|  | October 30, 2020 |  | January 31, 2020 |
|  | (in millions) |
| Redeemable shares classified as temporary equity | $ | 527 |  |  | $ | 629 |  |
| Issued and outstanding unrestricted common shares | 2 |  |  | 2 |  |
| Restricted stock units | — |  |  | 1 |  |
| Restricted stock awards | — |  |  | — |  |
| Outstanding stock options | 9 |  |  | 15 |  |

[0001571996-20-000051:notes:291]
The decrease in the value of redeemable shares during the nine months ended October 30, 2020 was primarily attributable to a reduction in the number of shares eligible for put rights.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001571996-20-000051:notes:292]
[same as prior period, unchanged from 0001571996-20-000045:notes:278]

[0001571996-20-000051:notes:293]
[same as prior period, unchanged from 0001571996-20-000045:notes:279]

[0001571996-20-000051:notes:294]
[same as prior period, unchanged from 0001571996-20-000045:notes:280]

[0001571996-20-000051:notes:295]
[same as prior period, unchanged from 0001571996-20-000045:notes:281]

[0001571996-20-000051:notes:296]
[same as prior period, unchanged from 0001571996-20-000045:notes:282]

[0001571996-20-000051:notes:297]
[same as prior period, unchanged from 0001571996-20-000045:notes:283]

[0001571996-20-000051:notes:298]
[same as prior period, unchanged from 0001571996-20-000045:notes:284]

[0001571996-20-000051:notes:299]
[same as prior period, unchanged from 0001571996-20-000045:notes:285]

[0001571996-20-000051:notes:300]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 30, 2020 |  | November 1, 2019 |  | October 30, 2020 |  | November 1, 2019 |
|  | (in millions) |
| Consolidated net revenue: |  |  |  |  |  |  |  |
| Infrastructure Solutions Group | $ | 8,024 |  |  | $ | 8,390 |  |  | $ | 23,800 |  |  | $ | 25,213 |  |
| Client Solutions Group | 12,286 |  |  | 11,410 |  |  | 34,593 |  |  | 34,068 |  |
| VMware | 2,893 |  |  | 2,671 |  |  | 8,556 |  |  | 7,779 |  |
| Reportable segment net revenue | 23,203 |  |  | 22,471 |  |  | 66,949 |  |  | 67,060 |  |
| Other businesses (a) | 314 |  |  | 456 |  |  | 1,288 |  |  | 1,311 |  |
| Unallocated transactions (b) | 4 |  |  | 1 |  |  | 4 |  |  | 1 |  |
| Impact of purchase accounting (c) | (39) |  |  | (84) |  |  | (129) |  |  | (250) |  |
| Total consolidated net revenue | $ | 23,482 |  |  | $ | 22,844 |  |  | $ | 68,112 |  |  | $ | 68,122 |  |
| Consolidated operating income: |  |  |  |  |  |  |  |
| Infrastructure Solutions Group | $ | 882 |  |  | $ | 996 |  |  | $ | 2,587 |  |  | $ | 2,889 |  |
| Client Solutions Group | 1,002 |  |  | 739 |  |  | 2,309 |  |  | 2,514 |  |
| VMware | 837 |  |  | 709 |  |  | 2,504 |  |  | 2,055 |  |
| Reportable segment operating income | 2,721 |  |  | 2,444 |  |  | 7,400 |  |  | 7,458 |  |
| Other businesses (a) | 3 |  |  | — |  |  | 105 |  |  | (48) |  |
| Unallocated transactions (b) | 1 |  |  | (2) |  |  | (1) |  |  | (29) |  |
| Impact of purchase accounting (c) | (49) |  |  | (96) |  |  | (165) |  |  | (299) |  |
| Amortization of intangibles | (845) |  |  | (1,057) |  |  | (2,547) |  |  | (3,334) |  |
| Transaction-related expenses (d) | (52) |  |  | (76) |  |  | (211) |  |  | (165) |  |
| Stock-based compensation expense (e) | (436) |  |  | (322) |  |  | (1,219) |  |  | (886) |  |
| Other corporate expenses (f) | (214) |  |  | (55) |  |  | (395) |  |  | (792) |  |
| Total consolidated operating income | $ | 1,129 |  |  | $ | 836 |  |  | $ | 2,967 |  |  | $ | 1,905 |  |

[0001571996-20-000051:notes:301]
(a)Secureworks, Virtustream, and Boomi constitute “Other businesses” and do not meet the requirements for a reportable segment, either individually or collectively.  The results of Other businesses are not material to the Company’s overall results.  On September 1, 2020, the Company completed the sale of RSA Security.  Prior to the divestiture, RSA Security’s results were included in “Other businesses.”  See Note 1 of the Notes to the Condensed Consolidated Financial Statements for more information about the sale of RSA Security.

[0001571996-20-000051:notes:302]
[same as prior period, unchanged from 0001571996-20-000045:notes:288]

[0001571996-20-000051:notes:303]
[same as prior period, unchanged from 0001571996-20-000045:notes:289]

[0001571996-20-000051:notes:304]
[same as prior period, unchanged from 0001571996-20-000045:notes:290]

[0001571996-20-000051:notes:305]
[same as prior period, unchanged from 0001571996-20-000045:notes:291]

[0001571996-20-000051:notes:306]
(f)Other corporate expenses includes impairment charges, severance, facility action, and other costs.  During the nine months ended November 1, 2019, this category includes Virtustream gross impairment charges of $619 million.

[0001571996-20-000051:notes:307]
[same as prior period, unchanged from 0001571996-20-000045:notes:293]

[0001571996-20-000051:notes:308]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 30, 2020 |  | November 1, 2019 |  | October 30, 2020 |  | November 1, 2019 |
|  | (in millions) |
| Net revenue: |  |  |  |  |  |  |  |
| Infrastructure Solutions Group: |  |  |  |  |  |  |  |
| Servers and networking | $ | 4,164 |  |  | $ | 4,241 |  |  | $ | 12,118 |  |  | $ | 12,858 |  |
| Storage | 3,860 |  |  | 4,149 |  |  | 11,682 |  |  | 12,355 |  |
| Total ISG net revenue | 8,024 |  |  | 8,390 |  |  | 23,800 |  |  | 25,213 |  |
| Client Solutions Group: |  |  |  |  |  |  |  |
| Commercial | 8,783 |  |  | 8,330 |  |  | 25,456 |  |  | 25,714 |  |
| Consumer | 3,503 |  |  | 3,080 |  |  | 9,137 |  |  | 8,354 |  |
| Total CSG net revenue | 12,286 |  |  | 11,410 |  |  | 34,593 |  |  | 34,068 |  |
| VMware: |  |  |  |  |  |  |  |
| Total VMware net revenue | 2,893 |  |  | 2,671 |  |  | 8,556 |  |  | 7,779 |  |
| Total segment net revenue | $ | 23,203 |  |  | $ | 22,471 |  |  | $ | 66,949 |  |  | $ | 67,060 |  |


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0001571996-20-000051:notes:309]
[same as prior period, unchanged from 0001571996-20-000045:notes:295]

[0001571996-20-000051:notes:310]
[same as prior period, unchanged from 0001571996-20-000045:notes:296]

[0001571996-20-000051:notes:311]
|  | October 30, 2020 |  | January 31, 2020 |
|  | (in millions) |
| Cash, cash equivalents, and restricted cash: |  |  |  |
| Cash and cash equivalents | $ | 11,304 |  |  | $ | 9,302 |  |
| Restricted cash - other current assets (a) | 761 |  |  | 730 |  |
| Restricted cash - other non-current assets (a) | 92 |  |  | 119 |  |
| Total cash, cash equivalents, and restricted cash | $ | 12,157 |  |  | $ | 10,151 |  |
| Inventories, net: |  |  |  |
| Production materials | $ | 1,687 |  |  | $ | 1,590 |  |
| Work-in-process | 710 |  |  | 563 |  |
| Finished goods | 996 |  |  | 1,128 |  |
| Total inventories, net | $ | 3,393 |  |  | $ | 3,281 |  |
| Other non-current assets: |  |  |  |
| Deferred and other tax assets | $ | 6,127 |  |  | $ | 5,960 |  |
| Operating lease ROU assets | 2,179 |  |  | 1,780 |  |
| Deferred commissions | 1,028 |  |  | 998 |  |
| Other | 1,727 |  |  | 1,690 |  |
| Total other non-current assets | $ | 11,061 |  |  | $ | 10,428 |  |
| Other non-current liabilities: |  |  |  |
| Deferred and other tax liabilities | $ | 2,184 |  |  | $ | 3,110 |  |
| Operating lease liabilities | 1,829 |  |  | 1,360 |  |
| Warranty liability | 130 |  |  | 155 |  |
| Other | 1,290 |  |  | 758 |  |
| Total other non-current liabilities | $ | 5,433 |  |  | $ | 5,383 |  |

[0001571996-20-000051:notes:312]
(a)    Restricted cash primarily includes cash required to be held in escrow pursuant to DFS securitization arrangements and VMware, Inc. restricted cash.

[0001571996-20-000051:notes:313]
[same as prior period, unchanged from 0001571996-20-000045:notes:299]

[0001571996-20-000051:notes:314]
Allowance for expected credit losses of trade receivables as of October 30, 2020 includes the impact of adoption of the new CECL standard, which was adopted as of February 1, 2020 using the modified retrospective method, as described in Note 1 of the Notes to the Condensed Consolidated Financial Statements.  The provision recognized on the Condensed Consolidated Statements of Income (Loss) during the three and nine months ended October 30, 2020 is based on an assessment of the impact of current and expected future conditions, inclusive of the effect of the COVID-19 pandemic on credit losses.  The duration and severity of COVID-19 and continued market volatility is highly uncertain and, as such, the impact on expected credit losses is subject to significant judgment and may cause variability in the Company’s allowance for credit losses in future periods.

[0001571996-20-000051:notes:315]
[same as prior period, unchanged from 0001571996-20-000045:notes:301]

[0001571996-20-000051:notes:316]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 30, 2020 |  | October 30, 2020 |
|  | (in millions) |
| Trade Receivables - Allowance for expected credit losses: |  |  |  |
| Balance at beginning of period | $ | 146 |  |  | $ | 94 |  |
| Adjustment for adoption of the new CECL standard (Note 1) | — |  |  | 27 |  |
| Provision charged to income statement | (4) |  |  | 43 |  |
| Bad debt write-offs | (27) |  |  | (49) |  |
| Balance at end of period | $ | 115 |  |  | $ | 115 |  |

[0001571996-20-000051:notes:317]
[same as prior period, unchanged from 0001571996-20-000045:notes:303]

[0001571996-20-000051:notes:318]
[same as prior period, unchanged from 0001571996-20-000045:notes:304]

[0001571996-20-000051:notes:319]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 30, 2020 |  | November 1, 2019 |  | October 30, 2020 |  | November 1, 2019 |
|  | (in millions) |
| Warranty liability: |  |  |  |  |  |  |  |
| Warranty liability at beginning of period | $ | 479 |  |  | $ | 525 |  |  | $ | 496 |  |  | $ | 524 |  |
| Costs accrued for new warranty contracts and changes in estimates for pre-existing warranties (a) (b) | 219 |  |  | 211 |  |  | 573 |  |  | 651 |  |
| Service obligations honored | (206) |  |  | (216) |  |  | (577) |  |  | (655) |  |
| Warranty liability at end of period | $ | 492 |  |  | $ | 520 |  |  | $ | 492 |  |  | $ | 520 |  |
| Current portion | $ | 362 |  |  | $ | 351 |  |  | $ | 362 |  |  | $ | 351 |  |
| Non-current portion | $ | 130 |  |  | $ | 169 |  |  | $ | 130 |  |  | $ | 169 |  |

[0001571996-20-000051:notes:320]
[same as prior period, unchanged from 0001571996-20-000045:notes:306]

[0001571996-20-000051:notes:321]
[same as prior period, unchanged from 0001571996-20-000045:notes:307]

[0001571996-20-000051:notes:322]
Severance Charges

[0001571996-20-000051:notes:323]
The Company incurs costs related to employee severance and records a liability for these costs when it is probable that employees will be entitled to termination benefits and the amounts can be reasonably estimated.  The liability related to these actions is included in accrued and other current liabilities in the Condensed Consolidated Statements of Financial Position.  The following table presents the activity related to the Company’s severance liability for the periods indicated:

[0001571996-20-000051:notes:324]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 30, 2020 |  | November 1, 2019 |  | October 30, 2020 |  | November 1, 2019 |
|  | (in millions) |
| Severance liability: |  |  |  |  |  |  |  |
| Severance liability at beginning of period | $ | 168 |  |  | $ | 115 |  |  | $ | 196 |  |  | $ | 146 |  |
| Severance charges to provision | 226 |  |  | 44 |  |  | 417 |  |  | 141 |  |
| Cash paid and other (a) | (181) |  |  | (44) |  |  | (400) |  |  | (172) |  |
| Severance liability at end of period | $ | 213 |  |  | $ | 115 |  |  | $ | 213 |  |  | $ | 115 |  |

[0001571996-20-000051:notes:325]
(a)Other adjustments include the impact of foreign currency exchange rate fluctuations.

[0001571996-20-000051:notes:326]
The following table presents severance charges as included in the Condensed Consolidated Statements of Income (Loss) for the periods indicated:

[0001571996-20-000051:notes:327]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 30, 2020 |  | November 1, 2019 |  | October 30, 2020 |  | November 1, 2019 |
|  | (in millions) |
| Severance charges: |  |  |  |  |  |  |  |
| Cost of net revenue | $ | 46 |  |  | $ | — |  |  | $ | 58 |  |  | $ | 14 |  |
| Selling, general, and administrative | 139 |  |  | 31 |  |  | 308 |  |  | 103 |  |
| Research and development | 41 |  |  | 13 |  |  | 51 |  |  | 24 |  |
| Total severance charges | $ | 226 |  |  | $ | 44 |  |  | $ | 417 |  |  | $ | 141 |  |

[0001571996-20-000051:notes:328]
Interest and Other, Net

[0001571996-20-000051:notes:329]
The following table provides information regarding interest and other, net for the periods indicated:

[0001571996-20-000051:notes:330]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 30, 2020 |  | November 1, 2019 |  | October 30, 2020 |  | November 1, 2019 |
|  | (in millions) |
| Interest and other, net: |  |  |  |  |  |  |  |
| Investment income, primarily interest | $ | 11 |  |  | $ | 41 |  |  | $ | 47 |  |  | $ | 127 |  |
| Gain on investments, net (a) | 489 |  |  | 18 |  |  | 591 |  |  | 160 |  |
| Interest expense | (566) |  |  | (654) |  |  | (1,855) |  |  | (2,045) |  |
| Foreign exchange | (31) |  |  | (43) |  |  | (130) |  |  | (123) |  |
| Other (b) | 370 |  |  | (39) |  |  | 418 |  |  | (119) |  |
| Total interest and other, net | $ | 273 |  |  | $ | (677) |  |  | $ | (929) |  |  | $ | (2,000) |  |

[0001571996-20-000051:notes:331]
(a)Includes a $465 million gain on the fair value adjustment of a strategic investment during three months ended October 30, 2020.  See Note 3 of the Notes to the Condensed Consolidated Financial Statements for more information.

[0001571996-20-000051:notes:332]
(b)Includes a pre-tax gain of $338 million on the sale of RSA Security during three months ended October 30, 2020.  See Note 1 of the Notes to the Condensed Consolidated Financial Statements for more information.
